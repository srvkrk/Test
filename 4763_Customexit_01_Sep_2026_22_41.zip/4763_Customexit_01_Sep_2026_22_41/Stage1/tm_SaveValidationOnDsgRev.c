/****************************************************************************************************
*  File           :		tm_SaveValidationOnDsgRev.c
*  Created By     :		Sudhir Srivastava
*  Created On     :		05-Sept-2011
*  Purpose        :		Remove extra character from Desciption of Design and Design Revision.
*						This is called at pre action of save.
*
*  Modification History :
*  S.No		Date			CR		Modified By			Modification Notes
*	1		15/06/2012				Sharvari Karale		Added save_method_5 and save_method_4 for Attribute Mapping of Design Reision/CMI2Drawing
*	2		04/05/2016				Muktesh Girdhani	Removed file createpost (createpost.so) and added code in this file, Updation of NR;1 Revision done in this file.
*	3		08/08/2018				Mohan Tayade		New DFM-A DML introduction and validations/Live for DR-validations.
*	4		12/09/2016				Mohan Tayade		DFM-A module should be attached under Architecture module.
*	5		28/04/2019				Ashwini Yedake		Migration from hexavalent Cr-coated fasteners to trivalent Cr-coated fasteners in line with the validation in TcE for PVBU
*   6		17/07/2019				Ashwini Yedake		Dummy Component/Dummy Assembly /Component  parttype not allowed if for 12-digit part 9th and 10th digit is 01. It has to be assembly.
*   7		18/07/2019				Rupali Rane			Added save_method_Design_3 for new upgradation of IPEM 11.5.2 and Creo4
*   8		14/11/2019				Ashwini Yedake		Revise API change from ITEM_find_item to ITEM_find_items_by_key_attributes
*   9		02/01/2020				Ashwini Yedake		Extension of Fasteners related check for Nexon to TcUA
*   10		05-02-2022	CR/ERC/PLM/22/0027				Validation for Module Address Added on Design Revision
******************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#define ITK_Prjerr (EMH_USER_error_base + 8)
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <cfm/cfm.h>
#include <ce/ce.h>
#include <tccore/aom_prop.h>
#include <bom/bom_attr.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/project.h>
#include <tccore/tc_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <bom/bom_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <sa/workcontext.h>
#include <tcinit/tcinit.h>
#include <ctype.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/sa_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <tc/preferences.h> //MBOM implementation for CV TZ-1.69
#include <pie/pie.h> //closure rule
#include<ics/ics.h>  //For classification
#include<ics/ics2.h> //For classification
#include<ics/ics_defines.h> //For classification
#include<ics/ics_errors.h> //For classification
#define ITK_err 919006
#define	t9NewPartReqCre_Val0048 (EMH_USER_error_base+21)
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_errStore1 (EMH_USER_error_base + 7)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d) ", __LINE__, ifail); return 0;}
#define GRM_create_msg           "GRM_create"

int customStrStr();
/************************* Adi ****************/
#define PLM_error (EMH_USER_error_base + 325)
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s) ", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s ", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s ", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n ", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d ", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

int checkProjectCodeAccess(char*,char*);

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d  ",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "\n Error(PrintErrorStack): ");
        fprintf( stderr, "\t%6d: %s ", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

void reverse1(char *s) // Added by Ketan to remove warning for 14.3
{
   int length, c;
   char *begin, *end, temp;

   length = tc_strlen(s);
   begin  = s;
   end    = s;

   for (c = 0; c < length - 1; c++)
      end++;

   for (c = 0; c < length/2; c++)
   {
      temp   = *end;
      *end   = *begin;
      *begin = temp;

      begin++;
      end--;
   }
}

void GetPlantWiseRelStatAtAPL1( char * item_id ,char  getLCSAPLWrkg[40],char  getLCSAPLRlzd[40]) // Added by Ketan to remove warning for 14.3
{
	char* Dsgn_No = NULL;
	char* PLT_Code = NULL;
	char  ItemIDCpy[40];

	char *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};
	char **qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	int cntrlcnt=0;
	int  control_number_found1=0;

	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;

	char *APLWrkng			= NULL;
	char *APLRlzd			= NULL;

	printf( "\n GetPlantWiseRelStatAtAPL1::item_id:%s\n", item_id);
	tc_strcpy(ItemIDCpy,item_id);
	printf("\n GetPlantWiseRelStatAtAPL1::ItemIDCpy is : %s\n",ItemIDCpy);fflush(stdout);
	Dsgn_No=tc_strtok(ItemIDCpy,"_");
	printf("\n GetPlantWiseRelStatAtAPL1::Test0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,ItemIDCpy);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\n GetPlantWiseRelStatAtAPL1::Test0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,ItemIDCpy);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\n GetPlantWiseRelStatAtAPL1::Test0.13..PLT_Code:[%s],[%s]\n",PLT_Code,ItemIDCpy);

	if( QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n GetPlantWiseRelStatAtAPL1::Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="APLStateInf";
		qry_valuesCntrl1[1]=PLT_Code;
		qry_valuesCntrl1[2]="0";

		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	else
	{
		printf("\n GetPlantWiseRelStatAtAPL1::Control Object Query not Found \n");fflush(stdout);
	}

	printf("\n GetPlantWiseRelStatAtAPL1::control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

	if(control_number_found1>0)
	{

		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &APLWrkng);
		printf("\n GetPlantWiseRelStatAtAPL1::APLWrkng: %s\n",APLWrkng);fflush(stdout);

		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &APLRlzd);
		printf("\n GetPlantWiseRelStatAtAPL1::APLRlzd: %s\n",APLRlzd);fflush(stdout);

		tc_strcpy(getLCSAPLWrkg,APLWrkng);
		tc_strcpy(getLCSAPLRlzd,APLRlzd);
	}
	else
	{
		tc_strcpy(getLCSAPLWrkg,"T5_LcsAPLpWrkg");
		tc_strcpy(getLCSAPLRlzd,"T5_LcsAplpRlzd");
	}

	printf( "\n GetPlantWiseRelStatAtAPL1::getLCSAPLWrkg:%s\n", getLCSAPLWrkg);
	printf( "\n GetPlantWiseRelStatAtAPL1::getLCSAPLRlzd:%s\n", getLCSAPLRlzd);
}

int tm_check_info_control_object_gen ( char *syscd, char *subsyscd, char *info1, char *info2 )
{
	int n_found = 0 ;
	int n_entries = 4 ;
	char *qry_entries[4] = { "SYSCD", "SUBSYSCD","Information-1","Information-2" } ;
	char *qry_values[4] =  { syscd, subsyscd,info1,info2} ;
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;
	char *l_info1 = NULL ;
	char *l_info2 = NULL ;

	ITK_CALL ( QRY_find2 ( "Control Objects...", &query ) ) ;
	ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
    printf ("\n tm_check_info_control_object_gen::[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;
    TC_write_syslog ("\n tm_check_info_control_object_gen::[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;

	if ( n_found > 0 )
	{
		ITK_CALL ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&l_info1) );
		tc_strcpy( info1, l_info1 );
		ITK_CALL ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo2",&l_info2) );
		tc_strcpy( info2, l_info2 );

		TC_write_syslog ("\n tm_check_info_control_object_gen::info1 : [%s] info2 : [%s]" ,info1 ,info2 ) ; fflush ( stdout) ;
	}

	return n_found ;
}

void  GetPlantForDMLORTask1( char * item_id ,char  getPlant[40]) //// Added by Ketan to remove warning for 14.3
{
    printf( "\n GetPlantForDMLORTask1::item_id:%s ", item_id);

	char *item_idCpy =NULL;
	char *revStr =NULL;
	char *tmpStr =NULL;
	char *revStr1 =NULL;
	item_idCpy	=	(char *)MEM_alloc(50);

	tc_strcpy(item_idCpy,item_id);
	reverse1(item_idCpy);
	revStr	=	(char *)MEM_alloc(50);
	tc_strcpy(revStr,item_idCpy);
	printf("\n GetPlantForDMLORTask1::revStr Find %s.......",revStr);fflush(stdout);
	tmpStr	=	strtok(revStr,"_");
	printf("\n GetPlantForDMLORTask1::tmpStr Find %s.......",tmpStr);fflush(stdout);
	revStr1	=	(char *)MEM_alloc(50);
	reverse1(tmpStr);
	tc_strcpy(revStr1,tmpStr);
	printf("\n GetPlantForDMLORTask1::revStr1 Find %s.......",revStr1);fflush(stdout);
	tc_strcpy(getPlant,revStr1);

	printf( "\n GetPlantForDMLORTask1::getPlant:%s\n", getPlant);
}

//Check ERC_PLM_SUPPORT group
int CheckSupportLogin_DR(tag_t SessionUser_tag)
{
	int     ac    = 0;
	int     Accessflag    = 0;
	int     AccessCount    = 0;
	int     Support_rsltCount    = 0;
	int     Support_n_entry    = 1;
	tag_t	*SupportCntrlObjectTag	= NULLTAG;
	tag_t	SupportqryTag		= NULLTAG;
	char    *Support_qry_entry[1]  = {"SYSCD"};
	char    **Support_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char*	 Supportinfo1 = NULL;
	char*	 Supportinfo2 = NULL;
	char*	 AccessFound_name = NULL;
	tag_t	AccessFound_tg = NULLTAG;
	tag_t	*AccessFound = NULLTAG;

	printf("\n CheckSupportLogin_DR--CheckSupportLogin...\n");fflush(stdout);
	//GETTING mileston obj.
	if(QRY_find2("ControlObjects",&SupportqryTag));
	if (SupportqryTag)
	{
		printf("\n CheckSupportLogin_DR--Found Query SupportqryTag \n");fflush(stdout);
	}
	else
	{
		printf("\n CheckSupportLogin_DR--Not Found Query SupportqryTag \n");fflush(stdout);
	}

	Support_qry_values2[0] = "SUPPORT";
	if(QRY_execute(SupportqryTag, Support_n_entry, Support_qry_entry, Support_qry_values2,&Support_rsltCount,&SupportCntrlObjectTag));
	printf(" \n CheckSupportLogin_DR--DR_rsltCount :%d:", Support_rsltCount); fflush(stdout);
	if(Support_rsltCount > 0)
	{
		if (AOM_ask_value_string(SupportCntrlObjectTag[0],"t5_Userinfo1",&Supportinfo1)!=ITK_ok)   PrintErrorStack();
		printf("\n CheckSupportLogin_DR--Supportinfo1 is : [%s]\n", Supportinfo1);fflush(stdout);

		if (AOM_ask_value_string(SupportCntrlObjectTag[0],"t5_Userinfo2",&Supportinfo2)!=ITK_ok)   PrintErrorStack();
		printf("\n CheckSupportLogin_DR--Supportinfo2 is : [%s]\n", Supportinfo2);fflush(stdout);
		if(tc_strstr(Supportinfo1,"CHKLOGINOFF")==NULL)
		{
			//if (SA_find_groupmember_by_user(SessionUser_tag,&Gmcnt,&GmFound)!=ITK_ok)PrintErrorStack();
			if (SA_find_groupmember_by_user(SessionUser_tag,&AccessCount,&AccessFound)!=ITK_ok)PrintErrorStack();
			printf("\n CheckSupportLogin_DR--count of AccessCount: [%d]", AccessCount);fflush(stdout);
			for(ac=0;ac<AccessCount;ac++)
			{
				AccessFound_tg = AccessFound[ac];
				if (AOM_ask_value_string(AccessFound_tg,"object_name",&AccessFound_name)!=ITK_ok)   PrintErrorStack();
				//printf("\n Actual Group Member AccessFound_name: [%s]", AccessFound_name);fflush(stdout);
				if((tc_strstr(AccessFound_name,Supportinfo1)!=NULL)|| (tc_strstr(AccessFound_name,Supportinfo2)!=NULL))
				{
					Accessflag++;
					printf("\n CheckSupportLogin_DR--AccessFound_name----: [%s][%d]", AccessFound_name,Accessflag);fflush(stdout);
					break;
				}
			}
			if(Accessflag >0)
			{
				printf("\n CheckSupportLogin_DR--support access found.\n");fflush(stdout);
				return 1;
			}
			else
			{
				printf("\n CheckSupportLogin_DR--support access not found. \n");fflush(stdout);
				return 0;
			}
		}
	}

	return 0;
}
//Ashwini- to query Obsolete part from Table if exist
char* QueryObsPart_Uses(char* ProjctcdeS)
{
	tag_t queryTag		= NULLTAG;
	tag_t *NewPartsSet	= NULLTAG;
	tag_t PrjCdObj		= NULLTAG;

	int n_entries = 1;
	int resultCount =0;

	char *ProjectCodeValS	= NULL;
	char *ProjectCodeValS1	= NULL;
	//char *qry_entries[2] = {"t5_Obspno","t5_AltPartInd"};
	//char *qry_entries[2] = {"Obspno","Alt Part Ind"};
	char *qry_entries[1] = {"Obspno"};
	char **qry_values = (char **) MEM_alloc(20 * sizeof(char *));

	//printf("\nIn QueryObsPart_Uses"); fflush(stdout);
	printf("\n QueryObsPart_Uses::In QueryObsPart_Uses ProjctcdeS = %s",ProjctcdeS); fflush(stdout);
	qry_values[0]=ProjctcdeS;
	//qry_values[1]="DELMAT";
	//qry_values[1]="";

	if(QRY_find2("Cntrl_t5ObmPrt", &queryTag));
	if (queryTag)
	{
		printf("\nCntrl_t5ObmPrt... Found Query ControlObjects ");
		fflush(stdout);
	}
	else
	{
		printf("\n QueryObsPart_Uses::General Cntrl_t5ObmPrt...:Not Found Query ControlObjects ");
	}

	if(QRY_execute(queryTag,n_entries,qry_entries,qry_values,&resultCount,&NewPartsSet));
	printf("\n QueryObsPart_Uses::11 Unique General... Query resultCount :%d: ", resultCount); fflush(stdout);

	if (resultCount > 0)
	{
		PrjCdObj = NewPartsSet[0];
		if(AOM_ask_value_string(PrjCdObj,"t5_Proalpno",&ProjectCodeValS) != ITK_ok);
		printf("\n QueryObsPart_Uses::ProjectCodeValS = %s",ProjectCodeValS); fflush(stdout);
		if(strcmp(ProjectCodeValS,"")!=0)
		{
			ProjectCodeValS1=ProjectCodeValS;
		}
		else
		{
			ProjectCodeValS1="PrtDelete";
		}
	}
	else
	{
		//printf("\n QueryObsPart_Uses::In ELSE... ");fflush(stdout);
		ProjectCodeValS1 = "QryNotFound";
		printf("\n QueryObsPart_Uses::In ELSE ProjectCodeValS1 = %s... ",ProjectCodeValS1);fflush(stdout);
	}

	printf("\n QueryObsPart_Uses::ProjectCodeValS1 = %s",ProjectCodeValS1); fflush(stdout);
	return ProjectCodeValS1;
}

//Ashwini- to query Obsolete part from Table if exist
char* QueryObsPartOSPREY_Uses(char* ProjctcdeS)
{
	tag_t queryTag		= NULLTAG;
	tag_t *NewPartsSet	= NULLTAG;
	tag_t PrjCdObj		= NULLTAG;

	int n_entries = 2;
	int resultCount =0;

	char *ProjectCodeValS	= NULL;
	char *ProjectCodeValS1	= NULL;
	//char *qry_entries[2] = {"t5_Obspno","t5_AltPartInd"};
	char *qry_entries[2] = {"Obspno","Alt Part Ind"};
	//char *qry_entries[1] = {"Obspno"};
	char **qry_values = (char **) MEM_alloc(20 * sizeof(char *));

	printf("\n QueryObsPartOSPREY_Uses--In QueryObsPart_Uses ProjctcdeS = %s",ProjctcdeS); fflush(stdout);
	qry_values[0]=ProjctcdeS;
	qry_values[1]="OSPREY";
	//qry_values[1]="";

	//if(QRY_find2("Cntrl_t5ObmPrt", &queryTag));
	if(QRY_find2("Cntrl_t5ObmPrt_OSPRY", &queryTag));
	if (queryTag)
	{
		printf("\nQueryObsPartOSPREY_Uses--Cntrl_t5ObmPrt... Found Query ControlObjects ");	fflush(stdout);

		if(QRY_execute(queryTag,n_entries,qry_entries,qry_values,&resultCount,&NewPartsSet));
	}
	else
	{
		printf("\nQueryObsPartOSPREY_Uses--General Cntrl_t5ObmPrt...:Not Found Query ControlObjects ");
	}

	printf("\nQueryObsPartOSPREY_Uses--Unique General... Query resultCount :%d: ", resultCount); fflush(stdout);

	if (resultCount > 0)
	{
		ProjectCodeValS1="OSPREYPresnt";
		//PrjCdObj = NewPartsSet[0];
		//if(AOM_ask_value_string(PrjCdObj,"t5_Proalpno",&ProjectCodeValS) != ITK_ok);
		//printf("\nIn ProjectCodeValS = %s",ProjectCodeValS); fflush(stdout);
		//if(strcmp(ProjectCodeValS,"")!=0)
		//{
		//	ProjectCodeValS1=ProjectCodeValS;
		//}
		//else
		//{
		//	ProjectCodeValS1="PrtDelete";
		//}
	}
	else
	{
		printf("\nQueryObsPartOSPREY_Uses--In ELSE... ");fflush(stdout);
		ProjectCodeValS1 = "OSPREYNTPresnt";
	}

	printf("\nQueryObsPartOSPREY_Uses--In ProjectCodeValS1 = %s",ProjectCodeValS1); fflush(stdout);
	return ProjectCodeValS1;
}
/************************* Adi ****************/

char* subString (char* mainStringf, int fromCharf, int toCharf)
{
	int i;
	char *retStringf=NULL;
	if(!mainStringf) return NULL;//input string if null
	retStringf = (char*) malloc(strlen(mainStringf)+1);
	if (!retStringf) return NULL;//failed to allocate memory
	for(i=0; i < toCharf; i++ )
        *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


// setAddStr function added by Aadarsh
void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}

	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	tc_strcpy((*strset)[*count-1],str);
	printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}
//;
//setFindStr1 function added by Aadarsh
int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;

	//tmp = sizeof(*strset);

	for(j=0;j<*count;j++)
	{
		printf("\n setFindStr1= %d  setFindStr1 value is ===%s",*count,(*strset)[j]);fflush(stdout);
		//printf("\n setFindStr1 value is ===%s",(*strset)[*count-1]);fflush(stdout);

		//if(tc_strcmp((*strset)[*count-1],str)==0) //check this
		if(tc_strcmp((*strset)[j],str)==0) //check this
		//if(tc_strcmp(*strset[j],str)==0)

		return j;
	}
	return -1;
}
//Vitthal :START: Validate Part Creation
int Validate_On_Creation(tag_t DesignRevision)
{
	char* sPartType;
	char* sStartPrtProd;
	char *sUserInfoVal = NULL;
	char *sDesGrp = NULL;

	tag_t
		TagQryContObjDsgGrp = NULLTAG,
		*cntr_objects = NULL;
	int	n_entries = 2;
	int n_found = 0;

	char *qry_entries[2] = {"SYSCD", "SUBSYSCD"};
    char *qry_values[2] = {"TOOLTYPE", "DESIGNGROUP"};

	if (AOM_ask_value_string(DesignRevision,"t5_PartType",&sPartType)!=ITK_ok) PrintErrorStack();
	if (AOM_ask_value_string(DesignRevision,"t5_StartPartProduct",&sStartPrtProd)!=ITK_ok) PrintErrorStack();
	if(	AOM_ask_value_string(DesignRevision,"t5_DesignGrp",&sDesGrp)!=ITK_ok) PrintErrorStack();

	printf("\n Validate_On_Creation--AOM_ask_value_string sPartType  %s sStartPrtProd  %s  ",sPartType,sStartPrtProd);fflush(stdout);

	 if(QRY_find2("ControlObjFindCadToolBasedOnDesGrp", &TagQryContObjDsgGrp));

	 if(QRY_execute(TagQryContObjDsgGrp, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
	 printf("\n Validate_On_Creation--Objects for Query ControlObjFindCadToolBasedOnDesGrp == %d", n_found);fflush(stdout);

	 if(n_found==1)
	 {
		if( AOM_ask_value_string(cntr_objects[0],"t5_userinfo10",&sUserInfoVal));
		 printf("\n Validate_On_Creation--Information 10 Value == [%s] and User Enter Design Group :[%s]", sUserInfoVal,sDesGrp);fflush(stdout);
		if(tc_strstr(sUserInfoVal, sDesGrp) != NULL)
		{
			if(((strcmp(sPartType,"A")==0) ||(strcmp(sPartType,"C")==0) ||(strcmp(sPartType,"T")==0) ||(strcmp(sPartType,"G")==0)) && (tc_strcmp(sStartPrtProd,"")==0))return 1;
		}
	 }
	return 0;
}
//Vitthal :END: Validate Part Creation

// check milestone live project START
// int CheckMilestoneLive(char* sProject)
// {
	// int     Milston_rsltCount    = 0;
	// int     Milston_n_entry    = 1;
	// tag_t     *MilstonCntrlObjectTag                = NULLTAG;
	// tag_t     MilestoneqryTag                              = NULLTAG;
	// char    *Milston_qry_entry[1]  = {"SYSCD"};
	// char    **Milston_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	// char*     Milstoninfo1 = NULL;
	// char*     Milstoninfo2 = NULL;

	// printf("\n P: CheckMilestoneLive for project: %s  ", sProject);fflush(stdout);
	// //GETTING mileston obj.
	// if(QRY_find2("ControlObjects", &MilestoneqryTag));
	// if (MilestoneqryTag)
	// {
		// printf("\n P1:Found Query MilestoneqryTag  ");fflush(stdout);
	// }
	// else
	// {
		// printf("\n P2:Not Found Query MilestoneqryTag  ");fflush(stdout);
	// }

	// Milston_qry_values2[0] = "Milston";
	// if(QRY_execute(MilestoneqryTag, Milston_n_entry, Milston_qry_entry, Milston_qry_values2, &Milston_rsltCount, &MilstonCntrlObjectTag));
	// printf(" \n P3:DR_rsltCount :%d:", Milston_rsltCount); fflush(stdout);
	// if(Milston_rsltCount > 0)
	// {
		// if (AOM_ask_value_string(MilstonCntrlObjectTag[0],"t5_Userinfo1",&Milstoninfo1)!=ITK_ok) PrintErrorStack();
		// printf("\n P4:Milstoninfo1 is : [%s] ", Milstoninfo1);fflush(stdout);

		// if (AOM_ask_value_string(MilstonCntrlObjectTag[0],"t5_Userinfo2",&Milstoninfo2)!=ITK_ok) PrintErrorStack();
		// printf("\n P4:Milstoninfo2 is : [%s] ", Milstoninfo2);fflush(stdout);

		// if((tc_strstr(Milstoninfo1,sProject)!=NULL)|| (tc_strstr(Milstoninfo2,sProject)!=NULL))
		// {
			// printf("\n P: It is MilestoneLive project: %s  ", sProject);fflush(stdout);
			// return 1;
		// }
		// else
		// {
			// printf("\n P: It is not MilestoneLive project: %s  ", sProject);fflush(stdout);
		// return 0;
		// }


		// return 0;
	// }
// }

int CheckMilestoneLive(char* sProject)
{
	int Milston_rsltCount    = 0;
	int Milston_n_entry    = 1;
	int MLPrjLive = 0;
	tag_t *MilstonCntrlObjectTag = NULLTAG;
	tag_t MilstonCntrlObj = NULLTAG;
	tag_t MilestoneqryTag = NULLTAG;
	char *Milston_qry_entry[1]  = {"SYSCD"};
	char **Milston_qry_values2 = (char **) MEM_alloc(10 * sizeof(char *));
	char* Milstoninfo1 = NULL;
	char* Milstoninfo2 = NULL;

	printf("\n CheckMilestoneLive--for project: [%s]", sProject);fflush(stdout);
	//GETTING mileston obj.
	if(QRY_find2("ControlObjects", &MilestoneqryTag));
	if (MilestoneqryTag)
	{
		printf("\n CheckMilestoneLive--P1:Found Query MilestoneqryTag  ");fflush(stdout);

		Milston_qry_values2[0] = "Milston";
		if(QRY_execute(MilestoneqryTag, Milston_n_entry, Milston_qry_entry, Milston_qry_values2, &Milston_rsltCount, &MilstonCntrlObjectTag));
	}
	else
	{
		printf("\n CheckMilestoneLive--P2:Not Found Query MilestoneqryTag  ");fflush(stdout);
	}

	printf("\n CheckMilestoneLive--P3:DR_rsltCount :%d:", Milston_rsltCount); fflush(stdout);
	if(Milston_rsltCount > 0)
	{
		for (MLPrjLive=0;MLPrjLive<Milston_rsltCount;MLPrjLive++ )
		{
			MilstonCntrlObj = MilstonCntrlObjectTag[MLPrjLive];
			if (AOM_ask_value_string(MilstonCntrlObj,"t5_Userinfo1",&Milstoninfo1)!=ITK_ok) PrintErrorStack();
			printf("\n CheckMilestoneLive--P4:Milstoninfo1: [%s]", Milstoninfo1);fflush(stdout);

			if (AOM_ask_value_string(MilstonCntrlObj,"t5_Userinfo2",&Milstoninfo2)!=ITK_ok) PrintErrorStack();
			printf("\n CheckMilestoneLive--P4:Milstoninfo2 is : [%s]", Milstoninfo2);fflush(stdout);

			if((tc_strstr(Milstoninfo1,sProject)!=NULL)|| (tc_strstr(Milstoninfo2,sProject)!=NULL))
			{
				printf("\n CheckMilestoneLive--P: It is MilestoneLive project: %s", sProject);fflush(stdout);
				return 1;
				break;
			}
			else
			{
				printf("\n CheckMilestoneLive--P: It is not MilestoneLive project: %s", sProject);fflush(stdout);
				return 0;
			}
		}
		return 0;
	}
	return 0;
}
// check milestone live project END
//start added on 29June2023 CR-FY24-0030
int CheckERCAccessLogin(tag_t Usr_tag)
{
	int     ac    = 0;
	int     Accessflag    = 0;
	int     AccessCount    = 0;

	char*	 AccessFound_name = NULL;
	tag_t	AccessFound_tg = NULLTAG;
	tag_t	*AccessFound = NULLTAG;

	tag_t	ERCGrpqryTag		= NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char   *qry_entry[1]  = {"SYSCD"};
	char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	int n_entry    = 1;
	int  rsltCount      =  0;
	char *ERCGrpinfo1 = NULL;
	char *ERCGrpinfo2 = NULL;

		if(QRY_find2("ControlObjects", &ERCGrpqryTag));
		if (ERCGrpqryTag)
		{
			printf("\n CheckERCAccessLogin:Found Query ControlObjects  ");fflush(stdout);
		}
		else
		{
			printf("\n CheckERCAccessLogin:Not Found Query ControlObjects  ");fflush(stdout);
		}

		qry_values2[0] = "CheckUserGrpRole";
		if(QRY_execute(ERCGrpqryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
		printf(" \n CheckERCAccessLogin:rsltCount[%d]", rsltCount); fflush(stdout);

	if(rsltCount > 0)
	{
		if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&ERCGrpinfo1)!=ITK_ok) PrintErrorStack();
		printf("\n CheckERCAccessLogin:ERCGrpinfo1: [%s] ", ERCGrpinfo1);fflush(stdout);

		//if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&ERCGrpinfo2)!=ITK_ok) PrintErrorStack();
		//printf("\n ERCGrpinfo2 is : [%s] ", ERCGrpinfo2);fflush(stdout);


		if (SA_find_groupmember_by_user(Usr_tag,&AccessCount,&AccessFound)!=ITK_ok) PrintErrorStack();
		printf("\n CheckERCAccessLogin:count of AccessCount: [%d]", AccessCount);fflush(stdout);
		for(ac=0;ac<AccessCount;ac++)
		{
			AccessFound_tg = AccessFound[ac];

			if (AOM_ask_value_string(AccessFound_tg,"object_name",&AccessFound_name)!=ITK_ok) PrintErrorStack();
			//printf("\n CheckERCAccessLogin:Actual Group Member AccessFound_name: [%s]", AccessFound_name);fflush(stdout);
			////if((tc_strstr(AccessFound_name,Supportinfo1)!=NULL)|| (tc_strstr(AccessFound_name,ERCGrpinfo2)!=NULL))
			////if(tc_strstr(AccessFound_name,Supportinfo1)!=NULL)
			if(tc_strstr(AccessFound_name, ERCGrpinfo1) != NULL)
			{
				Accessflag++;
				printf("\n CheckERCAccessLogin:AccessFound_name----: [%s][%d]", AccessFound_name,Accessflag);fflush(stdout);
				break;
			}
		}
		if(Accessflag >0)
		{
			printf("\n CheckERCAccessLogin:ERC access found. ");fflush(stdout);
			return 0;
		}
		else
		{
			printf("\n CheckERCAccessLogin:ERC access not found.  ");fflush(stdout);
			return 1;
		}
	}

	return 0;
}

//end added on 29June2023 CR-FY24-0030

// Validate DR-MileStone START
int tm_PreviousRev_Milestone_Validate(tag_t rev_tag, char* value)
{
	int     count1    = 0;
	int     iij    = 0;
	char*     rev_id = NULL;
	char*     rev_num = NULL;
	char*     rell_status = NULL;
	char*     ML_Staus = NULL;
	tag_t 	*rev_listt 	= NULL;
	tag_t 	Partrev 	= NULLTAG;
	tag_t 	ITEM_tag 	= NULLTAG;

	if(AOM_ask_value_tag(rev_tag,"items_tag",&ITEM_tag)!=ITK_ok) PrintErrorStack();

	if (ITEM_tag==NULLTAG)
	{
		printf("\n tm_PreviousRev_Milestone_Validate ITEM not found  ");fflush(stdout);
		return 0;
	}

	if(ITEM_list_all_revs(ITEM_tag, &count1, &rev_listt)!=ITK_ok) PrintErrorStack();
	if(count1 > 0)
	{
		iij=0;
		for(iij=count1-1;iij>=0;iij--)
		{
			printf("\n tm_PreviousRev_Milestone_Validate--Total rev rev_listt: %d.", count1);fflush(stdout);
			Partrev = rev_listt[iij];

			if(AOM_UIF_ask_value(Partrev,"item_id", &rev_num)!=ITK_ok) PrintErrorStack();
			if(AOM_UIF_ask_value(Partrev,"item_revision_id", &rev_id)!=ITK_ok) PrintErrorStack();
			if (AOM_UIF_ask_value(Partrev,"release_status_list", &rell_status)!=ITK_ok) PrintErrorStack();
			if (AOM_ask_value_string(Partrev,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok) PrintErrorStack();

			printf("\n tm_PreviousRev_Milestone_Validate--rev_id:%s and rell_status:%s", rev_id,rell_status);fflush(stdout);
			if(tc_strstr(rell_status, "ERC Released") !=NULL && tc_strcmp(value,ML_Staus)==0)
			{
				printf("\n tm_PreviousRev_Milestone_Validate--for %s %s  milestone %s ",rev_num,rev_id,ML_Staus);fflush(stdout);
				return 1;
			}
		}
	}
	return 0;
}
// int tm_Validate_DR_Milestone_OnPart(tag_t rev_tag)
// {
	// int flag=0;
	// char *PrtDR = NULL;
	// char *ML_Staus = NULL;
	// char *ObjProject = NULL;
	// char *desRev = NULL;
	// char *DRinfo4 = NULL;
	// int IsMilestoneLiveFlag=0;
	// int n_entry    = 1;
	// int  rsltCount      =  0;

	// tag_t   qryTag     = NULLTAG;
	// tag_t   *CntrlObjectTag      = NULLTAG;
	// char   *qry_entry[1]  = {"SYSCD"};
	// char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	// if(AOM_ask_value_string(rev_tag,"t5_ProjectCode",&ObjProject)!=ITK_ok) PrintErrorStack();
	// //if(AOM_ask_value_string(PartTag,"t5_ProjectCode",&PrtPrjct)!=ITK_ok) PrintErrorStack();

	// printf("\nProject stamped is : %s ",ObjProject);fflush(stdout);
	// IsMilestoneLiveFlag=0;
	// IsMilestoneLiveFlag = CheckMilestoneLive(ObjProject);
	// printf("\n P3:IsMilestoneLiveFlag: %d",IsMilestoneLiveFlag);fflush(stdout);
	// if (IsMilestoneLiveFlag >0)
	// {
		// printf("\n project is live check part level Milestone validations");fflush(stdout);
		// if(QRY_find2("ControlObjects", &qryTag));
		// if (qryTag)
		// {
			// printf("\n CREVali:Found Query ControlObjects  ");fflush(stdout);
		// }
		// else
		// {
			// printf("\n CREVali:Not Found Query ControlObjects  ");fflush(stdout);
		// }

		// qry_values2[0] = "CREVali";
		// if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
		// printf(" \n CREVali:rsltCount 44:%d:", rsltCount); fflush(stdout);
		// if(rsltCount > 0)
		// {
			// if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo4",&DRinfo4)!=ITK_ok) PrintErrorStack();

			// printf("\n CREVali:DRinfo4:%s",DRinfo4);fflush(stdout);
		// }
		// if(tc_strstr(DRinfo4,"AHCHK1")==NULL)
		// {
			// /*UNV0        corresponds to DR1
			// UNV1      corresponds to DR1
			// Pre-UPV0       corresponds to DR1
			// UNV2           corresponds to DR2
			// UPV0           corresponds to DR2
			// UNV3          corresponds to DR2
			// UPV1           corresponds to DR2
			// UPV2                corresponds to DR2
			// UPV3            corresponds to DR3*/

			// printf("\n here0 ");fflush(stdout);
			// if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
			// if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok) PrintErrorStack();
			// if(AOM_ask_value_string(rev_tag,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
			// printf("\n  PrtDR: [%s] ML_Staus:[%s] REV [%s]  ",PrtDR,ML_Staus,desRev);fflush(stdout);
			// if (tc_strcmp(ML_Staus,"")==0)
			// {

				// flag=1;
				// return flag;
				// /*EMH_clear_errors();
				// EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
				// return ITK_err;*/
			// }
			// if(tc_strstr(desRev,"NR")!=NULL)
			// //if (tc_strcmp(desRev,"NR")==0)
			// {
				// // Check the initial value from controm object for initial value
				// int     Milston_rsltCount    = 0;
				// int     Milston_n_entry    = 1;
				// tag_t     *MilstonCntrlObjectTag                = NULLTAG;
				// tag_t     MilestoneqryTag                              = NULLTAG;
				// char    *Milston_qry_entry[1]  = {"SYSCD"};
				// char    **Milston_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
				// char*     Milstoninfo4 = NULL;

				// printf("\n P: CheckMileston initial value for project ");fflush(stdout);
				// //GETTING mileston obj.
				// if(QRY_find2("ControlObjects", &MilestoneqryTag));
				// if (MilestoneqryTag)
				// {
					// printf("\n Query MilestoneqryTag  ");fflush(stdout);
				// }
				// else
				// {
					// printf("\n Not Found Query MilestoneqryTag  ");fflush(stdout);
				// }

				// Milston_qry_values2[0] = "Milston";
				// if(QRY_execute(MilestoneqryTag, Milston_n_entry, Milston_qry_entry, Milston_qry_values2, &Milston_rsltCount, &MilstonCntrlObjectTag));
				// printf(" \n P3:DR_rsltCount :%d:", Milston_rsltCount); fflush(stdout);
				// if(Milston_rsltCount > 0)
				// {
					// if (AOM_ask_value_string(MilstonCntrlObjectTag[0],"t5_Userinfo4",&Milstoninfo4)!=ITK_ok) PrintErrorStack();
					// printf("\n P4:Milstoninfo4 is : [%s] ", Milstoninfo4);fflush(stdout);

				// }

				// //
				// if(tc_strstr(Milstoninfo4,ML_Staus) !=NULL)
				// {
					// printf("\n Milestone ok update DR Value   "); fflush(stdout);
					// if(AOM_refresh(rev_tag,TRUE)!=ITK_ok) PrintErrorStack();

					// if(tc_strcmp(ML_Staus,"UNV0")==0 || tc_strcmp(ML_Staus,"Pre-UPV0")==0 || tc_strcmp(ML_Staus,"UNV1")==0)
					// {
						// //if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR1")!=ITK_ok) PrintErrorStack();
						// if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR1")!=ITK_ok) PrintErrorStack();
					// }
					// if(tc_strcmp(ML_Staus,"UNV2")==0 || tc_strcmp(ML_Staus,"UPV0")==0 || tc_strcmp(ML_Staus,"UNV3")==0 || tc_strcmp(ML_Staus,"UPV1")==0 || tc_strcmp(ML_Staus,"UPV2")==0)
					// {
						// //if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR2")!=ITK_ok) PrintErrorStack();
						// if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR2")!=ITK_ok) PrintErrorStack();
					// }
					// if(tc_strcmp(ML_Staus,"UPV3")==0)
					// {
						// //if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR3")!=ITK_ok) PrintErrorStack();
						// if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR3")!=ITK_ok) PrintErrorStack();
					// }
					// if(AOM_save_without_extensions(rev_tag)!=ITK_ok) PrintErrorStack();
					// if(AOM_refresh(rev_tag,FALSE)!=ITK_ok) PrintErrorStack();
					// if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
					// printf("\n Milestone is [%s] and  Part DR is updated to [%s]   ",ML_Staus,PrtDR);fflush(stdout);

				// }

				// else
				// {
					// //error since info4 value and milestone is not matching
					// /*EMH_clear_errors();
					// EMH_store_error_s1(EMH_severity_error,ITK_err," for NR revision Milestone Status should be as per Standards provided by PLM Team");
					// return ITK_err;*/
					// flag=5;
					// return flag;
				// }
			// }
			// else
			// {
					// printf("\n Milestone ok, update DR Value for other than NR   "); fflush(stdout);
					// //if(AOM_refresh(rev_tag,TRUE)!=ITK_ok) PrintErrorStack();
					// //if(AOM_refresh(rev_tag,TRUE)!=ITK_ok) PrintErrorStack();
					// if (AOM_lock(rev_tag)!=ITK_ok) PrintErrorStack();

					// if(tc_strcmp(ML_Staus,"UNV0")==0 || tc_strcmp(ML_Staus,"Pre-UPV0")==0 || tc_strcmp(ML_Staus,"UNV1")==0)
					// {
						// if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR1")!=ITK_ok) PrintErrorStack();
					// }
					// if(tc_strcmp(ML_Staus,"UNV2")==0 || tc_strcmp(ML_Staus,"UPV0")==0 || tc_strcmp(ML_Staus,"UNV3")==0 || tc_strcmp(ML_Staus,"UPV1")==0 || tc_strcmp(ML_Staus,"UPV2")==0)
					// {
						// if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR2")!=ITK_ok) PrintErrorStack();
					// }
					// if(tc_strcmp(ML_Staus,"UPV3")==0)
					// {
						// if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR3")!=ITK_ok) PrintErrorStack();
					// }
					// if(AOM_save_without_extensions(rev_tag)!=ITK_ok) PrintErrorStack();
					// if(AOM_unlock(rev_tag)!=ITK_ok) PrintErrorStack();
					// if(AOM_refresh(rev_tag,0)!=ITK_ok) PrintErrorStack();

					// if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
					// printf("\n for non NR Milestone is [%s] and  Part DR is updated to [%s]   ",ML_Staus,PrtDR);fflush(stdout);
					// flag=0;
					// return flag;


			// }
		// }
	// }
// }

int tm_Update_DR_AsPerMilestone_OnPart(tag_t rev_tag)
{
	int flag=0;
	char *PrtDR = NULL;
	char *ML_Staus = NULL;
	char *ObjProject = NULL;
	char *desRev = NULL;
	char *Revinfo2 = NULL;
	char *MLStatusinfo3 = NULL;
	char *MLStatusinfo4 = NULL;
	char *MLStatusinfo5 = NULL;
	char *PrjCodeinfo1 = NULL;
	int IsMilestoneLiveFlag=0;
	int n_entry    = 1;
	int  rsltCount      =  0;

	tag_t   qryTag     = NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char   *qry_entry[1]  = {"SYSCD"};
	char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	if(AOM_ask_value_string(rev_tag,"t5_ProjectCode",&ObjProject)!=ITK_ok) PrintErrorStack();
	//if(AOM_ask_value_string(PartTag,"t5_ProjectCode",&PrtPrjct)!=ITK_ok) PrintErrorStack();

	printf("\n tm_Update_DR_AsPerMilestone_OnPart:Project stamped: %s ",ObjProject);fflush(stdout);

	printf("--project is live check part level Milestone validations");fflush(stdout);
	if(QRY_find2("ControlObjects", &qryTag));
	if (qryTag)
	{
		printf("\n tm_Update_DR_AsPerMilestone_OnPart:PrtRevMilstonVal:Found Query ControlObjects  ");fflush(stdout);
	}
	else
	{
		printf("\n tm_Update_DR_AsPerMilestone_OnPart:PrtRevMilstonVal:Not Found Query ControlObjects  ");fflush(stdout);
	}

	qry_values2[0] = "PrtRevMilstonVal";

	if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
	printf(" \n tm_Update_DR_AsPerMilestone_OnPart:PrtRevMilstonVal:rsltCount 44:%d:", rsltCount); fflush(stdout);

	int PrtRevMilstonValFl=0;
	if(rsltCount > 0)
	{
		int MLstRevcnt=0;
		PrtRevMilstonValFl=0;
		tag_t CntrlObjectObj = NULLTAG;
		for (MLstRevcnt=0;MLstRevcnt<rsltCount;MLstRevcnt++ )
		{
			CntrlObjectObj = CntrlObjectTag[MLstRevcnt];
			if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo1",&PrjCodeinfo1)!=ITK_ok) PrintErrorStack();
			printf("\n tm_Update_DR_AsPerMilestone_OnPart:INFORMATIO1 for project code:%s:", PrjCodeinfo1); fflush(stdout);
			if(tc_strcmp(PrjCodeinfo1,ObjProject)==0)
			{
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo2",&Revinfo2)!=ITK_ok) PrintErrorStack();
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo3",&MLStatusinfo3)!=ITK_ok) PrintErrorStack();
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo4",&MLStatusinfo4)!=ITK_ok) PrintErrorStack();
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo5",&MLStatusinfo5)!=ITK_ok) PrintErrorStack();
				printf(" \n tm_Update_DR_AsPerMilestone_OnPart:INFORMATIO2 for revision:[%s]  MLStatusinfo3: [%s]  MLStatusinfo4: [%s] MLStatusinfo5: [%s]", Revinfo2, MLStatusinfo3,MLStatusinfo4,MLStatusinfo5); fflush(stdout);
				//printf(" \n tm_Update_DR_AsPerMilestone_OnPart:Starting milestone value "); fflush(stdout);
				PrtRevMilstonValFl=1;
				break;
			}
		}
	}
	if(PrtRevMilstonValFl>0)
	{
		printf("\n tm_Update_DR_AsPerMilestone_OnPart:for compare project code: [%s] MLStatusinfo3:[%s] Revinfo2 [%s] MLStatusinfo4: [%s] MLStatusinfo5:[%s]",PrjCodeinfo1,MLStatusinfo3,Revinfo2, MLStatusinfo4,MLStatusinfo5);fflush(stdout);
		//printf(" \n tm_Update_DR_AsPerMilestone_OnPart:Final Starting milestone value"); fflush(stdout);
		if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
		if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok) PrintErrorStack();
		if(AOM_ask_value_string(rev_tag,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
		printf("\n tm_Update_DR_AsPerMilestone_OnPart:PrtDR: [%s] ML_Staus:[%s] REV [%s]  ",PrtDR,ML_Staus,desRev);fflush(stdout);
		if(tc_strstr(desRev,Revinfo2)!=NULL)
		{
			//printf("\n tm_Update_DR_AsPerMilestone_OnPart:here compare ");fflush(stdout);

			if (tc_strcmp(ML_Staus,"")==0)
			{
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
				return 1;
			}
			else if(tc_strstr(MLStatusinfo3,ML_Staus)==NULL)
			{
				char *t5MlStRevErr=NULL;

				t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
				strcpy(t5MlStRevErr,"");
				strcpy(t5MlStRevErr,"For Project ");
				strcat(t5MlStRevErr,ObjProject);
				strcat(t5MlStRevErr," and NR revision UN milestone must be '");
				strcat(t5MlStRevErr,MLStatusinfo4);
				strcat(t5MlStRevErr," or below'");
				strcat(t5MlStRevErr," and UP milestone must be '");
				strcat(t5MlStRevErr,MLStatusinfo5);
				strcat(t5MlStRevErr," or below'.");
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
				return 1;
			}
			else
			{
				//printf("\n tm_Update_DR_AsPerMilestone_OnPart:Milestone ok update DR Value   "); fflush(stdout);
				if(AOM_refresh(rev_tag,TRUE)!=ITK_ok) PrintErrorStack();

				if(tc_strcmp(ML_Staus,"UNV0")==0 || tc_strcmp(ML_Staus,"Pre-UPV0")==0 || tc_strcmp(ML_Staus,"UNV1")==0)
				{
					if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR1")!=ITK_ok) PrintErrorStack();
					printf("\n tm_Update_DR_AsPerMilestone_OnPart:Milestone is [%s] and  Part DR is updated to DR1",ML_Staus);fflush(stdout);
				}
				if(tc_strcmp(ML_Staus,"UNV2")==0 || tc_strcmp(ML_Staus,"UPV0")==0 || tc_strcmp(ML_Staus,"UNV3")==0 || tc_strcmp(ML_Staus,"UPV1")==0 || tc_strcmp(ML_Staus,"UPV2")==0)
				{
					if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR2")!=ITK_ok) PrintErrorStack();
					printf("\n tm_Update_DR_AsPerMilestone_OnPart:Milestone is [%s] and  Part DR is updated to DR2",ML_Staus);fflush(stdout);
				}
				if(tc_strcmp(ML_Staus,"UPV3")==0)
				{
					if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR3")!=ITK_ok) PrintErrorStack();
					printf("\n tm_Update_DR_AsPerMilestone_OnPart:Milestone is [%s] and  Part DR is updated to DR3",ML_Staus);fflush(stdout);
				}
				if(AOM_save_without_extensions(rev_tag)!=ITK_ok) PrintErrorStack();
				if(AOM_refresh(rev_tag,FALSE)!=ITK_ok) PrintErrorStack();
				if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
				printf("\n tm_Update_DR_AsPerMilestone_OnPart:Milestone is [%s] and  Part DR is updated to [%s]",ML_Staus,PrtDR);fflush(stdout);
				return 0;
			}
		}
		else
		{
				printf("\n tm_Update_DR_AsPerMilestone_OnPart:Milestone ok, update DR Value for other than NR   "); fflush(stdout);
				//if(AOM_refresh(rev_tag,TRUE)!=ITK_ok) PrintErrorStack();
				//if(AOM_refresh(rev_tag,TRUE)!=ITK_ok) PrintErrorStack();
				if (AOM_lock(rev_tag)!=ITK_ok) PrintErrorStack();

				if(tc_strcmp(ML_Staus,"UNV0")==0 || tc_strcmp(ML_Staus,"Pre-UPV0")==0 || tc_strcmp(ML_Staus,"UNV1")==0)
				{
					if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR1")!=ITK_ok) PrintErrorStack();
				}
				if(tc_strcmp(ML_Staus,"UNV2")==0 || tc_strcmp(ML_Staus,"UPV0")==0 || tc_strcmp(ML_Staus,"UNV3")==0 || tc_strcmp(ML_Staus,"UPV1")==0 || tc_strcmp(ML_Staus,"UPV2")==0)
				{
					if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR2")!=ITK_ok) PrintErrorStack();
				}
				if(tc_strcmp(ML_Staus,"UPV3")==0)
				{
					if(AOM_UIF_set_value (rev_tag,"t5_PartStatus","DR3")!=ITK_ok) PrintErrorStack();
				}
				if(AOM_save_without_extensions(rev_tag)!=ITK_ok) PrintErrorStack();
				if(AOM_unlock(rev_tag)!=ITK_ok) PrintErrorStack();
				if(AOM_refresh(rev_tag,0)!=ITK_ok) PrintErrorStack();

				if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
				printf("\n tm_Update_DR_AsPerMilestone_OnPart:for non NR Milestone is [%s] and  Part DR is updated to [%s]   ",ML_Staus,PrtDR);fflush(stdout);

				return 0;
		}
	}
	return 0;
}
int tm_Update_DR_AsPerMilestone_OnPart_UpdLogic(tag_t rev_tag)
{
	char *PrtDR = NULL;
	char *ML_Staus = NULL;
	char *PrtType = NULL;
	char *ObjProject = NULL;
	char *desRevItenId = NULL;
	char *item_id = NULL;
	char *MlVerinfo1 = NULL;
	char *MlPrtTypeinfo2 = NULL;
	char *desRev = NULL;
	int n_entry    = 1;
	int  rsltCount      =  0;
	char *sPrt_Tp = NULL;
	sPrt_Tp=(char *)MEM_alloc(20);

	tag_t   qryTag     = NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char   *qry_entry[1]  = {"SYSCD"};
	char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	if(AOM_ask_value_string(rev_tag,"t5_ProjectCode",&ObjProject)!=ITK_ok) PrintErrorStack();
	//if(AOM_ask_value_string(PartTag,"t5_ProjectCode",&PrtPrjct)!=ITK_ok) PrintErrorStack();

		printf("\n tm_Update_DR_AsPerMilestone_OnPart_UpdLogic:Project stamped is : %s ",ObjProject);fflush(stdout);

		if(QRY_find2("ControlObjects", &qryTag));
		if (qryTag)
		{
			printf("\n PrtMilstonGen:Found Query ControlObjects  ");fflush(stdout);
		}
		else
		{
			printf("\n PrtMilstonGen:Not Found Query ControlObjects  ");fflush(stdout);
		}

		qry_values2[0] = "PrtMilstonGen";

		if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
		printf(" \n PrtMilstonGen:rsltCount 44:%d:", rsltCount); fflush(stdout);

		if(rsltCount > 0)
		{
			int MLstRevcnt=0;
			tag_t CntrlObjVer = NULLTAG;
			for (MLstRevcnt=0;MLstRevcnt<rsltCount;MLstRevcnt++ )
			{
				CntrlObjVer = CntrlObjectTag[MLstRevcnt];
				if (AOM_ask_value_string(CntrlObjVer,"t5_Userinfo1",&MlVerinfo1)!=ITK_ok) PrintErrorStack();
				printf(" \n INFORMATIO1 for mileston Generation:%s:", MlVerinfo1); fflush(stdout);

				if (AOM_ask_value_string(CntrlObjVer,"t5_Userinfo2",&MlPrtTypeinfo2)!=ITK_ok) PrintErrorStack();
				printf(" \n INFORMATIO2 for mileston Generation Part type:%s:", MlPrtTypeinfo2); fflush(stdout);

				if(tc_strcmp(MlVerinfo1,"Gen3")==0)
				{
					if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_PartType",&PrtType)!=ITK_ok) PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok) PrintErrorStack();
					if(AOM_ask_value_string(rev_tag,"item_id",&desRevItenId)!=ITK_ok) PrintErrorStack();
					if(AOM_ask_value_string(rev_tag,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
					printf("\n MilstonGen PrtDR: [%s] ML_Staus:[%s] PartNumber[%s] REV [%s] Part Type [%s]  ",PrtDR,ML_Staus,desRevItenId,desRev,PrtType);fflush(stdout);

					tc_strcpy(sPrt_Tp,"");
					tc_strcpy(sPrt_Tp,",");
					tc_strcat(sPrt_Tp,PrtType);
					tc_strcat(sPrt_Tp,",");
					printf("\n sPrt_Tp is:: %s",sPrt_Tp);fflush(stdout);

					if(tc_strstr(MlPrtTypeinfo2,sPrt_Tp) != NULL)
					{
						if ((tc_strcmp(PrtDR,"")==0)|| (tc_strcmp(PrtDR,"NA")==0))
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"It Is Milestone live project.DR Status cannot be NULL or NA.");
							return 1;
						}
						if (tc_strcmp(ML_Staus,"")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
							return 1;
						}
						else
						{
							printf("\n check Milestone Value for updating the DR status  "); fflush(stdout);
							printf("\n Milestone status  is: [%s] and DR status  is: [%s] ",ML_Staus,PrtDR);fflush(stdout);

							if(tc_strcmp(ML_Staus,"Pre-UNVO")==0 || tc_strcmp(ML_Staus,"Pre-UPVO")==0||tc_strcmp(ML_Staus,"Pre-UNV0")==0 || tc_strcmp(ML_Staus,"Pre-UPV0")==0|| tc_strcmp(ML_Staus,"UNV0")==0|| tc_strcmp(ML_Staus,"UNV1")==0|| tc_strcmp(ML_Staus,"UNV2")==0|| tc_strcmp(ML_Staus,"UPV0")==0|| tc_strcmp(ML_Staus,"UPV1")==0|| tc_strcmp(ML_Staus,"UPV2")==0|| tc_strcmp(ML_Staus,"UPV3")==0)
							{
								printf("\n Milestone ok update DR Value   "); fflush(stdout);

								if (AOM_lock(rev_tag)!=ITK_ok) PrintErrorStack();

								if(tc_strcmp(ML_Staus,"Pre-UNVO")==0 || tc_strcmp(ML_Staus,"Pre-UPVO")==0|| tc_strcmp(ML_Staus,"Pre-UNV0")==0|| tc_strcmp(ML_Staus,"Pre-UPV0")==0)
								{
									if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR0")!=ITK_ok) PrintErrorStack();
									printf("\n Milestone is [%s] and  Part DR is updated to DR0   ",ML_Staus);fflush(stdout);
								}
								if(tc_strcmp(ML_Staus,"UNV0")==0 || tc_strcmp(ML_Staus,"UNV1")==0 || tc_strcmp(ML_Staus,"UNV2")==0 || tc_strcmp(ML_Staus,"UNV3")==0 || tc_strcmp(ML_Staus,"UPV0")==0)
								{
									if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR1")!=ITK_ok) PrintErrorStack();
									printf("\n Milestone is [%s] and  Part DR is updated to DR1   ",ML_Staus);fflush(stdout);
								}
								if(tc_strcmp(ML_Staus,"UPV1")==0|| tc_strcmp(ML_Staus,"UPV2")==0|| tc_strcmp(ML_Staus,"UPV3")==0)
								{
									if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR2")!=ITK_ok) PrintErrorStack();
									printf("\n Milestone is [%s] and  Part DR is updated to DR2   ",ML_Staus);fflush(stdout);
								}

								if(AOM_save_without_extensions(rev_tag)!=ITK_ok) PrintErrorStack();
								if(AOM_refresh(rev_tag,FALSE)!=ITK_ok) PrintErrorStack();
								if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
								printf("\n Milestone is [%s] and  Part DR is updated to [%s]   ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								printf("\n DR Status not updated as Milestone status  is: [%s] ",ML_Staus);fflush(stdout);
							}

							return 0;
						}
					}
					else
					{
						printf("\nMileston bypass as per control Object [%s] Part Type[%s]",MlPrtTypeinfo2,sPrt_Tp);fflush(stdout);
					}

				}
				else if(tc_strcmp(MlVerinfo1,"Gen4")==0)
				{

					if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_PartType",&PrtType)!=ITK_ok) PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok) PrintErrorStack();
					if(AOM_ask_value_string(rev_tag,"item_id",&desRevItenId)!=ITK_ok) PrintErrorStack();
					if(AOM_ask_value_string(rev_tag,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
					printf("\n MilstonGen PrtDR: [%s] ML_Staus:[%s] PartNumber[%s] REV [%s] Part Type [%s]  ",PrtDR,ML_Staus,desRevItenId,desRev,PrtType);fflush(stdout);

					tc_strcpy(sPrt_Tp,"");
					tc_strcpy(sPrt_Tp,",");
					tc_strcat(sPrt_Tp,PrtType);
					tc_strcat(sPrt_Tp,",");
					printf("\n sPrt_Tp is:: %s",sPrt_Tp);fflush(stdout);

					if(tc_strstr(MlPrtTypeinfo2,sPrt_Tp) != NULL)
					{
						if ((tc_strcmp(PrtDR,"")==0)|| (tc_strcmp(PrtDR,"NA")==0))
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"It Is Milestone live project.DR Status cannot be NULL or NA.");
							return 1;
						}
						if (tc_strcmp(ML_Staus,"")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
							return 1;
						}
						else
						{
							printf("\n check Milestone Value for updating the DR status  "); fflush(stdout);
							printf("\n Milestone status  is: [%s] and DR status  is: [%s] ",ML_Staus,PrtDR);fflush(stdout);

							if(tc_strcmp(ML_Staus,"UPV0")==0 || tc_strcmp(ML_Staus,"UNV1")==0||tc_strcmp(ML_Staus,"UPV1")==0 || tc_strcmp(ML_Staus,"UNV2")==0|| tc_strcmp(ML_Staus,"UPV2")==0|| tc_strcmp(ML_Staus,"UNV3")==0|| tc_strcmp(ML_Staus,"UPV3")==0)
							{
								printf("\n Milestone ok update DR Value   "); fflush(stdout);

								if (AOM_lock(rev_tag)!=ITK_ok) PrintErrorStack();

								if(tc_strcmp(ML_Staus,"UPV0")==0 || tc_strcmp(ML_Staus,"UNV1")==0)
								{
									if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR0")!=ITK_ok) PrintErrorStack();
									printf("\n Milestone is [%s] and  Part DR is updated to DR0   ",ML_Staus);fflush(stdout);
								}
								if(tc_strcmp(ML_Staus,"UPV1")==0 || tc_strcmp(ML_Staus,"UNV2")==0 || tc_strcmp(ML_Staus,"UPV2")==0 || tc_strcmp(ML_Staus,"UNV3")==0)
								{
									if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR1")!=ITK_ok) PrintErrorStack();
									printf("\n Milestone is [%s] and  Part DR is updated to DR1   ",ML_Staus);fflush(stdout);
								}
								if(tc_strcmp(ML_Staus,"UPV3")==0)
								{
									if(AOM_set_value_string(rev_tag,"t5_PartStatus","DR2")!=ITK_ok) PrintErrorStack();
									printf("\n Milestone is [%s] and  Part DR is updated to DR2   ",ML_Staus);fflush(stdout);
								}

								if(AOM_save_without_extensions(rev_tag)!=ITK_ok) PrintErrorStack();
								if(AOM_refresh(rev_tag,FALSE)!=ITK_ok) PrintErrorStack();
								if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
								printf("\n Milestone is [%s] and  Part DR is updated to [%s]   ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								printf("\n DR Status not updated as Milestone status  is: [%s] ",ML_Staus);fflush(stdout);
							}

							return 0;
						}
					}
					else
					{
						printf("\nMileston bypass as per control Object [%s] Part Type[%s]",MlPrtTypeinfo2,sPrt_Tp);fflush(stdout);
					}

				}
				else
				{
					printf("\n Milestone version logic is off");fflush(stdout);
				}
			}
		}


	return 0;
}
//added on 14Apr2023
int tm_MilestoneValAsPerDRStatus_OnPartUpd(tag_t rev_tag)
{
	int flag=0;
	char *PrtDR = NULL;
	char *PrtType = NULL;
	char *ML_Staus = NULL;
	char *ObjProject = NULL;
	char *desRev = NULL;
	char *Revinfo2 = NULL;
	char *MLStatusinfo3 = NULL;
	char *MLStatusinfo4 = NULL;
	char *MLStatusinfo5 = NULL;
	char *MlVerinfo1 = NULL;
	char *MlPrtTypeinfo2 = NULL;
	int IsMilestoneLiveFlag=0;
	int n_entry    = 1;
	int  rsltCount      =  0;
	char *sPrt_Tp = NULL;
	sPrt_Tp=(char *)MEM_alloc(20);

	tag_t   qryTag     = NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char   *qry_entry[1]  = {"SYSCD"};
	char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	if(AOM_ask_value_string(rev_tag,"t5_ProjectCode",&ObjProject)!=ITK_ok) PrintErrorStack();
	//if(AOM_ask_value_string(PartTag,"t5_ProjectCode",&PrtPrjct)!=ITK_ok) PrintErrorStack();
	//printf("\n calling function tm_MilestoneValAsPerDRStatus_OnPartUpd");fflush(stdout);
	printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:Project stamped: %s ",ObjProject);fflush(stdout);
	IsMilestoneLiveFlag=0;
	IsMilestoneLiveFlag = CheckMilestoneLive(ObjProject);
	printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:project %s IsMilestoneLiveFlag: %d",ObjProject,IsMilestoneLiveFlag);fflush(stdout);
	if (IsMilestoneLiveFlag >0)
	{
		printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:project is live check part level Milestone validations");fflush(stdout);

		if(QRY_find2("ControlObjects", &qryTag));
		if (qryTag)
		{
			printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:PrtMilstonGen:Found Query ControlObjects  ");fflush(stdout);

			qry_values2[0] = "PrtMilstonGen";

			if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
		}
		else
		{
			printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:PrtMilstonGen:Not Found Query ControlObjects  ");fflush(stdout);
		}

		printf(" \n tm_MilestoneValAsPerDRStatus_OnPartUpd:PrtMilstonGen:rsltCount:%d:", rsltCount); fflush(stdout);

		if(rsltCount > 0)
		{
			int MLstRevcnt=0;
			tag_t CntrlObjVer = NULLTAG;
			for (MLstRevcnt=0;MLstRevcnt<rsltCount;MLstRevcnt++ )
			{
				CntrlObjVer = CntrlObjectTag[MLstRevcnt];
				if (AOM_ask_value_string(CntrlObjVer,"t5_Userinfo1",&MlVerinfo1)!=ITK_ok) PrintErrorStack();
				printf(" \n tm_MilestoneValAsPerDRStatus_OnPartUpd:INFORMATIO1 for mileston Version:%s:", MlVerinfo1); fflush(stdout);

				if (AOM_ask_value_string(CntrlObjVer,"t5_Userinfo2",&MlPrtTypeinfo2)!=ITK_ok) PrintErrorStack();
				printf(" \n tm_MilestoneValAsPerDRStatus_OnPartUpd:INFORMATIO2 for mileston Part type:%s:", MlPrtTypeinfo2); fflush(stdout);

				if(tc_strcmp(MlVerinfo1,"Gen3")==0)
				{

					if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_PartType",&PrtType)!=ITK_ok) PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok) PrintErrorStack();
					if(AOM_ask_value_string(rev_tag,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
					printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:PrtDR: [%s] ML_Staus:[%s] REV [%s] Part Type [%s]  ",PrtDR,ML_Staus,desRev,PrtType);fflush(stdout);

					tc_strcpy(sPrt_Tp,"");
					tc_strcpy(sPrt_Tp,",");
					tc_strcat(sPrt_Tp,PrtType);
					tc_strcat(sPrt_Tp,",");
					printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:sPrt_Tp is:: %s",sPrt_Tp);fflush(stdout);

					if(tc_strstr(MlPrtTypeinfo2,sPrt_Tp) != NULL)
					{
						if ((tc_strcmp(PrtDR,"")==0))
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"It Is Milestone live project.DR Status cannot bes NULL or NA.");
							return 1;
						}
						if (tc_strcmp(ML_Staus,"")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
							return 1;
						}
						else if ((tc_strcmp(PrtDR,"DR0")==0)|| (tc_strcmp(PrtDR,"AR0")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV1")==0)|| (tc_strcmp(ML_Staus,"UPV0")==0))
							{
								printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"For DR Status [");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,"] Part,Please select only 'UNV1,UPV0' milestone status.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}
						}
						else if ((tc_strcmp(PrtDR,"DR1")==0)|| (tc_strcmp(PrtDR,"AR1")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV2")==0)|| (tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV1")==0)|| (tc_strcmp(ML_Staus,"UPV2")==0))
							{
								printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"For DR Status [");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,"] Part,Please select only 'UNV2,UNV3,UPV1,UPV2' milestone status.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}
						}
						else if ((tc_strcmp(PrtDR,"DR2")==0)|| (tc_strcmp(PrtDR,"AR2")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV3")==0))
							{
								printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"For DR Status [");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,"] Part,Please select only 'UNV3,UPV3' milestone status.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else if ((tc_strcmp(PrtDR,"DR3")==0)|| (tc_strcmp(PrtDR,"AR3")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV3")==0))
							{
								printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"For DR Status [");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,"] Part,Please select only 'UNV3,UPV3' milestone status.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else if ((tc_strcmp(PrtDR,"DR4")==0)|| (tc_strcmp(PrtDR,"AR4")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV3")==0))
							{
								printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"For DR Status [");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,"] Part,Please select only 'UNV3,UPV3' milestone status.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}
						}
						else if ((tc_strcmp(PrtDR,"DR5")==0)|| (tc_strcmp(PrtDR,"AR5")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV3")==0))
							{
								printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"For DR Status [");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,"] Part,Please select only 'UNV3,UPV3' milestone status.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else if ((tc_strcmp(PrtDR,"DR3P")==0)|| (tc_strcmp(PrtDR,"AR3P")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV3")==0))
							{
								printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"For DR Status [");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,"] Part,Please select only 'UNV3,UPV3' milestone status.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}
						}
						else
						{
							printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:Part Type[%s],Part DR Status[%s],Part Milston Status[%s]",sPrt_Tp,PrtDR,ML_Staus);fflush(stdout);
						}
					}
					else
					{
						printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:Mileston bypass as per control Object [%s] Part Type[%s]",MlPrtTypeinfo2,sPrt_Tp);fflush(stdout);
					}
				}
				else
				{
					printf("\n tm_MilestoneValAsPerDRStatus_OnPartUpd:Milestone version logic is off");fflush(stdout);
				}
			}
		}
	}
	return 0;
}
//end on 14Apr2023
int tm_MilestoneValAsPerDRStatus_OnPart(tag_t rev_tag)
{
	int flag=0;
	char *PrtDR = NULL;
	char *PrtType = NULL;
	char *ML_Staus = NULL;
	char *ObjProject = NULL;
	char *desRev = NULL;
	char *Revinfo2 = NULL;
	char *MLStatusinfo3 = NULL;
	char *MLStatusinfo4 = NULL;
	char *MLStatusinfo5 = NULL;
	char *MlVerinfo1 = NULL;
	char *MlPrtTypeinfo2 = NULL;
	int IsMilestoneLiveFlag=0;
	int n_entry    = 1;
	int  rsltCount      =  0;
	char *sPrt_Tp = NULL;
	sPrt_Tp=(char *)MEM_alloc(20);

	tag_t   qryTag     = NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char   *qry_entry[1]  = {"SYSCD"};
	char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	if(AOM_ask_value_string(rev_tag,"t5_ProjectCode",&ObjProject)!=ITK_ok) PrintErrorStack();
	//if(AOM_ask_value_string(PartTag,"t5_ProjectCode",&PrtPrjct)!=ITK_ok) PrintErrorStack();

	printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Project stamped is : %s ",ObjProject);fflush(stdout);
	IsMilestoneLiveFlag=0;
	IsMilestoneLiveFlag = CheckMilestoneLive(ObjProject);
	printf("\n tm_MilestoneValAsPerDRStatus_OnPart:project %s IsMilestoneLiveFlag: %d",ObjProject,IsMilestoneLiveFlag);fflush(stdout);
	if (IsMilestoneLiveFlag >0)
	{
		printf("\n tm_MilestoneValAsPerDRStatus_OnPart:project is live check part level Milestone validations");fflush(stdout);
		if(QRY_find2("ControlObjects", &qryTag));
		if (qryTag)
		{
			printf("\n tm_MilestoneValAsPerDRStatus_OnPart:PrtRevMilstonVersion:Found Query ControlObjects  ");fflush(stdout);
		}
		else
		{
			printf("\n tm_MilestoneValAsPerDRStatus_OnPart:PrtRevMilstonVersion:Not Found Query ControlObjects  ");fflush(stdout);
		}

		qry_values2[0] = "PrtRevMilstonVersion";

		if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
		printf("\n tm_MilestoneValAsPerDRStatus_OnPart:PrtRevMilstonVersion:rsltCount 44:%d:", rsltCount); fflush(stdout);

		if(rsltCount > 0)
		{
			int MLstRevcnt=0;
			tag_t CntrlObjVer = NULLTAG;
			for (MLstRevcnt=0;MLstRevcnt<rsltCount;MLstRevcnt++ )
			{
				CntrlObjVer = CntrlObjectTag[MLstRevcnt];
				if (AOM_ask_value_string(CntrlObjVer,"t5_Userinfo1",&MlVerinfo1)!=ITK_ok) PrintErrorStack();
				printf(" \n tm_MilestoneValAsPerDRStatus_OnPart:INFORMATIO1 for mileston Version:%s:", MlVerinfo1); fflush(stdout);

				if (AOM_ask_value_string(CntrlObjVer,"t5_Userinfo2",&MlPrtTypeinfo2)!=ITK_ok) PrintErrorStack();
				printf(" \n tm_MilestoneValAsPerDRStatus_OnPart:INFORMATIO2 for mileston Part type:%s:", MlPrtTypeinfo2); fflush(stdout);

				if(tc_strcmp(MlVerinfo1,"VERSION8")==0)
				{
					if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_PartType",&PrtType)!=ITK_ok) PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok) PrintErrorStack();
					if(AOM_ask_value_string(rev_tag,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
					printf("\n tm_MilestoneValAsPerDRStatus_OnPart:PrtDR: [%s] ML_Staus:[%s] REV [%s] Part Type [%s]  ",PrtDR,ML_Staus,desRev,PrtType);fflush(stdout);

					tc_strcpy(sPrt_Tp,"");
					tc_strcpy(sPrt_Tp,",");
					tc_strcat(sPrt_Tp,PrtType);
					tc_strcat(sPrt_Tp,",");
					printf("\n tm_MilestoneValAsPerDRStatus_OnPart:sPrt_Tp is:: %s",sPrt_Tp);fflush(stdout);

					if(tc_strstr(MlPrtTypeinfo2,sPrt_Tp) != NULL)
					{
						if ((tc_strcmp(PrtDR,"")==0)|| (tc_strcmp(PrtDR,"NA")==0))
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"It Is Milestone live project.DR Status cannot bes NULL or NA.");
							return 1;
						}
						if (tc_strcmp(ML_Staus,"")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
							return 1;
						}
						else if ((tc_strcmp(PrtDR,"DR0")==0)|| (tc_strcmp(PrtDR,"AR0")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV0")==0)|| (tc_strcmp(ML_Staus,"Pre-UPV0")==0))
							{
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{

								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr," Milestone Status must be UNV0 or Pre-UPV0.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}
						}
						else if ((tc_strcmp(PrtDR,"DR1")==0)|| (tc_strcmp(PrtDR,"AR1")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV0")==0)|| (tc_strcmp(ML_Staus,"UNV1")==0)|| (tc_strcmp(ML_Staus,"Pre-UPV0")==0))
							{
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr," Milestone Status must be UNV0,UNV1 or Pre-UPV0.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}
						}
						else if ((tc_strcmp(PrtDR,"DR2")==0)|| (tc_strcmp(PrtDR,"AR2")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV2")==0)|| (tc_strcmp(ML_Staus,"UPV0")==0)|| (tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV1")==0)|| (tc_strcmp(ML_Staus,"UPV2")==0))
							{
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,", Milestone Status must be UPV0,UPV1,UPV2,UNV2 or UNV3.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}
						}
						else if ((tc_strcmp(PrtDR,"DR3")==0)|| (tc_strcmp(PrtDR,"AR3")==0))
						{
							if ((tc_strcmp(ML_Staus,"UPV3")==0)|| (tc_strcmp(ML_Staus,"UNV3")==0))
							{
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,", Milestone Status must be UNV3 or UPV3.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}
						}
						else if ((tc_strcmp(PrtDR,"DR3P")==0)|| (tc_strcmp(PrtDR,"AR3P")==0)|| (tc_strcmp(PrtDR,"DR4")==0)|| (tc_strcmp(PrtDR,"AR4")==0)|| (tc_strcmp(PrtDR,"DR5")==0)|| (tc_strcmp(PrtDR,"AR5")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV3")==0))
							{
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,", Milestone Status must be UNV3 or UPV3.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}
						}
					}
					else
					{
						printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Mileston bypass as per control Object [%s] Part Type[%s]",MlPrtTypeinfo2,sPrt_Tp);fflush(stdout);
					}
				}
				else if(tc_strcmp(MlVerinfo1,"VERSION9")==0)
				{
					if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_PartType",&PrtType)!=ITK_ok) PrintErrorStack();
					if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok) PrintErrorStack();
					if(AOM_ask_value_string(rev_tag,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
					printf("\n tm_MilestoneValAsPerDRStatus_OnPart:PrtDR: [%s] ML_Staus:[%s] REV [%s] Part Type [%s] ",PrtDR,ML_Staus,desRev,PrtType);fflush(stdout);

					tc_strcpy(sPrt_Tp,"");
					tc_strcpy(sPrt_Tp,",");
					tc_strcat(sPrt_Tp,PrtType);
					tc_strcat(sPrt_Tp,",");
					printf("\n tm_MilestoneValAsPerDRStatus_OnPart:sPrt_Tp is:: %s",sPrt_Tp);fflush(stdout);

					if(tc_strstr(MlPrtTypeinfo2,sPrt_Tp) != NULL)
					{
						if ((tc_strcmp(PrtDR,"")==0)|| (tc_strcmp(PrtDR,"NA")==0))
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"It Is Milestone live project.Please select valid DR Status of Part.");
							return 1;
						}
						if (tc_strcmp(ML_Staus,"")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
							return 1;
						}
						else if ((tc_strcmp(PrtDR,"DR0")==0)|| (tc_strcmp(PrtDR,"AR0")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV1")==0)|| (tc_strcmp(ML_Staus,"UPV0")==0))
							{
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr," Milestone Status must be UNV1 or UPV0.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}
						}
						else if ((tc_strcmp(PrtDR,"DR1")==0)|| (tc_strcmp(PrtDR,"AR1")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV1")==0)|| (tc_strcmp(ML_Staus,"UNV2")==0)|| (tc_strcmp(ML_Staus,"UPV0")==0)|| (tc_strcmp(ML_Staus,"UPV1")==0))
							{
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr," Milestone Status must be UNV1,UNV2,UPV0 or UPV1.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}

						}
						else if ((tc_strcmp(PrtDR,"DR2")==0)|| (tc_strcmp(PrtDR,"AR2")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV2")==0)|| (tc_strcmp(ML_Staus,"UPV3")==0))
							{
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,", Milestone Status must be UNV3,UPV2 or UPV3.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}
						}
						else if ((tc_strcmp(PrtDR,"DR3")==0)|| (tc_strcmp(PrtDR,"AR3")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV3")==0))
							{
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,", Milestone Status must be UNV3 or UPV3.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}
						}
						else if ((tc_strcmp(PrtDR,"DR3P")==0)|| (tc_strcmp(PrtDR,"AR3P")==0)|| (tc_strcmp(PrtDR,"DR4")==0)|| (tc_strcmp(PrtDR,"AR4")==0)|| (tc_strcmp(PrtDR,"DR5")==0)|| (tc_strcmp(PrtDR,"AR5")==0))
						{
							if ((tc_strcmp(ML_Staus,"UNV3")==0)|| (tc_strcmp(ML_Staus,"UPV3")==0))
							{
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Milestone value[%s] is correct corresponding to DR status[%] ",ML_Staus,PrtDR);fflush(stdout);
							}
							else
							{
								char *t5MlStRevErr=NULL;

								t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStRevErr,"");
								strcpy(t5MlStRevErr,"Part DR Status is ");
								strcat(t5MlStRevErr,PrtDR);
								strcat(t5MlStRevErr,", Milestone Status must be UNV3 or UPV3.");
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
								printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Error msg [%s]",t5MlStRevErr);fflush(stdout);
								return 1;
							}
						}
					}
					else
					{
						printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Mileston bypass as per control Object [%s] Part Type[%s]",MlPrtTypeinfo2,sPrt_Tp);fflush(stdout);
					}
				}
				else
				{
					printf("\n tm_MilestoneValAsPerDRStatus_OnPart:Milestone version logic is off");fflush(stdout);
				}
			}
		}
	}
	return 0;
}

// Validate DR-MileStone END
// Validate Parts's Revision-MileStone START
int tm_Validate_Rev_Milestone_OnPart(tag_t rev_tag)
{
	int flag=0;
	char *PrtDR = NULL;
	char *ML_Staus = NULL;
	char *ObjProject = NULL;
	char *desRev = NULL;
	char *Revinfo2 = NULL;
	char *MLStatusinfo3 = NULL;
	char *MLStatusinfo4 = NULL;
	char *MLStatusinfo5 = NULL;
	char *PrjCodeinfo1 = NULL;
	int IsMilestoneLiveFlag=0;
	int n_entry    = 1;
	int  rsltCount      =  0;

	tag_t   qryTag     = NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char   *qry_entry[1]  = {"SYSCD"};
	char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	if(AOM_ask_value_string(rev_tag,"t5_ProjectCode",&ObjProject)!=ITK_ok) PrintErrorStack();
	//if(AOM_ask_value_string(PartTag,"t5_ProjectCode",&PrtPrjct)!=ITK_ok) PrintErrorStack();

	printf("\nProject stamped is : %s ",ObjProject);fflush(stdout);
	IsMilestoneLiveFlag=0;
	IsMilestoneLiveFlag = CheckMilestoneLive(ObjProject);
	printf("\n project %s IsMilestoneLiveFlag: %d",ObjProject,IsMilestoneLiveFlag);fflush(stdout);
	if (IsMilestoneLiveFlag >0)
	{
		printf("\n project is live check part level Milestone validations");fflush(stdout);
		if(QRY_find2("ControlObjects", &qryTag));
		if (qryTag)
		{
			printf("\n PrtRevMilstonVal:Found Query ControlObjects  ");fflush(stdout);
		}
		else
		{
			printf("\n PrtRevMilstonVal:Not Found Query ControlObjects  ");fflush(stdout);
		}

		qry_values2[0] = "PrtRevMilstonVal";

		if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
		printf(" \n PrtRevMilstonVal:rsltCount 44:%d:", rsltCount); fflush(stdout);

		int PrtRevMilstonValFl=0;
		if(rsltCount > 0)
		{
			int MLstRevcnt=0;
			PrtRevMilstonValFl=0;
			tag_t CntrlObjectObj = NULLTAG;
			for (MLstRevcnt=0;MLstRevcnt<rsltCount;MLstRevcnt++ )
			{
				CntrlObjectObj = CntrlObjectTag[MLstRevcnt];
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo1",&PrjCodeinfo1)!=ITK_ok) PrintErrorStack();
				printf(" \n INFORMATIO1 for project code: 44:%s:", PrjCodeinfo1); fflush(stdout);
				if(tc_strcmp(PrjCodeinfo1,ObjProject)==0)
				{
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo2",&Revinfo2)!=ITK_ok) PrintErrorStack();
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo3",&MLStatusinfo3)!=ITK_ok) PrintErrorStack();
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo4",&MLStatusinfo4)!=ITK_ok) PrintErrorStack();
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo5",&MLStatusinfo5)!=ITK_ok) PrintErrorStack();
				printf(" \n INFORMATIO2 for revision:%s:", Revinfo2); fflush(stdout);
				printf(" \n INFORMATIO3 for MLStatusinfo3: 44:%s:", MLStatusinfo3); fflush(stdout);
				printf(" \n Starting milestone value MLStatusinfo4 %s MLStatusinfo5:%5:", MLStatusinfo4,MLStatusinfo5); fflush(stdout);
				PrtRevMilstonValFl=1;
				break;
				}
			}
		}
		if(PrtRevMilstonValFl>0)
		{
			printf("\n for compare project code: [%s] MLStatusinfo3:[%s] Revinfo2 [%s]  ",PrjCodeinfo1,MLStatusinfo3,Revinfo2);fflush(stdout);
			printf(" \n Final Starting milestone value MLStatusinfo4 %s MLStatusinfo5:%5:", MLStatusinfo4,MLStatusinfo5); fflush(stdout);
			if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
			if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&ML_Staus)!=ITK_ok) PrintErrorStack();
			if(AOM_ask_value_string(rev_tag,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
			printf("\n  PrtDR: [%s] ML_Staus:[%s] REV [%s]  ",PrtDR,ML_Staus,desRev);fflush(stdout);
			if(tc_strstr(desRev,Revinfo2)!=NULL)
			{

				printf("\n here compare ");fflush(stdout);

				if (tc_strcmp(ML_Staus,"")==0)
				{
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
					return 1;
				}
				else if(tc_strstr(MLStatusinfo3,ML_Staus)==NULL)
				{
					char *t5MlStRevErr=NULL;

					t5MlStRevErr = (char *) MEM_alloc( 1000 * sizeof(char) );
					strcpy(t5MlStRevErr,"");
					strcpy(t5MlStRevErr,"For Project ");
					strcat(t5MlStRevErr,ObjProject);
					strcat(t5MlStRevErr," and NR revision UN milestone must be '");
					strcat(t5MlStRevErr,MLStatusinfo4);
					strcat(t5MlStRevErr," or below'");
					strcat(t5MlStRevErr," and UP milestone must be '");
					strcat(t5MlStRevErr,MLStatusinfo5);
					strcat(t5MlStRevErr," or below'.");
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStRevErr);
					return 1;
				}
				else
				{
					printf("\n bye ");fflush(stdout);
				}
			}
	    }
	}
	return 0;
}
// Validate Parts's Revision-MileStone END

int tm_check_MilesStoneStatusSame_OnPart(tag_t rev_tag)
{
	char *rev_tagItemID = NULL;
	char *Prevrev_tagItemID = NULL;
	char *PreVrevMLStatus = NULL;
	char *PrtMLStatus = NULL;
	char *PrevDgMLInitials = NULL;
	char *DgMLInitials = NULL;
	char *Prevrev_id = NULL;
	char *rev_tagvrev_id = NULL;
	tag_t		Prevrev_tag			= NULLTAG;
	tag_t		*rev_list_set		= NULLTAG;
	int			rev_cnt				= 0;
	int			iij				= 0;

	//printf("\n in function tm_check_MilesStoneStatusSame_OnPart");fflush(stdout);

	if( AOM_ask_value_string(rev_tag,"item_id",&rev_tagItemID)!=ITK_ok) PrintErrorStack();
	printf("\n tm_check_MilesStoneStatusSame_OnPart:current Item Id %s ",rev_tagItemID);fflush(stdout);

	if(AOM_UIF_ask_value(rev_tag,"item_revision_id", &rev_tagvrev_id)!=ITK_ok) PrintErrorStack();
	printf("\n tm_check_MilesStoneStatusSame_OnPart:current revision Item Id %s ",rev_tagvrev_id);fflush(stdout);

	if (AOM_ask_value_string(rev_tag,"t5_DesignMilestoneStatus",&PrtMLStatus)!=ITK_ok) PrintErrorStack();
	printf("\n tm_check_MilesStoneStatusSame_OnPart:current Part ML Status [%s] ",PrtMLStatus);fflush(stdout);

	if (tc_strcmp(PrtMLStatus,"")==0)
	{
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
		return 1;
	}
	else
	{
		if (tc_strcmp(PrtMLStatus,"Pre-UPV0")==0)
		{
			printf("\n tm_check_MilesStoneStatusSame_OnPart:its Pre-UPV0 %s ",PrtMLStatus);fflush(stdout);
			DgMLInitials=subString(PrtMLStatus, 4, 2);
		}
		else
		{
			DgMLInitials=subString(PrtMLStatus, 0, 2);
		}
		printf("\n tm_check_MilesStoneStatusSame_OnPart:Current Part intials of Design MilesStone %s ",DgMLInitials);fflush(stdout);

		ITK_CALL(ITEM_find_item(rev_tagItemID, &Prevrev_tag ));
		ITK_CALL(ITEM_list_all_revs(Prevrev_tag,&rev_cnt,&rev_list_set));

		printf("\n tm_check_MilesStoneStatusSame_OnPart:Total rev rev_listt: %d.", rev_cnt);fflush(stdout);

		if(rev_cnt != 0)
		{
			for(iij=rev_cnt-1;iij>=0;iij--)
			{
				if( AOM_ask_value_string(rev_list_set[iij],"item_id",&Prevrev_tagItemID)!=ITK_ok) PrintErrorStack();
				printf("\n tm_check_MilesStoneStatusSame_OnPart:Previous revision Item Id %s ",Prevrev_tagItemID);fflush(stdout);

				if(AOM_UIF_ask_value(rev_list_set[iij],"item_revision_id", &Prevrev_id)!=ITK_ok) PrintErrorStack();
				printf("\n tm_check_MilesStoneStatusSame_OnPart:Previous revision Item Id %s ",Prevrev_id);fflush(stdout);

					if (tc_strcmp(rev_tagvrev_id,Prevrev_id)==0)
					{
						printf("\n tm_check_MilesStoneStatusSame_OnPart:Same part Currect rev Item ID %s -- Perv Item ID %s",rev_tagItemID,Prevrev_tagItemID);fflush(stdout);
						printf("\n tm_check_MilesStoneStatusSame_OnPart:Same part Currect rev Item RevID %s -- Perv Item RevID %s",rev_tagvrev_id,Prevrev_id);fflush(stdout);
						continue;
					}
					else
					{
						//printf("\n Just previsous part");fflush(stdout);
						printf("\n tm_check_MilesStoneStatusSame_OnPart:Currect rev Item ID %s -- Perv Item ID %s",rev_tagItemID,Prevrev_tagItemID);fflush(stdout);
						printf("\n tm_check_MilesStoneStatusSame_OnPart:Currect rev Item RevID %s -- Perv Item RevID %s",rev_tagvrev_id,Prevrev_id);fflush(stdout);

						if (AOM_ask_value_string(rev_list_set[iij],"t5_DesignMilestoneStatus",&PreVrevMLStatus)!=ITK_ok) PrintErrorStack();
						printf("\n tm_check_MilesStoneStatusSame_OnPart:Part ML Status [%s] ",PreVrevMLStatus);fflush(stdout);

						if (tc_strcmp(PreVrevMLStatus,"")!=0)
						{
							if (tc_strcmp(PreVrevMLStatus,"Pre-UPV0")==0)
							{
								PrevDgMLInitials=subString(PreVrevMLStatus, 4, 2);
							}
							else
							{
								PrevDgMLInitials=subString(PreVrevMLStatus, 0, 2);
							}

							printf("\n tm_check_MilesStoneStatusSame_OnPart:intials of Design MilesStone Previous %s ",PrevDgMLInitials);fflush(stdout);

							if (tc_strcmp(DgMLInitials,PrevDgMLInitials)!=0)
							{
								printf("\n tm_check_MilesStoneStatusSame_OnPart:intials of Design MilesStone %s ",DgMLInitials);fflush(stdout);
								char *t5MlStIntialErr=NULL;

								t5MlStIntialErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStIntialErr,"");
								strcpy(t5MlStIntialErr,"Please select Design Milestone value starting with ");
								strcat(t5MlStIntialErr,PrevDgMLInitials);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStIntialErr);
								return 1;
							}
						}
						else
						{
							//printf("\n Previous revision part miles Stone status is blank");fflush(stdout);
							printf("\n tm_check_MilesStoneStatusSame_OnPart:Part ML Status [%s] ",PreVrevMLStatus);fflush(stdout);
						}
					}
				break;
			}
		}
	}

	return 0;
}

logical IsNewpartRequestAvail(char   *NewModuleNumber)
{
	logical IsNewPrtReqfg = false;
	tag_t	*NewPartReqObj		= NULLTAG;
	tag_t	*ControlObjs		= NULLTAG;
	tag_t	Controlquery		= NULLTAG;
	tag_t	NPRquery			= NULLTAG;

	char   *TempNewModuleNumber = NULL;

	int	n_nprfound		= 0;
	int	n_cntrlfound	= 0;


	char
	//*qname[2] = {"Tml Part Number","New Part Request"},
	*qname[1] = {"Tml Part Number"},
	*qvalue[1]	= {"*"};


	char
	*ctrl_qry_entries[2] = {"SYSCD","Information-1"},
	*ctrl_qry_values[2]	= {"*","*"};


	printf("\n IsNewpartRequestAvail::NewModuleNumber =[%s]",NewModuleNumber);fflush(stdout);
	TempNewModuleNumber = (char *) MEM_alloc( 50 * sizeof(char));
	tc_strcpy(TempNewModuleNumber,"*");
	tc_strcat(TempNewModuleNumber,NewModuleNumber);
	tc_strcat(TempNewModuleNumber,"*");
	printf("\n IsNewpartRequestAvail::TempNewModuleNumber =[%s]",TempNewModuleNumber);fflush(stdout);
	//qvalue[0]	= NewModuleNumber;
	qvalue[0]	= TempNewModuleNumber;
	//qvalue[1]	= "New Part Request";
	QRY_find2("tm_NewPartRequest", &NPRquery);
	QRY_execute(NPRquery, 1, qname, qvalue, &n_nprfound, &NewPartReqObj);
	printf("\n IsNewpartRequestAvail::n_nprfound =[%d]",n_nprfound);fflush(stdout);

	ctrl_qry_values[0]	= "NewPartReqForSubModule";
	ctrl_qry_values[1]	= "Y";
	QRY_find2("ControlObjects", &Controlquery);
	QRY_execute(Controlquery, 2, ctrl_qry_entries, ctrl_qry_values, &n_cntrlfound, &ControlObjs);
	printf("\n IsNewpartRequestAvail::n_cntrlfound =[%d]",n_cntrlfound);fflush(stdout);

	if(n_nprfound > 0 && n_cntrlfound > 0)
	{
		printf("\n IsNewpartRequestAvail::NewModuleNumber =[%s]",NewModuleNumber);fflush(stdout);
		IsNewPrtReqfg = true;
	}
	if(n_nprfound > 0 && n_cntrlfound ==0)
	{
		printf("\n IsNewpartRequestAvail::NewModuleNumber =[%s]",NewModuleNumber);fflush(stdout);
		IsNewPrtReqfg = true;
	}
	if(n_nprfound ==0 && n_cntrlfound ==0)
	{
		printf("\n IsNewpartRequestAvail::NewModuleNumber =[%s]",NewModuleNumber);fflush(stdout);
		IsNewPrtReqfg = true;
	}
	if(n_nprfound ==0 && n_cntrlfound >0)
	{
		printf("\n IsNewpartRequestAvail::NewModuleNumber =[%s]",NewModuleNumber);fflush(stdout);
		IsNewPrtReqfg = false;
	}
	return IsNewPrtReqfg;
}

static int FunToQuery_ModuleAddress(char *ModuleAddress)
{
	char
        *ctrl_qry_entries[2] = {"SYSCD","SUBSYSCD"},
        *ctrl_qry_values[2]	= {"*","*"};

	int ISMODULE_FOUND = 0;
	int n_found = 0;

	tag_t	query		= NULLTAG;
	tag_t	*q_item		= NULLTAG;

	char *modinfo04Str	= NULL;
	char *modinfo05Str	= NULL;
	char *modinfo06Str	= NULL;
	char *modinfo07Str	= NULL;
	char *modinfo08Str	= NULL;
	char *modinfo09Str	= NULL;
	char *modinfo010Str	= NULL;

	int retcode = ITK_ok;

	printf("\n FunToQuery_ModuleAddress:ModuleAddress===%s",ModuleAddress);fflush(stdout);
	ctrl_qry_values[0]	= "ModAddForIM";
	ctrl_qry_values[1]	= "ModAddForIM";
	QRY_find2("Control Objects...", &query);
	if(query!=NULLTAG)
	{
		QRY_execute(query, 2, ctrl_qry_entries, ctrl_qry_values, &n_found, &q_item);
		printf("\n FunToQuery_ModuleAddress:n_found===%d",n_found);fflush(stdout);
		if(n_found>0)
		{
			AOM_ask_value_string(q_item[0],"t5_Userinfo4",&modinfo04Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo5",&modinfo05Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo6",&modinfo06Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo7",&modinfo07Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo8",&modinfo08Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo9",&modinfo09Str);
			AOM_ask_value_string(q_item[0],"t5_userinfo10",&modinfo010Str);

			if(tc_strstr(ModuleAddress,modinfo04Str)!=NULL
				|| tc_strstr(ModuleAddress,modinfo05Str)!=NULL
				|| tc_strstr(ModuleAddress,modinfo06Str)!=NULL
				|| tc_strstr(ModuleAddress,modinfo07Str)!=NULL
				|| tc_strstr(ModuleAddress,modinfo08Str)!=NULL
				|| tc_strstr(ModuleAddress,modinfo09Str)!=NULL
				|| tc_strstr(ModuleAddress,modinfo010Str)!=NULL)
			{
				ISMODULE_FOUND = 1;
			}
		}
	}
	printf("\n FunToQuery_ModuleAddress:ISMODULE_FOUND===%d",ISMODULE_FOUND);fflush(stdout);

	return ISMODULE_FOUND;
}

//function for setting Bom Type on Vehicle
void BOMTypeValidateStampFun (char *VehicleId,tag_t Vehicle_BT,tag_t ChildTagLatestRevt_BT)
{
	int rulefound	=	0;
	int n_lines_BT = 0;
	int kBT = 0;
	int PartTypeM= 0;
	int PartTypeT = 0;
	char	**rulename				=	NULL;
	char	**rulevalue				=	 NULL;
	char *Item_ID_str_Use_BT = NULL;
	char *Item_Revision_str_Use_BT = NULL;
	char *PartType_str_Use_BT = NULL;

	//char *Item_ID_str_BT = NULL;
	//char *Item_Revision_str_BT = NULL;



	tag_t	*closurerule		=	NULLTAG;
	tag_t	close_tag;
	tag_t window_BT  =NULLTAG;
	tag_t rule_BT =NULLTAG;
	tag_t top_line_BT  =NULLTAG;
	tag_t  *children_BT;
	//char *cv_PartType_str_Uses_BT		=	NULL;
	//char *cv_PartType_str_BT		=	NULL;
	char *c_BomTyp		=	NULL;
	char *child_type = NULL;


	if(AOM_ask_value_string(Vehicle_BT,"t5_Part_Info",&c_BomTyp)!=ITK_ok) PrintErrorStack();
	printf("\n BOMTypeValidateStampFun-The existing Bom Type for Vehicle design revision is [%s]",c_BomTyp);fflush(stdout);
	//some attributes are to be found again

	//if(tc_strlen(c_BomTyp) == 0)
	//{
		printf("\n BOMTypeValidateStampFun-The design revision [%s] must be  ERC Review", VehicleId);

		if(PIE_find_closure_rules2( "BOMViewClosureRuleERC",PIE_TEAMCENTER, &rulefound, &closurerule )!=ITK_ok) PrintErrorStack();
		if (rulefound > 0)
		{
			close_tag = closurerule[0];
			printf ("\n BOMTypeValidateStampFun--closure rule found while Check-in ");fflush(stdout);
		}

		if(ChildTagLatestRevt_BT)
		{
			if(AOM_ask_value_string(ChildTagLatestRevt_BT,"t5_PartType",&child_type)!=ITK_ok) PrintErrorStack();
			printf("\n\t ChildPartType => %s ",child_type);fflush(stdout);

			if (tc_strcmp(child_type,"M")==0)
			{
				PartTypeM=PartTypeM+1;
			}
			else if (tc_strcmp(child_type,"T")==0)
			{
				PartTypeT=PartTypeT+1;
			}
			else
			{
				PartTypeM=PartTypeM+1;
			}
		}

		if (BOM_create_window (&window_BT)!=ITK_ok) PrintErrorStack();
		if(CFM_find( "Latest Working", &rule_BT )!=ITK_ok) PrintErrorStack();
		if(BOM_set_window_config_rule( window_BT, rule_BT )!=ITK_ok) PrintErrorStack();
		if(BOM_window_set_closure_rule( window_BT,close_tag, 0, rulename,rulevalue )!=ITK_ok) PrintErrorStack(); //Applying closure rule
		if(BOM_set_window_pack_all (window_BT, true)!=ITK_ok) PrintErrorStack();
		if(BOM_set_window_top_line (window_BT, NULLTAG,Vehicle_BT,NULLTAG,&top_line_BT)!=ITK_ok) PrintErrorStack();
		if(BOM_window_show_suppressed ( window_BT )!=ITK_ok) PrintErrorStack();
		if(BOM_line_ask_child_lines(top_line_BT, &n_lines_BT, &children_BT)!=ITK_ok) PrintErrorStack();
		printf("\n BOMTypeValidateStampFun-total children_BT are :[%d] ",n_lines_BT);fflush(stdout);
		if(n_lines_BT > 0)
		{
		for (kBT = 0; kBT < n_lines_BT; kBT++)
		{
			ITK_CALL(AOM_ask_value_string(children_BT[kBT],"bl_item_item_id",&Item_ID_str_Use_BT));
			printf("\n  BOMTypeValidateStampFun-Item_ID_str_Use_BT =%s\n",Item_ID_str_Use_BT);fflush(stdout);

			ITK_CALL(AOM_ask_value_string(children_BT[kBT],"bl_rev_item_revision_id",&Item_Revision_str_Use_BT));
			printf("\n BOMTypeValidateStampFun--Item_Revision_str_Use_BT =%s",Item_Revision_str_Use_BT);fflush(stdout);

			//ITK_CALL(AOM_ask_value_string(children_BT[kBT],"bl_Design_t5_RevPartType",&PartType_str_Use_BT));  //bl_Design Revision_t5_PartType
			ITK_CALL(AOM_ask_value_string(children_BT[kBT],"bl_Design Revision_t5_PartType",&PartType_str_Use_BT));
			printf("\n BOMTypeValidateStampFun--PartType_str_Use_BT =%s",PartType_str_Use_BT);fflush(stdout);


			if (tc_strcmp(PartType_str_Use_BT,"M")==0)
			{
				PartTypeM=PartTypeM+1;
			}
			else if (tc_strcmp(PartType_str_Use_BT,"T")==0)
			{
				PartTypeT=PartTypeT+1;
			}
			else
			{
					PartTypeM=PartTypeM+1;
			}
		}
		printf("\n BOMTypeValidateStampFun--PartTypeM=%d and PartTypeT=%d ",PartTypeM,PartTypeT);fflush(stdout);
		printf("\n BOMTypeValidateStampFun--Stamping Bom type for vehicle started");fflush(stdout);
		if((PartTypeT==0) && (PartTypeM!=0))
		{
			printf("\n BOMTypeValidateStampFun--Updating Bom type MODULAR BOM");fflush(stdout);
			ITK_CALL(AOM_lock(Vehicle_BT));
			ITK_CALL(AOM_set_value_string(Vehicle_BT,"t5_Part_Info","MODULAR BOM"));
			ITK_CALL( AOM_save_without_extensions(Vehicle_BT));
			ITK_CALL(AOM_unlock(Vehicle_BT));


		}
		else if ((PartTypeM==0) &&(PartTypeT!=0) )
		{
			printf("\n BOMTypeValidateStampFun--Updating Bom type TPL BOM");fflush(stdout);
			ITK_CALL(AOM_lock(Vehicle_BT));
			ITK_CALL(AOM_set_value_string(Vehicle_BT,"t5_Part_Info","TPL BOM"));
			ITK_CALL( AOM_save_without_extensions(Vehicle_BT));
			ITK_CALL(AOM_unlock(Vehicle_BT));

		}
		else
		{
			printf("\n BOMTypeValidateStampFun--Updating Bom type HYBRID BOM");fflush(stdout);
			ITK_CALL(AOM_lock(Vehicle_BT));
			ITK_CALL(AOM_set_value_string(Vehicle_BT,"t5_Part_Info","HYBRID BOM"));
			ITK_CALL( AOM_save_without_extensions(Vehicle_BT));
			ITK_CALL(AOM_unlock(Vehicle_BT));
		}
		}
		else
		{
			printf(" Bom type is NULL and no uses parts in Vehicle");fflush(stdout);
		}
	//}
	/*
	else
	{
		printf("\n BOMTypeValidateStampFun--As the bom type is already there no need to expand uses parts.");fflush(stdout);

		ITK_CALL(AOM_ask_value_string(ChildTagLatestRevt_BT,"current_id",&Item_ID_str_BT));
		printf("\n  BOMTypeValidateStampFun-Item_ID_str_BT =%s\n",Item_ID_str_BT);fflush(stdout);

		ITK_CALL(AOM_ask_value_string(ChildTagLatestRevt_BT,"item_revision_id",&Item_Revision_str_BT));
		printf("\n BOMTypeValidateStampFun--Item_Revision_str_BT =%s",Item_Revision_str_BT);fflush(stdout);

		//if( AOM_ask_value_string(ChildTagLatestRevt_BT,"bl_Design_t5_RevPartType",&cv_PartType_str_Uses_BT));
		//printf("\n BOMTypeValidateStampFun--cv_PartType_str_Uses_BT of new added part  =[%s]",cv_PartType_str_Uses_BT);fflush(stdout);
		ITK_CALL( AOM_ask_value_string(ChildTagLatestRevt_BT,"t5_PartType",&cv_PartType_str_BT));
		printf("\n BOMTypeValidateStampFun--cv_PartType_str_BT of new added part  =[%s]",cv_PartType_str_BT);fflush(stdout);

		if(strcmp(c_BomTyp,"MODULAR BOM")==0)
		{
			printf("\n BOMTypeValidateStampFun--original is MODULAR BOM");fflush(stdout);
			if(strcmp(cv_PartType_str_BT,"M")==0)
			{
				printf("\n BOMTypeValidateStampFun--New Bom type is already  MODULAR BOM");fflush(stdout);
			}
			else if(strcmp(cv_PartType_str_BT,"T")==0)
			{
				printf("\n BOMTypeValidateStampFun--Updating Bom type as HYBRID BOM");fflush(stdout);
				ITK_CALL(AOM_lock(Vehicle_BT));
				ITK_CALL(AOM_set_value_string(Vehicle_BT,"t5_Part_Info","HYBRID BOM"));
				ITK_CALL( AOM_save_without_extensions(Vehicle_BT));
				ITK_CALL(AOM_unlock(Vehicle_BT));
			}
		}
		else if(strcmp(c_BomTyp,"TPL BOM")==0)
		{
			printf("\n BOMTypeValidateStampFun--original is TPL BOM");fflush(stdout);
			if(strcmp(cv_PartType_str_BT,"T")==0)
			{
				printf("\n BOMTypeValidateStampFun--New Bom type is already  TPL BOM");fflush(stdout);
			}
			else if(strcmp(cv_PartType_str_BT,"M")==0)
			{
				printf("\n BOMTypeValidateStampFun--Updating Bom type as HYBRID BOM");fflush(stdout);
				ITK_CALL(AOM_lock(Vehicle_BT));
				ITK_CALL(AOM_set_value_string(Vehicle_BT,"t5_Part_Info","HYBRID BOM"));
				ITK_CALL( AOM_save_without_extensions(Vehicle_BT));
				ITK_CALL(AOM_unlock(Vehicle_BT));
			}
		}
		else if(strcmp(c_BomTyp,"HYBRID BOM")==0)
		{
			printf("\n BOMTypeValidateStampFun--original is HYBRID BOM");fflush(stdout);
		}

	}
	*/
	printf("\n BOMTypeValidateStampFun--Processing is completed.");fflush(stdout);
}

extern DLLAPI int  save_method_3(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);
	tag_t objTypeTag = NULLTAG;
	//char   type_name[TCTYPE_name_size_c+1];

	char   *desid=NULL;
	char   *type_name	=	NULL;

	char   *DesRevDesc=NULL;
	char   *ReplacedDesRevDesc=NULL;
	char   *NewReplacedDescription=NULL;
	char   *ItemMaterial=NULL;

	int desclength= 0;
	int revdesccnt= 0;

	EPM_decision_t decision=EPM_go;

	printf("\n save_method_3--It's the time to save ItemRevision----------new-19-12-2024 ");fflush(stdout);

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
	if(tc_strcmp(type_name,"T5_PeDesign")==0)
	{
		printf("\n save_method_3--IT IS PE PART OBJECT HENCE EXIT!!! *** save_method_3 ***");fflush(stdout);
		return error_code;
	}

	if(strcmp(type_name,"Design")==0 || strcmp(type_name,"T5_SparKit")==0)//T5_SparKit
	{
		if( AOM_ask_value_string(objTag,"item_id",&desid)!=ITK_ok) PrintErrorStack();
		if( AOM_ask_value_string(objTag,"object_desc",&DesRevDesc)!=ITK_ok) PrintErrorStack();

		// if( AOM_ask_value_string(objTag,"t5Material",&ItemMaterial)!=ITK_ok);

		printf("\n save_method_3--Design Revision ItemID: [%s] and ItemMaterial: [%s] ", desid,ItemMaterial);fflush(stdout);

		if(strcmp(DesRevDesc,"")!=0)
		{
			desclength = strlen(DesRevDesc);
			for(revdesccnt=0;revdesccnt<desclength;revdesccnt++)
			{
				if(DesRevDesc[revdesccnt]=='\n')
				DesRevDesc[revdesccnt] =' ';

				if(DesRevDesc[revdesccnt]=='`')
				DesRevDesc[revdesccnt] =' ';

				if(DesRevDesc[revdesccnt]=='~')
				DesRevDesc[revdesccnt] =' ';

				if(DesRevDesc[revdesccnt]=='|')
				DesRevDesc[revdesccnt] =' ';

				if(DesRevDesc[revdesccnt]=='$')
				DesRevDesc[revdesccnt] =' ';

				if(DesRevDesc[revdesccnt]=='#')
				DesRevDesc[revdesccnt] =' ';

				if(DesRevDesc[revdesccnt]=='@')
				DesRevDesc[revdesccnt] =' ';

				if(DesRevDesc[revdesccnt]=='^')
				DesRevDesc[revdesccnt] =' ';

				if(DesRevDesc[revdesccnt]=='!')
				DesRevDesc[revdesccnt] =' ';
				printf("\n save_method_3--[%c] ",DesRevDesc[revdesccnt]);fflush(stdout);
			}

			ReplacedDesRevDesc = (char *)MEM_alloc (desclength * sizeof(char));
			strcpy(ReplacedDesRevDesc,DesRevDesc);

			printf("\n save_method_3--AFTER SET SAVE_METHOD_1::ReplacedDesRevDesc=====>[%s] ",ReplacedDesRevDesc);fflush(stdout);
			if(ReplacedDesRevDesc)
			{
				////if(AOM_refresh(objTag,TRUE)!=ITK_ok) PrintErrorStack();
				//if(AOM_set_value_string(objTag,"object_desc",ReplacedDesRevDesc)!=ITK_ok) PrintErrorStack();
				//if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
				////if(AOM_refresh(objTag,FALSE)!=ITK_ok) PrintErrorStack();
				//if(AOM_ask_value_string(objTag,"object_desc",&NewReplacedDescription)!=ITK_ok) PrintErrorStack();
				printf("\n save_method_3--AFTER SET SAVE_METHOD_1::NewReplacedDescription==>[%s] ", NewReplacedDescription);fflush(stdout);
			}
		}
	}
	printf("\n save_method_3--completed processing----");fflush(stdout);

	return ITK_ok;
}
extern DLLAPI int  save_method_Design_3(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;

	tag_t objTag = va_arg(args, tag_t);
	logical  isNew = va_arg(args, int);
	tag_t LatestRev = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t attr_id = NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t dataset = NULLTAG;
	tag_t form_attr_id = NULLTAG;
	tag_t status_rel = NULLTAG;

	tag_t *attachments = NULLTAG;
	char *PrtDR = NULL;
	char *ML_Staus = NULL;
	char *ObjProject = NULL;
	char *DRinfo4 = NULL;
	int IsMilestoneLiveFlag=0;
	int n_entry    = 1;
	int  rsltCount      =  0;

	tag_t   qryTag     = NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char   *qry_entry[1]  = {"SYSCD"};
	char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	//char type_name[TCTYPE_name_size_c+1];
	char *desid=NULL;
	char *type_name=NULL;
	char *desRev=NULL;
	char *PrtPrj=NULL;
	char *ObjectClassType = NULL;
	char *ObjectName = NULL;
	char* oojname = NULL;
	/*Start New Part Request Validation Calling Sudhir!!!!!!!*/
	char
        *qry_entries3[2] = {"Name","Type"},
        *qry_values3[2]	= {"*","*"};

	char
        *npr_qry_entries[2] = {"Tml Part Number","Type"},
        *npr_qry_values[2]	= {"*","*"};

	char
        *ctrl_qry_entries2[2] = {"SYSCD","SUBSYSCD"},
        *ctrl_qry_values2[2]	= {"*","*"};

	char
        *ctrl_qry_entries3[2] = {"SYSCD","SUBSYSCD"},
        *ctrl_qry_values3[2]	= {"*","*"};

	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};

	tag_t query = NULLTAG;
	tag_t ctrlquery2 = NULLTAG;
	tag_t ctrlquery3 = NULLTAG;
	tag_t *NewProjObj = NULLTAG;
	tag_t *setOfUsrDbObjsda = NULLTAG;
	tag_t *setOfPVBUObjspv = NULLTAG;
	tag_t *PartNewObjs = NULLTAG;
	tag_t master = NULLTAG;
	tag_t latestitemrev = NULLTAG;
	tag_t NPRQuery = NULLTAG;
	tag_t userSession = NULLTAG;
	tag_t usertag = NULLTAG;
	tag_t NPRCheckQuery = NULLTAG;
	tag_t *NPRCntrlObjs = NULLTAG;

	char *ProjectNewNameS = NULL;
	char *BussiNameS = NULL;
	char *ProjectTypeS = NULL;
	char *DsgGrup1S = NULL;
	char *subpart91 = NULL;
	char *sesOrgUsrName1Dup = NULL;
	char *NewPrtTypeS = NULL;
	char *subpart5 = NULL;
	char *subpart6 = NULL;
	char *subpart4 = NULL;
	char *t5ColourIndicatorS = NULL;
	char *t5CoatedS = NULL;
	char *t5Userinfo1DupS=NULL;
    char *t5Userinfo1S=NULL;
	 char *t5Userinfo2DupS=NULL;
    char *t5Userinfo2S=NULL;
	 char *t5Userinfo3DupS=NULL;
    char *t5Userinfo3S=NULL;
	 char *t5Userinfo4DupS=NULL;
    char *t5Userinfo4S=NULL;
    char *t5Userinfo1PV=NULL;
    char *t5PV1S=NULL;
	char *t5Userinfo2PV=NULL;
    char *t5PV2S=NULL;
	char *t5Userinfo3PV=NULL;
    char *t5PV3S=NULL;
	char *t5Userinfo4PV=NULL;
    char *t5PV4S=NULL;
    char *NewPartS=NULL;
    char *nwLifeCycleS=NULL;
    char *nwRaisedbydS=NULL;
    char *t5NwPartSessionNotMatchRaised=NULL;
    char *t5NwPartAppNeeded=NULL;
    char *NewPartS1=NULL;
    char *t5Userinfo5DupS=NULL;
    char *t5Userinfo5S=NULL;
    char *userName=NULL;
    char *info09=NULL;
    char *CommonPrtTypeS=NULL;

	int	n_found	= 0;
	int	n_tags_found = 0;
	int	ctrl_n_found2 = 0;
	int	ctrl_n_found3 = 0;
	int	CheckApplicable	= 0;
	int	flagNewPrt = 0;
	int	NewPartlength = 0;
	int	npr_n_found	= 0;
	int	nprfound = 0;
	//logical isNew = 0;
	/*END New Part Request Validation Calling Sudhir!!!!!!!*/

	int cnt = 0;
	int ij = 0;

	logical retain = 0;

	//printf("\n Design--METHOD_post_action_type---save_method_Design_3--Start....."); fflush(stdout);
	//printf("\n save_method_Design_3::It's the time to save Item/Design---");fflush(stdout);

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
	printf("\n save_method_Design_3::type_name: [%s]",type_name);fflush(stdout);

	if(tc_strcmp(type_name,"T5_PeDesign")==0)
	{
		printf("\n IT IS PE PART OBJECT HENCE EXIT!!! ***save_method_Design_3*** ");fflush(stdout);
		return ITK_ok;
	}

	if(strcmp(type_name,"Design")==0 || strcmp(type_name,"T5_SparKit")==0)//T5_SparKit
	{
		if( AOM_ask_value_string(objTag,"item_id",&desid)!=ITK_ok) PrintErrorStack();
		printf("\n save_method_Design_3::Design ItemID: [%s]", desid);fflush(stdout);
		if(ITEM_ask_latest_rev(objTag,&LatestRev)!=ITK_ok) PrintErrorStack();
		if (LatestRev!=NULLTAG)
		{
			if( AOM_ask_value_string(LatestRev,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
		}
		printf("\n save_method_Design_3::desRev: [%s]", desRev);fflush(stdout);

		CE_current_user_session_tag(&userSession);
		POM_get_user(&sesOrgUsrName1Dup,&usertag);
		AOM_ask_value_string(userSession,"user_id",&userName);
		AOM_ask_value_string(LatestRev,"t5_PartType",&CommonPrtTypeS);
		printf("\n save_method_Design_3::userName=[%s] sesOrgUsrName1Dup=[%s] CommonPrtTypeS=[%s]", userName, sesOrgUsrName1Dup, CommonPrtTypeS);fflush(stdout);
		/*Start New Part Request Validation Calling Sudhir!!!!!!!*/

		NewPartlength = strlen(desid);
		printf("\n save_method_Design_3::NewPartlength=[%d]  isNew=[%d]", NewPartlength, isNew);fflush(stdout);

		if(NewPartlength==12 && (isNew==true || isNew==1))
		{
			subpart5=subString(desid,6,2);
			subpart6=subString(desid,8,1);
			subpart91=subString(desid,8,2);
			subpart4=subString(desid,4,2);

			printf("\n save_method_Design_3::subpart5=[%s] subpart6=[%s] subpart91=[%s] subpart4=[%s]", subpart5,subpart6,subpart91,subpart4);fflush(stdout);

			AOM_ask_value_string(LatestRev,"t5_ProjectCode",&ProjectNewNameS);
			AOM_ask_value_string(LatestRev,"t5_DesignGrp",&DsgGrup1S);
			AOM_ask_value_string(LatestRev,"t5_PartType",&NewPrtTypeS);

			char *ctrl_entries[1] = {"SYSCD"}, 	*ctrl_values[1]	= {"*"};

			QRY_find2("ControlObjects", &NPRCheckQuery);
			ctrl_values[0]	= "NPRSignOffCheck";
			QRY_execute(NPRCheckQuery, 1, ctrl_entries, ctrl_values, &nprfound, &NPRCntrlObjs);
			printf("\n save_method_Design_3::nprfound: [%d]", nprfound);fflush(stdout);
			if(nprfound>0)
			{
				AOM_ask_value_string(NPRCntrlObjs[0],"t5_Userinfo9",&info09);
				printf("\n save_method_Design_3: info09 of :: %s",info09);fflush(stdout);
			}

			printf("\n save_method_Design_3::ProjectNewNameS=[%s] DsgGrup1S=[%s] NewPrtTypeS=[%s] ", ProjectNewNameS,DsgGrup1S,NewPrtTypeS);fflush(stdout);

			if(strcmp(subpart5,"CK") == 0)
			{
				printf("\n #############7th and 8th digit are CK hence bypassing New Part Request  ##############  ");fflush(stdout);
			}
			else
			{
				if (( strcmp(subpart6,"Z") == 0) || ( strcmp(subpart6,"C") == 0))
				{
					printf("\n ********** 9th and 10th digit are Z OR C hence bypassing New Part Request  ******** ");fflush(stdout);
				}
				else
				{
					AOM_ask_value_string(LatestRev,"t5_ColourInd",&t5ColourIndicatorS);
					AOM_ask_value_string(LatestRev,"t5_PrtCatCode",&t5CoatedS);

					printf("\n save_method_Design_3::t5ColourIndicatorS=[%s]  t5CoatedS=[%s] ", t5ColourIndicatorS,t5CoatedS);fflush(stdout);

					if(strcmp(t5ColourIndicatorS,"C") == 0 || strcmp(t5CoatedS,"C") == 0)
					{
						printf("\n save_method_Design_3::ByPass for Objects with Colour Indicator as C ");fflush(stdout);
					}
					else
					{
						if((strcmp(NewPrtTypeS,"A")==0) || (strcmp(NewPrtTypeS,"C")==0))
						{
						qry_values3[0]	= ProjectNewNameS;
						qry_values3[1]	= "Project";
						QRY_find2("Item...", &query);
						//QRY_execute(query, 1, qry_entries3, qry_values3, &n_found, &NewProjObj);
						QRY_execute(query, 2, qry_entries3, qry_values3, &n_found, &NewProjObj);
						printf("\n save_method_Design_3::n_found =[%d]",n_found);fflush(stdout);
						if(n_found>0)
						{
							AOM_ask_value_string(NewProjObj[0],"t5_BussUnitType",&BussiNameS);
							printf("\n save_method_Design_3::BussiNameS====>[%s]", BussiNameS);fflush(stdout);
							AOM_ask_value_string(NewProjObj[0],"t5_ProjectType",&ProjectTypeS);
							printf("\n save_method_Design_3::Proj_typ====>[%s]", ProjectTypeS);fflush(stdout);

							if( (strcmp(ProjectTypeS,"E")==0) || (strcmp(ProjectTypeS,"G")==0))
							{
								printf("\n save_method_Design_3::engine gear box Project code= %s ", ProjectNewNameS);fflush(stdout);
								printf("\t -->In Assyvalidation Inside the project type as Engine or GearBox  ");fflush(stdout);
								if(strcmp(ProjectTypeS,"E")==0)
								{
										printf("\n save_method_Design_3:: Inside the project type as->(%s) Design-(%s) Designation ID- (%s) ",ProjectTypeS,DsgGrup1S,subpart91);fflush(stdout);

										  if(strcmp(DsgGrup1S,"50")==0)
										{
											 if(strcmp(subpart91,"33")==0)
											{
												CheckApplicable=1;
												printf("\n save_method_Design_3::Check is applicable to design group 50 and designation id -33  ");fflush(stdout);
											}

										}
										else if(strcmp(DsgGrup1S,"23")==0)
										{
											if((strcmp(subpart91,"33")==0) || (strcmp(subpart91,"37")==0) || (strcmp(subpart91,"38")==0))
											{
												CheckApplicable=1;
												printf("\n save_method_Design_3:: Check is applicable to design group 23 and designation id -33/37/38  ");fflush(stdout);
											}

										}
										printf("\n save_method_Design_3:: Engine-Outside the project type as ---->(%s)  ",ProjectTypeS);fflush(stdout);
								}
								else if(strcmp(ProjectTypeS,"G")==0)
								{
									printf("\n save_method_Design_3::  GB-Project type as ---->(%s) and Design group -(%s) and Designation ID-(%s)  ",ProjectTypeS,DsgGrup1S,subpart91);fflush(stdout);
										if(strcmp(DsgGrup1S,"26")==0)
										{
											 if((strcmp(subpart91,"31")==0) || (strcmp(subpart91,"77")==0) || (strcmp(subpart91,"78")==0) || (strcmp(subpart91,"86")==0) ||(strcmp(subpart91,"65")==0))
											{
												CheckApplicable=1;
												printf("\n save_method_Design_3::  Gear-Box Check is applicable to design group 26 and designation id -33  ");fflush(stdout);
											}

										}
										else if(strcmp(DsgGrup1S,"35")==0)
										{
											if((strcmp(subpart91,"31")==0) || (strcmp(subpart91,"77")==0) || (strcmp(subpart91,"78")==0) || (strcmp(subpart91,"86")==0) ||(strcmp(subpart91,"65")==0))
											{
												CheckApplicable=1;
												printf("\n save_method_Design_3::  Gear-Box Check is applicable to design group 35 and designation id -33/37/38  ");fflush(stdout);
											}

										}
										printf("\n save_method_Design_3:: GB Outside the project type as ---->(%s)  ",ProjectTypeS);fflush(stdout);
								}
							}
							if((strcmp(BussiNameS,"CVBU")==0) || (strcmp(BussiNameS,"PCBU")==0) || (strcmp(BussiNameS,"PCBU and CVBU Both")==0))
							{
								ctrl_qry_values2[0]	= "NwPrtReq";
								ctrl_qry_values2[1]	= BussiNameS;
								QRY_find2("ControlObjQry", &ctrlquery2);
								//QRY_execute(ctrlquery2, 1, ctrl_qry_entries2, ctrl_qry_values2, &ctrl_n_found2, &setOfUsrDbObjsda);
								QRY_execute(ctrlquery2, 2, ctrl_qry_entries2, ctrl_qry_values2, &ctrl_n_found2, &setOfUsrDbObjsda);
								printf("\n save_method_Design_3::ctrl_n_found2 =[%d]",ctrl_n_found2);fflush(stdout);
								if(ctrl_n_found2>0)
								{
									AOM_ask_value_string(setOfUsrDbObjsda[0],"t5_Userinfo1",&t5Userinfo1DupS);
									t5Userinfo1S = strdup(t5Userinfo1DupS);
									AOM_ask_value_string(setOfUsrDbObjsda[0],"t5_Userinfo2",&t5Userinfo2DupS);
									t5Userinfo2S = strdup(t5Userinfo2DupS);
									AOM_ask_value_string(setOfUsrDbObjsda[0],"t5_Userinfo3",&t5Userinfo3DupS);
									t5Userinfo3S = strdup(t5Userinfo3DupS);
									AOM_ask_value_string(setOfUsrDbObjsda[0],"t5_Userinfo4",&t5Userinfo4DupS);
									t5Userinfo4S = strdup(t5Userinfo4DupS);
									AOM_ask_value_string(setOfUsrDbObjsda[0],"t5_Userinfo5",&t5Userinfo5DupS);
									t5Userinfo5S = strdup(t5Userinfo5DupS);
									printf("\n In save_method_Design_3:::: Control object row 1===> %s ",t5Userinfo1S);fflush(stdout);
									printf("\n In save_method_Design_3:::: Control object row 2 ===> %s ",t5Userinfo2S);fflush(stdout);
									printf("\n In save_method_Design_3:::: Control object row 3===> %s ",t5Userinfo3S);fflush(stdout);
									printf("\n In save_method_Design_3:::: Control object row 4 ===> %s ",t5Userinfo4S);fflush(stdout);
									printf("\n In save_method_Design_3:::: Control object row 5 ===> %s ",t5Userinfo5S);fflush(stdout);
									printf("\n In save_method_Design_3:::: ProjectNewNameS ===> %s ",ProjectNewNameS);fflush(stdout);
									printf("\n save_method_Design_3::Vlaue of CheckApplicable %d  ",CheckApplicable);fflush(stdout);
									if(tc_strstr(t5Userinfo5S,ProjectNewNameS)!=NULL)
									{
									if(CheckApplicable== 0)
									{
										if(strcmp(BussiNameS,"CVBU")==0)
										{
											printf("\n In save_method_Design_3:: Inside the CVBU  ");fflush(stdout);
											if(strstr(t5Userinfo1S, subpart4) != NULL || strstr(t5Userinfo2S, subpart4) != NULL || strstr(t5Userinfo3S, subpart4) != NULL || strstr(t5Userinfo4S, subpart4) != NULL)
											{
												printf("\n save_method_Design_3::#### Do nothing after checking 5th and 6th digit in save_method_Design_3:: ");fflush(stdout);
												flagNewPrt=1;
											}
										}
										else
										{
											if(strcmp(BussiNameS,"PCBU")==0)
											{
												ctrl_qry_values3[0]	= "PVB";
												ctrl_qry_values3[1]	= "DesGrp";
												QRY_find2("ControlObjQry", &ctrlquery3);
												//QRY_execute(ctrlquery3, 1, ctrl_qry_entries3, ctrl_qry_values3, &ctrl_n_found3, &setOfPVBUObjspv);
												QRY_execute(ctrlquery3, 2, ctrl_qry_entries3, ctrl_qry_values3, &ctrl_n_found3, &setOfPVBUObjspv);
												printf("\n save_method_Design_3::ctrl_n_found3 =[%d]",ctrl_n_found3);fflush(stdout);
												if(ctrl_n_found3>0)
												{
													AOM_ask_value_string(setOfPVBUObjspv[0],"t5_Userinfo1",&t5Userinfo1PV);
													t5PV1S = strdup(t5Userinfo1PV);
													AOM_ask_value_string(setOfPVBUObjspv[0],"t5_Userinfo2",&t5Userinfo2PV);
													t5PV2S = strdup(t5Userinfo2PV);
													AOM_ask_value_string(setOfPVBUObjspv[0],"t5_Userinfo3",&t5Userinfo3PV);
													t5PV3S = strdup(t5Userinfo3PV);
													AOM_ask_value_string(setOfPVBUObjspv[0],"t5_Userinfo4",&t5Userinfo4PV);
													t5PV4S = strdup(t5Userinfo4PV);
													printf("\n save_method_Design_3:::::: Control object row 1===> %s ",t5PV1S);fflush(stdout);
													printf("\n save_method_Design_3:::::: Control object row 2 ===> %s ",t5PV2S);fflush(stdout);
													printf("\n save_method_Design_3:::::: Control object row 3===> %s ",t5PV3S);fflush(stdout);
													printf("\n save_method_Design_3:::::: Control object row 4 ===> %s ",t5PV4S);fflush(stdout);
													printf("\n save_method_Design_3::#### INSIDE THE PCBU CONDITION Designation id -%s and Design Group --(%s) !!!!!!! ", subpart91,DsgGrup1S);fflush(stdout);

													//printf("\n save_method_Design_3::#### New part is not applicable for PVBU for designation ID-%s ### ", subpart91);fflush(stdout);

													if(strstr(t5PV1S, subpart4) != NULL || strstr(t5PV2S, subpart4) != NULL || strstr(t5PV3S, subpart4) != NULL || strstr(t5PV4S, subpart4) != NULL)
													{
														printf("\n save_method_Design_3::#### PVBU control object Do nothing after checking Design group digit in save_method_Design_3:::: file  ### ");fflush(stdout);
														flagNewPrt=1;
													}
													else
													{
														printf("\n save_method_Design_3::Inside else as design grp-(%s) not in control object for PVBU ~~~~~~~~~~ ",subpart4);fflush(stdout);
														if(strcmp(DsgGrup1S,"54")==0)
														{
															if((strstr(subpart91,"82") != NULL) || (strstr(subpart91,"99") != NULL) || (strstr(subpart91,"63") != NULL) || (strstr(subpart91,"33") != NULL))
															{
																flagNewPrt=0;
																printf("\n save_method_Design_3::***** Flag Set to 0 for 82 ~~~~~~~~~ ");fflush(stdout);
															}
															else
															{
																printf("\n save_method_Design_3::!!!!! Design group -(%s) CONDITION Designation id -(%s) ### ",DsgGrup1S, subpart91);fflush(stdout);
																flagNewPrt=1;
																printf("\n save_method_Design_3::***** Flag Set to 1 ~~~~~~~~~ ");fflush(stdout);
															}
														}
														else
														{
															if(strstr(t5Userinfo1S, subpart91) != NULL || strstr(t5Userinfo2S, subpart91) != NULL || strstr(t5Userinfo3S, subpart91) != NULL || strstr(t5Userinfo4S, subpart91) != NULL )
															{
																flagNewPrt=1;
																printf("\n save_method_Design_3::outside the 54 design grp condition -%s   ",DsgGrup1S );fflush(stdout);
															}
														}
													 }
												}
											}
										}
										if((strcmp(BussiNameS,"PCBU and CVBU Both")==0) && (CheckApplicable== 0))
										{
											printf("\n save_method_Design_3::!!!!!! AAAA !!! Inside the CheckApplicable--- %d  ",CheckApplicable );fflush(stdout);
											printf("\n save_method_Design_3::!!!!!! AAAA !!! Vlaue of bussiness unit--- %s  ",BussiNameS );fflush(stdout);
											flagNewPrt=1;
											printf("\n save_method_Design_3::flagNewPrt Value attt  -%d  ",flagNewPrt );fflush(stdout);
										}
									}
									printf("\n save_method_Design_3::Inside the assyvalidation file flagNewPrt -%d   ",flagNewPrt );fflush(stdout);
									if(CheckApplicable==1)
									{
										flagNewPrt=1;
										printf("\n save_method_Design_3::@@ Else Inside t5assyvalidation value of CheckApplicable - %d ", CheckApplicable);fflush(stdout);
										printf("\n save_method_Design_3::@@ Elseinside CheckApplicable=!0 condition -- Designation Id of part is  (%s) and design grp -%s ",subpart91,DsgGrup1S);fflush(stdout);
										printf("\n save_method_Design_3::@@ Else Inside PrtNm Value issssssss ----->>> (%s)### ",desid);fflush(stdout);
										NewPartS = (char *) MEM_alloc( 100 * sizeof(char) );
										strcpy(NewPartS,"*");
										strcat(NewPartS,desid);
										strcat(NewPartS,"*");
										printf("\n save_method_Design_3::@@ Else PrtNm Value after string copy is  ----->>> (%s)### ",NewPartS);fflush(stdout);

										npr_qry_values[0]	= NewPartS;
										npr_qry_values[1]	= "New Part Request";
										QRY_find2("tm_NewPartRequest", &NPRQuery);
										//QRY_execute(NPRQuery, 1, npr_qry_entries, npr_qry_values, &npr_n_found, &PartNewObjs);
										QRY_execute(NPRQuery, 2, npr_qry_entries, npr_qry_values, &npr_n_found, &PartNewObjs);

										printf("\n save_method_Design_3:: npr_n_found==>%d",npr_n_found);fflush(stdout);
										if(npr_n_found>0)
										{
											AOM_ask_value_string(PartNewObjs[0],"t5_NwLCState",&nwLifeCycleS);
											printf("\n save_method_Design_3::nwLifeCycleS====>[%s]", nwLifeCycleS);fflush(stdout);

											AOM_ask_value_string(PartNewObjs[0],"t5_NwRaisedBy",&nwRaisedbydS);
											printf("\n save_method_Design_3::NwRaisedBy====>[%s]", nwRaisedbydS);fflush(stdout);
											if(tc_strstr(userName,nwRaisedbydS)!=NULL || tc_strcmp(userName,nwRaisedbydS)==0 || tc_strcmp(nwRaisedbydS,sesOrgUsrName1Dup)==0)
											{
												printf("\n save_method_Design_3::@@ Else Session User Name and Raised by User Login Name is same. Hence Allowed to Created the TC part  ");fflush(stdout);
											}
											else
											{
												if(tc_strstr(info09,"NPR")!=NULL)
												{
													printf("\n save_method_Design_3::Else Inside the Condition of Raised by User Login Name missmatch with Session user Login ");fflush(stdout);
													t5NwPartSessionNotMatchRaised = (char *) MEM_alloc( 1000 * sizeof(char) );
													strcpy(t5NwPartSessionNotMatchRaised,"You Can not Create the TC Part Number.As New Part Request Raised by Login ");
													strcat(t5NwPartSessionNotMatchRaised,nwRaisedbydS);
													strcat(t5NwPartSessionNotMatchRaised,"is Different.");
													strcat(t5NwPartSessionNotMatchRaised,"Your Current Login is ");
													strcat(t5NwPartSessionNotMatchRaised,sesOrgUsrName1Dup);
													EMH_clear_errors();
													error_code=t9NewPartReqCre_Val0048;
													EMH_store_error_s1(EMH_severity_error,error_code, t5NwPartSessionNotMatchRaised);
													return error_code;
												}
												else
												{
													printf("\n save_method_Design_3::1ALLOWED TO CREATE");fflush(stdout);
												}
											}
										}
										else
										{
											if(tc_strstr(info09,"NPR")!=NULL)
											{
												printf("\n save_method_Design_3::Inside the approval condition for new part ");fflush(stdout);
												t5NwPartAppNeeded = (char *) MEM_alloc( 1000 * sizeof(char) );
												strcpy(t5NwPartAppNeeded,"New Part Request is Not Approved for Newly Created TC Part Number ");
												strcat(t5NwPartAppNeeded,"Raise the New Part Request in Creo or Catia for TC Part which is having Cad Data For SPARE-KIT,Please Use the Option Crete-->New Part Request. Fill the Form and Submit to LifeCycle [New Part Request]");
												EMH_clear_errors();
												error_code=t9NewPartReqCre_Val0048;
												EMH_store_error_s1(EMH_severity_error,error_code, t5NwPartAppNeeded);
												return error_code;
											}
											else
											{
												printf("\n save_method_Design_3::2ALLOWED TO CREATE");fflush(stdout);
											}
										}
									}
									printf("\n save_method_Design_3::11111 Inside the assyvalidation file  flagNewPrt  -%d   ",flagNewPrt );fflush(stdout);
									if(flagNewPrt !=1)
									{
										printf("\n save_method_Design_3::inside flagNewPrt=!1 condition -- Designation Id of part is  (%s) and design grp -%s ",subpart91,DsgGrup1S);fflush(stdout);
										printf("\n save_method_Design_3::PrtNm Value issssssss ----->>> (%s)### ",desid);fflush(stdout);
										NewPartS = (char *) MEM_alloc( 100 * sizeof(char) );
										strcpy(NewPartS,"*");
										strcat(NewPartS,desid);
										strcat(NewPartS,"*");
										printf("\n save_method_Design_3::@@ Else PrtNm Value after string copy is  ----->>> (%s)### ",NewPartS);fflush(stdout);
										npr_qry_values[0]	= NewPartS;
										npr_qry_values[1]	= "New Part Request";
										QRY_find2("tm_NewPartRequest", &NPRQuery);
										//QRY_execute(NPRQuery, 1, npr_qry_entries, npr_qry_values, &npr_n_found, &PartNewObjs);
										QRY_execute(NPRQuery, 2, npr_qry_entries, npr_qry_values, &npr_n_found, &PartNewObjs);
										printf("\n save_method_Design_3:: npr_n_found==>%d",npr_n_found);fflush(stdout);
										if(npr_n_found>0)
										{
											AOM_ask_value_string(PartNewObjs[0],"t5_NwLCState",&nwLifeCycleS);
											printf("\n save_method_Design_3::nwLifeCycleS====>[%s]", nwLifeCycleS);fflush(stdout);

											AOM_ask_value_string(PartNewObjs[0],"t5_NwRaisedBy",&nwRaisedbydS);
											printf("\n save_method_Design_3::NwRaisedBy====>[%s]", nwRaisedbydS);fflush(stdout);
											if(tc_strstr(userName,nwRaisedbydS)!=NULL || tc_strcmp(userName,nwRaisedbydS)==0 || tc_strcmp(nwRaisedbydS,sesOrgUsrName1Dup)==0)
											{
												printf("\n save_method_Design_3::Else Session User Name and Raised by User Login Name is same. Hence Allowed to Created the TC part  ");fflush(stdout);
											}
											else
											{
												if(tc_strstr(info09,"NPR")!=NULL)
												{
													printf("\n save_method_Design_3::Else Inside the Condition of Raised by User Login Name missmatch with Session user Login ");fflush(stdout);
													printf("\n save_method_Design_3--Else Inside the Condition of Raised by User Login Name missmatch with Session user Login ");fflush(stdout);
													t5NwPartSessionNotMatchRaised = (char *) MEM_alloc( 1000 * sizeof(char) );
													strcpy(t5NwPartSessionNotMatchRaised,"You Can not Create the TC Part Number.As New Part Request Raised by Login ");
													strcat(t5NwPartSessionNotMatchRaised,nwRaisedbydS);
													strcat(t5NwPartSessionNotMatchRaised,"is Different.");
													strcat(t5NwPartSessionNotMatchRaised,"Your Current Login is ");
													strcat(t5NwPartSessionNotMatchRaised,sesOrgUsrName1Dup);
													EMH_clear_errors();
													error_code=t9NewPartReqCre_Val0048;
													EMH_store_error_s1(EMH_severity_error,error_code, t5NwPartSessionNotMatchRaised);
													return error_code;
												}
												else
												{
													printf("\n save_method_Design_3::3ALLOWED TO CREATE");fflush(stdout);
												}
											}
										}
										else
										{
											if(tc_strstr(info09,"NPR")!=NULL)
											{
												printf("\n save_method_Design_3:: Else Inside the approval condition for new part ");fflush(stdout);
												t5NwPartAppNeeded = (char *) MEM_alloc( 1000 * sizeof(char) );
												strcpy(t5NwPartAppNeeded,"New Part Request is Not Approved for Newly Created TC Part Number ");
												strcat(t5NwPartAppNeeded,"Raise the New Part Request in Creo or Catia for TC Part which is having Cad Data For SPARE-KIT,Please Use the Option Crete-->New Part Request. Fill the Form and Submit to LifeCycle [New Part Request]");
												EMH_clear_errors();
												error_code=t9NewPartReqCre_Val0048;
												EMH_store_error_s1(EMH_severity_error,error_code, t5NwPartAppNeeded);
												return error_code;
											}
											else
											{
												printf("\n save_method_Design_3::4ALLOWED TO CREATE");fflush(stdout);
											}
										}
									}///
									}
								}
							}
							// ///////////////////////////test message !!!!!!
							//NewPartS1 = (char *) MEM_alloc( 100 * sizeof(char) );
							//strcpy(NewPartS1,"*");
							//strcat(NewPartS1,desid);
							//strcat(NewPartS1,"*");
							//printf("\n @@ NewPartS1 is  ----->>> (%s)### ",NewPartS1);fflush(stdout);
							//npr_qry_values[0]	= NewPartS1;
							//npr_qry_values[1]	= "New Part Request";
							//QRY_find2("New Part Request", &NPRQuery);
							//QRY_execute(NPRQuery, 1, npr_qry_entries, npr_qry_values, &npr_n_found, &PartNewObjs);
							//printf("\n TEST------save_method_Design_3:: n_tags_found==>%d",npr_n_found);fflush(stdout);
							//if(npr_n_found==0)
							//{
							//	EMH_clear_errors();
							//	EMH_store_error_s1(EMH_severity_error,ITK_err, "New Part Request Not found!!!!");
							//	return ITK_err;
							//}
						}
						}
					}
				}
			}
		}

		/// For TPL Creation Validation.
		if(NewPartlength==11 && (isNew==true || isNew==1) && (tc_strcmp(CommonPrtTypeS,"T")==0 || tc_strcmp(CommonPrtTypeS,"Technical Part List")==0))
		{
			char *TPLDsgGrupS=NULL;
			char *TechPrtTypeS=NULL;
			char *info09=NULL;
			char *TPLNewPartS=NULL;
			char *nprTPLRaisedbydS=NULL;
			char
			*ctrl_qry_tplentries[1] = {"SYSCD"},
			*ctrl_qry_tplvalues[1]	= {"*"};

			char
			*npr_TPL_qry_entries[2] = {"Tml Part Number","Type"},
			*npr_TPL_qry_values[2]	= {"*","*"};

			tag_t	NPRTPLQuery	= NULLTAG;
			tag_t	TPLCheckQuery	= NULLTAG;
			tag_t	*TPLPartNewPartReqObjs		= NULLTAG;
			tag_t	*TPLCntrlObjs		= NULLTAG;

			int	npr_TPL_n_found	= 0;
			int	tplnpr_n_found	= 0;

			AOM_ask_value_string(LatestRev,"t5_DesignGrp",&TPLDsgGrupS);
			AOM_ask_value_string(LatestRev,"t5_PartType",&TechPrtTypeS);
			printf("\n save_method_Design_3::TPLDsgGrupS: [%s]", TPLDsgGrupS);fflush(stdout);
			printf("\n save_method_Design_3::TechPrtTypeS: [%s]", TechPrtTypeS);fflush(stdout);
			if((tc_strcmp(TechPrtTypeS,"T")==0 || tc_strcmp(TechPrtTypeS,"Technical Part List")==0))
			{
				printf("\n save_method_Design_3::desid: [%s]", desid);fflush(stdout);
				TPLNewPartS = (char *) MEM_alloc( 100 * sizeof(char) );
				tc_strcpy(TPLNewPartS,"*");
				tc_strcat(TPLNewPartS,desid);
				tc_strcat(TPLNewPartS,"*");
				printf("\n save_method_Design_3::TPLNewPartS: [%s]", TPLNewPartS);fflush(stdout);

				npr_TPL_qry_values[0]	= TPLNewPartS;
				npr_TPL_qry_values[1]	= "New Part Request";
				QRY_find2("tm_NewPartRequest", &NPRTPLQuery);
				QRY_find2("ControlObjects", &TPLCheckQuery);
				if(NPRTPLQuery!=NULLTAG)
				{
					QRY_execute(NPRTPLQuery, 2, npr_TPL_qry_entries, npr_TPL_qry_values, &npr_TPL_n_found, &TPLPartNewPartReqObjs);
					printf("\n save_method_Design_3::npr_TPL_n_found: [%d]", npr_TPL_n_found);fflush(stdout);

					ctrl_qry_tplvalues[0]	= "VehNPRSignOffCheck";
					QRY_execute(TPLCheckQuery, 1, ctrl_qry_tplentries, ctrl_qry_tplvalues, &tplnpr_n_found, &TPLCntrlObjs);
					printf("\n save_method_Design_3::tplnpr_n_found: [%d]", tplnpr_n_found);fflush(stdout);
					if(tplnpr_n_found>0)
					{
						AOM_ask_value_string(TPLCntrlObjs[0],"t5_Userinfo9",&info09);
						printf("\n save_method_Design_3: info09 of :: %s\n",info09);fflush(stdout);
					}

					if(npr_TPL_n_found>0)
					{
						AOM_ask_value_string(TPLPartNewPartReqObjs[0],"t5_NwRaisedBy",&nprTPLRaisedbydS);
						printf("\n save_method_Design_3::nprTPLRaisedbydS====>[%s]", nprTPLRaisedbydS);fflush(stdout);
						if(tc_strstr(userName,nprTPLRaisedbydS)!=NULL || tc_strcmp(userName,nprTPLRaisedbydS)==0 || tc_strcmp(nprTPLRaisedbydS,sesOrgUsrName1Dup)==0)
						{
							printf("\n save_method_Design_3::Else Session User Name and Raised by User Login Name is same. Hence Allowed to Created the TC part  ");fflush(stdout);
						}
						else
						{
							if(tc_strstr(info09,"TPLNPR")!=NULL)
							{
								printf("\n save_method_Design_3--Else Inside the Condition of Raised by User Login Name missmatch with Session user Login ");fflush(stdout);
								char *t5NwTPLPartSessionNotMatchRaised = NULL;
								t5NwTPLPartSessionNotMatchRaised = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5NwTPLPartSessionNotMatchRaised,"You Can not Create the Vehicle.As Vehicle New Part Request Raised by Login ");
								strcat(t5NwTPLPartSessionNotMatchRaised,nprTPLRaisedbydS);
								strcat(t5NwTPLPartSessionNotMatchRaised,"is Different.");
								strcat(t5NwTPLPartSessionNotMatchRaised,"Your Current Login is ");
								strcat(t5NwTPLPartSessionNotMatchRaised,sesOrgUsrName1Dup);
								EMH_clear_errors();
								error_code=t9NewPartReqCre_Val0048;
								EMH_store_error_s1(EMH_severity_error,error_code, t5NwTPLPartSessionNotMatchRaised);
								return error_code;
							}
							else
							{
								printf("\n 1save_method_Design_3: continue::info09 of :: %s\n",info09);fflush(stdout);
							}

						}
					}
					else
					{
						if(tc_strstr(info09,"TPLNPR")!=NULL)
						{
							printf("\n save_method_Design_3::Else Inside the approval condition for new part ");fflush(stdout);
							char *t5NwTPLPartAppNeeded = NULL;
							t5NwTPLPartAppNeeded = (char *) MEM_alloc( 1000 * sizeof(char) );
							strcpy(t5NwTPLPartAppNeeded,"New Part Request is Not Approved for Newly Created TPL ");
							strcat(t5NwTPLPartAppNeeded,"Raise the New Part Request,Please Use the Option CV Engineering-->Create->New Part Request. Fill the Form and Submit to LifeCycle [New Part Request LifeCycle]");
							EMH_clear_errors();
							error_code=t9NewPartReqCre_Val0048;
							EMH_store_error_s1(EMH_severity_error,error_code, t5NwTPLPartAppNeeded);
							return error_code;
						}
						else
						{
							printf("\n 2save_method_Design_3: continue::info09 of :: %s\n",info09);fflush(stdout);
						}
					}
				}
			}
		}
		/// end For TPL Creation Validation.
		if(NewPartlength==9 && (isNew==true || isNew==1) && (tc_strcmp(CommonPrtTypeS,"V")==0 || tc_strcmp(CommonPrtTypeS,"Vehicle")==0))
		{
			char *VehDsgGrupS=NULL;
			char *VehPrtTypeS=NULL;
			char *info02=NULL;
			char
			*ctrl_qry_vehentries[1] = {"SYSCD"},
			*ctrl_qry_vehvalues[1]	= {"*"};

			char
			*vnpr_qry_entries[1] = {"Veh New Tml Part No"},
			*vnpr_qry_values[1]	= {"*"};

			tag_t	VehCheckQuery	= NULLTAG;
			tag_t	*VehCntrlObjs		= NULLTAG;

			int	vehnpr_n_found	= 0;

			AOM_ask_value_string(LatestRev,"t5_DesignGrp",&VehDsgGrupS);
			AOM_ask_value_string(LatestRev,"t5_PartType",&VehPrtTypeS);
			printf("\n save_method_Design_3::VehDsgGrupS: [%s]", VehDsgGrupS);fflush(stdout);
			printf("\n save_method_Design_3::VehPrtTypeS: [%s]", VehPrtTypeS);fflush(stdout);
			if(tc_strcmp(VehDsgGrupS,"00")==0 && (tc_strcmp(VehPrtTypeS,"V")==0 || tc_strcmp(VehPrtTypeS,"Vehicle")==0))
			{
				NewPartS = (char *) MEM_alloc( 100 * sizeof(char) );
				tc_strcpy(NewPartS,"*");
				tc_strcat(NewPartS,desid);
				tc_strcat(NewPartS,"*");
				printf("\n save_method_Design_3::NewPartS: [%s]", NewPartS);fflush(stdout);
				vnpr_qry_values[0]	= NewPartS;
				QRY_find2("tm_VehNewPartRequest", &NPRQuery);
				QRY_find2("ControlObjects", &VehCheckQuery);
				if(NPRQuery!=NULLTAG)
				{
					QRY_execute(NPRQuery, 1, vnpr_qry_entries, vnpr_qry_values, &npr_n_found, &PartNewObjs);
					printf("\n save_method_Design_3::npr_n_found: [%d]", npr_n_found);fflush(stdout);
					ctrl_qry_vehvalues[0]	= "VehNPRSignOffCheck";
					QRY_execute(VehCheckQuery, 1, ctrl_qry_vehentries, ctrl_qry_vehvalues, &vehnpr_n_found, &VehCntrlObjs);
					printf("\n save_method_Design_3::vehnpr_n_found: [%d]", vehnpr_n_found);fflush(stdout);
					if(vehnpr_n_found>0)
					{
						AOM_ask_value_string(VehCntrlObjs[0],"t5_Userinfo2",&info02);
						printf("\n save_method_Design_3: info02 of :: %s\n",info02);fflush(stdout);
					}

					if(npr_n_found>0)
					{
						AOM_ask_value_string(PartNewObjs[0],"t5_NwLCState",&nwLifeCycleS);
						printf("\n save_method_Design_3::nwLifeCycleS====>[%s]", nwLifeCycleS);fflush(stdout);

						AOM_ask_value_string(PartNewObjs[0],"t5_VehNwRaisedBy",&nwRaisedbydS);
						printf("\n save_method_Design_3::NwRaisedBy====>[%s]", nwRaisedbydS);fflush(stdout);
						if(tc_strstr(userName,nwRaisedbydS)!=NULL || tc_strcmp(userName,nwRaisedbydS)==0 || tc_strcmp(nwRaisedbydS,sesOrgUsrName1Dup)==0)
						{
							printf("\n @@ Else Session User Name and Raised by User Login Name is same. Hence Allowed to Created the TC part  ");fflush(stdout);
						}
						else
						{
							if(tc_strstr(info02,"VehNPR")!=NULL)
							{
								printf("\n@@ Else Inside the Condition of Raised by User Login Name missmatch with Session user Login ");fflush(stdout);
								printf("\n save_method_Design_3--Else Inside the Condition of Raised by User Login Name missmatch with Session user Login ");fflush(stdout);
								t5NwPartSessionNotMatchRaised = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5NwPartSessionNotMatchRaised,"You Can not Create the Vehicle.As Vehicle New Part Request Raised by Login ");
								strcat(t5NwPartSessionNotMatchRaised,nwRaisedbydS);
								strcat(t5NwPartSessionNotMatchRaised,"is Different.");
								strcat(t5NwPartSessionNotMatchRaised,"Your Current Login is ");
								strcat(t5NwPartSessionNotMatchRaised,sesOrgUsrName1Dup);
								EMH_clear_errors();
								error_code=t9NewPartReqCre_Val0048;
								EMH_store_error_s1(EMH_severity_error,error_code, t5NwPartSessionNotMatchRaised);
								return error_code;
							}
							else
							{
								printf("\n 1save_method_Design_3: continue::info02 of :: %s\n",info02);fflush(stdout);
							}

						}
					}
					else
					{
						if(tc_strstr(info02,"VehNPR")!=NULL)
						{
							printf("\n @@ Else Inside the approval condition for new part ");fflush(stdout);
							t5NwPartAppNeeded = (char *) MEM_alloc( 1000 * sizeof(char) );
							strcpy(t5NwPartAppNeeded,"Vehicle New Part Request is Not Approved for Newly Created vehicle ");
							strcat(t5NwPartAppNeeded,"Raise the Vehicle New Part Request,Please Use the Option CV Engineering-->Create->Vehicle New Part Request. Fill the Form and Submit to LifeCycle [Vehicle New Part Request LifeCycle]");
							EMH_clear_errors();
							error_code=t9NewPartReqCre_Val0048;
							EMH_store_error_s1(EMH_severity_error,error_code, t5NwPartAppNeeded);
							return error_code;
						}
						else
						{
							printf("\n 2save_method_Design_3: continue::info02 of :: %s\n",info02);fflush(stdout);
						}
					}
				}
			}

		}
		/*End New Part Request Validation Calling Sudhir!!!!!!!*/

		if(ITEM_ask_latest_rev(objTag,&LatestRev)!=ITK_ok) PrintErrorStack();
		if (LatestRev!=NULLTAG)
		{
			if( AOM_ask_value_string(LatestRev,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();
		}
		printf("\n save_method_Design_3::desRev: [%s]", desRev);fflush(stdout);

		if(tc_strcmp(desRev,"NR")==0 && LatestRev!=NULLTAG)
		{
			printf("\n  1C--Inside NR check----");fflush(stdout);
			AOM_refresh( LatestRev, TRUE);
			AOM_set_value_string(LatestRev,"item_revision_id","NR;1");
			if(AOM_save_without_extensions(LatestRev)!=ITK_ok)PrintErrorStack();
			AOM_refresh(LatestRev,FALSE);
			//if(AOM_refresh(LatestRev,1)!=ITK_ok) PrintErrorStack();
			//if(AOM_refresh(objTag,1)!=ITK_ok) PrintErrorStack();
			printf("\n  2C--Inside NR check----");fflush(stdout);
			printf("\n  NR;1 updated");fflush(stdout);

			/*
			if(POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id)!=ITK_ok) PrintErrorStack();
			printf("\n  C--Inside NR check----");fflush(stdout);
			if(AOM_lock(LatestRev));
			if(POM_set_attr_string(1,&LatestRev,attr_id,"NR;1")) PrintErrorStack();
			if(AOM_save_without_extensions(LatestRev)!=ITK_ok) PrintErrorStack();
			if(AOM_unlock(LatestRev)!=ITK_ok) PrintErrorStack();
			if(AOM_refresh(LatestRev,1)!=ITK_ok) PrintErrorStack();
			if(AOM_refresh(objTag,1)!=ITK_ok) PrintErrorStack();
			printf("\n  NR;1 updated");fflush(stdout);
			*/

			if(GRM_list_secondary_objects_only(LatestRev,relation_type,&cnt,&attachments)!=ITK_ok) PrintErrorStack();
			printf("\n Attached Datasets2: %d ",cnt);fflush(stdout);

			for(ij=0;ij<cnt;ij++)
			{
				dataset = attachments[ij];
				if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok) PrintErrorStack();
				printf("\n\n Dataset ObjectClassType :%s ",ObjectClassType);fflush(stdout);

				if (strcmp(ObjectClassType,"Design Revision Master")==0 || strcmp(ObjectClassType,"T5_SparKitRevisionMaster")==0)//T5_SparKitRevisionMaster
				{
					if (AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok) PrintErrorStack();
					printf("\n\n Revision Master Name :%s ",ObjectName);fflush(stdout);
					oojname=strtok(ObjectName,"/");
					strcat(oojname,"/");
					strcat(oojname,"NR;1");
					printf("\n\n Name of Revision Master:%s ",oojname);fflush(stdout);

					if(POM_attr_id_of_attr("object_name", "Form", &form_attr_id)!=ITK_ok) PrintErrorStack();

					if(AOM_lock(dataset));
					if(POM_set_attr_string(1, &dataset, form_attr_id,oojname)!=ITK_ok) PrintErrorStack();
					if(AOM_save_without_extensions(dataset)!=ITK_ok) PrintErrorStack();
					if(AOM_unlock(dataset)!=ITK_ok) PrintErrorStack();
					break;
				}
			}
			//if (RELSTAT_create_release_status("ERC Review",&status_rel)!=ITK_ok) PrintErrorStack();
			//if(RELSTAT_add_release_status(status_rel,1,&LatestRev,retain)!=ITK_ok) PrintErrorStack();
		}

	}
	printf("\n Design--METHOD_ppost_action_type---save_method_Design_3--End"); fflush(stdout);

	return error_code;
}

//Added by kalpesh(23_aug_2018)[Modified on 14_aug2019]

extern DLLAPI int  save_method_ee_part(METHOD_message_t *msg, va_list args)
{
	int error_code			= ITK_ok;
	tag_t objTag			= va_arg(args, tag_t);
	tag_t objTypeTag,item_tag = NULLTAG;
	//char   type_name[TCTYPE_name_size_c+1];
	char *desid				= NULL;
	char *type_name				= NULL;
	char *Desc				= NULL;
	char *NewDesc			= NULL;
	char *DerRoleNme		= NULL;
	char *DerRoleNme1		= NULL;
	char *NewDescription	= NULL;
	tag_t rev				= NULLTAG;
	char *objname			= NULL;

	tag_t*   resultTags		= NULLTAG;
	char *DrwName           = NULL;
	char *DrwName1          = NULL;
	char *parent_name       = NULL;
	char *group_name        = NULL;
	char *Role_name         = NULL;
	char *Grp_name          = NULL;
	char *Desc_obj2         = NULL;
	char *item_rev_id       = NULL;
	char *currpro           = NULL;
	tag_t attr_id ;
	int cnt=0;

	tag_t	*attachments    = NULLTAG;
	int		ij				=0;
	int		jk				=0;
	int		jkl				=0;
	int		Rolflag			=0;
	int		dsflag			=0;
	char
	*qry_entries[2]						= {"Name","Type"},
	*qry_values[2]						= {"*","CMI2Drawing"};
	int index,resultCount=0,j=0;
	char		*ObjectClassType        = NULL;
	char		*ObjectName             = NULL;
	char		*desi_grp               = NULL;
	char*		oojname = NULL;
	tag_t		form_attr_id ;
	tag_t		relation_type            = NULLTAG;
	tag_t		DesRolTag                = NULLTAG;
	tag_t		Currproj                 = NULLTAG;
	tag_t		GroupMem                 = NULLTAG;
	tag_t		Roletag                  = NULLTAG;
	tag_t		grptag                                                                                                                   = NULLTAG;
	tag_t		projobj;
	tag_t		dataset                = NULLTAG;
	tag_t		ActGm                  = NULLTAG;
	tag_t		ActGm1                 = NULLTAG;
	tag_t		status_rel             = NULLTAG;
	tag_t		projid                 = NULLTAG;
	tag_t		tagItem=NULLTAG;
	logical		checkout				= 0;
	logical		checkoutp				= 0;
	logical		retain					= 0;
	logical    promem                   = 0;

	char		*ee_weight				= NULL;
	char		*ee_desc				= NULL;
	char		*ee_keyword				= NULL;
	char		*ee_ecutype				= NULL;
	char		*ee_AppforEOL			= NULL;
	char		*ee_EPreadable			= NULL;
	char		*ee_swPartType			= NULL;

	tag_t		reln_type				= NULLTAG;
	tag_t		*secondary_objects		= NULLTAG;
	char		*username;
	tag_t		user_tag				=NULLTAG;
	const char		reason;
	const char		reason1;
	const char		change_id;
	const char		change_id1;
	const char		dir_name;
	const char		dir_name1;
	char			*ObjProject			= NULL;
	char			*dst_name			= NULL;
	char			*objPartType		= NULL;
	char			*object_typeDS		= NULL;

	char type_name2[TCTYPE_name_size_c+1];
	double objWeightVal ;
	double roundedWtVal ;
	char wgtstr[100];
	//1.25
	tag_t   qryTag     = NULLTAG;
	int     n_entry    = 1;
	char    *qry_entry[1]  = {"SYSCD"};
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	int     rsltCount      =  0;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char       *DesgTyp            = NULL;
	char       *info1   = NULL;
	char       *MPart_Desg    = NULL;
	char       *Part_DegGrp   = NULL;
	char       *Part_prj             = NULL;
	char       *DesgNo             = NULL;
	char       *sDesgNoG        = NULL;
	char       *sDesgNoT         = NULL;
	char       *sDesgNoVC      = NULL;
	char       *sDesgNoV        = NULL;
	char       *sDesgNoVCCR = NULL;
	char       *PrtProj               = NULL;
	char       *info2   = NULL;
	char       *PrtDR  = NULL;
	char       *sDesgNoD        = NULL;
	char       *Part_Desg        = NULL;
	char       *Part_Proj          = NULL;
	char       *Proj_typ                            = NULL;
	tag_t     Project_t                             = NULLTAG;
	tag_t     ObjTypProj         = NULLTAG;
	char   type_Proj[TCTYPE_name_size_c+1];
	//1.25
	//char **val=NULL;
	                //Amol
	tag_t TagQryContObjSite = NULLTAG;
	//tag_t *cntr_objects = NULL;
	char   *desidForTRL=NULL;
	char   *sLastThreeChar=NULL;
	char   *NewIDTRL=NULL;
	int CntrCount = 0;
	int           n_Input = 2;

	char   *RepalcedID=NULL;
	char       *DesgTypTRL     = NULL;
	//Amol

	int iTemp=0;

	int desclength = 0,index1=0;
	int desccnt = 0,n_entries=2;
	int c_attchs = 0,p=0;
	tag_t                                     primary               = NULLTAG;
	tag_t latest_datas=NULLTAG;
	tag_t                                     objTypeTagDi         = NULLTAG;
	//tag_t                                     latest_rev         = NULLTAG;

	char *st5_EE_PartType = NULL;
	char *st5_PartStatus = NULL;


	tag_t query = NULLTAG, *cntr_objects = NULL;
	//int n_found = 0;
	char *value=NULL;
	char *value_desc=NULL;
	char *eepartid=NULL;
	//	char *sSwPrtTyp=NULL;

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
	POM_get_user(&username,&user_tag);
	printf("\n save_method_ee_part:part type is = %s", type_name);
	if(strcmp(type_name,"T5_EE_PartRevision")==0)
	 {
		st5_EE_PartType = NULL;
		st5_PartStatus = NULL;
		ITK_CALL( AOM_ask_value_string(objTag,"t5_EE_PartType",&st5_EE_PartType));//D
		ITK_CALL( AOM_ask_value_string(objTag,"t5_PartStatus",&st5_PartStatus));//NA

		printf("\n save_method_ee_part:st5_EE_PartType: [%s] st5_PartStatus : [%s]",st5_EE_PartType,st5_PartStatus);fflush(stdout);
		TC_write_syslog("\n save_method_ee_part:st5_EE_PartType : [%s] st5_PartStatus : [%s]",st5_EE_PartType,st5_PartStatus);fflush(stdout);

		if ( tc_strcmp ( st5_PartStatus, "NA" ) == 0 )
		{
			if ( tc_strcmp ( st5_EE_PartType, "D" ) == 0 )
			{
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, "Unable to create part, Enter Valid DR/AR status");
				printf("\n save_method_ee_part:st5_EE_PartType, D Unable to create part, Enter Valid DR/AR status");fflush(stdout);
				TC_write_syslog("\n save_method_ee_part:st5_EE_PartType, D Unable to create part, Enter Valid DR/AR status");fflush(stdout);
				return ITK_err;
			}
		}
		error_code = AOM_UIF_ask_value(objTag, "t5_DesignGrp", &value);
		//printf("\n save_method_ee_part:Design group:%s ", value);

        ITK_CALL( AOM_ask_value_string(objTag,"item_id",&eepartid));
		//ITK_CALL( AOM_ask_value_string(objTag,"t5_SwPartType",&sSwPrtTyp));

		if (tc_strstr(eepartid, "G") == NULL )
		{
			//if(tc_strcmp(value, "16") != 0)
			if(tc_strcmp(value, "16") != 0 && tc_strcmp(value, "0E") != 0 && tc_strcmp(value, "SD") != 0) //enabling 0E design group for EE part creation on TZ 1.85
			{
				printf("\n save_method_ee_part:Unable to create part, design group must be 16/0E/SD  ");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, "Unable to create part, design group must be 16/0E/SD");
				return ITK_err;
			}

			error_code = AOM_UIF_ask_value(objTag, "object_desc", &value_desc);
			if(tc_strcmp(value_desc, "") == 0 || tc_strlen(value_desc) == 0)
			{
				printf("\n save_method_ee_part:Please provide description...!! ");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, "Unable to create part, description should be filled.");
				return ITK_err;
			}
			else
			{
				printf("\n save_method_ee_part:Description of part is filled(Non-Empty), hence EE part is created. ");fflush(stdout);
			}
		}

		printf("\n save_method_ee_part:EE revison Session user %s  ",username);fflush(stdout);
		char *projcodeList=NULL;
		char *projcode=NULL;
		tag_t   projobj1;
		if( AOM_ask_value_string(objTag,"project_ids",&projcodeList)!=ITK_ok) PrintErrorStack();
		if( AOM_ask_value_string(objTag,"t5_ProjectCode",&projcode)!=ITK_ok) PrintErrorStack();
		printf("\n save_method_ee_part:Project : <%s> ProjectList : <%s> %d ",projcode,projcodeList,strlen(projcodeList));fflush(stdout);
		if(strcmp(projcodeList,"")==0 || strlen(projcodeList) < 4) //project_list
		{
			if(strcmp(projcode,"")==0) //project_list
			{
				printf("\n save_method_ee_part:Project is  NULL  ");fflush(stdout);
			}
			else
			{
				printf("\n save_method_ee_part:Project from Object in else : %s ",projcode);fflush(stdout);

				if (PROJ_find(projcode,&projobj1) !=ITK_ok) PrintErrorStack();

				if(projobj1)
				{
	//				printf("\nTCDCGetting Master Object for Project ");fflush(stdout);
	//				if (ITEM_ask_item_of_rev( objTag,&objMasterTag)!=ITK_ok) PrintErrorStack();
	//				printf("\nTCDCAfter Master Object for Project ");fflush(stdout);
					if (PROJ_assign_objects(1 ,&projobj1 ,1 ,&objTag )!=ITK_ok) PrintErrorStack();
					printf("\n  save_method_ee_part:Assigned to Project ");fflush(stdout);
				}
				else
				{
					printf("\n save_method_ee_part:Project not found ");fflush(stdout);
				}
			}
		}
		else
		{
			printf("\n save_method_ee_part:Projectlist already assigned Project : <%s> ProjectList : <%s> ",projcode,projcodeList);fflush(stdout);
		}
	    //1.25 t5_PartType

	     if (AOM_ask_value_string(objTag,"item_revision_id",&Desc_obj2)!=ITK_ok) PrintErrorStack();
	     printf("\n  save_method_ee_part:Desc_obj2  = [%s] ", Desc_obj2);fflush(stdout);

	     if(POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id)!=ITK_ok) PrintErrorStack();

	     if(strcmp(Desc_obj2,"NR;1")==0 )
	     {
	        //if(AOM_lock(objTag)!=ITK_ok) PrintErrorStack();
	        //printf("\n  save_method_ee_part:Before Modification Description for NR;1 ");
			fflush(stdout);
	        //if( AOM_set_value_string(objTag,"t5_DocRemarks","NEW RELEASE")!=ITK_ok) PrintErrorStack();
	        //printf("\n  save_method_ee_part:After Modification Description for NR;1 ");fflush(stdout);
	        //if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
	        //if(AOM_unlock(objTag)!=ITK_ok) PrintErrorStack();
	        //if(AOM_refresh(objTag,1)!=ITK_ok) PrintErrorStack();
	     }

	     if(strcmp(Desc_obj2,"NR")==0 )
	     {
	          //if(AOM_lock(objTag)!=ITK_ok) PrintErrorStack();
	          //printf("\n save_method_ee_part:Before Modification Description ");
			  fflush(stdout);
	          //if( AOM_set_value_string(objTag,"t5_DocRemarks","NEW RELEASE")!=ITK_ok) PrintErrorStack();
	          //printf("\n save_method_ee_part:After Modification Description ");fflush(stdout);
	          //if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
	          //if(AOM_unlock(objTag)!=ITK_ok) PrintErrorStack();
	          //if(AOM_refresh(objTag,1)!=ITK_ok) PrintErrorStack();

	          printf("\n save_method_ee_part:A--inside NR check ");fflush(stdout);
	          if(AOM_lock(objTag));
	          if(POM_set_attr_string(1,&objTag,attr_id,"NR;1")) PrintErrorStack();
	          if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
	          if(AOM_unlock(objTag)!=ITK_ok) PrintErrorStack();
	          printf("\n save_method_ee_part:NR;1 updated ");fflush(stdout);

	          if(GRM_list_secondary_objects_only(objTag,relation_type,&cnt,&attachments)!=ITK_ok) PrintErrorStack();
	          printf("\n save_method_ee_part:Attached Datasets2: %d ",cnt);fflush(stdout);

	          for(ij=0;ij<cnt;ij++)
	          {
	              dataset = attachments[ij];
	              if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok) PrintErrorStack();
	              printf("\n save_method_ee_part:Dataset ObjectClassType :%s ",ObjectClassType);fflush(stdout);

	              if (strcmp(ObjectClassType,"T5_PeAsmRevisionMaster")==0)
	              {
	                   if (AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok) PrintErrorStack();
	                   printf("\n save_method_ee_part:Revision Master Name :%s ",ObjectName);fflush(stdout);
	                   oojname=strtok(ObjectName,"/");
	                   strcat(oojname,"/");
	                   strcat(oojname,"NR;1");
	                   printf("\n save_method_ee_part:Name of Revision Master:%s ",oojname);fflush(stdout);

	                   if(POM_attr_id_of_attr("object_name", "Form", &form_attr_id)!=ITK_ok) PrintErrorStack();

	                   if(AOM_lock(dataset));
	                   if(POM_set_attr_string(1, &dataset, form_attr_id,oojname)!=ITK_ok) PrintErrorStack();
	                   if(AOM_save_without_extensions(dataset)!=ITK_ok) PrintErrorStack();
	                   if(AOM_unlock(dataset)!=ITK_ok) PrintErrorStack();
	                   break;
	              }
	          }
	          if (RELSTAT_create_release_status("ERC Review",&status_rel)!=ITK_ok) PrintErrorStack();
	          if(RELSTAT_add_release_status(status_rel,1,&objTag,retain)!=ITK_ok) PrintErrorStack();
	     }

	     if( AOM_ask_value_string(objTag,"item_id",&desid)!=ITK_ok) PrintErrorStack();
	     if( AOM_ask_value_string(objTag,"object_desc",&Desc)!=ITK_ok) PrintErrorStack();

	     if(strcmp(Desc,"")!=0)
	     {
			desclength = strlen(Desc);
			for(desccnt=0;desccnt<desclength;desccnt++)
			{
				if(Desc[desccnt]=='\n')
				                Desc[desccnt] =' ';

				if(Desc[desccnt]=='`')
				                Desc[desccnt] =' ';

				if(Desc[desccnt]=='~')
				                Desc[desccnt] =' ';

				if(Desc[desccnt]=='|')
				                Desc[desccnt] =' ';

				if(Desc[desccnt]=='$')
				                Desc[desccnt] =' ';

				if(Desc[desccnt]=='#')
				                Desc[desccnt] =' ';

				if(Desc[desccnt]=='@')
				                Desc[desccnt] =' ';

				if(Desc[desccnt]=='^')
				                Desc[desccnt] =' ';

				if(Desc[desccnt]=='!')
				                Desc[desccnt] =' ';
				printf("\n save_method_ee_part:[%c] ",Desc[desccnt]);fflush(stdout);
			}
			//val=(char **)MEM_alloc(sizeof(char **));
			NewDesc = (char *)MEM_alloc (desclength * sizeof(char));
			strcpy(NewDesc,Desc);

			printf("\n save_method_ee_part:NewDesc[%s]!!!!!!!!!!!!!!!!!!! ", NewDesc);fflush(stdout);

			if(NewDesc)
			{
				////AOM_lock(objTag);
				//AOM_refresh(objTag, TRUE);
				if(AOM_set_value_string(objTag,"object_desc",NewDesc)!=ITK_ok) PrintErrorStack();
				if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
				//AOM_refresh(objTag,FALSE);
				////AOM_unlock(objTag);
				if( AOM_ask_value_string(objTag,"object_desc",&NewDescription)!=ITK_ok) PrintErrorStack();
				printf("\n save_method_ee_part::NewDescription[%s]!!!!!!!!!!!!!!!!!!! ", NewDescription);fflush(stdout);
			}
		}
        //}
	}
    return error_code;
}

//16_sept19(EE Parttype update)
extern DLLAPI int ee_part_post(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;
	tag_t		objTag				= va_arg(args, tag_t);

	char		*ee_parttype		= NULL;
	char		*type_name		= NULL;
	//char		type_name[TCTYPE_name_size_c+1];
	tag_t		objTypeTag			= NULLTAG;

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
	printf("\n ee_part_post:Part type is:%s", type_name);
	if(strcmp(type_name,"T5_EE_PartRevision")==0)
	{
		error_code = AOM_UIF_ask_value(objTag, "t5_EE_PartType", &ee_parttype);
		printf("\n ee_part_post:EE Part Type:%s ", ee_parttype);

		if(AOM_lock(objTag)!=ITK_ok) PrintErrorStack();
		printf("\n ee_part_post:Before setting EE Part Type ");fflush(stdout);
		if( AOM_set_value_string(objTag,"t5_PartType",ee_parttype)!=ITK_ok) PrintErrorStack();
		printf("\n ee_part_post:After setting EE Part Type ");fflush(stdout);
		if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
		if(AOM_unlock(objTag)!=ITK_ok) PrintErrorStack();
		if(AOM_refresh(objTag,1)!=ITK_ok) PrintErrorStack();
	}
	return error_code;
}
//End(kalpesh)

extern DLLAPI int  save_Post_DesRev(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	tag_t objTypeTag;
	//char   type_name[TCTYPE_name_size_c+1];
	tag_t objTag = va_arg(args, tag_t);
	char *type_name	=	NULL;

	char	*grpName	= NULL;
	tag_t userSession = NULLTAG;
	tag_t 	VOD_relation_type =NULLTAG;
	int vodcount =0;
	tag_t	*VODObjects =NULLTAG;
	tag_t	VODObject = NULLTAG;
	char 	*VOD_item_rev_id =NULL;
	char 	*VOD_latest_item_rev_id =NULL;
	tag_t 	master= NULLTAG;
	tag_t 	veh_latest_rev_tag = NULLTAG;
	tag_t	vodrel_tag = NULLTAG;
	tag_t	new_relation = NULLTAG;
	int p =0;
	//Declaration for setting part family as parent of keyword from classification module
	int			Key_entries			= 2;
	int			Key_found			= 0;
	int			key					= 0;
	char *parentKeyWordName = NULL;
	char *ParentkeyWordId = NULL;
	char *DgnGrp				= NULL;
	char *qryKey_entries[2] = {"Name","ext_1"};
	char **Keyqry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t		queryKey			= NULLTAG;
	 tag_t		*Keycntr_objects	= NULLTAG;
	 tag_t		parentKeyWord=NULLTAG;
	//Declaration for setting part family as parent of keyword from classification module

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();

	CE_current_user_session_tag(&userSession);
	AOM_ask_value_string(userSession,"group_name",&grpName);
	printf("\n save_Post_DesRev--grpName====>[%s]", grpName);fflush(stdout);

	if(tc_strcmp(type_name,"T5_PeDesignRevision")==0)
	{
		printf("\n save_Post_DesRev--IT IS PE PART OBJECT HENCE EXIT!!! ***save_Post_DesRev***");fflush(stdout);
		return error_code;
	}
	if(strcmp(type_name,"Design Revision")==0)
	{
		char   *sPartType1	 =NULL;
		char   *sCatName	 =NULL;
		char   *ModName	 =NULL;
		char   *VendorPart	 =NULL;
		tag_t   qryVendor		= NULLTAG;
		char **qry_valuesV = (char **) MEM_alloc(10 * sizeof(char *));
		char *qry_entriesV[1] = {"ID"};
		int resultCountV=0;
		tag_t *qry_cntrlobjV= NULLTAG;
		char* Vid =	NULL;
		char* CurID = NULL;
		char* CurRev = NULL;
		char* Vname = NULL;
		char *VenID = (char *) MEM_alloc(32);
		char* desid=NULL;

		if( AOM_ask_value_string(objTag,"item_id",&desid)!=ITK_ok) PrintErrorStack();
		printf("\n save_Post_DesRev--IDDDD1==%s",desid);fflush(stdout);

		//D9Y01 A9Z01 CompCodeSet
		if(tc_strstr(desid,"D9Y01")!=NULL)
		{
			printf("\n save_Post_DesRev--IDDDD2==%s",desid);fflush(stdout);
			if(AOM_lock(objTag)!=ITK_ok) PrintErrorStack();
			if(AOM_set_value_string(objTag,"t5_ColourInd","Y")!=ITK_ok) PrintErrorStack();
			if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
			//if(AOM_unlock(objTag)!=ITK_ok) PrintErrorStack();

			//if(AOM_lock(objTag)!=ITK_ok) PrintErrorStack();
			if(AOM_set_value_string(objTag,"t5_PrtCatCode","BODY_SHELL")!=ITK_ok) PrintErrorStack();
			if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
			if(AOM_unlock(objTag)!=ITK_ok) PrintErrorStack();
			printf("\n save_Post_DesRev--IDDDD2 After ");fflush(stdout);
		}
		else if(tc_strstr(desid,"A9Z01")!=NULL)
		{
			printf("\n save_Post_DesRev--IDDDD3==%s",desid);fflush(stdout);
			if(AOM_lock(objTag)!=ITK_ok) PrintErrorStack();
			if(AOM_set_value_string(objTag,"t5_ColourInd","Y")!=ITK_ok) PrintErrorStack();
			if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
			//if(AOM_unlock(objTag)!=ITK_ok) PrintErrorStack();

			//if(AOM_lock(objTag)!=ITK_ok) PrintErrorStack();
			if(AOM_set_value_string(objTag,"t5_PrtCatCode","LOADBODY_SHELL")!=ITK_ok) PrintErrorStack();
			if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
			if(AOM_unlock(objTag)!=ITK_ok) PrintErrorStack();
			printf("\n save_Post_DesRev--IDDDD3 After ");fflush(stdout);
		}
		// END D9Y01 A9Z01

		if( AOM_ask_value_string(objTag,"t5_PartType",&sPartType1)!=ITK_ok) PrintErrorStack();
		if( AOM_ask_value_string(objTag,"t5_CategoryName",&sCatName)!=ITK_ok) PrintErrorStack();

		printf("\n save_Post_DesRev--sPartType1: [%s] ",sPartType1);fflush(stdout);

		if((tc_strcmp(sPartType1,"A")==0 || tc_strcmp(sPartType1,"C")==0) || tc_strcmp(sPartType1,"SA")==0 || tc_strcmp(sPartType1,"SP")==0)
		{
			printf("\n	save_Post_DesRev--Keyword description :%s",sCatName);fflush(stdout);
			if(tc_strcmp(sCatName,"")==0)
			{
				printf("\n save_Post_DesRev--Keyword description is NULL ");fflush(stdout);
			}
			else
			{
				printf("\n save_Post_DesRev--Before setting Description ");fflush(stdout);
				//if(AOM_lock(objTag)!=ITK_ok) PrintErrorStack();
				if(AOM_refresh(objTag,TRUE)!=ITK_ok) PrintErrorStack();
				if( AOM_set_value_string(objTag,"object_desc",sCatName)!=ITK_ok) PrintErrorStack();
				printf("\n save_Post_DesRev--After setting Description ");fflush(stdout);
				if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
				//if(AOM_unlock(objTag)!=ITK_ok) PrintErrorStack();
				if(AOM_refresh(objTag,FALSE)!=ITK_ok) PrintErrorStack();
				//setting part family as parent of keyword from classification module
				printf("\n\nThe design revision [%s] is ERC Working having keyword description as %s\n\n", desid,sCatName);
				if( AOM_ask_value_string(objTag,"t5_DesignGrp",&DgnGrp)!=ITK_ok) PrintErrorStack();
				printf("\n --->> DgnGrp = %s",DgnGrp);
				Keyqry_values[0] = sCatName;
				Keyqry_values[1] = DgnGrp;

				ITK_CALL(QRY_find2("KeyWordQryforDR", &queryKey));
				if (queryKey)
				{
					ITK_CALL(QRY_execute(queryKey, Key_entries, qryKey_entries, Keyqry_values, &Key_found, &Keycntr_objects));
				}
				printf("\n Keyword Key_found:%d", Key_found);fflush(stdout);


				if(Key_found>0)
				{
					printf("\n keyword found  ");fflush(stdout);
					for (key = 0; key < Key_found; key++)
					{
						if(ICS_ask_parent(Keycntr_objects[key],&parentKeyWord) != ITK_ok);
						ITK_CALL(ICS_ask_id_name(parentKeyWord,&ParentkeyWordId,&parentKeyWordName));
						printf("\n For keyword  %s Parent keyword Id is %s and Parentkeyword name  is %s", sCatName,ParentkeyWordId,parentKeyWordName);fflush(stdout);
						printf("\n Setting the Part Family as ParentKeyWordName");fflush(stdout);
						if(AOM_lock(objTag)!=ITK_ok) PrintErrorStack();
						AOM_set_value_string ( objTag, "t5_PartFamily", parentKeyWordName ) ;
						if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
						if(AOM_unlock(objTag)!=ITK_ok) PrintErrorStack();
						//if(AOM_refresh(objTag,FALSE)!=ITK_ok) PrintErrorStack();
					}
				}
				//setting part family as parent of keyword from classification module
			}
		}
		else if(tc_strcmp(sPartType1,"M")==0) //Added by Rohit for Module Name to be stamped on Description as well Starts.
		{
			if( AOM_ask_value_string(objTag,"t5_ModuleName",&ModName)!=ITK_ok) PrintErrorStack();
			printf("\n save_Post_DesRev--Module Name=[%s] ",ModName); fflush(stdout);

			if(tc_strcmp(ModName,"")==0)
			{
				printf("\n save_Post_DesRev--Module Name is NULL ");fflush(stdout);
			}
			else
			{
				printf("\n Before setting Module Name as Description ");fflush(stdout);
				//if(AOM_lock(objTag)!=ITK_ok) PrintErrorStack();
				if(AOM_refresh(objTag,TRUE)!=ITK_ok) PrintErrorStack();
				if(AOM_set_value_string(objTag,"object_desc",ModName)!=ITK_ok) PrintErrorStack();
				printf("\n After setting Module Name as Description ");fflush(stdout);
				if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
				//if(AOM_unlock(objTag)!=ITK_ok) PrintErrorStack();
				if(AOM_refresh(objTag,FALSE)!=ITK_ok) PrintErrorStack();
			}
		}
		//Added by Rohit for Module Name to be stamped on Description as well Starts.

		// iman save action for vehicle to check VOD latest added by Suryansh Mishra--------------
				printf("\n save_Post_DesRev--sPartType1: [%s] grpName: [%s] ",sPartType1,grpName); fflush(stdout);
		if(tc_strcmp(grpName,"ERC_Designers_Group")==0)
		{
			if(tc_strcmp(sPartType1,"V")==0)
			{
				GRM_find_relation_type("T5_HasVOD",&VOD_relation_type);
				GRM_list_secondary_objects_only(objTag, VOD_relation_type, &vodcount, &VODObjects);
				printf("\n save_Post_DesRev--vodcount: [%d] ",vodcount); fflush(stdout);

				if(vodcount>0)
				{
					for(p=0;p<vodcount;p++)
					{
						VODObject = VODObjects[p];
						AOM_ask_value_string(VODObject,"item_revision_id",&VOD_item_rev_id);

						ITEM_ask_item_of_rev(VODObject, &master);
						ITEM_ask_latest_rev(master,&veh_latest_rev_tag);

						AOM_ask_value_string(veh_latest_rev_tag,"item_revision_id",&VOD_latest_item_rev_id);

						if(tc_strcmp(VOD_item_rev_id,VOD_latest_item_rev_id)==0)
						{
							printf("\n save_Post_DesRev--latest VOD is alredy attached with vehicle\n");fflush(stdout);
						}
						else
						{
							if(GRM_find_relation(objTag, VODObject, VOD_relation_type, &vodrel_tag)!=ITK_ok) PrintErrorStack();

							if(GRM_delete_relation(vodrel_tag)!=ITK_ok) PrintErrorStack();
							//printf("\n Step 1 --->");fflush(stdout);

							if(AOM_refresh(vodrel_tag, TRUE)!=ITK_ok) PrintErrorStack();
							//printf("\n Step 1 --->");fflush(stdout);

							if(AOM_save_without_extensions(vodrel_tag)!=ITK_ok) PrintErrorStack();
							if(AOM_refresh(vodrel_tag,FALSE)!=ITK_ok) PrintErrorStack();
							//printf("\n Step 2 --->");fflush(stdout);

							if(veh_latest_rev_tag !=NULLTAG)
							{
								printf("\n save_Post_DesRev--TMLSTD_CreateRelation_ISDOC:Under creating relation!!");fflush(stdout);
								if(GRM_create_relation(objTag, veh_latest_rev_tag, VOD_relation_type, NULLTAG, &new_relation)!=ITK_ok) PrintErrorStack();
								if(GRM_save_relation(new_relation)!=ITK_ok) PrintErrorStack();
								printf("\n save_Post_DesRev--TMLSTD_CreateRelation_ISDOC::Relation Created !!");fflush(stdout);
							}
						}
					}
				}
			}
			//added by Vinayak.B
			if(AOM_ask_value_string(objTag,"t5_RefPartNumber",&VendorPart)!=ITK_ok) PrintErrorStack();
			printf("\n save_Post_DesRev--VendorPart : [%s]",VendorPart);fflush(stdout);
			if(VendorPart!=NULL)
			{
				if(QRY_find2("VendorParts", &qryVendor)!=ITK_ok)PrintErrorStack();
				if (qryVendor)
				{
					printf("\n save_Post_DesRev--Query Found : VendorParts");fflush(stdout);

					qry_valuesV[0]=VendorPart;
					if(QRY_execute(qryVendor,1, qry_entriesV, qry_valuesV, &resultCountV, &qry_cntrlobjV)!=ITK_ok)PrintErrorStack();
				}
				else
				{
					printf("\n save_Post_DesRev--Query NOT Found : VendorParts");fflush(stdout);
				}
				if(resultCountV>0)
				{
					if(AOM_ask_value_string(qry_cntrlobjV[0],"vendor_id",&Vid)!=ITK_ok) PrintErrorStack();
					if(AOM_ask_value_string(qry_cntrlobjV[0],"vendor_name",&Vname)!=ITK_ok) PrintErrorStack();
					printf(" \n save_Post_DesRev--Vid:[%s]:Vname:[%s]",Vid,Vname); fflush(stdout);

					if(AOM_lock(objTag)!=ITK_ok) PrintErrorStack();
					if(AOM_set_value_string(objTag,"t5_VendorID",Vid)!=ITK_ok) PrintErrorStack();
					if(AOM_set_value_string(objTag,"t5_VendorName",Vname)!=ITK_ok) PrintErrorStack();
					if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
					if(AOM_refresh(objTag, TRUE)!=ITK_ok) PrintErrorStack();
					printf("\n save_Post_DesRev--Vendor details stamped on TML Part\n");fflush(stdout);

					if(AOM_ask_value_string(objTag,"current_id",&CurID)!=ITK_ok) PrintErrorStack();
					if(AOM_ask_value_string(objTag,"current_revision_id",&CurRev)!=ITK_ok) PrintErrorStack();
					//strcpy(VenID,CurID);
					//strcat(VenID,"/");
					//strcat(VenID,CurRev);
					//printf(" \n save_Post_DesRev--VenID:[%s]",VenID); fflush(stdout);

					AOM_lock(qry_cntrlobjV[0]);
					AOM_set_value_string(qry_cntrlobjV[0],"gov_classification",CurID);
					AOM_save_without_extensions(qry_cntrlobjV[0]);
					AOM_refresh(qry_cntrlobjV[0], TRUE);
					printf("\n save_Post_DesRev--TML part number stamped on Vendor Part\n");fflush(stdout);
				}
			}
		}
	}

	printf("\n save_Post_DesRev--completed processing----\n"); fflush(stdout);
	return ITK_ok;
}

//Added by Amar TZ TCUA 1.76
int CheckParttypeSAandModuleAdderess(tag_t object,int* match)
{
	int ifail=ITK_ok;
	char *ModuleAddress=NULL;
	char *Part_No=NULL;
	char *ModuleAddressList=NULL;

	// Control Object
	tag_t   qryCntrlobj		= NULLTAG;
	tag_t*	list_cntrl_tags	= NULLTAG;

	char*	qry_entryCntrl[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
	char**	qry_valuesCntrl	= (char **) MEM_alloc(5 * sizeof(char *));

	int controlObjCount	= 0;
	int	entryCntrlobj = 3;
	int cntrlcnt=0;

	if(QRY_find2("Control Objects...", &qryCntrlobj));

	if (qryCntrlobj)
	{
		printf("\n CheckParttypeSAandModuleAdderess:Control Object Query Found  ");fflush(stdout);
		qry_valuesCntrl[0]="Iman_Save";
		qry_valuesCntrl[1]="ModuleAddress";
		qry_valuesCntrl[2]="0";

		if(QRY_execute(qryCntrlobj, entryCntrlobj, qry_entryCntrl, qry_valuesCntrl, &controlObjCount, &list_cntrl_tags));
	}
	else
	{
		printf("\n CheckParttypeSAandModuleAdderess:Control Object Query not Found for Iman_Save  ");fflush(stdout);
	}

	printf("\n CheckParttypeSAandModuleAdderess:controlObjCount for Iman_Save is ==> %d ",controlObjCount);fflush(stdout);

	if(controlObjCount>0)
	{
		for(cntrlcnt=0;cntrlcnt<controlObjCount;cntrlcnt++)
		{
			AOM_ask_value_string( list_cntrl_tags[cntrlcnt], "t5_Userinfo1", &ModuleAddressList);
			printf("\n CheckParttypeSAandModuleAdderess:ModuleAddressList: %s ",ModuleAddressList);fflush(stdout);

			//printf("\n CheckParttypeSAandModuleAdderess:Amar Inside CheckParttypeSAandModuleAdderess  ") ;fflush(stdout);
			char* t5_ModuleAddress;

			ITK_CALL(AOM_ask_value_string(object,"item_id",&Part_No));
			printf("\n CheckParttypeSAandModuleAdderess:Type of Part_No is [%s]  ",Part_No);fflush(stdout);

			ITK_CALL(AOM_ask_value_string(object,"t5_ModuleAddress",&t5_ModuleAddress));
			printf("\n CheckParttypeSAandModuleAdderess:Type of t5_ModuleAddress is [%s]  ",t5_ModuleAddress);fflush(stdout);

			ModuleAddress=(char*)MEM_alloc(6);
			//2196H9X0233001
			tc_strncpy(ModuleAddress,Part_No+4,5);

			printf("\n CheckParttypeSAandModuleAdderess:Part of ModuleAddress is [%s]  ",ModuleAddress);fflush(stdout);

			if(tc_strstr(ModuleAddressList,ModuleAddress)!= NULL)
			{
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err,"For This Module address Property Cannot modified..");
				return 1;
			}
		}
	}

	return ITK_ok;
}

//Added by Amar TZ TCUA 1.76
extern DLLAPI int  DesignGroup_Set_pre_action(METHOD_message_t *msg, va_list args)
{
	/** va_list for PROP_set_value_string_msg **/

	//printf("\n Amar Inside DesignGroup_Set_pre_action  ") ;fflush(stdout);

	int error_code = ITK_ok;
	tag_t  prop = va_arg(args, tag_t );
	char*  value = va_arg(args, char* );

	//printf("\n Amar value is %s ",value) ;fflush(stdout);

	tag_t  object = NULLTAG;
	tag_t  object_type = NULLTAG;
	//char   type_name[TCTYPE_name_size_c+1] = "";
	logical hasBypass=false;
	tag_t userSession=NULLTAG;
	char *project_name=NULL;
	char *type_name=NULL;
	char *role_name=NULL;
	char *P_type=NULL;
	char *release_status_list=NULL;
	char *DesignGrp=NULL;
	char* username = NULL;
	char *group_name1	= NULL;
	char *group_name	= NULL;
	tag_t user_tag=NULLTAG;
	tag_t GroupMem=NULLTAG;
	int* match;


	// Control Object
	tag_t   qryTagCntrlobj		= NULLTAG;
	tag_t*	list_of_cntrl_tags	= NULLTAG;

	char*	qry_entryCntrlformat[4] = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};
	char**	qry_valuesCntrlformat	= (char **) MEM_alloc(5 * sizeof(char *));

	int controlObjfound	= 0;
	int	n_entryCntrlobj = 4;

	if(QRY_find2("Control Objects...", &qryTagCntrlobj));

	if (qryTagCntrlobj)
	{
		printf("\n DesignGroup_Set_pre_action:Control Object Query Found  ");fflush(stdout);

		qry_valuesCntrlformat[0]="Iman_Save";
		qry_valuesCntrlformat[1]="DesignGrp";
		qry_valuesCntrlformat[2]="0";
		qry_valuesCntrlformat[3]="Live";

		if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
	}
	else
	{
		printf("\n DesignGroup_Set_pre_action:Control Object Query not Found for Iman_Save  ");fflush(stdout);
	}

	printf("\n DesignGroup_Set_pre_action:controlObjfound for Iman_Save is ==> %d ",controlObjfound);fflush(stdout);

	if(controlObjfound>0)
	{
		POM_get_user(&username,&user_tag);

		SA_ask_current_groupmember(&GroupMem);

		if(GroupMem !=NULLTAG)
		{
			if (AOM_ask_value_string(GroupMem,"object_name",&group_name1)!=ITK_ok) PrintErrorStack();
			printf("\ngroup_name session is  : %s ",group_name1);fflush(stdout);

			group_name=strtok(group_name1,"/");
			printf("\n Group_name session is  : %s ",group_name);fflush(stdout);
		}

		METHOD_PROP_MESSAGE_OBJECT(msg, object);
		ITK_CALL(TCTYPE_ask_object_type(object, &object_type));
		ITK_CALL(TCTYPE_ask_name2(object_type, &type_name));

		printf("\n DesignGroup_Set_pre_action:object type: %s - value: %s ", type_name, value);fflush(stdout);

		char *SupportUsername9 = NULL;
		tag_t SessionUser9_tag=NULLTAG;
		int     SupportFlag      =  0;

		SupportFlag=0;
		POM_get_user(&SupportUsername9,&SessionUser9_tag);
		if(SessionUser9_tag!=NULLTAG)
		{
			SupportFlag=0;
			SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
			printf("\n DesignGroup_Set_pre_action:SupportFlag.: %d",SupportFlag);fflush(stdout);
		}
		if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (tc_strcmp(username,"aplloader") !=0) && (SupportFlag==0) && (tc_strcmp(group_name, "PLM_Support_Group") != 0))
		{

			if(strcmp(type_name,"Design Revision")==0)
			{
				ITK_CALL(AOM_ask_value_string(object,"t5_PartType",&P_type));
				printf("\n DesignGroup_Set_pre_action:Type of P_type is [%s]  ",P_type);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(object,"t5_DesignGrp",&DesignGrp));
				printf("\n DesignGroup_Set_pre_action:Type of DesignGrp is [%s]  ",DesignGrp);fflush(stdout);

				if(strcmp(P_type,"SA")==0)
				{
					if(strcmp(value,DesignGrp)==0)
					{
						printf("\n  DesignGroup_Set_pre_action:Amar Allowed to modified..  ");fflush(stdout);
					}
					else
					{
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Updation of Desgin Group is not Allowed..");
						return 1;
					}
				}
				else if(strcmp(P_type,"M")==0)
				{
					CheckParttypeSAandModuleAdderess(object,match);
				}
			}
		}
	}
	return ITK_ok;
}
//End Amar

//Added by Amar TZ TCUA 1.76
extern DLLAPI int  ProjectCode_Set_pre_action(METHOD_message_t *msg, va_list args)
{
	/** va_list for PROP_set_value_string_msg **/

	//printf("\n Amar Inside ProjectCode_Set_pre_action  ") ;fflush(stdout);

	int error_code = ITK_ok;
	tag_t  prop = va_arg(args, tag_t );
	char*  value = va_arg(args, char* );

	//printf("\n Amar value is %s ",value) ;fflush(stdout);

	tag_t  object = NULLTAG;
	tag_t  object_type = NULLTAG;
	//char   type_name[TCTYPE_name_size_c+1] = "";
	char *P_type=NULL;
	char *type_name=NULL;
	char *ProjectCode=NULL;
	char* username = NULL;
	char *group_name1	= NULL;
	char *group_name	= NULL;
	tag_t user_tag=NULLTAG;
	tag_t GroupMem=NULLTAG;
	int *match;

	// Control Object
	tag_t   qryTagCntrlobj		= NULLTAG;
	tag_t*	list_of_cntrl_tags	= NULLTAG;

	char*	qry_entryCntrlformat[4] = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};
	char**	qry_valuesCntrlformat	= (char **) MEM_alloc(5 * sizeof(char *));

	int controlObjfound	= 0;
	int	n_entryCntrlobj = 4;

	if(QRY_find2("Control Objects...", &qryTagCntrlobj));

	if (qryTagCntrlobj)
	{
		printf("\n ProjectCode_Set_pre_action:Control Object Query Found  ");fflush(stdout);
		qry_valuesCntrlformat[0]="Iman_Save";
		qry_valuesCntrlformat[1]="ProjectCode";
		qry_valuesCntrlformat[2]="0";
		qry_valuesCntrlformat[3]="Live";

		if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
	}
	else
	{
		printf("\n ProjectCode_Set_pre_action:Control Object Query not Found for Iman_Save  ");fflush(stdout);
	}

	printf("\n ProjectCode_Set_pre_action:controlObjfound for Iman_Save is ==> %d ",controlObjfound);fflush(stdout);

	if(controlObjfound>0)
	{

		POM_get_user(&username,&user_tag);

		SA_ask_current_groupmember(&GroupMem);

		if(GroupMem !=NULLTAG)
		{
			if (AOM_ask_value_string(GroupMem,"object_name",&group_name1)!=ITK_ok) PrintErrorStack();
			printf("\n ProjectCode_Set_pre_action:group_name1 session is  : %s ",group_name1);fflush(stdout);

			group_name=strtok(group_name1,"/");
			printf("\n ProjectCode_Set_pre_action:Group_name session is  : %s ",group_name);fflush(stdout);
		}

		METHOD_PROP_MESSAGE_OBJECT(msg, object);
		ITK_CALL(TCTYPE_ask_object_type(object, &object_type));
		ITK_CALL(TCTYPE_ask_name2(object_type, &type_name));

		printf("\n ProjectCode_Set_pre_action:object type: %s - value: %s ", type_name, value);fflush(stdout);

		char *SupportUsername9 = NULL;
		tag_t SessionUser9_tag=NULLTAG;
		int     SupportFlag      =  0;

		SupportFlag=0;
		POM_get_user(&SupportUsername9,&SessionUser9_tag);
		if(SessionUser9_tag!=NULLTAG)
		{
			SupportFlag=0;
			SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
			printf("\n ProjectCode_Set_pre_action:SupportFlag.: %d",SupportFlag);fflush(stdout);
		}
		if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (tc_strcmp(username,"aplloader") !=0) && (SupportFlag==0) && (tc_strcmp(group_name, "PLM_Support_Group") != 0))
		{
			if(strcmp(type_name,"Design Revision")==0)
			{
				ITK_CALL(AOM_ask_value_string(object,"t5_PartType",&P_type));
				printf("\n ProjectCode_Set_pre_action:Type of P_type is [%s]  ",P_type);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(object,"t5_ProjectCode",&ProjectCode));
				printf("\n ProjectCode_Set_pre_action:Type of ProjectCode is [%s]  ",ProjectCode);fflush(stdout);

				if(strcmp(P_type,"SA")==0)
				{
					if(strcmp(value,ProjectCode)==0)
					{
						printf("\n ProjectCode_Set_pre_action:Amar Allowed to modified..  ");fflush(stdout);
					}
					else
					{
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Updation of Project Code is not Allowed..");
						return 1;
					}
				}
				else if(strcmp(P_type,"M")==0)
				{
					CheckParttypeSAandModuleAdderess(object,match);
				}
			}
		}
	}
	return ITK_ok;
}
//End Amar

extern DLLAPI int  save_method_durafit(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag,item_tag = NULLTAG;
	//char   type_name[TCTYPE_name_size_c+1];

	char* username = NULL;
	char* type_name = NULL;
	char* sDuraFitRefPart = NULL;
	char* sDuraFitModLvl = NULL;
	char* rlsstatus1 = NULL;
	char* ErrorString = NULL;
    tag_t user_tag=NULLTAG;
	int		n_tags_found	=	0;
	tag_t	*tags_found	=	NULLTAG;
	int		n_revtags_found	=	0;
	tag_t	*revtags_found	=	NULLTAG;
	int		count;
	int		NStatus=0;
	int		errordisplay=0;
	tag_t *status_list=NULLTAG;
	tag_t revstatus = NULLTAG;
	logical StatusFound=false;
	//char  name[WSO_name_size_c+1]    = {'\0'}; Commented for 14.3 upgradation
	char *	name	=	NULL;

	const char
        *attrs[1] = {"item_id"},
        *values[1]	= {"*"};


	const char
        *attrs2[1] = {"item_id"},
        *values2[1]	= {"*"};

	char    temp_parent_item_rev_id[10]= {'\0'};

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
	POM_get_user(&username,&user_tag);

	if(strcmp(type_name,"T5_DuraFitPartRevision")==0) //T5_DuraFitPartRevision
	{
		if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0))
		{
			if( AOM_ask_value_string(objTag,"t5_DuraFitRefPart",&sDuraFitRefPart)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(objTag,"t5_DuraFitModLvl",&sDuraFitModLvl)!=ITK_ok) PrintErrorStack();
			printf("\n save_method_durafits:DuraFitRefPart: [%s]",sDuraFitRefPart);fflush(stdout);
			printf("\n save_method_durafit:sDuraFitModLvl: [%s]",sDuraFitModLvl);fflush(stdout);

			values2[0] = sDuraFitRefPart;
			if(ITEM_find_items_by_key_attributes(1,attrs2, values2, &n_tags_found, &tags_found)!=ITK_ok) PrintErrorStack();
			printf("\n save_method_durafits:n_tags_found: [%d]",n_tags_found);fflush(stdout);
			if(n_tags_found>0)
			{
				printf("\n save_method_durafits:DuraFitRefPart: [%s] found!!",sDuraFitRefPart);fflush(stdout);
				tc_strcpy(temp_parent_item_rev_id,sDuraFitModLvl);
				tc_strcat(temp_parent_item_rev_id,"*");
				values[0] = sDuraFitRefPart;
				if(ITEM_find_item_revs_by_key_attributes(1,attrs, values, temp_parent_item_rev_id, &n_revtags_found, &revtags_found)!=ITK_ok) PrintErrorStack();
				printf("\n save_method_durafits:n_revtags_found: [%d]",n_revtags_found);fflush(stdout);
				if(n_revtags_found>0)
				{
					printf("\n save_method_durafits:sDuraFitModLvl: [%s] found!!",sDuraFitModLvl);fflush(stdout);
					WSOM_ask_release_status_list(revtags_found[0] ,&count,&status_list);
					if(count>0)
					{
						for(NStatus=0;NStatus<count;NStatus++)
						{
							RELSTAT_ask_release_status_type(status_list[NStatus],&name);
							printf("\n save_method_durafits:name==>[%s]  ",name);fflush(stdout);

							if(tc_strcmp(name,"T5_LcsReview")==0 || tc_strcmp(name,"T5_LcsWorking")==0)
							{
								printf("\n save_method_durafits:sDuraFitModLvl: [%s] is not ERC Released!!",sDuraFitModLvl);fflush(stdout);
								StatusFound = true;
							}
							if(tc_strcmp(name,"T5_LcsErcRlzd")==0)
							{
								StatusFound = false;
								errordisplay = 1;
							}
						}
						if(StatusFound==true && errordisplay==0)
						{
							printf("\n save_method_durafits:Given Mod level is not ERC Released!! ");fflush(stdout);
							ErrorString=(char *) MEM_alloc(250);
							printf("save_method_durafits:After mem alloc ");
							tc_strcpy (ErrorString, "Entered DuraFitReference Part:");
							strcat(ErrorString,sDuraFitRefPart);
							strcat(ErrorString," and Ref Mod level ");
							strcat(ErrorString,sDuraFitModLvl);
							strcat(ErrorString,"is not ERC Released!!. Please select other Refrence Part / Mod Level.");
							EMH_store_error_s1(EMH_severity_error,ITK_err,ErrorString);
							return ITK_err;
						}
					}
				}
				else
				{
					printf("\n save_method_durafits:sDuraFitModLvl: [%s] not found!!",sDuraFitModLvl);fflush(stdout);
					ErrorString=(char *) MEM_alloc(250);
					printf(" save_method_durafits:After mem alloc ");
					tc_strcpy(ErrorString,"Entered Mod Level :");
					strcat(ErrorString,sDuraFitModLvl);
					strcat(ErrorString,"for DuraFitReference Part :");
					strcat(ErrorString,sDuraFitRefPart);
					strcat (ErrorString, "is not available!!");
					strcat(ErrorString,". Please select other DuraFitReference Mod level");
					EMH_store_error_s1(EMH_severity_error,ITK_err,ErrorString);
					return ITK_err;
				}
			}
			else
			{
				printf("\n save_method_durafits:DuraFitRefPart: [%s] not found!!",sDuraFitRefPart);fflush(stdout);
				ErrorString=(char *) MEM_alloc(150);
				printf(" save_method_durafits:After mem alloc ");
				tc_strcpy(ErrorString,sDuraFitRefPart);
				strcat (ErrorString, ": Entered DuraFitReference Part is not available!!");
				strcat(ErrorString,". Please select other DuraFitReference Part");
				EMH_store_error_s1(EMH_severity_error,ITK_err,ErrorString);
				return ITK_err;
			}
		}
		MEM_free(tags_found);
		MEM_free(revtags_found);
		MEM_free(ErrorString);
	}
	return ITK_ok;
}
/*void  get_CtrlVal_APLPltLCS( char * Plt_Code ,char  Info1[40],char  Info2[40],char  Info3[40],char  Info4[40],char  Info5[40],char  Info6[40],char Info7[40],char Info8[40],char Info9[40],char Info10[40])
{
	 char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};
	 char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *LcsAplReview 			= NULL;
	 char *LcsAPLWrkg		= NULL;
	 char *LcsAplRlzd		= NULL;
	 char *LcsSTDWrkg			= NULL;
	 char *LcsStdRlzd		= NULL;
	 char *loc	= NULL;
	 char *UserLoc			= NULL;
	 char *ClosureRule		= NULL;
	 char *revRule	= NULL;
	 char *Info10ctrl		= NULL;
	 char *PlantOneChar		= NULL;

	 char* viewtocpy		= NULL;
	 int max_char_size = 80;
	 viewtocpy = (char *)MEM_alloc(max_char_size * sizeof(char));

	 if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found  ");fflush(stdout);
				qry_valuesCntrl1[0]="APLStateInf";
				qry_valuesCntrl1[1]=Plt_Code;
				qry_valuesCntrl1[2]="0";

				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found  ");fflush(stdout);
			}

			printf("\n control_number_found1 is : %d ",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &LcsAplReview);
				printf("\n LcsAplReview: %s ",LcsAplReview);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &LcsAPLWrkg);
				printf("\n LcsAPLWrkg: %s ",LcsAPLWrkg);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &LcsAplRlzd);
				printf("\n LcsAplRlzd: %s ",LcsAplRlzd);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo4", &LcsSTDWrkg);
				printf("\n LcsSTDWrkg: %s ",LcsSTDWrkg);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo5", &LcsStdRlzd);
				printf("\n LcsStdRlzd: %s ",LcsStdRlzd);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo6", &loc);
				printf("\n loc: %s ",loc);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo7", &UserLoc);
				printf("\n UserLoc: %s ",UserLoc);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &revRule);
				printf("\n revRule: %s ",revRule);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo9", &ClosureRule);
				printf("\n ClosureRule: %s ",ClosureRule);fflush(stdout);

				if(tc_strlen(LcsAplReview)>0)
				{
					tc_strcpy(Info1,LcsAplReview);
				}
				if(tc_strlen(LcsAPLWrkg)>0)
				{
					tc_strcpy(Info2,LcsAPLWrkg);
				}
				if(tc_strlen(LcsAplRlzd)>0)
				{
					tc_strcpy(Info3,LcsAplRlzd);
				}
				if(tc_strlen(LcsSTDWrkg)>0)
				{
					tc_strcpy(Info4,LcsSTDWrkg);
				}
				if(tc_strlen(LcsStdRlzd)>0)
				{
					tc_strcpy(Info5,LcsStdRlzd);
				}
				if(tc_strlen(loc)>0)
				{
					tc_strcpy(Info6,loc);
				}
				if(tc_strlen(UserLoc)>0)
				{
					tc_strcpy(Info7,UserLoc);
				}
				if(tc_strlen(revRule)>0)
				{
					tc_strcpy(Info8,revRule);
				}
				if(tc_strlen(ClosureRule)>0)
				{
					tc_strcpy(Info9,ClosureRule);
				}
				if(tc_strlen(PlantOneChar)>0)
				{
					tc_strcpy(Info10,PlantOneChar);
				}

			}
			else
			{
				tc_strcpy(Info1,"T5_LcsAplpReview");
				tc_strcpy(Info2,"T5_LcsAPLpWrkg");
				tc_strcpy(Info3,"T5_LcsAplpRlzd");
				tc_strcpy(Info4,"T5_LcsSTDpWrkg");
				tc_strcpy(Info5,"T5_LcsStdpRlzd");
				tc_strcpy(Info6,"PUNE");
				tc_strcpy(Info7,"STDP");
				tc_strcpy(Info8,"APLP Release and above");
				tc_strcpy(Info9,"BOMViewClosureRuleSTDP");
				tc_strcpy(Info10,"APLP");
			}
}*/
int SiteViseProjectValidationCheck(char *sProjectCode,char *FrstBarrel,char **OutputStr)
{
	int 	index				=	0;
	char *  SiteName			=	NULL;
	char*	sUsrInfo			=	NULL;
	tag_t   Cntl_obj_Qtag		=	NULLTAG;
	int     n_entry				=	1;
	char    *qry_sys_entry[1]	=	{"SYSCD"};
	char    **qry_sys_values    =  (char **) MEM_alloc(10 * sizeof(char *));
	int		IntCntlObj			=	0;
	int		IsValidFlag			=	0;
	tag_t   *CntrlObject_Tag    =	NULLTAG;

	*OutputStr=(char *) MEM_alloc(250);

	strcpy(*OutputStr,"");
	printf("\n Inside SiteViseProjectValidationCheck: [%s]------------------------\n",FrstBarrel);fflush(stdout);

 	if(QRY_find2("ControlObjects", &Cntl_obj_Qtag));
	if (Cntl_obj_Qtag)
	{
		printf("\n SiteViseProjectValidationCheck::Found Query ControlObjects \n");fflush(stdout);
	}
	else
	{
		printf("\n SiteViseProjectValidationCheck::Not Found Query ControlObjects \n");fflush(stdout);
	}

	if(PREF_ask_char_value("tm_TC_site_name",index,&SiteName)!=ITK_ok) PrintErrorStack();
	printf("\n SiteViseProjectValidationCheck SiteName :%s\n",SiteName);fflush(stdout); //MBOM implementation for CV TZ-1.69

	if(strcmp(SiteName,"cmitest")==0) // if uaprod then not allow to create 9001/9002.... 9020
	{
		qry_sys_values[0] = "cmitest_Proj" ;
		if(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCntlObj, &CntrlObject_Tag));
		printf(" \n SiteViseProjectValidationCheck:SiteName:[%s]:IntCntlObj:[%d]",SiteName,IntCntlObj); fflush(stdout);
		if(IntCntlObj>0)
		{
			if( AOM_ask_value_string(CntrlObject_Tag[0],"t5_Userinfo1",&sUsrInfo)!=ITK_ok) PrintErrorStack();
			// if project found in info1 then allow tmetc user only to create part.
			printf(" \n SiteViseProjectValidationCheck:sUsrInfo:[%s]:sProjectCode:[%s]",sUsrInfo,sProjectCode); fflush(stdout);
			if(strstr(sUsrInfo,sProjectCode)!=NULL) // if(tc_strstr(sUserInfoVal, sDesGrp) != NULL)
			{
				IsValidFlag =0;
				printf(" \n Selected project code is allowed to create at tmetc site only."); fflush(stdout);
				//strcat(*OutputStr,"Selected project code is allowed to create at tmetc site only.");
				// check starting 4 digits are from list i.e. 9001/9002/9003 etc
				if(strstr(sUsrInfo,FrstBarrel)!=NULL)
				{
					IsValidFlag =0;
					printf(" \n inside if."); fflush(stdout);
				}
				else
				{
					printf(" \n inside else."); fflush(stdout);
					IsValidFlag =1;
					strcat(*OutputStr,"First Barrel code [First 4 digit] of TC Part is invalid.");
					strcat(*OutputStr,"Valid digits are ");
					strcat(*OutputStr,sUsrInfo);
					strcat(*OutputStr," only.");
				}
			}
			else
			{
				IsValidFlag =1;
				printf(" \n Selected project code is not allowed to create at tmetc site only."); fflush(stdout);
				strcat(*OutputStr,"Selected Project code ");
				strcat(*OutputStr,sProjectCode);
				strcat(*OutputStr," is not allowed to create at tmetc site.");

			}
		}
	}
	else if(strcmp(SiteName,"TMETC")==0)
	{
		qry_sys_values[0] = "TMETC_Proj" ;
		if(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCntlObj, &CntrlObject_Tag));
		printf(" \n SiteViseProjectValidationCheck:SiteName:[%s]:IntCntlObj:[%d]",SiteName,IntCntlObj); fflush(stdout);
		if(IntCntlObj>0)
		{
			if( AOM_ask_value_string(CntrlObject_Tag[0],"t5_Userinfo1",&sUsrInfo)!=ITK_ok) PrintErrorStack();
			// if project found in info1 then allow tmetc user only to create part.
			printf(" \n SiteViseProjectValidationCheck:sUsrInfo:[%s]:sProjectCode:[%s]",sUsrInfo,sProjectCode); fflush(stdout);
			if(strstr(sUsrInfo,sProjectCode)!=NULL) // if(tc_strstr(sUserInfoVal, sDesGrp) != NULL)
			{
				IsValidFlag =0;
				printf(" \n SiteViseProjectValidationCheck:Selected project code is allowed to create at tmetc site only."); fflush(stdout);
				//strcat(*OutputStr,"Selected project code is allowed to create at tmetc site only.");
				// check starting 4 digits are from list i.e. 9001/9002/9003 etc
				if(strstr(sUsrInfo,FrstBarrel)!=NULL)
				{
					IsValidFlag =0;
					printf(" \n SiteViseProjectValidationCheck:inside if."); fflush(stdout);
				}
				else
				{
					printf(" \n SiteViseProjectValidationCheck:inside else."); fflush(stdout);
					IsValidFlag =1;
					strcat(*OutputStr,"First Barrel code [First 4 digit] of TC Part is invalid.");
					strcat(*OutputStr,"Valid digits are ");
					strcat(*OutputStr,sUsrInfo);
					strcat(*OutputStr," only.");
				}
			}
			else
			{
				IsValidFlag =1;
				printf(" \n SiteViseProjectValidationCheck:Selected project code is not allowed to create at tmetc site only."); fflush(stdout);
				strcat(*OutputStr,"Selected Project code ");
				strcat(*OutputStr,sProjectCode);
				strcat(*OutputStr," is not allowed to create at tmetc site.");

			}
		}
	}
	else if(strcmp(SiteName,"Trilix")==0)
	{
		qry_sys_values[0] = "Trilix_Proj" ;
		if(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCntlObj, &CntrlObject_Tag));
		printf("\n SiteViseProjectValidationCheck:SiteName:[%s]:IntCntlObj:[%d]",SiteName,IntCntlObj); fflush(stdout);
		if(IntCntlObj>0)
		{
			if( AOM_ask_value_string(CntrlObject_Tag[0],"t5_Userinfo1",&sUsrInfo)!=ITK_ok) PrintErrorStack();
			// if project found in info1 then allow trilix user only to create part.
			printf("\n SiteViseProjectValidationCheck:sUsrInfo:[%s]:sProjectCode:[%s]",sUsrInfo,sProjectCode); fflush(stdout);
			if(strstr(sUsrInfo,sProjectCode)!=NULL)
			{
				IsValidFlag =0;
				printf(" \n SiteViseProjectValidationCheck:Selected project code is allowed to create at trilix site only."); fflush(stdout);
				//strcat(*OutputStr,"Selected project code is allowed to create at trilix site only.");

				// check starting 4 digits are from list i.e. 9011 etc
				if(strstr(sUsrInfo,FrstBarrel)!=NULL)
				{
					IsValidFlag =0;
					printf(" \n SiteViseProjectValidationCheck:inside if."); fflush(stdout);
				}
				else
				{
					printf(" \n SiteViseProjectValidationCheck:inside else."); fflush(stdout);
					IsValidFlag =1;
					strcat(*OutputStr,"First Barrel code [First 4 digit] of TC Part is invalid.");
					strcat(*OutputStr,"Valid digits are ");
					strcat(*OutputStr,sUsrInfo);
					strcat(*OutputStr," only.");
				}
			}
			else
			{
				IsValidFlag =1;
				printf(" \n SiteViseProjectValidationCheck:Selected project code is not allowed to create at trilix site only."); fflush(stdout);
				strcat(*OutputStr,"Selected Project code ");
				strcat(*OutputStr,sProjectCode);
				strcat(*OutputStr," is not allowed to create at trilix site.");
			}
		}
	}
	return IsValidFlag;
}
int FunToValidateProjectCodeNPartType(tag_t Des_Rev_tag,char **OutputStr)
{
	int		IsValidFlag			=	0;
	char	*sProjCode			=	NULL;
	char	*sPrtType			=	NULL;
	char*	sUsrInfo2			=	NULL;
	tag_t   Cntl_obj_Qtag		=	NULLTAG;
	int     n_entry				=	3;
	int		IntCntlObj			=	0;
	tag_t   *CntrlObject_Tag    =	NULLTAG;
	char	*PartTypeVal		=	NULL;
	char    *qry_sys_entry[3]	=	{"SYSCD","SUBSYSCD","Information-1"};
	char    **qry_sys_values    =  (char **) MEM_alloc(10 * sizeof(char *));

	*OutputStr=(char *) MEM_alloc(250);
	PartTypeVal=(char *) MEM_alloc(250);

	strcpy(*OutputStr,"");
	strcpy(PartTypeVal,"");

	//printf("\n Inside FunToValidateProjectCodeNPartType  ");fflush(stdout);

	if( AOM_ask_value_string(Des_Rev_tag,"t5_ProjectCode",&sProjCode)!=ITK_ok)  PrintErrorStack();
	if( AOM_ask_value_string(Des_Rev_tag,"t5_PartType",&sPrtType)!=ITK_ok) PrintErrorStack();

	printf("\n FunToValidateProjectCodeNPartType::Project Code:[%s] Part Type:[%s]  ",sProjCode,sPrtType);fflush(stdout);

	// create control object having info1 == project code and info2 == part type
	// if project code in info1 check it's accessibility for the part types in info2.

	if(QRY_find2("Control Objects...", &Cntl_obj_Qtag));
	if (Cntl_obj_Qtag)
	{
		printf("\n FunToValidateProjectCodeNPartType::Found Query ControlObjects  ");fflush(stdout);
	}
	else
	{
		printf("\n FunToValidateProjectCodeNPartType::Not Found Query ControlObjects  ");fflush(stdout);
	}
	qry_sys_values[0] = "ProCodeNPrtTypeVal";
	qry_sys_values[1] = "ProCodeNPrtTypeVal";
	qry_sys_values[2] =	 sProjCode;
	if(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCntlObj, &CntrlObject_Tag));
	printf(" \n FunToValidateProjectCodeNPartType::IntCntlObj:[%d]",IntCntlObj); fflush(stdout);
	if(IntCntlObj>0)
	{
		if( AOM_ask_value_string(CntrlObject_Tag[0],"t5_Userinfo2",&sUsrInfo2)!=ITK_ok) PrintErrorStack();
		strcat(PartTypeVal,"[");
		strcat(PartTypeVal,sPrtType);
		strcat(PartTypeVal,"]");
		printf(" \n FunToValidateProjectCodeNPartType::sUsrInfo2:[%s]:PartType:[%s]",sUsrInfo2,PartTypeVal); fflush(stdout);
		if(strstr(sUsrInfo2,PartTypeVal)!=NULL)
		{
			printf(" \n FunToValidateProjectCodeNPartType::inside if."); fflush(stdout);
			IsValidFlag = 0;
		}
		else
		{
			printf("\n FunToValidateProjectCodeNPartType::inside else."); fflush(stdout);
			IsValidFlag =1;
			strcat(*OutputStr,"Part Type ");
			strcat(*OutputStr,sPrtType);
			strcat(*OutputStr," is invalid for selected project code: ");
			strcat(*OutputStr,sProjCode);
		}
	}
	else
	{
	printf("\n FunToValidateProjectCodeNPartType::Control object not found for:syscd[ProCodeNPrtTypeVal],subsyscd[ProCodeNPrtTypeVal],info1[%s]",sProjCode); fflush(stdout);
	}

	return IsValidFlag;
}
/******************************************************* Added by Aashish_w Start *******************************************************/
int t5_partcategory(tag_t Des_Rev_tag,char **OutputStr)
{
	int		IsValidFlag			=	0;
	char *partcatgry = NULL;
	partcatgry=(char *) MEM_alloc(1000);
	char *parttype = NULL;
	char *prjcode = NULL;
	char *designGrp = NULL;
	char *itemid;
	itemid=(char *) MEM_alloc(1000);
	char *itemid_toked;
	itemid_toked=(char *) MEM_alloc(1000);
	char *itemid_toked1;
	itemid_toked1=(char *) MEM_alloc(1000);
	int itemidlength = 0;
	tag_t   Cntl_obj_Qtag		=	NULLTAG;
	tag_t   Cntl_obj_Qtag2		=	NULLTAG;
	int n_entries1 = 3;
	int n_entries2 = 3;
	char *qry_entries1[3] = {"Name","SYSCD","SUBSYSCD"};
	char *qry_entries2[3] = {"Information-1","SYSCD","SUBSYSCD"};
	char **qry_values1 = (char **) MEM_alloc(50 * sizeof(char *));
	char **qry_values2 = (char **) MEM_alloc(50 * sizeof(char *));
	int resultCount1=0;
	int resultCount2=0;
	tag_t *qry_cntrlobj= NULLTAG;
	tag_t *qry_cntrlobj2= NULLTAG;
	char *userinfo1;

	*OutputStr=(char *) MEM_alloc(250);
	strcpy(*OutputStr,"");

	//printf("\n Inside t5_partcategory  ");fflush(stdout);

	if( AOM_ask_value_string(Des_Rev_tag,"t5_SpareCriteria",&partcatgry)!=ITK_ok) PrintErrorStack();
	printf("\n t5_partcategory::Part Category --------> %s  ",partcatgry);fflush(stdout);
	//if (partcatgry != NULL)
	if (tc_strlen(partcatgry)!=0)
	{
		if(QRY_find2("Control Objects...", &Cntl_obj_Qtag));
		if (Cntl_obj_Qtag)
		{
			printf("\n t5_partcategory::Query Found : Control Objects...  ");fflush(stdout);
		}
		else
		{
			printf("\n t5_partcategory::Query NOT Found : Control Objects...  ");fflush(stdout);
		}

		//************************************ 1.Designer has to mandatorily select the part categories from the available dropdown while creating TC part. ************************************
		qry_values1[0] = partcatgry ;
		qry_values1[1] = "PRTCAT" ;
		qry_values1[2] = "PRTCAT" ;

		ITK_CALL(QRY_execute(Cntl_obj_Qtag, n_entries1, qry_entries1, qry_values1, &resultCount1, &qry_cntrlobj));
		printf("\n t5_partcategory::Count of Control object found while save validation ------------------>  %d  ",resultCount1);

		if (resultCount1 > 0)
		{
				printf("\n t5_partcategory::Inside my IF  ");fflush(stdout);

				ITK_CALL(AOM_ask_value_string(qry_cntrlobj[0],"t5_Userinfo1",&userinfo1));

				ITK_CALL(AOM_refresh(Des_Rev_tag,1));

				ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria",userinfo1));

				ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));

				ITK_CALL(AOM_refresh(Des_Rev_tag,0));

				IsValidFlag =0;

				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_SpareCriteria",&partcatgry));
				printf("\n t5_partcategory::Part Category after save --------> %s  ",partcatgry);fflush(stdout);


				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"item_id",&itemid));
				printf("\n t5_partcategory::Item ID --------> %s ",itemid);fflush(stdout);
				//******************** 2.CON- Consumable parts will be needed. Check will be put in not to use this part category for 12 digit ERC part. *******************
				if (tc_strcmp(partcatgry,"CON")==0)
				{
					printf("\n t5_partcategory::inside Part Category CON check tc_strlen(itemid): [%d]",tc_strlen(itemid));fflush(stdout);
					if (tc_strlen(itemid) == 12)
					{
						printf("\n t5_partcategory::CON Lov BreakDown... ");fflush(stdout);
						IsValidFlag =1;
						strcat(*OutputStr,"Part Category CON:Consumable parts is invalid for 12 digit parts.");
					}
				}
				//******************** 3.As this field is going to be mandatory, for dummy parts PHN- phantom should be stamped. *********************
				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_PartType",&parttype));
				printf("\n t5_partcategory::Part Type is ----> %s  ",parttype);fflush(stdout);
				if (tc_strcmp(parttype,"D")==0 || tc_strcmp(parttype,"DC")==0 || tc_strcmp(parttype,"DA")==0 || tc_strcmp(parttype,"G")==0)
				{
					printf("\n t5_partcategory::Inside Part Type Dummy check  ");fflush(stdout);
					ITK_CALL(AOM_refresh(Des_Rev_tag,1));

					ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","PHN"));

					ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));

					ITK_CALL(AOM_refresh(Des_Rev_tag,0));
				}

				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_ProjectCode",&prjcode));
				printf("\n t5_partcategory::Project Code of Part= %s  ",prjcode);fflush(stdout);
				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_DesignGrp",&designGrp));
				printf(" Design Group=%s ",designGrp);fflush(stdout);

				//******************** if prj is 1111 and dsgngrp is 11 then std or con only  **************************..
				if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"11")==0)
				{
					//******** According to TS 11808, parts starting from 5 should carry CON as Part Category. *********
					itemid_toked=subString(itemid,0,1);
					printf("\n t5_partcategory::ItemId_Toked -------> %s  ",itemid_toked);fflush(stdout);
					if (tc_strcmp(itemid_toked,"5")==0)
					{
						printf("\n t5_partcategory::Inside Parts starting from 5 check  ");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","CON"));
						ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
					//******** According to TS 11808,  Parts starting with other than 5 should carry STD as Part Category. *********
					else
					{
						printf("\n t5_partcategory::Inside Parts NOT starting from 5 check  ");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
						ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
				}
				//******************** 4.System should not allow STD & CON for parts other than project code "1111" & design group "11". ********************
				if (tc_strcmp(partcatgry,"STD")==0 || tc_strcmp(partcatgry,"CON")==0 )
				{
					printf("\n t5_partcategory::inside project code 1111 & design group 11 check  ");fflush(stdout);

					if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"11")==0)
					{
						//******** According to TS 11808, parts starting from 5 should carry CON as Part Category. *********
						itemid_toked=subString(itemid,0,1);
						printf("\n t5_partcategory::ItemId_Toked -------> %s  ",itemid_toked);fflush(stdout);
						if (tc_strcmp(itemid_toked,"5")==0)
						{
							printf("\n t5_partcategory::Inside Parts starting from 5 check  ");fflush(stdout);
							ITK_CALL(AOM_refresh(Des_Rev_tag,1));
							ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","CON"));
							ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));
							ITK_CALL(AOM_refresh(Des_Rev_tag,0));
						}
						//******** According to TS 11808,  Parts starting with other than 5 should carry STD as Part Category. *********
						else
						{
							printf("\n t5_partcategory::Inside Parts NOT starting from 5 check  ");fflush(stdout);
							ITK_CALL(AOM_refresh(Des_Rev_tag,1));
							ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
							ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));
							ITK_CALL(AOM_refresh(Des_Rev_tag,0));
						}
					}
					else
					{
						if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"54")==0)
						{
								printf("\n t5_partcategory::Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category check  ");fflush(stdout);
								ITK_CALL(AOM_refresh(Des_Rev_tag,1));
								ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
								ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));
								ITK_CALL(AOM_refresh(Des_Rev_tag,0));
						}
						else
						{
							printf("\n t5_partcategory::STD & CON Lov BreakDown... ");fflush(stdout);
							IsValidFlag =1;
							strcat(*OutputStr,"Part Category STD:Standard Part & CON:Consumable parts is valid only for Project Code 1111 & Design Group 11 & 54.Please select other value.");
						}
					}
				}
				//******************** 5.Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category. ********************
				if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"54")==0)
				{
						printf("\n t5_partcategory::Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category check  ");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
						ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
				}
				//******************** 6.Part type Vehicle , TPL, VC, Group ID, Dummy, Dummy TPL,VC CR must carry PHN (PHN:Phantom Assembly). ********************
				if (tc_strcmp(parttype,"V")==0 || tc_strcmp(parttype,"TPL")==0 || tc_strcmp(parttype,"VC")==0 || tc_strcmp(parttype,"G")==0 || tc_strcmp(parttype,"VCCR")==0 )
				{
					printf("\n t5_partcategory::Inside Part type Vehicle , TPL, VC CR, VC, Group ID, Dummy, Dummy TPL must carry PHN check  ");fflush(stdout);
					ITK_CALL(AOM_refresh(Des_Rev_tag,1));
					ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","PHN"));
					ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));
					ITK_CALL(AOM_refresh(Des_Rev_tag,0));
				}
	//******************** 7.Part number having third barrel  16  must carry TSD:TML Specification Document. ********************
				itemid_toked1=subString(itemid,8,2); //third barrel 16 changes by Aadarsh kumar
				printf("\n t5_partcategory::D1--itemid_toked1 of 3rd baral --AA -- ------> %s",itemid_toked1);
			if (strlen(itemid)==12)
			{
			if(((tc_strcmp(parttype,"A")==0) || (tc_strcmp(parttype,"C")==0) || (tc_strcmp(parttype,"D")==0)))
				{
					if (tc_strcmp(itemid_toked1,"16")==0)
					{
						printf("\n t5_partcategory::D1--Inside Part number having third barrel 16 must carry TSD:TML Specification Document check  ");fflush(stdout);
						if (tc_strcmp(subString(partcatgry,0,3),"TSD")==0) //part category 0 to 3 condition added by added by Aadarsh
						{
							printf("\n t5_partcategory::D1--Inside Part number having third barrel 16 must carry TSD:TML Specification Document check Sucessful ");fflush(stdout);
						}
						else
						{
							printf("\n t5_partcategory::D1--third barrel 16 Lov BreakDown... ");fflush(stdout);
							IsValidFlag =1;
							strcat(*OutputStr,"Please Select Part Category as TSD-Black or TSD-Gray.");
						}
					}
				}
			}
		}
		else
		{
			if(QRY_find2("Control Objects...", &Cntl_obj_Qtag2));
						qry_values2[0] = partcatgry ;
						qry_values2[1] = "PRTCAT" ;
						qry_values2[2] = "PRTCAT" ;
			ITK_CALL(QRY_execute(Cntl_obj_Qtag2, n_entries2, qry_entries2, qry_values2, &resultCount2, &qry_cntrlobj2));
			printf("\n t5_partcategory::Count of Control object 2222 found-> %d  ",resultCount2);

			if (resultCount2 > 0)
			{
				IsValidFlag =0;
				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_SpareCriteria",&partcatgry));
				printf("\n t5_partcategory::Part Category after save: %s ",partcatgry);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"item_id",&itemid));
				printf(" Item ID: %s ",itemid);fflush(stdout);
				//******************** 2.CON- Consumable parts will be needed. Check will be put in not to use this part category for 12 digit ERC part. *******************
				if (tc_strcmp(partcatgry,"CON")==0)
				{
					printf(" -->inside Part Category CON check tc_strlen(itemid): [%d] \n",tc_strlen(itemid));fflush(stdout);
					if (tc_strlen(itemid) == 12)
					{
						printf("\n t5_partcategory::CON Lov BreakDown...\n");fflush(stdout);
						IsValidFlag =1;
						strcat(*OutputStr,"Part Category CON:Consumable parts is invalid for 12 digit parts.");
					}
				}
				//******************** 3.As this field is going to be mandatory, for dummy parts PHN- phantom should be stamped. *********************
				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_PartType",&parttype));
				printf("\n t5_partcategory::Part Type is ----> %s \n",parttype);fflush(stdout);
				if (tc_strcmp(parttype,"D")==0 || tc_strcmp(parttype,"DC")==0 || tc_strcmp(parttype,"DA")==0 || tc_strcmp(parttype,"G")==0)
				{
				printf("\n t5_partcategory::Inside Part Type Dummy check \n");fflush(stdout);
					ITK_CALL(AOM_refresh(Des_Rev_tag,1));

					ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","PHN"));

					ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));

					ITK_CALL(AOM_refresh(Des_Rev_tag,0));
				}

				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_ProjectCode",&prjcode));
				printf("\n t5_partcategory::Project Code of Part= %s \n",prjcode);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_DesignGrp",&designGrp));
				printf("\n t5_partcategory::Design Group of Part=%s \n",designGrp);fflush(stdout);
				//******************** if prj is 1111 and dsgngrp is 11 then std or con only  **************************..
				if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"11")==0)
				{
					//******** According to TS 11808, parts starting from 5 should carry CON as Part Category. *********
					itemid_toked=subString(itemid,0,1);
					printf("\n t5_partcategory::ItemId_Toked -------> %s \n",itemid_toked);fflush(stdout);
					if (tc_strcmp(itemid_toked,"5")==0)
					{
						printf("\n t5_partcategory::Inside Parts starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","CON"));
						ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
					//******** According to TS 11808,  Parts starting with other than 5 should carry STD as Part Category. *********
					else
					{
						printf("\n t5_partcategory::Inside Parts NOT starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
						ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
				}
				//******************** 4.System should not allow STD & CON for parts other than project code "1111" & design group "11". ********************
				if (tc_strcmp(partcatgry,"STD")==0 || tc_strcmp(partcatgry,"CON")==0 )
				{
					printf("\n t5_partcategory::inside project code 1111 & design group 11 check \n");fflush(stdout);

					if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"11")==0)
					{
						//******** According to TS 11808, parts starting from 5 should carry CON as Part Category. *********
						itemid_toked=subString(itemid,0,1);
						printf("\n t5_partcategory::ItemId_Toked -------> %s \n",itemid_toked);fflush(stdout);
						if (tc_strcmp(itemid_toked,"5")==0)
						{
							printf("\n t5_partcategory::Inside Parts starting from 5 check \n");fflush(stdout);
							ITK_CALL(AOM_refresh(Des_Rev_tag,1));
							ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","CON"));
							ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));
							ITK_CALL(AOM_refresh(Des_Rev_tag,0));
						}
						//******** According to TS 11808,  Parts starting with other than 5 should carry STD as Part Category. *********
						else
						{
							printf("\n t5_partcategory::Inside Parts NOT starting from 5 check \n");fflush(stdout);
							ITK_CALL(AOM_refresh(Des_Rev_tag,1));
							ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
							ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));
							ITK_CALL(AOM_refresh(Des_Rev_tag,0));
						}
					}
					else
					{
						if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"54")==0)
						{
								printf("\n t5_partcategory::Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category check \n");fflush(stdout);
								ITK_CALL(AOM_refresh(Des_Rev_tag,1));
								ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
								ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));
								ITK_CALL(AOM_refresh(Des_Rev_tag,0));
						}
						else
						{
							printf("\n t5_partcategory::STD & CON Lov BreakDown...\n");fflush(stdout);
							IsValidFlag =1;
							strcat(*OutputStr,"Part Category STD:Standard Part & CON:Consumable parts is valid only for Project Code 1111 & Design Group 11.Please select other value.");
						}
					}
				}
				//******************** 5.Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category. ********************
				if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"54")==0)
				{
						printf("\n t5_partcategory::Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
						ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
				}
				//******************** 6.Part type Vehicle , TPL, VC, Group ID, Dummy, Dummy TPL,VC CR must carry PHN (PHN:Phantom Assembly). ********************
				if (tc_strcmp(parttype,"V")==0 || tc_strcmp(parttype,"TPL")==0 || tc_strcmp(parttype,"VC")==0 || tc_strcmp(parttype,"G")==0 || tc_strcmp(parttype,"VCCR")==0 )
				{
					printf("\n t5_partcategory::Inside Part type Vehicle,TPL,VC_CR,VC,Group_ID,Dummy,Dummy_TPL must carry PHN check \n");fflush(stdout);
					ITK_CALL(AOM_refresh(Des_Rev_tag,1));
					ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","PHN"));
					ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));
					ITK_CALL(AOM_refresh(Des_Rev_tag,0));
				}
		//******************** 7.Part number having third barrel  16  must carry TSD:TML Specification Document. ********************
		if (strlen(itemid)==12)
		{
			if(((tc_strcmp(parttype,"A")==0) || (tc_strcmp(parttype,"C")==0) || (tc_strcmp(parttype,"D")==0)))  // part type condition added for third barrel
			{
				itemid_toked1=subString(itemid,8,2);  //third barrel 16 chnaged by Aadarsh
				printf("\nt5_partcategory::E1--itemid_toked1 of 3rd baral ------> %s",itemid_toked1);
				if (tc_strcmp(itemid_toked1,"16")==0)
					{
						printf("\n t5_partcategory::E1--Inside Part number having third barrel  16  must carry TSD:TML Specification Document check \n");fflush(stdout);
						if (tc_strcmp(subString(partcatgry,0,3),"TSD")==0)
						{
								printf("\n t5_partcategory::E1--Inside Part number having third barrel  16  must carry TSD:TML Specification Document check Sucessful\n");fflush(stdout);
						}
						else
						{
							printf("\n t5_partcategory::third barrel 16 Lov BreakDown...\n");fflush(stdout);
							IsValidFlag =1;
							strcat(*OutputStr,"Please Select Part Category as TSD-Black or TSD-Gray.");
						}
					}
				}
			}
		}
		else
		{
			printf("\n t5_partcategory::Suggestive LOV Breakdown...\n");fflush(stdout);
			IsValidFlag =1;
			strcat(*OutputStr,"Please select values of Part Category from Dropdown List Only.");
		}
		}
	}
	else
	{
		//******************** As this field is going to be mandatory, for dummy parts PHN- phantom should be stamped. *********************
		ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_PartType",&parttype));
		printf("\n t5_partcategory::Part Type is ----> %s \n",parttype);fflush(stdout);
		if (tc_strcmp(parttype,"D")==0 || tc_strcmp(parttype,"DC")==0 || tc_strcmp(parttype,"DA")==0 || tc_strcmp(parttype,"G")==0 || tc_strcmp(parttype,"V")==0 || tc_strcmp(parttype,"TPL")==0 || tc_strcmp(parttype,"VC")==0 || tc_strcmp(parttype,"VCCR")==0 )
		{
			printf("\nInside Part Type Dummy check \n");fflush(stdout);
			ITK_CALL(AOM_refresh(Des_Rev_tag,1));

			ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","PHN"));

			ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));

			ITK_CALL(AOM_refresh(Des_Rev_tag,0));
		}
		else
		{
			ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_ProjectCode",&prjcode));
			printf("\n t5_partcategory::Project Code of Part= %s \n",prjcode);fflush(stdout);

			ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_DesignGrp",&designGrp));
			printf("\n t5_partcategory::Design Group= %s \n",designGrp);fflush(stdout);
			//******************** Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category. ********************
			if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"54")==0)
			{
				printf("\n t5_partcategory::Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category check \n");fflush(stdout);
				ITK_CALL(AOM_refresh(Des_Rev_tag,1));
				ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
				ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));
				ITK_CALL(AOM_refresh(Des_Rev_tag,0));
			}
			else
			{
				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"item_id",&itemid));
				//******************** if prj is 1111 and dsgngrp is 11 then std or con only  **************************..
				if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"11")==0)
				{
					//******** According to TS 11808, parts starting from 5 should carry CON as Part Category. *********
					itemid_toked=subString(itemid,0,1);
					printf("\n t5_partcategory::ItemId_Toked -------> %s \n",itemid_toked);fflush(stdout);
					if (tc_strcmp(itemid_toked,"5")==0)
					{
						printf("\n t5_partcategory::Inside Parts starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","CON"));
						ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
					//******** According to TS 11808,  Parts starting with other than 5 should carry STD as Part Category. *********
					else
					{
						printf("\n t5_partcategory::Inside Parts NOT starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
						ITK_CALL( AOM_save_without_extensions(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
				}
				else
					{

						IsValidFlag =1;
						strcat(*OutputStr,"Please find List of Mandatory Attributes,*Part Category*.");
					}
				}
	}
	}
	return IsValidFlag;
}
/******************************************************* Added by Aashish_w End *******************************************************/
int IsPartAvail(char* InputPart)
{
	int		IsAvailInUA		=	0;
	tag_t   OutPutTag		=	NULLTAG;
	tag_t   query		=	NULLTAG;
	int		n_tags_found2	=	0;
	tag_t	*tags_found2	=	NULL;

	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int		n_tags_foundd2	=	0;
	tag_t	*tags_foundd2	=	NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];

	char
        *qry_entries[1] = {"Item ID"},
        *qry_values[1]	= {"*"};
	//MT end
	printf("\n IsPartAvail::FUN:part no :%s.", InputPart);fflush(stdout);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	//attrs2[0] ="item_id";
	//attrs2[1] ="object_type";
	//values2[0] = (char *)InputPart;
	//values2[1] = "Design";
	//if(ITEM_find_items_by_key_attributes(1,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok) PrintErrorStack();

	qry_values[0]	= InputPart;
	QRY_find2("Item...", &query);
	QRY_execute(query, 1, qry_entries, qry_values, &n_tags_found2, &tags_found2);
	printf("\n IsPartAvail::FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
		IsAvailInUA = 1;
		printf("\n IsPartAvail::Part found in TCUA:%d",IsAvailInUA);fflush(stdout);
	}
	else
	{
		IsAvailInUA = 0;
		printf("\n IsPartAvail::Part not found in TCUA:%d",IsAvailInUA);fflush(stdout);
	}
	return IsAvailInUA;
}

int IsDesignRevisionAvail(char* InputPart)
{
	int		IsAvailInUA		=	0;
	tag_t   OutPutTag		=	NULLTAG;
	tag_t   query		=	NULLTAG;
	int		n_tags_found2	=	0;
	tag_t	*tags_found2	=	NULL;

	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int		n_tags_foundd2	=	0;
	tag_t	*tags_foundd2	=	NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	char
        *qry_entries[2] = {"Item ID","Type"},
        *qry_values[2]	= {"*","*"};
	//MT end
	printf("\n IsDesignRevisionAvail--FUN:part no :%s.", InputPart);fflush(stdout);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	//attrs2[0] ="item_id";
	//attrs2[1] ="object_type";
	//values2[0] = (char *)InputPart;
	//values2[1] = "Design";
	//if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok) PrintErrorStack();

	qry_values[0]	= InputPart;
	qry_values[1]	= "Design";
	QRY_find2("Item...", &query);
	QRY_execute(query, 2, qry_entries, qry_values, &n_tags_found2, &tags_found2);
	printf("\n IsDesignRevisionAvail--FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
		IsAvailInUA = 1;
		printf("\n IsDesignRevisionAvail--Part found in TCUA:%d",IsAvailInUA);fflush(stdout);
	}
	else
	{
		IsAvailInUA = 0;
		printf("\n IsDesignRevisionAvail--Part not found in TCUA:%d",IsAvailInUA);fflush(stdout);
	}
	return IsAvailInUA;
}

int FunToCheckPartAvailInICE(tag_t cntrl_objTCE,char *Item_ID)
{
	int IsAvailTCE = 0;

	// Added code to consume web service

	//printf("\n consuming web service start  "); fflush(stdout);

	char*syscommand=NULL;
	char*ExePath=NULL;
	char*UsrP=NULL;
	char*PwdP=NULL;
	char*roleP=NULL;

	// Added code to consume web service

	printf("\n FunToCheckPartAvailInICE--consuming web service start:  "); fflush(stdout);

	if (AOM_ask_value_string(cntrl_objTCE,"t5_Userinfo1",&ExePath)!=ITK_ok) PrintErrorStack();
	if (AOM_ask_value_string(cntrl_objTCE,"t5_Userinfo2",&UsrP)!=ITK_ok) PrintErrorStack();
	if (AOM_ask_value_string(cntrl_objTCE,"t5_Userinfo3",&PwdP)!=ITK_ok) PrintErrorStack();
	if (AOM_ask_value_string(cntrl_objTCE,"t5_Userinfo4",&roleP)!=ITK_ok) PrintErrorStack();
	printf("\n FunToCheckPartAvailInICE--cntrl_objTCE: ExePath is  = [%s] PwdP = [%s] ", ExePath,PwdP);fflush(stdout);

	syscommand=(char *) MEM_alloc(200);
	tc_strcpy(syscommand,ExePath);
	tc_strcat(syscommand," ");
	tc_strcat(syscommand,UsrP);
	tc_strcat(syscommand," ");
	tc_strcat(syscommand,PwdP);
	tc_strcat(syscommand," ");
	tc_strcat(syscommand,roleP);
	tc_strcat(syscommand," ");
	tc_strcat(syscommand,Item_ID);

	printf("\n FunToCheckPartAvailInICE--start Calling exe using system syscommand: [%s] ",syscommand); fflush(stdout);

	int rc;
	FILE *pipe = NULL;
	int i;
	char buffer[3000];

	sprintf(buffer, "%s",syscommand);

	if ((pipe = popen(buffer, "r")) == NULL) {
		perror("popen");
		return 1;
	}
	while (fgets(buffer, 3000, pipe) != NULL)
		printf("buffer: %s",  buffer);

	if (pclose(pipe) == -1) {
	perror("pclose");
	return 1;
	}
	printf("\n FunToCheckPartAvailInICE--consuming web service end  "); fflush(stdout);

	if(strstr(buffer,"[NA]")!=NULL)
		{
			printf("\n FunToCheckPartAvailInICE--Checked in TCE, part is not present in TCE   "); fflush(stdout);
			IsAvailTCE =0;
		}
		else
		{
			printf("\n FunToCheckPartAvailInICE--Checked in TCE, part is present in TCE  "); fflush(stdout);
			IsAvailTCE =2;
		}

	return IsAvailTCE;
}
int FunToCheckGroupIDRefInICE(tag_t CntrlObj_tag,char* Item_id,char*GroupID)
{
	int IsAvailTCE = 0;
	char*syscommand=NULL;
	char*ExePath=NULL;
	char*UsrP=NULL;
	char*PwdP=NULL;
	char*roleP=NULL;

	// Added code to consume web service

	//printf("\n consuming web service start:  "); fflush(stdout);

	if (AOM_ask_value_string(CntrlObj_tag,"t5_Userinfo1",&ExePath)!=ITK_ok) PrintErrorStack();
	if (AOM_ask_value_string(CntrlObj_tag,"t5_Userinfo2",&UsrP)!=ITK_ok) PrintErrorStack();
	if (AOM_ask_value_string(CntrlObj_tag,"t5_Userinfo3",&PwdP)!=ITK_ok) PrintErrorStack();
	if (AOM_ask_value_string(CntrlObj_tag,"t5_Userinfo4",&roleP)!=ITK_ok) PrintErrorStack();
	printf("\n FunToCheckGroupIDRefInICE--CntrlObj_tag: ExePath is  = [%s] PwdP = [%s] ", ExePath,PwdP);fflush(stdout);

	syscommand=(char *) MEM_alloc(200);
	tc_strcpy(syscommand,ExePath);
	tc_strcat(syscommand," ");
	tc_strcat(syscommand,UsrP);
	tc_strcat(syscommand," ");
	tc_strcat(syscommand,PwdP);
	tc_strcat(syscommand," ");
	tc_strcat(syscommand,roleP);
	tc_strcat(syscommand," ");
	tc_strcat(syscommand,Item_id);
	tc_strcat(syscommand," ");
	tc_strcat(syscommand,GroupID);

	printf("\n FunToCheckGroupIDRefInICE--start Calling exe using system syscommand: [%s] ",syscommand); fflush(stdout);

	int rc;
	FILE *pipe = NULL;
	int i;
	char buffer[3000];

	sprintf(buffer, "%s",syscommand);
	if ((pipe = popen(buffer, "r")) == NULL) {
		perror("popen");
		return 1;
	}
	while (fgets(buffer, 3000, pipe) != NULL)
		printf("buffer: %s",  buffer);

	if (pclose(pipe) == -1) {
	perror("pclose");
	return 1;
	}
	printf("\n FunToCheckGroupIDRefInICE--consuming web service end  "); fflush(stdout);

	if(strstr(buffer,"[NA]")!=NULL)
		{
			printf("\n FunToCheckGroupIDRefInICE--$$$ Checked in TCE, part is not present in TCE  $$$  "); fflush(stdout);
			IsAvailTCE =0;
		}
		else
		{
			printf("\n FunToCheckGroupIDRefInICE--$$$ Checked in TCE, part is present in TCE \n $$$"); fflush(stdout);
			IsAvailTCE =2;
		}

	return IsAvailTCE;
}
extern DLLAPI int  save_method_4(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;

	tag_t objTag = va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);
	logical flag = va_arg(args, int);

	const char reason;
	const char reason1;
	const char change_id;
	const char change_id1;
	const char dir_name;
	const char dir_name1;
	char wgtstr[100];

	double objWeight ;
	double objWeightVal ;
	double roundedWtVal ;

	int cnt=0;
	int Rolflag1=0;
	int Gmcnt=0;
	int Gmcnt1=0;
	int Gmcnt2=0;
	int Gmcnt3=0;
	int ij=0;
	int jk=0;
	int jkl=0;
	int Rolflag=0;
	int dsflag=0;
	int resultCount=0,j=0;
	int Rev_idlength = 0;//Adi
	int	 pp = 0;
	int  catcnt = 0;
	int	 PrtChkFlag = 0;
	int	 PrdChkFlag = 0;
	int count1 = 0; //Adi 1.35
	int n_entry    = 1;
	int rsltCount      =  0;
	int ValCnt      =  0;
	int CntrCount = 0,ByPasQCount = 0,CheckBypasFlag=0;
	int	n_Input = 2;
	int DRValiFlag=0;
	int iTemp=0;
	int desclength = 0,index1=0;
	int desccnt = 0,n_entries=2;
	int c_attchs = 0,p=0;
	int n_dfqentry = 1;
	int rsltDfqCount = 0;
	int Key_qry_entry = 1;
	int CntlObjCount = 0;
	int intDay = 0;
	int intMonth = 0;
	int intYear = 0;
	int rev_cnt = 0;
	int iji = 0;
	int FlagKey = 0;
	int outobjcnt = 0;
	int	n_InputC = 2;
	int MilStflg=0;
	int iPPRid = 0;
	int PartCreationBypassFlag = 0;
	//int n_found = 0;
	int ClrBomEtry = 1;
	int ClrBOMQryC =0;
	int PrtClassFlag =0;
	int n_cntrlfound=0, i= 0;
	int n_attchs_ds = 0, jr=0;
	int countConfigCtx = 0;

	char *desid = NULL;
	char *type_name = NULL;
	char *Desc = NULL;
	char *NewDesc = NULL;
	char *DerRoleNme = NULL; //14.3 Check API help if there is issue
	char *DerRoleNme1 = NULL;
	char *NewDescription = NULL;
	char *objname = NULL;
	char *objMat = NULL;
	char *objMatThickness = NULL;
	char *objOppHandDrg = NULL;
	char *objRefDrw = NULL;
	char *objSurfStd = NULL;
	char *ActGmName = NULL;
	char *ActGmName1 = NULL;
	char *DrwName		= NULL;
	char *DrwName1		= NULL;
	char *parent_name	= NULL;
	char *group_name	= NULL;
	char *Role_name		= NULL;
	char *Grp_name		= NULL;
	char *Desc_obj2		= NULL;
	char *item_rev_id	= NULL;
	char *currpro		= NULL;
	char *ObjectClassType		= NULL;
	char *ObjectName		= NULL;
	char *desi_grp		= NULL;
	char* oojname = NULL;
	char* username = NULL;
	char *ObjProject= NULL;
	//char *dst_name = NULL;
	char *objPartType = NULL;
	char *object_typeDS = NULL;
	char *DesignGrp = "60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,54,16";//Adi
	char *DesignGrpCatia = NULL;//Adi
	char *Rev_id = NULL;//Adi
	char *Rev_Sub = NULL;//Adi
	char *Rev_Sub1 = NULL;//Adi
	char *PartTypeDR = 0; //Adi
	char *ObjectTypeX = NULL;
	char *Desc_obj = NULL;
	char *STDesGrp = NULL; //Adi ST
	char *DesgTyp	= NULL;
	char *info1	= NULL;
	char *MPart_Desg	= NULL;
	char *Part_DegGrp	= NULL;
	char *Part_type		= NULL;
	char *Part_prj	= NULL;
	char *DesgNo	= NULL;
	char *sDesgNoG	= NULL;
	char *sDesgNoT	= NULL;
	char *sDesgNoT1	= NULL;
	char *sDesgNoTN	= NULL;
	char *sDesgNoVC	= NULL;
	char *sDesgNoV	= NULL;
	char *sDesgNoVCCR	= NULL;
	char *PrtProj	= NULL;
	char *info2	= NULL;
	char *Prttyp	= NULL;
	char *PrtDR	= NULL;
	char *sDesgNoD	= NULL;
	char *Part_Desg	= NULL;
	char *Part_Proj	= NULL;
	char *Proj_typ		= NULL;
	char *ThirdBarrel    = NULL;
	char *ForthBarrel    = NULL;
	char *SpareCrit      = NULL;
	char *type_Proj      = NULL;
	//char **val=NULL;
	char   *desidForTRL=NULL;
	char   *sLastThreeChar=NULL;
	char   *NewIDTRL=NULL;
	char   *RepalcedID=NULL;
	char	*DesgTypTRL	= NULL;
	char	*info4	= NULL;
	char *PrtCol = NULL;
	char *PrtClass = NULL;
	char *release_status = NULL;

	char *info3 = NULL;
	char *info5 = NULL;
	char *info6 = NULL;
	char *info7 = NULL;
	char *info8 = NULL;
	char *info9 = NULL;
	char *info10 = NULL;
	char *DitemRev_ID = NULL;
	char *Ditem_ID = NULL;
	char *Ditem_ID2 = NULL;
	char *CreationDate = NULL;
	char *rlstatus = NULL;
	char *AhdMkByInd = NULL;
	char *CarMkByInd = NULL;
	char *DwdMkByInd = NULL;
	char *JsrMkByInd = NULL;
	char *JdlMkByInd = NULL;
	char *LkoMkByInd = NULL;
	char *PnrMkByInd = NULL;
	char *PCBUMkByInd = NULL;
	char *PuneMkByInd = NULL;
	char *PuneUVMkByInd = NULL;
	char *SrgMkByInd = NULL;
	char *R_Date = NULL;
	char *month = NULL;
	char *day = NULL;
	char *Year = NULL;
	char *ReqKeyWord = NULL;
	char *PrevKeyWord = NULL;
	char *info1_value = NULL;
	char *token = NULL;
	char *ClrIndicator = NULL;
	char *RefPartNumber	= NULL;
	char *DesgNoFound	= NULL;
	char *ErrorString = NULL;
	char *DesRNo = NULL;
	char *DesgTypPPR	= NULL;
	char *desidForPPR=NULL;
	char *sLastFourChar=NULL;
	char *ProSubStr =NULL;
	char *BussiNameS =NULL; //Added By Sudhir...
	char* moduleAddress = NULL;
	char *DescRevprtType=NULL;
	char *ModuleAddrs=NULL;
	char *Revtype_name=NULL;
	char *user_Info_01=NULL;
	char *user_Info_02=NULL;
	char *user_Info_03=NULL;
	char *ERROR_MODULE_NPR=NULL;
	char *sesOrgUsrName1Dup=NULL;
	char *groupname1 = NULL;
	char *groupname	= NULL;
	char *grpName = NULL;
	char *projectName = NULL;
	char *rolename = NULL;
	char *role_Name	= NULL;
	char *userName = NULL;
	char *DSCurrent_Name=NULL;
	char *Specifictype_name=NULL;
	char *DSobject_name=NULL;
	char *DSobject_string=NULL;
	char *DesgRev=NULL;

	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));
	char *qry_entries[2] = {"Name","Type"},
         *qry_values[2]	= {"*","CMI2Drawing"};

	char *qry_entry[1] = {"SYSCD"};
	char **qry_values2 = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values3 = (char **) MEM_alloc(10 * sizeof(char *));

	char **qry_dfqCtrObjct =  (char **) MEM_alloc(10 * sizeof(char *));

	char *qry_Input[2] = {"SYSCD", "SUBSYSCD"};
	char *qry_InputVal[2] = {"TRILIX", "TRILIX"};
	char *qry_BypVal[2] = {"VALDBYPASS", "DSGPROJ"};

	char *QryCntr_entry[1]	= {"SYSCD"};
	char **QryCntr_values    = (char **) MEM_alloc(10 * sizeof(char *));

	char *ClrBomQryEtry[1] = {"SYSCD"};
	char **ClrBOMQryVal =  (char **) MEM_alloc(100 * sizeof(char *));

	//char *qryParty_Input[2] = {"ID", "Ref Part Number"};//MBOM implementation for CV TZ-1.69
	char *qryParty_Input[2] = {"ID", "Party Part Number"};//MBOM implementation for CV TZ-1.69

	char	*qry_entries1[2] = {"SUBSYSCD", "SYSCD"},
			*qry_values1[2] =  {"*", "MATCLS"};

	char *ctrl_qry_entries[2] = {"SYSCD","SUBSYSCD"},
		 *ctrl_qry_values[2]	= {"*","*"};

	tag_t objTypeTag = NULLTAG , item_tag = NULLTAG;
	tag_t rev=NULLTAG;
	tag_t queryTag = NULLTAG;
	tag_t* resultTags =NULLTAG;
	tag_t attr_id = NULLTAG;
	tag_t *attachments = NULLTAG;
	tag_t *GmFound = NULLTAG;
	tag_t *GmFound1 = NULLTAG;
	tag_t *GmFound2 = NULLTAG;
	tag_t *GmFound3 = NULLTAG;
	tag_t form_attr_id ;
	tag_t relation_type = NULLTAG;
	tag_t DesRolTag = NULLTAG;
	tag_t Currproj = NULLTAG;
	tag_t GroupMem = NULLTAG;
	tag_t Roletag = NULLTAG;
	tag_t grptag = NULLTAG;
	tag_t projobj = NULLTAG;
	tag_t dataset = NULLTAG;
	tag_t ActGm = NULLTAG;
	tag_t ActGm1 = NULLTAG;
	tag_t status_rel = NULLTAG;
	tag_t projid = NULLTAG;
	tag_t tagItem=NULLTAG;
	tag_t reln_type =NULLTAG;
	tag_t *secondary_objects=NULLTAG;
	tag_t user_tag=NULLTAG;
	tag_t *DiAttached = NULLTAG;
	tag_t rev1 = NULLTAG;
	tag_t relation_typeX  = NULLTAG;
	tag_t objMasterTag = NULLTAG; //Adi 1.35
	tag_t *rev_list1 = NULLTAG; //Adi 1.35
	tag_t qryTag = NULLTAG;//1.25
	tag_t qryTag1 = NULLTAG;//1.25
	tag_t *CntrlObjectTag = NULLTAG;
	tag_t *CntrlObjectTag11 = NULLTAG;
	tag_t *ValCntrlObjectTag1 = NULLTAG;
	tag_t Project_t = NULLTAG;
	tag_t ObjTypProj = NULLTAG;
	tag_t TagQryContObjSite = NULLTAG;
	tag_t PrtCls =	NULLTAG;
	tag_t primary = NULLTAG;
	tag_t latest_datas=NULLTAG;
	tag_t objTypeTagDi = NULLTAG;
	tag_t CurrentRoleTag = NULLTAG;
	tag_t CntrlObjQry = NULLTAG;
	tag_t DItem_tag = NULLTAG;
	tag_t LatestRev_tag = NULLTAG;
	tag_t *CntObj_Tag2 = NULLTAG;
	tag_t *rev_list_set = NULLTAG;
	tag_t ClrInd_CtrObjQryTag = NULLTAG;
	tag_t *ClrBOMCtrObj =NULLTAG;
	tag_t TagQryPartyPart = NULLTAG;
	tag_t *Res_des_objs = NULLTAG;
	tag_t Destag = NULLTAG;
	tag_t query = NULLTAG, *cntr_objects = NULLTAG;
	tag_t latestitemrev = NULLTAG;
	tag_t RevobjTypeTag = NULLTAG;
	tag_t *ControlObjects = NULLTAG;
	tag_t CtrlObjectItem = NULLTAG;
	tag_t usertag = NULLTAG;
	tag_t Group_Mem = NULLTAG;
	tag_t CurrentRole_Tag = NULLTAG;
	tag_t ControlObjQryTag = NULLTAG;
	tag_t userSession = NULLTAG;
	tag_t reln_typeDvp =NULLTAG;
	tag_t SpecifiTypeTag =NULLTAG;
	tag_t *secondary_ds =NULLTAG;

	logical	checkout = 0;
	logical	checkoutp = 0;
	logical retain = 0;
	logical	promem = 0;
	logical isNewpartReq = false;
	logical isNewpartReqByPass = false;

	//Rohit Starts
	//	tag_t		*bvrss			=	NULLTAG;
	//	tag_t		bvr				=	NULLTAG;
	//	tag_t		*occsal			=	NULLTAG;
	//	tag_t		*Effobbj		=	NULLTAG;
	//	tag_t		nChildItem		=	NULLTAG;
	//	tag_t		nbvrchild		=	NULLTAG;
	//	tag_t		tagref			=	NULLTAG;
	//	tag_t		*referencersV	=	NULLTAG;
	//	tag_t		objTypeTagV		=	NULLTAG;
	//	tag_t		status_reviewV	=	NULLTAG;
	//	int    bvr_count	=	0;
	//	int n_occs=0;
	//	int iy	=	0;
	//	int iz	=	0;
	//	int occsal_arr	=	0;
	//	int		effcnt = 0;
	//	int	n_parentsV = 0;
	//	int *levelsV	   = 0;
	//	int il		= 0;
	//	int n_referencersV = 0;
	//	char *CItem_ID		= NULL;
	//	char *PItem_ID		= NULL;
	//	char *P_type		= NULL;
	//	char *DML_task		= NULL;
	//	char *C_DsgGrp		= NULL;
	//	char *C_item_id		= NULL;
	//	char *bvrItem_ID	= NULL;
	//	char *bvrDsgGrp		= NULL;
	//	char *occurrence_name = NULL;
	//	char *nocc_item_id	= NULL;
	//	char *nocc_rev_id	= NULL;
	//	char **relationsRefV = NULL;
	//	char  type_nameV[TCTYPE_name_size_c+1];
	//	tag_t cvprod_CntrlOBJB		=	NULLTAG;
	//	tag_t *CntrlObject_cvprodB	=	NULLTAG;
	//	int cvprod_entriesB			=	1;
	//	int	cvprod_foundB			=	0;
	//	char	*info6cv			=	NULL;
	//	char *qry_cvprodcntrlB[1] = {"SYSCD"};
	//	char **qry_valuescvprodB = (char **) MEM_alloc(10 * sizeof(char *));
	//
	//	qry_valuescvprodB[0] = "CVBUBOMCntrlObjCOPY";
	//Rohit Ends

	printf("\n In save_method_4----------------------------------");fflush(stdout);

	POM_get_user(&username,&user_tag);
	//printf("\n save_method_4--1");fflush(stdout);

	if (objTag)
	{
		if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
		//printf("\n save_method_4--2");fflush(stdout);

		if (objTypeTag)
		{
			if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
			//printf("\n save_method_4--3");fflush(stdout);
		}
		if (AOM_ask_value_string(objTag,"item_id",&DesgNo)!=ITK_ok) PrintErrorStack();
		//printf("\n save_method_4--5");fflush(stdout);
	}
	else
	{
		printf("\n save_method_4--objTag is not found ???");fflush(stdout);
	}

	//Sagar Start
	printf("\n save_method_4--type_name = [%s]  DesgNo: [%s]  ",type_name,DesgNo);fflush(stdout);

	if(tc_strcmp(type_name,"T5_PeDesignRevision")==0)
	{
		printf("\n save_method_4--IT IS PE PART OBJECT HENCE EXIT!!! ***save_method_4***");fflush(stdout);
		return ITK_ok;
	}

	//RAJAN 1.0
	if(tc_strcmp(type_name,"Design Revision")==0)
	{
		if(GRM_find_relation_type("IMAN_specification",&reln_typeDvp)!=ITK_ok) PrintErrorStack();
		if(GRM_list_secondary_objects_only(objTag,reln_typeDvp,&n_attchs_ds,&secondary_ds)!=ITK_ok) PrintErrorStack();
		printf("\n\t save_method_4--RAJAN 1.0 ... Configuration Context count is : %d",countConfigCtx);

		for (jr=0;jr<n_attchs_ds;jr++ )
		{
			if(TCTYPE_ask_object_type(secondary_ds[jr],&SpecifiTypeTag)!=ITK_ok) PrintErrorStack();
			if(TCTYPE_ask_name2(SpecifiTypeTag,&Specifictype_name)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(secondary_ds[jr],"current_name",&DSCurrent_Name)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(secondary_ds[jr],"object_name",&DSobject_name)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(secondary_ds[jr],"object_string",&DSobject_string)!=ITK_ok) PrintErrorStack();
			printf("\n save_method_4--RAJAN 1.0 ...Start--save_method_4 :: [%s] DSCurrent_Name:[%s] OnjName: [%s] ObjStr: [%s]", Specifictype_name,DSCurrent_Name,DSobject_name,DSobject_string);fflush(stdout);
		}
	}

	/*START ADD VALIDATION FOR NEW PART REQUEST FOR SUB-MODULE CREATION*/
	POM_get_user(&sesOrgUsrName1Dup,&usertag);
	SA_ask_current_groupmember(&Group_Mem);
	if(Group_Mem !=NULLTAG)
	{
		AOM_ask_value_string(Group_Mem,"object_name",&groupname1);
		printf("\n save_method_4--group_name session is  : %s ",groupname1);fflush(stdout);
		groupname=strtok(groupname1,"/");
		printf("\n save_method_4--Group_name session is  : %s ",groupname);fflush(stdout);
	}

	SA_ask_current_role(&CurrentRole_Tag);
	SA_ask_role_name2(CurrentRole_Tag,&role_Name);
	printf("\n save_method_4--role_Name: [%s]",role_Name);fflush(stdout);

	CE_current_user_session_tag(&userSession);

	AOM_ask_value_string(userSession,"group_name",&grpName);
	printf("\n save_method_4--grpName====>[%s]", grpName);fflush(stdout);

	AOM_ask_value_string(userSession,"project_name",&projectName);
	printf("\n save_method_4--projectName====>[%s]", projectName);fflush(stdout);

	AOM_ask_value_string(userSession,"role_name",&rolename);
	printf("\n save_method_4--roleName====>[%s]", rolename);fflush(stdout);

	AOM_ask_value_string(userSession,"user_id",&userName);
	printf("\n save_method_4--userName====>[%s]", userName);fflush(stdout);

	printf("\n save_method_4--flag [%d] ",flag);fflush(stdout);
	//if(flag==true || flag==1 || flag==0)
	if(flag==true || flag==1)
	{
		if(objTag!=NULLTAG)
		{
			if (TCTYPE_ask_object_type(objTag,&RevobjTypeTag)!=ITK_ok) PrintErrorStack();
			if (TCTYPE_ask_name2(RevobjTypeTag,&Revtype_name)!=ITK_ok) PrintErrorStack();
			printf("\n save_method_4--Revtype_name [%s] ",Revtype_name);fflush(stdout);

			if((tc_strstr(groupname,"ERC")!=NULL || tc_strstr(groupname,"CAB")!=NULL) &&
			   (tc_strstr(rolename,"CAB")!=NULL || tc_strstr(rolename,"Designers")!=NULL || tc_strstr(rolename,"Managers")!=NULL))
			{
			if(tc_strcmp(Revtype_name,"Design Revision")==0)
			{
				if( AOM_UIF_ask_value(objTag,"t5_PartType",&DescRevprtType)!=ITK_ok) PrintErrorStack();

				printf("\n save_method_4--DescRevprtType [%s] ",DescRevprtType);fflush(stdout);
				if(tc_strcmp(DescRevprtType,"Module")==0 || tc_strcmp(DescRevprtType,"M")==0 || tc_strcmp(DescRevprtType,"IFD Module")==0 || tc_strcmp(DescRevprtType,"IM")==0 || tc_strcmp(DescRevprtType,"ECU Module")==0 || tc_strcmp(DescRevprtType,"EM")==0)
				{
					int IsModule = 0;
					if( AOM_UIF_ask_value(objTag,"t5_ModuleAddress",&ModuleAddrs)!=ITK_ok) PrintErrorStack();
					printf("\n save_method_4--ModuleAddrs [%s] ",ModuleAddrs);fflush(stdout);
					IsModule = FunToQuery_ModuleAddress(ModuleAddrs);
					printf("\n save_method_4--IsModule [%d] ",IsModule);fflush(stdout);
					isNewpartReq = false;
					isNewpartReqByPass=false;
					ctrl_qry_values[0]	= "NPRNotReqdForModuleAddress";
					ctrl_qry_values[1]	= "NPRNotReqdForModuleAddress";
					if(QRY_find2("ControlObjects", &ControlObjQryTag)!=ITK_ok) PrintErrorStack();
					if(QRY_execute(ControlObjQryTag, 2, ctrl_qry_entries, ctrl_qry_values, &n_cntrlfound, &ControlObjects)!=ITK_ok) PrintErrorStack();
					if(n_cntrlfound>0)
					{
						for (i = 0; i < n_cntrlfound; i++)
						{
							CtrlObjectItem = ControlObjects[i];
							if( AOM_UIF_ask_value(CtrlObjectItem,"t5_Userinfo1",&user_Info_01)!=ITK_ok) PrintErrorStack();
							if( AOM_UIF_ask_value(CtrlObjectItem,"t5_Userinfo2",&user_Info_02)!=ITK_ok) PrintErrorStack();
							if( AOM_UIF_ask_value(CtrlObjectItem,"t5_Userinfo3",&user_Info_03)!=ITK_ok) PrintErrorStack();
							if(tc_strstr(user_Info_01,ModuleAddrs)!=NULL || tc_strstr(user_Info_02,ModuleAddrs)!=NULL || tc_strstr(user_Info_03,ModuleAddrs)!=NULL)
							{
								isNewpartReqByPass=true;
							}
						}
					}
					if((isNewpartReqByPass==0 || isNewpartReqByPass==false) && (tc_strlen(DesgNo)==14) && (IsModule==1))
					{
						isNewpartReq = IsNewpartRequestAvail(DesgNo);
					}
					else
					{
						isNewpartReq=true;
					}
					printf("\n save_method_4--isNewpartReq: [%d]  isNewpartReqByPass: [%d]",isNewpartReq,isNewpartReqByPass);fflush(stdout);

					if((isNewpartReq==0 && isNewpartReqByPass==0))
					{
						//FILE* fptr = NULL;
						//char *file_name = NULL;
						//char *file_loc = NULL;
						//file_name = (char *) MEM_alloc( 100 * sizeof(char));
						//file_loc = (char *) MEM_alloc( 100 * sizeof(char));
						//strcpy(file_name,DesgNo);
						//strcat(file_name,"_NPRERROR.txt");
						//strcpy(file_loc,"/tmp/");
						//strcat(file_loc,file_name);
						//fptr=fopen(file_loc,"w");
						//fprintf(fptr,"%s~",ERROR_MODULE_NPR);
						//fclose(fptr);

						ERROR_MODULE_NPR = (char *) MEM_alloc( 1000 * sizeof(char) );
						strcpy(ERROR_MODULE_NPR,"New Part Request for Sub Module Number ");
						strcat(ERROR_MODULE_NPR,DesgNo);
						strcat(ERROR_MODULE_NPR," is not Created");
						printf("\n save_method_4--ERROR_MODULE_NPR [%s] ",ERROR_MODULE_NPR);fflush(stdout);

						EMH_clear_errors();
						error_code=t9NewPartReqCre_Val0048;
						EMH_store_error_s1(EMH_severity_error,error_code, ERROR_MODULE_NPR);
						return error_code;
					}
					if((isNewpartReq==1 && isNewpartReqByPass==0))
					{
						char *TempNewModuleNumber = NULL;
						char *NprRaiser_id = NULL;
						char *Npr_id = NULL;
						char *ERROR_MODULE_NPR_Str = NULL;
						tag_t	NPRquery	= NULLTAG;
						tag_t	*NewPartReqObj	= NULLTAG;
						int n_nprfound	= 0;
						char
						*qname[1] = {"Tml Part Number"},
						*qvalue[1]	= {"*"};
						TempNewModuleNumber = (char *) MEM_alloc( 200 * sizeof(char));
						tc_strcpy(TempNewModuleNumber,"*");
						tc_strcat(TempNewModuleNumber,DesgNo);
						tc_strcat(TempNewModuleNumber,"*");
						printf("\n save_method_4--::TempNewModuleNumber =[%s]",TempNewModuleNumber);fflush(stdout);
						qvalue[0]	= TempNewModuleNumber;
						//qvalue[1]	= "New Part Request";
						if(QRY_find2("tm_NewPartRequest", &NPRquery)!=ITK_ok) PrintErrorStack();
						if(QRY_execute(NPRquery, 1, qname, qvalue, &n_nprfound, &NewPartReqObj)!=ITK_ok) PrintErrorStack();
						printf("\n save_method_4--::n_nprfound =[%d]",n_nprfound);fflush(stdout);
						if(n_nprfound>0)
						{
							if(AOM_UIF_ask_value(NewPartReqObj[0],"t5_NwRaisedBy",&NprRaiser_id)!=ITK_ok) PrintErrorStack();
							if(AOM_UIF_ask_value(NewPartReqObj[0],"item_id",&Npr_id)!=ITK_ok) PrintErrorStack();
							printf("\n save_method_4--NprRaiser_id =[%s]",NprRaiser_id);fflush(stdout);
							if(tc_strstr(userName,NprRaiser_id)!=NULL || tc_strcmp(userName,NprRaiser_id)==0)
							{
								printf("\n save_method_4--NprRaiser_id =[%s] gets matched with user[%s] ",NprRaiser_id,userName);fflush(stdout);
							}
							else
							{
								ERROR_MODULE_NPR_Str = (char *) MEM_alloc( 1000 * sizeof(char));
								strcpy(ERROR_MODULE_NPR_Str,"New Part Request[");
								strcat(ERROR_MODULE_NPR_Str,Npr_id);
								strcat(ERROR_MODULE_NPR_Str,"] for Sub Module Number[");
								strcat(ERROR_MODULE_NPR_Str,DesgNo);
								strcat(ERROR_MODULE_NPR_Str,"] is Created.\n");
								strcat(ERROR_MODULE_NPR_Str,"But You are not NPR Raiser[");
								strcat(ERROR_MODULE_NPR_Str,NprRaiser_id);
								strcat(ERROR_MODULE_NPR_Str,"].\nYou Should take your own New Part Request.");
								printf("\n save_method_4--ERROR_MODULE_NPR_Str [%s] ",ERROR_MODULE_NPR_Str);fflush(stdout);

								EMH_clear_errors();
								error_code=t9NewPartReqCre_Val0048;
								EMH_store_error_s1(EMH_severity_error,error_code, ERROR_MODULE_NPR_Str);
								return error_code;
							}
						}
					}
				}
			}
			}
		}
	}
	/*END ADD VALIDATION FOR NEW PART REQUEST FOR SUB-MODULE CREATION*/
	//neha -- color Ind

	//neha
	tag_t nt_Window		= NULLTAG;
	tag_t t_RRule		= NULLTAG;
	tag_t ItemTag		= NULLTAG;
	tag_t t_TLine		= NULLTAG;
	tag_t UseMaster		= NULLTAG;
	tag_t Nrev			= NULLTAG;
	tag_t t_Childobject = NULLTAG;
	tag_t TagCtrlQryContObj = NULLTAG;
	tag_t *t_PrtChldren = NULLTAG;
	char *ColInd_str	= NULL;
	char *cp_ItemID_str	= NULL;
	char *ColIndicator	= NULL;
	char *ColIndYPrt	= NULL;
	int ChildCount,iChPrts,iItemId = 0;
	//end neha

	char *ctrlQryEntries[2] = {"SYSCD", "SUBSYSCD"};
	char *ctrlQryValues[2] = {"ColIndValSave", "ColIndValSave1"};
	tag_t TagCtrlQryObj = NULLTAG,*ctrlCntrObj = NULL;
	int nEntr = 2;
	int nFnd = 0;

	if(QRY_find2("ControlObjQry", &TagCtrlQryObj)!=ITK_ok) PrintErrorStack();
	if(QRY_execute(TagCtrlQryObj, nEntr, ctrlQryEntries, ctrlQryValues, &nFnd, &ctrlCntrObj)!=ITK_ok) PrintErrorStack();
	printf("\n save_method_4--Objects for Query ControlObjQry from structure manager validation of save method 4 : %d", nFnd);fflush(stdout);

	if(nFnd > 0)
	{
		if(BOM_create_window (&nt_Window) !=ITK_ok) PrintErrorStack();
		printf("\nsave_method_4::After nt_Window ");fflush(stdout);
		if(CFM_find( "Latest Working", &t_RRule )!=ITK_ok) PrintErrorStack();
		printf("\nsave_method_4::After t_RRule ");fflush(stdout);
		if(BOM_set_window_config_rule(nt_Window, t_RRule )!=ITK_ok) PrintErrorStack();
		printf("\nsave_method_4::After BOM_set_window_config_rule ");fflush(stdout);
		if(BOM_set_window_pack_all (nt_Window, true)!=ITK_ok) PrintErrorStack();
		printf("\nsave_method_4::After BOM_set_window_pack_all ");fflush(stdout);
		if(BOM_set_window_top_line (nt_Window, ItemTag, objTag, NULLTAG, &t_TLine)!=ITK_ok) PrintErrorStack();
		printf("\nsave_method_4::After BOM_set_window_top_line ");fflush(stdout);
		if(t_TLine!=NULLTAG)
		{
			printf("\nsave_method_4::Inside t_Tline ");fflush(stdout);
			if(BOM_line_ask_child_lines (t_TLine, &ChildCount, &t_PrtChldren)!=ITK_ok) PrintErrorStack();
			printf("\nsave_method_4::After BOM_line_ask_child_lines ");fflush(stdout);
		}
		printf("\n save_method_4--Child Parts Found in BomLine are :: [%d] ",ChildCount);fflush(stdout);

		if(ChildCount > 0)
		{
			for (iChPrts = 0; iChPrts < ChildCount; iChPrts++)
			{
				if(t_Childobject) t_Childobject=NULLTAG;
				t_Childobject=t_PrtChldren[iChPrts];

				if(AOM_ask_value_string(objTag,"t5_ColourInd",&ColInd_str)!=ITK_ok) PrintErrorStack();
				if( AOM_ask_value_string(t_Childobject,"bl_item_item_id",&cp_ItemID_str)!=ITK_ok) PrintErrorStack();
				printf("\n save_method_4--Color Indicator: [%s] cp_ItemIDD_str: [%s]",ColInd_str,cp_ItemID_str);

				if(ITEM_find_item(cp_ItemID_str,&UseMaster)!=ITK_ok) PrintErrorStack();
				//printf("\n save_method_4--UseMaster found------>");

				if(ITEM_ask_latest_rev(UseMaster, &Nrev)!=ITK_ok) PrintErrorStack();
				if(nFnd>0)
				{
					if(AOM_UIF_ask_value(Nrev,"t5_ColourInd",&ColIndicator)!=ITK_ok) PrintErrorStack();
					{
						printf("\n save_method_4--Inside Colour Ind: [%s] ",ColIndicator);fflush(stdout);
						if(tc_strcmp(ColInd_str,"N")==0 && tc_strcmp(ColIndicator,"Y")==0)
						{
							printf("\n save_method_4--Inside if condition  ");fflush(stdout);
							ColIndYPrt=(char *)MEM_alloc(200);
							tc_strcpy(ColIndYPrt,"");
							tc_strcat(ColIndYPrt,cp_ItemID_str);

							printf("\n save_method_4--One of the child part color indicator is Y ");fflush(stdout);

							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"The child part with colour indicator Y, cannot go below assembly with colour ind N. This is invalid combination of colour ind");
							return ITK_err;
						}
					}
				}
			}
		}
	}
	//end

	//Rohit validation Starts
	tag_t		*bvrss			=	NULLTAG;
	tag_t		bvr			=	NULLTAG;
	tag_t		*occsal			=	NULLTAG;
	tag_t		*Effobbj		=	NULLTAG;
	tag_t		nChildItem		=	NULLTAG;
	tag_t		nbvrchild		=	NULLTAG;
	tag_t		tagref			=	NULLTAG;
	tag_t		*referencersV	=	NULLTAG;
	tag_t		objTypeTagV		=	NULLTAG;
	tag_t		status_reviewV	=	NULLTAG;

	int    bvr_count	=	0;
	int n_occs=0;
	int iy	=	0;
	int iz	=	0;
	int occsal_arr	=	0;
	int		effcnt = 0;
	int	n_parentsV = 0;
	int *levelsV	   = 0;
	int il		= 0;
	int n_referencersV = 0;
	int cvprod_entriesB = 1;
	int cvprod_foundB = 0;

	char *CItem_ID		= NULL;
	char *PItem_ID		= NULL;
	char *P_type		= NULL;
	char *DML_task		= NULL;
	char *C_DsgGrp		= NULL;
	char *C_ModAddrss		= NULL;
	char *C_item_id		= NULL;
	char *bvrItem_ID	= NULL;
	char *bvrDsgGrp		= NULL;
	char *occurrence_name = NULL;
	char *nocc_item_id	= NULL;
	char *nocc_rev_id	= NULL;
	char *info6cv = NULL;
	char *info8cv = NULL;

	char **relationsRefV = NULL;

	char  type_nameV[TCTYPE_name_size_c+1];

	tag_t cvprod_CntrlOBJB		=	NULLTAG;
	tag_t *CntrlObject_cvprodB	=	NULLTAG;

	char *qry_cvprodcntrlB[1] = {"SYSCD"};
	char **qry_valuescvprodB = (char **) MEM_alloc(10 * sizeof(char *));

	qry_valuescvprodB[0] = "CVBUBOMCntrlObjCOPY";

	char	*objID				=	NULL;
	char	*objrevID			=	NULL;
	char	*latest_objIDstr	=	NULL;
	char	*latest_objrevstr	=	NULL;
	char	*vrlsstatusC			=   NULL;
	tag_t	latest_objID		=	NULLTAG;
	tag_t	latest_objrev		=	NULLTAG;
	tag_t	t_Window			=	NULLTAG;
	tag_t	t_revrule			=	NULLTAG;
	tag_t	topline_tbom		=	NULLTAG;
	tag_t   *tbom_childs		=	NULLTAG;
	tag_t	tc_Childobject = NULLTAG;

	int ChildCount_c			=	0;
	int iChPrts_c				=	0;

	if(QRY_find2("Control Objects...",&cvprod_CntrlOBJB)!=ITK_ok) PrintErrorStack();
	if(QRY_execute(cvprod_CntrlOBJB, cvprod_entriesB, qry_cvprodcntrlB, qry_valuescvprodB, &cvprod_foundB, &CntrlObject_cvprodB)!=ITK_ok) PrintErrorStack();
	printf("\n save_method_4--CVPROD Control Object SYSCD :[ %d ] ",cvprod_foundB);	fflush(stdout);

	if(cvprod_foundB > 0)
	{
		printf("\n save_method_4--CVPROD Control Object for SAVE AS functionality found ");	fflush(stdout);
		if (objTag)
		{
			printf("\n\n save_method_4--Inside if condition of objTag found \n");	fflush(stdout);
			if(AOM_ask_value_string(objTag,"item_id",&objID)!=ITK_ok) PrintErrorStack(); //Rohit BOM
			if(AOM_ask_value_string(objTag,"item_revision_id",&objrevID)!=ITK_ok) PrintErrorStack(); //Rohit BOM

			if(ITEM_find_item(objID,&latest_objID)!=ITK_ok) PrintErrorStack(); //Rohit BOM
			if(ITEM_ask_latest_rev(latest_objID,&latest_objrev)!=ITK_ok) PrintErrorStack(); //Rohit BOM
			if(AOM_ask_value_string(latest_objID,"item_id",&latest_objIDstr)!=ITK_ok) PrintErrorStack(); //Rohit BOM
			if(AOM_ask_value_string(latest_objrev,"item_revision_id",&latest_objrevstr)!=ITK_ok) PrintErrorStack(); //Rohit BOM

			if(AOM_ask_value_string(objTag,"t5_PartType",&P_type)!=ITK_ok) PrintErrorStack();
			printf("\n save_method_4--Type of parent is [%s] and revision ID is [%s] ",P_type,objrevID);fflush(stdout);

			if(AOM_UIF_ask_value(objTag,"release_status_list",&vrlsstatusC)!=ITK_ok) PrintErrorStack();
			printf("\n save_method_4--Released status for newly created vehicle is [%s]  ",vrlsstatusC); fflush(stdout);

			if(tc_strcmp(P_type,"V")==0)
			{
				if(tc_strcmp(objrevID,"NR;1")==0)
				{
					if(tc_strcmp(vrlsstatusC,"")==0)
					{
						printf("\n\n save_method_4--Expanding BOM as part type is vehicle for SAVE AS functionality ");	fflush(stdout);
						if(BOM_create_window(&t_Window)!=ITK_ok) PrintErrorStack();
						if(CFM_find("Latest Working", &t_revrule)!=ITK_ok) PrintErrorStack();
						if(BOM_set_window_config_rule( t_Window, t_revrule)!=ITK_ok) PrintErrorStack();
						if(BOM_set_window_pack_all(t_Window, true)!=ITK_ok) PrintErrorStack();
						if(BOM_set_window_top_line(t_Window,latest_objID,latest_objrev,NULLTAG,&topline_tbom)!=ITK_ok) PrintErrorStack();
						if(BOM_line_ask_child_lines(topline_tbom,&ChildCount_c,&tbom_childs)!=ITK_ok) PrintErrorStack();
						printf("\n save_method_4--Latest Item ID and Rev ID is [%s] and [%s] and child count is [%d] ",latest_objIDstr,latest_objrevstr,ChildCount_c); fflush(stdout);

						if(ChildCount_c > 0)
						{
							for (iChPrts_c = 0; iChPrts_c < ChildCount_c; iChPrts_c++)
							{
								if(AOM_ask_value_string(CntrlObject_cvprodB[0],"t5_Userinfo6",&info6cv)!=ITK_ok) PrintErrorStack();
								if(AOM_ask_value_string(CntrlObject_cvprodB[0],"t5_Userinfo8",&info8cv)!=ITK_ok) PrintErrorStack();
								printf("\n\n save_method_4--User Information 6 is : [%s] and Info 8 is [%s] \n",info6cv,info8cv);	fflush(stdout);

								if(tc_Childobject) tc_Childobject=NULLTAG;
								tc_Childobject=tbom_childs[iChPrts_c];

								if(AOM_ask_value_string(tc_Childobject,"bl_item_item_id",&CItem_ID)!=ITK_ok) PrintErrorStack();
								if(AOM_ask_value_string(tc_Childobject,"bl_Design Revision_t5_DesignGrp",&C_DsgGrp)!=ITK_ok) PrintErrorStack();
								if(AOM_ask_value_string(tc_Childobject,"bl_Design Revision_t5_ModuleAddress",&C_ModAddrss)!=ITK_ok) PrintErrorStack();

								printf("\n save_method_4--Item ID of Child is [%s] , its design group and Module Address is [%s][%s] \n",CItem_ID,C_DsgGrp,C_ModAddrss);

								if(ITEM_rev_list_bom_view_revs(objTag,&bvr_count,&bvrss)!=ITK_ok) PrintErrorStack();
								if(PS_list_occurrences_of_bvr(bvrss[0], &n_occs, &occsal)!=ITK_ok) PrintErrorStack();
								printf("\n\n save_method_4--n_occs is : [%d] \n",n_occs); fflush(stdout);
								if(n_occs > 0)
								{
									if(AOM_lock(bvrss[0])!=ITK_ok) PrintErrorStack();
									for (iz = 0; iz<n_occs; iz++)
									{
										if(PS_ask_occurrence_child(bvrss[0],occsal[iz], &nChildItem, &nbvrchild)!=ITK_ok) PrintErrorStack();
										if(AOM_ask_value_string(nChildItem, "item_id", &nocc_item_id)!=ITK_ok) PrintErrorStack();
										if (tc_strcmp(nocc_item_id,CItem_ID)==0)
										{
											if ((tc_strstr(info6cv,C_DsgGrp) !=NULL) || (tc_strstr(info8cv,C_ModAddrss) !=NULL))
											{
												printf("\n save_method_4--nocc_item_id & child_item_id  is [%s] and [%s] \n ",nocc_item_id,C_DsgGrp);fflush(stdout);
												if(PS_delete_occurrence(bvrss[0], occsal[iz])!=ITK_ok) PrintErrorStack();
												if(AOM_save_without_extensions( bvrss[0] )!=ITK_ok) PrintErrorStack();
												if(AOM_unlock( bvrss[0] )!=ITK_ok) PrintErrorStack();
												printf("\n save_method_4--Deleted Successfuly \n ");fflush(stdout);
											}
											else
											{
												char *AhdViewMask = NULL;
												char *CarViewMask = NULL;
												char *DwdViewMask = NULL;
												char *JsrViewMask = NULL;
												char *JdlViewMask = NULL;
												char *LkoViewMask = NULL;
												char *PnrViewMask = NULL;
												char *PCBUViewMask = NULL;
												char *PuneViewMask = NULL;
												char *PuneUVViewMask = NULL;
												//char *SrgViewMask = NULL;
												if(AOM_ask_value_string(tc_Childobject,"bl_occ_t5_CurrentViewMaskA",&AhdViewMask)!=ITK_ok) PrintErrorStack();
												if(AOM_ask_value_string(tc_Childobject,"bl_occ_t5_CurrentViewMaskC",&CarViewMask)!=ITK_ok) PrintErrorStack();
												if(AOM_ask_value_string(tc_Childobject,"bl_occ_t5_CurrentViewMaskD",&DwdViewMask)!=ITK_ok) PrintErrorStack();
												if(AOM_ask_value_string(tc_Childobject,"bl_occ_t5_CurrentViewMaskJ",&JsrViewMask)!=ITK_ok) PrintErrorStack();
												if(AOM_ask_value_string(tc_Childobject,"bl_occ_t5_CurrentViewMaskL",&JdlViewMask)!=ITK_ok) PrintErrorStack();
												if(AOM_ask_value_string(tc_Childobject,"bl_occ_t5_CurrentViewMaskM",&LkoViewMask)!=ITK_ok) PrintErrorStack();
												if(AOM_ask_value_string(tc_Childobject,"bl_occ_t5_CurrentViewMaskP",&PnrViewMask)!=ITK_ok) PrintErrorStack();
												if(AOM_ask_value_string(tc_Childobject,"bl_occ_t5_CurrentViewMaskV",&PCBUViewMask)!=ITK_ok) PrintErrorStack();
												if(AOM_ask_value_string(tc_Childobject,"bl_occ_t5_CurrentViewMaskS",&PuneViewMask)!=ITK_ok) PrintErrorStack();
												if(AOM_ask_value_string(tc_Childobject,"bl_occ_t5_CurrentViewMaskU",&PuneUVViewMask)!=ITK_ok) PrintErrorStack();
												//if(AOM_ask_value_string(tc_Childobject,"bl_Design Revision_t5_SgrMakeBuyIndicator",&SrgViewMask)!=ITK_ok) PrintErrorStack();

												printf("\n save_method_4-- AhdViewMask = [%s] ", AhdViewMask);fflush(stdout);
												printf("\n save_method_4-- CarViewMask = [%s] ", CarViewMask);fflush(stdout);
												printf("\n save_method_4-- DwdViewMask = [%s] ", DwdViewMask);fflush(stdout);
												printf("\n save_method_4-- JsrViewMask = [%s] ", JsrViewMask);fflush(stdout);
												printf("\n save_method_4-- JdlViewMask = [%s] ", JdlViewMask);fflush(stdout);
												printf("\n save_method_4-- LkoViewMask = [%s] ", LkoViewMask);fflush(stdout);
												printf("\n save_method_4-- PnrViewMask = [%s] ", PnrViewMask);fflush(stdout);
												printf("\n save_method_4-- PCBUViewMask = [%s] ", PCBUViewMask);fflush(stdout);
												printf("\n save_method_4-- PuneViewMask = [%s] ", PuneViewMask);fflush(stdout);
												printf("\n save_method_4-- PuneUVViewMask = [%s] ", PuneUVViewMask);fflush(stdout);
												//printf("\n save_method_4-- SrgViewMask = [%s] ", SrgViewMask);fflush(stdout);
												if (tc_strlen(AhdViewMask)!=0)
												{
													if(AOM_set_value_string(tc_Childobject, "bl_occ_t5_CurrentViewMaskA","")!=ITK_ok) PrintErrorStack();
												}
												if (tc_strlen(CarViewMask)!=0)
												{
													if(AOM_set_value_string(tc_Childobject, "bl_occ_t5_CurrentViewMaskC","")!=ITK_ok) PrintErrorStack();
												}
												if (tc_strlen(DwdViewMask)!=0)
												{
													if(AOM_set_value_string(tc_Childobject, "bl_occ_t5_CurrentViewMaskD","")!=ITK_ok) PrintErrorStack();
												}
												if (tc_strlen(JsrViewMask)!=0)
												{
													if(AOM_set_value_string(tc_Childobject, "bl_occ_t5_CurrentViewMaskJ","")!=ITK_ok) PrintErrorStack();
												}
												if (tc_strlen(JdlViewMask)!=0)
												{
													if(AOM_set_value_string(tc_Childobject, "bl_occ_t5_CurrentViewMaskL","")!=ITK_ok) PrintErrorStack();
												}
												if (tc_strlen(LkoViewMask)!=0)
												{
													if(AOM_set_value_string(tc_Childobject, "bl_occ_t5_CurrentViewMaskM","")!=ITK_ok) PrintErrorStack();
												}
												if (tc_strlen(PnrViewMask)!=0)
												{
													if(AOM_set_value_string(tc_Childobject, "bl_occ_t5_CurrentViewMaskP","")!=ITK_ok) PrintErrorStack();
												}
												if (tc_strlen(PCBUViewMask)!=0)
												{
													if(AOM_set_value_string(tc_Childobject, "bl_occ_t5_CurrentViewMaskV","")!=ITK_ok) PrintErrorStack();
												}
												if (tc_strlen(PuneViewMask)!=0)
												{
													if(AOM_set_value_string(tc_Childobject, "bl_occ_t5_CurrentViewMaskS","")!=ITK_ok) PrintErrorStack();
												}
												if (tc_strlen(PuneUVViewMask)!=0)
												{
													if(AOM_set_value_string(tc_Childobject, "bl_occ_t5_CurrentViewMaskU","")!=ITK_ok) PrintErrorStack();
												}
											}
										}
									}
								}
							}

							//printf("\nClosing Bom Window ");fflush(stdout);
							//if(BOM_close_window (t_Window)!=ITK_ok) PrintErrorStack();
							//printf("\nAfter Closing Bom Window ");fflush(stdout);
							logical retain_released_date =TRUE;
							printf("\n save_method_4--BEFORE stamping Review status ");fflush(stdout);
							if(RELSTAT_create_release_status("T5_LcsReview",&status_reviewV)!=ITK_ok) PrintErrorStack();
							if(RELSTAT_add_release_status(status_reviewV,1,&objTag,retain_released_date)!=ITK_ok) PrintErrorStack();
							printf("\n save_method_4--After stamping Review status ");fflush(stdout);
						}
					}//Release
				}
			}
		}
		else
		{
			printf("\n save_method_4--objTag is not found....!");fflush(stdout);
		}

	}
	//Rohit validation Ends

	/****************************************Rohit Validation starts for Platform Name attribute*********************************/
	tag_t platformcr_CntrlOBJ = NULLTAG;
	int platformcr_entries = 1;
	int platcr_found = 0;
	tag_t *CntrlObject_platcr = NULLTAG;

	if(QRY_find2("Control Objects...",&platformcr_CntrlOBJ)!=ITK_ok) PrintErrorStack();
	printf("\n save_method_4--platform_create::Platform Query Found\n ");	fflush(stdout);

	char *qry_platcrcntrl[1] = {"SYSCD"};
	char **qry_valuesplatcr = (char **) MEM_alloc(10 * sizeof(char *));
	qry_valuesplatcr[0] = "platform_create";

	if(QRY_execute(platformcr_CntrlOBJ, platformcr_entries, qry_platcrcntrl, qry_valuesplatcr, &platcr_found, &CntrlObject_platcr)!=ITK_ok) PrintErrorStack();
	printf("\n\n save_method_4--Platform SYSCD :%d ",platcr_found);	fflush(stdout);
	if(platcr_found>0)
	{
		tag_t user_tagPP = NULLTAG;
		tag_t PP_CntrlOBJ = NULLTAG;
		tag_t *CntrlObject_PP	= NULLTAG;

		char *useridPP = NULL;
		char *usernamePP = NULL;
		char *homeSitePP = NULL;
		char *qry_PPcntrl[1] = {"SYSCD"};

		char **qry_valuesPP = (char **) MEM_alloc(10 * sizeof(char *));
		qry_valuesPP[0] = "PartPlatform";

		char		*pp_itemid			=	NULL;
		char		*pp_revisionid		=	NULL;
		char		*pp_parttype		=	NULL;
		char		*pp_PartPlatform	=	NULL;
		char		*info1PP			=	NULL;
		char		*info2PP			=	NULL;
		char		*pp_projectcode		=	NULL;

		int PP_entries			=	1;
		int	PP_found			=	0;
		int pp					=	0;

		POM_get_user(&usernamePP,&user_tagPP);
		SA_ask_user_identifier2 (user_tagPP,&useridPP);
		printf ("\n save_method_4--Logged in user for Platform attribute updation is :[%s] [%s] ",useridPP,usernamePP);fflush(stdout);

		if(AOM_UIF_ask_value(user_tagPP,"fnd0home_site",&homeSitePP)!=ITK_ok) PrintErrorStack();
		printf("\n save_method_4--Logged in fnd0home_site for Platform attribute updation is : [%s]",homeSitePP);fflush(stdout);

		if (strcmp(homeSitePP,"CV_Production")==0)
		{
			printf("\n save_method_4--Inside our home site - CVPROD"); fflush(stdout);

			if(AOM_ask_value_string(objTag,"item_id",&pp_itemid)!=ITK_ok) PrintErrorStack();
			if(AOM_ask_value_string(objTag,"item_revision_id",&pp_revisionid)!=ITK_ok) PrintErrorStack();
			if(AOM_ask_value_string(objTag,"t5_PartType",&pp_parttype)!=ITK_ok) PrintErrorStack();
			if(AOM_ask_value_string(objTag,"t5_Platform",&pp_PartPlatform)!=ITK_ok) PrintErrorStack();
			if(AOM_ask_value_string(objTag,"t5_ProjectCode",&pp_projectcode)!=ITK_ok) PrintErrorStack();

			if((tc_strcmp(pp_parttype,"V")==0))
			{
				printf("\n save_method_4--Part Type is Vehicle hence inside loop "); fflush(stdout);

				if(tc_strcmp(pp_PartPlatform,"")==0)
				{
					printf("\n save_method_4--Part Platform cannot be NULL/NA for vehicle. Kindly slect value from LOV only."); fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Platform cannot be NULL/NA for vehicle. Kindly slect value from LOV only.");
					return ITK_errStore;
				}
				else
				{
					if(QRY_find2("Control Objects...",&PP_CntrlOBJ)!=ITK_ok) PrintErrorStack();
					//printf("\n save_method_4--Part Platform Query Found\n "); fflush(stdout);
					if(QRY_execute(PP_CntrlOBJ, PP_entries, qry_PPcntrl, qry_valuesPP, &PP_found, &CntrlObject_PP)!=ITK_ok) PrintErrorStack();
					printf("\n save_method_4--Part Platfrom SYSCD :[%d] ",PP_found); fflush(stdout);

					for(pp = 0; pp < PP_found; pp++)
					{
						if(AOM_ask_value_string(CntrlObject_PP[pp],"t5_Userinfo1",&info1PP)!=ITK_ok) PrintErrorStack();
						if(AOM_ask_value_string(CntrlObject_PP[pp],"t5_Userinfo2",&info2PP)!=ITK_ok) PrintErrorStack();
						printf("\n save_method_4--For Part platform Info 1 and and Info 2 values are [%s] and [%s] ",info1PP,info2PP); fflush(stdout);

						//if(tc_strcmp(info1PP,pp_PartPlatform) == 0)
						if((tc_strcmp(info1PP,pp_PartPlatform)==0))
						{
							if(tc_strstr(info2PP,pp_projectcode) == NULL)
							{
								printf("\n save_method_4--Part Platform and Project Code does not match."); fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Platform and Project Code does not match.");
								return ITK_errStore;
							}
							else
							{
								printf("\n save_method_4--Vehicle can be checked-in as Platform name and Project code matches"); fflush(stdout);
								break;
							}
						}
					}
				}
			}
		}
	}
	/****************************************Rohit Validation ends for Platform Name attribute*********************************/

	/****************************************Rohit Validation starts for JLR Relation attribute*********************************/
	tag_t jlrcr_CntrlOBJ = NULLTAG;
	int jlrcr_entries = 1;
	int	jlrcr_found = 0;
	tag_t *CntrlObject_jlrcr = NULLTAG;
	char JLR_Projects[1900]	= { 0 };

	if(QRY_find2("Control Objects...",&jlrcr_CntrlOBJ)!=ITK_ok) PrintErrorStack();
	//printf("\n\nJLR Query Found\n "); fflush(stdout);

	char *qry_jlrcrcntrl[1] = {"SYSCD"};
	char **qry_valuesjlrcr = (char **) MEM_alloc(10 * sizeof(char *));
	qry_valuesjlrcr[0] = "JLR_Relation";

	if(QRY_execute(jlrcr_CntrlOBJ, jlrcr_entries, qry_jlrcrcntrl, qry_valuesjlrcr, &jlrcr_found, &CntrlObject_jlrcr)!=ITK_ok) PrintErrorStack();
	printf("\n save_method_4--JLR SYSCD :%d ",jlrcr_found);	fflush(stdout);
	if(jlrcr_found>0)
	{
		char	*jlr_itemid		=	NULL;
		char	*jlr_revisionid	=	NULL;
		char	*info1_JLR		=	NULL;
		char	*info2_JLR		=	NULL;
		char	*info8_JLR		=	NULL;
		char	*info9_JLR		=	NULL;
		char	*info10_JLR		=	NULL;
		char	*jlr_cva		=	NULL;
		char	*jlr_cvpc		=	NULL;
		char	*jlr_rpn		=	NULL;
		char	*jlr_projectcode		=	NULL;

		if(AOM_ask_value_string(objTag,"item_id",&jlr_itemid)!=ITK_ok) PrintErrorStack();
		if(AOM_ask_value_string(objTag,"item_revision_id",&jlr_revisionid)!=ITK_ok) PrintErrorStack();
		if(AOM_ask_value_string(objTag,"t5_TPEM_JLR_CVA",&jlr_cva)!=ITK_ok) PrintErrorStack();
		if(AOM_ask_value_string(objTag,"t5_TPEM_JLR_CVPC",&jlr_cvpc)!=ITK_ok) PrintErrorStack();
		if(AOM_ask_value_string(objTag,"t5_ProjectCode",&jlr_projectcode)!=ITK_ok) PrintErrorStack();
		printf("\n save_method_4--CVA and CVPC values are [%s] and [%s] ",jlr_cva,jlr_cvpc); fflush(stdout);

		if(AOM_ask_value_string(CntrlObject_jlrcr[0],"t5_Userinfo1",&info1_JLR)!=ITK_ok) PrintErrorStack();
		if(AOM_ask_value_string(CntrlObject_jlrcr[0],"t5_Userinfo2",&info2_JLR)!=ITK_ok) PrintErrorStack();
		if(AOM_ask_value_string(CntrlObject_jlrcr[0],"t5_Userinfo8",&info8_JLR)!=ITK_ok) PrintErrorStack();
		if(AOM_ask_value_string(CntrlObject_jlrcr[0],"t5_Userinfo9",&info9_JLR)!=ITK_ok) PrintErrorStack();
		if(AOM_ask_value_string(CntrlObject_jlrcr[0],"t5_userinfo10",&info10_JLR)!=ITK_ok) PrintErrorStack();
		printf("\n save_method_4--Info 1 and Info 2 values are [%s] and [%s] ",info1_JLR,info2_JLR); fflush(stdout);

		tc_strcpy(JLR_Projects,"");
		tc_strcat(JLR_Projects,info8_JLR);
		tc_strcat(JLR_Projects,info9_JLR);
		tc_strcat(JLR_Projects,info10_JLR);

		printf("\n save_method_4--All JLR projects are : [%s] ",JLR_Projects); fflush(stdout);

		if(tc_strstr(JLR_Projects,jlr_projectcode) != NULL)
		{
			if(tc_strcmp(jlr_cva,"")==0)
			{
				printf("\n save_method_4--For selected project , TPEM-JLR Combined Vehicle Aggregate should not be NULL "); fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_errStore,"For selected project , TPEM-JLR Combined Vehicle Aggregate should not be NULL");
				return ITK_errStore;
			}
			else
			{
				if(tc_strcmp(jlr_cva,"TOP HAT") == 0)
				{
					printf("\n save_method_4--CVA values is TOP HAT ");fflush(stdout);
					if(tc_strstr(info1_JLR,jlr_cvpc) != NULL)
					{
						printf("\n save_method_4--LOV's are selected properly "); fflush(stdout);
					}
					else
					{
						printf("\n save_method_4--LOV's are not selected properly "); fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Kindly select correct value for TPEM-JLR Combined Vehicle Part Category . If TPEM-JLR Combined Vehicle Aggregate is TOP HAT , then TPEM-JLR Combined Vehicle Part Category should be Carryover TPEM toolkit or TPEM New part");
						return ITK_errStore;
					}

				}
				else if(tc_strcmp(jlr_cva,"PLATFORM") == 0)
				{
					printf("\n save_method_4--CVA values is PLATFORM ");fflush(stdout);
					if(tc_strstr(info2_JLR,jlr_cvpc) != NULL)
					{
						printf("\n save_method_4--LOV's are selected properly "); fflush(stdout);
					}
					else
					{
						printf("\n save_method_4--LOV's are not selected properly "); fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Kindly select correct value for TPEM-JLR Combined Vehicle Part Category . If TPEM-JLR Combined Vehicle Aggregate is PLATFORM , then TPEM-JLR Combined Vehicle Part Category should be Carryover JLR toolkit or Carryover modified JLR toolkit");
						return ITK_errStore;
					}
				}
			}

			if(tc_strcmp(jlr_cva,"PLATFORM") == 0)
			{
				printf("\n save_method_4--CVA is PLATFORM . Hence checking reference part number "); fflush(stdout);

				if(AOM_ask_value_string(objTag,"t5_TPEM_JLR_RPN",&jlr_rpn)!=ITK_ok) PrintErrorStack();

				if(tc_strcmp(jlr_rpn,"") == 0)
				{
					printf("\n save_method_4--RPN is NULL "); fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Kindly enter value for TPEM-JLR Refrence Part Number , as TPEM-JLR Combined Vehicle Aggregate is selected as PLATFORM");
					return ITK_errStore;
				}
				else
				{
					printf("\n save_method_4--For attibute PLATFORM , Reference Part Number is entered properly "); fflush(stdout);
				}
			}
		}
	}
	/****************************************Rohit Validation ends for JLR Relation attribute*********************************/

	/****************************************Vinayak Validation starts for UOM attribute*********************************/
	tag_t cv_CntrlOBJ		   =	NULLTAG;
	tag_t *CntrlObject_cv	   =	NULLTAG;
	tag_t CurrentRoleTagUOM	   =    NULLTAG;
	tag_t user_tag_UOM	       =    NULLTAG;
	tag_t group_tag_UOM		   =    NULLTAG;

	char *qry_cvprodcntrlOBJ[1] = {"SYSCD"};
	char **qry_valuescvprodOBJ = (char **) MEM_alloc(10 * sizeof(char *));
	char *uom_uom = NULL;
	char *uom_parttype = NULL;
	char *partNum = NULL;
	char* username_UOM = NULL;
	char *group_name_UOM	= NULL;
	char *roleName_UOM	= NULL;
	//char roleName_UOM[SA_name_size_c+1];
	int cv_entriesB = 1;
	int cv_foundB = 0;

	qry_valuescvprodOBJ[0] = "CVUOMCntrlObj";

	if(QRY_find2("Control Objects...",&cv_CntrlOBJ)!=ITK_ok) PrintErrorStack();
	if(QRY_execute(cv_CntrlOBJ, cv_entriesB, qry_cvprodcntrlOBJ, qry_valuescvprodOBJ, &cv_foundB, &CntrlObject_cv)!=ITK_ok) PrintErrorStack();
	printf("\n save_method_4--CVPROD Control Object SYSCD :[ %d ] ",cv_foundB);fflush(stdout);

	if(cv_foundB > 0)
	{
		if(SA_ask_current_role(&CurrentRoleTagUOM)!=ITK_ok) PrintErrorStack();
		if(SA_ask_role_name2(CurrentRoleTagUOM,&roleName_UOM)!=ITK_ok) PrintErrorStack();
		POM_get_user(&username_UOM, &user_tag_UOM);
		POM_ask_group(&group_name_UOM, &group_tag_UOM);

		printf("\n save_method_4--User name while save validation: %s", username_UOM);
		printf("\n save_method_4--roleName_UOM: %s ",roleName_UOM); fflush(stdout);

		if (((tc_strcmp(username_UOM,"infodba")!=0) && (tc_strcmp(username_UOM,"loader")!=0)) && (tc_strstr(roleName_UOM,"STD")==NULL) && (tc_strstr(roleName_UOM,"APL")==NULL) && (tc_strstr(roleName_UOM,"MBOM")==NULL) && (tc_strstr(roleName_UOM,"Support")==NULL))
		{
			printf("\n save_method_4--Inside control_obj_UOM validation for assembly and component"); fflush(stdout);
			if(AOM_ask_value_string(objTag,"t5_PartType",&uom_parttype)!=ITK_ok) PrintErrorStack();
			if(AOM_ask_value_string(objTag,"object_name",&partNum)!=ITK_ok) PrintErrorStack();
			printf("\n save_method_4--Part number [%s] Length [%d] Part type [%s]",partNum,tc_strlen(partNum),uom_parttype); fflush(stdout);

			if((tc_strcmp(uom_parttype,"A")==0) || ((tc_strcmp(uom_parttype,"C")==0) && (tc_strlen(partNum)==12)) || (tc_strcmp(uom_parttype,"M")==0) || (tc_strcmp(uom_parttype,"VC")==0) || (tc_strcmp(uom_parttype,"V")==0) )
			{
				if(AOM_ask_value_string(objTag,"t5_uom",&uom_uom)!=ITK_ok) PrintErrorStack();

				if(tc_strcmp(uom_uom,"4-Nos")!=0)
				{
					printf("\n save_method_4--For Part Type Assembly/Component/Module/Vehicle/VC UOM should be -4Nos. Kindly update UOM and try. ");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"For Part Type Assembly/Component/Module/Vehicle/VC UOM should be -4Nos. Kindly update UOM and try.");
					return ITK_errStore;
				}
				else
				{
					printf("\n save_method_4--Eligible for UOM "); fflush(stdout);
				}
			}
		}
	}
	/****************************************Vinayak Validation End for UOM attribute*********************************/

	//if(strcmp(type_name,"Design Revision")==0)
	//{
	//	char *PartNo   = NULL;
	//	char *ProjCode   = NULL;
	//	char *CurrentRole = NULL;
	//	tag_t   Qry_tag     = NULLTAG;
	//	int error_code	= ITK_ok;
	//	int No_of_Entry = 2 ;
	//	int ControlObj_count = 0;
	//	char    *Q_Entry[2]  = {"Name","SUBSYSCD"};
	//	char	**Q_Value = (char **) MEM_alloc(5 * sizeof(char *));
	//	tag_t *ControlObject_tag = NULLTAG;
	//	logical	DelIndicator	= false;
	//	char *Error_Msg = (char*)MEM_alloc(sizeof(char) * 3000);
	//	tag_t CurrentRole_Tag = NULLTAG;
	//	AOM_ask_value_string( objTag, "item_id", &PartNo);
	//	AOM_ask_value_string( objTag, "t5_ProjectCode", &ProjCode);
	//
	//	printf("\n PartNo = %s, Project Code =  %s ",PartNo,ProjCode);fflush(stdout);
	//
	//	if(QRY_find2("Control Objects...", &Qry_tag)!=ITK_ok) PrintErrorStack();
	//
	//	if (Qry_tag)
	//	{
	//		printf("\n Control Object Query Found  ");fflush(stdout);
	//
	//		Q_Value[0]="PlantDML";
	//		Q_Value[1]=ProjCode;
	//
	//		if(QRY_execute(Qry_tag, No_of_Entry, Q_Entry, Q_Value, &ControlObj_count, &ControlObject_tag)!=ITK_ok) PrintErrorStack();
	//		printf("\n No of Control object Found = %d ",ControlObj_count);fflush(stdout);
	//		if (ControlObj_count > 0)
	//		{
	//			printf("\n Control Object Found for Plant and Project  ");fflush(stdout);
	//			AOM_ask_value_logical( ControlObject_tag[0],"t5_DelInd",&DelIndicator);
	//
	//			if (DelIndicator == true)
	//			{
	//				printf("\n Selected project code < %s > is not made live for plant. Part creation is allowed only for Live projects.   ",ProjCode);fflush(stdout);
	//
	//				tc_strcpy(Error_Msg,"Selected project code< ");
	//				tc_strcat(Error_Msg,ProjCode);
	//				tc_strcat(Error_Msg," > is not made live for plant. Part creation is allowed only for Live projects. ");
	//				EMH_clear_errors();
	//				EMH_store_error_s1(EMH_severity_error,ITK_errStore1,Error_Msg);
	//				return ITK_errStore1;
	//			}
	//			else
	//			{
	//				printf("\n Selected Project code is Live for Plant  ");fflush(stdout);
	//			}
	//		}
	//		else
	//		{
	//			printf("\n Control Object Not Found for Plant and Project  ");fflush(stdout);
	//			printf("\n Selected project code < %s > is not made live for plant. Part creation is allowed only for Live projects.  ",ProjCode);fflush(stdout);
	//
	//			tc_strcpy(Error_Msg,"Selected project code < ");
	//			tc_strcat(Error_Msg,ProjCode);
	//			tc_strcat(Error_Msg," > is not made live for plant. Part creation is allowed only for Live projects.");
	//			EMH_clear_errors();
	//			EMH_store_error_s1(EMH_severity_error,ITK_errStore1,Error_Msg);
	//			return ITK_errStore1;
	//		}
	//	}
	//
	//}
	//Sagar End

	//CR/ERC/PLM/22/0027 , Validation for Module Address Added on Design Revision. 05-02-2022
	if(tc_strcmp(type_name,"Design Revision")==0)
	{
		if( AOM_ask_value_string(objTag,"t5_PartType",&Part_type)!=ITK_ok) PrintErrorStack();
		printf("\n save_method_4--Type found:%s ", Part_type);

		if(tc_strcmp(Part_type, "M") == 0 || tc_strcmp(Part_type, "EM") == 0)
		{
			//Bypassing this check for DBA users
			//10-June-2022 //CR/ERC/PLM/22/0027 - Removing Loader from bypass
			if((tc_strcmp(username,"infodba")!=0))
			{
				if((tc_strstr(rolename,"APLP_Planner")==NULL)) //TZ 1.79 pl922201 bypass Module Address check while updating CS TCUA/CR/PLM SYS/APL/24/0032
				{
					if( AOM_ask_value_string(objTag,"t5_ModuleAddress",&moduleAddress)!=ITK_ok) PrintErrorStack();
					if (tc_strlen(moduleAddress)==0)
					{
							printf("\n save_method_4--Design revision cannot be created as Module Address is not Found. ");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Design revision cannot be created, As Module Address (t5_ModuleAddress) is not present.");
							return ITK_err;
					}
				}
				else
				{
					printf("\n save_method_4--TZ 1.79 pl922201 bypass Module Address check while updating CS TCUA/CR/PLM SYS/APL/24/0032 ");fflush(stdout);
				}
			}
		}
	}
	//kalpesh(12_sept19)
	//CR/ERC/PLM/22/0061
	int No_of_Entry = 2 ;
	char    *Q_Entry[2]  = {"Name","SUBSYSCD"};
	char	 **Q_Value = (char **) MEM_alloc(5 * sizeof(char *));
	tag_t   Qry_tag     = NULLTAG;
	int ControlObj_count = 0;
	tag_t *ControlObject_tag = NULLTAG;

	if(QRY_find2("Control Objects...", &Qry_tag)!=ITK_ok) PrintErrorStack();

	if(tc_strcmp(type_name,"Design Revision")==0)
	{
		if( AOM_ask_value_string(objTag,"t5_DesignGrp",&Part_DegGrp)!=ITK_ok) PrintErrorStack();
		if(tc_strcmp(Part_DegGrp, "16") == 0)
		{
			if( AOM_ask_value_string(objTag,"t5_PartType",&Part_type)!=ITK_ok) PrintErrorStack();
			printf("\n save_method_4--B.Type found:%s ", Part_type);
			if(tc_strcmp(Part_type, "M") == 0 || tc_strcmp(Part_type, "EM") == 0)
			{
				printf("\n save_method_4--B.Bypass for Module and ECU Module. ");
			}
			else
			{
				if (Qry_tag!=NULLTAG)
				{
					printf("\n save_method_4--B.Control Object Query Found  ");fflush(stdout);

					Q_Value[0]="DESG_REV_EE_Part_Validation";
					Q_Value[1]="DESG_REV_EE_Part_Validation";

					if(QRY_execute(Qry_tag, No_of_Entry, Q_Entry, Q_Value, &ControlObj_count, &ControlObject_tag)!=ITK_ok) PrintErrorStack();
					printf("\n save_method_4--No of Control object Found = %d ",ControlObj_count);fflush(stdout);
					if (ControlObj_count > 0)
					{
						printf("\n save_method_4--Control Object Found  ");fflush(stdout);
						//CR/ERC/PLM/22/0061 07-08-2022
						if((tc_strcmp(username,"loader") == 0))
						{
							printf("\n save_method_4--Design revision cannot be created with 16 design group. ");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Design revision cannot be created with 16 design group.");
							return ITK_err;
						}

					}
				}
			}
		}
	}//End

	// ClrIndicator =C  Should not be allowed on Non Color Revision
	printf("\n save_method_4--Before ClrIndicator Updation validation  ");fflush(stdout);

	if(QRY_find2("ControlObjQry", &ClrInd_CtrObjQryTag)!=ITK_ok) PrintErrorStack();
	ClrBOMQryVal[0] = "ClriNdC";
	if(QRY_execute(ClrInd_CtrObjQryTag, ClrBomEtry, ClrBomQryEtry, ClrBOMQryVal, &ClrBOMQryC, &ClrBOMCtrObj)!=ITK_ok) PrintErrorStack();
	printf("\n save_method_4--ClrBOMQryC-Control object found = [%d]  ",ClrBOMQryC);fflush(stdout);

	if(ClrBOMQryC>0)
	{
		if(AOM_ask_value_string(ClrBOMCtrObj[0],"t5_Userinfo1",&info1_value)!=ITK_ok) PrintErrorStack();

		PrtClassFlag =0;
		token= tc_strtok(info1_value,";");
		while (token != NULL)
		{
			printf("\n save_method_4--Patrt Class= %s ", token);
			if(tc_strcmp(type_name,token)==0)
			{
				PrtClassFlag=1;
				printf("\n save_method_4--PrtClassFlag updated= [%d] ", PrtClassFlag);
			}
			token = tc_strtok(NULL,";");
		}

		if(PrtClassFlag==1)
		{
			if( AOM_ask_value_string(objTag,"t5_ColourInd",&ClrIndicator)!=ITK_ok) PrintErrorStack();
			if(tc_strcmp(ClrIndicator, "C") == 0)
			{
				printf("\n save_method_4--Color Indicator 'C' is not valid with Non Color Part.");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s2(EMH_severity_error,ITK_err,"Color Indicator 'C' is not valid with Non Color Part.","Select Color Indicator either 'Y' or 'N'");
				return ITK_err;
			}
		}
	}
	//ClrInd End

	//mbb_start
	if(strcmp(type_name,"Design Revision")==0)
	{
		printf("\n\t save_method_4--B.Inside of Updation of Keyword validation  ");fflush(stdout);

		if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0))
		{
			if( AOM_ask_value_string(objTag,"item_id",&Ditem_ID)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(objTag,"item_revision_id",&DitemRev_ID)!=ITK_ok) PrintErrorStack();

			printf("\n\t save_method_4--B.Part: [%s] with Revision [%s]  ",Ditem_ID,DitemRev_ID);fflush(stdout);

			if(tc_strstr(DitemRev_ID,"NR")==NULL)
			{
				if(QRY_find2("ControlObjects", &CntrlObjQry)!=ITK_ok) PrintErrorStack();
				if (CntrlObjQry)
				{
					printf("\n\t save_method_4--B.ControlObjects Query Found  ");fflush(stdout);
				}
				else
				{
					printf("\n\t save_method_4--ControlObjects Query Not Found  ");fflush(stdout);
				}

				QryCntr_values[0] = "KeyJan19" ;

				if(QRY_execute(CntrlObjQry, Key_qry_entry, QryCntr_entry, QryCntr_values, &CntlObjCount, &CntObj_Tag2)!=ITK_ok) PrintErrorStack();
				printf("\n\t save_method_4--B.ControlObjects Count = %d  ",CntlObjCount);fflush(stdout);

				if(CntlObjCount>0)
				{
					if(ITEM_find_item( Ditem_ID, &DItem_tag )!=ITK_ok) PrintErrorStack();
					if(DItem_tag )		//MBOM implementation for CV TZ-1.69
					{

						if(ITEM_list_all_revs(DItem_tag,&rev_cnt,&rev_list_set)!=ITK_ok) PrintErrorStack();
						//if(rev_cnt != 0)	//MBOM implementation for CV TZ-1.69
						if(rev_cnt > 0)	//MBOM implementation for CV TZ-1.69
						{
							for(iji=(rev_cnt-1);iji>=0;iji--)
							{
								if(AOM_UIF_ask_value(rev_list_set[iji],"release_status_list",&rlstatus)!=ITK_ok) PrintErrorStack();
								if(rlstatus)
								{
									if(strstr(rlstatus,"ERC Released"))
									{
										 LatestRev_tag= rev_list_set[iji];
										 FlagKey=1;
										break;
									}
								}
							}
						}
					}

					printf("\n\t save_method_4--FlagKey = [%d]  ",FlagKey);fflush(stdout);

					if(FlagKey==1)
					{
						if( AOM_ask_value_string(objTag,"item_id",&Ditem_ID2)!=ITK_ok) PrintErrorStack();
						printf("\n\t save_method_4--Ditem_ID2 [%s]  ",Ditem_ID2);fflush(stdout);

						if( AOM_UIF_ask_value(LatestRev_tag,"creation_date",&CreationDate)!=ITK_ok) PrintErrorStack();

						printf("\n\t save_method_4--creation date [%s]  ",CreationDate);fflush(stdout);



						 day=subString(CreationDate,0,2);
						 month=subString(CreationDate,3,3);
						 Year=subString(CreationDate,7,4);

						 printf("\n\t save_method_4--day =  [%s]  month =  [%s]  Year =  [%s]   ",day,month,Year);fflush(stdout);

						if (tc_strcmp(month,"Jan")==0)
						{
							intMonth=1;
						}
						else if (tc_strcmp(month,"Feb")==0)
						{
							intMonth=2;
						}
						else if (tc_strcmp(month,"Mar")==0)
						{
							intMonth=3;
						}
						else if (tc_strcmp(month,"Apr")==0)
						{
							intMonth=4;
						}
						else if (tc_strcmp(month,"May")==0)
						{
							intMonth=5;
						}
						else if (tc_strcmp(month,"Jun")==0)
						{
							intMonth=6;
						}
						else if (tc_strcmp(month,"Jul")==0)
						{
							intMonth=7;
						}
						else if (tc_strcmp(month,"Aug")==0)
						{
							intMonth=8;
						}
						else if (tc_strcmp(month,"Sep")==0)
						{
							intMonth=9;
						}
						else if (tc_strcmp(month,"Oct")==0)
						{
							intMonth=10;
						}
						else if (tc_strcmp(month,"Nov")==0)
						{
							intMonth=11;
						}
						else if (tc_strcmp(month,"Dec")==0)
						{
							intMonth=12;
						}

						 printf("\n save_method_4--intMonth: [%d]   ",intMonth);fflush(stdout);

						 intDay = atoi(day);
						 intYear = atoi(Year);

						  printf("\n save_method_4--intDay = [%d] \t intMonth = [%d] \t intYear =[%d]  ",intDay,intMonth,intYear);fflush(stdout);

						 if (intYear>=2019 && intMonth>=1 && intYear>=1)
						 {
							printf("\n save_method_4--Indside validation  ");fflush(stdout);

							if(AOM_ask_value_string(objTag,"t5_AhdMakeBuyIndicator",&AhdMkByInd)!=ITK_ok) PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_CarMakeBuyIndicator",&CarMkByInd)!=ITK_ok) PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_DwdMakeBuyIndicator",&DwdMkByInd)!=ITK_ok) PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_JsrMakeBuyIndicator",&JsrMkByInd)!=ITK_ok) PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_JdlMakeBuyIndicator",&JdlMkByInd)!=ITK_ok) PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_LkoMakeBuyIndicator",&LkoMkByInd)!=ITK_ok) PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_PnrMakeBuyIndicator",&PnrMkByInd)!=ITK_ok) PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_PunPCBUMakeBuyIndicator",&PCBUMkByInd)!=ITK_ok) PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_PunMakeBuyIndicator",&PuneMkByInd)!=ITK_ok) PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_PunUVMakeBuyIndicator",&PuneUVMkByInd)!=ITK_ok) PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_SgrMakeBuyIndicator",&SrgMkByInd)!=ITK_ok) PrintErrorStack();

							if((tc_strcmp(AhdMkByInd,"F")==0 ) || (tc_strcmp(CarMkByInd,"F")==0 ) || (tc_strcmp(DwdMkByInd,"F")==0 ) || (tc_strcmp(JsrMkByInd,"F")==0 ) || (tc_strcmp(JdlMkByInd,"F")==0 ) || (tc_strcmp(LkoMkByInd,"F")==0 )
									|| (tc_strcmp(PnrMkByInd,"F")==0 ) || (tc_strcmp(PCBUMkByInd,"F")==0 ) || (tc_strcmp(PuneMkByInd,"F")==0 ) || (tc_strcmp(PuneUVMkByInd,"F")==0 ) || (tc_strcmp(SrgMkByInd,"F")==0 )	)
							{

								if(AOM_ask_value_string(objTag,"t5_CategoryName",&ReqKeyWord)!=ITK_ok) PrintErrorStack();
								if(AOM_ask_value_string(LatestRev_tag,"t5_CategoryName",&PrevKeyWord)!=ITK_ok) PrintErrorStack();

								printf("\n\t save_method_4--ReqKeyWord =[%s] \t PrevKeyWord [%s]  ",ReqKeyWord,PrevKeyWord);fflush(stdout);

								if(strcmp(ReqKeyWord,PrevKeyWord)==0)
								{
									printf("\n\t save_method_4--No change in Keyword  ");fflush(stdout);
								}
								else
								{
									printf("\n\t save_method_4--Giving the error message for keyword not matching  ");fflush(stdout);
									//EMH_clear_errors();
									//EMH_store_error_s2(EMH_severity_error,ITK_err,"Updation of Keyword of Current Revision is Not Allowed as it is Buyable Part and Created After 1st Jan 2019.","If Still you Want the Same Keyowrd Description then Please Contact Bom Proecss Team.");
									//return ITK_err;
									//W.R.T CR-FY24-0163
								}
							}
							else
							{
								printf("\n\t save_method_4--In else as Make buy indicator, No error  ");fflush(stdout);
							}

						 }
						 else
						{
							printf("\n\t save_method_4--Previous official Rev is created before 1-Jan-2019  ");fflush(stdout);
						}

					}

				}

			}
			else
			{
				printf("\n\t save_method_4--Revision is NR  ");fflush(stdout);
			}
		}
		printf("\n\t save_method_4--END of Updation of Keyword validation  ");fflush(stdout);
	}


	//RAJAN 1.5
	//if(tc_strcmp(type_name,"Design Revision")==0)
	//{
	//	if(GRM_find_relation_type("IMAN_specification",&reln_typeDvp)!=ITK_ok) PrintErrorStack();
	//	if(GRM_list_secondary_objects_only(objTag,reln_typeDvp,&n_attchs_ds,&secondary_ds)!=ITK_ok) PrintErrorStack();
	//	printf("\n save_method_4--RAJAN 1.5... time Configuration Context count is : %d",countConfigCtx);
	//
	//	for (jr=0;jr<n_attchs_ds;jr++ )
	//	{
	//		if(TCTYPE_ask_object_type(secondary_ds[jr],&SpecifiTypeTag)!=ITK_ok) PrintErrorStack();
	//		if(TCTYPE_ask_name2(SpecifiTypeTag,&Specifictype_name)!=ITK_ok) PrintErrorStack();
	//		if( AOM_ask_value_string(secondary_ds[jr],"current_name",&DSCurrent_Name)!=ITK_ok) PrintErrorStack();
	//		if( AOM_ask_value_string(secondary_ds[jr],"object_name",&DSobject_name)!=ITK_ok) PrintErrorStack();
	//		if( AOM_ask_value_string(secondary_ds[jr],"object_string",&DSobject_string)!=ITK_ok) PrintErrorStack();
	//		printf("\n save_method_4--RAJAN 1.5...--save_method_4 :: [%s] DSCurrent_Name:[%s] OnjName: [%s] ObjStr: [%s]", Specifictype_name,DSCurrent_Name,DSobject_name,DSobject_string);fflush(stdout);
	//	}
	//}

	if(tc_strcmp(type_name,"Design Revision")==0)
	{
		if(GRM_find_relation_type("IMAN_specification",&reln_typeDvp)!=ITK_ok) PrintErrorStack();
		if(GRM_list_secondary_objects_only(objTag,reln_typeDvp,&n_attchs_ds,&secondary_ds)!=ITK_ok) PrintErrorStack();
		printf("\n save_method_4--2nd time*** Configuration Context count is : %d",countConfigCtx);

		for (jr=0;jr<n_attchs_ds;jr++ )
		{
			if(TCTYPE_ask_object_type(secondary_ds[jr],&SpecifiTypeTag)!=ITK_ok) PrintErrorStack();
			if(TCTYPE_ask_name2(SpecifiTypeTag,&Specifictype_name)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(secondary_ds[jr],"current_name",&DSCurrent_Name)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(secondary_ds[jr],"object_name",&DSobject_name)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(secondary_ds[jr],"object_string",&DSobject_string)!=ITK_ok) PrintErrorStack();
			printf("\n save_method_4--2nd time***--save_method_4 :: [%s] DSCurrent_Name:[%s] OnjName: [%s] ObjStr: [%s]", Specifictype_name,DSCurrent_Name,DSobject_name,DSobject_string);fflush(stdout);
		}
	}
	//mbb_end
	char *PrtPrj=NULL;
	char *desRev=NULL;
	char *ML_Staus=NULL;
	logical			checkoutrev;
	char *DRinfo4=NULL;
	int IsMilestoneLiveFlag=0;
	tag_t   qryTag12     = NULLTAG;
	char   *qry_entry1[1]  = {"SYSCD"};
	char   **qry_values21     =  (char **) MEM_alloc(10 * sizeof(char *));
	int     rsltCount1      =  0;
	tag_t   *CntrlObjectTag1      = NULLTAG;

	if( AOM_ask_value_string(objTag,"item_revision_id",&desRev)!=ITK_ok) PrintErrorStack();

	//if(RES_is_checked_out(objTag,&checkoutrev)!=ITK_ok) PrintErrorStack();
	//printf("\n aMilestone %d  ",checkoutrev);fflush(stdout);
	//if (checkoutrev==1)
	//{
		printf("\n save_method_4--aMilestone for design revisionn");fflush(stdout);
		if (tc_strcmp(type_name,"Design Revision")==0)
		{
				// if Design revision is NR then checking DR-Milestone mapping
				if(AOM_ask_value_string(objTag,"t5_ProjectCode",&PrtPrj)!=ITK_ok) PrintErrorStack();
				printf("\n save_method_4--Project stamped is : %s ",PrtPrj);fflush(stdout);
				IsMilestoneLiveFlag=0;
				IsMilestoneLiveFlag = CheckMilestoneLive(PrtPrj);
				printf("\n save_method_4--P3:IsMilestoneLiveFlag: %d",IsMilestoneLiveFlag);fflush(stdout);

				// if (IsMilestoneLiveFlag >0)
				// {
						// int MilStRev=0;
						// printf("\n going to call function tm_Validate_Rev_Milestone_OnPart  %d  ",MilStRev); fflush(stdout);
						// MilStRev = tm_Validate_Rev_Milestone_OnPart(objTag);
						// printf("\n after calling tm_Validate_Rev_Milestone_OnPart checking %d  ",MilStRev); fflush(stdout);
						// if (MilStRev >0)
						// {
							// printf("\n Part miles status error");fflush(stdout);
							// return ITK_err;
						// }
				// }

				// if (IsMilestoneLiveFlag >0)
				// {
					// printf("\n project is live check part level Milestone validations");fflush(stdout);
					// if(QRY_find2("ControlObjects", &qryTag12)!=ITK_ok) PrintErrorStack();
					// if (qryTag12)
					// {
						// printf("\n CREVali:Found Query ControlObjects  ");fflush(stdout);
					// }
					// else
					// {
						// printf("\n CREVali:Not Found Query ControlObjects  ");fflush(stdout);
					// }

					// qry_values21[0] = "CREVali";
					// if(QRY_execute(qryTag12, n_entry, qry_entry1, qry_values21, &rsltCount1, &CntrlObjectTag1)!=ITK_ok) PrintErrorStack();
					// printf(" \n CREVali:rsltCount 11:%d:", rsltCount1); fflush(stdout);
					// if(rsltCount1 > 0)
					// {
						// if (AOM_ask_value_string(CntrlObjectTag1,"t5_Userinfo4",&DRinfo4)!=ITK_ok) PrintErrorStack();
						// printf("\n CREVali:DRinfo4:%s ",DRinfo4);fflush(stdout);
					// }
					// if(tc_strstr(DRinfo4,"AHCHKNR")==NULL)
					// {
						// printf("\n AHCHKNR is null  ",MilStflg); fflush(stdout);
						// MilStflg = tm_Validate_DR_Milestone_OnPart(objTag);
						// printf("\n after milestone checking %d  ",MilStflg); fflush(stdout);
						// if(MilStflg==1)
						// {
							// EMH_clear_errors();
							// EMH_store_error_s1(EMH_severity_error,ITK_err,"Milestone Status cannot be NULL for this part");
							// return ITK_err;
						// }
						// else if (MilStflg==5)
						// {
							// EMH_clear_errors();
							// EMH_store_error_s1(EMH_severity_error,ITK_err," for NR revision Milestone Status should be as per Standards provided by PLM Team");
							// return ITK_err;
						// }
					// }
				// }
				// if (IsMilestoneLiveFlag >0)
				// {
					// printf("\n project is live check part level Milestone validations and update DR Status");fflush(stdout);

					// MilStflg = tm_Update_DR_AsPerMilestone_OnPart(objTag);

					// if (MilStflg >0)
						// {
							// printf("\n Part DR updated as per miles status error");fflush(stdout);
							// return ITK_err;
						// }
				// }

				//added on 14Apr2023
				char *PrtDRStatus = NULL;

				if(AOM_ask_value_string(objTag,"t5_PartStatus",&PrtDRStatus)!=ITK_ok) PrintErrorStack();
				printf("\n save_method_4--PrtDRStatus : %s ",PrtDRStatus);fflush(stdout);

				char *SupportUsername9 = NULL;
				tag_t SessionUser9_tag=NULLTAG;
				int     SupportFlag      =  0;

				SupportFlag=0;
				POM_get_user(&SupportUsername9,&SessionUser9_tag);
				if(SessionUser9_tag!=NULLTAG)
				{
					SupportFlag=0;
					SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
					printf("\n save_method_4--SupportFlag.: %d",SupportFlag);fflush(stdout);
				}
				if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
				{
					if ((tc_strcmp(PrtDRStatus,"Pre-KO")==0)|| (tc_strcmp(PrtDRStatus,"KO")==0)|| (tc_strcmp(PrtDRStatus,"NA")==0))
					{
						printf("\n save_method_4--Milestone bypass for DRStatus[%s]",PrtDRStatus);fflush(stdout);
					}
					else
					{
						int MilStOnDrFlg=0;
						if (IsMilestoneLiveFlag >0)
						{
							printf("\n save_method_4--project is live check part level Milestone validations as per DR Status");fflush(stdout);

							int ERCUserFlag=0;
							char *SessionUsername;
							tag_t Usertag=NULLTAG;
							POM_get_user(&SessionUsername,&Usertag);

							char *t5userId1=NULL;
							if(AOM_ask_value_string(Usertag, "user_id", &t5userId1)!=ITK_ok) PrintErrorStack();
							printf( "\n save_method_4--session user is t5userId1:[%s]", t5userId1);fflush(stdout);

							if(Usertag!=NULLTAG)
							{
								ERCUserFlag=0;
								ERCUserFlag = CheckERCAccessLogin(Usertag);
								printf("\n save_method_4--ERCUserFlag..: %d",ERCUserFlag);fflush(stdout);
							}

							if(ERCUserFlag==0)
							{
								printf("\n save_method_4--Check Milston status user is:[%s] in ERC Group ERCUserFlag..: [%d]",t5userId1,ERCUserFlag);fflush(stdout);

								printf("\n save_method_4--calling tm_MilestoneValAsPerDRStatus_OnPartUpd ");fflush(stdout);
								MilStOnDrFlg = tm_MilestoneValAsPerDRStatus_OnPartUpd(objTag);
								printf("\n save_method_4--end calling tm_MilestoneValAsPerDRStatus_OnPartUpd ");fflush(stdout);
								if (MilStOnDrFlg >0)
								{
									printf("\n save_method_4--Milesston status validation as per  DR status error.");fflush(stdout);
									return ITK_err;
								}
							}
							else
							{
								printf("\n save_method_4--NOT Check Milston status user is:[%s] in ERC Group ERCUserFlag..: [%d]",t5userId1,ERCUserFlag);
							}


						}
					}
				}
				else
				{
					printf("\n save_method_4--It Support team or Super user [%s] SupportFlag.: %d,",username,SupportFlag);fflush(stdout);
				}
				//end on 14Apr2023

				// char *PrtDRStatus = NULL;

				// if(AOM_get_value_string(objTag,"t5_PartStatus",&PrtDRStatus)!=ITK_ok) PrintErrorStack();
				// printf("\n PrtDRStatus : %s ",PrtDRStatus);fflush(stdout);

				// char *SupportUsername9 = NULL;
				// tag_t SessionUser9_tag=NULLTAG;
				// int     SupportFlag      =  0;

				// SupportFlag=0;
				// POM_get_user(&SupportUsername9,&SessionUser9_tag);
				// if(SessionUser9_tag!=NULLTAG)
				// {
					// SupportFlag=0;
					// SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
					// printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
				// }
				// if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
				// {
					// if ((tc_strcmp(PrtDRStatus,"Pre-KO")==0)|| (tc_strcmp(PrtDRStatus,"KO")==0))
					// {
						// printf("\n Milestone bypass for DRStatus[%s]",PrtDRStatus);fflush(stdout);
					// }
					// else
					// {
						// if (IsMilestoneLiveFlag >0)
						// {
							// printf("\n project is live check part level Milestone validations and update DR Status");fflush(stdout);
							// MilStflg=0;
							// MilStflg = tm_Update_DR_AsPerMilestone_OnPart_UpdLogic(objTag);

							// if (MilStflg >0)
								// {
									// printf("\n Part DR updated as per miles status error");fflush(stdout);
									// return ITK_err;
								// }
								// else
								// {
									// printf("\n Part DR updated as per miles status ");fflush(stdout);
								// }
						// }
					// }
				// }
				// else
				// {
					// printf("\n It Support team or Super user [%s] SupportFlag.: %d,",username,SupportFlag);fflush(stdout);
				// }

				// char *PrtDRStatus = NULL;

				// if(AOM_get_value_string(objTag,"t5_PartStatus",&PrtDRStatus)!=ITK_ok) PrintErrorStack();
				// printf("\n PrtDRStatus : %s ",PrtDRStatus);fflush(stdout);

				// char *SupportUsername9 = NULL;
				// tag_t SessionUser9_tag=NULLTAG;
				// int     SupportFlag      =  0;

				// SupportFlag=0;
				// POM_get_user(&SupportUsername9,&SessionUser9_tag);
				// if(SessionUser9_tag!=NULLTAG)
				// {
					// SupportFlag=0;
					// SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
					// printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
				// }
				// if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
				// {
					// if ((tc_strcmp(PrtDRStatus,"Pre-KO")==0)|| (tc_strcmp(PrtDRStatus,"KO")==0))
					// {
						// printf("\n Milestone bypass for DRStatus[%s]",PrtDRStatus);fflush(stdout);
					// }
					// else
					// {
						// int MilStOnDrFlg=0;
						// if (IsMilestoneLiveFlag >0)
						// {
							// printf("\n project is live check part level Milestone validations as per DR Status");fflush(stdout);
							// printf("\n calling tm_MilestoneValAsPerDRStatus_OnPart ");fflush(stdout);
							// MilStOnDrFlg = tm_MilestoneValAsPerDRStatus_OnPart(objTag);
							// printf("\n end calling tm_MilestoneValAsPerDRStatus_OnPart ");fflush(stdout);
							// if (MilStOnDrFlg >0)
								// {
									// printf("\n Milesston status validation as per  DR status error.");fflush(stdout);
									// return ITK_err;
								// }
						// }
					// }
				// }
				// else
				// {
					// printf("\n It Support team or Super user [%s] SupportFlag.: %d,",username,SupportFlag);fflush(stdout);
				// }
				// if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
				// {
					// if ((tc_strcmp(PrtDRStatus,"Pre-KO")==0)|| (tc_strcmp(PrtDRStatus,"KO")==0))
					// {
						// printf("\n Milestone bypass for DRStatus[%s]",PrtDRStatus);fflush(stdout);
					// }
					// else
					// {
						// int MilStflgSame=0;
						// if (IsMilestoneLiveFlag >0)
						// {
							// printf("\n calling tm_check_MilesStoneStatusSame_OnPart ");fflush(stdout);
							// MilStflgSame = tm_check_MilesStoneStatusSame_OnPart(objTag);
							// printf("\n end calling tm_check_MilesStoneStatusSame_OnPart ");fflush(stdout);
							// if (MilStflgSame >0)
								// {
									// printf("\n Part  miles status is not same for all rev/seq");fflush(stdout);
									// return ITK_err;
								// }
						// }
					// }
				// }
				// else
				// {
					// printf("\n It Support team or Super user [%s] SupportFlag.: %d,",username,SupportFlag);fflush(stdout);
				// }
		}
	//}

	/*Start PART DUPLICATE CHECK*/
	char
		*qry_entries_ctrl_objtype[1] = {"SYSCD"},
		*qry_values_ctrl_objtype[1]	= {"*"};

	tag_t	objtypequery	= NULLTAG;
	tag_t	*q_ObjTypeCtrlSet	= NULLTAG;

	char *partDuplicateCheckType=NULL;

	int	n_CtrlTypefound	= 0;
	int	partduplicatecheckrqd	= 0;

	QRY_find2("Control Objects...", &objtypequery);
	if(objtypequery!=NULLTAG)
	{
		qry_values_ctrl_objtype[0] = "OBJECTTYPEFORDUPLICATE";
		QRY_execute(objtypequery, 1, qry_entries_ctrl_objtype, qry_values_ctrl_objtype, &n_CtrlTypefound, &q_ObjTypeCtrlSet);
		printf("\n save_method_4--n_CtrlTypefound===%d",n_CtrlTypefound);fflush(stdout);
		if(n_CtrlTypefound>0)
		{
			printf("\n save_method_4--Inside if condition of n_CtrlTypefound > 0 \n");fflush(stdout);
			AOM_ask_value_string(q_ObjTypeCtrlSet[0],"t5_Userinfo1",&partDuplicateCheckType);
			printf("\n save_method_4--partDuplicateCheckType===>[%s]",partDuplicateCheckType);fflush(stdout);
			if(strcmp(type_name,"Design Revision")==0 || strcmp(type_name,"T5_SparKitRevision")==0 || tc_strstr(partDuplicateCheckType,type_name)!=NULL)
			{
				partduplicatecheckrqd = 1;
			}
		}
	}
	printf("\n save_method_4--partduplicatecheckrqd===>[%d]",partduplicatecheckrqd);fflush(stdout);
	if(partduplicatecheckrqd==1)
	{
		char *ItemIdV=NULL;
		char *sRevID=NULL;
		char *Part_TypeStr=NULL;
		if (objTag!=NULLTAG)
		{
			if( AOM_ask_value_string(objTag,"item_id",&ItemIdV)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(objTag,"item_revision_id",&sRevID)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(objTag,"t5_PartType",&Part_TypeStr)!=ITK_ok) PrintErrorStack();
			printf("\n save_method_4--ItemIdV===>[%s]",ItemIdV);fflush(stdout);
			printf(" sRevID===>[%s]",sRevID);fflush(stdout);
			printf(" Part_TypeStr===>[%s]",Part_TypeStr);fflush(stdout);
		}
		printf("\n save_method_4--A-Inside partduplicatecheckrqd Session user [%s]",username);fflush(stdout);

		// Check Is Part Available in TCE.
		if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0))
		{
			printf("\n 1save_method_4::A-sRevID: [%s] so check availability in TCE ",sRevID);fflush(stdout);
			printf("\n 1save_method_4::A-Part_TypeStr: [%s] so check availability in TCE ",Part_TypeStr);fflush(stdout);
			printf("\n 1111save_method_4::flag [%d] ",flag);fflush(stdout);

			if(tc_strstr(sRevID,"NR")!=NULL && flag==1)
			{
				printf("\n 2save_method_4::A-sRevID: [%s] so check availability in TCE ",sRevID);fflush(stdout);

				int		IsAvailInUA			=	0;
				int		IsAvailInTCE		=	0;
				int		ValCntT				=	0;
				int		n_Ctrlfound				=	0;
				tag_t*	ValCntrlObjectTagT	=	NULLTAG;
				tag_t*	q_CtrlSet	=	NULLTAG;
				tag_t	qryTagT				=	NULLTAG;
				tag_t	query				=	NULLTAG;
				char    **qry_valuesT		=	(char **) MEM_alloc(10 * sizeof(char *));
				int		n_entryT			=	1;
				char    *qry_entryT[1]		=	{"SYSCD"};
				char *New_TML_Part_Number	= NULL;
				char *itemId	= NULL;
				char *partDuplicateCheckStr	= NULL;
				char *partDuplicateCheckOffStr	= NULL;
				char *partDuplicateCheckTypeStr	= NULL;
				char *partDuplicateCheckLocStr	= NULL;
				char *partDuplicateCheckLogic1	= NULL;
				char *partDuplicateCheckLogic2	= NULL;
				char *partDuplicateCheckShellStr= NULL;
				char *partDuplicateCheckSaveAsStr= NULL;


				if(QRY_find2("ControlObjects", &qryTagT)!=ITK_ok) PrintErrorStack();
				if (qryTagT)
				{
					printf("\n save_method_4--Found Query ControlObjects  ");fflush(stdout);
				}
				else
				{
					printf("\n save_method_4--Not Found Query ControlObjects  ");fflush(stdout);
				}

				qry_valuesT[0] = "PartInTCE" ;
				if(QRY_execute(qryTagT, n_entryT, qry_entryT, qry_valuesT, &ValCntT, &ValCntrlObjectTagT)!=ITK_ok) PrintErrorStack();
				printf(" \n save_method_4--PartInTCE:ValCnt :%d:", ValCntT); fflush(stdout);

				if(ValCntT>0)
				{
					printf(" \n save_method_4--ItemIdV---> :%s:", ItemIdV); fflush(stdout);
					AOM_ask_value_string(ValCntrlObjectTagT[0],"t5_Userinfo5",&partDuplicateCheckLogic1);
					printf("\n save_method_4--partDuplicateCheckLogic1===>[%s]",partDuplicateCheckLogic1);fflush(stdout);

					AOM_ask_value_string(ValCntrlObjectTagT[0],"t5_Userinfo6",&partDuplicateCheckLogic2);
					printf("\n save_method_4--partDuplicateCheckLogic2===>[%s]",partDuplicateCheckLogic2);fflush(stdout);

					if((tc_strstr(partDuplicateCheckLogic1,"WebService")!=NULL || tc_strlen(partDuplicateCheckLogic1)==0) && tc_strlen(partDuplicateCheckLogic2)==0)
					{
						IsAvailInUA = IsDesignRevisionAvail(ItemIdV);
						printf(" \n save_method_4--1IsAvailInUA---> :%d:", IsAvailInUA); fflush(stdout);

						if(IsAvailInUA == 0)
						{
							IsAvailInTCE = FunToCheckPartAvailInICE(ValCntrlObjectTagT[0],ItemIdV);
							printf("\n save_method_4--IsAvailInTCE--->[%d]  ",IsAvailInTCE);fflush(stdout);
							if(IsAvailInTCE==2)
							{
								printf("\n save_method_4--PART [%s] AVAILABLE IN TCE  ",ItemIdV);fflush(stdout);
								EMH_clear_errors();
								error_code=t9NewPartReqCre_Val0048;

								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,error_code,"Part is already available in TCE, Please get it loaded from PLM Team");
								return error_code;
							}
							else
							{
								char
									*qry_entries_ctrl[1] = {"SYSCD"},
									*qry_values_ctrl[1]	= {"*"};

								QRY_find2("Control Objects...", &query);
								if(query!=NULLTAG)
								{
									qry_values_ctrl[0] = "PartDuplicateCheck";
									QRY_execute(query, 1, qry_entries_ctrl, qry_values_ctrl, &n_Ctrlfound, &q_CtrlSet);
									printf("\n save_method_4--1n_Ctrlfound===%d",n_Ctrlfound);fflush(stdout);
									if(n_Ctrlfound>0)
									{
										AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo1",&partDuplicateCheckStr);
										printf("\n save_method_4--1partDuplicateCheckStr===>[%s]",partDuplicateCheckStr);fflush(stdout);

										AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo3",&partDuplicateCheckOffStr);
										printf("\n save_method_4--1partDuplicateCheckOffStr===>[%s]",partDuplicateCheckOffStr);fflush(stdout);

										AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo4",&partDuplicateCheckTypeStr);
										printf("\n save_method_4--1partDuplicateCheckTypeStr===>[%s]",partDuplicateCheckTypeStr);fflush(stdout);

										AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo5",&partDuplicateCheckLocStr);
										printf("\n save_method_4--1partDuplicateCheckLocStr===>[%s]",partDuplicateCheckLocStr);fflush(stdout);

										AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo6",&partDuplicateCheckShellStr);
										printf("\n save_method_4--1partDuplicateCheckShellStr===>[%s]",partDuplicateCheckShellStr);fflush(stdout);

										AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo7",&partDuplicateCheckSaveAsStr);
										printf("\n save_method_4--1partDuplicateCheckSaveAsStr===>[%s]",partDuplicateCheckSaveAsStr);fflush(stdout);
									}
								}
								if(tc_strstr(partDuplicateCheckStr,"PARTDUPLICATECHECK")!=NULL && n_Ctrlfound>0 && tc_strstr(partDuplicateCheckTypeStr,Part_TypeStr)==NULL)
								{
									printf("\n save_method_4--1Part not present in both TCUA and TCE. Please proceed.  ");fflush(stdout);
									char *homeSite = NULL;
									AOM_UIF_ask_value(user_tag,"fnd0home_site",&homeSite);
									printf("\n save_method_4--1homeSite===>[%s]",homeSite);fflush(stdout);
									char*	sysCmnd	=	NULL;
									char* PNoStr = NULL;
									char* FNameStr = NULL;
									char* EROOR_MESSAGE_STR = NULL;
									sysCmnd=(char *) MEM_alloc(400);
									PNoStr=(char *) MEM_alloc(400);
									FNameStr=(char *) MEM_alloc(400);
									EROOR_MESSAGE_STR=(char *) MEM_alloc(500);
									tc_strcpy(PNoStr,ItemIdV);
									tc_strcpy(FNameStr,ItemIdV);
									tc_strcat(FNameStr,"_Create.txt");
									printf("\n save_method_4--1PNoStr: [%s]\n",PNoStr);fflush(stdout);
									printf("\n save_method_4--1FNameStr: [%s]\n",FNameStr);fflush(stdout);
									if(tc_strcmp(homeSite,"CV_Production")==0)
									{
										tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/CVPARTCHECK/PartCallingCVShell.sh ");
									}
									else if(tc_strcmp(homeSite,"Production-Pune")==0)
									{
										tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/UAPARTCHECK/PartCallingPVShell.sh ");
									}
									else if(tc_strcmp(homeSite,"Cmitest")==0 || tc_strcmp(homeSite,"AWS_FullTextSearch_Solr_Site")==0)
									{
										tc_strcpy(sysCmnd,"/user/testcmi/Dev/devgroups/sudhir/PartCheck/PartCallingCMITESTShell.sh ");
									}
									else if(tc_strcmp(homeSite,"IMC--1750164028")==0 || tc_strcmp(homeSite,"IMC--1254497832")==0)
									{
										tc_strcpy(sysCmnd,"/user/infodba03/sudhir/PartCheck/PartCallingDEVShell.sh ");
									}
									else
									{
										tc_strcpy(sysCmnd,partDuplicateCheckLocStr);
										tc_strcat(sysCmnd,partDuplicateCheckShellStr);
										tc_strcat(sysCmnd," ");
										//tc_strcat(sysCmnd,"PartCallingOtherShell.sh ");
									}
									tc_strcat(sysCmnd,PNoStr);
									tc_strcat(sysCmnd," ");
									tc_strcat(sysCmnd,FNameStr);
									printf("\n save_method_4--1Command: [%s]\n",sysCmnd);fflush(stdout);
									system(sysCmnd);
									MEM_free(sysCmnd);

									// File Open...

									FILE* fptr = NULL;
									char *File_Name = NULL;
									char *File_LOC = NULL;
									char *inputline = NULL;
									char	*f	=NULL;
									char	result1 [ 100000 ] ;
									char	result2 [ 100000 ] ;

									int i = 0;

									File_Name=(char *) MEM_alloc(300);
									File_LOC=(char *) MEM_alloc(400);
									tc_strcpy(File_Name,ItemIdV);
									tc_strcat(File_Name,"_Create.txt");

									if(tc_strcmp(homeSite,"CV_Production")==0)
									{
										tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/CVPARTCHECK/");
									}
									else if(tc_strcmp(homeSite,"Production-Pune")==0)
									{
										tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/UAPARTCHECK/");
									}
									else if(tc_strcmp(homeSite,"Cmitest")==0 || tc_strcmp(homeSite,"AWS_FullTextSearch_Solr_Site")==0)
									{
										tc_strcpy(File_LOC,"/user/testcmi/Dev/devgroups/sudhir/PartCheck/");
									}
									else if(tc_strcmp(homeSite,"IMC--1750164028")==0 || tc_strcmp(homeSite,"IMC--1254497832")==0)
									{
										tc_strcpy(File_LOC,"/user/infodba03/sudhir/PartCheck/");
									}
									else
									{
										//tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/");
										tc_strcpy(File_LOC,partDuplicateCheckLocStr);
									}
									//tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/");
									tc_strcat(File_LOC,File_Name);
									printf("\n save_method_4--1File_Name: [%s]",File_Name);fflush(stdout);
									printf("\n save_method_4--1File_LOC: [%s]",File_LOC);fflush(stdout);
									fptr=fopen(File_LOC,"r");
									if(fptr!=NULL)
									{
										inputline=(char *) MEM_alloc(50000);
										while(fgets(inputline,50000,fptr)!=NULL)
										{
											for (i = 0; i < strlen(inputline); i++)
											{
												if ( inputline[i] == '\n' || inputline[i] == '\r' )
													inputline[i] = '\0';
											}
											while(1)
											{
												f = strstr(inputline,",,");
												if(f==NULL)
												{
													break;
												}

												strcpy(result2,f+1);
												*(f+1)=' ';
												*(f+2)='\0';
												strcat(f,result2);
											}
											strcpy(result1,inputline);
											printf("\n save_method_4--1inputline .......%s",result1);fflush(stdout);
											itemId=tc_strtok(result1,"^");
											printf("\n save_method_4--1itemId .......[%s]",itemId);fflush(stdout);
											if(tc_strlen(itemId)>0 && tc_strcmp(itemId,"NA")!=0)
											{
												New_TML_Part_Number=(char *) MEM_alloc(200);
												tc_strcpy(New_TML_Part_Number, itemId);
												printf("\n save_method_4--1New_TML_Part_Number .......[%s]",New_TML_Part_Number);fflush(stdout);
												tc_strcpy(EROOR_MESSAGE_STR,New_TML_Part_Number);
												tc_strcat(EROOR_MESSAGE_STR," Is already available in TCE.\n");
												tc_strcat(EROOR_MESSAGE_STR,"Please get it loaded from PLM Team.");
												EMH_clear_errors();
												error_code=t9NewPartReqCre_Val0048;

												EMH_clear_errors();
												EMH_store_error_s1(EMH_severity_error,error_code,EROOR_MESSAGE_STR);
												return error_code;
											}
											else
											{
												printf("\n save_method_4--1PART NOT AVAILABLE IN TCE :: Allowed to create in TCUA"); fflush(stdout);
											}
										}
									}
									else
									{
										if(tc_strstr(partDuplicateCheckOffStr,"PARTDUPLICATECHECKOFF")!=NULL && n_Ctrlfound>0)
										{
											printf("\n save_method_4--11FILE NOT AVAILABLE :: ERROR MESSAGE TO BE PRINT"); fflush(stdout);
											EMH_clear_errors();
											error_code=t9NewPartReqCre_Val0048;

											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error,error_code,"There is an issue while duplicacy check b/w TCE and TCUA.Please Contact to PLM Support Team");
											return error_code;
										}
										else
										{
											printf("\n save_method_4--111FILE NOT AVAILABLE :: ERROR MESSAGE TO BE PRINT"); fflush(stdout);
										}

									}
								}
								else
								{
									printf(" \n save_method_4--1111FILE NOT AVAILABLE :: ERROR MESSAGE TO BE PRINT"); fflush(stdout);
								}
							} // else
						}//if(IsAvailInUA == 0)
						else
						{
							printf("\n save_method_4--1Part present in TCUA, so skip to check in TCE");fflush(stdout);
							if(tc_strstr(partDuplicateCheckOffStr,"PARTDUPLICATECHECKOFF")!=NULL && n_Ctrlfound>0 && tc_strstr(partDuplicateCheckSaveAsStr,"SaveAs")==NULL)
							{
								EMH_clear_errors();
								error_code=t9NewPartReqCre_Val0048;
								EMH_store_error_s1(EMH_severity_error,error_code,"Part is already available in TCUA, Please get it New Part Number");
								return error_code;
							}
							else
							{
								printf("\n save_method_4--1Part present in TCUA, so skip to check in TCE::Allowed");fflush(stdout);
							}

						}
					} // Webservice Logic..

					if(tc_strstr(partDuplicateCheckLogic2,"ClientCode")!=NULL)
					{
						IsAvailInUA = IsPartAvail(ItemIdV);
						printf(" \n save_method_4--2IsAvailInUA---> :%d:", IsAvailInUA); fflush(stdout);
						if(IsAvailInUA == 0)
						{
							char
								*qry_entries_ctrl[1] = {"SYSCD"},
								*qry_values_ctrl[1]	= {"*"};

							QRY_find2("Control Objects...", &query);
							if(query!=NULLTAG)
							{
								qry_values_ctrl[0] = "PartDuplicateCheck";
								QRY_execute(query, 1, qry_entries_ctrl, qry_values_ctrl, &n_Ctrlfound, &q_CtrlSet);
								printf("\n save_method_4--2n_Ctrlfound===%d",n_Ctrlfound);fflush(stdout);
								if(n_Ctrlfound>0)
								{
									AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo1",&partDuplicateCheckStr);
									printf("\n save_method_4--2partDuplicateCheckStr===>[%s]",partDuplicateCheckStr);fflush(stdout);

									AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo3",&partDuplicateCheckOffStr);
									printf("\n save_method_4--2partDuplicateCheckOffStr===>[%s]",partDuplicateCheckOffStr);fflush(stdout);

									AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo4",&partDuplicateCheckTypeStr);
									printf("\n save_method_4--2partDuplicateCheckTypeStr===>[%s]",partDuplicateCheckTypeStr);fflush(stdout);

									AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo5",&partDuplicateCheckLocStr);
									printf("\n save_method_4--2partDuplicateCheckLocStr===>[%s]",partDuplicateCheckLocStr);fflush(stdout);
									AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo6",&partDuplicateCheckShellStr);
									printf("\n save_method_4--2partDuplicateCheckLocStr===>[%s]",partDuplicateCheckShellStr);fflush(stdout);
									AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo7",&partDuplicateCheckSaveAsStr);
									printf("\n save_method_4--2partDuplicateCheckSaveAsStr===>[%s]",partDuplicateCheckSaveAsStr);fflush(stdout);
								}
							}
							if(tc_strstr(partDuplicateCheckStr,"PARTDUPLICATECHECK")!=NULL && n_Ctrlfound>0 && tc_strstr(partDuplicateCheckTypeStr,Part_TypeStr)==NULL)
							{
								printf("\n save_method_4--2Part not present in both TCUA and TCE. Please proceed.  ");fflush(stdout);
								char *homeSite = NULL;
								AOM_UIF_ask_value(user_tag,"fnd0home_site",&homeSite);
								printf("\n save_method_4--2homeSite===>[%s]",homeSite);fflush(stdout);
								char*	sysCmnd	=	NULL;
								char* PNoStr = NULL;
								char* FNameStr = NULL;
								char* EROOR_MESSAGE_STR = NULL;
								sysCmnd=(char *) MEM_alloc(400);
								PNoStr=(char *) MEM_alloc(400);
								FNameStr=(char *) MEM_alloc(400);
								EROOR_MESSAGE_STR=(char *) MEM_alloc(500);
								tc_strcpy(PNoStr,ItemIdV);
								tc_strcpy(FNameStr,ItemIdV);
								tc_strcat(FNameStr,"_Create.txt");
								printf("\n save_method_4--2PNoStr: [%s]",PNoStr);fflush(stdout);
								printf("\n save_method_4--2FNameStr: [%s]",FNameStr);fflush(stdout);
								if(tc_strcmp(homeSite,"CV_Production")==0)
								{
									tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/CVPARTCHECK/PartCallingCVShell.sh ");
								}
								else if(tc_strcmp(homeSite,"Production-Pune")==0)
								{
									tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/UAPARTCHECK/PartCallingPVShell.sh ");
								}
								else if(tc_strcmp(homeSite,"Cmitest")==0 || tc_strcmp(homeSite,"AWS_FullTextSearch_Solr_Site")==0)
								{
									tc_strcpy(sysCmnd,"/user/testcmi/Dev/devgroups/sudhir/PartCheck/PartCallingCMITESTShell.sh ");
								}
								else if(tc_strcmp(homeSite,"IMC--1750164028")==0 || tc_strcmp(homeSite,"IMC--1254497832")==0)
								{
									tc_strcpy(sysCmnd,"/user/infodba03/sudhir/PartCheck/PartCallingDEVShell.sh ");
								}
								else
								{
									tc_strcpy(sysCmnd,partDuplicateCheckLocStr);
									tc_strcat(sysCmnd,partDuplicateCheckShellStr);
									tc_strcat(sysCmnd," ");
									//tc_strcat(sysCmnd,"PartCallingOtherShell.sh ");
								}
								tc_strcat(sysCmnd,PNoStr);
								tc_strcat(sysCmnd," ");
								tc_strcat(sysCmnd,FNameStr);
								printf("\n save_method_4--2Command: [%s]",sysCmnd);fflush(stdout);
								system(sysCmnd);
								MEM_free(sysCmnd);

								// File Open...

								FILE* fptr = NULL;
								char *File_Name = NULL;
								char *File_LOC = NULL;
								char *inputline = NULL;
								char	*f	=NULL;
								char	result1 [ 100000 ] ;
								char	result2 [ 100000 ] ;

								int i = 0;

								File_Name=(char *) MEM_alloc(300);
								File_LOC=(char *) MEM_alloc(400);
								tc_strcpy(File_Name,ItemIdV);
								tc_strcat(File_Name,"_Create.txt");

								if(tc_strcmp(homeSite,"CV_Production")==0)
								{
									tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/CVPARTCHECK/");
								}
								else if(tc_strcmp(homeSite,"Production-Pune")==0)
								{
									tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/UAPARTCHECK/");
								}
								else if(tc_strcmp(homeSite,"Cmitest")==0 || tc_strcmp(homeSite,"AWS_FullTextSearch_Solr_Site")==0)
								{
									tc_strcpy(File_LOC,"/user/testcmi/Dev/devgroups/sudhir/PartCheck/");
								}
								else if(tc_strcmp(homeSite,"IMC--1750164028")==0 || tc_strcmp(homeSite,"IMC--1254497832")==0)
								{
									tc_strcpy(File_LOC,"/user/infodba03/sudhir/PartCheck/");
								}
								else
								{
									//tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/");
									tc_strcpy(File_LOC,partDuplicateCheckLocStr);
								}
								//tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/");
								tc_strcat(File_LOC,File_Name);
								printf("\n save_method_4--2File_Name: [%s]",File_Name);fflush(stdout);
								printf("\n save_method_4--2File_LOC: [%s]",File_LOC);fflush(stdout);
								fptr=fopen(File_LOC,"r");
								if(fptr!=NULL)
								{
									inputline=(char *) MEM_alloc(50000);
									while(fgets(inputline,50000,fptr)!=NULL)
									{
										for (i = 0; i < strlen(inputline); i++)
										{
											if ( inputline[i] == '\n' || inputline[i] == '\r' )
												inputline[i] = '\0';
										}
										while(1)
										{
											f = strstr(inputline,",,");
											if(f==NULL)
											{
												break;
											}

											strcpy(result2,f+1);
											*(f+1)=' ';
											*(f+2)='\0';
											strcat(f,result2);
										}
										strcpy(result1,inputline);
										printf("\n save_method_4--2inputline .......%s",result1);fflush(stdout);
										itemId=tc_strtok(result1,"^");
										printf("\n save_method_4--2itemId .......[%s]",itemId);fflush(stdout);
										if(tc_strlen(itemId)>0 && tc_strcmp(itemId,"NA")!=0)
										{
											New_TML_Part_Number=(char *) MEM_alloc(200);
											tc_strcpy(New_TML_Part_Number, itemId);
											printf("\n save_method_4--2New_TML_Part_Number .......[%s]",New_TML_Part_Number);fflush(stdout);
											tc_strcpy(EROOR_MESSAGE_STR,New_TML_Part_Number);
											tc_strcat(EROOR_MESSAGE_STR," Is already available in TCE.\n");
											tc_strcat(EROOR_MESSAGE_STR,"Please get it loaded from PLM Team.");

											EMH_clear_errors();
											error_code=t9NewPartReqCre_Val0048;
											EMH_store_error_s1(EMH_severity_error,error_code,EROOR_MESSAGE_STR);
											return error_code;
										}
										else
										{
											printf("\n save_method_4--2PART NOT AVAILABLE IN TCE :: Allowed to create in TCUA"); fflush(stdout);
										}
									}
								}
								else
								{
									if(tc_strstr(partDuplicateCheckOffStr,"PARTDUPLICATECHECKOFF")!=NULL && n_Ctrlfound>0)
									{
										printf("\n save_method_4--2FILE NOT AVAILABLE :: ERROR MESSAGE TO BE PRINT"); fflush(stdout);
										EMH_clear_errors();
										error_code=t9NewPartReqCre_Val0048;
										EMH_store_error_s1(EMH_severity_error,error_code,"There is an issue while duplicacy check b/w TCE and TCUA.Please Contact to PLM Support Team");
										return error_code;
									}
									else
									{
										printf("\n save_method_4--22FILE NOT AVAILABLE :: ERROR MESSAGE TO BE PRINT"); fflush(stdout);
									}

								}
							}
							else
							{
								printf("\n save_method_4--222FILE NOT AVAILABLE :: ERROR MESSAGE TO BE PRINT"); fflush(stdout);
							}
						}
						else
						{
							printf("\n save_method_4--2Part present in TCUA, so skip to check in TCE");fflush(stdout);
							if(tc_strstr(partDuplicateCheckOffStr,"PARTDUPLICATECHECKOFF")!=NULL && n_Ctrlfound>0 && tc_strstr(partDuplicateCheckSaveAsStr,"SaveAs")==NULL)
							{
								EMH_clear_errors();
								error_code=t9NewPartReqCre_Val0048;
								EMH_store_error_s1(EMH_severity_error,error_code,"Part is already available in TCUA, Please get it New Part Number");
								return error_code;
							}
							else
							{
								printf("\n save_method_4--2Part present in TCUA, so skip to check in TCE::Allowed");fflush(stdout);
							}
						}
					}

				}//if(ValCntT>0)
			}
		}// username

	} //if(partduplicatecheckrqd==1)
	/*END PART DUPLICATE CHECK*/

	if(strcmp(type_name,"Design Revision")==0 || strcmp(type_name,"T5_SparKitRevision")==0) //T5_SparKitRevision
	{
		printf("\n save_method_4--A-Inside preaction type Save Validation 4 design revison Session user [%s]  ",username);fflush(stdout);
		char *projcodeList=NULL;
		char *projcode=NULL;
		char *ItemIdV=NULL;
		char *sRevID=NULL;
		//char *Part_TypeStr=NULL;
		tag_t projobj1 = NULLTAG;

		if (objTag!=NULLTAG)
		{
			if( AOM_ask_value_string(objTag,"item_id",&ItemIdV)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(objTag,"item_revision_id",&sRevID)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(objTag,"project_ids",&projcodeList)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(objTag,"t5_ProjectCode",&projcode)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(objTag,"t5_DesignGrp",&Part_DegGrp)!=ITK_ok) PrintErrorStack();
			//if( AOM_ask_value_string(objTag,"t5_PartType",&Part_TypeStr)!=ITK_ok) PrintErrorStack();
		}
		printf("\n save_method_4--A-Project : <%s> ProjectList : <%s> %d ",projcode,projcodeList,strlen(projcodeList) );fflush(stdout);

		// Check Is Part Available in TCE.
		/*
		if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0))
		{
			printf("\n 1save_method_4::A-sRevID: [%s] so check availability in TCE ",sRevID);fflush(stdout);
			printf("\n 1save_method_4::A-Part_TypeStr: [%s] so check availability in TCE ",Part_TypeStr);fflush(stdout);
			printf("\n 1111save_method_4::flag [%d] ",flag);fflush(stdout);

			if(tc_strstr(sRevID,"NR")!=NULL && flag==1)
			{
				printf("\n 2save_method_4::A-sRevID: [%s] so check availability in TCE ",sRevID);fflush(stdout);

				int		IsAvailInUA			=	0;
				int		IsAvailInTCE		=	0;
				int		ValCntT				=	0;
				int		n_Ctrlfound				=	0;
				tag_t*	ValCntrlObjectTagT	=	NULLTAG;
				tag_t*	q_CtrlSet	=	NULLTAG;
				tag_t	qryTagT				=	NULLTAG;
				tag_t	query				=	NULLTAG;
				char    **qry_valuesT		=	(char **) MEM_alloc(10 * sizeof(char *));
				int		n_entryT			=	1;
				char    *qry_entryT[1]		=	{"SYSCD"};
				char *New_TML_Part_Number	= NULL;
				char *itemId	= NULL;
				char *partDuplicateCheckStr	= NULL;
				char *partDuplicateCheckOffStr	= NULL;
				char *partDuplicateCheckTypeStr	= NULL;
				char *partDuplicateCheckLocStr	= NULL;


				if(QRY_find2("ControlObjects", &qryTagT)!=ITK_ok) PrintErrorStack();
				if (qryTagT)
				{
					printf("\n Found Query ControlObjects  ");fflush(stdout);
				}
				else
				{
					printf("\n Not Found Query ControlObjects  ");fflush(stdout);
				}

				qry_valuesT[0] = "PartInTCE" ;
				if(QRY_execute(qryTagT, n_entryT, qry_entryT, qry_valuesT, &ValCntT, &ValCntrlObjectTagT)!=ITK_ok) PrintErrorStack();
				printf(" \n PartInTCE:ValCnt :%d:", ValCntT); fflush(stdout);

				if(ValCntT>0)
				{
					printf(" \n ItemIdV---> :%s:", ItemIdV); fflush(stdout);
					IsAvailInUA = IsDesignRevisionAvail(ItemIdV);
					printf(" \n IsAvailInUA---> :%d:", IsAvailInUA); fflush(stdout);

					if(IsAvailInUA == 0)
					{
						IsAvailInTCE = FunToCheckPartAvailInICE(ValCntrlObjectTagT[0],ItemIdV);
						printf("\n IsAvailInTCE--->[%d]  ",IsAvailInTCE);fflush(stdout);
						if(IsAvailInTCE==2)
						{
							printf("\n PART [%s] AVAILABLE IN TCE  ",ItemIdV);fflush(stdout);
							EMH_clear_errors();
							error_code=t9NewPartReqCre_Val0048;
							EMH_store_error_s1(EMH_severity_error,error_code,"Part is already available in TCE, Please get it loaded from PLM Team");
							return error_code;
						}
						else
						{
							char
								*qry_entries_ctrl[1] = {"SYSCD"},
								*qry_values_ctrl[1]	= {"*"};

							QRY_find2("Control Objects...", &query);
							if(query!=NULLTAG)
							{
								qry_values_ctrl[0] = "PartDuplicateCheck";
								QRY_execute(query, 1, qry_entries_ctrl, qry_values_ctrl, &n_Ctrlfound, &q_CtrlSet);
								printf("\n n_Ctrlfound===%d",n_Ctrlfound);fflush(stdout);
								if(n_Ctrlfound>0)
								{
									AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo1",&partDuplicateCheckStr);
									printf("\n partDuplicateCheckStr===>[%s]",partDuplicateCheckStr);fflush(stdout);

									AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo3",&partDuplicateCheckOffStr);
									printf("\n partDuplicateCheckOffStr===>[%s]",partDuplicateCheckOffStr);fflush(stdout);

									AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo4",&partDuplicateCheckTypeStr);
									printf("\n partDuplicateCheckTypeStr===>[%s]",partDuplicateCheckTypeStr);fflush(stdout);

									AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo5",&partDuplicateCheckLocStr);
									printf("\n partDuplicateCheckLocStr===>[%s]",partDuplicateCheckLocStr);fflush(stdout);
								}
							}
							if(tc_strstr(partDuplicateCheckStr,"PARTDUPLICATECHECK")!=NULL && n_Ctrlfound>0 && tc_strstr(partDuplicateCheckTypeStr,Part_TypeStr)==NULL)
							{
								printf("\n Part not present in both TCUA and TCE. Please proceed.  ");fflush(stdout);
								char *homeSite = NULL;
								AOM_UIF_ask_value(user_tag,"fnd0home_site",&homeSite);
								printf("\n homeSite===>[%s]",homeSite);fflush(stdout);
								char*	sysCmnd	=	NULL;
								char* PNoStr = NULL;
								char* FNameStr = NULL;
								char* EROOR_MESSAGE_STR = NULL;
								sysCmnd=(char *) MEM_alloc(400);
								PNoStr=(char *) MEM_alloc(400);
								FNameStr=(char *) MEM_alloc(400);
								EROOR_MESSAGE_STR=(char *) MEM_alloc(500);
								tc_strcpy(PNoStr,ItemIdV);
								tc_strcpy(FNameStr,ItemIdV);
								tc_strcat(FNameStr,"_Create.txt");
								printf("\n PNoStr: [%s]",PNoStr);fflush(stdout);
								printf("\n FNameStr: [%s]",FNameStr);fflush(stdout);
								if(tc_strcmp(homeSite,"CV_Production")==0)
								{
									tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/PartCallingCVShell.sh ");
								}
								else if(tc_strcmp(homeSite,"Production-Pune")==0)
								{
									tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/PartCallingPVShell.sh ");
								}
								else if(tc_strcmp(homeSite,"Cmitest")==0 || tc_strcmp(homeSite,"AWS_FullTextSearch_Solr_Site")==0)
								{
									tc_strcpy(sysCmnd,"/user/testcmi/Dev/devgroups/sudhir/PartCheck/PartCallingCMITESTShell.sh ");
								}
								else if(tc_strcmp(homeSite,"IMC--1750164028")==0 || tc_strcmp(homeSite,"IMC--1254497832")==0)
								{
									tc_strcpy(sysCmnd,"/user/infodba03/sudhir/PartCheck/PartCallingDEVShell.sh ");
								}
								else
								{
									tc_strcpy(sysCmnd,partDuplicateCheckLocStr);
									tc_strcat(sysCmnd,"PartCallingOtherShell.sh ");
								}
								tc_strcat(sysCmnd,PNoStr);
								tc_strcat(sysCmnd," ");
								tc_strcat(sysCmnd,FNameStr);
								printf("\n Command: [%s]",sysCmnd);fflush(stdout);
								system(sysCmnd);
								MEM_free(sysCmnd);

								// File Open...

								FILE* fptr = NULL;
								char *File_Name = NULL;
								char *File_LOC = NULL;
								char *inputline = NULL;
								char	*f	=NULL;
								char	result1 [ 100000 ] ;
								char	result2 [ 100000 ] ;

								int i = 0;

								File_Name=(char *) MEM_alloc(30);
								File_LOC=(char *) MEM_alloc(400);
								tc_strcpy(File_Name,ItemIdV);
								tc_strcat(File_Name,"_Create.txt");

								if(tc_strcmp(homeSite,"CV_Production")==0)
								{
									tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/");
								}
								else if(tc_strcmp(homeSite,"Production-Pune")==0)
								{
									tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/");
								}
								else if(tc_strcmp(homeSite,"Cmitest")==0 || tc_strcmp(homeSite,"AWS_FullTextSearch_Solr_Site")==0)
								{
									tc_strcpy(File_LOC,"/user/testcmi/Dev/devgroups/sudhir/PartCheck/");
								}
								else if(tc_strcmp(homeSite,"IMC--1750164028")==0 || tc_strcmp(homeSite,"IMC--1254497832")==0)
								{
									tc_strcpy(File_LOC,"/user/infodba03/sudhir/PartCheck/");
								}
								else
								{
									//tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/");
									tc_strcpy(File_LOC,partDuplicateCheckLocStr);
								}
								//tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/");
								tc_strcat(File_LOC,File_Name);
								printf("\n File_Name: [%s]",File_Name);fflush(stdout);
								printf("\n File_LOC: [%s]",File_LOC);fflush(stdout);
								fptr=fopen(File_LOC,"r");
								if(fptr!=NULL)
								{
									inputline=(char *) MEM_alloc(50000);
									while(fgets(inputline,50000,fptr)!=NULL)
									{
										for (i = 0; i < strlen(inputline); i++)
										{
											if ( inputline[i] == '\n' || inputline[i] == '\r' )
												inputline[i] = '\0';
										}
										while(1)
										{
											f = strstr(inputline,",,");
											if(f==NULL)
											{
												break;
											}

											strcpy(result2,f+1);
											*(f+1)=' ';
											*(f+2)='\0';
											strcat(f,result2);
										}
										strcpy(result1,inputline);
										printf("\n inputline .......%s",result1);fflush(stdout);
										itemId=tc_strtok(result1,"^");
										printf("\n itemId .......[%s]",itemId);fflush(stdout);
										if(tc_strlen(itemId)>0 && tc_strcmp(itemId,"NA")!=0)
										{
											New_TML_Part_Number=(char *) MEM_alloc(20);
											tc_strcpy(New_TML_Part_Number, itemId);
											printf("\n New_TML_Part_Number .......[%s]",New_TML_Part_Number);fflush(stdout);
											tc_strcpy(EROOR_MESSAGE_STR,New_TML_Part_Number);
											tc_strcat(EROOR_MESSAGE_STR," Is already available in TCE.\n");
											tc_strcat(EROOR_MESSAGE_STR,"Please get it loaded from PLM Team.");
											EMH_clear_errors();
											error_code=t9NewPartReqCre_Val0048;
											EMH_store_error_s1(EMH_severity_error,error_code,EROOR_MESSAGE_STR);
											return error_code;
										}
										else
										{
											printf(" \n PART NOT AVAILABLE IN TCE :: Allowed to create in TCUA"); fflush(stdout);
										}
									}
								}
								else
								{
									if(tc_strstr(partDuplicateCheckOffStr,"PARTDUPLICATECHECKOFF")!=NULL && n_Ctrlfound>0)
									{
										printf(" \n FILE NOT AVAILABLE :: ERROR MESSAGE TO BE PRINT"); fflush(stdout);
										EMH_clear_errors();
										error_code=t9NewPartReqCre_Val0048;
										EMH_store_error_s1(EMH_severity_error,error_code,"There is an issue while duplicacy check b/w TCE and TCUA.Please Contact to PLM Support Team");
										return error_code;
									}
									else
									{
										printf(" \n 1FILE NOT AVAILABLE :: ERROR MESSAGE TO BE PRINT"); fflush(stdout);
									}
								}
							}
							else
							{
								printf(" \n 2FILE NOT AVAILABLE :: ERROR MESSAGE TO BE PRINT"); fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n Part present in TCUA, so skip to check in TCE");fflush(stdout);
						EMH_clear_errors();
						error_code=t9NewPartReqCre_Val0048;
						EMH_store_error_s1(EMH_severity_error,error_code,"Part is already available in TCUA, Please get it New Part Number");
						return error_code;
					}
				}
			}
		}
		*/
		printf("\n save_method_4--B-Project : <%s> ProjectList : <%s> %d ",projcode,projcodeList,strlen(projcodeList) );fflush(stdout);
		if(strcmp(projcodeList,"")==0 || strlen(projcodeList) < 4) //project_list
		{
			if(strcmp(projcode,"")==0) //project_list
			{
				printf("\n save_method_4--Project is  NULL  ");fflush(stdout);
			}
			else
			{
				printf("\n save_method_4--Project from Object in else : %s ",projcode);fflush(stdout);

				if (PROJ_find(projcode,&projobj1) !=ITK_ok) PrintErrorStack();

				if(projobj1)
				{
					//printf("\nTCDCGetting Master Object for Project ");fflush(stdout);
					//if (ITEM_ask_item_of_rev( objTag,&objMasterTag)!=ITK_ok) PrintErrorStack();
					//printf("\nTCDCAfter Master Object for Project ");fflush(stdout);
					if (PROJ_assign_objects(1 ,&projobj1 ,1 ,&objTag )!=ITK_ok) PrintErrorStack();
					printf("\n save_method_4--Assigned to Project ");fflush(stdout);
				}
				else
				{
					printf("\n save_method_4--Project not found ");fflush(stdout);
				}
			}
		}
		else
		{
				printf("\n save_method_4--Projectlist already assigned Project : <%s> ProjectList : <%s> ",projcode,projcodeList);fflush(stdout);
		}

		//Bypass Revision Creation Validations If Found in SYSCD=VALDBYPASS Control Object
		if(QRY_find2("ControlObjQry", &TagQryContObjSite)!=ITK_ok) PrintErrorStack();
		if(TagQryContObjSite)
		{
			 if(QRY_execute(TagQryContObjSite, n_Input, qry_Input, qry_BypVal, &ByPasQCount, &cntr_objects)!=ITK_ok) PrintErrorStack();
			 printf("\n save_method_4--Objects for Query VALDBYPASS == %d", ByPasQCount);fflush(stdout);
		}
		else
		{
			printf("\n save_method_4--ContrlObj not found for SYSCD=VALDBYPASS");fflush(stdout);
		}

		if(ByPasQCount >0)
		{
			printf("\n save_method_4--Part Project Code [%s] Design Group :[%s]",projcode,Part_DegGrp);fflush(stdout);
			if (AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&info1)!=ITK_ok) PrintErrorStack();	//Design Group
			if (AOM_ask_value_string(cntr_objects[0],"t5_Userinfo2",&info2)!=ITK_ok) PrintErrorStack();//Project Code

			printf("\n save_method_4--Bypass Project Codes List [%s]",info2); fflush(stdout);
			printf("\n save_method_4--Bypass Design Group List [%s]",info1); fflush(stdout);

			if(tc_strstr(info2,projcode)!=NULL || tc_strstr(info1,Part_DegGrp)!=NULL)
			{
				CheckBypasFlag=1; //If not found in Control Object Creation check will be applied.
			}
		}

		//  Added by Aashish_w Start

		char *sValOutput=NULL;
		char *userinfo11=NULL;
		int IsValidProjNType =0;
		int n_entries11 =2;
		tag_t	Cntl_obj_Qtag11	=	NULLTAG;
		char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
		char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
		int resultCount11=0;
		tag_t *qry_cntrlobj11= NULLTAG;
		char *rlsstatus1=NULL;

		if(QRY_find2("Control Objects...", &Cntl_obj_Qtag11)!=ITK_ok) PrintErrorStack();

		qry_values11[0] = "PRTCATMAIN" ;
		qry_values11[1] = "PRTCATMAIN" ;

		if(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11)!=ITK_ok) PrintErrorStack();
		if (resultCount11 > 0)
		{
			AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo1",&userinfo11);
			if(tc_strcmp(userinfo11,"Y") ==0 )
			{
				printf("\n save_method_4--User Info 1 of Main Control Object is valid...  ");fflush(stdout);

				if( AOM_UIF_ask_value(objTag,"release_status_list",&rlsstatus1)!=ITK_ok) PrintErrorStack();
				printf("\n save_method_4--release_status_list -----------> %s  ",rlsstatus1);fflush(stdout);

				//if(strstr(rlsstatus1,"ERC Released"))
				//{
					printf("\n **************** Calling Function t5_partcategory  t5_partcategory $Welcome$ to Revise operation ****************  ");

					IsValidProjNType = t5_partcategory(objTag,&sValOutput);		//added by Aashish_w...

					if(IsValidProjNType==1)
					{
						printf("\n save_method_4--Part category is invalid...  ");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err, sValOutput);
						return ITK_err;
					}
					else
					{
						printf("\n save_method_4--Part Category is Valid... Please proceed.  ");fflush(stdout);
					}
				//}
				//else
				//{
				//	printf("\n Object is NOT Released........  ");fflush(stdout);
				//}
			}
			else
			{
				printf("\n save_method_4--User Info 1 of Main Control Object is NOT valid...  ");fflush(stdout);
				printf("\n save_method_4--Hence skipping the Part Category Rationalization...  ");fflush(stdout);
			}
		}
		// Added by Aashish_w End

		if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0))
		{
			char *sValOutput=NULL;
			int IsValidProjNType =0;

			// Validation: which part type is allowed to create for selected project code.

			IsValidProjNType = FunToValidateProjectCodeNPartType(objTag,&sValOutput);

			if(IsValidProjNType==1)
			{
				printf("\n save_method_4--Part type is invalid for selected project code  ");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, sValOutput);
				return ITK_err;
			}
			else
			{
				printf("\n save_method_4--Part type is valid for selected project code. Please proceed.  ");fflush(stdout);
			}

			// Add validation for TMETC and Trilix Site before creation of specific project code parts.
			ProSubStr=subString(ItemIdV,0,4);
			char *sOutput=NULL;
			int	ValidProj=0;
			printf("\n save_method_4--Call SiteViseProjectValidationCheck:11:ProSubStr: [%s] ",ProSubStr);fflush(stdout);
			ValidProj = SiteViseProjectValidationCheck(projcode,ProSubStr,&sOutput);
			printf("\n save_method_4--End SiteViseProjectValidationCheck: [%s] ",sOutput);fflush(stdout);

			if(ValidProj==1)
			{
				printf("\n save_method_4--Project code is invalid for this Site.   ");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, sOutput);
				return ITK_err;
			}
			else
			{
				printf("\n save_method_4--Project code is valid for this Site. Please proceed.   ");fflush(stdout);
			}
		}

		char *roleName	= NULL;
		if(SA_ask_current_role(&CurrentRoleTag)!=ITK_ok) PrintErrorStack();
		if(SA_ask_role_name2(CurrentRoleTag,&roleName)!=ITK_ok) PrintErrorStack();
		printf("\n save_method_4--dss roleName : %s ",roleName); fflush(stdout);

		if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0) && CheckBypasFlag==0)
		{
			//char   *sPartType1	 =NULL;
			//char   *sCatName	 =NULL;
			//char   *sDesignGrp	 =NULL;
			//if( AOM_ask_value_string(objTag,"t5_PartType",&sPartType1)!=ITK_ok) PrintErrorStack();
			//if( AOM_ask_value_string(objTag,"t5_CategoryName",&sCatName)!=ITK_ok) PrintErrorStack();
			//if(	AOM_UIF_ask_value(objTag,"t5_DesignGrp",&sDesignGrp)!=ITK_ok) PrintErrorStack();

			//if((tc_strcmp(sPartType1,"A")==0 || tc_strcmp(sPartType1,"C")==0))
			//{
			//printf("\n	Keyword description :%s",sCatName);fflush(stdout);
			//if(tc_strcmp(sCatName,"")==0)
			//{

			//printf("\n For  Part [%s]  Keyword description cannot be NULL ");fflush(stdout);
			//EMH_clear_errors();
			//EMH_store_error_s1(EMH_severity_error,ITK_err,"Keyword Description cannot be NULL for parttype Assembly and Component");
			//return ITK_err;
			//}
			//else
			//{
			//printf("\n	Keyword description :%s, Design Group : %s",sCatName,sDesignGrp);fflush(stdout);
			//char *qry_entries[2] = {"Name","ext_1"};
			//int n_entries= 2,n_found;
			//tag_t query = NULLTAG, *cntr_objects = NULL;
			//char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

			//qry_values[0] = sCatName ;
			//qry_values[1] = sDesignGrp;
			//QRY_find2("QryKyWrd_iDsgGrp_oClsfObj", &query);
			//QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects);
			//printf("\nKeyword n_found:%d", n_found);fflush(stdout);
			//if(n_found==0)
			//{
			//EMH_clear_errors();
			//EMH_store_error_s1(EMH_severity_error,ITK_err,"Keyword Description for Design Revision is not matched as per given Design Group of Design Revision");
			//return ITK_err;
			//}
			//}
			//}
			//Amol K

			//Added By Dhanashri for PPR part type validation for 14 digit


			if ( (strstr(roleName,"APL"))|| (strstr(roleName,"MBOM"))) //MBOM implementation for CV TZ-1.69
			{
				if (AOM_ask_value_string(objTag,"t5_PartType",&DesgTypPPR)!=ITK_ok) PrintErrorStack();
				printf("\n save_method_4--dss DesgTypPPR is  = [%s] ", DesgTypPPR);fflush(stdout);

				if( AOM_ask_value_string(objTag,"item_id",&desidForPPR)!=ITK_ok) PrintErrorStack();
				printf("\n save_method_4--dss desidForPPR is  = [%s] ", desidForPPR);fflush(stdout);

				sLastFourChar=subString(desidForPPR, strlen(desidForPPR)-4,4);
				printf("\n save_method_4--dss sLastFourChar == %s", sLastFourChar);fflush(stdout);


				if(tc_strcmp(DesgTypPPR,"PPR")==0)
				{
					if(tc_strcmp(sLastFourChar,"_PPR")!=0)
					{
						printf("\n save_method_4--dss For Part type Process Planning Resource 14 digit Partnumber should end with _PPR:  ");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"For Part Type 'Process Planning Resource', 14 digit PartNumber should end with '_PPR'.");
						return ITK_err;
					}
					else
					{
						iPPRid = strlen(desidForPPR);
						printf("\n save_method_4--dss iPPRid == %d", iPPRid);fflush(stdout);
						if((iPPRid)!=18)
						{
							printf("\n save_method_4--dss For Part type Process Planning Resource, Part Number should be 14 digit before '_PPR'.  ");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"For Part type 'Process Planning Resource', PartNumber should be 14 digits before '_PPR'.");
							return ITK_err;
						}
					}
				}

				if( (tc_strcmp(sLastFourChar,"_PPR")==0) && (tc_strcmp(DesgTypPPR,"PPR")!=0) )
				{
					printf("\n save_method_4--dss Item contains _PPR but partype diff  ");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Part Type should be 'Process Planning Resource' Since Item ID ends with '_PPR'.");
					return ITK_err;
				}
			}
			else
			{
				//Amol K for PPR part type validation
				if (AOM_ask_value_string(objTag,"t5_PartType",&DesgTypPPR)!=ITK_ok) PrintErrorStack();
				printf("\n save_method_4--DesgTypPPR is  = [%s] ", DesgTypPPR);fflush(stdout);
				if( AOM_ask_value_string(objTag,"item_id",&desidForPPR)!=ITK_ok) PrintErrorStack();
				sLastFourChar=subString(desidForPPR, strlen(desidForPPR)-4,4);
				printf("\n save_method_4--sLastFourChar == %s", sLastFourChar);fflush(stdout);

				if(tc_strcmp(DesgTypPPR,"PPR")==0)
				{
					if(tc_strcmp(sLastFourChar,"_PPR")!=0)
					{
						printf("\n save_method_4--For Part type Process Planning Resource 12 digits part number should end with _PPR:  ");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"For Part type Process Planning Resource 12 digits part number should end with '_PPR'.");
						return ITK_err;
					}
					else
					{
						iPPRid = strlen(desidForPPR);
						printf("\n iPPRid == %d", iPPRid);fflush(stdout);
						if((iPPRid)!=16)
						{
							printf("\n save_method_4--For Part type Process Planning Resource, Part Number should be 12 digits before '_PPR'.  ");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"For Part type Process Planning Resource, Part Number should be 12 digits before '_PPR'.");
							return ITK_err;
						}
					}
				}

				if( (tc_strcmp(sLastFourChar,"_PPR")==0) && (tc_strcmp(DesgTypPPR,"PPR")!=0) )
				{
					printf("\n save_method_4--Amol check Item contains _PPR but partype diff  ");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Part Type should be 'Process Planning Resource' Since Item ID ends with '_PPR'.");
					return ITK_err;
				}
				//end Amol K for PPR part type validation
			}
			//End of code Added By Dhanashri for PPR part type validation for 14 digit
			//Aadarsh
			tag_t Partypartctrlobj		=	NULLTAG;
			tag_t *CntrlObject_Partypart	=	NULLTAG;
			int Partypart_entries			=	1;
			int	Partypart_found			=	0;
			char *qry_Partypartcntrl[1]	= {"SYSCD"};
			char **qry_valuesPartypart		= (char **) MEM_alloc(10 * sizeof(char *));
			qry_valuesPartypart[0]			= "PartypartERCbypass";

			if(QRY_find2("Control Objects...",&Partypartctrlobj)!=ITK_ok) PrintErrorStack();
			//printf("\n\n save_method_4--CVBUBOMCntrlObj Query Found\n ");	fflush(stdout);

			if(QRY_execute(Partypartctrlobj, Partypart_entries, qry_Partypartcntrl, qry_valuesPartypart, &Partypart_found, &CntrlObject_Partypart)!=ITK_ok) PrintErrorStack();
			printf("\n save_method_4--PartyPartCntrlObj Control Object SYSCD :%d ",Partypart_found);	fflush(stdout);

			if(Partypart_found > 0)
			{
				if (AOM_ask_value_string(objTag,"item_id",&DesgNo)!=ITK_ok) PrintErrorStack();
				printf("\n save_method_4--DesgNo is  = [%s] ", DesgNo);fflush(stdout);
				if (AOM_ask_value_string(objTag,"t5_RefPartNumber",&RefPartNumber)!=ITK_ok) PrintErrorStack();
				printf("\n save_method_4--RefPartNumber is  = [%s] ", RefPartNumber);fflush(stdout);
				//Bypass for APL user

				if ( (strstr(roleName,"APL")==NULL) || (strstr(roleName,"MBOM")==NULL)) //MBOM implementation for CV TZ-1.69
				{
					//if(RefPartNumber)		//
					if(tc_strcmp(RefPartNumber,"")!=0)	 //MBOM implementation for CV TZ-1.69
					{
						char *qryParty_InputVal[2] = {DesgNo,RefPartNumber};
						if(QRY_find2("QryDesRevUsgPartyPart", &TagQryPartyPart)!=ITK_ok) PrintErrorStack();
						//if(TagQryPartyPart)	 //MBOM implementation for CV TZ-1.69
						if (TagQryPartyPart!=NULLTAG) //MBOM implementation for CV TZ-1.69
						{
							if(QRY_execute(TagQryPartyPart, n_InputC, qryParty_Input, qryParty_InputVal, &outobjcnt, &Res_des_objs)!=ITK_ok) PrintErrorStack();
							printf("\n save_method_4--Objects for Query TagQryPartyPart == %d", outobjcnt);fflush(stdout);
							if(outobjcnt >0)
							{
								if (AOM_ask_value_string(Res_des_objs[0],"item_id",&DesgNoFound)!=ITK_ok) PrintErrorStack();
								printf("\n save_method_4--DesgNoFound is  = [%s] ", DesgNoFound);fflush(stdout);
								ErrorString=(char *) MEM_alloc(150);
								printf(" After mem alloc ");
								tc_strcpy (ErrorString, "Party/Vendor Part ");
								strcat(ErrorString,RefPartNumber);
								strcat(ErrorString," is already used with Design ");
								strcat(ErrorString,DesgNoFound);
								strcat(ErrorString,". Please select other Party/Vendor Part.");

								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,ErrorString);
								return ITK_err;
							}
						}
						else
						{
						  printf("\n save_method_4--QryDesRevUsgPartyPart query not found");fflush(stdout);
						}
					}
				}
			}

			char* sPartColInd=NULL;
			if( AOM_ask_value_string(objTag,"t5_ColourInd",&sPartColInd)!=ITK_ok) PrintErrorStack();
			printf("\n save_method_4--color indicator :%s",sPartColInd);fflush(stdout);

			/*
			if((tc_strcmp(sPartColInd,"Y")==0))
			{
			printf("\n	color indicator of part is Y");fflush(stdout);
			char* sPrtCompCode=NULL;
			if( AOM_ask_value_string(objTag,"t5_PrtCatCode",&sPrtCompCode)!=ITK_ok) PrintErrorStack();
			if(tc_strcmp(sPrtCompCode,"")==0)
			{
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"For Color Indicator 'Y', COMP CODE should not be NULL");
			return ITK_err;
			}
			}
			*/

			if((tc_strcmp(sPartColInd,"N")==0))
			{
				if((tc_strstr(rolename,"APLP_Planner")==NULL)) //TZ 1.79 pl922201 bypass Color Indicator 'N', COMP CODE should be NULL check while updating CS TCUA/CR/PLM SYS/APL/24/0032
				{
					printf("\n save_method_4--color indicator of part is => N ");fflush(stdout);

					char* nPrtCompCode=NULL;
					if( AOM_ask_value_string(objTag,"t5_PrtCatCode",&nPrtCompCode)!=ITK_ok) PrintErrorStack();
					printf("\n save_method_4--PrtCompCode of part is => %s ",nPrtCompCode);fflush(stdout);

					if(tc_strcmp(nPrtCompCode,"")!=0)
					{
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"For Color Indicator 'N', COMP CODE should be NULL");
						return ITK_err;
					}
				}
				else
				{
					printf("\n save_method_4--TZ 1.79 pl922201 bypass Color Indicator 'N', COMP CODE should be NULL check while updating CS TCUA/CR/PLM SYS/APL/24/0032 ");fflush(stdout);
				}
			}

			if(QRY_find2("ControlObjQry", &TagQryContObjSite)!=ITK_ok) PrintErrorStack();
			if(TagQryContObjSite)
			{
				if(QRY_execute(TagQryContObjSite, n_Input, qry_Input, qry_InputVal, &CntrCount, &cntr_objects)!=ITK_ok) PrintErrorStack();
				printf("\n save_method_4--Objects for Query ControlBasedOnSite == %d", CntrCount);fflush(stdout);
			}
			else
			{
				printf("\n save_method_4--ContrlObjQry query not found");fflush(stdout);
			}

			if (AOM_ask_value_string(objTag,"item_id",&DesRNo)!=ITK_ok) PrintErrorStack();
			printf("\n save_method_4--DesRNo is  = [%s] ", DesRNo);fflush(stdout);
			//if(ITEM_find_item(DesRNo,&Destag)!=ITK_ok) PrintErrorStack();//Revise - Ashwini

			printf("\n save_method_4--Revise API Change and call  IsDesignRevisionAvail() for [%s] Item ", DesRNo);fflush(stdout);
			int		IsRAvailInUA			=	0;
			IsRAvailInUA = IsDesignRevisionAvail(DesRNo);

			printf("\n save_method_4--Revise IsRAvailInUA= [%d] ", IsRAvailInUA);fflush(stdout);

			//if(Destag==NULLTAG)
			if(IsRAvailInUA==0)
			{
				printf("\n save_method_4--CntrCount: [%d] ",CntrCount);fflush(stdout);
				if(CntrCount >0 )
				{
					if( AOM_ask_value_string(objTag,"item_id",&desidForTRL)!=ITK_ok) PrintErrorStack();
					sLastThreeChar=subString(desidForTRL, strlen(desidForTRL)-4,4);
					printf("\n save_method_4--sLastThreeChar == %s", sLastThreeChar);fflush(stdout);
					if(tc_strcmp(sLastThreeChar,"_TRL")!=0)
					{
						printf("\n save_method_4--For TRILIX SITE part number should end with _TRL: validation removed as per CR-FY20-0028   ");fflush(stdout);
						//EMH_clear_errors();
						//EMH_store_error_s1(EMH_severity_error,ITK_err,"For TRILIX site, Part number should end with '_TRL'.");
						//return ITK_err;
					}

					if (AOM_ask_value_string(objTag,"t5_PartType",&DesgTypTRL)!=ITK_ok) PrintErrorStack();
					printf("\n save_method_4--DesgTyp is  = [%s] ", DesgTypTRL);fflush(stdout);
					if(tc_strcmp(DesgTypTRL,"D")!=0)
					{
						printf("\n save_method_4--For TRILIX site, Part Type should be 'Dummy': validation removed as per CR-FY20-0028  ");fflush(stdout);
						//EMH_clear_errors();
						//EMH_store_error_s1(EMH_severity_error,ITK_err,"For TRILIX site, Part Type should be 'Dummy'.");
						//return ITK_err;
					}
				}
			}

			if(QRY_find2("ControlObjects", &qryTag)!=ITK_ok) PrintErrorStack();
			if (qryTag)
			{
				printf("\n save_method_4--CREVali:Found Query ControlObjects  ");fflush(stdout);

				qry_values2[0] = "CREVali" ;
				if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag)!=ITK_ok) PrintErrorStack();
			}
			else
			{
				printf("\n save_method_4--CREVali:Not Found Query ControlObjects  ");fflush(stdout);
			}

			printf(" \n save_method_4--CREVali:rsltCount 22:%d:", rsltCount); fflush(stdout);
			if(rsltCount>0)
			{
				if ( (strstr(roleName,"APL")==NULL) || (strstr(roleName,"MBOM")==NULL)) //MBOM implementation for CV TZ-1.69
				{
					if (AOM_ask_value_string(objTag,"item_id",&DesgNo)!=ITK_ok) PrintErrorStack();
					printf("\n save_method_4--DesgNo is  = [%s] ", DesgNo);fflush(stdout);

					if (AOM_ask_value_string(objTag,"t5_ProjectCode",&Part_prj)!=ITK_ok) PrintErrorStack();
					printf("\n save_method_4--Part_prj is  = [%s] ", Part_prj);fflush(stdout);	//ADI ST

					if (AOM_ask_value_string(objTag,"t5_DesignGrp",&STDesGrp)!=ITK_ok) PrintErrorStack(); //ADI ST
					printf("\n save_method_4--STDesGrp is  = [%s] ", STDesGrp);fflush(stdout);								//ADI ST

					if (AOM_ask_value_string(objTag,"t5_PartType",&DesgTyp)!=ITK_ok) PrintErrorStack();
					printf("\n save_method_4--DesgTyp is  = [%s] ", DesgTyp);fflush(stdout);
					if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok) PrintErrorStack();
					printf("\n save_method_4--info1 is  = [%s] ", info1);fflush(stdout);
					if(SA_ask_current_role(&CurrentRoleTag)!=ITK_ok) PrintErrorStack();
					if(SA_ask_role_name2(CurrentRoleTag,&roleName)!=ITK_ok) PrintErrorStack();
					printf("\n save_method_4--roleName : %s ",roleName); fflush(stdout);

					//if(((tc_strcmp(DesgTyp,"A")==0) || (tc_strcmp(DesgTyp,"C")==0))&& (tc_strlen(DesgNo) !=12)&& (tc_strlen(DesgNo) !=11) &&  ( (!strstr(roleName,"APL"))  ||  (!strstr(roleName,"MBOM")) ))  //MBOM implementation for CV TZ-1.69
					//Added Hrishikesh TZ1.70 02.06.2023 (Added CKC and 14 digit)
					if(((tc_strcmp(DesgTyp,"A")==0) || (tc_strcmp(DesgTyp,"C")==0))&& ((tc_strlen(DesgNo) !=12)&& (tc_strlen(DesgNo) !=11) && (tc_strlen(DesgNo) !=14) && (tc_strstr(DesgNo,"CK")==NULL)) &&  ( (!strstr(roleName,"APL"))  ||  (!strstr(roleName,"MBOM")) ))  //MBOM implementation for CV TZ-1.69
					{
						printf("\n save_method_4--Assembly or component must be 12 digit: [%s] ", DesgNo);fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"For part type assembly or component, part number must be 12 digit.");
						return ITK_err;
					}

					//Ashwini - Dummy Component/Dummy Assembly /Component   parttype not allowed if for 12-digit part 9th and 10th digit is 01. It has to be assembly.
					//printf("\nPart_prj=%s,STDesGrp = %s  ",Part_prj,STDesGrp);fflush(stdout);
					PartCreationBypassFlag = 0;
					if(tc_strcmp(STDesGrp,"ST")==0)
					{
						PartCreationBypassFlag = 1;
					}

					qry_dfqCtrObjct[0] = "TMETC_ProjectCdeList_allow_PartCreation";

					if(QRY_execute(qryTag, n_dfqentry,qry_entry, qry_dfqCtrObjct, &rsltDfqCount, &CntrlObjectTag11)!=ITK_ok) PrintErrorStack();
					printf(" \n save_method_4--Part Creation Bypass TMETC_ProjectCdeList_allow_PartCreation:rsltDfqCount :%d: ", rsltDfqCount); fflush(stdout);

					if(rsltDfqCount > 0)
					{
						if (AOM_ask_value_string(CntrlObjectTag11[0],"t5_Userinfo1",&info1)!=ITK_ok) PrintErrorStack();
						printf("\n save_method_4--info1 is.:[%s] ", info1);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag11[0],"t5_Userinfo2",&info2)!=ITK_ok) PrintErrorStack();
						printf("\n save_method_4--info2 is.:[%s] ", info2);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag11[0],"t5_Userinfo3",&info3)!=ITK_ok) PrintErrorStack();
						printf("\n save_method_4--info3 is.:[%s] ", info3);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag11[0],"t5_Userinfo4",&info4)!=ITK_ok) PrintErrorStack();
						printf("\n save_method_4--info4 is.:[%s] ", info4);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag11[0],"t5_Userinfo5",&info5)!=ITK_ok) PrintErrorStack();
						printf("\n save_method_4--info5 is.:[%s] ", info5);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag11[0],"t5_Userinfo6",&info6)!=ITK_ok) PrintErrorStack();
						printf("\n save_method_4--info6 is.:[%s] ", info6);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag11[0],"t5_Userinfo7",&info7)!=ITK_ok) PrintErrorStack();
						printf("\n save_method_4--info7 is.:[%s] ", info7);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag11[0],"t5_Userinfo8",&info8)!=ITK_ok) PrintErrorStack();
						printf("\n save_method_4--info8 is.:[%s] ", info8);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag11[0],"t5_Userinfo9",&info9)!=ITK_ok) PrintErrorStack();
						printf("\n save_method_4--info9 is.:[%s] ", info9);fflush(stdout);

						if((tc_strstr(info1,Part_prj)!=NULL) || (tc_strstr(info2,Part_prj)!=NULL) || (tc_strstr(info3,Part_prj)!=NULL) || (tc_strstr(info4,Part_prj)!=NULL) || (tc_strstr(info5,Part_prj)!=NULL) || (tc_strstr(info6,Part_prj)!=NULL) || (tc_strstr(info7,Part_prj)!=NULL) || (tc_strstr(info8,Part_prj)!=NULL) || (tc_strstr(info9,Part_prj)!=NULL))
						{
							printf("\n save_method_4--%s Project Code control object found for TMETC %s... ",Part_prj);fflush(stdout);
							PartCreationBypassFlag = 1;
						}
					}
					printf("\n save_method_4--PartCreationBypassFlag = %d",PartCreationBypassFlag);fflush(stdout);
					if(PartCreationBypassFlag != 1)
					{
						if(tc_strlen(DesgNo) == 12)
						{
							sDesgNoTN=subString(DesgNo,8,2);
							printf("\n save_method_4--9th and 10th digit of Design [%s] and Lenth = [%d] and Type = [%s] ",sDesgNoTN,tc_strlen(DesgNo),DesgTyp);fflush(stdout);
							if(tc_strcmp(sDesgNoTN,"01") == 0)
							{
								if(tc_strcmp(DesgTyp,"A")!= 0)
								{
									printf("\n save_method_4--Assembly or component must be 12 digit: [%s] ", DesgNo);fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Part Lenght is 12 digit and 9th and 10th digit are 01. Please select Part Type as 'Assembly'");
									return ITK_err;
								}
								else
								{
									printf("\n save_method_4--12 digit part type with assembly allow to create part because 9th and 10th digits are 01.. ");fflush(stdout);
								}
							}
						}
					}
					//
					//if(((tc_strcmp(DesgTyp,"DC")== 0) || (tc_strcmp(DesgTyp,"DA")== 0) || (tc_strcmp(DesgTyp,"C")== 0)) && (tc_strlen(DesgNo) == 12))
					//{
					//}

					//Ashwini - TC part having space in the name
					if(tc_strstr(DesgNo," ") != 0)
					{
						printf("\n save_method_4--TC part having space in the name: [%s] ", DesgNo);fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Space Not allowed in Part Number");
						return ITK_err;
					}
					if (tc_strcmp(DesgTyp,"T")==0)
					{
						//TPL should be 11/13 digit and end with R/L
						sDesgNoT=subString(DesgNo, 10, 1);
						sDesgNoT1=subString(DesgNo, 12, 1); //NSS CR-FY25-0184 29May2025 UA 1.83
						printf("\n save_method_4--TPL last digit: [%s] ", sDesgNoT);fflush(stdout);
						if (((tc_strlen(DesgNo) == 11)&& ((tc_strcmp(sDesgNoT,"R")==0)||(tc_strcmp(sDesgNoT,"L")==0))) ||
							((tc_strlen(DesgNo) == 13)&& ((tc_strcmp(sDesgNoT1,"R")==0)||(tc_strcmp(sDesgNoT1,"L")==0))))
						{
							printf("\n save_method_4--TPL is 11/13 digit: [%s] ", DesgNo);fflush(stdout);
						}
						else
						{
							printf("\n save_method_4--TPL is not 11 digit: [%s] ", DesgNo);fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"For part type TPL, part number must be 11 digit and end with R/L.");
							return ITK_err;
						}
					}
					if (tc_strcmp(DesgTyp,"M")==0)
					{
						//Module should be 14 digit.
						printf("\n save_method_4--TPL last digit ");fflush(stdout);
						if (tc_strlen(DesgNo) ==14)
						{
							printf("\n save_method_4--Module is 14 digit: [%s] ", DesgNo);fflush(stdout);
						}
						else
						{
							printf("\n save_method_4--Module is not 14 digit: [%s] ", DesgNo);fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Module must be 14 digit.");
							return ITK_err;
						}
					}
					//if (strcmp(DesgTyp,"G")==0)
					//{
					//	//Work for frist digit should be G and and part length should be 7 digit
					//	sDesgNoG=subString(DesgNo, 0, 1);
					//	printf("\n Group ID first digit: [%s] ", sDesgNoG);fflush(stdout);
					//	if ((tc_strlen(DesgNo) ==7)&& (strcmp(sDesgNoG,"G")==0))
					//	{
					//		printf("\n Group ID is 7 digit: [%s] ", DesgNo);fflush(stdout);
					//	}
					//	else
					//	{
					//		printf("\n Group Id is not 7 digit: [%s] ", DesgNo);fflush(stdout);
					//		EMH_store_error_s1(EMH_severity_error,ITK_err,"For Group Id, part number must be 7 digit and Start with G.");
					//		return ITK_err;
					//	}
					//}
					if (tc_strcmp(DesgTyp,"V")==0)
					{
						//vehicle should be 9 digit and end with R/L
						sDesgNoV=subString(DesgNo, 8, 1);
						printf("\n save_method_4--Vehicle last digit: [%s] ", sDesgNoV);fflush(stdout);
						if ((tc_strlen(DesgNo) ==9)&& ((tc_strcmp(sDesgNoV,"R")==0)||(tc_strcmp(sDesgNoV,"L")==0)))
						{
							printf("\n save_method_4--Vehicle is 9 digit: [%s] ", DesgNo);fflush(stdout);
						}
						else
						{
							printf("\n save_method_4--Vehicle is not 9 digit: [%s] ", DesgNo);fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"For vehicle, part number must be 9 digit and end with R/L.");
							return ITK_err;
						}
					}
					if (tc_strcmp(DesgTyp,"VC")==0)
					{
						//VC should be 12 digit and end with R/L
						sDesgNoVC=subString(DesgNo, 11, 1);
						printf("\n save_method_4--VC last digit: [%s] ", sDesgNoVC);fflush(stdout);
						if ((tc_strlen(DesgNo) ==12)&& ((tc_strcmp(sDesgNoVC,"R")==0)||(tc_strcmp(sDesgNoVC,"L")==0)))
						{
							printf("\n save_method_4--VC is 12 digit: [%s] ", DesgNo);fflush(stdout);
						}
						else
						{
							printf("\n save_method_4--VC is not 9 digit: [%s] ", DesgNo);fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"For VC, part number must be 12 digit and end with R/L.");
							return ITK_err;
						}
					}
					if (tc_strcmp(DesgTyp,"VCCR")==0)
					{
						tag_t VCCR_CntrlOBJ	=	NULLTAG;
						int VCCR_entries = 1;
						int	VCCR_found	=	0;
						tag_t *CntrlObject_VCCR	=	NULLTAG;

						if(QRY_find2("Control Objects...",&VCCR_CntrlOBJ)!=ITK_ok) PrintErrorStack();
						//printf("\nVCCRCntrlObj Query Found..");	fflush(stdout);

						char *qry_VCCRcntrl[1] = {"SYSCD"};
						char **qry_valuesVCCR = (char **) MEM_alloc(10 * sizeof(char *));
						qry_valuesVCCR[0] = "VCCRCVBUCntrlObj";

						if(QRY_execute(VCCR_CntrlOBJ, VCCR_entries, qry_VCCRcntrl, qry_valuesVCCR, &VCCR_found, &CntrlObject_VCCR)!=ITK_ok) PrintErrorStack();
						printf("\n VCCR SYSCD :%d",VCCR_found);	fflush(stdout);
						if(VCCR_found>0)
						{
							if(AOM_ask_value_string(objTag,"item_revision_id",&DesgRev)!=ITK_ok) PrintErrorStack();
							printf("\n Design Revision's revision to create is %s",DesgRev);fflush(stdout);
							if(tc_strstr(DesgRev,"NR") == NULL)
							{
									//VCCR should be 12 digit and end with R/L
									sDesgNoVCCR=subString(DesgNo, 11, 1);
									printf("\n save_method_4--VCCR last digit: [%s] ", sDesgNoVCCR);fflush(stdout);
									if ((tc_strlen(DesgNo) ==12)&& ((tc_strcmp(sDesgNoVCCR,"R")==0)||(tc_strcmp(sDesgNoVCCR,"L")==0)))
									{
										printf("\n save_method_4--VCCR is 12 digit: [%s] ", DesgNo);fflush(stdout);
									}
									else
									{
										printf("\n save_method_4--VCCR is not 9 digit: [%s] ", DesgNo);fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err,"For VCCR, part number must be 12 digit and end with R/L.");
										return ITK_err;
									}
							}
							else
							{
										printf("\n save_method_4--VCCR of NR revision is tried to create ");fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err,"Creation of Vehicle Combination CR  is not allowed");
										return ITK_err;
							}
						}
						else
						{
							//VCCR should be 12 digit and end with R/L
							sDesgNoVCCR=subString(DesgNo, 11, 1);
							printf("\n save_method_4--VCCR last digit: [%s] ", sDesgNoVCCR);fflush(stdout);
							if ((tc_strlen(DesgNo) ==12)&& ((tc_strcmp(sDesgNoVCCR,"R")==0)||(tc_strcmp(sDesgNoVCCR,"L")==0)))
							{
								printf("\n save_method_4--VCCR is 12 digit: [%s] ", DesgNo);fflush(stdout);
							}
							else
							{
								printf("\n save_method_4--VCCR is not 9 digit: [%s] ", DesgNo);fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,"For VCCR, part number must be 12 digit and end with R/L.");
								return ITK_err;
							}
						}
					}
					if (tc_strcmp(DesgTyp,"D")==0 && CntrCount==0 )//bypassed for trilix site
					{
						//Dummy part should be 12 digit and 9th and 10th digit should be 00/04

						if(tc_strcmp(STDesGrp,"ST")!=0) //ADI ALIAS
						{
						sDesgNoD=subString(DesgNo, 8, 2);
						printf("\n save_method_4--VCCR last digit: [%s] ", sDesgNoD);fflush(stdout);
						if (tc_strlen(DesgNo) ==12)
						{
							if ((tc_strcmp(sDesgNoD,"04")!=0)&&(tc_strcmp(sDesgNoD,"00")!=0))
							{
								printf("\n save_method_4--Dummy is 12 digit: [%s] ", DesgNo);fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,"For 12 digit Dummy part, 9th and 10th digit of part number must be 00/04.");
								return ITK_err;
							}
						}
						}
						else
						{
							printf("\n save_method_4--design group ST hence bypassing dummy part validation  " );fflush(stdout); //ADI ALIAS
						}
					}

					if((tc_strcmp(DesgTyp,"A")==0 || tc_strcmp(DesgTyp,"C")==0 || tc_strcmp(DesgTyp,"D")==0) && tc_strlen(DesgNo)==12)
					{
						// If Design Revision Number - XXXX XX XX 16 XX
						ThirdBarrel = subString(DesgNo,8,2);
						if (AOM_ask_value_string(objTag,"t5_SpareCriteria",&SpareCrit)!=ITK_ok) PrintErrorStack();
						printf("\n --C1--save_method_4--Part [%s] ThirdBarrel [%s] Part Category-AA [%s] ", DesgNo,ThirdBarrel,SpareCrit);fflush(stdout);

						if(tc_strcmp(ThirdBarrel,"16")==0 && (tc_strcmp((subString(SpareCrit,0,3)),"TSD")!=0 || tc_strlen(SpareCrit)==0))   //added Substring after TSD error Date : 16-01-2024
						{
							//Hard Check To Select TSD
							printf("\n--C1--save_method_4--If Part [%s] and ThirdBarrel [%s] Please select Part Category Value : TSD ",DesgNo,ThirdBarrel);fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Parts Numbers Third Barrel is 16, Part Category Value Should be TSD : TML specification drawing");
							return ITK_err;
						}
					}

					// When new TC Part created with 9th and 10 th digit as 00 or 04 then Part type should be Info Fitment Drawing or Table Drawing

					if(QRY_find2("ControlObjects", &qryTag1)!=ITK_ok) PrintErrorStack();
					if (qryTag1)
					{
						printf("\n save_method_4--IFDNTDVal:Found Query ControlObjects  ");fflush(stdout);
					}
					else
					{
						printf("\n save_method_4--IFDNTDVal:Not Found Query ControlObjects  ");fflush(stdout);
					}

					qry_values3[0] = "IFDNTDVal" ;
					if(QRY_execute(qryTag1, n_entry, qry_entry, qry_values3, &ValCnt, &ValCntrlObjectTag1)!=ITK_ok) PrintErrorStack();
					printf("\n save_method_4--IFDNTDVal:ValCnt :%d:", ValCnt); fflush(stdout);

					if(ValCnt>0)
					{
						if((tc_strcmp(DesgTyp,"IFD")==0) && tc_strlen(DesgNo)==12)
						{
							if(tc_strcmp(STDesGrp,"ST")!=0) //skip ALIAS
							{
								printf("\n save_method_4--validation for Info Fitment Drawing or Table Drawing");fflush(stdout);
								// If Design Revision Number - XXXX XX XX 00/04 XX
								ForthBarrel = subString(DesgNo,8,2);
								printf("\n save_method_4--ForthBarrel: [%s]",ForthBarrel);fflush(stdout);
								if(tc_strcmp(ForthBarrel,"00")==0)
								{
									printf("\n save_method_4--ForthBarrel is: [%s], so you can create IFD ",ForthBarrel);fflush(stdout);
								}
								else
								{
									printf("\n save_method_4--If Part [%s] and ForthBarrel [%s] Please select Part Type: IFD ",DesgNo,ForthBarrel);fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err,"For Part Type IFD [Info Fitment Drawing], 9th and 10th digit should be 00");
									return ITK_err;
								}
							}
						}
						if((tc_strcmp(DesgTyp,"TD")==0) && tc_strlen(DesgNo)==12)
						{
							if(tc_strcmp(STDesGrp,"ST")!=0) //skip ALIAS
							{
								printf("\n save_method_4--validation for Table Drawing");fflush(stdout);
								// If Design Revision Number - XXXX XX XX 00/04 XX
								ForthBarrel = subString(DesgNo,8,2);
								printf("\n save_method_4--ForthBarrel: [%s]",ForthBarrel);fflush(stdout);
								if(tc_strcmp(ForthBarrel,"04")==0)
								{
									printf("\n save_method_4--ForthBarrel is: [%s], so you can create TD ",ForthBarrel);fflush(stdout);
								}
								else
								{
									printf("\n save_method_4--If Part [%s] and ForthBarrel [%s] Please select Part Type: TD ",DesgNo,ForthBarrel);fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err,"For Part Type TD [Table Drawing], 9th and 10th digit should be 04");
									return ITK_err;
								}
							}
						}
					}

					if (AOM_ask_value_string(objTag,"t5_ProjectCode",&Part_prj)!=ITK_ok) PrintErrorStack();
					if (AOM_ask_value_string(objTag,"t5_DesignGrp",&Part_DegGrp)!=ITK_ok) PrintErrorStack();
					printf("\n save_method_4--Part Project code is  = [%s] DsgGrp [%s] ", Part_prj,Part_DegGrp);fflush(stdout);
					printf("\n save_method_4--DesgNo while Save As is  = [%s]", DesgNo);fflush(stdout); //objTag
					printf("\n save_method_4--DesgTyp while Save As is  = [%s] -- AR", DesgTyp);fflush(stdout); //objTag
					char *DesignGroup = NULL;
					char *Project_Code = NULL;
					if(tc_strlen(DesgNo)==14 && tc_strcmp(DesgTyp,"M")==0)
					{
						char *Temp_NewModuleNumber = NULL;
						char *NewPartReq_prj = NULL;
						char *NewPartReq_DesignGrp = NULL;
						char *NewPartReq_ModAdd = NULL;
						char *NewPartReq_DrSt = NULL;
						char *NewPartReq_SubModule = NULL;
						char *NewPartReq_AggregateGrp = NULL;
						char *NewPartReq_Aggregates = NULL;
						char *NewPartReq_Module = NULL;
						char *NewPartReq_Plateform = NULL;
						char *NewPartReq_StartPartProduct = NULL;
						char *NewPartReq_PartCategory = NULL;
						char *NewPartReq_PartType = NULL;
						char *TempSubModuleAddress = NULL;

						char *PartDescription = NULL;
						tag_t	NPR_query	= NULLTAG;
						tag_t	*New_PartReqObjs	= NULLTAG;
						tag_t	New_PartReqObj	= NULLTAG;
						int nprfound	= 0;
						char
						*q_name[1] = {"Tml Part Number"},
						*q_value[1]	= {"*"};
						Temp_NewModuleNumber = (char *) MEM_alloc( 200 * sizeof(char));
						tc_strcpy(Temp_NewModuleNumber,"*");
						tc_strcat(Temp_NewModuleNumber,DesgNo);
						tc_strcat(Temp_NewModuleNumber,"*");
						printf("\n save_method_4--Save As::::Temp_NewModuleNumber =[%s] NA---",Temp_NewModuleNumber);fflush(stdout);
						q_value[0]	= Temp_NewModuleNumber;

						QRY_find2("tm_NewPartRequest_NA", &NPR_query); //Query name chenaged on 19.12.2024
						if (NPR_query)
						{
							QRY_execute(NPR_query, 1, q_name, q_value, &nprfound, &New_PartReqObjs);
						}
						printf("\n save_method_4--Save As::::n_nprfound =[%d]",nprfound);fflush(stdout);

						if(nprfound>0)
						{
							New_PartReqObj = New_PartReqObjs[0];
							if (AOM_ask_value_string(New_PartReqObj,"t5_ProjectCode",&NewPartReq_prj)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(New_PartReqObj,"t5_DesignGroup",&NewPartReq_DesignGrp)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(New_PartReqObj,"t5_ModuleAddress",&NewPartReq_ModAdd)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(New_PartReqObj,"t5_DRStatus",&NewPartReq_DrSt)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(New_PartReqObj,"t5_SubModule",&NewPartReq_SubModule)!=ITK_ok) PrintErrorStack();
							int lenght = 0;
							lenght = tc_strlen(NewPartReq_SubModule);
							PartDescription = (char *) MEM_alloc( 50 * sizeof(char) );
							PartDescription= subString(NewPartReq_SubModule,3,lenght-3);
							if (AOM_ask_value_string(New_PartReqObj,"t5_AggregateGrp",&NewPartReq_AggregateGrp)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(New_PartReqObj,"t5_Aggregates",&NewPartReq_Aggregates)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(New_PartReqObj,"t5_Module",&NewPartReq_Module)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(New_PartReqObj,"t5_Plateform",&NewPartReq_Plateform)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(New_PartReqObj,"t5_StartPartProduct",&NewPartReq_StartPartProduct)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(New_PartReqObj,"t5_PartCategory",&NewPartReq_PartCategory)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(New_PartReqObj,"t5_PartType",&NewPartReq_PartType)!=ITK_ok) PrintErrorStack();
							if(objTag!=NULLTAG)
							{
								printf("\n save_method_4--Save As::::NewPartReq_prj =[%s]",NewPartReq_prj);fflush(stdout);
								printf("\n save_method_4--Save As::::NewPartReq_DesignGrp =[%s]",NewPartReq_DesignGrp);fflush(stdout);
								printf("\n save_method_4--Save As::::NewPartReq_DrSt =[%s]",NewPartReq_DrSt);fflush(stdout);
								printf("\n save_method_4--Save As::::NewPartReq_StartPartProduct =[%s]",NewPartReq_StartPartProduct);fflush(stdout);
								printf("\n save_method_4--Save As::::NewPartReq_PartCategory =[%s]",NewPartReq_PartCategory);fflush(stdout);
								printf("\n save_method_4--Save As::::PartDescription =[%s]",PartDescription);fflush(stdout);
								printf("\n save_method_4--Save As::::NewPartReq_PartType =[%s]",NewPartReq_PartType);fflush(stdout);
								printf("\n save_method_4--Save As::::NewPartReq_AggregateGrp =[%s]",NewPartReq_AggregateGrp);fflush(stdout);
								printf("\n save_method_4--Save As::::NewPartReq_Aggregates =[%s]",NewPartReq_Aggregates);fflush(stdout);
								printf("\n save_method_4--Save As::::NewPartReq_Module =[%s]",NewPartReq_Module);fflush(stdout);
								printf("\n save_method_4--Save As::::NewPartReq_SubModule =[%s]",NewPartReq_SubModule);fflush(stdout);
								printf("\n save_method_4--Save As::::NewPartReq_Plateform =[%s]",NewPartReq_Plateform);fflush(stdout);
								printf("\n save_method_4--Save As::::NewPartReq_ModAdd =[%s]",NewPartReq_ModAdd);fflush(stdout);

								AOM_refresh(objTag,TRUE);
								AOM_set_value_string(objTag, "t5_ProjectCode",NewPartReq_prj);
								AOM_set_value_string(objTag, "t5_DesignGrp",NewPartReq_DesignGrp);
								AOM_set_value_string(objTag, "t5_PartStatus",NewPartReq_DrSt);
								AOM_set_value_string(objTag, "t5_StartPartProduct",NewPartReq_StartPartProduct);
								AOM_set_value_string(objTag, "t5_SpareCriteria",NewPartReq_PartCategory);
								AOM_set_value_string(objTag,"object_name",PartDescription);
								AOM_set_value_string(objTag, "object_desc",PartDescription);
								if(tc_strcmp(NewPartReq_PartType,"M")==0 || tc_strcmp(NewPartReq_PartType,"Module")==0)AOM_set_value_string(objTag, "t5_PartType","M");
								if(tc_strcmp(NewPartReq_PartType,"IM")==0 || tc_strcmp(NewPartReq_PartType,"IFD Module")==0)AOM_set_value_string(objTag, "t5_PartType","IM");
								if(tc_strcmp(NewPartReq_PartType,"EM")==0 || tc_strcmp(NewPartReq_PartType,"ECU Module")==0)AOM_set_value_string(objTag, "t5_PartType","EM");

								TempSubModuleAddress = (char *) MEM_alloc( 20 * sizeof(char) );
								tc_strcpy(TempSubModuleAddress,"M");
								tc_strcat(TempSubModuleAddress,NewPartReq_ModAdd);
								printf("\n save_method_4--Save As::::TempSubModuleAddress =[%s]",TempSubModuleAddress);fflush(stdout);

								AOM_set_value_string(objTag, "t5_ModuleAddress",TempSubModuleAddress);
								AOM_set_value_string(objTag, "t5_AggregateGroup",NewPartReq_AggregateGrp);
								AOM_set_value_string(objTag, "t5_Aggregate",NewPartReq_Aggregates);
								AOM_set_value_string(objTag, "t5_Module_Group",NewPartReq_Module);
								AOM_set_value_string(objTag, "t5_Module",NewPartReq_SubModule);
								AOM_set_value_string(objTag, "t5_ModuleName",PartDescription);
								AOM_set_value_string(objTag, "t5_Platform",NewPartReq_Plateform);
								AOM_set_value_string(objTag, "t5_ModuleType","PLATFORM");

								AOM_save_without_extensions(objTag);
								AOM_refresh(objTag,FALSE);
							}
						}
					}
					if(tc_strlen(DesgNo)==12 && (tc_strcmp(DesgTyp,"A")==0 || tc_strcmp(DesgTyp,"C")==0))
					{
						char *Temp_NewModuleNumber = NULL;
						char *NewPartReq_prj = NULL;
						char *NewPartReq_DesignGrp = NULL;
						char *NewPartReq_KeyWordDesc = NULL;
						char *NewPartReq_DrSt = NULL;
						char *NewPartReq_SubModule = NULL;
						char *NewPartReq_AggregateGrp = NULL;
						char *NewPartReq_Aggregates = NULL;
						char *NewPartReq_Module = NULL;
						char *NewPartReq_Plateform = NULL;
						char *NewPartReq_StartPartProduct = NULL;
						char *NewPartReq_PartCategory = NULL;
						char *NewPartReq_PartType = NULL;
						char *TempSubModuleAddress = NULL;

						char *PartDescription = NULL;
						tag_t	NPR_query	= NULLTAG;
						tag_t	*New_PartReqObjs	= NULLTAG;
						tag_t	New_PartReqObj	= NULLTAG;
						int nprfound	= 0;
						char
						*q_name[1] = {"Tml Part Number"},
						*q_value[1]	= {"*"};
						Temp_NewModuleNumber = (char *) MEM_alloc( 200 * sizeof(char));
						tc_strcpy(Temp_NewModuleNumber,"*");
						tc_strcat(Temp_NewModuleNumber,DesgNo);
						tc_strcat(Temp_NewModuleNumber,"*");
						printf("\n save_method_4--Temp_NewModuleNumber =[%s]",Temp_NewModuleNumber);fflush(stdout);
						q_value[0]	= Temp_NewModuleNumber;
						QRY_find2("tm_NewPartRequest_NA", &NPR_query); //Query name chenaged on 19.12.2024
						if (NPR_query)
						{
							QRY_execute(NPR_query, 1, q_name, q_value, &nprfound, &New_PartReqObjs);
						}
						printf("\n save_method_4--n_nprfound =[%d]",nprfound);fflush(stdout);
						if(nprfound>0)
						{
							New_PartReqObj = New_PartReqObjs[0];
							if (AOM_ask_value_string(New_PartReqObj,"t5_ProjectCode",&NewPartReq_prj)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(New_PartReqObj,"t5_DesignGroup",&NewPartReq_DesignGrp)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(New_PartReqObj,"t5_CategoryName",&NewPartReq_KeyWordDesc)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(New_PartReqObj,"t5_DRStatus",&NewPartReq_DrSt)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(New_PartReqObj,"t5_StartPartProduct",&NewPartReq_StartPartProduct)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(New_PartReqObj,"t5_PartCategory",&NewPartReq_PartCategory)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(New_PartReqObj,"t5_PartType",&NewPartReq_PartType)!=ITK_ok) PrintErrorStack();
							if(objTag!=NULLTAG)
							{
								printf("\n save_method_4--NewPartReq_prj =[%s]",NewPartReq_prj);fflush(stdout);
								printf("\n save_method_4--NewPartReq_DesignGrp =[%s]",NewPartReq_DesignGrp);fflush(stdout);
								printf("\n save_method_4--NewPartReq_DrSt =[%s]",NewPartReq_DrSt);fflush(stdout);
								printf("\n save_method_4--NewPartReq_StartPartProduct =[%s]",NewPartReq_StartPartProduct);fflush(stdout);
								printf("\n save_method_4--NewPartReq_PartCategory =[%s]",NewPartReq_PartCategory);fflush(stdout);
								printf("\n save_method_4--NewPartReq_KeyWordDesc =[%s]",NewPartReq_KeyWordDesc);fflush(stdout);
								printf("\n save_method_4--NewPartReq_PartType =[%s]",NewPartReq_PartType);fflush(stdout);

								if(AOM_refresh(objTag,TRUE)!=ITK_ok) PrintErrorStack();
								if(AOM_set_value_string(objTag, "t5_ProjectCode",NewPartReq_prj)!=ITK_ok) PrintErrorStack();
								if(AOM_set_value_string(objTag, "t5_DesignGrp",NewPartReq_DesignGrp)!=ITK_ok) PrintErrorStack();
								if(AOM_set_value_string(objTag, "t5_PartStatus",NewPartReq_DrSt)!=ITK_ok) PrintErrorStack();
								if(AOM_set_value_string(objTag, "t5_StartPartProduct",NewPartReq_StartPartProduct)!=ITK_ok) PrintErrorStack();
								if(AOM_set_value_string(objTag, "t5_SpareCriteria",NewPartReq_PartCategory)!=ITK_ok) PrintErrorStack();
								if(AOM_set_value_string(objTag,"object_name",NewPartReq_KeyWordDesc)!=ITK_ok) PrintErrorStack();
								if(AOM_set_value_string(objTag, "object_desc",NewPartReq_KeyWordDesc)!=ITK_ok) PrintErrorStack();

								if(tc_strcmp(NewPartReq_PartType,"A")==0 || tc_strcmp(NewPartReq_PartType,"Assembly")==0)
								{
									if(AOM_set_value_string(objTag, "t5_PartType","A")!=ITK_ok) PrintErrorStack();
								}

								if(tc_strcmp(NewPartReq_PartType,"C")==0 || tc_strcmp(NewPartReq_PartType,"Component")==0)
								{
									if(AOM_set_value_string(objTag, "t5_PartType","C")!=ITK_ok) PrintErrorStack();
								}

								if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
								if(AOM_refresh(objTag,FALSE)!=ITK_ok) PrintErrorStack();
							}
						}
					}

					Part_Proj=subString(DesgNo, 0, 4);
					Part_Desg=subString(DesgNo, 4, 2);
					printf("\n save_method_4--Part first 4 digit: [%s], 5 and 6th digit [%s] ", Part_Proj,Part_Desg);fflush(stdout);
					if(AOM_ask_value_string(objTag,"t5_ProjectCode",&Project_Code)!=ITK_ok) PrintErrorStack();
					printf("\n save_method_4--Save As::::Project_Code =[%s]",Project_Code);fflush(stdout);

					if(AOM_ask_value_string(objTag,"t5_DesignGrp",&DesignGroup)!=ITK_ok) PrintErrorStack();
					printf("\n save_method_4--Save As::::DesignGroup =[%s]",DesignGroup);fflush(stdout);
					if(tc_strlen(DesgNo) != 11)
					{
						//Checking project/design group Start
						printf("\n save_method_4--Item ID is not 11 digit, so check validations... ");fflush(stdout);
						if((tc_strcmp(DesgTyp,"A")==0) || (tc_strcmp(DesgTyp,"C")==0)|| (tc_strcmp(DesgTyp,"CM")==0)||(tc_strcmp(DesgTyp,"M")==0))
						{
							printf("\n save_method_4--1.Part type is:[%s]  ",DesgTyp);fflush(stdout);

							if (strcmp(Part_Proj,Project_Code)!=0)
							{
								printf("\n save_method_4--Part first 4 digit are not same as project code. ");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,"First 4 digits of part number should be same as project code.");
								return ITK_err;
							}
						}
						//Design group check.
						if((tc_strcmp(DesgTyp,"A")==0) || (tc_strcmp(DesgTyp,"C")==0)||(tc_strcmp(DesgTyp,"CM")==0))
						{
							printf("\n save_method_4--2.Part type is:[%s]  ",DesgTyp);fflush(stdout);
							//if (strcmp(Part_Desg,Part_DegGrp)!=0)
							if (strcmp(DesignGroup,"0E")!=0) //Enabling EE Part release process in TZ1.85
							{
								if (strcmp(Part_Desg,DesignGroup)!=0)
								{
									printf("\n save_method_4--A.Part 5th and 6th digit are not same as Desgin group. ");fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err,"5th and 6th digits of part number should be same as design group.");
									return ITK_err;
								}
							}
						}
						else if (tc_strcmp(DesgTyp,"M")==0)
						{
							printf("\n save_method_4--3.Part type is:[%s]  ",DesgTyp);fflush(stdout);

							MPart_Desg=subString(DesgNo, 9, 2);
							printf("\n save_method_4--MPart_Desg: [%s] ", MPart_Desg);fflush(stdout);
							//if (strcmp(MPart_Desg,Part_DegGrp)!=0)
							if (strcmp(MPart_Desg,DesignGroup)!=0)
							{
								printf("\n save_method_4--B.Part 5th and 6th digit are not same as Desgin group. ");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,"10th and 11th digits of part number should be same as design group.");
								return ITK_err;
							}
						}
						//Checking project/design group end.
					}
					else
					{
						printf("\n save_method_4--std parts.. ");fflush(stdout);
					}

					//DR Validation 1.30 start..

					//char *PLT_CodeS = NULL;
					//char *OwningGrp_value = NULL;
					if(tc_strlen(DesgNo) !=11)
					{
						if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok) PrintErrorStack();
						printf("\n save_method_4--info2 is  = [%s] ", info2);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo4",&info4)!=ITK_ok) PrintErrorStack();
						printf("\t info4 is  = [%s] ", info4);fflush(stdout);

						if (AOM_ask_value_string(objTag,"t5_ColourInd",&PrtCol)!=ITK_ok) PrintErrorStack();
						if (AOM_ask_value_string(objTag,"t5_PartType",&Prttyp)!=ITK_ok) PrintErrorStack();
						if (AOM_ask_value_string(objTag,"t5_PartStatus",&PrtDR)!=ITK_ok) PrintErrorStack();
						/*if(AOM_UIF_ask_value(objTag,"owning_group",&OwningGrp_value)!=ITK_ok) PrintErrorStack();
						printf("\n************** OwningGrp_value:[%s]**************** ",OwningGrp_value);fflush(stdout);
						PrintErrorStack();
						PLT_CodeS = (char *)MEM_alloc(1 * sizeof(char *));
						logical		retain	=	0;
						tag_t	status_rel	=	NULLTAG;

						if(tc_strcmp(OwningGrp_value,"APLPUNE")==0)
						{
						tc_strcpy(PLT_CodeS,"APLP");
						}else
						if(tc_strcmp(OwningGrp_value,"APLDWD")==0)
						{
						tc_strcpy(PLT_CodeS,"APLD");
						}else
						if(tc_strcmp(OwningGrp_value,"APLCAR")==0)
						{
						tc_strcpy(PLT_CodeS,"APLC");
						}else
						if(tc_strcmp(OwningGrp_value,"APLJSR")==0)
						{
						tc_strcpy(PLT_CodeS,"APLJ");
						}else
						if(tc_strcmp(OwningGrp_value,"APLLKO")==0)
						{
						tc_strcpy(PLT_CodeS,"APLL");
						}else
						if(tc_strcmp(OwningGrp_value,"APLAHD")==0)
						{
						tc_strcpy(PLT_CodeS,"APLA");
						}else
						if(tc_strcmp(OwningGrp_value,"APLUTK")==0)
						{
						tc_strcpy(PLT_CodeS,"APLU");
						}else
						{
						tc_strcpy(PLT_CodeS,"APLP");
						}

						printf("\n PLT_CodeS VALUE of 14 - digit part : %s ",PLT_CodeS);

						char closrule_ctrl[40];
						char ctxtPlant_ctrl[40];
						char Info1Ctr[40];
						char Info2Ctr[40];
						char Info3Ctr[40];
						char Info4Ctr[40];
						char Info5Ctr[40];
						char Info7Ctr[40];
						char Info8Ctr[40];
						char Info10Ctr[40];
						get_CtrlVal_APLPltLCS(PLT_CodeS,Info1Ctr,Info2Ctr,Info3Ctr,Info4Ctr,Info5Ctr,closrule_ctrl,Info7Ctr,Info8Ctr,ctxtPlant_ctrl,Info10Ctr);
						printf("\n Released status after creation of 14 - digit part : %s ",Info1Ctr);
						//AOM_UIF_set_value(objTag,"release_status_list",Info1Ctr);
						RELSTAT_create_release_status(Info1Ctr,&status_rel);
						RELSTAT_add_release_status(status_rel,1,&objTag,retain);
						AOM_UIF_ask_value(objTag,"release_status_list",&release_status);
						printf("\n release_status of 14 - digit part : %s ",release_status);*/
						//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

						printf("\n save_method_4--Prttyp: [%s] PrtDR: [%s] PrtCol:[%s] release_status:[%s] ",Prttyp,PrtDR,PrtCol,release_status);fflush(stdout);

						if(POM_class_of_instance(objTag,&PrtCls)!=ITK_ok) PrintErrorStack();
						if(POM_name_of_class(PrtCls,&PrtClass)!=ITK_ok) PrintErrorStack();
						printf("\n save_method_4--PrtClass :%s",PrtClass); fflush(stdout);

						if (AOM_ask_value_string(objTag,"t5_ProjectCode",&PrtProj)!=ITK_ok) PrintErrorStack();
						printf("\n save_method_4--PrtProj is  = [%s] ", PrtProj);fflush(stdout);

						DRValiFlag=0;

						if(tc_strcmp(release_status,"")!=0)
						{
							if(tc_strstr(info4,release_status) != NULL)
							{
								DRValiFlag=1;
								printf("\n save_method_4--DRValiFlag..:[%d] ", DRValiFlag);fflush(stdout);
							}
						}
						else
						{
							printf("\n save_method_4--DRValiFlag:[%d] ", DRValiFlag);fflush(stdout);
						}
						if((tc_strcmp(PrtProj,"")!=0)&&(DRValiFlag==0))
						{
							if(ITEM_find_item(PrtProj,&Project_t)!=ITK_ok) PrintErrorStack();
							if (Project_t!=NULLTAG)
							{
								if(TCTYPE_ask_object_type(Project_t,&ObjTypProj)!=ITK_ok) PrintErrorStack();
								if(TCTYPE_ask_name2(ObjTypProj,&type_Proj)!=ITK_ok) PrintErrorStack();
								printf("\n save_method_4--DML: type_Proj :: %s ", type_Proj);fflush(stdout);

								if (strcmp(type_Proj,"T5_Project")==0)
								{
									if(AOM_ask_value_string(Project_t,"t5_ProjectType",&Proj_typ)!=ITK_ok) PrintErrorStack();
									printf("\n save_method_4--Proj_typ :[%s] ",Proj_typ);   fflush(stdout);

									// START SUDHIR IS ADDED FOR VALIDATION OF DVPT....
									if(AOM_ask_value_string(Project_t,"t5_BussUnitType",&BussiNameS)!=ITK_ok) PrintErrorStack();
									printf("\n save_method_4--BussiNameS :[%s] ",BussiNameS);   fflush(stdout);

									if(tc_strcmp(BussiNameS,"CVBU")== 0 || tc_strcmp(BussiNameS,"PCBU")== 0)
									{
										printf("\n save_method_4--Prttype :[%s] PrtDRStatus :[%s]",Prttyp,PrtDR);fflush(stdout);

										if(tc_strcmp(Prttyp,"DTPL")==0)
										{
											if(tc_strcmp(PrtDR,"DVPT"))
											{
												EMH_clear_errors();
												EMH_store_error_s1(EMH_severity_error,ITK_err,"Part Type Dummy TPL can have DR as DVPT only.");
												return ITK_err;
											}
										}
										if(tc_strcmp(PrtDR,"DVPT")==0)
										{
											char	*part_DsgnOwn	=	NULL;
											if(tc_strcmp(Prttyp,"DTPL"))
											{
												EMH_clear_errors();
												EMH_store_error_s1(EMH_severity_error,ITK_err,"DR Status as DVPT can have Part Type Dummy TPL only.");
												return ITK_err;
											}

											if (AOM_ask_value_string(objTag,"t5_DsgnOwn",&part_DsgnOwn)!=ITK_ok) PrintErrorStack();
											printf("\n save_method_4--part_DsgnOwn :[%s] ",part_DsgnOwn);fflush(stdout);
											if(tc_strstr(part_DsgnOwn,"PRO") == NULL)
											{
												EMH_clear_errors();
												EMH_store_error_s1(EMH_severity_error,ITK_err,"DR Status as DVPT can have PROPUN/PROJSR/PROLKO only.");
												return ITK_err;
											}
										}
									}
									// END SUDHIR IS ADDED FOR VALIDATION OF DVPT....

									if((tc_strcmp(PrtDR,"")!=0) && (tc_strcmp(PrtDR,"NA")!=0))
									{
										if((tc_strcmp(Proj_typ,"E")==0)||(tc_strcmp(Proj_typ,"G")==0)||(tc_strcmp(Proj_typ,"H")==0)||(tc_strcmp(Proj_typ,"A")==0))
										{
											if((tc_strcmp(PrtDR,"AR0")!=0) && (tc_strcmp(PrtDR,"AR1")!=0)  && (tc_strcmp(PrtDR,"AR2")!=0) &&
											(tc_strcmp(PrtDR,"AR3")!=0) && (tc_strcmp(PrtDR,"AR4")!=0)  &&  (tc_strcmp(PrtDR,"AR5")!=0) &&  (tc_strcmp(PrtDR,"AR3P")!=0))
											{
												printf("\n save_method_4--ERROR:1. "); fflush(stdout);
												EMH_clear_errors();
												EMH_store_error_s1(EMH_severity_error,ITK_err,"Please select valid AR-status from AR0/AR1/AR2/AR3/AR3P/AR4/AR5.\n Part project type-Engine/GearBox/Clutch/Axles should have AR-value.\n To update DR-status for ERC Review parts,select latest revision and use below option.\n Option- Tools-> Product Structure Classes-> Update Non Cad Attributes.");
												return ITK_err;
											}
										}
										else
										{
											if((tc_strcmp(PrtDR,"DR0")!=0) && (tc_strcmp(PrtDR,"DR1")!=0) && (tc_strcmp(PrtDR,"DR2")!=0) &&
												(tc_strcmp(PrtDR,"DR3")!=0) && (tc_strcmp(PrtDR,"DR4")!=0) && (tc_strcmp(PrtDR,"DR5")!=0) && (tc_strcmp(PrtDR,"DR3P")!=0) &&
												(tc_strcmp(PrtDR,"AR0")!=0) && (tc_strcmp(PrtDR,"AR1")!=0) && (tc_strcmp(PrtDR,"AR2")!=0) && (tc_strcmp(PrtDR,"AR3")!=0) &&
												(tc_strcmp(PrtDR,"AR3P")!=0) && (tc_strcmp(PrtDR,"AR4")!=0) && (tc_strcmp(PrtDR,"AR5")!=0) && (tc_strcmp(PrtDR,"DVPT")!=0) &&
												(tc_strcmp(PrtDR,"Pre-KO")!=0) && (tc_strcmp(PrtDR,"KO")!=0))
											{
												printf("\n save_method_4--ERROR:2. "); fflush(stdout);
												EMH_clear_errors();
												EMH_store_error_s1(EMH_severity_error,ITK_err,"Please select valid DR-status from DR0/DR1/DR2/DR3/DR3P/DR4/DR5/AR0/AR1/AR2/AR3/AR3P/AR4/AR5/DVPT/Pre-KO/KO.\n To update DR-status for ERC Review parts,select latest revision and use below option.\n Option- Tools-> Product Structure Classes-> Update Non Cad Attributes.");
												return ITK_err;
											}
										}
									}
									else
									{
										//Check Part type
										//Added Hrishikesh and Shrivardhan TZ1.70 02.06.2023
										if(((tc_strcmp(Prttyp,"V")==0) || (tc_strcmp(Prttyp,"VCCR")==0)|| (tc_strcmp(Prttyp,"A")==0) || (tc_strcmp(Prttyp,"T")==0) || (tc_strcmp(Prttyp,"C")==0) ||
										(tc_strcmp(Prttyp,"M")==0)||(tc_strcmp(Prttyp,"G")==0)) && ((tc_strcmp(PrtCol,"Y")==0) || (tc_strcmp(PrtCol,"N")==0)) && (tc_strcmp(PrtClass,"T5_SparKitRevision")!=0) && (tc_strstr(DesgNo,"CK")==NULL))
										{
											printf("\n save_method_4--ERROR:3.. "); fflush(stdout);
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error,ITK_err,"Please select valid DR-status from drop down list.\n To update DR-status for ERC Review parts,select latest revision and use below option.\n Option- Tools-> Product Structure Classes-> Update Non Cad Attributes.");
											return ITK_err;
										}
									}
								}
							}
						}
					}
					//DR Validation 1.30 End
				}
			}
			else
			{
				// skip as control object is not present.
				printf("\n save_method_4--Validation skiped as control object is not present.  ");fflush(stdout);
			}

			//Vitthal :START: Validate Part Creation
			if( (strstr(roleName,"APL")==NULL) || (strstr(roleName,"MBOM")==NULL) )//MBOM implementation for CV TZ-1.69
			{
				if (AOM_ask_value_string(objTag,"item_revision_id",&item_rev_id)!=ITK_ok) PrintErrorStack();
				printf("\n save_method_4--item_rev_id  = [%s] ", item_rev_id);fflush(stdout);
				if(strcmp(item_rev_id,"NR")==0)
				{
					printf("\n save_method_4--item_rev_id  is NR so inside if  ");fflush(stdout);
					iTemp=Validate_On_Creation(objTag);
					if(iTemp>0)
					{
						EMH_clear_errors();
						if(iTemp==1)EMH_store_error_s1(EMH_severity_error,ITK_err,"Start Part/Product is Mandatory for Part Type Assembly,Component,TPL and GID for CATIA Design group");
						return ITK_err;
					}
				}
			}
			//Vitthal :END: Validate Part Creation

			/****************Adi TZ 1.32 Validation on Design Rev creation *************************/
			if(AOM_ask_value_string(objTag,"item_revision_id",&Rev_id)!=ITK_ok) PrintErrorStack();
			printf("\n save_method_4--Rev_id=> %s ", Rev_id);fflush(stdout);

			if(AOM_ask_value_string(objTag,"t5_DesignGrp",&DesignGrpCatia)!=ITK_ok) PrintErrorStack();
			printf(" DesignGrpCatia => %s ",DesignGrpCatia);fflush(stdout);

			if(AOM_ask_value_string(objTag,"t5_PartType",&PartTypeDR)!=ITK_ok) PrintErrorStack();
			printf(" PartTypeDR => %s ",PartTypeDR);fflush(stdout);

			printf(" DesignGrp => %s ",DesignGrp);fflush(stdout);

			if(tc_strstr(DesignGrp,DesignGrpCatia)!=NULL)
			{
				printf("\n save_method_4--catia design group so proceed => %s ",DesignGrpCatia);fflush(stdout);

				if(tc_strstr(Rev_id,"NR")!=NULL)
				{
					Rev_idlength = tc_strlen(Rev_id);

					if((Rev_idlength)>2)
					{
						Rev_Sub=subString(Rev_id,0,3);
						printf("\n save_method_4--Rev_Sub => %s ",Rev_Sub);fflush(stdout);

						if(tc_strcmp(Rev_Sub,"NR;")==0) //&& checked out ==Y OR erc REVIEW LIFECYCLE STATE ?
						{
							printf("\n save_method_4--PROCEED   2222222222  ");fflush(stdout);
						}
						else
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Please enter Revision value either as NR; followed by sequence OR simply NR");
							return ITK_err;
						}
					}
					else if((Rev_idlength)==2)
					{
						Rev_Sub1=subString(Rev_id,0,2);
						printf("\n save_method_4--Rev_Sub1 is => %s ",Rev_Sub1);fflush(stdout);

						if(tc_strcmp(Rev_Sub1,"NR")==0)
						{
							printf("\n save_method_4--PROCEED 3333333333  ");fflush(stdout);
						}
						else
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Please enter Revision value either as NR; followed by sequence OR simply NR");
							return ITK_err;
						}
					}
					printf("\n save_method_4--PROCEED   44444444  ");fflush(stdout);
				}
				else /************* Adi TZ 1.35 Begin do not allow creation of higher rev if NR does not exist*********************/
				{
					if (ITEM_ask_item_of_rev(objTag,&objMasterTag)!=ITK_ok) PrintErrorStack();

					ITEM_list_all_revs(objMasterTag,&count1,&rev_list1);
					printf("\n save_method_4--count1 IS= %d  ",count1);fflush(stdout);

					if(count1>=1)
					{
						printf("\n save_method_4--count 1 or greater so Proceed");fflush(stdout);
					}
					else
					{
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Please create initial revision as NR. Please enter Revision value either as NR; followed by sequence OR simply NR");
						return ITK_err;
					}
				}
				/*************Adi TZ 1.35 End do not allow creation of higher rev if NR does not exist*********************/
				//}																							//Adi 1.35 commented
			}
			else
			{
				printf("\n save_method_4--not a catia design group so continue=====  ");fflush(stdout);
			}
			/****************Adi TZ 1.32  Validation on Design Rev creation ENDS ***********************/
		}
		//1.25 t5_PartType

		if (AOM_ask_value_string(objTag,"item_revision_id",&Desc_obj2)!=ITK_ok) PrintErrorStack();
		printf("\n save_method_4--Desc_obj2  = [%s] ", Desc_obj2);fflush(stdout);

		if(POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id)!=ITK_ok) PrintErrorStack();
		printf("\n save_method_4--before NR check ");fflush(stdout);

		//weight rounding
		if( AOM_ask_value_double(objTag,"t5_Weight",&objWeightVal)!=ITK_ok) PrintErrorStack();
		printf("\n save_method_4--user entered weight :%f ",objWeightVal);fflush(stdout);

		if ((strstr(roleName,"APL")==NULL) || (strstr(roleName,"MBOM")==NULL)) //MBOM implementation for CV TZ-1.69
		{
			if (objWeightVal > 0)
			{
				sprintf(wgtstr,"%0.3f",objWeightVal);
				roundedWtVal = atof(wgtstr);
				printf("\n save_method_4--rounded weight :%f ",roundedWtVal);fflush(stdout);

				if(AOM_lock(objTag)!=ITK_ok) PrintErrorStack();
				printf("\n save_method_4--Before weight update ");fflush(stdout);
				if( AOM_set_value_double(objTag,"t5_Weight",roundedWtVal)!=ITK_ok) PrintErrorStack();
				printf("\n save_method_4--After weight update ");fflush(stdout);
				if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
				if(AOM_unlock(objTag)!=ITK_ok) PrintErrorStack();
				if(AOM_refresh(objTag,1)!=ITK_ok) PrintErrorStack();
			}
		}
		//weight rounding

		////RAJAN 2.1
		//if(tc_strcmp(type_name,"Design Revision")==0)
		//{
		//	if(GRM_find_relation_type("IMAN_specification",&reln_typeDvp)!=ITK_ok) PrintErrorStack();
		//	if(GRM_list_secondary_objects_only(objTag,reln_typeDvp,&n_attchs_ds,&secondary_ds)!=ITK_ok) PrintErrorStack();
		//	printf("\n\t save_method_4--RAJAN 2.1... time Configuration Context count is : %d",countConfigCtx);
		//
		//	for (jr=0;jr<n_attchs_ds;jr++ )
		//	{
		//		if(TCTYPE_ask_object_type(secondary_ds[jr],&SpecifiTypeTag)!=ITK_ok) PrintErrorStack();
		//		if(TCTYPE_ask_name2(SpecifiTypeTag,&Specifictype_name)!=ITK_ok) PrintErrorStack();
		//		if( AOM_ask_value_string(secondary_ds[jr],"current_name",&DSCurrent_Name)!=ITK_ok) PrintErrorStack();
		//		if( AOM_ask_value_string(secondary_ds[jr],"object_name",&DSobject_name)!=ITK_ok) PrintErrorStack();
		//		if( AOM_ask_value_string(secondary_ds[jr],"object_string",&DSobject_string)!=ITK_ok) PrintErrorStack();
		//		printf("\n save_method_4--RAJAN 2.1...--save_method_4 :: [%s] DSCurrent_Name:[%s] OnjName: [%s] ObjStr: [%s]", Specifictype_name,DSCurrent_Name,DSobject_name,DSobject_string);fflush(stdout);
		//	}
		//}

		if(strcmp(Desc_obj2,"NR;1")==0 )
		{
			if(AOM_lock(objTag)!=ITK_ok) PrintErrorStack();
			printf("\n save_method_4--A.Before Modification Description for NR;1 ");fflush(stdout);
			if( AOM_set_value_string(objTag,"t5_DocRemarks","NEW RELEASE")!=ITK_ok) PrintErrorStack();
			printf("\n save_method_4--A.After Modification Description for NR;1 ");fflush(stdout);
			if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
			if(AOM_unlock(objTag)!=ITK_ok) PrintErrorStack();
			if(AOM_refresh(objTag,1)!=ITK_ok) PrintErrorStack();
		}

		////RAJAN 2.5
		//if(tc_strcmp(type_name,"Design Revision")==0)
		//{
		//	if(GRM_find_relation_type("IMAN_specification",&reln_typeDvp)!=ITK_ok) PrintErrorStack();
		//	if(GRM_list_secondary_objects_only(objTag,reln_typeDvp,&n_attchs_ds,&secondary_ds)!=ITK_ok) PrintErrorStack();
		//	printf("\n save_method_4--RAJAN 2.5... time Configuration Context count is : %d",countConfigCtx);
		//
		//	for (jr=0;jr<n_attchs_ds;jr++ )
		//	{
		//		if(TCTYPE_ask_object_type(secondary_ds[jr],&SpecifiTypeTag)!=ITK_ok) PrintErrorStack();
		//		if(TCTYPE_ask_name2(SpecifiTypeTag,&Specifictype_name)!=ITK_ok) PrintErrorStack();
		//		if( AOM_ask_value_string(secondary_ds[jr],"current_name",&DSCurrent_Name)!=ITK_ok) PrintErrorStack();
		//		if( AOM_ask_value_string(secondary_ds[jr],"object_name",&DSobject_name)!=ITK_ok) PrintErrorStack();
		//		if( AOM_ask_value_string(secondary_ds[jr],"object_string",&DSobject_string)!=ITK_ok) PrintErrorStack();
		//		printf("\n save_method_4--RAJAN 2.5...--save_method_4 :: [%s] DSCurrent_Name:[%s] OnjName: [%s] ObjStr: [%s]", Specifictype_name,DSCurrent_Name,DSobject_name,DSobject_string);fflush(stdout);
		//	}
		//}

		if(strcmp(Desc_obj2,"NR")==0 )
		{
			printf("\n save_method_4--B.Before Modification Description ");fflush(stdout);
			if(AOM_lock(objTag)!=ITK_ok) PrintErrorStack();
			if( AOM_set_value_string(objTag,"t5_DocRemarks","NEW RELEASE")!=ITK_ok) PrintErrorStack();
			printf("\n save_method_4--B.After Modification Description ");fflush(stdout);
			if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
			if(AOM_unlock(objTag)!=ITK_ok) PrintErrorStack();
			if(AOM_refresh(objTag,1)!=ITK_ok) PrintErrorStack();

			//TCUA 1.47-Start
			/*
			 printf("\n B--inside NR check ");fflush(stdout);
			if(AOM_lock(objTag)!=ITK_ok) PrintErrorStack();
			if(POM_set_attr_string(1,&objTag,attr_id,"NR;1")) PrintErrorStack();
			if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
			if(AOM_unlock(objTag)!=ITK_ok) PrintErrorStack();
			printf("\n  NR;1 updated ");fflush(stdout);


			if(GRM_list_secondary_objects_only(objTag,relation_type,&cnt,&attachments)!=ITK_ok) PrintErrorStack();
			printf("\n Attached Datasets2: %d ",cnt);fflush(stdout);

			for(ij=0;ij<cnt;ij++)
			{
					dataset = attachments[ij];
					if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok) PrintErrorStack();
					printf("\n\n Dataset ObjectClassType :%s ",ObjectClassType);fflush(stdout);

					if (strcmp(ObjectClassType,"Design Revision Master")==0 || strcmp(ObjectClassType,"T5_SparKitRevisionMaster")==0)//T5_SparKitRevisionMaster
					{
						if (AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok) PrintErrorStack();
						printf("\n\n Revision Master Name :%s ",ObjectName);fflush(stdout);
							oojname=strtok(ObjectName,"/");
							strcat(oojname,"/");
							strcat(oojname,"NR;1");
							printf("\n\n Name of Revision Master:%s ",oojname);fflush(stdout);


							if(POM_attr_id_of_attr("object_name", "Form", &form_attr_id)!=ITK_ok) PrintErrorStack();

							if(AOM_lock(dataset)!=ITK_ok) PrintErrorStack();
							if(POM_set_attr_string(1, &dataset, form_attr_id,oojname)) PrintErrorStack();
							if(AOM_save_without_extensions(dataset)!=ITK_ok) PrintErrorStack();
							if(AOM_unlock(dataset)!=ITK_ok) PrintErrorStack();
							break;
					}
			}


			if (RELSTAT_create_release_status("ERC Review",&status_rel)!=ITK_ok) PrintErrorStack();
			if(RELSTAT_add_release_status(status_rel,1,&objTag,retain)!=ITK_ok) PrintErrorStack();
			*/
			//TCUA 1.47-End

			// bhaskar starts
			tag_t PartCreAccCtrlO	=	NULLTAG;
			int PartCreAccTCnt = 0;
			tag_t *PartCreAccObjTag	= NULLTAG;

			char *useridCrea = NULL; //Catia group
            char *usernameCrea = NULL; //Catia group
            char *homeSiteCrea = NULL; //Catia group
            tag_t user_tagCrea = NULLTAG; //Catia group
            char *FinalDesGrp               = NULL;  //Catia group
            char *CatiaDesGrp=",60,61,62,63,64,65,66,67,68,69,71,72,73,74,75,76,77,78,79,81,83,84,85,86,88,89,90,91,92,93,94,95,96,97,98,99";  //Catia group
            POM_get_user(&usernameCrea,&user_tagCrea);
            SA_ask_user_identifier2 (user_tagCrea,&useridCrea);
            printf ("\n save_method_4--Logged in user for creation [%s] [%s] ",useridCrea,usernameCrea);fflush(stdout);
            if(AOM_UIF_ask_value(user_tagCrea,"fnd0home_site",&homeSiteCrea)!=ITK_ok) PrintErrorStack();
            printf("\n save_method_4--Logged in fnd0home_site for creation is : [%s]",homeSiteCrea);fflush(stdout);

			if(QRY_find2("Control Objects...",&PartCreAccCtrlO)!=ITK_ok) PrintErrorStack();

			char *qry_VCCRcntrl[1] = {"SYSCD"};
			char **qry_valuesVCCR = (char **) MEM_alloc(10 * sizeof(char *));
			qry_valuesVCCR[0] = "PartCreAccCheck";

			if(QRY_execute(PartCreAccCtrlO, 1, qry_VCCRcntrl, qry_valuesVCCR, &PartCreAccTCnt, &PartCreAccObjTag)!=ITK_ok) PrintErrorStack();
			printf("\n PartCreAccCheck--SYSCD: [%d]",PartCreAccTCnt); fflush(stdout);
			
			if (SA_ask_current_groupmember(&GroupMem)!=ITK_ok) PrintErrorStack();
			if(GroupMem !=NULLTAG)
			{
				if (AOM_ask_value_string(GroupMem,"object_name",&group_name)!=ITK_ok) PrintErrorStack();
				printf("\nsave_method_4--A.group_name session=%s ",group_name);fflush(stdout);

				if (SA_ask_groupmember_role(GroupMem,&Roletag) !=ITK_ok) PrintErrorStack();
				if (SA_ask_groupmember_group(GroupMem,&grptag) !=ITK_ok) PrintErrorStack();
				if((Roletag !=NULLTAG) && (Roletag !=NULLTAG))
				{
					if (AOM_ask_value_string(Roletag,"object_name",&Role_name)!=ITK_ok) PrintErrorStack();
					if (AOM_ask_value_string(grptag,"object_name",&Grp_name)!=ITK_ok) PrintErrorStack();
					if (AOM_ask_value_string(objTag,"t5_DesignGrp",&desi_grp)!=ITK_ok) PrintErrorStack();
					printf("\nsave_method_4--A.Role_name session: [%s]  [%s]  Part Design group= [%s]",Role_name,Grp_name,desi_grp);fflush(stdout);

					DerRoleNme = (char *) MEM_alloc(50 * sizeof(char ));
					FinalDesGrp = (char *) MEM_alloc(50 * sizeof(char )); //Catia group
					tc_strcpy(DerRoleNme,"");   //New comment for identification and exact match
					tc_strcat(DerRoleNme,"/");  //New comment for identification and exact match

					 //for Catia design group
                    tc_strcpy(FinalDesGrp,"");
                    if ((tc_strstr(CatiaDesGrp,desi_grp)!=NULL) &&  (tc_strcmp(homeSiteCrea,"CV_Production")==0))
                    {
                            printf("\nCab Design group and home site CV_Production ");fflush(stdout);
                            tc_strcpy(FinalDesGrp,"CAB");
                    }
                    else
                    {
                            printf("\nEither Design group is not Cab Design group for CV or design group is of CAB but home site is Production-Pune");fflush(stdout);
                            tc_strcpy(FinalDesGrp,desi_grp);

                    }

                    //for catia design group
					//tc_strcat(DerRoleNme,desi_grp);
					tc_strcat(DerRoleNme,FinalDesGrp); //Catia group and normal 
					tc_strcat(DerRoleNme,"_Designers/");  //New comment for identification and exact match /.

					printf("\nsave_method_4--A.Role name required= [%s] ", DerRoleNme);fflush(stdout);

					if (SA_find_role2(DerRoleNme,&DesRolTag)!=ITK_ok) PrintErrorStack();
					if (SA_find_groupmember_by_user(user_tag,&Gmcnt,&GmFound)!=ITK_ok) PrintErrorStack();
					printf("\nsave_method_4--A.Total Number of roles present with user= [%d]",Gmcnt);  //New comment for identification. Check whether we can get user name

					if(SA_ask_current_role(&CurrentRoleTag)!=ITK_ok) PrintErrorStack();
					if(SA_ask_role_name2(CurrentRoleTag,&roleName)!=ITK_ok) PrintErrorStack();
					//printf("\nsave_method_4--A.roleName: [%s]  DerRoleNme: [%s]  PartDesGrp: [%s]",roleName,DerRoleNme,desi_grp); fflush(stdout);
					printf("\nsave_method_4--A.roleName: [%s]  DerRoleNme: [%s]  PartDesGrp: [%s]",roleName,DerRoleNme,FinalDesGrp); fflush(stdout);  //Catia group and normal
					
					for(jk=0;jk<Gmcnt;jk++)
					{
						ActGm = GmFound[jk];
						if (AOM_ask_value_string(ActGm,"object_name",&ActGmName)!=ITK_ok) PrintErrorStack();
						//printf("\nsave_method_4--A.ERC/APL Actual Group Member name  = [%s]", ActGmName);fflush(stdout);
						//if (strstr(ActGmName,DerRoleNme)|| strstr(roleName,"APL") ) //DEEPTI ADDED TZ1.42
						if (strstr(ActGmName,DerRoleNme) && ((tc_strstr(roleName,"APL")==NULL) || (tc_strstr(roleName,"MBOM")==NULL)) ) //DEEPTI ADDED TZ1.42//MBOM implementation for CV TZ-1.69
						{
							printf("\nsave_method_4--A.Inside ERC-->Actual Group Member name = [%s] [%s]--Valid Access Found", ActGmName,DerRoleNme);fflush(stdout);
							Rolflag++;
							DerRoleNme1=NULL;DerRoleNme1=malloc(100);
							strcpy(DerRoleNme1,ActGmName);
							break;
						}
						else if ((tc_strstr(ActGmName,roleName)!=NULL) && ((tc_strstr(roleName,"APL")!=NULL) || (tc_strstr(roleName,"MBOM")!=NULL)) )
						{
							//printf("\nsave_method_4--A.Inside APL"); fflush(stdout);
							printf("\nsave_method_4--A.Inside APL-->Actual Group Member name = [%s] [%s]--Valid Access Found", ActGmName,roleName);fflush(stdout);
							Rolflag++;
							DerRoleNme1=NULL;DerRoleNme1=malloc(100);
							strcpy(DerRoleNme1,ActGmName);
							break;
						}
					}
					printf("\n save_method_4--A.Count of Rolflag = [%d]  DerRoleNme1= [%s] PartCreAccTCnt:[%d]", Rolflag, DerRoleNme1,PartCreAccTCnt);fflush(stdout);
					//UA1.90 Backend
					if(PartCreAccTCnt==0)
					{
					if ((Rolflag==0) && ((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0)))
					{
						printf(" --Access not Found");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"1.Your login Doesn't have access for Entered Design group for project. kindly get access from TCUA Admin and set same project in session details.");
						return ITK_err;
					}
					}
				}
			}

			if (AOM_ask_value_string(objTag,"t5_ProjectCode",&ObjProject)!=ITK_ok) PrintErrorStack();
			printf("\nsave_method_4--A.Project stamped: %s ",ObjProject);fflush(stdout);

			if(strcmp(ObjProject,"")!=0)
			{
				if (PROJ_find(ObjProject,&projobj) !=ITK_ok) PrintErrorStack();

				if(projobj !=NULLTAG)
				{
					//if (TCTYPE_ask_object_type(projobj,&projobj1)!=ITK_ok) PrintErrorStack();
					//if (TCTYPE_ask_name2(projobj1,Ptype_name1)!=ITK_ok) PrintErrorStack();
					//printf("\n Proj type_name = %s ", Ptype_name1);
					printf("\nsave_method_4--modification here for the shown error of  Get access from TCUA Admin ");  //New comment for identification
					//printf("\nsave_method_4--Assigned to Projecttttttt33 ");fflush(stdout);

					SA_ask_current_project(&Currproj);

					// Ketan Added
					char*	ObjPartType = NULL;

					if (AOM_ask_value_string(objTag,"t5_PartType",&ObjPartType)!=ITK_ok) PrintErrorStack();  // KD
					printf("\nsave_method_4--ObjPartType => %s",ObjPartType);fflush(stdout);

					if (tc_strcmp(ObjPartType,"CKDVC") == 0 )
					{
						printf("\nsave_method_4--Project access skipping for CKDVC parttype");fflush(stdout);
					}
					else
					{
						if(Currproj !=NULLTAG)
						{
							if (AOM_ask_value_string(Currproj,"object_name",&parent_name)!=ITK_ok) PrintErrorStack();
							printf("\nsave_method_4--Project session: %s ",parent_name);fflush(stdout);

							if (PROJ_is_user_a_member(projobj,user_tag,&promem)!=ITK_ok) PrintErrorStack();
							if(promem==1)
							{
								printf("\nsave_method_4--B.Setting session project as t5_projectcode attribute ");fflush(stdout);

								if(SA_set_current_project(projobj)!=ITK_ok) PrintErrorStack();
								if (PROJ_ask_team(projobj,&Gmcnt1,&GmFound1,&Gmcnt2,&GmFound2,&Gmcnt3,&GmFound3)!=ITK_ok) PrintErrorStack();
								printf("\nsave_method_4--B.Total Number of users for project: [%d]  DerRoleNme1->[%s]",Gmcnt1,DerRoleNme1);fflush(stdout); //New comment for identification

								for(jkl=0;jkl<Gmcnt1;jkl++)
								{
									ActGm1 = GmFound1[jkl];
									if (AOM_ask_value_string(ActGm1,"object_name",&ActGmName1)!=ITK_ok) PrintErrorStack();
									//printf("\nsave_method_4--Actual Group Member name1= [%s]", ActGmName1);fflush(stdout);
									if(DerRoleNme1)
									{
										if (strcmp (ActGmName1,DerRoleNme1) == 0)
										{
											printf("\nsave_method_4--B.Actual Group Member name1=[%s]---Valid user to create the part ", ActGmName1);fflush(stdout);
											Rolflag1++;
											break;
										}
									}
								}
								printf("\nSave_method_4--B.After loop of all the users,Rolflag1:[%d] PartCreAccTCnt:[%d]",Rolflag1,PartCreAccTCnt);fflush(stdout);  //New comment for identification

								//UA1.90 Backend
								if(PartCreAccTCnt==0)
								{
								if ((Rolflag1==0) && ((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0)))
								{
									printf("\nsave_method_4--B.User not in the required group, so giving error for creation");fflush(stdout); //New comment for identification
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err,"2.Your login Doesn't have access for Entered Design group for project. Get access from TCUA Admin and set same project in session details");
									return ITK_err;
								}
								}
							}
							else
							{
								printf("\nsave_method_4--B.call error ITK ok2 ");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,"You are not member for this project. kindly get access from TCUA Admin and set same project in session details");
								return ITK_err;
							}
							printf("\nsave_method_4--B.Assigned to Project ");fflush(stdout);
						}
						else
						{
							if (PROJ_is_user_a_member(projobj,user_tag,&promem)!=ITK_ok) PrintErrorStack();
							if(promem==1)
							{
								printf("\nave_method_4--C.Setting session project as t5_projectcode attribute ");fflush(stdout);
								if (SA_set_current_project(projobj)!=ITK_ok) PrintErrorStack();
								if (PROJ_ask_team(projobj,&Gmcnt1,&GmFound1,&Gmcnt2,&GmFound2,&Gmcnt3,&GmFound3)!=ITK_ok) PrintErrorStack();

								for(jkl=0;jkl<Gmcnt1;jkl++)
								{
									ActGm1 = GmFound1[jkl];
									if (AOM_ask_value_string(ActGm1,"object_name",&ActGmName1)!=ITK_ok) PrintErrorStack();
									//printf("\nave_method_4--C.Actual Group Member name2= [%s] ", ActGmName1);fflush(stdout);
									if(DerRoleNme1)
									{
										if (strcmp (ActGmName1,DerRoleNme1) == 0)
										{
											printf("\nave_method_4--C.Actual Group Member name2= [%s]--Valid user to create the part ", ActGmName1);fflush(stdout);
											Rolflag1++;
										}
									}
								}
								printf("\nSave_method_4--C.After loop of all the users,Rolflag1:[%d] PartCreAccTCnt:[%d]",Rolflag1,PartCreAccTCnt);fflush(stdout);  //New comment for identification
								//UA1.90 Backend
								if(PartCreAccTCnt==0)
								{
								if ((Rolflag1 == 0) && ((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0)))
								{
									printf("\nsave_method_4--C.User not in the required group , so giving error for creation");fflush(stdout); //New comment for identification
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err,"3.Your login Doesn't have access for Entered Design group for project.kindly get access from TCUA Admin and set same project in session details");
									return ITK_err;
								}
								}
							}
							else
							{
								printf("\nsave_method_4--C.call error ITK ok2 ");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,"You are not member for this project. kindly get access from TCUA Admin and set same project in session details");
								return ITK_err;
							}
						}
					}
				}
			}
			else
			{
				printf("\nsave_method_4--D.call error ITK ok2 ");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Please enter the Project code and set the same project in session details");
				return ITK_err;
			}
			// bhaskar ends

			//if(AOM_load(objTag)!=ITK_ok) PrintErrorStack();
			//if(AOM_lock(objTag)!=ITK_ok) PrintErrorStack();
			//printf("\n Before Modification Description ");fflush(stdout);
			//if( AOM_set_value_string(objTag,"t5_DocRemarks","NEW RELEASE")!=ITK_ok) PrintErrorStack();
			//printf("\n After Modification Description ");fflush(stdout);
			//if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
			//if(AOM_unlock(objTag)!=ITK_ok) PrintErrorStack();
			//if(AOM_unload(objTag)!=ITK_ok) PrintErrorStack();
			//if(AOM_refresh(objTag,1)!=ITK_ok) PrintErrorStack();

			//if(RES_is_checked_out(objTag,&checkout)!=ITK_ok) PrintErrorStack();
			//if (checkout==0)
			//{
			//	if (RES_checkout(objTag,&reason,&change_id,&dir_name,RES_EXCLUSIVE_RESERVE)!=ITK_ok) PrintErrorStack();
			//
			//	printf("\n**********After Check Out DR in createpost*************** ");fflush(stdout);
			//	if(GRM_list_secondary_objects_only(objTag,reln_type,&c_attchs,&secondary_objects)!=ITK_ok) PrintErrorStack();
			//	printf("\nc_attchs :%d ",c_attchs);fflush(stdout);
			//	if(c_attchs>0)
			//	{
			//		for (p= 0; p < c_attchs; p++)
			//		{
			//			primary=secondary_objects[p];
			//			if(TCTYPE_ask_object_type(primary,&objTypeTagDi)!=ITK_ok) PrintErrorStack();
			//			if(TCTYPE_ask_name2(objTypeTagDi,type_name2)!=ITK_ok) PrintErrorStack();
			//			if(strcmp(type_name2,"ProPrt")==0 || strcmp(type_name2,"ProAsm")==0|| strcmp(type_name2,"ProDrw")==0)
			//			{
			//				  if(RES_is_checked_out(primary,&checkoutp)!=ITK_ok) PrintErrorStack();
			//				   if (checkoutp==0)
			//				 {
			//					if (RES_checkout(primary,&reason1,&change_id1,&dir_name1,RES_EXCLUSIVE_RESERVE)!=ITK_ok) PrintErrorStack();
			//					printf("\n**********After Check Out Dataset in createpost*************** ");fflush(stdout);
			//				 }
			//
			//			}
			//
			//
			//		}
			//	}
			//}
		}

		////RAJAN 3.0 -
		//if(tc_strcmp(type_name,"Design Revision")==0)
		//{
		//	if(GRM_find_relation_type("IMAN_specification",&reln_typeDvp)!=ITK_ok) PrintErrorStack();
		//	if(GRM_list_secondary_objects_only(objTag,reln_typeDvp,&n_attchs_ds,&secondary_ds)!=ITK_ok) PrintErrorStack();
		//	printf("\n\t RAJAN 3.0... time Configuration Context count is : %d",countConfigCtx);
		//
		//	for (jr=0;jr<n_attchs_ds;jr++ )
		//	{
		//		if(TCTYPE_ask_object_type(secondary_ds[jr],&SpecifiTypeTag)!=ITK_ok) PrintErrorStack();
		//		if(TCTYPE_ask_name2(SpecifiTypeTag,&Specifictype_name)!=ITK_ok) PrintErrorStack();
		//		if( AOM_ask_value_string(secondary_ds[jr],"current_name",&DSCurrent_Name)!=ITK_ok) PrintErrorStack();
		//		if( AOM_ask_value_string(secondary_ds[jr],"object_name",&DSobject_name)!=ITK_ok) PrintErrorStack();
		//		if( AOM_ask_value_string(secondary_ds[jr],"object_string",&DSobject_string)!=ITK_ok) PrintErrorStack();
		//		printf("\n RAJAN 3.0...--save_method_4 :: [%s] DSCurrent_Name:[%s] OnjName: [%s] ObjStr: [%s]", Specifictype_name,DSCurrent_Name,DSobject_name,DSobject_string);fflush(stdout);
		//	}
		//}

		if (objTag!=NULLTAG)
		{
			if( AOM_ask_value_string(objTag,"item_id",&desid)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(objTag,"object_desc",&Desc)!=ITK_ok) PrintErrorStack();

			if(strcmp(Desc,"")!=0)
			{
				desclength = strlen(Desc);
				for(desccnt=0;desccnt<desclength;desccnt++)
				{
					if(Desc[desccnt]=='\n')
						Desc[desccnt] =' ';

					if(Desc[desccnt]=='`')
						Desc[desccnt] =' ';

					if(Desc[desccnt]=='~')
						Desc[desccnt] =' ';

					if(Desc[desccnt]=='|')
						Desc[desccnt] =' ';

					if(Desc[desccnt]=='$')
						Desc[desccnt] =' ';

					if(Desc[desccnt]=='#')
						Desc[desccnt] =' ';

					if(Desc[desccnt]=='@')
						Desc[desccnt] =' ';

					if(Desc[desccnt]=='^')
						Desc[desccnt] =' ';

					if(Desc[desccnt]=='!')
						Desc[desccnt] =' ';
					//printf("\n [%c] ",Desc[desccnt]);fflush(stdout);
				}
				//val=(char **)MEM_alloc(sizeof(char **));
				NewDesc = (char *)MEM_alloc (desclength * sizeof(char));
				strcpy(NewDesc,Desc);

				printf("\nsave_method_4--NewDesc[%s]", NewDesc);fflush(stdout);

				if(NewDesc!=NULL)
				{
					//AOM_lock(objTag);
					if(AOM_set_value_string(objTag,"object_desc",NewDesc)!=ITK_ok) PrintErrorStack();
					if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
					//AOM_unlock(objTag);
					if( AOM_ask_value_string(objTag,"object_desc",&NewDescription)!=ITK_ok) PrintErrorStack();
					printf("\nsave_method_4--NewDescription[%s]", NewDescription);fflush(stdout);
				}
			}
		}

		////RAJAN 4.0
		//if(tc_strcmp(type_name,"Design Revision")==0)
		//{
		//	if(GRM_find_relation_type("IMAN_specification",&reln_typeDvp)!=ITK_ok) PrintErrorStack();
		//	if(GRM_list_secondary_objects_only(objTag,reln_typeDvp,&n_attchs_ds,&secondary_ds)!=ITK_ok) PrintErrorStack();
		//	printf("\n\t save_method_4--RAJAN 4.0... time Configuration Context count is : %d",countConfigCtx);
		//
		//	for (jr=0;jr<n_attchs_ds;jr++ )
		//	{
		//		if(TCTYPE_ask_object_type(secondary_ds[jr],&SpecifiTypeTag)!=ITK_ok) PrintErrorStack();
		//		if(TCTYPE_ask_name2(SpecifiTypeTag,&Specifictype_name)!=ITK_ok) PrintErrorStack();
		//		if( AOM_ask_value_string(secondary_ds[jr],"current_name",&DSCurrent_Name)!=ITK_ok) PrintErrorStack();
		//		if( AOM_ask_value_string(secondary_ds[jr],"object_name",&DSobject_name)!=ITK_ok) PrintErrorStack();
		//		if( AOM_ask_value_string(secondary_ds[jr],"object_string",&DSobject_string)!=ITK_ok) PrintErrorStack();
		//		printf("\n save_method_4--RAJAN 4.0: [%s] DSCurrent_Name:[%s] OnjName: [%s] ObjStr: [%s]", Specifictype_name,DSCurrent_Name,DSobject_name,DSobject_string);fflush(stdout);
		//	}
		//}

		//Add by Hanuman in TZ 1.54
		char *Desc_RevID=NULL;
		char *DescTD=NULL;
		printf("\n save_method_4--DesgNo is => [%s] ", DesgNo);fflush(stdout);
		if(AOM_ask_value_string(objTag,"item_revision_id",&Desc_RevID)!=ITK_ok) PrintErrorStack();
		printf("\n save_method_4--Desc_RevID  = [%s] ", Desc_RevID);fflush(stdout);
		if(strstr(Desc_RevID,"NR")!=NULL)
		{
			if(AOM_ask_value_string(objTag,"object_desc",&DescTD)!=ITK_ok) PrintErrorStack();
			printf("\n save_method_4--DescTD  = [%s] ", DescTD);fflush(stdout);
			if(DescTD!=NULL)
			{
				if(strstr(DescTD,"TABLE DRG.")!=NULL || strstr(DescTD,"TABLE DRG")!=NULL || strstr(DescTD,"TABLE DRAWING")!=NULL || strstr(DescTD,"TABLE OFFER DRAWING")!=NULL || strstr(DescTD,"TABLE DRW")!=NULL || strstr(DescTD,"TABLE OFFER DRG.")!=NULL || strstr(DescTD,"TABLE DRWG")!=NULL || strstr(DescTD,"TBL DRG.")!=NULL || strstr(DescTD,"TBL DRG")!=NULL || strstr(DescTD,"TBL.DRG.")!=NULL || strstr(DescTD,"TBL.DRG")!=NULL || strstr(DescTD,"TBLE_DRG")!=NULL || strstr(DescTD,"TBL DRAWING")!=NULL || strstr(DescTD,"TABLE-DRG.")!=NULL || strstr(DescTD,"TABLE-DRAWING")!=NULL || strstr(DescTD,"TABLE-DRG")!=NULL)
				{
					ForthBarrel = subString(DesgNo,8,2);
					printf("\n save_method_4--ForthBarrel: [%s]",ForthBarrel);fflush(stdout);
					if(tc_strcmp(ForthBarrel,"04")==0)
					{
						printf("\n save_method_4--ForthBarrel is: [%s], so you can create TD ",ForthBarrel);fflush(stdout);
					}else
					{
						printf("\n save_method_4--If Part [%s] and ForthBarrel [%s] Please select 9th and 10th digit should be 04  ",DesgNo,ForthBarrel);fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"For Description Table Drawing 3rd barrel of 12 digit number should be 04. Please choose correct Part number or change the current Dscription accordingly.");
						return ITK_err;
					}
				}else
				{
					printf("\n save_method_4--DescTD:[%s] Can't cantain TABLE DRAWING so you can create TD ",DescTD);fflush(stdout);
				}
			}
		}
		else
		{
			printf("\nsave_method_4--Checked-in Design Revision is other than NR= [%s] ",Desc_RevID);fflush(stdout);
		}

		printf("\n\nsave_method_4--TPL Revise Validation Processing...."); fflush(stdout);
		tag_t TPL_CntrlOBJ	=	NULLTAG;
		int TPL_entries = 1;
		int	TPL_found	=	0;
		tag_t *CntrlObject_TPL	=	NULLTAG;
		tag_t secondary_drw	=	NULLTAG;

		if(QRY_find2("Control Objects...",&TPL_CntrlOBJ)!=ITK_ok) PrintErrorStack();

		char *qry_TPLcntrl[1] = {"SYSCD"};
		char **qry_valuesTPL = (char **) MEM_alloc(10 * sizeof(char *));
		qry_valuesTPL[0] = "TPL_Revise_ON";

		if(QRY_execute(TPL_CntrlOBJ, TPL_entries, qry_TPLcntrl, qry_valuesTPL, &TPL_found, &CntrlObject_TPL)!=ITK_ok) PrintErrorStack();
		printf("\nsave_method_4--TPL Revise SYSCD :%d ",TPL_found); fflush(stdout);
		if(TPL_found > 0)
		{
			if(AOM_ask_value_string(objTag,"t5_PartType", &objPartType)!=ITK_ok) PrintErrorStack();
			printf("\nsave_method_4--Create Design Revision of Type :: [%s] ", objPartType);fflush(stdout);

			if(tc_strcmp(objPartType,"T")==0)
			{
				if((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0))
				{
					printf("\nsave_method_4--TPL creation should not be allowed from front end ?? \n");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,"TPL creation should not be allowed from front end.");
					return ITK_err;
				}
			}
		}

		//RAJAN 5.0
		if(tc_strcmp(type_name,"Design Revision")==0)
		{
			if(GRM_find_relation_type("IMAN_specification",&reln_typeDvp)!=ITK_ok) PrintErrorStack();
			if(GRM_list_secondary_objects_only(objTag,reln_typeDvp,&n_attchs_ds,&secondary_ds)!=ITK_ok) PrintErrorStack();
			printf("\n save_method_4--RAJAN 5.0... time Configuration Context count is : %d",countConfigCtx);

			for (jr=0;jr<n_attchs_ds;jr++ )
			{
				printf("\n save_method_4--RAJAN 5.0... Inside For loop");fflush(stdout);

				secondary_drw=secondary_ds[jr];
				if(TCTYPE_ask_object_type(secondary_drw,&SpecifiTypeTag)!=ITK_ok) PrintErrorStack();
				if(TCTYPE_ask_name2(SpecifiTypeTag,&Specifictype_name)!=ITK_ok) PrintErrorStack();
				if( AOM_ask_value_string(secondary_drw,"current_name",&DSCurrent_Name)!=ITK_ok) PrintErrorStack();
				if( AOM_ask_value_string(secondary_drw,"object_name",&DSobject_name)!=ITK_ok) PrintErrorStack();
				if( AOM_ask_value_string(secondary_drw,"object_string",&DSobject_string)!=ITK_ok) PrintErrorStack();
				printf("\n \n save_method_4--RAJAN 5.0: [%s] DSCurrent_Name:[%s] OnjName: [%s] ObjStr: [%s]", Specifictype_name,DSCurrent_Name,DSobject_name,DSobject_string);fflush(stdout);
				if(tc_strcmp(Specifictype_name,"CMI2Drawing")==0)
				{
					printf("\n\t \n save_method_4--RAJAN 5.0... Before Update Drawing Attributes");fflush(stdout);
					if( AOM_ask_value_string(objTag,"t5_Material",&objname)!=ITK_ok) PrintErrorStack();
					if( AOM_ask_value_string(objTag,"t5_MThickness",&objMatThickness)!=ITK_ok) PrintErrorStack();
					if( AOM_ask_value_string(objTag,"t5_OppHandDrg",&objOppHandDrg)!=ITK_ok) PrintErrorStack();
					if( AOM_ask_value_string(objTag,"t5_RefDrawing",&objRefDrw)!=ITK_ok) PrintErrorStack();
					if( AOM_ask_value_string(objTag,"t5_SurfPrtStd",&objSurfStd)!=ITK_ok) PrintErrorStack();
					if( AOM_ask_value_double(objTag,"t5_Weight",&objWeight)!=ITK_ok) PrintErrorStack();

					printf ( "\n save_method_4--t5_PartMaterial for rev is  %s , t5_OppHandDrg :%s and objRefDrw :%s and objMatThickness :%s  ", objname,objOppHandDrg,objRefDrw,objMatThickness);fflush(stdout);
					AOM_lock(secondary_drw);
					if( AOM_set_value_string(secondary_drw,"t5_PartMaterial",objname)!=ITK_ok) PrintErrorStack();
					if( AOM_set_value_string(secondary_drw,"t5_MThickness",objMatThickness)!=ITK_ok) PrintErrorStack();
					// if(strcmp(objOppHandDrg,"")==0)
					//{
						if( AOM_set_value_string(secondary_drw,"t5_OppHandDrg",objOppHandDrg)!=ITK_ok) PrintErrorStack();
					//}
					// if(strcmp(objRefDrw,"")==0)
					//{
						if( AOM_set_value_string(secondary_drw,"t5_RefDrawing",objRefDrw)!=ITK_ok) PrintErrorStack();
					//}
					if( AOM_set_value_string(secondary_drw,"t5_SurfPrtStd",objSurfStd)!=ITK_ok) PrintErrorStack();
					if( AOM_set_value_double(secondary_drw,"t5_Weight",objWeight)!=ITK_ok) PrintErrorStack();
					if(AOM_save_without_extensions(secondary_drw)!=ITK_ok) PrintErrorStack();
					if(AOM_unlock(secondary_drw)!=ITK_ok) PrintErrorStack();
					dsflag++;
					break;
				}
			}
		}

		//printf("\n save_method_4--After mem1 alloc ");
		//dst_name = NULL;
		//dst_name=(char *) MEM_alloc(200);
		//printf("\n save_method_4--After mem alloc ");

		/*tc_strcpy (dst_name, desid);
			strcat(dst_name,"/");
			strcat(dst_name,"NR;1");

		// if ( AE_find_datasettype (dst_name, &a_datasettype)!=ITK_ok) PrintErrorStack();
		printf("After find  dataset ");

		//printf("drawign name %s,%s",DrwName1,DrwName);
		//if( AE_find_all_datasets_by_id(a_datasettype, "000138", &resultCount, &resultTags)!=ITK_ok) PrintErrorStack();
		if( AE_find_all_datasets(dst_name, &resultCount, &resultTags)!=ITK_ok) PrintErrorStack();
		 printf("resultCount **** %d ", resultCount);

		if (resultCount == 0 )
		{
			tc_strcpy (dst_name, "");
			tc_strcpy (dst_name, desid);
			strcat(dst_name,"/");
			strcat(dst_name,"NR");
			printf("After find  dataset..2 ");
			if( AE_find_all_datasets(dst_name, &resultCount, &resultTags)!=ITK_ok) PrintErrorStack();
			printf("resultCount:::::: %d", resultCount);
		} */

		printf("\n save_method_4--resultCount:: FOR TEST [%d]", resultCount);
		if (resultCount  > 0 )
		{
			for (j=0;j<resultCount;j++ )
			{
				item_tag = resultTags[j];

				if( AE_ask_dataset_latest_rev(item_tag, &latest_datas)!=ITK_ok) PrintErrorStack();
				if( AOM_ask_value_string(latest_datas,"object_name",&DrwName)!=ITK_ok) PrintErrorStack();

				DrwName1=strtok(DrwName,"/");
				printf ( "\n save_method_4--DrwName%s and desid :%s ", DrwName1,desid);fflush(stdout);
				if( AOM_ask_value_string(latest_datas,"object_type",&object_typeDS)!=ITK_ok) PrintErrorStack();

				//if( AE_ask_dataset_id_rev(latest_datas, &dataset_id, &dataset_rev )!=ITK_ok) PrintErrorStack();
				printf ( "\n save_method_4--dataset object_typeDS :%s ", object_typeDS);fflush(stdout);

				if(tc_strcmp(object_typeDS,"CMI2Drawing")==0)
				{
					if ((dsflag == 0) && (strcmp(DrwName1,desid) ==0))
					{
						if( AOM_ask_value_string(objTag,"t5_Material",&objname)!=ITK_ok) PrintErrorStack();
						if( AOM_ask_value_string(objTag,"t5_MThickness",&objMatThickness)!=ITK_ok) PrintErrorStack();
						if( AOM_ask_value_string(objTag,"t5_OppHandDrg",&objOppHandDrg)!=ITK_ok) PrintErrorStack();
						if( AOM_ask_value_string(objTag,"t5_RefDrawing",&objRefDrw)!=ITK_ok) PrintErrorStack();
						if( AOM_ask_value_string(objTag,"t5_SurfPrtStd",&objSurfStd)!=ITK_ok) PrintErrorStack();
						if( AOM_ask_value_double(objTag,"t5_Weight",&objWeight)!=ITK_ok) PrintErrorStack();

						printf ( "\n save_method_4--t5_PartMaterial for rev is  %s , t5_OppHandDrg :%s and objRefDrw :%s and objMatThickness :%s  ", objname,objOppHandDrg,objRefDrw,objMatThickness);fflush(stdout);
						AOM_lock(item_tag);
						if( AOM_set_value_string(item_tag,"t5_PartMaterial",objname)!=ITK_ok) PrintErrorStack();
						if( AOM_set_value_string(item_tag,"t5_MThickness",objMatThickness)!=ITK_ok) PrintErrorStack();
						// if(strcmp(objOppHandDrg,"")==0)
						//{
							if( AOM_set_value_string(item_tag,"t5_OppHandDrg",objOppHandDrg)!=ITK_ok) PrintErrorStack();
						//}
						// if(strcmp(objRefDrw,"")==0)
						//{
							if( AOM_set_value_string(item_tag,"t5_RefDrawing",objRefDrw)!=ITK_ok) PrintErrorStack();
						//}
						if( AOM_set_value_string(item_tag,"t5_SurfPrtStd",objSurfStd)!=ITK_ok) PrintErrorStack();
						if( AOM_set_value_double(item_tag,"t5_Weight",objWeight)!=ITK_ok) PrintErrorStack();
						if(AOM_save_without_extensions(item_tag)!=ITK_ok) PrintErrorStack();
						if(AOM_unlock(item_tag)!=ITK_ok) PrintErrorStack();
						dsflag++;
						break;
					}
				}
			}
		}
		//}
	}
	printf("\n save_method_4--completed processing ");fflush(stdout);
	return ITK_ok;
}

//Ashish -
int BLFormula_Validate(tag_t ConfigCtx,char* child_bl_formula,char* othermodule_bl_formula)
{

	printf( "\n\t**********In BLFormula_Validate funtion now ***************");
	//Need to add custom strstr function

	tag_t  ConfigCtxObjTypeTag=NULLTAG;
	//char   Config_CtxType[TCTYPE_name_size_c+1];
	char*	 SmVCContext			= NULL;
	char*	 SmCrIDContext			= NULL;
	char*	 Config_CtxType			= NULL;

	if(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag)!=ITK_ok) PrintErrorStack();
	if(TCTYPE_ask_name2(ConfigCtxObjTypeTag,&Config_CtxType)!=ITK_ok) PrintErrorStack();
	printf( "\n\t Config relation Config_CtxType :%s ..",Config_CtxType);

	if(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext)!=ITK_ok) PrintErrorStack();
	printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);fflush(stdout);

	if(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext)!=ITK_ok) PrintErrorStack();
	printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);fflush(stdout);


	char *qry_entriesOptFam[] = {"ID"};
	char **qry_valuesOptFam = (char **) MEM_alloc(50 * sizeof(char *));
	tag_t Optfmly_tag = NULLTAG;
	tag_t queryTagOptFam = NULLTAG;
	tag_t *revOptFam=NULL;
	int resultCountOptFam=0,n_entriesOptFam=1,j=0;

	char *qry_entriesOptFamVal[] = {"Thread ID","ID"};
	char **qry_valuesOptFamVal = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t OptfmlyVal_tag = NULLTAG;
	tag_t queryTagOptFamVal = NULLTAG;
	tag_t *revOptFamVal=NULL;
	int resultCountOptFamVal=0,n_entriesOptFamVal=2,i=0;
	char* OptValName=NULL;
	char* OptfmlyName=NULL;
	char* VariantFormulaStr=NULL;
	char* VariantFormulaStrOptionVal=NULL;
	VariantFormulaStr=(char *)MEM_alloc(300);
	VariantFormulaStrOptionVal=(char *)MEM_alloc(300);

	if(QRY_find2("Cfg0OptionFamiliesFromIDs", &queryTagOptFam));
	printf("\n After IFERR_REPORT : QRY_find2 \n");fflush(stdout);
	if (queryTagOptFam)
	{
		printf("2.Found Query \n");fflush(stdout);
	}
	else
	{
		printf("Not Found Query");fflush(stdout);
	}
	 qry_valuesOptFam[0] = SmCrIDContext;
	if(QRY_execute(queryTagOptFam, n_entriesOptFam, qry_entriesOptFam, qry_valuesOptFam, &resultCountOptFam, &revOptFam));
	printf(" \n resultCountOptFam : %d\n", resultCountOptFam); fflush(stdout);

	for (j=0;j<resultCountOptFam;j++ )
	{
		printf( "\n\t****************In option family loop now *************");

		int Flag_child_bl_Found=0;
		int Flag_other_bl_Found=0;
		Optfmly_tag = revOptFam[j];
		ITK_CALL(AOM_ask_value_string(Optfmly_tag,"object_name",&OptfmlyName));
		printf("\n\t OptfmlyName Object String Type is :%s",OptfmlyName);	fflush(stdout);
		tc_strcpy(VariantFormulaStr,"");
		if (tc_strstr(OptfmlyName," ")!=NULL)
		{
			tc_strcat(VariantFormulaStr,"'");
			tc_strcat(VariantFormulaStr,OptfmlyName);
			tc_strcat(VariantFormulaStr,"'");
		}
		else
		{
			tc_strcat(VariantFormulaStr,OptfmlyName);
		}
		tc_strcat(VariantFormulaStr," = ");
		printf("\n\t VariantFormulaStr is :<%s>",VariantFormulaStr);	fflush(stdout);



		if(QRY_find2("__Cfg0OptionValuesFromOptionFamilyIDs", &queryTagOptFamVal));
		printf("\n After IFERR_REPORT : QRY_find2 \n");fflush(stdout);
		if (queryTagOptFamVal)
		{
			printf("Found Query __Cfg0OptionValuesFromOptionFamilyIDs \n");fflush(stdout);
		}
		else
		{
			printf("Not Found Query __Cfg0OptionValuesFromOptionFamilyIDs ");fflush(stdout);
		}
		qry_valuesOptFamVal[0]= OptfmlyName;
		qry_valuesOptFamVal[1]= SmCrIDContext;
		if(QRY_execute(queryTagOptFamVal, n_entriesOptFamVal, qry_entriesOptFamVal, qry_valuesOptFamVal, &resultCountOptFamVal, &revOptFamVal));
		for (i=0;i<resultCountOptFamVal;i++ )
		{
			printf("\n\t***************** In option value loop now *******************");

			OptfmlyVal_tag = revOptFamVal[i];
			ITK_CALL(AOM_ask_value_string(OptfmlyVal_tag,"object_name",&OptValName));
			printf("\n\t Value Object String  is :%s",OptValName);	fflush(stdout);

			tc_strcpy(VariantFormulaStrOptionVal,"");
			tc_strcat(VariantFormulaStrOptionVal,VariantFormulaStr);

			if (tc_strstr(OptValName," ")!=NULL)
			{
				tc_strcat(VariantFormulaStrOptionVal,"'");
				tc_strcat(VariantFormulaStrOptionVal,OptValName);
				tc_strcat(VariantFormulaStrOptionVal,"'");
			}
			else
			{
				tc_strcat(VariantFormulaStrOptionVal,OptValName);
			}

			printf("\n\t Final VariantFormulaStr is :<%s> \n",VariantFormulaStrOptionVal);	fflush(stdout);

			//Custom strstr added to fix duplicate VF save issue
			//if (tc_strstr(child_bl_formula,VariantFormulaStrOptionVal)!=NULL)
			if (customStrStr(child_bl_formula, VariantFormulaStrOptionVal) > 0)
			{
				printf("\n\t child_bl_formula =[%s] &&  VariantFormulaStrOptionVal = [%s] \n",child_bl_formula,VariantFormulaStrOptionVal);

				printf("\n\t Matched for VariantFormulaStr is :<%s> \n",VariantFormulaStrOptionVal);	fflush(stdout);
				Flag_child_bl_Found++;


				//if (tc_strstr(othermodule_bl_formula,VariantFormulaStrOptionVal)!=NULL)
				if (customStrStr(othermodule_bl_formula, VariantFormulaStrOptionVal) > 0)
				{
						printf("\n\t othermodule_bl_formula =[%s] &&  VariantFormulaStrOptionVal = [%s] \n",othermodule_bl_formula,VariantFormulaStrOptionVal);
						Flag_other_bl_Found++;
				}

			}
			else
			{

			}

		}/// end of option value loop
		printf("\n\t Value for <%s> Match %d other match %d \n",OptfmlyName,Flag_child_bl_Found,Flag_other_bl_Found);	fflush(stdout);

		if (Flag_child_bl_Found > 0 && Flag_other_bl_Found==0)
		{
			return 1;
		}

	}/// end of option family loop

	return 0;
}
//Custom strstr Added by Kirtikumar
int customStrStr(char* strEdited, char* strDefault) {

	printf("\n **************Inside customStrStr function********************");
	printf("\n bl_formula -: %s", strEdited);
	printf("\n VariantFormulaStrOptionVal -: %s", strDefault);
	printf("\n\n\n");
	char* tmpEdited = strEdited;
	char* tmpDefault = strDefault;
	int isFullTraversed = 0;
	int matchCnt = 0;
	int partialMatchCnt = 0;
	int exactMatchCnt = 0;
	while(*tmpEdited != '\0') {
		if(*tmpEdited == *tmpDefault) {
			isFullTraversed = 1;
			while(*tmpDefault != '\0') {
				if(*tmpEdited == *tmpDefault) {
					//printf("\n %c", *tmpEdited);
				} else {
					//printf("\n Not matched successive chars");
					isFullTraversed = 0;
					tmpDefault = strDefault;
					break;
				}
				tmpEdited ++;
				tmpDefault ++;
			}
			if(isFullTraversed) {
				if(((*tmpEdited == ' ') && (*(tmpEdited+1) == '|' || *(tmpEdited+1) == '&')) || (*tmpEdited == ')')){
					exactMatchCnt ++;
				} else {
					partialMatchCnt ++;
				}
				tmpDefault = strDefault;
				matchCnt ++;
			}
		}
		tmpEdited ++;
	}
	printf("\n matchCnt -: %d", matchCnt);
	printf("\n partialMatchCnt -: %d", partialMatchCnt);
	printf("\n exactMatchCnt -: %d\n", exactMatchCnt);

	return exactMatchCnt;
}

/* CR-FY24-0107 -Start */

int isBlankVF(tag_t bomlineTag, logical *res)
{
	int ifail = ITK_ok;
	char* vf_formulaStr = NULL;
	*res = true;

	ifail = AOM_ask_value_string(bomlineTag, "bl_formula", &vf_formulaStr );
	printf("\n\t vf_formulaStr--------------> %s\n",vf_formulaStr); fflush(stdout);

	if(vf_formulaStr == NULL )
	{
		*res = false;
	}
	else if(tc_strlen(vf_formulaStr) > 0)
	{
		*res = true;
	}
	else
	{
		*res = false;
	}


	return ITK_ok;
}

/* CR-FY24-0107 -End */

/**************Sanjoy fix the issue Duplicate Variant Formula *************************/

// --- Tokenizer and parser from previous code ---

typedef enum {
    TOKEN_LPAREN, TOKEN_RPAREN, TOKEN_AND, TOKEN_OR,
    TOKEN_FIELD, TOKEN_EQ, TOKEN_END
} TokenType;

typedef struct {
    TokenType type;
    char* text;
} Token;

typedef struct {
    const char* input;
    size_t pos;
    Token current;
} Tokenizer;

Tokenizer tz;

void free_token(Token* t) {
    if (t->text) free(t->text);
    t->text = NULL;
}

void tokenizer_skip_spaces(Tokenizer* tz) {
    while (isspace(tz->input[tz->pos])) tz->pos++;
}

int starts_with(const char* str, const char* prefix) {
    return strncmp(str, prefix, strlen(prefix)) == 0;
}

void tokenizer_next(Tokenizer* tz) {
    free_token(&tz->current);
    tokenizer_skip_spaces(tz);

    char c = tz->input[tz->pos];
    if (c == 0) {
        tz->current.type = TOKEN_END;
        tz->current.text = NULL;
        return;
    }
    if (c == '(') {
        tz->current.type = TOKEN_LPAREN;
        tz->pos++;
        tz->current.text = NULL;
        return;
    }
    if (c == ')') {
        tz->current.type = TOKEN_RPAREN;
        tz->pos++;
        tz->current.text = NULL;
        return;
    }
    if (c == '&') {
        tz->current.type = TOKEN_AND;
        tz->pos++;
        tz->current.text = NULL;
        return;
    }
    if (c == '|') {
        tz->current.type = TOKEN_OR;
        tz->pos++;
        tz->current.text = NULL;
        return;
    }
    if (c == '=') {
        tz->current.type = TOKEN_EQ;
        tz->pos++;
        tz->current.text = NULL;
        return;
    }

    // Skip "[Teamcenter]" prefix if present
    if (starts_with(&tz->input[tz->pos], "[Teamcenter]")) {
        tz->pos += strlen("[Teamcenter]");
        tokenizer_skip_spaces(tz);
        c = tz->input[tz->pos];
    }

    if (c == '\'') {
        char quote = c;
        tz->pos++;
        size_t capacity = 64;
        char* buffer = malloc(capacity);
        if (!buffer) {
            tz->current.type = TOKEN_END;
            tz->current.text = NULL;
            return;
        }
        size_t len = 0;
        while (1) {
            char curr = tz->input[tz->pos];
            if (curr == 0) break;
            if (curr == quote) {
                if (tz->input[tz->pos + 1] == quote) {
                    if (len + 1 >= capacity) {
                        capacity *= 2;
                        buffer = realloc(buffer, capacity);
                        if (!buffer) {
                            tz->current.type = TOKEN_END;
                            tz->current.text = NULL;
                            return;
                        }
                    }
                    buffer[len++] = quote;
                    tz->pos += 2;
                    continue;
                } else {
                    tz->pos++;
                    break;
                }
            }
            if (len + 1 >= capacity) {
                capacity *= 2;
                buffer = realloc(buffer, capacity);
                if (!buffer) {
                    tz->current.type = TOKEN_END;
                    tz->current.text = NULL;
                    return;
                }
            }
            buffer[len++] = curr;
            tz->pos++;
        }
        buffer[len] = 0;
        tz->current.type = TOKEN_FIELD;
        tz->current.text = buffer;
        return;
    }

    // Unquoted token: read until space, operator or paren
    size_t start = tz->pos;
    while (tz->input[tz->pos] && !isspace(tz->input[tz->pos]) &&
           tz->input[tz->pos] != '(' && tz->input[tz->pos] != ')' &&
           tz->input[tz->pos] != '&' && tz->input[tz->pos] != '|' &&
           tz->input[tz->pos] != '=') {
        tz->pos++;
    }
    size_t len = tz->pos - start;
    char* txt = malloc(len + 1);
    if (!txt) {
        tz->current.type = TOKEN_END;
        tz->current.text = NULL;
        return;
    }
    strncpy(txt, &tz->input[start], len);
    txt[len] = 0;
    tz->current.type = TOKEN_FIELD;
    tz->current.text = txt;
}

// AST Nodes

typedef enum { NODE_CONDITION, NODE_AND, NODE_OR } NodeType;

typedef struct ExprNode {
    NodeType type;
    union {
        struct {
            char* field;
            char* value;
        } condition;
        struct {
            struct ExprNode* left;
            struct ExprNode* right;
        } op;
    };
} ExprNode;

void free_expr(ExprNode* node) {
    if (!node) return;
    if (node->type == NODE_CONDITION) {
        free(node->condition.field);
        free(node->condition.value);
    } else {
        free_expr(node->op.left);
        free_expr(node->op.right);
    }
    free(node);
}

// Parser functions

typedef enum {
    PARSE_OK = 0,
    PARSE_ERR,
} ParseResult;

ParseResult parse_expr(ExprNode** out_node);

ParseResult expect(TokenType type) {
    if (tz.current.type != type) {
        return PARSE_ERR;
    }
    tokenizer_next(&tz);
    return PARSE_OK;
}

ParseResult parse_condition(ExprNode** out_node) {
    if (tz.current.type != TOKEN_FIELD) return PARSE_ERR;

    char* field = strdup(tz.current.text);
    if (!field) return PARSE_ERR;
    tokenizer_next(&tz);

    if (tz.current.type != TOKEN_EQ) {
        free(field);
        return PARSE_ERR;
    }
    tokenizer_next(&tz);

    if (tz.current.type != TOKEN_FIELD) {
        free(field);
        return PARSE_ERR;
    }
    char* value = strdup(tz.current.text);
    if (!value) {
        free(field);
        return PARSE_ERR;
    }
    tokenizer_next(&tz);

    ExprNode* node = malloc(sizeof(ExprNode));
    if (!node) {
        free(field);
        free(value);
        return PARSE_ERR;
    }
    node->type = NODE_CONDITION;
    node->condition.field = field;
    node->condition.value = value;

    *out_node = node;
    return PARSE_OK;
}

ParseResult parse_factor(ExprNode** out_node) {
    if (tz.current.type == TOKEN_LPAREN) {
        tokenizer_next(&tz);
        ParseResult res = parse_expr(out_node);
        if (res != PARSE_OK) return res;
        if (tz.current.type != TOKEN_RPAREN) {
            free_expr(*out_node);
            *out_node = NULL;
            return PARSE_ERR;
        }
        tokenizer_next(&tz);
        return PARSE_OK;
    }
    return parse_condition(out_node);
}

ParseResult parse_term(ExprNode** out_node) {
    ExprNode* node = NULL;
    ParseResult res = parse_factor(&node);
    if (res != PARSE_OK) return res;

    while (tz.current.type == TOKEN_AND) {
        tokenizer_next(&tz);
        ExprNode* right = NULL;
        res = parse_factor(&right);
        if (res != PARSE_OK) {
            free_expr(node);
            return res;
        }
        ExprNode* parent = malloc(sizeof(ExprNode));
        if (!parent) {
            free_expr(node);
            free_expr(right);
            return PARSE_ERR;
        }
        parent->type = NODE_AND;
        parent->op.left = node;
        parent->op.right = right;
        node = parent;
    }
    *out_node = node;
    return PARSE_OK;
}

ParseResult parse_expr(ExprNode** out_node) {
    ExprNode* node = NULL;
    ParseResult res = parse_term(&node);
    if (res != PARSE_OK) return res;

    while (tz.current.type == TOKEN_OR) {
        tokenizer_next(&tz);
        ExprNode* right = NULL;
        res = parse_term(&right);
        if (res != PARSE_OK) {
            free_expr(node);
            return res;
        }
        ExprNode* parent = malloc(sizeof(ExprNode));
        if (!parent) {
            free_expr(node);
            free_expr(right);
            return PARSE_ERR;
        }
        parent->type = NODE_OR;
        parent->op.left = node;
        parent->op.right = right;
        node = parent;
    }
    *out_node = node;
    return PARSE_OK;
}

// Data structures for conditions and conjunctions

typedef struct {
    char* field;
    char* value;
} Cond;

typedef struct {
    Cond* conds;
    int count;
    int capacity;
} Conjunction;

void conj_init(Conjunction* conj) {
    conj->capacity = 8;
    conj->count = 0;
    conj->conds = malloc(conj->capacity * sizeof(Cond));
}

void conj_free(Conjunction* conj) {
    for (int i = 0; i < conj->count; i++) {
        free(conj->conds[i].field);
        free(conj->conds[i].value);
    }
    free(conj->conds);
}

void conj_add(Conjunction* conj, const char* field, const char* value) {
    if (conj->count >= conj->capacity) {
        conj->capacity *= 2;
        conj->conds = realloc(conj->conds, conj->capacity * sizeof(Cond));
    }
    conj->conds[conj->count].field = strdup(field);
    conj->conds[conj->count].value = strdup(value);
    conj->count++;
}

// Flatten expression into conjunctions in DNF (OR of ANDs)

typedef struct {
    Conjunction* conj_array;
    int count;
    int capacity;
} ConjList;

void conjlist_init(ConjList* cl) {
    cl->capacity = 8;
    cl->count = 0;
    cl->conj_array = malloc(cl->capacity * sizeof(Conjunction));
}

void conjlist_free(ConjList* cl) {
    for (int i = 0; i < cl->count; i++) {
        conj_free(&cl->conj_array[i]);
    }
    free(cl->conj_array);
}

void conjlist_add(ConjList* cl, Conjunction* conj) {
    if (cl->count >= cl->capacity) {
        cl->capacity *= 2;
        cl->conj_array = realloc(cl->conj_array, cl->capacity * sizeof(Conjunction));
    }
    cl->conj_array[cl->count++] = *conj;
}

// Recursive helper to copy conjunction
Conjunction conj_copy(const Conjunction* c) {
    Conjunction copy;
    conj_init(&copy);
    for (int i = 0; i < c->count; i++) {
        conj_add(&copy, c->conds[i].field, c->conds[i].value);
    }
    return copy;
}

// Multiply two lists of conjunctions (for AND operator)
void conjlist_multiply(ConjList* dest, const ConjList* a, const ConjList* b) {
    for (int i = 0; i < a->count; i++) {
        for (int j = 0; j < b->count; j++) {
            Conjunction c = conj_copy(&a->conj_array[i]);
            for (int k = 0; k < b->conj_array[j].count; k++) {
                conj_add(&c, b->conj_array[j].conds[k].field, b->conj_array[j].conds[k].value);
            }
            conjlist_add(dest, &c);
        }
    }
}

// Convert ExprNode to DNF conjunction list
void expr_to_dnf(ExprNode* node, ConjList* out) {
    if (!node) return;
    if (node->type == NODE_CONDITION) {
        Conjunction c;
        conj_init(&c);
        conj_add(&c, node->condition.field, node->condition.value);
        conjlist_add(out, &c);
    } else if (node->type == NODE_AND) {
        ConjList left_list, right_list;
        conjlist_init(&left_list);
        conjlist_init(&right_list);
        expr_to_dnf(node->op.left, &left_list);
        expr_to_dnf(node->op.right, &right_list);

        ConjList combined;
        conjlist_init(&combined);
        conjlist_multiply(&combined, &left_list, &right_list);

        for (int i = 0; i < combined.count; i++) {
            conjlist_add(out, &combined.conj_array[i]);
        }

        // Free temporary lists but not the conjunctions (moved to out)
        free(left_list.conj_array);
        free(right_list.conj_array);
        free(combined.conj_array);
    } else if (node->type == NODE_OR) {
        expr_to_dnf(node->op.left, out);
        expr_to_dnf(node->op.right, out);
    }
}

// Check if two conditions conflict (field equals but different value)
int cond_conflict(const Cond* a, const Cond* b) {
    if (strcasecmp(a->field, b->field) == 0 && strcasecmp(a->value, b->value) != 0) {
        return 1;
    }
    return 0;
}

// Check if conjunction c1 is subset of conjunction c2 (c1 has all conditions in c2, or compatible)
int conj_is_subset(const Conjunction* c1, const Conjunction* c2) {
    // For every condition in c2, c1 must have same condition with same field/value
    for (int i = 0; i < c2->count; i++) {
        int found = 0;
        for (int j = 0; j < c1->count; j++) {
            if (strcasecmp(c2->conds[i].field, c1->conds[j].field) == 0) {
                // Check equality of values
                if (strcasecmp(c2->conds[i].value, c1->conds[j].value) == 0) {
                    found = 1;
                    break;
                } else {
                    // Different values for same field - no subset
                    return 0;
                }
            }
        }
        if (!found) return 0;
    }
    return 1;
}

// Check if two conjunctions overlap (no conflicting conditions)
int conj_overlap(const Conjunction* c1, const Conjunction* c2) {
    for (int i = 0; i < c1->count; i++) {
        for (int j = 0; j < c2->count; j++) {
            if (strcasecmp(c1->conds[i].field, c2->conds[j].field) == 0) {
                if (strcasecmp(c1->conds[i].value, c2->conds[j].value) != 0) {
                    return 0; // conflict
                }
            }
        }
    }
    return 1;
}

// Check if expr1 conjunction list is subset of expr2 conjunction list
int expr_is_subset(ConjList* expr1, ConjList* expr2) {
    // For every conjunction in expr1, exists a conjunction in expr2 that is a superset
    for (int i = 0; i < expr1->count; i++) {
        int found = 0;
        for (int j = 0; j < expr2->count; j++) {
            if (conj_is_subset(&expr1->conj_array[i], &expr2->conj_array[j])) {
                found = 1;
                break;
            }
        }
        if (!found) return 0;
    }
    return 1;
}

// Check if expr1 overlaps expr2
int expr_overlap(ConjList* expr1, ConjList* expr2) {
    for (int i = 0; i < expr1->count; i++) {
        for (int j = 0; j < expr2->count; j++) {
            if (conj_overlap(&expr1->conj_array[i], &expr2->conj_array[j])) {
                return 1;
            }
        }
    }
    return 0;
}

// The main function you asked for: compare logical expressions

// Return:
// 0 = no relation
// 1 = expr1 subset expr2
// 1 = expr2 subset expr1
// 3 = overlap
// 4 = equivalent
int compare_logical_expressions(const char* expr1, const char* expr2) {
	printf("\n****************************************************************************\n");fflush(stdout);
	printf("\nExp1:<<%s>>\n\n\nExp2:<<%s>>\n\n",expr1,expr2);fflush(stdout);
	printf("\n****************************************************************************\n");fflush(stdout);
    ExprNode* root1 = NULL;
    ExprNode* root2 = NULL;

    // Parse expr1
    tz.input = expr1;
    tz.pos = 0;
    tokenizer_next(&tz);
    if (parse_expr(&root1) != 0 || tz.current.type != TOKEN_END) {
        fprintf(stderr, "Parse error in expr1\n");fflush(stderr);
        if (root1) free_expr(root1);
        return 0;
    }

    // Parse expr2
    tz.input = expr2;
    tz.pos = 0;
    tokenizer_next(&tz);
    if (parse_expr(&root2) != 0 || tz.current.type != TOKEN_END) {
        fprintf(stderr, "Parse error in expr2\n");
        free_expr(root1);
        if (root2) free_expr(root2);
        return 0;
    }

    ConjList dnf1, dnf2;
    conjlist_init(&dnf1);
    conjlist_init(&dnf2);
    expr_to_dnf(root1, &dnf1);
    expr_to_dnf(root2, &dnf2);

    int subset12 = expr_is_subset(&dnf1, &dnf2);
    int subset21 = expr_is_subset(&dnf2, &dnf1);
    int overlap12 = expr_overlap(&dnf1, &dnf2);
	int overlap = expr_overlap(&dnf1, &dnf2);

    free_expr(root1);
    free_expr(root2);

    conjlist_free(&dnf1);
    conjlist_free(&dnf2);

    if (subset12 && subset21) return 4; // equivalent
    if (subset12) return 1; // expr1 subset expr2
	if (subset21) return 2;// expr2 subset expr1
    if (overlap) return 3; // overlap
    return 0; // no relation
}



/*****************End Sanjoy Fix Duplicate Variant Formula ***************************/

//Prachi - Added function to validate Variant Formula
extern DLLAPI int  check_vf_module(METHOD_message_t *msg, va_list args)
{
 	char *child_rev_id = NULL;
 	char *child_rev_seq = NULL;
	char *child_rev_stat = NULL;
	char *child_objType = NULL;
	char *mod_addr = NULL;
	char *mod_dsgGrp = NULL;
	char *mod_PrjCode = NULL;
 	int			revid			= 0;
 	int			revseq			= 0;
 	int			revstat			= 0;
 	int			blobjType		= 0;
	int			PartTypeI		= 0;
 	int			PartTypeCI		= 0;
 	int			modadd			= 0;
	int			modDG			= 0;
	int			modPC			= 0;
	int	ifail = 0;
	char *username;
	char *group_name;
	char *userid;
	tag_t user_tag=NULLTAG;
	tag_t group_tag=NULLTAG;
	char *designer_role = NULL;
	char *manager_role = NULL;

	char *dsgRole = NULL;
	char *mgrRole = NULL;

	char *CAB_dsgRole = NULL;
	char *CAB_mgrRole = NULL;

	int designer_found=0,manager_found=0;
	int desgFound=0,mgrFound=0;


	int projectCodeAccess = 0;

	int CABdesgFound=0,CABmgrFound=0;
	tag_t * 	list;

	tag_t * 	Desg_list;
	tag_t * 	Mgr_list;

	tag_t * 	CABDesg_list;
	tag_t * 	CABMgr_list;

	tag_t window=NULLTAG;
	tag_t top_bom_line=NULLTAG;
	//ass915906
	int     fndidlatest			=0;
	char   *child_fndid_latest	= NULL;
	int		Variantflag			= 0;
 	int		Variantflag1		= 0;
	char *child_PartType = NULL;
	char *child_ColorIndicator = NULL;

	tag_t	qry_t1	= NULLTAG;
	tag_t	Module	= NULLTAG;
	tag_t	ModuleIDRev	= NULLTAG;
	char **qry_val3 = (char **) MEM_alloc(10 * sizeof(char *));
	int n_entr1 = 1;
	char    *qry_entr1[1]  = {"SYSCD"};
	int rsltCunt1=0;
	tag_t *CntrlObjTag1=NULLTAG;
	int rsltCunt2=0;
	tag_t *CntrlObjTag2=NULLTAG;
	char	*info1r	= NULL;
	char	*ModuleGroup_Name	= NULL;
	//ass915906

	//Module Add Validation bypass for CV 22-08-2023
	tag_t	qry_cv_isCV	= NULLTAG;
	char **qry_cv_isCV_val = (char **) MEM_alloc(35 * sizeof(char *));
	int n_entr_cv_isCV = 1;
	char    *qry_entr_cv_isCV[1]  = {"SYSCD"};
	int rsltCunt_cv_isCV=0;
	tag_t *CntrlObjTag_cv_isCV=NULLTAG;
	logical isTCUAIsCV =false;
	int iqo = 0;


	tag_t bomline = msg->object_tag;

	tag_t BL_targ=va_arg(args, tag_t);
	char * BL_FormulaEdited=va_arg(args, char *);
	printf("\n!!!!!!!!!!!!!!!!! check_vf_module!!!!!!!!!!  <<<%s>>>\t\n",BL_FormulaEdited);fflush(stdout);
	POM_ask_group(&group_name, &group_tag);
	printf ("Logged in group:%s\n",group_name);fflush(stdout);
	if(bomline)
	{
 		printf("\n Validate VF\n");fflush(stdout);
 		//if(BOM_line_look_up_attribute("bl_item_item_id",&revid)!=ITK_ok) PrintErrorStack();
 		//if(BOM_line_look_up_attribute("bl_rev_item_revision_id",&revseq)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&revstat)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_look_up_attribute ("bl_item_object_type",&blobjType)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_look_up_attribute ("bl_Design Revision_t5_PartType",&PartTypeI)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_look_up_attribute ("bl_Design Revision_t5_ColourInd",&PartTypeCI)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_ask_attribute_string(bomline,revid,&child_rev_id)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_ask_attribute_string(bomline,revseq,&child_rev_seq)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_ask_attribute_string(bomline, revstat, &child_rev_stat)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_ask_attribute_string(bomline, blobjType, &child_objType)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_ask_attribute_string(bomline, PartTypeI, &child_PartType)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_ask_attribute_string(bomline, PartTypeCI, &child_ColorIndicator)!=ITK_ok) PrintErrorStack();

		if( AOM_ask_value_string(bomline,"bl_item_item_id",&child_rev_id));
		if( AOM_ask_value_string(bomline,"bl_rev_item_revision_id",&child_rev_seq));
		//if( AOM_ask_value_string(bomline,"bl_rev_release_status_list",&child_rev_stat));
		if( AOM_UIF_ask_value(bomline,"bl_rev_release_status_list",&child_rev_stat));
		if( AOM_ask_value_string(bomline,"bl_item_object_type",&child_objType));
		if( AOM_ask_value_string(bomline,"bl_Design Revision_t5_PartType",&child_PartType));
		if( AOM_ask_value_string(bomline,"bl_Design Revision_t5_ColourInd",&child_ColorIndicator));

		//if(BOM_line_ask_attribute_string(bomline, PartTypeCI, &child_ColorIndicator)!=ITK_ok) PrintErrorStack();
		printf("\n Part:%s %s Status:%s  child_objType <%s> \n",child_rev_id,child_rev_seq,child_rev_stat,child_objType);fflush(stdout);

		 ITEM_find_item(child_rev_id,&Module);
		 ITEM_ask_latest_rev(Module,&ModuleIDRev);
		 AOM_UIF_ask_value(ModuleIDRev,"owning_group",&ModuleGroup_Name);


		//ass915906
		/*bl_config = 0;
		if( BOM_line_look_up_attribute ("bl_rev_fnd0DSState",&bl_config));
		printf(" bl_config= [%d]\n", bl_config);

		if(BOM_line_ask_attribute_logical(bomline, bl_config, &bl_config_log));
		printf("bl_config_log= [%d]\n",bl_config_log);*/

		//if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
		//if(BOM_line_ask_attribute_string(bomline,fndidlatest,&child_fndid_latest));

		if( AOM_ask_value_string(bomline,"bl_occ_t5_upd_vf_form",&child_fndid_latest));
		printf("\n child_fndid_latest===============>>>>>> %s\n",child_fndid_latest);fflush(stdout);
		//ass915906

		/* If blank VF then allow to update */
		logical res = false;
		ifail = isBlankVF(bomline,&res);
		printf("\n isblank VF -- res ===> %d\n",res);fflush(stdout);

		if (tc_strcmp(child_objType,"Colour Part")!=0)
		{
			if(BOM_line_ask_window(bomline,&window)!=ITK_ok) PrintErrorStack();
			if(window)
			{
				  if(BOM_ask_window_top_line(window,&top_bom_line)!=ITK_ok) PrintErrorStack();
				  if(top_bom_line)
				  {
					  //if(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&blobjType)!=ITK_ok) PrintErrorStack();
					  //if(BOM_line_ask_attribute_string(top_bom_line, blobjType, &child_objType)!=ITK_ok) PrintErrorStack();

					  if( AOM_ask_value_string(top_bom_line,"fnd0bl_line_object_type",&child_objType));
					  if (tc_strcmp(child_objType,"T5_PlatformRevision")==0)
					  {
						POM_get_user(&username,&user_tag);
						SA_ask_user_identifier2	(user_tag,&userid)	;
						printf ("Logged in user:%s %s\n",userid,username);fflush(stdout);

						char *SupportUsername9 = NULL;
						tag_t SessionUser9_tag=NULLTAG;
						int     SupportFlag      =  0;

						SupportFlag=0;
						POM_get_user(&SupportUsername9,&SessionUser9_tag);
						if(SessionUser9_tag!=NULLTAG)
						{
							SupportFlag=0;
							SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
							printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
						}
						//if(tc_strcmp(userid,"ercpsup")!=0 && tc_strcmp(userid,"loader")!=0)
						if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
						{
							printf("\n Variant formula with X4 Context Not Allowed \n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s2(EMH_severity_error,ITK_err,"Variant formula can't be updated at platform level","Send architecture node separately to Structure Manager to edit variant formula of the module");
							return ITK_errStore;
						}
					  }
				  }
			}
			//ass915906
			if(QRY_find2("ControlObjects", &qry_t1));
			if (qry_t1)
			{
				printf("\n ControlObjects:.Found Query ControlObjects in UVF\n");fflush(stdout);
			}
			else
			{
				printf("\n ControlObjects:.Not Found Query ControlObjects in UVF\n");fflush(stdout);
			}

			qry_val3[0] = "UVFCROBJ";
			if(QRY_execute(qry_t1, n_entr1, qry_entr1, qry_val3, &rsltCunt1, &CntrlObjTag1));
			printf(" \n UVFCROBJ:rsltCunt1:::: in UVF>>> :%d:", rsltCunt1); fflush(stdout);
			if(rsltCunt1>0)
			{
				if (AOM_ask_value_string(CntrlObjTag1[0],"t5_Userinfo1",&info1r)!=ITK_ok) PrintErrorStack();
				printf("  UVF info1r is = [%s]\n", info1r);fflush(stdout);

				if (tc_strcmp(info1r,"ON")==0)
				{
					printf ("Inside control OBJ ON\n");fflush(stdout);
					POM_get_user(&username,&user_tag);
					SA_ask_user_identifier2	(user_tag,&userid)	;
					printf ("Logged in user Inside control OBJ ON-->:%s %s\n",userid,username);fflush(stdout);

					if((tc_strstr(child_rev_stat,"Release") != NULL))
					{
						printf ("\n 1111 Allowed to updte as child_rev_stat:- ERC Release & child_rev_seq:- not NR \n");fflush(stdout);
						//allowed if child_fndid_latest value is "False"
						if	(tc_strcmp(child_fndid_latest,"False")==0)
						{
							Variantflag++;
						}
						else if  ( ((tc_strstr(group_name,"APL") != NULL)&&(tc_strstr(ModuleGroup_Name,"APL") != NULL)) || ((tc_strstr(group_name,"MBOM") != NULL)) )  //MBOM implementation for CV TZ-1.69
						{

							printf ("for APL Create Module VF is allowed to update by APL user \n");fflush(stdout);

						}
						else
						{
							char *SupportUsername9 = NULL;
							tag_t SessionUser9_tag=NULLTAG;
							int     SupportFlag      =  0;

							SupportFlag=0;
							POM_get_user(&SupportUsername9,&SessionUser9_tag);
							if(SessionUser9_tag!=NULLTAG)
							{
								SupportFlag=0;
								SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
								printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
							}
							//if((tc_strcmp(userid,"su_mdm")!=0) && (tc_strcmp(userid,"infodba") !=0) && (tc_strcmp(userid,"loader") !=0) && (tc_strcmp(userid,"ercpsup") !=0))
							if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0) && (tc_strcmp(group_name, "Master_Data_Mgmt") != 0))
							{
								printf("\n Inside child_fndid_latest::Flag 111111::>>> True \n"); fflush(stdout);
								EMH_clear_errors();
								//EMH_store_error_s2(EMH_severity_error,ITK_err,"Variant formula can't be updated as module is already in update Variant formula workflow for updatation",child_rev_id);
								if(res)
								{
									EMH_store_error_s2(EMH_severity_error,ITK_err,"Variant formula can't be updated as module is already released, please take variant formula update DML to update variant formula.",child_rev_id);
									return ITK_errStore;
								}

							}
						}
					}

					else if(((tc_strcmp(child_rev_stat,"ERC Review") == 0) || (tc_strstr(child_rev_stat,"Working") != NULL)) && (tc_strstr(child_rev_seq,"NR") == NULL))
					{
						printf ("\n 2222 NOT Allowed to updte Variant Formula as child_rev_stat:- ERC Review/ERC Working & child_rev_seq:- is not NR \n");fflush(stdout);
						if(res)
						{
							Variantflag1++;
						}
					}

					else if(((tc_strcmp(child_rev_stat,"ERC Review") == 0) || (tc_strstr(child_rev_stat,"Working") != NULL)) && (tc_strstr(child_rev_seq,"NR") != NULL))
					{
						printf ("\n 3333 Allowed to updte child_rev_stat:- ERC Reviev/ERC Working & child_rev_seq:-NR \n");fflush(stdout);
						Variantflag++;

					}

	//				else if((tc_strstr(child_rev_stat,"Release") != NULL) && (tc_strstr(child_rev_seq,"NR") == NULL))
	//				{
	//					printf ("\n 2222 Allowed to updte as child_rev_stat:- ERC Release & child_rev_seq:- not NR \n");fflush(stdout);
	//					//allowed if child_fndid_latest value is "False"
	//					if	(tc_strcmp(child_fndid_latest,"False")==0)
	//					{
	//						Variantflag++;
	//					}
	//					else
	//					{
	//						if((tc_strcmp(userid,"su_mdm")!=0) && (tc_strcmp(userid,"infodba") !=0) && (tc_strcmp(userid,"loader") !=0) && (tc_strcmp(userid,"ercpsup") !=0))
	//						{
	//						printf("\n Inside child_fndid_latest::Flag 111111::>>> True \n"); fflush(stdout);
	//						EMH_clear_errors();
	//						EMH_store_error_s2(EMH_severity_error,ITK_err,"Variant formula can't be updated as module is already in update Variant formula workflow for updatation",child_rev_id);
	//						return ITK_errStore;
	//						}
	//					}
	//				}
				}
				else
				{
					if(tc_strstr(child_rev_stat,"Release") != NULL)
					{
						POM_get_user(&username,&user_tag);
						SA_ask_user_identifier2	(user_tag,&userid)	;
						printf ("Logged in user:%s %s\n",userid,username);fflush(stdout);

						char *SupportUsername9 = NULL;
						tag_t SessionUser9_tag=NULLTAG;
						int     SupportFlag      =  0;

						SupportFlag=0;
						POM_get_user(&SupportUsername9,&SessionUser9_tag);
						if(SessionUser9_tag!=NULLTAG)
						{
							SupportFlag=0;
							SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
							printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
						}
						//if((tc_strcmp(userid,"su_mdm")!=0) && (tc_strcmp(userid,"ercpsup")!=0))
						if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0) && (tc_strcmp(group_name, "Master_Data_Mgmt") != 0))
						{
							printf("\n Released Part, Variant Formula change is not allowed:%s %s\n",child_rev_id,child_rev_seq);fflush(stdout);
							EMH_clear_errors();
							if(res)
							{
								EMH_store_error_s3(EMH_severity_error,ITK_err,"\nVariant formula can't be updated for released part","Part or Module is already released ",child_rev_id);
								return ITK_errStore;
							}
						}
					}
					else //review or working
					{
						Variantflag++;
					}
				}
			}
		//ass915906
			//if(tc_strstr(child_rev_stat,"Release") != NULL)
			if (Variantflag1>0)
			{
				POM_get_user(&username,&user_tag);
				SA_ask_user_identifier2	(user_tag,&userid)	;
				printf ("Logged in user:%s %s\n",userid,username);fflush(stdout);
				char *SupportUsername9 = NULL;
				tag_t SessionUser9_tag=NULLTAG;
				int     SupportFlag      =  0;

				SupportFlag=0;
				POM_get_user(&SupportUsername9,&SessionUser9_tag);
				if(SessionUser9_tag!=NULLTAG)
				{
					SupportFlag=0;
					SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
					printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
				}
				//if((tc_strcmp(userid,"su_mdm")!=0) && (tc_strcmp(userid,"infodba")!=0) && (tc_strcmp(userid,"ercpsup")!=0))
				if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0) && (tc_strcmp(group_name, "Master_Data_Mgmt") != 0) && ((tc_strstr(ModuleGroup_Name,"APL") == NULL) || (tc_strstr(ModuleGroup_Name,"MBOM") == NULL))) //MBOM implementation for CV TZ-1.69
				{
					printf("\n Released Part, Variant Formula change is not allowed:%s %s\n",child_rev_id,child_rev_seq);fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s3(EMH_severity_error,ITK_err,"\nVariant formula updation is allowed if Module Revision =NR and Release Status =ERC Review","For Revision other than NR kindly take Update variant formula type DML",child_rev_id);
					return ITK_errStore;
				}
			}

			if (Variantflag>0)
			{
				POM_get_user(&username,&user_tag);
				SA_ask_user_identifier2	(user_tag,&userid)	;
				printf ("Logged in user:%s\n",userid);fflush(stdout);

				// check if TCUA Env is PV or CV
				if(QRY_find2("ControlObjects", &qry_cv_isCV));
				if (qry_cv_isCV)
				{
					printf("\n ControlObjects:.Found Query qry_cv_isCV \n");fflush(stdout);
				}
				else
				{
					printf("\n ControlObjects:.Not Found Query qry_cv_isCV \n");fflush(stdout);
				}

				qry_cv_isCV_val[0] = "CV_ModuleAdd_Validation_bypass_OnVFUpdate";
				if(QRY_execute(qry_cv_isCV, n_entr_cv_isCV, qry_entr_cv_isCV, qry_cv_isCV_val, &rsltCunt_cv_isCV, &CntrlObjTag_cv_isCV));
				printf(" \n CV_ModuleAdd_Validation_bypass_OnVFUpdate::::>>> :%d:", rsltCunt_cv_isCV); fflush(stdout);
				if(rsltCunt_cv_isCV	> 0)
				{
					isTCUAIsCV =true;
				}

				if((tc_strcmp(group_name,"Master_Data_Mgmt")!=0)) //&& (tc_strcmp(userid,"infodba")!=0)
				{
						//if(BOM_line_look_up_attribute("bl_Design Revision_t5_ModuleAddress",&modadd)!=ITK_ok) PrintErrorStack();
						//if(BOM_line_look_up_attribute("bl_Design Revision_t5_DesignGrp",&modDG)!=ITK_ok) PrintErrorStack();  //Not used anywhere
						//if(BOM_line_look_up_attribute("bl_Design Revision_t5_ProjectCode",&modPC)!=ITK_ok) PrintErrorStack(); //Not used anywhere

						//if(modadd > 0)
						//{

							if(isTCUAIsCV)
							{
									//CV Logic
									//if(BOM_line_ask_attribute_string(bomline, modDG, &mod_dsgGrp)!=ITK_ok) PrintErrorStack();
									//printf("\n mod_dsgGrp:%s\n",mod_dsgGrp);fflush(stdout);
									if( AOM_ask_value_string(bomline,"bl_Design Revision_t5_DesignGrp",&mod_dsgGrp));
									printf("\n mod_dsgGrp:%s\n",mod_dsgGrp);fflush(stdout);

									//if(BOM_line_ask_attribute_string(bomline, modPC, &mod_PrjCode)!=ITK_ok) PrintErrorStack();
									//printf("\n mod_PrjCode:%s\n",mod_PrjCode);fflush(stdout);
									if( AOM_ask_value_string(bomline,"bl_Design Revision_t5_ProjectCode",&mod_PrjCode));
									printf("\n mod_PrjCode:%s\n",mod_PrjCode);fflush(stdout);

									//if(BOM_line_ask_attribute_string(bomline, modadd, &mod_addr)!=ITK_ok) PrintErrorStack();
									//printf("\n mod_addr:%s\n",mod_addr);fflush(stdout);
									if( AOM_ask_value_string(bomline,"bl_Design Revision_t5_ModuleAddress",&mod_addr));
									printf("\n mod_addr:%s\n",mod_addr);fflush(stdout);

									if(mod_addr != NULL && strlen(mod_addr) > 0)
									{
										//chek if user having access for Module Design Group

										dsgRole = (char *)MEM_alloc ((strlen(mod_dsgGrp) + strlen("_Designers")) * sizeof(char));
										strcpy(dsgRole,mod_dsgGrp);
										strcat(dsgRole,"_Designers");

										mgrRole  = (char *)MEM_alloc ((strlen(mod_dsgGrp) + strlen("_Managers")) * sizeof(char));
										strcpy(mgrRole,mod_dsgGrp);
										strcat(mgrRole,"_Managers");

										CAB_dsgRole =(char *)MEM_alloc(25);
										CAB_mgrRole =(char *)MEM_alloc(25);

										strcpy(CAB_dsgRole,"");
										strcat(CAB_dsgRole,"CAB_Designers");

										strcpy(CAB_mgrRole,"");
										strcat(CAB_mgrRole,"CAB_Managers");


										printf("\nFirst search for role:%s OR %s\n",CAB_dsgRole,CAB_mgrRole);fflush(stdout);

										if(SA_find_groupmember_by_rolename(CAB_dsgRole,"ERC_Designers_Group",userid,&CABdesgFound,&CABDesg_list)!=ITK_ok) PrintErrorStack();
										if(SA_find_groupmember_by_rolename(CAB_mgrRole,"ERC_Designers_Group",userid,&CABmgrFound,&CABMgr_list)!=ITK_ok) PrintErrorStack();

										if(CABdesgFound == 0 && CABmgrFound == 0)
										{
											// No Cab Designer or Manager access found.
											// now checking access for Design group


											printf("\n Second search for role:%s OR %s\n",dsgRole,mgrRole);fflush(stdout);

											if(SA_find_groupmember_by_rolename(dsgRole,"ERC_Designers_Group",userid,&desgFound,&Desg_list)!=ITK_ok) PrintErrorStack();
											if(SA_find_groupmember_by_rolename(mgrRole,"ERC_Designers_Group",userid,&mgrFound,&Mgr_list)!=ITK_ok) PrintErrorStack();

											if(desgFound == 0 && mgrFound == 0 && ( (tc_strstr(ModuleGroup_Name,"APL") == NULL) || (tc_strstr(ModuleGroup_Name,"MBOM") ))) //MBOM implementation for CV TZ-1.69
											{
													EMH_clear_errors();
													EMH_store_error_s3(EMH_severity_error,ITK_err,"\nYou don't have access to update variant formula for this module","Contact PLM Admin to get access",userid);
													return ITK_errStore;
											}
											//checking project code access
											projectCodeAccess = checkProjectCodeAccess(mod_PrjCode,userid);

											printf("\n projectCodeAccess :[ %d ] \n",projectCodeAccess);fflush(stdout);

											if(projectCodeAccess == 0  && ( (tc_strstr(ModuleGroup_Name,"APL") == NULL) || (tc_strstr(ModuleGroup_Name,"MBOM") ))) //MBOM implementation for CV TZ-1.69
											{
													EMH_clear_errors();
													EMH_store_error_s3(EMH_severity_error,ITK_err,"\nYou don't have access to update variant formula for this module","Contact PLM Admin to get access",userid);
													return ITK_errStore;
											}


										}
										//checking project code access
										 projectCodeAccess = checkProjectCodeAccess(mod_PrjCode,userid);

										 printf("\n projectCodeAccess :[ %d ] \n",projectCodeAccess);fflush(stdout);

										 if(projectCodeAccess == 0  && ( (tc_strstr(ModuleGroup_Name,"APL") == NULL) || (tc_strstr(ModuleGroup_Name,"MBOM") ))) //MBOM implementation for CV TZ-1.69
										 {
												EMH_clear_errors();
												EMH_store_error_s3(EMH_severity_error,ITK_err,"\nYou don't have access to update variant formula for this module","Contact PLM Admin to get access",userid);
												return ITK_errStore;
										 }


									}
									else
									{
											EMH_clear_errors();
											EMH_store_error_s3(EMH_severity_error,ITK_err,"\nModule Address is blank for this module","Contact PLM Team to update Module Address",userid);
											return ITK_errStore;

									}

							}
							else
							{
									// PV logic:

									//if(BOM_line_ask_attribute_string(bomline, modadd, &mod_addr)!=ITK_ok) PrintErrorStack();
									if( AOM_ask_value_string(bomline,"bl_Design Revision_t5_ModuleAddress",&mod_addr));
									printf("\n mod_addr:%s\n",mod_addr);fflush(stdout);
									if(mod_addr != NULL && strlen(mod_addr) > 0)
									{

										designer_role = (char *)MEM_alloc ((strlen(mod_addr) + strlen("_Designers")) * sizeof(char));
										strcpy(designer_role,mod_addr);
										strcat(designer_role,"_Designers");
										manager_role  = (char *)MEM_alloc ((strlen(mod_addr) + strlen("_Managers")) * sizeof(char));
										strcpy(manager_role,mod_addr);
										strcat(manager_role,"_Managers");
										printf("\nsearch for role:%s OR %s\n",designer_role,manager_role);fflush(stdout);

										if(SA_find_groupmember_by_rolename(designer_role,"ERC_Designers_Group",userid,&designer_found,&list)!=ITK_ok) PrintErrorStack();
										if(SA_find_groupmember_by_rolename(manager_role,"ERC_Designers_Group",userid,&manager_found,&list)!=ITK_ok) PrintErrorStack();
										printf("\n designer_found:%d manager_found:%d\n",designer_found,manager_found); fflush(stdout);
										if(designer_found == 0 && manager_found == 0 && ( (tc_strstr(ModuleGroup_Name,"APL") == NULL) || (tc_strstr(ModuleGroup_Name,"MBOM") ))) //MBOM implementation for CV TZ-1.69
										{
											EMH_clear_errors();
											EMH_store_error_s3(EMH_severity_error,ITK_err,"\nYou don't have access to update variant formula for this module","Contact PLM Admin to get access",userid);
											return ITK_errStore;
										}

									}
									else
									{
											EMH_clear_errors();
											EMH_store_error_s3(EMH_severity_error,ITK_err,"\nModule Address is blank for this module","Contact PLM Team to update Module Address",userid);
											return ITK_errStore;

									}

							}

						//}
						//else
						//{
						//			EMH_clear_errors();
						//			EMH_store_error_s3(EMH_severity_error,ITK_err,"\nModule Address not found for this module","Contact PLM Team to update Module Address",userid);
						//			return ITK_errStore;
						//}
				}
			}



						/////////Module Variant Formula  Validation////////

			int parent_item_seq=0;
			tag_t itemrev =NULLTAG;
			char* Trgt_bl_formula=NULL;
			char*  Part_no =NULL;
			int n_parents=0;
			int *levels = 0;
			tag_t *parents = NULL;
			int jd=0;
			tag_t ArchAssyTag =NULLTAG;
			char* Arch_obj= NULL;
			char* Archtype_name= NULL;
			tag_t ArchobjTypeTag=NULLTAG;
			//char   Archtype_name[TCTYPE_name_size_c+1];
			tag_t window=NULLTAG;
			tag_t  rule=NULLTAG;
			tag_t top_line =NULLTAG;
			int n_BL=0;
			tag_t *children1= NULL;
			int p1=0;
			tag_t Childobject=NULLTAG;
			char* child_item_id = NULL;
			char* chidl_moduleAddress =NULL;
			char* child_bl_formula_cmp = NULL;
			char* child_bl_formula = NULL;
			tag_t  	master =	NULLTAG;
			char*  Arch_obj_str = NULL;
			tag_t relation_dep=	NULLTAG;
			int countConfigCtx = 0;
			tag_t  *ConfigCtxSecObject	= NULLTAG;
			tag_t ConfigCtx = NULLTAG;
			tag_t  ConfigCtxObjTypeTag=NULLTAG;
			//char   Config_CtxType[TCTYPE_name_size_c+1];
			char*	 SmVCContext			= NULL;
			char*	 SmCrIDContext			= NULL;
			char*	 ContextobjName			= NULL;
			char*	 Config_CtxType			= NULL;

			tag_t	qry_t1	= NULLTAG;
			char **qry_val3 = (char **) MEM_alloc(10 * sizeof(char *));
			char **qry_val4 = (char **) MEM_alloc(10 * sizeof(char *));
			int n_entr1 = 1;
			char    *qry_entr1[1]  = {"SYSCD"};
			int rsltCunt1=0;
			tag_t *CntrlObjTag1=NULLTAG;

			tag_t	queryTag	= NULLTAG;
			char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
			int n_entries = 1;
			int resultCount=0;
			char *qry_entries[1] = {"ID"};

			tag_t *ConId  = NULL;
			int j=0;
			tag_t Optfmly_tag = NULLTAG;

			int dmlIncnt =0;
			int CmpleteVrf=0;
			char *username_vf =NULL;
			tag_t user_tag_vf =NULLTAG;

			//PV CV Changes:: 18-04-2023
			tag_t	qry_cv_bypass	= NULLTAG;
			char **qry_cv_bypass_val = (char **) MEM_alloc(35 * sizeof(char *));
			int n_entr_cv_bypass = 1;
			char    *qry_entr_cv_bypass[1]  = {"SYSCD"};
			int rsltCunt_cv_bypass=0;
			tag_t *CntrlObjTag_cv_bypass=NULLTAG;
			logical isCVProd =false;
			int iqo = 0;

			char* useInfo1 =NULL;
			char* useInfo2 =NULL;
			char* useInfo3 =NULL;
			char* useInfo4 =NULL;
			char* useInfo5 =NULL;
			char* useInfo6 =NULL;
			char* useInfo7 =NULL;
			char* useInfo8 =NULL;
			char* useInfo9 =NULL;
			char* useInfo10 =NULL;

			char *modAddressFinalStr		=NULL;

			POM_get_user(&username_vf,&user_tag_vf);
			printf ("Logged in user in VF validation function : %s\n",username_vf);fflush(stdout);

			//if(BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &parent_item_seq)!=ITK_ok) PrintErrorStack();
			//if(BOM_line_ask_attribute_tag(bomline, parent_item_seq, &itemrev)!=ITK_ok) PrintErrorStack();

			CALLAPI(AOM_ask_value_tag(bomline,"bl_revision",&itemrev));
			//CALLAPI(ITEM_find_revision(Module,child_rev_seq,&itemrev));

			if(itemrev)
				{
					//if(AOM_ask_value_string(bomline, "bl_formula", &Trgt_bl_formula )!=ITK_ok) PrintErrorStack();
					//printf("\n\t child_bl_formula--------------> %s\n",Trgt_bl_formula); fflush(stdout);

					if(AOM_ask_value_string(itemrev,"item_id",&Part_no)!=ITK_ok) PrintErrorStack();
					printf("\n\n\t CP Part_no  is :%s",Part_no);fflush(stdout);

					if(PS_where_used_all(itemrev,1,&n_parents,&levels,&parents)!=ITK_ok) PrintErrorStack();
					printf("\n\t CP where_used count of objects are Drag Drop : %d",n_parents); fflush(stdout); // 1
				}

			if(top_bom_line)
			{
				//if(BOM_line_ask_attribute_tag(top_bom_line, parent_item_seq, &ArchAssyTag)!=ITK_ok) PrintErrorStack();
				//CALLAPI(ITEM_find_revision(Module,child_rev_seq,&ArchAssyTag));
				CALLAPI(AOM_ask_value_tag(top_bom_line,"bl_revision",&ArchAssyTag));
				printf("\n\t Inside top bomline"); fflush(stdout);



			  if(ArchAssyTag)
			  {
				//ArchAssyTag=parents[jd];
				if(AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj)!=ITK_ok) PrintErrorStack();
				printf("\n\t Architecture Object Drag Drop is :%s",Arch_obj);	fflush(stdout);

				if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag)!=ITK_ok) PrintErrorStack();
				if(TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name)!=ITK_ok) PrintErrorStack();
				printf("\n\t Drag Drop Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

				if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
				{
					 printf("\n\t Inside T5_ArchModuleRevision........");fflush(stdout);

					  if(ITEM_ask_item_of_rev(ArchAssyTag, &master));
					 if(AOM_ask_value_string(master,"item_id",&Arch_obj_str)!=ITK_ok) PrintErrorStack();
					 printf("\n\t Architecture Object String Type is :%s",Arch_obj_str); fflush(stdout);

					 if(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep)!=ITK_ok) PrintErrorStack();
					 if(relation_dep)
					 {
						printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);
					 }

					 if(GRM_list_secondary_objects_only(master,relation_dep,&countConfigCtx,&ConfigCtxSecObject)!=ITK_ok) PrintErrorStack();
					 printf("\n\t Configuration Context count is : %d",countConfigCtx);


					if(countConfigCtx>0)
					{
						ConfigCtx=ConfigCtxSecObject[0];
						if(BOM_create_window (&window)!=ITK_ok) PrintErrorStack();
						if(CFM_find( "Latest Working", &rule )!=ITK_ok) PrintErrorStack();
						if(BOM_set_window_config_rule( window, rule )!=ITK_ok) PrintErrorStack();
						if(BOM_set_window_pack_all (window, false)!=ITK_ok) PrintErrorStack();
						if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok) PrintErrorStack();
						if(top_line!=NULLTAG)
						{
							if(BOM_line_ask_child_lines(top_line, &n_BL, &children1)!=ITK_ok) PrintErrorStack();
							printf("\n\t No of child objects are n : %d",n_BL);fflush(stdout);
							if (n_BL >0)
							{


								if(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag)!=ITK_ok) PrintErrorStack();
								if(TCTYPE_ask_name2(ConfigCtxObjTypeTag,&Config_CtxType)!=ITK_ok) PrintErrorStack();
								printf( "\n\t Config relation Config_CtxType :%s ..",Config_CtxType);

								if(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext)!=ITK_ok) PrintErrorStack();
								printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

								if(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext)!=ITK_ok) PrintErrorStack();
								printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

								if(QRY_find2("Cfg0OptionFamiliesFromIDs", &queryTag)!=ITK_ok) PrintErrorStack();
								printf("\n\t After Cfg0OptionFamiliesFromIDs : QRY_find2");fflush(stdout);
								if (queryTag)
								{
									printf("\n\tFound Query");fflush(stdout);
								}else
								{
									printf("\n\tNot Found Query");fflush(stdout);
								}

								qry_values[0] = SmCrIDContext;
								resultCount = 0;
								if(queryTag!= NULLTAG)
								{
									if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &ConId)!=ITK_ok) PrintErrorStack();
								}
								printf("\n\t resultCount : %d\n", resultCount); fflush(stdout);


								if(tc_strcmp(BL_FormulaEdited,"")==0 && resultCount >0)
								{
									printf("\n CC available Variant formula not available \n"); fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s2(EMH_severity_error,ITK_err, "Module Release not allowed without variant formula for",Part_no);
									return ITK_errStore;
								}
								else
								{
								  for (j=0;j<resultCount;j++ )
								  {
									 Optfmly_tag = ConId[j];
									 if(AOM_ask_value_string(Optfmly_tag,"object_name",&ContextobjName)!=ITK_ok) PrintErrorStack();
									 printf("\n\t ContextobjName Object String Type is :%s",ContextobjName); fflush(stdout);   //Drive, Fuel is a Name if Option family

									 if(ContextobjName)
									 {
										printf("\n\t child_bl_formula value:%s",BL_FormulaEdited);
										printf("\n\t child_bl_formulaaaa tc_strstr result--------------> %s\n",tc_strstr(BL_FormulaEdited,ContextobjName)); fflush(stdout);

										if(tc_strstr(BL_FormulaEdited,ContextobjName)==NULL)
										{
											printf("\n inside iff \n"); fflush(stdout);
											dmlIncnt++;
										}
										else
										 {
											printf("\n inside else \n"); fflush(stdout);
											CmpleteVrf++;
										 }
									 }
								  }

								  printf("\n dmlIncnt value is at end for loop :%d\n",dmlIncnt); fflush(stdout);
								  if (dmlIncnt>0)
								  {
									  // Validation is baypass for loader
									  if((tc_strcmp(username_vf,"loader")!=0))
									  {
											printf("\n dmlIncnt greator than 1 :%d\n",dmlIncnt); fflush(stdout);
											EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_error,ITK_err, "Variant formula is not complete for Module",Part_no);
											return ITK_errStore;
									  }
									  else
									  {

									  }

								  }

								}
								//PV CV Changes::
								if(QRY_find2("ControlObjects", &qry_cv_bypass));
								if (qry_cv_bypass)
								{
									printf("\n ControlObjects:.Found Query qry_cv_bypass \n");fflush(stdout);
								}
								else
								{
									printf("\n ControlObjects:.Not Found Query qry_cv_bypass \n");fflush(stdout);
								}

								qry_cv_bypass_val[0] = "CV_ValidationByPassWithModuleAdd";
								if(QRY_execute(qry_cv_bypass, n_entr_cv_bypass, qry_entr_cv_bypass, qry_cv_bypass_val, &rsltCunt_cv_bypass, &CntrlObjTag_cv_bypass));
								printf(" \n CV_ValidationByPassWithModuleAdd::::>>> :%d:", rsltCunt_cv_bypass); fflush(stdout);
								if(rsltCunt_cv_bypass>0)
								{
									isCVProd =true;
								}

								modAddressFinalStr = (char *) MEM_alloc(5000 * sizeof(char *));

								for(iqo =0 ;iqo < rsltCunt_cv_bypass ;iqo++)
								{
											printf("\n\t Value of iqo :: is [%d]",iqo);

											ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_Userinfo1",&useInfo1));
											printf("\n\t useInfo1 string value: %s",useInfo1);

											ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_Userinfo2",&useInfo2));
											printf("\n\t useInfo2 string value: %s",useInfo2);

											ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_Userinfo3",&useInfo3));
											printf("\n\t useInfo3 string value: %s",useInfo3);

											ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_Userinfo4",&useInfo4));
											printf("\n\t useInfo4 string value: %s",useInfo4);

											ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_Userinfo5",&useInfo5));
											printf("\n\t useInfo5 string value: %s",useInfo5);

											ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_Userinfo6",&useInfo6));
											printf("\n\t useInfo6 string value: %s",useInfo6);

											ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_Userinfo7",&useInfo7));
											printf("\n\t useInfo7 string value: %s",useInfo7);

											ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_Userinfo8",&useInfo8));
											printf("\n\t useInfo8 string value: %s",useInfo8);

											ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_Userinfo9",&useInfo9));
											printf("\n\t useInfo9 string value: %s",useInfo9);

											ITK_CALL(AOM_ask_value_string(CntrlObjTag_cv_bypass[iqo],"t5_userinfo10",&useInfo10));
											printf("\n\t useInfo10 string value: %s",useInfo10);

											if(useInfo1 == NULL)
											{
												tc_strcat(useInfo1,"");
											}
											if(useInfo2 == NULL)
											{
												tc_strcat(useInfo2,"");
											}
											if(useInfo3 == NULL)
											{
												tc_strcat(useInfo3,"");
											}
											if(useInfo4 == NULL)
											{
												tc_strcat(useInfo4,"");
											}
											if(useInfo5 == NULL)
											{
												tc_strcat(useInfo5,"");
											}
											if(useInfo6 == NULL)
											{
												tc_strcat(useInfo6,"");
											}
											if(useInfo7 == NULL)
											{
												tc_strcat(useInfo7,"");
											}
											if(useInfo8 == NULL)
											{
												tc_strcat(useInfo8,"");
											}
											if(useInfo9 == NULL)
											{
												tc_strcat(useInfo9,"");
											}
											if(useInfo10 == NULL)
											{
												tc_strcat(useInfo10,"");
											}

											if(modAddressFinalStr == NULL)
											{
												tc_strcpy(modAddressFinalStr,"");
												tc_strcat(modAddressFinalStr,useInfo1);
												tc_strcat(modAddressFinalStr,useInfo2);
												tc_strcat(modAddressFinalStr,useInfo3);
												tc_strcat(modAddressFinalStr,useInfo4);
												tc_strcat(modAddressFinalStr,useInfo5);
												tc_strcat(modAddressFinalStr,useInfo6);
												tc_strcat(modAddressFinalStr,useInfo7);
												tc_strcat(modAddressFinalStr,useInfo8);
												tc_strcat(modAddressFinalStr,useInfo9);
												tc_strcat(modAddressFinalStr,useInfo10);
											}
											else
											{
												tc_strcat(modAddressFinalStr,useInfo1);
												tc_strcat(modAddressFinalStr,useInfo2);
												tc_strcat(modAddressFinalStr,useInfo3);
												tc_strcat(modAddressFinalStr,useInfo4);
												tc_strcat(modAddressFinalStr,useInfo5);
												tc_strcat(modAddressFinalStr,useInfo6);
												tc_strcat(modAddressFinalStr,useInfo7);
												tc_strcat(modAddressFinalStr,useInfo8);
												tc_strcat(modAddressFinalStr,useInfo9);
												tc_strcat(modAddressFinalStr,useInfo10);
											}
								}

								printf("\n\t modAddressFinalStr string value After concat: %s\n \n",modAddressFinalStr);

								for (p1=0;p1<n_BL ;p1++ )
								{
									int Result=1;
									if(Childobject) Childobject=NULLTAG;
									Childobject=children1[p1];
									if(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id )!=ITK_ok) PrintErrorStack();
									printf("\n\t Design Object ===> :: %s",child_item_id); fflush(stdout);

									if(AOM_ask_value_string(Childobject, "bl_Design Revision_t5_ModuleAddress", &chidl_moduleAddress )!=ITK_ok) PrintErrorStack();
									printf("\n\t Revision_t5_ModuleAddress ===> :: %s",chidl_moduleAddress); fflush(stdout);

									if(isCVProd==false || (isCVProd && tc_strstr(modAddressFinalStr,chidl_moduleAddress)==0))
									{
											if(tc_strcmp(Part_no,child_item_id))
											{

												if(AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula_cmp )!=ITK_ok) PrintErrorStack();
												printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula_cmp); fflush(stdout);

												if (tc_strcmp(child_bl_formula_cmp,BL_FormulaEdited)==0)
												{
													printf("\nDuplicate Variant Formula found,change is not allowed:%s %s\n",Part_no,child_item_id);fflush(stdout);
													EMH_clear_errors();
													EMH_store_error_s4(EMH_severity_error,ITK_err,"\nDuplicate Variant formula  found for ",Part_no,"  and ",child_item_id);
													return ITK_errStore;
												}

												/// checkin for OR condition

												if(QRY_find2("ControlObjects", &qry_t1));
												if (qry_t1)
												{
													printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);
												}
												else
												{
													printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
												}

												qry_val3[0] = "Modulewith_OR1";
												if(QRY_execute(qry_t1, n_entr1, qry_entr1, qry_val3, &rsltCunt1, &CntrlObjTag1));
												printf("\nUVF:ModulewithOR:rsltCunt1::::>>> :%d:", rsltCunt1); fflush(stdout);
												if(rsltCunt1>0)
												{

													qry_val4[0] = "DuplicateVFCkeck_OR";

													if(QRY_execute(qry_t1, n_entr1, qry_entr1, qry_val4, &rsltCunt2, &CntrlObjTag2));
													printf("\nUVF:DuplicateVFCkeck_OR:rsltCunt2::::>>> :%d:", rsltCunt2); fflush(stdout);

													if(rsltCunt2>0)
													{
														int resul = 0;
														char* BL_FormulaEditedDup = NULL;
														char* child_bl_formula_cmpDup = NULL;
														if(BL_FormulaEdited)tc_strdup(BL_FormulaEdited,&BL_FormulaEditedDup);
														if(child_bl_formula_cmp)tc_strdup(child_bl_formula_cmp,&child_bl_formula_cmpDup);
														printf("\nUVF:child_bl_formula_cmpDup:[%s]",child_bl_formula_cmpDup);fflush(stdout);
														printf("\nUVF:BL_FormulaEditedDup:[%s]\n",BL_FormulaEditedDup);fflush(stdout);
														if(child_bl_formula_cmpDup != NULL && BL_FormulaEditedDup != NULL)
														{
															int l1 = tc_strlen(child_bl_formula_cmpDup);
															int l2 = tc_strlen(BL_FormulaEditedDup);
															printf("\nl1:[%d], l2:[%d]\n",l1,l2);fflush(stdout);
															if(l1 > 0 &&  l2 > 0)
															{
																printf("\nInside comparision\n");fflush(stdout);
																resul = compare_logical_expressions(BL_FormulaEditedDup,child_bl_formula_cmpDup);


																printf("UVF:Compare result:[%d]",resul);fflush(stdout);
																switch (resul)
																{
																	case 0: printf("UVF:No relation, Diff VF\n"); break;
																	case 1: printf("UVF:Expr1 is subset of Expr2\n"); break;
																	case 2: printf("UVF:Expr2 is subset of Expr1\n"); break;
																	case 3: printf("UVF:Expr1 overlaps Expr2\n"); break;
																	case 4: printf("UVF:Expr1 is equivalent to Expr2\n"); break;
																}

																if(resul == 1 || resul == 2 || resul == 3 || resul == 4)
																{
																	printf("\nUVF:Equivalent VF,BLFormula_ValidateNew: Duplicate Variant formula\n");fflush(stdout);
																	EMH_store_error_s4(EMH_severity_error,ITK_err,"\nError :BLFormula_ValidateNew: Duplicate Variant formula  found for ",Part_no,"  and ",child_item_id);
																	return ITK_errStore;
																}
															}
															else
															{
																printf("\nUVF:skip1");fflush(stdout);
															}

														}
														else
														{
															printf("\nUVF:skip");fflush(stdout);
														}




													}
													else
													{
																																															Result=BLFormula_Validate(ConfigCtx,BL_FormulaEdited,child_bl_formula_cmp);
														printf(" \n ModulewithOR:Result::::>>> :%d:", Result); fflush(stdout);
														if (Result==0)
														{
															EMH_store_error_s4(EMH_severity_error,ITK_err,"\nError :BLFormula_Validate: Duplicate Variant formula  found for ",Part_no,"  and ",child_item_id);
															return ITK_errStore;
														}
													}

												}

										}
									}

								}
							}//
						}
					}
				}
			  }
			}


			//Added by Deepti in TZ1.54 for APLModule

			char *Part_no_rev =NULL;
			char *sFourFiveChar =NULL;
			char *ModuleErr =NULL;
			char *plantName =NULL;
			int control_number_found_mod=0;
			int FlagModFnd=0;
			int count_task=0;
			int cnt_tk=0;
			tag_t	*list_of_WSO_cntrlPrj_mod_tags	=	NULLTAG;
			char	**qry_valuesCntrlA= (char **) MEM_alloc(6 * sizeof(char *));
			tag_t   qryTagCntrl			=	NULLTAG;
			int     n_entryCntrl		=	4;
			char    *qry_entryCntrl[4]  = {"Name","SUBSYSCD","Delete Indicator","Information-1"};
			tag_t	  		relation_type_PrtToTsk	=	NULLTAG;
			tag_t*			PartTaskTags		= NULLTAG;
			tag_t	  		TaskTag_class	=	NULLTAG;
			//char			Task_class[TCTYPE_name_size_c+1];
			char*			TaskId				=	NULL;
			char*			Task_class				=	NULL;
			char GetPlant[40];
			tag_t	  		PartTskTag			=	NULLTAG;


			if(AOM_ask_value_string(itemrev,"item_id",&Part_no)!=ITK_ok) PrintErrorStack();
			printf("\n\n\t CP Part_no  is :%s",Part_no);fflush(stdout);

			if(AOM_ask_value_string(itemrev,"item_revision_id",&Part_no_rev)!=ITK_ok) PrintErrorStack();
			printf("\n\n\t CP Part_no_rev  is :%s",Part_no_rev);fflush(stdout);

			sFourFiveChar	=	subString(Part_no,4,5);

			if(QRY_find2("Control Objects...", &qryTagCntrl));

			if (qryTagCntrl!=NULLTAG)
			{

				qry_valuesCntrlA[0]	=	"BIW_APL_MODULE";
				qry_valuesCntrlA[1]	=	"APL";
				qry_valuesCntrlA[2]	=	"0";
				qry_valuesCntrlA[3]	=	sFourFiveChar;

				printf("\n sFourFiveChar: %s\n",sFourFiveChar);fflush(stdout);
				if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrlA, &control_number_found_mod, &list_of_WSO_cntrlPrj_mod_tags));
				printf("\n CompCodeAPLPrj=>control_number_found_mod is : %d\n",control_number_found_mod);fflush(stdout);
				if(control_number_found_mod>0)
				{
					FlagModFnd=1;
				}
				if(FlagModFnd==1)
				{

					 ITKCALL(AOM_ask_value_string(list_of_WSO_cntrlPrj_mod_tags[0], "t5_Userinfo2", &plantName));
					 printf("\n plantName: %s\n",plantName);fflush(stdout);

					GRM_find_relation_type("CMHasSolutionItem",&relation_type_PrtToTsk);
					GRM_list_primary_objects_only(itemrev,relation_type_PrtToTsk,&count_task,&PartTaskTags);

					printf("\n count_task: %d \n",count_task); fflush(stdout);

					if(count_task>0)
					{
						for (cnt_tk=0;cnt_tk<count_task ;cnt_tk++ )
						{
							PartTskTag=PartTaskTags[cnt_tk];
							ITKCALL (TCTYPE_ask_object_type(PartTskTag,&TaskTag_class));
							ITKCALL (TCTYPE_ask_name2(TaskTag_class,&Task_class));

							printf("\t  Task_class ...%s\n", Task_class); fflush(stdout);
							if(tc_strcmp(Task_class,"T5_APLTaskRevision")==0)
							{
								ITKCALL(AOM_ask_value_string(PartTskTag, "item_id",&TaskId));
								printf("\n TaskId %s.....\n",TaskId); fflush(stdout);

								GetPlantForDMLORTask1(TaskId,GetPlant);

								printf("\n GetPlant %s.plantName %s ....\n",GetPlant,plantName); fflush(stdout);
								if(tc_strcmp(GetPlant,plantName)==0)
								{
									printf("\nInside error if DML alreadt attached"); fflush(stdout);
									ModuleErr	=	NULL;
									ModuleErr	=	(char *)MEM_alloc(200);
									tc_strcpy(ModuleErr,"");
									tc_strcat(ModuleErr,"Module ");
									tc_strcat(ModuleErr,Part_no);
									tc_strcat(ModuleErr,";");
									tc_strcat(ModuleErr,Part_no_rev);
									tc_strcat(ModuleErr," are attached to Task ");
									tc_strcat(ModuleErr,TaskId);
									tc_strcat(ModuleErr,".Hence not allowed to update Variant formula.");
									tc_strcat(ModuleErr,".\n");

									printf("\nModuleErr %s",ModuleErr); fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err,ModuleErr);
									return ITK_errStore;
									break;

								}

							}
						}
					}


				}
			}

			//End of Deepti in TZ1.54 for APLModule

			/*
			//Added by Hanuman in TZ 1.52
			printf("\n BOMLine PartType :%s and Colour Indicator is :%s\n",child_PartType,child_ColorIndicator);fflush(stdout);
			if((tc_strstr(child_PartType,"Module")!= NULL) && (tc_strstr(child_ColorIndicator,"Y")!= NULL))
			{
				if(BL_FormulaEdited!=NULL)
				{
					printf("\n Going To Check Variant Formula =>%s\t\n",BL_FormulaEdited); fflush(stdout);
					if((tc_strstr(BL_FormulaEdited,"COLOUR-BOM")!= NULL) && (tc_strstr(BL_FormulaEdited,"SCHEME-NO")!= NULL))
					{
						if((tc_strstr(BL_FormulaEdited,"[Teamcenter]COLOUR-BOM = N")!= NULL) && (tc_strstr(BL_FormulaEdited,"[Teamcenter]COLOUR-BOM = Y")!= NULL))
						{
							printf("\n Both [Teamcenter]COLOUR-BOM = N & [Teamcenter]COLOUR-BOM = Y are Present in Variant Formula---------------->\t\n"); fflush(stdout);
						}else
						{
							EMH_clear_errors();
							EMH_store_error_s3(EMH_severity_error,ITK_err,"Colour-related Both Options Values for COLOUR-BOM = N and COLOUR-BOM = Y are Mandatory in Variant Formula","Please Update Variant Formula for Both Options with Proper Values for Module ==>",child_rev_id);
							return ITK_errStore;
						}
					}else
					{
						EMH_clear_errors();
						EMH_store_error_s2(EMH_severity_error,ITK_err,"Colour-related Options Values for (COLOUR-BOM=>Y & N and SCHEME-NO Both Mandatory) are not mapped for the parent architecture node of this module. Please take up with the Master Data Management team to get these options populated","Only then the change in colour indicator will be allowed to proceed");
						return ITK_errStore;
					}
				}
			}
			*/
		}
	}
  	return ITK_ok;
}
int checkProjectCodeAccess(char* projCode,char* userID)
{
	int isProjectAccessisPresent = 0;

	printf("\nInside checkProjectCodeAccess, Project Code[%s] & User ID[%s]",projCode,userID); fflush(stdout);

	tag_t	qryProj= NULLTAG;
	char **qryProj_val = (char **) MEM_alloc(35 * sizeof(char *));

	int  n_entrProj = 2;
	char *qry_entrProj[2]  = {"Project ID","Id"};

	int rsltCuntProj=0;
	tag_t *ObjTag=NULLTAG;

	if(QRY_find2("ProjectUserAccessDet", &qryProj));
	if (qryProj)
	{
		printf("\n ProjectUserAccessDet:.Found Query qryProj \n");fflush(stdout);
	}
	else
	{
		printf("\n ProjectUserAccessDet:.Not Found Query qryProj \n");fflush(stdout);

	}

	qryProj_val[0] = projCode;
	qryProj_val[1] = userID;
	if(QRY_execute(qryProj, n_entrProj, qry_entrProj, qryProj_val, &rsltCuntProj, &ObjTag));
	printf(" \n Total no of Objects return ::::>>> :%d:", rsltCuntProj); fflush(stdout);

	if(rsltCuntProj>0)
	{
		isProjectAccessisPresent =1;
	}

	return isProjectAccessisPresent;
}

extern DLLAPI int  save_method_5(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);
	tag_t objTypeTag ,item_tag= NULLTAG;
	//char   type_name[TCTYPE_name_size_c+1];
	char *desid = NULL;
	char *type_name = NULL;
	char *objname = NULL;
	char *Desc = NULL;
	char *NewDesc = NULL;
	char *NewDescription = NULL;
	const char *item_name = NULL;
	char *item_name_str = NULL;
	char *object_type = NULL;
	char *ItemName = NULL;
	char *objdesc	   = NULL;
	char *objMat = NULL;
	char *objMatThickness = NULL;
	char *objOppHandDrg = NULL;
	char *objRefDrw = NULL;
	char *objSurfStd = NULL;
	double  objWeight ;
	tag_t rev=NULLTAG;
	char* item_revision_id=NULL;
	char* item_name_copy=NULL;
	int ItmNamelength = 0;
	const char *cTemp="item_id";
	WSO_description_t     desc;

	//char **val=NULL;

	int desclength = 0;
	int desccnt = 0,n_tags_found=0;

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();

	printf("\n!!!!!!!!!!!!!!!!! save_method_5:::::::::type_name[%s]\n",type_name);fflush(stdout);

	if(strcmp(type_name,"CMI2Drawing")==0)
	{
		//item_name = (char *)MEM_alloc (50 * sizeof(char));
		//if( AOM_ask_value_string(objTag,"current_name",&item_name)!=ITK_ok) PrintErrorStack();
		if( AOM_ask_value_string(objTag,"current_name",&item_name_str)!=ITK_ok) PrintErrorStack();
		if( AOM_ask_value_string(objTag,"object_type",&object_type)!=ITK_ok) PrintErrorStack();
		if( AOM_ask_value_string(objTag,"object_desc",&Desc)!=ITK_ok) PrintErrorStack();

		//ItmNamelength = strlen(item_name);
		ItmNamelength = strlen(item_name_str);
		item_name_copy = (char *)MEM_alloc (ItmNamelength * sizeof(char));
		//strcpy(item_name_copy,item_name);
		strcpy(item_name_copy,item_name_str);
		printf("\n save_method_5--item_name_copy  :%s and item_name_str :%s\n",item_name_copy,item_name_str);fflush(stdout);

		item_name=strtok(item_name_copy,"/");

		printf("\n save_method_5--item_name :%s\n",item_name);fflush(stdout);

		if(item_name)
		{
			tag_t *tags_found = NULL;
			int n_tags_found= 0;
			printf("\n save_method_5--values[0] for parent is  :%s\n",item_name);fflush(stdout);
			//if(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found) !=ITK_ok) PrintErrorStack();
			if(ITEM_find_items_by_key_attributes(1,&cTemp, &item_name, &n_tags_found, &tags_found) !=ITK_ok) PrintErrorStack();

			if (n_tags_found > 1)
			{
				MEM_free(tags_found);
				EMH_store_initial_error(EMH_severity_error,ITEM_multiple_items_returned);
				printf ("\n save_method_5--More than one items matched with id %s\n", item_name);fflush(stdout);
				exit (0);
			}
			else if (n_tags_found == 1)
			{
				printf ("\n save_method_5--only one items matched with id %s\n", item_name);fflush(stdout);

				item_tag = tags_found[0];

				if(ITEM_find_revision(item_tag,item_name,&rev)!=ITK_ok) PrintErrorStack();
				if(ITEM_ask_latest_rev(item_tag,&rev)!=ITK_ok) PrintErrorStack();

				if(rev)
				{
					if( AOM_ask_value_string(rev,"t5_Material",&objname)!=ITK_ok) PrintErrorStack();
					if( AOM_ask_value_string(rev,"object_desc",&objdesc)!=ITK_ok) PrintErrorStack();

					if( AOM_ask_value_string(rev,"t5_MThickness",&objMatThickness)!=ITK_ok) PrintErrorStack();
					if( AOM_ask_value_string(rev,"t5_OppHandDrg",&objOppHandDrg)!=ITK_ok) PrintErrorStack();
					if( AOM_ask_value_string(rev,"t5_RefDrawing",&objRefDrw)!=ITK_ok) PrintErrorStack();
					if( AOM_ask_value_string(rev,"t5_SurfPrtStd",&objSurfStd)!=ITK_ok) PrintErrorStack();
					if( AOM_ask_value_double(rev,"t5_Weight",&objWeight)!=ITK_ok) PrintErrorStack();

					//AOM_save_without_extensions(objTag);
					if( AOM_set_value_string(objTag,"t5_PartMaterial",objname)!=ITK_ok) PrintErrorStack();
					if( AOM_set_value_string(objTag,"object_desc",objdesc)!=ITK_ok) PrintErrorStack();
					if( AOM_set_value_string(objTag,"t5_MThickness",objMatThickness)!=ITK_ok) PrintErrorStack();
					if( AOM_set_value_string(objTag,"t5_OppHandDrg",objOppHandDrg)!=ITK_ok) PrintErrorStack();
					if( AOM_set_value_string(objTag,"t5_RefDrawing",objRefDrw)!=ITK_ok) PrintErrorStack();
					if( AOM_set_value_string(objTag,"t5_SurfPrtStd",objSurfStd)!=ITK_ok) PrintErrorStack();
					if( AOM_set_value_double(objTag,"t5_Weight",objWeight)!=ITK_ok) PrintErrorStack();
				}
				else
				{
					printf("\n save_method_5--Null rev tag ");fflush(stdout);
				}
			}
			else if (n_tags_found == 0)
			{
				printf ("\n save_method_5--ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", item_name);fflush(stdout);
				//exit (0);
			}
		}
	}

	return error_code;
}

//Amol
extern DLLAPI int  save_method_Vendor(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);
	tag_t objTypeTag ,item_tag= NULLTAG;
	char *username;
	tag_t user_tag=NULLTAG;
	tag_t * 	list;
	char * 	userid;
	int number_found=0;

	//char   type_name[TCTYPE_name_size_c+1];
	char *type_name	=	NULL;

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();

	printf("\n!!!!!!!!!!!!!!!!! save_method_Vendor:::::::::type_name[%s]\n",type_name);fflush(stdout);

	POM_get_user(&username,&user_tag);
	printf ("logged in user in vendor Creation :: %s\n",username);fflush(stdout);
	SA_ask_user_identifier2	(user_tag,&userid)	;
	printf ("logged in userid in vendor Creation :: %s\n",userid);fflush(stdout);

	SA_find_groupmember_by_rolename	("vendor_create","VendorCreationGroup",userid,&number_found,&list);
	printf ("number_found:: %d\n",number_found);fflush(stdout);

	if(number_found == 0)
	{
		printf ("logged in user is not in vendor creation group:: %s\n",username);fflush(stdout);

		EMH_store_error_s1(EMH_severity_error,ITK_err,"You are not allowed to create Vendor. Please contact BOM Process Team to create vendor");
		return ITK_err;
	}

	return error_code;
}

///saurabh
extern DLLAPI int  save_method_Para_Rel(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	int ifail = 0;

	tag_t objTypeTag ,item_tag= NULLTAG;
	//char   type_name[TCTYPE_name_size_c+1];
	char	*type_name	=	NULL;

	tag_t RelobjTag = va_arg(args, tag_t);
	int	isNew = va_arg(args, int);

	if (TCTYPE_ask_object_type(RelobjTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();

	printf("\n!!!!!!!!!!!!!!!!! save_method_Para_Rel:::::::::type_name[%s]  [%d] \n",type_name,isNew);fflush(stdout);

	if (isNew)
	{
		printf("\n!!!!!!!!!!!!!!!!! save_method_Para_Rel::::::::: Revise or Checkedout!!!!!!!! \n");fflush(stdout);
		return error_code;
	}

	int ii;
	int count,count1;

	tag_t	primary_object					= NULLTAG;
	tag_t	primary_obj_type_tag			= NULLTAG;
	tag_t	secondary_object				= NULLTAG;
	tag_t	secondary_obj_type_tag			= NULLTAG;

	tag_t  	rel_type;
	tag_t	*sec_objects;
	tag_t	tsk_dml_rel_type;
	tag_t	DML_rev_tag						= NULLTAG;
	tag_t	*DMLRevision					= NULL;

	//char	type_name1[WSO_name_size_c+1];
	//char	type_name2[WSO_name_size_c+1];
	char	*obj_type_name2					= NULL;
	char	*type_name1					= NULL;
	char	*type_name2					= NULL;
	char	*objectvalue1					= NULL;
	char	*objectvalue2					= NULL;
	char	*TaskDsgGrp						= NULL;
	char	*username						= NULL;
	char	*PartType						= NULL;
	char	*TskNm							= NULL;
	char	*rls_type;

	logical	check_out = 0;
	ifail=GRM_ask_primary(RelobjTag,&primary_object);
	ifail=TCTYPE_ask_object_type(primary_object,&primary_obj_type_tag);
	ifail=TCTYPE_ask_name2(primary_obj_type_tag,&type_name1);
	printf("\nECU Primary_object type_name is:%s",type_name1);fflush(stdout);

	ifail=GRM_ask_secondary(RelobjTag,&secondary_object);
	ifail=TCTYPE_ask_object_type(secondary_object,&secondary_obj_type_tag);
	ifail=TCTYPE_ask_name2(secondary_obj_type_tag,&type_name2);
	printf("\nECU secondary_object type_name is:%s",type_name2);fflush(stdout);
	POM_get_user_id (&username);
	printf("\nLogged in user:%s\n",username); fflush(stdout);

	char *SupportUsername9 = NULL;
	tag_t SessionUser9_tag=NULLTAG;
	int SupportFlag =  0;

	SupportFlag=0;
	POM_get_user(&SupportUsername9,&SessionUser9_tag);
	if(SessionUser9_tag!=NULLTAG)
	{
		SupportFlag=0;
		SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
		printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
	}

	//if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0 && tc_strcmp(username,"ercpsup") !=0) //544216261202  5442165555555/NR;2
	if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
	{
		if(tc_strcmp(type_name2,"T5_EPara") == 0 || tc_strcmp(type_name2,"T5_EParaRevision") == 0)
		{
			printf("\n*****INSIDE T5_EPara(Clause)*****\n");fflush(stdout);

			if(tc_strcmp(type_name1,"T5_EE_PartRevision") == 0)
			{
				printf("\n*****INSIDE T5_EE_PartRevision*****\n");fflush(stdout);

				char* SwPart=NULL;
				AOM_ask_value_string(primary_object,"t5_SwPartType",&SwPart);
				printf("\n*****INSIDE T5_EE_PartRevision***** <%s>\n",SwPart);fflush(stdout);

				if (tc_strcmp(SwPart,"PRM")==0)
				{
					if(RES_is_checked_out(primary_object, &check_out)!=ITK_ok) PrintErrorStack();
					printf("\n*****After RES_is_checked_out***** [%d]\n",check_out);fflush(stdout);
					if(check_out != 0)
					{
						printf("\nPart is checked-out, so Updated...!!\n");fflush(stdout);
					}
					else
					{
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Update not allowed on Checked-In Part.Please check-out the EE Part first.");
						printf("\nPlease check-out the EE Part first...!!\n");fflush(stdout);
						return ITK_err;
					}
				}
			}
		}
	}



	return error_code;
}
extern DLLAPI int  save_method_SVR(METHOD_message_t *msg, va_list args)
{

	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);
	tag_t objTypeTag ,item_tag= NULLTAG;
	//char   type_name[TCTYPE_name_size_c+1];
	char *objname = NULL;
	char *type_name = NULL;
	char *Desc = NULL;
	const char *item_name = NULL;
	char *objdesc	   = NULL;
	char *VcNos	   = NULL;
	char *Svr_Token	   = NULL;
	char *Svr_Rev	   = NULL;
	char *Svr_VC_Suffix	   = NULL;
	char *svrObjString	   = NULL;
	char* subStrProjectCode = NULL;
	char* usrInfo1			= NULL;
	char* errorMsgCCVCVal = NULL;
	int ItmNamelength = 0;
	tag_t*    status_list_SVR=NULLTAG;

	//char **val=NULL;

	int desclength = 0,st_count_SVR=0;
	int desccnt = 0,n_tags_found=0;

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();

	printf("\n!!!!!!!!!!!!!!!!! save_method_SVR:::::::::type_name[%s]\n",type_name);fflush(stdout);

	if(strcmp(type_name,"VariantRule")==0)
	{
		//object_desc
		//object_name
		if( AOM_ask_value_string(objTag,"object_name",&objname)!=ITK_ok) PrintErrorStack();
		if( AOM_ask_value_string(objTag,"object_desc",&objdesc)!=ITK_ok) PrintErrorStack();
		ItmNamelength = strlen(objname);
		printf("\n!!!!!!!!!!!!!!!!! save_method_SVR:::::::::obj_name[%s] obj_desc [%s]\n Item length%d \n",objname,objdesc,ItmNamelength);fflush(stdout);

		if (ItmNamelength > 15 )
		{
			/// 21826536000R_NR 21826536000R_A
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Please give SVR name as VC_Revision eg: 21826536000R_NR or 21826536000R_A... so on");
			return ITK_err;
		}
		else if (ItmNamelength < 14)
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Please give SVR name as VC_Revision eg: 21826536000R_NR or 21826536000R_A... so on");
			return ITK_err;
		}
		else
		{
			VcNos=subString(objname,0,12);      // "21826536000R"
			Svr_Token=subString(objname,12,1);  // "_"
			Svr_VC_Suffix=subString(objname,8,4); // "000R" or "000L"
			printf("\n save_method_SVR VcNos [%s] Svr_Token [%s]  Svr_VC_Suffix [%s]\n",VcNos,Svr_Token,Svr_VC_Suffix);fflush(stdout);
			if(strcmp(Svr_VC_Suffix,"000R") &&  strcmp(Svr_VC_Suffix,"000L") && strcmp(Svr_Token,"_") )
			{
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Please give SVR name as VC_Revision eg: 21826536000R_NR or 21826536000R_A... so on");
				return ITK_err;
			}
			if (ItmNamelength == 15)
			{

				Svr_Rev=subString(objname,13,2);
				printf("\nInside Character SVR %s\n",Svr_Rev);fflush(stdout);
				if(strcmp(Svr_Rev,"NR")  )
				{
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Please give SVR name as VC_Revision eg: 21826536000R_NR or 21826536000R_A... so on");
					return ITK_err;
				}

			}
			else if (ItmNamelength == 14)
			{
				Svr_Rev=subString(objname,13,1);
				printf("\nInside Character SVR %s %c %d\n",Svr_Rev,Svr_Rev[0],Svr_Rev[0]);fflush(stdout);
				if (Svr_Rev[0] >= 'A' && Svr_Rev[0] <= 'Z')
				{
					printf("\nInside Character SVR\n");fflush(stdout);
				}
				else
				{
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Please give SVR name as VC_Revision eg: 21826536000R_NR or 21826536000R_A... so on");
					return ITK_err;
				}
			}
		}

		desclength = strlen(objdesc);
		if (desclength > 27 )
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"SVR Description is greater than 27 character.");
			return ITK_err;
		}

		if( WSOM_ask_release_status_list(objTag,&st_count_SVR,&status_list_SVR)!=ITK_ok) PrintErrorStack();
		logical			retain							= 0;
		tag_t			primary					= NULLTAG;
		tag_t			status_rel					= NULLTAG;
		tag_t			objTypeTagDi					= NULLTAG;
		char*			WSO_Name					= NULL;
		char*			type_name3					= NULL;
		//char   type_name3[TCTYPE_name_size_c+1];
		int				cnt=0,countDep=0,k;
		tag_t  *secondary_objects1	= NULLTAG;

		printf("\n!!!!!!!!!!!!!!!!! save_method_SVR:::::::::obj_name[%s] Status count [%d]\n",objname,st_count_SVR);fflush(stdout);

		if( GRM_list_primary_objects_only(objTag,NULLTAG,&countDep,&secondary_objects1)!=ITK_ok) PrintErrorStack();
		printf("\n count found %d \n ",countDep);fflush(stdout);

			for (k=0;k<countDep;k++)
			{

				primary=secondary_objects1[k];
				if(TCTYPE_ask_object_type(primary,&objTypeTagDi)!=ITK_ok) PrintErrorStack();
				if(TCTYPE_ask_name2(objTypeTagDi,&type_name3)!=ITK_ok) PrintErrorStack();
				printf( "\n type_name3 :%s ..\n",type_name3);
			}

		if(st_count_SVR>0)
		{
			for (cnt=0;cnt< st_count_SVR;cnt++ )
			{
				if(AOM_ask_name(status_list_SVR[cnt],&WSO_Name)!=ITK_ok) PrintErrorStack();
				printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
			}
		}
		else
		{
			printf("\n count found %d \n ",countDep);fflush(stdout);
			if (countDep == 0)
			{
//				printf("\n >>>>>>>>>>>>>>>>>>>>Inside Creating ERC Review status<<<<<<<<<<<<<<<<<<\n");fflush(stdout);
//				if (RELSTAT_create_release_status("ERC Review",&status_rel)!=ITK_ok) PrintErrorStack();
//				printf("\n >>>>>>>>>>>>>>>>>>> Adding ERC Review status<<<<<<<<<<<<<<<<<<\n");fflush(stdout);
//	//			if(RELSTAT_add_release_status(status_rel,1,&objTag,retain)!=ITK_ok) PrintErrorStack();
//				if(RELSTAT_add_release_status(status_rel,1,&objTag,retain)!=ITK_ok) PrintErrorStack();
//				printf("\n >>>>>>>>>>>>>>>>>>> After ERC Review status<<<<<<<<<<<<<<<<<<\n");fflush(stdout);
			}
		}
		//Thhis is added by Kirtikumar,15-Dec-2022
		//Control Obj for On and Off Validation.
		tag_t	qry_t1_sVrVal			= NULLTAG;
		char **qry_val3_sVrVal			= (char **) MEM_alloc(100 * sizeof(char *));
		char    *qry_entr1_sVrVal[1]   = {"SYSCD"};
		int n_entr1_sVrVal				= 1;
		int rsltCunt1_sVrVal			= 0;
		tag_t *CntrlObjTag1_sVrVal		= NULLTAG;

		// To get Revision of SVR
		char data[2][50];
		char *buffer;
		int i;

		char *SVR_ID = (char *) MEM_alloc( 30 * sizeof(char) );
		char *SVR_REV = (char *) MEM_alloc( 30 * sizeof(char) );


		ITK_CALL(AOM_ask_value_string(objTag,"object_string",&svrObjString));
		printf("\n\t SVR Object String is : %s \n",svrObjString);
		//Getting project code from SVR Obj String.
		subStrProjectCode=subString(svrObjString, 0, 4);
		printf("\n\t subStrProjectCode is : %s \n",subStrProjectCode);


		buffer = strtok(svrObjString, "_");
		i = 0;
		 while (buffer != NULL) {
			strcpy(data[i], buffer);

			//printf("data[%i] = %s\n\t", i+1, data[i]);
			buffer = strtok(NULL, "_");
			i++;
		}

		tc_strcpy(SVR_ID, data[0]);
		tc_strcpy(SVR_REV, data[1]);

		printf("\n\t SVR_ID :%s", SVR_ID);
		printf("\n\t SVR_REV :%s", SVR_REV);

		if(strcmp(SVR_REV,"NR")==0)
		{
				//Control Object for Validation on and Off. And Project Code for validation.
				if(QRY_find2("ControlObjects", &qry_t1_sVrVal));
				if (qry_t1_sVrVal)
				{
					printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
				}
				qry_val3_sVrVal[0] = "CCVC/SVR Check";
				if(QRY_execute(qry_t1_sVrVal, n_entr1_sVrVal, qry_entr1_sVrVal, qry_val3_sVrVal, &rsltCunt1_sVrVal, &CntrlObjTag1_sVrVal));

				if(rsltCunt1_sVrVal>0)
				{
					ITK_CALL(AOM_ask_value_string(CntrlObjTag1_sVrVal[0],"t5_Userinfo1",&usrInfo1));
					if((tc_strstr(usrInfo1,subStrProjectCode) != NULL))
					{

							errorMsgCCVCVal=(char *)MEM_alloc(200);
							printf("After mem alloc\n");
							tc_strcpy (errorMsgCCVCVal, "SVR, ");
							//strcat(errorMsgCCVCVal,item_rev_id);
							strcat(errorMsgCCVCVal," of Project code : ");
							strcat(errorMsgCCVCVal,subStrProjectCode);
							strcat(errorMsgCCVCVal,", is not allowed to create.");
							//Not allowed give error here.
							EMH_store_error_s1(EMH_severity_error,ITK_err,errorMsgCCVCVal);
							return ITK_err;
					}
					else
					{
						printf("\n Project code is not lock. Allowed to create SVR. \n");fflush(stdout);
					}

				}
				else
				{
					printf("\n Control Object no found, Validation is OFF , this is for SVR \n");fflush(stdout);
				}
		}

	}// object type if ends

	return error_code;
}

//extern DLLAPI int  save_method_6(METHOD_message_t *msg, va_list args)
//{
//
//	int error_code = ITK_ok;
//	tag_t objTag = va_arg(args, tag_t);
//	//logical flag = va_arg(args, logical);
//	tag_t objTypeTag = NULLTAG;
//	char   type_name[TCTYPE_name_size_c+1];
//
//
//	int checked_out_user = 0;
//	//logical	checkoutp				= 0;
//
//	char *username;
//	char *cp_ChildChkOutValue = NULL;
//	char *Item_ID_str = NULL;
//	char *ischek = NULL;
//	char *Item_ID_Rev_str = NULL;
//	int    Item_ID,Item_Revision = 0;
//	tag_t user_tag=NULLTAG;
//	tag_t rev_tag=NULLTAG;
//	tag_t paritem=NULLTAG;
//	char *objecttype = NULL;
//	char *PartType = NULL;
//	int n_parents = 0;
//	int index = 0;
//	int *levels = 0;
//	tag_t *parents = NULL;
//	int	chkflg=0;
//
//	//char **val=NULL;
//
//	//int desclength = 0;
//	//int desccnt = 0,n_tags_found=0;
//
//	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
//	if (TCTYPE_ask_name2(objTypeTag,type_name)!=ITK_ok) PrintErrorStack();
//	POM_get_user(&username,&user_tag);
//
//	printf("\n!!!!!!!!!!!!!!!!! save_method_6:::::::::type_name[%s]\n",type_name);fflush(stdout);
//
//	if(strcmp(type_name,"BOMLine")==0)
//	{
//
//		//item_name = (char *)MEM_alloc (50 * sizeof(char));
//		// if(RES_is_checked_out(objTag,&checkoutp)!=ITK_ok) PrintErrorStack();
//
//			if(BOM_line_look_up_attribute ("bl_rev_checked_out",&checked_out_user)!=ITK_ok) PrintErrorStack();
//			if(BOM_line_ask_attribute_string (objTag, checked_out_user, &cp_ChildChkOutValue)!=ITK_ok) PrintErrorStack();
//
//		if(  BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision)!=ITK_ok) PrintErrorStack();
//	    if(  BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID)!=ITK_ok) PrintErrorStack();
//		if(BOM_line_ask_attribute_string(objTag, Item_ID, &Item_ID_str)!=ITK_ok) PrintErrorStack();
//		if(BOM_line_ask_attribute_string(objTag, Item_Revision, &Item_ID_Rev_str)!=ITK_ok) PrintErrorStack();
//
//		printf("\n ItemRevision is [%s] and ItemID is: [%s]\n",Item_ID_Rev_str,Item_ID_str);
//		if(ITEM_find_rev(Item_ID_str,Item_ID_Rev_str,&rev_tag)!=ITK_ok) PrintErrorStack();
//
//		if(PS_where_used_all(rev_tag,1,&n_parents,&levels,&parents)!=ITK_ok) PrintErrorStack();
//
//		if(AOM_ask_value_string(rev_tag,"object_type",&objecttype));
//		printf("\n\t object type => %s\n",objecttype);fflush(stdout);
//
//		if(AOM_ask_value_string(rev_tag,"t5_PartType",&PartType));
//		printf("\n\t PartType => %s\n",PartType);fflush(stdout);
//		printf("\n\t no of parents and levels => %d,%d\n",n_parents,levels);fflush(stdout);
//
//		if(strcmp(objecttype,"Design Revision")==0)
//		{
//
//		 if(n_parents > 0)
//				 {
//					 for( index=0; index<=1; index++)
//					 {
//                        paritem = parents[index];
//						if( AOM_ask_value_string(paritem,"checked_out",&ischek)!=ITK_ok);
//						printf("\n\t parent checkout status => %s\n",ischek);fflush(stdout);
//						if(strcmp(ischek,"Y")==0)
//						 {
//                              chkflg++;
//						 }
//					 }
//				 }
//				 printf("\n\t chkflg => %d\n",chkflg);fflush(stdout);
//
//				 if ((chkflg==0) && ((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0)))
//				{
//				EMH_store_error_s1(EMH_severity_error,ITK_err,"Parent is not checked out, so you cannot delete the child from BOM");
//				return ITK_err;
//				}
//		}
//
//
//
//	}
//
//	return error_code;
//}
//Vitthal :START: Validation on Architecture Module Revision Address and Module Address.
int BomLineModuleValidaion(tag_t tag_bomLineParent,tag_t tag_child)
{
	int   Status			 = ITK_ok;
	char *sDesModuleAddress  = NULL;
	char *sArModAddress		 = NULL;
	char *sPartType			 = NULL;
	char *sObjectTypeArch	 = NULL;
	char *sObjectTypeModule	 = NULL;
	tag_t ChildTagLatestRev	 = NULLTAG;

	if(ITEM_ask_latest_rev(tag_child,&ChildTagLatestRev));
	if((tag_bomLineParent) && (ChildTagLatestRev))
	{
		if(AOM_ask_value_string(tag_bomLineParent,"object_type",&sObjectTypeArch));
		if(AOM_ask_value_string(ChildTagLatestRev,"object_type",&sObjectTypeModule));
		if(AOM_ask_value_string(ChildTagLatestRev,"t5_PartType",&sPartType));
		printf("\n FILE NAME:BOMLineValidation.c, FUNCTION NAME:BomLineModuleValidaion(), \n sObjectTypeArch => %s\n sObjectTypeModule=>%s\n Module t5_PartType=>%s",sObjectTypeArch,sObjectTypeModule,sPartType);fflush(stdout);
		if((tc_strcmp(sObjectTypeArch,"T5_ArchModuleRevision")==0) && (tc_strcmp(sObjectTypeModule,"Design Revision")==0) &&  (tc_strcmp(sPartType,"M")==0))
		{
			if(AOM_ask_value_string(tag_bomLineParent,"t5_ArchModuleAddress",&sArModAddress));
			if(AOM_ask_value_string(ChildTagLatestRev,"t5_ModuleAddress",&sDesModuleAddress));
			printf("\nFILE NAME:BOMLineValidation.c, FUNCTION NAME:BomLineModuleValidaion(), \n t5_ArchModuleAddress => %s\n t5_ModuleAddress=>%s",sArModAddress,sDesModuleAddress);fflush(stdout);
			if(tc_strcmp(sArModAddress,sDesModuleAddress)!=0)
			{
				return 1;
			}
		}
	}
	printf("\n Architecture Module Revision Address and Module Address is same, \n t5_ArchModuleAddress => %s\n t5_ModuleAddress=>%s",sArModAddress,sDesModuleAddress);fflush(stdout);
	return 0;
}
//Vitthal :END: Validation on Architecture Module Revision Address and Module Address.
extern DLLAPI int  save_method_7(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;

	tag_t objTag = va_arg(args, tag_t);
	tag_t item_tag = va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);

	tag_t objTypeTag = NULLTAG;
	//char   type_name[TCTYPE_name_size_c+1];
	int checked_out_user = 0;
	//logical checkoutp = 0;
	char *username;
	char *cp_ChildChkOutValue = NULL;
	char *type_name = NULL;
	char *Item_ID_str = NULL;
	char *Item_ID_Rev_str = NULL;
	char *DesignGrp = "60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,54,16";
	int   Item_ID,Item_Revision = 0;
	tag_t user_tag=NULLTAG;
	tag_t rev_tag=NULLTAG;
	char *objecttype = NULL;
	char *PartType = NULL;
	char *t5_DesignGrp = NULL;
	char *ChildPartType = NULL;
	//int ItmNamelength = 0;
	//const char *cTemp="item_id";
	//WSO_description_t     desc;
	//char **val=NULL;
	//int desclength = 0;
	//int desccnt = 0,n_tags_found=0;

	//added by ajinkya on 2 march//
	char *objecttypeRight = NULL;
	tag_t ChildTagLatestRevt	 = NULLTAG;
	char *sObjectTypeModulet	 = NULL;
	char *Item_id_par=NULL;
	char *Modultyp=NULL;
	char   *ninethteenth=NULL;
	char	*designRev_id	= NULL;
	char	*roleName	= NULL;
	int item_idlength =0;
	tag_t  CurrentRoleTag = NULLTAG;
	//char roleName[SA_name_size_c+1];
	//end

	//Ashwini
	char *Item_Pcde_str = NULL;
	char *qry_entriesObs[2] = {"Name","Type"};
	char **qry_valuesObs = (char **) MEM_alloc(10 * sizeof(char *));
	char *ProjectCodeValS		= NULL;
	char *CItem_id_par			= NULL;
	char *CItem_ProjctCdeS		= NULL;
	char *CItem_DsgnGrpS		= NULL;
	char *AlternatePrtS			= NULL;
	char *ChildCpyAltS			= NULL;
	char *ChildOSPRENTS			= NULL;
	char *CPartQryLst			= NULL;
	char *CStrtngWth1			= NULL;

	char *CItem_SWparttype		= NULL;//Kalpesh(EEPart_Hardware)
	char *CItem_Prj_code		= NULL;//Kalpesh(for project code)

	char *group_name;
	tag_t group_tag=NULLTAG;

	tag_t queryTagObs		= NULLTAG;
	tag_t *NewPartsSetObs	= NULL;
	tag_t PrjCdObj			= NULLTAG;

	int n_entriesObs = 2;
	int resultCountObs =0;
	int Cpartlength =0,Item_Pcde;


	tag_t TagControlObs14 = NULLTAG,
	*cntr_objectsObs14 = NULL;
	int	n_entriesObs14 = 1;
	int n_foundObs14 = 0;
	char *qry_entriesObs14[1] = {"SYSCD"};
	char *qry_valuesObs14[1] = {"Obsolete_PrjCde_allow"};

	char	*info1		= NULL;
	char	*info2		= NULL;
	char	*info3		= NULL;
	char	*info4		= NULL;
	char	*info5		= NULL;
	char	*info6		= NULL;
	char	*info7		= NULL;
	char	*info8		= NULL;
	char	*info9		= NULL;
	char	*info10		= NULL;
	//Ashwini End.

	int ref1				=	0;
	int n_refs				=	0;
	int *n_lvls;
	int groupidflag=0;
	tag_t *refs_tag;
	char *sObjStr			=	NULL;
	char *sPrtType			=	NULL;
	char *sPartID			=	NULL;
	char **rel_char			=	NULL;
	char* Response			=	NULL ;
	char *itemId			=	NULL;
	char *ref_type_name			=	NULL;
	tag_t ref_objTypTag		=	NULLTAG;
	tag_t Ref_Item_tag		=	NULLTAG;
	//char ref_type_name[TCTYPE_name_size_c+1];

	//Aadarsh - Group id enhancement declaring variables
	tag_t RefitemId		    =	NULLTAG;
	tag_t latest_objtemId    = NULLTAG;
	tag_t bom_G    = NULLTAG;
	tag_t bom_G_revrule = NULLTAG;
	tag_t topline_bom_G = NULLTAG;
	tag_t toplinebom_G_countTAG = NULLTAG;
	tag_t *bom_G_childs = NULLTAG;
	char *objRev3			=	NULL;
	char *objitemid3			=	NULL;
	char *Gchilditemid			=	NULL;
	//char *GchilditemRev			=	NULL;
	int toplinebom_G_count=0;
	int ik=0;

	int tt2=0;
	char **childPartthree = NULL;
	childPartthree = (char**)MEM_alloc( 50 * sizeof *childPartthree );

	//neha
	tag_t t_Window1 = NULLTAG;
	tag_t t_RRule1 = NULLTAG;
	tag_t ItemTag1 = NULLTAG;
	tag_t t_TLine1 = NULLTAG;
	tag_t t_Childobject = NULLTAG;
	int ChildCount1= 0;
	int iChldPrts=0;
	int	iItemId=0;
	int n_fnd = 0;
	int n_entry = 1;
	char *cp_ItemID_str1=NULL;
	tag_t *t_PrtChldren1;
	char *Err =NULL;
	char *ctrlQryE[2]		= {"SYSCD", "SUBSYSCD"};
	char *ctrlQryV[2]		= {"PltArchM", "PltArchMM"};
	tag_t TagQryCtrlObj		= NULLTAG;
	tag_t *cntr_obj = NULLTAG;
	//char *Item_Qnty_str = NULL;//pp PravinJ
	//int Item_Qnty =0;//pp
	//neha
	char *sSwPrtTyp=NULL;

	char *childrlsstatObs	= NULL; // obsolute parts in structure General
	char *ErrorMsgOb = NULL;  // obsolute parts in structure General
	ErrorMsgOb = (char *)MEM_alloc(300);  // obsolute parts in structure General


	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
	POM_get_user(&username,&user_tag);
	POM_ask_group(&group_name, &group_tag);

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName));
	printf("\n\n  roleName1 : %s\n",roleName); fflush(stdout);

	printf("\n!!!!!!!!!!!!!!!!! save_method_7:::::::::type_name[%s]\n",type_name);fflush(stdout);
	printf("\n  Printf added for testing [%s]\n",type_name);fflush(stdout);

	if(strcmp(type_name,"BOMLine")==0)
	{
		//item_name = (char *)MEM_alloc (50 * sizeof(char));
		// if(RES_is_checked_out(objTag,&checkoutp)!=ITK_ok) PrintErrorStack();

		//if(BOM_line_look_up_attribute ("bl_rev_checked_out",&checked_out_user)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_ask_attribute_string (objTag, checked_out_user, &cp_ChildChkOutValue)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_ask_attribute_string(objTag, Item_ID, &Item_ID_str)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_ask_attribute_string(objTag, Item_Revision, &Item_ID_Rev_str)!=ITK_ok) PrintErrorStack();

		if( AOM_ask_value_string(objTag,"bl_rev_checked_out",&cp_ChildChkOutValue));
		if( AOM_ask_value_string(objTag,"bl_rev_item_revision_id",&Item_ID_Rev_str));
		if( AOM_ask_value_string(objTag,"bl_item_item_id",&Item_ID_str));

		printf("\n ItemRevision is [%s] and ItemID is: [%s]\n",Item_ID_Rev_str,Item_ID_str);
		if(ITEM_find_rev(Item_ID_str,Item_ID_Rev_str,&rev_tag)!=ITK_ok) PrintErrorStack();

		if(AOM_ask_value_string(rev_tag,"object_type",&objecttype));
		printf("\n\t object type at 1657 line **************** => %s\n",objecttype);fflush(stdout);

		if(AOM_ask_value_string(rev_tag,"t5_PartType",&PartType));
		printf("\n\t PartType => %s\n",PartType);fflush(stdout);

		if(AOM_ask_value_string(rev_tag,"t5_DesignGrp",&t5_DesignGrp));
		printf("\n\t t5_DesignGrp => %s\n",t5_DesignGrp);fflush(stdout);

		//if(BOM_line_look_up_attribute ("bl_T5_ClrPartRevision_t5_ProjectCode",&Item_Pcde)!=ITK_ok) PrintErrorStack();//Need to change attributes
		//if(BOM_line_ask_attribute_string(objTag, Item_Pcde, &Item_Pcde_str)!=ITK_ok) PrintErrorStack();

		if( AOM_ask_value_string(objTag,"bl_T5_ClrPartRevision_t5_ProjectCode",&Item_Pcde_str));
		printf("\n QtyOccur_str is----------------------------------> [%s]\n",Item_Pcde_str);

		//if(BOM_line_look_up_attribute ("bl_quantity",&Item_Qnty)!=ITK_ok) PrintErrorStack();//Need to change attributes pp PravinJ
		//if(BOM_line_ask_attribute_string(objTag, Item_Qnty, &Item_Qnty_str)!=ITK_ok) PrintErrorStack();
		//printf("\n Item_Qnty_str is----------------------------------> [%s]\n",Item_Qnty_str);


		//added in TZ 1.34
		if(AOM_ask_value_string(rev_tag,"item_id",&designRev_id));
		printf("\n\t designRev_id => %s\n",designRev_id);fflush(stdout);

		ninethteenth = subString(designRev_id, 8, 2);
		printf("\n\t 9th & 10th digit is :: [%s]\n", ninethteenth);fflush(stdout);

		item_idlength = strlen(designRev_id);
		printf("\n\t Lenght of ItemID is => %d\n",item_idlength);fflush(stdout);

		printf ("logged in user,status of BOMLine :: %s,%s\n",username,cp_ChildChkOutValue);fflush(stdout);

		if(item_tag)
		{
			// added by ajinkya on 2 march//
			if(AOM_ask_value_string(item_tag,"object_type",&objecttypeRight));
			printf("\n\t Finding Right object type => %s\n",objecttypeRight);fflush(stdout);

			//added on 20 march //
			if(ITEM_ask_latest_rev(item_tag,&ChildTagLatestRevt));
		}
		else
		{
			//Added by Prachi
			printf("\n\tinside else\n");fflush(stdout);
			ChildTagLatestRevt = va_arg(args, tag_t);
			if(ChildTagLatestRevt)
			{
				printf("\ngot ChildTagLatestRev not null\n");fflush(stdout);
			}
			else
			{
				printf("\nnull revision tag\n");fflush(stdout);
			}

		}
		if(AOM_ask_value_string(ChildTagLatestRevt,"object_type",&sObjectTypeModulet));
		printf("\n\t Added for finding latest Arch Revision => %s\n",sObjectTypeModulet);fflush(stdout);

		if(AOM_ask_value_string(ChildTagLatestRevt,"t5_PartType",&ChildPartType));
		printf("\n\t ChildPartType => %s\n",ChildPartType);fflush(stdout);

		if( AOM_ask_value_string(ChildTagLatestRevt,"item_id",&Item_id_par)!=ITK_ok);
		printf("\n  Dropping Right Object Item ID is  ---->%s \n",Item_id_par); fflush(stdout);

		/*if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0)) PravinJ
		{
			if(tc_strcmp(objecttype,"Design Revision")==0 || tc_strcmp(objecttype,"T5_SparKitRevision")==0)
			{
				printf("\n Part Found  PP \n");fflush(stdout);
				if(tc_strstr(roleName,"MBOM")!=NULL)
				{
					printf("\n Only for MBOM PP \n");fflush(stdout);
					if((tc_strcmp(ChildPartType,"CM")==0) && (tc_strcmp(Item_Qnty_str,"0")!=0))
					{
						printf("\n Inside CM ....PP \n");fflush(stdout);
						printf("\n CAD Module  is only allowed to attach under any parts with 0 Quantity  \n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"CAD Module  is only allowed to attach under any parts with 0 Quantity");
						return ITK_err;

					}
				}

			}
		}
        */

		ITK_CALL(AOM_UIF_ask_value(ChildTagLatestRevt,"release_status_list",&childrlsstatObs));
		printf("\n Released status for to be child part(right) is [%s] \n",childrlsstatObs); fflush(stdout);

		if(tc_strstr(childrlsstatObs,"Obsolete") == NULL)  //for obsolute parts in structure General
		{
		if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0))
		{
			if(tc_strcmp(objecttype,"Design Revision")==0 || tc_strcmp(objecttype,"T5_SparKitRevision")==0)
			{
				if((tc_strcmp(PartType,"CM")==0))
				{
					printf("\n Inside CM  \n");fflush(stdout);
					if(tc_strcmp(ChildPartType,"M") && tc_strcmp(ChildPartType,"D")&& tc_strcmp(ChildPartType,"DC") && tc_strcmp(ChildPartType,"DA") && tc_strcmp(ChildPartType,"IM")) //Adi for DC & DA  Part type IM added by Aadarsh kumar CR-FY25-0026
					{
						printf("\n Contextual Product can have only module or dummy parts  \n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"CAD Module should contain Module/Dummy/IFD Parts only");
						return ITK_err;
					}
				}
				// Add validation on selection group id, check child part adding to parent is not attached to other groupid.
				else if((tc_strcmp(PartType,"G")==0))
				{
					printf("\n Inside FILE NAME:tm_SaveValidationOnDsgRev.c, FUNCTION NAME:save_method_7() : Validation for Part type GroupID \n");fflush(stdout);

					int 	n_levels;
					int  	n_parents;
					int * 	levels;
					tag_t * 	parents	;
					char* GrpStrset = NULL;
					GrpStrset = (char *)MEM_alloc(50);

					//if(WSOM_where_referenced(ChildTagLatestRevt,WSO_where_ref_any_depth,&n_refs,&n_lvls,&refs_tag,&rel_char));
					if(PS_where_used_all(ChildTagLatestRevt,1,&n_parents,&levels,&parents));

					printf("\n Inside FILE NAME:tm_SaveValidationOnDsgRev.c, FUNCTION NAME:save_method_7() : n_parents: [%d]  \n",n_parents);fflush(stdout);

					if(n_parents>0)
					{
						for (ref1=0; ref1<n_parents;ref1++ )
						{
							if (TCTYPE_ask_object_type(parents[ref1],&ref_objTypTag));
							if (TCTYPE_ask_name2(ref_objTypTag,&ref_type_name));



							printf("\n Inside FILE NAME:tm_SaveValidationOnDsgRev.c, FUNCTION NAME:save_method_7() : ref1[%d]ref_type_name: [%s]\n",ref1,ref_type_name);fflush(stdout);

							if(tc_strcmp(ref_type_name,"Design Revision")==0)
							{
								if( AOM_ask_value_string(parents[ref1],"t5_PartType",&sPrtType)!=ITK_ok);
								if( AOM_ask_value_string(parents[ref1],"item_id",&itemId)!=ITK_ok);
								if( AOM_ask_value_string(parents[ref1],"object_string",&sObjStr)!=ITK_ok);
								printf("\n Inside FILE NAME:tm_SaveValidationOnDsgRev.c, FUNCTION NAME:save_method_7(): sObjStr:[%s] sPrtType [%s]\n",sObjStr,sPrtType);fflush(stdout);

								//sPartID = strtok(sObjStr,"/");

								//printf("\n\t sPartID: [%s]\n",sPartID);fflush(stdout);

								//if(ITEM_find_item(sPartID,&Ref_Item_tag));

								//if(AOM_ask_value_string(Ref_Item_tag,"t5_RevPartType",&sPrtType)!=ITK_ok);

								//if(tc_strcmp(sPrtType,"G")==0)

								printf("\n Inside FILE NAME:tm_SaveValidationOnDsgRev.c, FUNCTION NAME:save_method_7(): sPrtType:[%s] designRev_id:[%s] itemId[%s] ",sPrtType,itemId,designRev_id);fflush(stdout);

								if((tc_strcmp(itemId,designRev_id)!=0) && (tc_strcmp(sPrtType,"G")==0))
								{
										printf("\n starting the logic of Group id enhancement...");fflush(stdout);
										if(setFindStr1(&tt2,&childPartthree,itemId)==-1)
										{
											printf("---A1---");fflush(stdout);

											setAddStr(&tt2,&childPartthree,itemId);
											printf("\t Set of String [%s] ",itemId);fflush(stdout);

											if(ITEM_find_item(itemId,&RefitemId));
											if (RefitemId !=NULLTAG)
											{
												ITK_CALL(ITEM_ask_latest_rev(RefitemId,&latest_objtemId));
											    if (latest_objtemId !=NULLTAG)
												{
													ITK_CALL(AOM_ask_value_string(latest_objtemId,"item_revision_id",&objRev3));
													ITK_CALL(AOM_ask_value_string(latest_objtemId,"item_id",&objitemid3));
													printf("\n Inside FILE NAME:tm_SaveValidationOnDsgRev.c_Ada: item_revision_id -> [%s] item_id -> [%s] ",objRev3,objitemid3);fflush(stdout);
													ITK_CALL(BOM_create_window(&bom_G));
													ITK_CALL(CFM_find("Latest Working", &bom_G_revrule));
													ITK_CALL(BOM_set_window_config_rule( bom_G, bom_G_revrule));
													ITK_CALL(BOM_set_window_pack_all(bom_G, true));
													ITK_CALL(BOM_set_window_top_line(bom_G,RefitemId,latest_objtemId,NULLTAG,&topline_bom_G));
													ITK_CALL(BOM_line_ask_child_lines(topline_bom_G,&toplinebom_G_count,&bom_G_childs));
													printf("\nCount of Children present under Group %s is [%d]\n",objitemid3,toplinebom_G_count); fflush(stdout);
													if(toplinebom_G_count>0)
														{
															for (ik=0; ik<toplinebom_G_count; ik++)
															{
																Gchilditemid=NULL;
																//GchilditemRev=NULL;

																toplinebom_G_countTAG=bom_G_childs[ik];
																ITK_CALL(AOM_ask_value_string(toplinebom_G_countTAG,"bl_item_item_id",&Gchilditemid));
																//ITK_CALL(AOM_ask_value_string(toplinebom_G_countTAG,"bl_rev_item_revision_id",&GchilditemRev));
																printf("\n Group id child part [%s] and attached child part [%s]\n",Gchilditemid,Item_id_par); fflush(stdout);
																if (tc_strcmp(Gchilditemid,Item_id_par)==0)
																	{
																		groupidflag=1;
																		tc_strcpy(GrpStrset,"");
																		tc_strcat(GrpStrset, objitemid3);
																		break;

																	}
															}
														}
												}
											}
										}
								}
							}
						}
					}
					if(groupidflag==1)
					{

						printf("\n Inside FILE NAME:tm_SaveValidationOnDsgRev.c, FUNCTION NAME:save_method_7(): This Child Part %s already exists for other GroupID %s \n",Item_id_par,sObjStr);fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s4(EMH_severity_error,ITK_err,"\n This Child Part ",Item_id_par," already exists for other GroupID ",GrpStrset);
						return ITK_err;
					}
					else if(groupidflag==0)
					{
						printf("\n  check group id validation in TCE here.\n"); fflush(stdout);

						int ValCnt1=0;
						int GrpIDInICE = 0;
						tag_t*	ValCntrlObjectTag2=NULLTAG;
						tag_t qryTag2 =NULLTAG;
						char    **qry_values4     =  (char **) MEM_alloc(10 * sizeof(char *));
						int n_entry1=1;
						char    *qry_entry1[1]  = {"SYSCD"};


						if(QRY_find2("ControlObjects", &qryTag2));
						if (qryTag2)
						{
							printf("\n Found Query ControlObjects \n");fflush(stdout);
						}
						else
						{
							printf("\n Not Found Query ControlObjects \n");fflush(stdout);
						}

						qry_values4[0] = "GIDINTCE" ;
						if(QRY_execute(qryTag2, n_entry1, qry_entry1, qry_values4, &ValCnt1, &ValCntrlObjectTag2));
						printf(" \n GIDINTCE:ValCnt :%d:", ValCnt1); fflush(stdout);

						if(ValCnt1>0)
						{
							GrpIDInICE = FunToCheckGroupIDRefInICE(ValCntrlObjectTag2[0],Item_id_par,Item_ID_str);
							printf("\n  End Calling exe using system command\n"); fflush(stdout);

							if(GrpIDInICE==2)
							{
							printf("\n PART IS ATTACHED TO OTHER GROUPID IN TCE \n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_initial_error_s1(EMH_severity_error,ITK_err,"Part you are trying to attach is attached to other GroupID in TCE. Please get it loaded from PLM Team.");
							return ITK_err;
							}
							else
							{
							printf("\n Please proceed to attach part to groupID. \n");fflush(stdout);
							}
							printf("\n ------------------------Done------------- \n");fflush(stdout);
							}
						else
						{
							printf("\n\t control object GIDINTCE not found. \n");fflush(stdout);
						}
					}
				}

				///Neha-Start UA-1.77

				/*
				//Neha :CR/ERC/PLM/24/0045
				int SupportFlag			= 0;
				char *SupportUsername9	= NULL;
				tag_t SessionUser9_tag	= NULLTAG;
				//char *group_name			= NULL;
				//tag_t group_tag			= NULLTAG;
				char		*userid				= NULL;
				//char		*username			= NULL;
				//tag_t		user_tag			= NULLTAG;
				char		*rel_stat			= NULL;
				int			revstat				= 0;
				int			CtrEtry1						= 1;
				int			QryC1						= 0;
				tag_t		CtrObjQryTag1				= NULLTAG;
				tag_t		*CtrObjSet1					= NULLTAG;
				char		*QryEtry1[1]					= {"SYSCD"};
				char		**QryVal1					= (char **) MEM_alloc(100 * sizeof(char *));

				POM_get_user(&username,&user_tag);
				SA_ask_user_identifier2	(user_tag,&userid);
				printf ("\nCR_0045: Logged in user:%s %s\n",userid, username);fflush(stdout);

				POM_get_user(&SupportUsername9,&SessionUser9_tag);
				POM_ask_group(&group_name, &group_tag);

				if(SessionUser9_tag!=NULLTAG)
				{
					SupportFlag=0;
					SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
					printf("\nCR_0045: Inside SupportFlag.: %d",SupportFlag);fflush(stdout);
				}

				printf("\n CR_0045: Group name of %s : [%s] \n",SupportUsername9,group_name);fflush(stdout);

				QRY_find2("ControlObjQry", &CtrObjQryTag1);
				if (CtrObjQryTag1)
				{
					QryVal1[0] = "modifyCtl";
					QRY_execute(CtrObjQryTag1, CtrEtry1, QryEtry1, QryVal1, &QryC1, &CtrObjSet1);
				}

				printf("\n CR_0045: modifyCtl ControlObjQry : %d", QryC1);fflush(stdout);
				if(QryC1>0)
				{
					if((SupportFlag==0) && (tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (tc_strcmp(username,"aplloader")==0))
					{

						if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&revstat)!=ITK_ok) PrintErrorStack();
						if(BOM_line_ask_attribute_string(item_tag, revstat, &rel_stat)!=ITK_ok) PrintErrorStack();
						printf("\nCR_0045: Release status : [%s] \n",rel_stat);fflush(stdout);

						if((tc_strstr(rel_stat,"ERC Released") != NULL) && ((tc_strstr(group_name,"ERC_Designers_Group") != NULL) || (tc_strstr(group_name,"Vehicle_Integration") != NULL) || (tc_strstr(group_name,"Colour_Designer_Group") != NULL)))
						{
							printf("\n Part is released, structure updation is not allowed \n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
							return ITK_err;
						}
						else if(((tc_strcmp(rel_stat,"ERC Review") == 0) || (tc_strcmp(rel_stat,"ERC Working") == 0)) && (tc_strstr(group_name,"APL") != NULL))
						{
							printf("\n APL user is not allowed to update ERC review/working lifecycle state part structure \n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"APL user is not allowed to update ERC review/working part");
							return ITK_err;
						}
					}
					else
					{
							printf("\nCR_0045: [%s] user Bypassed\n",username);fflush(stdout);
					}
				}
				//CR/ERC/PLM/24/0045
				*/

				//Neha(CR-ERC-MSD-24-0003) start--CR given By Creo team Shivshankar
				int CtrEtry = 1;
				int QryC = 0;
				tag_t CtrObjQryTag = NULLTAG;
				tag_t		*CtrObjSet					= NULLTAG;
				char		*QryEtry[1]					= {"SYSCD"};
				char		**QryVal					= (char **) MEM_alloc(100 * sizeof(char *));
				tag_t		CurrRoleTag					= NULLTAG;
				//char		rolNme[SA_name_size_c+1];
				int			result = 0;
				int			n_attchs = 0;
				tag_t		tRel_ImanSpec			= NULLTAG;
				tag_t		*SecObjs				= NULLTAG;
				tag_t		*SecObjs_child			= NULLTAG;
				tag_t		t_SecObjType			= NULLTAG;
				tag_t		t_DrwDataSet			= NULLTAG;
				tag_t		*ProAsmMemberstag		= NULLTAG;
				tag_t		ProRelation_type		= NULLTAG;
				tag_t		latest_objID2			= NULLTAG;
				tag_t		latest_objrev2			= NULLTAG;
				tag_t		ProRelation_type_bulk	= NULLTAG;
				tag_t		*ProAsmMembersBulkT		= NULLTAG;
				//char		type_name1[TCTYPE_name_size_c+1] ;
				int			result2					= 0;
				int			result3					= 0;
				int			n_attch_asm				= 0;
				int			ip						= 0;
				int			i						= 0;
				int			ChildCount_c			= 0;
				int			iChPrts_c				= 0;
				int			ChildPresentInCreoFlag	= 0;
				int			CreoDatasetPresent		= 0;
				int			n_attch_bulk			= 0;
				int			po						= 0;
				char		*objTyp					= NULL;
				char		*type_name1				= NULL;
				char		*ChildPartNo			= NULL;
				char		*ChildPartNoT			= NULL;
				char		*infor1					= NULL;
				char		*ProObjName				= NULL;
				char		*ProObjId				= NULL;
				char		*ParentPartNo			= NULL;
				char		*ParentObjTyp			= NULL;
				char		*objID2					= NULL;
				char		*objRev2				= NULL;
				char		*objRev3				= NULL;
				char		*Ptyp					= NULL;
				char		*iparttype				= NULL;
				char		*rolNme					= NULL;
				char		*creoBulkStr			= NULL;
				char		*ProObjNameB			= NULL;
				//Neha(CR-ERC-MSD-24-0003) end

				creoBulkStr	= (char *)MEM_alloc(3000);
				tc_strcpy(creoBulkStr,"");
				ChildPartNoT = (char *)MEM_alloc(50);
				tc_strcpy(ChildPartNoT,"");


				//Neha(CR-ERC-MSD-24-0003) Validation for adding new part in bom if mismatch found in creo and bom

				QRY_find2("ControlObjQry", &CtrObjQryTag);
				if (CtrObjQryTag)
				{
					QryVal[0] = "CreoBomMismatch";
					QRY_execute(CtrObjQryTag, CtrEtry, QryEtry, QryVal, &QryC, &CtrObjSet);
				}
				printf("\n save_method_7--CR-24-0003: CreoBomMismatch Control object found = [%d]",QryC);fflush(stdout);

				ITKCALL(SA_ask_current_role(&CurrRoleTag));
				ITKCALL(SA_ask_role_name2(CurrRoleTag,&rolNme));
				printf("\n save_method_7--CR-24-0003: RoleName : %s\n",rolNme); fflush(stdout);

				if(QryC > 0)
				{
					printf("\n save_method_7--CR-24-0003: Inside control object CreoBomMismatch");fflush(stdout);
					ITKCALL(AOM_ask_value_string(CtrObjSet[0], "t5_Userinfo1", &infor1));
					printf("\n save_method_7--CR-24-0003: Information1 is: %s\n",infor1);fflush(stdout);

					if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0) && (tc_strstr(rolNme,"Support")==NULL))
					{
						if(AOM_ask_value_string(objTag,"bl_Design Revision_t5_PartType",&Ptyp));
						printf("\n 1. save_method_7--CR-24-0003: Parent part -> [%s] Part Type -> [%s]\n",Item_ID_str,Ptyp);fflush(stdout);

						if ((tc_strcmp(Ptyp,"A")==0) || (tc_strcmp(Ptyp,"M")==0) || (tc_strcmp(Ptyp,"CM")==0) || (tc_strcmp(Ptyp,"G")==0) || (tc_strcmp(Ptyp,"T")==0)) //CR/ERC/MSD/25/0007 - added for TPL PT
						{
							printf("\n save_method_7--CR-24-0003:Part type is Assembly/Module/TPL\n");fflush(stdout);
							if (ChildTagLatestRevt!=NULLTAG)
							{
								if(AOM_ask_value_string(ChildTagLatestRevt,"object_type",&objTyp));
								printf("\n save_method_7--CR-24-0003:Child part object Type => %s\n",objTyp);fflush(stdout);

								ITK_CALL(AOM_ask_value_string(ChildTagLatestRevt,"item_id",&ChildPartNo));
								printf("\n save_method_7--CR-24-0003: Part Number which user is going to add in BOM -> [%s]\n",ChildPartNo);fflush(stdout);

								if(AOM_ask_value_string(ChildTagLatestRevt,"t5_PartType",&iparttype));
								printf("\n save_method_7--CR-24-0003: child Part Type -> [%s]\n",iparttype);fflush(stdout);
							}

							result = GRM_find_relation_type("IMAN_specification", &tRel_ImanSpec);
							printf("\n save_method_7--CR-24-0003: IMAN_specification--GRM_find_relation_type ---->%d",result); fflush(stdout);

							if(tRel_ImanSpec)
							{
								if (objTag)
								{
									ITK_CALL(AOM_ask_value_string(objTag,"bl_item_item_id",&objID2));
									ITK_CALL(AOM_ask_value_string(objTag,"bl_rev_item_revision_id",&objRev2));

									printf("\n save_method_7--CR-24-0003:BOM line Part number and revision:[%s\t%s]",objID2,objRev2); fflush(stdout);

									ITK_CALL(ITEM_find_item(objID2,&latest_objID2));
									if (latest_objID2 !=NULLTAG)
									{
										ITK_CALL(ITEM_ask_latest_rev(latest_objID2,&latest_objrev2));

										if (latest_objrev2 !=NULLTAG)
										{
											ITK_CALL(AOM_ask_value_string(latest_objrev2,"item_revision_id",&objRev3));

											printf("\n save_method_7--CR-24-0003:-- Latest revision [%s] and BOMLine revision [%s]",objRev3,objRev2); fflush(stdout);
											printf("\n save_method_7--CR-24-0003:-- Group name [%s]",group_name);fflush(stdout);

											if (tc_strcmp(objRev2,objRev3)==0)
											{
												printf("\n save_method_7--CR-24-0003:--Both the revisions are same"); fflush(stdout);
												if(GRM_list_secondary_objects_only(latest_objrev2, tRel_ImanSpec ,&n_attchs, &SecObjs));  //parent tag=objTag
											}
											else if (tc_strstr(group_name,"ERC_Designers_Group") != NULL)
											{
												printf("\n save_method_7--CR-24-0003:Latest revision and BOMLine revision is not same"); fflush(stdout);
												EMH_clear_errors();
												EMH_store_error_s1(EMH_severity_error,ITK_err,"Latest revision of part and BOMLine revision are different, Kindly take a latest revision.");
												return ITK_err;
											}
										}
									}

									printf("\n save_method_7--CR-24-0003:--objTag n_attchs:[%d]",n_attchs); fflush(stdout);

									if(n_attchs>0)
									{
										ChildPresentInCreoFlag=0;

										for (i=0; i < n_attchs; i++)
										{
											if(TCTYPE_ask_object_type(SecObjs[i],&t_SecObjType)!=ITK_ok) PrintErrorStack();
											if(TCTYPE_ask_name2(t_SecObjType,&type_name1)!=ITK_ok) PrintErrorStack();
											printf("\n save_method_7--CR-24-0003:--Type_name:[%s]",type_name1); fflush(stdout);

											if (tc_strcmp(type_name1,"ProAsm")==0) //Creo Assembly
											{
												printf("\n save_method_7--CR-24-0003:--Inside if of ProAsm Type"); fflush(stdout);

												result2 = GRM_find_relation_type("Pro2_membership", &ProRelation_type);
												printf("\n save_method_7--CR-24-0003:--nnn..GRM_find_relation_type Pro2_membership ----> %d",result2);fflush(stdout);

												if(GRM_list_secondary_objects_only(SecObjs[i], ProRelation_type, &n_attch_asm ,&ProAsmMemberstag)!=ITK_ok) PrintErrorStack();
												printf("\n save_method_7--CR-24-0003:--ProAsmMem from ProAsm dataset:: %d\n",n_attch_asm);fflush(stdout);

												for (ip = 0; ip < n_attch_asm; ip++)
												{
													if( AOM_ask_value_string(ProAsmMemberstag[ip],"item_id",&ProObjName)!=ITK_ok) PrintErrorStack();
													if( AOM_ask_value_string(ProAsmMemberstag[ip],"item_revision_id",&ProObjId)!=ITK_ok) PrintErrorStack();
													printf("\n save_method_7--CR-24-0003:--Creo Membership parts[%s][%s] New Part[%s]",ProObjName,ProObjId,ChildPartNo); fflush(stdout);

													//if(tc_strcmp(ProObjName,ChildPartNo)==0)
													if(tc_strstr(ProObjName, ChildPartNo) != NULL) //112_1 and 112
													{
														ChildPresentInCreoFlag = 1;

														break;
													}
												}

												printf("\n save_method_7--CR-24-0003:--ChildPresentInCreoFlag Flag:[%d]",ChildPresentInCreoFlag); fflush(stdout);

												if (ChildPresentInCreoFlag==0) //Child not in Creo
												{
													CreoDatasetPresent=0;
													if(GRM_list_secondary_objects_only(ChildTagLatestRevt, tRel_ImanSpec ,&n_attchs, &SecObjs_child));  //child tag=ChildTagLatestRevt
													printf("\n save_method_7--CR-24-0003:--objTag n_attchs:[%d]",n_attchs); fflush(stdout);

													if(n_attchs>0)
													{
														for (i=0; i < n_attchs; i++)
														{
															if(TCTYPE_ask_object_type(SecObjs_child[i],&t_SecObjType));
															if(TCTYPE_ask_name2(t_SecObjType,&type_name1));
															printf("\n save_method_7--CR-24-0003:--Type_name:[%s]",type_name1); fflush(stdout);

															if ((tc_strcmp(type_name1,"ProAsm")==0)||(tc_strcmp(type_name1,"ProPrt")==0)) //Creo Assembly/Creo Part
															{
																CreoDatasetPresent=1;
																break;
															}
														}
													}

													printf("\n save_method_7--CR-24-0003:--CreoDatasetPresent Flag:[%d]",CreoDatasetPresent); fflush(stdout);

													//Check cad attached or not
													if (CreoDatasetPresent==1)
													{
														if(tc_strcmp(infor1,"ON")==0)
														{
															printf("\n save_method_7--CR-24-0003: Group name [%s]",group_name);fflush(stdout);
															printf("\n save_method_7--CR-24-0003: Part Type -> [%s]",iparttype);fflush(stdout);

															result3 = GRM_find_relation_type("Pro2_bulk", &ProRelation_type_bulk);
															if(GRM_list_secondary_objects_only(SecObjs[i], ProRelation_type_bulk, &n_attch_bulk ,&ProAsmMembersBulkT)!=ITK_ok) PrintErrorStack();
															printf("\n save_method_7--CR-24-0003:--Creo bulk membership :: %d",n_attch_bulk);fflush(stdout);

															for(po=0;po<n_attch_bulk;po++)
															{
																if( AOM_ask_value_string(ProAsmMembersBulkT[po],"object_name",&ProObjNameB)!=ITK_ok) PrintErrorStack();
																printf("\n save_method_7--CR-24-0003:--Bulk Creo Membership parts[%s] New Part [%s]",ProObjNameB,ChildPartNo); fflush(stdout);
																tc_strcat(creoBulkStr,ProObjNameB);
																tc_strcat(creoBulkStr,",");
															}

															tc_strcpy(ChildPartNoT,ChildPartNo);
															tc_strcat(ChildPartNoT,",");

															printf("\n save_method_7--CR-24-0003:--creoBulkStr [%s] \t [%s]",creoBulkStr,ChildPartNoT); fflush(stdout);


															if (((tc_strcmp(subString(ChildPartNo,8,2),"00")==0) && ((tc_strcmp(iparttype,"D")==0) || (tc_strcmp(iparttype,"Dummy")==0)
																|| (tc_strcmp(iparttype,"Info Fitment Drw")==0) || (tc_strcmp(iparttype,"IFD")==0) || (tc_strcmp(iparttype,"IM")==0)
																|| (tc_strcmp(iparttype,"IFD Module")==0)))

																||

																((tc_strcmp(subString(ChildPartNo,8,2),"04")==0) && ((tc_strcmp(iparttype,"D")==0) || (tc_strcmp(iparttype,"Dummy")==0)
																|| (tc_strcmp(iparttype,"Table Drawing")==0) || (tc_strcmp(iparttype,"TD")==0)))

																||

																(tc_strstr(ChildPartNo,"_Skel") || tc_strstr(ChildPartNo,"_skel") || tc_strstr(ChildPartNo,"_SKEL")))
															{
																// allow to add for IFD modules
																printf("\n save_method_7--CR-24-0003: IFD and Table drawing cases -> 9th & 10th digit is 00/04 & part type is IFD/Dummy/TD \n Allowing *_Skel part addition. \n");fflush(stdout);
															}
															else if (tc_strstr(creoBulkStr,ChildPartNoT)!=NULL)
															{
																printf("\n save_method_7--CR-24-0003: Part found in creo bulk membership \n");fflush(stdout);
															}
															else if(tc_strstr(group_name,"ERC_Designers_Group") != NULL)
															{
																//Error --- Do not allow to add
																printf("\n save_method_7--CR-24-0003: Creo data set available to part %s and it is not available in parent creo members\n",ChildPartNo);fflush(stdout);
																EMH_clear_errors();
																EMH_store_error_s1(EMH_severity_error,ITK_err,"Parent part creo members don't have the creo data set of newly added child parts; hence, addition in structure is not allowed.");
																return ITK_err;
															}
														}
													}
													else
													{
														// allow to add
														printf("\n save_method_7--CR-24-0003:--CreoDatasetPresent not available hence allowing case\n"); fflush(stdout);
													}
												}

												break;
											}
										}
									}
								}
							}
						}
						else
						{
							printf("\n save_method_7--CR-24-0003:Inside else of part type other than Assembly/Module/TPL\n");fflush(stdout);
						}
					}
					else
					{
						printf("\n save_method_7--CR-24-0003:--BYPASS Adding new part in bom if mismatch found in creo and bom Validaion for infodba and loader Login\t Cureent Login:%s\n",username);fflush(stdout);
					}
				}
				//Neha (CR-ERC-MSD-24-0003) End UA-1.77
			}
			if(tc_strcmp(objecttype,"T5_PlatformRevision")==0)
			{
				printf("\n\t Inside the left object at ------------------->>>>>>>>=> %s\n",objecttype);fflush(stdout);

				//Neha(CR-FY23-0166)
				if(QRY_find2("ControlObjQry", &TagQryCtrlObj));
				if(QRY_execute(TagQryCtrlObj, n_entry, ctrlQryE, ctrlQryV, &n_fnd, &cntr_obj));
				printf("\n PltArchM control object nfound variable size == %d", n_fnd);fflush(stdout);

				if(n_fnd>0)
				{

					if((tc_strcmp(sObjectTypeModulet,"T5_ArchModuleRevision")==0))
					{
							if(BOM_create_window (&t_Window1) !=ITK_ok) PrintErrorStack();
							if(CFM_find( "Latest Working", &t_RRule1 )!=ITK_ok) PrintErrorStack();
							if(BOM_set_window_config_rule( t_Window1, t_RRule1 )!=ITK_ok) PrintErrorStack();
							if(BOM_set_window_pack_all (t_Window1, true)!=ITK_ok) PrintErrorStack();
							if(BOM_set_window_top_line (t_Window1, ItemTag1, rev_tag, null_tag, &t_TLine1)!=ITK_ok) PrintErrorStack();
							if(BOM_line_ask_child_lines (t_TLine1, &ChildCount1, &t_PrtChldren1)!=ITK_ok) PrintErrorStack();
							printf("\nChild Parts Found in BomLine are :: [%d]\n",ChildCount1);fflush(stdout);

							if((ChildCount1 > 0))
							{
								for (iChldPrts = 0; iChldPrts < ChildCount1; iChldPrts++)
								{
									if(t_Childobject) t_Childobject=NULLTAG;
									t_Childobject=t_PrtChldren1[iChldPrts];

									//if(BOM_line_look_up_attribute ("bl_item_item_id",&iItemId));
									//if(BOM_line_ask_attribute_string(t_Childobject, iItemId, &cp_ItemID_str1));

									if( AOM_ask_value_string(t_Childobject,"bl_item_item_id",&cp_ItemID_str1));
									printf("\n ItemID_is -> [%s]\n",cp_ItemID_str1);

									if(tc_strcmp(Item_id_par,cp_ItemID_str1)==0)
									{
										printf("\n Same architecture module found \n");fflush(stdout);
										Err	=	NULL;
										Err	=	(char *)MEM_alloc(200);
										tc_strcpy(Err,"");
										tc_strcat(Err,Item_id_par);
										tc_strcat(Err,":");
										tc_strcat(Err,"architecture module are already attached to Platform");
										tc_strcat(Err,".Kindly check.");

										printf("\nErr %s",Err); fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err,Err);
										return ITK_errStore;
									}
								}
							}
					}
				}

			 //if(tc_strcmp(objecttypeRight,"T5_ArchModule")!=0)
			 if((tc_strcmp(sObjectTypeModulet,"T5_ArchModuleRevision")!=0))
				{
					printf("\n Inside the error -Platform shall have only Architecture Modules as immediate child \n");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,"\n Platform shall have only Architecture Modules as immediate child");
					//EMH_store_error_s1(EMH_severity_error,ITK_err,"Child parts can't be added to Checked-in/ERC Review part");
					return ITK_err;
				}
				//Added by kalpesh(13-Jun-19)
				else
				{
					//if(tc_strcmp(sObjectTypeModulet,"T5_ArchModuleRevision") == 0 && tc_strcmp(username, "su_mdm") == 0)
					if(tc_strcmp(sObjectTypeModulet,"T5_ArchModuleRevision") == 0 && tc_strcmp(group_name, "Master_Data_Mgmt") == 0)
					{
					}
					else
					{
						printf("\nOnly user having Group (Master_Data_Mgmt) can attach Architecture Modules to Platform BOM Structure.\n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"\nOnly user having Group (Master_Data_Mgmt)can attach Architecture Modules to Platform BOM Structure.");
						//EMH_store_error_s1(EMH_severity_error,ITK_err,"Child parts can't be added to Checked-in/ERC Review part");
						return ITK_err;
					}
				}//End
			}
		}
		}
		else
		{
			tc_strcpy(ErrorMsgOb,"");
			tc_strcat(ErrorMsgOb,"Part Number [");
			tc_strcat(ErrorMsgOb,Item_id_par);
			tc_strcat(ErrorMsgOb,"] is Obsoluted. It should not be added in structure.");


			printf("\n Error for obsolute part addition in Structure ErrorMsgOb: [%s]",ErrorMsgOb);fflush(stdout);

			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_errStore,ErrorMsgOb);
			return ITK_err;
		}
		//Ashwini - Check Obsolete Part and Give Hard check..
		if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0))
		{
			printf("\nUses Parts Starts................................................\n");fflush(stdout);
			printf("\n QtyOccur_str is----------------------------------> [%s]\n",Item_Pcde_str);
			if(QRY_find2("Item...", &queryTagObs));
			if (queryTagObs)
			{
				printf("\nGeneral... Found Query ControlObjects ");
				fflush(stdout);
			}
			else
			{
				printf("\n General...:Not Found Query ControlObjects \n");
				fflush(stdout);
			}
			qry_valuesObs[0] = Item_Pcde_str ;
			qry_valuesObs[1] = "Project" ;

			if(QRY_execute(queryTagObs,n_entriesObs,qry_entriesObs,qry_valuesObs,&resultCountObs,&NewPartsSetObs));
			printf("\n11 Unique General... Query resultCount :%d:\n", resultCountObs); fflush(stdout);

			if (resultCountObs > 0)
			{
				PrjCdObj = NewPartsSetObs[0];
				if(AOM_ask_value_string(PrjCdObj,"t5_BussUnitType",&ProjectCodeValS) != ITK_ok);
				printf("\nIN function QueryProject t5_BussUnitType = %s..\n",ProjectCodeValS);fflush(stdout);
			}
			//Query Project
			//Child
			if(tc_strcmp(ProjectCodeValS,"PCBU") == 0)
			{
				if(AOM_ask_value_string(ChildTagLatestRevt,"item_id",&CItem_id_par)!=ITK_ok);
				printf("\n  Dropping Right Object Item ID is  ---->%s \n",CItem_id_par); fflush(stdout);

				if(AOM_ask_value_string(ChildTagLatestRevt,"t5_ProjectCode",&CItem_ProjctCdeS)!=ITK_ok);
				printf("\n  Dropping Right Object Item ID is  ---->%s \n",CItem_ProjctCdeS); fflush(stdout);

				if(AOM_ask_value_string(ChildTagLatestRevt,"t5_DesignGrp",&CItem_DsgnGrpS)!=ITK_ok);
				printf("\n  Dropping Right Object Item ID is  ---->%s \n",CItem_DsgnGrpS); fflush(stdout);

				CStrtngWth1=subString(CItem_id_par,0,1);
				Cpartlength = tc_strlen(CItem_id_par);

				if(Cpartlength == 11 && tc_strcmp(CItem_DsgnGrpS,"11")==0 && tc_strcmp(CItem_ProjctCdeS,"1111")==0 && tc_strcmp(CStrtngWth1,"1")==0)
				{

					if(QRY_find2("ControlObjQry", &TagControlObs14));
					if(QRY_execute(TagControlObs14, n_entriesObs14, qry_entriesObs14, qry_valuesObs14, &n_foundObs14, &cntr_objectsObs14));
					printf("\n Project Code Control Object found == %d\n", n_foundObs14);fflush(stdout);

					if(n_foundObs14==1)
					{
						if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo1",&info1)!=ITK_ok) PrintErrorStack();	//Design Group
						printf("\nBypass Design  Group List [%s] and project code = %s",info1,Item_Pcde_str); fflush(stdout);
						if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo2",&info2)!=ITK_ok) PrintErrorStack();
						printf("\n info2 is.:[%s] and Project code = %s\n", info2,Item_Pcde_str);fflush(stdout);
						if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo3",&info3)!=ITK_ok) PrintErrorStack();
						printf("\n info3 is.:[%s] and project code = %s\n", info3,Item_Pcde_str);fflush(stdout);
						if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo4",&info4)!=ITK_ok) PrintErrorStack();
						printf("\n info4 is.:[%s] and Project code = %s\n", info4,Item_Pcde_str);fflush(stdout);
						if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo5",&info5)!=ITK_ok) PrintErrorStack();
						printf("\n info5 is.:[%s] and project code = %s\n", info5,Item_Pcde_str);fflush(stdout);
						if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo6",&info6)!=ITK_ok) PrintErrorStack();
						printf("\n info6 is.:[%s] and project code = %s\n", info6,Item_Pcde_str);fflush(stdout);
						if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo7",&info7)!=ITK_ok) PrintErrorStack();
						printf("\n info7 is.:[%s] and project code = %s\n", info7,Item_Pcde_str);fflush(stdout);
						if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo8",&info8)!=ITK_ok) PrintErrorStack();
						printf("\n info8 is.:[%s] and project code = %s\n", info8,Item_Pcde_str);fflush(stdout);
						if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo9",&info9)!=ITK_ok) PrintErrorStack();
						printf("\n info9 is.:[%s] and project code = %s\n", info9,Item_Pcde_str);fflush(stdout);

						if((tc_strstr(info1,Item_Pcde_str)!=NULL) || (tc_strstr(info2,Item_Pcde_str)!=NULL) || (tc_strstr(info3,Item_Pcde_str)!=NULL) || (tc_strstr(info4,Item_Pcde_str)!=NULL) || (tc_strstr(info5,Item_Pcde_str)!=NULL) || (tc_strstr(info6,Item_Pcde_str)!=NULL) || (tc_strstr(info7,Item_Pcde_str)!=NULL) || (tc_strstr(info8,Item_Pcde_str)!=NULL) || (tc_strstr(info9,Item_Pcde_str)!=NULL))
						{
							printf("\n%s Project code present in Control object \n",Item_Pcde_str);fflush(stdout);
							//}
							//if(tc_strcmp(Item_Pcde_str,"5438")==0)
							//{//Start
							printf("\n123 Extension of Fasteners related check for Nexon to TcUA - 5438 project\n"); //

							ChildOSPRENTS=(char *) MEM_alloc(850);
							printf("\nProject PCBU Obsolete Uses Parts..\n");fflush(stdout);
							tc_strcpy(ChildOSPRENTS,"");
							strcat(ChildOSPRENTS,"----Below List of fasteners used from outside the list----\nPlease note that check-in in PLM will be unsuccessful if the 11-digit standard fasteners are not in line with the list of fasteners maintained specifically for Nexon project.For any requirement beyond this list, a DCR needs to be raised. \n'Query--->Cntrl_t5ObmPrt_OSPRY---> Alt Part Ind = OSPREY and Obsolte Part =ChildPart Number' ");

							printf("\nPart is OBSOLETE Do check-in....\n");fflush(stdout);
							AlternatePrtS=QueryObsPartOSPREY_Uses(CItem_id_par);
							printf("\nAlternatePrtS = %s\n",AlternatePrtS);fflush(stdout);
							if(strcmp(AlternatePrtS,"OSPREYPresnt")==0)
							{
								printf("\nOSPREY present in table allow Uses parts Creation.....\n");fflush(stdout);
							}
							else
							{
								if(strcmp(AlternatePrtS,"OSPREYNTPresnt")==0)
								{
									printf("\n%s OSPREY NOT Present %s\n",CItem_id_par,AlternatePrtS);
									strcat(ChildOSPRENTS,CItem_id_par );
									strcat(ChildOSPRENTS,",");
									EMH_store_error_s1(EMH_severity_error,ITK_err,ChildOSPRENTS);
									return ITK_err;
								}
							}
						}
					}
					ChildCpyAltS=(char *) MEM_alloc(650);
					CPartQryLst=(char *) MEM_alloc(650);
					printf("\nProject PCBU Obsolete Check-in..\n");fflush(stdout);
					tc_strcpy(ChildCpyAltS,"");
					strcat(ChildCpyAltS,"This part is hexavalent Cr-coated and can not be used. You may use the suggested alternate in its place ");

					tc_strcpy(CPartQryLst,"");
					strcat(CPartQryLst,"This part is hexavalent Cr-coated. You can not use it in your structure definition ");

					printf("\nChild Name Lenght = %d and Child Part starts with = %s\n",Cpartlength,CStrtngWth1);
					//if(Cpartlength == 13 && tc_strcmp(CItem_DsgnGrpS,"16")==0 && tc_strcmp(CItem_ProjctCdeS,"5442")==0)
				//if(Cpartlength == 11 && tc_strcmp(CItem_DsgnGrpS,"11")==0 && tc_strcmp(CItem_ProjctCdeS,"1111")==0 && tc_strcmp(CStrtngWth1,"1")==0)
				//{
					printf("\nPart is OBSOLETE Do check-in....\n");fflush(stdout);
					AlternatePrtS=QueryObsPart_Uses(CItem_id_par);
					printf("\nAlternatePrtS = %s\n",AlternatePrtS);fflush(stdout);
					if(strcmp(AlternatePrtS,"PrtDelete")==0)
					{
						printf("\n%s have Alternate Part PrtDelete %s\n",CItem_id_par,AlternatePrtS);
						strcat(CPartQryLst,CItem_id_par);
						strcat(CPartQryLst,"," );
						EMH_store_error_s1(EMH_severity_error,ITK_err,CPartQryLst);
						return ITK_err;
					}
					if(strcmp(AlternatePrtS,"PrtDelete") != 0)
					{
						if(strcmp(AlternatePrtS,"QryNotFound")!=0 && (tc_strlen(AlternatePrtS)!=0))
						{
							printf("\n%s have Alternate Part %s\n",CItem_id_par,AlternatePrtS);
							strcat(ChildCpyAltS,CItem_id_par );
							strcat(ChildCpyAltS,"--->" );
							strcat(ChildCpyAltS,AlternatePrtS);
							EMH_store_error_s1(EMH_severity_error,ITK_err,ChildCpyAltS);
							return ITK_err;
						}
					}
					//}
				//}
				}
			}
			printf("\nUses Parts ENDS.........................................................\n");fflush(stdout);
		}

		//Added by kalpesh(21st_June_2018)//Modified_23rd_june19(IFD Module)//Modified_25_july19(T5_ClrPartRevision)
		//Modified_28_Aug19(ECU Module)

		if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0))
		{
			if(tc_strcmp(objecttype,"T5_ArchModuleRevision")==0)
			{
				printf("\n\t Inside the left object at ------------------->>>>>>>>=> %s\n",objecttype);fflush(stdout);

				char* child_type = NULL;
				if(AOM_UIF_ask_value(ChildTagLatestRevt,"t5_PartType",&child_type));
				printf("\n\t ChildPartType => %s sObjectTypeModulet => %s\n",child_type,sObjectTypeModulet);fflush(stdout);

				if(tc_strcmp(sObjectTypeModulet,"Design Revision") == 0 || tc_strcmp(sObjectTypeModulet,"T5_ClrPartRevision") == 0)
				{
					if((tc_strcmp(child_type, "Module") == 0) || (tc_strcmp(child_type, "IFD Module") == 0) || (tc_strcmp(child_type, "ECU Module") == 0) || (tc_strcmp(child_type, "CAD Module") == 0))
					{
						if(AOM_ask_value_string(ChildTagLatestRevt,"t5_ModuleType",&Modultyp)!=ITK_ok) PrintErrorStack();
						printf("\n dorping Modultyp:%s ...\n",Modultyp);fflush(stdout);
						//below DFA-M validation reverted in sept 2018.
						/*if(tc_strcmp(Modultyp,"")!=0)
						{
							if(tc_strcmp(Modultyp,"DFM-A")==0)
							{
								printf("\n Inside error for DFM-A. \n");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,"\n DFM-A modules cannot be added under Architecture Modules as immediate child.");
								return ITK_err;
							}
						}*/
					}
					else
					{
						if(tc_strcmp(sObjectTypeModulet,"T5_ClrPartRevision") == 0)
						{
						}
						else
						{
							printf("\nArch_Module Rev. should have only Module,IFD Module,ECU Module and color part as immediate child.\n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err, "Only Module,IFD Module,ECU Module and color part can be attached to Arch Module as immediate child");
							return ITK_err;
						}
					}
				}
				else
				{
					printf("\nArch_Module Rev. should have only Module,IFD Module,ECU Module and color part as immediate child.\n");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err, "Only Module,IFD Module,ECU Module and color part can be attached to Arch Module as immediate child");
					return ITK_err;
				}
			}
		}

		//ECU Module Validation(24_oct2019)//Kalpesh
		if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0))
		{
			//Only EE Parts should get attached under ECU Module
			printf("\nChild_Object_Type:%s", sObjectTypeModulet);
			if(tc_strcmp(sObjectTypeModulet,"T5_EE_PartRevision") == 0)
			{
				if(AOM_ask_value_string(ChildTagLatestRevt,"t5_ProjectCode",&CItem_Prj_code)!=ITK_ok);
				printf("\n EE Part project_code is---->%s \n",CItem_Prj_code); fflush(stdout);
				if(tc_strcmp(CItem_Prj_code,"9002") == 0 || tc_strcmp(CItem_Prj_code,"9011") == 0)
				{
					printf("\nEE Part is bypassed for project code(9002 & 9011)...!!\n");
				}
				else
				{
					if(tc_strcmp(objecttype,"Design Revision") == 0)
					{
						printf("\nParent_Object_Type:%s\n Parent_Part_Type:%s\n",objecttype, PartType);fflush(stdout);
						if((tc_strcmp(PartType,"EM") == 0) || (tc_strcmp(PartType,"T") == 0))
						{
							printf("\nEE Part got attached under ECU Module\n");
						}
						else
						{
							//Modified on (20-Dec-2019) for bypassing hardware parts.

							if(AOM_ask_value_string(ChildTagLatestRevt,"t5_DesignGrp",&CItem_DsgnGrpS)!=ITK_ok);
							printf("\n EE Part design_group is  ---->%s \n",CItem_DsgnGrpS); fflush(stdout);

							if(tc_strcmp(CItem_DsgnGrpS, "16") == 0)
							{
								if(AOM_ask_value_string(ChildTagLatestRevt,"t5_SwPartType",&CItem_SWparttype)!=ITK_ok);
								printf("\n EE Part SW_parttype---->%s \n",CItem_SWparttype); fflush(stdout);

								if(tc_strcmp(CItem_SWparttype, "HWC") == 0 || tc_strcmp(CItem_SWparttype, "CON") == 0)//Modified for bypassing Container parts.(18th_june2020)
								{
									printf("\nHardware parts and Container parts are bypassed.\n");
								}
								else
								{
									printf("\nEE parts should be attached under ECU Module only.\n");fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err, "EE parts should be attached under ECU Module only.");
									return ITK_err;
								}
							}
						}
					}
				}
			}
			//Only EE Parts should get attached under EE Part
			if(tc_strcmp(objecttype,"T5_EE_PartRevision") == 0)
			{
				printf("\nInside parent part(EE_Part_Revision)...!!");
				printf("\nParent Object Type:%s",objecttype);fflush(stdout);
				printf("\nChild Object Type:%s", sObjectTypeModulet);
				if(tc_strcmp(sObjectTypeModulet,"T5_EE_PartRevision") == 0)
				{
					printf("\nEE Part got attached under EE Part\n");
				}
				else
				{
					if(AOM_ask_value_string(ChildTagLatestRevt,"t5_ProjectCode",&CItem_Prj_code)!=ITK_ok);
					printf("\n EE Part project_code is---->%s \n",CItem_Prj_code); fflush(stdout);
					ITK_CALL( AOM_ask_value_string(rev_tag,"t5_SwPartType",&sSwPrtTyp));
					printf("\n EE Part sSwPrtTyp is---->%s \n",sSwPrtTyp); fflush(stdout);
					if(tc_strcmp(CItem_Prj_code,"9002") == 0 || tc_strcmp(CItem_Prj_code,"9011") == 0 || tc_strcmp(sSwPrtTyp,"HWC") ==0)
					{
						printf("\nEE Part is bypassed for project code(9002 & 9011) and hardware...!!\n");
					}
					else
					{
						printf("\nEE Parts should have only EE Part as immediate child.\n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err, "EE Parts should have only EE Part as immediate child.");
						return ITK_err;
					}
				}
			}
		}
		//Kalpesh(End of ECU Module validation)
             	/// Starts Added By Nana to Restrict Quick Add Button

						tag_t   CntobjQKAddVld		=	NULLTAG;

						char    *qry_QKaddVld_entry[2]	=	{"SYSCD","SUBSYSCD"};
						char    **qry_QKaddVld_values    =  (char **) MEM_alloc(10 * sizeof(char *));
						int     QKaddVld_entry				=	2;
						int		QKaddVldCntlObj			=	0;
						tag_t   *QKaddVldCntrlObj_Tags    =	NULLTAG;

						if(QRY_find2("Control Objects...", &CntobjQKAddVld));
						if (CntobjQKAddVld)
						{
							printf("\n Found Query ControlObjects for Quick Add Button validation \n");fflush(stdout);
						}
						else
						{
							printf("\n Not Found Query ControlObjects for Quick Add Button validation  \n");fflush(stdout);
						}

						qry_QKaddVld_values[0] = "QuickAddCntrl";
						qry_QKaddVld_values[1] = "QKAddCntrobj";
						if(QRY_execute(CntobjQKAddVld, QKaddVld_entry, qry_QKaddVld_entry, qry_QKaddVld_values, &QKaddVldCntlObj, &QKaddVldCntrlObj_Tags));
						printf(" \n Quick Add Button validation:QKaddVldCntlObj:[%d]",QKaddVldCntlObj); fflush(stdout);
						int iLCS,cntLcs=0;
						int st_count=0;
						 char* class_name=NULL;
						 tag_t *status_list=NULLTAG;

						if (QKaddVldCntlObj>0)
						{
									ITKCALL(WSOM_ask_release_status_list(rev_tag,&st_count,&status_list));
								    printf("\n st_count :%d is\n",st_count);fflush(stdout);

						 for (iLCS=0;iLCS<st_count ;iLCS++ )
							{

									ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
									printf("\n class_name: %s\n",class_name);fflush(stdout);

									if(tc_strcmp(class_name,"T5_LcsErcRlzd")!=0) //TZ3.46
										{

											if (tc_strstr(class_name,"Rlzd")!=NULL)
											{
												cntLcs++;
												printf("\n REls count flag :%d is\n",cntLcs);fflush(stdout);

											}

											//break;
										}

							}
						}

						/// ENd Added By Nana to Restrict Quick Add Button

		ITKCALL(SA_ask_current_role(&CurrentRoleTag));
		ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName));
		printf("\n\n  roleName1 : %s\n",roleName); fflush(stdout);


				//Addition by Rohit Bhosale Starts for CR-FY23-0184 :

		printf("\nInside BOM Validation by Rohit Before declaration\n");	fflush(stdout);

		tag_t cvprod_CntrlOBJ		=	NULLTAG;
		tag_t *CntrlObject_cvprod	=	NULLTAG;
		tag_t *refs_bomtag			=	NULLTAG;
		tag_t *referencersV			=	NULLTAG;
		tag_t *referencersC			=	NULLTAG;
		tag_t class_idV				=	NULLTAG;
		tag_t class_idC				=	NULLTAG;
		tag_t user_tagR				=	NULLTAG;
		tag_t PGmrelation_type		=	NULLTAG;
		tag_t *secondary_Pobjects	=	NULLTAG;
		tag_t PDML_tag				=	NULLTAG;
		tag_t DMLtaskTag			=	NULLTAG;
		tag_t DMLRevTag1			=	NULLTAG;
		tag_t PDMLTypeTag			=	NULLTAG;
		tag_t latest_parentID		=	NULLTAG; //Rohit BOM
		tag_t latest_revV			=	NULLTAG; //Rohit BOM
		tag_t bom_cv				=	NULLTAG; //Rohit BOM
		tag_t cv_revrule			=	NULLTAG; //Rohit BOM
		tag_t topline_cvbom			=	NULLTAG; //Rohit BOM
		tag_t *cvbom_childs			=	NULLTAG; //Rohit BOM
		tag_t cv_childtag			=	NULLTAG; //Rohit BOM


		int cvprod_entries			=	1;
		int	cvprod_found			=	0;
		int jcv						=	0;
		int n_bomrefs				=	0;
		int *n_bomlvls				=	0;
		int n_bomlevels				;
		int sv						=	0;
		int n_referencersV			=   0;
		int n_referencersC			=   0;
		int *levelsV				=	0;
		int *levelsC				=	0;
		int flag1					=	0;
		int sc						=	0;
		int flagDMLattach			=	0;
		int Pn_attchs				=   0;
		int lt						=	0;
		int toplinecvbom_count		=	0;	//Rohit BOM
		int	CVC						=	0;	//Rohit BOM
		int cvchildline_ID			=	0;	//Rohit BOM
		int cvchildline_rev			=	0;  //Rohit BOM
		int cvchildline_designgrp	=	0;	//Rohit BOM
		int cvchildline_modules_addrs	=	0;	//Rohit BOM

		char	*info1cv			=	NULL;
		char	*cvchild			=	NULL;
		char	*dmlownerparent		=	NULL;
		char	*dmlownerchild		=	NULL;
		char	*cvchilddsggrp		=	NULL;
		char	*module_addrs		=	NULL;
		char	*taskTempLTV		=	NULL;
		char	**referenced_char	=	NULL;
		char	*class_nameV		=	NULL;
		char	*class_nameC		=	NULL;
		char	*MPartNoV			=	NULL;
		char	*MPartNoC			=	NULL;
		char	*ItemIDV			=	NULL;
		char	*ItemIDC			=	NULL;
		char    **relationsRefV		=	NULL;
		char    **relationsRefC		=	NULL;
		char    *usernameR			=	NULL;
		char	*DmlAnalyst_name	=	NULL;
		char	*useridR			=	NULL;
		char	*vrlsstatus			=   NULL;
		char	*PartRelStatusC		=	NULL;
		char	*childrlsstat		=	NULL;
		char  allclsname[4900]		= { 0 };
		char *qry_cvprodcntrl[1]	= {"SYSCD"};
		char **qry_valuescvprod		= (char **) MEM_alloc(10 * sizeof(char *));
		qry_valuescvprod[0]			= "CVBUBOMCntrlObj";
		char	*TokDMLId			=	NULL;
		char	*DMLItem_id			=	NULL;
		char	*task_id			=	NULL;
		char	*DMLtaskID			=	NULL;
		char	*value				=	NULL;
		DMLtaskID=(char *)MEM_alloc(3000);
		char	*all_tasks			=	NULL;
		char PDMLtype_name[TCTYPE_name_size_c+1];

		char *parentID				=	NULL; //Rohit BOM
		char *parentrevID			=	NULL; //Rohit BOM
		char *latest_parentIDstr	=	NULL; //Rohit BOM
		char *latest_revVstr		=	NULL; //Rohit BOM
		char *cv_ItemID_str			=	NULL; //Rohit BOM
		char *cv_ItemRev_str		=	NULL; //Rohit BOM
		char *cv_designgrp_str		=	NULL; //Rohit BOM
		char *cv_modaddrs_str		=	NULL; //Rohit BOM
		char alldsggrp[1900]		=	{ 0 }; //Rohit BOM

		char *ErrorMsgF = NULL;	//Rohit BOM
		ErrorMsgF = (char *)MEM_alloc(500);	//Rohit BOM


		printf("\nInside BOM Validation by Rohit After declaration\n");	fflush(stdout); //rev_tag
		ITK_CALL(QRY_find2("Control Objects...",&cvprod_CntrlOBJ));
		//printf("\n\n CVBUBOMCntrlObj Query Found\n\n");	fflush(stdout);


		ITK_CALL(QRY_execute(cvprod_CntrlOBJ, cvprod_entries, qry_cvprodcntrl, qry_valuescvprod, &cvprod_found, &CntrlObject_cvprod));
		printf("\n\n  CVBUBOMCntrlObj Control Object SYSCD :%d\n",cvprod_found);	fflush(stdout);

		if(cvprod_found > 0)
		{
			ITK_CALL(AOM_UIF_ask_value(rev_tag,"release_status_list",&vrlsstatus));
			printf("\n Released status for parent is [%s] \n",vrlsstatus); fflush(stdout);
			if((tc_strcmp(cp_ChildChkOutValue,"Y")!=0) ||((tc_strcmp(PartType,"V")==0) && (tc_strcmp(vrlsstatus,"ERC Working") == 0)))
			{
				if (	((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0)) &&
					(tc_strstr(roleName,"STD")==NULL) &&
					(tc_strstr(roleName,"APL")==NULL) &&
					(tc_strstr(roleName,"MBOM")==NULL) &&
					(tc_strstr(roleName,"Support")==NULL)
				) //MBOM implementation for CV TZ-1.70 Backend Fixes
				{
					POM_get_user(&usernameR,&user_tagR);
					SA_ask_user_identifier2	(user_tagR,&useridR);

					printf ("Logged in user for Vehicle attaching functinality : [%s] [%s]\n",useridR,usernameR);fflush(stdout);
					printf("Role Name for the logged in user is [%s]",roleName);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(CntrlObject_cvprod[0],"t5_Userinfo1",&info1cv));
					printf("\n\nUser Information 1 is : %s",info1cv);	fflush(stdout);

/* 					ITK_CALL(AOM_UIF_ask_value(rev_tag,"release_status_list",&vrlsstatus));
					printf("\n Released status for parent is [%s] \n",vrlsstatus); fflush(stdout); */

					ITK_CALL(AOM_UIF_ask_value(rev_tag,"item_id",&parentID)); //Rohit BOM
					ITK_CALL(AOM_UIF_ask_value(rev_tag,"item_revision_id",&parentrevID)); //Rohit BOM

					ITK_CALL(ITEM_find_item(parentID,&latest_parentID)); //Rohit BOM
					ITK_CALL(ITEM_ask_latest_rev(latest_parentID,&latest_revV)); //Rohit BOM

					ITK_CALL(AOM_ask_value_string(latest_parentID,"item_id",&latest_parentIDstr)); //Rohit BOM
					ITK_CALL(AOM_ask_value_string(latest_revV,"item_revision_id",&latest_revVstr)); //Rohit BOM

					printf("\n Parent ID and Rev ID is [%s] and [%s] \n",latest_parentIDstr,latest_revVstr); fflush(stdout); //Rohit BOM

					if ((tc_strcmp(PartType,"V")==0) && (tc_strcmp(vrlsstatus,"ERC Working") == 0))
					{
						printf("\nAddition of part in Vehicle is successful when checked out\n"); fflush(stdout);
						//CR:CR-FY26-0065  call BOMTypeValidateStampFun function for TCUA 1.84 Backend
						printf("\n save_method_7--Before calling function to update Bom type and latest vehicle id is [%s] when checked out",latest_parentIDstr); fflush(stdout);
						BOMTypeValidateStampFun(latest_parentIDstr,latest_revV,ChildTagLatestRevt);
						printf("\n save_method_7--After  calling function to update Bom type when checked out"); fflush(stdout);
					}
					else if ((tc_strcmp(PartType,"V")==0) && (tc_strstr(vrlsstatus,"ERC Review") != NULL))
					{
						ITK_CALL(AOM_ask_value_string(ChildTagLatestRevt,"current_id",&cvchild));
						ITK_CALL(AOM_ask_value_string(ChildTagLatestRevt,"t5_DesignGrp",&cvchilddsggrp));
						ITK_CALL(AOM_ask_value_string(ChildTagLatestRevt,"t5_ModuleAddress",&module_addrs));
						ITK_CALL(AOM_UIF_ask_value(ChildTagLatestRevt,"release_status_list",&childrlsstat));
						printf("\n Released status for child is [%s] \n",childrlsstat); fflush(stdout);

						printf("\nParent ID is [%s] and its part Type is [%s]",designRev_id,PartType); fflush(stdout); //Parent Attributes ==> rev_tag
						printf("\nChild ID is [%s] and its Design group is [%s] and its Module address is [%s]",cvchild,cvchilddsggrp,module_addrs);	fflush(stdout); //Childs tag ==> ChildTagLatestRevt

						ITK_CALL(WSOM_where_referenced2(rev_tag,2,&n_referencersV,&levelsV,&referencersV,&relationsRefV));
						printf("\n WSOM_where_referenced n_referencers count is [%d] \n",n_referencersV); fflush(stdout);

						if(n_referencersV>0)
						{
							for (sv=0;sv<n_referencersV;sv++ )
							{
								//flag1=0;
								printf("\nInside FOR loooop for n_referencersV of Parent\n",class_nameV);fflush(stdout);
								POM_class_of_instance(referencersV[sv],&class_idV);
								POM_name_of_class(class_idV,& class_nameV);

								WSOM_ask_name2(referencersV[sv],&MPartNoV);

								WSOM_ask_object_id_string(referencersV[sv],&ItemIDV);
								printf("\n Item Id for Parent to find DML is ==> [%s]\n",ItemIDV);fflush(stdout);

								//ITK_CALL(AOM_UIF_ask_value(referencersV[sv],"owning_user",&dmlownerparent));
								//printf("\n Owner of DML to which parent is attached is [%s]\n",dmlownerparent);fflush(stdout);

								if(strcmp(class_nameV,"T5_ChangeTaskRevision")==0)
								{
									ITK_CALL(AOM_UIF_ask_value(referencersV[sv],"fnd0ActuatedInteractiveTsks",&taskTempLTV));
									printf("\n primary taskTempLTV is [%s]\n",taskTempLTV);fflush(stdout);

									if(tc_strstr(ItemIDV,"_00") != NULL)  //Assignment need to be added
									{
										printf("\nPaaarent Loop is finished and DML is [%s]\n",ItemIDV); fflush(stdout);

										strcpy(DMLtaskID,"");
										strcpy(DMLtaskID,ItemIDV);

										TokDMLId = tc_strtok(ItemIDV,"_");
										printf("\nDML is : [%s]\n",TokDMLId); fflush(stdout);

										ITK_CALL(ITEM_find_item(TokDMLId,&PDML_tag));

										//ITK_CALL(AOM_ask_value_string(PDML_tag,"current_revision_id",&DMLItem_id)); //T5_DMLTaskRelation

										ITK_CALL(ITEM_ask_latest_rev(PDML_tag,&DMLRevTag1));

										//ITK_CALL(AOM_ask_value_string(DMLRevTag1,"T5_DMLTaskRelation",&all_tasks));

										//printf("\nDMLItem_id id is [%s]\n",DMLItem_id); fflush(stdout);
										//printf("\nall_tasks id is [%s]\n",all_tasks); fflush(stdout);

										//printf("\n After token DML DMLItem_id is : %s\n",DMLItem_id,all_tasks);fflush(stdout);

										ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &PGmrelation_type));
										ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag1,PGmrelation_type,&Pn_attchs,&secondary_Pobjects));
										//ITK_CALL(AOM_ask_value_tags(DMLRevTag1,"T5_DMLTaskRelation",&Pn_attchs,&secondary_Pobjects));

										printf("Count of tasks is : %d",Pn_attchs); fflush(stdout);
										if(Pn_attchs>0)
										{
											for (lt=0;lt<Pn_attchs ;lt++ )
											{
												DMLtaskTag = secondary_Pobjects[lt];
												ITK_CALL(AOM_UIF_ask_value(DMLtaskTag,"item_id",&task_id));

												char* delimiter = strrchr(task_id, '_');

												if (delimiter != NULL)
												{
													char* value = delimiter + 1;
													printf("\nLast occurence is [%s]\n", value);

													if (tc_strcmp(cvchilddsggrp,"00")==0)
													{
														if(tc_strstr(value,"0E") != NULL)
														{
															ITK_CALL(AOM_UIF_ask_value(DMLtaskTag,"Analyst",&DmlAnalyst_name));
															printf("\n\n\t\t Parent DML task ID is :[%s] and its Analyst is [%s]",task_id,DmlAnalyst_name);fflush(stdout);
														}
													}
													else if (tc_strstr(value,cvchilddsggrp) != NULL)
													{
														ITK_CALL(AOM_UIF_ask_value(DMLtaskTag,"Analyst",&DmlAnalyst_name));
														printf("\n\nELSE IF loop Parent DML task ID is :[%s] and its Analyst is [%s]",task_id,DmlAnalyst_name);fflush(stdout);
													}
												}
											}
										}
									}
									break;
								}
							}
						} //Parent References Loop Ends

						//Rohit BOM logic starts
						ITK_CALL(BOM_create_window(&bom_cv));
						ITK_CALL(CFM_find("Latest Working", &cv_revrule));
						ITK_CALL(BOM_set_window_config_rule( bom_cv, cv_revrule));
						ITK_CALL(BOM_set_window_pack_all(bom_cv, true));
						ITK_CALL(BOM_set_window_top_line(bom_cv,latest_parentID,latest_revV,NULLTAG,&topline_cvbom));
						ITK_CALL(BOM_line_ask_child_lines(topline_cvbom,&toplinecvbom_count,&cvbom_childs));

						printf("\nCount of Children present under Vehicle %s is [%d]\n",latest_parentIDstr,toplinecvbom_count); fflush(stdout);

						if(toplinecvbom_count > 0)
						{
							for(CVC = 0 ; CVC < toplinecvbom_count ; CVC++)
							{
								cv_childtag = cvbom_childs[CVC];

								//ITK_CALL(BOM_line_look_up_attribute ("bl_item_item_id",&cvchildline_ID));
								//ITK_CALL(BOM_line_look_up_attribute ("bl_rev_item_revision_id",&cvchildline_rev));
								//ITK_CALL(BOM_line_look_up_attribute ("bl_Design Revision_t5_DesignGrp",&cvchildline_designgrp));
								//ITK_CALL(BOM_line_look_up_attribute ("bl_Design Revision_t5_ModuleAddress",&cvchildline_modules_addrs));
								//
								//ITK_CALL(BOM_line_ask_attribute_string(cv_childtag, cvchildline_ID, &cv_ItemID_str));
								//ITK_CALL(BOM_line_ask_attribute_string(cv_childtag, cvchildline_rev, &cv_ItemRev_str));
								//ITK_CALL(BOM_line_ask_attribute_string(cv_childtag, cvchildline_designgrp, &cv_designgrp_str));
								//ITK_CALL(BOM_line_ask_attribute_string(cv_childtag, cvchildline_modules_addrs, &cv_modaddrs_str));

								if( AOM_ask_value_string(cv_childtag,"bl_item_item_id",&cv_ItemID_str));
								if( AOM_ask_value_string(cv_childtag,"bl_rev_item_revision_id",&cv_ItemRev_str));
								if( AOM_ask_value_string(cv_childtag,"bl_Design Revision_t5_DesignGrp",&cv_designgrp_str));
								if( AOM_ask_value_string(cv_childtag,"bl_Design Revision_t5_ModuleAddress",&cv_modaddrs_str));

								printf("\nChild ID already present under Vehicle , its Rev ID and its Design Group is [%s] , [%s] and [%s] and Module address is [%s]\n",cv_ItemID_str,cv_ItemRev_str,cv_designgrp_str,cv_modaddrs_str); fflush(stdout);

								//tc_strcpy(alldsggrp,"");
								tc_strcat(alldsggrp,cv_modaddrs_str);
								tc_strcat(alldsggrp,",");

								printf("\nAll Design group for child present in BOM are : [%s]\n",alldsggrp); fflush(stdout);

							}
						}

						printf("\nPrinting Design Group of all childs inside BOM outside loop ======>>>>>>> %s\n",alldsggrp); fflush(stdout);
						//Rohit BOM logic ends

						printf("\nParent part type is vehicle and it is in ERC Review\n"); fflush(stdout);

						if(tc_strstr(info1cv,cvchilddsggrp) != NULL)
						{
							printf("\nPart Type is vehicle and is in erc review and control object matches and is attached to task : [%s]\n",DMLtaskID); fflush(stdout);
							//printf("\n Already Present Design Groups : [%s]\n",tc_strstr(alldsggrp,cvchilddsggrp)); fflush(stdout);

							if(tc_strstr(alldsggrp,module_addrs) == NULL) //Rohit BOM
							{
								if(tc_strstr(DMLtaskID,"_00") != NULL)
								{
									if (tc_strcmp(taskTempLTV,"Add solution items")==0)
									{
										if(tc_strstr(childrlsstat,"ERC Released") != NULL)
										{
											if(tc_strstr(DmlAnalyst_name,usernameR) != NULL) //Remove condition
											{
												printf("\nAddition of part in Vehicle is successful\n"); fflush(stdout);
												//CR:CR-FY26-0065  call BOMTypeValidateStampFun function for TCUA 1.84 Backend
												printf("\n save_method_7--Before calling function to update Bom type and latest vehicle id is [%s]",latest_parentIDstr); fflush(stdout);
												BOMTypeValidateStampFun(latest_parentIDstr,latest_revV,ChildTagLatestRevt);
												printf("\n save_method_7--After  calling function to update Bom type"); fflush(stdout);

											}
											else
											{
												printf("\nDML Analyst and Logged In user sesssion does not match. [%s] and [%s]\n",DmlAnalyst_name,usernameR); fflush(stdout);
												//flagDMLattach=1;
												EMH_store_error_s1(EMH_severity_error,ITK_err,"You cannot modify BOM for checked-in part as DML Analyst and Logged In user sesssion does not match.");
												return ITK_err;
											}
										}
										else
										{

											printf("\n\n You cannot modify BOM for checked-in part as part you are trying to add is not Released\n"); fflush(stdout);
											//flagDMLattach=1;
											EMH_store_error_s1(EMH_severity_error,ITK_err,"You cannot modify BOM for checked-in part as part you are trying to add is not Released");
											return ITK_err;
										}
									}
									else
									{
										printf("\n\n  Task is not at Add solution items task\n"); fflush(stdout);
										//flagDMLattach=1;
										EMH_store_error_s1(EMH_severity_error,ITK_err,"You cannot modify BOM for checked-in Vehicle as Task is not at Add solution items task");
										return ITK_err;
									}
								}
								else
								{
									printf("\nYou cannot modify BOM for checked-in part as parent (Vehicle) is not attached to DML\n"); fflush(stdout);
									//flagDMLattach=1;
									EMH_store_error_s1(EMH_severity_error,ITK_err,"You cannot modify BOM for checked-in part as parent (Vehicle) is not attached to DML");
									return ITK_err;
								}
							}
							else
							{
								tc_strcpy(ErrorMsgF,"");
								tc_strcat(ErrorMsgF,"Child part with Module Address [");
								tc_strcat(ErrorMsgF,module_addrs);
								tc_strcat(ErrorMsgF,"] is already present under Vehicle.");
								printf("\nChild part with Module Address [%s] is already present under Vehicle.\n",module_addrs); fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,ErrorMsgF);
								return ITK_err;
							}
						}
						else
						{
							printf("\nDesign group of child does not match with 00,16,21,50\n"); fflush(stdout);
							flagDMLattach=1;
						}
					}
					else
					{
						printf("\nPart type is not Vehicle or it is not in ERC Review stage\n"); fflush(stdout);
						flagDMLattach=1;
					}
				}//Infodba Access LOOP
			} //Checked-out value loop
		} //Control Object loop
		else
		{
			flagDMLattach=1;
		}
		//Addition by Rohit Bhosale Ends for CR-FY23-0184

		if(tc_strcmp(objecttype,"Design Revision")==0 || tc_strcmp(objecttype,"T5_SparKitRevision")==0)
		{
			if( (!strstr(roleName,"APL")) || (!strstr(roleName,"MBOM")))     //MBOM implementation for CV TZ-1.69
			{
				printf("\n\n  inside roleName1111 : %s\n",roleName); fflush(stdout);
				if(tc_strcmp(roleName,"Colour_Designer")!=0)
				{
					printf("\n\nflagDMLattach value is [%d]\n",flagDMLattach); fflush(stdout);
					if(tc_strcmp(cp_ChildChkOutValue,"Y")==0)
					{
						printf("\nPart is already checked-out...........\n");fflush(stdout);
						if((tc_strcmp(PartType,"C")==0) && ((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0)))
						{
							printf("\nPartType is Cmponent & username is ---> %s\n",username);fflush(stdout);
							if(tc_strstr(DesignGrp,t5_DesignGrp)!=NULL) //go inside
							{
								printf("\nDesignGrp of part found in set of String..\n");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s3(EMH_severity_error,ITK_err,"\n Component can't have structure","please check PartType of",Item_id_par);
								return ITK_err;
							}else
							{
								if(tc_strcmp(ChildPartType,"D")!=0)
								{
									EMH_clear_errors();
									EMH_store_error_s3(EMH_severity_error,ITK_err,"\n Component can't have structure","please check PartType of",Item_id_par);
									return ITK_err;
								}else
								{
									printf("\ncomponent for Barrel-3 with part designation is 69..\n");fflush(stdout);
								}
							}
						}
					}
					else if (((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0)) && (tc_strstr(roleName,"STD")==NULL) && (tc_strstr(roleName,"APL")==NULL) && (tc_strstr(roleName,"MBOM")==NULL) && (tc_strstr(roleName,"Support")==NULL) && flagDMLattach==1) //MBOM implementation for CV TZ-1.70 Backend Fixes
					{
						printf("\n\n  Inside LOADER/INFODBA loop\n"); fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Child parts can't be added to Checked-in/ERC Review part");
						return ITK_err;

					}
				}
			}else if (tc_strstr(roleName,"Support")==NULL)
			{
				int count_DML=0;
				int d=0;
				tag_t	  		dml_task_rel_type	=	NULLTAG;
				tag_t*			DMtaskRevision			= NULLTAG;
				tag_t*			DMLRevision			= NULLTAG;
				tag_t			prtTask1			= NULLTAG;
				tag_t			DMLRev			= NULLTAG;
				tag_t			tsk_dml_rel_type			= NULLTAG;
				char	*TaskDMLNumberr	= NULL;
				char	*releasest_name	= NULL;
				char	*ECNType	= NULL;


				tag_t		*status_list =	NULLTAG;
				int st_count=0;
				int iLCS1=0;
				int releaseStatusFnd=0;

             //rev_tag

			 printf("\n Going to Check APL rest Task :");fflush(stdout);

			ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&dml_task_rel_type));
			ITK_CALL(GRM_list_primary_objects_only(rev_tag,dml_task_rel_type,&count_DML,&DMtaskRevision));
		if (count_DML>0)
		{
			for (d=0;d<count_DML ;d++ )
			{

					prtTask1=	DMtaskRevision[d];

				ITK_CALL( AOM_ask_value_string(prtTask1,"item_id",&TaskDMLNumberr));
				printf("\n TaskDMLNumberr : %s",TaskDMLNumberr);fflush(stdout);
				if (tc_strstr(TaskDMLNumberr,"AM")!=NULL||tc_strstr(TaskDMLNumberr,"SM")!=NULL)
				{

				  ITK_CALL(WSOM_ask_release_status_list(prtTask1,&st_count,&status_list));


				releasest_name	=	NULL;
				for (iLCS1=0; iLCS1< st_count ; iLCS1++)
				{

				ITK_CALL(AOM_ask_value_string(status_list[iLCS1],"object_name",&releasest_name));
				printf("\n releasest_name: %s\n",releasest_name);fflush(stdout);
				//if(tc_strcmp(releasest_name,"T5_LcsAPLWrkg")==0)
			 if (tc_strstr(releasest_name,"Rlzd")==NULL)
				{

				ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
					ITK_CALL(GRM_list_primary_objects_only(prtTask1,tsk_dml_rel_type,&count_DML,&DMLRevision));

					if (count_DML>0)
					{
						DMLRev=	DMLRevision[0];
						ITK_CALL( AOM_ask_value_string(DMLRev,"t5_EcnType",&ECNType));
						if (tc_strcmp(ECNType,"APLSTR")==0)
						{
							 releaseStatusFnd++;
						}
						else if (tc_strstr(TaskDMLNumberr,"SM")!=NULL)
						{
							releaseStatusFnd++;
						}

					}

				}
				}

			}
			  }


	}

		if (releaseStatusFnd==1)
				{
		            printf("\n Allowed to do Add part as Assy is attached to APL Rest DML %s\n",releasest_name);fflush(stdout);

				}
				else if (releaseStatusFnd==0)
				{
					if((tc_strcmp(username,"infodba")==0) || (tc_strcmp(username,"loader")==0)|| (tc_strcmp(username,"aplloader")==0))
					{
						printf("\n Allowed to do Add part as User is Infodba or loader \n");fflush(stdout);

					}
					else
					{

					if (QKaddVldCntlObj==0)
					{
						printf("\n Quick Add  control object not Live \n");fflush(stdout);

					}
					else
						{
						if (cntLcs>0)
						{
							     EMH_store_error_s1(EMH_severity_error,ITK_err,"You can not add parts in APL View withouth Restructuring DML");

								return ITK_err;
						}


						}

					}
				}
		}



		}

	//Akshay ECU Bom modification

    printf("\n Inside ECU BOM Modification \n"); fflush(stdout);

    tag_t	qryTag_ecu			= NULLTAG;
	char **qry_val_ecu			= (char **) MEM_alloc(100 * sizeof(char *));
	char    *qry_entri_ecu[1]   = {"SYSCD"};
	int n_entries_ecu			= 1;
	int qrycount_ecu			= 0;
	tag_t *CntrlObjTagecu		= NULLTAG;

    char *ecubcm_rel_status = NULL;

		if(QRY_find2("ControlObjects", &qryTag_ecu));
		if (qryTag_ecu)
		{
			printf("\n ControlObjects:.Found Query ControlObjects for ECU BOM Modification  ");fflush(stdout);
		}
		else
		{
			printf("\n ControlObjects:.Not Found for ECU BOM Modification  ");fflush(stdout);
		}
		qry_val_ecu[0] = "bomsavepaste";
		if(QRY_execute(qryTag_ecu, n_entries_ecu, qry_entri_ecu, qry_val_ecu, &qrycount_ecu, &CntrlObjTagecu));

		printf("\n\t ****qrycount ECU Bom Modification => %d***** ",qrycount_ecu);fflush(stdout);

		if(qrycount_ecu>0)
		{

			if( AOM_ask_value_string(objTag,"bl_rev_release_status_list",&ecubcm_rel_status));
			printf("\n ECU Release status of Parent : [%s] \n",ecubcm_rel_status);fflush(stdout);

			printf("\n ECU part Object Type : [%s] \n",objecttype);fflush(stdout);
			printf("\n username : [%s] \n",username);fflush(stdout);
		    printf("\n roleName : [%s] \n",roleName);fflush(stdout);
			printf ("ECU BOMLine check out status ::%s\n",cp_ChildChkOutValue);fflush(stdout);

			if(tc_strcmp(objecttype,"T5_EE_PartRevision")==0)

			{
				   if (((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0)) && (tc_strstr(roleName,"STD")==NULL) && (tc_strstr(roleName,"APL")==NULL) && (tc_strstr(roleName,"MBOM")==NULL) && (tc_strstr(roleName,"Support")==NULL)) //MBOM implementation for CV TZ-1.70 Backend Fixes
					{


						if(tc_strcmp(cp_ChildChkOutValue,"Y")!=0)
						{

								printf("\n ECU  bomline_cut_method--Parent is not checked-out.\n"); fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error, ITK_err, "You cannot modify BOM as Selected part is not checked-out");
								return ITK_err;


						}
						else if ((tc_strstr(ecubcm_rel_status,"Release") != NULL) || (tc_strstr(ecubcm_rel_status,"T5_LcsErcRlzd") != NULL))
						{
							printf("\n ECU part is Release \n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error, ITK_err, "You cannot modify BOM as parent part is released.");
							return ITK_err;
						}



					}
					else
					{
						printf("\n ECU bomline_cut_method--User Role is APL, STD, or MBOM , hence bypassed this validation\n"); fflush(stdout);
					}
			}
		}



		if(tc_strcmp(objecttype,"T5_ClrPartRevision")==0)
		{
		if (QKaddVldCntlObj>0)
			{


			int colrpartflg,st_countc=0;
			int count_DMLC,dc,iLCS1C=0;
			char	*TaskDMLNumberrC =	NULL;
			char	*releasest_nameC =	NULL;

			tag_t   dml_task_rel_typeC		=	NULLTAG;
			tag_t   prtTask1C		=	NULLTAG;
			tag_t   *DMtaskRevisionC		=	NULLTAG;
			tag_t*    status_listc =NULLTAG;

            ITK_CALL(GRM_find_relation_type("CMReferences",&dml_task_rel_typeC));
			ITK_CALL(GRM_list_primary_objects_only(rev_tag,dml_task_rel_typeC,&count_DMLC,&DMtaskRevisionC));
		if (count_DMLC>0)
			{
		for (dc=0;dc<count_DMLC ;dc++ )
				{

					prtTask1C=	DMtaskRevisionC[dc];

				ITK_CALL( AOM_ask_value_string(prtTask1C,"item_id",&TaskDMLNumberrC));
				printf("\n TaskDMLNumberrC : %s",TaskDMLNumberrC);fflush(stdout);
				if (tc_strstr(TaskDMLNumberrC,"AM")!=NULL||tc_strstr(TaskDMLNumberrC,"SM")!=NULL)
				{

				  ITK_CALL(WSOM_ask_release_status_list(prtTask1C,&st_countc,&status_listc));


				releasest_nameC	=	NULL;
				for (iLCS1C=0; iLCS1C< st_countc ; iLCS1C++)
				  {
						ITK_CALL(AOM_ask_value_string(status_listc[iLCS1C],"object_name",&releasest_nameC));
				           printf("\n releasest_nameC: %s\n",releasest_nameC);fflush(stdout);

						    if (tc_strstr(releasest_nameC,"Rlzd")==NULL)
					        {
								colrpartflg++;

							}

				  }
				}
			}

		    }

          if (tc_strstr(roleName,"Support")!=NULL || (tc_strcmp(username,"infodba")==0) || (tc_strcmp(username,"loader")==0)|| (tc_strcmp(username,"aplloader")==0))
			{

			  printf("\n Allowed to do Add part as User is Infodba or loader \n");fflush(stdout);


		    }
			else
			{

				if (QKaddVldCntlObj==0)
					{
						printf("\n Quick Add  control object not Live \n");fflush(stdout);

					}
					else
						{
						if (colrpartflg==0)
						{

						if (cntLcs>0)
							{
			 EMH_store_error_s1(EMH_severity_error,ITK_err,"You can not add parts in APL View directly in color Assembly,do APL restructuring of Non Color Revision");
			 return ITK_err;
							}
						}
						}

			}
		}


		}
		if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0))
		{
			printf("\n DURA FIT BOM PROCESS CHECK VALIDATION PARENT PART OBJECT TYPE IS=>[%s]\n",objecttype);fflush(stdout); // parent object type
			printf("\n DURA FIT BOM PROCESS CHECK VALIDATION CHILD PART OBJECT TYPE IS=>[%s]\n",sObjectTypeModulet);fflush(stdout); // child part object type
			printf("\n\t ChildPartType => %s\n",ChildPartType);fflush(stdout); // child part parttype
			printf("\n  Child Part Number ---->[%s] \n",Item_id_par); fflush(stdout);
			if(tc_strcmp(objecttype,"Design Revision")==0)
			{
				if(tc_strcmp(sObjectTypeModulet,"T5_DuraFitPartRevision")==0)
				{
					EMH_store_error_s3(EMH_severity_error,ITK_err,"Dura Fit part no ", Item_id_par," is not allowed to attach under Design Revision BOM!!");
					return ITK_err;
				}
			}
			if(tc_strcmp(objecttype,"T5_DuraFitPartRevision")==0)
			{
				if(tc_strcmp(sObjectTypeModulet,"Design Revision")==0 && tc_strcmp(ChildPartType,"V")!=0)
				{
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Other Than Vehicle under Durafit is not allowed!!");
					return ITK_err;
				}
			}
		}
	}

	//Vitthal :START: Validation on Architecture Module Revision Address and Module Address.
	//POM_get_user(&username,&user_tag);
	if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0))
	{
		printf("\n\n  BomLineModuleValidaion calling.."); fflush(stdout);
		if((rev_tag) && (BomLineModuleValidaion(rev_tag,item_tag)>0) )
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"\n Architecture Module Revision Address and Module Address is not same.");
			return ITK_errStore;
		}
	}
	else
	{
		printf("\n\t BYPASS:Architecture Module Revision Address and Module Address Validaion for infodba and loader Login\n Cureent Login:%s ",username);fflush(stdout);
	}
	//Vitthal :END: Validation on Architecture Module Revision Address and Module Address.
	return error_code;
}
//********Added by Kalpesh**********(Post_action//30th_june_2018)

extern DLLAPI int save_method_qty_updt(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;
	int			child_attr			= 0;
	int			Item_attr			= 0;
	int			Rev_attr			= 0;
	int			bl_abs_xform		= 0;
	//int			bl_relative_xform	= 0;
	char		*child_qty			= NULL;
	char		*Item_id			= NULL;
	char		*Item_rev_id		= NULL;
	char		*child_part_type	= NULL;
	char		*child_obj_type		= NULL;
	char		*parent_obj_type	= NULL;
	char		*child_item_id2		= NULL;
	char		*child_item_id		= NULL;
	char		*ApplnOwner			= NULL;
	char		*child_abs_xform	= NULL;
	char		*child_relv_xform	= NULL;
	char		*child_rev_id		= NULL;
	tag_t		revision_tag		= NULLTAG;
	tag_t		parent_tag			= va_arg(args, tag_t);
	tag_t		child_tag			= va_arg(args, tag_t);
	tag_t		child_rev_tag		= va_arg(args, tag_t);
	tag_t		bv_tag				= va_arg(args, tag_t);
	char*		occ_type			= va_arg(args, char*);
	tag_t*		child_bline_tag		= va_arg(args, tag_t*);

	//if(BOM_line_look_up_attribute ("bl_item_item_id",&Item_attr)!=ITK_ok) PrintErrorStack();
	//if(BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Rev_attr)!=ITK_ok) PrintErrorStack();
	//
	//if(BOM_line_ask_attribute_string(parent_tag, Item_attr, &Item_id)!=ITK_ok) PrintErrorStack();
	//if(BOM_line_ask_attribute_string(parent_tag, Rev_attr, &Item_rev_id)!=ITK_ok) PrintErrorStack();

	if( AOM_ask_value_string(parent_tag,"bl_item_item_id",&Item_id));
	if( AOM_ask_value_string(parent_tag,"bl_rev_item_revision_id",&Item_rev_id));

	if(ITEM_find_rev(Item_id,Item_rev_id,&revision_tag)!=ITK_ok) PrintErrorStack();

	if(AOM_ask_value_string(revision_tag,"object_type",&parent_obj_type));
	printf("\n\t Parent_bomline => %s\n",parent_obj_type);fflush(stdout);

	//RRR: TCUA 1.43 - START: Add -90 Degree rotation T-matrix for ProE modules based on application owner while attaching/saving Architecture node
	if (child_rev_tag == NULLTAG)
	{
		//if(BOM_line_ask_attribute_string(child_bline_tag[0], Item_attr, &child_item_id2)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_ask_attribute_string(child_bline_tag[0], Rev_attr, &child_rev_id)!=ITK_ok) PrintErrorStack();

		if( AOM_ask_value_string(child_bline_tag[0],"bl_item_item_id",&child_item_id2));
		if( AOM_ask_value_string(child_bline_tag[0],"bl_rev_item_revision_id",&child_rev_id));

		printf("\n\t 1...child_item_id2 => [%s] \n\t child_rev_id => [%s]\n",child_item_id2,child_rev_id);fflush(stdout);

		if(ITEM_find_rev(child_item_id2,child_rev_id,&child_rev_tag)!=ITK_ok) PrintErrorStack();
	}
	//RRR: TCUA 1.43 - END: Add -90 Degree rotation T-matrix for ProE modules based on application owner while attaching/saving Architecture node

	if(AOM_ask_value_string(child_rev_tag,"t5_PartType",&child_part_type));
	if(AOM_ask_value_string(child_rev_tag,"object_type",&child_obj_type));
	if(AOM_ask_value_string(child_rev_tag,"item_id",&child_item_id));

	printf("\n\t ChildPartType => [%s] child_obj_type => [%s]\n",child_part_type,child_obj_type);fflush(stdout);

	if(tc_strcmp(parent_obj_type,"T5_ArchModuleRevision")==0)
	{
		printf("\n\t Inside the left object at------------>>>>>>>>=> [%s]\n",parent_obj_type);fflush(stdout);
		// condition modified on date 26-06-2025 by AK
		if((tc_strcmp(child_obj_type,"Design Revision")==0) && ((tc_strcmp(child_part_type, "M") == 0) ||(tc_strcmp(child_part_type, "Module") == 0)))
		{
			//if(BOM_line_look_up_attribute ("bl_quantity",&child_attr)!=ITK_ok) PrintErrorStack();
			//if(BOM_line_ask_attribute_string (child_bline_tag[0], child_attr, &child_qty)!=ITK_ok) PrintErrorStack();

			if( AOM_ask_value_string(child_bline_tag[0],"bl_quantity",&child_qty));
			if(tc_strcmp(child_qty, "0") == 0 || tc_strlen(child_qty) == 0)
			{
				if(AOM_set_value_string(child_bline_tag[0], "bl_quantity", "1") != ITK_ok) PrintErrorStack();
				printf("\nQuantity set to 1\n");fflush(stdout);
			}

			//RRR: TCUA 1.43 - START: Add -90 Degree rotation T-matrix for ProE modules based on application owner while attaching/saving Architecture node
			if( AOM_ask_value_string(child_bline_tag[0],"bl_Design Revision_t5_ApplicationOwner",&ApplnOwner)!=ITK_ok);
			printf("\n\t [%s] Right Object's ApplicationOwner ---->[%s] \n",child_item_id,ApplnOwner); fflush(stdout);
            // condition modified on date 26-06-2025 by AK
			if( (tc_strcmp(ApplnOwner,"ProEAsm")==0) || (tc_strcmp(ApplnOwner,"ProEPart")==0) ||
				(tc_strcmp(ApplnOwner,"ProEngineer-Part")==0) || (tc_strcmp(ApplnOwner,"ProEngineer-Asm")==0) ||
				((strlen(ApplnOwner)==0)&&((tc_strcmp(subString(child_item_id,4,1),"C")==0)||(tc_strcmp(subString(child_item_id,4,1),"P")==0)))
				)
			{
				tag_t   qryTag = NULLTAG;
				tag_t   *CntrolObjectTag = NULLTAG;
				char	*info9r	= NULL;
				int     n_entry    = 1;
				int     rsltCount  =  0;
				char    *qry_entry[1]  = {"SYSCD"};
				char    **qry_values     =  (char **) MEM_alloc(10 * sizeof(char *));

				if(QRY_find2("ControlObjects", &qryTag));
				if (qryTag)
				{
					//printf("\n Eff:Found Query ControlObjects ");
					fflush(stdout);
				}
				else
				{
					printf("\n Eff:Not Found Query ControlObjects \n");
					fflush(stdout);
				}
				if (qryTag)
				{
					printf("\n Found Query ControlObjects... ");fflush(stdout);
					qry_values[0] = "ERCVali";
					if(QRY_execute(qryTag, n_entry, qry_entry, qry_values, &rsltCount, &CntrolObjectTag));
					printf("\t rsltCount :%d:", rsltCount); fflush(stdout);
					if(rsltCount > 0)
					{
						if (AOM_ask_value_string(CntrolObjectTag[0],"t5_Userinfo9",&info9r)!=ITK_ok) PrintErrorStack();
						printf("\t info9r is = [%s] \n", info9r);fflush(stdout);
					}
				}
				if (tc_strcmp(info9r,"MATRIXON")==0)
				{
					printf("\n\t Dropping ProE Module as Right Object "); fflush(stdout);

					//if(BOM_line_look_up_attribute ("bl_plmxml_abs_xform",&bl_abs_xform)!=ITK_ok) PrintErrorStack();
					//if(BOM_line_ask_attribute_string (child_bline_tag[0], bl_abs_xform, &child_abs_xform)) PrintErrorStack();
					//if(BOM_line_look_up_attribute ("bl_plmxml_occ_xform",&bl_relative_xform)!=ITK_ok) PrintErrorStack();
					//if(BOM_line_ask_attribute_string (child_bline_tag[0], bl_relative_xform, &child_relv_xform)) PrintErrorStack();

					if( AOM_ask_value_string(child_bline_tag[0],"bl_plmxml_abs_xform",&child_abs_xform));
					if( AOM_ask_value_string(child_bline_tag[0],"bl_plmxml_occ_xform",&child_relv_xform));

					printf("\n\t child_abs_xform:[%s]   child_relv_xform:[%s] ",child_abs_xform,child_relv_xform); fflush(stdout);

					if (tc_strcmp(child_abs_xform,"1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1") == 0)
					{
						printf("== -90 Degree T-matrix is rotated..[%s] [%s]",child_item_id,ApplnOwner); fflush(stdout);
						if ((tc_strcmp(child_relv_xform,"") == 0) || (tc_strcmp(child_abs_xform,"1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1") == 0))
						{
							printf("--Updating -90 roatation for RelativeMatrix...\n"); fflush(stdout);
							//if(BOM_line_set_attribute_string(child_bline_tag[0], bl_relative_xform, "1 0 0 0 0 0 1 0 0 -1 0 0 0 0 0 1")) PrintErrorStack();
							if(AOM_UIF_set_value(child_bline_tag[0],"bl_plmxml_occ_xform","1 0 0 0 0 0 1 0 0 -1 0 0 0 0 0 1"));
							//if(BOM_line_set_attribute_string(child_bline_tag[0], bl_abs_xform, "1 0 0 0 0 0 1 0 0 -1 0 0 0 0 0 1") != ITK_ok) PrintErrorStack();
						}
					}
				}
			}
			//RRR: TCUA 1.43 - END: Add -90 Degree rotation T-matrix for ProE modules based on application owner while attaching/saving Architecture node
		}
	}
	// Ashish: UA1.46 Start - Quantity set to 0 if part type of child revision is IFD
	else if(tc_strcmp(parent_obj_type,"Design Revision")==0)
	{
		printf("\n\t BOMLine_Add-post action:  %s\n",parent_obj_type);fflush(stdout);

		if((tc_strcmp(child_obj_type,"Design Revision")==0) && (tc_strcmp(child_part_type, "IFD") == 0))
		{
			//if(BOM_line_look_up_attribute ("bl_quantity",&child_attr) != ITK_ok) PrintErrorStack();
			//if(BOM_line_ask_attribute_string (child_bline_tag[0], child_attr, &child_qty)!= ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(child_bline_tag[0],"bl_quantity",&child_qty));

			//if(tc_strcmp(child_qty, "1") == 0)
			//{
				printf("\n If part type of child part is IFD then set quantity as 0, Quantity set to 0\n");fflush(stdout);
				if(AOM_set_value_string(child_bline_tag[0], "bl_quantity", "0") != ITK_ok) PrintErrorStack();
				printf("\n Quantity set to 0 \n");fflush(stdout);
			//}
		}
	}
	// Ashish: UA1.46 End - Quantity set to 0 if part type of child revision is IFD

	return error_code;
}
//End ******(kalpesh)

void GetPlantWise_STD_LCS( char * PlantName,char  getPlant_STDWorkingLCS[40],char  getPlant_STDReleasedLCS[40])
{
	printf("\n Inside Ketan function GetPlantWise_STD_LCS \n");fflush(stdout);

	printf("\n PlantName:%s\n", PlantName);fflush(stdout);

	if(strcmp(PlantName,"STDD")==0)
	{
		printf("\n Inside STDD \n");fflush(stdout);
		tc_strcpy(getPlant_STDWorkingLCS,"T5_LcsSTDdWrkg");
		tc_strcpy(getPlant_STDReleasedLCS,"T5_LcsStddRlzd");
	}
	else if(strcmp(PlantName,"STDP")==0)
	{
		printf("\n Inside STDP \n");fflush(stdout);
		tc_strcpy(getPlant_STDWorkingLCS,"T5_LcsSTDpWrkg");
		tc_strcpy(getPlant_STDReleasedLCS,"T5_LcsStdpRlzd");
	}
	else if(strcmp(PlantName,"STDC")==0)
	{
		printf("\n Inside STDC \n");fflush(stdout);
		tc_strcpy(getPlant_STDWorkingLCS,"T5_LcsSTDWrkg");
		tc_strcpy(getPlant_STDReleasedLCS,"T5_LcsStdRlzd");
	}
	else if(strcmp(PlantName,"STDJ")==0)
	{
		printf("\n Inside STDJ \n");fflush(stdout);
		tc_strcpy(getPlant_STDWorkingLCS,"T5_LcsSTDjWrkg");
		tc_strcpy(getPlant_STDReleasedLCS,"T5_LcsStdjRlzd");
	}
	else if(strcmp(PlantName,"STDL")==0)
	{
		printf("\n Inside STDL \n");fflush(stdout);
		tc_strcpy(getPlant_STDWorkingLCS,"T5_LcsSTDlWrkg");
		tc_strcpy(getPlant_STDReleasedLCS,"T5_LcsStdlRlzd");
	}
	else if(strcmp(PlantName,"STDU")==0)
	{
		printf("\n Inside STDU \n");fflush(stdout);
		tc_strcpy(getPlant_STDWorkingLCS,"T5_LcsSTDuWrkg");
		tc_strcpy(getPlant_STDReleasedLCS,"T5_LcsStduRlzd");
	}
	else if(strcmp(PlantName,"STDS")==0)
	{
		printf("\n Inside STDS \n");fflush(stdout);
		tc_strcpy(getPlant_STDWorkingLCS,"T5_LcsSTDsWrkg");
		tc_strcpy(getPlant_STDReleasedLCS,"T5_LcsStdsRlzd");
	}
	else if(strcmp(PlantName,"STDA")==0)
	{
		printf("\n Inside STDA \n");fflush(stdout);
		tc_strcpy(getPlant_STDWorkingLCS,"T5_LcsSTDaWrkg");
		tc_strcpy(getPlant_STDReleasedLCS,"T5_LcsStdaRlzd");
	}
	else if(strcmp(PlantName,"STDV")==0)
	{
		printf("\n Inside STDV \n");fflush(stdout);
		tc_strcpy(getPlant_STDWorkingLCS,"T5_LcsSTDvWrkg");
		tc_strcpy(getPlant_STDReleasedLCS,"T5_LcsStdvRlzd");
	}
}

void GetPlantWise_STDRestrecture_LCS( char * PlantName,char  getPlant_STDRestLCS[40],char  getPlant_STDReRestLCS[40])
{
	printf("\nRestructuring Inside  function GetPlantWise_STDRestrecture_LCS");fflush(stdout);

	printf("\nPlantName:%s", PlantName);fflush(stdout);

	if(strcmp(PlantName,"STDD")==0)
	{
		printf("\nRestructuring Inside STDD");fflush(stdout);
		tc_strcpy(getPlant_STDRestLCS,"T5_LcsStddRestructured");
		tc_strcpy(getPlant_STDReRestLCS,"T5_LcsSTDDRResc");
	}
	else if(strcmp(PlantName,"STDP")==0)
	{
		printf("\nRestructuring Inside STDP");fflush(stdout);
		tc_strcpy(getPlant_STDRestLCS,"T5_LcsStdpRestructured");
		tc_strcpy(getPlant_STDReRestLCS,"T5_LcsSTDPRResc");
	}
	else if(strcmp(PlantName,"STDC")==0)
	{
		printf("\nRestructuring Inside STDC");fflush(stdout);
		tc_strcpy(getPlant_STDRestLCS,"T5_LcsStdRestructured");
		tc_strcpy(getPlant_STDReRestLCS,"T5_LcsSTDRResc");
	}
	else if(strcmp(PlantName,"STDJ")==0)
	{
		printf("\nRestructuring Inside STDJ");fflush(stdout);
		tc_strcpy(getPlant_STDRestLCS,"T5_LcsStdjRestructured");
		tc_strcpy(getPlant_STDReRestLCS,"T5_LcsSTDJRResc");
	}
	else if(strcmp(PlantName,"STDL")==0)
	{
		printf("\nRestructuring Inside STDL");fflush(stdout);
		tc_strcpy(getPlant_STDRestLCS,"T5_LcsStdlRestructured");
		tc_strcpy(getPlant_STDReRestLCS,"T5_LcsSTDlRResc");
	}
	else if(strcmp(PlantName,"STDU")==0)
	{
		printf("\nRestructuring Inside STDU");fflush(stdout);
		tc_strcpy(getPlant_STDRestLCS,"T5_LcsStduRestructured");
		tc_strcpy(getPlant_STDReRestLCS,"T5_LcsSTDURResc");
	}
	else if(strcmp(PlantName,"STDS")==0)
	{
		printf("\n Restructuring Inside STDS");fflush(stdout);
		tc_strcpy(getPlant_STDRestLCS,"T5_LcsStdsRestructured");
		tc_strcpy(getPlant_STDReRestLCS,"T5_LcsSTDSRResc");
	}
	else if(strcmp(PlantName,"STDA")==0)
	{
		printf("\nRestructuring Inside STDA");fflush(stdout);
		tc_strcpy(getPlant_STDRestLCS,"T5_LcsStdaRestructured");
		tc_strcpy(getPlant_STDReRestLCS,"T5_LcsSTDARResc");
	}
}

extern DLLAPI int bom_addition_only_release_pat(METHOD_message_t *msg, va_list args)  //Aniket
{
	tag_t	aparent_tag				= va_arg(args, tag_t);
	tag_t	aobjTypeTag				= NULLTAG;
	tag_t	aqryTagCntrl1			= NULLTAG;
	int	a_entryCntrl1			= 3;
	int	acontrol_number_found1	= 0;
	tag_t*	list_of_WSO_cntrl_a	= NULLTAG;
	char*	atype_name			= NULL;
	tag_t	aCurrentRoleTag			= NULLTAG;
	char*	aroleName			= NULL;
	char*	aItem_ID_Rev_str		= NULL;
	char*	aItem_ID_str			= NULL;
	char*	prttypeofdsr			= NULL;
	int numOfReleaseStatus = 0;
	tag_t *valuesOfReleaseStatus = NULLTAG;
	char *releaseStatusListOnPart		= NULL ;
	int aaa =0;

	char *aqry_entryCntrl1[3]	= {"SYSCD","SUBSYSCD","Delete Indicator"};
	char **aqry_valuesCntrl1		= (char **) MEM_alloc(5 * sizeof(char *));

	QRY_find2("Control Objects...", &aqryTagCntrl1);
	if(aqryTagCntrl1)
	{
		aqry_valuesCntrl1[0]="BOM_rleaddition";
		aqry_valuesCntrl1[1]="BOM_rleaddition";
		aqry_valuesCntrl1[2]="0";

		if(QRY_execute(aqryTagCntrl1, a_entryCntrl1, aqry_entryCntrl1, aqry_valuesCntrl1, &acontrol_number_found1, &list_of_WSO_cntrl_a));
		if(acontrol_number_found1>0)
		{
			printf("\n Inside Aniket Function for MBOM Structure creation fixes \n");fflush(stdout);
			if (TCTYPE_ask_object_type(aparent_tag,&aobjTypeTag)!=ITK_ok) PrintErrorStack();
			if (TCTYPE_ask_name2(aobjTypeTag,&atype_name)!=ITK_ok) PrintErrorStack();
			printf("\n Type Name for Structure fixes:- %s\n",atype_name);fflush(stdout);
			if(aparent_tag)
			{
				if(strcmp(atype_name,"BOMLine")==0)
				{
					printf("\n Inside BOM Line....................");fflush(stdout);
					ITK_CALL(SA_ask_current_role(&aCurrentRoleTag));
					ITK_CALL(SA_ask_role_name2(aCurrentRoleTag,&aroleName));
					printf("\n Role Name for Structure fixes:- %s\n",aroleName);fflush(stdout);

					if(tc_strstr(aroleName,"MBOM")!=NULL)
					{
						if( AOM_ask_value_string(aparent_tag,"bl_rev_item_revision_id",&aItem_ID_Rev_str));
						if( AOM_ask_value_string(aparent_tag,"bl_item_item_id",&aItem_ID_str));
						if( AOM_ask_value_string(aparent_tag,"bl_T5_ClrPartRevision_t5_PartType",&prttypeofdsr));

						if((tc_strcmp(prttypeofdsr,"V")!=0)||(tc_strcmp(prttypeofdsr,"VC")!=0))
						{
							printf("\n Part type is not vehicle or Vehicle combination");fflush(stdout);

							printf("\n Item ID & Revision Id forStructure fixes:- %s ,%s\n",aItem_ID_str,aItem_ID_Rev_str);fflush(stdout);
							printf("\nPart type of parent is-%s\n",prttypeofdsr);fflush(stdout);

							if(AOM_ask_value_tags(aparent_tag, "awb0RevisionRelStatusList", &numOfReleaseStatus, &valuesOfReleaseStatus));
							printf("\nafter change Release status count %d\n",numOfReleaseStatus);fflush(stdout);
							if(numOfReleaseStatus>0)
							{
								for(aaa=0;aaa<numOfReleaseStatus;aaa++)
								{
									if( AOM_ask_value_string(valuesOfReleaseStatus[aaa],"object_name",&releaseStatusListOnPart));
									printf("\n Release Status on parant object:- %s \n",releaseStatusListOnPart);fflush(stdout);
									if(tc_strstr(releaseStatusListOnPart,"T5_MBOMReleased")!=NULL)
									{
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error, ITK_err,"\nSelected Design-Revision is MBOM Relesed, Kindly revise the part to add BOM Line");
										return ITK_err;
									}
									else
									{
										printf("\n Part is not MBOM Release so modificationsss allowed");fflush(stdout);
									}

								}
							}
						}
						else
						{
							printf("\n Skip for Vehicle & Vehicle combination");fflush(stdout);

						}
					}
					else
					{
						printf("\n Role Name not MBOM");fflush(stdout);

					}

				}
			}
		}
		else
		{
			printf("\n BOM_rleaddition Control Object Not found ");fflush(stdout);

		}

	}

	return ITK_ok;
}


extern DLLAPI int tm_nonerc_Validation_add_method(METHOD_message_t *msg, va_list args) // Ketan
{
	printf("\n Inside Ketan function tm_nonerc_Validation_add_method calling \n");fflush(stdout);

	int error_code = ITK_ok;

	tag_t	parent_tag				= va_arg(args, tag_t);
	tag_t	objTypeTag				= NULLTAG;
	tag_t	CurrentRoleTag			= NULLTAG;
	tag_t	rev_tag					= NULLTAG;
	tag_t*	PartTaskTags			= NULLTAG;
	tag_t	PartTskTag				= NULLTAG;
	tag_t	TaskTag_class			= NULLTAG;
	tag_t*	status_list				= NULLTAG;
	tag_t*	rev_status_list			= NULLTAG;
	tag_t	tsk_dml_rel_type		= NULLTAG;
	tag_t*	DMLRevision				= NULLTAG;
	tag_t	DMLRevTag				= NULLTAG;
	tag_t	class_id1				= NULLTAG;
	tag_t	relation_type_PrtToTsk	= NULLTAG;

	char*	Item_ID_str			= NULL;
	char*	Item_ID_Rev_str		= NULL;
	char*	bcm_release_status1	= NULL;
	char*	bcm_part_type		= NULL;
	char*	bl_owning_user		= NULL;
	char*	username			= NULL;
	char*	info1				= NULL;
	char*	TaskId				= NULL;
	char*	parentID			= NULL;
	char*	parentrevID			= NULL;
	char*	PlantName			= NULL;
	char*	TaskRelStat			= NULL;
	char*	Rev_RelStat			= NULL;
	char*	class_name1			= NULL;
	char*	EcnType				= NULL;
	char*	bl_owning_group		= NULL;
	char*	SM_item_id			= NULL;
	char*	roleName			= NULL;
	char*	type_name			= NULL;
	char*	Task_class			= NULL;
	char*	Parent_object_type	= NULL;
	char*	bl_checked_out		= NULL;
	char*	checked_out_user	= NULL;
	char*	CurrentSessionUsr	= NULL;
	char*	Part_Aggregts		= NULL;
	char*	Parent_PartType		= NULL;
	char*	Item_ID_Check		= NULL;
	char	LcsAplWrkg[40];
	char	LcsAplRlzd[40];
	char	GetPlant[40];

	int Item_ID					= 0;
	int Item_Revision			= 0;
	int	rel_stat1				= 0;
	int	part_type				= 0;
	int	owning_user				= 0;
	int	owning_group			= 0;
	int	control_number_found1	= 0;
	int	n_entryCntrl1			= 3;
	int	count_task				= 0;
	int cnt_tk					= 0;
	int	st_count				= 0;
	int	rev_st_count			= 0;
	int	cnt_next				= 0;
	int	rev_cnt_next			= 0;
	int count_DML				= 0;
	int j						= 0;
	int	workingMBOMPrtFnd		= 0;
	int workingMBOMDMLFnd		= 0;
	int FlagGrpErr				= 0;
	int checked_out				= 0;

	char *qry_entryCntrl1[3]	= {"SYSCD","SUBSYSCD","Delete Indicator"};
	char **qry_valuesCntrl1		= (char **) MEM_alloc(5 * sizeof(char *));

	tag_t*	list_of_WSO_cntrl_tags1	= NULLTAG;
	tag_t	qryTagCntrl1			= NULLTAG;

	QRY_find2("Control Objects...", &qryTagCntrl1);
	if (qryTagCntrl1)
	{
		printf("\n tm_nonerc_Validation_add_method--Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="BOM_Modified";
		qry_valuesCntrl1[1]="Validation";
		qry_valuesCntrl1[2]="0";
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		printf("\n tm_nonerc_Validation_add_method--Number of control Obj Found is: %d",control_number_found1);fflush(stdout);

		if (control_number_found1>0)
		{
			printf("\n tm_nonerc_Validation_add_method--Live.. Ketan inside Main control object: tm_nonerc_Validation_add_method \n");fflush(stdout);

			ITKCALL(AOM_ask_value_string(list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &Part_Aggregts));
			printf("\n tm_nonerc_Validation_add_method--Part_Aggregts => %s ",Part_Aggregts);fflush(stdout);

			if (TCTYPE_ask_object_type(parent_tag,&objTypeTag)!=ITK_ok) PrintErrorStack();
			if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
			printf("\n  tm_nonerc_Validation_add_method--type_name => [%s]",type_name);fflush(stdout);

			if(parent_tag)
			{
				if(strcmp(type_name,"BOMLine")==0)
				{
					printf("\n tm_nonerc_Validation_add_method--Inside BOMLine type_name \n");fflush(stdout);

					ITK_CALL(SA_ask_current_role(&CurrentRoleTag));
					ITK_CALL(SA_ask_role_name2(CurrentRoleTag,&roleName));
					printf("\n tm_nonerc_Validation_add_method--roleName : %s\n",roleName); fflush(stdout);

					//ITK_CALL(BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision));
					//ITK_CALL(BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
					//ITK_CALL(BOM_line_ask_attribute_string(parent_tag, Item_ID, &Item_ID_str));
					//ITK_CALL(BOM_line_ask_attribute_string(parent_tag, Item_Revision, &Item_ID_Rev_str));

					if( AOM_ask_value_string(parent_tag,"bl_rev_item_revision_id",&Item_ID_Rev_str));
					if( AOM_ask_value_string(parent_tag,"bl_item_item_id",&Item_ID_str));

					printf("\n tm_nonerc_Validation_add_method--ItemRevision is [%s] and ItemID is: [%s]\n",Item_ID_Rev_str,Item_ID_str);
					if(ITEM_find_rev(Item_ID_str,Item_ID_Rev_str,&rev_tag)) PrintErrorStack();

					ITK_CALL(AOM_UIF_ask_value(rev_tag,"item_id",&parentID));
					ITK_CALL(AOM_UIF_ask_value(rev_tag,"item_revision_id",&parentrevID));

					printf("\n tm_nonerc_Validation_add_method--parentID is [%s] and parentrevID is: [%s]\n",parentID,parentrevID);

					//Added by Amar Kate

					//ITK_CALL(BOM_line_look_up_attribute ("bl_rev_checked_out",&checked_out));
					//ITK_CALL(BOM_line_ask_attribute_string(parent_tag, checked_out, &bl_checked_out));

					if(AOM_ask_value_string(parent_tag,"bl_rev_checked_out",&bl_checked_out));
					printf("\n tm_nonerc_Validation_add_method--Amar bl_checked_out is => %s \n", bl_checked_out);fflush(stdout);

					ITK_CALL(AOM_UIF_ask_value(rev_tag,"checked_out_user",&checked_out_user));
					printf("\n tm_nonerc_Validation_add_method--Amar checked_out_user is => %s \n", checked_out_user);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(rev_tag,"object_type",&Parent_object_type ));
					printf("\n tm_nonerc_Validation_add_method--Parent_object_type => %s \n",Parent_object_type);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(rev_tag,"t5_PartType",&Parent_PartType ));
					printf("\n tm_nonerc_Validation_add_method--Parent_PartType => %s \n",Parent_PartType);fflush(stdout);

					if(tc_strcmp(Parent_PartType,"M")==0 )
					{
						Item_ID_Check=subString(parentID,4,5);
						printf("\n tm_nonerc_Validation_add_method--Module Item_ID_Check => %s \n",Item_ID_Check);fflush(stdout);
					}

					POM_get_user_id (&CurrentSessionUsr);
					printf("\n tm_nonerc_Validation_add_method--Amar current Session user: %s\n",CurrentSessionUsr); fflush(stdout);

					//ITK_CALL(BOM_line_look_up_attribute ("bl_rev_owning_user",&owning_user));
					//ITK_CALL(BOM_line_ask_attribute_string(parent_tag, owning_user, &bl_owning_user));
					if( AOM_ask_value_string(parent_tag,"bl_rev_owning_user",&bl_owning_user));
					printf("\n tm_nonerc_Validation_add_method--bl_owning_user is => %s", bl_owning_user);fflush(stdout);

					//ITK_CALL(BOM_line_look_up_attribute ("bl_rev_owning_group",&owning_group));
					//ITK_CALL(BOM_line_ask_attribute_string(parent_tag, owning_group, &bl_owning_group));
					if( AOM_ask_value_string(parent_tag,"bl_rev_owning_group",&bl_owning_group));
					printf("\n tm_nonerc_Validation_add_method--bl_owning_group is => %s", bl_owning_group);fflush(stdout);

					PlantName=subString(roleName,3,4);
					printf("\n tm_nonerc_Validation_add_method--PlantName => %s\n", PlantName);fflush(stdout);

					ITK_CALL(POM_get_user_id (&username));
					printf("\n tm_nonerc_Validation_add_method--LogIN User ID is => %s \n", username);fflush(stdout);

					if (tc_strstr(roleName,"Support")!=NULL || (tc_strcmp(username,"infodba")==0) || (tc_strcmp(username,"loader")==0)|| (tc_strcmp(username,"aplloader")==0))
					{
						printf("\n tm_nonerc_Validation_add_method--Allowed to do Add part as User is Infodba/loader/aplloader/Support Group \n");fflush(stdout);
					}
					else if (tc_strstr(roleName,"MBOM")!=NULL || (tc_strstr(roleName,"APL")!=NULL) || (tc_strstr(roleName,"STD")!=NULL))
					{
						printf("\n tm_nonerc_Validation_add_method--Inside roleName : %s\n",roleName); fflush(stdout);

						if (tc_strstr(bl_checked_out,"Y")!=NULL) //checked out part bypass //Added By Amar Kate
						{
							printf("\n tm_nonerc_Validation_add_method--Amar Inside bl_checked_out Revision \n"); fflush(stdout);

							if (tc_strstr(checked_out_user,CurrentSessionUsr)!=NULL)
							{
								printf("\n tm_nonerc_Validation_add_method--Amar Addition of part in Assembly is allowed as it is Checkout Revision \n"); fflush(stdout);
							}
							else
							{
								FlagGrpErr=1;
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error, ITK_err, "Addition of part in Selected assembly is not allowed as the Parent Assembly is not checked out By Currnet user");
								return ITK_err;
							}
						}
						else if(tc_strcmp(Parent_object_type,"T5_ClrPartRevision")==0) //Color Part bypass //Added By Ketan
						{
							printf("\n tm_nonerc_Validation_add_method--Skip Validation for color part \n");fflush(stdout);
						}
						else if(tc_strstr(Part_Aggregts,Item_ID_Check)!=NULL) // Module bypass //Added By Ketan
						{
							printf("\n tm_nonerc_Validation_add_method--Skip Validation for Module Address => [%s] \n",Item_ID_Check);fflush(stdout);
						}
						// APL implementation
						else if (tc_strstr(roleName,"APL")!=NULL)
						{
							printf("\n tm_nonerc_Validation_add_method--add_method : Inside APL Role.. Checking Control Object  \n"); fflush(stdout);

							tag_t   qryTagCntrlobj_APL		= NULLTAG;
							tag_t*	list_of_cntrl_tags_APL	= NULLTAG;

							char*	qry_entryCntrl_APL[4] = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};
							char**	qry_valuesCntrl_APL	= (char **) MEM_alloc(5 * sizeof(char *));

							int controlObjfound_APL	= 0;
							int	n_entryCntrlobj_APL = 4;

							if(QRY_find2("Control Objects...", &qryTagCntrlobj_APL));

							if (qryTagCntrlobj_APL)
							{
								printf("\n tm_nonerc_Validation_add_method--Control Object Query Found \n");fflush(stdout);
								qry_valuesCntrl_APL[0]="BOM_Save";
								qry_valuesCntrl_APL[1]="APL";
								qry_valuesCntrl_APL[2]="0";
								qry_valuesCntrl_APL[3]="Live";

								if(QRY_execute(qryTagCntrlobj_APL, n_entryCntrlobj_APL, qry_entryCntrl_APL, qry_valuesCntrl_APL, &controlObjfound_APL, &list_of_cntrl_tags_APL));
							}
							else
							{
								printf("\n tm_nonerc_Validation_add_method--Control Object Query not Found  \n");fflush(stdout);
							}

							printf("\n tm_nonerc_Validation_add_method--controlObjfound_APL is ==> %d\n",controlObjfound_APL);fflush(stdout);

							if(controlObjfound_APL>0)
							{
								printf("\n tm_nonerc_Validation_add_method--Control Object is Live for APL \n"); fflush(stdout);

								int  workingAPLDMLFnd = 0;

								GRM_find_relation_type("CMHasSolutionItem",&relation_type_PrtToTsk);
								GRM_list_primary_objects_only(rev_tag,relation_type_PrtToTsk,&count_task,&PartTaskTags);

								printf("\n tm_nonerc_Validation_add_method--Number of Task => %d \n",count_task); fflush(stdout);

								if(count_task>0)
								{
									for (cnt_tk=0;cnt_tk<count_task ;cnt_tk++ )
									{
										TaskId		= NULL;

										PartTskTag	= PartTaskTags[cnt_tk];
										ITK_CALL(TCTYPE_ask_object_type(PartTskTag,&TaskTag_class));
										ITK_CALL(TCTYPE_ask_name2(TaskTag_class,&Task_class));

										printf("\n tm_nonerc_Validation_add_method--[%d] Task_class ...%s\n",cnt_tk,Task_class); fflush(stdout);

										if(tc_strcmp(Task_class,"T5_APLTaskRevision")==0)
										{
											ITK_CALL(AOM_ask_value_string(PartTskTag,"item_id",&TaskId));
											printf("\n tm_nonerc_Validation_add_method--TaskId %s.....\n",TaskId); fflush(stdout);

											GetPlantForDMLORTask1(TaskId,GetPlant);

											printf("\n tm_nonerc_Validation_add_method--GetPlant => %s and PlantName => %s ....\n",GetPlant,PlantName); fflush(stdout);

											if(tc_strcmp(GetPlant,PlantName)==0)
											{
												printf("\n tm_nonerc_Validation_add_method--Same Plant task Found \n"); fflush(stdout);

												GetPlantWiseRelStatAtAPL1(TaskId,LcsAplWrkg,LcsAplRlzd);
												printf("\n tm_nonerc_Validation_add_method--LcsAplWrkg: %s \n",LcsAplWrkg);
												printf("\n tm_nonerc_Validation_add_method--LcsAplRlzd: %s \n",LcsAplRlzd);

												ITK_CALL(WSOM_ask_release_status_list(PartTskTag,&st_count,&status_list));
												printf("\n tm_nonerc_Validation_add_method--st_count :%d is\n",st_count);fflush(stdout);

												if(st_count>0)
												{
													for (cnt_next=0;cnt_next< st_count;cnt_next++ )
													{
														TaskRelStat=NULL;
														ITK_CALL(AOM_ask_name(status_list[cnt_next],&TaskRelStat));
														printf("\n tm_nonerc_Validation_add_method--TaskRelStat is :%s\n",TaskRelStat);fflush(stdout);

														if ((tc_strcmp(TaskRelStat,LcsAplWrkg)==0))
														{
															ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
															if (tsk_dml_rel_type!=NULLTAG)
															{
																ITK_CALL(GRM_list_primary_objects_only(PartTskTag,tsk_dml_rel_type,&count_DML,&DMLRevision));
																printf("\n tm_nonerc_Validation_add_method--APL DML Revision from Task : %d",count_DML); fflush(stdout);
															}

															for (j=0;j<count_DML;j++ )
															{
																DMLRevTag = DMLRevision[j];

																ITK_CALL(POM_class_of_instance(DMLRevTag,&class_id1));
																ITK_CALL(POM_name_of_class(class_id1,&class_name1));
																printf("\n tm_nonerc_Validation_add_method--class_name found1 :%s \n",class_name1); fflush(stdout);

																if(tc_strcmp(class_name1,"T5_APLDMLRevision")==0)
																{
																	ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_EcnType",&EcnType));
																	printf("\n tm_nonerc_Validation_add_method--APLDMLtype is :%s",EcnType); fflush(stdout);

																	if((tc_strcmp(EcnType,"APLSTR")==0) || (tc_strcmp(EcnType,"MR")==0)|| (tc_strcmp(EcnType,"IPBT")==0))
																	{
																		printf("\n tm_nonerc_Validation_add_method--Inside ECN type check \n"); fflush(stdout);
																		workingAPLDMLFnd++;
																		printf("\n tm_nonerc_Validation_add_method--Addition of part in Assembly is allowed as it is attached to APL Re-Structuring DML \n"); fflush(stdout);
																		break;
																	}

																	// Checking ERC Task // TZ 1.78
																	char    *qry_entryCntrlERCTask[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};
																	char	**qry_valuesCntrlERCTask= (char **) MEM_alloc(5 * sizeof(char *));

																	tag_t   qryTagCntrlERCTask     = NULLTAG;

																	int     n_entryCntrlERCTask    = 3;
																	int  control_number_foundERCTask=0;

																	tag_t *list_of_WSO_cntrl_tagsERCTask=NULLTAG;

																	char*	TaskAggregts		=	NULL;

																	if(QRY_find2("Control Objects...", &qryTagCntrlERCTask));
																	if (qryTagCntrlERCTask)
																	{
																		printf("\n tm_nonerc_Validation_add_method--Control Object Query Found \n");fflush(stdout);

																		qry_valuesCntrlERCTask[0]="PP_PM_Task";
																		qry_valuesCntrlERCTask[1]="ERC_Task";
																		qry_valuesCntrlERCTask[2]="0";

																		if(QRY_execute(qryTagCntrlERCTask, n_entryCntrlERCTask, qry_entryCntrlERCTask, qry_valuesCntrlERCTask, &control_number_foundERCTask, &list_of_WSO_cntrl_tagsERCTask));
																	}

																	printf("\n tm_nonerc_Validation_add_method--add_method : control_number_foundERCTask is => %d\n",control_number_foundERCTask);fflush(stdout);

																	if(control_number_foundERCTask>0)
																	{
																		printf("\n tm_nonerc_Validation_add_method--Inside control_number_foundERCTask \n");fflush(stdout);
																		ITKCALL(AOM_ask_value_string(list_of_WSO_cntrl_tagsERCTask[0], "t5_Userinfo1", &TaskAggregts));
																		printf("\n tm_nonerc_Validation_add_method--TaskAggregts => %s \n",TaskAggregts);fflush(stdout);

																		printf("\n tm_nonerc_Validation_add_method--TaskId %s.....\n",TaskId); fflush(stdout);

																		char*	Task_Suffix	= NULL;

																		Task_Suffix=subString(TaskId,2,2);
																		printf("\n tm_nonerc_Validation_add_method--Task_Suffix: %s\n",Task_Suffix);fflush(stdout);

																		if(tc_strstr(TaskAggregts,Task_Suffix)!=NULL)
																		{
																			printf("\n tm_nonerc_Validation_add_method--Inside PP/PM/JP/JM/LP/LM/CU/JU/LU check \n",EcnType); fflush(stdout);
																			workingAPLDMLFnd++;
																			printf("\n tm_nonerc_Validation_add_method--Addition of part in Assembly is allowed as it is attached to PP/PM/JP/JM/LP/LM/CU/JU/LU DML \n"); fflush(stdout);
																			break;
																		}
																	}
																}
															}
														}
														if (workingAPLDMLFnd>0)
														{
															printf("\n tm_nonerc_Validation_add_method--lcsStP for loope break => %d \n",workingAPLDMLFnd); fflush(stdout);
															break;
														}
													}
												}

											}
										}
										if (workingAPLDMLFnd>0)
										{
											printf("\n tm_nonerc_Validation_add_method--i for loope break => %d \n",workingAPLDMLFnd);fflush(stdout);
											break;
										}
									}
								}
								if(workingAPLDMLFnd == 0)
								{
									FlagGrpErr=1;
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error, ITK_err, "Addition of part in Selected assembly is not allowed as the Selected Assembly is not attached to any APL Restructuring DML");
									return ITK_err;
								}
							}
							else
							{
								printf("\n tm_nonerc_Validation_add_method--Control Object is Not Live for APL \n"); fflush(stdout);
							}

						}
						// MBOM implementation
						else if (tc_strstr(roleName,"MBOM")!=NULL)
						{
							printf("\n tm_nonerc_Validation_add_method--add_method : Inside MBOM Role.. Checking Control Object \n"); fflush(stdout);

							tag_t   qryTagCntrlobj_MBOM		= NULLTAG;
							tag_t*	list_of_cntrl_tags_MBOM	= NULLTAG;

							char*	qry_entryCntrl_MBOM[4] = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};
							char**	qry_valuesCntrl_MBOM	= (char **) MEM_alloc(5 * sizeof(char *));

							int controlObjfound_MBOM = 0;
							int	n_entryCntrlobj_MBOM = 4;

							if(QRY_find2("Control Objects...", &qryTagCntrlobj_MBOM));

							if (qryTagCntrlobj_MBOM)
							{
								printf("\n tm_nonerc_Validation_add_method--Control Object Query Found \n");fflush(stdout);
								qry_valuesCntrl_MBOM[0]="BOM_Save";
								qry_valuesCntrl_MBOM[1]="MBOM";
								qry_valuesCntrl_MBOM[2]="0";
								qry_valuesCntrl_MBOM[3]="Live";

								if(QRY_execute(qryTagCntrlobj_MBOM, n_entryCntrlobj_MBOM, qry_entryCntrl_MBOM, qry_valuesCntrl_MBOM, &controlObjfound_MBOM, &list_of_cntrl_tags_MBOM));
							}
							else
							{
								printf("\n tm_nonerc_Validation_add_method--Control Object Query not Found  \n");fflush(stdout);
							}

							printf("\n tm_nonerc_Validation_add_method--controlObjfound_MBOM is ==> %d\n",controlObjfound_MBOM);fflush(stdout);

							if(controlObjfound_MBOM>0)
							{
								printf("\n tm_nonerc_Validation_add_method--Control Object is Live for MBOM \n"); fflush(stdout);

								char* lcsToMBOMWorking=NULL;
								lcsToMBOMWorking =(char *) MEM_alloc(20 * sizeof(char *));
								strcpy(lcsToMBOMWorking,"T5_MBOMWorking");

								ITK_CALL(WSOM_ask_release_status_list(rev_tag,&rev_st_count,&rev_status_list));
								printf("\n tm_nonerc_Validation_add_method--rev_st_count :%d is\n",rev_st_count);fflush(stdout);

								if ((tc_strcmp(bl_owning_group,"MBOM")==0) || (tc_strcmp(bl_owning_group,"dba")==0)|| (tc_strcmp(bl_owning_group,"loader")==0)|| (tc_strcmp(bl_owning_group,"aplloader")==0)) // For MBOM User Created Part
								{
									if(rev_st_count>0)
									{
										for (rev_cnt_next=0;rev_cnt_next< rev_st_count;rev_cnt_next++ )
										{
											TaskRelStat=NULL;
											ITK_CALL(AOM_ask_name(rev_status_list[rev_cnt_next],&Rev_RelStat));
											printf("\n tm_nonerc_Validation_add_method--Rev_RelStat is :%s\n",Rev_RelStat);fflush(stdout);

											if ((tc_strcmp(Rev_RelStat,lcsToMBOMWorking)==0))
											{
												printf("\n tm_nonerc_Validation_add_method--Test 1. Checking the release status for MBOM..\n");fflush(stdout);
												workingMBOMPrtFnd=1;
												break;
											}
										}
									}
									if(workingMBOMPrtFnd == 0)
									{
										FlagGrpErr=1;
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error, ITK_err, "Selected Design-Revision is not MBOM-Working.Restructuring is allowed for MBOM-Working Design-Revision.");
										return ITK_err;

									}
								}
								else
								{
									if(rev_st_count>0)
									{
										for (rev_cnt_next=0;rev_cnt_next< rev_st_count;rev_cnt_next++ )
										{
											TaskRelStat=NULL;
											ITK_CALL(AOM_ask_name(rev_status_list[rev_cnt_next],&Rev_RelStat));
											printf("\n tm_nonerc_Validation_add_method--Rev_RelStat is :%s\n",Rev_RelStat);fflush(stdout);

											if ((tc_strcmp(Rev_RelStat,"T5_LcsErcRlzd")==0)) // For ERC Created Part
											{
												printf("\n tm_nonerc_Validation_add_method--Test 2. Checking the release status for MBOM..\n");fflush(stdout);
												workingMBOMPrtFnd=1;
												break;
											}
										}
									}
									if(workingMBOMPrtFnd == 0)
									{
										FlagGrpErr=1;
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error, ITK_err, "Selected Design-Revision is not ERC Released.Restructuring is allowed for ERC Released and above Design-Revision.");
										return ITK_err;

									}
									if(FlagGrpErr == 0)
									{
										GRM_find_relation_type("CMHasSolutionItem",&relation_type_PrtToTsk);
										GRM_list_primary_objects_only(rev_tag,relation_type_PrtToTsk,&count_task,&PartTaskTags);

										printf("\n tm_nonerc_Validation_add_method--Number of MBOM Task => %d \n",count_task); fflush(stdout);

										if(count_task>0)
										{
											for (cnt_tk=0;cnt_tk<count_task ;cnt_tk++ )
											{
												PartTskTag=PartTaskTags[cnt_tk];
												ITK_CALL(TCTYPE_ask_object_type(PartTskTag,&TaskTag_class));
												ITK_CALL(TCTYPE_ask_name2(TaskTag_class,&Task_class));

												printf("\n tm_nonerc_Validation_add_method--[%d] MBOM Task_class ...%s\n",cnt_tk,Task_class); fflush(stdout);

												if(tc_strcmp(Task_class,"T5_MBOMTASKRevision")==0)
												{
													ITK_CALL(AOM_ask_value_string(PartTskTag,"item_id",&TaskId));
													printf("\n tm_nonerc_Validation_add_method--MBOM TaskId %s.....\n",TaskId); fflush(stdout);

													GetPlantForDMLORTask1(TaskId,GetPlant);

													printf("\n tm_nonerc_Validation_add_method--GetPlant => %s and PlantName => %s ....\n",GetPlant,PlantName); fflush(stdout);

													if(tc_strcmp(GetPlant,PlantName)==0)
													{
														printf("\n tm_nonerc_Validation_add_method--Same Plant task Found--"); fflush(stdout);

														printf("\t lcsToMBOMWorking: %s \n",lcsToMBOMWorking);

														ITK_CALL(WSOM_ask_release_status_list(PartTskTag,&st_count,&status_list));
														printf("\n tm_nonerc_Validation_add_method--st_count :%d is\n",st_count);fflush(stdout);

														if(st_count>0)
														{
															for (cnt_next=0;cnt_next< st_count;cnt_next++ )
															{
																TaskRelStat=NULL;
																ITK_CALL(AOM_ask_name(status_list[cnt_next],&TaskRelStat));
																printf("\n tm_nonerc_Validation_add_method--MBOM TaskRelStat is :%s\n",TaskRelStat);fflush(stdout);

																if ((tc_strcmp(TaskRelStat,lcsToMBOMWorking)==0))
																{
																	ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
																	if (tsk_dml_rel_type!=NULLTAG)
																	{
																		ITK_CALL(GRM_list_primary_objects_only(PartTskTag,tsk_dml_rel_type,&count_DML,&DMLRevision));
																		printf("\n tm_nonerc_Validation_add_method--MBOM DML Revision from Task : %d",count_DML); fflush(stdout);
																	}

																	for (j=0;j<count_DML;j++ )
																	{
																		DMLRevTag = DMLRevision[j];

																		ITK_CALL(POM_class_of_instance(DMLRevTag,&class_id1));
																		ITK_CALL(POM_name_of_class(class_id1,&class_name1));
																		printf("\n tm_nonerc_Validation_add_method--class_name found1 :%s \n",class_name1); fflush(stdout);

																		if(tc_strcmp(class_name1,"T5_MBOMDMLRevision")==0)
																		{
																			ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_MBOMRlzType",&EcnType));
																			printf("\n tm_nonerc_Validation_add_method--t5_MBOMRlzType is :%s",EcnType); fflush(stdout);

																			if((tc_strcmp(EcnType,"VCREST")==0) || (tc_strcmp(EcnType,"MFG_SubMdRlz")==0))
																			{
																				workingMBOMDMLFnd++;
																				printf("\n tm_nonerc_Validation_add_method--Addition of part in Selected Assembly is allowed as it is attached to MBOM VC Re-Structuring DML.\n"); fflush(stdout);
																				break;
																			}
																		}
																	}
																}
																if (workingMBOMDMLFnd>0)
																{
																	printf("\n tm_nonerc_Validation_add_method--lcsStP for loope break => %d \n",workingMBOMDMLFnd); fflush(stdout);
																	break;
																}
															}
														}

													}
												}
												if (workingMBOMDMLFnd>0)
												{
													printf("\n tm_nonerc_Validation_add_method--i for loope break => %d \n",workingMBOMDMLFnd);fflush(stdout);
													break;
												}
											}
										}
										if(workingMBOMDMLFnd == 0)
										{
											FlagGrpErr=1;
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error, ITK_err, "Addition of part in selected Design-Revision is not allowed as the selected Design-Revision is not attached to MBOM Working DML with MBOM-Release-Type VC-Restructuring/MFG Submodule Release");
											return ITK_err;
										}
									}
								}
							}
							else
							{
								printf("\n tm_nonerc_Validation_add_method--Control Object is Live Not for MBOM \n"); fflush(stdout);
							}

						}
						// STD implementation
						else if (tc_strstr(roleName,"STD")!=NULL)
						{
							printf("\n tm_nonerc_Validation_add_method--add_method : Inside STD Role.. Checking Control Object \n"); fflush(stdout);
							printf("\n tm_nonerc_Validation_add_method--PlantName => %s \n",PlantName); fflush(stdout);

							tag_t   qryTagCntrlobj_STD		= NULLTAG;
							tag_t*	list_of_cntrl_tags_STD	= NULLTAG;

							char*	qry_entryCntrl_STD[4] = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};
							char**	qry_valuesCntrl_STD	= (char **) MEM_alloc(5 * sizeof(char *));

							int controlObjfound_STD = 0;
							int	n_entryCntrlobj_STD = 4;

							if(QRY_find2("Control Objects...", &qryTagCntrlobj_STD));

							if (qryTagCntrlobj_STD)
							{
								printf("\n tm_nonerc_Validation_add_method--Control Object Query Found \n");fflush(stdout);
								qry_valuesCntrl_STD[0]="BOM_Save";
								qry_valuesCntrl_STD[1]="STD";
								qry_valuesCntrl_STD[2]="0";
								qry_valuesCntrl_STD[3]="Live";

								if(QRY_execute(qryTagCntrlobj_STD, n_entryCntrlobj_STD, qry_entryCntrl_STD, qry_valuesCntrl_STD, &controlObjfound_STD, &list_of_cntrl_tags_STD));
							}
							else
							{
								printf("\n tm_nonerc_Validation_add_method--Control Object Query not Found  \n");fflush(stdout);
							}

							printf("\n tm_nonerc_Validation_add_method--controlObjfound_STD is ==> %d\n",controlObjfound_STD);fflush(stdout);

							if(controlObjfound_STD>0)
							{
								printf("\n tm_nonerc_Validation_add_method--Control Object is Live for STD \n"); fflush(stdout);

								char LcsStdWrkg[40];
								char LcsStdRlzd[40];
								char LcsStdRestLcs[40];
								char LcsStdReRestLcs[40];
								int workingSMDMLFnd=0;
								int relStatFnd=0;

								GetPlantWise_STD_LCS(PlantName,LcsStdWrkg,LcsStdRlzd);
								GetPlantWise_STDRestrecture_LCS(PlantName,LcsStdRestLcs,LcsStdReRestLcs);
								printf("\n tm_nonerc_Validation_add_method--LcsStdWrkg: %s ",LcsStdWrkg);
								printf("\n tm_nonerc_Validation_add_method--LcsStdRlzd: %s \n",LcsStdRlzd);
								printf("\n tm_nonerc_Validation_add_method--LcsStdRestLcs: %s \n",LcsStdRestLcs);
								printf("\n ABtm_nonerc_Validation_add_method--LcsStdReRestLcs: %s \n",LcsStdReRestLcs);

								ITK_CALL(WSOM_ask_release_status_list(rev_tag,&rev_st_count,&rev_status_list));
								printf("\n tm_nonerc_Validation_add_method--rev_st_count :%d is\n",rev_st_count);fflush(stdout);

								if(rev_st_count>0)
								{
									for (rev_cnt_next=0;rev_cnt_next< rev_st_count;rev_cnt_next++ )
									{
										TaskRelStat=NULL;
										ITK_CALL(AOM_ask_name(rev_status_list[rev_cnt_next],&Rev_RelStat));
										printf("\n tm_nonerc_Validation_add_method--Rev_RelStat is :%s\n",Rev_RelStat);fflush(stdout);

										if ((tc_strcmp(Rev_RelStat,LcsStdRlzd)==0))
										{
											printf("\n tm_nonerc_Validation_add_method--Inside STD Released Release Status \n");fflush(stdout);
											relStatFnd++;
										}
									}
								}
								if(relStatFnd==0)
								{
									printf("\n tm_nonerc_Validation_add_method--Inside error message for STDSI \n");fflush(stdout);
									FlagGrpErr++;

									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error, ITK_err, "Please select only STDSI Released Part for adding in Structure.");
									return ITK_err;

								}
								if(FlagGrpErr==0)
								{
									GRM_find_relation_type("CMHasSolutionItem",&relation_type_PrtToTsk);
									GRM_list_primary_objects_only(rev_tag,relation_type_PrtToTsk,&count_task,&PartTaskTags);

									printf("\n tm_nonerc_Validation_add_method--Number of SM Task => %d \n",count_task); fflush(stdout);

									if(count_task>0)
									{
										for (cnt_tk=0;cnt_tk<count_task ;cnt_tk++ )
										{
											PartTskTag=PartTaskTags[cnt_tk];
											ITK_CALL(TCTYPE_ask_object_type(PartTskTag,&TaskTag_class));
											ITK_CALL(TCTYPE_ask_name2(TaskTag_class,&Task_class));

											printf("\n tm_nonerc_Validation_add_method--[%d] SM Task_class ...%s\n",cnt_tk,Task_class); fflush(stdout);

											if(tc_strcmp(Task_class,"T5_SMDMLTaskRevision")==0)
											{
												ITK_CALL(AOM_ask_value_string(PartTskTag,"item_id",&TaskId));
												printf("\n tm_nonerc_Validation_add_method--SM TaskId %s.....\n",TaskId); fflush(stdout);

												GetPlantForDMLORTask1(TaskId,GetPlant);

												printf("\n tm_nonerc_Validation_add_method--GetPlant => %s and PlantName => %s ....\n",GetPlant,PlantName); fflush(stdout);

												if(tc_strcmp(GetPlant,PlantName)==0)
												{
													printf("\n tm_nonerc_Validation_add_method--Same Plant task Found \n"); fflush(stdout);

													ITK_CALL(WSOM_ask_release_status_list(PartTskTag,&st_count,&status_list));
													printf("\n tm_nonerc_Validation_add_method--st_count :%d is\n",st_count);fflush(stdout);

													if(st_count>0)
													{
														for (cnt_next=0;cnt_next< st_count;cnt_next++ )
														{
															TaskRelStat=NULL;
															ITK_CALL(AOM_ask_name(status_list[cnt_next],&TaskRelStat));
															printf("\n tm_nonerc_Validation_add_method--SM TaskRelStat is :%s\n",TaskRelStat);fflush(stdout);

															if ((tc_strcmp(TaskRelStat,LcsStdWrkg)==0)||
																(tc_strcmp(TaskRelStat,LcsStdRestLcs)==0)||
																(tc_strcmp(TaskRelStat,LcsStdReRestLcs)==0))
															{
																workingSMDMLFnd++;
																ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
																if (tsk_dml_rel_type!=NULLTAG)
																{
																	ITK_CALL(GRM_list_primary_objects_only(PartTskTag,tsk_dml_rel_type,&count_DML,&DMLRevision));
																	printf("\n tm_nonerc_Validation_add_method--MBOM DML Revision from Task : %d",count_DML); fflush(stdout);
																}

																for (j=0;j<count_DML;j++ )
																{
																	DMLRevTag = DMLRevision[j];

																	ITK_CALL(POM_class_of_instance(DMLRevTag,&class_id1));
																	ITK_CALL(POM_name_of_class(class_id1,&class_name1));
																	printf("\n tm_nonerc_Validation_add_method--class_name found1 :%s \n",class_name1); fflush(stdout);

																	if(tc_strcmp(class_name1,"T5_SMDMLRevision")==0)
																	{
																		ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&SM_item_id));
																		printf("\n tm_nonerc_Validation_add_method--SM_item_id is :%s",SM_item_id); fflush(stdout);

																	}
																}
															}
														}
													}
												}
											}
										}
									}
									if(workingSMDMLFnd==0)
									{
										FlagGrpErr++;
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error, ITK_err, "Part is not attached to STDSI Working SMDML.\n Please attach the Part to SMDML and then perform restrcturing.");
										return ITK_err;
									}
								}
							}
							else
							{
								printf("\n tm_nonerc_Validation_add_method--Control Object is Not Live for STD "); fflush(stdout);
							}
						}
					}
				}
			}
		}
	}

	printf("\n tm_nonerc_Validation_add_method--Completed processing------- \n"); fflush(stdout);

	return ITK_ok;
}

extern DLLAPI int tm_nonerc_Validation_cut_method(METHOD_message_t *msg, va_list args) // Ketan
{
	printf("\n Inside Ketan function tm_nonerc_Validation_cut_method calling \n");fflush(stdout);

	int error_code = ITK_ok;

	tag_t	bomline_tag				= va_arg(args, tag_t);
	tag_t	objTypeTag				= NULLTAG;
	tag_t	window					= NULLTAG;
	tag_t	top_bom_line			= NULLTAG;
	tag_t	CurrentRoleTag			= NULLTAG;
	tag_t	rev_tag					= NULLTAG;
	tag_t*	PartTaskTags			= NULLTAG;
	tag_t	PartTskTag				= NULLTAG;
	tag_t	TaskTag_class			= NULLTAG;
	tag_t*	status_list				= NULLTAG;
	tag_t*	rev_status_list			= NULLTAG;
	tag_t	tsk_dml_rel_type		= NULLTAG;
	tag_t*	DMLRevision				= NULLTAG;
	tag_t	DMLRevTag				= NULLTAG;
	tag_t	class_id1				= NULLTAG;
	tag_t	relation_type_PrtToTsk	= NULLTAG;

	char*	Item_ID_str			= NULL;
	char*	Item_ID_Rev_str		= NULL;
	char*	bcm_release_status1	= NULL;
	char*	bcm_part_type		= NULL;
	char*	bl_owning_user		= NULL;
	char*	username			= NULL;
	char*	info1				= NULL;
	char*	TaskId				= NULL;
	char*	parentID			= NULL;
	char*	parentrevID			= NULL;
	char*	PlantName			= NULL;
	char*	TaskRelStat			= NULL;
	char*	Rev_RelStat			= NULL;
	char*	class_name1			= NULL;
	char*	EcnType				= NULL;
	char*	bl_owning_group		= NULL;
	char*	SM_item_id			= NULL;
	char*	roleName			= NULL;
	char*	type_name			= NULL;
	char*	Task_class			= NULL;
	char*	Parent_object_type	= NULL;
	char*	bl_checked_out		= NULL;
	char*	checked_out_user	= NULL;
	char*	CurrentSessionUsr	= NULL;
	char*	Part_Aggregts		= NULL;
	char*	Parent_PartType		= NULL;
	char*	Item_ID_Check		= NULL;
	char	LcsAplWrkg[40];
	char	LcsAplRlzd[40];
	char	GetPlant[40];

	int Item_ID					= 0;
	int Item_Revision			= 0;
	int	rel_stat1				= 0;
	int	part_type				= 0;
	int	owning_user				= 0;
	int	owning_group			= 0;
	int	control_number_found1	= 0;
	int	n_entryCntrl1			= 3;
	int	count_task				= 0;
	int cnt_tk					= 0;
	int	st_count				= 0;
	int	rev_st_count			= 0;
	int	cnt_next				= 0;
	int	rev_cnt_next			= 0;
	int count_DML				= 0;
	int j						= 0;
	int	workingMBOMPrtFnd		= 0;
	int workingMBOMDMLFnd		= 0;
	int FlagGrpErr				= 0;
	int checked_out				= 0;

	char *qry_entryCntrl1[3]	= {"SYSCD","SUBSYSCD","Delete Indicator"};
	char **qry_valuesCntrl1		= (char **) MEM_alloc(5 * sizeof(char *));

	tag_t*	list_of_WSO_cntrl_tags1	= NULLTAG;
	tag_t	qryTagCntrl1			= NULLTAG;

	QRY_find2("Control Objects...", &qryTagCntrl1);

	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="BOM_Modified";
		qry_valuesCntrl1[1]="Validation";
		qry_valuesCntrl1[2]="0";
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		printf("\n tm_nonerc_Validation_cut_method--Number of control Obj Found is: %d",control_number_found1);fflush(stdout);

		if (control_number_found1>0)
		{
			printf("\n tm_nonerc_Validation_cut_method--Live.. Ketan inside Main control object: tm_nonerc_Validation_cut_method \n");fflush(stdout);

			ITKCALL(AOM_ask_value_string(list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &Part_Aggregts));
			printf("\n tm_nonerc_Validation_cut_method--Part_Aggregts => %s ",Part_Aggregts);fflush(stdout);

			if (TCTYPE_ask_object_type(bomline_tag,&objTypeTag)!=ITK_ok) PrintErrorStack();
			if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();

			printf("\n tm_nonerc_Validation_cut_method--type_name => %s\n",type_name);fflush(stdout);

			if(strcmp(type_name,"BOMLine")==0)
			{
				printf("\n tm_nonerc_Validation_cut_method--Inside BOMLine type_name of tm_nonerc_Validation_cut_method ");fflush(stdout);

				if(BOM_line_ask_window(bomline_tag,&window)!=ITK_ok) PrintErrorStack();
				if(window)
				{
					if(BOM_ask_window_top_line(window,&top_bom_line)!=ITK_ok) PrintErrorStack();
					if(top_bom_line)
					{
						ITK_CALL(SA_ask_current_role(&CurrentRoleTag));
						ITK_CALL(SA_ask_role_name2(CurrentRoleTag,&roleName));
						printf("\n tm_nonerc_Validation_cut_method--roleName : %s ",roleName); fflush(stdout);

						//ITK_CALL(BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision));
						//ITK_CALL(BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
						//ITK_CALL(BOM_line_ask_attribute_string(top_bom_line, Item_ID, &Item_ID_str));
						//ITK_CALL(BOM_line_ask_attribute_string(top_bom_line, Item_Revision, &Item_ID_Rev_str));

						if( AOM_ask_value_string(top_bom_line,"bl_rev_item_revision_id",&Item_ID_Rev_str));
						if( AOM_ask_value_string(top_bom_line,"bl_item_item_id",&Item_ID_str));

						printf("\n tm_nonerc_Validation_cut_method--ItemRevision is [%s] and ItemID is: [%s]\n",Item_ID_Rev_str,Item_ID_str);
						if(ITEM_find_rev(Item_ID_str,Item_ID_Rev_str,&rev_tag)!=ITK_ok) PrintErrorStack();

						ITK_CALL(AOM_UIF_ask_value(rev_tag,"item_id",&parentID));
						ITK_CALL(AOM_UIF_ask_value(rev_tag,"item_revision_id",&parentrevID));

						printf("\n tm_nonerc_Validation_cut_method--parentID is [%s] and parentrevID is: [%s]\n",parentID,parentrevID);

						//Added by Amar Kate

						//ITK_CALL(BOM_line_look_up_attribute ("bl_rev_checked_out",&checked_out));
						//ITK_CALL(BOM_line_ask_attribute_string(top_bom_line, checked_out, &bl_checked_out));
						if( AOM_ask_value_string(top_bom_line,"bl_rev_checked_out",&bl_checked_out));
						printf("\n tm_nonerc_Validation_cut_method--bl_checked_out is => %s \n", bl_checked_out);fflush(stdout);

						ITK_CALL(AOM_UIF_ask_value(rev_tag,"checked_out_user",&checked_out_user));
						printf("\n tm_nonerc_Validation_cut_method--checked_out_user is => %s \n", checked_out_user);fflush(stdout);

						ITK_CALL(AOM_ask_value_string(rev_tag,"object_type",&Parent_object_type ));
						printf("\n tm_nonerc_Validation_cut_method--Parent_object_type => %s \n",Parent_object_type);fflush(stdout);

						ITK_CALL(AOM_ask_value_string(rev_tag,"t5_PartType",&Parent_PartType ));
						printf("\n tm_nonerc_Validation_cut_method--Parent_PartType => %s \n",Parent_PartType);fflush(stdout);

						if(tc_strcmp(Parent_PartType,"M")==0 )
						{
							Item_ID_Check=subString(parentID,4,5);
							printf("\n tm_nonerc_Validation_cut_method--Module Item_ID_Check => %s \n",Item_ID_Check);fflush(stdout);
						}

						POM_get_user_id (&CurrentSessionUsr);
						printf("\n tm_nonerc_Validation_cut_method--current Session user: %s\n",CurrentSessionUsr); fflush(stdout);

						//ITK_CALL(BOM_line_look_up_attribute ("bl_rev_owning_user",&owning_user));
						//ITK_CALL(BOM_line_ask_attribute_string(top_bom_line, owning_user, &bl_owning_user));
						if( AOM_ask_value_string(top_bom_line,"bl_rev_owning_user",&bl_owning_user));
						printf("\n tm_nonerc_Validation_cut_method--bl_owning_user is => %s", bl_owning_user);fflush(stdout);

						//ITK_CALL(BOM_line_look_up_attribute ("bl_rev_owning_group",&owning_group));
						//ITK_CALL(BOM_line_ask_attribute_string(top_bom_line, owning_group, &bl_owning_group));
						if( AOM_ask_value_string(top_bom_line,"bl_rev_owning_group",&bl_owning_group));
						printf("\n tm_nonerc_Validation_cut_method--bl_owning_group is => %s", bl_owning_group);fflush(stdout);

						PlantName=subString(roleName,3,4);
						printf("\n tm_nonerc_Validation_cut_method--PlantName => %s\n", PlantName);fflush(stdout);

						ITK_CALL(POM_get_user_id (&username));
						printf("\n tm_nonerc_Validation_cut_method--LogIN User ID is => %s \n", username);fflush(stdout);

						if (tc_strstr(roleName,"Support")!=NULL || (tc_strcmp(username,"infodba")==0) || (tc_strcmp(username,"loader")==0)|| (tc_strcmp(username,"aplloader")==0))
						{
							printf("\n tm_nonerc_Validation_cut_method--Allowed to do Deletion part as User is Infodba/loader/aplloader/Support Group \n");fflush(stdout);
						}
						else if (tc_strstr(roleName,"MBOM")!=NULL || (tc_strstr(roleName,"APL")!=NULL) || (tc_strstr(roleName,"STD")!=NULL))
						{
							printf("\n tm_nonerc_Validation_cut_method--Inside roleName : %s\n",roleName); fflush(stdout);

							if (tc_strstr(bl_checked_out,"Y")!=NULL) //Added By Amar //checked out part bypass
							{
								printf("\n tm_nonerc_Validation_cut_method--Amar Inside bl_checked_out Revision \n"); fflush(stdout);

								if (tc_strstr(checked_out_user,CurrentSessionUsr)!=NULL)
								{
									printf("\n tm_nonerc_Validation_cut_method--Amar Deletion of part in Assembly is allowed as it is Checkout Revision \n"); fflush(stdout);
								}
								else
								{
									FlagGrpErr=1;
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error, ITK_err, "Deletion of part in Selected assembly is not allowed as the Parent Assembly is not checked out By Currnet user");
									return ITK_err;
								}
							}
							else if(tc_strcmp(Parent_object_type,"T5_ClrPartRevision")==0) //Color Part bypass //Added By Ketan
							{
								printf("\n tm_nonerc_Validation_cut_method--Skip Validation for color part \n");fflush(stdout);
							}
							else if(tc_strstr(Part_Aggregts,Item_ID_Check)!=NULL) // Module bypass //Added By Ketan
							{
								printf("\n tm_nonerc_Validation_cut_method--Skip Validation for Module Address => [%s] \n",Item_ID_Check);fflush(stdout);
							}

							// APL implementation
							else if (tc_strstr(roleName,"APL")!=NULL)
							{
								printf("\n tm_nonerc_Validation_cut_method--cut_method : Inside APL Role.. Checking Control Object  \n"); fflush(stdout);

								tag_t   qryTagCntrlobj_APL		= NULLTAG;
								tag_t*	list_of_cntrl_tags_APL	= NULLTAG;

								char*	qry_entryCntrl_APL[4] = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};
								char**	qry_valuesCntrl_APL	= (char **) MEM_alloc(5 * sizeof(char *));

								int controlObjfound_APL	= 0;
								int	n_entryCntrlobj_APL = 4;

								if(QRY_find2("Control Objects...", &qryTagCntrlobj_APL));

								if (qryTagCntrlobj_APL)
								{
									printf("\n tm_nonerc_Validation_cut_method--Control Object Query Found \n");fflush(stdout);
									qry_valuesCntrl_APL[0]="BOM_Save";
									qry_valuesCntrl_APL[1]="APL";
									qry_valuesCntrl_APL[2]="0";
									qry_valuesCntrl_APL[3]="Live";

									if(QRY_execute(qryTagCntrlobj_APL, n_entryCntrlobj_APL, qry_entryCntrl_APL, qry_valuesCntrl_APL, &controlObjfound_APL, &list_of_cntrl_tags_APL));
								}
								else
								{
									printf("\n tm_nonerc_Validation_cut_method--Control Object Query not Found  \n");fflush(stdout);
								}

								printf("\n tm_nonerc_Validation_cut_method--controlObjfound_APL is ==> %d\n",controlObjfound_APL);fflush(stdout);

								if(controlObjfound_APL>0)
								{
									printf("\n tm_nonerc_Validation_cut_method--Control Object is Live for APL \n"); fflush(stdout);

									int  workingAPLDMLFnd = 0;

									GRM_find_relation_type("CMHasSolutionItem",&relation_type_PrtToTsk);
									GRM_list_primary_objects_only(rev_tag,relation_type_PrtToTsk,&count_task,&PartTaskTags);

									printf("\n tm_nonerc_Validation_cut_method--Number of Task => %d \n",count_task); fflush(stdout);

									if(count_task>0)
									{
										for (cnt_tk=0;cnt_tk<count_task ;cnt_tk++ )
										{
											PartTskTag=PartTaskTags[cnt_tk];
											ITK_CALL(TCTYPE_ask_object_type(PartTskTag,&TaskTag_class));
											ITK_CALL(TCTYPE_ask_name2(TaskTag_class,&Task_class));

											printf("\n tm_nonerc_Validation_cut_method--[%d] Task_class ...%s\n",cnt_tk,Task_class); fflush(stdout);

											if(tc_strcmp(Task_class,"T5_APLTaskRevision")==0)
											{
												ITK_CALL(AOM_ask_value_string(PartTskTag,"item_id",&TaskId));
												printf("\n tm_nonerc_Validation_cut_method--TaskId %s.....\n",TaskId); fflush(stdout);

												GetPlantForDMLORTask1(TaskId,GetPlant);

												printf("\n tm_nonerc_Validation_cut_method--GetPlant => %s and PlantName => %s ....\n",GetPlant,PlantName); fflush(stdout);

												if(tc_strcmp(GetPlant,PlantName)==0)
												{
													printf("\n tm_nonerc_Validation_cut_method--Same Plant task Found \n"); fflush(stdout);

													GetPlantWiseRelStatAtAPL1(TaskId,LcsAplWrkg,LcsAplRlzd);
													printf("\n tm_nonerc_Validation_cut_method--LcsAplWrkg: %s ",LcsAplWrkg);
													printf("\n tm_nonerc_Validation_cut_method--LcsAplRlzd: %s \n",LcsAplRlzd);

													ITK_CALL(WSOM_ask_release_status_list(PartTskTag,&st_count,&status_list));
													printf("\n tm_nonerc_Validation_cut_method--st_count :%d is\n",st_count);fflush(stdout);

													if(st_count>0)
													{
														for (cnt_next=0;cnt_next< st_count;cnt_next++ )
														{
															TaskRelStat=NULL;
															ITK_CALL(AOM_ask_name(status_list[cnt_next],&TaskRelStat));
															printf("\n tm_nonerc_Validation_cut_method--TaskRelStat is :%s\n",TaskRelStat);fflush(stdout);

															if ((tc_strcmp(TaskRelStat,LcsAplWrkg)==0))
															{
																ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
																if (tsk_dml_rel_type!=NULLTAG)
																{
																	ITK_CALL(GRM_list_primary_objects_only(PartTskTag,tsk_dml_rel_type,&count_DML,&DMLRevision));
																	printf("\n tm_nonerc_Validation_cut_method--APL DML Revision from Task : %d",count_DML); fflush(stdout);
																}

																for (j=0;j<count_DML;j++ )
																{
																	DMLRevTag = DMLRevision[j];

																	ITK_CALL(POM_class_of_instance(DMLRevTag,&class_id1));
																	ITK_CALL(POM_name_of_class(class_id1,&class_name1));
																	printf("\n tm_nonerc_Validation_cut_method--class_name found1 :%s \n",class_name1); fflush(stdout);

																	if(tc_strcmp(class_name1,"T5_APLDMLRevision")==0)
																	{
																		ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_EcnType",&EcnType));
																		printf("\n tm_nonerc_Validation_cut_method--APLDMLtype is :%s",EcnType); fflush(stdout);

																		if((tc_strcmp(EcnType,"APLSTR")==0) || (tc_strcmp(EcnType,"MR")==0)|| (tc_strcmp(EcnType,"IPBT")==0))
																		{
																			workingAPLDMLFnd++;
																			printf("\n tm_nonerc_Validation_cut_method--Deletion of part in Assembly is allowed as it is attached to APL Re-Structuring DML \n"); fflush(stdout);
																			break;
																		}

																		// Checking ERC Task // TZ 1.78
																		char    *qry_entryCntrlERCTask[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};
																		char	**qry_valuesCntrlERCTask= (char **) MEM_alloc(5 * sizeof(char *));

																		tag_t   qryTagCntrlERCTask     = NULLTAG;

																		int     n_entryCntrlERCTask    = 3;
																		int  control_number_foundERCTask=0;

																		tag_t *list_of_WSO_cntrl_tagsERCTask=NULLTAG;

																		char*	TaskAggregts		=	NULL;

																		if(QRY_find2("Control Objects...", &qryTagCntrlERCTask));
																		if (qryTagCntrlERCTask)
																		{
																			printf("\n tm_nonerc_Validation_cut_method--Control Object Query Found \n");fflush(stdout);

																			qry_valuesCntrlERCTask[0]="PP_PM_Task";
																			qry_valuesCntrlERCTask[1]="ERC_Task";
																			qry_valuesCntrlERCTask[2]="0";

																			if(QRY_execute(qryTagCntrlERCTask, n_entryCntrlERCTask, qry_entryCntrlERCTask, qry_valuesCntrlERCTask, &control_number_foundERCTask, &list_of_WSO_cntrl_tagsERCTask));
																		}

																		printf("\n tm_nonerc_Validation_cut_method--cut_method : control_number_foundERCTask is => %d\n",control_number_foundERCTask);fflush(stdout);

																		if(control_number_foundERCTask>0)
																		{
																			printf("\n Inside control_number_foundERCTask \n");fflush(stdout);
																			ITKCALL(AOM_ask_value_string(list_of_WSO_cntrl_tagsERCTask[0], "t5_Userinfo1", &TaskAggregts));
																			printf("\n tm_nonerc_Validation_cut_method--TaskAggregts => %s \n",TaskAggregts);fflush(stdout);

																			printf("\n tm_nonerc_Validation_cut_method--TaskId %s.....\n",TaskId); fflush(stdout);

																			char*	Task_Suffix	= NULL;

																			Task_Suffix=subString(TaskId,2,2);
																			printf("\n tm_nonerc_Validation_cut_method--Task_Suffix: %s\n",Task_Suffix);fflush(stdout);

																			if(tc_strstr(TaskAggregts,Task_Suffix)!=NULL)
																			{
																				printf("\n tm_nonerc_Validation_cut_method--Inside PP/PM/JP/JM/LP/LM/CU/JU/LU DML check \n",EcnType); fflush(stdout);
																				workingAPLDMLFnd++;
																				printf("\n tm_nonerc_Validation_cut_method--Deletion of part in Assembly is allowed as it is attached to PP/PM/JP/JM/LP/LM/CU/JU/LU DML \n"); fflush(stdout);
																				break;
																			}
																		}
																	}
																}
															}
															if (workingAPLDMLFnd>0)
															{
																printf("\n tm_nonerc_Validation_cut_method--lcsStP for loope break => %d \n",workingAPLDMLFnd); fflush(stdout);
																break;
															}
														}
													}

												}
											}
											if (workingAPLDMLFnd>0)
											{
												printf("\n tm_nonerc_Validation_cut_method--i for loope break => %d \n",workingAPLDMLFnd);fflush(stdout);
												break;
											}
										}
									}
									if(workingAPLDMLFnd == 0)
									{
										FlagGrpErr=1;
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error, ITK_err, "Deletion of part in Selected assembly is not allowed as the Selected Assembly is not attached to any APL Restructuring DML");
										return ITK_err;
									}
								}
								else
								{
									printf("\n tm_nonerc_Validation_cut_method--Control Object is Not Live for APL \n"); fflush(stdout);
								}
							}
							// MBOM implementation
							else if (tc_strstr(roleName,"MBOM")!=NULL)
							{
								printf("\n tm_nonerc_Validation_cut_method--cut_method : Inside MBOM Role.. Checking Control Object \n"); fflush(stdout);

								tag_t   qryTagCntrlobj_MBOM		= NULLTAG;
								tag_t*	list_of_cntrl_tags_MBOM	= NULLTAG;

								char*	qry_entryCntrl_MBOM[4] = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};
								char**	qry_valuesCntrl_MBOM	= (char **) MEM_alloc(5 * sizeof(char *));

								int controlObjfound_MBOM = 0;
								int	n_entryCntrlobj_MBOM = 4;

								if(QRY_find2("Control Objects...", &qryTagCntrlobj_MBOM));

								if (qryTagCntrlobj_MBOM)
								{
									printf("\n tm_nonerc_Validation_cut_method--Control Object Query Found \n");fflush(stdout);
									qry_valuesCntrl_MBOM[0]="BOM_Save";
									qry_valuesCntrl_MBOM[1]="MBOM";
									qry_valuesCntrl_MBOM[2]="0";
									qry_valuesCntrl_MBOM[3]="Live";

									if(QRY_execute(qryTagCntrlobj_MBOM, n_entryCntrlobj_MBOM, qry_entryCntrl_MBOM, qry_valuesCntrl_MBOM, &controlObjfound_MBOM, &list_of_cntrl_tags_MBOM));
								}
								else
								{
									printf("\n tm_nonerc_Validation_cut_method--Control Object Query not Found  \n");fflush(stdout);
								}

								printf("\n tm_nonerc_Validation_cut_method--controlObjfound_MBOM is ==> %d\n",controlObjfound_MBOM);fflush(stdout);

								if(controlObjfound_MBOM>0)
								{
									printf("\n tm_nonerc_Validation_cut_method--Control Object is Live for MBOM \n"); fflush(stdout);

									char* lcsToMBOMWorking=NULL;
									lcsToMBOMWorking =(char *) MEM_alloc(20 * sizeof(char *));
									strcpy(lcsToMBOMWorking,"T5_MBOMWorking");

									ITK_CALL(WSOM_ask_release_status_list(rev_tag,&rev_st_count,&rev_status_list));
									printf("\n tm_nonerc_Validation_cut_method--rev_st_count :%d is\n",rev_st_count);fflush(stdout);

									if ((tc_strcmp(bl_owning_group,"MBOM")==0) || (tc_strcmp(bl_owning_group,"dba")==0)|| (tc_strcmp(bl_owning_group,"loader")==0)|| (tc_strcmp(bl_owning_group,"aplloader")==0)) // For MBOM User Created Part
									{
										if(rev_st_count>0)
										{
											for (rev_cnt_next=0;rev_cnt_next< rev_st_count;rev_cnt_next++ )
											{
												TaskRelStat=NULL;
												ITK_CALL(AOM_ask_name(rev_status_list[rev_cnt_next],&Rev_RelStat));
												printf("\n tm_nonerc_Validation_cut_method--Rev_RelStat is :%s\n",Rev_RelStat);fflush(stdout);

												if ((tc_strcmp(Rev_RelStat,lcsToMBOMWorking)==0))
												{
													printf("\n tm_nonerc_Validation_cut_method--Test 1. Checking the release status for MBOM..\n");fflush(stdout);
													workingMBOMPrtFnd=1;
													break;
												}
											}
										}
										if(workingMBOMPrtFnd == 0)
										{
											FlagGrpErr=1;
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error, ITK_err, "Selected Design-Revision is not MBOM-Working.Deletion is allowed for MBOM-Working Design-Revision.");
											return ITK_err;

										}
									}
									else
									{
										if(rev_st_count>0)
										{
											for (rev_cnt_next=0;rev_cnt_next< rev_st_count;rev_cnt_next++ )
											{
												TaskRelStat=NULL;
												ITK_CALL(AOM_ask_name(rev_status_list[rev_cnt_next],&Rev_RelStat));
												printf("\n tm_nonerc_Validation_cut_method--Rev_RelStat is :%s\n",Rev_RelStat);fflush(stdout);

												if ((tc_strcmp(Rev_RelStat,"T5_LcsErcRlzd")==0)) // For ERC Created Part
												{
													printf("\n tm_nonerc_Validation_cut_method--Test 2. Checking the release status for MBOM..\n");fflush(stdout);
													workingMBOMPrtFnd=1;
													break;
												}
											}
										}
										if(workingMBOMPrtFnd == 0)
										{
											FlagGrpErr=1;
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error, ITK_err, "Selected Design-Revision is not ERC Released.Deletion is allowed for ERC Released and above Design-Revision.");
											return ITK_err;

										}
										if(FlagGrpErr == 0)
										{
											GRM_find_relation_type("CMHasSolutionItem",&relation_type_PrtToTsk);
											GRM_list_primary_objects_only(rev_tag,relation_type_PrtToTsk,&count_task,&PartTaskTags);

											printf("\n tm_nonerc_Validation_cut_method--Number of MBOM Task => %d \n",count_task); fflush(stdout);

											if(count_task>0)
											{
												for (cnt_tk=0;cnt_tk<count_task ;cnt_tk++ )
												{
													PartTskTag=PartTaskTags[cnt_tk];
													ITK_CALL(TCTYPE_ask_object_type(PartTskTag,&TaskTag_class));
													ITK_CALL(TCTYPE_ask_name2(TaskTag_class,&Task_class));

													printf("\n tm_nonerc_Validation_cut_method--[%d] MBOM Task_class ...%s\n",cnt_tk,Task_class); fflush(stdout);

													if(tc_strcmp(Task_class,"T5_MBOMTASKRevision")==0)
													{
														ITK_CALL(AOM_ask_value_string(PartTskTag,"item_id",&TaskId));
														printf("\n tm_nonerc_Validation_cut_method--MBOM TaskId %s.....\n",TaskId); fflush(stdout);

														GetPlantForDMLORTask1(TaskId,GetPlant);

														printf("\n tm_nonerc_Validation_cut_method--GetPlant => %s and PlantName => %s ....\n",GetPlant,PlantName); fflush(stdout);

														if(tc_strcmp(GetPlant,PlantName)==0)
														{
															printf("\n tm_nonerc_Validation_cut_method--Same Plant task Found--"); fflush(stdout);

															printf("\t lcsToMBOMWorking: %s \n",lcsToMBOMWorking);

															ITK_CALL(WSOM_ask_release_status_list(PartTskTag,&st_count,&status_list));
															printf("\n tm_nonerc_Validation_cut_method--st_count :%d is\n",st_count);fflush(stdout);

															if(st_count>0)
															{
																for (cnt_next=0;cnt_next< st_count;cnt_next++ )
																{
																	TaskRelStat=NULL;
																	ITK_CALL(AOM_ask_name(status_list[cnt_next],&TaskRelStat));
																	printf("\n tm_nonerc_Validation_cut_method--MBOM TaskRelStat is :%s\n",TaskRelStat);fflush(stdout);

																	if ((tc_strcmp(TaskRelStat,lcsToMBOMWorking)==0))
																	{
																		ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
																		if (tsk_dml_rel_type!=NULLTAG)
																		{
																			ITK_CALL(GRM_list_primary_objects_only(PartTskTag,tsk_dml_rel_type,&count_DML,&DMLRevision));
																			printf("\n tm_nonerc_Validation_cut_method--MBOM DML Revision from Task : %d",count_DML); fflush(stdout);
																		}

																		for (j=0;j<count_DML;j++ )
																		{
																			DMLRevTag = DMLRevision[j];

																			ITK_CALL(POM_class_of_instance(DMLRevTag,&class_id1));
																			ITK_CALL(POM_name_of_class(class_id1,&class_name1));
																			printf("\n tm_nonerc_Validation_cut_method--class_name found1 :%s \n",class_name1); fflush(stdout);

																			if(tc_strcmp(class_name1,"T5_MBOMDMLRevision")==0)
																			{
																				ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_MBOMRlzType",&EcnType));
																				printf("\n tm_nonerc_Validation_cut_method--t5_MBOMRlzType is :%s",EcnType); fflush(stdout);

																				if((tc_strcmp(EcnType,"VCREST")==0) || (tc_strcmp(EcnType,"MFG_SubMdRlz")==0))
																				{
																					workingMBOMDMLFnd++;
																					printf("\n tm_nonerc_Validation_cut_method--Deletion of part in Selected Assembly is allowed as it is attached to MBOM VC Re-Structuring DML.\n"); fflush(stdout);
																					break;
																				}
																			}
																		}
																	}
																	if (workingMBOMDMLFnd>0)
																	{
																		printf("\n tm_nonerc_Validation_cut_method--lcsStP for loope break => %d \n",workingMBOMDMLFnd); fflush(stdout);
																		break;
																	}
																}
															}

														}
													}
													if (workingMBOMDMLFnd>0)
													{
														printf("\n tm_nonerc_Validation_cut_method--i for loope break => %d \n",workingMBOMDMLFnd);fflush(stdout);
														break;
													}
												}
											}
											if(workingMBOMDMLFnd == 0)
											{
												FlagGrpErr=1;
												EMH_clear_errors();
												EMH_store_error_s1(EMH_severity_error, ITK_err, "Deletion of part in selected Design-Revision is not allowed as the selected Design-Revision is not attached to MBOM Working DML with MBOM-Release-Type VC-Restructuring/MFG Submodule Release");
												return ITK_err;
											}
										}
									}
								}
								else
								{
									printf("\n tm_nonerc_Validation_cut_method--Control Object is Live Not for MBOM \n"); fflush(stdout);
								}

							}
							// STD implementation
							else if (tc_strstr(roleName,"STD")!=NULL)
							{
								printf("\n tm_nonerc_Validation_cut_method--cut_method : Inside STD Role.. Checking Control Object -- "); fflush(stdout);
								printf(" PlantName => %s \n",PlantName); fflush(stdout);

								tag_t   qryTagCntrlobj_STD		= NULLTAG;
								tag_t*	list_of_cntrl_tags_STD	= NULLTAG;

								char*	qry_entryCntrl_STD[4] = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};
								char**	qry_valuesCntrl_STD	= (char **) MEM_alloc(5 * sizeof(char *));

								int controlObjfound_STD = 0;
								int	n_entryCntrlobj_STD = 4;

								if(QRY_find2("Control Objects...", &qryTagCntrlobj_STD));

								if (qryTagCntrlobj_STD)
								{
									printf("\n tm_nonerc_Validation_cut_method--Control Object Query Found \n");fflush(stdout);
									qry_valuesCntrl_STD[0]="BOM_Save";
									qry_valuesCntrl_STD[1]="STD";
									qry_valuesCntrl_STD[2]="0";
									qry_valuesCntrl_STD[3]="Live";

									if(QRY_execute(qryTagCntrlobj_STD, n_entryCntrlobj_STD, qry_entryCntrl_STD, qry_valuesCntrl_STD, &controlObjfound_STD, &list_of_cntrl_tags_STD));
								}
								else
								{
									printf("\n tm_nonerc_Validation_cut_method--Control Object Query not Found  \n");fflush(stdout);
								}

								printf("\n tm_nonerc_Validation_cut_method--controlObjfound_STD is ==> %d\n",controlObjfound_STD);fflush(stdout);

								if(controlObjfound_STD>0)
								{
									printf("\n tm_nonerc_Validation_cut_method--Control Object is Live for STD \n"); fflush(stdout);

									char LcsStdWrkg[40];
									char LcsStdRlzd[40];
									int workingSMDMLFnd=0;
									int relStatFnd=0;

									GetPlantWise_STD_LCS(PlantName,LcsStdWrkg,LcsStdRlzd);
									printf("\n tm_nonerc_Validation_cut_method--LcsStdWrkg: %s \n",LcsStdWrkg);
									printf("\n tm_nonerc_Validation_cut_method--LcsStdRlzd: %s \n",LcsStdRlzd);

									ITK_CALL(WSOM_ask_release_status_list(rev_tag,&rev_st_count,&rev_status_list));
									printf("\n tm_nonerc_Validation_cut_method--rev_st_count :%d is\n",rev_st_count);fflush(stdout);

									if(rev_st_count>0)
									{
										for (rev_cnt_next=0;rev_cnt_next< rev_st_count;rev_cnt_next++ )
										{
											TaskRelStat=NULL;
											ITK_CALL(AOM_ask_name(rev_status_list[rev_cnt_next],&Rev_RelStat));
											printf("\n tm_nonerc_Validation_cut_method--Rev_RelStat is :%s\n",Rev_RelStat);fflush(stdout);

											if ((tc_strcmp(Rev_RelStat,LcsStdRlzd)==0))
											{
												printf("\n tm_nonerc_Validation_cut_method--Inside STD Released Release Status \n");fflush(stdout);
												relStatFnd++;
											}
										}
									}
									if(relStatFnd==0)
									{
										printf("\n tm_nonerc_Validation_cut_method--Inside error message for STDSI \n");fflush(stdout);
										FlagGrpErr++;

										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error, ITK_err, "Please select only STDSI Released Part for Deletion in Structure.");
										return ITK_err;

									}
									if(FlagGrpErr==0)
									{
										GRM_find_relation_type("CMHasSolutionItem",&relation_type_PrtToTsk);
										GRM_list_primary_objects_only(rev_tag,relation_type_PrtToTsk,&count_task,&PartTaskTags);

										printf("\n tm_nonerc_Validation_cut_method--Number of SM Task => %d \n",count_task); fflush(stdout);

										if(count_task>0)
										{
											for (cnt_tk=0;cnt_tk<count_task ;cnt_tk++ )
											{
												PartTskTag=PartTaskTags[cnt_tk];
												ITK_CALL(TCTYPE_ask_object_type(PartTskTag,&TaskTag_class));
												ITK_CALL(TCTYPE_ask_name2(TaskTag_class,&Task_class));

												printf("\n tm_nonerc_Validation_cut_method--[%d] SM Task_class ...%s\n",cnt_tk,Task_class); fflush(stdout);

												if(tc_strcmp(Task_class,"T5_SMDMLTaskRevision")==0)
												{
													ITK_CALL(AOM_ask_value_string(PartTskTag,"item_id",&TaskId));
													printf("\n tm_nonerc_Validation_cut_method--SM TaskId %s.....\n",TaskId); fflush(stdout);

													GetPlantForDMLORTask1(TaskId,GetPlant);

													printf("\n tm_nonerc_Validation_cut_method--GetPlant => %s and PlantName => %s ....\n",GetPlant,PlantName); fflush(stdout);

													if(tc_strcmp(GetPlant,PlantName)==0)
													{
														printf("\n tm_nonerc_Validation_cut_method--Same Plant task Found \n"); fflush(stdout);

														ITK_CALL(WSOM_ask_release_status_list(PartTskTag,&st_count,&status_list));
														printf("\n tm_nonerc_Validation_cut_method--st_count :%d is\n",st_count);fflush(stdout);

														if(st_count>0)
														{
															for (cnt_next=0;cnt_next< st_count;cnt_next++ )
															{
																TaskRelStat=NULL;
																ITK_CALL(AOM_ask_name(status_list[cnt_next],&TaskRelStat));
																printf("\n tm_nonerc_Validation_cut_method--SM TaskRelStat is :%s\n",TaskRelStat);fflush(stdout);

																if ((tc_strcmp(TaskRelStat,LcsStdWrkg)==0))
																{
																	workingSMDMLFnd++;
																	ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
																	if (tsk_dml_rel_type!=NULLTAG)
																	{
																		ITK_CALL(GRM_list_primary_objects_only(PartTskTag,tsk_dml_rel_type,&count_DML,&DMLRevision));
																		printf("\n tm_nonerc_Validation_cut_method--STD DML Revision from Task : %d",count_DML); fflush(stdout);
																	}

																	for (j=0;j<count_DML;j++ )
																	{
																		DMLRevTag = DMLRevision[j];

																		ITK_CALL(POM_class_of_instance(DMLRevTag,&class_id1));
																		ITK_CALL(POM_name_of_class(class_id1,&class_name1));
																		printf("\n tm_nonerc_Validation_cut_method--class_name found1 :%s \n",class_name1); fflush(stdout);

																		if(tc_strcmp(class_name1,"T5_SMDMLRevision")==0)
																		{
																			ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&SM_item_id));
																			printf("\n tm_nonerc_Validation_cut_method--SM_item_id is :%s",SM_item_id); fflush(stdout);

																		}
																	}
																}

															}
														}

													}
												}

											}
										}
										if(workingSMDMLFnd==0)
										{
											FlagGrpErr++;
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error, ITK_err, "Part is not attached to STDSI Working SMDML.\n Please attach/Deletion the Part to SMDML and then perform restrcturing.");
											return ITK_err;
										}
									}
								}
								else
								{
									printf("\n tm_nonerc_Validation_cut_method--Control Object is Not Live for STD \n"); fflush(stdout);
								}
							}
						}
					}
				}
			}
		}
	}
	printf("\n tm_nonerc_Validation_cut_method--Completed processing------- \n"); fflush(stdout);

	return ITK_ok;
}

/******************************************************************************************
*   Function name			:	arch_module_access_fun
*   Description				:	This function provides the access to su_mdm user only
*								while creating Architecture module.
*
*	Date				Modified By				Modification Notes
*	06/05/2019			Kalpesh Gondhali		1.45:
******************************************************************************************/
extern DLLAPI int arch_module_access_fun(METHOD_message_t *msg, va_list args)
{
	int				error_code					= ITK_ok;
    tag_t			objTag						= va_arg(args, tag_t);
	tag_t			objTypeTag					= NULLTAG;
	tag_t			user_tag					= NULLTAG;

	char			*username					= NULL;
	char			*type_name					= NULL;
	//char			type_name[TCTYPE_name_size_c+1];

	char			*group_name					=NULL;
	tag_t			group_tag					=NULLTAG;

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
	POM_get_user(&username, &user_tag);
	POM_ask_group(&group_name, &group_tag);
	printf("\n arch_module_access_fun--User name is:%s", username);
	printf("\n arch_module_access_fun--Part type is:%s", type_name);

	if(strcmp(type_name, "T5_ArchModuleRevision") == 0)
	{
		//if(tc_strcmp(username, "su_mdm") != 0)
		if(tc_strcmp(group_name, "Master_Data_Mgmt") != 0)
		{
			printf("\n arch_module_access_fun--Unable to create part, as only user having group (Master_Data_Mgmt) having access to create this object.\n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err, "Unable to create part, as only user having group (Master_Data_Mgmt) having access to create this object.");
			return ITK_err;
		}
	}
	printf("\n arch_module_access_fun--Completed processing------- \n"); fflush(stdout);

	return ITK_ok;
}

/******************************************************************************************
*   Function name			:	platform_access_fun
*   Description				:	This function provides access to su_mdm user only
*								while creating platform.
*
*	Date				Modified By				Modification Notes
*	06/05/2019			Kalpesh Gondhali		1.45:
******************************************************************************************/
extern DLLAPI int platform_access_fun(METHOD_message_t *msg, va_list args)
{
	int				error_code					= ITK_ok;
    tag_t			objTag						= va_arg(args, tag_t);
	tag_t			objTypeTag					= NULLTAG;
	tag_t			user_tag					= NULLTAG;
	char			*group_name					=NULL;
	tag_t			group_tag					=NULLTAG;

	char			*username					= NULL;
	char			*type_name					= NULL;
	//char			type_name[TCTYPE_name_size_c+1];

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
	POM_get_user(&username, &user_tag);
	POM_ask_group(&group_name, &group_tag);
	printf("\n platform_access_fun--User name is:%s", username);
	printf("\n platform_access_fun--Part type is:%s", type_name);

	if(strcmp(type_name, "T5_PlatformRevision") == 0)
	{
	if(tc_strcmp(group_name, "Master_Data_Mgmt") != 0)
		{
			printf("\n platform_access_fun--Unable to create part, as only user having Group (Master_Data_Mgmt) having access to create this object.\n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err, "Unable to create part, as only user having Group (Master_Data_Mgmt) having access to create this object.");
			return ITK_err;
		}
	}

	printf("\n platform_access_fun--Completed processing------- \n"); fflush(stdout);

	return ITK_ok;
}

/******************************************************************************************
*   Function name			:	bomline_cut_method
*   Description				:	This function provides access to su_mdm user only to
*								cut the bomline from Structure.
*
*	Date				Modified By				Modification Notes
*	13/06/2019			Kalpesh Gondhali		1.46:
******************************************************************************************/
extern DLLAPI int bomline_cut_method(METHOD_message_t *msg, va_list args)
{
	int			error_code					= ITK_ok;
	int			blobjType					= 0;
	int			line_name					= 0;
	int			parent_nm					= 0;
	int			modadd						= 0;
	int			attr_id						= 0;
	int			rev_attr_id					= 0;
	int			rel_stat					= 0;
	int			n_parents					= 0;
	int			*levels						= 0;
	int			designer_found				= 0;
	int			manager_found				= 0;

	//Rohit start
	int			parent_bl					=	0;
	int			checked_out_uservalue		=   0;
	int			obj_typebm		=   0;
	int			bsc_entries			=	1;
	int			bsc2_entries			=	1;
	int			bsc_found			=	0;
	int			bsc2_found			=	0;
	int			toplinebcbom_count	=	0;

	char		*parent_name				=	NULL;
	char		*cp_ChildChkOutV			=   NULL;
	char		*cp_obj_typebm			=   NULL;
	char		*username1					=	NULL;
	char		*group_name1				=	NULL;
	char		*roleName1				=	NULL;
	//char		roleName1[SA_name_size_c+1];

	char		*qry_bsccntrl[1]		= {"SYSCD"};
	char		*qry_bsc2cntrl[1]		= {"SYSCD"};
	char		**qry_valuesbsc		= (char **) MEM_alloc(10 * sizeof(char *));
	char		**qry_valuesbsc2		= (char **) MEM_alloc(10 * sizeof(char *));
	qry_valuesbsc[0]					= "bomsavecut"; //bomsavecut
	qry_valuesbsc2[0]					= "bomsavevalcut";

	//char		*latest_parentname			=	NULL;
	char		*latest_parentIDstrbc			=	NULL;
	char		*latest_revVstrbc			=	NULL;
	char		*pname						=	NULL;

	tag_t		CurrentRoleTag1				= NULLTAG;
	tag_t		user_tag1					= NULLTAG;
	tag_t		group_tag1					= NULLTAG;
	tag_t		bsc_CntrlOBJ				=	NULLTAG;
	tag_t		bsc2_CntrlOBJ				=	NULLTAG;
	tag_t		*CntrlObject_bsc			=	NULLTAG;
	tag_t		*CntrlObject_bsc2			=	NULLTAG;
	tag_t		bc_revrule					=	NULLTAG;
	tag_t		bom_bc						=	NULLTAG;
	tag_t		topline_bcbom				=	NULLTAG;
	tag_t		*bcbom_childs				=	NULLTAG;
	tag_t		latest_revbv				=	NULLTAG;
	tag_t		latest_parentname			=	NULLTAG;
	//Rohit End

	char		*userid						= NULL;
	char		*mod_addr					= NULL;
	char		*objType					= NULL;
	char		*username					= NULL;
	char		*bcm_type_name				= NULL;
	char		*rev_type_name				= NULL;
	char		*bcm_username				= NULL;
	char		*bomline_objType			= NULL;
	char		*bomline_name				= NULL;
	char		*parent_string				= NULL;
	char		*bcm_release_status			= NULL;
	char		*bcm_rel_status				= NULL;

	char		*designer_role				= NULL;
	char		*manager_role				= NULL;

	char		*part						= NULL;
	char		*rev						= NULL;
	char		*group_name					= NULL;
	int			Lvl							= 0;
	tag_t		group_tag					= NULLTAG;

	tag_t		*list;
	tag_t		*parents					= NULL;
	tag_t		window						= NULLTAG;
	tag_t		user_tag					= NULLTAG;
	tag_t		top_bom_line				= NULLTAG;

	tag_t		rev_tag						= NULLTAG;
	tag_t		objTypeTag					= NULLTAG;
	tag_t		bcm_user_tag				= NULLTAG;

	tag_t		bomline_tag					= va_arg(args, tag_t);

	//if (TCTYPE_ask_object_type(bomline_tag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	//if (TCTYPE_ask_name2(objTypeTag,&bcm_type_name)!=ITK_ok) PrintErrorStack();
	//if (AOM_UIF_ask_value(bomline_tag, "bl_item_object_type", &bcm_type_name)!=ITK_ok) PrintErrorStack();

	if(BOM_line_ask_window(bomline_tag,&window)!=ITK_ok) PrintErrorStack();
	if(window)
	{
		if(BOM_ask_window_top_line(window,&top_bom_line)!=ITK_ok) PrintErrorStack();
		if(top_bom_line)
		{
			//if(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&blobjType)!=ITK_ok) PrintErrorStack();
			//if(BOM_line_ask_attribute_string(top_bom_line, blobjType, &bomline_objType)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(top_bom_line,"fnd0bl_line_object_type",&bomline_objType));
			printf("\n bomline_cut_method--Top_Bomline obj_type:%s", bomline_objType);

			//if (BOM_line_look_up_attribute("fnd0bl_line_object_type", &attr_id)!=ITK_ok) PrintErrorStack();
			//if (BOM_line_ask_attribute_string(bomline_tag, attr_id, &bcm_type_name)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(bomline_tag,"fnd0bl_line_object_type",&bcm_type_name));
			printf("\n bomline_cut_method--Child_Bomline obj_type:%s", bcm_type_name);

			POM_get_user(&bcm_username, &bcm_user_tag);
			POM_ask_group(&group_name, &group_tag);

			printf("\n bomline_cut_method--bcm_user_name is:%s", bcm_username);

			if (tc_strcmp(bomline_objType,"T5_PlatformRevision") == 0)
			{

				if(tc_strcmp(bcm_type_name, "T5_ArchModuleRevision") == 0)
				{
					if((tc_strcmp(group_name, "Master_Data_Mgmt") != 0) && (tc_strcmp(username,"infodba")!=0))
					{
						printf("\n bomline_cut_method--Only user having (Master_Data_Mgmt ) group can cut the Bomline.\n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error, ITK_err, "Only user having (Master_Data_Mgmt ) group can cut the Bomline.");
						return ITK_err;
					}
				}
			}
		}
	}

	//Rohit function to prevent bomsave from ERC_Designers login when part is not checked-out

	if(QRY_find2("Control Objects...",&bsc_CntrlOBJ));
	printf("\n bomline_cut_method--bomline_cut_method--BOM Save while cut Query Found\n\n");	fflush(stdout);

	if(QRY_execute(bsc_CntrlOBJ, bsc_entries, qry_bsccntrl, qry_valuesbsc, &bsc_found, &CntrlObject_bsc));
	printf("\n bomline_cut_method--BOM Save while cut SYSCD 1:[%d]\n",bsc_found);	fflush(stdout);

	if(bsc_found > 0)
	{
		printf("\n bomline_cut_method--Inside Rohit's function to prevent deletion of child from structure\n"); fflush(stdout);

		ITKCALL(SA_ask_current_role(&CurrentRoleTag1));
		ITKCALL(SA_ask_role_name2(CurrentRoleTag1,&roleName1));
		POM_get_user(&username1, &user_tag1);
		POM_ask_group(&group_name1, &group_tag1);

		printf("\n bomline_cut_method--User name while save validation: [%s]   roleName1 : %s", username1,roleName1);

		if(bomline_tag)
		{
			//ITK_CALL(BOM_line_look_up_attribute ("bl_formatted_parent_name",&parent_bl));
			//ITK_CALL(BOM_line_ask_attribute_string(bomline_tag, parent_bl, &parent_name));
			//
			//ITK_CALL(BOM_line_look_up_attribute ("bl_rev_checked_out",&checked_out_uservalue));
			//ITK_CALL(BOM_line_ask_attribute_string (top_bom_line, checked_out_uservalue, &cp_ChildChkOutV));

			if( AOM_ask_value_string(bomline_tag,"bl_formatted_parent_name",&parent_name));
			if( AOM_ask_value_string(top_bom_line,"bl_rev_checked_out",&cp_ChildChkOutV));

			printf("\n bomline_cut_method--cp_ChildChkOutV value is [%s] and  [%d]\n",cp_ChildChkOutV,checked_out_uservalue);fflush(stdout);
			printf("\n bomline_cut_method--Parent Bom line is [%s] and it's checked-out value is [%s]", parent_name,cp_ChildChkOutV); fflush(stdout);

			//ITK_CALL(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&obj_typebm));
			//ITK_CALL(BOM_line_ask_attribute_string (top_bom_line, obj_typebm, &cp_obj_typebm));

			if( AOM_ask_value_string(top_bom_line,"fnd0bl_line_object_type",&cp_obj_typebm));
			printf(" bomline_cut_method--Object type for below validation is [%s]",cp_obj_typebm); fflush(stdout);

			if ((tc_strcmp(cp_obj_typebm,"Design Revision") == 0) || (tc_strcmp(cp_obj_typebm,"T5_EE_PartRevision") == 0)) //Added by Akshay for ECU Bom Cut object Restriction
			{
				if(tc_strcmp(cp_ChildChkOutV,"Y")!=0)
				{
					if (((tc_strcmp(username1,"infodba")!=0) && (tc_strcmp(username1,"loader")!=0)) && (tc_strstr(roleName1,"STD")==NULL) && (tc_strstr(roleName1,"APL")==NULL) && (tc_strstr(roleName1,"MBOM")==NULL) && (tc_strstr(roleName1,"Support")==NULL))
					{
						printf("\n bomline_cut_method--Parent is not checked-out.\n"); fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error, ITK_err, "You cannot modify BOM as this part is not checked-out");
						return ITK_err;
					}
					else
					{
						printf("\n bomline_cut_method--User Role is APL, STD, or MBOM , hence bypassed this validation\n"); fflush(stdout);
					}
				}
				else
				{
					printf("\n bomline_cut_method--Parent is checked-out.\n"); fflush(stdout);

					//NSS
					if (((tc_strcmp(username1,"infodba")!=0) && (tc_strcmp(username1,"loader")!=0)) && (tc_strstr(roleName1,"STD")==NULL) && (tc_strstr(roleName1,"APL")==NULL) && (tc_strstr(roleName1,"MBOM")==NULL) && (tc_strstr(roleName1,"Support")==NULL))
					{
						if( AOM_ask_value_string(top_bom_line,"bl_rev_release_status_list",&bcm_rel_status));
						printf("\n  bomline_cut_method--bcm_rel_status : [%s]\n",bcm_rel_status); fflush(stdout);

						if(AOM_ask_value_int(bomline_tag,"bl_level_starting_0",&Lvl));//CR/ERC/PLM/25/0063
						printf("\n bomline_cut_method-- : Level: [%d] ",Lvl);fflush(stdout);

						if((tc_strstr(bcm_rel_status,"T5_LcsErcRlzd") != NULL) || (tc_strstr(bcm_rel_status,"T5_LcsReview") != NULL) ||
							(Lvl>1))
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error, ITK_err, "You cannot modify BOM as parent part is in ERC review/released state.");
							return ITK_err;
						}
					}
				}
			}
		}
	}

	if(QRY_find2("Control Objects...",&bsc2_CntrlOBJ));
	printf("\n bomline_cut_method--BOM Save while cut Query Found\n\n");	fflush(stdout);

	if(QRY_execute(bsc2_CntrlOBJ, bsc2_entries, qry_bsc2cntrl, qry_valuesbsc2, &bsc2_found, &CntrlObject_bsc2));
	printf("\n bomline_cut_method--BOM Save while cut SYSCD 2:[%d]\n",bsc2_found);	fflush(stdout);

	if(bsc2_found > 0)
	{
		if(window)
		{
			ITKCALL(SA_ask_current_role(&CurrentRoleTag1));
			ITKCALL(SA_ask_role_name2(CurrentRoleTag1,&roleName1));
			POM_get_user(&username1, &user_tag1);
			POM_ask_group(&group_name1, &group_tag1);

			printf("\n bomline_cut_method--User name while save validation is:%s", username1);
			printf("\n bomline_cut_method--roleName1 : %s\n",roleName1); fflush(stdout);
			printf("\n bomline_cut_method--Inside Rohit's function to prevent deletion of child from structure\n"); fflush(stdout);
			//ITK_CALL(BOM_line_look_up_attribute ("bl_formatted_parent_name",&parent_bl));
			//ITK_CALL(BOM_line_look_up_attribute ("bl_formatted_parent_name",&parent_bl));
			//ITK_CALL(BOM_line_ask_attribute_string(bomline_tag, parent_bl, &parent_name));

			if( AOM_ask_value_string(bomline_tag,"bl_formatted_parent_name",&parent_name));

			pname=strtok(parent_name,"/");

			printf("\n bomline_cut_method--Parent Name after token is : [%s]\n",pname); fflush(stdout);

			ITK_CALL(ITEM_find_item(pname,&latest_parentname)); //Rohit BOM
			ITK_CALL(ITEM_ask_latest_rev(latest_parentname,&latest_revbv)); //Rohit BOM

			ITK_CALL(AOM_ask_value_string(latest_parentname,"item_id",&latest_parentIDstrbc)); //Rohit BOM
			ITK_CALL(AOM_ask_value_string(latest_revbv,"item_revision_id",&latest_revVstrbc)); //Rohit BOM

			ITK_CALL(BOM_create_window(&bom_bc));
			ITK_CALL(CFM_find("Latest Working", &bc_revrule));
			ITK_CALL(BOM_set_window_config_rule( bom_bc, bc_revrule));
			ITK_CALL(BOM_set_window_pack_all(bom_bc, true));
			ITK_CALL(BOM_set_window_top_line(bom_bc,latest_parentname,latest_revbv,NULLTAG,&topline_bcbom));
			ITK_CALL(BOM_line_ask_child_lines(topline_bcbom,&toplinebcbom_count,&bcbom_childs));
			printf("\n bomline_cut_method--Count of Children present under Vehicle %s is [%d]\n",latest_parentIDstrbc,toplinebcbom_count); fflush(stdout);

			//ITK_CALL(BOM_line_look_up_attribute ("bl_rev_checked_out",&checked_out_uservalue));
			//ITK_CALL(BOM_line_ask_attribute_string (topline_bcbom, checked_out_uservalue, &cp_ChildChkOutV));

			if( AOM_ask_value_string(topline_bcbom,"bl_rev_checked_out",&cp_ChildChkOutV));

			printf("\n bomline_cut_method--cp_ChildChkOutV value is [%s] and  [%d]\n",cp_ChildChkOutV,checked_out_uservalue);fflush(stdout);
			printf("\n bomline_cut_method--Parent Bom line is [%s] and it's checked-out value is [%s]", parent_name,cp_ChildChkOutV); fflush(stdout);

			if(tc_strcmp(cp_ChildChkOutV,"Y")!=0)
			{
				if (((tc_strcmp(username1,"infodba")!=0) && (tc_strcmp(username1,"loader")!=0)) && (tc_strstr(roleName1,"STD")==NULL) && (tc_strstr(roleName1,"APL")==NULL) && (tc_strstr(roleName1,"MBOM")==NULL) && (tc_strstr(roleName1,"Support")==NULL))
				{
					printf("\n bomline_cut_method--Parent is not checked-out.\n"); fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error, ITK_err, "You cannot modify BOM as this part is not checked-out");
					return ITK_err;
				}
				else
				{
					printf("\n bomline_cut_method--User Role is APL, STD, or MBOM , hence bypassed this validation\n"); fflush(stdout);
				}
			}
			else
			{
				printf("\n bomline_cut_method--Parent is checked-out.\n"); fflush(stdout);
			}
		}
	}


	//Rohit function to prevent bomsave from ERC_Designers login when part is not checked-out

	/*if(BOM_line_ask_window(bomline_tag,&window)!=ITK_ok) PrintErrorStack();
	if(window)
	{
	if(BOM_ask_window_top_line(window,&top_bom_line)!=ITK_ok) PrintErrorStack();
	if(top_bom_line)
	{*/
	printf("\n bomline_cut_method--Inside parent check...!!");
	//if(BOM_line_look_up_attribute ("bl_formatted_parent_name",&parent_nm)!=ITK_ok) PrintErrorStack();
	//if(BOM_line_ask_attribute_string(bomline_tag, parent_nm, &parent_string)!=ITK_ok) PrintErrorStack();

	if( AOM_ask_value_string(bomline_tag,"bl_formatted_parent_name",&parent_string));
	printf("\n bomline_cut_method--parent_str:%s", parent_string);

	/*part = strtok(parent_string, "/");
	rev =  strtok(NULL, " ");
	printf("\npart:%s Rev:%s", part, rev);

	if(ITEM_find_rev(part, rev, &rev_tag)!=ITK_ok) PrintErrorStack();
	if(AOM_UIF_ask_value(rev_tag, "object_type", &objType)!=ITK_ok) PrintErrorStack();
	printf("\nObj_type:%s", objType);*/

	//		if (tc_strcmp(objType,"Architecture Module Revision") == 0)
	//			{
	if(tc_strstr(parent_string, "X4M") != NULL)
	{
		//		if(PS_where_used_all(bomline_tag,1,&n_parents,&levels,&parents)!=ITK_ok) PrintErrorStack();
		//		{
		//			if(n_parents > 0)
		//			{
		//				if(BOM_line_look_up_attribute ("bl_line_name",&line_name)!=ITK_ok) PrintErrorStack();
		//				if(BOM_line_ask_attribute_string(parents[0], line_name, &bomline_name)!=ITK_ok) PrintErrorStack();
		//				printf("\n bomline_cut_method--Bomline_name:%s\n", bomline_name);
		//
		//				if(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&blobjType)!=ITK_ok) PrintErrorStack();
		//				if(BOM_line_ask_attribute_string(parents[0], blobjType, &bomline_objType)!=ITK_ok) PrintErrorStack();
		//				printf("\n bomline_cut_method--Top_Bomline obj_type:%s\n", bomline_objType);
		//				if (tc_strcmp(bomline_objType,"T5_ArchModuleRevision") == 0)
		//				{
		//if (BOM_line_look_up_attribute("fnd0bl_line_object_type", &attr_id)!=ITK_ok) PrintErrorStack();
		//if (BOM_line_ask_attribute_string(bomline_tag, attr_id, &bcm_type_name)!=ITK_ok) PrintErrorStack();
		//if (BOM_line_look_up_attribute("bl_Design_t5_RevPartType", &rev_attr_id)!=ITK_ok) PrintErrorStack();
		//if (BOM_line_ask_attribute_string(bomline_tag, rev_attr_id, &rev_type_name)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&rel_stat)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_ask_attribute_string(bomline_tag, rel_stat, &bcm_release_status)!=ITK_ok) PrintErrorStack();

		if( AOM_ask_value_string(bomline_tag,"fnd0bl_line_object_type",&bcm_type_name));
		if( AOM_ask_value_string(bomline_tag,"bl_Design_t5_RevPartType",&rev_type_name));
		if( AOM_ask_value_string(bomline_tag,"bl_rev_release_status_list",&bcm_release_status));

		if (tc_strcmp(bcm_type_name,"Design Revision") == 0 && tc_strcmp(rev_type_name,"Module") == 0)
		{
			if(tc_strstr(bcm_release_status,"Release") != NULL)
			{
			POM_get_user(&username,&user_tag);
			POM_ask_group(&group_name, &group_tag);
			SA_ask_user_identifier2	(user_tag,&userid);
			printf ("\n bomline_cut_method--Logged in user:%s %s\n",userid, username);fflush(stdout);
			if((tc_strcmp(group_name,"Master_Data_Mgmt")!=0) && (tc_strcmp(username,"infodba")!=0))
			{
				printf("\n bomline_cut_method--Released Part, bomline cut not allowed:%s %s\n");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err,"\nBomline cut not allowed, Module is already released");
				return ITK_err;
			}
			}
			else //review or working
			{
				POM_get_user(&username,&user_tag);
				POM_ask_group(&group_name, &group_tag);
				SA_ask_user_identifier2	(user_tag,&userid);
				printf ("\n bomline_cut_method--Logged in user:%s %s\n",userid, username);fflush(stdout);
				//if((tc_strcmp(username,"su_mdm")!=0) && (tc_strcmp(username,"infodba")!=0))
				if((tc_strcmp(group_name,"Master_Data_Mgmt")!=0) && (tc_strcmp(username,"infodba")!=0))
				{
					//if(BOM_line_look_up_attribute("bl_Design Revision_t5_ModuleAddress",&modadd)!=ITK_ok) PrintErrorStack();
					if(modadd > 0)
					{
						//if(BOM_line_ask_attribute_string(bomline_tag, modadd, &mod_addr)!=ITK_ok) PrintErrorStack();
						if( AOM_ask_value_string(bomline_tag,"bl_Design Revision_t5_ModuleAddress",&mod_addr));
						printf("\n  bomline_cut_method--mod_addr:%s\n",mod_addr);fflush(stdout);
						if(mod_addr != NULL && strlen(mod_addr) > 0)
						{
							designer_role = (char *)MEM_alloc ((strlen(mod_addr) + strlen("_Designers")) * sizeof(char));
							strcpy(designer_role,mod_addr);
							strcat(designer_role,"_Designers");
							manager_role  = (char *)MEM_alloc ((strlen(mod_addr) + strlen("_Managers")) * sizeof(char));
							strcpy(manager_role,mod_addr);
							strcat(manager_role,"_Managers");
							printf("\n bomline_cut_method--search for role:%s OR %s\n",designer_role,manager_role);fflush(stdout);

							if(SA_find_groupmember_by_rolename(designer_role,"ERC_Designers_Group",userid,&designer_found,&list)!=ITK_ok) PrintErrorStack();
							if(SA_find_groupmember_by_rolename(manager_role,"ERC_Designers_Group",userid,&manager_found,&list)!=ITK_ok) PrintErrorStack();
							printf("\n  bomline_cut_method--designer_found:%d manager_found:%d\n",designer_found,manager_found); fflush(stdout);
							if(designer_found == 0 && manager_found == 0)
							{
								printf("\n bomline_cut_method--You don't have access to cut the bomline...!!\n");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,"\nYou don't have access to cut the bomline.");
								return ITK_err;
							}
						}
						else
						{
							printf("\n bomline_cut_method--Module Address is blank, hence cannot cut the bomline...!!\n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"\nModule Address is blank, hence cannot cut the bomline.");
							return ITK_err;

						}
					}
					else
					{
						printf("\n bomline_cut_method--Module Address not found, hence cannot cut the bomline...!!\n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"\nModule Address not found, hence cannot cut the bomline.");
						return ITK_err;
					}
				}
			}
		}
		//}
		//}
	}

	////Neha :CR/ERC/PLM/24/0045
	//int			SupportFlag			= 0;
	//char		*SupportUsername9	= NULL;
	//tag_t		SessionUser9_tag	= NULLTAG;
	////char		*group_name			= NULL;
	////tag_t		group_tag			= NULLTAG;
	////char		*userid				= NULL;
	////char		*username			= NULL;
	////tag_t		user_tag			= NULLTAG;
	//char		*rel_stat1			= NULL;
	//int			revstat				= 0;
	//int			CtrEtry1			= 1;
	//int			QryC1				= 0;
	//tag_t		CtrObjQryTag1		= NULLTAG;
	//tag_t		*CtrObjSet1			= NULLTAG;
	//char		*QryEtry1[1]		= {"SYSCD"};
	//char		**QryVal1			= (char **) MEM_alloc(100 * sizeof(char *));
	//
	//POM_get_user(&username,&user_tag);
	//SA_ask_user_identifier2	(user_tag,&userid);
	//printf ("\n bomline_cut_method--CR_0045:CutMethod Logged in user:%s %s\n",userid, username);fflush(stdout);
	//
	//POM_get_user(&SupportUsername9,&SessionUser9_tag);
	//POM_ask_group(&group_name, &group_tag);
	//
	//if(SessionUser9_tag!=NULLTAG)
	//{
	//	SupportFlag=0;
	//	SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
	//	printf("\n bomline_cut_method--CR_0045:CutMethod Inside SupportFlag.: %d",SupportFlag);fflush(stdout);
	//}
	//
	//printf("\n bomline_cut_method--CR_0045:CutMethod Group name of %s : [%s] \n",SupportUsername9,group_name);fflush(stdout);
	//
	//QRY_find2("ControlObjQry", &CtrObjQryTag1);
	//if (CtrObjQryTag1)
	//{
	//	QryVal1[0] = "modifyCtl";
	//	QRY_execute(CtrObjQryTag1, CtrEtry1, QryEtry1, QryVal1, &QryC1, &CtrObjSet1);
	//}
	//
	//printf("\n bomline_cut_method--CR_0045:CutMethod modifyCtl ControlObjQry : %d", QryC1);fflush(stdout);
	//if(QryC1>0)
	//{
	//	if((SupportFlag==0) && (tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (tc_strcmp(username,"aplloader")==0))
	//	{
	//
	//		if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&revstat)!=ITK_ok) PrintErrorStack();
	//		if(BOM_line_ask_attribute_string(bomline_tag, revstat, &rel_stat1)!=ITK_ok) PrintErrorStack();
	//		printf("\n bomline_cut_method--CR_0045:CutMethod Release status : [%s] \n",rel_stat1);fflush(stdout);
	//
	//		if((tc_strstr(rel_stat1,"ERC Released") != NULL) && ((tc_strstr(group_name,"ERC_Designers_Group") != NULL) || (tc_strstr(group_name,"Vehicle_Integration") != NULL) || (tc_strstr(group_name,"Colour_Designer_Group") != NULL)))
	//		{
	//			printf("\n bomline_cut_method--Part is released, structure updation is not allowed \n");fflush(stdout);
	//			EMH_clear_errors();
	//			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
	//			return ITK_err;
	//		}
	//		else if(((tc_strcmp(rel_stat1,"ERC Review") == 0) || (tc_strcmp(rel_stat1,"ERC Working") == 0)) && (tc_strstr(group_name,"APL") != NULL))
	//		{
	//			printf("\n bomline_cut_method--APL user is not allowed to update ERC review/working lifecycle state part structure \n");fflush(stdout);
	//			EMH_clear_errors();
	//			EMH_store_error_s1(EMH_severity_error,ITK_err,"APL user is not allowed to update ERC review/working part");
	//			return ITK_err;
	//		}
	//	}
	//}
	////CR/ERC/PLM/24/0045

	printf("\n bomline_cut_method--Completed processing------- \n"); fflush(stdout);

	return ITK_ok;
}





//function added to reverse a string BY Prince

void stringReverse(char* str)
{
    int len = strlen(str);
    char* start = str;
    char* end = str + len - 1;

    while (start < end) {
        char temp = *start;
        *start = *end;
        *end = temp;
        start++;
        end--;
    }
}

//function added to remove white space until first charcter is not coming in string BY Prince

void removeLeadingSpaces(char *str) {
    int i = 0;
    while (isspace(str[i])) {
        i++;
    }

    int j = 0;
    while (str[i] != '\0') {
        str[j] = str[i];
        i++;
        j++;
    }
    str[j] = '\0';
}

//function added,  modification on BOM only allowed when the release status is MBOM Working for the MBOM Agency BY Prince

int bomPropertyNotModified( METHOD_message_t *msg, va_list  args )
{
	printf("\n new function bomPropertyNotModified calling");
	int	error_code	= ITK_ok;
	tag_t window = NULLTAG;
	tag_t top_bom_line = NULLTAG;
	int	checked_out_uservalue = 0;
	char *cp_ChildChkOutV = NULL;
	int	rel_stat1 = 0;
	int	part_type = 0;
	int	owning_user = 0;
	int	object_type = 0;
	char *bcm_release_status1 = NULL;
	char *bcm_object_type = NULL;
	char *bcm_part_type = NULL;
	tag_t window_tag = va_arg( args, tag_t );
	tag_t		bom_bca		=	NULLTAG;

	int n_entryCntrl1 = 3;
	char *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};
	char **qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	int  control_number_found1=0;
	char *info1 = NULL;
	char *info2 = NULL;
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t qryTagCntrl1 = NULLTAG;

	QRY_find2("Control Objects...", &qryTagCntrl1);
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="BOM_Modification";
		qry_valuesCntrl1[1]="BOMModification";
		qry_valuesCntrl1[2]="0";
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		printf("\n Number of control Obj Found is: %d",control_number_found1);fflush(stdout);

		if (control_number_found1>0)
		{
			printf("\n inside control object");fflush(stdout);
			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &info1));
			printf("\n Information112 is: %s\n",info1);fflush(stdout);

			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &info2));
			printf("\n Information2 is: %s\n",info2);fflush(stdout);

			ITKCALL(BOM_ask_window_top_line(window_tag,&top_bom_line));

			//ITK_CALL(BOM_line_look_up_attribute ("bl_rev_release_status_list",&rel_stat1));
			//ITK_CALL(BOM_line_ask_attribute_string(top_bom_line, rel_stat1, &bcm_release_status1));
			if( AOM_ask_value_string(top_bom_line,"bl_rev_release_status_list",&bcm_release_status1));
			printf("\n release_status is   %s", bcm_release_status1);fflush(stdout);

			//ITK_CALL(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&object_type));
			//ITK_CALL(BOM_line_ask_attribute_string(top_bom_line, object_type, &bcm_object_type));
			if( AOM_ask_value_string(top_bom_line,"fnd0bl_line_object_type",&bcm_object_type));
			printf("\n object type  is   %s", bcm_object_type);fflush(stdout);

			char* releaseStatus = NULL;
			if((tc_strcmp(bcm_release_status1,"")!=0) && (tc_strcmp(bcm_object_type,"Design Revision")==0) )
			{
				//reverse value
				stringReverse(bcm_release_status1);
				printf("\n reverseStatusValue is   %s", bcm_release_status1);fflush(stdout);

				//strtok value by comma

				releaseStatus=strtok(bcm_release_status1,",");
				printf("\n stockStatusValue is   %s", releaseStatus);fflush(stdout);

				//reverse value
				stringReverse(releaseStatus);
				printf("\n reverseStatusValue after strtok to get current release status   %s", releaseStatus);fflush(stdout);

				//remove white space until first charcter is not coming in string
				removeLeadingSpaces(releaseStatus);
				printf("\n remove white space from current release status is   %s", releaseStatus);fflush(stdout);

				//ITK_CALL(BOM_line_look_up_attribute ("bl_Design Revision_t5_PartType",&part_type));
				//ITK_CALL(BOM_line_ask_attribute_string(top_bom_line, part_type, &bcm_part_type));

				if( AOM_ask_value_string(top_bom_line,"bl_Design Revision_t5_PartType",&bcm_part_type));
				printf("\n bl_part_type is   %s", bcm_part_type);fflush(stdout);

				//concat using comma to get unique value like ,Module,
				char * VehCat = NULL;

				if (tc_strcmp(VehCat,"NULL") !=0) MEM_free(VehCat);
				{
					VehCat = (char *)MEM_alloc(50);
					tc_strcpy(VehCat,"");
					tc_strcpy(VehCat,",");
					tc_strcat(VehCat,bcm_part_type);
					tc_strcat(VehCat,",");
					printf("\n VehCat.:%s",VehCat);fflush(stdout);
				}

				// finding group
				char *group_name= NULL;
				tag_t group_tag=NULLTAG;
				POM_ask_group(&group_name, &group_tag);
				printf("\n\n  group_name : %s\n",group_name); fflush(stdout);

				//concat using comma to get unique value like ,DBA,Support  for group

				char * VehCatInfo2 = NULL;

				if (tc_strcmp(VehCatInfo2,"NULL") !=0) MEM_free(VehCatInfo2);
				{
					VehCatInfo2 = (char *)MEM_alloc(50);
					tc_strcpy(VehCatInfo2,"");
					tc_strcpy(VehCatInfo2,",");
					tc_strcat(VehCatInfo2,group_name);
					tc_strcat(VehCatInfo2,",");
					printf("\n VehCatInfo2.:%s",VehCatInfo2);fflush(stdout);
				}

				if(((tc_strcmp(releaseStatus,"MBOM Review")==0) || (tc_strcmp(releaseStatus,"MBOM Released")==0)) || (tc_strcmp(releaseStatus,"MBOM Working")==0) )
				{
					printf("\n allowed to modify BOM these release type %s ", bcm_release_status1);fflush(stdout);
					//ITK_CALL(BOM_line_look_up_attribute ("bl_rev_checked_out",&checked_out_uservalue));
					//ITK_CALL(BOM_line_ask_attribute_string (top_bom_line, checked_out_uservalue, &cp_ChildChkOutV));

					if( AOM_ask_value_string(top_bom_line,"bl_rev_checked_out",&cp_ChildChkOutV));
					printf("\n checkedout_status is   %s", cp_ChildChkOutV);fflush(stdout);
					if(((tc_strcmp(releaseStatus,"MBOM Working")==0) && (tc_strcmp(cp_ChildChkOutV,"Y")==0) && (tc_strstr(info1,VehCat)!=NULL)) || ((tc_strstr(info2,VehCatInfo2)!=NULL)))
					{
						printf("\n  checked out part and allowed to modification \n");fflush(stdout);
					}
					else
					{
						printf("\nParent is not checked-out.\n"); fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error, ITK_err, "You cannot modify BOM as this part not in MBOM Working Release State or part is not check out.");
						return ITK_err;
					}
				}
				else
				{
					printf("\n allowed to modify other release status expect MBOM Review and MBOM Released");fflush(stdout);
				}
			}
		}
	}

	return error_code;

}


//Neha(CR-FY23-0145)
int BOMLineCheck(tag_t bomline)
{
	int			revstat				= 0;
	int			SupportFlag			= 0;
	char		*child_rev_stat		= NULL;
	char		*SupportUsername9	= NULL;
	tag_t		window				= NULLTAG;
	tag_t		SessionUser9_tag	= NULLTAG;
	char		*group_name			= NULL;
	tag_t		group_tag			= NULLTAG;
	char		*userid				= NULL;
 	char		*username			= NULL;
	tag_t		user_tag			= NULLTAG;

	if(BOM_line_ask_window(bomline,&window)!=ITK_ok) PrintErrorStack();
	if(window)
	{
		//if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&revstat)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_ask_attribute_string(bomline, revstat, &child_rev_stat)!=ITK_ok) PrintErrorStack();

		if( AOM_ask_value_string(bomline,"bl_rev_release_status_list",&child_rev_stat));
		printf("\nBOMLineCheck: Release status of : [%s] \n",child_rev_stat);fflush(stdout);

		POM_get_user(&username,&user_tag);
		SA_ask_user_identifier2	(user_tag,&userid);
		printf ("\nBOMLineCheck:Logged in user:%s %s\n",userid, username);fflush(stdout);

		POM_get_user(&SupportUsername9,&SessionUser9_tag);
		POM_ask_group(&group_name, &group_tag);

		if(SessionUser9_tag!=NULLTAG)
		{
			SupportFlag=0;
			SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
			printf("\nBOMLineCheck:Inside BOMLineCheck SupportFlag.: %d",SupportFlag);fflush(stdout);
		}

		printf("\nnBOMLineCheck: Group name of %s : [%s] \n",SupportUsername9,group_name);fflush(stdout);

		if((SupportFlag==0) && (tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0)
			&& ((tc_strcmp(userid,"aplloader")!=0) || (tc_strcmp(username,"aplloader") !=0)))
		{
			printf("\n BOMLineCheck:User is not from support group/infodba/loader/aplloader\n");fflush(stdout);

			if((tc_strstr(child_rev_stat,"Release") != NULL) ||	(tc_strstr(child_rev_stat,"T5_LcsErcRlzd") != NULL))
			{
				printf("\n Part is released hence returning error code 1 \n");fflush(stdout);
				return 1;
			}
		}
		else
		{
			printf("\n BOMLineCheck:User is from support group/infodba/loader/aplloader\n");fflush(stdout);
		}

	}
	return 0;
}

/******************************************************************************************
*   Function name			:	prop_bl_quantity_check
*   Description				:	This function provides access to su_mdm user only to
*								update the bl_quantity from Platform Structure.
*
*	Date				Modified By				Modification Notes
*	17/06/2019			Kalpesh Gondhali		1.46:
******************************************************************************************/
extern DLLAPI int prop_bl_quantity_check(METHOD_message_t *msg, va_list args)
{
	int			error_code					= ITK_ok;
	int			modadd						= 0;
	int			blobjType					= 0;
	int			blrelease					= 0;
	int			child_blobjType				= 0;

	int			attr_id						= 0;
	int			line_name					= 0;
	int			parent_nm					= 0;
	int			rev_attr_id					= 0;
	int			rel_stat					= 0;
	int			designer_found				= 0;
	int			manager_found				= 0;
	int			n_parents					= 0;
	int			*levels						= 0;
	int			child_attr			= 0;
	char		*child_qty			= NULL;

	char		*mod_addr					= NULL;
	char		*objType					= NULL;
 	char		*item_id					= NULL;
 	char		*rev_id						= NULL;
 	char		*userid						= NULL;
 	char		*username					= NULL;
	char		*bomline_objType			= NULL;
	char		*topBomLineRelease			= NULL;
	char		*bomline_name				= NULL;
	char		*child_bomline_objType		= NULL;
	char		*bcm_type_name				= NULL;
	char		*rev_type_name				= NULL;
	char		*bcm_username				= NULL;
	char		*parent_string				= NULL;
	char		*bcm_release_status			= NULL;

	char		*designer_role				= NULL;
	char		*manager_role				= NULL;

	char		*part						= NULL;
	char		*rev						= NULL;
	char		*group_name					=NULL;
	tag_t		group_tag					=NULLTAG;

	tag_t		*list;
	tag_t		*parents					= NULL;
	tag_t		rev_tag						= NULLTAG;
	tag_t		window						= NULLTAG;
	tag_t		user_tag					= NULLTAG;
	tag_t		top_bom_line				= NULLTAG;

	char* prop_value						=NULL;
	tag_t prop_tag							=NULLTAG;

	char *ctrlQryEnt[2]		= {"SYSCD", "SUBSYSCD"};
	char *ctrlQryVal[2]		= {"PltArchMQty", "PltArchMQtyy"};
	tag_t TagQryCtrlObjj		= NULLTAG;
	tag_t *cntr_objj = NULLTAG;
	int n_fndd = 0;
	int n_entryy = 1;

	//PV CV Change CR-FY24-0095 :: 27-10-2023
	tag_t	qryisCV	= NULLTAG;
	char **qryisCV_val = (char **) MEM_alloc(35 * sizeof(char *));
	int n_entrisCV = 1;
	char    *qry_entrisCV[1]  = {"SYSCD"};
	int rsltCuntisCV=0;
	tag_t *CntrlObjTagisCV=NULLTAG;
	logical isTCUAIsCV =false;
	int iqo = 0;

	tag_t bomline = msg->object_tag;

	prop_tag = va_arg(args, tag_t);
	prop_value = va_arg(args, char*);

	printf("\nprop_bl_quantity_check -->Inside prop_bl_quantity_check method...!!");

	if(BOM_line_ask_window(bomline,&window)!=ITK_ok) PrintErrorStack();
	if(window)
	{
		if(BOM_ask_window_top_line(window,&top_bom_line)!=ITK_ok) PrintErrorStack();
		if(top_bom_line)
		{
			//if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&blrelease)!=ITK_ok) PrintErrorStack();
			//if(BOM_line_ask_attribute_string(top_bom_line, blrelease, &topBomLineRelease)!=ITK_ok) PrintErrorStack();

			if( AOM_ask_value_string(top_bom_line,"bl_rev_release_status_list",&topBomLineRelease));
			printf("\nTop_Bomline topBomLineRelease:%s", topBomLineRelease);
		}
	}
	int errorCode = BOMLineCheck(top_bom_line);
	printf("\nprop_bl_quantity_check --> errorCode: [ %d ]", errorCode);
	if (errorCode)
	{
			if((tc_strstr(topBomLineRelease,"Release") != NULL ) || (tc_strstr(topBomLineRelease,"T5_LcsErcRlzd") != NULL))
			{
				printf("\nprop_bl_quantity_check --> Released Part, structure updation not allowed \n");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence attribute updation not allowed");
				return ITK_err;
			}
	}

	POM_get_user(&username,&user_tag);
	POM_ask_group(&group_name, &group_tag);
	if(BOM_line_ask_window(bomline,&window)!=ITK_ok) PrintErrorStack();
	if(window)
	{
		if(BOM_ask_window_top_line(window,&top_bom_line)!=ITK_ok) PrintErrorStack();
		if(top_bom_line)
		{
			//if(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&blobjType)!=ITK_ok) PrintErrorStack();
			//if(BOM_line_ask_attribute_string(top_bom_line, blobjType, &bomline_objType)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(top_bom_line,"fnd0bl_line_object_type",&bomline_objType));
			printf("\nprop_bl_quantity_check -->Top_Bomline obj_type:%s", bomline_objType);
			if (tc_strcmp(bomline_objType,"T5_PlatformRevision") == 0)
			{
				//if(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&child_blobjType)!=ITK_ok) PrintErrorStack();
				//if(BOM_line_ask_attribute_string(bomline, child_blobjType, &child_bomline_objType)!=ITK_ok) PrintErrorStack();

				if( AOM_ask_value_string(bomline,"fnd0bl_line_object_type",&child_bomline_objType));
				printf("\nprop_bl_quantity_check -->Child_Bomline obj_type:%s\n", child_bomline_objType);
			 	if (tc_strcmp(child_bomline_objType,"T5_ArchModuleRevision") == 0)
				{
					SA_ask_user_identifier2	(user_tag,&userid);
					printf ("\nprop_bl_quantity_check -->Logged in user:%s %s\n",userid, username);fflush(stdout);

					//Neha(CR-FY23-0166)
					if(QRY_find2("ControlObjQry", &TagQryCtrlObjj));
					if(QRY_execute(TagQryCtrlObjj, n_entryy, ctrlQryEnt, ctrlQryVal, &n_fndd, &cntr_objj));
					printf("\nprop_bl_quantity_check --> PltArchMQty control object nfound variable size == %d", n_fndd);fflush(stdout);

					if(n_fndd>0)
					{
						if((tc_strcmp(group_name, "Master_Data_Mgmt") != 0) && (tc_strcmp(username,"infodba")!=0))
						{
							printf("\nprop_bl_quantity_check -->Only (Master_Data_Mgmt) group user can update the quantity of Arch. Module.\n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error, ITK_err, "You can't update the quantity of Arch. Module.");
							return ITK_err;
						}
					}

					//if((tc_strcmp(group_name, "Master_Data_Mgmt") != 0) && (tc_strcmp(username,"infodba")!=0))
					//{
						printf("\nprop_bl_quantity_check -->Only (Master_Data_Mgmt) group user can update the quantity of Arch. Module.\n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error, ITK_err, "You can't update the quantity of Arch. Module.");
						return ITK_err;
					//}
				}
			}

			//NSS [CR-FY24-0138]
			//Qty user restriction for greater than 1 qty
			printf("\n prop_bl_quantity_check CR-FY24-0138: Objectt typee [%s]",bomline_objType); fflush(stdout);
			if ((tc_strcmp(bomline_objType,"Design Revision")==0) || (tc_strcmp(bomline_objType,"T5_SparKitRevision")==0)
				|| (tc_strcmp(bomline_objType,"T5_EE_PartRevision")==0)) // T5_SparKitRevision/T5_EE_PartRevision added for CR/ERC/PLM/25/0110
			{

				char	*cPrtNum	= NULL;
				char	*iInfo3		= NULL;
				char	*iInfo4		= NULL;
				char	*iPrtTyp	= NULL;
				char	*iUOM		= NULL;
				char	*masterUOM	= NULL;

				int		iCtrEtry1	= 1;
				int		iQryC1		= 0;
				int		iJ			= 0;

				tag_t	tCtrlQT			= NULLTAG;
				tag_t	*tCtrObjSet		= NULLTAG;

				char	*iQryEtry1[1]	=  {"SYSCD"};
				char	**iQryVal1		=  (char **) MEM_alloc(100 * sizeof(char *));

				QRY_find2("ControlObjQry", &tCtrlQT);
				if (tCtrlQT)
				{
					iQryVal1[0] = "QtyCheck";
					QRY_execute(tCtrlQT, iCtrEtry1, iQryEtry1, iQryVal1, &iQryC1, &tCtrObjSet);
				}
				printf("\n\n prop_bl_quantity_check CR-FY24-0138: QtyCheck Control object found = [%d]",iQryC1);fflush(stdout);

				if(iQryC1 > 0)
				{
					if (AOM_ask_value_string(tCtrObjSet[0], "t5_Userinfo3", &iInfo3)!=ITK_ok);
					printf("\n prop_bl_quantity_check CR-FY24-0138: Information3 is: [%s]",iInfo3);fflush(stdout);

					if (AOM_ask_value_string(tCtrObjSet[0],"t5_Userinfo4",&iInfo4)!=ITK_ok);
					printf("\n prop_bl_quantity_check CR-FY24-0138: Information4 is: [%s]",iInfo4);fflush(stdout);

					if (AOM_ask_value_string(top_bom_line,"bl_Design Revision_t5_PartType",&iPrtTyp));
					printf("\n prop_bl_quantity_check CR-FY24-0138: Part type is: [%s]",iPrtTyp);fflush(stdout);

					if ((tc_strcmp(iInfo3,"ON")==0) && (tc_strstr(iInfo4,iPrtTyp)))
					{
						printf("\n prop_bl_quantity_check CR-FY24-0138: group_name [%s]",group_name);fflush(stdout);

						if((tc_strstr(group_name,"ERC_Designers_Group")) || (tc_strstr(group_name,"Vehicle_Integration")))
						{
							printf("\n prop_bl_quantity_check CR-FY24-0138: => Inside if condition of group ERC_Designers_Group/Vehicle_Integration");fflush(stdout);
							printf("\n prop_bl_quantity_check CR-FY24-0138: Object type [%s]",bomline_objType); fflush(stdout);

							//if (tc_strcmp(bomline_objType,"Design Revision")==0)
							//{
								printf("\n prop_bl_quantity_check CR-FY24-0138: prop_value--> [%s]\n",prop_value); fflush(stdout);
								iJ = atoi(prop_value);
								printf("\n prop_bl_quantity_check CR-FY24-0138: After typecast prop_value--> [%d]\n",iJ); fflush(stdout);

								if(AOM_ask_value_string(bomline,"bl_Design Revision_t5_uom",&iUOM)!=ITK_ok) PrintErrorStack();
								printf("\n prop_bl_quantity_check CR-FY24-0138: UOMMM Value is [%s]",iUOM); fflush(stdout);

								//if(AOM_ask_value_string(bomline,"bl_uom",&masterUOM)!=ITK_ok) PrintErrorStack();
								//printf("\n checkin_method_1 CR-FY24-0138: Master UOM Value is [%s]",masterUOM); fflush(stdout);

								if ((tc_strcmp(iUOM,"4-Nos")==0) || (tc_strcmp(iUOM,"each")==0) || (tc_strcmp(iUOM,"")==0)) // Validation is only applicable for parts which is having UOM value 4
								{
									printf("\n prop_bl_quantity_check CR-FY24-0138: UOM is each/4-Nos"); fflush(stdout);

									if(tc_strcmp(prop_value,"")==0)
									{
										printf("\n prop_bl_quantity_check CR-FY24-0138: 1. prop_value	--> [%s]\n",prop_value); fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Quantity value Can't be blank");
										return ITK_errStore;
									}

									if(iJ>1)
									{
										printf("\n prop_bl_quantity_check CR-FY24-0138: 2. prop_value	--> [%s]\n",prop_value); fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Quantity value should be either 0 or 1");
										return ITK_errStore;
									}
								}
								else
								{
									printf("\n prop_bl_quantity_check CR-FY24-0138: UOM is not each/4-Nos"); fflush(stdout);
								}
							//}
						}
					}
					else
					{
						printf("\n prop_bl_quantity_check CR-FY24-0138: Control object doesn't contain part type [%s]",iPrtTyp);fflush(stdout);
					}
				}
			}
			//End NSS CR-FY24-0138
		}
	}

	/*if(BOM_line_ask_window(bomline,&window)!=ITK_ok) PrintErrorStack();
	if(window)
	{
		if(BOM_ask_window_top_line(window,&top_bom_line)!=ITK_ok) PrintErrorStack();
		if(top_bom_line)
		{*/


		printf("\nInside parent check...!!");
		//if(BOM_line_look_up_attribute ("bl_formatted_parent_name",&parent_nm)!=ITK_ok) PrintErrorStack();
		//if(BOM_line_ask_attribute_string(bomline, parent_nm, &parent_string)!=ITK_ok) PrintErrorStack();

		if( AOM_ask_value_string(bomline,"bl_formatted_parent_name",&parent_string));
		printf("\nparent_str:%s", parent_string);

	/*part = strtok(parent_string, "/");
	rev =  strtok(NULL, "-");

	if(ITEM_find_rev(part, rev, &rev_tag)!=ITK_ok) PrintErrorStack();
	if(AOM_UIF_ask_value(rev_tag, "object_type", &objType)!=ITK_ok) PrintErrorStack();

	if (tc_strcmp(objType,"Architecture Module Revision") == 0)
			{*/
	if(tc_strstr(parent_string, "X4M") != NULL || tc_strcmp(bomline_objType,"T5_ArchModuleRevision") == 0)
	{
//	if(PS_where_used_all(bomline,1,&n_parents,&levels,&parents)!=ITK_ok) PrintErrorStack();
//	{
//		printf("\ncount_parent:%d\n", n_parents);
//		if(n_parents > 0)
//		{
//			if(BOM_line_look_up_attribute ("bl_line_name",&line_name)!=ITK_ok) PrintErrorStack();
//			if(BOM_line_ask_attribute_string(parents[0], line_name, &bomline_name)!=ITK_ok) PrintErrorStack();
//			printf("\nBomline_name:%s\n", bomline_name);
//
//			if(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&blobjType)!=ITK_ok) PrintErrorStack();
//			if(BOM_line_ask_attribute_string(top_bom_line, blobjType, &bomline_objType)!=ITK_ok) PrintErrorStack();
//			printf("\nTop_Bomline obj_type:%s", bomline_objType);
//			if (tc_strcmp(bomline_objType,"T5_ArchModuleRevision") == 0)
//			{
				//if(BOM_line_look_up_attribute("fnd0bl_line_object_type", &attr_id)!=ITK_ok) PrintErrorStack();
				//if(BOM_line_ask_attribute_string(bomline, attr_id, &bcm_type_name)!=ITK_ok) PrintErrorStack();
				//if(BOM_line_look_up_attribute("bl_Design_t5_RevPartType", &rev_attr_id)!=ITK_ok) PrintErrorStack();
				//if(BOM_line_ask_attribute_string(bomline, rev_attr_id, &rev_type_name)!=ITK_ok) PrintErrorStack();
				//if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&rel_stat)!=ITK_ok) PrintErrorStack();
				//if(BOM_line_ask_attribute_string(bomline, rel_stat, &bcm_release_status)!=ITK_ok) PrintErrorStack();

				if( AOM_ask_value_string(bomline,"fnd0bl_line_object_type",&bcm_type_name));
				if( AOM_ask_value_string(bomline,"bl_Design_t5_RevPartType",&rev_type_name));
				if( AOM_ask_value_string(bomline,"bl_rev_release_status_list",&bcm_release_status));

				printf("\nObject_type:%s and Part_type:%s\n", bcm_type_name, rev_type_name);
				if (tc_strcmp(bcm_type_name,"Design Revision") == 0 && tc_strcmp(rev_type_name,"Module") == 0)
				{
					if(tc_strstr(bcm_release_status,"Release") != NULL)
					{
						POM_get_user(&username,&user_tag);
						SA_ask_user_identifier2	(user_tag,&userid);
						printf ("\nLogged in user:%s %s\n",userid, username);fflush(stdout);
						char *SupportUsername9 = NULL;
						tag_t SessionUser9_tag=NULLTAG;
						int     SupportFlag      =  0;

						SupportFlag=0;
						POM_get_user(&SupportUsername9,&SessionUser9_tag);
						if(SessionUser9_tag!=NULLTAG)
						{
							SupportFlag=0;
							SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
							printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
						}
						//if((tc_strcmp(username,"su_mdm")!= 0) && (tc_strcmp(username,"infodba")!=0) && (tc_strcmp(userid,"ercpsup")!=0))
						if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0) && (tc_strcmp(group_name, "Master_Data_Mgmt") != 0))
						{
							printf("\n Released Part, not allowed to update the quantity\n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"\nCan't update bomline quantity, Module is already released");
							return ITK_err;
						}
					}
					else //review or working
					{
						POM_get_user(&username,&user_tag);
						SA_ask_user_identifier2	(user_tag,&userid);
						printf ("Logged in user:%s %s\n",userid, username);fflush(stdout);
						if((tc_strcmp(group_name,"Master_Data_Mgmt")!= 0) && (tc_strcmp(username,"infodba")!=0))
						{
							//if(BOM_line_look_up_attribute("bl_Design Revision_t5_ModuleAddress",&modadd)!=ITK_ok) PrintErrorStack();

							//if(modadd > 0)
							//{
								//if(BOM_line_ask_attribute_string(bomline, modadd, &mod_addr)!=ITK_ok) PrintErrorStack();

								if( AOM_ask_value_string(bomline,"bl_Design Revision_t5_ModuleAddress",&mod_addr));

								printf("\n mod_addr:%s\n",mod_addr);fflush(stdout);
								if(mod_addr != NULL && strlen(mod_addr) > 0)
								{

									designer_role = (char *)MEM_alloc ((strlen(mod_addr) + strlen("_Designers")) * sizeof(char));
									strcpy(designer_role,mod_addr);
									strcat(designer_role,"_Designers");
									manager_role  = (char *)MEM_alloc ((strlen(mod_addr) + strlen("_Managers")) * sizeof(char));
									strcpy(manager_role,mod_addr);
									strcat(manager_role,"_Managers");
									printf("\nsearch for role:%s OR %s\n",designer_role,manager_role);fflush(stdout);

									if(SA_find_groupmember_by_rolename(designer_role,"ERC_Designers_Group",userid,&designer_found,&list)!=ITK_ok) PrintErrorStack();
									if(SA_find_groupmember_by_rolename(manager_role,"ERC_Designers_Group",userid,&manager_found,&list)!=ITK_ok) PrintErrorStack();
									printf("\n designer_found:%d manager_found:%d\n",designer_found,manager_found); fflush(stdout);
									if(designer_found == 0 && manager_found == 0)
									{
										printf("\nYou don't have access to update the quantity of bomline.\n");fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err,"\nYou don't have access to update the quantity of bomline.");
										return ITK_err;
									}

								}
								else
								{
									printf("\nModule Address is blank, hence cannot update the quantity of bomline.\n");fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err,"\nModule Address is blank, hence cannot update the quantity of bomline.");
									return ITK_err;

								}
							//}
							//else
							//{
							//	printf("\nModule Address not found, hence cannot update the quantity of bomline.\n");fflush(stdout);
							//	EMH_clear_errors();
							//	EMH_store_error_s1(EMH_severity_error,ITK_err,"\nModule Address not found, hence cannot update the quantity of bomline.");
							//	return ITK_err;
							//}
						}
					}
					printf("\nUser is trying to update : prop_value : -- %s",prop_value);
					// check if TCUA Env is PV or CV
					if(QRY_find2("ControlObjects", &qryisCV));
					if (qryisCV)
					{
						printf("\n ControlObjects:.Found Query qryisCV \n");fflush(stdout);
					}
					else
					{
						printf("\n ControlObjects:.Not Found Query qryisCV \n");fflush(stdout);
					}
					qryisCV_val[0] = "CV_ZeroQty";
					if(QRY_execute(qryisCV, n_entrisCV, qry_entrisCV, qryisCV_val, &rsltCuntisCV, &CntrlObjTagisCV));
					printf(" \n CV_ZeroQty::::>>> :%d:", rsltCuntisCV); fflush(stdout);
					if(rsltCuntisCV	> 0)
					{
						isTCUAIsCV =true;
					}
					//if(BOM_line_look_up_attribute ("bl_quantity",&child_attr)!=ITK_ok) PrintErrorStack();
					//if(BOM_line_ask_attribute_string (bomline, child_attr, &child_qty)!=ITK_ok) PrintErrorStack();
					//printf("\n Child Qty is===============>>>>>> %s\n",child_qty);fflush(stdout);
					if(tc_strcmp(prop_value,"0") == 0 || tc_strlen(prop_value) == 0)
					{
						if(isTCUAIsCV)
						{
							if((tc_strcmp(group_name,"Master_Data_Mgmt")== 0))
							{
								printf("\nZero OR blank Quantity is allowed, As env is CV and group is MDM.\n");fflush(stdout);
							}
							else
							{
								printf("\nZero OR blank Quantity is not allowed.\n");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,"\nZero OR blank Quantity is not allowed.");
								return ITK_err;
							}
						}
						else
						{
							printf("\nZero OR blank Quantity is not allowed.\n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"\nZero OR blank Quantity is not allowed.");
							return ITK_err;
						}

					}
				}
			//}
		//}
	}

	return error_code;
}

//Neha - TZ 1.77
int BOMLineChldReviewChk(tag_t bomline)
{
	int			revstat				= 0;
	int			SupportFlag			= 0;
	char		*child_rev_stat		= NULL;
	char		*parent_rev_stat	= NULL;
	char		*SupportUsername9	= NULL;
	tag_t		window				= NULLTAG;
	tag_t		SessionUser9_tag	= NULLTAG;
	char		*group_name			= NULL;
	tag_t		group_tag			= NULLTAG;
	char		*userid				= NULL;
 	char		*username			= NULL;
	tag_t		user_tag			= NULLTAG;
	tag_t		top_bom_line		= NULLTAG;


	if(BOM_line_ask_window(bomline,&window)!=ITK_ok) PrintErrorStack();
	if(window)
	{
		if(BOM_ask_window_top_line(window,&top_bom_line)!=ITK_ok) PrintErrorStack();
		if(top_bom_line)
		{
			//if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&revstat)!=ITK_ok) PrintErrorStack();
			//if(BOM_line_ask_attribute_string(top_bom_line, revstat, &parent_rev_stat)!=ITK_ok) PrintErrorStack();

			if( AOM_ask_value_string(top_bom_line,"bl_rev_release_status_list",&parent_rev_stat));
			printf("\n BOMLineChldReviewChk: Release status of Parent : [%s] \n",parent_rev_stat);fflush(stdout);

			//if(BOM_line_ask_attribute_string(bomline, revstat, &child_rev_stat)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(bomline,"bl_rev_release_status_list",&child_rev_stat));
			printf("\n BOMLineChldReviewChk: Release status of child : [%s] \n",child_rev_stat);fflush(stdout);

			POM_get_user(&username,&user_tag);
			SA_ask_user_identifier2	(user_tag,&userid);
			printf ("\n BOMLineChldReviewChk: Logged in user:%s %s\n",userid, username);fflush(stdout);

			POM_get_user(&SupportUsername9,&SessionUser9_tag);
			POM_ask_group(&group_name, &group_tag);

			if(SessionUser9_tag!=NULLTAG)
			{
				SupportFlag=0;
				SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
				printf("\n BOMLineChldReviewChk:Inside BOMLineCheck SupportFlag.: %d",SupportFlag);fflush(stdout);
			}

			printf("\n BOMLineChldReviewChk: Group name of %s : [%s] \n",SupportUsername9,group_name);fflush(stdout);

			if((SupportFlag==0) && (tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (tc_strcmp(username,"aplloader")!=0))
			{
				printf("\n BOMLineChldReviewChk: User is not from support group/infodba/loader/aplloader\n");fflush(stdout);
				//if((tc_strstr(parent_rev_stat,"Release") != NULL) || (tc_strcmp(parent_rev_stat,"ERC Review") == 0))
				//condition updated because user is able to update attribute from ERC Review state
				if((tc_strcmp(parent_rev_stat,"ERC Released") == 0)|| (tc_strstr(parent_rev_stat,"T5_LcsErcRlzd") != NULL)
					|| (tc_strcmp(parent_rev_stat,"ERC Review") == 0) ||	(tc_strstr(parent_rev_stat,"T5_LcsReview") != NULL)
					||	(tc_strstr(child_rev_stat,"T5_LcsReview") != NULL) || (tc_strcmp(child_rev_stat,"ERC Review") == 0)
					||	(tc_strstr(child_rev_stat,"T5_LcsErcRlzd") != NULL) || (tc_strcmp(child_rev_stat,"ERC Released") == 0))
				{
					printf("\n Parent part is released/review hence returning error code 1 \n");fflush(stdout);
					return 1;
				}
			}
			else
			{
				printf("\n BOMLineChldReviewChk: User is from support group/infodba/loader/aplloader\n");fflush(stdout);
			}
		}
	}

	return 0;
}

extern DLLAPI int prop_bl_method_check(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	int CtrEtry = 1;
	int QryC = 0;
	int QryC1 = 0;
	tag_t CtrObjQryTag = NULLTAG;
	tag_t		*CtrObjSet	= NULLTAG;
	tag_t		*CtrObjSet1	= NULLTAG;
	char		*QryEtry[1]	= {"SYSCD"};
	char		**QryVal	= (char **) MEM_alloc(100 * sizeof(char *));
	char		**QryVal1	= (char **) MEM_alloc(100 * sizeof(char *));
	tag_t		CurrRoleTag	= NULLTAG;

	printf("\n ****11.INSIDE prop_bl_method_check**** \n");fflush(stdout);
	tag_t bomline = msg->object_tag;

	QRY_find2("ControlObjQry", &CtrObjQryTag);
	if (CtrObjQryTag)
	{
		QryVal[0] = "releasedBOMVal";
		QRY_execute(CtrObjQryTag, CtrEtry, QryEtry, QryVal, &QryC, &CtrObjSet);
	}
	printf("\n prop_bl_method_check: releasedBOMVal : %d\n",QryC);fflush(stdout);

	if (CtrObjQryTag)
	{
		QryVal1[0] = "releasedReviewBOMVal";
		QRY_execute(CtrObjQryTag, CtrEtry, QryEtry, QryVal1, &QryC1, &CtrObjSet1);
	}
	printf("\n prop_bl_method_check: releasedReviewBOMVal : %d\n",QryC1);fflush(stdout);

	if(QryC>0)
	{
		int errorCode = BOMLineCheck(bomline);
		printf("\n prop_bl_method_check: Error code : %d\n",errorCode);fflush(stdout);

		if (errorCode)
		{
			printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Part has been released, hence updating attributes is prohibited.");
			return ITK_err;
		}
	}

	if(QryC1>0)
	{
		int errCode = BOMLineChldReviewChk(bomline);
		printf("\n prop_bl_method_check: Error code : %d\n",errCode);fflush(stdout);

		if (errCode)
		{
			printf("\n Parent part is Released, structure attribute updation not allowed \n");fflush(stdout);
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Updates to child part attributes are prohibited because the parent part has been released/review.");
			return ITK_err;
		}
	}

	return error_code;
}

extern DLLAPI int prop_bl_method_KeyDesc_check(METHOD_message_t *msg, va_list args)
{
	int			error_code			= ITK_ok;
	int			revstat				= 0;
	int			SupportFlag			= 0;
	char		*child_rev_stat		= NULL;
	char		*parent_rev_stat	= NULL;
	char		*SupportUsername9	= NULL;
	tag_t		window				= NULLTAG;
	tag_t		SessionUser9_tag	= NULLTAG;
	tag_t		top_bom_line		= NULLTAG;

	char *ctrlQryEntries[2] = {"SYSCD", "SUBSYSCD"};
	char *ctrlQryValues[2] = {"bom_keyDes", "bom_keyDes1"};
	tag_t TagCtrlQryObj = NULLTAG,*ctrlCntrObj = NULL;
	tag_t TagCtrlQryContObj = NULLTAG;
	int		nEntr		= 2;
	int		nFnd		= 0;

	char ref_type_name[TCTYPE_name_size_c+1];


	printf("\n ***INSIDE prop_bl_method_KeyDesc_check*** \n");fflush(stdout);
	tag_t bomline = msg->object_tag;

	if(BOM_line_ask_window(bomline,&window)!=ITK_ok) PrintErrorStack();
	if(window)
	{
		if(BOM_ask_window_top_line(window,&top_bom_line)!=ITK_ok) PrintErrorStack();
		if(top_bom_line)
		{
			//if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&revstat)!=ITK_ok) PrintErrorStack();
			//if(BOM_line_ask_attribute_string(top_bom_line, revstat, &parent_rev_stat)!=ITK_ok) PrintErrorStack();

			if( AOM_ask_value_string(top_bom_line,"bl_rev_release_status_list",&parent_rev_stat));
			printf("\n Release status of Parent : [%s] \n",parent_rev_stat);fflush(stdout);

			//if(BOM_line_ask_attribute_string(bomline, revstat, &child_rev_stat)!=ITK_ok) PrintErrorStack();

			if( AOM_ask_value_string(bomline,"bl_rev_release_status_list",&child_rev_stat));
			printf("\n Release status of child : [%s] \n",child_rev_stat);fflush(stdout);
		}
	}


	POM_get_user(&SupportUsername9,&SessionUser9_tag);
	if(SessionUser9_tag!=NULLTAG)
	{
		SupportFlag=0;
		SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
		printf("\n SupportFlag............: %d",SupportFlag);fflush(stdout);
	}

	if(SupportFlag==0)
	{
		if(QRY_find2("ControlObjQry", &TagCtrlQryObj));
		if(QRY_execute(TagCtrlQryContObj, nEntr, ctrlQryEntries, ctrlQryValues, &nFnd, &ctrlCntrObj));
		printf("\n bom_keyDes ControlObjQry : %d", nFnd);fflush(stdout);
		if(nFnd>0)
		{
			if((tc_strstr(child_rev_stat,"Release") != NULL) || (tc_strstr(child_rev_stat,"T5_LcsErcRlzd") != NULL))
			{
				printf("\n Released Part, structure updation not allowed \n");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Part is released hence  attribute updation not allowed");
				return ITK_err;
			}
		}
	}
	return error_code;
}

extern DLLAPI int prop_bl_method_mainsrl_check(METHOD_message_t *msg, va_list args)
{
	int		error_code		= ITK_ok;
	int		CtrEtry			= 1;
	int		QryC			= 0;
	int		blrelease		= 0;
	int		attr_id			= 0;
	int     SupportFlag     = 0;

	tag_t	CtrObjQryTag		= NULLTAG;
	tag_t	*CtrObjSet			= NULLTAG;
	tag_t	window				= NULLTAG;
	tag_t	top_bom_line		= NULLTAG;
	tag_t	SessionUser9_tag	= NULLTAG;
	tag_t	user_tag			= NULLTAG;


	char	*bcm_type_name		= NULL;
	char	*SupportUsername9	= NULL;
	char	*topBomLineRelease	= NULL;
	char	*username			= NULL;
	char	*userid				= NULL;
	char	*QryEtry[1]			= {"SYSCD"};
	char	**QryVal			= (char **) MEM_alloc(100 * sizeof(char *));


	printf("\n **** INSIDE prop_bl_method_mainsrl_check **** \n");fflush(stdout);
	tag_t bomline = msg->object_tag;

	QRY_find2("ControlObjQry", &CtrObjQryTag);
	if (CtrObjQryTag)
	{
		QryVal[0] = "blMainSrlCheck";
		QRY_execute(CtrObjQryTag, CtrEtry, QryEtry, QryVal, &QryC, &CtrObjSet);
	}
	printf("\n prop_bl_method_mainsrl_check: blMainSrlCheck : %d\n",QryC);fflush(stdout);

	if(QryC>0)
	{
		if(BOM_line_ask_window(bomline,&window)!=ITK_ok) PrintErrorStack();
		if(window)
		{
			if(BOM_ask_window_top_line(window,&top_bom_line)!=ITK_ok) PrintErrorStack();
			if(top_bom_line)
			{
				//if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&blrelease)) PrintErrorStack();
				//if(BOM_line_ask_attribute_string(top_bom_line, blrelease, &topBomLineRelease)) PrintErrorStack();
				//
				//if(BOM_line_look_up_attribute("fnd0bl_line_object_type", &attr_id)!=ITK_ok) PrintErrorStack();
				//if(BOM_line_ask_attribute_string(top_bom_line, attr_id, &bcm_type_name)!=ITK_ok) PrintErrorStack();

				if( AOM_ask_value_string(top_bom_line,"bl_rev_release_status_list",&topBomLineRelease));
				if( AOM_ask_value_string(top_bom_line,"fnd0bl_line_object_type",&bcm_type_name));

				printf("\n prop_bl_method_mainsrl_check: Top_Bomline release status : [%s] and Object Type : [%s]", topBomLineRelease,bcm_type_name);

				if(tc_strcmp(bcm_type_name,"Design Revision") == 0)
				{
					if( (tc_strstr(topBomLineRelease,"Release") != NULL) || (tc_strstr(topBomLineRelease,"Review") != NULL) ||
						(tc_strstr(topBomLineRelease,"T5_LcsErcRlzd") != NULL) || (tc_strstr(topBomLineRelease,"T5_LcsReview") != NULL) )
					{
						POM_get_user(&username,&user_tag);
						SA_ask_user_identifier2	(user_tag,&userid);
						printf ("\n prop_bl_method_mainsrl_check : Logged in user:%s %s\n",userid, username);fflush(stdout);
						SupportFlag=0;
						POM_get_user(&SupportUsername9,&SessionUser9_tag);

						if(SessionUser9_tag!=NULLTAG)
						{
							SupportFlag=0;
							SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
							printf("\n prop_bl_method_mainsrl_check : SupportFlag.: %d",SupportFlag);fflush(stdout);
						}

						if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0)
							&& ((tc_strcmp(userid,"aplloader")!=0) || (tc_strcmp(username,"aplloader") !=0)))
						{

							printf("\n prop_bl_method_mainsrl_check : Main serial update not permitted for parent part in released/review vault. \n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"\n Main serial update not permitted for parent part in released/review vault.");
							return ITK_err;
						}
						else
						{
							printf("\n prop_bl_method_mainsrl_check : User is either infodba/loader/support");fflush(stdout);
						}
					}
					else
					{
							printf("\n prop_bl_method_mainsrl_check : Part is in ERC working");fflush(stdout);
					}
				}
			}
		}
	}
	return error_code;
}

extern DLLAPI int prop_bl_method_absoluteTmatrix_check(METHOD_message_t *msg, va_list args)
{
	int		error_code		= ITK_ok;
	int		CtrEtry			= 1;
	int		QryC			= 0;
	int		blrelease		= 0;
	int		attr_id			= 0;
	int     SupportFlag     = 0;

	tag_t	CtrObjQryTag		= NULLTAG;
	tag_t	*CtrObjSet			= NULLTAG;
	tag_t	window				= NULLTAG;
	tag_t	top_bom_line		= NULLTAG;
	tag_t	SessionUser9_tag	= NULLTAG;
	tag_t	user_tag			= NULLTAG;


	char	*bcm_type_name		= NULL;
	char	*SupportUsername9	= NULL;
	char	*topBomLineRelease	= NULL;
	char	*username			= NULL;
	char	*userid				= NULL;
	char	*QryEtry[1]			= {"SYSCD"};
	char	**QryVal			= (char **) MEM_alloc(100 * sizeof(char *));


	printf("\n **** INSIDE prop_bl_method_absoluteTmatrix_check **** \n");fflush(stdout);
	tag_t bomline = msg->object_tag;

	QRY_find2("ControlObjQry", &CtrObjQryTag);
	if (CtrObjQryTag)
	{
		QryVal[0] = "blAbsoluteTMatrixCheck";
		QRY_execute(CtrObjQryTag, CtrEtry, QryEtry, QryVal, &QryC, &CtrObjSet);
	}
	printf("\n prop_bl_method_absoluteTmatrix_check: blAbsoluteTMatrixCheck : %d\n",QryC);fflush(stdout);

	if(QryC>0)
	{

		if(BOM_line_ask_window(bomline,&window)!=ITK_ok) PrintErrorStack();
		if(window)
		{
			if(BOM_ask_window_top_line(window,&top_bom_line)!=ITK_ok) PrintErrorStack();
			if(top_bom_line)
			{
				//if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&blrelease)) PrintErrorStack();
				//if(BOM_line_ask_attribute_string(top_bom_line, blrelease, &topBomLineRelease)) PrintErrorStack();
				//
				//if(BOM_line_look_up_attribute("fnd0bl_line_object_type", &attr_id)!=ITK_ok) PrintErrorStack();
				//if(BOM_line_ask_attribute_string(top_bom_line, attr_id, &bcm_type_name)!=ITK_ok) PrintErrorStack();

				if( AOM_ask_value_string(top_bom_line,"bl_rev_release_status_list",&topBomLineRelease));
				if( AOM_ask_value_string(top_bom_line,"fnd0bl_line_object_type",&bcm_type_name));

				printf("\n prop_bl_method_absoluteTmatrix_check: Top_Bomline release status : [%s] and Object Type : [%s]", topBomLineRelease,bcm_type_name);

				if(tc_strcmp(bcm_type_name,"Design Revision") == 0)
				{
					if( (tc_strstr(topBomLineRelease,"Release") != NULL) || (tc_strstr(topBomLineRelease,"Review") != NULL) ||
						(tc_strstr(topBomLineRelease,"T5_LcsErcRlzd") != NULL) || (tc_strstr(topBomLineRelease,"T5_LcsReview") != NULL) )
					{
						POM_get_user(&username,&user_tag);
						SA_ask_user_identifier2	(user_tag,&userid);
						printf ("\n prop_bl_method_absoluteTmatrix_check : Logged in user:%s %s\n",userid, username);fflush(stdout);
						SupportFlag=0;
						POM_get_user(&SupportUsername9,&SessionUser9_tag);

						if(SessionUser9_tag!=NULLTAG)
						{
							SupportFlag=0;
							SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
							printf("\n prop_bl_method_absoluteTmatrix_check : SupportFlag.: %d",SupportFlag);fflush(stdout);
						}

						if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0)
							&& ((tc_strcmp(userid,"aplloader")!=0) || (tc_strcmp(username,"aplloader") !=0)))
						{
							printf("\n prop_bl_method_absoluteTmatrix_check : Absolute Transformation Matrix update not permitted for parent part in released/review vault. \n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"\n Absolute Transformation Matrix update not permitted for parent part in released/review vault.");
							return ITK_err;
						}
						else
						{
							printf("\n prop_bl_method_absoluteTmatrix_check : User is either infodba/loader/support");fflush(stdout);
						}
					}
					else
					{
							printf("\n prop_bl_method_absoluteTmatrix_check : Part is in ERC working");fflush(stdout);
					}
				}
			}
		}
	}
	return error_code;
}

extern DLLAPI int prop_bl_method_defaultTmatrix_check(METHOD_message_t *msg, va_list args)
{
	int		error_code		= ITK_ok;
	int		CtrEtry			= 1;
	int		QryC			= 0;
	int		blrelease		= 0;
	int		attr_id			= 0;
	int     SupportFlag     = 0;

	tag_t	CtrObjQryTag		= NULLTAG;
	tag_t	*CtrObjSet			= NULLTAG;
	tag_t	window				= NULLTAG;
	tag_t	top_bom_line		= NULLTAG;
	tag_t	SessionUser9_tag	= NULLTAG;
	tag_t	user_tag			= NULLTAG;


	char	*bcm_type_name		= NULL;
	char	*SupportUsername9	= NULL;
	char	*topBomLineRelease	= NULL;
	char	*username			= NULL;
	char	*userid				= NULL;
	char	*QryEtry[1]			= {"SYSCD"};
	char	**QryVal			= (char **) MEM_alloc(100 * sizeof(char *));


	printf("\n **** INSIDE prop_bl_method_defaultTmatrix_check **** \n");fflush(stdout);
	tag_t bomline = msg->object_tag;

	QRY_find2("ControlObjQry", &CtrObjQryTag);
	if (CtrObjQryTag)
	{
		QryVal[0] = "blDefaultTMatrixCheck";
		QRY_execute(CtrObjQryTag, CtrEtry, QryEtry, QryVal, &QryC, &CtrObjSet);
	}
	printf("\n prop_bl_method_defaultTmatrix_check: blDefaultTMatrixCheck : %d\n",QryC);fflush(stdout);

	if(QryC>0)
	{
		if(BOM_line_ask_window(bomline,&window)!=ITK_ok) PrintErrorStack();
		if(window)
		{
			if(BOM_ask_window_top_line(window,&top_bom_line)!=ITK_ok) PrintErrorStack();
			if(top_bom_line)
			{
				//if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&blrelease)) PrintErrorStack();
				//if(BOM_line_ask_attribute_string(top_bom_line, blrelease, &topBomLineRelease)) PrintErrorStack();
				//
				//if(BOM_line_look_up_attribute("fnd0bl_line_object_type", &attr_id)!=ITK_ok) PrintErrorStack();
				//if(BOM_line_ask_attribute_string(top_bom_line, attr_id, &bcm_type_name)!=ITK_ok) PrintErrorStack();

				if( AOM_ask_value_string(top_bom_line,"bl_rev_release_status_list",&topBomLineRelease));
				if( AOM_ask_value_string(top_bom_line,"fnd0bl_line_object_type",&bcm_type_name));

				printf("\n prop_bl_method_defaultTmatrix_check: Top_Bomline release status : [%s] and Object Type : [%s]", topBomLineRelease,bcm_type_name);

				if(tc_strcmp(bcm_type_name,"Design Revision") == 0)
				{
					if( (tc_strstr(topBomLineRelease,"Release") != NULL) || (tc_strstr(topBomLineRelease,"Review") != NULL) ||
						(tc_strstr(topBomLineRelease,"T5_LcsErcRlzd") != NULL) || (tc_strstr(topBomLineRelease,"T5_LcsReview") != NULL))
					{
						POM_get_user(&username,&user_tag);
						SA_ask_user_identifier2	(user_tag,&userid);
						printf ("\n prop_bl_method_defaultTmatrix_check : Logged in user:%s %s\n",userid, username);fflush(stdout);
						SupportFlag=0;
						POM_get_user(&SupportUsername9,&SessionUser9_tag);

						if(SessionUser9_tag!=NULLTAG)
						{
							SupportFlag=0;
							SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
							printf("\n prop_bl_method_defaultTmatrix_check : SupportFlag.: %d",SupportFlag);fflush(stdout);
						}

						if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0)
							&& ((tc_strcmp(userid,"aplloader")!=0) || (tc_strcmp(username,"aplloader") !=0)))
						{
							printf("\n prop_bl_method_defaultTmatrix_check : Default Transformation Matrix update not permitted for parent part in released/review vault. \n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"\n Default Transformation Matrix update not permitted for parent part in released/review vault.");
							return ITK_err;
						}
						else
						{
							printf("\n prop_bl_method_defaultTmatrix_check : User is either infodba/loader/support");fflush(stdout);
						}
					}
					else
					{
							printf("\n prop_bl_method_defaultTmatrix_check : Part is in ERC working");fflush(stdout);
					}
				}
			}
		}
	}
	return error_code;
}

extern DLLAPI int prop_bl_method_Suppressed_check(METHOD_message_t *msg, va_list args)
{
	int		error_code		= ITK_ok;
	int		CtrEtry			= 1;
	int		QryC			= 0;
	int		blrelease		= 0;
	int		attr_id			= 0;
	int     SupportFlag     = 0;

	tag_t	CtrObjQryTag		= NULLTAG;
	tag_t	*CtrObjSet			= NULLTAG;
	tag_t	window				= NULLTAG;
	tag_t	top_bom_line		= NULLTAG;
	tag_t	SessionUser9_tag	= NULLTAG;
	tag_t	user_tag			= NULLTAG;


	char	*bcm_type_name		= NULL;
	char	*SupportUsername9	= NULL;
	char	*topBomLineRelease	= NULL;
	char	*username			= NULL;
	char	*userid				= NULL;
	char	*QryEtry[1]			= {"SYSCD"};
	char	**QryVal			= (char **) MEM_alloc(100 * sizeof(char *));


	printf("\n **** INSIDE prop_bl_method_Suppressed_check **** \n");fflush(stdout);
	tag_t bomline = msg->object_tag;

	QRY_find2("ControlObjQry", &CtrObjQryTag);
	if (CtrObjQryTag)
	{
		QryVal[0] = "blSuppressedCheck";
		QRY_execute(CtrObjQryTag, CtrEtry, QryEtry, QryVal, &QryC, &CtrObjSet);
	}
	printf("\n prop_bl_method_Suppressed_check: blSuppressedCheck : %d\n",QryC);fflush(stdout);

	if(QryC>0)
	{

		if(BOM_line_ask_window(bomline,&window)!=ITK_ok) PrintErrorStack();
		if(window)
		{
			if(BOM_ask_window_top_line(window,&top_bom_line)!=ITK_ok) PrintErrorStack();
			if(top_bom_line)
			{
				//if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&blrelease)) PrintErrorStack();
				//if(BOM_line_ask_attribute_string(top_bom_line, blrelease, &topBomLineRelease)) PrintErrorStack();
				//
				//if(BOM_line_look_up_attribute("fnd0bl_line_object_type", &attr_id)!=ITK_ok) PrintErrorStack();
				//if(BOM_line_ask_attribute_string(top_bom_line, attr_id, &bcm_type_name)!=ITK_ok) PrintErrorStack();

				if( AOM_ask_value_string(top_bom_line,"bl_rev_release_status_list",&topBomLineRelease));
				if( AOM_ask_value_string(top_bom_line,"fnd0bl_line_object_type",&bcm_type_name));

				printf("\n prop_bl_method_Suppressed_check: Top_Bomline release status : [%s] and Object Type : [%s]", topBomLineRelease,bcm_type_name);

				if(tc_strcmp(bcm_type_name,"Design Revision") == 0)
				{
					if( (tc_strstr(topBomLineRelease,"Release") != NULL) ||	(tc_strstr(topBomLineRelease,"T5_LcsErcRlzd") != NULL))
					{
						POM_get_user(&username,&user_tag);
						SA_ask_user_identifier2	(user_tag,&userid);
						printf ("\n prop_bl_method_Suppressed_check : Logged in user:%s %s\n",userid, username);fflush(stdout);
						SupportFlag=0;
						POM_get_user(&SupportUsername9,&SessionUser9_tag);

						if(SessionUser9_tag!=NULLTAG)
						{
							SupportFlag=0;
							SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
							printf("\n prop_bl_method_Suppressed_check : SupportFlag.: %d",SupportFlag);fflush(stdout);
						}

						if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0)
							&& ((tc_strcmp(userid,"aplloader")!=0) || (tc_strcmp(username,"aplloader") !=0)))
						{
							printf("\n prop_bl_method_Suppressed_check : Suppressed Indicator attribute update not permitted for parent part in released vault. \n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"\n Suppressed Indicator attribute update not permitted for parent part in released vault.");
							return ITK_err;
						}
						else
						{
							printf("\n prop_bl_method_Suppressed_check : User is either infodba/loader/support");fflush(stdout);
						}
					}
					else
					{
						printf("\n prop_bl_method_Suppressed_check : Part is in ERC working/Review");fflush(stdout);
					}
				}
			}
		}
	}
	return error_code;
}
//End Neha

// method added to restrict MBOM user to create part except it can create part whose part type is Stage Assemble, Module, Dummy, Dummy Component and Dummt Assembly By PRINCE

int partRestrictUsingMethodRegister( METHOD_message_t *msg, va_list  args )
{
	int error_code = ITK_ok;
	char *ModuleErr	= NULL;
	char *object_type = NULL;
	char *object_name = NULL;
	char *item_id = NULL;
	char *item_Rev = NULL;
	char *part_type = NULL;
	char *roleName = NULL;
	tag_t CurrentRoleTag = NULLTAG;
	//char roleName[SA_name_size_c+1];
	int l = 0;
	int n_entryCntrl1 = 3;
	char *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};
	char **qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	int  control_number_found1=0;
	char *info1 = NULL;
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t qryTagCntrl1 = NULLTAG;
	tag_t	TaskTag		= va_arg(args, tag_t);

    AOM_ask_value_string( TaskTag, "item_id", &item_id);
	AOM_ask_value_string( TaskTag, "item_revision_id", &item_Rev);
    AOM_ask_value_string( TaskTag, "object_type", &object_type);
	AOM_ask_value_string( TaskTag, "object_name", &object_name);
	AOM_ask_value_string( TaskTag, "t5_PartType", &part_type);

	l = tc_strlen(item_id);

    printf("\n partRestrictUsingMethodRegister--part_length : %d ",l); fflush(stdout);
	printf("\n partRestrictUsingMethodRegister--part_number : %s ",item_id); fflush(stdout);
	printf("\n partRestrictUsingMethodRegister--part_Revision : %s ",item_Rev); fflush(stdout);
	printf("\n partRestrictUsingMethodRegister--object_type : %s ",object_type); fflush(stdout);
	printf("\n partRestrictUsingMethodRegister--part_type11 : %s ",part_type); fflush(stdout);

	char * VehCat = NULL;
	if(tc_strcmp(object_type,"T5_PeDesignRevision")==0)
	{
		printf("\n partRestrictUsingMethodRegister--IT IS PE PART OBJECT HENCE EXIT!!! ***partRestrictUsingMethodRegister***");fflush(stdout);
		return error_code;
	}
	if (tc_strcmp(VehCat,"NULL") !=0) MEM_free(VehCat);
	{
		VehCat = (char *)MEM_alloc(50);
		tc_strcpy(VehCat,"");
	    tc_strcpy(VehCat,",");
		tc_strcat(VehCat,part_type);
		tc_strcat(VehCat,",");
		printf("\n partRestrictUsingMethodRegister--VehCat.:%s",VehCat);fflush(stdout);
	}

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
    ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName));
	printf("\n partRestrictUsingMethodRegister--roleName : %s\n",roleName); fflush(stdout);

	QRY_find2("Control Objects...", &qryTagCntrl1);
	if (qryTagCntrl1)
	{
		printf("\n partRestrictUsingMethodRegister--Control Object Query Found ");fflush(stdout);
		qry_valuesCntrl1[0]="Part_Type";
		qry_valuesCntrl1[1]="PartType";
		qry_valuesCntrl1[2]="0";
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		printf("\n partRestrictUsingMethodRegister--Number of control Obj Found is: %d",control_number_found1);fflush(stdout);

		if (control_number_found1>0)
		{
			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &info1));
			printf("\n partRestrictUsingMethodRegister--Information1 is: %s\n",info1);fflush(stdout);

			if((tc_strstr(roleName,"MBOM")!=NULL) && (tc_strcmp(object_type,"Design Revision")==0)   )
			{
				if((tc_strstr(info1,VehCat)!=NULL))
				{
					printf("\n partRestrictUsingMethodRegister--item_id : %s ",item_id); fflush(stdout);
					printf("\n partRestrictUsingMethodRegister--Allowed to Create 14 digit part from MBON Group of part type %s ",info1);
				}
				else
				{
					ModuleErr =	(char *)MEM_alloc(200);
					tc_strcat(ModuleErr,"MBOM user not allowed to create part except MBOM can create part with part type ");
					tc_strcat(ModuleErr,info1);
					tc_strcat(ModuleErr,".\n");
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_errStore1,ModuleErr);
					return ITK_errStore1;
				}
				if (tc_strcmp(VehCat,",SA,")==0 )	//added amm
				{
					//SA should be 14 digit.
					printf("\n partRestrictUsingMethodRegister--TPL last digit---SA ");fflush(stdout);
					if (l ==14)
					{
						printf("\n partRestrictUsingMethodRegister--SA is 14 digit: [%d] ", l);fflush(stdout);
					}
					else
					{
						printf("\n partRestrictUsingMethodRegister--SA is not 14 digit: [%d]\n", l);fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_err,"SA must be 14 digit.");
						return ITK_err;
					}
				}
				if (tc_strcmp(VehCat,",M,")==0 )	//added amm
				{
					//M should be 14 digit.
					printf("\n partRestrictUsingMethodRegister--TPL last digit---M ");fflush(stdout);
					if (l ==14)
					{
						printf("\n partRestrictUsingMethodRegister--Module is 14 digit: [%d] ", l);fflush(stdout);
					}
					else
					{
						printf("\n partRestrictUsingMethodRegister--Module is not 14 digit: [%d] ", l);fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Module must be 14 digit.");
						return ITK_err;
					}
				}
				if ((tc_strcmp(VehCat,",D,")==0) || (tc_strcmp(VehCat,",DC,")==0) ||(tc_strcmp(VehCat,",DA,")==0))										//added amm
				{
					//D/DC/DA should be 17 digit.
					printf("\n partRestrictUsingMethodRegister--TPL last digit---D/DC/DA--");fflush(stdout);
					if (l >=17)
					{
						printf("\n partRestrictUsingMethodRegister--Part type D/DC/DA--l>=17-- is 17 digit: [%d]", l);fflush(stdout);
					}
					else
					{
						printf("\n partRestrictUsingMethodRegister--Part type D/DC/DA is not 17 digit: [%d]", l);fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Part type D/DC/DA must be 17 digit or more than 17 digit.");
						return ITK_err;
					}
				}
			}
			else
			{
       			printf("\n partRestrictUsingMethodRegister--item_id : %s\n",item_id); fflush(stdout);
				printf("\n partRestrictUsingMethodRegister--Allowed to Create Part %s ",info1);
			}
		}
	}

	return 0;
}

//neha

//Added by kalpesh for validation of Parameter part and it's clause.
int para_clause_attach_method(METHOD_message_t *msg, va_list args)
{
	printf("\n ***INSIDE para_clause_attach_method*** \n");fflush(stdout);

	int		ifail							= 0;
	int		svrFlag							= 0;
	int		ii;
	int  	count,count1;

	tag_t	primary_object					= va_arg(args, tag_t);
	tag_t	primary_obj_type_tag			= NULLTAG;
	tag_t	secondary_object				= va_arg(args, tag_t);
	tag_t	secondary_obj_type_tag			= NULLTAG;
	tag_t	RelobjTag						= va_arg(args, tag_t);

	tag_t  	rel_type;
	tag_t	*sec_objects;
	tag_t	tsk_dml_rel_type;
	tag_t	DML_rev_tag						= NULLTAG;
	tag_t	*DMLRevision					= NULL;

	//char	type_name1[WSO_name_size_c+1];
	//char	type_name2[WSO_name_size_c+1];
	char	*obj_type_name2					= NULL;
	char	*type_name1					= NULL;
	char	*type_name2					= NULL;
	char	*objectvalue1					= NULL;
	char	*objectvalue2					= NULL;
	char	*TaskDsgGrp						= NULL;
	char	*username						= NULL;
	char	*PartType						= NULL;
	char	*TskNm							= NULL;
	char	*rls_type;

	logical	check_out = 0;

	ifail=TCTYPE_ask_object_type(primary_object,&primary_obj_type_tag);
	ifail=TCTYPE_ask_name2(primary_obj_type_tag,&type_name1);
	printf("\nERC DML Primary_object type_name is:%s",type_name1);fflush(stdout);

	ifail=TCTYPE_ask_object_type(secondary_object,&secondary_obj_type_tag);
	ifail=TCTYPE_ask_name2(secondary_obj_type_tag,&type_name2);
	printf("\nERC DML secondary_object type_name is:%s",type_name2);fflush(stdout);
	POM_get_user_id (&username);
	printf("\nLogged in user:%s\n",username); fflush(stdout);

	char *SupportUsername9 = NULL;
	tag_t SessionUser9_tag=NULLTAG;
	int     SupportFlag      =  0;

	SupportFlag=0;
	POM_get_user(&SupportUsername9,&SessionUser9_tag);
	if(SessionUser9_tag!=NULLTAG)
	{
		SupportFlag=0;
		SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
		printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
	}

	//if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0 && tc_strcmp(username,"ercpsup") !=0)
	if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
	{
		if(tc_strcmp(type_name2,"T5_EPara") == 0 || tc_strcmp(type_name2,"T5_EParaRevision") == 0)
		{
			printf("\n*****INSIDE T5_EPara(Clause)*****\n");fflush(stdout);

			if(tc_strcmp(type_name1,"T5_EE_PartRevision") == 0)
			{
				printf("\n*****INSIDE T5_EE_PartRevision*****\n");fflush(stdout);

				if(RES_is_checked_out(primary_object, &check_out)!=ITK_ok) PrintErrorStack();
				if(check_out != 0)
				{
					printf("\nPart is checked-out, so relation created...!!\n");fflush(stdout);
				}
				else
				{
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Please check-out the EE Part first.");
					printf("\nPlease check-out the EE Part first...!!\n");fflush(stdout);
					return ITK_err;
				}
			}
		}
	}
	//Start: Rupali Rahane CR-FY25-0149 Data type HEX and User Entered Value Within Range of (0to 9, A to F)
	char * DataType = NULL;
	char * UserEntervalue=NULL;
	int i=0,len;
	tag_t	Cntl_obj_Paracla =	NULLTAG;
	int n_entries11 =2;
	char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
	char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
	int resultCount11=0;
	tag_t *qry_cntrlobj11= NULLTAG;
	char* userinfo_TPL_ECU=NULL;

	if(QRY_find2("Control Objects...", &Cntl_obj_Paracla));
	qry_values11[0] = "ECU" ;
	qry_values11[1] = "HEXVALDTN" ;
	ITK_CALL(QRY_execute(Cntl_obj_Paracla, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
	if (resultCount11 > 0)
	{
		//printf("\n***** CONTROL OBJECT found for ECU_Parameter_Cre*****\n");fflush(stdout);
		AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo2",&userinfo_TPL_ECU);

		printf("\n***** CONTROL OBJECT found for ECU_Parameter_Cre***** %s \n", userinfo_TPL_ECU);fflush(stdout);
		if(strcmp(userinfo_TPL_ECU,"ON")==0)
		{

			AOM_ask_value_string(secondary_object,"t5_EPType",&DataType);
			printf("\n*****INSIDE T5_EE_PartRevision***** <%s>\n",DataType);fflush(stdout);
			if(strcmp(DataType,"HEX")==0)
			{
				AOM_ask_value_string(RelobjTag,"t5_BitValue",&UserEntervalue);
				printf("\n*****INSIDE T5_EE_PartRevision***** <%s>\n",UserEntervalue);fflush(stdout);
				if(strcmp(UserEntervalue,"USD")!=0)
				{
					len= strlen(UserEntervalue);
					for(i=0;i<len;i++)
					{
						printf(" i = %d \n",i);fflush(stdout);
						printf(" UserEntervalue[i] = %c\n",(int)UserEntervalue[i]);fflush(stdout);
						if(((int)UserEntervalue[i]>=65 && (int)UserEntervalue[i]<=70) || ((int)UserEntervalue[i]>=48 && (int)UserEntervalue[i]<=57) || (int)UserEntervalue[i]==45)
						{
							printf(" UserEnterValue is ok \n"); fflush(stdout);
						}
						else
						{
							printf("\n For Data Type Please Select Value Hex");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"User Entered Value must contain value from this range only.0to9 and AtoF");
							return 1;
						}
					}
				}
			}
		}
	}//END :Rupali Rahane CR-FY25-0149 Data Type HEX and User Entered Value Within Ranage of(0 to 9 A to f)

	return ifail;
}
//End of Parametere clause validation.

extern DLLAPI int  save_method_8(METHOD_message_t *msg, va_list args)
{

	int error_code = ITK_ok;
	int i = 0;
	tag_t objTypeTag = NULLTAG;
	tag_t user_tag=NULLTAG;

	logical	checkout1 = 0;

	char *object_name = NULL;
	char   *type_name = NULL;
	char* username = NULL;

	const char		*reason	= NULL;
	const char		*change_id	= NULL;
	const char		*dir_name = NULL;

	tag_t datasetTypeTag = va_arg(args, tag_t);
	const 	char* datasetName = va_arg(args, const 	char* );
	const 	char* datasetDescription = va_arg(args, const 	char* );
	const 	char* datasetID = va_arg(args, const 	char* );
	const 	char* datasetRevision = va_arg(args, const 	char* );
	tag_t 	newDataset = va_arg(args, tag_t );

	//tag_t	LatestRev = NULLTAG;  //Adi Alias         // commented by Adi
	//tag_t	ref_item = NULLTAG;   //Adi Alias        // commented by Adi
	//char* RevL = NULL;			  //Adi Alias   // commented by Adi
	//char *AliasTransFileName=NULL;//Adi Alias    // commented by Adi
	char* ObjNum1 = NULL;		  //Adi CMI
	char* username1 = NULL;		  //Adi CMI

	tag_t *tags_found = NULL;
	tag_t item_tag= NULLTAG, rev=NULLTAG;
	const char *item_name = NULL;
	char *SetType = NULL;
	char *USetType = NULL;
	const char *cTemp="item_id";
	int n_tags_found=0,len=0;
	char* itemName = NULL;
	char* startPart = NULL;
//	char* PartTypeCAT = NULL; //Adi 1.35

	printf("\nsave_method_8 ::  Inside Function\n");

	ObjNum1 =malloc(150);		  //Adi CMI

	if(newDataset)
	{
		if (TCTYPE_ask_object_type(newDataset,&objTypeTag)!=ITK_ok) PrintErrorStack();
		if(objTypeTag)
		{
			if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
//		}
//		else
//		{
//			printf("\nsave_method_8 :: objTypeTag is NULLTAG\n");
//		}

		//AOM_get_value_string(newDataset, "object_name", &object_name);
		if(AOM_ask_value_string(newDataset, "object_name", &object_name)!=ITK_ok) PrintErrorStack();
		printf("\n!!!!!!!!!!!!!!!!! save_method_8:::::::::type_name[%s] -- %s\n",type_name, object_name);fflush(stdout);

		 if(tc_strcmp(type_name,"CATProduct")==0 || tc_strcmp(type_name,"CATPart")==0 || tc_strcmp(type_name,"CATDrawing")==0)
		{
			printf("\n!!:::type_name not allowed[%s] -- %s\n",type_name, object_name);fflush(stdout);
			EMH_store_error_s3(EMH_severity_error,ITK_err,"Dataset of type", type_name," Not allowed to create");
			return ITK_err;
		}


		if(strcmp(type_name,"ProPrt")==0 || strcmp(type_name,"ProAsm")==0 || strcmp(type_name,"ProDrw")==0)
		{
			POM_get_user(&username,&user_tag);
			printf("\nSession username == %s\n", username);fflush(stdout);
			//if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0))
			if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"aplloader")!=0))
			{
				printf("\nsave_method_8 :: Inside ProPrt | ProAsm | ProDrw Condition.\n");fflush(stdout);
				if(RES_is_checked_out(newDataset,&checkout1) !=ITK_ok) PrintErrorStack();
				if (checkout1==0)
				{
					if (RES_checkout2(newDataset,reason,change_id,dir_name,RES_EXCLUSIVE_RESERVE)!=ITK_ok) PrintErrorStack();
					printf("\nsave_method_8 :: DataSet Checked Out \n");fflush(stdout);

				}
				else
				{
					printf("\nsave_method_8 ::  Skipping as DataSet already Checked Out\n");fflush(stdout);
				}
			}
		}


		/**************************** Adi CATIA 1.32 CMI dataset should not have rev or seq **********************************/

		else if(((tc_strcmp(type_name,"CMI2Product")==0)|| (tc_strcmp(type_name,"CMI2Part")==0)|| (tc_strcmp(type_name,"CMI2Drawing")==0)|| (tc_strcmp(type_name,"CMI2DesignTable")==0)))
		{
			POM_get_user(&username1,&user_tag);
			printf("\n Session username1 == %s\n", username1);
			//if((tc_strcmp(username1,"infodba")!=0) && (tc_strcmp(username1,"loader")!=0))
			if(tc_strcmp(username,"loader")!=0)
			{
				if(tc_strcmp(type_name,"CMI2Drawing")!=0)	//skiping for CMI2Drawing
				{
					item_name=strtok(object_name,"/");
					if(item_name)
					{
						printf("\nItem Name %s ",item_name);fflush(stdout);

						if(ITEM_find_items_by_key_attributes(1,&cTemp, &item_name, &n_tags_found, &tags_found) !=ITK_ok) PrintErrorStack();

						if (n_tags_found > 1)
						{
							MEM_free(tags_found);
							EMH_store_initial_error(EMH_severity_error,ITEM_multiple_items_returned);
							printf("More than one items matched with id %s\n", item_name);fflush(stdout);
							exit (0);
						}
						else if (n_tags_found == 1)
						{
							printf("only one items matched with id %s\n", item_name);fflush(stdout);
							item_tag = tags_found[0];
							if(ITEM_ask_latest_rev(item_tag,&rev)); PrintErrorStack();

							if(rev)
							{
								if( AOM_ask_value_string(rev,"item_id",&itemName)!=ITK_ok);
								if( AOM_ask_value_string(rev,"t5_StartPartProduct",&startPart)!=ITK_ok);
								printf("\nt5_Material %s StartPartProduct %s \n",itemName,startPart);fflush(stdout);
								//if( AOM_ask_value_string(rev,"t5_PartType",&PartTypeCAT));  //Adi 1.35 commented
								if(strcmp(startPart,"")!=0)
								{
									SetType=strtok(type_name,"CMI2");
									tc_strupr(SetType,&USetType);
									printf("\n*****DataSet Type [%s] \n",USetType);

									if(tc_strstr(startPart,USetType)!=NULL)
									{
										printf("\nStartPart and DataSet Type Match..[%s] \n",USetType);
									}
									else
									{
										printf("\nStartPart %s and DataSet Type %s Not Matching\n",startPart,USetType);
										EMH_store_error_s4(EMH_severity_error,ITK_err,"Start Part of Design Revision and Dataset Type Not Matching..", startPart," Not Matching with Dataset", type_name);
										return ITK_err;
									}
									//if((tc_strcmp(PartTypeCAT,"A")==0)&&(tc_strcmp(USetType,"PART")==0)) //Adi 1.35
									//{
									//	EMH_store_error_s1(EMH_severity_error,ITK_err,"Part type Assembly cannot have CMI2Part as an attachment");	//Adi 1.35
									//	return ITK_err;

									//}
									//else if((tc_strcmp(PartTypeCAT,"C")==0)&&(tc_strcmp(USetType,"PRODUCT")==0))//Adi 1.35
									//{
									//	EMH_store_error_s1(EMH_severity_error,ITK_err,"Part type Component cannot have CMI2Product as an attachment"); //Adi 1.35
									//	return ITK_err;
									//}
								}
							}

						}
					}
				}

				printf("\n save_method_8:: Inside CMI Condition \n");fflush(stdout);

				ObjNum1=strtok(object_name,"/");

				if(AOM_lock(newDataset));
				printf("\n after locking catia dataset \n");fflush(stdout);

				AOM_set_value_string(newDataset,"object_name", ObjNum1);

				if(AOM_save_without_extensions(newDataset));
				if(AOM_unlock(newDataset));
				printf("\n after unlocking catia dataset \n");fflush(stdout);
			}
		}
		  /******************************* Adi CATIA 1.32 ends *************************************/



		  /********************************* Adi ALIAS 1.32 *************************************/
       // commented by Adi
		/*else if (((strcmp(type_name,"T5_Alias")==0) || (strcmp(type_name,"WIRE")==0)||(strcmp(type_name,"T5_Wire")==0)))
		{
			printf("\n DATASET NAME IS [%s] , [%s]\n" ,object_name,type_name);fflush(stdout);

			if(ITEM_find_item(object_name,&ref_item));
			printf("\n ITEM_find_item AAA-------------- \n");fflush(stdout);

			if(ITEM_ask_latest_rev(ref_item,&LatestRev));
			printf("\n ITEM_ask_latest_rev AAA------------- \n");fflush(stdout);

			if( AOM_ask_value_string(LatestRev,"item_revision_id",&RevL)!=ITK_ok) PrintErrorStack();
			printf("\n RevL AAA--------------%s \n",RevL);fflush(stdout);

			//ITK_CALL(AOM_ask_value_string(primaryA,"object_name",&DatasetNameAlias));
			AliasTransFileName=malloc(2000);
			strcpy(AliasTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=");
			//strcpy(JTTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=282960203301  -r='A;5' -dn=282960203301/NR -dt=CMI2Part -pr=1 -pn=SIEMENS -tn=catiav5tojt -ty=COMMAND_LINE");

			strcat(AliasTransFileName,object_name);
			strcat(AliasTransFileName," ");
			strcat(AliasTransFileName,"-r='");

			strcat(AliasTransFileName,RevL);
			strcat(AliasTransFileName,"'");
			strcat(AliasTransFileName," ");

			strcat(AliasTransFileName,"-dt=T5_Alias  -dn='");
			strcat(AliasTransFileName,object_name);
			strcat(AliasTransFileName,"'");
			strcat(AliasTransFileName," ");

			strcat(AliasTransFileName,"-pr=1 -pn=SIEMENS   -tn=aliastocatpart -ty=COMMAND_LINE");
			printf("\n AliasTransFileName  T5_Alias before system is  =>%s\n", AliasTransFileName);fflush(stdout);

			system(AliasTransFileName);

			printf("\n After T5_Alias dispatcher_create_rqst shell =>%s\n", AliasTransFileName);fflush(stdout);*/

		//}   /****************************** Adi ALIAS 1.32  ***************************************/
	}
		else
		{
			printf("\nsave_method_8 :: objTypeTag is NULLTAG\n");
		}
	}
	printf("\nsave_method_8 ::  Exiting Function\n");
	return error_code;
}

/*********** Adi for CREO AND CATIA ********************/

extern DLLAPI int  save_method_9(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	int i = 0;
	tag_t objTypeTag = NULLTAG;
	tag_t user_tag=NULLTAG;

	logical	checkout1 = 0;

	char *object_name = NULL;
	char *object_type = NULL;
	char   *type_name = NULL;
	char   *type_name3 = NULL;
	char   *ObjNum = NULL;
	char   *ObjNum1 = NULL;
	char* username = NULL;

	const char		*reason	= "";
	const char		*change_id	= "";
	const char		*dir_name = "";

	char * catiasynch	 = NULL;
	tag_t	queryTag	 = NULLTAG;
	int		n_entries	 = 1;
	int		countDep	 = 0;
	char *qry_entries[1] = {"SYSCD"};
	char **qry_values    = (char **) MEM_alloc(10 * sizeof(char *));
	int		resultCount	 = 0;
	int		k			= 0;
	tag_t	*rev		 = NULLTAG;
	char	*itemId		 = NULL;
	char	*RevL		 = NULL;
	tag_t			objTypeTagDi				= NULLTAG;
	tag_t *CntrlObjectTag=NULLTAG;
	tag_t			primary					= NULLTAG;
	tag_t  *secondary_objects3	= NULLTAG;
	tag_t	LatestRev = NULLTAG;
	tag_t	LatestRev1 = NULLTAG;
	tag_t	ref_item = NULLTAG;

	//char cmi_name[TCTYPE_name_size_c+1];

	/*tag_t datasetTypeTag = va_arg(args, tag_t);
	const 	char* datasetName = va_arg(args, const 	char* );
	const 	char* datasetDescription = va_arg(args, const 	char* );
	const 	char* datasetID = va_arg(args, const 	char* );
	const 	char* datasetRevision = va_arg(args, const 	char* );*/
	tag_t 	newDataset = va_arg(args, tag_t );
	ObjNum =malloc(150);
	ObjNum1 =malloc(150);
	//ObjNum1 =malloc(100);


	//printf("\n save_method_9 ::  Inside Function \n");

		if (TCTYPE_ask_object_type(newDataset,&objTypeTag)!=ITK_ok) PrintErrorStack();
		if(objTypeTag)
		{
			if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
		}
		else
		{
			printf("\n save_method_9 :: objTypeTag is NULLTAG\n");
		}

		//AOM_get_value_string(newDataset,"object_name", &object_name);
		if (AOM_ask_value_string(newDataset,"object_name", &object_name)!=ITK_ok) PrintErrorStack();

		printf("\n!!!!!!!!!!!!!!!!! save_method_9:::::::::type_name[%s] -- %s\n",type_name, object_name);fflush(stdout);

		POM_get_user(&username,&user_tag);

		printf("\n Session username == %s\n", username);

		//if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0))
		if(tc_strcmp(username,"loader")!=0)
		{
			if(((tc_strcmp(type_name,"ProPrt")==0) || (tc_strcmp(type_name,"ProAsm")==0) || (tc_strcmp(type_name,"ProDrw")==0)))
			{

				printf("\n save_method_9 :: Inside ProPrt | ProAsm | ProDrw Condition.\n");

				if (tc_strstr(object_name,"/") || (tc_strstr(object_name,";")))
				{
					printf("\n ERROR: save_method_9 :: DataSet  \n");
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Please remove '/' , ';' ,Revision and Seq from Object Name ");
					return ITK_err;

				}
				else
				{
					printf("\n save_method_9 ::  Skipping as DataSet \n");fflush(stdout);
				}

			}
			/*else if(((tc_strcmp(type_name,"CMI2Product")==0)|| (tc_strcmp(type_name,"CMI2Part")==0)|| (tc_strcmp(type_name,"CMI2Drawing")==0)))
			{
				printf("\n ADI for CATIA datasets \n");

				if(QRY_find2("ControlObjects", &queryTag));

				if (queryTag)
				{
					printf("\n Found Query CMI \n");fflush(stdout);
				}
				else
				{
					printf("\n Not Found Query CMI \n");fflush(stdout);
				}

				qry_values[0] = "CatData" ;

				ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &CntrlObjectTag));

				printf(" \n resultCount :%d:", resultCount); fflush(stdout);

				if(resultCount>0)
				{
					printf("\n CatData control object found-------------- \n");fflush(stdout);

					//if( GRM_list_primary_objects_only(newDataset,NULLTAG,&countDep,&secondary_objects3)!=ITK_ok) PrintErrorStack();
					//printf("\n count found %d \n ",countDep);fflush(stdout);

					strcpy(ObjNum,object_name);
					ObjNum1=strtok(ObjNum,"/");

					if(ITEM_find_item(ObjNum1,&ref_item));
					//printf("\n ITEM_find_item AAA-------------- \n");fflush(stdout);

					if(ITEM_ask_latest_rev(ref_item,&LatestRev));
					printf("\n ITEM_ask_latest_rev AAA------------- \n");fflush(stdout);

					if( AOM_ask_value_string(LatestRev,"item_id",&RevL)!=ITK_ok) PrintErrorStack();
					printf("\n RevL AAA--------------%s \n",RevL);fflush(stdout);

					AOM_get_value_string(LatestRev,"object_type", &object_type);
					printf("\n object_type AAA--------------%s \n",object_type);fflush(stdout);

					if(tc_strcmp(object_type,"Design Revision")==0 )
					{
						if( AOM_ask_value_string(LatestRev,"t5_IsCatSynch",&catiasynch)!=ITK_ok) PrintErrorStack();

						printf("\n catiasynch value is -------------- %s \n",catiasynch);fflush(stdout);

						if(tc_strcmp(catiasynch ,"Y")==0)
						{
						    printf("\n part has been synched from catia--- so no issues \n");fflush(stdout);
						}
						else
						{
							printf("\n catiasynch VALUE IS N OR NULL \n");fflush(stdout);

							if (tc_strstr(object_name,"/") || (tc_strstr(object_name,";")))
							{
								printf("\n Part has not been synchronised from Catia \n");fflush(stdout);
								//EMH_store_error_s1(EMH_severity_warning,ITK_err,"Please synchronize the part from Catia");
								EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Please remove '/' , ';' ,Revision and Seq from Object Name");

								return ITK_errStore;
							}
							else
							{
								printf("\n / OR ; does not exist for Catia dataset \n");fflush(stdout);
							}
						}
					}
				}
				else
				{
					 printf("\n Pl create CatData control object  -------------- \n");fflush(stdout);
				}
			}*/
		}


	printf("\nsave_method_9 ::  Exiting Function\n");
	return error_code;
}

/*************Adi for CREO AND CATIA ********************/




//upp Start

extern DLLAPI int qauntity_handled_as_per_uom (METHOD_message_t *msg, va_list args)
{
	//tag_t    object;
	int ifail = ITK_ok;
	//char  object_type[WSO_name_size_c+1] ;
	//char* uomValue;
	char* sPartType;
	char	*sDesgNoD	= NULL;
	char	*DesgNo	= NULL;
	char	*object_type	= NULL;


	tag_t parent_bvr=va_arg(args, tag_t);
	tag_t child_item=va_arg(args, tag_t);
	tag_t child_bom_view=va_arg(args, tag_t);
	int n_occurrences=va_arg(args, int);
	tag_t** occ_thread_tags=va_arg(args, tag_t**);

	printf("Upendra...99=====n_occurrences=%d",n_occurrences);fflush(stdout);
	if(WSOM_ask_object_type2(child_item, &object_type)!=ITK_ok) PrintErrorStack();
	printf("Object Name upp=%s \n",object_type);fflush(stdout);

	if (strcmp(object_type,"T5_ClrPart")==0)
	{
		printf("\nT5_ClrPart--for UOM set Qty=1 ...");fflush(stdout);
		if( PS_set_occurrence_qty(parent_bvr,*occ_thread_tags[0],1)!=ITK_ok) PrintErrorStack();
	}
	else
	{
		if( AOM_UIF_ask_value(child_item,"t5_RevPartType",&sPartType)!=ITK_ok) PrintErrorStack();
		printf("\nPart Type :%s",sPartType);fflush(stdout);
		if( AOM_UIF_ask_value(child_item,"item_id",&DesgNo)!=ITK_ok) PrintErrorStack();
		printf("\nComponent part Num :%s",DesgNo);fflush(stdout);

		if ((strcmp(sPartType,"Dummy")==0) || (strcmp(sPartType,"Information Fitment Drawing")==0))
		{
			//IFD-Dummy part should be 12 digit and 9th and 10th digit should be 00/04
			sDesgNoD=subString(DesgNo, 8, 2);
			printf("\n IFD-Dummy part 9th and 10th digit [%s]\n", sDesgNoD);fflush(stdout);

			if (((strlen(DesgNo) ==12) && ((tc_strcmp(sDesgNoD,"04")==0) || (tc_strcmp(sDesgNoD,"00")==0))) || (tc_strlen(DesgNo) ==14))
			{
				printf("\n 12 digit Dummy part-9th and 10th digit is 00/04: [%s]\n", DesgNo);fflush(stdout);
				if( PS_set_occurrence_qty(parent_bvr,*occ_thread_tags[0],0)!=ITK_ok) PrintErrorStack();
			}
			else
			{
			   printf("\nDummy part is other than IFD");fflush(stdout);
			   if( PS_set_occurrence_qty(parent_bvr,*occ_thread_tags[0],1)!=ITK_ok) PrintErrorStack();
			}
		}
		else if((strcmp(sPartType,"CAD Module")==0))
		{
			if( PS_set_occurrence_qty(parent_bvr,*occ_thread_tags[0],0)!=ITK_ok) PrintErrorStack();
		}
		else
		{
			printf("\nfor UOM set Qty=1 ...");fflush(stdout);
			if( PS_set_occurrence_qty(parent_bvr,*occ_thread_tags[0],1)!=ITK_ok) PrintErrorStack();
		}

		/*
		if( AOM_UIF_ask_value(child_item,"t5_uom",&uomValue)!=ITK_ok) PrintErrorStack();
		printf("\n CUSTOM UOM name is = %s",uomValue);fflush(stdout);

		else if (strcmp(uomValue,"4-Nos")==0)
		{
			printf("UOM is 4-nos and Qty=1 ...");
			if( PS_set_occurrence_qty(parent_bvr,*occ_thread_tags[0],1)!=ITK_ok) PrintErrorStack();
		}
		else
		{
			printf("UOM is other than 4-nos and Qty=0 ...");
			if( PS_set_occurrence_qty(parent_bvr,*occ_thread_tags[0],0)!=ITK_ok) PrintErrorStack();
		}*/
	}
	return ifail ;
}

int ECU_Para_PreCond_Func(METHOD_message_t *msg, va_list args)
{
	printf("\n ***INSIDE ECU_Para_PreCond_Func*** \n");fflush(stdout);

	int		ifail							= 0;

	 tag_t objTag = va_arg(args, tag_t);
     int isNew = va_arg(args, int);
	 char* username=NULL;

	if (!isNew)
	{
		printf("\n!!!!!!!!!!!!!!!!! ECU_Para_PreCond_Func::::::::: not first time creation!!!!!!!! \n");fflush(stdout);
		return ifail;
	}

	POM_get_user_id (&username);
	printf("\nLogged in user:%s\n",username); fflush(stdout);



	int n_entries11 =2;
	tag_t	Cntl_obj_Qtag11	=	NULLTAG;
	char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
	char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
	int resultCount11=0;

	tag_t *qry_cntrlobj11= NULLTAG;
	char* userinfo_TPL_ECU=NULL;

	if(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));


	qry_values11[0] = "ECU_Parameter_Cre" ;
	qry_values11[1] = "ECU_Parameter_Cre" ;

	ITK_CALL(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
	if (resultCount11 > 0)
	{
		//printf("\n***** CONTROL OBJECT found for ECU_Parameter_Cre*****\n");fflush(stdout);
		AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo1",&userinfo_TPL_ECU);

		printf("\n***** CONTROL OBJECT found for ECU_Parameter_Cre***** %s \n", userinfo_TPL_ECU);fflush(stdout);

		if(!tc_strstr(userinfo_TPL_ECU,username))
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"ECU Parameter creation is disabled from user side.Please contact Support team for more information");
			return ITK_err;
		}

	}

	// Start: Rupali Rahane CR-FY25-0149- parameter clause creation To Select DataType Value  ASCII or HEX only in LOV.
	tag_t objTypeTag = NULLTAG;
	char * Datatype = NULL;
	char *type_name	= NULL;
	tag_t	Cntl_obj_Paracla =	NULLTAG;

	if(QRY_find2("Control Objects...", &Cntl_obj_Paracla));
	qry_values11[0] = "ECU" ;
	qry_values11[1] = "HEXVALDTN" ;
	ITK_CALL(QRY_execute(Cntl_obj_Paracla, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
	if (resultCount11 > 0)
	{
		//printf("\n***** CONTROL OBJECT found for ECU_Parameter_Cre*****\n");fflush(stdout);
		AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo1",&userinfo_TPL_ECU);

		printf("\n***** CONTROL OBJECT found for ECU_Parameter_Cre***** %s \n", userinfo_TPL_ECU);fflush(stdout);
		if(strcmp(userinfo_TPL_ECU,"ON")==0)
		{

			if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
			if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
			printf("\npart type is = %s", type_name);fflush(stdout);
			if(strcmp(type_name,"T5_EPara")==0)
			{
				ITK_CALL( AOM_ask_value_string(objTag,"t5_EPType",&Datatype));
				printf("\nData Type  is = %s",Datatype);fflush(stdout);
				if(strcmp(Datatype,"ASCII")==0 || strcmp(Datatype,"HEX")==0)
				{
					printf("\n Value is ok.");fflush(stdout);
				}
				else
				{
					printf("\n For Data Type Please Select Value ACII or Hex");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,"For Data Type Please Select Value ASCII or Hex only");
					return 1;
				}
			}
		}
	}// END: Rupali Rahane CR-FY25-0149- parameter clause creation To Select DataType Value ASCII or HEX only in LOV.

	return ifail;

}
int CCV_ECU_PreCond_Func(METHOD_message_t *msg, va_list args)
{
	printf("\n ***INSIDE para_clause_attach_method*** \n");fflush(stdout);

	int		ifail							= 0;

	tag_t	primary_object					= va_arg(args, tag_t);
	tag_t	primary_obj_type_tag			= NULLTAG;
	tag_t	secondary_object				= va_arg(args, tag_t);
	tag_t	secondary_obj_type_tag			= NULLTAG;




	tag_t	LatestRev					= NULLTAG;

	//char	type_name1[WSO_name_size_c+1];
	//char	type_name2[WSO_name_size_c+1];




	char	*username						= NULL;
	char	*PartType						= NULL;
	char	*DesGroup						= NULL;
	char	*ProjCode						= NULL;
	char	*type_name1						= NULL;
	char	*type_name2						= NULL;

	logical	check_out = 0;

	ifail=TCTYPE_ask_object_type(primary_object,&primary_obj_type_tag);
	ifail=TCTYPE_ask_name2(primary_obj_type_tag,&type_name1);
	printf("\nERC DML Primary_object type_name is:%s",type_name1);fflush(stdout);

	ifail=TCTYPE_ask_object_type(secondary_object,&secondary_obj_type_tag);
	ifail=TCTYPE_ask_name2(secondary_obj_type_tag,&type_name2);
	printf("\nERC DML secondary_object type_name is:%s",type_name2);fflush(stdout);
	POM_get_user_id (&username);
	printf("\nLogged in user:%s\n",username); fflush(stdout);

	char *SupportUsername9 = NULL;
	tag_t SessionUser9_tag=NULLTAG;
	int     SupportFlag      =  0;

	SupportFlag=0;
	POM_get_user(&SupportUsername9,&SessionUser9_tag);
	if(SessionUser9_tag!=NULLTAG)
	{
		SupportFlag=0;
		SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
		printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
	}

	//if(tc_strcmp(username,"infodba") !=0 && tc_strcmp(username,"loader") !=0 && tc_strcmp(username,"ercpsup") !=0)
	if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
	{
		int Errorflag=0;
		if(tc_strcmp(type_name2,"Design") == 0 )
		{
			printf("\n*****INSIDE Design*****\n");fflush(stdout);

			//t5_DesignGrp
			//t5_PartType

			if(ITEM_ask_latest_rev(secondary_object,&LatestRev)!=ITK_ok) PrintErrorStack();
			if (LatestRev!=NULLTAG)
			{
				if( AOM_ask_value_string(LatestRev,"t5_DesignGrp",&DesGroup)!=ITK_ok) PrintErrorStack();
				if( AOM_ask_value_string(LatestRev,"t5_PartType",&PartType)!=ITK_ok) PrintErrorStack();
				if( AOM_ask_value_string(LatestRev,"t5_ProjectCode",&ProjCode)!=ITK_ok) PrintErrorStack();

				printf("\n*****INSIDE Design***** <%s> <%s> <%s> \n",DesGroup,PartType,ProjCode);fflush(stdout);

				if (tc_strcmp(DesGroup,"16")==0)
				{

					int n_entries11 =2;
					tag_t	Cntl_obj_Qtag11	=	NULLTAG;
					char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
					char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
					int resultCount11=0;
					int TplBypassflag=0;
					tag_t *qry_cntrlobj11= NULLTAG;
					char* userinfo_TPL_ECU=NULL;

					if(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));


					qry_values11[0] = ProjCode ;
					qry_values11[1] = "CCV_ECU_REL_ATTACH" ;

					ITK_CALL(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
					if (resultCount11 > 0)
					{
						printf("\n***** CONTROL OBJECT found for PROJECT TPL*****\n");fflush(stdout);
						AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo1",&userinfo_TPL_ECU);
						TplBypassflag=1;
					}

					printf("\n*****INSIDE Design***** <%s>  \n",userinfo_TPL_ECU);fflush(stdout);


					if (TplBypassflag==1)
					{
						if (tc_strstr(userinfo_TPL_ECU,PartType) != NULL)
						{
							printf("\n*****TPL*****\n");fflush(stdout);
						}
						else
						{
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Only 16R TPL/EM Master can be attached in CCVC has ECU module relationship");
								return ITK_err;
						}

					}
					else
					{
						if (tc_strcmp(PartType,"EM")==0)
						{
							printf("\n*****EM PartType*****\n");fflush(stdout);

						}
						else
						{
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Only ECU Module Master can be attached in CCVC has ECU module relationship");
								return ITK_err;
						}
					}

				}
				else
				{
					printf("\n*****NOT 16 Design Group*****\n");fflush(stdout);
					Errorflag=1;
				}
			}
			else
			{
				printf("\n*****NOT Latest Design*****\n");fflush(stdout);
				Errorflag=1;
			}
		}
		else
		{
			printf("\n*****NOT Design*****\n");fflush(stdout);

			Errorflag=1;
		}

		if (Errorflag==1)
		{
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Only ECU Module or 16R TPL can be attached ( Master only, not Revision) ");
				return ITK_err;
		}
	}
	return ifail;
}
//upp End

//Added by Kirtikumar Thakur for SVR validation
int SVR_PreCond_Validation_Func(METHOD_message_t *msg, va_list args)
{

	printf("\n ***INSIDE SVR_PreCond_Validation_Func*** \n");fflush(stdout);

	int		ifail							= 0;

	tag_t	primary_object					= va_arg(args, tag_t);
	tag_t	primary_obj_type_tag			= NULLTAG;
	tag_t	secondary_object				= va_arg(args, tag_t);
	tag_t	secondary_obj_type_tag			= NULLTAG;

	//char	primary_obj_type_name[WSO_name_size_c+1];
	//char	secondary_obj_type_name[WSO_name_size_c+1];

	char	*username						= NULL;
	char	*primary_obj_type_name						= NULL;
	char	*secondary_obj_type_name						= NULL;

	tag_t Smc0HasVariantConfigContext_Rel_tag =NULLTAG;
	int platformCount						  =0;
	tag_t* paltFormTag						  =NULLTAG;
	tag_t platFormNodeTag					  =NULLTAG;
	char* platFormItemID                      =NULL;
	char* secObjString						  =NULL;
	char* platFormObject_string				  =NULL;

	//To Get control object:
	int		n_entries		=3;
	tag_t	Cntl_obj_Qtag	=	NULLTAG;
	char	*qry_entries[3] = {"SYSCD","SUBSYSCD","Information-1"};
	char	**qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	int		resultCount=0;
	tag_t	*qry_cntrlobj= NULLTAG;

	//char* userinfo_1=NULL;
	char* userinfo_2=NULL;
	char* userinfo_3=NULL;

	char* projectCode =NULL;
	char* subStrProjectCode =NULL;
	char* errorMsg =NULL;





	ITK_CALL(TCTYPE_ask_object_type(primary_object,&primary_obj_type_tag));
	ITK_CALL(TCTYPE_ask_name2(primary_obj_type_tag,&primary_obj_type_name));
	printf("\nPrimary_object type_name is:%s",primary_obj_type_name);fflush(stdout);

	if((tc_strcmp(primary_obj_type_name,"Cfg0ProductItem") == 0))
	{
		ITK_CALL(TCTYPE_ask_object_type(secondary_object,&secondary_obj_type_tag));
		ITK_CALL(TCTYPE_ask_name2(secondary_obj_type_tag,&secondary_obj_type_name));
		printf("\n Secondary_object type_name is:%s",secondary_obj_type_name);fflush(stdout);

		if((tc_strcmp(secondary_obj_type_name,"VariantRule") == 0))
		{
			POM_get_user_id (&username);
			printf("\nLogged in user:%s\n",username); fflush(stdout);

			char *SupportUsername9 = NULL;
			tag_t SessionUser9_tag=NULLTAG;
			int     SupportFlag      =  0;

			SupportFlag=0;
			POM_get_user(&SupportUsername9,&SessionUser9_tag);
			if(SessionUser9_tag!=NULLTAG)
			{
				SupportFlag=0;
				SupportFlag = CheckSupportLogin_DR(SessionUser9_tag);
				printf("\n SupportFlag.: %d",SupportFlag);fflush(stdout);
			}
			//Bypass for dba users
			if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (SupportFlag==0))
			{
				ITK_CALL(GRM_find_relation_type("Smc0HasVariantConfigContext",&Smc0HasVariantConfigContext_Rel_tag));
				printf("\n after finding Smc0HasVariantConfigContext \n");fflush(stdout);

				//Finding platform attached to Config Context i.e. primaray object
				ITK_CALL(GRM_list_primary_objects_only(primary_object, Smc0HasVariantConfigContext_Rel_tag, &platformCount, &paltFormTag));
				printf("\n  platformCount.:%d\n",platformCount);fflush(stdout);

				if(platformCount >0)
				{

					platFormNodeTag = paltFormTag[0];

					ITK_CALL(AOM_ask_value_string(platFormNodeTag,"item_id",&platFormItemID));
					ITK_CALL(AOM_ask_value_string(platFormNodeTag,"object_string",&platFormObject_string));

					ITK_CALL(AOM_ask_value_string(secondary_object,"object_string",&secObjString));

					printf("\n platFormItemID is: %s \n",platFormItemID);fflush(stdout);

					//Querying the Control Objects.
					if(QRY_find2("Control Objects...", &Cntl_obj_Qtag));

					qry_values[0] = "SPLIT_PLATFORM";
					qry_values[1] = "SPLIT_PLATFORM_SVR_CHECK";
					qry_values[2] = platFormItemID;

					ITK_CALL(QRY_execute(Cntl_obj_Qtag, n_entries, qry_entries, qry_values, &resultCount, &qry_cntrlobj));
					if (resultCount > 0)
					{
						printf("\n***** CONTROL OBJECT found*****\n");fflush(stdout);
						//Reading project code from Cntrl Object;

						ITK_CALL(AOM_ask_value_string(qry_cntrlobj[0],"t5_Userinfo2",&userinfo_2));
						printf("userinfo_2 is : %s \n",userinfo_2);

						//In sub string 0 is starting position and 4 is no of char
						subStrProjectCode=subString(secObjString, 0, 4);
						printf("subStrProjectCode is : %s \n",subStrProjectCode);

						if((tc_strstr(userinfo_2,subStrProjectCode)==NULL))
						{
							//Error msg:
							errorMsg=(char *)MEM_alloc(200);
							printf("After mem alloc\n");
							tc_strcpy (errorMsg, "SVR :");
							strcat(errorMsg,secObjString);
							strcat(errorMsg," of Project code : ");
							strcat(errorMsg,subStrProjectCode);
							strcat(errorMsg,", is not applicable for selected configurator context.");
							//Not allowed give error here.
							EMH_store_error_s1(EMH_severity_error,ITK_err,errorMsg);
							return ITK_err;
						}

					}
					else
					{
						printf("\n\t Control Object Not Found");
					}

				}
				else
				{
					printf("\n\t NO Platform Found");
				}

			}

		}
		else
		{
			printf("\n\t Validation is not requrired for this type of object, I am in secondary obj if.");
		}

	}
	else
	{
		printf("\n\t Validation is not requrired for this type of object");

	}

	return ifail;

}
//16-03-2023
int bom_WindowSave_Validation(METHOD_message_t *msg, va_list args)
{

	printf("\n ***************** I am in ::bom_WindowSave_Validation:: ********************");fflush(stdout);

		int			child_attr			= 0;
		int			child_attr1			= 0;
		int			Item_attr			= 0;
		int			blobjType			= 0;
		int			modadd				= 0;
		int			bl_Child_objType			= 0;
		int			Rev_attr			= 0;
		int			bl_abs_xform		= 0;
		int			bl_relative_xform	= 0;
		int			chlidLine_Count		= 0;
		int			i					= 0;
		int			error_code			= ITK_ok;
		char		*child_qty			= NULL;
		char		*child_PartType			= NULL;
		char		*moduleAdd				= NULL;
		char		*child_qty1			= NULL;
		char		*Item_id			= NULL;
		char		*Item_rev_id		= NULL;

		char		*child_Item_id			= NULL;
		char		*child_Item_rev_id		= NULL;
		char		*topLineObjectType		= NULL;

		char		*child_part_type	= NULL;
		char		*child_obj_type		= NULL;
		char		*parent_obj_type	= NULL;
		char		*child_item_id2		= NULL;
		char		*child_item_id		= NULL;
		char		*ApplnOwner			= NULL;
		char		*child_abs_xform	= NULL;
		char		*child_relv_xform	= NULL;
		char		*child_rev_id		= NULL;

		//

		tag_t top_bom_line				= NULLTAG;
		tag_t *childLines				= NULLTAG;
		tag_t		revision_tag		= NULLTAG;

		tag_t window_tag = va_arg( args, tag_t );

		//Control Obj for On and Off Validation.
		tag_t	qry_t1_bomSave			= NULLTAG;
		char **qry_val3_bomSave			= (char **) MEM_alloc(100 * sizeof(char *));
		char    *qry_entr1_bomSave[1]   = {"SYSCD"};
		int n_entr1_bomSave				= 1;
		int rsltCunt1_bomSave			= 0;
		tag_t *CntrlObjTag1_bomSave		= NULLTAG;

		char* usrInfo1_bomSave			= NULL;
		char* usrInfo2_bomSave			= NULL;


		if(QRY_find2("ControlObjects", &qry_t1_bomSave));
		if (qry_t1_bomSave)
		{
			printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);
		}
		else
		{
			printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
		}
		qry_val3_bomSave[0] = "BOMWindowSaveEvent";
		if(QRY_execute(qry_t1_bomSave, n_entr1_bomSave, qry_entr1_bomSave, qry_val3_bomSave, &rsltCunt1_bomSave, &CntrlObjTag1_bomSave));

		if(rsltCunt1_bomSave>0)
		{
			ITKCALL(BOM_ask_window_top_line(window_tag,&top_bom_line));
			//ITKCALL(BOM_line_look_up_attribute ("bl_item_item_id",&Item_attr));
			//ITKCALL(BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Rev_attr));
			//ITKCALL(BOM_line_look_up_attribute ("bl_quantity",&child_attr));
			//ITKCALL(BOM_line_look_up_attribute ("bl_Design Revision_t5_ModuleAddress",&modadd));
			//ITKCALL(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&blobjType));
			//ITKCALL(BOM_line_look_up_attribute ("bl_Design Revision_t5_PartType",&bl_Child_objType));

			//ITKCALL(BOM_line_ask_attribute_string(top_bom_line, Item_attr, &Item_id));
			//ITKCALL(BOM_line_ask_attribute_string(top_bom_line, Rev_attr, &Item_rev_id));
			//ITKCALL(BOM_line_ask_attribute_string(top_bom_line, blobjType, &topLineObjectType));

			if( AOM_ask_value_string(top_bom_line,"bl_item_item_id",&Item_id)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(top_bom_line,"bl_rev_item_revision_id",&Item_rev_id)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(top_bom_line,"fnd0bl_line_object_type",&topLineObjectType)!=ITK_ok) PrintErrorStack();


			printf("\n\t topLineObjectType => [%s]\n",topLineObjectType);fflush(stdout);


			ITKCALL(AOM_ask_value_string(CntrlObjTag1_bomSave[0],"t5_Userinfo1",&usrInfo1_bomSave));
			printf("\n\t ****usrInfo1_bomSave => %s*****\n",usrInfo1_bomSave);fflush(stdout);

			//if (tc_strcmp(topLineObjectType,"T5_ArchModuleRevision")==0)
			if((tc_strstr(usrInfo1_bomSave,topLineObjectType) != NULL))
			{
					 printf("\n\t *****Parent_bomline ID => %s*****\n",Item_id);fflush(stdout);
					 printf("\n\t *****Parent_bomline Rev ID => %s*****\n",Item_rev_id);fflush(stdout);

					 ITKCALL(AOM_ask_value_string(CntrlObjTag1_bomSave[0],"t5_Userinfo2",&usrInfo2_bomSave));
					 printf("\n\t ****usrInfo2_bomSave => %s*****\n",usrInfo2_bomSave);fflush(stdout);

					// PV CV Change: CR-FY24-0095 : Allow 0 Qty for CV IFD, CP and Specific Mod Add
					tag_t	qry_isCV	= NULLTAG;
					char **qry_isCV_val = (char **) MEM_alloc(35 * sizeof(char *));
					int n_entr_isCV = 1;
					char    *qry_entr_isCV[1]  = {"SYSCD"};
					int rsltCunt_isCV=0;
					tag_t *CntrlObjTag_isCV=NULLTAG;
					logical isTCUA_isCV =false;
					int iqo = 0;

					char* finalModuleAdd     = NULL;
					char *info1				 = NULL;
					char *info2				 = NULL;
					char *info3				 = NULL;
					char *info4				 = NULL;
					char *info5				 = NULL;
					char *info6				 = NULL;
					char *info7				 = NULL;
					char *info8				 = NULL;
					char *info9				 = NULL;
					char *info10			 = NULL;

					// check if TCUA Env is PV or CV
					if(QRY_find2("ControlObjects", &qry_isCV));
					if (qry_isCV)
					{
						printf("\n ControlObjects:.Found Query qry_isCV \n");fflush(stdout);
					}
					else
					{
						printf("\n ControlObjects:.Not Found Query qry_isCV \n");fflush(stdout);
					}

					qry_isCV_val[0] = "BOMWindowSaveZeroQryBOM_CV";
					if(QRY_execute(qry_isCV, n_entr_isCV, qry_entr_isCV, qry_isCV_val, &rsltCunt_isCV, &CntrlObjTag_isCV));
					printf(" \n BOMWindowSaveZeroQryBOM_CV::::>>> :%d:", rsltCunt_isCV); fflush(stdout);
					if(rsltCunt_isCV	> 0)
					{
						isTCUA_isCV =true;

						finalModuleAdd = (char *) MEM_alloc(5000 * sizeof(char *));
						for(iqo= 0;iqo < rsltCunt_isCV ;iqo++)
						{
							if (AOM_ask_value_string(CntrlObjTag_isCV[iqo],"t5_Userinfo1",&info1)!=ITK_ok);
							printf("\n info1 Mod Add List [%s]",info1); fflush(stdout);

							if (AOM_ask_value_string(CntrlObjTag_isCV[iqo],"t5_Userinfo2",&info2)!=ITK_ok);
							printf("\n info2 Mod Add List [%s]",info2); fflush(stdout);

							if (AOM_ask_value_string(CntrlObjTag_isCV[iqo],"t5_Userinfo3",&info3)!=ITK_ok);
							printf("\n info3 Mod Add List [%s]",info3); fflush(stdout);

							if (AOM_ask_value_string(CntrlObjTag_isCV[iqo],"t5_Userinfo4",&info4)!=ITK_ok);
							printf("\n info4 Mod Add List [%s]",info4); fflush(stdout);

							if (AOM_ask_value_string(CntrlObjTag_isCV[iqo],"t5_Userinfo5",&info5)!=ITK_ok);
							printf("\n info5 Mod Add List [%s]",info5); fflush(stdout);

							if (AOM_ask_value_string(CntrlObjTag_isCV[iqo],"t5_Userinfo6",&info6)!=ITK_ok);
							printf("\n info6 Mod Add List [%s]",info6); fflush(stdout);

							if (AOM_ask_value_string(CntrlObjTag_isCV[iqo],"t5_Userinfo7",&info7)!=ITK_ok);
							printf("\n info7 Mod Add List [%s]",info7); fflush(stdout);

							if (AOM_ask_value_string(CntrlObjTag_isCV[iqo],"t5_Userinfo8",&info8)!=ITK_ok);
							printf("\n info8 Mod Add List [%s]",info8); fflush(stdout);

							if (AOM_ask_value_string(CntrlObjTag_isCV[iqo],"t5_Userinfo9",&info9)!=ITK_ok);
							printf("\n info9 Mod Add List [%s]",info9); fflush(stdout);

							if (AOM_ask_value_string(CntrlObjTag_isCV[iqo],"t5_userinfo10 ",&info10)!=ITK_ok);
							printf("\n info10 Mod Add List [%s]",info10); fflush(stdout);

							if(info1 == NULL)
							{
								tc_strcat(info1,"");
							}
							if(info2 == NULL)
							{
								tc_strcat(info2,"");
							}
							if(info3 == NULL)
							{
								tc_strcat(info3,"");
							}
							if(info4 == NULL)
							{
								tc_strcat(info4,"");
							}
							if(info5 == NULL)
							{
								tc_strcat(info5,"");
							}
							if(info6 == NULL)
							{
								tc_strcat(info6,"");
							}
							if(info7 == NULL)
							{
								tc_strcat(info7,"");
							}
							if(info8 == NULL)
							{
								tc_strcat(info8,"");
							}
							if(info9 == NULL)
							{
								tc_strcat(info9,"");
							}
							if(info10 == NULL)
							{
								tc_strcat(info10,"");
							}

							if(finalModuleAdd == NULL)
							{
								tc_strcpy(finalModuleAdd,"");
								tc_strcat(finalModuleAdd,info1);
								tc_strcat(finalModuleAdd,info2);
								tc_strcat(finalModuleAdd,info3);
								tc_strcat(finalModuleAdd,info4);
								tc_strcat(finalModuleAdd,info5);
								tc_strcat(finalModuleAdd,info6);
								tc_strcat(finalModuleAdd,info7);
								tc_strcat(finalModuleAdd,info8);
								tc_strcat(finalModuleAdd,info9);
								tc_strcat(finalModuleAdd,info10);
							}
							else
							{
								tc_strcat(finalModuleAdd,info1);
								tc_strcat(finalModuleAdd,info2);
								tc_strcat(finalModuleAdd,info3);
								tc_strcat(finalModuleAdd,info4);
								tc_strcat(finalModuleAdd,info5);
								tc_strcat(finalModuleAdd,info6);
								tc_strcat(finalModuleAdd,info7);
								tc_strcat(finalModuleAdd,info8);
								tc_strcat(finalModuleAdd,info9);
								tc_strcat(finalModuleAdd,info10);
							}
						}

						printf("\n\t finalModuleAdd string value After concat: %s\n \n",finalModuleAdd);
					}

					//Getting all child of Top Line
					ITKCALL(BOM_line_ask_child_lines(top_bom_line,&chlidLine_Count,&childLines));
					for(i =0; i < chlidLine_Count;i++)
					{
						//ITKCALL(BOM_line_ask_attribute_string(childLines[i], Item_attr, &child_Item_id));
						//ITKCALL(BOM_line_ask_attribute_string(childLines[i], Rev_attr, &child_Item_rev_id));
						//ITKCALL(BOM_line_ask_attribute_string(childLines[i], child_attr, &child_qty));
						//ITKCALL(BOM_line_ask_attribute_string(childLines[i], bl_Child_objType, &child_PartType));
						//ITKCALL(BOM_line_ask_attribute_string(childLines[i], modadd, &moduleAdd));

						if( AOM_ask_value_string(childLines[i],"bl_item_item_id",&child_Item_id)!=ITK_ok) PrintErrorStack();
						if( AOM_ask_value_string(childLines[i],"bl_rev_item_revision_id",&child_Item_rev_id)!=ITK_ok) PrintErrorStack();
						if( AOM_ask_value_string(childLines[i],"bl_quantity",&child_qty)!=ITK_ok) PrintErrorStack();
						if( AOM_ask_value_string(childLines[i],"bl_Design Revision_t5_PartType",&child_PartType)!=ITK_ok) PrintErrorStack();
						if( AOM_ask_value_string(childLines[i],"bl_Design Revision_t5_ModuleAddress",&moduleAdd)!=ITK_ok) PrintErrorStack();

						printf("\n\t child_PartType => [%s]\n",child_PartType);fflush(stdout);

						if(isTCUA_isCV)
						{
							if((tc_strstr(usrInfo2_bomSave,child_PartType) != NULL))
							{
								printf("\n\t **child_Item_id=> [%s]** ",child_Item_id);fflush(stdout);
								printf("\n\t **child_Item_rev_id => [%s]** ",child_Item_rev_id);fflush(stdout);
								printf("\n\t **child_qty => [%s]** ",child_qty);fflush(stdout);
								printf("\n\t **child_moduleAdd => [%s]** ",moduleAdd);fflush(stdout);

								if(tc_strcmp(child_qty, "0") == 0 || tc_strlen(child_qty) == 0)
								{
									if(tc_strcmp(child_PartType,"CAD Module") == 0 || tc_strcmp(child_PartType, "IFD Module") == 0 || (tc_strstr(finalModuleAdd,moduleAdd) != NULL))
									{
										printf("\nQuantity Zero is Allowd, no need to set to 1. ");fflush(stdout);
									}
									else
									{
											ITKCALL(AOM_UIF_set_value(childLines[i], "bl_quantity", "1"));
											printf("\nQuantity set to 1 ");fflush(stdout);
									}
								}
							}
						}
						else
						{
							//if (tc_strcmp(child_PartType,"Module")==0 || tc_strcmp(child_PartType,"M") ==0)
							if((tc_strstr(usrInfo2_bomSave,child_PartType) != NULL))
							{
								printf("\n\t **child_Item_id=> [%s]** ",child_Item_id);fflush(stdout);
								printf("\n\t **child_Item_rev_id => [%s]** ",child_Item_rev_id);fflush(stdout);
								printf("\n\t **child_qty => [%s]** ",child_qty);fflush(stdout);
								printf("\n\t **child_moduleAdd => [%s]** ",moduleAdd);fflush(stdout);

								if(tc_strcmp(child_qty, "0") == 0 || tc_strlen(child_qty) == 0)
								{
									ITKCALL(AOM_UIF_set_value(childLines[i], "bl_quantity", "1") != ITK_ok) PrintErrorStack();
									printf("\nQuantity set to 1 ");fflush(stdout);
								}
							}
						}
					}
			 }
		}
		else
		{
			printf("\n bom_WindowSave_Validation is OFF !!  ");fflush(stdout);

		}

	return error_code;
}
int carryMastSlvRelationOnReviseForEEPartRev(METHOD_message_t *msg, va_list args)
{
	printf("\n ***************** I am in ::carryMastSlvRelationOnReviseForEEPartRev:: ********************");fflush(stdout);

	//int			error_code					= ITK_ok;

	//Control Obj for On and Off Validation.
	tag_t	qry_t1MastSlv			= NULLTAG;
	char **qry_val3MastSlv			= (char **) MEM_alloc(100 * sizeof(char *));
	char    *qry_entr1MastSlv[1]   = {"SYSCD"};
	int n_entr1MastSlv				= 1;
	int rsltCunt1MastSlv			= 0;
	tag_t *CntrlObjTag1MastSlv		= NULLTAG;

	//

	int			error_code					= ITK_ok;
	tag_t        source_rev					= va_arg( args, tag_t );
	const char*  rev_id						= va_arg( args, const char* );
	tag_t*       new_rev					= va_arg( args,  tag_t* );
	tag_t        item_rev_master_form		= va_arg( args, tag_t );

	char* source_revObject_string  = NULL;
	char* new_revObject_string	 = NULL;
	tag_t MastSlvRelTag	 = NULLTAG;



	int			masterCout					= 0;
	tag_t*		masterTag					= NULLTAG;
	int			i1							= 0;
	int			j1							= 0;

	int			slaveCount					= 0;
	tag_t*		SlaveTag					= NULLTAG;

	char*			slaveObjStr					= NULL;
	tag_t		    relationTag					= NULLTAG;
	tag_t			newRelation					= NULLTAG;
	char*			MasterItemRevId				= NULLTAG;
	char*			MasterObject_string				= NULLTAG;
	tag_t			masterItemTag				= NULLTAG;
	tag_t			MasterLatestItemRevTag		= NULLTAG;
	char*			MasterLatestItemRevID		= NULLTAG;



	if(QRY_find2("ControlObjects", &qry_t1MastSlv));
	if (qry_t1MastSlv)
	{
		printf("\n ControlObjects:.Found Query ControlObjects  ");fflush(stdout);
	}
	else
	{
		printf("\n ControlObjects:.Not Found Query ControlObjects  ");fflush(stdout);
	}
	qry_val3MastSlv[0] = "MasterSlavContRelForRevise";
	if(QRY_execute(qry_t1MastSlv, n_entr1MastSlv, qry_entr1MastSlv, qry_val3MastSlv, &rsltCunt1MastSlv, &CntrlObjTag1MastSlv));

	printf("\n\t ****rsltCunt1MastSlv => %d***** ",rsltCunt1MastSlv);fflush(stdout);

	if(rsltCunt1MastSlv>0)
	{
		ITKCALL(AOM_ask_value_string(source_rev,"object_string",&source_revObject_string));
		ITKCALL(AOM_ask_value_string(*new_rev,"object_string",&new_revObject_string));

	    printf("\n\t ****source_revObject_string => %s***** ",source_revObject_string);fflush(stdout);
	    printf("\n\t ****new_revObject_string => %s***** ",new_revObject_string);fflush(stdout);

		ITK_CALL(GRM_find_relation_type("T5_ContHasSlave",&MastSlvRelTag));
		printf("\n after finding MastSlvRelTag  ");fflush(stdout);

		ITK_CALL(GRM_list_primary_objects_only(source_rev, MastSlvRelTag, &masterCout, &masterTag));
		printf("\n  masterCout.:%d ",masterCout);fflush(stdout);

		if(masterCout > 0)
	    {
			printf("\n\t ****Slave has Master container***** ");fflush(stdout);
			for(i1= 0 ;i1 < masterCout; i1++)
		    {

				ITKCALL(AOM_ask_value_string(masterTag[i1],"object_string",&MasterObject_string));
				printf("\n MasterObject_string is :%s ",MasterObject_string);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(masterTag[i1],"item_revision_id",&MasterItemRevId));
				printf("\n MasterItemRevId is :%s ",MasterItemRevId);fflush(stdout);

				ITK_CALL(ITEM_ask_item_of_rev(masterTag[i1],&masterItemTag));
				ITK_CALL(ITEM_ask_latest_rev(masterItemTag,&MasterLatestItemRevTag));

				ITK_CALL(AOM_ask_value_string(MasterLatestItemRevTag,"item_revision_id",&MasterLatestItemRevID));
				printf("\n MasterLatestItemRevID :%s ",MasterLatestItemRevID);fflush(stdout);
				//CHEK FOR ONLY LATEST  REV OF MASTER CONTAINER
				//if(strcmp(MasterItemRevId,MasterLatestItemRevID)==0)
				//{
				ITK_CALL(GRM_list_secondary_objects_only(masterTag[i1], MastSlvRelTag, &slaveCount, &SlaveTag));
				printf("\n  slaveCount.:%d ",slaveCount);fflush(stdout);

				 if(slaveCount > 0)
				 {
					  for(j1 =0; j1 < slaveCount; j1++)
					  {
						 ITKCALL(AOM_ask_value_string(SlaveTag[j1],"object_string",&slaveObjStr));
						 printf("\n\t ****slaveObjStr => %s***** ",slaveObjStr);fflush(stdout);

//						 if((tc_strcmp(source_revObject_string,slaveObjStr) == 0))
//						 {
//							 ITK_CALL(GRM_find_relation(masterTag[i1], SlaveTag[j1], MastSlvRelTag, &relationTag));
//							 if(relationTag)
//							 {
//								ITK_CALL(GRM_delete_relation(relationTag));
//								printf("\n\t ****OLD Slave Revision has been removed.***** ");fflush(stdout);
//
//							 }
//
//						 }

					  }
				 }
				 ITK_CALL(AOM_refresh(masterTag[i1],1));
				 ITK_CALL(GRM_create_relation(masterTag[i1], *new_rev, MastSlvRelTag, NULLTAG,&newRelation));
				 ITK_CALL(GRM_save_relation(newRelation));
				 ITK_CALL(AOM_save_without_extensions(masterTag[i1]));
				 ITK_CALL(AOM_refresh(masterTag[i1],0));
				 printf("\n\t ****Relation is created with Master and Latest slave revision.***** ");fflush(stdout);
				//}

			}

		}


		////////////parameter

		tag_t conparaRelTag	 = NULLTAG;
		tag_t* masterparaTag	 = NULLTAG;
		tag_t* paraTag	 = NULLTAG;
		int masterparaCout=0;
		int cp=0;
		int paraCount=0;
		int jp=0;
		char*			MasterparaObject_string				= NULLTAG;
		char*			MasterparaItemRevId				= NULLTAG;
		char*			MasterparaLatestItemRevID				= NULLTAG;
		char*			paraObjStr				= NULLTAG;
		tag_t			masterparaItemTag				= NULLTAG;
		tag_t			MasterparaLatestItemRevTag				= NULLTAG;
		tag_t			newparaRelation				= NULLTAG;
		ITK_CALL(GRM_find_relation_type("T5_ContHasPara",&conparaRelTag));
		printf("\n after finding conparaRelTag  ");fflush(stdout);

		ITK_CALL(GRM_list_primary_objects_only(source_rev, conparaRelTag, &masterparaCout, &masterparaTag));
		printf("\n  masterparaCout.:%d ",masterparaCout);fflush(stdout);

		if(masterparaCout > 0)
	    {
			printf("\n\t ****parameter has Master container***** ");fflush(stdout);
			for(cp= 0 ;cp < masterparaCout; cp++)
		    {

				ITKCALL(AOM_ask_value_string(masterparaTag[cp],"object_string",&MasterparaObject_string));
				printf("\n MasterparaObject_string is :%s ",MasterparaObject_string);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(masterparaTag[cp],"item_revision_id",&MasterparaItemRevId));
				printf("\n MasterparaItemRevId is :%s ",MasterparaItemRevId);fflush(stdout);

				ITK_CALL(ITEM_ask_item_of_rev(masterparaTag[cp],&masterparaItemTag));
				ITK_CALL(ITEM_ask_latest_rev(masterparaItemTag,&MasterparaLatestItemRevTag));

				ITK_CALL(AOM_ask_value_string(MasterparaLatestItemRevTag,"item_revision_id",&MasterparaLatestItemRevID));
				printf("\n MasterparaLatestItemRevID :%s ",MasterparaLatestItemRevID);fflush(stdout);

				ITK_CALL(GRM_list_secondary_objects_only(masterparaTag[cp], conparaRelTag, &paraCount, &paraTag));
				printf("\n  paraCount:%d ",paraCount);fflush(stdout);

				 if(paraCount > 0)
				 {
					  for(jp =0; jp < paraCount; jp++)
					  {
						 ITKCALL(AOM_ask_value_string(paraTag[jp],"object_string",&paraObjStr));
						 printf("\n\t ****paraObjStr => %s***** ",paraObjStr);fflush(stdout);


					  }
				 }
				 ITK_CALL(AOM_refresh(masterparaTag[cp],1));
				 ITK_CALL(GRM_create_relation(masterparaTag[cp], *new_rev, conparaRelTag, NULLTAG,&newparaRelation));
				 ITK_CALL(GRM_save_relation(newparaRelation));
				 ITK_CALL(AOM_save_without_extensions(masterparaTag[cp]));
				 ITK_CALL(AOM_refresh(masterparaTag[cp],0));
				 printf("\n\t ****Relation is created with Master and Latest para revision.***** ");fflush(stdout);
				//}

			}

		}


		//sparkit

		tag_t consparkitRelTag	 = NULLTAG;
		tag_t* mastersparkitTag	 = NULLTAG;
		tag_t* sparkitTag	 = NULLTAG;
		int mastersparekitCout=0;
		int cs=0;
		int sparkitcount=0;
		int js=0;
		char*			MastersparkitObject_string				= NULLTAG;
		char*			MasterspawrkitItemRevId				= NULLTAG;
		char*			MastersparkitLatestItemRevID				= NULLTAG;
		char*			sparkitObjStr				= NULLTAG;
		tag_t			mastersparkitItemTag				= NULLTAG;
		tag_t			MastersparkitLatestItemRevTag				= NULLTAG;
		tag_t			sparkitcontRelation				= NULLTAG;
		ITK_CALL(GRM_find_relation_type("T5_HasSpareKit",&consparkitRelTag));
		printf("\n after finding consparkitRelTag  ");fflush(stdout);

		ITK_CALL(GRM_list_primary_objects_only(source_rev, consparkitRelTag, &mastersparekitCout, &mastersparkitTag));
		printf("\n  mastersparekitCout.:%d ",mastersparekitCout);fflush(stdout);

		if(mastersparekitCout > 0)
	    {
			printf("\n\t ****parameter has Master container***** ");fflush(stdout);
			for(cs= 0 ;cs < mastersparekitCout; cs++)
		    {

				ITKCALL(AOM_ask_value_string(mastersparkitTag[cs],"object_string",&MastersparkitObject_string));
				printf("\n MastersparkitObject_string is :%s ",MastersparkitObject_string);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(mastersparkitTag[cs],"item_revision_id",&MasterspawrkitItemRevId));
				printf("\n MasterspawrkitItemRevId is :%s ",MasterspawrkitItemRevId);fflush(stdout);

				ITK_CALL(ITEM_ask_item_of_rev(mastersparkitTag[cs],&mastersparkitItemTag));
				ITK_CALL(ITEM_ask_latest_rev(mastersparkitItemTag,&MastersparkitLatestItemRevTag));

				ITK_CALL(AOM_ask_value_string(MastersparkitLatestItemRevTag,"item_revision_id",&MastersparkitLatestItemRevID));
				printf("\n MastersparkitLatestItemRevID :%s ",MastersparkitLatestItemRevID);fflush(stdout);

				ITK_CALL(GRM_list_secondary_objects_only(mastersparkitTag[cs], consparkitRelTag, &sparkitcount, &sparkitTag));
				printf("\n  sparkitcount:%d ",sparkitcount);fflush(stdout);

				 if(sparkitcount > 0)
				 {
					  for(js =0; js < sparkitcount; js++)
					  {
						 ITKCALL(AOM_ask_value_string(sparkitTag[js],"object_string",&sparkitObjStr));
						 printf("\n\t ****sparkitObjStr => %s***** ",sparkitObjStr);fflush(stdout);


					  }
				 }
				 ITK_CALL(AOM_refresh(mastersparkitTag[cs],1));
				 ITK_CALL(GRM_create_relation(mastersparkitTag[cs], *new_rev, consparkitRelTag, NULLTAG,&sparkitcontRelation));
				 ITK_CALL(GRM_save_relation(sparkitcontRelation));
				 ITK_CALL(AOM_save_without_extensions(mastersparkitTag[cs]));
				 ITK_CALL(AOM_refresh(mastersparkitTag[cs],0));
				 printf("\n\t ****Relation is created with Master and Latest sparekit revision.***** ");fflush(stdout);
				//}

			}

		}



	}
	else
	{
		printf("\n Auto Relation Carryforword is OFF !!  ");fflush(stdout);

	}

	return error_code;

}
int carryMastSlvRelationOnCheckOutForEEPartRev(METHOD_message_t *msg, va_list args)
{
	 printf("\n ***************** I am in ::carryMastSlvRelationOnCheckOutForEEPartRev:: ********************");fflush(stdout);
	 int			error_code					= ITK_ok;

	 tag_t objTag = va_arg(args, tag_t);

	 char* ObjStr = NULL;
	 tag_t objTypeTag,item_tag = NULLTAG;
	 //char  type_name[TCTYPE_name_size_c+1];
	 char* itemRevIDObj =	NULL;
	 char* type_name =	NULL;
	 tag_t			ItemTag				= NULLTAG;
	 char*			ObjStrItem			= NULLTAG;
	 int			count1				= 0;
	 tag_t *		rev_list1			= NULLTAG;
	 int			i1					=	0;
	 int			j1					=	0;
	 int			k1					=   0;

	 char*			Prevrev_tagItemRevID	= NULL;
	 char*			Prevrev_tagObjStr		= NULL;
	 tag_t			MastSlvRelTag			=  NULLTAG;
	 int			masterCout					= 0;
	 tag_t*			masterTag					= NULLTAG;

	//char*			slaveObjStr					= NULL;
	//tag_t		    relationTag					= NULLTAG;
	//tag_t			newRelation					= NULLTAG;

	char*			MasterItemRevId				= NULLTAG;
	char*			MasterObject_string				= NULLTAG;
	tag_t			masterItemTag				= NULLTAG;
	tag_t			MasterLatestItemRevTag		= NULLTAG;
	char*			MasterLatestItemRevID		= NULLTAG;

	int			    slaveCount					= 0;
	tag_t*		    SlaveTag					= NULLTAG;
	char*			slaveObjStr					= NULL;
	tag_t		    relationTag					= NULLTAG;
	tag_t			newRelation					= NULLTAG;

	 //Control Obj for On and Off Validation.
	tag_t	qry_t1MastSlv			= NULLTAG;
	char **qry_val3MastSlv			= (char **) MEM_alloc(100 * sizeof(char *));
	char    *qry_entr1MastSlv[1]   = {"SYSCD"};
	int n_entr1MastSlv				= 1;
	int rsltCunt1MastSlv			= 0;
	tag_t *CntrlObjTag1MastSlv		= NULLTAG;


	ITKCALL(AOM_ask_value_string(objTag,"object_string",&ObjStr));
	printf("\n\t ****ObjStr => %s***** ",ObjStr);fflush(stdout);

	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();

	if(tc_strcmp(type_name,"T5_EE_PartRevision")==0)
	{
			if(QRY_find2("ControlObjects", &qry_t1MastSlv));
			if (qry_t1MastSlv)
			{
				printf("\n ControlObjects:.Found Query ControlObjects  ");fflush(stdout);
			}
			else
			{
				printf("\n ControlObjects:.Not Found Query ControlObjects  ");fflush(stdout);
			}
			qry_val3MastSlv[0] = "MasterSlavContRelForCheckOut";
			if(QRY_execute(qry_t1MastSlv, n_entr1MastSlv, qry_entr1MastSlv, qry_val3MastSlv, &rsltCunt1MastSlv, &CntrlObjTag1MastSlv));
			printf("\n\t ****rsltCunt1MastSlv => %d***** ",rsltCunt1MastSlv);fflush(stdout);


			if(rsltCunt1MastSlv>0)
			{

					ITK_CALL(GRM_find_relation_type("T5_ContHasSlave",&MastSlvRelTag));
					printf("\n after finding MastSlvRelTag  ");fflush(stdout);

					printf("\n\t ****T5_EE_PartRevision Found..***** ");fflush(stdout);

					ITKCALL(AOM_ask_value_string(objTag,"item_revision_id",&itemRevIDObj));
					printf("\n\t ****itemRevIDObj => %s***** ",itemRevIDObj);fflush(stdout);

					ITK_CALL(ITEM_ask_item_of_rev(objTag,&ItemTag));

					ITKCALL(AOM_ask_value_string(ItemTag,"object_string",&ObjStrItem));
					printf("\n\t ****ObjStrItem => %s***** ",ObjStrItem);fflush(stdout);
					ITKCALL(ITEM_list_all_revs(ItemTag,&count1,&rev_list1));

					printf("\n\t **** Total Rev count is :: => %d***** ",count1);fflush(stdout);

				   for(i1=count1-1;i1>=0;i1--)
				   {
						  printf("\n  -- :: i1  ::-- %d ",i1);fflush(stdout);

						  if( AOM_ask_value_string(rev_list1[i1],"object_string",&Prevrev_tagObjStr)!=ITK_ok) PrintErrorStack();
						  if( AOM_ask_value_string(rev_list1[i1],"item_revision_id",&Prevrev_tagItemRevID)!=ITK_ok) PrintErrorStack();

						  printf("\n Prevrev_tagObjStr  ::-- %s ",Prevrev_tagObjStr);fflush(stdout);
						  printf("\n Previous revision Item Rev Id %s ",Prevrev_tagItemRevID);fflush(stdout);

						  ITK_CALL(GRM_list_primary_objects_only(rev_list1[i1], MastSlvRelTag, &masterCout, &masterTag));
						  printf("\n  masterCout.:%d ",masterCout);fflush(stdout);

						  if(masterCout > 0)
						  {
								printf("\n\t ****Slave has Master container***** ");fflush(stdout);
								for(j1= 0 ;j1 < masterCout; j1++)
								{

									ITKCALL(AOM_ask_value_string(masterTag[j1],"object_string",&MasterObject_string));
									printf("\n MasterObject_string is :%s ",MasterObject_string);fflush(stdout);

									ITK_CALL(AOM_ask_value_string(masterTag[j1],"item_revision_id",&MasterItemRevId));
									printf("\n MasterItemRevId is :%s ",MasterItemRevId);fflush(stdout);

									ITK_CALL(ITEM_ask_item_of_rev(masterTag[j1],&masterItemTag));
									ITK_CALL(ITEM_ask_latest_rev(masterItemTag,&MasterLatestItemRevTag));

									ITK_CALL(AOM_ask_value_string(MasterLatestItemRevTag,"item_revision_id",&MasterLatestItemRevID));
									printf("\n MasterLatestItemRevID :%s ",MasterLatestItemRevID);fflush(stdout);
									//CHEK FOR ONLY LATEST  REV OF MASTER CONTAINER
									//if(strcmp(MasterItemRevId,MasterLatestItemRevID)==0)
									//{

									ITK_CALL(GRM_list_secondary_objects_only(masterTag[j1], MastSlvRelTag, &slaveCount, &SlaveTag));
									printf("\n  slaveCount.:%d ",slaveCount);fflush(stdout);

									if(slaveCount > 0)
									{
										 for(k1 =0; k1 < slaveCount; k1++)
										 {

											   ITKCALL(AOM_ask_value_string(SlaveTag[k1],"object_string",&slaveObjStr));
											   printf("\n\t ****slaveObjStr => %s***** ",slaveObjStr);fflush(stdout);
//												if((tc_strcmp(Prevrev_tagObjStr,slaveObjStr) == 0))
//												{
//													 ITK_CALL(GRM_find_relation(masterTag[j1], SlaveTag[k1], MastSlvRelTag, &relationTag));
//													 if(relationTag)
//													 {
//														ITK_CALL(GRM_delete_relation(relationTag));
//														printf("\n\t ****OLD Slave Revision has been removed.***** ");fflush(stdout);
//
//													 }
//
//												}

										  }

									 } // if for slave count.

									 ITK_CALL(AOM_refresh(masterTag[j1],1));
									 ITK_CALL(GRM_create_relation(masterTag[j1], objTag, MastSlvRelTag, NULLTAG,&newRelation));
									 ITK_CALL(GRM_save_relation(newRelation));
									 ITK_CALL(AOM_save_without_extensions(masterTag[j1]));
									 ITK_CALL(AOM_refresh(masterTag[j1],0));
									 printf("\n\t ****Relation is created with Master and Latest slave revision.***** ");fflush(stdout);


									//}// if for latest master rev check.


								} // for for master count

						  }// if for Master count

						  //Just need to consider previous revision only.
						 int tempCount = 0;
						 tempCount = count1 -2;
						 printf("\n\t **** tempCount :: => %d***** ",tempCount);fflush(stdout);
						 if(tempCount == i1)
						 {
							break;
						 }
						 // break;

				   } // for for Rev List


			}
			else
			{
				printf("\n Auto Relation Carryforword is OFF  :: RES CheckOutMsg !!  ");fflush(stdout);

			}

	}
	else
	{
		printf("\n Not a Valid Obj Type for  :: carryMastSlvRelationOnCheckOutForEEPartRev !!  ");fflush(stdout);
	}
	return error_code;

}

//*********added by akshay Toke*************
int RemoveIRChecklistOnCheckOutOnModule(METHOD_message_t *msg, va_list args)
{
	 printf("\n ***************** I am in ::RemoveIRChecklistOnCheckOutOnModule:: ********************");fflush(stdout);
	 int			error_code					= ITK_ok;

	 tag_t objTag = va_arg(args, tag_t);

	 char* ObjStr = NULL;
	 tag_t objTypeTag,item_tag = NULLTAG;
	// char  type_name[TCTYPE_name_size_c+1];
	 char* itemRevIDObj =	NULL;
	 char* type_name =	NULL;
	 tag_t			ItemTag				= NULLTAG;
	 char*			ObjStrItem			= NULLTAG;
	 int			count1				= 0;
	 tag_t *		rev_list1			= NULLTAG;
	 int			i1					=	0;
	 int			j1					=	0;
	 int			k1					=   0;

	 char*			Prevrev_tagItemRevID	    = NULL;
	 char*			Prevrev_tagObjStr		    = NULL;
	 tag_t			RefRelTag			        =  NULLTAG;
	 int			masterCout					= 0;
	 tag_t*			masterTag					= NULLTAG;

	//char*			IRCObjStr					= NULL;
	//tag_t		    relationTag					= NULLTAG;
	//tag_t			newRelation					= NULLTAG;

	char*			MasterItemRevId				= NULLTAG;
	char*			MasterObject_string			= NULLTAG;
	tag_t			masterItemTag				= NULLTAG;
	tag_t			MasterLatestItemRevTag		= NULLTAG;
	char*			MasterLatestItemRevID		= NULLTAG;

	int			    IRCCount					= 0;
	tag_t*		    IRCTag					    = NULLTAG;
	char*			IRCObjStr					= NULL;
	tag_t		    relationTag					= NULLTAG;
	tag_t			newRelation					= NULLTAG;

	 //Control Obj for On and Off Validation.
	tag_t	qryTag			= NULLTAG;
	char **qry_val			= (char **) MEM_alloc(100 * sizeof(char *));
	char    *qry_entri[1]   = {"SYSCD"};
	int n_entries				= 1;
	int qrycount			= 0;
	tag_t *CntrlObjTag		= NULLTAG;

	char* IRCobjtyp =NULL;
	IRCobjtyp=(char *) MEM_alloc(100);


	ITKCALL(AOM_ask_value_string(objTag,"object_string",&ObjStr));
	printf("\n\t ****ObjStr => %s***** ",ObjStr);fflush(stdout);

	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();

	printf("\n\t ****object_type => %s***** ",type_name);fflush(stdout);

	if(tc_strcmp(type_name,"Design Revision")==0)
	{
			if(QRY_find2("ControlObjects", &qryTag));
			if (qryTag)
			{
				printf("\n ControlObjects:.Found Query ControlObjects  ");fflush(stdout);
			}
			else
			{
				printf("\n ControlObjects:.Not Found Query ControlObjects  ");fflush(stdout);
			}
			qry_val[0] = "IRChecklistRelForCheckOut";
			if(QRY_execute(qryTag, n_entries, qry_entri, qry_val, &qrycount, &CntrlObjTag));
			printf("\n\t ****qrycount => %d***** ",qrycount);fflush(stdout);


			if(qrycount>0)
			{

					ITK_CALL(GRM_find_relation_type("IMAN_reference",&RefRelTag));
					printf("\n after finding RefRelTag  ");fflush(stdout);

				/*	printf("\n\t ****T5_EE_PartRevision Found..***** ");fflush(stdout);

					ITKCALL(AOM_ask_value_string(objTag,"item_revision_id",&itemRevIDObj));
					printf("\n\t ****itemRevIDObj => %s***** ",itemRevIDObj);fflush(stdout);

					ITK_CALL(ITEM_ask_item_of_rev(objTag,&ItemTag));

					ITKCALL(AOM_ask_value_string(ItemTag,"object_string",&ObjStrItem));
					printf("\n\t ****ObjStrItem => %s***** ",ObjStrItem);fflush(stdout);
					ITKCALL(ITEM_list_all_revs(ItemTag,&count1,&rev_list1));

					printf("\n\t **** Total Rev count is :: => %d***** ",count1);fflush(stdout);*/



					ITK_CALL(GRM_list_secondary_objects_only(objTag, RefRelTag, &IRCCount, &IRCTag));
					for(k1 =0; k1 < IRCCount; k1++)
					 {

						   ITKCALL(AOM_ask_value_string(IRCTag[k1],"object_type",&IRCobjtyp));

						   printf("\n ****************checking IRC object TYPE***************: %s", IRCobjtyp);fflush(stdout);

						   ITKCALL(AOM_ask_value_string(IRCTag[k1],"object_string",&IRCObjStr));
						   printf("\n\t ****IRCObjStr => %s***** ",IRCObjStr);fflush(stdout);

							if((tc_strcmp(IRCobjtyp,"T5_IR_CHECKLISTRevision") == 0))
							{
								 ITK_CALL(GRM_find_relation(objTag, IRCTag[k1], RefRelTag, &relationTag));
								 if(relationTag)
								 {
									ITK_CALL(GRM_delete_relation(relationTag));
									printf("\n\t ****OLD IRC Relation has been removed.***** ");fflush(stdout);

								 }

							}

					  }

			}
			else
			{
				printf("\n Auto Interface rule checklist Relation Carryforword is OFF  :: RES CheckOutMsg !!  ");fflush(stdout);

			}

	}
	else
	{
		printf("\n Not a Valid Obj Type for  :: RemoveIRChecklistOnCheckOutOnModule !!  ");fflush(stdout);
	}
	return error_code;

}

//*********added by akshay Toke*************

int RemoveIRChecklistOnReviseOnmoduleRev(METHOD_message_t *msg, va_list args)
{
	printf("\n ***************** I am in ::RemoveIRChecklistOnReviseOnmoduleRev:: ********************");fflush(stdout);

	//int			error_code					= ITK_ok;

	//Control Obj for On and Off Validation.
	tag_t	qryTag			= NULLTAG;
	char **qry_val			= (char **) MEM_alloc(100 * sizeof(char *));
	char    *qry_entri[1]   = {"SYSCD"};
	int n_entries			= 1;
	int qrycount			= 0;
	tag_t *CntrlObjTag		= NULLTAG;

	int			error_code					= ITK_ok;
	tag_t        source_rev					= va_arg( args, tag_t );
	const char*  rev_id						= va_arg( args, const char* );
	tag_t*       new_rev					= va_arg( args,  tag_t* );
	tag_t        item_rev_master_form		= va_arg( args, tag_t );

	char* source_revObject_string  = NULL;
	char* new_revObject_string	   = NULL;
	tag_t RefRelTag	               = NULLTAG;

	int			masterCout		    = 0;
	tag_t*		masterTag			= NULLTAG;
	int			i1					= 0;
	int			j1					= 0;

	int			IRCCount			= 0;
	tag_t*		IRCTag				= NULLTAG;

	char*			IRCObjStr					= NULL;
	tag_t		    relationTag					= NULLTAG;
	tag_t			newRelation					= NULLTAG;
	char*			MasterItemRevId				= NULLTAG;
	char*			MasterObject_string				= NULLTAG;
	tag_t			masterItemTag				= NULLTAG;
	tag_t			MasterLatestItemRevTag		= NULLTAG;
	char*			MasterLatestItemRevID		= NULLTAG;

    tag_t objTypeTag = NULLTAG;
	//char  type_name[TCTYPE_name_size_c+1];
	char* IRCobjtyp =NULL;
	char* type_name =NULL;
	IRCobjtyp=(char *) MEM_alloc(100);


	if(TCTYPE_ask_object_type(source_rev,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();

	printf("\n\t ****object_type => %s***** ",type_name);fflush(stdout);
	if(tc_strcmp(type_name,"T5_PeDesignRevision")==0)
	{
		printf("\n IT IS PE PART OBJECT HENCE EXIT!!! ***RemoveIRChecklistOnReviseOnmoduleRev***");fflush(stdout);
		return error_code;
	}
	if(tc_strcmp(type_name,"Design Revision")==0)
	{


		if(QRY_find2("ControlObjects", &qryTag));
		if (qryTag)
		{
			printf("\n ControlObjects:.Found Query ControlObjects for Revise on module  ");fflush(stdout);
		}
		else
		{
			printf("\n ControlObjects:.Not Found for Revise on module  ");fflush(stdout);
		}
		qry_val[0] = "IRChecklistRelForRevise";
		if(QRY_execute(qryTag, n_entries, qry_entri, qry_val, &qrycount, &CntrlObjTag));

		printf("\n\t ****qrycount => %d***** ",qrycount);fflush(stdout);

		if(qrycount>0)
		{
			ITKCALL(AOM_ask_value_string(source_rev,"object_string",&source_revObject_string));
			ITKCALL(AOM_ask_value_string(*new_rev,"object_string",&new_revObject_string));

			printf("\n\t ****source_revObject_string => %s***** ",source_revObject_string);fflush(stdout);
			printf("\n\t ****new_revObject_string => %s***** ",new_revObject_string);fflush(stdout);

			ITK_CALL(GRM_find_relation_type("IMAN_reference",&RefRelTag));
			printf("\n after finding RefRelTag  ");fflush(stdout);



			ITK_CALL(GRM_list_secondary_objects_only(*new_rev, RefRelTag, &IRCCount, &IRCTag));
			printf("\n  IRCCount.:%d ",IRCCount);fflush(stdout);

			 if(IRCCount > 0)
			 {

				 for(j1 =0; j1 < IRCCount; j1++)
				  {
					 ITKCALL(AOM_ask_value_string(IRCTag[j1],"object_type",&IRCobjtyp));
					 ITKCALL(AOM_ask_value_string(IRCTag[j1],"object_string",&IRCObjStr));
					 printf("\n\t ****IRC object_type => %s***** ",IRCobjtyp);fflush(stdout);
					 printf("\n\t ****IRC object_string => %s***** ",IRCObjStr);fflush(stdout);

					 if((tc_strcmp(IRCobjtyp,"T5_IR_CHECKLISTRevision") == 0))
					 {
						 ITK_CALL(GRM_find_relation(*new_rev, IRCTag[j1], RefRelTag, &relationTag));
						 if(relationTag)
						 {
							ITK_CALL(GRM_delete_relation(relationTag));
							printf("\n\t ****IRC Relation from latest revision has been removed.***** ");fflush(stdout);

						 }

					 }


					 if((tc_strcmp(IRCobjtyp,"PDF") == 0) && (tc_strstr(IRCObjStr,"IR_report")!= NULL))
					 {
						 ITK_CALL(GRM_find_relation(*new_rev, IRCTag[j1], RefRelTag, &relationTag));
						 if(relationTag)
						 {
							ITK_CALL(GRM_delete_relation(relationTag));
							printf("\n\t ****IRC PDF Relation from latest revision has been removed.***** ");fflush(stdout);

						 }

					 }

				  }
			 }

		}
		else
		{
			printf("\n Auto Relation Carryforword is OFF for Revise on Module!!  ");fflush(stdout);

		}

	}
	else
	{
		printf("\n Not a Valid Obj Type for  :: RemoveIRChecklistOnReviseOnmoduleRev !!  ");fflush(stdout);
	}

	return error_code;
}

//Akshay
int RmvsoftversionReviseee(METHOD_message_t *msg, va_list args)
{
	printf("\n ***************** I am in ::RmvsoftversionRevise on ee part:: ********************");fflush(stdout);

	//int			error_code					= ITK_ok;

	//Control Obj for On and Off Validation.
	tag_t	qryTag			= NULLTAG;
	char **qry_val			= (char **) MEM_alloc(100 * sizeof(char *));
	char    *qry_entri[1]   = {"SYSCD"};
	int n_entries			= 1;
	int qrycount			= 0;
	tag_t *CntrlObjTag		= NULLTAG;

	int			error_code					= ITK_ok;
	tag_t        source_rev					= va_arg( args, tag_t );
	const char*  rev_id						= va_arg( args, const char* );
	tag_t*       new_rev					= va_arg( args,  tag_t* );
	tag_t        item_rev_master_form		= va_arg( args, tag_t );

	char* source_revObject_string  = NULL;
	char* new_revObject_string	   = NULL;

    tag_t objTypeTag = NULLTAG;
	//char  type_name[TCTYPE_name_size_c+1];

	char* type_name =NULL;
	char* sourcesoftrev =NULL;
	char* newsoftrev =NULL;
	char* Release_status_ee =NULL;
	char* swparttype =NULL;
	char* controlObjInfo1 =NULL;
	char* controlObjInfo2 =NULL;


	if(TCTYPE_ask_object_type(source_rev,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();

	printf("\n\t ****object_type => %s***** ",type_name);fflush(stdout);
/*	if(tc_strcmp(type_name,"T5_PeDesignRevision")==0)
	{
		printf("\n IT IS PE PART OBJECT HENCE EXIT!!! ***RemoveIRChecklistOnReviseOnmoduleRev***");fflush(stdout);
		return error_code;
	}*/
	if(tc_strcmp(type_name,"T5_EE_PartRevision")==0)
	{


		if(QRY_find2("ControlObjects", &qryTag));
		if (qryTag)
		{
			printf("\n ControlObjects:.Found Query ControlObjects for Revise for RmvsoftversionReviseee  ");fflush(stdout);
		}
		else
		{
			printf("\n ControlObjects:.Not Found for RmvsoftversionReviseee  ");fflush(stdout);
		}
		qry_val[0] = "ecuswparttyp";
		if(QRY_execute(qryTag, n_entries, qry_entri, qry_val, &qrycount, &CntrlObjTag));

		printf("\n\t ****qrycount RmvsoftversionReviseee=> %d***** ",qrycount);fflush(stdout);

		if(qrycount>0)
		{
			ITK_CALL(AOM_ask_value_string(source_rev,"t5_SwPartType",&swparttype));
			printf("\n t5_SwPartType is :%s\n",swparttype);fflush(stdout);

			AOM_ask_value_string(CntrlObjTag[0],"t5_Userinfo1",&controlObjInfo1);
			printf("\n Userinfo1 is=%s ",controlObjInfo1);fflush(stdout);

			  if(tc_strcmp(controlObjInfo1,"softversionrev")==0)
			  {

				if ((tc_strcmp(swparttype,"CAL")==0) || (tc_strcmp(swparttype,"CFG")==0) || (tc_strcmp(swparttype,"APP")==0) || (tc_strcmp(swparttype,"BAS")==0) || (tc_strcmp(swparttype,"HCL")==0) || (tc_strcmp(swparttype,"PBL")==0) || (tc_strcmp(swparttype,"SBL")==0))
				{

					ITKCALL(AOM_ask_value_string(source_rev,"object_string",&source_revObject_string));
					ITKCALL(AOM_ask_value_string(*new_rev,"object_string",&new_revObject_string));

					printf("\n\t ****source_revObject_string RmvsoftversionReviseee=> %s***** ",source_revObject_string);fflush(stdout);
					printf("\n\t ****new_revObject_string RmvsoftversionReviseee=> %s***** ",new_revObject_string);fflush(stdout);

					ITKCALL(AOM_ask_value_string(source_rev,"t5_software_rev",&sourcesoftrev));
					printf("\n\t ****new_revObject_string sourcesoftrev=> %s***** ",sourcesoftrev);fflush(stdout);

					ITKCALL(AOM_ask_value_string(*new_rev,"t5_software_rev",&newsoftrev));
					printf("\n\t ****new_revObject_string newsoftrev=> %s***** ",newsoftrev);fflush(stdout);

				//	Release_status_ee = NULL;
						ITK_CALL(AOM_UIF_ask_value(source_rev,"release_status_list",&Release_status_ee));
					//	TC_write_syslog ( "\n Release_status_ee : [%s]", Release_status_ee ) ;
					printf("\n\t elease_status_ee :=> %s***** ",Release_status_ee);fflush(stdout);

					if ( tc_strstr( Release_status_ee, "ERC Released" ) != NULL )
					{

						printf("\n user performing Revise Action so emptying the software version Revision");fflush(stdout);

						if(AOM_lock(*new_rev)!=ITK_ok) PrintErrorStack();
						printf("\n Before Modification newsoftrev ");fflush(stdout);
						if( AOM_set_value_string(*new_rev,"t5_software_rev","")!=ITK_ok) PrintErrorStack();
						printf("\n After Modification newsoftrev ");fflush(stdout);
						if(AOM_save_without_extensions(*new_rev)!=ITK_ok) PrintErrorStack();
						if(AOM_unlock(*new_rev)!=ITK_ok) PrintErrorStack();
						if(AOM_refresh(*new_rev,1)!=ITK_ok) PrintErrorStack();

					}
				}
			  }


			tag_t RefRelTag =NULLTAG;
			tag_t relationTag =NULLTAG;
			tag_t* RFCTag =NULLTAG;
			int rfCCount =0;
			int rf =0;
			char* rfobjtyp =NULL;
	        char* rfObjStr =NULL;

           AOM_ask_value_string(CntrlObjTag[0],"t5_Userinfo2",&controlObjInfo2);
		   printf("\n Userinfo2 is=%s ",controlObjInfo2);fflush(stdout);

			if((tc_strcmp(swparttype,"PRM")==0) && (tc_strcmp(controlObjInfo2,"paracrefile")==0))
			{

			ITKCALL(AOM_ask_value_string(source_rev,"object_string",&source_revObject_string));
			ITKCALL(AOM_ask_value_string(*new_rev,"object_string",&new_revObject_string));

			printf("\n\t ****source_revObject_string Rmv parameter file from reference=> %s***** ",source_revObject_string);fflush(stdout);
			printf("\n\t ****new_revObject_string parameter file from reference=> %s***** ",new_revObject_string);fflush(stdout);

			ITK_CALL(GRM_find_relation_type("IMAN_reference",&RefRelTag));
			printf("\n after finding RefRelTag To Rmv parameter file from reference ");fflush(stdout);

			ITK_CALL(GRM_list_secondary_objects_only(*new_rev, RefRelTag, &rfCCount, &RFCTag));
			printf("\n  rfCCount.:%d ",rfCCount);fflush(stdout);

			 if(rfCCount > 0)
			 {

				 for(rf =0; rf < rfCCount; rf++)
				  {
					 ITKCALL(AOM_ask_value_string(RFCTag[rf],"object_type",&rfobjtyp));
					 ITKCALL(AOM_ask_value_string(RFCTag[rf],"object_string",&rfObjStr));
					 printf("\n\t ****ref object_type => %s***** ",rfobjtyp);fflush(stdout);
					 printf("\n\t ****ref object_string => %s***** ",rfObjStr);fflush(stdout);

					 if(tc_strstr(rfObjStr,"_parameter.csv")!= NULL)
					 {
						 ITK_CALL(GRM_find_relation(*new_rev, RFCTag[rf], RefRelTag, &relationTag));
						 if(relationTag)
						 {
							ITK_CALL(GRM_delete_relation(relationTag));
							printf("\n\t ****parameter file Relation from latest revision has been removed.***** ");fflush(stdout);

						 }

					 }

				  }
			 }


		    }


		}
		else
		{
			printf("\n RmvsoftversionReviseee is OFF for Revise on ee part!!  ");fflush(stdout);

		}

	}
	else
	{
		printf("\n Not a Valid Obj Type for  :: RmvsoftversionReviseee !!  ");fflush(stdout);
	}

	return error_code;
}
//******************REMOVING REPORT************************//
int RemoveREPORTOnReviseOnmoduleRev(METHOD_message_t *msg, va_list args)
{
	printf("\n ***************** I am in ::RemoveREPORTOnReviseOnmoduleRev:: ********************");fflush(stdout);

	//int			error_code					= ITK_ok;

	//Control Obj for On and Off Validation.
	tag_t	qryTag			= NULLTAG;
	char **qry_val			= (char **) MEM_alloc(100 * sizeof(char *));
	char    *qry_entri[1]   = {"SYSCD"};
	int n_entries			= 1;
	int qrycount			= 0;
	tag_t *CntrlObjTag		= NULLTAG;

	int			error_code					= ITK_ok;
	tag_t        source_rev					= va_arg( args, tag_t );
	const char*  rev_id						= va_arg( args, const char* );
	tag_t*       new_rev					= va_arg( args,  tag_t* );
	tag_t        item_rev_master_form		= va_arg( args, tag_t );

	char* source_revObject_string  = NULL;
	char* new_revObject_string	   = NULL;
	tag_t RefRelTag	               = NULLTAG;

	int			masterCout		    = 0;
	tag_t*		masterTag			= NULLTAG;
	int			i1					= 0;
	int			j1					= 0;

	int			RCCount			= 0;
	tag_t*		RCTag				= NULLTAG;

	char*			RCObjStr					= NULL;
	char*			RCObjname					= NULL;
	char*			RptNamesubstring					= NULL;
	tag_t		    relationTag					= NULLTAG;
	tag_t			newRelation					= NULLTAG;
	char*			MasterItemRevId				= NULLTAG;
	char*			MasterObject_string				= NULLTAG;
	tag_t			masterItemTag				= NULLTAG;
	tag_t			MasterLatestItemRevTag		= NULLTAG;
	char*			MasterLatestItemRevID		= NULLTAG;

    tag_t objTypeTag = NULLTAG;
	//char  type_name[TCTYPE_name_size_c+1];
	char* RCobjtyp =NULL;
	char* type_name =NULL;
	RCobjtyp=(char *) MEM_alloc(100);
	//char* RptNamesubstring_TOK[6];
	char* RptNamesubstring_TOK =NULL;
	RCobjtyp=(char *) MEM_alloc(6);
	RptNamesubstring_TOK=(char *) MEM_alloc(6);


	if(TCTYPE_ask_object_type(source_rev,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();

	printf("\n\t ****RemoveReportOnReviseOnmoduleRev---object_type => %s***** ",type_name);fflush(stdout);
	if(tc_strcmp(type_name,"T5_PeDesignRevision")==0)
	{
		printf("\n IT IS PE PART OBJECT HENCE EXIT!!! ***RemoveREPORTOnReviseOnmoduleRev***");fflush(stdout);
		return error_code;
	}
	if(tc_strcmp(type_name,"Design Revision")==0)
	{

		if(QRY_find2("ControlObjects", &qryTag));
		if (qryTag)
		{
			printf("\n RemoveREPORTOnReviseOnmoduleRev --- ControlObjects:.Found Query ControlObjects for Revise on module  ");fflush(stdout);
		}
		else
		{
			printf("\n RemoveREPORTOnReviseOnmoduleRev --- ControlObjects:.Not Found for Revise on module  ");fflush(stdout);
		}
		qry_val[0] = "REMOVEREPORTSONREVISE";
		if(QRY_execute(qryTag, n_entries, qry_entri, qry_val, &qrycount, &CntrlObjTag));

		printf("\n\t RemoveREPORTOnReviseOnmoduleRev -- ****qrycount => %d***** ",qrycount);fflush(stdout);

		if(qrycount>0)
		{

			ITKCALL(AOM_ask_value_string(source_rev,"object_string",&source_revObject_string));
			ITKCALL(AOM_ask_value_string(*new_rev,"object_string",&new_revObject_string));

			if (AOM_ask_value_string(CntrlObjTag[0],"t5_Userinfo1",&RptNamesubstring)!=ITK_ok)   PrintErrorStack();
			printf("\n RemoveREPORTOnReviseOnmoduleRev--RptNamesubstring is : [%s]\n", RptNamesubstring);fflush(stdout);

			printf("\n\t RemoveREPORTOnReviseOnmoduleRev --****source_revObject_string => %s***** ",source_revObject_string);fflush(stdout);
			printf("\n\t RemoveREPORTOnReviseOnmoduleRev ---****new_revObject_string => %s***** ",new_revObject_string);fflush(stdout);

			ITK_CALL(GRM_find_relation_type("IMAN_reference",&RefRelTag));
			printf("\n RemoveREPORTOnReviseOnmoduleRev--after finding RefRelTag  ");fflush(stdout);
			ITK_CALL(GRM_list_secondary_objects_only(*new_rev, RefRelTag, &RCCount, &RCTag));
			printf("\n  RemoveREPORTOnReviseOnmoduleRev---RCCount.:%d ",RCCount);fflush(stdout);
			 if(RCCount > 0)
			 {

				 for(j1 =0; j1 < RCCount; j1++)
				  {
					 ITKCALL(AOM_ask_value_string(RCTag[j1],"object_type",&RCobjtyp));
					 ITKCALL(AOM_ask_value_string(RCTag[j1],"object_string",&RCObjStr));
					 ITKCALL(AOM_ask_value_string(RCTag[j1],"object_name",&RCObjname));
					 printf("\n\t RemoveREPORTOnReviseOnmoduleRev--**** object_type => %s***** ",RCobjtyp);fflush(stdout);
					 printf("\n\t RemoveREPORTOnReviseOnmoduleRev--**** object_string => %s***** ",RCObjStr);fflush(stdout);
					 tc_strncpy(RptNamesubstring_TOK,RCObjname,4);
					 printf("\n\t RemoveREPORTOnReviseOnmoduleRev--**** RCObjname  => %s***** RptNamesubstring_TOK ==> %s",RCObjname,RptNamesubstring_TOK);fflush(stdout);
					 if((tc_strstr(RptNamesubstring,RptNamesubstring_TOK)!=NULL))
					 {
						  ITK_CALL(GRM_find_relation(*new_rev, RCTag[j1], RefRelTag, &relationTag));
						  if (relationTag)
						  {
							  printf("\n Report found %s \n",RCObjname); fflush(stdout);
							  ITK_CALL(GRM_delete_relation(relationTag));
							  printf("\n\t RemoveREPORTOnReviseOnmoduleRev--****Report from latest revision has been removed.***** ");fflush(stdout);

						  }
					 }
				  }
			 }

		}
		else
		{
			printf("\n RemoveREPORTOnReviseOnmoduleRev--Auto Relation Carryforword is OFF for Revise on Module!!  ");fflush(stdout);

		}

	}
	else
	{
		printf("\n Not a Valid Obj Type for  :: RemoveREPORTOnReviseOnmoduleRev !!  ");fflush(stdout);
	}

	return error_code;
}
int checkforkeyworddescription(METHOD_message_t *msg, va_list args)
{
	int	error_code = ITK_ok;
	tag_t source_revision= va_arg( args, tag_t );
	tag_t object1 = NULLTAG;
	//char  objecttype1[TCTYPE_name_size_c+1];
	tag_t	QueryTag1	= NULLTAG;
	int n_entries9 = 3;
	char *qry_entary[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};
	char **qry_value9= (char **) MEM_alloc(5 * sizeof(char *));
	int querycount= 0;
	tag_t *controlobjecttag		= NULLTAG;
	char* source_revObject_string1  = NULL;
	char* objectname9= NULL;
	char* objecttype1= NULL;
	char* Keyworddescription  = NULL;
	char* t5parttype  = NULL;
	char* information11  = NULL;
	char* role_Name1  = NULL;
	tag_t CurrentRoleTag9 = NULLTAG;
	//char role_Name1[SA_name_size_c+1];

	ITKCALL(SA_ask_current_role(&CurrentRoleTag9));
    ITKCALL(SA_ask_role_name2(CurrentRoleTag9,&role_Name1));

	printf("\n\t !..*A Inside Role Name Satisfy...\n*");fflush(stdout);
	if(TCTYPE_ask_object_type(source_revision,&object1)!=ITK_ok) PrintErrorStack();
	if(TCTYPE_ask_name2(object1,&objecttype1)!=ITK_ok) PrintErrorStack();
	printf("\n\t !..*object_type => %s\n*",objecttype1);fflush(stdout);
	if(tc_strcmp(objecttype1,"T5_PeDesignRevision")==0)
	{
		printf("\n IT IS PE PART OBJECT HENCE EXIT!!! ***checkforkeyworddescription***");fflush(stdout);
		return error_code;
	}
	if(tc_strcmp(objecttype1,"Design Revision")==0)
	{
		ITKCALL(AOM_ask_value_string(source_revision,"object_string",&source_revObject_string1));
		ITKCALL(AOM_ask_value_string(source_revision,"object_name",&objectname9));
		ITKCALL(AOM_ask_value_string(source_revision,"t5_CategoryName",&Keyworddescription));
		ITKCALL(AOM_ask_value_string(source_revision,"t5_PartType",&t5parttype));

		printf("\n  !..*Object String for Object is :- %s  ",source_revObject_string1);fflush(stdout);
		printf("\n  !..*Key Word Description:- %s  ",Keyworddescription);fflush(stdout);
		printf("\n  !..*Part type:- %s  ",t5parttype);fflush(stdout);
		printf("\n  !..*Object Name is:- %s  ",objectname9);fflush(stdout);

		char * partCat = NULL;
		if (tc_strcmp(partCat,"NULL") !=0) MEM_free(partCat);
		{
			partCat = (char *)MEM_alloc(50);
			tc_strcpy(partCat,"");
	    	tc_strcpy(partCat,",");
			tc_strcat(partCat,t5parttype);
			tc_strcat(partCat,",");
			printf("\n partCat.:%s",partCat);fflush(stdout);
		}
		printf("\n In side A IF Condition  ");fflush(stdout);
		if(QRY_find2("Control Objects...", &QueryTag1));
		if (QueryTag1)
		{
			printf("\n !..* ControlObjects Query Found for Check Key Word Description *..! ");fflush(stdout);
		}
		else
		{
			printf("\n  !..*Not Found  Check Key Word Description *..!  ");fflush(stdout);
		}
		qry_value9[0] = "checkforkeyworddesc";
		qry_value9[1] = "Key_WordDesc";
		qry_value9[2] = "0";
		if(QRY_execute(QueryTag1, n_entries9, qry_entary, qry_value9, &querycount, &controlobjecttag));
		printf("\n\t !..*Query Count => %d*..! ",querycount);fflush(stdout);
		if(querycount>0)
		{
			ITKCALL(AOM_ask_value_string( controlobjecttag[0], "t5_Userinfo1", &information11));
			printf("\n Information1 is: %s ",information11);fflush(stdout);
			if((tc_strstr(role_Name1,"MBOM") != NULL) || (tc_strstr(role_Name1,"APL") != NULL))
			{
				printf("\n\n Latest Current RoleName : %s ",role_Name1); fflush(stdout);
				if(tc_strstr(information11,partCat)!=NULL)///error
				{
					printf("\n\n Condition is Satisfy Inside Condition.............. ",role_Name1); fflush(stdout);
					int length= strlen(Keyworddescription);
					if(length == 0)
					{
						printf("\n !..*Please fill Key-word Description ");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err, "Unable to create part, Please Fill Key-word Description.");
						return ITK_err;
					}
					else
					{
						printf("\n Key Word Description is Filled, Allow user to create part.... ");fflush(stdout);
					}
				}
				else
				{
					printf("\n Information1 is not having Part type.. ");fflush(stdout);
				}
			}
			else
			{
				printf("\n\t !..*Current LogIn User is not belongs to APL & MBOM\n*..!");fflush(stdout);
			}

		}
		else
		{
			printf("\n  !..*control Object of Key-Word Description is not found  ");fflush(stdout);
		}
	}
	else
	{
		printf("\n  !..*object type is not Design Revision......  ");fflush(stdout);
	}
	return 0;
}
//Akshay
extern DLLAPI int tm_delete_rel_dataset_method_1(METHOD_message_t *msg, va_list args)
{
	int ifail = ITK_ok;
    //ResultStatus rstat;
	int pi = 0 ;
	int si = 0 ;
    va_list largs;
    va_copy( largs, args );
    tag_t relation  = va_arg(largs, tag_t);
    va_end( largs );

	tag_t primary_object = NULLTAG;
	tag_t secondary_object = NULLTAG;
	tag_t primary_obj_Type_Tag = NULLTAG;
	tag_t secondary_Type_Tag = NULLTAG;
	char *relation_type_name = NULL;
	char *primary_type_name = NULL;
	char *secondary_type_name = NULL;
	char *Release_status_SOR = NULL;
	char *error_msg_1 = NULL;
	int n_found_ctrl_obj = 0;

	error_msg_1 = ( char * ) MEM_alloc ( 150 * sizeof( char )) ;

	char *username;
	char *group_name;
	char	*roleName	= NULL;
	tag_t group_tag=NULLTAG;
	tag_t user_tag=NULLTAG;
	tag_t  CurrentRoleTag = NULLTAG;


	tag_t relation_type = NULLTAG;
    ITK_CALL(GRM_ask_relation_type(relation , &relation_type));
	//ITK_CALL ( TCTYPE_ask_object_type ( primary_object, &primary_obj_Type_Tag ) ) ;
	ITK_CALL ( TCTYPE_ask_name2 ( relation_type, &relation_type_name ) );
	TC_write_syslog("\nQSOR_pdf_delete_rel_method_pre obj relation_type_name : [%s]\n", relation_type_name);

	ITK_CALL( GRM_ask_primary (relation , &primary_object) );
	ITK_CALL ( TCTYPE_ask_object_type ( primary_object, &primary_obj_Type_Tag ) ) ;
	ITK_CALL ( TCTYPE_ask_name2 ( primary_obj_Type_Tag, &primary_type_name ) );
	TC_write_syslog("\nQSOR_pdf_delete_rel_method_pre obj primary_type_name : [%s]\n", primary_type_name);

	ITK_CALL ( GRM_ask_secondary(relation , &secondary_object) );
	ITK_CALL ( TCTYPE_ask_object_type ( secondary_object, &secondary_Type_Tag ) ) ;
	ITK_CALL ( TCTYPE_ask_name2 ( secondary_Type_Tag, &secondary_type_name ) );
	TC_write_syslog("\nQSOR_pdf_delete_rel_method_pre obj secondary_type_name : [%s]\n", secondary_type_name);


	n_found_ctrl_obj = tm_check_info_control_object_gen ( "CTRL_DEL_REL",relation_type_name , primary_type_name, secondary_type_name );
	printf ( "\nn_found_ctrl_obj : [%d]", n_found_ctrl_obj ) ;
	TC_write_syslog ( "\nn_found_ctrl_obj : [%d]", n_found_ctrl_obj ) ;

	POM_get_user(&username,&user_tag);
	POM_ask_group(&group_name, &group_tag);

	ITK_CALL(SA_ask_current_role(&CurrentRoleTag));
	ITK_CALL(SA_ask_role_name2(CurrentRoleTag,&roleName));
	printf("\n\n  User namew : %s\n",username); fflush(stdout);
	printf("\n\n  roleName1 : %s\n",roleName); fflush(stdout);


	if ( n_found_ctrl_obj > 0 )
	{
		if (((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0)) && (tc_strstr(roleName,"STD")==NULL) && (tc_strstr(roleName,"APL")==NULL) && (tc_strstr(roleName,"MBOM")==NULL) && (tc_strstr(roleName,"Support")==NULL)) //MBOM implementation for CV TZ-1.70 Backend Fixes
			{



				//TC_write_syslog ( "\nCreate hostname username and password file control object for host : %s",hostbuffer ) ;
				//return 0;
			//}

			//if ( ( tc_strcmp (primary_type_name,"T5_quicksorRevision") == 0 ) && ( tc_strcmp (secondary_type_name,"PDF") == 0 ) )
			//{
				Release_status_SOR = NULL;
				ITK_CALL(AOM_UIF_ask_value(primary_object,"release_status_list",&Release_status_SOR));
				TC_write_syslog ( "\nRelease_status_SOR : [%s]", Release_status_SOR ) ;

				if ( tc_strstr( Release_status_SOR, "ERC Released" ) != NULL )
				{
					sprintf ( error_msg_1, "You Can not delete relation between [%s] and [%s] as primary object is ERC Released" ,primary_type_name ,secondary_type_name ) ;
					EMH_store_error_s1 ( EMH_severity_error, PLM_error, error_msg_1 ) ;
					TC_write_syslog ( "\nError MSG : [%s]", error_msg_1 ) ;
					return PLM_error;
				}
				else
				{
					TC_write_syslog ( "\nRelease_status_SOR : [%s] hence allowed to cut (break relation)", Release_status_SOR ) ;
				}
			}
			else
			{
				printf("\n\n  Bypass for infodba/loader/support \n"); fflush(stdout);

			}
	}
    return ifail;
}


//Akshay
extern DLLAPI int tm_add_rel_dataset_method_1(METHOD_message_t *msg, va_list args)
{
	int ifail = ITK_ok;
    //ResultStatus rstat;
	int pi = 0 ;
	int si = 0 ;
    va_list largs;
    va_copy( largs, args );
    tag_t relation  = va_arg(largs, tag_t);
    va_end( largs );

	tag_t primary_object = NULLTAG;
	tag_t secondary_object = NULLTAG;
	tag_t primary_obj_Type_Tag = NULLTAG;
	tag_t secondary_Type_Tag = NULLTAG;
	char *relation_type_name = NULL;
	char *primary_type_name = NULL;
	char *secondary_type_name = NULL;
	char *Release_status_SOR = NULL;
	char *error_msg_1 = NULL;
	int n_found_ctrl_obj = 0;

	error_msg_1 = ( char * ) MEM_alloc ( 150 * sizeof( char )) ;

	char *username;
	char *group_name;
	char	*roleName	= NULL;
	tag_t group_tag=NULLTAG;
	tag_t user_tag=NULLTAG;
	tag_t  CurrentRoleTag = NULLTAG;


	tag_t relation_type = NULLTAG;
    ITK_CALL(GRM_ask_relation_type(relation , &relation_type));
	//ITK_CALL ( TCTYPE_ask_object_type ( primary_object, &primary_obj_Type_Tag ) ) ;
	ITK_CALL ( TCTYPE_ask_name2 ( relation_type, &relation_type_name ) );
	TC_write_syslog("\nQSOR_pdf_add_rel_method_pre obj relation_type_name : [%s]\n", relation_type_name);

	ITK_CALL( GRM_ask_primary (relation , &primary_object) );
	ITK_CALL ( TCTYPE_ask_object_type ( primary_object, &primary_obj_Type_Tag ) ) ;
	ITK_CALL ( TCTYPE_ask_name2 ( primary_obj_Type_Tag, &primary_type_name ) );
	TC_write_syslog("\nQSOR_pdf_add_rel_method_pre obj primary_type_name : [%s]\n", primary_type_name);

	ITK_CALL ( GRM_ask_secondary(relation , &secondary_object) );
	ITK_CALL ( TCTYPE_ask_object_type ( secondary_object, &secondary_Type_Tag ) ) ;
	ITK_CALL ( TCTYPE_ask_name2 ( secondary_Type_Tag, &secondary_type_name ) );
	TC_write_syslog("\nQSOR_pdf_add_rel_method_pre obj secondary_type_name : [%s]\n", secondary_type_name);


	n_found_ctrl_obj = tm_check_info_control_object_gen ( "CTRL_add_REL",relation_type_name , primary_type_name, secondary_type_name );
	printf ( "\nn_found_ctrl_obj for add rel : [%d]", n_found_ctrl_obj ) ;
	TC_write_syslog ( "\nn_found_ctrl_obj : [%d]", n_found_ctrl_obj ) ;

	POM_get_user(&username,&user_tag);
	POM_ask_group(&group_name, &group_tag);

	ITK_CALL(SA_ask_current_role(&CurrentRoleTag));
	ITK_CALL(SA_ask_role_name2(CurrentRoleTag,&roleName));
	printf("\n\n  User namew : %s\n",username); fflush(stdout);
	printf("\n\n  roleName1 : %s\n",roleName); fflush(stdout);

	char *swparttype = NULL;
	char *PEcuType = NULL;
	char *SEcuType = NULL;
	int flag=0;
	int eeflag=0;

	//Checking s/w part type and ECU Type

	if (((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0)) && (tc_strstr(roleName,"STD")==NULL) && (tc_strstr(roleName,"APL")==NULL) && (tc_strstr(roleName,"MBOM")==NULL) && (tc_strstr(roleName,"Support")==NULL))
	 {

		if ((tc_strcmp(relation_type_name,"T5_ContHasPara")==0) && (tc_strcmp(primary_type_name,"T5_EE_PartRevision")==0))
		{
			 printf("\n\n  Inside T5_ContHasPara \n"); fflush(stdout);
			if (tc_strcmp(secondary_type_name,"T5_EE_PartRevision")==0)
			{
				eeflag=1;
				 ITKCALL(AOM_ask_value_string(secondary_object,"t5_SwPartType",&swparttype));
				 ITKCALL(AOM_ask_value_string(primary_object,"t5_EcuType",&PEcuType));
				 ITKCALL(AOM_ask_value_string(secondary_object,"t5_EcuType",&SEcuType));

				 printf("\n\n  swparttype : %s\n",swparttype); fflush(stdout);
				 printf("\n\n  PEcuType : %s\n",PEcuType); fflush(stdout);
				 printf("\n\n  SEcuType : %s\n",SEcuType); fflush(stdout);

				 if (tc_strcmp(swparttype,"PRM")==0)
				 {
					 flag=1;
				 }
			}
			if (flag==0 || eeflag==0)
			{
				sprintf ( error_msg_1, "You Can not create relation between [%s] and [%s] as Secondary object not Parameter " ,primary_type_name ,secondary_type_name ) ;
				EMH_store_error_s1 ( EMH_severity_error, PLM_error, error_msg_1 ) ;
				TC_write_syslog ( "\nError MSG1 : [%s]", error_msg_1 ) ;
				return PLM_error;

			}
			if (tc_strcmp(PEcuType,SEcuType)!=0)
			{
				sprintf ( error_msg_1, "You Can not create relation between [%s] and [%s] as ECU Type is not Matching " ,primary_type_name ,secondary_type_name ) ;
				EMH_store_error_s1 ( EMH_severity_error, PLM_error, error_msg_1 ) ;
				TC_write_syslog ( "\nError MSG3 : [%s]", error_msg_1 ) ;
				return PLM_error;

			}
		 }

		 if ((tc_strcmp(relation_type_name,"T5_ContHasSlave")==0) && (tc_strcmp(primary_type_name,"T5_EE_PartRevision")==0))
		{
			 printf("\n\n  Inside T5_ContHasSlave \n"); fflush(stdout);
			if (tc_strcmp(secondary_type_name,"T5_EE_PartRevision")==0)
			{
				eeflag=1;
				 ITKCALL(AOM_ask_value_string(secondary_object,"t5_SwPartType",&swparttype));
				 printf("\n\n  swparttype : %s\n",swparttype); fflush(stdout);
				 if (tc_strcmp(swparttype,"CON")==0)
				 {
					 flag=1;
				 }
			}
			if (flag==0 || eeflag==0)
			{
				sprintf ( error_msg_1, "You Can not create relation between [%s] and [%s] as Secondary object not Container " ,primary_type_name ,secondary_type_name ) ;
				EMH_store_error_s1 ( EMH_severity_error, PLM_error, error_msg_1 ) ;
				TC_write_syslog ( "\nError MSG2 : [%s]", error_msg_1 ) ;
				return PLM_error;

			}
		 }
	 }

//Checking Release Flag
	if ( n_found_ctrl_obj > 0 )
	{
		if (((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0)) && (tc_strstr(roleName,"STD")==NULL) && (tc_strstr(roleName,"APL")==NULL) && (tc_strstr(roleName,"MBOM")==NULL) && (tc_strstr(roleName,"Support")==NULL)) //MBOM implementation for CV TZ-1.70 Backend Fixes
			{



				//TC_write_syslog ( "\nCreate hostname username and password file control object for host : %s",hostbuffer ) ;
				//return 0;
			//}

			//if ( ( tc_strcmp (primary_type_name,"T5_quicksorRevision") == 0 ) && ( tc_strcmp (secondary_type_name,"PDF") == 0 ) )
			//{
				Release_status_SOR = NULL;
				ITK_CALL(AOM_UIF_ask_value(primary_object,"release_status_list",&Release_status_SOR));
				TC_write_syslog ( "\nRelease_status_ecu : [%s]", Release_status_SOR ) ;

				if ( tc_strstr( Release_status_SOR, "ERC Released" ) != NULL )
				{
					sprintf ( error_msg_1, "You Can not create relation between [%s] and [%s] as primary object is ERC Released" ,primary_type_name ,secondary_type_name ) ;
					EMH_store_error_s1 ( EMH_severity_error, PLM_error, error_msg_1 ) ;
					TC_write_syslog ( "\nError MSG : [%s]", error_msg_1 ) ;
					return PLM_error;
				}
				else
				{
					TC_write_syslog ( "\nRelease_status_SOR : [%s] hence allowed to Create relation", Release_status_SOR ) ;
				}
			}
			else
			{
				printf("\n\n  Bypass for infodba/loader/support \n"); fflush(stdout);

			}
	}
    return ifail;
}

//11-09-2023 EEPart Validation
int eePartContParaBOM_Validation(METHOD_message_t *msg, va_list args)
{

	printf("\n ***************** I am in ::eePartContParaBOM_Validation:: ********************");fflush(stdout);

		int			child_attr			= 0;
		int			child_attr1			= 0;
		int			Item_attr			= 0;
		int			blobjType			= 0;
		int			bl_Child_SWobjType	= 0;
		int			Rev_attr			= 0;
		int			bl_abs_xform		= 0;
		int			bl_relative_xform	= 0;
		int			chlidLine_Count		= 0;
		int			i					= 0;

		int			isParentCont		=0;
		int			isParentPara		=0;

		int			error_code			= ITK_ok;
		char		*childObjType			= NULL;
		char		*childSWPartType			= NULL;
		char		*child_qty1			= NULL;
		char		*Item_id			= NULL;
		char		*Item_rev_id		= NULL;

		char		*child_Item_id			= NULL;
		char		*child_Item_rev_id		= NULL;
		char		*topLineObjectType		= NULL;
		char		*topLineSWType		= NULL;

		char		*child_part_type	= NULL;
		char		*child_obj_type		= NULL;
		char		*parent_obj_type	= NULL;
		char		*child_item_id2		= NULL;
		char		*child_item_id		= NULL;
		char		*ApplnOwner			= NULL;
		char		*child_abs_xform	= NULL;
		char		*child_relv_xform	= NULL;
		char		*child_rev_id		= NULL;

		//
		tag_t top_bom_line				= NULLTAG;
		tag_t *childLines				= NULLTAG;
		tag_t		revision_tag		= NULLTAG;

		tag_t window_tag = va_arg( args, tag_t );

		//Control Obj for On and Off Validation.
		tag_t	qry_t1_bomSave			= NULLTAG;
		char **qry_val3_bomSave			= (char **) MEM_alloc(100 * sizeof(char *));
		char    *qry_entr1_bomSave[1]   = {"SYSCD"};
		int n_entr1_bomSave				= 1;
		int rsltCunt1_bomSave			= 0;
		tag_t *CntrlObjTag1_bomSave		= NULLTAG;

		char* usrInfo1_bomSave			= NULL;
		char* usrInfo2_bomSave			= NULL;


		if(QRY_find2("ControlObjects", &qry_t1_bomSave));
		if (qry_t1_bomSave)
		{
			printf("\n ControlObjects:.Found Query ControlObjects  ");fflush(stdout);
		}
		else
		{
			printf("\n ControlObjects:.Not Found Query ControlObjects  ");fflush(stdout);
		}
		qry_val3_bomSave[0] = "EEPartBOMValidation";
		if(QRY_execute(qry_t1_bomSave, n_entr1_bomSave, qry_entr1_bomSave, qry_val3_bomSave, &rsltCunt1_bomSave, &CntrlObjTag1_bomSave));

		if(rsltCunt1_bomSave>0)
		{
			ITKCALL(BOM_ask_window_top_line(window_tag,&top_bom_line));

			//ITKCALL(BOM_line_look_up_attribute ("bl_item_item_id",&Item_attr));
			//ITKCALL(BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Rev_attr));
			//ITKCALL(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&blobjType));
			//ITKCALL(BOM_line_look_up_attribute ("bl_T5_EE_PartRevision_t5_SwPartType",&bl_Child_SWobjType));
			//
			//ITKCALL(BOM_line_ask_attribute_string(top_bom_line, Item_attr, &Item_id));
			//ITKCALL(BOM_line_ask_attribute_string(top_bom_line, Rev_attr, &Item_rev_id));
			//ITKCALL(BOM_line_ask_attribute_string(top_bom_line, blobjType, &topLineObjectType));
			//ITKCALL(BOM_line_ask_attribute_string(top_bom_line, bl_Child_SWobjType, &topLineSWType));

			if( AOM_ask_value_string(top_bom_line,"bl_item_item_id",&Item_id)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(top_bom_line,"bl_rev_item_revision_id",&Item_rev_id)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(top_bom_line,"fnd0bl_line_object_type",&topLineObjectType)!=ITK_ok) PrintErrorStack();
			if( AOM_ask_value_string(top_bom_line,"bl_T5_EE_PartRevision_t5_SwPartType",&topLineSWType)!=ITK_ok) PrintErrorStack();

			printf("\n\t topLineObjectType => [%s] ",topLineObjectType);fflush(stdout);
			printf("\n\t topLineSWType	   => [%s] ",topLineSWType);fflush(stdout);

			// This check is for EE Part only
			if (tc_strcmp(topLineObjectType,"T5_EE_PartRevision") ==0 )
			{
				//Check if SW is Container or Parameter

				if ((tc_strcmp(topLineSWType,"Container") ==0 ) || (tc_strcmp(topLineSWType,"Parameter") ==0))
				{
					//Getting all child of Top Line
					ITKCALL(BOM_line_ask_child_lines(top_bom_line,&chlidLine_Count,&childLines));
					for(i =0; i < chlidLine_Count;i++)
					{
						//ITKCALL(BOM_line_ask_attribute_string(childLines[i], Item_attr, &child_Item_id));
						//ITKCALL(BOM_line_ask_attribute_string(childLines[i], Rev_attr, &child_Item_rev_id));
						//ITKCALL(BOM_line_ask_attribute_string(childLines[i], blobjType, &childObjType));
						//ITKCALL(BOM_line_ask_attribute_string(childLines[i], bl_Child_SWobjType, &childSWPartType));

						if( AOM_ask_value_string(childLines[i],"bl_item_item_id",&child_Item_id)!=ITK_ok) PrintErrorStack();
						if( AOM_ask_value_string(childLines[i],"bl_rev_item_revision_id",&child_Item_rev_id)!=ITK_ok) PrintErrorStack();
						if( AOM_ask_value_string(childLines[i],"fnd0bl_line_object_type",&childObjType)!=ITK_ok) PrintErrorStack();
						if( AOM_ask_value_string(childLines[i],"bl_T5_EE_PartRevision_t5_SwPartType",&childSWPartType)!=ITK_ok) PrintErrorStack();

						printf("\n\t childObjType		   => [%s] ",childObjType);fflush(stdout);
						printf("\n\t childSWPartType	   => [%s] ",childSWPartType);fflush(stdout);

						if (tc_strcmp(childSWPartType,"Container") ==0)
						{
							//Container inside container is not allowed.
							printf("\n Pararent is [%s] & child is [%s] , this is not allowd.",topLineSWType,childSWPartType);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Please check S/W Part type of Parent & child, Not valid combination.");
							return ITK_err;
						}
						else if (tc_strcmp(childSWPartType,"Parameter") ==0)
						{
							//Container inside Parameter is not allowed.
							printf("\n Pararent is [%s] & child is [%s] , this is not allowd.",topLineSWType,childSWPartType);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Please check S/W Part type of Parent & child, Not valid combination.");
							return ITK_err;

						}

					}

				}
			}
		}
		else
		{
			printf("\n eePartContParaBOM_Validation is OFF !!  ");fflush(stdout);

		}

	return error_code;
}
//CCVC_PreAction_Validation
/*int CCVC_PreAction_Validation(METHOD_message_t *msg, va_list args)
{

	printf("\n *************INSIDE CCVC_PreAction_Validation********************  ");fflush(stdout);
	int		ifail							= 0;

	//char* item_id				= va_arg(args, char*);
	//char* item_name				= va_arg(args, char*);
	//char* type_name				= va_arg(args, char*);
	//char* item_rev_id			= va_arg(args, char*);

	//tag_t* new_item				=va_arg(args, tag_t*);
	//tag_t* new_rev				=va_arg(args, tag_t*);
	//tag_t* item_master_form		=va_arg(args, tag_t*);
	//tag_t* item_rev_master_form	=va_arg(args, tag_t*);

	tag_t objTypeTag = NULLTAG;
	char  type_name[TCTYPE_name_size_c+1];

	tag_t objTag = va_arg(args, tag_t);

	//Control Obj for On and Off Validation.
	tag_t	qry_t1_CCVCVal			= NULLTAG;
	char **qry_val3_CCVCVal			= (char **) MEM_alloc(100 * sizeof(char *));
	char    *qry_entr1_CCVCVal[1]   = {"SYSCD"};
	int n_entr1_CCVCVal				= 1;
	int rsltCunt1_CCVCVal			= 0;
	tag_t *CntrlObjTag1_CCVCVal		= NULLTAG;

	//tag_t new_rev_type_tag = NULL;
	//char new_rev_obj_type_name[WSO_name_size_c+1];
	char    *PartType               = NULL;
	char    *ProjectCode               = NULL;
	char*	 usrInfo1				= NULL;
	char* errorMsgCCVCVal =NULL;
	char* colourInd =NULL;
	char* objectString =NULL;
	char* itemRevID =NULL;


	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,type_name)!=ITK_ok) PrintErrorStack();


	printf("\n type_name is:%s",type_name);fflush(stdout);

	//This check is applicable for only Desg Rev
	if((tc_strcmp(type_name,"Design Revision") == 0))
	{
		ITK_CALL(AOM_ask_value_string(objTag,"t5_PartType",&PartType));
		ITK_CALL(AOM_ask_value_string(objTag,"t5_ProjectCode",&ProjectCode));
		ITK_CALL(AOM_ask_value_string(objTag,"t5_ColourInd",&colourInd));
		ITK_CALL(AOM_ask_value_string(objTag,"object_string",&objectString));
		ITK_CALL(AOM_ask_value_string(objTag,"item_revision_id",&itemRevID));


		printf("\n\n\t\t t5_PartType := %s  ",PartType);fflush(stdout);
		printf("\n\n\t\t t5_ProjectCode := %s  ",ProjectCode);fflush(stdout);
		printf("\n\n\t\t t5_ColourInd := %s  ",colourInd);fflush(stdout);
		printf("\n\n\t\t objectString := %s  ",objectString);fflush(stdout);
		printf("\n\n\t\t item_revision_id := %s  ",itemRevID);fflush(stdout);

		//Part type check.
		if((tc_strcmp(PartType,"CCVC") == 0) || (tc_strcmp(PartType,"V") == 0) )
		{
			//This validation is applicable for only non colour objects
			if((tc_strcmp(colourInd,"N") == 0))
			{
				if((tc_strcmp(itemRevID,"NR;1") == 0))
				{

					if(QRY_find2("ControlObjects", &qry_t1_CCVCVal));
					if (qry_t1_CCVCVal)
					{
						printf("\n ControlObjects:.Found Query ControlObjects  ");fflush(stdout);
					}
					else
					{
						printf("\n ControlObjects:.Not Found Query ControlObjects  ");fflush(stdout);
					}
					qry_val3_CCVCVal[0] = "CCVC/SVR Check";
					if(QRY_execute(qry_t1_CCVCVal, n_entr1_CCVCVal, qry_entr1_CCVCVal, qry_val3_CCVCVal, &rsltCunt1_CCVCVal, &CntrlObjTag1_CCVCVal));

					if(rsltCunt1_CCVCVal>0)
					{
						printf("\n Part type CCVC / V found  ");fflush(stdout);
						ITK_CALL(AOM_ask_value_string(CntrlObjTag1_CCVCVal[0],"t5_Userinfo1",&usrInfo1));

							if((tc_strstr(usrInfo1,ProjectCode) != NULL))
							{
									// Need to give error, design rev should not create here
									errorMsgCCVCVal=(char *)MEM_alloc(200);
									printf("After mem alloc ");
									tc_strcpy (errorMsgCCVCVal, "CCVC/V : ");
									strcat(errorMsgCCVCVal,objectString);
									strcat(errorMsgCCVCVal,",of Project code : ");
									strcat(errorMsgCCVCVal,ProjectCode);
									strcat(errorMsgCCVCVal,", is not allowed to create.");
									//Not allowed give error here.
									EMH_store_error_s1(EMH_severity_error,ITK_err,errorMsgCCVCVal);
									return ITK_err;

						    }
							else
							{
								printf("\n CCVC_PreAction_Validation ::Object creation is allowed, As Porject code is not LOCK for creation.  ");fflush(stdout);
							}

					}
					else
					{
						printf("\n CCVC_PreAction_Validation:: Control Object no found, Validation is OFF  ");fflush(stdout);
					}
				}
				else
				{
					printf("\n\n\t\t CCVC_PreAction_Validation:: Validation is not applicable, Rev Seq is not NR1");fflush(stdout);
				}
			}
			else
			{
					printf("\n\n\t\t CCVC_PreAction_Validation:: Validation is not applicable, Colour indicator is Y");fflush(stdout);
			}

		}
		else
		{
			printf("\n\n\t\t CCVC_PreAction_Validation :: Validation is not applicable for :  t5_PartType := %s  ",PartType);fflush(stdout);
		}


	  }
	return ifail;

}
*/
extern int t8save_design_custom_exit(int *decision, va_list args)
{
	int ifail = ITK_ok;
	METHOD_id_t  method ;
	METHOD_id_t  method1 ;
	METHOD_id_t  method2 ;
	METHOD_id_t  method3 ;
	METHOD_id_t  method31; //prince
	METHOD_id_t  method4 ; //Adi
	METHOD_id_t  methodSVR ;
	METHOD_id_t  methodVendor ;
	METHOD_id_t  methodBOM ;
 	METHOD_id_t  methodVF ;
	//Neha (CR-FY23-0145)
	METHOD_id_t  methodDR ;
	METHOD_id_t  methodColInd ;
	METHOD_id_t  methodCompCode ;
	METHOD_id_t  methodEnvDim ;
	METHOD_id_t	 methodDesGrp ;
	METHOD_id_t	 methodSpareCri ;
	METHOD_id_t  methodSpareInd ;
	METHOD_id_t  methodMatCls ;
	METHOD_id_t  methodMaterial ;
	METHOD_id_t  methodPrtTyp ;
	METHOD_id_t  methodProjCode ;
	METHOD_id_t  methodRevPrtTyp ;
	METHOD_id_t  methodWeight ;
	METHOD_id_t  methodRolledupWt ;
	METHOD_id_t  methodUom ;
	METHOD_id_t  methodAhdMakeBuyInd ;
	METHOD_id_t  methodCarMakeBuyInd ;
	METHOD_id_t  methodPunPCBUMakeBuyInd ;
	METHOD_id_t	 methodPunUvMakeBuyInd ;
	METHOD_id_t	 methodKeyDesc ;
	//v2
	METHOD_id_t	 methodARDRSts ;
	METHOD_id_t	 methodAddOnDes ;
	METHOD_id_t	 methodDesignGrp ;
	METHOD_id_t  methodDesignMileStone;
	METHOD_id_t  methodEEMatCls;
	METHOD_id_t  methodEEPrtPara;
	METHOD_id_t  methodEEPrtMileStone;
	METHOD_id_t  methodEEPrtTyp;
	METHOD_id_t  methodEEEcuTyp;
	METHOD_id_t  methodKeyDescClPrt;
	METHOD_id_t  methodKeyDescDesign;
	METHOD_id_t  methodModDescDesRev;
	METHOD_id_t  methodModDescClPrt;
	METHOD_id_t  methodModule;
	METHOD_id_t  methodAddr;
	METHOD_id_t  methodModGrp;
	METHOD_id_t  methodModNme;
	METHOD_id_t  methodModTyp;
	METHOD_id_t  methodPrtMaterial;
	METHOD_id_t  methodPrtType;
	METHOD_id_t  methodProCode;
	METHOD_id_t  methodProIds;
	METHOD_id_t  methodSWPrtTyp;
	METHOD_id_t  methodUnitofMeasure;
	METHOD_id_t  methodUOMDesign;

	METHOD_id_t  methodDesc;
	METHOD_id_t  methodDescEE;
	METHOD_id_t  methodDrawingInd;
	METHOD_id_t  methodDrawingIndClr;
	METHOD_id_t  methodDrawingNo;
	METHOD_id_t  methodLoc;
	METHOD_id_t  methodMainSrl;
	METHOD_id_t  methodRemrk;
	METHOD_id_t  methodDesgnGrp;
	METHOD_id_t  methodDmlNo;
	METHOD_id_t  methodColIndClr;
	METHOD_id_t  methodCoated;
	METHOD_id_t  methodCoatedClr;
	METHOD_id_t  methodWtClr;
	METHOD_id_t  methodWtEE;
	METHOD_id_t  methodMatClsClr;
	METHOD_id_t  methodCompCodeClr;
	METHOD_id_t  methodRolledUpWeight;
	METHOD_id_t  methodOwnerDesignUnt;
	METHOD_id_t  methodOwnerDesignUntClr;
	METHOD_id_t  methodHomoInd;
	METHOD_id_t  methodCMVR;
	METHOD_id_t  methodSurfAra;
	METHOD_id_t  methodTT;
	METHOD_id_t  methodSupplierNme;
	METHOD_id_t  methodTargetWt;
	METHOD_id_t  methodPlatform;
	METHOD_id_t  methodBOMCmpl;

	METHOD_id_t  methodAbsoluteTMatrix;
	METHOD_id_t  methodAggregate;
	METHOD_id_t  methodAggregateGrp;
	METHOD_id_t  methodDesignRuleApplicability;
	METHOD_id_t  methodOwner;
	METHOD_id_t  methodOwnerDesignDept;
	METHOD_id_t  methodOwningProject;
	METHOD_id_t  methodPartPlatform;
	METHOD_id_t  methodDefaultUOM;
	METHOD_id_t  methodDefaultTmatrix;
	METHOD_id_t  methodSuppressed;

	//Neha

	//Kalpesh
	METHOD_id_t		method_ee_part;
	METHOD_id_t		method_arch_module_access;
	METHOD_id_t		method_platform_access;
 	METHOD_id_t		method_bl_cut;
	METHOD_id_t		method_quantity;
	METHOD_id_t		method_para_clause;
	METHOD_id_t		method_durafit;
	METHOD_id_t		method_para_Save;
	METHOD_id_t		method_CCV_ECU;
	METHOD_id_t		method_Ecu_para_Save;

	//Kirtikumar 10/10/2022
	METHOD_id_t		method_svr_validation;
	METHOD_id_t		method_ccvc_validation;
	//METHOD_id_t		method_ccvc_validation1;
	//16-March-2023
	METHOD_id_t		method_bom_windowSave_validation;

	METHOD_id_t		method_ee_Part_Revise;
	METHOD_id_t		method_ee_Part_checkOut;

	//11-09-2023 Added by Kirtikumar
	METHOD_id_t		method_EE_PartContParaBOM_Save_Validation;

	//Added by Amar TZ TCUA 1.76
	METHOD_id_t  method_Desgrp ;
	METHOD_id_t  method_Prjcode ;

	//Added by Ketan TZ TCUA 1.76
	//METHOD_id_t  method13;
	METHOD_id_t		method13_bl_add;
	METHOD_id_t		amethod13_bl_addrelease;
	METHOD_id_t		method13_bl_cut;

	METHOD_id_t		method_Module_checkOut;
	METHOD_id_t		method_Module_Revise;

	METHOD_id_t     method_Keyworddescription;

	METHOD_id_t  method_delete_rel;
	METHOD_id_t  method_add_rel;

	*decision = ALL_CUSTOMIZATIONS;

	/* do something useful here, for now just return */
	printf("\n\n CreateDesign.c:it, via Custom User Exit. ");fflush(stdout);
	if ( METHOD_find_method("Design", TC_save_msg, &method) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_method("Design Revision", TC_save_msg, &method1) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_method("CMI2Drawing", AE_save_dataset_msg, &method2) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_method("BOMLine", BOMLine_add_msg, &method3) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_method("VariantRule", TC_save_msg, &methodSVR) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_method("Vendor", TC_save_msg, &methodVendor) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_method("BOMView Revision","PS_bvr_create_occs",&methodBOM) !=ITK_ok) PrintErrorStack();//uppp
	if ( METHOD_find_prop_method("BOMLine","bl_formula", PROP_set_value_tag_msg,&methodVF) !=ITK_ok) PrintErrorStack();   //Prachi
	//Neha(CR-FY23-0145)
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_PartStatus", PROP_set_value_string_msg, &methodDR) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_ColourInd", PROP_set_value_string_msg, &methodColInd) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_PrtCatCode", PROP_set_value_string_msg, &methodCompCode) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_EnvelopeDimensions", PROP_set_value_string_msg, &methodEnvDim) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_DesignGrp", PROP_set_value_string_msg, &methodDesGrp) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_SpareCriteria", PROP_set_value_string_msg, &methodSpareCri) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_SpareInd", PROP_set_value_string_msg, &methodSpareInd) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_MatlClass", PROP_set_value_string_msg, &methodMatCls) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_Material", PROP_set_value_string_msg, &methodMaterial) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_PartType", PROP_set_value_string_msg, &methodPrtTyp) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_ProjectCode", PROP_set_value_string_msg, &methodProjCode) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design_t5_RevPartType", PROP_set_value_string_msg, &methodRevPrtTyp) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_Weight", PROP_set_value_string_msg, &methodWeight) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_RolledupWt", PROP_set_value_string_msg, &methodRolledupWt) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_uom", PROP_set_value_string_msg, &methodUom) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_AhdMakeBuyIndicator", PROP_set_value_string_msg, &methodAhdMakeBuyInd) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_CarMakeBuyIndicator", PROP_set_value_string_msg, &methodCarMakeBuyInd) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_PunPCBUMakeBuyIndicator", PROP_set_value_string_msg, &methodPunPCBUMakeBuyInd) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_PunUVMakeBuyIndicator", PROP_set_value_string_msg, &methodPunUvMakeBuyInd) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_CategoryName", PROP_set_value_string_msg, &methodKeyDesc) !=ITK_ok) PrintErrorStack();
	//v2
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_PartStatus", PROP_set_value_string_msg, &methodARDRSts) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_SimVal", PROP_set_value_string_msg, &methodAddOnDes) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_DesignGrp", PROP_set_value_string_msg, &methodDesignGrp) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_DesignMilestoneStatus", PROP_set_value_string_msg, &methodDesignMileStone) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_EE_PartRevision_t5_EE_MatClass", PROP_set_value_string_msg, &methodEEMatCls) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_EE_PartRevision_T5_EEPrm", PROP_set_value_string_msg, &methodEEPrtPara) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_EE_PartRevision_t5_EEPartMilestoneStatus", PROP_set_value_string_msg, &methodEEPrtMileStone) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_EE_PartRevision_t5_EE_PartType", PROP_set_value_string_msg, &methodEEPrtTyp) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_EE_PartRevision_t5_EcuType", PROP_set_value_string_msg, &methodEEEcuTyp) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_CategoryName", PROP_set_value_string_msg, &methodKeyDescClPrt) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design_t5_RevCategoryName", PROP_set_value_string_msg, &methodKeyDescDesign) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_DocRemarks", PROP_set_value_string_msg, &methodModDescDesRev) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_DocRemarks", PROP_set_value_string_msg, &methodModDescClPrt) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_Module", PROP_set_value_string_msg, &methodModule) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_ModuleAddress", PROP_set_value_string_msg, &methodAddr) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_Module_Group", PROP_set_value_string_msg, &methodModGrp) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_ModuleName", PROP_set_value_string_msg, &methodModNme) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_ModuleType", PROP_set_value_string_msg, &methodModTyp) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_Material", PROP_set_value_string_msg, &methodPrtMaterial) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_PartType", PROP_set_value_string_msg, &methodPrtType) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_ProjectCode", PROP_set_value_string_msg, &methodProCode) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_rorev_project_ids", PROP_set_value_string_msg, &methodProIds) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_EE_PartRevision_t5_SwPartType", PROP_set_value_string_msg, &methodSWPrtTyp) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design_t5_uom", PROP_set_value_string_msg, &methodUOMDesign) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_uom", PROP_set_value_tag_msg, &methodUnitofMeasure) !=ITK_ok) PrintErrorStack();

	if ( METHOD_find_prop_method("BOMLine", "bl_rorev_object_desc", PROP_set_value_string_msg, &methodDesc) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_EE_PartRevision_t5_Description", PROP_set_value_string_msg, &methodDescEE) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_DrawingInd", PROP_set_value_string_msg, &methodDrawingInd) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_DrawingInd", PROP_set_value_string_msg, &methodDrawingIndClr) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_DrawingNo", PROP_set_value_string_msg, &methodDrawingNo) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_occ_t5_Location", PROP_set_value_string_msg, &methodLoc) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_occ_t5_MainSerial", PROP_set_value_string_msg, &methodMainSrl) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_occ_t5_Remark", PROP_set_value_string_msg, &methodRemrk) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_rev_t5designgroup", PROP_set_value_string_msg, &methodDesgnGrp) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_occ_t5_WbsID", PROP_set_value_string_msg, &methodDmlNo) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_ColourInd", PROP_set_value_string_msg, &methodColIndClr) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_Coated", PROP_set_value_string_msg, &methodCoated) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_Coated", PROP_set_value_string_msg, &methodCoatedClr) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_Weight", PROP_set_value_string_msg, &methodWtClr) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Mfg0MEEquipmentRevision_mfg0Weight", PROP_set_value_string_msg, &methodWtEE) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_MatlClass", PROP_set_value_string_msg, &methodMatClsClr) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_PrtCatCode", PROP_set_value_string_msg, &methodCompCodeClr) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_RolledupWt", PROP_set_value_string_msg, &methodRolledUpWeight) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_DsgnOwn", PROP_set_value_string_msg, &methodOwnerDesignUnt) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_T5_ClrPartRevision_t5_DsgnOwn", PROP_set_value_string_msg, &methodOwnerDesignUntClr) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_HomologationReqd", PROP_set_value_string_msg, &methodHomoInd) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_CMVRCertificationReqd", PROP_set_value_string_msg, &methodCMVR) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_SurfaceArea", PROP_set_value_string_msg, &methodSurfAra) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_TrackTrace", PROP_set_value_string_msg, &methodTT) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Mfg0MEEquipmentRevision_mfg0Supplier", PROP_set_value_string_msg, &methodSupplierNme) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_TargetWt", PROP_set_value_string_msg, &methodTargetWt) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_Platform", PROP_set_value_string_msg, &methodPlatform) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_BOMCmpl", PROP_set_value_string_msg, &methodBOMCmpl) !=ITK_ok) PrintErrorStack();

	if ( METHOD_find_prop_method("BOMLine", "bl_plmxml_abs_xform", PROP_set_value_string_msg, &methodAbsoluteTMatrix) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_Aggregate", PROP_set_value_string_msg, &methodAggregate) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_AggregateGroup", PROP_set_value_string_msg, &methodAggregateGrp) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_DesignRuleA", PROP_set_value_string_msg, &methodDesignRuleApplicability) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_rorev_owning_user", PROP_set_value_string_msg, &methodOwner) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_DsgnDept", PROP_set_value_string_msg, &methodOwnerDesignDept) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_rorev_owning_project", PROP_set_value_string_msg, &methodOwningProject) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_Design Revision_t5_PartPlatform", PROP_set_value_string_msg, &methodPartPlatform) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_item_uom_tag", PROP_set_value_string_msg, &methodDefaultUOM) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_plmxml_def_occ_xform", PROP_set_value_string_msg, &methodDefaultTmatrix) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_is_occ_suppressed", PROP_set_value_logical_msg, &methodSuppressed) !=ITK_ok) PrintErrorStack();
	//Neha

	//Added by kalpesh(23_aug_2018)
	if ( METHOD_find_method("BOMLine", BOMLine_cut_msg, &method_bl_cut) !=ITK_ok) PrintErrorStack();
	//prince
	if ( METHOD_find_method("BOMWindow", BOMWindow_save_msg, &method31) !=ITK_ok) PrintErrorStack();
	//if ( METHOD_find_method("BOMWindow", BOMWindow_save_msg, &method13) !=ITK_ok) PrintErrorStack(); // Ketan // TZ 1.76
	if ( METHOD_find_method("BOMLine", BOMLine_add_msg, &method13_bl_add) !=ITK_ok) PrintErrorStack(); // Ketan
	if ( METHOD_find_method("BOMLine", BOMLine_add_msg, &amethod13_bl_addrelease) !=ITK_ok) PrintErrorStack(); // Aniket
	if ( METHOD_find_method("BOMLine", BOMLine_cut_msg, &method13_bl_cut) !=ITK_ok) PrintErrorStack(); // Ketan

	if ( METHOD_find_method("T5_EEPrm", GRM_create_msg, &method_para_clause) != ITK_ok) PrintErrorStack();
	if ( METHOD_find_method("T5_EEPrm", TC_save_msg, &method_para_Save) != ITK_ok) PrintErrorStack();
	if ( METHOD_find_method("T5_EPara", TC_save_msg, &method_Ecu_para_Save) != ITK_ok) PrintErrorStack();
	if ( METHOD_find_method("T5_EE_PartRevision", TC_save_msg, &method_ee_part) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_method("T5_PlatformRevision", TC_save_msg, &method_platform_access) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_method("T5_ArchModuleRevision", TC_save_msg, &method_arch_module_access) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_prop_method("BOMLine", "bl_quantity", PROP_set_value_tag_msg, &method_quantity) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_method("T5_CCVCHasECUModule", GRM_create_msg, &method_CCV_ECU) != ITK_ok) PrintErrorStack();
	if ( METHOD_find_method("T5_DuraFitPartRevision", TC_save_msg, &method_durafit) !=ITK_ok) PrintErrorStack();

	//Kirtikumar 10/10/2022
	if ( METHOD_find_method("IMAN_reference", GRM_create_msg, &method_svr_validation) !=ITK_ok) PrintErrorStack();
	//Use this to add validation on BOMWindow Save action
	if ( METHOD_find_method("BOMWindow", BOMWindow_save_msg, &method_bom_windowSave_validation) !=ITK_ok) PrintErrorStack();
	//if ( METHOD_find_method("Design", ITEM_create_msg, &method_ccvc_validation) !=ITK_ok) PrintErrorStack();
	//if ( METHOD_find_method("Design Revision", TC_save_msg, &method_ccvc_validation1) !=ITK_ok) PrintErrorStack();

	if ( METHOD_find_method("T5_EE_PartRevision", ITEM_copy_rev_msg, &method_ee_Part_Revise) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_method(RES_Type, RES_checkout_msg , &method_ee_Part_checkOut) !=ITK_ok) PrintErrorStack();

	if ( METHOD_find_method("BOMWindow", BOMWindow_save_msg, &method_EE_PartContParaBOM_Save_Validation) !=ITK_ok) PrintErrorStack();

	if ( METHOD_find_method(RES_Type, RES_checkout_msg , &method_Module_checkOut) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_method("Design Revision", ITEM_copy_rev_msg, &method_Module_Revise) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_method("Design Revision", TC_save_msg, &method_Keyworddescription) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_method("ImanRelation","IMAN_delete", &method_delete_rel) !=ITK_ok) PrintErrorStack();
	if ( METHOD_find_method("ImanRelation","IMAN_save", &method_add_rel) !=ITK_ok) PrintErrorStack();



	//For EE Part Pre-action validation.aa
	if (method_ee_part.id)
	{
		if( METHOD_add_action(method_ee_part, METHOD_pre_action_type, (METHOD_function_t)save_method_ee_part, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************Method_ee_part not found...!!***************** ");
	}

	//For EE Part Post-action validation.(16_sept19)
	if (method_ee_part.id)
	{
		if( METHOD_add_action(method_ee_part, METHOD_post_action_type, (METHOD_function_t) ee_part_post, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************Method ee_part_post not found...!!***************** "); fflush(stdout);
	}

	//For architecture module access...!!(T5_ArchModuleRevision)(06_may_2019)
	if (method_arch_module_access.id)
	{
		if( METHOD_add_action(method_arch_module_access, METHOD_pre_action_type, (METHOD_function_t)arch_module_access_fun, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************Method_arch_module_access not found...!!***************** ");
	}
	//For Platform revision access...!!(T5_PlatformRevision)
	if (method_platform_access.id)
	{
		if( METHOD_add_action(method_platform_access, METHOD_pre_action_type, (METHOD_function_t)platform_access_fun, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************Method_platform_access not found...!!***************** ");
	}
	//Validation on bomline cut.
	if (method_bl_cut.id)
	{
		if( METHOD_add_action(method_bl_cut, METHOD_pre_action_type, (METHOD_function_t) bomline_cut_method, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************Method_bl_cut not found...!!***************** ");
	}
	//Validation on bomline_quantity update.
	if (method_quantity.id)
	{
		printf("\nInside method_quantity...!! ");
		if( METHOD_add_action(method_quantity, METHOD_pre_action_type, (METHOD_function_t) prop_bl_quantity_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_quantity ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************Method_quantity tag not found...!!***************** ");
	}


	if (methodDR.id)
	{
		printf("\nInside methodDR...!! ");
		if( METHOD_add_action(methodDR, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDR ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDR tag not found...!!***************** ");
	}

	if (methodARDRSts.id)
	{
		printf("\nInside methodARDRSts...!! ");
		if( METHOD_add_action(methodARDRSts, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodARDRSts ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodARDRSts tag not found...!!***************** ");
	}

	if (methodAddOnDes.id)
	{
		printf("\nInside methodAddOnDes...!! ");
		if( METHOD_add_action(methodAddOnDes, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodAddOnDes ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodAddOnDes tag not found...!!***************** ");
	}

	if (methodDesignGrp.id)
	{
		printf("\nInside methodDesignGrp...!! ");
		if( METHOD_add_action(methodDesignGrp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDesignGrp ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDesignGrp tag not found...!!***************** ");
	}

	if (methodDesignMileStone.id)
	{
		printf("\nInside methodDesignMileStone...!! ");
		if( METHOD_add_action(methodDesignMileStone, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDesignMileStone ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDesignMileStone tag not found...!!***************** ");
	}


	if (methodEEMatCls.id)
	{
		printf("\nInside methodEEMatCls...!! ");
		if( METHOD_add_action(methodEEMatCls, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodEEMatCls ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodEEMatCls tag not found...!!***************** ");
	}

	if (methodEEPrtPara.id)
	{
		printf("\nInside methodEEPrtPara...!! ");
		if( METHOD_add_action(methodEEPrtPara, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodEEPrtPara ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodEEPrtPara tag not found...!!***************** ");
	}

	if (methodEEPrtMileStone.id)
	{
		printf("\nInside methodEEPrtMileStone...!! ");
		if( METHOD_add_action(methodEEPrtMileStone, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodEEPrtMileStone ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodEEPrtMileStone tag not found...!!***************** ");
	}

	if (methodEEPrtTyp.id)
	{
		printf("\nInside methodEEPrtTyp...!! ");
		if( METHOD_add_action(methodEEPrtTyp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodEEPrtTyp ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodEEPrtTyp tag not found...!!***************** ");
	}

	if (methodEEEcuTyp.id)
	{
		printf("\nInside methodEEEcuTyp...!! ");
		if( METHOD_add_action(methodEEEcuTyp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodEEEcuTyp ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodEEEcuTyp tag not found...!!***************** ");
	}

	if (methodKeyDescClPrt.id)
	{
		printf("\nInside methodKeyDescClPrt...!! ");
		if( METHOD_add_action(methodKeyDescClPrt, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodKeyDescClPrt ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodKeyDescClPrt tag not found...!!***************** ");
	}

	if (methodKeyDescDesign.id)
	{
		printf("\nInside methodKeyDescDesign...!! ");
		if( METHOD_add_action(methodKeyDescDesign, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodKeyDescDesign ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodKeyDescDesign tag not found...!!***************** ");
	}

	if (methodModDescDesRev.id)
	{
		printf("\nInside methodModDescDesRev...!! ");
		if( METHOD_add_action(methodModDescDesRev, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodModDescDesRev ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodModDescDesRev tag not found...!!***************** ");
	}

	if (methodModDescClPrt.id)
	{
		printf("\nInside methodModDescClPrt...!! ");
		if( METHOD_add_action(methodModDescClPrt, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodModDescClPrt ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodModDescClPrt tag not found...!!***************** ");
	}


	if (methodModule.id)
	{
		printf("\nInside methodModule...!! ");
		if( METHOD_add_action(methodModule, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodModule ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodModule tag not found...!!***************** ");
	}

	if (methodAddr.id)
	{
		printf("\nInside methodAddr...!! ");
		if( METHOD_add_action(methodAddr, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodAddr ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodAddr tag not found...!!***************** ");
	}


	if (methodModGrp.id)
	{
		printf("\nInside methodModGrp...!! ");
		if( METHOD_add_action(methodModGrp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodModGrp ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodModGrp tag not found...!!***************** ");
	}

	if (methodModNme.id)
	{
		printf("\nInside methodModNme...!! ");
		if( METHOD_add_action(methodModNme, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodModNme ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodModNme tag not found...!!***************** ");
	}

	if (methodModTyp.id)
	{
		printf("\nInside methodModTyp...!! ");
		if( METHOD_add_action(methodModTyp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodModTyp ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodModTyp tag not found...!!***************** ");
	}


	if (methodPrtMaterial.id)
	{
		printf("\nInside methodPrtMaterial...!! ");
		if( METHOD_add_action(methodPrtMaterial, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodPrtMaterial ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodPrtMaterial tag not found...!!***************** ");
	}

	if (methodPrtType.id)
	{
		printf("\nInside methodPrtType...!! ");
		if( METHOD_add_action(methodPrtType, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodPrtType ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodPrtType tag not found...!!***************** ");
	}

	if (methodProCode.id)
	{
		printf("\nInside methodProCode...!! ");
		if( METHOD_add_action(methodProCode, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodProCode ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodProCode tag not found...!!***************** ");
	}

	if (methodProIds.id)
	{
		printf("\nInside methodProIds...!! ");
		if( METHOD_add_action(methodProIds, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodProIds ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodProIds tag not found...!!***************** ");
	}


	if (methodSWPrtTyp.id)
	{
		printf("\nInside methodSWPrtTyp...!! ");
		if( METHOD_add_action(methodSWPrtTyp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodSWPrtTyp ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodSWPrtTyp tag not found...!!***************** ");
	}

	if (methodUnitofMeasure.id)
	{
		printf("\nInside methodUnitofMeasure...!! ");
		if( METHOD_add_action(methodUnitofMeasure, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodUnitofMeasure ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodUnitofMeasure tag not found...!!***************** ");
	}


	if (methodUOMDesign.id)
	{
		printf("\nInside methodUOMDesign...!! ");
		if( METHOD_add_action(methodUOMDesign, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodUOMDesign ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodUOMDesign tag not found...!!***************** ");
	}

	if (methodDesc.id)
	{
		printf("\nInside methodDesc...!! ");
		if( METHOD_add_action(methodDesc, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDesc ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDesc tag not found...!!***************** ");
	}

	if (methodDescEE.id)
	{
		printf("\nInside methodDescEE...!! ");
		if( METHOD_add_action(methodDescEE, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDescEE ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDescEE tag not found...!!***************** ");
	}

	if (methodDrawingInd.id)
	{
		printf("\nInside methodDrawingInd...!! ");
		if( METHOD_add_action(methodDrawingInd, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDrawingInd ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDrawingInd tag not found...!!***************** ");
	}

	if (methodDrawingIndClr.id)
	{
		printf("\nInside methodDrawingIndClr...!! ");
		if( METHOD_add_action(methodDrawingIndClr, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDrawingIndClr ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDrawingIndClr tag not found...!!***************** ");
	}

	if (methodDrawingIndClr.id)
	{
		printf("\nInside methodDrawingIndClr...!! ");
		if( METHOD_add_action(methodDrawingIndClr, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDrawingIndClr ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDrawingIndClr tag not found...!!***************** ");
	}

	if (methodDrawingNo.id)
	{
		printf("\nInside methodDrawingNo...!! ");
		if( METHOD_add_action(methodDrawingNo, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDrawingNo ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDrawingNo tag not found...!!***************** ");
	}

	if (methodLoc.id)
	{
		printf("\nInside methodLoc...!! ");
		if( METHOD_add_action(methodLoc, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodLoc ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodLoc tag not found...!!***************** ");
	}

	if (methodMainSrl.id)
	{
		printf("\nInside methodMainSrl...!! ");
		if( METHOD_add_action(methodMainSrl, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_mainsrl_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodMainSrl ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodMainSrl tag not found...!!***************** ");
	}

	if (methodAbsoluteTMatrix.id)
	{
		printf("\nInside methodAbsoluteTMatrix...!! ");
		if( METHOD_add_action(methodAbsoluteTMatrix, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_absoluteTmatrix_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodAbsoluteTMatrix ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodAbsoluteTMatrix tag not found...!!***************** ");
	}

	if (methodDefaultTmatrix.id)
	{
		printf("\nInside methodDefaultTmatrix...!! ");
		if( METHOD_add_action(methodDefaultTmatrix, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_defaultTmatrix_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDefaultTmatrix ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDefaultTmatrix tag not found...!!***************** ");
	}

	if (methodSuppressed.id)
	{
		printf("\nInside methodSuppressed...!! ");
		if( METHOD_add_action(methodSuppressed, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_Suppressed_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodSuppressed ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodSuppressed tag not found...!!***************** ");
	}

	if (methodAggregate.id)
	{
		printf("\nInside methodAggregate...!! ");
		if( METHOD_add_action(methodAggregate, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodAggregate ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodAggregate tag not found...!!***************** ");
	}

	if (methodAggregateGrp.id)
	{
		printf("\nInside methodAggregateGrp...!! ");
		if( METHOD_add_action(methodAggregateGrp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodAggregateGrp ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodAggregateGrp tag not found...!!***************** ");
	}

	if (methodDesignRuleApplicability.id)
	{
		printf("\nInside methodDesignRuleApplicability...!! ");
		if( METHOD_add_action(methodDesignRuleApplicability, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDesignRuleApplicability ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDesignRuleApplicability tag not found...!!***************** ");
	}

	if (methodOwner.id)
	{
		printf("\nInside methodOwner...!! ");
		if( METHOD_add_action(methodOwner, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodOwner ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodOwner tag not found...!!***************** ");
	}

	if (methodOwnerDesignDept.id)
	{
		printf("\nInside methodOwnerDesignDept...!! ");
		if( METHOD_add_action(methodOwnerDesignDept, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodOwnerDesignDept ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodOwnerDesignDept tag not found...!!***************** ");
	}

	if (methodOwningProject.id)
	{
		printf("\nInside methodOwningProject...!! ");
		if( METHOD_add_action(methodOwningProject, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodOwningProject ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodOwningProject tag not found...!!***************** ");
	}

	if (methodPartPlatform.id)
	{
		printf("\nInside methodPartPlatform...!! ");
		if( METHOD_add_action(methodPartPlatform, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodPartPlatform ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodPartPlatform tag not found...!!***************** ");
	}

	if (methodDefaultUOM.id)
	{
		printf("\nInside methodDefaultUOM...!! ");
		if( METHOD_add_action(methodDefaultUOM, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDefaultUOM ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDefaultUOM tag not found...!!***************** ");
	}

	if (methodRemrk.id)
	{
		printf("\nInside methodRemrk...!! ");
		if( METHOD_add_action(methodRemrk, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodRemrk ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodRemrk tag not found...!!***************** ");
	}
	if (methodDesgnGrp.id)
	{
		printf("\nInside methodDesgnGrp...!! ");
		if( METHOD_add_action(methodDesgnGrp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDesgnGrp ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDesgnGrp tag not found...!!***************** ");
	}

	if (methodDmlNo.id)
	{
		printf("\nInside methodDmlNo...!! ");
		if( METHOD_add_action(methodDmlNo, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDmlNo ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDmlNo tag not found...!!***************** ");
	}

	if (methodColIndClr.id)
	{
		printf("\nInside methodColIndClr...!! ");
		if( METHOD_add_action(methodColIndClr, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodColIndClr ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodColIndClr tag not found...!!***************** ");
	}

	if (methodCoated.id)
	{
		printf("\nInside methodCoated...!! ");
		if( METHOD_add_action(methodCoated, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodCoated ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodCoated tag not found...!!***************** ");
	}

	if (methodCoatedClr.id)
	{
		printf("\nInside methodCoatedClr...!! ");
		if( METHOD_add_action(methodCoatedClr, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodCoatedClr ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodCoatedClr tag not found...!!***************** ");
	}

	if (methodWtClr.id)
	{
		printf("\nInside methodWtClr...!! ");
		if( METHOD_add_action(methodWtClr, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodWtClr ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodWtClr tag not found...!!***************** ");
	}

	if (methodWtEE.id)
	{
		printf("\nInside methodWtEE...!! ");
		if( METHOD_add_action(methodWtEE, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodWtEE ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodWtEE tag not found...!!***************** ");
	}

	if (methodWtEE.id)
	{
		printf("\nInside methodWtEE...!! ");
		if( METHOD_add_action(methodWtEE, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodWtEE ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodWtEE tag not found...!!***************** ");
	}

	if (methodMatClsClr.id)
	{
		printf("\nInside methodMatClsClr...!! ");
		if( METHOD_add_action(methodMatClsClr, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodMatClsClr ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodMatClsClr tag not found...!!***************** ");
	}

	if (methodCompCodeClr.id)
	{
		printf("\nInside methodCompCodeClr...!! ");
		if( METHOD_add_action(methodCompCodeClr, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodCompCodeClr ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodCompCodeClr tag not found...!!***************** ");
	}

	if (methodRolledUpWeight.id)
	{
		printf("\nInside methodRolledUpWeight...!! ");
		if( METHOD_add_action(methodRolledUpWeight, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodRolledUpWeight ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodRolledUpWeight tag not found...!!***************** ");
	}

	if (methodOwnerDesignUnt.id)
	{
		printf("\nInside methodOwnerDesignUnt...!! ");
		if( METHOD_add_action(methodOwnerDesignUnt, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodOwnerDesignUnt ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodOwnerDesignUnt tag not found...!!***************** ");
	}
	if (methodOwnerDesignUntClr.id)
	{
		printf("\nInside methodOwnerDesignUntClr...!! ");
		if( METHOD_add_action(methodOwnerDesignUntClr, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodOwnerDesignUntClr ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodOwnerDesignUntClr tag not found...!!***************** ");
	}
	if (methodHomoInd.id)
	{
		printf("\nInside methodHomoInd...!! ");
		if( METHOD_add_action(methodHomoInd, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodHomoInd ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodHomoInd tag not found...!!***************** ");
	}
	if (methodCMVR.id)
	{
		printf("\nInside methodCMVR...!! ");
		if( METHOD_add_action(methodCMVR, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodCMVR ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodCMVR tag not found...!!***************** ");
	}

	if (methodSurfAra.id)
	{
		printf("\nInside methodSurfAra...!! ");
		if( METHOD_add_action(methodSurfAra, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodSurfAra ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodSurfAra tag not found...!!***************** ");
	}
	if (methodTT.id)
	{
		printf("\nInside methodTT...!! ");
		if( METHOD_add_action(methodTT, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodTT ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodTT tag not found...!!***************** ");
	}
	if (methodSupplierNme.id)
	{
		printf("\nInside methodSupplierNme...!! ");
		if( METHOD_add_action(methodSupplierNme, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodSupplierNme ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodSupplierNme tag not found...!!***************** ");
	}

	if (methodTargetWt.id)
	{
		printf("\nInside methodTargetWt...!! ");
		if( METHOD_add_action(methodTargetWt, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodTargetWt ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodTargetWt tag not found...!!***************** ");
	}

	if (methodPlatform.id)
	{
		printf("\nInside methodPlatform...!! ");
		if( METHOD_add_action(methodPlatform, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodPlatform ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodPlatform tag not found...!!***************** ");
	}

	if (methodBOMCmpl.id)
	{
		printf("\nInside methodBOMCmpl...!! ");
		if( METHOD_add_action(methodBOMCmpl, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodBOMCmpl ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodBOMCmpl tag not found...!!***************** ");
	}

	if (methodColInd.id)
	{
		printf("\nInside methodColInd...!! ");
		if( METHOD_add_action(methodColInd, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodColInd ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodColInd tag not found...!!***************** ");
	}

	if (methodCompCode.id)
	{
		printf("\nInside methodCompCode...!! ");
		if( METHOD_add_action(methodCompCode, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodCompCode ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodCompCode tag not found...!!***************** ");
	}

	if (methodEnvDim.id)
	{
		printf("\nInside methodEnvDim...!! ");
		if( METHOD_add_action(methodEnvDim, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodEnvDim ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodEnvDim tag not found...!!***************** ");
	}

	if (methodDesGrp.id)
	{
		printf("\nInside methodDesGrp...!! ");
		if( METHOD_add_action(methodDesGrp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodDesGrp ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodDesGrp tag not found...!!***************** ");
	}

	if (methodSpareCri.id)
	{
		printf("\nInside methodSpareCri...!! ");
		if( METHOD_add_action(methodSpareCri, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodSpareCri ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodSpareCri tag not found...!!***************** ");
	}

	if (methodSpareInd.id)
	{
		printf("\nInside methodSpareInd...!! ");
		if( METHOD_add_action(methodSpareInd, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodSpareInd ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodSpareInd tag not found...!!***************** ");
	}

	if (methodMatCls.id)
	{
		printf("\nInside methodMatCls...!! ");
		if( METHOD_add_action(methodMatCls, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodMatCls ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodMatCls tag not found...!!***************** ");
	}


	if (methodMaterial.id)
	{
		printf("\nInside methodMaterial...!! ");
		if( METHOD_add_action(methodMaterial, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodMaterial ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodMaterial tag not found...!!***************** ");
	}

	if (methodPrtTyp.id)
	{
		printf("\nInside methodPrtTyp...!! ");
		if( METHOD_add_action(methodPrtTyp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodPrtTyp ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodPrtTyp tag not found...!!***************** ");
	}

	if (methodProjCode.id)
	{
		printf("\nInside methodProjCode...!! ");
		if( METHOD_add_action(methodProjCode, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodProjCode ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodProjCode tag not found...!!***************** ");
	}

	if (methodRevPrtTyp.id)
	{
		printf("\nInside methodRevPrtTyp...!! ");
		if( METHOD_add_action(methodRevPrtTyp, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodRevPrtTyp ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodRevPrtTyp tag not found...!!***************** ");
	}

	if (methodWeight.id)
	{
		printf("\nInside methodWeight...!! ");
		if( METHOD_add_action(methodWeight, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodWeight ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodWeight tag not found...!!***************** ");
	}

	if (methodRolledupWt.id)
	{
		printf("\nInside methodRolledupWt...!! ");
		if( METHOD_add_action(methodRolledupWt, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodRolledupWt ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodRolledupWt tag not found...!!***************** ");
	}
	if (methodUom.id)
	{
		printf("\nInside methodUom...!! ");
		if( METHOD_add_action(methodUom, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodUom ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodUom tag not found...!!***************** ");
	}

	if (methodAhdMakeBuyInd.id)
	{
		printf("\nInside methodAhdMakeBuyInd...!! ");
		if( METHOD_add_action(methodAhdMakeBuyInd, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodAhdMakeBuyInd ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodAhdMakeBuyInd tag not found...!!***************** ");
	}

	if (methodCarMakeBuyInd.id)
	{
		printf("\nInside methodCarMakeBuyInd...!! ");
		if( METHOD_add_action(methodCarMakeBuyInd, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodCarMakeBuyInd ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodCarMakeBuyInd tag not found...!!***************** ");
	}

	if (methodPunPCBUMakeBuyInd.id)
	{
		printf("\nInside methodPunPCBUMakeBuyInd...!! ");
		if( METHOD_add_action(methodPunPCBUMakeBuyInd, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodPunPCBUMakeBuyInd ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodPunPCBUMakeBuyInd tag not found...!!***************** ");
	}

	if (methodPunUvMakeBuyInd.id)
	{
		printf("\nInside methodPunUvMakeBuyInd...!! ");
		if( METHOD_add_action(methodPunUvMakeBuyInd, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodPunUvMakeBuyInd ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodPunUvMakeBuyInd tag not found...!!***************** ");
	}

	if (methodKeyDesc.id)
	{
		printf("\nInside methodKeyDesc...!! ");
		if( METHOD_add_action(methodKeyDesc, METHOD_pre_action_type, (METHOD_function_t) prop_bl_method_KeyDesc_check, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodKeyDesc ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodKeyDesc tag not found...!!***************** ");
	}

	//Added by Amar TZ TCUA 1.76
	if(METHOD_find_prop_method("Design Revision", "t5_DesignGrp", PROP_set_value_string_msg/*PROP_UIF_set_value_msg*/, &method_Desgrp)!=ITK_ok) PrintErrorStack();
    if(method_Desgrp.id)
    {
		if(METHOD_add_action(method_Desgrp, METHOD_pre_action_type ,(METHOD_function_t)DesignGroup_Set_pre_action, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
    }
	//End

	//Added by Amar TZ TCUA 1.76
	if(METHOD_find_prop_method("Design Revision", "t5_ProjectCode", PROP_set_value_string_msg/*PROP_UIF_set_value_msg*/, &method_Prjcode)!=ITK_ok) PrintErrorStack();
    if(method_Prjcode.id)
    {
		if(METHOD_add_action(method_Prjcode, METHOD_pre_action_type ,(METHOD_function_t)ProjectCode_Set_pre_action, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
    }
	//End

	//method register and call by Prince
	if (method1.id)
	{
		int ifail = ITK_ok;
		*decision = ALL_CUSTOMIZATIONS;
		//METHOD_id_t  method3;
		ifail = METHOD_find_method("Design Revision", TC_save_msg, &method1);
		printf("\nInside methodKeyDesc...!! ");

		if( METHOD_add_action(method1, METHOD_pre_action_type, (METHOD_function_t) partRestrictUsingMethodRegister, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError methodKeyDesc ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************methodKeyDesc tag not found...!!***************** ");
	}


	//Validation on Parameter part and it's clause.
	if (method_para_clause.id)
	{
		printf("\nInside method_para_clause...!! ");
		if( METHOD_add_pre_condition(method_para_clause, (METHOD_function_t) para_clause_attach_method, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_para_clause ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_para_clause tag not found...!!***************** ");
	}
	//End (kalpesh)

	// prince new condition

	if (method31.id)
	{
		printf("\nprince new method..!! ");
		if( METHOD_add_pre_condition(method31, (METHOD_function_t) bomPropertyNotModified, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_para_clause ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n***************** else prince new method..!!***************** ");
	}

	/////////////////////////////////// Ketan Started ////////////////////
	// new condition
	// if (method13.id)
	// {
	// 	printf("\n Ketan new method..!! ");
	// 	if( METHOD_add_pre_condition(method13, (METHOD_function_t) BOM_Modified_Validation, NULL)!=ITK_ok) PrintErrorStack();
	// 	if( ifail != ITK_ok )
	// 	{
	// 		printf("\nError method_para_clause ");
	// 		EMH_store_error( EMH_severity_error, ifail );
	// 	}
	// }
	// else
	// {
	// 	printf("\n ***************** else Ketan new method..!!*****************  ");
	// }

	// APL/MBOM/STD Validation on bomline Add.

	if (method13_bl_add.id)
	{
		if( METHOD_add_action(method13_bl_add, METHOD_pre_action_type, (METHOD_function_t) tm_nonerc_Validation_add_method, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n ***************** method13_bl_add not found...!!*****************  ");
    }

	if (amethod13_bl_addrelease.id)
	{
		if( METHOD_add_action(amethod13_bl_addrelease, METHOD_pre_action_type, (METHOD_function_t) bom_addition_only_release_pat, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n ***************** amethod13_bl_addrelease not found...!!*****************  ");
    }

	//APL/MBOM/STD Validation on bomline Cut.
	if (method13_bl_cut.id)
	{
		if( METHOD_add_action(method13_bl_cut, METHOD_pre_action_type, (METHOD_function_t) tm_nonerc_Validation_cut_method, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n ***************** method13_bl_cut not found...!!*****************  ");
	}
	/////////////////////////////////// Ketan Ended ////////////////////

	if (method.id)
	{
		if( METHOD_add_action(method, METHOD_pre_action_type, (METHOD_function_t) save_method_3, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	    else
	    {
			printf("\n !!!!!!!!!!!Method not found!!!!!!!!!! ");
	    }

	//TCUA 1.47-Start
	if (method.id)
	{
		if( METHOD_add_action(method, METHOD_post_action_type, (METHOD_function_t) save_method_Design_3, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n !!!!!!!!!!!save_method_Design_3 not found!!!!!!!!!! "); fflush(stdout);
	}
	//TCUA 1.47-End

	if (method1.id)
	{
		if( METHOD_add_action(method1, METHOD_pre_action_type, (METHOD_function_t) save_method_4, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	    else
	    {
			printf("\n !!!!!!!!!!!Method not found!!!!!!!!!! ");
	    }

	if (method1.id)
	{
		if( METHOD_add_action(method1, METHOD_post_action_type, (METHOD_function_t) save_Post_DesRev, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n !!!!!!!!!!!Method not found save_Post_DesRev!!!!!!!!!! ");
	}

	if (method2.id)
	{
		if( METHOD_add_action(method2, METHOD_pre_action_type, (METHOD_function_t) save_method_5, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!Method2 not found!!!!!!!!!! ");
    }

	if (methodSVR.id)
	{
		if( METHOD_add_action(methodSVR, METHOD_pre_action_type, (METHOD_function_t) save_method_SVR, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!! methodSVR not found!!!!!!!!!! ");
    }

	if (methodVendor.id)
	{
		if( METHOD_add_action(methodVendor, METHOD_pre_action_type, (METHOD_function_t) save_method_Vendor, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!! methodVendor not found!!!!!!!!!! ");
    }

	//Pro-E specific Customization to Check-Out Dataset on Create.
	if ( METHOD_find_method("Dataset", AE_create_dataset_msg, &method2) !=ITK_ok) PrintErrorStack();
    if (method2.id)
	{
		printf("\nInside Method 2 ");
		if( METHOD_add_action(method2, METHOD_post_action_type, (METHOD_function_t) save_method_8, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!Method2 for AE_create_dataset_msg Post not found!!!!!!!!!! ");
    }
	//End of Pro-E specific Customization to Check-Out Dataset on Create.

	 if (method3.id)
	{
		if( METHOD_add_action(method3, METHOD_pre_action_type, (METHOD_function_t) save_method_7, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!Method3 not found!!!!!!!!!! ");
    }

	 if (method3.id)
	{
		if( METHOD_add_action(method3, METHOD_post_action_type, (METHOD_function_t) save_method_qty_updt, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!Method3 not found!!!!!!!!!! ");
    }

	/* Adi for CREO  */

	if ( METHOD_find_method("Dataset", AE_save_dataset_msg , &method4) !=ITK_ok) PrintErrorStack();
    if (method4.id)
	{
		//printf("\nInside Method 2 "); fflush(stdout);

		if( METHOD_add_action(method4, METHOD_pre_action_type, (METHOD_function_t) save_method_9, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!Method4 for AE_save_dataset_msg Post not found!!!!!!!!!! ");
    }

	if (methodBOM.id)///upp
	{
		printf("\nInside methodBOM ");
		if( METHOD_add_action(methodBOM, METHOD_post_action_type, (METHOD_function_t) qauntity_handled_as_per_uom, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n methodBOM not found ");
    }

	if (methodVF.id) //Prachi
	{
		printf("\nInside methodVF for vf tag ");
		if( METHOD_add_action(methodVF, METHOD_pre_action_type, (METHOD_function_t) check_vf_module, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\n error  methodVF ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n methodVF tag not found ");
    }


	if (method_durafit.id)
	{
		if( METHOD_add_action(method_durafit, METHOD_pre_action_type, (METHOD_function_t) save_method_durafit, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n !!!!!!!!!!!Method not found!!!!!!!!!! ");
	}

	if (method_para_Save.id)
	{
		if( METHOD_add_action(method_para_Save, METHOD_pre_action_type, (METHOD_function_t)save_method_Para_Rel, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_para_Save not found...!!***************** ");
	}

	if (method_CCV_ECU.id)
	{
		printf("\nInside method_CCV_ECU...!! ");
		if( METHOD_add_pre_condition(method_CCV_ECU, (METHOD_function_t) CCV_ECU_PreCond_Func, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_CCV_ECU ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_CCV_ECU tag not found...!!***************** ");
	}

	if (method_Ecu_para_Save.id)
	{
		printf("\nInside method_Ecu_para_Save...!! ");
		if( METHOD_add_pre_condition(method_Ecu_para_Save, (METHOD_function_t) ECU_Para_PreCond_Func, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_Ecu_para_Save ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_Ecu_para_Save tag not found...!!***************** ");
	}
	// Added by Kirtikumar
	if (method_svr_validation.id)
	{
		printf("\nInside method_svr_validation...!! ");
		if( METHOD_add_pre_condition(method_svr_validation, (METHOD_function_t) SVR_PreCond_Validation_Func, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_svr_validation ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_svr_validation tag not found...!!***************** ");
	}
	//16-03-2023
	 if (method_bom_windowSave_validation.id)
	{
		if( METHOD_add_action(method_bom_windowSave_validation, METHOD_post_action_type, (METHOD_function_t) bom_WindowSave_Validation, NULL)!=ITK_ok) PrintErrorStack();
		//if( METHOD_add_action(method3, METHOD_pre_action_type, (METHOD_function_t) save_method_qty_updt, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!method_bom_windowSave_validation not found!!!!!!!!!! ");
    }
	if (method_ee_Part_Revise.id)
	{
		printf("\nInside method_ee_Part_Revise...!! ");
		if( METHOD_add_action(method_ee_Part_Revise, METHOD_post_action_type, (METHOD_function_t) carryMastSlvRelationOnReviseForEEPartRev, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_ee_Part_Revise ");
			EMH_store_error( EMH_severity_error, ifail );
		}

		// Akshay
		TC_write_syslog("\n Start RmvsoftversionReviseee...!!\n");
		if( METHOD_add_action(method_ee_Part_Revise, METHOD_post_action_type, (METHOD_function_t) RmvsoftversionReviseee, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			TC_write_syslog("\n Error RmvsoftversionReviseee... ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_ee_Part_Revise tag not found...!!***************** ");
	}

	if (method_ee_Part_checkOut.id)
	{
		printf("\nInside method_ee_Part_checkOut...!! ");
		if( METHOD_add_action(method_ee_Part_checkOut, METHOD_post_action_type, (METHOD_function_t) carryMastSlvRelationOnCheckOutForEEPartRev, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_ee_Part_checkOut ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_ee_Part_checkOut tag not found...!!***************** ");
	}
	//11-09-2023
	 if (method_EE_PartContParaBOM_Save_Validation.id)
	{
		if( METHOD_add_action(method_EE_PartContParaBOM_Save_Validation, METHOD_pre_action_type, (METHOD_function_t) eePartContParaBOM_Validation, NULL)!=ITK_ok) PrintErrorStack();
		//if( METHOD_add_action(method3, METHOD_pre_action_type, (METHOD_function_t) save_method_qty_updt, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!method_EE_PartContParaBOM_Save_Validation not found!!!!!!!!!! ");
    }

	//******************Akshay Toke**********
     if (method_Module_checkOut.id)
	{
		printf("\nInside method_Module_checkOut...!! ");
		if( METHOD_add_action(method_Module_checkOut, METHOD_post_action_type, (METHOD_function_t) RemoveIRChecklistOnCheckOutOnModule, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_Module_checkOut ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_Module_checkOut tag not found...!!***************** ");
	}

	if (method_Module_Revise.id)
	{
		printf("\nInside method_Module_Revise...!! ");
		if( METHOD_add_action(method_Module_Revise, METHOD_post_action_type, (METHOD_function_t) RemoveIRChecklistOnReviseOnmoduleRev, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_Module_Revise ");
			EMH_store_error( EMH_severity_error, ifail );
		}
		TC_write_syslog("\n Start Removing carryforwarded report relation...!!\n");
		if( METHOD_add_action(method_Module_Revise, METHOD_post_action_type, (METHOD_function_t) RemoveREPORTOnReviseOnmoduleRev, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			TC_write_syslog("\n Error Removing carryforwarded report relation... ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_Module_Revise tag not found...!!***************** "); fflush(stdout);
	}

	if (method_Keyworddescription.id)
	{
		printf("\nInside method_Keyworddescription...!! "); fflush(stdout);
		if( METHOD_add_action(method_Keyworddescription, METHOD_pre_action_type, (METHOD_function_t) checkforkeyworddescription, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_Keyworddescription "); fflush(stdout);
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_Keyworddescription tag not found...!!***************** ");
	}


    if (method_delete_rel.id)
    {
        ITK_CALL( METHOD_add_action(method_delete_rel, METHOD_pre_action_type, (METHOD_function_t) tm_delete_rel_dataset_method_1, NULL));
        TC_write_syslog("Registered tm_delete_dataset_method_1 as Pre-Action for delete relation of dataset\n");
    }
    else
        TC_write_syslog("tm_delete_dataset_method_1 not found!\n");

	 if (method_add_rel.id)
    {
        ITK_CALL( METHOD_add_action(method_add_rel, METHOD_pre_action_type, (METHOD_function_t) tm_add_rel_dataset_method_1, NULL));
        TC_write_syslog("Registered tm_add_rel_dataset_method_1 as Pre-Action for add relation of dataset\n");

    }
    else
        TC_write_syslog("tm_add_rel_dataset_method_1 not found!\n");


	// Added by Kirtikumar
	/*
	if (method_ccvc_validation1.id)
	{
		printf("\nInside method_ccvc_validation1...!! ");
		//if( METHOD_add_pre_condition(method_ccvc_validation, (METHOD_function_t) CCVC_PreCon_Validation, NULL)!=ITK_ok) PrintErrorStack();
		//if( METHOD_add_action(method_ccvc_validation1, METHOD_post_action_type, (METHOD_function_t) CCVC_PreCon_Validation, NULL)!=ITK_ok) PrintErrorStack();
		if( METHOD_add_action(method_ccvc_validation1, METHOD_pre_action_type, (METHOD_function_t) CCVC_PreAction_Validation, NULL)!=ITK_ok) PrintErrorStack();
		if( ifail != ITK_ok )
		{
			printf("\nError method_ccvc_validation1 ");
			EMH_store_error( EMH_severity_error, ifail );
		}
	}
	else
	{
		printf("\n*****************method_ccvc_validation1 tag not found...!!***************** ");
	}*/
	/* Adi for CREO  */


	//if (method4.id)
	//{
	//	if( METHOD_add_action(method4, METHOD_pre_action_type, (METHOD_function_t) save_method_6, NULL)!=ITK_ok) PrintErrorStack();
	//
	//	if( ifail != ITK_ok )
	//	{
	//			EMH_store_error( EMH_severity_error, ifail );
	//	}
	//}
	//else
	//{
	//	printf("\n !!!!!!!!!!!Method4 not found!!!!!!!!!! ");
	//}

	printf("\n\n CreateDesign.c:it, t8save_design_custom_exit end . ");fflush(stdout);

    return ifail;
}

extern DLLAPI int tm_SaveValidationOnDsgRev_register_callbacks ()
{
     printf("\n \n tm_SaveValidationOnDsgRev.c :::Hello Teamcenter, via Custom User Exit ");fflush(stdout);

      CUSTOM_register_exit ( "tm_SaveValidationOnDsgRev", "USER_init_module", (CUSTOM_EXIT_ftn_t) t8save_design_custom_exit);

      return ( ITK_ok );
}
