				/****************************************************************************************************
				*  File                 :		tm_SaveRelation.c
				*  Created By			:		Yogendra Kumar Mahikwar
				*  Created On			:		23-July-2012
				*  Purpose				:		 Model Indicator and drawing Indicator field should be read only for user. The indicators should be updated on attaching of model or drawing by the system..			
				*								This is called at pre action of save.
				*  Modification History :		Set the Value of Application OwnerD in DataSet based on ProPrt/ProAsm.
												Datatype Selection if ApplicationOwner value in DesignRevision is blank. 
				*  Modification Date    :		22-Oct-2016
				*  Modification  By	    :		Deepti Meshram
				******************************************************************************************************/
				#define _CRT_SECURE_NO_DEPRECATE
				#define NUM_ENTRIES 1
				#define TE_MAXLINELEN  128
				#include <user_exits/user_exits.h>
				#include <ss/ss_const.h>
				#include <ae/ae.h>
				#include <tccore/aom_prop.h>
				#include <epm/epm_errors.h>
				#include <sys/stat.h>
				#include <bom/bom.h>
				#include <bom/bom_msg.h>
				#include <cfm/cfm.h>
				#include <tccore/custom.h>
				#include <ae/dataset.h>
				#include <tccore/grm.h>
				#include <ict/ict_userservice.h>
				//#include <itk/mem.h>
				#include <tccore/method.h>
				#include <ps/ps_errors.h>
				#include <tccore/aom.h>
				#include <res/reservation.h>
				#include <sa/sa.h>
				#include <fclasses/tc_stdarg.h>
				#include <fclasses/tc_stdio.h>
				#include <fclasses/tc_stdlib.h>
				#include <fclasses/tc_string.h>
				//#include <tc/tc.h>
				#include <tc/emh.h>
				#include <fclasses/tc_string.h>
				#include <Fnd0Participant/participant.h>//NP
				#include <fnd0booleansolve/booleansolve.h>//NP 
				#include <ps/vrule.h>//NP 
				#include <epm/signoff.h>//NP
				#include <tccore/item.h>
				#include <tccore/item_errors.h>
				#include <sa/tcfile.h>
				#include <tcinit/tcinit.h>
				#include <tccore/tctype.h>
				#include <fclasses/tc_time.h>
				#include <unidefs.h>
				#include <tccore/workspaceobject.h>
				#include <tccore/item_msg.h>
				#include <tccore/tc_msg.h>
				//#include <tccore/iman_msg.h>
				#include <epm/epm.h>
				#include <ae/dataset_msg.h>
				#include <tccore/grmtype.h>
				#include <pom/pom/pom.h>
				#include <ai/sample_err.h>
				#include <dispatcher/dispatcher_itk.h>
				#include <unistd.h>
				#include <tccore/grm_msg.h>
				#include <pie/pie.h>
				
				#define ITK_errInd (EMH_USER_error_base + 4)
				#define ITK_err 919002
				#define CONNECT_FAIL (EMH_USER_error_base + 2)
				#define PLM_error (EMH_USER_error_base+26)
				#define ITEM_CHECKED_OUT  EMH_USER_error_base + 5
				#define JT_PDF_NOT_FOUND  EMH_USER_error_base + 8
				#define BU_is_ntSame  EMH_USER_error_base + 28
				#define ITEMS_NOTFOUND_INDENT  EMH_USER_error_base+24
				#define DESREV_CONTLIMIT  EMH_USER_error_base+25
				#define Not_Item_Revision  EMH_USER_error_base + 6
				#define Non_PLM_Parts  EMH_USER_error_base + 7
				#define ERCIndQtysetNULL  EMH_USER_error_base + 9
				#define ERIndIR  EMH_USER_error_base + 10
				#define ERCIndReqQtysetNULL  EMH_USER_error_base + 11
				#define ERIndEditProperties  EMH_USER_error_base + 12
				#define IndNameNotMatchError  EMH_USER_error_base + 30
				#define clrRelError (EMH_USER_error_base + 21)
				#define ITK_PLMError (EMH_USER_error_base + 22)
				#define ITK_Error (EMH_USER_error_base + 23)
				#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
				#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
				#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

				int getCntrlObj( char*,int* ,tag_t**);
				char* subString (char* mainStringf ,int fromCharf,int toCharf)
				{
					int i;
					char *retStringf;
					retStringf = (char*) malloc(200);
					for(i=0; i < toCharf; i++ )
							  *(retStringf+i) = *(mainStringf+i+fromCharf);
					*(retStringf+i) = '\0';
					return retStringf;
				}
				static int report_error( char *file, int line, char *function, int return_code)
					{
						if (return_code != ITK_ok)
						{
							char *error_msg_string;

							EMH_ask_error_text (return_code, &error_msg_string);
							printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
							TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
							printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);    
							TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
							if(error_msg_string) MEM_free(error_msg_string);
													
						}
									return return_code;
					}


				int SCMExpationBOM(char *itemRevSeq, tag_t ColSchmRevTag,char *t5itemid,char *t5PrtCatCd1,char *Suffix1);
				int SCMhasClrData(tag_t ColSchmRevTag ,tag_t sClrSVRPart);
				int findSchmValueY(char *itemRevSeq,tag_t ClrSchmTag ,tag_t ColSchmRevTag,tag_t subColSchmRevTag1,char *t5itemid,char *t5PrtCatCd1,char *Suffix1);
				int CompareVehicleLevel(tag_t sClrSVRPart,char *CmpCodeCmp ,char *ColourID, char *ClrScmSerialID);
				int ComparisionClrIdAndCmpCodeWithClrSchm(char *itemRevSeq,tag_t ColSchmRevTag,char *t5itemid,char *sColourID,char *t5PrtCatCd1);
				int Indent_register_action_handlers();
				int Indent_register_rule_handlers();
				int BOMSetCreate(tag_t Topline, tag_t ColSchmRevTag);
				int BOMCorrect(char* Platform,char* SVR,char* RevisionRule,tag_t ColSchmRevTag);

				char	*t5ApplOwnerDValCheck		=	NULL; //Added by Deepti
				logical getIndentRefNo(char *IndentRefNo);
				int getJTPDFItemRev(tag_t DesignRevTag);
				char* GetNextSVRNo(char *IStr);
				char* CreateClrSVRNo(char *InputClrSVRStr, tag_t priObjTag,tag_t secObjTag);
				char* GetPreClrSVRNo(tag_t priObjTag,tag_t secObjTag);
				char *childParts ;
				char *FullAdvString;
				char *FullAdvString1;
				char *FullAdvString2;
				char *sTempItemID;	
				char *sTempItemRev;
				int FlagVC_Vehicle      = 0;
				int findSchmValue(char *itemRevSeq,tag_t ClrSchmTag ,tag_t ColSchmRevTag,char *t5itemid,char *t5PrtCatCd1,char *Suffix1);
				int    ifail   = ITK_ok;

				static int PrintErrorStack( void )
				/*
				*
				* PURPOSE : Function to dump the ITK error stack
				*
				* RETURN : causes program termination. If you made it here
				*          you're not coming back modified for cust.c to not call exit()
				*          but to just print the error stack
				*
				* NOTES : This version will always return ITK_ok, which is quite strange
				*           actually. But if the error reporting was "OK" then that makes
				*           sense
				*
				*/
				{
					int iNumErrs = 0;
					const int *pSevLst = NULL;
					const int *pErrCdeLst = NULL;
					const char **pMsgLst = NULL;
					register int i = 0;

					EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
					fprintf( stderr, "Error(PrintErrorStack): \n");
					for ( i = 0; i < iNumErrs; i++ )
					{
						fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
					}
					return ITK_ok;
				}

				//Check ERC_PLM_SUPPORT group
				int CheckSupportLogin(tag_t SessionUser_tag)
				{
					int     ac    = 0;
					int     Accessflag    = 0;
					int     AccessCount    = 0;
					int     Support_rsltCount    = 0;
					int     Support_n_entry    = 1;
					tag_t	*SupportCntrlObjectTag	= NULLTAG;
					tag_t	SupportqryTag		= NULLTAG;
					char    *Support_qry_entry[1]  = {"SYSCD"};
					char    **Support_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
					char*	 Supportinfo1 = NULL;
					char*	 Supportinfo2 = NULL;
					char*	 AccessFound_name = NULL;
					tag_t	AccessFound_tg = NULLTAG;
					tag_t	*AccessFound = NULLTAG;

					printf("\n L1: CheckSupportLogin...\n");fflush(stdout);
					//GETTING mileston obj.
					if(QRY_find2("ControlObjects", &SupportqryTag));
					if (SupportqryTag)
					{
						printf("\n L2:Found Query SupportqryTag \n");fflush(stdout);
					}
					else
					{
						printf("\n L3:Not Found Query SupportqryTag \n");fflush(stdout);
					}

					Support_qry_values2[0] = "SUPPORT";
					if(QRY_execute(SupportqryTag, Support_n_entry, Support_qry_entry, Support_qry_values2, &Support_rsltCount, &SupportCntrlObjectTag));
					printf(" \n L4:DR_rsltCount :%d:", Support_rsltCount); fflush(stdout);
					if(Support_rsltCount > 0)
					{
						if (AOM_ask_value_string(SupportCntrlObjectTag[0],"t5_Userinfo1",&Supportinfo1)!=ITK_ok)   PrintErrorStack();
						printf("\n L5:Supportinfo1 is : [%s]\n", Supportinfo1);fflush(stdout);

						if (AOM_ask_value_string(SupportCntrlObjectTag[0],"t5_Userinfo2",&Supportinfo2)!=ITK_ok)   PrintErrorStack();
						printf("\n L6:Supportinfo2 is : [%s]\n", Supportinfo2);fflush(stdout);
						if(tc_strstr(Supportinfo1,"CHKLOGINOFF")==NULL)
						{
							//if (SA_find_groupmember_by_user(SessionUser_tag,&Gmcnt,&GmFound)!=ITK_ok)PrintErrorStack();
							if (SA_find_groupmember_by_user(SessionUser_tag,&AccessCount,&AccessFound)!=ITK_ok)PrintErrorStack();
							printf("\n count of AccessCount: [%d]", AccessCount);fflush(stdout);
							for(ac=0;ac<AccessCount;ac++)
							{
								AccessFound_tg = AccessFound[ac];
								if (AOM_ask_value_string(AccessFound_tg,"object_name",&AccessFound_name)!=ITK_ok)   PrintErrorStack();
								//printf("\n Actual Group Member AccessFound_name: [%s]", AccessFound_name);fflush(stdout);
								if((tc_strstr(AccessFound_name,Supportinfo1)!=NULL)|| (tc_strstr(AccessFound_name,Supportinfo2)!=NULL))
								{
									Accessflag++;
									printf("\n AccessFound_name----: [%s][%d]", AccessFound_name,Accessflag);fflush(stdout);
									break;
								}
							}
							if(Accessflag >0)
							{
								printf("\n L7: support access found.\n");fflush(stdout);
								return 1;
							}
							else
							{
								printf("\n L8:support access not found. \n");fflush(stdout);
								return 0;
							}
						}
					}

					return 0;	
				}
					//  ********* Dhiraj ********** //
				extern DLLAPI int Indent_Design_relation(METHOD_message_t *m,va_list args)
				{
					int		error_code				=	ITK_ok;
					int		design_rev_cnt			=	0;
					int		dataset_cnt,i			=	0;
					int		result					=   0;
				//	int		result,count			=   0;
					tag_t	objTag					=	va_arg(args, tag_t);
					tag_t	objTypeTag				=	NULLTAG;
					tag_t	priObjTag				=	NULLTAG;
					tag_t	priObjTypeTag			=	NULLTAG;

					tag_t	secObjTag				=	NULLTAG;
					tag_t	secObjTypeTag			=	NULLTAG;
					tag_t	select_itemrev			=   NULLTAG;
					tag_t	dataset_relation_type	=   NULLTAG;
					tag_t	obj_type				=   NULLTAG;
					tag_t	relation				=   NULLTAG;

					tag_t	*design_rev_tag			=	NULLTAG;
					tag_t	*DatasetList			=	NULLTAG;
				//	tag_t	*secondary_list			=	NULLTAG;

					//char   type_name[TCTYPE_name_size_c+1];
					//char   type_name1[TCTYPE_name_size_c+1];
					//char   type_name2[TCTYPE_name_size_c+1];
					
					char	*designrevName			=	NULL;
					char	*type_name			=	NULL;
					char	*type_name1			=	NULL;
					char	*type_name2			=	NULL;
					char	*designrev				=	NULL;
					char	*chkout_val				=   NULL;
					char	*IndentCategory			=   NULL;
					char	*dataset_typeName		=   NULL;
					char	*data_set_Project		= NULL;
					char	*DesRevProj		= NULL;
					char	*ERCIndQtyset		= NULL;
					char	*ERCIndReqQtyset		= NULL;
					char	*NewPartNum		= NULL;
					
					const char 
						*attrs[1] = {"item_id"},
						*values[1] = {"*"};


					TC_write_syslog("Indent_Design_relation..in save relation...\n");
					
					GRM_find_relation_type("T5ERCDtl", &relation);


					if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
					if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
					TC_write_syslog("relation type_name ::  %s\n", type_name);
					//printf("\nrelation type_name ::  %s\n", type_name);fflush(stdout);
					
					AOM_ask_value_string(objTag,"t5_ERCIndQtySet",&ERCIndQtyset);
					 TC_write_syslog("ERCIndQtyset ::  %s\n", ERCIndQtyset);

					 AOM_ask_value_string(objTag,"t5_ERCIndReqdSet",&ERCIndReqQtyset);
					 TC_write_syslog("ERCIndReqQtyset ::  %s\n", ERCIndReqQtyset);

					

					if (GRM_ask_primary (objTag,&priObjTag)!=ITK_ok);
					if (TCTYPE_ask_object_type(priObjTag,&priObjTypeTag)!=ITK_ok);
					if (TCTYPE_ask_name2(priObjTypeTag,&type_name1)!=ITK_ok);
					TC_write_syslog("primary obj type_name ::  %s\n", type_name1);
					//printf("\nprimary obj type_name ::  %s\n", type_name1);fflush(stdout);

					if (GRM_ask_secondary (objTag,&secObjTag)!=ITK_ok);
					if (TCTYPE_ask_object_type(secObjTag,&secObjTypeTag)!=ITK_ok);
					if (TCTYPE_ask_name2(secObjTypeTag,&type_name2)!=ITK_ok);
					TC_write_syslog("sec obj type_name ::  %s\n", type_name2);
					//printf("\nsec obj type_name ::  %s\n", type_name2);fflush(stdout);
					
					AOM_ask_value_string(secObjTag,"item_id",&NewPartNum);
					printf("\n  NewPartNum[%s]\n", NewPartNum);fflush(stdout);

					
					//// note: below validation of limit to 50 with Indents Has Parts relation is removed as per the request from BOM team @ 01-Mar-2019
					printf("\n starting removal of limit to 50 with Indents Has Parts relation == %s == %s\n", type_name1, type_name2);   fflush(stdout);
					//// Check Design Revision Count with "Indent Has Parts" relation, Max. limit is 40 Design rev can attach only...
				//	if(priObjTag != NULLTAG)
				//	{
				//		if(tc_strcasecmp(type_name1,"T5_ERCIndRevision")==0)
				//		{
				//			GRM_list_secondary_objects_only(priObjTag, relation, &count, &secondary_list);
				//			TC_write_syslog("\nCheck Design Revision Count   :: %d",count);
				//
				//			if(count >= 41 )
				//			{
				//				EMH_store_error_s1(EMH_severity_error,DESREV_CONTLIMIT,"Design Revision count is reached max. limit to 50 with Indents Has Parts relation. Please Create new ERC Indent.");
				//				return DESREV_CONTLIMIT;
				//			}
				//		}
				//	}
				
								int			NoNewPartAddFlag			= 0;
				tag_t           *secondary_list	= NULLTAG;
				int				secObj_count	= 0;
				tag_t           designObj		= NULLTAG;
				int indPrtC=0;
				if(strcmp(type_name1,"T5_ERCIndRevision")==0)
					{
						
						if(relation != NULLTAG)
						{
							ITK_CALL(GRM_list_secondary_objects_only(priObjTag, relation, &secObj_count, &secondary_list));
							for(indPrtC=0; indPrtC<secObj_count; indPrtC++)
							{
								char	*designrevName1		= NULL;
								designObj = secondary_list[indPrtC];
								AOM_ask_value_string(designObj,"item_id",&designrevName1);
								
								printf("\n designrevName1[%s]", designrevName1);fflush(stdout);
								printf("\n NewPartNum[%s]", NewPartNum);fflush(stdout);
								
								if(strcmp(designrevName1,NewPartNum)==0)
								{
									printf("\n NO New part is geting added");fflush(stdout);	
									NoNewPartAddFlag=1;
									break;
								}
							}
						}
					}
					
					int			AddDelIndPrtIndFlg			= 0;
					if(strcmp(type_name1,"T5_ERCIndRevision")==0)
					{
						char		*IndentName		= NULL;
						AOM_ask_value_string(priObjTag,"item_id",&IndentName);
						printf(" Indent number %s\n",IndentName);fflush(stdout);
						
						char		*IndWFStatus		= NULL;
						CALLAPI(AOM_UIF_ask_value(priObjTag,"fnd0StartedWorkflowTasks",&IndWFStatus));
						printf("\n Indent No fnd0StartedWorkflowTasks == [%s]\n", IndWFStatus);fflush(stdout);
						
						char		*IndRelStatus		= NULL;
						CALLAPI(AOM_UIF_ask_value(priObjTag,"release_status_list",&IndRelStatus));
						printf("\n Indent No IndRelStatus == [%s]\n", IndRelStatus);fflush(stdout);

						char*	 username = NULL;
						if(POM_get_user_id (&username)!=ITK_ok)PrintErrorStack();
						
						char *SupportUsername6 = NULL;
						tag_t SessionUser6_tag=NULLTAG;
						int     SupportFlag      =  0;
						
						POM_get_user(&SupportUsername6,&SessionUser6_tag);
						
						printf("\n Login check-6 End......:%s\n",SupportUsername6);fflush(stdout);
						if(SessionUser6_tag!=NULLTAG)
						{
							SupportFlag=0;
							SupportFlag = CheckSupportLogin(SessionUser6_tag);
							printf("\n SupportFlag......: %d",SupportFlag);fflush(stdout);
						}
						printf("\n Login check-6 End......:%s\n",username);fflush(stdout);
						
						tag_t   qryTag     = NULLTAG;
						tag_t   *IndCntrlObjTag      = NULLTAG;
						char   *qry_entry[1]  = {"SYSCD"};
						char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
						if(QRY_find2("ControlObjects", &qryTag));
						
						int n_entry    = 1;
						int  rsltCount      =  0;
						
							if (qryTag)
							{
								printf("\n IndAddDelPart:Found Query ControlObjects \n");fflush(stdout);
							}
							else
							{
								printf("\n IndAddDelPart:Not Found Query ControlObjects \n");fflush(stdout);
							}

							qry_values2[0] = "IndAddDelPart";
							
							if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &IndCntrlObjTag));
							printf(" \n IndAddDelPart:rsltCount 44:%d:", rsltCount); fflush(stdout);
							
						if(rsltCount > 0)
						{
								printf("\n IndWFStatusDup is:: [%s] Indent release status is [%s]",IndWFStatus,IndRelStatus);fflush(stdout);
								
								tag_t   qryTagWF     = NULLTAG;
								tag_t   *IndCntrlObjTagWF      = NULLTAG;
								char   *qry_entryWF[1]  = {"SYSCD"};
								char   **qry_values2WF     =  (char **) MEM_alloc(10 * sizeof(char *));
								if(QRY_find2("ControlObjects", &qryTagWF));

								int n_entryWF    = 1;
								int  rsltCountWF      =  0;

								if (qryTagWF)
								{
									printf("\n IndWFStep:Found Query ControlObjects \n");fflush(stdout);
								}
								else
								{
									printf("\n IndWFStep:Not Found Query ControlObjects \n");fflush(stdout);
								}

								qry_values2WF[0] = "IndWFStep";

								if(QRY_execute(qryTagWF, n_entryWF, qry_entryWF, qry_values2WF, &rsltCountWF, &IndCntrlObjTagWF));
								printf(" \n Indent_Design_relation saveRelation IndWFStep:rsltCountWF 44:%d:", rsltCountWF); fflush(stdout);
								
								if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (tc_strcmp(username,"ercjsup") !=0) && (SupportFlag==0))
								{
									if((tc_strstr(IndRelStatus,"ERC Released")!=NULL) ||(tc_strstr(IndRelStatus,"T5_LcsErcRlzd")!=NULL))
									{
										AddDelIndPrtIndFlg=1;
										printf("\n Indent is released");fflush(stdout);
									 
										EMH_store_error_s2(EMH_severity_error,ITK_err,"Indent is Released.You can not create relation with Indent and Part at this step OR update properties on Relation", IndentName);
										return ITK_err;
									}
									//if((tc_strstr(IndWFStatus,"Manager Review")!=NULL)||(tc_strstr(IndWFStatus,"Chief Eng Review")!=NULL)||(tc_strstr(IndWFStatus,"Proto Ind Review")!=NULL) ||(tc_strstr(IndWFStatus,"New Proto Ind Review 1")!=NULL))
									else if((tc_strstr(IndWFStatus,"Proto Manager Review")!=NULL) ||(tc_strstr(IndWFStatus,"Proto Engineer Review")!=NULL))
									{
										if(NoNewPartAddFlag == 0)
										{
											AddDelIndPrtIndFlg=1;
											printf("\nyou cannot add part in this step");fflush(stdout);
										 
											EMH_store_error_s2(EMH_severity_error,ITK_err,"You can not create relation with Indent and Part at this step.", IndentName);
											return ITK_err;
										}
										else
										{
											printf("\n New Part can be add part in this step in work flow step[%s]",IndWFStatus);fflush(stdout);
										}
									}
									else if(rsltCountWF > 0)
									{
										char		*IndWFStepinfo1		= NULL;
										char		*IndWFStepinfo2		= NULL;
										
										CALLAPI(AOM_ask_value_string(IndCntrlObjTagWF[0],"t5_Userinfo1",&IndWFStepinfo1));
										printf("\n IndWFStepinfo1 is : [%s]\n", IndWFStepinfo1);fflush(stdout);
										
										CALLAPI(AOM_ask_value_string(IndCntrlObjTagWF[0],"t5_Userinfo2",&IndWFStepinfo2));
										printf("\n IndWFStepinfo2 is : [%s]\n", IndWFStepinfo2);fflush(stdout);
										
										if(strcmp(IndWFStatus,"")!=0 || strcmp(IndWFStepinfo1,"")!=0)
										{
											if((tc_strstr(IndWFStatus,IndWFStepinfo1)!=NULL))
											{
												if(NoNewPartAddFlag == 0)
												{
													AddDelIndPrtIndFlg=1;
													printf("\nyou cannot add part in this step");fflush(stdout);
												 
													EMH_store_error_s2(EMH_severity_error,ITK_err,"You can not create relation with Indent and Part at this step.", IndentName);
													return ITK_err;
												}
												else
												{
													printf("\n New Part can be add part in this step in work flow step[%s]",IndWFStatus);fflush(stdout);
												}
											}
										}
										else if(strcmp(IndWFStatus,"")!=0 || strcmp(IndWFStepinfo2,"")!=0)
										{
											if((tc_strstr(IndWFStatus,IndWFStepinfo2)!=NULL))
											{
												if(NoNewPartAddFlag == 0)
												{
													AddDelIndPrtIndFlg=1;
													printf("\nyou cannot add part in this step");fflush(stdout);
												 
													EMH_store_error_s2(EMH_severity_error,ITK_err,"You can not create relation with Indent and Part at this step.", IndentName);
													return ITK_err;
												}
												else
												{
													printf("\n New Part can be add part in this step in work flow step[%s]",IndWFStatus);fflush(stdout);
												}
											}
										}
										else
										{
											printf("\n IndWFStatus[%s],IndWFStepinfo1[%s],IndWFStepinfo2[%s]",IndWFStatus,IndWFStepinfo1,IndWFStepinfo2);fflush(stdout);
										}
									}
									
									else
									{
										printf("\n you Part can be added");fflush(stdout);
									}
								}
								else
								{
									printf("\n super user,Suppoert team bypass %s",username);fflush(stdout);
								}
						}
						else
						{
							printf("\n Control object for add delete not found");fflush(stdout);
						}
					}
					
					if(AddDelIndPrtIndFlg == 0)
					{
						if(strcmp(type_name2,"Design Revision")==0)
						{
							 AOM_ask_value_string(secObjTag,"item_id",&designrevName);
							 TC_write_syslog("designrevName ::  %s\n", designrevName);
							 //printf("\ndesignrevName ::  %s\n", designrevName);fflush(stdout);

							 AOM_ask_value_string(secObjTag,"item_revision_id",&designrev);
							 TC_write_syslog("designrev ::  %s\n", designrev);
							// printf("\ndesignrevName ::  %s\n", designrev);fflush(stdout);

							if(designrevName != NULL && designrev != NULL)
							{
								values[0] = designrevName;
								ITEM_find_item_revs_by_key_attributes(1,attrs, values,designrev,&design_rev_cnt, &design_rev_tag);
								TC_write_syslog("design_rev_cnt ::  %d\n", design_rev_cnt);
								
								if(design_rev_cnt > 0)
								{
									if(design_rev_tag )
									{				
										select_itemrev = design_rev_tag[0];
										AOM_ask_value_string(select_itemrev,"checked_out", &chkout_val);
										TC_write_syslog("chkout_val ::  %s\n", chkout_val);

										if(tc_strcmp(chkout_val,"Y") == 0)
										{					
											EMH_store_error_s2(EMH_severity_error,ITEM_CHECKED_OUT,designrevName,"is checked-out, kindly check-in Design Revision then attach to Indent.");
											return ITEM_CHECKED_OUT;
										}
									}
								}
							}
						}


						if(strcmp(type_name1,"T5_ERCIndRevision")==0)
						{
							AOM_ask_value_string(priObjTag,"t5PrtIndCat",&IndentCategory);
							TC_write_syslog("IndentCategory == %s type_name2 == %s\n", IndentCategory,type_name2);
							printf("IndentCategory == %s type_name2 == %s\n", IndentCategory,type_name2);fflush(stdout);
							//printf("\ndesignrevName ::  %s\n", designrevName);fflush(stdout);
							if (tc_strstr(type_name2,"Revision") == NULL)
							{
								TC_write_syslog("IndentCategory == %s type_name2 == %s\n", IndentCategory,type_name2);
								printf("IndentCategory == %s type_name2 == %s\n", IndentCategory,type_name2);fflush(stdout);
								EMH_store_error_s2(EMH_severity_error,Not_Item_Revision,"You Can attach Only Design Revision to Indent ", designrevName);
								return Not_Item_Revision ;
							}
							if (tc_strcmp(IndentCategory,"PLM Parts with Drawing") == 0 )
							{
								printf("\n PLM Parts with Drawing \n");fflush(stdout);
								TC_write_syslog("PLM Parts with Drawing..");
								GRM_find_relation_type("IMAN_specification",&dataset_relation_type);

								GRM_list_secondary_objects_only(secObjTag,dataset_relation_type,&dataset_cnt,&DatasetList);
								TC_write_syslog("dataset_cnt ::  %d\n", dataset_cnt);

								AOM_ask_value_string(secObjTag,"t5_ProjectCode",&DesRevProj);
								TC_write_syslog("ProjectCode ==  %s\n", DesRevProj);
								printf("\n getJTPDFItemRev ProjectCode==  [%s]\n", DesRevProj);fflush(stdout);
								if (tc_strcmp(DesRevProj,"1111") == 0 )
								{
									printf("\n BY PASS For Project Code == [%s].\n", DesRevProj);fflush(stdout);
								}
								else
								{
									if(dataset_cnt > 0)
									{
										for(i=0;i<dataset_cnt;i++)
										{
											AOM_ask_value_string(DatasetList[i],"object_type",&dataset_typeName);
											TC_write_syslog("dataset_typeName ::  %s\n", dataset_typeName);

											AOM_ask_value_string(secObjTag,"t5_ProjectCode",&data_set_Project);
											TC_write_syslog("ProjectCode ==  %s\n", data_set_Project);
											printf("\n getJTPDFItemRev ProjectCode ::  %s\n", data_set_Project);fflush(stdout);

											if( (tc_strcmp(dataset_typeName,"ProDrw") == 0 || tc_strcmp(dataset_typeName,"CMI2Drawing") == 0))
											{
												/// Calling function to get PDF and JT, from IMAN_rendering relation..
												result = getJTPDFItemRev(secObjTag);					
											}
										}				
										
										TC_write_syslog("result == %d",result);	
										printf("result == %d",result);fflush(stdout);
										if(result == 1)
										{
											//EMH_store_error_s3(EMH_severity_error,ITEM_NOTMATCH,"Please attach ",DmlItemNumber," in Problem items relationship with DCR ");
											EMH_store_error_s3(EMH_severity_error,JT_PDF_NOT_FOUND,"Please attach PDF File to ", designrevName ," in relationship IMAN Rendering..");
											return JT_PDF_NOT_FOUND;
										}
									}
								}
							}
							else if (tc_strcmp(IndentCategory,"Non PLM Parts") == 0)
							{
								printf("\n Non PLM Parts \n");fflush(stdout);
								TC_write_syslog("\n Non PLM Parts \n");
								TC_write_syslog(" Non PLM Parts IndentCategory == %s type_name2 == %s\n", IndentCategory,type_name2);
								printf(" Non PLM Parts IndentCategory == %s type_name2 == %s\n", IndentCategory,type_name2);fflush(stdout);
								//EMH_store_error_s1(EMH_severity_error,Non_PLM_Parts,"You Can not attach the Parts to Non PLM Parts Indent type");
								//return Non_PLM_Parts ;
							}
						}
						
						
						printf(" Now Creating relation with Indent in part has indent relation...\n");fflush(stdout);
						
						tag_t	PartIndrel				=   NULLTAG;
						tag_t  newPartIndrel = NULLTAG;
						char	*IndentName			=	NULL;
						
						AOM_ask_value_string(priObjTag,"item_id",&IndentName);
						
						printf(" Indent number %s\n",IndentName);fflush(stdout);
						
						GRM_find_relation_type("T5_PartHasIndent", &PartIndrel);
						
						AOM_ask_value_string(secObjTag,"item_id",&designrevName);
						printf(" designrevName %s\n",designrevName);fflush(stdout);
						
						AOM_ask_value_string(secObjTag,"item_revision_id",&designrev);
						printf(" designrev %s\n",designrev);fflush(stdout);

						if(PartIndrel != NULLTAG)
								{
									if (secObjTag != NULLTAG && priObjTag != NULLTAG)
									{
										(GRM_create_relation(secObjTag,priObjTag,PartIndrel,NULLTAG,&newPartIndrel));
										if(newPartIndrel != NULLTAG)
										{
										(GRM_save_relation(newPartIndrel));
										printf(" Relation created with Indent in part has indent relation");fflush(stdout);
										}
									}
									else
									{
										printf(" Indent number or design rev is null");fflush(stdout);
									}
								}
								
						printf(" EXIT Indent_Design_relation..in save relation...\n");fflush(stdout);
				}
					
					
					MEM_free(DatasetList);
					return error_code;
				}


				int getJTPDFItemRev(tag_t DesignRevTag )
				{
					int			n_attchs,i		= 0;
					int			ref_count_d		= 0;
					int			result			= 1;
					int			ifail				=	ITK_ok;
					tag_t		ref_type		= NULLTAG;
					tag_t		objTag			= NULLTAG;
					tag_t		objTypeTag			= NULLTAG;
					tag_t*    secondary_list	 = NULLTAG;	
					tag_t*		namRefObject_d	= NULLTAG;
					char*		type_name		= NULL;
					
					
					if(GRM_find_relation_type("IMAN_Rendering",&ref_type)!= ITK_ok);
					if(GRM_list_secondary_objects_only(DesignRevTag,ref_type,&n_attchs,&secondary_list) != ITK_ok);
					TC_write_syslog("Total n attches ::  %d\n", n_attchs);
					
					for (i= 0; i < n_attchs; i++)
					{
						 printf("\n getJTPDFItemRev \n");fflush(stdout);
						 TC_write_syslog("getJTPDFItemRev\n");
						objTag = secondary_list[i];

						AOM_ask_value_string(objTag,"object_type",&type_name);
						TC_write_syslog("type_name ::  %s\n", type_name);
					
						if(tc_strcmp(type_name,"PDF") ==0) 
						{
							AE_ask_dataset_named_refs(objTag,&ref_count_d, &namRefObject_d);
							TC_write_syslog("ref_count_d Count ::  %d\n", ref_count_d);

							if(ref_count_d > 0)
								result = 0;
						} 
						
					}
					
					MEM_free(namRefObject_d);
					MEM_free(secondary_list);

					return result;
				}
				extern DLLAPI int  Restrict_JT_attchtouser(METHOD_message_t *msg, va_list args)
				{
					tag_t	query1	= NULLTAG;
					int	 n_entries1	= 1;
					int	n_found1	= 0;
					char    *qry_entries1[1]	=	{"SYSCD"};
					char    **qry_values1    =  (char **) MEM_alloc(10 * sizeof(char *));	
					tag_t   *CntrlObject_Tag1			= NULLTAG;
					char* sUsrInfo1 = NULL;
					char* username2 = NULL;
					
					QRY_find2("Control Objects...",&query1);
					qry_values1[0] = "JTRestrictionCntrlObj" ;
					QRY_execute(query1, n_entries1, qry_entries1, qry_values1, &n_found1, &CntrlObject_Tag1);
					printf("\n\tControl Object JTRestrictionCntrlObj count found  %d\n",n_found1);
					if(n_found1>0)
					{				
						AOM_ask_value_string(CntrlObject_Tag1[0],"t5_Userinfo1",&sUsrInfo1);
						AOM_ask_value_string(CntrlObject_Tag1[0],"t5_Userinfo2",&username2);
						printf("\n\t Control Object value   %s %s\n",sUsrInfo1,username2);
					}
					if (tc_strcmp(sUsrInfo1,"JTCadRestON")==0)
					{
						char* user_id = NULL;
						char * group_string=NULL;
						char* groupname = NULL;
						char* rolename = NULL;
						char* type_name1 = NULL;
						char* type_name2 = NULL;
						//char* Pri_ObjNmae1 = NULL;
						char* D_typeName = NULL;
						char* PrObjTypeTagRelStus = NULL;
						char* Reltype_name = NULL;
						char* Crnt_id = NULL;
						char* SecObjid = NULL;

						tag_t group_tag=NULLTAG;
						tag_t role_tag=NULLTAG;

						tag_t	RelobjTypeTag				=	NULLTAG;
						tag_t	priObjTypeTag1				=	NULLTAG;
						tag_t	secObjTypeTag1				=	NULLTAG;
						tag_t	*DatasetList					=	NULLTAG;
						tag_t	DatasetTypeTag					=	NULLTAG;
						tag_t	RelType					=	NULLTAG;

						tag_t	primary_object1				=	va_arg(args, tag_t);
						tag_t	secondary_object1			=	va_arg(args, tag_t);
						tag_t	relation_type1				=	va_arg(args, tag_t);

						int DatasetCnt,i =0;

						if (POM_get_user_id(&user_id)!=ITK_ok);
						CALLAPI(POM_ask_group(&group_string,&group_tag));
						CALLAPI(SA_ask_group_name2(group_tag,&groupname));
						CALLAPI(SA_ask_current_role(&role_tag));
						CALLAPI(SA_ask_role_name2(role_tag,&rolename));
						printf("\n JTAttchValid Login user groupname ::  %s\n",groupname);fflush(stdout);
						printf("\n JTAttchValid Login user Rolename  ::  %s\n",rolename);fflush(stdout);

						printf("\n Inside Restrict_JT_attchtouser curent login user is ==> [ %s ] \n",user_id);fflush(stdout);

						if (TCTYPE_ask_object_type(primary_object1,&priObjTypeTag1)!=ITK_ok);
						if (TCTYPE_ask_name2(priObjTypeTag1,&type_name1)!=ITK_ok);
						printf("\n\t Pri obj type name is :%s  \n", type_name1);fflush(stdout);
						if(tc_strcmp(type_name1,"Design Revision")==0)
						{

							if(tc_strstr(user_id,username2)!=NULL||  tc_strcmp(groupname,"PLM_Support_Group")==0 || tc_strcmp(rolename,"Translation_Support")==0 || tc_strcmp(groupname,"dba")==0)// Add Translation support group
							{ 
							  

								printf("\n Copy/paste Allowing for dba and support role to Copy the JT pdf.....   \n");fflush(stdout);

							
							  
							}
							else
							{
								if (TCTYPE_ask_name2(relation_type1,&Reltype_name)!=ITK_ok);
								printf("\n\t RelType name is :%s\n", Reltype_name);fflush(stdout);

								
							
								//if (AOM_UIF_ask_value(priObjTypeTag1,"object_name",&Pri_ObjNmae1)!=ITK_ok);

								
									if (TCTYPE_ask_object_type(secondary_object1,&secObjTypeTag1)!=ITK_ok);
									if (TCTYPE_ask_name2(secObjTypeTag1,&type_name2)!=ITK_ok);
									printf("\n\t type_name2 count  :%s\n", type_name2);fflush(stdout);

									ITK_CALL(AOM_UIF_ask_value(primary_object1,"release_status_list",&PrObjTypeTagRelStus));
									 printf("\n Design Revision status  *************** %s",PrObjTypeTagRelStus);fflush(stdout);
									 if (tc_strcmp(type_name2,"DirectModel")==0 || tc_strcmp(type_name2,"PDF")==0/*&& tc_strcmp(Reltype_name,"IMAN_Rendering")==0 || tc_strcmp(Reltype_name,"IMAN_specification")==0*/)
									 {
										 if ((tc_strstr(PrObjTypeTagRelStus,"ERC Released")!=NULL) || (tc_strstr(PrObjTypeTagRelStus,"T5_LcsErcRlzd")!=NULL ))
										 {
												 printf("\n\t Part in release state  \n");fflush(stdout);
												 EMH_store_error_s2(EMH_severity_error,PLM_error,"Manually JT/PDF attachment is not allowed","Part in release state.");
												 return(PLM_error);										
										 }
										else
										{
											  printf("\n Inside condition Design Revision status  *************** %s",PrObjTypeTagRelStus);fflush(stdout);

												if (tc_strstr(PrObjTypeTagRelStus,"ERC Working")!= NULL || tc_strstr(PrObjTypeTagRelStus,"ERC Review")!=NULL || tc_strstr(PrObjTypeTagRelStus,"T5_LcsWorking")!= NULL || tc_strstr(PrObjTypeTagRelStus,"T5_LcsReview")!=NULL )
												{
													 if (AOM_UIF_ask_value(primary_object1,"current_id",&Crnt_id)!=ITK_ok);
													 if (AOM_UIF_ask_value(secondary_object1,"current_name",&SecObjid)!=ITK_ok);

													 printf("\n\t Primamy object id[%s] secondary object id[%s] =\n", Crnt_id,SecObjid);fflush(stdout);
													 if (tc_strstr(Crnt_id,SecObjid)!= NULL)
													 {
														 if (GRM_find_relation_type("IMAN_specification",&RelType)!=ITK_ok);

														if (GRM_list_secondary_objects_only(primary_object1,RelType,&DatasetCnt,&DatasetList)!=ITK_ok);
														printf("\n\t dataset count  :%d\n", DatasetCnt);fflush(stdout);
														

														if (DatasetCnt>0)
														{
															for(i=0;i<DatasetCnt;i++)
															{
																if (TCTYPE_ask_object_type(DatasetList[i],&DatasetTypeTag)!=ITK_ok);
																if (TCTYPE_ask_name2(DatasetTypeTag,&D_typeName)!=ITK_ok);	
																//if (tc_strcmp(type_name2,"DirectModel")==0 /*&& tc_strcmp(Reltype_name,"IMAN_Rendering")==0 || tc_strcmp(Reltype_name,"IMAN_specification")==0*/)
																//{
																	if(tc_strcmp(D_typeName,"ProAsm")==0 || tc_strcmp(D_typeName,"ProDrw")==0 || tc_strcmp(D_typeName,"ProPrt")==0 || tc_strcmp(D_typeName,"CMI2Product")==0 || tc_strcmp(D_typeName,"CMI2Part")==0 || tc_strcmp(D_typeName,"CMI2Process")==0 || tc_strcmp(D_typeName,"CMI2Drawing")==0 || tc_strcmp(D_typeName,"CMI2DesignTable")==0 || tc_strcmp(D_typeName,"CMI2AuxPart")==0 )
																	{
																			printf("\n\t CAD dataset is present  \n");fflush(stdout);
																			EMH_store_error_s2(EMH_severity_error,PLM_error,"Manually JT/PDF attachment is not allowed","JT/PDF will create through tessellation process only.");
																			return(PLM_error);

																	}
																//}

																

															}
														}
													 }

														
												}
										 }
										 
									}
									 

									

									
							}

						}
					}
					else
					{
						printf("\n\t Control Object is OFF  \n");fflush(stdout);

					}
					return 0;

				}


				int Indent_Reviewers_assign(EPM_action_message_t msg )
				{
					int ifail = ITK_ok;

					int			count, att_count,strlen = 0;
					int			member_count,mem_count		= 0;
					int			member_count1, rp_count		= 0;
					tag_t		rootTask_t			= NULLTAG;
					tag_t*		attachments			= NULLTAG;
					tag_t*		ChfEng_Members	    = NULLTAG;
					tag_t*		FunEng_Members	    = NULLTAG;
					tag_t*		Proto_Members	    = NULLTAG;
					tag_t*		members			    = NULLTAG;
					tag_t*		rps				    = NULLTAG;

					tag_t		Chf_user_tag	    = NULLTAG;
					tag_t		Proto_user_tag	    = NULLTAG;
					tag_t		Mgr_user_tag	    = NULLTAG;
					tag_t		Mgr_Type_tag	    = NULLTAG;
					tag_t		ChfEng_Type_tag	    = NULLTAG;
					tag_t		Mgr_participant	    = NULLTAG;
					tag_t		ChfEng_participant  = NULLTAG;
					tag_t		Grp_tag				= NULLTAG;
					tag_t		role_tag		    = NULLTAG;
					tag_t		Func_role_tag		    = NULLTAG;
					tag_t		objTag				=  NULLTAG;
					tag_t		BU_Grp_tag				=  NULLTAG;
					tag_t		BU_role_tag				=  NULLTAG;
					tag_t		proto_Type_tag				=  NULLTAG;
					tag_t		proto_participant				=  NULLTAG;
					
					char*		obj_type			= NULL;
					char*		IndentChfEng		= NULL;
					char*		IndentNo		= NULL;
					char*		IndentApprover		= NULL;
					char*		tempChfEng			= NULL;
					char		*groupName			= NULL;
					char		*RoleName			= NULL;
					char		*FunctionalRoleName	= NULL;
					char		*user_id			= NULL;
					char		*type_name			= NULL;
					char		*IndentRoleName		= NULL;
					char		*IndentGrpName		= NULL;
					char		*ERCBU				= NULL;
					char		*PowerTrainInd		= NULL;
					char		*t5PlatForm		= NULL;
					char		*ERCIndentee		= NULL;

					char		ChfEngRev[20]			= {'\0'};
					char		tempChfEngRev[20]		= {'\0'};

					printf("\n Inside Indent_Reviewers_assign\n");fflush(stdout);


					groupName = (char	*)MEM_alloc(100);
					tc_strcpy(groupName,"ERC_Designers_Group");
					printf("\n MT: groupName  --> %s\n",groupName);   fflush(stdout);

					RoleName = (char	*)MEM_alloc(100);
					tc_strcpy(RoleName,"Chf_Eng_Role");
					printf("\n MT: RoleName  --> %s\n",RoleName);   fflush(stdout);

					IndentGrpName = (char	*)MEM_alloc(100);
					tc_strcpy(IndentGrpName,"Indent_Participants_Group");
					printf("\n MT: IndentGrpName  --> %s\n",IndentGrpName);   fflush(stdout);

					FunctionalRoleName = (char	*)MEM_alloc(100);
					tc_strcpy(FunctionalRoleName,"Functional_Head_Grp");
					printf("\n MT: Functional RoleName  --> %s\n",FunctionalRoleName);   fflush(stdout);

					IndentRoleName = (char	*)MEM_alloc(100);
					

					EPM_ask_root_task(msg.task,&rootTask_t);
					EPM_ask_attachments(rootTask_t, EPM_target_attachment, &count, &attachments);

					if(count>0)
					{
						objTag = attachments[0];
					}
						
					if(count > 0)
					{
						for(att_count=0; att_count<count; att_count++)
						{
							WSOM_ask_object_type2(objTag, &obj_type);
							TC_write_syslog("Object Type = %s\n",obj_type);

							if(tc_strcmp(obj_type,"T5_ERCIndRevision") == 0)
							{
								AOM_UIF_ask_value(objTag, "item_id", &IndentNo);
								printf("\n Indent No item_id == [%s]\n", IndentNo);fflush(stdout);

								AOM_ask_value_string(objTag,"t5PrtIndChfEng",&IndentChfEng);
								TC_write_syslog("IndentChfEng ::  %s\n", IndentChfEng);
								printf("IndentChfEng ::  %s\n", IndentChfEng);fflush(stdout);

								AOM_ask_value_string(objTag,"t5PrtIndApprov",&IndentApprover);
								TC_write_syslog("IndentApprover ::  %s\n", IndentApprover);
								printf("IndentApprover ::  %s\n", IndentApprover);fflush(stdout);
								
								AOM_ask_value_string(objTag,"t5ERCIndBU",&ERCBU);
								TC_write_syslog("ERCBU ::  %s\n", ERCBU);
								printf("ERCBU ::  %s\n", ERCBU);fflush(stdout);

								AOM_ask_value_string(objTag,"t5IndChkPRD",&PowerTrainInd);
								TC_write_syslog("PowerTrainInd ::  %s\n", PowerTrainInd);
								printf("PowerTrainInd ::  %s\n", PowerTrainInd);
								
								AOM_ask_value_string(objTag,"t5_IndPlatform",&t5PlatForm);
								TC_write_syslog("t5PlatForm ::  %s\n", t5PlatForm);
								printf("t5PlatForm ::  %s\n", t5PlatForm);
								
								AOM_ask_value_string(objTag,"t5ERCIndentee",&ERCIndentee);
								TC_write_syslog("ERCIndentee ::  %s\n", ERCIndentee);
								printf("ERCIndentee ::  %s\n", ERCIndentee);
								
								tag_t	HomeSiteNameQry		= NULLTAG;
								char    *SiteName_qry_entry[1]  = {"SYSCD"};
								char    **SiteName_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
								int     SiteNm_rsltCount    = 0;
								tag_t	*SiteNameCntrlObjectTag	= NULLTAG;
								int     SiteName_n_entry    = 1;
								char*	 SiteNameinfo1 = NULL;
								char*	 SiteNameinfo2IndName = NULL;
								char*	 info3PltFormLive = NULL;
								
								if(QRY_find2("ControlObjects", &HomeSiteNameQry));
								if (HomeSiteNameQry)
								{
									printf("\n Found Query HomeSiteNameQry.");fflush(stdout);
								}
								else
								{
									printf("\n Not Found Query HomeSiteNameQry.");fflush(stdout);
								}

								SiteName_qry_values2[0] = "SiteNameDeatils";
								if(QRY_execute(HomeSiteNameQry, SiteName_n_entry, SiteName_qry_entry, SiteName_qry_values2, &SiteNm_rsltCount, &SiteNameCntrlObjectTag));
								printf(" \n SiteNm_rsltCount :%d:", SiteNm_rsltCount); fflush(stdout);
								if(SiteNm_rsltCount > 0)
								{
									if (AOM_ask_value_string(SiteNameCntrlObjectTag[0],"t5_Userinfo1",&SiteNameinfo1)!=ITK_ok);
									printf("\n :SiteNameinfo1 is : [%s]", SiteNameinfo1);fflush(stdout);
									
									if (AOM_ask_value_string(SiteNameCntrlObjectTag[0],"t5_Userinfo2",&SiteNameinfo2IndName)!=ITK_ok);
									printf("\n :SiteNameinfo2IndName is : [%s]", SiteNameinfo2IndName);fflush(stdout);
									
									if (AOM_ask_value_string(SiteNameCntrlObjectTag[0],"t5_Userinfo3",&info3PltFormLive)!=ITK_ok);
									printf("\n :info3PltFormLive is : [%s]", info3PltFormLive);fflush(stdout);
									
									if(tc_strcmp(info3PltFormLive,"IndentPlatFormLive")==0)
									{
										if(tc_strcmp(PowerTrainInd,"Y") == 0)
										{
											if(tc_strcmp(ERCIndentee,"Proto Planning") == 0)
											{
											tc_strcpy(IndentRoleName,"");
											tc_strcpy(IndentRoleName,"PRD_Prt_Ind_Planning_Grp");
											printf("\n PowerTrainInd and ERCIndentee are: [%s][%s]",PowerTrainInd, ERCIndentee);fflush(stdout);
											}
											
											else if(tc_strcmp(ERCIndentee,"LKO Proto Planning") == 0)
											{
											tc_strcpy(IndentRoleName,"");
											tc_strcpy(IndentRoleName,"LKO_Prt_Ind_Planning_Grp");
											printf("\n PowerTrainInd and ERCIndentee are: [%s][%s]",PowerTrainInd, ERCIndentee);fflush(stdout);
											}
											
											else if(tc_strcmp(ERCIndentee,"JSR Proto Planning") == 0)
											{
											tc_strcpy(IndentRoleName,"");
											tc_strcpy(IndentRoleName,"JSR_Prt_Ind_Planning_Grp");
											printf("\n PowerTrainInd and ERCIndentee are: [%s][%s]",PowerTrainInd, ERCIndentee);fflush(stdout);
											}
										}
										else if(tc_strcmp(ERCBU,"CVBU") == 0 && tc_strcmp(PowerTrainInd,"N") == 0)
										{
											if(tc_strcmp(t5PlatForm,NULL)!=0 || tc_strcmp(t5PlatForm,"")!=0)
											{
												printf("\n IN CVBU :t5PlatForm is : [%s]", t5PlatForm);fflush(stdout);
												
												if(tc_strcmp(ERCIndentee,"Proto Planning") == 0)
												{
												
												tc_strcpy(IndentRoleName,"");
												tc_strcat(IndentRoleName,t5PlatForm);
												tc_strcat(IndentRoleName,"_Prt_Ind_Planning_Grp");
												
												printf("\n :111111IndentRoleName is : [%s]", IndentRoleName);fflush(stdout);
												}
												
												//tc_strcpy(IndentRoleName,"");
												//tc_strcat(IndentRoleName,t5PlatForm);
												//tc_strcat(IndentRoleName,"_Prt_Ind_Planning_Grp");
												
												//printf("\n :IndentRoleName is : [%s]", IndentRoleName);fflush(stdout);
												
												else if(tc_strcmp(ERCIndentee,"LKO Proto Planning") == 0)
												{
													tc_strcpy(IndentRoleName,"");
													tc_strcat(IndentRoleName,"LKO_Prt_Ind_Planning_Grp");
													
													printf("\n 11111Under LKO Proto Planning :IndentRoleName is : [%s]", IndentRoleName);fflush(stdout);
												}
												else if(tc_strcmp(ERCIndentee,"JSR Proto Planning") == 0)
												{
													tc_strcpy(IndentRoleName,"");
													tc_strcat(IndentRoleName,"JSR_Prt_Ind_Planning_Grp");
													
													printf("\n 111111Under JSR Proto Planning :IndentRoleName is : [%s]", IndentRoleName);fflush(stdout);
												}
											}
											
											else
											{
												printf("\n IN CVBU indent Platform is null :");fflush(stdout);
												tc_strcpy(IndentRoleName,"");
												tc_strcpy(IndentRoleName,"CVBU_Prt_Ind_Planning_Grp");
											}
											
											
										}
										else if(tc_strcmp(ERCBU,"PVBU") == 0 && tc_strcmp(PowerTrainInd,"N") == 0) 
										{
											if(tc_strcmp(t5PlatForm,NULL)!=0 || tc_strcmp(t5PlatForm,"")!=0)
											{
												printf("\n :t5PlatForm is : [%s]", t5PlatForm);fflush(stdout);
												
												tc_strcpy(IndentRoleName,"");
												tc_strcat(IndentRoleName,t5PlatForm);
												tc_strcat(IndentRoleName,"_Prt_Ind_Planning_Grp");
												
												printf("\n :IndentRoleName is : [%s]", IndentRoleName);fflush(stdout);
											}
											else
											{
												printf("\n indent Platform is null : [%s]", t5PlatForm);fflush(stdout);
												tc_strcpy(IndentRoleName,"");
												tc_strcpy(IndentRoleName,"PCBU_Prt_Ind_Planning_Grp");
											}
										}
									}
									else
									{
										printf("\n indent plantform is not live info3PltFormLive is : [%s]", info3PltFormLive);fflush(stdout);
										printf(" \n contorl object not found SiteNm_rsltCount :%d:", SiteNm_rsltCount); fflush(stdout);
										printf(" \n ERCBU :[%s] ERCIndentee [%s]:", ERCBU,ERCIndentee); fflush(stdout);
										if(tc_strcmp(ERCBU,"CVBU") == 0 && tc_strcmp(ERCIndentee,"LKO Proto Planning") == 0)
										{
											tc_strcpy(IndentRoleName,"LKO_Prt_Ind_Planning_Grp");
										}
										else if(tc_strcmp(ERCBU,"CVBU") == 0 && tc_strcmp(ERCIndentee,"JSR Proto Planning") == 0)
										{	
											tc_strcpy(IndentRoleName,"JSR_Prt_Ind_Planning_Grp");										
										}
										else if(tc_strcmp(PowerTrainInd,"Y") == 0)
										{
											tc_strcpy(IndentRoleName,"PRD_Prt_Ind_Planning_Grp");
										}
										else if(tc_strcmp(ERCBU,"CVBU") == 0 && tc_strcmp(PowerTrainInd,"N") == 0)
										{
											tc_strcpy(IndentRoleName,"CVBU_Prt_Ind_Planning_Grp");
										}
										else if(tc_strcmp(ERCBU,"PVBU") == 0 && tc_strcmp(PowerTrainInd,"N") == 0) 
										{
											tc_strcpy(IndentRoleName,"PCBU_Prt_Ind_Planning_Grp");
										}

										TC_write_syslog("ERCBU  :: %s  ,  IndentRoleName ::  %s\n", ERCBU, IndentRoleName);
										printf("\n ERCBU  :: [%s]  ,  IndentRoleName ::  [%s]", ERCBU, IndentRoleName);fflush(stdout);
									}

								}

								if(IndentChfEng != NULL && IndentApprover != NULL)
								{
									
									if(SA_find_group(groupName, &Grp_tag)!=ITK_ok);
												
									/// Assignning Manager Review
									member_count = 0;
									if(SA_find_role2(FunctionalRoleName,&Func_role_tag)!=ITK_ok);
									if(SA_find_groupmember_by_role(Func_role_tag,Grp_tag,&member_count,&FunEng_Members)!=ITK_ok);
									TC_write_syslog("FunEng_Members member_count fun::  %d\n", member_count);
									printf("FunEng_Members member_count fun::  %d\n", member_count);fflush(stdout);

									if(member_count > 0)
									{
										for(mem_count=0; mem_count<member_count; mem_count++)
										{
											if(SA_ask_groupmember_user(FunEng_Members[mem_count], &Mgr_user_tag)!=ITK_ok);							
											
											if((POM_ask_user_id(Mgr_user_tag, &user_id))!=ITK_ok);
											TC_write_syslog("user_id  ::  %s\n", user_id);
											printf("user_id  ::  %s\n", user_id);fflush(stdout);
											if(tc_strstr(IndentApprover, user_id) != NULL)
											{		
												TC_write_syslog("T5_IndMngrReviw ............. \n");
												printf("T5_IndMngrReviw ............. \n");fflush(stdout);
												TC_write_syslog(" Func user_id  ::  %s\n", user_id);
												printf(" Func user_id  ::  %s\n", user_id);fflush(stdout);
												if(EPM_get_participanttype ("T5_IndMngrReviw",&Mgr_Type_tag)!=ITK_ok);
												if(EPM_create_participant(FunEng_Members[mem_count],Mgr_Type_tag,&Mgr_participant)!=ITK_ok)
												//AOM_unlock(objTag);
												//AOM_refresh(objTag,TRUE);
												//AOM_unlock(Mgr_participant);
												//AOM_refresh(Mgr_participant,TRUE);
												//AOM_lock(objTag);	 PrintErrorStack();
												//if(PARTICIPANT_add_participant(objTag,Mgr_participant)!=ITK_ok);
												//AOM_save_without_extensions(objTag); PrintErrorStack();
												//AOM_unlock(objTag); PrintErrorStack();
												//AOM_unlock(FunEng_Members[mem_count]);
												//AOM_refresh(FunEng_Members[mem_count],TRUE);
												
												AOM_refresh( objTag, TRUE);
												PARTICIPANT_add_participant(objTag,TRUE,Mgr_participant);
												AOM_save_without_extensions(objTag);
												AOM_refresh(objTag,FALSE);
												
												break;
											}
										}
										
										//AOM_unlock(objTag); PrintErrorStack();
										//AOM_refresh(objTag,TRUE); PrintErrorStack();
										MEM_free(user_id);	
										MEM_free(FunEng_Members);
									}	
									

									//// Assigning Chief Eng Review..
									member_count = 0;
									if(SA_find_role2(RoleName,&role_tag)!=ITK_ok);
									if(SA_find_groupmember_by_role(role_tag,Grp_tag,&member_count,&ChfEng_Members)!=ITK_ok);
									TC_write_syslog("ChfEng_Members member_count ::  %d\n", member_count);
									printf("ChfEng_Members member_count ::  %d\n", member_count);fflush(stdout);

									if(member_count > 0)
									{
										for(mem_count=0; mem_count<member_count; mem_count++)
										{
											if(SA_ask_groupmember_user(ChfEng_Members[mem_count], &Chf_user_tag)!=ITK_ok);							
											
											if((POM_ask_user_id(Chf_user_tag, &user_id))!=ITK_ok);
											TC_write_syslog("user_id  ::  %s\n", user_id);
											printf("user_id  ::  %s\n", user_id);fflush(stdout);
											if(tc_strstr(IndentChfEng, user_id) != NULL)
											{
												TC_write_syslog("T5_IndChfEng ............. \n");
												printf("T5_IndChfEng ............. \n");fflush(stdout);
												TC_write_syslog("Chf user_id  ::  %s\n", user_id);
												printf("Chf user_id  ::  %s\n", user_id);fflush(stdout);
												if(EPM_get_participanttype ("T5_IndChfEng",&ChfEng_Type_tag)!=ITK_ok);
												if(EPM_create_participant(ChfEng_Members[mem_count],ChfEng_Type_tag,&ChfEng_participant)!=ITK_ok)
												//AOM_unlock(objTag); PrintErrorStack();
												//AOM_refresh(objTag,TRUE); PrintErrorStack();
												//AOM_lock(objTag);	PrintErrorStack();
												///if(PARTICIPANT_add_participant(objTag,ChfEng_participant)!=ITK_ok);
												//AOM_save_without_extensions(objTag); PrintErrorStack();
												//AOM_unlock(objTag); PrintErrorStack();
												
												AOM_refresh( objTag, TRUE);
												PARTICIPANT_add_participant(objTag,TRUE,ChfEng_participant);
												AOM_save_without_extensions(objTag);
												AOM_refresh(objTag,FALSE);
												break;
											}							
										}

										//AOM_unlock(objTag);
										//AOM_refresh(objTag,TRUE);
										MEM_free(user_id);	
										MEM_free(ChfEng_Members);
									}

								
									/// Assignning Proto Indent Review
									member_count = 0;
									if(SA_find_group(IndentGrpName, &BU_Grp_tag)!=ITK_ok);
									if(SA_find_role2(IndentRoleName,&BU_role_tag)!=ITK_ok);
									if(SA_find_groupmember_by_role(BU_role_tag,BU_Grp_tag,&member_count,&Proto_Members)!=ITK_ok);
									TC_write_syslog("Proto_Members member_count ::  %d\n", member_count);
									printf("Proto_Members member_count ::  %d\n", member_count);fflush(stdout);

									if(member_count > 0)
									{
										for(mem_count=0; mem_count<member_count; mem_count++)
										{	
											if(SA_ask_groupmember_user(Proto_Members[mem_count], &Proto_user_tag)!=ITK_ok);							
											
											if((POM_ask_user_id(Proto_user_tag, &user_id))!=ITK_ok);
											TC_write_syslog("user_id  ::  %s\n", user_id);
											printf("user_id  ::  %s\n", user_id);fflush(stdout);

											TC_write_syslog("T5_ProtoInd ............. \n");
											printf("T5_ProtoInd ............. \n");fflush(stdout);
											if(EPM_get_participanttype ("T5_ProtoInd",&proto_Type_tag)!=ITK_ok);
											if(EPM_create_participant(Proto_Members[mem_count],proto_Type_tag,&proto_participant)!=ITK_ok)
											// AOM_unlock(objTag); PrintErrorStack();
											// AOM_refresh(objTag,TRUE);  PrintErrorStack();
											// AOM_lock(objTag);  PrintErrorStack();
											// if(PARTICIPANT_add_participant(objTag,proto_participant)!=ITK_ok);
											// AOM_save_without_extensions(objTag); PrintErrorStack();
											// AOM_unlock(objTag); PrintErrorStack();
											
											AOM_refresh( objTag, TRUE);
											PARTICIPANT_add_participant(objTag,TRUE,proto_participant);
											AOM_save_without_extensions(objTag);
											AOM_refresh(objTag,FALSE);
										
										}
										
										//AOM_unlock(objTag); PrintErrorStack();
										//AOM_refresh(objTag,TRUE); PrintErrorStack();
										MEM_free(Proto_Members);  
									}
								}
							}
						}
					}
					printf("\n Exit Indent_Reviewers_assign\n");fflush(stdout);
					return ifail;
				}


				int generate_indent_refno(EPM_action_message_t msg)
				{
					int ifail = ITK_ok;

					int			count				= 0;
					int			att_count			= 0;
					tag_t		rootTask_t			= NULLTAG;
					tag_t*		attachments			= NULLTAG;

					tag_t		objTag				= NULLTAG;
					logical		found				= false;
					char*		obj_type			= NULL;
					char*		ERCBU				= NULL;
					char*		IndentRoleName		= NULL;
					char*		IndentRefNo			= NULL;
					char*		PowerTrainInd			= NULL;
					char*		IndentRefNum			= NULL;
					char*		t5PlatForm			= NULL;
					char*		ERCIndentee			= NULL;

					IndentRoleName = (char	*)MEM_alloc(100);
					IndentRefNo = (char	*)MEM_alloc(100);

					printf("\n Inside generate_indent_refno\n");fflush(stdout);
					
					if(EPM_ask_root_task(msg.task,&rootTask_t)!=ITK_ok);
					if(EPM_ask_attachments(rootTask_t, EPM_target_attachment, &count, &attachments)!=ITK_ok);
					TC_write_syslog("Count :: %d",count);
					
					if(count > 0)
					{
						objTag = attachments[0];
					}
					
					if(count > 0)
					{
						WSOM_ask_object_type2(objTag, &obj_type);
						TC_write_syslog("Object Type = %s\n",obj_type);

						if(tc_strcmp(obj_type,"T5_ERCIndRevision") == 0)
						{
							AOM_ask_value_string(objTag,"t5ERCIndBU",&ERCBU);
							TC_write_syslog("ERCBU ::  %s\n", ERCBU);
							
							AOM_ask_value_string(objTag,"t5IndChkPRD",&PowerTrainInd);
							TC_write_syslog("PowerTrainInd ::  %s\n", PowerTrainInd);
							
							//AOM_get_value_string(objTag, "t5RefNo", &IndentRefNum);  
							if (AOM_ask_value_string(objTag, "t5RefNo", &IndentRefNum)!=ITK_ok) PrintErrorStack(); 
							TC_write_syslog("IndentRefNum ::  %s\n", IndentRefNum);
							
							//AOM_get_value_string(objTag, "t5_IndPlatform", &t5PlatForm);  
							if (AOM_ask_value_string(objTag, "t5_IndPlatform", &t5PlatForm)!=ITK_ok) PrintErrorStack();
							printf("t5PlatForm ::  %s\n", t5PlatForm);fflush(stdout);
							
							ITK_CALL(AOM_ask_value_string(objTag, "t5ERCIndentee", &ERCIndentee));
							printf("\n ERCIndentee-------->  : %s",ERCIndentee); fflush(stdout);
							
							tag_t	HomeSiteNameQry		= NULLTAG;
							char    *SiteName_qry_entry[1]  = {"SYSCD"};
							char    **SiteName_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
							int     SiteNm_rsltCount    = 0;
							tag_t	*SiteNameCntrlObjectTag	= NULLTAG;
							int     SiteName_n_entry    = 1;
							char*	 SiteNameinfo1 = NULL;
							char*	 SiteNameinfo2IndName = NULL;
							char*	 info3PltFormLive = NULL;
							
							if(QRY_find2("ControlObjects", &HomeSiteNameQry));
							if (HomeSiteNameQry)
							{
								printf("\n Found Query HomeSiteNameQry.");fflush(stdout);
							}
							else
							{
								printf("\n Not Found Query HomeSiteNameQry.");fflush(stdout);
							}

							SiteName_qry_values2[0] = "SiteNameDeatils";
							if(QRY_execute(HomeSiteNameQry, SiteName_n_entry, SiteName_qry_entry, SiteName_qry_values2, &SiteNm_rsltCount, &SiteNameCntrlObjectTag));
							printf(" \n SiteNm_rsltCount :%d:", SiteNm_rsltCount); fflush(stdout);
							if(SiteNm_rsltCount > 0)
							{
								
								if (AOM_ask_value_string(SiteNameCntrlObjectTag[0],"t5_Userinfo1",&SiteNameinfo1)!=ITK_ok);
								printf("\n :SiteNameinfo1 is : [%s]", SiteNameinfo1);fflush(stdout);
								
								if (AOM_ask_value_string(SiteNameCntrlObjectTag[0],"t5_Userinfo2",&SiteNameinfo2IndName)!=ITK_ok);
								printf("\n :SiteNameinfo2IndName is : [%s]", SiteNameinfo2IndName);fflush(stdout);
								
								if (AOM_ask_value_string(SiteNameCntrlObjectTag[0],"t5_Userinfo3",&info3PltFormLive)!=ITK_ok);
								printf("\n :info3PltFormLive is : [%s]", info3PltFormLive);fflush(stdout);
								
								if(tc_strcmp(info3PltFormLive,"IndentPlatFormLive")==0)
								{
									if(tc_strcmp(ERCBU,NULL)!=0 || tc_strcmp(ERCBU,"")!=0)
									{
										if(tc_strcmp(PowerTrainInd,"Y") == 0)
										{
											if(tc_strcmp(ERCIndentee,"Proto Planning") == 0)
											{
											tc_strcpy(IndentRoleName,"");
											tc_strcpy(IndentRoleName,"PRD_Prt_Ind_Planning_Grp");
											printf("\n PowerTrainInd and ERCIndentee are: [%s][%s]",PowerTrainInd, ERCIndentee);fflush(stdout);
											}
											
											else if(tc_strcmp(ERCIndentee,"LKO Proto Planning") == 0)
											{
											tc_strcpy(IndentRoleName,"");
											tc_strcpy(IndentRoleName,"LKO_Prt_Ind_Planning_Grp");
											printf("\n PowerTrainInd and ERCIndentee are: [%s][%s]",PowerTrainInd, ERCIndentee);fflush(stdout);
											}
											
											else if(tc_strcmp(ERCIndentee,"JSR Proto Planning") == 0)
											{
											tc_strcpy(IndentRoleName,"");
											tc_strcpy(IndentRoleName,"JSR_Prt_Ind_Planning_Grp");
											printf("\n PowerTrainInd and ERCIndentee are: [%s][%s]",PowerTrainInd, ERCIndentee);fflush(stdout);
											}
										}
										else if(tc_strcmp(ERCBU,"CVBU") == 0 && tc_strcmp(PowerTrainInd,"N") == 0)
										{
											
											if(tc_strcmp(t5PlatForm,NULL)!=0 || tc_strcmp(t5PlatForm,"")!=0)
											{
											printf("\n 2222IN CVBU :t5PlatForm is : [%s]", t5PlatForm);fflush(stdout);
											
											if(tc_strcmp(ERCIndentee,"Proto Planning") == 0)
											{
												tc_strcpy(IndentRoleName,"");
												tc_strcat(IndentRoleName,t5PlatForm);
												tc_strcat(IndentRoleName,"_Prt_Ind_Planning_Grp");
												printf("\n :22222IndentRoleName is : [%s]", IndentRoleName);fflush(stdout);
											}
											else if(tc_strcmp(ERCIndentee,"LKO Proto Planning") == 0)
											{
												tc_strcpy(IndentRoleName,"");
												tc_strcat(IndentRoleName,"LKO_Prt_Ind_Planning_Grp");
												
												printf("\n 22222Under LKO Proto Planning :IndentRoleName is : [%s]", IndentRoleName);fflush(stdout);
											}
											else if(tc_strcmp(ERCIndentee,"JSR Proto Planning") == 0)
											{
												tc_strcpy(IndentRoleName,"");
												tc_strcat(IndentRoleName,"JSR_Prt_Ind_Planning_Grp");
												
												printf("\n 22222Under JSR Proto Planning :IndentRoleName is : [%s]", IndentRoleName);fflush(stdout);
											}
											}
											
											else
											{
												printf("\n IN CVBU indent Platform is null :");fflush(stdout);
												tc_strcpy(IndentRoleName,"");
												tc_strcpy(IndentRoleName,"CVBU_Prt_Ind_Planning_Grp");
											}
											//tc_strcpy(IndentRoleName,"");
											//tc_strcpy(IndentRoleName,"CVBU_Prt_Ind_Planning_Grp");
										}
										else if(tc_strcmp(ERCBU,"PVBU") == 0 && tc_strcmp(PowerTrainInd,"N") == 0) 
										{
											if(tc_strcmp(t5PlatForm,NULL)!=0 || tc_strcmp(t5PlatForm,"")!=0)
											{
												tc_strcpy(IndentRoleName,"");
												tc_strcat(IndentRoleName,t5PlatForm);
												tc_strcat(IndentRoleName,"_Prt_Ind_Planning_Grp");
												
												printf("\n :IndentRoleName is : [%s]", IndentRoleName);fflush(stdout);
											}
											else
											{
												printf("\n indent Planform is null : [%s]", t5PlatForm);fflush(stdout);
												tc_strcpy(IndentRoleName,"");
												tc_strcpy(IndentRoleName,"PCBU_Prt_Ind_Planning_Grp");
											}
										}
									}
									else
									{
										printf("\n Business unit is null : [%s]", ERCBU);fflush(stdout);
										tc_strcpy(IndentRoleName,"");
										tc_strcpy(IndentRoleName,"Default_Prt_Ind_Planning_Grp");
										printf("\n in else IndentRoleName is : [%s]", IndentRoleName);fflush(stdout);
									}
									printf("Final ERCBU:[%s]  ,  IndentRoleName :[%s] t5PlatForm:[%s]", ERCBU, IndentRoleName,t5PlatForm);fflush(stdout);
									if(tc_strcmp(IndentRoleName,NULL)!=0 || tc_strcmp(IndentRoleName,"")!=0)
									{
										AOM_lock(objTag);
										AOM_set_value_string(objTag, "t5Indentee", IndentRoleName);
										AOM_save_without_extensions(objTag);
										AOM_unlock(objTag);
										AOM_refresh(objTag,TRUE);
									}
								}
								else
								{
									//if(ERCBU != NULL)
									if(tc_strcmp(ERCBU,NULL)!=0 || tc_strcmp(ERCBU,"")!=0)
									{
										printf("\n indent plantform is not live info3PltFormLive is : [%s]", info3PltFormLive);fflush(stdout);
										if(tc_strcmp(ERCBU,"CVBU") == 0 && tc_strcmp(ERCIndentee,"LKO Proto Planning") == 0)
										{
											tc_strcpy(IndentRoleName,"LKO_Prt_Ind_Planning_Grp");
										}
										else if(tc_strcmp(ERCBU,"CVBU") == 0 && tc_strcmp(ERCIndentee,"JSR Proto Planning") == 0)
										{	
											tc_strcpy(IndentRoleName,"JSR_Prt_Ind_Planning_Grp");										
										}
										else if(tc_strcmp(PowerTrainInd,"Y") == 0)
										{
											tc_strcpy(IndentRoleName,"PRD_Prt_Ind_Planning_Grp");
										}
										else if(tc_strcmp(ERCBU,"CVBU") == 0 && tc_strcmp(PowerTrainInd,"N") == 0)
										{
											tc_strcpy(IndentRoleName,"CVBU_Prt_Ind_Planning_Grp");
										}
										else if(tc_strcmp(ERCBU,"PVBU") == 0 && tc_strcmp(PowerTrainInd,"N") == 0) 
										{
											tc_strcpy(IndentRoleName,"PCBU_Prt_Ind_Planning_Grp");
										}
									}
									TC_write_syslog("ERCBU  :: %s  ,  IndentRoleName ::  %s\n", ERCBU, IndentRoleName);
									
									
									if(IndentRoleName != NULL)
									{
										AOM_lock(objTag);
										AOM_set_value_string(objTag, "t5Indentee", IndentRoleName);
										AOM_save_without_extensions(objTag);
										AOM_unlock(objTag);
										AOM_refresh(objTag,TRUE);
									}	
								}
							
							}
							else
							{
								printf(" \n contorl object not found SiteNm_rsltCount :%d:", SiteNm_rsltCount); fflush(stdout);
							}
							


							if(IndentRefNum == NULL )
							{	
								//// Calling Function to get the Ref No.
								found = getIndentRefNo(IndentRefNo);
								if(found == true && IndentRefNo != NULL)
								{
									TC_write_syslog("IndentRefNo ::  %s\n", IndentRefNo);
									
									AOM_lock(objTag);
									AOM_set_value_string(objTag, "t5RefNo", IndentRefNo);
									AOM_save_without_extensions(objTag);
									AOM_unlock(objTag);
									AOM_refresh(objTag,TRUE);
								}
							}
							if (( tc_strstr(IndentRefNum,"UAPUN") == NULL) ||( tc_strstr(IndentRefNum,"CVPUN") == NULL))
							{				
								//// Calling Function to get the Ref No.
								found = getIndentRefNo(IndentRefNo);
								if(found == true && IndentRefNo != NULL)
								{
									TC_write_syslog("IndentRefNo ::  %s\n", IndentRefNo);
									
									AOM_lock(objTag);
									AOM_set_value_string(objTag, "t5RefNo", IndentRefNo);
									AOM_save_without_extensions(objTag);
									AOM_unlock(objTag);
									AOM_refresh(objTag,TRUE);
								}
							}
						}	
					}
					printf("\n Exit generate_indent_refno\n");fflush(stdout);
					
					MEM_free(IndentRefNum);
					return ifail;
				}


				logical getIndentRefNo(char *IndentRefNo)
				{
				   time_t now;
				   char* result	=  NULL;
				   char* finalrefno	=  NULL;
				  // char* nxtSrl	=  NULL;
				   char* location = "UAPUN";
				   char* FixValue = "9999";
				   char year [12] = {'\0'};
				   char Sec [12] = {'\0'};
				   char *sub = NULL;
				   char *refno = NULL;
				   char *latestRefNo = NULL;
				   char    nxtSrl[25]= {'\0'};
				   char    IndRefNo[25]= {'\0'};

				   int		num_found		= 0;
				   logical	found;
				   int		latestref_int		= 0;
				   char
						*qry_entries[1] = {"Indent Reference No"},
						*qry_values[1]	= {"*"};

				   tag_t		query_tag		= NULLTAG;
				   tag_t*		results			= NULLTAG;

				   result = (char	*)MEM_alloc(100);
				   finalrefno = (char	*)MEM_alloc(100);
				  // nxtSrl = (char	*)MEM_alloc(100);
				   sub = (char	*)MEM_alloc(100);

				   if ( time(&now) != (time_t)(-1) )
				   {
					  struct tm *mytime = localtime(&now);
					  if ( mytime )
					  {
						 if ( strftime(year, sizeof year, "%Y", mytime) )
						 {
							TC_write_syslog("year ::  %s\n", year);
							sub = subString(year,2, 2);
							TC_write_syslog("sub ::  %s\n", sub);
						 }

						 if ( strftime(Sec, sizeof year, "%S", mytime) )
						 {
							TC_write_syslog("Sec ::  %s\n", Sec);
						 }
					  }
				   }
					
					tc_strcpy(result,"");
					tc_strcat(result,location);
					tc_strcat(result,sub);
					tc_strcat(result,FixValue);
					tc_strcat(result,"*");
					TC_write_syslog("result ::  %s\n", result);
				   
					if(result != NULL)
					{
						qry_values[0] = result;
						QRY_find2("Indent Ref Gen..", &query_tag);
						
						if(query_tag != NULLTAG)
						{
							QRY_execute(query_tag, 1, qry_entries, qry_values, &num_found, &results);
							TC_write_syslog("num_found ::  %d\n", num_found);
							if(num_found==0)
							{
								found=false;
							}
							if(num_found > 0)
							{
								AOM_ask_value_string(results[0] ,"t5RefNo", &refno);				
								TC_write_syslog("refno ::  %s\n", refno);
								latestRefNo = subString(refno,11, 5);
								TC_write_syslog("latestRefNo ::  %s\n", latestRefNo);
								
								if(latestRefNo != NULL)
								{
									latestref_int = atoi(latestRefNo);
									//TC_write_syslog("latestref_int ::  %d\n", latestref_int);
									//latestref_int = latestref_int + 1;
									latestref_int = num_found + 1;
									//TC_write_syslog("latestref_int ::  %d\n", latestref_int);
									
									sprintf (nxtSrl, "%d",latestref_int);
									TC_write_syslog("nxtSrl ::  %s\n", nxtSrl);

									if(latestref_int ==0)
									{
										found=false;
									}
								}

								if(nxtSrl != NULL)
								{
									tc_strcpy(finalrefno,"");
									tc_strcat(finalrefno,location);
									tc_strcat(finalrefno,sub);
									tc_strcat(finalrefno,FixValue);
									tc_strcat(finalrefno,nxtSrl);
									tc_strcat(finalrefno,"_");
									tc_strcat(finalrefno,Sec);
									TC_write_syslog("finalrefno ::  %s\n", finalrefno);

									if(finalrefno != NULL)
									{
										tc_strcpy(IndentRefNo,"");
										tc_strcat(IndentRefNo,finalrefno);
										found=true;
									}
								}
							}
						}
					}

					return found;
				}


				int CM_Gen_ERC_IndentReport(EPM_action_message_t msg)
				{
					time_t now;
					int			ifail							= ITK_ok;
					int			count,transfermodeCnt			= 0;
					char		outputtime[50]					= {'\0'};
					char		Data[50]						= {'\0'};
					
					time_t t ;
					struct tm *tmp ;
					time( &t );

					tag_t		rootTask_t		= NULLTAG;
					tag_t		objTag			= NULLTAG;
					tag_t		PLMSession		= NULLTAG;
					tag_t		specRelationType_t		= NULLTAG;
					tag_t		msExlType		= NULLTAG;
					tag_t		MsXlDataset		= NULLTAG;
					tag_t		specificationRel_t		= NULLTAG;
					tag_t		MsXlatestDat_t		= NULLTAG;
					tag_t*		attachments		= NULLTAG;
					tag_t*		transfermodes	= NULLTAG;

					char*		obj_type			= NULL;
					char*		indentNumber		= NULL;
					char*		indentrevision		= NULL;
					char*		token				= NULL;
					char		mainFile[100];
					char		XlsxFile[100];
					char		command[512];
					struct    tm when;
					
					printf("\n Inside CM_Gen_ERC_IndentReport\n");fflush(stdout);

					if(EPM_ask_root_task(msg.task,&rootTask_t)!=ITK_ok);
					if(EPM_ask_attachments(rootTask_t, EPM_target_attachment, &count, &attachments)!=ITK_ok);
					TC_write_syslog("Count :: %d",count);
					
					GRM_find_relation_type("IMAN_specification",&specRelationType_t);

					if(count > 0)
					{
						objTag = attachments[0];
					}

					
					time(&now);
					when = *localtime(&now);
					
					strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
					sprintf(outputtime,"%s",Data);
					TC_write_syslog("outputtime :: %s\n",outputtime);
					

					if(objTag != NULLTAG)
					{
						WSOM_ask_object_type2(objTag,&obj_type);
						TC_write_syslog("obj_type :: %s",obj_type);

						if(tc_strcasecmp(obj_type,"T5_ERCIndRevision")==0)
						{
							AOM_ask_value_string(objTag,"t5RefNo",&indentNumber);
							TC_write_syslog("\nindentNumber :: %s",indentNumber);
							printf("\nindentNumber :: %s",indentNumber);fflush(stdout);
							
							AOM_ask_value_string(objTag,"current_revision_id",&indentrevision);
							TC_write_syslog("\nindentrevision :: %s",indentrevision);
							printf("\nindentrevision :: %s",indentrevision);fflush(stdout);
							
							token=strtok(indentrevision,";");

							tc_strcpy(mainFile,"");
							tc_strcat(mainFile,"/tmp/");
							tc_strcat(mainFile,indentNumber);
							tc_strcat(mainFile,"_");
							tc_strcat(mainFile,token);
							tc_strcat(mainFile,"_");
							tc_strcat(mainFile,outputtime);
							tc_strcat(mainFile,".xml");
							TC_write_syslog("\nMain File = %s\n",mainFile);
							printf("\nMain File = %s\n",mainFile);fflush(stdout);

							
							tc_strcpy(XlsxFile,"");
							tc_strcat(XlsxFile,"/tmp/Indent_");
							tc_strcat(XlsxFile,indentNumber);
							tc_strcat(XlsxFile,"_");
							tc_strcat(XlsxFile,token);
							tc_strcat(XlsxFile,"_");
							tc_strcat(XlsxFile,outputtime);
							tc_strcat(XlsxFile,".xls");
							TC_write_syslog("Xlsx File = %s\n",XlsxFile);
							printf("Xlsx File = %s\n",XlsxFile);fflush(stdout);
						
							PIE_create_session(&PLMSession);
							PIE_session_set_file(PLMSession,mainFile);

							PIE_find_transfer_mode2("T5_ERC_MFG_Indent_Report_TM","DEFAULT_PIE_CONTEXT_STRING",&transfermodeCnt,&transfermodes);
							TC_write_syslog("No of TrasnferModes = %d\n",transfermodeCnt);
							printf("No of TrasnferModes = %d\n",transfermodeCnt);fflush(stdout);

							if(transfermodeCnt > 0)
							{
								PIE_session_set_transfer_mode(PLMSession,transfermodes[0]);
								PIE_session_export_objects(PLMSession,1,&objTag);

								sprintf(command,"$TC_ROOT/bin/tml_tools/indent.sh %s %s",mainFile,XlsxFile);
								TC_write_syslog("Command = %s\n",command);
								printf("Command = %s\n",command);fflush(stdout);
								system(command);

								if(access(XlsxFile,F_OK)!=-1)
								{
									TC_write_syslog("XLS file created successfully\n");
									printf("XLS file created successfully\n");fflush(stdout);
									AE_find_datasettype2("MSExcel",&msExlType);

									if(msExlType == NULLTAG)
									{
										TC_write_syslog("Could not find Dataset Type MSExcel. Please check data model\n");						 
										printf("Could not find Dataset Type MSExcel. Please check data model\n");fflush(stdout);
									}

									AE_create_dataset_with_id(msExlType,indentNumber,"ERC Indent Report","","",&MsXlDataset);
									AE_save_myself(MsXlDataset);
									GRM_create_relation(objTag,MsXlDataset,specRelationType_t,NULLTAG,&specificationRel_t);
									AOM_load(specificationRel_t);
									GRM_save_relation(specificationRel_t);
									AE_ask_dataset_latest_rev(MsXlDataset,&MsXlatestDat_t);
									AOM_refresh(MsXlatestDat_t,TRUE);
									AE_import_named_ref(MsXlatestDat_t,"excel",XlsxFile,NULL,SS_BINARY);
									AE_save_myself(MsXlatestDat_t);
									remove(XlsxFile);
								}
							}
						}
					}
					printf("\n Exit CM_Gen_ERC_IndentReport\n");fflush(stdout);
					return ifail;
				}
				extern EPM_decision_t DLLAPI ChkIndentActiveinLC(EPM_rule_message_t msg)
				{
					tag_t			root_task=NULLTAG;
					char*			CurrentTask				=NULL;
					char*			t5current_name				=NULL;
					char*			procedure_name				=NULL;

					tag_t *attachments = NULLTAG;
					tag_t *parents = NULLTAG;
					tag_t IndLcmTag = NULLTAG;

					EPM_decision_t decision = EPM_go;
					int ifail=0,count=0,n_parents=0;
					char*			Indobj_type					= NULL;
					
					tag_t			primary_obj_type_tag		= NULLTAG;
					char			*type_name1					= NULL;

					CALLAPI(EPM_ask_root_task(msg.task,&root_task));
					printf("\n\n\t\t Root task found for ChkIndentActiveinLC"); fflush(stdout);

					CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
					printf("\nCurrentTask:%s\n",CurrentTask);

					CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
					printf("\n\n\t\t EPM_ask_attachments of :: %d",count);

					if(count > 0)
					{
						IndLcmTag = attachments[0];
						
						CALLAPI(TCTYPE_ask_object_type(IndLcmTag,&primary_obj_type_tag));
						CALLAPI(TCTYPE_ask_name2(primary_obj_type_tag, &type_name1));
						printf("\n ChkIndentActiveinLC::Primary_object type_name is:%s",type_name1);fflush(stdout);
						
						CALLAPI(AOM_ask_value_string(IndLcmTag,"current_name",&t5current_name));
						printf("\n\n\t\t t5current_name is : %s",t5current_name);fflush(stdout);

						CALLAPI(EPM_ask_active_job_for_target(IndLcmTag,&n_parents,&parents));
						printf("\n EPM_ask_active_job_for_target------>%d\n",n_parents); fflush(stdout);
					}

					

					if (n_parents>0)
					{
						CALLAPI(EPM_ask_procedure_name2(parents[0],&procedure_name));
						printf("\n procedure_nameprocedure_name----->%s\n",procedure_name); fflush(stdout);
					
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_warning,ITK_err, "Indent already submitted in Lifecycle ... You can not submit it again.");
						//decision = EPM_nogo;
						return EPM_nogo;
					}else
					{
						decision = EPM_go;
						//return EPM_go;
					}
					if(IndLcmTag != NULLTAG)
					{
						WSOM_ask_object_type2(IndLcmTag,&Indobj_type);
						printf("\n IndLcmTag type----->[%s]",Indobj_type); fflush(stdout);
						
						if(tc_strcasecmp(Indobj_type,"T5_ERCIndRevision")==0)
						{
							
							//decision = EPM_go;
							return EPM_go;
						}
						else
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_warning,ITK_err, "Please select Indent Revision and submit into Workflow.");
							//decision = EPM_nogo;
							return EPM_nogo;
						}
					}

					return decision;
				}
				extern EPM_decision_t DLLAPI Chk_ProtoResPartyAssignLC(EPM_rule_message_t msg)
				{
					tag_t			root_task=NULLTAG;
					char*			CurrentTask				=NULL;
					char*			t5current_name				=NULL;
					char*			procedure_name				=NULL;
					tag_t Ind_PT_rel_type	= NULLTAG;

					tag_t *taskAttachments = NULLTAG;
					tag_t *parents = NULLTAG;
					tag_t IndLcmTag = NULLTAG;
					tag_t objTag = NULLTAG;

					EPM_decision_t decision = EPM_go;
					int ifail=0,count=0,n_parents=0;
					int attachmentCount=0;
					int RSPcount=0;
					tag_t *IndRspy = NULLTAG;
					tag_t IndRspyTag = NULLTAG;
					char*			obj_type					= NULL;
					char *type_name7 = NULL;
					tag_t* signOffTags = NULLTAG;
					int cnt=0;
					int IndResPartyFlag=0;
					int ResPartyFound=0;

					CALLAPI(EPM_ask_root_task(msg.task,&root_task));
					printf("\n\n\t\t Root task found for Chk_ProtoResPartyAssignLC"); fflush(stdout);
					
					if(EPM_ask_attachments(msg.task, EPM_signoff_attachment,&cnt, &signOffTags)!=ITK_ok)PrintErrorStack();
					//if(EPM_ask_attachments(msg.task, EPM_target_attachment,&cnt, &signOffTags)!=ITK_ok)PrintErrorStack();
					
					printf("\n No of Sign off Tags ===> %d\n",cnt);fflush(stdout);

					CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
					printf("\nCurrentTask:%s\n",CurrentTask);
					
					if(cnt>0)
					{
					tag_t signOffTag = NULLTAG;
					EPM_signoff_decision_t decsn = EPM_no_decision;
					char* comments = NULL;
					date_t decision_date = NULLDATE;
					signOffTag = signOffTags[0];
					if(EPM_ask_signoff_decision(signOffTag, &decsn, &comments, &decision_date)!=ITK_ok)PrintErrorStack();
					printf("\n comments ==> %s\n",comments);fflush(stdout);
					if (decsn==EPM_approve_decision)
					{
					EPM_ask_attachments(root_task,EPM_target_attachment,&attachmentCount,&taskAttachments);
					printf("\nattachmentCount:[%d]",attachmentCount);
					if(attachmentCount > 0)
					{
						objTag = taskAttachments[0];
						
						WSOM_ask_object_type2(objTag,&obj_type);
						printf("\n IndLcmTag type in Assign parti----->[%s]",obj_type); fflush(stdout);
					}
					
					if(GRM_find_relation_type("HasParticipant", &Ind_PT_rel_type)!=ITK_ok)PrintErrorStack();
					if (Ind_PT_rel_type!=NULLTAG)
					{
						printf("\n ADPR:P28:DML to Has participant. \n");fflush(stdout);
						if(GRM_list_secondary_objects_only(objTag,Ind_PT_rel_type,&RSPcount,&IndRspy)!=ITK_ok)PrintErrorStack();
						printf("\n Indent Reponsible Party count: %d",RSPcount);fflush(stdout);	
					}
					
					if (RSPcount >0)
					{
						int jk=0;
					
						for (jk=0;jk<RSPcount ;jk++ )
						{	
							tag_t ObjTypIndRspy = NULLTAG;
							IndRspyTag = IndRspy[jk];
							if(TCTYPE_ask_object_type(IndRspyTag,&ObjTypIndRspy));
							if(TCTYPE_ask_name2(ObjTypIndRspy,&type_name7));
							printf("\n ADPR:CV:P30:CE: Participants Name: %s", type_name7);fflush(stdout);
							//VI Reviewer will be work as Certification reviewer
							if (tc_strcmp(type_name7,"ProposedResponsibleParty")==0)
							{
								IndResPartyFlag=1;
								break;
							}
						}
					}
			

					 if (IndResPartyFlag==0)
					 {
						 ResPartyFound=0;
						 printf("\n ResPartyFound and IndResPartyFlag are 0");fflush(stdout);
						// EMH_clear_errors();
						 //EMH_store_error_s1(EMH_severity_warning,ITK_err, "Please Assign Responsible Party.");
						 //decision = EPM_nogo;
					 }
					 else
					 {
						 ResPartyFound=1;
						 //decision = EPM_go;
						 printf("\n ResPartyFound is not zero");fflush(stdout);
					 }
					 if(ResPartyFound==0)
					 {
						 EMH_clear_errors();
						 EMH_store_error_s1(EMH_severity_warning,ITK_err, "Please Assign Responsible Party.");
						 decision = EPM_nogo; 
					 }
					 
					 if (ResPartyFound>0)
					 {
						
						 char*		IndentApproverstr		= NULL;
						 char*		IndentApprover		= NULL;
						tag_t 		IndentApproverTag = NULLTAG;
						tag_t		person_tag = NULLTAG;
						
							
							
							AOM_UIF_ask_value(IndRspyTag,"fnd0AssigneeUser",&IndentApproverstr);
							printf("\n epm_proposed_responsible_party ::  %s\n", IndentApproverstr);fflush(stdout);
							
							IndentApprover =  (char *)MEM_alloc(100);
							
							IndentApprover = tc_strtok(IndentApproverstr, "(");
							IndentApprover = tc_strtok(NULL, ")");
							
							printf("\n under EPR Indent Approver value is %s",IndentApprover);fflush(stdout);
							
							if(SA_find_user2(IndentApprover, &IndentApproverTag)!=ITK_ok)PrintErrorStack();
							
							if(SA_ask_user_person (IndentApproverTag,&person_tag)!=ITK_ok)PrintErrorStack(); 
							
							char* mailId = NULL;
							char*	eMailTo			= NULL;
							eMailTo=(char *) MEM_alloc(500 * sizeof(char *));
							char*	eMailCC			= NULL;
							eMailCC=(char *) MEM_alloc(500 * sizeof(char *));
							char  *buff 	= NULL;
							buff=(char *) MEM_alloc(2000 * sizeof(char *));
							char  *envSub	  = NULL;
							char  *envDesc	  = NULL;
							envSub = (char *) MEM_alloc( 250 * sizeof(char) );
							envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
							
								if(person_tag!=NULLTAG)
								{
									if(SA_ask_person_email_address(person_tag,&mailId)!=ITK_ok)PrintErrorStack();
									if(tc_strlen(mailId)>0)
									{
										printf("\n%s mailId: %s",mailId);
										if(tc_strstr(eMailTo, mailId)==NULL)
										{
											tc_strcat(eMailTo,",");
											tc_strcat(eMailTo,mailId);
										}
									}
								}
								printf("\n Mail to Proposed Responsible Party:  [%s]", eMailTo);fflush(stdout);
								char* IndNum = NULL;
								char* IndDummyRefNo = NULL;
								char* Indcurrent_desc = NULL;
								char* Indt5WBS = NULL;
								char* Indt5IndWbsDes = NULL;
								char* Indt5_IndPlatform = NULL;
								
								AOM_ask_value_string(objTag,"item_id",&IndNum);
								printf("\n ERCDMLNum [%s]",IndNum);fflush(stdout);
								
								AOM_ask_value_string(objTag,"t5DummyRefNo",&IndDummyRefNo);
			
								printf("\n IndDummyRefNo [%s]",IndDummyRefNo);fflush(stdout);
								
								AOM_ask_value_string(objTag,"current_desc",&Indcurrent_desc);
			
								printf("\n Indcurrent_desc [%s]",Indcurrent_desc);fflush(stdout);
								
								AOM_ask_value_string(objTag,"t5WBS",&Indt5WBS);
			
								printf("\n Indt5WBS [%s]",Indt5WBS);fflush(stdout);
								
								AOM_ask_value_string(objTag,"t5IndWbsDes",&Indt5IndWbsDes);
			
								printf("\n Indt5IndWbsDes [%s]",Indt5IndWbsDes);fflush(stdout);
								
								AOM_ask_value_string(objTag,"t5_IndPlatform",&Indt5_IndPlatform);
			
								printf("\n Indt5_IndPlatform [%s]",Indt5_IndPlatform);fflush(stdout);
				
				
								tc_strcpy(envSub,"Indent:");
								tc_strcat(envSub,IndNum);
								tc_strcat(envSub, " New Assignment recieved in your work list.");

								tc_strcpy(envDesc,"Dear All, ");
								
								tc_strcat(envDesc,"\n\nNew Assignment recieved in your work list");
								
								tc_strcat(envDesc,"\n\nIndent: ");
								tc_strcat(envDesc,IndNum);
								tc_strcat(envDesc,"\n\nUser Reference Number: ");
								tc_strcat(envDesc,IndDummyRefNo);
								tc_strcat(envDesc,"\n\nCurrent Description: ");
								tc_strcat(envDesc,Indcurrent_desc);
								tc_strcat(envDesc,"\n\nWork Breakdown Structure(WBS): ");
								tc_strcat(envDesc,Indt5WBS);
								tc_strcat(envDesc,"\n\nWBS Description: ");
								tc_strcat(envDesc,Indt5IndWbsDes);
								tc_strcat(envDesc,"\n\nIndent Platform: ");
								tc_strcat(envDesc,Indt5_IndPlatform);
								
								tc_strcat(envDesc,"\n\n Regards");
								tc_strcat(envDesc,"\n PLM Team,\n\n");

								printf("\n\nMAIL_initialize\n\n");
								printf("\n\nMAIL_initialize\n\n");
								
								tc_strcpy(eMailCC,"renuka.deshpande@tatamotors.com");
								//tc_strcpy(eMailCC,"poonams.ttl@tatamotors.com");
								//tc_strcpy(eMailTo,"poonams.ttl@tatamotors.com");
								
								sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
								printf("\n MailIndentNewProtoReviewLC BUFF--- is :: [%s] ..\n",buff);fflush(stdout);
								system(buff);
								
								decision = EPM_go;
								
					 }
					 
					 
					}
				}

					return decision;
				}
			int MailIndentManagerReviewLC(EPM_action_message_t msg)
				{
					int error_code = ITK_ok;
					tag_t			root_task=NULLTAG;
					char*			CurrentTask				=NULL;
					char*			t5current_name				=NULL;
					char*			procedure_name				=NULL;
					tag_t Ind_PT_rel_type	= NULLTAG;

					tag_t *taskAttachments = NULLTAG;
					tag_t *parents = NULLTAG;
					tag_t IndobjTag = NULLTAG;

					EPM_decision_t decision = EPM_go;
					int ifail=0,count=0,n_parents=0;
					int attachmentCount=0;
					int NumOfAtchm=0;
					

					CALLAPI(EPM_ask_root_task(msg.task,&root_task));
					printf("\n\n\t\t Root task found for MailIndentManagerReviewLC"); fflush(stdout);

					CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
					printf("\nCurrentTask:%s\n",CurrentTask);
					
					EPM_ask_attachments(root_task,EPM_target_attachment,&attachmentCount,&taskAttachments);
					printf("\nattachmentCount:[%d]",attachmentCount);
					if(attachmentCount > 0)
					{
						for (NumOfAtchm=0;NumOfAtchm<attachmentCount ;NumOfAtchm++ )
						{
						IndobjTag = NULLTAG;
						char*			Indobjtype					= NULL;
						IndobjTag = taskAttachments[NumOfAtchm];
						
						WSOM_ask_object_type2(IndobjTag,&Indobjtype);
						printf("\n IndobjTag type in Assign parti----->[%s]",Indobjtype); fflush(stdout);
						
					
						if(tc_strcasecmp(Indobjtype,"T5_ERCIndRevision")==0)
						{
							char*		IndentApprover		= NULL;
							tag_t IndentApproverTag = NULLTAG;
							tag_t person_tag = NULLTAG;
							
							AOM_ask_value_string(IndobjTag,"t5PrtIndApprov",&IndentApprover);
							printf("IndentApprover ::  %s\n", IndentApprover);fflush(stdout);
							
							if(SA_find_user2(IndentApprover, &IndentApproverTag)!=ITK_ok)PrintErrorStack();
							
							if(SA_ask_user_person (IndentApproverTag,&person_tag)!=ITK_ok)PrintErrorStack();
							
							char* mailId = NULL;
							char*	eMailTo			= NULL;
							eMailTo=(char *) MEM_alloc(500 * sizeof(char *));
							char*	eMailCC			= NULL;
							eMailCC=(char *) MEM_alloc(500 * sizeof(char *));
							char  *buff 	= NULL;
							buff=(char *) MEM_alloc(2000 * sizeof(char *));
							char  *envSub	  = NULL;
							char  *envDesc	  = NULL;
							envSub = (char *) MEM_alloc( 250 * sizeof(char) );
							envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
							
								if(person_tag!=NULLTAG)
								{
									if(SA_ask_person_email_address(person_tag,&mailId)!=ITK_ok)PrintErrorStack();
									if(tc_strlen(mailId)>0)
									{
										printf("\n%s mailId: %s",mailId);
										if(tc_strstr(eMailTo, mailId)==NULL)
										{
											tc_strcat(eMailTo,",");
											tc_strcat(eMailTo,mailId);
										}
									}
								}
								printf("\n Final mail to Manager Review:  [%s]", eMailTo);fflush(stdout);
								char* IndNum = NULL;
								char* IndDummyRefNo = NULL;
								char* Indcurrent_desc = NULL;
								char* Indt5WBS = NULL;
								char* Indt5IndWbsDes = NULL;
								char* Indt5_IndPlatform = NULL;
								
								AOM_ask_value_string(IndobjTag,"item_id",&IndNum);
								printf("\n ERCDMLNum [%s]",IndNum);fflush(stdout);
								
								AOM_ask_value_string(IndobjTag,"t5DummyRefNo",&IndDummyRefNo);
			
								printf("\n IndDummyRefNo [%s]",IndDummyRefNo);fflush(stdout);
								
								AOM_ask_value_string(IndobjTag,"current_desc",&Indcurrent_desc);
			
								printf("\n Indcurrent_desc [%s]",Indcurrent_desc);fflush(stdout);
								
								AOM_ask_value_string(IndobjTag,"t5WBS",&Indt5WBS);
			
								printf("\n Indt5WBS [%s]",Indt5WBS);fflush(stdout);
								
								AOM_ask_value_string(IndobjTag,"t5IndWbsDes",&Indt5IndWbsDes);
			
								printf("\n Indt5IndWbsDes [%s]",Indt5IndWbsDes);fflush(stdout);
								
								AOM_ask_value_string(IndobjTag,"t5_IndPlatform",&Indt5_IndPlatform);
			
								printf("\n Indt5_IndPlatform [%s]",Indt5_IndPlatform);fflush(stdout);
				
				
								tc_strcpy(envSub,"Indent:");
								tc_strcat(envSub,IndNum);
								tc_strcat(envSub, " New Assignment recieved in your work list.");

								tc_strcpy(envDesc,"Dear All, ");
								
								tc_strcat(envDesc,"\n\nNew Assignment recieved in your work list");
								
								tc_strcat(envDesc,"\n\nIndent: ");
								tc_strcat(envDesc,IndNum);
								tc_strcat(envDesc,"\n\nUser Reference Number: ");
								tc_strcat(envDesc,IndDummyRefNo);
								tc_strcat(envDesc,"\n\nCurrent Description: ");
								tc_strcat(envDesc,Indcurrent_desc);
								tc_strcat(envDesc,"\n\nWork Breakdown Structure(WBS): ");
								tc_strcat(envDesc,Indt5WBS);
								tc_strcat(envDesc,"\n\nWBS Description: ");
								tc_strcat(envDesc,Indt5IndWbsDes);
								tc_strcat(envDesc,"\n\nIndent Platform: ");
								tc_strcat(envDesc,Indt5_IndPlatform);
								
								tc_strcat(envDesc,"\n\n Regards");
								tc_strcat(envDesc,"\n PLM Team,\n\n");

								printf("\n\nMAIL_initialize\n\n");
								printf("\n\nMAIL_initialize\n\n");
								
								tc_strcpy(eMailCC,"renuka.deshpande@tatamotors.com");
								//tc_strcpy(eMailTo,"poonams.ttl@tatamotors.com");
								
								sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
								printf("\n MailIndentManagerReviewLC BUFF--- is :: [%s] ..\n",buff);fflush(stdout);
								system(buff);
							}
						}
					}

					return error_code;
				}
				
			int MailIndentChiefEnggReviewLC(EPM_action_message_t msg)
				{
					int error_code = ITK_ok;
					tag_t			root_task=NULLTAG;
					char*			CurrentTask				=NULL;
					char*			t5current_name				=NULL;
					char*			procedure_name				=NULL;
					tag_t Ind_PT_rel_type	= NULLTAG;

					tag_t *taskAttachments = NULLTAG;
					tag_t *parents = NULLTAG;
					tag_t IndLcmTag = NULLTAG;
					tag_t IndobjTag = NULLTAG;

					EPM_decision_t decision = EPM_go;
					int ifail=0,count=0,n_parents=0;
					int attachmentCount=0;
					int RSPcount=0;
					int NumOfAtchm=0;
					tag_t *IndRspy = NULLTAG;
					tag_t IndRspyTag = NULLTAG;
					char*			Indobjtype					= NULL;
					char *type_name7 = NULL;

					CALLAPI(EPM_ask_root_task(msg.task,&root_task));
					printf("\n\n\t\t Root task found for MailIndentChiefEnggReviewLC"); fflush(stdout);

					CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
					printf("\nCurrentTask:%s\n",CurrentTask);
					
					EPM_ask_attachments(root_task,EPM_target_attachment,&attachmentCount,&taskAttachments);
					printf("\nattachmentCount:[%d]",attachmentCount);
					if(attachmentCount > 0)
					{
						for (NumOfAtchm=0;NumOfAtchm<attachmentCount ;NumOfAtchm++ )
						{
						IndobjTag = taskAttachments[NumOfAtchm];
						
						WSOM_ask_object_type2(IndobjTag,&Indobjtype);
						printf("\n IndLcmTag type in Assign parti----->[%s]",Indobjtype); fflush(stdout);
					
						if(tc_strcasecmp(Indobjtype,"T5_ERCIndRevision")==0)
						{
							char*		IndentChfEng		= NULL;
							tag_t IndentChfEngTag = NULLTAG;
							tag_t person_tag = NULLTAG;
							
							AOM_ask_value_string(IndobjTag,"t5PrtIndChfEng",&IndentChfEng);
							printf("IndentChfEng ::  %s\n", IndentChfEng);fflush(stdout);
							
							if(SA_find_user2(IndentChfEng, &IndentChfEngTag)!=ITK_ok)PrintErrorStack();
							
							if(SA_ask_user_person (IndentChfEngTag,&person_tag)!=ITK_ok)PrintErrorStack();
							
							char* mailId = NULL;
							char*	eMailTo			= NULL;
							eMailTo=(char *) MEM_alloc(500 * sizeof(char *));
							char*	eMailCC			= NULL;
							eMailCC=(char *) MEM_alloc(500 * sizeof(char *));
							char  *buff 	= NULL;
							buff=(char *) MEM_alloc(2000 * sizeof(char *));
							char  *envSub	  = NULL;
							char  *envDesc	  = NULL;
							envSub = (char *) MEM_alloc( 250 * sizeof(char) );
							envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
							
							if(person_tag!=NULLTAG)
								{
									if(SA_ask_person_email_address(person_tag,&mailId)!=ITK_ok)PrintErrorStack();
									
									if(tc_strlen(mailId)>0)
									{
										printf("\n%s mailId: %s",mailId);
										if(tc_strstr(eMailTo, mailId)==NULL){
											tc_strcat(eMailTo,",");
											tc_strcat(eMailTo,mailId);
										}
									}
								}
								printf("\n Final mail to Chief Engg Review:  [%s]", eMailTo);fflush(stdout);
								char* IndNum = NULL;
								char* IndDummyRefNo = NULL;
								char* Indcurrent_desc = NULL;
								char* Indt5WBS = NULL;
								char* Indt5IndWbsDes = NULL;
								char* Indt5_IndPlatform = NULL;
								
								AOM_ask_value_string(IndobjTag,"item_id",&IndNum);
								printf("\n ERCDMLNum [%s]",IndNum);fflush(stdout);
								
								AOM_ask_value_string(IndobjTag,"t5DummyRefNo",&IndDummyRefNo);
			
								printf("\n IndDummyRefNo [%s]",IndDummyRefNo);fflush(stdout);
								
								AOM_ask_value_string(IndobjTag,"current_desc",&Indcurrent_desc);
			
								printf("\n Indcurrent_desc [%s]",Indcurrent_desc);fflush(stdout);
								
								AOM_ask_value_string(IndobjTag,"t5WBS",&Indt5WBS);
			
								printf("\n Indt5WBS [%s]",Indt5WBS);fflush(stdout);
								
								AOM_ask_value_string(IndobjTag,"t5IndWbsDes",&Indt5IndWbsDes);
			
								printf("\n Indt5IndWbsDes [%s]",Indt5IndWbsDes);fflush(stdout);
								
								AOM_ask_value_string(IndobjTag,"t5_IndPlatform",&Indt5_IndPlatform);
			
								printf("\n Indt5_IndPlatform [%s]",Indt5_IndPlatform);fflush(stdout);
				
				
								tc_strcpy(envSub,"Indent:");
								tc_strcat(envSub,IndNum);
								tc_strcat(envSub, " New Assignment recieved in your work list.");

								tc_strcpy(envDesc,"Dear All, ");
								
								tc_strcat(envDesc,"\n\nNew Assignment recieved in your work list");
								
								tc_strcat(envDesc,"\n\nIndent: ");
								tc_strcat(envDesc,IndNum);
								tc_strcat(envDesc,"\n\nUser Reference Number: ");
								tc_strcat(envDesc,IndDummyRefNo);
								tc_strcat(envDesc,"\n\nCurrent Description: ");
								tc_strcat(envDesc,Indcurrent_desc);
								tc_strcat(envDesc,"\n\nWork Breakdown Structure(WBS): ");
								tc_strcat(envDesc,Indt5WBS);
								tc_strcat(envDesc,"\n\nWBS Description: ");
								tc_strcat(envDesc,Indt5IndWbsDes);
								tc_strcat(envDesc,"\n\nIndent Platform: ");
								tc_strcat(envDesc,Indt5_IndPlatform);
								
								tc_strcat(envDesc,"\n\n Regards");
								tc_strcat(envDesc,"\n PLM Team,\n\n");

								printf("\n\nMAIL_initialize\n\n");
								printf("\n\nMAIL_initialize\n\n");
								
								tc_strcpy(eMailCC,"renuka.deshpande@tatamotors.com");
								//tc_strcpy(eMailTo,"poonams.ttl@tatamotors.com");
								
								sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
								printf("\n MailIndentChiefEnggReviewLC BUFF--- is  :: [%s] ..\n",buff);fflush(stdout);
								system(buff);
						}
					}
				}

					return error_code;
				}
				int MailIndentProtoReviewLC(EPM_action_message_t msg)
				{
					int error_code = ITK_ok;
					tag_t			root_task=NULLTAG;
					char*			CurrentTask				=NULL;
				
					tag_t *taskAttachments = NULLTAG;
					tag_t *parents = NULLTAG;
					tag_t IndobjTag = NULLTAG;

					EPM_decision_t decision = EPM_go;
					int attachmentCount=0;
					int NumOfAtchm=0;
					char*			Indobjtype					= NULL;

					CALLAPI(EPM_ask_root_task(msg.task,&root_task));
					printf("\n\n\t\t Root task found for MailIndentProtoReviewLC"); fflush(stdout);

					CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
					printf("\nCurrentTask:%s\n",CurrentTask);
					
					EPM_ask_attachments(root_task,EPM_target_attachment,&attachmentCount,&taskAttachments);
					printf("\nattachmentCount:[%d]",attachmentCount);
					if(attachmentCount > 0)
					{
						for (NumOfAtchm=0;NumOfAtchm<attachmentCount ;NumOfAtchm++ )
						{
						IndobjTag = taskAttachments[NumOfAtchm];
						
						WSOM_ask_object_type2(IndobjTag,&Indobjtype);
						printf("\n IndobjTag type in Assign parti----->[%s]",Indobjtype); fflush(stdout);
					
					if(tc_strcasecmp(Indobjtype,"T5_ERCIndRevision")==0)
					{
						
						char* mailId = NULL;
						char*	eMailTo			= NULL;
						eMailTo=(char *) MEM_alloc(500 * sizeof(char *));
						char*	eMailCC			= NULL;
						eMailCC=(char *) MEM_alloc(500 * sizeof(char *));
						char  *buff 	= NULL;
						buff=(char *) MEM_alloc(2000 * sizeof(char *));
						char  *envSub	  = NULL;
						char  *envDesc	  = NULL;
						envSub = (char *) MEM_alloc( 250 * sizeof(char) );
						envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
						
						
						
						tc_strcpy(eMailTo,"");
						char		*IndentGrpName		= NULL;
						IndentGrpName = (char	*)MEM_alloc(100);
						tc_strcpy(IndentGrpName,"Indent_Participants_Group");
						printf("\n MT: IndentGrpName  --> %s\n",IndentGrpName);   fflush(stdout);
						char		*IndentRoleName		= NULL;
						
						AOM_ask_value_string(IndobjTag,"t5Indentee",&IndentRoleName);
						printf("\n IndentRoleName [%s]",IndentRoleName);fflush(stdout);
						
						tag_t		BU_Grp_tag				=  NULLTAG;
						tag_t		BU_role_tag				=  NULLTAG;
						tag_t		Proto_user_tag	    = NULLTAG;
						tag_t*		Proto_Members	    = NULLTAG;
						tag_t person_tag = NULLTAG;
						
						int member_count = 0;
						int mem_count = 0;
						if(SA_find_group(IndentGrpName, &BU_Grp_tag)!=ITK_ok);
						if(SA_find_role2(IndentRoleName,&BU_role_tag)!=ITK_ok);
						if(SA_find_groupmember_by_role(BU_role_tag,BU_Grp_tag,&member_count,&Proto_Members)!=ITK_ok);
						TC_write_syslog("Proto_Members member_count ::  %d\n", member_count);
						printf("Proto_Members member_count ::  %d\n", member_count);fflush(stdout);

						if(member_count > 0)
						{
							for(mem_count=0; mem_count<member_count; mem_count++)
							{	
								if(SA_ask_groupmember_user(Proto_Members[mem_count], &Proto_user_tag)!=ITK_ok);							
								
								if(SA_ask_user_person (Proto_user_tag,&person_tag)!=ITK_ok)PrintErrorStack();
									if(person_tag!=NULLTAG)
									{
										if(SA_ask_person_email_address(person_tag,&mailId)!=ITK_ok)PrintErrorStack();
										if(tc_strlen(mailId)>0)
										{
											printf("\n%s mailId: %s",mailId);
											if(tc_strstr(eMailTo, mailId)==NULL){
												tc_strcat(eMailTo,",");
												tc_strcat(eMailTo,mailId);
											}
										}
									}
							}
							
						}
						
							printf("\n Final mail to MailIndentProtoReviewLC:  [%s]", eMailTo);fflush(stdout);
							char* IndNum = NULL;
							char* IndDummyRefNo = NULL;
							char* Indcurrent_desc = NULL;
							char* Indt5WBS = NULL;
							char* Indt5IndWbsDes = NULL;
							char* Indt5_IndPlatform = NULL;
							
							AOM_ask_value_string(IndobjTag,"item_id",&IndNum);
							printf("\n ERCDMLNum [%s]",IndNum);fflush(stdout);
							
							AOM_ask_value_string(IndobjTag,"t5DummyRefNo",&IndDummyRefNo);
		
							printf("\n IndDummyRefNo [%s]",IndDummyRefNo);fflush(stdout);
							
							AOM_ask_value_string(IndobjTag,"current_desc",&Indcurrent_desc);
		
							printf("\n Indcurrent_desc [%s]",Indcurrent_desc);fflush(stdout);
							
							AOM_ask_value_string(IndobjTag,"t5WBS",&Indt5WBS);
		
							printf("\n Indt5WBS [%s]",Indt5WBS);fflush(stdout);
							
							AOM_ask_value_string(IndobjTag,"t5IndWbsDes",&Indt5IndWbsDes);
		
							printf("\n Indt5IndWbsDes [%s]",Indt5IndWbsDes);fflush(stdout);
							
							AOM_ask_value_string(IndobjTag,"t5_IndPlatform",&Indt5_IndPlatform);
		
							printf("\n Indt5_IndPlatform [%s]",Indt5_IndPlatform);fflush(stdout);
			
			
							tc_strcpy(envSub,"");
							tc_strcpy(envDesc,"");
							tc_strcpy(envSub,"Indent:");
							tc_strcat(envSub,IndNum);
							tc_strcat(envSub, " New Assignment recieved in your work list.");

							tc_strcpy(envDesc,"Dear All, ");
							
							tc_strcat(envDesc,"\n\nNew Assignment recieved in your work list");
							
							tc_strcat(envDesc,"\n\nIndent: ");
							tc_strcat(envDesc,IndNum);
							tc_strcat(envDesc,"\n\nUser Reference Number: ");
							tc_strcat(envDesc,IndDummyRefNo);
							tc_strcat(envDesc,"\n\nCurrent Description: ");
							tc_strcat(envDesc,Indcurrent_desc);
							tc_strcat(envDesc,"\n\nWork Breakdown Structure(WBS): ");
							tc_strcat(envDesc,Indt5WBS);
							tc_strcat(envDesc,"\n\nWBS Description: ");
							tc_strcat(envDesc,Indt5IndWbsDes);
							tc_strcat(envDesc,"\n\nIndent Platform: ");
							tc_strcat(envDesc,Indt5_IndPlatform);
							
							tc_strcat(envDesc,"\n\n Regards");
							tc_strcat(envDesc,"\n PLM Team,\n\n");

							printf("\n\nMAIL_initialize\n\n");
							printf("\n\nMAIL_initialize\n\n");
							
							tc_strcpy(eMailCC,"renuka.deshpande@tatamotors.com");
							//tc_strcpy(eMailTo,"poonams.ttl@tatamotors.com");
							
							sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
							printf("\n MailIndentProtoReviewLC BUFF--- is :: [%s] ..\n",buff);fflush(stdout);
							system(buff);
					}
				}
				}

					return error_code;
				}
				EPM_decision_t Chk_DsgnRevObjs_Indent(EPM_rule_message_t msg)
				{
					EPM_decision_t decision = EPM_go;
					int				attachmentCount,count		= 0;
					logical			epmmsg						= false;	
					tag_t			rootTask_t					= NULLTAG;
					tag_t			objTag						= NULLTAG;
					tag_t			relation					= NULLTAG;

					tag_t*			taskAttachments				= NULLTAG;
					tag_t*			secondary_list				= NULLTAG;

					char*			obj_type					= NULL;
					char*			type_name2					= NULL;
					char*			IndentCategory					= NULL;

					printf("\n Inside Chk_DsgnRevObjs_Indent \n");fflush(stdout);
					
					EPM_ask_root_task(msg.task,&rootTask_t);
					EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments);
					TC_write_syslog("\nattachmentCount  :: %d",attachmentCount);

					GRM_find_relation_type("T5ERCDtl", &relation);

					if(attachmentCount > 0)
					{
						objTag = taskAttachments[0];
					}

					if(objTag != NULLTAG)
					{
						WSOM_ask_object_type2(objTag,&obj_type);
						TC_write_syslog("obj_type :: %s",obj_type);

						if(tc_strcasecmp(obj_type,"T5_ERCIndRevision")==0)
						{			
							AOM_ask_value_string(objTag,"t5PrtIndCat",&IndentCategory);
							TC_write_syslog("IndentCategory == %s \n", IndentCategory);
							 if (tc_strcmp(IndentCategory,"Non PLM Parts") == 0)
							 {
								 TC_write_syslog("\n Indent is Non PLM Parts type No need to attach Part to Indent\n");
								 printf("\n Indent is Non PLM Parts type No need to attach Part to Indent\n");fflush(stdout);
								 return EPM_go;
							 }
							else
							{
								GRM_list_secondary_objects_only(objTag, relation, &count, &secondary_list);
								
								TC_write_syslog("\ncount  :: %d",count);

								if(count > 0)
								{
									TC_write_syslog(" TRUE... \n");
									epmmsg = true;
									return EPM_go;				
								}			

								if(epmmsg == false)
								{
									TC_write_syslog("\nItems not availble in ERC Indent. Hence returning EPM_nogo.Kindly attached Items in Indent\n");
									printf("\nItems not availble in ERC Indent. Hence returning EPM_nogo.Kindly attached Items in Indent\n");fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITEMS_NOTFOUND_INDENT,"Please attach Item Revisions in Indents Has Parts relationship with Indent.");
									return EPM_nogo;
								}
							}
						}
					}

					printf("\n Exit Chk_DsgnRevObjs_Indent \n");fflush(stdout);

				}

				extern DLLAPI int  save_method_17(METHOD_message_t *msg, va_list args)
				{

						int		error_code				=	ITK_ok;
						int		desclength				=	0;
						int		revdesccnt				=	0;
						int		prt_seq				=	0;

						tag_t	objTag					=	va_arg(args, tag_t);
						tag_t	objTypeTag				=	NULLTAG;
						tag_t	priObjTag				=	NULLTAG;
						tag_t	priObjTypeTag			=	NULLTAG;
						tag_t	secObjTag				=	NULLTAG;
						tag_t	secObjTypeTag			=	NULLTAG;

						//char   type_name[TCTYPE_name_size_c+1];
						//char   type_name1[TCTYPE_name_size_c+1];
						//char   type_name2[TCTYPE_name_size_c+1];

						char	*desid					=	NULL;   
						char	*type_name					=	NULL;   
						char	*type_name1					=	NULL;   
						char	*type_name2					=	NULL;   
						char	*prtnumber					=	NULL;   
						char	*DesRevDesc				=	NULL;
						char	*ReplacedDesRevDesc		=	NULL;
						char	*NewReplacedDescription	=	NULL;
						char	*ItemMaterial			=	NULL;
						char	*DrwName				=	NULL;
						char	*FileName				=	NULL;
						char	*t5ApplOwnerDValCheckss				=	NULL;
						char	*t5ApplOwnerDValCheckss11				=	NULL;
				   



					  EPM_decision_t decision=EPM_go;

					  printf("\n save_method_17::It's the time to save IMAN_specification relation \n");fflush(stdout);


					  if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
					  if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
					  printf("\n save_method_17::type_name :%s\n", type_name);fflush(stdout);


					  if (GRM_ask_primary (objTag,&priObjTag)!=ITK_ok);
					  if (TCTYPE_ask_object_type(priObjTag,&priObjTypeTag)!=ITK_ok);
					  if (TCTYPE_ask_name2(priObjTypeTag,&type_name1)!=ITK_ok);
					  printf("\n save_method_17::pri_type_name :%s\n", type_name1);fflush(stdout);

					  if (GRM_ask_secondary (objTag,&secObjTag)!=ITK_ok);
					  if (TCTYPE_ask_object_type(secObjTag,&secObjTypeTag)!=ITK_ok);
					  if (TCTYPE_ask_name2(secObjTypeTag,&type_name2)!=ITK_ok);
					  printf("\n save_method_17::sec_type_nameAPPown :%s\n", type_name2);fflush(stdout);

					  
					  if( AOM_ask_value_string(priObjTag,"t5_ApplicationOwner",&t5ApplOwnerDValCheck)!=ITK_ok);
					  printf("\n Before saving re;ation of dataset t5ApplOwnerDValCheck %s\n", t5ApplOwnerDValCheck);fflush(stdout);
					  if( AOM_ask_value_string(priObjTag,"item_id",&prtnumber)!=ITK_ok);
						if( AOM_ask_value_int(priObjTag,"sequence_id",&prt_seq)==ITK_ok)

					  printf("\n Before saving relation of dataset t5ApplOwnerDValCheck %s for part %s  %d and now the dataset in process is %s \n", t5ApplOwnerDValCheck,prtnumber,prt_seq,type_name2);fflush(stdout);

					  
					 if (tc_strcmp(t5ApplOwnerDValCheck,"")==0)
					{
						 printf("\n t5ApplOwnerDValCheck is not set");fflush(stdout);
						 if((tc_strcmp(type_name2,"ProPrt")==0) || (tc_strcmp(type_name2,"ProAsm")==0) || (tc_strstr(type_name2,"Creo")!=NULL) )
						{
							 //set proE value
							if(AOM_lock(secObjTag))PrintErrorStack();
							if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD","ProEPart")!=ITK_ok);
							printf("\n ProAsm first AOM_set_value_string for app owner: ProEPart \n");fflush(stdout);
							if(AOM_save_without_extensions(secObjTag))PrintErrorStack();
							printf("\n ProAsm first save..\n");fflush(stdout);
							if(AOM_unlock(secObjTag))PrintErrorStack();
							printf("\n ProAsm first unlock..\n");fflush(stdout);	
							if(AOM_refresh(secObjTag,TRUE))PrintErrorStack();
							if( AOM_ask_value_string(secObjTag,"t5_ApplicationOwnerD",&t5ApplOwnerDValCheckss11)!=ITK_ok);
							printf("\n after dataset t5ApplOwnerDValCheckD %s\n", t5ApplOwnerDValCheckss11);fflush(stdout);
							if( AOM_ask_value_string(priObjTag,"t5_ApplicationOwner",&t5ApplOwnerDValCheckss)!=ITK_ok);
							printf("\n after saving relation of dataset t5ApplOwnerDValCheck %s\n", t5ApplOwnerDValCheckss);fflush(stdout);
							 
						}
						else if ((tc_strcmp(type_name2,"CMI2Part")==0) || (tc_strcmp(type_name2,"Cat-Part")==0))
						{
							//cat-part
							if(AOM_lock(secObjTag))PrintErrorStack();
							if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD","Cat-Part")!=ITK_ok);
							printf("\n in CMI2Part AOM_set_value_string for app owner: Cat-Part \n");fflush(stdout);
							if(AOM_save_without_extensions(secObjTag))PrintErrorStack();
							printf("\n in CMI2Part save..\n");fflush(stdout);
							if(AOM_unlock(secObjTag))PrintErrorStack();
							printf("\n in CMI2Part unlock..\n");fflush(stdout);	
							if(AOM_refresh(secObjTag,TRUE))PrintErrorStack();
							if( AOM_ask_value_string(secObjTag,"t5_ApplicationOwnerD",&t5ApplOwnerDValCheckss11)!=ITK_ok);
							printf("\n after dataset t5ApplOwnerDValCheckD %s\n", t5ApplOwnerDValCheckss11);fflush(stdout);
							if( AOM_ask_value_string(priObjTag,"t5_ApplicationOwner",&t5ApplOwnerDValCheckss)!=ITK_ok);
							printf("\n after saving relation of dataset t5ApplOwnerDValCheck %s\n", t5ApplOwnerDValCheckss);fflush(stdout);
						}
						else if (tc_strcmp(type_name2,"Cat-Product")==0|| tc_strcmp(type_name2,"CMI2Product")==0)
						{
							if(AOM_lock(secObjTag))PrintErrorStack();
							if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD","Cat-Product")!=ITK_ok);
							printf("\n in CMI2Product AOM_set_value_string for app owner: Cat-Product \n");fflush(stdout);
							if(AOM_save_without_extensions(secObjTag))PrintErrorStack();
							printf("\n in CMI2Product save..\n");fflush(stdout);
							if(AOM_unlock(secObjTag))PrintErrorStack();
							printf("\n in CMI2Product unlock..\n");fflush(stdout);	
							if(AOM_refresh(secObjTag,TRUE))PrintErrorStack();
							if( AOM_ask_value_string(secObjTag,"t5_ApplicationOwnerD",&t5ApplOwnerDValCheckss11)!=ITK_ok);
							printf("\n after dataset t5ApplOwnerDValCheckD %s\n", t5ApplOwnerDValCheckss11);fflush(stdout);
							if( AOM_ask_value_string(priObjTag,"t5_ApplicationOwner",&t5ApplOwnerDValCheckss)!=ITK_ok);
							printf("\n after saving relation of dataset t5ApplOwnerDValCheck %s\n", t5ApplOwnerDValCheckss);fflush(stdout);
							
						}


						else if (tc_strcmp(type_name2,"T5_Alias")==0) 
						{
							if(AOM_lock(secObjTag))PrintErrorStack();
							if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD","Alias")!=ITK_ok);
							printf("\n in Alias AOM_set_value_string for app owner: Alias\n");fflush(stdout);
							if(AOM_save_without_extensions(secObjTag))PrintErrorStack();
							printf("\n in Alias save..\n");fflush(stdout);
							if(AOM_unlock(secObjTag))PrintErrorStack();
							printf("\n in Alias unlock..\n");fflush(stdout);	
							if(AOM_refresh(secObjTag,TRUE))PrintErrorStack();
							if( AOM_ask_value_string(secObjTag,"t5_ApplicationOwnerD",&t5ApplOwnerDValCheckss11)!=ITK_ok);
							printf("\n after Alias dataset t5ApplOwnerDValCheckD %s\n", t5ApplOwnerDValCheckss11);fflush(stdout);
							if( AOM_ask_value_string(priObjTag,"t5_ApplicationOwner",&t5ApplOwnerDValCheckss)!=ITK_ok);
							printf("\n after saving relation of Alias dataset t5ApplOwnerDValCheck %s\n", t5ApplOwnerDValCheckss);fflush(stdout);
							
						}  

						
						/*if( (tc_strcmp(type_name2,"CMI2Part")!=0 ) && (tc_strcmp(type_name2,"CMI2Product")!=0 ) && (tc_strcmp(type_name2,"ProPrt")!=0 ) && (tc_strcmp(type_name2,"ProAsm")!=0 ))
						{
							printf("\n No CMI2Part/CMI2Product/ProPrt/ProAsm� Dataset found ..\n");fflush(stdout);
							if(AOM_lock(secObjTag))PrintErrorStack();
							if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD",t5ApplOwnerDValCheck)!=ITK_ok);
							printf("\n AOM_set_value_string for app owner: ProEAsm \n");fflush(stdout);
							if(AOM_save_without_extensions(secObjTag))PrintErrorStack();
							printf("\n save..\n");fflush(stdout);
							if(AOM_unlock(secObjTag))PrintErrorStack();
							printf("\n unlock..\n");fflush(stdout);	
						}*/

					}
					else
					{printf("\n t5ApplOwnerDValCheck is set not going to update it in this loop");fflush(stdout);}

					

					  return error_code;
				}

				//adk

				extern DLLAPI int  save_method_19(METHOD_message_t *msg, va_list args)
				{
						
									
						tag_t	objTag					=	va_arg(args, tag_t);
						tag_t	objTypeTag				=	NULLTAG;
						tag_t	priObjTag				=	NULLTAG;
						tag_t	priObjTypeTag			=	NULLTAG;
						tag_t	secObjTag				=	NULLTAG;
						tag_t	secObjTypeTag			=	NULLTAG;
						char* sObj_string = NULL;
						char* sGov_classif = NULL;
						char* type_name1 = NULL;
						char* type_name = NULL;
						char* type_name2 = NULL;

						//char   type_name[TCTYPE_name_size_c+1];
						//char   type_name1[TCTYPE_name_size_c+1];
						//char   type_name2[TCTYPE_name_size_c+1];

					  if (GRM_ask_primary (objTag,&priObjTag)!=ITK_ok);
					  if (TCTYPE_ask_object_type(priObjTag,&priObjTypeTag)!=ITK_ok);
					  if (TCTYPE_ask_name2(priObjTypeTag,&type_name1)!=ITK_ok);
			   
					   if( AOM_ask_value_string(priObjTag,"object_string",&sObj_string)!=ITK_ok); fflush(stdout);
					   printf("\n object_string Color Scheme Is :   %s",sObj_string);fflush(stdout);
					   if( AOM_ask_value_string(priObjTag,"gov_classification",&sGov_classif)!=ITK_ok); fflush(stdout);
					   printf("\n For Revise gov_classification:   %s",sGov_classif);fflush(stdout);
							if (tc_strcmp(sGov_classif,"Revise") != 0)
							{
							
							int n_entries0 =2;
							tag_t	Cntl_obj_Qtag0	=	NULLTAG;
							char *qry_entries0[2] = {"SYSCD","SUBSYSCD"};
							char **qry_values0 = (char **) MEM_alloc(50 * sizeof(char *));
							int resultCount0=0;
							tag_t *qry_cntrlobj0= NULLTAG;
							char *userinfo0=NULL;
							char *group_name;
							tag_t group_tag = NULLTAG;


						if(QRY_find2("Control Objects...", &Cntl_obj_Qtag0));
					
						qry_values0[0] = "GROUPSVRREL" ;
						qry_values0[1] = "GROUPSVRREL" ;
					
						if(QRY_execute(Cntl_obj_Qtag0, n_entries0, qry_entries0, qry_values0, &resultCount0, &qry_cntrlobj0)!=ITK_ok);
						printf("\n ITEM_find replaced-- upgrade activity12.2  resultCount0 %d",resultCount0);fflush(stdout);
						if (resultCount0 > 0)
						{
						
						if(AOM_ask_value_string(qry_cntrlobj0[0],"t5_Userinfo1",&userinfo0)!=ITK_ok);
					
					  if(tc_strcmp(userinfo0,"ON")==0)
						{
						   POM_ask_group(&group_name, &group_tag);
						 if((tc_strcmp(group_name, "Vehicle_Integration") != 0))
							{                      
							 EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_PLMError,"Unable to create Relation. Please set the  Vehicle_Integration for creatiing Color scheme and SVR relation  ");
							return ITK_PLMError;
					
							}
					
						}
					 }			

						tag_t tRelationFind ,Rel_task= NULLTAG;
						tag_t	HasclrsvrRelation		= NULLTAG; 
						tag_t	LatestRev		= NULLTAG; 
						tag_t	ref_item		= NULLTAG;  
						char* RevL				= NULL;			 
						char* object_name1		= NULL;	 
						char* ver_name			= NULL;		 
						char* item_id1			= NULL;	 		
						char *sColourSeq				=	NULL;
						char *sColourSeqall		= NULL;	
						char *sdrpdSVRname				=	NULL;
						char *sClrSchemeREVName				=	NULL;
						char *sClrSchemeOnlyREVName				=	NULL;
						char *sClrSchemeName				=	NULL;
						char *stestname				=	NULL;
						char *sdrpdSVRDesc				=	NULL;
						char *	expression;
						char *	tmpstring;
						char *sCustomExpression= NULL;
						char *sCustomExpression2= NULL;
						char *sCustomExpression3= NULL;
						char *sCustomExpressiontmp= NULL;
						sCustomExpression=MEM_alloc(30000);
						sCustomExpression2=MEM_alloc(30000);
						sCustomExpression3=MEM_alloc(30000);
						char *sCustomExpWithColrSchm= NULL;
						sCustomExpWithColrSchm=MEM_alloc(30000);
						char *scolourSchExpr= NULL;
						scolourSchExpr=malloc(80);
						char *scolourSchExpr1= NULL;
						scolourSchExpr1=malloc(80);
						tag_t vrule=NULLTAG;
						char *sNewSvrName= NULL;
						sNewSvrName=malloc(30);
						char *sNewSvrdesc= NULL;
						sNewSvrdesc=malloc(240);
						strcpy(sNewSvrName,"");	
						strcpy(sNewSvrdesc,"");	
						char *ErrorString = NULL;
						char *ErrorStringSVR = NULL;
						char			*user_id				= NULL;

						tag_t
						QryOptionValue = NULLTAG,
						*OptionValues = NULL;
						int	n_entries = 2;
						int n_found = 0;

					char *qry_entries[2] = {"Thread ID", "ID"};
					char **qry_values    = (char **) MEM_alloc(2 * sizeof(char *));
					//char *qry_values[2] = {"TOOLTYPE", "*"};
				tag_t new_relation = NULLTAG;
				tag_t
						QryVariantRule = NULLTAG,
						*VariantTags = NULL;
						int	n_entris = 1;
						int n_foundc = 0;
					char *qry_entries_Variant[1] = {"Name"};
					char **qry_values_Variant   = (char **) MEM_alloc(1 * sizeof(char *));
							

						tag_t* tags ;
						tag_t	item_tag		= NULLTAG; 
						
								int countV= 0;
						int k= 0;
						int count= 0;
						tag_t  *secondary_objects,primary;
						tag_t objTypeTagDi=NULLTAG;
						//char   type_name3[TCTYPE_name_size_c+1];
						char *type_name3	=	NULL;
						 tag_t VariqueryTag = NULLTAG;

				char * 	formula ;
				//Aashish_w
							int n_entries11 =2;
							tag_t	Cntl_obj_Qtag11	=	NULLTAG;
							char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
							char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
							int resultCount11=0;
							tag_t *qry_cntrlobj11= NULLTAG;
							char *userinfo11=NULL;

							int n_entries111 =2;
							tag_t	Cntl_obj_Qtag111	=	NULLTAG;
							char *qry_entries111[2] = {"SYSCD","SUBSYSCD"};
							char **qry_values111 = (char **) MEM_alloc(50 * sizeof(char *));
							int resultCount111=0;
							tag_t *qry_cntrlobj111= NULLTAG;
							char *userinfo111=NULL;
							char *Variantname				=	NULL;
							char *myvarientname				=	NULL;
							tag_t  relation_dep	= NULLTAG;

					tag_t ApplSvrRelType =	NULLTAG;
					tag_t ASReltag = NULLTAG;
					char *AssociateInfoStr=NULL;
					char *pltfrm				=	NULL;
						printf("\n in save method 19 \n");fflush(stdout);

						  if (POM_get_user_id(&user_id)!=ITK_ok);

						printf("\n Inside save method 19 curent login user is ==> [ %s ] \n",user_id);fflush(stdout);
					
					printf("\n ITEM_find replaced-- upgrade activity");fflush(stdout);

						if(tc_strcmp(user_id,"loader")!=0)
					{
					
						printf("\n query checking upgrade activity12.2");fflush(stdout);
							if(QRY_find2("Control Objects...", &Cntl_obj_Qtag111));

									qry_values111[0] = "CLRSVRBlank" ;
									qry_values111[1] = "CLRSVRBlank" ;

						if(QRY_execute(Cntl_obj_Qtag111, n_entries111, qry_entries111, qry_values111, &resultCount111, &qry_cntrlobj111)!=ITK_ok);
						printf("\n ITEM_find replaced-- upgrade activity12.2  resultCount111 %d",resultCount111);fflush(stdout);
						if(AOM_ask_value_string(qry_cntrlobj111[0],"t5_Userinfo1",&userinfo111)!=ITK_ok);
						printf("\n ITEM_find replaced-- upgrade activity12.2");fflush(stdout);
							if(tc_strcmp(userinfo111,"Y")==0)
				{
					
					int n_entriesObs=1;
					tag_t queryTagObs		= NULLTAG;
					char **qry_valuesObs = (char **) MEM_alloc(10 * sizeof(char *));
					printf("\n else ITEM_find replaced by QRY_find2");fflush(stdout);
					if(QRY_find2("Platform", &queryTagObs));
					if (queryTagObs)
					{
					printf("\nPlatform Found Query General ");
					fflush(stdout);
					}
					else
					{
					printf("\n Platform:Not Found Query General \n");
					fflush(stdout);
					}

					 // if (GRM_ask_primary (objTag,&priObjTag)!=ITK_ok);
					 // if (TCTYPE_ask_object_type(priObjTag,&priObjTypeTag)!=ITK_ok);
					 // if (TCTYPE_ask_name2(priObjTypeTag,type_name1)!=ITK_ok);
					   
					   if (priObjTag!=NULLTAG)
						   {
							AOM_UIF_ask_value(priObjTag,"t5_SchmPlant",&pltfrm);	
							printf("\n\t Platform = %s \n", pltfrm);fflush(stdout);
						   }

					char *qry_entriesObs[1] = {"ID"};
					qry_valuesObs[0] = pltfrm ;

					if(QRY_execute(queryTagObs,n_entriesObs,qry_entriesObs,qry_valuesObs,&count,&tags));
					printf("\n11 else Unique Platform Query count :%d:\n", count); fflush(stdout);

					if ( count > 0 )
					{
						printf("\nX4 Found");
						item_tag = tags[0];
					
					}
					else
					{
						printf("\nX4 NOT Found");
					}
					

					 if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
					  if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
					  printf("\n save_method_19::type_name :%s\n", type_name);fflush(stdout); 
						  
						  if (GRM_ask_secondary (objTag,&secObjTag)!=ITK_ok);
						  //Added by Aashish_w
						if(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));

									qry_values11[0] = "Project" ;
									qry_values11[1] = "AltrozWay" ;

						QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11);
							AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo1",&userinfo11);
							printf("\n **************** User Info 1 ===> %s **************** \n",userinfo11);fflush(stdout);
							
						if( AOM_ask_value_string(secObjTag,"object_name",&Variantname)!=ITK_ok); fflush(stdout);
						printf("\n **************** Base Varient Rule Name ===> %s **************** \n",Variantname);fflush(stdout);
						myvarientname = subString(Variantname,0,4);	
									printf("\n **************** MY Varient Name ===> %s **************** \n",myvarientname);fflush(stdout);
				  
				//Start Finction if Gajanan
							int		 n_entriesgr					= 1;
							int		 n_foundgr					= 0;
							int		 i;
							tag_t	querygr						= NULLTAG;
							tag_t   *CntrlObject_Taggr			= NULLTAG;
							char*	 sUsrInfogr					= NULL;	
							char    *qry_entriesgr[1]	=	{"SYSCD"};
							char    **qry_valuesgr    =  (char **) MEM_alloc(50 * sizeof(char *));	
							QRY_find2("ControlObjQry",&querygr);
							qry_valuesgr[0] = "SVR_CLR_SCHEME_REL_IF";
							QRY_execute(querygr, n_entriesgr, qry_entriesgr, qry_valuesgr, &n_foundgr, &CntrlObject_Taggr);
							printf("\n\tControl Object SVR_CLR_SCHEME_REL_IF count found  %d\n",n_foundgr);

						if(n_foundgr>0)
						{				
							AOM_ask_value_string(CntrlObject_Taggr[0],"t5_Userinfo1",&sUsrInfogr);
							printf("\n\t Control Object value   %s\n",sUsrInfogr);
						if (tc_strcmp(sUsrInfogr,"SVR_CLR_SCHEME_REL_IF")==0)
						{
								
						childParts =	(char *) MEM_alloc(40000);
						FullAdvString		= (char *) MEM_alloc(60000);
						FullAdvString1		= (char *) MEM_alloc(60000);
						FullAdvString2		= (char *) MEM_alloc(40000);
						sTempItemID		    = (char *) MEM_alloc(50);
						sTempItemRev		= (char *) MEM_alloc(50);

						//int					n_entry				= 1;
						//int					rsltCount			= 0;
						//int					ifail				= ITK_ok;
						//int					CmpVcCnt			= 0;
						char				* Platform			= NULL;
						char				* SVR				= NULL;
						char				* RevisionRule		= NULL;
						char				* ClrSCMID			= NULL;
						//char				* userName			= NULL;
						//char				* userPass		    = NULL;
						//char				* userGrp        	= NULL;				
						//char				* DR_objNo			= NULL;
						//char				* DR_Item_id		= NULL;
						//char				* VehId				= NULL;
						//char				Data[100]			= "";			
						//char				*test				= (char*)MEM_alloc(sizeof (char) * 200);
						//char				*Percentage				= (char*)MEM_alloc(sizeof (char) * 100);
						//char				*qry_entry[1]		= {"Name"};
						//char				**qry_values2		= (char **) MEM_alloc(10 * sizeof(char *));

						//tag_t	SchemeItag			= NULLTAG;
						//tag_t	ColSchmRevTag		= NULLTAG;
						//tag_t	RelType				= NULLTAG;
						//tag_t	Reltag				= NULLTAG;
						//tag_t	CmpCodeObj			= NULLTAG;
						//tag_t	*AppliSvrsRelTags	= NULLTAG;


						//Platform				= ITK_ask_cli_argument("-Platform=");
						//SVR						= ITK_ask_cli_argument("-SVR=");
						//RevisionRule			= ITK_ask_cli_argument("-RevisionRule=");
						//ClrSCMID				= ITK_ask_cli_argument("-ColorSCM=");
						//userName				= ITK_ask_cli_argument("-u=");
						//userPass				= ITK_ask_cli_argument("-pf=");
						//userGrp					= ITK_ask_cli_argument("-g=");

						
						//printf("\n\t INSIDE MAIN FUN \n");fflush(stdout);
						//ITK_auto_login();
						//ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
						
						//provide access.
						//ITK_CALL(ITK_set_bypass(true));

						//if (ITEM_find_item(ColorSCM,&SchemeItag)!=ITK_ok);
						//if (ITEM_ask_latest_rev(SchemeItag,&ColSchmRevTag)!=ITK_ok);
						if (priObjTag!=NULLTAG)
						   {
							AOM_UIF_ask_value(priObjTag,"item_id",&ClrSCMID);
							AOM_UIF_ask_value(priObjTag,"t5_SchmPlant",&Platform);	
							printf("\n\t Platform = %s \n", Platform);fflush(stdout);

							//if(GRM_find_relation_type("T5_Applicable_SVR",&RelType)!=ITK_ok);
							//if(GRM_list_secondary_objects_only(ColSchmRevTag,RelType,&CmpVcCnt,&AppliSvrsRelTags)!=ITK_ok);
							//if(CmpVcCnt>0)
							//{
							//	if(CmpCodeObj) CmpCodeObj=NULLTAG;
							//	CmpCodeObj=AppliSvrsRelTags[0];
							//if (AOM_UIF_ask_value(CmpCodeObj,"object_string",&SVR)!=ITK_ok);
							//}
							RevisionRule ="ERC release and above";
							printf("\n\t Scheme No = [%s]  and Color SVR  Variantname = [%s] and Revision Rule = [%s]\n",ClrSCMID,Variantname,RevisionRule);fflush(stdout);
							tc_strcat(childParts," ");
							tc_strcat(FullAdvString," ");
							tc_strcat(FullAdvString1," ");
							tc_strcat(FullAdvString2," ");

							ITK_CALL(BOMCorrect(Platform,Variantname,RevisionRule,priObjTag));

							printf("\n Before Printing  Eorror "); fflush(stdout);
							printf("\n %s  ",FullAdvString); fflush(stdout);
							if (tc_strcmp(FullAdvString,"NULL") != 0 && tc_strcmp(FullAdvString," ") != 0)
							{
								
							tc_strcat(FullAdvString1,"\nATTENTION : Relation between target Colour Scheme and given VC !!!  ");
							tc_strcat(FullAdvString1,"\nFollowing   BoM  mismatches are observed w.r.t. their  coloured child parts:");
							tc_strcat(FullAdvString1,FullAdvString);
							tc_strcat(FullAdvString1,"\nPlease check if a new Variant Colour scheme needs to be created or any existing scheme with same colour combination can be used . ");
							printf("\n Full Errorr %s  ",FullAdvString1); fflush(stdout);

							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_PLMError,FullAdvString1);
							printf("\n After  EMH_store_error_s1 "); fflush(stdout);

							return ITK_PLMError;

							printf("\n After Printing  Error "); fflush(stdout);


							}
							
						   }
						}
					}
				//End Finction if Gajanan

					if(strstr(userinfo11,myvarientname)!=NULL)
					{
							printf("\n **** Skipping for 5442 And live projects **** \n");fflush(stdout);
					}
					else
					{
						  if (TCTYPE_ask_object_type(secObjTag,&secObjTypeTag)!=ITK_ok);
					  
					  if (TCTYPE_ask_name2(secObjTypeTag,&type_name2)!=ITK_ok);
					  printf("\n save_method_19::sec_type_name :%s\n", type_name2);fflush(stdout);

					  BSLV_get_variant_expression(NULLTAG,secObjTag,&expression );PrintErrorStack();
					  printf("\n expression  =%s\n",expression);fflush(stdout);

					  if( AOM_ask_value_string(priObjTag,"object_name",&sClrSchemeName)!=ITK_ok); PrintErrorStack();
					   printf("\n sClrSchemeName name  =%s\n",sClrSchemeName);fflush(stdout);
					   

					  if( AOM_ask_value_string(priObjTag,"item_revision_id",&sClrSchemeREVName)!=ITK_ok); PrintErrorStack();
					   printf("\n sClrSchemeREVName name  =%s\n",sClrSchemeREVName);fflush(stdout);	
					   sClrSchemeOnlyREVName=strtok(sClrSchemeREVName,";");
						printf("\n Main Revision name  =%s\n",sClrSchemeOnlyREVName);fflush(stdout);

						printf("\n Query Values for Varient Start");fflush(stdout);
						tc_strcpy(scolourSchExpr1,"");
						tc_strcat(scolourSchExpr1,sClrSchemeName);
						 tc_strcat(scolourSchExpr1,"_");
						 tc_strcat(scolourSchExpr1,sClrSchemeOnlyREVName);
						 printf("\n Query Values for Varient =%s\n",scolourSchExpr1);fflush(stdout);

					   qry_values[0]=malloc(100);
					   qry_values[1]=malloc(100);
					   strcpy(qry_values[0],scolourSchExpr1);
					   strcpy(qry_values[1],"*");

						   strcpy(scolourSchExpr,"[Teamcenter]SCHEME-NO = ");
						  //  tc_strcat(scolourSchExpr,sClrSchemeName);
							
				//Aashish_w..
					printf("\n Base SVR expression Expr name  =%s\n",expression);fflush(stdout);

				//	if(tc_strstr(expression,"[Teamcenter]SCHEME-NO = NA") != NULL)
					if(tc_strstr(expression,"[Teamcenter]SCHEME-NO = NA"))
					{
						// IF NA is avaailble in BASE SVR 
						//skip by Aashish_w
						printf("Skip by aww917697 as NA is present in Base SVR");
						 tc_strcat(scolourSchExpr,sClrSchemeName);
						 tc_strcat(scolourSchExpr,"_");
						 tc_strcat(scolourSchExpr,sClrSchemeOnlyREVName);
					}
					else
					{	
					tc_strcat(scolourSchExpr,"NA");
					tc_strcat(scolourSchExpr," | ");
					tc_strcat(scolourSchExpr,"[Teamcenter]SCHEME-NO = ");
					tc_strcat(scolourSchExpr,sClrSchemeName);
					tc_strcat(scolourSchExpr,"_");
					tc_strcat(scolourSchExpr,sClrSchemeOnlyREVName);
					tc_strcat(scolourSchExpr,") & ");

					printf("scolourSchExpr ------------------> %s",&scolourSchExpr);

					if(tc_strstr(expression,"[Teamcenter]COLOUR-BOM = N"))
					{
					printf("\n in first if\n");fflush(stdout);	
					//MEM_free(sCustomExpression);
					//sCustomExpression=NULL;
					STRNG_replace_str(expression,"[Teamcenter]COLOUR-BOM = N","[Teamcenter]COLOUR-BOM = Y",&sCustomExpressiontmp);	PrintErrorStack();
					tc_strcpy(sCustomExpression,sCustomExpressiontmp);PrintErrorStack();

					}
					else if(tc_strstr(expression,"[Teamcenter]COLOUR-BOM = Y"))
					{
					printf("\n in 2nd if\n");fflush(stdout);
					tc_strcpy(sCustomExpression,expression);
					}
					else
					{
					printf("\n in 3rd if\n");fflush(stdout);
					tmpstring= tc_strstr(expression,"[Teamcenter]" )	;
					if(tmpstring != NULL)
					{
					 // tc_strncpy(sCustomExpression,expression,(tmpstring-expression)-2)	;
					 //tc_strncpy(sCustomExpression,expression,3)	;
					 //subString(sdrpdSVRname,0,8)
					// tc_strcat(sCustomExpression,subString(expression,0,3));	
						strcpy(sCustomExpression,"");
					  tc_strcat(sCustomExpression,"(((");	
					  printf("\n sCustomExpression 1 =%s\n",sCustomExpression);fflush(stdout);
					  tc_strcat(sCustomExpression,"[Teamcenter]COLOUR-BOM = Y & ");	
					  printf("\n sCustomExpression 2 =%s\n",sCustomExpression);fflush(stdout);
					  tc_strcat(sCustomExpression,tmpstring);
					  printf("\n sCustomExpression 3  =%s\n",sCustomExpression);fflush(stdout);
					}
					}
					}


					//custom exprssion with color scheme option value
					STRNG_replace_str(sCustomExpression,"[Teamcenter]SCHEME-NO = NA & ","",&sCustomExpression2);	PrintErrorStack();
					STRNG_replace_str(sCustomExpression2," & [Teamcenter]SCHEME-NO = NA","",&sCustomExpression3);	PrintErrorStack();
					tmpstring= tc_strstr(sCustomExpression3,"[Teamcenter]" )	;
					 if(tmpstring != NULL)
						{			
							strcpy(sCustomExpWithColrSchm,"");
						  tc_strcat(sCustomExpWithColrSchm,"((((");	
						 // printf("\n sCustomExpWithColrSchm 1 =%s\n",sCustomExpWithColrSchm);fflush(stdout);
						  tc_strcat(sCustomExpWithColrSchm,scolourSchExpr);	
						 // printf("\n sCustomExpWithColrSchm 2 =%s\n",sCustomExpWithColrSchm);fflush(stdout);
						  tc_strcat(sCustomExpWithColrSchm,tmpstring);
						  printf("\n sCustomExpWithColrSchm 3  =%s\n",sCustomExpWithColrSchm);fflush(stdout);
						}	 
					//end


					

					  if( AOM_ask_value_string(priObjTag,"t5_ClSrl",&sColourSeqall)!=ITK_ok);
							printf("\n  sColourSeqall %s\n", sColourSeqall);fflush(stdout);	

							sColourSeq=strtok(sColourSeqall,";");
							//sColourSeq = strtok( NULL, ";" );
							printf("\n  sColourSeq %s\n", sColourSeq);fflush(stdout);	


				///////
						printf("\n before VRULE_create\n");fflush(stdout);		
						//VRULE_create(sNewSvrName,"Amol Test Variant Rule",&vrule);	
						if(sColourSeq != NULL )		
						{
						  if( AOM_ask_value_string(secObjTag,"object_name",&sdrpdSVRname)!=ITK_ok); PrintErrorStack();
						printf("\n  sdrpdSVRname %s\n", sdrpdSVRname);fflush(stdout);
						printf("\n  substring test  %s\n", subString(sdrpdSVRname,0,8));fflush(stdout);
						printf("\n  substring last test  %s\n", subString(sdrpdSVRname,12,tc_strlen(sdrpdSVRname)-12));fflush(stdout);

						tc_strcat(sNewSvrName,subString(sdrpdSVRname,0,8));
						tc_strcat(sNewSvrName,"A");			
						tc_strcat(sNewSvrName,sColourSeq);
						tc_strcat(sNewSvrName,"R");
						tc_strcat(sNewSvrName,subString(sdrpdSVRname,12,tc_strlen(sdrpdSVRname)-12));

						printf("\n  sNewSvrName %s\n", sNewSvrName);fflush(stdout);

					 qry_values_Variant[0]=malloc(100);
					   strcpy(qry_values_Variant[0],sNewSvrName);
					
				//	if(QRY_find2("VariantRule", &QryVariantRule));
				//					if(QRY_execute(QryVariantRule, n_entris, qry_entries_Variant, qry_values_Variant, &n_foundc, &VariantTags));
				//					printf("\n Objects for Query __VariantRule == %d", n_foundc);fflush(stdout);
				//				 if(n_foundc>0)
				//				 {
				//					 		ErrorStringSVR=(char *) MEM_alloc(300);
				//							printf("After mem alloc\n");
				//							tc_strcpy (ErrorStringSVR, "Variant Rule");
				//							strcat(ErrorStringSVR,sNewSvrName);
				//							strcat(ErrorStringSVR," is already exist in system. Get it deleted first and then create this relation again.");
				//
				//					 EMH_store_error_s1( EMH_severity_error,ITK_err,ErrorStringSVR);
				//						return ITK_err;
				//				 }
				//
				//
				//
				//
				//		if( AOM_ask_value_string(secObjTag,"object_desc",&sdrpdSVRDesc)!=ITK_ok);
				//		tc_strcat(sNewSvrdesc,sdrpdSVRDesc);
				//		tc_strcat(sNewSvrdesc," [");
				//		tc_strcat(sNewSvrdesc,sColourSeq);
				//		tc_strcat(sNewSvrdesc,"]");
				//		if(tc_strlen(sNewSvrdesc)<27)
				//			{
				//				VRULE_create(sNewSvrName,sNewSvrdesc,&vrule);PrintErrorStack();
				//			}
				//			else
				//			{
				//				VRULE_create(sNewSvrName,sdrpdSVRDesc,&vrule);PrintErrorStack();
				//			}
				//		AOM_lock(vrule); printf("\t   "); fflush(stdout);PrintErrorStack();
				//		AOM_save_without_extensions(vrule); printf("\t   "); fflush(stdout);PrintErrorStack();
				//		AOM_refresh(vrule,0); printf("\t   "); fflush(stdout);PrintErrorStack();
				//		AOM_unlock(vrule);PrintErrorStack();
				//		}
				//		else
				//		{
				//			printf("\n sColourSeq is null 111\n");fflush(stdout);		
				//		}
				//		
				//		
				//		printf("\n After VRULE_create\n");fflush(stdout);
				//added by ashish_w
						if(QRY_find2("VariantRule", &QryVariantRule));
									if(QRY_execute(QryVariantRule, n_entris, qry_entries_Variant, qry_values_Variant, &n_foundc, &VariantTags));
									printf("\n Objects for Query __VariantRule == %d", n_foundc);fflush(stdout);
				//				 if(n_foundc>0)
				//				 {
				//					 		ErrorStringSVR=(char *) MEM_alloc(300);
				//							printf("After mem alloc\n");
				//							tc_strcpy (ErrorStringSVR, "Variant Rule");
				//							strcat(ErrorStringSVR,sNewSvrName);
				//							strcat(ErrorStringSVR," is already exist in system. Get it deleted first and then create this relation again.");
				//
				//					 EMH_store_error_s1( EMH_severity_error,ITK_err,ErrorStringSVR);
				//						return ITK_err;
				//				 }
						 if(n_foundc==0)
							{


						if( AOM_ask_value_string(secObjTag,"object_desc",&sdrpdSVRDesc)!=ITK_ok);
						tc_strcat(sNewSvrdesc,sdrpdSVRDesc);
						tc_strcat(sNewSvrdesc," [");
						tc_strcat(sNewSvrdesc,sColourSeq);
						tc_strcat(sNewSvrdesc,"]");
						if(tc_strlen(sNewSvrdesc)<27)
							{
								VRULE_create(sNewSvrName,sNewSvrdesc,&vrule);PrintErrorStack();
							}
							else
							{
								VRULE_create(sNewSvrName,sdrpdSVRDesc,&vrule);PrintErrorStack();
							}
						AOM_lock(vrule); printf("\t   "); fflush(stdout);PrintErrorStack();
						AOM_save_without_extensions(vrule); printf("\t   "); fflush(stdout);PrintErrorStack();
						AOM_refresh(vrule,0); printf("\t   "); fflush(stdout);PrintErrorStack();
						AOM_unlock(vrule);PrintErrorStack();

						printf("\n Creating Relation T5_HasColourSVR \n");fflush(stdout);

						//added by aashish_w for Has colour svr relation

						GRM_find_relation_type ("T5_HasColourSVR",&HasclrsvrRelation);PrintErrorStack();

						if(HasclrsvrRelation != NULLTAG)
							{
								(GRM_create_relation(secObjTag,vrule,HasclrsvrRelation,NULLTAG,&new_relation));
								if(new_relation != NULLTAG)
									{
									(GRM_save_relation(new_relation));
									}
							}

						printf("\n Created a new Relation T5_HasColourSVR \n");fflush(stdout);

							}
						}
						else
						{
							printf("\n sColourSeq is null 111\n");fflush(stdout);		
						}
						
						if(vrule==NULLTAG)
						{
							printf("\n  VRULE is already present... \n");fflush(stdout);
							vrule = VariantTags[0];
							printf("\n  assigning  VariantTags[0] to VRULE \n");fflush(stdout);
						}

						printf("\n After VRULE_create\n");fflush(stdout);

						GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep);
						if(relation_dep != NULLTAG)
						{
							printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);	
						}			

						GRM_list_secondary_objects_only(item_tag,relation_dep,&countV,&secondary_objects);PrintErrorStack();
						printf("\n Smc0HasVariantConfigContext countV :%d ..\n",countV); fflush(stdout);

						if (countV >0)		
						{
							for (k=0;k<countV ;k++ )
							{
								primary=secondary_objects[k];

								TCTYPE_ask_object_type(primary,&objTypeTagDi);PrintErrorStack();
								TCTYPE_ask_name2(objTypeTagDi,&type_name3); PrintErrorStack();
								printf("\n After VRULE_create--->%s\n",type_name3);fflush(stdout);

								if (strcmp(type_name3,"Cfg0ProductItem")==0)
								{
									if( AOM_ask_value_string(primary,"object_name",&stestname)!=ITK_ok); PrintErrorStack();
									printf("\n  sdrpdSVRname %s\n", stestname);fflush(stdout);

									printf("\n in Cfg0ProductItem\n");fflush(stdout);
									
									if(QRY_find2("__Cfg0OptionValuesFromValueIDs", &QryOptionValue));
									if(QRY_execute(QryOptionValue, n_entries, qry_entries, qry_values, &n_found, &OptionValues));
									printf("\n Objects for Query __Cfg0OptionValuesFromValueIDs == %d", n_found);fflush(stdout);
								 if(n_found>0)
									{
									 BSLV_set_variant_expression(primary,NULLTAG,vrule,sCustomExpWithColrSchm );PrintErrorStack(); // this is working line with colour scheme option value						
													printf("\n before expression_to_formula\n");fflush(stdout);

									 GRM_find_relation_type ("IMAN_reference",&tRelationFind);PrintErrorStack();
										if (vrule!=NULLTAG && primary!=NULLTAG)
										 { 
											printf("\n inside if loop \n");fflush(stdout);
											GRM_create_relation(primary,vrule,tRelationFind,NULLTAG,&Rel_task);PrintErrorStack();
											printf("\n inside if loop \n");fflush(stdout);
											AOM_load(Rel_task);
											printf("\nAOM_load-----\n");fflush(stdout);
											GRM_save_relation(Rel_task); PrintErrorStack();
											printf("\nRelation Created Successfully...\n");fflush(stdout);
										 }

									}
									else
									{
										
										BSLV_set_variant_expression(primary,NULLTAG,vrule,sCustomExpression );PrintErrorStack(); // this is working line without colour scheme option value						
										printf("\n before expression_to_formula\n");fflush(stdout);

									 GRM_find_relation_type ("IMAN_reference",&tRelationFind);PrintErrorStack();
										if (vrule!=NULLTAG && primary!=NULLTAG)
										 { 
											printf("\n inside if loop \n");fflush(stdout);
											GRM_create_relation(primary,vrule,tRelationFind,NULLTAG,&Rel_task);PrintErrorStack();
											printf("\n inside if loop \n");fflush(stdout);
											AOM_load(Rel_task);
											printf("\nAOM_load-----\n");fflush(stdout);
											GRM_save_relation(Rel_task); PrintErrorStack();
											printf("\nRelation Created Successfully...\n");fflush(stdout);
										 }
											ErrorString=(char *) MEM_alloc(300);
											printf("After mem alloc\n");
											tc_strcpy (ErrorString, "Color scheme number ");
											strcat(ErrorString,sClrSchemeName);
											strcat(ErrorString," is not found in option values, So it is not included in expression. Please contact support team and get it added in values.");
											

										EMH_store_error_s1(EMH_severity_information,ITK_err,ErrorString);
										return ITK_err;
							
									}


														
									//BSLV_set_variant_expression(primary,NULLTAG,vrule,sCustomExpression );PrintErrorStack(); // this is working line without colour scheme option value						
									//BSLV_set_variant_expression(primary,NULLTAG,vrule,sCustomExpWithColrSchm );PrintErrorStack(); // this is working line with colour scheme option value						
				//					printf("\n before expression_to_formula\n");fflush(stdout);
				//
				//					 GRM_find_relation_type ("IMAN_reference",&tRelationFind);PrintErrorStack();
				//						if (vrule!=NULLTAG && primary!=NULLTAG)
				//						 { 
				//							printf("\n inside if loop \n");fflush(stdout);
				//							GRM_create_relation(primary,vrule,tRelationFind,NULLTAG,&Rel_task);PrintErrorStack();
				//							printf("\n inside if loop \n");fflush(stdout);
				//							AOM_load(Rel_task);
				//							printf("\nAOM_load-----\n");fflush(stdout);
				//							GRM_save_relation(Rel_task); PrintErrorStack();
				//							printf("\nRelation Created Successfully...\n");fflush(stdout);
				//						 }
				//					
									//BSLV_convert_variant_expression_to_formula	(primary,NULLTAG,expression,&formula );
									// printf("\n formula  =%s\n",formula);
													
								}
							}
						}




									MEM_free(sCustomExpression);	
									MEM_free(sCustomExpWithColrSchm);
					}
				}
						else
				{
					//**********************************************************MYCODE(Aashish_W) ******************************************//
					int n_entriesObs=1;
					tag_t queryTagObs		= NULLTAG;
					char *Platformg1  = NULL;
					char **qry_valuesObs = (char **) MEM_alloc(10 * sizeof(char *));
					printf("\n else ITEM_find replaced by QRY_find2");fflush(stdout);
					if(QRY_find2("Platform", &queryTagObs));
					if (queryTagObs)
					{
					printf("\nPlatform Found Query General ");
					fflush(stdout);
					}
					else
					{
					printf("\n Platform:Not Found Query General \n");
					fflush(stdout);
					}

					
					  if (GRM_ask_primary (objTag,&priObjTag)!=ITK_ok);
					  if (TCTYPE_ask_object_type(priObjTag,&priObjTypeTag)!=ITK_ok);
					  if (TCTYPE_ask_name2(priObjTypeTag,&type_name1)!=ITK_ok);
					
					if (priObjTag!=NULLTAG)
						   {
							AOM_UIF_ask_value(priObjTag,"t5_SchmPlant",&Platformg1);	
							printf("\n\t Platfor = %s \n", Platformg1);fflush(stdout);
						   }

					char *qry_entriesObs[1] = {"ID"};
					qry_valuesObs[0] = Platformg1 ;
				   

					if(QRY_execute(queryTagObs,n_entriesObs,qry_entriesObs,qry_valuesObs,&count,&tags));
					printf("\n11 else Unique Platform Query count :%d:\n", count); fflush(stdout);

					if ( count > 0 )
					{
						printf("\nX4 Found");
						item_tag = tags[0];
					
					}
					else
					{
						printf("\nX4 NOT Found");
					}
					

					 if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
					  if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
					  printf("\n save_method_19::type_name :%s\n", type_name);fflush(stdout);
					  
						  if (GRM_ask_secondary (objTag,&secObjTag)!=ITK_ok);
						  //Added by Aashish_w
						if(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));

									qry_values11[0] = "Project" ;
									qry_values11[1] = "AltrozWay" ;

						QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11);
							AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo1",&userinfo11);
							printf("\n **************** User Info 1 ===> %s **************** \n",userinfo11);fflush(stdout);
							
						if( AOM_ask_value_string(secObjTag,"object_name",&Variantname)!=ITK_ok); fflush(stdout);
						printf("\n **************** Base Varient Rule Name ===> %s **************** \n",Variantname);fflush(stdout);
						myvarientname = subString(Variantname,0,4);	
									printf("\n **************** MY Varient Name ===> %s **************** \n",myvarientname);fflush(stdout);

				//Start Finction else  Gajanan 
							int		 n_entriesg					= 1;
							int		 n_foundg					= 0;
							int		 i;
							tag_t	queryg						= NULLTAG;
							tag_t   *CntrlObject_Tagg			= NULLTAG;
							char*	 sUsrInfog					= NULL;	
							char    *qry_entriesg[1]	=	{"SYSCD"};
							char    **qry_valuesg    =  (char **) MEM_alloc(50 * sizeof(char *));	
							QRY_find2("ControlObjQry",&queryg);
							qry_valuesg[0] = "SVR_CLR_SCHEME_REL";
							QRY_execute(queryg, n_entriesg, qry_entriesg, qry_valuesg, &n_foundg, &CntrlObject_Tagg);
							printf("\n\tControl Object SVR_CLR_SCHEME_REL count found  %d\n",n_foundg);

						if(n_foundg>0)
						{				
							AOM_ask_value_string(CntrlObject_Tagg[0],"t5_Userinfo1",&sUsrInfog);
							printf("\n\t Control Object value   %s\n",sUsrInfog);
						if (tc_strcmp(sUsrInfog,"SVR_CLR_SCHEME_REL")==0)
						{
								
						childParts =	(char *) MEM_alloc(40000);
						FullAdvString		= (char *) MEM_alloc(60000);
						FullAdvString1		= (char *) MEM_alloc(60000);
						sTempItemID		    = (char *) MEM_alloc(50);
						sTempItemRev		= (char *) MEM_alloc(50);

						char				* Platformg			= NULL;
						char				* SVR				= NULL;
						char				* RevisionRule		= NULL;
						char				* ClrSCMID			= NULL;
						
						if (priObjTag!=NULLTAG)
						   {
							AOM_UIF_ask_value(priObjTag,"item_id",&ClrSCMID);
							AOM_UIF_ask_value(priObjTag,"t5_SchmPlant",&Platformg);	
							printf("\n\t Platfor = %s \n", Platformg);fflush(stdout);
							RevisionRule ="ERC release and above";
							printf("\n\t Scheme No = [%s]  and Color SVR  Variantname = [%s] and Revision Rule = [%s]\n",ClrSCMID,Variantname,RevisionRule);fflush(stdout);
							tc_strcat(childParts," ");
							tc_strcat(FullAdvString," ");
							tc_strcat(FullAdvString1," ");

							ITK_CALL(BOMCorrect(Platformg,Variantname,RevisionRule,priObjTag));
							printf("\n Before Printing  Eorror "); fflush(stdout);
							printf("\n %s  ",FullAdvString); fflush(stdout);
							if (tc_strcmp(FullAdvString,NULL) != 0 && tc_strcmp(FullAdvString," ") != 0)
							{
								
							tc_strcat(FullAdvString1,"\nATTENTION : Relation between target Colour Scheme and given VC !!!  ");
							tc_strcat(FullAdvString1,"\nFollowing   BoM  mismatches are observed w.r.t. their  coloured child parts:");
							tc_strcat(FullAdvString1,FullAdvString);
							//tc_strcat(FullAdvString1,"\nPlease check if a new Variant Colour scheme needs to be created or any existing scheme with same colour combination can be used . ");
							printf("\n Full Errorr %s  ",FullAdvString1); fflush(stdout);

							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,clrRelError,FullAdvString1);
							printf("\n After  EMH_store_error_s1 "); fflush(stdout);
							return clrRelError ;
							printf("\n After Printing  Error "); fflush(stdout);


							}
							
						   }
						}
					}
				//End Finction else Gajanan



					if(strstr(userinfo11,myvarientname)!=NULL)
					{
							printf("\n **** Skipping for 5442 And live projects **** \n");fflush(stdout);
					}
					else
					{
						  if (TCTYPE_ask_object_type(secObjTag,&secObjTypeTag)!=ITK_ok);
					  
					  if (TCTYPE_ask_name2(secObjTypeTag,&type_name2)!=ITK_ok);
					  printf("\n save_method_19::sec_type_name :%s\n", type_name2);fflush(stdout);

					  BSLV_get_variant_expression(NULLTAG,secObjTag,&expression );PrintErrorStack();
					  printf("\n expression  =%s\n",expression);fflush(stdout);

					  if( AOM_ask_value_string(priObjTag,"object_name",&sClrSchemeName)!=ITK_ok); PrintErrorStack();
					   printf("\n sClrSchemeName name  =%s\n",sClrSchemeName);fflush(stdout);
					   

					  if( AOM_ask_value_string(priObjTag,"item_revision_id",&sClrSchemeREVName)!=ITK_ok); PrintErrorStack();
					   printf("\n sClrSchemeREVName name  =%s\n",sClrSchemeREVName);fflush(stdout);	
					   sClrSchemeOnlyREVName=strtok(sClrSchemeREVName,";");
						printf("\n Main Revision name  =%s\n",sClrSchemeOnlyREVName);fflush(stdout);

						printf("\n Query Values for Varient Start");fflush(stdout);

						tc_strcpy(scolourSchExpr1,"");
						 tc_strcat(scolourSchExpr1,sClrSchemeName);
						 tc_strcat(scolourSchExpr1,"_");
						 tc_strcat(scolourSchExpr1,sClrSchemeOnlyREVName);
						 printf("\n Query Values for Varient =%s\n",scolourSchExpr1);fflush(stdout);

					   qry_values[0]=malloc(100);
					   qry_values[1]=malloc(100);
					   strcpy(qry_values[0],scolourSchExpr1);
					   strcpy(qry_values[1],"*");

						   strcpy(scolourSchExpr,"([Teamcenter]SCHEME-NO = ");
						 tc_strcat(scolourSchExpr,sClrSchemeName);
						 tc_strcat(scolourSchExpr,"_");
						 tc_strcat(scolourSchExpr,sClrSchemeOnlyREVName);
						 tc_strcat(scolourSchExpr," | [Teamcenter]SCHEME-NO = NA) & ");
					printf("\n scolourSchExpr name  =%s\n",scolourSchExpr);fflush(stdout);
					if(tc_strstr(expression,"[Teamcenter]COLOUR-BOM = N"))
					{
						printf("\n in first if\n");fflush(stdout);	
						//MEM_free(sCustomExpression);
						//sCustomExpression=NULL;
						STRNG_replace_str(expression,"[Teamcenter]COLOUR-BOM = N","[Teamcenter]COLOUR-BOM = Y",&sCustomExpressiontmp);	PrintErrorStack();
						tc_strcpy(sCustomExpression,sCustomExpressiontmp);PrintErrorStack();

					}
					else if(tc_strstr(expression,"[Teamcenter]COLOUR-BOM = Y"))
					{
						printf("\n in 2nd if\n");fflush(stdout);
						tc_strcpy(sCustomExpression,expression);
					}
					else
					{
						printf("\n in 3rd if\n");fflush(stdout);
					tmpstring= tc_strstr(expression,"[Teamcenter]" )	;
					 if(tmpstring != NULL)
						{	
							strcpy(sCustomExpression,"");
						  tc_strcat(sCustomExpression,"(((");	
						  printf("\n sCustomExpression 1 =%s\n",sCustomExpression);fflush(stdout);
						  tc_strcat(sCustomExpression,"[Teamcenter]COLOUR-BOM = Y & ");	
						  printf("\n sCustomExpression 2 =%s\n",sCustomExpression);fflush(stdout);
						  tc_strcat(sCustomExpression,tmpstring);
						  printf("\n sCustomExpression 3  =%s\n",sCustomExpression);fflush(stdout);
						}
					}
					//custom exprssion with color scheme option value
					STRNG_replace_str(sCustomExpression,"[Teamcenter]SCHEME-NO = NA & ","",&sCustomExpression2);	PrintErrorStack();
					STRNG_replace_str(sCustomExpression2," & [Teamcenter]SCHEME-NO = NA","",&sCustomExpression3);	PrintErrorStack();
					tmpstring= tc_strstr(sCustomExpression3,"[Teamcenter]" )	;
					 if(tmpstring != NULL)
						{			
							strcpy(sCustomExpWithColrSchm,"");
						  tc_strcat(sCustomExpWithColrSchm,"(((");	
						 // printf("\n sCustomExpWithColrSchm 1 =%s\n",sCustomExpWithColrSchm);fflush(stdout);
						  tc_strcat(sCustomExpWithColrSchm,scolourSchExpr);	
						 // printf("\n sCustomExpWithColrSchm 2 =%s\n",sCustomExpWithColrSchm);fflush(stdout);
						  tc_strcat(sCustomExpWithColrSchm,tmpstring);
						  printf("\n sCustomExpWithColrSchm 3  =%s\n",sCustomExpWithColrSchm);fflush(stdout);
						}	
					//end
					
					  if( AOM_ask_value_string(priObjTag,"t5_ClSrl",&sColourSeqall)!=ITK_ok);
							printf("\n  sColourSeqall %s\n", sColourSeqall);fflush(stdout);	

							sColourSeq=strtok(sColourSeqall,";");
							//sColourSeq = strtok( NULL, ";" );
							printf("\n  sColourSeq %s\n", sColourSeq);fflush(stdout);	


				///////
						printf("\n before VRULE_create\n");fflush(stdout);		
						//VRULE_create(sNewSvrName,"Amol Test Variant Rule",&vrule);	
						if(sColourSeq != NULL )		
						{
						  if( AOM_ask_value_string(secObjTag,"object_name",&sdrpdSVRname)!=ITK_ok); PrintErrorStack();
						printf("\n  sdrpdSVRname %s\n", sdrpdSVRname);fflush(stdout);
						printf("\n  substring test  %s\n", subString(sdrpdSVRname,0,8));fflush(stdout);
						printf("\n  substring last test  %s\n", subString(sdrpdSVRname,12,tc_strlen(sdrpdSVRname)-12));fflush(stdout);

						char *InputSVRString= NULL;
						InputSVRString=malloc(30);		
						strcpy(InputSVRString,"");
						tag_t	SVR_CtrObjQryTag1		= NULLTAG;
						tag_t	*SVRCtrObjSet1			= NULLTAG;
						int		SVRCtrEtry1				= 1;
						int		SVRQryC1				= 0;
						char    *SVRQryEtry1[1]			= {"SYSCD"};
						char    **SVRQryVal1				=  (char **) MEM_alloc(100 * sizeof(char *));

						tc_strcat(InputSVRString,subString(sdrpdSVRname,0,8));
						tc_strcat(InputSVRString,"A");			
						tc_strcat(InputSVRString,sColourSeq);
						tc_strcat(InputSVRString,"R");
						tc_strcat(InputSVRString,subString(sdrpdSVRname,12,tc_strlen(sdrpdSVRname)-12));

						printf("\n  InputSVRString %s\n", InputSVRString);fflush(stdout);
						
						QRY_find2("ControlObjQry", &SVR_CtrObjQryTag1);
						SVRQryVal1[0] = "SVRAFFR";
						QRY_execute(SVR_CtrObjQryTag1, SVRCtrEtry1, SVRQryEtry1, SVRQryVal1, &SVRQryC1, &SVRCtrObjSet1);
						printf("\n\t SVRQryC1-Control object found = [%d] \n",SVRQryC1);fflush(stdout);
						if(SVRQryC1>0)
						{

							int		CtrC2				= 0;
							int		UserFlag			= 0;
							char	*info1_value2		= NULL;
							char	*token2				= NULL;	

							UserFlag			= 0;
							for (CtrC2=0; CtrC2 < SVRQryC1; CtrC2++)
							{
								printf("\n\t inside  CtrC2= [%d]\n", CtrC2);  fflush(stdout);
								ITKCALL(AOM_ask_value_string(SVRCtrObjSet1[CtrC2],"t5_Userinfo1",&info1_value2));

								token2= tc_strtok(info1_value2,";");
								while (token2 != NULL) 
								{ 
									printf("\n\t  curren login user is %s\n", token2);										
									if(tc_strcmp(user_id,token2)==0)
									{
										UserFlag=1;
										printf("\n\t  UserFlag updated to [%d]\n", UserFlag);	
									}
									token2 = tc_strtok(NULL,";");
								}
							}

							printf("\n\t  UserFlag %d\n", UserFlag);
							if (UserFlag == 0)
							{
							  

								sNewSvrName = CreateClrSVRNo(InputSVRString,priObjTag,secObjTag);
								printf("\n\t ***** Ouside of CreateClrSVRNo ***** \n");
								printf("Final sNewSvrName String is %s \n",sNewSvrName);
							}
							else
							{
								tc_strcpy(sNewSvrName,InputSVRString);
							}			
						}
						else
						{
							tc_strcpy(sNewSvrName,InputSVRString);
						}	
						printf("\n  sNewSvrName %s\n", sNewSvrName);fflush(stdout);		

					 qry_values_Variant[0]=malloc(100);
					   strcpy(qry_values_Variant[0],sNewSvrName);
					

				//added by ashish_w
						if(QRY_find2("VariantRule", &QryVariantRule));
									if(QRY_execute(QryVariantRule, n_entris, qry_entries_Variant, qry_values_Variant, &n_foundc, &VariantTags));
									printf("\n Objects for Query __VariantRule == %d", n_foundc);fflush(stdout);
						 if(n_foundc==0)
							{
						if( AOM_ask_value_string(secObjTag,"object_desc",&sdrpdSVRDesc)!=ITK_ok);
						tc_strcat(sNewSvrdesc,sdrpdSVRDesc);
						tc_strcat(sNewSvrdesc," [");
						tc_strcat(sNewSvrdesc,sColourSeq);
						tc_strcat(sNewSvrdesc,"]");
						if(tc_strlen(sNewSvrdesc)<27)
							{
								VRULE_create(sNewSvrName,sNewSvrdesc,&vrule);PrintErrorStack();
							}
							else
							{
								VRULE_create(sNewSvrName,sdrpdSVRDesc,&vrule);PrintErrorStack();
							}
						AOM_lock(vrule); printf("\t   "); fflush(stdout);PrintErrorStack();
						AOM_save_without_extensions(vrule); printf("\t   "); fflush(stdout);PrintErrorStack();
						AOM_refresh(vrule,0); printf("\t   "); fflush(stdout);PrintErrorStack();
						AOM_unlock(vrule);PrintErrorStack();

						printf("\n Creating Relation T5_HasColourSVR \n");fflush(stdout);

						//added by aashish_w for Has colour svr relation

						GRM_find_relation_type ("T5_HasColourSVR",&HasclrsvrRelation);PrintErrorStack();

						if(HasclrsvrRelation != NULLTAG)
							{
								(GRM_create_relation(secObjTag,vrule,HasclrsvrRelation,NULLTAG,&new_relation));
								if(new_relation != NULLTAG)
									{
									(GRM_save_relation(new_relation));
									}
							}

						printf("\n Created a new Relation T5_HasColourSVR \n");fflush(stdout);

							}
						}
						else
						{
							printf("\n sColourSeq is null 111\n");fflush(stdout);		
						}
						
						if(vrule==NULLTAG)
						{
							printf("\n  VRULE is already present... \n");fflush(stdout);
							vrule = VariantTags[0];
							printf("\n  assigning  VariantTags[0] to VRULE \n");fflush(stdout);
						}

						printf("\n After VRULE_create\n");fflush(stdout);

						GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep);
						if(relation_dep != NULLTAG)
						{
							printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);	
						}

						GRM_list_secondary_objects_only(item_tag,relation_dep,&countV,&secondary_objects);PrintErrorStack();
						printf("\n Smc0HasVariantConfigContext countV :%d ..\n",countV); fflush(stdout);

						if (countV >0)		
						{
							for (k=0;k<countV ;k++ )
							{
								primary=secondary_objects[k];

								TCTYPE_ask_object_type(primary,&objTypeTagDi);PrintErrorStack();
								TCTYPE_ask_name2(objTypeTagDi,&type_name3); PrintErrorStack();
								printf("\n After VRULE_create111---%s\n",type_name3);fflush(stdout);

								if (strcmp(type_name3,"Cfg0ProductItem")==0)
								{
									if( AOM_ask_value_string(primary,"object_name",&stestname)!=ITK_ok); PrintErrorStack();
									printf("\n  sdrpdSVRname %s\n", stestname);fflush(stdout);

									printf("\n in Cfg0ProductItem\n");fflush(stdout);
									
									if(QRY_find2("__Cfg0OptionValuesFromValueIDs", &QryOptionValue));
									if(QRY_execute(QryOptionValue, n_entries, qry_entries, qry_values, &n_found, &OptionValues));
									printf("\n Objects for Query __Cfg0OptionValuesFromValueIDs == %d", n_found);fflush(stdout);
									if(n_found>0)
									{
									 printf("\n Aashish_W_BSLV_set_variant_expression -----------> %s\n",sCustomExpWithColrSchm);fflush(stdout);
									 BSLV_set_variant_expression(primary,NULLTAG,vrule,sCustomExpWithColrSchm );PrintErrorStack(); // this is working line with colour scheme option value						
													printf("\n before expression_to_formula\n");fflush(stdout);

									 GRM_find_relation_type ("IMAN_reference",&tRelationFind);PrintErrorStack();
										if (vrule!=NULLTAG && primary!=NULLTAG)
										 { 
											printf("\n inside if loop \n");fflush(stdout);
											GRM_create_relation(primary,vrule,tRelationFind,NULLTAG,&Rel_task);PrintErrorStack();
											printf("\n inside if loop \n");fflush(stdout);
											AOM_load(Rel_task);
											printf("\nAOM_load-----\n");fflush(stdout);
											GRM_save_relation(Rel_task); PrintErrorStack();
											printf("\nRelation Created Successfully...\n");fflush(stdout);
										 }

									}
									else
									{
										printf("\n Aashish_W_BSLV_set_variant_expression -----------> %s\n",sCustomExpression);fflush(stdout);
										
										BSLV_set_variant_expression(primary,NULLTAG,vrule,sCustomExpression );PrintErrorStack(); // this is working line without colour scheme option value						
										printf("\n before expression_to_formula\n");fflush(stdout);

									 GRM_find_relation_type ("IMAN_reference",&tRelationFind);PrintErrorStack();
										if (vrule!=NULLTAG && primary!=NULLTAG)
										 { 
											printf("\n inside if loop \n");fflush(stdout);
											GRM_create_relation(primary,vrule,tRelationFind,NULLTAG,&Rel_task);PrintErrorStack();
											printf("\n inside if loop \n");fflush(stdout);
											AOM_load(Rel_task);
											printf("\nAOM_load-----\n");fflush(stdout);
											GRM_save_relation(Rel_task); PrintErrorStack();
											printf("\nRelation Created Successfully...\n");fflush(stdout);
										 }
											ErrorString=(char *) MEM_alloc(300);
											printf("After mem alloc\n");
											tc_strcpy (ErrorString, "Color scheme number ");
											strcat(ErrorString,sClrSchemeName);
											strcat(ErrorString," is not found in option values, So it is not included in expression. Please contact support team and get it added in values.");
											

										EMH_store_error_s1(EMH_severity_information,ITK_err,ErrorString);
										return ITK_err;
							
									}			
								}
							}
						}

								MEM_free(sCustomExpression);	
								MEM_free(sCustomExpWithColrSchm);
							}
						}

						////Added on 28.12.2021
						//Find SVR and Scheme check has_application SVR
						////Set bhm0associationinfo on ClrSvr and scheme
						if (GRM_find_relation_type("T5_Applicable_SVR", &ApplSvrRelType)!=ITK_ok);
						if ((priObjTag != NULLTAG) && (secObjTag != NULLTAG))
						{
							printf("\n priObjTag and secObjTag Tag Found...sNewSvrName=[%s]...",sNewSvrName); fflush(stdout);

							if (GRM_find_relation(priObjTag,secObjTag,ApplSvrRelType,&ASReltag)!=ITK_ok);
							if (ASReltag != NULLTAG)
							{
								printf("------ T5_Applicable_SVR---Relation Tag found \n"); fflush(stdout);

								AOM_lock(ASReltag);
								AOM_set_value_string(ASReltag,"bhm0associationinfo",sNewSvrName);
								AOM_save_without_extensions(ASReltag);
								AOM_unlock(ASReltag);

								printf("After update bhm0associationinfo on relation , sNewSvrName=[%s]...\n",sNewSvrName); fflush(stdout);

								if (AOM_UIF_ask_value(ASReltag,"bhm0associationinfo",&AssociateInfoStr)!=ITK_ok);
								printf("\n\t bhm0associationinfo---updated value: [%s]\n",AssociateInfoStr);
							}
							else
							{
								printf("\n Relation ASReltag not Found...  "); fflush(stdout);
							}
						}
						else
						{
							printf("\n priObjTag and secObjTag Tag not Found...  "); fflush(stdout);
						}
					}
				}  // GR
				else
					printf("\n color scheme is revised "); fflush(stdout);


					return ITK_ok;
				}


				char* CreateClrSVRNo(char *InputClrSVRStr, tag_t priObjTag,tag_t secObjTag)
				{
					char	*SchmRevId		    = NULL;
					char	*CreatedClrSVRNo	= NULL;
					char	*PreClrSVRNo		= NULL;
					char	*PreClrSVRNo_tok	= NULL;
					char	*PreClrSVRRev_tok	= NULL;
					char	*IpClrSVRNo_tok		= NULL;
					char	*IpClrSVRRev_tok	= NULL;

					printf("\n\t ***** Inside CreateClrSVRNo ***** \n");

					if (AOM_UIF_ask_value(priObjTag,"current_revision_id",&SchmRevId)!=ITK_ok);
					printf("\n\t Current Scheme rev ID = [%s] \n",SchmRevId);

					if (tc_strstr(SchmRevId,"NR")!=NULL)
					{
						printf("\n\t Scheme has NR rev \n");
						CreatedClrSVRNo = GetNextSVRNo(InputClrSVRStr);
						printf("\n\t ***** Ouside of GetNextSVRNo ***** \n");
						printf("\n\t CreatedClrSVRNo [%s] \n",CreatedClrSVRNo);
						return CreatedClrSVRNo;
					}
					else
					{
						printf("\n\t Scheme has no NR rev \n");
						PreClrSVRNo = GetPreClrSVRNo(priObjTag,secObjTag);
						printf("\n\t ***** Ouside of GetPreClrSVRNo ***** \n");
						printf("\n\t PreClrSVRNo [%s] \n",PreClrSVRNo);
						
						if (tc_strlen(PreClrSVRNo) > 9 )
						{
							if (tc_strcmp(PreClrSVRNo,InputClrSVRStr)==0)
							 {
								printf("\n\t Input ClrSVRNo and Prev Relation ClrSVRNo are same \n");

								PreClrSVRNo_tok = tc_strtok(PreClrSVRNo,"_");
								PreClrSVRRev_tok = tc_strtok(NULL,"_");

								printf("\n\t PreClrSVRNo_tok [%s] PreClrSVRRev_tok [%s] \n",PreClrSVRNo_tok,PreClrSVRRev_tok);

								char	*PreClrSVRNo1				= NULL;
								PreClrSVRNo1		= (char *) MEM_alloc(30 * sizeof(char));				

								if (tc_strcmp(PreClrSVRRev_tok,"NR")==0)
								{
									tc_strcpy(PreClrSVRNo1,"");
									tc_strcat(PreClrSVRNo1,PreClrSVRNo_tok);
									tc_strcat(PreClrSVRNo1,"_A");

									printf("\n\t PreClrSVRNo1 [%s] \n",PreClrSVRNo1);

								}
								else
								{
									char	RevStr			= '\0';
									char	RevNStr			= '\0';
									char	*RevNStr1		= NULL;

									RevNStr1		= (char *) MEM_alloc(10 * sizeof(char));

									
									RevStr = PreClrSVRRev_tok[0];
									printf("\n\t Rev is %c \n",RevStr);
									RevNStr = (char)(((int)RevStr) + 1);
									printf("\n\t Next Rev is %c \n",RevNStr);

									RevNStr1[0] = RevNStr;
									printf("\n\t New Rev String is %s \n",RevNStr1);

									tc_strcpy(PreClrSVRNo1,"");
									tc_strcat(PreClrSVRNo1,PreClrSVRNo_tok);
									tc_strcat(PreClrSVRNo1,"_");
									tc_strcat(PreClrSVRNo1,RevNStr1);

									printf("\n\t PreClrSVRNo1 [%s] \n",PreClrSVRNo1);
								}
								
								
								return PreClrSVRNo1;


							}
							else if (tc_strcmp(PreClrSVRNo,"NoRelFound")==0)
							{
								printf("\n\t No prior relation found between Scheme and Base SVR  \n");

								CreatedClrSVRNo = GetNextSVRNo(InputClrSVRStr);
								printf("\n\t ***** Ouside of GetNextSVRNo ***** \n");
								printf("CreatedClrSVRNo [%s] \n",CreatedClrSVRNo);
								return CreatedClrSVRNo;		

							}
							else if (tc_strcmp(PreClrSVRNo,"NoSVRNoFound")==0)
							{	
								printf("\n\t Clr SVR no not found on relation so going to return Input String as output  \n");
								return InputClrSVRStr;
							}
							else
							{
								printf("\n\t Input ClrSVRNo and Prev Relation ClrSVRNo are not same \n");

								char	*StrforTok_PreClrSVRNo		= NULL;
								char	*StrforTok_InputClrSVRStr		= NULL;
								StrforTok_PreClrSVRNo		= (char *) MEM_alloc(50 * sizeof(char));
								StrforTok_InputClrSVRStr		= (char *) MEM_alloc(50 * sizeof(char));
								tc_strcpy(StrforTok_PreClrSVRNo,"");				
								tc_strcat(StrforTok_PreClrSVRNo,PreClrSVRNo);
								tc_strcpy(StrforTok_InputClrSVRStr,"");
								tc_strcat(StrforTok_InputClrSVRStr,InputClrSVRStr);

								printf("\n\t StrforTok_PreClrSVRNo [%s] StrforTok_InputClrSVRStr [%s] \n",StrforTok_PreClrSVRNo,StrforTok_InputClrSVRStr);

								PreClrSVRNo_tok = tc_strtok(StrforTok_PreClrSVRNo,"_");
								PreClrSVRRev_tok = tc_strtok(NULL,"_");

								printf("\n\t PreClrSVRNo_tok [%s] PreClrSVRRev_tok [%s] \n",PreClrSVRNo_tok,PreClrSVRRev_tok);

								IpClrSVRNo_tok = tc_strtok(StrforTok_InputClrSVRStr,"_");
								IpClrSVRRev_tok = tc_strtok(NULL,"_");

								printf("\n\t IpClrSVRNo_tok [%s] IpClrSVRRev_tok [%s] \n",IpClrSVRNo_tok,IpClrSVRRev_tok);

								if (tc_strcmp(PreClrSVRNo_tok,IpClrSVRNo_tok)==0)
								{
									printf("\n\t AXXR is common \n");
									printf("\n\t InputClrSVRStr %s \n",InputClrSVRStr);
									return InputClrSVRStr;
								}
								else
								{
									printf("\n\t AXXR is not common \n");

									char	*PreClrSVRNo2				= NULL;
									PreClrSVRNo2		= (char *) MEM_alloc(30 * sizeof(char));

									tc_strcpy(PreClrSVRNo2,"");
									tc_strcat(PreClrSVRNo2,PreClrSVRNo_tok);
									tc_strcat(PreClrSVRNo2,"_");
									tc_strcat(PreClrSVRNo2,IpClrSVRRev_tok);

									printf("\n\t PreClrSVRNo2 [%s] \n",PreClrSVRNo2);
									
									return PreClrSVRNo2;

								}
							}
						}
						else
						{
							return InputClrSVRStr;
						}

					}

					return InputClrSVRStr;
				}

				char* GetNextSVRNo(char *IStr)
				{
					int			Qry_entry_c		= 1;
					int			n_foundc		= 0;

					char	Str				= '\0';
					char	NStr			= '\0';
					char	*SubString1		= NULL;
					char	*SubString2		= NULL;
					char	*StrCast		= NULL;
					char	*LatestStr		= NULL;
					char	*OutStr		    = NULL;

					tag_t QryVariantRule	= NULLTAG;
					tag_t *VariantTags		= NULLTAG;

					SubString1	= (char *) MEM_alloc(20 * sizeof(char));
					SubString2	= (char *) MEM_alloc(20 * sizeof(char));
					StrCast		= (char *) MEM_alloc(10 * sizeof(char));
					OutStr		= (char *) MEM_alloc(30 * sizeof(char));

					char	*Qry_entry[1]	= {"Name"};
					char	**qry_values	= (char **) MEM_alloc(1 * sizeof(char *));

					printf("\n\t ***** Inside GetNextSVRNo ***** \n");
					

					printf("Inpurt String Is %s \n",IStr);

					qry_values[0]=malloc(100);
					strcpy(qry_values[0],IStr);

					if(QRY_find2("VariantRule", &QryVariantRule));
					if(QRY_execute(QryVariantRule, Qry_entry_c, Qry_entry, qry_values, &n_foundc, &VariantTags));
					printf("\n No of SVR found in System = %d \n", n_foundc);fflush(stdout);
					if(n_foundc==0)
					{
						return IStr;
					}
					else
					{
						SubString1 = subString(IStr,0,8);
						SubString2 = subString(IStr,9,tc_strlen(IStr)-9);

						printf("Substring1 =[%s] and Substring2 = [%s] \n",SubString1,SubString2);

						Str = IStr[8];
						printf("8 th no char is %c \n",Str);
						NStr = (char)(((int)Str) + 1);
						printf("Next Entered String is %c \n",NStr);

						StrCast[0] = NStr;
						printf("Cast String is %s \n",StrCast);

						tc_strcpy(OutStr,"");
						tc_strcat(OutStr,SubString1);
						tc_strcat(OutStr,StrCast);
						tc_strcat(OutStr,SubString2);
						printf("Output String Is %s \n",OutStr);

						LatestStr = GetNextSVRNo(OutStr);
						printf("\n\t ***** Ouside of GetNextSVRNo ***** \n");

						return LatestStr;
					}

					return IStr;
				}

				char* GetPreClrSVRNo(tag_t priObjTag,tag_t secObjTag)
				{
					char *PreClrSVRNo			= NULL;
					char *PreClrSchemeNo		= NULL;
					char *PreClrSchemeID		= NULL;
					char *PreClrSchemeRID		= NULL;
					char *token1				= NULL;	
					char *token2				= NULL;	
					tag_t PrevSchm				= NULLTAG;
					tag_t RelType				= NULLTAG;
					tag_t Reltag				= NULLTAG;

					printf("\n\t ***** Inside GetPreClrSVRNo ***** \n");

					if (AOM_UIF_ask_value(priObjTag,"IMAN_based_on",&PreClrSchemeNo)!=ITK_ok);

					if (PreClrSchemeNo != NULL)
					{
						printf("\n\t PreClrSchemeNo %s \n",PreClrSchemeNo);

						token1 = tc_strtok(PreClrSchemeNo,",");
						token2 = tc_strtok(NULL,",");

						printf("\n\t Previous Scheme No [%s] and Revision [%s] \n",token1,token2);

						if (ITEM_find_rev(token1,token2,&PrevSchm)!=ITK_ok);

						if (GRM_find_relation_type("T5_Applicable_SVR", &RelType)!=ITK_ok);
						if (GRM_find_relation(PrevSchm,secObjTag,RelType,&Reltag)!=ITK_ok);

						if (Reltag != NULLTAG)
						{
							printf("\n\t Relation Tag found \n");			
							if (AOM_UIF_ask_value(Reltag,"bhm0associationinfo",&PreClrSVRNo)!=ITK_ok);

							printf("\n\t PreClrSVRNo [%s]\n",PreClrSVRNo);

							if (tc_strlen(PreClrSVRNo) > 12 )
							{
								return PreClrSVRNo;
							}
							else
							{
								printf("\n\t No Clr SVR No found \n");
								return "NoSVRNoFound";
							}
							
						}
						else
						{
							printf("\n\t Relation Tag Not found \n");

							int		Flag						= 0;
							char	*IpBaseSVRNo				= NULL;	
							char	*IpBaseSVRNo_tok			= NULL;	
							char	*IpBaseSVRNoRev_tok		= NULL;
							char	*BaseSVRoutStr				= NULL;
							BaseSVRoutStr		= (char *) MEM_alloc(30 * sizeof(char));			

							if (AOM_UIF_ask_value(secObjTag,"object_name",&IpBaseSVRNo)!=ITK_ok);

							printf("\n\t IpBaseSVRNo [%s] \n",IpBaseSVRNo);

							IpBaseSVRNo_tok		= tc_strtok(IpBaseSVRNo,"_");
							IpBaseSVRNoRev_tok	= tc_strtok(NULL,"_");

							printf("\n\t IpBaseSVRNo_tok [%s] IpBaseSVRNoRev_tok [%s] \n",IpBaseSVRNo_tok,IpBaseSVRNoRev_tok);

							if (tc_strcmp(IpBaseSVRNoRev_tok,"NR")==0)
							{
								printf("\n\t Rel tag Not Found for Base SVR with NR rev \n");
								return "NoRelFound";
							}
							else if (tc_strcmp(IpBaseSVRNoRev_tok,"A")==0)
							{
								tc_strcpy(BaseSVRoutStr,"");
								tc_strcat(BaseSVRoutStr,IpBaseSVRNo_tok);
								tc_strcat(BaseSVRoutStr,"_NR");

								printf("\n\t BaseSVRoutStr 1 [%s] \n",BaseSVRoutStr);
								Flag =1;

							}
							else
							{
								char	RevStr			= '\0';
								char	RevNStr			= '\0';
								char	*RevNStr1		= NULL;

								RevNStr1		= (char *) MEM_alloc(10 * sizeof(char));

								RevStr = IpBaseSVRNoRev_tok[0];
								printf("\n\t Rev is %c \n",RevStr);
								RevNStr = (char)(((int)RevStr) - 1);
								printf("\n\t Prev Rev is %c \n",RevNStr);

								RevNStr1[0] = RevNStr;
								printf("\n\t New Rev String is %s \n",RevNStr1);

								tc_strcpy(BaseSVRoutStr,"");
								tc_strcat(BaseSVRoutStr,IpBaseSVRNo_tok);
								tc_strcat(BaseSVRoutStr,"_");
								tc_strcat(BaseSVRoutStr,RevNStr1);

								printf("\n\t BaseSVRoutStr 2 [%s] \n",BaseSVRoutStr);	
								Flag =1;

							}

							printf("\n\t Flag [%d] \n",Flag);	

							if (Flag ==1)
							{
								printf("\n\t Inside Flag =1 BaseSVRoutStr is [%s] \n",BaseSVRoutStr);
								int			Qry_entry_c		= 1;
								int			n_foundc		= 0;
								tag_t		QryVariantRule	= NULLTAG;
								tag_t		*VariantTags	= NULLTAG;
								char	*Qry_entry[1]	= {"Name"};
								char	**qry_values	= (char **) MEM_alloc(1 * sizeof(char *));
								qry_values[0]=malloc(100);		
								
								strcpy(qry_values[0],BaseSVRoutStr);

								if(QRY_find2("VariantRule", &QryVariantRule));
								if(QRY_execute(QryVariantRule, Qry_entry_c, Qry_entry, qry_values, &n_foundc, &VariantTags));
								printf("\n\t No of SVR found in System = %d \n", n_foundc);fflush(stdout);
								if(n_foundc > 0)
								{
									tag_t	PrevsecObjTag  = NULLTAG;
									tag_t	Reltag_PrevSVR = NULLTAG;
									PrevsecObjTag = VariantTags[0];

									if (GRM_find_relation(PrevSchm,PrevsecObjTag,RelType,&Reltag_PrevSVR)!=ITK_ok);

									if (Reltag_PrevSVR != NULLTAG)
									{
										printf("\n\t Prev SVR Relation Tag found \n");			
										if (AOM_UIF_ask_value(Reltag_PrevSVR,"bhm0associationinfo",&PreClrSVRNo)!=ITK_ok);

										printf("\n\t PreClrSVRNo [%s]\n",PreClrSVRNo);
										
										if (tc_strlen(PreClrSVRNo) > 12 )
										{
											printf("\n\t Clr SVR No found \n");
											return PreClrSVRNo;
										}
										else
										{
											printf("\n\t No Clr SVR No found \n");
											return "NoSVRNoFound";
										}
										printf("\n\t Test 1 \n");
										
									}
									else
									{
										printf("\n\t No Prev SVR Relation Tag found \n");
										return "NoRelFound";
									}
									
								}
								else
								{
									printf("No Prev Base SVR found in system \n");
									return "NoRelFound";
								}
							}			
						}
					}
					else
					{
						printf("\n\t No Previous Rev Found \n");
						return "NoRelFound";
					}
					return "NoRelFound";
				}
				//Start GR

	int BOMCorrect(char* Platform,char* SVR,char* RevisionRule,tag_t ColSchmRevTag)
		{

			int			transfermode1Cnt		= 0;
			int			n_entriesV				= 1;
			int			resultCountVNCol		= 0;
			int			n_bom_views				= 0;
			int			rulefound				= 0;
			int			n_lines1				= 0;
			int			p1						= 0;
			int			n_lines2				= 0;
			int			p2						= 0;
			int			Level					= 0;
						FlagVC_Vehicle          = 0;
			char		*RevTyp					= NULL;
			char		**rulename				= NULL;
			char		**rulevalue				= NULL;
			char		*sRevId					= NULL;
			char		*AppSVR					= NULL;
			tag_t		plat					= NULLTAG;
			tag_t		rev						= NULLTAG;
			tag_t		RevTypTag				= NULLTAG;
			tag_t		VariqueryTag			= NULLTAG;
			tag_t		VarientRuletag			= NULLTAG;
			tag_t		item					= NULLTAG;
			tag_t		bom_view				= NULLTAG;
			tag_t		bom_window				= NULLTAG;
			tag_t		rule					= NULLTAG;
			tag_t		close_tag				= NULLTAG;
			tag_t		top_line				= NULLTAG;
			tag_t		ArchiTNode				= NULLTAG;
			tag_t		ModuleLine				= NULLTAG;
			tag_t		ItemSVRTag					= NULLTAG;
			tag_t		*outputVNCol_tags		=NULLTAG;
			tag_t		*bom_views				=NULLTAG;
			tag_t		*closurerule			=NULLTAG;
			tag_t		*lines1					=NULLTAG;
			tag_t		*lines2					=NULLTAG;
			tag_t		view_type				= NULLTAG;


	// vc com 
	// part  id color id and comp

			int n_entries11 =2;
			tag_t	Cntl_obj_Qtag11	=	NULLTAG;
			char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
			char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
			int resultCount11=0;
			tag_t *qry_cntrlobj11= NULLTAG;
			char *userinfo11=NULL;
			char *clrRevTag=NULL;
			char *myvarientname				=	NULL;
			char *t5itemid				=	NULL;
			char *t5itemidTopLine				=	NULL;
			
				tag_t query = NULLTAG;
			char		*qry_entries3[1]		= {"Name"};

			char	**valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));

			printf("\n\t ********************INSIDE BOMCorrect FUN*****************8 \n");fflush(stdout);
			printf("\n\t RevisionRule %s \n",RevisionRule);fflush(stdout);

				if(QRY_find2("Control Objects...", &query));
				qry_values11[0] = "CLRSCMPROJ183" ;
				qry_values11[1] = "CLRSCMPROJ183" ;
				QRY_execute(query, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11);
				AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo1",&userinfo11);
				printf("\n **************** User Info 1 ===> %s **************** \n",userinfo11);fflush(stdout);
				myvarientname = subString(SVR,0,4);	
				printf("\n **************** MY Varient Name ===> %s **************** \n",myvarientname);fflush(stdout);
					 if(strstr(userinfo11,myvarientname))
						{
							printf("\n if execute control obj Hornbill_Way_VC for VC ............  : ");fflush(stdout);
							ITK_CALL(ITEM_find_item(Platform, &plat));
							ITK_CALL(ITEM_ask_latest_rev(plat, &rev));

							if(TCTYPE_ask_object_type(rev, &RevTypTag));
							if(TCTYPE_ask_name2(RevTypTag,&RevTyp));
							printf("\n\t MT: RevTyp type: [%s]\n", RevTyp);fflush(stdout);

							if(QRY_find2("VariantRule", &VariqueryTag));
							printf("\n\t After IFERR_REPORT : QRY_find2 .... "); fflush(stdout);
							valuesNonColSvr[0] = SVR ;
							if(QRY_execute(VariqueryTag, n_entriesV, qry_entries3, valuesNonColSvr, &resultCountVNCol, &outputVNCol_tags));
							printf("   n_entriesV:%d   resultCount:%d \n\t",n_entriesV,resultCountVNCol); fflush(stdout);

							if (resultCountVNCol > 0)
							{
								VarientRuletag = outputVNCol_tags[0];
							}
							else
							{
								printf ("\n NonColour-SVR-VarientRule not present  [%s]\n", SVR); fflush(stdout);
								exit (0);
							}
							
						}
						else
						{
								AppSVR=subString(SVR,0,12);fflush(stdout);                                  
								printf("\n **** for 5442 And live projects **** \n");fflush(stdout); 
								printf("\n **** for 5442 And SVR **** %s \n",AppSVR);fflush(stdout); 
								ITK_CALL(ITEM_find_item(AppSVR, &ItemSVRTag));                              
								ITK_CALL(ITEM_ask_latest_rev(ItemSVRTag, &rev));                  
								ITK_CALL(AOM_ask_value_string(rev,"item_revision_id",&sRevId));
								printf("\n Non Clr Latest Revision %s\n",sRevId);fflush(stdout);         


						}

			//if (tc_strcmp(RevTyp,"T5_PlatformRevision")==0)
			//{

				if ( rev !=NULLTAG )
				{
					CALLAPI ( PS_find_view_type( "view", &view_type ));
					printf("\n PS_find_view_type is found......\n" ); fflush(stdout);

					if ( view_type != NULLTAG )
					{
						CALLAPI ( ITEM_ask_item_of_rev( rev, &item ));
						CALLAPI ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));
								 if (bom_views)
								 {
						   bom_view = bom_views[0];					   
						   }			
							   else{
							printf("\nView not found check.......3\n"); fflush(stdout);		  
								 }
						
					}
					else
					printf("\nView not found check.......4\n"); fflush(stdout);
				}

				if ( bom_view != NULLTAG )
				{
					printf(" before BOM_create_window..\n");          fflush(stdout);   
					CALLAPI ( BOM_create_window( &bom_window ));
					CALLAPI(CFM_find( RevisionRule, &rule ));
					CALLAPI(BOM_set_window_config_rule( bom_window, rule ));
					
					
					CALLAPI(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
					
					printf ("rule count %d \n",rulefound);fflush(stdout);
					if (rulefound > 0)
					{
						close_tag = closurerule[0];
						printf ("closure rule found \n");fflush(stdout);
					}

					//CALLAPI(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));			
					CALLAPI(BOM_set_window_pack_all(bom_window, TRUE));
					CALLAPI ( BOM_set_window_top_line( bom_window, NULLTAG, rev, NULLTAG, &top_line ));
					printf( " After BOM_set_window_top_line..\n");fflush(stdout);		
				  
					
					if(top_line!=NULLTAG)
					{
						CALLAPI(BOM_window_hide_unconfigured(bom_window));
						CALLAPI(BOM_window_show_variants(bom_window));
						
						if(strstr(userinfo11,myvarientname))
						{
						printf("\n After inside bom_window-----\n"); fflush(stdout);                                    
						CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&VarientRuletag))   ;
						printf("\n After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);
						}
						CALLAPI(BOM_window_hide_variants(bom_window));	
						ITK_CALL(AOM_ask_value_string(top_line, "bl_item_item_id", &t5itemidTopLine));
						printf(  "\n First Level = %s \n",t5itemidTopLine); fflush(stdout); 
						CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines1));
						printf("\n Clr_LLlast Before setting option n_lines1: %d \n", n_lines1); fflush(stdout);

						if (n_lines1 >0)
						{
							for (p1=0;p1<n_lines1;p1++ )
							{
								n_lines2				= 0;
								lines2					=NULLTAG;
								char *sColourIndArch	=NULL;
								char *t5PrtCatCdArch	=NULL;
								char *sPartTypeArch	=NULL;
								if(ArchiTNode) ArchiTNode=NULLTAG;
								ArchiTNode=lines1[p1];
								ITK_CALL(AOM_ask_value_string(ArchiTNode, "bl_item_item_id", &t5itemid));
								ITK_CALL(AOM_ask_value_string(ArchiTNode, "bl_Design Revision_t5_PartType", &sPartTypeArch));
								ITK_CALL(AOM_ask_value_string(ArchiTNode, "bl_Design Revision_t5_ColourInd", &sColourIndArch));
								ITK_CALL(AOM_ask_value_string(ArchiTNode, "bl_Design Revision_t5_PrtCatCode", &t5PrtCatCdArch));
								printf(  "\n 2nd level item id =%s , Part Type = %s , ColourInd = %s ,comp Code = %s   \n",t5itemid,sPartTypeArch,sColourIndArch,t5PrtCatCdArch); fflush(stdout); 
	 
									if(strstr(userinfo11,myvarientname))
										{
										printf("\n **** for 5445 And live projects Second level Archi **** \n");fflush(stdout); 
										
										}
										else
										{
										if(tc_strcmp(sColourIndArch,"Y")==0 && (tc_strcmp(sPartTypeArch,"M")==0 || tc_strcmp(sPartTypeArch,"A")==0 ||tc_strcmp(sPartTypeArch,"T")==0 || tc_strcmp(sPartTypeArch,"V")==0))
										   {
											if(tc_strstr(t5PrtCatCdArch,"CCA")==0 ||tc_strstr(t5PrtCatCdArch,"TPL")==0 ||tc_strstr(t5PrtCatCdArch,"VEHICLE")==0)
											   {
												printf("\n \tPrint Non-colour Vehicle = %s \n",t5itemid);fflush(stdout);
												//(AOM_ask_value_string(ModuleLine, "bl_Design Revision_t5_PrtCatCode", &t5PrtCatCd)!=ITK_ok);
												SCMhasClrData(ColSchmRevTag,ArchiTNode);
												printf("\n \t FlagVC_Vehicle = %d \n",FlagVC_Vehicle);fflush(stdout);
												if (FlagVC_Vehicle == 1)
												{
												  break;
												}
												
											   }
										   }
										}

								CALLAPI(BOM_line_ask_child_lines(ArchiTNode, &n_lines2, &lines2));
								printf(  "\n 2nd level for non-colour Vehicle child count %d \n",n_lines2); fflush(stdout);

								if (n_lines2 >0)
								{
									for (p2=0;p2<n_lines2;p2++ )
									{
										char *BLitemid	=NULL;
										char *t5itemid3	=NULL;
										char *sColourInd	=NULL;
										char *t5PrtCatCd	=NULL;
										char *sPartType	=NULL;
										char *t5VariantFormula	=NULL;
										if(ModuleLine) ModuleLine=NULLTAG;
										ModuleLine=lines2[p2];
										
										Level = 1;
										 ITK_CALL(AOM_ask_value_string(ModuleLine, "bl_item_item_id", &t5itemid3));
										 ITK_CALL(AOM_ask_value_string(ModuleLine, "bl_Design Revision_t5_PartType", &sPartType));
										 ITK_CALL(AOM_ask_value_string(ModuleLine, "bl_Design Revision_t5_ColourInd", &sColourInd));
										 ITK_CALL(AOM_ask_value_string(ModuleLine, "bl_Design Revision_t5_PrtCatCode", &t5PrtCatCd));
										 ITK_CALL(AOM_ask_value_string(ModuleLine, "bl_formula", &t5VariantFormula));
										 printf(  "\n Vehicle/ Archi_node item id =%s , Part Type = %s , ColourInd = %s ,comp Code = %s   \n",t5itemid3,sPartType,sColourInd,t5PrtCatCd); fflush(stdout); 
										 if(strstr(userinfo11,myvarientname))
										{
										 if(tc_strcmp(t5VariantFormula,NULL) != 0 && tc_strcmp(t5VariantFormula,"") != 0)
										 if(tc_strcmp(sColourInd,"Y")==0 && (tc_strcmp(sPartType,"M")==0 || tc_strcmp(sPartType,"A")==0 ||tc_strcmp(sPartType,"T")==0 || tc_strcmp(sPartType,"V")==0))
										   {
											if(tc_strstr(t5PrtCatCd,"CCA")==0 ||tc_strstr(t5PrtCatCd,"TPL")==0 ||tc_strstr(t5PrtCatCd,"VEHICLE")==0)
											   {
													printf("\n \tNon Clr Print Module Item Hronbill way= %s \n",t5itemid3);fflush(stdout);
													SCMhasClrData(ColSchmRevTag,ModuleLine);
													printf("\n \tNon Clr Print Module Expanding below function with Hronbill way %s \n",t5itemid3);fflush(stdout);
													ITK_CALL(BOMSetCreate(ModuleLine ,ColSchmRevTag));
											   }
										   }
										}
										else
										{
										if(tc_strcmp(sColourInd,"Y")==0 && (tc_strcmp(sPartType,"M")==0 || tc_strcmp(sPartType,"A")==0 ||tc_strcmp(sPartType,"T")==0 || tc_strcmp(sPartType,"V")==0))
										   {
											if(tc_strstr(t5PrtCatCd,"CCA")==0 ||tc_strstr(t5PrtCatCd,"TPL")==0 ||tc_strstr(t5PrtCatCd,"VEHICLE")==0)
											   {
												printf("\n \tClr Print Module Item  Altroz way  = %s \n",t5itemid3);fflush(stdout);												
												SCMhasClrData(ColSchmRevTag,ModuleLine);
												printf("\n \tNon Clr Print Module Expanding below function with Altroz way  %s \n",t5itemid3);fflush(stdout);
												ITK_CALL(BOMSetCreate(ModuleLine ,ColSchmRevTag));
											   }
										   }
										}
										 
									}
								}
								
							}
							
							
							}

							CALLAPI(BOM_save_window(bom_window));
							CALLAPI(BOM_close_window(bom_window));	
							
						//	printf("\n All FullAdvString is = %s  ",FullAdvString); fflush(stdout);
						//	if (tc_strcmp(FullAdvString,NULL) != 0 && tc_strcmp(FullAdvString," ") != 0)
						//	{
						//		
						//	tc_strcat(FullAdvString1,"\nATTENTION : Relation between target Colour Scheme and given VC !!!  ");
						//	tc_strcat(FullAdvString1,"\nFollowing   BoM  mismatches are observed w.r.t. their  coloured child parts:");
						//	tc_strcat(FullAdvString1,FullAdvString);
						//	tc_strcat(FullAdvString1,"\nPlease check if a new Variant Colour scheme needs to be created or any existing scheme with same colour combination can be used . ");
						//	printf("\n %s  ",FullAdvString1); fflush(stdout);
						//
						//	}

					}

				}
				else
				{
					printf(  "\n\t no bom window found here \n"); fflush(stdout); 
				}
				printf("\n\t END MAIN FUN \n");fflush(stdout);
			//}
			return ITK_ok;
		}

int BOMSetCreate(tag_t Topline, tag_t ColSchmRevTag)
	 {
			int LineCnt =0;
			int ii =0;
			int jj =0;
			int Flag =0;
			int	ifail = ITK_ok;
			char		*PartCat = NULL;
			char		*PartCatDup1		= NULL;
			char		*PartCatDup		= NULL;
			char *RevId	=NULL;
			char *RevId2=NULL;
			tag_t *Lines	=NULLTAG;
			tag_t ChildLine	=NULLTAG;
			ITK_CALL(AOM_ask_value_string(Topline, "bl_item_item_id", &RevId));
			
				printf("\n\t Item ID=> %s \n",RevId);fflush(stdout);
				CALLAPI(BOM_line_ask_child_lines(Topline, &LineCnt, &Lines)); 
					printf("\n BOM_line_ask_child_lines line count : %d \n", LineCnt); fflush(stdout);

						if (LineCnt >0)
							{
								for (ii=0;ii<LineCnt ;ii++ )
								{
									char *t5itemid	=NULL;
									char *sColourInd	=NULL;
									char *t5PrtCatCd	=NULL;
									if(ChildLine) ChildLine=NULLTAG;
									ChildLine=Lines[ii];
									ITK_CALL(AOM_ask_value_string(ChildLine, "bl_item_item_id", &t5itemid));
									ITK_CALL(AOM_ask_value_string(ChildLine, "bl_Design Revision_t5_ColourInd", &sColourInd));
									if(tc_strcmp(sColourInd,"Y")==0)
									{
										(AOM_ask_value_string(ChildLine, "bl_Design Revision_t5_PrtCatCode", &t5PrtCatCd)!=ITK_ok);

										//printf("\n\tchild compcode property => [%s],[%s] \n",t5itemid,t5PrtCatCd);fflush(stdout);
										SCMhasClrData(ColSchmRevTag,ChildLine);		
										ITK_CALL(BOMSetCreate(ChildLine,ColSchmRevTag));

									}
								}
							}
			
			return ITK_ok;
		}


int SCMhasClrData(tag_t ColSchmRevTag ,tag_t sClrSVRPart)
{
	int	ifail = ITK_ok;  // add GR
	tag_t SchmWithCmpcdRel_VC	= NULLTAG;
	tag_t *CmpCodeOfClrScheme	= NULLTAG;
	tag_t CmpCodeObj			= NULLTAG;
	tag_t ClrPartTag			= NULLTAG;
	tag_t ItemTag1			    = NULLTAG;
	tag_t ItemRevTag			= NULLTAG;
	char *CmpCodeCmp			= NULL;
	char *t5PrtCatCd			= NULL;
	char *t5itemid			= NULL;
	char *t5itemid1			= NULL;
	char *itemRevSeq		=NULL;
	
	char *t5ClSrl = NULL;
	char *Suffix = NULL;
	char *ColourID = NULL;
	char *ChildNCCompCode = NULL;
	int Cmpcount = 0;
	int g1		 = 0;
	char **valuesClrPrt = (char **) MEM_alloc(1 * sizeof(char *));
	int n_entriesC = 1;
	char *qry_entries[1] = {"ID"};
	int n_tags_found1 = 0;
	tag_t *tags_found1  = NULL;	
	char *sColourInd	= NULL;
	char *sPartType		= NULL;
	char *sColourID		= NULL;
	char *SCMColorID	= NULL;
	char *ColourIDSchm  = NULL;
	char *ClrScmSerialID  = NULL;
	int n_entries11 =2;
	tag_t	Cntl_obj_Qtag11	=	NULLTAG;
	char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
	char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
	int resultCount11=0;
	tag_t *qry_cntrlobj11= NULLTAG;
	char *userinfo11=NULL;
	char *myvarientname				=	NULL;
	if(GRM_find_relation_type("T5_ShmHasClrData",&SchmWithCmpcdRel_VC)!=ITK_ok);
	if(GRM_list_secondary_objects_only(ColSchmRevTag, SchmWithCmpcdRel_VC, &Cmpcount, &CmpCodeOfClrScheme)!=ITK_ok);
	printf("\n Comp Code Cmpcount for Color Scheme : %d\n",Cmpcount); fflush(stdout);
		if(AOM_ask_value_string(ColSchmRevTag, "t5_ClSrl",&ClrScmSerialID)!=ITK_ok);
		printf("\n  Color Scheme  Serial Id : %s\n",ClrScmSerialID); fflush(stdout);
		if(Cmpcount > 0)
		{
			for(g1=0;g1<Cmpcount;g1++ )
			{	
				if(CmpCodeObj) CmpCodeObj=NULLTAG;
				CmpCodeObj=CmpCodeOfClrScheme[g1];
				if(AOM_ask_value_string(sClrSVRPart, "bl_item_item_id", &t5itemid)!=ITK_ok);
				if(AOM_ask_value_string(sClrSVRPart, "bl_Design Revision_t5_PrtCatCode", &t5PrtCatCd)!=ITK_ok);
				if(AOM_ask_value_string(CmpCodeObj, "t5_PrtCatCode", &CmpCodeCmp)!=ITK_ok);
				printf("\n CmpCodeCmp & t5PrtCatCd is --> : [%s] = [%s] ---Matched ",CmpCodeCmp,t5PrtCatCd); fflush(stdout);
				if(tc_strcmp(t5PrtCatCd,CmpCodeCmp)==0)
				{
					if(AOM_ask_value_string(CmpCodeObj, "t5_ClSrl", &t5ClSrl )!=ITK_ok);
					//printf("\n t5ClSrl --> : %s",t5ClSrl); fflush(stdout);
					if(tc_strstr(t5ClSrl,";")!=NULL)
					{															
						Suffix =  strtok(t5ClSrl,";");
						//printf("\n Suffix --> : %s",Suffix); fflush(stdout);

						ColourID  =  strtok(NULL,";");
						//printf("\n ColourID --> : %s",ColourID); fflush(stdout);
					}else{
						Suffix =  strtok(t5ClSrl,",");
						printf("\n Suffix --> : %s",Suffix); fflush(stdout);

						ColourID  =  strtok(NULL,",");
						//printf("\n ColourID --> : %s \n",ColourID); fflush(stdout);
					}

					itemRevSeq = NULL;
					itemRevSeq=(char *) MEM_alloc(32);	
					strcpy(itemRevSeq,"");
					strcat(itemRevSeq,t5itemid);  //  need to initialize
					strcat(itemRevSeq,Suffix);										
					printf("\n Colour Part for Creation----  %s",itemRevSeq);
				

		if(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));
		qry_values11[0] = "CLRSCMPROJ183" ;
		qry_values11[1] = "CLRSCMPROJ183" ;
		QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11);
			AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo1",&userinfo11);
			  myvarientname = subString(t5itemid,0,4);	
			 if(strstr(userinfo11,myvarientname) == NULL)
				{

					{
						if(tc_strcmp(CmpCodeCmp,"VEHICLE") == 0)
						{
							CompareVehicleLevel(sClrSVRPart,CmpCodeCmp,ColourID,ClrScmSerialID);
						}
					}
				}
			
				if(FlagVC_Vehicle == 0)
				{
					if(QRY_find2("ClrPart", &ClrPartTag));
					valuesClrPrt[0] = itemRevSeq;
					if(QRY_execute(ClrPartTag, n_entriesC, qry_entries, valuesClrPrt, &n_tags_found1, &tags_found1));
					printf("\n\n\n ClrPart count is-------->  : %d",n_tags_found1);fflush(stdout);
					if(n_tags_found1 > 0)
					{
						ItemTag1 = tags_found1[0];
						ITEM_ask_latest_rev(ItemTag1, &ItemRevTag);
						char *t5PrtCatCd1			= NULL;
						if(AOM_ask_value_string(ItemRevTag, "item_id", &t5itemid1)!=ITK_ok);
						if(AOM_ask_value_string(ItemRevTag, "t5_ColourInd", &sColourInd)!=ITK_ok);
						if(AOM_ask_value_string(ItemRevTag, "t5_PartType", &sPartType)!=ITK_ok);
						if(AOM_ask_value_string(ItemRevTag, "t5_PrtCatCode", &t5PrtCatCd1)!=ITK_ok);
						if(AOM_ask_value_string(ItemRevTag, "t5_ColourID", &sColourID)!=ITK_ok);
						printf("\n\t Parent Item id =>[%s],[%s],[%s],[%s],[%s]\n",t5itemid1,sColourInd,t5PrtCatCd1,sColourID,sPartType);fflush(stdout);
						if(tc_strcmp(sColourInd,"C")==0 && (tc_strcmp(sPartType,"M")==0 || tc_strcmp(sPartType,"A")==0 ||tc_strcmp(sPartType,"T")==0 || tc_strcmp(sPartType,"V")==0))
						  {
							printf("\n inside if part type .....  ....");fflush(stdout);
							if(tc_strstr(t5PrtCatCd1,"CCA")==0 ||tc_strstr(t5PrtCatCd1,"TPL")==0 ||tc_strstr(t5PrtCatCd1,"VEHICLE")==0)
							  {
								printf("\n inside if compcode condition  ....");fflush(stdout);
						        ComparisionClrIdAndCmpCodeWithClrSchm(itemRevSeq,ColSchmRevTag,t5itemid,sColourID,t5PrtCatCd1);
								printf("\n\t Inside if Parent ClrScmBOM Comp code and Colour ID =>[%s],[%s],[%s],[%s],[%s]\n",t5itemid1,sColourInd,t5PrtCatCd1,sColourID,sPartType);fflush(stdout);
							  }
							  
						   }
						
						   
					}

				}
				else
				{
					break;
				}
				}

				
			}
			
		}
			return ITK_ok;
	}

int CompareVehicleLevel(tag_t sClrSVRPart,char *CmpCodeCmp ,char *ColourID, char *ClrScmSerialID)
{
		int n_entriesVeh =4;
		tag_t	veh_Qtag	=	NULLTAG;
		char *qry_entriesVeh[4] = {"ID","Colour Indicator","Non Colour Part","Colour ID"};
		char **qry_valuesVeh = (char **) MEM_alloc(50 * sizeof(char *));
		int resultCountVeh=0;
		tag_t *qry_cntrlobjVeh= NULLTAG;
		char *t5itemidVeh = NULL;
		char *itemidVeh = NULL;
		char *itemid_Veh = NULL;
		char *itemidNClr = NULL;
		char *t5itemidTopLine = NULL;
		int			i						= 0;
		int			p1						= 0;
		int			n_bom_views				= 0;
		int			rulefound				= 0;
		int			n_lines1				= 0;
		tag_t clrPartTag			= NULLTAG;
		tag_t ItemSVRTag			= NULLTAG;
		tag_t clrRevTag			= NULLTAG;
		tag_t clritemTag			= NULLTAG;
		tag_t		*bom_views				=NULLTAG;
		tag_t		item					= NULLTAG;
		tag_t		bom_view				= NULLTAG;
		tag_t		bom_window				= NULLTAG;
		tag_t		rule					= NULLTAG;
		tag_t		close_tag				= NULLTAG;
		tag_t		top_line				= NULLTAG;
		tag_t		*lines1					= NULLTAG;
		tag_t		view_type				= NULLTAG;
		tag_t		ArchiTNode				= NULLTAG;
		char *tmpAdvString			= NULL;
		char *sColourIndArch1	= NULL;
		char *t5PrtCatCdArch1	= NULL;
		char *sPartTypeArch1		= NULL;
		char *st5ColourIDArch1		= NULL;
		char* ClrId = NULL;
		char* CLrSerialID = NULL;
            printf("\n Before Creation Compare Comp code = %s ,  and Colour Id = %s  clrSCMSerialID =%s \n",CmpCodeCmp,ColourID , ClrScmSerialID); fflush(stdout);
             
			 ClrId = strtok(ClrScmSerialID,";");
			 CLrSerialID = strtok(NULL,";");
		       
			if(AOM_ask_value_string(sClrSVRPart, "bl_item_item_id", &t5itemidVeh)!=ITK_ok);
			itemidVeh = subString(t5itemidVeh,0,8);fflush(stdout);
			
			itemid_Veh=(char *) MEM_alloc(32);
			itemidNClr=(char *) MEM_alloc(32);
			strcpy(itemid_Veh,"");
			strcat(itemid_Veh,itemidVeh);  //  need to initialize
			strcat(itemid_Veh,"*");
			printf("\n Print Item For Vehicle  level ----  %s",itemid_Veh);

			strcpy(itemidNClr,"");
			strcat(itemidNClr,itemidVeh);
			strcat(itemidNClr,"000R");
			printf("\n Non Colour part  ----  %s",itemidNClr);

			if(QRY_find2("Colour Part Revision Details", &veh_Qtag));
			qry_valuesVeh[0] = itemid_Veh ;
			qry_valuesVeh[1] = "C" ;
			qry_valuesVeh[2] = itemidNClr ;
			qry_valuesVeh[3] = CLrSerialID ;
			QRY_execute(veh_Qtag, n_entriesVeh, qry_entriesVeh, qry_valuesVeh, &resultCountVeh, &qry_cntrlobjVeh);
			printf("\n Cretaed  %s colour part for count is   : %d\n",itemidNClr,resultCountVeh); fflush(stdout);
			if (resultCountVeh > 0)
			{
              for (i=0;i<resultCountVeh;i++ )
              {
					   clrPartTag =qry_cntrlobjVeh[i];
					   char *clrt5ItemId = NULL;
					   ITK_CALL(AOM_ask_value_string(clrPartTag, "item_id", &clrt5ItemId));
						printf("\nColour part id Is = %s   \n",clrt5ItemId); fflush(stdout);
						ITK_CALL(ITEM_find_item(clrt5ItemId, &ItemSVRTag));                              
						ITK_CALL(ITEM_ask_latest_rev(ItemSVRTag, &clrRevTag));  
						
				if ( clrRevTag !=NULLTAG )
				{
					CALLAPI ( PS_find_view_type( "view", &view_type ));
					printf("\n PS_find_view_type is found......\n" ); fflush(stdout);

					if ( view_type != NULLTAG )
					{
						CALLAPI ( ITEM_ask_item_of_rev( clrRevTag, &clritemTag ));
						CALLAPI ( ITEM_list_bom_views( clritemTag, &n_bom_views, &bom_views ));
                        if (bom_views)
                        {
						  bom_view = bom_views[0];

                        }
						else
						printf("\nView not found check.......9\n"); fflush(stdout);

					}
					else
					printf("\nView not found check.......10\n"); fflush(stdout);
				}

			if ( bom_view != NULLTAG )
			{
				printf(" before BOM_create_window..\n");      fflush(stdout);   
				CALLAPI ( BOM_create_window( &bom_window ));
				CALLAPI(BOM_set_window_pack_all(bom_window, TRUE));
				CALLAPI ( BOM_set_window_top_line( bom_window, NULLTAG, clrRevTag, NULLTAG, &top_line ));
				printf( " After BOM_set_window_top_line..\n");fflush(stdout);
				if(top_line!=NULLTAG)
				{
					CALLAPI(BOM_window_hide_unconfigured(bom_window));
					CALLAPI(BOM_window_show_variants(bom_window));
					
					CALLAPI(BOM_window_hide_variants(bom_window));	
					ITK_CALL(AOM_ask_value_string(top_line, "bl_item_item_id", &t5itemidTopLine));
					ITK_CALL(AOM_ask_value_string(top_line, "bl_Design Revision_t5_PartType", &sPartTypeArch1));
					ITK_CALL(AOM_ask_value_string(top_line, "bl_Design Revision_t5_ColourInd", &sColourIndArch1));
					ITK_CALL(AOM_ask_value_string(top_line, "bl_Design Revision_t5_PrtCatCode", &t5PrtCatCdArch1));
					ITK_CALL(AOM_ask_value_string(top_line, "bl_T5_ClrPartRevision_t5_ColourID", &st5ColourIDArch1));
					printf("\n 1st level item id =%s , Part Type = %s , ColourInd = %s ,comp Code = %s  ,Colour ID = %s  \n",t5itemidTopLine,sPartTypeArch1,sColourIndArch1,t5PrtCatCdArch1 ,st5ColourIDArch1); fflush(stdout); 


					CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines1));
					printf("\nClr_LLlast Before setting option n_lines1: %d \n", n_lines1); fflush(stdout);

					if (n_lines1 >0)
					{
						for (p1=0;p1<n_lines1;p1++ )
						{
							char *t5itemid	= NULL;
							char *sColourIndArch	= NULL;
							char *t5PrtCatCdArch	= NULL;
							char *sPartTypeArch		= NULL;
							char *st5ColourIDArch		= NULL;
							if(ArchiTNode) ArchiTNode=NULLTAG;
							ArchiTNode=lines1[p1];
							ITK_CALL(AOM_ask_value_string(ArchiTNode, "bl_item_item_id", &t5itemid));
							ITK_CALL(AOM_ask_value_string(ArchiTNode, "bl_Design Revision_t5_PartType", &sPartTypeArch));
							ITK_CALL(AOM_ask_value_string(ArchiTNode, "bl_Design Revision_t5_ColourInd", &sColourIndArch));
							ITK_CALL(AOM_ask_value_string(ArchiTNode, "bl_Design Revision_t5_PrtCatCode", &t5PrtCatCdArch));
							ITK_CALL(AOM_ask_value_string(ArchiTNode, "bl_T5_ClrPartRevision_t5_ColourID", &st5ColourIDArch));
							printf(  "\n 2nd level item id =%s , Part Type = %s , ColourInd  = %s ,comp Code = %s , Colour ID = %s  \n",t5itemid,sPartTypeArch,sColourIndArch,t5PrtCatCdArch, st5ColourIDArch); fflush(stdout); 
                            
							if(tc_strcmp(t5PrtCatCdArch1 ,"VC" ) == 0 && tc_strstr(ClrScmSerialID,st5ColourIDArch1) == NULL)
							{
								printf("\n inside VC loop For Continue ..........................! \n"); fflush(stdout);

								if(tc_strcmp(t5PrtCatCdArch ,CmpCodeCmp )== 0 && tc_strcmp(ColourID ,st5ColourIDArch )!= 0)
								{
									 FlagVC_Vehicle = 1;
									printf("\n For VEHICLE Error Message Already Creataed  colour Part, Please try again \n", n_lines1); fflush(stdout);
									tmpAdvString = (char *) MEM_alloc(60000);
									tc_strcat(tmpAdvString," ");
									sprintf(tmpAdvString,"\nPartNo %s with Comp Code %s and  colour %s is already Released in different Colour Structure than this Colour Scheme",t5itemidTopLine,t5PrtCatCdArch1,st5ColourIDArch1);
									tc_strcat(FullAdvString,tmpAdvString);
								}
								else
								{
								printf("\n For VEHICLE Continue ..........................! \n", n_lines1); fflush(stdout);
								}
							
							}
							else
							{
								printf("\n For VC Continue ..........................! \n", n_lines1); fflush(stdout);
							}

							 break;
							
						}
					}

				}

			}
              
              }
			}


return 0;
}

int ComparisionClrIdAndCmpCodeWithClrSchm(char *itemRevSeq,tag_t ColSchmRevTag,char *t5itemid,char *sColourID,char *t5PrtCatCd1)
{
	
	tag_t SchmWithCmpcdRel_VC	= NULLTAG;
		tag_t *CmpCodeOfClrScheme	= NULLTAG;
		tag_t CmpCodeObj			= NULLTAG;
		int Cmpcount = 0;
		int g1		 = 0;
		char *t5itemid2				= NULL;
		char *CmpCodeCmp			= NULL;
		char *SCMColorID			= NULL;
		char *ColourIDSchm			= NULL;
		char *Suffix				= NULL;
		int flag =0;			
				
		if(GRM_find_relation_type("T5_ShmHasClrData",&SchmWithCmpcdRel_VC)!=ITK_ok);
		if(GRM_list_secondary_objects_only(ColSchmRevTag, SchmWithCmpcdRel_VC, &Cmpcount, &CmpCodeOfClrScheme)!=ITK_ok);
		//printf("\n Comp Code Cmpcount for Color Scheme : %d\n",Cmpcount); fflush(stdout);
			if(Cmpcount > 0)
			{
				
				for(g1=0;g1<Cmpcount;g1++ )
				{	
					 CmpCodeCmp			= NULL;
					 ColourIDSchm			= NULL;
					if(CmpCodeObj) CmpCodeObj=NULLTAG;
					CmpCodeObj=CmpCodeOfClrScheme[g1];
					if(AOM_ask_value_string(CmpCodeObj, "t5_PrtCatCode", &CmpCodeCmp)!=ITK_ok);
					if(AOM_ask_value_string(CmpCodeObj, "t5_ClSrl", &SCMColorID)!=ITK_ok);
						Suffix =  strtok(SCMColorID,";");
						ColourIDSchm  =  strtok(NULL,";");
					
					if(tc_strcmp(t5PrtCatCd1,CmpCodeCmp) ==0 && tc_strcmp(sColourID,ColourIDSchm) ==0)
					{
						printf("\n\t  Matches with compcode and color of scheme  =>[%s=%s],[%s =%s],[%s] \n",t5PrtCatCd1,CmpCodeCmp,sColourID,ColourIDSchm,t5itemid);fflush(stdout);
				 
						SCMExpationBOM(itemRevSeq,ColSchmRevTag,t5itemid,t5PrtCatCd1,Suffix);
						flag = 1;
					}
					
					
					
				}
				if ( flag == 0)
				{
				 printf("\n\t  Unable matches with compcode and color of scheme \n");
				}
					
					
				
			}



	return ITK_ok;
}


int SCMExpationBOM(char *itemRevSeq, tag_t ColSchmRevTag,char *t5itemid,char *t5PrtCatCd1,char *Suffix1)
 {
	
		int			transfermode1Cnt		= 0;
		int			n_entriesV				= 1;
		int			resultCountVNCol		= 0;
		int			n_bom_views				= 0;
		int			rulefound				= 0;
		int			n_lines1				= 0;
		int			p1						= 0;
		int			p2						= 0;
		int			Level					= 0;

		char		*RevTyp					= NULL;

		char		**rulename				= NULL;
		char		**rulevalue				= NULL;
		char		* RevisionRule			= NULL;
		char *itemId			=NULL;
		tag_t		plat					= NULLTAG;
		tag_t		rev						= NULLTAG;
		tag_t		RevTypTag				= NULLTAG;
		tag_t		VariqueryTag			= NULLTAG;
		tag_t		VarientRuletag			= NULLTAG;
		tag_t		item					= NULLTAG;
		tag_t		bom_view				= NULLTAG;
		tag_t		bom_window				= NULLTAG;
		tag_t		rule					= NULLTAG;
		tag_t		close_tag				= NULLTAG;
		tag_t		top_line				= NULLTAG;
		tag_t		childNode				= NULLTAG;
		

		tag_t		*outputVNCol_tags		=NULLTAG;
		tag_t		*bom_views				=NULLTAG;
		tag_t		*closurerule			=NULLTAG;
		tag_t		*lines1					=NULLTAG;
		tag_t		view_type				= NULLTAG;

		char		*qry_entries3[1]		= {"Name"};

		char	**valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));
		RevisionRule ="ERC release and above";
		//printf("\n\t ClrScmBOM RevisionRule %s \n",RevisionRule);fflush(stdout);

		ITK_CALL(ITEM_find_item(itemRevSeq, &plat));
		ITK_CALL(ITEM_ask_latest_rev(plat, &rev));

		if(TCTYPE_ask_object_type(rev, &RevTypTag));
		if(TCTYPE_ask_name2(RevTypTag,&RevTyp));
		//printf("\n\t ClrScmBOM  MT: RevTyp type: [%s]\n", RevTyp);fflush(stdout);
			
		if (tc_strcmp(RevTyp,"T5_ClrPartRevision")==0)
		{
			if ( rev !=NULLTAG )
			{
				CALLAPI ( PS_find_view_type( "view", &view_type ));
				//printf("\n ClrScmBOM PS_find_view_type is found......\n" ); fflush(stdout);

				if ( view_type != NULLTAG )
				{
					CALLAPI ( ITEM_ask_item_of_rev( rev, &item ));
					CALLAPI ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));
				  if (bom_views )
				  {
					   bom_view = bom_views[0];
				  } 
				  else
					{
					   printf("\nClrScmBOM View not found check1.......\n"); fflush(stdout);
					}
					
				}
				else
				printf("\nClrScmBOM View not found check2.......\n"); fflush(stdout);					


			if ( bom_view != NULLTAG )
			{
				//printf("ClrScmBOM before BOM_create_window..\n");          fflush(stdout);   
				CALLAPI ( BOM_create_window( &bom_window ));
				CALLAPI(CFM_find( RevisionRule, &rule ));
				CALLAPI(BOM_set_window_config_rule( bom_window, rule ));
				
				CALLAPI(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
				
				//printf ("ClrScmBOM rule count %d \n",rulefound);fflush(stdout);
				if (rulefound > 0)
				{
					close_tag = closurerule[0];
					//printf ("ClrScmBOM closure rule found \n");fflush(stdout);
				}

				CALLAPI(BOM_set_window_pack_all(bom_window, TRUE));
				CALLAPI ( BOM_set_window_top_line( bom_window, NULLTAG, rev, NULLTAG, &top_line ));
				//printf( " ClrScmBOM After BOM_set_window_top_line..\n");fflush(stdout);		
			  
				if(top_line!=NULLTAG)
				{
					
					char *subColSchm1 = NULL;
					char *t5itemid6	= NULL;
					char *govClassClrScheme1	= NULL;
					tag_t		ClrChild				= NULLTAG;
					tag_t		*lines3					= NULLTAG;
					tag_t		govClrSchmTag			= NULLTAG;
					tag_t		subColSchmRevTag		= NULLTAG;
					tag_t		PClrChild			= NULLTAG;
					tag_t		PClrChildRevTag			= NULLTAG;

					CALLAPI(BOM_window_hide_unconfigured(bom_window));
					CALLAPI(BOM_window_show_variants(bom_window));
						 
					//printf("\n ClrScmBOM After inside bom_window-----\n"); fflush(stdout);                                    
					//CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&VarientRuletag))   ;
					//printf("\n After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

					CALLAPI(BOM_window_hide_variants(bom_window));	
					
					CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines1));
					printf("\n ClrScmBOM Before setting option n_lines1: %d \n", n_lines1); fflush(stdout);


						ITEM_find_item(itemRevSeq, &PClrChild);
						ITK_CALL(ITEM_ask_latest_rev(PClrChild, &PClrChildRevTag));
						ITK_CALL(AOM_ask_value_string(PClrChildRevTag,"item_id", &t5itemid6));
						ITK_CALL(AOM_ask_value_string(PClrChildRevTag,"gov_classification", &govClassClrScheme1));
						printf(  "\n Part [%s]=Government Classfication   [%s] \n",t5itemid6,govClassClrScheme1); fflush(stdout);


							
					if (n_lines1 >0)
					{
						
						for (p1=0;p1<n_lines1;p1++ )
						{	
							char *t5ColourInd = NULL;
							char *t5itemid7 = NULL;
							if(childNode) childNode		= NULLTAG;
							childNode=lines1[p1];
							ITK_CALL(AOM_ask_value_string(childNode, "bl_Design Revision_t5_ColourInd", &t5ColourInd));
							ITK_CALL(AOM_ask_value_string(childNode, "bl_item_item_id", &t5itemid7));
							printf("Part No = [%s] , BLine Colour Indicator= [%s]",t5itemid7,t5ColourInd);fflush(stdout);
						   
							if(tc_strcmp(t5ColourInd,"C") == 0)
								{
									findSchmValue(itemRevSeq,childNode,ColSchmRevTag,t5itemid,t5PrtCatCd1,Suffix1);
								}
								if(tc_strcmp(t5ColourInd,"Y") == 0)
								{
									printf(  "\n Part [%s]=Government Classfication   [%s] \n",t5itemid6,govClassClrScheme1); fflush(stdout);

									if(tc_strcmp(govClassClrScheme1,NULL) != 0 && tc_strcmp(govClassClrScheme1,"") !=0)
									{
									tag_t govClrSchmTag1		= NULLTAG;
									tag_t subColSchmRevTag1		= NULLTAG;
									subColSchm1=strtok(govClassClrScheme1,"#");
									printf("Part No = [%s] , Matches of colour and comp code of ClrSchm with child part= [%s]",t5itemid6,subColSchm1);fflush(stdout);
									ITK_CALL(ITEM_find_item(subColSchm1, &govClrSchmTag1));
									ITK_CALL(ITEM_ask_latest_rev(govClrSchmTag1, &subColSchmRevTag1));
									findSchmValueY(itemRevSeq,childNode,ColSchmRevTag,subColSchmRevTag1,t5itemid6,t5PrtCatCd1,Suffix1);

									}


								}
							 
							//MultilevelExpansion(itemRevSeq,childNode,ColSchmRevTag,t5itemid,t5PrtCatCd1,Suffix1);
						
						}

						
					CALLAPI(BOM_save_window(bom_window));
					CALLAPI(BOM_close_window(bom_window));
					
				}

			}
			else
			{
				printf(  "\n\t no bom window found here \n"); fflush(stdout); 
			}
		}
		}
	
	}
	
	
	return ITK_ok;

}

int findSchmValue(char *itemRevSeq,tag_t ClrSchmTag ,tag_t ColSchmRevTag,char *t5itemid,char *t5PrtCatCd1,char *Suffix1)
{
			int	ifail = ITK_ok;
			int		 n_entries2					= 1;
			int		 n_found2					= 0;
			int		 i;
			tag_t   *CntrlObjectTag2			= NULLTAG;
			tag_t	query2						= NULLTAG;
			tag_t   *CntrlObject_Tag2			= NULLTAG;
			char*	 sUsrInfo2					= NULL;	
			char    *qry_entries2[1]	=	{"SYSCD"};
			char    **qry_values2    =  (char **) MEM_alloc(10 * sizeof(char *));	
			QRY_find2("Control Objects...",&query2);
			qry_values2[0] = "CLRINDICATOR_C" ;
			QRY_execute(query2, n_entries2, qry_entries2, qry_values2, &n_found2, &CntrlObject_Tag2);
			printf("\n\tControl Object CLRINDICATOR_C count found  %d\n",n_found2);
		if(n_found2>0)
		{				
				AOM_ask_value_string(CntrlObject_Tag2[0],"t5_Userinfo1",&sUsrInfo2);
				printf("\n\t Control Object value CLRINDICATOR_C   %s\n",sUsrInfo2);
		if (tc_strcmp(sUsrInfo2,"CLRINDICATOR_C")==0)
			{

		tag_t SchmWithCmpcdRel_VC	= NULLTAG;
		tag_t *CmpCodeOfClrScheme	= NULLTAG;
		tag_t CmpCodeObj			= NULLTAG;
		int Cmpcount = 0;
		int g1		 = 0;
		char *t5itemid2				= NULL;
		char *sColourInd			= NULL;
		char *t5PrtCatCd			= NULL;
		char *CmpCodeCmp			= NULL;
		char *sPartType				= NULL;
		char *sColourID				= NULL;
		char *SCMColorID			= NULL;
		char *ColourIDSchm			= NULL;
		char *Suffix				= NULL;
		char *tmpAdvString			= NULL;
		char *tmpAdvString1			= NULL;						
		char *Suffix2 			    = NULL;
		char *itemidSuffix          = NULL;
			itemidSuffix = (char *) MEM_alloc(500);
		 ITK_CALL(AOM_ask_value_string(ClrSchmTag, "bl_item_item_id", &t5itemid2));
		 ITK_CALL(AOM_ask_value_string(ClrSchmTag, "bl_Design Revision_t5_ColourInd", &sColourInd));
		 ITK_CALL(AOM_ask_value_string(ClrSchmTag, "bl_T5_ClrPartRevision_t5_PartType", &sPartType));
		 ITK_CALL(AOM_ask_value_string(ClrSchmTag, "bl_item_item_id", &t5itemid2));
		(AOM_ask_value_string(ClrSchmTag, "bl_T5_ClrPartRevision_t5_PrtCatCode", &t5PrtCatCd)!=ITK_ok);
		(AOM_ask_value_string(ClrSchmTag, "bl_T5_ClrPartRevision_t5_ColourID", &sColourID)!=ITK_ok);
			
		// printf("\n\t  ClrScmBOM Child Comp code and Colour ID =>[%s],[%s],[%s],[%s],[%s]\n",t5itemid2,sColourInd,t5PrtCatCd,sColourID,sPartType);fflush(stdout);
				
		if(GRM_find_relation_type("T5_ShmHasClrData",&SchmWithCmpcdRel_VC)!=ITK_ok);
		if(GRM_list_secondary_objects_only(ColSchmRevTag, SchmWithCmpcdRel_VC, &Cmpcount, &CmpCodeOfClrScheme)!=ITK_ok);
		//printf("\n Comp Code Cmpcount for Color Scheme : %d\n",Cmpcount); fflush(stdout);
			if(Cmpcount > 0)
			{
				
				for(g1=0;g1<Cmpcount;g1++ )
				{	
					 CmpCodeCmp			= NULL;
					 ColourIDSchm			= NULL;
					if(CmpCodeObj) CmpCodeObj=NULLTAG;
					CmpCodeObj=CmpCodeOfClrScheme[g1];
					if(AOM_ask_value_string(CmpCodeObj, "t5_PrtCatCode", &CmpCodeCmp)!=ITK_ok);
					if(AOM_ask_value_string(CmpCodeObj, "t5_ClSrl", &SCMColorID)!=ITK_ok);
						Suffix =  strtok(SCMColorID,";");
						ColourIDSchm  =  strtok(NULL,";");
					
					if(tc_strcmp(t5PrtCatCd,CmpCodeCmp) ==0 && tc_strcmp(sColourID,ColourIDSchm) !=0)
					{
						printf("\n\t For Colour Ind C Matches with compcode and color of scheme  =>[%s=%s],[%s =%s],[%s] \n",t5PrtCatCd,CmpCodeCmp,sColourID,ColourIDSchm,t5itemid2);fflush(stdout);

							printf(  "\n For Colour Ind C Parent item =  [%s =%s] \n",t5itemid,Suffix1); fflush(stdout);
						if(tc_strcmp(sColourInd,"C") == 0)
						{
							if (tc_strcmp(sTempItemID,NULL) == 0)
							{
								tc_strcpy(sTempItemID,"");
								tc_strcpy(sTempItemID,t5itemid);
								//printf("unique id %s",sTempItemID);
							   tmpAdvString = (char *) MEM_alloc(60000);
							   tc_strcat(tmpAdvString," ");
							   sprintf(tmpAdvString,"\nPartNo %s with Comp Code %s and  colour %s is already Released in different Colour Structure than this Colour Scheme",t5itemid,t5PrtCatCd1,Suffix1);
							   tc_strcat(FullAdvString,tmpAdvString);
							}
							//printf("\n copy item  = [%s]",sTempItemID);

							if (tc_strstr(FullAdvString,t5itemid) == NULL)
							{	
																			
								printf("\n3SVR Part No = [%s]",t5itemid);
								printf("\n3SVR Comp Code = [%s]",t5PrtCatCd1);
								printf("\n3SVR Suffix = [%s]",Suffix1);
							   tmpAdvString = (char *) MEM_alloc(60000);
							   tc_strcat(tmpAdvString," ");
							   sprintf(tmpAdvString,"\nPartNo %s with Comp Code %s and  colour %s is already Released in different Colour Structure than this Colour Scheme",t5itemid,t5PrtCatCd1,Suffix1);
							   tc_strcat(FullAdvString,tmpAdvString);
							}
									
								
						}
						
						//if(tc_strcmp(sColourInd,"Y") == 0)
						//{	
						//	tc_strcat(itemidSuffix,"");
						//	tc_strcat(itemidSuffix,t5itemid);
						//	tc_strcat(itemidSuffix,Suffix1);
						//	if (tc_strcmp(sTempItemRev,NULL) == 0)
						//	{
						//	tmpAdvString1 = (char *) MEM_alloc(40000);
						//	tc_strcat(tmpAdvString1," ");
						//	sprintf(tmpAdvString1,"\nPartNo %s Is pending for post colour release .Please take appropriate action. ",itemidSuffix);
						//	tc_strcat(childParts,tmpAdvString1);
						//	}
						//	if (tc_strstr(childParts,itemidSuffix) == NULL)
						//	{
						//
						//	tmpAdvString1 = (char *) MEM_alloc(40000);
						//	tc_strcat(tmpAdvString1," ");
						//	sprintf(tmpAdvString1,"\nPartNo %s Is pending for post colour release .Please take appropriate action. ",itemidSuffix);
						//	tc_strcat(childParts,tmpAdvString1);
						//	}
						//}
					}
					
					
					
				}
				
			}

			}
		}
	return ITK_ok;
}
					
int findSchmValueY(char *itemRevSeq,tag_t ClrSchmTag ,tag_t ColSchmRevTag,tag_t subColSchmRevTag1,char *t5itemid,char *t5PrtCatCd1,char *Suffix1)
{
			int	ifail = ITK_ok;
			int		 n_entries1					= 1;
			int		 n_found					= 0;
			int		 n_found1					= 0;
			int		 i;
			int		 status						 = 0;
			tag_t	query						= NULLTAG;
			tag_t   *CntrlObjectTag1			= NULLTAG;
			tag_t	query1						= NULLTAG;
			tag_t   *CntrlObject_Tag1			= NULLTAG;
			char*	 sUsrInfo1					= NULL;	
			char    *qry_entries1[1]	=	{"SYSCD"};
			char    **qry_values1    =  (char **) MEM_alloc(10 * sizeof(char *));	
			QRY_find2("Control Objects...",&query1);
			qry_values1[0] = "CLR_INDICATOR_Y" ;
			QRY_execute(query1, n_entries1, qry_entries1, qry_values1, &n_found1, &CntrlObject_Tag1);
			printf("\n\tControl Object CLR_INDICATOR_Y count found  %d\n",n_found1);
		if(n_found1>0)
		{				
				AOM_ask_value_string(CntrlObject_Tag1[0],"t5_Userinfo1",&sUsrInfo1);
				printf("\n\t Control Object value   %s\n",sUsrInfo1);
		if (tc_strcmp(sUsrInfo1,"CLRINDICATOR_Y")==0)
			{

		tag_t SchmWithCmpcdRel_VC1	= NULLTAG;
		tag_t *CmpCodeOfClrScheme1	= NULLTAG;
		tag_t CmpCodeObj1			= NULLTAG;
		int Cmpcount1 = 0;
		int g1		 = 0;
		tag_t SchmWithCmpcdRel_VC	= NULLTAG;
		tag_t *CmpCodeOfClrScheme	= NULLTAG;
		tag_t CmpCodeObj			= NULLTAG;
		int Cmpcount = 0;
		int g		 = 0;
		char *t5itemid2				= NULL;
		char *sColourInd			= NULL;
		char *t5PrtCatCd			= NULL;
		char *CmpCodeCmp1			= NULL;
		char *CmpCodeCmp			= NULL;
		char *sPartType				= NULL;
		char *sColourID1			= NULL;
		char *sColourID			= NULL;
		char *SCMColorID1			= NULL;
		char *SCMColorID			= NULL;
		char *ColourIDSchm1			= NULL;
		char *ColourIDSchm			= NULL;
		char *Suffix3				= NULL;
		char *Suffix				= NULL;
		char *tmpAdvString			= NULL;
		char *tmpAdvString1			= NULL;						
		char *Suffix2 			    = NULL;
		char *Suffix4 			    = NULL;
		char *itemidSuffix          = NULL;
			itemidSuffix = (char *) MEM_alloc(500);
		 ITK_CALL(AOM_ask_value_string(ClrSchmTag, "bl_item_item_id", &t5itemid2));
		 ITK_CALL(AOM_ask_value_string(ClrSchmTag, "bl_Design Revision_t5_ColourInd", &sColourInd));
		 ITK_CALL(AOM_ask_value_string(ClrSchmTag, "bl_T5_ClrPartRevision_t5_PartType", &sPartType));
		 ITK_CALL(AOM_ask_value_string(ClrSchmTag, "bl_item_item_id", &t5itemid2));
		(AOM_ask_value_string(ClrSchmTag, "bl_T5_ClrPartRevision_t5_PrtCatCode", &t5PrtCatCd)!=ITK_ok);
		(AOM_ask_value_string(ClrSchmTag, "bl_T5_ClrPartRevision_t5_ColourID", &sColourID1)!=ITK_ok);
		 //printf("\n\t  For Colour Ind Y out side Matches with compcode and color of scheme =>[%s],[%s],[%s],[%s],[%s]\n",t5itemid2,sColourInd,t5PrtCatCd,sColourID,sPartType);fflush(stdout);
		printf("\n\t For Colour Ind Y Matches with compcode and color of scheme ");fflush(stdout);
		if(GRM_find_relation_type("T5_ShmHasClrData",&SchmWithCmpcdRel_VC1)!=ITK_ok);
		if(GRM_list_secondary_objects_only(subColSchmRevTag1, SchmWithCmpcdRel_VC1, &Cmpcount1, &CmpCodeOfClrScheme1)!=ITK_ok);
		if(GRM_find_relation_type("T5_ShmHasClrData",&SchmWithCmpcdRel_VC)!=ITK_ok);
		if(GRM_list_secondary_objects_only(ColSchmRevTag, SchmWithCmpcdRel_VC, &Cmpcount, &CmpCodeOfClrScheme)!=ITK_ok);
		//printf("\n Comp Code Cmpcount for Color Scheme : %d\n",Cmpcount); fflush(stdout);
			if(Cmpcount1 > 0)
			{
				
				for(g1=0;g1<Cmpcount1;g1++ )
				{	
					 CmpCodeCmp1			= NULL;
					 ColourIDSchm1			= NULL;
					if(CmpCodeObj1) CmpCodeObj1=NULLTAG;
					CmpCodeObj1=CmpCodeOfClrScheme1[g1];
					if(AOM_ask_value_string(CmpCodeObj1, "t5_PrtCatCode", &CmpCodeCmp1)!=ITK_ok);
					if(AOM_ask_value_string(CmpCodeObj1, "t5_ClSrl", &SCMColorID1)!=ITK_ok);
						Suffix3 =  strtok(SCMColorID1,";");
						ColourIDSchm1  =  strtok(NULL,";");
					//printf("\n\t For Colour Ind Y Matches with compcode and color of scheme =>[%s=%s],[%s =%s],[%s] \n",t5PrtCatCd,CmpCodeCmp1,sColourID,ColourIDSchm,t5itemid2);fflush(stdout);

					if(tc_strcmp(t5PrtCatCd,CmpCodeCmp1) ==0 && tc_strcmp(sColourID1,ColourIDSchm1) !=0)
					{
						//printf("\n\t For Colour Ind Y Ouside if  Matches with compcode and color of scheme =>[%s=%s],[%s =%s],[%s] \n",t5PrtCatCd,CmpCodeCmp1,sColourID,ColourIDSchm,t5itemid2);fflush(stdout);

						printf(  "\nFor Colour Ind Y  Child PartNo [=%s] , there  Parent PartNo =  [%s],  and Suffix =[%s] \n",t5itemid2,t5itemid,Suffix1); fflush(stdout);
													
						if(tc_strcmp(sColourInd,"Y") == 0)
						{	
					  
							if(Cmpcount > 0)
							{
								
								for(g=0;g<Cmpcount;g++ )        // Parent color scheme loping
								{	
									 CmpCodeCmp			= NULL;
									 ColourIDSchm			= NULL;
									if(CmpCodeObj) CmpCodeObj=NULLTAG;
									CmpCodeObj=CmpCodeOfClrScheme[g];
									if(AOM_ask_value_string(CmpCodeObj, "t5_PrtCatCode", &CmpCodeCmp)!=ITK_ok);
									if(AOM_ask_value_string(CmpCodeObj, "t5_ClSrl", &SCMColorID)!=ITK_ok);
										Suffix =  strtok(SCMColorID,";");
										ColourIDSchm  =  strtok(NULL,";");
									if(tc_strcmp(CmpCodeCmp1,CmpCodeCmp)== 0)
									{
										printf(  "\nFor Matches Child Colour Scheme With Parent Color Scheme: Child CompCode [%s] = Parent CompCode [%s]  And Child Suffix [%s]= Parent Suffix [%s] , Part Number=[%s]  \n",CmpCodeCmp1,CmpCodeCmp,Suffix3,Suffix, t5itemid); fflush(stdout);
									}
									if(tc_strcmp(CmpCodeCmp1,CmpCodeCmp) ==0 && tc_strcmp(Suffix,Suffix3) !=0)
									{
										
										Suffix4=subString(t5itemid, strlen(t5itemid)-2 , 2);
										t5itemid[strlen(t5itemid)-2] = '\0';
										printf(  "\n\t Clr Part Number = %s, Comp Code = %s, SufFix = %s\n",t5itemid,t5PrtCatCd1,Suffix4); fflush(stdout);
										if (tc_strcmp(sTempItemRev,NULL) == 0)
										{

										 tmpAdvString = (char *) MEM_alloc(60000);
										 tc_strcat(tmpAdvString," ");
										 sprintf(tmpAdvString,"\nPartNo %s with Comp Code %s and  colour %s is already Released in different Colour Structure than this Colour Scheme",t5itemid,t5PrtCatCd1,Suffix4);
										 tc_strcat(FullAdvString,tmpAdvString);
				
										//tmpAdvString1 = (char *) MEM_alloc(40000);
										//tc_strcat(tmpAdvString1," ");
										//sprintf(tmpAdvString1,"\nPartNo %s Is pending for post colour release .Please take appropriate action. ",t5itemid);
										//tc_strcat(childParts,tmpAdvString1);
										}
										if (tc_strstr(FullAdvString,t5itemid) == NULL)
										{

										 tmpAdvString = (char *) MEM_alloc(60000);
										 tc_strcat(tmpAdvString," ");
										 sprintf(tmpAdvString,"\nPartNo %s with Comp Code %s and  colour %s is already Released in different Colour Structure than this Colour Scheme",t5itemid,t5PrtCatCd1,Suffix4);
										 tc_strcat(FullAdvString,tmpAdvString);
					  
										//tmpAdvString1 = (char *) MEM_alloc(40000);
										//tc_strcat(tmpAdvString1," ");
										//sprintf(tmpAdvString1,"\nPartNo %s Is pending for post colour release .Please take appropriate action. ",t5itemid);
										//tc_strcat(childParts,tmpAdvString1);
										}
									}
								
									
								}
							}
					  
							
						}
					  }
												
					
				}
				
			}
		}
	  }

  return ITK_ok;
}
					
int MultilevelExpansion(char *itemRevSeq,tag_t subChildNode, tag_t ColSchmRevTag,char *t5itemid,char *t5PrtCatCd1,char *Suffix1)
{

		tag_t		ClrChild				= NULLTAG;
		tag_t		*lines3					= NULLTAG;
		tag_t		govClrSchmTag			= NULLTAG;
		tag_t		subColSchmRevTag		= NULLTAG;
		tag_t		PClrChild			= NULLTAG;
		tag_t		PClrChildRevTag			= NULLTAG;
		int			n_lines3				= 0;
		int			p3						= 0;
		char *t5itemid4 = NULL;
		char *t5PrtCatCd4 = NULL;
		char *Suffix4 = NULL;
		char *RevId = NULL;
		char *govClassClrScheme = NULL;
		char *t5itemid5 = NULL;
		char *t5itemid6 = NULL;
		char *subColSchm = NULL;
		char *blColorId =NULL;

		CALLAPI(BOM_line_ask_child_lines(subChildNode, &n_lines3, &lines3));
		ITK_CALL(AOM_ask_value_string(subChildNode,"bl_item_item_id", &t5itemid4));
		printf(  "\n 2nd level Part No : %s ,child count %d \n",t5itemid4,n_lines3); fflush(stdout);
		if (n_lines3 >0)
		{
		
		ITK_CALL(AOM_ask_value_string(subChildNode,"bl_item_item_id", &t5itemid5));
		ITK_CALL(AOM_ask_value_string(subChildNode,"bl_T5_ClrPartRevision_t5_PrtCatCode", &t5PrtCatCd4));
		ITK_CALL(AOM_ask_value_string(subChildNode,"bl_rev_item_revision_id", &RevId));
		ITK_CALL(AOM_ask_value_string(subChildNode,"bl_Design Revision_t5_ColourInd", &blColorId));
			 if(tc_strcmp(blColorId,"Y") != 0)
			{
				
				Suffix4=subString(t5itemid4, strlen(t5itemid4)-2 , 2);
				t5itemid4[strlen(t5itemid4)-2] = '\0';
				printf(  "\n\t Clr Part Number = %s, Comp Code = %s, SufFix = %s\n",t5itemid4,t5PrtCatCd4,Suffix4); fflush(stdout);
			
			}
			ITEM_find_item(t5itemid5, &PClrChild);
			ITK_CALL(ITEM_ask_latest_rev(PClrChild, &PClrChildRevTag));
			ITK_CALL(AOM_ask_value_string(PClrChildRevTag,"item_id", &t5itemid6));
			ITK_CALL(AOM_ask_value_string(PClrChildRevTag,"gov_classification", &govClassClrScheme));
			printf(  "\n Part [%s]=Government Classfication   [%s] \n",t5itemid6,govClassClrScheme); fflush(stdout);
		if(tc_strstr(t5PrtCatCd4,"CCA")==0 ||tc_strstr(t5PrtCatCd4,"TPL")==0 ||tc_strstr(t5PrtCatCd4,"VEHICLE")==0)
		{
			for (p3=0;p3<n_lines3;p3++ )
			{
				char *sColourInd =NULL;
				if(ClrChild) ClrChild=NULLTAG;
				ClrChild=lines3[p3];
				ITK_CALL(AOM_ask_value_string(ClrChild, "bl_Design Revision_t5_ColourInd", &sColourInd));
				
					if(tc_strcmp(sColourInd,"C") == 0)
					{
						findSchmValue(RevId,ClrChild,ColSchmRevTag,t5itemid4,t5PrtCatCd4,Suffix4);
						MultilevelExpansion(RevId,ClrChild,ColSchmRevTag,t5itemid4,t5PrtCatCd4,Suffix4);
					}
					if(tc_strcmp(sColourInd,"Y") == 0)
					{
						
					
					  if(tc_strcmp(govClassClrScheme,NULL) != 0 && tc_strcmp(govClassClrScheme,"") !=0)
						{
						subColSchm=strtok(govClassClrScheme,"#");
						printf("Part No = [%s] , Matches of colour and comp code of ClrSchm with child part= [%s]",t5itemid6,subColSchm);fflush(stdout);
						ITK_CALL(ITEM_find_item(subColSchm, &govClrSchmTag));
						ITK_CALL(ITEM_ask_latest_rev(govClrSchmTag, &subColSchmRevTag));
						findSchmValueY(RevId,ClrChild,ColSchmRevTag,subColSchmRevTag,t5itemid4,t5PrtCatCd4,Suffix4);
						MultilevelExpansion(RevId,ClrChild,subColSchmRevTag,t5itemid4,t5PrtCatCd4,Suffix4);
						}
					}
			}

		}
		}

	return ITK_ok;
}

	//End GR


				extern DLLAPI int  save_method_20(METHOD_message_t *msg, va_list args)
				{

						int		error_code				=	ITK_ok;
						
						tag_t	objTag					=	va_arg(args, tag_t);
						tag_t	objTypeTag				=	NULLTAG;
						tag_t	priObjTag				=	NULLTAG;
						tag_t	priObjTypeTag			=	NULLTAG;
						tag_t	secObjTag				=	NULLTAG;
						tag_t	secObjTypeTag			=	NULLTAG;
						char	*sdrpdSVRname			=	NULL;
						char	*noOfColor				=	NULL;

						//char   type_name[TCTYPE_name_size_c+1];
						//char   type_name1[TCTYPE_name_size_c+1];
						//char   type_name2[TCTYPE_name_size_c+1];
						char *user_id				=	NULL;
						char *type_name				=	NULL;
						char *type_name1				=	NULL;
						char *type_name2				=	NULL;

						tag_t	RelType			        = NULLTAG;
						tag_t	Reltag			        = NULLTAG;
						tag_t	SVR_CtrObjQryTag1		= NULLTAG;
						tag_t	Clrs_CtrObjQryTag1		= NULLTAG;
						tag_t	*SVRCtrObjSet1			= NULLTAG;
						tag_t	*ClrsCtrObjSet1			= NULLTAG;
						tag_t	*CmpRev					= NULLTAG;
						tag_t	CompCd					= NULLTAG;


						int		SVRCtrEtry1				= 1;
						int		ClrsCtrEtry1			= 1;
						int		SVRQryC1				= 0;
						int		ClrsQryC1				= 0;
						int		resultCount				= 0;
						int		n_entries				= 1;
						int		noOfClr					= 0;
						int		colSrlLength	=	0;



						char	*ClrSchemeNo			= NULL;
						char	*ClrSrlDup				= NULL;
						char	*ClrSrl					= NULL;
						char	*SVRName				= NULL;
						char	*ErrorMsg				= NULL;
						char    *SVRQryEtry1[1]			= {"SYSCD"};
						char    *ClrsQryEtry1[1]		= {"SYSCD"};
						char    **SVRQryVal1			=  (char **) MEM_alloc(100 * sizeof(char *));
						char    **ClrsQryVal1			=  (char **) MEM_alloc(100 * sizeof(char *));
						char    **valuesCmpVl           = (char **) MEM_alloc(1 * sizeof(char *));
						char	*qry_entries[1]			= {"Colour ID"};
						ErrorMsg = (char	*)MEM_alloc(500);

					  EPM_decision_t decision=EPM_go;
					
						printf("\n save_method_20::It's the time to save IMAN_specification relation \n");fflush(stdout);
					 if (POM_get_user_id(&user_id)!=ITK_ok);

						printf("\n Inside save_method_20 curent login user is ==> [ %s ] \n",user_id);fflush(stdout);

						if(tc_strcmp(user_id,"loader")!=0)
						{


					  if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
					  if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
					  printf("\n save_method_20::type_name :%s\n", type_name);fflush(stdout);


					  if (GRM_ask_primary (objTag,&priObjTag)!=ITK_ok);
					  if (TCTYPE_ask_object_type(priObjTag,&priObjTypeTag)!=ITK_ok);
					  if (TCTYPE_ask_name2(priObjTypeTag,&type_name1)!=ITK_ok);
					  printf("\n save_method_20::pri_type_name :%s\n", type_name1);fflush(stdout);

					  if (GRM_ask_secondary (objTag,&secObjTag)!=ITK_ok);
					  if (TCTYPE_ask_object_type(secObjTag,&secObjTypeTag)!=ITK_ok);
					  if (TCTYPE_ask_name2(secObjTypeTag,&type_name2)!=ITK_ok);
					  printf("\n save_method_20::sec_type_nameAPPown :%s\n", type_name2);fflush(stdout);

						if( AOM_ask_value_string(secObjTag,"object_name",&sdrpdSVRname)!=ITK_ok); PrintErrorStack();
						printf("\n  sdrpdSVRname %s\n", sdrpdSVRname);fflush(stdout);
						
						if((tc_strstr(sdrpdSVRname, "000R") == NULL) && (tc_strstr(sdrpdSVRname, "000L") == NULL))
						{
							 printf("\n save_method_20aaaa::this SVR is not valid drop \n");fflush(stdout);
							 EMH_store_error_s1( EMH_severity_error,ITK_err,"This is Colour SVR and it is not valid to create this relation");
							return ITK_err;
						}

						
						//Neha(CR-FY22-0226)
						QRY_find2("ControlObjQry", &Clrs_CtrObjQryTag1);
						ClrsQryVal1[0] = "CLRSAFFR";
						QRY_execute(Clrs_CtrObjQryTag1, ClrsCtrEtry1, ClrsQryEtry1, ClrsQryVal1, &ClrsQryC1, &ClrsCtrObjSet1);
						printf("\n\t ClrsQryC1-Control object found = [%d] \n",ClrsQryC1);fflush(stdout);
						if(ClrsQryC1>0)
						{
							//color serial from color scheme
							//t5_ClSrl
							if (AOM_ask_value_string(priObjTag,"t5_ClSrl",&ClrSrl)!=ITK_ok);
							printf("\nColor serial: %s",ClrSrl);fflush(stdout);
							colSrlLength=tc_strlen(ClrSrl);
							printf("\n\t Color serial length : [%d] \n",colSrlLength);fflush(stdout);

							ClrSrlDup = subString(ClrSrl,3,colSrlLength);
							tc_strcat(ClrSrlDup,"*");
							printf("\nColor Id: %s",ClrSrlDup);fflush(stdout);
							
							if(QRY_find2("Colour Master", &CompCd));
							valuesCmpVl[0] = ClrSrlDup;
							if(QRY_execute(CompCd, n_entries, qry_entries, valuesCmpVl, &resultCount, &CmpRev));
							printf("\n Color master count query is-------->  : %d",resultCount);fflush(stdout);

							if (resultCount>0)
							{
								if (AOM_ask_value_string(CmpRev[0],"t5_NoOfColors",&noOfColor)!=ITK_ok);
								printf("\nNo of color: %s",noOfColor);fflush(stdout);
								if(noOfColor) noOfClr = atoi(noOfColor);
								printf("\n atoi :%d\n",noOfClr); fflush(stdout);

								if(noOfClr>1)
								{
										printf("\n Inside no of color grater than 2 \n"); fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"The selected colour serial is a combination of 2 or more colours.\nSome other colour serials may also be present for this combination.\nPlease check and select the appropriate colour serial before you proceed.");
										return ITK_err;								      
								}															
								else
								{
									printf("\n Inside else part \n"); fflush(stdout);

								}
							}
						}



						QRY_find2("ControlObjQry", &SVR_CtrObjQryTag1);

						SVRQryVal1[0] = "SVRAFFR";
						QRY_execute(SVR_CtrObjQryTag1, SVRCtrEtry1, SVRQryEtry1, SVRQryVal1, &SVRQryC1, &SVRCtrObjSet1);
						printf("\n\t SVRQryC1-Control object found = [%d] \n",SVRQryC1);fflush(stdout);

						if(SVRQryC1>0)
						{
							if (AOM_ask_value_string(priObjTag,"object_name",&ClrSchemeNo)!=ITK_ok);
							if (AOM_ask_value_string(secObjTag,"object_name",&SVRName)!=ITK_ok);

							printf("\n\t Scheme No = [%s] and SVR Name = [%s]\n",ClrSchemeNo,SVRName);fflush(stdout);

							if (GRM_find_relation_type("T5_Applicable_SVR", &RelType)!=ITK_ok);
							if (GRM_find_relation(priObjTag,secObjTag,RelType,&Reltag)!=ITK_ok);

							if (Reltag != NULLTAG)
							{
								tc_strcpy(ErrorMsg,"");
								tc_strcat(ErrorMsg,"Relation between SVR [");
								tc_strcat(ErrorMsg,SVRName);
								tc_strcat(ErrorMsg,"] and Scheme [");
								tc_strcat(ErrorMsg,ClrSchemeNo);
								tc_strcat(ErrorMsg,"] already availabe");
								printf("\n\t %se \n",ErrorMsg);fflush(stdout);
								EMH_store_error_s1( EMH_severity_error,ITK_err,ErrorMsg);
								return ITK_err;
							}
							else
							{
								printf("\n\t Ok to create relation \n");fflush(stdout);
							}
							
						}
						else
						{
							printf("\n\t SVRAFFR Control object Not found  \n");fflush(stdout);
						}

						}
					  return error_code;
				}

				//adk

				int GetErrorCode(tag_t priObjTag, tag_t secObjTag) //mbb915858
				{

					int Value_SPK = 0;

					int Task_C1, Task_C2, DML_C, DML_C2, ij, CmpFlag, CmpFlag_1;

					tag_t			SolItemR			=	NULLTAG;
					tag_t			DMLTaskR			=	NULLTAG;
					tag_t			*Task_Obj			=	NULLTAG; 
					tag_t			*Task_Obj2			=	NULLTAG;
					tag_t			*DML_Obj1			=	NULLTAG;
					tag_t			*DML_Obj2			=	NULLTAG;
					tag_t			DML_Task1			=	NULLTAG;
					tag_t			DML_Task2			=	NULLTAG;
					tag_t			DML1				=	NULLTAG;
					tag_t			DML2				=	NULLTAG;
						

						
					char			*Sec_Obj_Rls_Status		= NULL;
					char			*DML_no1				= NULL;
					char			*DML_no2				= NULL;
					char			*TaskAssg				= NULL;

					CmpFlag = 0;
					CmpFlag_1 = 0;


					printf("\n Inside GetErrorCode \n");fflush(stdout);


					if (GRM_find_relation_type("CMHasSolutionItem", &SolItemR)!=ITK_ok);
					if (GRM_list_primary_objects_only(priObjTag,SolItemR,&Task_C1,&Task_Obj)!=ITK_ok);
					printf("\n Primary Object Task Count %d \n",Task_C1);fflush(stdout);

					if (Task_C1==1)
					{
						printf("\n Only one Primary Object Task found\n");fflush(stdout);

						DML_Task1 = Task_Obj[0];

						if (GRM_find_relation_type("T5_DMLTaskRelation", &DMLTaskR)!=ITK_ok);			

						if (GRM_list_primary_objects_only(DML_Task1,DMLTaskR,&DML_C,&DML_Obj1)!=ITK_ok);

						printf("\n DML count of Primary Object  %d \n",DML_C);fflush(stdout);

						DML1 = DML_Obj1[0];

						if (AOM_UIF_ask_value(DML1,"item_id",&DML_no1) !=ITK_ok);

						printf("\n DML of Primary Object is : [%s]\n", DML_no1);fflush(stdout);

						if (AOM_UIF_ask_value(secObjTag,"release_status_list",&Sec_Obj_Rls_Status) !=ITK_ok);
						printf("\n Release status list of Sec Object : %s\n", Sec_Obj_Rls_Status);fflush(stdout);

						if(tc_strstr(Sec_Obj_Rls_Status, "ERC Released") == NULL)
						{

							if (GRM_list_primary_objects_only(secObjTag,SolItemR,&Task_C2,&Task_Obj2)!=ITK_ok);

							printf("\n Secondary Object Task Count %d \n",Task_C2);fflush(stdout);

							if (Task_C2==1)
							{
								printf("\n Only one Secondary Object Task found\n");fflush(stdout);

								DML_Task2 = Task_Obj2[0];

								if (GRM_list_primary_objects_only(DML_Task2,DMLTaskR,&DML_C2,&DML_Obj2)!=ITK_ok);

								DML2 = DML_Obj2[0];
								
								if (AOM_UIF_ask_value(DML2,"item_id",&DML_no2) !=ITK_ok);
								printf("\n DML of Secondary Object is : [%s]\n", DML_no2);fflush(stdout);

								if(tc_strcmp(DML_no1,DML_no2)==0)
								{
									printf("\n Design Revision and Spare kit are attach to DML : [%s]\n", DML_no2);fflush(stdout);

									if (AOM_UIF_ask_value(DML_Task1,"fnd0ActuatedInteractiveTsks",&TaskAssg)!=ITK_ok);

									if (tc_strcmp(TaskAssg,"Add solution items") ==0)
									{
										printf("\n Assigment is for 'Add solution items'\n");fflush(stdout);
									}
									else
									{
										printf("\n\n\t ******* DML Task is not for 'Add solution items *****\n");fflush(stdout);
										

										Value_SPK = 1;
										printf("\n\n\t Value_SPK = [%d] \n",Value_SPK);fflush(stdout);
										return(Value_SPK);
									}
								}
								else
								{
									printf("\n\n\t ******* Design_Rev and Spare_Kit_Rev are not attached to same DML *****\n");fflush(stdout);					

									Value_SPK = 2;
									printf("\n\n\t Value_SPK = [%d] \n",Value_SPK);fflush(stdout);
									return(Value_SPK);

								}
							}
							else if (Task_C2==0)
							{
								printf("\n\n\t ******* Spare_Kit_Rev is not attach to DML Task *****\n");fflush(stdout);

								Value_SPK = 3;
								printf("\n\n\t Value_SPK = [%d] \n",Value_SPK);fflush(stdout);
								return(Value_SPK);
							}

						}
						else
						{
							if (GRM_find_relation_type("CMReferences", &SolItemR)!=ITK_ok);
							if (GRM_list_primary_objects_only(priObjTag,SolItemR,&Task_C1,&Task_Obj)!=ITK_ok);

							if (GRM_list_primary_objects_only(secObjTag,SolItemR,&Task_C2,&Task_Obj2)!=ITK_ok);

							printf("\n Secondary (ERC_Released) Object Task Count %d \n",Task_C2);fflush(stdout);

							if (Task_C2==0)
							{

								printf("\n\n\t ******* Spare_Kit_Rev is not attach to DML Task *****\n");fflush(stdout);

								Value_SPK = 3;
								printf("\n\n\t Value_SPK = [%d] \n",Value_SPK);fflush(stdout);
								return(Value_SPK);
							}
							else
							{

								

								for (ij=0 ; ij < Task_C2; ij++ )
								{
									printf("\n Inside For Loop %d \n",ij);fflush(stdout);

									DML_Obj2	= NULLTAG;
									DML2		= NULLTAG;
									DML_Task2	= NULLTAG;
									DML_no2		= NULL;
									TaskAssg	= NULL;

									DML_Task2	= Task_Obj2[ij];
									DML_C2		= 1;


									if (GRM_list_primary_objects_only(DML_Task2,DMLTaskR,&DML_C2,&DML_Obj2)!=ITK_ok);
									printf("\n DML Count of DML_C2  %d \n",DML_C2);fflush(stdout);

									DML2 = DML_Obj2[0];

									if (AOM_UIF_ask_value(DML2,"item_id",&DML_no2) !=ITK_ok);
									printf("\n DML of Secondary Object is : [%s]\n", DML_no2);fflush(stdout);

									if(tc_strcmp(DML_no1,DML_no2)==0)
									{
										CmpFlag = 1;

										printf("\n Design Revision and Spare kit are attach to DML : [%s]\n", DML_no2);fflush(stdout);

										if (AOM_UIF_ask_value(DML_Task1,"fnd0ActuatedInteractiveTsks",&TaskAssg)!=ITK_ok);

										if (tc_strcmp(TaskAssg,"Add solution items") ==0)
										{
											CmpFlag_1 = 1;

											printf("\n Assigment is for 'Add solution items'\n");fflush(stdout);

											
										}
										else
										{							
											printf("\n\n\t ******* DML Task is not for 'Add solution items *****\n");fflush(stdout);
											
											Value_SPK = 4;
											printf("\n\n\t Value_SPK = [%d] \n",Value_SPK);fflush(stdout);
											return(Value_SPK);
										}
									}
									
								}

								printf("\n After For Loop CmpFlag =[%d] CmpFlag_1 = [%d] \n",CmpFlag,CmpFlag_1);fflush(stdout);

								if(CmpFlag ==0 && CmpFlag_1==0)
								{
									printf("\n Inside If \n");fflush(stdout);
									printf("\n\n\t ******* Design_Rev and Spare_Kit_Rev are not attached to same DML *****\n");fflush(stdout);

									Value_SPK = 5;
									printf("\n\n\t Value_SPK = [%d] \n",Value_SPK);fflush(stdout);
									return(Value_SPK);
								}
								printf("\n After If \n");fflush(stdout);

							}			

						}
					}
					else if(Task_C1==0)
					{
						printf("\n\n\t ******* Design_Rev is not attach to DML Task *****\n");fflush(stdout);

						Value_SPK = 6;
						printf("\n\n\t Value_SPK = [%d] \n",Value_SPK);fflush(stdout);
						return(Value_SPK);
					}
					else
					{
						printf("\n\n\t ******* Design_Rev is attached to Multiple DML Task under Solution_items Folder *****\n");fflush(stdout);
					}

					return(Value_SPK);
				}

				extern DLLAPI int  Multiple_DatasetType_validation(METHOD_message_t *msg, va_list args)
				{
					tag_t	primary_object				=	va_arg(args, tag_t);
					tag_t	secondary_object			=	va_arg(args, tag_t);
					tag_t	relation_type				=	va_arg(args, tag_t);

					tag_t	RelobjTypeTag				=	NULLTAG;
					tag_t	priObjTypeTag				=	NULLTAG;
					tag_t	secObjTypeTag				=	NULLTAG;
					tag_t	*DatasetList					=	NULLTAG;
					tag_t	DatasetTypeTag					=	NULLTAG;
					tag_t	RelType					=	NULLTAG;

					int		DatasetCnt					=0;
					int		i						=0;

					//char   Reltype_name[TCTYPE_name_size_c+1];
					//char   type_name1[TCTYPE_name_size_c+1];
					//char   type_name2[TCTYPE_name_size_c+1];
					//char   D_typeName[TCTYPE_name_size_c+1];

					char			*user_id				= NULL;
					char			*Part_Type				= NULL;
					char			*D_ObjName				= NULL;
					char			*Sec_ObjNmae				= NULL;
					char			*Pri_ObjNmae				= NULL;
					char			*Reltype_name				= NULL;
					char			*type_name1				= NULL;
					char			*type_name2				= NULL;
					char			*D_typeName				= NULL;
					



					if (POM_get_user_id(&user_id)!=ITK_ok);

					printf("\n Inside Has_Spare_kit_validation curent login user is ==> [ %s ] \n",user_id);fflush(stdout);

					if(tc_strcmp(user_id,"loader")!=0 && tc_strcmp(user_id,"infodba")!=0)
					{
						if (TCTYPE_ask_name2(relation_type,&Reltype_name)!=ITK_ok);
						printf("\n\t RelType name is :%s\n", Reltype_name);fflush(stdout);

						if (TCTYPE_ask_object_type(primary_object,&priObjTypeTag)!=ITK_ok);
						if (TCTYPE_ask_name2(priObjTypeTag,&type_name1)!=ITK_ok);
						printf("\n\t Pri obj type name is :%s  \n", type_name1);fflush(stdout);
					
						if (AOM_UIF_ask_value(priObjTypeTag,"object_name",&Pri_ObjNmae)!=ITK_ok);

						if(tc_strcmp(type_name1,"Design Revision")==0)
						{
							if (TCTYPE_ask_object_type(secondary_object,&secObjTypeTag)!=ITK_ok);
							if (TCTYPE_ask_name2(secObjTypeTag,&type_name2)!=ITK_ok);

							if (AOM_UIF_ask_value(secondary_object,"object_name",&Sec_ObjNmae)!=ITK_ok);

							if(tc_strcmp(type_name2,"CMI2Product")==0 || tc_strcmp(type_name2,"CMI2Part")==0 || tc_strcmp(type_name2,"CMI2Process")==0 || tc_strcmp(type_name2,"CMI2Drawing")==0 || tc_strcmp(type_name2,"CMI2DesignTable")==0 || tc_strcmp(type_name2,"CMI2AuxPart")==0 )
							{
								if (GRM_find_relation_type("IMAN_specification",&RelType)!=ITK_ok);

								if (GRM_list_secondary_objects_only(primary_object,RelType,&DatasetCnt,&DatasetList)!=ITK_ok);
								printf("\n\t dataset count  :%d\n", DatasetCnt);fflush(stdout);

								if (DatasetCnt>0)
								{
									for(i=0;i<DatasetCnt;i++)
									{
										if (TCTYPE_ask_object_type(DatasetList[i],&DatasetTypeTag)!=ITK_ok);
										if (TCTYPE_ask_name2(DatasetTypeTag,&D_typeName)!=ITK_ok);						

										if(tc_strcmp(type_name2,D_typeName)==0)
										{
											if (AOM_UIF_ask_value(DatasetList[i],"object_name",&D_ObjName)!=ITK_ok);

											if (tc_strcmp(D_ObjName,Sec_ObjNmae)==0)
											{
												printf("\n\t %s dataset with same name and type availabe.\n", D_ObjName);fflush(stdout);
												EMH_store_error_s2(EMH_severity_error,PLM_error,"Creation of multiple Dataset is Restricted.","Same type of Dataset with same name is already availabe.");
												return(PLM_error);
											}
											else
											{
												printf("\n\t dataset has been created  :%s\n", D_ObjName);fflush(stdout);
											}

										}
									}
								}
							}
							
						}		
					}		

					return 0;
					
				}


				extern DLLAPI int  Has_Spare_kit_validation(METHOD_message_t *msg, va_list args)
				{
						
						tag_t	objTag					=	va_arg(args, tag_t);
						tag_t	objTypeTag				=	NULLTAG;
						tag_t	priObjTag				=	NULLTAG;
						tag_t	priObjTypeTag			=	NULLTAG;
						tag_t	secObjTag				=	NULLTAG;
						tag_t	secObjTypeTag			=	NULLTAG;
						tag_t	DMLTaskR				=	NULLTAG;
						tag_t	SolItemR				=	NULLTAG;
						tag_t	*Task_Obj				=	NULLTAG;
						tag_t	*Task_Obj2				=	NULLTAG;
						tag_t	*DML_Obj2				=	NULLTAG;
						tag_t	DML2					=	NULLTAG;
						tag_t	DML_Task1				=	NULLTAG;
						tag_t	*DML_Obj1				=	NULLTAG;
						tag_t	DML1					=	NULLTAG;
						tag_t	DML_Task2				=	NULLTAG;

						int i				=0;
						int attribute		=0;
						int SPK_R_Value		=0;
						int CmpFlag			=0;
						int	CmpFlag_1		=0;
						int	Task_C1			=0;
						int	Task_C2			=0;
						int	ij				=0;
						int	kk				=0;
						int	DML_C2			=0;
						int	DML_C1			=0;

						//char   type_name[TCTYPE_name_size_c+1];
						//char   type_name1[TCTYPE_name_size_c+1];
						//char   type_name2[TCTYPE_name_size_c+1];
						
						char			*SpareInd_1				= NULL;
						char			*Item_ID				= NULL;
						char			*user_id				= NULL;
						char			*Part_Type				= NULL;
						char			*Pri_Obj_Rls_Status		= NULL;
						char			*Sec_Obj_Rls_Status		= NULL;
						char			*DML_no1				= NULL;
						char			*DML_no2				= NULL;
						char			*TaskAssg				= NULL;
						char			*type_name				= NULL;
						char			*type_name1				= NULL;
						char			*type_name2				= NULL;
						 
							
						if (POM_get_user_id(&user_id)!=ITK_ok);

						printf("\n Inside Has_Spare_kit_validation curent login user is ==> [ %s ] \n",user_id);fflush(stdout);

						if(tc_strcmp(user_id,"loader")!=0 && tc_strcmp(user_id,"infodba")!=0)
						{
							int		HSPKEtry				= 1;
							int		HSPKQryC				= 0;
							tag_t	SPK_CtrObjQryTag		= NULLTAG;
							tag_t	*HSPKCtrObj				= NULLTAG;
							char    *HSPKQryEtry[1]			= {"SYSCD"};
							char    **HPKQryVal				=  (char **) MEM_alloc(100 * sizeof(char *));

							QRY_find2("ControlObjQry", &SPK_CtrObjQryTag);

							HPKQryVal[0] = "HSPKVal";
							QRY_execute(SPK_CtrObjQryTag, HSPKEtry, HSPKQryEtry, HPKQryVal, &HSPKQryC, &HSPKCtrObj);
							printf("\n\t HSPKQryC-Control object found = [%d] \n",HSPKQryC);fflush(stdout);

							if(HSPKQryC>0)
							{

								if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
								if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
								printf("\n HSKV::type_name :%s\n", type_name);fflush(stdout);

								if (GRM_ask_primary (objTag,&priObjTag)!=ITK_ok);
								//if (TCTYPE_ask_object_type(priObjTag,&priObjTypeTag)!=ITK_ok);
								//if (TCTYPE_ask_name2(priObjTypeTag,&type_name1)!=ITK_ok);
								//printf("\n HSKV::pri_type_name :%s  \n", type_name1);fflush(stdout);

								if (GRM_ask_secondary (objTag,&secObjTag)!=ITK_ok);
								if (TCTYPE_ask_object_type(secObjTag,&secObjTypeTag)!=ITK_ok);
								if (TCTYPE_ask_name2(secObjTypeTag,&type_name2)!=ITK_ok);
								printf("\n HSKV::sec_type_name :%s\n", type_name2);fflush(stdout);

								if(tc_strcmp(type_name2,"T5_SparKitRevision")==0)
								{

									if (AOM_ask_value_string(priObjTag,"t5_PartType",&Part_Type) !=ITK_ok);
									
									if(tc_strcmp(Part_Type,"M")!=0)
									{
										if (AOM_UIF_ask_value(priObjTag,"t5_SpareInd",&SpareInd_1) !=ITK_ok);

										if(tc_strcmp(SpareInd_1,"True")!=0)
										{
											EMH_store_error_s1(EMH_severity_error,PLM_error,"Primary object having 'False' Spare Indicator");
											printf("\n\n\t ******* Primary object having 'False' Spare_Indicator*****\n");fflush(stdout);
											return(PLM_error);
										} 
									}		

									printf("\n *** SPK_R Validation CODE Start by mbb915858\n");fflush(stdout);


									if (AOM_UIF_ask_value(priObjTag,"release_status_list",&Pri_Obj_Rls_Status) !=ITK_ok);
									printf("\n Release status list of Pri Object : %s\n", Pri_Obj_Rls_Status);fflush(stdout);

									if (AOM_UIF_ask_value(secObjTag,"release_status_list",&Sec_Obj_Rls_Status) !=ITK_ok);
									printf("\n Release status list of Sec Object : %s\n", Sec_Obj_Rls_Status);fflush(stdout);
										
									if(tc_strstr(Pri_Obj_Rls_Status, "ERC Released") == NULL)
									{

										printf("\n Primary Object is not Released \n");fflush(stdout);

										SPK_R_Value = GetErrorCode(priObjTag,secObjTag);

										printf("\n\n\t SPK_R_Value = [%d] \n",SPK_R_Value);fflush(stdout);

										if (SPK_R_Value==1 || SPK_R_Value==4)
										{
											EMH_store_error_s2(EMH_severity_error,PLM_error,"DML Task is not for 'Add solution items'","'Part Has Spare Kit' relation can be Create/Delete only on 'Add solution items' assignment.");
											printf("\n\n\t ******* DML Task is not for 'Add solution item *****\n");fflush(stdout);
											return(PLM_error);
										}
										else if (SPK_R_Value==2 || SPK_R_Value==5)
										{
											EMH_store_error_s2(EMH_severity_error,PLM_error,"Design_Rev and Spare_Kit_Rev are not attached to same DML","'Part Has Spare Kit' relation can be Create/Delete only on 'Add solution items' assignment.");
											printf("\n\n\t ******* Design_Rev and Spare_Kit_Rev are not attached to same DML *****\n");fflush(stdout);
											return(PLM_error);
										}
										else if (SPK_R_Value==3)
										{
											EMH_store_error_s2(EMH_severity_error,PLM_error,"Spare_Kit_Rev is not attach to DML Task","'Part Has Spare Kit' relation can be Create/Delete only on 'Add solution items' assignment.");
											printf("\n\n\t ******* Spare_Kit_Rev is not attach to DML Task *****\n");fflush(stdout);
											return(PLM_error);
										}
										else if (SPK_R_Value==6)
										{
											EMH_store_error_s2(EMH_severity_error,PLM_error,"Design_Rev is not attach to DML Task","'Part Has Spare Kit' relation can be Create/Delete only on 'Add solution items' assignment.");
											printf("\n\n\t ******* Design_Rev is not attach to DML Task *****\n");fflush(stdout);
											return(PLM_error);
										}

									}
									else if(tc_strstr(Sec_Obj_Rls_Status, "ERC Released") == NULL)
									{
										printf("\n Secondary Object is not Released \n");fflush(stdout);

										SPK_R_Value = GetErrorCode(secObjTag,priObjTag);

										printf("\n\n\t SPK_R_Value = [%d] \n",SPK_R_Value);fflush(stdout);


										if (SPK_R_Value==1 || SPK_R_Value==4)
										{
											EMH_store_error_s2(EMH_severity_error,PLM_error,"DML Task is not for 'Add solution items'","'Part Has Spare Kit' relation can be Create/Delete only on 'Add solution items' assignment.");
											printf("\n\n\t ******* DML Task is not for 'Add solution item *****\n");fflush(stdout);
											return(PLM_error);
										}
										else if (SPK_R_Value==2 || SPK_R_Value==5)
										{
											EMH_store_error_s2(EMH_severity_error,PLM_error,"Design_Rev and Spare_Kit_Rev are not attached to same DML","'Part Has Spare Kit' relation can be Create/Delete only on 'Add solution items' assignment.");
											printf("\n\n\t ******* Design_Rev and Spare_Kit_Rev are not attached to same DML *****\n");fflush(stdout);
											return(PLM_error);
										}
										else if (SPK_R_Value==3)
										{
											EMH_store_error_s2(EMH_severity_error,PLM_error,"Design_Rev is not attach to DML Task","'Part Has Spare Kit' relation can be Create/Delete only on 'Add solution items' assignment.");
											printf("\n\n\t ******* Design_Rev is not attach to DML Task *****\n");fflush(stdout);
											return(PLM_error);
										}
										else if (SPK_R_Value==6)
										{
											EMH_store_error_s2(EMH_severity_error,PLM_error,"Spare_Kit_Rev is not attach to DML Task","'Part Has Spare Kit' relation can be Create/Delete only on 'Add solution items' assignment.");
											printf("\n\n\t ******* Spare_Kit_Rev is not attach to DML Task *****\n");fflush(stdout);
											return(PLM_error);
										}
									}
									else
									{
											printf("\n Both are Released \n");fflush(stdout);

											

											CmpFlag = 0;
											CmpFlag_1 = 0;


											if (GRM_find_relation_type("T5_DMLTaskRelation", &DMLTaskR)!=ITK_ok);
											if (GRM_find_relation_type("CMReferences", &SolItemR)!=ITK_ok);
											if (GRM_list_primary_objects_only(priObjTag,SolItemR,&Task_C1,&Task_Obj)!=ITK_ok);

											if (GRM_list_primary_objects_only(secObjTag,SolItemR,&Task_C2,&Task_Obj2)!=ITK_ok);

											printf("\n Secondary (Both ERC_Released) Object Task Count %d \n",Task_C2);fflush(stdout);

											if (Task_C2==0 || Task_C1==0 )
											{
												EMH_store_error_s2(EMH_severity_error,PLM_error,"Either Design_Rev or Spare_Kit_Rev is not attach to DML Task","'Part Has Spare Kit' relation can be Create/Delete only on 'Add solution items' assignment.");
												printf("\n\n\t ******* Either Design_Rev or Spare_Kit_Rev is not attach to DML Task *****\n");fflush(stdout);
												return(PLM_error);										
											}
											else
											{
												

												for (ij=0 ; ij < Task_C2; ij++ )
												{
													printf("\n Inside For Loop %d \n",ij);fflush(stdout);

													DML_Task2	= Task_Obj2[ij];
													DML_C2		= 1;


													if (GRM_list_primary_objects_only(DML_Task2,DMLTaskR,&DML_C2,&DML_Obj2)!=ITK_ok);
													printf("\n DML Count of DML_C2  %d \n",DML_C2);fflush(stdout);

													DML2 = DML_Obj2[0];

													if (AOM_UIF_ask_value(DML2,"item_id",&DML_no2) !=ITK_ok);
													printf("\n DML of Secondary Object is : [%s]\n", DML_no2);fflush(stdout);


													for (kk=0 ; kk < Task_C1; kk++ )
													{
														DML_Task1	= Task_Obj[kk];

														if (GRM_list_primary_objects_only(DML_Task1,DMLTaskR,&DML_C1,&DML_Obj1)!=ITK_ok);
														printf("\n DML Count of DML_C1  %d \n",DML_C1);fflush(stdout);

														DML1 = DML_Obj1[0];

														if (AOM_UIF_ask_value(DML1,"item_id",&DML_no1) !=ITK_ok);
														printf("\n DML of Primary Object is : [%s]\n", DML_no1);fflush(stdout);

														if(tc_strcmp(DML_no1,DML_no2)==0)
														{
															CmpFlag = 1;

															printf("\n Design Revision and Spare kit are attach to DML : [%s]\n", DML_no2);fflush(stdout);

															if (AOM_UIF_ask_value(DML_Task1,"fnd0ActuatedInteractiveTsks",&TaskAssg)!=ITK_ok);

															if (tc_strcmp(TaskAssg,"Add solution items") ==0)
															{
																CmpFlag_1 = 1;

																printf("\n Assigment is for 'Add solution items'\n");fflush(stdout);
																
															}
															else
															{
																EMH_store_error_s2(EMH_severity_error,PLM_error,"DML Task is not for 'Add solution items'","'Part Has Spare Kit' relation can be Create/Delete only on 'Add solution items' assignment.");
																printf("\n\n\t ******* DML Task is not for 'Add solution items' *****\n");fflush(stdout);
																return(PLM_error);														
															}
														}
													}						
												}

												printf("\n After For Loop CmpFlag =[%d] CmpFlag_1 = [%d] \n",CmpFlag,CmpFlag_1);fflush(stdout);

												if(CmpFlag ==0 && CmpFlag_1==0)
												{
													printf("\n Inside If \n");fflush(stdout);
													EMH_store_error_s2(EMH_severity_error,PLM_error,"Design_Rev and Spare_Kit_Rev are not attached to same DML","'Part Has Spare Kit' relation can be Create/Delete only on 'Add solution items' assignment.");
													printf("\n\n\t ******* Design_Rev and Spare_Kit_Rev are not attached to same DML *****\n");fflush(stdout);
													return(PLM_error);								
												}
												printf("\n After If \n");fflush(stdout);
											}
									}
									printf("\n *** SPK_R Validation CODE END by mbb915858 \n");fflush(stdout);
								}
								else
								{
									EMH_store_error_s1(EMH_severity_error,PLM_error,"Attachment is not Spare Kit Revision");
									printf("\n\n\t ******* Attachment is not Spare Kit Revision *****\n");fflush(stdout);
									return(PLM_error);
								}
							}

						}

				return 0;
					
				}


				extern DLLAPI int  Spare_kit_BOM_validation(METHOD_message_t *msg, va_list args)
				{
						tag_t  parent_tag		= va_arg(args, tag_t);
						tag_t  item_tag			= va_arg(args, tag_t);
						tag_t  itemRev_tag		= va_arg(args, tag_t);
						tag_t  bv_tag			= va_arg(args, tag_t);		
						char *occType			= va_arg(args, char *);	
						tag_t *newBomline_tag	= va_arg(args, tag_t *);
						tag_t gde_tag			= va_arg(args, tag_t);	
						
						tag_t	priObjTag				=	NULLTAG;
						tag_t	secObjTypeTag			=	NULLTAG;

						int i				=0;
						int attribute		=0;
						
						//char   type_name2[TCTYPE_name_size_c+1];
						
						char			*user_id				= NULL;
						char			*Part_Type				= NULL;
						char			*type_name2				= NULL;
						tag_t  	         PrtCls					= NULLTAG;
						char			*PrtClass				= NULL;
						char			*priItmID				= NULL;
						char			*objtyp				= NULL;

						 
							
						if (POM_get_user_id(&user_id)!=ITK_ok);
						
						printf("\n Inside Spare_kit_BOM_validation curent login [BOM] user is ==> [ %s ] \n",user_id);fflush(stdout);

						if(tc_strcmp(user_id,"loader")!=0 && tc_strcmp(user_id,"infodba")!=0)
						{
							for(i=0; i< 1; i++);
							{
								if(AOM_ask_value_tag(parent_tag,"bl_revision", &priObjTag));
								if(AOM_UIF_ask_value(parent_tag,"bl_item_item_id", &priItmID)!=ITK_ok) PrintErrorStack();
								if(AOM_UIF_ask_value(priObjTag,"object_type",&objtyp)!=ITK_ok) PrintErrorStack();
								if (TCTYPE_ask_object_type(itemRev_tag,&secObjTypeTag)!=ITK_ok) PrintErrorStack();
								if (TCTYPE_ask_name2(secObjTypeTag,&type_name2)!=ITK_ok) PrintErrorStack();
								printf("\n Spare_kit_BOM_validation ::bjtyp [%s] type_name2 :[%s] priItmID [%s]",objtyp,type_name2,priItmID); fflush(stdout);
								if (TCTYPE_ask_object_type(itemRev_tag,&secObjTypeTag)!=ITK_ok);
								if (TCTYPE_ask_name2(secObjTypeTag,&type_name2)!=ITK_ok);
								
								if(tc_strcmp(type_name2,"T5_SparKitRevision")==0)
								{
									if (AOM_ask_value_string(priObjTag,"t5_PartType",&Part_Type) !=ITK_ok);

									printf("\n\n\t [BOM] Part_Type is %s \n",Part_Type);fflush(stdout);
									if(tc_strcmp(objtyp,"Spare Kit Revision")!=0)
									{
										if(tc_strcmp(Part_Type,"M")==0 || tc_strcmp(Part_Type,"A")==0 || tc_strcmp(Part_Type,"C")==0)
										{
											EMH_store_error_s1(EMH_severity_error,PLM_error,"Spare kit class part is not allowed to call under Assembly,Component and Module");
											printf("\n\n\t *******Spare kit part is not allowed to call under Assembly,Component and Module *****\n");fflush(stdout);
											return(PLM_error);
										} 
									}
														
								}					
							}
						}
				return 0;
				}

				extern DLLAPI int  Spare_kit_save_validation(METHOD_message_t *msg, va_list args)
				{
						tag_t	objTag			=	va_arg(args, tag_t);
						char			*D_grp				= NULL;
						char			*user_id				= NULL;

						

						if (POM_get_user_id(&user_id)!=ITK_ok);

						printf("\n Spare_kit_save_validation curent login user is ==> [ %s ] \n",user_id);fflush(stdout);

						if(tc_strcmp(user_id,"loader")!=0 && tc_strcmp(user_id,"infodba")!=0)
						{


							if (AOM_ask_value_string(objTag,"t5_DesignGrp",&D_grp) !=ITK_ok);

							if(tc_strcmp(D_grp,"99")==0)
							{
								EMH_store_error_s1(EMH_severity_error,PLM_error,"As per TS, group 99 is meant for KITs and SETs");
								printf("\n\n\t ******* As per TS group 99 is not allowed*****\n");fflush(stdout);
								return(PLM_error);
							} 
						}
						printf("\n\n\t ******* End of Spare_kit_save_validation *****\n");fflush(stdout);
				return 0;	
				}

				//madhu

								/*********** Adi Alias ************/

				extern DLLAPI int  save_method_18(METHOD_message_t *msg, va_list args)
				{

						tag_t	objTag					=	va_arg(args, tag_t);
						tag_t	objTypeTag				=	NULLTAG;
						tag_t	priObjTag				=	NULLTAG;
						tag_t	priObjTypeTag			=	NULLTAG;
						tag_t	secObjTag				=	NULLTAG;
						tag_t	secObjTypeTag			=	NULLTAG;

						//char   type_name[TCTYPE_name_size_c+1];
						//char   type_name1[TCTYPE_name_size_c+1];
						//char   type_name2[TCTYPE_name_size_c+1];
						//char   t5ApplOwnerDValCheckaaa[TCTYPE_name_size_c+1];


						tag_t	LatestRev		= NULLTAG; 
						tag_t	ref_item		= NULLTAG;  
						char* RevL				= NULL;		
						char* type_name				= NULL;		
						char* type_name1				= NULL;		
						char* type_name2				= NULL;		
						char* VehNo				= NULL;
						char* object_name1		= NULL;	 
						char* ver_name			= NULL;		 
						char* item_id1			= NULL;	 
						char *AliasTransFileName= NULL;
						char *t5ApplOwnerDValCheckaaa= NULL;
						char *t5ApplOwnerDValCheckss =	NULL; //Adi TZ1.37 
						char *t5ApplOwnerDValCheckss11=	NULL; //Adi TZ1.37 
					 
						char *ErrMsg = (char *) MEM_alloc(200 * sizeof(char *));

					 printf("\n in save method 18888888888888 \n");fflush(stdout);

					 if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
					  if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
					  printf("\n save_method_18::type_name :%s\n", type_name);fflush(stdout);



					  if (GRM_ask_primary (objTag,&priObjTag)!=ITK_ok);
					  if (TCTYPE_ask_object_type(priObjTag,&priObjTypeTag)!=ITK_ok);
					  if (TCTYPE_ask_name2(priObjTypeTag,&type_name1)!=ITK_ok);
					  //if (TCTYPE_ask_name2(priObjTypeTag,t5ApplOwnerDValCheckaaa)!=ITK_ok);

					  if (tc_strcmp(type_name1,"T5_ERCIndRevision")!=0)
					  {
							 if (tc_strstr(type_name1,"T5_TSComp")==NULL)
							 {
								if( AOM_ask_value_string(priObjTypeTag,"t5_ApplicationOwner",&t5ApplOwnerDValCheckaaa)!=ITK_ok); 
							 }
							
							printf("\n save_method_18::pri_type_name :%s  application owner is %s \n", type_name1,t5ApplOwnerDValCheckaaa);fflush(stdout);
					  }
					  printf("\n save_method_18::pri_type_name :%s  application owner is %s \n", type_name1,t5ApplOwnerDValCheckaaa);fflush(stdout);
					  
					  if (GRM_ask_secondary (objTag,&secObjTag)!=ITK_ok);
					  if (TCTYPE_ask_object_type(secObjTag,&secObjTypeTag)!=ITK_ok);
					  if (TCTYPE_ask_name2(secObjTypeTag,&type_name2)!=ITK_ok);
					  printf("\n save_method_18::sec_type_name :%s\n", type_name2);fflush(stdout);
						int tscount=0;
						tag_t    *TSbypassCntrlObjSet=NULLTAG;
						ITK_CALL(getCntrlObj( "TechRelBypass",&tscount ,&TSbypassCntrlObjSet));
						printf("\n inside save_method_18 tscount[%d]",tscount);fflush(stdout);
						if(tscount>0)
						{
						  if(tc_strstr(type_name2,"Design")!=0 && tc_strcmp(type_name1,"T5_TSComp")==0)
								{
									AOM_ask_value_string(secObjTag,"item_id",&VehNo);
									printf( "\n save_method_18:: - item_id: %s\n", VehNo);fflush(stdout);
									sprintf(ErrMsg,"Dropping Vehicle [%s] on TechSpec is not valid with Specification relation .",VehNo);
									//EMH_store_error_s2(EMH_severity_error,ITK_err,"Tech Spec has not been classified,so update the classified value first for TechSpec[%s]",tsitem);
									printf("\n ErrMsg[%s] ",ErrMsg); fflush(stdout);
									ITK_CALL(EMH_store_error_s1(EMH_severity_error,ITK_err,ErrMsg));
									return ITK_err;
								}
						}
					  
						if(tc_strcmp(type_name2,"T5_Alias")==0)
						{
							printf("\n DATASET TYPE IS [%s] \n" ,type_name2);fflush(stdout);

							//Adi TZ 1.37 BEGINS
							if(AOM_lock(secObjTag))PrintErrorStack();									
							if( AOM_set_value_string(secObjTag,"t5_ApplicationOwnerD","Alias")!=ITK_ok);   
							printf("\n in Alias AOM_set_value_string for app owner \n");fflush(stdout);

							if(AOM_save_without_extensions(secObjTag))PrintErrorStack();
							printf("\n in Alias save..\n");fflush(stdout);

							if(AOM_unlock(secObjTag))PrintErrorStack();
							printf("\n in Alias unlock..\n");fflush(stdout);
							
							if(AOM_refresh(secObjTag,TRUE))PrintErrorStack();
							printf("\n in Alias refresh..\n");fflush(stdout);

							if( AOM_ask_value_string(secObjTag,"t5_ApplicationOwnerD",&t5ApplOwnerDValCheckss11)!=ITK_ok);
							printf("\n After Alias dataset t5ApplOwnerDValCheckD %s\n", t5ApplOwnerDValCheckss11);fflush(stdout);

							if( AOM_ask_value_string(priObjTag,"t5_ApplicationOwner",&t5ApplOwnerDValCheckss)!=ITK_ok);
							printf("\n After saving relation of Alias dataset t5ApplOwnerDValCheck %s\n", t5ApplOwnerDValCheckss);fflush(stdout);
							//Adi TZ 1.37 ENDS

							//AOM_get_value_string(priObjTag, "object_name", &object_name1);	
							if (AOM_ask_value_string(priObjTag, "object_name", &object_name1)!=ITK_ok) PrintErrorStack();	
							printf("\n object_name1 [%s] \n" ,object_name1);fflush(stdout);

							//AOM_get_value_string(objTag, "revision_number", &ver_name);	
							//printf("\n ver_name [%s] \n" ,ver_name);fflush(stdout);

							if(ITEM_find_item(object_name1,&ref_item));

							if(ITEM_ask_latest_rev(ref_item,&LatestRev));
							
							if( AOM_ask_value_string(LatestRev,"item_revision_id",&RevL)==ITK_ok) 
							printf("\n item_revision_id AAA--------------%s \n",RevL);fflush(stdout);

							if( AOM_ask_value_string(LatestRev,"item_id",&item_id1)==ITK_ok) 
							printf("\n item_id1 AAA--------------%s \n",item_id1);fflush(stdout);
											
							AliasTransFileName=malloc(2000);
							strcpy(AliasTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i='");
							//strcpy(JTTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=282960203301  -r='A;5' -dn=282960203301/NR -dt=CMI2Part -pr=1 -pn=SIEMENS -tn=catiav5tojt -ty=COMMAND_LINE");
							tc_strcat(AliasTransFileName,item_id1);
							tc_strcat(AliasTransFileName,"'");
							tc_strcat(AliasTransFileName," ");

							tc_strcat(AliasTransFileName,"-r='");
							tc_strcat(AliasTransFileName,RevL);
							tc_strcat(AliasTransFileName,"'");
							tc_strcat(AliasTransFileName," ");

							tc_strcat(AliasTransFileName,"-dt='");
							tc_strcat(AliasTransFileName,type_name2);
							tc_strcat(AliasTransFileName,"'");
							tc_strcat(AliasTransFileName," ");

							tc_strcat(AliasTransFileName,"-dn='");
							tc_strcat(AliasTransFileName,object_name1);
							tc_strcat(AliasTransFileName,"'");
							tc_strcat(AliasTransFileName," ");

							tc_strcat(AliasTransFileName,"-pr=1");
							tc_strcat(AliasTransFileName," ");
							tc_strcat(AliasTransFileName,"-pn=SIEMENS");
							tc_strcat(AliasTransFileName," ");
							tc_strcat(AliasTransFileName,"-tn=aliastocatpart");
							tc_strcat(AliasTransFileName," ");
							tc_strcat(AliasTransFileName,"-ty=COMMAND_LINE");

							printf("\n AliasTransFileName  T5_Alias before system is  =>%s\n", AliasTransFileName);fflush(stdout);

							system(AliasTransFileName);

							printf("\n After T5_Alias dispatcher_create_rqst shell =>%s\n", AliasTransFileName);fflush(stdout);

						}
					return ITK_ok;

				}
							/*********** Adi Alias ************/

				// Akash
				extern DLLAPI int Indent_Rev_Post_Msg(METHOD_message_t *msg, va_list args)
				{
					int			error_code			= ITK_ok;
					tag_t		objTag				= va_arg(args, tag_t);

					char		*IndentNo		= NULL;
					char		*ERCBU		= NULL;
					char		*PowerTrainInd		= NULL;
					char		*t5PlatForm		= NULL;
					char		*ERCIndentee		= NULL;
					char		*Refno		= NULL;
					char		*IndentRefNum		= NULL;
					char		*IndentRoleName		= NULL;
					char		*WBSNo		= NULL;
					char		*Wbs_desc		= NULL;
					char		*type_name		= NULL;
					//char		type_name[TCTYPE_name_size_c+1];
					tag_t		objTypeTag			= NULLTAG;
					const char *select_attrs[]={"t5ERCWrkOrd"};
					const char *str_list[1];
					int n_rows;
					int n_cols;
					int row;
					int column;
					int i;
					int				n_entriesV				= 1;
					int				No_of_WO				= 0;
					int				ii				= 0;
					void ***report;
					tag_t			WBS_tag						= NULLTAG;
					char			**wbs_no			= (char **) MEM_alloc(1 * sizeof(char *));
					char			*qry_entries3[1]		= {"Work Order Number"};
					tag_t			*WO_tag				= NULLTAG;
					tag_t			WorkOrder			= NULLTAG;
					IndentRoleName = (char	*)MEM_alloc(100);

					printf("\n **** Inside the Indent Revision Creation Post **** \n");fflush(stdout);

					if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok)PrintErrorStack();
					if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok)PrintErrorStack();
					printf("\nPart type is:%s", type_name);
					if(strcmp(type_name,"T5_ERCIndRevision")==0)
					{
						error_code = AOM_UIF_ask_value(objTag, "item_id", &IndentNo);
						printf("\n Indent No item_id == [%s]\n", IndentNo);fflush(stdout);

						error_code = AOM_UIF_ask_value(objTag, "t5RefNo", &Refno);
						printf("\n Indent Reference No == [%s]\n", Refno);fflush(stdout);

						error_code = AOM_UIF_ask_value(objTag, "t5WBS", &WBSNo);
						printf("\n Indent WBS No == [%s]\n", WBSNo);fflush(stdout);

						str_list[0]=WBSNo;
						printf("\nstr_list[0]=%s",str_list[0]);

						AOM_ask_value_string(objTag,"t5ERCIndBU",&ERCBU);
						printf("ERCBU ::  %s\n", ERCBU);fflush(stdout);
						
						AOM_ask_value_string(objTag,"t5IndChkPRD",&PowerTrainInd);
						printf("PowerTrainInd ::  %s\n", PowerTrainInd);fflush(stdout);
						
						AOM_ask_value_string(objTag,"t5_IndPlatform",&t5PlatForm);
						printf("t5PlatForm ::  %s\n", t5PlatForm);fflush(stdout);
						
						AOM_ask_value_string(objTag,"t5ERCIndentee",&ERCIndentee);
						printf("ERCIndentee ::  %s\n", ERCIndentee);fflush(stdout);
						
						//AOM_get_value_string(objTag, "t5RefNo", &IndentRefNum);  
						if (AOM_ask_value_string(objTag, "t5RefNo", &IndentRefNum)!=ITK_ok) PrintErrorStack();
						printf("IndentRefNum ::  %s\n", IndentRefNum);fflush(stdout);
						
						tag_t	HomeSiteNameQry		= NULLTAG;
						char    *SiteName_qry_entry[1]  = {"SYSCD"};
						char    **SiteName_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
						int     SiteNm_rsltCount    = 0;
						tag_t	*SiteNameCntrlObjectTag	= NULLTAG;
						int     SiteName_n_entry    = 1;
						char*	 SiteNameinfo1 = NULL;
						char*	 SiteNameinfo2IndName = NULL;
						char*	 info3PltFormLive = NULL;
						
						if(QRY_find2("ControlObjects", &HomeSiteNameQry));
						if (HomeSiteNameQry)
						{
							printf("\n Found Query HomeSiteNameQry.");fflush(stdout);
						}
						else
						{
							printf("\n Not Found Query HomeSiteNameQry.");fflush(stdout);
						}

						SiteName_qry_values2[0] = "SiteNameDeatils";
						if(QRY_execute(HomeSiteNameQry, SiteName_n_entry, SiteName_qry_entry, SiteName_qry_values2, &SiteNm_rsltCount, &SiteNameCntrlObjectTag));
						printf(" \n SiteNm_rsltCount :%d:", SiteNm_rsltCount); fflush(stdout);
						
						if(SiteNm_rsltCount > 0)
						{
							if (AOM_ask_value_string(SiteNameCntrlObjectTag[0],"t5_Userinfo1",&SiteNameinfo1)!=ITK_ok);
							printf("\n :SiteNameinfo1 is : [%s]", SiteNameinfo1);fflush(stdout);
							
							if (AOM_ask_value_string(SiteNameCntrlObjectTag[0],"t5_Userinfo2",&SiteNameinfo2IndName)!=ITK_ok);
							printf("\n :SiteNameinfo2IndName is : [%s]", SiteNameinfo2IndName);fflush(stdout);
							
							if (AOM_ask_value_string(SiteNameCntrlObjectTag[0],"t5_Userinfo3",&info3PltFormLive)!=ITK_ok);
							printf("\n :info3PltFormLive is : [%s]", info3PltFormLive);fflush(stdout);
							
							if(tc_strcmp(info3PltFormLive,"IndentPlatFormLive")==0)
							{
								if(tc_strcmp(ERCBU,NULL)!=0 || tc_strcmp(ERCBU,"")!=0)
								{
									if(tc_strcmp(PowerTrainInd,"Y") == 0)
									{
										if(tc_strcmp(ERCIndentee,"Proto Planning") == 0)
										{
										tc_strcpy(IndentRoleName,"");
										tc_strcpy(IndentRoleName,"PRD_Prt_Ind_Planning_Grp");
										printf("\n PowerTrainInd and ERCIndentee are: [%s][%s]",PowerTrainInd, ERCIndentee);fflush(stdout);
										}
										
										else if(tc_strcmp(ERCIndentee,"LKO Proto Planning") == 0)
										{
										tc_strcpy(IndentRoleName,"");
										tc_strcpy(IndentRoleName,"LKO_Prt_Ind_Planning_Grp");
										printf("\n PowerTrainInd and ERCIndentee are: [%s][%s]",PowerTrainInd, ERCIndentee);fflush(stdout);
										}
										
										else if(tc_strcmp(ERCIndentee,"JSR Proto Planning") == 0)
										{
										tc_strcpy(IndentRoleName,"");
										tc_strcpy(IndentRoleName,"JSR_Prt_Ind_Planning_Grp");
										printf("\n PowerTrainInd and ERCIndentee are: [%s][%s]",PowerTrainInd, ERCIndentee);fflush(stdout);
										}
									}
									else if(tc_strcmp(ERCBU,"CVBU") == 0 && tc_strcmp(PowerTrainInd,"N") == 0)
									{
										if(tc_strcmp(t5PlatForm,NULL)!=0 || tc_strcmp(t5PlatForm,"")!=0)
										{
											printf("\n 33333IN CVBU :t5PlatForm is : [%s]", t5PlatForm);fflush(stdout);
											
											if(tc_strcmp(ERCIndentee,"Proto Planning") == 0)
											{
												tc_strcpy(IndentRoleName,"");
												tc_strcat(IndentRoleName,t5PlatForm);
												tc_strcat(IndentRoleName,"_Prt_Ind_Planning_Grp");
												
												printf("\n :33333IndentRoleName is : [%s]", IndentRoleName);fflush(stdout);
											}
											else if(tc_strcmp(ERCIndentee,"LKO Proto Planning") == 0)
											{
												tc_strcpy(IndentRoleName,"");
												tc_strcat(IndentRoleName,"LKO_Prt_Ind_Planning_Grp");
												
												printf("\n 33333Under LKO Proto Planning :IndentRoleName is : [%s]", IndentRoleName);fflush(stdout);
											}
											else if(tc_strcmp(ERCIndentee,"JSR Proto Planning") == 0)
											{
												tc_strcpy(IndentRoleName,"");
												tc_strcat(IndentRoleName,"JSR_Prt_Ind_Planning_Grp");
												
												printf("\n 33333Under JSR Proto Planning :IndentRoleName is : [%s]", IndentRoleName);fflush(stdout);
											}
										}
										
										else
										{
											printf("\n IN CVBU indent Platform is null :");fflush(stdout);
											tc_strcpy(IndentRoleName,"");
											tc_strcpy(IndentRoleName,"CVBU_Prt_Ind_Planning_Grp");
										}
										//tc_strcpy(IndentRoleName,"");
										//tc_strcpy(IndentRoleName,"CVBU_Prt_Ind_Planning_Grp");
									}
									else if(tc_strcmp(ERCBU,"PVBU") == 0 && tc_strcmp(PowerTrainInd,"N") == 0) 
									{
										if(tc_strcmp(t5PlatForm,NULL)!=0 || tc_strcmp(t5PlatForm,"")!=0)
										{
											tc_strcpy(IndentRoleName,"");
											tc_strcat(IndentRoleName,t5PlatForm);
											tc_strcat(IndentRoleName,"_Prt_Ind_Planning_Grp");
											
											printf("\n :IndentRoleName is : [%s]", IndentRoleName);fflush(stdout);
										}
										else
										{
											printf("\n indent Planform is null : [%s]", t5PlatForm);fflush(stdout);
											tc_strcpy(IndentRoleName,"");
											tc_strcpy(IndentRoleName,"PCBU_Prt_Ind_Planning_Grp");
										}
									}
								}
								else
								{
									printf("\n Business unit is null : [%s]", ERCBU);fflush(stdout);
									tc_strcpy(IndentRoleName,"");
									tc_strcpy(IndentRoleName,"Default_Prt_Ind_Planning_Grp");
									printf("\n in else IndentRoleName is : [%s]", IndentRoleName);fflush(stdout);
								}
								printf("Final ERCBU:[%s]  ,  IndentRoleName :[%s] t5PlatForm:[%s]", ERCBU, IndentRoleName,t5PlatForm);fflush(stdout);
								
								if(tc_strcmp(IndentRoleName,NULL)!=0 || tc_strcmp(IndentRoleName,"")!=0)
								{
									AOM_lock(objTag);
									AOM_set_value_string(objTag, "t5Indentee", IndentRoleName);
									AOM_save_without_extensions(objTag);
									AOM_unlock(objTag);
									AOM_refresh(objTag,TRUE);
								}
							}
							else
							{
								//if(ERCBU != NULL)
								if(tc_strcmp(ERCBU,NULL)!=0 || tc_strcmp(ERCBU,"")!=0)
								{
									if(tc_strcmp(ERCBU,"CVBU") == 0 && tc_strcmp(ERCIndentee,"LKO Proto Planning") == 0)
									{
										tc_strcpy(IndentRoleName,"LKO_Prt_Ind_Planning_Grp");
									}
									else if(tc_strcmp(ERCBU,"CVBU") == 0 && tc_strcmp(ERCIndentee,"JSR Proto Planning") == 0)
									{	
										tc_strcpy(IndentRoleName,"JSR_Prt_Ind_Planning_Grp");										
									}
									else if(tc_strcmp(PowerTrainInd,"Y") == 0)
									{
										tc_strcpy(IndentRoleName,"PRD_Prt_Ind_Planning_Grp");
									}
									else if(tc_strcmp(ERCBU,"CVBU") == 0 && tc_strcmp(PowerTrainInd,"N") == 0)
									{
										tc_strcpy(IndentRoleName,"CVBU_Prt_Ind_Planning_Grp");
									}
									else if(tc_strcmp(ERCBU,"PVBU") == 0 && tc_strcmp(PowerTrainInd,"N") == 0) 
									{
										tc_strcpy(IndentRoleName,"PCBU_Prt_Ind_Planning_Grp");
									}
								}
								printf("\n ERCBU  :: [%s]  ,  IndentRoleName ::  [%s] ERCIndentee [%s]", ERCBU, IndentRoleName,ERCIndentee);fflush(stdout);

								if(IndentRoleName != NULL)
								{
									AOM_lock(objTag);
									AOM_set_value_string(objTag, "t5Indentee", IndentRoleName);
									AOM_save_without_extensions(objTag);
									AOM_unlock(objTag);
									AOM_refresh(objTag,TRUE);
								}
							}
							printf(" finalERCBU  :: %s  ,  IndentRoleName ::  %s\n", ERCBU, IndentRoleName);fflush(stdout);
						}
						else
						{
							printf(" \n contorl object not found SiteNm_rsltCount :%d:", SiteNm_rsltCount); fflush(stdout);
						}

						


						/*POM_enquiry_create ("WBS_Desc");
						POM_enquiry_add_select_attrs ("WBS_Desc","T5ERCWORevision", 1, select_attrs);
						POM_enquiry_set_string_value ("WBS_Desc","attrval",1,str_list,POM_enquiry_bind_value);
						POM_enquiry_set_attr_expr ("WBS_Desc","expr1", "T5ERCWORevision","t5ERCWrkOrd",POM_enquiry_like, "attrval");
						POM_enquiry_set_where_expr ("WBS_Desc","expr1");
						POM_enquiry_add_order_attr( "WBS_Desc", "T5ERCWORevision", "item_id", POM_enquiry_desc_order );
						POM_enquiry_execute ("WBS_Desc", &n_rows, &n_cols,&report);
						POM_enquiry_delete("WBS_Desc");

						printf("\n \n number of row : %d cols : %d \n",n_rows,n_cols);fflush(stdout);

						for (row = 0; row < n_rows; row++)
						{
							for (column = 0; column < n_cols; column++)
							{
								printf("\n Query return=%s\t", report[row][column]);	
							}
						}


						if(n_rows > 0 ) 
						{
							tag_t *objs = NULLTAG;
							(objs) = (tag_t *) MEM_alloc( 100 *sizeof(tag_t)); 
									
							for(i=0; i<n_cols; i++)
							{
								  (objs)[i] = (*(tag_t *)( report [i][0]));

								 // ITK_CALL(ITEM_ask_latest_rev((objs)[i], &WBS_tag));
								  error_code = AOM_ask_value_string((objs)[i],"t5ERCWODesc",&Wbs_desc);
								  printf("\n Wbs_desc is  : %s\n\n",Wbs_desc);	fflush(stdout);							  
							}						
						}*/
						int				n_entIndWO				= 1;
						int				No_of_IndWO				= 0;
						int				jj				= 0;
						char			**wbs_no			= (char **) MEM_alloc(1 * sizeof(char *));
						char			*qry_entIndWO[1]		= {"Work Breakdown Structure"};
						tag_t			*IndWO_tag				= NULLTAG;
						tag_t			IndWOQ			= NULLTAG;
						char		*IndNumWbs		= NULL;
						char		*IndEstCost		= NULL;
						float totalIndEstCost =0.0;
						
						error_code = QRY_ignore_case_on_search(TRUE);
						QRY_find2("ERC Indent", &IndWOQ);
						wbs_no[0] = WBSNo ;

						QRY_execute(IndWOQ, n_entIndWO, qry_entIndWO, wbs_no, &No_of_IndWO, &IndWO_tag);

						if(!IndWO_tag)
						{
							printf("\n ERC Indent Query Not Found in TC....!!\n");
							return 0;
						}
						
						if (No_of_IndWO > 0)
						{
							for (jj = 0;jj < No_of_IndWO ; jj ++ )
							{
								
								printf("\n Loop Number	== [%d] ",jj);fflush(stdout);
								
								if(AOM_ask_value_string(IndWO_tag[jj],"item_id",&IndNumWbs)==ITK_ok);
								printf("\n IndNumWbs	== [%s] ",IndNumWbs);fflush(stdout);
								
								if(AOM_ask_value_string(IndWO_tag[jj],"t5EstmCost",&IndEstCost)==ITK_ok);
								printf("\n IndEstCost	== [%s] ",IndEstCost);fflush(stdout);
								
								float FlIndEstCost = atof(IndEstCost);
								
								printf("\n Float Value of IndEstCost	== [%f] ",FlIndEstCost);fflush(stdout);
								
								totalIndEstCost = totalIndEstCost + FlIndEstCost;
								
								printf("\n Total Value of IndEstCost	== [%f] ",totalIndEstCost);fflush(stdout);
								
							}
						}
						printf("\n Final Total Value of IndEstCost	== [%f] ",totalIndEstCost);fflush(stdout);
						//char strtotalIndEstCost[50];
						//sprintf(strtotalIndEstCost, "%f", totalIndEstCost);
						
						//printf("The converted value strtotalIndEstCost: [%s]", strtotalIndEstCost);fflush(stdout);
						
						error_code = QRY_ignore_case_on_search(TRUE);
						QRY_find2("ERC_Work_Order", &WorkOrder);
						wbs_no[0] = WBSNo ;
						

						QRY_execute(WorkOrder, n_entriesV, qry_entries3, wbs_no, &No_of_WO, &WO_tag);

						if(!WO_tag)
						{
							printf("\nQuery Not Found in TC....!!\n");
							return 0;
						}
						

						printf(" \n No of Work Order = %d\n",No_of_WO);

						if (No_of_WO > 0)
						{
							for (ii = 0;ii < No_of_WO ; ii ++ )
							{
								
								char		*WbsMatApprovedBdg		= NULL;
								char		*WbsMatConsumedBdg		= NULL;
								char		*WbsMatInventryBdg		= NULL;
								char		*WbsMatOpenCmntBdg		= NULL;
								
								char		*IndBudgetInfo=(char *) MEM_alloc(300); 
								
								if(AOM_ask_value_string(WO_tag[ii],"t5ERCWODesc",&Wbs_desc)==ITK_ok);
								printf("\n Wbs_desc	== %s \n",Wbs_desc);fflush(stdout);
								
								if(AOM_ask_value_string(WO_tag[ii],"t5_MatApprovedBdg",&WbsMatApprovedBdg)==ITK_ok);
								printf("\n WbsMatApprovedBdg	== [%s]",WbsMatApprovedBdg);fflush(stdout);
								
								if(AOM_ask_value_string(WO_tag[ii],"t5_MatConsumedBdg",&WbsMatConsumedBdg)==ITK_ok);
								printf("\n WbsMatConsumedBdg	== [%s]",WbsMatConsumedBdg);fflush(stdout);
								
								if(AOM_ask_value_string(WO_tag[ii],"t5_MatInventryBdg",&WbsMatInventryBdg)==ITK_ok);
								printf("\n WbsMatInventryBdg	== [%s]",WbsMatInventryBdg);fflush(stdout);
								
								if(AOM_ask_value_string(WO_tag[ii],"t5_MatOpenCmntBdg",&WbsMatOpenCmntBdg)==ITK_ok);
								printf("\n WbsMatOpenCmntBdg	== [%s]",WbsMatOpenCmntBdg);fflush(stdout);

								if(AOM_lock(objTag))PrintErrorStack();
								printf("\n Before setting Value \n");fflush(stdout);
								if( AOM_set_value_string(objTag,"t5IndWbsDes",Wbs_desc))PrintErrorStack();
								if( AOM_set_value_string(objTag,"t5RefNo",IndentNo))PrintErrorStack();
								
								if(tc_strlen(WbsMatApprovedBdg)>0)
								{
								if( AOM_set_value_string(objTag,"t5_IndMatApprovedBdg",WbsMatApprovedBdg))PrintErrorStack();
								}
								if(tc_strlen(WbsMatConsumedBdg)>0)
								{
								if( AOM_set_value_string(objTag,"t5_IndMatConsumedBdg",WbsMatConsumedBdg))PrintErrorStack();
								}
								if(tc_strlen(WbsMatInventryBdg)>0)
								{
								if( AOM_set_value_string(objTag,"t5_IndMatInventryBdg",WbsMatInventryBdg))PrintErrorStack();
								}
								if(tc_strlen(WbsMatOpenCmntBdg)>0)
								{
								if( AOM_set_value_string(objTag,"t5_IndMatOpenCmntBdg",WbsMatOpenCmntBdg))PrintErrorStack();
								}
								
								printf("\n After setting Value\n");fflush(stdout);
								if(AOM_save_without_extensions(objTag))PrintErrorStack();
								if(AOM_unlock(objTag))PrintErrorStack();
								if(AOM_refresh(objTag,1))PrintErrorStack();
								//----------------
								char		*IndMatApprovedBdg		= NULL;
								char		*IndMatConsumedBdg		= NULL;
								char		*IndMatInventryBdg		= NULL;
								char		*IndMatOpenCmntBdg		= NULL;
								
																
								if(AOM_ask_value_string(objTag,"t5_IndMatApprovedBdg",&IndMatApprovedBdg)==ITK_ok);
								printf("\n IndMatApprovedBdg	== [%s]",IndMatApprovedBdg);fflush(stdout);
								
								float FloatIndMatApprovedBdg = atof(IndMatApprovedBdg);
								
								printf("The converted value FloatIndMatApprovedBdg: [%f]", FloatIndMatApprovedBdg);fflush(stdout);
								
								if(AOM_ask_value_string(objTag,"t5_IndMatConsumedBdg",&IndMatConsumedBdg)==ITK_ok);
								printf("\n IndMatConsumedBdg	== [%s]",IndMatConsumedBdg);fflush(stdout);
								
								float FloatIndMatConsumedBdg = atof(IndMatConsumedBdg);
								
								printf("The converted value FloatIndMatConsumedBdg: [%f]", FloatIndMatConsumedBdg);fflush(stdout);
								
								if(AOM_ask_value_string(objTag,"t5_IndMatInventryBdg",&IndMatInventryBdg)==ITK_ok);
								printf("\n IndMatInventryBdg	== [%s]",IndMatInventryBdg);fflush(stdout);
								
								float FloatIndMatInventryBdg = atof(IndMatInventryBdg);
								
								printf("The converted value FloatIndMatInventryBdg: [%f]", FloatIndMatInventryBdg);fflush(stdout);
								
								if(AOM_ask_value_string(objTag,"t5_IndMatOpenCmntBdg",&IndMatOpenCmntBdg)==ITK_ok);
								printf("\n IndMatOpenCmntBdg	== [%s]",IndMatOpenCmntBdg);fflush(stdout);
								
								float FloatIndMatOpenCmntBdg = atof(IndMatOpenCmntBdg);
								
								printf("The converted value FloatIndMatOpenCmntBdg: [%f]", FloatIndMatOpenCmntBdg);fflush(stdout);
								
								printf("Total Estimate cost for WBS: [%s] is [%f]", WBSNo,totalIndEstCost);fflush(stdout);
								
								float totalUsedBdt = FloatIndMatConsumedBdg + FloatIndMatInventryBdg + FloatIndMatOpenCmntBdg + totalIndEstCost;
								
								printf("\n totalUsedBdt: [%f]", totalUsedBdt);fflush(stdout);
								
								float AvlBalBdt = FloatIndMatApprovedBdg - totalUsedBdt ;
								
								printf("\n AvlBalBdt: [%f]", AvlBalBdt);fflush(stdout);
								
								//char		*strAvlBalBdt		= NULL;
								
								char strAvlBalBdt[50];
								sprintf(strAvlBalBdt, "%f", AvlBalBdt);
								
								printf("The converted value strAvlBalBdt: [%s]", strAvlBalBdt);fflush(stdout);
								
								tc_strcpy (IndBudgetInfo, "");
								tc_strcpy (IndBudgetInfo, "Information:For Indent [");
								strcat(IndBudgetInfo,IndentNo);
								strcat(IndBudgetInfo,"], WBS[");
								strcat(IndBudgetInfo,WBSNo);
								strcat(IndBudgetInfo,"] Approved Budget is [");
								strcat(IndBudgetInfo,strAvlBalBdt);
								strcat(IndBudgetInfo,"].");
								printf("\n For Indent [%s] WBS[%s] Approved Budget is [%s]",IndentNo,WBSNo,strAvlBalBdt);fflush(stdout);
								printf("\n IndBudgetInfo111 [%s] ",IndBudgetInfo);fflush(stdout);
								//EMH_store_error_s1(EMH_severity_information,ITK_errInd,IndBudgetInfo);
								//return 0;
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_warning,ITK_errInd,IndBudgetInfo);
							}
						}		
					}

					AOM_UIF_ask_value(objTag, "t5RefNo", &Refno);
					printf("\n Indent Reference No == [%s]\n", Refno);fflush(stdout);

					printf("\n **** Exit Indent Revision Creation Post **** \n");fflush(stdout);
					return error_code;
				}
				extern DLLAPI int Indent_Rev_Pre_Msg(METHOD_message_t *msg, va_list args)
				{
					int			error_code			= ITK_ok;
					int			No_of_WOP			= 0;
					int			ii			= 0;
					int			ChkBUWBSIndFlag			= 0;
					tag_t		objTag				= va_arg(args, tag_t);

					char		*IndentNo		= NULL;
					char		*t5PlatForm		= NULL;
					char		*ERCBU		= NULL;
					char		*WBS_No		= NULL;
					char		*Wbs_desc		= NULL;
					char		*WBSNoP		= NULL;
					char		*WbsBU		= NULL;
					
					char		*Refno		= NULL;
					char *WBS_str = NULL;
					char *type_name = NULL;
					//char		type_name[TCTYPE_name_size_c+1];
					tag_t		objTypeTag			= NULLTAG;
					char			**wbs_no_pre			= (char **) MEM_alloc(1 * sizeof(char *));
					
					char			*qry_entriesP3[1]		= {"Work Order Number"};
					tag_t			*WO_tag_pre				= NULLTAG;
					tag_t			WorkOrderP			= NULLTAG;
					int				n_entries				= 1;
					int			EditIndFlg			= 0;

					printf("\n **** Inside the Indent Revision Creation Pre **** \n");fflush(stdout);

					if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
					if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);PrintErrorStack();
					printf("\nPart type is:%s", type_name);
					char*	 username = NULL;
					
					if(POM_get_user_id (&username)!=ITK_ok)PrintErrorStack();
					
					char *SupportUsername6 = NULL;
					tag_t SessionUser6_tag=NULLTAG;
					int     SupportFlag      =  0;
					POM_get_user(&SupportUsername6,&SessionUser6_tag);
					if(SessionUser6_tag!=NULLTAG)
					{
						SupportFlag=0;
						SupportFlag = CheckSupportLogin(SessionUser6_tag);
						printf("\n SupportFlag......: %d",SupportFlag);fflush(stdout);
					}
					printf("\n Login check-6 End......:%d\n",SupportFlag);fflush(stdout);
					
					char		*useridPP		=	NULL;
					char		*homeSitePP			=	NULL;
		
					SA_ask_user_identifier2 (SessionUser6_tag,&useridPP);
					printf ("\n Logged in user for Platform attribute updation is :[%s] [%s] ",useridPP,SupportUsername6);fflush(stdout);
					AOM_UIF_ask_value(SessionUser6_tag,"fnd0home_site",&homeSitePP);
					printf("\n Logged in fnd0home_site for Platform attribute updation is : [%s]",homeSitePP);fflush(stdout);
					
					if(strcmp(type_name,"T5_ERCIndRevision")==0)
					{
						error_code = AOM_UIF_ask_value(objTag, "item_id", &IndentNo);
						printf("\n Indent No item_id == [%s]\n", IndentNo);fflush(stdout);
						
						error_code = AOM_UIF_ask_value(objTag, "t5_IndPlatform", &t5PlatForm);
						printf("\n Indent t5PlatForm == [%s] ", t5PlatForm);fflush(stdout);
						
						tag_t	HomeSiteNameQry		= NULLTAG;
						char    *SiteName_qry_entry[1]  = {"SYSCD"};
						char    **SiteName_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
						int     SiteNm_rsltCount    = 0;
						tag_t	*SiteNameCntrlObjectTag	= NULLTAG;
						int     SiteName_n_entry    = 1;
						char*	 SiteNameinfo1 = NULL;
						char*	 SiteNameinfo2IndName = NULL;
						char*	 info3PltFormLive = NULL;
						
						if(QRY_find2("ControlObjects", &HomeSiteNameQry));
						if (HomeSiteNameQry)
						{
							printf("\n Found Query HomeSiteNameQry.");fflush(stdout);
						}
						else
						{
							printf("\n Not Found Query HomeSiteNameQry.");fflush(stdout);
						}

						SiteName_qry_values2[0] = "SiteNameDeatils";
						if(QRY_execute(HomeSiteNameQry, SiteName_n_entry, SiteName_qry_entry, SiteName_qry_values2, &SiteNm_rsltCount, &SiteNameCntrlObjectTag));
						printf(" \n SiteNm_rsltCount :%d:", SiteNm_rsltCount); fflush(stdout);
						
						
						if(SiteNm_rsltCount > 0)
						{
							if (AOM_ask_value_string(SiteNameCntrlObjectTag[0],"t5_Userinfo1",&SiteNameinfo1)!=ITK_ok)   PrintErrorStack();
							printf("\n :SiteNameinfo1 is : [%s]", SiteNameinfo1);fflush(stdout);
							
							if (AOM_ask_value_string(SiteNameCntrlObjectTag[0],"t5_Userinfo2",&SiteNameinfo2IndName)!=ITK_ok)   PrintErrorStack();
							printf("\n :SiteNameinfo2IndName is : [%s]", SiteNameinfo2IndName);fflush(stdout);
							
							if(strcmp(homeSitePP,SiteNameinfo1)==0)
							{
								printf("\n Site Name Match");fflush(stdout);
								printf("\n homeSitePP [%s]",homeSitePP);fflush(stdout);
								printf("\n SiteNameinfo1 [%s]",SiteNameinfo1);fflush(stdout);
								
								if(tc_strstr(IndentNo,SiteNameinfo2IndName)!=NULL)
								{
									printf("\n IF condition Mathched");fflush(stdout);
									printf("\n Indent Number [%s]",IndentNo);fflush(stdout);
									printf("\n Indent Start with is [%s]",SiteNameinfo2IndName);fflush(stdout);
								}
								else
								{
									printf("\n ELSE condition NOT Matched");fflush(stdout);
									printf("\n Indent is [%s]",IndentNo);fflush(stdout);
									printf("\n Indent Start with is [%s]",SiteNameinfo2IndName);fflush(stdout);
									printf("\n sitename is [%s]",homeSitePP);fflush(stdout);
									
									EMH_store_error_s3(EMH_severity_error,IndNameNotMatchError,"Please Assign 'ID' start with ", SiteNameinfo2IndName ," in 'ERC Indent' form.");
									return IndNameNotMatchError;
								}
							}
							
						}
						
						// if(SiteNm_rsltCount > 0)
						// {
							
							// if (AOM_ask_value_string(SiteNameCntrlObjectTag[0],"t5_Userinfo1",&SiteNameinfo1)!=ITK_ok);
							// printf("\n :SiteNameinfo1 is : [%s]", SiteNameinfo1);fflush(stdout);
							
							// if (AOM_ask_value_string(SiteNameCntrlObjectTag[0],"t5_Userinfo2",&SiteNameinfo2IndName)!=ITK_ok);
							// printf("\n :SiteNameinfo2IndName is : [%s]", SiteNameinfo2IndName);fflush(stdout);
							
							// if (AOM_ask_value_string(SiteNameCntrlObjectTag[0],"t5_Userinfo3",&info3PltFormLive)!=ITK_ok);
							// printf("\n :info3PltFormLive is : [%s]", info3PltFormLive);fflush(stdout);
							
							// //if(strcmp(PrtRevSeq,designrev)==0)
							// if(tc_strcmp(info3PltFormLive,"IndentPlatFormLive")==0)
							// {
								// printf("\n test1");fflush(stdout);
								// if(tc_strcmp(t5PlatForm,"")==0 || tc_strcmp(t5PlatForm,NULL)==0)
								// {
									// printf("\n Platform is mandatory Please enter platform : [%s]", info3PltFormLive);fflush(stdout);
									// EMH_store_error_s1( EMH_severity_error,ITK_err,"Platform is mandatory Please select the platform.");
									// return ITK_err;
								// }
							// }
							// else
							// {
								// printf("\n else info3PltFormLive is : [%s]", info3PltFormLive);fflush(stdout);
							// }
						// }
						
						if(tc_strcmp(t5PlatForm,"")==0 || tc_strcmp(t5PlatForm,NULL)==0)
							{
								printf("\n Platform is blank.it is mandatory Please enter platform : [%s]", t5PlatForm);fflush(stdout);
								EMH_store_error_s1( EMH_severity_error,ITK_err,"Platform is mandatory Please select the platform.");
								return ITK_err;
							}
							else
							{
								printf("\n Platform is persent platform : [%s]", t5PlatForm);fflush(stdout);
							}
						
						printf("\n User is == [%s]", username);fflush(stdout);
						printf("\n Support Flag is [%d] ", SupportFlag);fflush(stdout);
						
						if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0) && (tc_strcmp(username,"ercjsup") !=0) && (SupportFlag==0))
						{
							tag_t   qryTagWF     = NULLTAG;
							tag_t   *IndCntrlObjTagWF      = NULLTAG;
							char   *qry_entryWF[1]  = {"SYSCD"};
							char   **qry_values2WF     =  (char **) MEM_alloc(10 * sizeof(char *));
							if(QRY_find2("ControlObjects", &qryTagWF));

							int n_entryWF    = 1;
							int  rsltCountWF      =  0;

							if (qryTagWF)
							{
								printf("\n IndWFStep:Found Query ControlObjects \n");fflush(stdout);
							}
							else
							{
								printf("\n IndWFStep:Not Found Query ControlObjects \n");fflush(stdout);
							}

							qry_values2WF[0] = "IndWFStep";

							if(QRY_execute(qryTagWF, n_entryWF, qry_entryWF, qry_values2WF, &rsltCountWF, &IndCntrlObjTagWF));
							printf(" \n IndWFStep:rsltCountWF 44:%d:", rsltCountWF); fflush(stdout);
							
							char		*IndWFStatus		= NULL;
							
							error_code = AOM_UIF_ask_value(objTag, "fnd0StartedWorkflowTasks", &IndWFStatus);
							printf("\n Indent No fnd0StartedWorkflowTasks == [%s]\n", IndWFStatus);fflush(stdout);
							
							char		*IndRelStatus		= NULL;
							CALLAPI(AOM_UIF_ask_value(objTag,"release_status_list",&IndRelStatus));
							printf("\n Indent No IndRelStatus == [%s]\n", IndRelStatus);fflush(stdout);
							
							printf("\n Indent_Rev_Pre_Msg tm_saveRelation IndWFStatusDup is:: %s Indetnt IndRelStatus[%s]",IndWFStatus,IndRelStatus);fflush(stdout);
							
							if((tc_strstr(IndRelStatus,"ERC Released")!=NULL) ||(tc_strstr(IndRelStatus,"T5_LcsErcRlzd")!=NULL))
							{
								printf("\n indent is released Cant Edit Indent");fflush(stdout);
								EditIndFlg=1;
								EMH_store_error_s2(EMH_severity_error,ERIndEditProperties,"Indent is released.You can not edit Indent Properties.", IndentNo);
								return ERIndEditProperties;
							}
							//if((tc_strstr(IndWFStatus,"Chief Eng Review")!=NULL)||(tc_strstr(IndWFStatus,"Proto Ind Review")!=NULL) ||(tc_strstr(IndWFStatus,"New Proto Ind Review 1")!=NULL))
							else if((tc_strstr(IndWFStatus,"Proto Manager Review")!=NULL) ||(tc_strstr(IndWFStatus,"Proto Engineer Review")!=NULL))
							{
								printf("\n Cant Edit Indent");fflush(stdout);
								EditIndFlg=1;
								EMH_store_error_s2(EMH_severity_error,ERIndEditProperties,"At this Step, you can not edit Indent Properties.", IndentNo);
								return ERIndEditProperties;
							}
							else if(rsltCountWF > 0)
							{
								char		*IndWFStepinfo1		= NULL;
								char		*IndWFStepinfo2		= NULL;
								
								CALLAPI(AOM_ask_value_string(IndCntrlObjTagWF[0],"t5_Userinfo1",&IndWFStepinfo1));
								printf("\n IndWFStepinfo1 is : [%s]\n", IndWFStepinfo1);fflush(stdout);
								
								CALLAPI(AOM_ask_value_string(IndCntrlObjTagWF[0],"t5_Userinfo2",&IndWFStepinfo2));
								printf("\n IndWFStepinfo2 is : [%s]\n", IndWFStepinfo2);fflush(stdout);
				
								if(strcmp(IndWFStatus,"")!=0 || strcmp(IndWFStepinfo1,"")!=0)
								{
									if((tc_strstr(IndWFStatus,IndWFStepinfo1)!=NULL))
									{
										printf("\n Cant Edit Indent");fflush(stdout);
										EditIndFlg=1;
										EMH_store_error_s2(EMH_severity_error,ERIndEditProperties,"At this Step, you can not edit Indent Properties.", IndentNo);
										return ERIndEditProperties;
									}
									
								}
								else if(strcmp(IndWFStatus,"")!=0 || strcmp(IndWFStepinfo2,"")!=0)
								{
									if((tc_strstr(IndWFStatus,IndWFStepinfo2)!=NULL))
									{
										printf("\n Cant Edit Indent");fflush(stdout);
										EditIndFlg=1;
										EMH_store_error_s2(EMH_severity_error,ERIndEditProperties,"At this Step, you can not edit Indent Properties.", IndentNo);
										return ERIndEditProperties;
									}
									
								}
								else
								{
									printf("\n IndWFStatus [%s] IndWFStepinfo1 [%s] IndWFStepinfo2 [%s] ",IndWFStatus,IndWFStepinfo1,IndWFStepinfo2);fflush(stdout);
								}
							}
							else
							{
								printf("\n u Can Edit Indent properties");fflush(stdout);
							}
						}
						if(EditIndFlg == 0)
						{
						printf("\n Final u Can Edit Indent properties");fflush(stdout);
						
						error_code = AOM_UIF_ask_value(objTag, "t5ERCIndBU", &ERCBU);
						printf("\n ERC Business Unit == [%s]\n", ERCBU);fflush(stdout);

						error_code = AOM_UIF_ask_value(objTag, "t5RefNo", &Refno);
						printf("\n Indent Reference No == [%s]\n", Refno);fflush(stdout);

						AOM_UIF_ask_value(objTag, "t5WBS", &WBSNoP);
						printf("\n Indent WBS No == [%s]\n", WBSNoP);fflush(stdout);


						error_code = QRY_ignore_case_on_search(TRUE);
						QRY_find2("ERC_Work_Order", &WorkOrderP);
						wbs_no_pre[0] = WBSNoP ;

						QRY_execute(WorkOrderP, n_entries, qry_entriesP3, wbs_no_pre, &No_of_WOP, &WO_tag_pre);

						if(!WO_tag_pre)
						{
							printf("\nQuery Not Found in TC....!!\n");
							return 0;
						}
						

						printf(" \n No of Work Order = %d\n",No_of_WOP);

						if (No_of_WOP > 0)
						{
							for (ii = 0;ii < No_of_WOP ; ii ++ )
							{
								if(AOM_ask_value_string(WO_tag_pre[ii],"t5ERCWODesc",&Wbs_desc)==ITK_ok);
								printf("\n Wbs_desc	== %s \n",Wbs_desc);fflush(stdout);

								if(AOM_ask_value_string(WO_tag_pre[ii],"t5ERCWrkOrd",&WBS_No)==ITK_ok);
								printf("\n WBS_No	== %s \n",WBS_No);fflush(stdout);

								if(AOM_ask_value_string(WO_tag_pre[ii],"t5ERCWOType",&WbsBU)==ITK_ok);
								printf("\n Wbs_BU	== %s \n",WbsBU);fflush(stdout);

								WBS_str=(char *) MEM_alloc(300);
								
								tc_strcpy (WBS_str, "Selected WBS -");
								strcat (WBS_str, WBS_No);
								strcat(WBS_str," - ");
								strcat(WBS_str,Wbs_desc);
								strcat(WBS_str,"- is Related to ");
								strcat(WBS_str,WbsBU);
								strcat(WBS_str," it is Not Valid for ");
								strcat(WBS_str,ERCBU);
								strcat(WBS_str," Indent.");

								printf("\n WBS_str	== %s \n",WBS_str);fflush(stdout);

								if (tc_strcmp(ERCBU,WbsBU) == 0)
								{
									printf("\n BU of WBS & Indent is SAME \n");fflush(stdout);
									ChkBUWBSIndFlag=1;
									break;
								}	
								else
								{
									printf("\n BU of WBS & Indent is Not SAME \n");fflush(stdout);
									//EMH_store_error_s1(EMH_severity_error,BU_is_ntSame,WBS_str );
									//return BU_is_ntSame;
								}
							}
							
							if(ChkBUWBSIndFlag == 1)
							{
								printf("\n BU of WBS & Indent is SAME \n");fflush(stdout);
							}
							else
							{
								printf("\n BU of WBS & Indent is Not SAME \n");fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,BU_is_ntSame,WBS_str );
								return BU_is_ntSame;
							}
						}
					}		
					}


					

					printf("\n **** Exit Indent Revision Creation Pre **** \n");fflush(stdout);
					return error_code;
				}

				extern int save_relation_custom_exit(int *decision, va_list args)
				{
					int ifail = ITK_ok;
					METHOD_id_t  method ;
					METHOD_id_t  method1 ;
					METHOD_id_t  method2 ;
					METHOD_id_t  method3 ;
					METHOD_id_t  method4 ;
					METHOD_id_t  method5 ;
					METHOD_id_t  method6 ;
					METHOD_id_t  method7 ;
					METHOD_id_t  method8 ;
					METHOD_id_t  method_action ;
					METHOD_id_t  method_IndRev ;
					METHOD_id_t  method_IndRevPre ;


					*decision = ALL_CUSTOMIZATIONS;  

					/* do something useful here, for now just return */
					printf("\n\n tm_SaveRelation.c:it, via Custom Exits.\n");fflush(stdout);
					if ( METHOD_find_method("IMAN_specification", TC_save_msg, &method) !=ITK_ok);
					if ( METHOD_find_method("T5_Applicable_SVR", TC_save_msg, &method1) !=ITK_ok);
					if ( METHOD_find_method("T5_Applicable_SVR", TC_save_msg, &method2) !=ITK_ok);
					if ( METHOD_find_method("T5_HasSpareKit", TC_save_msg, &method3) !=ITK_ok);
					if ( METHOD_find_method("T5_SparKitRevision", TC_save_msg, &method4) !=ITK_ok);
					if (METHOD_find_method("BOMLine", BOMLine_add_msg, &method5) !=ITK_ok);
					if ( METHOD_find_method("T5_HasSpareKit", TC_delete_msg, &method6) !=ITK_ok);
					//Akash 
					if ( METHOD_find_method("T5_ERCIndRevision", TC_save_msg, &method_IndRev) !=ITK_ok);
					if ( METHOD_find_method("T5_ERCIndRevision", TC_save_msg, &method_IndRevPre) !=ITK_ok);
					if ( METHOD_find_method("IMAN_specification", GRM_create_msg, &method7) !=ITK_ok); //mbb multiple dataset with same name and type are validated
					if ( METHOD_find_method("ImanRelation", GRM_create_msg, &method8) !=ITK_ok); //If cad data availble then JT attachment is restricted

				 
				   //adk
					 if (method1.id)
					{
						printf("\n !!!!!!!!!!! T5_Applicable_SVR ---method1 is  found save_method_19 !!!!!!!!!!\n");fflush(stdout);
						if( METHOD_add_action(method1, METHOD_post_action_type, (METHOD_function_t) save_method_19, NULL)!=ITK_ok);
				   
						if( ifail != ITK_ok )
						{
								EMH_store_error( EMH_severity_error, ifail );
						}
					}
					  if (method2.id)
					{
						printf("\n !!!!!!!!!!! T5_Applicable_SVR ---method2 is  found save_method_20 !!!!!!!!!!\n");fflush(stdout);
						if( METHOD_add_action(method2, METHOD_pre_action_type, (METHOD_function_t) save_method_20, NULL)!=ITK_ok);
				   
						if( ifail != ITK_ok )
						{
								EMH_store_error( EMH_severity_error, ifail );
						}
					}
				   //adk

				//madhu 

					if (method3.id)
					{
						printf("Registered as pre-condition for Spare_Kit_Relation Save validation \n");fflush(stdout);
						if( METHOD_add_pre_condition(method3,(METHOD_function_t)Has_Spare_kit_validation,NULL)!=ITK_ok)
						PrintErrorStack();
						
					}
					else
					{
						printf("method3 not found\n");fflush(stdout);
					}

					if (method4.id)
					{
						printf("Registered as pre-condition for Spare_Kit Save Validation \n");fflush(stdout);
						if( METHOD_add_pre_condition(method4,(METHOD_function_t)Spare_kit_save_validation,NULL)!=ITK_ok)
						PrintErrorStack();
						
					}
					else
					{
						printf("method4 not found\n");fflush(stdout);
					}

					if (method5.id)
					{
						printf("Registered as pre-condition for Spare_Kit BOM line create Validation \n");fflush(stdout);
						if( METHOD_add_pre_condition(method5,(METHOD_function_t)Spare_kit_BOM_validation,NULL)!=ITK_ok)
						PrintErrorStack();
						
					}
					else
					{
						printf("method5 not found\n");fflush(stdout);
					}
					if (method6.id)
					{
						printf("Registered as pre-condition for delete Spare_Kit_Relation validation \n");fflush(stdout);
						if( METHOD_add_pre_condition(method6,(METHOD_function_t)Has_Spare_kit_validation,NULL)!=ITK_ok)
						PrintErrorStack();
						
					}
					else
					{
						printf("method6 not found\n");fflush(stdout);
					}

					if (method7.id)
					{
						printf("Registered (GRM_create_msg) as pre-condition for multiple dataset with same name and type validation \n");fflush(stdout);
						if( METHOD_add_pre_condition(method7,(METHOD_function_t)Multiple_DatasetType_validation,NULL)!=ITK_ok)
						PrintErrorStack();
						
					}
					else
					{
						printf("method7 not found\n");fflush(stdout);
					}
					//Nilesh
					if (method8.id)
					{
						printf("Registered (GRM_create_msg) as pre-condition for multiple dataset with same name and type validation \n");fflush(stdout);
						//if( METHOD_add_pre_condition(method8,(METHOD_function_t)Restrict_JT_attchtouser,NULL)!=ITK_ok)
						if( METHOD_add_action(method8, METHOD_pre_action_type, (METHOD_function_t) Restrict_JT_attchtouser, NULL)!=ITK_ok)
						PrintErrorStack();
						
					}
					else
					{
						printf("method8 not found\n");fflush(stdout);
					}
				   //madhu
					
					if (method.id)
					{
						printf("\n !!!!!!!!!!!IMAN_specification ---Method is  found!!!!!!!!!!\n");fflush(stdout);
						if( METHOD_add_action(method, METHOD_pre_action_type, (METHOD_function_t) save_method_17, NULL)!=ITK_ok);
				   
						if( ifail != ITK_ok )
						{
								EMH_store_error( EMH_severity_error, ifail );
						}
					}

					else
					{
						printf("\n !!!!!!!!!!!Method not found!!!!!!!!!!\n");fflush(stdout);
					}

					/*********** Alias ************/
				 
					if (method.id)
					{
						printf("\n !!!!!!!!!!! IMAN_specification ---Method is  found save_method_18 !!!!!!!!!!\n");fflush(stdout);
						if( METHOD_add_action(method, METHOD_post_action_type, (METHOD_function_t) save_method_18, NULL)!=ITK_ok);
				   
						if( ifail != ITK_ok )
						{
								EMH_store_error( EMH_severity_error, ifail );
						}
					}
					/*********** Alias ************/

					/// Changes by Dhiraj for Indent..

					if ( METHOD_find_method("T5ERCDtl", TC_save_msg, &method_action) !=ITK_ok);
					
					if (method_action.id)
					{
						if( METHOD_add_action(method_action, METHOD_pre_action_type, (METHOD_function_t) Indent_Design_relation, NULL)!=ITK_ok);

						if( ifail != ITK_ok )
						{
							EMH_store_error( EMH_severity_error, ifail );
						}

					}

					if (method_IndRev.id)
					{
						if( METHOD_add_action(method_IndRev, METHOD_post_action_type, (METHOD_function_t) Indent_Rev_Post_Msg, NULL)!=ITK_ok);

						if( ifail != ITK_ok )
						{
							EMH_store_error( EMH_severity_error, ifail );
						}
					}
					if (method_IndRevPre.id)
					{
						if( METHOD_add_action(method_IndRevPre, METHOD_pre_action_type, (METHOD_function_t) Indent_Rev_Pre_Msg, NULL)!=ITK_ok);

						if( ifail != ITK_ok )
						{
							EMH_store_error( EMH_severity_error, ifail );
						}
					}
					
					//Calling Action Handler for assigning Reviwers to indent..
					ifail=Indent_register_action_handlers();


					//Calling Rule Handler to check no. of design revision attach
					ifail=Indent_register_rule_handlers();


					return ifail;
				}


				int Indent_register_action_handlers()
				{
					int ifail = ITK_ok;

					EPM_register_action_handler("Indent_Reviewers_assign","Assign MGR, Chief Eng and Proto Planner Reviwers", Indent_Reviewers_assign);
					TC_write_syslog("Registered Action Handler Indent_Reviewers_assign..\n");

					EPM_register_action_handler("generate_indent_refno","Generate Indent Ref No. after approval from manager",generate_indent_refno);
					TC_write_syslog("Registered Action Handler generate_indent_refno\n");

					EPM_register_action_handler("CM_Gen_ERC_IndentReport","Generate ERC Indent Report after Chief Reviwer",CM_Gen_ERC_IndentReport);
					TC_write_syslog("Registered Action Handler CM_Gen_ERC_IndentReport\n");

					return ifail;
				}


				int Indent_register_rule_handlers()
				{
					int ifail = ITK_ok;

				if(ITK_ok == EPM_register_rule_handler("Chk_DsgnRevObjs_Indent","Rule handler to validate no. of Design Rev. objs to indent",Chk_DsgnRevObjs_Indent))
					   {
							printf("\t\n Registered rule  Chk_DsgnRevObjs_Indent.................\n");fflush(stdout);
					   }else
					   {
							printf("\t FAILED to register rule Handler Chk_DsgnRevObjs_Indent\n");fflush(stdout);
					   }
					//TC_write_syslog("Registered Rule Handler Chk_DsgnRevObjs_Indent..\n");
					
					if(ITK_ok ==  EPM_register_rule_handler ("IndActiveInWorkflow","Check Validation with IndActiveInWorkflow", (EPM_rule_handler_t) ChkIndentActiveinLC))
					   {
							printf("\t\n Registered rule  IndActiveInWorkflow.................\n");fflush(stdout);
					   }else
					   {
							printf("\t FAILED to register rule Handler IndActiveInWorkflow\n");fflush(stdout);
					   }
					 if(ITK_ok ==  EPM_register_rule_handler ("Chk_ProtoResPartyAssign","Rule handler to validate no. of Design Rev. objs to indent", (EPM_rule_handler_t) Chk_ProtoResPartyAssignLC))
					   {
							printf("\t\n Registered rule  Chk_ProtoResPartyAssign.................\n");fflush(stdout);
					   }else
					   {
							printf("\t FAILED to register rule Handler Chk_ProtoResPartyAssign\n");fflush(stdout);
					   }
					   
					   if(ITK_ok ==  EPM_register_action_handler ("MailIndentManagerReview","action handler to send mail on  MailIndentManagerReview", (EPM_action_handler_t) MailIndentManagerReviewLC))
					   {
							printf("\t\n Registered rule  MailIndentManagerReview.................\n");fflush(stdout);
					   }else
					   {
							printf("\t FAILED to register rule Handler MailIndentManagerReview\n");fflush(stdout);
					   }
					   
					   if(ITK_ok ==  EPM_register_action_handler ("MailIndentChiefEnggReview","action handler to send mail on  MailIndentChiefEnggReview", (EPM_action_handler_t) MailIndentChiefEnggReviewLC))
					   {
							printf("\t\n Registered rule  MailIndentChiefEnggReview.................\n");fflush(stdout);
					   }else
					   {
							printf("\t FAILED to register rule Handler MailIndentChiefEnggReview\n");fflush(stdout);
					   }
					   
					   if(ITK_ok ==  EPM_register_action_handler ("MailIndentProtoReview","action handler to send mail on  MailIndentProtoReview", (EPM_action_handler_t) MailIndentProtoReviewLC))
					   {
							printf("\t\n Registered rule  MailIndentProtoReview.................\n");fflush(stdout);
					   }else
					   {
							printf("\t FAILED to register rule Handler MailIndentProtoReview\n");fflush(stdout);
					   }

					return ifail;
				}

				extern DLLAPI int tm_SaveRelation_register_callbacks ()
				{
					 printf("\n \n tm_SaveRelation.c:::Hello Teamcenter, via Custom Exit\n");fflush(stdout);

					 CUSTOM_register_exit ( "tm_SaveRelation", "USER_init_module", (CUSTOM_EXIT_ftn_t) save_relation_custom_exit);

					 return ( ITK_ok );
				}
