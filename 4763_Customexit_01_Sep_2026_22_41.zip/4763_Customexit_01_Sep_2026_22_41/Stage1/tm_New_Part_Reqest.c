/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : tm_New_Part_Reqest.c
* Created By                   : Sudhir
* Created On                   : 01-Aug-2019
* Project                      : TML/New Part Request
* Methods Defined              : CUSTOM_EXIT
* Description                  : On TML custom action
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/
//#define _CRT_SECURE_NO_DEPRECATE					
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <epm/signoff.h>
#include <ce/ce.h>
#include <tc/folder.h>
#include <tccore/project.h>
//#include <tc/tc.h>
#include <tc/tc_startup.h>
#include <ae/datasettype.h>
#include <tccore/grm_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <pom/pom/pom.h>
#include <tccore/aom_prop.h>
#include <tccore/releasestatus.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <base_utils/Mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <tccore/item_msg.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <common/emh_const.h>
#include <sa/groupmember.h>
#include <ps/ps_tokens.h>
#include <tc/envelope.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <Fnd0Participant/participant.h>
#include <unistd.h>
#define ITK_err 919006
#define ITK_errStore (EMH_USER_error_base+2)
#define ITK_err2 (EMH_USER_error_base+3)
#define ITK_err1 (EMH_USER_error_base+4)
#define ALPHA_SIZE 26
#define DIGIT_SIZE 10
#define CLASS_IS_ITEM       0
#define CLASS_IS_DATASET    1
#define FIRST_DS_REV_ID "0"
#define FIRST_REV_ID "NR"

#define PROJ_id_size_c   64 
#define PROJ_name_size_c   32 
#define	t9NewPartReqCre_Val001 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val002 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val003 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val004 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val005 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val006 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val007 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val008 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val009 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0010 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0011 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0012 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0013 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0014 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0015 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0016 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0017 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0018 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0019 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0020 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0021 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0022 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0023 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0024 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0025 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0026 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0027 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0028 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0029 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0030 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0031 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0032 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0033 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0034 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0035 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0036 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0037 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0038 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0039 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0040 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0041 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0042 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0043 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0044 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0045 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0046 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0047 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0048 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0049 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0050 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0051 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0052 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0053 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0054 (EMH_USER_error_base+21)
#define	t9NewPartReqCre_Val0055 (EMH_USER_error_base+21)
//#define EPM_cannot_perform_action(EMH_EPM_error_base + 52)


#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

#define ECHO(X) printf X; TC_write_syslog X


int t5_LOVKeyWordDescValuesMethod( METHOD_message_t *msg, va_list  args ) ;
int t5CheckInPartLeadger(char *thisPartNumber);
int t5CreatePart(tag_t NewPartReqObj, char *vstr);
int AssignProject(tag_t  itemRev,char* projectcode);
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    printf(msg);
}


static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Checkout Error(s): \n");
	Write_To_Log("Checkout Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return pErrCdeLst[i];//ITK_ok;
}


static int t5CatiaNumbering(tag_t rev,char *thisPartNumber,logical updatable , int incrementval);
void setAddTAG(int *count,tag_t **objlist,tag_t obj );
void setAddStr(int *count,char ***strset,char* str);

static void TAG_free(void *what)
{
    if (what != NULL)
    {
        MEM_free(what);
        what = NULL;
    }
}

char *subString1(char *val)
{

char *newval = (char*) malloc(12);

strncpy(newval, val,11);
printf("\n newval=%s",newval);fflush(stdout);

return newval;

}
char* NewPartsubString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(30);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;

}


int AssignProject(tag_t  itemRev,char* projectcode)
{

	int status;
	tag_t  projobj=NULLTAG;
	char* username=NULL;
	tag_t user_tag=NULLTAG;

	// ITK_CALL(AOM_lock(itemRev));
	printf("\n\t projectcode [%s]\n",projectcode);fflush(stdout);
	PROJ_find(projectcode,&projobj);
	//printf("\n\t Assigned to Project \n");fflush(stdout);

	if(projobj !=NULLTAG)
	{
		//POM_get_user(&username,&user_tag);
		//ITK_CALL(PROJ_add_members(projobj,1,&user_tag));
		PROJ_assign_objects(1 ,&projobj ,1 ,&itemRev);
		printf("\n Assigned to Project\n");fflush(stdout);
	}
	else
	{
		printf("\n Project not found\n");fflush(stdout);
	}
	//   ITK_CALL(AOM_save(itemRev));
	//  ITK_CALL(AOM_unlock(itemRev));

	return status;
}


static int FunToQueryIFDModuleAddress(char *ModuleAddress)
{

	char
        *ctrl_qry_entries[2] = {"SYSCD","SUBSYSCD"},
        *ctrl_qry_values[2]	= {"*","*"};

	int IFDMDADD_FOUND = 0;
	int n_found = 0;

	tag_t	query		= NULLTAG;
	tag_t	*q_item		= NULLTAG;

	char *modinfo01Str	= NULL;
	char *modinfo02Str	= NULL;
	char *modinfo03Str	= NULL;

	int retcode = ITK_ok;


	printf("\n ModuleAddress===%s",ModuleAddress);fflush(stdout);
	ctrl_qry_values[0]	= "ModAddForIM";
	ctrl_qry_values[1]	= "ModAddForIM";
	QRY_find2("Control Objects...", &query);
	if(query!=NULLTAG)
	{
		QRY_execute(query, 2, ctrl_qry_entries, ctrl_qry_values, &n_found, &q_item);
		printf("\n n_found===%d",n_found);fflush(stdout);
		if(n_found>0)
		{
			AOM_ask_value_string(q_item[0],"t5_Userinfo1",&modinfo01Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo2",&modinfo02Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo3",&modinfo03Str);
			if(tc_strstr(modinfo01Str,ModuleAddress)!=NULL 
				|| tc_strstr(modinfo02Str,ModuleAddress)!=NULL 
				|| tc_strstr(modinfo03Str,ModuleAddress)!=NULL)
			{
				IFDMDADD_FOUND = 1;
			}
		}
	}
	printf("\n IFDMDADD_FOUND===%d",IFDMDADD_FOUND);fflush(stdout);

	return IFDMDADD_FOUND;
}

static int FunToQueryModuleAddress(char *ModuleAddress)
{

	char
        *ctrl_qry_entries[2] = {"SYSCD","SUBSYSCD"},
        *ctrl_qry_values[2]	= {"*","*"};

	int ISMODULE_FOUND = 0;
	int n_found = 0;

	tag_t	query		= NULLTAG;
	tag_t	*q_item		= NULLTAG;

	char *modinfo04Str	= NULL;
	char *modinfo05Str	= NULL;
	char *modinfo06Str	= NULL;
	char *modinfo07Str	= NULL;
	char *modinfo08Str	= NULL;
	char *modinfo09Str	= NULL;
	char *modinfo010Str	= NULL;

	int retcode = ITK_ok;


	printf("\n ModuleAddress===%s",ModuleAddress);fflush(stdout);
	ctrl_qry_values[0]	= "ModAddForIM";
	ctrl_qry_values[1]	= "ModAddForIM";
	QRY_find2("Control Objects...", &query);
	if(query!=NULLTAG)
	{
		QRY_execute(query, 2, ctrl_qry_entries, ctrl_qry_values, &n_found, &q_item);
		printf("\n n_found===%d",n_found);fflush(stdout);
		if(n_found>0)
		{
			AOM_ask_value_string(q_item[0],"t5_Userinfo4",&modinfo04Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo5",&modinfo05Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo6",&modinfo06Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo7",&modinfo07Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo8",&modinfo08Str);
			AOM_ask_value_string(q_item[0],"t5_Userinfo9",&modinfo09Str);
			AOM_ask_value_string(q_item[0],"t5_userinfo10",&modinfo010Str);

			if(tc_strstr(ModuleAddress,modinfo04Str)!=NULL
				|| tc_strstr(ModuleAddress,modinfo05Str)!=NULL
				|| tc_strstr(ModuleAddress,modinfo06Str)!=NULL
				|| tc_strstr(ModuleAddress,modinfo07Str)!=NULL
				|| tc_strstr(ModuleAddress,modinfo08Str)!=NULL
				|| tc_strstr(ModuleAddress,modinfo09Str)!=NULL
				|| tc_strstr(ModuleAddress,modinfo010Str)!=NULL)
			{
				ISMODULE_FOUND = 1;
			}
		}
	}
	printf("\n ISMODULE_FOUND===%d",ISMODULE_FOUND);fflush(stdout);

	return ISMODULE_FOUND;
}

int IsDesignRevisionAvail(char* InputPart)
{
	int		IsAvailInUA		=	0;
	tag_t   OutPutTag		=	NULLTAG;
	tag_t   query		=	NULLTAG;
	int		n_tags_found2	=	0;
	tag_t	*tags_found2	=	NULL;

	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int		n_tags_foundd2	=	0;
	tag_t	*tags_foundd2	=	NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	char
        *qry_entries[2] = {"Item ID","Type"},
        *qry_values[2]	= {"*","*"};
	//MT end
	printf("\n FUN:part no :%s.", InputPart);fflush(stdout);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	//attrs2[0] ="item_id";
	//attrs2[1] ="object_type";
	//values2[0] = (char *)InputPart;
	//values2[1] = "Design";
	//if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();

	qry_values[0]	= InputPart;
	qry_values[1]	= "Design";
	QRY_find2("Item...", &query);
	QRY_execute(query, 2, qry_entries, qry_values, &n_tags_found2, &tags_found2);
	printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
		IsAvailInUA = 1;
		printf("\n Part found in TCUA:%d",IsAvailInUA);fflush(stdout);
	}
	else
	{
		IsAvailInUA = 0;
		printf("\n Part not found in TCUA:%d",IsAvailInUA);fflush(stdout);
	}
	return IsAvailInUA;
}


/*************************************************************************
To fetch Keyword Description from classification in LOV
*************************************************************************
int t5_LOVKeyWordDescValuesMethod( METHOD_message_t *msg, va_list  args )
{
    tag_t lov_tag  = va_arg(args, const tag_t);
    int*  n_values = va_arg(args, int*);
    char  ***values = va_arg(args, char***);
	char *Classi_class;
	char *DesignGrp;	
	int error_code = ITK_ok;
	int n_entries = 2;
	int n_found = 0;
	int ii = 0;
	int i;
	tag_t query = NULLTAG, *cntr_objects = NULL;
	
	int TotalLovCount = 0;
	int iMyLovCounter = 0;
	char *qry_entries[2] = {"Name","ext_1"};
	char * user_name_string;
	char *lov_name=NULL;
	char *prop_value=NULL;
	char *lov_type=NULL;
	char *DGrp=NULL;
	char *DGrp1=NULL;
	
	lov_type=(char *) MEM_alloc(100);
	DGrp=(char *) MEM_alloc(10);
	DGrp1=(char *) MEM_alloc(10);
	prop_value=(char *) MEM_alloc(10);


	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	printf("\n Inside t5_LOVKeyWordDescValuesMethod\n");fflush(stdout);
	LOV_ask_name2(lov_tag,&lov_name);
	printf("\n Lov_Name_Is %s\n",lov_name);fflush(stdout);
	
	for (i=0;i<100;i++)
		{
			strcpy(DGrp,"");
			sprintf(DGrp,"%d", i);
			
			strcpy(lov_type,"");
			strcpy(lov_type,"T5_KeyWord_D_Grp_");		
			strcat(lov_type,DGrp);
			if(tc_strcmp(lov_name,lov_type)==0)
			{
				if (i<10)
				{
					strcpy(DGrp1,"0");
					strcat(DGrp1,DGrp);
					strcpy(prop_value,DGrp1);
					printf("\n prop_value (DGrp1) is: %s\n",prop_value);fflush(stdout);
				}
				else
				{
					strcpy(prop_value,DGrp);
					printf("\n prop_value (DGrp) is: %s\n",prop_value);fflush(stdout);
				}
				
			}
			
		}

	qry_values[0] = "*" ;
	qry_values[1] = prop_value;

	IFERR_REPORT(QRY_find2("QryKyWrd_iDsgGrp_oClsfObj", &query));
	IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
	printf("\nKeyword n_found:%d", n_found);fflush(stdout);

	*n_values=n_found;
	if(n_values>0)
	{
		printf("\nKeyword *n_values: %d\n", *n_values);fflush(stdout);

		*values = (char **)MEM_alloc (*n_values * sizeof(char*));
		memset( *values, 0,  *n_values * sizeof(char*)); 

		for (ii = 0; ii < n_found; ii++)
		{
			AOM_ask_value_string(cntr_objects[ii],"name",&Classi_class);

			(*values)[ii] = (char *) MEM_alloc (strlen(Classi_class) + 1);
			strcpy((*values)[ii], Classi_class);

			printf("\n Keyword :%s",(*values)[ii]);
					
		}
		TAG_free(cntr_objects); 
	}
			
    return error_code;
}
*/

/****************************************************************************
Function:       NewPartReqItem_create_pre_condition
Description:    This function used for register custom method/handler 
				on class for different action like pre/post.
				code lsit of an user.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
extern DLLAPI int NewPartReqItem_create_pre_condition(METHOD_message_t *m, va_list args)
{

    int ifail=ITK_ok;	
    /***  va_list for TC_save_msg  ***/
    tag_t item  = va_arg(args, tag_t);
    logical  isNew = va_arg(args, int);
    //logical  isNew = va_arg(args, logical);
	
    /***********************************/


    char *item_type=NULL;
    char *itemId=NULL;
    char *prj_code=NULL;
    char *designgroup=NULL;
    char *designid=NULL;
    char *NwVehicleMdl=NULL;
    char *t5NwDgSbGrpDupS=NULL;
    char *t5NwDgSbGrpS=NULL;
    char *ootbitemId=NULL;

	char *MachineNameS=NULL;
    char *part_num=NULL;
    char *subpart91=NULL;
    char *BussiNameS=NULL;
    char *Proj_typ=NULL;
    char *t5Userinfo1DupS=NULL;
    char *t5Userinfo1S=NULL;
	 char *t5Userinfo2DupS=NULL;
    char *t5Userinfo2S=NULL;
	 char *t5Userinfo3DupS=NULL;
    char *t5Userinfo3S=NULL;
	 char *t5Userinfo4DupS=NULL;
    char *t5Userinfo4S=NULL;
    char *t5Userinfo1PV=NULL;
    char *t5PV1S=NULL;
	char *t5Userinfo2PV=NULL;
    char *t5PV2S=NULL;
	char *t5Userinfo3PV=NULL;
    char *t5PV3S=NULL;
	char *t5Userinfo4PV=NULL;
    char *t5PV4S=NULL;
    char *anyfileS=NULL;
    char *anyfile=NULL;
    char *PartType=NULL;
    char *NwKeywrdDesdup=NULL;
    char *NwKeywrdDes=NULL;
    char *prtFamily=NULL;
    char *partFam=NULL;
    char *strClassIDdup=NULL;
    char *strClassID=NULL;
    char *newpartreqnumber=NULL;
    char *NwThirdAttachS=NULL;
    char *NwThirdAttach=NULL;
    char *NwPrtVliS=NULL;
    char *NwPrtVli=NULL;
    char *SubModuleAddress=NULL;
    char *newReqpartTypeDup=NULL;
    char *newReqpartType=NULL;
    char *AggregateGrp=NULL;
    char *Aggregates=NULL;
    char *Module=NULL;
    char *SubModule=NULL;
    char *tempAggregateGrp=NULL;
    char *tempAggregates=NULL;
    char *tempModule=NULL;
    char *tempSubModule=NULL;
	char *AggregatesDup=NULL;
    char *ModuleDup=NULL;
    char *SubModuleDup=NULL;
    char *NPRDRStatusDup=NULL;
    char *NPRDRStatus=NULL;
    char *NPRPartCategoryDup=NULL;
    char *NPRPartCategory=NULL;
    char *NPRStartPartProductDup=NULL;
    char *NPRStartPartProduct=NULL;
    char *NwKeywrdDescription=NULL;
    char *PlateformDup=NULL;
    char *Plateform=NULL;
    char *grpName=NULL;
    char *projectName=NULL;
    char *roleName=NULL;
    char *SubModDesignGroup=NULL;
    char *t5Userinfo6DupS=NULL;
    char *t5Userinfo6S=NULL;
	char *IBDomesticDup=NULL;
	char *IBDomestic=NULL;
	char *ProductLineDup=NULL;
	char *ProductLine=NULL;
	char *ProposeTPLNum=NULL;
	char *ProposeTPLNumDup=NULL;

	int e1=0;
	int e2=0;
	int NwDgSbGrpError=0;
	int g=0;
	
	int	l		= 0;

	time_t now;
	struct tm *tm;

	int n_tags_found= 0;
	int ctrl_n_found1= 0;
	int ctrl_n_found2= 0;
	int ctrl_n_found3= 0;
	int ctrl_n_found4= 0;
	int ctrl_n_found5= 0;
	int prj_n_found= 0;
	int classification_n_found= 0;
	tag_t *t_item1=NULLTAG;
	tag_t DesignPartTag=NULLTAG;
	tag_t  *soResult1	= NULLTAG;
	tag_t ctrlquery=NULLTAG;
	tag_t ctrlquery2=NULLTAG;
	tag_t ctrlquery3=NULLTAG;
	tag_t ctrlquery4=NULLTAG;
	tag_t ctrlquery5=NULLTAG;
	tag_t prjquery=NULLTAG;
	tag_t classificationquery=NULLTAG;
	tag_t *prj_items=NULLTAG;
	tag_t *setOfUsrDbObjs=NULLTAG;
	tag_t *setOfUsrDbObjsda=NULLTAG;
	tag_t *setOfPVBUObjspv=NULLTAG;
	tag_t *UaPartSO=NULLTAG;
	tag_t *partFamObjs=NULLTAG;
	tag_t userSession=NULLTAG;
	
	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};

	char
        *qry_entries[2] = {"Item ID","Type"},
        *qry_values[2]	= {"*","*"};

	char
        *ctrl_qry_entries[2] = {"SYSCD","SUBSYSCD"},
        *ctrl_qry_values[2]	= {"*","*"};

	char
        *ctrl_qry_entries2[2] = {"SYSCD","SUBSYSCD"},
        *ctrl_qry_values2[2]	= {"*","*"};

	char
        *ctrl_qry_entries3[2] = {"SYSCD","SUBSYSCD"},
        *ctrl_qry_values3[2]	= {"*","*"};

	char
        *ctrl_qry_entries4[2] = {"SYSCD","t5_Userinfo1"},
        *ctrl_qry_values4[2]	= {"*","*"};

	char
        *ctrl_qry_entries5[1] = {"SYSCD"},
        *ctrl_qry_values5[1]	= {"*"};

	char
        *prj_qry_entries[2] = {"Name","Type"},
        *prj_qry_values[2]	= {"*","*"};

	char
        *classification_qry_entries[2] = {"Name","ext_1"},
        *classification_qry_values[2]	= {"*","*"};

	char
        *ModAddctrl_qry_entries[1] = {"SYSCD"},
        *ModAddctrl_qry_values[1]	= {"*"};

	int ReqApplicable	= 0;

	tag_t	designquery = NULLTAG;
	char *keys[1] = {"creation_date"};
	int  	 orders[1]  ={1};
	int  num_to_sort = 1;
	char *part_num1 = NULL;
	char *anyfileret = NULL;
	char *NwPrtVliret= NULL;
	char *NwThirdAttachret= NULL;
	char *filename1 = NULL;
	const char ch = '.';
	int error = 0;

	//CLASSIFICATIO	
	char **sOutStr			=NULL;
	int *Ids;	
	int nSize=0;
	int i;
	int x;
	char* sId			=NULL;
	int xyz=0;
	int *formatType;
	int xyzf=0;
	int *modifier1;
	int xyzm1=0;
	int *modifier2;
	int xyzm2=0;
	int *length;
	int xyzl=0;
	


	int  	theCount =0;
	int * 	theIds;
	char ** 	theNames;
	char ** 	theShortNames;
	char ** 	theAnnotations;
	int * 	theArraySize;
	int * 	theFormat;
	char ** 	theUnit;
	char ** 	theMinValues;
	char ** 	theMaxValues;
	char ** 	theDefaultValues;
	char ** 	theDescriptions;
	int * 	theOptions1 ;
	int id=0;
	tag_t	theClassTag = NULLTAG;
	tag_t	view		= NULLTAG;
	tag_t	ModAddctrlquery		= NULLTAG;


	char * 	theParent;
	int 		theType;
	char * 	theName;
	char * 	theShortName;
	char * 	theDescription;
	char *	theUserData1;
	char * 	theUserData2;
	int  		theOptions;
	int  		theInstanceCount;
	int  		theChildrenCount;
	int  		theViewCount;
	int modaddlen = 0;

	logical			isFor12Digit = false;
	logical			isFor14Digit = false;
	logical			PrtCmoInd = false;
	logical			StdFldInd = false;
	logical			ExtPrtInd = false;
	logical			AlowCreSubMod = false;

	
	logical hasBypass=false;

	


    AOM_ask_value_string(item,"object_type",&item_type);
    printf("\n **NewPartReqItem_create_pre_condition::type_name = [%s]\n", item_type);fflush(stdout);
	printf("\n **NewPartReqItem_create_pre_condition::isNew = [%d]\n", isNew);fflush(stdout);
	if(isNew==true)
	{
		if(tc_strcmp(item_type,"T5_NwPCre")==0)
		{

			CE_current_user_session_tag(&userSession);
			AOM_ask_value_string(userSession,"group_name",&grpName);
			printf("\n NewPartReqItem_create_pre_condition::grpName====>[%s]", grpName);fflush(stdout);

			AOM_ask_value_string(userSession,"project_name",&projectName);
			printf("\n NewPartReqItem_create_pre_condition::projectName====>[%s]", projectName);fflush(stdout);

			AOM_ask_value_string(userSession,"role_name",&roleName);
			printf("\n NewPartReqItem_create_pre_condition::roleName====>[%s]", roleName);fflush(stdout);

			if(tc_strcmp(grpName,"ERC_Designers_Group")!=0)
			{
				ifail=t9NewPartReqCre_Val008;
				EMH_store_error_s1(EMH_severity_error,ifail,"Please select Group as ERC_Designers_Group in user rsession!!");
				return ifail;
			}
			if(tc_strstr(roleName,"Designers")==NULL)
			{
				ifail=t9NewPartReqCre_Val009;
				EMH_store_error_s1(EMH_severity_error,ifail,"Please select Role as Designers Role in user rsession!!");
				return ifail;
			}
			
			
			AOM_ask_value_logical(item,"t5_Is12Digit",&isFor12Digit);
			printf("\n NewPartReqItem_create_pre_condition::isFor12Digit====>[%d]", isFor12Digit);fflush(stdout);

			AOM_ask_value_logical(item,"t5_Is14Digit",&isFor14Digit);//t5_isFor14Digit
			printf("\n NewPartReqItem_create_pre_condition::isFor14Digit====>[%d]", isFor14Digit);fflush(stdout);

			AOM_ask_value_logical(item,"t5_PrtCmoInd",&PrtCmoInd);
			printf("\n NewPartReqItem_create_pre_condition::PrtCmoInd====>[%d]", PrtCmoInd);fflush(stdout);

			AOM_ask_value_logical(item,"t5_StdFldInd",&StdFldInd);
			printf("\n NewPartReqItem_create_pre_condition::StdFldInd====>[%d]", StdFldInd);fflush(stdout);

			AOM_ask_value_logical(item,"t5_ExtPrtInd",&ExtPrtInd);
			printf("\n NewPartReqItem_create_pre_condition::ExtPrtInd====>[%d]", ExtPrtInd);fflush(stdout);

			AOM_ask_value_logical(item,"t5_AlowCreSubMod",&AlowCreSubMod);
			printf("\n NewPartReqItem_create_pre_condition::AlowCreSubMod====>[%d]", AlowCreSubMod);fflush(stdout);

			AOM_ask_value_string(item,"t5_DRStatus",&NPRDRStatus);
			NPRDRStatusDup = strdup(NPRDRStatus);
			printf("\n NewPartReqItem_create_pre_condition:: NPRDRStatusDup====>[%s]", NPRDRStatusDup);fflush(stdout);

			AOM_ask_value_string(item,"t5_PartCategory",&NPRPartCategory);
			NPRPartCategoryDup = strdup(NPRPartCategory);
			printf("\n NewPartReqItem_create_pre_condition:: NPRPartCategoryDup====>[%s]", NPRPartCategoryDup);fflush(stdout);

			AOM_ask_value_string(item,"t5_StartPartProduct",&NPRStartPartProduct);
			NPRStartPartProductDup = strdup(NPRStartPartProduct);
			printf("\n NewPartReqItem_create_pre_condition:: NPRStartPartProductDup====>[%s]", NPRStartPartProductDup);fflush(stdout);

			AOM_ask_value_string(item,"t5_Plateform",&Plateform);
			PlateformDup = strdup(Plateform);
			printf("\n NewPartReqItem_create_pre_condition:: PlateformDup====>[%s]", PlateformDup);fflush(stdout);

			AOM_ask_value_string(item,"t5_IBDomestic",&IBDomestic);
			IBDomesticDup = strdup(IBDomestic);
			printf("\n NewPartReqItem_create_pre_condition:: IBDomesticDup====>[%s]", IBDomesticDup);fflush(stdout);

			AOM_ask_value_string(item,"t5_ProductLine",&ProductLine);
			ProductLineDup = strdup(ProductLine);
			printf("\n NewPartReqItem_create_pre_condition:: ProductLineDup====>[%s]", ProductLineDup);fflush(stdout);


			AOM_ask_value_string(item,"t5_NwPrtAny",&anyfile);
			anyfileS = strdup(anyfile);

			AOM_ask_value_string(item,"t5_NwPrtVli",&NwPrtVli);
			NwPrtVliS = strdup(NwPrtVli);

			AOM_ask_value_string(item,"t5_NwThirdAttach",&NwThirdAttach);
			NwThirdAttachS = strdup(NwThirdAttach);

			AOM_ask_value_string(item,"t5_PartType",&newReqpartTypeDup);
			newReqpartType = strdup(newReqpartTypeDup);
			printf("\n NewPartReqItem_create_pre_condition:: newReqpartType====>[%s]", newReqpartType);fflush(stdout);

			printf("\n NewPartReqItem_create_pre_condition:: anyfileS====>[%s]", anyfileS);fflush(stdout);
			printf("\n NewPartReqItem_create_pre_condition:: NwPrtVliS====>[%s]", NwPrtVliS);fflush(stdout);
			printf("\n NewPartReqItem_create_pre_condition:: NwThirdAttachS====>[%s]", NwThirdAttachS);fflush(stdout);

			char *AggregateGrp1			= NULL;
			char *SubModDesignGroup1	= NULL;
			char *Aggregates1			= NULL;
			char *Module1				= NULL;
			char *SubModule1			= NULL;
			char *designgroup1			= NULL;
			char *t5NwDgSbGrpDupS1		= NULL;
			char *designid1				= NULL;
			int NPR_TPL_Create_ERROR_Flag = 0;
			AOM_ask_value_string(item,"t5_AggregateGrp",&AggregateGrp1);
			AOM_ask_value_string(item,"t5_SubModDsgGrp",&SubModDesignGroup1);
			AOM_ask_value_string(item,"t5_Aggregates",&Aggregates1);
			AOM_ask_value_string(item,"t5_Module",&Module1);
			AOM_ask_value_string(item,"t5_SubModule",&SubModule1);
			AOM_ask_value_string(item,"t5_DesignGroup",&designgroup1);
			AOM_ask_value_string(item,"t5_DesignSubGrp",&t5NwDgSbGrpDupS1);
			AOM_ask_value_string(item,"t5_NwDgId",&designid1);

			AOM_ask_value_string(item,"t5_ProposeTPLNum",&ProposeTPLNum);
			ProposeTPLNumDup = strdup(ProposeTPLNum);
			printf("\n NewPartReqItem_create_pre_condition:: ProposeTPLNum====>[%s]", ProposeTPLNumDup);fflush(stdout);
			if(tc_strcmp(newReqpartType,"T")==0 || tc_strcmp(newReqpartType,"Technical Part List")==0)
			{
				if(tc_strlen(ProposeTPLNumDup)==0)
				{
					NPR_TPL_Create_ERROR_Flag = 1;
					ifail=t9NewPartReqCre_Val0049;
					EMH_store_error_s1(EMH_severity_error,ifail,"Part Type TPL, Proposed TPL Number is Required!!");
					return ifail;
				}
				if(tc_strlen(AggregateGrp1)>0 
					|| tc_strlen(SubModDesignGroup1)>0 
					|| tc_strlen(Aggregates1)>0
					|| tc_strlen(Module1)>0
					|| tc_strlen(SubModule1)>0
					|| tc_strlen(t5NwDgSbGrpDupS1)>0
					|| tc_strlen(designid1)>0
					)
				{
					NPR_TPL_Create_ERROR_Flag = 1;
					char *TPLErrorMsg = NULL;
					TPLErrorMsg = (char *) MEM_alloc( 1000 * sizeof(char) );
					tc_strcpy(TPLErrorMsg,"Part Type TPL, AggregateGroup, Aggregate,Module,SubModule");
					tc_strcat(TPLErrorMsg,"\nSub Module Design Group,Design Sub Group, Designation ID");
					tc_strcat(TPLErrorMsg,"\nSelection is not Required!!");
					ifail=t9NewPartReqCre_Val0050;
					EMH_store_error_s1(EMH_severity_error,ifail,TPLErrorMsg);
					return ifail;
				}
				if(tc_strlen(designgroup1)==0)
				{
					NPR_TPL_Create_ERROR_Flag = 1;
					ifail=t9NewPartReqCre_Val0051;
					EMH_store_error_s1(EMH_severity_error,ifail,"For TPL Part Type,Design Group is requires!!");
					return ifail;
				}
			}
			if(tc_strlen(ProposeTPLNumDup)>0)
			{
				if(tc_strlen(newReqpartType)==0)
				{
					NPR_TPL_Create_ERROR_Flag = 1;
					ifail=t9NewPartReqCre_Val0052;
					EMH_store_error_s1(EMH_severity_error,ifail,"For Proposed TPL Number, Part Type TPL is Required!!");
					return ifail;
				}
				if(tc_strlen(newReqpartType)>0)
				{
					if(tc_strcmp(newReqpartType,"Module")==0 
						|| tc_strcmp(newReqpartType,"M")==0 
						|| tc_strcmp(newReqpartType,"IFD Module")==0 
						|| tc_strcmp(newReqpartType,"IM")==0 
						|| tc_strcmp(newReqpartType,"ECU Module")==0 
						|| tc_strcmp(newReqpartType,"EM")==0
						||tc_strcmp(newReqpartType,"Assembly")==0 
						|| tc_strcmp(newReqpartType,"A")==0 
						|| tc_strcmp(newReqpartType,"Component")==0 
						|| tc_strcmp(newReqpartType,"C")==0)
					{
						NPR_TPL_Create_ERROR_Flag = 1;
						ifail=t9NewPartReqCre_Val0053;
						EMH_store_error_s1(EMH_severity_error,ifail,"For Proposed TPL Number, Only Part Type TPL is Required!!");
						return ifail;
					}
				}
				if(tc_strlen(designgroup1)==0)
				{
					NPR_TPL_Create_ERROR_Flag = 1;
					ifail=t9NewPartReqCre_Val0054;
					EMH_store_error_s1(EMH_severity_error,ifail,"For TPL Part Type,Design Group is requires!!");
					return ifail;
				}
			}

			printf("\n In NewPartReqItem_create_pre_condition In Message Code ::NewPartReq NPR_TPL_Create_ERROR_Flag %d\n",NPR_TPL_Create_ERROR_Flag);fflush(stdout);
			if((tc_strcmp(newReqpartType,"T")==0 || tc_strcmp(newReqpartType,"Technical Part List")==0) && NPR_TPL_Create_ERROR_Flag==0 && tc_strlen(ProposeTPLNumDup)>0)
			{
				int		IsAvailInUA			=	0;
				int		ValCntT				=	0;
				tag_t*	ValCntrlObjectTagT	=	NULLTAG;
				tag_t	qryTagT				=	NULLTAG;
				char    **qry_valuesT		=	(char **) MEM_alloc(10 * sizeof(char *));
				int		n_entryT			=	1;
				char    *qry_entryT[1]		=	{"SYSCD"};
				char *New_TML_Part_Number_NPR	= NULL;
				char *partDuplicateCheckStr	= NULL;
				char *partDuplicateCheckLocStr	= NULL;
				char *partDuplicateCheckShellStr	= NULL;
				char *itemId	= NULL;


				if(QRY_find2("ControlObjects", &qryTagT));
				if (qryTagT)
				{
					printf("\n In NewPartReqItem_create_pre_condition In Message Code ::Found Query ControlObjects  ");fflush(stdout);
				}
				else
				{
					printf("\n In NewPartReqItem_create_pre_condition In Message Code ::Not Found Query ControlObjects  ");fflush(stdout);
				}
				qry_valuesT[0] = "NPRPartDuplicateCheck" ;
				if(QRY_execute(qryTagT, n_entryT, qry_entryT, qry_valuesT, &ValCntT, &ValCntrlObjectTagT));
				printf(" \n In NewPartReqItem_create_pre_condition In Message Code ::PartInTCE:ValCnt :%d:", ValCntT); fflush(stdout);
				if(ValCntT>0)
				{
					AOM_ask_value_string(ValCntrlObjectTagT[0],"t5_Userinfo3",&partDuplicateCheckStr);
					printf("\n In NewPartReqItem_create_pre_condition In Message Code ::partDuplicateCheckStr===>[%s]",partDuplicateCheckStr);fflush(stdout);

					AOM_ask_value_string(ValCntrlObjectTagT[0],"t5_Userinfo5",&partDuplicateCheckLocStr);
					printf("\n In NewPartReqItem_create_pre_condition In Message Code ::partDuplicateCheckLocStr===>[%s]",partDuplicateCheckLocStr);fflush(stdout);

					AOM_ask_value_string(ValCntrlObjectTagT[0],"t5_Userinfo7",&partDuplicateCheckShellStr);
					printf("\n In NewPartReqItem_create_pre_condition In Message Code ::partDuplicateCheckShellStr===>[%s]",partDuplicateCheckShellStr);fflush(stdout);

					IsAvailInUA = IsDesignRevisionAvail(ProposeTPLNumDup);
					printf("\n In NewPartReqItem_create_pre_condition In Message Code ::IsAvailInUA===>[%d]",IsAvailInUA);fflush(stdout);

					if(IsAvailInUA == 0 && tc_strstr(partDuplicateCheckStr,"TPL")!=NULL)
					{
						char *username=NULL;
						tag_t user_tag=NULLTAG;
						char*	sysCmnd	=	NULL;
						char *homeSite = NULL;
						char* PNoStr = NULL;
						char* FNameStr = NULL;
						sysCmnd=(char *) MEM_alloc(400);
						PNoStr=(char *) MEM_alloc(400);
						FNameStr=(char *) MEM_alloc(400);
						tc_strcpy(PNoStr,ProposeTPLNumDup);
						tc_strcpy(FNameStr,ProposeTPLNumDup);
						tc_strcat(FNameStr,".txt");
						printf("\n PNoStr: [%s]\n",PNoStr);fflush(stdout);
						printf("\n FNameStr: [%s]\n",FNameStr);fflush(stdout);
						POM_get_user(&username,&user_tag);
						AOM_UIF_ask_value(user_tag,"fnd0home_site",&homeSite);
						printf("\n homeSite===>[%s]",homeSite);fflush(stdout);
						if(tc_strcmp(homeSite,"CV_Production")==0)
						{
							tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/NPRCVPROD/PartCallingNPRCVShell.sh ");
						}
						else if(tc_strcmp(homeSite,"Production-Pune")==0)
						{
							tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/NPRUAPROD/PartCallingNPRPVShell.sh ");
						}
						else if(tc_strcmp(homeSite,"Cmitest")==0 || tc_strcmp(homeSite,"AWS_FullTextSearch_Solr_Site")==0)
						{
							tc_strcpy(sysCmnd,"/user/testcmi/Dev/devgroups/sudhir/NPRCheck/PartCallingNPRCMITESTShell.sh ");
						}
						else if(tc_strcmp(homeSite,"IMC--1750164028")==0 || tc_strcmp(homeSite,"IMC--1254497832")==0)
						{
							tc_strcpy(sysCmnd,"/user/infodba03/sudhir/NPRCheck/PartCallingNPRDEVShell.sh ");
						}
						else
						{
							//tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/PartCallingShell.sh ");
							tc_strcpy(sysCmnd,partDuplicateCheckLocStr);
							tc_strcat(sysCmnd,partDuplicateCheckShellStr);
							tc_strcat(sysCmnd," ");
							//tc_strcat(sysCmnd,"PartCallingNPROtherShell.sh ");
						}
						//tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/PartCallingShell.sh ");
						tc_strcat(sysCmnd,PNoStr);
						tc_strcat(sysCmnd," ");
						tc_strcat(sysCmnd,FNameStr);
						printf("\n In NewPartReqItem_create_pre_condition In Message Code ::Command: [%s]\n",sysCmnd);fflush(stdout);
						system(sysCmnd);
						MEM_free(sysCmnd);

						// File Open...

						FILE* fptr = NULL;
						char *File_Name = NULL;
						char *File_LOC = NULL;
						char *inputline = NULL;
						char	*f	=NULL;
						char	result1 [ 100000 ] ;
						char	result2 [ 100000 ] ;

						int i = 0;

						File_Name=(char *) MEM_alloc(200);
						File_LOC=(char *) MEM_alloc(400);
						tc_strcpy(File_Name,ProposeTPLNumDup);
						tc_strcat(File_Name,".txt");
						if(tc_strcmp(homeSite,"CV_Production")==0)
						{
							tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/NPRCVPROD/");
						}
						else if(tc_strcmp(homeSite,"Production-Pune")==0)
						{
							tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/NPRUAPROD/");
						}
						else if(tc_strcmp(homeSite,"Cmitest")==0 || tc_strcmp(homeSite,"AWS_FullTextSearch_Solr_Site")==0)
						{
							tc_strcpy(File_LOC,"/user/testcmi/Dev/devgroups/sudhir/NPRCheck/");
						}
						else if(tc_strcmp(homeSite,"IMC--1750164028")==0 || tc_strcmp(homeSite,"IMC--1254497832")==0)
						{
							tc_strcpy(File_LOC,"/user/infodba03/sudhir/NPRCheck/");
						}
						else
						{
							tc_strcpy(File_LOC,partDuplicateCheckLocStr);
						}
						tc_strcat(File_LOC,File_Name);
						printf("\n File_Name: [%s]\n",File_Name);fflush(stdout);
						printf("\n File_LOC: [%s]\n",File_LOC);fflush(stdout);
						fptr=fopen(File_LOC,"r");
						if(fptr!=NULL)
						{
							inputline=(char *) MEM_alloc(50000);
							while(fgets(inputline,50000,fptr)!=NULL)
							{
								for (i = 0; i < strlen(inputline); i++)
								{
									if ( inputline[i] == '\n' || inputline[i] == '\r' )
										inputline[i] = '\0';
								}
								while(1)
								{
									f = strstr(inputline,",,");
									if(f==NULL)
									{
										break;
									}

									strcpy(result2,f+1);					
									*(f+1)=' ';
									*(f+2)='\0';
									strcat(f,result2);
								}
								strcpy(result1,inputline);
								printf("\n inputline .......%s\n",result1);fflush(stdout);
								itemId=tc_strtok(result1,"^");
								printf("\n itemId .......[%s]\n",itemId);fflush(stdout);
								if(tc_strlen(itemId)>0 && tc_strcmp(itemId,"NA")!=0)
								{
									ifail=t9NewPartReqCre_Val0055;
									EMH_store_error_s1(EMH_severity_error,ifail,"Given Proposed TPL Number is alreday Present in TCE or TCUA.\nPlease give other TPL Number!!");
									return ifail;
								}
								else
								{
									printf(" \n TPL PART NOT AVAILABLE SO CREATE ALLOWED"); fflush(stdout);
								}
							}
						}
						else
						{
							printf(" \n FILE NOT AVAILABLE :: ERROR MESSAGE TO BE PRINT"); fflush(stdout);							
						}
					}
				}
			}
			AOM_ask_value_string(item,"t5_ModuleAddress",&SubModuleAddress);
			printf("\n In NewPartReqItem_create_pre_condition In Message Code ::NewPartReq SubModuleAddress %s\n",SubModuleAddress);fflush(stdout);

			if(tc_strcmp(newReqpartType,"Module")==0 || tc_strcmp(newReqpartType,"M")==0 || tc_strcmp(newReqpartType,"IFD Module")==0 || tc_strcmp(newReqpartType,"IM")==0 || tc_strcmp(newReqpartType,"ECU Module")==0 || tc_strcmp(newReqpartType,"EM")==0)
			{
				SubModuleAddress = (char *) MEM_alloc( 200 * sizeof(char) );
				AOM_ask_value_string(item,"t5_AggregateGrp",&AggregateGrp);
				AOM_ask_value_string(item,"t5_SubModDsgGrp",&SubModDesignGroup);
				printf("\n In NewPartReqItem_create_pre_condition In Message Code ::NewPartReq AggregateGrp %s\n",AggregateGrp);fflush(stdout);
				printf("\n In NewPartReqItem_create_pre_condition In Message Code ::NewPartReq SubModDesignGroup %s\n",SubModDesignGroup);fflush(stdout);
				
				tempAggregateGrp = (char *) MEM_alloc(2 * sizeof(char) );
				tempAggregateGrp= NewPartsubString(AggregateGrp,0,1);
				printf("\n In NewPartReqItem_create_pre_condition In Message Code ::NewPartReq tempAggregateGrp %s\n",tempAggregateGrp);fflush(stdout);

				AOM_ask_value_string(item,"t5_Aggregates",&Aggregates);
				AggregatesDup = strdup(Aggregates);
				printf("\n In NewPartReqItem_create_pre_condition In Message Code ::NewPartReq Aggregates %s\n",Aggregates);fflush(stdout);
				tempAggregates = strtok(Aggregates, "-");

				
				AOM_ask_value_string(item,"t5_Module",&Module);
				ModuleDup = strdup(Module);
				printf("\n In NewPartReqItem_create_pre_condition In Message Code ::NewPartReq Module %s\n",Module);fflush(stdout);
				tempModule = strtok(Module, "-");

				AOM_ask_value_string(item,"t5_SubModule",&SubModule);
				printf("\n In NewPartReqItem_create_pre_condition In Message Code ::NewPartReq SubModule %s\n",SubModule);fflush(stdout);
				SubModuleDup = strdup(SubModule);
				tempSubModule = strtok(SubModule, "-");

				tc_strcpy(SubModuleAddress,tempAggregateGrp);
				tc_strcat(SubModuleAddress,tempAggregates);
				tc_strcat(SubModuleAddress,tempModule);
				tc_strcat(SubModuleAddress,tempSubModule);
				printf("\n In NewPartReqItem_create_pre_condition In Message Code ::NewPartReq SubModuleAddress %s\n",SubModuleAddress);fflush(stdout);
				
				modaddlen = tc_strlen(SubModuleAddress);
				int ModAddctrl_n_found = 0;
				tag_t	*ModAddCntrlObjs	= NULLTAG;
				char *modinfo01Str	= NULL;
				char *modinfo02Str	= NULL;
				char *ErrorMsg	= NULL;

				ModAddctrl_qry_values[0]	= "NewPartReqPartTypeCheckForIFD";
				QRY_find2("ControlObjQry", &ModAddctrlquery);
				QRY_execute(ModAddctrlquery,1, ModAddctrl_qry_entries, ModAddctrl_qry_values, &ModAddctrl_n_found, &ModAddCntrlObjs);
				printf("\n ModAddctrl_n_found =[%d]",ModAddctrl_n_found);fflush(stdout);
				if(ModAddctrl_n_found>0)
				{
					AOM_ask_value_string(ModAddCntrlObjs[0],"t5_Userinfo1",&modinfo01Str);
					AOM_ask_value_string(ModAddCntrlObjs[0],"t5_Userinfo2",&modinfo02Str);
					if(tc_strstr(modinfo01Str,SubModuleAddress)!=NULL || tc_strstr(modinfo02Str,SubModuleAddress)!=NULL)
					{
						if(tc_strcmp(newReqpartType,"Module")==0 || tc_strcmp(newReqpartType,"M")==0)
						{
							ErrorMsg = (char *) MEM_alloc( 1000 * sizeof(char) );
							tc_strcpy(ErrorMsg,"Sub Module Address[");
							tc_strcat(ErrorMsg,SubModuleAddress);
							tc_strcat(ErrorMsg,"] Part Type Module is not applicable.Please Change Part Type.\nIFD Module is applicable for Below Submodule Address\n");
							tc_strcat(ErrorMsg,modinfo01Str);
							tc_strcat(ErrorMsg,"\nECU Module is applicable for below Module Address.\n");
							tc_strcat(ErrorMsg,modinfo02Str);
							ifail=t9NewPartReqCre_Val0011;
							EMH_store_error_s1(EMH_severity_error,ifail,ErrorMsg);
							return ifail;
						}
					}
				}
				
			}
			printf("\n In NewPartReqItem_create_pre_condition In Message Code ::NewPartReq modaddlen %d\n",modaddlen);fflush(stdout);

			AOM_ask_value_string(item,"t5_DesignGroup",&designgroup);
			printf("\n NewPartReqItem_create_pre_condition:: designgroup====>[%s]", designgroup);fflush(stdout);

			AOM_ask_value_string(item,"t5_DesignSubGrp",&t5NwDgSbGrpDupS);
			t5NwDgSbGrpS = strdup(t5NwDgSbGrpDupS);
			printf("\n NewPartReqItem_create_pre_condition:: t5NwDgSbGrpS====>[%s]", t5NwDgSbGrpS);fflush(stdout);

			AOM_ask_value_string(item,"t5_NwDgId",&designid);
			printf("\n NewPartReqItem_create_pre_condition:: designid====>[%s]", designid);fflush(stdout);
			
			
			if(tc_strlen(newReqpartType)==0)
			{
				ifail=t9NewPartReqCre_Val0038;
				EMH_store_error_s1(EMH_severity_error,ifail,"Part Type Selection is Required!!");
				return ifail;
			}
			
			if(tc_strcmp(newReqpartType,"Module")==0 || tc_strcmp(newReqpartType,"M")==0 || tc_strcmp(newReqpartType,"IFD Module")==0 || tc_strcmp(newReqpartType,"IM")==0 || tc_strcmp(newReqpartType,"ECU Module")==0 || tc_strcmp(newReqpartType,"EM")==0)
			{
				if(modaddlen==0)
				{
					ifail=t9NewPartReqCre_Val0033;
					EMH_store_error_s1(EMH_severity_error,ifail,"For Module Part Type,AggrgateGroup/Aggregate/Module/SubModule Required!!");
					return ifail;
				}
				if(tc_strlen(SubModuleDup)==0 || tc_strlen(ModuleDup)==0 || tc_strlen(AggregatesDup)==0 || tc_strlen(AggregateGrp)==0)
				{
					ifail=t9NewPartReqCre_Val0012;
					EMH_store_error_s1(EMH_severity_error,ifail,"For Module Part Type,AggrgateGroup/Aggregate/Module/SubModule Required!!");
					return ifail;
				}
				if(tc_strlen(designgroup)==0)
				{
					ifail=t9NewPartReqCre_Val0035;
					EMH_store_error_s1(EMH_severity_error,ifail,"For Module Part Type,Design Group is requires!!");
					return ifail;
				}
				
				
				if(tc_strlen(SubModDesignGroup)==0)
				{
					ifail=t9NewPartReqCre_Val0024;
					EMH_store_error_s1(EMH_severity_error,ifail,"For Module Part Type,Sub Module Design Group is requires!!");
					return ifail;
				}
				if(tc_strcmp(SubModDesignGroup,designgroup)!=0)
				{
					ifail=t9NewPartReqCre_Val0013;
					EMH_store_error_s1(EMH_severity_error,ifail,"For Module Part Type,Sub Module Design Group and Design Group Should be match.");
					return ifail;
				}
				
				

				if(tc_strlen(t5NwDgSbGrpS)>0 || tc_strlen(designid)>0)
				{
					ifail=t9NewPartReqCre_Val0036;
					EMH_store_error_s1(EMH_severity_error,ifail,"For Module Part Type,Design Sub Group and Designation ID is not requires!!");
					return ifail;
				}

				if(ExtPrtInd==true || PrtCmoInd==true)
				{
					if(tc_strlen(anyfileS)==0)
					{
						ifail=t9NewPartReqCre_Val0039;
						EMH_store_error_s1(EMH_severity_error,ifail,"For Module Part Type,Attach Similiar Part Analysis Report required!!");
						return ifail;
					}
				}
				if(StdFldInd==true)
				{
					if(tc_strlen(NwPrtVliS)==0)
					{
						ifail=t9NewPartReqCre_Val0040;
						EMH_store_error_s1(EMH_severity_error,ifail,"For Module Part Type,Attach Justification required!!");
						return ifail;
					}
				}

				if(IBDomesticDup==0)
				{
					ifail=t9NewPartReqCre_Val0018;
					EMH_store_error_s1(EMH_severity_error,ifail,"For Module Part Type,IBDomestic Required!!");
					return ifail;
				}

				if(ProductLineDup==0)
				{
					ifail=t9NewPartReqCre_Val0019;
					EMH_store_error_s1(EMH_severity_error,ifail,"For Module Part Type,Product Line Required!!");
					return ifail;
				}

				/*
				if(StdFldInd==false)
				{
					if(tc_strlen(NwThirdAttachS)==0)
					{
						ifail=t9NewPartReqCre_Val0041;
						EMH_store_error_s1(EMH_severity_error,ifail,"For Module Part Type,Attach Justification Details required!!");
						return ifail;
					}
				}
				*/
				
			}
			if(AlowCreSubMod==true || AlowCreSubMod==1)
			{
				if(tc_strcmp(newReqpartType,"Module")==0 || tc_strcmp(newReqpartType,"M")==0 || tc_strcmp(newReqpartType,"IFD Module")==0 || tc_strcmp(newReqpartType,"IM")==0 || tc_strcmp(newReqpartType,"ECU Module")==0 || tc_strcmp(newReqpartType,"EM")==0)
				{
					if(tc_strlen(NPRDRStatus)==0 || tc_strlen(NPRPartCategoryDup)==0 || tc_strlen(NPRStartPartProductDup)==0)
					{
						ifail=t9NewPartReqCre_Val0042;
						EMH_store_error_s1(EMH_severity_error,ifail,"Pls select DRStatus, Part Category, Start Part Product");
						return ifail;
					}
					if(tc_strlen(PlateformDup)==0 && (tc_strcmp(newReqpartType,"Module")==0 || tc_strcmp(newReqpartType,"M")==0 || tc_strcmp(newReqpartType,"IFD Module")==0 || tc_strcmp(newReqpartType,"IM")==0 || tc_strcmp(newReqpartType,"ECU Module")==0 || tc_strcmp(newReqpartType,"EM")==0))
					{
						ifail=t9NewPartReqCre_Val0043;
						EMH_store_error_s1(EMH_severity_error,ifail,"Pls select Plateform, For Module Part Type");
						return ifail;
					}
				}
				if(tc_strcmp(newReqpartType,"Assembly")==0 || tc_strcmp(newReqpartType,"A")==0 || tc_strcmp(newReqpartType,"Component")==0 || tc_strcmp(newReqpartType,"C")==0 || tc_strcmp(newReqpartType,"Technical Part List")==0 || tc_strcmp(newReqpartType,"T")==0)
				{
					ifail=t9NewPartReqCre_Val0014;
					EMH_store_error_s1(EMH_severity_error,ifail,"Allowed To Create Submodule is not required for Assembly/Cmponent/TPL Part Type");
					return ifail;
				}
				
			}
			
			if(AlowCreSubMod==false || AlowCreSubMod==0)
			{
				if(tc_strcmp(newReqpartType,"Module")==0 || tc_strcmp(newReqpartType,"M")==0 || tc_strcmp(newReqpartType,"IFD Module")==0 || tc_strcmp(newReqpartType,"IM")==0 || tc_strcmp(newReqpartType,"ECU Module")==0 || tc_strcmp(newReqpartType,"EM")==0)
				{
					if(tc_strlen(NPRDRStatus)==0 || tc_strlen(NPRPartCategoryDup)==0 || tc_strlen(NPRStartPartProductDup)==0)
					{
						ifail=t9NewPartReqCre_Val0022;
						EMH_store_error_s1(EMH_severity_error,ifail,"Pls select DRStatus, Part Category, Start Part Product");
						return ifail;
					}
					if(tc_strlen(PlateformDup)==0 && (tc_strcmp(newReqpartType,"Module")==0 || tc_strcmp(newReqpartType,"M")==0 || tc_strcmp(newReqpartType,"IFD Module")==0 || tc_strcmp(newReqpartType,"IM")==0 || tc_strcmp(newReqpartType,"ECU Module")==0 || tc_strcmp(newReqpartType,"EM")==0))
					{
						ifail=t9NewPartReqCre_Val0023;
						EMH_store_error_s1(EMH_severity_error,ifail,"Pls select Plateform, For Module Part Type");
						return ifail;
					}
				}
				/*
				if(tc_strcmp(newReqpartType,"Module")==0 || tc_strcmp(newReqpartType,"M")==0 || tc_strcmp(newReqpartType,"IFD Module")==0 || tc_strcmp(newReqpartType,"IM")==0 || tc_strcmp(newReqpartType,"ECU Module")==0 || tc_strcmp(newReqpartType,"EM")==0)
				{
					ifail=t9NewPartReqCre_Val0022;
					EMH_store_error_s1(EMH_severity_error,ifail,"Pls select Allowed To Create Submodule as True.");
					return ifail;
				}
				*/
			}
			
			if(tc_strcmp(newReqpartType,"Assembly")==0 || tc_strcmp(newReqpartType,"A")==0 || tc_strcmp(newReqpartType,"Component")==0 || tc_strcmp(newReqpartType,"C")==0)
			{
				if(modaddlen>0)
				{
					ifail=t9NewPartReqCre_Val0032;
					EMH_store_error_s1(EMH_severity_error,ifail,"For Assembly/Component Part Type,Sub Module Address is not requires!!");
					return ifail;
				}
				AOM_ask_value_string(item,"t5_CategoryName",&NwKeywrdDescription);
				if(tc_strlen(NwKeywrdDescription)==0)
				{
					ifail=t9NewPartReqCre_Val0044;
					EMH_store_error_s1(EMH_severity_error,ifail,"For Assembly/Component Part Type,Keyword Description requires!!");
					return ifail;
				}
				
				if(tc_strlen(SubModDesignGroup)>0)
				{
					ifail=t9NewPartReqCre_Val0031;
					EMH_store_error_s1(EMH_severity_error,ifail,"For Assembly/Component Part Type,Sub Module Design Group is not requires!!");
					return ifail;
				}

				if(ExtPrtInd==true || PrtCmoInd==true)
				{
					if(tc_strlen(anyfileS)==0)
					{
						ifail=t9NewPartReqCre_Val0039;
						EMH_store_error_s1(EMH_severity_error,ifail,"For Module Part Type,Attach Similiar Part Analysis Report required!!");
						return ifail;
					}
				}
				if(StdFldInd==true)
				{
					if(tc_strlen(NwPrtVliS)==0)
					{
						ifail=t9NewPartReqCre_Val0040;
						EMH_store_error_s1(EMH_severity_error,ifail,"For Module Part Type,Attach Justification required!!");
						return ifail;
					}
				}
				
			}
			/*
			if(isFor12Digit==false && isFor14Digit==false)
			{
				ifail=t9NewPartReqCre_Val0031;
				EMH_store_error_s1(EMH_severity_error,ifail,"Pls select either 12Digit or 14Digit option.For 14Digit,Sub Module Address is required!!");
				return ifail;
			}
			if(isFor12Digit==true)
			{
				if(modaddlen>0)
				{
					ifail=t9NewPartReqCre_Val0032;
					EMH_store_error_s1(EMH_severity_error,ifail,"For 12Digit,Sub Module Address is not requires!!");
					return ifail;
				}
			}
			if(isFor14Digit==true)
			{
				if(modaddlen==0)
				{
					ifail=t9NewPartReqCre_Val0033;
					EMH_store_error_s1(EMH_severity_error,ifail,"For 14Digit,Sub Module Address is requires!!");
					return ifail;
				}
				if(tc_strlen(designgroup)==0)
				{
					ifail=t9NewPartReqCre_Val0035;
					EMH_store_error_s1(EMH_severity_error,ifail,"For 14Digit,Design Group is requires!!");
					return ifail;
				}

				if(tc_strlen(t5NwDgSbGrpS)>0 || tc_strlen(designid)>0)
				{
					ifail=t9NewPartReqCre_Val0036;
					EMH_store_error_s1(EMH_severity_error,ifail,"For 14Digit,Design Sub Group and Designation ID is not requires!!");
					return ifail;
				}
			}
			if(isFor12Digit==true && isFor14Digit==true)
			{
				ifail=t9NewPartReqCre_Val0034;
				EMH_store_error_s1(EMH_severity_error,ifail,"Please select either 12Digit or 14Digit option!!");
				return ifail;
			}
			*/

			AOM_ask_value_string(item,"item_id",&itemId);
			printf("\n In NewPartReqItem_create_pre_condition In Message Code ::NewPartReq Item ID %s\n",itemId);fflush(stdout);

			AOM_ask_value_string(item,"t5_ProjectCode",&prj_code);
			printf("\n NewPartReqItem_create_pre_condition:: prj_code====>[%s]", prj_code);fflush(stdout);

			prj_qry_values[0]	= prj_code;
			prj_qry_values[1]	= "Project";
			QRY_find2("Item...", &prjquery);
			QRY_execute(prjquery, 2, prj_qry_entries, prj_qry_values, &prj_n_found, &prj_items);
			printf("\n prj_n_found =[%d]",prj_n_found);
			if(prj_n_found>0)
			{
				AOM_ask_value_string(prj_items[0],"t5_BussUnitType",&BussiNameS);
				printf("\n BussiNameS====>[%s]", BussiNameS);fflush(stdout);
				AOM_ask_value_string(prj_items[0],"t5_ProjectType",&Proj_typ);
				printf("\n Proj_typ====>[%s]", Proj_typ);fflush(stdout);
			}

			/*
			AOM_ask_value_string(item,"t5_DesignGroup",&designgroup);
			printf("\n NewPartReqItem_create_pre_condition:: designgroup====>[%s]", designgroup);fflush(stdout);

			AOM_ask_value_string(item,"t5_DesignSubGrp",&t5NwDgSbGrpDupS);
			t5NwDgSbGrpS = strdup(t5NwDgSbGrpDupS);
			printf("\n NewPartReqItem_create_pre_condition:: t5NwDgSbGrpS====>[%s]", t5NwDgSbGrpS);fflush(stdout);

			AOM_ask_value_string(item,"t5_NwDgId",&designid);
			printf("\n NewPartReqItem_create_pre_condition:: designid====>[%s]", designid);fflush(stdout);
			*/

			
			if(tc_strcmp(anyfileS,"NA")!= 0 && anyfileS!=NULL && tc_strlen(anyfileS)>0)
			{
				anyfileret = strrchr(anyfileS, ch);
				printf("\nextension is==========>%s\n", anyfileret);fflush(stdout);
				if(anyfileret== NULL)
				{
					error++;
				}
			}
			if(tc_strcmp(NwPrtVliS,"NA")!= 0 && NwPrtVliS!=NULL && tc_strlen(NwPrtVliS)>0)
			{
				NwPrtVliret = strrchr(NwPrtVliS, ch);
				printf("\nextension is==========>%s\n", NwPrtVliret);fflush(stdout);
				if(NwPrtVliret== NULL)
				{
					error++;
				}
			}
			if(tc_strcmp(NwThirdAttachS,"NA")!= 0 && NwThirdAttachS!=NULL && tc_strlen(NwThirdAttachS)>0)
			{
				NwThirdAttachret = strrchr(NwThirdAttachS, ch);
				printf("\nextension is==========>%s\n", NwThirdAttachret);fflush(stdout);
				if(NwThirdAttachret== NULL)
				{
					error++;
				}
			}

			/*
			if(strcmp(anyfileS,"NA")!= 0 || strcmp(NwPrtVliS,"NA")!= 0 || strcmp(NwThirdAttachS,"NA")!= 0)
			{	
				anyfileret = strrchr(anyfileS, ch);
				NwPrtVliret = strrchr(NwPrtVliS, ch);
				NwThirdAttachret = strrchr(NwThirdAttachS, ch);
				printf("\nextension is==========>%s\n", anyfileret);fflush(stdout);
				printf("\nextension is==========>%s\n", NwPrtVliret);fflush(stdout);
				printf("\nextension is==========>%s\n", NwThirdAttachret);fflush(stdout);
				if((anyfileret!=NULL) || (NwPrtVliret!=NULL) || (NwThirdAttachret!=NULL))
				{
					printf("\nextension is present\n");fflush(stdout);
				}

				if(anyfileS!=NULL)
				{
					anyfileret = NULL;
					anyfileret = strrchr(anyfileS, ch);
					if(anyfileret== NULL)
					{
						error++;
					}
				}
				if(NwPrtVliS!=NULL)
				{
					NwPrtVliret = NULL;
					NwPrtVliret = strrchr(NwPrtVliS, ch);
					if(NwPrtVliret== NULL)
					{
						error++;
					}
				}
				if(NwThirdAttachS!=NULL)
				{
					NwThirdAttachret = NULL;
					NwThirdAttachret = strrchr(NwThirdAttachS, ch);
					if(NwThirdAttachret== NULL)
					{
						error++;
					}
				}
			}
			*/
			printf("\n NewPartReqItem_create_pre_condition:: error====>[%d]", error);fflush(stdout);
			if(error>0)
			{
				ifail=t9NewPartReqCre_Val007;
				EMH_store_error_s1(EMH_severity_error,ifail,"Pls give valid File Name with valid file extension(txt/doc/pdf/xls/ppt/jpeg) !!");
				return ifail;
			}
			if(tc_strcmp(anyfileS,"NA")==0 || tc_strcmp(NwPrtVliS,"NA")==0 || tc_strcmp(NwThirdAttachS,"NA")==0)
			{
				printf("\n filename1 is==========>%s,%s,%s\n", anyfileS,NwPrtVliS,NwThirdAttachS);fflush(stdout);
				EMH_clear_errors();
				ifail=t9NewPartReqCre_Val006;
				EMH_store_error_s1(EMH_severity_error,ifail, "In File Name NA is not allowed, Pls give valid name with file extension(txt/doc/pdf/xls/ppt/jpeg)!!");
				return ifail;
			}

			AOM_ask_value_string(item,"t5_PartType",&PartType);
			printf("\n NewPartReqItem_create_pre_condition:: PartType====>[%s]", PartType);fflush(stdout);

			/*
			if(strcmp(BussiNameS,"CVBU")==0)
			{
				AOM_ask_value_string(item,"t5_CategoryName",&NwKeywrdDes);
				NwKeywrdDesdup = strdup(NwKeywrdDes);
				printf("\nKeyWord Description of New Part Request is----->>> (%s)\n",NwKeywrdDesdup);fflush(stdout);
				classification_qry_values[0]	= NwKeywrdDesdup;
				classification_qry_values[1]	= "*";
				QRY_find2("QryKyWrd_iDsgGrp_oClsfObj", &classificationquery);
				QRY_execute(classificationquery, 2, classification_qry_entries, classification_qry_values, &classification_n_found, &UaPartSO);
				printf("\n classification_n_found =[%d]",classification_n_found);fflush(stdout);
				if(classification_n_found>0)
				{
					ctrl_qry_values5[0]	= "PartFamily";
					QRY_find2("ControlObjQry", &ctrlquery5);
					QRY_execute(ctrlquery5, 1, ctrl_qry_entries5, ctrl_qry_values5, &ctrl_n_found5, &partFamObjs);
					printf("\n ctrl_n_found5 =[%d]",ctrl_n_found5);fflush(stdout);
					if(ctrl_n_found5>0)
					{
						for(g=0;g<ctrl_n_found5;g++)
						{
							printf("\n NwKeywrdDesdup  [%s]\n",NwKeywrdDesdup); fflush(stdout);
							AOM_ask_value_string(partFamObjs[g],"t5_Userinfo1",&prtFamily);
							partFam = strdup(prtFamily);
							printf("\n Part Family  from keyword  [%s]\n",partFam); fflush(stdout);
							AOM_ask_value_string(partFamObjs[g],"t5_Userinfo2",&strClassID);
							printf("\n strClassID====>[%s]", strClassID);fflush(stdout);
							if(tc_strcmp(NwKeywrdDesdup,partFam)==0)
							{
								AOM_ask_value_string(partFamObjs[g],"t5_Userinfo2",&strClassID);
								printf("\n NewPartReqItem_create_pre_condition:: strClassIDdup====>[%s]", strClassID);fflush(stdout);
								strClassIDdup = strdup(strClassID);
								printf("\n NewPartReqItem_create_pre_condition:: strClassIDdup====>[%s]", strClassIDdup);fflush(stdout);
								break;
							}
						}
						/
						printf("\n before calling GetClassDetails...[%s]\n",strClassIDdup);fflush(stdout);
						if(strClassIDdup!=NULL)
						{
							formatType=&xyzf;
							modifier1=&xyzm1;
							modifier2=&xyzm2;
							length=&xyzl;
							//sOutStr = (char **)GetClassDetails(strClassIDdup,&nSize, &Ids,&formatType,&modifier1,&modifier2,&length);
							//printf("\n After calling GetClassDetails...:nSize: %d \n",nSize);fflush(stdout);
							ICS_class_describe_attributes(strClassIDdup,
										&theCount,
										&theIds,
										&theNames,
										&theShortNames,
										&theAnnotations,
										&theArraySize,
										&theFormat,
										&theUnit,
										&theMinValues,
										&theMaxValues,
										&theDefaultValues,
										&theDescriptions,
										&theOptions1);
							printf("\n After calling GetClassDetails...:theCount: %d \n",theCount);fflush(stdout);
							ICS_class_ask_tag(strClassIDdup,&theClassTag);
							for(id=0;id<theCount;id++)
							{
								printf("\n ID : %d",theIds[id]);fflush(stdout);
							}
							ICS_view_ask_tag("defaultView",&view);
							ICS_class_describe(strClassIDdup,&theParent,&theType,&theName,&theShortName,&theDescription,&theUserData1,&theUserData2,&theOptions,&theInstanceCount,&theChildrenCount,&theViewCount);
							printf("\n\n theParent : %s ",theParent);fflush(stdout);
							printf("\n theType : %d ",theType);fflush(stdout);
							printf("\n theName : %s ",theName);fflush(stdout);
							printf("\n theShortName : %s ",theShortName);fflush(stdout);
							printf("\n theDescription : %s ",theDescription);fflush(stdout);
							printf("\n theUserData1 : %s ",theUserData1);fflush(stdout);
							printf("\n theUserData2 : %s ",theUserData2);fflush(stdout);
							printf("\n theOptions : %d ",theOptions);fflush(stdout);
							printf("\n theInstanceCount : %d ",theInstanceCount);fflush(stdout);
							printf("\n theChildrenCount : %d ",theChildrenCount);fflush(stdout);
							printf("\n theViewCount : %d \n\n",theViewCount);fflush(stdout);
							//ICS_search_instances(theClassTag,view,theCount,theIds,InputValuesArr1,&nInstances99,&instances99);
						}
						/
						
					}
				}
				MEM_free(partFamObjs);
				MEM_free(UaPartSO);
				///
				if(classification_n_found>0)
				{
					for(g=0;g<classification_n_found;g++)
					{
						AOM_ask_value_string(item,"t5_PartFamily",&prtFamily);
						partFam = strdup(prtFamily);
						printf("\n Part Family  from keyword  [%s]\n",partFam); fflush(stdout);
					}
				}
				if(strlen(partFam)>0)
				{
					ctrl_qry_values4[0]	= "PartFamily";
					ctrl_qry_values4[1]	= partFam;
					QRY_find2("ControlObjQry", &ctrlquery4);
					QRY_execute(ctrlquery4, 1, ctrl_qry_entries4, ctrl_qry_values4, &ctrl_n_found4, &partFamObjs);
					printf("\n ctrl_qry_values4 =[%d]",ctrl_qry_values4);fflush(stdout);
					if(ctrl_qry_values4>0)
					{
						AOM_ask_value_string(partFamObjs[0],"t5_Userinfo2",&strClassID);
						strClassIDdup = strdup(strClassID);
						printf("\n NewPartReqItem_create_pre_condition:: strClassIDdup====>[%s]", strClassIDdup);fflush(stdout);
					}
				}
				/
			}
			*/

			//if(isFor12Digit==true && isFor14Digit==false)
			if(tc_strcmp(newReqpartType,"Assembly")==0 || tc_strcmp(newReqpartType,"A")==0 || tc_strcmp(newReqpartType,"Component")==0 || tc_strcmp(newReqpartType,"C")==0)
			{
				if(tc_strlen(t5NwDgSbGrpS)!=2)
				{
					printf("\n NewPartReqItem_create_pre_condition:: t5NwDgSbGrpS====> is of 2 digit");fflush(stdout);
					ifail = t9NewPartReqCre_Val001;
					EMH_store_error_s2(EMH_severity_error,ifail,t5NwDgSbGrpS,"Given Sub Group should not more than 2 digit!!");
					return ifail;
				}
				if(tc_strlen(designid)!=2)
				{
					printf("\n NewPartReqItem_create_pre_condition:: designid====> is of 2 digit");fflush(stdout);
					ifail = t9NewPartReqCre_Val001;
					EMH_store_error_s2(EMH_severity_error,ifail,designid,"Given Designation Id should not more than 2 digit!!");
					return ifail;
				}

				if(strcmp(designid,"00")== 0 || strcmp(designid,"04")== 0)
				{
					printf("\n Inside  Dummy part creation condition via New Part Request value of designid-------->(%s) \n",designid );fflush(stdout);	
					ifail = t9NewPartReqCre_Val003;
					EMH_store_error_s2(EMH_severity_error,ifail,designid,"You are Trying to Create the Request for Dummy TC Part which is Not Requried!!");
					return ifail;
					
				}

				MachineNameS = (char *) MEM_alloc( 100 * sizeof(char) );
				strcpy(MachineNameS,prj_code);
				strcat(MachineNameS,designgroup);
				strcat(MachineNameS,t5NwDgSbGrpS);
				strcat(MachineNameS,designid);
				strcat(MachineNameS,"*");

				//values[0] = MachineNameS;
				//values[1] = "Design";
				//ITEM_find_items_by_key_attributes(1, attrs, values, &n_tags_found, &t_item1);

				qry_values[0]	= MachineNameS;
				qry_values[1]	= "Design";
				QRY_find2("Item...", &designquery);
				
				QRY_execute_with_sort(designquery, 2, qry_entries, qry_values, num_to_sort, keys, orders, &n_tags_found, &t_item1);

				printf("\n NewPartReqItem_create_pre_condition:: n_tags_found====>%d",n_tags_found);fflush(stdout);
				if(n_tags_found>0)
				{
					for(e1=0;e1<n_tags_found;e1++)
					{
						DesignPartTag = t_item1[e1];
						AOM_ask_value_string(DesignPartTag,"item_id",&part_num);
						printf("\n NewPartReqItem_create_pre_condition:: part_num====>%s",part_num);fflush(stdout);
						if(strlen(part_num)==12)
						{
							setAddTAG(&l,&soResult1,DesignPartTag);
						}
					}
					for(e2=0;e2<l;e2++)
					{
						AOM_ask_value_string(soResult1[e2],"item_id",&part_num1);
						printf("\n NewPartReqItem_create_pre_condition:: soResult1====>%d",l);fflush(stdout);
						printf("\n NewPartReqItem_create_pre_condition:: part_num1====>%s",part_num1);fflush(stdout);
						subpart91 = (char *) MEM_alloc(2 * sizeof(char) );
						subpart91= NewPartsubString(part_num1,10,2);
						printf("\n NewPartReqItem_create_pre_condition:: subpart91====>%s",subpart91);fflush(stdout);
						if(l>=98 || strcmp(subpart91,"99")==0)
						{
							NwDgSbGrpError = 1;
						}
					}
					if(NwDgSbGrpError==1)
					{
						ifail = t9NewPartReqCre_Val002;
						EMH_store_error_s2(EMH_severity_error,ifail,t5NwDgSbGrpS,"Please Increase the Design Sub Group Value by 1 and then Try to Create the Request Again!!");
						return ifail;
					}
					
				}
			//}

			
			

			ctrl_qry_values[0]	= "NwPrtReq";
			ctrl_qry_values[1]	= "Allow";
			QRY_find2("ControlObjQry", &ctrlquery);
			QRY_execute(ctrlquery, 2, ctrl_qry_entries, ctrl_qry_values, &ctrl_n_found1, &setOfUsrDbObjs);
			printf("\n ctrl_n_found1 =[%d]",ctrl_n_found1);fflush(stdout);
			printf("\n Inside the  control object greater than 1 condition-->\n");fflush(stdout);
			if(ctrl_n_found1>0)
			{
				AOM_ask_value_string(setOfUsrDbObjs[0],"t5_Userinfo6",&t5Userinfo6DupS);
				t5Userinfo6S = strdup(t5Userinfo6DupS);
				printf("\n In NewPartReqItem_create_pre_condition:: Control object row 6 ===> %s\n",t5Userinfo6S);fflush(stdout);
				if((tc_strstr(BussiNameS,"CVBU")!=NULL || strcmp(BussiNameS,"PCBU")==0) && tc_strstr(t5Userinfo6S,newReqpartType)!=NULL)
				{
					ctrl_qry_values2[0]	= "NwPrtReq";
					ctrl_qry_values2[1]	= BussiNameS;
					QRY_find2("ControlObjQry", &ctrlquery2);
					QRY_execute(ctrlquery2, 2, ctrl_qry_entries2, ctrl_qry_values2, &ctrl_n_found2, &setOfUsrDbObjsda);
					printf("\n ctrl_n_found2 =[%d]",ctrl_n_found2);fflush(stdout);
					if(ctrl_n_found2>0)
					{
						AOM_ask_value_string(setOfUsrDbObjsda[0],"t5_Userinfo1",&t5Userinfo1DupS);
						t5Userinfo1S = strdup(t5Userinfo1DupS);
						AOM_ask_value_string(setOfUsrDbObjsda[0],"t5_Userinfo2",&t5Userinfo2DupS);
						t5Userinfo2S = strdup(t5Userinfo2DupS);
						AOM_ask_value_string(setOfUsrDbObjsda[0],"t5_Userinfo3",&t5Userinfo3DupS);
						t5Userinfo3S = strdup(t5Userinfo3DupS);
						AOM_ask_value_string(setOfUsrDbObjsda[0],"t5_Userinfo4",&t5Userinfo4DupS);
						t5Userinfo4S = strdup(t5Userinfo4DupS);
						printf("\n In NewPartReqItem_create_pre_condition:: Control object row 1===> %s\n",t5Userinfo1S);fflush(stdout);
						printf("\n In NewPartReqItem_create_pre_condition:: Control object row 2 ===> %s\n",t5Userinfo2S);fflush(stdout);
						printf("\n In NewPartReqItem_create_pre_condition:: Control object row 3===> %s\n",t5Userinfo3S);fflush(stdout);
						printf("\n In NewPartReqItem_create_pre_condition:: Control object row 4 ===> %s\n",t5Userinfo4S);fflush(stdout);

						if(tc_strstr(BussiNameS,"CVBU")!=NULL)
						{
							printf("\n In NewPartReqItem_create_pre_condition::Inside the CVBU \n");fflush(stdout);

							if(strstr(t5Userinfo1S, designgroup) != NULL || strstr(t5Userinfo2S, designgroup) != NULL || strstr(t5Userinfo3S, designgroup) != NULL || strstr(t5Userinfo4S, designgroup) != NULL)
							{
								printf("\n#### Do nothing after checking 5th and 6th digit in In NewPartReqItem_create_pre_condition file  ###\n");fflush(stdout);
								ReqApplicable=1;
							}

						}
						else if (strcmp(BussiNameS,"PCBU")==0)
						{
							ctrl_qry_values3[0]	= "PVB";
							ctrl_qry_values3[1]	= "DesGrp";
							QRY_find2("ControlObjQry", &ctrlquery3);
							QRY_execute(ctrlquery3, 2, ctrl_qry_entries3, ctrl_qry_values3, &ctrl_n_found3, &setOfPVBUObjspv);
							printf("\n ctrl_n_found3 =[%d]",ctrl_n_found3);fflush(stdout);
							if(ctrl_n_found3>0)
							{
								AOM_ask_value_string(setOfPVBUObjspv[0],"t5_Userinfo1",&t5Userinfo1PV);
								t5PV1S = strdup(t5Userinfo1PV);
								AOM_ask_value_string(setOfPVBUObjspv[0],"t5_Userinfo2",&t5Userinfo2PV);
								t5PV2S = strdup(t5Userinfo2PV);
								AOM_ask_value_string(setOfPVBUObjspv[0],"t5_Userinfo3",&t5Userinfo3PV);
								t5PV3S = strdup(t5Userinfo3PV);
								AOM_ask_value_string(setOfPVBUObjspv[0],"t5_Userinfo4",&t5Userinfo4PV);
								t5PV4S = strdup(t5Userinfo4PV);
								printf("\n In NewPartReqItem_create_pre_condition:: Control object row 1===> %s\n",t5PV1S);fflush(stdout);
								printf("\n In NewPartReqItem_create_pre_condition:: Control object row 2 ===> %s\n",t5PV2S);fflush(stdout);
								printf("\n In NewPartReqItem_create_pre_condition:: Control object row 3===> %s\n",t5PV3S);fflush(stdout);
								printf("\n In NewPartReqItem_create_pre_condition:: Control object row 4 ===> %s\n",t5PV4S);fflush(stdout);

								if(strstr(t5PV1S, designgroup) != NULL || strstr(t5PV2S, designgroup) != NULL || strstr(t5PV3S, designgroup) != NULL || strstr(t5PV4S, designgroup) != NULL)
								{
									printf("\nIn t5NwpCre.mth PVBU control object Do nothing after checking Design group digit in t5AssyValidation.mth file  ###\n");fflush(stdout);
									ReqApplicable=1;
								}
								else
								{
									printf("\n In t5NwpCre.mth Inside else as design grp-(%s) not in control object for PVBU \n",designgroup);fflush(stdout);
									
									//if(isFor12Digit==true && isFor14Digit==false)
									if(tc_strcmp(newReqpartType,"Assembly")==0 || tc_strcmp(newReqpartType,"A")==0 || tc_strcmp(newReqpartType,"Component")==0 || tc_strcmp(newReqpartType,"C")==0)
									{
										if(strcmp(designgroup,"54")==0) 
										{
											if((strstr(designid,"82") != NULL) || (strstr(designid,"99") != NULL) || (strstr(designid,"63") != NULL) || (strstr(designid,"33") != NULL))
											{
												ReqApplicable=0;
												printf("\n In t5NwpCre.mth Flag Set to 0 for 82 ~~~~~~~~~\n");fflush(stdout);
											}
											else
											{
												printf("\n In t5NwpCre.mth Design group -(%s) CONDITION Designation id -(%s) ###\n",designgroup, designid);fflush(stdout);
												ReqApplicable=1;
												printf("\n In t5NwpCre.mth  Flag Set to 1 ~~~~~~~~~\n");fflush(stdout);
											}		
																				
										}
										else
										{
											if(strstr(t5Userinfo1S, designid) != NULL || strstr(t5Userinfo2S, designid) != NULL || strstr(t5Userinfo3S, designid) != NULL || strstr(t5Userinfo4S, designid) != NULL )
											{
												ReqApplicable=1;
												printf("\n In t5NwpCre.mth the 54 design grp condition -%s  \n",designgroup );fflush(stdout);
											}
										}
									}
															
								 }
							}
						}
					}
					if(ReqApplicable ==1)
					{
						printf("\n ####### Inside The design group exclude condition ##### \n");fflush(stdout);
						ifail = t9NewPartReqCre_Val004;
						EMH_store_error_s2(EMH_severity_error,ifail,designgroup,"New Part Request is Not Required For Design Group!!");
						return ifail;
					}
				}
			}//
			}

			if(strlen(anyfileS)==0)
			{
				//if(strcmp(PartType,"C")==0 && (isFor12Digit==true && isFor14Digit==false))
				if(strcmp(PartType,"C")==0)
				{
					printf("\nInside The  condition where first attachment is null and part type is component ##### \n");fflush(stdout);
					ifail = t9NewPartReqCre_Val005;
					EMH_store_error_s2(EMH_severity_error,ifail,designgroup,"If Part Type is Component then Attach Similar Part Analysis Report is Mandatory!!");
					return ifail;
				}
			}
		}	
	}
	MEM_free(t_item1);
    return ifail;
}


/****************************************************************************
Function:       NewPartReq_CheckList_pre_action
Description:    This function used for register custom method/handler 
				on class for different action like pre/post.
				code lsit of an user.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
extern DLLAPI int NewPartReq_CheckList_pre_action(METHOD_message_t *m, va_list args)
{
	int ifail=ITK_ok;
	tag_t item  = va_arg(args, tag_t);
	logical  isNew = va_arg(args, int);

	char *checklist_type=NULL;
	char *BaseSubModule=NULL;
	char *BaseVCDesc=NULL;
	char *BaseVCNum=NULL;
	char *Varity=NULL;
	char *NewSubModReqNum=NULL;
	char *VCDesc=NULL;
	char *VCNumber=NULL;
	char *Change=NULL;
	char *SubModDes=NULL;
	char *Requirement=NULL;
	char *CarryOver=NULL;
	char *ReplaceEliminate=NULL;
	char *VarLib=NULL;

	AOM_ask_value_string(item,"object_type",&checklist_type);
	printf("\n **NewPartReq_CheckList_pre_action::type_name = [%s]\n", checklist_type);fflush(stdout);
	if(tc_strcmp(checklist_type,"T5_NPRCheckList")==0 || tc_strcmp(checklist_type,"New Part Request CheckList")==0)
	{
		AOM_ask_value_string(item,"t5_BaseSubModule",&BaseSubModule);
		AOM_ask_value_string(item,"t5_BaseVCDesc",&BaseVCDesc);
		AOM_ask_value_string(item,"t5_BaseVCNum",&BaseVCNum);
		AOM_ask_value_string(item,"t5_Varity",&Varity);
		AOM_ask_value_string(item,"t5_NewSubModReqNum",&NewSubModReqNum);
		AOM_ask_value_string(item,"t5_VCDesc",&VCDesc);
		AOM_ask_value_string(item,"t5_VCNumber",&VCNumber);
		AOM_ask_value_string(item,"t5_Change",&Change);
		AOM_ask_value_string(item,"t5_SubModDes",&SubModDes);
		AOM_ask_value_string(item,"t5_Requirement",&Requirement);
		AOM_ask_value_string(item,"t5_CarryOver",&CarryOver);
		AOM_ask_value_string(item,"t5_ReplaceEliminate",&ReplaceEliminate);
		AOM_ask_value_string(item,"t5_VarLib",&VarLib);
		printf("\n **NewPartReq_CheckList_pre_action::BaseSubModule = [%s]\n", BaseSubModule);fflush(stdout);
		printf("\n **NewPartReq_CheckList_pre_action::BaseVCDesc = [%s]\n", BaseVCDesc);fflush(stdout);
		printf("\n **NewPartReq_CheckList_pre_action::BaseVCNum = [%s]\n", BaseVCNum);fflush(stdout);
		printf("\n **NewPartReq_CheckList_pre_action::Varity = [%s]\n", Varity);fflush(stdout);
		printf("\n **NewPartReq_CheckList_pre_action::NewSubModReqNum = [%s]\n", NewSubModReqNum);fflush(stdout);
		printf("\n **NewPartReq_CheckList_pre_action::VCDesc = [%s]\n", VCDesc);fflush(stdout);
		printf("\n **NewPartReq_CheckList_pre_action::VCNumber = [%s]\n", VCNumber);fflush(stdout);
		printf("\n **NewPartReq_CheckList_pre_action::Change = [%s]\n", Change);fflush(stdout);
		printf("\n **NewPartReq_CheckList_pre_action::SubModDes = [%s]\n", SubModDes);fflush(stdout);
		printf("\n **NewPartReq_CheckList_pre_action::Requirement = [%s]\n", Requirement);fflush(stdout);
		printf("\n **NewPartReq_CheckList_pre_action::CarryOver = [%s]\n", CarryOver);fflush(stdout);
		printf("\n **NewPartReq_CheckList_pre_action::ReplaceEliminate = [%s]\n", ReplaceEliminate);fflush(stdout);
		printf("\n **NewPartReq_CheckList_pre_action::VarLib = [%s]\n", VarLib);fflush(stdout);

		AOM_refresh( item, TRUE);
		if(tc_strlen(BaseSubModule)>0)AOM_set_value_string(item,"t5_BaseSubModule",BaseSubModule);
		if(tc_strlen(BaseVCDesc)>0)AOM_set_value_string(item,"t5_BaseVCDesc",BaseVCDesc);
		if(tc_strlen(BaseVCNum)>0)AOM_set_value_string(item,"t5_BaseVCNum",BaseVCNum);
		if(tc_strlen(Varity)>0)AOM_set_value_string(item,"t5_Varity",Varity);
		if(tc_strlen(NewSubModReqNum)>0)AOM_set_value_string(item,"t5_NewSubModReqNum",NewSubModReqNum);
		if(tc_strlen(VCDesc)>0)AOM_set_value_string(item,"t5_VCDesc",VCDesc);
		if(tc_strlen(VCNumber)>0)AOM_set_value_string(item,"t5_VCNumber",VCNumber);
		if(tc_strlen(Change)>0)AOM_set_value_string(item,"t5_Change",Change);
		if(tc_strlen(SubModDes)>0)AOM_set_value_string(item,"t5_SubModDes",SubModDes);
		if(tc_strlen(Requirement)>0)AOM_set_value_string(item,"t5_Requirement",Requirement);
		if(tc_strlen(CarryOver)>0)AOM_set_value_string(item,"t5_CarryOver",CarryOver);
		if(tc_strlen(ReplaceEliminate)>0)AOM_set_value_string(item,"t5_ReplaceEliminate",ReplaceEliminate);
		if(tc_strlen(VarLib)>0)AOM_set_value_string(item,"t5_VarLib",VarLib);
		AOM_save_without_extensions(item);
		AOM_refresh( item, FALSE);

		if(tc_strlen(BaseSubModule)==0
			|| tc_strlen(BaseVCDesc)==0
			|| tc_strlen(BaseVCNum)==0
			|| tc_strlen(Varity)==0
			|| tc_strlen(NewSubModReqNum)==0
			|| tc_strlen(VCDesc)==0
			|| tc_strlen(VCNumber)==0
			|| tc_strlen(Change)==0
			|| tc_strlen(SubModDes)==0
			|| tc_strlen(Requirement)==0
			|| tc_strlen(CarryOver)==0
			|| tc_strlen(ReplaceEliminate)==0
			|| tc_strlen(VarLib)==0)
		{
			ifail=t9NewPartReqCre_Val0025;
			EMH_store_error_s1(EMH_severity_error,ifail,"Please Fill All Fileds in New Part Request CheckList.It is mandatory to fill all properties on Check List!!");
			return ifail;
		}
	}
	

return ifail;
}

/****************************************************************************
Function:       NewPartReq_CheckList_post_action
Description:    This function used for register custom method/handler 
				on class for different action like pre/post.
				code lsit of an user.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
extern DLLAPI int NewPartReq_CheckList_post_action(METHOD_message_t *m, va_list args)
{
	int ifail=ITK_ok;
	tag_t item  = va_arg(args, tag_t);
	logical  isNew = va_arg(args, int);

	char *checklist_type=NULL;
	char *BaseSubModule=NULL;
	char *BaseVCDesc=NULL;
	char *BaseVCNum=NULL;
	char *Varity=NULL;
	char *NewSubModReqNum=NULL;
	char *VCDesc=NULL;
	char *VCNumber=NULL;
	char *Change=NULL;
	char *SubModDes=NULL;
	char *Requirement=NULL;
	char *CarryOver=NULL;
	char *ReplaceEliminate=NULL;
	char *VarLib=NULL;

	AOM_ask_value_string(item,"object_type",&checklist_type);
	printf("\n **NewPartReq_CheckList_post_action::type_name = [%s]\n", checklist_type);fflush(stdout);
	if(tc_strcmp(checklist_type,"T5_NPRCheckList")==0 || tc_strcmp(checklist_type,"New Part Request CheckList")==0)
	{
		AOM_ask_value_string(item,"t5_BaseSubModule",&BaseSubModule);
		AOM_ask_value_string(item,"t5_BaseVCDesc",&BaseVCDesc);
		AOM_ask_value_string(item,"t5_BaseVCNum",&BaseVCNum);
		AOM_ask_value_string(item,"t5_Varity",&Varity);
		AOM_ask_value_string(item,"t5_NewSubModReqNum",&NewSubModReqNum);
		AOM_ask_value_string(item,"t5_VCDesc",&VCDesc);
		AOM_ask_value_string(item,"t5_VCNumber",&VCNumber);
		AOM_ask_value_string(item,"t5_Change",&Change);
		AOM_ask_value_string(item,"t5_SubModDes",&SubModDes);
		AOM_ask_value_string(item,"t5_Requirement",&Requirement);
		AOM_ask_value_string(item,"t5_CarryOver",&CarryOver);
		AOM_ask_value_string(item,"t5_ReplaceEliminate",&ReplaceEliminate);
		AOM_ask_value_string(item,"t5_VarLib",&VarLib);
		printf("\n **NewPartReq_CheckList_post_action::BaseSubModule = [%s]\n", BaseSubModule);fflush(stdout);
		printf("\n **NewPartReq_CheckList_post_action::BaseVCDesc = [%s]\n", BaseVCDesc);fflush(stdout);
		printf("\n **NewPartReq_CheckList_post_action::BaseVCNum = [%s]\n", BaseVCNum);fflush(stdout);
		printf("\n **NewPartReq_CheckList_post_action::Varity = [%s]\n", Varity);fflush(stdout);
		printf("\n **NewPartReq_CheckList_post_action::NewSubModReqNum = [%s]\n", NewSubModReqNum);fflush(stdout);
		printf("\n **NewPartReq_CheckList_post_action::VCDesc = [%s]\n", VCDesc);fflush(stdout);
		printf("\n **NewPartReq_CheckList_post_action::VCNumber = [%s]\n", VCNumber);fflush(stdout);
		printf("\n **NewPartReq_CheckList_post_action::Change = [%s]\n", Change);fflush(stdout);
		printf("\n **NewPartReq_CheckList_post_action::SubModDes = [%s]\n", SubModDes);fflush(stdout);
		printf("\n **NewPartReq_CheckList_post_action::Requirement = [%s]\n", Requirement);fflush(stdout);
		printf("\n **NewPartReq_CheckList_post_action::CarryOver = [%s]\n", CarryOver);fflush(stdout);
		printf("\n **NewPartReq_CheckList_post_action::ReplaceEliminate = [%s]\n", ReplaceEliminate);fflush(stdout);
		printf("\n **NewPartReq_CheckList_post_action::VarLib = [%s]\n", VarLib);fflush(stdout);

		AOM_refresh( item, TRUE);
		if(tc_strlen(BaseSubModule)>0)AOM_set_value_string(item,"t5_BaseSubModule",BaseSubModule);
		if(tc_strlen(BaseVCDesc)>0)AOM_set_value_string(item,"t5_BaseVCDesc",BaseVCDesc);
		if(tc_strlen(BaseVCNum)>0)AOM_set_value_string(item,"t5_BaseVCNum",BaseVCNum);
		if(tc_strlen(Varity)>0)AOM_set_value_string(item,"t5_Varity",Varity);
		if(tc_strlen(NewSubModReqNum)>0)AOM_set_value_string(item,"t5_NewSubModReqNum",NewSubModReqNum);
		if(tc_strlen(VCDesc)>0)AOM_set_value_string(item,"t5_VCDesc",VCDesc);
		if(tc_strlen(VCNumber)>0)AOM_set_value_string(item,"t5_VCNumber",VCNumber);
		if(tc_strlen(Change)>0)AOM_set_value_string(item,"t5_Change",Change);
		if(tc_strlen(SubModDes)>0)AOM_set_value_string(item,"t5_SubModDes",SubModDes);
		if(tc_strlen(Requirement)>0)AOM_set_value_string(item,"t5_Requirement",Requirement);
		if(tc_strlen(CarryOver)>0)AOM_set_value_string(item,"t5_CarryOver",CarryOver);
		if(tc_strlen(ReplaceEliminate)>0)AOM_set_value_string(item,"t5_ReplaceEliminate",ReplaceEliminate);
		if(tc_strlen(VarLib)>0)AOM_set_value_string(item,"t5_VarLib",VarLib);
		AOM_save_without_extensions(item);
		AOM_refresh( item, FALSE);
	}
	

return ifail;
}

/****************************************************************************
Function:       NewPartReqItem_create_post_action
Description:    This function used for register custom method/handler 
				on class for different action like pre/post.
				code lsit of an user.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
extern DLLAPI int NewPartReqItem_create_post_action(METHOD_message_t *m, va_list args)
{

    int ifail=ITK_ok;	
    /***  va_list for TC_save_msg  ***/
    tag_t item  = va_arg(args, tag_t);
    logical  isNew = va_arg(args, int);
    //logical  isNew = va_arg(args, logical);
	
    /***********************************/


    char *item_type=NULL;
    char *itemId=NULL;
    char *prj_code=NULL;
    char *designgroup=NULL;
    char *designid=NULL;
    char *t5NwDgSbGrpDupS=NULL;
    char *t5NwDgSbGrpS=NULL;


	char *ootbitemId=NULL;

	char *Requestno=NULL;
    char *date=NULL;
    char *year=NULL;
    char *month=NULL;
    char *hour=NULL;
    char *min=NULL;
    char *sec=NULL;
    char *newpartreqnumber=NULL;


	tag_t	NewPrtReqTypeTag=NULLTAG;
	tag_t	NewPrtReqCreInTag=NULLTAG;
	tag_t	NewPrtReqTag=NULLTAG;
	tag_t	user_tag=NULLTAG;
	tag_t	latestitemrev=NULLTAG;
	tag_t	datasettype_any = NULLTAG;
	tag_t	Newdataset_any = NULLTAG;
	tag_t	filetag_any = NULLTAG;
	tag_t	tool_any = NULLTAG;
	tag_t	relation_type_any = NULLTAG;
	tag_t	relation_any = NULLTAG;
	tag_t	datasettype_vli = NULLTAG;
	tag_t	Newdataset_vli = NULLTAG;
	tag_t	filetag_vli = NULLTAG;
	tag_t	tool_vli = NULLTAG;
	tag_t	relation_type_vli = NULLTAG;
	tag_t	relation_vli = NULLTAG;
	tag_t	datasettype_three = NULLTAG;
	tag_t	Newdataset_three = NULLTAG;
	tag_t	filetag_three = NULLTAG;
	tag_t	tool_three = NULLTAG;
	tag_t	relation_type_three = NULLTAG;
	tag_t	relation_three = NULLTAG;

	char   *CategoryName=NULL;
	char   *ClsAtrCount=NULL;
	char   *DeptNwPrt=NULL;
	char   *inputIdsArr=NULL;
	char   *inputValusArr=NULL;
	char   *NwAggregate=NULL;
	char   *NwCeId=NULL;
	char   *NwChiefId=NULL;
	char   *NwCocId=NULL;
	char   *NwHeadEng=NULL;
	char   *NwLCState=NULL;
	char   *anyfileS=NULL;
	char   *NwPrtVli=NULL;
	char   *NwRaisedBy=NULL;
	char   *NwReason=NULL;
	char   *NwRefPtNo=NULL;
	char   *NwRqNumber=NULL;
	char   *NwThirdAttach=NULL;
	char   *NwTypChng=NULL;
	char   *NwVcNo=NULL;
	char   *NwVehicleMdl=NULL;
	char   *PartFamilyCls=NULL;
	char   *PartType=NULL;
	char   *any_type=NULL;
	char   *vli_type=NULL;
	char   *three_type=NULL;
	char   *suf1=NULL;
	char   *suf2=NULL;
	char   *suf3=NULL;
	char   *user_id=NULL;


	char           *ExtFirFile	= NULL;
	char           *SecExtFirFile	= NULL;
	char           *ThirdExtFirFile	= NULL;
	char           *tok	= NULL;
	char           *tok2	= NULL;
	char           *tok3	= NULL;
	char           *NewFileNameS_any	= NULL;
	char           *NewFileNameS_vli	= NULL;
	char           *NewFileNameS_three	= NULL;
	char           *any	= NULL;
	char           *vli	= NULL;
	char           *three	= NULL;
	char           *SubModuleAddress	= NULL;
	char *AggregateGrp=NULL;
    char *Aggregates=NULL;
    char *Module=NULL;
    char *SubModule=NULL;
    char *tempAggregateGrp=NULL;
    char *tempAggregates=NULL;
    char *tempModule=NULL;
    char *tempSubModule=NULL;
	char *AggregatesDup=NULL;
    char *ModuleDup=NULL;
    char *SubModuleDup=NULL;
    char *TempSubModuleAddress=NULL;
    char *PlateformDup=NULL;
    char *Plateform=NULL;
    char *NPRDRStatusDup=NULL;
    char *NPRDRStatus=NULL;
    char *NPRPartCategoryDup=NULL;
    char *NPRPartCategory=NULL;
    char *NPRStartPartProductDup=NULL;
    char *NPRStartPartProduct=NULL;
    char *IBDomesticDup=NULL;
    char *IBDomestic=NULL;
    char *ProductLineDup=NULL;
    char *ProductLine=NULL;
    char *ProposeTPLNumDup=NULL;
    char *ProposeTPLNum=NULL;

	logical			ExtPrtInd = false;
	logical			IsMirrorPaInd = false;
	logical			PrtCmoInd = false;
	logical			StdFldInd = false;
	logical			isFor12Digit = false;
	logical			isFor14Digit = false;
	logical			AlowCreSubMod = false;

	logical			checkout_any = 0;
	logical			checkout_vli = 0;
	logical			checkout_three = 0;
	logical			checkout_checklist = false;

	const char		*reason_any	= "";
	const char		*change_id_any	= "";
	const char		*dir_name_any = "";
	int				reservation_type_any = 2;

	const char		*reason_vli	= "";
	const char		*change_id_vli	= "";
	const char		*dir_name_vli = "";
	int				reservation_type_vli = 2;

	const char		*reason_three	= "";
	const char		*change_id_three	= "";
	const char		*dir_name_three = "";
	int				reservation_type_three = 2;

	const char		*reason_checklist	= "";
	const char		*change_id_checklist	= "";
	const char		*dir_name_checklist = "";
	int				reservation_type_checklist = 2;

	time_t now;
	struct tm *tm;

	int n_tags_found= 0;
	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};
    
	
	logical hasBypass=false;
	
	tag_t userSession=NULLTAG;
	tag_t *t_item1=NULLTAG;

    AOM_ask_value_string(item,"object_type",&item_type);
    printf("\n **NewPartReqItem_create_post_action::type_name = [%s]\n", item_type);fflush(stdout);
	POM_get_user_id(&user_id);
	SA_find_user2(user_id, &user_tag);
    if(tc_strcmp(item_type,"T5_NwPCre")==0)
	{
		CALLAPI(CE_current_user_session_tag(&userSession));
		CALLAPI(AOM_ask_value_logical(userSession,"fnd0bypassflag",&hasBypass));
		if(hasBypass==false)
		{
			printf("\nHAS By pass Flag is FALSE") ;fflush(stdout);
			if(isNew==true)
			{
				/*All Custom Validation Called Here !!!!!*/
				AOM_ask_value_string(item,"item_id",&itemId);
				printf("\n In NewPartReqItem_create_post_action In Message Code ::NewPartReq Item ID %s\n",itemId);fflush(stdout);

				AOM_ask_value_string(item,"item_id",&itemId);
				printf("\n In NewPartReqItem_create_post_action In Message Code ::NewPartReq Item ID %s\n",itemId);fflush(stdout);

				AOM_ask_value_string(item,"t5_ProjectCode",&prj_code);
				printf("\n NewPartReqItem_create_post_action:: prj_code====>[%s]", prj_code);fflush(stdout);

				AOM_ask_value_string(item,"t5_DesignGroup",&designgroup);
				printf("\n NewPartReqItem_create_post_action:: designgroup====>[%s]", designgroup);fflush(stdout);

				AOM_ask_value_string(item,"t5_DesignSubGrp",&t5NwDgSbGrpDupS);
				t5NwDgSbGrpS = strdup(t5NwDgSbGrpDupS);
				printf("\n NewPartReqItem_create_post_action:: t5NwDgSbGrpS====>[%s]", t5NwDgSbGrpS);fflush(stdout);

				AOM_ask_value_string(item,"t5_NwDgId",&designid);
				printf("\n NewPartReqItem_create_post_action:: designid====>[%s]", designid);fflush(stdout);

				AOM_ask_value_string(item,"t5_CategoryName",&CategoryName);
				printf("\n NewPartReqItem_create_post_action::CategoryName====>[%s]", CategoryName);fflush(stdout);

				AOM_ask_value_string(item,"t5_ClsAtrCount",&ClsAtrCount);
				printf("\n NewPartReqItem_create_post_action::ClsAtrCount====>[%s]", ClsAtrCount);fflush(stdout);

				AOM_ask_value_string(item,"t5_DeptNwPrt",&DeptNwPrt);
				printf("\n NewPartReqItem_create_post_action::DeptNwPrt====>[%s]", DeptNwPrt);fflush(stdout);

				AOM_ask_value_logical(item,"t5_ExtPrtInd",&ExtPrtInd);
				printf("\n NewPartReqItem_create_post_action::ExtPrtInd====>[%d]", ExtPrtInd);fflush(stdout);

				AOM_ask_value_string(item,"t5_inputIdsArr",&inputIdsArr);
				printf("\n NewPartReqItem_create_post_action::inputIdsArr====>[%s]", inputIdsArr);fflush(stdout);

				AOM_ask_value_string(item,"t5_inputValusArr",&inputValusArr);
				printf("\n NewPartReqItem_create_post_action::inputValusArr====>[%s]", inputValusArr);fflush(stdout);

				AOM_ask_value_logical(item,"t5_IsMirrorPaInd",&IsMirrorPaInd);
				printf("\n NewPartReqItem_create_post_action::IsMirrorPaInd====>[%d]", IsMirrorPaInd);fflush(stdout);

				AOM_ask_value_string(item,"t5_NwAggregate",&NwAggregate);
				printf("\n NewPartReqItem_create_post_action::NwAggregate====>[%s]", NwAggregate);fflush(stdout);

				AOM_ask_value_string(item,"t5_NwCeId",&NwCeId);
				printf("\n NewPartReqItem_create_post_action::NwCeId====>[%s]", NwCeId);fflush(stdout);

				AOM_ask_value_string(item,"t5_NwChiefId",&NwChiefId);
				printf("\n NewPartReqItem_create_post_action::NwChiefId====>[%s]", NwChiefId);fflush(stdout);

				AOM_ask_value_string(item,"t5_NwCocId",&NwCocId);
				printf("\n NewPartReqItem_create_post_action::NwCocId====>[%s]", NwCocId);fflush(stdout);

				AOM_ask_value_string(item,"t5_NwHeadEng",&NwHeadEng);
				printf("\n NewPartReqItem_create_post_action::NwHeadEng====>[%s]", NwHeadEng);fflush(stdout);

				AOM_ask_value_string(item,"t5_NwLCState",&NwLCState);
				printf("\n NewPartReqItem_create_post_action::NwLCState====>[%s]", NwLCState);fflush(stdout);

				AOM_ask_value_string(item,"t5_NwPrtAny",&anyfileS);
				printf("\n NewPartReqItem_create_post_action::anyfileS====>[%s]", anyfileS);fflush(stdout);
				
				AOM_ask_value_string(item,"t5_NwPrtVli",&NwPrtVli);
				printf("\n NewPartReqItem_create_post_action::NwPrtVli====>[%s]", NwPrtVli);fflush(stdout);

				AOM_ask_value_string(item,"t5_NwRaisedBy",&NwRaisedBy);
				printf("\n NewPartReqItem_create_post_action::NwRaisedBy====>[%s]", NwRaisedBy);fflush(stdout);

				AOM_ask_value_string(item,"t5_NwReason",&NwReason);
				printf("\n NewPartReqItem_create_post_action::NwReason====>[%s]", NwReason);fflush(stdout);

				AOM_ask_value_string(item,"t5_NwRefPtNo",&NwRefPtNo);
				printf("\n NewPartReqItem_create_post_action::NwRefPtNo====>[%s]", NwRefPtNo);fflush(stdout);

				AOM_ask_value_string(item,"t5_NwRqNumber",&NwRqNumber);
				printf("\n NewPartReqItem_create_post_action::NwRqNumber====>[%s]", NwRqNumber);fflush(stdout);

				AOM_ask_value_string(item,"t5_NwThirdAttach",&NwThirdAttach);
				printf("\n NewPartReqItem_create_post_action::NwThirdAttach====>[%s]", NwThirdAttach);fflush(stdout);

				AOM_ask_value_string(item,"t5_NwTypChng",&NwTypChng);
				printf("\n NewPartReqItem_create_post_action::NwTypChng====>[%s]", NwTypChng);fflush(stdout);

				AOM_ask_value_string(item,"t5_NwVcNo",&NwVcNo);
				printf("\n NewPartReqItem_create_post_action::NwVcNo====>[%s]", NwVcNo);fflush(stdout);
				
				AOM_ask_value_string(item,"t5_NwVehicleMdl",&NwVehicleMdl);
				printf("\n NewPartReqItem_create_post_action::NwVehicleMdl====>[%s]", NwVehicleMdl);fflush(stdout);

				AOM_ask_value_string(item,"t5_PartFamilyCls",&PartFamilyCls);
				printf("\n NewPartReqItem_create_post_action::PartFamilyCls====>[%s]", PartFamilyCls);fflush(stdout);
				
				AOM_ask_value_string(item,"t5_PartType",&PartType);
				printf("\n NewPartReqItem_create_post_action::PartType====>[%s]", PartType);fflush(stdout);

				AOM_ask_value_logical(item,"t5_PrtCmoInd",&PrtCmoInd);
				printf("\n NewPartReqItem_create_post_action::PrtCmoInd====>[%d]", PrtCmoInd);fflush(stdout);

				AOM_ask_value_logical(item,"t5_StdFldInd",&StdFldInd);
				printf("\n NewPartReqItem_create_post_action::StdFldInd====>[%d]", StdFldInd);fflush(stdout);

				AOM_ask_value_logical(item,"t5_AlowCreSubMod",&AlowCreSubMod);
				AOM_ask_value_string(item,"t5_Plateform",&Plateform);
				AOM_ask_value_string(item,"t5_DRStatus",&NPRDRStatus);
				NPRDRStatusDup = strdup(NPRDRStatus);
				printf("\n NewPartReqItem_create_post_action:: NPRDRStatusDup====>[%s]", NPRDRStatusDup);fflush(stdout);

				AOM_ask_value_string(item,"t5_PartCategory",&NPRPartCategory);
				NPRPartCategoryDup = strdup(NPRPartCategory);
				printf("\n NewPartReqItem_create_post_action:: NPRPartCategoryDup====>[%s]", NPRPartCategoryDup);fflush(stdout);

				AOM_ask_value_string(item,"t5_StartPartProduct",&NPRStartPartProduct);
				NPRStartPartProductDup = strdup(NPRStartPartProduct);
				printf("\n NewPartReqItem_create_post_action:: NPRStartPartProductDup====>[%s]", NPRStartPartProductDup);fflush(stdout);
				PlateformDup = strdup(Plateform);
				printf("\n NewPartReqItem_create_post_action:: PlateformDup====>[%s]", PlateformDup);fflush(stdout);

				AOM_ask_value_logical(item,"t5_Is12Digit",&isFor12Digit);
				printf("\n NewPartReqItem_create_post_action::isFor12Digit====>[%d]", isFor12Digit);fflush(stdout);

				AOM_ask_value_logical(item,"t5_Is14Digit",&isFor14Digit);
				printf("\n NewPartReqItem_create_post_action::isFor14Digit====>[%d]", isFor14Digit);fflush(stdout);

				AOM_ask_value_string(item,"t5_IBDomestic",&IBDomestic);
				IBDomesticDup = strdup(IBDomestic);
				printf("\n NewPartReqItem_create_post_action:: IBDomesticDup====>[%s]", IBDomesticDup);fflush(stdout);

				AOM_ask_value_string(item,"t5_ProductLine",&ProductLine);
				ProductLineDup = strdup(ProductLine);
				printf("\n NewPartReqItem_create_post_action:: ProductLineDup====>[%s]", ProductLineDup);fflush(stdout);

				AOM_ask_value_string(item,"t5_ProposeTPLNum",&ProposeTPLNum);
				ProposeTPLNumDup = strdup(ProposeTPLNum);
				printf("\n NewPartReqItem_create_post_action:: ProposeTPLNumDup====>[%s]", ProposeTPLNumDup);fflush(stdout);

				//AOM_ask_value_string(item,"t5_ModuleAddress",&SubModuleAddress);
				//printf("\n In NewPartReqItem_create_post_action:: SubModuleAddress %s\n",SubModuleAddress);fflush(stdout);

				if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
				{
				
				SubModuleAddress = (char *) MEM_alloc( 200 * sizeof(char) );
				AOM_ask_value_string(item,"t5_AggregateGrp",&AggregateGrp);
				printf("\n In NewPartReqItem_create_post_action In Message Code ::NewPartReq AggregateGrp %s\n",AggregateGrp);fflush(stdout);
				
				tempAggregateGrp = (char *) MEM_alloc(2 * sizeof(char) );
				tempAggregateGrp= NewPartsubString(AggregateGrp,0,1);
				printf("\n In NewPartReqItem_create_post_action In Message Code ::NewPartReq tempAggregateGrp %s\n",tempAggregateGrp);fflush(stdout);

				AOM_ask_value_string(item,"t5_Aggregates",&Aggregates);
				AggregatesDup = strdup(Aggregates);
				printf("\n In NewPartReqItem_create_post_action In Message Code ::NewPartReq Aggregates %s\n",Aggregates);fflush(stdout);
				tempAggregates = strtok(Aggregates, "-");

				
				AOM_ask_value_string(item,"t5_Module",&Module);
				ModuleDup = strdup(Module);
				printf("\n In NewPartReqItem_create_post_action In Message Code ::NewPartReq Module %s\n",Module);fflush(stdout);
				tempModule = strtok(Module, "-");

				AOM_ask_value_string(item,"t5_SubModule",&SubModule);
				SubModuleDup = strdup(SubModule);
				printf("\n In NewPartReqItem_create_post_action In Message Code ::NewPartReq SubModule %s\n",SubModule);fflush(stdout);
				tempSubModule = strtok(SubModule, "-");

				tc_strcpy(SubModuleAddress,tempAggregateGrp);
				tc_strcat(SubModuleAddress,tempAggregates);
				tc_strcat(SubModuleAddress,tempModule);
				tc_strcat(SubModuleAddress,tempSubModule);
				printf("\n In NewPartReqItem_create_post_action In Message Code ::NewPartReq SubModuleAddress %s\n",SubModuleAddress);fflush(stdout);
				}

				values[0] = itemId;
				values[1] = "T5_NwPCre";
				//values[1] = "New Part Request";
				ITEM_find_items_by_key_attributes(2, attrs, values, &n_tags_found, &t_item1);
				printf("\n NewPartReqItem_create_post_action:: n_tags_found==>%d",n_tags_found);fflush(stdout);
				if(n_tags_found>0 || n_tags_found==0)
				{
					now = time(0);
					printf("\n 11111111");fflush(stdout);
					if ((tm = localtime (&now)) == NULL) {printf ("Error extracting time \n");fflush(stdout);}
					Requestno = (char *) MEM_alloc( 100 * sizeof(char) );
					year = (char *) MEM_alloc( 10 * sizeof(char) );
					month = (char *) MEM_alloc( 10 * sizeof(char) );
					date = (char *) MEM_alloc( 10 * sizeof(char) );
					hour = (char *) MEM_alloc( 10 * sizeof(char) );
					min = (char *) MEM_alloc( 10 * sizeof(char) );
					sec = (char *) MEM_alloc( 10 * sizeof(char) );
	
					   
					sprintf(year,"%d",tm->tm_year+1900-2000);
					sprintf(month,"%d",tm->tm_mon+1);
					sprintf(date,"%d",tm->tm_mday);
					sprintf(hour,"%d",tm->tm_hour);
					sprintf(min,"%d",tm->tm_min);
					sprintf(sec,"%d",tm->tm_sec);

					printf("\n year->%s",year);fflush(stdout);
					printf("\n month->%s",month);fflush(stdout);
					printf("\n date->%s",date);fflush(stdout);
					printf("\n hour->%s",hour);fflush(stdout);
					printf("\n min->%s",min);fflush(stdout);
					printf("\n sec->%s",sec);fflush(stdout);

					//if(isFor12Digit==true)
					if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
					{
						strcpy(Requestno,prj_code);
						strcat(Requestno,designgroup);
						strcat(Requestno,t5NwDgSbGrpS);
						strcat(Requestno,designid);
						strcat(Requestno,"_");
						if(strlen(date) < 2) strcat(Requestno,"0");
						strcat(Requestno,date);
						if(strlen(month) < 2) strcat(Requestno,"0");
						strcat(Requestno,month);
						strcat(Requestno,year);
						strcat(Requestno,"_");
						if(strlen(hour) < 2) strcat(Requestno,"0");	
						strcat(Requestno,hour);
						if(strlen(min) < 2) strcat(Requestno,"0");
						strcat(Requestno,min);
						if(strlen(sec) < 2) strcat(Requestno,"0");
						strcat(Requestno,sec);
					}
					//if(isFor14Digit==true)
					if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
					{
						strcpy(Requestno,prj_code);
						strcat(Requestno,SubModuleAddress);
						strcat(Requestno,designgroup);
						strcat(Requestno,"_");
						if(strlen(date) < 2) strcat(Requestno,"0");
						strcat(Requestno,date);
						if(strlen(month) < 2) strcat(Requestno,"0");
						strcat(Requestno,month);
						strcat(Requestno,year);
						strcat(Requestno,"_");
						if(strlen(hour) < 2) strcat(Requestno,"0");	
						strcat(Requestno,hour);
						if(strlen(min) < 2) strcat(Requestno,"0");
						strcat(Requestno,min);
						if(strlen(sec) < 2) strcat(Requestno,"0");
						strcat(Requestno,sec);

					}
					if(tc_strcmp(PartType,"Technical Part List")==0 || tc_strcmp(PartType,"T")==0)
					{
						strcpy(Requestno,ProposeTPLNumDup);
						strcat(Requestno,"_");
						if(strlen(date) < 2) strcat(Requestno,"0");
						strcat(Requestno,date);
						if(strlen(month) < 2) strcat(Requestno,"0");
						strcat(Requestno,month);
						strcat(Requestno,year);
						strcat(Requestno,"_");
						if(strlen(hour) < 2) strcat(Requestno,"0");	
						strcat(Requestno,hour);
						if(strlen(min) < 2) strcat(Requestno,"0");
						strcat(Requestno,min);
						if(strlen(sec) < 2) strcat(Requestno,"0");
						strcat(Requestno,sec);

					}
					
					printf(" #######NewPartReqItem_create_post_action::Request No created with name (%s)########\n",Requestno);fflush(stdout);
					

					if(strlen(Requestno)>0)
					{
						AOM_refresh( item, TRUE);
						AOM_set_value_string(item, "object_name", Requestno);
						AOM_set_value_string(item,"item_id",Requestno);
						AOM_set_value_string(item,"object_desc",Requestno);

						//AOM_refresh( item, TRUE);
						AOM_set_value_string(item,"t5_ProjectCode",prj_code);
						AOM_set_value_string(item,"t5_DesignGroup",designgroup);
						AOM_set_value_string(item,"t5_DesignSubGrp",t5NwDgSbGrpDupS);
						AOM_set_value_string(item,"t5_NwDgId",designid);
						AOM_set_value_string(item,"t5_CategoryName",CategoryName);
						AOM_set_value_string(item,"t5_ClsAtrCount",ClsAtrCount);
						AOM_set_value_string(item,"t5_DeptNwPrt",DeptNwPrt);
						AOM_set_value_logical(item,"t5_ExtPrtInd",ExtPrtInd);
						AOM_set_value_string(item,"t5_inputIdsArr",inputIdsArr);
						AOM_set_value_string(item,"t5_inputValusArr",inputValusArr);
						AOM_set_value_logical(item,"t5_IsMirrorPaInd",IsMirrorPaInd);
						AOM_set_value_string(item,"t5_NwAggregate",NwAggregate);
						AOM_set_value_string(item,"t5_NwCeId",NwCeId);
						AOM_set_value_string(item,"t5_NwChiefId",NwChiefId);
						AOM_set_value_string(item,"t5_NwCocId",NwCocId);
						AOM_set_value_string(item,"t5_NwHeadEng",NwHeadEng);
						AOM_set_value_string(item,"t5_NwLCState","LcsNwCre");
						AOM_set_value_string(item,"t5_NwPrtAny",anyfileS);
						AOM_set_value_string(item,"t5_NwPrtVli",NwPrtVli);
						AOM_set_value_string(item,"t5_NwRaisedBy",user_id);
						AOM_set_value_string(item,"t5_NwReason",NwReason);
						AOM_set_value_string(item,"t5_NwRefPtNo",NwRefPtNo);
						AOM_set_value_string(item,"t5_NwRqNumber",Requestno);
						AOM_set_value_string(item,"t5_NwThirdAttach",NwThirdAttach);
						AOM_set_value_string(item,"t5_NwTypChng",NwTypChng);
						AOM_set_value_string(item,"t5_NwVcNo",NwVcNo);
						AOM_set_value_string(item,"t5_NwVehicleMdl",NwVehicleMdl);
						AOM_set_value_string(item,"t5_PartFamilyCls",PartFamilyCls);
						AOM_set_value_string(item,"t5_PartType",PartType);
						AOM_set_value_logical(item,"t5_PrtCmoInd",PrtCmoInd);
						AOM_set_value_logical(item,"t5_StdFldInd",StdFldInd);
						//AOM_set_value_string(item,"t5_AggregateGrp",AggregateGrp);
						//AOM_set_value_string(item,"t5_Aggregates",Aggregates);
						//AOM_set_value_string(item,"t5_Module",Module);
						//AOM_set_value_string(item,"t5_SubModule",SubModule);
						//AOM_set_value_string(item,"t5_ModuleAddress",SubModuleAddress);
						AOM_set_value_logical(item,"t5_AlowCreSubMod",AlowCreSubMod);
						AOM_set_value_string(item,"t5_DRStatus",NPRDRStatusDup);
						AOM_set_value_string(item,"t5_PartCategory",NPRPartCategoryDup);
						AOM_set_value_string(item,"t5_StartPartProduct",NPRStartPartProductDup);
						AOM_set_value_string(item,"t5_SignOffCountRaiser","0");
						//AOM_set_value_logical(item,"t5_Is12Digit",isFor12Digit);
						//AOM_set_value_logical(item,"t5_Is14Digit",isFor14Digit);
						if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
						{						
							AOM_set_value_string(item,"t5_AggregateGrp",AggregateGrp);
							AOM_set_value_string(item,"t5_Aggregates",AggregatesDup);
							AOM_set_value_string(item,"t5_Module",ModuleDup);
							AOM_set_value_string(item,"t5_SubModule",SubModuleDup);
							AOM_set_value_string(item,"t5_Plateform",Plateform);
							TempSubModuleAddress = (char *) MEM_alloc( 20 * sizeof(char) );
							tc_strcpy(TempSubModuleAddress,"M");
							tc_strcat(TempSubModuleAddress,SubModuleAddress);
							AOM_set_value_string(item,"t5_ModuleAddress",SubModuleAddress);
							AOM_set_value_string(item,"t5_IBDomestic",IBDomesticDup);
							AOM_set_value_string(item,"t5_ProductLine",ProductLineDup);
						}
						//AOM_save(item);
						char *TempPart_Type = NULL;
						AOM_ask_value_string(item,"t5_PartType",&TempPart_Type);
						printf("\n NewPartReqItem_create_post_action::Value of TempPart_Type    ------->[%s]\n ",TempPart_Type);fflush(stdout);
						printf("\n NewPartReqItem_create_post_action::Before AOM_save_without_extensions\n");fflush(stdout);
						AOM_save_without_extensions(item);
						printf("\n NewPartReqItem_create_post_action::After AOM_save_without_extensions\n");fflush(stdout);
						printf("\n NewPartReqItem_create_post_action::Before AOM_refresh\n");fflush(stdout);
						AOM_refresh(item,FALSE);
						printf("\n NewPartReqItem_create_post_action::After AOM_refresh\n");fflush(stdout);

						AOM_ask_value_string(item,"object_name",&newpartreqnumber);
						printf(" ####### NewPartReqItem_create_post_action::newpartreqnumber No created with name--->[%s]\n",newpartreqnumber);fflush(stdout);
						AOM_ask_value_string(item,"item_id",&ootbitemId);
						printf(" ####### NewPartReqItem_create_post_action::ootbitemId No created with name--->[%s]\n",ootbitemId);fflush(stdout);
						/*Start Revison Item ID and File Creation...*/
						if(ITEM_ask_latest_rev(item,&latestitemrev));
						if(latestitemrev!=NULLTAG)
						{
							//AOM_refresh( latestitemrev, TRUE);
							AOM_set_value_string(latestitemrev,"item_id",Requestno);
							AOM_set_value_string(latestitemrev,"object_desc",Requestno);
							//AOM_save(latestitemrev);
							//AOM_save_without_extensions(latestitemrev);
							//AOM_refresh(latestitemrev,FALSE);

							if(anyfileS!=NULL && strlen(anyfileS)>0)
							{
								suf1 = strdup(anyfileS);
								printf("\n Value of suf1    ------->[%s]\n ",suf1);fflush(stdout);
								if(strcmp(suf1,"NA")!= 0)
								{	
									tok = strtok(suf1, ".");
									printf("\n After tok suf1 value  ------->[%s]\n ",tok);fflush(stdout);
									tok = strtok(NULL, ".");
									ExtFirFile= tok; 
									
								}
								if(strcasecmp(ExtFirFile,"txt") == 0)
								{
									any="Text";
									any_type = "Text";
								}

								
								if(strcasecmp(ExtFirFile,"jpg") == 0)
								{
									any="JPEG_Reference";
									any_type = "JPEG";
								}

								if(strcasecmp(ExtFirFile,"png") == 0)
								{
									any="JPEG_Reference";
									any_type = "JPEG";
								}

								if(strcasecmp(ExtFirFile,"xls") == 0)
								{
									any = "excel";
									any_type = "MSExcel";
								}

								if(strcasecmp(ExtFirFile,"doc") == 0)
								{
									any = "word";
									any_type = "MSWord";
								}

								if(strcasecmp(ExtFirFile,"pdf") == 0)
								{
									any = "PDF_Reference";
									any_type = "PDF";
								}

								if(strcasecmp(ExtFirFile,"ppt") == 0)
								{
									any = "powerpoint";
									any_type = "MSPowePoint";
								}

								if(strcasecmp(ExtFirFile,"pptx") == 0)
								{
									any = "powerpoint";
									any_type = "MSPowePointX";
								}

								if(strcasecmp(ExtFirFile,"docx") == 0)
								{
									any = "word";
									any_type = "MSWordX";
								}

								if(strcasecmp(ExtFirFile,"xlsx") == 0)
								{
									any = "excel";
									any_type = "MSExcelX";
								}

								if(strcasecmp(ExtFirFile,"jpeg") == 0)
								{
									any = "JPEG_Reference";
									any_type = "JPEG";
								}

								if(strcasecmp(ExtFirFile,"bmp") == 0)
								{
									any = "JPEG_Reference";
									any_type = "JPEG";
								}
								
								if(strcasecmp(ExtFirFile,"msg") == 0)
								{
									any = "Outlook-Msg";
									any_type = "Outlook";
								}


								printf("\n Extension of First File is  ------->[%s]\n ",ExtFirFile);fflush(stdout);
								NewFileNameS_any = (char *) MEM_alloc( 100 * sizeof(char) );
								strcpy(NewFileNameS_any,Requestno);
								//strcat(NewFileNameS_any,"_1.");
								strcat(NewFileNameS_any,"_");
								printf("\n anyfileS    ------->[%s]\n ",anyfileS);fflush(stdout);
								strcat(NewFileNameS_any,anyfileS);
								//strcat(NewFileNameS_any,ExtFirFile);
								printf(" #######Attachment 1  (%s)########\n",NewFileNameS_any);fflush(stdout);
								//AE_find_datasettype(any_type, &datasettype_any);
								AE_find_datasettype2(any_type, &datasettype_any);
								AE_create_dataset_with_id(datasettype_any,NewFileNameS_any,NewFileNameS_any, NULL, NULL, &Newdataset_any);
								//AE_set_dataset_format(Newdataset_any, "BINARY_REF");
								AE_set_dataset_format2(Newdataset_any, "BINARY_REF");
								AE_ask_datasettype_def_tool(datasettype_any, &tool_any);
								AE_set_dataset_tool(Newdataset_any,tool_any);
								//AOM_save(Newdataset_any);
								AOM_refresh( Newdataset_any, TRUE);
								AOM_save_without_extensions(Newdataset_any);
								AOM_refresh(Newdataset_any,FALSE);
								
								if(latestitemrev!=NULLTAG && Newdataset_any!=NULLTAG)
								{
									RES_is_checked_out(Newdataset_any,&checkout_any);
									if (checkout_any==0)
									{
										RES_checkout2(Newdataset_any,reason_any,change_id_any,dir_name_any,reservation_type_any);
										printf("\n DataSet Checked Out \n");fflush(stdout);
									}
									GRM_find_relation_type("IMAN_specification", &relation_type_any);
									GRM_create_relation(latestitemrev, Newdataset_any, relation_type_any, NULLTAG, &relation_any);
									GRM_save_relation(relation_any);
								}
								
							}

							if(NwPrtVli!=NULL && strlen(NwPrtVli)>0)
							{
								suf2 = strdup(NwPrtVli);
								printf("\n Value of suf2    ------->[%s]\n ",suf2);
								if(strcmp(suf2,"NA")!= 0)
								{	
									tok2 = strtok(suf2, ".");
									printf("\n After tok suf2 value  ------->[%s]\n ",tok2);fflush(stdout);
									tok2 = strtok(NULL, ".");
									SecExtFirFile= tok2; 
									
								}
								if(strcasecmp(SecExtFirFile,"txt") == 0)
								{
									vli="Text";
									vli_type = "Text";
								}

								
								if(strcasecmp(SecExtFirFile,"jpg") == 0)
								{
									any="JPEG_Reference";
									vli_type = "JPEG";
								}

								if(strcasecmp(SecExtFirFile,"png") == 0)
								{
									vli="JPEG_Reference";
									vli_type = "JPEG";
								}

								if(strcasecmp(SecExtFirFile,"xls") == 0)
								{
									vli = "excel";
									vli_type = "MSExcel";
								}

								if(strcasecmp(SecExtFirFile,"doc") == 0)
								{
									vli = "word";
									vli_type = "MSWord";
								}

								if(strcasecmp(SecExtFirFile,"pdf") == 0)
								{
									vli = "PDF_Reference";
									vli_type = "PDF";
								}

								if(strcasecmp(SecExtFirFile,"ppt") == 0)
								{
									vli = "powerpoint";
									vli_type = "MSPowePoint";
								}

								if(strcasecmp(SecExtFirFile,"pptx") == 0)
								{
									vli = "powerpoint";
									vli_type = "MSPowePointX";
								}

								if(strcasecmp(SecExtFirFile,"docx") == 0)
								{
									vli = "word";
									vli_type = "MSWordX";
								}

								if(strcasecmp(SecExtFirFile,"xlsx") == 0)
								{
									vli = "excel";
									vli_type = "MSExcelX";
								}

								if(strcasecmp(SecExtFirFile,"jpeg") == 0)
								{
									vli = "JPEG_Reference";
									vli_type = "JPEG";
								}

								if(strcasecmp(SecExtFirFile,"bmp") == 0)
								{
									vli = "JPEG_Reference";
									vli_type = "JPEG";
								}
								
								if(strcasecmp(SecExtFirFile,"msg") == 0)
								{
									vli = "Outlook-Msg";
									vli_type = "Outlook";
								}


								printf("\n Extension of First File is  ------->[%s]\n ",SecExtFirFile);fflush(stdout);
								NewFileNameS_vli = (char *) MEM_alloc( 100 * sizeof(char) );
								strcpy(NewFileNameS_vli,Requestno);
								//strcat(NewFileNameS_vli,"_2.");
								strcat(NewFileNameS_vli,"_");
								printf("\n NwPrtVli    ------->[%s]\n ",NwPrtVli);fflush(stdout);
								strcat(NewFileNameS_vli,NwPrtVli);
								//strcat(NewFileNameS_vli,SecExtFirFile);
								printf(" #######Attachment 1  (%s)########\n",NewFileNameS_vli);fflush(stdout);
								//AE_find_datasettype(vli_type, &datasettype_vli);
								AE_find_datasettype2(vli_type, &datasettype_vli);
								AE_create_dataset_with_id(datasettype_vli,NewFileNameS_vli,NewFileNameS_vli, NULL, NULL, &Newdataset_vli);
								//AE_set_dataset_format(Newdataset_vli, "BINARY_REF");
								AE_set_dataset_format2(Newdataset_vli, "BINARY_REF");
								AE_ask_datasettype_def_tool(datasettype_vli, &tool_vli);
								AE_set_dataset_tool(Newdataset_vli,tool_vli);
								//AOM_save(Newdataset_vli);
								AOM_refresh( Newdataset_vli, TRUE);
								AOM_save_without_extensions(Newdataset_vli);
								AOM_refresh(Newdataset_vli,FALSE);
								
								if(latestitemrev!=NULLTAG && Newdataset_vli!=NULLTAG)
								{
									RES_is_checked_out(Newdataset_vli,&checkout_vli);
									if (checkout_vli==0)
									{
										RES_checkout2(Newdataset_vli,reason_vli,change_id_vli,dir_name_vli,reservation_type_vli);
										printf("\n DataSet Checked Out \n");fflush(stdout);
									}
									GRM_find_relation_type("IMAN_specification", &relation_type_vli);
									GRM_create_relation(latestitemrev, Newdataset_vli, relation_type_vli, NULLTAG, &relation_vli);
									GRM_save_relation(relation_vli);
								}
								
							}

							if(NwThirdAttach!=NULL && strlen(NwThirdAttach)>0)
							{
								suf3 = strdup(NwThirdAttach);
								printf("\n Value of suf1    ------->[%s]\n ",suf3);
								if(strcmp(suf3,"NA")!= 0)
								{	
									tok3 = strtok(suf3, ".");
									printf("\n After tok suf2 value  ------->[%s]\n ",tok3);fflush(stdout);
									tok3 = strtok(NULL, ".");
									ThirdExtFirFile= tok3; 
									
								}
								if(strcasecmp(ThirdExtFirFile,"txt") == 0)
								{
									vli="Text";
									three_type = "Text";
								}

								
								if(strcasecmp(ThirdExtFirFile,"jpg") == 0)
								{
									any="JPEG_Reference";
									three_type = "JPEG";
								}

								if(strcasecmp(ThirdExtFirFile,"png") == 0)
								{
									three="JPEG_Reference";
									three_type = "JPEG";
								}

								if(strcasecmp(ThirdExtFirFile,"xls") == 0)
								{
									three = "excel";
									three_type = "MSExcel";
								}

								if(strcasecmp(ThirdExtFirFile,"doc") == 0)
								{
									three = "word";
									three_type = "MSWord";
								}

								if(strcasecmp(ThirdExtFirFile,"pdf") == 0)
								{
									three = "PDF_Reference";
									three_type = "PDF";
								}

								if(strcasecmp(ThirdExtFirFile,"ppt") == 0)
								{
									three = "powerpoint";
									three_type = "MSPowePoint";
								}

								if(strcasecmp(ThirdExtFirFile,"pptx") == 0)
								{
									three = "powerpoint";
									three_type = "MSPowePointX";
								}

								if(strcasecmp(ThirdExtFirFile,"docx") == 0)
								{
									three = "word";
									three_type = "MSWordX";
								}

								if(strcasecmp(ThirdExtFirFile,"xlsx") == 0)
								{
									three = "excel";
									three_type = "MSExcelX";
								}

								if(strcasecmp(ThirdExtFirFile,"jpeg") == 0)
								{
									three = "JPEG_Reference";
									three_type = "JPEG";
								}

								if(strcasecmp(ThirdExtFirFile,"bmp") == 0)
								{
									three = "JPEG_Reference";
									three_type = "JPEG";
								}
								
								if(strcasecmp(ThirdExtFirFile,"msg") == 0)
								{
									three = "Outlook-Msg";
									three_type = "Outlook";
								}


								printf("\n Extension of First File is  ------->[%s]\n ",ThirdExtFirFile);fflush(stdout);
								NewFileNameS_three = (char *) MEM_alloc( 100 * sizeof(char) );
								strcpy(NewFileNameS_three,Requestno);
								//strcat(NewFileNameS_three,"_3.");
								strcat(NewFileNameS_three,"_");
								printf("\n NwThirdAttach    ------->[%s]\n ",NwThirdAttach);fflush(stdout);
								strcat(NewFileNameS_three,NwThirdAttach);
								//strcat(NewFileNameS_three,ThirdExtFirFile);
								printf(" #######Attachment 1  (%s)########\n",NewFileNameS_three);fflush(stdout);
								//AE_find_datasettype(three_type, &datasettype_three);
								AE_find_datasettype2(three_type, &datasettype_three);
								AE_create_dataset_with_id(datasettype_three,NewFileNameS_three,NewFileNameS_three, NULL, NULL, &Newdataset_three);
								//AE_set_dataset_format(Newdataset_three, "BINARY_REF");
								AE_set_dataset_format2(Newdataset_three, "BINARY_REF");
								AE_ask_datasettype_def_tool(datasettype_three, &tool_three);
								AE_set_dataset_tool(Newdataset_three,tool_three);
								//AOM_save(Newdataset_three);
								AOM_refresh( Newdataset_three, TRUE);
								AOM_save_without_extensions(Newdataset_three);
								AOM_refresh(Newdataset_three,FALSE);
								
								if(latestitemrev!=NULLTAG && Newdataset_three!=NULLTAG)
								{
									RES_is_checked_out(Newdataset_three,&checkout_three);
									if (checkout_three==0)
									{
										RES_checkout2(Newdataset_three,reason_three,change_id_three,dir_name_three,reservation_type_three);
										printf("\n DataSet Checked Out \n");fflush(stdout);
									}
									GRM_find_relation_type("IMAN_specification", &relation_type_three);
									GRM_create_relation(latestitemrev, Newdataset_three, relation_type_three, NULLTAG, &relation_three);
									GRM_save_relation(relation_three);
								}
								
							}
						}
						/*End Revison Item ID and File Creation...*/
						/*START FOR NPR CHECKLIST*/
						if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
						{
							tag_t	NPRChkLstTag		= NULLTAG;
							tag_t	NPRChkLstCreInTag	= NULLTAG;
							tag_t	NePartReqChkListTag	= NULLTAG;
							tag_t	creltypetag			= NULLTAG;
							tag_t	rel_tag				= NULLTAG;
							//char   NPR_ChkList_type[TCTYPE_name_size_c+1];

							char   *NPRChkListName=NULL;
							char   *NPR_ChkList_type=NULL;
							NPRChkListName = (char *) MEM_alloc( 100 * sizeof(char) );
							tc_strcpy(NPRChkListName,Requestno);
							tc_strcat(NPRChkListName,"_CheckList");
							TCTYPE_find_type("T5_NPRCheckList", "T5_NPRCheckList", &NPRChkLstTag);
							TCTYPE_ask_name2(NPRChkLstTag,&NPR_ChkList_type);
							printf("\n NPR_ChkList_type [%s]*******",NPR_ChkList_type);fflush(stdout);
							TCTYPE_construct_create_input(NPRChkLstTag,&NPRChkLstCreInTag);
							AOM_set_value_string(NPRChkLstCreInTag, "object_name", NPRChkListName);
							AOM_set_value_string(NPRChkLstCreInTag, "object_desc", NPRChkListName);
							TCTYPE_create_object(NPRChkLstCreInTag, &NePartReqChkListTag);
							//AOM_save(NePartReqChkListTag);
							AOM_save_without_extensions(NePartReqChkListTag);

							GRM_find_relation_type("IMAN_reference",&creltypetag);
							if(item!=NULLTAG && NePartReqChkListTag!=NULLTAG && creltypetag!=NULLTAG)
							{
								RES_is_checked_out(NePartReqChkListTag,&checkout_checklist);
								if (checkout_checklist==0)
								{
									RES_checkout2(NePartReqChkListTag,reason_checklist,change_id_checklist,dir_name_checklist,reservation_type_checklist);
									printf("\n CheckLiat Checked Out \n");fflush(stdout);
								}
								GRM_create_relation(item,NePartReqChkListTag,creltypetag,NULLTAG,&rel_tag);
								//AOM_save(rel_tag);
								GRM_save_relation(rel_tag);
							}
						}
						/*END FOR NPR CHECKLIST*/

						/*START FOR Auto Assign Reviewers NPR*/
						if(latestitemrev!=NULLTAG)
						{

							char
								*qry_entries3[2] = {"Name","Type"},
								*qry_values3[2]	= {"*","*"};

							tag_t	query			= NULLTAG;
							tag_t	*q_item1		= NULLTAG;
							tag_t	group_tag		= NULLTAG;
							tag_t	role_tag		= NULLTAG;
							tag_t	*members		= NULLTAG;
							tag_t   coc_id			= NULLTAG;
							tag_t   coc_principle	= NULLTAG;
							tag_t   coc_head		= NULLTAG;
							tag_t   head_engg		= NULLTAG;
							tag_t   pvbu_coc_id		= NULLTAG;
							tag_t   user_tag		= NULLTAG;

							tag_t		Module_Patricipant_Type			= NULLTAG;
							tag_t		module_participant				= NULLTAG;
							tag_t		COCPrinciple_Patricipant_Type	= NULLTAG;
							tag_t		cocprinciple_participant		= NULLTAG;
							tag_t		COCHead_Patricipant_Type		= NULLTAG;
							tag_t		cochead_participant				= NULLTAG;
							tag_t		HeadEngg_Patricipant_Type		= NULLTAG;
							tag_t		headengg_participant			= NULLTAG;
							tag_t		PVBU_Patricipant_Type			= NULLTAG;
							tag_t		pvbu_participant				= NULLTAG;
							tag_t		RaisedBy						= NULLTAG;
							tag_t		RaisedBy_Patricipant_Type		= NULLTAG;
							tag_t		raisedby_participant			= NULLTAG;
							tag_t		*AcknowledgeUser				= NULLTAG;
							tag_t		*Acknowledge_User				= NULLTAG;
							tag_t		ModRevrole_tag					= NULLTAG;
							tag_t		*ModRevmembers					= NULLTAG;
							tag_t		ModReviwer_id					= NULLTAG;
							tag_t		Module_Proposed_Type			= NULLTAG;
							tag_t		modulerev_participant			= NULLTAG;
							tag_t		Roletag							= NULLTAG;
							tag_t		grouptag						= NULLTAG;
							tag_t		current_groupmember_tag			= NULLTAG;
							tag_t		VIGrole_tag						= NULLTAG;

							char   *NprRevitemId=NULL;
							char   *BussiNameS=NULL;
							char   *Proj_typ=NULL;
							char   *ErcGroupName=NULL;
							char   *GroupNameS=NULL;
							char   *GroupNameDup=NULL;
							char   *GroupNameS1=NULL;
							char   *GroupName1Dup=NULL;
							char   *Role_Name=NULL;
							char   *roleName=NULL;
							char   *grpName=NULL;

							int n_found = 0;
							int CheckApplicable = 0;
							int member_found = 0;
							int ModRevmember_found = 0;
							int r,w =0;
							int g =0;
							int h =0;
							int p =0;
							int e =0;
							int userfind =0;
							int ackmemberfound =0;
							int memberfound =0;

							AOM_ask_value_string(latestitemrev,"item_id",&NprRevitemId);
							printf("\n AAAAA NprRevitemId====>[%s]", NprRevitemId);fflush(stdout);

							qry_values3[0]	= prj_code;
							qry_values3[1]	= "Project";
							QRY_find2("Item...", &query);
							QRY_execute(query, 2, qry_entries3, qry_values3, &n_found, &q_item1);
							printf("\n n_found =[%d]",n_found);fflush(stdout);
							if(n_found>0)
							{
								AOM_ask_value_string(q_item1[0],"t5_BussUnitType",&BussiNameS);
								printf("\n AAAAA BussiNameS====>[%s]", BussiNameS);fflush(stdout);
								AOM_ask_value_string(q_item1[0],"t5_ProjectType",&Proj_typ);
								printf("\n AAAAA Proj_typ====>[%s]", Proj_typ);fflush(stdout);

								if(tc_strcmp(Proj_typ,"E")==0 || (tc_strcmp(Proj_typ,"G")==0))
								{
									printf("\n Inside the project type as Engine or GearBox");fflush(stdout);
									printf("\n Inside the project type as Engine or GearBox %s",prj_code);fflush(stdout);
									if(tc_strcmp(Proj_typ,"E")==0)
									{
										printf("\n Inside the project type as Engine or GearBox %s",designgroup);fflush(stdout);
										printf("\n Inside the project type as Engine or GearBox %s",designgroup);fflush(stdout);
										//if(isFor12Digit==true && isFor14Digit==false)
										if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
										{
											if(tc_strcmp(designgroup,"50")==0)
											{
												 if(tc_strcmp(designid,"33")==0)
												{
													CheckApplicable=1;
													printf("\n Check is applicable to design group 50 and designation id -33 \n");fflush(stdout);
												}
														
											}
											else if(tc_strcmp(designgroup,"23")==0)
											{
												if((tc_strcmp(designid,"33")==0) || (tc_strcmp(designid,"37")==0) || (tc_strcmp(designid,"38")==0))
												{
													CheckApplicable=1;
													printf("\n Check is applicable to design group 23 and designation id -33/37/38 \n");fflush(stdout);
												}

											}
										}
										else
										{
											CheckApplicable = 0;
											
										}
										
									}
									else if(tc_strcmp(Proj_typ,"G")==0)
									{
										//if(isFor12Digit==true && isFor14Digit==false)
										if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
										{
											if(tc_strcmp(designgroup,"26")==0)
											{
												 if((tc_strcmp(designid,"31")==0) || (tc_strcmp(designid,"77")==0) || (tc_strcmp(designid,"78")==0) || (tc_strcmp(designid,"86")==0) ||(tc_strcmp(designid,"65")==0))
												{
													CheckApplicable=1;
													printf("\n Gear-Box Check is applicable to design group 26 and designation id -33 \n");fflush(stdout);
												}
														
											}
											else if(tc_strcmp(designgroup,"35")==0)
											{
												if((tc_strcmp(designid,"31")==0) || (tc_strcmp(designid,"77")==0) || (tc_strcmp(designid,"78")==0) || (tc_strcmp(designid,"86")==0) ||(tc_strcmp(designid,"65")==0))
												{
													CheckApplicable=1;
													printf("\n Gear-Box Check is applicable to design group 35 and designation id -33/37/38 \n");fflush(stdout);
												}

											}
										}
										else
										{
											CheckApplicable = 0;
											
										}
										
									}
									if(CheckApplicable== 1)
									{
										ErcGroupName = (char *) MEM_alloc( 100 * sizeof(char) );
										GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
										GroupNameDup = (char *) MEM_alloc( 100 * sizeof(char) );

										

										printf("\n FOR CheckApplicable  Project code ---- %s\n", prj_code);fflush(stdout);
										printf("\n FOR CheckApplicable Design code ---- %s\n", designgroup);fflush(stdout);
										tc_strcpy(GroupNameS,prj_code);
										tc_strcat(GroupNameS,"_");
										tc_strcat(GroupNameS,designgroup);
										tc_strcat(GroupNameS,"_");
										tc_strcat(GroupNameS,"Module");

										GroupNameS1 = (char *) MEM_alloc( 200 * sizeof(char) );
										GroupName1Dup = (char *) MEM_alloc( 200 * sizeof(char) );
										//tc_strcpy(GroupNameS1,designgroup);
										//tc_strcat(GroupNameS1,"_");
										//tc_strcat(GroupNameS1,"New");
										//tc_strcat(GroupNameS1,"_");
										//tc_strcat(GroupNameS1,"ModuleReviewer");

										//tc_strcpy(GroupNameS1,"MCCReviewer");

										printf("\n 123SubModuleAddress-->[%s] \n",SubModuleAddress);fflush(stdout);
										printf("\n 123PartType====>[%s]", PartType);fflush(stdout);
										if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
										{
											char *tempSubModuleAddress = NULL;
											tempSubModuleAddress = (char *) MEM_alloc(2 * sizeof(char) );
											tempSubModuleAddress= NewPartsubString(SubModuleAddress,0,1);
											printf("\n 123tempSubModuleAddress====>[%s]", tempSubModuleAddress);fflush(stdout);
											if(tc_strcmp(tempSubModuleAddress,"A")==0)
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_App");
											}
											else if(tc_strcmp(tempSubModuleAddress,"K")==0)
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_Veh");
											}
											else if(tc_strcmp(tempSubModuleAddress,"D")==0)
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_Cabin");
											}
											else if(tc_strcmp(tempSubModuleAddress,"G")==0)
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_EE");
											}
											else if(tc_strcmp(tempSubModuleAddress,"H")==0)
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_PSE");
											}
											else if(tc_strcmp(tempSubModuleAddress,"F")==0)
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_VSE");
											}
											else
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_All");
											}
										}
										else
										{
											tc_strcpy(GroupNameS1,"MCCReviewer");
										}
										//tc_strcpy(GroupNameS1,"MCCReviewer");
										if(GroupNameS1)
										{
											tc_strcpy(GroupName1Dup,GroupNameS1);
										}					

										//tc_strcat(GroupNameS,"*");
										if(GroupNameS)
										{
											tc_strcpy(GroupNameDup,GroupNameS);
										}
										

										printf(" \n For Engine and Gear Box Access group name is created with name-- (%s) $$$$ \n",GroupNameDup);fflush(stdout);
										printf(" \n For Engine and Gear Box Access group name is created with name-- (%s) $$$$ \n",GroupName1Dup);fflush(stdout);

										tc_strcpy(ErcGroupName,"ERC_Designers_Group");
										SA_find_group(ErcGroupName, &group_tag);
										
										//CALLAPI(SA_find_groupmember_by_rolename(role_name, GroupNameDup, user_id, &number_found, &members));
										SA_find_role2(GroupNameDup,&role_tag);

										SA_find_role2(GroupName1Dup,&ModRevrole_tag);
										//SA_ask_current_groupmember(&current_groupmember_tag );
										//SA_ask_groupmember_group (current_groupmember_tag,&group_tag) ;
										if(group_tag!=NULLTAG)
										{
											SA_find_groupmember_by_role(role_tag,group_tag,&member_found,&members);
											printf("\n member_found==>[%d] \n",member_found);fflush(stdout);
											if(member_found>0)
											{
												//coc_id = members[0];
												AOM_refresh( item, TRUE);
												AOM_set_value_string(item,"t5_NwCocId",GroupNameDup);
												//AOM_save(item);
												AOM_save_without_extensions(item);
												AOM_refresh(item,FALSE);
												printf("\n For Engine and Gear Box Module Team Lead value set \n");fflush(stdout);

												r=0;
												for(r=0 ; r<member_found; r++)
												{	
													printf("\n Modeule_Reviewer: %d",r+1);fflush(stdout);
													coc_id = members[r];
													if(EPM_get_participanttype ("T5_Modeule_Reviewer",&Module_Patricipant_Type)!=ITK_ok) PrintErrorStack();
													if(EPM_create_participant(coc_id,Module_Patricipant_Type,&module_participant)!=ITK_ok) PrintErrorStack();
													AOM_refresh(latestitemrev, TRUE);
													//if(ITEM_rev_add_participant(latestitemrev,module_participant)!=ITK_ok)PrintErrorStack();
													PARTICIPANT_add_participant(latestitemrev,TRUE,module_participant);
													AOM_save_without_extensions(latestitemrev);
													AOM_refresh(latestitemrev,FALSE);
												}
											}
											SA_find_groupmember_by_role(ModRevrole_tag,group_tag,&ModRevmember_found,&ModRevmembers);
											if(ModRevmember_found>0)
											{
												//coc_id = members[0];
												AOM_refresh( item, TRUE);
												AOM_set_value_string(item,"t5_ModuleReviewer",GroupName1Dup);
												AOM_save_without_extensions(item);
												AOM_refresh(item,FALSE);
												printf("\n For Engine and Gear Box Module Team Lead value set \n");fflush(stdout);

												w=0;
												for(w=0 ; w<ModRevmember_found; w++)
												{	
													printf("\n Modeule_Reviewer: %d",w+1);fflush(stdout);
													ModReviwer_id = ModRevmembers[w];
													if(EPM_get_participanttype ("ProposedReviewer",&Module_Proposed_Type)!=ITK_ok) PrintErrorStack();
													if(EPM_create_participant(ModReviwer_id,Module_Proposed_Type,&modulerev_participant)!=ITK_ok) PrintErrorStack();
													AOM_refresh(latestitemrev, TRUE);
													//if(ITEM_rev_add_participant(latestitemrev,modulerev_participant)!=ITK_ok)PrintErrorStack();
													PARTICIPANT_add_participant(latestitemrev,TRUE,modulerev_participant);
													AOM_save_without_extensions(latestitemrev);
													AOM_refresh(latestitemrev,FALSE);
												}
											}
										}
										MEM_free(members);
										MEM_free(ModRevmembers);

										MEM_free(GroupNameS);
										GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
										tc_strcpy(GroupNameS,designgroup);
										tc_strcat(GroupNameS,"_");
										tc_strcat(GroupNameS,"New");
										tc_strcat(GroupNameS,"_");
										tc_strcat(GroupNameS,"COCPrinciple");
										printf(" \n $$$$ Temporary Request No created with name (%s) $$$$ \n",GroupNameS);fflush(stdout);
										//SA_find_group(ErcGroupName, &group_tag);
										SA_find_role2(GroupNameS,&role_tag);
										if(group_tag!=NULLTAG)
										{
											SA_find_groupmember_by_role(role_tag,group_tag,&member_found,&members);
											printf("\n COC Principle Assign--->[%d] \n",member_found);fflush(stdout);
											if(member_found>0)
											{
												//coc_id = members[0];
												AOM_refresh( item, TRUE);
												AOM_set_value_string(item,"t5_NwChiefId",GroupNameS);
												AOM_save_without_extensions(item);
												AOM_refresh(item,FALSE);
												printf("\n COC Principle Assign\n");fflush(stdout);
												g=0;
												for(g=0 ; g<member_found; g++)
												{	
													printf("\n COC Principle Assign: %d",g+1);fflush(stdout);
													coc_principle = members[g];
													if(EPM_get_participanttype ("T5_COCPrinciple_Reviewer",&COCPrinciple_Patricipant_Type)!=ITK_ok) PrintErrorStack();
													if(EPM_create_participant(coc_principle,COCPrinciple_Patricipant_Type,&cocprinciple_participant)!=ITK_ok) PrintErrorStack();
													AOM_refresh(latestitemrev, TRUE);
													//if(ITEM_rev_add_participant(latestitemrev,cocprinciple_participant)!=ITK_ok) PrintErrorStack();
													PARTICIPANT_add_participant(latestitemrev,TRUE,cocprinciple_participant);
													AOM_save_without_extensions(latestitemrev);
													AOM_refresh(latestitemrev,FALSE);
												}
											}
										}
										MEM_free(members);
										MEM_free(GroupNameS);
										GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
										tc_strcpy(GroupNameS,designgroup);
										tc_strcat(GroupNameS,"_");
										tc_strcat(GroupNameS,"New");
										tc_strcat(GroupNameS,"_");
										tc_strcat(GroupNameS,"COCHead");
										printf(" \n $$$$ Temporary Request No created with name (%s) $$$$ \n",GroupNameS);fflush(stdout);
										//SA_find_group(GroupNameS, &group_tag);
										SA_find_role2(GroupNameS,&role_tag);
										if(group_tag!=NULLTAG)
										{
											SA_find_groupmember_by_role(role_tag,group_tag,&member_found,&members);
											printf("\n COC Head Assign--->[%d] \n",member_found);fflush(stdout);
											if(member_found>0)
											{
												//coc_id = members[0];
												AOM_refresh( item, TRUE);
												AOM_set_value_string(item,"t5_NwCeId",GroupNameS);
												//if ((strcmp(designgroup,"31")==0)  &&  (strcmp(partFam,"LONG MEMBER")==0))
												if ((strcmp(designgroup,"31")==0))
												{
													AOM_set_value_string(item,"t5_NwHeadEng",GroupNameS);
												}
												AOM_save_without_extensions(item);
												AOM_refresh(item,FALSE);

												printf("\n COC Head Assign\n");fflush(stdout);
												h=0;
												for(h=0 ; h<member_found; h++)
												{	
													printf("\n COC Head Assign: %d",g+1);fflush(stdout);
													coc_head = members[h];
													if(EPM_get_participanttype ("T5_COCHead_Reviewer",&COCHead_Patricipant_Type)!=ITK_ok) PrintErrorStack();
													if(EPM_create_participant(coc_head,COCHead_Patricipant_Type,&cochead_participant)!=ITK_ok) PrintErrorStack();
													AOM_refresh(latestitemrev, TRUE);
													//if(ITEM_rev_add_participant(latestitemrev,cochead_participant)!=ITK_ok) PrintErrorStack();
													PARTICIPANT_add_participant(latestitemrev,TRUE,cochead_participant);
													AOM_save_without_extensions(latestitemrev);
													AOM_refresh(latestitemrev,FALSE);
												}
												AOM_refresh ( latestitemrev,TRUE);
												if ((strcmp(designgroup,"31")==0))
												{
													printf("\n Head Engg Assign\n");fflush(stdout);
													e=0;
													for(e=0 ; e<member_found; e++)
													{
														head_engg = members[e];
														if(EPM_get_participanttype ("T5_HeadOfEngg",&HeadEngg_Patricipant_Type)!=ITK_ok) PrintErrorStack();
														if(EPM_create_participant(head_engg,HeadEngg_Patricipant_Type,&headengg_participant)!=ITK_ok) PrintErrorStack();
														AOM_refresh(latestitemrev, TRUE);
														//if(ITEM_rev_add_participant(latestitemrev,headengg_participant)!=ITK_ok) PrintErrorStack();
														PARTICIPANT_add_participant(latestitemrev,TRUE,headengg_participant);
														AOM_save_without_extensions(latestitemrev);
														AOM_refresh(latestitemrev,FALSE);
													}
												}
											}
										}
										MEM_free(members);
										MEM_free(GroupNameS);
										if(tc_strcmp(PartType,"T")==0 || tc_strcmp(PartType,"Technical Part List")==0)
										{
											GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
											tc_strcpy(GroupNameS,"Veh");
											tc_strcat(GroupNameS,"_");
											tc_strcat(GroupNameS,"VIG");
											tc_strcat(GroupNameS,"_");
											tc_strcat(GroupNameS,"Head");
											SA_find_role2(GroupNameS,&VIGrole_tag);
											if(group_tag!=NULLTAG)
											{
												int ModVIGRevmember_found = 0;
												tag_t	*ModVIGRevmembers	= NULLTAG;
												tag_t	ModVIGReviwer_id	= NULLTAG;
												tag_t	ModuleVIG_Proposed_Type	= NULLTAG;
												tag_t	modulerev_vigparticipant	= NULLTAG;
												if(VIGrole_tag!=NULLTAG)
												{
													SA_find_groupmember_by_role(VIGrole_tag,group_tag,&ModVIGRevmember_found,&ModVIGRevmembers);
													if(ModVIGRevmember_found>0)
													{
														//coc_id = members[0];
														AOM_refresh( item, TRUE);
														AOM_set_value_string(item,"t5_NwHeadEng",GroupNameS);
														AOM_save_without_extensions(item);
														AOM_refresh(item,FALSE);
														printf("\n For Engine and Gear Box Module Team Lead value set \n");fflush(stdout);

														int vig=0;
														for(vig=0 ; vig<ModVIGRevmember_found; vig++)
														{	
															printf("\n Modeule_Reviewer: %d",vig+1);fflush(stdout);
															ModVIGReviwer_id = ModVIGRevmembers[vig];
															if(EPM_get_participanttype ("T5_HeadOfEngg",&ModuleVIG_Proposed_Type)!=ITK_ok) PrintErrorStack();
															if(EPM_create_participant(ModVIGReviwer_id,ModuleVIG_Proposed_Type,&modulerev_vigparticipant)!=ITK_ok) PrintErrorStack();
															AOM_refresh(latestitemrev, TRUE);
															PARTICIPANT_add_participant(latestitemrev,TRUE,modulerev_vigparticipant);
															AOM_save_without_extensions(latestitemrev);
															AOM_refresh(latestitemrev,FALSE);
														}
													}
												}
											}
										}
									}
								}

								if(CheckApplicable== 0)
								{
									printf("\n Value of Bussiness Unit (%s) \n",BussiNameS);fflush(stdout);
									if(strcmp(BussiNameS,"CVBU")==0 || tc_strstr(BussiNameS,"CVBU")!=NULL)
									{
										ErcGroupName = (char *) MEM_alloc( 100 * sizeof(char) );
										GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
										GroupNameDup = (char *) MEM_alloc( 100 * sizeof(char) );
										tc_strcpy(GroupNameS,designgroup);
										tc_strcat(GroupNameS,"_");
										tc_strcat(GroupNameS,"New");
										tc_strcat(GroupNameS,"_");
										tc_strcat(GroupNameS,"Module");

										GroupNameS1 = (char *) MEM_alloc( 200 * sizeof(char) );
										GroupName1Dup = (char *) MEM_alloc( 200 * sizeof(char) );
										//tc_strcpy(GroupNameS1,designgroup);
										//tc_strcat(GroupNameS1,"_");
										//tc_strcat(GroupNameS1,"New");
										//tc_strcat(GroupNameS1,"_");
										//tc_strcat(GroupNameS1,"ModuleReviewer");

										printf("\n 123SubModuleAddress-->[%s] \n",SubModuleAddress);fflush(stdout);
										printf("\n 123PartType====>[%s]", PartType);fflush(stdout);
										if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
										{
											char *tempSubModuleAddress = NULL;
											tempSubModuleAddress = (char *) MEM_alloc(2 * sizeof(char) );
											tempSubModuleAddress= NewPartsubString(SubModuleAddress,0,1);
											printf("\n 123tempSubModuleAddress====>[%s]", tempSubModuleAddress);fflush(stdout);
											if(tc_strcmp(tempSubModuleAddress,"A")==0)
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_App");
											}
											else if(tc_strcmp(tempSubModuleAddress,"K")==0)
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_Veh");
											}
											else if(tc_strcmp(tempSubModuleAddress,"D")==0)
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_Cabin");
											}
											else if(tc_strcmp(tempSubModuleAddress,"G")==0)
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_EE");
											}
											else if(tc_strcmp(tempSubModuleAddress,"H")==0)
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_PSE");
											}
											else if(tc_strcmp(tempSubModuleAddress,"F")==0)
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_VSE");
											}
											else
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_All");
											}
										}
										else
										{
											tc_strcpy(GroupNameS1,"MCCReviewer");
										}
										//tc_strcpy(GroupNameS1,"MCCReviewer");
										if(GroupNameS1)
										{
											tc_strcpy(GroupName1Dup,GroupNameS1);
										}

										printf(" \n $$$$ Temporary Request No created with name (%s) $$$$ \n",GroupNameS);fflush(stdout);
										printf(" \n $$$$ Temporary Request No created with name (%s) $$$$ \n",GroupName1Dup);fflush(stdout);
										if(GroupNameS)
										{
											tc_strcpy(GroupNameDup,GroupNameS);
										}
										tc_strcpy(ErcGroupName,"ERC_Designers_Group");
										SA_find_group(ErcGroupName, &group_tag);
										SA_find_role2(GroupNameDup,&role_tag);
										SA_find_role2(GroupName1Dup,&ModRevrole_tag);
										if(group_tag!=NULLTAG)
										{
											SA_find_groupmember_by_role(role_tag,group_tag,&member_found,&members);
											printf("\n Module Team Leader Assign-->[%d] \n",member_found);fflush(stdout);
											if(member_found>0)
											{
												//coc_id = members[0];
												AOM_refresh( item, TRUE);
												AOM_set_value_string(item,"t5_NwCocId",GroupNameDup);
												AOM_save_without_extensions(item);
												AOM_refresh(item,FALSE);
												printf("\n Module Team Leader Assign \n");fflush(stdout);
												r=0;
												for(r=0 ; r<member_found; r++)
												{	
													printf("\n Modeule_Reviewer: %d",r+1);fflush(stdout);
													coc_id = members[r];
													if(EPM_get_participanttype ("T5_Modeule_Reviewer",&Module_Patricipant_Type)!=ITK_ok) PrintErrorStack();
													if(EPM_create_participant(coc_id,Module_Patricipant_Type,&module_participant)!=ITK_ok) PrintErrorStack();
													AOM_refresh(latestitemrev, TRUE);
													//if(ITEM_rev_add_participant(latestitemrev,module_participant)!=ITK_ok) PrintErrorStack();
													PARTICIPANT_add_participant(latestitemrev,TRUE,module_participant);
													AOM_save_without_extensions(latestitemrev);
													AOM_refresh(latestitemrev,FALSE);
												}
											}
											SA_find_groupmember_by_role(ModRevrole_tag,group_tag,&ModRevmember_found,&ModRevmembers);
											if(ModRevmember_found>0)
											{
												//coc_id = members[0];
												AOM_refresh( item, TRUE);
												AOM_set_value_string(item,"t5_ModuleReviewer",GroupName1Dup);
												AOM_save_without_extensions(item);
												AOM_refresh(item,FALSE);
												printf("\n For Engine and Gear Box Module Team Lead value set \n");fflush(stdout);

												w=0;
												for(w=0 ; w<ModRevmember_found; w++)
												{	
													printf("\n Modeule_Reviewer: %d",w+1);fflush(stdout);
													ModReviwer_id = ModRevmembers[w];
													if(EPM_get_participanttype ("ProposedReviewer",&Module_Proposed_Type)!=ITK_ok) PrintErrorStack();
													if(EPM_create_participant(ModReviwer_id,Module_Proposed_Type,&modulerev_participant)!=ITK_ok) PrintErrorStack();
													AOM_refresh(latestitemrev, TRUE);
													//if(ITEM_rev_add_participant(latestitemrev,modulerev_participant)!=ITK_ok)PrintErrorStack();
													PARTICIPANT_add_participant(latestitemrev,TRUE,modulerev_participant);
													AOM_save_without_extensions(latestitemrev);
													AOM_refresh(latestitemrev,FALSE);
												}
											}
										}

										MEM_free(members);
										MEM_free(ModRevmembers);
										MEM_free(GroupNameS);
										GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
										tc_strcpy(GroupNameS,designgroup);
										tc_strcat(GroupNameS,"_");
										tc_strcat(GroupNameS,"New");
										tc_strcat(GroupNameS,"_");
										tc_strcat(GroupNameS,"COCPrinciple");
										printf(" \n $$$$ Temporary Request No created with name (%s) $$$$ \n",GroupNameS);fflush(stdout);
										//SA_find_group(ErcGroupName, &group_tag);
										SA_find_role2(GroupNameS,&role_tag);
										if(group_tag!=NULLTAG)
										{
											SA_find_groupmember_by_role(role_tag,group_tag,&member_found,&members);
											printf("\n COC Principle Assign--->[%d] \n",member_found);fflush(stdout);
											if(member_found>0)
											{
												//coc_id = members[0];
												AOM_refresh( item, TRUE);
												AOM_set_value_string(item,"t5_NwChiefId",GroupNameS);
												AOM_save_without_extensions(item);
												AOM_refresh(item,FALSE);
												printf("\n COC Principle Assign\n");fflush(stdout);
												g=0;
												for(g=0 ; g<member_found; g++)
												{	
													printf("\n COC Principle Assign: %d",g+1);fflush(stdout);
													coc_principle = members[g];
													if(EPM_get_participanttype ("T5_COCPrinciple_Reviewer",&COCPrinciple_Patricipant_Type)!=ITK_ok) PrintErrorStack();
													if(EPM_create_participant(coc_principle,COCPrinciple_Patricipant_Type,&cocprinciple_participant)!=ITK_ok) PrintErrorStack();
													AOM_refresh(latestitemrev, TRUE);
													//if(ITEM_rev_add_participant(latestitemrev,cocprinciple_participant)!=ITK_ok) PrintErrorStack();
													PARTICIPANT_add_participant(latestitemrev,TRUE,cocprinciple_participant);
													AOM_save_without_extensions(latestitemrev);
													AOM_refresh(latestitemrev,FALSE);
												}
											}
										}
										MEM_free(members);
										MEM_free(GroupNameS);
										GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
										tc_strcpy(GroupNameS,designgroup);
										tc_strcat(GroupNameS,"_");
										tc_strcat(GroupNameS,"New");
										tc_strcat(GroupNameS,"_");
										tc_strcat(GroupNameS,"COCHead");
										printf(" \n $$$$ Temporary Request No created with name (%s) $$$$ \n",GroupNameS);fflush(stdout);
										//SA_find_group(GroupNameS, &group_tag);
										SA_find_role2(GroupNameS,&role_tag);
										if(group_tag!=NULLTAG)
										{
											SA_find_groupmember_by_role(role_tag,group_tag,&member_found,&members);
											printf("\n COC Head Assign--->[%d] \n",member_found);fflush(stdout);
											if(member_found>0)
											{
												//coc_id = members[0];
												AOM_refresh( item, TRUE);
												AOM_set_value_string(item,"t5_NwCeId",GroupNameS);
												//if ((strcmp(designgroup,"31")==0)  &&  (strcmp(partFam,"LONG MEMBER")==0))
												if ((strcmp(designgroup,"31")==0))
												{
													AOM_set_value_string(item,"t5_NwHeadEng",GroupNameS);
												}
												AOM_save_without_extensions(item);
												AOM_refresh(item,FALSE);

												printf("\n COC Head Assign\n");fflush(stdout);
												h=0;
												for(h=0 ; h<member_found; h++)
												{	
													printf("\n COC Head Assign: %d",g+1);fflush(stdout);
													coc_head = members[h];
													if(EPM_get_participanttype ("T5_COCHead_Reviewer",&COCHead_Patricipant_Type)!=ITK_ok) PrintErrorStack();
													if(EPM_create_participant(coc_head,COCHead_Patricipant_Type,&cochead_participant)!=ITK_ok) PrintErrorStack();
													AOM_refresh(latestitemrev, TRUE);
													//if(ITEM_rev_add_participant(latestitemrev,cochead_participant)!=ITK_ok) PrintErrorStack();
													PARTICIPANT_add_participant(latestitemrev,TRUE,cochead_participant);
													AOM_save_without_extensions(latestitemrev);
													AOM_refresh(latestitemrev,FALSE);
												}
												AOM_refresh ( latestitemrev,TRUE);
												if ((strcmp(designgroup,"31")==0))
												{
													printf("\n Head Engg Assign\n");fflush(stdout);
													e=0;
													for(e=0 ; e<member_found; e++)
													{
														head_engg = members[e];
														if(EPM_get_participanttype ("T5_HeadOfEngg",&HeadEngg_Patricipant_Type)!=ITK_ok) PrintErrorStack();
														if(EPM_create_participant(head_engg,HeadEngg_Patricipant_Type,&headengg_participant)!=ITK_ok) PrintErrorStack();
														AOM_refresh(latestitemrev, TRUE);
														//if(ITEM_rev_add_participant(latestitemrev,headengg_participant)!=ITK_ok) PrintErrorStack();
														PARTICIPANT_add_participant(latestitemrev,TRUE,headengg_participant);
														AOM_save_without_extensions(latestitemrev);
														AOM_refresh(latestitemrev,FALSE);
													}
												}
											}
										}
										MEM_free(members);
										MEM_free(GroupNameS);
										if(tc_strcmp(PartType,"T")==0 || tc_strcmp(PartType,"Technical Part List")==0)
										{
											GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
											tc_strcpy(GroupNameS,"Veh");
											tc_strcat(GroupNameS,"_");
											tc_strcat(GroupNameS,"VIG");
											tc_strcat(GroupNameS,"_");
											tc_strcat(GroupNameS,"Head");
											SA_find_role2(GroupNameS,&VIGrole_tag);
											if(group_tag!=NULLTAG)
											{
												int ModVIGRevmember_found = 0;
												tag_t	*ModVIGRevmembers	= NULLTAG;
												tag_t	ModVIGReviwer_id	= NULLTAG;
												tag_t	ModuleVIG_Proposed_Type	= NULLTAG;
												tag_t	modulerev_vigparticipant	= NULLTAG;
												if(VIGrole_tag!=NULLTAG)
												{
													SA_find_groupmember_by_role(VIGrole_tag,group_tag,&ModVIGRevmember_found,&ModVIGRevmembers);
													if(ModVIGRevmember_found>0)
													{
														//coc_id = members[0];
														AOM_refresh( item, TRUE);
														AOM_set_value_string(item,"t5_NwHeadEng",GroupNameS);
														AOM_save_without_extensions(item);
														AOM_refresh(item,FALSE);
														printf("\n VIG Head Engg Assign\n");fflush(stdout);

														int vig=0;
														for(vig=0 ; vig<ModVIGRevmember_found; vig++)
														{	
															printf("\n VIG Head Engg: %d",vig+1);fflush(stdout);
															ModVIGReviwer_id = ModVIGRevmembers[vig];
															if(EPM_get_participanttype ("T5_HeadOfEngg",&ModuleVIG_Proposed_Type)!=ITK_ok) PrintErrorStack();
															if(EPM_create_participant(ModVIGReviwer_id,ModuleVIG_Proposed_Type,&modulerev_vigparticipant)!=ITK_ok) PrintErrorStack();
															AOM_refresh(latestitemrev, TRUE);
															PARTICIPANT_add_participant(latestitemrev,TRUE,modulerev_vigparticipant);
															AOM_save_without_extensions(latestitemrev);
															AOM_refresh(latestitemrev,FALSE);
														}
													}
												}
											}
										}

										
									}
									if(strcmp(BussiNameS,"PCBU")==0)
									{
										ErcGroupName = (char *) MEM_alloc( 100 * sizeof(char) );
										GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
										GroupNameDup = (char *) MEM_alloc( 100 * sizeof(char) );
										tc_strcpy(GroupNameS,designgroup);
										tc_strcat(GroupNameS,"_");
										tc_strcat(GroupNameS,"PVBU");
										//tc_strcat(GroupNameS,"*");
										if(GroupNameS)
										{
											tc_strcpy(GroupNameDup,GroupNameS);
										}

										GroupNameS1 = (char *) MEM_alloc( 200 * sizeof(char) );
										GroupName1Dup = (char *) MEM_alloc( 200 * sizeof(char) );
										//tc_strcpy(GroupNameS1,designgroup);
										//tc_strcat(GroupNameS1,"_");
										//tc_strcat(GroupNameS1,"New");
										//tc_strcat(GroupNameS1,"_");
										//tc_strcat(GroupNameS1,"ModuleReviewer");

										//tc_strcpy(GroupNameS1,"MCCReviewer");

										printf("\n 123SubModuleAddress-->[%s] \n",SubModuleAddress);fflush(stdout);
										printf("\n 123PartType====>[%s]", PartType);fflush(stdout);
										if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
										{
											char *tempSubModuleAddress = NULL;
											tempSubModuleAddress = (char *) MEM_alloc(2 * sizeof(char) );
											tempSubModuleAddress= NewPartsubString(SubModuleAddress,0,1);
											printf("\n 123tempSubModuleAddress====>[%s]", tempSubModuleAddress);fflush(stdout);
											if(tc_strcmp(tempSubModuleAddress,"A")==0)
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_App");
											}
											else if(tc_strcmp(tempSubModuleAddress,"K")==0)
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_Veh");
											}
											else if(tc_strcmp(tempSubModuleAddress,"D")==0)
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_Cabin");
											}
											else if(tc_strcmp(tempSubModuleAddress,"G")==0)
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_EE");
											}
											else if(tc_strcmp(tempSubModuleAddress,"H")==0)
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_PSE");
											}
											else if(tc_strcmp(tempSubModuleAddress,"F")==0)
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_VSE");
											}
											else
											{
												tc_strcpy(GroupNameS1,"MCCReviewer_All");
											}
										}
										else
										{
											tc_strcpy(GroupNameS1,"MCCReviewer");
										}
										//tc_strcpy(GroupNameS1,"MCCReviewer");
										if(GroupNameS1)
										{
											tc_strcpy(GroupName1Dup,GroupNameS1);
										}
										
										tc_strcpy(ErcGroupName,"ERC_Designers_Group");
										SA_find_group(ErcGroupName, &group_tag);
										SA_find_role2(GroupNameDup,&role_tag);
										SA_find_role2(GroupName1Dup,&ModRevrole_tag);
										if(group_tag!=NULLTAG)
										{
											SA_find_groupmember_by_role(role_tag,group_tag,&member_found,&members);
											if(member_found>0)
											{
												//coc_id = members[0];
												AOM_refresh( item, TRUE);
												AOM_set_value_string(item,"t5_NwCocId",GroupNameDup);
												AOM_save_without_extensions(item);
												AOM_refresh(item,FALSE);
												printf("\n For PVBU Assignee \n");fflush(stdout);
												EPM_get_participanttype ("T5_Modeule_Reviewer",&PVBU_Patricipant_Type);
												for(p=0 ; p<member_found; p++)
												{
													pvbu_coc_id = members[p];
													EPM_create_participant(pvbu_coc_id,PVBU_Patricipant_Type,&pvbu_participant);
													AOM_refresh(latestitemrev, TRUE);
													//ITEM_rev_add_participant(latestitemrev,pvbu_participant);
													PARTICIPANT_add_participant(latestitemrev,TRUE,pvbu_participant);
													AOM_save_without_extensions(latestitemrev);
													AOM_refresh(latestitemrev,FALSE);
												}
											}
											SA_find_groupmember_by_role(ModRevrole_tag,group_tag,&ModRevmember_found,&ModRevmembers);
											if(ModRevmember_found>0)
											{
												//coc_id = members[0];
												AOM_refresh( item, TRUE);
												AOM_set_value_string(item,"t5_ModuleReviewer",GroupName1Dup);
												AOM_save_without_extensions(item);
												AOM_refresh(item,FALSE);
												printf("\n For Engine and Gear Box Module Team Lead value set \n");fflush(stdout);

												w=0;
												for(w=0 ; w<ModRevmember_found; w++)
												{	
													printf("\n Modeule_Reviewer: %d",w+1);fflush(stdout);
													ModReviwer_id = ModRevmembers[w];
													if(EPM_get_participanttype ("ProposedReviewer",&Module_Proposed_Type)!=ITK_ok) PrintErrorStack();
													if(EPM_create_participant(ModReviwer_id,Module_Proposed_Type,&modulerev_participant)!=ITK_ok) PrintErrorStack();
													AOM_refresh(latestitemrev, TRUE);
													//if(ITEM_rev_add_participant(latestitemrev,modulerev_participant)!=ITK_ok)PrintErrorStack();
													PARTICIPANT_add_participant(latestitemrev,TRUE,modulerev_participant);
													AOM_save_without_extensions(latestitemrev);
													AOM_refresh(latestitemrev,FALSE);
												}
											}
										}
										MEM_free(members);
										MEM_free(ModRevmembers);
										MEM_free(GroupNameS);
										GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
										tc_strcpy(GroupNameS,designgroup);
										tc_strcat(GroupNameS,"_");
										tc_strcat(GroupNameS,"New");
										tc_strcat(GroupNameS,"_");
										tc_strcat(GroupNameS,"COCPrinciple");
										printf(" \n $$$$ Temporary Request No created with name (%s) $$$$ \n",GroupNameS);fflush(stdout);
										//SA_find_group(ErcGroupName, &group_tag);
										SA_find_role2(GroupNameS,&role_tag);
										if(group_tag!=NULLTAG)
										{
											SA_find_groupmember_by_role(role_tag,group_tag,&member_found,&members);
											printf("\n COC Principle Assign--->[%d] \n",member_found);fflush(stdout);
											if(member_found>0)
											{
												//coc_id = members[0];
												AOM_refresh( item, TRUE);
												AOM_set_value_string(item,"t5_NwChiefId",GroupNameS);
												AOM_save_without_extensions(item);
												AOM_refresh(item,FALSE);
												printf("\n COC Principle Assign\n");fflush(stdout);
												g=0;
												for(g=0 ; g<member_found; g++)
												{	
													printf("\n COC Principle Assign: %d",g+1);fflush(stdout);
													coc_principle = members[g];
													if(EPM_get_participanttype ("T5_COCPrinciple_Reviewer",&COCPrinciple_Patricipant_Type)!=ITK_ok) PrintErrorStack();
													if(EPM_create_participant(coc_principle,COCPrinciple_Patricipant_Type,&cocprinciple_participant)!=ITK_ok) PrintErrorStack();
													AOM_refresh(latestitemrev, TRUE);
													//if(ITEM_rev_add_participant(latestitemrev,cocprinciple_participant)!=ITK_ok) PrintErrorStack();
													PARTICIPANT_add_participant(latestitemrev,TRUE,cocprinciple_participant);
													AOM_save_without_extensions(latestitemrev);
													AOM_refresh(latestitemrev,FALSE);
												}
											}
										}
										MEM_free(members);
										MEM_free(GroupNameS);
										GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
										tc_strcpy(GroupNameS,designgroup);
										tc_strcat(GroupNameS,"_");
										tc_strcat(GroupNameS,"New");
										tc_strcat(GroupNameS,"_");
										tc_strcat(GroupNameS,"COCHead");
										printf(" \n $$$$ Temporary Request No created with name (%s) $$$$ \n",GroupNameS);fflush(stdout);
										//SA_find_group(GroupNameS, &group_tag);
										SA_find_role2(GroupNameS,&role_tag);
										if(group_tag!=NULLTAG)
										{
											SA_find_groupmember_by_role(role_tag,group_tag,&member_found,&members);
											printf("\n COC Head Assign--->[%d] \n",member_found);fflush(stdout);
											if(member_found>0)
											{
												//coc_id = members[0];
												AOM_refresh( item, TRUE);
												AOM_set_value_string(item,"t5_NwCeId",GroupNameS);
												//if ((strcmp(designgroup,"31")==0)  &&  (strcmp(partFam,"LONG MEMBER")==0))
												if ((strcmp(designgroup,"31")==0))
												{
													AOM_set_value_string(item,"t5_NwHeadEng",GroupNameS);
												}
												AOM_save_without_extensions(item);
												AOM_refresh(item,FALSE);

												printf("\n COC Head Assign\n");fflush(stdout);
												h=0;
												for(h=0 ; h<member_found; h++)
												{	
													printf("\n COC Head Assign: %d",g+1);fflush(stdout);
													coc_head = members[h];
													if(EPM_get_participanttype ("T5_COCHead_Reviewer",&COCHead_Patricipant_Type)!=ITK_ok) PrintErrorStack();
													if(EPM_create_participant(coc_head,COCHead_Patricipant_Type,&cochead_participant)!=ITK_ok) PrintErrorStack();
													AOM_refresh(latestitemrev, TRUE);
													//if(ITEM_rev_add_participant(latestitemrev,cochead_participant)!=ITK_ok) PrintErrorStack();
													PARTICIPANT_add_participant(latestitemrev,TRUE,cochead_participant);
													AOM_save_without_extensions(latestitemrev);
													AOM_refresh(latestitemrev,FALSE);
												}
												AOM_refresh ( latestitemrev,TRUE);
												if ((strcmp(designgroup,"31")==0))
												{
													printf("\n Head Engg Assign\n");fflush(stdout);
													e=0;
													for(e=0 ; e<member_found; e++)
													{
														head_engg = members[e];
														if(EPM_get_participanttype ("T5_HeadOfEngg",&HeadEngg_Patricipant_Type)!=ITK_ok) PrintErrorStack();
														if(EPM_create_participant(head_engg,HeadEngg_Patricipant_Type,&headengg_participant)!=ITK_ok) PrintErrorStack();
														AOM_refresh(latestitemrev, TRUE);
														//if(ITEM_rev_add_participant(latestitemrev,headengg_participant)!=ITK_ok) PrintErrorStack();
														PARTICIPANT_add_participant(latestitemrev,TRUE,headengg_participant);
														AOM_save_without_extensions(latestitemrev);
														AOM_refresh(latestitemrev,FALSE);
													}
												}
											}
										}
										MEM_free(members);
										MEM_free(GroupNameS);
										if(tc_strcmp(PartType,"T")==0 || tc_strcmp(PartType,"Technical Part List")==0)
										{
											GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
											tc_strcpy(GroupNameS,"Veh");
											tc_strcat(GroupNameS,"_");
											tc_strcat(GroupNameS,"VIG");
											tc_strcat(GroupNameS,"_");
											tc_strcat(GroupNameS,"Head");
											SA_find_role2(GroupNameS,&VIGrole_tag);
											if(group_tag!=NULLTAG)
											{
												int ModVIGRevmember_found = 0;
												tag_t	*ModVIGRevmembers	= NULLTAG;
												tag_t	ModVIGReviwer_id	= NULLTAG;
												tag_t	ModuleVIG_Proposed_Type	= NULLTAG;
												tag_t	modulerev_vigparticipant	= NULLTAG;
												if(VIGrole_tag!=NULLTAG)
												{
													SA_find_groupmember_by_role(VIGrole_tag,group_tag,&ModVIGRevmember_found,&ModVIGRevmembers);
													if(ModVIGRevmember_found>0)
													{
														//coc_id = members[0];
														AOM_refresh( item, TRUE);
														AOM_set_value_string(item,"t5_NwHeadEng",GroupNameS);
														AOM_save_without_extensions(item);
														AOM_refresh(item,FALSE);
														printf("\n VIG Head Engg Assign\n");fflush(stdout);

														int vig=0;
														for(vig=0 ; vig<ModVIGRevmember_found; vig++)
														{	
															printf("\n VIG Head Engg: %d",vig+1);fflush(stdout);
															ModVIGReviwer_id = ModVIGRevmembers[vig];
															if(EPM_get_participanttype ("T5_HeadOfEngg",&ModuleVIG_Proposed_Type)!=ITK_ok) PrintErrorStack();
															if(EPM_create_participant(ModVIGReviwer_id,ModuleVIG_Proposed_Type,&modulerev_vigparticipant)!=ITK_ok) PrintErrorStack();
															AOM_refresh(latestitemrev, TRUE);
															PARTICIPANT_add_participant(latestitemrev,TRUE,modulerev_vigparticipant);
															AOM_save_without_extensions(latestitemrev);
															AOM_refresh(latestitemrev,FALSE);
														}
													}
												}
											}
										}
										
									}
								}
								printf("\n Reviewer set before obejct creation @@ \n");fflush(stdout);
							}
							else
							{
								ifail=t9NewPartReqCre_Val0048;
								EMH_store_error_s1(EMH_severity_error,ifail,"Project Details Not Found,Please contact to PLM Team!!");
								return ifail;
							}

							//CE_current_user_session_tag(&userSession);
							

							AOM_ask_value_string(userSession,"role_name",&roleName);
							printf("\n NewPartReqItem_create_pre_condition::roleName====>[%s]", roleName);fflush(stdout);
							AOM_ask_value_string(userSession,"group_name",&grpName);
							printf("\n NewPartReqItem_create_pre_condition::grpName====>[%s]", grpName);fflush(stdout);
							
							Role_Name = (char *) MEM_alloc( 100 * sizeof(char));
							if(tc_strstr(roleName,"CAB")!=NULL)
							{
								if(designgroup!=NULL && tc_strlen(designgroup)>0)tc_strcpy(Role_Name,"CAB");
								tc_strcat(Role_Name,"_");
								tc_strcat(Role_Name,"Designers");
							}
							else
							{
								if(designgroup!=NULL && tc_strlen(designgroup)>0)tc_strcpy(Role_Name,designgroup);
								tc_strcat(Role_Name,"_");
								tc_strcat(Role_Name,"Designers");
							}
							
							
							SA_find_role2(Role_Name,&Roletag);
							if(Roletag!=NULLTAG)
							{
								SA_ask_current_groupmember(&current_groupmember_tag );
								SA_ask_groupmember_group (current_groupmember_tag,&grouptag) ;
								SA_find_groupmember_by_role(Roletag,grouptag,&memberfound,&Acknowledge_User);
							}
							SA_find_groupmember_by_rolename(Role_Name, grpName, user_id, &ackmemberfound, &AcknowledgeUser);
							//SA_find_user2(user_id,&RaisedBy);
							//SA_find_groupmember_by_user(user_tag,&userfind,&AcknowledgeUser);
							printf("\n Acknowledge Assignee-->[%d]\n",ackmemberfound);fflush(stdout);
							if(ackmemberfound>0)
							{
								
								EPM_get_participanttype ("T5_NwRaisedBy",&RaisedBy_Patricipant_Type);
								EPM_create_participant(AcknowledgeUser[0],RaisedBy_Patricipant_Type,&raisedby_participant);
								AOM_refresh(latestitemrev, TRUE);
								//ITEM_rev_add_participant(latestitemrev,raisedby_participant);
								PARTICIPANT_add_participant(latestitemrev,TRUE,raisedby_participant);
								AOM_save_without_extensions(latestitemrev);
								AOM_refresh(latestitemrev,FALSE);
							}
						}
						/*END FOR Auto Assign Reviewers NPR*/
					
					}
				}
			}
		}

	}
    return ifail;
}

/****************************************************************************
Function:       NewPartReq_create_pre_action
Description:    This function used for register custom method/handler 
				on class for different action like pre/post.
				code lsit of an user.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
/*
extern DLLAPI int NewPartReq_create_pre_action(METHOD_message_t *m, va_list args)
{

    int ifail=ITK_ok;	
    /***  va_list for TC_save_msg  ***
    tag_t item  = va_arg(args, tag_t);
    logical  isNew = va_arg(args, int);
    //logical  isNew = va_arg(args, logical);
	
    /***********************************


    char *item_type=NULL;
    char *itemId=NULL;
    char *prj_code=NULL;
    char *designgroup=NULL;
    char *designid=NULL;
    char *NwVehicleMdl=NULL;
    char *t5NwDgSbGrpDupS=NULL;
    char *t5NwDgSbGrpS=NULL;
    char *revision_id=NULL;
    char *CategoryName=NULL;
    char *ClsAtrCount=NULL;
    char *DeptNwPrt=NULL;
    char *inputIdsArr=NULL;
    char *inputValusArr=NULL;
    char *NwAggregate=NULL;
    char *NwCeId=NULL;
    char *NwChiefId=NULL;
    char *NwCocId=NULL;
    char *NwHeadEng=NULL;
    char *NwLCState=NULL;
    char *anyfileS=NULL;
    char *NwPrtVli=NULL;
    char *NwRaisedBy=NULL;
    char *NwReason=NULL;
    char *NwRefPtNo=NULL;
    char *NwRqNumber=NULL;
    char *NwThirdAttach=NULL;
    char *NwTypChng=NULL;
	char   *NwVcNo=NULL;
	char   *PartFamilyCls=NULL;
	char   *PartType=NULL;

	int n_tags_found= 0;
	logical			ExtPrtInd = false;
	logical			IsMirrorPaInd = false;
	logical			PrtCmoInd = false;
	logical			StdFldInd = false;
	logical			isFor12Digit = false;
	logical			isFor14Digit = false;
	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};
    
	
	logical hasBypass=false;
	
	tag_t userSession=NULLTAG;
	tag_t *t_item1=NULLTAG;
	tag_t t_NewPartReq=NULLTAG;
    AOM_ask_value_string(item,"object_type",&item_type);
    printf("\n **NewPartReq_create_pre_action::type_name = [%s]\n", item_type);fflush(stdout);
    if(tc_strcmp(item_type,"T5_NwPCreRevision")==0)
	{
		CALLAPI(CE_current_user_session_tag(&userSession));
		CALLAPI(AOM_ask_value_logical(userSession,"fnd0bypassflag",&hasBypass));
		if(hasBypass==false)
		{
			printf("\nHAS By pass Flag is FALSE") ;fflush(stdout);
			if(isNew==true)
			{
				/*All Custom Validation Called Here !!!!!*
				AOM_ask_value_string(item,"item_id",&itemId);
				printf("\n In NewPartReq_create_pre_action In Message Code ::NewPartReq Item ID %s\n",itemId);fflush(stdout);

				AOM_ask_value_string(item,"item_id",&itemId);
				printf("\n In NewPartReq_create_pre_action In Message Code ::NewPartReq Item ID %s\n",itemId);fflush(stdout);


				values[0] = itemId;
				values[1] = "New Part Request";
				ITEM_find_items_by_key_attributes(1, attrs, values, &n_tags_found, &t_item1);
				printf("\n NewPartReq_create_pre_action:: n_tags_found==>%d",n_tags_found);fflush(stdout);
				if(n_tags_found>0)
				{
					t_NewPartReq = t_item1[0];

					AOM_ask_value_string(t_NewPartReq,"item_id",&revision_id);
					printf("\n NewPartReq_create_pre_action:: revision_id====>[%s]", revision_id);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_ProjectCode",&prj_code);
					printf("\n NewPartReq_create_pre_action:: prj_code====>[%s]", prj_code);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_DesignGroup",&designgroup);
					printf("\n NewPartReq_create_pre_action:: designgroup====>[%s]", designgroup);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_NwDgId",&designid);
					printf("\n NewPartReq_create_pre_action:: designid====>[%s]", designid);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_CategoryName",&CategoryName);
					printf("\n NewPartReq_create_pre_action:: CategoryName====>[%s]", CategoryName);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_ClsAtrCount",&ClsAtrCount);
					printf("\n NewPartReq_create_pre_action:: ClsAtrCount====>[%s]", ClsAtrCount);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_DeptNwPrt",&DeptNwPrt);
					printf("\n NewPartReq_create_pre_action:: DeptNwPrt====>[%s]", DeptNwPrt);fflush(stdout);

					AOM_ask_value_logical(t_NewPartReq,"t5_ExtPrtInd",&ExtPrtInd);
					printf("\n NewPartReq_create_pre_action:: ExtPrtInd====>[%d]", ExtPrtInd);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_inputIdsArr",&inputIdsArr);
					printf("\n NewPartReq_create_pre_action:: inputIdsArr====>[%s]", inputIdsArr);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_inputValusArr",&inputValusArr);
					printf("\n NewPartReq_create_pre_action:: inputValusArr====>[%s]", inputValusArr);fflush(stdout);

					AOM_ask_value_logical(t_NewPartReq,"t5_IsMirrorPaInd",&IsMirrorPaInd);
					printf("\n NewPartReq_create_pre_action:: IsMirrorPaInd====>[%d]", IsMirrorPaInd);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_NwAggregate",&NwAggregate);
					printf("\n NewPartReq_create_pre_action:: NwAggregate====>[%s]", NwAggregate);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_NwCeId",&NwCeId);
					printf("\n NewPartReq_create_pre_action:: NwCeId====>[%s]", NwCeId);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_NwChiefId",&NwChiefId);
					printf("\n NewPartReq_create_pre_action:: NwChiefId====>[%s]", NwChiefId);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_NwCocId",&NwCocId);
					printf("\n NewPartReq_create_pre_action:: NwCocId====>[%s]", NwCocId);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_NwHeadEng",&NwHeadEng);
					printf("\n NewPartReq_create_pre_action:: NwHeadEng====>[%s]", NwHeadEng);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_NwLCState",&NwLCState);
					printf("\n NewPartReq_create_pre_action:: NwLCState====>[%s]", NwLCState);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_NwPrtAny",&anyfileS);
					printf("\n NewPartReq_create_pre_action:: anyfileS====>[%s]", anyfileS);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_NwPrtVli",&NwPrtVli);
					printf("\n NewPartReq_create_pre_action:: NwPrtVli====>[%s]", NwPrtVli);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_NwRaisedBy",&NwRaisedBy);
					printf("\n NewPartReq_create_pre_action:: NwRaisedBy====>[%s]", NwRaisedBy);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_NwReason",&NwReason);
					printf("\n NewPartReq_create_pre_action:: NwReason====>[%s]", NwReason);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_NwRefPtNo",&NwRefPtNo);
					printf("\n NewPartReq_create_pre_action:: NwRefPtNo====>[%s]", NwRefPtNo);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_NwRqNumber",&NwRqNumber);
					printf("\n NewPartReq_create_pre_action:: NwRqNumber====>[%s]", NwRqNumber);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_NwThirdAttach",&NwThirdAttach);
					printf("\n NewPartReq_create_pre_action:: NwThirdAttach====>[%s]", NwThirdAttach);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_NwTypChng",&NwTypChng);
					printf("\n NewPartReq_create_pre_action:: NwTypChng====>[%s]", NwTypChng);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_NwVcNo",&NwVcNo);
					printf("\n NewPartReq_create_pre_action:: NwVcNo====>[%s]", NwVcNo);fflush(stdout);
					
					AOM_ask_value_string(t_NewPartReq,"t5_NwVehicleMdl",&NwVehicleMdl);
					printf("\n NewPartReq_create_pre_action:: NwVehicleMdl====>[%s]", NwVehicleMdl);fflush(stdout);

					AOM_ask_value_string(t_NewPartReq,"t5_PartFamilyCls",&PartFamilyCls);
					printf("\n NewPartReq_create_pre_action:: PartFamilyCls====>[%s]", PartFamilyCls);fflush(stdout);
					
					AOM_ask_value_string(t_NewPartReq,"t5_PartType",&PartType);
					printf("\n NewPartReq_create_pre_action:: PartType====>[%s]", PartType);fflush(stdout);

					AOM_ask_value_logical(t_NewPartReq,"t5_PrtCmoInd",&PrtCmoInd);
					printf("\n NewPartReq_create_pre_action:: PrtCmoInd====>[%d]", PrtCmoInd);fflush(stdout);

					AOM_ask_value_logical(t_NewPartReq,"t5_StdFldInd",&StdFldInd);
					printf("\n NewPartReq_create_pre_action:: StdFldInd====>[%d]", StdFldInd);fflush(stdout);

					AOM_ask_value_logical(t_NewPartReq,"t5_Is12Digit",&isFor12Digit);
					printf("\n NewPartReq_create_pre_action:: isFor12Digit====>[%d]", isFor12Digit);fflush(stdout);

					AOM_ask_value_logical(t_NewPartReq,"t5_Is14Digit",&isFor14Digit);
					printf("\n NewPartReq_create_pre_action:: isFor14Digit====>[%d]", isFor14Digit);fflush(stdout);
				}
			}
		}

	}
    return ifail;
}
*/

/****************************************************************************
Function:       NewPartReq_Create_postaction
Description:    This function used to assign project while create an assembly
Input:          None
Output:         None
Return value:   None
****************************************************************************/
int NewPartReq_Create_postaction(METHOD_message_t *msg, va_list args)
{
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag = NULLTAG;
	tag_t project	 = NULLTAG;

	tag_t	master		=	NULLTAG;
	tag_t	*t_item1		=	NULLTAG;
	tag_t	*q_item1		=	NULLTAG;
	tag_t	latestrev	=	NULLTAG;
	tag_t	query	=	NULLTAG;


	char   *newpartreqnumber=NULL;
	char   *prj_code=NULL;
	char   *itemId=NULL;
	char   *BussiNameS=NULL;
	char   *Proj_typ=NULL;
	char   *revision_id=NULL;
	char   *designgroup=NULL;
	char   *designid=NULL;
	char   *user_id=NULL;
	char   *GroupNameS=NULL;
	char   *GroupNameDup=NULL;
	char   *CategoryName=NULL;
	char   *ClsAtrCount=NULL;
	char   *DeptNwPrt=NULL;
	char   *inputIdsArr=NULL;
	char   *inputValusArr=NULL;
	char   *NwAggregate=NULL;
	char   *NwCeId=NULL;
	char   *NwChiefId=NULL;
	char   *NwCocId=NULL;
	char   *NwHeadEng=NULL;
	char   *NwLCState=NULL;
	char   *anyfileS=NULL;
	char   *NwPrtVli=NULL;
	char   *NwRaisedBy=NULL;
	char   *NwReason=NULL;
	char   *NwRefPtNo=NULL;
	char   *NwRqNumber=NULL;
	char   *NwThirdAttach=NULL;
	char   *NwTypChng=NULL;
	char   *NwVcNo=NULL;
	char   *NwVehicleMdl=NULL;
	char   *PartFamilyCls=NULL;
	char   *PartType=NULL;
	char   *any_type=NULL;
	char   *vli_type=NULL;
	char   *three_type=NULL;
	char   *suf1=NULL;
	char   *suf2=NULL;
	char   *suf3=NULL;


	char           *ExtFirFile	= NULL;
	char           *SecExtFirFile	= NULL;
	char           *ThirdExtFirFile	= NULL;
	char           *tok	= NULL;
	char           *tok2	= NULL;
	char           *tok3	= NULL;
	char           *NewFileNameS_any	= NULL;
	char           *NewFileNameS_vli	= NULL;
	char           *NewFileNameS_three	= NULL;
	char           *any	= NULL;
	char           *vli	= NULL;
	char           *three	= NULL;
	char           *ErcGroupName	= NULL;
	char           *GroupNameS1	= NULL;
	char           *GroupName1Dup	= NULL;
	char           *masteritemId	= NULL;

	logical			ExtPrtInd = false;
	logical			IsMirrorPaInd = false;
	logical			PrtCmoInd = false;
	logical			StdFldInd = false;
	logical			isFor12Digit = false;
	logical			isFor14Digit = false;

	int n_tags_found = 0;

	int n_found =0;
	int CheckApplicable =0;
	int r,w =0;
	int g =0;
	int h =0;
	int p =0;
	int e =0;
	int userfind =0;

	const char*   head_role_name = "COC_Head";
	const char*   cocprincipal_role_name = "COCPrinciple";
	const char*   Modulerole_name = "Module";
	const char*   pvburole_name = "PVBU";
	const char*   role_name = "Manager";
	

	tag_t   role_tag			= NULLTAG;
    tag_t   group_tag			= NULLTAG;
    tag_t   current_groupmember_tag =NULLTAG;
	tag_t*  members				= NULLTAG;
	tag_t   coc_id  = NULLTAG;
	tag_t   coc_principle  = NULLTAG;
	tag_t   coc_head  = NULLTAG;
	tag_t   head_engg  = NULLTAG;
	tag_t   pvbu_coc_id  = NULLTAG;
	tag_t   user_tag = NULLTAG;
	tag_t		datasettype_any = NULLTAG;
	tag_t		Newdataset_any = NULLTAG;
	tag_t		filetag_any = NULLTAG;
	tag_t		tool_any = NULLTAG;
	tag_t		relation_type_any = NULLTAG;
	tag_t		relation_any = NULLTAG;

	tag_t		datasettype_vli = NULLTAG;
	tag_t		Newdataset_vli = NULLTAG;
	tag_t		filetag_vli = NULLTAG;
	tag_t		tool_vli = NULLTAG;
	tag_t		relation_type_vli = NULLTAG;
	tag_t		relation_vli = NULLTAG;

	tag_t		datasettype_three = NULLTAG;
	tag_t		Newdataset_three = NULLTAG;
	tag_t		filetag_three = NULLTAG;
	tag_t		tool_three = NULLTAG;
	tag_t		relation_type_three = NULLTAG;
	tag_t		relation_three = NULLTAG;
	tag_t		latestitemrev = NULLTAG;
	tag_t		Module_Patricipant_Type = NULLTAG;
	tag_t		module_participant = NULLTAG;
	tag_t		COCPrinciple_Patricipant_Type = NULLTAG;
	tag_t		cocprinciple_participant = NULLTAG;
	tag_t		COCHead_Patricipant_Type = NULLTAG;
	tag_t		cochead_participant = NULLTAG;
	tag_t		HeadEngg_Patricipant_Type = NULLTAG;
	tag_t		headengg_participant = NULLTAG;
	tag_t		PVBU_Patricipant_Type = NULLTAG;
	tag_t		pvbu_participant = NULLTAG;
	tag_t		RaisedBy = NULLTAG;
	tag_t		RaisedBy_Patricipant_Type = NULLTAG;
	tag_t		raisedby_participant = NULLTAG;
	tag_t		*AcknowledgeUser = NULLTAG;
	tag_t		ModRevrole_tag = NULLTAG;
	tag_t		*ModRevmembers = NULLTAG;
	tag_t		ModReviwer_id = NULLTAG;
	tag_t		Module_Proposed_Type = NULLTAG;
	tag_t		modulerev_participant = NULLTAG;
	
	

	int          member_found = 0;
	int          ModRevmember_found = 0;

	logical			checkout_any = 0;
	logical			checkout_vli = 0;
	logical			checkout_three = 0;

	const char		*reason_any	= "";
	const char		*change_id_any	= "";
	const char		*dir_name_any = "";
	int				reservation_type_any = 2;

	const char		*reason_vli	= "";
	const char		*change_id_vli	= "";
	const char		*dir_name_vli = "";
	int				reservation_type_vli = 2;

	const char		*reason_three	= "";
	const char		*change_id_three	= "";
	const char		*dir_name_three = "";
	int				reservation_type_three = 2;
	

	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};

	char
        *qry_entries3[2] = {"Name","Type"},
        *qry_values3[2]	= {"*","*"};

	//char   type_name[TCTYPE_name_size_c+1];
	char           *type_name	= NULL;

	int error_code = ITK_ok;

	printf("\n In NewPartReq_Create_postaction In Custom Message Code\n");fflush(stdout);

	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack(); 

	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();

	printf("\n In NewPartReq_Create_postaction In Message Code Type Of Selected Item Is= [%s]\n",type_name);fflush(stdout);

	POM_get_user_id(&user_id);
	SA_find_user2(user_id, &user_tag);

	if(strcmp(type_name,"T5_NwPCreRevision")==0)
	{
		if(ITEM_ask_item_of_rev  ( objTag,&master) );
		if(ITEM_ask_latest_rev(master,&latestitemrev));
		AOM_ask_value_string(latestitemrev,"item_id",&itemId);
		AOM_ask_value_string(master,"item_id",&masteritemId);
		printf("\n In NewPartReq_Create_postaction In Message Code ::NewPartReqRevision Item ID %s\n",itemId);fflush(stdout);
		printf("\n In NewPartReq_Create_postaction In Message Code ::NewPartReq Item ID %s\n",masteritemId);fflush(stdout);

		AOM_ask_value_string(latestitemrev,"item_id",&newpartreqnumber);
		printf("\n In NewPartReq_Create_postaction In Message Code ::NewPartReq NEW-PART-REQUEST-NUMBER [%s]\n",newpartreqnumber);fflush(stdout);

		AOM_refresh( latestitemrev, TRUE);
		AOM_set_value_string(latestitemrev, "object_name", newpartreqnumber);
		AOM_set_value_string(latestitemrev,"object_desc",newpartreqnumber);
		AOM_save_without_extensions(latestitemrev);
		AOM_refresh(latestitemrev,FALSE);
		
		 
		//attrs[0] ="item_id";
		//attrs[1] ="object_type";
		values[0] = itemId;
		values[1] = "T5_NwPCre";
		ITEM_find_items_by_key_attributes(2, attrs, values, &n_tags_found, &t_item1);
		printf("\n n_tags_found [%d]", n_tags_found);fflush(stdout);

		if(n_tags_found>0)
		{
			latestrev = t_item1[0];
			AOM_ask_value_string(latestrev,"item_id",&revision_id);
			printf("\n AAAAA revision_id====>[%s]", revision_id);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_ProjectCode",&prj_code);
			printf("\n AAAAA prj_code====>[%s]", prj_code);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_DesignGroup",&designgroup);
			printf("\n AAAAA designgroup====>[%s]", designgroup);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_NwDgId",&designid);
			printf("\n AAAAA designid====>[%s]", designid);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_CategoryName",&CategoryName);
			printf("\n AAAAA CategoryName====>[%s]", CategoryName);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_ClsAtrCount",&ClsAtrCount);
			printf("\n AAAAA ClsAtrCount====>[%s]", ClsAtrCount);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_DeptNwPrt",&DeptNwPrt);
			printf("\n AAAAA DeptNwPrt====>[%s]", DeptNwPrt);fflush(stdout);

			AOM_ask_value_logical(latestrev,"t5_ExtPrtInd",&ExtPrtInd);
			printf("\n AAAAA ExtPrtInd====>[%d]", ExtPrtInd);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_inputIdsArr",&inputIdsArr);
			printf("\n AAAAA inputIdsArr====>[%s]", inputIdsArr);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_inputValusArr",&inputValusArr);
			printf("\n AAAAA inputValusArr====>[%s]", inputValusArr);fflush(stdout);

			AOM_ask_value_logical(latestrev,"t5_IsMirrorPaInd",&IsMirrorPaInd);
			printf("\n AAAAA IsMirrorPaInd====>[%d]", IsMirrorPaInd);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_NwAggregate",&NwAggregate);
			printf("\n AAAAA NwAggregate====>[%s]", NwAggregate);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_NwCeId",&NwCeId);
			printf("\n AAAAA NwCeId====>[%s]", NwCeId);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_NwChiefId",&NwChiefId);
			printf("\n AAAAA NwChiefId====>[%s]", NwChiefId);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_NwCocId",&NwCocId);
			printf("\n AAAAA NwCocId====>[%s]", NwCocId);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_NwHeadEng",&NwHeadEng);
			printf("\n AAAAA NwHeadEng====>[%s]", NwHeadEng);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_NwLCState",&NwLCState);
			printf("\n AAAAA NwLCState====>[%s]", NwLCState);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_NwPrtAny",&anyfileS);
			printf("\n AAAAA anyfileS====>[%s]", anyfileS);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_NwPrtVli",&NwPrtVli);
			printf("\n AAAAA NwPrtVli====>[%s]", NwPrtVli);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_NwRaisedBy",&NwRaisedBy);
			printf("\n AAAAA NwRaisedBy====>[%s]", NwRaisedBy);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_NwReason",&NwReason);
			printf("\n AAAAA NwReason====>[%s]", NwReason);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_NwRefPtNo",&NwRefPtNo);
			printf("\n AAAAA NwRefPtNo====>[%s]", NwRefPtNo);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_NwRqNumber",&NwRqNumber);
			printf("\n AAAAA NwRqNumber====>[%s]", NwRqNumber);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_NwThirdAttach",&NwThirdAttach);
			printf("\n AAAAA NwThirdAttach====>[%s]", NwThirdAttach);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_NwTypChng",&NwTypChng);
			printf("\n AAAAA NwTypChng====>[%s]", NwTypChng);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_NwVcNo",&NwVcNo);
			printf("\n AAAAA NwVcNo====>[%s]", NwVcNo);fflush(stdout);
			
			AOM_ask_value_string(latestrev,"t5_NwVehicleMdl",&NwVehicleMdl);
			printf("\n AAAAA NwVehicleMdl====>[%s]", NwVehicleMdl);fflush(stdout);

			AOM_ask_value_string(latestrev,"t5_PartFamilyCls",&PartFamilyCls);
			printf("\n AAAAA PartFamilyCls====>[%s]", PartFamilyCls);fflush(stdout);
			
			AOM_ask_value_string(latestrev,"t5_PartType",&PartType);
			printf("\n AAAAA PartType====>[%s]", PartType);fflush(stdout);

			AOM_ask_value_logical(latestrev,"t5_PrtCmoInd",&PrtCmoInd);
			printf("\n AAAAA PrtCmoInd====>[%d]", PrtCmoInd);fflush(stdout);

			AOM_ask_value_logical(latestrev,"t5_StdFldInd",&StdFldInd);
			printf("\n AAAAA StdFldInd====>[%d]", StdFldInd);fflush(stdout);

			AOM_ask_value_logical(latestrev,"t5_Is12Digit",&isFor12Digit);
			printf("\n AAAAA isFor12Digit====>[%d]", isFor12Digit);fflush(stdout);

			AOM_ask_value_logical(latestrev,"t5_Is14Digit",&isFor14Digit);
			printf("\n AAAAA isFor14Digit====>[%d]", isFor14Digit);fflush(stdout);

			/*
			if(anyfileS!=NULL && strlen(anyfileS)>0)
			{
				suf1 = strdup(anyfileS);
				printf("\n Value of suf1    ------->[%s]\n ",suf1);
				if(strcmp(suf1,"NA")!= 0)
				{	
					tok = strtok(suf1, ".");
					printf("\n After tok suf1 value  ------->[%s]\n ",tok);fflush(stdout);
					tok = strtok(NULL, ".");
					ExtFirFile= tok; 
					
				}
				if(strcasecmp(ExtFirFile,"txt") == 0)
				{
					any="Text";
					any_type = "Text";
				}

				
				if(strcasecmp(ExtFirFile,"jpg") == 0)
				{
					any="JPEG_Reference";
					any_type = "JPEG";
				}

				if(strcasecmp(ExtFirFile,"png") == 0)
				{
					any="JPEG_Reference";
					any_type = "JPEG";
				}

				if(strcasecmp(ExtFirFile,"xls") == 0)
				{
					any = "excel";
					any_type = "MSExcel";
				}

				if(strcasecmp(ExtFirFile,"doc") == 0)
				{
					any = "word";
					any_type = "MSWord";
				}

				if(strcasecmp(ExtFirFile,"pdf") == 0)
				{
					any = "PDF_Reference";
					any_type = "PDF";
				}

				if(strcasecmp(ExtFirFile,"ppt") == 0)
				{
					any = "powerpoint";
					any_type = "MSPowePoint";
				}

				if(strcasecmp(ExtFirFile,"pptx") == 0)
				{
					any = "powerpoint";
					any_type = "MSPowePointX";
				}

				if(strcasecmp(ExtFirFile,"docx") == 0)
				{
					any = "word";
					any_type = "MSWordX";
				}

				if(strcasecmp(ExtFirFile,"xlsx") == 0)
				{
					any = "excel";
					any_type = "MSExcelX";
				}

				if(strcasecmp(ExtFirFile,"jpeg") == 0)
				{
					any = "JPEG_Reference";
					any_type = "JPEG";
				}

				if(strcasecmp(ExtFirFile,"bmp") == 0)
				{
					any = "JPEG_Reference";
					any_type = "JPEG";
				}
				
				if(strcasecmp(ExtFirFile,"msg") == 0)
				{
					any = "Outlook-Msg";
					any_type = "Outlook";
				}


				printf("\n Extension of First File is  ------->[%s]\n ",ExtFirFile);fflush(stdout);
				newpartreqnumber = (char *) MEM_alloc( 100 * sizeof(char) );
				tc_strcpy(newpartreqnumber,prj_code);
				tc_strcat(GroupNameS,designgroup);
				NewFileNameS_any = (char *) MEM_alloc( 100 * sizeof(char) );
				strcpy(NewFileNameS_any,itemId);
				strcat(NewFileNameS_any,"_1.");
				strcat(NewFileNameS_any,ExtFirFile);
				printf(" #######Attachment 1  (%s)########\n",NewFileNameS_any);fflush(stdout);
				AE_find_datasettype(any_type, &datasettype_any);
				AE_create_dataset_with_id(datasettype_any,NewFileNameS_any,NewFileNameS_any, NULL, NULL, &Newdataset_any);
				AE_set_dataset_format(Newdataset_any, "BINARY_REF");
				AE_ask_datasettype_def_tool(datasettype_any, &tool_any);
				AE_set_dataset_tool(Newdataset_any,tool_any);
				AOM_save_without_extensions(Newdataset_any);
				if(latestitemrev!=NULLTAG && Newdataset_any!=NULLTAG)
				{
					RES_is_checked_out(Newdataset_any,&checkout_any);
					if (checkout_any==0)
					{
						RES_checkout2(Newdataset_any,reason_any,change_id_any,dir_name_any,reservation_type_any);
						printf("\n %d DataSet Checked Out \n");fflush(stdout);
					}
					GRM_find_relation_type("IMAN_specification", &relation_type_any);
					GRM_create_relation(latestitemrev, Newdataset_any, relation_type_any, NULLTAG, &relation_any);
					GRM_save_relation(relation_any);
				}
			}

			if(NwPrtVli!=NULL && strlen(NwPrtVli)>0)
			{
				suf2 = strdup(NwPrtVli);
				printf("\n Value of suf2    ------->[%s]\n ",suf2);
				if(strcmp(suf2,"NA")!= 0)
				{	
					tok2 = strtok(suf2, ".");
					printf("\n After tok suf2 value  ------->[%s]\n ",tok2);fflush(stdout);
					tok2 = strtok(NULL, ".");
					SecExtFirFile= tok2; 
					
				}
				if(strcasecmp(SecExtFirFile,"txt") == 0)
				{
					vli="Text";
					vli_type = "Text";
				}

				
				if(strcasecmp(SecExtFirFile,"jpg") == 0)
				{
					any="JPEG_Reference";
					vli_type = "JPEG";
				}

				if(strcasecmp(SecExtFirFile,"png") == 0)
				{
					vli="JPEG_Reference";
					vli_type = "JPEG";
				}

				if(strcasecmp(SecExtFirFile,"xls") == 0)
				{
					vli = "excel";
					vli_type = "MSExcel";
				}

				if(strcasecmp(SecExtFirFile,"doc") == 0)
				{
					vli = "word";
					vli_type = "MSWord";
				}

				if(strcasecmp(SecExtFirFile,"pdf") == 0)
				{
					vli = "PDF_Reference";
					vli_type = "PDF";
				}

				if(strcasecmp(SecExtFirFile,"ppt") == 0)
				{
					vli = "powerpoint";
					vli_type = "MSPowePoint";
				}

				if(strcasecmp(SecExtFirFile,"pptx") == 0)
				{
					vli = "powerpoint";
					vli_type = "MSPowePointX";
				}

				if(strcasecmp(SecExtFirFile,"docx") == 0)
				{
					vli = "word";
					vli_type = "MSWordX";
				}

				if(strcasecmp(SecExtFirFile,"xlsx") == 0)
				{
					vli = "excel";
					vli_type = "MSExcelX";
				}

				if(strcasecmp(SecExtFirFile,"jpeg") == 0)
				{
					vli = "JPEG_Reference";
					vli_type = "JPEG";
				}

				if(strcasecmp(SecExtFirFile,"bmp") == 0)
				{
					vli = "JPEG_Reference";
					vli_type = "JPEG";
				}
				
				if(strcasecmp(SecExtFirFile,"msg") == 0)
				{
					vli = "Outlook-Msg";
					vli_type = "Outlook";
				}


				printf("\n Extension of First File is  ------->[%s]\n ",SecExtFirFile);fflush(stdout);
				NewFileNameS_vli = (char *) MEM_alloc( 100 * sizeof(char) );
				strcpy(NewFileNameS_vli,itemId);
				strcat(NewFileNameS_vli,"_2.");
				strcat(NewFileNameS_vli,SecExtFirFile);
				printf(" #######Attachment 1  (%s)########\n",NewFileNameS_vli);fflush(stdout);
				AE_find_datasettype(vli_type, &datasettype_vli);
				AE_create_dataset_with_id(datasettype_vli,NewFileNameS_vli,NewFileNameS_vli, NULL, NULL, &Newdataset_vli);
				AE_set_dataset_format(Newdataset_vli, "BINARY_REF");
				AE_ask_datasettype_def_tool(datasettype_vli, &tool_vli);
				AE_set_dataset_tool(Newdataset_vli,tool_vli);
				AOM_save_without_extensions(Newdataset_vli);
				if(latestitemrev!=NULLTAG && Newdataset_vli!=NULLTAG)
				{
					RES_is_checked_out(Newdataset_vli,&checkout_vli);
					if (checkout_vli==0)
					{
						RES_checkout2(Newdataset_vli,reason_vli,change_id_vli,dir_name_vli,reservation_type_vli);
						printf("\n %d DataSet Checked Out \n");fflush(stdout);
					}
					GRM_find_relation_type("IMAN_specification", &relation_type_vli);
					GRM_create_relation(latestitemrev, Newdataset_vli, relation_type_vli, NULLTAG, &relation_vli);
					GRM_save_relation(relation_vli);
				}
			}

			if(NwThirdAttach!=NULL && strlen(NwThirdAttach)>0)
			{
				suf3 = strdup(NwThirdAttach);
				printf("\n Value of suf1    ------->[%s]\n ",suf3);
				if(strcmp(suf3,"NA")!= 0)
				{	
					tok3 = strtok(suf3, ".");
					printf("\n After tok suf2 value  ------->[%s]\n ",tok3);fflush(stdout);
					tok3 = strtok(NULL, ".");
					ThirdExtFirFile= tok3; 
					
				}
				if(strcasecmp(ThirdExtFirFile,"txt") == 0)
				{
					vli="Text";
					three_type = "Text";
				}

				
				if(strcasecmp(ThirdExtFirFile,"jpg") == 0)
				{
					any="JPEG_Reference";
					three_type = "JPEG";
				}

				if(strcasecmp(ThirdExtFirFile,"png") == 0)
				{
					three="JPEG_Reference";
					three_type = "JPEG";
				}

				if(strcasecmp(ThirdExtFirFile,"xls") == 0)
				{
					three = "excel";
					three_type = "MSExcel";
				}

				if(strcasecmp(ThirdExtFirFile,"doc") == 0)
				{
					three = "word";
					three_type = "MSWord";
				}

				if(strcasecmp(ThirdExtFirFile,"pdf") == 0)
				{
					three = "PDF_Reference";
					three_type = "PDF";
				}

				if(strcasecmp(ThirdExtFirFile,"ppt") == 0)
				{
					three = "powerpoint";
					three_type = "MSPowePoint";
				}

				if(strcasecmp(ThirdExtFirFile,"pptx") == 0)
				{
					three = "powerpoint";
					three_type = "MSPowePointX";
				}

				if(strcasecmp(ThirdExtFirFile,"docx") == 0)
				{
					three = "word";
					three_type = "MSWordX";
				}

				if(strcasecmp(ThirdExtFirFile,"xlsx") == 0)
				{
					three = "excel";
					three_type = "MSExcelX";
				}

				if(strcasecmp(ThirdExtFirFile,"jpeg") == 0)
				{
					three = "JPEG_Reference";
					three_type = "JPEG";
				}

				if(strcasecmp(ThirdExtFirFile,"bmp") == 0)
				{
					three = "JPEG_Reference";
					three_type = "JPEG";
				}
				
				if(strcasecmp(ThirdExtFirFile,"msg") == 0)
				{
					three = "Outlook-Msg";
					three_type = "Outlook";
				}


				printf("\n Extension of First File is  ------->[%s]\n ",ThirdExtFirFile);fflush(stdout);
				NewFileNameS_three = (char *) MEM_alloc( 100 * sizeof(char) );
				strcpy(NewFileNameS_three,itemId);
				strcat(NewFileNameS_three,"_3.");
				strcat(NewFileNameS_three,ThirdExtFirFile);
				printf(" #######Attachment 1  (%s)########\n",NewFileNameS_three);fflush(stdout);
				AE_find_datasettype(three_type, &datasettype_three);
				AE_create_dataset_with_id(datasettype_three,NewFileNameS_three,NewFileNameS_three, NULL, NULL, &Newdataset_three);
				AE_set_dataset_format(Newdataset_three, "BINARY_REF");
				AE_ask_datasettype_def_tool(datasettype_three, &tool_three);
				AE_set_dataset_tool(Newdataset_three,tool_three);
				AOM_save_without_extensions(Newdataset_three);
				if(latestitemrev!=NULLTAG && Newdataset_three!=NULLTAG)
				{
					RES_is_checked_out(Newdataset_three,&checkout_three);
					if (checkout_three==0)
					{
						RES_checkout2(Newdataset_three,reason_three,change_id_three,dir_name_three,reservation_type_three);
						printf("\n %d DataSet Checked Out \n");fflush(stdout);
					}
					GRM_find_relation_type("IMAN_specification", &relation_type_three);
					GRM_create_relation(latestitemrev, Newdataset_three, relation_type_three, NULLTAG, &relation_three);
					GRM_save_relation(relation_three);
				}
			}
			*/

		

			qry_values3[0]	= prj_code;
			qry_values3[1]	= "Project";
			QRY_find2("Item...", &query);
			QRY_execute(query, 2, qry_entries3, qry_values3, &n_found, &q_item1);
			printf("\n n_found =[%d]",n_found);
			if(n_found>0)
			{
				AOM_ask_value_string(q_item1[0],"t5_BussUnitType",&BussiNameS);
				printf("\n AAAAA BussiNameS====>[%s]", BussiNameS);fflush(stdout);
				AOM_ask_value_string(q_item1[0],"t5_ProjectType",&Proj_typ);
				printf("\n AAAAA Proj_typ====>[%s]", Proj_typ);fflush(stdout);

				if(tc_strcmp(Proj_typ,"E")==0 || (tc_strcmp(Proj_typ,"G")==0))
				{
					printf("\n Inside the project type as Engine or GearBox");fflush(stdout);
					printf("\n Inside the project type as Engine or GearBox %s",prj_code);fflush(stdout);
					if(tc_strcmp(Proj_typ,"E")==0)
					{
						printf("\n Inside the project type as Engine or GearBox %s",designgroup);fflush(stdout);
						printf("\n Inside the project type as Engine or GearBox %s",designgroup);fflush(stdout);
						//if(isFor12Digit==true && isFor14Digit==false)
						if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
						{
							if(tc_strcmp(designgroup,"50")==0)
							{
								 if(tc_strcmp(designid,"33")==0)
								{
									CheckApplicable=1;
									printf("\n Check is applicable to design group 50 and designation id -33 \n");fflush(stdout);
								}
										
							}
							else if(tc_strcmp(designgroup,"23")==0)
							{
								if((tc_strcmp(designid,"33")==0) || (tc_strcmp(designid,"37")==0) || (tc_strcmp(designid,"38")==0))
								{
									CheckApplicable=1;
									printf("\n Check is applicable to design group 23 and designation id -33/37/38 \n");fflush(stdout);
								}

							}
						}
						else
						{
							CheckApplicable = 0;
							
						}
						
					}
					else if(tc_strcmp(Proj_typ,"G")==0)
					{
						//if(isFor12Digit==true && isFor14Digit==false)
						if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
						{
							if(tc_strcmp(designgroup,"26")==0)
							{
								 if((tc_strcmp(designid,"31")==0) || (tc_strcmp(designid,"77")==0) || (tc_strcmp(designid,"78")==0) || (tc_strcmp(designid,"86")==0) ||(tc_strcmp(designid,"65")==0))
								{
									CheckApplicable=1;
									printf("\n Gear-Box Check is applicable to design group 26 and designation id -33 \n");fflush(stdout);
								}
										
							}
							else if(tc_strcmp(designgroup,"35")==0)
							{
								if((tc_strcmp(designid,"31")==0) || (tc_strcmp(designid,"77")==0) || (tc_strcmp(designid,"78")==0) || (tc_strcmp(designid,"86")==0) ||(tc_strcmp(designid,"65")==0))
								{
									CheckApplicable=1;
									printf("\n Gear-Box Check is applicable to design group 35 and designation id -33/37/38 \n");fflush(stdout);
								}

							}
						}
						else
						{
							CheckApplicable = 0;
							
						}
						
					}
					if(CheckApplicable== 1)
					{
						ErcGroupName = (char *) MEM_alloc( 100 * sizeof(char) );
						GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
						GroupNameDup = (char *) MEM_alloc( 100 * sizeof(char) );

						

						printf("\n FOR CheckApplicable  Project code ---- %s\n", prj_code);fflush(stdout);
						printf("\n FOR CheckApplicable Design code ---- %s\n", designgroup);fflush(stdout);
						tc_strcpy(GroupNameS,prj_code);
						tc_strcat(GroupNameS,"_");
						tc_strcat(GroupNameS,designgroup);
						tc_strcat(GroupNameS,"_");
						tc_strcat(GroupNameS,"Module");

						GroupNameS1 = (char *) MEM_alloc( 200 * sizeof(char) );
						GroupName1Dup = (char *) MEM_alloc( 200 * sizeof(char) );
						//tc_strcpy(GroupNameS1,designgroup);
						//tc_strcat(GroupNameS1,"_");
						//tc_strcat(GroupNameS1,"New");
						//tc_strcat(GroupNameS1,"_");
						//tc_strcat(GroupNameS1,"ModuleReviewer");

						tc_strcpy(GroupNameS1,"MCCReviewer");
						if(GroupNameS1)
						{
							tc_strcpy(GroupName1Dup,GroupNameS1);
						}

						//tc_strcat(GroupNameS,"*");
						if(GroupNameS)
						{
							tc_strcpy(GroupNameDup,GroupNameS);
						}
						

						printf(" \n For Engine and Gear Box Access group name is created with name-- (%s) $$$$ \n",GroupNameDup);fflush(stdout);
						printf(" \n For Engine and Gear Box Access group name is created with name-- (%s) $$$$ \n",GroupName1Dup);fflush(stdout);

						tc_strcpy(ErcGroupName,"ERC_Designers_Group");
						SA_find_group(ErcGroupName, &group_tag);
						
						//CALLAPI(SA_find_groupmember_by_rolename(role_name, GroupNameDup, user_id, &number_found, &members));
						SA_find_role2(GroupNameDup,&role_tag);

						SA_find_role2(GroupName1Dup,&ModRevrole_tag);
						//SA_ask_current_groupmember(&current_groupmember_tag );
						//SA_ask_groupmember_group (current_groupmember_tag,&group_tag) ;
						if(group_tag!=NULLTAG)
						{
							SA_find_groupmember_by_role(role_tag,group_tag,&member_found,&members);
							printf("\n member_found==>[%d] \n",member_found);fflush(stdout);
							if(member_found>0)
							{
								//coc_id = members[0];
								AOM_refresh( latestrev, TRUE);
								AOM_set_value_string(latestrev,"t5_NwCocId",GroupNameDup);
								AOM_save_without_extensions(latestrev);
								AOM_refresh(latestrev,FALSE);
								printf("\n For Engine and Gear Box Module Team Lead value set \n");fflush(stdout);

								r=0;
								for(r=0 ; r<member_found; r++)
								{	
									printf("\n Modeule_Reviewer: %d",r+1);fflush(stdout);
									coc_id = members[r];
									if(EPM_get_participanttype ("T5_Modeule_Reviewer",&Module_Patricipant_Type)!=ITK_ok) PrintErrorStack();
									if(EPM_create_participant(coc_id,Module_Patricipant_Type,&module_participant)!=ITK_ok) PrintErrorStack();
									AOM_refresh(latestitemrev, TRUE);
									//if(ITEM_rev_add_participant(latestitemrev,module_participant)!=ITK_ok)PrintErrorStack();
									PARTICIPANT_add_participant(latestitemrev,TRUE,module_participant);
									AOM_save_without_extensions(latestitemrev);
									AOM_refresh(latestitemrev,FALSE);
								}
							}
							SA_find_groupmember_by_role(ModRevrole_tag,group_tag,&ModRevmember_found,&ModRevmembers);
							if(ModRevmember_found>0)
							{
								//coc_id = members[0];
								AOM_refresh( latestrev, TRUE);
								AOM_set_value_string(latestrev,"t5_ModuleReviewer",GroupName1Dup);
								AOM_save_without_extensions(latestrev);
								AOM_refresh(latestrev,FALSE);
								printf("\n For Engine and Gear Box Module Team Lead value set \n");fflush(stdout);

								w=0;
								for(w=0 ; w<ModRevmember_found; w++)
								{	
									printf("\n Modeule_Reviewer: %d",w+1);fflush(stdout);
									ModReviwer_id = ModRevmembers[w];
									if(EPM_get_participanttype ("ProposedReviewer",&Module_Proposed_Type)!=ITK_ok) PrintErrorStack();
									if(EPM_create_participant(ModReviwer_id,Module_Proposed_Type,&modulerev_participant)!=ITK_ok) PrintErrorStack();
									AOM_refresh(latestitemrev, TRUE);
									//if(ITEM_rev_add_participant(latestitemrev,modulerev_participant)!=ITK_ok)PrintErrorStack();
									PARTICIPANT_add_participant(latestitemrev,TRUE,modulerev_participant);
									AOM_save_without_extensions(latestitemrev);
									AOM_refresh(latestitemrev,FALSE);
								}
							}
						}
						MEM_free(members);
						MEM_free(ModRevmembers);
						
					}
				}

				if(CheckApplicable== 0)
				{
					printf("\n Value of Bussiness Unit (%s) \n",BussiNameS);fflush(stdout);
					if(strcmp(BussiNameS,"CVBU")==0)
					{
						ErcGroupName = (char *) MEM_alloc( 100 * sizeof(char) );
						GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
						GroupNameDup = (char *) MEM_alloc( 100 * sizeof(char) );
						tc_strcpy(GroupNameS,designgroup);
						tc_strcat(GroupNameS,"_");
						tc_strcat(GroupNameS,"New");
						tc_strcat(GroupNameS,"_");
						tc_strcat(GroupNameS,"Module");

						GroupNameS1 = (char *) MEM_alloc( 200 * sizeof(char) );
						GroupName1Dup = (char *) MEM_alloc( 200 * sizeof(char) );
						//tc_strcpy(GroupNameS1,designgroup);
						//tc_strcat(GroupNameS1,"_");
						//tc_strcat(GroupNameS1,"New");
						//tc_strcat(GroupNameS1,"_");
						//tc_strcat(GroupNameS1,"ModuleReviewer");

						tc_strcpy(GroupNameS1,"MCCReviewer");
						if(GroupNameS1)
						{
							tc_strcpy(GroupName1Dup,GroupNameS1);
						}

						printf(" \n $$$$ Temporary Request No created with name (%s) $$$$ \n",GroupNameS);fflush(stdout);
						printf(" \n $$$$ Temporary Request No created with name (%s) $$$$ \n",GroupName1Dup);fflush(stdout);
						if(GroupNameS)
						{
							tc_strcpy(GroupNameDup,GroupNameS);
						}
						tc_strcpy(ErcGroupName,"ERC_Designers_Group");
						SA_find_group(ErcGroupName, &group_tag);
						SA_find_role2(GroupNameDup,&role_tag);
						SA_find_role2(GroupName1Dup,&ModRevrole_tag);
						if(group_tag!=NULLTAG)
						{
							SA_find_groupmember_by_role(role_tag,group_tag,&member_found,&members);
							printf("\n Module Team Leader Assign-->[%d] \n",member_found);fflush(stdout);
							if(member_found>0)
							{
								//coc_id = members[0];
								AOM_refresh( latestrev, TRUE);
								AOM_set_value_string(latestrev,"t5_NwCocId",GroupNameDup);
								AOM_save_without_extensions(latestrev);
								AOM_refresh(latestrev,FALSE);
								printf("\n Module Team Leader Assign \n");fflush(stdout);
								r=0;
								for(r=0 ; r<member_found; r++)
								{	
									printf("\n Modeule_Reviewer: %d",r+1);fflush(stdout);
									coc_id = members[r];
									if(EPM_get_participanttype ("T5_Modeule_Reviewer",&Module_Patricipant_Type)!=ITK_ok) PrintErrorStack();
									if(EPM_create_participant(coc_id,Module_Patricipant_Type,&module_participant)!=ITK_ok) PrintErrorStack();
									AOM_refresh(latestitemrev, TRUE);
									//if(ITEM_rev_add_participant(latestitemrev,module_participant)!=ITK_ok) PrintErrorStack();
									PARTICIPANT_add_participant(latestitemrev,TRUE,module_participant);
									AOM_save_without_extensions(latestitemrev);
									AOM_refresh(latestitemrev,FALSE);
								}
							}
							SA_find_groupmember_by_role(ModRevrole_tag,group_tag,&ModRevmember_found,&ModRevmembers);
							if(ModRevmember_found>0)
							{
								//coc_id = members[0];
								AOM_refresh( latestrev, TRUE);
								AOM_set_value_string(latestrev,"t5_ModuleReviewer",GroupName1Dup);
								AOM_save_without_extensions(latestrev);
								AOM_refresh(latestrev,FALSE);
								printf("\n For Engine and Gear Box Module Team Lead value set \n");fflush(stdout);

								w=0;
								for(w=0 ; w<ModRevmember_found; w++)
								{	
									printf("\n Modeule_Reviewer: %d",w+1);fflush(stdout);
									ModReviwer_id = ModRevmembers[w];
									if(EPM_get_participanttype ("ProposedReviewer",&Module_Proposed_Type)!=ITK_ok) PrintErrorStack();
									if(EPM_create_participant(ModReviwer_id,Module_Proposed_Type,&modulerev_participant)!=ITK_ok) PrintErrorStack();
									AOM_refresh(latestitemrev, TRUE);
									//if(ITEM_rev_add_participant(latestitemrev,modulerev_participant)!=ITK_ok)PrintErrorStack();
									PARTICIPANT_add_participant(latestitemrev,TRUE,modulerev_participant);
									AOM_save_without_extensions(latestitemrev);
									AOM_refresh(latestitemrev,FALSE);
								}
							}
						}

						MEM_free(members);
						MEM_free(ModRevmembers);
						MEM_free(GroupNameS);
						GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
						tc_strcpy(GroupNameS,designgroup);
						tc_strcat(GroupNameS,"_");
						tc_strcat(GroupNameS,"New");
						tc_strcat(GroupNameS,"_");
						tc_strcat(GroupNameS,"COCPrinciple");
						printf(" \n $$$$ Temporary Request No created with name (%s) $$$$ \n",GroupNameS);fflush(stdout);
						//SA_find_group(ErcGroupName, &group_tag);
						SA_find_role2(GroupNameS,&role_tag);
						if(group_tag!=NULLTAG)
						{
							SA_find_groupmember_by_role(role_tag,group_tag,&member_found,&members);
							printf("\n COC Principle Assign--->[%d] \n",member_found);fflush(stdout);
							if(member_found>0)
							{
								//coc_id = members[0];
								AOM_refresh( latestrev, TRUE);
								AOM_set_value_string(latestrev,"t5_NwChiefId",GroupNameS);
								AOM_save_without_extensions(latestrev);
								AOM_refresh(latestrev,FALSE);
								printf("\n COC Principle Assign\n");fflush(stdout);
								g=0;
								for(g=0 ; g<member_found; g++)
								{	
									printf("\n COC Principle Assign: %d",g+1);fflush(stdout);
									coc_principle = members[g];
									if(EPM_get_participanttype ("T5_COCPrinciple_Reviewer",&COCPrinciple_Patricipant_Type)!=ITK_ok) PrintErrorStack();
									if(EPM_create_participant(coc_principle,COCPrinciple_Patricipant_Type,&cocprinciple_participant)!=ITK_ok) PrintErrorStack();
									AOM_refresh(latestitemrev, TRUE);
									//if(ITEM_rev_add_participant(latestitemrev,cocprinciple_participant)!=ITK_ok) PrintErrorStack();
									PARTICIPANT_add_participant(latestitemrev,TRUE,cocprinciple_participant);
									AOM_save_without_extensions(latestitemrev);
									AOM_refresh(latestitemrev,FALSE);
								}
							}
						}
						MEM_free(members);
						MEM_free(GroupNameS);
						GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
						tc_strcpy(GroupNameS,designgroup);
						tc_strcat(GroupNameS,"_");
						tc_strcat(GroupNameS,"New");
						tc_strcat(GroupNameS,"_");
						tc_strcat(GroupNameS,"COCHead");
						printf(" \n $$$$ Temporary Request No created with name (%s) $$$$ \n",GroupNameS);fflush(stdout);
						//SA_find_group(GroupNameS, &group_tag);
						SA_find_role2(GroupNameS,&role_tag);
						if(group_tag!=NULLTAG)
						{
							SA_find_groupmember_by_role(role_tag,group_tag,&member_found,&members);
							printf("\n COC Head Assign--->[%d] \n",member_found);fflush(stdout);
							if(member_found>0)
							{
								//coc_id = members[0];
								AOM_refresh( latestrev, TRUE);
								AOM_set_value_string(latestrev,"t5_NwCeId",GroupNameS);
								//if ((strcmp(designgroup,"31")==0)  &&  (strcmp(partFam,"LONG MEMBER")==0))
								if ((strcmp(designgroup,"31")==0))
								{
									AOM_set_value_string(latestrev,"t5_NwHeadEng",GroupNameS);
								}
								AOM_save_without_extensions(latestrev);
								AOM_refresh(latestrev,FALSE);

								printf("\n COC Head Assign\n");fflush(stdout);
								h=0;
								for(h=0 ; h<member_found; h++)
								{	
									printf("\n COC Head Assign: %d",g+1);fflush(stdout);
									coc_head = members[h];
									if(EPM_get_participanttype ("T5_COCHead_Reviewer",&COCHead_Patricipant_Type)!=ITK_ok) PrintErrorStack();
									if(EPM_create_participant(coc_head,COCHead_Patricipant_Type,&cochead_participant)!=ITK_ok) PrintErrorStack();
									AOM_refresh(latestitemrev, TRUE);
									//if(ITEM_rev_add_participant(latestitemrev,cochead_participant)!=ITK_ok) PrintErrorStack();
									PARTICIPANT_add_participant(latestitemrev,TRUE,cochead_participant);
									AOM_save_without_extensions(latestitemrev);
									AOM_refresh(latestitemrev,FALSE);
								}
								AOM_refresh ( latestitemrev,TRUE);
								if ((strcmp(designgroup,"31")==0))
								{
									printf("\n Head Engg Assign\n");fflush(stdout);
									e=0;
									for(e=0 ; e<member_found; e++)
									{
										head_engg = members[e];
										if(EPM_get_participanttype ("T5_HeadOfEngg",&HeadEngg_Patricipant_Type)!=ITK_ok) PrintErrorStack();
										if(EPM_create_participant(head_engg,HeadEngg_Patricipant_Type,&headengg_participant)!=ITK_ok) PrintErrorStack();
										AOM_refresh(latestitemrev, TRUE);
										//if(ITEM_rev_add_participant(latestitemrev,headengg_participant)!=ITK_ok) PrintErrorStack();
										PARTICIPANT_add_participant(latestitemrev,TRUE,headengg_participant);
										AOM_save_without_extensions(latestitemrev);
										AOM_refresh(latestitemrev,FALSE);
									}
								}
							}
						}
						MEM_free(members);

						
					}
					//else if(strcmp(BussiNameS,"PCBU")==0)
					else
					{
						ErcGroupName = (char *) MEM_alloc( 100 * sizeof(char) );
						GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
						GroupNameDup = (char *) MEM_alloc( 100 * sizeof(char) );
						tc_strcpy(GroupNameS,designgroup);
						tc_strcat(GroupNameS,"_");
						tc_strcat(GroupNameS,"PVBU");
						//tc_strcat(GroupNameS,"*");
						if(GroupNameS)
						{
							tc_strcpy(GroupNameDup,GroupNameS);
						}

						GroupNameS1 = (char *) MEM_alloc( 200 * sizeof(char) );
						GroupName1Dup = (char *) MEM_alloc( 200 * sizeof(char) );
						//tc_strcpy(GroupNameS1,designgroup);
						//tc_strcat(GroupNameS1,"_");
						//tc_strcat(GroupNameS1,"New");
						//tc_strcat(GroupNameS1,"_");
						//tc_strcat(GroupNameS1,"ModuleReviewer");

						tc_strcpy(GroupNameS1,"MCCReviewer");
						if(GroupNameS1)
						{
							tc_strcpy(GroupName1Dup,GroupNameS1);
						}
						tc_strcpy(ErcGroupName,"ERC_Designers_Group");
						SA_find_group(ErcGroupName, &group_tag);
						SA_find_role2(GroupNameDup,&role_tag);
						SA_find_role2(GroupName1Dup,&ModRevrole_tag);
						if(group_tag!=NULLTAG)
						{
							SA_find_groupmember_by_role(role_tag,group_tag,&member_found,&members);
							if(member_found>0)
							{
								//coc_id = members[0];
								AOM_refresh( latestrev, TRUE);
								AOM_set_value_string(latestrev,"t5_NwCocId",GroupNameDup);
								AOM_save_without_extensions(latestrev);
								AOM_refresh(latestrev,FALSE);
								printf("\n For PVBU Assignee \n");fflush(stdout);
								EPM_get_participanttype ("T5_Modeule_Reviewer",&PVBU_Patricipant_Type);
								for(p=0 ; p<member_found; p++)
								{
									pvbu_coc_id = members[p];
									EPM_create_participant(pvbu_coc_id,PVBU_Patricipant_Type,&pvbu_participant);
									AOM_refresh(latestitemrev, TRUE);
									//ITEM_rev_add_participant(latestitemrev,pvbu_participant);
									PARTICIPANT_add_participant(latestitemrev,TRUE,pvbu_participant);
									AOM_save_without_extensions(latestitemrev);
									AOM_refresh(latestitemrev,FALSE);
								}
							}
							SA_find_groupmember_by_role(ModRevrole_tag,group_tag,&ModRevmember_found,&ModRevmembers);
							if(ModRevmember_found>0)
							{
								//coc_id = members[0];
								AOM_refresh( latestrev, TRUE);
								AOM_set_value_string(latestrev,"t5_ModuleReviewer",GroupName1Dup);
								AOM_save_without_extensions(latestrev);
								AOM_refresh(latestrev,FALSE);
								printf("\n For Engine and Gear Box Module Team Lead value set \n");fflush(stdout);

								w=0;
								for(w=0 ; w<ModRevmember_found; w++)
								{	
									printf("\n Modeule_Reviewer: %d",w+1);fflush(stdout);
									ModReviwer_id = ModRevmembers[w];
									if(EPM_get_participanttype ("ProposedReviewer",&Module_Proposed_Type)!=ITK_ok) PrintErrorStack();
									if(EPM_create_participant(ModReviwer_id,Module_Proposed_Type,&modulerev_participant)!=ITK_ok) PrintErrorStack();
									AOM_refresh(latestitemrev, TRUE);
									//if(ITEM_rev_add_participant(latestitemrev,modulerev_participant)!=ITK_ok)PrintErrorStack();
									PARTICIPANT_add_participant(latestitemrev,TRUE,modulerev_participant);
									AOM_save_without_extensions(latestitemrev);
									AOM_refresh(latestitemrev,FALSE);
								}
							}
						}
						MEM_free(members);
						MEM_free(ModRevmembers);
						MEM_free(GroupNameS);
						GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
						tc_strcpy(GroupNameS,designgroup);
						tc_strcat(GroupNameS,"_");
						tc_strcat(GroupNameS,"New");
						tc_strcat(GroupNameS,"_");
						tc_strcat(GroupNameS,"COCPrinciple");
						printf(" \n $$$$ Temporary Request No created with name (%s) $$$$ \n",GroupNameS);fflush(stdout);
						//SA_find_group(ErcGroupName, &group_tag);
						SA_find_role2(GroupNameS,&role_tag);
						if(group_tag!=NULLTAG)
						{
							SA_find_groupmember_by_role(role_tag,group_tag,&member_found,&members);
							printf("\n COC Principle Assign--->[%d] \n",member_found);fflush(stdout);
							if(member_found>0)
							{
								//coc_id = members[0];
								AOM_refresh( latestrev, TRUE);
								AOM_set_value_string(latestrev,"t5_NwChiefId",GroupNameS);
								AOM_save_without_extensions(latestrev);
								AOM_refresh(latestrev,FALSE);
								printf("\n COC Principle Assign\n");fflush(stdout);
								g=0;
								for(g=0 ; g<member_found; g++)
								{	
									printf("\n COC Principle Assign: %d",g+1);fflush(stdout);
									coc_principle = members[g];
									if(EPM_get_participanttype ("T5_COCPrinciple_Reviewer",&COCPrinciple_Patricipant_Type)!=ITK_ok) PrintErrorStack();
									if(EPM_create_participant(coc_principle,COCPrinciple_Patricipant_Type,&cocprinciple_participant)!=ITK_ok) PrintErrorStack();
									AOM_refresh(latestitemrev, TRUE);
									//if(ITEM_rev_add_participant(latestitemrev,cocprinciple_participant)!=ITK_ok) PrintErrorStack();
									PARTICIPANT_add_participant(latestitemrev,TRUE,cocprinciple_participant);
									AOM_save_without_extensions(latestitemrev);
									AOM_refresh(latestitemrev,FALSE);
								}
							}
						}
						MEM_free(members);
						MEM_free(GroupNameS);
						GroupNameS = (char *) MEM_alloc( 100 * sizeof(char) );
						tc_strcpy(GroupNameS,designgroup);
						tc_strcat(GroupNameS,"_");
						tc_strcat(GroupNameS,"New");
						tc_strcat(GroupNameS,"_");
						tc_strcat(GroupNameS,"COCHead");
						printf(" \n $$$$ Temporary Request No created with name (%s) $$$$ \n",GroupNameS);fflush(stdout);
						//SA_find_group(GroupNameS, &group_tag);
						SA_find_role2(GroupNameS,&role_tag);
						if(group_tag!=NULLTAG)
						{
							SA_find_groupmember_by_role(role_tag,group_tag,&member_found,&members);
							printf("\n COC Head Assign--->[%d] \n",member_found);fflush(stdout);
							if(member_found>0)
							{
								//coc_id = members[0];
								AOM_refresh( latestrev, TRUE);
								AOM_set_value_string(latestrev,"t5_NwCeId",GroupNameS);
								//if ((strcmp(designgroup,"31")==0)  &&  (strcmp(partFam,"LONG MEMBER")==0))
								if ((strcmp(designgroup,"31")==0))
								{
									AOM_set_value_string(latestrev,"t5_NwHeadEng",GroupNameS);
								}
								AOM_save_without_extensions(latestrev);
								AOM_refresh(latestrev,FALSE);

								printf("\n COC Head Assign\n");fflush(stdout);
								h=0;
								for(h=0 ; h<member_found; h++)
								{	
									printf("\n COC Head Assign: %d",g+1);fflush(stdout);
									coc_head = members[h];
									if(EPM_get_participanttype ("T5_COCHead_Reviewer",&COCHead_Patricipant_Type)!=ITK_ok) PrintErrorStack();
									if(EPM_create_participant(coc_head,COCHead_Patricipant_Type,&cochead_participant)!=ITK_ok) PrintErrorStack();
									AOM_refresh(latestitemrev, TRUE);
									//if(ITEM_rev_add_participant(latestitemrev,cochead_participant)!=ITK_ok) PrintErrorStack();
									PARTICIPANT_add_participant(latestitemrev,TRUE,cochead_participant);
									AOM_save_without_extensions(latestitemrev);
									AOM_refresh(latestitemrev,FALSE);
								}
								AOM_refresh ( latestitemrev,TRUE);
								if ((strcmp(designgroup,"31")==0))
								{
									printf("\n Head Engg Assign\n");fflush(stdout);
									e=0;
									for(e=0 ; e<member_found; e++)
									{
										head_engg = members[e];
										if(EPM_get_participanttype ("T5_HeadOfEngg",&HeadEngg_Patricipant_Type)!=ITK_ok) PrintErrorStack();
										if(EPM_create_participant(head_engg,HeadEngg_Patricipant_Type,&headengg_participant)!=ITK_ok) PrintErrorStack();
										AOM_refresh(latestitemrev, TRUE);
										//if(ITEM_rev_add_participant(latestitemrev,headengg_participant)!=ITK_ok) PrintErrorStack();
										PARTICIPANT_add_participant(latestitemrev,TRUE,headengg_participant);
										AOM_save_without_extensions(latestitemrev);
										AOM_refresh(latestitemrev,FALSE);
									}
								}
							}
						}
						MEM_free(members);
						MEM_free(GroupNameS);
						
					}
				}
				printf("\n Reviewer set before obejct creation @@ \n");fflush(stdout);
			}
			else
			{
				error_code=t9NewPartReqCre_Val0037;
				EMH_store_error_s1(EMH_severity_error,error_code,"Project Details Not Found,Please contact to PLM Team!!");
				return error_code;
			}
			
			SA_find_user2(NwRaisedBy,&RaisedBy);
			SA_find_groupmember_by_user(RaisedBy,&userfind,&AcknowledgeUser);
			printf("\n Acknowledge Assignee-->[%d]\n",userfind);fflush(stdout);
			if(userfind>0)
			{
				EPM_get_participanttype ("T5_NwRaisedBy",&RaisedBy_Patricipant_Type);
				EPM_create_participant(AcknowledgeUser[0],RaisedBy_Patricipant_Type,&raisedby_participant);
				AOM_refresh(latestitemrev, TRUE);
				//ITEM_rev_add_participant(latestitemrev,raisedby_participant);
				PARTICIPANT_add_participant(latestitemrev,TRUE,raisedby_participant);
				AOM_save_without_extensions(latestitemrev);
				AOM_refresh(latestitemrev,FALSE);
			}
			
		}
		MEM_free(t_item1);
		MEM_free(ErcGroupName);
		MEM_free(q_item1);
		MEM_free(AcknowledgeUser);

	}

return error_code;
}


/****************************************************************************
Function:       TML_New_Part_Request_Ledger_function
Description:    This function is used in WF after while approve from manager login
				to release DML/task/part/dataset.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
int TML_New_Part_Request_Ledger_function(EPM_action_message_t msg)
{
	tag_t        tzroottask					=  NULLTAG;
	tag_t		 session					=  NULLTAG;
	tag_t		 *tzattachment				=  NULLTAG;
	tag_t		 query1						=  NULLTAG;
	tag_t		 query2						=  NULLTAG;
	tag_t		 *q_item1					=  NULLTAG;
	tag_t		 *q_item2					=  NULLTAG;
	tag_t		 creltypetag				=  NULLTAG;
	tag_t		 rel_tag					=  NULLTAG;
	tag_t		 PrtLedgerTypeTag			=  NULLTAG;
	tag_t		 PrtLedgerCreInTag			=  NULLTAG;
	tag_t		 prt_tag					=  NULLTAG;
	tag_t		 PartLedgerTag				=  NULLTAG;
	tag_t		 prt_ledger_tag				=  NULLTAG;
	tag_t		 latestitemrev				=  NULLTAG;
	tag_t		 updatedrevtag1			=  NULLTAG;
	tag_t		 updatedrevtag2			=  NULLTAG;
	tag_t		 *npr_tagitems			=  NULLTAG;
	tag_t		 master					=  NULLTAG;
	tag_t		 design_tag				=  NULLTAG;
	tag_t		 *q_designfound				=  NULLTAG;
	tag_t		 *q_partledgeritem				=  NULLTAG;
	tag_t		 partledger_tag				=  NULLTAG;
	tag_t		 updatetag				=  NULLTAG;
	tag_t		 updatetagprt				=  NULLTAG;
	tag_t		 query_ctrl				=  NULLTAG;
	tag_t		 *q_item_ctrl				=  NULLTAG;

	char
        *qry_entries1[2] = {"Name","Type"},
        *qry_values1[2]	= {"*","*"};


	char
        *qry_entries2[2] = {"Item ID","Type"},
        *qry_values2[2]	= {"*","*"};

	char
        *qry_entries_ctrl[1] = {"SYSCD"},
        *qry_values_ctrl[1]	= {"*"};



	char		*UserId					=  NULL;
	char		*newpartreq				=  NULL;
	char		*reqid					=  NULL;
	char		*ProjectNameDupS					=  NULL;
	char		*ProjectNameS					=  NULL;
	char		*t5DesignGroupDupS					=  NULL;
	char		*t5DesignGroupS					=  NULL;
	char		*t5NwDgSbGrpDupS					=  NULL;
	char		*t5NwDgSbGrpS					=  NULL;
	char		*t5NwDgIdDupS					=  NULL;
	char		*t5NwDgIdS					=  NULL;
	char		*PartNumberS					=  NULL;
	char		*t5NwTmlPtNoDup					=  NULL;
	char		*t5NwTmlPtNo					=  NULL;
	char		*thisPartNumber					=  NULL;
	char		*ledgerdocnumber					=  NULL;
	char		*ledgerdoc					=  NULL;
	char		*revid					=  NULL;
	char		*revid1					=  NULL;
	char		*tempId					=  NULL;
	char		*tempId1					=  NULL;
	char		*vstr					=  NULL;
	char		*Partstr					=  NULL;
	char		*tmlpartnumber					=  NULL;
	char		*new_type					=  NULL;
	char		*dgidstr					=  NULL;
	char		*DesigIdstr					=  NULL;
	char		*this_PartNumber					=  NULL;
	char		*design_id					=  NULL;
	char		*desigIdtempId					=  NULL;
	char		*desigIdvstr					=  NULL;
	char		*desigIdPartstr					=  NULL;
	char		*this_PartNumber_partLedger		=  NULL;
	char		*partledger_id		=  NULL;
	char		*prtledgertempId		=  NULL;
	char		*prtledgervstr		=  NULL;
	char		*prtledgerPartstr		=  NULL;
	char		*prtledger_design_vstr		=  NULL;
	char		*prtledger_design_Partstr		=  NULL;
	char		*PartType		=  NULL;
	char		*part_ledger_type		=  NULL;
	//char   part_ledger_type[TCTYPE_name_size_c+1];
	char buffer[4000];
	char*syscommand=NULL;
	char*ExePath=NULL;
	char*username=NULL;
	char*userpasswd=NULL;
	char*usergrp=NULL;
	char*SubModuleAddress=NULL;
	char *TEMPrevid=NULL;
	char *TEMP_revid=NULL;
	char *TEMPrtNum=NULL;
	char *NextTEMPrtNum=NULL;
	char *TEMP_revid2=NULL;
	char *rev_PrtType2=NULL;
	char *revPrtType=NULL;
	char *rev_PrtType=NULL;
	char *design_prt_type=NULL;
	char *ProposeTPLNum=NULL;

	int inumarg =0;
	int izntaskattachment =0;
	int n_found1 =0;
	int n_found2 =0;
	int h =0;
	int p =0;
	int len =0;
	int n_entries	= 1;
	int IncrementPartNumber =0;
	int IncrementPartNumber1 =0;
	int FinalIncrement =0;
	int designfound =0;
	int Increment_PartNumber =0;
	int IncrementDgId =0;
	int partledgerfound =0;
	int Increment_PartNumber_ledger =0;
	int Final_Increment =0;
	int IncrementPartNumber_design =0;
	int Increment_DgId =0;
	int IncrementPartNumber_Ledger =0;
	int IncrementDgId_Ledger =0;
	int Increment_PartNumber_PartLedger =0;
	int IncrementPartNumber_design_1 =0;
	int IncrementDgId_1 =0;
	int n_found_ctrl =0;
	int dsgcnt =0;
	int dsg_cnt =0;
	int dsgcnt2 =0;
	int latestObjindex = -1;
	int Is_Module = 0;

	logical			isFor12Digit = false;
	logical			isFor14Digit = false;

	int error_code	= ITK_ok;


	//char *keys[1] = {"creation_date"};
	char *partledgerkeys[1] = {"object_name"};
    int  partledgerorders[1]  ={2};
	int  partledgernum_to_sort = 1;

	char *designkeys[1] = {"item_id"};
    int  designorders[1]  ={2};
	int  designnum_to_sort = 1;

	int  n_tags_found = 0;

	 const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};

	 EPM_decision_t   decision = EPM_go;


	//ITK_set_bypass(true);
	inumarg = TC_number_of_arguments(msg.arguments);
	printf("\n No of Argument====>[%d]", inumarg);fflush(stdout);

	//POM_ask_session(&session);
	if(POM_ask_session(&session)!=ITK_ok)   PrintErrorStack();
	//POM_get_user_id(&UserId);
	if(POM_get_user_id(&UserId)!=ITK_ok)   PrintErrorStack();
	printf("\n TML_New_Part_Request_Ledger_function::UserId====>[%s]", UserId);fflush(stdout);
	//MEM_free(UserId);


	if(EPM_ask_root_task(msg.task, &tzroottask)!=ITK_ok)   PrintErrorStack();
	if(EPM_ask_attachments(tzroottask, EPM_target_attachment,&izntaskattachment, &tzattachment)!=ITK_ok)   PrintErrorStack();
	printf("\n No of Attachements====>[%d]", izntaskattachment);fflush(stdout);

	if (AOM_ask_value_string(tzattachment[0],"object_type",&new_type)!=ITK_ok)   PrintErrorStack();
	printf("\n new_type====>[%s]", new_type);fflush(stdout);

	if (AOM_ask_value_string(tzattachment[0],"item_id",&newpartreq)!=ITK_ok)   PrintErrorStack();
	printf("\n newpartreq====>[%s]", newpartreq);fflush(stdout);

	// to Item from revision
	if(ITEM_ask_item_of_rev(tzattachment[0],&master)!=ITK_ok) PrintErrorStack();

	if (AOM_ask_value_string(master,"t5_NwRqNumber",&reqid)!=ITK_ok)   PrintErrorStack();
	printf("\n reqid====>[%s]", reqid);fflush(stdout);

	if (AOM_ask_value_string(master,"t5_ProjectCode",&ProjectNameDupS)!=ITK_ok)   PrintErrorStack();
	ProjectNameS = strdup(ProjectNameDupS);
	printf("\n ProjectNameS====>[%s]", ProjectNameS);fflush(stdout);

	if (AOM_ask_value_string(master,"t5_DesignGroup",&t5DesignGroupDupS)!=ITK_ok)   PrintErrorStack();
	t5DesignGroupS = strdup(t5DesignGroupDupS);
	printf("\n t5DesignGroupS====>[%s]", t5DesignGroupS);fflush(stdout);

	if (AOM_ask_value_string(master,"t5_DesignSubGrp",&t5NwDgSbGrpDupS)!=ITK_ok)   PrintErrorStack();
	t5NwDgSbGrpS = strdup(t5NwDgSbGrpDupS);
	printf("\n t5NwDgSbGrpS====>[%s]", t5NwDgSbGrpS);fflush(stdout);

	if (AOM_ask_value_string(master,"t5_NwDgId",&t5NwDgIdDupS)!=ITK_ok)   PrintErrorStack();
	t5NwDgIdS = strdup(t5NwDgIdDupS);
	printf("\n t5NwDgIdS====>[%s]", t5NwDgIdS);fflush(stdout);

	if (AOM_ask_value_string(master,"t5_NwDgId",&t5NwDgIdDupS)!=ITK_ok)   PrintErrorStack();
	t5NwDgIdS = strdup(t5NwDgIdDupS);
	printf("\n t5NwDgIdS====>[%s]", t5NwDgIdS);fflush(stdout);

	AOM_ask_value_logical(master,"t5_Is12Digit",&isFor12Digit);
	printf("\n isFor12Digit====>[%d]", isFor12Digit);fflush(stdout);

	AOM_ask_value_logical(master,"t5_Is14Digit",&isFor14Digit);
	printf("\n isFor14Digit====>[%d]", isFor14Digit);fflush(stdout);

	AOM_ask_value_string(master,"t5_ModuleAddress",&SubModuleAddress);
	printf("\n SubModuleAddress %s\n",SubModuleAddress);fflush(stdout);

	AOM_ask_value_string(master,"t5_PartType",&PartType);
	printf("\n PartType====>[%s]", PartType);fflush(stdout);

	AOM_ask_value_string(master,"t5_ProposeTPLNum",&ProposeTPLNum);
	printf("\n ProposeTPLNum====>[%s]", ProposeTPLNum);fflush(stdout);


	PartNumberS = (char *) MEM_alloc( 20 * sizeof(char) );
	if(ProjectNameS)tc_strcpy(PartNumberS,ProjectNameS);
	else tc_strcpy(PartNumberS, "2829");

	//if(isFor12Digit==true && isFor14Digit==false)
	if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
	{
		if(t5DesignGroupS)tc_strcat(PartNumberS,t5DesignGroupS);
		if(t5NwDgSbGrpS) tc_strcat(PartNumberS,t5NwDgSbGrpS);
		if(t5NwDgIdS) tc_strcat(PartNumberS,t5NwDgIdS);
		tc_strcat(PartNumberS,"*");
		printf("\nThe 12 digit PartNumber is %s\n",PartNumberS);fflush(stdout);
	}
	if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
	{
		if(SubModuleAddress)tc_strcat(PartNumberS,SubModuleAddress);
		if(t5DesignGroupS)tc_strcat(PartNumberS,t5DesignGroupS);
		tc_strcat(PartNumberS,"*");
		printf("\nThe 14 digit PartNumber is %s\n",PartNumberS);fflush(stdout);
	}
	if(tc_strcmp(PartType,"T")==0 || tc_strcmp(PartType,"Technical Part List")==0)
	{
		if(ProposeTPLNum)tc_strcpy(PartNumberS,ProposeTPLNum);
	}
	
	


	// QUERY IN PART LEDGER ....

	
	qry_values1[0]	= PartNumberS;
	qry_values1[1]	= "Part Ledger";
	//QRY_find2("General...", &query1);
	if(QRY_find2("General...", &query1) !=ITK_ok)  PrintErrorStack();
	//QRY_execute(query1, 2, qry_entries1, qry_values1, &n_found1, &q_item1);
	//QRY_execute_with_sort(query1, 2, qry_entries1, qry_values1, num_to_sort, keys, orders, &n_found1, &q_item1);
	//if(QRY_execute_with_sort(query1, 2, qry_entries1, qry_values1, num_to_sort, keys, orders, &n_found1, &q_item1) !=ITK_ok) PrintErrorStack();
	if(QRY_execute_with_sort(query1, 2, qry_entries1, qry_values1, partledgernum_to_sort, partledgerkeys, partledgerorders, &n_found1, &q_item1) !=ITK_ok) PrintErrorStack();
	printf("\n n_found1 =[%d]",n_found1);fflush(stdout);
	printf("\nNumber of Ledger Object Found are %d\n",n_found1);fflush(stdout);

	// QUERY IN DESIGN CLASS ....

	qry_values2[0]	= PartNumberS;
	qry_values2[1]	= "Design";
	QRY_find2("Item - simple", &query2);
	//QRY_execute(query2, 2, qry_entries2, qry_values2, &n_found2, &q_item2);
	//QRY_execute_with_sort(query2, 2, qry_entries2, qry_values2, num_to_sort, keys, orders, &n_found2, &q_item2);
	//if(QRY_execute_with_sort(query2, 2, qry_entries2, qry_values2, num_to_sort, keys, orders, &n_found2, &q_item2) !=ITK_ok) PrintErrorStack();
	if(QRY_execute_with_sort(query2, 2, qry_entries2, qry_values2, designnum_to_sort, designkeys, designorders, &n_found2, &q_item2) !=ITK_ok) PrintErrorStack();
	printf("\n n_found2 =[%d]",n_found2);fflush(stdout);

	// n_found2 ----> Design Object Found.
	// n_found1 ----> Part Ledger Object Found.

	

	if((n_found1==0 && n_found2==0))
	{
		thisPartNumber = (char *) MEM_alloc( 20 * sizeof(char) );
		tc_strcpy(thisPartNumber, ProjectNameS);
		//if(isFor12Digit==true && isFor14Digit==false)
		if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
		{
			tc_strcat(thisPartNumber,t5DesignGroupS);
			tc_strcat(thisPartNumber,t5NwDgSbGrpS);
			tc_strcat(thisPartNumber,t5NwDgIdS);
			tc_strcat(thisPartNumber,"01");
			printf("\n\n 1 Going to  Create Part Ledger -->%s\n\n",thisPartNumber);fflush(stdout);
		}
		if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
		{
			tc_strcat(thisPartNumber,SubModuleAddress);
			tc_strcat(thisPartNumber,t5DesignGroupS);
			tc_strcat(thisPartNumber,"001");
			printf("\n\n 2 Going to  Create Part Ledger -->%s\n\n",thisPartNumber);fflush(stdout);
		}
		if(tc_strcmp(PartType,"T")==0 || tc_strcmp(PartType,"Technical Part List")==0)
		{
			tc_strcpy(thisPartNumber, ProposeTPLNum);
		}
	}
	else if(n_found2>0 && n_found1==0)
	{
		//Design ....
		tag_t		 *soResult1					=  NULLTAG;
		int  totalPart = 0;
		int  IFDModule = 0;
		int  ISModule = 0;
		for(dsgcnt=0;dsgcnt<n_found2;dsgcnt++)
		{
			AOM_ask_value_string(q_item2[dsgcnt],"item_id",&TEMPrevid);
			printf("\n TEMPrevid====>[%s]", TEMPrevid);fflush(stdout);
			AOM_ask_value_string(q_item2[dsgcnt],"t5_RevPartType",&revPrtType);
			printf("\n revPrtType====>[%s]", revPrtType);fflush(stdout);
			if(tc_strlen(TEMPrevid)==14 || tc_strlen(TEMPrevid)==12 || (tc_strcmp(PartType,"T")==0 || tc_strcmp(PartType,"Technical Part List")==0))
			{
				if(tc_strlen(TEMPrevid)==14)
				{
					IFDModule = FunToQueryIFDModuleAddress(SubModuleAddress);
					ISModule = FunToQueryModuleAddress(SubModuleAddress);
				}
				
				printf("\n IFDModule====>[%d]", IFDModule);fflush(stdout);
				if(tc_strlen(TEMPrevid)==14 && 
					(tc_strcmp(revPrtType,"M")==0 || tc_strcmp(revPrtType,"Module")==0 
					|| tc_strcmp(revPrtType,"IM")==0 || tc_strcmp(revPrtType,"IFD Module")==0
					|| tc_strcmp(revPrtType,"EM")==0 
					|| tc_strcmp(revPrtType,"ECU Module")==0 
					|| tc_strlen(revPrtType)==0 
					|| IFDModule==1 
					|| tc_strcmp(revPrtType,"D")==0)
					&& (tc_strcmp(PartType,"Module")==0 
					|| tc_strcmp(PartType,"M")==0 
					|| tc_strcmp(PartType,"IFD Module")==0 
					|| tc_strcmp(PartType,"IM")==0 
					|| tc_strcmp(PartType,"ECU Module")==0 
					|| tc_strcmp(PartType,"EM")==0)
					&& ISModule==1)
				{
					setAddTAG(&totalPart,&soResult1,q_item2[dsgcnt]);
				}
				if(tc_strlen(TEMPrevid)==12 && 
					(tc_strcmp(revPrtType,"A")==0 || tc_strcmp(revPrtType,"Assembly")==0 
					|| tc_strcmp(revPrtType,"Component")==0 || tc_strcmp(revPrtType,"C")==0 || tc_strlen(revPrtType)==0)
					&& (tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Assembly")==0 
					|| tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0))
				{
					setAddTAG(&totalPart,&soResult1,q_item2[dsgcnt]);
				}

				if((tc_strcmp(revPrtType,"T")==0 || tc_strcmp(revPrtType,"Technical Part List")==0)
					&& (tc_strcmp(PartType,"T")==0 || tc_strcmp(PartType,"Technical Part List")==0))
				{
					setAddTAG(&totalPart,&soResult1,q_item2[dsgcnt]);
				}
			}
		}
		printf("\n totalPart====>[%d]", totalPart);fflush(stdout);
		if(totalPart>0)
		{
			prt_tag = soResult1[0];
		}
		else
		{
			thisPartNumber = (char *) MEM_alloc( 20 * sizeof(char) );
			tc_strcpy(thisPartNumber, ProjectNameS);
			if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
			{
				tc_strcat(thisPartNumber,t5DesignGroupS);
				tc_strcat(thisPartNumber,t5NwDgSbGrpS);
				tc_strcat(thisPartNumber,t5NwDgIdS);
				tc_strcat(thisPartNumber,"01");
				printf("\n\n 3 Going to  Create Part Ledger -->%s\n\n",thisPartNumber);fflush(stdout);
			}
			if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
			{
				tc_strcat(thisPartNumber,SubModuleAddress);
				tc_strcat(thisPartNumber,t5DesignGroupS);
				tc_strcat(thisPartNumber,"001");
				printf("\n\n 4 Going to  Create Part Ledger -->%s\n\n",thisPartNumber);fflush(stdout);
			}
			if(tc_strcmp(PartType,"Technical Part List")==0 || tc_strcmp(PartType,"T")==0)
			{
				tc_strcpy(thisPartNumber, ProposeTPLNum);
			}
		}

		if(prt_tag!=NULLTAG)
		{
			//prt_tag = q_item2[0];
			AOM_ask_value_string(prt_tag,"item_id",&revid);
			printf("\n revid====>[%s]", revid);fflush(stdout);

			if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
			{
				tempId = (char *) MEM_alloc(2 * sizeof(char) );
				vstr = (char *) MEM_alloc(2 * sizeof(char) );
				dgidstr = (char *) MEM_alloc(2 * sizeof(char) );
				Partstr = (char *) MEM_alloc(2 * sizeof(char) );
				DesigIdstr = (char *) MEM_alloc(2 * sizeof(char) );
				tempId= NewPartsubString(revid,10,2);
				//282954601087
				//0123456789
				//2829D3A0154001
				printf("\n tempId====>[%s]", tempId);fflush(stdout);
				len = strlen(tempId);
				printf("\n len====>[%d]", len);fflush(stdout);
				IncrementPartNumber = atoi(tempId);
				IncrementDgId = atoi(t5NwDgIdS);
				printf("\n IncrementPartNumber====>[%d]", IncrementPartNumber);fflush(stdout);
				if(IncrementPartNumber<9)
				{
					IncrementPartNumber_design = IncrementPartNumber+1;
					sprintf(vstr,"%d",IncrementPartNumber_design);
					tc_strcpy(Partstr,"0");
					tc_strcat(Partstr,vstr);
					printf("\n Partstr [%s] ",Partstr);fflush(stdout);
				}
				if(IncrementPartNumber>=9 && IncrementPartNumber<=98)
				{
					IncrementPartNumber_design = IncrementPartNumber+1;
					printf("\n IncrementPartNumber_design====>[%d]", IncrementPartNumber_design);fflush(stdout);
					sprintf(vstr,"%d",IncrementPartNumber_design);
					tc_strcpy(Partstr,vstr);
				}
				if(IncrementPartNumber>=99)
				{
					if(IncrementDgId<10)
					{
						IncrementDgId_1 = IncrementDgId+1;
						sprintf(dgidstr,"%d",IncrementDgId_1);
						if(IncrementDgId_1==10)
						{
							tc_strcpy(DesigIdstr,dgidstr);
						}
						else
						{
							tc_strcpy(DesigIdstr,"0");
							tc_strcat(DesigIdstr,dgidstr);
						}
						
						printf("\n DesigIdstr [%s] ",DesigIdstr);fflush(stdout);
					}
					if(IncrementDgId>=10 && IncrementDgId<=98)
					{
						IncrementDgId_1 = IncrementDgId+1;
						sprintf(dgidstr,"%d",IncrementDgId_1);
						tc_strcpy(DesigIdstr,dgidstr);
						printf("\n DesigIdstr [%s] ",DesigIdstr);fflush(stdout);
					}
				}
				if(strlen(Partstr)>0 && IncrementPartNumber_design<=99)
				{
					printf("\n Partstr====>[%s]", Partstr);fflush(stdout);
					thisPartNumber = (char *) MEM_alloc( 20 * sizeof(char) );
					tc_strcpy(thisPartNumber, ProjectNameS);
					tc_strcat(thisPartNumber,t5DesignGroupS);
					tc_strcat(thisPartNumber,t5NwDgSbGrpS);
					tc_strcat(thisPartNumber,t5NwDgIdS);
					tc_strcat(thisPartNumber,Partstr);

					printf("\n\n 5 Going to  Create Part Ledger -->%s\n\n",thisPartNumber);fflush(stdout);
				}
				printf("\n DesigIdstr length====>[%d]", tc_strlen(DesigIdstr));fflush(stdout);
				if(tc_strlen(DesigIdstr)>0)
				{
					printf("\n DesigIdstr====>[%s]", DesigIdstr);fflush(stdout);
					this_PartNumber = (char *) MEM_alloc( 20 * sizeof(char) );
					tc_strcpy(this_PartNumber, ProjectNameS);
					tc_strcat(this_PartNumber,t5DesignGroupS);
					tc_strcat(this_PartNumber,t5NwDgSbGrpS);
					tc_strcat(this_PartNumber,DesigIdstr);
					tc_strcat(this_PartNumber,"*");
					qry_values2[0]	= this_PartNumber;
					qry_values2[1]	= "Design";
					//if(QRY_execute_with_sort(query2, 2, qry_entries2, qry_values2, num_to_sort, keys, orders, &designfound, &q_designfound) !=ITK_ok) PrintErrorStack();
					QRY_execute_with_sort(query2, 2, qry_entries2, qry_values2, designnum_to_sort, designkeys, designorders, &designfound, &q_designfound);
					printf("\n designfound =[%d]",designfound);fflush(stdout);
					if(designfound>0)
					{
						int totalPart2 = 0;
						tag_t		 *soResult2				=  NULLTAG;
						soResult2 = (tag_t *) MEM_alloc( designfound * sizeof(tag_t) );
						for(dsgcnt2=0;dsgcnt2<designfound;dsgcnt2++)
						{
							AOM_ask_value_string(q_designfound[dsgcnt2],"item_id",&TEMP_revid2);
							printf("\n TEMP_revid2====>[%s]", TEMP_revid2);fflush(stdout);
							AOM_ask_value_string(q_designfound[dsgcnt],"t5_RevPartType",&rev_PrtType2);
							printf("\n rev_PrtType2====>[%s]", rev_PrtType2);fflush(stdout);
							if(tc_strlen(TEMP_revid2)==12)
							{
								if(tc_strlen(TEMP_revid2)==12 && (tc_strcmp(rev_PrtType2,"A")==0 || tc_strcmp(rev_PrtType2,"Assembly")==0 || tc_strcmp(rev_PrtType2,"Component")==0 || tc_strcmp(rev_PrtType2,"C")==0 || tc_strlen(rev_PrtType2)==0))
								{
									setAddTAG(&totalPart2,&soResult2,q_designfound[dsgcnt2]);
								}
							}
						}
						printf("\n totalPart2====>[%d]", totalPart2);fflush(stdout);
						if(totalPart2>0)
						{
							design_tag = soResult2[0];
						}
						else
						{
							if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
							{
								thisPartNumber = (char *) MEM_alloc( 20 * sizeof(char) );
								tc_strcpy(thisPartNumber, ProjectNameS);
								tc_strcat(thisPartNumber,t5DesignGroupS);
								tc_strcat(thisPartNumber,t5NwDgSbGrpS);
								tc_strcat(thisPartNumber,t5NwDgIdS);
								tc_strcat(thisPartNumber,"01");
								printf("\n\n 6 Going to  Create Part Ledger -->%s\n\n",thisPartNumber);fflush(stdout);
							}
						}
						//design_tag = q_designfound[0];
						if(design_tag!=NULLTAG)
						{
							AOM_ask_value_string(design_tag,"item_id",&design_id);
							printf("\n design_id====>[%s]", design_id);fflush(stdout);

							desigIdtempId = (char *) MEM_alloc(2 * sizeof(char) );
							desigIdvstr = (char *) MEM_alloc(2 * sizeof(char) );
							desigIdPartstr = (char *) MEM_alloc(2 * sizeof(char) );
							desigIdtempId= NewPartsubString(design_id,10,2);
							printf("\n desigIdtempId====>[%s]", desigIdtempId);fflush(stdout);
							Increment_PartNumber = atoi(desigIdtempId);
							if(Increment_PartNumber<10)
							{
								IncrementPartNumber_design_1 = Increment_PartNumber+1;
								sprintf(desigIdvstr,"%d",IncrementPartNumber_design_1);
								if(IncrementPartNumber_design_1==10)
								{
									tc_strcpy(desigIdPartstr,desigIdvstr);
								}
								else
								{
									tc_strcpy(desigIdPartstr,"0");
									tc_strcat(desigIdPartstr,desigIdvstr);
								}
								
								printf("\n desigIdPartstr [%s] ",desigIdPartstr);fflush(stdout);
							}
							if(Increment_PartNumber>=10 && Increment_PartNumber<=98)
							{
								IncrementPartNumber_design_1 = Increment_PartNumber+1;
								sprintf(desigIdvstr,"%d",IncrementPartNumber_design_1);
								tc_strcpy(desigIdPartstr,desigIdvstr);
							}
							if(strlen(desigIdPartstr)>0)
							{
								printf("\n desigIdPartstr====>[%s]", desigIdPartstr);fflush(stdout);
								thisPartNumber = (char *) MEM_alloc( 20 * sizeof(char) );
								tc_strcpy(thisPartNumber, ProjectNameS);
								tc_strcat(thisPartNumber,t5DesignGroupS);
								tc_strcat(thisPartNumber,t5NwDgSbGrpS);
								tc_strcat(thisPartNumber,DesigIdstr);
								tc_strcat(thisPartNumber,desigIdPartstr);
								printf("\n\n 7 Going to  Create Part Ledger -->%s\n\n",thisPartNumber);fflush(stdout);
							}
						}
					}
					else
					{
						thisPartNumber = (char *) MEM_alloc( 20 * sizeof(char) );
						tc_strcpy(thisPartNumber, ProjectNameS);
						tc_strcat(thisPartNumber,t5DesignGroupS);
						tc_strcat(thisPartNumber,t5NwDgSbGrpS);
						tc_strcat(thisPartNumber,DesigIdstr);
						tc_strcat(thisPartNumber,"01");
						printf("\n\n 8 Going to  Create Part Ledger -->%s\n\n",thisPartNumber);fflush(stdout);
					}
				}/////////////
			}
			else if((tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0))
			{
				tempId = (char *) MEM_alloc(4 * sizeof(char) );
				vstr = (char *) MEM_alloc(4 * sizeof(char) );
				Partstr = (char *) MEM_alloc(4 * sizeof(char) );
				tempId= NewPartsubString(revid,11,3);
				printf("\n for 14 digit tempId====>[%s]", tempId);fflush(stdout);
				//len = strlen(tempId);
				printf("\n for 14 digit len====>[%d]", len);fflush(stdout);
				IncrementPartNumber = atoi(tempId);
				printf("\n for 14 digit IncrementPartNumber====>[%d]", IncrementPartNumber);fflush(stdout);
				IncrementPartNumber_design = IncrementPartNumber+1;
				printf("\n Next Serial Number integer to be appended for module part number is :: %d \n",IncrementPartNumber_design);fflush(stdout);
				sprintf(vstr,"%d",IncrementPartNumber_design);
				len = strlen(vstr);
				if(len==2)
				{
					tc_strcpy(Partstr,"0");
					tc_strcat(Partstr,vstr);
					printf("\n for 14 digit Partstr [%s] ",Partstr);fflush(stdout);
				}
				else if(len==1)
				{
					tc_strcpy(Partstr,"00");
					tc_strcat(Partstr,vstr);
					printf("\n for 14 digit Partstr [%s] ",Partstr);fflush(stdout);
				}
				else
				{
					tc_strcpy(Partstr,vstr);
					printf("\n for 14 digit Partstr [%s] ",Partstr);fflush(stdout);
				}

				if(strlen(Partstr)>0)
				{
					printf("\n Partstr====>[%s]", Partstr);fflush(stdout);
					thisPartNumber = (char *) MEM_alloc( 20 * sizeof(char) );
					tc_strcpy(thisPartNumber, ProjectNameS);
					tc_strcat(thisPartNumber,SubModuleAddress);
					tc_strcat(thisPartNumber,t5DesignGroupS);
					tc_strcat(thisPartNumber,Partstr);

					printf("\n\n For 9 Digit 2 Going to  Create Part Ledger -->%s\n\n",thisPartNumber);fflush(stdout);
				}
			}/////
			else if((tc_strcmp(PartType,"T")==0 || tc_strcmp(PartType,"Technical Part List")==0))
			{
				tc_strcpy(thisPartNumber, ProposeTPLNum);
			}
			else
			{
				tc_strcpy(thisPartNumber, "NA");
			}
		}
		
	} ////elseif

		// Part ledger ...
	else if(n_found1>0 && n_found2==0)
	{
		prt_ledger_tag = q_item1[0];
		AOM_ask_value_string(prt_ledger_tag,"object_name",&revid);
		printf("\n part ledger revid====>[%s]", revid);fflush(stdout);

		//if(isFor12Digit==true && isFor14Digit==false)
		if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
		{
			tempId = (char *) MEM_alloc(2 * sizeof(char) );
			vstr = (char *) MEM_alloc(2 * sizeof(char) );
			dgidstr = (char *) MEM_alloc(2 * sizeof(char) );
			Partstr = (char *) MEM_alloc(2 * sizeof(char) );
			DesigIdstr = (char *) MEM_alloc(2 * sizeof(char) );
			tempId= NewPartsubString(revid,10,2);
			printf("\n tempId====>[%s]", tempId);fflush(stdout);
			len = strlen(tempId);
			printf("\n len====>[%d]", len);fflush(stdout);
			IncrementPartNumber = atoi(tempId);
			IncrementDgId = atoi(t5NwDgIdS);
			printf("\n IncrementPartNumber====>[%d]", IncrementPartNumber);fflush(stdout);
			if(IncrementPartNumber<10)
			{
				IncrementPartNumber_Ledger = IncrementPartNumber+1;
				sprintf(vstr,"%d",IncrementPartNumber_Ledger);
				if(IncrementPartNumber_Ledger==10)
				{
					tc_strcpy(Partstr,vstr);
				}
				else
				{
					tc_strcpy(Partstr,"0");
					tc_strcat(Partstr,vstr);
				}
				printf("\n Partstr [%s] ",Partstr);fflush(stdout);
			}
			if(IncrementPartNumber>=10 && IncrementPartNumber<=98)
			{
				IncrementPartNumber_Ledger = IncrementPartNumber+1;
				sprintf(vstr,"%d",IncrementPartNumber_Ledger);
				tc_strcpy(Partstr,vstr);
			}
			if(IncrementPartNumber>=99)
			{
				if(IncrementDgId<10)
				{
					IncrementDgId_Ledger = IncrementDgId+1;
					sprintf(dgidstr,"%d",IncrementDgId_Ledger);
					if(IncrementDgId_Ledger==10)
					{
						tc_strcpy(DesigIdstr,dgidstr);
					}
					else
					{
						tc_strcpy(DesigIdstr,"0");
						tc_strcat(DesigIdstr,dgidstr);
					}
					printf("\n DesigIdstr [%s] ",DesigIdstr);fflush(stdout);
				}
				if(IncrementDgId>=10 && IncrementDgId<=98)
				{
					IncrementDgId_Ledger = IncrementDgId+1;
					sprintf(dgidstr,"%d",IncrementDgId_Ledger);
					tc_strcpy(DesigIdstr,dgidstr);
					printf("\n DesigIdstr [%s] ",DesigIdstr);fflush(stdout);
				}
			}
			if(strlen(Partstr)>0 && IncrementPartNumber_Ledger<=99)
			{
				printf("\n Partstr====>[%s]", Partstr);fflush(stdout);
				thisPartNumber = (char *) MEM_alloc( 20 * sizeof(char) );
				tc_strcpy(thisPartNumber, ProjectNameS);
				tc_strcat(thisPartNumber,t5DesignGroupS);
				tc_strcat(thisPartNumber,t5NwDgSbGrpS);
				tc_strcat(thisPartNumber,t5NwDgIdS);
				tc_strcat(thisPartNumber,Partstr);

				printf("\n\n 10 Going to  Create Part Ledger -->%s\n\n",thisPartNumber);fflush(stdout);
			}
			if(strlen(DesigIdstr)>0)
			{
				printf("\n DesigIdstr====>[%s]", DesigIdstr);fflush(stdout);
				this_PartNumber_partLedger = (char *) MEM_alloc( 20 * sizeof(char) );
				tc_strcpy(this_PartNumber_partLedger, ProjectNameS);
				tc_strcat(this_PartNumber_partLedger,t5DesignGroupS);
				tc_strcat(this_PartNumber_partLedger,t5NwDgSbGrpS);
				tc_strcat(this_PartNumber_partLedger,DesigIdstr);
				tc_strcat(this_PartNumber_partLedger,"*");
				printf("\n this_PartNumber_partLedger====>[%s]", this_PartNumber_partLedger);fflush(stdout);
				qry_values1[0]	= this_PartNumber_partLedger;
				qry_values1[1]	= "Part Ledger";
				//if(QRY_execute_with_sort(query1, 2, qry_entries1, qry_values1, num_to_sort, keys, orders, &partledgerfound, &q_partledgeritem) !=ITK_ok) PrintErrorStack();
				QRY_execute_with_sort(query1, 2, qry_entries1, qry_values1, partledgernum_to_sort, partledgerkeys, partledgerorders, &partledgerfound, &q_partledgeritem);
				printf("\n partledgerfound =[%d]",partledgerfound);fflush(stdout);
				if(partledgerfound>0)
				{
					partledger_tag = q_partledgeritem[0];
					AOM_ask_value_string(partledger_tag,"object_name",&partledger_id);
					printf("\n partledger_id====>[%s]", partledger_id);fflush(stdout);

					prtledgertempId = (char *) MEM_alloc(2 * sizeof(char) );
					prtledgervstr = (char *) MEM_alloc(2 * sizeof(char) );
					prtledgerPartstr = (char *) MEM_alloc(2 * sizeof(char) );
					prtledgertempId= NewPartsubString(partledger_id,10,2);
					printf("\n prtledgertempId====>[%s]", prtledgertempId);fflush(stdout);
					Increment_PartNumber_ledger = atoi(prtledgertempId);
					if(Increment_PartNumber_ledger<10)
					{
						Increment_PartNumber_PartLedger = Increment_PartNumber_ledger+1;
						sprintf(prtledgervstr,"%d",Increment_PartNumber_PartLedger);
						if(Increment_PartNumber_PartLedger==10)
						{
							tc_strcpy(prtledgerPartstr,prtledgervstr);
						}
						else
						{
							tc_strcpy(prtledgerPartstr,"0");
							tc_strcat(prtledgerPartstr,prtledgervstr);
						}
						printf("\n prtledgerPartstr [%s] ",prtledgerPartstr);fflush(stdout);
					}
					if(Increment_PartNumber_ledger>=10 && Increment_PartNumber_ledger<=98)
					{
						Increment_PartNumber_PartLedger = Increment_PartNumber_ledger+1;
						sprintf(prtledgervstr,"%d",Increment_PartNumber_PartLedger);
						tc_strcpy(prtledgerPartstr,prtledgervstr);
					}
					if(strlen(prtledgerPartstr)>0)
					{
						printf("\n prtledgerPartstr====>[%s]", prtledgerPartstr);fflush(stdout);
						thisPartNumber = (char *) MEM_alloc( 20 * sizeof(char) );
						tc_strcpy(thisPartNumber, ProjectNameS);
						tc_strcat(thisPartNumber,t5DesignGroupS);
						tc_strcat(thisPartNumber,t5NwDgSbGrpS);
						tc_strcat(thisPartNumber,DesigIdstr);
						tc_strcat(thisPartNumber,prtledgerPartstr);
						printf("\n\n 11 Going to  Create Part Ledger -->%s\n\n",thisPartNumber);fflush(stdout);
					}
				}
				else
				{
					thisPartNumber = (char *) MEM_alloc( 20 * sizeof(char) );
					tc_strcpy(thisPartNumber, ProjectNameS);
					tc_strcat(thisPartNumber,t5DesignGroupS);
					tc_strcat(thisPartNumber,t5NwDgSbGrpS);
					tc_strcat(thisPartNumber,DesigIdstr);
					tc_strcat(thisPartNumber,"01");
					printf("\n\n 12 Going to  Create Part Ledger -->%s\n\n",thisPartNumber);fflush(stdout);
				}
			}
		}
		if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
		{
			tempId = (char *) MEM_alloc(4 * sizeof(char) );
			vstr = (char *) MEM_alloc(4 * sizeof(char) );
			Partstr = (char *) MEM_alloc(4 * sizeof(char) );
			tempId= NewPartsubString(revid,11,3);
			printf("\n for 14 digit tempId====>[%s]", tempId);fflush(stdout);
			//len = strlen(tempId);
			printf("\n for 14 digit len====>[%d]", len);fflush(stdout);
			IncrementPartNumber = atoi(tempId);
			printf("\n for 14 digit IncrementPartNumber====>[%d]", IncrementPartNumber);fflush(stdout);
			IncrementPartNumber_Ledger = IncrementPartNumber+1;
			printf("\n Next Serial Number integer to be appended for module part number is :: %d \n",IncrementPartNumber_Ledger);fflush(stdout);
			sprintf(vstr,"%d",IncrementPartNumber_Ledger);
			len = strlen(vstr);
			if(len==2)
			{
				tc_strcpy(Partstr,"0");
				tc_strcat(Partstr,vstr);
				printf("\n for 14 digit Partstr [%s] ",Partstr);fflush(stdout);
			}
			else if(len==1)
			{
				tc_strcpy(Partstr,"00");
				tc_strcat(Partstr,vstr);
				printf("\n for 14 digit Partstr [%s] ",Partstr);fflush(stdout);
			}
			else
			{
				tc_strcpy(Partstr,vstr);
				printf("\n for 14 digit Partstr [%s] ",Partstr);fflush(stdout);
			}

			if(strlen(Partstr)>0)
			{
				printf("\n Partstr====>[%s]", Partstr);fflush(stdout);
				thisPartNumber = (char *) MEM_alloc( 20 * sizeof(char) );
				tc_strcpy(thisPartNumber, ProjectNameS);
				tc_strcat(thisPartNumber,SubModuleAddress);
				tc_strcat(thisPartNumber,t5DesignGroupS);
				tc_strcat(thisPartNumber,Partstr);

				printf("\n\n For 13 Digit 2 Going to  Create Part Ledger -->%s\n\n",thisPartNumber);fflush(stdout);
			}
		}
		if((tc_strcmp(PartType,"T")==0 || tc_strcmp(PartType,"Technical Part List")==0))
		{
			tc_strcpy(thisPartNumber, ProposeTPLNum);
		}
		
	} ///11
	else
	{
		tag_t		 *soResult1					=  NULLTAG;
		int  totalPart = 0;
		int  IFDModule = 0;
		int  ISModule = 0;
		soResult1 = (tag_t *) MEM_alloc( n_found2 * sizeof(tag_t) );
		for(dsgcnt=0;dsgcnt<n_found2;dsgcnt++)
		{
			AOM_ask_value_string(q_item2[dsgcnt],"item_id",&TEMPrevid);
			printf("\n TEMPrevid====>[%s]", TEMPrevid);fflush(stdout);
			AOM_ask_value_string(q_item2[dsgcnt],"t5_RevPartType",&revPrtType);
			printf("\n revPrtType====>[%s]", revPrtType);fflush(stdout);
			if(tc_strlen(TEMPrevid)==14 || tc_strlen(TEMPrevid)==12)
			{
				if(tc_strlen(TEMPrevid)==14)
				{
					IFDModule = FunToQueryIFDModuleAddress(SubModuleAddress);
					ISModule = FunToQueryModuleAddress(SubModuleAddress);
				}
				
				if(tc_strlen(TEMPrevid)==14 && 
					(tc_strcmp(revPrtType,"M")==0 || tc_strcmp(revPrtType,"Module")==0 
					|| tc_strcmp(revPrtType,"IM")==0 || tc_strcmp(revPrtType,"IFD Module")==0
					|| tc_strcmp(revPrtType,"EM")==0 || tc_strcmp(revPrtType,"ECU Module")==0 || tc_strlen(revPrtType)==0 || IFDModule==1)
					&& (tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0) && ISModule==1)
				{
					setAddTAG(&totalPart,&soResult1,q_item2[dsgcnt]);
				}
				if(tc_strlen(TEMPrevid)==12 && 
					(tc_strcmp(revPrtType,"A")==0 || tc_strcmp(revPrtType,"Assembly")==0 
					|| tc_strcmp(revPrtType,"Component")==0 || tc_strcmp(revPrtType,"C")==0 || tc_strlen(revPrtType)==0)
					&& (tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Assembly")==0 
					|| tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0))
				{
					setAddTAG(&totalPart,&soResult1,q_item2[dsgcnt]);
				}

				if((tc_strcmp(revPrtType,"T")==0 || tc_strcmp(revPrtType,"Technical Part List")==0)
					&& (tc_strcmp(PartType,"T")==0 || tc_strcmp(PartType,"Technical Part List")==0))
				{
					setAddTAG(&totalPart,&soResult1,q_item2[dsgcnt]);
				}
			}
		}
		printf("\n totalPart====>[%d]", totalPart);fflush(stdout);
		if(totalPart>0)
		{
			prt_tag = soResult1[0];
		}
		//prt_tag = q_item2[0];
		if(prt_tag!=NULLTAG)
		{
			AOM_ask_value_string(prt_tag,"item_id",&revid);
			printf("\n part revid====>[%s]", revid);fflush(stdout);

			prt_ledger_tag = q_item1[0];
			AOM_ask_value_string(prt_ledger_tag,"object_name",&revid1);
			printf("\n part ledger revid====>[%s]", revid1);fflush(stdout);

			//if(isFor12Digit==true && isFor14Digit==false)
			if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
			{
				tempId = (char *) MEM_alloc(2 * sizeof(char) );
				tempId1 = (char *) MEM_alloc(2 * sizeof(char) );
				vstr = (char *) MEM_alloc(2 * sizeof(char) );
				dgidstr = (char *) MEM_alloc(2 * sizeof(char) );
				Partstr = (char *) MEM_alloc(2 * sizeof(char) );
				DesigIdstr = (char *) MEM_alloc(2 * sizeof(char) );
				prtledger_design_vstr = (char *) MEM_alloc(2 * sizeof(char) );
				prtledger_design_Partstr = (char *) MEM_alloc(2 * sizeof(char) );
				tempId= NewPartsubString(revid,10,2);
				tempId1= NewPartsubString(revid1,10,2);
				printf("\n tempId====>[%s]", tempId);fflush(stdout);
				printf("\n tempId1====>[%s]", tempId1);fflush(stdout);
				len = tc_strlen(tempId);
				printf("\n len====>[%d]", len);fflush(stdout);
				IncrementPartNumber = atoi(tempId);
				IncrementPartNumber1 = atoi(tempId1);
				IncrementDgId = atoi(t5NwDgIdS);
				printf("\n IncrementPartNumber====>[%d]", IncrementPartNumber);fflush(stdout);
				printf("\n IncrementPartNumber1====>[%d]", IncrementPartNumber1);fflush(stdout);
				printf("\n IncrementDgId====>[%d]", IncrementDgId);fflush(stdout);
				if(IncrementPartNumber>IncrementPartNumber1)
				{
					FinalIncrement = IncrementPartNumber+1;
				}
				if(IncrementPartNumber<IncrementPartNumber1)
				{
					FinalIncrement = IncrementPartNumber1+1;
				}
				if(IncrementPartNumber==IncrementPartNumber1)
				{
					FinalIncrement = IncrementPartNumber+1;
				}
				printf("\n FinalIncrement====>[%d]", FinalIncrement);fflush(stdout);
				if(FinalIncrement<10)
				{
					sprintf(vstr,"%d",FinalIncrement);
					if(FinalIncrement==10)
					{
						tc_strcpy(Partstr,vstr);
					}
					else
					{
						tc_strcpy(Partstr,"0");
						tc_strcat(Partstr,vstr);
					}
					
					printf("\n Partstr [%s] ",Partstr);fflush(stdout);
				}
				if(FinalIncrement>=10 && FinalIncrement<=99)
				{
					sprintf(vstr,"%d",FinalIncrement);
					tc_strcpy(Partstr,vstr);
				}
				if(FinalIncrement>99)
				{
					if(IncrementDgId<10)
					{
						Increment_DgId = IncrementDgId+1;
						sprintf(dgidstr,"%d",Increment_DgId);
						if(Increment_DgId==10)
						{
							tc_strcpy(DesigIdstr,dgidstr);
						}
						else
						{
							tc_strcpy(DesigIdstr,"0");
							tc_strcat(DesigIdstr,dgidstr);
						}
						printf("\n DesigIdstr [%s] ",DesigIdstr);fflush(stdout);
					}
					if(IncrementDgId>=10 && IncrementDgId<=98)
					{
						Increment_DgId = IncrementDgId+1;
						sprintf(dgidstr,"%d",Increment_DgId);
						tc_strcpy(DesigIdstr,dgidstr);
						printf("\n DesigIdstr [%s] ",DesigIdstr);fflush(stdout);
					}
				}
				if(tc_strlen(Partstr)>0 && FinalIncrement<=99)
				{
					printf("\n Partstr====>[%s]", Partstr);fflush(stdout);
					thisPartNumber = (char *) MEM_alloc( 20 * sizeof(char) );
					tc_strcpy(thisPartNumber, ProjectNameS);
					tc_strcat(thisPartNumber,t5DesignGroupS);
					tc_strcat(thisPartNumber,t5NwDgSbGrpS);
					tc_strcat(thisPartNumber,t5NwDgIdS);
					tc_strcat(thisPartNumber,Partstr);

					printf("\n\n 14 Going to  Create Part Ledger -->%s\n\n",thisPartNumber);fflush(stdout);
				}

				printf("\n DesigIdstr length ====>[%d]", tc_strlen(DesigIdstr));fflush(stdout);
				if(tc_strlen(DesigIdstr)>0)
				{
					printf("\n DesigIdstr====>[%s]", DesigIdstr);fflush(stdout);
					this_PartNumber_partLedger = (char *) MEM_alloc( 20 * sizeof(char) );
					tc_strcpy(this_PartNumber_partLedger, ProjectNameS);
					tc_strcat(this_PartNumber_partLedger,t5DesignGroupS);
					tc_strcat(this_PartNumber_partLedger,t5NwDgSbGrpS);
					tc_strcat(this_PartNumber_partLedger,DesigIdstr);
					tc_strcat(this_PartNumber_partLedger,"*");
					printf("\n this_PartNumber_partLedger====>[%s]", this_PartNumber_partLedger);fflush(stdout);
					qry_values1[0]	= this_PartNumber_partLedger;
					qry_values1[1]	= "Part Ledger";
					//if(QRY_execute_with_sort(query1, 2, qry_entries1, qry_values1, num_to_sort, keys, orders, &partledgerfound, &q_partledgeritem) !=ITK_ok) PrintErrorStack();
					QRY_execute_with_sort(query1, 2, qry_entries1, qry_values1, partledgernum_to_sort, partledgerkeys, partledgerorders, &partledgerfound, &q_partledgeritem);
					printf("\n partledgerfound =[%d]",partledgerfound);fflush(stdout);

					if(partledgerfound>0)
					{
						partledger_tag = q_partledgeritem[0];
						AOM_ask_value_string(partledger_tag,"object_name",&partledger_id);
						printf("\n partledger_id====>[%s]", partledger_id);fflush(stdout);
						prtledgertempId = (char *) MEM_alloc(2 * sizeof(char) );
						prtledgervstr = (char *) MEM_alloc(2 * sizeof(char) );
						prtledgerPartstr = (char *) MEM_alloc(2 * sizeof(char) );
						prtledgertempId= NewPartsubString(partledger_id,10,2);
						printf("\n prtledgertempId====>[%s]", prtledgertempId);fflush(stdout);
						Increment_PartNumber_ledger = atoi(prtledgertempId);
					}
					qry_values2[0]	= this_PartNumber_partLedger;
					qry_values2[1]	= "Design";
					//if(QRY_execute_with_sort(query2, 2, qry_entries2, qry_values2, num_to_sort, keys, orders, &designfound, &q_designfound) !=ITK_ok) PrintErrorStack();
					QRY_execute_with_sort(query2, 2, qry_entries2, qry_values2, designnum_to_sort, designkeys, designorders, &designfound, &q_designfound);
					printf("\n designfound =[%d]",designfound);fflush(stdout);
					if(designfound>0)
					{
						tag_t		 *soResult2					=  NULLTAG;
						int  total_Part = 0;
						soResult2 = (tag_t *) MEM_alloc( designfound * sizeof(tag_t) );
						for(dsg_cnt=0;dsg_cnt<designfound;dsg_cnt++)
						{
							AOM_ask_value_string(q_designfound[dsg_cnt],"item_id",&TEMP_revid);
							printf("\n TEMP_revid====>[%s]", TEMP_revid);fflush(stdout);
							AOM_ask_value_string(q_designfound[dsg_cnt],"t5_RevPartType",&rev_PrtType);
							printf("\n rev_PrtType====>[%s]", rev_PrtType);fflush(stdout);
							if(tc_strlen(TEMP_revid)==14 || tc_strlen(TEMP_revid)==12)
							{								
								if(tc_strlen(TEMP_revid)==12 && (tc_strcmp(rev_PrtType,"A")==0 || tc_strcmp(rev_PrtType,"Assembly")==0 || tc_strcmp(rev_PrtType,"Component")==0 || tc_strcmp(rev_PrtType,"C")==0 || tc_strlen(rev_PrtType)==0))
								{
									setAddTAG(&total_Part,&soResult2,q_designfound[dsg_cnt]);
								}
							}
						}
						printf("\n total_Part====>[%d]", total_Part);fflush(stdout);
						if(total_Part>0)
						{
							design_tag = q_designfound[0];
							AOM_ask_value_string(design_tag,"item_id",&design_id);
							printf("\n design_id====>[%s]", design_id);fflush(stdout);
							desigIdtempId = (char *) MEM_alloc(2 * sizeof(char) );
							desigIdvstr = (char *) MEM_alloc(2 * sizeof(char) );
							desigIdPartstr = (char *) MEM_alloc(2 * sizeof(char) );
							desigIdtempId= NewPartsubString(design_id,10,2);
							printf("\n desigIdtempId====>[%s]", desigIdtempId);fflush(stdout);
							Increment_PartNumber = atoi(desigIdtempId);
							printf("\n Increment_PartNumber====>[%d]", Increment_PartNumber);fflush(stdout);
							printf("\n Increment_PartNumber_ledger====>[%d]", Increment_PartNumber_ledger);fflush(stdout);
							if(Increment_PartNumber>Increment_PartNumber_ledger)
							{
								Final_Increment = Increment_PartNumber+1;
							}
							if(Increment_PartNumber<Increment_PartNumber_ledger)
							{
								Final_Increment = Increment_PartNumber_ledger+1;
							}
							if(Increment_PartNumber==Increment_PartNumber_ledger)
							{
								Final_Increment = Increment_PartNumber+1;
							}
						}
					}
					
					
					printf("\n Final_Increment====>[%d]", Final_Increment);fflush(stdout);
					if(Final_Increment<10)
					{
						sprintf(prtledger_design_vstr,"%d",Final_Increment);
						if(Final_Increment==10)
						{
							tc_strcpy(prtledger_design_Partstr,prtledger_design_vstr);
						}
						else
						{
							tc_strcpy(prtledger_design_Partstr,"0");
							tc_strcat(prtledger_design_Partstr,prtledger_design_vstr);
						}
						printf("\n prtledger_design_Partstr [%s] ",prtledger_design_Partstr);fflush(stdout);
					}
					if(Final_Increment>=10 && Final_Increment<=98)
					{
						sprintf(prtledger_design_vstr,"%d",Final_Increment);
						tc_strcpy(prtledger_design_Partstr,prtledger_design_vstr);
						printf("\n prtledger_design_Partstr [%s] ",prtledger_design_Partstr);fflush(stdout);
					}
					if(tc_strlen(prtledger_design_Partstr)>0)
					{
						printf("\n prtledger_design_Partstr====>[%s]", prtledger_design_Partstr);fflush(stdout);
						thisPartNumber = (char *) MEM_alloc( 20 * sizeof(char) );
						tc_strcpy(thisPartNumber, ProjectNameS);
						tc_strcat(thisPartNumber,t5DesignGroupS);
						tc_strcat(thisPartNumber,t5NwDgSbGrpS);
						tc_strcat(thisPartNumber,DesigIdstr);
						tc_strcat(thisPartNumber,prtledger_design_Partstr);
						printf("\n\n 15 Going to  Create Part Ledger -->%s\n\n",thisPartNumber);fflush(stdout);
					}
				}
			}
			if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
			{
				tempId = (char *) MEM_alloc(4 * sizeof(char) );
				tempId1 = (char *) MEM_alloc(4 * sizeof(char) );
				vstr = (char *) MEM_alloc(4 * sizeof(char) );
				Partstr = (char *) MEM_alloc(4 * sizeof(char) );
				prtledger_design_vstr = (char *) MEM_alloc(4 * sizeof(char) );
				prtledger_design_Partstr = (char *) MEM_alloc(4 * sizeof(char) );
				tempId= NewPartsubString(revid,11,3);
				tempId1= NewPartsubString(revid1,11,3);
				printf("\n tempId====>[%s]", tempId);fflush(stdout);
				printf("\n tempId1====>[%s]", tempId1);fflush(stdout);

				IncrementPartNumber = atoi(tempId);
				IncrementPartNumber1 = atoi(tempId1);
				printf("\n IncrementPartNumber====>[%d]", IncrementPartNumber);fflush(stdout);
				printf("\n IncrementPartNumber1====>[%d]", IncrementPartNumber1);fflush(stdout);
				if(IncrementPartNumber>IncrementPartNumber1)
				{
					FinalIncrement = IncrementPartNumber+1;
				}
				if(IncrementPartNumber<IncrementPartNumber1)
				{
					FinalIncrement = IncrementPartNumber1+1;
				}
				if(IncrementPartNumber==IncrementPartNumber1)
				{
					FinalIncrement = IncrementPartNumber+1;
				}
				printf("\n FinalIncrement====>[%d]", FinalIncrement);fflush(stdout);
				sprintf(vstr,"%d",FinalIncrement);
				printf("\n vstr====>[%s]", vstr);fflush(stdout);
				len = strlen(vstr);
				if(len==2)
				{
					tc_strcpy(Partstr,"0");
					tc_strcat(Partstr,vstr);
					printf("\n for 14 digit Partstr [%s] ",Partstr);fflush(stdout);
				}
				else if(len==1)
				{
					tc_strcpy(Partstr,"00");
					tc_strcat(Partstr,vstr);
					printf("\n for 14 digit Partstr [%s] ",Partstr);fflush(stdout);
				}
				else
				{
					tc_strcpy(Partstr,vstr);
					printf("\n for 14 digit Partstr [%s] ",Partstr);fflush(stdout);
				}

				if(strlen(Partstr)>0)
				{
					printf("\n Partstr====>[%s]", Partstr);fflush(stdout);
					thisPartNumber = (char *) MEM_alloc( 20 * sizeof(char) );
					tc_strcpy(thisPartNumber, ProjectNameS);
					tc_strcat(thisPartNumber,SubModuleAddress);
					tc_strcat(thisPartNumber,t5DesignGroupS);
					tc_strcat(thisPartNumber,Partstr);

					printf("\n\n for 16 digit 8 Going to  Create Part Ledger -->%s\n\n",thisPartNumber);fflush(stdout);
				}
				printf("\n SubModuleAddress length ====>[%d]", tc_strlen(SubModuleAddress));fflush(stdout);
				if(tc_strlen(SubModuleAddress)>0)
				{
					Is_Module = 0;
					printf("\n SubModuleAddress====>[%s]", SubModuleAddress);fflush(stdout);
					this_PartNumber_partLedger = (char *) MEM_alloc( 20 * sizeof(char) );
					tc_strcpy(this_PartNumber_partLedger, ProjectNameS);
					tc_strcat(this_PartNumber_partLedger,SubModuleAddress);
					tc_strcat(this_PartNumber_partLedger,t5DesignGroupS);
					tc_strcat(this_PartNumber_partLedger,"*");
					printf("\n this_PartNumber_partLedger====>[%s]", this_PartNumber_partLedger);fflush(stdout);
					qry_values1[0]	= this_PartNumber_partLedger;
					qry_values1[1]	= "Part Ledger";
					//if(QRY_execute_with_sort(query1, 2, qry_entries1, qry_values1, num_to_sort, keys, orders, &partledgerfound, &q_partledgeritem) !=ITK_ok) PrintErrorStack();
					QRY_execute_with_sort(query1, 2, qry_entries1, qry_values1, partledgernum_to_sort, partledgerkeys, partledgerorders, &partledgerfound, &q_partledgeritem);
					printf("\n partledgerfound =[%d]",partledgerfound);fflush(stdout);
					
					if(partledgerfound>0)
					{
						partledger_tag = q_partledgeritem[0];
						AOM_ask_value_string(partledger_tag,"object_name",&partledger_id);
						printf("\n partledger_id====>[%s]", partledger_id);fflush(stdout);
						prtledgertempId = (char *) MEM_alloc(4 * sizeof(char) );
						prtledgervstr = (char *) MEM_alloc(4 * sizeof(char) );
						prtledgerPartstr = (char *) MEM_alloc(4 * sizeof(char) );
						prtledgertempId= NewPartsubString(partledger_id,11,3);
						printf("\n prtledgertempId====>[%s]", prtledgertempId);fflush(stdout);
						Increment_PartNumber_ledger = atoi(prtledgertempId);
					}
					qry_values2[0]	= this_PartNumber_partLedger;
					qry_values2[1]	= "Design";
					//if(QRY_execute_with_sort(query2, 2, qry_entries2, qry_values2, num_to_sort, keys, orders, &designfound, &q_designfound) !=ITK_ok) PrintErrorStack();
					QRY_execute_with_sort(query2, 2, qry_entries2, qry_values2, designnum_to_sort, designkeys, designorders, &designfound, &q_designfound);
					printf("\n designfound =[%d]",designfound);fflush(stdout);
					if(designfound>0)
					{
						design_tag = q_designfound[0];
						AOM_ask_value_string(design_tag,"item_id",&design_id);
						AOM_ask_value_string(design_tag,"t5_RevPartType",&design_prt_type);
						Is_Module = FunToQueryModuleAddress(SubModuleAddress);
						
						if(tc_strlen(design_id)==14 && (tc_strcmp(design_prt_type,"Module")==0 || tc_strcmp(design_prt_type,"M")==0 || tc_strcmp(design_prt_type,"IFD Module")==0 || tc_strcmp(design_prt_type,"IM")==0 || tc_strcmp(design_prt_type,"ECU Module")==0 || tc_strcmp(design_prt_type,"EM")==0) && Is_Module==1)
						{
							printf("\n design_id====>[%s]", design_id);fflush(stdout);
							desigIdtempId = (char *) MEM_alloc(4 * sizeof(char) );
							desigIdvstr = (char *) MEM_alloc(4 * sizeof(char) );
							desigIdPartstr = (char *) MEM_alloc(4 * sizeof(char) );
							desigIdtempId= NewPartsubString(design_id,11,3);
							printf("\n desigIdtempId====>[%s]", desigIdtempId);fflush(stdout);
							Increment_PartNumber = atoi(desigIdtempId);

							printf("\n Increment_PartNumber====>[%d]", Increment_PartNumber);fflush(stdout);
							printf("\n Increment_PartNumber_ledger====>[%d]", Increment_PartNumber_ledger);fflush(stdout);
							if(Increment_PartNumber>Increment_PartNumber_ledger)
							{
								Final_Increment = Increment_PartNumber+1;
							}
							if(Increment_PartNumber<Increment_PartNumber_ledger)
							{
								Final_Increment = Increment_PartNumber_ledger+1;
							}
							if(Increment_PartNumber==Increment_PartNumber_ledger)
							{
								Final_Increment = Increment_PartNumber+1;
							}
							printf("\n Final_Increment====>[%d]", Final_Increment);fflush(stdout);
							sprintf(prtledger_design_vstr,"%d",Final_Increment);
							printf("\n prtledger_design_vstr====>[%s]", prtledger_design_vstr);fflush(stdout);
							len = strlen(prtledger_design_vstr);
							if(len==2)
							{
								tc_strcpy(prtledger_design_Partstr,"0");
								tc_strcat(prtledger_design_Partstr,prtledger_design_vstr);
								printf("\n for 1111 digit prtledger_design_Partstr [%s] ",prtledger_design_Partstr);fflush(stdout);
							}
							else if(len==1)
							{
								tc_strcpy(prtledger_design_Partstr,"00");
								tc_strcat(prtledger_design_Partstr,prtledger_design_vstr);
								printf("\n for 2222 digit prtledger_design_Partstr [%s] ",prtledger_design_Partstr);fflush(stdout);
							}
							else
							{
								tc_strcpy(prtledger_design_Partstr,prtledger_design_vstr);
								printf("\n for 3333 digit prtledger_design_Partstr [%s] ",prtledger_design_Partstr);fflush(stdout);
							}
						}
						
					}
					

					if(strlen(prtledger_design_Partstr)>0)
					{
						printf("\n prtledger_design_Partstr====>[%s]", prtledger_design_Partstr);fflush(stdout);
						thisPartNumber = (char *) MEM_alloc( 20 * sizeof(char) );
						tc_strcpy(thisPartNumber, ProjectNameS);
						tc_strcat(thisPartNumber,SubModuleAddress);
						tc_strcat(thisPartNumber,t5DesignGroupS);
						tc_strcat(thisPartNumber,prtledger_design_Partstr);

						printf("\n\n for 17 digit 9 Going to  Create Part Ledger -->%s\n\n",thisPartNumber);fflush(stdout);
					}
				}
			}// module
			if((tc_strcmp(PartType,"T")==0 || tc_strcmp(PartType,"Technical Part List")==0))
			{
				tc_strcpy(thisPartNumber, ProposeTPLNum);
			}
		}
		
	}

	printf("\n\n Finally Going To Create Part Ledger -->[%s]\n\n",thisPartNumber);fflush(stdout);

	int		IsAvailInUA			=	0;
	int		ValCntT				=	0;
	tag_t*	ValCntrlObjectTagT	=	NULLTAG;
	tag_t	qryTagT				=	NULLTAG;
	char    **qry_valuesT		=	(char **) MEM_alloc(10 * sizeof(char *));
	int		n_entryT			=	1;
	char    *qry_entryT[1]		=	{"SYSCD"};
	char *New_TML_Part_Number_NPR	= NULL;
	char *partDuplicateCheckStr	= NULL;
	char *partDuplicateCheckLocStr	= NULL;
	char *partDuplicateCheckShellStr	= NULL;
	char *itemId	= NULL;


	if(QRY_find2("ControlObjects", &qryTagT));
	if (qryTagT)
	{
		printf("\n Found Query ControlObjects  ");fflush(stdout);
	}
	else
	{
		printf("\n Not Found Query ControlObjects  ");fflush(stdout);
	}

	New_TML_Part_Number_NPR = (char *) MEM_alloc( 200 * sizeof(char) );

	qry_valuesT[0] = "NPRPartDuplicateCheck" ;
	if(QRY_execute(qryTagT, n_entryT, qry_entryT, qry_valuesT, &ValCntT, &ValCntrlObjectTagT));
	printf(" \n PartInTCE:ValCnt :%d:", ValCntT); fflush(stdout);
	if(ValCntT>0)
	{
		AOM_ask_value_string(ValCntrlObjectTagT[0],"t5_Userinfo2",&partDuplicateCheckStr);
		printf("\n partDuplicateCheckStr===>[%s]",partDuplicateCheckStr);fflush(stdout);

		AOM_ask_value_string(ValCntrlObjectTagT[0],"t5_Userinfo5",&partDuplicateCheckLocStr);
		printf("\n partDuplicateCheckLocStr===>[%s]",partDuplicateCheckLocStr);fflush(stdout);

		AOM_ask_value_string(ValCntrlObjectTagT[0],"t5_Userinfo7",&partDuplicateCheckShellStr);
		printf("\n partDuplicateCheckShellStr===>[%s]",partDuplicateCheckShellStr);fflush(stdout);

		IsAvailInUA = IsDesignRevisionAvail(thisPartNumber);

		if(IsAvailInUA == 0 && tc_strstr(partDuplicateCheckStr,"NPRPARTDUPLICATECHECK")!=NULL)
		{
			char *username=NULL;
			tag_t user_tag=NULLTAG;
			char*	sysCmnd	=	NULL;
			char *homeSite = NULL;
			char* PNoStr = NULL;
			char* FNameStr = NULL;
			sysCmnd=(char *) MEM_alloc(400);
			PNoStr=(char *) MEM_alloc(400);
			FNameStr=(char *) MEM_alloc(400);
			tc_strcpy(PNoStr,thisPartNumber);
			tc_strcpy(FNameStr,thisPartNumber);
			tc_strcat(FNameStr,".txt");
			printf("\n PNoStr: [%s]\n",PNoStr);fflush(stdout);
			printf("\n FNameStr: [%s]\n",FNameStr);fflush(stdout);
			POM_get_user(&username,&user_tag);
			AOM_UIF_ask_value(user_tag,"fnd0home_site",&homeSite);
			printf("\n homeSite===>[%s]",homeSite);fflush(stdout);
			if(tc_strcmp(homeSite,"CV_Production")==0)
			{
				tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/NPRCVPROD/PartCallingNPRCVShell.sh ");
			}
			else if(tc_strcmp(homeSite,"Production-Pune")==0)
			{
				tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/NPRUAPROD/PartCallingNPRPVShell.sh ");
			}
			else if(tc_strcmp(homeSite,"Cmitest")==0 || tc_strcmp(homeSite,"AWS_FullTextSearch_Solr_Site")==0)
			{
				tc_strcpy(sysCmnd,"/user/testcmi/Dev/devgroups/sudhir/NPRCheck/PartCallingNPRCMITESTShell.sh ");
			}
			else if(tc_strcmp(homeSite,"IMC--1750164028")==0 || tc_strcmp(homeSite,"IMC--1254497832")==0)
			{
				tc_strcpy(sysCmnd,"/user/infodba03/sudhir/NPRCheck/PartCallingNPRDEVShell.sh ");
			}
			else
			{
				//tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/PartCallingShell.sh ");
				tc_strcpy(sysCmnd,partDuplicateCheckLocStr);
				tc_strcat(sysCmnd,partDuplicateCheckShellStr);
				tc_strcat(sysCmnd," ");
				//tc_strcat(sysCmnd,"PartCallingNPROtherShell.sh ");
			}
			//tc_strcpy(sysCmnd,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/PartCallingShell.sh ");
			tc_strcat(sysCmnd,PNoStr);
			tc_strcat(sysCmnd," ");
			tc_strcat(sysCmnd,FNameStr);
			printf("\n Command: [%s]\n",sysCmnd);fflush(stdout);
			system(sysCmnd);
			MEM_free(sysCmnd);

			// File Open...

			FILE* fptr = NULL;
			char *File_Name = NULL;
			char *File_LOC = NULL;
			char *inputline = NULL;
			char	*f	=NULL;
			char	result1 [ 100000 ] ;
			char	result2 [ 100000 ] ;

			int i = 0;

			File_Name=(char *) MEM_alloc(200);
			File_LOC=(char *) MEM_alloc(400);
			tc_strcpy(File_Name,thisPartNumber);
			tc_strcat(File_Name,".txt");
			if(tc_strcmp(homeSite,"CV_Production")==0)
			{
				tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/NPRCVPROD/");
			}
			else if(tc_strcmp(homeSite,"Production-Pune")==0)
			{
				tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/NPRUAPROD/");
			}
			else if(tc_strcmp(homeSite,"Cmitest")==0 || tc_strcmp(homeSite,"AWS_FullTextSearch_Solr_Site")==0)
			{
				tc_strcpy(File_LOC,"/user/testcmi/Dev/devgroups/sudhir/NPRCheck/");
			}
			else if(tc_strcmp(homeSite,"IMC--1750164028")==0 || tc_strcmp(homeSite,"IMC--1254497832")==0)
			{
				tc_strcpy(File_LOC,"/user/infodba03/sudhir/NPRCheck/");
			}
			else
			{
				///tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/");
				tc_strcpy(File_LOC,partDuplicateCheckLocStr);
			}
			//tc_strcpy(File_LOC,"/proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/");
			tc_strcat(File_LOC,File_Name);
			printf("\n File_Name: [%s]\n",File_Name);fflush(stdout);
			printf("\n File_LOC: [%s]\n",File_LOC);fflush(stdout);
			fptr=fopen(File_LOC,"r");
			if(fptr!=NULL)
			{
				inputline=(char *) MEM_alloc(50000);
				while(fgets(inputline,50000,fptr)!=NULL)
				{
					for (i = 0; i < strlen(inputline); i++)
					{
						if ( inputline[i] == '\n' || inputline[i] == '\r' )
							inputline[i] = '\0';
					}
					while(1)
					{
						f = strstr(inputline,",,");
						if(f==NULL)
						{
							break;
						}

						strcpy(result2,f+1);					
						*(f+1)=' ';
						*(f+2)='\0';
						strcat(f,result2);
					}
					strcpy(result1,inputline);
					printf("\n inputline .......%s\n",result1);fflush(stdout);
					itemId=tc_strtok(result1,"^");
					printf("\n itemId .......[%s]\n",itemId);fflush(stdout);
					if(tc_strlen(itemId)>0 && tc_strcmp(itemId,"NA")!=0)
					{
						tc_strcpy(New_TML_Part_Number_NPR, itemId);
					}
					else
					{
						printf(" \n PART NOT AVAILABLE :: ERROR MESSAGE TO BE PRINT"); fflush(stdout);
						tc_strcpy(New_TML_Part_Number_NPR, thisPartNumber);
					}
				}
			}
			else
			{
				printf(" \n FILE NOT AVAILABLE :: ERROR MESSAGE TO BE PRINT"); fflush(stdout);
				tc_strcpy(New_TML_Part_Number_NPR, thisPartNumber);
			}
		}
		else
		{
			printf("\n error message here !!!Part present in TCUA, so skip to check in TCE");fflush(stdout);
			tc_strcpy(New_TML_Part_Number_NPR, thisPartNumber);
		}
	}
	else
	{
		tc_strcpy(New_TML_Part_Number_NPR, thisPartNumber);
	}

	printf("\n\n Finally Going To Create Part Ledger After Check IN TCE -->[%s]\n\n",New_TML_Part_Number_NPR);fflush(stdout);
	char* temp_Id1 = NULL;
	char* temp_Id2 = NULL;
	char* FINAL_ASSIGN_PART_NUMBER = NULL;
	temp_Id1=(char *) MEM_alloc(5);
	temp_Id2=(char *) MEM_alloc(5);
	FINAL_ASSIGN_PART_NUMBER=(char *) MEM_alloc(200);
	int Increment_PartNumber_1 = 0;
	int Increment_PartNumber_2 = 0;
	if(tc_strlen(New_TML_Part_Number_NPR)==12 && tc_strlen(thisPartNumber)==12)
	{
		temp_Id1= NewPartsubString(New_TML_Part_Number_NPR,10,2);
		temp_Id2= NewPartsubString(thisPartNumber,10,2);
		printf("\n 1temp_Id1 [%s]*******",temp_Id1);fflush(stdout);
		printf("\n 1temp_Id2 [%s]*******",temp_Id2);fflush(stdout);
		Increment_PartNumber_1 = atoi(temp_Id1);
		Increment_PartNumber_2 = atoi(temp_Id2);
	}
	if(tc_strlen(New_TML_Part_Number_NPR)==14 && tc_strlen(thisPartNumber)==14)
	{
		temp_Id1= NewPartsubString(New_TML_Part_Number_NPR,11,3);
		temp_Id2= NewPartsubString(thisPartNumber,11,3);
		printf("\n 2temp_Id1 [%s]*******",temp_Id1);fflush(stdout);
		printf("\n 2temp_Id2 [%s]*******",temp_Id2);fflush(stdout);
		Increment_PartNumber_1 = atoi(temp_Id1);
		Increment_PartNumber_2 = atoi(temp_Id2);
	}
	printf("\n Increment_PartNumber_1 [%d]*******",Increment_PartNumber_1);fflush(stdout);
	printf("\n Increment_PartNumber_2 [%d]*******",Increment_PartNumber_2);fflush(stdout);
	
	if(Increment_PartNumber_1==Increment_PartNumber_2)
	{
		tc_strcpy(FINAL_ASSIGN_PART_NUMBER,thisPartNumber);
	}
	if(Increment_PartNumber_1>Increment_PartNumber_2)
	{
		tc_strcpy(FINAL_ASSIGN_PART_NUMBER,New_TML_Part_Number_NPR);
	}
	if(Increment_PartNumber_1<Increment_PartNumber_2)
	{
		tc_strcpy(FINAL_ASSIGN_PART_NUMBER,thisPartNumber);
	}
	printf("\n FINAL_ASSIGN_PART_NUMBER [%s]*******",FINAL_ASSIGN_PART_NUMBER);fflush(stdout);

	//if(tc_strlen(thisPartNumber)>0)
	if(tc_strlen(FINAL_ASSIGN_PART_NUMBER)>0)
	{
		if(TCTYPE_find_type ("T5_PrtMtr", "T5_PrtMtr", &PrtLedgerTypeTag)!=ITK_ok) PrintErrorStack();
		if(TCTYPE_ask_name2(PrtLedgerTypeTag,&part_ledger_type)!=ITK_ok) PrintErrorStack();
		//TCTYPE_find_type ("T5_PrtMtr", "T5_PrtMtr", &PrtLedgerTypeTag);
		//TCTYPE_ask_name2(PrtLedgerTypeTag,part_ledger_type);
		
		printf("\n part_ledger_type [%s]*******",part_ledger_type);fflush(stdout);
		if(TCTYPE_construct_create_input(PrtLedgerTypeTag,&PrtLedgerCreInTag)!=ITK_ok) PrintErrorStack();
		//if(AOM_set_value_string(PrtLedgerCreInTag, "object_name", thisPartNumber)!=ITK_ok) PrintErrorStack();
		if(AOM_set_value_string(PrtLedgerCreInTag, "object_name", FINAL_ASSIGN_PART_NUMBER)!=ITK_ok) PrintErrorStack();
		//if(AOM_set_value_string(PrtLedgerCreInTag, "object_desc", thisPartNumber)!=ITK_ok) PrintErrorStack();
		if(AOM_set_value_string(PrtLedgerCreInTag, "object_desc", FINAL_ASSIGN_PART_NUMBER)!=ITK_ok) PrintErrorStack();
		if(TCTYPE_create_object(PrtLedgerCreInTag, &PartLedgerTag)!=ITK_ok) PrintErrorStack();
		//TCTYPE_construct_create_input(PrtLedgerTypeTag,&PrtLedgerCreInTag);
		//TCTYPE_create_object(PrtLedgerCreInTag, &PartLedgerTag);
		
		//if(AOM_save_without_extensions_with_extensions(PartLedgerTag) !=ITK_ok) PrintErrorStack();
		
		if(PartLedgerTag!=NULLTAG)
		{
			AOM_refresh( PartLedgerTag, TRUE);
			if(AOM_set_value_string(PartLedgerTag, "object_name", FINAL_ASSIGN_PART_NUMBER)!=ITK_ok) PrintErrorStack();
			//if(AOM_set_value_string(PartLedgerTag, "object_name", thisPartNumber)!=ITK_ok) PrintErrorStack();
			if(AOM_set_value_string(PartLedgerTag, "t5_PrtProjCode", ProjectNameS)!=ITK_ok) PrintErrorStack();
			if(AOM_set_value_string(PartLedgerTag, "t5_PrtDesignGrp", t5DesignGroupS)!=ITK_ok) PrintErrorStack();

			//if(isFor12Digit==true && isFor14Digit==false)
			if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
			{
				if(AOM_set_value_string(PartLedgerTag, "t5_PrtSubGroup", t5NwDgSbGrpS)!=ITK_ok) PrintErrorStack();
				if(tc_strcmp(t5NwDgIdS,"73")!=0)
				{
					if(AOM_set_value_string(PartLedgerTag, "t5_PrtDesignation", t5NwDgIdS)!=ITK_ok) PrintErrorStack();
				}
				if(tc_strcmp(t5NwDgIdS,"73")==0)
				{
					if(AOM_set_value_string(PartLedgerTag, "t5_PrtDesignation", "72")!=ITK_ok) PrintErrorStack();
				}
				
			}
			if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
			{
				if(AOM_set_value_string(PartLedgerTag, "t5_ModuleAddress", SubModuleAddress)!=ITK_ok) PrintErrorStack();
			}
			
			//if(AOM_set_value_string(PartLedgerTag, "t5_PrtNmbrDesc", thisPartNumber)!=ITK_ok) PrintErrorStack();
			if(AOM_set_value_string(PartLedgerTag, "t5_PrtNmbrDesc", FINAL_ASSIGN_PART_NUMBER)!=ITK_ok) PrintErrorStack();
			if(AOM_save_without_extensions(PartLedgerTag)!=ITK_ok) PrintErrorStack();
			//AOM_set_value_string(PartLedgerTag, "object_name", thisPartNumber);
			//AOM_set_value_string(PartLedgerTag, "t5_PrtProjCode", ProjectNameS);
			//AOM_set_value_string(PartLedgerTag, "t5_PrtDesignGrp", t5DesignGroupS);
			//AOM_set_value_string(PartLedgerTag, "t5_PrtSubGroup", t5NwDgSbGrpS);
			//AOM_set_value_string(PartLedgerTag, "t5_PrtDesignation", t5NwDgIdS);
			//AOM_set_value_string(PartLedgerTag, "t5_PrtNmbrDesc", thisPartNumber);
			//AOM_save(PartLedgerTag);
			
			AOM_refresh(PartLedgerTag,FALSE);
			if(AOM_ask_value_string(PartLedgerTag,"object_name",&ledgerdocnumber)!=ITK_ok) PrintErrorStack();
			//AOM_ask_value_string(PartLedgerTag,"object_name",&ledgerdocnumber);
			printf("\n Part Ledger [%s] Created Successfully*******",ledgerdocnumber);fflush(stdout);
			if(AOM_ask_value_string(PartLedgerTag,"t5_PrtNmbrDesc",&ledgerdoc)!=ITK_ok) PrintErrorStack();
			//AOM_ask_value_string(PartLedgerTag,"t5_PrtNmbrDesc",&ledgerdoc);
			printf("\n Part Ledger [%s] Created Successfully*******",ledgerdoc);fflush(stdout);
		}
		if(GRM_find_relation_type("T5_NwLHP",&creltypetag)!=ITK_ok) PrintErrorStack();
		//GRM_find_relation_type("T5_NwLHP",&creltypetag);
		if(master!=NULLTAG && PartLedgerTag!=NULLTAG)
		{
			printf("\n Part Ledger [%s] *******",ledgerdoc);fflush(stdout);
			printf("\n New Part Request [%s] *******",newpartreq);fflush(stdout);
			ITEM_ask_latest_rev(master,&latestitemrev);
			//if(ITEM_ask_latest_rev(tzattachment[0],&latestitemrev)!=ITK_ok) PrintErrorStack();
			if(PartLedgerTag!=NULLTAG)
			{
				if(GRM_create_relation(tzattachment[0],PartLedgerTag,creltypetag,NULLTAG,&rel_tag)!=ITK_ok) PrintErrorStack();
				//GRM_create_relation(latestitemrev,PartLedgerTag,creltypetag,NULLTAG,&rel_tag);
				printf("\n After GRM_create_relation *******");fflush(stdout);
				//if(AOM_save_without_extensions(rel_tag)!=ITK_ok) PrintErrorStack();
				GRM_save_relation(rel_tag);
				printf("\n After rel_tag *******");fflush(stdout);
			}

			//Control Object Query ..
			/*
			qry_values_ctrl[0]	= "NewPartReqUpdate";
			if(QRY_find2("ControlObjects", &query_ctrl) !=ITK_ok)  PrintErrorStack();
			QRY_execute(query_ctrl, 1, qry_entries_ctrl, qry_values_ctrl, &n_found_ctrl, &q_item_ctrl);
			if(n_found_ctrl>0)
			{
				if(AOM_ask_value_string(q_item_ctrl[0],"t5_Userinfo1",&ExePath)!=ITK_ok) PrintErrorStack();
				if(AOM_ask_value_string(q_item_ctrl[0],"t5_Userinfo2",&username)!=ITK_ok) PrintErrorStack();
				if(AOM_ask_value_string(q_item_ctrl[0],"t5_Userinfo3",&userpasswd)!=ITK_ok) PrintErrorStack();
				if(AOM_ask_value_string(q_item_ctrl[0],"t5_Userinfo4",&usergrp)!=ITK_ok) PrintErrorStack();
				syscommand=(char *) MEM_alloc(200);
				tc_strcpy(syscommand,ExePath);
				tc_strcat(syscommand," -u=");
				tc_strcat(syscommand,username);
				tc_strcat(syscommand," -pf=");
				tc_strcat(syscommand,userpasswd);
				tc_strcat(syscommand," -g=");
				tc_strcat(syscommand,usergrp);
				tc_strcat(syscommand," -i=");
				tc_strcat(syscommand,newpartreq);
				tc_strcat(syscommand," -n=");
				tc_strcat(syscommand,thisPartNumber);
				printf("\n  start Calling exe using system syscommand: [%s]\n",syscommand); fflush(stdout);
				system(syscommand);
				printf("\n  complete Calling exe using system syscommand: [%s]\n",syscommand); fflush(stdout);
			}
			*/
			AOM_refresh(master, TRUE);
			POM_attr_id_of_attr("t5_NwLCState", "T5_NwPCre", &updatetag);
			POM_set_attr_string(1, &master, updatetag, "LcsNwAppr");
			POM_attr_id_of_attr("t5_NwTmlPtNo", "T5_NwPCre", &updatetagprt);
			if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
			{
				POM_set_attr_string(1, &master, updatetagprt, FINAL_ASSIGN_PART_NUMBER);
			}
			if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
			{
				POM_set_attr_string(1, &master, updatetagprt, thisPartNumber);
			}
			if(tc_strcmp(PartType,"Technical Part List")==0 || tc_strcmp(PartType,"T")==0)
			{
				if(tc_strlen(FINAL_ASSIGN_PART_NUMBER)>0)
				{
					POM_set_attr_string(1, &master, updatetagprt, FINAL_ASSIGN_PART_NUMBER);
				}
				else
				{
					POM_set_attr_string(1, &master, updatetagprt, thisPartNumber);
				}				
			}
			POM_save_instances(1, &master, false);
			printf("\n Completed::POM_save_instances");fflush(stdout);
			AOM_refresh(master, FALSE);
			/*
			if(AOM_lock(npr_tagitems[0])!=ITK_ok) PrintErrorStack();
			if(AOM_set_value_string(npr_tagitems[0], "t5_NwTmlPtNo", thisPartNumber)!=ITK_ok) PrintErrorStack();
			if(AOM_set_value_string(npr_tagitems[0], "t5_NwLCState", "LcsNwAppr")!=ITK_ok) PrintErrorStack();
			if(AOM_save_without_extensions(npr_tagitems[0])!=ITK_ok) PrintErrorStack();
			if(AOM_unlock(npr_tagitems[0])!=ITK_ok) PrintErrorStack();
			*/
			//AOM_lock(npr_tagitems[0]);
			//AOM_set_value_string(npr_tagitems[0], "t5_NwTmlPtNo", thisPartNumber);
			//AOM_set_value_string(npr_tagitems[0], "t5_NwLCState", "LcsNwAppr");
			//AOM_save_without_extensions(npr_tagitems[0]);
			//AOM_unlock(npr_tagitems[0]);
		}
		
	//MEM_free(tzattachment);
	//MEM_free(thisPartNumber);
	//MEM_free(tempId);
	//MEM_free(vstr);
	//MEM_free(Partstr);
	//MEM_free(PartNumberS);
	//MEM_free(q_item1);
	//MEM_free(q_item2);
	//MEM_free(npr_tagitems);
	}
	return error_code;
}

/****************************************************************************
Function:       TML_Assign_NewPartRequest_Module_Reviewer_Fuction
Description:    This function is used in WF after while approve from manager login
				to release DML/task/part/dataset.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
int TML_Assign_NewPartRequest_Module_Reviewer_Fuction(EPM_action_message_t msg)
{
	tag_t		tzroottask			= NULLTAG;
	tag_t		*tzattachment		= NULLTAG;
	tag_t       *SignoffATT         = NULLTAG;
	
	
	tag_t		COCPrincipalReview    		= NULLTAG;
	tag_t		COCHeadReview    		= NULLTAG;
	tag_t		ModuleLeaderReview    		= NULLTAG;
	tag_t		HODReview    		= NULLTAG;
	
	tag_t		*COC_reviewGrpMemberTag    = NULLTAG;
	tag_t		*ModuleLeader_reviewGrpMemberTag    = NULLTAG;
	tag_t		*COCHead_reviewGrpMemberTag    = NULLTAG;
	tag_t		*HOD_reviewGrpMemberTag    = NULLTAG;
	
	
	tag_t		*COC_reviewSIGNOFF         = NULLTAG;
	tag_t		*ModuleLeader_reviewSIGNOFF         = NULLTAG;
	tag_t		*COCHead_reviewSIGNOFF         = NULLTAG;
	tag_t		*HOD_reviewSIGNOFF         = NULLTAG;
	
	tag_t		ModuleLeader_review_group_All         = NULLTAG;
	tag_t		COC_review_group_All         = NULLTAG;
	tag_t		COCHead_review_group_All         = NULLTAG;
	tag_t		HOD_review_group_All         = NULLTAG;
	
	tag_t        *SubTASKS          = NULLTAG;
	tag_t        roleTag            = NULLTAG;
	tag_t        hodroleTag         = NULLTAG;
	
	
	char		*objtype			= NULL;
	char 		*itemid				= NULL;
	
	char 		*DesignGroup		= NULL;
	
	char 		*roottaskName		= NULL;
	char        *WroottaskName      = NULL;
	
	char        *COCPrincipalReviewName     = NULL;
	char        *COCHeadReviewName     = NULL;
	char        *ModuleLeaderReviewName     = NULL;
	char        *HODReviewName     = NULL;
	char        *CocIdGroupName     = NULL;
	
	
	
	char        *SUBTASKNAMEstr     = NULL;
	
	
	char 		 *COC_review_group	= NULL;
	char 		 *COCHead_review_group	= NULL;
	char 		 *ModuleLeader_review_group	= NULL;
	char 		 *HOD_review_group	= NULL;
	
	const char*   Modulerole_name = "Module";
	const char*   pvburole_name = "PVBU";
	
	
	int  i =0;
	int  z = 0;
	int  r = 0;


	int  COC_reviewCount  =0;
	int  ModuleLeader_reviewCount  =0;
	int  COCHead_reviewCount  =0;
	int  HOD_reviewCount  =0;


	int  SignoffCountCOC_review = 0;
	int  SignoffCountModuleLeader_review = 0;
	int  SignoffCountCOCHead_review = 0;
	int  SignoffCountHOD_review = 0;


	
	int  CntSubTsk=0;
	int  t=0;
	
	int	izntaskattachment	= 0;
	int SignoffCountPeerreview =0;
	int SignoffCountCOCPrincipalreview =0;
	
	int error_code = ITK_ok;
	

	printf("\n *** Start : TML_Assign_NewPartRequest_Module_Reviewer_Fuction ***\n");fflush(stdout);
	if(EPM_ask_root_task(msg.task, &tzroottask)!=ITK_ok)   PrintErrorStack();
	EPM_ask_name2(tzroottask,&roottaskName);
	printf("\nRoot Task Name is %s",roottaskName);fflush(stdout);
	
	WSOM_ask_name2(tzroottask,&WroottaskName);
	printf("\nRoot Task Name BY wsom ASK Name 2  is %s",WroottaskName);fflush(stdout);
	
	z=EPM_ask_sub_tasks(tzroottask,&CntSubTsk,&SubTASKS);
	printf("\nCount of sub tasks is %d",CntSubTsk);fflush(stdout);
	for(t=0 ; t<CntSubTsk ; t++)
	{
		z=EPM_ask_name2(SubTASKS[t],&SUBTASKNAMEstr);
		printf(" \n Sub task name are %s",SUBTASKNAMEstr);fflush(stdout);
	}
	
	
	
	
	if(EPM_ask_attachments(tzroottask, EPM_target_attachment,&izntaskattachment, &tzattachment)!=ITK_ok)   PrintErrorStack();

	EPM_ask_sub_task(tzroottask,"ModuleReview",&ModuleLeaderReview);
    EPM_ask_name2(ModuleLeaderReview,&ModuleLeaderReviewName);
	printf("\n ModuleLeaderReviewName is =====>[%s]", ModuleLeaderReviewName);fflush(stdout);

	if(EPM_ask_attachments(msg.task,EPM_signoff_attachment,&SignoffCountCOCPrincipalreview,&SignoffATT)!=ITK_ok)   PrintErrorStack();
	printf("\n No of Attachments ====> Signoff count is [%d]", SignoffCountCOCPrincipalreview);fflush(stdout);
		
	if(izntaskattachment>0 && SignoffCountCOCPrincipalreview==0)
	{
		
		for(i=0;i<izntaskattachment;i++)
		{
			AOM_ask_value_string(tzattachment[i],"object_type",&objtype);
			printf("\n Object type ====>[%s]", objtype);fflush(stdout);
			
			AOM_ask_value_string(tzattachment[i],"object_name",&itemid);
			printf("\n item id ====>[%s]", itemid);fflush(stdout);

			//if(tc_strcmp(objtype,"T5_NwPCreRevision")==0)
			if(tc_strcmp(objtype,"T5_NwPCre")==0)
			{

				AOM_ask_value_string(tzattachment[i],"t5_DesignGroup",&DesignGroup);
				printf("\n Value of design group is %s", DesignGroup);fflush(stdout);
				AOM_ask_value_string(tzattachment[i],"t5_NwCocId",&CocIdGroupName);
				printf("\n Value of CocIdGroupName is %s", CocIdGroupName);fflush(stdout);

				if(strcmp(ModuleLeaderReviewName,"ModuleReview")==0)
				{
					ModuleLeader_review_group = (char *) MEM_alloc( 30 * sizeof(char) );
					if(strstr(CocIdGroupName,"Module") != NULL)
					{
						SA_find_role2 (Modulerole_name,&roleTag);
						tc_strcpy(ModuleLeader_review_group,DesignGroup);
						tc_strcat(ModuleLeader_review_group,"_New_Module");
						printf("\n Value of ModuleLeader_review_group is %s", ModuleLeader_review_group);fflush(stdout);
					}
					if(strstr(CocIdGroupName,"PVBU") != NULL)
					{
						SA_find_role2 (pvburole_name,&roleTag);
						tc_strcpy(ModuleLeader_review_group,DesignGroup);
						tc_strcat(ModuleLeader_review_group,"_PVBU");
						printf("\n Value of ModuleLeader_review_group is %s", ModuleLeader_review_group);fflush(stdout);
					}

					SA_find_group(ModuleLeader_review_group,&ModuleLeader_review_group_All);
					SA_find_groupmember_by_role(roleTag,ModuleLeader_review_group_All,&ModuleLeader_reviewCount,&ModuleLeader_reviewGrpMemberTag);
					printf("\n Value of ModuleLeader_reviewCount is %d", ModuleLeader_reviewCount);fflush(stdout);
					for(r=0 ; r<ModuleLeader_reviewCount ; r++)
					{
						EPM_create_adhoc_signoff(msg.task,ModuleLeader_reviewGrpMemberTag[r],&SignoffCountModuleLeader_review,&ModuleLeader_reviewSIGNOFF);
						printf("\n Value of SignoffCountModuleLeader_review is %d",SignoffCountModuleLeader_review);fflush(stdout);
					}
					
				}
				EPM_set_adhoc_signoff_selection_done(msg.task,TRUE);
			}
		}
		
		MEM_free(COC_reviewGrpMemberTag);
		MEM_free(COC_reviewSIGNOFF);
		MEM_free(ModuleLeader_reviewGrpMemberTag);
		MEM_free(ModuleLeader_reviewSIGNOFF);
		MEM_free(COCHead_reviewGrpMemberTag);
		MEM_free(COCHead_reviewSIGNOFF);
		MEM_free(COCHead_reviewGrpMemberTag);
		MEM_free(HOD_reviewGrpMemberTag);
		MEM_free(HOD_reviewSIGNOFF);
		MEM_free(COC_review_group);
		MEM_free(ModuleLeader_review_group);
		MEM_free(COCHead_review_group);
		MEM_free(HOD_review_group);
	}		
	
	
	return error_code;
}


/****************************************************************************
Function:       TML_Assign_NewPartRequest_COCPrinciple_Reviewer_Fuction
Description:    This function is used in WF after while approve from manager login
				to release DML/task/part/dataset.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
int TML_Assign_NewPartRequest_COCPrinciple_Reviewer_Fuction(EPM_action_message_t msg)
{
	tag_t		tzroottask			= NULLTAG;
	tag_t		*tzattachment		= NULLTAG;
	tag_t       *SignoffATT         = NULLTAG;
	
	
	tag_t		COCPrincipalReview    		= NULLTAG;
	tag_t		COCHeadReview    		= NULLTAG;
	tag_t		ModuleLeaderReview    		= NULLTAG;
	tag_t		HODReview    		= NULLTAG;
	
	tag_t		*COC_reviewGrpMemberTag    = NULLTAG;
	tag_t		*ModuleLeader_reviewGrpMemberTag    = NULLTAG;
	tag_t		*COCHead_reviewGrpMemberTag    = NULLTAG;
	tag_t		*HOD_reviewGrpMemberTag    = NULLTAG;
	
	
	tag_t		*COC_reviewSIGNOFF         = NULLTAG;
	tag_t		*ModuleLeader_reviewSIGNOFF         = NULLTAG;
	tag_t		*COCHead_reviewSIGNOFF         = NULLTAG;
	tag_t		*HOD_reviewSIGNOFF         = NULLTAG;
	
	tag_t		ModuleLeader_review_group_All         = NULLTAG;
	tag_t		COC_review_group_All         = NULLTAG;
	tag_t		COCHead_review_group_All         = NULLTAG;
	tag_t		HOD_review_group_All         = NULLTAG;
	
	tag_t        *SubTASKS          = NULLTAG;
	tag_t        roleTag            = NULLTAG;
	tag_t        hodroleTag         = NULLTAG;
	
	
	char		*objtype			= NULL;
	char 		*itemid				= NULL;
	
	char 		*DesignGroup		= NULL;
	
	char 		*roottaskName		= NULL;
	char        *WroottaskName      = NULL;
	
	char        *COCPrincipalReviewName     = NULL;
	char        *COCHeadReviewName     = NULL;
	char        *ModuleLeaderReviewName     = NULL;
	char        *HODReviewName     = NULL;
	
	
	
	char        *SUBTASKNAMEstr     = NULL;
	
	
	char 		 *COC_review_group	= NULL;
	char 		 *COCHead_review_group	= NULL;
	char 		 *ModuleLeader_review_group	= NULL;
	char 		 *HOD_review_group	= NULL;
	const char*   cocprincipal_role_name = "COCPrinciple";
	
	
	int  i =0;
	int  z = 0;
	int  r = 0;


	int  COC_reviewCount  =0;
	int  ModuleLeader_reviewCount  =0;
	int  COCHead_reviewCount  =0;
	int  HOD_reviewCount  =0;


	int  SignoffCountCOC_review = 0;
	int  SignoffCountModuleLeader_review = 0;
	int  SignoffCountCOCHead_review = 0;
	int  SignoffCountHOD_review = 0;


	
	int  CntSubTsk=0;
	int  t=0;
	
	int	izntaskattachment	= 0;
	int SignoffCountPeerreview =0;
	int SignoffCountCOCPrincipalreview =0;
	
	int error_code = ITK_ok;
	

	printf("\n *** Start : TML_Assign_NewPartRequest_COCPrinciple_Reviewer_Fuction ***\n");fflush(stdout);
	if(EPM_ask_root_task(msg.task, &tzroottask)!=ITK_ok)   PrintErrorStack();
	EPM_ask_name2(tzroottask,&roottaskName);
	printf("\nRoot Task Name is %s",roottaskName);fflush(stdout);
	
	WSOM_ask_name2(tzroottask,&WroottaskName);
	printf("\nRoot Task Name BY wsom ASK Name 2  is %s",WroottaskName);fflush(stdout);
	
	z=EPM_ask_sub_tasks(tzroottask,&CntSubTsk,&SubTASKS);
	printf("\nCount of sub tasks is %d",CntSubTsk);fflush(stdout);
	for(t=0 ; t<CntSubTsk ; t++)
	{
		z=EPM_ask_name2(SubTASKS[t],&SUBTASKNAMEstr);
		printf(" \n Sub task name are %s",SUBTASKNAMEstr);fflush(stdout);
	}
	
	
	
	
	if(EPM_ask_attachments(tzroottask, EPM_target_attachment,&izntaskattachment, &tzattachment)!=ITK_ok)   PrintErrorStack();

	EPM_ask_sub_task(tzroottask,"COC Principal Engineer Review",&COCPrincipalReview);
    EPM_ask_name2(COCPrincipalReview,&COCPrincipalReviewName);
	printf("\n COCPrincipalReviewName is =====>[%s]", COCPrincipalReviewName);fflush(stdout);

	

	
	if(EPM_ask_attachments(msg.task,EPM_signoff_attachment,&SignoffCountCOCPrincipalreview,&SignoffATT)!=ITK_ok)   PrintErrorStack();
	printf("\n No of Attachments ====> Signoff count is [%d]", SignoffCountCOCPrincipalreview);fflush(stdout);
		
	if(izntaskattachment>0 && SignoffCountCOCPrincipalreview==0)
	{
		
		for(i=0;i<izntaskattachment;i++)
		{
			AOM_ask_value_string(tzattachment[i],"object_type",&objtype);
			printf("\n Object type ====>[%s]", objtype);fflush(stdout);
			
			AOM_ask_value_string(tzattachment[i],"object_name",&itemid);
			printf("\n item id ====>[%s]", itemid);fflush(stdout);

			//if(tc_strcmp(objtype,"T5_NwPCreRevision")==0)
			if(tc_strcmp(objtype,"T5_NwPCre")==0)
			{

				AOM_ask_value_string(tzattachment[i],"t5_DesignGroup",&DesignGroup);
				printf("\n Value of design group is %s", DesignGroup);fflush(stdout);
				SA_find_role2 (cocprincipal_role_name,&roleTag);

				if(strcmp(COCPrincipalReviewName,"COC Principal Engineer Review")==0)
				{
					COC_review_group = (char *) MEM_alloc( 30 * sizeof(char) );
					tc_strcpy(COC_review_group,DesignGroup);
					tc_strcat(COC_review_group,"_New_COCPrinciple");
					printf("\n Value of COC_review_group is %s", COC_review_group);fflush(stdout);

					SA_find_group(COC_review_group,&COC_review_group_All);
					SA_find_groupmember_by_role(roleTag,COC_review_group_All,&COC_reviewCount,&COC_reviewGrpMemberTag);
					printf("\n Value of COC_reviewCount is %d", COC_reviewCount);fflush(stdout);
					for(r=0 ; r<COC_reviewCount ; r++)
					{
						EPM_create_adhoc_signoff(msg.task,COC_reviewGrpMemberTag[r],&SignoffCountCOC_review,&COC_reviewSIGNOFF);
						printf("\n Value of SignoffCountCOC_review is %d",SignoffCountCOC_review);fflush(stdout);
					}
				}
				EPM_set_adhoc_signoff_selection_done(msg.task,TRUE);
			}
		}
		
		MEM_free(COC_reviewGrpMemberTag);
		MEM_free(COC_reviewSIGNOFF);
		MEM_free(ModuleLeader_reviewGrpMemberTag);
		MEM_free(ModuleLeader_reviewSIGNOFF);
		MEM_free(COCHead_reviewGrpMemberTag);
		MEM_free(COCHead_reviewSIGNOFF);
		MEM_free(COCHead_reviewGrpMemberTag);
		MEM_free(HOD_reviewGrpMemberTag);
		MEM_free(HOD_reviewSIGNOFF);
		MEM_free(COC_review_group);
		MEM_free(ModuleLeader_review_group);
		MEM_free(COCHead_review_group);
		MEM_free(HOD_review_group);
	}		
	
	
	return error_code;
}


/****************************************************************************
Function:       TML_Assign_NewPartRequest_HeadEngCOC_Reviewer_Fuction
Description:    This function is used in WF after while approve from manager login
				to release DML/task/part/dataset.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
int TML_Assign_NewPartRequest_HeadEngCOC_Reviewer_Fuction(EPM_action_message_t msg)
{
	tag_t		tzroottask			= NULLTAG;
	tag_t		*tzattachment		= NULLTAG;
	tag_t       *SignoffATT         = NULLTAG;
	
	
	tag_t		COCPrincipalReview    		= NULLTAG;
	tag_t		COCHeadReview    		= NULLTAG;
	tag_t		ModuleLeaderReview    		= NULLTAG;
	tag_t		HODReview    		= NULLTAG;
	
	tag_t		*COC_reviewGrpMemberTag    = NULLTAG;
	tag_t		*ModuleLeader_reviewGrpMemberTag    = NULLTAG;
	tag_t		*COCHead_reviewGrpMemberTag    = NULLTAG;
	tag_t		*HOD_reviewGrpMemberTag    = NULLTAG;
	
	
	tag_t		*COC_reviewSIGNOFF         = NULLTAG;
	tag_t		*ModuleLeader_reviewSIGNOFF         = NULLTAG;
	tag_t		*COCHead_reviewSIGNOFF         = NULLTAG;
	tag_t		*HOD_reviewSIGNOFF         = NULLTAG;
	
	tag_t		ModuleLeader_review_group_All         = NULLTAG;
	tag_t		COC_review_group_All         = NULLTAG;
	tag_t		COCHead_review_group_All         = NULLTAG;
	tag_t		HOD_review_group_All         = NULLTAG;
	
	tag_t        *SubTASKS          = NULLTAG;
	tag_t        roleTag            = NULLTAG;
	tag_t        hodroleTag         = NULLTAG;
	
	
	char		*objtype			= NULL;
	char 		*itemid				= NULL;
	
	char 		*DesignGroup		= NULL;
	
	char 		*roottaskName		= NULL;
	char        *WroottaskName      = NULL;
	
	char        *COCPrincipalReviewName     = NULL;
	char        *COCHeadReviewName     = NULL;
	char        *ModuleLeaderReviewName     = NULL;
	char        *HODReviewName     = NULL;
	
	
	
	char        *SUBTASKNAMEstr     = NULL;
	
	
	char 		 *COC_review_group	= NULL;
	char 		 *COCHead_review_group	= NULL;
	char 		 *ModuleLeader_review_group	= NULL;
	char 		 *HOD_review_group	= NULL;
	const char*   head_role_name = "COC_Head";
	
	
	int  i =0;
	int  z = 0;
	int  r = 0;


	int  COC_reviewCount  =0;
	int  ModuleLeader_reviewCount  =0;
	int  COCHead_reviewCount  =0;
	int  HOD_reviewCount  =0;


	int  SignoffCountCOC_review = 0;
	int  SignoffCountModuleLeader_review = 0;
	int  SignoffCountCOCHead_review = 0;
	int  SignoffCountHOD_review = 0;


	
	int  CntSubTsk=0;
	int  t=0;
	
	int	izntaskattachment	= 0;
	int SignoffCountPeerreview =0;
	int SignoffCountCOCPrincipalreview =0;
	
	int error_code = ITK_ok;
	

	printf("\n *** Start : TML_Assign_NewPartRequest_HeadEngCOC_Reviewer_Fuction ***\n");fflush(stdout);
	if(EPM_ask_root_task(msg.task, &tzroottask)!=ITK_ok)   PrintErrorStack();
	EPM_ask_name2(tzroottask,&roottaskName);
	printf("\nRoot Task Name is %s",roottaskName);fflush(stdout);
	
	WSOM_ask_name2(tzroottask,&WroottaskName);
	printf("\nRoot Task Name BY wsom ASK Name 2  is %s",WroottaskName);fflush(stdout);
	
	z=EPM_ask_sub_tasks(tzroottask,&CntSubTsk,&SubTASKS);
	printf("\nCount of sub tasks is %d",CntSubTsk);fflush(stdout);
	for(t=0 ; t<CntSubTsk ; t++)
	{
		z=EPM_ask_name2(SubTASKS[t],&SUBTASKNAMEstr);
		printf(" \n Sub task name are %s",SUBTASKNAMEstr);fflush(stdout);
	}
	
	
	
	
	if(EPM_ask_attachments(tzroottask, EPM_target_attachment,&izntaskattachment, &tzattachment)!=ITK_ok)   PrintErrorStack();

	EPM_ask_sub_task(tzroottask,"COC Head Plantform Engineer Review",&COCHeadReview);
    EPM_ask_name2(COCHeadReview,&COCHeadReviewName);
	printf("\n COCHeadReviewName is =====>[%s]", COCHeadReviewName);fflush(stdout);

	

	
	if(EPM_ask_attachments(msg.task,EPM_signoff_attachment,&SignoffCountCOCPrincipalreview,&SignoffATT)!=ITK_ok)   PrintErrorStack();
	printf("\n No of Attachments ====> Signoff count is [%d]", SignoffCountCOCPrincipalreview);fflush(stdout);
		
	if(izntaskattachment>0 && SignoffCountCOCPrincipalreview==0)
	{
		
		for(i=0;i<izntaskattachment;i++)
		{
			AOM_ask_value_string(tzattachment[i],"object_type",&objtype);
			printf("\n Object type ====>[%s]", objtype);fflush(stdout);
			
			AOM_ask_value_string(tzattachment[i],"object_name",&itemid);
			printf("\n item id ====>[%s]", itemid);fflush(stdout);

			//if(tc_strcmp(objtype,"T5_NwPCreRevision")==0)
			if(tc_strcmp(objtype,"T5_NwPCre")==0)
			{

				AOM_ask_value_string(tzattachment[i],"t5_DesignGroup",&DesignGroup);
				printf("\n Value of design group is %s", DesignGroup);fflush(stdout);
				SA_find_role2 (head_role_name,&roleTag);
				if(strcmp(COCHeadReviewName,"COC Head Plantform Engineer Review")==0)
				{
					COCHead_review_group = (char *) MEM_alloc( 30 * sizeof(char) );
					tc_strcpy(COCHead_review_group,DesignGroup);
					tc_strcat(COCHead_review_group,"_New_COCHead");
					printf("\n Value of COCHead_review_group is %s", COCHead_review_group);fflush(stdout);

					SA_find_group(COCHead_review_group,&COCHead_review_group_All);
					SA_find_groupmember_by_role(roleTag,COCHead_review_group_All,&COCHead_reviewCount,&COCHead_reviewGrpMemberTag);
					printf("\n Value of COCHead_reviewCount is %d", COCHead_reviewCount);fflush(stdout);
					for(r=0 ; r<COCHead_reviewCount ; r++)
					{
						EPM_create_adhoc_signoff(msg.task,COCHead_reviewGrpMemberTag[r],&SignoffCountCOCHead_review,&COCHead_reviewSIGNOFF);
						printf("\n Value of SignoffCountCOCHead_review is %d",SignoffCountCOCHead_review);fflush(stdout);
					}
				}
				EPM_set_adhoc_signoff_selection_done(msg.task,TRUE);
				
			}
		}
		
		MEM_free(COC_reviewGrpMemberTag);
		MEM_free(COC_reviewSIGNOFF);
		MEM_free(ModuleLeader_reviewGrpMemberTag);
		MEM_free(ModuleLeader_reviewSIGNOFF);
		MEM_free(COCHead_reviewGrpMemberTag);
		MEM_free(COCHead_reviewSIGNOFF);
		MEM_free(COCHead_reviewGrpMemberTag);
		MEM_free(HOD_reviewGrpMemberTag);
		MEM_free(HOD_reviewSIGNOFF);
		MEM_free(COC_review_group);
		MEM_free(ModuleLeader_review_group);
		MEM_free(COCHead_review_group);
		MEM_free(HOD_review_group);
	}		
	
	
	return error_code;
}


/****************************************************************************
Function:       TML_Assign_NewPartRequest_HOD_Reviewer_Fuction
Description:    This function is used in WF after while approve from manager login
				to release DML/task/part/dataset.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
int TML_Assign_NewPartRequest_HOD_Reviewer_Fuction(EPM_action_message_t msg)
{
	tag_t		tzroottask			= NULLTAG;
	tag_t		*tzattachment		= NULLTAG;
	tag_t       *SignoffATT         = NULLTAG;
	
	
	tag_t		COCPrincipalReview    		= NULLTAG;
	tag_t		COCHeadReview    		= NULLTAG;
	tag_t		ModuleLeaderReview    		= NULLTAG;
	tag_t		HODReview    		= NULLTAG;
	
	tag_t		*COC_reviewGrpMemberTag    = NULLTAG;
	tag_t		*ModuleLeader_reviewGrpMemberTag    = NULLTAG;
	tag_t		*COCHead_reviewGrpMemberTag    = NULLTAG;
	tag_t		*HOD_reviewGrpMemberTag    = NULLTAG;
	
	
	tag_t		*COC_reviewSIGNOFF         = NULLTAG;
	tag_t		*ModuleLeader_reviewSIGNOFF         = NULLTAG;
	tag_t		*COCHead_reviewSIGNOFF         = NULLTAG;
	tag_t		*HOD_reviewSIGNOFF         = NULLTAG;
	
	tag_t		ModuleLeader_review_group_All         = NULLTAG;
	tag_t		COC_review_group_All         = NULLTAG;
	tag_t		COCHead_review_group_All         = NULLTAG;
	tag_t		HOD_review_group_All         = NULLTAG;
	
	tag_t        *SubTASKS          = NULLTAG;
	tag_t        roleTag            = NULLTAG;
	tag_t        hodroleTag         = NULLTAG;
	
	
	char		*objtype			= NULL;
	char 		*itemid				= NULL;
	
	char 		*DesignGroup		= NULL;
	
	char 		*roottaskName		= NULL;
	char        *WroottaskName      = NULL;
	
	char        *COCPrincipalReviewName     = NULL;
	char        *COCHeadReviewName     = NULL;
	char        *ModuleLeaderReviewName     = NULL;
	char        *HODReviewName     = NULL;
	const char*   head_role_name = "COC_Head";
	
	
	
	char        *SUBTASKNAMEstr     = NULL;
	
	
	char 		 *COC_review_group	= NULL;
	char 		 *COCHead_review_group	= NULL;
	char 		 *ModuleLeader_review_group	= NULL;
	char 		 *HOD_review_group	= NULL;
	
	
	int  i =0;
	int  z = 0;
	int  r = 0;


	int  COC_reviewCount  =0;
	int  ModuleLeader_reviewCount  =0;
	int  COCHead_reviewCount  =0;
	int  HOD_reviewCount  =0;


	int  SignoffCountCOC_review = 0;
	int  SignoffCountModuleLeader_review = 0;
	int  SignoffCountCOCHead_review = 0;
	int  SignoffCountHOD_review = 0;


	
	int  CntSubTsk=0;
	int  t=0;
	
	int	izntaskattachment	= 0;
	int SignoffCountPeerreview =0;
	int SignoffCountCOCPrincipalreview =0;
	
	int error_code = ITK_ok;
	

	printf("\n *** Start : TML_Assign_NewPartRequest_HOD_Reviewer_Fuction ***\n");fflush(stdout);
	if(EPM_ask_root_task(msg.task, &tzroottask)!=ITK_ok)   PrintErrorStack();
	EPM_ask_name2(tzroottask,&roottaskName);
	printf("\nRoot Task Name is %s",roottaskName);fflush(stdout);
	
	WSOM_ask_name2(tzroottask,&WroottaskName);
	printf("\nRoot Task Name BY wsom ASK Name 2  is %s",WroottaskName);fflush(stdout);
	
	z=EPM_ask_sub_tasks(tzroottask,&CntSubTsk,&SubTASKS);
	printf("\nCount of sub tasks is %d",CntSubTsk);fflush(stdout);
	for(t=0 ; t<CntSubTsk ; t++)
	{
		z=EPM_ask_name2(SubTASKS[t],&SUBTASKNAMEstr);
		printf(" \n Sub task name are %s",SUBTASKNAMEstr);fflush(stdout);
	}
	
	
	
	
	if(EPM_ask_attachments(tzroottask, EPM_target_attachment,&izntaskattachment, &tzattachment)!=ITK_ok)   PrintErrorStack();

	EPM_ask_sub_task(tzroottask,"Head of the Engineering Review",&HODReview);
    EPM_ask_name2(HODReview,&HODReviewName);
	printf("\n HODReviewName is =====>[%s]", HODReviewName);fflush(stdout);

	

	
	if(EPM_ask_attachments(msg.task,EPM_signoff_attachment,&SignoffCountCOCPrincipalreview,&SignoffATT)!=ITK_ok)   PrintErrorStack();
	printf("\n No of Attachments ====> Signoff count is [%d]", SignoffCountCOCPrincipalreview);fflush(stdout);
		
	if(izntaskattachment>0 && SignoffCountCOCPrincipalreview==0)
	{
		
		for(i=0;i<izntaskattachment;i++)
		{
			AOM_ask_value_string(tzattachment[i],"object_type",&objtype);
			printf("\n Object type ====>[%s]", objtype);fflush(stdout);
			
			AOM_ask_value_string(tzattachment[i],"object_name",&itemid);
			printf("\n item id ====>[%s]", itemid);fflush(stdout);

			//if(tc_strcmp(objtype,"T5_NwPCreRevision")==0)
			if(tc_strcmp(objtype,"T5_NwPCre")==0)
			{

				AOM_ask_value_string(tzattachment[i],"t5_DesignGroup",&DesignGroup);
				printf("\n Value of design group is %s", DesignGroup);fflush(stdout);
				SA_find_role2 (head_role_name,&roleTag);

				if(strcmp(HODReviewName,"Head of the Engineering Review")==0)
				{
					HOD_review_group = (char *) MEM_alloc( 30 * sizeof(char) );
					tc_strcpy(HOD_review_group,DesignGroup);
					tc_strcat(HOD_review_group,"_New_COCHead");
					printf("\n Value of HOD_review_group is %s", HOD_review_group);fflush(stdout);

					SA_find_group(HOD_review_group,&HOD_review_group_All);
					SA_find_groupmember_by_role(roleTag,HOD_review_group_All,&HOD_reviewCount,&HOD_reviewGrpMemberTag);
					printf("\n Value of HOD_reviewCount is %d", HOD_reviewCount);fflush(stdout);
					for(r=0 ; r<HOD_reviewCount ; r++)
					{
						EPM_create_adhoc_signoff(msg.task,HOD_reviewGrpMemberTag[r],&SignoffCountHOD_review,&HOD_reviewSIGNOFF);
						printf("\n Value of SignoffCountHOD_review is %d",SignoffCountHOD_review);fflush(stdout);
					}
				}
				EPM_set_adhoc_signoff_selection_done(msg.task,TRUE);
			}
		}
		
		MEM_free(COC_reviewGrpMemberTag);
		MEM_free(COC_reviewSIGNOFF);
		MEM_free(ModuleLeader_reviewGrpMemberTag);
		MEM_free(ModuleLeader_reviewSIGNOFF);
		MEM_free(COCHead_reviewGrpMemberTag);
		MEM_free(COCHead_reviewSIGNOFF);
		MEM_free(COCHead_reviewGrpMemberTag);
		MEM_free(HOD_reviewGrpMemberTag);
		MEM_free(HOD_reviewSIGNOFF);
		MEM_free(COC_review_group);
		MEM_free(ModuleLeader_review_group);
		MEM_free(COCHead_review_group);
		MEM_free(HOD_review_group);
	}		
	
	
	return error_code;
}




/****************************************************************************
Function:       TML_Assign_NewPartRequest_Reviewer_Fuction
Description:    This function is used in WF after while approve from manager login
				to release DML/task/part/dataset.
Input:          None
Output:         None
Return value:   None
****************************************************************************/

int TML_Assign_NewPartRequest_Reviewer_Fuction(EPM_action_message_t msg)
{
	tag_t		tzroottask			= NULLTAG;
	tag_t		*tzattachment		= NULLTAG;
	tag_t       *SignoffATT         = NULLTAG;
	
	
	tag_t		COCPrincipalReview    		= NULLTAG;
	tag_t		COCHeadReview    		= NULLTAG;
	tag_t		ModuleLeaderReview    		= NULLTAG;
	tag_t		HODReview    		= NULLTAG;
	
	tag_t		*COC_reviewGrpMemberTag    = NULLTAG;
	tag_t		*ModuleLeader_reviewGrpMemberTag    = NULLTAG;
	tag_t		*COCHead_reviewGrpMemberTag    = NULLTAG;
	tag_t		*HOD_reviewGrpMemberTag    = NULLTAG;
	
	
	tag_t		*COC_reviewSIGNOFF         = NULLTAG;
	tag_t		*ModuleLeader_reviewSIGNOFF         = NULLTAG;
	tag_t		*COCHead_reviewSIGNOFF         = NULLTAG;
	tag_t		*HOD_reviewSIGNOFF         = NULLTAG;
	
	tag_t		ModuleLeader_review_group_All         = NULLTAG;
	tag_t		COC_review_group_All         = NULLTAG;
	tag_t		COCHead_review_group_All         = NULLTAG;
	tag_t		HOD_review_group_All         = NULLTAG;
	
	tag_t        *SubTASKS          = NULLTAG;
	tag_t        roleTag            = NULLTAG;
	tag_t        hodroleTag         = NULLTAG;
	
	
	char		*objtype			= NULL;
	char 		*itemid				= NULL;
	
	char 		*DesignGroup		= NULL;
	
	char 		*roottaskName		= NULL;
	char        *WroottaskName      = NULL;
	
	char        *COCPrincipalReviewName     = NULL;
	char        *COCHeadReviewName     = NULL;
	char        *ModuleLeaderReviewName     = NULL;
	char        *HODReviewName     = NULL;
	
	
	
	char        *SUBTASKNAMEstr     = NULL;
	
	
	char 		 *COC_review_group	= NULL;
	char 		 *COCHead_review_group	= NULL;
	char 		 *ModuleLeader_review_group	= NULL;
	char 		 *HOD_review_group	= NULL;
	
	
	int  i =0;
	int  z = 0;
	int  r = 0;


	int  COC_reviewCount  =0;
	int  ModuleLeader_reviewCount  =0;
	int  COCHead_reviewCount  =0;
	int  HOD_reviewCount  =0;


	int  SignoffCountCOC_review = 0;
	int  SignoffCountModuleLeader_review = 0;
	int  SignoffCountCOCHead_review = 0;
	int  SignoffCountHOD_review = 0;


	
	int  CntSubTsk=0;
	int  t=0;
	
	int	izntaskattachment	= 0;
	int SignoffCountPeerreview =0;
	int SignoffCountCOCPrincipalreview =0;
	
	int error_code = ITK_ok;
	

	printf("\n *** Start : TML_Assign_NewPartRequest_Reviewer_Fuction ***\n");fflush(stdout);
	if(EPM_ask_root_task(msg.task, &tzroottask)!=ITK_ok)   PrintErrorStack();
	EPM_ask_name2(tzroottask,&roottaskName);
	printf("\nRoot Task Name is %s",roottaskName);fflush(stdout);
	
	WSOM_ask_name2(tzroottask,&WroottaskName);
	printf("\nRoot Task Name BY wsom ASK Name 2  is %s",WroottaskName);fflush(stdout);
	
	z=EPM_ask_sub_tasks(tzroottask,&CntSubTsk,&SubTASKS);
	printf("\nCount of sub tasks is %d",CntSubTsk);fflush(stdout);
	for(t=0 ; t<CntSubTsk ; t++)
	{
		z=EPM_ask_name2(SubTASKS[t],&SUBTASKNAMEstr);
		printf(" \n Sub task name are %s",SUBTASKNAMEstr);fflush(stdout);
	}
	
	
	
	
	if(EPM_ask_attachments(tzroottask, EPM_target_attachment,&izntaskattachment, &tzattachment)!=ITK_ok)   PrintErrorStack();

	EPM_ask_sub_task(tzroottask,"ModuleReview",&ModuleLeaderReview);
    EPM_ask_name2(ModuleLeaderReview,&ModuleLeaderReviewName);
	printf("\n ModuleLeaderReviewName is =====>[%s]", ModuleLeaderReviewName);fflush(stdout);

	EPM_ask_sub_task(tzroottask,"COC Principal Engineer Review",&COCPrincipalReview);
    EPM_ask_name2(COCPrincipalReview,&COCPrincipalReviewName);
	printf("\n COCPrincipalReviewName is =====>[%s]", COCPrincipalReviewName);fflush(stdout);

	EPM_ask_sub_task(tzroottask,"COC Head Plantform Engineer Review",&COCHeadReview);
    EPM_ask_name2(COCHeadReview,&COCHeadReviewName);
	printf("\n COCHeadReviewName is =====>[%s]", COCHeadReviewName);fflush(stdout);

	EPM_ask_sub_task(tzroottask,"Head of the Engineering Review",&HODReview);
    EPM_ask_name2(HODReview,&HODReviewName);
	printf("\n HODReviewName is =====>[%s]", HODReviewName);fflush(stdout);

	
	if(EPM_ask_attachments(msg.task,EPM_signoff_attachment,&SignoffCountCOCPrincipalreview,&SignoffATT)!=ITK_ok)   PrintErrorStack();
	printf("\n No of Attachments ====> Signoff count is [%d]", SignoffCountCOCPrincipalreview);fflush(stdout);
		
	if(izntaskattachment>0 && SignoffCountCOCPrincipalreview==0)
	{
		
		for(i=0;i<izntaskattachment;i++)
		{
			AOM_ask_value_string(tzattachment[i],"object_type",&objtype);
			printf("\n Object type ====>[%s]", objtype);fflush(stdout);
			
			AOM_ask_value_string(tzattachment[i],"object_name",&itemid);
			printf("\n item id ====>[%s]", itemid);fflush(stdout);

			//if(tc_strcmp(objtype,"T5_NwPCreRevision")==0)
			if(tc_strcmp(objtype,"T5_NwPCre")==0)
			{

				AOM_ask_value_string(tzattachment[i],"t5_DesignGroup",&DesignGroup);
				printf("\n Value of design group is %s", DesignGroup);fflush(stdout);
				SA_find_role2 ("Manager",&roleTag);
				SA_find_role2 ("HOD",&hodroleTag);

				if(strcmp(ModuleLeaderReviewName,"ModuleReview")==0)
				{
					ModuleLeader_review_group = (char *) MEM_alloc( 30 * sizeof(char) );
					tc_strcpy(ModuleLeader_review_group,DesignGroup);
					tc_strcat(ModuleLeader_review_group,"_New_Module");
					printf("\n Value of ModuleLeader_review_group is %s", ModuleLeader_review_group);fflush(stdout);

					SA_find_group(ModuleLeader_review_group,&ModuleLeader_review_group_All);
					SA_find_groupmember_by_role(roleTag,ModuleLeader_review_group_All,&ModuleLeader_reviewCount,&ModuleLeader_reviewGrpMemberTag);
					printf("\n Value of ModuleLeader_reviewCount is %d", ModuleLeader_reviewCount);fflush(stdout);
					for(r=0 ; r<ModuleLeader_reviewCount ; r++)
					{
						EPM_create_adhoc_signoff(msg.task,ModuleLeader_reviewGrpMemberTag[r],&SignoffCountModuleLeader_review,&ModuleLeader_reviewSIGNOFF);
						printf("\n Value of SignoffCountModuleLeader_review is %d",SignoffCountModuleLeader_review);fflush(stdout);
					}
					EPM_set_adhoc_signoff_selection_done(msg.task,TRUE);
				}

				if(strcmp(COCPrincipalReviewName,"COC Principal Engineer Review")==0)
				{
					COC_review_group = (char *) MEM_alloc( 30 * sizeof(char) );
					tc_strcpy(COC_review_group,DesignGroup);
					tc_strcat(COC_review_group,"_COCPrinciple");
					printf("\n Value of COC_review_group is %s", COC_review_group);fflush(stdout);

					SA_find_group(COC_review_group,&COC_review_group_All);
					SA_find_groupmember_by_role(roleTag,COC_review_group_All,&COC_reviewCount,&COC_reviewGrpMemberTag);
					printf("\n Value of COC_reviewCount is %d", COC_reviewCount);fflush(stdout);
					for(r=0 ; r<COC_reviewCount ; r++)
					{
						EPM_create_adhoc_signoff(msg.task,COC_reviewGrpMemberTag[r],&SignoffCountCOC_review,&COC_reviewSIGNOFF);
						printf("\n Value of SignoffCountCOC_review is %d",SignoffCountCOC_review);fflush(stdout);
					}
					EPM_set_adhoc_signoff_selection_done(msg.task,TRUE);
				}

				if(strcmp(COCHeadReviewName,"COC Head Plantform Engineer Review")==0)
				{
					COCHead_review_group = (char *) MEM_alloc( 30 * sizeof(char) );
					tc_strcpy(COCHead_review_group,DesignGroup);
					tc_strcat(COCHead_review_group,"_COCHead");
					printf("\n Value of COCHead_review_group is %s", COCHead_review_group);fflush(stdout);

					SA_find_group(COCHead_review_group,&COCHead_review_group_All);
					SA_find_groupmember_by_role(roleTag,COCHead_review_group_All,&COCHead_reviewCount,&COCHead_reviewGrpMemberTag);
					printf("\n Value of COCHead_reviewCount is %d", COCHead_reviewCount);fflush(stdout);
					for(r=0 ; r<COCHead_reviewCount ; r++)
					{
						EPM_create_adhoc_signoff(msg.task,COCHead_reviewGrpMemberTag[r],&SignoffCountCOCHead_review,&COCHead_reviewSIGNOFF);
						printf("\n Value of SignoffCountCOCHead_review is %d",SignoffCountCOCHead_review);fflush(stdout);
					}
					EPM_set_adhoc_signoff_selection_done(msg.task,TRUE);
				}

				if(strcmp(HODReviewName,"Head of the Engineering Review")==0)
				{
					HOD_review_group = (char *) MEM_alloc( 30 * sizeof(char) );
					tc_strcpy(HOD_review_group,DesignGroup);
					tc_strcat(HOD_review_group,"_HOD");
					printf("\n Value of HOD_review_group is %s", HOD_review_group);fflush(stdout);

					SA_find_group(HOD_review_group,&HOD_review_group_All);
					SA_find_groupmember_by_role(hodroleTag,HOD_review_group_All,&HOD_reviewCount,&HOD_reviewGrpMemberTag);
					printf("\n Value of HOD_reviewCount is %d", HOD_reviewCount);fflush(stdout);
					for(r=0 ; r<HOD_reviewCount ; r++)
					{
						EPM_create_adhoc_signoff(msg.task,HOD_reviewGrpMemberTag[r],&SignoffCountHOD_review,&HOD_reviewSIGNOFF);
						printf("\n Value of SignoffCountHOD_review is %d",SignoffCountHOD_review);fflush(stdout);
					}
					EPM_set_adhoc_signoff_selection_done(msg.task,TRUE);
				}	
			}
		}
		
		MEM_free(COC_reviewGrpMemberTag);
		MEM_free(COC_reviewSIGNOFF);
		MEM_free(ModuleLeader_reviewGrpMemberTag);
		MEM_free(ModuleLeader_reviewSIGNOFF);
		MEM_free(COCHead_reviewGrpMemberTag);
		MEM_free(COCHead_reviewSIGNOFF);
		MEM_free(COCHead_reviewGrpMemberTag);
		MEM_free(HOD_reviewGrpMemberTag);
		MEM_free(HOD_reviewSIGNOFF);
		MEM_free(COC_review_group);
		MEM_free(ModuleLeader_review_group);
		MEM_free(COCHead_review_group);
		MEM_free(HOD_review_group);
	}		
	
	
	return error_code;
}

/****************************************************************************
Function:       TML_New_Part_Request_function
Description:    This function is used in WF after while approve from manager login
				to release DML/task/part/dataset.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
int TML_New_Part_Request_function(EPM_action_message_t msg)
{
	tag_t        tzroottask             =  NULLTAG;
	tag_t        item		            =  NULLTAG;
	tag_t        release_status         =  NULLTAG;
	tag_t        *revstatus		        =  NULLTAG;
	tag_t        *tzattachment          =  NULLTAG;
	tag_t        *t_item1		        =  NULLTAG;
	tag_t        *effec			        =  NULLTAG;
	tag_t        *targetComponentList   =  NULLTAG;
	tag_t        *PartList				=  NULLTAG;
	tag_t        relation_type		    =  NULLTAG;
	tag_t        *attachments		    =  NULLTAG;
	tag_t		 *itemRevs				=  NULLTAG;
	tag_t		 relrev					=  NULLTAG;
	tag_t		 relprevrev				=  NULLTAG;
	tag_t		 query					=  NULLTAG;
	tag_t		 updatedrevtag			=  NULLTAG;
	tag_t		 updatedrevtag1			=  NULLTAG;
	tag_t		 updatedrevtag2			=  NULLTAG;
	tag_t		 updatedrevtag3			=  NULLTAG;
	tag_t		 updatedrevtag4			=  NULLTAG;
	tag_t		 updatedrevtag5			=  NULLTAG;
	tag_t		 session				=  NULLTAG;
	tag_t		 bomrelrev				=  NULLTAG;
	tag_t		 *BomViewList			=  NULLTAG;

	logical  	FrozenInd=1;
	

	tag_t  *status_list				= NULL;

	int          izntaskattachment      =  0;
	int	         iCountSec              =  0;
	int	         taskcount              =  0;
	int	         partcount              =  0;
	int	         partcounter            =  0;
	int	         cnt,count	            =  0;
	int	         partcnt,NStatus        =  0;
	int	         datacnt	            =  0;
	int	         h	            =  0;

	char		*DmlNumber				=  NULL;
	char		*newpartreq				=  NULL;
	char		*reqid				=  NULL;
	char		*desid					=  NULL;
	char		*revision_id			=  NULL;
	char		*lifecycle_state		=  NULL;
	char		*templog				=  NULL;
	char		*PartNumber				=  NULL;
	char		*revid					=  NULL;
	char		*tempDmlNumber			=  NULL;
	char		*dmltype				=  NULL;
	char		*UserId					=  NULL;

	char		*FileNameS					=  NULL;
	char		*ProjectNameDupS					=  NULL;
	char		*ProjectNameS					=  NULL;
	char		*t5DesignGroupDupS					=  NULL;
	char		*t5DesignGroupS					=  NULL;
	char		*t5NwDgSbGrpDupS					=  NULL;
	char		*t5NwDgSbGrpS					=  NULL;
	char		*t5NwDgIdDupS					=  NULL;
	char		*t5NwDgIdS					=  NULL;
	char		*PartNumberS					=  NULL;
	char		*t5NwTmlPtNoDup					=  NULL;
	char		*t5NwTmlPtNo					=  NULL;
	char		*NomenclatureDupS					=  NULL;
	char		*NomenclatureS					=  NULL;
	char		*t5NwTmlPtNo1S					=  NULL;
	char		*NomenclatureDupS1					=  NULL;
	char		*NomenclatureS1					=  NULL;
	


	tag_t        *LedgerSO				=  NULLTAG;


	int LedgerSize = 0;
	int UpdPartIndS = 0;


	logical     IsMirrorPaInd=false;

	EPM_decision_t   decision = EPM_go;

	date_t   *date			= NULL;

	char		*logFilePath			= NULL;

	logical StatusFound = false;

	char  name[WSO_name_size_c+1]    = {'\0'};

	int inumarg =0;
	int count1 =0;

	int n_entries = 1;
	int n_found = 1;

	tag_t	set_effec		= NULLTAG;

	//date_t ReleasedDate = NULLDATE;


	FILE *fplog = NULL;

	time_t now;

	//char ReleasedDate_str[12] = {'\0'};

	struct tm* now_tm;

	int n_tags_found;
	int BomViewCnt =0;

	//char **attrs = (char **) MEM_alloc(2 * sizeof(char *));
    //char **values = (char **) MEM_alloc(2 * sizeof(char *));
	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};

	char ***qry_entries1 = (char ***) MEM_alloc(10 * sizeof(char *));
	char ***qry_values1 = (char ***) MEM_alloc(10 * sizeof(char *));

	char
        *qry_entries3[1] = {"ECRID"},
        *qry_values3[1]	= {"*"};


	char		relation_name[TCTYPE_name_size_c+1];
	//char *ReleasedDate_str="2013/10/11";

	int error_code = ITK_ok;

	templog	=MEM_alloc(200);
	logFilePath=MEM_alloc(200);

	date = (date_t*) MEM_alloc(sizeof(date_t) * 2);

	tempDmlNumber = (char *) MEM_alloc( 10 * sizeof(char) );

	ITK_set_bypass(true);
	inumarg = TC_number_of_arguments(msg.arguments);
	printf("\n No of Argument====>[%d]", inumarg);fflush(stdout);

	POM_ask_session(&session);
	//AOM_ask_value_string(session,"user_id",&UserId);
	//printf("\n UserId====>[%s]", UserId);fflush(stdout);
	POM_get_user_id(&UserId);
	printf("\n TML_Attach_Alt_to_Targets::UserId====>[%s]", UserId);fflush(stdout);
	MEM_free(UserId);


	if(EPM_ask_root_task(msg.task, &tzroottask)!=ITK_ok)   PrintErrorStack();
	if(EPM_ask_attachments(tzroottask, EPM_target_attachment,&izntaskattachment, &tzattachment)!=ITK_ok)   PrintErrorStack();
	printf("\n No of Attachements====>[%d]", izntaskattachment);fflush(stdout);

	AOM_ask_value_string(tzattachment[0],"item_id",&newpartreq);
	printf("\n newpartreq====>[%s]", newpartreq);fflush(stdout);
	AOM_ask_value_string(tzattachment[0],"t5_NwRqNumber",&reqid);
	printf("\n reqid====>[%s]", reqid);fflush(stdout);

	
	FileNameS = (char *) MEM_alloc( 200 * sizeof(char) );
	tc_strcpy(FileNameS, "/tmp/");
	if(reqid) tc_strcat(FileNameS, reqid);
	if(FileNameS) tc_strcat(FileNameS,".txt");
	printf("\nThe filename is %s\n",FileNameS);fflush(stdout);

	AOM_ask_value_string(tzattachment[0],"t5_ProjectCode",&ProjectNameDupS);
	//tc_strdup(ProjectNameDupS,ProjectNameS);
	ProjectNameS = strdup(ProjectNameDupS);
	printf("\n ProjectNameS====>[%s]", ProjectNameS);fflush(stdout);

	AOM_ask_value_string(tzattachment[0],"t5_DesignGroup",&t5DesignGroupDupS);
	//if(t5DesignGroupDupS) tc_strdup(t5DesignGroupDupS,t5DesignGroupS);
	t5DesignGroupS = strdup(t5DesignGroupDupS);
	printf("\n t5DesignGroupS====>[%s]", t5DesignGroupS);fflush(stdout);

	AOM_ask_value_string(tzattachment[0],"t5_DesignSubGrp",&t5NwDgSbGrpDupS);
	//if(t5NwDgSbGrpDupS) tc_strdup(t5NwDgSbGrpDupS,t5NwDgSbGrpS);
	t5NwDgSbGrpS = strdup(t5NwDgSbGrpDupS);
	printf("\n t5NwDgSbGrpS====>[%s]", t5NwDgSbGrpS);fflush(stdout);

	AOM_ask_value_string(tzattachment[0],"t5_NwDgId",&t5NwDgIdDupS);
	//if(t5NwDgIdDupS) tc_strdup(t5NwDgIdDupS,t5NwDgIdS);
	t5NwDgIdS = strdup(t5NwDgIdDupS);
	printf("\n t5NwDgIdS====>[%s]", t5NwDgIdS);fflush(stdout);


	PartNumberS = (char *) MEM_alloc( 20 * sizeof(char) );
	if(ProjectNameS)tc_strcpy(PartNumberS,ProjectNameS);
	else tc_strcpy(PartNumberS, "2829");
	tc_strcat(PartNumberS,t5DesignGroupS);
	if(t5NwDgSbGrpS) tc_strcat(PartNumberS,t5NwDgSbGrpS);
	if(t5NwDgIdS) tc_strcat(PartNumberS,t5NwDgIdS);
	printf("\nThe PartNumber is %s\n",PartNumberS);fflush(stdout);

	AOM_ask_value_logical(tzattachment[0],"t5_IsMirrorPaInd",&IsMirrorPaInd);
	printf("\n IsMirrorPaInd====>[%s]", IsMirrorPaInd);fflush(stdout);

	AOM_ask_value_string(tzattachment[0],"t5NwTmlPtNo",&t5NwTmlPtNoDup);
	//tc_strdup(t5NwTmlPtNoDup,t5NwTmlPtNo);
	t5NwTmlPtNo = strdup(t5NwTmlPtNoDup);
	printf("\n t5NwTmlPtNo====>[%s]", t5NwTmlPtNo);fflush(stdout);

	AOM_ask_value_tags (tzattachment[0],"T5_NwLHP",&LedgerSize, &LedgerSO);
	printf("\n No of LedgerSize====>[%d]", LedgerSize);fflush(stdout);
	if(LedgerSize>0)
	{
		if(LedgerSize == 2 && IsMirrorPaInd==false)
		{
			return decision;
		}
		if(LedgerSize == 2 && IsMirrorPaInd==true)
		{
			if(tc_strlen(t5NwTmlPtNo)==0)
			{
				printf("2+Getting Part Number from Ledger as TML Part Number field is null");fflush(stdout);
				AOM_ask_value_string(LedgerSO[0],"item_id",&NomenclatureDupS);
				//if(NomenclatureDupS) tc_strdup(NomenclatureDupS,NomenclatureS);
				NomenclatureS = strdup(NomenclatureDupS);
				
				t5NwTmlPtNo1S = (char *) MEM_alloc( 40 * sizeof(char) );
				if(NomenclatureS)tc_strcpy(t5NwTmlPtNo1S,NomenclatureS);
				tc_strcat(t5NwTmlPtNo1S,";");

				printf("Getting Second Part Number from Ledger as TML Part Number field is null");fflush(stdout);
				AOM_ask_value_string(LedgerSO[1],"item_id",&NomenclatureDupS1);
				//if(NomenclatureDupS1) tc_strdup(NomenclatureDupS1,NomenclatureS1);
				NomenclatureS1 = strdup(NomenclatureDupS1);
				tc_strcat(t5NwTmlPtNo1S,NomenclatureS1);

				UpdPartIndS = 1;
			}
			if(strstr(t5NwTmlPtNo,";") == NULL)
			{
				printf("2+Getting Part Number from Ledger as TML Part Number field is null");fflush(stdout);
				AOM_ask_value_string(LedgerSO[0],"item_id",&NomenclatureDupS);
				//if(NomenclatureDupS) tc_strdup(NomenclatureDupS,NomenclatureS);
				NomenclatureS = strdup(NomenclatureDupS);

				
				t5NwTmlPtNo1S = (char *) MEM_alloc( 40 * sizeof(char) );
				if(NomenclatureS)tc_strcpy(t5NwTmlPtNo1S,NomenclatureS);
				tc_strcat(t5NwTmlPtNo1S,";");

				printf("Getting Second Part Number from Ledger as TML Part Number field is null");fflush(stdout);
				AOM_ask_value_string(LedgerSO[1],"item_id",&NomenclatureDupS1);
				//if(NomenclatureDupS1) tc_strdup(NomenclatureDupS1,NomenclatureS1);
				NomenclatureS1 = strdup(NomenclatureDupS1);
				tc_strcpy(t5NwTmlPtNo1S,NomenclatureS1);

				//tc_strcat(t5NwTmlPtNo1S,Nomenclature1S);
				UpdPartIndS = 1;
			}
		}
		if(LedgerSize == 1 && IsMirrorPaInd==false)
		{
			if(tc_strlen(t5NwTmlPtNo)==0)
			{
				UpdPartIndS = 1;
			}
		}
		if(LedgerSize > 2)
		{
			return decision;
		}
		if(LedgerSize == 1 && IsMirrorPaInd==false)
		{
			LedgerSize = 0;
			t5CatiaNumbering(tzattachment[0], PartNumberS,false,0);
			MEM_free(LedgerSO);
			GRM_find_relation_type("T5_NwLHP",&relation_type);
			if(relation_type != NULLTAG)
			{
				   
				GRM_list_secondary_objects_only(tzattachment[0],relation_type,&cnt,&attachments);
				printf("\n Attached Datasets:%d\n",cnt);fflush(stdout);
				if(cnt>0)
				{
					printf("1+Getting Part Number from Ledger as TML Part Number field is null");fflush(stdout);
					AOM_ask_value_string(LedgerSO[0],"item_id",&NomenclatureDupS);
					//if(NomenclatureDupS) tc_strdup(NomenclatureDupS,NomenclatureS);
					NomenclatureS = strdup(NomenclatureDupS);

					t5NwTmlPtNo1S = (char *) MEM_alloc( 40 * sizeof(char) );
					if(NomenclatureS)tc_strcpy(t5NwTmlPtNo1S,NomenclatureS);
					tc_strcat(t5NwTmlPtNo1S,";");

					printf("Getting Second art Number from Ledger as TML Part Number field is null");fflush(stdout);

					AOM_ask_value_string(LedgerSO[1],"item_id",&NomenclatureDupS1);
					//if(NomenclatureDupS1) tc_strdup(NomenclatureDupS1,NomenclatureS1);
					NomenclatureS1 = strdup(NomenclatureDupS1);
					tc_strcat(t5NwTmlPtNo1S,NomenclatureS1);

					//tc_strcat(t5NwTmlPtNo1S,Nomenclature1S);
					UpdPartIndS = 1;


				}
				else
				{
					return decision;
				}
			}
		}
	}
	else
	{		
		if(IsMirrorPaInd==true)
		{
			t5CatiaNumbering(tzattachment[0], PartNumberS,true,0);
		}
		else
		{
			t5CatiaNumbering(tzattachment[0], PartNumberS,false,0);
		}
	}
	//Updating TML Part Number as part ledger and its relationship was created but TML Part Number not updated, useful when event is restarted.
	if(UpdPartIndS == 1)
	{		
		printf("\n TML Part Number value is %s\n", t5NwTmlPtNo1S);
		if(t5NwTmlPtNo1S)
		{
			AOM_refresh( tzattachment[0], TRUE);
			POM_attr_id_of_attr("t5NwTmlPtNo", "T5_NwPCreRevision", &updatedrevtag1);
			POM_set_attr_string(1, &tzattachment[0], updatedrevtag1, t5NwTmlPtNo1S);
			POM_save_instances(1, &tzattachment[0], false);
			printf("\n 6 Completed::POM_save_instances");fflush(stdout);
			AOM_refresh(tzattachment[0], FALSE);
		}
		else
		{
			return decision;
		}
	}
	AOM_refresh( tzattachment[0], TRUE);
	POM_attr_id_of_attr("t5_NwLCState", "T5_NwPCreRevision", &updatedrevtag2);
	POM_set_attr_string(1, &tzattachment[0], updatedrevtag2, "LcsNwAppr");
	POM_save_instances(1, &tzattachment[0], false);
	printf("\n 6 Completed::POM_save_instances");fflush(stdout);
	AOM_refresh(tzattachment[0], FALSE);
	return decision;
}


/****************************************************************************
Function:       t5CatiaNumbering
Description:    This function used to create part ledger .
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int t5CatiaNumbering(tag_t NewPartReqObj,char *thisPartNumber,logical updatable , int incrementval)
{
	int   n_found,n_found1,n_found2,n_found3,n_found4,n_found5,i = 0,
		count						= 0,
		ifail						= 0;

	char *status_name				= NULL;

	char
        *qry_entries3[2] = {"Name","Type"},
        *qry_values3[2]	= {"*","*"};

	char
        *qry_entries4[2] = {"Name","Type"},
        *qry_values4[2]	= {"*","*"};

	char
        *qry_entries5[2] = {"Name","Type"},
        *qry_values5[2]	= {"*","*"};

	tag_t query						= NULLTAG;
	tag_t query2						= NULLTAG;
	tag_t query3						= NULLTAG;
	tag_t query4						= NULLTAG;
	tag_t query5						= NULLTAG;
		
	tag_t  *q_item1				= NULLTAG;
	tag_t  *q_item2				= NULLTAG;
	tag_t  *q_item3				= NULLTAG;
	tag_t  *q_item4				= NULLTAG;
	tag_t  *q_item5				= NULLTAG;
	tag_t  *soResult1				= NULLTAG;
	date_t ReleasedDate = NULLDATE;

	char         *PartNumberS             = NULL;
	char         *TCPartNumberDupS             = NULL;
	char         *TCPartNumberS             = NULL;
	char         *vstr             = NULL;
	
	char         *thisPartNumber1             = NULL;

	char		*ProjectNameDupS					=  NULL;
	char		*ProjectNameS					=  NULL;
	char		*t5DesignGroupDupS					=  NULL;
	char		*t5DesignGroupS					=  NULL;
	char		*t5NwDgSbGrpDupS					=  NULL;
	char		*t5NwDgSbGrpS					=  NULL;
	char		*t5NwDgIdDupS					=  NULL;
	char		*t5NwDgIdS					=  NULL;

	int  y = 0;
	int  x = 0;
	int  w = 0;
	int  v = 0;
	int  t = 0;
	int thisPartNumber5 = 0;
	



	//char *soResult1[20000] = {"*"};

	char  name[WSO_name_size_c+1]    = {'\0'};
	int looponce = 0;

	time_t now;
	int pp,l,z,j,PartExistLedger,FAIL=0;

	char ReleasedDate_str[12] = {'\0'};

	struct tm* now_tm;

	
	int retcode = ITK_ok;

	printf("\n Inside t5CatiaNumbering \n");fflush(stdout);

	
	PartNumberS = (char *) MEM_alloc( 20 * sizeof(char) );
	
	printf("\nINput Part Numbetr is %s\n", thisPartNumber);

	if(thisPartNumber) 
	{
		tc_strcpy(PartNumberS,thisPartNumber);
		tc_strcat(PartNumberS,"*");
		printf("\nINput Part Numbetr is %s\n", PartNumberS);fflush(stdout);
	}
	else 
	{
		return 0;
	}

	qry_values3[0]	= PartNumberS;
	qry_values3[1]	= "Design";
	QRY_find2("Item - simple", &query);
	QRY_execute(query, 2, qry_entries3, qry_values3, &n_found, &q_item1);
	printf("\n n_found =[%d]",n_found);fflush(stdout);

	if(n_found>0)
	{
		soResult1 = (tag_t *) MEM_alloc( n_found * sizeof(tag_t) );
		for(i = 0;i<n_found ;i++)
		{
			AOM_ask_value_string(q_item1[i],"item_id",&TCPartNumberDupS);
			//if(TCPartNumberDupS) tc_strdup(TCPartNumberDupS,TCPartNumberS);
			TCPartNumberS = strdup(TCPartNumberDupS);
			v = strlen(TCPartNumberS);
			printf("\nTCPartNumberS == %s and lenght == %d\n",TCPartNumberS,v);fflush(stdout);
			if(v==12)
			{
				setAddTAG(&l,&soResult1,q_item1[i]);
			}
		}
		i=0;
		if(l > 0)
		{
			z=0;
			for (i = 0;i<101 ;i++ )
			{
				printf("\nInside For Condition");fflush(stdout);
				MEM_free(vstr);
				vstr = (char *) MEM_alloc( 20 * sizeof(char) );
				if(i < 10)
				{
					sprintf(vstr,"%s0%d",thisPartNumber,i);
				}
				else
				{
					sprintf(vstr,"%s%d",thisPartNumber,i);
				}
				if(j<l)
				{
					printf("\n j == %d\n",j);fflush(stdout);
					AOM_ask_value_string(soResult1[j],"item_id",&TCPartNumberDupS);
					//if(TCPartNumberDupS) tc_strdup(TCPartNumberDupS,TCPartNumberS);
					TCPartNumberS = strdup(TCPartNumberDupS);
					printf("\n vstr=>%s == TCPartNumberS-->%s", vstr, TCPartNumberS);fflush(stdout);
					if(strcmp(vstr,TCPartNumberS)==0)
					{
						j++;	
						printf("\n %s == %s --> Already Exists", vstr, TCPartNumberS);fflush(stdout);
					}
					else
					{
						printf("\n %s == Not Found in Queried Part List 5555555555", vstr);fflush(stdout);
						PartExistLedger = t5CheckInPartLeadger(vstr);
						if(PartExistLedger == 0 && i != 0)
						{
							FAIL = t5CreatePart(NewPartReqObj, vstr);
							if(FAIL==1)
							{
								printf("\nPart Ledger Creation Failed\n");fflush(stdout);
								if(looponce == 0)
								{
									z++;
									looponce = 1;
									printf("\nLooping one more time for creating Part Ledger\n");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n*** Looping 2 time also failed to create Part Ledger. Hence Exiting. ***\n");fflush(stdout);
								}
							}
							else
							{
								printf("\nNew Part Ledger Created Successfully\n");fflush(stdout);
							}
							if(updatable==true)
							{
								updatable = false;
								z++;
								continue;
							}
							else
							{
								break;
							}
						}
						else
						{
							z++;
						}
						
					}
				}
				else
				{
					printf("\n j == %d",j+z);fflush(stdout);
					y=(j+z)/100;           /*  Computes quotient */
					x=(j+z)%100;			/*  Computes Remainder */

					if((x == 0 ))
					{
											
					
						AOM_ask_value_string(NewPartReqObj,"t5_ProjectCode",&ProjectNameDupS);
						//tc_strdup(ProjectNameDupS,ProjectNameS);
						ProjectNameS = strdup(ProjectNameDupS);
						printf("\n ProjectNameS====>[%s]", ProjectNameS);fflush(stdout);

						AOM_ask_value_string(NewPartReqObj,"t5_DesignGroup",&t5DesignGroupDupS);
						//if(t5DesignGroupDupS) tc_strdup(t5DesignGroupDupS,t5DesignGroupS);
						t5DesignGroupS = strdup(t5DesignGroupDupS);
						printf("\n t5DesignGroupS====>[%s]", t5DesignGroupS);fflush(stdout);

						AOM_ask_value_string(NewPartReqObj,"t5_DesignSubGrp",&t5NwDgSbGrpDupS);
						//if(t5NwDgSbGrpDupS) tc_strdup(t5NwDgSbGrpDupS,t5NwDgSbGrpS);
						t5NwDgSbGrpS = strdup(t5NwDgSbGrpDupS);
						printf("\n t5NwDgSbGrpS====>[%s]", t5NwDgSbGrpS);fflush(stdout);

						AOM_ask_value_string(NewPartReqObj,"t5_NwDgId",&t5NwDgIdDupS);
						//if(t5NwDgIdDupS) tc_strdup(t5NwDgIdDupS,t5NwDgIdS);
						t5NwDgIdS = strdup(t5NwDgIdDupS);
						printf("\n t5NwDgIdS====>[%s]", t5NwDgIdS);fflush(stdout);

						thisPartNumber5 = atoi(t5NwDgSbGrpS);
						printf("\nIncremnet Vaue and SubDesign GrpS == %d and %d\n",incrementval, thisPartNumber5);
						
						w = incrementval + 1;
						t = thisPartNumber5+w;
						
						thisPartNumber1 = (char *) MEM_alloc( 50 * sizeof(char) );
						if(t < 10)
						{
							sprintf(thisPartNumber1,"%s%s0%d%s", ProjectNameS, t5DesignGroupS,t,t5NwDgIdS);
						}
						else
						{
							sprintf(thisPartNumber1,"%s%s%d%s", ProjectNameS, t5DesignGroupS,t,t5DesignGroupS);
						}
						printf("\nNew Input Part Number %s== %d\n", thisPartNumber1, t);fflush(stdout);
						t5CatiaNumbering(NewPartReqObj, thisPartNumber1,false,w);
						break;				
					}
					else
					{
						printf("\n %s == Not Found in Queried Part List 66666666", vstr);fflush(stdout);
						PartExistLedger = t5CheckInPartLeadger(vstr);
						if(PartExistLedger == 0)
						{
							FAIL = t5CreatePart(NewPartReqObj, vstr);	
							if(FAIL==1)
							{
								printf("\n33333Part Ledger Creation Failed\n");fflush(stdout);
								if(looponce == 0)
								{
									z++;
									looponce = 1;
									printf("\n33333Looping one more time for creating Part Ledger\n");fflush(stdout);
									continue;									
								}
								else
								{
									printf("\n33333Looping 2 time also failed to create Part Ledger\n");fflush(stdout);
								}
							}
							else
							{
								printf("\n33333New Part Ledger Created Successfully\n");fflush(stdout);
							}
							if(updatable==true)
							{
								updatable = false;
								z++;
								continue;
							}
							else
							{
								break;
							}
						}
						else
						{
							z++;
						}
					}
				}
			}
		}
		else
		{
			qry_values5[0]	= PartNumberS;
			qry_values5[1]	= "Part Ledger";
			QRY_find2("General...", &query5);
			QRY_execute(query5, 2, qry_entries5, qry_values5, &n_found5, &q_item5);
			printf("\n n_found5 =[%d]",n_found5);fflush(stdout);
			printf("\nNumber of Ledger Object Found are %d\n",n_found5);fflush(stdout);
			

			if(n_found5 > 0)
			{
				soResult1 = (tag_t *) MEM_alloc( n_found5 * sizeof(tag_t) );
				for (i = 0;i<n_found5 ;i++ )
				{
					AOM_ask_value_string(q_item5[i],"item_id",&TCPartNumberS);
					
					v = strlen(TCPartNumberS);
					printf("\nTCPartNumberS == %s and lenght == %d\n",TCPartNumberS,v);
					if(v == 12)
					{
						setAddTAG(&l,&soResult1,q_item5[i]);
					}
				}
				printf("\nNo Of Objects in Set are %d\n", l);
				i=1;
				if(l > 0)
				{
					for (i = 0;i<101 ;i++ )
					{				
						printf("\nInside For Condition");fflush(stdout);
						MEM_free(vstr);
						vstr = (char *) MEM_alloc( 20 * sizeof(char) );
						if(i < 10)
						{
							sprintf(vstr,"%s0%d",thisPartNumber,i);
						}
						else
						{
							sprintf(vstr,"%s%d",thisPartNumber,i);
						}
						if(j<l)
						{	
							printf("\n j == %d\n",j);fflush(stdout);
							//printf("\nvstr == %s\n",vstr);

							AOM_ask_value_string(soResult1[j],"item_id",&TCPartNumberS);
							printf("\n %s == %s", vstr, TCPartNumberS);fflush(stdout);
							
							
							if(strcmp(vstr, TCPartNumberS) == 0)
							{
								j++;	
								printf("\n %s == %s --> Ledger Already Exists", vstr, TCPartNumberS);fflush(stdout);
							}
							else
							{	
								printf("\n %s == Ledger Not Found in Queried Part List 1111", vstr);fflush(stdout);
								PartExistLedger = t5CheckInPartLeadger(vstr);
								if(PartExistLedger == 0 && i !=0)
								{
									FAIL = t5CreatePart(NewPartReqObj, vstr);
									if(FAIL==1) 
									{
										printf("\n22222Part Ledger Creation Failed\n");fflush(stdout);
										if(looponce == 0)
										{
											z++;
											looponce = 1;
											printf("\n22222Looping one more time for creating Part Ledger\n");fflush(stdout);
											continue;									
										}
										else
										{
											printf("\n22222Looping 2 time also failed to create Part Ledger\n");fflush(stdout);
										}
									}
									else
									{
										printf("\n22222New Part Ledger Created Successfully\n");fflush(stdout);
									}
									if(updatable==true)
									{
										updatable = false;
										z++;
										continue;
									}
									else
									{
										break;
									}
								}
								else
								{
									z++;
								}
							}					
						}
						else
						{
							printf("\n j == %d",j+z);fflush(stdout);
							y=(j+z)/100;           /*  Computes quotient */
							x=(j+z)%100;			/*  Computes Remainder */
							if((x == 0 ))
							{
								AOM_ask_value_string(NewPartReqObj,"t5_ProjectCode",&ProjectNameDupS);
								//tc_strdup(ProjectNameDupS,ProjectNameS);
								ProjectNameS = strdup(ProjectNameDupS);
								printf("\n ProjectNameS====>[%s]", ProjectNameS);fflush(stdout);

								AOM_ask_value_string(NewPartReqObj,"t5_DesignGroup",&t5DesignGroupDupS);
								//if(t5DesignGroupDupS) tc_strdup(t5DesignGroupDupS,t5DesignGroupS);
								t5DesignGroupS = strdup(t5DesignGroupDupS);
								printf("\n t5DesignGroupS====>[%s]", t5DesignGroupS);fflush(stdout);

								AOM_ask_value_string(NewPartReqObj,"t5_DesignSubGrp",&t5NwDgSbGrpDupS);
								//if(t5NwDgSbGrpDupS) tc_strdup(t5NwDgSbGrpDupS,t5NwDgSbGrpS);
								t5NwDgSbGrpS = strdup(t5NwDgSbGrpDupS);
								printf("\n t5NwDgSbGrpS====>[%s]", t5NwDgSbGrpS);fflush(stdout);

								AOM_ask_value_string(NewPartReqObj,"t5_NwDgId",&t5NwDgIdDupS);
								//if(t5NwDgIdDupS) tc_strdup(t5NwDgIdDupS,t5NwDgIdS);
								t5NwDgIdS = strdup(t5NwDgIdDupS);
								printf("\n t5NwDgIdS====>[%s]", t5NwDgIdS);fflush(stdout);						
								
								thisPartNumber5 = atoi(t5NwDgSbGrpS);
								printf("\nIncremnet Vaue and SubDesign GrpS == %d and %d\n",incrementval, thisPartNumber5);
								
								w = incrementval + 1;
								t = thisPartNumber5+w;
								
								thisPartNumber1 = (char *) MEM_alloc( 50 * sizeof(char) );
								if(t < 10)
								{
									sprintf(thisPartNumber1,"%s%s0%d%s", ProjectNameS, t5DesignGroupS,t,t5NwDgIdS);
								}
								else
								{
									sprintf(thisPartNumber1,"%s%s%d%s", ProjectNameS, t5DesignGroupS,t,t5NwDgIdS);
								}
								printf("\nNew Input Part Number %s== %d\n", thisPartNumber1, t);fflush(stdout);
								t5CatiaNumbering(NewPartReqObj, thisPartNumber1,false,w);
								break;				
							}
							else
							{
								printf("\n %s == Not Found in Queried Part List 66666666", vstr);fflush(stdout);
								PartExistLedger = t5CheckInPartLeadger(vstr);
								if(PartExistLedger == 0)
								{
									FAIL = t5CreatePart(NewPartReqObj, vstr);
									if(FAIL==1) 
									{
										printf("\n33333Part Ledger Creation Failed\n");fflush(stdout);
										if(looponce == 0)
										{
											z++;
											looponce = 1;
											printf("\n33333Looping one more time for creating Part Ledger\n");fflush(stdout);
											continue;									
										}
										else
										{
											printf("\n33333Looping 2 time also failed to create Part Ledger\n");fflush(stdout);
										}
									}
									else
									{
										printf("\n33333New Part Ledger Created Successfully\n");fflush(stdout);
									}
									if(updatable==true)
									{
										updatable = false;
										z++;
										continue;
									}
									else
									{
										break;
									}
								}
								else
								{
									z++;
								}
							}
						}
					}
				}
			}
			else
			{
				// Part and Ledger Both Not Found
				MEM_free(vstr);
				vstr = (char *) MEM_alloc( 20 * sizeof(char) );
				i = 1;
				sprintf(vstr,"%s0%d",thisPartNumber,i);

				PartExistLedger = t5CheckInPartLeadger(vstr);
				if(PartExistLedger == 0)
				{
					printf("\nThe part number already exists %s\n", vstr);
					FAIL = t5CreatePart(NewPartReqObj, vstr);
					if(FAIL==1) 
					{
						i=i+1;
						MEM_free(vstr);
						vstr = (char *) MEM_alloc( 20 * sizeof(char) );
						sprintf(vstr,"%s0%d",thisPartNumber,i);
						FAIL = t5CreatePart(NewPartReqObj, vstr);
					}
					else
					{
						printf("\n33333New Part Ledger Created Successfully\n");fflush(stdout);
					}
				}
				else
				{
					printf("\n33333New Part Ledger Created Successfully\n");fflush(stdout);
				}

				if(updatable==true)
				{
					MEM_free(vstr);
					vstr = (char *) MEM_alloc( 20 * sizeof(char) );
					i=i+1;
					sprintf(vstr,"%s0%d",thisPartNumber,i);
					updatable = false;

					PartExistLedger = t5CheckInPartLeadger(vstr);
					if(PartExistLedger == 0)
					{
						FAIL = t5CreatePart(NewPartReqObj, vstr);
						if(FAIL==1) 
						{
							i=i+1;
							MEM_free(vstr);	
							vstr = (char *) MEM_alloc( 20 * sizeof(char) );
							sprintf(vstr,"%s0%d",thisPartNumber,i);
							FAIL = t5CreatePart(NewPartReqObj, vstr);
						}
						else
						{
							printf("\n33333New Part Ledger Created Successfully\n");fflush(stdout);
						}
					}
					else
					{
						 printf("\nThe part number already exists %s\n", vstr);
					}
				}
			}
		}
		///
	}
	else
	{
		
		//No Part Found querying in the Part Ledger
		qry_values4[0]	= PartNumberS;
		qry_values4[1]	= "Part Ledger";
		QRY_find2("General...", &query4);
		QRY_execute(query4, 2, qry_entries4, qry_values4, &n_found4, &q_item4);
		printf("\n n_found4 =[%d]",n_found4);fflush(stdout);
		printf("\nNumber of Ledger Object Found are %d\n",n_found4);fflush(stdout);

		if(n_found4 > 0)
		{
			soResult1 = (tag_t *) MEM_alloc( n_found4 * sizeof(tag_t) );
			for (i = 0;i<n_found4 ;i++ )
			{
				AOM_ask_value_string(q_item4[i],"item_id",&TCPartNumberS);
				
				v = strlen(TCPartNumberS);
				printf("\nTCPartNumberS == %s and lenght == %d\n",TCPartNumberS,v);fflush(stdout);
				if(v == 12)
				{
					setAddTAG(&l,&soResult1,q_item4[i]);
				}
			}
			printf("\nNo Of Objects in Set are %d\n", l);fflush(stdout);
			i=0;
			if(l > 0)
			{
				for (i = 0;i<101 ;i++ )
				{				
					printf("\nInside For Condition");fflush(stdout);
					MEM_free(vstr);
					vstr = (char *) MEM_alloc( 20 * sizeof(char) );
					if(i < 10)
					{
						sprintf(vstr,"%s0%d",thisPartNumber,i);
					}
					else
					{
						sprintf(vstr,"%s%d",thisPartNumber,i);
					}
					if(j<l)
					{	
						printf("\n j == %d\n",j);fflush(stdout);
						AOM_ask_value_string(soResult1[j],"item_id",&TCPartNumberS);
						printf("\n %s == %s", vstr, TCPartNumberS);fflush(stdout);
						
						
						if(tc_strcmp(vstr,TCPartNumberS)==0)
						{
							j++;	
							printf("\n %s == %s --> Ledger Already Exists", vstr, TCPartNumberS);
						}
						else
						{	
							printf("\n %s == Ledger Not Found in Queried Part List 3333333333", vstr);	
							PartExistLedger = t5CheckInPartLeadger(vstr);
							if(PartExistLedger == 0 && i != 0)
							{
								FAIL = t5CreatePart(NewPartReqObj, vstr);
								if(FAIL==1)
								{
									printf("\nPart Ledger Creation Failed\n");fflush(stdout);
									//vstr="282930010198";
									if(looponce == 0)
									{
										z++;
										looponce = 1;
										printf("\nLooping one more time for creating Part Ledger\n");fflush(stdout);
										continue;
									}
									else
									{
										printf("\n*** Looping 2 time also failed to create Part Ledger. Hence Exiting. ***\n");fflush(stdout);
									}
								}
								else
								{
									printf("\nNew Part Ledger Created Successfully\n");fflush(stdout);
								}
								if(updatable==true)
								{
									updatable = false;
									z++;
									continue;
								}
								else
								{
									break;
								}
							}
							else
							{
								z++;
							}
						}					
					}
					else
					{
						printf("\n j == %d",j+z);fflush(stdout);
						y=(j+z)/100;           /*  Computes quotient */
						x=(j+z)%100;			/*  Computes Remainder */
						if((x == 0 ))
						{
							AOM_ask_value_string(NewPartReqObj,"t5_ProjectCode",&ProjectNameDupS);
							//tc_strdup(ProjectNameDupS,ProjectNameS);
							ProjectNameS = strdup(ProjectNameDupS);
							printf("\n ProjectNameS====>[%s]", ProjectNameS);fflush(stdout);

							AOM_ask_value_string(NewPartReqObj,"t5_DesignGroup",&t5DesignGroupDupS);
							//if(t5DesignGroupDupS) tc_strdup(t5DesignGroupDupS,t5DesignGroupS);
							t5DesignGroupS = strdup(t5DesignGroupDupS);
							printf("\n t5DesignGroupS====>[%s]", t5DesignGroupS);fflush(stdout);

							AOM_ask_value_string(NewPartReqObj,"t5_DesignSubGrp",&t5NwDgSbGrpDupS);
							//if(t5NwDgSbGrpDupS) tc_strdup(t5NwDgSbGrpDupS,t5NwDgSbGrpS);
							t5NwDgSbGrpS = strdup(t5NwDgSbGrpDupS);
							printf("\n t5NwDgSbGrpS====>[%s]", t5NwDgSbGrpS);fflush(stdout);

							AOM_ask_value_string(NewPartReqObj,"t5_NwDgId",&t5NwDgIdDupS);
							//if(t5NwDgIdDupS) tc_strdup(t5NwDgIdDupS,t5NwDgIdS);
							t5NwDgIdS = strdup(t5NwDgIdDupS);
							printf("\n t5NwDgIdS====>[%s]", t5NwDgIdS);fflush(stdout);						
							
							thisPartNumber5 = atoi(t5NwDgSbGrpS);
							printf("\nIncremnet Vaue and SubDesign GrpS == %d and %d\n",incrementval, thisPartNumber5);
							
							w = incrementval + 1;
							t = thisPartNumber5+w;
							
							thisPartNumber1 = (char *) MEM_alloc( 50 * sizeof(char) );
							if(t < 10)
							{
								sprintf(thisPartNumber1,"%s%s0%d%s", ProjectNameS, t5DesignGroupS,t,t5NwDgIdS);
							}
							else
							{
								sprintf(thisPartNumber1,"%s%s%d%s", ProjectNameS, t5DesignGroupS,t,t5NwDgIdS);
							}
							printf("\nNew Input Part Number %s== %d\n", thisPartNumber1, t);fflush(stdout);
							t5CatiaNumbering(NewPartReqObj, thisPartNumber1,false,w);
							break;
						}
						else
						{							
							printf("\n %s == Not Found in Queried Part List 66666666", vstr);fflush(stdout);
							PartExistLedger = t5CheckInPartLeadger(vstr);
							if(PartExistLedger == 0)
							{
								FAIL = t5CreatePart(NewPartReqObj, vstr);
								if(FAIL==1)
								{
									printf("\nPart Ledger Creation Failed\n");fflush(stdout);
									if(looponce == 0)
									{
										z++;
										looponce = 1;
										printf("\nLooping one more time for creating Part Ledger\n");fflush(stdout);
										continue;
									}
									else
									{
										printf("\n*** Looping 2 time also failed to create Part Ledger. Hence Exiting. ***\n");fflush(stdout);
									}
								}
								else
								{
									printf("\n55555New Part Ledger Created Successfully\n");fflush(stdout);
								}
								if(updatable==true)
								{
									updatable = false;
									z++;
									continue;
								}
								else
								{
									break;
								}
							}
							else
							{
								z++;
							}
						}
					}
				}
			}
		}
		else
		{
			// Part and Ledger Both Not Found
			MEM_free(vstr);
			vstr = (char *) MEM_alloc( 20 * sizeof(char) );
			i = 1;
			sprintf(vstr,"%s0%d",thisPartNumber,i);

			PartExistLedger = t5CheckInPartLeadger(vstr);
			
			if(PartExistLedger == 0)
			{
				FAIL = t5CreatePart(NewPartReqObj, vstr);
				if(FAIL==1) 
				{
					i=i+1;
					MEM_free(vstr);
					vstr = (char *) MEM_alloc( 20 * sizeof(char) );
					sprintf(vstr,"%s0%d",thisPartNumber,i);
					FAIL = t5CreatePart(NewPartReqObj, vstr);
					
				}
				else
				{
					printf("\n44444New Part Ledger Created Successfully\n");fflush(stdout);
				}
			}
			else
			{
				 printf("\nThe part number already exists %s\n", vstr);fflush(stdout);
			}

			if(updatable==true)
			{
				MEM_free(vstr);
				vstr = (char *) MEM_alloc( 20 * sizeof(char) );
				i=i+1;
				sprintf(vstr,"%s0%d",thisPartNumber,i);
				updatable = false;

				PartExistLedger = t5CheckInPartLeadger(vstr);
				if(PartExistLedger == 0)
				{
					FAIL = t5CreatePart(NewPartReqObj, vstr);
					if(FAIL==1) 
					{
						i=i+1;
						MEM_free(vstr);
						vstr = (char *) MEM_alloc( 20 * sizeof(char) );
						sprintf(vstr,"%s0%d",thisPartNumber,i);
						FAIL = t5CreatePart(NewPartReqObj, vstr);
						
					}
					else
					{
						printf("\n33333New Part Ledger Created Successfully\n");fflush(stdout);
					}
				}				
				else
				{
					printf("\nThe part number already exists %s\n", vstr);fflush(stdout);
				}
			}
		}
	}
	//

	return retcode;

}


/* Function to add Tag into a set of Tag */	
void setAddTAG(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		printf("\n ****setAddTAG1");fflush(stdout);
		//(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
		(*objlist) = (tag_t *)MEM_alloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		printf("\n ****setAddTAG2");fflush(stdout);
		//(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
		(*objlist) = (tag_t *)MEM_realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}


/* Function to add string into a set of string */
void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		//(*strset) = (char **)malloc((*count ) * sizeof(char *));
		(*strset) = (char **)MEM_alloc((*count ) * sizeof(char *));
	}
	else
	{
		//(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
		(*strset) = (char **)MEM_realloc((*strset),(*count ) * sizeof(char *));
	}
	//(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	(*strset)[*count-1] = MEM_alloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}


int t5CheckInPartLeadger(char *thisPartNumber)
{
	 char
        *qry_entries3[2] = {"Name","Type"},
        *qry_values3[2]	= {"*","*"}; 

	 tag_t query						= NULLTAG;
		
	tag_t  *q_item1				= NULLTAG;
	int n_found = 0;



	 int retcode = ITK_ok;


    qry_values3[0]	= thisPartNumber;
	qry_values3[1]	= "Part Ledger";
	QRY_find2("General...", &query);
	QRY_execute(query, 2, qry_entries3, qry_values3, &n_found, &q_item1);
	printf("\n n_found =[%d]",n_found);fflush(stdout);

	if(n_found>0)
	{
	    printf("\n Ledger==%s Found in function \n",thisPartNumber);

		return 1;	
	}
	else 
		
	{
	    printf("\n Ledger ===%s Not Found in function \n",thisPartNumber);
		return 0;


	}

}

int t5CreatePart(tag_t NewPartReqObj, char *thisPartNumber)
{

	char *ProjectNameDupS = NULL;
	char *ProjectNameS = NULL;

	char *t5DesignGroupDupS = NULL;
	char *t5DesignGroupS = NULL;

	char *t5NwDgSbGrpDupS = NULL;
	char *t5NwDgSbGrpS = NULL;

	char *t5NwDgIdDupS = NULL;
	char *t5NwDgIdS = NULL;
	char *t5NwTmlPtNo1S = NULL;
	char *ledgerdocnumber = NULL;
	char *ledgerdoc = NULL;

	logical     IsMirrorPaInd=false;

	char *t5NwTmlPtNoDup = NULL;
	char *t5NwTmlPtNo = NULL;

	tag_t PartLedgerTag = NULLTAG;
	tag_t PrtLedgerTypeTag = NULLTAG;
	tag_t PrtLedgerCreInTag = NULLTAG;
	tag_t creltypetag = NULLTAG;
	tag_t rel_tag = NULLTAG;

	char**			stringArrayAPLD		= NULL;
	int			    	n_strings			= 1;
	int				index,failure				= 0;

	int retcode = ITK_ok;

	AOM_ask_value_string(NewPartReqObj,"t5_ProjectCode",&ProjectNameDupS);
	//tc_strdup(ProjectNameDupS,ProjectNameS);
	ProjectNameS = strdup(ProjectNameDupS);
	printf("\n ProjectNameS====>[%s]", ProjectNameS);fflush(stdout);

	AOM_ask_value_string(NewPartReqObj,"t5_DesignGroup",&t5DesignGroupDupS);
	//if(t5DesignGroupDupS) tc_strdup(t5DesignGroupDupS,t5DesignGroupS);
	t5DesignGroupS = strdup(t5DesignGroupDupS);
	printf("\n t5DesignGroupS====>[%s]", t5DesignGroupS);fflush(stdout);

	AOM_ask_value_string(NewPartReqObj,"t5_DesignSubGrp",&t5NwDgSbGrpDupS);
	//if(t5NwDgSbGrpDupS) tc_strdup(t5NwDgSbGrpDupS,t5NwDgSbGrpS);
	t5NwDgSbGrpS = strdup(t5NwDgSbGrpDupS);
	printf("\n t5NwDgSbGrpS====>[%s]", t5NwDgSbGrpS);fflush(stdout);

	AOM_ask_value_string(NewPartReqObj,"t5_NwDgId",&t5NwDgIdDupS);
	//if(t5NwDgIdDupS) tc_strdup(t5NwDgIdDupS,t5NwDgIdS);
	t5NwDgIdS = strdup(t5NwDgIdDupS);
	printf("\n t5NwDgIdS====>[%s]", t5NwDgIdS);fflush(stdout);

	AOM_ask_value_logical(NewPartReqObj,"t5_IsMirrorPaInd",&IsMirrorPaInd);
	printf("\n IsMirrorPaInd====>[%s]", IsMirrorPaInd);fflush(stdout);

	AOM_ask_value_string(NewPartReqObj,"t5NwTmlPtNo",&t5NwTmlPtNoDup);
	//tc_strdup(t5NwTmlPtNoDup,t5NwTmlPtNo);
	t5NwTmlPtNo = strdup(t5NwTmlPtNoDup);
	printf("\n t5NwTmlPtNo====>[%s]", t5NwTmlPtNo);fflush(stdout);

	printf("\n\nGoing to  Create Part Ledger -->%s\n\n",thisPartNumber);fflush(stdout);

	TCTYPE_find_type ("T5_PrtMtr", NULL, &PrtLedgerTypeTag );
	TCTYPE_construct_create_input( PrtLedgerTypeTag, &PrtLedgerCreInTag);
	AOM_set_value_string(PrtLedgerCreInTag, "object_name", thisPartNumber);
	AOM_set_value_string(PrtLedgerCreInTag, "t5_PrtProjCode", ProjectNameS);
	AOM_set_value_string(PrtLedgerCreInTag, "t5_PrtDesignGrp", t5DesignGroupS);
	AOM_set_value_string(PrtLedgerCreInTag, "t5_PrtSubGroup", t5NwDgSbGrpS);
	AOM_set_value_string(PrtLedgerCreInTag, "t5_PrtDesignation", t5NwDgIdS);
	AOM_set_value_string(PrtLedgerCreInTag, "t5_PrtNmbrDesc", thisPartNumber);
	TCTYPE_create_object( PrtLedgerCreInTag, &PartLedgerTag);
	
	if(PartLedgerTag!=NULLTAG)
	{
		AOM_refresh( PartLedgerTag, TRUE);
		AOM_save_without_extensions(PartLedgerTag);
		AOM_refresh(PartLedgerTag,FALSE);
		AOM_ask_value_string(PartLedgerTag,"object_name",&ledgerdocnumber);
		printf("\n Part Ledger [%s] Created Successfully*******",ledgerdocnumber);
		AOM_ask_value_string(PartLedgerTag,"t5_PrtNmbrDesc",&ledgerdoc);
		printf("\n Part Ledger [%s] Created Successfully*******",ledgerdoc);
	}
	


	

	if(IsMirrorPaInd== true)
	{
		if(strlen(t5NwTmlPtNo)==0)
		{
			AOM_refresh( NewPartReqObj, TRUE);
			AOM_set_value_string(NewPartReqObj,"t5_NwTmlPtNo",thisPartNumber);
			AOM_save_without_extensions(NewPartReqObj);
			AOM_refresh(NewPartReqObj,FALSE);
		}
		else
		{
			t5NwTmlPtNo1S = (char *) MEM_alloc( 40 * sizeof(char) );
			strcpy(t5NwTmlPtNo1S,t5NwTmlPtNo);
			strcat(t5NwTmlPtNo1S,";");
			strcat(t5NwTmlPtNo1S,thisPartNumber);
			if(strlen(t5NwTmlPtNo1S) > 30) 
			{
				printf("\n*** TML Part Number being set is greaten than 30 characters. This is not allowed. ***\n");fflush(stdout);
				failure =1;
			}
			else
			{
				
				AOM_refresh( NewPartReqObj, TRUE);
				AOM_set_value_string(NewPartReqObj,"t5_NwTmlPtNo",t5NwTmlPtNo1S);
				AOM_save_without_extensions(NewPartReqObj);
				AOM_refresh(NewPartReqObj,FALSE);
			}
		}
	}
	else
	{
		AOM_refresh( NewPartReqObj, TRUE);
		AOM_set_value_string(NewPartReqObj,"t5_NwTmlPtNo",thisPartNumber);
		AOM_save_without_extensions(NewPartReqObj);
		AOM_refresh(NewPartReqObj,FALSE);
	}
	GRM_find_relation_type("T5_NwLHP",&creltypetag);
	if(NewPartReqObj!=NULLTAG && PartLedgerTag!=NULLTAG)
	{
		AOM_refresh( NewPartReqObj, TRUE);
		GRM_create_relation(NewPartReqObj,PartLedgerTag,creltypetag,NULLTAG,&rel_tag);
		GRM_save_relation(rel_tag);
		AOM_save_without_extensions(NewPartReqObj);
		AOM_refresh(NewPartReqObj,FALSE);
	}
	if(failure ==1)
	{
		if(PartLedgerTag)
		{
			AOM_refresh( PartLedgerTag, TRUE);
			AOM_delete(PartLedgerTag);
		}
	}

	return failure;

}

/*
extern DLLAPI int t5_NwPrtAny_Set_post_action (METHOD_message_t * message, va_list args )
{
	int ifail = ITK_ok;

	tag_t  prop = va_arg(args, tag_t );
    //char*  filename = va_arg(args, char* );
	tag_t custom_part_tag= message->object_tag;

	tag_t  userSession = NULLTAG;
	tag_t  property_tag = NULLTAG;
	logical hasBypass=false;
	char *ret;
	char *filename1 = NULL;
	const char ch = '.';

	CALLAPI(CE_current_user_session_tag(&userSession));
	CALLAPI(AOM_ask_value_logical(userSession,"fnd0bypassflag",&hasBypass));

	if(hasBypass==true)
	{
		printf("\nHAS By pass Flag is TRUE") ;fflush(stdout);
		return ifail;
	}
	else
	{
		//printf("\n t5_NwPrtAny_Set_post_action::HAS By pass Flag is FALSE file name is111111-->%s",filename);fflush(stdout);
		//PROP_ask_property_by_name(custom_part_tag,"t5_NwPrtAny",&property_tag);
		if(prop!=NULLTAG)
		{
			PROP_ask_value_string(prop,&filename1);
			printf("\n t5_NwPrtAny_Set_post_action::HAS By pass Flag is FALSE file name is2222222-->%s",filename1);fflush(stdout);
		}
		
		if(strcmp(filename1,"NA")!= 0)
		{	
			ret = strrchr(filename1, ch);
			printf("\nextension is==========>%s\n", ret);fflush(stdout);
			if(ret)
			{
				printf("\nextension is %s\n", ret);fflush(stdout);
			}
			else
			{
				
				ifail=t9NewPartReqCre_Val007;
				EMH_store_error_s1(EMH_severity_error,ifail,"Pls give valid File Name with valid file extension(txt/doc/pdf/xls/ppt/jpeg) !!");
				return ifail;
			}
		}
		if(tc_strcmp(filename1,"NA")==0)
		{
			printf("\n filename1 is==========>%s\n", filename1);fflush(stdout);
			EMH_clear_errors();
			ifail=t9NewPartReqCre_Val006;
			EMH_store_error_s1(EMH_severity_error,ifail, "In File Name NA is not allowed, Pls give valid name with file extension(txt/doc/pdf/xls/ppt/jpeg)!!");
			return ifail;
		}
	}
return ifail;
}
*/


/****************************************************************************
Function:       TML_New_MCC_NODE_Function
Description:    This function is used in WF after while approve from manager login
				to release DML/task/part/dataset.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
int TML_New_MCC_NODE_Function(EPM_action_message_t msg)
{
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;
	tag_t			primary_obj_type_tag		= NULLTAG;
	char			*type_name1					= NULL;
	char*			reqnumber				= NULL;
	char*			NprSubModAdd				= NULL;

	tag_t *attachments = NULLTAG;
	tag_t DMLLcmTag = NULLTAG;
	tag_t NPRMasterTag = NULLTAG;
	tag_t *ReqPartList = NULLTAG;
	tag_t	updatetagprt =  NULLTAG;

	int ModAddctrl_n_found = 0;
	tag_t	ModAddctrlquery	= NULLTAG;
	tag_t	*ModAddCntrlObjs	= NULLTAG;
	char *modinfo01Str	= NULL;
	char *modinfo02Str	= NULL;
	char *modinfo03Str	= NULL;
	char *ErrorMsg	= NULL;
	char *newReqpartType	= NULL;

	char
        *ModAddctrl_qry_entries[1] = {"SYSCD"},
        *ModAddctrl_qry_values[1]	= {"*"};

	

	const char
        *attrs1[1] = {"item_id"},
        *values1[1]	= {"*"};



	EPM_decision_t decision = EPM_go;
	int count,req_tags_found=0;
	int error_code	= ITK_ok;

	EPM_ask_root_task(msg.task,&root_task);
	printf("\nTML_New_MCC_NODE_Function"); fflush(stdout);

	AOM_ask_value_string(msg.task,"object_name",&CurrentTask);
	printf("\nTML_New_MCC_NODE_Function::CurrentTask:%s\n",CurrentTask);fflush(stdout);

	EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments);
	printf("\nTML_New_MCC_NODE_Function::EPM_ask_attachments of :: %d",count);fflush(stdout);

	if(count > 0)
	{
		DMLLcmTag = attachments[0];
		AOM_ask_value_string(DMLLcmTag,"item_id",&reqnumber);
		printf("\n In TML_New_MCC_NODE_Function : reqnumber : %s\n",reqnumber);fflush(stdout);
		values1[0] = reqnumber;
		ITEM_find_items_by_key_attributes(1, attrs1, values1, &req_tags_found, &ReqPartList);
		printf("\n In TML_New_MCC_NODE_Function : req_tags_found : %d\n",req_tags_found);fflush(stdout);
		if(req_tags_found>0)
		{
			NPRMasterTag = ReqPartList[0];
			TCTYPE_ask_object_type(NPRMasterTag,&primary_obj_type_tag);
			TCTYPE_ask_name2(primary_obj_type_tag, &type_name1);
			printf("\nTML_New_MCC_NODE_Function type_name is:%s",type_name1);fflush(stdout);
			if(tc_strcmp(type_name1,"T5_NwPCre")==0 || tc_strcmp(type_name1,"New Part Request")==0)
			{
				AOM_ask_value_string(NPRMasterTag,"t5_PartType",&newReqpartType);
				printf("\nTML_New_MCC_NODE_Function newReqpartTypeDup is:%s",newReqpartType);fflush(stdout);

				if(tc_strcmp(newReqpartType,"Module")==0 || tc_strcmp(newReqpartType,"M")==0 || tc_strcmp(newReqpartType,"IFD Module")==0 || tc_strcmp(newReqpartType,"IM")==0 || tc_strcmp(newReqpartType,"ECU Module")==0 || tc_strcmp(newReqpartType,"EM")==0)
				{
					AOM_ask_value_string(NPRMasterTag,"t5_ModuleAddress",&NprSubModAdd);
					printf("\n TML_New_MCC_NODE_Function NprSubModAdd is:%s",NprSubModAdd);fflush(stdout);

					ModAddctrl_qry_values[0]	= "NewPartReqPartTypeCheckForIFD";
					QRY_find2("ControlObjQry", &ModAddctrlquery);
					QRY_execute(ModAddctrlquery,1, ModAddctrl_qry_entries, ModAddctrl_qry_values, &ModAddctrl_n_found, &ModAddCntrlObjs);
					printf("\n TML_New_MCC_NODE_Function::ModAddctrl_n_found =[%d]",ModAddctrl_n_found);fflush(stdout);
					if(ModAddctrl_n_found>0)
					{
						AOM_ask_value_string(ModAddCntrlObjs[0],"t5_Userinfo1",&modinfo01Str);
						AOM_ask_value_string(ModAddCntrlObjs[0],"t5_Userinfo2",&modinfo02Str);
						AOM_ask_value_string(ModAddCntrlObjs[0],"t5_Userinfo3",&modinfo03Str);
						printf("\nTML_New_MCC_NODE_Function modinfo01Str is:%s",modinfo01Str);fflush(stdout);
						printf("\nTML_New_MCC_NODE_Function modinfo02Str is:%s",modinfo01Str);fflush(stdout);
						printf("\nTML_New_MCC_NODE_Function modinfo03Str is:%s",modinfo01Str);fflush(stdout);
						if(tc_strstr(modinfo01Str,NprSubModAdd)!=NULL || tc_strstr(modinfo02Str,NprSubModAdd)!=NULL || tc_strstr(modinfo03Str,NprSubModAdd)!=NULL)
						{
							printf("\nTML_New_MCC_NODE_Function NprSubModAdd Found is:%s",NprSubModAdd);fflush(stdout);
							if(tc_strcmp(newReqpartType,"IFD Module")==0 || tc_strcmp(newReqpartType,"IM")==0 || tc_strcmp(newReqpartType,"ECU Module")==0 || tc_strcmp(newReqpartType,"EM")==0)
							{
								printf("\nTML_New_MCC_NODE_Function newReqpartType Found is:%s",newReqpartType);fflush(stdout);
								AOM_refresh(DMLLcmTag, TRUE);
								POM_attr_id_of_attr("t5_IsReject", "T5_NwPCreRevision", &updatetagprt);
								POM_set_attr_logical(1, &DMLLcmTag, updatetagprt, false);
								POM_save_instances(1, &DMLLcmTag, false);
								printf("\n Completed::POM_save_instances");fflush(stdout);
								AOM_refresh(DMLLcmTag, FALSE);
							}
							else
							{
								printf("\nTML_New_MCC_NODE_Function newReqpartType not Found is:%s",newReqpartType);fflush(stdout);
								AOM_refresh(DMLLcmTag, TRUE);
								POM_attr_id_of_attr("t5_IsReject", "T5_NwPCreRevision", &updatetagprt);
								POM_set_attr_logical(1, &DMLLcmTag, updatetagprt, false);
								POM_save_instances(1, &DMLLcmTag, false);
								printf("\n Completed::POM_save_instances");fflush(stdout);
								AOM_refresh(DMLLcmTag, FALSE);
							}
						}
						else
						{
							printf("\nTML_New_MCC_NODE_Function NprSubModAdd not Found is:%s",NprSubModAdd);fflush(stdout);
							AOM_refresh(DMLLcmTag, TRUE);
							POM_attr_id_of_attr("t5_IsReject", "T5_NwPCreRevision", &updatetagprt);
							POM_set_attr_logical(1, &DMLLcmTag, updatetagprt, true);
							POM_save_instances(1, &DMLLcmTag, false);
							printf("\n Completed::POM_save_instances");fflush(stdout);
							AOM_refresh(DMLLcmTag, FALSE);
						}
					}
				}
				else
				{
					printf("\nTML_New_MCC_NODE_Function newReqpartType Found is:%s",newReqpartType);fflush(stdout);
					AOM_refresh(DMLLcmTag, TRUE);
					POM_attr_id_of_attr("t5_IsReject", "T5_NwPCreRevision", &updatetagprt);
					POM_set_attr_logical(1, &DMLLcmTag, updatetagprt, false);
					POM_save_instances(1, &DMLLcmTag, false);
					printf("\n Completed::POM_save_instances");fflush(stdout);
					AOM_refresh(DMLLcmTag, FALSE);
				}
			}
		}
	}
	return error_code;
}



/****************************************************************************
Function:       TML_New_SubModule_MCC_Start_Function
Description:    This function is used in WF after while approve from manager login
				to release DML/task/part/dataset.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
int TML_New_SubModule_MCC_Start_Function(EPM_action_message_t msg)
{
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;
	tag_t			primary_obj_type_tag		= NULLTAG;
	char			*type_name1					= NULL;
	char*			reqnumber				= NULL;
	char*			process_Name				= NULL;
	char*			process_type				= NULL;
	char*			processtype				= NULL;
	char*			MCCprocessStDate				= NULL;
	char*			newReqpartType				= NULL;
	char*			newReqModAddress				= NULL;

	int totalprocess = 0;
	int reviewcounter = 0;
	int MCC = 0;
	int process_counter = 0;
	int queryResultCount = 0;
	

	tag_t *attachments = NULLTAG;
	tag_t DMLLcmTag = NULLTAG;
	tag_t NPRMasterTag = NULLTAG;
	tag_t *ReqPartList = NULLTAG;
	tag_t	updateMCCStartDate =  NULLTAG;
	tag_t	updateMCCStatus =  NULLTAG;
	tag_t	*ProcessStageList =  NULLTAG;
	tag_t	ReviewProcessStage =  NULLTAG;
	tag_t	Process_Stage =  NULLTAG;
	tag_t	query =  NULLTAG;
	tag_t	*queryResult =  NULLTAG;
	tag_t	relation_type_any =  NULLTAG;
	tag_t	relation_any =  NULLTAG;

	char
		*qry_entries[1] = {"ID"},
		*qry_values[1]	= {"*"};
	

	

	const char
        *attrs1[1] = {"item_id"},
        *values1[1]	= {"*"};



	EPM_decision_t decision = EPM_go;
	int count,req_tags_found=0;
	int error_code	= ITK_ok;

	EPM_ask_root_task(msg.task,&root_task);
	printf("\n TML_New_SubModule_MCC_Start_Function"); fflush(stdout);

	AOM_ask_value_string(msg.task,"object_name",&CurrentTask);
	printf("\n TML_New_SubModule_MCC_Start_Function::CurrentTask:%s\n",CurrentTask);fflush(stdout);

	EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments);
	printf("\n TML_New_SubModule_MCC_Start_Function::EPM_ask_attachments of :: %d",count);fflush(stdout);

	if(count > 0)
	{
		DMLLcmTag = attachments[0];
		AOM_ask_value_string(DMLLcmTag,"item_id",&reqnumber);
		printf("\n In TML_New_SubModule_MCC_Start_Function : reqnumber : %s\n",reqnumber);fflush(stdout);
		values1[0] = reqnumber;
		ITEM_find_items_by_key_attributes(1, attrs1, values1, &req_tags_found, &ReqPartList);
		printf("\n In TML_New_SubModule_MCC_Start_Function : req_tags_found : %d\n",req_tags_found);fflush(stdout);
		if(req_tags_found>0)
		{
			NPRMasterTag = ReqPartList[0];
			TCTYPE_ask_object_type(NPRMasterTag,&primary_obj_type_tag);
			TCTYPE_ask_name2(primary_obj_type_tag, &type_name1);
			printf("\n TML_New_SubModule_MCC_Start_Function type_name is:%s",type_name1);fflush(stdout);
			if(tc_strcmp(type_name1,"T5_NwPCre")==0 || tc_strcmp(type_name1,"New Part Request")==0)
			{
				AOM_ask_value_tags(DMLLcmTag,"fnd0ActuatedInteractiveTsks",&totalprocess,&ProcessStageList);
				if(totalprocess>0)
				{
					tag_t			*soResult1				= NULLTAG;
					int				TotalReviewTask				= 0;
					for(reviewcounter=0;reviewcounter<totalprocess;reviewcounter++)
					{
						ReviewProcessStage = ProcessStageList[reviewcounter];
						AOM_UIF_ask_value(ReviewProcessStage,"object_type",&processtype);
						if(tc_strcmp(processtype,"Review Task")==0 || tc_strcmp(processtype,"Do Task")==0)
						{
							setAddTAG(&TotalReviewTask,&soResult1,ReviewProcessStage);
						}
					}
					printf("\n TotalReviewTask[%d]\n",TotalReviewTask);fflush(stdout);
					if(TotalReviewTask>0)
					{
						MCC = 0;
						for(process_counter=0;process_counter<TotalReviewTask;process_counter++)
						{
							Process_Stage = soResult1[process_counter];
							AOM_ask_value_string(Process_Stage,"object_name",&process_Name);
							AOM_UIF_ask_value(Process_Stage,"object_type",&process_type);
							printf("\n process_Name[%s]\n",process_Name);fflush(stdout);
							printf("\n process_type[%s]\n",process_type);fflush(stdout);
							if(tc_strcmp(CurrentTask,"MCC Review")==0 && tc_strcmp(process_type,"Review Task")==0)
							{
								MCC++;
								AOM_UIF_ask_value(Process_Stage,"fnd0StartDate",&MCCprocessStDate);
								break;
							}
						}
						if(MCC>0)
						{
							printf("\n MCCprocessStDate[%s]\n",MCCprocessStDate);fflush(stdout);
						}
					}
				}
				
				AOM_refresh(NPRMasterTag, TRUE);

				POM_attr_id_of_attr("t5_MCCStartDate", "T5_NwPCre", &updateMCCStartDate);
				POM_attr_id_of_attr("t5_MCCStatus", "T5_NwPCre", &updateMCCStatus);
				if(tc_strlen(MCCprocessStDate)>0 && MCCprocessStDate!=NULL)
				{
					POM_set_attr_string(1, &NPRMasterTag, updateMCCStartDate, MCCprocessStDate);
				}
				else
				{
					POM_set_attr_string(1, &NPRMasterTag, updateMCCStartDate, "NA");
				}
				
				POM_set_attr_string(1, &NPRMasterTag, updateMCCStatus, "WIP");

				POM_save_instances(1, &NPRMasterTag, false);
				printf("\n Completed::POM_save_instances");fflush(stdout);

				AOM_refresh(NPRMasterTag, FALSE);

				// Add Module Library List Table in NPR Revision...
				AOM_ask_value_string(NPRMasterTag,"t5_PartType",&newReqpartType);
				if(tc_strcmp(newReqpartType,"Module")==0 || tc_strcmp(newReqpartType,"M")==0 || tc_strcmp(newReqpartType,"IFD Module")==0 || tc_strcmp(newReqpartType,"IM")==0 || tc_strcmp(newReqpartType,"ECU Module")==0 || tc_strcmp(newReqpartType,"EM")==0)
				{
					AOM_ask_value_string(NPRMasterTag,"t5_ModuleAddress",&newReqModAddress);
					if(tc_strlen(newReqModAddress)>0)
					{
						char *TempModAdd = NULL;
						TempModAdd = (char *) MEM_alloc( 10 * sizeof(char) );
						TempModAdd= NewPartsubString(newReqModAddress,1,5);
						printf("\n TML_New_SubModule_MCC_Start_Function:TempModAdd=>[%s]",TempModAdd);fflush(stdout);
						
						QRY_find2("SubModuleLibraryDestails", &query);
						if(query!=NULLTAG)
						{
							//qry_values[0] = TempModAdd;
							qry_values[0] = newReqModAddress;
							QRY_execute(query, 1, qry_entries, qry_values, &queryResultCount, &queryResult);
							printf("\n TML_New_SubModule_MCC_Start_Function:queryResultCount=>[%d]",queryResultCount);fflush(stdout);
							if(queryResultCount>0)
							{
								AOM_refresh(NPRMasterTag, TRUE);
								GRM_find_relation_type("IMAN_reference", &relation_type_any);
								GRM_create_relation(NPRMasterTag, queryResult[0], relation_type_any, NULLTAG, &relation_any);
								GRM_save_relation(relation_any);
								AOM_save_without_extensions(NPRMasterTag);
								AOM_refresh(NPRMasterTag, FALSE);
							}
						}
						
					}
				}
			}
		}
	}
	return error_code;
}
/****************************************************************************
Function:       TML_New_SubModule_Create_Function
Description:    This function is used in WF after while Acknowledge from creator login
				to create SubModule Part
Input:          None
Output:         None
Return value:   None
****************************************************************************/
int TML_New_SubModule_Create_Function(EPM_action_message_t msg)
{
	tag_t        tzroottask					=  NULLTAG;
	tag_t		 session					=  NULLTAG;
	tag_t		 *tzattachment				=  NULLTAG;
	tag_t		 query1						=  NULLTAG;
	tag_t		 query2						=  NULLTAG;
	tag_t		 *q_item1					=  NULLTAG;
	tag_t		 *q_item2					=  NULLTAG;
	tag_t		 creltypetag				=  NULLTAG;
	tag_t		 rel_tag					=  NULLTAG;
	tag_t		 PrtLedgerTypeTag			=  NULLTAG;
	tag_t		 PrtLedgerCreInTag			=  NULLTAG;
	tag_t		 prt_tag					=  NULLTAG;
	tag_t		 PartLedgerTag				=  NULLTAG;
	tag_t		 prt_ledger_tag				=  NULLTAG;
	tag_t		 latestitemrev				=  NULLTAG;
	tag_t		 updatedrevtag1			=  NULLTAG;
	tag_t		 updatedrevtag2			=  NULLTAG;
	tag_t		 *npr_tagitems			=  NULLTAG;
	tag_t		 master					=  NULLTAG;
	tag_t		 design_tag				=  NULLTAG;
	tag_t		 *q_designfound				=  NULLTAG;
	tag_t		 *q_partledgeritem				=  NULLTAG;
	tag_t		 partledger_tag				=  NULLTAG;
	tag_t		 updatetag				=  NULLTAG;
	tag_t		 updatetagprt				=  NULLTAG;
	tag_t		 query_ctrl				=  NULLTAG;
	tag_t		 *q_item_ctrl				=  NULLTAG;
	tag_t		 *soResult1					=  NULLTAG;
	tag_t		 *t_item1				=  NULLTAG;
	tag_t		 Designobject				=  NULLTAG;
	tag_t		 DesignPartRevision			=  NULLTAG;
	tag_t		 user_tag			=  NULLTAG;
	tag_t	envelope					= NULLTAG;

	char
        *qry_entries1[2] = {"Name","Type"},
        *qry_values1[2]	= {"*","*"};


	char
        *qry_entries2[2] = {"Item ID","Type"},
        *qry_values2[2]	= {"*","*"};

	char
        *qry_entries_ctrl[1] = {"SYSCD"},
        *qry_values_ctrl[1]	= {"*"};



	char		*UserId					=  NULL;
	char		*newpartreq				=  NULL;
	char		*reqid					=  NULL;
	char		*ProjectNameDupS					=  NULL;
	char		*ProjectNameS					=  NULL;
	char		*t5DesignGroupDupS					=  NULL;
	char		*t5DesignGroupS					=  NULL;
	char		*t5NwDgSbGrpDupS					=  NULL;
	char		*t5NwDgSbGrpS					=  NULL;
	char		*t5NwDgIdDupS					=  NULL;
	char		*t5NwDgIdS					=  NULL;
	char		*PartNumberS					=  NULL;
	char		*t5NwTmlPtNoDup					=  NULL;
	char		*t5NwTmlPtNo					=  NULL;
	char		*thisPartNumber					=  NULL;
	char		*ledgerdocnumber					=  NULL;
	char		*ledgerdoc					=  NULL;
	char		*revid					=  NULL;
	char		*revid1					=  NULL;
	char		*tempId					=  NULL;
	char		*tempId1					=  NULL;
	char		*vstr					=  NULL;
	char		*Partstr					=  NULL;
	char		*tmlpartnumber					=  NULL;
	char		*new_type					=  NULL;
	char		*dgidstr					=  NULL;
	char		*DesigIdstr					=  NULL;
	char		*this_PartNumber					=  NULL;
	char		*design_id					=  NULL;
	char		*desigIdtempId					=  NULL;
	char		*desigIdvstr					=  NULL;
	char		*desigIdPartstr					=  NULL;
	char		*this_PartNumber_partLedger		=  NULL;
	char		*partledger_id		=  NULL;
	char		*prtledgertempId		=  NULL;
	char		*prtledgervstr		=  NULL;
	char		*prtledgerPartstr		=  NULL;
	char		*prtledger_design_vstr		=  NULL;
	char		*prtledger_design_Partstr		=  NULL;
	char		*PartType		=  NULL;
	char		*revPrtType		=  NULL;
	char		*rev_PrtType		=  NULL;
	char *NPRDRStatusDup=NULL;
    char *NPRDRStatus=NULL;
    char *NPRPartCategoryDup=NULL;
    char *NPRPartCategory=NULL;
    char *NPRStartPartProductDup=NULL;
    char *NPRStartPartProduct=NULL;
    char *TmlPartNumberDup=NULL;
    char *TmlPartNumber=NULL;
	char   part_ledger_type[TCTYPE_name_size_c+1];
	char buffer[4000];
	char*syscommand=NULL;
	char*ExePath=NULL;
	char*username=NULL;
	char*userpasswd=NULL;
	char*usergrp=NULL;
	char*SubModuleAddress=NULL;
	char*TEMPrevid=NULL;
	char*TEMP_revid=NULL;
	char*TEMPrtNum=NULL;
	char*NextTEMPrtNum=NULL;
	char*ErrorMsg=NULL;
	char*AggregateGrp=NULL;
	char*AggregateGrpDup=NULL;
	char*AggregatesDup=NULL;
	char*Aggregates=NULL;
	char*ModuleDup=NULL;
	char*Module=NULL;
	char*SubModuleDup=NULL;
	char*SubModule=NULL;
	char*PartDescription=NULL;
	char*TempSubModuleAddress=NULL;
	char*NwKeywrdDes=NULL;
	char*Plateform=NULL;
	char*tempSubModuleName=NULL;
	char*tempSubModule=NULL;
	char*env_subject=NULL;
	char*env_body=NULL;

	int inumarg =0;
	int izntaskattachment =0;
	int n_found1 =0;
	int n_found2 =0;
	int h =0;
	int p =0;
	int len =0;
	int n_entries	= 1;
	int IncrementPartNumber =0;
	int IncrementPartNumber1 =0;
	int FinalIncrement =0;
	int designfound =0;
	int Increment_PartNumber =0;
	int IncrementDgId =0;
	int partledgerfound =0;
	int Increment_PartNumber_ledger =0;
	int Final_Increment =0;
	int IncrementPartNumber_design =0;
	int Increment_DgId =0;
	int IncrementPartNumber_Ledger =0;
	int IncrementDgId_Ledger =0;
	int Increment_PartNumber_PartLedger =0;
	int n_found_ctrl =0;
	int dsgcnt =0;
	int dsg_cnt =0;
	int latestObjindex = -1;

	logical			isFor12Digit = false;
	logical			isFor14Digit = false;
	logical			AlowCreSubMod = false;

	int error_code	= ITK_ok;


	//char *keys[1] = {"creation_date"};
	char *partledgerkeys[1] = {"object_name"};
    int  partledgerorders[1]  ={2};
	int  partledgernum_to_sort = 1;

	char *designkeys[1] = {"item_id"};
    int  designorders[1]  ={2};
	int  designnum_to_sort = 1;

	int  n_tags_found = 0;
	int  totalPart = 0;
	int  total_Part = 0;
	int  prtcnt = 0;
	int  create_flag = 0;

	logical			checkout_designrev = 0;


	const char		*reason_designrev	= "";
	const char		*change_id_designrev	= "";
	const char		*dir_name_designrev = "";
	int				reservation_type_designrev = 2;

	 const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};

	 EPM_decision_t   decision = EPM_go;


	//ITK_set_bypass(true);
	inumarg = TC_number_of_arguments(msg.arguments);
	printf("\n TML_New_SubModule_Create_Function::No of Argument====>[%d]", inumarg);fflush(stdout);

	//POM_ask_session(&session);
	if(POM_ask_session(&session)!=ITK_ok)   PrintErrorStack();
	//POM_get_user_id(&UserId);
	if(POM_get_user_id(&UserId)!=ITK_ok)   PrintErrorStack();
	printf("\n TML_New_SubModule_Create_Function::UserId====>[%s]", UserId);fflush(stdout);
	SA_find_user2 (UserId, &user_tag);
	//MEM_free(UserId);


	if(EPM_ask_root_task(msg.task, &tzroottask)!=ITK_ok)   PrintErrorStack();
	if(EPM_ask_attachments(tzroottask, EPM_target_attachment,&izntaskattachment, &tzattachment)!=ITK_ok)   PrintErrorStack();
	printf("\n TML_New_SubModule_Create_Function::No of Attachements====>[%d]", izntaskattachment);fflush(stdout);

	if (AOM_ask_value_string(tzattachment[0],"object_type",&new_type)!=ITK_ok)   PrintErrorStack();
	printf("\n TML_New_SubModule_Create_Function::new_type====>[%s]", new_type);fflush(stdout);

	if(tc_strcmp(new_type,"T5_NwPCreRevision")==0)
	{

	if (AOM_ask_value_string(tzattachment[0],"item_id",&newpartreq)!=ITK_ok)   PrintErrorStack();
	printf("\n TML_New_SubModule_Create_Function::newpartreq====>[%s]", newpartreq);fflush(stdout);

	// to Item from revision
	if(ITEM_ask_item_of_rev(tzattachment[0],&master)!=ITK_ok) PrintErrorStack();
	AOM_refresh(master, TRUE);
	AOM_refresh(master, FALSE);

	if (AOM_ask_value_string(master,"t5_NwRqNumber",&reqid)!=ITK_ok)   PrintErrorStack();
	printf("\n TML_New_SubModule_Create_Function::reqid====>[%s]", reqid);fflush(stdout);

	if (AOM_ask_value_string(master,"t5_ProjectCode",&ProjectNameDupS)!=ITK_ok)   PrintErrorStack();
	ProjectNameS = strdup(ProjectNameDupS);
	printf("\n TML_New_SubModule_Create_Function::ProjectNameS====>[%s]", ProjectNameS);fflush(stdout);

	if (AOM_ask_value_string(master,"t5_DesignGroup",&t5DesignGroupDupS)!=ITK_ok)   PrintErrorStack();
	t5DesignGroupS = strdup(t5DesignGroupDupS);
	printf("\n TML_New_SubModule_Create_Function::t5DesignGroupS====>[%s]", t5DesignGroupS);fflush(stdout);

	if (AOM_ask_value_string(master,"t5_DesignSubGrp",&t5NwDgSbGrpDupS)!=ITK_ok)   PrintErrorStack();
	t5NwDgSbGrpS = strdup(t5NwDgSbGrpDupS);
	printf("\n TML_New_SubModule_Create_Function::t5NwDgSbGrpS====>[%s]", t5NwDgSbGrpS);fflush(stdout);

	if (AOM_ask_value_string(master,"t5_NwDgId",&t5NwDgIdDupS)!=ITK_ok)   PrintErrorStack();
	t5NwDgIdS = strdup(t5NwDgIdDupS);
	printf("\n TML_New_SubModule_Create_Function::t5NwDgIdS====>[%s]", t5NwDgIdS);fflush(stdout);

	if (AOM_ask_value_string(master,"t5_NwDgId",&t5NwDgIdDupS)!=ITK_ok)   PrintErrorStack();
	t5NwDgIdS = strdup(t5NwDgIdDupS);
	printf("\n TML_New_SubModule_Create_Function::t5NwDgIdS====>[%s]", t5NwDgIdS);fflush(stdout);

	AOM_ask_value_logical(master,"t5_Is12Digit",&isFor12Digit);
	printf("\n TML_New_SubModule_Create_Function::isFor12Digit====>[%d]", isFor12Digit);fflush(stdout);

	AOM_ask_value_logical(master,"t5_Is14Digit",&isFor14Digit);
	printf("\n TML_New_SubModule_Create_Function::isFor14Digit====>[%d]", isFor14Digit);fflush(stdout);

	AOM_ask_value_string(master,"t5_ModuleAddress",&SubModuleAddress);
	printf("\n TML_New_SubModule_Create_Function::SubModuleAddress %s\n",SubModuleAddress);fflush(stdout);

	AOM_ask_value_string(master,"t5_PartType",&PartType);
	printf("\n TML_New_SubModule_Create_Function::PartType====>[%s]", PartType);fflush(stdout);

	AOM_ask_value_logical(master,"t5_AlowCreSubMod",&AlowCreSubMod);
	printf("\n TML_New_SubModule_Create_Function::AlowCreSubMod====>[%d]", AlowCreSubMod);fflush(stdout);

	AOM_ask_value_string(master,"t5_DRStatus",&NPRDRStatus);
	NPRDRStatusDup = strdup(NPRDRStatus);
	printf("\n TML_New_SubModule_Create_Function:: NPRDRStatusDup====>[%s]", NPRDRStatusDup);fflush(stdout);

	AOM_ask_value_string(master,"t5_PartCategory",&NPRPartCategory);
	NPRPartCategoryDup = strdup(NPRPartCategory);
	printf("\n TML_New_SubModule_Create_Function:: NPRPartCategoryDup====>[%s]", NPRPartCategoryDup);fflush(stdout);

	AOM_ask_value_string(master,"t5_StartPartProduct",&NPRStartPartProduct);
	AOM_ask_value_string(master,"t5_NwTmlPtNo",&TmlPartNumber);
	AOM_ask_value_string(master,"t5_Plateform",&Plateform);
	TmlPartNumberDup = strdup(TmlPartNumber);
	NPRStartPartProductDup = strdup(NPRStartPartProduct);
	printf("\n TML_New_SubModule_Create_Function:: NPRStartPartProductDup====>[%s]", NPRStartPartProductDup);fflush(stdout);
	printf("\n TML_New_SubModule_Create_Function:: TmlPartNumberDup====>[%s]", TmlPartNumberDup);fflush(stdout);
	printf("\n TML_New_SubModule_Create_Function:: Plateform====>[%s]", Plateform);fflush(stdout);
	if(tc_strlen(TmlPartNumberDup)==0)
	{
		int ledgercnt = 0;
		tag_t	creltypetag					= NULLTAG;
		tag_t	*PartLedgerattachments		= NULLTAG;
		char	*PartLedgerNumber			= NULL;
		GRM_find_relation_type("T5_NwLHP",&creltypetag);
		GRM_list_secondary_objects_only(tzattachment[0],creltypetag,&ledgercnt,&PartLedgerattachments);
		printf("\n TML_New_SubModule_Create_Function:: ledgercnt====>[%s]", ledgercnt);fflush(stdout);
		if(ledgercnt>0)
		{
			AOM_ask_value_string(PartLedgerattachments[0], "object_name", &PartLedgerNumber);
			printf("\n TML_New_SubModule_Create_Function:: PartLedgerNumber====>[%s]", PartLedgerNumber);fflush(stdout);
			TmlPartNumberDup = strdup(PartLedgerNumber);
			//AOM_lock(master);
			AOM_refresh( master, TRUE);
			AOM_set_value_string(master, "t5_NwTmlPtNo", PartLedgerNumber);
			AOM_save_without_extensions(master);
			//AOM_unlock(master);
			AOM_refresh(master,FALSE);
		}
		else
		{
			env_subject = (char *) MEM_alloc( 300 * sizeof(char) );
			tc_strcpy(env_subject,"SubModule Part Number ");
			tc_strcat(env_subject,TmlPartNumberDup);

			env_body = (char *) MEM_alloc( 500 * sizeof(char) );
			tc_strcpy(env_body,"Blank TML PartNumber[");
			tc_strcat(env_body,TmlPartNumberDup);
			tc_strcat(env_body,"] On New Part Reqiest[");
			tc_strcat(env_body,newpartreq);
			tc_strcat(env_body,"] is assigned,\n Please contact to PLM Team!!");
			MAIL_create_envelope(env_subject, env_body, &envelope);
			if(envelope!=NULLTAG)
			{
				MAIL_initialize_envelope2(envelope, env_subject, env_body);
				if(user_tag != NULLTAG)
				{
					char *Analyst_email_addr= NULL;
					tag_t	Analyst_person_tag = NULLTAG;
					tag_t	*recievers = NULLTAG;
					int countenvelop = 0;
					AOM_ask_value_tag(user_tag,"person",&Analyst_person_tag);
					SA_ask_person_email_address(Analyst_person_tag,&Analyst_email_addr);
					printf("\n Analyst_email_addr %s\n",Analyst_email_addr);fflush(stdout);
					MAIL_add_external_receiver(envelope, MAIL_send_to,Analyst_email_addr);
					MAIL_add_external_receiver(envelope, MAIL_send_cc,"sudhirs1.ttl@tatamotors.com");
					MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers);
					MAIL_send_envelope(envelope);
				}
			}
		}
	}

	AOM_ask_value_string(master,"t5_CategoryName",&NwKeywrdDes);

	AOM_ask_value_string(master,"t5_AggregateGrp",&AggregateGrp);
	AOM_ask_value_string(master,"t5_Aggregates",&AggregatesDup);
	Aggregates = strdup(AggregatesDup);
	AOM_ask_value_string(master,"t5_Module",&ModuleDup);
	Module = strdup(ModuleDup);
	AOM_ask_value_string(master,"t5_SubModule",&SubModuleDup);
	SubModule = strdup(SubModuleDup);
	if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
	{
		//tempSubModule = strtok(SubModuleDup, "-");
		printf("\n 11TML_New_SubModule_Create_Function:: For Module SubModuleDup====>[%s]", SubModuleDup);fflush(stdout);
		//PartDescription = strtok(NULL, "-");
		//PartDescription = tc_strtok(NULL, "");
		int lenght = 0;
		lenght = tc_strlen(SubModuleDup);
		PartDescription = (char *) MEM_alloc( 50 * sizeof(char) );
		PartDescription= NewPartsubString(SubModuleDup,3,lenght-3);
		printf("\n TML_New_SubModule_Create_Function:: For Module PartDescription====>[%s]", PartDescription);fflush(stdout);
	}
	if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
	{
		PartDescription = (char *) MEM_alloc( 50 * sizeof(char) );
		//PartDescription = strdup(NwKeywrdDes);
		tc_strcpy(PartDescription,NwKeywrdDes);
		printf("\n TML_New_SubModule_Create_Function:: For Assy/Cmp PartDescription====>[%s]", PartDescription);fflush(stdout);
	}

	
	printf("\n TML_New_SubModule_Create_Function:: NwKeywrdDes====>[%s]", NwKeywrdDes);fflush(stdout);
	printf("\n TML_New_SubModule_Create_Function:: AggregateGrp====>[%s]", AggregateGrp);fflush(stdout);
	printf("\n TML_New_SubModule_Create_Function:: Aggregates====>[%s]", Aggregates);fflush(stdout);
	printf("\n TML_New_SubModule_Create_Function:: Module====>[%s]", Module);fflush(stdout);
	printf("\n TML_New_SubModule_Create_Function:: SubModule====>[%s]", SubModule);fflush(stdout);

	if(AlowCreSubMod==true || AlowCreSubMod==1)
	{
		tag_t	item_type_tag				= NULLTAG;
		tag_t	item_create_input_tag		= NULLTAG;
		tag_t	Dsg_type_Revtag				= NULLTAG;
		tag_t	object_create_input_revtag	= NULLTAG;
	

		values[0] = TmlPartNumberDup;
		values[1] = "Design";
		ITEM_find_items_by_key_attributes(2, attrs, values, &n_tags_found, &t_item1);
		printf("\n TML_New_SubModule_Create_Function:: n_tags_found==>%d",n_tags_found);fflush(stdout);
		if(n_tags_found>0)
		{
			//error_code=t9NewPartReqCre_Val0045;
			env_subject = (char *) MEM_alloc( 300 * sizeof(char) );
			tc_strcpy(env_subject,"SubModule Part Number ");
			tc_strcat(env_subject,TmlPartNumberDup);

			env_body = (char *) MEM_alloc( 500 * sizeof(char) );
			if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
			{
				tc_strcpy(env_body,"Sub Module Design Part number[");
			}
			if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
			{
				tc_strcpy(env_body,"Design Part number[");
			}
			tc_strcat(env_body,TmlPartNumberDup);
			tc_strcat(env_body,"] which Assigned TML PartNumber[");
			tc_strcat(env_body,TmlPartNumberDup);
			tc_strcat(env_body,"] On New Part Reqiest[");
			tc_strcat(env_body,newpartreq);
			tc_strcat(env_body,"] is available.\nPlease contact to PLM Team!!");
			MAIL_create_envelope(env_subject, env_body, &envelope);
			if(envelope!=NULLTAG)
			{
				MAIL_initialize_envelope2(envelope, env_subject, env_body);
				if(user_tag != NULLTAG)
				{
					char *Analyst_email_addr= NULL;
					tag_t	Analyst_person_tag = NULLTAG;
					tag_t	*recievers = NULLTAG;
					int countenvelop = 0;
					AOM_ask_value_tag(user_tag,"person",&Analyst_person_tag);
					SA_ask_person_email_address(Analyst_person_tag,&Analyst_email_addr);
					printf("\n Analyst_email_addr %s\n",Analyst_email_addr);fflush(stdout);
					MAIL_add_external_receiver(envelope, MAIL_send_to,Analyst_email_addr);
					MAIL_add_external_receiver(envelope, MAIL_send_cc,"sudhirs1.ttl@tatamotors.com");
					MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers);
					MAIL_send_envelope(envelope);
				}
			}
			//EMH_store_error_s1(EMH_severity_error,error_code,ErrorMsg);
			//return error_code;
		}
		else
		{
			
			TCTYPE_find_type("Design", "Design", &item_type_tag);
			TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag);
			TCTYPE_find_type("Design Revision", "Design Revision", &Dsg_type_Revtag);
			TCTYPE_construct_create_input(Dsg_type_Revtag, &object_create_input_revtag);
			//PartDescription = strtok(SubModuleDup, "-");
			printf("\n TML_New_SubModule_Create_Function:: PartDescription==>%s",PartDescription);fflush(stdout);
			if(TmlPartNumberDup!=NULL && tc_strlen(TmlPartNumberDup)>0 && PartDescription!=NULL && tc_strlen(PartDescription)>0 && item_create_input_tag!=NULLTAG && object_create_input_revtag!=NULLTAG)
			{
				AOM_set_value_string(item_create_input_tag,"item_id",TmlPartNumberDup);
				AOM_set_value_string(object_create_input_revtag, "item_revision_id","NR;1");
				AOM_set_value_string(object_create_input_revtag, "t5_ProjectCode",ProjectNameS);
				AOM_set_value_string(object_create_input_revtag, "t5_DesignGrp",t5DesignGroupS);
				AOM_set_value_string(object_create_input_revtag, "t5_PartStatus",NPRDRStatusDup);
				AOM_set_value_string(object_create_input_revtag, "t5_StartPartProduct",NPRStartPartProductDup);
				AOM_set_value_string(object_create_input_revtag, "t5_SpareCriteria",NPRPartCategoryDup);

				if(tc_strlen(SubModuleAddress)>0)
				{
					AOM_set_value_string(item_create_input_tag,"object_name",PartDescription);
					AOM_set_value_string(object_create_input_revtag, "object_desc",PartDescription);
					if(tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"Module")==0)AOM_set_value_string(object_create_input_revtag, "t5_PartType","M");
					if(tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"IFD Module")==0)AOM_set_value_string(object_create_input_revtag, "t5_PartType","IM");
					if(tc_strcmp(PartType,"EM")==0 || tc_strcmp(PartType,"ECU Module")==0)AOM_set_value_string(object_create_input_revtag, "t5_PartType","EM");
					//TempSubModuleAddress = (char *) MEM_alloc( 20 * sizeof(char) );
					//tc_strcpy(TempSubModuleAddress,"M");
					//tc_strcat(TempSubModuleAddress,SubModuleAddress);
					//AOM_set_value_string(object_create_input_revtag, "t5_ModuleAddress",TempSubModuleAddress);
					//AOM_set_value_string(object_create_input_revtag, "t5_AggregateGroup",AggregateGrp);
					//AOM_set_value_string(object_create_input_revtag, "t5_Aggregate",Aggregates);
					//AOM_set_value_string(object_create_input_revtag, "t5_Module_Group",Module);
					//AOM_set_value_string(object_create_input_revtag, "t5_Module",SubModule);
					//AOM_set_value_string(object_create_input_revtag, "t5_ModuleName",PartDescription);
					//AOM_set_value_string(object_create_input_revtag, "t5_Platform",Plateform);
				}
				else
				{
					if(tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Assembly")==0)AOM_set_value_string(object_create_input_revtag, "t5_PartType","A");
					if(tc_strcmp(PartType,"C")==0 || tc_strcmp(PartType,"Component")==0)AOM_set_value_string(object_create_input_revtag, "t5_PartType","C");
					AOM_set_value_string(object_create_input_revtag, "object_desc",NwKeywrdDes);
					AOM_set_value_string(item_create_input_tag,"object_name",NwKeywrdDes);
					//AOM_set_value_string(object_create_input_revtag, "t5_CategoryName",NwKeywrdDes);
				}
				AOM_set_value_tag(item_create_input_tag, "revision",object_create_input_revtag);
				create_flag++;
			}
		}
		printf("\n create_flag=>%d", create_flag);fflush(stdout);
		if(create_flag>0)
		{
			TCTYPE_create_object (item_create_input_tag, &Designobject);
			if(Designobject != NULLTAG)
			{
				AOM_refresh( Designobject, TRUE);
				//AOM_save_without_extensions(Designobject);
				//AOM_unlock(Designobject);
				//AOM_refresh(Designobject,1);
				AOM_set_value_string(Designobject,"item_id",TmlPartNumberDup);
				AOM_save_without_extensions(Designobject);
				//AOM_refresh(Designobject,0);
				AOM_refresh(Designobject,FALSE);

				ITEM_ask_latest_rev(Designobject,&DesignPartRevision);
				if(DesignPartRevision!=NULLTAG)
				{
					AOM_refresh( DesignPartRevision, TRUE);
					if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"EM")==0 || tc_strcmp(PartType,"ECU Module")==0)
					{
						//AOM_refresh(DesignPartRevision,1);
						TempSubModuleAddress = (char *) MEM_alloc( 20 * sizeof(char) );
						tc_strcpy(TempSubModuleAddress,"M");
						tc_strcat(TempSubModuleAddress,SubModuleAddress);
						AOM_set_value_string(DesignPartRevision, "t5_ModuleAddress",TempSubModuleAddress);
						AOM_set_value_string(DesignPartRevision, "t5_AggregateGroup",AggregateGrp);
						AOM_set_value_string(DesignPartRevision, "t5_Aggregate",Aggregates);
						AOM_set_value_string(DesignPartRevision, "t5_Module_Group",Module);
						AOM_set_value_string(DesignPartRevision, "t5_Module",SubModule);
						AOM_set_value_string(DesignPartRevision, "t5_ModuleName",PartDescription);
						AOM_set_value_string(DesignPartRevision, "t5_Platform",Plateform);
						AOM_set_value_string(DesignPartRevision, "t5_ModuleType","PLATFORM");
					}
					if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
					{
						AOM_set_value_string(DesignPartRevision, "t5_CategoryName",NwKeywrdDes);
					}
					AOM_save_without_extensions(DesignPartRevision);
					AOM_refresh(DesignPartRevision,FALSE);
				}

				RES_is_checked_out(DesignPartRevision,&checkout_designrev);
				if (checkout_designrev==0)
				{
					RES_checkout2(DesignPartRevision,reason_designrev,change_id_designrev,dir_name_designrev,reservation_type_designrev);
					printf("\n designrev Checked Out \n");fflush(stdout);
				}

				FL_user_update_newstuff_folder(Designobject);

				env_subject = (char *) MEM_alloc( 300 * sizeof(char) );
				tc_strcpy(env_subject,"SubModule Part Number ");
				tc_strcat(env_subject,TmlPartNumberDup);

				env_body = (char *) MEM_alloc( 500 * sizeof(char) );
			
				//ErrorMsg = (char *) MEM_alloc( 300 * sizeof(char) );
				tc_strcpy(env_body,"Assigned TML PartNumber[");
				tc_strcat(env_body,TmlPartNumberDup);
				tc_strcat(env_body,"] On New Part Reqiest[");
				tc_strcat(env_body,newpartreq);
				if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
				{
					tc_strcat(env_body,"].\nDesign Submodule[");
				}
				if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
				{
					tc_strcat(env_body,"].\nDesign Part[");
				}
				tc_strcat(env_body,TmlPartNumberDup);
				tc_strcat(env_body,"] is created.\nPlease expand Newstuff folder.");
				MAIL_create_envelope(env_subject, env_body, &envelope);
				if(envelope!=NULLTAG)
				{
					MAIL_initialize_envelope2(envelope, env_subject, env_body);
					if(user_tag != NULLTAG)
					{
						char *Analyst_email_addr= NULL;
						tag_t	Analyst_person_tag = NULLTAG;
						tag_t	*recievers = NULLTAG;
						int countenvelop = 0;
						AOM_ask_value_tag(user_tag,"person",&Analyst_person_tag);
						SA_ask_person_email_address(Analyst_person_tag,&Analyst_email_addr);
						printf("\n Analyst_email_addr %s\n",Analyst_email_addr);fflush(stdout);
						MAIL_add_external_receiver(envelope, MAIL_send_to,Analyst_email_addr);
						MAIL_add_external_receiver(envelope, MAIL_send_cc,"sudhirs1.ttl@tatamotors.com");
						MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers);
						MAIL_send_envelope(envelope);
					}
				}
				//error_code=t9NewPartReqCre_Val0046;
				//EMH_store_error_s1(EMH_severity_information,error_code,ErrorMsg);
				//return error_code;
			}
		}
	}
	if(AlowCreSubMod==false || AlowCreSubMod==0)
	{
		//error_code=t9NewPartReqCre_Val0047;
		//ErrorMsg = (char *) MEM_alloc( 300 * sizeof(char) );
		env_subject = (char *) MEM_alloc( 300 * sizeof(char) );
		if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
		{
			tc_strcpy(env_subject,"SubModule Part Number ");
		}
		if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
		{
			tc_strcpy(env_subject,"Design Part Number ");
		}
		
		tc_strcat(env_subject,TmlPartNumberDup);

		env_body = (char *) MEM_alloc( 500 * sizeof(char) );
		tc_strcpy(env_body,"Assigned TML PartNumber[");
		tc_strcat(env_body,TmlPartNumberDup);
		tc_strcat(env_body,"] On New Part Reqiest[");
		tc_strcat(env_body,newpartreq);
		if(tc_strcmp(PartType,"Module")==0 || tc_strcmp(PartType,"M")==0 || tc_strcmp(PartType,"IFD Module")==0 || tc_strcmp(PartType,"IM")==0 || tc_strcmp(PartType,"ECU Module")==0 || tc_strcmp(PartType,"EM")==0)
		{
			tc_strcat(env_body,"] is available,\n But Design SubModule is not creted,Please use below option in menu.\nCV-Engineering->Create->SubModule.");
		}
		if(tc_strcmp(PartType,"Assembly")==0 || tc_strcmp(PartType,"A")==0 || tc_strcmp(PartType,"Component")==0 || tc_strcmp(PartType,"C")==0)
		{
			tc_strcat(env_body,"] is available,\n But Design Part is not creted,Please use below option in menu.\nFile->New->Other...->Design");
		}
		MAIL_create_envelope(env_subject, env_body, &envelope);
		if(envelope!=NULLTAG)
		{
			MAIL_initialize_envelope2(envelope, env_subject, env_body);
			if(user_tag != NULLTAG)
			{
				char *Analyst_email_addr= NULL;
				tag_t	Analyst_person_tag = NULLTAG;
				tag_t	*recievers = NULLTAG;
				int countenvelop = 0;
				AOM_ask_value_tag(user_tag,"person",&Analyst_person_tag);
				SA_ask_person_email_address(Analyst_person_tag,&Analyst_email_addr);
				printf("\n Analyst_email_addr %s\n",Analyst_email_addr);fflush(stdout);
				MAIL_add_external_receiver(envelope, MAIL_send_to,Analyst_email_addr);
				MAIL_add_external_receiver(envelope, MAIL_send_cc,"sudhirs1.ttl@tatamotors.com");
				MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers);
				MAIL_send_envelope(envelope);
			}
		}
		//EMH_store_error_s1(EMH_severity_error,error_code,ErrorMsg);
		//return error_code;
	}
	}


	return error_code;
}

/****************************************************************************
Function:       TML_MCC_SignOff_RejectFunction
Description:    This function is used in WF after while Acknowledge from creator login
				to create SubModule Part
Input:          None
Output:         None
Return value:   None
****************************************************************************/
int TML_MCC_SignOff_RejectFunction(EPM_action_message_t msg)
{
	EPM_decision_t decision = EPM_go;
	//implement your logic
	tag_t user_tag = NULLTAG;
	tag_t tzroottask = NULLTAG;
	tag_t master = NULLTAG;
	tag_t *tzattachment = NULLTAG;
	tag_t updateMCCRejectBy = NULLTAG;
	tag_t updateMCCApproveBy = NULLTAG;
	tag_t updateMCCRejectDate = NULLTAG;
	tag_t updateMCCApproveDate = NULLTAG;
	tag_t updateRejectMCCStatus = NULLTAG;
	tag_t updateMCCRejectCount = NULLTAG;
	tag_t updateMCCRejectComment = NULLTAG;
	tag_t query_ctrl = NULLTAG;
	tag_t *q_item_ctrl = NULLTAG;
	tag_t item_ctrl = NULLTAG;
	tag_t itemctrl = NULLTAG;
	char* username = NULL;
	EPM_signoff_decision_t desc = EPM_no_decision;
	char* comments = NULL;
	char* decisiondate = NULL;
	char* DECISION = NULL;
	char* MCCFinalComment = NULL;
	char* ObsoluteNumber = NULL;
	char* TargetDate = NULL;
	char* MCCReasonApproveReject = NULL;
	char* ERROR_MSG = NULL;
	char* Userinfo1 = NULL;
	char* Userinfo001 = NULL;
	date_t decision_date = NULLDATE;
	int izntaskattachment = 0;
	int n_found_ctrl = 0;
	int count = 0;
	int count1 = 0;
	int commentfound = 0;

	char
        *qry_entries_ctrl[1] = {"SYSCD"},
        *qry_values_ctrl[1]	= {"*"};

	int error_code	= ITK_ok;
	
	POM_get_user(&username,&user_tag);
	printf("\n TML_MCC_SignOff_RejectFunction::Starting for username :%s....\n",username);fflush(stdout);	

	EPM_ask_decision(msg.task,user_tag,&desc,&comments,&decision_date);

	EPM_ask_root_task(msg.task, &tzroottask);
	EPM_ask_attachments(tzroottask, EPM_target_attachment,&izntaskattachment, &tzattachment);
	printf("\n TML_MCC_SignOff_RejectFunction::No of Attachements====>[%d]", izntaskattachment);fflush(stdout);

	ITK_date_to_string(decision_date,&decisiondate);

	if(desc==EPM_reject_decision)
	{
		DECISION = (char*)MEM_alloc(20*sizeof(char));
		tc_strcpy(DECISION,"Reject");
	}
	
	
	printf("\n TML_MCC_SignOff_RejectFunction::DECISION ==> %s\n",DECISION);fflush(stdout);
	printf("\n TML_MCC_SignOff_RejectFunction::comments ==> %s\n",comments);fflush(stdout);
	printf("\n TML_MCC_SignOff_RejectFunction::decisiondate ==> %s\n",decisiondate);fflush(stdout);
	
	ITEM_ask_item_of_rev(tzattachment[0],&master);
	if(master!=NULLTAG)
	{
		if(desc==EPM_reject_decision || tc_strcmp(DECISION,"Reject")==0)
		{
			AOM_refresh(master, TRUE);
			POM_attr_id_of_attr("t5_MCCRejectBy", "T5_NwPCre", &updateMCCRejectBy);
			POM_set_attr_string(1, &master, updateMCCRejectBy, username);

			POM_attr_id_of_attr("t5_MCCApprovedBy", "T5_NwPCre", &updateMCCApproveBy);
			POM_set_attr_string(1, &master, updateMCCApproveBy, "NA");

			POM_attr_id_of_attr("t5_MCCRejectDate", "T5_NwPCre", &updateMCCRejectDate);
			POM_set_attr_string(1, &master, updateMCCRejectDate, decisiondate);

			POM_attr_id_of_attr("t5_MCCApproveDate", "T5_NwPCre", &updateMCCApproveDate);
			POM_set_attr_string(1, &master, updateMCCApproveDate, "NA");

			POM_attr_id_of_attr("t5_MCCStatus", "T5_NwPCre", &updateRejectMCCStatus);
			POM_set_attr_string(1, &master, updateRejectMCCStatus, "Dropped");

			POM_attr_id_of_attr("t5_SignOffCountRaiser", "T5_NwPCre", &updateMCCRejectCount);
			POM_set_attr_string(1, &master, updateMCCRejectCount, "1");

			POM_save_instances(1, &master, false);
			printf("\n TML_MCC_SignOff_RejectFunction::Completed::POM_save_instances");fflush(stdout);
			AOM_refresh(master, FALSE);
		}
	}
	if(tc_strlen(comments)>0 && tc_strcmp(comments,"")!=0)
	{
		if(tc_strcmp(DECISION,"Reject")==0 || desc==EPM_reject_decision)
		{
			qry_values_ctrl[0]	= "MCCRejectComment";
			QRY_find2("ControlObjects", &query_ctrl);
			QRY_execute(query_ctrl, 1, qry_entries_ctrl, qry_values_ctrl, &n_found_ctrl, &q_item_ctrl);
			if(n_found_ctrl>0)
			{
				ERROR_MSG = (char*)MEM_alloc(2000*sizeof(char));
				for(count=0;count<n_found_ctrl;count++)
				{
					item_ctrl = q_item_ctrl[count];
					AOM_ask_value_string(item_ctrl,"t5_Userinfo1",&Userinfo1);
					if(count==0)
					{
						tc_strcpy(ERROR_MSG,"Below Comment only Accepted.\n");
						tc_strcat(ERROR_MSG,Userinfo1);
						tc_strcat(ERROR_MSG,"\n");
					}
					else
					{
						tc_strcat(ERROR_MSG,Userinfo1);
						tc_strcat(ERROR_MSG,"\n");
					}
				}
			}
		}
	}
	if(n_found_ctrl>0)
	{
		for(count1=0;count1<n_found_ctrl;count1++)
		{
			itemctrl = q_item_ctrl[count1];
			AOM_ask_value_string(itemctrl,"t5_Userinfo1",&Userinfo001);
			printf("\n TML_MCC_SignOff_RejectFunction::Userinfo001====>[%s]", Userinfo001);fflush(stdout);

			if(tc_strstr(Userinfo001,comments)!=NULL)
			{
				commentfound=1;
				break;
			}
		}
	}
	printf("\n TML_MCC_SignOff_RejectFunction::commentfound====>[%d]", commentfound);fflush(stdout);
	printf("\n TML_MCC_SignOff_RejectFunction::comments====>[%d]", comments);fflush(stdout);
	

	if(commentfound==1)
	{
		if(master!=NULLTAG)
		{
			if(desc==EPM_reject_decision || tc_strcmp(DECISION,"Reject")==0)
			{
				AOM_refresh(master, TRUE);
				POM_attr_id_of_attr("t5_MCCRejectBy", "T5_NwPCre", &updateMCCRejectBy);
				POM_set_attr_string(1, &master, updateMCCRejectBy, username);

				POM_attr_id_of_attr("t5_MCCApprovedBy", "T5_NwPCre", &updateMCCApproveBy);
				POM_set_attr_string(1, &master, updateMCCApproveBy, "NA");

				POM_attr_id_of_attr("t5_MCCRejectDate", "T5_NwPCre", &updateMCCRejectDate);
				POM_set_attr_string(1, &master, updateMCCRejectDate, decisiondate);

				POM_attr_id_of_attr("t5_MCCApproveDate", "T5_NwPCre", &updateMCCApproveDate);
				POM_set_attr_string(1, &master, updateMCCApproveDate, "NA");

				POM_attr_id_of_attr("t5_MCCStatus", "T5_NwPCre", &updateRejectMCCStatus);
				POM_set_attr_string(1, &master, updateRejectMCCStatus, "Dropped");

				POM_attr_id_of_attr("t5_SignOffCountRaiser", "T5_NwPCre", &updateMCCRejectCount);
				POM_set_attr_string(1, &master, updateMCCRejectCount, "1");

				POM_attr_id_of_attr("t5_MCCReasonApproveReject", "T5_NwPCre", &updateMCCRejectComment);
				POM_set_attr_string(1, &master, updateMCCRejectComment, comments);
				

				POM_save_instances(1, &master, false);
				printf("\n TML_MCC_SignOff_RejectFunction::Completed::POM_save_instances");fflush(stdout);
				AOM_refresh(master, FALSE);
			}
		}
	}

	if(tc_strlen(ERROR_MSG)>0 && commentfound==0 && tc_strcmp(DECISION,"Reject")==0)
	{
		error_code=t9NewPartReqCre_Val0048;
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_error,error_code,ERROR_MSG);
		return error_code;
	}
	
	return error_code;
}


/****************************************************************************
    Function:       tm_New_Part_Reqest_register_action_handlers
    Description:    Entry point for register all Handlers

    Input:

    Output:         None
    Return value:   ifail = 0 on success
	                ifail = Error Base on failure
****************************************************************************/

int tm_New_Part_Reqest_register_action_handlers()
{
	int retcode = ITK_ok;

	if ( retcode == ITK_ok )
	{						
		/*						
		retcode = EPM_register_action_handler (
								"TML_New_Part_Request",
								"TML_New_Part_Request",
								(EPM_action_handler_t)TML_New_Part_Request_function
								);
		*/
		retcode = EPM_register_action_handler (
								"TML_New_Part_Request_Ledger",
								"TML_New_Part_Request_Ledger",
								(EPM_action_handler_t)TML_New_Part_Request_Ledger_function
								);


		retcode = EPM_register_action_handler (
								"TML_PartRequest_Reviewer",
								"TML_PartRequest_Reviewer",
								(EPM_action_handler_t)TML_Assign_NewPartRequest_Reviewer_Fuction
								);

		retcode = EPM_register_action_handler (
								"TML_Module_Reviewer",
								"TML_Module_Reviewer",
								(EPM_action_handler_t)TML_Assign_NewPartRequest_Module_Reviewer_Fuction
								);

		retcode = EPM_register_action_handler (
								"TML_COCPrinciple_Reviewer",
								"TML_COCPrinciple_Reviewer",
								(EPM_action_handler_t)TML_Assign_NewPartRequest_COCPrinciple_Reviewer_Fuction
								);

		retcode = EPM_register_action_handler (
								"TML_HeadEngCOC_Reviewer",
								"TML_HeadEngCOC_Reviewer",
								(EPM_action_handler_t)TML_Assign_NewPartRequest_HeadEngCOC_Reviewer_Fuction
								);

		retcode = EPM_register_action_handler (
								"TML_HOD_Reviewer",
								"TML_HOD_Reviewer",
								(EPM_action_handler_t)TML_Assign_NewPartRequest_HOD_Reviewer_Fuction
								);


		retcode = EPM_register_action_handler (
								"TML_New_MCC_NODE",
								"TML_New_MCC_NODE",
								(EPM_action_handler_t)TML_New_MCC_NODE_Function
								);


		retcode = EPM_register_action_handler (
								"TML_New_SubModule_Create",
								"TML_New_SubModule_Create",
								(EPM_action_handler_t)TML_New_SubModule_Create_Function
								);

		retcode = EPM_register_action_handler (
								"TML_MCC_Start",
								"TML_MCC_Start",
								(EPM_action_handler_t)TML_New_SubModule_MCC_Start_Function
								);

		retcode = EPM_register_action_handler (
								"TML_MCC_SignOff_Reject",
								"TML_MCC_SignOff_Reject",
								(EPM_action_handler_t)TML_MCC_SignOff_RejectFunction
								);
		

		printf("\n tm_New_Part_Reqest_register_action_handlers\n");fflush(stdout);
	}
	return retcode;
}


/****************************************************************************
Function:       TML_New_Part_Reqest_Check_TargetFunction
Description:    This function is used in WF after while complete task assignment
				from designer's login on vehicle release.
Input:          None
Output:         None
Return value:   None
****************************************************************************/

EPM_decision_t TML_New_Part_Reqest_Check_TargetFunction( EPM_rule_message_t msg)
{
	
	int			izntaskattachment	= 0;

	tag_t		tzroottask			= NULLTAG;
	tag_t		partrevtag			= NULLTAG;
	tag_t		*tzattachment		= NULLTAG;
	tag_t  		*ReqPartList 		= NULLTAG;
	tag_t  		*attachments 		= NULLTAG;
	tag_t		relation_type 		= NULLTAG;
	tag_t		datasetTypeTag 		= NULLTAG;
	tag_t		refrelation_type	= NULLTAG;
	tag_t		nprmaster			= NULLTAG;
	tag_t		*refnprchklist		= NULLTAG;
	tag_t		objTypeTag			= NULLTAG;
	int          ifail              = ITK_ok;
	
	int req_tags_found=0;
	int			i			= 0;
	int			cnt			= 0;
	int			k			= 0;
	int			refcnt		= 0;
	int			error		= 0;
	int			chklisterror= 0;
	int			chklistValueerror= 0;
	int			chklistNotAvail= 0;
	int			AssignedPart= 0;
	logical ischkout = 0;
	logical	checkout_checklist = 0;
	
	char		*objType			=  NULL;
	char    *reqnumber = NULL;
	char    *dataset_type_name = NULL;
	char    *type_name = NULL;
	char *checklist_type=NULL;
	char *BaseSubModule=NULL;
	char *BaseVCDesc=NULL;
	char *BaseVCNum=NULL;
	char *Varity=NULL;
	char *NewSubModReqNum=NULL;
	char *VCDesc=NULL;
	char *VCNumber=NULL;
	char *Change=NULL;
	char *SubModDes=NULL;
	char *Requirement=NULL;
	char *CarryOver=NULL;
	char *ReplaceEliminate=NULL;
	char *VarLib=NULL;
	char *AssignedTMLPart=NULL;
	char *newReqpartType=NULL;
	int datasetNamedRefCount = 0;
	tag_t *datasetRefObjectTag = NULLTAG;
	//char  dataset_type_name[TCTYPE_name_size_c+1];

	const char
        *attrs1[1] = {"item_id"},
        *values1[1]	= {"*"};

	EPM_decision_t   decision = EPM_go;

	//ITK_set_bypass(true);
	EPM_ask_root_task(msg.task, &tzroottask);
	EPM_ask_attachments(tzroottask, EPM_target_attachment, &izntaskattachment, &tzattachment );
	for(i=0; i<izntaskattachment;i++)
	{
		tag_t partrevtag = tzattachment[i];
		AOM_ask_value_string(partrevtag,"object_type",&objType);
		printf("\n In TML_New_Part_Reqest_Check_TargetFunction : object_type : %s \n",objType);fflush(stdout);
		TCTYPE_ask_object_type(partrevtag, &objTypeTag);
		TCTYPE_ask_name2( objTypeTag, &type_name);
		printf("\n TML_New_Part_Reqest_Check_TargetFunction::type_name ==> %s\n", type_name);fflush(stdout);
		AOM_ask_value_string(partrevtag,"item_id",&reqnumber);
		printf("\n In TML_New_Part_Reqest_Check_TargetFunction : reqnumber : %s\n",reqnumber);fflush(stdout);
		if(tc_strcmp(type_name,"T5_NwPCreRevision")==0 || tc_strcmp(type_name,"New Part Request Revision")==0)
		{
			chklistNotAvail = 0;
			values1[0] = reqnumber;
			ifail = ITEM_find_item_revs_by_key_attributes(1,attrs1, values1,"NR",&req_tags_found, &ReqPartList);
			printf("\n In TML_New_Part_Reqest_Check_TargetFunction : req_tags_found : %d\n",req_tags_found);fflush(stdout);
			if(req_tags_found>0 || req_tags_found==0)
			{
				GRM_find_relation_type("IMAN_specification",&relation_type);
				GRM_find_relation_type("IMAN_reference",&refrelation_type);
				GRM_list_secondary_objects_only(partrevtag,relation_type,&cnt,&attachments);
				ITEM_ask_item_of_rev(partrevtag,&nprmaster);
				GRM_list_secondary_objects_only(nprmaster,refrelation_type,&refcnt,&refnprchklist);
				printf("\n In TML_New_Part_Reqest_Check_TargetFunction : attachment cnt : %d\n",cnt);fflush(stdout);
				printf("\n In TML_New_Part_Reqest_Check_TargetFunction : attachment refcnt : %d\n",refcnt);fflush(stdout);
				if(cnt>0)
				{
					for(k=0;k<cnt;k++)
					{
						tag_t  filetag = attachments[k];
						RES_is_checked_out(filetag,&ischkout);
						AE_ask_dataset_named_refs(filetag,&datasetNamedRefCount,&datasetRefObjectTag);
						if(TCTYPE_ask_object_type(filetag,&datasetTypeTag)!=ITK_ok) PrintErrorStack();
						if(TCTYPE_ask_name2(datasetTypeTag,&dataset_type_name)!=ITK_ok) PrintErrorStack();
						printf("\n dataset_type_name is ====>[%s]", dataset_type_name);fflush(stdout);
						printf("\n datasetNamedRefCount is ====>[%d]", datasetNamedRefCount);fflush(stdout);
						if(ischkout==1 || datasetNamedRefCount==0)
						{
							error++;
						}
						if(datasetNamedRefCount>0)
						{
							tag_t file_name_tag		= NULLTAG;
							tag_t objTypeTag		= NULLTAG;
							char  *fileextension	= NULL;
							char  *filename			= NULL;
							char  *token			= NULL;
							char  *type_name			= NULL;
							//char  type_name[TCTYPE_name_size_c+1];
							int		f				= 0;
							for(f=0;f<datasetNamedRefCount;f++)
							{
								file_name_tag = datasetRefObjectTag[f];
								if(TCTYPE_ask_object_type(file_name_tag,&objTypeTag)!=ITK_ok) PrintErrorStack();
								if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
								printf("\n File type_name is ====>[%s]", type_name);fflush(stdout);
								AOM_ask_value_string(file_name_tag,"file_ext",&fileextension);
								printf("\n file extension is ====>[%s]", fileextension);fflush(stdout);
								AOM_ask_value_string(file_name_tag,"object_string",&filename);
								printf("\n filename is ====>[%s]", filename);fflush(stdout);
								token = strtok(filename, ".");
								token = strtok(NULL, ".");
								printf("\n token is ====>[%s]", token);fflush(stdout);
								if(strcasecmp(fileextension,token) == 0)
								{
									printf("\n File extension matched %s", token);fflush(stdout);
								}
								else
								{
									printf("\n File extension not matched %s", token);fflush(stdout);
									error++;
								}
								
							}
						}
					}
				}
				if(refcnt>0)
				{
					RES_is_checked_out(refnprchklist[0],&checkout_checklist);
					if(checkout_checklist==1 || checkout_checklist==true)
					{
						chklisterror++;
					}
					// CHECK_LIST
					if(checkout_checklist==0 || checkout_checklist==false)
					{
						AOM_ask_value_string(refnprchklist[0],"object_type",&checklist_type);
						printf("\n **TML_New_Part_Reqest_Check_TargetFunction::type_name = [%s]\n", checklist_type);fflush(stdout);
						if(tc_strcmp(checklist_type,"T5_NPRCheckList")==0 || tc_strcmp(checklist_type,"New Part Request CheckList")==0)
						{
							AOM_ask_value_string(refnprchklist[0],"t5_BaseSubModule",&BaseSubModule);
							AOM_ask_value_string(refnprchklist[0],"t5_BaseVCDesc",&BaseVCDesc);
							AOM_ask_value_string(refnprchklist[0],"t5_BaseVCNum",&BaseVCNum);
							AOM_ask_value_string(refnprchklist[0],"t5_Varity",&Varity);
							AOM_ask_value_string(refnprchklist[0],"t5_NewSubModReqNum",&NewSubModReqNum);
							AOM_ask_value_string(refnprchklist[0],"t5_VCDesc",&VCDesc);
							AOM_ask_value_string(refnprchklist[0],"t5_VCNumber",&VCNumber);
							AOM_ask_value_string(refnprchklist[0],"t5_Change",&Change);
							AOM_ask_value_string(refnprchklist[0],"t5_SubModDes",&SubModDes);
							AOM_ask_value_string(refnprchklist[0],"t5_Requirement",&Requirement);
							AOM_ask_value_string(refnprchklist[0],"t5_CarryOver",&CarryOver);
							AOM_ask_value_string(refnprchklist[0],"t5_ReplaceEliminate",&ReplaceEliminate);
							AOM_ask_value_string(refnprchklist[0],"t5_VarLib",&VarLib);
							printf("\n **TML_New_Part_Reqest_Check_TargetFunction::BaseSubModule = [%s]\n", BaseSubModule);fflush(stdout);
							printf("\n **TML_New_Part_Reqest_Check_TargetFunction::BaseVCDesc = [%s]\n", BaseVCDesc);fflush(stdout);
							printf("\n **TML_New_Part_Reqest_Check_TargetFunction::BaseVCNum = [%s]\n", BaseVCNum);fflush(stdout);
							printf("\n **TML_New_Part_Reqest_Check_TargetFunction::Varity = [%s]\n", Varity);fflush(stdout);
							printf("\n **TML_New_Part_Reqest_Check_TargetFunction::NewSubModReqNum = [%s]\n", NewSubModReqNum);fflush(stdout);
							printf("\n **TML_New_Part_Reqest_Check_TargetFunction::VCDesc = [%s]\n", VCDesc);fflush(stdout);
							printf("\n **TML_New_Part_Reqest_Check_TargetFunction::VCNumber = [%s]\n", VCNumber);fflush(stdout);
							printf("\n **TML_New_Part_Reqest_Check_TargetFunction::Change = [%s]\n", Change);fflush(stdout);
							printf("\n **TML_New_Part_Reqest_Check_TargetFunction::SubModDes = [%s]\n", SubModDes);fflush(stdout);
							printf("\n **TML_New_Part_Reqest_Check_TargetFunction::Requirement = [%s]\n", Requirement);fflush(stdout);
							printf("\n **TML_New_Part_Reqest_Check_TargetFunction::CarryOver = [%s]\n", CarryOver);fflush(stdout);
							printf("\n **TML_New_Part_Reqest_Check_TargetFunction::ReplaceEliminate = [%s]\n", ReplaceEliminate);fflush(stdout);
							printf("\n **TML_New_Part_Reqest_Check_TargetFunction::VarLib = [%s]\n", VarLib);fflush(stdout);
							if(tc_strlen(BaseSubModule)==0
								|| tc_strlen(BaseVCDesc)==0
								|| tc_strlen(BaseVCNum)==0
								|| tc_strlen(Varity)==0
								|| tc_strlen(NewSubModReqNum)==0
								|| tc_strlen(VCDesc)==0
								|| tc_strlen(VCNumber)==0
								|| tc_strlen(Change)==0
								|| tc_strlen(SubModDes)==0
								|| tc_strlen(Requirement)==0
								|| tc_strlen(CarryOver)==0
								|| tc_strlen(ReplaceEliminate)==0
								|| tc_strlen(VarLib)==0)
							{
								chklistValueerror++;								
							}
						}
					}
					
				}
				if(refcnt==0)
				{
					AOM_ask_value_string(nprmaster,"t5_PartType",&newReqpartType);
					if(tc_strcmp(newReqpartType,"Module")==0 || tc_strcmp(newReqpartType,"M")==0 || tc_strcmp(newReqpartType,"IFD Module")==0 || tc_strcmp(newReqpartType,"IM")==0 || tc_strcmp(newReqpartType,"ECU Module")==0 || tc_strcmp(newReqpartType,"EM")==0)
					{
						chklistNotAvail++;
					}					
				}
				AOM_ask_value_string(nprmaster,"t5_NwTmlPtNo",&AssignedTMLPart);
				printf("\n In TML_New_Part_Reqest_Check_TargetFunction : AssignedTMLPart : %s\n",AssignedTMLPart);fflush(stdout);
				if(tc_strlen(AssignedTMLPart)>0)
				{
					AssignedPart++;
				}
				MEM_free(datasetRefObjectTag);
			}
		}
		
	}
	printf("\n In TML_New_Part_Reqest_Check_TargetFunction : attachment error : %d\n",error);fflush(stdout);
	printf("\n In TML_New_Part_Reqest_Check_TargetFunction : chklist chklisterror : %d\n",chklisterror);fflush(stdout);
	printf("\n In TML_New_Part_Reqest_Check_TargetFunction : chklist chklistValueerror : %d\n",chklistValueerror);fflush(stdout);
	printf("\n In TML_New_Part_Reqest_Check_TargetFunction : chklist chklistNotAvail : %d\n",chklistNotAvail);fflush(stdout);
	printf("\n In TML_New_Part_Reqest_Check_TargetFunction : chklist AssignedPart : %d\n",AssignedPart);fflush(stdout);
	if(error>0)
	{
		ifail=t9NewPartReqCre_Val0030;
		EMH_store_error_s1(EMH_severity_error,ifail,"Attaching Files Should have Physical File,Please add files and check In to dataset!!...");
		decision = EPM_nogo;
	}

	if(chklisterror>0)
	{
		ifail=t9NewPartReqCre_Val0010;
		EMH_store_error_s1(EMH_severity_error,ifail,"New part request CheckList is checkout, please update property on checklist ...");
		decision = EPM_nogo;
	}

	if(chklistValueerror>0)
	{
		ifail=t9NewPartReqCre_Val0026;
		EMH_store_error_s1(EMH_severity_error,ifail,"Please Fill All Fileds in New Part Request CheckList.It is mandatory to fill all properties on Check List!!");
		decision = EPM_nogo;
	}

	if(chklistNotAvail>0)
	{
		ifail=t9NewPartReqCre_Val0027;
		EMH_store_error_s1(EMH_severity_error,ifail,"New Part Request CheckList is not available.It is mandatory to attach with NPR's Reference!");
		decision = EPM_nogo;
	}

	if(AssignedPart>0)
	{
		ifail=t9NewPartReqCre_Val0028;
		EMH_store_error_s1(EMH_severity_error,ifail,"TML Part Number is assigned to selected New Part Request,It can not be resubmit, Please take New NPR");
		decision = EPM_nogo;
	}
	
	MEM_free(tzattachment);
	MEM_free(ReqPartList);
	MEM_free(attachments);
	
	return decision;


}


/****************************************************************************
Function:       Reviewer_SignOffCheck
Description:    This function is used in WF after while complete task assignment
				from designer's login on vehicle release.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
extern EPM_decision_t DLLAPI Reviewer_SignOffCheck(EPM_rule_message_t msg)
{
	tag_t root_task=NULLTAG;
	EPM_decision_t decision = EPM_go;
	tag_t *attachments = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t task_Prty_rel_type = NULLTAG;
	tag_t *TaskCRB = NULLTAG;
	tag_t TskCRBTag = NULLTAG;
	tag_t ObjTypTskCRB = NULLTAG;
	tag_t master = NULLTAG;
	tag_t  currGrpMember = NULLTAG;
	tag_t  query = NULLTAG;
	tag_t  *q_CtrlSet = NULLTAG;

	char*	CurrentTask				=NULL;
	char*	parent_name				=NULL;
	char*	NewPrtreqDesignGrp		=NULL;
	char*	NewPrtreqPrtType		=NULL;
	char*	DocNum					=NULL;
	char*	type_name				=NULL;
	char*	Tsk_Prty_typ			=NULL;
	char*	group_AssGroup_Role		=NULL;
	char*	group_AssGroup_RoleDup	=NULL;
	char*	RequiredRolName			=NULL;
	char *Session_group = NULL;
	char *Session_Role = NULL;
	char *Session_User = NULL;
	char *ERROR_MESSAGE = NULL;
	char *GROUP_DETAIS_USER = NULL;
	char *info01 = NULL;
	char *info03 = NULL;
	char *info04 = NULL;
	char *info05 = NULL;
	char *info06 = NULL;
	char *info07 = NULL;
	char *info08 = NULL;

	char *ModuleRvrGroup_Role = NULL;
	char *ModuleRvrGroup_User = NULL;
	

	char *COCPGroup_Role = NULL;
	char *COCPGroup_User = NULL;

	char *COCHGroup_Role = NULL;
	char *COCHGroup_User = NULL;

	char *HeadEngGroup_Role = NULL;
	char *HeadEngGroup_User = NULL;

	char *MCCGroup_Role = NULL;
	char *MCCGroup_User = NULL;

	char *AckGroup_Role = NULL;
	char *AckGroup_User = NULL;



	//char  	type_name[TCTYPE_name_size_c+1];
	//char  	Tsk_Prty_typ[TCTYPE_name_size_c+1];

	int	count,i	=	0;
	int	TskPrtycount,jkk	=	0;
	
	int	ModuleReviewerflag	=	0;
	int	CoCPrincipleReviewerflag	=	0;
	int	CoCHeadReviewerflag	=	0;
	int	HeadOfEngReviewerflag	=	0;
	int ProposedReviewerflag	=	0;
	int	NwRaisedByflag	=	0;
	int	n_Ctrlfound	=	0;

	char
					*qry_entries_ctrl[1] = {"SYSCD"},
					*qry_values_ctrl[1]	= {"*"};

	int ifail= ITK_ok;

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n Reviewer_SignOffCheck:Root task found");fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n Reviewer_SignOffCheck:CurrentTask:%s\n",CurrentTask);fflush(stdout);

	CALLAPI(AOM_ask_value_string(root_task,"object_name",&parent_name));
	printf("\n Reviewer_SignOffCheck:Parent Name:%s\n",parent_name);fflush(stdout);
	
	//RequiredRolName = (char *)MEM_alloc(250);
	Session_group = (char *)MEM_alloc(250);
	Session_Role = (char *)MEM_alloc(250);
	Session_User = (char *)MEM_alloc(250);
	ERROR_MESSAGE = (char *)MEM_alloc(500);
	//ERROR_MESSAGE_USR = (char *)MEM_alloc(100);
	
	SA_ask_current_groupmember(&currGrpMember);
	CALLAPI(AOM_ask_value_string(currGrpMember,"object_name",&group_AssGroup_Role));
	printf("\n Reviewer_SignOffCheck ::group_AssGroup_Role====>[%s]", group_AssGroup_Role);fflush(stdout);
	group_AssGroup_RoleDup = strdup(group_AssGroup_Role);
	tc_strcpy(Session_group, "");
	tc_strcpy(Session_Role, "");
	Session_group = strtok(group_AssGroup_Role,"/");
	Session_Role = strtok(NULL,"/");
	Session_User = strtok(NULL,"/");

	tc_strcpy(ERROR_MESSAGE,"Your Login is not a member of Assigned Reviewer.\nPlease login with assigned Reviewer with same Group and Role and then sign off.");
	//tc_strcat(ERROR_MESSAGE,group_AssGroup_RoleDup);
	//tc_strcat(ERROR_MESSAGE,"] is not matched with Assign Reviewer[");
	
	printf("\n Reviewer_SignOffCheck::Session_group is  ::Session_group====>[%s]", Session_group);fflush(stdout);
	printf("\n Reviewer_SignOffCheck::Session_Role is  ::Session_Role====>[%s]", Session_Role);fflush(stdout);
	printf("\n Reviewer_SignOffCheck::Session_User is  ::Session_User====>[%s]", Session_User);fflush(stdout);

	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
	printf("\n Reviewer_SignOffCheck: EPM_ask_attachments of :: %d\n",count);fflush(stdout);
	if(count>0)
	{
		for(i=0;i<count;i++)
		{
			CALLAPI(TCTYPE_ask_object_type (attachments[i], &objTypeTag));
			CALLAPI(TCTYPE_ask_name2( objTypeTag, &type_name));
			printf("\n Reviewer_SignOffCheck::type_name ==> %s\n", type_name);fflush(stdout);			
			if(tc_strcmp(type_name,"T5_NwPCreRevision")==0 || tc_strcmp(type_name,"New Part Request Revision")==0)
			{
				AOM_ask_value_string(attachments[i],"item_id",&DocNum);
				printf("\n Reviewer_SignOffCheck::DocNum ==> %s\n", DocNum);fflush(stdout);
				ITEM_ask_item_of_rev(attachments[i],&master);
				AOM_ask_value_string(master,"t5_DesignGroup",&NewPrtreqDesignGrp);
				printf("\n Reviewer_SignOffCheck::NewPrtreqDesignGrp ==> %s\n", NewPrtreqDesignGrp);fflush(stdout);
				AOM_ask_value_string(master,"t5_PartType",&NewPrtreqPrtType);
				printf("\n Reviewer_SignOffCheck::NewPrtreqPrtType ==> %s\n", NewPrtreqPrtType);fflush(stdout);
				CALLAPI(GRM_find_relation_type("HasParticipant", &task_Prty_rel_type));				
				if (task_Prty_rel_type!=NULLTAG)
				{
					CALLAPI(GRM_list_secondary_objects_only(attachments[i],task_Prty_rel_type,&TskPrtycount,&TaskCRB));
					printf("\n Reviewer_SignOffCheck: TaskCRB count: %d",TskPrtycount);fflush(stdout);
					if(TskPrtycount>0)
					{
						ModuleReviewerflag=0;
						CoCPrincipleReviewerflag=0;
						CoCHeadReviewerflag=0;
						HeadOfEngReviewerflag=0;
						ProposedReviewerflag=0;
						NwRaisedByflag=0;
						for(jkk=0;jkk<TskPrtycount;jkk++)
						{
							TskCRBTag = TaskCRB[jkk];
							if(TCTYPE_ask_object_type(TskCRBTag,&ObjTypTskCRB));
							if(TCTYPE_ask_name2(ObjTypTskCRB,&Tsk_Prty_typ));
							
							printf("\n Reviewer_SignOffCheck::Tsk_Prty_typ: %s",Tsk_Prty_typ);fflush(stdout);
														
							if (tc_strcmp(Tsk_Prty_typ,"T5_Modeule_Reviewer")==0 && tc_strstr(CurrentTask,"Module Review")!=NULL)
							{
								if(GROUP_DETAIS_USER!=NULL)
								{
									GROUP_DETAIS_USER = NULL;
								}
								GROUP_DETAIS_USER = (char *)MEM_alloc(100);

								if(RequiredRolName!=NULL)
								{
									RequiredRolName = NULL;
								}
								RequiredRolName = (char *)MEM_alloc(250);

								CALLAPI(AOM_ask_value_string(TskCRBTag,"fnd0AssigneeGroupRole",&ModuleRvrGroup_Role));
								CALLAPI(AOM_ask_value_string(TskCRBTag,"object_string",&ModuleRvrGroup_User));
								printf("\n Reviewer_SignOffCheck::ModuleRvrGroup_Role: %s",ModuleRvrGroup_Role);fflush(stdout);
								printf("\n TR_CHK_Grp_Role_User::ModuleRvrGroup_User: %s",ModuleRvrGroup_User);fflush(stdout);
								tc_strcpy(GROUP_DETAIS_USER,ModuleRvrGroup_Role);
								tc_strcat(GROUP_DETAIS_USER,"/");
								tc_strcat(GROUP_DETAIS_USER,ModuleRvrGroup_User);
								printf("\n Reviewer_SignOffCheck::GROUP_DETAIS_USER: %s",GROUP_DETAIS_USER);fflush(stdout);
								printf("\n Reviewer_SignOffCheck::Session_User111: %s",Session_User);fflush(stdout);
								printf("\n Reviewer_SignOffCheck::group_AssGroup_RoleDup: %s",group_AssGroup_RoleDup);fflush(stdout);
								tc_strcpy(RequiredRolName,NewPrtreqDesignGrp);
								tc_strcat(RequiredRolName,"_New_Module");
								printf("\n Reviewer_SignOffCheck::RequiredRolName: %s",RequiredRolName);fflush(stdout);
								if(tc_strstr(Session_User,ModuleRvrGroup_User)!=NULL)
								{
									if(tc_strstr(group_AssGroup_RoleDup,ModuleRvrGroup_Role)!=NULL && tc_strstr(group_AssGroup_RoleDup,RequiredRolName)!=NULL)
									{
										ModuleReviewerflag=1;
										break;
									}
									else
									{
										ModuleReviewerflag=0;
									}
								}
								else
								{
									ModuleReviewerflag=0;
								}
							}
							if (tc_strcmp(Tsk_Prty_typ,"T5_COCPrinciple_Reviewer")==0 && tc_strstr(CurrentTask,"COC Principal Engineer Review")!=NULL)
							{
								if(GROUP_DETAIS_USER!=NULL)
								{
									GROUP_DETAIS_USER = NULL;
								}
								GROUP_DETAIS_USER = (char *)MEM_alloc(100);

								if(RequiredRolName!=NULL)
								{
									RequiredRolName = NULL;
								}
								RequiredRolName = (char *)MEM_alloc(250);

								CALLAPI(AOM_ask_value_string(TskCRBTag,"fnd0AssigneeGroupRole",&COCPGroup_Role));
								CALLAPI(AOM_ask_value_string(TskCRBTag,"object_string",&COCPGroup_User));
								printf("\n Reviewer_SignOffCheck::COCPGroup_Role: %s",COCPGroup_Role);fflush(stdout);
								printf("\n TR_CHK_Grp_Role_User::COCPGroup_User: %s",COCPGroup_User);fflush(stdout);
								tc_strcpy(GROUP_DETAIS_USER,COCPGroup_Role);
								tc_strcat(GROUP_DETAIS_USER,"/");
								tc_strcat(GROUP_DETAIS_USER,COCPGroup_User);
								printf("\n Reviewer_SignOffCheck::GROUP_DETAIS_USER: %s",GROUP_DETAIS_USER);fflush(stdout);
								printf("\n Reviewer_SignOffCheck::Session_User111: %s",Session_User);fflush(stdout);
								printf("\n Reviewer_SignOffCheck::group_AssGroup_RoleDup: %s",group_AssGroup_RoleDup);fflush(stdout);
								tc_strcpy(RequiredRolName,NewPrtreqDesignGrp);
								tc_strcat(RequiredRolName,"_New_COCPrinciple");
								printf("\n Reviewer_SignOffCheck::RequiredRolName: %s",RequiredRolName);fflush(stdout);
								if(tc_strstr(Session_User,COCPGroup_User)!=NULL)
								{
									if(tc_strstr(group_AssGroup_RoleDup,COCPGroup_Role)!=NULL && tc_strstr(group_AssGroup_RoleDup,RequiredRolName)!=NULL)
									{
										CoCPrincipleReviewerflag=1;
										break;
									}
									else
									{
										CoCPrincipleReviewerflag=0;
									}
								}
								else
								{
									CoCPrincipleReviewerflag=0;
								}
							}
							if (tc_strcmp(Tsk_Prty_typ,"T5_COCHead_Reviewer")==0 && tc_strstr(CurrentTask,"COC Head Plantform Engineer Review")!=NULL)
							{
								if(GROUP_DETAIS_USER!=NULL)
								{
									GROUP_DETAIS_USER = NULL;
								}
								GROUP_DETAIS_USER = (char *)MEM_alloc(100);

								if(RequiredRolName!=NULL)
								{
									RequiredRolName = NULL;
								}
								RequiredRolName = (char *)MEM_alloc(250);

								CALLAPI(AOM_ask_value_string(TskCRBTag,"fnd0AssigneeGroupRole",&COCHGroup_Role));
								CALLAPI(AOM_ask_value_string(TskCRBTag,"object_string",&COCHGroup_User));
								printf("\n Reviewer_SignOffCheck::COCHGroup_Role: %s",COCHGroup_Role);fflush(stdout);
								printf("\n TR_CHK_Grp_Role_User::COCHGroup_User: %s",COCHGroup_User);fflush(stdout);
								tc_strcpy(GROUP_DETAIS_USER,COCHGroup_Role);
								tc_strcat(GROUP_DETAIS_USER,"/");
								tc_strcat(GROUP_DETAIS_USER,COCHGroup_User);
								printf("\n Reviewer_SignOffCheck::GROUP_DETAIS_USER: %s",GROUP_DETAIS_USER);fflush(stdout);
								printf("\n Reviewer_SignOffCheck::Session_User111: %s",Session_User);fflush(stdout);
								printf("\n Reviewer_SignOffCheck::group_AssGroup_RoleDup: %s",group_AssGroup_RoleDup);fflush(stdout);
								tc_strcpy(RequiredRolName,NewPrtreqDesignGrp);
								tc_strcat(RequiredRolName,"_New_COCHead");
								printf("\n Reviewer_SignOffCheck::RequiredRolName: %s",RequiredRolName);fflush(stdout);
								if(tc_strstr(Session_User,COCHGroup_User)!=NULL)
								{
									if(tc_strstr(group_AssGroup_RoleDup,COCHGroup_Role)!=NULL && tc_strstr(group_AssGroup_RoleDup,RequiredRolName)!=NULL)
									{
										CoCHeadReviewerflag=1;
										break;
									}
									else
									{
										CoCHeadReviewerflag=0;
									}
								}
								else
								{
									CoCHeadReviewerflag=0;
								}
							}
							if (tc_strcmp(Tsk_Prty_typ,"T5_HeadOfEngg")==0 && tc_strstr(CurrentTask,"Head of the Engineering Review")!=NULL)
							{
								if(GROUP_DETAIS_USER!=NULL)
								{
									GROUP_DETAIS_USER = NULL;
								}
								GROUP_DETAIS_USER = (char *)MEM_alloc(100);

								if(RequiredRolName!=NULL)
								{
									RequiredRolName = NULL;
								}
								RequiredRolName = (char *)MEM_alloc(250);

								CALLAPI(AOM_ask_value_string(TskCRBTag,"fnd0AssigneeGroupRole",&HeadEngGroup_Role));
								CALLAPI(AOM_ask_value_string(TskCRBTag,"object_string",&HeadEngGroup_User));
								printf("\n Reviewer_SignOffCheck::HeadEngGroup_Role: %s",HeadEngGroup_Role);fflush(stdout);
								printf("\n TR_CHK_Grp_Role_User::HeadEngGroup_User: %s",HeadEngGroup_User);fflush(stdout);
								tc_strcpy(GROUP_DETAIS_USER,HeadEngGroup_Role);
								tc_strcat(GROUP_DETAIS_USER,"/");
								tc_strcat(GROUP_DETAIS_USER,HeadEngGroup_User);
								printf("\n Reviewer_SignOffCheck::GROUP_DETAIS_USER: %s",GROUP_DETAIS_USER);fflush(stdout);
								printf("\n Reviewer_SignOffCheck::Session_User111: %s",Session_User);fflush(stdout);
								printf("\n Reviewer_SignOffCheck::group_AssGroup_RoleDup: %s",group_AssGroup_RoleDup);fflush(stdout);
								tc_strcpy(RequiredRolName,NewPrtreqDesignGrp);
								tc_strcat(RequiredRolName,"_New_COCHead");
								printf("\n Reviewer_SignOffCheck::RequiredRolName: %s",RequiredRolName);fflush(stdout);
								if(tc_strstr(Session_User,HeadEngGroup_User)!=NULL)
								{
									if(tc_strstr(group_AssGroup_RoleDup,HeadEngGroup_Role)!=NULL && tc_strstr(group_AssGroup_RoleDup,RequiredRolName)!=NULL && tc_strcmp(NewPrtreqDesignGrp,"31")==0)
									{
										HeadOfEngReviewerflag=1;
										break;
									}
									else
									{
										HeadOfEngReviewerflag=0;
									}
								}
								else
								{
									HeadOfEngReviewerflag=0;
								}
							}
							if (tc_strcmp(Tsk_Prty_typ,"ProposedReviewer")==0 && tc_strstr(CurrentTask,"MCC Review")!=NULL)
							{
								if(GROUP_DETAIS_USER!=NULL)
								{
									GROUP_DETAIS_USER = NULL;
								}
								GROUP_DETAIS_USER = (char *)MEM_alloc(100);

								if(RequiredRolName!=NULL)
								{
									RequiredRolName = NULL;
								}
								RequiredRolName = (char *)MEM_alloc(250);

								CALLAPI(AOM_ask_value_string(TskCRBTag,"fnd0AssigneeGroupRole",&MCCGroup_Role));
								CALLAPI(AOM_ask_value_string(TskCRBTag,"object_string",&MCCGroup_User));
								printf("\n Reviewer_SignOffCheck::MCCGroup_Role: %s",MCCGroup_Role);fflush(stdout);
								printf("\n TR_CHK_Grp_Role_User::MCCGroup_User: %s",MCCGroup_User);fflush(stdout);
								tc_strcpy(GROUP_DETAIS_USER,MCCGroup_Role);
								tc_strcat(GROUP_DETAIS_USER,"/");
								tc_strcat(GROUP_DETAIS_USER,MCCGroup_User);
								printf("\n Reviewer_SignOffCheck::GROUP_DETAIS_USER: %s",GROUP_DETAIS_USER);fflush(stdout);
								printf("\n Reviewer_SignOffCheck::Session_User111: %s",Session_User);fflush(stdout);
								printf("\n Reviewer_SignOffCheck::group_AssGroup_RoleDup: %s",group_AssGroup_RoleDup);fflush(stdout);
								tc_strcpy(RequiredRolName,"MCCReviewer");
								printf("\n Reviewer_SignOffCheck::RequiredRolName: %s",RequiredRolName);fflush(stdout);
								if(tc_strstr(Session_User,MCCGroup_User)!=NULL)
								{
									if(tc_strstr(group_AssGroup_RoleDup,MCCGroup_Role)!=NULL && tc_strstr(group_AssGroup_RoleDup,RequiredRolName)!=NULL)
									{
										ProposedReviewerflag=1;
										break;
									}
									else
									{
										ProposedReviewerflag=0;
									}
								}
								else
								{
									ProposedReviewerflag=0;
								}
							}
							if (tc_strcmp(Tsk_Prty_typ,"T5_NwRaisedBy")==0 && tc_strstr(CurrentTask,"Acknowledge Assignment")!=NULL)
							{
								if(GROUP_DETAIS_USER!=NULL)
								{
									GROUP_DETAIS_USER = NULL;
								}
								GROUP_DETAIS_USER = (char *)MEM_alloc(100);

								CALLAPI(AOM_ask_value_string(TskCRBTag,"fnd0AssigneeGroupRole",&AckGroup_Role));
								CALLAPI(AOM_ask_value_string(TskCRBTag,"object_string",&AckGroup_User));
								printf("\n Reviewer_SignOffCheck::AckGroup_Role: %s",AckGroup_Role);fflush(stdout);
								printf("\n TR_CHK_Grp_Role_User::AckGroup_User: %s",AckGroup_User);fflush(stdout);
								tc_strcpy(GROUP_DETAIS_USER,MCCGroup_Role);
								tc_strcat(GROUP_DETAIS_USER,"/");
								tc_strcat(GROUP_DETAIS_USER,AckGroup_User);
								printf("\n Reviewer_SignOffCheck::GROUP_DETAIS_USER: %s",GROUP_DETAIS_USER);fflush(stdout);
								printf("\n Reviewer_SignOffCheck::Session_User111: %s",Session_User);fflush(stdout);
								printf("\n Reviewer_SignOffCheck::group_AssGroup_RoleDup: %s",group_AssGroup_RoleDup);fflush(stdout);
								if(tc_strstr(Session_User,AckGroup_User)!=NULL)
								{
									if(tc_strstr(group_AssGroup_RoleDup,AckGroup_Role)!=NULL)
									{
										NwRaisedByflag=1;
										break;
									}
									else
									{
										NwRaisedByflag=0;
									}
								}
								else
								{
									NwRaisedByflag=0;
								}
								
							}
						}
					}
				}
				printf("\n Reviewer_SignOffCheck: ModuleReviewerflag of :: %d\n",ModuleReviewerflag);fflush(stdout);
				printf("\n Reviewer_SignOffCheck: CoCPrincipleReviewerflag of :: %d\n",CoCPrincipleReviewerflag);fflush(stdout);
				printf("\n Reviewer_SignOffCheck: CoCHeadReviewerflag of :: %d\n",CoCHeadReviewerflag);fflush(stdout);
				printf("\n Reviewer_SignOffCheck: HeadOfEngReviewerflag of :: %d\n",HeadOfEngReviewerflag);fflush(stdout);
				printf("\n Reviewer_SignOffCheck: ProposedReviewerflag of :: %d\n",ProposedReviewerflag);fflush(stdout);
				printf("\n Reviewer_SignOffCheck: NwRaisedByflag of :: %d\n",NwRaisedByflag);fflush(stdout);
				printf("\n Reviewer_SignOffCheck: GROUP_DETAIS_USER of :: %s\n",GROUP_DETAIS_USER);fflush(stdout);
				
				//if(GROUP_DETAIS_USER!=NULL && tc_strlen(GROUP_DETAIS_USER)>0)tc_strcat(ERROR_MESSAGE,GROUP_DETAIS_USER);
				//tc_strcat(ERROR_MESSAGE,"].\nPlease login with assigned person and sigoff approve.");
				printf("\n Reviewer_SignOffCheck: ERROR_MESSAGE of :: %s\n",ERROR_MESSAGE);fflush(stdout);
				
				QRY_find2("Control Objects...", &query);
				if(query!=NULLTAG)
				{
					qry_values_ctrl[0] = "NPRSignOffCheck";
					QRY_execute(query, 1, qry_entries_ctrl, qry_values_ctrl, &n_Ctrlfound, &q_CtrlSet);
					printf("\n Reviewer_SignOffCheck: n_Ctrlfound of :: %d\n",n_Ctrlfound);fflush(stdout);
					AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo1",&info01);
					printf("\n Reviewer_SignOffCheck: info01 of :: %s\n",info01);fflush(stdout);

					AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo3",&info03);
					printf("\n Reviewer_SignOffCheck: info03 of :: %s\n",info03);fflush(stdout);

					AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo4",&info04);
					printf("\n Reviewer_SignOffCheck: info04 of :: %s\n",info04);fflush(stdout);

					AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo5",&info05);
					printf("\n Reviewer_SignOffCheck: info05 of :: %s\n",info05);fflush(stdout);

					AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo6",&info06);
					printf("\n Reviewer_SignOffCheck: info06 of :: %s\n",info06);fflush(stdout);

					AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo7",&info07);
					printf("\n Reviewer_SignOffCheck: info07 of :: %s\n",info07);fflush(stdout);

					AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo8",&info08);
					printf("\n Reviewer_SignOffCheck: info08 of :: %s\n",info08);fflush(stdout);

				}

				if(tc_strstr(info01,"NPRSignOffCheck")!=NULL && n_Ctrlfound>0)
				{
					if(ModuleReviewerflag==0 && tc_strstr(CurrentTask,"Module Review")!=NULL)
					{
						if(tc_strcmp(type_name,"T5_NwPCreRevision")==0 && tc_strstr(info03,"ModuleReview")!=NULL)
						{
							EMH_clear_errors();
							ifail=t9NewPartReqCre_Val0015;
							EMH_store_error_s1(EMH_severity_error,ifail,ERROR_MESSAGE);
							decision = EPM_nogo;
							return decision;
						}
						else
						{
							decision = EPM_go;
						}
					}
					if(CoCPrincipleReviewerflag==0 && tc_strstr(CurrentTask,"COC Principal Engineer Review")!=NULL)
					{
						if(tc_strcmp(type_name,"T5_NwPCreRevision")==0 && tc_strstr(info04,"COCPrincipal")!=NULL)
						{
							EMH_clear_errors();
							ifail=t9NewPartReqCre_Val0015;
							EMH_store_error_s1(EMH_severity_error,ifail,ERROR_MESSAGE);
							decision = EPM_nogo;
							return decision;
						}
						else
						{
							decision = EPM_go;
						}
					}
					if(CoCHeadReviewerflag==0 && tc_strstr(CurrentTask,"COC Head Plantform Engineer Review")!=NULL)
					{
						if(tc_strcmp(type_name,"T5_NwPCreRevision")==0 && tc_strstr(info05,"COCHead")!=NULL)
						{
							EMH_clear_errors();
							ifail=t9NewPartReqCre_Val0015;
							EMH_store_error_s1(EMH_severity_error,ifail,ERROR_MESSAGE);
							decision = EPM_nogo;
							return decision;
						}
						else
						{
							decision = EPM_go;
						}
					}
					if(HeadOfEngReviewerflag==0 && tc_strstr(CurrentTask,"Head of the Engineering Review")!=NULL)
					{
						if(tc_strcmp(type_name,"T5_NwPCreRevision")==0 && tc_strstr(info06,"HeadEngineering")!=NULL)
						{
							EMH_clear_errors();
							ifail=t9NewPartReqCre_Val0015;
							EMH_store_error_s1(EMH_severity_error,ifail,ERROR_MESSAGE);
							decision = EPM_nogo;
							return decision;
						}
						else
						{
							decision = EPM_go;
						}
					}
					if(ProposedReviewerflag==0 && tc_strstr(CurrentTask,"MCC Review")!=NULL)
					{
						if(tc_strcmp(type_name,"T5_NwPCreRevision")==0 && tc_strstr(info07,"MCCReview")!=NULL)
						{
							EMH_clear_errors();
							ifail=t9NewPartReqCre_Val0015;
							EMH_store_error_s1(EMH_severity_error,ifail,ERROR_MESSAGE);
							decision = EPM_nogo;
							return decision;
						}
						else
						{
							decision = EPM_go;
						}
					}
					if(NwRaisedByflag==0 && tc_strstr(CurrentTask,"Acknowledge Assignment")!=NULL)
					{
						if(tc_strcmp(type_name,"T5_NwPCreRevision")==0 && tc_strstr(info08,"Acknowledge")!=NULL)
						{
							EMH_clear_errors();
							ifail=t9NewPartReqCre_Val0015;
							EMH_store_error_s1(EMH_severity_error,ifail,ERROR_MESSAGE);
							decision = EPM_nogo;
							return decision;
						}
						else
						{
							decision = EPM_go;
						}
					}
				}
				else
				{
					decision = EPM_go;
				}
			}
		}
	}
	

	//decision = EPM_go;
	return decision;
}

/****************************************************************************
Function:       New_TML_Raiser_SignOffFn
Description:    This function is used in WF after while complete task assignment
				from designer's login on vehicle release.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
EPM_decision_t New_TML_Raiser_SignOffFn( EPM_rule_message_t msg)
{
	EPM_decision_t decision = EPM_go;
	int ifail = ITK_ok;
	tag_t tzroottask=NULLTAG;
	tag_t *tzattachment = NULLTAG;
	tag_t master = NULLTAG;
	tag_t query = NULLTAG;
	tag_t *q_CtrlSet = NULLTAG;

	char* new_type = NULL;
	char* SignOffCountRaiser = NULL;
	char* MCCStatus = NULL;
	char* nprnum = NULL;
	char* info02 = NULL;
	char* ERROR_MSG = NULL;

	char
					*qry_entries_ctrl[1] = {"SYSCD"},
					*qry_values_ctrl[1]	= {"*"};

	int izntaskattachment = 0;
	int n_Ctrlfound = 0;

	EPM_ask_root_task(msg.task, &tzroottask);
	EPM_ask_attachments(tzroottask, EPM_target_attachment,&izntaskattachment, &tzattachment);
	printf("\n New_TML_Raiser_SignOffFn::No of Attachements====>[%d]", izntaskattachment);fflush(stdout);

	if(izntaskattachment>0)
	{

		AOM_ask_value_string(tzattachment[0],"object_type",&new_type);
		printf("\n New_TML_Raiser_SignOffFn::new_type====>[%s]", new_type);fflush(stdout);

		ITEM_ask_item_of_rev(tzattachment[0],&master);
	}
	if(master!=NULLTAG)
	{
		AOM_ask_value_string(master,"item_id",&nprnum);
		printf("\n New_TML_Raiser_SignOffFn::nprnum====>[%s]", nprnum);fflush(stdout);
		AOM_ask_value_string(master,"t5_SignOffCountRaiser",&SignOffCountRaiser);
		AOM_ask_value_string(master,"t5_MCCStatus",&MCCStatus);
		printf("\n New_TML_Raiser_SignOffFn::SignOffCountRaiser====>[%s]", SignOffCountRaiser);fflush(stdout);
		printf("\n New_TML_Raiser_SignOffFn::MCCStatus====>[%s]", MCCStatus);fflush(stdout);
		QRY_find2("Control Objects...", &query);
		if(query!=NULLTAG)
		{
			qry_values_ctrl[0] = "NPRSignOffCheck";
			QRY_execute(query, 1, qry_entries_ctrl, qry_values_ctrl, &n_Ctrlfound, &q_CtrlSet);
			printf("\n New_TML_Raiser_SignOffFn: n_Ctrlfound of :: %d\n",n_Ctrlfound);fflush(stdout);
			AOM_ask_value_string(q_CtrlSet[0],"t5_Userinfo2",&info02);
			printf("\n New_TML_Raiser_SignOffFn: info02 of :: %s\n",info02);fflush(stdout);
		}
		if(tc_strcmp(MCCStatus,"Dropped")==0 && tc_strcmp(SignOffCountRaiser,"1")==0 && tc_strstr(info02,"RaiserCount")!=NULL)
		{
			ERROR_MSG = (char*)MEM_alloc(2000*sizeof(char));
			tc_strcpy(ERROR_MSG,"You Can not Sign Off Complete.\n");
			tc_strcat(ERROR_MSG,"Because New part Request[");
			tc_strcat(ERROR_MSG,nprnum);
			tc_strcat(ERROR_MSG,"]is Rejected by MCC Reviewers.Please Review with MCC Team!");
			ifail=t9NewPartReqCre_Val0021;
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ifail,ERROR_MSG);
			decision = EPM_nogo;
			return decision;
		}
		else
		{
			decision = EPM_go;
		}
	}
return decision;
}
/****************************************************************************
Function:       New_PartReq_CheckSignOffCommentFn
Description:    This function is used in WF after while complete task assignment
				from designer's login on vehicle release.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
EPM_decision_t New_PartReq_CheckSignOffCommentFn( EPM_rule_message_t msg)
{
	EPM_decision_t decision = EPM_go;
	int ifail = ITK_ok;
	//implement your logic
	tag_t user_tag = NULLTAG;
	char* username = NULL;
	EPM_signoff_decision_t desc = EPM_no_decision;
	char* comments = NULL;
	char* new_type = NULL;
	char* newpartreq = NULL;
	char* Userinfo1 = NULL;
	char* Userinfo2 = NULL;
	char* Userinfo3 = NULL;
	char* Userinfo4 = NULL;
	char* Userinfo5 = NULL;
	char* Userinfo6 = NULL;
	char* Userinfo7 = NULL;
	char* Userinfo8 = NULL;
	char* Userinfo9 = NULL;
	char* ERROR_MSG = NULL;
	char* DECISION = NULL;
	char* MCCFinalComment = NULL;
	char* ObsoluteNumber = NULL;
	char* TargetDate = NULL;
	char* MCCReasonApproveReject = NULL;
	char* decisiondate = NULL;
	date_t decision_date = NULLDATE;
	tag_t tzroottask=NULLTAG;
	tag_t *tzattachment = NULLTAG;
	tag_t master = NULLTAG;
	tag_t query_ctrl = NULLTAG;
	tag_t *q_item_ctrl = NULLTAG;
	tag_t item_ctrl = NULLTAG;
	tag_t MCCApproveReject = NULLTAG;
	tag_t updateMCCRejectBy = NULLTAG;
	tag_t updateMCCApproveBy = NULLTAG;
	tag_t MCCapproveRejectComment = NULLTAG;
	tag_t updateMCCRejectDate = NULLTAG;
	tag_t updateMCCApproveDate = NULLTAG;
	tag_t updateApproveMCCStatus = NULLTAG;
	tag_t updateRejectMCCStatus = NULLTAG;
	tag_t updateMCCCompleteDate = NULLTAG;
	tag_t updateMCCRejectCount = NULLTAG;
	int izntaskattachment = 0;
	int n_found_ctrl = 0;
	int count = 0;
	int commentfound = 0;

	char
        *qry_entries_ctrl[1] = {"SYSCD"},
        *qry_values_ctrl[1]	= {"*"};
	
	POM_get_user(&username,&user_tag);
	printf("\n New_PartReq_CheckSignOffCommentFn::Starting for username :%s....\n",username);fflush(stdout);	

	EPM_ask_decision(msg.task,user_tag,&desc,&comments,&decision_date);
	printf("\n New_PartReq_CheckSignOffCommentFn::comments ==> %s\n",comments);fflush(stdout);

	EPM_ask_root_task(msg.task, &tzroottask);
	EPM_ask_attachments(tzroottask, EPM_target_attachment,&izntaskattachment, &tzattachment);
	printf("\n New_PartReq_CheckSignOffCommentFn::No of Attachements====>[%d]", izntaskattachment);fflush(stdout);

	if(izntaskattachment>0)
	{
		AOM_ask_value_string(tzattachment[0],"object_type",&new_type);
		printf("\n New_PartReq_CheckSignOffCommentFn::new_type====>[%s]", new_type);fflush(stdout);
		
		AOM_ask_value_string(tzattachment[0],"item_id",&newpartreq);
		printf("\n New_PartReq_CheckSignOffCommentFn::newpartreq====>[%s]", newpartreq);fflush(stdout);

		ITK_date_to_string(decision_date,&decisiondate);
		if(desc==EPM_approve_decision)
		{
			DECISION = (char*)MEM_alloc(20*sizeof(char));
			tc_strcpy(DECISION,"Approved");
		}
		if(desc==EPM_reject_decision)
		{
			DECISION = (char*)MEM_alloc(20*sizeof(char));
			tc_strcpy(DECISION,"Reject");
		}

		printf("\n New_PartReq_CheckSignOffCommentFn::DECISION====>[%s]", DECISION);fflush(stdout);

		ITEM_ask_item_of_rev(tzattachment[0],&master);
	}
	if(master!=NULLTAG)
	{
		if(desc==EPM_approve_decision || tc_strcmp(DECISION,"Approved")==0 || desc==EPM_reject_decision || tc_strcmp(DECISION,"Reject")==0)
		{
			AOM_ask_value_string(master,"t5_MCCFinalComment",&MCCFinalComment);
			printf("\n New_PartReq_CheckSignOffCommentFn::MCCFinalComment====>[%s]", MCCFinalComment);fflush(stdout);

			AOM_ask_value_string(master,"t5_ObsoluteNumber",&ObsoluteNumber);
			printf("\n New_PartReq_CheckSignOffCommentFn::ObsoluteNumber====>[%s]", ObsoluteNumber);fflush(stdout);

			AOM_ask_value_string(master,"t5_TargetDate",&TargetDate);
			printf("\n New_PartReq_CheckSignOffCommentFn::TargetDate====>[%s]", TargetDate);fflush(stdout);

			AOM_ask_value_string(master,"t5_MCCReasonApproveReject",&MCCReasonApproveReject);
			printf("\n New_PartReq_CheckSignOffCommentFn::MCCReasonApproveReject====>[%s]", MCCReasonApproveReject);fflush(stdout);
			if(desc==EPM_reject_decision || tc_strcmp(DECISION,"Reject")==0)
			{
				AOM_refresh(master, TRUE);
				POM_attr_id_of_attr("t5_SignOffCountRaiser", "T5_NwPCre", &updateMCCRejectCount);
				POM_set_attr_string(1, &master, updateMCCRejectCount, "1");
				POM_save_instances(1, &master, false);
				printf("\n New_PartReq_CheckSignOffCommentFn::Completed::POM_save_instances");fflush(stdout);
				AOM_refresh(master, FALSE);
			}

			if(tc_strlen(MCCFinalComment)==0 || tc_strlen(ObsoluteNumber)==0 || tc_strlen(TargetDate)==0 || tc_strlen(MCCReasonApproveReject)==0)
			{
				ifail=t9NewPartReqCre_Val0020;
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ifail,"Please Update Remark For Analysis.\nSubmodule number to be made obsolete.\nTarget date for making submodule obsolete.\nCV-Engineering->Update->Update New Part Request");
				decision = EPM_nogo;
				return decision;
			}
		}
	}
	
	if(comments == NULL)
	{
		
		char* buff = NULL;
		ifail=t9NewPartReqCre_Val0016;
		buff = (char*)MEM_alloc(200*sizeof(char));
		sprintf(buff, "Sign off Comment is mandatory. Kindly enter comments before sign off");
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_error,ifail,buff);
		decision = EPM_nogo;
		if(buff)MEM_free(buff);
		return decision; 						
	}
	else
	{
		if(tc_strcmp(comments,"")==0)
		{
			char* buff = NULL;
			ifail=t9NewPartReqCre_Val0016;
			buff = (char*)MEM_alloc(200*sizeof(char));
			sprintf(buff, "Sign off Comment is blank. Kindly enter comments before sign off");
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ifail,buff);
			decision = EPM_nogo;
			if(buff)MEM_free(buff);
			return decision; 						
		}
		if(tc_strlen(comments)>0 && tc_strcmp(comments,"")!=0)
		{
			commentfound = 0;
			if(tc_strcmp(DECISION,"Approved")==0 || desc==EPM_approve_decision)
			{
				qry_values_ctrl[0]	= "MCCApproveComment";
				QRY_find2("ControlObjects", &query_ctrl);
				QRY_execute(query_ctrl, 1, qry_entries_ctrl, qry_values_ctrl, &n_found_ctrl, &q_item_ctrl);
				if(n_found_ctrl>0)
				{
					ERROR_MSG = (char*)MEM_alloc(2000*sizeof(char));
					for(count=0;count<n_found_ctrl;count++)
					{
						item_ctrl = q_item_ctrl[count];
						AOM_ask_value_string(item_ctrl,"t5_Userinfo1",&Userinfo1);
						if(count==0)
						{
							tc_strcpy(ERROR_MSG,"Below Comment only Accepted.\n");
							tc_strcat(ERROR_MSG,Userinfo1);
							tc_strcat(ERROR_MSG,"\n");
						}
						else
						{
							tc_strcat(ERROR_MSG,Userinfo1);
							tc_strcat(ERROR_MSG,"\n");
						}
					}
				}
			}

			if(tc_strcmp(DECISION,"Reject")==0 || desc==EPM_reject_decision)
			{
				qry_values_ctrl[0]	= "MCCRejectComment";
				QRY_find2("ControlObjects", &query_ctrl);
				QRY_execute(query_ctrl, 1, qry_entries_ctrl, qry_values_ctrl, &n_found_ctrl, &q_item_ctrl);
				if(n_found_ctrl>0)
				{
					ERROR_MSG = (char*)MEM_alloc(2000*sizeof(char));
					for(count=0;count<n_found_ctrl;count++)
					{
						item_ctrl = q_item_ctrl[count];
						AOM_ask_value_string(item_ctrl,"t5_Userinfo1",&Userinfo1);
						if(count==0)
						{
							tc_strcpy(ERROR_MSG,"Below Comment only Accepted.\n");
							tc_strcat(ERROR_MSG,Userinfo1);
							tc_strcat(ERROR_MSG,"\n");
						}
						else
						{
							tc_strcat(ERROR_MSG,Userinfo1);
							tc_strcat(ERROR_MSG,"\n");
						}
					}
				}
			}
			
			if(n_found_ctrl>0)
			{
				for(count=0;count<n_found_ctrl;count++)
				{
					item_ctrl = q_item_ctrl[count];
					AOM_ask_value_string(item_ctrl,"t5_Userinfo1",&Userinfo1);
					printf("\n New_PartReq_CheckSignOffCommentFn::Userinfo1====>[%s]", Userinfo1);fflush(stdout);

					if(tc_strstr(Userinfo1,comments)!=NULL)
					{
						commentfound=1;
						break;
					}
				}
			}
			printf("\n New_PartReq_CheckSignOffCommentFn::commentfound====>[%d]", commentfound);fflush(stdout);
			if(commentfound==0)
			{
				if(master!=NULLTAG)
				{
					AOM_refresh(master, TRUE);

					POM_attr_id_of_attr("t5_MCCApproveReject", "T5_NwPCre", &MCCApproveReject);
					POM_set_attr_string(1, &master, MCCApproveReject, DECISION);

					POM_attr_id_of_attr("t5_MCCapproveRejectComment", "T5_NwPCre", &MCCapproveRejectComment);
					POM_set_attr_string(1, &master, MCCapproveRejectComment, comments);

					if(desc==EPM_approve_decision || tc_strcmp(DECISION,"Approved")==0)
					{
						POM_attr_id_of_attr("t5_MCCApprovedBy", "T5_NwPCre", &updateMCCApproveBy);
						POM_set_attr_string(1, &master, updateMCCApproveBy, username);

						POM_attr_id_of_attr("t5_MCCRejectBy", "T5_NwPCre", &updateMCCRejectBy);
						POM_set_attr_string(1, &master, updateMCCRejectBy, "NA");

						POM_attr_id_of_attr("t5_MCCApproveDate", "T5_NwPCre", &updateMCCApproveDate);
						POM_set_attr_string(1, &master, updateMCCApproveDate, decisiondate);

						POM_attr_id_of_attr("t5_MCCRejectDate", "T5_NwPCre", &updateMCCRejectDate);
						POM_set_attr_string(1, &master, updateMCCRejectDate, "NA");

						POM_attr_id_of_attr("t5_MCCStatus", "T5_NwPCre", &updateApproveMCCStatus);
						POM_set_attr_string(1, &master, updateApproveMCCStatus, "Aggreed");

						POM_attr_id_of_attr("t5_MCCCompleteDate", "T5_NwPCre", &updateMCCCompleteDate);
						POM_set_attr_string(1, &master, updateMCCCompleteDate, decisiondate);

						POM_attr_id_of_attr("t5_SignOffCountRaiser", "T5_NwPCre", &updateMCCRejectCount);
						POM_set_attr_string(1, &master, updateMCCRejectCount, "0");
					}
					if(desc==EPM_reject_decision || tc_strcmp(DECISION,"Reject")==0)
					{
						POM_attr_id_of_attr("t5_MCCRejectBy", "T5_NwPCre", &updateMCCRejectBy);
						POM_set_attr_string(1, &master, updateMCCRejectBy, username);

						POM_attr_id_of_attr("t5_MCCApprovedBy", "T5_NwPCre", &updateMCCApproveBy);
						POM_set_attr_string(1, &master, updateMCCApproveBy, "NA");

						POM_attr_id_of_attr("t5_MCCRejectDate", "T5_NwPCre", &updateMCCRejectDate);
						POM_set_attr_string(1, &master, updateMCCRejectDate, decisiondate);

						POM_attr_id_of_attr("t5_MCCApproveDate", "T5_NwPCre", &updateMCCApproveDate);
						POM_set_attr_string(1, &master, updateMCCApproveDate, "NA");

						POM_attr_id_of_attr("t5_MCCStatus", "T5_NwPCre", &updateRejectMCCStatus);
						POM_set_attr_string(1, &master, updateRejectMCCStatus, "Dropped");

						POM_attr_id_of_attr("t5_SignOffCountRaiser", "T5_NwPCre", &updateMCCRejectCount);
						POM_set_attr_string(1, &master, updateMCCRejectCount, "1");
					}

					POM_save_instances(1, &master, false);
					printf("\n New_PartReq_CheckSignOffCommentFn::Completed::POM_save_instances");fflush(stdout);
					AOM_refresh(master, FALSE);
				}
				if(tc_strlen(ERROR_MSG)>0)
				{
					ifail=t9NewPartReqCre_Val0017;
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ifail,ERROR_MSG);
					decision = EPM_nogo;
					return decision;
				}
			}
			if(commentfound==1)
			{
				if(master!=NULLTAG)
				{
					AOM_refresh(master, TRUE);

					POM_attr_id_of_attr("t5_MCCApproveReject", "T5_NwPCre", &MCCApproveReject);
					POM_set_attr_string(1, &master, MCCApproveReject, DECISION);

					POM_attr_id_of_attr("t5_MCCapproveRejectComment", "T5_NwPCre", &MCCapproveRejectComment);
					POM_set_attr_string(1, &master, MCCapproveRejectComment, comments);

					if(desc==EPM_approve_decision || tc_strcmp(DECISION,"Approved")==0)
					{
						POM_attr_id_of_attr("t5_MCCApprovedBy", "T5_NwPCre", &updateMCCApproveBy);
						POM_set_attr_string(1, &master, updateMCCApproveBy, username);

						POM_attr_id_of_attr("t5_MCCRejectBy", "T5_NwPCre", &updateMCCRejectBy);
						POM_set_attr_string(1, &master, updateMCCRejectBy, "NA");

						POM_attr_id_of_attr("t5_MCCApproveDate", "T5_NwPCre", &updateMCCApproveDate);
						POM_set_attr_string(1, &master, updateMCCApproveDate, decisiondate);

						POM_attr_id_of_attr("t5_MCCRejectDate", "T5_NwPCre", &updateMCCRejectDate);
						POM_set_attr_string(1, &master, updateMCCRejectDate, "NA");

						POM_attr_id_of_attr("t5_MCCStatus", "T5_NwPCre", &updateApproveMCCStatus);
						POM_set_attr_string(1, &master, updateApproveMCCStatus, "Aggreed");

						POM_attr_id_of_attr("t5_MCCCompleteDate", "T5_NwPCre", &updateMCCCompleteDate);
						POM_set_attr_string(1, &master, updateMCCCompleteDate, decisiondate);

						POM_attr_id_of_attr("t5_SignOffCountRaiser", "T5_NwPCre", &updateMCCRejectCount);
						POM_set_attr_string(1, &master, updateMCCRejectCount, "0");
					}
					if(desc==EPM_reject_decision || tc_strcmp(DECISION,"Reject")==0)
					{
						POM_attr_id_of_attr("t5_MCCRejectBy", "T5_NwPCre", &updateMCCRejectBy);
						POM_set_attr_string(1, &master, updateMCCRejectBy, username);

						POM_attr_id_of_attr("t5_MCCApprovedBy", "T5_NwPCre", &updateMCCApproveBy);
						POM_set_attr_string(1, &master, updateMCCApproveBy, "NA");

						POM_attr_id_of_attr("t5_MCCRejectDate", "T5_NwPCre", &updateMCCRejectDate);
						POM_set_attr_string(1, &master, updateMCCRejectDate, decisiondate);

						POM_attr_id_of_attr("t5_MCCApproveDate", "T5_NwPCre", &updateMCCApproveDate);
						POM_set_attr_string(1, &master, updateMCCApproveDate, "NA");

						POM_attr_id_of_attr("t5_MCCStatus", "T5_NwPCre", &updateRejectMCCStatus);
						POM_set_attr_string(1, &master, updateRejectMCCStatus, "Dropped");

						POM_attr_id_of_attr("t5_SignOffCountRaiser", "T5_NwPCre", &updateMCCRejectCount);
						POM_set_attr_string(1, &master, updateMCCRejectCount, "1");
					}

					POM_save_instances(1, &master, false);
					printf("\n New_PartReq_CheckSignOffCommentFn::Completed::POM_save_instances");fflush(stdout);
					AOM_refresh(master, FALSE);
				}
				decision = EPM_go;
			}
		}
	}	
	
	return decision;
}
/****************************************************************************
Function:       New_PartReq_assign_manager_teamreviewer
Description:    This function is used in WF after while complete task assignment
				from designer's login on vehicle release.
Input:          None
Output:         None
Return value:   None
****************************************************************************/
extern EPM_decision_t DLLAPI New_PartReq_assign_manager_teamreviewer(EPM_rule_message_t msg)
{
	tag_t root_task=NULLTAG;
	EPM_decision_t decision = EPM_go;
	tag_t *attachments = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t task_Prty_rel_type = NULLTAG;
	tag_t *TaskCRB = NULLTAG;
	tag_t TskCRBTag = NULLTAG;
	tag_t ObjTypTskCRB = NULLTAG;
	tag_t master = NULLTAG;

	char*	CurrentTask				=NULL;
	char*	parent_name				=NULL;
	char*	NewPrtreqDesignGrp				=NULL;
	char*	NewPrtreqPrtType				=NULL;
	char*	DocNum				=NULL;
	char*	type_name				=NULL;
	char*	Tsk_Prty_typ				=NULL;

	//char  	type_name[TCTYPE_name_size_c+1];
	//char  	Tsk_Prty_typ[TCTYPE_name_size_c+1];

	int	count,i	=	0;
	int	TskPrtycount,jkk	=	0;
	
	int	ModuleReviewerflag	=	0;
	int	CoCPrincipleReviewerflag	=	0;
	int	CoCHeadReviewerflag	=	0;
	int	HeadOfEngReviewerflag	=	0;
	int ProposedReviewerflag	=	0;
	int	NwRaisedByflag	=	0;

	int ifail=0;

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n New_PartReq_assign_manager_teamreviewer:Root task found");fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n New_PartReq_assign_manager_teamreviewer:CurrentTask:%s\n",CurrentTask);fflush(stdout);

	CALLAPI(AOM_ask_value_string(root_task,"object_name",&parent_name));
	printf("\n New_PartReq_assign_manager_teamreviewer:Parent Name:%s\n",parent_name);fflush(stdout);
	if(strstr(CurrentTask,"Assign Reviewers and Review NPR")!=NULL)
	{
		CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
		printf("\n New_PartReq_assign_manager_teamreviewer: EPM_ask_attachments of :: %d\n",count);fflush(stdout);
		if(count>0)
		{
			for(i=0;i<count;i++)
			{
				CALLAPI(TCTYPE_ask_object_type (attachments[i], &objTypeTag));
				CALLAPI(TCTYPE_ask_name2( objTypeTag, &type_name));
				printf("\n type_name ==> %s\n", type_name);fflush(stdout);			
				if(tc_strcmp(type_name,"T5_NwPCreRevision")==0 || tc_strcmp(type_name,"New Part Request Revision")==0)
				{
					AOM_ask_value_string(attachments[i],"item_id",&DocNum);
					printf("\n DocNum ==> %s\n", DocNum);fflush(stdout);
					ITEM_ask_item_of_rev(attachments[i],&master);
					AOM_ask_value_string(master,"t5_DesignGroup",&NewPrtreqDesignGrp);
					printf("\n NewPrtreqDesignGrp ==> %s\n", NewPrtreqDesignGrp);fflush(stdout);
					AOM_ask_value_string(master,"t5_PartType",&NewPrtreqPrtType);
					printf("\n NewPrtreqPrtType ==> %s\n", NewPrtreqPrtType);fflush(stdout);
					//CALLAPI(AOM_UIF_ask_value(attachments[i],"Analyst",&AnalystName));
					//printf("\n Analyst Name of task :: %s \n",AnalystName);fflush(stdout);
					//getting Participants.
					CALLAPI(GRM_find_relation_type("HasParticipant", &task_Prty_rel_type));
					if (task_Prty_rel_type!=NULLTAG)
					{
						CALLAPI(GRM_list_secondary_objects_only(attachments[i],task_Prty_rel_type,&TskPrtycount,&TaskCRB));
						printf("\n MT: TaskCRB count: %d",TskPrtycount);fflush(stdout);
						if(TskPrtycount>0)
						{
							ModuleReviewerflag=0;
							CoCPrincipleReviewerflag=0;
							CoCHeadReviewerflag=0;
							HeadOfEngReviewerflag=0;
							ProposedReviewerflag=0;
							NwRaisedByflag=0;
							for(jkk=0;jkk<TskPrtycount;jkk++)
							{
								TskCRBTag = TaskCRB[jkk];
								if(TCTYPE_ask_object_type(TskCRBTag,&ObjTypTskCRB));
								if(TCTYPE_ask_name2(ObjTypTskCRB,&Tsk_Prty_typ));
								if (tc_strcmp(Tsk_Prty_typ,"T5_Modeule_Reviewer")==0)
								{
									ModuleReviewerflag=1;
								}
								if (tc_strcmp(Tsk_Prty_typ,"T5_COCPrinciple_Reviewer")==0)
								{
									CoCPrincipleReviewerflag=1;
								}
								if (tc_strcmp(Tsk_Prty_typ,"T5_COCHead_Reviewer")==0)
								{
									CoCHeadReviewerflag=1;
								}
								if (tc_strcmp(Tsk_Prty_typ,"T5_HeadOfEngg")==0)
								{
									HeadOfEngReviewerflag=1;
								}
								if (tc_strcmp(Tsk_Prty_typ,"ProposedReviewer")==0)
								{
									ProposedReviewerflag=1;
								}
								if (tc_strcmp(Tsk_Prty_typ,"T5_NwRaisedBy")==0)
								{
									NwRaisedByflag=1;
								}
							}
						}
					}///
					printf("\n assign_manager_teamreviewer: ModuleReviewerflag of :: %d\n",ModuleReviewerflag);fflush(stdout);
					printf("\n assign_manager_teamreviewer: CoCPrincipleReviewerflag of :: %d\n",CoCPrincipleReviewerflag);fflush(stdout);
					printf("\n assign_manager_teamreviewer: CoCHeadReviewerflag of :: %d\n",CoCHeadReviewerflag);fflush(stdout);
					printf("\n assign_manager_teamreviewer: HeadOfEngReviewerflag of :: %d\n",HeadOfEngReviewerflag);fflush(stdout);
					printf("\n assign_manager_teamreviewer: ProposedReviewerflag of :: %d\n",ProposedReviewerflag);fflush(stdout);
					printf("\n assign_manager_teamreviewer: NwRaisedByflag of :: %d\n",NwRaisedByflag);fflush(stdout);

					if(ModuleReviewerflag==0)
					{
						if(tc_strcmp(type_name,"T5_NwPCreRevision")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign Module Reviewer, \nHelp: Expand Document till target","\nUse: Select Document : Tools->Assign Participant option");
							decision = EPM_nogo;
							return decision;
						}
					}

					if(CoCPrincipleReviewerflag==0)
					{
						if(tc_strcmp(type_name,"T5_NwPCreRevision")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign COC Principle Reviewer, \nHelp: Expand Document till target","\nUse: Select Document : Tools->Assign Participant option");
							decision = EPM_nogo;
							return decision;
						}
					}

					if(CoCHeadReviewerflag==0)
					{
						if(tc_strcmp(type_name,"T5_NwPCreRevision")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign COC head Reviewer, \nHelp: Expand Document till target","\nUse: Select Document : Tools->Assign Participant option");
							decision = EPM_nogo;
							return decision;
						}
					}

					if(HeadOfEngReviewerflag==0 && tc_strcmp(NewPrtreqDesignGrp,"31")==0)
					{
						if(tc_strcmp(type_name,"T5_NwPCreRevision")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign HeadOf Engg, \nHelp: Expand Document till target","\nUse: Select Document : Tools->Assign Participant option");
							decision = EPM_nogo;
							return decision;
						}
					}

					if(ProposedReviewerflag==0 && (tc_strcmp(NewPrtreqPrtType,"M")==0 || tc_strstr(NewPrtreqPrtType,"Module")!=NULL || tc_strcmp(NewPrtreqPrtType,"IM")==0))
					{
						if(tc_strcmp(type_name,"T5_NwPCreRevision")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign Proposed Reviewer, \nHelp: Expand Document till target","\nUse: Select Document : Tools->Assign Participant option");
							decision = EPM_nogo;
							return decision;
						}
					}

					if(NwRaisedByflag==0)
					{
						if(tc_strcmp(type_name,"T5_NwPCreRevision")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign New Part Request Raised By, \nHelp: Expand Document till target","\nUse: Select Document : Tools->Assign Participant option");
							decision = EPM_nogo;
							return decision;
						}
					}

					if(HeadOfEngReviewerflag==0 && (tc_strcmp(NewPrtreqPrtType,"T")==0 || tc_strcmp(NewPrtreqPrtType,"Technical Part List")==0))
					{
						if(tc_strcmp(type_name,"T5_NwPCreRevision")==0)
						{
							EMH_clear_errors();
							EMH_store_error_s2(EMH_severity_error,ITK_err,"Please assign Head Of Eng., \nHelp: Expand Document till target","\nUse: Select Document : Tools->Assign Participant option");
							decision = EPM_nogo;
							return decision;
						}
					}
					break;
				}
			}
		}
	}

	//decision = EPM_go;
	return decision;
}

extern EPM_decision_t DLLAPI New_PartReq_ChkdmlActiveinLC(EPM_rule_message_t msg)
{
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;
	tag_t			primary_obj_type_tag		= NULLTAG;
	char			*type_name1					= NULL;
	char*			procedure_name				= NULL;

	tag_t *attachments = NULLTAG;
	tag_t DMLLcmTag = NULLTAG;
	tag_t *parents = NULLTAG;



	EPM_decision_t decision = EPM_go;
	int ifail=0,count,n_parents=0;

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n New_PartReq_ChkdmlActiveinLC::Root task found for New_PartReq_ChkdmlActiveinLC"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n New_PartReq_ChkdmlActiveinLC::CurrentTask:%s\n",CurrentTask);fflush(stdout);

	CALLAPI(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
	printf("\n New_PartReq_ChkdmlActiveinLC::EPM_ask_attachments of :: %d",count);fflush(stdout);

	if(count > 0)
	{
		DMLLcmTag = attachments[0];
		CALLAPI(TCTYPE_ask_object_type(DMLLcmTag,&primary_obj_type_tag));
		CALLAPI(TCTYPE_ask_name2(primary_obj_type_tag, &type_name1));
		printf("\n New_PartReq_ChkdmlActiveinLC::Primary_object type_name is:%s",type_name1);fflush(stdout);

		EPM_ask_active_job_for_target(DMLLcmTag,&n_parents,&parents);
		printf("\n New_PartReq_ChkdmlActiveinLC::EPM_ask_active_job_for_target------>%d\n",n_parents); fflush(stdout);
	}

	if(tc_strcmp(type_name1,"T5_NwPCre")==0 || tc_strcmp(type_name1,"New Part Request")==0)
	{
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_warning,ITK_err, "New Part Request Master cannot submit in Lifecycle. Kindly Submit New Part Request Revision in workflow.");
		decision = EPM_nogo;
		return decision;
	}

	
	if(n_parents>0 && n_parents==1)
	{
		EPM_ask_procedure_name2(parents[0],&procedure_name);
		printf("\n New_PartReq_ChkdmlActiveinLC::procedure_nameprocedure_name----->%s\n",procedure_name); fflush(stdout);

		if(tc_strcmp(procedure_name,"New Part Request Lifecycle")!=0)
		{
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_warning,ITK_err, "New Part Request Revision can be submit in Lifecycle New Part Request Lifecycle.\n You can not submit it other workflow.");
			decision = EPM_nogo;
			return decision;
		}
		else
		{
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_warning,ITK_err, "New Part Request Revision can not be submit in same Lifecycle New Part Request Lifecycle.");
			decision = EPM_nogo;
			return decision;
			//decision = EPM_go;
		}
	}
	
	
	else if (n_parents>1)
	{
		EMH_clear_errors();
		EMH_store_error_s1(EMH_severity_warning,ITK_err, "New Part Request already submitted in Lifecycle ... You can not submit it again.");
		decision = EPM_nogo;
		return decision;
	}
	else
	{
		decision = EPM_go;
	}

	return decision;
}


/****************************************************************************
Function:       TML_Reject_Function
Description:    This function is used in WF after while complete task assignment
				from designer's login on vehicle release.
Input:          None
Output:         None
Return value:   None
****************************************************************************/

EPM_decision_t TML_Reject_Function( EPM_rule_message_t msg)
{
	
	int			izntaskattachment	= 0;

	tag_t		tzroottask			= NULLTAG;
	tag_t		partrevtag			= NULLTAG;
	tag_t		*tzattachment		= NULLTAG;
	tag_t  		*ReqPartList 		= NULLTAG;
	tag_t  		*attachments 		= NULLTAG;
	tag_t		relation_type 		= NULLTAG;
	tag_t		datasetTypeTag 		= NULLTAG;
	tag_t		refrelation_type	= NULLTAG;
	tag_t		nprmaster			= NULLTAG;
	tag_t		*refnprchklist		= NULLTAG;
	int          ifail              = ITK_ok;
	
	int req_tags_found=0;
	int			i			= 0;
	int			cnt			= 0;
	int			k			= 0;
	int			refcnt		= 0;
	int			error		= 0;
	int			chklisterror= 0;
	logical ischkout = 0;
	logical	checkout_checklist = 0;
	
	char		*objType			=  NULL;
	char    *reqnumber = NULL;
	int datasetNamedRefCount = 0;
	tag_t *datasetRefObjectTag = NULLTAG;
	char  dataset_type_name[TCTYPE_name_size_c+1];

	const char
        *attrs1[1] = {"item_id"},
        *values1[1]	= {"*"};

	EPM_decision_t   decision = EPM_go;

	//ITK_set_bypass(true);
	
	EPM_ask_root_task(msg.task, &tzroottask);
	EPM_ask_attachments(tzroottask, EPM_target_attachment, &izntaskattachment, &tzattachment );
	for(i=0; i<izntaskattachment;i++)
	{
		tag_t partrevtag = tzattachment[i];
		AOM_ask_value_string(partrevtag,"object_type",&objType);
		printf("\n In TML_Reject_Function : object_type : %s \n",objType);fflush(stdout);
		AOM_ask_value_string(partrevtag,"item_id",&reqnumber);
		printf("\n In TML_Reject_Function : reqnumber : %s\n",reqnumber);fflush(stdout);
		values1[0] = reqnumber;
		ifail = ITEM_find_item_revs_by_key_attributes(1,attrs1, values1,"NR",&req_tags_found, &ReqPartList);
		printf("\n In TML_Reject_Function : req_tags_found : %d\n",req_tags_found);fflush(stdout);
		if(req_tags_found>0)
		{
			int n_statuses = 0;
			int ii = 0;
			int kk = 0;
			int n_signoffs = 0;
			tag_t	*statuses		= NULLTAG;
			date_t *sign_off_dates = NULL;
			EPM_decision_t  *decisions = NULL;
			char **signers = NULL;
			char *date_string = NULL;
			char decision_string[3][12] = {"Rejected", "No Decision", "Approved"};
			ITEM_ask_item_of_rev(ReqPartList[0],&nprmaster);
			WSOM_ask_release_status_list(ReqPartList[0],&n_statuses,&statuses);
			printf("\n In TML_Reject_Function : n_statuses : %d\n",n_statuses);fflush(stdout);
			if(n_statuses>0)
			{
				for(ii = 0; ii < n_statuses; ii++)
				{
					EPM_ask_signoff_details(ReqPartList[0], statuses[ii],&n_signoffs, &decisions, &signers, &sign_off_dates);
					printf("\n In TML_Reject_Function : n_statuses : %d\n",n_statuses);fflush(stdout);
					for (kk = 0; kk < n_signoffs; kk++)
					{
						ITK_date_to_string(sign_off_dates[kk],&date_string);
						printf("\n In TML_Reject_Function : signers : [%s]\n",signers[kk]);fflush(stdout);
						printf("\n In TML_Reject_Function : decision_string : [%s]\n",decision_string[decisions[kk]]);fflush(stdout);
						printf("\n In TML_Reject_Function : date_string : [%s]\n",date_string);fflush(stdout);
						MEM_free(date_string);
					}
					for (kk = 0; kk < n_signoffs; kk++)
					{
						MEM_free(signers);
						MEM_free(decisions);
						MEM_free(sign_off_dates);
					}
				}
				MEM_free(statuses);
			}
			
		}
		
	}
	printf("\n In TML_Reject_Function : attachment error : %d\n",error);fflush(stdout);
	printf("\n In TML_Reject_Function : chklist chklisterror : %d\n",chklisterror);fflush(stdout);
	if(error>0)
	{
		ifail=t9NewPartReqCre_Val0030;
		EMH_store_error_s1(EMH_severity_error,ifail,"Attaching Files Should have Physical File,Please add files and check In to dataset!!...");
		decision = EPM_nogo;
	}

	if(chklisterror>0)
	{
		ifail=t9NewPartReqCre_Val0010;
		EMH_store_error_s1(EMH_severity_error,ifail,"New part request CheckList is checkout, please update property on checklist ...");
		decision = EPM_nogo;
	}
	
	MEM_free(tzattachment);
	MEM_free(ReqPartList);
	
	return decision;


}

/****************************************************************************
    Function:       tm_New_Part_Reqest_register_rule_handlers
    Description:    Entry point for register all Handlers

    Input:

    Output:         None
    Return value:   ifail = 0 on success
	                ifail = Error Base on failure
****************************************************************************/

int tm_New_Part_Reqest_register_rule_handlers()
{
	int retcode = ITK_ok;

	if ( retcode == ITK_ok )
	{						
		retcode = EPM_register_rule_handler (
								"TML_Check_Target",
								"TML_Check_Target",
								(EPM_rule_handler_t)TML_New_Part_Reqest_Check_TargetFunction
								);

		retcode = EPM_register_rule_handler (
								"TML_Check_Reviewers",
								"TML_Check_Reviewers",
								(EPM_rule_handler_t)New_PartReq_assign_manager_teamreviewer
								);

		retcode = EPM_register_rule_handler (
								"TML_Check_Target_LC",
								"TML_Check_Target_LC",
								(EPM_rule_handler_t)New_PartReq_ChkdmlActiveinLC
								);

		retcode = EPM_register_rule_handler (
								"TML_Check_SignOff_Check",
								"TML_Check_SignOff_Check",
								(EPM_rule_handler_t)Reviewer_SignOffCheck
								);

		retcode = EPM_register_rule_handler (
								"TML_MCC_SignOff_Comment",
								"TML_MCC_SignOff_Comment",
								(EPM_rule_handler_t)New_PartReq_CheckSignOffCommentFn
								);

		retcode = EPM_register_rule_handler (
								"TML_Raiser_SignOff",
								"TML_Raiser_SignOff",
								(EPM_rule_handler_t)New_TML_Raiser_SignOffFn
								);

/*
		retcode = EPM_register_rule_handler (
								"TML_New_SubModule_Create",
								"TML_New_SubModule_Create",
								(EPM_rule_handler_t)TML_New_SubModule_Create_Function
								);
*/	


		printf("\n tm_New_Part_Reqest_register_rule_handlers\n");fflush(stdout);
	}
	return retcode;
}


/****************************************************************************
Function:       MYTPE_New_Part_Reqest
Description:    This function used for register custom method/handler 
				on class for different action like pre/post.
				code lsit of an user.
Input:          None
Output:         None
Return value:   None
****************************************************************************/

extern int MYTPE_New_Part_Reqest(int *decision, va_list args)
{
    int          ifail = ITK_ok;
   	METHOD_id_t  method1;
   	METHOD_id_t  method2;
   	METHOD_id_t  method3;
   	METHOD_id_t  method4;
   	METHOD_id_t  method5;
   

	TC_argument_list_t
        *myArgs;
	//METHOD_function_t ;
	char *lov_type=NULL;
	char *DGrp=NULL;
	int i=0;
    *decision = ALL_CUSTOMIZATIONS;


	


	lov_type=(char *) MEM_alloc(100);
	DGrp=(char *) MEM_alloc(10);

    /* Create the method by registering the base action.
    */
	printf("\n MYTPE_New_Part_Reqest - ");fflush(stdout);

	/*
	if( ifail == ITK_ok )
    {
		for (i=0;i<100;i++)
		{
			strcpy(DGrp,"");
			sprintf(DGrp,"%d", i);
			
			strcpy(lov_type,"");
			strcpy(lov_type,"T5_KeyWord_D_Grp_");		
			strcat(lov_type,DGrp);
			printf("\n Lov Type is: %s\n",lov_type);fflush(stdout);

			ifail = METHOD_register_method( lov_type,LOV_ask_values_msg,&t5_LOVKeyWordDescValuesMethod,  0,&method1);
		}
	}
	*/

	ifail = (METHOD_find_method("T5_NwPCreRevision", "IMAN_save", &method2));
	ifail = (METHOD_find_method("T5_NwPCre", "IMAN_save", &method4));
	ifail = (METHOD_find_method(RES_Type, RES_checkin_msg, &method3));
	/*
	printf("\n =======BEFORE Method is t5_NwPrtAny_Set_post_action added now.====== ");fflush(stdout);
	ifail = (METHOD_find_prop_method("T5_NwPCre", "t5_NwPrtAny", PROP_ask_value_string_msg, &method5));
	if(method5.id != NULLTAG)
	{
		ifail = ( METHOD_add_pre_condition(method5, (METHOD_function_t) t5_NwPrtAny_Set_post_action, NULL));
	}
	printf("\n =======AFTER Method is t5_NwPrtAny_Set_post_action added now.====== ");fflush(stdout);
	*/
    if( ifail != ITK_ok )
	{
		EMH_store_error( EMH_severity_error, ifail );
	}
	
	if (method2.id != 0)
	{
		/*
		printf("\n =======before Method is added now::NewPartReq_create_pre_condition====== ");fflush(stdout);
		ifail = ( METHOD_add_pre_condition(method2, (METHOD_function_t) NewPartReq_create_pre_condition, NULL));
		printf("\n =======after Method is added now::NewPartReq_create_pre_condition====== ");fflush(stdout);
		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
		*/

		/*
		printf("\nbefore Method is added now::NewPartReq_create_pre_action");fflush(stdout);
		ifail = ( METHOD_add_action(method2, METHOD_pre_action_type, (METHOD_function_t) NewPartReq_create_pre_action, NULL));
		printf("\nafter Method is added now::NewPartReq_create_pre_action");fflush(stdout);
		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
		*/
		
		//printf("\nbefore Method is NewPartReq_Create_postaction added now");fflush(stdout);
		//ifail = ( METHOD_add_action(method2, METHOD_post_action_type, (METHOD_function_t) NewPartReq_Create_postaction, NULL));
		//printf("\nafter Method is NewPartReq_Create_postaction added now");fflush(stdout);
		//if( ifail != ITK_ok )
		//{
			//EMH_store_error( EMH_severity_error, ifail );
		//}
	}
	
	
	if (method4.id != 0)
	{
		printf("\nbefore Method is added now::NewPartReqItem_create_post_action");fflush(stdout);
		ifail = ( METHOD_add_action(method4, METHOD_post_action_type, (METHOD_function_t) NewPartReqItem_create_post_action, NULL));
		printf("\nafter Method is added now::NewPartReqItem_create_post_action");fflush(stdout);
		ifail = ( METHOD_add_pre_condition(method4, (METHOD_function_t) NewPartReqItem_create_pre_condition, NULL));
		printf("\nafter Method is added now::NewPartReqItem_create_pre_condition");fflush(stdout);
		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}

	if (method3.id != 0)
	{
		printf("\nbefore Method is added now::NewPartReq_CheckList_pre_action");fflush(stdout);
		ifail = ( METHOD_add_action(method3, METHOD_pre_action_type, (METHOD_function_t) NewPartReq_CheckList_pre_action, NULL));
		printf("\nafter Method is added now::NewPartReq_CheckList_pre_action");fflush(stdout);

		printf("\nbefore Method is added now::NewPartReq_CheckList_post_action");fflush(stdout);
		ifail = ( METHOD_add_action(method3, METHOD_post_action_type, (METHOD_function_t) NewPartReq_CheckList_post_action, NULL));
		printf("\nafter Method is added now::NewPartReq_CheckList_post_action");fflush(stdout);
	}
	
	
	printf("\n before tm_New_Part_Reqest_register_action_handlers is added now");fflush(stdout);
	ifail = tm_New_Part_Reqest_register_action_handlers();
	printf("\n after tm_New_Part_Reqest_register_action_handlers is added now");fflush(stdout);

	ifail = tm_New_Part_Reqest_register_rule_handlers();
	printf("\n after tm_New_Part_Reqest_register_rule_handlers is added now");fflush(stdout);

	
    return ifail;
}

/****************************************************************************
    Function:       tm_New_Part_Reqest_register_custom_handlers
    Description:    Registering custom entry point

    Input:          int *decision
					va_list args

    Output:         None
    Return value:   ifail = 0 on success
	                ifail = Error Base on failure
****************************************************************************/
extern DLLAPI int tm_New_Part_Reqest_register_custom_handlers( int *decision , va_list args)
{
	int ifail = ITK_ok;
	ifail = tm_New_Part_Reqest_register_action_handlers();
	*decision  = ALL_CUSTOMIZATIONS;
	args = NULL;
	printf("\n tm_New_Part_Reqest_register_custom_handlers\n");fflush(stdout);
	return ifail;
}

extern DLLAPI int tm_New_Part_Reqest_register_callbacks ()
{
    int ifail    = ITK_ok;
    printf("\n TML.c:before Revise_register_callbacks");fflush(stdout);
    
    ifail=CUSTOM_register_exit ( "tm_New_Part_Reqest", "USER_init_module", (CUSTOM_EXIT_ftn_t)  MYTPE_New_Part_Reqest);
    printf("\n after calling TML_register_callbacks\n");fflush(stdout);

  return ( ITK_ok );
}
