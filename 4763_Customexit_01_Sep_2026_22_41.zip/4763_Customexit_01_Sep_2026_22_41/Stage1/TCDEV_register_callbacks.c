#include "TCDEV_register_callbacks.h"
#include "iman_headers.h"
#include "epm_task_template_itk.h"
#define NUM_ENTRIES 1
//#define EPM_target_attachment   1 
/*
extern DLLAPI int TCDEV_register_callbacks()
{
  CUSTOM_register_exit("TCDEV","USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)TCDEV_register_userservices);
  printf("\ncalling ITK\n");
  return ITK_ok;
}

extern DLLAPI int TCDEV_register_userservices(METHOD_message_t *msg,va_list args)
{

	int nargs=1;
    int *inputArgTypes;
	int retValueType;

	inputArgTypes=(int *)MEM_alloc(nargs * sizeof(int));

	inputArgTypes[0]=USERARG_STRING_TYPE;
	
	retValueType=USERARG_TAG_TYPE;

	printf("\n User Service Call...........");

	USERSERVICE_register_method("createBulkItems",(USER_function_t)TCDEV_create_bulk_items,nargs,inputArgTypes,retValueType);

	//printf("\nitk........");

    return ITK_ok;

}
*/
int TCDEV_create_bulk_items(void* retValue)
{

	int status=ITK_ok;
	char* PassedFdr=NULL;
	char	HitsS[7];
	char	CrHitsS[7];
	char	DvoItemId[8];
	char	CrItemId[28];
	char	DvoDesc[100];
	char	CrDesc[100];
	char	DvoName[100];

	char	NameRef[20];
	char	NameRefpath[20];
	char	*RqmtID							= NULL;
	char	*RqmtTitle						= NULL;
	char	*RqmtTxt						= NULL;
	char	*user_name						= NULL;
	char	*userid							= NULL;
	char	*RqstID							= NULL;
	/*Getting DvmID,DvmRev,DvmName from Requirement Object*/
	char	*ReqID							= NULL;
	char	*t5DvoID						= NULL;
	char	*ReqRev							= NULL;
	char	*ReqName						= NULL;
	char	*ReqOwnAttrGrp					= NULL;
	char	*DvmID							= NULL;
	char	*DvmRev							= NULL;
	char	*DvmName						= NULL;
	logical 	DvmMile1;
	logical 	DvmMile2;
	logical 	DvmMile3;
	logical 	DvmMile4;
	logical 	DvmMile5;
	logical 	DvmMile6;
	logical 	DvmMile7;
	logical 	DvmMile8;
	logical 	DvmMile9;
	logical 	DvmMile10;
	logical 	DvmMile11;
	logical 	DvmMile12;
	logical 	DvmMile13;
	logical 	DvmMile14;
	logical 	DvmMile15;
	logical 	DvmMile16;
	logical 	DvmMile17;
		char	aDvoFdrName[WSO_name_size_c +1]	= { "DVO" };
	char	aDvoFdrDesc[WSO_desc_size_c +1]	= { "DVO-Folder-Created-For-Loaded-Data" };
	char	Wso_Name[WSO_name_size_c+1];
	char	WSO_Name_Type[WSO_name_size_c+1] ;
	char	DvoReqRel_Name[WSO_name_size_c+1] ;
	char	DvoReqRel_Name_Type[WSO_name_size_c+1] ;
	char	Req_Name[WSO_name_size_c+1] ;
	char	Req_Name_Type[WSO_name_size_c+1] ;
	char	DVO_Name[WSO_name_size_c+1] ;
	char	DVO_Name_Type[WSO_name_size_c+1] ;
	char	ReqDvmSpec_Name[WSO_name_size_c+1] ;
	char	ReqDvmSpec_Name_Type[WSO_name_size_c+1];
	//char	ReqDvmRef_Name[WSO_name_size_c+1];
	//char	ReqDvmRef_Name_Type[WSO_name_size_c+1];
	char	personname[SA_person_name_size_c+1];
	char	*DvoCriteria1;
	char	*DvoCriteria2;
	char	*DvoCriteria3;
	char	*DvoCriteria4;
	char	*DvoCriteria5;
	char	*DvoCriteria6;
	char	*DvoCriteria7;
	char	*DvoCriteria8;
	char	*DvoCriteria9;
	char	*DvoCriteria10;
	char	*DvoCriteria11;
	char	*DvoCriteria12;
	char	*DvoCriteria13;
	char	*DvoCriteria14;
	char	*DvoCriteria15;
	char	*DvoCriteria16;
	char	*DvoCriteria17;
	char	*DvoCriteria18;
	char	*DvoCriteria19;
	char	*DvoCriteria20;
	char	*DvoCriteria21;
	char	*DvoCriteria22;
	char	*DvoCriteria23;
	char	*DvoCriteria24;
	char	*DvoCriteria25;
	char	*DvoCriteria26;
	char	*DvoCriteria27;
	char	*DvoCriteria28;
	char	*DvoCriteria29;
	char	*DvoCriteria30;
	char	*DvoCriteria31;
	char	*DvoCriteria32;
	char	*DvoCriteria33;
	char	*DvoCriteria34;
	char	*DvoCriteria35;
	char	*DvoCriteria36;
	char	*DvoCriteria37;
	char	*DvoCriteria38;
	char	*DvoCriteria39;
	char	*DvoCriteria40;
	char	*DvoCriteria41;
	char	*DvoCriteria42;
	char	*DvoCriteria43;
	char	*DvoCriteria44;
	char	*DvoCriteria45;
	char	*DvoCriteria46;
	char	*DvoCriteria47;
	char	*DvoCriteria48;
	char	*DvoCriteria49;
	char	*DvoCriteria50;
	char	*DvoCriteria51;
	char	*DvoCriteria52;
	char	*DvoCriteria53;
	char	*DvoCriteria54;
	char	*DvoCriteria55;
	char	*DvoCriteria56;
	char	*DvoCriteria57;
	char	*DvoCriteria58;
	char	*DvoCriteria59;
	char	*DvoCriteria60;
	char	*DvoCriteria61;
	char	*DvoCriteria62;
	char	*DvoCriteria63;
	char	*DvoCriteria64;
	char	*DvoCriteria65;
	char	*DvoCriteria66;
	char	*DvoCriteria67;
	char	*DvoCriteria68;
	char	*DvoCriteria69;
	char	*DvoCriteria70;
	char	*DvoCriteria71;
	char	*DvoCriteria72;
	char	*DvoCriteria73;
	char	*DvoCriteria74;
	char	*DvoCriteria75;
	char	*DvoCriteria76;
	char	*DvoCriteria77;
	char	*DvoCriteria78;
	char	*DvoCriteria79;
	char	*DvoCriteria80;
	char	*DvoCriteria81;
	char	*DvoCriteria82;
	char	*DvoCriteria83;
	char	*DvoCriteria84;
	char	*DvoCriteria85;
	char	*DvoCriteria86;
	char	*DvoCriteria87;
	char	*DvoCriteria88;
	char	*DvoCriteria89;
	char	*DvoCriteria90;
	char	*DvoCriteria91;
	char	*DvoCriteria92;
	char	*DvoCriteria93;
	char	*DvoCriteria94;
	char	*DvoCriteria95;
	char	*DvoCriteria96;
	char	*DvoCriteria97;
	char	*DvoCriteria98;
	char	*DvoCriteria99;
	char	*DvoCriteria100;
	char	*DvoCriteria101;
	char	*DvoCriteria102;
	char	*DvoCriteria103;
	char	*DvoCriteria104;
	char	*DvoCriteria105;
	char	*DvoCriteria106;
	char	*DvoCriteria107;
	char	*DvoCriteria108;
	char	*DvoCriteria109;
	char	*DvoCriteria110;
	char	*DvoCriteria111;
	char	*DvoCriteria112;
	char	*DvoCriteria113;
	char	*DvoCriteria114;
	char	*DvoCriteria115;
	char	*DvoCriteria116;
	char	*DvoCriteria117;
	char	*DvoCriteria118;
	char	*DvoCriteria119;
	char	*DvoCriteria120;
	char	*DvoCriteria121;
	char	*DvoCriteria122;
	char	*DvoCriteria123;
	char	*DvoCriteria124;
	char	*DvoCriteria125;
	char	*DvoCriteria126;
	char	*DvoCriteria127;
	char	*DvoCriteria128;
	char	*DvoCriteria129;
	char	*DvoCriteria130;
	char	*DvoCriteria131;
	char	*DvoCriteria132;
	char	*DvoCriteria133;
	char	*DvoCriteria134;
	char	*DvoCriteria135;
	char	*DvoCriteria136;
	char	*DvoCriteria137;
	char	*DvoCriteria138;
	char	*DvoCriteria139;
	char	*DvoCriteria140;
	char	*DvoCriteria141;
	char	*DvoCriteria142;
	char	*DvoCriteria143;
	char	*DvoCriteria144;
	char	*DvoCriteria145;
	char	*DvoCriteria146;
	char	*DvoCriteria147;
	char	*DvoCriteria148;
	char	*DvoCriteria149;
	char	*DvoCriteria150;
	char	*DvoCriteria151;
	char	*DvoCriteria152;
	char	*DvoCriteria153;
	char	*DvoCriteria154;
	char	*DvoCriteria155;
	char	*DvoCriteria156;
	char	*DvoCriteria157;
	char	*DvoCriteria158;
	char	*DvoCriteria159;
	char	*DvoCriteria160;

	int		MileNumber = 0;
	int     MileCounter = 0;
	char	MileName[100];
	char	MileCount[10];
	logical	DvmMilea;
								
	int		hits,lenHits,Crhits,CrlenHits	= 0;
	int		HomeFolderSize1					= -1;
	int		HomeFolderSize					= -1;
	int		DvoReqFdrSize					= -1;
	int		DvoReqFdrSize1					= -1;
	int		ReqFdrSize1						= -1;
	int		TotalSize						= -1;
	int		ReqFdrSize						= -1;
	int		foundcnt,CountFdr				= 0;
	int		DvoReqCnt,foundcnt2				= 0;
	int		DvoCountFdr						= 0;
	int		iAbhiDvoCheck					= 0;
	int		iDvo_Fdr_Cnt					= 0;
	int		ReqRevRelCnt,ReqFdrFound		= 0;
	int		ReqDvmCnt,ReqCnt				= 0;
	int		ReqDvmSpec,ReqDvmRef			= 0;
	int		DvoCount						= 0;
	int     AttachmentType                  = 0;
	int		i,j,mk								= 0;
	int		masterfoundcnt					= 0;
	tag_t	tDvoFolder						= NULLTAG;
	tag_t	tDvoItemRev						= NULLTAG;
	tag_t	tCrItemRev						= NULLTAG;
	tag_t	*temptag						= NULLTAG;
	tag_t	tDvoItem						= NULLTAG;
	tag_t	tCrItem1						= NULLTAG;
	tag_t	tCrItem2						= NULLTAG;
	tag_t	tCrItem3						= NULLTAG;
	tag_t	tCrItem4						= NULLTAG;
	tag_t	tCrItem5						= NULLTAG;
	tag_t	tCrItem6						= NULLTAG;
	tag_t	tCrItem7						= NULLTAG;
	tag_t	tCrItem8						= NULLTAG;
	tag_t	tCrItem9						= NULLTAG;
	tag_t	tCrItem10						= NULLTAG;
	tag_t	tCrItem11						= NULLTAG;
	tag_t	tCrItem12						= NULLTAG;
	tag_t	tCrItem13						= NULLTAG;
	tag_t	tCrItem14						= NULLTAG;
	tag_t	tCrItem15						= NULLTAG;
	tag_t	tCrItem16						= NULLTAG;
	tag_t	tCrItem17						= NULLTAG;
	tag_t	tCrItem18						= NULLTAG;
	tag_t	tCrItem19						= NULLTAG;
	tag_t	tCrItem20						= NULLTAG;
	tag_t	tCrItem21						= NULLTAG;
	tag_t	tCrItem22						= NULLTAG;
	tag_t	tCrItem23						= NULLTAG;
	tag_t	tCrItem24						= NULLTAG;
	tag_t	tCrItem25						= NULLTAG;
	tag_t	tCrItem26						= NULLTAG;
	tag_t	tCrItem27						= NULLTAG;
	tag_t	tCrItem28						= NULLTAG;
	tag_t	tCrItem29						= NULLTAG;
	tag_t	tCrItem30						= NULLTAG;
	tag_t	tCrItem31						= NULLTAG;
	tag_t	tCrItem32						= NULLTAG;
	tag_t	tCrItem33						= NULLTAG;
	tag_t	tCrItem34						= NULLTAG;
	tag_t	tCrItem35						= NULLTAG;
	tag_t	tCrItem36						= NULLTAG;
	tag_t	tCrItem37						= NULLTAG;
	tag_t	tCrItem38						= NULLTAG;
	tag_t	tCrItem39						= NULLTAG;
	tag_t	tCrItem40						= NULLTAG;
	tag_t	tCrItem41						= NULLTAG;
	tag_t	tCrItem42						= NULLTAG;
	tag_t	tCrItem43						= NULLTAG;
	tag_t	tCrItem44						= NULLTAG;
	tag_t	tCrItem45						= NULLTAG;
	tag_t	tCrItem46						= NULLTAG;
	tag_t	tCrItem47						= NULLTAG;
	tag_t	tCrItem48						= NULLTAG;
	tag_t	tCrItem49						= NULLTAG;
	tag_t	tCrItem50						= NULLTAG;
	tag_t	tCrItem51						= NULLTAG;
	tag_t	tCrItem52						= NULLTAG;
	tag_t	tCrItem53						= NULLTAG;
	tag_t	tCrItem54						= NULLTAG;
	tag_t	tCrItem55						= NULLTAG;
	tag_t	tCrItem56						= NULLTAG;
	tag_t	tCrItem57						= NULLTAG;
	tag_t	tCrItem58						= NULLTAG;
	tag_t	tCrItem59						= NULLTAG;
	tag_t	tCrItem60						= NULLTAG;
	tag_t	tCrItem61						= NULLTAG;
	tag_t	tCrItem62						= NULLTAG;
	tag_t	tCrItem63						= NULLTAG;
	tag_t	tCrItem64						= NULLTAG;
	tag_t	tCrItem65						= NULLTAG;
	tag_t	tCrItem66						= NULLTAG;
	tag_t	tCrItem67						= NULLTAG;
	tag_t	tCrItem68						= NULLTAG;
	tag_t	tCrItem69						= NULLTAG;
	tag_t	tCrItem70						= NULLTAG;
	tag_t	tCrItem71						= NULLTAG;
	tag_t	tCrItem72						= NULLTAG;
	tag_t	tCrItem73						= NULLTAG;
	tag_t	tCrItem74						= NULLTAG;
	tag_t	tCrItem75						= NULLTAG;
	tag_t	tCrItem76						= NULLTAG;
	tag_t	tCrItem77						= NULLTAG;
	tag_t	tCrItem78						= NULLTAG;
	tag_t	tCrItem79						= NULLTAG;
	tag_t	tCrItem80						= NULLTAG;
	tag_t	tCrItem81						= NULLTAG;
	tag_t	tCrItem82						= NULLTAG;
	tag_t	tCrItem83						= NULLTAG;
	tag_t	tCrItem84						= NULLTAG;
	tag_t	tCrItem85						= NULLTAG;
	tag_t	tCrItem86						= NULLTAG;
	tag_t	tCrItem87						= NULLTAG;
	tag_t	tCrItem88						= NULLTAG;
	tag_t	tCrItem89						= NULLTAG;
	tag_t	tCrItem90						= NULLTAG;
	tag_t	tCrItem91						= NULLTAG;
	tag_t	tCrItem92						= NULLTAG;
	tag_t	tCrItem93						= NULLTAG;
	tag_t	tCrItem94						= NULLTAG;
	tag_t	tCrItem95						= NULLTAG;
	tag_t	tCrItem96						= NULLTAG;
	tag_t	tCrItem97						= NULLTAG;
	tag_t	tCrItem98						= NULLTAG;
	tag_t	tCrItem99						= NULLTAG;
	tag_t	tCrItem100						= NULLTAG;
	tag_t	tCrItem101						= NULLTAG;
	tag_t	tCrItem102						= NULLTAG;
	tag_t	tCrItem103						= NULLTAG;
	tag_t	tCrItem104						= NULLTAG;
	tag_t	tCrItem105						= NULLTAG;
	tag_t	tCrItem106						= NULLTAG;
	tag_t	tCrItem107						= NULLTAG;
	tag_t	tCrItem108						= NULLTAG;
	tag_t	tCrItem109						= NULLTAG;
	tag_t	tCrItem110						= NULLTAG;
	tag_t	tCrItem111						= NULLTAG;
	tag_t	tCrItem112						= NULLTAG;
	tag_t	tCrItem113						= NULLTAG;
	tag_t	tCrItem114						= NULLTAG;
	tag_t	tCrItem115						= NULLTAG;
	tag_t	tCrItem116						= NULLTAG;
	tag_t	tCrItem117						= NULLTAG;
	tag_t	tCrItem118						= NULLTAG;
	tag_t	tCrItem119						= NULLTAG;
	tag_t	tCrItem120						= NULLTAG;
	tag_t	tCrItem121						= NULLTAG;
	tag_t	tCrItem122						= NULLTAG;
	tag_t	tCrItem123						= NULLTAG;
	tag_t	tCrItem124						= NULLTAG;
	tag_t	tCrItem125						= NULLTAG;
	tag_t	tCrItem126						= NULLTAG;
	tag_t	tCrItem127						= NULLTAG;
	tag_t	tCrItem128						= NULLTAG;
	tag_t	tCrItem129						= NULLTAG;
	tag_t	tCrItem130						= NULLTAG;
	tag_t	tCrItem131						= NULLTAG;
	tag_t	tCrItem132						= NULLTAG;
	tag_t	tCrItem133						= NULLTAG;
	tag_t	tCrItem134						= NULLTAG;
	tag_t	tCrItem135						= NULLTAG;
	tag_t	tCrItem136						= NULLTAG;
	tag_t	tCrItem137						= NULLTAG;
	tag_t	tCrItem138						= NULLTAG;
	tag_t	tCrItem139						= NULLTAG;
	tag_t	tCrItem140						= NULLTAG;
	tag_t	tCrItem141						= NULLTAG;
	tag_t	tCrItem142						= NULLTAG;
	tag_t	tCrItem143						= NULLTAG;
	tag_t	tCrItem144						= NULLTAG;
	tag_t	tCrItem145						= NULLTAG;
	tag_t	tCrItem146						= NULLTAG;
	tag_t	tCrItem147						= NULLTAG;
	tag_t	tCrItem148						= NULLTAG;
	tag_t	tCrItem149						= NULLTAG;
	tag_t	tCrItem150						= NULLTAG;
	tag_t	tCrItem151						= NULLTAG;
	tag_t	tCrItem152						= NULLTAG;
	tag_t	tCrItem153						= NULLTAG;
	tag_t	tCrItem154						= NULLTAG;
	tag_t	tCrItem155						= NULLTAG;
	tag_t	tCrItem156						= NULLTAG;
	tag_t	tCrItem157						= NULLTAG;
	tag_t	tCrItem158						= NULLTAG;
	tag_t	tCrItem159						= NULLTAG;
	tag_t	tCrItem160						= NULLTAG;

	tag_t	*ListOfDvoObj					= NULLTAG;
	tag_t	*ListOfCrObj					= NULLTAG;
	tag_t	tReqRevTag						= NULLTAG;
	tag_t	tRelationFind					= NULLTAG;
	tag_t	tRelationFind1					= NULLTAG;
	tag_t	tCrRelationFind1					= NULLTAG;
	tag_t	tRelationObj					= NULLTAG;
	tag_t	tRelationObj1					= NULLTAG;
	tag_t	tCrRelationObj1			= NULLTAG;
	tag_t	tCrRelationObj2			= NULLTAG;
	tag_t	tCrRelationObj3			= NULLTAG;
	tag_t	tCrRelationObj4			= NULLTAG;
	tag_t	tCrRelationObj5			= NULLTAG;
	tag_t	tCrRelationObj6			= NULLTAG;
	tag_t	tCrRelationObj7			= NULLTAG;
	tag_t	tCrRelationObj8			= NULLTAG;
	tag_t	tCrRelationObj9			= NULLTAG;
	tag_t	tCrRelationObj10		= NULLTAG;
	tag_t	tCrRelationObj11		= NULLTAG;
	tag_t	tCrRelationObj12		= NULLTAG;
	tag_t	tCrRelationObj13		= NULLTAG;
	tag_t	tCrRelationObj14		= NULLTAG;
	tag_t	tCrRelationObj15		= NULLTAG;
	tag_t	tCrRelationObj16		= NULLTAG;
	tag_t	tCrRelationObj17		= NULLTAG;
	tag_t	tCrRelationObj18		= NULLTAG;
	tag_t	tCrRelationObj19		= NULLTAG;
	tag_t	tCrRelationObj20		= NULLTAG;
	tag_t	tCrRelationObj21		= NULLTAG;
	tag_t	tCrRelationObj22		= NULLTAG;
	tag_t	tCrRelationObj23		= NULLTAG;
	tag_t	tCrRelationObj24		= NULLTAG;
	tag_t	tCrRelationObj25		= NULLTAG;
	tag_t	tCrRelationObj26		= NULLTAG;
	tag_t	tCrRelationObj27		= NULLTAG;
	tag_t	tCrRelationObj28		= NULLTAG;
	tag_t	tCrRelationObj29		= NULLTAG;
	tag_t	tCrRelationObj30		= NULLTAG;
	tag_t	tCrRelationObj31		= NULLTAG;
	tag_t	tCrRelationObj32		= NULLTAG;
	tag_t	tCrRelationObj33		= NULLTAG;
	tag_t	tCrRelationObj34		= NULLTAG;
	tag_t	tCrRelationObj35		= NULLTAG;
	tag_t	tCrRelationObj36		= NULLTAG;
	tag_t	tCrRelationObj37		= NULLTAG;
	tag_t	tCrRelationObj38		= NULLTAG;
	tag_t	tCrRelationObj39		= NULLTAG;
	tag_t	tCrRelationObj40		= NULLTAG;
	tag_t	tCrRelationObj41		= NULLTAG;
	tag_t	tCrRelationObj42		= NULLTAG;
	tag_t	tCrRelationObj43		= NULLTAG;
	tag_t	tCrRelationObj44		= NULLTAG;
	tag_t	tCrRelationObj45		= NULLTAG;
	tag_t	tCrRelationObj46		= NULLTAG;
	tag_t	tCrRelationObj47		= NULLTAG;
	tag_t	tCrRelationObj48		= NULLTAG;
	tag_t	tCrRelationObj49		= NULLTAG;
	tag_t	tCrRelationObj50		= NULLTAG;
	tag_t	tCrRelationObj51		= NULLTAG;
	tag_t	tCrRelationObj52		= NULLTAG;
	tag_t	tCrRelationObj53		= NULLTAG;
	tag_t	tCrRelationObj54		= NULLTAG;
	tag_t	tCrRelationObj55		= NULLTAG;
	tag_t	tCrRelationObj56		= NULLTAG;
	tag_t	tCrRelationObj57		= NULLTAG;
	tag_t	tCrRelationObj58		= NULLTAG;
	tag_t	tCrRelationObj59		= NULLTAG;
	tag_t	tCrRelationObj60		= NULLTAG;
	tag_t	tCrRelationObj61		= NULLTAG;
	tag_t	tCrRelationObj62		= NULLTAG;
	tag_t	tCrRelationObj63		= NULLTAG;
	tag_t	tCrRelationObj64		= NULLTAG;
	tag_t	tCrRelationObj65		= NULLTAG;
	tag_t	tCrRelationObj66		= NULLTAG;
	tag_t	tCrRelationObj67		= NULLTAG;
	tag_t	tCrRelationObj68		= NULLTAG;
	tag_t	tCrRelationObj69		= NULLTAG;
	tag_t	tCrRelationObj70		= NULLTAG;
	tag_t	tCrRelationObj71		= NULLTAG;
	tag_t	tCrRelationObj72		= NULLTAG;
	tag_t	tCrRelationObj73		= NULLTAG;
	tag_t	tCrRelationObj74		= NULLTAG;
	tag_t	tCrRelationObj75		= NULLTAG;
	tag_t	tCrRelationObj76		= NULLTAG;
	tag_t	tCrRelationObj77		= NULLTAG;
	tag_t	tCrRelationObj78		= NULLTAG;
	tag_t	tCrRelationObj79		= NULLTAG;
	tag_t	tCrRelationObj80		= NULLTAG;
	tag_t	tCrRelationObj81		= NULLTAG;
	tag_t	tCrRelationObj82		= NULLTAG;
	tag_t	tCrRelationObj83		= NULLTAG;
	tag_t	tCrRelationObj84		= NULLTAG;
	tag_t	tCrRelationObj85		= NULLTAG;
	tag_t	tCrRelationObj86		= NULLTAG;
	tag_t	tCrRelationObj87		= NULLTAG;
	tag_t	tCrRelationObj88		= NULLTAG;
	tag_t	tCrRelationObj89		= NULLTAG;
	tag_t	tCrRelationObj90		= NULLTAG;
	tag_t	tCrRelationObj91		= NULLTAG;
	tag_t	tCrRelationObj92		= NULLTAG;
	tag_t	tCrRelationObj93		= NULLTAG;
	tag_t	tCrRelationObj94		= NULLTAG;
	tag_t	tCrRelationObj95		= NULLTAG;
	tag_t	tCrRelationObj96		= NULLTAG;
	tag_t	tCrRelationObj97		= NULLTAG;
	tag_t	tCrRelationObj98		= NULLTAG;
	tag_t	tCrRelationObj99		= NULLTAG;
	tag_t	tCrRelationObj100		= NULLTAG;
	tag_t	tCrRelationObj101		= NULLTAG;
	tag_t	tCrRelationObj102		= NULLTAG;
	tag_t	tCrRelationObj103		= NULLTAG;
	tag_t	tCrRelationObj104		= NULLTAG;
	tag_t	tCrRelationObj105		= NULLTAG;
	tag_t	tCrRelationObj106		= NULLTAG;
	tag_t	tCrRelationObj107		= NULLTAG;
	tag_t	tCrRelationObj108		= NULLTAG;
	tag_t	tCrRelationObj109		= NULLTAG;
	tag_t	tCrRelationObj110		= NULLTAG;
	tag_t	tCrRelationObj111		= NULLTAG;
	tag_t	tCrRelationObj112		= NULLTAG;
	tag_t	tCrRelationObj113		= NULLTAG;
	tag_t	tCrRelationObj114		= NULLTAG;
	tag_t	tCrRelationObj115		= NULLTAG;
	tag_t	tCrRelationObj116		= NULLTAG;
	tag_t	tCrRelationObj117		= NULLTAG;
	tag_t	tCrRelationObj118		= NULLTAG;
	tag_t	tCrRelationObj119		= NULLTAG;
	tag_t	tCrRelationObj120		= NULLTAG;
	tag_t	tCrRelationObj121		= NULLTAG;
	tag_t	tCrRelationObj122		= NULLTAG;
	tag_t	tCrRelationObj123		= NULLTAG;
	tag_t	tCrRelationObj124		= NULLTAG;
	tag_t	tCrRelationObj125		= NULLTAG;
	tag_t	tCrRelationObj126		= NULLTAG;
	tag_t	tCrRelationObj127		= NULLTAG;
	tag_t	tCrRelationObj128		= NULLTAG;
	tag_t	tCrRelationObj129		= NULLTAG;
	tag_t	tCrRelationObj130		= NULLTAG;
	tag_t	tCrRelationObj131		= NULLTAG;
	tag_t	tCrRelationObj132		= NULLTAG;
	tag_t	tCrRelationObj133		= NULLTAG;
	tag_t	tCrRelationObj134		= NULLTAG;
	tag_t	tCrRelationObj135		= NULLTAG;
	tag_t	tCrRelationObj136		= NULLTAG;
	tag_t	tCrRelationObj137		= NULLTAG;
	tag_t	tCrRelationObj138		= NULLTAG;
	tag_t	tCrRelationObj139		= NULLTAG;
	tag_t	tCrRelationObj140		= NULLTAG;
	tag_t	tCrRelationObj141		= NULLTAG;
	tag_t	tCrRelationObj142		= NULLTAG;
	tag_t	tCrRelationObj143		= NULLTAG;
	tag_t	tCrRelationObj144		= NULLTAG;
	tag_t	tCrRelationObj145		= NULLTAG;
	tag_t	tCrRelationObj146		= NULLTAG;
	tag_t	tCrRelationObj147		= NULLTAG;
	tag_t	tCrRelationObj148		= NULLTAG;
	tag_t	tCrRelationObj149		= NULLTAG;
	tag_t	tCrRelationObj150		= NULLTAG;
	tag_t	tCrRelationObj151		= NULLTAG;
	tag_t	tCrRelationObj152		= NULLTAG;
	tag_t	tCrRelationObj153		= NULLTAG;
	tag_t	tCrRelationObj154		= NULLTAG;
	tag_t	tCrRelationObj155		= NULLTAG;
	tag_t	tCrRelationObj156		= NULLTAG;
	tag_t	tCrRelationObj157		= NULLTAG;
	tag_t	tCrRelationObj158		= NULLTAG;
	tag_t	tCrRelationObj159		= NULLTAG;
	tag_t	tCrRelationObj160		= NULLTAG;
	tag_t			results = NULLTAG;

	tag_t	tRelationExist					= NULLTAG;
	tag_t	tRelationExist1					= NULLTAG;
	tag_t	tUser							= NULLTAG;
	tag_t	DvmItemTag						= NULLTAG;
	tag_t	tHome_Folder					= NULLTAG;
	tag_t	process_task_template			= NULLTAG;
	tag_t	new_process						= NULLTAG;
	tag_t	*tWSOM_Find						= NULLTAG;
	tag_t	*tDvoReqRel_Find				= NULLTAG;
	tag_t	*tReq_Find						= NULLTAG;
	tag_t	*Objects_Found						= NULLTAG;
	tag_t	*Secondary_Objects;
	tag_t   query_object						= NULLTAG;
	tag_t *  total_results						= NULLTAG;

	tag_t	tmp_criteria1						= NULLTAG;
	tag_t	tmp_criteria2						= NULLTAG;
	tag_t	tmp_criteria3						= NULLTAG;
	tag_t	tmp_criteria4						= NULLTAG;

	WSO_search_criteria_t  mastercriteria;
	WSO_search_criteria_t  performtask;
	int number_found;
	tag_t *list_of_WSO_tags = NULLTAG;

	int   entry_count;  
	int   p=0;  
	int   num_found =0;  
	char **  entries; 
	char **  values; 
 

	char	taskName[WSO_name_size_c + 1];
	char    type_name[WSO_name_size_c + 1];
	char    JobName[WSO_name_size_c + 1];
	char		   *JobTargerAttach		=NULL;
	  
	FILE *fp1;
	char inputfile[20];
	char *inputline=NULL;
	char *requirementid=NULL;
	char *requirementpath=NULL;
	char	*JobDesc		= NULL;

	char	* mastercriteriacode		= NULL;
	char	* mastercriteriadata		= NULL;
	char	* mastercriteriadefault		= NULL;
	char	* mastercriteriaunit		= NULL;
	char	* mastercriteriatype		= NULL;
	tag_t	reln_type					 =NULLTAG;
	int n_attchs=0;
	tag_t			*attached_objects			= NULLTAG;
// GRM_relation_t *attached_objects; 
	tag_t	roottask		= NULLTAG;
	char	*inTask			= NULL;
	//char**	critNames;
	//char**	critValues;
	char    *req_item = NULL;
	int index;
char
        *critNames[2],
		*critValues[2];

//char	entryNamesArray[NUM_ENTRIES][QRY_uid_name_size_c+1]	= { "Type" };
//char	entryValuesArray[NUM_ENTRIES][QRY_clause_size_c+1]	= { "TasksToPerform" };

	WSO_search_criteria_t  criteria;
	WSO_search_criteria_t  Crcriteria;
	WSO_description_t     desc;

	AttachmentType=EPM_target_attachment;
	
	
	req_item=malloc(18);
	strcpy(req_item,"TasksToPerform");
    
	USERARG_get_string_argument(&PassedFdr);
	printf("\n Folder Name  : %s",PassedFdr);

	printf("\n LOGIN\n");fflush(stdout);
	
	/*
	/*Finding Passed Folder Inside Home Folder.
	ERROR_CALL(POM_get_user(&user_name,&tUser));
	ERROR_CALL(SA_ask_user_home_folder (tUser,&tHome_Folder));
	ERROR_CALL(FL_ask_size(tHome_Folder,&HomeFolderSize));
	ERROR_CALL(FL_ask_references(tHome_Folder,FL_fsc_by_date_modified ,&HomeFolderSize1,&tWSOM_Find));

	ERROR_CALL(SA_ask_user_person_name(tUser,personname));
	printf("\nPerson Logged In ==> [%s]\n",personname);fflush(stdout);

	for (foundcnt=0;foundcnt<HomeFolderSize1;foundcnt++)
	{
		ERROR_CALL(WSOM_ask_name(tWSOM_Find[foundcnt],Wso_Name));
		ERROR_CALL(WSOM_ask_object_type(tWSOM_Find[foundcnt],WSO_Name_Type));
		//printf("\nWSO_Name [%s] and it Is [%s]\n",Wso_Name,WSO_Name_Type);fflush(stdout);
		if (tc_strcmp(WSO_Name_Type,"Folder")==0 && tc_strcmp(Wso_Name,PassedFdr)==0)
		{
			printf("\nPassed Folder Found Inside Home Folder\n");fflush(stdout);
			CountFdr ++;
			break;
		}
	}
*/
 
	ERROR_CALL(POM_get_user_id(&userid));
	//printf("\nName of the user from 1st: %s\n",user_name);
	printf("\nName of the user from 2nd: %s\n",userid);
	//WSOM_clear_search_criteria(&performtask);
	//strcpy(performtask.date_released,userid);
	//ERROR_CALL(WSOM_search(performtask, &number_found,&list_of_WSO_tags));

	ERROR_CALL(QRY_find ( "General...",&query_object)); 
	printf("\nquery_tag : %d\n",query_object);fflush(stdout);
/*
	QRY_find_user_entries(query_object,&entry_count,&entries,&values); 
	printf("\nentry_count : %d \n",entry_count);fflush(stdout);


for (mk=0;mk<entry_count;mk++ )
{
	printf("\n%s : %s\n",entries[mk],values[mk]);fflush(stdout);
}
values[2]="TasksToPerform";
for (mk=0;mk<entry_count;mk++ )
{
	printf("\n%s : %s\n",entries[mk],values[mk]);fflush(stdout);
}


critNames = malloc( NUM_ENTRIES * sizeof *critNames );
		for( index=0; index<NUM_ENTRIES; index++ )
		{
			critNames[index] = malloc( strlen(entryNamesArray[index] + 1) );
			if( critNames[index] )
			strcpy( critNames[index], entryNamesArray[index] );
		}

critValues = malloc( NUM_ENTRIES * sizeof *critValues );
		for( index=0; index<NUM_ENTRIES; index++ )
		{
			critValues[index] = malloc( strlen(entryValuesArray[index] + 1) );
			if( critValues[index] )
			strcpy( critValues[index], req_item );
		}
*/
 //critNames[2] = ("Type","Owning User");
//critValues[2]	= ("TasksToPerform",userid);

critNames[0] = "Type";
critNames[1] = "Owning User";
critValues[0] = "TasksToPerform";
critValues[1] = userid;

ERROR_CALL( QRY_execute(query_object, 2, critNames, critValues, &num_found, &total_results) );

printf("\nTotal Tasks To perform Found : %d\n",num_found);fflush(stdout);

//ERROR_CALL(WSOM_describe(total_results[0], &desc));


ERROR_CALL(FL_ask_references(total_results[0],FL_fsc_by_date_modified ,&TotalSize,&Objects_Found));

printf("\nObjects under Tasks To perform Found : %d\n",TotalSize);
for (p=0;p<TotalSize ;p++ )
{
				ERROR_CALL(WSOM_ask_name(Objects_Found[p],taskName));
				ERROR_CALL(WSOM_ask_object_type(Objects_Found[p],type_name));
				ERROR_CALL(WSOM_ask_description(Objects_Found[p],JobName));
				ERROR_CALL(AOM_get_value_string(Objects_Found[p],"object_desc",&JobDesc));
				ERROR_CALL(AOM_ask_value_string(Objects_Found[p],"job_name",&JobTargerAttach));
				printf("\n Actual taskName [%s] and it type_name  Is [%s] and JobName :%s and JobDesc : %s\n",taskName,type_name,JobName,JobDesc);fflush(stdout);
				printf("\n JobTargerAttach is :%s\n",JobTargerAttach); fflush(stdout);
				
				if (tc_strcmp(JobTargerAttach,PassedFdr)==0)
				{
					printf("\nInside for : %s\n",JobTargerAttach);
					//ERROR_CALL(GRM_list_secondary_objects_only(Objects_Found[p],reln_type,&n_attchs,&attached_objects));
				//	ERROR_CALL(FL_ask_references(Objects_Found[p],FL_fsc_by_date_modified ,&n_attchs,&attached_objects));
					//printf("\n n_attchs iss :%d\n",n_attchs); fflush(stdout);
					//ERROR_CALL(GRM_list_all_related_objects ( Objects_Found[p],&n_attchs,&attached_objects));  
					//ERROR_CALL(EPM_ask_attachments(Objects_Found[p],EPM_target_attachment,&n_attchs,&attached_objects)); 

					//printf("\n n_attchs iss :%d\n",n_attchs); fflush(stdout);
					tWSOM_Find = NULLTAG;
					//tWSOM_Find[0] = NULLTAG;
					ERROR_CALL(AOM_ask_value_tags(Objects_Found[p],"root_target_attachments",&n_attchs,&tWSOM_Find)); 
					printf("\n n_attchs iss :%d and tWSOM_Find : %d tWSOM_Find[0] : %d tWSOM_Find[foundcnt] : %d\n",n_attchs,tWSOM_Find,tWSOM_Find[0],tWSOM_Find[foundcnt]); fflush(stdout);
				break;
				}
}
			foundcnt ==0;
			//ERROR_CALL(WSOM_ask_name(tWSOM_Find[foundcnt],DVO_Name));
			//ERROR_CALL(WSOM_ask_object_type(tWSOM_Find[foundcnt],DVO_Name_Type));
			//printf("\nDVO_Name [%s] and it Is [%s]\n",DVO_Name,DVO_Name_Type);fflush(stdout);

	if (n_attchs >= 1)
	{
		printf("\nPassed Folder Found Inside Home,So Get Requirement Folder Inside This\n");fflush(stdout);
		/* Expanding Found Folder To Get All Its Contents */
		ERROR_CALL(FL_ask_size(tWSOM_Find[0],&ReqFdrSize));
		ERROR_CALL(FL_ask_references(tWSOM_Find[0],FL_fsc_by_date_modified ,&ReqFdrSize1,&tReq_Find));
		/*Getting DVO Folder Tag*/
		DvoCountFdr = 0;
		iDvo_Fdr_Cnt = 0;
		iAbhiDvoCheck = 0;
		for (foundcnt2=0;foundcnt2<ReqFdrSize1;foundcnt2++)
		{
			ERROR_CALL(WSOM_ask_name(tReq_Find[foundcnt2],DVO_Name));
			ERROR_CALL(WSOM_ask_object_type(tReq_Find[foundcnt2],DVO_Name_Type));
			printf("\nDVO_Name [%s] and it Is [%s]\n",DVO_Name,DVO_Name_Type);fflush(stdout);
	
			if (tc_strcmp(DVO_Name_Type,"Folder")==0 && tc_strcmp(DVO_Name,"DVO")==0)
			{			
				printf("\nDVO Folder Tag\n");fflush(stdout);
				DvoCountFdr = 1;
				iDvo_Fdr_Cnt = 1;
				iAbhiDvoCheck = 1;
			}
			if (DvoCountFdr >= 1)
			{
				printf("\nFolder DVO Found Inside Passed Folder\n");fflush(stdout);
				break;
			}
		}
		if (iDvo_Fdr_Cnt == 0)
		{
			/*Creating DVO Folder*/
			ERROR_CALL(FL_create( aDvoFdrName, aDvoFdrDesc, &tDvoFolder ));
			ERROR_CALL(AOM_save( tDvoFolder ));
			//ERROR_CALL(FL_user_update_newstuff_folder( tDvoFolder ));
			ERROR_CALL(AOM_lock( tWSOM_Find[0] ));
			ERROR_CALL(FL_insert(tWSOM_Find[0],tDvoFolder,999));				
			ERROR_CALL(AOM_save( tWSOM_Find[0] ));
			ERROR_CALL(AOM_unlock( tWSOM_Find[0]));
			printf("\nNew DVO Folder Created Under Passed Folder\n");fflush(stdout);
		}
		/*Getting Requirement Folder */
		ReqFdrFound = 0;
		for (ReqCnt=0;ReqCnt<ReqFdrSize1;ReqCnt++)
		{
			ERROR_CALL(WSOM_ask_name(tReq_Find[ReqCnt],Req_Name));
			ERROR_CALL(WSOM_ask_object_type(tReq_Find[ReqCnt],Req_Name_Type));
			printf("\nReq_Name [%s] and it Is [%s]\n",Req_Name,Req_Name_Type);fflush(stdout);
			if (tc_strcmp(Req_Name_Type,"Folder")==0 && tc_strcmp(Req_Name,"Requirement")==0)
			{
				printf("\nRequirement Folder Found Inside Passed Folder\n");fflush(stdout);
				ReqFdrFound = 1;
				break;
			}
		}
		printf("\nValue of ReqFdrFound => [%d]\n",ReqFdrFound);fflush(stdout);
		if (ReqFdrFound == 1)
		{
			printf("\nRequirement Folder Found Inside Passed Folder, So Get All Its Content\n");fflush(stdout);
			/* Expanding Requirement Folder To Get All Its Contents */
			ERROR_CALL(FL_ask_size(tReq_Find[ReqCnt],&DvoReqFdrSize));
			ERROR_CALL(FL_ask_references(tReq_Find[ReqCnt],FL_fsc_by_date_modified ,&DvoReqFdrSize1,&tDvoReqRel_Find));
			printf("\nNumber of files found : %d\n",DvoReqFdrSize1);
			for (DvoReqCnt=0;DvoReqCnt<DvoReqFdrSize1;DvoReqCnt++)
			{
				ERROR_CALL(WSOM_ask_name(tDvoReqRel_Find[DvoReqCnt],DvoReqRel_Name));
				ERROR_CALL(WSOM_ask_object_type(tDvoReqRel_Find[DvoReqCnt],DvoReqRel_Name_Type));
				printf("\nDvoReqRel_Name [%s] and it Is [%s]\n",DvoReqRel_Name,DvoReqRel_Name_Type);fflush(stdout);
				
				if ((tc_strcmp(DvoReqRel_Name_Type,"Text")==0) && (tc_strcmp(DvoReqRel_Name,"requirement")==0))
				{
					printf("\nText FileFound Inside Passed-Requirement Folder\n");fflush(stdout);
					strcpy(NameRef,"Text");
					printf("\nNameRef : %s\n",NameRef);
					//strcpy(NameRefpath,"C:\\Temp\\");             //For Windows
					strcpy(NameRefpath,"/tmp/");
					strcat(NameRefpath,PassedFdr);
					strcat(NameRefpath,".txt");
					printf("\nNameRefpath : %s\n",NameRefpath);

					AE_export_named_ref  ( tDvoReqRel_Find[DvoReqCnt],NameRef,NameRefpath);
					
					strcpy(inputfile,NameRefpath);
					printf("\ninputfile : %s\n",inputfile);
					fp1=fopen(inputfile,"r");
					printf("\nFile Opened\n");
					if(fp1!=NULL)
					{
					inputline=(char *) MEM_alloc(500);
					while(fgets(inputline,500,fp1)!=NULL)
					{

						fputs(inputline,stdout);
                        requirementid=strtok(inputline,"^");
                        requirementpath=strtok(NULL,"^");

						printf("\nRequirement ID : %s and Requirement Path : %s\n",requirementid,requirementpath);
					
						ITEM_find_item (requirementid,&results);
						printf("\nNumber of Objects : %d\n",results);

					/*Get Revision Tag of Requirement Found*/
					ERROR_CALL(ITEM_find_revision(results,"A",&tReqRevTag)) ;
					/*Getting ReqID,ReqRevision,ReqName from Requirement Object*/
					ERROR_CALL(AOM_get_value_string(results,"item_id",&ReqID));
					ERROR_CALL(AOM_get_value_string(tReqRevTag,"item_revision_id",&ReqRev));
					ERROR_CALL(AOM_get_value_string(tReqRevTag,"t5ownattrgrp",&ReqOwnAttrGrp));
					ERROR_CALL(AOM_get_value_string(results,"object_name",&ReqName));


					/*Now Check If Requirement Has DVM Object in Relation*/
					/*Finding Whether IMAN_specification exist or not And getting Its Tag*/
					ReqDvmSpec = 0;
					ERROR_CALL(GRM_find_relation_type  ("IMAN_specification",&tRelationFind));
					GRM_list_secondary_objects_only (tReqRevTag,tRelationFind,&ReqRevRelCnt,&Secondary_Objects); 
					printf("\nTotal Secondary Objects Attached With Requirement Revision with IMAN_specification Relation => [%d]\n",ReqRevRelCnt);fflush(stdout);
					if (ReqRevRelCnt > 0)
					{
						printf("\nSome Specification Relation Present\n");fflush(stdout);
						for (ReqDvmCnt=0;ReqDvmCnt<ReqRevRelCnt;ReqDvmCnt++)
						{
							ERROR_CALL(WSOM_ask_name(Secondary_Objects[ReqDvmCnt],ReqDvmSpec_Name));
							ERROR_CALL(WSOM_ask_object_type(Secondary_Objects[ReqDvmCnt],ReqDvmSpec_Name_Type));
							printf("\nReqDvmSpec_Name [%s] and it Is [%s]\n",ReqDvmSpec_Name,ReqDvmSpec_Name_Type);fflush(stdout);
							if (tc_strcmp(ReqDvmSpec_Name_Type,"T5DvmRevision")==0 )
							{
								ReqDvmSpec = 1;
								DvoCount = 0;
								/*Now Creating Criteria Object*/
								/*Find Total Criteria Objects in Database*/

									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria1",&DvoCriteria1));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria2",&DvoCriteria2));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria3",&DvoCriteria3));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria4",&DvoCriteria4));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria5",&DvoCriteria5));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria6",&DvoCriteria6));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria7",&DvoCriteria7));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria8",&DvoCriteria8));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria9",&DvoCriteria9));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria10",&DvoCriteria10));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria11",&DvoCriteria11));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria12",&DvoCriteria12));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria13",&DvoCriteria13));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria14",&DvoCriteria14));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria15",&DvoCriteria15));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria16",&DvoCriteria16));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria17",&DvoCriteria17));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria18",&DvoCriteria18));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria19",&DvoCriteria19));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria20",&DvoCriteria20));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria21",&DvoCriteria21));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria22",&DvoCriteria22));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria23",&DvoCriteria23));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria24",&DvoCriteria24));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria25",&DvoCriteria25));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria26",&DvoCriteria26));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria27",&DvoCriteria27));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria28",&DvoCriteria28));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria29",&DvoCriteria29));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria30",&DvoCriteria30));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria31",&DvoCriteria31));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria32",&DvoCriteria32));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria33",&DvoCriteria33));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria34",&DvoCriteria34));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria35",&DvoCriteria35));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria36",&DvoCriteria36));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria37",&DvoCriteria37));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria38",&DvoCriteria38));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria39",&DvoCriteria39));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria40",&DvoCriteria40));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria41",&DvoCriteria41));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria42",&DvoCriteria42));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria43",&DvoCriteria43));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria44",&DvoCriteria44));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria45",&DvoCriteria45));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria46",&DvoCriteria46));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria47",&DvoCriteria47));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria48",&DvoCriteria48));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria49",&DvoCriteria49));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria50",&DvoCriteria50));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria51",&DvoCriteria51));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria52",&DvoCriteria52));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria53",&DvoCriteria53));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria54",&DvoCriteria54));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria55",&DvoCriteria55));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria56",&DvoCriteria56));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria57",&DvoCriteria57));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria58",&DvoCriteria58));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria59",&DvoCriteria59));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria60",&DvoCriteria60));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria61",&DvoCriteria61));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria62",&DvoCriteria62));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria63",&DvoCriteria63));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria64",&DvoCriteria64));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria65",&DvoCriteria65));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria66",&DvoCriteria66));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria67",&DvoCriteria67));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria68",&DvoCriteria68));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria69",&DvoCriteria69));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria70",&DvoCriteria70));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria71",&DvoCriteria71));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria72",&DvoCriteria72));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria73",&DvoCriteria73));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria74",&DvoCriteria74));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria75",&DvoCriteria75));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria76",&DvoCriteria76));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria77",&DvoCriteria77));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria78",&DvoCriteria78));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria79",&DvoCriteria79));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria80",&DvoCriteria80));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria81",&DvoCriteria81));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria82",&DvoCriteria82));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria83",&DvoCriteria83));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria84",&DvoCriteria84));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria85",&DvoCriteria85));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria86",&DvoCriteria86));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria87",&DvoCriteria87));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria88",&DvoCriteria88));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria89",&DvoCriteria89));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria90",&DvoCriteria90));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria91",&DvoCriteria91));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria92",&DvoCriteria92));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria93",&DvoCriteria93));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria94",&DvoCriteria94));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria95",&DvoCriteria95));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria96",&DvoCriteria96));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria97",&DvoCriteria97));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria98",&DvoCriteria98));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria99",&DvoCriteria99));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria100",&DvoCriteria100));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria101",&DvoCriteria101));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria102",&DvoCriteria102));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria103",&DvoCriteria103));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria104",&DvoCriteria104));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria105",&DvoCriteria105));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria106",&DvoCriteria106));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria107",&DvoCriteria107));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria108",&DvoCriteria108));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria109",&DvoCriteria109));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria110",&DvoCriteria110));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria111",&DvoCriteria111));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria112",&DvoCriteria112));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria113",&DvoCriteria113));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria114",&DvoCriteria114));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria115",&DvoCriteria115));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria116",&DvoCriteria116));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria117",&DvoCriteria117));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria118",&DvoCriteria118));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria119",&DvoCriteria119));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria120",&DvoCriteria120));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria121",&DvoCriteria121));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria122",&DvoCriteria122));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria123",&DvoCriteria123));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria124",&DvoCriteria124));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria125",&DvoCriteria125));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria126",&DvoCriteria126));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria127",&DvoCriteria127));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria128",&DvoCriteria128));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria129",&DvoCriteria129));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria130",&DvoCriteria130));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria131",&DvoCriteria131));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria132",&DvoCriteria132));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria133",&DvoCriteria133));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria134",&DvoCriteria134));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria135",&DvoCriteria135));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria136",&DvoCriteria136));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria137",&DvoCriteria137));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria138",&DvoCriteria138));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria139",&DvoCriteria139));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria140",&DvoCriteria140));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria141",&DvoCriteria141));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria142",&DvoCriteria142));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria143",&DvoCriteria143));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria144",&DvoCriteria144));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria145",&DvoCriteria145));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria146",&DvoCriteria146));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria147",&DvoCriteria147));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria148",&DvoCriteria148));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria149",&DvoCriteria149));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria150",&DvoCriteria150));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria151",&DvoCriteria151));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria152",&DvoCriteria152));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria153",&DvoCriteria153));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria154",&DvoCriteria154));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria155",&DvoCriteria155));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria156",&DvoCriteria156));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria157",&DvoCriteria157));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria158",&DvoCriteria158));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria159",&DvoCriteria159));
									ERROR_CALL(AOM_UIF_ask_value(Secondary_Objects[ReqDvmCnt],"t5dvocriteria160",&DvoCriteria160));
									
									strcpy(CrDesc,"(For Requirement:");
									strcat(CrDesc,ReqName);
									strcat(CrDesc,")");
									

									WSOM_clear_search_criteria(&mastercriteria);
									strcpy(mastercriteria.class_name,"T5masterdataRevision");
									ERROR_CALL(WSOM_search(mastercriteria, &number_found,&list_of_WSO_tags));
									printf(" \n Number of Criterias Found in Master Data %d\n",number_found);fflush(stdout); 
									/*
									printf("\nValue of Criteria NAME : %s\n",DvoCriteria1);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria2);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria3);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria4);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria5);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria6);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria7);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria8);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria9);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria10);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria11);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria12);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria13);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria14);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria15);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria16);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria17);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria18);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria19);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria20);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria21);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria22);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria23);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria24);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria25);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria26);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria27);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria28);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria29);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria30);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria31);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria32);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria33);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria34);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria35);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria36);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria37);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria38);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria39);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria40);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria41);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria42);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria43);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria44);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria45);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria46);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria47);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria48);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria49);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria50);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria51);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria52);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria53);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria54);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria55);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria56);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria57);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria58);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria59);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria60);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria61);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria62);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria63);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria64);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria65);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria66);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria67);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria68);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria69);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria70);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria71);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria72);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria73);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria74);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria75);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria76);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria77);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria78);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria79);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria80);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria81);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria82);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria83);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria84);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria85);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria86);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria87);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria88);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria89);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria90);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria91);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria92);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria93);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria94);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria95);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria96);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria97);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria98);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria99);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria100);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria101);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria102);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria103);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria104);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria105);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria106);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria107);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria108);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria109);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria110);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria111);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria112);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria113);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria114);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria115);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria116);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria117);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria118);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria119);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria120);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria121);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria122);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria123);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria124);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria125);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria126);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria127);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria128);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria129);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria130);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria131);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria132);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria133);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria134);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria135);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria136);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria137);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria138);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria139);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria140);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria141);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria142);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria143);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria144);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria145);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria146);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria147);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria148);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria149);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria150);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria151);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria152);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria153);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria154);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria155);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria156);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria157);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria158);	
									printf("\nValue of DVO NAME : %s\n",DvoCriteria159);
									printf("\nValue of DVO NAME : %s\n",DvoCriteria160);
									*/

									//if(DvoCriteria1)
										if(strcmp(DvoCriteria1,""))
									 {
										printf("\nValue of Criteria NAME 1: %s\n",DvoCriteria1);
										ERROR_CALL(FORM_create( DvoCriteria1,CrDesc,"T5critera",&tCrItem1));
										ERROR_CALL(AOM_save(tCrItem1));
										
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria1)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem1,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem1,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem1,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem1,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem1,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem1));
									}

									//if (DvoCriteria2)
										if(strcmp(DvoCriteria2,""))
									{
										printf("\nValue of Criteria NAME 2: %s\n",DvoCriteria2);
										ERROR_CALL(FORM_create( DvoCriteria2,CrDesc,"T5critera",&tCrItem2));
										ERROR_CALL(AOM_save(tCrItem2));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											////printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria2)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem2,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem2,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem2,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem2,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem2,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem2));
									}
									//if (DvoCriteria3)
										if(strcmp(DvoCriteria3,""))
									{
										printf("\nValue of Criteria NAME 3: %s\n",DvoCriteria3);
										ERROR_CALL(FORM_create( DvoCriteria3,CrDesc,"T5critera",&tCrItem3));
										ERROR_CALL(AOM_save(tCrItem3));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											////printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria3)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem3,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem3,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem3,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem3,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem3,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem3));
									}
									//if (DvoCriteria4)
										if(strcmp(DvoCriteria4,""))
									{
										printf("\nValue of Criteria NAME 4: %s\n",DvoCriteria4);
										ERROR_CALL(FORM_create( DvoCriteria4,CrDesc,"T5critera",&tCrItem4));
										ERROR_CALL(AOM_save(tCrItem4));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											////printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria4)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem4,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem4,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem4,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem4,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem4,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem4));
									}
									//if (DvoCriteria5)
									if(strcmp(DvoCriteria5,""))
									{
										printf("\nValue of Criteria NAME 5: %s\n",DvoCriteria5);
										ERROR_CALL(FORM_create( DvoCriteria5,CrDesc,"T5critera",&tCrItem5));
										ERROR_CALL(AOM_save(tCrItem5));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											////printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria5)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem5,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem5,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem5,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem5,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem5,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem5));
									}
									//if (DvoCriteria6)
										if(strcmp(DvoCriteria6,""))
									{
										printf("\nValue of Criteria NAME 6: %s\n",DvoCriteria6);
										ERROR_CALL(FORM_create( DvoCriteria6,CrDesc,"T5critera",&tCrItem6));
										ERROR_CALL(AOM_save(tCrItem6));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											////printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria6)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem6,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem6,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem6,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem6,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem6,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem6));
									}
									//if (DvoCriteria7)
										if(strcmp(DvoCriteria7,""))
									{
										printf("\nValue of Criteria NAME 7: %s\n",DvoCriteria7);
										ERROR_CALL(FORM_create( DvoCriteria7,CrDesc,"T5critera",&tCrItem7));
										ERROR_CALL(AOM_save(tCrItem7));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											////printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria7)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem7,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem7,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem7,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem7,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem7,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem7));
									}
									//if (DvoCriteria8)
										if(strcmp(DvoCriteria8,""))
									{
										printf("\nValue of Criteria NAME 8: %s\n",DvoCriteria8);
										ERROR_CALL(FORM_create( DvoCriteria8,CrDesc,"T5critera",&tCrItem8));
										ERROR_CALL(AOM_save(tCrItem8));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											////printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria8)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem8,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem8,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem8,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem8,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem8,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem8));
									}
									//if (DvoCriteria9)
									if(strcmp(DvoCriteria9,""))
									{
										printf("\nValue of Criteria NAME 9: %s\n",DvoCriteria9);
										ERROR_CALL(FORM_create( DvoCriteria9,CrDesc,"T5critera",&tCrItem9));
										ERROR_CALL(AOM_save(tCrItem9));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											////printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria9)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem9,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem9,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem9,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem9,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem9,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem9));
									}
									//if (DvoCriteria10)
									if(strcmp(DvoCriteria10,""))
									{
										printf("\nValue of Criteria NAME 10: %s\n",DvoCriteria10);
										ERROR_CALL(FORM_create( DvoCriteria10,CrDesc,"T5critera",&tCrItem10));
										ERROR_CALL(AOM_save(tCrItem10));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria10)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem10,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem10,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem10,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem10,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem10,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem10));
									}
									//if (DvoCriteria11)
									if(strcmp(DvoCriteria11,""))
									{
										printf("\nValue of Criteria NAME 11: %s\n",DvoCriteria11);
										ERROR_CALL(FORM_create( DvoCriteria11,CrDesc,"T5critera",&tCrItem11));
										ERROR_CALL(AOM_save(tCrItem11));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria11)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem11,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem11,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem11,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem11,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem11,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem11));
									}
									//if (DvoCriteria12)
									if(strcmp(DvoCriteria12,""))
									{
										printf("\nValue of Criteria NAME 12: %s\n",DvoCriteria12);
										ERROR_CALL(FORM_create( DvoCriteria12,CrDesc,"T5critera",&tCrItem12));
										ERROR_CALL(AOM_save(tCrItem12));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria12)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem12,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem12,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem12,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem12,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem12,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem12));
									}
									//if (DvoCriteria13)
									if(strcmp(DvoCriteria13,""))
									{
										printf("\nValue of Criteria NAME 13: %s\n",DvoCriteria13);
										ERROR_CALL(FORM_create( DvoCriteria13,CrDesc,"T5critera",&tCrItem13));
										ERROR_CALL(AOM_save(tCrItem13));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria13)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem13,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem13,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem13,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem13,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem13,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem13));
									}
									//if (DvoCriteria14)
									if(strcmp(DvoCriteria14,""))
									{
										printf("\nValue of Criteria NAME 14: %s\n",DvoCriteria14);
										ERROR_CALL(FORM_create( DvoCriteria14,CrDesc,"T5critera",&tCrItem14));
										ERROR_CALL(AOM_save(tCrItem14));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria14)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem14,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem14,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem14,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem14,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem14,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem14));
									}
									//if (DvoCriteria15)
									if(strcmp(DvoCriteria15,""))
									{
										printf("\nValue of Criteria NAME 15: %s\n",DvoCriteria15);
										ERROR_CALL(FORM_create( DvoCriteria15,CrDesc,"T5critera",&tCrItem15));
										ERROR_CALL(AOM_save(tCrItem15));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria15)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem15,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem15,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem15,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem15,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem15,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem15));
									}
									//if (DvoCriteria16)
									if(strcmp(DvoCriteria16,""))
									{
										printf("\nValue of Criteria NAME 16: %s\n",DvoCriteria16);
										ERROR_CALL(FORM_create( DvoCriteria16,CrDesc,"T5critera",&tCrItem16));
										ERROR_CALL(AOM_save(tCrItem16));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria16)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem16,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem16,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem16,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem16,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem16,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem16));
									}
									//if (DvoCriteria17)
									if(strcmp(DvoCriteria17,""))
									{
										printf("\nValue of Criteria NAME 17: %s\n",DvoCriteria17);
										ERROR_CALL(FORM_create( DvoCriteria17,CrDesc,"T5critera",&tCrItem17));
										ERROR_CALL(AOM_save(tCrItem17));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria17)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem17,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem17,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem17,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem17,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem17,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem17));
									}
									//if (DvoCriteria18)
									if(strcmp(DvoCriteria18,""))
									{
										printf("\nValue of Criteria NAME 18: %s\n",DvoCriteria18);
										ERROR_CALL(FORM_create( DvoCriteria18,CrDesc,"T5critera",&tCrItem18));
										ERROR_CALL(AOM_save(tCrItem18));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria18)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem18,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem18,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem18,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem18,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem18,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem18));
									}
									//if (DvoCriteria19)
									if(strcmp(DvoCriteria19,""))
									{
										printf("\nValue of Criteria NAME 19: %s\n",DvoCriteria19);
										ERROR_CALL(FORM_create( DvoCriteria19,CrDesc,"T5critera",&tCrItem19));
										ERROR_CALL(AOM_save(tCrItem19));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria19)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem19,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem19,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem19,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem19,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem19,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem19));
									}
									//if (DvoCriteria20)
									if(strcmp(DvoCriteria20,""))
									{
										printf("\nValue of Criteria NAME 20: %s\n",DvoCriteria20);
										ERROR_CALL(FORM_create( DvoCriteria20,CrDesc,"T5critera",&tCrItem20));
										ERROR_CALL(AOM_save(tCrItem20));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria20)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem20,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem20,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem20,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem20,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem20,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem20));
									}
									
									//if (DvoCriteria21)
									if(strcmp(DvoCriteria21,""))
									{
										printf("\nValue of Criteria NAME 21: %s\n",DvoCriteria21);
										ERROR_CALL(FORM_create( DvoCriteria21,CrDesc,"T5critera",&tCrItem21));
										ERROR_CALL(AOM_save(tCrItem21));
										
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria21)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem21,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem21,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem21,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem21,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem21,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem21));

									}
									//if (DvoCriteria22)
									if(strcmp(DvoCriteria22,""))
									{
										printf("\nValue of Criteria NAME 22: %s\n",DvoCriteria22);
										ERROR_CALL(FORM_create( DvoCriteria22,CrDesc,"T5critera",&tCrItem22));
										ERROR_CALL(AOM_save(tCrItem22));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria22)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem22,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem22,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem22,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem22,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem22,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem22));
									}
									//if (DvoCriteria23)
									if(strcmp(DvoCriteria23,""))
									{
										printf("\nValue of Criteria NAME 23: %s\n",DvoCriteria23);
										ERROR_CALL(FORM_create( DvoCriteria23,CrDesc,"T5critera",&tCrItem23));
										ERROR_CALL(AOM_save(tCrItem23));
										
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria23)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem23,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem23,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem23,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem23,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem23,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem23));

									}
								//	if (DvoCriteria24)
									if(strcmp(DvoCriteria24,""))
									{
										printf("\nValue of Criteria NAME 24: %s\n",DvoCriteria24);
										ERROR_CALL(FORM_create( DvoCriteria24,CrDesc,"T5critera",&tCrItem24));
										ERROR_CALL(AOM_save(tCrItem24));
										
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											
											if(strcmp(mastercriteriadata,DvoCriteria24)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											printf(" \n  Setting criteria attributes 24 %s\n",mastercriteriatype);fflush(stdout);
											ERROR_CALL(AOM_set_value_string(tCrItem24,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem24,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem24,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem24,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem24,"t5targetcategory",mastercriteriatype));

											printf(" \n  After Setting criteria attributes 24 %s\n",mastercriteriatype);fflush(stdout);
											ERROR_CALL(AOM_save(tCrItem24));
											printf(" \n  After Save 24 %s\n",mastercriteriatype);fflush(stdout);
									}
//									if (DvoCriteria25)
									if(strcmp(DvoCriteria25,""))
									{
										printf("\nValue of Criteria NAME 25: %s\n",DvoCriteria25);
										ERROR_CALL(FORM_create( DvoCriteria25,CrDesc,"T5critera",&tCrItem25));
										ERROR_CALL(AOM_save(tCrItem25));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria25)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem25,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem25,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem25,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem25,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem25,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem25));
									}
									//if (DvoCriteria26)
									if(strcmp(DvoCriteria26,""))
									{
										printf("\nValue of Criteria NAME 26: %s\n",DvoCriteria26);
										ERROR_CALL(FORM_create( DvoCriteria26,CrDesc,"T5critera",&tCrItem26));
										ERROR_CALL(AOM_save(tCrItem26));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria26)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem26,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem26,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem26,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem26,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem26,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem26));
									}
									//if (DvoCriteria27)
									if(strcmp(DvoCriteria27,""))
									{
										printf("\nValue of Criteria NAME 27: %s\n",DvoCriteria27);
										ERROR_CALL(FORM_create( DvoCriteria27,CrDesc,"T5critera",&tCrItem27));
										ERROR_CALL(AOM_save(tCrItem27));
										
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria27)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem27,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem27,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem27,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem27,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem27,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem27));

									}
									//if (DvoCriteria28)
									if(strcmp(DvoCriteria28,""))
									{
										printf("\nValue of Criteria NAME 28: %s\n",DvoCriteria28);
										ERROR_CALL(FORM_create( DvoCriteria28,CrDesc,"T5critera",&tCrItem28));
										ERROR_CALL(AOM_save(tCrItem28));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria28)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem28,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem28,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem28,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem28,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem28,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem28));
									}
									//if (DvoCriteria29)
									if(strcmp(DvoCriteria29,""))
									{
										printf("\nValue of Criteria NAME 29: %s\n",DvoCriteria29);
										ERROR_CALL(FORM_create( DvoCriteria29,CrDesc,"T5critera",&tCrItem29));
										ERROR_CALL(AOM_save(tCrItem29));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria29)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem29,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem29,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem29,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem29,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem29,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem29));
									}
									//if (DvoCriteria30)
									if(strcmp(DvoCriteria30,""))
									{
										printf("\nValue of Criteria NAME 30: %s\n",DvoCriteria30);
										ERROR_CALL(FORM_create( DvoCriteria30,CrDesc,"T5critera",&tCrItem30));
										ERROR_CALL(AOM_save(tCrItem30));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria30)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem30,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem30,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem30,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem30,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem30,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem30));
									}

									//if (DvoCriteria31)
									if(strcmp(DvoCriteria31,""))
									{
										printf("\nValue of Criteria NAME 31: %s\n",DvoCriteria31);
										ERROR_CALL(FORM_create( DvoCriteria31,CrDesc,"T5critera",&tCrItem31));
										ERROR_CALL(AOM_save(tCrItem31));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria31)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem31,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem31,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem31,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem31,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem31,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem31));
									}
									//if (DvoCriteria32)
									if(strcmp(DvoCriteria32,""))
									{
										printf("\nValue of Criteria NAME 32: %s\n",DvoCriteria32);
										ERROR_CALL(FORM_create( DvoCriteria32,CrDesc,"T5critera",&tCrItem32));
										ERROR_CALL(AOM_save(tCrItem32));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria32)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem32,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem32,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem32,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem32,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem32,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem32));
									}
									//if (DvoCriteria33)
									if(strcmp(DvoCriteria33,""))
									{
										printf("\nValue of Criteria NAME 33: %s\n",DvoCriteria33);
										ERROR_CALL(FORM_create( DvoCriteria33,CrDesc,"T5critera",&tCrItem33));
										ERROR_CALL(AOM_save(tCrItem33));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria33)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem33,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem33,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem33,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem33,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem33,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem33));
									}	
									//if (DvoCriteria34)
									if(strcmp(DvoCriteria34,""))
									{
										printf("\nValue of Criteria NAME 34: %s\n",DvoCriteria34);
										ERROR_CALL(FORM_create( DvoCriteria34,CrDesc,"T5critera",&tCrItem34));
										ERROR_CALL(AOM_save(tCrItem34));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria34)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem34,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem34,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem34,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem34,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem34,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem34));
									}
									//if (DvoCriteria35)
									if(strcmp(DvoCriteria35,""))
									{
										printf("\nValue of Criteria NAME 35: %s\n",DvoCriteria35);
										ERROR_CALL(FORM_create( DvoCriteria35,CrDesc,"T5critera",&tCrItem35));
										ERROR_CALL(AOM_save(tCrItem35));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria35)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem35,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem35,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem35,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem35,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem35,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem35));
									}
									//if (DvoCriteria36)
									if(strcmp(DvoCriteria36,""))
									{
										printf("\nValue of Criteria NAME 36: %s\n",DvoCriteria36);
										ERROR_CALL(FORM_create( DvoCriteria36,CrDesc,"T5critera",&tCrItem36));
										ERROR_CALL(AOM_save(tCrItem36));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria36)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem36,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem36,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem36,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem36,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem36,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem36));
									}
									//if (DvoCriteria37)
									if(strcmp(DvoCriteria37,""))
									{
										printf("\nValue of Criteria NAME 37: %s\n",DvoCriteria37);
										ERROR_CALL(FORM_create( DvoCriteria37,CrDesc,"T5critera",&tCrItem37));
										ERROR_CALL(AOM_save(tCrItem37));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria37)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem37,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem37,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem37,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem37,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem37,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem37));
									}
									//if (DvoCriteria38)
									if(strcmp(DvoCriteria38,""))
									{
										printf("\nValue of Criteria NAME 38: %s\n",DvoCriteria38);
										ERROR_CALL(FORM_create( DvoCriteria38,CrDesc,"T5critera",&tCrItem38));
										ERROR_CALL(AOM_save(tCrItem38));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria38)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem38,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem38,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem38,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem38,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem38,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem38));
									}
									//if (DvoCriteria39)
									if(strcmp(DvoCriteria39,""))
									{
										printf("\nValue of Criteria NAME 39: %s\n",DvoCriteria39);
										ERROR_CALL(FORM_create( DvoCriteria39,CrDesc,"T5critera",&tCrItem39));
										ERROR_CALL(AOM_save(tCrItem39));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria39)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem39,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem39,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem39,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem39,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem39,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem39));
									}
									//if (DvoCriteria40)
									if(strcmp(DvoCriteria40,""))
									{
										printf("\nValue of Criteria NAME 40: %s\n",DvoCriteria40);
										ERROR_CALL(FORM_create( DvoCriteria40,CrDesc,"T5critera",&tCrItem40));
										ERROR_CALL(AOM_save(tCrItem40));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria40)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
										}
											ERROR_CALL(AOM_set_value_string(tCrItem40,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem40,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem40,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem40,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem40,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem40));
									}
									//if (DvoCriteria41)
									if(strcmp(DvoCriteria41,""))
									{
										printf("\nValue of Criteria NAME 41: %s\n",DvoCriteria41);
										ERROR_CALL(FORM_create( DvoCriteria41,CrDesc,"T5critera",&tCrItem41));
										ERROR_CALL(AOM_save(tCrItem41));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria41)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem41,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem41,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem41,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem41,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem41,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem41));
									}
									//if (DvoCriteria42)
									if(strcmp(DvoCriteria42,""))
									{
										printf("\nValue of Criteria NAME 42: %s\n",DvoCriteria42);
										ERROR_CALL(FORM_create( DvoCriteria42,CrDesc,"T5critera",&tCrItem42));
										ERROR_CALL(AOM_save(tCrItem42));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria42)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem42,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem42,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem42,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem42,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem42,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem42));
									}
									//if (DvoCriteria43)
									if(strcmp(DvoCriteria43,""))
									{
										printf("\nValue of Criteria NAME 43: %s\n",DvoCriteria43);
										ERROR_CALL(FORM_create( DvoCriteria43,CrDesc,"T5critera",&tCrItem43));
										ERROR_CALL(AOM_save(tCrItem43));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria43)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem43,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem43,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem43,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem43,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem43,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem43));
									}
									//if (DvoCriteria44)
									if(strcmp(DvoCriteria44,""))
									{
										printf("\nValue of Criteria NAME 44: %s\n",DvoCriteria44);
										ERROR_CALL(FORM_create( DvoCriteria44,CrDesc,"T5critera",&tCrItem44));
										ERROR_CALL(AOM_save(tCrItem44));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria44)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem44,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem44,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem44,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem44,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem44,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem44));
									}
									//if (DvoCriteria45)
									if(strcmp(DvoCriteria45,""))
									{
										printf("\nValue of Criteria NAME 45: %s\n",DvoCriteria45);
										ERROR_CALL(FORM_create( DvoCriteria45,CrDesc,"T5critera",&tCrItem45));
										ERROR_CALL(AOM_save(tCrItem45));
										
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria45)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem45,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem45,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem45,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem45,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem45,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem45));

									}
									//if (DvoCriteria46)
									if(strcmp(DvoCriteria46,""))
									{
										printf("\nValue of Criteria NAME : %s\n",DvoCriteria46);
										ERROR_CALL(FORM_create( DvoCriteria46,CrDesc,"T5critera",&tCrItem46));
										ERROR_CALL(AOM_save(tCrItem46));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria46)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem46,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem46,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem46,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem46,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem46,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem46));
									}
									//if (DvoCriteria47)
									if(strcmp(DvoCriteria47,""))
									{
										printf("\nValue of Criteria NAME 47: %s\n",DvoCriteria47);
										ERROR_CALL(FORM_create( DvoCriteria47,CrDesc,"T5critera",&tCrItem47));
										ERROR_CALL(AOM_save(tCrItem47));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria47)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem47,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem47,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem47,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem47,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem47,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem47));
									}
									//if (DvoCriteria48)
									if(strcmp(DvoCriteria48,""))
									{
										printf("\nValue of Criteria NAME 48: %s\n",DvoCriteria48);
										ERROR_CALL(FORM_create( DvoCriteria48,CrDesc,"T5critera",&tCrItem48));
										ERROR_CALL(AOM_save(tCrItem48));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria48)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem48,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem48,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem48,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem48,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem48,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem48));
									}
									//if (DvoCriteria49)
									if(strcmp(DvoCriteria49,""))
									{
										printf("\nValue of Criteria NAME 49: %s\n",DvoCriteria49);
										ERROR_CALL(FORM_create( DvoCriteria49,CrDesc,"T5critera",&tCrItem49));
										ERROR_CALL(AOM_save(tCrItem49));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria49)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem49,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem49,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem49,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem49,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem49,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem49));
									}
									//if (DvoCriteria50)
									if(strcmp(DvoCriteria50,""))
									{
										printf("\nValue of Criteria NAME 50: %s\n",DvoCriteria50);
										ERROR_CALL(FORM_create( DvoCriteria50,CrDesc,"T5critera",&tCrItem50));
										ERROR_CALL(AOM_save(tCrItem50));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria50)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem50,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem50,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem50,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem50,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem50,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem50));
									}
									
									//if (DvoCriteria51)
										if(strcmp(DvoCriteria51,""))
										{
										printf("\nValue of Criteria NAME 51: %s\n",DvoCriteria50);
										ERROR_CALL(FORM_create( DvoCriteria51,CrDesc,"T5critera",&tCrItem51));
										ERROR_CALL(AOM_save(tCrItem51));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria51)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem51,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem51,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem51,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem51,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem51,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem51));
									}
									//if (DvoCriteria52)
										if(strcmp(DvoCriteria52,""))
									{
										printf("\nValue of Criteria NAME 52: %s\n",DvoCriteria52);
										ERROR_CALL(FORM_create( DvoCriteria52,CrDesc,"T5critera",&tCrItem52));
										ERROR_CALL(AOM_save(tCrItem52));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria52)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem52,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem52,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem52,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem52,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem52,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem52));
									}
									//if (DvoCriteria53)
									if(strcmp(DvoCriteria53,""))
									{
										printf("\nValue of Criteria NAME 53: %s\n",DvoCriteria53);
										ERROR_CALL(FORM_create( DvoCriteria53,CrDesc,"T5critera",&tCrItem53));
										ERROR_CALL(AOM_save(tCrItem53));
										
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria53)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem53,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem53,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem53,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem53,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem53,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem53));
									}
									//if (DvoCriteria54)
									if(strcmp(DvoCriteria54,""))
									{
										printf("\nValue of Criteria NAME 54: %s\n",DvoCriteria54);
										ERROR_CALL(FORM_create( DvoCriteria54,CrDesc,"T5critera",&tCrItem54));
										ERROR_CALL(AOM_save(tCrItem54));
										
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria54)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem54,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem54,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem54,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem54,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem54,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem54));
									}
									//if (DvoCriteria55)
									if(strcmp(DvoCriteria55,""))
									{
										printf("\nValue of Criteria NAME 55: %s\n",DvoCriteria55);
										ERROR_CALL(FORM_create( DvoCriteria55,CrDesc,"T5critera",&tCrItem55));
										ERROR_CALL(AOM_save(tCrItem55));
										
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria55)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem55,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem55,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem55,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem55,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem55,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem55));
									}
									//if (DvoCriteria56)
									if(strcmp(DvoCriteria56,""))
									{
										printf("\nValue of Criteria NAME 56: %s\n",DvoCriteria56);
										ERROR_CALL(FORM_create( DvoCriteria56,CrDesc,"T5critera",&tCrItem56));
										ERROR_CALL(AOM_save(tCrItem56));
										
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria56)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem56,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem56,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem56,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem56,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem56,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem56));
									}
									//if (DvoCriteria57)
									if(strcmp(DvoCriteria57,""))
									{
										printf("\nValue of Criteria NAME 57: %s\n",DvoCriteria57);
										ERROR_CALL(FORM_create( DvoCriteria57,CrDesc,"T5critera",&tCrItem57));
										ERROR_CALL(AOM_save(tCrItem57));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria57)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem57,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem57,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem57,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem57,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem57,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem57));
									}
									//if (DvoCriteria58)
									if(strcmp(DvoCriteria58,""))
									{
										printf("\nValue of Criteria NAME 58: %s\n",DvoCriteria58);
										ERROR_CALL(FORM_create( DvoCriteria58,CrDesc,"T5critera",&tCrItem58));
										ERROR_CALL(AOM_save(tCrItem58));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria58)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem58,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem58,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem58,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem58,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem58,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem58));
									}
									//if (DvoCriteria59)
									if(strcmp(DvoCriteria59,""))
									{
										printf("\nValue of Criteria NAME 59: %s\n",DvoCriteria59);
										ERROR_CALL(FORM_create( DvoCriteria59,CrDesc,"T5critera",&tCrItem59));
										ERROR_CALL(AOM_save(tCrItem59));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria59)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem59,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem59,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem59,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem59,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem59,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem59));
									}
									//if (DvoCriteria60)
									if(strcmp(DvoCriteria60,""))
									{
										printf("\nValue of Criteria NAME 60: %s\n",DvoCriteria60);
										ERROR_CALL(FORM_create( DvoCriteria60,CrDesc,"T5critera",&tCrItem60));
										ERROR_CALL(AOM_save(tCrItem60));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria60)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem60,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem60,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem60,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem60,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem60,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem60));
									}
									//if (DvoCriteria61)
									if(strcmp(DvoCriteria61,""))
									{
										printf("\nValue of Criteria NAME 61: %s\n",DvoCriteria61);
										ERROR_CALL(FORM_create( DvoCriteria61,CrDesc,"T5critera",&tCrItem61));
										ERROR_CALL(AOM_save(tCrItem61));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria61)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem61,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem61,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem61,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem61,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem61,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem61));
									}
									//if (DvoCriteria62)
									if(strcmp(DvoCriteria62,""))
									{
										printf("\nValue of Criteria NAME 62: %s\n",DvoCriteria62);
										ERROR_CALL(FORM_create( DvoCriteria62,CrDesc,"T5critera",&tCrItem62));
										ERROR_CALL(AOM_save(tCrItem62));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria62)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem62,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem62,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem62,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem62,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem62,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem62));
									}
									//if (DvoCriteria63)
									if(strcmp(DvoCriteria63,""))
									{
										printf("\nValue of Criteria NAME 63: %s\n",DvoCriteria63);
										ERROR_CALL(FORM_create( DvoCriteria63,CrDesc,"T5critera",&tCrItem63));
										ERROR_CALL(AOM_save(tCrItem63));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria63)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem63,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem63,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem63,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem63,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem63,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem63));
									}
									//if (DvoCriteria64)
									if(strcmp(DvoCriteria64,""))
									{
										printf("\nValue of Criteria NAME 64: %s\n",DvoCriteria64);
										ERROR_CALL(FORM_create( DvoCriteria64,CrDesc,"T5critera",&tCrItem64));
										ERROR_CALL(AOM_save(tCrItem64));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria64)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem64,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem64,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem64,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem64,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem64,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem64));
									}
									//if (DvoCriteria65)
									if(strcmp(DvoCriteria65,""))
									{
										printf("\nValue of Criteria NAME 65: %s\n",DvoCriteria65);
										ERROR_CALL(FORM_create( DvoCriteria65,CrDesc,"T5critera",&tCrItem65));
										ERROR_CALL(AOM_save(tCrItem65));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria65)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem65,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem65,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem65,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem65,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem65,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem65));
									}
									//if (DvoCriteria66)
									if(strcmp(DvoCriteria66,""))
									{
										printf("\nValue of Criteria NAME 66: %s\n",DvoCriteria66);
										ERROR_CALL(FORM_create( DvoCriteria66,CrDesc,"T5critera",&tCrItem66));
										ERROR_CALL(AOM_save(tCrItem66));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria66)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem66,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem66,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem66,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem66,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem66,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem66));
									}
									//if (DvoCriteria67)
									if(strcmp(DvoCriteria67,""))
									{
										printf("\nValue of Criteria NAME 67: %s\n",DvoCriteria67);
										ERROR_CALL(FORM_create( DvoCriteria67,CrDesc,"T5critera",&tCrItem67));
										ERROR_CALL(AOM_save(tCrItem67));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria67)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem67,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem67,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem67,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem67,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem67,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem67));
									}
									//if (DvoCriteria68)
									if(strcmp(DvoCriteria68,""))
									{
										printf("\nValue of Criteria NAME 68: %s\n",DvoCriteria68);
										ERROR_CALL(FORM_create( DvoCriteria68,CrDesc,"T5critera",&tCrItem68));
										ERROR_CALL(AOM_save(tCrItem68));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria68)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem68,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem68,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem68,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem68,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem68,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem68));
									}
									//if (DvoCriteria69)
									if(strcmp(DvoCriteria69,""))
									{
										printf("\nValue of Criteria NAME 69: %s\n",DvoCriteria69);
										ERROR_CALL(FORM_create( DvoCriteria69,CrDesc,"T5critera",&tCrItem69));
										ERROR_CALL(AOM_save(tCrItem69));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria69)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem69,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem69,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem69,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem69,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem69,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem69));
									}
									//if (DvoCriteria70)
									if(strcmp(DvoCriteria70,""))
									{
										printf("\nValue of Criteria NAME 70: %s\n",DvoCriteria70);
										ERROR_CALL(FORM_create( DvoCriteria70,CrDesc,"T5critera",&tCrItem70));
										ERROR_CALL(AOM_save(tCrItem70));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria70)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem70,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem70,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem70,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem70,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem70,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem70));
									}								
									//if (DvoCriteria71)
									if(strcmp(DvoCriteria71,""))
									{
										printf("\nValue of Criteria NAME 71: %s\n",DvoCriteria71);
										ERROR_CALL(FORM_create( DvoCriteria71,CrDesc,"T5critera",&tCrItem71));
										ERROR_CALL(AOM_save(tCrItem71));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria71)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem71,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem71,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem71,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem71,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem71,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem71));
									}
									//if (DvoCriteria72)
									if(strcmp(DvoCriteria72,""))
									{
										printf("\nValue of Criteria NAME 72: %s\n",DvoCriteria72);
										ERROR_CALL(FORM_create( DvoCriteria72,CrDesc,"T5critera",&tCrItem72));
										ERROR_CALL(AOM_save(tCrItem72));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria72)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem72,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem72,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem72,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem72,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem72,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem72));
									}
									//if (DvoCriteria73)
									if(strcmp(DvoCriteria73,""))
									{
										printf("\nValue of Criteria NAME 73: %s\n",DvoCriteria73);
										ERROR_CALL(FORM_create( DvoCriteria73,CrDesc,"T5critera",&tCrItem73));
										ERROR_CALL(AOM_save(tCrItem73));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria73)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem73,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem73,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem73,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem73,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem73,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem73));
									}
									//if (DvoCriteria74)
									if(strcmp(DvoCriteria74,""))
									{
										printf("\nValue of Criteria NAME 74: %s\n",DvoCriteria74);
										ERROR_CALL(FORM_create( DvoCriteria74,CrDesc,"T5critera",&tCrItem74));
										ERROR_CALL(AOM_save(tCrItem74));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria74)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem74,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem74,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem74,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem74,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem74,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem74));
									}
									//if (DvoCriteria75)
									if(strcmp(DvoCriteria75,""))
									{
										printf("\nValue of Criteria NAME 75: %s\n",DvoCriteria75);
										ERROR_CALL(FORM_create( DvoCriteria75,CrDesc,"T5critera",&tCrItem75));
										ERROR_CALL(AOM_save(tCrItem75));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria75)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem75,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem75,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem75,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem75,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem75,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem75));
									}
									//if (DvoCriteria76)
									if(strcmp(DvoCriteria76,""))
									{
										printf("\nValue of Criteria NAME 76: %s\n",DvoCriteria76);
										ERROR_CALL(FORM_create( DvoCriteria76,CrDesc,"T5critera",&tCrItem76));
										ERROR_CALL(AOM_save(tCrItem76));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria76)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem76,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem76,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem76,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem76,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem76,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem76));
									}
									//if (DvoCriteria77)
									if(strcmp(DvoCriteria77,""))
									{
										printf("\nValue of Criteria NAME 77: %s\n",DvoCriteria77);
										ERROR_CALL(FORM_create( DvoCriteria77,CrDesc,"T5critera",&tCrItem77));
										ERROR_CALL(AOM_save(tCrItem77));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria77)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem77,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem77,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem77,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem77,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem77,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem77));
									}
									//if (DvoCriteria78)
									if(strcmp(DvoCriteria78,""))
									{
										printf("\nValue of Criteria NAME 78: %s\n",DvoCriteria78);
										ERROR_CALL(FORM_create( DvoCriteria78,CrDesc,"T5critera",&tCrItem78));
										ERROR_CALL(AOM_save(tCrItem78));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria78)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem78,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem78,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem78,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem78,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem78,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem78));
									}
									//if (DvoCriteria79)
									if(strcmp(DvoCriteria79,""))
									{
										printf("\nValue of Criteria NAME 79: %s\n",DvoCriteria79);
										ERROR_CALL(FORM_create( DvoCriteria79,CrDesc,"T5critera",&tCrItem79));
										ERROR_CALL(AOM_save(tCrItem79));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria79)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem79,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem79,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem79,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem79,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem79,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem79));
									}
									//if (DvoCriteria80)
									if(strcmp(DvoCriteria80,""))
									{
										printf("\nValue of Criteria NAME 80: %s\n",DvoCriteria80);
										ERROR_CALL(FORM_create( DvoCriteria80,CrDesc,"T5critera",&tCrItem80));
										ERROR_CALL(AOM_save(tCrItem80));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria80)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem80,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem80,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem80,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem80,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem80,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem80));
									}
									//if (DvoCriteria81)
									if(strcmp(DvoCriteria81,""))
									{
										printf("\nValue of Criteria NAME 81: %s\n",DvoCriteria81);
										ERROR_CALL(FORM_create( DvoCriteria81,CrDesc,"T5critera",&tCrItem81));
										ERROR_CALL(AOM_save(tCrItem81));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria81)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem81,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem81,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem81,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem81,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem81,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem81));
									}
									//if (DvoCriteria82)
									if(strcmp(DvoCriteria82,""))
									{
										printf("\nValue of Criteria NAME 82: %s\n",DvoCriteria82);
										ERROR_CALL(FORM_create( DvoCriteria82,CrDesc,"T5critera",&tCrItem82));
										ERROR_CALL(AOM_save(tCrItem82));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria82)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem82,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem82,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem82,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem82,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem82,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem82));
									}
									//if (DvoCriteria83)
									if(strcmp(DvoCriteria83,""))
									{
										printf("\nValue of Criteria NAME 83: %s\n",DvoCriteria83);
										ERROR_CALL(FORM_create( DvoCriteria83,CrDesc,"T5critera",&tCrItem83));
										ERROR_CALL(AOM_save(tCrItem83));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria83)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem83,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem83,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem83,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem83,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem83,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem83));
									}
									//if (DvoCriteria84)
									if(strcmp(DvoCriteria84,""))
									{
										printf("\nValue of Criteria NAME 84: %s\n",DvoCriteria84);
										ERROR_CALL(FORM_create( DvoCriteria84,CrDesc,"T5critera",&tCrItem84));
										ERROR_CALL(AOM_save(tCrItem84));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria84)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem84,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem84,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem84,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem84,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem84,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem84));
									}
									//if (DvoCriteria85)
									if(strcmp(DvoCriteria85,""))
									{
										printf("\nValue of Criteria NAME 85: %s\n",DvoCriteria85);
										ERROR_CALL(FORM_create( DvoCriteria85,CrDesc,"T5critera",&tCrItem85));
										ERROR_CALL(AOM_save(tCrItem85));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria85)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem85,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem85,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem85,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem85,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem85,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem85));
									}
									//if (DvoCriteria86)
									if(strcmp(DvoCriteria86,""))
									{
										printf("\nValue of Criteria NAME 86: %s\n",DvoCriteria86);
										ERROR_CALL(FORM_create( DvoCriteria86,CrDesc,"T5critera",&tCrItem86));
										ERROR_CALL(AOM_save(tCrItem86));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria86)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem86,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem86,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem86,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem86,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem86,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem86));
									}
									//if (DvoCriteria87)
									if(strcmp(DvoCriteria87,""))
									{
										printf("\nValue of Criteria NAME 87: %s\n",DvoCriteria87);
										ERROR_CALL(FORM_create( DvoCriteria87,CrDesc,"T5critera",&tCrItem87));
										ERROR_CALL(AOM_save(tCrItem87));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria87)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem87,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem87,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem87,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem87,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem87,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem87));
									}
									//if (DvoCriteria88)
									
									if(strcmp(DvoCriteria88,""))
									{
										printf("\nValue of Criteria NAME 88: %s\n",DvoCriteria88);
										ERROR_CALL(FORM_create( DvoCriteria88,CrDesc,"T5critera",&tCrItem88));
										ERROR_CALL(AOM_save(tCrItem88));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria88)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem88,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem88,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem88,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem88,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem88,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem88));
									}
									//if (DvoCriteria89)
									if(strcmp(DvoCriteria89,""))
									{
										printf("\nValue of Criteria NAME 89: %s\n",DvoCriteria89);
										ERROR_CALL(FORM_create( DvoCriteria89,CrDesc,"T5critera",&tCrItem89));
										ERROR_CALL(AOM_save(tCrItem89));
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria89)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem89,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem89,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem89,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem89,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem89,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem89));
									}
									//if (DvoCriteria90)
									if(strcmp(DvoCriteria90,""))
									{
										printf("\nValue of Criteria NAME 90: %s\n",DvoCriteria90);
										ERROR_CALL(FORM_create( DvoCriteria90,CrDesc,"T5critera",&tCrItem90));
										ERROR_CALL(AOM_save(tCrItem90));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria90)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem90,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem90,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem90,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem90,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem90,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem90));
									}
									//if (DvoCriteria91)
									if(strcmp(DvoCriteria91,""))
									{
										printf("\nValue of Criteria NAME 91: %s\n",DvoCriteria91);
										ERROR_CALL(FORM_create( DvoCriteria91,CrDesc,"T5critera",&tCrItem91));
										ERROR_CALL(AOM_save(tCrItem91));
										
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria91)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem91,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem91,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem91,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem91,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem91,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem91));

									}
									//if (DvoCriteria92)
									if(strcmp(DvoCriteria92,""))
									{
										printf("\nValue of Criteria NAME 92: %s\n",DvoCriteria92);
										ERROR_CALL(FORM_create( DvoCriteria92,CrDesc,"T5critera",&tCrItem92));
										ERROR_CALL(AOM_save(tCrItem92));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria92)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem92,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem92,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem92,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem92,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem92,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem92));
									}
									//if (DvoCriteria93)
									if(strcmp(DvoCriteria93,""))
									{
										printf("\nValue of Criteria NAME 93: %s\n",DvoCriteria93);
										ERROR_CALL(FORM_create( DvoCriteria93,CrDesc,"T5critera",&tCrItem93));
										ERROR_CALL(AOM_save(tCrItem93));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria93)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem93,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem93,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem93,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem93,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem93,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem93));
									}
									//if (DvoCriteria94)
									if(strcmp(DvoCriteria94,""))
									{
										printf("\nValue of Criteria NAME 94: %s\n",DvoCriteria94);
										ERROR_CALL(FORM_create( DvoCriteria94,CrDesc,"T5critera",&tCrItem94));
										ERROR_CALL(AOM_save(tCrItem94));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria94)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem94,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem94,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem94,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem94,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem94,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem94));
									}
									//if (DvoCriteria95)
									if(strcmp(DvoCriteria95,""))
									{
										printf("\nValue of Criteria NAME 95: %s\n",DvoCriteria95);
										ERROR_CALL(FORM_create( DvoCriteria95,CrDesc,"T5critera",&tCrItem95));
										ERROR_CALL(AOM_save(tCrItem95));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria95)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem95,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem95,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem95,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem95,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem95,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem95));
									}
									//if (DvoCriteria96)
									if(strcmp(DvoCriteria96,""))
									{
										printf("\nValue of Criteria NAME 96: %s\n",DvoCriteria96);
										ERROR_CALL(FORM_create( DvoCriteria96,CrDesc,"T5critera",&tCrItem96));
										ERROR_CALL(AOM_save(tCrItem96));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria96)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem96,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem96,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem96,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem96,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem96,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem96));
									}
									//if (DvoCriteria97)
									if(strcmp(DvoCriteria97,""))
									{
										printf("\nValue of Criteria NAME 97: %s\n",DvoCriteria97);
										ERROR_CALL(FORM_create( DvoCriteria97,CrDesc,"T5critera",&tCrItem97));
										ERROR_CALL(AOM_save(tCrItem97));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria97)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem97,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem97,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem97,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem97,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem97,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem97));
									}
									//if (DvoCriteria98)
									if(strcmp(DvoCriteria98,""))
									{
										printf("\nValue of Criteria NAME 98: %s\n",DvoCriteria98);
										ERROR_CALL(FORM_create( DvoCriteria98,CrDesc,"T5critera",&tCrItem98));
										ERROR_CALL(AOM_save(tCrItem98));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria98)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem98,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem98,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem98,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem98,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem98,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem98));
									}
									//if (DvoCriteria99)
									if(strcmp(DvoCriteria99,""))
									{
										printf("\nValue of Criteria NAME 99: %s\n",DvoCriteria99);
										ERROR_CALL(FORM_create( DvoCriteria99,CrDesc,"T5critera",&tCrItem99));
										ERROR_CALL(AOM_save(tCrItem99));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria99)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem99,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem99,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem99,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem99,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem99,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem99));
									}
									//if (DvoCriteria100)
									if(strcmp(DvoCriteria100,""))
									{
										printf("\nValue of Criteria NAME 100: %s\n",DvoCriteria100);
										ERROR_CALL(FORM_create( DvoCriteria100,CrDesc,"T5critera",&tCrItem100));
										ERROR_CALL(AOM_save(tCrItem100));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria100)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem100,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem100,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem100,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem100,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem100,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem100));
									}
									//if (DvoCriteria101)
									if(strcmp(DvoCriteria101,""))
									{
										printf("\nValue of Criteria NAME 101: %s\n",DvoCriteria101);
										ERROR_CALL(FORM_create( DvoCriteria101,CrDesc,"T5critera",&tCrItem101));
										ERROR_CALL(AOM_save(tCrItem101));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria101)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem101,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem101,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem101,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem101,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem101,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem101));
									}
									//if (DvoCriteria102)
									if(strcmp(DvoCriteria102,""))
									{
										printf("\nValue of Criteria NAME 102: %s\n",DvoCriteria102);
										ERROR_CALL(FORM_create( DvoCriteria102,CrDesc,"T5critera",&tCrItem102));
										ERROR_CALL(AOM_save(tCrItem102));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria102)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem102,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem102,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem102,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem102,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem102,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem102));
									}
									//if (DvoCriteria103)
									if(strcmp(DvoCriteria103,""))
									{
										printf("\nValue of Criteria NAME 103: %s\n",DvoCriteria103);
										ERROR_CALL(FORM_create( DvoCriteria103,CrDesc,"T5critera",&tCrItem103));
										ERROR_CALL(AOM_save(tCrItem103));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria103)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem103,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem103,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem103,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem103,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem103,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem103));
									}
									//if (DvoCriteria104)
									if(strcmp(DvoCriteria104,""))
									{
										printf("\nValue of Criteria NAME 104: %s\n",DvoCriteria104);
										ERROR_CALL(FORM_create( DvoCriteria104,CrDesc,"T5critera",&tCrItem104));
										ERROR_CALL(AOM_save(tCrItem104));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria104)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem104,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem104,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem104,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem104,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem104,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem104));
									}
									//if (DvoCriteria105)
									if(strcmp(DvoCriteria105,""))
									{
										printf("\nValue of Criteria NAME 105: %s\n",DvoCriteria105);
										ERROR_CALL(FORM_create( DvoCriteria105,CrDesc,"T5critera",&tCrItem105));
										ERROR_CALL(AOM_save(tCrItem105));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria105)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem105,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem105,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem105,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem105,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem105,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem105));
									}
									//if (DvoCriteria106)
									if(strcmp(DvoCriteria106,""))
									{
										printf("\nValue of Criteria NAME 106: %s\n",DvoCriteria106);
										ERROR_CALL(FORM_create( DvoCriteria106,CrDesc,"T5critera",&tCrItem106));
										ERROR_CALL(AOM_save(tCrItem106));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria106)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem106,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem106,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem106,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem106,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem106,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem106));
									}
									//if (DvoCriteria107)
									if(strcmp(DvoCriteria107,""))
									{
										printf("\nValue of Criteria NAME 107: %s\n",DvoCriteria107);
										ERROR_CALL(FORM_create( DvoCriteria107,CrDesc,"T5critera",&tCrItem107));
										ERROR_CALL(AOM_save(tCrItem107));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria107)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem107,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem107,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem107,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem107,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem107,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem107));
									}
									//if (DvoCriteria108)
									if(strcmp(DvoCriteria108,""))
									{
										printf("\nValue of Criteria NAME 108: %s\n",DvoCriteria108);
										ERROR_CALL(FORM_create( DvoCriteria108,CrDesc,"T5critera",&tCrItem108));
										ERROR_CALL(AOM_save(tCrItem108));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria108)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem108,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem108,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem108,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem108,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem108,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem108));
									}
									//if (DvoCriteria109)
									if(strcmp(DvoCriteria109,""))
									{
										printf("\nValue of Criteria NAME 109: %s\n",DvoCriteria109);
										ERROR_CALL(FORM_create( DvoCriteria109,CrDesc,"T5critera",&tCrItem109));
										ERROR_CALL(AOM_save(tCrItem109));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria109)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem109,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem109,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem109,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem109,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem109,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem109));
									}
									//if (DvoCriteria110)
									if(strcmp(DvoCriteria110,""))
									{
										printf("\nValue of Criteria NAME 110: %s\n",DvoCriteria110);
										ERROR_CALL(FORM_create( DvoCriteria110,CrDesc,"T5critera",&tCrItem110));
										ERROR_CALL(AOM_save(tCrItem110));
										
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria110)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem110,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem110,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem110,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem110,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem110,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem110));
									}
									//if (DvoCriteria111)
									if(strcmp(DvoCriteria111,""))
									{
										printf("\nValue of Criteria NAME 111: %s\n",DvoCriteria111);
										ERROR_CALL(FORM_create( DvoCriteria111,CrDesc,"T5critera",&tCrItem111));
										ERROR_CALL(AOM_save(tCrItem111));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria111)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem111,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem111,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem111,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem111,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem111,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem111));
									}
									//if (DvoCriteria112)
									if(strcmp(DvoCriteria112,""))
									{
										printf("\nValue of Criteria NAME 112: %s\n",DvoCriteria112);
										ERROR_CALL(FORM_create( DvoCriteria112,CrDesc,"T5critera",&tCrItem112));
										ERROR_CALL(AOM_save(tCrItem112));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria112)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem112,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem112,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem112,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem112,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem112,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem112));
									}
									//if (DvoCriteria113)
									if(strcmp(DvoCriteria113,""))
									{
										printf("\nValue of Criteria NAME 113: %s\n",DvoCriteria113);
										ERROR_CALL(FORM_create( DvoCriteria113,CrDesc,"T5critera",&tCrItem113));
										ERROR_CALL(AOM_save(tCrItem113));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria113)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem113,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem113,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem113,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem113,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem113,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem113));
									}
									//if (DvoCriteria114)
									if(strcmp(DvoCriteria114,""))
									{
										printf("\nValue of Criteria NAME 114: %s\n",DvoCriteria114);
										ERROR_CALL(FORM_create( DvoCriteria114,CrDesc,"T5critera",&tCrItem114));
										ERROR_CALL(AOM_save(tCrItem114));
									
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria114)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem114,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem114,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem114,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem114,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem114,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem114));
									}
									//if (DvoCriteria115)
									if(strcmp(DvoCriteria115,""))
									{
										printf("\nValue of Criteria NAME 115: %s\n",DvoCriteria115);
										ERROR_CALL(FORM_create( DvoCriteria115,CrDesc,"T5critera",&tCrItem115));
										ERROR_CALL(AOM_save(tCrItem115));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria115)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem115,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem115,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem115,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem115,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem115,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem115));
									}
										//if (DvoCriteria116)
									if(strcmp(DvoCriteria116,""))
									{
										printf("\nValue of Criteria NAME 116: %s\n",DvoCriteria116);
										ERROR_CALL(FORM_create( DvoCriteria116,CrDesc,"T5critera",&tCrItem116));
										ERROR_CALL(AOM_save(tCrItem116));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria116)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem116,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem116,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem116,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem116,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem116,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem116));
									}
									//if (DvoCriteria117)
									if(strcmp(DvoCriteria117,""))
									{
										printf("\nValue of Criteria NAME 117: %s\n",DvoCriteria117);
										ERROR_CALL(FORM_create( DvoCriteria117,CrDesc,"T5critera",&tCrItem117));
										ERROR_CALL(AOM_save(tCrItem117));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria117)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem117,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem117,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem117,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem117,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem117,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem117));
									}
									//if (DvoCriteria118)
									if(strcmp(DvoCriteria118,""))
									{
										printf("\nValue of Criteria NAME 118: %s\n",DvoCriteria118);
										ERROR_CALL(FORM_create( DvoCriteria118,CrDesc,"T5critera",&tCrItem118));
										ERROR_CALL(AOM_save(tCrItem118));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria118)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem118,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem118,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem118,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem118,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem118,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem118));
									}
										//if (DvoCriteria119)
									if(strcmp(DvoCriteria119,""))
									{
										printf("\nValue of Criteria NAME 119: %s\n",DvoCriteria119);
										ERROR_CALL(FORM_create( DvoCriteria119,CrDesc,"T5critera",&tCrItem119));
										ERROR_CALL(AOM_save(tCrItem119));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria119)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem119,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem119,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem119,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem119,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem119,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem119));
									}
									//if (DvoCriteria120)
									if(strcmp(DvoCriteria120,""))
									{
										printf("\nValue of Criteria NAME 120: %s\n",DvoCriteria120);
										ERROR_CALL(FORM_create( DvoCriteria120,CrDesc,"T5critera",&tCrItem120));
										ERROR_CALL(AOM_save(tCrItem120));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria120)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem120,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem120,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem120,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem120,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem120,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem120));
									}
									//if (DvoCriteria121)
									if(strcmp(DvoCriteria121,""))
									{
										printf("\nValue of Criteria NAME 121: %s\n",DvoCriteria121);
										ERROR_CALL(FORM_create( DvoCriteria121,CrDesc,"T5critera",&tCrItem121));
										ERROR_CALL(AOM_save(tCrItem121));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria121)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem121,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem121,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem121,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem121,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem121,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem121));
									}
									//if (DvoCriteria122)
									if(strcmp(DvoCriteria122,""))
									{
										printf("\nValue of Criteria NAME 122: %s\n",DvoCriteria122);
										ERROR_CALL(FORM_create( DvoCriteria122,CrDesc,"T5critera",&tCrItem122));
										ERROR_CALL(AOM_save(tCrItem122));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria122)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem122,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem122,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem122,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem122,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem122,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem122));
									}
									//if (DvoCriteria123)
									if(strcmp(DvoCriteria123,""))
									{
										printf("\nValue of Criteria NAME 123: %s\n",DvoCriteria123);
										ERROR_CALL(FORM_create( DvoCriteria123,CrDesc,"T5critera",&tCrItem123));
										ERROR_CALL(AOM_save(tCrItem123));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria123)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem123,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem123,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem123,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem123,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem123,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem123));
									}
									if(strcmp(DvoCriteria124,""))
									//if (DvoCriteria124)
									{
										printf("\nValue of Criteria NAME 124: %s\n",DvoCriteria124);
										ERROR_CALL(FORM_create( DvoCriteria124,CrDesc,"T5critera",&tCrItem124));
										ERROR_CALL(AOM_save(tCrItem124));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria124)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem124,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem124,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem124,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem124,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem124,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem124));
									}
									if(strcmp(DvoCriteria125,""))
									//if (DvoCriteria125)
									{
										printf("\nValue of Criteria NAME 125: %s\n",DvoCriteria125);
										ERROR_CALL(FORM_create( DvoCriteria125,CrDesc,"T5critera",&tCrItem125));
										ERROR_CALL(AOM_save(tCrItem125));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria125)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem125,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem125,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem125,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem125,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem125,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem125));
									}
									//if (DvoCriteria126)
									if(strcmp(DvoCriteria126,""))
									{
										printf("\nValue of Criteria NAME 126: %s\n",DvoCriteria126);
										ERROR_CALL(FORM_create( DvoCriteria126,CrDesc,"T5critera",&tCrItem126));
										ERROR_CALL(AOM_save(tCrItem126));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria126)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem126,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem126,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem126,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem126,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem126,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem126));
									}
									//if (DvoCriteria127)
									if(strcmp(DvoCriteria127,""))
									{
										printf("\nValue of Criteria NAME 127: %s\n",DvoCriteria127);
										ERROR_CALL(FORM_create( DvoCriteria127,CrDesc,"T5critera",&tCrItem127));
										ERROR_CALL(AOM_save(tCrItem127));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria127)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem127,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem127,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem127,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem127,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem127,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem127));
									}
									//if (DvoCriteria128)
									if(strcmp(DvoCriteria128,""))
									{
										printf("\nValue of Criteria NAME 128: %s\n",DvoCriteria128);
										ERROR_CALL(FORM_create( DvoCriteria128,CrDesc,"T5critera",&tCrItem128));
										ERROR_CALL(AOM_save(tCrItem128));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria128)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem128,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem128,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem128,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem128,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem128,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem128));
									}
									//if (DvoCriteria129)
									if(strcmp(DvoCriteria129,""))
									{
										printf("\nValue of Criteria NAME 129: %s\n",DvoCriteria129);
										ERROR_CALL(FORM_create( DvoCriteria129,CrDesc,"T5critera",&tCrItem129));
										ERROR_CALL(AOM_save(tCrItem129));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria129)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem129,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem129,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem129,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem129,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem129,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem129));
									}
									//if (DvoCriteria130)
									if(strcmp(DvoCriteria130,""))
									{
										printf("\nValue of Criteria NAME 130: %s\n",DvoCriteria130);
										ERROR_CALL(FORM_create( DvoCriteria130,CrDesc,"T5critera",&tCrItem130));
										ERROR_CALL(AOM_save(tCrItem130));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria130)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem130,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem130,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem130,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem130,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem130,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem130));
									}
									//if (DvoCriteria131)
									if(strcmp(DvoCriteria131,""))
									{
										printf("\nValue of Criteria NAME 131: %s\n",DvoCriteria131);
										ERROR_CALL(FORM_create( DvoCriteria131,CrDesc,"T5critera",&tCrItem131));
										ERROR_CALL(AOM_save(tCrItem131));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria131)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem131,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem131,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem131,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem131,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem131,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem131));
									}
									//if (DvoCriteria132)
									if(strcmp(DvoCriteria132,""))
									{
										printf("\nValue of Criteria NAME 132: %s\n",DvoCriteria132);
										ERROR_CALL(FORM_create( DvoCriteria132,CrDesc,"T5critera",&tCrItem132));
										ERROR_CALL(AOM_save(tCrItem132));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria132)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem132,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem132,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem132,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem132,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem132,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem132));
									}
									//if (DvoCriteria133)
									if(strcmp(DvoCriteria133,""))
									{
										printf("\nValue of Criteria NAME 133: %s\n",DvoCriteria133);
										ERROR_CALL(FORM_create( DvoCriteria133,CrDesc,"T5critera",&tCrItem133));
										ERROR_CALL(AOM_save(tCrItem133));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria133)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem133,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem133,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem133,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem133,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem133,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem133));
									}
									//if (DvoCriteria134)
									if(strcmp(DvoCriteria134,""))
									{
										printf("\nValue of Criteria NAME 134: %s\n",DvoCriteria134);
										ERROR_CALL(FORM_create( DvoCriteria134,CrDesc,"T5critera",&tCrItem134));
										ERROR_CALL(AOM_save(tCrItem134));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria134)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem134,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem134,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem134,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem134,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem134,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem134));
									}
									//if (DvoCriteria135)
									if(strcmp(DvoCriteria135,""))
									{
										printf("\nValue of Criteria NAME 135: %s\n",DvoCriteria135);
										ERROR_CALL(FORM_create( DvoCriteria135,CrDesc,"T5critera",&tCrItem135));
										ERROR_CALL(AOM_save(tCrItem135));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria135)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem135,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem135,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem135,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem135,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem135,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem135));
									}
									//if (DvoCriteria136)
									if(strcmp(DvoCriteria136,""))
									{
										printf("\nValue of Criteria NAME 136: %s\n",DvoCriteria136);
										ERROR_CALL(FORM_create( DvoCriteria136,CrDesc,"T5critera",&tCrItem136));
										ERROR_CALL(AOM_save(tCrItem136));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria136)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem136,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem136,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem136,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem136,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem136,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem136));
									}
									//if (DvoCriteria137)
									if(strcmp(DvoCriteria137,""))
									{
										printf("\nValue of Criteria NAME 137: %s\n",DvoCriteria137);
										ERROR_CALL(FORM_create( DvoCriteria137,CrDesc,"T5critera",&tCrItem137));
										ERROR_CALL(AOM_save(tCrItem137));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria137)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem137,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem137,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem137,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem137,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem137,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem137));
									}
									//if (DvoCriteria138)
									if(strcmp(DvoCriteria138,""))
									{
										printf("\nValue of Criteria NAME 138: %s\n",DvoCriteria138);
										ERROR_CALL(FORM_create( DvoCriteria138,CrDesc,"T5critera",&tCrItem138));
										ERROR_CALL(AOM_save(tCrItem138));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria138)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem138,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem138,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem138,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem138,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem138,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem138));
									}
									//if (DvoCriteria139)
									if(strcmp(DvoCriteria139,""))
									{
										printf("\nValue of Criteria NAME 139: %s\n",DvoCriteria139);
										ERROR_CALL(FORM_create( DvoCriteria139,CrDesc,"T5critera",&tCrItem139));
										ERROR_CALL(AOM_save(tCrItem139));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria139)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem139,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem139,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem139,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem139,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem139,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem139));
									}
									//if (DvoCriteria140)
									if(strcmp(DvoCriteria140,""))
									{
										printf("\nValue of Criteria NAME 140: %s\n",DvoCriteria140);
										ERROR_CALL(FORM_create( DvoCriteria140,CrDesc,"T5critera",&tCrItem140));
										ERROR_CALL(AOM_save(tCrItem140));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria140)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem140,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem140,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem140,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem140,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem140,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem140));
									}
									//if (DvoCriteria141)
									if(strcmp(DvoCriteria141,""))
									{
										printf("\nValue of Criteria NAME 141: %s\n",DvoCriteria141);
										ERROR_CALL(FORM_create( DvoCriteria141,CrDesc,"T5critera",&tCrItem141));
										ERROR_CALL(AOM_save(tCrItem141));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria141)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem141,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem141,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem141,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem141,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem141,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem141));
									}
									//if (DvoCriteria142)
									if(strcmp(DvoCriteria142,""))
									{
										printf("\nValue of Criteria NAME 142: %s\n",DvoCriteria142);
										ERROR_CALL(FORM_create( DvoCriteria142,CrDesc,"T5critera",&tCrItem142));
										ERROR_CALL(AOM_save(tCrItem142));
										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria142)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem142,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem142,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem142,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem142,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem142,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem142));
									}
									//if (DvoCriteria143)
									if(strcmp(DvoCriteria143,""))
									{
										printf("\nValue of Criteria NAME 143: %s\n",DvoCriteria143);
										ERROR_CALL(FORM_create( DvoCriteria143,CrDesc,"T5critera",&tCrItem143));
										ERROR_CALL(AOM_save(tCrItem143));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria143)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem143,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem143,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem143,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem143,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem143,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem143));
									}
									//if (DvoCriteria144)
									if(strcmp(DvoCriteria144,""))
									{
										printf("\nValue of Criteria NAME 144: %s\n",DvoCriteria144);
										ERROR_CALL(FORM_create( DvoCriteria144,CrDesc,"T5critera",&tCrItem144));
										ERROR_CALL(AOM_save(tCrItem144));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria144)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem144,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem144,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem144,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem144,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem144,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem144));
									}
									//if (DvoCriteria145)
									if(strcmp(DvoCriteria145,""))
									{
										printf("\nValue of Criteria NAME 145: %s\n",DvoCriteria145);
										ERROR_CALL(FORM_create( DvoCriteria145,CrDesc,"T5critera",&tCrItem145));
										ERROR_CALL(AOM_save(tCrItem145));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria145)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem145,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem145,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem145,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem145,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem145,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem145));
									}
									//if (DvoCriteria146)
									if(strcmp(DvoCriteria146,""))
									{
										printf("\nValue of Criteria NAME 146: %s\n",DvoCriteria146);
										ERROR_CALL(FORM_create( DvoCriteria146,CrDesc,"T5critera",&tCrItem146));
										ERROR_CALL(AOM_save(tCrItem146));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria146)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem146,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem146,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem146,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem146,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem146,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem146));
									}
									//if (DvoCriteria147)
									if(strcmp(DvoCriteria147,""))
									{
										printf("\nValue of Criteria NAME 147: %s\n",DvoCriteria147);
										ERROR_CALL(FORM_create( DvoCriteria147,CrDesc,"T5critera",&tCrItem147));
										ERROR_CALL(AOM_save(tCrItem147));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria147)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem147,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem147,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem147,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem147,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem147,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem147));
									}
									//if (DvoCriteria148)
									if(strcmp(DvoCriteria148,""))
									{
										printf("\nValue of Criteria NAME 148: %s\n",DvoCriteria148);
										ERROR_CALL(FORM_create( DvoCriteria148,CrDesc,"T5critera",&tCrItem148));
										ERROR_CALL(AOM_save(tCrItem148));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria148)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem148,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem148,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem148,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem148,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem148,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem148));
									}
									//if (DvoCriteria149)
									if(strcmp(DvoCriteria149,""))
									{
										printf("\nValue of Criteria NAME 149: %s\n",DvoCriteria149);
										ERROR_CALL(FORM_create( DvoCriteria149,CrDesc,"T5critera",&tCrItem149));
										ERROR_CALL(AOM_save(tCrItem149));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria149)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem149,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem149,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem149,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem149,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem149,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem149));
									}
									//if (DvoCriteria150)
									if(strcmp(DvoCriteria150,""))
									{
										printf("\nValue of Criteria NAME 150: %s\n",DvoCriteria150);
										ERROR_CALL(FORM_create( DvoCriteria150,CrDesc,"T5critera",&tCrItem150));
										ERROR_CALL(AOM_save(tCrItem150));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria150)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem150,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem150,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem150,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem150,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem150,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem150));
									}
									//if (DvoCriteria151)
									if(strcmp(DvoCriteria151,""))
									{
										printf("\nValue of Criteria NAME 151: %s\n",DvoCriteria151);
										ERROR_CALL(FORM_create( DvoCriteria151,CrDesc,"T5critera",&tCrItem151));
										ERROR_CALL(AOM_save(tCrItem151));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria151)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem151,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem151,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem151,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem151,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem151,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem151));
									}
									//if (DvoCriteria152)
									if(strcmp(DvoCriteria152,""))
									{
										printf("\nValue of Criteria NAME 152: %s\n",DvoCriteria152);
										ERROR_CALL(FORM_create( DvoCriteria152,CrDesc,"T5critera",&tCrItem152));
										ERROR_CALL(AOM_save(tCrItem152));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria152)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem152,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem152,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem152,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem152,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem152,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem152));
									}
									//if (DvoCriteria153)
									if(strcmp(DvoCriteria153,""))
									{
										printf("\nValue of Criteria NAME 153: %s\n",DvoCriteria153);
										ERROR_CALL(FORM_create( DvoCriteria153,CrDesc,"T5critera",&tCrItem153));
										ERROR_CALL(AOM_save(tCrItem153));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria153)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem153,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem153,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem153,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem153,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem153,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem153));
									}
									//if (DvoCriteria154)
									if(strcmp(DvoCriteria154,""))
									{
										printf("\nValue of Criteria NAME 154: %s\n",DvoCriteria154);
										ERROR_CALL(FORM_create( DvoCriteria154,CrDesc,"T5critera",&tCrItem154));
										ERROR_CALL(AOM_save(tCrItem154));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria154)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem154,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem154,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem154,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem154,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem154,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem154));
									}
									//if (DvoCriteria155)
									if(strcmp(DvoCriteria155,""))
									{
										printf("\nValue of Criteria NAME 155: %s\n",DvoCriteria155);
										ERROR_CALL(FORM_create( DvoCriteria155,CrDesc,"T5critera",&tCrItem155));
										ERROR_CALL(AOM_save(tCrItem155));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria155)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem155,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem155,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem155,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem155,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem155,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem155));
									}
									//if (DvoCriteria156)
									if(strcmp(DvoCriteria156,""))
									{
										printf("\nValue of Criteria NAME 156: %s\n",DvoCriteria156);
										ERROR_CALL(FORM_create( DvoCriteria156,CrDesc,"T5critera",&tCrItem156));
										ERROR_CALL(AOM_save(tCrItem156));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria156)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem156,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem156,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem156,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem156,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem156,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem156));
									}
									//if (DvoCriteria157)
									if(strcmp(DvoCriteria157,""))
									{
										printf("\nValue of Criteria NAME 157: %s\n",DvoCriteria157);
										ERROR_CALL(FORM_create( DvoCriteria157,CrDesc,"T5critera",&tCrItem157));
										ERROR_CALL(AOM_save(tCrItem157));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria157)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem157,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem157,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem157,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem157,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem157,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem157));
									}
									//if (DvoCriteria158)
									if(strcmp(DvoCriteria158,""))
									{
										printf("\nValue of Criteria NAME 158: %s\n",DvoCriteria158);
										ERROR_CALL(FORM_create( DvoCriteria158,CrDesc,"T5critera",&tCrItem158));
										ERROR_CALL(AOM_save(tCrItem158));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria158)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem158,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem158,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem158,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem158,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem158,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem158));
									}
									//if (DvoCriteria159)
									if(strcmp(DvoCriteria159,""))
									{
										printf("\nValue of Criteria NAME 159: %s\n",DvoCriteria159);
										ERROR_CALL(FORM_create( DvoCriteria159,CrDesc,"T5critera",&tCrItem159));
										ERROR_CALL(AOM_save(tCrItem159));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria159)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem159,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem159,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem159,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem159,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem159,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem159));
									}
									//if (DvoCriteria160)
									if(strcmp(DvoCriteria160,""))
									{
										printf("\nValue of Criteria NAME 160: %s\n",DvoCriteria160);
										ERROR_CALL(FORM_create( DvoCriteria160,CrDesc,"T5critera",&tCrItem160));
										ERROR_CALL(AOM_save(tCrItem160));

										masterfoundcnt=0;
										
										for (masterfoundcnt=0;masterfoundcnt<number_found;masterfoundcnt++)
										{
											mastercriteriadata		= NULL;
											mastercriteriacode		= NULL;
											mastercriteriadefault	= NULL;
											mastercriteriaunit		= NULL;
											mastercriteriatype		= NULL;
											
											if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriadata",&mastercriteriadata));
											//printf(" \n  criteria data %s\n",mastercriteriadata);fflush(stdout);

											if(strcmp(mastercriteriadata,DvoCriteria160)==0)
											{
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5criteriacode",&mastercriteriacode));
												printf(" \n  criteria code %s\n",mastercriteriacode);fflush(stdout);
				
												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5defaulttarget",&mastercriteriadefault));
												printf(" \n  default target %s\n",mastercriteriadefault);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5unit",&mastercriteriaunit));
												printf(" \n  Unit %s\n",mastercriteriaunit);fflush(stdout);

												if(AOM_get_value_string(list_of_WSO_tags[masterfoundcnt],"t5targettype",&mastercriteriatype));
												printf(" \n  Target Type %s\n",mastercriteriatype);fflush(stdout);
											
											break;
											}
											
										}
											ERROR_CALL(AOM_set_value_string(tCrItem160,"t5criteriacode",mastercriteriacode));
											ERROR_CALL(AOM_set_value_string(tCrItem160,"t5targetdescription",mastercriteriadata));
											ERROR_CALL(AOM_set_value_string(tCrItem160,"t5defaulttarget",mastercriteriadefault));
											ERROR_CALL(AOM_set_value_string(tCrItem160,"t5measureunit",mastercriteriaunit));
											ERROR_CALL(AOM_set_value_string(tCrItem160,"t5targetcategory",mastercriteriatype));

											ERROR_CALL(AOM_save(tCrItem160));
									}
									printf("\ncreated Criteria Objects\n");
								
								/*Getting Master Tag from Revision Tag*/
								ERROR_CALL(AOM_get_value_tag(Secondary_Objects[ReqDvmCnt],"items_tag",&DvmItemTag));
								
								/*Getting DvmID,DvmRev,DvmName from Requirement Object*/
								ERROR_CALL(AOM_get_value_string(DvmItemTag,"item_id",&DvmID));
								printf("\nValue of DvmID ==> [%s]\n",DvmID);fflush(stdout);
								ERROR_CALL(AOM_get_value_string(Secondary_Objects[ReqDvmCnt],"item_revision_id",&DvmRev));
								ERROR_CALL(AOM_get_value_string(Secondary_Objects[ReqDvmCnt],"object_name",&DvmName));
								ERROR_CALL(AOM_ask_value_logical(Secondary_Objects[ReqDvmCnt],"t5Milestone1",&DvmMile1));
								ERROR_CALL(AOM_ask_value_logical(Secondary_Objects[ReqDvmCnt],"t5milestone2",&DvmMile2));
								ERROR_CALL(AOM_ask_value_logical(Secondary_Objects[ReqDvmCnt],"t5milestone3",&DvmMile3));
								ERROR_CALL(AOM_ask_value_logical(Secondary_Objects[ReqDvmCnt],"t5milestone4",&DvmMile4));
								ERROR_CALL(AOM_ask_value_logical(Secondary_Objects[ReqDvmCnt],"t5milestone5",&DvmMile5));
								ERROR_CALL(AOM_ask_value_logical(Secondary_Objects[ReqDvmCnt],"t5milestone6",&DvmMile6));
								ERROR_CALL(AOM_ask_value_logical(Secondary_Objects[ReqDvmCnt],"t5milestone7",&DvmMile7));
								ERROR_CALL(AOM_ask_value_logical(Secondary_Objects[ReqDvmCnt],"t5milestone8",&DvmMile8));
								ERROR_CALL(AOM_ask_value_logical(Secondary_Objects[ReqDvmCnt],"t5milestone9",&DvmMile9));
								ERROR_CALL(AOM_ask_value_logical(Secondary_Objects[ReqDvmCnt],"t5milestone10",&DvmMile10));
								ERROR_CALL(AOM_ask_value_logical(Secondary_Objects[ReqDvmCnt],"t5milestone11",&DvmMile11));
								ERROR_CALL(AOM_ask_value_logical(Secondary_Objects[ReqDvmCnt],"t5milestone12",&DvmMile12));
								ERROR_CALL(AOM_ask_value_logical(Secondary_Objects[ReqDvmCnt],"t5milestone13",&DvmMile13));
								ERROR_CALL(AOM_ask_value_logical(Secondary_Objects[ReqDvmCnt],"t5milestone14",&DvmMile14));
								ERROR_CALL(AOM_ask_value_logical(Secondary_Objects[ReqDvmCnt],"t5milestone15",&DvmMile15));
								ERROR_CALL(AOM_ask_value_logical(Secondary_Objects[ReqDvmCnt],"t5milestone16",&DvmMile16));
								ERROR_CALL(AOM_ask_value_logical(Secondary_Objects[ReqDvmCnt],"t5milestone17",&DvmMile17));
								
								/*
								printf("\nValue of DvmMile1 ==> [%d]\n",DvmMile1);fflush(stdout);
								printf("\nValue of DvmMile2 ==> [%d]\n",DvmMile2);fflush(stdout);
								printf("\nValue of DvmMile2 ==> [%d]\n",DvmMile3);fflush(stdout);
								printf("\nValue of DvmMile2 ==> [%d]\n",DvmMile4);fflush(stdout);
								printf("\nValue of DvmMile2 ==> [%d]\n",DvmMile5);fflush(stdout);
								printf("\nValue of DvmMile2 ==> [%d]\n",DvmMile6);fflush(stdout);
								printf("\nValue of DvmMile2 ==> [%d]\n",DvmMile7);fflush(stdout);
								printf("\nValue of DvmMile2 ==> [%d]\n",DvmMile8);fflush(stdout);
								printf("\nValue of DvmMile2 ==> [%d]\n",DvmMile9);fflush(stdout);
								printf("\nValue of DvmMile2 ==> [%d]\n",DvmMile10);fflush(stdout);
								printf("\nValue of DvmMile2 ==> [%d]\n",DvmMile11);fflush(stdout);
								printf("\nValue of DvmMile2 ==> [%d]\n",DvmMile12);fflush(stdout);
								printf("\nValue of DvmMile2 ==> [%d]\n",DvmMile13);fflush(stdout);
								printf("\nValue of DvmMile2 ==> [%d]\n",DvmMile14);fflush(stdout);
								printf("\nValue of DvmMile2 ==> [%d]\n",DvmMile15);fflush(stdout);
								printf("\nValue of DvmMile2 ==> [%d]\n",DvmMile16);fflush(stdout);
								printf("\nValue of DvmMile2 ==> [%d]\n",DvmMile17);fflush(stdout);
								*/
								if(DvmMile1 == 1) DvoCount++;
								if(DvmMile2 == 1) DvoCount++;
								if(DvmMile3 == 1) DvoCount++;
								if(DvmMile4 == 1) DvoCount++;
								if(DvmMile5 == 1) DvoCount++;
								if(DvmMile6 == 1) DvoCount++;
								if(DvmMile7 == 1) DvoCount++;
								if(DvmMile8 == 1) DvoCount++;
								if(DvmMile9 == 1) DvoCount++;
								if(DvmMile10 == 1) DvoCount++;
								if(DvmMile11 == 1) DvoCount++;
								if(DvmMile12 == 1) DvoCount++;
								if(DvmMile13 == 1) DvoCount++;
								if(DvmMile14 == 1) DvoCount++;
								if(DvmMile15 == 1) DvoCount++;
								if(DvmMile16 == 1) DvoCount++;
								if(DvmMile17 == 1) DvoCount++;
								printf("\nValue of DvoCount ==> [%d]\n",DvoCount);fflush(stdout);
								//break;
						//	}
			// Muktesh			}
			//		}
								MileNumber=0;
								
					/*Creation Of DVO only if Requirement has DVM attached*/
					printf("\nValue of ReqDvmSpec => [%d]\nValue of ReqDvmRef => [%d]\n",ReqDvmSpec,ReqDvmRef);fflush(stdout);
					if (ReqDvmSpec > 0 || ReqDvmRef > 0)
					{
						for(i=0;i<DvoCount;i++)
						{
							MileNumber++;
							//MileName=NULL;

							for(MileCounter=MileNumber;MileCounter<=17;MileCounter++)
							{
								if (MileCounter==1)
								{
									strcpy(DvoName,"t5Milestone");
								}
								else
								{
									strcpy(DvoName,"t5milestone");
								}
							
								printf("\nValu of MileCounter : %d\n",MileCounter);
								printf("\nbefore sprintf\n");
								sprintf(MileCount,"%d",MileCounter);
								printf("\nValu of MileCounter : %d\n",MileCounter);
								printf("\nValu of MileCount : %s\n",MileCount);
								strcat(DvoName,MileCount);
								printf("\nValu of DvoName : %s\n",DvoName);
								
								//if(DvmMile6 == 1)
								printf("\nBefore Ask\n");fflush(stdout);
								ERROR_CALL(AOM_ask_value_logical(Secondary_Objects[ReqDvmCnt],DvoName,&DvmMilea));
								printf("\nValue of DvmMilea : %d\n",DvmMilea);
								if(DvmMilea==1)
								{
									//strcpy(MileName,DvoName);
									strcpy(MileName,"Milestone ");
									strcat(MileName,MileCount);
									printf("\nValue of MileName : %s\n",MileName);
									MileNumber=MileCounter;
									break;
								}

							}
														
							/*Now Creating DVO Object*/
						/*Find Total DVO Objects in Database*/
						WSOM_clear_search_criteria(&criteria);
						strcpy(criteria.class_name,"T5Dvo");
						ERROR_CALL(WSOM_search(criteria,&hits,&ListOfDvoObj)); 
						printf("\nTotal DVO Objects Found in PLM are [%d]\n",hits);fflush(stdout);
						hits++;
						printf("\nNew value of Hits [%d]\n",hits);fflush(stdout);
						sprintf(HitsS,"%d",hits);
						lenHits=strlen(HitsS);
						
						printf("\nString Value of Hits [%s]\n",HitsS);fflush(stdout);
						if (lenHits == 1)
						{
							strcpy(DvoItemId,"000000");
							strcat(DvoItemId,HitsS);
						}
						if (lenHits == 2)
						{
							strcpy(DvoItemId,"00000");
							strcat(DvoItemId,HitsS);
						}
						if (lenHits == 3)
						{
							strcpy(DvoItemId,"0000");
							strcat(DvoItemId,HitsS);
						}
						if (lenHits == 4)
						{
							strcpy(DvoItemId,"000");
							strcat(DvoItemId,HitsS);
						}
						if (lenHits == 5)
						{
							strcpy(DvoItemId,"00");
							strcat(DvoItemId,HitsS);
						}
						if (lenHits == 6)
						{
							strcpy(DvoItemId,"0");
							strcat(DvoItemId,HitsS);
						}
						if (lenHits == 7)
						{
							strcpy(DvoItemId,HitsS);
						}
						printf("\nValue of DvoItemId is  [%s]\n",DvoItemId);fflush(stdout);
								
						strcpy(DvoDesc,"(For Requirement:");
						strcat(DvoDesc,ReqName);
						strcat(DvoDesc,")");
						
						ERROR_CALL(ITEM_create_item( DvoItemId,DvoDesc,"T5Dvo","A",&tDvoItem,&tDvoItemRev ));
						ERROR_CALL(ITEM_save_item ( tDvoItem ));
		
						if (iAbhiDvoCheck == 1)
						{
							ERROR_CALL(AOM_lock( tReq_Find[foundcnt2] ));
							ERROR_CALL(FL_insert(tReq_Find[foundcnt2],tDvoItem,999));				
							ERROR_CALL(AOM_save( tReq_Find[foundcnt2] ));
							ERROR_CALL(AOM_unlock( tReq_Find[foundcnt2]));
						}
						else
						{
							ERROR_CALL(AOM_lock( tDvoFolder ));
							ERROR_CALL(FL_insert(tDvoFolder,tDvoItem,999));
							
							ERROR_CALL(AOM_save( tDvoFolder ));
							ERROR_CALL(AOM_unlock( tDvoFolder));
						}
						
						printf("\nDVO Item Created Now\n");fflush(stdout);
						
						//Updating Some Attributes Of Created DVO Object
						
						//ERROR_CALL(AOM_set_value_string(tDvoItemRev,"t5reqproto","AAAA"));
						ERROR_CALL(AOM_set_value_string(tDvoItemRev,"t5reqtestproc","AAAAA"));	
						ERROR_CALL(AOM_set_value_string(tDvoItemRev,"t5uom","01"));	
						ERROR_CALL(AOM_set_value_string(tDvoItemRev,"t5target","111"));		
						ERROR_CALL(AOM_set_value_string(tDvoItemRev,"t5sumresult","AAAA"));
						/*Updating Attributes Of Requirement and DVM in DVO Object*/
						ERROR_CALL(AOM_set_value_string(tDvoItemRev,"t5reqid",ReqID));// Requirement ID
						ERROR_CALL(AOM_set_value_string(tDvoItemRev,"t5reqrev",ReqRev));// Requirement Revision
						ERROR_CALL(AOM_set_value_string(tDvoItemRev,"t5reqname",ReqName));// Requirement Name
						ERROR_CALL(AOM_set_value_string(tDvoItemRev,"t5dvoownattr",ReqOwnAttrGrp));// Requirement Owning Attr Group
						ERROR_CALL(AOM_set_value_string(tDvoItemRev,"t5dvmid",DvmID));// DVM ID
						ERROR_CALL(AOM_set_value_string(tDvoItemRev,"t5dvmrev",DvmRev));// DVM Revision
						ERROR_CALL(AOM_set_value_string(tDvoItemRev,"t5dvmname",DvmName));// DVM Name
						ERROR_CALL(AOM_set_value_string(tDvoItemRev,"t5dvomilestone",MileName)); //Milestone Name
						ERROR_CALL(AOM_set_value_string(tDvoItemRev,"t5reqpath",requirementpath)); // Classiifcation Path
						
						ERROR_CALL(AOM_save(tDvoItemRev));
						ERROR_CALL(AOM_save(tDvoItem));
						printf("\nAll DVO Attribute Updated Successfully\n");fflush(stdout);

						/*Now Submitting Created DVO to Life Cycle ""*/


						/*Life Cycle Submission Completed*/
		
						/*Now Creating Relation*/
						/*Finding Whether IMAN_reference exist or not And getting Its Tag*/
						ERROR_CALL(GRM_find_relation_type  ("IMAN_reference",&tRelationFind1));
						if (tRelationFind1!=NULLTAG)
						{				
							/*Now Creating Relation Between Requirement and DVO Object*/
							GRM_find_relation(tDvoItemRev,tReqRevTag,tRelationFind1,&tRelationExist1);  
							if (tRelationExist1==NULLTAG)
							{
								printf("\n Now Creating Relation Between DVO and Requirement Object \n");fflush(stdout);
								ERROR_CALL(GRM_create_relation(tDvoItemRev,tReqRevTag,tRelationFind1,NULLTAG,&tRelationObj1));
								ERROR_CALL(GRM_save_relation  (tRelationObj1)); 
								printf("\nRelation Created Successfully\n");fflush(stdout);

								printf("\n Now Creating Relation Between DVO and Criteria Objects \n");fflush(stdout);
								ERROR_CALL(GRM_find_relation_type  ("T5dvocriteria",&tCrRelationFind1));
								if (tCrRelationFind1!=NULLTAG)
								{
										//ERROR_CALL(GRM_create_relation(tDvoItemRev,tmp_criteria1,tCrRelationFind1,NULLTAG,&tCrRelationObj1));
										//ERROR_CALL(GRM_save_relation  (tCrRelationObj1));
									if (tCrItem1 !=NULLTAG)
									{
										ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem1,tCrRelationFind1,NULLTAG,&tCrRelationObj1));	
										ERROR_CALL(GRM_save_relation  (tCrRelationObj1));      
									}
									if (tCrItem2 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem2,tCrRelationFind1,NULLTAG,&tCrRelationObj2));    	
										ERROR_CALL(GRM_save_relation  (tCrRelationObj2));
									}
									if (tCrItem3 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem3,tCrRelationFind1,NULLTAG,&tCrRelationObj3));    	
										ERROR_CALL(GRM_save_relation  (tCrRelationObj3));  
									}
									if (tCrItem4 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem4,tCrRelationFind1,NULLTAG,&tCrRelationObj4));    	
										ERROR_CALL(GRM_save_relation  (tCrRelationObj4));      
									}
									if (tCrItem5 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem5,tCrRelationFind1,NULLTAG,&tCrRelationObj5));    		
										ERROR_CALL(GRM_save_relation  (tCrRelationObj5));      
									}
									if (tCrItem6 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem6,tCrRelationFind1,NULLTAG,&tCrRelationObj6));    	
										ERROR_CALL(GRM_save_relation  (tCrRelationObj6));      
									}
									if (tCrItem7 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem7,tCrRelationFind1,NULLTAG,&tCrRelationObj7)); 
										ERROR_CALL(GRM_save_relation  (tCrRelationObj7));     
									}
									if (tCrItem8 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem8,tCrRelationFind1,NULLTAG,&tCrRelationObj8));    	
										ERROR_CALL(GRM_save_relation  (tCrRelationObj8));      
									}
									if (tCrItem9 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem9,tCrRelationFind1,NULLTAG,&tCrRelationObj9));    	
										ERROR_CALL(GRM_save_relation  (tCrRelationObj9));      
									}
									if (tCrItem10 !=NULLTAG)
									{
										ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem10,tCrRelationFind1,NULLTAG,&tCrRelationObj10));  		
										ERROR_CALL(GRM_save_relation  (tCrRelationObj10));     
									}
									if (tCrItem11 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem11,tCrRelationFind1,NULLTAG,&tCrRelationObj11));  	
										ERROR_CALL(GRM_save_relation  (tCrRelationObj11));     
									}
									if (tCrItem12 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem12,tCrRelationFind1,NULLTAG,&tCrRelationObj12));  	
										ERROR_CALL(GRM_save_relation  (tCrRelationObj12));     
									}
									if (tCrItem13 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem13,tCrRelationFind1,NULLTAG,&tCrRelationObj13));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj13));     
									}
									if (tCrItem14 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem14,tCrRelationFind1,NULLTAG,&tCrRelationObj14));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj14));     
									}
									if (tCrItem15 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem15,tCrRelationFind1,NULLTAG,&tCrRelationObj15));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj15));     
									}
									if (tCrItem16 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem16,tCrRelationFind1,NULLTAG,&tCrRelationObj16));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj16));     
									}
									if (tCrItem17 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem17,tCrRelationFind1,NULLTAG,&tCrRelationObj17));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj17));     
									}
									if (tCrItem18 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem18,tCrRelationFind1,NULLTAG,&tCrRelationObj18)); 
										ERROR_CALL(GRM_save_relation  (tCrRelationObj18));     
									}
									if (tCrItem19 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem19,tCrRelationFind1,NULLTAG,&tCrRelationObj19)); 
										ERROR_CALL(GRM_save_relation  (tCrRelationObj19));     
									}
									if (tCrItem20 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem20,tCrRelationFind1,NULLTAG,&tCrRelationObj20)); 
										ERROR_CALL(GRM_save_relation  (tCrRelationObj20));     
									}
									if (tCrItem21 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem21,tCrRelationFind1,NULLTAG,&tCrRelationObj21));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj21));     
									}
									if (tCrItem22 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem22,tCrRelationFind1,NULLTAG,&tCrRelationObj22));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj22));     
									}
									if (tCrItem23 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem23,tCrRelationFind1,NULLTAG,&tCrRelationObj23));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj23));     
									}
									if (tCrItem24 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem24,tCrRelationFind1,NULLTAG,&tCrRelationObj24));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj24));     
									}
									if (tCrItem25 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem25,tCrRelationFind1,NULLTAG,&tCrRelationObj25));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj25));     
									}
									if (tCrItem26 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem26,tCrRelationFind1,NULLTAG,&tCrRelationObj26));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj26));     
									}
									if (tCrItem27 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem27,tCrRelationFind1,NULLTAG,&tCrRelationObj27));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj27));     
									}
									if (tCrItem28 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem28,tCrRelationFind1,NULLTAG,&tCrRelationObj28));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj28));     
									}
									if (tCrItem29 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem29,tCrRelationFind1,NULLTAG,&tCrRelationObj29));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj29));     
									}
									if (tCrItem30 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem30,tCrRelationFind1,NULLTAG,&tCrRelationObj30));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj30));     
									}
									if (tCrItem31 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem31,tCrRelationFind1,NULLTAG,&tCrRelationObj31));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj31));     
									}
									if (tCrItem32 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem32,tCrRelationFind1,NULLTAG,&tCrRelationObj32));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj32));     
									}
									if (tCrItem33 !=NULLTAG){	
										ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem33,tCrRelationFind1,NULLTAG,&tCrRelationObj33));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj33));     
										}
									if (tCrItem34 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem34,tCrRelationFind1,NULLTAG,&tCrRelationObj34));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj34));     
									}
									if (tCrItem35 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem35,tCrRelationFind1,NULLTAG,&tCrRelationObj35));  	
										ERROR_CALL(GRM_save_relation  (tCrRelationObj35));     
									}
									if (tCrItem36 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem36,tCrRelationFind1,NULLTAG,&tCrRelationObj36));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj36));     
									}
									if (tCrItem37 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem37,tCrRelationFind1,NULLTAG,&tCrRelationObj37));  	
										ERROR_CALL(GRM_save_relation  (tCrRelationObj37));     
									}
									if (tCrItem38 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem38,tCrRelationFind1,NULLTAG,&tCrRelationObj38));  	
										ERROR_CALL(GRM_save_relation  (tCrRelationObj38));     
									}
									if (tCrItem39 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem39,tCrRelationFind1,NULLTAG,&tCrRelationObj39));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj39));     
									}
									if (tCrItem40 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem40,tCrRelationFind1,NULLTAG,&tCrRelationObj40));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj40));     
									}
									if (tCrItem41 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem41,tCrRelationFind1,NULLTAG,&tCrRelationObj41));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj41));     
									}
									if (tCrItem42 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem42,tCrRelationFind1,NULLTAG,&tCrRelationObj42));  	
										ERROR_CALL(GRM_save_relation  (tCrRelationObj42));     
									}
									if (tCrItem43 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem43,tCrRelationFind1,NULLTAG,&tCrRelationObj43));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj43));     
									}
									if (tCrItem44 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem44,tCrRelationFind1,NULLTAG,&tCrRelationObj44));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj44));     
									}
									if (tCrItem45 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem45,tCrRelationFind1,NULLTAG,&tCrRelationObj45));  	
										ERROR_CALL(GRM_save_relation  (tCrRelationObj45));     
									}
									if (tCrItem46 !=NULLTAG)
									{	
										ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem46,tCrRelationFind1,NULLTAG,&tCrRelationObj46));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj46));     
									}
									if (tCrItem47 !=NULLTAG)
									{	
										ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem47,tCrRelationFind1,NULLTAG,&tCrRelationObj47));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj47));     
									}
									if (tCrItem48 !=NULLTAG)
									{	
										ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem48,tCrRelationFind1,NULLTAG,&tCrRelationObj48));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj48));     
									}
									if (tCrItem49 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem49,tCrRelationFind1,NULLTAG,&tCrRelationObj49));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj49));     
									}
									if (tCrItem50 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem50,tCrRelationFind1,NULLTAG,&tCrRelationObj50));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj50));     
									}
									if (tCrItem51 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem51,tCrRelationFind1,NULLTAG,&tCrRelationObj51));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj51));     
									}
									if (tCrItem52 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem52,tCrRelationFind1,NULLTAG,&tCrRelationObj52));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj52));     
									}
									if (tCrItem53 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem53,tCrRelationFind1,NULLTAG,&tCrRelationObj53));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj53));     
									}
									if (tCrItem54 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem54,tCrRelationFind1,NULLTAG,&tCrRelationObj54));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj54));     
									}
									if (tCrItem55 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem55,tCrRelationFind1,NULLTAG,&tCrRelationObj55));  	
										ERROR_CALL(GRM_save_relation  (tCrRelationObj55));     
									}
									if (tCrItem56 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem56,tCrRelationFind1,NULLTAG,&tCrRelationObj56));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj56));     
									}
									if (tCrItem57 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem57,tCrRelationFind1,NULLTAG,&tCrRelationObj57));  
										ERROR_CALL(GRM_save_relation  (tCrRelationObj57));     
									}
									if (tCrItem58 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem58,tCrRelationFind1,NULLTAG,&tCrRelationObj58)); 
									ERROR_CALL(GRM_save_relation  (tCrRelationObj58));     
									}
									if (tCrItem59 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem59,tCrRelationFind1,NULLTAG,&tCrRelationObj59));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj59));  
									}
									if (tCrItem60 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem60,tCrRelationFind1,NULLTAG,&tCrRelationObj60));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj60));  
									}
									if (tCrItem61 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem61,tCrRelationFind1,NULLTAG,&tCrRelationObj61));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj61));   
									}
									if (tCrItem62 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem62,tCrRelationFind1,NULLTAG,&tCrRelationObj62));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj62));  
									}
									if (tCrItem63 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem63,tCrRelationFind1,NULLTAG,&tCrRelationObj63));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj63));   
									}
									if (tCrItem64 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem64,tCrRelationFind1,NULLTAG,&tCrRelationObj64));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj64));  
									}
									if (tCrItem65 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem65,tCrRelationFind1,NULLTAG,&tCrRelationObj65));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj65));   
									}
									if (tCrItem66 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem66,tCrRelationFind1,NULLTAG,&tCrRelationObj66));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj66));   
									}
									if (tCrItem67 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem67,tCrRelationFind1,NULLTAG,&tCrRelationObj67));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj67));   
									}
									if (tCrItem68 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem68,tCrRelationFind1,NULLTAG,&tCrRelationObj68));  	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj68));   
									}
									if (tCrItem69 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem69,tCrRelationFind1,NULLTAG,&tCrRelationObj69));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj69));    
									}
									if (tCrItem70 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem70,tCrRelationFind1,NULLTAG,&tCrRelationObj70));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj70));    
									}
									if (tCrItem71 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem71,tCrRelationFind1,NULLTAG,&tCrRelationObj71));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj71));    
									}
									if (tCrItem72 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem72,tCrRelationFind1,NULLTAG,&tCrRelationObj72));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj72));    
									}
									if (tCrItem73 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem73,tCrRelationFind1,NULLTAG,&tCrRelationObj73));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj73));   
									}
									if (tCrItem74 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem74,tCrRelationFind1,NULLTAG,&tCrRelationObj74));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj74));  
									}
									if (tCrItem75 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem75,tCrRelationFind1,NULLTAG,&tCrRelationObj75));  	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj75));  
									}
									if (tCrItem76 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem76,tCrRelationFind1,NULLTAG,&tCrRelationObj76));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj76));  
									}
									if (tCrItem77 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem77,tCrRelationFind1,NULLTAG,&tCrRelationObj77));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj77));  
									}
									if (tCrItem78 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem78,tCrRelationFind1,NULLTAG,&tCrRelationObj78));  	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj78)); 
									}
									if (tCrItem79 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem79,tCrRelationFind1,NULLTAG,&tCrRelationObj79));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj79)); 
									}
									if (tCrItem80 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem80,tCrRelationFind1,NULLTAG,&tCrRelationObj80));  	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj80));  
									}
									if (tCrItem81 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem81,tCrRelationFind1,NULLTAG,&tCrRelationObj81));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj81));   
									}
									if (tCrItem82 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem82,tCrRelationFind1,NULLTAG,&tCrRelationObj82));  	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj82));  
									}
									if (tCrItem83 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem83,tCrRelationFind1,NULLTAG,&tCrRelationObj83));  	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj83)); 
									}
									if (tCrItem84 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem84,tCrRelationFind1,NULLTAG,&tCrRelationObj84));  	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj84));  
									}
									if (tCrItem85 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem85,tCrRelationFind1,NULLTAG,&tCrRelationObj85));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj85));  
									}
									if (tCrItem86 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem86,tCrRelationFind1,NULLTAG,&tCrRelationObj86));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj86));  
									}
									if (tCrItem87 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem87,tCrRelationFind1,NULLTAG,&tCrRelationObj87));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj87));  
									}
									if (tCrItem88 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem88,tCrRelationFind1,NULLTAG,&tCrRelationObj88));  	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj88));   
									}
									if (tCrItem89 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem89,tCrRelationFind1,NULLTAG,&tCrRelationObj89));  	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj89));  
									}
									if (tCrItem90 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem90,tCrRelationFind1,NULLTAG,&tCrRelationObj90));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj90));    
									}
									if (tCrItem91 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem91,tCrRelationFind1,NULLTAG,&tCrRelationObj91));  
									ERROR_CALL(GRM_save_relation  (tCrRelationObj91));   
									}
									if (tCrItem92 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem92,tCrRelationFind1,NULLTAG,&tCrRelationObj92));  	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj92));   
									}
									if (tCrItem93 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem93,tCrRelationFind1,NULLTAG,&tCrRelationObj93));  	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj93));   
									}
									if (tCrItem94 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem94,tCrRelationFind1,NULLTAG,&tCrRelationObj94));  	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj94)); 
									}
									if (tCrItem95 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem95,tCrRelationFind1,NULLTAG,&tCrRelationObj95));  	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj95));   
									}
									if (tCrItem96 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem96,tCrRelationFind1,NULLTAG,&tCrRelationObj96));  	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj96));   
									}
									if (tCrItem97 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem97,tCrRelationFind1,NULLTAG,&tCrRelationObj97));  	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj97));   
									}
									if (tCrItem98 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem98,tCrRelationFind1,NULLTAG,&tCrRelationObj98));  	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj98));   
									}
									if (tCrItem99 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem99,tCrRelationFind1,NULLTAG,&tCrRelationObj99));  	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj99));   
									}
									if (tCrItem100!=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem100,tCrRelationFind1,NULLTAG,&tCrRelationObj100));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj100));  
									}
									if (tCrItem101 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem101,tCrRelationFind1,NULLTAG,&tCrRelationObj101));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj101));  
									}
									if (tCrItem102 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem102,tCrRelationFind1,NULLTAG,&tCrRelationObj102));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj102));  
									}
									if (tCrItem103 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem103,tCrRelationFind1,NULLTAG,&tCrRelationObj103));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj103));  
									}
									if (tCrItem104 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem104,tCrRelationFind1,NULLTAG,&tCrRelationObj104));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj104));  
									}
									if (tCrItem105 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem105,tCrRelationFind1,NULLTAG,&tCrRelationObj105));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj105));  
									}
									if (tCrItem106 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem106,tCrRelationFind1,NULLTAG,&tCrRelationObj106));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj106));  
									}
									if (tCrItem107 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem107,tCrRelationFind1,NULLTAG,&tCrRelationObj107));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj107));  
									}
									if (tCrItem108 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem108,tCrRelationFind1,NULLTAG,&tCrRelationObj108));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj108));  
									}
									if (tCrItem109 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem109,tCrRelationFind1,NULLTAG,&tCrRelationObj109));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj109));  
									}
									if (tCrItem110 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem110,tCrRelationFind1,NULLTAG,&tCrRelationObj110));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj110));  
									}
									if (tCrItem111 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem111,tCrRelationFind1,NULLTAG,&tCrRelationObj111));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj111));  
									}
									if (tCrItem112 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem112,tCrRelationFind1,NULLTAG,&tCrRelationObj112));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj112)); 
									}
									if (tCrItem113 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem113,tCrRelationFind1,NULLTAG,&tCrRelationObj113));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj113));   
									}
									if (tCrItem114 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem114,tCrRelationFind1,NULLTAG,&tCrRelationObj114));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj114));   
									}
									if (tCrItem115 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem115,tCrRelationFind1,NULLTAG,&tCrRelationObj115));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj115));   
									}
									if (tCrItem116 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem116,tCrRelationFind1,NULLTAG,&tCrRelationObj116));
									ERROR_CALL(GRM_save_relation  (tCrRelationObj116));  
									}
									if (tCrItem117 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem117,tCrRelationFind1,NULLTAG,&tCrRelationObj117));
									ERROR_CALL(GRM_save_relation  (tCrRelationObj117));   
									}
									if (tCrItem118 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem118,tCrRelationFind1,NULLTAG,&tCrRelationObj118));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj118));  
									}
									if (tCrItem119 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem119,tCrRelationFind1,NULLTAG,&tCrRelationObj119));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj119));   
									}
									if (tCrItem120 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem120,tCrRelationFind1,NULLTAG,&tCrRelationObj120));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj120));  
									}
									if (tCrItem121 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem121,tCrRelationFind1,NULLTAG,&tCrRelationObj121));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj121));    
									}
									if (tCrItem122 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem122,tCrRelationFind1,NULLTAG,&tCrRelationObj122));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj122));   
									}
									if (tCrItem123 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem123,tCrRelationFind1,NULLTAG,&tCrRelationObj123));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj123));   
									}
									if (tCrItem124 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem124,tCrRelationFind1,NULLTAG,&tCrRelationObj124));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj124));   
									}
									if (tCrItem125 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem125,tCrRelationFind1,NULLTAG,&tCrRelationObj125));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj125)); 
									}
									if (tCrItem126 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem126,tCrRelationFind1,NULLTAG,&tCrRelationObj126));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj126));   
									}
									if (tCrItem127 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem127,tCrRelationFind1,NULLTAG,&tCrRelationObj127));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj127));   
									}
									if (tCrItem128 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem128,tCrRelationFind1,NULLTAG,&tCrRelationObj128));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj128));   
									}
									if (tCrItem129 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem129,tCrRelationFind1,NULLTAG,&tCrRelationObj129));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj129));   
									}
									if (tCrItem130 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem130,tCrRelationFind1,NULLTAG,&tCrRelationObj130));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj130)); 
									}
									if (tCrItem131 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem131,tCrRelationFind1,NULLTAG,&tCrRelationObj131));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj131));  
									}
									if (tCrItem132 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem132,tCrRelationFind1,NULLTAG,&tCrRelationObj132));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj132));   
									}
									if (tCrItem133 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem133,tCrRelationFind1,NULLTAG,&tCrRelationObj133));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj133));   
									}
									if (tCrItem134 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem134,tCrRelationFind1,NULLTAG,&tCrRelationObj134));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj134));  
									}
									if (tCrItem135 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem135,tCrRelationFind1,NULLTAG,&tCrRelationObj135));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj135));   
									}
									if (tCrItem136 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem136,tCrRelationFind1,NULLTAG,&tCrRelationObj136));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj136));   
									}
									if (tCrItem137 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem137,tCrRelationFind1,NULLTAG,&tCrRelationObj137));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj137));   
									}
									if (tCrItem138 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem138,tCrRelationFind1,NULLTAG,&tCrRelationObj138));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj138));   
									}
									if (tCrItem139 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem139,tCrRelationFind1,NULLTAG,&tCrRelationObj139));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj139));    
									}
									if (tCrItem140 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem140,tCrRelationFind1,NULLTAG,&tCrRelationObj140));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj140));   
									}
									if (tCrItem141 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem141,tCrRelationFind1,NULLTAG,&tCrRelationObj141));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj141));   
									}
									if (tCrItem142 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem142,tCrRelationFind1,NULLTAG,&tCrRelationObj142));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj142));   
									}
									if (tCrItem143 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem143,tCrRelationFind1,NULLTAG,&tCrRelationObj143));
									ERROR_CALL(GRM_save_relation  (tCrRelationObj143));   
									}
									if (tCrItem144 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem144,tCrRelationFind1,NULLTAG,&tCrRelationObj144));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj144));   
									}
									if (tCrItem145 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem145,tCrRelationFind1,NULLTAG,&tCrRelationObj145));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj145));   
									}
									if (tCrItem146 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem146,tCrRelationFind1,NULLTAG,&tCrRelationObj146));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj146));   
									}
									if (tCrItem147 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem147,tCrRelationFind1,NULLTAG,&tCrRelationObj147));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj147));   
									}
									if (tCrItem148 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem148,tCrRelationFind1,NULLTAG,&tCrRelationObj148));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj148));   
									}
									if (tCrItem149 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem149,tCrRelationFind1,NULLTAG,&tCrRelationObj149));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj149));   
									}
									if (tCrItem150 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem150,tCrRelationFind1,NULLTAG,&tCrRelationObj150));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj150));    
									}
									if (tCrItem151 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem151,tCrRelationFind1,NULLTAG,&tCrRelationObj151));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj151));   
									}
									if (tCrItem152 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem152,tCrRelationFind1,NULLTAG,&tCrRelationObj152));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj152));   
									}
									if (tCrItem153 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem153,tCrRelationFind1,NULLTAG,&tCrRelationObj153));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj153));  
									}
									if (tCrItem154 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem154,tCrRelationFind1,NULLTAG,&tCrRelationObj154));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj154));   
									}
									if (tCrItem155 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem155,tCrRelationFind1,NULLTAG,&tCrRelationObj155));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj155));   
									}
									if (tCrItem156 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem156,tCrRelationFind1,NULLTAG,&tCrRelationObj156));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj156));   
									}
									if (tCrItem157 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem157,tCrRelationFind1,NULLTAG,&tCrRelationObj157));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj157));   
									}
									if (tCrItem158 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem158,tCrRelationFind1,NULLTAG,&tCrRelationObj158));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj158));   
									}
									if (tCrItem159 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem159,tCrRelationFind1,NULLTAG,&tCrRelationObj159));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj159));    
									}
									if (tCrItem160 !=NULLTAG)
									{	ERROR_CALL(GRM_create_relation(tDvoItemRev,tCrItem160,tCrRelationFind1,NULLTAG,&tCrRelationObj160));	
									ERROR_CALL(GRM_save_relation  (tCrRelationObj160));    
									}

								
									printf("\nRelation Created Successfully between DVO and Criteria\n");fflush(stdout);
								}	
								//EPM_find_template("DVO Workflow",0,&process_task_template); 
								//EPM_find_process_template ("DVO Workflow", &process_task_template);
								printf("After process_task_template:%d\n",process_task_template);
								
								//WSOM_copy(tDvoItemRev,"NULL",temptag); 
								//temptag[0]=tDvoItemRev;
								//ERROR_CALL(AOM_get_value_string(tDvoItem,"item_id",&t5DvoID));
								//printf("\nValue of DVO NAME : %s\n",t5DvoID);
								//strcat(ReqID,"(");
								//strcat(ReqID,ReqOwnAttrGrp);
								//strcat(ReqID,")");
								//printf("\nValue of DVO NAME : %s\n",ReqID);

								//ERROR_CALL(EPM_create_process( ReqName,"Testing",process_task_template,1,&tDvoItemRev,&AttachmentType,&new_process)); 
								printf("After EPM_create_process:%d\n",new_process);
		
							}
							else
							{
								printf("\n Relation already exist Between DVO and Requirement Object \n");fflush(stdout);	
							}
						}
						}
					}
					else
					{
						printf("\nNo Relation With DVM ..... So no Need To Create DVO\n");fflush(stdout);
					}
			tCrItem1	= NULLTAG;
									tCrItem2	= NULLTAG;
									tCrItem3	= NULLTAG;
									tCrItem4	= NULLTAG;
									tCrItem5	= NULLTAG;
									tCrItem6	= NULLTAG;
									tCrItem7	= NULLTAG;
									tCrItem8	= NULLTAG;
									tCrItem9	= NULLTAG;
									tCrItem10	= NULLTAG;
									tCrItem11	= NULLTAG;
									tCrItem12	= NULLTAG;
									tCrItem13	= NULLTAG;
									tCrItem14	= NULLTAG;
									tCrItem15	= NULLTAG;
									tCrItem16	= NULLTAG;
									tCrItem17	= NULLTAG;
									tCrItem18	= NULLTAG;
									tCrItem19	= NULLTAG;
									tCrItem20	= NULLTAG;
									tCrItem21	= NULLTAG;
									tCrItem22	= NULLTAG;
									tCrItem23	= NULLTAG;
									tCrItem24	= NULLTAG;
									tCrItem25	= NULLTAG;
									tCrItem26	= NULLTAG;
									tCrItem27	= NULLTAG;
									tCrItem28	= NULLTAG;
									tCrItem29	= NULLTAG;
									tCrItem30	= NULLTAG;
									tCrItem31	= NULLTAG;
									tCrItem32	= NULLTAG;
									tCrItem33	= NULLTAG;
									tCrItem34	= NULLTAG;
									tCrItem35	= NULLTAG;
									tCrItem36	= NULLTAG;
									tCrItem37	= NULLTAG;
									tCrItem38	= NULLTAG;
									tCrItem39	= NULLTAG;
									tCrItem40	= NULLTAG;
									tCrItem41	= NULLTAG;
									tCrItem42	= NULLTAG;
									tCrItem43	= NULLTAG;
									tCrItem44	= NULLTAG;
									tCrItem45	= NULLTAG;
									tCrItem46	= NULLTAG;
									tCrItem47	= NULLTAG;
									tCrItem48	= NULLTAG;
									tCrItem49	= NULLTAG;
									tCrItem50	= NULLTAG;
									tCrItem51	= NULLTAG;
									tCrItem52	= NULLTAG;
									tCrItem53	= NULLTAG;
									tCrItem54	= NULLTAG;
									tCrItem55	= NULLTAG;
									tCrItem56	= NULLTAG;
									tCrItem57	= NULLTAG;
									tCrItem58	= NULLTAG;
									tCrItem59	= NULLTAG;
									tCrItem60	= NULLTAG;
									tCrItem61	= NULLTAG;
									tCrItem62	= NULLTAG;
									tCrItem63	= NULLTAG;
									tCrItem64	= NULLTAG;
									tCrItem65	= NULLTAG;
									tCrItem66	= NULLTAG;
									tCrItem67	= NULLTAG;
									tCrItem68	= NULLTAG;
									tCrItem69	= NULLTAG;
									tCrItem70	= NULLTAG;
									tCrItem71	= NULLTAG;
									tCrItem72	= NULLTAG;
									tCrItem73	= NULLTAG;
									tCrItem74	= NULLTAG;
									tCrItem75	= NULLTAG;
									tCrItem76	= NULLTAG;
									tCrItem77	= NULLTAG;
									tCrItem78	= NULLTAG;
									tCrItem79	= NULLTAG;
									tCrItem80	= NULLTAG;
									tCrItem81	= NULLTAG;
									tCrItem82	= NULLTAG;
									tCrItem83	= NULLTAG;
									tCrItem84	= NULLTAG;
									tCrItem85	= NULLTAG;
									tCrItem86	= NULLTAG;
									tCrItem87	= NULLTAG;
									tCrItem88	= NULLTAG;
									tCrItem89	= NULLTAG;
									tCrItem90	= NULLTAG;
									tCrItem91	= NULLTAG;
									tCrItem92	= NULLTAG;
									tCrItem93	= NULLTAG;
									tCrItem94	= NULLTAG;
									tCrItem95	= NULLTAG;
									tCrItem96	= NULLTAG;
									tCrItem97	= NULLTAG;
									tCrItem98	= NULLTAG;
									tCrItem99	= NULLTAG;
									tCrItem100	= NULLTAG;
									tCrItem101	= NULLTAG;
									tCrItem102	= NULLTAG;
									tCrItem103	= NULLTAG;
									tCrItem104	= NULLTAG;
									tCrItem105	= NULLTAG;
									tCrItem106	= NULLTAG;
									tCrItem107	= NULLTAG;
									tCrItem108	= NULLTAG;
									tCrItem109	= NULLTAG;
									tCrItem110	= NULLTAG;
									tCrItem111	= NULLTAG;
									tCrItem112	= NULLTAG;
									tCrItem113	= NULLTAG;
									tCrItem114	= NULLTAG;
									tCrItem115	= NULLTAG;
									tCrItem116	= NULLTAG;
									tCrItem117	= NULLTAG;
									tCrItem118	= NULLTAG;
									tCrItem119	= NULLTAG;
									tCrItem120	= NULLTAG;
									tCrItem121	= NULLTAG;
									tCrItem122	= NULLTAG;
									tCrItem123	= NULLTAG;
									tCrItem124	= NULLTAG;
									tCrItem125	= NULLTAG;
									tCrItem126	= NULLTAG;
									tCrItem127	= NULLTAG;
									tCrItem128	= NULLTAG;
									tCrItem129	= NULLTAG;
									tCrItem130	= NULLTAG;
									tCrItem131	= NULLTAG;
									tCrItem132	= NULLTAG;
									tCrItem133	= NULLTAG;
									tCrItem134	= NULLTAG;
									tCrItem135	= NULLTAG;
									tCrItem136	= NULLTAG;
									tCrItem137	= NULLTAG;
									tCrItem138	= NULLTAG;
									tCrItem139	= NULLTAG;
									tCrItem140	= NULLTAG;
									tCrItem141	= NULLTAG;
									tCrItem142	= NULLTAG;
									tCrItem143	= NULLTAG;
									tCrItem144	= NULLTAG;
									tCrItem145	= NULLTAG;
									tCrItem146	= NULLTAG;
									tCrItem147	= NULLTAG;
									tCrItem148	= NULLTAG;
									tCrItem149	= NULLTAG;
									tCrItem150	= NULLTAG;
									tCrItem151	= NULLTAG;
									tCrItem152	= NULLTAG;
									tCrItem153	= NULLTAG;
									tCrItem154	= NULLTAG;
									tCrItem155	= NULLTAG;
									tCrItem156	= NULLTAG;
									tCrItem157	= NULLTAG;
									tCrItem158	= NULLTAG;
									tCrItem159	= NULLTAG;
									tCrItem160	= NULLTAG;	
			}
			printf("\nDVM not found in Requirement\n");
				}
				}
				}
				fclose (fp1);
				printf("\nFile closed\n");
				remove(inputfile);
				printf("\nFile deleted\n");
				}
				} // If of TEXT
				else
				{
					printf("\nNo Requirement Folder inside Passed Folder\n");fflush(stdout);
				}
			}
		}
		else
		{
			printf("\nRequirement Folder Not Found Inside Passed Folder\n");fflush(stdout);
		}
	}
	else
	{
		printf("\nPassed Folder Not Found in Home Folder\n");fflush(stdout);
	}

	

     printf("\n The End....");

	 return ITK_ok;
}

