/****************************************************************************************************
*  File	           :   tm_std_dml_assign.c ( File name )
*  Project         :   PLM TCUA Project-STDS1.		     
*  Modification History :
*  Date			Modified By			TZ			Modification Notes
*  20/06/18		Priti Pagar			1.35		STDSI Sign off validations-1. Previous revision not released check
																		   2. Child part not released
																		   3. AMDML validations bypass
																		   4. Two revision can not be released on same day
																		   5. Next revision of part exists with DR>DR3
																		   6. PP/PM DML for part released error
*******************************************************************************************************/

#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#include "tm_apl_std_common_function.c"
#define NULLDATE   (POM_null_date()) 

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002

int cnt = 0;
int cntFlag = 0;
int epacnt = 0;
int cntEPAFlag = 0;


#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;


static int t5UpdateLifecycleStateSTD(tag_t object_tag, char* lifecycleStateName, char* lcstoremove)
{
	int n_values_checkin = 0;
	int cunt1 = 0;
	int flag = 0;
	int				ifail=0;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;
    logical stat  ;
	char*			value					=NULL;
	char cNextDate[20]={0};

	char *class_name = NULL;
	char *Release_Status = NULL;

	tag_t		class_id				=     NULLTAG;
	tag_t		tReleaseStatusList_checkin=NULLTAG;
	tag_t*		attr_tags_checkin		=	NULLTAG;
	tag_t			status_rel					= NULLTAG;
	tag_t*    status_list1=NULLTAG;
	int              st_count1 = 0;
	int				st_count_1 = 0;
	int				DMLFlag =0;

	tag_t*    status_list;
	tag_t*    status_list_1=NULLTAG;
	tag_t	*rev_list				= NULL;
	int       ii=0;
	int       RevFlag=0;
	int       PreRevFlag=0;
	int       st_count=0;
	int Item_count      =  0;
	char*			PreRevOnly				= NULL;
	char*			RevOnly				= NULL;
	char*			Part_Rev				= NULL;
	char*			Part_Rev_copy				= NULL;
	char*			Part_rev_Id				= NULL;
	char*			PlantLCSFlag				= NULL;
	int       iLCS=0;
	int       cntLcs=0;
	WSOM_open_ended_status_t  	open_ended_or_stock_out;
	char cCurrentAccessDate[20]={0};
	date_t Ltest_date_2;
	date_t *Rel_start_end_values	= NULL;
	int	n_dates 	= 0;
	int	n_effectivities 		= 0;
	int	jj 		= 0;
    char	*old_to_date			= NULL;
	logical date_is_valid  ;
	date_t Ltest_date_1;
	date_t *Lstart_end_date			= NULL;
	tag_t	Leff_d				= NULLTAG;
	tag_t	*effectivities_tag		= NULL;

	logical		*is_it_null_checkin		=   NULL;
	logical		*is_it_empty_checkin	=   NULL;
	logical		log1;
	logical		checkout1;
	logical			retain							= 0;

	char*			Part_no				= NULL;
	char		   *WSO_Name	=	NULL;
	const char *qry_entries[2];//Multiple Item Queried Error
	const char *qry_values[2];//Multiple Item Queried Error
	int n_tags_found=0;
	tag_t	*itemclassp	= NULLTAG;
	tag_t item = NULLTAG;
	char	*Part_clr_ind	=	NULL;
	printf("\n inside t5UpdateLifecycleStateSTD: [%s:%s]\n ",lifecycleStateName,lcstoremove);fflush(stdout);
	ITKCALL(WSOM_ask_release_status_list(object_tag,&st_count_1,&status_list_1));         //**VB**
	printf("\n st_count1 :%d is\n",st_count_1);fflush(stdout);
	if(st_count_1>0)
	{
		for (cnt=0;cnt< st_count_1;cnt++ )
		{
			WSO_Name=NULL;
			ITKCALL(AOM_ask_name(status_list_1[cnt],&WSO_Name));
			printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
			if(tc_strcmp(WSO_Name,"")!=0)
			{
				//if (tc_strcmp(WSO_Name,"T5_LcsSTDWrkg")==0)
				if (tc_strcmp(WSO_Name,lifecycleStateName)==0)
				{
					DMLFlag = 1;
				}
			}
		}
	}
	if(strcmp(lcstoremove,"NA")==0 && DMLFlag == 0))
	{
		printf("\n Inside NA....");fflush(stdout);
		if (CR_create_release_status(lifecycleStateName,&status_rel));
		if(EPM_add_release_status(status_rel,1,&object_tag,retain));
	}
else
   {
	CALLAPI(POM_class_of_instance(object_tag,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));
	printf("\n class_name is :%s\n",class_name);fflush(stdout);

	CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
	CALLAPI(WSOM_ask_release_status_list(object_tag,&st_count1,&status_list1));
	printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

	CALLAPI(POM_unload_instances (1,&object_tag));
	CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
	CALLAPI(POM_is_loaded(object_tag,&log1));
	if(log1 == 1)
	{
		 printf(" Load Success\n " );
	}
	else
	printf("Load Failure\n"  );

	CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin) );
	printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
	if(n_values_checkin>0)
	{
		CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
		printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);
        flag = 0;
		for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
		{
			printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
			if(AOM_ask_name(attr_tags_checkin[cunt1], &Release_Status));
		   printf("\n  Release_Status changes done: for workspaceobject     %s\n", Release_Status);fflush(stdout);
            if( (tc_strstr(lifecycleStateName,"T5_LcsStd")!=NULL) && (tc_strstr(lifecycleStateName,"Rlzd")!=NULL) )
            {
				if( (tc_strcmp(Release_Status,lcstoremove)==0))
				{
				CALLAPI(POM_unload_instances (1,&object_tag));
				CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
				CALLAPI(POM_is_loaded(object_tag,&log1));

				//CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,flag,1));
				CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,cunt1,1));
				printf("\n cunt 1 == 0 removedd is :%d\n",cunt1);fflush(stdout);

				CALLAPI(POM_save_instances(1,&object_tag,1));

				CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));

				CALLAPI(AOM_lock(object_tag));

				CALLAPI(AOM_save(object_tag));
				CALLAPI(AOM_refresh(object_tag,1));
				 CALLAPI(AOM_unlock(object_tag));
				 //PlantLCSFlag = "CAR";
				}
			}

			if( (tc_strcmp(Release_Status,lifecycleStateName)==0))
				{
				CALLAPI(POM_unload_instances (1,&object_tag));
				CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
				CALLAPI(POM_is_loaded(object_tag,&log1));

				//CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,flag,1));
				CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,cunt1,1));
				printf("\n cunt 1 == 0 removedd is :%d\n",cunt1);fflush(stdout);

				CALLAPI(POM_save_instances(1,&object_tag,1));

				CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));

				CALLAPI(AOM_lock(object_tag));

				CALLAPI(AOM_save(object_tag));
				CALLAPI(AOM_refresh(object_tag,1));
				 CALLAPI(AOM_unlock(object_tag));
				 //PlantLCSFlag = "CAR";
				}


		}

	}
	if (DMLFlag == 0)
	{
		if (CR_create_release_status(lifecycleStateName,&status_rel));
		if(EPM_add_release_status(status_rel,1,&object_tag,retain));
	}
	if (tc_strcmp(class_name,"Design_0_Revision_alt")==0 || tc_strcmp(class_name,"Design Revision")==0 || tc_strcmp(class_name,"T5_ClrPartRevision")==0)
	{
		CALLAPI(WSOM_ask_effectivity_mode(&stat));

	//	getCurrentDateTime(cCurrentAccessDate);
		CALLAPI(PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag));
		CALLAPI(PROP_ask_value_string(propEff_tag,&value));

		getNextDate(cNextDate);
		printf("\n cNextDate:%s",cNextDate);

		CALLAPI(ITK_string_to_date(cNextDate, &test_date_1 ));
		CALLAPI(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));

		start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

		printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

		start_end_date[0] = test_date_1;
		start_end_date[1] = test_date_2;

		CALLAPI(WSOM_status_clear_effectivities (status_rel));
		CALLAPI(WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
		CALLAPI(AOM_save(eff_d));
		CALLAPI(AOM_save(status_rel));
		CALLAPI(AOM_refresh(status_rel,0));

         // Start Privious Rev and stamp the close date
		 CALLAPI(AOM_ask_value_string(object_tag,"item_revision_id",&Part_Rev));
		 CALLAPI(AOM_ask_value_string(object_tag,"item_revision_id",&Part_Rev_copy));
		 printf("\n Part_Rev: %s", Part_Rev);fflush(stdout);
		 printf("\n Part_Rev_copy: %s", Part_Rev_copy);fflush(stdout);

		ITKCALL(AOM_ask_value_string(object_tag,"item_id",&Part_no));
		printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);
		Part_clr_ind	=	NULL;
		ITKCALL(AOM_ask_value_string(object_tag,"t5_ColourInd",&Part_clr_ind));
		printf("\n\n\t\t Part_clr_ind  is :%s",Part_clr_ind);	fflush(stdout);

		qry_entries[0] ="item_id";
		qry_entries[1] ="object_type";//Multiple Item Queried Error
		qry_values[0] = Part_no;
		if (tc_strcmp(Part_clr_ind,"C")==0)
		{
			qry_values[1] = "T5_ClrPart";//Multiple Item Queried Error Hemal
		}
		else
		{
			//qry_values[1] = "Design";//Multiple Item Queried Error Hemal
			//Handle the different design child class.
			char	*designBORev		=	NULL;
			char	*designBO			=	NULL;
			tag_t	AssyTag			=	NULLTAG;
			//AssyTag=PartTags[k];
			printf("\nBefore getDesignType");fflush(stdout);
			getDesignType(object_tag, &designBORev,&designBO);
			printf("\nAfter getDesignType : %s",designBO);fflush(stdout);
			qry_values[1] = designBO;

		}//Multiple Item Queried Error
		//ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclassp);
		ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found, &itemclassp);//Multiple Item Queried Error
		//ITKCALL(ITEM_find_item(Part_no,&itemclassp));
		item = itemclassp[0];

		CALLAPI(ITEM_list_all_revs (item, &Item_count, &rev_list));
		printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);
			if(Item_count > 0)
			{
				RevFlag = 0;
				PreRevFlag = 0;
				for(ii=Item_count-1;ii>=0;ii--)
				{
				   RevOnly = NULL;
				   PreRevOnly = NULL;
				   CALLAPI(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));
					printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);
					printf("\n Part_rev_Id: %s\n",Part_rev_Id);fflush(stdout);
					if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
					{
						RevFlag = 1;
					}
					printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
					if(RevFlag == 1)
					{
					   RevOnly= strtok( Part_Rev_copy, ";" );
					   PreRevOnly= strtok( Part_rev_Id, ";" );
					   printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
					   printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
					   if(tc_strcmp(RevOnly,PreRevOnly)!=0)
						{
						  PreRevFlag = 1;
						}
					}
					printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
					if(PreRevFlag == 1)
					{
						CALLAPI(WSOM_ask_release_status_list(rev_list[ii],&st_count,&status_list));
						if(st_count == 0)
						{
						printf("\n NO LCS Found for part : %d\n",st_count);fflush(stdout);
						break;
						}
						else
						{
							for (iLCS=0;iLCS<st_count ;iLCS++ )
							{
									CALLAPI(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
									printf("\n class_name: %s\n",class_name);fflush(stdout);
									//if(tc_strcmp(PlantLCSFlag,"CAR")==0)
									//{
									if(tc_strcmp(class_name,lifecycleStateName)==0)
									{
										getCurrentDateTime(cCurrentAccessDate);
										printf("\n Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);
										if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &Ltest_date_2 )))
										{
											return ifail;
										}
										if(ITK_ok != (ifail = WSOM_status_ask_effectivities (status_list[iLCS],&n_effectivities, &effectivities_tag) )) return ifail;
										printf("\n Eff:n_effectivities count:[%d] \n",n_effectivities);fflush(stdout);
										if(n_effectivities > 0)
										{
											for(jj=0;jj<n_effectivities;jj++)
											{
												if(ITK_ok != (ifail = WSOM_effectivity_ask_dates(effectivities_tag[jj],&n_dates,&Rel_start_end_values,&open_ended_or_stock_out )))return ifail;
												printf("\n Eff:no of Rel_start_end_value:%d\n", n_dates);fflush(stdout);
												if(n_dates > 0)
												{
													if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
													{
														return ifail;
													}
													printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
													if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 )))
													{
														return ifail;
													}
													printf(" and  DATE_string_to_date_t..\n");fflush(stdout);
													if(date_is_valid != true)
													{
														printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
													}
													else
													{
														printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
													}
												}
												else
												{
													printf("\n EFF1:NO Eff date available, so setting closure date....");fflush(stdout);
												}
											}

											Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
											Lstart_end_date[0] = Ltest_date_1;
											Lstart_end_date[1] = Ltest_date_2;

											printf("\n ERCReview--EFF:Clearing effectivities...");fflush(stdout);
											if(ITK_ok != (ifail = WSOM_status_clear_effectivities (status_list[iLCS])))
											{
												return ifail;
											}

											printf("\n ERCReview--EFF:Creating effectivities...");fflush(stdout);
											if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_list[iLCS], NULLTAG, 2,Lstart_end_date, EFFECTIVITY_closed, &Leff_d )))
											{
												return ifail;
											}
											printf("\n ERCReview--EFF:Saving effectivities...");fflush(stdout);
											if(ITK_ok != (ifail = AOM_save(Leff_d)))
											{
												return ifail;
											}
											printf("\n ERCReview--EFF:Saving Revision...");fflush(stdout);
											if(ITK_ok != (ifail = AOM_save(status_list[iLCS])))
											{
												return ifail;
											}
											printf("\n ERCReview--EFF:Refreshing Revision...");fflush(stdout);
											if(ITK_ok != (ifail = AOM_refresh( status_list[iLCS], 0 )))
											{
												return ifail;
											}
										}
										
										break;

									}
							}
						printf("\n cntLcs inside : %d\n",cntLcs);fflush(stdout);
						break;
						}
					}  /// End Prev Rev  Flag Loop
				}
			} /// End Prev Rev

	}
		else if(tc_strcmp(class_name,"VariantRule")==0)
		{
			CALLAPI(WSOM_ask_effectivity_mode(&stat));

		//	getCurrentDateTime(cCurrentAccessDate);
			CALLAPI(PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag));
			CALLAPI(PROP_ask_value_string(propEff_tag,&value));

			getNextDate(cNextDate);
			printf("\n cNextDate:%s",cNextDate);

			CALLAPI(ITK_string_to_date(cNextDate, &test_date_1 ));
			CALLAPI(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));

			start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

			printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

			start_end_date[0] = test_date_1;
			start_end_date[1] = test_date_2;

			CALLAPI(WSOM_status_clear_effectivities (status_rel));
			CALLAPI(WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
			CALLAPI(AOM_save(eff_d));
			CALLAPI(AOM_save(status_rel));
			CALLAPI(AOM_refresh(status_rel,0));
		}
	}

	return 0;
}

int tm_std_dml_assign( EPM_action_message_t msg )
{

		int   ifail				= 0;
		int	  noAttachment,t,n_attchs,i,m,noTaskAttachment,l;
		int  attype = 1;
		int  count = 1;
		int  TaskCnt = 1;
		tag_t			parent_task				=NULLTAG;
		tag_t			rootTask				=NULLTAG;
		tag_t			*attachments			=NULLTAG;
		tag_t			*Taskattachments			=NULLTAG;
		tag_t			item					=NULLTAG;
		tag_t			*Dml_Task_Tag					=NULLTAG;
	    tag_t DMLTag = NULLTAG;
	    tag_t			APLDMLRevTag		= NULLTAG;
	    tag_t*			TaskRevision		= NULLTAG;

		tag_t			*objTypeTagTask			= NULLTAG;
	    tag_t	relation_type,relation	,propTag	= NULLTAG;

		//GRM_relation_t			*secondary_objects	;
		tag_t			primary					=NULLTAG;
		tag_t			*secondary_objects					=NULLTAG;
		tag_t			remove					= NULLTAG;
		tag_t			user_tag				=NULLTAG;
		tag_t			job						= NULLTAG;
		tag_t		   Analystusertag			= NULLTAG;
     	tag_t			TaskRevTag			= NULLTAG;
		char		*job_name					= NULL;
		char		*job_name_new				= NULL;


		char*			parent_name				=NULL;
		char*			object_type				=NULL;
		char*			Analyst_name			=NULL;
		char*			DmlAnalyst_name			=NULL;

		char*			Dml_no					=NULL;
		char*			CurrentTask				=NULL;
		char*			TaskName				=NULL;
		char*			username				=NULL;
		char*			ImplbyTaskNo			=NULL;
		char*			token					=NULL;
		char*			Tasktoken					=NULL;



		POM_get_user(&username,&user_tag);
		printf("\nStarting for username :%s....\n",username);fflush(stdout);
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n tm_std_dml_assign \n"); fflush(stdout);
		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	   printf("\nCurrentTask:%s\n",CurrentTask);
		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\nParent Name:%s\n",parent_name);fflush(stdout);

			CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
			printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
			 if(noAttachment > 0)
			{
			   for(t=0;t<noAttachment;t++)
			   {
				   DMLTag = attachments[t];
				  AOM_ask_value_string(attachments[t],"object_type",&object_type);
				  printf("\n object_type is :%s\n",object_type);fflush(stdout);
     			  if(strcmp(object_type,"T5_APLDMLRevision")==0)
				  {
					CALLAPI(AOM_ask_value_string(attachments[t],"current_id",&Dml_no));
					printf("\n Dml_no is :%s\n",Dml_no);	fflush(stdout);
				   if (DMLTag != NULLTAG)
				    {
							GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
							CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&count,&TaskRevision));
							printf("\n\n\t\t APL DML Cre:ERC DML to Task : %d",count);fflush(stdout);
						   for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
							{
								TaskRevTag = TaskRevision[TaskCnt];
								CALLAPI(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
								printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
								if(strcmp(object_type,"T5_APLTaskRevision")==0)
								{
								if(AssignSTDAnalyst(TaskRevTag));
								if(AssignSTDReviewer(TaskRevTag));
								}
							}
			        }
		       }
			 }
			}

		return ITK_ok;
}

int std_dml_claim( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *itemid 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;

	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	int              st_count1 = 0;
	int              cnt = 0;
	int              DMLFlag = 0;
	int              PartFlag = 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
	tag_t*    status_list1=NULLTAG;
	tag_t*    status_list1_assy=NULLTAG;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char *Part_Coated = NULL;
	char *Part_ColourInd = NULL;
	char *Part_Type = NULL;
	char **DesignGroupList;
	char *WSO_Name = NULL;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	char RevisionRule[40];
	char ClosureRule[40];
	char BVR[40];
	char APLDmlPlnt[40];
	char STDDmlPlnt[40];

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside std_dml_claim***************\n ");fflush(stdout);

	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}


	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n std_dml_claim \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);

	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name(objTypeTag,type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	AOM_ask_value_string( DMLTag, "item_id", &itemid);
	printf("\n itemid:%s\n",itemid);

		char LcsStdWrkg[40];
		char LcsStdRlzd[40];

		GetPlantWiseRelStat(itemid,LcsStdWrkg,LcsStdRlzd);
		printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
		printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);

		//strcpy(lcsToset,"T5_LcsSTDWrkg");
		  strcpy(lcsToset,LcsStdWrkg);


	if(strcmp(type_name,"T5_APLTaskRevision")==0 || strcmp(CurrentTask,"Create EPA")==0)
	{
		    printf("\n inside class T5_APLTaskRevision......\n");fflush(stdout);
			AOM_ask_value_string( DMLTag, "item_id", &item_id);
			AOM_ask_value_string( DMLTag, "current_id", &DML_no);
			AOM_ask_value_strings(DMLTag,"t5_crdesigngroup",&num,&DesignGroupList);
			//AOM_ask_value_string(DMLTag,"t5_rlstype",&RlsType);
			AOM_ask_value_string( DMLTag, "t5_crdesigngroup", &Proj_Code);


			ITKCALL(WSOM_ask_release_status_list(DMLTag,&st_count1,&status_list1));
			printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

			if(st_count1>0)
			{
				for (cnt=0;cnt< st_count1;cnt++ )
				{
					WSO_Name=NULL;
					ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
					printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
					if(tc_strcmp(WSO_Name,"")!=0)
						{
							//if (tc_strcmp(WSO_Name,"T5_LcsSTDWrkg")==0)
							if (tc_strcmp(WSO_Name,LcsStdWrkg)==0)
							{
								DMLFlag = 1;
							}
						}
				}
			}

			if(DMLFlag == 0)
			{
				CALLAPI(CR_create_release_status(lcsToset,&status2));
				CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
				printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
				CALLAPI(EPM_add_release_status(status2,1,&DMLTag,retain));
			}

			ITKCALL(SA_ask_current_role(&CurrentRoleTag));
			ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
			printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

			printf("\n Proj_Code : %s\n",Proj_Code);fflush(stdout);
			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n DML_no : %s\n",DML_no);fflush(stdout);
			printf("\n RlsType : %s\n",RlsType);fflush(stdout);
			printf("\n num is : %d\n",num);fflush(stdout);
			printf("\n Item created first time only with item_id \n");fflush(stdout);
			if (DMLTag != NULLTAG)
			 {
					PartCnt=0;
					getPlantDetailsAttr_Std(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency,RevisionRule,ClosureRule,BVR,APLDmlPlnt,STDDmlPlnt);//TZ1.41
					printf("\n PlantCS %s \n",PlantCS);
					printf("\n PlantOptCS %s \n",PlantOptCS);
					printf("\n PlantAgency %s \n",PlantIA);
					printf("\n PlantStore %s \n",PlantStore);
					printf("\n UserAgency %s \n",UserAgency);

					CALLAPI(AOM_ask_value_tags(DMLTag,"CMHasSolutionItem",&PartCnt,&PartTags));
					printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];

							PartFlag = 0;
							st_count1 = 0;
			            	ITKCALL(WSOM_ask_release_status_list(AssyTag,&st_count1,&status_list1_assy));
							printf("\n #######st_count1 :%d is\n",st_count1);fflush(stdout);

							if(st_count1>0)
							{
								for (cnt=0;cnt< st_count1;cnt++ )
								{
									WSO_Name=NULL;
									
									ITKCALL(AOM_ask_name(status_list1_assy[cnt],&WSO_Name));
									printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
									if(tc_strcmp(WSO_Name,"")!=0)
										{
											//if (tc_strcmp(WSO_Name,"T5_LcsSTDWrkg")==0)
											if (tc_strcmp(WSO_Name,LcsStdWrkg)==0)
											{
												PartFlag = 1;
											}
										}
								}
							}
							printf("\n #######PartFlag :%d is\n",PartFlag);fflush(stdout);
							if(PartFlag == 0)
							{
								CALLAPI(CR_create_release_status(lcsToset,&status2));
								CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
								printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
								CALLAPI(EPM_add_release_status(status2,1,&AssyTag,retain));
							}
						}
					}


					tag_t                            TaskClosureDtAttrId=NULLTAG; 
					date_t                           Task_Release_date =NULLDATE;

					CALLAPI(AOM_lock(DMLTag));
					CALLAPI(POM_attr_id_of_attr("date_released","T5_APLTaskRevision",&TaskClosureDtAttrId));
					CALLAPI(AOM_refresh(DMLTag,TRUE));
					CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
					CALLAPI(POM_set_attr_date(1,&DMLTag,TaskClosureDtAttrId,Task_Release_date));
					CALLAPI(AOM_save(DMLTag));
					CALLAPI(AOM_unlock(DMLTag));

				}


				


	}if(strcmp(type_name,"T5_APLTaskRevision")==0 || strcmp(CurrentTask,"Review the Changes")==0)
	{
   /********************** Gss 2.49 For Generating 35-36 Parts at reviewer Claim of APL Reviewer *****************/
   /********************** This need to  be implemented if required now it is moved to ERC *****************/
	}
	else
	   {
	     	printf("\n No proper class class T5_APLDMLRevision......\n");fflush(stdout);
	   }

	return error_code;
}

int AssignSTDAnalyst(tag_t APLTaskRevT)
{
	char*			Task_no				= NULL;
	char*			Dsgn_Grp			= NULL;
	char*			Proj_Code			= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	char*			APL_Task_Grp		= NULL;
	char*			PLT_CodeS		= NULL;
	char*			PLT_CodeSuffix		= NULL;
	char			type_namee_task[TCTYPE_name_size_c+1];
	char*			TaskAssignee		= NULL;
	//char*			rolename			= NULL;
	//char*			userid				= NULL;
	char			rolename[SA_name_size_c+1];
	char				userid[SA_user_size_c+1];
	int   ifail				= 0;


	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			*ParticipantRel			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			ParticipantRelTag		= NULLTAG;
	tag_t			ObjTypTask			= NULLTAG;


	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	int				count		= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int				stdCnt				= 0;
	int				analystFnd			= 0;
	int				extUsrCnt			= 0; //DEEPTI TZ1.44
	int				oldusrcount			= 0; //DEEPTI TZ1.44
	tag_t			*OldParticipantRel			= NULLTAG;//DEEPTI TZ1.44
	tag_t			OldParticipantRelTag		= NULLTAG;//DEEPTI TZ1.44
	tag_t			OldObjTypTask			= NULLTAG;//DEEPTI TZ1.44
	char			Oldtype_namee_task[TCTYPE_name_size_c+1];//DEEPTI TZ1.44


	//logical			flgRoleFnd			= false;

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	
	// Added by Dhanashri for Projectwise Mapping
				char  Projj[40];
				int Gmcnt1=0;
				int ProjectAccessFound=0;
				int FlaggAssignSTDAnalyst=0;
				int countt=0;
				int b=0;
				int z=0;
				tag_t	*GmFound1 = NULLTAG;
				char *Object_Name  =  NULL;

		tag_t			role_tag		= NULLTAG;
	// Added by Dhanashri for Projectwise Mapping

	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *PltCodeFrmCntrl 	  = NULL;
	 char *PltCodeSufx 	  = NULL;


	printf("\n Inside AssignSTDAnalyst \n");

	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_crdesigngroup",&Dsgn_Grp));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_cprojectcode",&Proj_Code));
	printf("\n\n\t\t APL DML Cre:AssignSTDAnalyst:Task_no  is :%s",Task_no);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignSTDAnalyst:Dsgn_Grp  is :%s",Dsgn_Grp);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignSTDAnalyst:Proj_Code  is :%s",Proj_Code);	fflush(stdout);

	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);fflush(stdout);

	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));
	PLT_CodeSuffix=(char *) MEM_alloc(100 * sizeof(char *));
	PltCodeSufx=subString(PLT_Code,3,1);
	printf("\n PltCodeSufx:%s",PltCodeSufx);fflush(stdout);

		//****************************TZ1.46****************************************//

	if(QRY_find("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="APLPltInf";
		qry_valuesCntrl1[1]=PLT_Code;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	else
	{
		printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
	}	
	
	printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

	if(control_number_found1>0)
	{			
		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &PltCodeFrmCntrl);
		printf("\n PltCodeFrmCntrl: %s\n",PltCodeFrmCntrl);fflush(stdout);
		//AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo10", &PltCodeSufx);
		//printf("\n PltCodeSufx: %s\n",PltCodeSufx);fflush(stdout);
		tc_strcpy(PLT_CodeS,PltCodeFrmCntrl);	
		tc_strcpy(PLT_CodeSuffix,PltCodeSufx);
	}
	else
		{
		tc_strcpy(PLT_CodeS,"PUNE");
		tc_strcpy(PLT_CodeSuffix,"P");
		}
		printf("\n PLT_CodeS: %s\n",PLT_CodeS);fflush(stdout);
		printf("\n PLT_CodeSuffix: %s\n",PLT_CodeSuffix);fflush(stdout);
		//****************************************************************//

//	if(tc_strcmp(PLT_Code,"APLP")==0)
//    {
//	tc_strcpy(PLT_CodeS,"PUNE");
//	tc_strcpy(PLT_CodeSuffix,"P");
//	}else
//	if(tc_strcmp(PLT_Code,"APLD")==0)
//	{
//	tc_strcpy(PLT_CodeS,"DWD");
//	tc_strcpy(PLT_CodeSuffix,"D");
//	}else
//	if(tc_strcmp(PLT_Code,"APLC")==0)
//	{
//	tc_strcpy(PLT_CodeS,"CAR");
//	tc_strcpy(PLT_CodeSuffix,"C");
//	}else
//	if(tc_strcmp(PLT_Code,"APLJ")==0)
//	{
//	tc_strcpy(PLT_CodeS,"JSR");
//	tc_strcpy(PLT_CodeSuffix,"J");
//	}else
//	if(tc_strcmp(PLT_Code,"APLL")==0)
//	{
//	tc_strcpy(PLT_CodeS,"LKO");
//	tc_strcpy(PLT_CodeSuffix,"L");
//	}else
//	if(tc_strcmp(PLT_Code,"APLA")==0)
//	{
//	tc_strcpy(PLT_CodeS,"AHD");
//	tc_strcpy(PLT_CodeSuffix,"A");
//	}else
//	if(tc_strcmp(PLT_Code,"APLU")==0)
//	{
//	tc_strcpy(PLT_CodeS,"UTK");
//	tc_strcpy(PLT_CodeSuffix,"U");
//	}else
//	if(tc_strcmp(PLT_Code,"APLS")==0)
//	{
//	tc_strcpy(PLT_CodeS,"JDL");
//	tc_strcpy(PLT_CodeSuffix,"S");
//	}else
//	{
//	tc_strcpy(PLT_CodeS,"PUNE");
//	tc_strcpy(PLT_CodeSuffix,"P");
//	}

// Added By Dhanashri for projectwise mapping// 

					APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
					tc_strcpy(APL_Plnr_Grp,"STD");
					tc_strcat(APL_Plnr_Grp,PLT_CodeS);

				
				tc_strcpy(Projj,Proj_Code);
				printf("\n Projj :[%s]\n",Projj);fflush(stdout);

// End Of code Added By Dhanashri for projectwise mapping// 

	printf("\n Test0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);fflush(stdout);

	CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&oldusrcount,&OldParticipantRel));//DEEPTI TZ1.44
	printf("\n oldusrcount to delete  :%d\n",oldusrcount);fflush(stdout);
	for(extUsrCnt=0;extUsrCnt<oldusrcount;extUsrCnt++)
	{
		printf("\n Removing old user :%d\n",extUsrCnt);fflush(stdout);
		OldParticipantRelTag = OldParticipantRel[extUsrCnt];
						
		printf("\n 11 Inside remving the relation...");fflush(stdout);

		if(TCTYPE_ask_object_type(OldParticipantRelTag,&OldObjTypTask));
		if(TCTYPE_ask_name(OldObjTypTask,Oldtype_namee_task));
		printf("\n 11Task: Participants Name: %s", Oldtype_namee_task);fflush(stdout);

		if ((tc_strcmp(Oldtype_namee_task,"Analyst")==0))
		{
			printf("\n Removing the user..");fflush(stdout);

			AOM_lock(APLTaskRevT);
			ITKCALL(ITEM_rev_remove_participant (APLTaskRevT,OldParticipantRelTag)!=ITK_ok);
			AOM_save(APLTaskRevT);
			AOM_unlock(APLTaskRevT);
		}
		
	}


	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));
	 if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\nNo of Role found in Group are :%d\n",num_of_roles);fflush(stdout);


	if(num_of_roles>0)
	{
		FlaggAssignSTDAnalyst=0; // by dss for projectwise mapping.

		for (i=0;i<num_of_roles ;i++ )
		{
				CALLAPI(SA_ask_role_name(role_tags[i],rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
				//printf("\n Dsgn_Grp [%s]\n",Dsgn_Grp);
				printf("\n Dsgn_No [%s]\n",Dsgn_No);fflush(stdout);

				//if(strstr(rolename,"APL") && strstr(rolename,Dsgn_Grp) && strstr(rolename,"Planner"))
				if(strstr(rolename,"STD") && strstr(rolename,Dsgn_No) && strstr(rolename,"Analyst") && strstr(rolename,"Default")==NULL ) 
				{
							printf("\nMatch Found\n");fflush(stdout);
							role_tag = role_tags[i];
							CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
							printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
							if(num_of_members>0)
							{
								for (j=0;j<num_of_members ;j++  )
								{
									CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
									CALLAPI(SA_ask_user_identifier(user_tag,userid));
									printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
								
									// Added by Dhanashri for projectwise mapping//
									ProjectAccessFound=0;
									Gmcnt1=0;
									GmFound1 = NULLTAG;
									GetProjectUserAccessDetails(Projj,userid,&Gmcnt1,&GmFound1);
									printf("\n Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
									
									countt=0;
									for(countt==0;countt<Gmcnt1;countt++)
									{
											Object_Name  =  NULL;
											CALLAPI(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
											printf("\n after func :  %s",Object_Name);fflush(stdout);
										
											if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,Dsgn_No) && strstr(Object_Name,"Analyst") && strstr(Object_Name,"Default")==NULL) 
											{
												printf("\n Condition Satisfy... ");fflush(stdout);
												ProjectAccessFound=1;
												break;
											}
									}
									printf("\n ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
									// Added by Dhanashri for projectwise mapping//
									
									if(ProjectAccessFound==1)
									{
										TCTYPE_find_type("Analyst", "Analyst", &participant_type);
										EPM_create_participant(member_tags[j], participant_type, &participant_tag);
										GRM_find_relation_type("HasParticipant", &relation_type);
										GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
										GRM_save_relation(relation);
										printf("\n APL Planner Assigned..to : [%s]\n",userid);fflush(stdout);
										FlaggAssignSTDAnalyst=1;
										//break;
									}
								}
							}
					if(FlaggAssignSTDAnalyst==1)
					{
						break;
					}
				}// Role matches  
		}

		printf("\n FlaggAssignSTDAnalyst: %d \n",FlaggAssignSTDAnalyst);fflush(stdout);

		if(FlaggAssignSTDAnalyst==0)
		{
			APL_Plnr_Grp = NULL;
			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"STD");
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,PLT_CodeS);
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,"Default");
			printf("\n Test Planner Group Name:[%s]\n",APL_Plnr_Grp);
			z=0;
			for (z=0;z<num_of_roles ;z++ )
			{
				CALLAPI(SA_ask_role_name(role_tags[z],rolename));
				printf("\nRol Name :[%d][%s]\n",z,rolename);
				if(strstr(rolename,APL_Plnr_Grp))
				{
					printf("\n Got Default Group");
					CALLAPI(SA_find_groupmember_by_role(role_tags[z],group_tag,&num_of_members,&member_tags));
					printf("\n No of Group Members found in Group/Role are :%d\n",num_of_members);
					if(num_of_members>0)
					{
						b=0;
						for (b=0;b<num_of_members ;b++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[b],&user_tag));
							CALLAPI(SA_ask_user_identifier(user_tag,userid));
							printf("\nUser ID Name :[%s]\n",userid);
							TCTYPE_find_type("Analyst", "Analyst", &participant_type);
							EPM_create_participant(member_tags[b], participant_type, &participant_tag);
							GRM_find_relation_type("HasParticipant", &relation_type);
							GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							GRM_save_relation(relation);
							printf("\n APL Planner Assigned..to : [%s]\n",userid);fflush(stdout);
							
						}
					}

				}


			}

		}        
	

	} // if(num_of_roles>0)




	//flgRoleFnd=false;
//	if(num_of_roles>0)
//	{
//		
//		for (i=0;i<num_of_roles ;i++ )
//		{
//				CALLAPI(SA_ask_role_name(role_tags[i],rolename));
//				printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
//				if(strstr(rolename,"STD"))
//				{
//					APL_Task_Grp=(char *) MEM_alloc(100 * sizeof(char *));
//					tc_strcpy(APL_Task_Grp,Dsgn_No);
//					tc_strcat(APL_Task_Grp,"_STD");
//					tc_strcat(APL_Task_Grp,PLT_CodeSuffix);
//					tc_strcat(APL_Task_Grp,"_Analyst");
//					printf("\n Rol APL_Task_Grp :[%d][%s]\n",i,APL_Task_Grp);fflush(stdout);
//					if(strstr(rolename,APL_Task_Grp))
//					{
//						printf("\nMatch Found\n");fflush(stdout);
//						flgRoleFnd=true;
//						break;
//					}
//				}
//		}
//
//		if (flgRoleFnd==true)
//		{
//			
//			
//			CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
//			printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
//			if(num_of_members>0)
//			{
//				for (j=0;j<num_of_members ;j++  )
//				{
//					CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
//					CALLAPI(SA_ask_user_identifier(user_tag,userid));
//					printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
//					//TCTYPE_find_type("Analyst", "Analyst", &participant_type);
//					//EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//					GRM_find_relation_type("HasParticipant", &relation_type);
// 				    CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&count,&ParticipantRel)); 
//					printf("\n count :[%d]\n",count);fflush(stdout);
//					if(count == 0) //TZ1.42 compilation by Deepti
//					{
//						analystFnd++;
//						printf("\n Inside relation creation...");fflush(stdout);
//						TCTYPE_find_type("Analyst", "Analyst", &participant_type);
//						EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//						CALLAPI(GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation));
//						CALLAPI(GRM_save_relation(relation));
//						printf("\n TestParticipent Assigned..DoneXXXX\n");fflush(stdout);
//					}
//					else
//					{
//						for(stdCnt=0;stdCnt<count;stdCnt++)
//						{
//							printf("\n Inside remving the relation...");fflush(stdout);
//							ParticipantRelTag = ParticipantRel[stdCnt];
//							
//							printf("\n 11 Inside remving the relation...");fflush(stdout);
//
//							if(TCTYPE_ask_object_type(ParticipantRelTag,&ObjTypTask));
//							if(TCTYPE_ask_name(ObjTypTask,type_namee_task));
//							printf("\n Task: Participants Name: %s", type_namee_task);fflush(stdout);
//
//							if ((tc_strcmp(type_namee_task,"Analyst")==0))
//							{
//								analystFnd++;
//								ITKCALL(AOM_UIF_ask_value(ParticipantRelTag,"fnd0AssigneeUser",&TaskAssignee)!=ITK_ok);
//								printf("\n Removing: TaskAssignee: [%s] ",TaskAssignee);fflush(stdout);
//								/*AOM_lock(APLTaskRevT);
//								ITKCALL(ITEM_rev_remove_participant (APLTaskRevT,ParticipantRelTag)!=ITK_ok);
//								AOM_save(APLTaskRevT);
//								AOM_unlock(APLTaskRevT);*/
//
//								TCTYPE_find_type("Analyst", "Analyst", &participant_type);
//								EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//								CALLAPI(GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation));
//								CALLAPI(GRM_save_relation(relation));
//								printf("\n 111 TestParticipent Assigned..DoneXXXX\n");fflush(stdout);
//								//break;
//							
//							}
//							
//						}
//						if(analystFnd==0)
//						{
//							analystFnd++;
//							printf("\n Inside analystFnd relation creation...");fflush(stdout);
//							TCTYPE_find_type("Analyst", "Analyst", &participant_type);
//							EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//							CALLAPI(GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation));
//							CALLAPI(GRM_save_relation(relation));
//							printf("\n TestParticipent Assigned..DoneXXXX\n");fflush(stdout);
//						
//						}
//					}
//				}
//				
//			}
//		}
//	
//
//	if(analystFnd==0)
//	{
//			APL_Plnr_Grp = NULL;
//			//group_tag = NULLTAG;
//			//num_of_roles = 0;
//			i=0;
//			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
//			tc_strcpy(APL_Plnr_Grp,"STD");
//			tc_strcat(APL_Plnr_Grp,"_");
//			tc_strcat(APL_Plnr_Grp,PLT_CodeS);
//			tc_strcat(APL_Plnr_Grp,"_");
//			tc_strcat(APL_Plnr_Grp,"Default");
//			printf("\n222 Test0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);fflush(stdout);
//
//			//CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));
//
//			// if (group_tag != NULLTAG)
//			//CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
//			//printf("\n222 No of Role found in Group are :%d\n",num_of_roles);fflush(stdout);
//			flgRoleFnd=false;
//			if(num_of_roles>0)
//			{
//				for (i=0;i<num_of_roles ;i++ )
//				{
//						CALLAPI(SA_ask_role_name(role_tags[i],rolename));
//						printf("\n 222 Rol Name :[%d][%s]\n",i,rolename);fflush(stdout);
//						if(strstr(rolename,APL_Plnr_Grp))
//						{
//							printf("\n 22 Match Found\n");fflush(stdout);
//							flgRoleFnd=true;
//							break;
//						}
//				}
//
//				if (flgRoleFnd==true)
//				{
//					CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
//					printf("\n 222 No of Group Members found in Group/Role are :%d,%d\n",num_of_roles,num_of_members);fflush(stdout);
//					if(num_of_members>0)
//					{
//						for (j=0;j<num_of_members ;j++  )
//						{
//							CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
//							CALLAPI(SA_ask_user_identifier(user_tag,userid));
//							printf("\n 222 User ID Name :[%s]\n",userid);fflush(stdout);
//							TCTYPE_find_type("Analyst", "Analyst", &participant_type);
//							EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//							GRM_find_relation_type("HasParticipant", &relation_type);
//							CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&count,&ParticipantRel));
//							printf("\n 222 count :[%d]\n",count);fflush(stdout);
//							if(count == 0) //TZ1.42 compilation by Deepti
//							{
//								GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
//								GRM_save_relation(relation);
//								printf("\n 222 TestParticipent Assigned..DoneXXXX\n");fflush(stdout);
//							}
//							else
//							{
//								for(stdCnt=0;stdCnt<count;stdCnt++)
//								{
//									printf("\n 333 Inside remving the relation...");fflush(stdout);
//									ParticipantRelTag = ParticipantRel[stdCnt];
//									
//									printf("\n 333  Inside remving the relation...");fflush(stdout);
//
//									if(TCTYPE_ask_object_type(ParticipantRelTag,&ObjTypTask));
//									if(TCTYPE_ask_name(ObjTypTask,type_namee_task));
//									printf("\n 333 Task: Participants Name: %s", type_namee_task);fflush(stdout);
//
//									if ((tc_strcmp(type_namee_task,"Analyst")==0))
//									{
//										analystFnd++;
//										ITKCALL(AOM_UIF_ask_value(ParticipantRelTag,"fnd0AssigneeUser",&TaskAssignee)!=ITK_ok);
//										printf("\n 333 Removing: TaskAssignee: [%s] ",TaskAssignee);fflush(stdout);
//										/*AOM_lock(APLTaskRevT);
//										ITKCALL(ITEM_rev_remove_participant (APLTaskRevT,ParticipantRelTag)!=ITK_ok);
//										AOM_save(APLTaskRevT);
//										AOM_unlock(APLTaskRevT);*/
//
//										TCTYPE_find_type("Analyst", "Analyst", &participant_type);
//										EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//										CALLAPI(GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation));
//										CALLAPI(GRM_save_relation(relation));
//										printf("\n 333 TestParticipent Assigned..DoneXXXX\n");fflush(stdout);
//										break;
//									
//									}
//									
//								}
//
//								if(analystFnd==0)
//								{
//									printf("\n Inside analystFnd relation creation...");fflush(stdout);
//									TCTYPE_find_type("Analyst", "Analyst", &participant_type);
//									EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//									CALLAPI(GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation));
//									CALLAPI(GRM_save_relation(relation));
//									printf("\n TestParticipent Assigned..DoneXXXX\n");fflush(stdout);
//								
//								}
//							}
//						}
//					}
//				}
//	        }
//		}
//	}
	return ITK_ok;
}


int AssignSTDAnalystPR(tag_t APLTaskRevT)
{
	char*			Task_no				= NULL;
	char*			Dsgn_Grp			= NULL;
	char*			Proj_Code			= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	char*			PLT_CodeS		= NULL;
	//char*			rolename			= NULL;
	//char*			userid				= NULL;
	char*			member_name				= NULL;
	char*			PRTaskCreator				= NULL;
	char*			type_namee				= NULL;

	char			rolename[SA_name_size_c+1];
	char				userid[SA_user_size_c+1];
	int   ifail				= 0;


	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			*ParticipantRel			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	int				count		= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int				FlaggAssignAnalystPR					= 0;

	logical			flgRoleFnd			= false;
	tag_t	participant_type2	= NULLTAG;
	tag_t	participant_tag2	= NULLTAG;
	printf("\n Inside AssignSTDAnalystPR \n");

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *PltCodeFrmCntrl 	  = NULL;


/*tag_t	CR_rel_type			= NULLTAG;
tag_t* RelCRTags = NULLTAG;
int Relcount=0;
int jk=0;
tag_t	CR_Asgn_Part		= NULLTAG;
tag_t	ObjTypCR			= NULLTAG;
char *CRAssignee 	   = NULL;

	ITKCALL(GRM_find_relation_type("HasParticipant", &CR_rel_type)!=ITK_ok);
			if (CR_rel_type!=NULLTAG)
			{
				printf("\n MT:REMOVE PARTICIPALNTS START.. \n");fflush(stdout);
				ITKCALL(GRM_list_secondary_objects_only(APLTaskRevT,CR_rel_type,&Relcount,&RelCRTags)!=ITK_ok);
				printf("\n MT: RelCRTags count: %d",Relcount);fflush(stdout);	
				for (jk=0;jk<Relcount ;jk++ )
				{						
					CR_Asgn_Part = RelCRTags[jk];
					if(TCTYPE_ask_object_type(CR_Asgn_Part,&ObjTypCR));
					if(TCTYPE_ask_name(ObjTypCR,type_namee));
					printf("\n CR: Participants Name: %s", type_namee);fflush(stdout);					
					if ((tc_strcmp(type_namee,"Analyst")==0))
					{
						ITKCALL(AOM_UIF_ask_value(CR_Asgn_Part,"fnd0AssigneeUser",&CRAssignee)!=ITK_ok);
						printf("\n Removing: CRAssignee: [%s] ",CRAssignee);fflush(stdout);
						AOM_lock(APLTaskRevT);
						ITKCALL(ITEM_rev_remove_participant (APLTaskRevT,CR_Asgn_Part)!=ITK_ok);
						AOM_save(APLTaskRevT);
						AOM_unlock(APLTaskRevT);
					}
					
				}
			}
			*/

	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_crdesigngroup",&Dsgn_Grp));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_cprojectcode",&Proj_Code));
	printf("\n\n\t\t APL DML Cre:AssignSTDAnalystPR:Task_no  is :%s",Task_no);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignSTDAnalystPR:Dsgn_Grp  is :%s",Dsgn_Grp);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignSTDAnalystPR:Proj_Code  is :%s",Proj_Code);	fflush(stdout);

	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);

	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));

	//****************************TZ1.46****************************************//

			if(QRY_find("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLPltInf";
				qry_valuesCntrl1[1]=PLT_Code;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{			
				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &PltCodeFrmCntrl);
				printf("\n PltCodeFrmCntrl: %s\n",PltCodeFrmCntrl);fflush(stdout);
				tc_strcpy(PLT_CodeS,PltCodeFrmCntrl);					
			}
			else
				{
				tc_strcpy(PLT_CodeS,"PUNE");
				}
				printf("\n PLT_CodeS: %s\n",PLT_CodeS);fflush(stdout);
				//****************************************************************//

//	if(tc_strcmp(PLT_Code,"APLP")==0)
//    {
//	tc_strcpy(PLT_CodeS,"PUNE");
//	}else
//	if(tc_strcmp(PLT_Code,"APLD")==0)
//	{
//	tc_strcpy(PLT_CodeS,"DWD");
//	}else
//	if(tc_strcmp(PLT_Code,"APLC")==0)
//	{
//	tc_strcpy(PLT_CodeS,"CAR");
//	}else
//	if(tc_strcmp(PLT_Code,"APLJ")==0)
//	{
//	tc_strcpy(PLT_CodeS,"JSR");
//	}else
//	if(tc_strcmp(PLT_Code,"APLL")==0)
//	{
//	tc_strcpy(PLT_CodeS,"LKO");
//	}else
//	if(tc_strcmp(PLT_Code,"APLA")==0)
//	{
//	tc_strcpy(PLT_CodeS,"AHD");
//	}else
//	if(tc_strcmp(PLT_Code,"APLU")==0)
//	{
//	tc_strcpy(PLT_CodeS,"UTK");
//	}else
//	if(tc_strcmp(PLT_Code,"APLS")==0)
//	{
//	tc_strcpy(PLT_CodeS,"JDL");
//	}else
//	{
//	tc_strcpy(PLT_CodeS,"PUNE");
//	}


	APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(APL_Plnr_Grp,"STD");
	tc_strcat(APL_Plnr_Grp,PLT_CodeS);


	//APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	//tc_strcpy(APL_Plnr_Grp,"STD");
	//tc_strcat(APL_Plnr_Grp,PLT_CodeS);
	printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);

	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));
	 if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\nNo of Role found in Group are :%d\n",num_of_roles);

	ITKCALL(AOM_UIF_ask_value(APLTaskRevT,"owning_user",&PRTaskCreator));
	printf("\n\n\t\t PRTaskCreator  is :%s",PRTaskCreator);fflush(stdout);


	flgRoleFnd=false;
	if(num_of_roles>0)
	{
		for (i=0;i<num_of_roles ;i++ )
		{
				CALLAPI(SA_ask_role_name(role_tags[i],rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);
				//if(strstr(rolename,"STD") && !strstr(rolename,"STD"))
				if( (tc_strstr(rolename,"STD")!=NULL) && (tc_strstr(rolename,"Analyst")!=NULL) && (tc_strstr(rolename,"Default")==NULL) )
				{
					printf("\nMatch Found\n");
				
						CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
						printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);
						if(num_of_members>0)
						{
							for (j=0;j<num_of_members ;j++  )
							{
								ITKCALL(AOM_ask_value_string(member_tags[j],"user_name",&member_name)!=ITK_ok);
								printf("\n member_name :[%s]\n",member_name);

								CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
								CALLAPI(SA_ask_user_identifier(user_tag,userid));
								printf("\nUser ID Name :[%s]\n",userid);
								printf("\n PRTaskCreator :[%s]\n",PRTaskCreator);
						
								if(tc_strstr(PRTaskCreator,member_name)!=NULL)
								{
									/*
									printf("\n Got same user ....\n");
									ITKCALL(EPM_get_participanttype ("Analyst",&participant_type2)!=ITK_ok);
									ITKCALL(EPM_create_participant(member_tags[j],participant_type2,&participant_tag2)!=ITK_ok);
									AOM_lock(APLTaskRevT);			
									ITKCALL(ITEM_rev_add_participant(APLTaskRevT,participant_tag2)!=ITK_ok);
									AOM_save(APLTaskRevT);
									AOM_unlock(APLTaskRevT);
									printf("\n AnalystPR Assigned..DoneXXXX\n");
									*/
									
									TCTYPE_find_type("Analyst", "Analyst", &participant_type);
									EPM_create_participant(member_tags[j], participant_type, &participant_tag);
									GRM_find_relation_type("HasParticipant", &relation_type);
									CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&count,&ParticipantRel));
									GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
									GRM_save_relation(relation);
									FlaggAssignAnalystPR=1;
									printf("\n TestParticipent Analyst PR Assigned..DoneXXXX\n");
									break;
								}
							}
						}
						
						if(FlaggAssignAnalystPR==1)
						{
							printf("\n FlaggAssignAnalystPR: 1 \n");
							break;
						}
			}
		}

		if(FlaggAssignAnalystPR==0)
		{
			printf("\n FlaggAssignAnalystPR: 0 \n");

			APL_Plnr_Grp = NULL;
			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"STD");
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,PLT_CodeS);
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,"Default");
			printf("\n Test Planner Group Name:[%s]\n",APL_Plnr_Grp);
			printf("\n Test Planner Group Name:[%s]\n",APL_Plnr_Grp);
			i=0;
			for (i=0;i<num_of_roles ;i++ )
			{
				CALLAPI(SA_ask_role_name(role_tags[i],rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);
				if(strstr(rolename,APL_Plnr_Grp))
				{
					printf("\n Got Default Group");
					CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
					printf("\n No of Group Members found in Group/Role are :%d\n",num_of_members);
					if(num_of_members>0)
					{
						for (j=0;j<num_of_members ;j++  )
						{
							/*
							ITKCALL(EPM_get_participanttype ("Analyst",&participant_type2)!=ITK_ok);
							ITKCALL(EPM_create_participant(member_tags[j],participant_type2,&participant_tag2)!=ITK_ok);
							AOM_lock(APLTaskRevT);			
							ITKCALL(ITEM_rev_add_participant(APLTaskRevT,participant_tag2)!=ITK_ok);
							AOM_save(APLTaskRevT);
							AOM_unlock(APLTaskRevT);
							printf("\n AnalystPR Assigned..DoneXXXX\n");
							*/
							
							CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
							CALLAPI(SA_ask_user_identifier(user_tag,userid));
							printf("\nUser ID Name :[%s]\n",userid);
							TCTYPE_find_type("Analyst", "Analyst", &participant_type);
							EPM_create_participant(member_tags[j], participant_type, &participant_tag);
							GRM_find_relation_type("HasParticipant", &relation_type);
							CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&count,&ParticipantRel));
							printf("\n count :[%d]\n",count);
							//if(count == 0)
							//{
							GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							GRM_save_relation(relation);
							printf("\n TestParticipent Assigned..DoneXXXX\n");
							//}
							//else
							//{
							//printf("\n Already Assigned..DoneXXXX\n");
							//}
							
						}
					}

				}


			}

		}
	}
	return ITK_ok;
}



int AssignSTDReviewerPR(tag_t APLTaskRevT)
{
	char*			Task_no				= NULL;
	char*			Task_no1				= NULL;
	char*			Dsgn_Grp			= NULL;
	char*			Proj_Code			= NULL;
	char*			dmlnum			= NULL;
	char*			DMLNo				= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	char*			PLT_CodeS		= NULL;
	char*			APLDML		= NULL;
	//char*			rolename			= NULL;
	//char*			userid				= NULL;
	char*			member_name				= NULL;
	char*			PRTaskCreator				= NULL;
	char*	 tsk_name		= NULL;
	char		   *PltNm =NULL;
	char		   *Tasknumber =NULL;
	char			rolename[SA_name_size_c+1];
	char				userid[SA_user_size_c+1];
	int   ifail				= 0;
	char TaskCpy[25];

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			*ParticipantRel			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t APLTask= NULLTAG;
	tag_t  	item_rev_cld_tag;

	int				count		= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int				FlaggAssignReviewerPR					= 0;

int n_tags_found=0;
	tag_t	*tags_found							= NULLTAG;
tag_t tsk_dml_rel_type;
tag_t *DMLRevision = NULLTAG;
int count1=0;
int Task=0;
int FlagOtherTsk=0;

	logical			flgRoleFnd			= false;

	// Added by Dhanashri for Projectwise Mapping
				
				char  Projj[40];
				int Gmcnt1=0;
				int ProjectAccessFound=0;
				int FlaggAssignSTDReviewer=0;
				int countt=0;
				int b=0;
				int z=0;
				tag_t	*GmFound1 = NULLTAG;
				char *Object_Name  =  NULL;

			tag_t			role_tag		= NULLTAG;
	// Added by Dhanashri for Projectwise Mapping

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *PltCodeFrmCntrl 	  = NULL;

	printf("\n Inside AssignSTDReviewerPR \n");

	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	printf("\n\n\t\t APL DML Cre:AssignSTDReviewerPR:Task_no  is :%s",Task_no);	fflush(stdout);

	DMLNo=tc_strtok(Task_no,"_");
	printf("\nTest0.11..DMLNo:[%s],[%s]\n",DMLNo,Task_no);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);

	APLDML=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(APLDML,DMLNo);
	tc_strcat(APLDML,"_");
	tc_strcat(APLDML,PLT_Code);
	printf("\n APLDML: [%s]\n",APLDML);


	const char *qry_entries[1];
	const char *qry_values[1];

	qry_entries[0] ="item_id";
	qry_values[0] = APLDML;


	ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &tags_found);
	printf("\n\n\t\t tags_found : %d\n",n_tags_found);fflush(stdout);

	itemcldclass = tags_found[0];
	ITKCALL(ITEM_ask_latest_rev(itemcldclass,&item_rev_cld_tag));

	CALLAPI(AOM_ask_value_string(item_rev_cld_tag,"t5_cprojectcode",&Proj_Code));
	printf("\n\n\t\t APL DML Cre:AssignAPLReviewer:Proj_Code  is :%s",Proj_Code);	fflush(stdout);

	CALLAPI(AOM_ask_value_string(item_rev_cld_tag,"item_id",&dmlnum));
	printf("\n\n\t\t APL DML Cre:AssignAPLReviewer:dmlnum  is :%s",dmlnum);	fflush(stdout);

	
	ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
	if (tsk_dml_rel_type!=NULLTAG)
	 {
		ITKCALL(GRM_list_secondary_objects_only(item_rev_cld_tag,tsk_dml_rel_type,&count1,&DMLRevision));
		printf("\n\n\t\t DML Revision from Task : %d",count1);fflush(stdout);		//task to dml
	 }

	 if(count1>0)
	{
		 for(Task=0;Task<count1;Task++)
		{
			APLTask=DMLRevision[Task];
			ITKCALL(AOM_ask_value_string(APLTask,"item_id",&tsk_name));
			printf("\n\n\t\t tsk_name is :%s\n",tsk_name);fflush(stdout);

			if(tc_strstr(tsk_name,"_PR")==NULL)
			{
				printf(" \n\n\t\t Got Task Other THan PR Task");fflush(stdout);
				FlagOtherTsk=1;
				break;
			}

		}
	}

	printf(" \n\n\t\t FlagOtherTsk: [%d]",FlagOtherTsk);fflush(stdout);

	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));

		//****************************TZ1.46****************************************//

			if(QRY_find("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLPltInf";
				qry_valuesCntrl1[1]=PLT_Code;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{			
				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &PltCodeFrmCntrl);
				printf("\n PltCodeFrmCntrl: %s\n",PltCodeFrmCntrl);fflush(stdout);
				tc_strcpy(PLT_CodeS,PltCodeFrmCntrl);					
			}
			else
				{
				tc_strcpy(PLT_CodeS,"PUNE");
				}
				printf("\n PLT_CodeS: %s\n",PLT_CodeS);fflush(stdout);
				//****************************************************************//

//	if(tc_strcmp(PLT_Code,"APLP")==0)
//    {
//	tc_strcpy(PLT_CodeS,"PUNE");
//	}else
//	if(tc_strcmp(PLT_Code,"APLV")==0)
//	{
//	tc_strcpy(PLT_CodeS,"UV");
//	}else
//	if(tc_strcmp(PLT_Code,"APLD")==0)
//	{
//	tc_strcpy(PLT_CodeS,"DWD");
//	}else
//	if(tc_strcmp(PLT_Code,"APLC")==0)
//	{
//	tc_strcpy(PLT_CodeS,"CAR");
//	}else
//	if(tc_strcmp(PLT_Code,"APLJ")==0)
//	{
//	tc_strcpy(PLT_CodeS,"JSR");
//	}else
//	if(tc_strcmp(PLT_Code,"APLL")==0)
//	{
//	tc_strcpy(PLT_CodeS,"LKO");
//	}else
//	if(tc_strcmp(PLT_Code,"APLA")==0)
//	{
//	tc_strcpy(PLT_CodeS,"AHD");
//	}else
//	if(tc_strcmp(PLT_Code,"APLU")==0)
//	{
//	tc_strcpy(PLT_CodeS,"UTK");
//	}else
//	if(tc_strcmp(PLT_Code,"APLS")==0)
//	{
//	tc_strcpy(PLT_CodeS,"JDL");
//	}else
//	{
//	tc_strcpy(PLT_CodeS,"PUNE");
//	}


// Added By Dhanashri for projectwise mapping// 

			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"STD");
			tc_strcat(APL_Plnr_Grp,PLT_CodeS);

			tc_strcpy(Projj,Proj_Code);
			printf("\n Projj :[%s]\n",Projj);fflush(stdout);

		
// End Of code Added By Dhanashri for projectwise mapping// 

	printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);


	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

	 if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\nNo of Role found in Group are :%d\n",num_of_roles);
	flgRoleFnd=false;
	if(num_of_roles>0)
	{
		FlaggAssignReviewerPR=0;
		for (i=0;i<num_of_roles ;i++ )
		{
				CALLAPI(SA_ask_role_name(role_tags[i],rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);
				
				if(FlagOtherTsk==1)
				{
						CALLAPI(AOM_ask_value_string(APLTask,"item_id",&Task_no1));
						CALLAPI(AOM_ask_value_string(APLTask,"t5_crdesigngroup",&Dsgn_Grp));
						
						printf("\n\n\t\t APL DML Cre:AssignAPLReviewer:Task_no1  is :[%s]",Task_no1);	fflush(stdout);
						printf("\n\n\t\t APL DML Cre:AssignAPLReviewer:Dsgn_Grp  is :[%s]",Dsgn_Grp);	fflush(stdout);
						if( (Dsgn_Grp==NULL) || (tc_strcmp(Dsgn_Grp,"")==0) )
						{				
								printf("\n testt1");	fflush(stdout);
								tc_strcpy(TaskCpy,Task_no1);

								Tasknumber = strtok( TaskCpy, "_" );
								Dsgn_Grp  = strtok ( NULL, "_" );
								PltNm  = strtok ( NULL, "_" );

								printf("\n dss Tasknumber : %s",Tasknumber); fflush(stdout);
								printf("\n dss Dsgn_Grp : %s",Dsgn_Grp); fflush(stdout);
								printf("\n dss PltNm : %s",PltNm); fflush(stdout);
						}

				if( (tc_strstr(rolename,"STD")!=NULL) && (tc_strstr(rolename,"Reviewer")!=NULL) && (tc_strstr(rolename,Dsgn_Grp)!=NULL) && (tc_strstr(rolename,"Default")==NULL) )
				{
					printf("\n hi ..Match Found\n");
				
						CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
						printf("\n hi No of Group Members found in Group/Role are :%d\n",num_of_roles);
						if(num_of_members>0)
						{
							for (j=0;j<num_of_members ;j++  )
							{
								ITKCALL(AOM_ask_value_string(member_tags[j],"user_name",&member_name)!=ITK_ok);
								printf("\n member_name :[%s]\n",member_name);

								CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
								CALLAPI(SA_ask_user_identifier(user_tag,userid));
								printf("\nUser ID Name :[%s]\n",userid);

									// Added by Dhanashri for projectwise mapping//
									ProjectAccessFound=0;
									Gmcnt1=0;
									GmFound1 = NULLTAG;
									GetProjectUserAccessDetails(Projj,userid,&Gmcnt1,&GmFound1);
									printf("\n Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
									
									countt=0;
									for(countt==0;countt<Gmcnt1;countt++)
									{
											Object_Name  =  NULL;
											CALLAPI(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
											printf("\n after func :  %s",Object_Name);fflush(stdout);
										
											if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,Dsgn_No) && strstr(Object_Name,"Reviewer") && strstr(Object_Name,"Default")==NULL) 
											{
												printf("\n Condition Satisfy... ");fflush(stdout);
												ProjectAccessFound=1;
												break;
											}
									}
									printf("\n ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
									// Added by Dhanashri for projectwise mapping//

									if(ProjectAccessFound==1)
									{
										TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
										EPM_create_participant(member_tags[j], participant_type, &participant_tag);
										GRM_find_relation_type("HasParticipant", &relation_type);
										CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&count,&ParticipantRel));
										
										GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
										GRM_save_relation(relation);
										FlaggAssignReviewerPR=1;
										printf("\n TestParticipent PR Reviewer Assigned..DoneXXXX\n");
									}	
							}
						}
						
						if(FlaggAssignReviewerPR==1)
						{
							printf("\n FlaggAssignReviewerPR: 1 \n");
							break;
						}
			}
		  }
		}

		if(FlaggAssignReviewerPR==0)
		{
			printf("\n FlaggAssignReviewerPR: 0 \n");

			APL_Plnr_Grp = NULL;
			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"STD");
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,PLT_CodeS);
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,"Default");
			printf("\n Test Planner Group Name:[%s]\n",APL_Plnr_Grp);
			i=0;
			for (i=0;i<num_of_roles ;i++ )
			{
				CALLAPI(SA_ask_role_name(role_tags[i],rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);
				if(strstr(rolename,APL_Plnr_Grp))
				{
					printf("\n Got Default Group");
					CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
					printf("\n No of Group Members found in Group/Role are :%d\n",num_of_roles);
					if(num_of_members>0)
					{
						for (j=0;j<num_of_members ;j++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
							CALLAPI(SA_ask_user_identifier(user_tag,userid));
							printf("\nUser ID Name :[%s]\n",userid);
							TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
							EPM_create_participant(member_tags[j], participant_type, &participant_tag);
							GRM_find_relation_type("HasParticipant", &relation_type);
							CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&count,&ParticipantRel));
							printf("\n count :[%d]\n",count);
							
							GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							GRM_save_relation(relation);
							printf("\n TestParticipent Assigned..DoneXXXX\n");
							
						}
					}

				}


			}

		}
				

	}




	return ITK_ok;
}

int AssignSTDReviewer(tag_t APLTaskRevT)
{
	char*			Task_no				= NULL;
	char*			Dsgn_Grp			= NULL;
	char*			Proj_Code			= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	char*			APL_Task_Grp		= NULL;
	char*			PLT_CodeS		= NULL;
	char*			PLT_CodeSuffix		= NULL;
	//char*			rolename			= NULL;
	//char*			userid				= NULL;
	char			rolename[SA_name_size_c+1];
	char				userid[SA_user_size_c+1];
	int   ifail				= 0;


	tag_t			*ParticipantRel			= NULLTAG;
	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	int				num_of_roles		= 0;
	int				count		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;

	//logical			flgRoleFnd			= false;

	tag_t			ParticipantRelTag		= NULLTAG;
	tag_t			ObjTypTask			= NULLTAG;
	int				stdCnt				= 0;
	int				ChangeSpeciaFnd		= 0;
	char			type_namee_task[TCTYPE_name_size_c+1];
	char*			TaskAssignee		= NULL;

	int				extUsrCnt			= 0; //DEEPTI TZ1.44
	int				oldusrcount			= 0; //DEEPTI TZ1.44
	tag_t			*OldParticipantRel			= NULLTAG;//DEEPTI TZ1.44
	tag_t			OldParticipantRelTag		= NULLTAG;//DEEPTI TZ1.44
	tag_t			OldObjTypTask			= NULLTAG;//DEEPTI TZ1.44
	char			Oldtype_namee_task[TCTYPE_name_size_c+1];//DEEPTI TZ1.44

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	
	// Added by Dhanashri for Projectwise Mapping
				
				char  Projj[40];
				int Gmcnt1=0;
				int ProjectAccessFound=0;
				int FlaggAssignSTDReviewer=0;
				int countt=0;
				int b=0;
				int z=0;
				tag_t	*GmFound1 = NULLTAG;
				char *Object_Name  =  NULL;

			tag_t			role_tag		= NULLTAG;
	// Added by Dhanashri for Projectwise Mapping

	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *PltCodeFrmCntrl 	  = NULL;
	 char *PltCodeSufx 	  = NULL;


	printf("\n Inside AssignSTDReviewer  \n");

	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_crdesigngroup",&Dsgn_Grp));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_cprojectcode",&Proj_Code));
	printf("\n\n\t\t APL DML Cre:AssignSTDReviewer:Task_no  is :%s",Task_no);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignSTDReviewer:Dsgn_Grp  is :%s",Dsgn_Grp);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignSTDReviewer:Proj_Code  is :%s",Proj_Code);	fflush(stdout);

	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);

	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));
	PLT_CodeSuffix=(char *) MEM_alloc(100 * sizeof(char *));
	PltCodeSufx=subString(PLT_Code,3,1);
	printf("\n PltCodeSufx:%s",PltCodeSufx);fflush(stdout);

			//****************************TZ1.46****************************************//

			if(QRY_find("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLPltInf";
				qry_valuesCntrl1[1]=PLT_Code;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{			
				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &PltCodeFrmCntrl);
				printf("\n PltCodeFrmCntrl: %s\n",PltCodeFrmCntrl);fflush(stdout);
				//AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo10", &PltCodeSufx);
				//printf("\n PltCodeSufx: %s\n",PltCodeSufx);fflush(stdout);
				tc_strcpy(PLT_CodeS,PltCodeFrmCntrl);	
				tc_strcpy(PLT_CodeSuffix,PltCodeSufx);
			}
			else
				{
				tc_strcpy(PLT_CodeS,"PUNE");
				tc_strcpy(PLT_CodeSuffix,"P");
				}
				printf("\n PLT_CodeS: %s\n",PLT_CodeS);fflush(stdout);
				printf("\n PLT_CodeSuffix: %s\n",PLT_CodeSuffix);fflush(stdout);
				//****************************************************************//

//	if(tc_strcmp(PLT_Code,"APLP")==0)
//    {
//	tc_strcpy(PLT_CodeS,"PUNE");
//	tc_strcpy(PLT_CodeSuffix,"P");
//	}else
//	if(tc_strcmp(PLT_Code,"APLD")==0)
//	{
//	tc_strcpy(PLT_CodeS,"DWD");
//	tc_strcpy(PLT_CodeSuffix,"D");
//	}else
//	if(tc_strcmp(PLT_Code,"APLC")==0)
//	{
//	tc_strcpy(PLT_CodeS,"CAR");
//	tc_strcpy(PLT_CodeSuffix,"C");
//	}else
//	if(tc_strcmp(PLT_Code,"APLJ")==0)
//	{
//	tc_strcpy(PLT_CodeS,"JSR");
//	tc_strcpy(PLT_CodeSuffix,"J");
//	}else
//	if(tc_strcmp(PLT_Code,"APLL")==0)
//	{
//	tc_strcpy(PLT_CodeS,"LKO");
//	tc_strcpy(PLT_CodeSuffix,"L");
//	}else
//	if(tc_strcmp(PLT_Code,"APLA")==0)
//	{
//	tc_strcpy(PLT_CodeS,"AHD");
//	tc_strcpy(PLT_CodeSuffix,"A");
//	}else
//	if(tc_strcmp(PLT_Code,"APLU")==0)
//	{
//	tc_strcpy(PLT_CodeS,"UTK");
//	tc_strcpy(PLT_CodeSuffix,"U");
//	}else
//	if(tc_strcmp(PLT_Code,"APLS")==0)
//	{
//	tc_strcpy(PLT_CodeS,"JDL");
//	tc_strcpy(PLT_CodeSuffix,"J");
//	}else
//	{
//	tc_strcpy(PLT_CodeS,"PUNE");
//	tc_strcpy(PLT_CodeSuffix,"P");
//	}


// Added By Dhanashri for projectwise mapping// 

					APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
					tc_strcpy(APL_Plnr_Grp,"STD");
					tc_strcat(APL_Plnr_Grp,PLT_CodeS);

			
			tc_strcpy(Projj,Proj_Code);
			printf("\n Projj :[%s]\n",Projj);fflush(stdout);

// End Of code Added By Dhanashri for projectwise mapping// 

	printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);

	CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&oldusrcount,&OldParticipantRel));//DEEPTI TZ1.44
	printf("\n oldusrcount to delete  :%d\n",oldusrcount);fflush(stdout);
	for(extUsrCnt=0;extUsrCnt<oldusrcount;extUsrCnt++)
	{
		printf("\n For STD Reviewer Removing old user :%d\n",extUsrCnt);fflush(stdout);
		OldParticipantRelTag = OldParticipantRel[extUsrCnt];
						
		printf("\n For STD Reviewer  Inside remving the relation...");fflush(stdout);

		if(TCTYPE_ask_object_type(OldParticipantRelTag,&OldObjTypTask));
		if(TCTYPE_ask_name(OldObjTypTask,Oldtype_namee_task));
		printf("\n For STD Reviewer Task: Participants Name: %s", Oldtype_namee_task);fflush(stdout);

		if ((tc_strcmp(Oldtype_namee_task,"ChangeSpecialist1")==0))
		{
			printf("\n  For STD Reviewer  Removing the user..");fflush(stdout);

			AOM_lock(APLTaskRevT);
			ITKCALL(ITEM_rev_remove_participant (APLTaskRevT,OldParticipantRelTag)!=ITK_ok);
			AOM_save(APLTaskRevT);
			AOM_unlock(APLTaskRevT);
		}
		
	}

	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

	 if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\nNo of Role found in Group are :%d\n",num_of_roles);

	//flgRoleFnd=false;
	if(num_of_roles>0)
	{
		FlaggAssignSTDReviewer=0; // by dss for projectwise mapping.

		for (i=0;i<num_of_roles ;i++ )
		{
				CALLAPI(SA_ask_role_name(role_tags[i],rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
				//printf("\n Dsgn_Grp [%s]\n",Dsgn_Grp);
				printf("\n Dsgn_No [%s]\n",Dsgn_No);fflush(stdout);

				//if(strstr(rolename,"APL") && strstr(rolename,Dsgn_Grp) && strstr(rolename,"Planner"))
				if(strstr(rolename,"STD") && strstr(rolename,Dsgn_No) && strstr(rolename,"Reviewer") && strstr(rolename,"Default")==NULL ) 
				{
							printf("\nMatch Found\n");fflush(stdout);
							role_tag = role_tags[i];
							CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
							printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
							if(num_of_members>0)
							{
								for (j=0;j<num_of_members ;j++  )
								{
									CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
									CALLAPI(SA_ask_user_identifier(user_tag,userid));
									printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
								
									// Added by Dhanashri for projectwise mapping//
									ProjectAccessFound=0;
									Gmcnt1=0;
									GmFound1 = NULLTAG;
									GetProjectUserAccessDetails(Projj,userid,&Gmcnt1,&GmFound1);
									printf("\n Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
									
									countt=0;
									for(countt==0;countt<Gmcnt1;countt++)
									{
											Object_Name  =  NULL;
											CALLAPI(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
											printf("\n after func :  %s",Object_Name);fflush(stdout);
										
											if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,Dsgn_No) && strstr(Object_Name,"Reviewer") && strstr(Object_Name,"Default")==NULL) 
											{
												printf("\n Condition Satisfy... ");fflush(stdout);
												ProjectAccessFound=1;
												break;
											}
									}
									printf("\n ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
									// Added by Dhanashri for projectwise mapping//
									
									if(ProjectAccessFound==1)
									{
										TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
										EPM_create_participant(member_tags[j], participant_type, &participant_tag);
										GRM_find_relation_type("HasParticipant", &relation_type);
										GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
										GRM_save_relation(relation);
										printf("\n APL Planner Assigned..to : [%s]\n",userid);fflush(stdout);
										FlaggAssignSTDReviewer=1;
										//break;
									}
								}
							}

					
					if(FlaggAssignSTDReviewer==1)
					{
						break;
					}
				}// Role matches  
		}

		printf("\n FlaggAssignSTDReviewer: %d \n",FlaggAssignSTDReviewer);fflush(stdout);

		if(FlaggAssignSTDReviewer==0)
		{
			APL_Plnr_Grp = NULL;
			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"STD");
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,PLT_CodeS);
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,"Default");
			printf("\n Test Planner Group Name:[%s]\n",APL_Plnr_Grp);
			z=0;
			for (z=0;z<num_of_roles ;z++ )
			{
				CALLAPI(SA_ask_role_name(role_tags[z],rolename));
				printf("\nRol Name :[%d][%s]\n",z,rolename);
				if(strstr(rolename,APL_Plnr_Grp))
				{
					printf("\n Got Default Group");
					CALLAPI(SA_find_groupmember_by_role(role_tags[z],group_tag,&num_of_members,&member_tags));
					printf("\n No of Group Members found in Group/Role are :%d\n",num_of_members);
					if(num_of_members>0)
					{
						b=0;
						for (b=0;b<num_of_members ;b++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[b],&user_tag));
							CALLAPI(SA_ask_user_identifier(user_tag,userid));
							printf("\nUser ID Name :[%s]\n",userid);
							TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
							EPM_create_participant(member_tags[b], participant_type, &participant_tag);
							GRM_find_relation_type("HasParticipant", &relation_type);
							GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							GRM_save_relation(relation);
							printf("\n APL Planner Assigned..to : [%s]\n",userid);fflush(stdout);
							
						}
					}

				}


			}

		}        
	

	} // if(num_of_roles>0)





	//flgRoleFnd=false;

	
//	if(num_of_roles>0)
//	{
//		for (i=0;i<num_of_roles ;i++ )
//		{
//				CALLAPI(SA_ask_role_name(role_tags[i],rolename));
//				printf("\nRol Name :[%d][%s]\n",i,rolename);
//				if(strstr(rolename,"STD"))
//				{
//					APL_Task_Grp=(char *) MEM_alloc(100 * sizeof(char *));
//					tc_strcpy(APL_Task_Grp,Dsgn_No);
//					tc_strcat(APL_Task_Grp,"_STD");
//					tc_strcat(APL_Task_Grp,PLT_CodeSuffix);
//					tc_strcat(APL_Task_Grp,"_Reviewer");
//					printf("\n Rol APL_Task_Grp :[%d][%s]\n",i,APL_Task_Grp);fflush(stdout);
//
//					if(strstr(rolename,APL_Task_Grp))
//					{
//						printf("\nMatch Found\n");fflush(stdout);
//						flgRoleFnd=true;
//						break;
//					}
//					
//				}
//		}
//
//		if (flgRoleFnd==true)
//		{
//			CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
//			printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_roles);
//			if(num_of_members>0)
//			{
//				for (j=0;j<num_of_members ;j++  )
//				{
//					CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
//					CALLAPI(SA_ask_user_identifier(user_tag,userid));
//					printf("\nUser ID Name :[%s]\n",userid);
//					//TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
//					//EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//					GRM_find_relation_type("HasParticipant", &relation_type);
//					CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&count,&ParticipantRel));
//					printf("\n count :[%d]\n",count);
//					if(count== 0) //TZ1.42 compilation by Deepti
//					{
//						ChangeSpeciaFnd++;
//						TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
//						EPM_create_participant(member_tags[j], participant_type, &participant_tag);					
//						GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
//						GRM_save_relation(relation);
//						printf("\n TestParticipent Assigned..DoneXXXX\n");
//					}
//					else
//					{
//						printf("\n Already Assigned..DoneXXXX\n");
//						for(stdCnt=0;stdCnt<count;stdCnt++)
//						{
//							printf("\n Inside remving the relation for reviewer...");fflush(stdout);
//							ParticipantRelTag = ParticipantRel[stdCnt];
//							
//							printf("\n 11 Inside remving the relation for reviewer ...");fflush(stdout);
//
//							if(TCTYPE_ask_object_type(ParticipantRelTag,&ObjTypTask));
//							if(TCTYPE_ask_name(ObjTypTask,type_namee_task));
//							printf("\n Task: Participants Name for reviewer: %s", type_namee_task);fflush(stdout);
//
//							if ((tc_strcmp(type_namee_task,"ChangeSpecialist1")==0))
//							{
//								ChangeSpeciaFnd++;
//								ITKCALL(AOM_UIF_ask_value(ParticipantRelTag,"fnd0AssigneeUser",&TaskAssignee)!=ITK_ok);
//								printf("\n Removing: TaskAssignee for reviewer: [%s] ",TaskAssignee);fflush(stdout);
//								/*AOM_lock(APLTaskRevT);
//								ITKCALL(ITEM_rev_remove_participant (APLTaskRevT,ParticipantRelTag)!=ITK_ok);
//								AOM_save(APLTaskRevT);
//								AOM_unlock(APLTaskRevT);*/
//
//								TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
//								EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//								CALLAPI(GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation));
//								CALLAPI(GRM_save_relation(relation));
//								printf("\n 111 TestParticipent Assigned..DoneXXXX for reviewer\n");fflush(stdout);
//								//break;
//							
//							}
//							
//						}
//						if(ChangeSpeciaFnd== 0) //TZ1.42 compilation by Deepti
//						{
//							ChangeSpeciaFnd++;
//							TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
//							EPM_create_participant(member_tags[j], participant_type, &participant_tag);					
//							GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
//							GRM_save_relation(relation);
//							printf("\n TestParticipent Assigned..DoneXXXX\n");
//						}
//					}
//				}
//			}
//			
//		}
//		
//	if(ChangeSpeciaFnd==0)
//	{
//					APL_Plnr_Grp = NULL;
//					APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
//					tc_strcpy(APL_Plnr_Grp,"STD");
//					tc_strcat(APL_Plnr_Grp,"_");
//					tc_strcat(APL_Plnr_Grp,PLT_CodeS);
//					tc_strcat(APL_Plnr_Grp,"_");
//					tc_strcat(APL_Plnr_Grp,"Default");
//					printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);
//
//					i=0;
//					flgRoleFnd=false;
//					if(num_of_roles>0)
//					{
//						for (i=0;i<num_of_roles ;i++ )
//						{
//								CALLAPI(SA_ask_role_name(role_tags[i],rolename));
//								printf("\nRol Name :[%d][%s]\n",i,rolename);
//								if(strstr(rolename,APL_Plnr_Grp))
//								{
//									printf("\nMatch Found\n");
//									flgRoleFnd=true;
//									break;
//								}
//						}
//
//						if (flgRoleFnd==true)
//						{
//							CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
//							printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_roles);
//							if(num_of_members>0)
//							{
//								for (j=0;j<num_of_members ;j++  )
//								{
//									CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
//									CALLAPI(SA_ask_user_identifier(user_tag,userid));
//									printf("\nUser ID Name :[%s]\n",userid);
//									TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
//									EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//									GRM_find_relation_type("HasParticipant", &relation_type);
//									CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&count,&ParticipantRel));
//									printf("\n count :[%d]\n",count);
//									if(count == 0) //TZ1.42 compilation by Deepti
//									{
//										GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
//										GRM_save_relation(relation);
//										printf("\n TestParticipent Assigned..DoneXXXX\n");
//									}
//									else
//									{
//										printf("\n 222 Already Assigned..DoneXXXX for reviewer\n");
//										for(stdCnt=0;stdCnt<count;stdCnt++)
//										{
//											printf("\n 222 Inside remving the relation for reviewer...");fflush(stdout);
//											ParticipantRelTag = ParticipantRel[stdCnt];
//											printf("\n 222 Inside remving the relation for reviewer...");fflush(stdout);
//
//											if(TCTYPE_ask_object_type(ParticipantRelTag,&ObjTypTask));
//											if(TCTYPE_ask_name(ObjTypTask,type_namee_task));
//											printf("\n 222 Task: Participants Name: for reviewer %s", type_namee_task);fflush(stdout);
//
//											if ((tc_strcmp(type_namee_task,"ChangeSpecialist1")==0))
//											{
//												ChangeSpeciaFnd++;
//											
//												ITKCALL(AOM_UIF_ask_value(ParticipantRelTag,"fnd0AssigneeUser",&TaskAssignee)!=ITK_ok);
//												printf("\n 222 Removing: TaskAssignee for reviewer: [%s] ",TaskAssignee);fflush(stdout);
//												/*AOM_lock(APLTaskRevT);
//												ITKCALL(ITEM_rev_remove_participant (APLTaskRevT,ParticipantRelTag)!=ITK_ok);
//												AOM_save(APLTaskRevT);
//												AOM_unlock(APLTaskRevT);*/
//
//												TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
//												EPM_create_participant(member_tags[j], participant_type, &participant_tag);
//												CALLAPI(GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation));
//												CALLAPI(GRM_save_relation(relation));
//												printf("\n 222  TestParticipent Assigned..DoneXXXX for reviewer\n");fflush(stdout);
//												//break;
//											
//											}
//											
//										}
//										if(ChangeSpeciaFnd== 0) //TZ1.42 compilation by Deepti
//										{
//											TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
//											EPM_create_participant(member_tags[j], participant_type, &participant_tag);					
//											GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
//											GRM_save_relation(relation);
//											printf("\n TestParticipent Assigned..DoneXXXX\n");
//										}
//									}
//								}
//							}
//					}
//			  }
//	}
//	} 
	return ITK_ok;

	//printf("\n Inside AssignAPLReviewer \n");

	///return 0;
}

int CheckforColBasicDMLReleaseSTD(int partCnt,tag_t	sTaskTag, tag_t* partsTags,char* lcsToset,char* SetStdRelErr)
{

	int				ifail				=	ITK_ok;
	int				status				=	0;

	char*			type_name			=	NULL;
	char*			type_nameCH			=	NULL;
	char			*SubSyscd			= NULL;
	char*			t5Task_name			=	NULL;
	char*			inp_Tsk_no			=	NULL;
	char*			chldLcsRlzd			=	NULL;
	char*			NRRevEPASet			=	NULL;

	char			*Rlztype			=	NULL;
	char			*NonColPrt			=	NULL;

	tag_t			tsk_dml_rel_type	=	NULLTAG;
	tag_t			APLDMLRevTag		=	NULLTAG;
	tag_t			ERCDMLRevTag		=	NULLTAG;
	tag_t			PartTag				=	NULLTAG;
	tag_t			objTypeTag			=	NULLTAG;
	tag_t			ChRDsgnTag			=	NULLTAG;
	tag_t			objTypeTagCH		=	NULLTAG;


	tag_t*			APLDMLRevision		=	NULLTAG;
	tag_t*			ERCDMLRevision		=	NULLTAG;	
	tag_t*			status_list			=	NULLTAG;
	tag_t			*list_of_WSO_cntrl_tags=NULLTAG;

	WSO_search_criteria_t  	criteria_Gcontrol;

	int countAPLDml			=	0;
	int countERCDml			=	0;	
	int j					=	0;
	int iPrt				=	0;
	int isColorDML			=	0;
	logical					is_latest;    
	int iChRItem			=	0;
	int iStCnt				=	0;
	int chkDnFlg			=	0;
	int	control_number_found= 0;
	int	cntCntrl= 0;
	int iCntl = 0;
	int TaskRlzFlg = 0;


	if (!NRRevEPASet) MEM_free(NRRevEPASet);
	NRRevEPASet=(char *)MEM_alloc(2000);
	tc_strcpy(NRRevEPASet," ");


	printf("\n###########Inside STDSI Child part checks###################\n");fflush(stdout);

	status = AOM_ask_value_string(sTaskTag,"current_name",&t5Task_name);

	CALLAPI(AOM_ask_value_string(sTaskTag,"item_id",&inp_Tsk_no));
	printf("\n\n\t\t inp_Tsk_no  is :%s",inp_Tsk_no);	fflush(stdout);

	//########Validation made control object based as in TCE#####//
	WSOM_clear_search_criteria(&criteria_Gcontrol);
	strcpy(criteria_Gcontrol.name,"BasicPrtRlsChk");
	strcpy(criteria_Gcontrol.class_name,"T5_ControlObject");
	status	= WSOM_search(criteria_Gcontrol, &control_number_found, &list_of_WSO_cntrl_tags);
	printf("\ncontrol_number_found : %d",control_number_found);fflush(stdout);
	if (control_number_found>0)
	{
		cntCntrl	=	0;
		for (iCntl=0;iCntl<control_number_found;iCntl++ )
		{
			AOM_ask_value_string( list_of_WSO_cntrl_tags[iCntl], "t5_SubSyscd", &SubSyscd);
			printf("\n\nSubSyscd : %s",SubSyscd);fflush(stdout);
			if ((tc_strcmp(SubSyscd,"Live")==0))
			{
				cntCntrl++;
				MEM_free(list_of_WSO_cntrl_tags);
				break;
			}
		}
	}

	printf("\n cntCntrl:%d",cntCntrl);fflush(stdout);
	//#############################################################//

	if(cntCntrl>0)
	{
		printf("\n Check to be executed as control object found");fflush(stdout);
	
	ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
		if (tsk_dml_rel_type!=NULLTAG)
		 {

			ITKCALL(GRM_list_primary_objects_only(sTaskTag,tsk_dml_rel_type,&countAPLDml,&APLDMLRevision));
			printf("\n\n\t\t DML Revision from Task : %d",countAPLDml);fflush(stdout);		//task to dml

			for (j=0;j<countAPLDml ;j++ )
			{
				ITKCALL(ITEM_rev_sequence_is_latest(APLDMLRevision[j],&is_latest));
				printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);

				if(is_latest != true)
				{
					printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
				}else
				{
					APLDMLRevTag = APLDMLRevision[j];//DML

					if (APLDMLRevTag!=NULLTAG)
					 {

						ITKCALL(GRM_list_primary_objects_only(APLDMLRevTag,tsk_dml_rel_type,&countERCDml,&ERCDMLRevision));
						printf("\n\n\t\t DML Revision from Task : %d",countERCDml);fflush(stdout);		//task to dml

						for (j=0;j<countERCDml ;j++ )
						{
							ITKCALL(ITEM_rev_sequence_is_latest(ERCDMLRevision[j],&is_latest));
							printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);

							if(is_latest != true)
							{
								printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
							}else
							{
								ERCDMLRevTag = ERCDMLRevision[j];//DML
								ITKCALL(AOM_ask_value_string(ERCDMLRevTag, "t5_rlstype",&Rlztype));
								printf("\n Rlztype %s.....\n",Rlztype);fflush(stdout);								
								if ( tc_strcmp(Rlztype,"Colour Part Release")==0 || tc_strcmp(Rlztype,"Colour Modification Release")==0)
								{
									isColorDML=1;
									break;
								}
							}
						}
					 }
				}
			}
		 }
		  if(isColorDML==1)
			{
			 
			  for (iPrt=0;iPrt<partCnt ;iPrt++ )
				{
				  printf("\niPrt : %d",iPrt);fflush(stdout);

					PartTag	=	partsTags[iPrt];
					ITKCALL(AOM_ask_value_string(PartTag, "t5_NcPartNo",&NonColPrt));
					printf("\n NonColPrt %s.....\n",NonColPrt);fflush(stdout);	

					const char *qry_entries[2];//Multiple Item Queried Error
					const char *qry_values[2];//Multiple Item Queried Error
					int			n_tags_found=0;
					tag_t		*itemclass	=	NULLTAG;
					tag_t		item		=	NULLTAG;
								
					qry_entries[0] ="item_id";
					qry_entries[1] ="object_type";//Multiple Item Queried Error
					qry_values[0] = NonColPrt;
					qry_values[1] = "Design";//Multiple Item Queried Error

					//ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
					ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found, &itemclass);//Multiple Item Queried Error
					if(n_tags_found>0)
					{
						item = itemclass[0];
						if(item != NULLTAG )
						{
							if(TCTYPE_ask_object_type(item,&objTypeTag));

							//Asks a type for its name. Return String, which need to free once used.
							if(TCTYPE_ask_name2(objTypeTag,&type_name));
							printf("\n\n\t\t AssyTag type_name := %s", type_name);fflush(stdout);

							if (tc_strcmp(type_name,"Design Revision")==0 || tc_strcmp(type_name,"Design_0_Revision_alt")==0)
							{
								
										int	nCRItem			=	0;
										int	cntCldTask		=	0;
										int st_count		=	0;

										tag_t		*CRitem_revs_tag		=	NULLTAG;
										
										ITKCALL(AOM_ask_value_tags(item,"revision_list",&nCRItem,&CRitem_revs_tag));
										printf("\n No of Non-color Item revisions : %d",nCRItem);fflush(stdout);								
										
										for(iChRItem=nCRItem-1;iChRItem>=0;iChRItem--)
										{
											printf("\nNo of iChRItem : %d",iChRItem);fflush(stdout);
											ChRDsgnTag=NULLTAG;
											ChRDsgnTag	=	CRitem_revs_tag[iChRItem];
											
											objTypeTagCH=NULLTAG;
											if(TCTYPE_ask_object_type(ChRDsgnTag,&objTypeTagCH));

											//Asks a type for its name. Return String, which need to free once used.
											type_nameCH=NULL;
											if(TCTYPE_ask_name2(objTypeTagCH,&type_nameCH));
											printf("\n\n\t\t AssyTag type_nameCH := %s", type_nameCH);fflush(stdout);

											
											if (tc_strcmp(type_nameCH,"Design_0_Revision_alt")==0 || tc_strcmp(type_nameCH,"Design Revision")==0 )
											{											
											ITKCALL(WSOM_ask_release_status_list(ChRDsgnTag,&st_count,&status_list));
											printf("\n\n\t\t Child Status Count  is :%d",st_count);	fflush(stdout);
											if (st_count>0)
											{
												for (iStCnt=0;iStCnt<st_count ;iStCnt++ )// 	T5_LcsStdRlzd
												{
													char* c_st_class_name	=	NULL;
													ITKCALL(AOM_ask_value_string(status_list[iStCnt],"object_name",&c_st_class_name));
													printf("\n c_st_class_name: %s:lcsToset %s\n",c_st_class_name,lcsToset);fflush(stdout);													
													if( (tc_strcmp(c_st_class_name,lcsToset)!=0) && (iStCnt==(st_count-1)) )
													{
														printf("\n No Revision of non-colour %s is STDSI released",NonColPrt);fflush(stdout);
														if(chkDnFlg==0)
														{
															 tc_strcat(NRRevEPASet,"\n Following Basic Parts are Not Released by STDSI \n");																	 
															 chkDnFlg=1;
														}
														
														 tc_strcat(NRRevEPASet,"Non-Colour part ");																 
														 tc_strcat(NRRevEPASet,NonColPrt);														
														 tc_strcat(NRRevEPASet," is not released from STDSI ");														
														 tc_strcat(NRRevEPASet,"\n");
														 break;
														
														

													}
												}
											}
											else
											{
												printf("\n has no status, so part is not released from any agency");fflush(stdout);
											}
											}
										}
							}
						}
					}
				}								

				
				printf("\n NRRevEPASet:%s",NRRevEPASet);fflush(stdout);
				
				if(strlen(NRRevEPASet)>10)
				{
					tc_strcat(SetStdRelErr,NRRevEPASet);	
					cntFlag = 1;
				}
			}
	}



	return 0;
}

//#######################################################################################//
//Child part validation-1. CHild part NR of parent is released from same DML or not
//						2. CHild part of parent is present in same plant EPA or not
//#######################################################################################//

//TZ1.42 --DEEPTI
int Child_std_validation(int partCnt,tag_t	sTaskTag, tag_t* partsTags,char* lcsToset,char* SetStdRelErr,char *RevisionRl,char *ClosureRl,char *ViewBVR)
{

	int				ifail				=	ITK_ok;
	int				status				=	0;
	char*			Part_no				=	NULL;
	char*			Part_Type			=	NULL;
	char*			CItemName			=	NULL;
	char*			CItemRev			=	NULL;
	char*			CPart_no			=	NULL;
	char*			CPart_Rev			=	NULL;
	char *			ChildRelErr			=	NULL;
	char*			type_name			=	NULL;
	char*			type_nameCH			=	NULL;
	char*			t5CTask_name		=	NULL;
	char*			t5Task_name			=	NULL;
	char*			TaskId				=	NULL;
	char*			tsk_Plant			=	NULL;
	char*			inp_Tsk_no			=	NULL;
	//char*			inp_Plant			=	NULL;
	char*			ClosureDatetsk		=	NULL;
	char*			ReleaseStatustsk	=	NULL;
	char*			CPart_IdNR			=	NULL;
	char*			CPart_RevNR			=	NULL;
	char*			NRTaskId			=	NULL;
	char*			epa_Plant			=	NULL;
	char*			ReleaseStatusepa	=	NULL;
	char*			NRRevEPASet			=	NULL;
	char*			NRRevDMLSet			=	NULL;
	char*			NrDmlID				=	NULL;


	tag_t			DesignTag			=	NULLTAG;
	tag_t			ChRDsgnTag			=	NULLTAG;
	tag_t			objTypeTag			=	NULLTAG;
	tag_t			objTypeTagCH		=	NULLTAG;
	tag_t			window				=	NULLTAG;
	tag_t			rule				=	NULLTAG;
	tag_t			top_line			=	NULLTAG;
	tag_t	  		relation_type		=	NULLTAG;
	tag_t	  		relation_type_task	=	NULLTAG;
	tag_t	  		t_ChildItemRev		=	NULLTAG;
	tag_t	  		PartTskTag			=	NULLTAG;
	tag_t	  		itemTypeTag_class	=	NULLTAG;
	tag_t	  		NRParttskTag		=	NULLTAG;
	tag_t	  		NRitemTypeTag_class	=	NULLTAG;

	tag_t*			DgnChld				=	NULLTAG;
	tag_t*  		prtTasks			=	NULLTAG;
	tag_t  			prtTask				=	NULLTAG;	
	tag_t*			status_list			=	NULLTAG;
	tag_t*			status_listTask		=	NULLTAG;
	tag_t*			PartTaskTags		=	NULLTAG;
	tag_t*			NRPartTskTags		=	NULLTAG;
	tag_t*			epa_status_list		=	NULLTAG;

	int				iPrt=0,nClhd=0,iChld=0,cntTask=0,iTask=0,iSameTask=0,iChRItem=0;
	int				iChildItemTag=0;
	int st_count			=	0;
	int iStCnt				=	0;
	int chldLcsRlzd			=	0;
	int count_task			=	0;
	int cnt_tk				=	0;
	int st_tskCnt			=	0;
	int stlst				=	0;
	int TaskRlzFlg			=	0;
	int epaRlzFlg			=	0;
	int NRcount_task		=	0;
	int Precnt				=	0;
	int preEpaFlg			=	0;
	int st_epacount			=	0;
	int NRinEPA				=	0;
	int preTaskNrFlg		=	0;
	int chNrRelzFlg			=	0;
	int n_tags_found2=0;

	tag_t		itemNR		=	NULLTAG;
	tag_t	*itemclass2							= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t *  rev_list;
	char	*object_type = NULL;

	char*			BVRAsPerPartOwner				= NULL;
	char*			Item_id						= NULL;
	char*			Part_owning_groupVal				= NULL;
	struct			BomChldStrut	ChldStrutBdySh[5000];
	int				StructCntBdyShProdPlan	= 0;
	int cntLcs=0;
	int childBS = 0;
	int				count1=0;

	tag_t			objChild_BS		= NULLTAG;
	tag_t			class_id				=     NULLTAG;
	char *class_name= NULL;

	const char *qry_entries[2];//Multiple Item Queried Error
	const char *qry_values[2];//Multiple Item Queried Error

	char inp_Plant[40];


	char			type_class[TCTYPE_name_size_c+1];
	char			NRtype_class[TCTYPE_name_size_c+1];

	if (!NRRevEPASet) MEM_free(NRRevEPASet);
	NRRevEPASet=(char *)MEM_alloc(2000);
	tc_strcpy(NRRevEPASet," ");

	if (!NRRevDMLSet) MEM_free(NRRevDMLSet);
	NRRevDMLSet=(char *)MEM_alloc(2000);
	tc_strcpy(NRRevDMLSet," ");


	printf("\n###########Inside STDSI Child part checks###################\n");fflush(stdout);

	status = AOM_ask_value_string(sTaskTag,"current_name",&t5Task_name);

	CALLAPI(AOM_ask_value_string(sTaskTag,"item_id",&inp_Tsk_no));
	printf("\n\n\t\t inp_Tsk_no  is :%s",inp_Tsk_no);	fflush(stdout);

	GetPlantForDMLORTask(inp_Tsk_no,inp_Plant);
	//inp_Plant=subString(inp_Tsk_no,14,strlen(inp_Tsk_no));
	printf("\t  inp_Plant after  ...%s\n", inp_Plant);

	if (partCnt>0)
	{
		for (iPrt=0;iPrt<partCnt ;iPrt++ )
		{
			printf("\niPrt : %d",iPrt);fflush(stdout);

			DesignTag	=	partsTags[iPrt];
			//Asks an object for its type. Return tag_t as output
			if(TCTYPE_ask_object_type(DesignTag,&objTypeTag));

			//Asks a type for its name. Return String, which need to free once used.
			if(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n\n\t\t AssyTag type_name := %s", type_name);fflush(stdout);

			if (tc_strcmp(type_name,"Design Revision")==0)
			{
				CALLAPI(AOM_ask_value_string(DesignTag,"item_id",&Part_no));
				printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);

				CALLAPI(AOM_ask_value_string(DesignTag,"t5_PartType",&Part_Type));
				printf("\n\n\t\t Part_Type  is :%s",Part_Type);	fflush(stdout);

				//Added By Dhanashri for skip prev rev UATZ1.42//
				 char*			SkipPrevRevSTD				= NULL;
				 ITKCALL(AOM_ask_value_string(DesignTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
				 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
				 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
					
					//if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
					if(tc_strlen(SkipPrevRevSTD)>0)
					{
						printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
						continue;
					}
				//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//


				//Explode the BOM
				/*nClhd	=	0;
				CALLAPI(BOM_create_window (&window));
				CALLAPI(CFM_find( "Latest Working", &rule));
				CALLAPI(BOM_set_window_config_rule( window, rule ));
				CALLAPI(BOM_set_window_top_line(window, null_tag,DesignTag , null_tag, &top_line));
				CALLAPI(BOM_line_ask_child_lines (top_line, &nClhd, &DgnChld));*/

				ITKCALL(AOM_UIF_ask_value(DesignTag,"owning_group",&Part_owning_groupVal));
				printf("\n\n\t\t Part_no  Part_owning_groupVal is :%s",Part_owning_groupVal);fflush(stdout);

				if (tc_strcmp(BVRAsPerPartOwner,"NULL") !=0) MEM_free(BVRAsPerPartOwner);
				BVRAsPerPartOwner=(char *)MEM_alloc(100);

				//TZ3.46
				char BVRInfo2[40];
				char Info1[40];
				char Info3[40];
				get_CtrlVal_APLLcsInf(Part_owning_groupVal,Info1,BVRInfo2,Info3);//TZ3.46
				tc_strcpy(BVRAsPerPartOwner,BVRInfo2);

				StructCntBdyShProdPlan	= 0;
				ITKCALL(Get_Part_BOM_Lvl(DesignTag,1,ClosureRl,RevisionRl,BVRAsPerPartOwner,ChldStrutBdySh,&StructCntBdyShProdPlan));
				printf("\n\t\t StructCntBdyShProdPlan:%d",StructCntBdyShProdPlan);fflush(stdout);

				iChld=0;
				for (iChld=1;iChld<=StructCntBdyShProdPlan ;iChld++ )
				{				
					cntLcs=0;
					iSameTask	=	0;
					objChild_BS		= NULLTAG;
					objChild_BS=ChldStrutBdySh[iChld].child_objs;
					char	*Part_clr_ind	=	NULL;

					ITKCALL(AOM_UIF_ask_value(objChild_BS,"item_id",&Item_id));
					printf("\n\n\t EPA Child Part String is Item_id-->%s",Item_id);	fflush(stdout);
					Part_clr_ind	=	NULL;
					ITKCALL(AOM_ask_value_string(objChild_BS,"t5_ColourInd",&Part_clr_ind));
					printf("\n\n\t EPA Child Part String is Part_clr_ind-->%s",Part_clr_ind);	fflush(stdout);

					qry_entries[0] ="item_id";
					qry_entries[1] ="object_type";//Multiple Item Queried Error
					qry_values[0] = Item_id;
					if (tc_strcmp(Part_clr_ind,"C")==0)
					{
						qry_values[1] = "T5_ClrPart";//Multiple Item Queried Error Hemal
					}
					else
					{
						//qry_values[1] = "Design";//Multiple Item Queried Error Hemal
						//Handle the different design child class.
						char	*designBORev		=	NULL;
						char	*designBO			=	NULL;
						//tag_t	AssyTag			=	NULLTAG;
						//AssyTag=PartTags[k];
						printf("\nBefore getDesignType");fflush(stdout);
						getDesignType(objChild_BS, &designBORev,&designBO);
						printf("\nAfter getDesignType : %s",designBO);fflush(stdout);
						qry_values[1] = designBO;

					}//Multiple Item Queried Error

					//ITKCALL(ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found2, &itemclass2));
					ITKCALL(ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found2, &itemclass2));//Multiple Item Queried Error
					if(n_tags_found2>0)
					{
						//itemcldclass = itemclass2[0];

						//ITKCALL(ITEM_list_all_revs(itemcldclass, &count1,&rev_list ));
						
						CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
						CALLAPI(GRM_list_primary_objects_only(objChild_BS,relation_type,&cntTask,&prtTasks));

						printf("\nNo of Child Task Found : %d",cntTask);fflush(stdout);
						//Check Child is attached with same Task or not.
						if (cntTask>0)
						{
							//iSameTask	=	0;
							for (iTask=0;iTask<cntTask;iTask++)
							{
								prtTask	=	NULLTAG;
								prtTask	=	prtTasks[iTask];
								//current_id
								CALLAPI(AOM_ask_value_string(prtTask,"object_type",&object_type));
								printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
								if(strcmp(object_type,"T5_APLTaskRevision")==0)
								{									
									status = AOM_ask_value_string(prtTask,"item_id",&t5CTask_name);
									printf("\nName of Input task: %s",inp_Tsk_no);fflush(stdout);
									printf("\nName of child task: %s",t5CTask_name);fflush(stdout);

									if (tc_strcmp(inp_Tsk_no,t5CTask_name)==0)
									{
										//Parent and child are in same Task.
										iSameTask++;
										printf("\nChild Part %s and Parent Parent Part is in Same Task : %s, count : %d",CItemName,t5CTask_name,iSameTask);fflush(stdout);
										break;
									}
								}
							}
							if (iSameTask>0)
							{
								//If Parent and child are in same task part validation will not be called.
								//return ifail;
							}
						}

							if(iSameTask == 0)
							{
								//Query the All revision of the child part
								//check any one revision release from same plant or not.
								//if any revision release from same plant validation will not be call
								//else validation error will be added in string.

								//const char *qry_entries[1];
								//const char *qry_values[1];
								int			n_tags_found=0;
								//tag_t		*itemclass	=	NULLTAG;
								//tag_t		item		=	NULLTAG;


								printf("\n Child Part Number %s.....\n",Item_id);
								//qry_entries[0] ="item_id";
								//qry_values[0] = Item_id;

								//Find Item by its ID.
								//ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
								//if(n_tags_found>0)
								//{
									//item = itemclass[0];
									//if(item != NULLTAG )
									if(objChild_BS != NULLTAG )
									{
										int	nCRItem			=	0;
										int	cntCldTask		=	0;
										int st_count		=	0;

										tag_t		*CRitem_revs_tag		=	NULLTAG;
										//tag_t*  	ChRTask				=	NULLTAG;
										//List all item revsion
										//ITKCALL(ITEM_list_all_revs(item,&nCRItem,&CRitem_revs_tag));
										ITKCALL(AOM_ask_value_tags(objChild_BS,"revision_list",&nCRItem,&CRitem_revs_tag));
										printf("\nNo of CHild Item revisions : %d",nCRItem);fflush(stdout);
										//printf("\n No of Child Task Found : %d",nCRItem);fflush(stdout);

										chldLcsRlzd=0;
										TaskRlzFlg=0;
										NRinEPA=0;
										//for (iChRItem=0;iChRItem<nCRItem ;iChRItem++ )
										for(iChRItem=nCRItem-1;iChRItem>=0;iChRItem--)
										{
											printf("\nNo of iChRItem : %d",iChRItem);fflush(stdout);
											ChRDsgnTag=NULLTAG;
											ChRDsgnTag	=	CRitem_revs_tag[iChRItem];

											//Added TZ 1.43//
											objTypeTagCH=NULLTAG;
											if(TCTYPE_ask_object_type(ChRDsgnTag,&objTypeTagCH));

											//Asks a type for its name. Return String, which need to free once used.
											type_nameCH=NULL;
											if(TCTYPE_ask_name2(objTypeTagCH,&type_nameCH));
											printf("\n\n\t\t AssyTag type_nameCH := %s", type_nameCH);fflush(stdout);
											
											CALLAPI(POM_class_of_instance(objTypeTagCH,&class_id));
											CALLAPI(POM_name_of_class(class_id,&class_name));
											printf("\n class_name is :%s\n",class_name);fflush(stdout);
											
											//Add color part in if condition remaining
											
											if (tc_strcmp(type_nameCH,"Design_0_Revision_alt")==0 || tc_strcmp(type_nameCH,"Design Revision")==0 )
											{				

											CALLAPI(AOM_ask_value_string(ChRDsgnTag,"item_id",&CPart_no));
											printf("\n\n\t\t Child Part_no  is :%s",CPart_no);	fflush(stdout);

											CALLAPI(AOM_ask_value_string(ChRDsgnTag,"item_revision_id",&CPart_Rev));
											printf("\n\n\t\t Child Part_no  is :%s",CPart_Rev);	fflush(stdout);

											ITKCALL(WSOM_ask_release_status_list(ChRDsgnTag,&st_count,&status_list));
											printf("\n\n\t\t Child Status Count  is :%d",st_count);	fflush(stdout);
											if (st_count>0)
											{
												for (iStCnt=0;iStCnt<st_count ;iStCnt++ )// 	T5_LcsStdRlzd
												{
													char* c_st_class_name	=	NULL;
													ITKCALL(AOM_ask_value_string(status_list[iStCnt],"object_name",&c_st_class_name));
													printf("\n c_st_class_name: %s:lcsToset %s\n",c_st_class_name,lcsToset);fflush(stdout);
													if(tc_strcmp(c_st_class_name,lcsToset)==0)
													{
														printf("\n Revision %s of child part %s of parent %s is STDSI released",CPart_Rev,CPart_no,Part_no);fflush(stdout);
														chldLcsRlzd=1;
														break;

													}
												}
											}
											else
											{
												printf("\n%s has no status, so part is not released from any agency",CPart_no);fflush(stdout);
											}
										}
											
										}

										if(chldLcsRlzd==0) 
										{
											chNrRelzFlg=0;
											//tag_t		itemNR		=	NULLTAG;
											printf("\n No revision of child part %s of parent %s seems released from STDSI, checking for NR in EPA and its DML",CPart_no,Part_no);fflush(stdout);

											iChRItem=0;
											//for (iChRItem=0;iChRItem<nCRItem ;iChRItem++ )
											for(iChRItem=nCRItem-1;iChRItem>=0;iChRItem--)
											{
												printf("\nNo of iChRItem : %d",iChRItem);fflush(stdout);
												ChRDsgnTag=NULLTAG;
												ChRDsgnTag	=	CRitem_revs_tag[iChRItem];								

												CPart_Rev=NULL;
												CALLAPI(AOM_ask_value_string(ChRDsgnTag,"item_revision_id",&CPart_Rev));
												printf("\n\n\t\t Child Part Rev  is :%s",CPart_Rev);	fflush(stdout);

												objTypeTagCH=NULLTAG;
												if(TCTYPE_ask_object_type(ChRDsgnTag,&objTypeTagCH));

												//Asks a type for its name. Return String, which need to free once used.
												type_nameCH=NULL;
												if(TCTYPE_ask_name2(objTypeTagCH,&type_nameCH));
												printf("\n\n\t\t AssyTag type_nameCH := %s", type_nameCH);fflush(stdout);
											
												if (tc_strcmp(type_nameCH,"Design_0_Revision_alt")==0 || tc_strcmp(type_nameCH,"Design Revision")==0 )
												{
													//if(tc_strcmp(CPart_Rev,"NR")==0)
													if(tc_strstr(CPart_Rev,"NR")!=NULL)
													{
														printf("\n Found NR Revision of %s",CPart_no);fflush(stdout);
														itemNR=CRitem_revs_tag[iChRItem];
														break;
													}
												}
											}
											
											//itemNR = itemclass[0];
											if(itemNR != NULLTAG )
											{
												CALLAPI(AOM_ask_value_string(itemNR,"item_id",&CPart_IdNR));
												printf("\n\n\t\t  CHild Name : CPart_IdNR  is :%s",CPart_IdNR);	fflush(stdout);

												CALLAPI(AOM_ask_value_string(itemNR,"item_revision_id",&CPart_RevNR));
												printf("\n\n\t\t  CHild Rev : CPart_RevNR  is :%s",CPart_RevNR);	fflush(stdout);

												//Checking whether NR is in EPA of same plant or not//

												epaRlzFlg=0;
												relation_type_task=NULLTAG;
												GRM_find_relation_type("CMHasSolutionItem",&relation_type_task);
												GRM_list_primary_objects_only(itemNR,relation_type_task,&NRcount_task,&NRPartTskTags);
												if(NRcount_task >0)
												{							
													for (Precnt=0;Precnt<NRcount_task ;Precnt++ )
													{
														NRParttskTag=NULLTAG;
														NRitemTypeTag_class=NULLTAG;
														NRParttskTag=NRPartTskTags[Precnt];
														ITKCALL (TCTYPE_ask_object_type(NRParttskTag,&NRitemTypeTag_class));
														ITKCALL (TCTYPE_ask_name(NRitemTypeTag_class,NRtype_class));

														printf("\n  NRtype_class ...%s\n", NRtype_class);

														NRTaskId=NULL;
														ITKCALL(AOM_ask_value_string(NRParttskTag, "item_id",&NRTaskId));
														printf("\n NRTaskId %s.....\n",NRTaskId);

														if(tc_strcmp(NRtype_class,"T5_EPATaskRevision")==0)
														{
															epa_Plant=NULL;
															epa_Plant=subString(NRTaskId,22,strlen(NRTaskId));
															printf("\t  epa_Plant after  ...%s\n", epa_Plant);

															if(tc_strcmp(inp_Plant,epa_Plant)==0)
															{
																ITKCALL(WSOM_ask_release_status_list(NRParttskTag,&st_epacount,&epa_status_list));
																for (stlst = 0; stlst < st_epacount; stlst++)
																{
																	printf("\n stlst:%d",stlst);fflush(stdout);

																	ReleaseStatusepa=NULL;
																	AOM_ask_name(epa_status_list[stlst], &ReleaseStatusepa);
																	printf("\n ReleaseStatusepa %s \n",  ReleaseStatusepa);fflush(stdout);
																	if( (tc_strcmp(ReleaseStatusepa,lcsToset)!=0) && (stlst==(st_epacount-1)) )
																	{
																		NRinEPA=1;
																		if(preEpaFlg==0)
																		{
																			 tc_strcat(NRRevEPASet,"\n Following child parts are under STDSI working EPA. Please release the child part by finalizing EPA \n");																	 
																			 preEpaFlg=1;
																		}
																		 //tc_strcat(NRRevEPASet,"\n");
																		 tc_strcat(NRRevEPASet,"NR Revision of part ");																 
																		 tc_strcat(NRRevEPASet,CPart_IdNR);
																		 tc_strcat(NRRevEPASet," of parent ");
																		 tc_strcat(NRRevEPASet,Part_no);
																		 tc_strcat(NRRevEPASet," is contained in EPA Task ");
																		 tc_strcat(NRRevEPASet,NRTaskId);
																		 tc_strcat(NRRevEPASet,"\n");
																		 break;
																	}
																}														
																
															}
														}
													}

													if(NRinEPA==0)
													{
														if(preTaskNrFlg==0)
														{
															tc_strcat(NRRevDMLSet,"\n Child Part NR of Parent is not STDSI Released From Plant DML.Please release the child part from STDS1.\n");																	 
															preTaskNrFlg=1;
														}
														//tc_strcat(NRRevDMLSet,"\n");
														tc_strcat(NRRevDMLSet,"NR Revision of child part ");																 
														tc_strcat(NRRevDMLSet,CPart_IdNR);
														tc_strcat(NRRevDMLSet," of parent ");
														tc_strcat(NRRevDMLSet,Part_no);
														tc_strcat(NRRevDMLSet," is not STDSI Released from plant.");
														tc_strcat(NRRevDMLSet,"\n");
																	
													}

												}
												else
												{
													tc_strcat(NRRevDMLSet,"NR Revision of child part ");																 
													tc_strcat(NRRevDMLSet,CPart_IdNR);
													tc_strcat(NRRevDMLSet," of parent ");
													tc_strcat(NRRevDMLSet,Part_no);
													tc_strcat(NRRevDMLSet," is neither STDSI Released nor attached to any task");
													tc_strcat(NRRevDMLSet,"\n");
												}				


											}



											
										}//chldLcsRlzd=0
									}
								//}
							}
					}
					//printf("\n ChildRelEr22r: %s\n",SetStdRelErr);fflush(stdout);
				}
			}
		}

		printf("\n NRRevDMLSet:%s",NRRevDMLSet);fflush(stdout);
		printf("\n NRRevEPASet:%s",NRRevEPASet);fflush(stdout);
		if(strlen(NRRevDMLSet)>10)
						{
							tc_strcat(SetStdRelErr,NRRevDMLSet);	
							cntFlag = 1;
						}
						if(strlen(NRRevEPASet)>10)
						{
							tc_strcat(SetStdRelErr,NRRevEPASet);	
							cntFlag = 1;
						}
	}

	return 0;
}



//#######################################################################################//
//This validation will ensure that the two revision of parts can not be released on same day
//#######################################################################################//
int STD_Two_Rev_Same_Day_Checks_P(int PartCnt, tag_t* PartTags,char* SetStdRelErr,char* itemid)
{
			int				j			=	0;
			int				task_len	=	0;
			int				kTask		=	0;
			int				count		=	0;
			int				Pre_count	=	0;
			int				k			=	0;

			

			char*			Part_no				= NULL;	        
			//char			*inp_Plant			= NULL;
			//char			*task_Plant			= NULL;
			char*			current_name		= NULL;
			char*			ClosureDate			= NULL;
			char*			ClosureDateDup		= NULL;
			char*			DmlId				= NULL;
			char			pAccessDate[20];
			char			cCurrentAccessDate[20]={0};
       		char *			pAccessDateDup 		= NULL;
			char *			twoRevRlzErr1		= NULL;
			char  			rev_id1[ITEM_id_size_c+1];
			char			type_name_ref[TCTYPE_name_size_c+1];
			char			*Part_Rev			=	NULL;

		    tag_t			*DMLRevision		= NULLTAG;	    
			tag_t			objTypeRefTag		= NULLTAG;			
			tag_t			tsk_dml_rel_type	= NULLTAG;
        	tag_t			relation_type		= NULLTAG;
        	tag_t			relation_type2		= NULLTAG;
        	tag_t			AssyPreTag			= NULLTAG;
			tag_t			DMLRevTag			= NULLTAG;	        
			tag_t*			PartDmlTags			= NULLTAG;
			tag_t*			PartPreTags			= NULLTAG;
			tag_t			PartDmlTag			= NULLTAG;
			tag_t			AssyTag				= NULLTAG;
			logical			is_latest;     

			char LcsStdWrkg[40];
			char LcsStdRlzd[40];
			char inp_Plant[40];
			char task_Plant[40];
		  
	      

		// Start for two rev. on same day check
		if (tc_strcmp(twoRevRlzErr1,"NULL")==0) MEM_free(twoRevRlzErr1);
		twoRevRlzErr1=(char *)MEM_alloc(100);
		tc_strcpy(twoRevRlzErr1,"");

		printf("\n ##############Inside two revision released on same day check###########");fflush(stdout);
				task_len=0;
				task_len=strlen(itemid);
				printf("\t  task_len ...%d\n", task_len);// length task
				//inp_Plant=subString(itemid,14,task_len);
				GetPlantForDMLORTask(itemid,inp_Plant);	
				printf("\t  inp_Plant after  ...%s\n", inp_Plant);//task

				char  ItemIDCpy[40];
				tc_strcpy(ItemIDCpy,itemid);
				GetPlantWiseRelStat(ItemIDCpy,LcsStdWrkg,LcsStdRlzd);
				printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
				printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);

				for (k=0;k<PartCnt ;k++ )
				{
					AssyPreTag=NULLTAG;
					const char *attrs[1];
					const char *values[1];
					int n_tags_found=0;
	                int				count1				= 0;
	                int				BypassNACSFlag				= 0;

					printf("\n\n\t\t for k_same rev =:%d",k);fflush(stdout);
					AssyTag=PartTags[k];
					ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
					printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);

					//Added By Dhanashri for skip prev rev UATZ1.42//
					 char*			SkipPrevRevSTD				= NULL;
					 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
					 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
					printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
					
					//if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
					if(tc_strlen(SkipPrevRevSTD)>0)
					{
						printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
						continue;
					}
					//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

					//Logic for getting previous revision//
//					GRM_find_relation_type("IMAN_based_on",&relation_type2);
//					GRM_list_secondary_objects_only(AssyTag,relation_type2,&Pre_count,&PartPreTags);
//					printf("\n\n\t\tPrev_Rev_Checks Pre_count: %d",Pre_count);fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev));
					printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);

					if(strstr(Part_Rev,"NR"))
					{
						printf("\n Previous revision function can not be called as current revision has NR revision");fflush(stdout);
					}
					else
					{
						printf("\n Calling function to get Previous revision ");fflush(stdout);
						tm_fnd_Prev_Official_Revision(Part_no,AssyTag,&AssyPreTag);//TZ 1.43
					}

					//if(Pre_count>0)
					if(AssyPreTag)
					{					

					//AssyPreTag=PartPreTags[0];
					///////////////////////////////////////			
					
						ITEM_ask_rev_id 	( AssyPreTag, rev_id1);

						printf("\n rev_id1 is  ---->%s\n", rev_id1);fflush(stdout);//diplay the previous revision					

						//Added By Dhanashri for skip prev rev UATZ1.42//
						 char*			SkipPrevRevSTD1				= NULL;
						 ITKCALL(AOM_ask_value_string(AssyPreTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD1));
						 printf("\n\n\t\t SkipPrevRevSTD1  is :%s",SkipPrevRevSTD1);	fflush(stdout);
						 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD1)  is :%d",tc_strlen(SkipPrevRevSTD1));	fflush(stdout);
					
							//if(tc_strcmp(SkipPrevRevSTD1,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD1,"") !=0)
							if(tc_strlen(SkipPrevRevSTD1)>0)
							{
								printf("\n\n\t\t Inside SkipPrevRevSTD1 not null...");	fflush(stdout);
								continue;
							}
						//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

						GRM_find_relation_type("CMHasSolutionItem",&relation_type);
						GRM_list_primary_objects_only(AssyPreTag,relation_type,&count,&PartDmlTags);

						printf("\n\n\t\t Part to ERC DML to Task : %d",count);fflush(stdout);
						if(count >0)
						{
					   for (kTask=0;kTask<count ;kTask++ )
					   {
						PartDmlTag=PartDmlTags[kTask];//task pointer
						printf("\n\n\t\t INSIDE: ");fflush(stdout);



							ITKCALL(TCTYPE_ask_object_type(PartDmlTag,&objTypeRefTag));//task pointer
							ITKCALL(TCTYPE_ask_name(objTypeRefTag,type_name_ref));
							printf("\nTCDCtype_name_ref isss :%s\n",type_name_ref);fflush(stdout);

							  if (strcmp(type_name_ref,"T5_APLTaskRevision")==0)
								{
									//ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
//									if (tsk_dml_rel_type!=NULLTAG)
//									 {
//
//										ITKCALL(GRM_list_primary_objects_only(PartDmlTag,tsk_dml_rel_type,&count1,&DMLRevision));
//										printf("\n\n\t\t DML Revision from Task : %d",count1);fflush(stdout);		//task to dml
//
//										for (j=0;j<count1 ;j++ )
//										{
//											ITKCALL(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
//											printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);
//
//											if(is_latest != true)
//											{
//												printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
//											}else
//											{
												ITKCALL(AOM_ask_value_string(PartDmlTag, "item_id",&DmlId));
												printf("\n DmlId %s.....\n",DmlId);//previous revision's task
//												DMLRevTag = DMLRevision[j];//DML
//												ITKCALL(AOM_ask_value_string(DMLRevTag,"current_name",&current_name));
//												printf("\n\n\t\t dml is :%s\n",current_name);fflush(stdout);
//												task_len=0;
//												task_len=strlen(DmlId);
												//task_Plant=subString(DmlId,14,task_len);
												GetPlantForDMLORTask(DmlId,task_Plant);	
												printf("\n task_Plant is : %s\n",task_Plant);fflush(stdout);

												if(tc_strcmp(inp_Plant,task_Plant)==0)
												{
													printf("\n inside plant check is :\n");fflush(stdout);

													//ITKCALL(AOM_UIF_ask_value(DMLRevTag,"date_released",&ClosureDate));
													ITKCALL(AOM_UIF_ask_value(PartDmlTag,"date_released",&ClosureDate));
													printf("\n ClosureDate : %s\n",ClosureDate);fflush(stdout);//28-Oct-2017 14:12

													ClosureDateDup = subString(ClosureDate,0,11);
													printf("\n ClosureDateDup : %s\n",ClosureDateDup);fflush(stdout);
													getCurrentDateTime(cCurrentAccessDate);
													printf("\n  todays date111 is: %s\n",cCurrentAccessDate);
													pAccessDateDup = subString(cCurrentAccessDate,0,11);
													printf("\n  todays date is: %s\n",pAccessDateDup);
													
													if(strlen(ClosureDateDup)>2)
													{
														if(tc_strcmp(ClosureDateDup,pAccessDateDup)==0)
														{
															tc_strcat(twoRevRlzErr1,"\n Two revision of part ");
															tc_strcat(twoRevRlzErr1,Part_no);
															tc_strcat(twoRevRlzErr1," cannot be released on same day.");
															printf("\n IsPPPPMRlzErr: %s\n",twoRevRlzErr1);fflush(stdout);												
														  }
													}
												}

											//}

									//}
								//  }

							  }


				  }
				}
				}
				else
					{
					printf("\n Previous revision does not exist for part %s",Part_no);fflush(stdout);
					}
			
				} 
				if(strlen(twoRevRlzErr1)>10)
				{
					tc_strcat(SetStdRelErr,twoRevRlzErr1);
					cntFlag=1;
				}

	return 0;
}
//###############################################################################################//
//##Check will not allow the Sign-off of a DML if Next Official Revision of  Parts exist with DR Status > DR3 so user has to Release Latest Revision only##//
//###############################################################################################//

int Next_Rev_Gt_DR3_Exists_Check(int PartCnt, tag_t* PartTags,char* SetStdRelErr,char* itemid)
{

	int				task_len			= 0;
	int				k,j					= 0;
	int				st_ok_Flg			= 0;
	int				cnt_next			= 0;
	int				count_task			= 0;
	int				cnt_tk				= 0;
	int				count_dml_1			= 0;
	int				st_count_dml		= 0;
	int				NextRevFlagDml		= 0;
	int				flagerror			= 0;
	int				st_count			= 0;
	int				dmlstlst			= 0;
	int				control_number_found= 0;
	int				cntCntrl			= 0;
	int				iCntl				= 0;
	int				status				= 0;

	//char			*inp_Plant			= NULL;
	//char			*tsk_Plant			= NULL;
	char			*Part_no			= NULL;
	char			*Desc_obj_lt_Rev	= NULL;
	char			*Desc_obj_Inp_Part	= NULL;
	char			*part_DRStatus		= NULL;
	char			*WSO_Name_next_Rev	= NULL;
	char			*ReleaseStatusDML	= NULL;
	char			*TaskId				= NULL;
	char			*Revision			= NULL;
	char			*Temp				= NULL;
	char			*attchdPart			= NULL;
	char			*SubSyscd			= NULL;

	char			type_class[TCTYPE_name_size_c+1];
	char			type_dml[TCTYPE_name_size_c+1];

	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;

	tag_t			AssyTag				= NULLTAG;
	tag_t			master				= NULLTAG;
	tag_t			latestrev			= NULLTAG;
	tag_t			relation_type_task	= NULLTAG;
	tag_t			PartTskTag			= NULLTAG;
	tag_t			itemTypeTag_class	= NULLTAG;
	tag_t			tsk_dml_rel_type_1	= NULLTAG;
	tag_t			DMLRevTag_Prt		= NULLTAG;
	tag_t			itemTypeTag_Dml		= NULLTAG;

	tag_t*			status_list			= NULLTAG;
	tag_t*			dml_status_list		= NULLTAG;
	tag_t*			PartTaskTags		= NULLTAG;
	tag_t*			DMLRevision_Prt		= NULLTAG;
	tag_t*			list_of_WSO_cntrl_tags= NULLTAG;

	char LcsStdWrkg[40];
	char LcsStdRlzd[40];
	char lcsAplRlzd[40];
	char inp_Plant[40];
	char tsk_Plant[40];
	char LcsAplWrkg[40];
	

	WSO_search_criteria_t  	criteria_Gcontrol;

	logical			is_latest_dml;

				printf("\n ############Inside Next_Rev_Gt_DR3_Exists_Check : Next revision DML with STDSI Check###########");fflush(stdout);
				task_len=0;
				task_len=strlen(itemid);
				printf("\t  task_len ...%d\n", task_len);// length task
				GetPlantForDMLORTask(itemid,inp_Plant);
				//inp_Plant=subString(itemid,14,task_len);
				printf("\t  inp_Plant after  ...%s\n", inp_Plant);

				char  ItemIDCpy[40];
				tc_strcpy(ItemIDCpy,itemid);
				GetPlantWiseRelStat(ItemIDCpy,LcsStdWrkg,LcsStdRlzd);
				printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
				printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);

				GetPlantWiseRelStatAtAPL(ItemIDCpy,LcsAplWrkg,lcsAplRlzd); //TZ3.46	
				printf("\n LcsAplWrkg:%s",LcsAplWrkg);fflush(stdout);
				printf("\n lcsAplRlzd:%s",lcsAplRlzd);fflush(stdout);
	
//				printf( "item_id:%s\n", ItemIDCpy);
//				Dsgn_No=tc_strtok(ItemIDCpy,"_");
//				printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,ItemIDCpy);
//				Dsgn_No = tc_strtok(NULL,"_");
//				printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,ItemIDCpy);
//				PLT_Code = tc_strtok(NULL,"_");
//				printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,ItemIDCpy);

//				if(tc_strcmp(PLT_Code,"APLP")==0)
//				{
//				strcpy(lcsAplRlzd,"T5_LcsAplpRlzd");
//			   }else
//				if(tc_strcmp(PLT_Code,"APLV")==0)
//				{
//				strcpy(lcsAplRlzd,"T5_LcsAplvRlzd");
//				}else
//				if(tc_strcmp(PLT_Code,"APLD")==0)
//				{
//				strcpy(lcsAplRlzd,"T5_LcsApldRlzd");
//				}else
//				if(tc_strcmp(PLT_Code,"APLC")==0)
//				{
//				strcpy(lcsAplRlzd,"T5_LcsAplRlzd");
//				}else
//				if(tc_strcmp(PLT_Code,"APLJ")==0)
//				{
//				strcpy(lcsAplRlzd,"T5_LcsApljRlzd");
//				}else
//				if(tc_strcmp(PLT_Code,"APLL")==0)
//				{
//				strcpy(lcsAplRlzd,"T5_LcsApllRlzd");
//				}else
//				if(tc_strcmp(PLT_Code,"APLA")==0)
//				{
//				strcpy(lcsAplRlzd,"T5_LcsAplaRlzd");
//				}else
//				if(tc_strcmp(PLT_Code,"APLU")==0)
//				{
//				strcpy(lcsAplRlzd,"T5_LcsApluRlzd");
//				}else
//				if(tc_strcmp(PLT_Code,"APLS")==0)
//				{
//				strcpy(lcsAplRlzd,"T5_LcsAplsRlzd");
//				}else
//				{
//				strcpy(lcsAplRlzd,"T5_LcsAplRlzd");
//				}

	//			printf("\n lcsAplRlzd:%s",lcsAplRlzd);fflush(stdout);

				//########Validation made control object based as in TCE#####//
				WSOM_clear_search_criteria(&criteria_Gcontrol);
				strcpy(criteria_Gcontrol.name,"NxtRevDrChk");
				strcpy(criteria_Gcontrol.class_name,"T5_ControlObject");
				status	= WSOM_search(criteria_Gcontrol, &control_number_found, &list_of_WSO_cntrl_tags);
				printf("\ncontrol_number_found : %d",control_number_found);fflush(stdout);
				if (control_number_found>0)
				{
					cntCntrl	=	0;
					for (iCntl=0;iCntl<control_number_found;iCntl++ )
					{
						AOM_ask_value_string( list_of_WSO_cntrl_tags[iCntl], "t5_SubSyscd", &SubSyscd);
						printf("\n\nSubSyscd : %s",SubSyscd);fflush(stdout);
						if ((tc_strcmp(SubSyscd,"Live")==0))
						{
							cntCntrl++;
							MEM_free(list_of_WSO_cntrl_tags);
							break;
						}
					}
				}

				printf("\n cntCntrl:%d",cntCntrl);fflush(stdout);

				if(cntCntrl>0)
				{
					printf("\n Check to be executed as control object found");fflush(stdout);

				//###########################################################//

				if((tc_strstr(itemid,"PP")!=NULL || tc_strstr(itemid,"PM")!=NULL  || tc_strstr(itemid,"JP")!=NULL  || tc_strstr(itemid,"JM")!=NULL  || tc_strstr(itemid,"LP")!=NULL  || tc_strstr(itemid,"LM")!=NULL))
				{
					for (k=0;k<PartCnt ;k++ )
					{				

						printf("\n\n\t\t for k =:%d",k);fflush(stdout);
						AssyTag=PartTags[k];
						latestrev=NULLTAG;
						NextRevFlagDml=0;

						ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
						printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);

						//Added By Dhanashri for skip prev rev UATZ1.42//
						 char*			SkipPrevRevSTD				= NULL;
						 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
						  printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
						 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
					
							//if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
							if(tc_strlen(SkipPrevRevSTD)>0)
							{
								printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
								continue;
							}
						//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

						if (AOM_ask_value_string(AssyTag,"current_revision_id",&Desc_obj_Inp_Part)==ITK_ok)
						printf("\n Desc_obj_Inp_Part Value is :  %s\n",Desc_obj_Inp_Part);

//						if( AOM_ask_value_string(AssyTag,"t5_PartStatus",&part_DRStatus)==ITK_ok)
//						printf("\n part_DRStatus Value :  %s\n",part_DRStatus);
//
//						if((!tc_strcmp(part_DRStatus,"DR0")) || (!tc_strcmp(part_DRStatus,"DR1")) || (!tc_strcmp(part_DRStatus,"DR2")) || (!tc_strcmp(part_DRStatus,"DR3")))
//						continue;
//
//						if( (strlen(part_DRStatus)==0) || !tc_strcmp(part_DRStatus,"DR4") || !tc_strcmp(part_DRStatus,"DR5")|| !tc_strcmp(part_DRStatus,"NA") || !tc_strcmp(part_DRStatus,"AR4") || !tc_strcmp(part_DRStatus,"AR5"))
//						//if( !tc_strcmp(part_DRStatus,"DR4") || !tc_strcmp(part_DRStatus,"DR5")|| !tc_strcmp(part_DRStatus,"NA") || !tc_strcmp(part_DRStatus,"AR4") || !tc_strcmp(part_DRStatus,"AR5"))
//						{

//							if(ITEM_ask_item_of_rev ( AssyTag,&master) );//Commented in TZ1.43
//							if(ITEM_ask_latest_rev(master,&latestrev));//Commented in TZ1.43

							tm_fnd_Next_revision(Part_no,AssyTag,&latestrev); //TZ1.43



							if(latestrev != NULLTAG)
							{
								if (AOM_ask_value_string(latestrev,"current_revision_id",&Desc_obj_lt_Rev)==ITK_ok)
								printf("\n Desc_obj_lt_Rev Value is : %s\n",Desc_obj_lt_Rev);

								if( AOM_ask_value_string(latestrev,"t5_PartStatus",&part_DRStatus)==ITK_ok)
								printf("\n part_DRStatus Value :  %s\n",part_DRStatus);

								if((!tc_strcmp(part_DRStatus,"DR0")) || (!tc_strcmp(part_DRStatus,"DR1")) || (!tc_strcmp(part_DRStatus,"DR2")) || (!tc_strcmp(part_DRStatus,"DR3")) || (!tc_strcmp(part_DRStatus,"AR0")) || (!tc_strcmp(part_DRStatus,"AR1")) || (!tc_strcmp(part_DRStatus,"AR2")) || (!tc_strcmp(part_DRStatus,"AR3")) )
								continue;

								if( (strlen(part_DRStatus)==0) || !tc_strcmp(part_DRStatus,"DR4") || !tc_strcmp(part_DRStatus,"DR5")|| !tc_strcmp(part_DRStatus,"NA") || !tc_strcmp(part_DRStatus,"AR4") || !tc_strcmp(part_DRStatus,"AR5") || !tc_strcmp(part_DRStatus,"DR3P") || !tc_strcmp(part_DRStatus,"AR3P"))
								{

								if (AOM_ask_value_string(latestrev,"item_revision_id",&Revision)==ITK_ok)
								printf("\n Revision Value is : %s\n",Revision);

								if(tc_strcmp(Desc_obj_Inp_Part,Desc_obj_lt_Rev)==0)
								{
									printf("Task Part object is latest ..");fflush(stdout);
								}
								else
								{
									printf("Task Part object is not latest ..");fflush(stdout);

									ITKCALL(WSOM_ask_release_status_list(latestrev,&st_count,&status_list));
									printf("\n st_count :%d is\n",st_count);fflush(stdout);

									if(st_count>0)
											{
												st_ok_Flg=0;
												for (cnt_next=0;cnt_next< st_count;cnt_next++ )
												{
													WSO_Name_next_Rev=NULL;
													ITKCALL(AOM_ask_name(status_list[cnt_next],&WSO_Name_next_Rev));
													printf("\n WSO_Name_next_Rev is :%s\n",WSO_Name_next_Rev);fflush(stdout);

													if ((tc_strcmp(WSO_Name_next_Rev,lcsAplRlzd)==0)||(tc_strcmp(WSO_Name_next_Rev,LcsStdWrkg)==0) || (tc_strcmp(WSO_Name_next_Rev,LcsStdRlzd)==0))
													{
														st_ok_Flg=1;
													}

												}
												if(st_ok_Flg==1)
												{
													GRM_find_relation_type("CMHasSolutionItem",&relation_type_task);
													GRM_list_primary_objects_only(latestrev,relation_type_task,&count_task,&PartTaskTags);
													if(count_task >0)
													{
														//NextRevFlagDml=0;
														for (cnt_tk=0;cnt_tk<count_task ;cnt_tk++ )
														{
															PartTskTag=PartTaskTags[cnt_tk];
															ITKCALL (TCTYPE_ask_object_type(PartTskTag,&itemTypeTag_class));
															ITKCALL (TCTYPE_ask_name(itemTypeTag_class,type_class));

															printf("\t  type_class ...%s\n", type_class);
															if(tc_strcmp(type_class,"T5_APLTaskRevision")==0)
															{
																ITKCALL(AOM_ask_value_string(PartTskTag, "item_id",&TaskId));
																printf("\n TaskId %s.....\n",TaskId);

																if(tc_strstr(TaskId,"APL")==NULL) continue;
																if(tc_strstr(TaskId,"_PR")!=NULL) continue;

																//tsk_Plant=subString(TaskId,14,strlen(TaskId));
																GetPlantForDMLORTask(TaskId,tsk_Plant);
																printf("\t  tsk_Plant after  ...%s\n", tsk_Plant);
																
																if(tc_strcmp(inp_Plant,tsk_Plant)==0)
																{
																	//ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type_1));
																	//if (tsk_dml_rel_type_1!=NULLTAG)
																	//{
																		//ITKCALL(GRM_list_primary_objects_only(PartTskTag,tsk_dml_rel_type_1,&count_dml_1,&DMLRevision_Prt));
																		//printf("\n\n\t\t DML Revision from Task : %d",count_dml_1);fflush(stdout);

																		//for (j=0;j<count_dml_1 ;j++ )
																		//{
																		//	ITKCALL(ITEM_rev_sequence_is_latest(DMLRevision_Prt[j],&is_latest_dml));
																		//	printf("\n\n\t\t is_latest_dml : %d\n",is_latest_dml);fflush(stdout);

																		//	if(is_latest_dml != true)
																		//	{
																			//	printf("\n\n\t\t is_latest_dml is not true .....\n");fflush(stdout);
																		//	}else
																			//{
																			//	DMLRevTag_Prt = DMLRevision_Prt[j];

																			//	ITKCALL (TCTYPE_ask_object_type(DMLRevTag_Prt,&itemTypeTag_Dml));
																			//	ITKCALL (TCTYPE_ask_name(itemTypeTag_Dml,type_dml));

																				//if(tc_strcmp(type_dml,"T5_APLDMLRevision")==0)
																				//{
																					//ITKCALL(WSOM_ask_release_status_list(DMLRevTag_Prt,&st_count_dml,&dml_status_list));
																					ITKCALL(WSOM_ask_release_status_list(PartTskTag,&st_count_dml,&dml_status_list));
																					for (dmlstlst = 0; dmlstlst < st_count_dml; dmlstlst++)
																					{
																						AOM_ask_name(dml_status_list[dmlstlst], &ReleaseStatusDML);
																						printf("\n ReleaseStatusDML %s \n",  ReleaseStatusDML);fflush(stdout);
																						if(tc_strcmp(ReleaseStatusDML,LcsStdRlzd)==0)
																						{
																							NextRevFlagDml=1;
																							break;
																						}
																					}																						
																				//}
																			//}
																		//}
																	//}
																}
															}
														}
													}

														if(NextRevFlagDml==0)
														{			

															attchdPart=NULL;
															attchdPart=(char *)MEM_alloc(1000);

															Temp=NULL;
															Temp=(char *)MEM_alloc(1000);												
															
															tc_strcpy(Temp,"\nNext Official Revision ");
															tc_strcat(Temp,Part_no);
															tc_strcat(Temp,",");
															tc_strcat(Temp,Revision);
															tc_strcat(Temp,",DR Status-");
															tc_strcat(Temp,part_DRStatus);
															tc_strcat(Temp," of part ");
															tc_strcat(Temp,Part_no);
															tc_strcat(Temp," exists with DR status > DR3. So, please release latest revision only.");															
															tc_strcpy(attchdPart,Temp);

															printf("%s",attchdPart); fflush(stdout);

															tc_strcat(SetStdRelErr,attchdPart);	
															cntFlag = 1;

														}

												}//st_ok_flg end
											}
								}
							}
							else
								{
									printf("\n Next revision Part DR status:%s, which is not greater than DR3",part_DRStatus);fflush(stdout);
								}
						}
						else
							{
								printf("\n No next revision of part");fflush(stdout);
							}
//						}
//						else
//						{
//							printf("\n Part DR status:%s",part_DRStatus);fflush(stdout);
//						}
					}
				}
				}
				else
				{
					printf("\n Control object not found for check execution");fflush(stdout);
				}

			

			return 0;

}

int GMDML_Part_Release_Check_STD(int PartCnt, tag_t* PartTags,char	***SetChildRelErr,int *icount,char* itemid)
{

	int				task_len			= 0;
	int				k,j					= 0;
	int				st_ok_Flg			= 0;
	int				cnt_next			= 0;
	int				count_task			= 0;
	int				cnt_tk				= 0;
	int				count_dml_1			= 0;
	int				st_count_dml		= 0;
	int				NextRevFlagDml		= 0;
	int				flagerror			= 0;
	int				st_count			= 0;
	int				dmlstlst			= 0;
	int				control_number_found= 0;
	int				cntCntrl			= 0;
	int				iCntl				= 0;
	int				status				= 0;

	//char			*inp_Plant			= NULL;
	//char			*tsk_Plant			= NULL;
	char			*Part_no			= NULL;
	char			*Desc_obj_lt_Rev	= NULL;
	char			*Desc_obj_Inp_Part	= NULL;
	char			*part_DRStatus		= NULL;
	char			*WSO_Name_next_Rev	= NULL;
	char			*ReleaseStatusDML	= NULL;
	char			*TaskId				= NULL;
	char			*Revision			= NULL;
	char			*Temp				= NULL;
	char			*attchdPart			= NULL;
	char			*SubSyscd			= NULL;

	char			type_class[TCTYPE_name_size_c+1];
	char			type_dml[TCTYPE_name_size_c+1];

	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;

	tag_t			AssyTag				= NULLTAG;
	tag_t			master				= NULLTAG;
	tag_t			latestrev			= NULLTAG;
	tag_t			relation_type_task	= NULLTAG;
	tag_t			PartTskTag			= NULLTAG;
	tag_t			itemTypeTag_class	= NULLTAG;
	tag_t			tsk_dml_rel_type_1	= NULLTAG;
	tag_t			DMLRevTag_Prt		= NULLTAG;
	tag_t			itemTypeTag_Dml		= NULLTAG;

	tag_t*			status_list			= NULLTAG;
	tag_t*			dml_status_list		= NULLTAG;
	tag_t*			PartTaskTags		= NULLTAG;
	tag_t*			DMLRevision_Prt		= NULLTAG;
	tag_t*			list_of_WSO_cntrl_tags= NULLTAG;
	
	int countstmnt=0;

	char LcsStdWrkg[40];
	char LcsStdRlzd[40];
	char lcsAplRlzd[40];
	char inp_Plant[40];
	char tsk_Plant[40];

	WSO_search_criteria_t  	criteria_Gcontrol;

	logical			is_latest_dml;

				printf("\n ############Inside GMDML_Part_Release_Check_STD : Next revision DML with STDSI Check###########");fflush(stdout);
				
				task_len=0;
				task_len=strlen(itemid);
				printf("\t  task_len ...%d\n", task_len);// length task
				GetPlantForDMLORTask(itemid,inp_Plant);
				//inp_Plant=subString(itemid,14,task_len);
				printf("\t  inp_Plant after  ...%s\n", inp_Plant);


				// Control Object Base 

					int cntt=0;
					int FlagGot=0;

					tag_t			CntrlTag		= NULLTAG;

					tag_t query1 = NULLTAG;
					int n_entries1=2;
					int n_found1=0;
  				    tag_t	*CntrlObjs	= NULLTAG;

					logical	delInd	= false;

					char *Info1 	   = NULL;

					char
					 *qry_entry[2] = {"SUBSYSCD", "SYSCD"},
					 *qry_vall[2] =  {"TODR", "LIVE"};

					//del indicator

					ITKCALL(QRY_find("ControlObjQry", &query1));
					printf("\n After fins qryyy-- ");fflush(stdout);
					ITKCALL(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
					printf("\n n_found1: %d", n_found1);fflush(stdout);

					if(n_found1>0)
					{
						for (cntt = 0; cntt < n_found1; cntt++)
						{
							CntrlTag=NULLTAG;
							CntrlTag=CntrlObjs[cntt];

							AOM_ask_value_string( CntrlTag, "t5_Userinfo1", &Info1);
							printf("\n Info1: %s\n",Info1);fflush(stdout);

							AOM_ask_value_logical( CntrlTag, "t5_DelInd", &delInd);
							printf("\n delInd: %d\n",delInd);fflush(stdout);

							if(tc_strstr(Info1,inp_Plant)!=NULL &&  delInd==false)
							{
								printf("\n inside got plant .. ");fflush(stdout);
								FlagGot=1;
								break;
							}
				
						}

					}
					printf("\n FlagGot: %d", FlagGot);fflush(stdout);
				///

			 if(FlagGot==1)
			  {
				char  ItemIDCpy[40];
				tc_strcpy(ItemIDCpy,itemid);
				GetPlantWiseRelStat(ItemIDCpy,LcsStdWrkg,LcsStdRlzd);
				printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
				printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);				
	
				//###########################################################//

					for (k=0;k<PartCnt ;k++ )
					{				
						printf("\n\n\t\t for k =:%d",k);fflush(stdout);

						AssyTag=NULLTAG;
						AssyTag=PartTags[k];

						Part_no=NULL;
						ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
						printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);
	
						Revision=NULL;
						ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Revision));
						printf("\n\n\t\t Revision  is :%s",Revision);	fflush(stdout);

						//skip prev rev //
						 char*			SkipPrevRevSTD				= NULL;
						 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
						 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
						 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
					
							if(tc_strlen(SkipPrevRevSTD)>0)
							{
								printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
								continue;
							}
						//skip prev rev//

									ITKCALL(WSOM_ask_release_status_list(AssyTag,&st_count,&status_list));
									printf("\n st_count :%d is\n",st_count);fflush(stdout);

									if(st_count>0)
											{
												st_ok_Flg=0;
												for (cnt_next=0;cnt_next< st_count;cnt_next++ )
												{
													WSO_Name_next_Rev=NULL;
													ITKCALL(AOM_ask_name(status_list[cnt_next],&WSO_Name_next_Rev));
													printf("\n WSO_Name_next_Rev is :%s\n",WSO_Name_next_Rev);fflush(stdout);

													if ((tc_strcmp(WSO_Name_next_Rev,LcsStdRlzd)==0))
													{
														st_ok_Flg=1;
													}

												}
												
												if(st_ok_Flg==0)
												{														
													attchdPart=NULL;
													attchdPart=(char *)MEM_alloc(1000);

													Temp=NULL;
													Temp=(char *)MEM_alloc(1000);												
																										
													tc_strcpy(Temp,"\n");
													tc_strcat(Temp,Part_no);
													tc_strcat(Temp,",");
													tc_strcat(Temp,Revision);
																											
													tc_strcpy(attchdPart,Temp);

													printf("attchdPart: %s",attchdPart); fflush(stdout);

													if(countstmnt==0)
													{
														setAddStr(icount,SetChildRelErr,"\nBelow mention PartNumbers are not Release from STDSI, Please release through AMDML(created for GM DML)/Basic ERC DML:");
														countstmnt++;
														cntFlag = 1;
													}
													setAddStr(icount,SetChildRelErr,attchdPart);
													
												}

										  }//if(st_count>0)
							}
						} //if(FlagGot==1)

			return 0;

}




//##############################################################################################################################################//
//This validation will ensure the release of previous revisions of part in DML
//1. Previous revision of part is released from same plant DML
//2. Previous revision of part is contained in same plant DML
//3. Previous revision of part is contanied in same plant SMDML-Rework point-Logic to carry forward previous revision changes into current revision
//###############################################################################################################################################//

int Prev_Rev_Checks(int PartCnt, tag_t* PartTags,char* SetStdRelErr,char* itemid,char* ProjectCode)
{

	int				task_len			= 0;
	int				k,j					= 0;
	int				st_ok_Flg			= 0;
	int				cnt_next			= 0;
	int				count_task			= 0;
	int				cnt_tk				= 0;
	int				count_dml_1			= 0;
	int				st_count_dml		= 0;
	int				NextRevFlagDml		= 0;
	int				flagerror			= 0;
	int				st_count			= 0;
	int				dmlstlst			= 0;
	int				Pre_count			= 0;
	int				Precnt				= 0;
	int				precount_task		= 0;
	int				preEpaFlg			= 0;
	int				stlst				= 0;
	int				st_epacount			= 0;
	int				epaRlzFlg			= 0;
	int				smRlzFlg			= 0;
	int				prevRevinEPA		= 0;
	int				precount_task1		= 0;
	int				tskRlzFlg			= 0;
	int				st_prt				= 0;
	int				prtRlzFlg			= 0;
	int				count1				= 0;
	int				st_dmlCnt			= 0;
	int				dmlRlzFlg			= 0;
	int				FlagPrevPartRlzd	= 0;

	//char			*inp_Plant			= NULL;
	char			*inp_PlntLstLtr		= NULL;
	char			*epa_Plant			= NULL;
	char			*Part_no			= NULL;
	char			*Desc_obj_lt_Rev	= NULL;
	char			*Desc_obj_Inp_Part	= NULL;
	char			*part_DRStatus		= NULL;
	char			*WSO_Name_next_Rev	= NULL;
	char			*ReleaseStatusDML	= NULL;
	char			*Revision			= NULL;
	char			*pre_revision		= NULL;
	char			*itemidpre			= NULL;
	char			*epaTaskId			= NULL;
	char			*PreTaskId			= NULL;
	char			*PreTaskId1			= NULL;
	char			*Preepa_Plant		= NULL;
	char			*PrevRevEPASet		= NULL;
	char			*ReleaseStatusepa	= NULL;
	char			*Part_Rev			= NULL;
	//char			*Pretask_Plant		= NULL;
	char			*Pretask_Plant1		= NULL;
	char			*dmlId				= NULL;
	char			*ClosureDate		= NULL;
	char			*ReleaseStatuspart	= NULL;
	char			*DmlName			= NULL;
	char			*dml_Plant			= NULL;
	char			*ClosureDateDML		= NULL;
	char			*ReleaseStatusdml	= NULL;
	char			*PrevRevDMLSet		= NULL;
	char			*Cur_revision		= NULL;

	char			type_class[TCTYPE_name_size_c+1];
	char			type_dml[TCTYPE_name_size_c+1];
	char			Pretype_class[TCTYPE_name_size_c+1];
	char			Pretype_class1[TCTYPE_name_size_c+1];
	char			Pretype_class2[TCTYPE_name_size_c+1];

	tag_t			AssyTag				= NULLTAG;
	tag_t			master				= NULLTAG;
	tag_t			latestrev			= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			relation_type_task	= NULLTAG;
	tag_t			PartepaTag			= NULLTAG;
	tag_t			itemTypeTag_class	= NULLTAG;
	tag_t			tsk_dml_rel_type_1	= NULLTAG;
	tag_t			DMLRevTag_Prt		= NULLTAG;
	tag_t			AssyPreTag			= NULLTAG;
	tag_t			PreParttskTag		= NULLTAG;
	tag_t			PreitemTypeTag_class= NULLTAG;
	tag_t			PreitemTypeTag_class1= NULLTAG;
	tag_t			PreitemTypeTag_class2= NULLTAG;
	tag_t			PreParttskTag1		= NULLTAG;
	tag_t			tsk_dml_rel_type	= NULLTAG;
	tag_t			DMLRevTag			= NULLTAG;
	tag_t*			status_listDml		= NULLTAG;

	tag_t*			status_list			= NULLTAG;
	tag_t*			dml_status_list		= NULLTAG;
	tag_t*			PartEpaTags			= NULLTAG;
	tag_t*			DMLRevision_Prt		= NULLTAG;
	tag_t*			PartPreTags			= NULLTAG;
	tag_t*			PrePartTskTags		= NULLTAG;
	tag_t*			PrePartTskTags1		= NULLTAG;
	tag_t*			epa_status_list		= NULLTAG;
	tag_t*			prt_status_list		= NULLTAG;
	tag_t*			DMLRevision			= NULLTAG;

	char LcsStdWrkg[40];
	char LcsStdRlzd[40];
	char inp_Plant[40];
	char Pretask_Plant[40];

	logical			CurrentRevInEPA2;
	logical			is_latest;

	if (!PrevRevEPASet) MEM_free(PrevRevEPASet);
	PrevRevEPASet=(char *)MEM_alloc(2000);
	tc_strcpy(PrevRevEPASet," ");
	
	if (!PrevRevDMLSet) MEM_free(PrevRevDMLSet);
	PrevRevDMLSet=(char *)MEM_alloc(2000);
	tc_strcpy(PrevRevDMLSet," ");

	printf("\n\n ##############Inside Previous revision checks##############");fflush(stdout);

    char  ItemIDCpy[40];
    tc_strcpy(ItemIDCpy,itemid);
	GetPlantWiseRelStat(ItemIDCpy,LcsStdWrkg,LcsStdRlzd);
	printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
	printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);

				task_len=0;
				task_len=strlen(itemid);
				printf("\t  TaskName is :  %s\n", itemid);fflush(stdout);
				printf("\t  task_len ...%d\n", task_len);fflush(stdout);// length task
				//inp_Plant=subString(itemid,14,task_len);
				GetPlantForDMLORTask(itemid,inp_Plant);	
				printf("\t  inp_Plant after  ...%s\n", inp_Plant);

				inp_PlntLstLtr=subString(itemid,17,task_len);
				printf("\t  inp_PlntLstLtr after  ...%s\n", inp_PlntLstLtr);
				printf("\t  input ProjectCode  ...%s\n", ProjectCode);
				
				for (k=0;k<PartCnt ;k++ )
				{					
					printf("\n\n\t\t Prev_Rev_Checks:for k_1 =:%d",k);fflush(stdout);
					AssyTag=PartTags[k];
					AssyPreTag=NULLTAG;

					ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
					printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyTag, "item_revision_id",&Cur_revision));
					printf("\n Cur_revision %s.....\n",Cur_revision);

					//Added By Dhanashri for skip prev rev UATZ1.42//
						 char*			SkipPrevRevSTD				= NULL;
						 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
						 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
						printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
					
							//if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
							if(tc_strlen(SkipPrevRevSTD)>0)
							{
								printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
								continue;
							}
					//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//


					//Finding whether current revision is in EPA or not//
					GRM_find_relation_type("CMHasSolutionItem",&relation_type_task);
					GRM_list_primary_objects_only(AssyTag,relation_type_task,&count_task,&PartEpaTags);
					if(count_task >0)
					{						
						for (cnt_tk=0;cnt_tk<count_task ;cnt_tk++ )
						{
							PartepaTag=PartEpaTags[cnt_tk];
							ITKCALL (TCTYPE_ask_object_type(PartepaTag,&itemTypeTag_class));
							ITKCALL (TCTYPE_ask_name(itemTypeTag_class,type_class));

							printf("\t  type_class ...%s\n", type_class);
							if(tc_strcmp(type_class,"T5_EPATaskRevision")==0)
							{
								ITKCALL(AOM_ask_value_string(PartepaTag, "item_id",&epaTaskId));
								printf("\n epaTaskId %s.....\n",epaTaskId);

								epa_Plant=subString(epaTaskId,22,strlen(epaTaskId));
								printf("\t  epa_Plant after  ...%s\n", epa_Plant);
								
								if(tc_strcmp(inp_Plant,epa_Plant)==0)
								{
									CurrentRevInEPA2=true;
								}
							}
						}
					}
					//#################################################//
					
//					GRM_find_relation_type("IMAN_based_on",&relation_type);
//					GRM_list_secondary_objects_only(AssyTag,relation_type,&Pre_count,&PartPreTags);
//					printf("\n\n\t\tPrev_Rev_Checks Pre_count: %d",Pre_count);fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev));
					printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);

					if(strstr(Part_Rev,"NR"))
					{
						printf("\n Previous revision function can not be called as current revision has NR revision");fflush(stdout);
					}
					else
					{
						printf("\n Calling function to get Previous revision ");fflush(stdout);
						tm_fnd_Prev_Official_Revision(Part_no,AssyTag,&AssyPreTag);//TZ 1.43
					}				
										
					//if(Pre_count >0)
					if(AssyPreTag)
					{
					prevRevinEPA=0;
					prtRlzFlg=0;
					dmlRlzFlg=0;
					FlagPrevPartRlzd=0;
					//AssyPreTag=PartPreTags[0]; --TZ1.43
					ITKCALL(AOM_ask_value_string(AssyPreTag, "item_id",&itemidpre));
					printf("\n itemidpre %s.....\n",itemidpre);

					ITKCALL(AOM_ask_value_string(AssyPreTag, "item_revision_id",&pre_revision));
					printf("\n pre_revision %s.....\n",pre_revision);

					//Added By Dhanashri for skip prev rev UATZ1.42//
					 char*			SkipPrevRevSTD1				= NULL;
					 ITKCALL(AOM_ask_value_string(AssyPreTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD1));
					 printf("\n\n\t\t SkipPrevRevSTD1  is :%s",SkipPrevRevSTD1);	fflush(stdout);
					 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD1)  is :%d",tc_strlen(SkipPrevRevSTD1));	fflush(stdout);
					
							//if(tc_strcmp(SkipPrevRevSTD1,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD1,"") !=0)
							if(tc_strlen(SkipPrevRevSTD1)>0)
							{
								printf("\n\n\t\t Inside SkipPrevRevSTD1 not null...");	fflush(stdout);
								continue;
							}
					//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

					ITKCALL(AOM_ask_value_string(AssyPreTag, "t5_PartStatus",&part_DRStatus));
					printf("\n part_DRStatus %s.....\n",part_DRStatus);

					ITKCALL(WSOM_ask_release_status_list(AssyPreTag,&st_prt,&prt_status_list));
					for (stlst = 0; stlst < st_prt; stlst++)
					{
						AOM_ask_name(prt_status_list[stlst], &ReleaseStatuspart);
						printf("\n ReleaseStatuspart %s \n",  ReleaseStatuspart);fflush(stdout);
						if(tc_strcmp(ReleaseStatuspart,LcsStdRlzd)==0)
						{
							prtRlzFlg=1;
						}
					}

					
					// CODE ADDED BY DHANASHRI //
					int cntt=0;
					int FlagGotProj=0;

					tag_t			CntrlTag		= NULLTAG;

					tag_t query1 = NULLTAG;
					int n_entries1=2;
					int n_found1=0;
  				    tag_t	*CntrlObjs	= NULLTAG;

					char *Info1 	   = NULL;

					char
					 *qry_entry[2] = {"SUBSYSCD", "SYSCD"},
					 *qry_vall[2] =  {"PROJ", "PREVREV"};

					ITKCALL(QRY_find("ControlObjQry", &query1));
					printf("\n After fins qryyy-- ");fflush(stdout);
					ITKCALL(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
					printf("\n n_found1: %d", n_found1);fflush(stdout);

					if(n_found1>0)
					{
						for (cntt = 0; cntt < n_found1; cntt++)
						{
							CntrlTag=NULLTAG;
							CntrlTag=CntrlObjs[cntt];

							AOM_ask_value_string( CntrlTag, "t5_Userinfo1", &Info1);
							printf("\n Info1: %s\n",Info1);fflush(stdout);

							if(tc_strcmp(Info1,ProjectCode)==0)
							{
								FlagGotProj=1;
								break;
							}
				
						}

					}

					printf("\n FlagGotProj: %d", FlagGotProj);fflush(stdout);


					int cnttSkpRev=0;
					int FlagSkpRev=0;

					tag_t			CntrlTagSkpRev		= NULLTAG;

					tag_t query1SkpRev = NULLTAG;
					int n_entries1SkpRev=2;
					int n_found1SkpRev=0;
  				    tag_t	*CntrlObjsSkpRev	= NULLTAG;

					char *Info1SkpRev 	   = NULL;

					char
					 *qry_entrySkpRev[2] = {"SUBSYSCD", "SYSCD"},
					 *qry_vallSkpRev[2] =  {"SKIP", "PREVREV"};

					ITKCALL(QRY_find("ControlObjQry", &query1SkpRev));
					printf("\n After fins qryyy-- ");fflush(stdout);
					ITKCALL(QRY_execute(query1SkpRev, n_entries1SkpRev, qry_entrySkpRev, qry_vallSkpRev, &n_found1SkpRev, &CntrlObjsSkpRev));
					printf("\n n_found1SkpRev: %d", n_found1SkpRev);fflush(stdout);

					if(n_found1SkpRev>0)
					{
						for (cnttSkpRev = 0; cnttSkpRev < n_found1SkpRev; cnttSkpRev++)
						{
							CntrlTagSkpRev=NULLTAG;
							CntrlTagSkpRev=CntrlObjsSkpRev[cnttSkpRev];

							AOM_ask_value_string( CntrlTagSkpRev, "t5_Userinfo1", &Info1SkpRev);
							printf("\n itemid: %s\n",itemid);fflush(stdout);
							printf("\n Info1SkpRev: %s\n",Info1SkpRev);fflush(stdout);

							if(tc_strstr(itemid,Info1SkpRev)!=NULL)
							{
								FlagSkpRev=1;
								break;
							}
				
						}

					}

					printf("\n FlagSkpRev: %d", FlagSkpRev);fflush(stdout);

					// END OF CODE ADDED BY DHANASHRI //


					if(strlen(part_DRStatus)>0)
					{
						if(FlagGotProj==1)
						{
							printf("\n Inside FlagGotProj==1.. \n");fflush(stdout);
							if( (tc_strcmp(part_DRStatus,"DR0")==0) || (tc_strcmp(part_DRStatus,"DR1")==0) || (tc_strcmp(part_DRStatus,"DR2")==0) || (tc_strcmp(part_DRStatus,"AR0")==0) || (tc_strcmp(part_DRStatus,"AR1")==0) || (tc_strcmp(part_DRStatus,"AR2")==0) || (tc_strcmp(part_DRStatus,"NA")==0) )
							{
								continue;
							}
						}
						else
						{
							if( (tc_strcmp(part_DRStatus,"DR0")==0) || (tc_strcmp(part_DRStatus,"DR1")==0) || (tc_strcmp(part_DRStatus,"DR2")==0) || (tc_strcmp(part_DRStatus,"DR3")==0) || (tc_strcmp(part_DRStatus,"AR0")==0) || (tc_strcmp(part_DRStatus,"AR1")==0) || (tc_strcmp(part_DRStatus,"AR2")==0) || (tc_strcmp(part_DRStatus,"AR3")==0) || (tc_strcmp(part_DRStatus,"NA")==0) )
							{
								continue;
							}
						}
					}

					if(CurrentRevInEPA2!=true)
					{
						printf("\n Current revision is not in epa of same plant, checking whether previous revision is in epa of same plant");fflush(stdout);						
						
						epaRlzFlg=0;
						PrePartTskTags=NULLTAG;
						GRM_list_primary_objects_only(AssyPreTag,relation_type_task,&precount_task,&PrePartTskTags);
						printf("\n precount_task:%d",precount_task);fflush(stdout);
						if(precount_task >0)
						{							
							for (Precnt=0;Precnt<precount_task ;Precnt++ )
							{
								PreParttskTag=NULLTAG;
								printf("\n For count:%d",Precnt);fflush(stdout);
								PreParttskTag=PrePartTskTags[Precnt];
								PreitemTypeTag_class=NULLTAG;
								ITKCALL (TCTYPE_ask_object_type(PreParttskTag,&PreitemTypeTag_class));
								ITKCALL (TCTYPE_ask_name(PreitemTypeTag_class,Pretype_class));

								printf("\n Pretype_class ...%s\n", Pretype_class);

								PreTaskId=NULL;
								ITKCALL(AOM_ask_value_string(PreParttskTag, "item_id",&PreTaskId));
								printf("\n PreTaskId %s.....\n",PreTaskId);

								if(tc_strcmp(Pretype_class,"T5_EPATaskRevision")==0)
								{								

									Preepa_Plant=subString(PreTaskId,22,strlen(PreTaskId));
									printf("\t  Preepa_Plant after  ...%s\n", Preepa_Plant);

									if(tc_strcmp(inp_Plant,Preepa_Plant)==0)
									{

										ITKCALL(WSOM_ask_release_status_list(PreParttskTag,&st_epacount,&epa_status_list));
										for (stlst = 0; stlst < st_epacount; stlst++)
										{
											AOM_ask_name(epa_status_list[stlst], &ReleaseStatusepa);
											printf("\n ReleaseStatusepa %s \n",  ReleaseStatusepa);fflush(stdout);
											if(tc_strcmp(ReleaseStatusepa,LcsStdRlzd)!=0 && (stlst==st_epacount-1) )
											{												
												prevRevinEPA=1;
												/*
												if(preEpaFlg==0)
												{
													 tc_strcat(PrevRevEPASet,"\nPlease release this EPA Task from STDS1.\n");
													 tc_strcat(PrevRevEPASet,"OR\n");
													 tc_strcat(PrevRevEPASet,"Put the current revision of part under same EPA or new EPA.");
													 preEpaFlg=1;
												}
												*/
												 tc_strcat(PrevRevEPASet,"\nBelow Previous Revisions are skipped for release from STDSI:");	
												 tc_strcat(PrevRevEPASet,"\n");
												 tc_strcat(PrevRevEPASet,"Previous Revision (");
												 tc_strcat(PrevRevEPASet,pre_revision);
												 tc_strcat(PrevRevEPASet,") Of Part ");
												 tc_strcat(PrevRevEPASet,Part_no);
												 tc_strcat(PrevRevEPASet," is contained in EPA Task ");
												 tc_strcat(PrevRevEPASet,PreTaskId);
												 tc_strcat(PrevRevEPASet,"\n");	
												 

												 //Added By Dhanashri Skip Previous Revision UATZ1.42//

												 /*
												 1. Softcheck for this check (pending)
												 2. Set SkipPrevRev on prev rev tag till it get the released prev rev
												 */
												 if(FlagSkpRev==1)
												 {
												  ITKCALL(AOM_lock(AssyPreTag));
												  ITKCALL(AOM_set_value_string(AssyPreTag,"t5_SkipPrevRevSTD",Cur_revision));
												  ITKCALL(AOM_save(AssyPreTag) );
												  ITKCALL(AOM_unlock(AssyPreTag));
	
												  //get the prev rev of AssyPreTag and set 	t5_SkipPrevRevSTD if its not released from plant.
													tag_t			AssyPreTagCpy			= NULLTAG;
												    AssyPreTagCpy=AssyPreTag;

												   FindPrevRevLabel:
													printf("\n inside FindPrevRevLabel ");fflush(stdout);
												  
												  	const char *qry_entries[2];//Multiple Item Queried Error
													const char *qry_values[2];//Multiple Item Queried Error
													int n_tags_found=0;
													tag_t	*itemclassp	= NULLTAG;
													tag_t item = NULLTAG;
													int Item_count      =  0;
													tag_t	*rev_list				= NULL;

													int PreRevFlag=0;
													int RevFlag=0;
													int ii=0;
													int LCSi=0;

													char			*prev_rev		= NULL;
													char			*Part_rev_Id		= NULL;
													char			*Part_Rev_copy		= NULL;
													char			*RevOnly		= NULL;
													char			*PreRevOnly		= NULL;
													char*			class_name=NULL;
													char	*Part_clr_ind		=	NULL;

													int stat_count=0;
													tag_t*			stat_list;
													int FlagPrevRevRlzd=0;
													
												   ITKCALL(AOM_ask_value_string(AssyPreTagCpy, "item_revision_id",&prev_rev));
												   ITKCALL(AOM_ask_value_string(AssyPreTagCpy, "item_revision_id",&Part_Rev_copy));
												   printf("\n prev_rev %s.....\n",prev_rev);fflush(stdout);
												   printf("\n Part_Rev_copy %s.....\n",Part_Rev_copy);fflush(stdout);

												   Part_clr_ind	=	NULL;
													ITKCALL(AOM_ask_value_string(AssyPreTagCpy,"t5_ColourInd",&Part_clr_ind));
													printf("\n Part_clr_ind %s.....\n",Part_clr_ind);fflush(stdout);
													
													qry_entries[0] ="item_id";
													qry_entries[1] ="object_type";//Multiple Item Queried Error
													qry_values[0] = Part_no;
													if (tc_strcmp(Part_clr_ind,"C")==0)
													{
														qry_values[1] = "T5_ClrPart";//Multiple Item Queried Error Hemal
													}
													else
													{
														//qry_values[1] = "Design";//Multiple Item Queried Error Hemal
														//Handle the different design child class.
														char	*designBORev		=	NULL;
														char	*designBO			=	NULL;
														//tag_t	AssyTag			=	NULLTAG;
														//AssyTag=PartTags[k];
														printf("\nBefore getDesignType");fflush(stdout);
														getDesignType(AssyPreTagCpy, &designBORev,&designBO);
														printf("\nAfter getDesignType : %s",designBO);fflush(stdout);
														qry_values[1] = designBO;


													}//Multiple Item Queried Error
													//ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclassp);
													ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found, &itemclassp);//Multiple Item Queried Error
													
													item = itemclassp[0];

													ITKCALL(ITEM_list_all_revs (item, &Item_count, &rev_list));
													printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);

													if(Item_count > 0)
													{
														RevFlag = 0;
														PreRevFlag = 0;
														for(ii=Item_count-1;ii>=0;ii--)
														{
														   RevOnly = NULL;
														   PreRevOnly = NULL;
														   ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));
															printf("\n Part_rev_Id: %s\n",Part_rev_Id);fflush(stdout);
															if(tc_strcmp(prev_rev,Part_rev_Id)==0)
															{
																RevFlag = 1;
															}
															printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
															if(RevFlag == 1)
															{
															   RevOnly= strtok( Part_Rev_copy, ";" );
															   PreRevOnly= strtok( Part_rev_Id, ";" );
															   printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
															   printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
															   if(tc_strcmp(RevOnly,PreRevOnly)!=0)
																{
																  PreRevFlag = 1;
																}
															}
															printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
															if(PreRevFlag == 1)
															{
																//set t5SkipPrevRev if not released from plant
																printf("\n check whether part released from plant");fflush(stdout);
																ITKCALL(WSOM_ask_release_status_list(rev_list[ii],&stat_count,&stat_list));
																if(stat_count == 0)
																{
																	printf("\n NO LCS Found for part : %d\n",stat_count);fflush(stdout);
																	//break;
																}
																else
																{
																	for (LCSi=0;LCSi<stat_count ;LCSi++ )
																	{
																		ITKCALL(AOM_ask_value_string(stat_list[LCSi],"object_name",&class_name));
																		printf("\n class_name: %s\n",class_name);fflush(stdout);
																		
																		if(tc_strcmp(class_name,LcsStdRlzd)==0)
																		{
																			FlagPrevRevRlzd=1;
																			break;
																		}
																	}
																	printf("\n FlagPrevRevRlzd : %d\n",FlagPrevRevRlzd);fflush(stdout);
																   
																}

																if(FlagPrevRevRlzd==0)
																{
																	  printf("\n set t5SkipPrevRev and goto FindPrevRevLabel");fflush(stdout);
																	  ITKCALL(AOM_lock(rev_list[ii]));
																	  ITKCALL(AOM_set_value_string(rev_list[ii],"t5_SkipPrevRevSTD",Cur_revision));
																	  ITKCALL(AOM_save(rev_list[ii]) );
																	  ITKCALL(AOM_unlock(rev_list[ii]));

																	  AssyPreTagCpy=rev_list[ii];
																	  goto FindPrevRevLabel;
																}
																else
																{
																	printf("\n Found Release revision Part_rev_Id: [%s]\n",Part_rev_Id);fflush(stdout);
																	break;
																}

															} // if(PreRevFlag == 1)
														} // for(ii=Item_count-1;ii>=0;ii--)
													} //if(Item_count > 0)
											      } // if(FlagSkpRev==1)
												 //End of Code Added By Dhanashri Skip Previous Revision UATZ1.42//
											}
										}
										break;
									}									
									
								}
							}						

						}
					}

						if(CurrentRevInEPA2!=true)
						{
							printf("\n Current revision is not in epa of same plant, checking whether previous revision is in SMDML of same plant");fflush(stdout);						
							
							epaRlzFlg=0;
							PrePartTskTags=NULLTAG;
							GRM_list_primary_objects_only(AssyPreTag,relation_type_task,&precount_task,&PrePartTskTags);
							if(precount_task >0)
							{							
								for (Precnt=0;Precnt<precount_task ;Precnt++ )
								{
									PreParttskTag=NULLTAG;
									PreParttskTag=PrePartTskTags[Precnt];
									ITKCALL (TCTYPE_ask_object_type(PreParttskTag,&PreitemTypeTag_class2));
									ITKCALL (TCTYPE_ask_name(PreitemTypeTag_class2,Pretype_class2));

									printf("\t  Pretype_class2 ...%s\n", Pretype_class2);

									ITKCALL(AOM_ask_value_string(PreParttskTag, "item_id",&PreTaskId));
									printf("\n PreTaskId %s.....\n",PreTaskId);


									if(tc_strcmp(Pretype_class2,"T5_APLTaskRevision")==0)
									{

										//Pretask_Plant=subString(PreTaskId,17,strlen(PreTaskId));
										GetPlantForDMLORTask(PreTaskId,Pretask_Plant);	
										printf("\t  Pretask_Plant after  ...%s\n", Pretask_Plant);
										
										dmlId=subString(PreTaskId,2,2);
										printf("\n dmlId:%s",dmlId);fflush(stdout);

										if(tc_strcmp(dmlId,"SM")==0 && (tc_strcmp(inp_PlntLstLtr,Pretask_Plant)==0))
										{

											ITKCALL(WSOM_ask_release_status_list(PreParttskTag,&st_epacount,&epa_status_list));
											for (stlst = 0; stlst < st_epacount; stlst++)
											{
												AOM_ask_name(epa_status_list[stlst], &ReleaseStatusepa);
												printf("\n ReleaseStatusepa %s \n",  ReleaseStatusepa);fflush(stdout);
												if(tc_strcmp(ReleaseStatusepa,LcsStdRlzd)!=0 && (stlst==st_epacount-1))
												{
													//smRlzFlg=1;
													///break;
													printf("\n Previous revision of part is contanied in SMDML which is not stdsi released, carry forward previous revision changes into current revision");fflush(stdout);
													//#############Logic to carry forward previous revision changes#############//



													//##########################################################################//
												}
											}
										}
									}
								}							
								
							}
						}

						if(prevRevinEPA==0)
						{
							///////START OF CODE COMMENTED BY PRITI//AS NO NEED TO CHECK PREVIOUS REVISION DML & TASKFOR RELEASE STATUS//////////////////
//							GRM_list_primary_objects_only(AssyPreTag,relation_type_task,&precount_task1,&PrePartTskTags1);
//							tskRlzFlg=0;
//							if(precount_task1 >0)
//							{							
//								for (Precnt=0;Precnt<precount_task1 ;Precnt++ )
//								{
//									PreParttskTag1=PrePartTskTags1[Precnt];
//									ITKCALL (TCTYPE_ask_object_type(PreParttskTag1,&PreitemTypeTag_class1));
//									ITKCALL (TCTYPE_ask_name(PreitemTypeTag_class1,Pretype_class1));
//
//									printf("\t  Pretype_class1 ...%s\n", Pretype_class1);
//
//									ITKCALL(AOM_ask_value_string(PreParttskTag1, "item_id",&PreTaskId1));
//									printf("\n PreTaskId1 %s.....\n",PreTaskId1);
//
//
//									if(tc_strcmp(Pretype_class1,"T5_APLTaskRevision")==0)
//									{
//
//										Pretask_Plant1=subString(PreTaskId1,17,strlen(PreTaskId1));
//										printf("\t  Pretask_Plant1 after  ...%s\n", Pretask_Plant1);
//
//										ITKCALL(AOM_UIF_ask_value(PreParttskTag1,"date_released",&ClosureDate));
//										printf("\n ClosureDate : %s\n",ClosureDate);fflush(stdout);
//
//										if(tc_strcmp(Pretask_Plant1,inp_Plant)==0)
//										{
//											ITKCALL(WSOM_ask_release_status_list(PreParttskTag1,&st_count,&status_list));
//											for (stlst = 0; stlst < st_count; stlst++)
//											{
//												AOM_ask_name(status_list[stlst], &ReleaseStatusepa);
//												printf("\n ReleaseStatusepa %s \n",  ReleaseStatusepa);fflush(stdout);
//												if(tc_strcmp(ReleaseStatusepa,LcsStdRlzd)==0)
//												{
//													tskRlzFlg=1;
//												}
//											}
//										}
//
//										if( (tskRlzFlg==1) && (strlen(ClosureDate)>2) && (prtRlzFlg==1))
//										{
//											FlagPrevPartRlzd=1;
//											break;
//										}
//										
//									}
//								}
//							}
//
//										//#####Check wthether DML is released or not############//
//										if(precount_task1 >0)
//										{	
//											for (Precnt=0;Precnt<precount_task1 ;Precnt++ )
//											{
//												PreParttskTag1=PrePartTskTags1[Precnt];
//												ITKCALL (TCTYPE_ask_object_type(PreParttskTag1,&PreitemTypeTag_class1));
//												ITKCALL (TCTYPE_ask_name(PreitemTypeTag_class1,Pretype_class1));
//
//												printf("\t  Pretype_class1 ...%s\n", Pretype_class1);
//
//												ITKCALL(AOM_ask_value_string(PreParttskTag1, "item_id",&PreTaskId1));
//												printf("\n PreTaskId1 %s.....\n",PreTaskId1);
//
//
//												if(tc_strcmp(Pretype_class1,"T5_APLTaskRevision")==0)
//												{
//													ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
//													if (tsk_dml_rel_type!=NULLTAG)
//													 {
//
//														ITKCALL(GRM_list_primary_objects_only(PreParttskTag1,tsk_dml_rel_type,&count1,&DMLRevision));
//														printf("\n\n\t\t DML Revision from Task : %d",count1);fflush(stdout);		//task to dml
//
//														for (j=0;j<count1 ;j++ )
//														{
//															ITKCALL(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
//															printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);
//
//															if(is_latest != true)
//															{
//																printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
//															}else
//															{
//																DMLRevTag = DMLRevision[j];//DML
//
//																ITKCALL(AOM_ask_value_string(DMLRevTag, "item_id",&DmlName));
//																printf("\n DmlName %s.....\n",DmlName);//previous revision's DML																
//
//																dml_Plant=subString(DmlName,11,strlen(DmlName));
//																printf("\n dml_Plant is : %s\n",dml_Plant);fflush(stdout);
//
//																if(tc_strcmp(inp_Plant,dml_Plant)==0)
//																{
//																	printf("\n inside plant check is :\n");fflush(stdout);
//
//																	ITKCALL(AOM_UIF_ask_value(DMLRevTag,"date_released",&ClosureDateDML));
//																	printf("\n ClosureDateDML : %s\n",ClosureDateDML);fflush(stdout);
//																	if(strlen(ClosureDateDML)>2) 
//																	{
//																		ITKCALL(WSOM_ask_release_status_list(DMLRevTag,&st_dmlCnt,&status_listDml));
//																		for (stlst = 0; stlst < st_dmlCnt; stlst++)
//																		{
//																			AOM_ask_name(status_listDml[stlst], &ReleaseStatusdml);
//																			printf("\n ReleaseStatusdml %s \n",  ReleaseStatusdml);fflush(stdout);
//																			if( (tc_strcmp(ReleaseStatusdml,LcsStdRlzd)==0))
//																			{
//																				dmlRlzFlg=1;
//																				break;
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													 }
//												}
//											}
//										}																
//
//										//#######################################################//
//										printf("\n dmlRlzFlg:%d \t FlagPrevPartRlzd:%d",dmlRlzFlg,FlagPrevPartRlzd);fflush(stdout);
										printf("\n prtRlzFlg:%d ",prtRlzFlg);fflush(stdout);

										//if( (dmlRlzFlg==0) && (FlagPrevPartRlzd==0))
										if( prtRlzFlg==0) //TZ1.43-As no need to check for DML and TAsk release for part release
										{
											 tc_strcat(PrevRevDMLSet,"\nBelow Previous Revisions are skipped for release from STDSI:");	
											 tc_strcat(PrevRevDMLSet,"\nPrevious Revision (");
											 tc_strcat(PrevRevDMLSet,pre_revision);
											 tc_strcat(PrevRevDMLSet,") Of Part ");
											 tc_strcat(PrevRevDMLSet,Part_no);
											// tc_strcat(PrevRevDMLSet," is contained in DML ");//TZ1.43
											// tc_strcat(PrevRevDMLSet,DmlName);
											// tc_strcat(PrevRevDMLSet," which is not released from STDSI ");	
											 tc_strcat(PrevRevDMLSet,"  is not released from STDSI ");	
											 


											//Added By Dhanashri Skip Previous Revision UATZ1.42//

												 /*
												 1. Softcheck for this check (pending)
												 2. Set SkipPrevRev on prev rev tag till it get the released prev rev
												 */
												 if(FlagSkpRev==1)
												 {
												  ITKCALL(AOM_lock(AssyPreTag));
												  ITKCALL(AOM_set_value_string(AssyPreTag,"t5_SkipPrevRevSTD",Cur_revision));
												  ITKCALL(AOM_save(AssyPreTag) );
												  ITKCALL(AOM_unlock(AssyPreTag));
	
												  //get the prev rev of AssyPreTag and set 	t5_SkipPrevRevSTD if its not released from plant.
													tag_t			AssyPreTagCpy			= NULLTAG;
												    AssyPreTagCpy=AssyPreTag;

												   FindPrevRevLabel1:
													printf("\n inside FindPrevRevLabel ");fflush(stdout);
												  
												  	const char *qry_entries[2];//Multiple Item Queried Error
													const char *qry_values[2];//Multiple Item Queried Error
													int n_tags_found=0;
													tag_t	*itemclassp	= NULLTAG;
													tag_t item = NULLTAG;
													int Item_count      =  0;
													tag_t	*rev_list				= NULL;

													int PreRevFlag=0;
													int RevFlag=0;
													int ii=0;
													int LCSi=0;

													char			*prev_rev		= NULL;
													char			*Part_rev_Id		= NULL;
													char			*Part_Rev_copy		= NULL;
													char			*RevOnly		= NULL;
													char			*PreRevOnly		= NULL;
													char*			class_name=NULL;

													int stat_count=0;
													tag_t*			stat_list;
													int FlagPrevRevRlzd=0;
													char	*Part_clr_ind	=	NULL;
													
												   ITKCALL(AOM_ask_value_string(AssyPreTagCpy, "item_revision_id",&prev_rev));
												   ITKCALL(AOM_ask_value_string(AssyPreTagCpy, "item_revision_id",&Part_Rev_copy));
												   printf("\n prev_rev %s.....\n",prev_rev);fflush(stdout);
												   printf("\n Part_Rev_copy %s.....\n",Part_Rev_copy);fflush(stdout);
												   Part_clr_ind	=	NULL;
													ITKCALL(AOM_ask_value_string(AssyPreTagCpy,"t5_ColourInd",&Part_clr_ind));
													 printf("\n Part_clr_ind %s.....\n",Part_clr_ind);fflush(stdout);
													
													qry_entries[0] ="item_id";
													qry_entries[1] ="object_type";//Multiple Item Queried Error
													qry_values[0] = Part_no;
													if (tc_strcmp(Part_clr_ind,"C")==0)
													{
														qry_values[1] = "T5_ClrPart";//Multiple Item Queried Error Hemal
													}
													else
													{
														//qry_values[1] = "Design";//Multiple Item Queried Error Hemal
														//Handle the different design child class.
														char	*designBORev		=	NULL;
														char	*designBO			=	NULL;
														//tag_t	AssyTag			=	NULLTAG;
														//AssyTag=PartTags[k];
														printf("\nBefore getDesignType");fflush(stdout);
														getDesignType(AssyPreTagCpy, &designBORev,&designBO);
														printf("\nAfter getDesignType : %s",designBO);fflush(stdout);
														qry_values[1] = designBO;

													}//Multiple Item Queried Error
													//ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclassp);
													ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found, &itemclassp);//Multiple Item Queried Error
													
													item = itemclassp[0];

													ITKCALL(ITEM_list_all_revs (item, &Item_count, &rev_list));
													printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);

													if(Item_count > 0)
													{
														RevFlag = 0;
														PreRevFlag = 0;
														for(ii=Item_count-1;ii>=0;ii--)
														{
														   RevOnly = NULL;
														   PreRevOnly = NULL;
														   ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));
															printf("\n Part_rev_Id: %s\n",Part_rev_Id);fflush(stdout);
															if(tc_strcmp(prev_rev,Part_rev_Id)==0)
															{
																RevFlag = 1;
															}
															printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
															if(RevFlag == 1)
															{
															   RevOnly= strtok( Part_Rev_copy, ";" );
															   PreRevOnly= strtok( Part_rev_Id, ";" );
															   printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
															   printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
															   if(tc_strcmp(RevOnly,PreRevOnly)!=0)
																{
																  PreRevFlag = 1;
																}
															}
															printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
															if(PreRevFlag == 1)
															{
																//set t5SkipPrevRev if not released from plant
																printf("\n check whether part released from plant");fflush(stdout);
																ITKCALL(WSOM_ask_release_status_list(rev_list[ii],&stat_count,&stat_list));
																if(stat_count == 0)
																{
																	printf("\n NO LCS Found for part : %d\n",stat_count);fflush(stdout);
																	//break;
																}
																else
																{
																	for (LCSi=0;LCSi<stat_count ;LCSi++ )
																	{
																		ITKCALL(AOM_ask_value_string(stat_list[LCSi],"object_name",&class_name));
																		printf("\n class_name: %s\n",class_name);fflush(stdout);
																		
																		if(tc_strcmp(class_name,LcsStdRlzd)==0)
																		{
																			FlagPrevRevRlzd=1;
																			break;
																		}
																	}
																	printf("\n FlagPrevRevRlzd : %d\n",FlagPrevRevRlzd);fflush(stdout);
																   
																}

																if(FlagPrevRevRlzd==0)
																{
																	  printf("\n set t5SkipPrevRev and goto FindPrevRevLabel");fflush(stdout);
																	  ITKCALL(AOM_lock(rev_list[ii]));
																	  ITKCALL(AOM_set_value_string(rev_list[ii],"t5_SkipPrevRevSTD",Cur_revision));
																	  ITKCALL(AOM_save(rev_list[ii]) );
																	  ITKCALL(AOM_unlock(rev_list[ii]));

																	  AssyPreTagCpy=rev_list[ii];
																	  goto FindPrevRevLabel1;
																}
																else
																{
																	printf("\n Found Release revision Part_rev_Id: [%s]\n",Part_rev_Id);fflush(stdout);
																	break;
																}

															} // if(PreRevFlag == 1)
														} // for(ii=Item_count-1;ii>=0;ii--)
													} //if(Item_count > 0)
											      } // if(FlagSkpRev==1)
												 //End of Code Added By Dhanashri Skip Previous Revision UATZ1.42//

										}
						}

						
					}
				}

				printf("\n PrevRevDMLSet:%s",PrevRevDMLSet);fflush(stdout);
				printf("\n PrevRevEPASet:%s",PrevRevEPASet);fflush(stdout);

				if(strlen(PrevRevDMLSet)>10)
						{
							tc_strcat(SetStdRelErr,PrevRevDMLSet);	
							//cntFlag = 1;
						}
						if(strlen(PrevRevEPASet)>10)
						{
							tc_strcat(SetStdRelErr,PrevRevEPASet);	
							//cntFlag = 1;
						}
					
					
				

			return 0;

}


int Prev_Rev_Checks_SMDML(int PartCnt, tag_t* PartTags,char* SetStdRelErr,char* itemid,char* ProjectCode,char *STDDmlPlnt)
{
	
	char			*PrevRevSMDMLSet		= NULL;
	char  ItemIDCpy[40];
	char LcsStdWrkg[40];
	char LcsStdRlzd[40];
	char inp_Plant[40];
	char Pretask_Plant[40];
	int				task_len			= 0;
	char			*inp_PlntLstLtr		= NULL;
	char			*Cur_revision		= NULL;
	char			*Part_no			= NULL;
	int				count_task			= 0;
	tag_t*			PartEpaTags			= NULLTAG;
	int				cnt_tk				= 0;
	tag_t			PartepaTag			= NULLTAG;
	tag_t			itemTypeTag_class	= NULLTAG;
	char			*epaTaskId			= NULL;
	char			type_class[TCTYPE_name_size_c+1];
	char			*epa_Plant			= NULL;
	logical			CurrentRevInEPA2;
	char			*Part_Rev			= NULL;
	int				prevRevinEPA		= 0;
	int				prtRlzFlg			= 0;
	int				dmlRlzFlg			= 0;
	int				stlst				= 0,st_dmlcount=0,smdmlErrorCnt=0,k=0;

	char			*itemidpre			= NULL;
	char			*pre_revision		= NULL;
	char			*ReleaseStatuspart		= NULL;
	char			*PreTaskId		= NULL;
	tag_t*			prt_status_list		= NULLTAG;

	tag_t			AssyTag				= NULLTAG;
	tag_t			AssyPreTag			= NULLTAG;
	tag_t			relation_type_task	= NULLTAG;
	int				st_prt				= 0	,	Precnt=0,smDmlFnd=0;
	tag_t*			PrePartTskTags		= NULLTAG;
	int				precount_task		= 0,smRlzFlg=0;
	tag_t			PreParttskTag		= NULLTAG;
	tag_t			PreitemTypeTag_class2= NULLTAG;
	char			Pretype_class2[TCTYPE_name_size_c+1];
	char			*dmlId				= NULL;
	char			*ReleaseStatusdml				= NULL;
	tag_t*			dml_status_list		= NULLTAG;

	if (!PrevRevSMDMLSet) MEM_free(PrevRevSMDMLSet);
	PrevRevSMDMLSet=(char *)MEM_alloc(2000);
	tc_strcpy(PrevRevSMDMLSet," ");

	printf("\n\n ##############Inside Previous revision SM checks##############");fflush(stdout);

   
	tc_strcpy(ItemIDCpy,itemid);
	GetPlantWiseRelStat(ItemIDCpy,LcsStdWrkg,LcsStdRlzd);
	printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
	printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);

	task_len=0;
	task_len=strlen(itemid);
	printf("\t  TaskName is :  %s\n", itemid);fflush(stdout);
	printf("\t  task_len ...%d\n", task_len);fflush(stdout);// length task
	GetPlantForDMLORTask(itemid,inp_Plant);	
	printf("\t  inp_Plant after  ...%s\n", inp_Plant);

	inp_PlntLstLtr=subString(itemid,17,task_len);
	printf("\t  inp_PlntLstLtr after  ...%s\n", inp_PlntLstLtr);
	printf("\t  input ProjectCode  ...%s\n", ProjectCode);
	
	for (k=0;k<PartCnt ;k++ )
	{					
		printf("\n\n\t\t Prev_Rev_Checks:for k_1 =:%d",k);fflush(stdout);
		AssyTag=PartTags[k];
		AssyPreTag=NULLTAG;

		ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
		printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);

		ITKCALL(AOM_ask_value_string(AssyTag, "item_revision_id",&Cur_revision));
		printf("\n Cur_revision %s.....\n",Cur_revision);

		GRM_find_relation_type("CMHasSolutionItem",&relation_type_task);
		GRM_list_primary_objects_only(AssyTag,relation_type_task,&count_task,&PartEpaTags);
		if(count_task >0)
		{						
			for (cnt_tk=0;cnt_tk<count_task ;cnt_tk++ )
			{
				PartepaTag=PartEpaTags[cnt_tk];
				ITKCALL (TCTYPE_ask_object_type(PartepaTag,&itemTypeTag_class));
				ITKCALL (TCTYPE_ask_name(itemTypeTag_class,type_class));

				printf("\t  type_class ...%s\n", type_class);
				if(tc_strcmp(type_class,"T5_EPATaskRevision")==0)
				{
					ITKCALL(AOM_ask_value_string(PartepaTag, "item_id",&epaTaskId));
					printf("\n epaTaskId %s.....\n",epaTaskId);

					epa_Plant=subString(epaTaskId,22,strlen(epaTaskId));
					printf("\t  epa_Plant after  ...%s\n", epa_Plant);
					
					if(tc_strcmp(inp_Plant,epa_Plant)==0)
					{
						CurrentRevInEPA2=true;
					}
				}
			}
		}

		ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev));
		printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);

		if(strstr(Part_Rev,"NR"))
		{
			printf("\n Previous revision function can not be called as current revision has NR revision");fflush(stdout);
		}
		else
		{
			printf("\n Calling function to get Previous revision ");fflush(stdout);
			tm_fnd_Prev_Official_Revision(Part_no,AssyTag,&AssyPreTag);//TZ 1.43
		}				
							
		if(AssyPreTag)
		{
			prtRlzFlg=0;
			ITKCALL(AOM_ask_value_string(AssyPreTag, "item_id",&itemidpre));
			printf("\n itemidpre %s.....\n",itemidpre);

			ITKCALL(AOM_ask_value_string(AssyPreTag, "item_revision_id",&pre_revision));
			printf("\n pre_revision %s.....\n",pre_revision);						

			ITKCALL(WSOM_ask_release_status_list(AssyPreTag,&st_prt,&prt_status_list));
			for (stlst = 0; stlst < st_prt; stlst++)
			{
				AOM_ask_name(prt_status_list[stlst], &ReleaseStatuspart);
				printf("\n ReleaseStatuspart %s \n",  ReleaseStatuspart);fflush(stdout);
				if(tc_strcmp(ReleaseStatuspart,LcsStdRlzd)==0)
				{
					prtRlzFlg=1;
				}
			}

			if((CurrentRevInEPA2!=true) && (prtRlzFlg>0))
			{
				printf("\n Current revision is not in epa of same plant, checking whether previous revision is in SMDML of same plant");fflush(stdout);						
				
				Precnt=0;
				PrePartTskTags=NULLTAG;
				smDmlFnd=0;
				GRM_list_primary_objects_only(AssyPreTag,relation_type_task,&precount_task,&PrePartTskTags);
				if(precount_task >0)
				{							
					for (Precnt=0;Precnt<precount_task ;Precnt++ )
					{
						PreParttskTag=NULLTAG;
						PreParttskTag=PrePartTskTags[Precnt];
						ITKCALL (TCTYPE_ask_object_type(PreParttskTag,&PreitemTypeTag_class2));
						ITKCALL (TCTYPE_ask_name(PreitemTypeTag_class2,Pretype_class2));

						printf("\t  Pretype_class2 ...%s\n", Pretype_class2);fflush(stdout);	
						
						smRlzFlg=0;
						

						if(tc_strcmp(Pretype_class2,"T5_SMDMLTaskRevision")==0)
						{
							ITKCALL(AOM_ask_value_string(PreParttskTag, "item_id",&PreTaskId));
							printf("\n PreTaskId %s.....\n",PreTaskId);	fflush(stdout);									

							//Pretask_Plant=subString(PreTaskId,17,strlen(PreTaskId));
							GetPlantForDMLORTask(PreTaskId,Pretask_Plant);	
							printf("\t  Pretask_Plant after  ...%s:::: %s", Pretask_Plant,STDDmlPlnt);
							
							dmlId=subString(PreTaskId,2,2);
							printf("\n dmlId:%s",dmlId);fflush(stdout);

							if(tc_strcmp(dmlId,"SM")==0 && (tc_strcmp(Pretask_Plant,STDDmlPlnt)==0))
							{

								smDmlFnd++;
								stlst = 0;
								ITKCALL(WSOM_ask_release_status_list(PreParttskTag,&st_dmlcount,&dml_status_list));
								for (stlst = 0; stlst < st_dmlcount; stlst++)
								{
									AOM_ask_name(dml_status_list[stlst], &ReleaseStatusdml);
									printf("\n ReleaseStatusdml %s :::LcsStdRlzd %s\n",  ReleaseStatusdml,LcsStdRlzd);fflush(stdout);
									if(tc_strcmp(ReleaseStatusdml,LcsStdRlzd)!=0 )
									{
										
										printf("\n Previous revision of part is contanied in SMDML which is not stdsi released, carry forward previous revision changes into current revision");fflush(stdout);
										//#############Logic to carry forward previous revision changes#############//



										//##########################################################################//
									}
									else
									{
										smRlzFlg++;
									
									}
								}
							}
						}
					}
					printf("\n smRlzFlg %d :: smDmlFnd %d",smRlzFlg,smDmlFnd);fflush(stdout);
					if((smRlzFlg==0) && (smDmlFnd>0))
					{
						printf("\n 111 smdmlErrorCnt %d" ,smdmlErrorCnt);fflush(stdout);
						 if(smdmlErrorCnt==0)
						 {
							 tc_strcat(PrevRevSMDMLSet,"\n Below Previous Revision of Part is attached to SM-DML which is not STDSI released.Please release the SM-DML.");	
							 tc_strcat(PrevRevSMDMLSet,"\n");
							 tc_strcat(PrevRevSMDMLSet,itemidpre);
							 tc_strcat(PrevRevSMDMLSet,":");
							 tc_strcat(PrevRevSMDMLSet,pre_revision);
							 tc_strcat(PrevRevSMDMLSet,";SM-DML Task :");
							 tc_strcat(PrevRevSMDMLSet,PreTaskId);	
							 smdmlErrorCnt++;
							 printf("\n 111 PrevRevSMDMLSet %s" ,PrevRevSMDMLSet);fflush(stdout);
						 }
						 else
						 {
							 tc_strcat(PrevRevSMDMLSet,"\n");
							 tc_strcat(PrevRevSMDMLSet,itemidpre);
							 tc_strcat(PrevRevSMDMLSet,":");
							 tc_strcat(PrevRevSMDMLSet,pre_revision);
							 tc_strcat(PrevRevSMDMLSet,";SM-DML Task :");
							 tc_strcat(PrevRevSMDMLSet,PreTaskId);	
							 smdmlErrorCnt++;
							 printf("\n 1112222 PrevRevSMDMLSet %s" ,PrevRevSMDMLSet);fflush(stdout);
						 }
					}
					
				}

				
			}

		}
	}

	printf("\n PrevRevSMDMLSet:%s",PrevRevSMDMLSet);fflush(stdout);

	if(smdmlErrorCnt>0)
	{
		tc_strcat(SetStdRelErr,PrevRevSMDMLSet);	
	}
		
	return 0;

}
//########################################################################################//
//At the time of sign off of APL AMDML, this validation will ensure whether the PP/PM DML
//for part is released or not.
//########################################################################################//

int AMDML_Std_Validation(int PartCnt,tag_t	sTaskTag, tag_t* PartTags,char* SetStdRelErr)
{

			int k = 0;
			int cnt1 = 0;
			int ppDMLFnd=0;
			int             st_count			= 0;
			int				n_refs				= 0;
			int				task_len			= 0;
			int				inp_len				= 0;
			int				cntErr				= 0;
			int				ifail				= ITK_ok;
			int				 *levels			= 0;
			int				n_tags_found1=0;
			int				cntSt=0;
			int				errCount=0;
			int				dmlcount=0;
			int				j=0;
			int				task_project_tags_found=0;
			int				part_project_tags_found=0;
			int				dml_project_tags_found=0;
			int				bypassChk=0;

			char			*Item_id = NULL;
			char*			ChildDml;
			char *  IsPPPPMRlzErr = NULL;
			char *  SetIsPPPPMRlzErr = NULL;
			char*			Part_no				= NULL;
			char*			Part_Rev				= NULL;
			char*			Part_DRStatus				= NULL;
			char*			inp_task_no			= NULL;
			char*			class_name=NULL;
			char			task_type_Proj[TCTYPE_name_size_c+1];
			char			dml_type_Proj[TCTYPE_name_size_c+1];
			//char			*inp_Plant			= NULL;
			//char			*task_Plant			= NULL;
			char            *desid				= NULL;
			char            *task_projCode		= NULL;
			char			*dml_type			= NULL;
			char			*DMLDRStatus		= NULL;
			char			*dmlId				= NULL;
			char			*task_PlantName		= NULL;
			char			type_name_ref[TCTYPE_name_size_c+1];
			char			**relations			= NULL;
			char*			lcsToset			= NULL;
			char*			dml_projCode		= NULL;
			char*			part_PlantName		= NULL;
			char			Part_type_Proj[TCTYPE_name_size_c+1];
			char*			dml_PlantName		= NULL;

			tag_t			item_rev_tag_p				= NULLTAG;
			tag_t			objTypeRefTag				= NULLTAG;
			tag_t			AssyTag						= NULLTAG;
			tag_t			*referencers				= NULLTAG;
			tag_t			item1						= NULLTAG;
			tag_t			tsk_dml_rel_type;
			tag_t			ObjTypTaskProj				= NULLTAG;
			tag_t			ObjTypDMLProj				= NULLTAG;
			tag_t			ObjTypPartProj				= NULLTAG;



			tag_t*    status_list;
			tag_t	*itemclass1							= NULLTAG;
			tag_t			relation_type= NULLTAG;
			tag_t			PartDmlTaskTag				= NULLTAG;
			tag_t			DmlRevTag			= NULLTAG;

			tag_t*			PartDmlTaskTags			= NULLTAG;
			tag_t*			DMLRevision			= NULLTAG;
			tag_t	*task_projectclass	= NULLTAG;
			tag_t	*dml_projectclass	= NULLTAG;
			tag_t	task_project_item	= NULLTAG;
			tag_t	dml_project_item	= NULLTAG;
			tag_t	part_project_item	= NULLTAG;
			tag_t	*part_projectclass	= NULLTAG;

			const char *attrs[1];
		    const char *values[1];
			const char *task_project_qry_entries[1];
		    const char *task_project_qry_values[1];
			
			const char *part_project_qry_entries[1];
		    const char *part_project_qry_values[1];

			const char *dml_project_qry_entries[1];
		    const char *dml_project_qry_values[1];

			char inp_Plant[40];
			char task_Plant[40];

			

			lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
			printf("\n Inside t5StdAMDMLValidation_Check_Func_New ....\n");
			cntErr = 0;

			ITKCALL(AOM_ask_value_string(sTaskTag,"item_id",&inp_task_no));
			printf("\n\n\t\t t5StdAMDMLValidation_Check_Func_New :inp_task_no  is :%s",inp_task_no);	fflush(stdout);

			if(strstr(inp_task_no,"AM"))
			{
				inp_len=0;
				inp_len=strlen(inp_task_no);
				if(strstr(inp_task_no,"NONERC"))
				{
					//inp_Plant=subString(inp_task_no,18,inp_len);
					GetPlantForDMLORTask(inp_task_no,inp_Plant);	
				}
				else
				{
					//inp_Plant=subString(inp_task_no,14,inp_len);
					GetPlantForDMLORTask(inp_task_no,inp_Plant);
				}
				printf("\n inp_Plant:%s",inp_Plant);fflush(stdout);

//				if(tc_strcmp(inp_Plant,"APLP")==0)
//				{
//					strcpy(lcsToset,"T5_LcsStdpRlzd");
//				}
//				else if(tc_strcmp(inp_Plant,"APLD")==0)
//				{
//					strcpy(lcsToset,"T5_LcsStddRlzd");
//				}
//				else if(tc_strcmp(inp_Plant,"APLC")==0)
//				{
//					strcpy(lcsToset,"T5_LcsStdRlzd");
//					
//				}
//				else if(tc_strcmp(inp_Plant,"APLJ")==0)
//				{
//					strcpy(lcsToset,"T5_LcsStdjRlzd");
//				}
//				else if(tc_strcmp(inp_Plant,"APLL")==0)
//				{
//					strcpy(lcsToset,"T5_LcsStdlRlzd");
//				}
//				else if(tc_strcmp(inp_Plant,"APLA")==0)
//				{
//					strcpy(lcsToset,"T5_LcsStdaRlzd");
//				}
//				else if((tc_strcmp(inp_Plant,"APLU")==0) )
//				{
//					strcpy(lcsToset,"T5_LcsStduRlzd");
//				}
//				else
//				{
//					strcpy(lcsToset,"T5_LcsStdRlzd");
//				}

				char  ItemIDCpy[40];
				char LcsStdWrkg[40];
				char LcsStdRlzd[40];
				tc_strcpy(ItemIDCpy,inp_task_no);
				GetPlantWiseRelStat(ItemIDCpy,LcsStdWrkg,LcsStdRlzd); //TZ3.46
				printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
				printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);
				strcpy(lcsToset,LcsStdRlzd);

			    printf("\n t5StdAMDMLValidation_Check_Func ..............");fflush(stdout);
				for (k=0;k<PartCnt ;k++ )
				{
					printf("\n\n\t\t STD DML Cre:for k =:%d",k);fflush(stdout);
					ppDMLFnd=0;
					AssyTag=PartTags[k];

					ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
					printf("\n\n\t\t STD DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev));
					printf("\n\n\t\t STD DML Cre:Part_Rev  is :%s",Part_Rev);	fflush(stdout);

					//Added By Dhanashri for skip prev rev UATZ1.42//

					 char*			SkipPrevRevSTD				= NULL;
					 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
					 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
					 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
					   
					  //if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
					  if(tc_strlen(SkipPrevRevSTD)>0)
					  {
					  	printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
					  	continue;
					  }
					//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//


					
					ITKCALL(AOM_ask_value_string(AssyTag,"t5_PartStatus",&Part_DRStatus));
					printf("\n\n\t\t STD DML Cre:Part_DRStatus  is :%s",Part_DRStatus);	fflush(stdout);

					n_refs=0;
					PartDmlTaskTags=NULLTAG;
					ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
					ITKCALL(GRM_list_primary_objects_only(AssyTag,relation_type,&n_refs,&PartDmlTaskTags));
					printf("\n\n\t\t n_refs ==%d",n_refs);fflush(stdout);
					
					if (n_refs >0)
					{
						for (cnt1=0;cnt1<n_refs ;cnt1++ )
						{
							PartDmlTaskTag=PartDmlTaskTags[cnt1];//task pointer
							printf("\n\n\t\t INSIDE EPA_Part_PP_DML_Rlzd_Checks: ");fflush(stdout);
							
							ITKCALL(TCTYPE_ask_object_type(PartDmlTaskTag,&objTypeRefTag));
							ITKCALL(TCTYPE_ask_name(objTypeRefTag,type_name_ref));
							printf("\nTCDCtype_name_ref isss :%s\n",type_name_ref);fflush(stdout);
							if (strcmp(type_name_ref,"T5_APLTaskRevision")==0)
							{

								if( AOM_ask_value_string(PartDmlTaskTag,"item_id",&desid)!=ITK_ok);
								printf("\n saveCS_method::Design Revision Item ID %s\n", desid);fflush(stdout);

								if( AOM_ask_value_string(PartDmlTaskTag,"t5_cprojectcode",&task_projCode)!=ITK_ok);
								printf("\n task_projCode %s\n", task_projCode);fflush(stdout);

								dml_type=subString(desid,2,2);
								ChildDml=subString(desid,0,10);
								printf("\ndml_type:%s",dml_type);fflush(stdout);
								printf("\n ChildDml:%s",ChildDml);fflush(stdout);

								task_len=0;
								task_len=strlen(desid);
								if(strstr(desid,"NONERC"))
								{
									//task_Plant=subString(desid,18,task_len);
									GetPlantForDMLORTask(desid,task_Plant);	
								}
								else
								{
									//task_Plant=subString(desid,14,task_len);
									GetPlantForDMLORTask(desid,task_Plant);	
								}
								printf("\n task_Plant:%s",task_Plant);fflush(stdout);
								printf("\n inp_Plant:%s",inp_Plant);fflush(stdout);

								st_count=0;
								status_list=NULLTAG;
								ITKCALL(WSOM_ask_release_status_list(PartDmlTaskTag,&st_count,&status_list));
								printf("\n st_count:%d",st_count);fflush(stdout);

								IsPPPPMRlzErr=NULL;
								IsPPPPMRlzErr=(char *)MEM_alloc(1000);
								tc_strcpy(IsPPPPMRlzErr," ");

								if(tc_strcmp(inp_Plant,task_Plant)==0)
								{
									if( (tc_strcmp(dml_type,"PP")==0) || (tc_strcmp(dml_type,"PM")==0) || (tc_strcmp(dml_type,"JP")==0) || (tc_strcmp(dml_type,"JM")==0) || (tc_strcmp(dml_type,"LP")==0) || (tc_strcmp(dml_type,"LM")==0))
									{

										if (st_count == 0)  /* No Status, so the Item is not yet Released */
										{
											printf("\n No Status, so the Item is not yet Released \n");
											//errCount=errCount+1;
											tc_strcat(IsPPPPMRlzErr,"PP/PM Series DML ");
											tc_strcat(IsPPPPMRlzErr,ChildDml);
											tc_strcat(IsPPPPMRlzErr,"_");
											tc_strcat(IsPPPPMRlzErr,task_Plant);
											tc_strcat(IsPPPPMRlzErr," for Part ");
											tc_strcat(IsPPPPMRlzErr,Part_no);
											tc_strcat(IsPPPPMRlzErr," is not STDSI Released.\n");
											tc_strcat(IsPPPPMRlzErr," Please Release the PP/PM Series DML from STDS first and try respective DML.\n");
											cntErr=cntErr+1;	
										}
										else
										{

											for(cntSt=0;cntSt<st_count;cntSt++)
											{

												ITKCALL(AOM_ask_value_string(status_list[cntSt],"object_name",&class_name));
												printf("\n class_name: %s\n",class_name);fflush(stdout);

											//	if( (tc_strcmp(lcsToset,class_name)!=0) )
											if( (tc_strcmp(lcsToset,class_name)!=0) && (cntSt==st_count-1))
												{
													tc_strcat(IsPPPPMRlzErr,"PP/PM Series DML ");
													tc_strcat(IsPPPPMRlzErr,ChildDml);
													tc_strcat(IsPPPPMRlzErr,"_");
													tc_strcat(IsPPPPMRlzErr,task_Plant);
													tc_strcat(IsPPPPMRlzErr," for Part ");
													tc_strcat(IsPPPPMRlzErr,Part_no);
													tc_strcat(IsPPPPMRlzErr," is not STDSI Released.\n");
													tc_strcat(IsPPPPMRlzErr," Please Release the PP/PM Series DML from STDS first and try respective DML.\n");
													cntErr=cntErr+1;
													//errCount=errCount+1;
													//printf("\n cntErr: %d,errCount %d\n",cntErr,errCount);fflush(stdout);
													printf("\n cntErr: %d\n",cntErr);fflush(stdout);

												}

											}

										}
										ppDMLFnd++;
										
									}

									//if(errCount>0)
									//{
										//if(tc_strcmp(inp_Plant,"APLS")==0)
										//{
										
//											tc_strcat(IsPPPPMRlzErr,"PP/PM Series DML ");
//											tc_strcat(IsPPPPMRlzErr,ChildDml);
//											tc_strcat(IsPPPPMRlzErr,"_");
//											tc_strcat(IsPPPPMRlzErr,task_Plant);
//											tc_strcat(IsPPPPMRlzErr," for Part ");
//											tc_strcat(IsPPPPMRlzErr,Part_no);
//											tc_strcat(IsPPPPMRlzErr," is not STDSI Released.\n");
//											tc_strcat(IsPPPPMRlzErr," Please Release the PP/PM Series DML from STDS first and try respective DML.\n");
//											cntErr=cntErr+1;		
//										}
//										else
//										{
//											ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
//											if (tsk_dml_rel_type!=NULLTAG)
//											{
//												ITKCALL(GRM_list_primary_objects_only(PartDmlTaskTag,tsk_dml_rel_type,&dmlcount,&DMLRevision));
//												for (j=0;j<dmlcount ;j++ )
//												{
//													DmlRevTag = DMLRevision[j];
//													ITKCALL(AOM_ask_value_string(DmlRevTag, "item_id",&dmlId));
//													ITKCALL(AOM_ask_value_string(DmlRevTag, "t5_cDRstatus",&DMLDRStatus));
//													ITKCALL(AOM_ask_value_string(DmlRevTag,"t5_cprojectcode",&dml_projCode));
//													printf("\n dml_projCode %s:%s:%s\n", dml_projCode,DMLDRStatus,Part_DRStatus);fflush(stdout);
//													if((tc_strcmp(DMLDRStatus,"DR0")==0) || (tc_strcmp(DMLDRStatus,"DR1")==0) || (tc_strcmp(DMLDRStatus,"DR2")==0) || (tc_strcmp(DMLDRStatus,"DR3")==0) || (tc_strcmp(DMLDRStatus,"AR0")==0) || (tc_strcmp(DMLDRStatus,"AR1")==0) || (tc_strcmp(DMLDRStatus,"AR2")==0) || (tc_strcmp(DMLDRStatus,"AR3")==0)) 
//													{
//														if((tc_strcmp(Part_DRStatus,"DR4")==0) || (tc_strcmp(Part_DRStatus,"DR5")==0) || (tc_strcmp(Part_DRStatus,"AR4")==0) || (tc_strcmp(Part_DRStatus,"AR5")==0) ) 
//														{
//															task_project_qry_entries[0] ="item_id";
//															task_project_qry_values[0] = task_projCode;
//															//task_project_qry_values[0] = "5442";
//
//															ITKCALL(ITEM_find_items_by_key_attributes(1, task_project_qry_entries, task_project_qry_values,&task_project_tags_found, &task_projectclass));
//															printf("\n task_project_tags_found %d\n", task_project_tags_found);fflush(stdout);
//													
//															if(task_project_tags_found>0)
//															{
//																printf("\n Inside task project code...");fflush(stdout);
//													
//																task_project_item = task_projectclass[0];
//																if (task_project_item!=NULLTAG)
//																{
//																	printf("\n task_project_item is not nulltag...");fflush(stdout);
//																	ITKCALL(TCTYPE_ask_object_type(task_project_item,&ObjTypTaskProj));
//																	ITKCALL(TCTYPE_ask_name(ObjTypTaskProj,task_type_Proj));
//																	printf("\n MT:DML: task_type_Proj :: %s\n", task_type_Proj);fflush(stdout);
//																	if (tc_strcmp(task_type_Proj,"T5_Project")==0)
//																	{
//																		ITKCALL(AOM_ask_value_string(task_project_item,"t5_ParentProductLine",&task_PlantName));
//																		printf("\n task_PlantName :: %s\n", task_PlantName);fflush(stdout);
//																		if(tc_strcmp(task_PlantName,"CVBU PUNE")==0)
//																		{
//																			
//																			dml_project_qry_entries[0] ="item_id";
//																			dml_project_qry_values[0] = dml_projCode;
//
//																			ITKCALL(ITEM_find_items_by_key_attributes(1, dml_project_qry_entries, dml_project_qry_values,&dml_project_tags_found, &dml_projectclass));
//																			printf("\n dml_project_tags_found :: %d\n", dml_project_tags_found);fflush(stdout);
//																			if(dml_project_tags_found>0)
//																			{
//																				dml_project_item = dml_projectclass[0];
//																				if (dml_project_item!=NULLTAG)
//																				{
//																					ITKCALL(TCTYPE_ask_object_type(dml_project_item,&ObjTypDMLProj));
//																					ITKCALL(TCTYPE_ask_name(ObjTypDMLProj,dml_type_Proj));
//																					printf("\n MT:DML: dml_type_Proj :: %s\n", dml_type_Proj);fflush(stdout);
//																					if (tc_strcmp(dml_type_Proj,"T5_Project")==0)
//																					{
//																						ITKCALL(AOM_ask_value_string(dml_project_item,"t5_ParentProductLine",&dml_PlantName));
//																						printf("\n dml_PlantName :: %s\n", dml_PlantName);fflush(stdout);
//																						if((tc_strcmp(dml_PlantName,"CVBU JSR")==0) || (tc_strcmp(dml_PlantName,"CVBU LKO")==0))
//																						{
//																							part_project_qry_entries[0] ="item_id";
//																							part_project_qry_values[0] = dml_projCode;
//																							
//																							ITKCALL(ITEM_find_items_by_key_attributes(1, part_project_qry_entries, part_project_qry_values,&part_project_tags_found, &part_projectclass));
//																							if(part_project_tags_found>0)
//																							{
//																								part_project_item = part_projectclass[0];
//																								if (part_project_item!=NULLTAG)
//																								{
//																									ITKCALL(TCTYPE_ask_object_type(part_project_item,&ObjTypPartProj));
//																									ITKCALL(TCTYPE_ask_name(ObjTypPartProj,Part_type_Proj));
//																									printf("\n MT:DML: Part_type_Proj :: %s\n", Part_type_Proj);fflush(stdout);
//																									if (tc_strcmp(Part_type_Proj,"T5_Project")==0)
//																									{
//																										ITKCALL(AOM_ask_value_string(part_project_item,"t5_ParentProductLine",&part_PlantName));
//																										printf("\n part_PlantName :: %s\n", part_PlantName);fflush(stdout);
//																										if((tc_strcmp(part_PlantName,"CVBU JSR")==0) || (tc_strcmp(part_PlantName,"CVBU LKO")==0))
//																										{
//																											bypassChk++;
//																										}
//																									}
//																								}
//																							}
//																						
//																						
//																						
//																						}
//																					
//																					
//																					}
//																				
//																				
//																				}
//																			
//																			
//																			}
//																		
//																		}
//																	}
//																}
//
//																
//															}
//														}	
//													
//													}
//												}
//											}
//											printf("\n bypassChk:%d",bypassChk);fflush(stdout);
//											if(bypassChk==0)
//											{
//												tc_strcat(IsPPPPMRlzErr,"PP/PM Series DML ");
//												tc_strcat(IsPPPPMRlzErr,ChildDml);
//												tc_strcat(IsPPPPMRlzErr,"_");
//												tc_strcat(IsPPPPMRlzErr,task_Plant);
//												tc_strcat(IsPPPPMRlzErr," for Part ");
//												tc_strcat(IsPPPPMRlzErr,Part_no);
//												tc_strcat(IsPPPPMRlzErr," is not STDSI Released.\n");
//												tc_strcat(IsPPPPMRlzErr," Please Release the PP/PM Series DML from STDS first and try respective DML.\n");
//												cntErr=cntErr+1;	
//											}
//										
//										}
//									}
																		
								}
									
								printf("\n IsPPPPMRlzErr:%s",IsPPPPMRlzErr);fflush(stdout);
								if(strlen(IsPPPPMRlzErr)>10)
								{
									tc_strcat(SetStdRelErr,IsPPPPMRlzErr);
									cntFlag = 1;
								}								
						
							}
							if(ppDMLFnd>0)
							{
								break;
							}
						}
					}


				}
			}

	return 0;

}


//TZ1.42 compilation DEEPTI for DML Released
int std_dml_release( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;
	char			*ClosureDate		= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
	char* WTlcsToset=NULL;//WT changes
    char* lcsToset=NULL;
    char* lcsToremove=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;


	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;
	tag_t         CurrentRoleTag = NULLTAG;
	char		  roleName[SA_name_size_c+1];

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;

	char cNextDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char **DesignGroupList;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	int st_count_dml=0; //Added by Deepti
	int iLCS=0; //Added by Deepti
	char*			releasest_name			= NULL;//Added by Deepti
	tag_t*			status_list			=	NULLTAG;//Added by Deepti
	int   releaseStatusFnd			= 0;//Added by Deepti
	int   taskreleaseStatusFnd			= 0;//Added by Deepti
	int   dmlreleaseStatusFnd			= 0;//Added by Deepti
	int   task_st_count			= 0;//Added by Deepti
	int   dml_st_count			= 0;//Added by Deepti
	int   taskLCS				= 0;//Added by Deepti
	int   dmlLCS				= 0;//Added by Deepti
	char*			dml_releasest_name		= NULL;
	char*			task_releasest_name	= NULL;
	tag_t *task_status_list;
	tag_t *dml_status_list;
	char cCurrentAccessDate[20]={0};
	char cCurrentAccessDate1[20]={0};
	date_t			Task_Release_date;
	date_t			DML_Release_date;
	tag_t  TaskClosureDtAttrId = NULLTAG;
	tag_t  DMLClosureDtAttrId = NULLTAG;
	tag_t  Closure = NULLTAG;
	tag_t  Maturity = NULLTAG;
	tag_t  Disposition = NULLTAG;
	char   *TaskName	= NULL;
	char*	 DMLtype		= NULL;
	char	 *PlantNameP		= NULL;



	WTlcsToset =(char *) MEM_alloc(20 * sizeof(char *));//WT Changes
	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
	lcsToremove =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside std_dml_release***************\n ");fflush(stdout);
   //strcpy(lcsToset,"T5_LcsStdRlzd");

	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}


	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n std_dml_release \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name(objTypeTag,type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_APLDMLRevision")==0)
	{
		    printf("\n inside class T5_APLDMLRevision......\n");fflush(stdout);
			AOM_ask_value_string( DMLTag, "item_id", &item_id);
			AOM_ask_value_string( DMLTag, "current_id", &DML_no);
			AOM_ask_value_strings(DMLTag,"t5_crdesigngroup",&num,&DesignGroupList);
			//AOM_ask_value_string(DMLTag,"t5_rlstype",&RlsType);
			AOM_ask_value_string( DMLTag, "t5_cprojectcode", &Proj_Code);

			printf("\n Proj_Code : %s\n",Proj_Code);fflush(stdout);
			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n DML_no : %s\n",DML_no);fflush(stdout);
			printf("\n RlsType : %s\n",RlsType);fflush(stdout);
			printf("\n num is : %d\n",num);fflush(stdout);

			//strcpy(lcsToremove,"NA");
			//**********TZ3.46*********************//
			ITKCALL(SA_ask_current_role(&CurrentRoleTag));
			ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
			printf("\n\n  roleName : %s\n",roleName); fflush(stdout);		
			
			char AplRvwLC[40];
			char AplWrkngLC[40];
			char AplRlzd[40];
			char Stdwrknglc[40];
			char Stdrlzdlc[40];
			char PltLcs[40];
			char StdPlant[40];
			char StdRevRule[40];
			char StdCLosRule[40];
			char StdView[40];
			PlantNameP=subString(roleName,3,4);
			printf( "PlantNameP:%s\n", PlantNameP);  
			
			//get_CtrlVal_APLStateInf(PlantNameP,"","","",Stdwrknglc,Stdrlzdlc,"","","","","");//TZ1.46//Priti
			get_CtrlVal_STDStateInf(PlantNameP,AplRvwLC,AplWrkngLC,AplRlzd,Stdwrknglc,Stdrlzdlc,PltLcs,StdPlant,StdRevRule,StdCLosRule,StdView);//TZ1.46//Priti

			strcpy(WTlcsToset,"Obsolete");//WT Chnages
			strcpy(lcsToset,Stdrlzdlc);
			strcpy(lcsToremove,Stdwrknglc);
			//***********************************//


        				printf("\n Item created first time only with item_id \n");fflush(stdout);
                        if (DMLTag != NULLTAG)
						 {
							ITKCALL(AOM_ask_value_string(DMLTag,"t5_EcnType",&DMLtype));//TZ1.43
							printf("\n\t APLDMLtype is :%s",DMLtype); fflush(stdout);//TZ1.43

							GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
							 /// Solution Item start

							CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&count,&TaskRevision));
							printf("\n\n\t\t APL DML Cre:ERC DML to Task : %d",count);fflush(stdout);
							for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
							{
							TaskRevTag = TaskRevision[TaskCnt];

							CALLAPI(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
							printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);

							CALLAPI(AOM_ask_value_string(TaskRevTag,"item_id",&TaskName));//TZ1.43
							printf("\n\n\t\t TaskName is :%s",TaskName);fflush(stdout);//TZ1.43

							if(strcmp(object_type,"T5_APLTaskRevision")==0)
							{
								PartCnt=0;

								/*CALLAPI(CR_create_release_status(lcsToset,&status2));
      							CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
								printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
								CALLAPI(EPM_add_release_status(status2,1,&TaskRevTag,retain));*/


								CALLAPI(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
								printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
								if (PartCnt>0)
								{
									GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
									for (k=0;k<PartCnt ;k++ )
									{
										printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
										AssyTag=PartTags[k];

										CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
										printf("\n\n\t\t APL DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);

										if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
										if(TCTYPE_ask_name2(objTypeTag,&type_name1));
										printf("\n\n\t\t APL DML Cre:AssyTag type_name1 := %s", type_name1);fflush(stdout);

										CALLAPI(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
										printf("\n\n\t\t APL DML Cre:AssyTag PartTypeStr := %s", PartTypeStr);fflush(stdout);

										if (tc_strcmp(type_name1,"Design Revision")==0 || tc_strcmp(type_name1,"Part Revision")==0 || tc_strcmp(type_name1,"T5_ClrPartRevision")==0  || tc_strcmp(type_name1,"Colour Part Revision")==0)
										{
											//Added By Dhanashri for skip prev rev UATZ1.42//
											 char*			SkipPrevRevSTD				= NULL;
											 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
											 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
											 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
												
												//if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
												if(tc_strlen(SkipPrevRevSTD)>0)
												{
													printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
													continue;
												}
											//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

								            //Commented by Deepti
											/*CALLAPI(EPM_add_release_status(status2,1,&AssyTag,retain));
											if((strcmp(ReleaseStatus,"T5_LcsStdRlzd")==0) )
											{
												CALLAPI(WSOM_ask_effectivity_mode(&stat));

												getCurrentDateTime(cCurrentAccessDate);
												CALLAPI(PROP_ask_property_by_name(status2,"effectivity_text",&propEff_tag));
												CALLAPI(PROP_ask_value_string(propEff_tag,&value));

												getNextDate(cNextDate);
												printf("\n cNextDate:%s",cNextDate);

												CALLAPI(ITK_string_to_date(cNextDate, &test_date_1 ));
												CALLAPI(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));

												start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

												printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

												start_end_date[0] = test_date_1;
												start_end_date[1] = test_date_2;

												CALLAPI(WSOM_status_clear_effectivities (status2));
												CALLAPI(WSOM_effectivity_create_with_dates(status2, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
												CALLAPI(AOM_save(eff_d));
												CALLAPI(AOM_save(status2));
												CALLAPI(AOM_refresh(status2,0));
											}*/

											releaseStatusFnd=0;
											ITKCALL(WSOM_ask_release_status_list(AssyTag,&st_count_dml,&status_list));
											for (iLCS=0;iLCS<st_count_dml ;iLCS++ )
											{
												ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&releasest_name));
												printf("\n in std dml releasest_name: %s\n",releasest_name);fflush(stdout);
												if(tc_strcmp(releasest_name,lcsToset)==0)
												{
													releaseStatusFnd++;
												}
											}

											printf("\n\n\t\t in std dml  releaseStatusFnd := %d", releaseStatusFnd);fflush(stdout);
											printf("\n\n\t\t DMLtype := %s", DMLtype);fflush(stdout);
											if(releaseStatusFnd==0)
											{
												if( (tc_strcmp(DMLtype,"AMDML")!=0) || (!strstr(TaskName,"NONERC")) ) //Added in TZ1.43
												{
													if(tc_strcmp(DMLtype,"WT")!=0)//WT Chnages
													{
														printf("\n\n\t\t in function std_dml_release attached to WT DML parts  WTlcsToset := %s", WTlcsToset);fflush(stdout);
														status = t5UpdateLifecycleStateSTD(AssyTag, WTlcsToset,lcsToremove);
													}
													else
													{
													status = t5UpdateLifecycleStateSTD(AssyTag, lcsToset,lcsToremove);
													}
												
												}
											}
										}
									}
								}

								taskreleaseStatusFnd=0;
								ITKCALL(WSOM_ask_release_status_list(TaskRevTag,&task_st_count,&task_status_list));
								
								for (taskLCS=0;taskLCS<task_st_count ;taskLCS++ )
								{
									ITKCALL(AOM_ask_value_string(task_status_list[taskLCS],"object_name",&task_releasest_name));
									printf("\n task_releasest_name: %s\n",task_releasest_name);fflush(stdout);
									if(tc_strcmp(task_releasest_name,lcsToset)==0)
									{
										taskreleaseStatusFnd++;
									}
								}

								ITKCALL(AOM_UIF_ask_value(TaskRevTag,"date_released",&ClosureDate));
								printf("\n ClosureDate : %s\n",ClosureDate);fflush(stdout);//28-Oct-2017 14:12

								printf("\n\n\t\t taskreleaseStatusFnd := %d", taskreleaseStatusFnd);fflush(stdout);
								if(taskreleaseStatusFnd==0)
								{
									status = t5UpdateLifecycleStateSTD(TaskRevTag, lcsToset,lcsToremove);
								}

								if(tc_strlen(ClosureDate)>2)
								{
									printf("\n Task already has closure time stamp stamped on it");fflush(stdout);
								}
								else
								{
									printf("\n Stamping Closure time stamp on task");fflush(stdout);

								getCurrentDateTime(cCurrentAccessDate1);
								printf("\n For STD DML Task  cCurrentAccessDate1:%s",cCurrentAccessDate1);fflush(stdout);
								ITKCALL(ITK_string_to_date(cCurrentAccessDate1, &Task_Release_date ));

								CALLAPI(AOM_lock(TaskRevTag));
								CALLAPI(POM_attr_id_of_attr("date_released","T5_APLTaskRevision",&TaskClosureDtAttrId));
								CALLAPI(AOM_refresh(TaskRevTag,TRUE));
								CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
								CALLAPI(POM_set_attr_date(1,&TaskRevTag,TaskClosureDtAttrId,Task_Release_date));

								CALLAPI(AOM_save(TaskRevTag));
								CALLAPI(AOM_unlock(TaskRevTag));
								}


							}
						  }  /// Solution Item end

						dmlreleaseStatusFnd=0;
		
						ITKCALL(WSOM_ask_release_status_list(DMLTag,&dml_st_count,&dml_status_list));
						for (dmlLCS=0;dmlLCS<dml_st_count ;dmlLCS++ )
						{
							ITKCALL(AOM_ask_value_string(dml_status_list[dmlLCS],"object_name",&dml_releasest_name));
							printf("\n dml_releasest_name: %s\n",dml_releasest_name);fflush(stdout);
							if(tc_strcmp(dml_releasest_name,lcsToset)==0)
							{
								dmlreleaseStatusFnd++;
							}
						}

						printf("\n\n\t\t dmlreleaseStatusFnd := %d", dmlreleaseStatusFnd);fflush(stdout);
						if(dmlreleaseStatusFnd==0)
						{
							status = t5UpdateLifecycleStateSTD(DMLTag, lcsToset,lcsToremove);
						}
						
						getCurrentDateTime(cCurrentAccessDate);
						printf("\n For DML cCurrentAccessDate:%s",cCurrentAccessDate);fflush(stdout);
						ITKCALL(ITK_string_to_date(cCurrentAccessDate, &DML_Release_date ));

						CALLAPI(AOM_lock(DMLTag));
						CALLAPI(POM_attr_id_of_attr("date_released","T5_APLDMLRevision",&DMLClosureDtAttrId));
						CALLAPI(POM_attr_id_of_attr("CMClosure","T5_APLDMLRevision",&Closure)); //1.43
						CALLAPI(POM_attr_id_of_attr("CMMaturity","T5_APLDMLRevision",&Maturity));//1.43
						CALLAPI(POM_attr_id_of_attr("CMDisposition","T5_APLDMLRevision",&Disposition));//1.43
						CALLAPI(AOM_refresh(DMLTag,TRUE));
						CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
						CALLAPI(POM_set_attr_date(1,&DMLTag,DMLClosureDtAttrId,DML_Release_date));
						if(POM_set_attr_string(1,&DMLTag,Closure ,"Closed"));//1.43
						if(POM_set_attr_string(1,&DMLTag,Maturity,"Complete"));//1.43
						if(POM_set_attr_string(1,&DMLTag,Disposition,"Approved"));//1.43
						
						CALLAPI(AOM_save(DMLTag));
						CALLAPI(AOM_unlock(DMLTag));

					 }

	}else
	   {
	     	printf("\n No proper class class T5_APLDMLRevision......\n");fflush(stdout);
	   }

	return error_code;
}

int pr_task_stamping( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
	char* WTlcsToset=NULL;//WT changes
    char* lcsToset=NULL;
    char* lcstoremove=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *itemid 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;


	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	tag_t			tsk_dml_rel_type    = NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	int				jj					= 0;
	int				countDml			= 0;
	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t			Fndrelation			= NULLTAG;
	tag_t			DMLRevTag			= NULLTAG;
	tag_t			class_id1			= NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char **DesignGroupList;
	char *class_name1= NULL;
	char   type_name[TCTYPE_name_size_c+1];
	char*	 DMLtype		= NULL;
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;
	date_t Release_date;
	
	WTlcsToset =(char *) MEM_alloc(20 * sizeof(char *));//WT Changes
	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
	lcstoremove =(char *) MEM_alloc(20 * sizeof(char *));

	int		prtreleaseStatusFnd		=	0;
	int		prt_st_count			=	0;
	tag_t	*prt_status_list		=	NULLTAG;
	int		dmlLCS					=	0;
	char	*dml_releasest_name		=	NULL;

    printf("\n **************inside pr_task_stamping***************\n ");fflush(stdout);

   	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}


	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n pr_task_stamping \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		TaskRevTag = attachments[0];
		if(TCTYPE_ask_object_type(TaskRevTag,&objTypeTag));
    	if(TCTYPE_ask_name(objTypeTag,type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

		AOM_ask_value_string( TaskRevTag, "item_id", &itemid);
		char LcsStdWrkg[40];
		char LcsStdRlzd[40];

		GetPlantWiseRelStat(itemid,LcsStdWrkg,LcsStdRlzd);
		printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
		printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);

		strcpy(WTlcsToset,"Obsolete");//WT changes
		strcpy(lcsToset,LcsStdRlzd);
		strcpy(lcstoremove,LcsStdWrkg);


						   

	if(strcmp(type_name,"T5_APLTaskRevision")==0)
	{
		    printf("\n inside class T5_APLTaskRevision......\n");fflush(stdout);
			AOM_ask_value_string( TaskRevTag, "item_id", &item_id);
			AOM_ask_value_string( TaskRevTag, "current_id", &DML_no);
			AOM_ask_value_strings(TaskRevTag,"t5_crdesigngroup",&num,&DesignGroupList);
			AOM_ask_value_string( TaskRevTag, "t5_cprojectcode", &Proj_Code);

			printf("\n Proj_Code : %s\n",Proj_Code);fflush(stdout);
			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n DML_no : %s\n",DML_no);fflush(stdout);
			printf("\n num is : %d\n",num);fflush(stdout);

			//Added by Priti TZ 1.43 //DO not stamp Part if DML of AMDML type or change type is NONERC

			
				ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
				if (tsk_dml_rel_type!=NULLTAG)
				{
					ITKCALL(GRM_list_primary_objects_only(TaskRevTag,tsk_dml_rel_type,&countDml,&DMLRevision));
					printf("\n\t\t APL DML Revision from Task : %d",countDml); fflush(stdout);
				}


				for (jj=0;jj<countDml;jj++ )
				{
					DMLRevTag = DMLRevision[j];

					ITKCALL(POM_class_of_instance(DMLRevTag,&class_id1));
					ITKCALL(POM_name_of_class(class_id1,&class_name1));
					printf("\n\t class_name found1 :%s",class_name1); fflush(stdout);

					if(tc_strcmp(class_name1,"T5_APLDMLRevision")==0)
					{
						ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_EcnType",&DMLtype));
						printf("\n\t APLDMLtype is :%s",DMLtype); fflush(stdout);
						break;
					}

				}
				//******************************************Added by Priti ENDS****************************//
        	                      
						   //CALLAPI(AOM_set_value_string(TaskRevTag,"CMClosureDate",cCurrentAccessDate));

						// CALLAPI(AOM_lock(TaskRevTag));
						// CALLAPI(AOM_set_value_date	(TaskRevTag,"date_released",Release_date));
						// CALLAPI(AOM_save(TaskRevTag));
						// CALLAPI(AOM_unlock(TaskRevTag));
						 
								//Part Stamping
		    					PartCnt=0;
								CALLAPI(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
								printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
								if (PartCnt>0)
								{
									GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
									for (k=0;k<PartCnt ;k++ )
									{
										printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
										AssyTag=PartTags[k];

										CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
										printf("\n\n\t\t APL DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);

										if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
										if(TCTYPE_ask_name2(objTypeTag,&type_name1));
										printf("\n\n\t\t APL DML Cre:AssyTag type_name1 := %s", type_name1);fflush(stdout);

										CALLAPI(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
										printf("\n\n\t\t APL DML Cre:AssyTag PartTypeStr := %s", PartTypeStr);fflush(stdout);

										if (tc_strcmp(type_name1,"Design Revision")==0 || tc_strcmp(type_name1,"Part Revision")==0 || tc_strcmp(type_name1,"Colour Part Revision")==0 )//Colour part type added Hemal
										{
											//Added By Dhanashri for skip prev rev UATZ1.42//
											 char*			SkipPrevRevSTD				= NULL;
											 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
											 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
											 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
												
												//if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
												if(tc_strlen(SkipPrevRevSTD)>0)
												{
													printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
													continue;
												}
											//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//
											//Check LCS if released not to go for stamping
											//Hemal Start
											prtreleaseStatusFnd=0;
		
											ITKCALL(WSOM_ask_release_status_list(AssyTag,&prt_st_count,&prt_status_list));
											for (dmlLCS=0;dmlLCS<prt_st_count ;dmlLCS++ )
											{
												ITKCALL(AOM_ask_value_string(prt_status_list[dmlLCS],"object_name",&dml_releasest_name));
												printf("\n dml_releasest_name: %s\n",dml_releasest_name);fflush(stdout);
												if(tc_strcmp(dml_releasest_name,lcsToset)==0)
												{
													prtreleaseStatusFnd++;
												}
											}

											printf("\n\n\t\t prtreleaseStatusFnd := %d", prtreleaseStatusFnd);fflush(stdout);
											
											printf("\n\n\t\t DMLtype := %s", DMLtype);fflush(stdout);
											if (prtreleaseStatusFnd==0)
											{
												if( (tc_strcmp(DMLtype,"AMDML")!=0) || (!strstr(item_id,"NONERC")) ) //Added in TZ1.43
												{
													if(tc_strcmp(DMLtype,"WT")!=0)//WT Changes
													{
														printf("\n\n\t\t in function pr_task_stamping attached to WT DML parts  WTlcsToset := %s", WTlcsToset);fflush(stdout);
														status = t5UpdateLifecycleStateSTD(AssyTag, WTlcsToset,lcstoremove);
													}
													else
													{
														status = t5UpdateLifecycleStateSTD(AssyTag, lcsToset,lcstoremove);
													}														
													
												}
											}
											//Hemal Ends
										}
									}
								}

						
						//Task Stamping

						getCurrentDateTime(cCurrentAccessDate);
						printf("\n cCurrentAccessDate:%s",cCurrentAccessDate);
						CALLAPI(ITK_string_to_date(cCurrentAccessDate, &Release_date ));

						 //CALLAPI(ITK_set_bypass(TRUE));
							tag_t  DtRlzd = NULLTAG;
							tag_t  Closure = NULLTAG;
							tag_t  Maturity = NULLTAG;
							tag_t  Disposition = NULLTAG;
							
						   CALLAPI(AOM_lock(TaskRevTag));
						   CALLAPI(POM_attr_id_of_attr("date_released","T5_APLTaskRevision",&DtRlzd));
						   CALLAPI(POM_attr_id_of_attr("CMClosure","T5_APLTaskRevision",&Closure));
						   CALLAPI(POM_attr_id_of_attr("CMMaturity","T5_APLTaskRevision",&Maturity));
						   CALLAPI(POM_attr_id_of_attr("CMDisposition","T5_APLTaskRevision",&Disposition));

						   if(AOM_refresh(TaskRevTag,TRUE));
						   if(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
						   if(POM_set_attr_date(1,&TaskRevTag,DtRlzd,Release_date));
						   if(POM_set_attr_string(1,&TaskRevTag,Closure,"Closed"));
						   if(POM_set_attr_string(1,&TaskRevTag,Maturity,"Complete"));
						   if(POM_set_attr_string(1,&TaskRevTag,Disposition,"Approved"));

						   //CALLAPI(AOM_set_value_string(TaskRevTag,"CMClosure","Closed"));
						   //CALLAPI(AOM_set_value_string(TaskRevTag,"CMMaturity","Complete"));
						   //CALLAPI(AOM_set_value_string(TaskRevTag,"CMDisposition","Approved"));

						   if(AOM_save(TaskRevTag));
						   if(AOM_refresh(TaskRevTag,TRUE));
						   CALLAPI(AOM_save(TaskRevTag));
						   CALLAPI(AOM_unlock(TaskRevTag));

						   printf("\n date set to ...cCurrentAccessDate:%s",cCurrentAccessDate);
							
							//Hemal Start
						   prtreleaseStatusFnd=0;
		
							ITKCALL(WSOM_ask_release_status_list(TaskRevTag,&prt_st_count,&prt_status_list));
							for (dmlLCS=0;dmlLCS<prt_st_count ;dmlLCS++ )
							{
								ITKCALL(AOM_ask_value_string(prt_status_list[dmlLCS],"object_name",&dml_releasest_name));
								printf("\n dml_releasest_name: %s\n",dml_releasest_name);fflush(stdout);
								if(tc_strcmp(dml_releasest_name,lcsToset)==0)
								{
									prtreleaseStatusFnd++;
								}
							}

							printf("\n\n\t\t prtreleaseStatusFnd := %d", prtreleaseStatusFnd);fflush(stdout);

							if(prtreleaseStatusFnd==0)
							{
							   status = t5UpdateLifecycleStateSTD(TaskRevTag, lcsToset,lcstoremove);
							}
							//Hemal Ends
						   
		}
		else
		   {
				printf("\n No proper class class T5_APLDMLRevision......\n");fflush(stdout);
		   }

	return error_code;
}

int AMDML_Bypass_Checks(tag_t Task_Tag)
{
	int			count				= 0;
	int			j					= 0;

	char		*DmlName			= NULL;
	char		*DmlEcn				= NULL;
	char		*TaskName			= NULL;

	tag_t		tsk_dml_rel_type	= NULLTAG;
	tag_t		DMLRevTag			= NULLTAG;

	tag_t*		DMLRevision			= NULLTAG;

	logical		is_latest;	

	printf("\n Inside AMDML_Bypass_Checks");fflush(stdout);

	ITKCALL(AOM_ask_value_string(Task_Tag, "item_id",&TaskName));
	printf("\n TaskName %s.....\n",TaskName);

	if(tc_strstr(TaskName,"AM"))
	{
		ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
		if (tsk_dml_rel_type!=NULLTAG)
		 {

			ITKCALL(GRM_list_primary_objects_only(Task_Tag,tsk_dml_rel_type,&count,&DMLRevision));
			printf("\n\n\t\t DML Revision from Task : %d",count);fflush(stdout);		//task to dml

			for (j=0;j<count ;j++ )
			{
				ITKCALL(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
				printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);

				if(is_latest != true)
				{
					printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
				}else
				{
					DMLRevTag = DMLRevision[j];//DML

					ITKCALL(AOM_ask_value_string(DMLRevTag, "item_id",&DmlName));
					printf("\n DmlName %s.....\n",DmlName);

					ITKCALL(AOM_ask_value_string(DMLRevTag, "t5_EcnType",&DmlEcn));
					printf("\n DmlEcn %s.....\n",DmlEcn);

					if(tc_strcmp(DmlEcn,"AMDML")==0)
					{
						printf("\n Bypass Validations as AMDML of type AM");fflush(stdout);
						return 1;
					}
					else
					{
						printf("\n Call all Validations as AMDML is not of type AM");fflush(stdout);
						return 0;
					}
				}
			}
		 }
	}
	else
	{
		printf("\n Given task is not of AMDML");fflush(stdout);
		return 0;
	}
        		
	           

	return 0;

}


int Save_APLTask_Msg( METHOD_message_t *msg, va_list  args )
{

    tag_t	TaskTag		= va_arg(args, const tag_t);

	tag_t	EM_Tag				= NULLTAG;
	tag_t	DeptHead_Tag		= NULLTAG;
	tag_t	participant_type	= NULLTAG;
	tag_t	participant_tag		= NULLTAG;
	tag_t	relation_type		= NULLTAG;
	tag_t	relation			= NULLTAG;
	tag_t	participant_type2	= NULLTAG;
	tag_t	participant_type3	= NULLTAG;
	tag_t	participant_type4	= NULLTAG;
	tag_t	participant_type5	= NULLTAG;
	tag_t	participant_tag2	= NULLTAG;
	tag_t	participant_tag3	= NULLTAG;
	tag_t	participant_tag4	= NULLTAG;
	tag_t	participant_tag5	= NULLTAG;
	tag_t	relation_type2		= NULLTAG;
	tag_t	relation2			= NULLTAG;
	tag_t	objTypeTag			= NULLTAG;
	tag_t	objTypeTag2			= NULLTAG;
	tag_t	objTypeTag3			= NULLTAG;
	tag_t	objTypeTag4			= NULLTAG;
	tag_t	CR_rel_type			= NULLTAG;
	tag_t	CR_Asgn_Part		= NULLTAG;
	tag_t	ObjTypCR			= NULLTAG;
	tag_t	Grp_tag				= NULLTAG;
	tag_t	Grp_tag1			= NULLTAG;
	tag_t	Grp_tag2			= NULLTAG;
	tag_t	Grp_tag3			= NULLTAG;
	tag_t	CR_GrHd_Tag			= NULLTAG;
	tag_t	CR_GrHd_Tag1			= NULLTAG;
	tag_t	CR_GrHd_Tag2			= NULLTAG;
	tag_t	CR_EM_Tag			= NULLTAG;

	int		error_code	= ITK_ok;
	int		ifail		= 0; 
	int		Relcount	= 0; 
	int		jk			= 0; 
	int		No_EM		= 0; 
	int		iii			= 0; 
	int		ii			= 0; 
	int		ij			= 0; 
	int		No_GH		= 0; 
	int		No_GH1		= 0; 
	int		No_GH2		= 0; 
	
	char *itemid 			= NULL;
	char *PRTaskRlzd 			= NULL;
	char *ChangeType 			= NULL;
	char *EstPlanner 	   = NULL;
	char *EstReviewer 	   = NULL;
	char *EstPlntName 	   = NULL;
	char *CR_PlantName 	   = NULL;
	char *CR_GrpHead 	   = NULL;
	char *CRAssignee 	   = NULL;
	char *groupName 	   = NULL;
	char *PsdRoleName 	   = NULL;
	char *member_name 	   = NULL;
	char *member_name1 	   = NULL;
	char *member_name2 	   = NULL;
char*			PRTaskCreator				= NULL;

	//const char*   CR_EM_role = "CR_ERC_EM";
	const char*   ES_Planner_role = "ES_Planner";
	const char*   ES_Reviewer_role = "ES_Reviewer";

	tag_t *tags_found = NULL;
	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t* RelCRTags = NULLTAG;
	tag_t*  EMTags		= NULLTAG;
	tag_t*  GHTags		= NULLTAG;
	tag_t*  GHTags1		= NULLTAG;
	tag_t*  GHTags2		= NULLTAG;

	char   type_name[TCTYPE_name_size_c+1];
	char   type_name1[TCTYPE_name_size_c+1];
	char   type_name2[TCTYPE_name_size_c+1];
	char   type_name3[TCTYPE_name_size_c+1];
	char   userid[SA_user_size_c+1];
	WSO_search_criteria_t  	criteria;

	groupName = (char	*)MEM_alloc(100);
	PsdRoleName = (char	*)MEM_alloc(100);
	tc_strcpy(groupName,"EstimateSheet_WF");
	printf("\n MT: groupName  --> %s\n",groupName);   fflush(stdout);

    printf("\n **************inside Save_CR_Msg***************\n ");fflush(stdout);

	if(TCTYPE_ask_object_type(TaskTag,&objTypeTag));
	if(TCTYPE_ask_name(objTypeTag,type_name));
	printf("\n type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

	AOM_ask_value_string( TaskTag, "item_id", &itemid);
	printf("\n itemid     %s\n", itemid);fflush(stdout);

	//AOM_ask_value_logical( TaskTag,"t5_PrTaskRelSTD", &PRTaskRlzd);
	//printf("\n PRTaskRlzd     %s\n", PRTaskRlzd);fflush(stdout);

	//AOM_ask_value_string( TaskTag, "t5_b2changetype", &ChangeType);
	//printf("\n ChangeType     %s\n", ChangeType);fflush(stdout);

	//if(strcmp(type_name,"T5_APLTaskRevision")==0  &&  strcmp(PRTaskRlzd,"True")==0  && strcmp(ChangeType,"PR")==0 && tc_strstr(itemid,"_PR")!=NULL)
	if(strcmp(type_name,"T5_APLTaskRevision")==0  && tc_strstr(itemid,"_PR")!=NULL)
	{
		printf("\n inside PR Task created by User... ");fflush(stdout);

		 //printf("\n Test1 ");   fflush(stdout);
		 //AssignSTDAnalystPR(TaskTag);

		 printf("\n Test2 ");   fflush(stdout);
		 AssignSTDReviewerPR(TaskTag);

	}
    return error_code;
}


extern EPM_decision_t DLLAPI std_dml_signoff_checks_Func(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int status;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int count_child = 0;
	int   attribute_act_tak;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char *Item_id = NULL;
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	int i = 0;
	int j = 0;
	int n = 0;
	int stampingdone=0;
	int iGChld = 0;
	char*	itemid;
	char *  ChildRelErr = NULL;
	char *  SetStdRelErr = NULL;
	char * SetPrevRevNotification=NULL;
	char*	childPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char  type_name[TCTYPE_name_size_c+1];

	char  type_itemRev[TCTYPE_name_size_c+1];
	char  ChildRevtype_name[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Childtop_line							= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag							= NULLTAG;
	tag_t	itemTypeTag_cdss							= NULLTAG;
	tag_t	*itemclassp	= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t	value_child_details							= NULLTAG;
	char  req_id[ITEM_id_size_c+1];
	tag_t  *children;
	tag_t  *totalchildren;
	tag_t  	value_act_Tak;
	tag_t  	item_rev_cld_tag;
	tag_t*			PartTags			= NULLTAG;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				ii				= 0;
	char*			value					=NULL;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	char*			Part_no				= NULL;
	int       st_count=0;
	int       iLCS=0;
	int       cntLcs=0;
	int				BypassNACSFlag=0;
	int				BypassAMDMLFlag=0;
	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	char STDDmlPlnt[40];
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
	char *lcsToset=NULL;
   cnt = 0;
  cntFlag = 0;
char	**SetGMErr = NULL;
int icount1=0;
	char	*tempErr	=	0;//1.45 added for dynamic memory allocation
	int		iLength	=	0;//1.45 added for dynamic memory allocation


//Added By Dhanashri For Gate Maturation DML Validation at STDSI UATZ 1.45//
	tag_t*			RefPartTags			= NULLTAG;
	int				RefPartCnt				= 0;
//End of Code Added By Dhanashri For Gate Maturation DML Validation at STDSI UATZ 1.45//

	char RevisionRule[40];
	char ClosureRule[40];
	char BVR[40];
	char APLDmlPlnt[40];
	char *task_po_check=NULL;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

SetGMErr = (char**)MEM_alloc( 1 * sizeof *SetGMErr );

	printf("\n Calling std_dml_signoff_checks_Func %d.....\n",iNumAttch);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n std_dml_signoff_checks_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

	getPlantDetailsAttr_Std(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency,RevisionRule,ClosureRule,BVR,APLDmlPlnt,STDDmlPlnt);//TZ1.41
	printf("\n PlantCS %s \n",PlantCS);
	printf("\n PlantOptCS %s \n",PlantOptCS);
	printf("\n PlantAgency %s \n",PlantIA);
	printf("\n PlantStore %s \n",PlantStore);
	printf("\n UserAgency %s \n",UserAgency);
	printf("\n STDDmlPlnt %s \n",STDDmlPlnt);

     if(tc_strcmp(CurrentTask,"Create EPA" )==0)
	{
 	ITKCALL( TCTYPE_find_type("T5_APLTaskRevision", NULL, &ItemTypeTag));

	printf("\n iNumAttch %d.....\n",iNumAttch);
	for (i=0; i < iNumAttch; i++)
	{
		tag_t objTypeTag = NULLTAG;
		tag_t objChildRevTag = NULLTAG;

		const char *qry_entries[1];
		const char *qry_values[1];

//		char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
//		char **values = (char **) MEM_alloc(1 * sizeof(char *));

		int n_tags_found=0;

		 tag_t	*itemclass							= NULLTAG;

		  tag_t item = NULLTAG;

		ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
		printf("\n itemid %s.....\n",itemid);
		qry_entries[0] ="item_id";
		qry_values[0] = itemid;

		ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
		 item = itemclass[0];
		if(item != NULLTAG )
		ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

		printf("\n itemid %s \n",itemid);
		ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
		ITKCALL( TCTYPE_ask_name( objTypeTag, type_name) );
		printf("\t  type_name ...%s\n", type_name);
		if( objTypeTag == ItemTypeTag )
		{
			printf("\t \n objTypeTag == ItemTypeTag \n");

			ITKCALL (TCTYPE_ask_object_type(item_rev_tag,&itemTypeTag_cdss));
			ITKCALL (TCTYPE_ask_name(itemTypeTag_cdss,type_itemRev));

			printf("\t  type_itemRev ...%s\n", type_itemRev);
			if (!SetStdRelErr) MEM_free(SetStdRelErr);
			SetStdRelErr=(char *)MEM_alloc(5000);
            tc_strcpy(SetStdRelErr,"");

				if (!SetPrevRevNotification) MEM_free(SetPrevRevNotification);
				SetPrevRevNotification=(char *)MEM_alloc(5000);
				tc_strcpy(SetPrevRevNotification,"");

			if(tc_strcmp(type_itemRev,"T5_APLTaskRevision" )==0)
			{
			  // Code Added by Dhanashri to get DML from Task////
			  tag_t			TskToDMLRel= NULLTAG;
			  tag_t			DMLRevTagg		= NULLTAG;
			  tag_t			DMLTypeTag		= NULLTAG;
			  tag_t*			DMLTagg		= NULLTAG;

			  int CountDML=0;
			  int Counter=0;

			  logical			isltstdmll;

			  char			DMLTyp[TCTYPE_name_size_c+1];
			  char*			ProjectCode				= NULL;
			  char*			Release_Type				= NULL;

				printf("\n\n\t\t Test dss .. ");fflush(stdout);
				ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &TskToDMLRel));
				if (TskToDMLRel!=NULLTAG)
				{
					ITKCALL(GRM_list_primary_objects_only(item_rev_tag,TskToDMLRel,&CountDML,&DMLTagg));
					printf("\n\n\t\t dss CountDML : %d",CountDML);fflush(stdout);

					for (Counter=0;Counter<CountDML ;Counter++ )
					{
						ITKCALL(ITEM_rev_sequence_is_latest(DMLTagg[Counter],&isltstdmll));
						printf("\n\n\t\t isltstdmll : %d\n",isltstdmll);fflush(stdout);

						if(isltstdmll != true)
						{
							printf("\n\n\t\t isltstdmll is not true .....\n");fflush(stdout);
						}else
						{
							printf("\n\n\t\t isltstdmll is  true .....\n");fflush(stdout);
							DMLRevTagg = DMLTagg[Counter];

							ITKCALL (TCTYPE_ask_object_type(DMLRevTagg,&DMLTypeTag));
							ITKCALL (TCTYPE_ask_name(DMLTypeTag,DMLTyp));
							printf("\n\n\t\t isltstdmll is  true test .....\n");fflush(stdout);

							if(tc_strcmp(DMLTyp,"T5_APLDMLRevision")==0)
							{
							  AOM_ask_value_string( DMLRevTagg, "t5_cprojectcode", &ProjectCode);
  							  printf("\n ProjectCode : %s\n",ProjectCode);fflush(stdout);

							  ITKCALL(AOM_ask_value_string(DMLRevTagg,"t5_rlstype",&Release_Type));
							  printf("\n\t Release_Type is :%s",Release_Type);fflush(stdout);
																					
							}
						}
					}
				}


			  //End Of Code Added by Dhanashri ////

			  	//Added By Dhanashri For Gate Maturation DML Validation at STDSI UATZ 1.45//
				  printf("\n\t Release_Type is :%s",Release_Type);fflush(stdout);

	   if(tc_strcmp(Release_Type,"TODR")==0)
	  // if(tc_strcmp(Release_Type,"DL")==0)
	     {
			RefPartCnt=0;
			RefPartTags=NULLTAG;
		    ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMReferences",&RefPartCnt,&RefPartTags));
			printf("\n\n\t\t Number of partnumbers in GM DML Task :%d",RefPartCnt);fflush(stdout);
			
			GMDML_Part_Release_Check_STD(RefPartCnt,RefPartTags,&SetGMErr,&icount1,itemid);

			if(cntFlag==1)
			 {
							iLength	=	0;
							if (!tempErr) MEM_free(tempErr);
							i=0;
							for (i=0; i < icount1; i++)
							{
								//printf("%s",SetChildRelErr[i]);fflush(stdout);
								tempErr	=	SetGMErr[i];
								iLength	=	iLength	+	tc_strlen(tempErr);
							}
							printf("iLength : %d",iLength);fflush(stdout);
							if (!tempErr) MEM_free(tempErr);
							tempErr	=	(char *)MEM_alloc(iLength+20);
							i=0;
							for (i=0; i < icount1; i++)
							{
								//printf("%s",SetChildRelErr[i]);fflush(stdout);
								if(i==0)
									tc_strcpy(tempErr,SetGMErr[i]);
								else
									tc_strcat(tempErr,SetGMErr[i]);
							}
							printf("\nPrinting Errors...!!!");fflush(stdout);
							printf("%s",tempErr);fflush(stdout);
							EMH_clear_errors();
							status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
							decision = EPM_nogo;
							return ITK_errStore;
			 }

		 }
    //End Of Code Added By Dhanashri For Gate Maturation DML Validation at STDSI UATZ 1.45//
		else
		  {
    		ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCnt,&PartTags));
			printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);

			//ADDED BY DHANASHRI TZ1.41 FOR PR TASK VALIDATION//
				char *changetype		=NULL;

				ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_b2changetype",&changetype));
				printf("\n\t hi changetype is :%s",changetype); fflush(stdout);

				//if( (tc_strstr(itemid,"_PR")!=NULL) && (tc_strcmp(changetype,"PR" )==0) && PartCnt==0 )
				if( (tc_strstr(itemid,"_PR")!=NULL) && (PartCnt==0) && (tc_strcmp(changetype,"PR" )==0) )
					{
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"PR Task Should Have Atleast One Part");
						return ITK_errStore1;
					}
			//END OF CODE ADDED BY DHANASHRI TZ1.41 FOR PR TASK VALIDATION//


			//##############Bypass All the validations if AMDML of type AM###############//
			BypassAMDMLFlag = AMDML_Bypass_Checks(item_rev_tag);
			printf("\t  BypassAMDMLFlag ...%d\n", BypassAMDMLFlag);	
		
			if(BypassAMDMLFlag==1)
			{
				printf("\n Bypass all validations as AMDML of type AM");fflush(stdout);
				goto BYPASSVALIDATIONS;
			}
			else
			{
				printf("\n Call all validations as DML is not of type AM");fflush(stdout);
			}
			//############################################################################//

			if (PartCnt>0)
			{
				GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
				printf("\n\n\t\t for k =:%d",k);fflush(stdout);

				printf("\n cntFlag_1: %d",cntFlag);fflush(stdout);

				AMDML_Std_Validation(PartCnt,item_rev_tag,PartTags,SetStdRelErr); //TZ1.42--Deepti
		        printf("\n cntFlag_2: %d",cntFlag);fflush(stdout);

				//**********TZ3.46*********************//				
				char LcsStdWrkg[40];
				char LcsStdRlzd[40];

				GetPlantWiseRelStat(itemid,LcsStdWrkg,LcsStdRlzd);
				printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
				printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);
				strcpy(lcsToset,LcsStdRlzd);
			//***********************************//

//				if(tc_strcmp(roleName,"STDP")==0)
//				{
//					strcpy(lcsToset,"T5_LcsStdpRlzd");
//				}
//				else if(tc_strcmp(roleName,"STDD")==0)
//				{
//					strcpy(lcsToset,"T5_LcsStddRlzd");
//				}
//				else if(tc_strcmp(roleName,"STDC")==0)
//				{
//					strcpy(lcsToset,"T5_LcsStdRlzd");
//					
//				}
//				else if(tc_strcmp(roleName,"STDJ")==0)
//				{
//					strcpy(lcsToset,"T5_LcsStdjRlzd");
//				}
//				else if(tc_strcmp(roleName,"STDL")==0)
//				{
//					strcpy(lcsToset,"T5_LcsStdlRlzd");
//				}
//				else if(tc_strcmp(roleName,"STDA")==0)
//				{
//					strcpy(lcsToset,"T5_LcsStdaRlzd");
//				}
//				else if((tc_strcmp(roleName,"STDU")==0))
//				{
//					strcpy(lcsToset,"T5_LcsStduRlzd");
//				}
//				else
//				{
//					strcpy(lcsToset,"T5_LcsStdRlzd");
//				}

                Child_std_validation(PartCnt,item_rev_tag, PartTags,lcsToset,SetStdRelErr,RevisionRule,ClosureRule,BVR); //TZ1.42--Deepti
		        printf("\n cntFlag_3: %d",cntFlag);fflush(stdout);

				STD_Two_Rev_Same_Day_Checks_P(PartCnt,PartTags,SetStdRelErr,itemid);
                printf("\n cntFlag_4: %d",cntFlag);fflush(stdout);

				Next_Rev_Gt_DR3_Exists_Check(PartCnt,PartTags,SetStdRelErr,itemid);
                printf("\n cntFlag_5: %d",cntFlag);fflush(stdout);

				CheckforColBasicDMLReleaseSTD(PartCnt,item_rev_tag, PartTags,lcsToset,SetStdRelErr); 
		        printf("\n cntFlag_6: %d",cntFlag);fflush(stdout);

				Prev_Rev_Checks_SMDML(PartCnt,PartTags,SetStdRelErr,itemid,ProjectCode,STDDmlPlnt);

				//Prev_Rev_Checks(PartCnt,PartTags,SetPrevRevNotification,itemid,ProjectCode);
                //printf("\n cntFlag_6: %d",cntFlag);fflush(stdout);


		 } //End for Part
		 
		   printf("\n SetStdRelErr: %s\n",SetStdRelErr);fflush(stdout);
			//if (tc_strcmp(SetChildRelErr,"NULL")!=0)
			if(cntFlag==1)
			{
				printf("\n All Child Part is not Released  Error %s \n",SetStdRelErr);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,SetStdRelErr);
				//printf("\n All Child Part is not TCM Released  %s \n",SetChildRelErr);
				//status=EMH_store_error_s2(EMH_severity_error,ITK_errStore,SetChildRelErr ,"Child Part Release Error");
				decision = EPM_nogo;
				return ITK_errStore;
			}
			else //TZ1.42--DEEPTI
			{
				printf("\n Inside else of no error");fflush(stdout);
				if (PartCnt>0)
				{
					task_po_check=NULL;
					ITKCALL(AOM_ask_value_string( item_rev_tag, "t5_POCheckStatus", &task_po_check));
					printf("\n task_po_check.. %s \n",task_po_check);fflush(stdout);
					if(strcmp(task_po_check,"")==0)
					{
						EMH_clear_errors();
						status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Please run the PO check before Signoff the Task.\n Select the Task ->Go to ->Manufacturing Menu->Implementaion-->PO Checks");
						decision = EPM_nogo;
						return ITK_errStore;				
					}
					else if(strcmp(task_po_check,"POCHKFAIL")==0)
					{
						EMH_clear_errors();
						status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"PO Check fails.Please check the PO Report attached with Task. ");
						decision = EPM_nogo;
						return ITK_errStore;				
					}
					else if(strcmp(task_po_check,"POCHKPASS")==0)
					{
						//decision = EPM_go;
						//return decision;			
					}
					else
					{				
						//decision = EPM_go;
						//return decision;
					}

					Prev_Rev_Checks(PartCnt,PartTags,SetPrevRevNotification,itemid,ProjectCode);
					printf("\n SetPrevRevNotification: %s\n",SetPrevRevNotification);fflush(stdout);
					printf("\n tc_strlen(SetPrevRevNotification): %d\n",tc_strlen(SetPrevRevNotification));fflush(stdout);

					 if(tc_strlen(SetPrevRevNotification)>0)
							{
								printf("\n inside %s \n",SetPrevRevNotification);fflush(stdout);
								EMH_clear_errors();
								status=EMH_store_error_s1(EMH_severity_information,ITK_Prjerr,SetPrevRevNotification);
								printf("\n Test2");fflush(stdout);
								//decision = EPM_go;
							}
				}
				
			}
		}//else of if(tc_strcmp(Release_Type,"TODR")==0)
	  }
    }
  }
 }
 BYPASSVALIDATIONS:
	decision = EPM_go;
	return decision;
}

extern EPM_decision_t DLLAPI DRStatusCondition(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int status;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int count_child = 0;
	int   attribute_act_tak;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char *Item_id = NULL;
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	int i = 0;
	int j = 0;
	int n = 0;
	int stampingdone=0;
	int iGChld = 0;
	char*	itemid;
	char *  ChildRelErr = NULL;
	char *  SetStdRelErr = NULL;
	char*	childPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char  type_name[TCTYPE_name_size_c+1];

	char  type_itemRev[TCTYPE_name_size_c+1];
	char  ChildRevtype_name[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Childtop_line							= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag							= NULLTAG;
	tag_t	itemTypeTag_cdss							= NULLTAG;
	tag_t	*itemclassp	= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t	value_child_details							= NULLTAG;
	char  req_id[ITEM_id_size_c+1];
	tag_t  *children;
	tag_t  *totalchildren;
	tag_t  	value_act_Tak;
	tag_t  	item_rev_cld_tag;
	tag_t*			PartTags			= NULLTAG;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				ii				= 0;
	char*			value					=NULL;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	char*			Part_no				= NULL;
	int       st_count=0;
	int       iLCS=0;
	int       cntLcs=0;
	int				BypassNACSFlag=0;
	int				BypassAMDMLFlag=0;
	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	tag_t  CurrentRoleTag = NULLTAG;
	char       roleName[SA_name_size_c+1]  ;
   cnt = 0;
  cntFlag = 0;

char *DML_DRStatus		=NULL;
char *Proj_Code		=NULL;
char *EcnType		=NULL;
char *Rlztype		=NULL;
char *PlntPlnt		=NULL;
char   *frmplnt=NULL;
tag_t			DMLRevTag			= NULLTAG;
tag_t			tsk_dml_rel_type	= NULLTAG;

	printf("\n Calling DRStatusCondition %d.....\n",iNumAttch);fflush(stdout);


	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n DRStatusCondition \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);


	//getPlantDetailsAttr_Std(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency);
	//printf("\n PlantCS %s \n",PlantCS);fflush(stdout);
	//printf("\n PlantOptCS %s \n",PlantOptCS);fflush(stdout);
	//printf("\n PlantAgency %s \n",PlantIA);fflush(stdout);
	//printf("\n PlantStore %s \n",PlantStore);fflush(stdout);
	//printf("\n UserAgency %s \n",UserAgency);fflush(stdout);


	printf("\n iNumAttch %d.....\n",iNumAttch);fflush(stdout);
	for (i=0; i < iNumAttch; i++)
	{
		tag_t objTypeTag = NULLTAG;
		tag_t objChildRevTag = NULLTAG;

		const char *qry_entries[1];
		const char *qry_values[1];

//		char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
//		char **values = (char **) MEM_alloc(1 * sizeof(char *));

		int n_tags_found=0;

		 tag_t	*itemclass							= NULLTAG;

		  tag_t item = NULLTAG;
	tag_t*			ERCDMLRevision			= NULLTAG;
	int count1=0;
logical			is_latest; 



		ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
		printf("\n itemid %s.....\n",itemid);fflush(stdout);
		qry_entries[0] ="item_id";
		qry_values[0] = itemid;

		ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
		 item = itemclass[0];
		if(item != NULLTAG )
		ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

		ITKCALL( AOM_ask_value_string(item_rev_tag,"t5_cDRstatus",&DML_DRStatus))
		printf("\n DML_DRStatus Value :--------------------   %s\n",DML_DRStatus); fflush(stdout);

		ITKCALL( AOM_ask_value_string(item_rev_tag,"t5_cprojectcode",&Proj_Code))
		printf("\n Proj_Code Value :--------------------   %s\n",Proj_Code); fflush(stdout);

		ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_EcnType",&EcnType));
		printf("\n EcnType %s.....\n",EcnType);fflush(stdout);


					// CODE ADDED BY DHANASHRI //
					int cntt=0;
					int FlagGotProj=0;

					tag_t			CntrlTag		= NULLTAG;

					tag_t query1 = NULLTAG;
					int n_entries1=2;
					int n_found1=0;
  				    tag_t	*CntrlObjs	= NULLTAG;

					char *Info1 	   = NULL;

					char
					 *qry_entry[2] = {"SUBSYSCD", "SYSCD"},
					 *qry_vall[2] =  {"PROJ", "PREVREV"};

					ITKCALL(QRY_find("ControlObjQry", &query1));
					printf("\n After fins qryyy-- ");fflush(stdout);
					ITKCALL(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
					printf("\n n_found1: %d", n_found1);fflush(stdout);

					if(n_found1>0)
					{
						for (cntt = 0; cntt < n_found1; cntt++)
						{
							CntrlTag=NULLTAG;
							CntrlTag=CntrlObjs[cntt];

							AOM_ask_value_string( CntrlTag, "t5_Userinfo1", &Info1);
							printf("\n Info1: %s\n",Info1);fflush(stdout);

							if(tc_strcmp(Info1,Proj_Code)==0)
							{
								FlagGotProj=1;
								break;
							}
				
						}

					}

					printf("\n FlagGotProj: %d", FlagGotProj);fflush(stdout);

					// END OF CODE ADDED BY DHANASHRI //



if(tc_strcmp(EcnType,"XO")==0)
		{
		ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
		if (tsk_dml_rel_type!=NULLTAG)
		 {

			ITKCALL(GRM_list_primary_objects_only(item_rev_tag,tsk_dml_rel_type,&count1,&ERCDMLRevision));
			printf("\n\n\t\t DML Revision from Task : %d",count1);fflush(stdout);		//task to dml

			for (j=0;j<count1 ;j++ )
			{
				ITKCALL(ITEM_rev_sequence_is_latest(ERCDMLRevision[j],&is_latest));
				printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);

				if(is_latest != true)
				{
					printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
				}else
				{
					DMLRevTag = ERCDMLRevision[j];//DML

					ITKCALL(AOM_ask_value_string(DMLRevTag, "t5_rlstype",&Rlztype));
					printf("\n Rlztype %s.....\n",Rlztype);fflush(stdout);

					if(tc_strcmp(Rlztype,"XO")==0)
					{
						ITKCALL(AOM_ask_value_string(DMLRevTag, "t5_PlntToPlnt",&PlntPlnt));
						printf("\n PlntPlnt %s.....\n",PlntPlnt);fflush(stdout);

						if( (tc_strstr(PlntPlnt,"DR")!=NULL) || (tc_strstr(PlntPlnt,"DR")!=NULL) )
						{
						  printf("\n Inside DR AR ...");fflush(stdout);
						  //PlantName=subString(RoleName,5,3);
						  frmplnt=subString(PlntPlnt,7,3);
						   printf("\n frmplnt %s.....\n",frmplnt);fflush(stdout);

							if( (tc_strcmp(frmplnt,"DR4")==0)|| (tc_strcmp(frmplnt,"DR5")==0) || (tc_strcmp(frmplnt,"AR4")==0) || (tc_strcmp(frmplnt,"AR5")==0) || (tc_strcmp(frmplnt,"DR3P")==0) || (tc_strcmp(frmplnt,"AR3P")==0))
							{
									decision = EPM_go;
							}
							else if(FlagGotProj==1)
							{
								if( (tc_strcmp(frmplnt,"DR3")==0)|| (tc_strcmp(frmplnt,"AR3")==0) || (tc_strcmp(frmplnt,"DR4")==0)|| (tc_strcmp(frmplnt,"DR5")==0) || (tc_strcmp(frmplnt,"AR4")==0) || (tc_strcmp(frmplnt,"AR5")==0) || (tc_strcmp(frmplnt,"DR3P")==0) || (tc_strcmp(frmplnt,"AR3P")==0))
								{
										decision = EPM_go;
								}
							}
							else
							{
								decision = EPM_nogo;
							}

						}

					}
		
				}
			}
		 }
	}


		if( (tc_strcmp(DML_DRStatus,"DR4")==0)|| (tc_strcmp(DML_DRStatus,"DR5")==0) || (tc_strcmp(DML_DRStatus,"AR4")==0) || (tc_strcmp(DML_DRStatus,"AR5")==0) || (tc_strcmp(DML_DRStatus,"AR3P")==0)|| (tc_strcmp(DML_DRStatus,"DR3P")==0))
		{
			printf("\n test1");fflush(stdout);
				decision = EPM_go;
		}
		else if(FlagGotProj==1)
		{
			printf("\n test2");fflush(stdout);
			if( (tc_strcmp(DML_DRStatus,"DR3")==0)|| (tc_strcmp(DML_DRStatus,"AR3")==0) || (tc_strcmp(DML_DRStatus,"DR4")==0)|| (tc_strcmp(DML_DRStatus,"DR5")==0) || (tc_strcmp(DML_DRStatus,"AR4")==0) || (tc_strcmp(DML_DRStatus,"AR5")==0) || (tc_strcmp(DML_DRStatus,"AR3P")==0)|| (tc_strcmp(DML_DRStatus,"DR3P")==0))
			{
				printf("\n test3");fflush(stdout);
					decision = EPM_go;
			}
		}
		else
		{
			decision = EPM_nogo;
		}

		printf("\n END BYEE");fflush(stdout);


	}

	return decision;
}

static int t5UpdateLifecycleStateEPA(tag_t object_tag, char* lifecycleStateName,char* lifecycleStateNameToremove)
{
	tag_t			status_rel					= NULLTAG;
	logical			retain						= 0;
	int				ifail						= 0;
	tag_t			class_id					= NULLTAG;
	char			*class_name					= NULL;
	tag_t			tReleaseStatusList_checkin	= NULLTAG;
	int             st_count1					= 0;
	tag_t*			status_list1				= NULLTAG;
	int				n_values_checkin			= 0;
	tag_t*			attr_tags_checkin			= NULLTAG;
	
	logical			*is_it_null_checkin			=   NULL;
	logical			*is_it_empty_checkin		=   NULL;
	int				cunt1						= 0;
	char			*Release_Status				= NULL;
	logical			log1;
    logical			stat  ;
	tag_t    	    propEff_tag				    =	NULLTAG;
	char*			value						=	NULL;
	char			cNextDate[20]={0};
	date_t			test_date_1;
	date_t			test_date_2;
	tag_t			eff_d						= NULLTAG;
	date_t			*start_end_date				= NULL;

	printf("\n **************t5UpdateLifecycleStateEPA*************** %s:%s\n ",lifecycleStateName,lifecycleStateNameToremove);fflush(stdout);
	if(strcmp(lifecycleStateNameToremove,"NA")==0)
	{
		printf("\n Inside NA....");fflush(stdout);
		CALLAPI(CR_create_release_status(lifecycleStateName,&status_rel));
		CALLAPI(EPM_add_release_status(status_rel,1,&object_tag,retain));
	}
	else
	{
		CALLAPI(POM_class_of_instance(object_tag,&class_id));
		CALLAPI(POM_name_of_class(class_id,&class_name));
		printf("\n class_name is :%s\n",class_name);fflush(stdout);

		CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
		CALLAPI(WSOM_ask_release_status_list(object_tag,&st_count1,&status_list1));
		printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);
		
		CALLAPI(POM_unload_instances (1,&object_tag));
		CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
		CALLAPI(POM_is_loaded(object_tag,&log1));
		if(log1 == 1)
		{
			 printf("For EPA Rlzd Load Success\n " );fflush(stdout);
		}
		else
		printf("For EPA Rlzd  Load Failure\n"  );fflush(stdout);

		CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin) );
		printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
		if(n_values_checkin>0)
		{
			CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
			printf("\n For EPA Rlzd n_values11 is :%d\n",n_values_checkin);fflush(stdout);

			for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
			{
				printf("\n For EPA Rlzd Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
				
				CALLAPI(AOM_ask_name(attr_tags_checkin[cunt1], &Release_Status));
				printf("\n  For EPA Rlzd Release_Status changes done: for workspaceobject     %s\n", Release_Status);fflush(stdout);
				
				if(tc_strcmp(Release_Status,lifecycleStateNameToremove)==0 )
				{
					CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,cunt1,1));
					printf("\n For EPA Rlzd cunt 1 == 0 removedd is :%d\n",cunt1);fflush(stdout);

					CALLAPI(POM_save_instances(1,&object_tag,1));

					CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));

					CALLAPI(AOM_lock(object_tag));

					CALLAPI(AOM_save(object_tag));
					CALLAPI(AOM_refresh(object_tag,1));
					CALLAPI(AOM_unlock(object_tag));
				}

			}


		}

		if (CR_create_release_status(lifecycleStateName,&status_rel));
		if(EPM_add_release_status(status_rel,1,&object_tag,retain));

		if (tc_strcmp(class_name,"Design_0_Revision_alt")==0 || tc_strcmp(class_name,"Design Revision")==0 )
		{
			CALLAPI(WSOM_ask_effectivity_mode(&stat));

			CALLAPI(PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag));
			CALLAPI(PROP_ask_value_string(propEff_tag,&value));

			getNextDate(cNextDate);
			printf("\n For EPA Rlzd  cNextDate:%s",cNextDate);fflush(stdout);

			CALLAPI(ITK_string_to_date(cNextDate, &test_date_1 ));
			CALLAPI(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));

			start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

			printf( "\n For EPA Rlzd  Setting release date effectivity  \n");fflush(stdout);

			start_end_date[0] = test_date_1;
			start_end_date[1] = test_date_2;

			CALLAPI(WSOM_status_clear_effectivities (status_rel));
			CALLAPI(WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
			CALLAPI(AOM_save(eff_d));
			CALLAPI(AOM_save(status_rel));
			CALLAPI(AOM_refresh(status_rel,0));
		}
	
	
	}
	
	return 0;
}

int std_epa_working( EPM_action_message_t msg )
{

	int		status;
	int 	error_code	= ITK_ok;
	tag_t		rootTask		= NULLTAG;
	char		*CurrentTask	= NULL;
	char        *parent_name	= NULL;
	int			 noAttachment 	= 0;
	tag_t		*attachments	= NULLTAG;
	tag_t		 EPATag			= NULLTAG;
	tag_t		 objTypeTag     = NULLTAG;
	char	type_name[TCTYPE_name_size_c+1];
	char	*item_id = NULL;
	char	*epa_no = NULL;
	char	*epa_plant = NULL;
	char	*object_type = NULL;
    char*	lcsToset=NULL;
    char*	lcsToremove=NULL;
	tag_t	relation_type= NULLTAG;
	tag_t*	EPATaskRevision		= NULLTAG;
	int TaskCnt=0;
	tag_t			EPATaskRevTag			= NULLTAG;
	int   ifail						= 0;
	int   count						= 0;
	int   PartCnt					= 0;
	int   k							= 0;
	int   st_count					= 0;
	int   epatask_st_count			= 0;
	int   iLCS						= 0;
	int   epaLCS					= 0;
	int   epataskLCS				= 0;
	int   releaseStatusFnd			= 0;
	int   epareleaseStatusFnd		= 0;
	int   epataskreleaseStatusFnd	= 0;
	int   epa_st_count				= 0;
	tag_t*			PartTags				= NULLTAG;
	tag_t			AssyTag					= NULLTAG;
	char*			Part_no					= NULL;
	char*			PartTypeStr				= NULL;
	tag_t			tsk_part_sol_rel_type	= NULLTAG;
	char*			type_name1				= NULL;
	char*			releasest_name			= NULL;
	char*			epa_releasest_name		= NULL;
	char*			epatask_releasest_name	= NULL;
	char*			EPATask_Num				= NULL;
	char*			epatask_no				= NULL;
	char*			DML_No					= NULL;
	char*			PLT_Code					= NULL;
	tag_t			EPAClosureDtAttrId=NULLTAG;
	tag_t			CurrentRoleTag=NULLTAG;
	char			roleName[SA_name_size_c+1]  ;
	char			*PlantNameP				= NULL;

	tag_t*			status_list;
	tag_t*			epa_status_list;
	tag_t*			epatask_status_list;
	date_t			epa_EPA_Release_date =NULLDATE; 


	//lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
	if (tc_strcmp(lcsToset,"NULL") !=0) MEM_free(lcsToset); 
	if (tc_strcmp(lcsToremove,"NULL") !=0) MEM_free(lcsToremove);
	
	lcsToset=(char *)MEM_alloc(20);
	lcsToremove =(char *) MEM_alloc(20);

    printf("\n **************inside std_epa_working***************\n ");fflush(stdout);

	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n inside std_epa_working \n"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n EPA CurrentTask:%s\n",CurrentTask);
	CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n EPA Parent Name:%s\n",parent_name);fflush(stdout);
	CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("EPA Target Attachment:%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		EPATag = attachments[0];
		CALLAPI(TCTYPE_ask_object_type(EPATag,&objTypeTag));
    	CALLAPI(TCTYPE_ask_name(objTypeTag,type_name));
	    printf("\n  EPA type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_EPARevision")==0)
	{
		printf("\n inside class T5_EPARevision......\n");fflush(stdout);
		AOM_ask_value_string( EPATag, "item_id", &item_id);
		AOM_ask_value_string( EPATag, "current_id", &epa_no);
		AOM_ask_value_string( EPATag, "t5_EpaPlantA", &epa_plant);
		
		printf("\n  EPA Details.. %s:%s:%s\n", item_id,epa_no,epa_plant);fflush(stdout);

		strcpy(lcsToremove,"NA");

			//**********TZ3.46*********************//
			ITKCALL(SA_ask_current_role(&CurrentRoleTag));
			ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
			printf("\n\n  roleName : %s\n",roleName); fflush(stdout);			
			
			char AplRvwLC[40];
			char AplWrkngLC[40];
			char AplRlzd[40];
			char Stdwrknglc[40];
			char Stdrlzdlc[40];
			char PltLcs[40];
			char StdPlant[40];
			char StdRevRule[40];
			char StdCLosRule[40];
			char StdView[40];
			PlantNameP=subString(roleName,3,4);
			printf( "PlantNameP:%s\n", PlantNameP);  
			
			//get_CtrlVal_APLStateInf(PlantNameP,"","","",Stdwrknglc,Stdrlzdlc,"","","","","");//TZ1.46//Priti
			get_CtrlVal_STDStateInf(PlantNameP,AplRvwLC,AplWrkngLC,AplRlzd,Stdwrknglc,Stdrlzdlc,PltLcs,StdPlant,StdRevRule,StdCLosRule,StdView);//TZ1.46//Priti

			strcpy(lcsToset,Stdwrknglc);
			//***********************************//		

		printf("\n\n\t\t lcsToset := %s", lcsToset);fflush(stdout);
		epareleaseStatusFnd=0;
		
		ITKCALL(WSOM_ask_release_status_list(EPATag,&epa_st_count,&epa_status_list));
		for (epaLCS=0;epaLCS<epa_st_count ;epaLCS++ )
		{
			ITKCALL(AOM_ask_value_string(epa_status_list[epaLCS],"object_name",&epa_releasest_name));
			printf("\n epa_releasest_name: %s\n",epa_releasest_name);fflush(stdout);
			if(tc_strcmp(epa_releasest_name,lcsToset)==0)
			{
				epareleaseStatusFnd++;
			}
		}

		printf("\n\n\t\t epareleaseStatusFnd := %d", epareleaseStatusFnd);fflush(stdout);
		if(epareleaseStatusFnd==0)
		{
			status = t5UpdateLifecycleStateSTD(EPATag, lcsToset,lcsToremove);
		}	
		

		if (EPATag != NULLTAG)
		{
			CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
			/// Solution Item start

			CALLAPI(GRM_list_secondary_objects_only(EPATag,relation_type,&count,&EPATaskRevision));
			printf("\n\n\t\t EPA to EPA Task : %d",count);fflush(stdout);
			for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
			{
				EPATaskRevTag = EPATaskRevision[TaskCnt];
				CALLAPI(AOM_ask_value_string(EPATaskRevTag,"object_type",&object_type));
				printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
				if(strcmp(object_type,"T5_EPATaskRevision")==0)
				{
					epataskreleaseStatusFnd=0;
					ITKCALL(WSOM_ask_release_status_list(EPATaskRevTag,&epatask_st_count,&epatask_status_list));
					
					for (epataskLCS=0;epataskLCS<epatask_st_count ;epataskLCS++ )
					{
						ITKCALL(AOM_ask_value_string(epatask_status_list[epataskLCS],"object_name",&epatask_releasest_name));
						printf("\n epatask_releasest_name: %s\n",epatask_releasest_name);fflush(stdout);
						if(tc_strcmp(epatask_releasest_name,lcsToset)==0)
						{
							epataskreleaseStatusFnd++;
						}
					}

					printf("\n\n\t\t epataskreleaseStatusFnd := %d", epataskreleaseStatusFnd);fflush(stdout);
					if(epataskreleaseStatusFnd==0)
					{
						status = t5UpdateLifecycleStateSTD(EPATaskRevTag, lcsToset,lcsToremove);
					}
					
					
					CALLAPI(AOM_ask_value_tags(EPATaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
					printf("\n\n\t\t EPA PartCnt:%d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t EPA Part Cnt:for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];

							CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
							printf("\n\n\t\t APL DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);

							if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
							if(TCTYPE_ask_name2(objTypeTag,&type_name1));
							printf("\n\n\t\t APL DML Cre:AssyTag type_name1 := %s", type_name1);fflush(stdout);

							CALLAPI(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
							printf("\n\n\t\t APL DML Cre:AssyTag PartTypeStr := %s", PartTypeStr);fflush(stdout);
							
							releaseStatusFnd=0;

							if (tc_strcmp(type_name1,"Design Revision")==0 || tc_strcmp(type_name1,"Part Revision")==0 )
							{
								ITKCALL(WSOM_ask_release_status_list(AssyTag,&st_count,&status_list));
								for (iLCS=0;iLCS<st_count ;iLCS++ )
								{
									ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&releasest_name));
									printf("\n releasest_name: %s\n",releasest_name);fflush(stdout);
									if(tc_strcmp(releasest_name,lcsToset)==0)
									{
										releaseStatusFnd++;
									}
								}

								printf("\n\n\t\t releaseStatusFnd := %d", releaseStatusFnd);fflush(stdout);
								if(releaseStatusFnd==0)
								{
									status = t5UpdateLifecycleStateSTD(AssyTag, lcsToset,lcsToremove);
								}
							}
						}
					
					
					}

					CALLAPI(AOM_lock(EPATaskRevTag));
					CALLAPI(POM_attr_id_of_attr("date_released","T5_EPATaskRevision",&EPAClosureDtAttrId));
					CALLAPI(AOM_refresh(EPATaskRevTag,TRUE));
					CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
					CALLAPI(POM_set_attr_date(1,&EPATaskRevTag,EPAClosureDtAttrId,epa_EPA_Release_date));
					

					CALLAPI(AOM_save(EPATaskRevTag));
					CALLAPI(AOM_unlock(EPATaskRevTag)); 

				}
			}

			CALLAPI(AOM_lock(EPATag));
			CALLAPI(POM_attr_id_of_attr("date_released","T5_EPARevision",&EPAClosureDtAttrId));
			CALLAPI(AOM_refresh(EPATag,TRUE));
			CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
			CALLAPI(POM_set_attr_date(1,&EPATag,EPAClosureDtAttrId,epa_EPA_Release_date));
			

			CALLAPI(AOM_save(EPATag));
			CALLAPI(AOM_unlock(EPATag)); 
		}
	}
	else if(strcmp(type_name,"T5_EPATaskRevision")==0)
	{
			printf("\n inside class T5_EPATaskRevision......\n");fflush(stdout);
			AOM_ask_value_string( EPATag, "item_id", &item_id);
			AOM_ask_value_string( EPATag, "current_id", &epatask_no);
			//AOM_ask_value_string( EPATag, "t5_EpaPlantA", &epa_plant);
			
			printf("\n  EPA Details.. %s:%s\n", item_id,epa_no);fflush(stdout);

			EPATask_Num=tc_strtok(epatask_no,"_");
			DML_No = tc_strtok(NULL,"_");
			PLT_Code = tc_strtok(NULL,"_");
			printf("\n PLT_Code:[%s],[%s]\n",EPATask_Num,DML_No,PLT_Code);

			strcpy(lcsToremove,"NA");

			if(tc_strcmp(PLT_Code,"APLP")==0)
			{
				strcpy(lcsToset,"T5_LcsSTDpWrkg");
			}
	//		else if(tc_strcmp(PLT_Code,"APLV")==0)
	//		{
	//			strcpy(lcsToset,"T5_LcsSTDvRlzd");
	//		}
			else if(tc_strcmp(PLT_Code,"APLD")==0)
			{
				strcpy(lcsToset,"T5_LcsSTDdWrkg");
			}
			else if(tc_strcmp(PLT_Code,"APLC")==0)
			{
				strcpy(lcsToset,"T5_LcsSTDWrkg");
			}
			else if(tc_strcmp(PLT_Code,"APLJ")==0)
			{
				strcpy(lcsToset,"T5_LcsSTDjWrkg");
			}
			else if(tc_strcmp(PLT_Code,"APLL")==0)
			{
				strcpy(lcsToset,"T5_LcsSTDlWrkg");
			}
			else if(tc_strcmp(PLT_Code,"APLA")==0)
			{
				strcpy(lcsToset,"T5_LcsSTDaWrkg");
			}
			else if((tc_strcmp(PLT_Code,"APLU")==0))
			{
				strcpy(lcsToset,"T5_LcsSTDuWrkg");
			}
	//		else if(tc_strcmp(PLT_Code,"APLS")==0)
	//		{
	//			strcpy(lcsToset,"T5_LcsSTDsRlzd");
	//		}
			else
			{
				strcpy(lcsToset,"T5_LcsSTDWrkg");
			}

			epataskreleaseStatusFnd=0;
		
			ITKCALL(WSOM_ask_release_status_list(EPATag,&epatask_st_count,&epatask_status_list));
					
			for (epataskLCS=0;epataskLCS<epatask_st_count ;epataskLCS++ )
			{
				ITKCALL(AOM_ask_value_string(epatask_status_list[epataskLCS],"object_name",&epatask_releasest_name));
				printf("\n epatask_releasest_name: %s\n",epatask_releasest_name);fflush(stdout);
				if(tc_strcmp(epatask_releasest_name,lcsToset)==0)
				{
					epataskreleaseStatusFnd++;
				}
			}

			printf("\n\n\t\t epataskreleaseStatusFnd := %d", epataskreleaseStatusFnd);fflush(stdout);
			if(epataskreleaseStatusFnd==0)
			{
				status = t5UpdateLifecycleStateSTD(EPATag, lcsToset,lcsToremove);
			}
			
			CALLAPI(AOM_ask_value_tags(EPATag,"CMHasSolutionItem",&PartCnt,&PartTags));
			printf("\n\n\t\t EPA PartCnt:%d",PartCnt);fflush(stdout);
			if (PartCnt>0)
			{
				GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
				for (k=0;k<PartCnt ;k++ )
				{
					printf("\n\n\t\t EPA Part Cnt:for k =:%d",k);fflush(stdout);
					AssyTag=PartTags[k];

					CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
					printf("\n\n\t\t APL DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);

					if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
					if(TCTYPE_ask_name2(objTypeTag,&type_name1));
					printf("\n\n\t\t APL DML Cre:AssyTag type_name1 := %s", type_name1);fflush(stdout);

					CALLAPI(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
					printf("\n\n\t\t APL DML Cre:AssyTag PartTypeStr := %s", PartTypeStr);fflush(stdout);
					
					releaseStatusFnd=0;

					if (tc_strcmp(type_name1,"Design Revision")==0 || tc_strcmp(type_name1,"Part Revision")==0 )
					{
						ITKCALL(WSOM_ask_release_status_list(AssyTag,&st_count,&status_list));
						for (iLCS=0;iLCS<st_count ;iLCS++ )
						{
							ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&releasest_name));
							printf("\n releasest_name: %s\n",releasest_name);fflush(stdout);
							if(tc_strcmp(releasest_name,lcsToset)==0)
							{
								releaseStatusFnd++;
							}
						}

						printf("\n\n\t\t releaseStatusFnd := %d", releaseStatusFnd);fflush(stdout);
						if(releaseStatusFnd==0)
						{
							status = t5UpdateLifecycleStateSTD(AssyTag, lcsToset,lcsToremove);
						}
					}
				}
			
			
			}

			CALLAPI(AOM_lock(EPATag));
			CALLAPI(POM_attr_id_of_attr("date_released","T5_EPATaskRevision",&EPAClosureDtAttrId));
			CALLAPI(AOM_refresh(EPATag,TRUE));
			CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
			CALLAPI(POM_set_attr_date(1,&EPATag,EPAClosureDtAttrId,epa_EPA_Release_date));
			

			CALLAPI(AOM_save(EPATag));
			CALLAPI(AOM_unlock(EPATag)); 
	
	
	}
	
	if (tc_strcmp(lcsToset,"NULL") !=0) MEM_free(lcsToset);
	return error_code;

}

int std_epa_rlzd( EPM_action_message_t msg )
{

	int		status;
	int 	error_code	= ITK_ok;
	tag_t		rootTask		= NULLTAG;
	char		*CurrentTask	= NULL;
	char        *parent_name	= NULL;
	int			 noAttachment 	= 0;
	tag_t		*attachments	= NULLTAG;
	tag_t		 EPATag			= NULLTAG;
	tag_t		 objTypeTag     = NULLTAG;
	char	type_name[TCTYPE_name_size_c+1];
	char	*item_id = NULL;
	char	*epa_no = NULL;
	char	*epa_plant = NULL;
	char	*object_type = NULL;
    char*	lcsToset=NULL;
    char*	lcsToremove=NULL;
	tag_t	relation_type= NULLTAG;
	tag_t*	EPATaskRevision		= NULLTAG;
	int TaskCnt=0;
	tag_t			EPATaskRevTag			= NULLTAG;
	int   ifail						= 0;
	int   count						= 0;
	int   PartCnt					= 0;
	int   k							= 0;
	int   st_count					= 0;
	int   epatask_st_count			= 0;
	int   iLCS						= 0;
	int   epaLCS					= 0;
	int   epataskLCS				= 0;
	int   releaseStatusFnd			= 0;
	int   epareleaseStatusFnd		= 0;
	int   epataskreleaseStatusFnd	= 0;
	int   epa_st_count				= 0;
	tag_t*			PartTags				= NULLTAG;
	tag_t			AssyTag					= NULLTAG;
	char*			Part_no					= NULL;
	char*			PartTypeStr				= NULL;
	tag_t			tsk_part_sol_rel_type	= NULLTAG;
	char*			type_name1				= NULL;
	char*			releasest_name			= NULL;
	char*			epa_releasest_name		= NULL;
	char*			epatask_releasest_name	= NULL;
	tag_t*			status_list;
	tag_t*			epa_status_list;
	tag_t*			epatask_status_list;
	date_t			EPA_Release_date;
	date_t			EPATask_Release_date;
	char cCurrentAccessDate[20]={0};
	char cCurrentAccessDate1[20]={0};
	tag_t  EPATaskClosureDtAttrId = NULLTAG;
	tag_t  EPAClosureDtAttrId = NULLTAG;
	tag_t			CurrentRoleTag=NULLTAG;
	char			roleName[SA_name_size_c+1]  ;


	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
	lcsToremove =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside std_epa_rlzd***************\n ");fflush(stdout);

	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n inside std_epa_rlzd \n"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n EPA CurrentTask:%s\n",CurrentTask);
	CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n EPA Parent Name:%s\n",parent_name);fflush(stdout);
	CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("EPA Target Attachment:%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		EPATag = attachments[0];
		CALLAPI(TCTYPE_ask_object_type(EPATag,&objTypeTag));
    	CALLAPI(TCTYPE_ask_name(objTypeTag,type_name));
	    printf("\n  EPA type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_EPARevision")==0)
	{
		printf("\n inside class T5_EPARevision......\n");fflush(stdout);
		AOM_ask_value_string( EPATag, "item_id", &item_id);
		AOM_ask_value_string( EPATag, "current_id", &epa_no);
		AOM_ask_value_string( EPATag, "t5_EpaPlantA", &epa_plant);
		
		printf("\n  EPA Details.. %s:%s:%s\n", item_id,epa_no,epa_plant);fflush(stdout);

		strcpy(lcsToremove,"NA");

//		if(tc_strcmp(epa_plant,"CVBU PUNE")==0)
//		{
//			strcpy(lcsToset,"T5_LcsStdpRlzd");
//			strcpy(lcsToremove,"T5_LcsSTDpWrkg");
//		}
////		else if(tc_strcmp(PLT_Code,"APLV")==0)
////		{
////			strcpy(lcsToset,"T5_LcsStdRlzd");
////		}
//		else if(tc_strcmp(epa_plant,"DHARWAD")==0)
//		{
//			strcpy(lcsToset,"T5_LcsStddRlzd");
//			strcpy(lcsToremove,"T5_LcsSTDdWrkg");
//		}
//		else if(tc_strcmp(epa_plant,"CAR")==0)
//		{
//			strcpy(lcsToset,"T5_LcsStdRlzd");
//			strcpy(lcsToremove,"T5_LcsSTDWrkg");
//		}
//		else if(tc_strcmp(epa_plant,"CVBU JSR")==0)
//		{
//			strcpy(lcsToset,"T5_LcsStdjRlzd");
//			strcpy(lcsToremove,"T5_LcsSTDjWrkg");
//		}
//		else if(tc_strcmp(epa_plant,"CVBU LKO")==0)
//		{
//			strcpy(lcsToset,"T5_LcsStdlRlzd");
//			strcpy(lcsToremove,"T5_LcsSTDlWrkg");
//		}
//		else if(tc_strcmp(epa_plant,"SMALLCAR AHD")==0)
//		{
//			strcpy(lcsToset,"T5_LcsStdaRlzd");
//			strcpy(lcsToremove,"T5_LcsSTDaWrkg");
//		}
//		else if((tc_strcmp(epa_plant,"CVBU PNR")==0) || (tc_strcmp(epa_plant,"SMALLCAR PNR")==0))
//		{
//			strcpy(lcsToset,"T5_LcsStduRlzd");
//			strcpy(lcsToremove,"T5_LcsSTDuWrkg");
//		}
////		else if(tc_strcmp(epa_plant,"APLS")==0)
////		{
////			strcpy(lcsToset,"T5_LcsSTDsRlzd");
////		}
//		else
//		{
//			strcpy(lcsToset,"T5_LcsStdRlzd");
//			strcpy(lcsToremove,"T5_LcsSTDWrkg");
//		}

		//**********TZ3.46*********************//
			ITKCALL(SA_ask_current_role(&CurrentRoleTag));
			ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
			printf("\n\n  roleName : %s\n",roleName); fflush(stdout);		
			
			char AplRvwLC[40];
			char AplWrkngLC[40];
			char AplRlzd[40];
			char Stdwrknglc[40];
			char Stdrlzdlc[40];
			char PltLcs[40];
			char StdPlant[40];
			char StdRevRule[40];
			char StdCLosRule[40];
			char StdView[40];
			char *PlantNameP = NULL;
			PlantNameP=subString(roleName,3,4);
			printf( "PlantNameP:%s\n", PlantNameP);  
			
			//get_CtrlVal_APLStateInf(PlantNameP,"","","",Stdwrknglc,Stdrlzdlc,"","","","","");//TZ1.46//Priti
			get_CtrlVal_STDStateInf(PlantNameP,AplRvwLC,AplWrkngLC,AplRlzd,Stdwrknglc,Stdrlzdlc,PltLcs,StdPlant,StdRevRule,StdCLosRule,StdView);//TZ1.46//Priti

			strcpy(lcsToset,Stdrlzdlc);
			strcpy(lcsToremove,Stdwrknglc);
			//***********************************//

		
		epareleaseStatusFnd=0;
		
		ITKCALL(WSOM_ask_release_status_list(EPATag,&epa_st_count,&epa_status_list));
		for (epaLCS=0;epaLCS<epa_st_count ;epaLCS++ )
		{
			ITKCALL(AOM_ask_value_string(epa_status_list[epaLCS],"object_name",&epa_releasest_name));
			printf("\n epa_releasest_name: %s\n",epa_releasest_name);fflush(stdout);
			if(tc_strcmp(epa_releasest_name,lcsToset)==0)
			{
				epareleaseStatusFnd++;
			}
		}

		printf("\n\n\t\t epareleaseStatusFnd := %d", epareleaseStatusFnd);fflush(stdout);
		if(epareleaseStatusFnd==0)
		{
			status = t5UpdateLifecycleStateSTD(EPATag, lcsToset,lcsToremove);
		}	
		

		if (EPATag != NULLTAG)
		{
			CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
			/// Solution Item start

			CALLAPI(GRM_list_secondary_objects_only(EPATag,relation_type,&count,&EPATaskRevision));
			printf("\n\n\t\t EPA to EPA Task : %d",count);fflush(stdout);
			for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
			{
				EPATaskRevTag = EPATaskRevision[TaskCnt];
				CALLAPI(AOM_ask_value_string(EPATaskRevTag,"object_type",&object_type));
				printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
				if(strcmp(object_type,"T5_EPATaskRevision")==0)
				{
					epataskreleaseStatusFnd=0;
					ITKCALL(WSOM_ask_release_status_list(EPATaskRevTag,&epatask_st_count,&epatask_status_list));
					
					for (epataskLCS=0;epataskLCS<epatask_st_count ;epataskLCS++ )
					{
						ITKCALL(AOM_ask_value_string(epatask_status_list[epataskLCS],"object_name",&epatask_releasest_name));
						printf("\n epatask_releasest_name: %s\n",epatask_releasest_name);fflush(stdout);
						if(tc_strcmp(epatask_releasest_name,lcsToset)==0)
						{
							epataskreleaseStatusFnd++;
						}
					}

					printf("\n\n\t\t epataskreleaseStatusFnd := %d", epataskreleaseStatusFnd);fflush(stdout);
					if(epataskreleaseStatusFnd==0)
					{
						status = t5UpdateLifecycleStateSTD(EPATaskRevTag, lcsToset,lcsToremove);
					}
					
					
					CALLAPI(AOM_ask_value_tags(EPATaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
					printf("\n\n\t\t EPA PartCnt:%d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t EPA Part Cnt:for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];

							CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
							printf("\n\n\t\t APL DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);

							if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
							if(TCTYPE_ask_name2(objTypeTag,&type_name1));
							printf("\n\n\t\t APL DML Cre:AssyTag type_name1 := %s", type_name1);fflush(stdout);

							CALLAPI(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
							printf("\n\n\t\t APL DML Cre:AssyTag PartTypeStr := %s", PartTypeStr);fflush(stdout);
							
							releaseStatusFnd=0;

							if (tc_strcmp(type_name1,"Design Revision")==0 || tc_strcmp(type_name1,"Part Revision")==0 )
							{
								//Added By Dhanashri for skip prev rev UATZ1.42//
								 char*			SkipPrevRevSTD				= NULL;
								 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
								 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
								 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
					   
								  //if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
								  if(tc_strlen(SkipPrevRevSTD)>0)
								  {
								 	printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
								 	continue;
								  }
								//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

								ITKCALL(WSOM_ask_release_status_list(AssyTag,&st_count,&status_list));
								for (iLCS=0;iLCS<st_count ;iLCS++ )
								{
									ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&releasest_name));
									printf("\n releasest_name: %s\n",releasest_name);fflush(stdout);
									if(tc_strcmp(releasest_name,lcsToset)==0)
									{
										releaseStatusFnd++;
									}
								}

								printf("\n\n\t\t releaseStatusFnd := %d", releaseStatusFnd);fflush(stdout);
								if(releaseStatusFnd==0)
								{
									status = t5UpdateLifecycleStateSTD(AssyTag, lcsToset,lcsToremove);
								}
							}
						}
					
					
					}

					getCurrentDateTime(cCurrentAccessDate1);
					printf("\n For EPA cCurrentAccessDate1:%s",cCurrentAccessDate1);fflush(stdout);
					ITKCALL(ITK_string_to_date(cCurrentAccessDate1, &EPATask_Release_date ));

					CALLAPI(AOM_lock(EPATaskRevTag));
					CALLAPI(POM_attr_id_of_attr("date_released","T5_EPATaskRevision",&EPATaskClosureDtAttrId));
					CALLAPI(AOM_refresh(EPATaskRevTag,TRUE));
					CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
					CALLAPI(POM_set_attr_date(1,&EPATaskRevTag,EPATaskClosureDtAttrId,EPATask_Release_date));

					CALLAPI(AOM_save(EPATaskRevTag));
					CALLAPI(AOM_unlock(EPATaskRevTag));

				}
			}
		}

		getCurrentDateTime(cCurrentAccessDate);
		printf("\n For EPA cCurrentAccessDate:%s",cCurrentAccessDate);fflush(stdout);
		ITKCALL(ITK_string_to_date(cCurrentAccessDate, &EPA_Release_date ));

		CALLAPI(AOM_lock(EPATag));
		CALLAPI(POM_attr_id_of_attr("date_released","T5_EPARevision",&EPAClosureDtAttrId));
		CALLAPI(AOM_refresh(EPATag,TRUE));
		CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
		CALLAPI(POM_set_attr_date(1,&EPATag,EPAClosureDtAttrId,EPA_Release_date));
		CALLAPI(AOM_set_value_string(EPATag,"t5_EpaStatus","F"));


		CALLAPI(AOM_save(EPATag));
		CALLAPI(AOM_unlock(EPATag));


	}
	
	
	return error_code;

}

/*********Start  Added by Deepti for EPA Sign off*******************************************/
int EPA_Prev_Part_Rev_TwoRev_Rlzd_Checks(char* epanosignoff,int PartCnt, tag_t* PartTags,char* SetChildRelErr,char *LcstobeChecked,char *PlantName,char *APLDmlPlnt,char *epaTaskNo)
{

	int k=0;
	int Item_count=0;
	int RevFlag=0;
	int PreRevFlag=0;
	int ii=0;
	int st_count=0;
	int iLCS=0;
	int cntLcs=0;
	int dmlTskcount=0;
	int epaSamePlantFnd=0;
	int dmlcount=0;
	int j=0;
	int revOnSameEpa=0;
	tag_t			AssyTag				= NULLTAG;
	char*			Part_no				= NULL;
	char*			Part_Rev			= NULL;
	char*			Part_rev_Id			= NULL;
	char*			Part_Rev_copy		= NULL;
	char*			ClosureDate			= NULL;
	char*			ClosureDateDup		= NULL;
	tag_t			All_item_tag		= NULLTAG;
	tag_t			*rev_list				= NULL;
	char*			PreRevOnly				= NULL;
	char*			RevOnly					= NULL;
	char*			class_name				= NULL;
	char*			epaTaskId				= NULL;
	char*			epaId					= NULL;
	tag_t*			status_list;
	tag_t*			effectivities;
	char *			ChildRelErr = NULL;
	tag_t			relation_type= NULLTAG;
	tag_t*			PartDmlTaskTags			= NULLTAG;
	tag_t*			EPARevision				= NULLTAG;
	tag_t*			DmlRevision				= NULLTAG;
	tag_t			PartDmlTaskTag			= NULLTAG;
	tag_t			DMLRevTag				= NULLTAG;
	tag_t			EpaRevTag				= NULLTAG;
	tag_t			objTypeRefTag						= NULLTAG;
	char			type_name_ref[TCTYPE_name_size_c+1];
	tag_t tsk_dml_rel_type;
	char cCurrentAccessDate[20]={0};
    char* pAccessDateDup 	= NULL;
	char*  IsEPARlzErr1 = NULL;
	char*  IsDMLRlzErr1 = NULL;
	char*  TaskId = NULL;
	char*  PrevRevItemID = NULL;
	char*  PrevRevItemSeq = NULL;
	char*  PreSMTaskId = NULL;
	char*  dmlId = NULL;
	int smdmlEpaErrorCnt=0;
    tag_t			AssyPreTag			= NULLTAG;
	char PreSMtask_Plant[40];
	char			*inp_PlntLstLtr		= NULL;
	char			*ReleaseStatusSMDML		= NULL;
	int smlst=0,st_dmlcount=0,smRlzFlg=0;
	tag_t *dml_status_list;
	char			*PrevRevSMDMLEPASet		= NULL;
	char  ItemIDCpy[40];
	char  LcsStdWrkg[40];
	char  LcsStdRlzd[40];

	printf("\n Calling EPA_Prev_Part_Rev_TwoRev_Rlzd_Checks .....\n");fflush(stdout);

	 
    tc_strcpy(ItemIDCpy,epaTaskNo);
	GetPlantWiseRelStat(ItemIDCpy,LcsStdWrkg,LcsStdRlzd);
	printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);fflush(stdout);
	printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);fflush(stdout);



	for (k=0;k<PartCnt ;k++ )
	{
		printf("\n\n\t\t Part Cn : =:%d",k);fflush(stdout);
		AssyTag=PartTags[k];
		cntLcs=0;
		PreRevFlag = 0;
		AssyPreTag=NULLTAG;

		ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
		ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev));
		ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev_copy));


		ITKCALL(ITEM_find_item (Part_no, &All_item_tag));
		ITKCALL(ITEM_list_all_revs (All_item_tag, &Item_count, &rev_list));
		printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);

		//Added By Dhanashri for skip prev rev UATZ1.42//
		 char*			SkipPrevRevSTD				= NULL;
		 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
		 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
		 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
			
			//if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
			if(tc_strlen(SkipPrevRevSTD)>0)
			{
			printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
			continue;
			}
		//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

		//COMMENTED BY DEEPTI TZ1.43
		/*if(Item_count > 0)
		{
			RevFlag = 0;
			PreRevFlag = 0;
			for(ii=Item_count-1;ii>=0;ii--)
			{
				RevOnly = NULL;
				PreRevOnly = NULL;
				ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));
				printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);
				printf("\n Part_rev_Id: %s\n",Part_rev_Id);fflush(stdout);
				if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
				{
					RevFlag = 1;
				}
				printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
				if(RevFlag == 1)
				{
					RevOnly= strtok( Part_Rev_copy, ";" );
					PreRevOnly= strtok( Part_rev_Id, ";" );
					printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
					printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
					if(tc_strcmp(RevOnly,PreRevOnly)!=0)
					{
						PreRevFlag = 1;
					}
				}
				printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
				if(PreRevFlag == 1)
				{
					//Added By Dhanashri for skip prev rev UATZ1.42//
					 char*			SkipPrevRevSTD1				= NULL;
					 ITKCALL(AOM_ask_value_string(rev_list[ii],"t5_SkipPrevRevSTD",&SkipPrevRevSTD1));
					 printf("\n\n\t\t SkipPrevRevSTD1  is :%s",SkipPrevRevSTD1);	fflush(stdout);
					 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD1)  is :%d",tc_strlen(SkipPrevRevSTD1));	fflush(stdout);
					   
								  //if(tc_strcmp(SkipPrevRevSTD1,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD1,"") !=0)
								  if(tc_strlen(SkipPrevRevSTD1)>0)
								  {
								 	printf("\n\n\t\t Inside SkipPrevRevSTD1 not null...");	fflush(stdout);
								 	continue;
								  }
					//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

					ITKCALL(WSOM_ask_release_status_list(rev_list[ii],&st_count,&status_list));
					if(st_count == 0)
					{
						printf("\n NO LCS Found for part : %d\n",st_count);fflush(stdout);
						break;
					}
					else
					{
						for (iLCS=0;iLCS<st_count ;iLCS++ )
						{
							ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
							printf("\n class_name: %s\n",class_name);fflush(stdout);
							
							if(tc_strcmp(class_name,LcstobeChecked)==0)
							{
								cntLcs++;
								break;
							}
							
						}
						printf("\n cntLcs inside : %d\n",cntLcs);fflush(stdout);
						break;
					}
				}  /// End Prev Rev  Flag Loop

			}
		}*/

		if(Item_count > 0)
		{
		
			if(strstr(Part_Rev,"NR"))
			{
				printf("\n in EPA Previous revision function can not be called as current revision has NR revision");fflush(stdout);
			}
			else
			{
				PreRevFlag = 0;
				printf("\n in EPA Calling function to get Previous revision ");fflush(stdout);
				tm_fnd_Prev_Official_Revision(Part_no,AssyTag,&AssyPreTag);//TZ 1.43
				if(AssyPreTag)
				{
					//Added By Dhanashri for skip prev rev UATZ1.42//
					PreRevFlag = 1;
					char*			SkipPrevRevSTD1				= NULL;
					ITKCALL(AOM_ask_value_string(AssyPreTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD1));
					printf("\n\n\t\t SkipPrevRevSTD1  is :%s",SkipPrevRevSTD1);	fflush(stdout);
					printf("\n\n\t\t tc_strlen(SkipPrevRevSTD1)  is :%d",tc_strlen(SkipPrevRevSTD1));	fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyPreTag,"item_id",&PrevRevItemID));
					printf("\n\n\t\t PrevRevItemID  is :%s",PrevRevItemID);	fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyPreTag,"item_revision_id",&PrevRevItemSeq));
					printf("\n\n\t\t PrevRevItemSeq  is :%s",PrevRevItemSeq);	fflush(stdout);

					

					//if(tc_strcmp(SkipPrevRevSTD1,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD1,"") !=0)
					if(tc_strlen(SkipPrevRevSTD1)>0)
					{
						printf("\n\n\t\t Inside SkipPrevRevSTD1 not null...");	fflush(stdout);
						continue;
					}
					//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

					ITKCALL(WSOM_ask_release_status_list(AssyPreTag,&st_count,&status_list));
					if(st_count == 0)
					{
						printf("\n NO LCS Found for part : %d\n",st_count);fflush(stdout);
						
					}
					else
					{
						for (iLCS=0;iLCS<st_count ;iLCS++ )
						{
							ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
							printf("\n class_name: %s\n",class_name);fflush(stdout);
							
							if(tc_strcmp(class_name,LcstobeChecked)==0)
							{
								cntLcs++;
								break;
							}
							
						}
						printf("\n cntLcs inside : %d\n",cntLcs);fflush(stdout);
						
					}				
				
				}
			}
				
		}
		
		if (tc_strcmp(ChildRelErr,"NULL") !=0) MEM_free(ChildRelErr);
		ChildRelErr=(char *)MEM_alloc(100);
		tc_strcpy(ChildRelErr," ");

		revOnSameEpa=0;

		if (cntLcs<=0 && PreRevFlag == 1)
		{
			ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
			ITKCALL(GRM_list_primary_objects_only(AssyPreTag,relation_type,&dmlTskcount,&PartDmlTaskTags));
			if(dmlTskcount >0)
			{
				
				for (k=0;k<dmlTskcount ;k++ )
				{
					PartDmlTaskTag=PartDmlTaskTags[k];//task pointer
					printf("\n\n\t\t INSIDE: ");fflush(stdout);

					ITKCALL(TCTYPE_ask_object_type(PartDmlTaskTag,&objTypeRefTag));//task pointer
					ITKCALL(TCTYPE_ask_name(objTypeRefTag,type_name_ref));

					printf("\n\n\t\t type_name_ref:%s",type_name_ref);fflush(stdout);

					if (strcmp(type_name_ref,"T5_EPATaskRevision")==0)
					{
						
						ITKCALL(AOM_ask_value_string(PartDmlTaskTag, "item_id",&epaTaskId));
						printf("\n\n\t\t epaTaskId:%s:%s",epaTaskId,APLDmlPlnt);fflush(stdout);
						if(tc_strstr(epaTaskId,APLDmlPlnt)!=NULL)
						{
					
							epaSamePlantFnd++;
							ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
							if (tsk_dml_rel_type!=NULLTAG)
							{
								ITKCALL(GRM_list_primary_objects_only(PartDmlTaskTag,tsk_dml_rel_type,&dmlcount,&EPARevision));
								for (j=0;j<dmlcount ;j++ )
								{
									EpaRevTag = EPARevision[j];
									ITKCALL(AOM_ask_value_string(EpaRevTag, "item_id",&epaId));
									printf("\n epaId %s.....\n",epaId);fflush(stdout);

									if(strcmp(epaId,epanosignoff)==0)
									{
										revOnSameEpa++;
									}
								}
							}
						}
					}
				}
			}
			
			
			if(revOnSameEpa==0)
			{
				if(epacnt==0)
				{
					epacnt = 1;
					tc_strcat(ChildRelErr,"Previous Revision Part ");
					tc_strcat(ChildRelErr,Part_no);
					tc_strcat(ChildRelErr,",");
					tc_strcat(ChildRelErr,Part_rev_Id);
					tc_strcat(ChildRelErr," is not STDSI Released. Please release Previous Revision First.\n");
					printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
				}
				else
				{
					tc_strcat(ChildRelErr,"Previous Revision Part ");
					tc_strcat(ChildRelErr,Part_no);
					tc_strcat(ChildRelErr,",");
					tc_strcat(ChildRelErr,Part_rev_Id);
					tc_strcat(ChildRelErr," is not STDSI Released. Please release Previous Revision First\n");
					printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
					epacnt = epacnt+1;
					printf("\n ChildRelEr22r: %s\n",ChildRelErr);fflush(stdout);
				}

				if(epacnt==1)
				{
					tc_strcpy(SetChildRelErr,ChildRelErr);
					cntEPAFlag = 1;
				}
				else
				{
					tc_strcat(SetChildRelErr,ChildRelErr);
					cntEPAFlag = 1;
				}
			}
		
		}

		if(cntLcs>0 && PreRevFlag == 1)
		{
			//ITKCALL(WSOM_status_ask_effectivities(status_list[iLCS],n_effectivities,&effectivities));
			ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
			ITKCALL(GRM_list_primary_objects_only(AssyPreTag,relation_type,&dmlTskcount,&PartDmlTaskTags));
			if(dmlTskcount >0)
			{
				
				for (k=0;k<dmlTskcount ;k++ )
				{
					PartDmlTaskTag=PartDmlTaskTags[k];//task pointer
					printf("\n\n\t\t INSIDE: ");fflush(stdout);

					ITKCALL(TCTYPE_ask_object_type(PartDmlTaskTag,&objTypeRefTag));//task pointer
					ITKCALL(TCTYPE_ask_name(objTypeRefTag,type_name_ref));
					if (strcmp(type_name_ref,"T5_EPATaskRevision")==0)
					{
						
						ITKCALL(AOM_ask_value_string(PartDmlTaskTag, "item_id",&epaTaskId));
						if(tc_strstr(epaTaskId,APLDmlPlnt)!=NULL)
						{
					
							epaSamePlantFnd++;
							ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
							if (tsk_dml_rel_type!=NULLTAG)
							{
								ITKCALL(GRM_list_primary_objects_only(PartDmlTaskTag,tsk_dml_rel_type,&dmlcount,&EPARevision));
								for (j=0;j<dmlcount ;j++ )
								{
									EpaRevTag = EPARevision[j];
									ITKCALL(AOM_ask_value_string(EpaRevTag, "item_id",&epaId));
									printf("\n epaId %s.....\n",epaId);

									//ITK_CALL(POM_attr_id_of_attr("date_released","T5_APLDMLRevision",&DMLClosureDtAttrId));
									//ITK_CALL(POM_set_attr_date(1,&itemrev,DMLClosureDtAttrId,test_date_2));

									ITKCALL(AOM_UIF_ask_value(EpaRevTag,"date_released",&ClosureDate));
									printf("\n ClosureDate : %s\n",ClosureDate);fflush(stdout);//28-Oct-2017 14:12

									ClosureDateDup = subString(ClosureDate,0,11);
									printf("\n ClosureDateDup : %s\n",ClosureDateDup);fflush(stdout);
									getCurrentDateTime(cCurrentAccessDate);
									printf("\n  todays date111 is: %s\n",cCurrentAccessDate);
									pAccessDateDup = subString(cCurrentAccessDate,0,11);
									printf("\n  todays date is: %s\n",pAccessDateDup);

									if (tc_strcmp(IsEPARlzErr1,"NULL")==0) MEM_free(IsEPARlzErr1);
									IsEPARlzErr1=(char *)MEM_alloc(100);
									tc_strcpy(IsEPARlzErr1,"");
									if(tc_strcmp(ClosureDateDup,pAccessDateDup)==0)
									{

										if(epacnt==0)
										{
											epacnt = 1;

											tc_strcat(IsEPARlzErr1,"\n Two revision of part ");
											tc_strcat(IsEPARlzErr1,Part_no);
											tc_strcat(IsEPARlzErr1," cannot be released on same day.\n");
											printf("\n IsEPARlzErr1: %s\n",IsEPARlzErr1);fflush(stdout);

										}
										else
										{
											tc_strcat(IsEPARlzErr1,"\n Two revision of part ");
											tc_strcat(IsEPARlzErr1,Part_no);
											tc_strcat(IsEPARlzErr1," cannot be released on same day..\n");
											epacnt=epacnt+1;
											printf("\n IsEPARlzErr1: %s\n",IsEPARlzErr1);fflush(stdout);
										}
										printf("\n epacnt: %d\n",epacnt);fflush(stdout);

										if(epacnt==1)
										{
											tc_strcat(SetChildRelErr,IsEPARlzErr1);
											cntEPAFlag = 1;
										}
										else
										{
											tc_strcat(SetChildRelErr,IsEPARlzErr1);
											cntEPAFlag = 1;
										}
									 }
								}
							
							}
						}
					}
					else if(strcmp(type_name_ref,"T5_SMDMLTaskRevision")==0)
					{
						ITKCALL(AOM_ask_value_string(PartDmlTaskTag, "item_id",&PreSMTaskId));
						printf("\n PreSMTaskId %s.....\n",PreSMTaskId);	fflush(stdout);

						GetPlantForDMLORTask(PreSMTaskId,PreSMtask_Plant);	
						printf("\t  PreSMtask_Plant after  ...%s\n %s", PreSMtask_Plant,PlantName);
						
						dmlId=subString(PreSMTaskId,2,2);
						printf("\n dmlId:%s",dmlId);fflush(stdout);

						if(tc_strcmp(dmlId,"SM")==0 && (tc_strcmp(PlantName,PreSMtask_Plant)==0))
						{

							smlst = 0;
							ITKCALL(WSOM_ask_release_status_list(PartDmlTaskTag,&st_dmlcount,&dml_status_list));
							for (smlst = 0; smlst < st_dmlcount; smlst++)
							{
								AOM_ask_name(dml_status_list[smlst], &ReleaseStatusSMDML);
								printf("\n ReleaseStatusepa %s :::LcsStdRlzd %s\n",  ReleaseStatusSMDML,LcsStdRlzd);fflush(stdout);
								if(tc_strcmp(ReleaseStatusSMDML,LcsStdRlzd)!=0 )
								{
									//smRlzFlg=1;
									///break;
									
									printf("\n Previous revision of part is contanied in SMDML which is not stdsi released, carry forward previous revision changes into current revision");fflush(stdout);
									//#############Logic to carry forward previous revision changes#############//



									//##########################################################################//
								}
								else
								{
									smRlzFlg++;
								
								}
							}
						}	
					
					
					}
				
				}

				if(smRlzFlg==0)
				{
					
					 if(smdmlEpaErrorCnt==0)
					 {
						 tc_strcat(PrevRevSMDMLEPASet,"\n Below Previous Revision of Part is attached to SM-DML which is not STDSI released.Please release the SM-DML.");
						 tc_strcat(PrevRevSMDMLEPASet,"\n");
						 tc_strcat(PrevRevSMDMLEPASet,PrevRevItemID);
						 tc_strcat(PrevRevSMDMLEPASet,":");
						 tc_strcat(PrevRevSMDMLEPASet,PrevRevItemSeq);
						 tc_strcat(PrevRevSMDMLEPASet,";SM-DML Task :");
						 tc_strcat(PrevRevSMDMLEPASet,PreSMTaskId);	
						 smdmlEpaErrorCnt++;
					 }
					 else
					 {
						 tc_strcat(PrevRevSMDMLEPASet,"\n");
						 tc_strcat(PrevRevSMDMLEPASet,PrevRevItemID);
						 tc_strcat(PrevRevSMDMLEPASet,":");
						 tc_strcat(PrevRevSMDMLEPASet,PrevRevItemSeq);
						 tc_strcat(PrevRevSMDMLEPASet,";SM-DML Task :");
						 tc_strcat(PrevRevSMDMLEPASet,PreSMTaskId);	
						 smdmlEpaErrorCnt++;
					 }
				}


				k=0;
				if(epaSamePlantFnd==0)
				{

					for (k=0;k<dmlTskcount ;k++ )
					{
						PartDmlTaskTag=PartDmlTaskTags[k];//task pointer
						printf("\n\n\t\t INSIDE: ");fflush(stdout);

						ITKCALL(TCTYPE_ask_object_type(PartDmlTaskTag,&objTypeRefTag));//task pointer
						ITKCALL(TCTYPE_ask_name(objTypeRefTag,type_name_ref));
						
						if (strcmp(type_name_ref,"T5_APLTaskRevision")==0)
						{
							ITKCALL(AOM_ask_value_string(PartDmlTaskTag, "item_id",&TaskId));
							if(tc_strstr(TaskId,APLDmlPlnt)!=NULL)
							{
						
								epaSamePlantFnd++;
								ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
								if (tsk_dml_rel_type!=NULLTAG)
								{
									ITKCALL(GRM_list_primary_objects_only(PartDmlTaskTag,tsk_dml_rel_type,&dmlcount,&DmlRevision));
									for (j=0;j<dmlcount ;j++ )
									{
										DMLRevTag = DmlRevision[j];
										ITKCALL(AOM_ask_value_string(DMLRevTag, "item_id",&epaId));
										printf("\n epaId %s.....\n",epaId);

										//ITK_CALL(POM_attr_id_of_attr("date_released","T5_APLDMLRevision",&DMLClosureDtAttrId));
										//ITK_CALL(POM_set_attr_date(1,&itemrev,DMLClosureDtAttrId,test_date_2));

										ITKCALL(AOM_UIF_ask_value(DMLRevTag,"date_released",&ClosureDate));
										printf("\n ClosureDate : %s\n",ClosureDate);fflush(stdout);//28-Oct-2017 14:12

										ClosureDateDup = subString(ClosureDate,0,11);
										printf("\n ClosureDateDup : %s\n",ClosureDateDup);fflush(stdout);
										getCurrentDateTime(cCurrentAccessDate);
										printf("\n  todays date111 is: %s\n",cCurrentAccessDate);
										pAccessDateDup = subString(cCurrentAccessDate,0,11);
										printf("\n  todays date is: %s\n",pAccessDateDup);

										if (tc_strcmp(IsDMLRlzErr1,"NULL")==0) MEM_free(IsDMLRlzErr1);
										IsDMLRlzErr1=(char *)MEM_alloc(100);
										tc_strcpy(IsDMLRlzErr1,"");
										if(tc_strcmp(ClosureDateDup,pAccessDateDup)==0)
										{

											if(epacnt==0)
											{
												epacnt = 1;

												tc_strcat(IsDMLRlzErr1,"\n Two revision of part ");
												tc_strcat(IsDMLRlzErr1,Part_no);
												tc_strcat(IsDMLRlzErr1," cannot be released on same day.\n");
												printf("\n IsDMLRlzErr1: %s\n",IsDMLRlzErr1);fflush(stdout);

											}
											else
											{
												tc_strcat(IsDMLRlzErr1,"\n Two revision of part ");
												tc_strcat(IsDMLRlzErr1,Part_no);
												tc_strcat(IsDMLRlzErr1," cannot be released on same day..\n");
												epacnt=epacnt+1;
												printf("\n IsDMLRlzErr1: %s\n",IsDMLRlzErr1);fflush(stdout);
											}
											printf("\n epacnt: %d\n",epacnt);fflush(stdout);

											if(epacnt==1)
											{
												tc_strcat(SetChildRelErr,IsDMLRlzErr1);
												cntEPAFlag = 1;
											}
											else
											{
												tc_strcat(SetChildRelErr,IsDMLRlzErr1);
												cntEPAFlag = 1;
											}
										 }
									}
								
								}
							}
						}


					}
				}
			}

		}

	
	}

	printf("\n PrevRevSMDMLEPASet:%s",PrevRevSMDMLEPASet);fflush(stdout);
	if(smdmlEpaErrorCnt>0)
	{
		tc_strcat(SetChildRelErr,PrevRevSMDMLEPASet);	
	}

	return 0;
}

int EPA_Part_PP_DML_Rlzd_Checks(char *epaTaskNo,int PartCnt, tag_t* PartTags,char* SetChildRelErr,char *LcstobeChecked,char *PlantName,char *APLDmlPlnt)
{
	EPM_decision_t decision;
	int k=0;
	int k1=0;
	int errorCnt=0;
	int cntLcs=0;
	int task_st_count=0;
	int dmlTskcount=0;
	int tskCnt=0;
	tag_t			AssyTag				= NULLTAG;
	tag_t			PartDmlTaskTag				= NULLTAG;
	char*			Part_no				= NULL;
	char*			Part_Rev			= NULL;
	char*			TaskId			= NULL;
	char*			Part_Rev_copy		= NULL;
	tag_t			relation_type= NULLTAG;
	tag_t*			PartDmlTaskTags			= NULLTAG;
	tag_t			objTypeRefTag						= NULLTAG;
	char			type_name_ref[TCTYPE_name_size_c+1];
	char*			ClosureDate			= NULL;
	char*			DMLList				= NULL;
	char*			class_name			= NULL;
	char*			IsDMLRlzErr1			= NULL;
	char*			EPA_Num			= NULL;
	char*			EPA_DML_Num			= NULL;
	tag_t *task_status_list;

	
	printf("\n Calling EPA_Part_PP_DML_Rlzd_Checks .....\n");fflush(stdout);
	
	

	EPA_Num=tc_strtok(epaTaskNo,"_");
	EPA_DML_Num = tc_strtok(NULL,"_");
	printf("\n EPA_Num :[%s],EPA_DML_Num %s \n",EPA_Num,EPA_DML_Num);fflush(stdout);
	
	if (tc_strcmp(DMLList,"NULL")==0) MEM_free(DMLList);
	DMLList=(char *)MEM_alloc(1000);


	for (k=0;k<PartCnt ;k++ )
	{
		printf("\n\n\t\t Part Cn : =:%d",k);fflush(stdout);
		AssyTag=PartTags[k];
		cntLcs=0;

		ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
		ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev));
		ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev_copy));

		printf("\n\n\t\t Part_no : =:%s: Part_Rev ==%s",Part_no,Part_Rev);fflush(stdout);

					//Added By Dhanashri for skip prev rev UATZ1.42//
					 char*			SkipPrevRevSTD				= NULL;
					 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
					 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
					 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
			
						//if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
						if(tc_strlen(SkipPrevRevSTD)>0)
						{
						printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
						continue;
						}
					//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

		ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
		ITKCALL(GRM_list_primary_objects_only(AssyTag,relation_type,&dmlTskcount,&PartDmlTaskTags));
		printf("\n\n\t\t dmlTskcount ==%d",dmlTskcount);fflush(stdout);
		if(dmlTskcount >0)
		{
			
			for (k1=0;k1<dmlTskcount ;k1++ )
			{
				PartDmlTaskTag=PartDmlTaskTags[k1];//task pointer
				printf("\n\n\t\t INSIDE EPA_Part_PP_DML_Rlzd_Checks: ");fflush(stdout);

				ITKCALL(TCTYPE_ask_object_type(PartDmlTaskTag,&objTypeRefTag));
				ITKCALL(TCTYPE_ask_name(objTypeRefTag,type_name_ref));
				printf("\n\n\t\t INSIDE EPA_Part_PP_DML_Rlzd_Checks type_name_ref %s: ",type_name_ref);fflush(stdout);

				if (strcmp(type_name_ref,"T5_APLTaskRevision")==0)
				{
					
					ITKCALL(AOM_ask_value_string(PartDmlTaskTag, "item_id",&TaskId));
					printf("\n\n\t\t DML PLant Details %s:%s:%s ",TaskId,APLDmlPlnt,EPA_DML_Num);fflush(stdout);
					if(tc_strstr(TaskId,APLDmlPlnt)!=NULL)
					{
						printf("\n\n\t\t Plant DML Task Found !!! ");fflush(stdout);
						
						if(tc_strstr(TaskId,EPA_DML_Num)!=NULL)
						{
							printf("\n\n\t\t Matched DML NO !!! ");fflush(stdout);
							
							ITKCALL(AOM_UIF_ask_value(PartDmlTaskTag,"date_released",&ClosureDate));
							printf("\n ClosureDate : %s\n",ClosureDate);fflush(stdout);
							ITKCALL(WSOM_ask_release_status_list(PartDmlTaskTag,&task_st_count,&task_status_list));
							if(task_st_count == 0)
							{
								printf("\n NO LCS Found for Plant Task : %d\n",task_st_count);fflush(stdout);
								//break;
							}
							else
							{
								for (tskCnt=0;tskCnt<task_st_count ;tskCnt++ )
								{
									ITKCALL(AOM_ask_value_string(task_status_list[tskCnt],"object_name",&class_name));
									printf("\n class_name: %s\n",class_name);fflush(stdout);
									
									if(tc_strcmp(class_name,LcstobeChecked)==0)
									{
										cntLcs++;
										break;
									}
									
								}
								printf("\n cntLcs inside : %d\n",cntLcs);fflush(stdout);
								//break;
							}
							//if((cntLcs==0) && (strcmp(ClosureDate,"")==0)) //TZ1.43 Deepti
							if(cntLcs==0)							
							{	
								if(errorCnt==0)
								{
									tc_strcpy(DMLList,TaskId);							
								}
								else
								{
									if((tc_strstr(DMLList,TaskId)!=NULL))
									{
										printf("\n IN DML List DMLList : %s,Task %s already found!!\n",DMLList,TaskId);fflush(stdout);
									}
									else
									{
										printf("\n Adding IN DML List DMLList : %s,Task %s !\n",DMLList,TaskId);fflush(stdout);
										tc_strcat(DMLList,";");
										tc_strcat(DMLList,TaskId);
									}
								}
								errorCnt++;	
								printf("\n DMLList : %s\n",DMLList);fflush(stdout);

							}
							break;
						}
					
					}
				
				}
			}
		}

		/*if (tc_strcmp(IsDMLRlzErr1,"NULL")==0) MEM_free(IsDMLRlzErr1);
		IsDMLRlzErr1=(char *)MEM_alloc(1000);
		tc_strcpy(IsDMLRlzErr1,"");
		if(errorCnt>0)
		{
			if(epacnt==0)
			{
				epacnt = 1;

				tc_strcat(IsDMLRlzErr1,"\n DML Task ");
				tc_strcat(IsDMLRlzErr1,DMLList);
				tc_strcat(IsDMLRlzErr1," are not released by STDSI.\n");
				tc_strcat(IsDMLRlzErr1," First release these DMLs/DML Task before releasing EPA.\n");
				printf("\n IsDMLRlzErr1: %s\n",IsDMLRlzErr1);fflush(stdout);

			}
			else
			{
				tc_strcat(IsDMLRlzErr1,"\n DML Task ");
				tc_strcat(IsDMLRlzErr1,DMLList);
				tc_strcat(IsDMLRlzErr1," are not released by STDSI.\n");
				tc_strcat(IsDMLRlzErr1," First release these DMLs/DML Task before releasing EPA.\n");
				epacnt=epacnt+1;
				printf("\n IsDMLRlzErr1: %s\n",IsDMLRlzErr1);fflush(stdout);
			}
			printf("\n epacnt: %d\n",epacnt);fflush(stdout);

			if(epacnt==1)
			{
				tc_strcat(SetChildRelErr,IsDMLRlzErr1);
				cntEPAFlag = 1;
			}
			else
			{
				tc_strcat(SetChildRelErr,IsDMLRlzErr1);
				cntEPAFlag = 1;
			}		
		
		}*/
	
	
	}
	if (tc_strcmp(IsDMLRlzErr1,"NULL")==0) MEM_free(IsDMLRlzErr1);
	IsDMLRlzErr1=(char *)MEM_alloc(1000);
	tc_strcpy(IsDMLRlzErr1,"");
	if(errorCnt>0)
	{
		if(epacnt==0)
		{
			epacnt = 1;

			tc_strcat(IsDMLRlzErr1,"\n DML Task ");
			tc_strcat(IsDMLRlzErr1,DMLList);
			tc_strcat(IsDMLRlzErr1," are not released by STDSI.\n");
			tc_strcat(IsDMLRlzErr1," First release these DMLs/DML Task before releasing EPA.\n");
			printf("\n IsDMLRlzErr1: %s\n",IsDMLRlzErr1);fflush(stdout);

		}
		else
		{
			tc_strcat(IsDMLRlzErr1,"\n DML Task ");
			tc_strcat(IsDMLRlzErr1,DMLList);
			tc_strcat(IsDMLRlzErr1," are not released by STDSI.\n");
			tc_strcat(IsDMLRlzErr1," First release these DMLs/DML Task before releasing EPA.\n");
			epacnt=epacnt+1;
			printf("\n IsDMLRlzErr1: %s\n",IsDMLRlzErr1);fflush(stdout);
		}
		printf("\n epacnt: %d\n",epacnt);fflush(stdout);

		if(epacnt==1)
		{
			tc_strcat(SetChildRelErr,IsDMLRlzErr1);
			cntEPAFlag = 1;
		}
		else
		{
			tc_strcat(SetChildRelErr,IsDMLRlzErr1);
			cntEPAFlag = 1;
		}		
	
	}
	
	
	return 0;
}

int EPA_Child_Part_Rlzd_Checks(int PartCnt, tag_t* PartTags,char* SetChildRelErr,char *LcstobeChecked,char *PlantName,char *RevisionRl,char *ClosureRl,char *ViewBVR)
{

	EPM_decision_t decision;
	int				k=0;
	int				st_count=0;
	int				cntLcs=0;
	int				count1=0;
	int				ii=0;
	int				iLCS=0;
	tag_t			AssyTag				= NULLTAG;
	char*			Part_no				= NULL;
	char*			Part_owning_groupVal				= NULL;
	char*			BVRAsPerPartOwner				= NULL;
	char*			Item_id				= NULL;
	char*			ChildRelErr				= NULL;
	char*			class_name				= NULL;
	struct			BomChldStrut	ChldStrutBdySh[5000];
	int				StructCntBdyShProdPlan	= 0;
	int				childBS	= 0;
	tag_t			objChild_BS		= NULLTAG;
	const char *qry_entries[2];
	const char *qry_values[2];
	int n_tags_found2=0;
	tag_t	*itemclass2							= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t	item_rev_cld_tag							= NULLTAG;
	tag_t *  rev_list;
	tag_t*    status_list;

	for (k=0;k<PartCnt ;k++ )
	{
		AssyTag=PartTags[k];
		cntLcs=0;

		ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
		printf("\n\n\t\t APL DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);

		ITKCALL(AOM_UIF_ask_value(AssyTag,"owning_group",&Part_owning_groupVal));
		printf("\n\n\t\t Part_no  Part_owning_groupVal is :%s",Part_owning_groupVal);fflush(stdout);

		//Added By Dhanashri for skip prev rev UATZ1.42//
		 char*			SkipPrevRevSTD				= NULL;
		 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
		 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
		 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
			
						//if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
						if(tc_strlen(SkipPrevRevSTD)>0)
						{
						printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
						continue;
						}
		//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//


		if (tc_strcmp(BVRAsPerPartOwner,"NULL") !=0) MEM_free(BVRAsPerPartOwner);
		BVRAsPerPartOwner=(char *)MEM_alloc(100);

		//TZ3.46
				char BVRInfo2[40];
				char Info1[40];
				char Info3[40];
				get_CtrlVal_APLLcsInf(Part_owning_groupVal,Info1,BVRInfo2,Info3);//TZ3.46
				tc_strcpy(BVRAsPerPartOwner,BVRInfo2);

		StructCntBdyShProdPlan=0;
		ITKCALL(Get_Part_BOM_Lvl(AssyTag,1,ClosureRl,RevisionRl,BVRAsPerPartOwner,ChldStrutBdySh,&StructCntBdyShProdPlan));
		printf("\n\t\t StructCntBdyShProdPlan:%d",StructCntBdyShProdPlan);fflush(stdout);

		childBS = 0;
		for (childBS = 1; childBS <= StructCntBdyShProdPlan; childBS++)
		{
			cntLcs=0;
			objChild_BS		= NULLTAG;
			objChild_BS=ChldStrutBdySh[childBS].child_objs;
			char	*Part_clr_ind	=	NULL;

			ITKCALL(AOM_UIF_ask_value(objChild_BS,"item_id",&Item_id));
			printf("\n\n\t EPA Child Part String is Item_id-->%s",Item_id);	fflush(stdout);

			Part_clr_ind	=	NULL;
			ITKCALL(AOM_ask_value_string(objChild_BS,"t5_ColourInd",&Part_clr_ind));
			printf("\n\n\t EPA Child Part String is Part_clr_ind-->%s",Part_clr_ind);	fflush(stdout);

			qry_entries[0] ="item_id";
			qry_entries[1] ="object_type";//Multiple Item Queried Error
			qry_values[0] = Item_id;
			if (tc_strcmp(Part_clr_ind,"C")==0)
			{
				qry_values[1] = "T5_ClrPart";//Multiple Item Queried Error Hemal
			}
			else
			{
				//qry_values[1] = "Design";//Multiple Item Queried Error Hemal
				//Handle the different design child class.
				char	*designBORev		=	NULL;
				char	*designBO			=	NULL;
				//tag_t	AssyTag			=	NULLTAG;
				//AssyTag=PartTags[k];
				printf("\nBefore getDesignType");fflush(stdout);
				getDesignType(objChild_BS, &designBORev,&designBO);
				printf("\nAfter getDesignType : %s",designBO);fflush(stdout);
				qry_values[1] = designBO;


			}//Multiple Item Queried Error

			//ITKCALL(ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found2, &itemclass2));
			ITKCALL(ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found2, &itemclass2));////Multiple Item Queried Error
			itemcldclass = itemclass2[0];

			ITKCALL(ITEM_list_all_revs(itemcldclass, &count1,&rev_list ));
			for (ii = 0; ii < count1; ii++)
			{
				item_rev_cld_tag = rev_list[ii];

				ITKCALL(WSOM_ask_release_status_list(item_rev_cld_tag,&st_count,&status_list));
				printf("\n st_count:%d \n",st_count);fflush(stdout);
				if (tc_strcmp(ChildRelErr,"NULL") !=0) MEM_free(ChildRelErr);
				ChildRelErr=(char *)MEM_alloc(100);
				tc_strcpy(ChildRelErr," ");
				if (st_count == 0)  /* No Status, so the Item is not yet Released */
				{
					printf("\n No Status, so the Item is not yet Released \n");

				}
				else
				{

						for (iLCS=0;iLCS<st_count ;iLCS++ )
						{
							ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
							printf("\n class_name: %s:%s\n",class_name,LcstobeChecked);fflush(stdout);
							if(tc_strcmp(class_name,LcstobeChecked)==0)
							{
								cntLcs++;
								break;
							}
						}
				}
			}

			printf("\n cntLcs: %d\n",cntLcs);fflush(stdout);
			if (cntLcs<=0)
			{
				if(epacnt==0)
				{
					epacnt = 1;
					tc_strcat(ChildRelErr,"Child Part ");
					tc_strcat(ChildRelErr,Item_id);
					//tc_strcat(ChildRelErr,",");
					//tc_strcat(ChildRelErr,Item_rev);
					tc_strcat(ChildRelErr,"  Of Parent Part ");
					tc_strcat(ChildRelErr,Part_no);
					tc_strcat(ChildRelErr," is not STDSI Released from Plant.\n");
					printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
				}
				else
				{
					tc_strcat(ChildRelErr,"Child Part ");
					tc_strcat(ChildRelErr,Item_id);
					//tc_strcat(ChildRelErr,",");
					//tc_strcat(ChildRelErr,Item_rev);
					tc_strcat(ChildRelErr,"  Of Parent Part ");
					tc_strcat(ChildRelErr,Part_no);
					tc_strcat(ChildRelErr," is not STDSI Released from Plant.\n");
					epacnt = epacnt+1;
					printf("\n ChildRelEr22r: %s\n",ChildRelErr);fflush(stdout);
				}
				if(epacnt==1)
				{
					tc_strcpy(SetChildRelErr,ChildRelErr);
					cntEPAFlag = 1;
				}
				else
				{
					tc_strcat(SetChildRelErr,ChildRelErr);
					cntEPAFlag = 1;
				}
			}				

		}
	
	}


	return 0;

}

extern EPM_decision_t DLLAPI epa_signoff_checks_Func(EPM_rule_message_t msg)
{

	EPM_decision_t decision;
	tag_t		 rootTask			= NULLTAG;
	char		*CurrentTask		= NULL;
	char        *parent_name		= NULL;
	char        *epaitemid			= NULL;
	int			iNumAttch = 0;
	int			i = 0;
	tag_t		* pTagAttch;
	char		type_name[TCTYPE_name_size_c+1];
	const char *qry_entries[1];
	const char *qry_values[1];
	int n_tags_found=0;
	int TaskCnt=0;
	int PartCnt=0;
	int count=0;
	tag_t	*itemclass							= NULLTAG;
	tag_t	item								= NULLTAG;
	tag_t	epa_rev_tag							= NULLTAG;
	tag_t	ItemTypeTag							= NULLTAG;
	tag_t	relation_type						= NULLTAG;
	tag_t*	EPATaskRevision						= NULLTAG;
	tag_t	EPATaskRevTag						= NULLTAG;
	char	*object_type						= NULL;
	char	*SetChildRelErr						= NULL;
	char	*EpaFinInf							= NULL;
	char	*epa_plant							= NULL;
	char	*epaTaskNo							= NULL;
	char	*lcsToset							= NULL;
	char	*PlantName							= NULL;
	tag_t*	PartTags							= NULLTAG;
	tag_t	CurrentRoleTag						= NULLTAG;
	char    RoleName[SA_name_size_c+1];
	char	PlantCS[40];
	char	PlantOptCS[40];
	char	PlantIA[40];
	char	PlantStore[40];
	char	UserAgency[40];
	char	RevisionRule[40];
	char	ClosureRule[40];
	char	STDDmlPlnt[40];
	char	BVR[40];
	char	APLDmlPlnt[40];
	int		status=0;
	int		errCnt=0;
	cntEPAFlag=0;
	epacnt=0;
	char	*epa_po_check						= NULL;

	printf("\n Calling epa_signoff_checks_Func .....\n");fflush(stdout);
	
	

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n epa_signoff_checks_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	if (!SetChildRelErr) MEM_free(SetChildRelErr);
	SetChildRelErr=(char *)MEM_alloc(5000);
	tc_strcpy(SetChildRelErr,"");

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name(CurrentRoleTag,RoleName))
	printf("\n\n  RoleName : %s\n",RoleName); fflush(stdout);

	PlantName=subString(RoleName,3,4);
    printf( "PlantName:%s\n", PlantName);fflush(stdout);

	getPlantDetailsAttr_Std(RoleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency,RevisionRule,ClosureRule,BVR,APLDmlPlnt,STDDmlPlnt);//TZ1.41

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

	//*************TZ3.46*****************//	
	char AplRvwLC[40];
	char AplWrkngLC[40];
	char AplRlzd[40];
	char Stdwrknglc[40];
	char Stdrlzdlc[40];
	char PltLcs[40];
	char StdPlant[40];
	char StdRevRule[40];
	char StdCLosRule[40];
	char StdView[40];
	
	//get_CtrlVal_APLStateInf(PlantName,"","","",Stdwrknglc,Stdrlzdlc,"","","","","");//TZ1.46//Priti
	get_CtrlVal_STDStateInf(PlantName,AplRvwLC,AplWrkngLC,AplRlzd,Stdwrknglc,Stdrlzdlc,PltLcs,StdPlant,StdRevRule,StdCLosRule,StdView);//TZ1.46//Priti

	strcpy(lcsToset,"T5_LcsStdRlzd");			
	//*****************************************//


	
	if(tc_strcmp(CurrentTask,"Finalize the EPA")==0)
	{
		ITKCALL( TCTYPE_find_type("T5_EPARevision", NULL, &ItemTypeTag));
		for (i=0; i < iNumAttch; i++)
		{
			tag_t		objTypeTag = NULLTAG;

			ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&epaitemid));
			printf("\n epa itemid %s.....\n",epaitemid);fflush(stdout);

			qry_entries[0] ="item_id";
			qry_values[0] = epaitemid;

			ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
			item = itemclass[0];
			if(item != NULLTAG )
			ITKCALL(ITEM_ask_latest_rev(item,&epa_rev_tag));
			
			ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
			ITKCALL( TCTYPE_ask_name( objTypeTag, type_name) );
			printf("\t  epa type_name ...%s\n", type_name);fflush(stdout);

			if( objTypeTag == ItemTypeTag )
			{
				ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
				ITKCALL(GRM_list_secondary_objects_only(epa_rev_tag,relation_type,&count,&EPATaskRevision));

				ITKCALL(AOM_ask_value_string( epa_rev_tag, "t5_EpaPlantA", &epa_plant));

				if(tc_strcmp(epa_plant,"CVBU PUNE")==0)
				{
					if(tc_strstr(RoleName,"STDP")!=NULL)
					{
						printf("\t SignoffP EPA of as per user location ");fflush(stdout);	
					}
					else
					{
						errCnt++;		
					}
				}
				else if(tc_strcmp(epa_plant,"DHARWAD")==0)
				{
					if(tc_strstr(RoleName,"STDD")!=NULL)
					{
						printf("\t SignoffD EPA of as per user location ");fflush(stdout);	
					}
					else
					{
						errCnt++;		
					}
				}
				else if((tc_strcmp(epa_plant,"CAR")==0) || (tc_strcmp(epa_plant,"PlantName1")==0))
				{
					if(tc_strstr(RoleName,"STDC")!=NULL)
					{
						printf("\t SignoffC EPA of as per user location ");fflush(stdout);	
					}
					else
					{
						errCnt++;		
					}
					
				}
				else if(tc_strcmp(epa_plant,"CVBU JSR")==0)
				{
					if(tc_strstr(RoleName,"STDJ")!=NULL)
					{
						printf("\t SignoffJ EPA of as per user location ");fflush(stdout);	
					}
					else
					{
						errCnt++;		
					}
				}
				else if(tc_strcmp(epa_plant,"CVBU LKO")==0)
				{
					if(tc_strstr(RoleName,"STDL")!=NULL)
					{
						printf("\t SignoffJ EPA of as per user location ");fflush(stdout);	
					}
					else
					{
						errCnt++;		
					}
				}
				else if(tc_strcmp(epa_plant,"SMALLCAR AHD")==0)
				{
					if(tc_strstr(RoleName,"STDA")!=NULL)
					{
						printf("\t SignoffA EPA of as per user location ");fflush(stdout);	
					}
					else
					{
						errCnt++;		
					}
				}
				else if((tc_strcmp(epa_plant,"CVBU PNR")==0) || (tc_strcmp(epa_plant,"SMALLCAR PNR")==0))
				{
					if(tc_strstr(RoleName,"STDU")!=NULL)
					{
						printf("\t SignoffU EPA of as per user location ");fflush(stdout);	
					}
					else
					{
						errCnt++;		
					}
				}

				if(errCnt>0)
				{
					printf("\n Showing error of group & role");fflush(stdout);
					EMH_clear_errors();
					status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Please select proper Group and Role before finalizing the EPA.");
					decision = EPM_nogo;
					return ITK_errStore;
				}
				errCnt=0;

				printf("\n\n\t\t EPA to EPA Task : %d",count);fflush(stdout);
				if(count>0)
				{
					for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
					{
						EPATaskRevTag = EPATaskRevision[TaskCnt];
						ITKCALL(AOM_ask_value_string(EPATaskRevTag,"object_type",&object_type));
						printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
						if(strcmp(object_type,"T5_EPATaskRevision")==0)
						{
							ITKCALL(AOM_ask_value_string( EPATaskRevTag, "item_id", &epaTaskNo));
							
							ITKCALL(AOM_ask_value_tags(EPATaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
							printf("\n\n\t\t EPA PartCnt:%d",PartCnt);fflush(stdout);
							if (PartCnt>0)
							{
//								if(tc_strcmp(epa_plant,"CVBU PUNE")==0)
//								{
//									strcpy(lcsToset,"T5_LcsStdpRlzd");
//								}
//								else if(tc_strcmp(epa_plant,"DHARWAD")==0)
//								{
//									strcpy(lcsToset,"T5_LcsStddRlzd");
//								}
//								else if(tc_strcmp(epa_plant,"CAR")==0)
//								{
//									strcpy(lcsToset,"T5_LcsStdRlzd");
//									
//								}
//								else if(tc_strcmp(epa_plant,"CVBU JSR")==0)
//								{
//									strcpy(lcsToset,"T5_LcsStdjRlzd");
//								}
//								else if(tc_strcmp(epa_plant,"CVBU LKO")==0)
//								{
//									strcpy(lcsToset,"T5_LcsStdlRlzd");
//								}
//								else if(tc_strcmp(epa_plant,"SMALLCAR AHD")==0)
//								{
//									strcpy(lcsToset,"T5_LcsStdaRlzd");
//								}
//								else if((tc_strcmp(epa_plant,"CVBU PNR")==0) || (tc_strcmp(epa_plant,"PlantName7")==0))
//								{
//									strcpy(lcsToset,"T5_LcsStduRlzd");
//								}
//								else
//								{
//									strcpy(lcsToset,"T5_LcsStdRlzd");
//								}
								
								EPA_Prev_Part_Rev_TwoRev_Rlzd_Checks(epaitemid,PartCnt,PartTags,SetChildRelErr,lcsToset,PlantName,APLDmlPlnt,epaTaskNo);
								printf("\n After Prev Rev Part Error SetChildRelErr: %s:%d\n",SetChildRelErr,cntEPAFlag);fflush(stdout);
								
								EPA_Part_PP_DML_Rlzd_Checks(epaTaskNo,PartCnt,PartTags,SetChildRelErr,lcsToset,PlantName,APLDmlPlnt);
								printf("\n After PP DML Rlzd Error SetChildRelErr: %s:%d\n",SetChildRelErr,cntEPAFlag);fflush(stdout);

								EPA_Child_Part_Rlzd_Checks(PartCnt,PartTags,SetChildRelErr,lcsToset,PlantName,RevisionRule,ClosureRule,BVR);
								printf("\n After Child Part Rlzd Error SetChildRelErr: %s:%d\n",SetChildRelErr,cntEPAFlag);fflush(stdout);
								
							}	
						
						}	
					}
				}
				else
				{
					printf("\n NO EPA TASK FOUND.. ");fflush(stdout);
//					EMH_clear_errors();
//					if (!EpaFinInf) MEM_free(EpaFinInf);
//					EpaFinInf=(char *)MEM_alloc(5000);
//					tc_strcpy(EpaFinInf,"No EPA Task is Found for this EPA.Do you want to Finalize this EPA?");
//
//					printf("\n befor showing softcheck  %d :%s\n",status,EpaFinInf);
//
//					status=EMH_store_error_s2(EMH_severity_warning,ITK_err, "EMH_severity_warning",EpaFinInf);
//					printf("\n after showing softcheck  %d \n",status);
					//decision = EPM_nogo;
					//return EMH_severity_information;

				
				}
			
			
			}
			printf("\n cntEPAFlag. %d \n",cntEPAFlag);fflush(stdout);
			if(cntEPAFlag==1)
			{
				printf("\n Showing error for epa finalization.. %s \n",SetChildRelErr);fflush(stdout);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,SetChildRelErr);
				printf("\n All Child Part is not TCM Released  %s \n",SetChildRelErr);fflush(stdout);
				decision = EPM_nogo;
				return ITK_errStore;
			}
			else
			{
				//TZ1.42--DEEPTI
				if (count>0)
				{
					ITKCALL(AOM_ask_value_string( epa_rev_tag, "t5_POCheckStatus", &epa_po_check));
					printf("\n epa_po_check.. %s \n",epa_po_check);fflush(stdout);
					if(strcmp(epa_po_check,"")==0)
					{
						EMH_clear_errors();
						status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Please run the PO check before finalizing the EPA.\n Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->PO Checks");
						decision = EPM_nogo;
						return ITK_errStore;				
					}
					else if(strcmp(epa_po_check,"POCHKFAIL")==0)
					{
						EMH_clear_errors();
						status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"PO Check fails.Please check the PO Report attached with EPA. ");
						decision = EPM_nogo;
						return ITK_errStore;				
					}
					else if(strcmp(epa_po_check,"POCHKPASS")==0)
					{
						//decision = EPM_go;
						//return decision;			
					}
					else
					{				
						//decision = EPM_go;
						//return decision;
					}
				}
				else
				{
					printf("\n NO Task under EPA..");fflush(stdout);
				}
				
			
			}
		}
	
	}

	decision = EPM_go;
	return decision;



}

extern int DLLAPI epa_part_attach( METHOD_message_t *msg, va_list  args )
{
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	char   type_name[TCTYPE_name_size_c+1];
	char   type_name2[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;


	tag_t  primary_object = va_arg(args, tag_t);
	tag_t  secondary_object = va_arg(args, tag_t);
	tag_t  relation_type = va_arg(args, tag_t);

	ITKCALL(TCTYPE_ask_object_type(primary_object,&objTypeTag));
	ITKCALL(TCTYPE_ask_name(objTypeTag,type_name));
	printf("\n     epa_part_attach primary_object  type_name :: %s\n", type_name); fflush(stdout);

//	ITKCALL(TCTYPE_ask_object_type(secondary_object,&objTypeTag2));
//	ITKCALL(TCTYPE_ask_name(objTypeTag2,type_name2));
//	printf("\n     epa_part_attach secondary_object  type_name2 :: %s\n", type_name2); fflush(stdout);

	ITKCALL(POM_get_user_id (&username));
	printf("\n\n  epa_part_attach Session login User1 : %s\n",username); fflush(stdout);
	
	if(tc_strcmp(type_name,"T5_EPATaskRevision")==0)
	{
		
		ITKCALL(TCTYPE_ask_object_type(secondary_object,&objTypeTag2));
		ITKCALL(TCTYPE_ask_name(objTypeTag2,type_name2));
		printf("\n     epa_part_attach secondary_object  type_name2 :: %s\n", type_name2); fflush(stdout);


		if(relation_type != NULLTAG)
		{
			ITKCALL(TCTYPE_ask_name( relation_type, relation_name));
		}

		if(tc_strcmp(relation_name,"CMHasSolutionItem")==0)
		{
			if(tc_strcmp(type_name2,"Design Revision")==0)
			{
				if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
				{
					//EMH_store_error_s1(EMH_severity_warning,ITK_err,"You cannot add parts from SolutionItem of the EPA Task Revision manually.");//DEEPTI TZ1.41
					//return ITK_err; //Will do in Next TZ
				}
			
			}
		
		}

	}

	return ITK_ok;

}
/*********End  Added by Deepti for EPA Sign off*******************************************/

extern int std_user_assign_register_method(int *decision, va_list args)
{
    METHOD_id_t  method1;
    METHOD_id_t  method2;
	METHOD_id_t  method;
	METHOD_id_t  method4;
    
    int ifail=0;
   // *decision = ALL_CUSTOMIZATIONS ;
    char   type_name[TCTYPE_name_size_c+1];
    char   type_name1[TCTYPE_name_size_c+1];
    tag_t objTag = va_arg(args, tag_t);
    tag_t objTypeTag=NULLTAG;

   if( ITK_ok == EPM_register_action_handler("tm_std_dml_assign", "", tm_std_dml_assign))
   {
		printf("\t\n Registered Action Handler std_user_assign_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler tm_std_dml_assign\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_rule_handler ("std_dml_signoff_checks_Func","This Handler is used to display message",(EPM_rule_handler_t)std_dml_signoff_checks_Func))
   {
		printf("\t\n Registered Rule Handler std_dml_signoff_checks_Func\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler std_dml_signoff_checks_Func\n");fflush(stdout);
   }
	if( ITK_ok == EPM_register_action_handler("std_dml_claim", "", std_dml_claim))
   {
		printf("\t\n Registered Action Handler std_dml_claim_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler std_dml_claim_register_method\n");fflush(stdout);
   }


   if( ITK_ok == EPM_register_action_handler("std_dml_release", "", std_dml_release))
   {
		printf("\t\n Registered Action Handler std_dml_release_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler std_dml_release_register_method\n");fflush(stdout);
   }

   ifail = METHOD_find_method("T5_APLTaskRevision", TC_save_msg, &method);
   if (method.id != NULLTAG)
   {
			ifail = METHOD_add_action(method, METHOD_post_action_type, (METHOD_function_t) Save_APLTask_Msg, NULL)!=ITK_ok;
			printf("\n rrrrrrrrRegistered as Post-Action for T5_APLTaskRevision Save\n");fflush(stdout);
   }else
		{
			printf("\n Method not found!TC_save_msg\n");fflush(stdout);
		}


  if( ITK_ok == EPM_register_action_handler("pr_task_stamping", "", pr_task_stamping))
   {
		printf("\t\n Registered Action Handler pr_task_stamping\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler pr_task_stamping\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_rule_handler ("DRStatusCondition","This Handler is used to display message",(EPM_rule_handler_t)DRStatusCondition))
   {
		printf("\t\n Registered Rule Handler DRStatusCondition\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler DRStatusCondition\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("std_epa_working", "", std_epa_working))
   {
		printf("\t\n Registered Action Handler std_epa_working_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler std_epa_working_register_method\n");fflush(stdout);
   }

    //TZ1.41
   if( ITK_ok == EPM_register_rule_handler("epa_signoff_checks_Func","This Handler is used to display message",(EPM_rule_handler_t)epa_signoff_checks_Func))
   {
		printf("\t\n Registered Rule Handler epa_signoff_checks_Func\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler epa_signoff_checks_Func\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("std_epa_rlzd", "", std_epa_rlzd))
   {
		printf("\t\n Registered Action Handler std_epa_rlzd_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler std_epa_rlzd_register_method\n");fflush(stdout);
   }

	ifail = METHOD_find_method("CMHasSolutionItem", GRM_create_msg, &method4);
	if( ifail == ITK_ok )
	{
		printf("\n Before register method for GRM_create_msg in epa part attach \n");
		if (method4.id != NULLTAG)
		{
			if( METHOD_add_action(method4, METHOD_pre_action_type, (METHOD_function_t) epa_part_attach, NULL)!=ITK_ok)
			printf("Registered as METHOD_pre_action_type for epa_part_attach\n");
		}
		else
		printf("Method not found!GRM_create_msg\n");
	}

    return ITK_ok;
}

extern DLLAPI int tm_std_dml_assign_register_callbacks()
{
	 CUSTOM_register_exit("tm_std_dml_assign", "USER_init_module", (CUSTOM_EXIT_ftn_t)std_user_assign_register_method);

     printf("\n registered function tm_std_dml_assign\n");	fflush(stdout);

	 return ( ITK_ok );
}
