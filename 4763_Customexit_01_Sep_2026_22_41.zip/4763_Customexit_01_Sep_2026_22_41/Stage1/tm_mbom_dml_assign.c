//#include <tccore/iman_msg.h>
//#include <tc/tc.h>
//#include <epm/releasestatus.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
//#include <itk/mem.h>
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <user_exits/epm_toolkit_utils.h>
#include <ae/dataset_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>//Added by Anshul Multilevel BOM explode
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <Fnd0Participant/participant.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <cfm/cfm.h>
#include <fclasses/tc_date.h>
#include <epm/epm_task_template_itk.h>
#include <sub_mgr/tcactionhandler.h>
#include <user_exits/user_exits.h>


//#include "tm_apl_std_common_function.c"
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002

/*********************/ 
int cnt = 0;
int cntFlag = 0;


#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
	printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;
//Start Code to Explode BOM -4
struct BomChldStrut
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
}*get_BomChldStrut;

struct BomChldStrut_Impl
{
	tag_t parent_objs;//CHild
	tag_t parent_objs_bvr;//BVR
	int parent_objs_lvl;//LVL
}*get_BomChldStrut_Impl;

//End Code to Explode BOM -4
char* subString_mbom (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;
void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}
void reverse(char *s)
{
   int length, c;
   char *begin, *end, temp;
 
   length = tc_strlen(s);
   begin  = s;
   end    = s;
 
   for (c = 0; c < length - 1; c++)
      end++;
 
   for (c = 0; c < length/2; c++)
   {        
      temp   = *end;
      *end   = *begin;
      *begin = temp;
 
      begin++;
      end--;
   }
}

void  GetPlantForDMLORTask( char * item_id ,char  getPlant[40])
{
    printf( "item_id:%s\n", item_id);

	char *item_idCpy =NULL;
	char *revStr =NULL;
	char *tmpStr =NULL;
	char *revStr1 =NULL;
	item_idCpy	=	(char *)MEM_alloc(50);

	tc_strcpy(item_idCpy,item_id);
	reverse(item_idCpy);
	revStr	=	(char *)MEM_alloc(50);
	tc_strcpy(revStr,item_idCpy);
	printf("\n revStr Find %s.......",revStr);fflush(stdout);
	tmpStr	=	strtok(revStr,"_");
	printf("\n tmpStr Find %s.......",tmpStr);fflush(stdout);
	revStr1	=	(char *)MEM_alloc(50);
	reverse(tmpStr);
	tc_strcpy(revStr1,tmpStr);
	printf("\n revStr1 Find %s.......",revStr1);fflush(stdout);
	tc_strcpy(getPlant,revStr1);

	printf( "getPlant:%s\n", getPlant);
}
void tm_fnd_Next_revision(char	*req_item,tag_t t_currentRevision, tag_t* t_NextRevision)
{
	int		Item_count			=	0;
	int		RevFlag				=	0;
	int		NextRevFlag 		=	0;
	int		ii					=	0;
	int		iRevLength			=	0;

	char	*Part_Rev			=	NULL;
	char	*Part_Rev_copy		=	NULL;
	char	*Part_rev_Id		=	NULL;
	char	*RevOnly			=	NULL;
	char	*NextRevOnly		=	NULL;
	char	*tmpNextRev			=	NULL;
	char	*Part_next_rev_Id	=	NULL;

	tag_t	All_item_tag		=	NULLTAG;
	tag_t	*rev_list			=	NULLTAG;

	printf("\ntm_fnd_prev_revision called : %s",req_item);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev));
	printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev_copy));
	printf("\n Part_Rev_copy: %s\n",Part_Rev_copy);fflush(stdout);

//	ITKCALL(ITEM_list_all_revs (All_item_tag, &Item_count, &rev_list));
	ITKCALL(AOM_ask_value_tags(t_currentRevision,"revision_list",&Item_count,&rev_list));
	printf("\nNo of Item : %d",Item_count);fflush(stdout);


	if(Item_count > 0)
	{
		RevFlag		=	0;
		NextRevFlag	=	0;

		for(ii=0;ii<Item_count;ii++)
		{
			RevOnly		=	NULL;
			NextRevOnly	=	NULL;

			ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));

			printf("\nPart number : %s Part_Rev %s and Part_rev_Id: %s\n",req_item,Part_Rev,Part_rev_Id);fflush(stdout);
			if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
			{
				RevFlag = 1;
			}
			printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
			if(RevFlag == 1)
			{
				//if (ii < Item_count)
				{				
					RevOnly		= strtok( Part_Rev_copy, ";" );
					NextRevOnly	= strtok( Part_rev_Id, ";" );

					printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
					printf("\n NextRevOnly: %s\n",NextRevOnly);fflush(stdout);
					if(tc_strcmp(RevOnly,NextRevOnly)!=0)
					{
						
						iRevLength	=	strlen(NextRevOnly);
						printf("\nNext Revision Length : %d",iRevLength);fflush(stdout);
						if(NextRevFlag ==0)
						{
							tmpNextRev	=	(char *)malloc(10);
							tc_strcpy(tmpNextRev,NextRevOnly);
							NextRevFlag =	1;
						}
						printf("\nNextRevFlag : %d, tmpNextRev : %s",NextRevFlag,tmpNextRev);fflush(stdout);
						if (tc_strcmp(tmpNextRev,NextRevOnly)==0)
						{
							printf("\nSame Revision of Part --> %s, temp rev --> %s, current rev --> %s ",req_item,tmpNextRev,Part_rev_Id);fflush(stdout);
							*t_NextRevision	=	rev_list[ii];
						}
						else
						{
							printf("\nSame Revision of Part --> %s is not same, temp rev --> %s, current rev --> %s ",req_item,tmpNextRev,Part_rev_Id);fflush(stdout);

							ITKCALL(AOM_ask_value_string(rev_list[ii-1],"item_revision_id",&Part_next_rev_Id));
							printf("\n Part_next_rev_Id: %s\n",Part_next_rev_Id);fflush(stdout);
							*t_NextRevision	=	rev_list[ii-1];
							break;
						}
					}
					else
					{
						printf("\nNext Revision Length : %d",iRevLength);fflush(stdout);
						if (ii	==	Item_count-1)
						{
							printf("\nii : %d,Item_count-1 : %d",ii,Item_count-1);fflush(stdout);
							*t_NextRevision	=	rev_list[ii];
							break;
						}
					}
				}
			}
		}
		if(RevFlag == 1 && NextRevFlag ==0)
		{
			*t_NextRevision	=	rev_list[ii];
		}
	}
}

void  GetProjectUserAccessDetails( char  *Projj , char  *UsrId ,int *Gmcnt ,tag_t	**GmFound)
{
	int		n_entries = 2;
	int		countt=0;

	char	*qry_entries[2] = {"Project ID","Id"};
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	tag_t	queryTag   = NULLTAG;

	 char *Object_Name  =  NULL;



	printf( "Projj:%s\n", Projj);fflush(stdout);
	printf( "UsrId:%s\n", UsrId);fflush(stdout);
	 

				if( QRY_find2("ProjectUserAccessDet", &queryTag));
				printf("\n MT:After Prd_Project:  QRY_find2");fflush(stdout);
				if (queryTag)
				{
					printf("\n MT:Found Query");fflush(stdout);
				}
				else
				{
					printf("\n MT:Not Found Query");fflush(stdout);
				}

				qry_values[0] = Projj;
				qry_values[1] = UsrId;

				if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, Gmcnt, GmFound));
				printf("\n MT: Gmcnt : %d\n", *Gmcnt); fflush(stdout);

//                for(countt==0;countt<*Gmcnt;countt++)
//				{
//						Object_Name  =  NULL;
//						ITKCALL(AOM_UIF_ask_value(GmFound[countt],"object_string", &Object_Name));	
//						printf("\n %s",Object_Name);fflush(stdout);
//				}

}
void setAddTAG_1(int *count,tag_t **objlist,tag_t obj ) // Added By Ketan TZ 1.76
{
 
	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTAG_11");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
 
	}
	else
	{
		//printf("\n ****setAddTAG_12");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
 
	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

int AssignMBOMPlanner(tag_t APLTaskRevT,char*		Proj_Code)
{
	
	char*			Task_no				= NULL;
	char*			Dsgn_No				= NULL;
	char*			Dsgn1				= NULL;
	char*			Dsgn2				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	char*			rolename			= NULL;
	char*			userid				= NULL;
	char*			PLT_CodeS			= NULL;
	char*			Object_Name			= NULL;

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t			qryTagCntrl1		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t*			GmFound1			= NULLTAG;
	tag_t*			list_of_WSO_cntrl_tags1=NULLTAG;
	
	int				ifail				= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int FlaggAssignPlanner=0;
	int countt=0;
	int b=0;
	int z=0;
	int cntrlcnt=0;
	int  control_number_found1=0;
	int     n_entryCntrl1    = 3;
	int FlaggAssignMBOMPlanner=0;

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	char  Projj[40];
	
	char *PltCodeFrmCntrl 	  = NULL;
	char Aggregt[40];
	char*	Temp_Task_no	= NULL;
	char*	CLSP_Dsgn_Grp	= NULL;
	int max_char_size = 80;
    Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));
	tag_t tsk_dml_rel_type=NULLTAG;
	int count = 0;
	tag_t *DMLRevision = NULLTAG;
	tag_t DMLRevTag =NULLTAG;
	char *Obj_type=NULL;
	char *DMLrlsType=NULL;
	int k=0;


	printf("\n Ketan Inside AssignMBOMPlanner \n");

	ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
	ITKCALL(GRM_list_primary_objects_only(APLTaskRevT,tsk_dml_rel_type,&count,&DMLRevision));
	printf("\n MBOM DML Revision from Task : %d",count); fflush(stdout);

	for (k=0;k<count;k++ )
	{
		DMLRevTag = DMLRevision[k];
		ITKCALL(AOM_ask_value_string(DMLRevTag,"object_type",&Obj_type));
		printf("\n Obj_type is :%s",Obj_type); fflush(stdout);

		if(tc_strcmp(Obj_type,"T5_MBOMDMLRevision")==0)
		{
			ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLrlsType));
			printf("\n DMLrlsType is :%s",DMLrlsType); fflush(stdout);
		}
	}

	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	
	printf("\n MBOM DML : AssignMBOMPlanner:Task_no  is :%s \n",Task_no);	fflush(stdout);
	tc_strcpy(Temp_Task_no, Task_no);
    printf("\n Ketan for AssignMBOMPlanner Temp_Task_no :%s \n", Temp_Task_no);fflush(stdout);
	printf("\n MBOM DML : AssignMBOMPlanner:Proj_Code  is :%s \n",Proj_Code);	fflush(stdout);

	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\n Test 1..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\n Test 2..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\n Test 3..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);fflush(stdout);
	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));
	
	// 31MB //
	// 0123    0123

	Dsgn1 = subString_mbom(Dsgn_No,0,2);
	printf("\n MBOM Planner Dsgn1 ==> %s\n",Dsgn1);  // 31

	Dsgn2 = subString_mbom(Dsgn_No,2,2);
	printf("\n MBOM Planner Dsgn2 ==> %s\n",Dsgn2);  // MB

	//if ((tc_strstr(Temp_Task_no, "CL") != NULL) || (tc_strstr(Temp_Task_no, "SP") != NULL))
    if ((tc_strstr(Temp_Task_no, "CL") != NULL) || (tc_strstr(Temp_Task_no, "SP") != NULL) || (tc_strstr(Temp_Task_no, "CO") != NULL))	
    {
        printf("\n Inside CL/SP/CO Task for MBOM Planner\n");fflush(stdout);
        CALLAPI(AOM_ask_value_string(APLTaskRevT, "t5_crdesigngroup", &CLSP_Dsgn_Grp));
        printf("\n CLSP_Dsgn_Grp ==> %s\n", CLSP_Dsgn_Grp);fflush(stdout);

        Dsgn1 = (char *)MEM_alloc(100 * sizeof(char *));
        tc_strcpy(Dsgn1, CLSP_Dsgn_Grp);
        printf("\n Final MBOM Planner : CL/SP Dsgn_No ==> %s \n", Dsgn1);fflush(stdout);
    }

	
	//**********************TZ1.46**********************************//
	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="APLPltInf";
		qry_valuesCntrl1[1]=PLT_Code;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	else
	{
		printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
	}	
	
	printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

	if(control_number_found1>0)
	{				
		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &PltCodeFrmCntrl);
		printf("\n PltCodeFrmCntrl: %s\n",PltCodeFrmCntrl);fflush(stdout);
		tc_strcpy(PLT_CodeS,PltCodeFrmCntrl);					
	}
	else
	{
		tc_strcpy(PLT_CodeS,"MBOM");
	}
	printf("\n PLT_CodeS: %s\n",PLT_CodeS);fflush(stdout);
	//****************************************************************************//

	APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(APL_Plnr_Grp,PLT_CodeS);
	//tc_strcat(APL_Plnr_Grp,PLT_CodeS);
	
	tc_strcpy(Projj,Proj_Code);
	printf("\n Projj :[%s]\n",Projj);fflush(stdout);
	
	printf("\n Test0.14.. MBOM Designer Group Name:[%s]\n",APL_Plnr_Grp);fflush(stdout);


	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));
	if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\n Planner: No of Role found in Group are :%d\n",num_of_roles);fflush(stdout);

	// Ketan Added
	if(num_of_roles>0)
	{
		for (i=0;i<num_of_roles ;i++ )
		{
			CALLAPI(SA_ask_role_name2(role_tags[i],&rolename));
			printf("\n Rol Name :[%d][%s]\n",i,rolename);fflush(stdout);
			printf("\n Dsgn1 [%s]\n",Dsgn1);fflush(stdout);

			if(strstr(rolename,"MBOM") && strstr(rolename,Dsgn1) && strstr(rolename,"Designer") && strstr(rolename,"Default")==NULL ) 
			{
				if(tc_strcmp(Dsgn1,"01")==0) 
				{
					FlaggAssignMBOMPlanner = 0;
					printf("\n Design 01 found so Assigning default Designer \n",Dsgn1);fflush(stdout);
					break;

				}
				printf("\n Match Found for MBOM Designer => %s \n",rolename);fflush(stdout);
				role_tag = role_tags[i];
				CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
				printf("\n Designer : No of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
				
				if(num_of_members>0)
				{
					b=0;

					tag_t*	ptypes		= NULLTAG;
					tag_t*	ptypes2		= NULLTAG;
					int p1=0;
					int p2=0;
					//FlaggAssignMBOMPlanner = 1;
					for (b=0;b<num_of_members ;b++  )
					{
						CALLAPI(SA_ask_groupmember_user(member_tags[b],&user_tag));
						CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
						printf("\n Designer : User ID Name :[%s]\n",userid);

						// Added by Ketan for projectwise mapping//
						ProjectAccessFound=0;
						Gmcnt1=0;
						GmFound1 = NULLTAG;
						GetProjectUserAccessDetails(Projj,userid,&Gmcnt1,&GmFound1);
						printf("\n Designer : Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
						
						countt=0;
						for(countt==0;countt<Gmcnt1;countt++)
						{
								Object_Name  =  NULL;
								CALLAPI(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
								printf("\n Designer : after func :  %s",Object_Name);fflush(stdout);
							
								if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,"Designer") && strstr(Object_Name,"Default")==NULL) 
								{
									printf("\n Designer : Condition Satisfy... ");fflush(stdout);
									ProjectAccessFound=1;
									break;
								}
						}
						printf("\n Designer : ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
						// Ended
						
						if(ProjectAccessFound==1)
						{
							// TCTYPE_find_type("Analyst", "Analyst", &participant_type);
							// EPM_create_participant(member_tags[b], participant_type, &participant_tag);
							// GRM_find_relation_type("HasParticipant", &relation_type);
							// GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							// GRM_save_relation(relation);
							// printf("\n MBOM Designer Assigned..to : [%s]\n",userid);fflush(stdout);
							FlaggAssignMBOMPlanner = 1;

							TCTYPE_find_type("Analyst", "Analyst", &participant_type);
							printf("\n Analyst Test 3333 \n");fflush(stdout);
							setAddTAG_1(&p1,&ptypes,participant_type);
							printf("\n Analyst Test 3333.1 \n");fflush(stdout);
							setAddTAG_1(&p2,&ptypes2,member_tags[b]);
							printf("\n Analyst Test ended 4444 \n");fflush(stdout);
							if((tc_strcmp(DMLrlsType,"TODR") == 0) && (tc_strcmp(DMLrlsType,"") != 0))
							{
								printf("\n MBOM DML release type is TODR, hence breaking loop after single analyst assign-1 \n");fflush(stdout);
								break;
							}
						}
			
					}
					tag_t* participant_list = NULLTAG;
					logical bypass_assignable_check =true;
					int k = 0;

					tag_t   type1TypeTag			= NULLTAG;

					char*    type1type_name;
					printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
					for(k=0;k<p2;k++)
					{
						tag_t type1 = ptypes[k];
						if(type1 != NULLTAG )
						{
							if(TCTYPE_ask_object_type(type1,&type1TypeTag));
							if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
							printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
						}
						else
						{
							printf("\n type is NULL \n");fflush(stdout);
						}
					}

					CALLAPI(PARTICIPANT_add_participants(APLTaskRevT,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
				}
				if(FlaggAssignMBOMPlanner==1)
				{
					printf("\n Designer : Break \n");fflush(stdout);
					break;
				}
			}
			
		}

	}
	//
	printf("\n FlaggAssignMBOMPlanner for default : [%d]\n",FlaggAssignMBOMPlanner);fflush(stdout);

	if(FlaggAssignMBOMPlanner==0)
	{
			printf("\n Ketan Inside Default Group for Designer\n");fflush(stdout);

			z=0;
			for (z=0;z<num_of_roles ;z++ )
			{
				CALLAPI(SA_ask_role_name2(role_tags[z],&rolename));
				printf("\nRol Name :[%d][%s]\n",z,rolename);
				if(strstr(rolename,"Default"))
				{
					printf("\n Got Default Group for Designer \n");
					CALLAPI(SA_find_groupmember_by_role(role_tags[z],group_tag,&num_of_members,&member_tags));
					printf("\n No of Group Members found in Group/Role are :%d\n",num_of_members);
					if(num_of_members>0)
					{
						b=0;

						tag_t*	ptypes		= NULLTAG;
						tag_t*	ptypes2		= NULLTAG;
						int p1=0;
						int p2=0;

						for (b=0;b<num_of_members ;b++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[b],&user_tag));
							CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
							printf("\n User ID Name :[%s]\n",userid);
							// TCTYPE_find_type("Analyst", "Analyst", &participant_type);
							// EPM_create_participant(member_tags[b], participant_type, &participant_tag);
							// GRM_find_relation_type("HasParticipant", &relation_type);
							// GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							// GRM_save_relation(relation);
							// printf("\n Default: MBOM Designer Assigned..to : [%s]\n",userid);fflush(stdout);

							TCTYPE_find_type("Analyst", "Analyst", &participant_type);
							printf("\n Default Analyst Test 3333 \n");fflush(stdout);
							setAddTAG_1(&p1,&ptypes,participant_type);
							printf("\n Default Analyst Test 3333.1 \n");fflush(stdout);
							setAddTAG_1(&p2,&ptypes2,member_tags[b]);
							printf("\n Default Analyst Test ended 4444 \n");fflush(stdout);
							if((tc_strcmp(DMLrlsType,"TODR") == 0) && (tc_strcmp(DMLrlsType,"") != 0))
							{
								printf("\n MBOM DML release type is TODR, hence breaking loop after single analyst assign-2 \n");fflush(stdout);
								break;
							}
							
						}
						tag_t* participant_list = NULLTAG;
						logical bypass_assignable_check =true;
						int k = 0;

						tag_t   type1TypeTag			= NULLTAG;

						char*    type1type_name;
						printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
						for(k=0;k<p2;k++)
						{
							tag_t type1 = ptypes[k];
							if(type1 != NULLTAG )
							{
								if(TCTYPE_ask_object_type(type1,&type1TypeTag));
								if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
								printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
							}
							else
							{
								printf("\n type is NULL \n");fflush(stdout);
							}
						}

						CALLAPI(PARTICIPANT_add_participants(APLTaskRevT,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
					}

				}


			}
			

	}  
	//
	return ITK_ok;

}
int AssignMBOMReviewer(tag_t APLTaskRevT,char*		Proj_Code)
{
	
	char*	Task_no				= NULL;
	char*	Dsgn_No				= NULL;
	char*	Dsgn1				= NULL;
	char*	Dsgn2				= NULL;
	char*	PLT_Code			= NULL;
	char*	APL_Plnr_Grp		= NULL;
	char*	rolename			= NULL;
	char*	userid				= NULL;
	char*	PLT_CodeS			= NULL;
	char	Aggregt[40];
	char*	PltCodeFrmCntrl 	= NULL;
	char	Projj[40];

	tag_t	group_tag				= NULLTAG;
	tag_t	user_tag				= NULLTAG;
	tag_t	relation				= NULLTAG;
	tag_t	participant_type		= NULLTAG;
	tag_t	participant_tag			= NULLTAG;
	tag_t	relation_type			= NULLTAG;
	tag_t*	role_tags				= NULLTAG;
	tag_t	role_tag				= NULLTAG;
	tag_t*	member_tags				= NULLTAG;
	tag_t*	list_of_WSO_cntrl_tags1	= NULLTAG;
	tag_t   qryTagCntrl1			= NULLTAG;

	int		num_of_roles			= 0;
	int		num_of_members			= 0;
	int		i						= 0;
	int		j						= 0;
	int		z						= 0;
	int		b						= 0;
	int		FlaggAssignMBOMReviewer	= 0;
	int		ifail					= 0;
	int		cntrlcnt				= 0;
	int		control_number_found1	= 0;
	int     n_entryCntrl1			= 3;

	// Added by Ketan for Projectwise Mapping
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int countt=0;
	tag_t	*GmFound1 = NULLTAG;
	char *Object_Name  =  NULL;
	// Ended
		
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	//
	char*	Temp_Task_no	= NULL;
	char*	CLSP_Dsgn_Grp	= NULL;
	int max_char_size = 80;
    Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));
	//

	printf("\n Ketan Inside AssignMBOMReviewer  \n");fflush(stdout);

	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	printf("\n AssignMBOMReviewer :Task_no  is :%s \n",Task_no);	fflush(stdout);
	tc_strcpy(Temp_Task_no, Task_no);
    printf("\n Ketan for AssignMBOMReviewer Temp_Task_no :%s \n", Temp_Task_no);fflush(stdout);
	
	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\n Test 1 Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\n Test 2 Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\n Test 3 PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);fflush(stdout);

	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));

	// MB31 || 31MB //
	// 0123    0123

	Dsgn1 = subString_mbom(Dsgn_No,0,2);
	printf("\n MBOM Reviewer Dsgn1 ==> %s\n",Dsgn1);  // 31MB

	Dsgn2 = subString_mbom(Dsgn_No,2,2);
	printf("\n MBOM Reviewer Dsgn2 ==> %s\n",Dsgn2); // MB31

	//if ((tc_strstr(Temp_Task_no, "CL") != NULL) || (tc_strstr(Temp_Task_no, "SP") != NULL))
	if ((tc_strstr(Temp_Task_no, "CL") != NULL) || (tc_strstr(Temp_Task_no, "SP") != NULL) || (tc_strstr(Temp_Task_no, "CO") != NULL))
    {
        printf("\n Inside CL/SP/CO Task for AssignMBOMReviewer\n");fflush(stdout);
        CALLAPI(AOM_ask_value_string(APLTaskRevT, "t5_crdesigngroup", &CLSP_Dsgn_Grp));
        printf("\n CLSP_Dsgn_Grp ==> %s\n", CLSP_Dsgn_Grp);fflush(stdout);

        Dsgn1 = (char *)MEM_alloc(100 * sizeof(char *));
        tc_strcpy(Dsgn1, CLSP_Dsgn_Grp);
        printf("\n Final MBOM AssignMBOMReviewer : CL/SP Dsgn_No ==> %s \n", Dsgn1);fflush(stdout);
    }
	
	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="APLPltInf";
		qry_valuesCntrl1[1]=PLT_Code;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	else
	{
		printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
	}	
	
	printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

	if(control_number_found1>0)
	{
		for(cntrlcnt=0;cntrlcnt<control_number_found1;cntrlcnt++)
		{
			AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo8", &PltCodeFrmCntrl);
			printf("\n PltCodeFrmCntrl: %s\n",PltCodeFrmCntrl);fflush(stdout);
			tc_strcpy(PLT_CodeS,PltCodeFrmCntrl);
		}
	}
	else
	{
		tc_strcpy(PLT_CodeS,"MBOM");
	}
	printf("\n PLT_CodeS: %s\n",PLT_CodeS);fflush(stdout);
	//****************************************************************//

	APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(APL_Plnr_Grp,PLT_CodeS);
			
	tc_strcpy(Projj,Proj_Code);
	printf("\n Projj :[%s]\n",Projj);fflush(stdout);
	
	printf("\n Test0.14.. MBOM Reviewer Group Name:[%s]\n",APL_Plnr_Grp);fflush(stdout);


	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

	if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\n Reviewer: No of Role found in Group are :%d\n",num_of_roles);fflush(stdout);

	// Ketan Added for Reviewer
	if(num_of_roles>0)
	{
		for (i=0;i<num_of_roles ;i++ )
		{
			CALLAPI(SA_ask_role_name2(role_tags[i],&rolename));
			printf("\n Rol Name :[%d][%s]\n",i,rolename);fflush(stdout);
			printf("\n Dsgn1 [%s]\n",Dsgn1);fflush(stdout);
			
			if(strstr(rolename,"MBOM") && strstr(rolename,Dsgn1) && strstr(rolename,"Reviewer") && strstr(rolename,"Default")==NULL ) 
			{
				if(tc_strcmp(Dsgn1,"01")==0) 
				{
					FlaggAssignMBOMReviewer = 0;
					printf("\n Design 01 found so Assigning default Reviewer \n",Dsgn1);fflush(stdout);
					break;

				}
				printf("\n Match Found for MBOM Reviewer => %s \n",rolename);fflush(stdout);
				role_tag = role_tags[i];
				CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
				printf("\n No of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);

				if(num_of_members>0)
				{
					b=0;

					tag_t*	ptypes		= NULLTAG;
					tag_t*	ptypes2		= NULLTAG;
					int p1=0;
					int p2=0;
					//FlaggAssignMBOMReviewer = 1;
					for (b=0;b<num_of_members ;b++  )
					{
						CALLAPI(SA_ask_groupmember_user(member_tags[b],&user_tag));
						CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
						printf("\n Reviewer: User ID Name :[%s]\n",userid);

						// Added by Ketan for projectwise mapping//
						ProjectAccessFound=0;
						Gmcnt1=0;
						GmFound1 = NULLTAG;
						GetProjectUserAccessDetails(Projj,userid,&Gmcnt1,&GmFound1);
						printf("\n Reviewer : Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
						
						countt=0;
						for(countt==0;countt<Gmcnt1;countt++)
						{
								Object_Name  =  NULL;
								CALLAPI(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
								printf("\n Reviewer : after func :  %s",Object_Name);fflush(stdout);
							
								if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,"Reviewer") && strstr(Object_Name,"Default")==NULL) 
								{
									printf("\n Reviewer : Condition Satisfy... ");fflush(stdout);
									ProjectAccessFound=1;
									break;
								}
						}
						printf("\n Reviewer : ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
						// Ended
						
						if(ProjectAccessFound==1)
						{
							// TCTYPE_find_type("T5_DMUReviewer", "T5_DMUReviewer", &participant_type);
							// EPM_create_participant(member_tags[b], participant_type, &participant_tag);
							// GRM_find_relation_type("HasParticipant", &relation_type);
							// GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							// GRM_save_relation(relation);
							// printf("\n MBOM Reviewer Assigned..to : [%s]\n",userid);fflush(stdout);
							FlaggAssignMBOMReviewer = 1;

							TCTYPE_find_type("T5_DMUReviewer", "T5_DMUReviewer", &participant_type);
							printf("\n T5_DMUReviewer Test 3333 \n");fflush(stdout);
							setAddTAG_1(&p1,&ptypes,participant_type);
							printf("\n T5_DMUReviewer Test 3333.1 \n");fflush(stdout);
							setAddTAG_1(&p2,&ptypes2,member_tags[b]);
							printf("\n T5_DMUReviewer Test ended 4444 \n");fflush(stdout);
						}

					}
					tag_t* participant_list = NULLTAG;
					logical bypass_assignable_check =true;
					int k = 0;

					tag_t   type1TypeTag			= NULLTAG;

					char*    type1type_name;
					printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
					for(k=0;k<p2;k++)
					{
						tag_t type1 = ptypes[k];
						if(type1 != NULLTAG )
						{
							if(TCTYPE_ask_object_type(type1,&type1TypeTag));
							if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
							printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
						}
						else
						{
							printf("\n type is NULL \n");fflush(stdout);
						}
					}

					CALLAPI(PARTICIPANT_add_participants(APLTaskRevT,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
				}
				if(FlaggAssignMBOMReviewer==1)
				{
					printf("\n Reviewer : Break \n");fflush(stdout);
					break;
				}
			}
			
		}

	}

	//
	printf("\n FlaggAssignMBOMReviewer for default : [%d]\n",FlaggAssignMBOMReviewer);fflush(stdout);

	if(FlaggAssignMBOMReviewer==0)
	{
			printf("\n Ketan Inside Default Group for Reviewer \n");fflush(stdout);

			z=0;
			for (z=0;z<num_of_roles ;z++ )
			{
				CALLAPI(SA_ask_role_name2(role_tags[z],&rolename));
				printf("\nRol Name :[%d][%s]\n",z,rolename);
				if(strstr(rolename,"Default"))
				{
					printf("\n Got Default Group for Reviewer \n");
					CALLAPI(SA_find_groupmember_by_role(role_tags[z],group_tag,&num_of_members,&member_tags));
					printf("\n No of Group Members found in Group/Role are :%d\n",num_of_members);
					if(num_of_members>0)
					{
						b=0;

						tag_t*	ptypes		= NULLTAG;
						tag_t*	ptypes2		= NULLTAG;
						int p1=0;
						int p2=0;

						for (b=0;b<num_of_members ;b++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[b],&user_tag));
							CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
							printf("\n User ID Name :[%s]\n",userid);
							//TCTYPE_find_type("T5_DMUReviewer", "T5_DMUReviewer", &participant_type);
							//EPM_create_participant(member_tags[b], participant_type, &participant_tag);
							//GRM_find_relation_type("HasParticipant", &relation_type);
							//GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							//GRM_save_relation(relation);
							//printf("\n Default: MBOM Reviewer Assigned..to : [%s]\n",userid);fflush(stdout);

							TCTYPE_find_type("T5_DMUReviewer", "T5_DMUReviewer", &participant_type);
							printf("\n Default T5_DMUReviewer Test 3333 \n");fflush(stdout);
							setAddTAG_1(&p1,&ptypes,participant_type);
							printf("\n Default T5_DMUReviewer Test 3333.1 \n");fflush(stdout);
							setAddTAG_1(&p2,&ptypes2,member_tags[b]);
							printf("\n Default T5_DMUReviewer Test ended 4444 \n");fflush(stdout);
							
						}
						tag_t* participant_list = NULLTAG;
						logical bypass_assignable_check =true;
						int k = 0;

						tag_t   type1TypeTag			= NULLTAG;

						char*    type1type_name;
						printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
						for(k=0;k<p2;k++)
						{
							tag_t type1 = ptypes[k];
							if(type1 != NULLTAG )
							{
								if(TCTYPE_ask_object_type(type1,&type1TypeTag));
								if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
								printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
							}
							else
							{
								printf("\n type is NULL \n");fflush(stdout);
							}
						}

						CALLAPI(PARTICIPANT_add_participants(APLTaskRevT,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
					}

				}


			}
			

	}  
	//
	
	return ITK_ok;

}

int AssignMBOMManagerReview(tag_t APLTaskRevT,char*		Proj_Code)
{
	
	char*		Task_no				= NULL;
	char*		Dsgn_No				= NULL;
	char*		Dsgn1				= NULL;
	char*		Dsgn2				= NULL;
	char*		PLT_Code			= NULL;
	char*		APL_Plnr_Grp		= NULL;
	char*		rolename			= NULL;
	char*		userid				= NULL;
	char*		PLT_CodeS			= NULL;
	char		Aggregt[40];	
	char*		PltCodeFrmCntrl 	= NULL;
	char		Projj[40];

	tag_t		group_tag			= NULLTAG;
	tag_t		user_tag			= NULLTAG;
	tag_t		relation			= NULLTAG;
	tag_t		participant_type	= NULLTAG;
	tag_t		participant_tag		= NULLTAG;
	tag_t		relation_type		= NULLTAG;
	tag_t*		role_tags			= NULLTAG;
	tag_t		role_tag			= NULLTAG;
	tag_t*		member_tags			= NULLTAG;
	tag_t*		list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t		qryTagCntrl1     = NULLTAG;

	int		num_of_roles			= 0;
	int		num_of_members			= 0;
	int		i						= 0;
	int		j						= 0;
	int		z						= 0;
	int		b						= 0;
	int		FlaggAssignMBOMManager	= 0;
	int		ifail					= 0;
	int		cntrlcnt				= 0;
	int		control_number_found1	= 0;
	int     n_entryCntrl1			= 3;

	// Added by Ketan for Projectwise Mapping
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int countt=0;
	tag_t	*GmFound1 = NULLTAG;
	char *Object_Name  =  NULL;
	// Ended	
	
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	//
	char*	Temp_Task_no	= NULL;
	char*	CLSP_Dsgn_Grp	= NULL;
	int max_char_size = 80;
    Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));
	tag_t tsk_dml_rel_type=NULLTAG;
	int count = 0;
	tag_t *DMLRevision = NULLTAG;
	tag_t DMLRevTag =NULLTAG;
	char *Obj_type=NULL;
	char *DMLrlsType=NULL;
	int k=0;

	printf("\n Ketan Inside AssignMBOMManagerReview  \n");fflush(stdout);


	ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
	ITKCALL(GRM_list_primary_objects_only(APLTaskRevT,tsk_dml_rel_type,&count,&DMLRevision));
	printf("\n MBOM DML Revision from Task : %d",count); fflush(stdout);

	for (k=0;k<count;k++ )
	{
		DMLRevTag = DMLRevision[k];
		ITKCALL(AOM_ask_value_string(DMLRevTag,"object_type",&Obj_type));
		printf("\n Obj_type is :%s",Obj_type); fflush(stdout);

		if(tc_strcmp(Obj_type,"T5_MBOMDMLRevision")==0)
		{
			ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLrlsType));
			printf("\n DMLrlsType is :%s",DMLrlsType); fflush(stdout);
		}
	}

	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	printf("\n AssignMBOMManagerReview :Task_no  is :%s \n",Task_no);	fflush(stdout);
	tc_strcpy(Temp_Task_no, Task_no);
    printf("\n Ketan for AssignMBOMManagerReview Temp_Task_no :%s \n", Temp_Task_no);fflush(stdout);
	
	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\n Test 1 Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\n Test 2 Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\n Test 3 PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);fflush(stdout);

	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));

	// MB31 || 31MB //
	// 0123    0123

	Dsgn1 = subString_mbom(Dsgn_No,0,2);
	printf("\n MBOM Manager Dsgn1 ==> %s\n",Dsgn1);  // 31MB

	Dsgn2 = subString_mbom(Dsgn_No,2,2);
	printf("\n MBOM Manager Dsgn2 ==> %s\n",Dsgn2); // MB31

	//if ((tc_strstr(Temp_Task_no, "CL") != NULL) || (tc_strstr(Temp_Task_no, "SP") != NULL))
	if ((tc_strstr(Temp_Task_no, "CL") != NULL) || (tc_strstr(Temp_Task_no, "SP") != NULL) || (tc_strstr(Temp_Task_no, "CO") != NULL))
    {
        printf("\n Inside CL/SP/CO Task for AssignMBOMManagerReview\n");fflush(stdout);
        CALLAPI(AOM_ask_value_string(APLTaskRevT, "t5_crdesigngroup", &CLSP_Dsgn_Grp));
        printf("\n CLSP_Dsgn_Grp ==> %s\n", CLSP_Dsgn_Grp);fflush(stdout);

        Dsgn1 = (char *)MEM_alloc(100 * sizeof(char *));
        tc_strcpy(Dsgn1, CLSP_Dsgn_Grp);
        printf("\n Final MBOM AssignMBOMManagerReview : CL/SP Dsgn_No ==> %s \n", Dsgn1);fflush(stdout);
    }
	

	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="APLPltInf";
		qry_valuesCntrl1[1]=PLT_Code;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	else
	{
		printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
	}	
	
	printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

	if(control_number_found1>0)
	{
		for(cntrlcnt=0;cntrlcnt<control_number_found1;cntrlcnt++)
		{
			AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo8", &PltCodeFrmCntrl);
			printf("\n PltCodeFrmCntrl: %s\n",PltCodeFrmCntrl);fflush(stdout);
			tc_strcpy(PLT_CodeS,PltCodeFrmCntrl);
		}
	}
	else
	{
		tc_strcpy(PLT_CodeS,"MBOM");
	}
	printf("\n PLT_CodeS: %s\n",PLT_CodeS);fflush(stdout);
	//****************************************************************//

	APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(APL_Plnr_Grp,PLT_CodeS);
			
	tc_strcpy(Projj,Proj_Code);
	printf("\n Projj :[%s]\n",Projj);fflush(stdout);
	
	printf("\n Test0.14.. MBOM Manager Group Name:[%s]\n",APL_Plnr_Grp);fflush(stdout);


	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

	if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\n Manager: No of Role found in Group are :%d\n",num_of_roles);fflush(stdout);

	// Ketan Added for Manager
	if(num_of_roles>0)
	{
		for (i=0;i<num_of_roles ;i++ )
		{
			CALLAPI(SA_ask_role_name2(role_tags[i],&rolename));
			printf("\n Rol Name :[%d][%s]\n",i,rolename);fflush(stdout);
			printf("\n Dsgn1 [%s]\n",Dsgn1);fflush(stdout);
			
			if(strstr(rolename,"MBOM") && strstr(rolename,Dsgn1) && strstr(rolename,"Manager") && strstr(rolename,"Default")==NULL ) 
			{
				if(tc_strcmp(Dsgn1,"01")==0) 
				{
					FlaggAssignMBOMManager = 0;
					printf("\n Design 01 found so Assigning default Manager \n",Dsgn1);fflush(stdout);
					break;

				}
				printf("\n Match Found for MBOM Manager => %s \n",rolename);fflush(stdout);
				role_tag = role_tags[i];
				CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
				printf("\n No of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
				
				if(num_of_members>0)
				{
					b=0;

					tag_t*	ptypes		= NULLTAG;
					tag_t*	ptypes2		= NULLTAG;
					int p1=0;
					int p2=0;
					//FlaggAssignMBOMManager = 1;
					for (b=0;b<num_of_members ;b++  )
					{
						CALLAPI(SA_ask_groupmember_user(member_tags[b],&user_tag));
						CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
						printf("\n Manager : User ID Name :[%s]\n",userid);

						// Added by Ketan for projectwise mapping//
						ProjectAccessFound=0;
						Gmcnt1=0;
						GmFound1 = NULLTAG;
						GetProjectUserAccessDetails(Projj,userid,&Gmcnt1,&GmFound1);
						printf("\n Manager : Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
						
						countt=0;
						for(countt==0;countt<Gmcnt1;countt++)
						{
								Object_Name  =  NULL;
								CALLAPI(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
								printf("\n Manager : after func :  %s",Object_Name);fflush(stdout);
							
								if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,"Manager") && strstr(Object_Name,"Default")==NULL) 
								{
									printf("\n Manager : Condition Satisfy... ");fflush(stdout);
									ProjectAccessFound=1;
									break;
								}
						}
						printf("\n Manager : ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
						// Ended

						if(ProjectAccessFound==1)
						{
							// TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
							// EPM_create_participant(member_tags[b], participant_type, &participant_tag);
							// GRM_find_relation_type("HasParticipant", &relation_type);
							// GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							// GRM_save_relation(relation);
							// printf("\n MBOM Manager Assigned..to : [%s]\n",userid);fflush(stdout);
							FlaggAssignMBOMManager = 1;

							TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
							printf("\n ChangeSpecialist1 Test 3333 \n");fflush(stdout);
							setAddTAG_1(&p1,&ptypes,participant_type);
							printf("\n ChangeSpecialist1 Test 3333.1 \n");fflush(stdout);
							setAddTAG_1(&p2,&ptypes2,member_tags[b]);
							printf("\n ChangeSpecialist1 Test ended 4444 \n");fflush(stdout);
							if((tc_strcmp(DMLrlsType,"TODR") == 0) && (tc_strcmp(DMLrlsType,"") != 0))
							{
								printf("\n MBOM DML release type is TODR, hence breaking loop after single reviewer assign-1 \n");fflush(stdout);
								break;
							}
						}

					}
					tag_t* participant_list = NULLTAG;
					logical bypass_assignable_check =true;
					int k = 0;

					tag_t   type1TypeTag			= NULLTAG;

					char*    type1type_name;
					printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
					for(k=0;k<p2;k++)
					{
						tag_t type1 = ptypes[k];
						if(type1 != NULLTAG )
						{
							if(TCTYPE_ask_object_type(type1,&type1TypeTag));
							if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
							printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
						}
						else
						{
							printf("\n type is NULL \n");fflush(stdout);
						}
					}

					CALLAPI(PARTICIPANT_add_participants(APLTaskRevT,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
				}
				if(FlaggAssignMBOMManager==1)
				{
					printf("\n Manager : Break \n");fflush(stdout);
					break;
				}
			}
			
		}

	}

	//
	printf("\n FlaggAssignMBOMManager for default : [%d]\n",FlaggAssignMBOMManager);fflush(stdout);

	if(FlaggAssignMBOMManager==0)
	{
			printf("\n Ketan Inside Default Group for Manager \n");fflush(stdout);

			z=0;
			for (z=0;z<num_of_roles ;z++ )
			{
				CALLAPI(SA_ask_role_name2(role_tags[z],&rolename));
				printf("\nRol Name :[%d][%s]\n",z,rolename);
				if(strstr(rolename,"Default"))
				{
					printf("\n Got Default Group for Manager \n");
					CALLAPI(SA_find_groupmember_by_role(role_tags[z],group_tag,&num_of_members,&member_tags));
					printf("\n No of Group Members found in Group/Role are :%d\n",num_of_members);
					if(num_of_members>0)
					{
						b=0;

						tag_t*	ptypes		= NULLTAG;
						tag_t*	ptypes2		= NULLTAG;
						int p1=0;
						int p2=0;

						for (b=0;b<num_of_members ;b++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[b],&user_tag));
							CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
							printf("\nUser ID Name :[%s]\n",userid);
							// TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
							// EPM_create_participant(member_tags[b], participant_type, &participant_tag);
							// GRM_find_relation_type("HasParticipant", &relation_type);
							// GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							// GRM_save_relation(relation);
							// printf("\n Default: MBOM Manager Assigned..to : [%s]\n",userid);fflush(stdout);

							TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
							printf("\n Default ChangeSpecialist1 Test 3333 \n");fflush(stdout);
							setAddTAG_1(&p1,&ptypes,participant_type);
							printf("\n Default ChangeSpecialist1 Test 3333.1 \n");fflush(stdout);
							setAddTAG_1(&p2,&ptypes2,member_tags[b]);
							printf("\n Default ChangeSpecialist1 Test ended 4444 \n");fflush(stdout);
							if((tc_strcmp(DMLrlsType,"TODR") == 0) && (tc_strcmp(DMLrlsType,"") != 0))
							{
								printf("\n MBOM DML release type is TODR, hence breaking loop after single reviewer assign-2 \n");fflush(stdout);
								break;
							}
							
						}
						tag_t* participant_list = NULLTAG;
						logical bypass_assignable_check =true;
						int k = 0;

						tag_t   type1TypeTag			= NULLTAG;

						char*    type1type_name;
						printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
						for(k=0;k<p2;k++)
						{
							tag_t type1 = ptypes[k];
							if(type1 != NULLTAG )
							{
								if(TCTYPE_ask_object_type(type1,&type1TypeTag));
								if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
								printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
							}
							else
							{
								printf("\n type is NULL \n");fflush(stdout);
							}
						}

						CALLAPI(PARTICIPANT_add_participants(APLTaskRevT,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
					}

				}


			}
			

	} 
	
	return ITK_ok;

}
// Funtion to getting Mcnote DML & Part from Assembly Object
int getRawpart(tag_t AssyTag, int *Retcount, tag_t *RetRawPart)
{
    int ifail = ITK_ok;
    tag_t itemrev = NULLTAG;
    char *partno = NULL;
    char *type_class=NULL;
    char *desview = NULL;
    char *status = NULL;
    tag_t *PartTaskTags = NULLTAG;
    tag_t ParSolItemTag = NULLTAG;
    tag_t tsk_dml_rel_type = NULLTAG;
    tag_t itemTypeTag_class = NULLTAG;
    tag_t *DMLRevision = NULLTAG;
    tag_t *RawPartAsmTags = NULLTAG;
    tag_t DMLRevTag = NULLTAG;
    tag_t class_id1 = NULLTAG;
    tag_t RawPartAsmTag = NULLTAG;
    tag_t relation_type_task = NULLTAG;
    tag_t objTypeTag = NULLTAG;
    tag_t RawMstr = NULLTAG;
    char *DmlId = NULL;
    char *tempnum = NULL;
    char *type_name=NULL;
    const char *select_attrs[] = {"item_id"};
    int rawpartexist;
    int count_dml;
    int count;
    int j;
    int dml = 0;
    int RawPrtcount = 0;
    char vals[30];
    char *class_name1 = NULL;
    char *rwpartno = NULL;
    // const char *str_list[15];
    char FinalItemId[15];

    char *EcnType = NULL;
    // tspartnum=MEM_alloc(30);
    // tempnum=MEM_alloc(30);
    printf("\n Inside the function getRawpart  ");
    fflush(stdout);

    // start process

    rawpartexist = 0;
    ITKCALL(AOM_ask_value_string(AssyTag, "item_id", &partno));
    printf("\n partno:%s ..............", partno);
    fflush(stdout);

    GRM_find_relation_type("CMHasSolutionItem", &relation_type_task);
    GRM_list_primary_objects_only(AssyTag, relation_type_task, &count_dml, &PartTaskTags);
    if (count_dml > 0)
    {
        for (dml = 0; dml < count_dml; dml++)
        {
            ParSolItemTag = PartTaskTags[dml];
            ITKCALL(TCTYPE_ask_object_type(ParSolItemTag, &itemTypeTag_class));
            ITKCALL(TCTYPE_ask_name2(itemTypeTag_class, &type_class));

            printf("\t  type_itemRev ...%s\n", type_class);
            fflush(stdout);
            if (tc_strcmp(type_class, "T5_APLTaskRevision") == 0)
            {
                ITKCALL(AOM_ask_value_string(ParSolItemTag, "item_id", &DmlId));
                printf("\n DmlId %s.....\n", DmlId);
                fflush(stdout);

                ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
                if (tsk_dml_rel_type != NULLTAG)
                {
                    ITKCALL(GRM_list_primary_objects_only(ParSolItemTag, tsk_dml_rel_type, &count, &DMLRevision));
                    printf("\n\t\t APL DML Revision from Task : %d", count);
                    fflush(stdout);
                }

                for (j = 0; j < count; j++)
                {
                    DMLRevTag = DMLRevision[j];

                    ITKCALL(POM_class_of_instance(DMLRevTag, &class_id1));
                    ITKCALL(POM_name_of_class(class_id1, &class_name1));
                    printf("\n\t class_name found1 :%s", class_name1);
                    fflush(stdout);
                    if (tc_strcmp(class_name1, "T5_APLDMLRevision") == 0)
                    {
                        ITKCALL(AOM_ask_value_string(DMLRevTag, "t5_EcnType", &EcnType));
                        printf("\n\t APLDMLtype is :%s", EcnType);
                        fflush(stdout);

                        if (tc_strstr(EcnType, "MC") != NULL)
                        {
                            // rawpartexist++;  //this is temporary solution ,it can be remove while reverse relation would be imposed.
                            printf("\n inside McNote availibilty for part[%s]", partno);
                            fflush(stdout);

                            ITKCALL(ITEM_ask_item_of_rev(AssyTag, &RawMstr));
                            if (TCTYPE_ask_object_type(RawMstr, &objTypeTag))
                                ;
                            if (TCTYPE_ask_name2(objTypeTag, &type_name))
                                ;
                            printf("\n     type_name     %s\n", type_name);
                            fflush(stdout);
                            if (tc_strcmp(type_name, "T5_RawPart") == 0)
                            {
                                GRM_find_relation_type("T5_RPtRel", &relation_type_task);
                                GRM_list_primary_objects_only(RawMstr, relation_type_task, &RawPrtcount, &RawPartAsmTags);
                                printf("\n     RawPrtcount     %d\n", RawPrtcount);
                                fflush(stdout);
                                if (RawPrtcount > 0)
                                {
                                    printf("\n Raw Part Found  ");
                                    fflush(stdout);
                                    RawPartAsmTag = RawPartAsmTags[0];
                                    ITKCALL(AOM_ask_value_string(RawPartAsmTag, "item_id", &rwpartno));
                                    printf("\n rwpartno:%s ..............", rwpartno);
                                    fflush(stdout);
                                    printf("\n Raw Part[%s] Found for assembly [%s]", rwpartno, partno);
                                    fflush(stdout);
                                    rawpartexist++;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // end process

    if (rawpartexist > 0)
    {
        printf("\n Raw Part Exist ");
        fflush(stdout);
        *RetRawPart = RawPartAsmTag;
        *Retcount = rawpartexist;
    }

    return ifail;
}
// Func to getting Mcnote DML & Part from Assembly Object
int tm_updateObjMasterFormNameMBOM(tag_t tObj, char	*cupdname)
{
	int		status;
	
	char	*ObjID		=	NULL;
	char	*ObjName	=	NULL;

	tag_t  reln_type_Reference =NULLTAG;

	printf("\nInside tm_updateMasterFormName");fflush(stdout);

	ITKCALL(AOM_ask_value_string( tObj, "item_id", &ObjID));
	ITKCALL(AOM_ask_value_string( tObj, "object_name", &ObjName));

	printf("\ntm_updateObjMasterFormName: Item ID: %s, Object Name : %s",ObjID,ObjName);fflush(stdout);

	int		n_attchs_ref		=	0;
	GRM_relation_t	*rellist_refs;

	ITKCALL(GRM_find_relation_type("IMAN_master_form",&reln_type_Reference));
    ITKCALL(GRM_list_secondary_objects(tObj,reln_type_Reference,&n_attchs_ref,&rellist_refs));


	if (n_attchs_ref>0)
	{
		int i	=	0;
		for (i= 0; i < n_attchs_ref; i++)
		{
			printf("\n Type Name:");fflush(stdout);
			tag_t	secondary		=	NULLTAG;
			tag_t	relationstr		=	NULLTAG;
			tag_t	objTypeTag		=	NULLTAG;
			char	*type_name		=	NULL;
			

	
			secondary	=	rellist_refs[i].secondary;
			relationstr	=	rellist_refs[i].the_relation;
			type_name	=	NULL;
			

			ITKCALL(TCTYPE_ask_object_type(relationstr,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n Type Name:%s ..............",type_name);fflush(stdout);

			ITKCALL(TCTYPE_ask_object_type(secondary,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n secondary Type Name:%s ..............",type_name);fflush(stdout);
			
            
			/*
			ITKCALL(ITK_set_bypass(TRUE));
            ITKCALL(AOM_lock(secondary));
			ITKCALL(AOM_set_value_string(secondary,"object_name",cupdname));
			ITKCALL(AOM_save_without_extensions(secondary));
			ITKCALL(AOM_unlock(secondary));
			ITKCALL(AOM_refresh(secondary,1));
			*/
			//if (tc_strcmp(type_name,"T5_MBOMDMLMaster")==0)

			if (tc_strcmp(type_name,"T5_MBOMDMLMaster")==0)

			{
				printf("\nInside secondary Type Name:%s,%s ..............",type_name,cupdname);fflush(stdout);

				ITKCALL(AOM_set_value_string(secondary,"object_name",cupdname));
				ITKCALL(AOM_save_without_extensions(secondary));
				ITKCALL(AOM_refresh(secondary,1));
			}
			
		}
	}
	return 0;
}



int tm_updateObjRevMasterFormNameMBOM(tag_t tObj, char	*cupdname)
{
	int status;
	int		n_attchs_ref		=	0;

	char	*dmlrevision		=	NULL;
	char	*ObjID				=	NULL;
	char	*ObjName			=	NULL;

	tag_t	reln_type_Reference =	NULLTAG;
	GRM_relation_t	*rellist_refs;
	
	printf("\nInside tm_updateObjRevMasterFormNameMBOM ");fflush(stdout);

	ITKCALL(AOM_ask_value_string(tObj, "item_revision_id", &dmlrevision));
	printf("\n dmlrevision: %s\n",dmlrevision);fflush(stdout);

	ITKCALL(GRM_find_relation_type("IMAN_master_form",&reln_type_Reference));

	ITKCALL(GRM_list_secondary_objects(tObj,reln_type_Reference,&n_attchs_ref,&rellist_refs));

	if (n_attchs_ref>0)
	{
		int i	=	0;
		for (i= 0; i < n_attchs_ref; i++)
		{
			tag_t	secondary		=	NULLTAG;
			tag_t	relationstr		=	NULLTAG;
			tag_t	objTypeTag		=	NULLTAG;
			char	*type_name		=	NULL;
			char	*mstrnamerev	=	NULL;

			mstrnamerev	=	(char *)MEM_alloc(tc_strlen(cupdname)+tc_strlen(dmlrevision)+15);
			tc_strcpy(mstrnamerev,cupdname);
			tc_strcat(mstrnamerev,"/");
			tc_strcat(mstrnamerev,dmlrevision);
			printf("\n mstrnamerev: %s\n",mstrnamerev);fflush(stdout);


			secondary	=	rellist_refs[i].secondary;
			relationstr	=	rellist_refs[i].the_relation;
			type_name	=	NULL;

			ITKCALL(TCTYPE_ask_object_type(relationstr,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n Type Name:%s ..............",type_name);//fflush(stdout);

			ITKCALL(TCTYPE_ask_object_type(secondary,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n secondary Type Name:%s..............",type_name);//fflush(stdout);
			/*
			ITKCALL(ITK_set_bypass(TRUE));
            ITKCALL(AOM_lock(secondary));
			ITKCALL(AOM_set_value_string(secondary,"object_name",mstrnamerev));
			ITKCALL(AOM_save_without_extensions(secondary));
			ITKCALL(AOM_unlock(secondary));
			ITKCALL(AOM_refresh(secondary,1));
			*/
			//if (tc_strcmp(type_name,"T5_MBOMDMLRevisionMaster")==0)
			if(tc_strcmp(type_name,"T5_MBOMDMLRevisionMaster")==0)
			{
				printf("\nInside secondary Type Name:%s,%s ..............",type_name,cupdname);fflush(stdout);

				ITKCALL(AOM_set_value_string(secondary,"object_name",mstrnamerev));
				ITKCALL(AOM_save_without_extensions(secondary));
				ITKCALL(AOM_refresh(secondary,1));
				printf("I am In Matched T5_MBOMDMLRevisionMaster...................\n");
			}
			else
			{
				printf("Not Matched...................\n");
			}
			

		}
	}
	return 0;
}
void getDesignType(tag_t Item, char	**designBORev, char **designBO)
{
	//char	*type_class					=	NULL;
	int		n_parents					=	0;
	tag_t	itemTypeTag_class			=	NULLTAG;
	tag_t	*parents					=	NULLTAG;
	tag_t	parent						=	NULLTAG;

	printf("Inside getDesignType...!!!");
	
	ITKCALL (TCTYPE_ask_object_type(Item,&itemTypeTag_class));
	ITKCALL (TCTYPE_ask_name2(itemTypeTag_class,designBORev));
	
	printf("\t  type_itemRev ...%s\n", *designBORev);
	//*designBO= (char *) MEM_alloc(tc_strlen(*designBORev) * sizeof(char *) +5);

	ITKCALL (AOM_ask_value_tags(Item,"items_tag",&n_parents,&parents));
	printf("\t  type_item n_parents ...%d\n", n_parents);
	if (n_parents==1)
	{
		parent	=	parents[0];
		
		ITKCALL (TCTYPE_ask_object_type(parent,&itemTypeTag_class));
		ITKCALL (TCTYPE_ask_name2(itemTypeTag_class,designBO));
	
		printf("\t  type_itemRev ...%s\n", *designBO);
		
	}
	else
	{
		printf("\nMore than one item tag return...!!!");fflush(stdout);
	}


	/*if (tc_strcmp(*designBORev,"T5_EE_PartRevision")==0)
	{
		printf("\t  designBO set as T5_EE_Part\n");
		tc_strcpy(*designBO,"T5_EE_Part");
	}
	else if (tc_strcmp(*designBORev,"T5_CkdDmyRevision")==0)
	{
		printf("\t  designBO set as T5_CkdDmy\n");
		tc_strcpy(*designBO,"T5_CkdDmy");
	}
	else if (tc_strcmp(*designBORev,"T5_DummyPartRevision")==0)
	{
		printf("\t  designBO set as T5_DummyPart\n");
		tc_strcpy(*designBO,"T5_DummyPart");
	}
	else if (tc_strcmp(*designBORev,"T5_RawPartRevision")==0)
	{
		printf("\t  designBO set as T5_RawPart\n");
		tc_strcpy(*designBO,"T5_RawPart");
	}
	else if (tc_strcmp(*designBORev,"T5_SparKitRevision")==0)
	{
		printf("\t  designBO set as T5_SparKit\n");
		tc_strcpy(*designBO,"T5_SparKit");
	}
	else if (tc_strcmp(*designBORev,"Design Revision")==0 || tc_strcmp(*designBORev,"Design_0_Revision_alt")==0)
	{
		printf("\t  designBO set as Design\n");
		tc_strcpy(*designBO,"Design");
	}
	else
	{
		printf("\t  condition not matched, so default Design is assigned.\n");
		tc_strcpy(*designBO,"Design");
	}*/
	
	printf("\t  type_itemRev ...%s, BO CLASS : %s\n", *designBORev,*designBO);

}

int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

//functionChange

void setAddStrMBOM(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n setAddStrMBOM %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStrMBOM===%s",(*strset)[*count-1]);fflush(stdout);

}

void  mbom_getPlantDetailsAttr( char * RoleName ,char  getPlantCS[40],char  getPlantOptCS[40],char  getPlantIA[40],char  getPlantStore[40],char  getUserAgency[40],char  getPlantCR[40],char getUsrLocation[40])
{
	 printf("\n Ketan Inside mbom_getPlantDetailsAttr \n");
     char   *PlantName=NULL;

	 char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	 char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *MakeBuy 			= NULL;
	 char *OptionalCS		= NULL;
	 char *InitialAgncy		= NULL;
	 char *StoreLoc			= NULL;
	 char *UserAgncy		= NULL;
	 char *PlantCLosRule	= NULL;
	 char *UserLoc			= NULL;
	 char *PlantOneChar		= NULL;
	 char* APlPltNm			= NULL;
	 int max_char_size = 80;
	 APlPltNm = (char *)MEM_alloc(max_char_size * sizeof(char));

	 printf("\n RoleName => %s\n", RoleName);
     PlantName=subString_mbom(RoleName,3,4);
     printf("\n PlantName => %s\n", PlantName);	 

	 PlantOneChar=subString_mbom(PlantName,3,1);
	 printf("\n PlantOneChar:%s",PlantOneChar);fflush(stdout);

	 if(strstr(PlantName,"STD"))
	 {
	   printf("\n STD Plant \n");fflush(stdout);
	   tc_strcpy(APlPltNm,"");
	 	tc_strcat(APlPltNm,"APL");
	 	tc_strcat(APlPltNm,PlantOneChar);			
	 	printf("\n APlPltNm:%s",APlPltNm);fflush(stdout);
	 }
	 else
	 {
	 	tc_strcpy(APlPltNm,"");
	 	tc_strcat(APlPltNm,PlantName);
	 	printf("\n APlPltNm:%s",APlPltNm);fflush(stdout);			
	 }

	 if(QRY_find2("Control Objects...", &qryTagCntrl1));
	 if (qryTagCntrl1)
	 {
	 	printf("\n Control Object Query Found \n");fflush(stdout);
	 	qry_valuesCntrl1[0]="APLPltInf";
	 	qry_valuesCntrl1[1]=APlPltNm;
	 	qry_valuesCntrl1[2]="0";
	 	
	 	if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	 }
	 else
	 {
	 	printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
	 }	
			
	 printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

	 if(control_number_found1>0)
	 {
		for(cntrlcnt=0;cntrlcnt<control_number_found1;cntrlcnt++)
		{
			AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo1", &MakeBuy);
			printf("\n MakeBuy: %s\n",MakeBuy);fflush(stdout);

			AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo2", &OptionalCS);
			printf("\n OptionalCS: %s\n",OptionalCS);fflush(stdout);

			AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo3", &InitialAgncy);
			printf("\n InitialAgncy: %s\n",InitialAgncy);fflush(stdout);

			AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo4", &StoreLoc);
			printf("\n StoreLoc: %s\n",StoreLoc);fflush(stdout);

			AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo5", &UserAgncy);
			printf("\n UserAgncy: %s\n",UserAgncy);fflush(stdout);

			AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo6", &PlantCLosRule);
			printf("\n PlantCLosRule: %s\n",PlantCLosRule);fflush(stdout);

			AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo7", &UserLoc);
			printf("\n UserLoc: %s\n",UserLoc);fflush(stdout);

			tc_strcpy(getPlantCS,MakeBuy);
			tc_strcpy(getPlantOptCS,OptionalCS);
			tc_strcpy(getPlantIA,InitialAgncy);
			tc_strcpy(getPlantStore,StoreLoc);
			tc_strcpy(getUserAgency,UserAgncy);
			tc_strcpy(getPlantCR,PlantCLosRule);
			tc_strcpy(getUsrLocation,UserLoc);
			
	
		}
	}
	else
	{
		//tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		//tc_strcpy(getPlantOptCS,"bl_occ_t5_PunOptionalCS");
		//tc_strcpy(getPlantIA,"t5_PunIntialAgency");
		//tc_strcpy(getPlantStore,"t5_PunStoreLocation");
		tc_strcpy(getUserAgency,"MBOM");
		tc_strcpy(getPlantCR,"BOMViewClosureRuleMBOM");
		tc_strcpy(getUsrLocation,"MBOM");

		//tc_strcpy(RevRuleInfo1,"MBOM Release and Above");//Deepti TZ1.55
		//tc_strcpy(BVRInfo2,"MBOM View");
		//tc_strcpy(CurMskInfo3,"bl_occ_t5_CurrentViewMaskM");
	}
}


void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

void  get_RRCRBVRCVm(char  RevRuleInfo1[40],char  closRuleInfo2[40],char  BVRInfo3[40],char  CurMskInfo4[40])
{
	 printf("\n ************** Inside of get_RRCRBVRCVm function ***************\n ");fflush(stdout);

	 char    *qry_entryCntrl1[2]  = {"SYSCD","Delete Indicator"};	
	 char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 2;
	 char *RevRule 			= NULL;
	 char *BVR		= NULL;
	 char *CurMsk		= NULL;
	 char *closRule		= NULL;


	 if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="MBOMinfo";
				
				qry_valuesCntrl1[1]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{
				
				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &RevRule);
				printf("\n RevRule: %s\n",RevRule);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &closRule);
				printf("\n closRule: %s\n",closRule);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &BVR);
				printf("\n BVR: %s\n",BVR);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo4", &CurMsk);
				printf("\n CurMsk: %s\n",CurMsk);fflush(stdout);

			
				tc_strcpy(RevRuleInfo1,RevRule);
				tc_strcpy(closRuleInfo2,closRule);
				tc_strcpy(BVRInfo3,BVR);
				tc_strcpy(CurMskInfo4,CurMsk);
			
					
			}
			else
			{
				
		        tc_strcpy(RevRuleInfo1,"MBOM Working and Above");
				tc_strcpy(closRuleInfo2,"BOMViewClosureRuleMBOM");
				tc_strcpy(BVRInfo3,"MBOM View");
				tc_strcpy(CurMskInfo4,"bl_occ_t5_CurrentViewMaskM");
			}

			printf("\n ************** Outside of get_RRCRBVRCVm function***************\n ");fflush(stdout);

}



static int t5UpdateLifecycleStateMBOM(tag_t object_tag, char* lifecycleStateName)
{
	int n_values_checkin	= 0;
	int cunt1				= 0;
	int flag				= 0;
	int	ifail				= 0;
	int st_count1			= 0;

	date_t*	start_end_date	= NULL;
	
	date_t	test_date_1;
	date_t	test_date_2;
	
    char*	value					=NULL;
	char	cNextDate[20]={0};

	char *class_name	 = NULL;
	char *Release_Status = NULL;

	tag_t		class_id					= NULLTAG;
	tag_t		tReleaseStatusList_checkin	= NULLTAG;
	tag_t*		attr_tags_checkin			= NULLTAG;
	tag_t		status_rel					= NULLTAG;
	tag_t*		status_list1				= NULLTAG;
	char *    	propEff_tag				    = NULL;
	tag_t		eff_d						= NULLTAG;

	logical		*is_it_null_checkin		=   NULL;
	logical		*is_it_empty_checkin	=   NULL;
	logical		log1;
	logical		checkout1;
	logical		retain							= 0;
	logical		stat;

	printf("\n Ketan Inside t5UpdateLifecycleStateMBOM \n");

	CALLAPI(POM_class_of_instance(object_tag,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));
	printf("\n class_name is :%s\n",class_name);fflush(stdout);

	CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
	CALLAPI(WSOM_ask_release_status_list(object_tag,&st_count1,&status_list1));
	printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

	CALLAPI(POM_unload_instances (1,&object_tag));
	CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
	CALLAPI(POM_is_loaded(object_tag,&log1));
	if(log1 == 1)
	{
		 printf("\n Load Success \n");
	}
	else
	{
		printf("\n Load Failure \n");
	}

	CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin) );
	printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
	if(n_values_checkin>0)
	{
		CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
		printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);
        flag = 0;
		for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
		{
			printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
			if(AOM_ask_name(attr_tags_checkin[cunt1], &Release_Status));
		    printf("\n  Release_Status changes done: for workspaceobject     %s\n", Release_Status);fflush(stdout);
            if(tc_strcmp(lifecycleStateName,"T5_MBOMReleased")==0)
            {
				if(tc_strcmp(Release_Status,"T5_MBOMReview")==0 || (tc_strcmp(Release_Status,"T5_MBOMWorking")==0) || (strcmp(Release_Status,"MBOM Review")==0) || (strcmp(Release_Status,"MBOM Working")==0))
				{
					CALLAPI(POM_unload_instances (1,&object_tag));
					CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
					CALLAPI(POM_is_loaded(object_tag,&log1));

					CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,flag,1));
					printf("\n cunt 1 == 0 removedd is :%d\n",cunt1);fflush(stdout);

					CALLAPI(POM_save_instances(1,&object_tag,1));

					CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));

					CALLAPI(AOM_lock(object_tag));

					CALLAPI(AOM_save_without_extensions(object_tag));
					CALLAPI(AOM_refresh(object_tag,1));
					CALLAPI(AOM_unlock(object_tag));

				}
				else
				{
					flag = flag+1;
				}
			}
			

		}

	}

	if (RELSTAT_create_release_status(lifecycleStateName,&status_rel));
	if(RELSTAT_add_release_status(status_rel,1,&object_tag,retain));
	/*
	if (tc_strcmp(class_name,"Design_0_Revision_alt")==0 || tc_strcmp(class_name,"Design Revision")==0 )
	{
		CALLAPI(WSOM_ask_effectivity_mode(&stat));

		CALLAPI(AOM_UIF_ask_name(status_rel,"effectivity_text",&propEff_tag));
		CALLAPI(AOM_ask_value_string(propEff_tag,&value));

		getNextDate(cNextDate);
		printf("\n cNextDate:%s",cNextDate);

		CALLAPI(ITK_string_to_date(cNextDate, &test_date_1 ));
		CALLAPI(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));

		start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

		printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

		start_end_date[0] = test_date_1;
		start_end_date[1] = test_date_2;

		CALLAPI(WSOM_status_clear_effectivities (status_rel));
		CALLAPI(WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
		CALLAPI(AOM_save_without_extensions(eff_d));
		CALLAPI(AOM_save_without_extensions(status_rel));
		CALLAPI(AOM_refresh(status_rel,0));
	}*/
	
	char*	PreRevOnly			= NULL;
	char*	RevOnly				= NULL;
	char*	Part_Rev			= NULL;
	char*	Part_Rev_copy		= NULL;
	char*	Part_rev_Id			= NULL;
	char*	PlantLCSFlag		= NULL;
	char*	Part_clr_ind		= NULL;
	char*	Part_no				= NULL;
	char*	old_to_date			= NULL;
	char*	WSO_Name			= NULL;
	char cCurrentAccessDate[20]={0};

	const char *qry_entries[2];	// Multiple Item Queried Error
	const char *qry_values[2];	// Multiple Item Queried Error

	tag_t*	itemclassp			= NULLTAG;
	tag_t	item				= NULLTAG;
	tag_t*	rev_list			= NULL;
	tag_t	Leff_d				= NULLTAG;
	tag_t*	effectivities_tag	= NULL;
	tag_t*  status_list;
	
	int		Item_count      = 0;
	int     ii				= 0;
	int     RevFlag			= 0;
	int     PreRevFlag		= 0;
	int     st_count		= 0;
	int     iLCS			= 0;
	int     cntLcs			= 0;
	int		n_tags_found	= 0;
	int		jj 				= 0;
	int		n_effectivities = 0;
	int		n_dates		 	= 0;
    
	date_t	Ltest_date_1;
	date_t	Ltest_date_2;
	date_t*	Rel_start_end_values	= NULL;
	date_t*	Lstart_end_date			= NULL;

	logical date_is_valid;

	WSOM_open_ended_status_t  	open_ended_or_stock_out;

	//if ((tc_strcmp(class_name,"T5_APLDMLRevision")!=0) && (tc_strcmp(class_name,"T5_APLTaskRevision")!=0) && (tc_strcmp(class_name,"T5_EPARevision")!=0) && (tc_strcmp(class_name,"T5_EPATaskRevision")!=0))
	if (tc_strcmp(class_name,"Design_0_Revision_alt")==0 || tc_strcmp(class_name,"Design Revision")==0 || tc_strcmp(class_name,"T5_ClrPartRevision")==0 )
	{
		
		CALLAPI(WSOM_ask_effectivity_mode(&stat));

		//	getCurrentDateTime(cCurrentAccessDate);
		CALLAPI(AOM_UIF_ask_name(status_rel,"effectivity_text",&propEff_tag));
		//CALLAPI(AOM_ask_value_string(propEff_tag,&value));

		getNextDate(cNextDate);
		printf("\n cNextDate:%s",cNextDate);

		CALLAPI(ITK_string_to_date(cNextDate, &test_date_1 ));
		CALLAPI(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));

		start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

		printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

		start_end_date[0] = test_date_1;
		start_end_date[1] = test_date_2;

		CALLAPI(WSOM_status_clear_effectivities (status_rel));
		CALLAPI(WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
		CALLAPI(AOM_save_without_extensions(eff_d));
		CALLAPI(AOM_save_without_extensions(status_rel));
		CALLAPI(AOM_refresh(status_rel,0));

         // Start Privious Rev and stamp the close date
		 CALLAPI(AOM_ask_value_string(object_tag,"item_revision_id",&Part_Rev));
		 CALLAPI(AOM_ask_value_string(object_tag,"item_revision_id",&Part_Rev_copy));
		 printf("\n Part_Rev: %s", Part_Rev);fflush(stdout);
		 printf("\n Part_Rev_copy: %s", Part_Rev_copy);fflush(stdout);

		CALLAPI(AOM_ask_value_string(object_tag,"item_id",&Part_no));
		printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);
		Part_clr_ind	=	NULL;
		CALLAPI(AOM_ask_value_string(object_tag,"t5_ColourInd",&Part_clr_ind));
		printf("\n\n\t\t Part_clr_ind  is :%s",Part_clr_ind);	fflush(stdout);

		qry_entries[0] ="item_id";
		qry_entries[1] ="object_type";//Multiple Item Queried Error
		qry_values[0] = Part_no;
		if (tc_strcmp(Part_clr_ind,"C")==0)
		{
			qry_values[1] = "T5_ClrPart";//Multiple Item Queried Error Hemal
		}
		else
		{
			//qry_values[1] = "Design";//Multiple Item Queried Error Hemal
			//Handle the different design child class.
			char	*designBORev		=	NULL;
			char	*designBO			=	NULL;
			tag_t	AssyTag			=	NULLTAG;
			//AssyTag=PartTags[k];
			printf("\nBefore getDesignType");fflush(stdout);
			getDesignType(object_tag, &designBORev,&designBO);
			printf("\nAfter getDesignType : %s",designBO);fflush(stdout);
			qry_values[1] = designBO;

		}//Multiple Item Queried Error
		//ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclassp);
		ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found, &itemclassp);//Multiple Item Queried Error
		//ITKCALL(ITEM_find_item(Part_no,&itemclassp));
		item = itemclassp[0];

		CALLAPI(ITEM_list_all_revs (item, &Item_count, &rev_list));
		printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);
			if(Item_count > 0)
			{
				RevFlag = 0;
				PreRevFlag = 0;
				for(ii=Item_count-1;ii>=0;ii--)
				{
				   RevOnly = NULL;
				   PreRevOnly = NULL;
				   CALLAPI(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));
					printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);
					printf("\n Part_rev_Id: %s\n",Part_rev_Id);fflush(stdout);
					if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
					{
						RevFlag = 1;
					}
					printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
					if(RevFlag == 1)
					{
					   RevOnly= strtok( Part_Rev_copy, ";" );
					   PreRevOnly= strtok( Part_rev_Id, ";" );
					   printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
					   printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
					   if(tc_strcmp(RevOnly,PreRevOnly)!=0)
						{
						  PreRevFlag = 1;
						}
					}
					printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
					if(PreRevFlag == 1)
					{
						CALLAPI(WSOM_ask_release_status_list(rev_list[ii],&st_count,&status_list));
						if(st_count == 0)
						{
						printf("\n NO LCS Found for part : %d\n",st_count);fflush(stdout);
						break;
						}
						else
						{
							for (iLCS=0;iLCS<st_count ;iLCS++ )
							{
									CALLAPI(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
									printf("\n class_name: %s\n",class_name);fflush(stdout);
									//if(tc_strcmp(PlantLCSFlag,"CAR")==0)
									//{
									if(tc_strcmp(class_name,lifecycleStateName)==0)
									{
										getCurrentDateTime(cCurrentAccessDate);
										printf("\n Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);
										if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &Ltest_date_2 )))
										{
											return ifail;
										}
										if(ITK_ok != (ifail = WSOM_status_ask_effectivities (status_list[iLCS],&n_effectivities, &effectivities_tag) )) return ifail;
										printf("\n Eff:n_effectivities count:[%d] \n",n_effectivities);fflush(stdout);
										if(n_effectivities > 0)
										{
											for(jj=0;jj<n_effectivities;jj++)
											{
												if(ITK_ok != (ifail = WSOM_eff_ask_dates(status_rel,effectivities_tag[jj],&n_dates,&Rel_start_end_values,&open_ended_or_stock_out )))return ifail;
												printf("\n Eff:no of Rel_start_end_value:%d\n", n_dates);fflush(stdout);
												if(n_dates > 0)
												{
													if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
													{
														return ifail;
													}
													printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
													if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 )))
													{
														return ifail;
													}
													printf(" and  DATE_string_to_date_t..\n");fflush(stdout);
													if(date_is_valid != true)
													{
														printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
													}
													else
													{
														printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
													}
												}
												else
												{
													printf("\n EFF1:NO Eff date available, so setting closure date....");fflush(stdout);
												}
											}
											
											// //
											// printf("\n KEtan update Value\n");fflush(stdout);
											// 
											// CALLAPI(ITK_string_to_date("25-Jul-2023 00:00", &Ltest_date_1 ));
											// CALLAPI(ITK_string_to_date("28-Jul-2023 00:00", &Ltest_date_2 ));
											// 
											// //
											Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
											Lstart_end_date[0] = Ltest_date_1;
											Lstart_end_date[1] = Ltest_date_2;

											printf("\n ERCReview--EFF:Clearing effectivities...");fflush(stdout);
											if(ITK_ok != (ifail = WSOM_status_clear_effectivities (status_list[iLCS])))
											{
												return ifail;
											}

											printf("\n ERCReview--EFF:Creating effectivities...");fflush(stdout);
											if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_list[iLCS], NULLTAG, 2,Lstart_end_date, EFFECTIVITY_closed, &Leff_d )))
											{
												return ifail;
											}
											printf("\n ERCReview--EFF:Saving effectivities...");fflush(stdout);
											if(ITK_ok != (ifail = AOM_save_without_extensions(Leff_d)))
											{
												return ifail;
											}
											printf("\n ERCReview--EFF:Saving Revision...");fflush(stdout);
											if(ITK_ok != (ifail = AOM_save_without_extensions(status_list[iLCS])))
											{
												return ifail;
											}
											printf("\n ERCReview--EFF:Refreshing Revision...");fflush(stdout);
											if(ITK_ok != (ifail = AOM_refresh( status_list[iLCS], 0 )))
											{
												return ifail;
											}
										}
										
										break;

									}
							}
						printf("\n cntLcs inside : %d\n",cntLcs);fflush(stdout);
						break;
						}
					}  /// End Prev Rev  Flag Loop
				}
			} /// End Prev Rev

	}



	return 0;
}




static void MultiExplosion (tag_t line,tag_t line1, int depth,char *taskPrtNo,int reqLevel,int level,char partFndStatus[40])
  {
    int ifail;
	int Item_Revision=0;
	int Item_Revision1=0;
	int Item_ID=0;
	int Item_ID1=0;
    int iChildItemTag;
    int iChildItemTag1;
    char *Item_ID_str, *Item_Revision_str;
    char *Item_ID_str1, *Item_Revision_str1;
	char * ItemName ;
	char * ItemRev ;
    int k=0;
    int n=0;

	tag_t  *children1=NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t   t_ChildItem;

	depth ++;


	printf("\n taskPrtNo:%s ..............",taskPrtNo);fflush(stdout);

	//BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID);
	//BOM_line_ask_attribute_string(line, Item_ID, &Item_ID_str);
	AOM_UIF_ask_value(line, "bl_item_item_id", &Item_ID_str); 
	printf("\n Item_ID_str =%s\n",Item_ID_str);fflush(stdout);

	//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
	//BOM_line_ask_attribute_tag(line, iChildItemTag, &t_ChildItemRev);
	AOM_ask_value_tag (line,bomAttr_lineItemRevTag, &t_ChildItemRev);

    //BOM_line_look_up_attribute (( char * ) bomAttr_lineItemTag , &iChildItemTag1);
	//BOM_line_ask_attribute_tag(line, iChildItemTag1, &t_ChildItem);
	AOM_ask_value_tag (line,bomAttr_lineItemTag, &t_ChildItem);

	AOM_ask_value_string(t_ChildItemRev,"item_id",&ItemName);
	printf("\n child ItemName:%s ..............",ItemName);fflush(stdout);

	if(tc_strcmp(taskPrtNo,ItemName)==0)
	{
		//tc_strcpy(partFndStatus,"Y");
		tc_strcpy(partFndStatus,"Y");

		goto CLEANUP;
		return ;
	}

	if( level >= reqLevel )
	{
		goto CLEANUP;
	}

	BOM_line_ask_child_lines (line, &n, &children1);
	printf("\n No of child objects for [%s]:[%d]\n",Item_ID_str,n);fflush(stdout);

	level = level + 1;
	for (k = 0; k < n; k++)
	{
		BOM_line_unpack (children1[k]);
		MultiExplosion(children1[k],line, 0,taskPrtNo,reqLevel,level,partFndStatus);
	}
	level = level - 1;
    MEM_free (children1);

	CLEANUP:
		 printf("\n Inside CLEANUP");fflush(stdout);

  }


int mbom_dml_task_assigment( EPM_action_message_t msg )
{

	int				error_code	= ITK_ok;
	int             ifail				= 0;		
		
	char*	Proj_Code			= NULL;
	char*	item_type			= NULL;
	//char    type_name[TCTYPE_name_size_c+1];
	char*	type_name			= NULL;
	char*	item_id				= NULL;
	char*	Task_no				= NULL;
	char**	DesignGroupList;
	char*	CurrentTask			= NULL;
	char*	parent_name			= NULL;
	char*	ecntypeVal			= NULL;
	char*	ERC_MBOMReleaseType	= NULL;
	char*	tsk_object_name		= NULL ;
	char*	tsk_object_type		= NULL ;
	
	int		TaskCnt					=	0;
	int		count					=	0;
	int	  noAttachment,noTaskAttachment 	= 0;
	
	tag_t   APLTaskRevT         = NULLTAG;
	tag_t   Task_rev_tag        = NULLTAG;
	tag_t   objTypeTag			= NULLTAG;
	tag_t	rootTask			= NULLTAG;
	tag_t	*attachments		= NULLTAG;
	tag_t 	relation_type       = NULLTAG;
	tag_t	*TaskRevision		= NULLTAG;

	tag_t	DML_tag		= NULLTAG;
	tag_t	DML_rev_tag = NULLTAG;
	
	char*			DML_Num				= NULL;

	printf("\n ************** Ketan inside mbom_dml_task_assigment***************\n ");fflush(stdout);


	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n mbom_dml_task_assigment \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
    printf("\n CurrentTask => %s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n Parent Name => %s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("\n Target Attachment => %d\n",noAttachment);fflush(stdout);
	
	if(noAttachment > 0)
	{
		Task_rev_tag = attachments[0];
		if(TCTYPE_ask_object_type(Task_rev_tag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n type_name changes done: for workspaceobject => %s\n", type_name);fflush(stdout);
	}

	//if(strcmp(type_name,"T5_MBOMDMLRevision")==0)
	if(strcmp(type_name,"T5_MBOMTASKRevision")==0)
	{
		    printf("\n inside NEW class T5_MBOMTASKRevision......\n");fflush(stdout);
			AOM_ask_value_string( Task_rev_tag, "item_id", &item_id);
			AOM_ask_value_string( Task_rev_tag, "current_id", &Task_no);

			printf("\n MBOM Task_no => %s \n",Task_no);fflush(stdout);
			
			DML_Num=tc_strtok(Task_no,"_");
			printf("\n DML_Num:[%s],[%s]\n",DML_Num,Task_no);

			tc_strcat(DML_Num,"_MBOM");

			printf("\n Final MBOM DML_Num => [%s]\n",DML_Num);
			
			CALLAPI(ITEM_find_item (DML_Num, &DML_tag));

			if(DML_tag != NULLTAG )
			{

				CALLAPI(ITEM_ask_latest_rev(DML_tag,&DML_rev_tag));

				AOM_ask_value_string( DML_rev_tag, "t5_cprojectcode", &Proj_Code);
				AOM_ask_value_string( DML_rev_tag, "t5_MBOMRlzType", &ecntypeVal);
				AOM_ask_value_string( DML_rev_tag, "t5_rlstype", &ERC_MBOMReleaseType);

				printf("\n t5_MBOMRlzType : %s\n",ecntypeVal);fflush(stdout);
				printf("\n ERC_MBOMReleaseType : %s\n",ERC_MBOMReleaseType);fflush(stdout);

				GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);

				CALLAPI(GRM_list_secondary_objects_only(DML_rev_tag,relation_type,&count,&TaskRevision));
				printf("\n No of Task found in MBOM DML => %d \n",count);fflush(stdout);
				{
					for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
					{
						tsk_object_name = NULL ;
						tsk_object_type = NULL ;

						APLTaskRevT = TaskRevision[TaskCnt];
						
						CALLAPI(AOM_ask_value_string(TaskRevision[TaskCnt],"item_id",&tsk_object_name));
						CALLAPI(AOM_ask_value_string(TaskRevision[TaskCnt],"object_type",&tsk_object_type));
						printf("\n Task => %s tsk_object_type is => %s \n",tsk_object_name,tsk_object_type);fflush(stdout);

						//if(tc_strstr(tsk_object_name,"MB_")!=NULL)
						if((tc_strstr(tsk_object_name,"MB_")!=NULL)||(tc_strstr(tsk_object_name,"MM_")!=NULL))
						{
							printf("\n User created task: %s assigning to Planner / Reviewer / Manager\n",tsk_object_name);fflush(stdout);
							CALLAPI(AssignMBOMPlanner(APLTaskRevT, Proj_Code));
							CALLAPI(AssignMBOMReviewer(APLTaskRevT, Proj_Code));
							CALLAPI(AssignMBOMManagerReview(APLTaskRevT, Proj_Code));
						}
						else
						{
							printf("\n System created task: %s \n",tsk_object_name);fflush(stdout);
							if(strcmp(ERC_MBOMReleaseType,"Veh")==0) // Added by Ketan
							{
								printf("\n Inside Veh DML. Assigning to Planner / Reviewer / Manager  to task: %s\n",tsk_object_name);fflush(stdout);
								CALLAPI(AssignMBOMPlanner(APLTaskRevT, Proj_Code));
								CALLAPI(AssignMBOMReviewer(APLTaskRevT, Proj_Code));
								CALLAPI(AssignMBOMManagerReview(APLTaskRevT, Proj_Code));
							}
							else
							{
								printf("\n ERC Flown Task: so Assigning to Planner / Manager  to task: %s\n",tsk_object_name);fflush(stdout);
								CALLAPI(AssignMBOMPlanner(APLTaskRevT, Proj_Code));
								CALLAPI(AssignMBOMManagerReview(APLTaskRevT, Proj_Code));
							}
						}

							
					}
	              }
			}
	}
	else
	{
	  	printf("\n No proper class T5_MBOMTASKRevision......\n");fflush(stdout);
	}

	return error_code;
}

//sanket




//venkat added

extern EPM_decision_t DLLAPI mbom_dml_default_group_checks_Func(EPM_rule_message_t msg)
{
    EPM_decision_t decision;
    int status;
    tag_t rootTask = NULLTAG;
    tag_t qryTagCntrl = NULLTAG;
    tag_t objTypeTag = NULLTAG;
    tag_t dml_rev_tag = NULLTAG;
    tag_t user_tag = NULLTAG;
    tag_t *TargetAttch = NULLTAG;
    tag_t *member_tags = NULLTAG;

    tag_t *Dflt_grp_cntrl_tags = NULLTAG;

    char *CurrentTask = NULL;
    char *parent_name = NULL;
    char *Task_no = NULL;
    char *DML_no = NULL;
    char *Aplplannergroup = NULL;
    char *DisAplplannergroup = NULL;
    char *Aplreviwergroup = NULL;
    char *DisAplreviwergroup = NULL;
    char *AplParticipant = NULL;
    char *Dsgn_No = NULL;
    char *PLT_Code = NULL;
    char *DmlNO = NULL;
    char *PLT_CodeS = NULL;
    char *APL_Plnr_Grp = NULL;
    char *userid = NULL;
    char *Plantname = NULL;
    char *Planner = NULL;
    char *CurrentDgnGrp = NULL;

    //char type_name[TCTYPE_name_size_c + 1];
	char*	type_name	= NULL;
   
    char rolename[SA_name_size_c + 1];

    int iNumAttch = 0;
    int n_entrycoCntrl = 3;

    int grp_control_number_found = 0;
    int defaultgroupplannerflag = 0;
    int defaultgroupreviewerflag = 0;
    int DMUReviewergroupreviewerflag = 0;
    int *num_of_members = 0;
    char *ReviwerPlantname = NULL;
    char *ReviwerCurrentDgnGrp = NULL;
    char *Reviwer = NULL;
    char *info3 = NULL;
    char *current_Task_no = NULL;

    Plantname = (char *)MEM_alloc(100 * sizeof(char *));
    ReviwerPlantname = (char *)MEM_alloc(100 * sizeof(char *));
    CurrentDgnGrp = (char *)MEM_alloc(100 * sizeof(char *));
    ReviwerCurrentDgnGrp = (char *)MEM_alloc(100 * sizeof(char *));
    PLT_CodeS = (char *)MEM_alloc(100 * sizeof(char *));
    Planner = (char *)MEM_alloc(100 * sizeof(char *));
    Reviwer = (char *)MEM_alloc(100 * sizeof(char *));

    char *qry_dlt_grp_entryCntrl[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
    char **qry_dlt_grp_valuesCntrl = (char **)MEM_alloc(5 * sizeof(char *));

    printf("\nInside mbom_dml_default_group_checks_Func111111");
    fflush(stdout);

    ITKCALL(EPM_ask_root_task(msg.task, &rootTask));
    printf("\n mbom_dml_default_group_checks_Func \n");
    fflush(stdout);

    ITKCALL(AOM_ask_value_string(msg.task, "object_name", &CurrentTask));
    printf("\nCurrentTask:%s\n", CurrentTask);
    fflush(stdout);
    ITKCALL(AOM_ask_value_string(rootTask, "object_name", &parent_name));
    printf("\nParent Name:%s\n", parent_name);
    fflush(stdout);

    char *group = (char *)MEM_alloc(200);

	int	commondefaultgrpflag	= 0 ;

    if (QRY_find2("Control Objects...", &qryTagCntrl))
        ;
    if (qryTagCntrl)
    {
        printf("\nDefault group Control Object Query Found \n");
        fflush(stdout);
        qry_dlt_grp_valuesCntrl[0] = "MbomPlannerandReviewer";
        qry_dlt_grp_valuesCntrl[1] = "DefaultGroup";

        qry_dlt_grp_valuesCntrl[2] = "0";

        if (QRY_execute(qryTagCntrl, n_entrycoCntrl, qry_dlt_grp_entryCntrl, qry_dlt_grp_valuesCntrl, &grp_control_number_found, &Dflt_grp_cntrl_tags))
            ;
    }
    printf("\nNo of control object found for default group:%d\n", grp_control_number_found);
    fflush(stdout);

    if (grp_control_number_found > 0)
    {
		ITKCALL(AOM_ask_value_string(Dflt_grp_cntrl_tags[0],"t5_Userinfo3",&info3));
		printf("\n MBOM designeranddReviewer info3: %s",info3);fflush(stdout);

        ITKCALL(EPM_ask_attachments(rootTask, EPM_target_attachment, &iNumAttch, &TargetAttch));
        printf("\nNo of Target Attachements:%d\n", iNumAttch);
        fflush(stdout);

        if (iNumAttch > 0)
        {
            dml_rev_tag = TargetAttch[0];
            ITKCALL(TCTYPE_ask_object_type(dml_rev_tag, &objTypeTag));
            ITKCALL(TCTYPE_ask_name2(objTypeTag, &type_name));

            printf("\n workspaceobject  type_name   %s\n", type_name);
            fflush(stdout);

                ITKCALL(AOM_ask_value_string(dml_rev_tag, "item_id", &Task_no));
                ITKCALL(AOM_ask_value_string(dml_rev_tag, "current_id", &DML_no));
                printf("\n\n\t\t current task item id  : %s", Task_no);
                fflush(stdout);

                char *DMLNO = tc_strtok(Task_no, "_");
                char *Dsgn_No = tc_strtok(NULL, "_");
                char *DMLPlant = tc_strtok(NULL, "_");

                printf("\n\n\t\t inside mbom task :DMLNO : Designgrp:DMLPlant  : [%s][%s][%s]", DMLNO, Dsgn_No, DMLPlant);
                fflush(stdout);
				tag_t	DML_tag		= NULLTAG;
				tag_t	DMLrevtag = NULLTAG; 
				char*	ERC_MBOMReleaseType	= NULL;


				ITKCALL(AOM_ask_value_string(dml_rev_tag, "item_id", &current_Task_no));
				printf("\n\n\t\t current_Task_no  : %s", current_Task_no);fflush(stdout);
                
				ITKCALL(ITEM_find_item (DMLNO, &DML_tag));
				
			
				if(DML_tag != NULLTAG )
				{

					ITKCALL(ITEM_ask_latest_rev(DML_tag,&DMLrevtag));
					AOM_ask_value_string( DMLrevtag, "t5_rlstype", &ERC_MBOMReleaseType);

					printf("\n ERC_MBOMReleaseType : %s\n",ERC_MBOMReleaseType);fflush(stdout);
				}

					tag_t	relation_type	= NULLTAG;
					tag_t*	Part_objects	= NULLTAG;
					int		part_cnt	= 0;

					char*	tcParobject_name	= NULL;
					char*	changeDMUReviewGrp	= NULL;
					char*	AnaDgnReviewr	= NULL;
					char*	anlstDsngrReviewGrp	= NULL;
					tag_t	ObjTypDmlCRB	= NULLTAG;

					ITKCALL(GRM_find_relation_type("HasParticipant", &relation_type));
					ITKCALL(GRM_list_secondary_objects_only(dml_rev_tag, relation_type, &part_cnt, &Part_objects));
					printf("\n partcipant_cnt : [%d]\n",part_cnt);fflush(stdout);
					if (part_cnt > 0)
					{
						int ptcnt = 0;

						for (ptcnt= 0; ptcnt<part_cnt;ptcnt++ )
						{
							
							tcParobject_name	= NULL;
							AnaDgnReviewr		= NULL;
							anlstDsngrReviewGrp	= NULL;
							ObjTypDmlCRB		= NULLTAG;
							DMUReviewergroupreviewerflag	= 0;

							ITKCALL(TCTYPE_ask_object_type(Part_objects[ptcnt],&ObjTypDmlCRB));
						
							
							ITKCALL( TCTYPE_ask_name2(ObjTypDmlCRB,&tcParobject_name));
							
							printf("\n\n\t\t Analyst and ChangeSpecialist1 tcParobject_name :   %s\n",tcParobject_name);
							fflush(stdout);
							if (tc_strcmp(tcParobject_name,"Analyst")==0)
							{
							
								ITKCALL(AOM_UIF_ask_value(Part_objects[ptcnt],"fnd0AssigneeUser",&AnaDgnReviewr));
								ITKCALL(AOM_UIF_ask_value(Part_objects[ptcnt],"assignee",&anlstDsngrReviewGrp));
								printf("\n TASK: Analyst: [%s] Group: [%s] ",AnaDgnReviewr,anlstDsngrReviewGrp);fflush(stdout);
								// TASK: DMU Reviewer: [Ketan Bhut (kbb910337)] Group: [MBOM/MBOM_Default/Ketan Bhut (kbb910337)]

								Plantname = tc_strtok(anlstDsngrReviewGrp, "/"); // APLCAR
								CurrentDgnGrp = tc_strtok(NULL, "/");           // 00_APLC_Planner
								Planner = tc_strtok(NULL, "/");                 // APLPlanner

								printf("\n\n\t\t plant group and Desinger :  [%s] : [%s] :[%s] AND [%s]\n", Plantname, CurrentDgnGrp, Planner, Dsgn_No);fflush(stdout);
								
								if ((tc_strstr(CurrentDgnGrp, "MBOM") != NULL)  && (tc_strstr(CurrentDgnGrp, "Designer") != NULL) && (tc_strstr(CurrentDgnGrp, "Default") == NULL))
								{
									printf("\n mbom planner is assigned to as per group\n");
									fflush(stdout);
									defaultgroupplannerflag++;
								}
								/*if (tc_strstr(CurrentDgnGrp, "Default") != NULL)
								{
										printf("\n Manager Reviewr DefultGroup has been found");
										fflush(stdout);
										commondefaultgrpflag++;
										
								}*/

								
							}
							else
							{
								printf("\n\n\t\t else condition Analyst and ChangeSpecialist1 tcParobject_name :   %s\n",tcParobject_name);
								fflush(stdout);
								if (tc_strcmp(tcParobject_name,"ChangeSpecialist1")==0)
								{
								
									ITKCALL(AOM_UIF_ask_value(Part_objects[ptcnt],"fnd0AssigneeUser",&AnaDgnReviewr));
									ITKCALL(AOM_UIF_ask_value(Part_objects[ptcnt],"assignee",&changeDMUReviewGrp));
									printf("\n TASK: DMU Reviewer: [%s] Group: [%s] ",AnaDgnReviewr,changeDMUReviewGrp);fflush(stdout);
									// TASK: DMU Reviewer: [Ketan Bhut (kbb910337)] Group: [MBOM/MBOM_Default/Ketan Bhut (kbb910337)]
									
									
									ReviwerPlantname = tc_strtok(changeDMUReviewGrp, "/");
									ReviwerCurrentDgnGrp = tc_strtok(NULL, "/");
									Reviwer = tc_strtok(NULL, "/");

									printf("\n\n\t\tBefore Reviewer:Plant group and reviewer:[%s] : [%s] and [%s]\n", ReviwerPlantname, ReviwerCurrentDgnGrp, Reviwer);
									// Before Reviewer:Plant group and reviewer:[MBOM] : [00_MBOM_Managers] and [Amar Kate (akk923977)]
									fflush(stdout);

									if ((tc_strstr(ReviwerCurrentDgnGrp, "MBOM") != NULL) && (tc_strstr(ReviwerCurrentDgnGrp, "Managers") != NULL) && (tc_strstr(ReviwerCurrentDgnGrp, "Default") == NULL))
									{
										printf("\n mbom reviewer is assigned to as per group\n");
										fflush(stdout);
										defaultgroupreviewerflag++;
									}
									/*if (tc_strstr(ReviwerCurrentDgnGrp, "Default") != NULL)
									{
										printf("\n Manager Reviewr DefultGroup has been found");
										fflush(stdout);
										commondefaultgrpflag++;
										
									}*/

									
								}
								else
								{
									printf("\n No  Analyst and Change Specialist1 \n");fflush(stdout);
										
								}
							}
						}
						
					}

					/*ITKCALL(AOM_UIF_ask_value(dml_rev_tag, "Analyst", &DisAplplannergroup));
					printf("\n\n\t\t Mbom Desinger Assigned Group :  %s\n", DisAplplannergroup);
					fflush(stdout);

					Plantname = tc_strtok(DisAplplannergroup, "/"); // APLCAR
					CurrentDgnGrp = tc_strtok(NULL, "/");           // 00_APLC_Planner
					Planner = tc_strtok(NULL, "/");                 // APLPlanner

					printf("\n\n\t\t plant group and Desinger :  [%s] : [%s] :[%s] AND [%s]\n", Plantname, CurrentDgnGrp, Planner, Dsgn_No);
					 //plant group and Desinger :  [MBOM] : [MBOM_Default] :[Ketan Bhut (kbb910337)] AND [60MM]
					 //Mbom Desinger Assigned Group :  MBOM/MBOM_Default/Ketan Bhut (kbb910337)
					 // MBOM/00_MBOM_Designer/Amar Kate (akk923977)
					fflush(stdout);
					
					if ((tc_strstr(CurrentDgnGrp, "MBOM") != NULL)  && (tc_strstr(CurrentDgnGrp, "Designer") != NULL) && (tc_strstr(CurrentDgnGrp, "Default") == NULL))
					{
						printf("\n mbom planner is assigned to as per group\n");
						fflush(stdout);
						defaultgroupplannerflag++;
					}

					ITKCALL(AOM_UIF_ask_value(dml_rev_tag, "ChangeSpecialist1", &DisAplreviwergroup));
					printf("\n\n\t\t mbom Assigned  reviewer Group :  %s\n", DisAplreviwergroup);
					fflush(stdout);

					ReviwerPlantname = tc_strtok(DisAplreviwergroup, "/");
					ReviwerCurrentDgnGrp = tc_strtok(NULL, "/");
					Reviwer = tc_strtok(NULL, "/");

					printf("\n\n\t\tBefore Reviewer:Plant group and reviewer:[%s] : [%s] and [%s]\n", ReviwerPlantname, ReviwerCurrentDgnGrp, Reviwer);
					// Before Reviewer:Plant group and reviewer:[MBOM] : [00_MBOM_Managers] and [Amar Kate (akk923977)]
					fflush(stdout);

					if ((tc_strstr(ReviwerCurrentDgnGrp, "MBOM") != NULL) && (tc_strstr(ReviwerCurrentDgnGrp, "Managers") != NULL) && (tc_strstr(ReviwerCurrentDgnGrp, "Default") == NULL))
					{
						printf("\n mbom reviewer is assigned to as per group\n");
						fflush(stdout);
						defaultgroupreviewerflag++;
					}*/

				if( (tc_strcmp(ERC_MBOMReleaseType, "Veh") == 0)||(tc_strstr(current_Task_no, "MB_")!= NULL)||(tc_strstr(current_Task_no, "MM_")!= NULL))
				{

						relation_type	= NULLTAG;
						Part_objects	= NULLTAG;
						part_cnt	= 0;
					ITKCALL(GRM_find_relation_type("HasParticipant", &relation_type));
					ITKCALL(GRM_list_secondary_objects_only(dml_rev_tag, relation_type, &part_cnt, &Part_objects));
					printf("\n partcipant_cnt : [%d]\n",part_cnt);fflush(stdout);
					if (part_cnt > 0)
					{
						int ptdcnt = 0;
						DMUReviewergroupreviewerflag	= 0;


						for (ptdcnt= 0; ptdcnt<part_cnt;ptdcnt++ )
						{
							
							char*	tcDmuParobject_name	= NULL;
							char*	DMUReviewr	= NULL;
							char*	DMUReviewGrp	= NULL;
							tag_t	ObjTypDmlCRB	= NULLTAG;
							
							ITKCALL(TCTYPE_ask_object_type(Part_objects[ptdcnt],&ObjTypDmlCRB));
						
							
							ITKCALL( TCTYPE_ask_name2	(ObjTypDmlCRB,&tcDmuParobject_name));
							
							printf("\n\n\t\t tcParobject_name1111122 :   %s\n",tcDmuParobject_name);
							fflush(stdout);
							if (tc_strcmp(tcDmuParobject_name,"T5_DMUReviewer")==0)
							{
							
								ITKCALL(AOM_UIF_ask_value(Part_objects[ptdcnt],"fnd0AssigneeUser",&DMUReviewr));
								ITKCALL(AOM_UIF_ask_value(Part_objects[ptdcnt],"assignee",&DMUReviewGrp));
								printf("\n TASK: DMU Reviewer: [%s] Group: [%s] ",DMUReviewr,DMUReviewGrp);fflush(stdout);
								// TASK: DMU Reviewer: [Ketan Bhut (kbb910337)] Group: [MBOM/MBOM_Default/Ketan Bhut (kbb910337)]
								
								fflush(stdout);
								if (tc_strstr(DMUReviewGrp, "Default") == NULL)
								{
									printf("\n DMUReviewr DefultGroup has been found");
									fflush(stdout);
									DMUReviewergroupreviewerflag++;
									break;
								}
							}
						}
						
					}

				}
					printf("\n\n Both designer Reviewer and DMUReviewer flag111111  : %d :%d and %d", defaultgroupplannerflag, defaultgroupreviewerflag, DMUReviewergroupreviewerflag);
					fflush(stdout);

				if( (tc_strcmp(ERC_MBOMReleaseType, "Veh") == 0)||(tc_strstr(current_Task_no, "MB_") != NULL)||(tc_strstr(current_Task_no, "MM_") != NULL))
				{
					if ((defaultgroupplannerflag == 0) && (defaultgroupreviewerflag == 0)&&(DMUReviewergroupreviewerflag == 0))
					{
						printf("\n\n All designer DMU reviewer and Reviewer flag  : %d  :%d and %d", defaultgroupplannerflag, defaultgroupreviewerflag,DMUReviewergroupreviewerflag);
						fflush(stdout);

						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error, ITK_err, "Please Assign Designer, Changespecilist1 and DMU Reviewer.");
						decision = EPM_nogo;
						return ITK_err;
					}
					else if ((defaultgroupplannerflag == 0)&&(DMUReviewergroupreviewerflag == 0))
					{
						printf("\n\n inside designer and DMUreviewer flag ");
						fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error, ITK_err, "Please Assign Analyst and DMUReviewer");
						decision = EPM_nogo;
						return ITK_err;
					}
					else if ((defaultgroupplannerflag == 0)&&(defaultgroupreviewerflag == 0))
					{
						printf("\n\n inside designer and Reviewer flag ");
						fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error, ITK_err, "Please Assign Analyst and Changespecilist1");
						decision = EPM_nogo;
						return ITK_err;
					}
					else if ((DMUReviewergroupreviewerflag == 0)&&(defaultgroupreviewerflag == 0))
					{
						printf("\n\n inside DMUreviewer and Reviewer flag ");
						fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error, ITK_err, "Please Assign DMUReviewer and Changespecilist1");
						decision = EPM_nogo;
						return ITK_err;
					}
					else if (defaultgroupreviewerflag == 0)
					{
						printf("\n\n inside Reviwer flag ");
						fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error, ITK_err, "Please Assign Changespecilist1.");
						decision = EPM_nogo;
						return ITK_err;
					}
					else if (DMUReviewergroupreviewerflag == 0)
					{
						printf("\n\n inside DMUReviewer flag ");
						fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error, ITK_err, "Please Assign DMUReviewer.");
						decision = EPM_nogo;
						return ITK_err;
					}
					else if (defaultgroupplannerflag == 0)
					{
						printf("\n\n inside Designer flag ");
						fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error, ITK_err, "Please Assign Analyst.");
						decision = EPM_nogo;
						return ITK_err;
					}
					else
					{

						decision = EPM_go;
					}
				}
				else
				{
					if ((defaultgroupplannerflag == 0)&&(defaultgroupreviewerflag == 0))
					{
						printf("\n\n inside designer and Reviewer flag ");
						fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error, ITK_err, "Please Assign Analyst and Changespecilist1");
						decision = EPM_nogo;
						return ITK_err;
					}
				
				
					else if (defaultgroupreviewerflag == 0)
					{
						printf("\n\n inside Reviwer flag ");
						fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error, ITK_err, "Please Assign Changespecilist1.");
						decision = EPM_nogo;
						return ITK_err;
					}
					else if (defaultgroupplannerflag == 0)
					{
						printf("\n\n inside Designer flag ");
						fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error, ITK_err, "Please Assign Analyst.");
						decision = EPM_nogo;
						return ITK_err;
					}
					else
					{

						decision = EPM_go;
					}
				
				}
            //}
        }
    }
    else
    {
        printf("\n\n Default group control objects are not found  : %d", grp_control_number_found);
        fflush(stdout);
        decision = EPM_go;
    }

    return decision;
}

//venkat
int mbom_dml_task_default_group(EPM_action_message_t msg)
{
    int error_code = ITK_ok;
    int ifail = 0;
    int noAttachment = 0;
    int DefaultPlannerflag = 0;
    int count = 0;
    int TaskCnt = 0;
    char *CurrentTask = NULL;
    char *parent_name = NULL;
    char *Aplreviwergroup = NULL;
    char *Aplplannergroup = NULL;
    char *DisAplplannergroup = NULL;
    char *DisAplreviwergroup = NULL;
    char *DisDMUReviewergroup = NULL;
    char *item_id = NULL;
    char *DML_no = NULL;
    char *type_name = NULL;
    //char type_name[TCTYPE_name_size_c + 1];
    tag_t rootTask = NULLTAG;
    tag_t *attachments = NULLTAG;
    tag_t *TaskRevision = NULLTAG;
    tag_t *Dflt_grp_cntrl_tags = NULLTAG;
    tag_t dml_rev_tag = NULLTAG;
    tag_t objTypeTag = NULLTAG;
    tag_t relation_type = NULLTAG;
    tag_t qryTagCntrl = NULLTAG;

    char *Plantname = NULL;
    char *group = NULL;
    char *planner = NULL;
    char *Department = NULL;
    char *plannerplant = NULL;
    char *plannergroup = NULL;
    char *info1 = NULL;
    char *info2 = NULL;
    char *current_item_id = NULL;

    int DefaultGrpflag = 0;
    int AnaDefaultGrpflag = 0;
    int RevDefaultGrpflag = 0;
    int DmurevDefaultGrpflag = 0;

    int n_entrycoCntrl = 3;
    int grp_control_number_found = 0;


	char *qry_dlt_grp_entryCntrl[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
    char **qry_dlt_grp_valuesCntrl = (char **)MEM_alloc(5 * sizeof(char *));

    printf("\n **************inside mbom_dml_task_default_group***************\n ");
    fflush(stdout);
	tag_t tTask	= msg.task; 
    ITKCALL(EPM_ask_root_task(msg.task, &rootTask));
    printf("\n apl_dml_task_assigment \n");
    fflush(stdout);

    ITKCALL(AOM_ask_value_string(msg.task, "object_name", &CurrentTask));
    printf("\nCurrentTask:%s\n", CurrentTask);
    ITKCALL(AOM_ask_value_string(rootTask, "object_name", &parent_name));
    printf("\nParent Name:%s\n", parent_name);
    fflush(stdout);
    ITKCALL(EPM_ask_attachments(rootTask, EPM_target_attachment, &noAttachment, &attachments));
    printf("Target Attachment:%d\n", noAttachment);
    fflush(stdout);
    if (noAttachment > 0)
    {
        dml_rev_tag = attachments[0];
        if (TCTYPE_ask_object_type(dml_rev_tag, &objTypeTag))
            ;
        if (TCTYPE_ask_name2(objTypeTag, &type_name));
         
        printf("\n venkat deafault type_name changes done: for workspaceobject     %s\n", type_name);
        fflush(stdout);
    }
	//First condition
	ITKCALL(AOM_ask_value_string(dml_rev_tag, "item_id", &item_id));
	ITKCALL(AOM_ask_value_string(dml_rev_tag, "current_id", &DML_no));
	printf("\n\n\t\t current task item id  : %s", item_id);
	fflush(stdout);



    if (QRY_find2("Control Objects...", &qryTagCntrl));
        
    if (qryTagCntrl)
    {
        printf("\nDefault group Control Object Query Found \n");
        fflush(stdout);
        qry_dlt_grp_valuesCntrl[0] = "MbomPlannerandReviewer";
        qry_dlt_grp_valuesCntrl[1] = "DefaultGroup";

        qry_dlt_grp_valuesCntrl[2] = "0";

        if (QRY_execute(qryTagCntrl, n_entrycoCntrl, qry_dlt_grp_entryCntrl, qry_dlt_grp_valuesCntrl, &grp_control_number_found, &Dflt_grp_cntrl_tags))
            ;
    }
    printf("\nNo of control object found for default group:%d\n", grp_control_number_found);
    fflush(stdout);

    if (grp_control_number_found > 0)
    {
		ITKCALL(AOM_ask_value_string(Dflt_grp_cntrl_tags[0],"t5_Userinfo1",&info1));
		ITKCALL(AOM_ask_value_string(Dflt_grp_cntrl_tags[0],"t5_Userinfo2",&info2));
		printf("\n MBOM designeranddReviewer t5_Userinfo1 and t5_Userinfo2 : %s : %s",info2,info1);fflush(stdout);

		ITKCALL(AOM_ask_value_string(dml_rev_tag, "item_id", &current_item_id));
		printf("\n MBOM current_item_id info: %s ",current_item_id);fflush(stdout);

		//if (tc_strcmp(CurrentTask,"Is_default_grp_Chk")==0) Is_default_grp_Chk
		if (tc_strcmp(CurrentTask,info1)==0)
		{
			printf("\n **************inside mbom_dml_task_default_group and task is Is_default_grp_Chk***************\n ");
			if (tc_strcmp(type_name, "T5_MBOMTASKRevision") == 0)
			{
				printf("\n inside class T5_MBOMTASKRevision......\n");
				fflush(stdout);
				
				if (dml_rev_tag != NULLTAG)
				{
					
					/*AOM_UIF_ask_value(dml_rev_tag, "Analyst", &Aplplannergroup);
					printf("\n\n\t\t Apl Planner Assigned Gropu and display group : %s", Aplplannergroup);
					fflush(stdout);

					if (tc_strstr(Aplplannergroup, "Default") != NULL)
					{
						printf("\nplanner DefultGroup has been found");
						fflush(stdout);
						DefaultGrpflag++;
						//AnaDefaultGrpflag++;
					}

					/*ITKCALL(AOM_UIF_ask_value(dml_rev_tag, "ChangeSpecialist1", &Aplreviwergroup));

					printf("\n\n\t\t Apl Planner Assigned Group AND Visible Reviewew Group: %s", Aplreviwergroup);
					fflush(stdout);
					if (tc_strstr(Aplreviwergroup, "Default") != NULL)
					{
						printf("\n Reviewr DefultGroup has been found");
						fflush(stdout);
						DefaultGrpflag++;
					  // RevDefaultGrpflag++;
					}*/

					tag_t	relation_type	= NULLTAG;
					tag_t*	AnaPart_objects	= NULLTAG;
					int		anaPart_cnt	= 0;
					int		anaCngptcnt = 0;

					char*	tcParobject_name	= NULL;
					char*	ChangeDMUReviewr	= NULL;
					char*	AnaDgnReviewr	= NULL;
					char*	anlstDsngrReviewGrp	= NULL;
					tag_t	ObjTypDmlCRB	= NULLTAG;

					ITKCALL(GRM_find_relation_type("HasParticipant", &relation_type));
					ITKCALL(GRM_list_secondary_objects_only(dml_rev_tag, relation_type, &anaPart_cnt, &AnaPart_objects));
					printf("\n partcipant_cnt : [%d]\n",anaPart_cnt);fflush(stdout);
					if (anaPart_cnt > 0)
					{
						for (anaCngptcnt= 0; anaCngptcnt<anaPart_cnt;anaCngptcnt++ )
						{
							
							tcParobject_name	= NULL;
							AnaDgnReviewr		= NULL;
							anlstDsngrReviewGrp	= NULL;
							ObjTypDmlCRB		= NULLTAG;
							//DMUReviewergroupreviewerflag	= 0;

							ITKCALL(TCTYPE_ask_object_type(AnaPart_objects[anaCngptcnt],&ObjTypDmlCRB));
						
							
							ITKCALL( TCTYPE_ask_name2	(ObjTypDmlCRB,&tcParobject_name));
							
							printf("\n\n\t\t tcParobject_name :   %s\n",tcParobject_name);
							fflush(stdout);
							if (tc_strcmp(tcParobject_name,"Analyst")==0)
							{
							
								ITKCALL(AOM_UIF_ask_value(AnaPart_objects[anaCngptcnt],"fnd0AssigneeUser",&AnaDgnReviewr));
								ITKCALL(AOM_UIF_ask_value(AnaPart_objects[anaCngptcnt],"assignee",&Aplplannergroup));
								printf("\n TASK: Analyst: [%s] Group: [%s] ",AnaDgnReviewr,Aplplannergroup);fflush(stdout);
								if (tc_strstr(Aplplannergroup, "Default") != NULL)
								{
									printf("\nplanner DefultGroup has been found");
									fflush(stdout);
									DefaultGrpflag++;
									break;
									
								}
								
							}
							else
							{

								printf("\n inside else : ChangeSpecialist1:\n");fflush(stdout);
								if (tc_strcmp(tcParobject_name,"ChangeSpecialist1")==0)
								{
								
									ITKCALL(AOM_UIF_ask_value(AnaPart_objects[anaCngptcnt],"fnd0AssigneeUser",&ChangeDMUReviewr));
									ITKCALL(AOM_UIF_ask_value(AnaPart_objects[anaCngptcnt],"assignee",&Aplreviwergroup));
									printf("\n TASK: DMU Reviewer: [%s] Group: [%s] ",ChangeDMUReviewr,Aplreviwergroup);fflush(stdout);
									if (tc_strstr(Aplreviwergroup, "Default") != NULL)
									{
										printf("\n Reviewr DefultGroup has been found");
										fflush(stdout);
										DefaultGrpflag++;
										break;
									 
									}
								
									
								}
								else
								{
									printf("\n No  Analyst and Change Specialist1 \n");fflush(stdout);
									char*	DMUReviewr	= NULL;
									char*	DMUReviewGrp	= NULL;
									if (tc_strcmp(tcParobject_name,"T5_DMUReviewer")==0)
									{
									
										ITKCALL(AOM_UIF_ask_value(AnaPart_objects[anaCngptcnt],"fnd0AssigneeUser",&DMUReviewr));
										ITKCALL(AOM_UIF_ask_value(AnaPart_objects[anaCngptcnt],"assignee",&DMUReviewGrp));
										printf("\n TASK: DMU Reviewer: [%s] Group: [%s] ",DMUReviewr,DMUReviewGrp);fflush(stdout);
										
										fflush(stdout);
										if (tc_strstr(DMUReviewGrp, "Default") != NULL)
										{
											printf("\n DMUReviewr DefultGroup has been found");
											fflush(stdout);
											DefaultGrpflag++;
											//DmurevDefaultGrpflag++;
											break;
										}
									}
										
								}
							}
						}
					}


					//23MM901053_00CL_MBOM
					
					/*	char *DMLNO = tc_strtok(item_id, "_");
						char *Dsgn_No = tc_strtok(NULL, "_");
						char *DMLPlant = tc_strtok(NULL, "_");

						printf("\n\n\t\t inside mbom task :DMLNO : Designgrp:DMLPlant  : [%s][%s][%s] \n", DMLNO, Dsgn_No, DMLPlant);
						fflush(stdout);
						tag_t	DML_tag		= NULLTAG;
						tag_t	DMLrevtag = NULLTAG; 
						char*	ERC_MBOMReleaseType	= NULL;

						ITKCALL(ITEM_find_item (DMLNO, &DML_tag));
						
					
						if(DML_tag != NULLTAG )
						{
							printf("\ninside  ERC_MBOMReleaseType :\n");fflush(stdout);
							ITKCALL(ITEM_ask_latest_rev(DML_tag,&DMLrevtag));
							AOM_ask_value_string( DMLrevtag, "t5_rlstype", &ERC_MBOMReleaseType);

							printf("\n ERC_MBOMReleaseType : %s\n",ERC_MBOMReleaseType);fflush(stdout);
						}
						printf("\n outside ERC_MBOMReleaseType : :%s  : %s\n",ERC_MBOMReleaseType,current_item_id);fflush(stdout);
						if( (tc_strcmp(ERC_MBOMReleaseType, "Veh") == 0)||(tc_strstr(current_item_id, "MB_") != NULL)||(tc_strstr(current_item_id, "MM_") != NULL))
						{
							tag_t	relation_type	= NULLTAG;
							tag_t*	Part_objects	= NULLTAG;
							int		part_cnt	= 0;
							ITKCALL(GRM_find_relation_type("HasParticipant", &relation_type));
							ITKCALL(GRM_list_secondary_objects_only(dml_rev_tag, relation_type, &part_cnt, &Part_objects));
							printf("\n inside  ERC_MBOMReleaseType partcipant_cnt Veh  MB_ MM_: [%d]\n",part_cnt);fflush(stdout);
							if (part_cnt > 0)
							{
								int ptcnt = 0;
								for (ptcnt= 0; ptcnt<part_cnt;ptcnt++ )
								{
									
									char*	tcParobject_name	= NULL;
									char*	DMUReviewr	= NULL;
									char*	DMUReviewGrp	= NULL;
									tag_t	ObjTypDmlCRB	= NULLTAG;

									if(TCTYPE_ask_object_type(Part_objects[ptcnt],&ObjTypDmlCRB));
								
									
									ITKCALL( TCTYPE_ask_name2	(ObjTypDmlCRB,&tcParobject_name));
									
									printf("\n\n\t\t tcParobject_name_T5_DMUReviewer :   %s\n",tcParobject_name);
									fflush(stdout);
									if (tc_strcmp(tcParobject_name,"T5_DMUReviewer")==0)
									{
									
										ITKCALL(AOM_UIF_ask_value(Part_objects[ptcnt],"fnd0AssigneeUser",&DMUReviewr));
										ITKCALL(AOM_UIF_ask_value(Part_objects[ptcnt],"assignee",&DMUReviewGrp));
										printf("\n TASK: DMU Reviewer: [%s] Group: [%s] ",DMUReviewr,DMUReviewGrp);fflush(stdout);
										
										fflush(stdout);
										if (tc_strstr(DMUReviewGrp, "Default") != NULL)
										{
											printf("\n DMUReviewr DefultGroup has been found");
											fflush(stdout);
											DefaultGrpflag++;
											//DmurevDefaultGrpflag++;
											break;
										}
									}
								}
							}

						}*/

				}
			}

			//printf("\n\n\t\t Apl Planner and reviewer Assigned Group flag: %d :%d :%d", AnaDefaultGrpflag,RevDefaultGrpflag,DmurevDefaultGrpflag);
			printf("\n\n\t\t Apl Planner and reviewer Assigned Group flag: %d ", DefaultGrpflag);
			fflush(stdout);
		   
			if (DefaultGrpflag > 0)
			{
				 printf("\n Task  assigned Deginged Manager and reviewer are  Default group..... \n");
				 return 789;

			}
		}
		//if (tc_strcmp(CurrentTask,"DefaultMOBAnaRevDMRevAssign")==0)
		if (tc_strcmp(CurrentTask,info2)==0)
		{
			printf("\n **************inside mbom_dml_default_group and TASK is DefaultMBOMDesgnRevAssiginment***************\n ");
			char    *participant_name           =NULL;
			char    *mode                       =NULL;
			char	*cuser						=NULL;
			char *role							=NULL;
			char *group							=NULL;
			tag_t	usertag						= NULLTAG;

			
			tag_t	participant_relation_type	= NULLTAG;
			tag_t*	participant_objects	= NULLTAG;
			int		participant_cnt	= 0;
			int		ParCngptcnt = 0;

			char*	Parobject_name	= NULL;
			char*	ChangeDMUReviewr	= NULL;
			char*	AnaDgnReviewr	= NULL;
			char*	anlstDsngrReviewGrp	= NULL;
			tag_t	Par_ObjTypDmlCRB	= NULLTAG;

			ITKCALL(GRM_find_relation_type("HasParticipant", &participant_relation_type));
			ITKCALL(GRM_list_secondary_objects_only(dml_rev_tag, participant_relation_type, &participant_cnt, &participant_objects));
			printf("\n HasParticipant partcipant_cnt : [%d]\n",participant_cnt);fflush(stdout);
			if (participant_cnt > 0)
			{
				for (ParCngptcnt= 0; ParCngptcnt<participant_cnt;ParCngptcnt++ )
				{
					
					Parobject_name	= NULL;
					AnaDgnReviewr		= NULL;
					anlstDsngrReviewGrp	= NULL;
					Par_ObjTypDmlCRB		= NULLTAG;
					//DMUReviewergroupreviewerflag	= 0;

					ITKCALL(TCTYPE_ask_object_type(participant_objects[ParCngptcnt],&Par_ObjTypDmlCRB));
				
					
					ITKCALL( TCTYPE_ask_name2	(Par_ObjTypDmlCRB,&Parobject_name));
					
					printf("\n\n\t\t Analyst and ChangeSpecialist1 tcParobject_name :   %s\n",Parobject_name);
					fflush(stdout);
					if (tc_strcmp(Parobject_name,"Analyst")==0)
					{
					
						ITKCALL(AOM_UIF_ask_value(participant_objects[ParCngptcnt],"fnd0AssigneeUser",&AnaDgnReviewr));
						ITKCALL(AOM_UIF_ask_value(participant_objects[ParCngptcnt],"assignee",&participant_name));
						printf("\n TASK: Analyst: [%s] Group: [%s] ",AnaDgnReviewr,participant_name);fflush(stdout);
						if (tc_strstr(participant_name, "Default") != NULL)
						{
							printf("\nplanner DefultGroup has been found");
					   
							cuser	= NULL;
							group	= NULL;
							usertag	= NULLTAG;

							group=tc_strtok(participant_name,"(");
							printf("\n participant group 1:[%s], participant_name :[%s]\n",group,participant_name);fflush(stdout);
							cuser = tc_strtok(NULL,")");
							printf("\n participant.. group 2:[%s], USER : [%s]\n",group,cuser);fflush(stdout);
							ITKCALL(SA_find_user2(cuser,&usertag));
								
							ITKCALL( EPM_assign_responsible_party(tTask, usertag ));
										
							printf("\n resourcePool Asiigned as responsible party...\n");fflush(stdout);
							break;
						}
						
					}
					else
					{

						printf("\n inside else : ChangeSpecialist1\n");fflush(stdout);
						participant_name	= NULLTAG;
						if (tc_strcmp(Parobject_name,"ChangeSpecialist1")==0)
						{
						
							ITKCALL(AOM_UIF_ask_value(participant_objects[ParCngptcnt],"fnd0AssigneeUser",&ChangeDMUReviewr));
							ITKCALL(AOM_UIF_ask_value(participant_objects[ParCngptcnt],"assignee",&participant_name));
							printf("\n TASK: DMU Reviewer: [%s] Group: [%s] ",ChangeDMUReviewr,participant_name);fflush(stdout);
							if (tc_strstr(participant_name, "Default") != NULL)
							{
								group=tc_strtok(participant_name,"(");
								printf("\n participant group 1:[%s], participant_name :[%s]\n",group,participant_name);fflush(stdout);
								cuser = tc_strtok(NULL,")");
								printf("\n participant.. group 2:[%s], USER : [%s]\n",group,cuser);fflush(stdout);
								ITKCALL(SA_find_user2(cuser,&usertag));

								ITKCALL( EPM_assign_responsible_party(tTask, usertag ));
											
								printf("\n resourcePool Asiigned as responsible party.....\n");fflush(stdout);
								break;
							}
						
							
						}
						else if (tc_strcmp(Parobject_name,"T5_DMUReviewer")==0)
						{
							//if (tc_strcmp(tcParobject_name,"T5_DMUReviewer")==0)
							//{
								char*	DMUReviewGrp	= NULL;
								char*	DMUReviewr	= NULL;

								ITKCALL(AOM_UIF_ask_value(participant_objects[ParCngptcnt],"fnd0AssigneeUser",&DMUReviewr));
								ITKCALL(AOM_UIF_ask_value(participant_objects[ParCngptcnt],"assignee",&DMUReviewGrp));
								printf("\n TASK: DMU Reviewer: [%s] Group: [%s] ",DMUReviewr,DMUReviewGrp);fflush(stdout);
								
								fflush(stdout);
								if (tc_strstr(DMUReviewGrp, "Default") != NULL)
								{
									group=tc_strtok(DMUReviewGrp,"(");
									printf("\n participant group 1:[%s], participant_name :[%s]\n",group,DMUReviewGrp);fflush(stdout);
									cuser = tc_strtok(NULL,")");
									printf("\n participant.. group 2:[%s], USER : [%s]\n",group,cuser);fflush(stdout);
									ITKCALL(SA_find_user2(cuser,&usertag));

									ITKCALL( EPM_assign_responsible_party(tTask, usertag ));
												
									printf("\n resourcePool Asiigned as responsible party.....\n");fflush(stdout);
									break;
								}
							//}
						}
						else
						{
							char *DMLNO = tc_strtok(item_id, "_");
							char *Dsgn_No = tc_strtok(NULL, "_");
							char *DMLPlant = tc_strtok(NULL, "_");

							printf("\n\n\t\t inside mbom task :DMLNO : Designgrp:DMLPlant  : [%s][%s][%s] \n", DMLNO, Dsgn_No, DMLPlant);
							fflush(stdout);
							tag_t	DML_tag		= NULLTAG;
							tag_t	DMLrevtag = NULLTAG; 
							char*	ERC_MBOMReleaseType	= NULL;

							ITKCALL(ITEM_find_item (DMLNO, &DML_tag));
							
						
							if(DML_tag != NULLTAG )
							{
								printf("\ninside  ERC_MBOMReleaseType :\n");fflush(stdout);
								ITKCALL(ITEM_ask_latest_rev(DML_tag,&DMLrevtag));
								AOM_ask_value_string( DMLrevtag, "t5_rlstype", &ERC_MBOMReleaseType);

								printf("\n ERC_MBOMReleaseType : %s\n",ERC_MBOMReleaseType);fflush(stdout);
							}
							else
							{
								printf("\n DML is not ERCDML and task id :%s  : %s\n",ERC_MBOMReleaseType,current_item_id);fflush(stdout);
							}
							printf("\nbefore condition DML is not ERCDML and task id :%s  : %s\n",ERC_MBOMReleaseType,current_item_id);fflush(stdout);

							/*if( (tc_strcmp(ERC_MBOMReleaseType, "Veh") == 0)||(tc_strstr(current_item_id, "MB_") != NULL)||(tc_strstr(current_item_id, "MM_") != NULL))
							{
								tag_t	relation_type	= NULLTAG;
								tag_t*	Part_objects	= NULLTAG;
								int		part_cnt	= 0;
								ITKCALL(GRM_find_relation_type("HasParticipant", &relation_type));
								ITKCALL(GRM_list_secondary_objects_only(dml_rev_tag, relation_type, &part_cnt, &Part_objects));
								printf("\n partcipant_cnt : [%d]\n",part_cnt);fflush(stdout);
								if (part_cnt > 0)
								{
									int ptcnt = 0;
									for (ptcnt= 0; ptcnt<part_cnt;ptcnt++ )
									{
										
										char*	tcParobject_name	= NULL;
										char*	DMUReviewr	= NULL;
										char*	DMUReviewGrp	= NULL;
										tag_t	ObjTypDmlCRB	= NULLTAG;

										if(TCTYPE_ask_object_type(Part_objects[ptcnt],&ObjTypDmlCRB));
									
										
										ITKCALL( TCTYPE_ask_name2	(ObjTypDmlCRB,&tcParobject_name));
										
										printf("\n\n\t\t tcParobject_name1111122 :   %s\n",tcParobject_name);
										fflush(stdout);
										if (tc_strcmp(tcParobject_name,"T5_DMUReviewer")==0)
										{
										
											ITKCALL(AOM_UIF_ask_value(Part_objects[ptcnt],"fnd0AssigneeUser",&DMUReviewr));
											ITKCALL(AOM_UIF_ask_value(Part_objects[ptcnt],"assignee",&DMUReviewGrp));
											printf("\n TASK: DMU Reviewer: [%s] Group: [%s] ",DMUReviewr,DMUReviewGrp);fflush(stdout);
											
											fflush(stdout);
											if (tc_strstr(DMUReviewGrp, "Default") != NULL)
											{
												group=tc_strtok(DMUReviewGrp,"(");
												printf("\n participant group 1:[%s], participant_name :[%s]\n",group,DMUReviewGrp);fflush(stdout);
												cuser = tc_strtok(NULL,")");
												printf("\n participant.. group 2:[%s], USER : [%s]\n",group,cuser);fflush(stdout);
												ITKCALL(SA_find_user2(cuser,&usertag));

												ITKCALL( EPM_assign_responsible_party(tTask, usertag ));
															
												printf("\n resourcePool Asiigned as responsible party.....\n");fflush(stdout);
												break;
											}
										}
									}
								}

							}*/
						}
					}
				}
			}

			/*ITKCALL(AOM_UIF_ask_value(dml_rev_tag,"Analyst",&participant_name));
			printf("\n VENKAT ANALYST %s \n",participant_name);
			if (tc_strstr(participant_name, "Default") != NULL)
			{
				printf("\nplanner DefultGroup has been found");
						   
				cuser	= NULL;
				group	= NULL;
				usertag	= NULLTAG;

				group=tc_strtok(participant_name,"(");
				printf("\n participant group 1:[%s], participant_name :[%s]\n",group,participant_name);fflush(stdout);
				cuser = tc_strtok(NULL,")");
				printf("\n participant.. group 2:[%s], USER : [%s]\n",group,cuser);fflush(stdout);
				ITKCALL(SA_find_user2(cuser,&usertag));
					
				ITKCALL( EPM_assign_responsible_party(tTask, usertag ));
							
				printf("\n resourcePool Asiigned as responsible party...\n");fflush(stdout);
			}
			else 
			{
				participant_name	= NULL;

				ITKCALL(AOM_UIF_ask_value(dml_rev_tag,"ChangeSpecialist1",&participant_name));
				printf("\nReviewer DefultGroup has been found : %s",participant_name);

				if (tc_strstr(participant_name, "Default") != NULL)
				{
					group=tc_strtok(participant_name,"(");
					printf("\n participant group 1:[%s], participant_name :[%s]\n",group,participant_name);fflush(stdout);
					cuser = tc_strtok(NULL,")");
					printf("\n participant.. group 2:[%s], USER : [%s]\n",group,cuser);fflush(stdout);
					ITKCALL(SA_find_user2(cuser,&usertag));

					ITKCALL( EPM_assign_responsible_party(tTask, usertag ));
								
					printf("\n resourcePool Asiigned as responsible party.....\n");fflush(stdout);
				}
				else
				{
					char *DMLNO = tc_strtok(item_id, "_");
					char *Dsgn_No = tc_strtok(NULL, "_");
					char *DMLPlant = tc_strtok(NULL, "_");

					printf("\n\n\t\t inside mbom task :DMLNO : Designgrp:DMLPlant  : [%s][%s][%s] \n", DMLNO, Dsgn_No, DMLPlant);
					fflush(stdout);
					tag_t	DML_tag		= NULLTAG;
					tag_t	DMLrevtag = NULLTAG; 
					char*	ERC_MBOMReleaseType	= NULL;

					ITKCALL(ITEM_find_item (DMLNO, &DML_tag));
					
				
					if(DML_tag != NULLTAG )
					{
						printf("\ninside  ERC_MBOMReleaseType :\n");fflush(stdout);
						ITKCALL(ITEM_ask_latest_rev(DML_tag,&DMLrevtag));
						AOM_ask_value_string( DMLrevtag, "t5_rlstype", &ERC_MBOMReleaseType);

						printf("\n ERC_MBOMReleaseType : %s\n",ERC_MBOMReleaseType);fflush(stdout);
					}
					else
					{
						printf("\n DML is not ERCDML and task id :%s  : %s\n",ERC_MBOMReleaseType,current_item_id);fflush(stdout);
					}
					printf("\nbefore condition DML is not ERCDML and task id :%s  : %s\n",ERC_MBOMReleaseType,current_item_id);fflush(stdout);

					if( (tc_strcmp(ERC_MBOMReleaseType, "Veh") == 0)||(tc_strstr(current_item_id, "MB_") != NULL)||(tc_strstr(current_item_id, "MM_") != NULL))
					{
						tag_t	relation_type	= NULLTAG;
						tag_t*	Part_objects	= NULLTAG;
						int		part_cnt	= 0;
						ITKCALL(GRM_find_relation_type("HasParticipant", &relation_type));
						ITKCALL(GRM_list_secondary_objects_only(dml_rev_tag, relation_type, &part_cnt, &Part_objects));
						printf("\n partcipant_cnt : [%d]\n",part_cnt);fflush(stdout);
						if (part_cnt > 0)
						{
							int ptcnt = 0;
							for (ptcnt= 0; ptcnt<part_cnt;ptcnt++ )
							{
								
								char*	tcParobject_name	= NULL;
								char*	DMUReviewr	= NULL;
								char*	DMUReviewGrp	= NULL;
								tag_t	ObjTypDmlCRB	= NULLTAG;

								if(TCTYPE_ask_object_type(Part_objects[ptcnt],&ObjTypDmlCRB));
							
								
								ITKCALL( TCTYPE_ask_name2	(ObjTypDmlCRB,&tcParobject_name));
								
								printf("\n\n\t\t tcParobject_name1111122 :   %s\n",tcParobject_name);
								fflush(stdout);
								if (tc_strcmp(tcParobject_name,"T5_DMUReviewer")==0)
								{
								
									ITKCALL(AOM_UIF_ask_value(Part_objects[ptcnt],"fnd0AssigneeUser",&DMUReviewr));
									ITKCALL(AOM_UIF_ask_value(Part_objects[ptcnt],"assignee",&DMUReviewGrp));
									printf("\n TASK: DMU Reviewer: [%s] Group: [%s] ",DMUReviewr,DMUReviewGrp);fflush(stdout);
									
									fflush(stdout);
									if (tc_strstr(DMUReviewGrp, "Default") != NULL)
									{
										group=tc_strtok(DMUReviewGrp,"(");
										printf("\n participant group 1:[%s], participant_name :[%s]\n",group,DMUReviewGrp);fflush(stdout);
										cuser = tc_strtok(NULL,")");
										printf("\n participant.. group 2:[%s], USER : [%s]\n",group,cuser);fflush(stdout);
										ITKCALL(SA_find_user2(cuser,&usertag));

										ITKCALL( EPM_assign_responsible_party(tTask, usertag ));
													
										printf("\n resourcePool Asiigned as responsible party.....\n");fflush(stdout);
										break;
									}
								}
							}
						}

					}
				}
			}*/
		}
	}
   return error_code;
}



//venkat end


int createMBOM_Task( METHOD_message_t *msg, va_list  args )
{
	EPM_decision_t decision;

	tag_t TaskTag = NULLTAG;

	va_list largs;    
	va_copy( largs, args ); 
    //tag_t TaskTag = va_arg(largs, const tag_t);
	tag_t		TaskTagrev			= va_arg(args, tag_t);
	logical  	isNew = va_arg(args, int);
	va_end( largs );
	ITEM_ask_item_of_rev(TaskTagrev,&TaskTag);



    // tag_t	TaskTag		= va_arg(args, const tag_t);
    // tag_t	TaskTagNew		= NULLTAG;
    // tag_t			TaskTagrev		= NULLTAG;
    // int*	n_values	= va_arg(args, int*);
    // char	***values	= va_arg(args, char***);
	char	*item_sequence_id;
	char	*DmlAnalyst_name=NULL;
	char	*DmlChangeSpecialist=NULL;
	int		status;
	int max_char_size = 100;
	char*			DMLMBOM					=NULL;
	char*			Suffix					=NULL;
	tag_t *DmlRev=NULLTAG;

	int n_tags_found = 0;


	int
	error_code	= ITK_ok,
	n_entries	= 1,
	n_found		= 0,
	num=0,
	i=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *Dml_Name 	   = NULL;
	char *Proj_ID 	   = NULL;
	tag_t *tags_found = NULL;
	char cCurrentAccessDate[20]={0};
	char *Year=NULL;
	char *DMLSerial=NULL;
	tag_t	queryTag	= NULLTAG;
	tag_t	Dml_tag	= NULLTAG;
	int resultCount=0;
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char *qry_entries[1] = {"ID"};
	//char *keys[1] = {"Date Created"};
	char *keys[1] = {"creation_date"};
    int  	 orders[1]  ={1};
	int  num_to_sort = 1;
	int  number_found;
	int  DMLFlag=0;
	int  DMLSerialInt;
	int  mbom_number_found;
	tag_t *list_of_WSO_tags=NULLTAG;
    tag_t  NewTaskAttrId = NULLTAG;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char	DmlLastSerial[20];
	char **DesignGroupList;
	tag_t  CurrentRoleTag = NULLTAG;
	//char       roleName[SA_name_size_c+1]  ;
    char   *roleName=NULL;
    char   *PlantName=NULL;
	char *EcnType=NULL;
	char *ecntypeVal=NULL;
	char*	type_name=NULL;
	//char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	WSO_search_criteria_t  	MBOMTaskCriteria;
    WSO_search_criteria_t  	MBOMDMLCriteria;
    char *item_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_id_dml = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_id_dml_Str = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *Dml_Number=NULL;


    printf("\n ************** Aniket inside createMBOM_Task***************\n ");fflush(stdout);

	if(TCTYPE_ask_object_type(TaskTag,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
    printf("\n DMLFlag [%d]",DMLFlag);fflush(stdout);

	printf("\n isNew is => %d \n",isNew);fflush(stdout);

	//if(strcmp(type_name,"T5_MBOMDML")==0)
	if(tc_strcmp(type_name,"T5_MBOMDML") == 0 && isNew == 1)
	{
			ITKCALL(SA_ask_current_role(&CurrentRoleTag));
			ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
			printf("\n\n  roleName : %s\n",roleName); fflush(stdout);
			PlantName=subString_mbom(roleName,3,4);
			printf( "PlantName:%s\n", PlantName);
			if(strcmp(PlantName,"")==0)
			{
				printf("\n Role is not correct  %s \n",PlantName);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Please Select the Correct Role for MBOM DML Creation");
				decision = EPM_nogo;
				return ITK_errStore;
			}
			
			//if(ITEM_ask_latest_rev(TaskTag,&TaskTagrev));
		    printf("\n inside class T5_MBOMDML......\n");fflush(stdout);
			AOM_ask_value_string( TaskTagrev, "item_id", &item_id);
			AOM_ask_value_string( TaskTagrev, "current_id", &DML_no);
			AOM_ask_value_strings(TaskTagrev,"t5_crdesigngroup",&num,&DesignGroupList);
            AOM_ask_value_string( TaskTagrev, "t5_cprojectcode", &Proj_ID);
			

			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n DML_no : %s\n",DML_no);fflush(stdout);
			printf("\n num is : %d\n",num);fflush(stdout);
			printf("\n Proj_ID is : %s\n",Proj_ID);fflush(stdout);

			if(QRY_find2("MBOMDMLQuery", &queryTag));
			
			if (queryTag)
			{
				getCurrentDateTime(cCurrentAccessDate);
				printf("\n cCurrentAccessDate:%s",cCurrentAccessDate);
				Year=subString_mbom(cCurrentAccessDate,9,2);

					strcpy(item_id_dml,Year);
					strcat (item_id_dml,"MM90");
					strcat (item_id_dml,"*");
					printf("\n item_id_dml:%s",item_id_dml);
					strcpy(item_id_dml_Str,Year);
					strcat (item_id_dml_Str,"MM90");
			}

				
					qry_values[0] = item_id_dml ;

					if(QRY_execute_with_sort(queryTag, n_entries, qry_entries, qry_values, num_to_sort, keys, orders, &resultCount, &DmlRev));
					if (resultCount>0)
					{
						Dml_tag = DmlRev[resultCount-1];
						AOM_ask_value_string( Dml_tag, "item_id", &Dml_Name);
						printf("\n Dml_Name : %s\n",Dml_Name);fflush(stdout);
						DMLSerial=subString_mbom(Dml_Name,6,4);
						printf("\n DMLSerial : %s\n",DMLSerial);fflush(stdout);
						DMLSerialInt =atoi(DMLSerial);
						DMLSerialInt = DMLSerialInt + 1 ;
						printf("\n DMLSerialInt :%d\n",DMLSerialInt);fflush(stdout);
						sprintf(DmlLastSerial,"%d",DMLSerialInt);
						printf("\n DmlLastSerial : %s\n",DmlLastSerial);fflush(stdout);
						strcat (item_id_dml_Str,DmlLastSerial);
						strcat (item_id_dml_Str,"_");
						strcat (item_id_dml_Str,PlantName);
						printf("\n item_id_dml_Str:%s",item_id_dml_Str);
					}
					else
					{
						strcat (item_id_dml_Str,"1001");
						strcat (item_id_dml_Str,"_");
						strcat (item_id_dml_Str,PlantName);
					}

					WSOM_clear_search_criteria(&MBOMDMLCriteria);              
					strcpy(MBOMDMLCriteria.name,item_id_dml_Str);
					strcpy(MBOMDMLCriteria.class_name,"T5_MBOMDMLRevision");
					status	= WSOM_search(MBOMDMLCriteria, &mbom_number_found, &list_of_WSO_tags);
					printf("\n mbom_number_found:%d",mbom_number_found);
					
					
					if(mbom_number_found == 0 )          
					{
					   printf("\n Item ID changed --> item_id_dml_Str:%s",item_id_dml_Str);
						
                        char	*DMLNumber	=	NULL;
						DMLNumber	=	(char *)MEM_alloc (50 * sizeof(char));


							if(POM_attr_id_of_attr("item_id","T5_MBOMDML",&NewTaskAttrId));
							if(AOM_refresh(TaskTag,TRUE));
							if(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
							if(POM_set_attr_string(1,&TaskTag,NewTaskAttrId,item_id_dml_Str));
							if(AOM_save_without_extensions(TaskTag));
							if(AOM_refresh(TaskTag,TRUE));	

							ITKCALL(tm_updateObjMasterFormNameMBOM(TaskTag, item_id_dml_Str));//Update MASTER
							ITKCALL(tm_updateObjRevMasterFormNameMBOM(TaskTagrev, item_id_dml_Str));//Update MASTER
					
						
					}


					AOM_ask_value_string( TaskTag, "current_id", &DML_no);
					printf("\n111DML_no is : %s\n",DML_no);fflush(stdout);  
					
			}		
			
		
			DMLMBOM = strtok (DML_no,"_");
			Suffix = strtok (NULL,"_");


			for(i=0;i<num;i++)
			{
				printf("\n DMLMBOM is : %s\n",DMLMBOM);fflush(stdout);
    			printf("\n Suffix is : %s\n",Suffix);fflush(stdout);

				strcpy(item_id_dup,DMLMBOM);
				strcat (item_id_dup,"_");
				strcat (item_id_dup,DesignGroupList[i]);
				strcat (item_id_dup,"MM_");
				strcat(item_id_dup,Suffix);

    			printf("\n item_id_dup AFTER CAT is :%s\n",item_id_dup);fflush(stdout);

				WSOM_clear_search_criteria(&MBOMTaskCriteria);
				strcpy(MBOMTaskCriteria.name,item_id_dup);
				strcpy(MBOMTaskCriteria.class_name,"T5_MBOMTASKRevision");
				status	= WSOM_search(MBOMTaskCriteria, &number_found, &list_of_WSO_tags);

				printf("\n\n\t\t Item_id count in DB is : %d\n",number_found);fflush(stdout);

				if(number_found == 0)
				 {
					printf("\n item_id :%s and DML_no :%s\n ",item_id,DML_no);fflush(stdout);
					printf("\n Item created first time only with item_id \n");fflush(stdout);      
					
					int				n_strings			=	1;
					int				l_strings			=	500;
					int				index				=	0;
					char**			stringArrayMBOMT		=	NULL;
					char*			tempStringt			= NULL;

					tag_t			MBOMTypeTag			= NULLTAG;
					tag_t			MBOMCreInTag		= NULLTAG;
					tag_t			MBOMRevTypeTag		= NULLTAG;
					tag_t			MBOMRevCreInTag		= NULLTAG;
					tag_t			MBOMTaskTag			= NULLTAG;
					tag_t 			MBOMTaskRevTag	    = NULLTAG;
					
					stringArrayMBOMT = (char**)malloc( n_strings * sizeof *stringArrayMBOMT );
					for( index=0; index<n_strings; index++ )
					{
						stringArrayMBOMT[index] = (char*)malloc( l_strings + 1 );
					}
					
					ITKCALL( TCTYPE_find_type( "T5_MBOMTASK", NULL, &MBOMTypeTag) );
					ITKCALL( TCTYPE_construct_create_input( MBOMTypeTag, &MBOMCreInTag) );

					ITKCALL( TCTYPE_find_type( "T5_MBOMTASKRevision", NULL, &MBOMRevTypeTag) );
					ITKCALL( TCTYPE_construct_create_input( MBOMRevTypeTag, &MBOMRevCreInTag) );

					tc_strcpy( stringArrayMBOMT[0], item_id_dup);
					ITKCALL( TCTYPE_set_create_display_value( MBOMCreInTag, "item_id", 1,(const char**)stringArrayMBOMT) );

					tc_strcpy( stringArrayMBOMT[0], item_id_dup);

					ITKCALL( TCTYPE_set_create_display_value( MBOMCreInTag, "object_name", 1,(const char**)stringArrayMBOMT) );

					tc_strcpy( stringArrayMBOMT[0], item_id_dup);
					ITKCALL( TCTYPE_set_create_display_value( MBOMCreInTag, "object_desc", 1,(const char**)stringArrayMBOMT) );

					ITKCALL( AOM_tag_to_string(MBOMRevCreInTag, &tempStringt) );
					tc_strcpy( stringArrayMBOMT[0], tempStringt);
					printf("\nTest0.4..[%s]\n",stringArrayMBOMT[0]);fflush(stdout);
					ITKCALL( TCTYPE_set_create_display_value( MBOMCreInTag, "revision", 1,(const char**) stringArrayMBOMT) );
					tc_strcpy( stringArrayMBOMT[0], "A");
					ITKCALL( TCTYPE_set_create_display_value( MBOMRevCreInTag, "item_revision_id", 1,(const char**)stringArrayMBOMT) );
					tc_strcpy( stringArrayMBOMT[0], DesignGroupList[i]);
					ITKCALL( TCTYPE_set_create_display_value( MBOMRevCreInTag, "t5_crdesigngroup", 1,(const char**)stringArrayMBOMT) );
					tc_strcpy( stringArrayMBOMT[0], Proj_ID);
					ITKCALL( TCTYPE_set_create_display_value( MBOMRevCreInTag, "t5_cprojectcode", 1,(const char**)stringArrayMBOMT) );

					printf("\n Value to set in mbom_task_number %s:%s:%s:%s:%s:\n",item_id_dup,item_id,tempStringt,DesignGroupList[i],Proj_ID);fflush(stdout);

					ITKCALL( TCTYPE_create_object( MBOMCreInTag, &MBOMTaskTag) );
					ITKCALL( AOM_save_without_extensions(MBOMTaskTag) );

					ITKCALL(ITEM_ask_latest_rev(MBOMTaskTag,&MBOMTaskRevTag)); 
					//
					printf("\nSave MBOM TASK ITEM AND REV\n");fflush(stdout);
					if (MBOMTaskTag!=NULLTAG) 
					{
						printf("\n MBOM TASK IS CREATED\n");fflush(stdout);
					}
					else
					{
						printf("\n MBOM TASK IS NOT CREATED\n");fflush(stdout);
					}
					if (MBOMTaskRevTag!=NULLTAG) 
					{
						printf("\n MBOM TASK REV IS CREATED\n");fflush(stdout);
					}
					else
					{
						printf("\n MBOM TASK REV IS NOT CREATED\n");fflush(stdout);
					}
					AOM_save_without_extensions(MBOMTaskTag); 
					AOM_save_without_extensions(MBOMTaskRevTag); 

					GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
					GRM_create_relation(TaskTagrev, MBOMTaskRevTag, relation_type,  NULLTAG, &relation);
					GRM_save_relation(relation);
					
					if (relation!=NULLTAG)
					{
						tag_t template_tag = NULLTAG;
	                    tag_t test_job_a = NULLTAG;
	                    int attachment_types = 1;

                        ITKCALL(EPM_find_template2("MBOM ECN Workflow",0,&template_tag));
						if (template_tag!=NULLTAG)
						{
						  ITKCALL(AOM_ask_value_string( TaskTag, "object_string", &Dml_Number));
						  printf("\n Dml_Number is : %s",Dml_Number);fflush(stdout);

						  ITKCALL(EPM_create_process(Dml_Number,"",template_tag,1, &TaskTagrev,&attachment_types,&test_job_a));
						  printf("\n Submit MBOM DML in to workflow process complete\n");fflush(stdout);
						}

					}
					
					if(AssignMBOMPlanner(MBOMTaskRevTag,Proj_ID));   
					if(AssignMBOMReviewer(MBOMTaskRevTag,Proj_ID));
					 

				 }
				 else
				 {
					printf("\n item_id created twice......  \n");fflush(stdout);
				 }

				 MEM_free(list_of_WSO_tags);
			 }
	//}

    return error_code;

}



//sanket

/**********************************Priyanka***********************************************/

int tm_check_SOR_MBOMDML_Val_control_object ( char *syscd, char *subsyscd )
{
	int n_found = 0 ;
	int n_entries = 2 ;
	char *qry_entries[2] = { "SYSCD", "SUBSYSCD" } ;
	char *qry_values[2] =  { syscd, subsyscd } ;
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;

	ITKCALL ( QRY_find2 ( "ControlObjQry", &query ) ) ;
	ITKCALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
	printf ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;
	

	printf ("\n--------------tm_check_SOR_MBOMDML_Val_control_object=Completed--------------------\n");fflush(stdout);
	return n_found ;
}

int SOR_task_signoff_val_MBOM ( tag_t DMLLcmTag )
{
	int part_cnt       = 0;
	int prt_c		   = 0;
	int part_SOR_cnt   = 0;
	int flag		   = 0;
	int prt_SOR_c	   = 0;
	logical	isCheckOut = 0;

	char *Tsk_object_type = NULL;
	char *part_SOR_num	  = NULL;
	char *SOR_numbers	  = NULL;

	tag_t Part_Tag			  = NULLTAG;
	tag_t Part_SOR_Tag		  = NULLTAG;
	tag_t part_tsk_rel		  = NULLTAG;
	tag_t part_SOR_Rel		  = NULLTAG;
	tag_t *Part_objects		  = NULLTAG;
	tag_t *part_SOR_objects   = NULLTAG;

	printf ("\nInside the function SOR_task_signoff_val_MBOM\n");
	

	ITKCALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_rel));
	printf ("\nExpanding Task to Parts relation\n");
	
	ITKCALL(GRM_list_secondary_objects_only(DMLLcmTag, part_tsk_rel, &part_cnt, &Part_objects));
	printf("\n part_cnt : [%d]\n",part_cnt);fflush(stdout);
	

	if ( part_cnt > 0 )
	{
		for ( prt_c = 0; prt_c < part_cnt ; prt_c++ )
		{
			Part_Tag = Part_objects[prt_c];
			ITKCALL(GRM_find_relation_type("T5_PartSorRel",&part_SOR_Rel));
			printf ("\nExpanding Part to SOR relation\n");
			
			ITKCALL(GRM_list_secondary_objects_only(Part_Tag, part_SOR_Rel, &part_SOR_cnt, &part_SOR_objects));
			printf("\n part_SOR_cnt : [%d]\n",part_SOR_cnt);fflush(stdout);
			

			if ( part_SOR_cnt > 0 )
			{
				for ( prt_SOR_c = 0; prt_SOR_c < part_SOR_cnt ; prt_SOR_c++ )
				{
					Part_SOR_Tag =  part_SOR_objects[prt_SOR_c];
					ITKCALL(AOM_UIF_ask_value(Part_SOR_Tag,"item_id",&part_SOR_num));
					printf("\npart_SOR_num : [%s]",part_SOR_num);fflush(stdout);
					
					ITKCALL(RES_is_checked_out(Part_SOR_Tag,&isCheckOut));

					if ( isCheckOut == 1 )
					{
						if(tc_strcmp(SOR_numbers,"")!=0)
						{
							tc_strcat ( SOR_numbers , part_SOR_num );
							tc_strcat ( SOR_numbers , ";" );
						}
						else
						{
							SOR_numbers = (char *) MEM_alloc(3000 * sizeof(char ));
							tc_strcpy ( SOR_numbers , part_SOR_num );
							
						}

						printf("\n[%s] is Checked out....",part_SOR_num);fflush(stdout);
						flag++;
					}
				}
			}
		}
	}
	if ( flag > 0 )
	{
		printf("\nPlease Check-In all SORs before signoff. [%s]",SOR_numbers);fflush(stdout);
		
		EMH_clear_errors();
		EMH_store_error_s2(EMH_severity_error,ITK_err,"\nPlease Check-In all SORs before signoff.\n",SOR_numbers);
		return 1;

	}
	else
	{
		printf ("\n--------------SOR_task_signoff_val_MBOM=Completed--------------------\n");fflush(stdout);
		return 0;
	}
}

/*************************************Priyanka*********************************/

// Added By Ketan
void mbomstrcat(char **src,char* dest)
{
    //printf("\n Inside Function gentplstrcat\n");fflush(stdout);

    // char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
     char * desc = dest ? dest : "NA";

    //printf("\n autoresizestrcat src len==%d",strlen(*src));
    //printf("\n autoresizestrcat desc len==%d",strlen(desc));
    const size_t a = strlen(*src);
    const size_t b = strlen(desc);
    const size_t size_ab = a + b + 2;
 
     //src = MEM_realloc(src, size_ab);

    *src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));


    tc_strcat(*src , desc);
 

}

int Part_task_checked_out_Validation( tag_t DMLLcmTag ) 
{
	int part_cnt       = 0;
	int prt_c		   = 0;
	int flag		   = 0;
	logical	isCheckOut = 0;

	char*	part_num		= NULL;
	char*	Part_numbers	= NULL;

	tag_t Part_Tag			  = NULLTAG;
	tag_t part_tsk_rel		  = NULLTAG;
	tag_t *Part_objects		  = NULLTAG;

	Part_numbers = (char *) MEM_alloc(3 * sizeof(char ));
	tc_strcpy(Part_numbers ,"");
	
	printf ("\n Ketan Inside the function Part_task_checked_out_Validation \n");
	
	ITKCALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_rel));
	printf ("\n Expanding Task to Parts relation\n");fflush(stdout);
	
	ITKCALL(GRM_list_secondary_objects_only(DMLLcmTag, part_tsk_rel, &part_cnt, &Part_objects));
	printf("\n part_cnt : [%d]\n",part_cnt);fflush(stdout);
	
	if ( part_cnt > 0 )
	{
		for ( prt_c = 0; prt_c < part_cnt ; prt_c++ )
		{
			Part_Tag = Part_objects[prt_c];
			
			ITKCALL(AOM_UIF_ask_value(Part_Tag,"item_id",&part_num));
			printf("\n part_num : [%s]",part_num);fflush(stdout);
			
			ITKCALL(RES_is_checked_out(Part_Tag,&isCheckOut));

			printf ("\n isCheckOut => %d \n",isCheckOut);fflush(stdout);

			if ( isCheckOut == 1 )
			{
				printf ("\n Test 1 \n");fflush(stdout);
				if(tc_strcmp(Part_numbers,"")!=0)
				{
					printf ("\n Test 2 \n");fflush(stdout);
					mbomstrcat(&Part_numbers,part_num);
					mbomstrcat(&Part_numbers,",");
				}
				else
				{
					printf ("\n Test 3 \n");fflush(stdout);
					mbomstrcat(&Part_numbers,part_num);
					mbomstrcat(&Part_numbers,",");
					
				}

				printf("\n [%s] is Checked out....",part_num);fflush(stdout);
				flag++;
			}
		}
	}
	if ( flag > 0 )
	{
		printf("\n Please Check-In all Part's before signoff. [%s]",Part_numbers);fflush(stdout);
		
		EMH_clear_errors();
		EMH_store_error_s2(EMH_severity_error,ITK_err,"\n Please Check-In all Part's before signoff.\n",Part_numbers);
		MEM_free(Part_numbers);
		return 1;

	}
	else
	{
		printf ("\n-------------- Part_task_checked_out_Validation = Completed--------------------\n");fflush(stdout);
		return 0;
	}
}
// Ended


int mbom_dml_release( EPM_action_message_t msg )
{
	
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;
	char*			DML_Num				= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	objErcTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t			TaskSVRRevisionTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			TaskSVRRevision		= NULLTAG;
	tag_t*			ERCDMLRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";


	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			DerivedsvrRelationTAG= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			ERCDMLTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t Release_date;


	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				countSVR				= 0;
	int				count_erc			= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
    int 	n_instances =1;
	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;
     tag_t 	  *ReleaseDateTgs = NULLTAG;
     tag_t 	  ReleaseDateTg = NULLTAG;
	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
     logical * 	date_is_valid  = false;
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char **DesignGroupList;
	char*	type_name = NULL;
	//char   type_name[TCTYPE_name_size_c+1];
	char   type_name_erc[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;
	char AplRlzdLc[40] ;
	char AplRvwLC[40];//TZ3.46
	char AplWrkngLC[40];	
	char Stdwrknglc[40];
	char Stdrlzdlc[40];
	char PltLcs[40];
	char StdPlant[40];
	char StdRevRule[40];
	char StdCLosRule[40];
	char StdView[40];
	char	*parttype=NULL;

	/********************AutoSor Priyanka*******************/

	tag_t status_Part_SOR_Tag	   = NULLTAG;
	tag_t status_part_SOR_Rel	   = NULLTAG;
	tag_t *status_part_SOR_objects = NULLTAG;
	int status_part_SOR_cnt = 0;
	int status_prt_c		= 0;
	char *status_part_SOR_num          = NULL;
	char *status_rel_part_SOR          = NULL;
	int SOR_MBOMDML_Val = 0;
	int AutoSorFlag = 0;
	/********************AutoSor Priyanka*******************/

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n ************** Ketan Inside mbom_dml_release ***************\n ");fflush(stdout);

	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}
	
	////////////////
	
	// tag_t user_temp = NULLTAG;
	// char*	user_id = NULL;
	// 
	// CALLAPI(POM_get_user(&user_id,&user_temp));
	// //CALLAPI(SA_find_user(user_id, &user_temp));
	// if (!user_temp)
	// {
	// 	printf("\n User ID: %s does not exist!\n", user_id);
	// }
	// else
	// {
	// 	CALLAPI(AOM_load(user_temp));
	// 	CALLAPI(AOM_refresh(user_temp, 1));
	// 	CALLAPI(POM_set_user_id(user_temp, "aplloader"));
	// 	CALLAPI(AOM_save_without_extensions(user_temp));
	// 	CALLAPI(AOM_refresh(user_temp,0));
	// 	printf("\n Before POM_set_user_id => %s\n",user_id);
	// 	CALLAPI(SA_ask_user_identifier2(user_temp, user_id));
	// 	printf("\n After POM_set_user_id => %s\n",user_id);
	// }
	////////////////

	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n ketan mbom_dml_release \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n CurrentTask => %s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n Parent Name => %s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("\n Target Attachment => %d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n type_name changes done: for workspaceobject %s\n", type_name);fflush(stdout);
	}
	

	// Control Object for Calling EXE // Added By Ketan TZ 1.73
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl1[3]= {"MBOM","Stamping","0"};
	
    tag_t qryTagCntrl1				= NULLTAG;
    tag_t* list_of_WSO_cntrl_tags1	= NULLTAG;

	int n_entryCntrl1		  = 3;
	int control_number_found1 = 0;;

	CALLAPI(QRY_find2("Control Objects...", &qryTagCntrl1));

	if (qryTagCntrl1)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPI(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
	}

	if(control_number_found1>0)
	{
		printf("\n Control Object Based Execution \n");fflush(stdout);

	    char* MBOM_DML_no = NULL;
		
		AOM_ask_value_string( DMLTag,"item_id",&MBOM_DML_no);

		printf("\n MBOM_DML_no => %s \n",MBOM_DML_no);fflush(stdout);

		char* t5_Userinfo1 = NULL;
		char cmd[100];

		tag_t MBOM_obj = list_of_WSO_cntrl_tags1[0];
		CALLAPI(AOM_ask_value_string(MBOM_obj,"t5_Userinfo1",&t5_Userinfo1));	
		sprintf(cmd,"%s %s",t5_Userinfo1,MBOM_DML_no);
		printf("Ketan Excuting Command = %s",cmd);fflush(stdout);
		system(cmd);
		printf("After executing Command");fflush(stdout);
	}
	else
	{
		printf("\n Non - Control Object Based Execution \n");fflush(stdout);

		if(strcmp(type_name,"T5_MBOMDMLRevision")==0)
		{
			    printf("\n inside class T5_MBOMDMLRevision......\n");fflush(stdout);
				AOM_ask_value_string( DMLTag, "item_id", &item_id);
				AOM_ask_value_string( DMLTag, "current_id", &DML_no);
				AOM_ask_value_strings(DMLTag,"t5_crdesigngroup",&num,&DesignGroupList);
				AOM_ask_value_string(DMLTag,"t5_MBOMRlzType",&RlsType);
				AOM_ask_value_string( DMLTag, "t5_cprojectcode", &Proj_Code);


				DML_Num=tc_strtok(DML_no,"_");
				printf("\nTest0.11..DML_Num:[%s],[%s]\n",DML_Num,DML_no);
				PLT_Code = tc_strtok(NULL,"_");
				printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,DML_no);

				strcpy(lcsToset,"T5_MBOMReleased");

				getCurrentDateTime(cCurrentAccessDate);
				printf("\n cCurrentAccessDate:%s",cCurrentAccessDate);
			    CALLAPI(ITK_string_to_date(cCurrentAccessDate, &Release_date ));
		 	  
				printf("\n Proj_Code : %s\n",Proj_Code);fflush(stdout);
				printf("\n item_id : %s\n",item_id);fflush(stdout);
				printf("\n DML_no : %s\n",DML_no);fflush(stdout);
				printf("\n RlsType : %s\n",RlsType);fflush(stdout);
				printf("\n num is : %d\n",num);fflush(stdout);
				printf("\n Item created first time only with item_id \n");fflush(stdout);

				if (DMLTag != NULLTAG)
				{
					GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
							
					CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&count,&TaskRevision));
					
					printf("\n MBOM DML to Task Count : %d",count);fflush(stdout);
					TaskRevTag = TaskRevision[TaskCnt];
					for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
					{
						TaskRevTag = TaskRevision[TaskCnt];

						counted_tag_list_t tlNewTargets = {0};
						int initial_tag_list_size = 16; // Reference PR-8968371 // 26062023
						tlNewTargets.list = (tag_t *)MEM_alloc(initial_tag_list_size * (sizeof(tag_t)));

						CALLAPI(EPM__add_to_tag_list(TaskRevTag, &tlNewTargets));

						CALLAPI(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
						printf("\n object_type is :%s",object_type);fflush(stdout);
						if(strcmp(object_type,"T5_MBOMTASKRevision")==0)
						{
							PartCnt=0;
							//printf("\n Task Stamping \n");fflush(stdout);
							//status = t5UpdateLifecycleStateMBOM(TaskRevTag, lcsToset);
							CALLAPI(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
							printf("\n MBOM Task DML PartCnt: %d",PartCnt);fflush(stdout);
							if (PartCnt>0)
							{
								GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
								for (k=0;k<PartCnt ;k++ )
								{
									printf("\n MBOM DML for k =:%d",k);fflush(stdout);
									AssyTag=PartTags[k];

									CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
									printf("\n MBOM DML Part_no is :%s",Part_no);	fflush(stdout);

									CALLAPI(AOM_ask_value_string(AssyTag,"t5_PartType",&parttype));
									printf("\n MBOM DML Parttype  is :%s",parttype);	fflush(stdout);

									if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
									if(TCTYPE_ask_name2(objTypeTag,&type_name1));
									printf("\n MBOM DML AssyTag type_name1 := %s", type_name1);fflush(stdout);

									CALLAPI(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
									printf("\n MBOM DML AssyTag PartTypeStr := %s", PartTypeStr);fflush(stdout);

									CALLAPI(EPM__add_to_tag_list(AssyTag, &tlNewTargets));
									printf("\n Test 1  \n");fflush(stdout);

									/***************Auto SOR Stamping Priyanka*************************************/
									
									SOR_MBOMDML_Val = 0;
									SOR_MBOMDML_Val = tm_check_SOR_MBOMDML_Val_control_object ( "AUTOSORMBOM" , "ON" );
									if ( SOR_MBOMDML_Val > 0)
									{
										status_Part_SOR_Tag	   = NULLTAG;
										status_part_SOR_Rel	   = NULLTAG;
										status_part_SOR_objects = NULLTAG;
										status_part_SOR_cnt = 0;
										status_prt_c		= 0;
										status_part_SOR_num          = NULL;
										status_rel_part_SOR          = NULL;

									CALLAPI(GRM_find_relation_type("T5_PartSorRel",&status_part_SOR_Rel));
									printf("\nExpanding Part to MBOM SOR relation");fflush(stdout);
									CALLAPI(GRM_list_secondary_objects_only(AssyTag, status_part_SOR_Rel, &status_part_SOR_cnt, &status_part_SOR_objects));
									printf("\n status_part_MBOMSOR_cnt : [%d]\n",status_part_SOR_cnt);fflush(stdout);
									if ( status_part_SOR_cnt > 0)
										{
											for ( status_prt_c = 0; status_prt_c < status_part_SOR_cnt; status_prt_c++ )
											{
												status_Part_SOR_Tag= status_part_SOR_objects[status_prt_c];
												CALLAPI(AOM_UIF_ask_value(status_Part_SOR_Tag,"item_id",&status_part_SOR_num));
												CALLAPI(AOM_UIF_ask_value(status_Part_SOR_Tag,"release_status_list",&status_rel_part_SOR));
												printf("\nstatus_part_MBOMSOR_num : [%s]\tstatus_rel_part_MBOMSOR : [%s]",status_part_SOR_num,status_rel_part_SOR);fflush(stdout);
												if((tc_strcmp ( status_rel_part_SOR,"MBOM Working" )==0) || (tc_strcmp( status_rel_part_SOR,"T5_MBOMWorking" )==0) || (tc_strcmp ( status_rel_part_SOR,"MBOM Review" )==0) || (tc_strcmp( status_rel_part_SOR,"T5_MBOMReview" )==0))
												{
													printf("\n Inside Autosor stamping \n");fflush(stdout);
													AutoSorFlag = 1;
													break;
												}
											}
										}
										if(AutoSorFlag == 1)
										{
												printf("\n Inside AutoSorFlag \n");fflush(stdout);
												CALLAPI(EPM__add_to_tag_list(status_Part_SOR_Tag, &tlNewTargets));
										}
									}
									else 
									{
										printf("\nControl object not present for AUTOSORMBOM,ON");fflush(stdout);
									}


									/***************Auto SOR Stamping Priyanka*************************************/

									// Ketan Added for Dataset // 01072023

									int		dataset_count		= 0;
									int		i_dataset			= 0;
									int		datset_st_count1	= 0;
									int		data_cnt			= 0;
									int		DatasetFlag			= 0;

									tag_t*	dataset_secObjsList		= NULLTAG;
									tag_t	Dataset_Tag_Name		= NULLTAG;
									tag_t	dataset_objNameType		= NULLTAG;
									tag_t*  dataset_status_list1	= NULLTAG;

									char*	DatasetNameOfObjTyp = NULL;
									char*   dataset_WSO_Name	= NULL;
									
									CALLAPI(GRM_list_secondary_objects_only(AssyTag, NULLTAG, &dataset_count, &dataset_secObjsList));
									printf("\n dataset_count ==> [%d]\n", dataset_count);fflush(stdout);

									if (dataset_count > 0)
									{
										for (i_dataset=0;i_dataset<dataset_count;i_dataset++ )
										{
											Dataset_Tag_Name= dataset_secObjsList[i_dataset];
											TCTYPE_ask_object_type(Dataset_Tag_Name,&dataset_objNameType);
											if(dataset_objNameType != NULLTAG)
											{
												TCTYPE_ask_name2(dataset_objNameType,&DatasetNameOfObjTyp);
												printf("\n[%d]Sec Object Type is %s \n",i_dataset,DatasetNameOfObjTyp);fflush(stdout);
												if ((tc_strcmp(DatasetNameOfObjTyp,"CMI2Product")==0) ||(tc_strcmp(DatasetNameOfObjTyp,"CMI2Part")==0)||(tc_strcmp(DatasetNameOfObjTyp,"CMI2Drawing")==0)||(tc_strcmp(DatasetNameOfObjTyp,"DirectModel")==0)||(tc_strcmp(DatasetNameOfObjTyp,"ProAsm")==0)||
														(tc_strcmp(DatasetNameOfObjTyp,"ProPrt")==0)||(tc_strcmp(DatasetNameOfObjTyp,"ProDrw")==0)||(tc_strcmp(DatasetNameOfObjTyp,"PDF")==0))
												{
													printf("\n Found Sec obj is of type ::[%s]\n", DatasetNameOfObjTyp);fflush(stdout);

													CALLAPI(WSOM_ask_release_status_list(Dataset_Tag_Name,&datset_st_count1,&dataset_status_list1));
													printf("\n datset_st_count1 :%d is\n",datset_st_count1);fflush(stdout);
													
													DatasetFlag	= 0;

													if(datset_st_count1>0)
													{
														for (data_cnt=0;data_cnt< datset_st_count1;data_cnt++ )
														{
															dataset_WSO_Name=NULL;
															CALLAPI(AOM_ask_name(dataset_status_list1[data_cnt],&dataset_WSO_Name));
															printf("\n dataset_WSO_Name => :%s\n",dataset_WSO_Name);fflush(stdout);
															if(tc_strcmp(dataset_WSO_Name,"")!=0)
																{
																	if ((tc_strcmp(dataset_WSO_Name,"T5_MBOMWorking")==0) || (tc_strcmp(dataset_WSO_Name,"T5_MBOMReview")==0) )
																	{
																		printf("\n Inside dataset_WSO_Name \n");fflush(stdout);
																		DatasetFlag = 1;
																		break;
																	}
																}
														}
													}
													if(DatasetFlag == 1)
													{
														printf("\n Inside DatasetFlag \n");fflush(stdout);
														CALLAPI(EPM__add_to_tag_list(Dataset_Tag_Name, &tlNewTargets));
													}
													
												}
											}
										}
									}

									// Ketan Ended

									//printf("\n Assy Stamping \n");fflush(stdout);
									//status = t5UpdateLifecycleStateMBOM(AssyTag, lcsToset);
									
								}
							}
								printf("\n Test 2  \n");fflush(stdout);
								int *piAttachTypes = NULL;
								int ii = 0;
								piAttachTypes = (int *) MEM_alloc (tlNewTargets.count * sizeof(int));
								for (ii = 0; ii < tlNewTargets.count; ii++)
								{
									printf("\n Test 2.1  \n");fflush(stdout);
									piAttachTypes[ii] = EPM_target_attachment;
								}
								printf("\n Test 4  \n");fflush(stdout);
								CALLAPI(AOM_refresh(rootTask, TRUE));
								printf("\n Test 3 \n");fflush(stdout);
								
								CALLAPI(EPM_add_attachments(rootTask, tlNewTargets.count, tlNewTargets.list, piAttachTypes));
								printf("\n Test 5  \n");fflush(stdout);
								
								if(piAttachTypes) MEM_free(piAttachTypes);
								
								CALLAPI(AOM_save_without_extensions(rootTask));
								printf("\n Test 6  \n");fflush(stdout);

								for (ii = 0; ii < tlNewTargets.count; ii++)
								{
									printf("\n Stamping : %d\n",ii);fflush(stdout);
									status = t5UpdateLifecycleStateMBOM(tlNewTargets.list[ii], lcsToset);

								}
								printf("\n Test 7  \n");fflush(stdout);
								CALLAPI(EPM_remove_attachments(rootTask,tlNewTargets.count,tlNewTargets.list));
								printf("\n Test 8 \n");fflush(stdout);
								
							//}
							
						}

					}  /// Solution Item end
							   
				printf("\n DML Stamping \n");fflush(stdout);
				status = t5UpdateLifecycleStateMBOM(DMLTag, lcsToset); //DML status stamped thru workflow.
				}

		}
		else
		{
		  	printf("\n No proper class class T5_MBOMDMLRevision......\n");fflush(stdout);
		}

	}

	return error_code;

}
//venkat added

void setAddTAG_Mbom(int *count,tag_t **objlist,tag_t obj ) // Added By Ketan 
{
 
	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTAG_11");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
 
	}
	else
	{
		//printf("\n ****setAddTAG_12");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
 
	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}
//int DefaultAssignMBOMManagerReview(tag_t APLTaskRevT, char *plantname,char *Role,char *cuserid)
int DefaultAssignMBOMManagerReview(tag_t APLTaskRevT, char *CurrentChangSplGrp,int chngSplCnt)
{
	int ifail	= ITK_ok ;
	tag_t  	group_tag	=	 NULLTAG;
	tag_t  	user_tag	=	 NULLTAG;
	tag_t  	*role_tags	=	 NULLTAG;
	tag_t  	*member_tags	=	 NULLTAG;
	int		num_of_roles	= 0;
	int		z				= 0;
	int		b				= 0;
	int		num_of_members		= 0;
	char*	rolename	= NULL;
	char*	userid	= NULL;
	char*	Task_no	= NULL;


	int		oldusrcount	   = 0; 
	int		cnt			   = 0; 
	int		par_Cnt			   = 0; 
	int		VldrRwCnt			   = 0; 

	tag_t*	OldParticipantRel   	= NULLTAG;
	tag_t   current_member			= NULLTAG;
	tag_t	new_participant_type	= NULLTAG;
	tag_t	participant_type		= NULLTAG;
	tag_t	new_participant_tag		= NULLTAG;
	tag_t	AnalystTag	= NULLTAG;
	
	char*	type_name;
	//venkat added
	char*	plantname;
	char*	Role;
	char*	cuserid;
	char*	CurrenttokenChangSplGrp;
	char*	validRowData;
	char*	userName;

	char *arrayVadDt[chngSplCnt];
	CurrenttokenChangSplGrp=(char *) MEM_alloc(50 * sizeof(char *));

	printf("\n  user assignment  as per existing userid\n");fflush(stdout);
	// user assignment  as per existing userid :;MBOM/MBOM_Default/Amol M Didore (amd04961);MBOM/MBOM_Default/Ketan Bhut (kbb910337) :2
	printf("\n  user assignment  as per existing userid :%s :%d\n",CurrentChangSplGrp,chngSplCnt);fflush(stdout);
	//CurrentChangSplGrp	= tc_strtok(CurrentChangSplGrp);

	for (VldrRwCnt=0;VldrRwCnt<chngSplCnt;VldrRwCnt++ )
	{
		if(VldrRwCnt==0)
		{
			validRowData=tc_strtok(CurrentChangSplGrp,";");
		}
		else
		{
			validRowData=tc_strtok(NULL,";");
		}

		printf("\n validRowData :[%s]\n",validRowData);fflush(stdout);
		if (validRowData != NULL)
		{
	

			arrayVadDt[VldrRwCnt]=validRowData;
			printf("\n index and arrayVadDt[VldrRwCnt] : %d:[%s] \n",VldrRwCnt,arrayVadDt[VldrRwCnt]);fflush(stdout);	
		}

	}

	for(par_Cnt=0;par_Cnt<chngSplCnt;par_Cnt++)
	{
		CurrenttokenChangSplGrp		=	arrayVadDt[par_Cnt];
		
		cnt ++;

		
		printf("\n\n DefaultAssignMBOMManagerReview Task_no111111111  is :%s :%d", CurrenttokenChangSplGrp,cnt);
		plantname = tc_strtok(CurrenttokenChangSplGrp,"/");
		Role	=	tc_strtok(NULL,"/");
		userName = tc_strtok(NULL,"(");
		cuserid = tc_strtok(NULL,")");

		printf("\n Plant Name : [%s] group : [%s]  user id : [%s]  : [%s]\n", plantname,Role,userName,cuserid);fflush(stdout);
		CALLAPI(AOM_ask_value_string(APLTaskRevT, "item_id", &Task_no));
		printf("\n\n DefaultAssignMBOMManagerReview Task_no  is :%s", Task_no);
		CALLAPI(SA_find_group(plantname, &group_tag));

		if (group_tag != NULLTAG)
		CALLAPI(SA_ask_roles_from_group(group_tag, &num_of_roles, &role_tags));

		printf("\nNo of Role found in Group are 11111111111:%d\n", num_of_roles);
		fflush(stdout);

		for (z = 0; z < num_of_roles; z++)
		{
			CALLAPI(SA_ask_role_name2(role_tags[z], &rolename));
		printf("\nRol Name :[%d][%s]\n", z, rolename);
		if (tc_strstr(rolename, Role) != NULL)
		{
			printf("\n got the  Group");
			CALLAPI(SA_find_groupmember_by_role(role_tags[z], group_tag, &num_of_members, &member_tags));
			printf("\n No of Group Members found in Group/Role are :%d\n", num_of_members);
			if (num_of_members > 0)
			{
				b = 0;
				tag_t*	ptypes		= NULLTAG;
				tag_t*	ptypes2		= NULLTAG;
				int p1=0;
				int p2=0;

				for (b = 0; b < num_of_members; b++)
				{
					CALLAPI(SA_ask_groupmember_user(member_tags[b], &user_tag));
					CALLAPI(SA_ask_user_identifier2(user_tag, &userid));
					printf("\n venkat User ID Name :[%s]\n", userid);
					// Plant Name : [APLPUNE] group : [00_APLP_Reviewer] username : [APLReviewer ]  user id : [aplreviewer]
					printf("\n Plant Name : [%s] group : [%s]  user id : [%s]  \n", plantname,Role,cuserid);fflush(stdout);


					//User ID Name :[aplreviewer]
					if (tc_strcmp(userid,cuserid)==0)
					{
					
						TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
						setAddTAG_Mbom(&p1,&ptypes,participant_type);
						printf("\n venkat DefaultAssignMBOMManagerReview\n");fflush(stdout);
						setAddTAG_Mbom(&p2,&ptypes2,member_tags[b]);
						printf("\nvenkat DefaultAssignMBOMManagerReview \n");fflush(stdout);
					}

						tag_t* participant_list = NULLTAG;
						logical bypass_assignable_check =true;
						int k = 0;

						tag_t   type1TypeTag			= NULLTAG;

						char*    type1type_name;
						printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
						for(k=0;k<p2;k++)
						{
							tag_t type1 = ptypes[k];
							if(type1 != NULLTAG )
							{
								if(TCTYPE_ask_object_type(type1,&type1TypeTag));
								if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
								printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
							}
							else
							{
								printf("\n venkat type is NULL \n");fflush(stdout);
							}
						}

						CALLAPI(PARTICIPANT_add_participants(APLTaskRevT,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));

				}
	
			}
		}
		}
		if (cnt == chngSplCnt)
		{
			printf("\nparticipant count same as per passed Participant count value : %d :%d\n", cnt,chngSplCnt);
			fflush(stdout);
			break;

		}
		
	}

	return ITK_ok;
}

//int DefaultAssignMBOMReviewer(tag_t APLTaskRevT, char *plantname,char *group,char *cuserid)
int DefaultAssignMBOMReviewer(tag_t APLTaskRevT, char *CurrentChangSplGrp,int chngSplCnt)
{
	int ifail	= ITK_ok ;
	tag_t  	group_tag	=	 NULLTAG;
	tag_t  	user_tag	=	 NULLTAG;
	tag_t  	*role_tags	=	 NULLTAG;
	tag_t  	*member_tags	=	 NULLTAG;
	int		num_of_roles	= 0;
	int		z				= 0;
	int		b				= 0;
	int		num_of_members		= 0;
	char*	rolename	= NULL;
	char*	userid	= NULL;
	char*	Task_no	= NULL;


	int		oldusrcount	   = 0; 
	int		cnt			   = 0; 
	int		par_Cnt			   = 0; 
	int		VldrRwCnt			   = 0; 

	tag_t*	OldParticipantRel   	= NULLTAG;
	tag_t   current_member			= NULLTAG;
	tag_t	new_participant_type	= NULLTAG;
	tag_t	participant_type		= NULLTAG;
	tag_t	new_participant_tag		= NULLTAG;
	tag_t	AnalystTag	= NULLTAG;
	
	char*	type_name;
	//venkat added
	char*	plantname;
	char*	Role;
	char*	cuserid;
	char*	CurrenttokenChangSplGrp;
	char*	PartcipantData;
	char*	userName;

	char *arrayVadDt[chngSplCnt];
	CurrenttokenChangSplGrp=(char *) MEM_alloc(50 * sizeof(char *));

	printf("\n  user assignment  as per existing userid\n");fflush(stdout);
	// user assignment  as per existing userid :;MBOM/MBOM_Default/Amol M Didore (amd04961);MBOM/MBOM_Default/Ketan Bhut (kbb910337) :2
	printf("\n  user assignment  as per existing userid :%s :%d\n",CurrentChangSplGrp,chngSplCnt);fflush(stdout);

	for (VldrRwCnt=0;VldrRwCnt<chngSplCnt;VldrRwCnt++ )
	{
		if(VldrRwCnt==0)
		{
			PartcipantData=tc_strtok(CurrentChangSplGrp,";");
		}
		else
		{
			PartcipantData=tc_strtok(NULL,";");
		}

		printf("\n Participants Data :[%s]\n",PartcipantData);fflush(stdout);
		if (PartcipantData != NULL)
		{
	

			arrayVadDt[VldrRwCnt]=PartcipantData;
			printf("\n index and arrayParticipantVadDt[VldrRwCnt] : %d:[%s] \n",VldrRwCnt,arrayVadDt[VldrRwCnt]);fflush(stdout);	
		}

	}

	for(par_Cnt=0;par_Cnt<chngSplCnt;par_Cnt++)
	{
		CurrenttokenChangSplGrp		=	arrayVadDt[par_Cnt];
		
		cnt ++;

		
		printf("\n\n DefaultAssignMBOMManagerReview Task_no111111111  is :%s :%d", CurrenttokenChangSplGrp,cnt);
		plantname = tc_strtok(CurrenttokenChangSplGrp,"/");
		Role	=	tc_strtok(NULL,"/");
		userName = tc_strtok(NULL,"(");
		cuserid = tc_strtok(NULL,")");

		printf("\n Plant Name : [%s] group : [%s]  user id : [%s]  : [%s]\n", plantname,Role,userName,cuserid);fflush(stdout);
		CALLAPI(AOM_ask_value_string(APLTaskRevT, "item_id", &Task_no));
		printf("\n\n DefaultAssignMBOMManagerReview Task_no  is :%s", Task_no);
		CALLAPI(SA_find_group(plantname, &group_tag));

		if (group_tag != NULLTAG)
		CALLAPI(SA_ask_roles_from_group(group_tag, &num_of_roles, &role_tags));

		printf("\nNo of Role found in Group are 11111111111:%d\n", num_of_roles);
		fflush(stdout);

		for (z = 0; z < num_of_roles; z++)
		{
			CALLAPI(SA_ask_role_name2(role_tags[z], &rolename));
			printf("\nRol Name :[%d][%s]\n", z, rolename);
			if (tc_strstr(rolename, Role) != NULL)
			{
				printf("\n got the  Group");
				CALLAPI(SA_find_groupmember_by_role(role_tags[z], group_tag, &num_of_members, &member_tags));
				printf("\n No of Group Members found in Group/Role are :%d\n", num_of_members);
				if (num_of_members > 0)
				{
						b = 0;
						tag_t*	ptypes		= NULLTAG;
						tag_t*	ptypes2		= NULLTAG;
						int p1=0;
						int p2=0;

						for (b = 0; b < num_of_members; b++)
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[b], &user_tag));
							CALLAPI(SA_ask_user_identifier2(user_tag, &userid));
							printf("\n venkat User ID Name :[%s]\n", userid);
							// Plant Name : [APLPUNE] group : [00_APLP_Reviewer] username : [APLReviewer ]  user id : [aplreviewer]
							printf("\n Plant Name : [%s] group : [%s]  user id : [%s]  \n", plantname,Role,cuserid);fflush(stdout);


							//User ID Name :[aplreviewer]
							if (tc_strcmp(userid,cuserid)==0)
							{
							
								TCTYPE_find_type("T5_DMUReviewer", "T5_DMUReviewer", &participant_type);
								setAddTAG_Mbom(&p1,&ptypes,participant_type);
								printf("\n venkat DefaultAssignMBOMManagerReview\n");fflush(stdout);
								setAddTAG_Mbom(&p2,&ptypes2,member_tags[b]);
								printf("\nvenkat DefaultAssignMBOMManagerReview \n");fflush(stdout);
							}

								tag_t* participant_list = NULLTAG;
								logical bypass_assignable_check =true;
								int k = 0;

								tag_t   type1TypeTag			= NULLTAG;

								char*    type1type_name;
								printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
								for(k=0;k<p2;k++)
								{
									tag_t type1 = ptypes[k];
									if(type1 != NULLTAG )
									{
										if(TCTYPE_ask_object_type(type1,&type1TypeTag));
										if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
										printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
									}
									else
									{
										printf("\n venkat type is NULL \n");fflush(stdout);
									}
								}

								CALLAPI(PARTICIPANT_add_participants(APLTaskRevT,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));

						}
			
				}
			}
		}
		if (cnt == chngSplCnt)
		{
			printf("\nparticipant count same as per passed Participant count value : %d :%d\n", cnt,chngSplCnt);
			fflush(stdout);
			break;

		}
		
	}
	return ITK_ok;
}
//venkat end

int mbom_dml_claim( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
    char* lcsTosetR=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;

	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	char ClosureRule[40];
	 char usrLocation[40];
	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;
	char*			DML_Num				= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	int              st_count1 = 0;
	int              cnt = 0;
	int              DMLFlag = 0;
	int              PartFlag = 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
	tag_t  CurrentRoleTag = NULLTAG;
	//char       roleName[SA_name_size_c+1]  ;
	char   *roleName=NULL;
	tag_t*    status_list1=NULLTAG;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char *Part_Coated = NULL;
	char *Part_ColourInd = NULL;
	char *Part_Type = NULL;
	char **DesignGroupList;
	char *WSO_Name = NULL;
	char *type_name = NULL;
	//char   type_name[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
	lcsTosetR =(char *) MEM_alloc(20 * sizeof(char *));


    printf("\n ************** Ketan Inside mbom_dml_claim ***************\n ");fflush(stdout);

	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}


	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n mbom_dml_claim \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
    printf("\n CurrentTask => %s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n Parent Name => %s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("\n Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_MBOMTASKRevision")==0 || strcmp(CurrentTask,"Work On MBOM-DML")==0)
	{
		    printf("\n inside class T5_MBOMTASKRevision......\n");fflush(stdout);
			AOM_ask_value_string( DMLTag, "item_id", &item_id);
			AOM_ask_value_string( DMLTag, "current_id", &DML_no);
			
			DML_Num=tc_strtok(DML_no,"_");
			printf("\nTest0.11..DML_Num:[%s],[%s]\n",DML_Num,DML_no);
			Dsgn_No = tc_strtok(NULL,"_");
			printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,DML_no);
			PLT_Code = tc_strtok(NULL,"_");
			printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,DML_no);

			strcpy(lcsToset,"T5_MBOMWorking");
			strcpy(lcsTosetR,"T5_MBOMReview");  // Ketan Added // 01072023
    		
			ITKCALL(WSOM_ask_release_status_list(DMLTag,&st_count1,&status_list1));
			printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

			if(st_count1>0)
			{
				for (cnt=0;cnt< st_count1;cnt++ )
				{
					WSO_Name=NULL;
					ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
					printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
					if(tc_strcmp(WSO_Name,"")!=0)
						{
							if (tc_strcmp(WSO_Name,lcsToset)==0)
							{
								DMLFlag = 1;
							}
						}
				}
			}

			if(DMLFlag == 0)
			{
				CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
				CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
				printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
				CALLAPI(RELSTAT_add_release_status(status2,1,&DMLTag,retain));
			}

			ITKCALL(SA_ask_current_role(&CurrentRoleTag));
			ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
			printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n DML_no : %s\n",DML_no);fflush(stdout);
			
			printf("\n Item created first time only with item_id \n");fflush(stdout);
			if (DMLTag != NULLTAG)
			 {
					PartCnt=0;
					mbom_getPlantDetailsAttr(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency,ClosureRule,usrLocation);
					printf("\n PlantCS %s \n",PlantCS);
					printf("\n PlantOptCS %s \n",PlantOptCS);
					printf("\n PlantAgency %s \n",PlantIA);
					printf("\n PlantStore %s \n",PlantStore);
					printf("\n UserAgency %s \n",UserAgency);
					printf("\n ClosureRule %s \n",ClosureRule);

					CALLAPI(AOM_ask_value_tags(DMLTag,"CMHasSolutionItem",&PartCnt,&PartTags));
					printf("\n MBOM Task Part Count: %d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n MBOM DML for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];

							PartFlag = 0;
			            	ITKCALL(WSOM_ask_release_status_list(AssyTag,&st_count1,&status_list1));
							printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

							if(st_count1>0)
							{
								for (cnt=0;cnt< st_count1;cnt++ )
								{
									WSO_Name=NULL;
									ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
									printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
									if(tc_strcmp(WSO_Name,"")!=0)
										{
											//if (tc_strcmp(WSO_Name,lcsToset)==0 || tc_strcmp(WSO_Name,lcsTosetR)==0 )
											if (tc_strcmp(WSO_Name,lcsTosetR)==0 ) // Added by Ketan 29072023
											{
												printf("\n Inside PartFlag=1 \n");fflush(stdout);
												PartFlag = 1;
											}
										}
								}
							}

							if(PartFlag == 0)
							{
								printf("\n Inside PartFlag=0 \n");fflush(stdout);
								//CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
								CALLAPI(RELSTAT_create_release_status(lcsTosetR,&status2)); // Added by Ketan 29072023
								CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
								printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
								CALLAPI(RELSTAT_add_release_status(status2,1,&AssyTag,retain));
							}


							CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
							printf("\n MBOM Task Part_no  is :%s",Part_no);	fflush(stdout);

							CALLAPI(AOM_ask_value_string(AssyTag,"t5_Coated",&Part_Coated));
							printf("\n MBOM Task Part_Coated  is :%s",Part_Coated);	fflush(stdout);
							CALLAPI(AOM_ask_value_string(AssyTag,"t5_ColourInd",&Part_ColourInd));
							printf("\n MBOM Task Part_ColourInd  is :%s",Part_ColourInd);	fflush(stdout);
							CALLAPI(AOM_ask_value_string(AssyTag,"t5_PartType",&Part_Type));
							printf("\n MBOM Task Part_Type is :%s",Part_Type);	fflush(stdout);

							if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
							if(TCTYPE_ask_name2(objTypeTag,&type_name1));
							printf("\n MBOM Task AssyTag type_name1 := %s", type_name1);fflush(stdout);

							CALLAPI(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
							printf("\n MBOM Task AssyTag PartTypeStr := %s", PartTypeStr);fflush(stdout);

							
						}
					}
				}
	// Ketan Added for reject // 20072023

	tag_t   qryTagCntrlobj		= NULLTAG;
	tag_t*	list_of_cntrl_tags	= NULLTAG;

	char*	qry_entryCntrlformat[4] = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};	
	char**	qry_valuesCntrlformat	= (char **) MEM_alloc(5 * sizeof(char *));

	int controlObjfound	= 0;
	int	n_entryCntrlobj = 4;

	if(QRY_find2("Control Objects...", &qryTagCntrlobj));

	if (qryTagCntrlobj)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrlformat[0]="MBOM";
		qry_valuesCntrlformat[1]="TaskReject";
		qry_valuesCntrlformat[2]="0";
		qry_valuesCntrlformat[3]="Live";
		
		if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
	}
	else
	{
		printf("\n Control Object Query not Found  \n");fflush(stdout);
	}

	printf("\n controlObjfound is ==> %d\n",controlObjfound);fflush(stdout);

	if(controlObjfound>0)
	{
	
		printf("\n\n Ketan Inside code for MBOM rejection \n");fflush(stdout);

		int		extUsrCnt	   = 0; 
		int		oldusrcount	   = 0; 
		
		tag_t*	OldParticipantRel   	= NULLTAG;
		tag_t	OldParticipantRelTag	= NULLTAG;
		tag_t	OldObjTypTask			= NULLTAG;
		tag_t   current_member			= NULLTAG;
		tag_t	new_participant_type	= NULLTAG;
		tag_t	new_participant_tag		= NULLTAG;

		char	Oldtype_namee_task[TCTYPE_name_size_c+1];
		
		// Ketan Added 09/01/2024
		tag_t	AnalystTag	= NULLTAG;
		tag_t	objTypeTag	= NULLTAG;

		char*	type_name;


		//venkat added
		char*	Mbomreviwergroup		 = NULL;
		char*	CurrentDMUReviewGrp		 = NULL;
		char*	CurrentChangSplGrp		 = NULL;
		
		char*	DMUReviewGrp			 = NULL;

		char*	DMUplantname			 = NULL;
		char*	DMUrole					 = NULL;
		char*	DMUDisuser				 = NULL;
		char*	DMUcuserid				 = NULL;
		
		char*	Changesplantname		 = NULL;
		char*	ChangeSpl_role			 = NULL;
		char*	ChangeSplDisuser		 = NULL;
		char*	ChangeSpl_cuserid		 = NULL;
		char*	Userinfo2				 = NULL;
		char*	titem_id				 = NULL;

		CurrentDMUReviewGrp=(char *) MEM_alloc(1000 * sizeof(char *));
		CurrentChangSplGrp=(char *) MEM_alloc(1000 * sizeof(char *));
		AOM_ask_value_string( DMLTag, "item_id", &titem_id);
		
		printf("\n\n\t\t venat item id  and titemid  :%s :  [%s]\n", item_id,titem_id);
		fflush(stdout);

		char *DMLNO = tc_strtok(titem_id, "_");
		char *Dsgn_No = tc_strtok(NULL, "_");
		char *DMLPlant = tc_strtok(NULL, "_");

		printf("\n\n\t\t inside mbom task :DMLNO : Designgrp:DMLPlant  : [%s] :[%s] :[%s] \n", DMLNO, Dsgn_No, DMLPlant);
		fflush(stdout);
		tag_t	DML_tag1		= NULLTAG;
		tag_t	DMLrevtag = NULLTAG; 
		char*	ERC_MBOMReleaseType	= NULL;

		ITKCALL(ITEM_find_item (DMLNO, &DML_tag1));
		
	
		if(DML_tag1 != NULLTAG )
		{
			printf("\ninside  ERC_MBOMReleaseType :\n");fflush(stdout);
			ITKCALL(ITEM_ask_latest_rev(DML_tag1,&DMLrevtag));
			AOM_ask_value_string( DMLrevtag, "t5_rlstype", &ERC_MBOMReleaseType);

			printf("\n ERC_MBOMReleaseType : %s\n",ERC_MBOMReleaseType);fflush(stdout);
		}

		

		CALLAPI(AOM_UIF_ask_value(DMLTag, "ChangeSpecialist1", &Mbomreviwergroup)); //ADDED BY VENKAT
		printf("\n venkat Mbom Manager  and item id : %s : %s\n",Mbomreviwergroup,item_id);fflush(stdout);

		Changesplantname	=	tc_strtok(Mbomreviwergroup,"/");
		ChangeSpl_role		=	tc_strtok(NULL,"/");
		ChangeSplDisuser	=	tc_strtok(NULL,"(");
		ChangeSpl_cuserid	=	tc_strtok(NULL,")");
		printf("\n TASK: DMU plant: [%s] role: [%s] :user %s:  current user : %s",Changesplantname,ChangeSpl_role,ChangeSplDisuser,ChangeSpl_cuserid);fflush(stdout);
		fflush(stdout);


		tag_t	relation_type	= NULLTAG;
		tag_t*	Part_objects	= NULLTAG;
		int		part_cnt	= 0;
		int chngSplCnt = 0;
		int dmuCnt = 0;


		ITKCALL(GRM_find_relation_type("HasParticipant", &relation_type));
		ITKCALL(GRM_list_secondary_objects_only(DMLTag, relation_type, &part_cnt, &Part_objects));
		printf("\n partcipant_cnt : [%d]\n",part_cnt);fflush(stdout);
		if (part_cnt > 0)
		{
			int ptcnt = 0;
			
			for (ptcnt= 0; ptcnt<part_cnt;ptcnt++ )
			{
				
				char*	tcParobject_name	= NULL;
				char*	DMUReviewr	= NULL;
				
				tag_t	ObjTypDmlCRB	= NULLTAG;

				if(TCTYPE_ask_object_type(Part_objects[ptcnt],&ObjTypDmlCRB));
			
				
				ITKCALL( TCTYPE_ask_name2	(ObjTypDmlCRB,&tcParobject_name));
				
				printf("\n\n\t\t tcParobject_name  ChangeSpecialist1:   %s\n",tcParobject_name);
				fflush(stdout);
				if (tc_strcmp(tcParobject_name,"ChangeSpecialist1")==0)
				{
				
					ITKCALL(AOM_UIF_ask_value(Part_objects[ptcnt],"fnd0AssigneeUser",&DMUReviewr));
					ITKCALL(AOM_UIF_ask_value(Part_objects[ptcnt],"assignee",&DMUReviewGrp));
					printf("\n TASK: DMU Reviewer: [%s] Group: [%s] ",DMUReviewr,DMUReviewGrp);fflush(stdout);
					if (DMUReviewGrp != NULL)
					{
						if (chngSplCnt == 0)
						{
						
							tc_strcpy(CurrentChangSplGrp,"");
							tc_strcpy(CurrentChangSplGrp,DMUReviewGrp);

							chngSplCnt++;

							printf("\n inside TASK: DMU Reviewer: Group: [%s] :%d",CurrentChangSplGrp,chngSplCnt);fflush(stdout);
						}
						else
						{
							tc_strcat(CurrentChangSplGrp,";");	
							tc_strcat(CurrentChangSplGrp,DMUReviewGrp);
							
							chngSplCnt++;
						
						
						}
						printf("\n inside TASK: DMU Reviewer: Group: [%s] :%d",CurrentChangSplGrp,chngSplCnt);fflush(stdout);
						
					}
					else{
					
						printf("\n NO TASK: DMUreviewer is found \n");fflush(stdout);
						fflush(stdout);
					}
				}
			}
		}
		//
		printf("\n TASK: DMU plant: [%s] role: [%s] :user %s: \n CurrentChangSplGrp : %s \n",Changesplantname,ChangeSpl_role,ChangeSplDisuser,CurrentChangSplGrp);fflush(stdout);
		fflush(stdout);



		//

		if( (tc_strcmp(ERC_MBOMReleaseType, "Veh") == 0)||(tc_strstr(item_id, "MB_") != NULL)||(tc_strstr(item_id, "MM_") != NULL))
		{
			
			tag_t	relation_type	= NULLTAG;
			tag_t*	Part_objects	= NULLTAG;
			int		part_cnt	= 0;

			printf("\n inside  partcipant_cnt vehicle or MB_ or MM_ task:\n");fflush(stdout);
			
			ITKCALL(GRM_find_relation_type("HasParticipant", &relation_type));
			ITKCALL(GRM_list_secondary_objects_only(DMLTag, relation_type, &part_cnt, &Part_objects));
			printf("\n partcipant_cnt : [%d]\n",part_cnt);fflush(stdout);
			if (part_cnt > 0)
			{
				int ptcnt = 0;
				for (ptcnt= 0; ptcnt<part_cnt;ptcnt++ )
				{
					
					char*	tcParobject_name	= NULL;
					char*	DMUReviewr	= NULL;
					
					tag_t	ObjTypDmlCRB	= NULLTAG;

					if(TCTYPE_ask_object_type(Part_objects[ptcnt],&ObjTypDmlCRB));
				
					
					ITKCALL( TCTYPE_ask_name2	(ObjTypDmlCRB,&tcParobject_name));
					
					printf("\n\n\t\t tcParobject_name :   %s\n",tcParobject_name);
					fflush(stdout);
					if (tc_strcmp(tcParobject_name,"T5_DMUReviewer")==0)
					{
					
						ITKCALL(AOM_UIF_ask_value(Part_objects[ptcnt],"fnd0AssigneeUser",&DMUReviewr));
						ITKCALL(AOM_UIF_ask_value(Part_objects[ptcnt],"assignee",&DMUReviewGrp));
						printf("\n TASK: DMU Reviewer: [%s] Group: [%s] ",DMUReviewr,DMUReviewGrp);fflush(stdout);

						if (DMUReviewGrp != NULL)
						{
							if (dmuCnt == 0)
							{
							
								tc_strcpy(CurrentDMUReviewGrp,"");
								tc_strcpy(CurrentDMUReviewGrp,DMUReviewGrp);

								dmuCnt++;

								printf("\n inside TASK: DMU Reviewer: Group: [%s] :%d",CurrentDMUReviewGrp,dmuCnt);fflush(stdout);
							}
							else
							{
								
								printf("\n inside else of adding participants DMU Reviewer \n");fflush(stdout);
								fflush(stdout);
								tc_strcat(CurrentDMUReviewGrp,";");
								tc_strcat(CurrentDMUReviewGrp,DMUReviewGrp);

								dmuCnt++;
							
							}
							printf("\n outside condition TASK: DMU Reviewer: Group: [%s] :%d",CurrentDMUReviewGrp,dmuCnt);fflush(stdout);
							//plantname=	tc_strtok(currentChangeSpecialist,"/");
							/*DMUplantname=	tc_strtok(DMUReviewGrp,"/");
							DMUrole	=	tc_strtok(NULL,"/");
							DMUDisuser	=	tc_strtok(NULL,"(");
							DMUcuserid	=	tc_strtok(NULL,")");
							printf("\n TASK: DMU plant: [%s] role: [%s] :user %s:  current user : %s",DMUplantname,DMUrole,DMUDisuser,DMUcuserid);fflush(stdout);*/
							
						}
						else{
						
							printf("\n NO TASK: DMUreviewer is found \n");fflush(stdout);
							fflush(stdout);
						}
					}
				}
			}

		}
		
		
		printf("\n\n\t\t mbom Assigned  CurrentDMUReviewGrp Group : %s\n",CurrentDMUReviewGrp);fflush(stdout);

		printf("\n TASK: DMUreviewer  plant: [%s] role: [%s] :user %s:  current user : %s",DMUplantname,DMUrole,DMUDisuser,DMUcuserid);fflush(stdout);
		printf("\n TASK: Change Specialist 1DMU plant: [%s] role: [%s] :user %s:  current user : %s",Changesplantname,ChangeSpl_role,ChangeSplDisuser,ChangeSpl_cuserid);fflush(stdout);
		fflush(stdout);
							
		ITKCALL(AOM_ask_value_string(list_of_cntrl_tags[0],"t5_Userinfo2",&Userinfo2)); 

		printf("\n\n\t\t mbom Assigned  list_of_cntrl_tags : %s \n",Userinfo2 );fflush(stdout);

		
		//venkat end
		
		CALLAPI( TCTYPE_find_type( "Analyst", "Analyst", &AnalystTag));

		if(TCTYPE_ask_name2(AnalystTag,&type_name));

		printf("\n APL Task: Name is : %s \n", type_name);fflush(stdout);

		CALLAPI(PARTICIPANT_ask_participants(DMLTag,AnalystTag,&oldusrcount,&OldParticipantRel));

		CALLAPI(PARTICIPANT_remove_participants(DMLTag,oldusrcount,OldParticipantRel));

		printf("\n Test 1111 \n");fflush(stdout);
		
		CALLAPI(SA_ask_current_groupmember(&current_member));
		TCTYPE_find_type("Analyst", "Analyst", &new_participant_type);
		CALLAPI(EPM_create_participant(current_member, new_participant_type, &new_participant_tag));
		
		printf("\n Test 2222 \n");fflush(stdout);
		int n_participant_types = 1;
		tag_t participant_types[1] = {new_participant_tag};
		printf("\n Test 3333 \n");fflush(stdout);
		//CALLAPI(ITEM_rev_set_participants(DMLTag,n_participant_types,participant_types));
		CALLAPI(PARTICIPANT_set_participants(DMLTag,true,n_participant_types,participant_types));
		printf("\n Test ended 4444 \n");fflush(stdout);
		
		// Added for Project Code // 
		tag_t	DML_tag		= NULLTAG;
		tag_t	DML_rev_tag = NULLTAG;

		printf("\n DML_no => [%s]\n",DML_no);
		tc_strcat(DML_no,"_MBOM");
		printf("\n Final MBOM DML_no => [%s]\n",DML_no);
		CALLAPI(ITEM_find_item (DML_no, &DML_tag));

		if(DML_tag != NULLTAG )
		{
			CALLAPI(ITEM_ask_latest_rev(DML_tag,&DML_rev_tag));
			AOM_ask_value_string( DML_rev_tag, "t5_cprojectcode", &Proj_Code);
			printf("\n MBOM DML Proj_Code => [%s]\n",Proj_Code);
		}
		// Ended
		
		printf("\n MBOM ChangeSpl_role and Userinfo2 => [%s] : %s\n",ChangeSpl_role,Userinfo2);fflush(stdout); 

		if (tc_strstr(ChangeSpl_role,Userinfo2)!= NULL ) //control object based created
		{
			printf("\n ketan code calling MBOM DML Proj_Code => [%s]\n",Proj_Code);fflush(stdout);
		
			CALLAPI(AssignMBOMReviewer(DMLTag, Proj_Code)); //dmu reviewer
			CALLAPI(AssignMBOMManagerReview(DMLTag, Proj_Code)); //changespecialst
		}
		else
		{
			printf("\n venkat DMU Reviewer and manager is calling item id :%s :%s\n",item_id,ERC_MBOMReleaseType);fflush(stdout);

			if( (tc_strcmp(ERC_MBOMReleaseType, "Veh") == 0)||(tc_strstr(item_id, "MB_") != NULL)||(tc_strstr(item_id, "MM_")!= NULL))
			{
				printf("\n venkat DMU Reviewer and manager is calling item id111111111 :%s :%s\n",item_id,ERC_MBOMReleaseType);fflush(stdout);
				
				//CALLAPI(DefaultAssignMBOMReviewer(DMLTag, DMUplantname,DMUrole,DMUcuserid));//T5_DMUReviewer
				//CALLAPI(DefaultAssignMBOMManagerReview(DMLTag, Changesplantname,ChangeSpl_role,ChangeSpl_cuserid));//ChangeSpecialist1

				CALLAPI(DefaultAssignMBOMReviewer(DMLTag,CurrentDMUReviewGrp, dmuCnt));//T5_DMUReviewer
				CALLAPI(DefaultAssignMBOMManagerReview(DMLTag, CurrentChangSplGrp,chngSplCnt));//ChangeSpecialist1
			}
			else
			{
			
				printf("\n venkat DMU Reviewer and manager is calling item id22222222222 :%s :%s\n",item_id,ERC_MBOMReleaseType);fflush(stdout);
				//CALLAPI(DefaultAssignMBOMManagerReview(DMLTag, Changesplantname,ChangeSpl_role,ChangeSpl_cuserid));//ChangeSpecialist1
				CALLAPI(DefaultAssignMBOMManagerReview(DMLTag, CurrentChangSplGrp,chngSplCnt));//ChangeSpecialist1

			}
		}

	}

	// Ketan Ended 
	

	}
	if(strcmp(type_name,"T5_MBOMTASKRevision")==0 || strcmp(CurrentTask,"Please Review The Changes Done By MBOM Planner")==0)
	{
		/********************** Gss 2.49 For Generating 35-36 Parts at reviewer Claim of APL Reviewer *****************/
		/********************** This need to  be implemented if required now it is moved to ERC *****************/
	}
	else
	{
	  	printf("\n No proper class class T5_MBOMDMLRevision......\n");fflush(stdout);
	}

	return error_code;
}

//added by sanjay

void Multi_Get_Part_BOM_Lvl_Unconfigured(tag_t inputPart,int reqLevel,int level,tag_t closure_tag,tag_t revRule,char ViewBVR[100],struct BomChldStrut BomChldStrut[],int* StructChldCnt)
{
	int ifail;
    int iChildItemTag=0;
	char * ItemName ;
	int k=0;
    int n=0;
    int assbvr=0;
    int flagBVR=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	tag_t	window 				= NULLTAG;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t	top_line			= NULLTAG;
	int bvrfound=0;
	tag_t  *children=NULLTAG;
	char* partNumber 	= NULL;

	printf("\n Inside Multi_Get_Part_BOM_Lvl[%d] of Unconfigured...\n",*StructChldCnt);

	ITKCALL(AOM_ask_value_string(inputPart,"item_id",&partNumber));
	printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	printf("\n ViewBVR=>[%s] ...\n",ViewBVR);

	if( level >= reqLevel )
	{
		goto CLEANUP;
	}

	ITKCALL(ITEM_rev_list_bom_view_revs(inputPart, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);

	if(n_values_bvr==0)
	{
		flagBVR=0;
	}
	else if(n_values_bvr>0)
	{
		printf("\n BVR found");fflush(stdout);
		for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{
				//if(tc_strcmp(viewTok,"View")==0)
				if(tc_strcmp(viewTok,ViewBVR)==0)
				{
					flagBVR=1;
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}
		if(flagBVR!=1)
		{
			for(assbvr=0;assbvr<n_values_bvr;assbvr++)
			{
				ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
				printf("\n view_name %s",view_name);fflush(stdout);
				partTok = strtok (view_name,"-");
				viewTok = strtok (NULL,"-");
				printf("\n viewTok %s",viewTok);fflush(stdout);
				if(strlen(viewTok)>0)
				{
					//if(tc_strcmp(viewTok,ViewBVR)==0)
					if(tc_strcmp(viewTok,"View")==0)
					{
						flagBVR=1;
						bvr_tag=bvr_assy_part[assbvr];
						break;
					}
				}
			}
		}

	}
	printf("\n flagBVR=>[%d] ",flagBVR);fflush(stdout);

	ITKCALL(BOM_create_window (&window));
	ITKCALL(BOM_set_window_config_rule(window,revRule));
	ITKCALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
	//ITKCALL(BOM_set_window_pack_all (window, true));
	if(flagBVR==1)
	{
		BOM_set_window_top_line(window, null_tag,inputPart ,bvr_tag, &top_line);
		ITKCALL(BOM_line_ask_child_lines (top_line, &n, &children));
		printf("\n\n\t\t No of child objects are n : %d\n",n);fflush(stdout);

		level = level + 1;
		for (k = 0; k < n; k++)
		{
			BOM_line_unpack (children[k]);
			//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);  //API Change

			//Changes made by Palash
			char *unconfigStat,*childQty;
			printf("Inside new segment - Palash");
			AOM_UIF_ask_value(children[k],"bl_config_string",&unconfigStat); // Added by Palash
			AOM_ask_value_string(children[k],"bl_quantity",&childQty);
			tag_t unconfiguredPart,unconfiguredPartLatest;
			if(tc_strcmp(unconfigStat,"No configured Revision")==0 && tc_strcmp(childQty,"0")!=0)
			{
				char* itemID;
				AOM_ask_value_string(children[k],"bl_item_item_id",&itemID);
				printf("Palash - bl_item_item_id - %s",itemID);
				ITEM_find_item(itemID,&unconfiguredPart);
				ITEM_ask_latest_rev(unconfiguredPart,&t_ChildItemRev);
			}
			else // Palash Code ends
				//BOM_line_ask_attribute_tag(children[k], iChildItemTag, &t_ChildItemRev); //API Change
				AOM_ask_value_tag(children[k],bomAttr_lineItemRevTag, &t_ChildItemRev);

			if(t_ChildItemRev!=NULLTAG)
			{
				AOM_ask_value_string(t_ChildItemRev,"item_id",&ItemName);
				*StructChldCnt	=	*StructChldCnt+1;
				//get_BomChldStrut[*StructChldCnt].child_objs = childrenTag[k]; Hemal
				BomChldStrut[*StructChldCnt].child_objs = t_ChildItemRev;
				BomChldStrut[*StructChldCnt].child_objs_bvr=children[k];
				BomChldStrut[*StructChldCnt].child_objs_lvl=level;

				Multi_Get_Part_BOM_Lvl_Unconfigured(t_ChildItemRev,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrut,StructChldCnt);
			}
		}
		level = level - 1;
	}

	MEM_free (childrenTag);

	CLEANUP:
		 printf("\n Inside Multi_Get_Part_BOM_Lvl Unvonfigured CLEANUP");fflush(stdout);
}
//Added by sanjay
int Get_Part_BOM_Lvl_Unconfigured(tag_t VehicleObj,int reqLevel,char*  closureRuleName,char*  revRuleName,char* ViewBVR,struct BomChldStrut BomChldStrut[] ,int* StructChldCnt)
{
	int   ifail				= 0;

	tag_t revRule 			= NULLTAG;
	char* vehicleNumber 	= NULL;
	int j					= 0;
	PIE_scope_t scope;
	int 	n_closure_tags;
	tag_t * 	closure_tags;
	tag_t  	closure_tag;
	int k1=0;
	int n=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	int level 				= 0;
	tag_t	window 				= NULLTAG;
	tag_t	top_line			= NULLTAG;
	tag_t	objChild			= NULLTAG;
	tag_t	objChild_bvr			= NULLTAG;
	int child_lvl=0;
	char	*c_Qty						=	NULL;
	tag_t  *children1=NULLTAG;
	int iChildItemTag=0;
	int assbvr=0;
	int bvrfound=0;
	int flagRevRule=0;
	int flagClosureRule=0;
	char *view_name=NULL;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t   t_ChildItemRev;
	char * ItemName ;

	printf("\nInside Get_Part_BOM_Lvl Unconfigured ....\n");

	if(VehicleObj == NULLTAG)
	{
		printf("\n VehicleObj is NULLTAG\n");fflush(stdout);
		return ifail;
	}
	CALLAPI(AOM_ask_value_string(VehicleObj,"item_id",&vehicleNumber));
	printf("\n Part number===>%s\n",vehicleNumber);fflush(stdout);

	printf("\nBefore Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);
	printf("\nBefore reqLevel==>%d\n",reqLevel);fflush(stdout);
	printf("\nBefore level==>%d\n",level);fflush(stdout);
	printf("\nclosureRuleName==>%s\n",closureRuleName);fflush(stdout);
	printf("\nrevRuleName==>%s\n",revRuleName);fflush(stdout);
	printf("\nViewBVR==>%s\n",ViewBVR);fflush(stdout);

	ITKCALL(ITEM_rev_list_bom_view_revs(VehicleObj, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);
	
	
	if(n_values_bvr>0)
	{
		
		//VIEW BVR Chnages done by Manindra as suggested by Manish 
		printf("\n BVR found");fflush(stdout);
		
		ITKCALL(AOM_ask_value_string(bvr_assy_part[0],"object_name",&view_name));
		printf("\n view_name %s",view_name);fflush(stdout);
		partTok = strtok (view_name,"-");
		viewTok = strtok (NULL,"-");
		printf("\n viewTok %s",viewTok);fflush(stdout);
		ViewBVR = (char *)MEM_alloc(100);
		tc_strcpy(ViewBVR,viewTok);
		printf("\n Pass View as %s",ViewBVR);fflush(stdout);
		bvrfound=1;
		//bvr_tag=bvr_assy_part[0];
		/* for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{
				if(tc_strcmp(viewTok,ViewBVR)==0)
				{
					bvrfound++;
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}
		//Added by Hemal, same need to check and add in common file also.
		if(bvrfound!=1)
		{
			for(assbvr=0;assbvr<n_values_bvr;assbvr++)
			{
				ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
				printf("\n view_name %s",view_name);fflush(stdout);
				partTok = strtok (view_name,"-");
				viewTok = strtok (NULL,"-");
				printf("\n viewTok %s",viewTok);fflush(stdout);
				if(strlen(viewTok)>0)
				{
					//if(tc_strcmp(viewTok,ViewBVR)==0)
					if(tc_strcmp(viewTok,"View")==0)
					{
						bvrfound=1;
						bvr_tag=bvr_assy_part[assbvr];
						break;
					}
				}
			}
		} */
		//Ended by Hemal

	}

	printf("\n bvrfound=>[%d] ",bvrfound);fflush(stdout);
	if(bvrfound==0)
	{
		printf("\n**********BVR NOT Exist*********\n");fflush(stdout);
	}
	else
	{
		CALLAPI(CFM_find(revRuleName, &revRule));
		if (revRule != NULLTAG)
		{
			printf("\nFind revRule\n");fflush(stdout);
			flagRevRule=1;
		}

		scope=PIE_TEAMCENTER;
		CALLAPI(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
		printf("\n n_closure_tags:%d ..............",n_closure_tags);fflush(stdout);
		if(n_closure_tags==1)
		{
			closure_tag=closure_tags[0];
			flagClosureRule=1;
		}
		printf("\n flagClosureRule=>[%d] ",flagClosureRule);fflush(stdout);
		printf("\n flagRevRule=>[%d] ",flagRevRule);fflush(stdout);
		if((flagClosureRule==1) && (flagRevRule==1))
		{

			Multi_Get_Part_BOM_Lvl_Unconfigured(VehicleObj,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrut,StructChldCnt);
		}
		else
		{
			printf("\n******Revision or Closure Rule Not Found******\n");fflush(stdout);
		}

	}
	printf("\nAfter Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);

	for (j=1;j<= *StructChldCnt;j++ )
	{
		objChild		= NULLTAG;
		objChild_bvr	= NULLTAG;
		c_Qty			= NULL;
		child_lvl       =0;

		printf("\nPrint Item ID==>%d\n",j);fflush(stdout);

		objChild=BomChldStrut[j].child_objs;
		objChild_bvr=BomChldStrut[j].child_objs_bvr;
		child_lvl=BomChldStrut[j].child_objs_lvl;

		AOM_ask_value_string(objChild,"item_id",&ItemName);
		printf("\nItemName==>%s\n",ItemName);fflush(stdout);

		printf("\nchild_lvl==>%d\n",child_lvl);fflush(stdout);

		AOM_ask_value_string(objChild_bvr,"bl_quantity",&c_Qty);
		printf("\nQty==>%s\n",c_Qty);fflush(stdout);

	}
	return ifail;
}







//Start Code to Explode BOM -3
void Multi_Get_Part_BOM_Lvl(tag_t inputPart,int reqLevel,int level,tag_t closure_tag,tag_t revRule,char ViewBVR[100],struct BomChldStrut BomChldStrut[],int* StructChldCnt)
{
	int ifail;
    int iChildItemTag=0;
	char * ItemName ;
	int k=0;
    int n=0;
    int assbvr=0;
    int flagBVR=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	tag_t	window 				= NULLTAG;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t	top_line			= NULLTAG;
	int bvrfound=0;
	tag_t  *children=NULLTAG;
	char* partNumber 	= NULL;

	printf("\n Inside Multi_Get_Part_BOM_Lvl[%d] ...\n",*StructChldCnt);

	ITKCALL(AOM_ask_value_string(inputPart,"item_id",&partNumber));
	printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	printf("\n ViewBVR=>[%s] ...\n",ViewBVR);

	if( level >= reqLevel )
	{
		goto CLEANUP;
	}

	ITKCALL(ITEM_rev_list_bom_view_revs(inputPart, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);

	if(n_values_bvr==0)
	{
		flagBVR=0;
	}
	else if(n_values_bvr>0)
	{
		printf("\n BVR found");fflush(stdout);
		for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{
				//if(tc_strcmp(viewTok,"View")==0)
				if(tc_strcmp(viewTok,ViewBVR)==0)
				{
					flagBVR=1;
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}
		if(flagBVR!=1)
		{
			for(assbvr=0;assbvr<n_values_bvr;assbvr++)
			{
				ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
				printf("\n view_name %s",view_name);fflush(stdout);
				partTok = strtok (view_name,"-");
				viewTok = strtok (NULL,"-");
				printf("\n viewTok %s",viewTok);fflush(stdout);
				if(strlen(viewTok)>0)
				{
					//if(tc_strcmp(viewTok,ViewBVR)==0)
					if(tc_strcmp(viewTok,"View")==0)
					{
						flagBVR=1;
						bvr_tag=bvr_assy_part[assbvr];
						break;
					}
				}
			}
		}

	}
	printf("\n flagBVR=>[%d] ",flagBVR);fflush(stdout);

	ITKCALL(BOM_create_window (&window));
	ITKCALL(BOM_set_window_config_rule(window,revRule));
	ITKCALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
	//ITKCALL(BOM_set_window_pack_all (window, true));
	if(flagBVR==1)
	{
		BOM_set_window_top_line(window, null_tag,inputPart ,bvr_tag, &top_line);
		ITKCALL(BOM_line_ask_child_lines (top_line, &n, &children));
		printf("\n No of child objects are n : %d\n",n);fflush(stdout);

		level = level + 1;
		for (k = 0; k < n; k++)
		{
			BOM_line_unpack (children[k]);
			//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
			//BOM_line_ask_attribute_tag(children[k], iChildItemTag, &t_ChildItemRev);
			//AOM_ask_value_tag (children[k],"bl_line_object", &t_ChildItemRev);
			AOM_ask_value_tag (children[k],bomAttr_lineItemRevTag, &t_ChildItemRev);
			if(t_ChildItemRev!=NULLTAG)
			{
				AOM_ask_value_string(t_ChildItemRev,"item_id",&ItemName);
				*StructChldCnt	=	*StructChldCnt+1;
				//get_BomChldStrut[*StructChldCnt].child_objs = childrenTag[k]; Hemal
				BomChldStrut[*StructChldCnt].child_objs = t_ChildItemRev;
				BomChldStrut[*StructChldCnt].child_objs_bvr=children[k];
				BomChldStrut[*StructChldCnt].child_objs_lvl=level;

				Multi_Get_Part_BOM_Lvl(t_ChildItemRev,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrut,StructChldCnt);
			}
		}
		level = level - 1;
	}

	MEM_free (childrenTag);

	CLEANUP:
		 printf("\n Inside Multi_Get_Part_BOM_Lvl CLEANUP");fflush(stdout);
}
int Get_Part_BOM_Lvl(tag_t VehicleObj,int reqLevel,char*  closureRuleName,char*  revRuleName,char* ViewBVR,struct BomChldStrut BomChldStrut[] ,int* StructChldCnt)
{
	int   ifail				= 0;

	tag_t revRule 			= NULLTAG;
	char* vehicleNumber 	= NULL;
	int j					= 0;
	PIE_scope_t scope;
	int 	n_closure_tags;
	tag_t * 	closure_tags;
	tag_t  	closure_tag;
	int k1=0;
	int n=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	int level 				= 0;
	tag_t	window 				= NULLTAG;
	tag_t	top_line			= NULLTAG;
	tag_t	objChild			= NULLTAG;
	tag_t	objChild_bvr			= NULLTAG;
	int child_lvl=0;
	char	*c_Qty						=	NULL;
	tag_t  *children1=NULLTAG;
	int iChildItemTag=0;
	int assbvr=0;
	int bvrfound=0;
	int flagRevRule=0;
	int flagClosureRule=0;
	char *view_name=NULL;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t   t_ChildItemRev;
	char * ItemName ;

	printf("\nInside Get_Part_BOM_Lvl ....\n");

	if(VehicleObj == NULLTAG)
	{
		printf("\n VehicleObj is NULLTAG\n");fflush(stdout);
		return ifail;
	}
	CALLAPI(AOM_ask_value_string(VehicleObj,"item_id",&vehicleNumber));
	printf("\n Part number===>%s\n",vehicleNumber);fflush(stdout);

	printf("\nBefore Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);
	printf("\nBefore reqLevel==>%d\n",reqLevel);fflush(stdout);
	printf("\nBefore level==>%d\n",level);fflush(stdout);
	printf("\nclosureRuleName==>%s\n",closureRuleName);fflush(stdout);
	printf("\nrevRuleName==>%s\n",revRuleName);fflush(stdout);
	printf("\nViewBVR==>%s\n",ViewBVR);fflush(stdout);

	ITKCALL(ITEM_rev_list_bom_view_revs(VehicleObj, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);
	if(n_values_bvr>0)
	{
		printf("\n BVR found");fflush(stdout);
		for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{
				if(tc_strcmp(viewTok,ViewBVR)==0)
				{
					bvrfound++;
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}

	}

	printf("\n bvrfound=>[%d] ",bvrfound);fflush(stdout);
	if(bvrfound==0)
	{
		printf("\n**********BVR NOT Exist*********\n");fflush(stdout);
	}
	else
	{
		CALLAPI(CFM_find(revRuleName, &revRule));
		if (revRule != NULLTAG)
		{
			printf("\nFind revRule\n");fflush(stdout);
			flagRevRule=1;
		}

		scope=PIE_TEAMCENTER;
		CALLAPI(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
		printf("\n n_closure_tags:%d ..............",n_closure_tags);fflush(stdout);
		if(n_closure_tags==1)
		{
			closure_tag=closure_tags[0];
			flagClosureRule=1;
		}
		printf("\n flagClosureRule=>[%d] ",flagClosureRule);fflush(stdout);
		printf("\n flagRevRule=>[%d] ",flagRevRule);fflush(stdout);
		if((flagClosureRule==1) && (flagRevRule==1))
		{

			Multi_Get_Part_BOM_Lvl(VehicleObj,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrut,StructChldCnt);
		}
		else
		{
			printf("\n******Revision or Closure Rule Not Found******\n");fflush(stdout);
		}

	}
	printf("\nAfter Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);

	for (j=1;j<= *StructChldCnt;j++ )
	{
		objChild		= NULLTAG;
		objChild_bvr	= NULLTAG;
		c_Qty			= NULL;
		child_lvl       =0;

		printf("\nPrint Item ID==>%d\n",j);fflush(stdout);

		objChild=BomChldStrut[j].child_objs;
		objChild_bvr=BomChldStrut[j].child_objs_bvr;
		child_lvl=BomChldStrut[j].child_objs_lvl;

		AOM_ask_value_string(objChild,"item_id",&ItemName);
		printf("\nItemName==>%s\n",ItemName);fflush(stdout);

		printf("\nchild_lvl==>%d\n",child_lvl);fflush(stdout);

		AOM_ask_value_string(objChild_bvr,"bl_quantity",&c_Qty);
		printf("\nQty==>%s\n",c_Qty);fflush(stdout);

	}
	return ifail;
}

/*************pp*******************/
int  GetCorrectDRMBOM( char* FromPlnt ,char*  Part_revStat_Id)
{
	int Flag_dr =0;
																	if((tc_strcmp(FromPlnt,"DR0")==0)|| (tc_strcmp(FromPlnt,"AR0")==0))
																	{
																		 printf("\n 1111AA \n");fflush(stdout);
																		if((tc_strcmp(Part_revStat_Id,"DR1")==0) ||(tc_strcmp(Part_revStat_Id,"DR2")==0)||(tc_strcmp(Part_revStat_Id,"DR3")==0)||(tc_strcmp(Part_revStat_Id,"DR3P")==0)||(tc_strcmp(Part_revStat_Id,"DR4")==0)||(tc_strcmp(Part_revStat_Id,"DR5")==0)||(tc_strcmp(Part_revStat_Id,"AR1")==0) ||(tc_strcmp(Part_revStat_Id,"AR2")==0)||(tc_strcmp(Part_revStat_Id,"AR3")==0)||(tc_strcmp(Part_revStat_Id,"AR3P")==0)||(tc_strcmp(Part_revStat_Id,"AR4")==0)||(tc_strcmp(Part_revStat_Id,"AR5")==0))
																		{
																			
																			printf("\n 1111 \n");fflush(stdout);
																			Flag_dr++;
																			
																		}

																	}
																	else if((tc_strcmp(FromPlnt,"DR1")==0)|| (tc_strcmp(FromPlnt,"AR1")==0))
																	{
																		printf("\n 1111AABB \n");fflush(stdout);
																		if((tc_strcmp(Part_revStat_Id,"DR2")==0)||(tc_strcmp(Part_revStat_Id,"DR3")==0)||(tc_strcmp(Part_revStat_Id,"DR3P")==0)||(tc_strcmp(Part_revStat_Id,"DR4")==0)||(tc_strcmp(Part_revStat_Id,"DR5")==0) ||(tc_strcmp(Part_revStat_Id,"AR2")==0)||(tc_strcmp(Part_revStat_Id,"AR3")==0)||(tc_strcmp(Part_revStat_Id,"AR3P")==0)||(tc_strcmp(Part_revStat_Id,"AR4")==0)||(tc_strcmp(Part_revStat_Id,"AR5")==0))
																		{
																		   
																			printf("\n 2222222 \n");fflush(stdout);
																			 Flag_dr++;
																			

																		}

																	}
																	else if((tc_strcmp(FromPlnt,"DR2")==0)|| (tc_strcmp(FromPlnt,"AR2")==0))
																	{
																		printf("\n 1111AABBCC \n");fflush(stdout);
																		if((tc_strcmp(Part_revStat_Id,"DR3")==0)||(tc_strcmp(Part_revStat_Id,"DR3P")==0)||(tc_strcmp(Part_revStat_Id,"DR4")==0)||(tc_strcmp(Part_revStat_Id,"DR5")==0)||(tc_strcmp(Part_revStat_Id,"AR3")==0)||(tc_strcmp(Part_revStat_Id,"AR3P")==0)||(tc_strcmp(Part_revStat_Id,"AR4")==0)||(tc_strcmp(Part_revStat_Id,"AR5")==0))
																		{
																			
																			printf("\n 33333330 \n");fflush(stdout);
																			Flag_dr++;
																			

																		}

																	}
																	else if((tc_strcmp(FromPlnt,"DR3")==0)|| (tc_strcmp(FromPlnt,"AR3")==0))
																	{
																		printf("\n 1111AABBCCDD\n");fflush(stdout);
																		if((tc_strcmp(Part_revStat_Id,"DR3P")==0)||(tc_strcmp(Part_revStat_Id,"DR4")==0)||(tc_strcmp(Part_revStat_Id,"DR5")==0)||(tc_strcmp(Part_revStat_Id,"AR3P")==0)||(tc_strcmp(Part_revStat_Id,"AR4")==0)||(tc_strcmp(Part_revStat_Id,"AR5")==0))
																		{
																			
																			printf("\n 4444 \n");fflush(stdout);
																			Flag_dr++;
																			

																		}

																	}
																	else if((tc_strcmp(FromPlnt,"DR3P")==0)|| (tc_strcmp(FromPlnt,"AR3P")==0))
																	{
																		printf("\n 1111AABBCCDDEE\n");fflush(stdout);
																		if((tc_strcmp(Part_revStat_Id,"DR4")==0)||(tc_strcmp(Part_revStat_Id,"DR5")==0)||(tc_strcmp(Part_revStat_Id,"AR4")==0)||(tc_strcmp(Part_revStat_Id,"AR5")==0))
																		{
																			
																			printf("\n 66666 \n");fflush(stdout);
																			Flag_dr++;
																			
																		}

																	}

																	else if((tc_strcmp(FromPlnt,"DR4")==0)|| (tc_strcmp(FromPlnt,"AR4")==0))
																	{
																		printf("\n 1111AABBCCDDEEFF\n");fflush(stdout);
																		if((tc_strcmp(Part_revStat_Id,"DR5")==0)||(tc_strcmp(Part_revStat_Id,"AR5")==0))
																		{
																			printf("\n 777 \n");fflush(stdout);
																			Flag_dr++;
																			
																		}

																	}
																	else
																	{
																		printf("\n 1111AABBCCDDEEFFGG\n");fflush(stdout);
																		printf("\n 88888888888888 \n");fflush(stdout);
																		

																	}
																	if(Flag_dr ==1)
																	{
																		return 1;
																	}
																	else{
																		return 0;
																	}
}
/***************pp**********/

void Multi_Get_Part_BOM_Lvl_Impl(tag_t inputPart,int reqLevel,int level,tag_t closure_tag,tag_t revRule,char ViewBVR[100],struct BomChldStrut_Impl BomChldStrutImpl[],int* StructParentCnt)
{
	int ifail;
    int iChildItemTag=0;
	char * ItemName ;
	char * childItemName ;
	int k=0;
    int n=0;
    int assbvr=0;
    int flagBVR=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	char *ParetnName=NULL;
	tag_t	window 				= NULLTAG;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t	top_line			= NULLTAG;
	int bvrfound=0;
	tag_t  *children=NULLTAG;
	char* partNumber 	= NULL;
	int  	n_parents=0;
	int  	jp=0;
	int * 	levels;
	tag_t * 	parents	 =NULLTAG;
	tag_t 	parents_tag	 =NULLTAG;

	printf("\n Inside Multi_Get_Part_BOM_Lvl_Impl[%d] ...\n",*StructParentCnt);

	ITKCALL(AOM_ask_value_string(inputPart,"item_id",&partNumber));
	printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	printf("\n ViewBVR=>[%s] ...\n",ViewBVR);

	if( level >= reqLevel )
	{
		goto CLEANUP;
	}
	ITKCALL(PS_where_used_configured(inputPart,revRule,1,&n_parents,&levels,&parents));
	printf("\n No of Assy objects are n_parents : %d\n",n_parents);fflush(stdout);

	level = level + 1;
	if(n_parents>0)
	{
		for(jp=0;jp<n_parents;jp++)
		{
			parents_tag=parents[jp];
			ITKCALL(AOM_ask_value_string(parents_tag,"item_id",&ParetnName));
			printf("\n Fparents %s",ParetnName);fflush(stdout);
			if(parents_tag!=NULLTAG)
			{
				ITKCALL(ITEM_rev_list_bom_view_revs(parents_tag, &n_values_bvr, &bvr_assy_part));
				printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);

				if(n_values_bvr==0)
				{
					flagBVR=0;
				}
				else if(n_values_bvr>0)
				{
					printf("\n BVR found");fflush(stdout);
					for(assbvr=0;assbvr<n_values_bvr;assbvr++)
					{
						ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
						printf("\n view_name %s",view_name);fflush(stdout);
						partTok = strtok (view_name,"-");
						viewTok = strtok (NULL,"-");
						printf("\n viewTok %s",viewTok);fflush(stdout);
						if(strlen(viewTok)>0)
						{
							//if(tc_strcmp(viewTok,"View")==0)
							if(tc_strcmp(viewTok,ViewBVR)==0)
							{
								flagBVR=1;
								bvr_tag=bvr_assy_part[assbvr];
								break;
							}
						}
					}
					if(flagBVR!=1)
					{
						for(assbvr=0;assbvr<n_values_bvr;assbvr++)
						{
							ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
							printf("\n view_name %s",view_name);fflush(stdout);
							partTok = strtok (view_name,"-");
							viewTok = strtok (NULL,"-");
							printf("\n viewTok %s",viewTok);fflush(stdout);
							if(strlen(viewTok)>0)
							{
								//if(tc_strcmp(viewTok,ViewBVR)==0)
								if(tc_strcmp(viewTok,"View")==0)
								{
									flagBVR=1;
									bvr_tag=bvr_assy_part[assbvr];
									break;
								}
							}
						}
					}

				}
				printf("\n flagBVR=>[%d] ",flagBVR);fflush(stdout);

				ITKCALL(BOM_create_window (&window));
				ITKCALL(BOM_set_window_config_rule(window,revRule));
				ITKCALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));

				if(flagBVR==1)
				{
					BOM_set_window_top_line(window, null_tag,parents_tag ,bvr_tag, &top_line);
					ITKCALL(BOM_line_ask_child_lines (top_line, &n, &children));
					printf("\n No of child objects are n : %d\n",n);fflush(stdout);

					for (k = 0; k < n; k++)
					{
						BOM_line_unpack (children[k]);
						//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
						//BOM_line_ask_attribute_tag(children[k], iChildItemTag, &t_ChildItemRev);
						//AOM_ask_value_tag (children[k],"bl_line_object", &t_ChildItemRev);
						AOM_ask_value_tag (children[k],bomAttr_lineItemRevTag, &t_ChildItemRev);
						if(t_ChildItemRev!=NULLTAG)
						{
							AOM_ask_value_string(t_ChildItemRev,"item_id",&childItemName);
							printf("\n ChildPrtNumP=>[%s] ",childItemName);fflush(stdout);
							printf("\n PrtNumM=>[%s] ",partNumber);fflush(stdout);

							if(strcmp(childItemName,partNumber)==0)
							{
								printf("\n*******INSIDE SAME FOUND*****\n");fflush(stdout);
								*StructParentCnt	=	*StructParentCnt+1;
								BomChldStrutImpl[*StructParentCnt].parent_objs = parents_tag;
								BomChldStrutImpl[*StructParentCnt].parent_objs_bvr=children[k];
								BomChldStrutImpl[*StructParentCnt].parent_objs_lvl=level;
								break;
							}
						}
					}
				}
				Multi_Get_Part_BOM_Lvl_Impl(parents_tag,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrutImpl,StructParentCnt);

			}//ParentRev Not-NULL

		}
	}
	level = level - 1;
	CLEANUP:
		 printf("\n Inside Multi_Get_Part_BOM_Lvl_Impl CLEANUP");fflush(stdout);
}
int Get_Part_BOM_Lvl_Impl(tag_t partObj,int reqLevel,char*  closureRuleName,char*  revRuleName,char* ViewBVR,struct BomChldStrut_Impl BomChldStrutImpl[] ,int* StructParentCnt)
{
	int   ifail				= 0;

	tag_t revRule 			= NULLTAG;
	char* prtNumber 	= NULL;
	int j					= 0;
	PIE_scope_t scope;
	int 	n_closure_tags;
	tag_t * 	closure_tags;
	tag_t  	closure_tag;
	int level 				= 0;
	tag_t	objParent			= NULLTAG;
	tag_t	objParent_bvr			= NULLTAG;
	int Parent_lvl=0;
	char	*c_Qty						=	NULL;
	int flagRevRule=0;
	int flagClosureRule=0;
	char * ItemName ;

	printf("\nInside Get_Part_BOM_Lvl_Impl ....\n");

	if(partObj == NULLTAG)
	{
		printf("\n partObj is NULLTAG\n");fflush(stdout);
		return ifail;
	}
	CALLAPI(AOM_ask_value_string(partObj,"item_id",&prtNumber));
	printf("\n Part number===>%s\n",prtNumber);fflush(stdout);

	printf("\nBefore Size of StructParentCnt==>%d\n",*StructParentCnt);fflush(stdout);
	printf("\nBefore reqLevel==>%d\n",reqLevel);fflush(stdout);
	printf("\nBefore level==>%d\n",level);fflush(stdout);
	printf("\nclosureRuleName==>%s\n",closureRuleName);fflush(stdout);
	printf("\nrevRuleName==>%s\n",revRuleName);fflush(stdout);
	printf("\nViewBVR==>%s\n",ViewBVR);fflush(stdout);



	CALLAPI(CFM_find(revRuleName, &revRule));
	if (revRule != NULLTAG)
	{
		printf("\nFind revRule\n");fflush(stdout);
		flagRevRule=1;
	}

	scope=PIE_TEAMCENTER;
	CALLAPI(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
	printf("\n n_closure_tags:%d ..............",n_closure_tags);fflush(stdout);
	if(n_closure_tags==1)
	{
		closure_tag=closure_tags[0];
		flagClosureRule=1;
	}
	printf("\n flagClosureRule=>[%d] ",flagClosureRule);fflush(stdout);
	printf("\n flagRevRule=>[%d] ",flagRevRule);fflush(stdout);
	if((flagClosureRule==1) && (flagRevRule==1))
	{

		Multi_Get_Part_BOM_Lvl_Impl(partObj,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrutImpl,StructParentCnt);
	}
	else
	{
		printf("\n******Revision or Closure Rule Not Found******\n");fflush(stdout);
	}

	printf("\nAfter Size of StructParentCnt==>%d\n",*StructParentCnt);fflush(stdout);

	for (j=1;j<= *StructParentCnt;j++ )
	{
		objParent		= NULLTAG;
		objParent_bvr	= NULLTAG;
		c_Qty			= NULL;
		Parent_lvl       =0;

		printf("\nPrint Item ID==>%d\n",j);fflush(stdout);

		objParent=BomChldStrutImpl[j].parent_objs;
		objParent_bvr=BomChldStrutImpl[j].parent_objs_bvr;
		Parent_lvl=BomChldStrutImpl[j].parent_objs_lvl;

		AOM_ask_value_string(objParent,"item_id",&ItemName);
		printf("\nItemName==>%s\n",ItemName);fflush(stdout);

		printf("\nParent_lvl==>%d\n",Parent_lvl);fflush(stdout);

		AOM_ask_value_string(objParent_bvr,"bl_quantity",&c_Qty);
		printf("\nQty==>%s\n",c_Qty);fflush(stdout);

	}
	return ifail;
}
//End Code to Explode BOM -3

int mbom_epm_assign_participant( EPM_action_message_t msg )
{
	int ifail = ITK_ok;

	tag_t resourcePool = NULLTAG;
    tag_t tRootTask = NULLTAG;
    CALLAPI(EPM_ask_root_task(msg.task, &tRootTask));
 
	int no;
	tag_t *tSignoffs;
	tag_t *members;
	tag_t tTask = msg.task;
	int n=0;
	int i;
	char *role=NULL;
	char *group=NULL;
	char *pcArgVal=NULL;
	char *pcArgName=NULL;
	char *arg=NULL;
	//tag_t *tSignoffs;
		
	printf("\n Ketan cccccc===%d",msg.action);fflush(stdout);

	if (msg.action == EPM_start_action  && msg.proposed_state == EPM_started)
	{
		int count=0;
        tag_t   *attachments            =NULLTAG;
        tag_t   objTag                       =NULLTAG;
        char    *type                       =NULL;
        char    *mode                       =NULL;
        CALLAPI(EPM_ask_attachments (tRootTask,EPM_target_attachment,&count,&attachments));
        printf("\n No of attachments:%d",count);
		if(count>0)
        {
			objTag=attachments[0];
			CALLAPI(AOM_UIF_ask_value(objTag,"ChangeReviewBoard",&type));
			printf("\n ChangeReviewBoard %s \n",type);

			group=tc_strtok(type,"/");
			printf("\n Test 1 group:[%s], type[%s]\n",group,type);fflush(stdout);
			role = tc_strtok(NULL,"/");
			printf("\n Test 2.. group:[%s], role [%s]\n",group,role);fflush(stdout);

			tag_t grouptag=NULLTAG;
			tag_t roletag=NULLTAG;
			printf("\n Test 3\n");fflush(stdout);
			CALLAPI(SA_find_group(group,&grouptag));
			CALLAPI(SA_find_role2(role,&roletag));
			printf("\n Test 4\n");fflush(stdout);
			CALLAPI(EPM_get_resource_pool(grouptag, roletag, FALSE, &resourcePool));
			printf("\n Test 5\n");fflush(stdout);
			printf("\n resourcePool = %d\n", resourcePool);
 
            CALLAPI( EPM_assign_responsible_party(tTask, resourcePool ));
			
            printf("\n Test 6...\n");fflush(stdout);
			
        }
	}

	return ifail;

}







extern int DLLAPI mbom_dml_part_attach( METHOD_message_t *msg, va_list  args )
{
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	tag_t tsk_dml_rel_type=NULLTAG;
	tag_t tsk_dml_rel_type_1=NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	tag_t *DMLRevision_Prt = NULLTAG;
	tag_t DMLRevTag = NULLTAG;
	tag_t DMLRevTag_Prt = NULLTAG;
	tag_t class_id1=NULLTAG;
	tag_t*    status_list1=NULLTAG;
	tag_t*    MBOMstatus_list=NULLTAG;
	tag_t    user_tag=NULLTAG;
	tag_t*    member_tags=NULLTAG;
	tag_t*    status_list_nextRev=NULLTAG;
	tag_t	latestrev	=	NULLTAG;
	tag_t  	master =	NULLTAG;
	tag_t*    status_list;
	tag_t*    dml_status_list;
	tag_t group_tag = NULLTAG;
	tag_t group_tag1 = NULLTAG;
	tag_t role_tag = NULLTAG;
	tag_t			tRole=NULLTAG;
	int error_code	= ITK_ok;
	char *type_name		=NULL;
	char *type_name2	=NULL;
	//char   type_name2[TCTYPE_name_size_c+1];
	char *relation_name	=NULL;
	//char   relation_name[TCTYPE_name_size_c+1];
	char *part_DRStatus		=NULL;
	char *part_name		=NULL;
	char *part_type		=NULL;
	char *owning_group_val		=NULL;
	char *owning_user_val =NULL;
	char *part_organization		=NULL;
	char *part_DesignGrp		=NULL;
	char *class_name		=NULL;
	char *part_MakeBuy		=NULL;
	char *Desc_obj		=NULL;
	char*	 DMLtype		= NULL;
	char*	 DMLDRStatus		= NULL;
	char*	 DMLNumber		= NULL;
	char*	 Desc_obj_drop_prt		= NULL;
	char*	 group_name		= NULL;
	char*	 roleName		= NULL;
	//char			roleName[SA_name_size_c+1];
	char*	 part_creator		= NULL;
	char *WSO_Name = NULL;
	char *WSO_Name_next_Rev = NULL;
	tag_t  CurrentRoleTag = NULLTAG;
    char       roleName_crt[SA_name_size_c+1];
	char PlantCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
    char ClosureRule[40];
	char OrgId[40];
	char dmlnumberCpy[20];
	char dmlnumberCpy_val[20];
	char ConndmlnumberCpy_val[20];
	char		   *DMLNo =NULL;
	char		   *DMLNoCpy =NULL;
	char		   *ConntDMLNoCpy =NULL;
	char		   *PlantName =NULL;
	char		   *PlantNameCpy =NULL;
	char		   *ConntPlantNameCpy =NULL;
	char		   *partDmlType =NULL;
	char *  ErrMssg = NULL;
	char*	DmlId;
	char *  MRDMLErr = NULL;
	logical is_latest_dml;

	char PlantOptCS[40];

	char *class_name1= NULL;
	char*	 DMLFrmToDR	= NULL;//pp
	char*	 FromDR	= NULL;//pp
	char*  GMDMLErr = NULL;//pp
	
	int aplRlzFnd =0;//Priyanka  TZ1.69
	int stcount =0;//Priyanka  TZ1.69
	int irlz =0;//Priyanka  TZ1.69
	int Flag_dr = 0;
	logical t5InProcess = false;
	int count = 0;
	int st_count1 = 0;
	int MBOM_st_count = 0; 
	int st_count_next_rev = 0;
	int cnt_next = 0;
	int j = 0;
	int cnt = 0;
	int errorFlag = 0;
	int NRCheCkBPS = 0;
	int count_dml = 0;
	int PlantDMLActiveFlg = 0;
	int dml = 0;
	int num_of_members = 0;
	int IsAPLStrDMLRlzErr = 0;
	int st_count = 0;
	int st_count_dml = 0;
	int j_mem = 0;
	int ercUsrFnd = 0;
	int aplUsrFnd = 0;
	int dmlstlst = 0;
	int count_dml_1 = 0;
	int t5AplPrtwithAPLWorkFlag=0;
	int samePlantPrtNotFound = 0;
	int samePlantPrtFound = 0;
	int validERCLCSFound=0;
	int	validAPLLCSFound=0;
	int	validSTDLCSFound=0;
	tag_t	relation_type_task = NULLTAG;
	tag_t*			PartTaskTags			= NULLTAG;
	tag_t			PartDmlTag				= NULLTAG;
	tag_t	itemTypeTag_class							= NULLTAG;
	char *type_class = NULL;
	//char  type_class[TCTYPE_name_size_c+1];
	char		   *creatorlogin =NULL;
	char		   *ReleaseStatusDML =NULL;
	char *taskTempLT = NULL; //ADDED BY DEEPTI TZ1.34
	char *username= NULL;//ADDED BY DEEPTI TZ1.34
	char *TaskAnlyst= NULL;//ADDED BY DEEPTI TZ1.34
	char *TaskSpec= NULL;//ADDED BY DEEPTI TZ1.34
	char usrLocation[40];
	char	*PlantNameP		= NULL;
	char AplRvwLC[40];
	char AplWrkngLC[40];
	char AplRlzdLc[40];
	char Stdwrknglc[40];
	char Stdrlzdlc[40];
	char PltLcs[40];
	char StdPlant[40];
	char StdRevRule[40];
	char StdCLosRule[40];
	char StdView[40];
	char *DrError           =NULL;
	char *DMLDRStr          =NULL;
	char *PRTDRStr          =NULL;
	int PRTSTVALU           =0;
	int DMLSTVALU           =0;
	tag_t qryTagCntrlobj    =NULLTAG;
	int n_entryCntrlobj     =3;
	char *qry_entryCntrlformat[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};
	char	**qry_valuesCntrlformat= (char **) MEM_alloc(5 * sizeof(char *));
	int controlObjfound =0;
	tag_t *list_of_cntrl_tags=NULLTAG;
	char *info1 			=NULL;
	char *info2 			=NULL;
	int i=0;
	//char   *UserAgency=NULL;
	tag_t  primary_object = va_arg(args, tag_t);
	tag_t  secondary_object = va_arg(args, tag_t);
	tag_t  relation_type = va_arg(args, tag_t);
	    printf("\n ************** Inside mbom_dml_part_attach ***************\n ");fflush(stdout);
		/*
		ITKCALL(SA_ask_current_role(&CurrentRoleTag));
		ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
		printf("\n\n  roleName : %s\n",roleName); fflush(stdout);
		
		mbom_getPlantDetailsAttr(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency,ClosureRule,usrLocation);
		
		printf("\n PlantCS %s \n",PlantCS);fflush(stdout);
		printf("\n PlantAgency %s \n",PlantIA);fflush(stdout);
		printf("\n PlantStore %s \n",PlantStore);fflush(stdout);
		printf("\n UserAgency %s \n",UserAgency);fflush(stdout);
		printf("\n ClosureRule %s \n",ClosureRule);fflush(stdout);
		*/
		
		printf("\n Calling A9_ValidationAtMMDML running.\n"); fflush(stdout);

		ITKCALL(TCTYPE_ask_object_type(primary_object,&objTypeTag));
		ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
		printf("\n     A9_ValidationAtMMDML primary_object  type_name :: %s\n", type_name); fflush(stdout);

		ITKCALL(TCTYPE_ask_object_type(secondary_object,&objTypeTag2));
		ITKCALL(TCTYPE_ask_name2(objTypeTag2,&type_name2));
		printf("\n     A9_ValidationAtAMDML secondary_object  type_name2 :: %s\n", type_name2); fflush(stdout);
		/**********************pp*******************************/
		// PlantNameP=subString_mbom(roleName,3,4);
		// printf( "PlantNameP:%s\n", PlantNameP);  

		//get_CtrlVal_APLStateInf(PlantNameP,AplRvwLC,AplWrkngLC,AplRlzdLc,Stdwrknglc,Stdrlzdlc,PltLcs,StdPlant,StdRevRule,StdCLosRule,StdView);//Priyanka
		/**********************pp*******************************/
		if(tc_strcmp(type_name,"T5_MBOMTASKRevision")==0)
		{

				ITKCALL(SA_ask_current_role(&CurrentRoleTag));
				ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
				printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

				mbom_getPlantDetailsAttr(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency,ClosureRule,usrLocation);

				printf("\n PlantCS %s \n",PlantCS);fflush(stdout);
				printf("\n PlantAgency %s \n",PlantIA);fflush(stdout);
				printf("\n PlantStore %s \n",PlantStore);fflush(stdout);
				printf("\n UserAgency %s \n",UserAgency);fflush(stdout);
				printf("\n ClosureRule %s \n",ClosureRule);fflush(stdout);

				PlantNameP=subString_mbom(roleName,3,4);
				printf( "PlantNameP:%s\n", PlantNameP);  
				ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
				if (tsk_dml_rel_type!=NULLTAG)
				{
					ITKCALL(GRM_list_primary_objects_only(primary_object,tsk_dml_rel_type,&count,&DMLRevision));
					printf("\n MBOM DML Revision from Task : %d",count); fflush(stdout);
				}

				printf("\n Total Task found is : %d",count);fflush(stdout);
				for (j=0;j<count;j++ )
				{
					DMLRevTag = DMLRevision[j];

					ITKCALL(POM_class_of_instance(DMLRevTag,&class_id1));
					ITKCALL(POM_name_of_class(class_id1,&class_name1));
					printf("\n class_name found1 :%s",class_name1); fflush(stdout);

					if(tc_strcmp(class_name1,"T5_MBOMDMLRevision")==0)
					{
						ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_MBOMRlzType",&DMLtype));
						printf("\n APLDMLtype is :%s",DMLtype); fflush(stdout);

						ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&DMLDRStatus));
						printf("\n DMLDRStatus is :%s",DMLDRStatus); fflush(stdout);

						ITKCALL(AOM_ask_value_string(DMLRevTag,"item_id",&DMLNumber));
						printf("\n DMLNumber is :%s",DMLNumber); fflush(stdout);

						ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_PlntToPlnt",&DMLFrmToDR));//Added by Priyanka Panda For apl GMDML
						printf("\n\t DMLFrmToDR is :%s",DMLFrmToDR); fflush(stdout);

						break;
					}


				}

						/********************************************************************************Priyanka Panda Part drag and drop*********************************************************************************/

				if (tc_strcmp(DMLtype,"GM_MMDML")==0)
				{
						if(tc_strstr(DMLNumber,"MM")!=NULL)
						{

							    if(relation_type != NULLTAG)
								{
										ITKCALL(TCTYPE_ask_name2( relation_type, &relation_name));
								}
								printf("\n   relation_name  CMHasSolutionItem :%s \n",relation_name); fflush(stdout);

								if(tc_strcmp(relation_name,"CMHasSolutionItem")==0) //venkat first change
								{
									printf("\n     Inside attaching part to MM DML task \n"); fflush(stdout);

									EMH_clear_errors();

									GMDMLErr=NULL;
									GMDMLErr=(char *)MEM_alloc(500);
									tc_strcpy(GMDMLErr,"DML NO :");
									tc_strcat(GMDMLErr,DMLNumber);
									tc_strcat(GMDMLErr," and release type:");
									tc_strcat(GMDMLErr,DMLtype);
									tc_strcat(GMDMLErr," .So part can not add under solution folder.");
									tc_strcat(GMDMLErr," Please add part under Change reference folder");
									EMH_store_error_s1(EMH_severity_error,ITK_errStore1,GMDMLErr);
									return ITK_errStore1;
								}

								printf("\n     Inside attaching part to MM DML task to GM_MMDML \n"); fflush(stdout);
								if( AOM_ask_value_string(secondary_object,"current_id",&part_name)==ITK_ok)
								printf("\nAPL GM part_name Value :--------------------   %s\n",part_name); fflush(stdout);

								if( AOM_ask_value_string(secondary_object,"t5_PartStatus",&part_DRStatus)==ITK_ok)
								printf("\nAPL GM part_DRStatus Value :--------------------   %s\n",part_DRStatus); fflush(stdout);

								if( AOM_UIF_ask_value(secondary_object,"owning_group",&owning_group_val)==ITK_ok)
								if( AOM_UIF_ask_value(secondary_object,"owning_user",&owning_user_val)==ITK_ok)
								printf("\nAPL GM after owning_group_val Value :--------------------   %s\n",owning_group_val); fflush(stdout);
								printf("\nAPL GM after owning_user_val Value :--------------------   %s\n",owning_user_val); fflush(stdout);
								FromDR	= NULL;
								FromDR = strtok(DMLFrmToDR," ");
								printf("\nFrom DR   %s\n",FromDR); fflush(stdout);
								Flag_dr =  GetCorrectDRMBOM(FromDR ,part_DRStatus);
								printf("\nFlag_dr 9999  %d\n",Flag_dr); fflush(stdout);


								//if (tc_strcmp(FromDR,part_DRStatus)!=0 )//Added part DRGate must same From DR attribute
								if(Flag_dr == 1)//Added part DRGate must same From DR attribute
								{
									//Error
									printf("\nValidation failed for create relation,Attach part DR status is not valid.");fflush(stdout);
									EMH_clear_errors();

									GMDMLErr=NULL;
									GMDMLErr=(char *)MEM_alloc(500);
									tc_strcpy(GMDMLErr,"Only ");
									tc_strcat(GMDMLErr,FromDR);
									tc_strcat(GMDMLErr," and below DR status Part can attach to this task.");
									EMH_store_error_s1(EMH_severity_error,ITK_errStore1,GMDMLErr);
									return ITK_errStore1;
								}

								if (tc_strstr(owning_group_val,"MBOM")!=NULL || ((tc_strstr(owning_group_val,"dba")!=NULL) && tc_strcmp(owning_user_val,"APL Loader (aplloader)")==0)) //Aniket
								{
									printf("\n Allowed to Add child part");
								}
								else{
									//Error
									printf("\nValidation failed for create relation,For MBOM Gate Maturaion DML, Part should be Created by MBOM User.");fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"For MBOM Gate Maturaion DML, Part should be Created by MBOM User.");
									return ITK_errStore1;
								}
								/*
								else
								{
									//If Part is SA and created by APL User, then check Release Status
									//If Release status is APLC Released found, then only allow to attached, else give error message.
									printf("\nPart is SA and created at APL, so allowed to create relation");fflush(stdout);
									if (WSOM_ask_release_status_list(secondary_object,&stcount,&status_list)==ITK_ok);
									printf("\n Inside MM_ReleaseRevision:: release status found stcount-->[%d]\n",stcount);fflush(stdout);

									if (stcount>0)
									{
										aplRlzFnd	=	0;
										for (irlz=0;irlz<stcount;irlz++)
										{
											printf("\n class_name: %s\n",class_name);fflush(stdout);
											ITKCALL(AOM_ask_value_string(status_list[irlz],"object_name",&class_name));
											printf("\n class_name: %s\n",class_name);fflush(stdout);
											
											if(tc_strcmp(class_name,AplRlzdLc)==0)
											{
												aplRlzFnd = 1;
												break;
											}
										}
									}
									if (aplRlzFnd==0)
									{
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"For MBOM Gate Maturaion DML, Part should be MBOM Released.Please attach MBOM Released Part Only.");
										return ITK_errStore1;
									}
									else
									{
										printf("\nPart is  MBOM Released, so  allow to attach the part.");fflush(stdout);
									}

								}
								*/

								
						}
				}
								
				/********************************************************************************Priyanka Panda**********************************************************************************/
				char*			ErcUserCheck			= NULL;					// Added by Nilesh 
				tag_t			GroupMem				= NULLTAG;				// Added by Nilesh
				tag_t			group_tag				= NULLTAG;				// Added by Nilesh
				char*			MBOM_Grp				= NULL;					// Added by Nilesh
				char*			MMtaskValid				= NULL;					// Added by Nilesh
				char*			TaskAnlystUserID		= NULL;					// Added by Nilesh
				char*			LatestPartRevID_MBOM	= NULL;					// Added by Nilesh
				char*			SecObjRevId				= NULL;					// Added by Nilesh
				int				BypassFlag				= 0;					// Added by Nilesh
				char*			TskAnalystErr			= NULL;					// Added by Nilesh
				char*			LatestPartDropErr		= NULL;					// Added by Nilesh

				/*
				MBOM_Grp=(char *) MEM_alloc(100 * sizeof(char *));
				tc_strcpy(MBOM_Grp,"MBOM");
				printf("\nMBOM Group Name:[%s]\n",MBOM_Grp);
				CALLAPI(SA_find_group(MBOM_Grp,&group_tag));
				if (SA_ask_groupmember_group(GroupMem,&grptag) !=ITK_ok)PrintErrorStack();
				*/

				if(relation_type != NULLTAG)
				{
					ITKCALL(TCTYPE_ask_name2( relation_type, &relation_name));
				}
				printf("\n   relation_name  A9_ValidationAtAMDML CMHasSolutionItem:%s \n",relation_name); fflush(stdout);

				if(tc_strcmp(relation_name,"CMHasSolutionItem")==0)
				{
					printf("\n     Inside attaching part to MM DML task \n"); fflush(stdout);
					//************************************************************************Modification by Nilesh**************************************************
					// TCTYPE_ask_object_type(primary_object)
					// if(tc_strcmp(type_name2,"Design Revision")==0)
					// {
						printf("\nModified by Nilesh");fflush(stdout);
						ITKCALL(AOM_UIF_ask_value(primary_object,"Analyst",&TaskAnlyst));
						printf("\n Task Analyst Before validation : %s",TaskAnlyst);fflush(stdout);
						ITKCALL(AOM_UIF_ask_value(primary_object,"analyst_user_id",&TaskAnlystUserID));
						printf("\n Task Anlyst User ID : %s",TaskAnlystUserID);fflush(stdout);
						ITKCALL(AOM_ask_value_string(primary_object,"item_id",&MMtaskValid));
						printf("\n Task Name is :%s",MMtaskValid); fflush(stdout);
						if( AOM_ask_value_string(secondary_object,"t5_PartType",&part_type)==ITK_ok)
						printf("\n 111 part_type Value :--------------------   %s\n",part_type); fflush(stdout);
						printf("\n String len : %d",strlen(MMtaskValid));fflush(stdout);
						if(strlen(MMtaskValid) == 18)
						{
							printf("\n Task is ERC flown task for MBOM DML");
						}
						if(strlen(MMtaskValid) == 20)
						{
							if(tc_strstr(MMtaskValid,"MM_MBOM"))
							printf("\n Task is user created MM task for MBOM DML");

							if(tc_strstr(MMtaskValid,"MB_MBOM"))
							printf("\n Task is user created MB task for MBOM DML");
						}

						if(POM_get_user_id (&username)==ITK_ok);
						printf("\n username : %s",username);fflush(stdout);
						// ITKCALL(AOM_UIF_ask_value(secondary_object,"owning_user",&ErcUserCheck));
						if( AOM_UIF_ask_value(secondary_object,"owning_group",&owning_group_val)==ITK_ok)
						printf("\n Owning Group : %s",owning_group_val);fflush(stdout);
						ITKCALL(WSOM_ask_release_status_list(primary_object,&MBOM_st_count,&MBOMstatus_list));
						printf("\n Task Release status count :%d",MBOM_st_count);fflush(stdout);
						ITKCALL( AOM_ask_value_logical(primary_object,"fnd0InProcess",&t5InProcess));
						printf("\n Task is in process : %d\n",t5InProcess);fflush(stdout);
						if(ITEM_ask_item_of_rev  (secondary_object,&master) );
						if(ITEM_ask_latest_rev(master,&latestrev));
						int part_st_count = 0;
						MBOMstatus_list = NULLTAG;
						ITKCALL(WSOM_ask_release_status_list(secondary_object,&part_st_count,&MBOMstatus_list));
						int Rel_Status_itr = 0;
						char *MBOM_Rel_status_list = NULL;
						printf("\n Part count is  : %d\n",part_st_count);fflush(stdout);
						ITKCALL(AOM_ask_name(MBOMstatus_list[0],&MBOM_Rel_status_list));
						printf("\n Part current release status is  : %s\n",MBOM_Rel_status_list);fflush(stdout);
						if(part_st_count > 0)
						{
							
								MBOM_Rel_status_list = NULL;
								ITKCALL(AOM_ask_name(MBOMstatus_list[0],&MBOM_Rel_status_list));
								printf("\n Part current release status is [inside if] : %s\n",MBOM_Rel_status_list);fflush(stdout);
							
						}

						if( (tc_strstr(MMtaskValid,"MM_MBOM") != NULL || tc_strstr(MMtaskValid,"MB_MBOM") != NULL)  &&  t5InProcess == 1 )
						{
							printf("\n Inside Claimed task validation check for MB_MBOM/ MM_MBOM Task...");fflush(stdout);					
							tag_t   dmlCtrlObjQry     			= NULLTAG;
							char	**qry_valuesCntrl1			= (char **) MEM_alloc(5 * sizeof(char *));
							char    *qry_entryCntrl1[3]  		= {"SYSCD","SUBSYSCD","Delete Indicator"};	
							int  	control_Object_Count		= 0;
							tag_t 	*cntr_objects				= NULLTAG;
							char 	*UserInfo1					= NULL;
							char 	*UserInfo2					= NULL;
							char 	*UserInfo3					= NULL;


							if(QRY_find2("Control Objects...", &dmlCtrlObjQry));
							if (dmlCtrlObjQry != 0)
							{
								printf("\n Control Object Query Found \n");fflush(stdout);
								qry_valuesCntrl1[0]="DMLCtrlObj";
								qry_valuesCntrl1[1]="MBDMLCtrlObj";
								qry_valuesCntrl1[2]="0";
								
								if(QRY_execute(dmlCtrlObjQry, 3, qry_entryCntrl1, qry_valuesCntrl1, &control_Object_Count, &cntr_objects));
								printf("\n MB/MM DML Control Object found : %d",control_Object_Count);fflush(stdout);

									if(control_Object_Count > 0)
									{
										printf("\n Delete Indicator for bypass user control object is false ...");fflush(stdout);
										ITKCALL(AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&UserInfo1));
										ITKCALL(AOM_ask_value_string(cntr_objects[0],"t5_Userinfo2",&UserInfo2));
										ITKCALL(AOM_ask_value_string(cntr_objects[0],"t5_Userinfo2",&UserInfo3));

										if(tc_strstr(UserInfo1,username) || tc_strstr(UserInfo2,username) || tc_strstr(UserInfo3,username))
										{
											BypassFlag = 1;
											printf("\n Bypass for supper user and support users...");fflush(stdout);
										}
									}
									else
									{
										printf("\n Delete indicatot for control object is OFF...");fflush(stdout);
									}
							}
							if(tc_strstr(TaskAnlyst,username) == NULL && BypassFlag == 0)
							{
								TskAnalystErr = NULL;
								TskAnalystErr = (char *)MEM_alloc(500);
								printf("\n Inside Task claimed Validation");fflush(stdout);
								printf("\n Task Analyst : %s",TaskAnlyst);fflush(stdout);
								printf("\n username : %s",username);fflush(stdout);
								tc_strcpy(TskAnalystErr,"");
								tc_strcat(TskAnalystErr,"Session User is Not Task Analyst..Only Analyst Can Add Part To MB DML Task.");
								tc_strcat(TskAnalystErr,"\n");
								tc_strcat(TskAnalystErr,"Task Analyst : ");
								tc_strcat(TskAnalystErr,TaskAnlyst);
								tc_strcat(TskAnalystErr,"And Session User is : ");
								tc_strcat(TskAnalystErr,username);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_errStore1,TskAnalystErr);
								return ITK_errStore1;
							}
						}
						char *release_type_of_DML =NULL;
						ITKCALL(AOM_ask_value_string(DMLRevision[0],"t5_rlstype",&release_type_of_DML));
						printf("\n release_type_of_DML is for colour checking:%s",release_type_of_DML); fflush(stdout);

						if((tc_strcmp(release_type_of_DML,"CP")==0) || (tc_strcmp(release_type_of_DML,"CM")==0)||((tc_strstr(MMtaskValid,"_CL_MBOM")!=NULL)&&(tc_strcmp(release_type_of_DML,"Veh")==0)))
						{
							printf("\n By Pass attach part in sol folder on ERC Flown DML for the Colour part and colour module release.......... ");fflush(stdout);

						}
						else
						{

							if(strlen(MMtaskValid) == 18 && t5InProcess == 1 )
							{
								printf("\n Validation - attach part to ERC flown task for MBOM DML ");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Part addition to ERC flown task for MBOM DML is not allowed ... ");
								return ITK_errStore1;
							}

						}
						if(BypassFlag == 1)
						{
							printf("\n PLM's GOD Mode Utilized");fflush(stdout);
						}
						if(strlen(MMtaskValid) == 20 && t5InProcess == 1 && BypassFlag == 0)
						{
							printf("\n Task is submitted in process");fflush(stdout);
							if((tc_strstr(MMtaskValid,"MM_MBOM") != NULL) || (tc_strstr(MMtaskValid,"MB_MBOM") != NULL))
							{
								printf("\n Inside MM_MBOM OR MB_MBOM");fflush(stdout);
								if(tc_strcmp(owning_group_val,"ERC_Designers_Group") == 0)
								{
									if(tc_strstr(MMtaskValid,"MM_MBOM") != NULL  && (tc_strcmp(part_type,"V") == 0 || tc_strcmp(part_type,"VCCR") == 0))
									{
										printf("\n Allowed dropping of ERC part - part type as vehicle on MM DML");fflush(stdout);
									}
									else
									{
										printf("\n attach erc-part to MM/MB task");fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Dropping of ERC-Part on MBOM DML (MB / MM task) not allowed !");
										return ITK_errStore1;
									}
								}
								if(tc_strcmp(owning_group_val, "MBOM") == 0)
								{
									AOM_UIF_ask_value(latestrev,"item_revision_id",&LatestPartRevID_MBOM);
									printf("\n Dropping part latest rev is : %s ",LatestPartRevID_MBOM);

									AOM_UIF_ask_value(secondary_object,"item_revision_id",&SecObjRevId);
									printf("\n Dropping part rev is : %s ",SecObjRevId);

									if(tc_strcmp(LatestPartRevID_MBOM,SecObjRevId) == 0 && tc_strcmp(MBOM_Rel_status_list,"T5_MBOMReview") == 0)
									{
										printf("\n dropped part is the lastest part");fflush(stdout);
									}
									else
									{
										printf("\n dropped part is not the lastest part");fflush(stdout);
										LatestPartDropErr = NULL;
										LatestPartDropErr = (char *)MEM_alloc(500);
										tc_strcpy(LatestPartDropErr,"Part is not the latest part. Kindly add the latest part only.");
										tc_strcat(LatestPartDropErr,"\n");
										tc_strcat(LatestPartDropErr,"Dropped Part Revision : ");
										tc_strcat(LatestPartDropErr,SecObjRevId);
										tc_strcat(LatestPartDropErr,"\n");
										tc_strcat(LatestPartDropErr,"Part Latest Revison ; ");
										tc_strcat(LatestPartDropErr,LatestPartRevID_MBOM);
										tc_strcat(LatestPartDropErr,"\n");
										tc_strcat(LatestPartDropErr,"Life Cycle state of the part is : ");
										tc_strcat(LatestPartDropErr,MBOM_Rel_status_list);
										tc_strcat(LatestPartDropErr,"\n");
										tc_strcat(LatestPartDropErr,"Part should be in MBOM Review");
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_errStore1,LatestPartDropErr);
										return ITK_errStore1;
									}
								}	
							}
						}

						
						// MB DML Creation Validation sec - Nilesh
						/*
						if((tc_strstr(MMtaskValid,"MM") == NULL) && control_Object_Count > 0)
						{
								printf("\n Inside MB task Validation");fflush(stdout);
								if(tc_strstr(TaskAnlyst,username)== NULL)		
									{
										printf("\n Inside Task claimed Validation");fflush(stdout);
										printf("\n Task Analyst : %s",TaskAnlyst);fflush(stdout);
										printf("\n username : %s",username);fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Session User is Not Task Analyst..Only Analyst Can Add Part To MB DML Task.");
										return ITK_errStore1;
									} 
									
								 if(tc_strstr(owning_group_val,"MBOM") == NULL)
								 	{
								 		printf("\n Inside Owning group Validation");fflush(stdout);
								 		EMH_clear_errors();
								 		EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Dropping of ERC-Part on MBOM DML not allowed !");
								 		return ITK_errStore1;
								 	}
									
							}
							 else
							{
								printf("\n Control Object delete indicator for MB DML is True \n");fflush(stdout);
							} 
							*/
						if( AOM_ask_value_string(secondary_object,"current_id",&part_name)==ITK_ok)
						printf("\n part_name Value :--------------------   %s\n",part_name); fflush(stdout);
						if( AOM_ask_value_string(secondary_object,"t5_PartStatus",&part_DRStatus)==ITK_ok)
						printf("\n part_DRStatus Value :--------------------   %s\n",part_DRStatus); fflush(stdout);
						if( AOM_UIF_ask_value(secondary_object,"owning_group",&owning_group_val)==ITK_ok)
						printf("\n after owning_group_val Value :--------------------   %s\n",owning_group_val); fflush(stdout);
						if( AOM_ask_value_string(secondary_object,"t5_DesignGrp",&part_DesignGrp)==ITK_ok)
						printf("\n part_DesignGrp Value :--------------------   %s\n",part_DesignGrp); fflush(stdout);
						if (AOM_ask_value_string(secondary_object,"current_revision_id",&Desc_obj_drop_prt)==ITK_ok)
						printf("\n Desc_obj_drop_prt Value :--------------------   %s\n",Desc_obj_drop_prt); fflush(stdout);
						cnt=0;
						WSO_Name=NULL;
						ITKCALL(WSOM_ask_release_status_list(secondary_object,&st_count1,&status_list1));
						printf("\n 111..st_count1 :%d is\n",st_count1);fflush(stdout);

						//sanket part drag and drop code logic start

						printf("\n Part Group ID Value is:%s",owning_group_val); fflush(stdout);

						if(tc_strcmp(owning_group_val,"MBOM")==0)
						{
							printf("\n Sanket inside part drag and drop"); fflush(stdout);
							ITKCALL(QRY_find2("Control Objects...", &qryTagCntrlobj));
							if (qryTagCntrlobj != NULLTAG)
							{
								 printf("\n Control Object Query Found \n");fflush(stdout);
								 qry_valuesCntrlformat[0]="PrtDrgDropVali";
								 qry_valuesCntrlformat[1]="PrtDrgDropVali";
								 qry_valuesCntrlformat[2]="0";
								 ITKCALL(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
								 printf("\n Number of control Obj Found is: %d",controlObjfound);fflush(stdout);
							}
							if (controlObjfound>0)
							{
								for (i=0;i<controlObjfound ;i++ )
								{
									ITKCALL(AOM_ask_value_string( list_of_cntrl_tags[i], "t5_Userinfo1", &info1));
									printf("\n Information1 is: %s\n",info1);fflush(stdout);
									ITKCALL(AOM_ask_value_string( list_of_cntrl_tags[i], "t5_Userinfo2", &info2));
									printf("\n Information2 is: %s\n",info2);fflush(stdout);

									if ((tc_strstr(DMLtype,info1)!=NULL) || (tc_strstr(DMLtype,info2)!=NULL))
									{
										printf("\n DML DR Status value is :%s",DMLDRStatus); fflush(stdout);
										printf("\n Part DR Status Value is:%s",part_DRStatus); fflush(stdout);
										printf("\n Part Type Value is:%s",part_type); fflush(stdout);
										if(tc_strcmp(part_type,"D")!=0)
										{
											if(tc_strstr(part_DRStatus,"NA")==NULL)
											{
												//DR3P
												if ((tc_strcmp(DMLDRStatus,"DR3P")==0)||(tc_strcmp(DMLDRStatus,"AR3P")==0))
												{
													if((tc_strcmp(part_DRStatus,"DR4")==0)||(tc_strcmp(part_DRStatus,"AR4")==0)||(tc_strcmp(part_DRStatus,"AR5")==0)||(tc_strcmp(part_DRStatus,"DR5")==0)||(tc_strcmp(part_DRStatus,"DR3P")==0)||(tc_strcmp(part_DRStatus,"AR3P")==0))
													{
														printf("\n DRCHK:AR3P dml, SO ABOVE DR-STATUS CHILD PARTS ALLOWED:[%s]..",part_name);fflush(stdout);
													}
													else
													{
														printf("\n DRCHK ERROR:[%s]..",part_name);fflush(stdout);
														EMH_clear_errors();
														DrError=NULL;
														DrError=(char *)MEM_alloc(500);
														tc_strcpy(DrError,"Part ");
														tc_strcat(DrError,part_name);
														tc_strcat(DrError," having DR-status ");
														tc_strcat(DrError,part_DRStatus);
														tc_strcat(DrError," and DML is with DR-status ");
														tc_strcat(DrError,DMLDRStatus);
														tc_strcat(DrError," which is not allowed.");
														tc_strcat(DrError,"\n");
														tc_strcat(DrError,"Please get the DR-status corrected.");
														tc_strcat(DrError,"\n");
														tc_strcat(DrError,"If DML DR-status is DR3P/AR3P, then dropping part should have DR3P/AR3P status or above.");
														tc_strcat(DrError,"\n");
														tc_strcat(DrError,"and child parts should have DR-status equal or above than DR3P/AR3P status.");
										
														ITKCALL(EMH_store_error_s1(EMH_severity_error,ITK_errStore1,DrError));
														return ITK_errStore1;
													}
												}
												else
												{
													if ((tc_strcmp(DMLDRStatus,"DR3")==0)||(tc_strcmp(DMLDRStatus,"AR3")==0))
													{
														if ((tc_strcmp(part_DRStatus,"DR3P")==0)||(tc_strcmp(part_DRStatus,"AR3P")==0))
														{
															EMH_clear_errors();
														    DrError=NULL;
														    DrError=(char *)MEM_alloc(500);
														    tc_strcpy(DrError,"Part ");
														    tc_strcat(DrError,part_name);
														    tc_strcat(DrError," having DR-status ");
														    tc_strcat(DrError,part_DRStatus);
														    tc_strcat(DrError," and DML is with DR-status ");
														    tc_strcat(DrError,DMLDRStatus);
														    tc_strcat(DrError," which is not allowed.");
														    tc_strcat(DrError,"\n");
														    tc_strcat(DrError,"Please get the DR-status corrected.");
														    tc_strcat(DrError,"\n");
														    tc_strcat(DrError,"If part DR-status is DR3P/AR3P, then DML should have DR3P/AR3P status.");
														    tc_strcat(DrError,"\n");
														    tc_strcat(DrError,"and child parts should have DR-status equal or above than DR3P/AR3P status.");
														    ITKCALL(EMH_store_error_s1(EMH_severity_error,ITK_errStore1,DrError));
														    return ITK_errStore1;

														}
													}
														DMLDRStr=NULL;
														PRTDRStr=NULL;
														PRTSTVALU=0;
														DMLSTVALU=0;
														PRTDRStr=subString_mbom(part_DRStatus, 2, 1);
														DMLDRStr=subString_mbom(DMLDRStatus, 2, 1);
														printf("\n DR: DMLDRStr: %s",DMLDRStr);fflush(stdout);
														printf("\n DR: PRTDRStr: %s",PRTDRStr);fflush(stdout);
														PRTSTVALU=atoi(PRTDRStr);
														DMLSTVALU=atoi(DMLDRStr);
														printf("\n DR: PRTSTVALU: %d DMLSTVALU: %d",PRTSTVALU,DMLSTVALU);fflush(stdout);
														if (PRTSTVALU == DMLSTVALU)
														{
															printf("\n DRCHK:DML UpdA:allow for part:[%s]",part_name);fflush(stdout);
														}
														else
														{
															if (DMLSTVALU==0 && PRTSTVALU==1)
															{
																printf("\n DRCHK:DML UpdB:allow for part:[%s]",part_name);fflush(stdout);
															}
															else if (DMLSTVALU==1 && PRTSTVALU==2)
															{
																printf("\n DRCHK:DML UpdC:allow for part:[%s]",part_name);fflush(stdout);
															}
															else if (DMLSTVALU==4 && PRTSTVALU==5)
															{
																printf("\n DRCHK:DML UpdD:allow for part:[%s]",part_name);fflush(stdout);
															}
															else
															{
																//Error
																printf("\n DRCHK:DML Upd ERROR:[%s]",part_name);fflush(stdout);
																EMH_clear_errors();
																DrError=NULL;
																DrError=(char *)MEM_alloc(500);
																tc_strcpy(DrError,"DML DR-status updation not allowed as part attached to DML having higher or lower DR-status.");
																tc_strcat(DrError,"\n");
																tc_strcat(DrError,"Parts were attached to DML should have DR-status equal to DML DR-status.");
																tc_strcat(DrError,"\n");
																tc_strcat(DrError,"In case of DR0/AR0 DML, part can be DR0/1 or AR0/1.");
																tc_strcat(DrError,"\n");
																tc_strcat(DrError,"In case of DR1/AR1 DML, part can be DR1/2 or AR1/2.");
																tc_strcat(DrError,"\n");
																tc_strcat(DrError,"In case of DR3P/AR3P DML, part can be DR3P/AR3P or above.");
																tc_strcat(DrError,"\n");
																tc_strcat(DrError,"In case of DR4/AR4 DML, part can be DR4/5 or AR4/5.");
										
																ITKCALL(EMH_store_error_s1(EMH_severity_error,ITK_errStore1,DrError));
																return ITK_errStore1;
															}  
														}
													}
												}
											}
										}
									}
								}
							}
							//sanket part drag and drop code logic end
							if(tc_strcmp(DMLtype,"")!=0)
							{
								printf("\n DMLtype is not null...\n"); fflush(stdout);
								if(tc_strstr(roleName,"MBOM")!=NULL)
								{
									if(tc_strstr(DMLNumber,"MM")!=NULL)
									{
										if((tc_strstr(MMtaskValid,"_00CL")!=NULL))
										{
											printf("\n By pass condition for 00CL Task\n");fflush(stdout);

										}
										else
										{
											printf("\n DMLNumber is MM...\n");fflush(stdout);
											printf("\nUSer restriction validation");fflush(stdout);
											if( AOM_UIF_ask_value(primary_object,"fnd0StartedWorkflowTasks",&taskTempLT)==ITK_ok); //ADDED BY Priyanka
											printf("\n primary taskTempLT is .. Add Part: %s\n",taskTempLT);fflush(stdout);

											if( AOM_UIF_ask_value(primary_object,"Analyst",&TaskAnlyst)==ITK_ok); 
											printf("\n TaskAnlyst: %s\n",TaskAnlyst);fflush(stdout);

											if( AOM_UIF_ask_value(primary_object,"ChangeSpecialist1",&TaskSpec)==ITK_ok); 
											printf("\n TaskSpec: %s\n",TaskSpec);fflush(stdout);

											if(POM_get_user_id (&username)==ITK_ok);
											printf("\n\n  username : %s\n",username); fflush(stdout);

											//if( (tc_strcmp(taskTempLT,"")!=0)&& (tc_strstr(taskTempLT,"Work On DML")!=NULL)) //ADDED BY DEEPTI 1.34
											if( (tc_strcmp(taskTempLT,"")!=0)&& (tc_strstr(taskTempLT,"Work On MBOM-DML")!=NULL)) //ADDED BY Priyanka 1.71
											{

												if(tc_strstr(TaskAnlyst,username) ==NULL)
												{

													EMH_clear_errors();
													EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Session User is Not Task Analyst..Only Analyst Can Add Part To APL DML Task.");

													return ITK_errStore1;

												}
												printf("\n\n  Before Dummy change part type: %s part_name: %s\n",part_type,part_name); fflush(stdout);

												if ((tc_strcmp(part_type, "D") != 0) && (tc_strcmp(part_type, "DC") != 0) && (tc_strcmp(part_type, "DA") != 0)) 
												{
													printf("\n\n  Inside dummy condition part_type : %s\n",part_type); fflush(stdout);
													
													if(tc_strcmp(DMLDRStatus,"")!=0)
													{
														/*************Start of DR Validation********************/
														if( (tc_strcmp(DMLDRStatus,"DR4")==0)|| (tc_strcmp(DMLDRStatus,"DR5")==0) || (tc_strcmp(DMLDRStatus,"AR4")==0) || (tc_strcmp(DMLDRStatus,"AR5")==0))
														{
															if( (tc_strcmp(part_DRStatus,"DR4")==0)|| (tc_strcmp(part_DRStatus,"DR5")==0) || (tc_strcmp(part_DRStatus,"AR4")==0) || (tc_strcmp(part_DRStatus,"AR5")==0))
															{
																printf("Correct...In APL MMDML with Status DR4/DR5/AR4/AR5 only Design Revision with DR Status DR4/DR5/AR4/AR5 allowed."); fflush(stdout);

															}
															else
															{

																printf("In APL AMDML with Status DR4/DR5/AR4/AR5 only Design Revision with DR Status DR4/DR5/AR4/AR5 allowed."); fflush(stdout);
																if (tc_strcmp(MRDMLErr,"NULL") !=0) MEM_free(MRDMLErr);
																MRDMLErr=(char *)MEM_alloc(500);
																tc_strcpy(MRDMLErr,"Part ");
																tc_strcat(MRDMLErr,part_name);
																tc_strcat(MRDMLErr," is with DR ");
																tc_strcat(MRDMLErr,part_DRStatus);
																//tc_strcat(MRDMLErr," status Not Allowed in APL Restructuring DML.\n");
																tc_strcat(MRDMLErr," status Not Allowed in MM DML of EcnType:");
																tc_strcat(MRDMLErr,DMLtype);
																tc_strcat(MRDMLErr,".\n");
																tc_strcat(MRDMLErr,"In MRDML with Status DR4/DR5/AR4/AR5 only Design Revision with DR Status DR4/DR5/AR4/AR5 allowed");

																EMH_clear_errors();
																EMH_store_error_s1(EMH_severity_error,ITK_errStore1,MRDMLErr);
																return ITK_errStore1;
															}
														}

														if( (tc_strcmp(DMLDRStatus,"DR0")==0)|| (tc_strcmp(DMLDRStatus,"DR1")==0) || (tc_strcmp(DMLDRStatus,"DR2")==0)|| (tc_strcmp(DMLDRStatus,"DR3")==0)|| (tc_strcmp(DMLDRStatus,"AR0")==0) || (tc_strcmp(DMLDRStatus,"AR1")==0)|| (tc_strcmp(DMLDRStatus,"AR2")==0)|| (tc_strcmp(DMLDRStatus,"AR3")==0))
														{
															if( (tc_strcmp(part_DRStatus,"DR0")==0)|| (tc_strcmp(part_DRStatus,"DR1")==0) || (tc_strcmp(part_DRStatus,"DR2")==0)|| (tc_strcmp(part_DRStatus,"DR3")==0)|| (tc_strcmp(part_DRStatus,"AR0")==0) || (tc_strcmp(part_DRStatus,"AR1")==0)|| (tc_strcmp(part_DRStatus,"AR2")==0)|| (tc_strcmp(part_DRStatus,"AR3")==0))
															{
																printf("Correct..In MRDML with Status DR0/DR1/DR2/DR3/AR0/AR1/AR2/AR3  only Design Revision with DR Status DR0/DR1/DR2/DR3/AR0/AR1/AR2/AR3  allowed."); fflush(stdout);

															}
															else
															{
																printf("In MR DML with Status DR0/DR1/DR2/DR3/AR0/AR1/AR2/AR3  only Design Revision with DR Status DR0/DR1/DR2/DR3/AR0/AR1/AR2/AR3  allowed."); fflush(stdout);
																if (tc_strcmp(MRDMLErr,"NULL") !=0) MEM_free(MRDMLErr);
																MRDMLErr=(char *)MEM_alloc(500);
																tc_strcpy(MRDMLErr,"Part ");
																tc_strcat(MRDMLErr,part_name);
																tc_strcat(MRDMLErr," is with DR ");
																tc_strcat(MRDMLErr,part_DRStatus);
																//tc_strcat(MRDMLErr," status Not Allowed in APL Restructuring DML.\n");
																tc_strcat(MRDMLErr," status Not Allowed in MM DML of EcnType:");
																tc_strcat(MRDMLErr,DMLtype);
																tc_strcat(MRDMLErr,".\n");
																tc_strcat(MRDMLErr,"In APL DML with Status DR0/DR1/DR2/DR3/AR0/AR1/AR2/AR3  only Design Revision with DR Status DR0/DR1/DR2/DR3/AR0/AR1/AR2/AR3  allowed.");
																EMH_clear_errors();
																EMH_store_error_s1(EMH_severity_error,ITK_errStore1,MRDMLErr);
																return ITK_errStore1;
															}

														}
														/*************End of DR Validation********************/
														printf("\n\n  End of DR Validation \n"); fflush(stdout);
													}
												}
										printf("\n\n  Outside dummy condition check \n"); fflush(stdout);
										/*************End of APL MBOM Re-Structuring Validation********************/
										/*************Start of APL MBOM Re-Structuring Validation********************/
										/*************COMMENTED BELOW CODE OF ORGANIZATION ID.WILL DO AFTER MANAGEMENT DECISION:::REWORK TZ TEST********************/
										if(tc_strstr(owning_group_val,"MBOM")!=NULL)
										{
											printf("\n owning_group_val is MBOM...");fflush(stdout);
										}
										else
										{
											if( AOM_ask_value_string(secondary_object,PlantCS,&part_MakeBuy)==ITK_ok)
											printf("\n part_MakeBuy Value :--------------------%s\n",part_MakeBuy);fflush(stdout);

											if(tc_strcmp(part_MakeBuy,"")!=0)
											{
												//if ( (tc_strcmp(part_MakeBuy,"E50 (In-house production-Phantom Assembly)")==0) || (tc_strcmp(part_MakeBuy,"F30 (External procurement - Subcontracting)")==0) || (tc_strcmp(part_MakeBuy,"E99 (In-house production-Back Flush Items)")==0) || (tc_strcmp(part_MakeBuy,"F40 (Interplant stock Transfer using STSA)")==0))
												//if ( (tc_strcmp(part_MakeBuy,"E50")==0) || (tc_strcmp(part_MakeBuy,"F30")==0) || (tc_strcmp(part_MakeBuy,"E99")==0) || (tc_strcmp(part_MakeBuy,"F40")==0))
												if ( (tc_strcmp(part_MakeBuy,"E50")==0) || (tc_strcmp(part_MakeBuy,"F30")==0) || (tc_strcmp(part_MakeBuy,"E99")==0) ||  (tc_strcmp(part_MakeBuy,"")==0) || (tc_strcmp(part_MakeBuy,"F40")==0) || (tc_strcmp(part_MakeBuy,"F35")==0) || (tc_strcmp(part_MakeBuy,"F")==0))//F35 added by Hemal
												{
													printf("\n APL working Design Rev with CS E50/E99/F30/F40/F35/F/Blank is allowed to attach in AM DML \n");fflush(stdout);
												}
												else
												{
														count_dml=0;
														dml=0;
														cnt=0;
														st_count1=0;
														PlantDMLActiveFlg=0;
														PartTaskTags=NULLTAG;
														PartDmlTag=NULLTAG;
														relation_type_task=NULLTAG;
														DmlId=NULL;
														GRM_find_relation_type("CMHasSolutionItem",&relation_type_task);
														GRM_list_primary_objects_only(secondary_object,relation_type_task,&count_dml,&PartTaskTags);
														printf("\t  count_dml ...%d\n", count_dml);fflush(stdout);
														if(count_dml >0)
														{
															for (dml=0;dml<count_dml ;dml++ )
															{
																PartDmlTag=PartTaskTags[dml];
																ITKCALL (TCTYPE_ask_object_type(PartDmlTag,&itemTypeTag_class));
																ITKCALL (TCTYPE_ask_name2(itemTypeTag_class,&type_class));

																printf("\t  type_itemRev ...%s\n", type_class);fflush(stdout);
																if(tc_strcmp(type_class,"T5_MBOMTASKRevision")==0)
																{
																	ITKCALL(AOM_ask_value_string(PartDmlTag, "item_id",&DmlId));
																	printf("\n DmlId %s.....PlantName:%s\n",DmlId,PlantName);fflush(stdout);
																	if(tc_strstr(DmlId,PlantName)!=NULL)
																	{

																		st_count1=0;
																		ITKCALL(WSOM_ask_release_status_list(PartDmlTag,&st_count1,&status_list1));
																		printf("\n 111..st_count1 :%d is\n",st_count1);fflush(stdout);

																		if(st_count1>0)
																		{
																			for (cnt=0;cnt< st_count1;cnt++ )
																			{
																				WSO_Name=NULL;
																				ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
																				printf("\n 111..ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);

																				if(tc_strcmp(WSO_Name,"")!=0)
																				{
																					if(tc_strcmp(UserAgency,"MBOM")==0)
																					{
																						if ((tc_strcmp(WSO_Name,"T5_LcsMBOMWrkg")==0))
																						{
																							PlantDMLActiveFlg++;
																						}																	    }
								
																				}
																			}
																		}
																	}
																}
															}
															if(PlantDMLActiveFlg>0)
															{
																printf("Design Revision is attached to some Other DML and is in MBOM-Working State.");fflush(stdout);
																EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Design Revision is attached to some Other DML and is in MBOM-Working State.");
																return ITK_errStore1;
															}
														}

													}

											}
											else
											{
													printf("\n part_MakeBuy Value :--------------------   %s is NULL\n",part_MakeBuy);fflush(stdout);
											}
										}
									/*************End of APL MBOM Re-Structuring Validation********************/

									/*************Start of AMDML Validation********************/
									if(tc_strcmp(DMLtype,"MM")==0)
									{

										printf("Inside MBOM validation...\n"); fflush(stdout);
										if(latestrev != NULLTAG)
										{
											if (AOM_ask_value_string(latestrev,"current_revision_id",&Desc_obj)==ITK_ok)
											printf("\n Desc_obj Value :--------------------   %s\n",Desc_obj); fflush(stdout);

											if(tc_strcmp(Desc_obj_drop_prt,Desc_obj)==0)
											{
												printf("Dropped object is latest MBOM released.."); fflush(stdout);
											}
											else
											{

												ITKCALL(WSOM_ask_release_status_list(latestrev,&st_count_next_rev,&status_list_nextRev));
												printf("\n st_count_next_rev :%d is\n",st_count_next_rev);fflush(stdout);

												if(st_count_next_rev>0)
												{
													for (cnt_next=0;cnt_next< st_count_next_rev;cnt_next++ )
													{
														WSO_Name_next_Rev=NULL;
														ITKCALL(AOM_ask_name(status_list_nextRev[cnt_next],&WSO_Name_next_Rev));
														printf("\n WSO_Name_next_Rev is :%s\n",WSO_Name_next_Rev);fflush(stdout);

													}
												}

												if(tc_strcmp(WSO_Name_next_Rev,"")!=0)
												{
													if(tc_strcmp(UserAgency,"MBOM")==0)
												{
													if ((tc_strcmp(WSO_Name_next_Rev,"T5_LcsMBOMRlzd")==0) || (tc_strcmp(WSO_Name_next_Rev,"T5_LcsAplRlzd")==0)||(tc_strcmp(WSO_Name_next_Rev,"T5_LcsSTDWrkg")==0) || (tc_strcmp(WSO_Name_next_Rev,"T5_LcsStdRlzd")==0))
													{
														printf("Drag & Drop Of Design Revision Not Allowed As The Next Revision Of Part is already MBOM Released"); fflush(stdout);
														if (tc_strcmp(MRDMLErr,"NULL") !=0) MEM_free(MRDMLErr);
														MRDMLErr=(char *)MEM_alloc(500);
														tc_strcpy(MRDMLErr,"Drag & Drop Of Part Not Allowed As The Next Revision Of Part ");
														tc_strcat(MRDMLErr,part_name);
														tc_strcat(MRDMLErr," Is Already MBOM Released.");
														EMH_clear_errors();
														EMH_store_error_s1(EMH_severity_error,ITK_errStore1,MRDMLErr);
														return ITK_errStore1;
													}
												}
												
												}

											}

										}
									}
									/*************Start of AMBSTR Validation********************/
									//if((tc_strcmp(DMLtype,"APLSTR")==0) || (tc_strcmp(DMLtype,"APLMBOMRES")==0) || (tc_strcmp(DMLtype,"AMBSTR")==0) || (tc_strcmp(DMLtype,"FrameGrp")==0))
									if((tc_strcmp(DMLtype,"APLSTR")==0) || (tc_strcmp(DMLtype,"AMBSTR")==0) || (tc_strcmp(DMLtype,"FrameGrp")==0))
									{

										printf("\n Inside 12-14 digiti validation.."); fflush(stdout);
										//if(tc_strlen(part_name)==14)
										if(tc_strstr(owning_group_val,"APL")!=NULL)
										{

											/*************COMMENTED BELOW CODE OF ORGANIZATION ID.WILL DO AFTER MANAGEMENT DECISION:REWORK.BELOW CHECK IS NOT REQUIRED********************/
											/*if(tc_strstr(organization_id,"APL")!=NULL)
											{
												printf("\n UserAgency is APL");fflush(stdout);
											}
											else
											{
												printf("For Any 14 digit Design Revision Organization ID should be APLP/APLA/APLJ/APLL/APLD.");

												if (tc_strcmp(MRDMLErr,"NULL") !=0) MEM_free(MRDMLErr);
												MRDMLErr=(char *)MEM_alloc(500);
												tc_strcpy(MRDMLErr,"Design Revision ");
												tc_strcat(MRDMLErr,part_name);
												tc_strcat(MRDMLErr," is 14 digit Part with Organization ID as ");
												tc_strcat(MRDMLErr,organization_id);
												tc_strcat(MRDMLErr,".\n For Any 14 digit Design Revision Organization ID should be APLP/APLA/APLJ/APLL/APLD");

												EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"For Any 14 digit Design Revision Organization ID should be APLP/APLA/APLJ/APLL/APLD.");
												return ITK_errStore1;

											}*/


											t5AplPrtwithAPLWorkFlag=0;
											cnt=0;
											if(st_count1>0)
											{
												for (cnt=0;cnt< st_count1;cnt++ )
												{
													WSO_Name=NULL;
													ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
													printf("\n 111..ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);

													if(tc_strcmp(WSO_Name,"")!=0)
													{
														if(tc_strcmp(UserAgency,"MBOM")==0)
														{
															if(tc_strcmp(WSO_Name,"T5_LcsMBOMWrkg")==0)
															{
																t5AplPrtwithAPLWorkFlag++;
															}
														}

													}
												}
												if(t5AplPrtwithAPLWorkFlag==0)
												{
													printf("For any MBOM created Design Revision, Release Status should be MBOM Working."); fflush(stdout);
													if (tc_strcmp(MRDMLErr,"NULL") !=0) MEM_free(MRDMLErr);
													MRDMLErr=(char *)MEM_alloc(500);
													tc_strcpy(MRDMLErr,"MBOM created Design Revision ");
													tc_strcat(MRDMLErr,part_name);
													tc_strcat(MRDMLErr," with Life Cycle State 'MBOM Working'");
													tc_strcat(MRDMLErr," are allowed under MBOM Restructuring DML "); // DEEPTI ADDDED TZ1.34
													tc_strcat(MRDMLErr,DMLNumber);
													tc_strcat(MRDMLErr,".\n For any MBOM created Design Revision, Release Status should be MBOM Working.");

													EMH_clear_errors();
													EMH_store_error_s1(EMH_severity_error,ITK_errStore1,MRDMLErr);
													return ITK_errStore1;

												}
											}

										}
										else
										{
											if(st_count1>0)
											{
												cnt=0;
												validERCLCSFound=0;
												validAPLLCSFound=0;
												validSTDLCSFound=0;
												for (cnt=0;cnt< st_count1;cnt++ )
												{
													WSO_Name=NULL;
													ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
													printf("\n ....111..ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);

													if(tc_strcmp(WSO_Name,"")!=0)
													{
														if(tc_strcmp(UserAgency,"CAR")==0)
														{
														if((tc_strcmp(WSO_Name,"T5_LcsErcRlzd")==0) ||(tc_strcmp(WSO_Name,"T5_LcsAPLWrkg")==0) ||(tc_strcmp(WSO_Name,"T5_LcsAplRlzd")==0)||(tc_strcmp(WSO_Name,"T5_LcsSTDWrkg")==0)||(tc_strcmp(WSO_Name,"T5_LcsStdRlzd")==0))
														{
															validERCLCSFound++;
														}
														if((tc_strcmp(WSO_Name,"T5_LcsAplRlzd")==0)||(tc_strcmp(WSO_Name,"T5_LcsSTDWrkg")==0)||(tc_strcmp(WSO_Name,"T5_LcsStdRlzd")==0))
														{
															validAPLLCSFound++;
														}
														if((tc_strcmp(WSO_Name,"T5_LcsStdRlzd")==0))
														{
															validSTDLCSFound++;
														}
														}
														else if(tc_strcmp(UserAgency,"PUV")==0)
														{
														if((tc_strcmp(WSO_Name,"T5_LcsErcRlzd")==0) ||(tc_strcmp(WSO_Name,"T5_LcsAPLvWrkg")==0) ||(tc_strcmp(WSO_Name,"T5_LcsAplvRlzd")==0)||(tc_strcmp(WSO_Name,"T5_LcsSTDvWrkg")==0)||(tc_strcmp(WSO_Name,"T5_LcsStdvRlzd")==0))
														{
															validERCLCSFound++;
														}
														if((tc_strcmp(WSO_Name,"T5_LcsAplvRlzd")==0)||(tc_strcmp(WSO_Name,"T5_LcsSTDvWrkg")==0)||(tc_strcmp(WSO_Name,"T5_LcsStdvRlzd")==0))
														{
															validAPLLCSFound++;
														}
														if((tc_strcmp(WSO_Name,"T5_LcsStdvRlzd")==0))
														{
															validSTDLCSFound++;
														}
														}
													}
												}
												printf("\n ....111..ppWSO_Name is :%s:%d:%d:%d\n",owning_group_val,validERCLCSFound,validAPLLCSFound,validSTDLCSFound);fflush(stdout);
												/*************COMMENTED BELOW CODE OF ORGANIZATION ID.WILL DO AFTER MANAGEMENT DECISION:REWORK POINT TZ********************/

												if(( ((tc_strstr(owning_group_val,"ERC")!=NULL)||(tc_strstr(owning_group_val,"dba")!=NULL) )&&   (validERCLCSFound>0)) || ( ( tc_strstr(owning_group_val,"APL")!=NULL ) &&   (validAPLLCSFound>0)))
												{
													printf("\n Inside checking NR for Frame Grp %s:%s",DMLtype,Desc_obj_drop_prt);fflush(stdout);
													if(validSTDLCSFound==0)
													{
														if((tc_strcmp(DMLtype,"FrameGrp")==0) && (tc_strstr(Desc_obj_drop_prt,"NR")!=NULL))
														{
															NRCheCkBPS=1;
														}

														if(NRCheCkBPS!=1)
														{
															printf("ERC Released and above Parts With ERC Orgnization and APL Working and above Parts with APL Organisation are allowed to add in Restructuring DML only.");
															EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"ERC Released and above Parts With ERC Orgnization and APL Working and above Parts with APL Organisation are allowed to add in Restructuring DML only.");
															return ITK_errStore1;
														}
													}
												}
												else
												if(tc_strcmp(UserAgency,"CAR")==0)
												{
												if(( ((tc_strstr(owning_group_val,"ERC")!=NULL)||(tc_strstr(owning_group_val,"dba")!=NULL)) &&   ((tc_strcmp(WSO_Name,"T5_LcsErcRlzd")!=0) ||(tc_strcmp(WSO_Name,"T5_LcsAPLWrkg")!=0) ||(tc_strcmp(WSO_Name,"T5_LcsAplRlzd")!=0)||(tc_strcmp(WSO_Name,"T5_LcsSTDWrkg")!=0)||(tc_strcmp(WSO_Name,"T5_LcsStdRlzd")!=0))) || ((tc_strstr(owning_group_val,"APL")!=NULL) &&   ((tc_strcmp(WSO_Name,"T5_LcsAPLWrkg")!=0) ||(tc_strcmp(WSO_Name,"T5_LcsAplRlzd")!=0)||(tc_strcmp(WSO_Name,"T5_LcsSTDWrkg")!=0)||(tc_strcmp(WSO_Name,"T5_LcsStdRlzd")!=0))))
												{
														printf("11..ERC Released and above Parts With ERC Orgnization and APL Working and above Parts with APL Organisation are allowed to add in Restructuring DML only.");
														EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"ERC Released and above Parts With ERC Orgnization and APL Working and above Parts with APL Organisation are allowed to add in Restructuring DML only.");
														return ITK_errStore1;


												}
												}
												else
												{
													tc_strcpy(dmlnumberCpy_val,DMLNumber);
													IsAPLStrDMLRlzErr=0;

													DMLNoCpy = strtok( dmlnumberCpy_val, "_" );
													PlantNameCpy  = strtok ( NULL, "_" );

													GRM_find_relation_type("CMHasSolutionItem",&relation_type_task);
													GRM_list_primary_objects_only(secondary_object,relation_type_task,&count_dml,&PartTaskTags);
													if(count_dml >0)
													{
														for (dml=0;dml<count_dml ;dml++ )
														{
															PartDmlTag=PartTaskTags[dml];
															ITKCALL (TCTYPE_ask_object_type(PartDmlTag,&itemTypeTag_class));
															ITKCALL (TCTYPE_ask_name2(itemTypeTag_class,&type_class));

															printf("\t  type_itemRev of MBOM DML ...%s\n", type_class); fflush(stdout);
															if(tc_strcmp(type_class,"T5_MBOMTASKRevision")==0)
															{
																ITKCALL(AOM_ask_value_string(PartDmlTag, "item_id",&DmlId));
																printf("\n DmlId of MBOM DML %s.....\n",DmlId);fflush(stdout);

																tc_strcpy(ConndmlnumberCpy_val,DmlId);

																ConntPlantNameCpy=subString_mbom(ConndmlnumberCpy_val,14,tc_strlen(ConndmlnumberCpy_val));


																printf("\n PlantNameCpy %s:ConntPlantNameCpy %s.....\n",PlantNameCpy,ConntPlantNameCpy); fflush(stdout);
																if(tc_strcmp(PlantNameCpy,ConntPlantNameCpy)==0)
																{
																	if(tc_strstr(DmlId,"MM")!=NULL)
																	{

																		ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type_1));
																		if (tsk_dml_rel_type_1!=NULLTAG)
																		{
																			ITKCALL(GRM_list_primary_objects_only(PartDmlTag,tsk_dml_rel_type_1,&count_dml_1,&DMLRevision_Prt));
																			printf("\n DML Revision from Task : %d",count_dml_1);fflush(stdout);

																			for (j=0;j<count_dml_1 ;j++ )
																			{
																				ITKCALL(ITEM_rev_sequence_is_latest(DMLRevision_Prt[j],&is_latest_dml));
																				printf("\n is_latest_dml : %d\n",is_latest_dml);fflush(stdout);

																				if(is_latest_dml != true)
																				{
																					printf("\n is_latest_dml is not true .....\n");fflush(stdout);
																				}else
																				{
																					DMLRevTag_Prt = DMLRevision_Prt[j];

																					ITKCALL(AOM_ask_value_string(DMLRevTag_Prt,"t5_MBOMRlzType",&partDmlType));
																					printf("\n partDmlType is :%s",partDmlType);fflush(stdout);
																				}
																			}
																		}



																		//if ((tc_strcmp(partDmlType,"APLSTR")==0) || (tc_strcmp(partDmlType,"APLMBOMRES")==0) || (tc_strcmp(partDmlType,"AMBSTR")==0)|| (tc_strcmp(partDmlType,"CARRYOVER")==0)|| (tc_strcmp(partDmlType,"TOODMLR")==0)|| (tc_strcmp(partDmlType,"K")==0))
																		if ((tc_strcmp(partDmlType,"APLSTR")==0) || (tc_strcmp(partDmlType,"AMBSTR")==0)|| (tc_strcmp(partDmlType,"CARRYOVER")==0)|| (tc_strcmp(partDmlType,"TOODMLR")==0)|| (tc_strcmp(partDmlType,"K")==0) || (tc_strcmp(partDmlType,"MBOM")==0))
																		{
																			ITKCALL(WSOM_ask_release_status_list(DMLRevTag_Prt,&st_count_dml,&dml_status_list));
																			for (dmlstlst = 0; dmlstlst < st_count_dml; dmlstlst++)
																			{
																				AOM_ask_name(dml_status_list[dmlstlst], &ReleaseStatusDML);
																				printf("\n ReleaseStatusDML %s \n",  ReleaseStatusDML);fflush(stdout);
																				if(tc_strcmp(UserAgency,"MBOM")==0)
																				{
																				if(tc_strcmp(ReleaseStatusDML,"T5_LcsStdRlzd")==0)//DEEPTI ADDED 1.34
																				{
																					IsAPLStrDMLRlzErr++;
																				}
																				}
								
																		}
																		}

																	}
																	else
																	{
																		ITKCALL(WSOM_ask_release_status_list(PartDmlTag,&st_count,&status_list));
																		if (st_count == 0)
																		{
																			printf("\n No Status in DML Task, so the Item is not yet Released \n");fflush(stdout);

																		}
																		else
																		{
																			dmlstlst = 0;
																			for (dmlstlst = 0; dmlstlst < st_count; dmlstlst++)
																			{
																				ITKCALL(AOM_ask_value_string(status_list[dmlstlst],"object_name",&class_name));
																				printf("\n class_name: %s\n",class_name);fflush(stdout);
																				if(tc_strcmp(UserAgency,"MBOM")==0)
																				{
																				if(tc_strcmp(class_name,"T5_LcsStdRlzd")==0)//DEEPTI ADDED 1.34
																				{
																					IsAPLStrDMLRlzErr++;

																				}
																				}

																			}
																		}


																	}

																}

															}
														}
													}

												}

											}
											printf("IsAPLStrDMLRlzErr %d",IsAPLStrDMLRlzErr);fflush(stdout);
											if(IsAPLStrDMLRlzErr==0)
											{

												printf("Latest STDSI Released Part from your Plant will be allow to attached in APL Restructuring DML .");fflush(stdout);

												if (tc_strcmp(MRDMLErr,"NULL") !=0) MEM_free(MRDMLErr);
												MRDMLErr=(char *)MEM_alloc(500);
												//tc_strcpy(MRDMLErr,"DML attached to  ");
												tc_strcpy(MRDMLErr,"Part  ");
												tc_strcat(MRDMLErr,part_name);
												tc_strcat(MRDMLErr,",");
												tc_strcat(MRDMLErr,Desc_obj_drop_prt);
												tc_strcat(MRDMLErr," is not STDSI Released from APLDML of your plant.\n");
												tc_strcat(MRDMLErr,"Latest STDSI Released Part from your Plant will be allow to attached in APL Restructuring DML . \n");


												EMH_clear_errors();
												EMH_store_error_s1(EMH_severity_error,ITK_errStore1,MRDMLErr);
												return ITK_errStore1;

											}


										}
									}

									}
									else //ADDED BY DEEPTI 1.34
									{
										printf("DML Is not on WORK ON MBOM DML...");fflush(stdout);
										if (tc_strcmp(MRDMLErr,"NULL") !=0) MEM_free(MRDMLErr);
										MRDMLErr=(char *)MEM_alloc(500);
										tc_strcpy(MRDMLErr,"Task ");
										tc_strcat(MRDMLErr,"is not for assignment of ");
										tc_strcat(MRDMLErr,"'Work On MBOM DML'.");
										tc_strcat(MRDMLErr,"You cannot add parts to SolutionItem of the task.");
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_errStore1,MRDMLErr);
										return ITK_errStore1;
									}

								}
							}
								}
								else
								{
									/*************Start of ERC Cannot Attach Part to APL DML********************/
									if(tc_strstr(roleName,"DBA")!=NULL)
									{

										printf("bypass the code for dba and allow the user to attach the part to AM-DML.." ); fflush(stdout);
									}
									else
									{
										if((tc_strstr(DMLNumber,"MBOM")!=NULL)&&(tc_strstr(DMLNumber,"AM")!=NULL))   //check here
										{
											if ((tc_strcmp(DMLtype,"MBOM")!=0))
											{
													printf("ERC cannot attach a Design Revision to APL DML."); fflush(stdout);
													EMH_clear_errors();
													EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Only APL user can attach a Design Revision to APL DML.");
													return ITK_errStore1;

											}


										}
									}
									/*************END of ERC Cannot Attach Part to APL DML********************/
								}

							}
				}


		/*************Added by Amol********************/

		/*Same  Part with diffrent revision validation *************/
		printf("\n\t Calling amol validation for MBOM.\n");
		fflush(stdout);
		EPM_decision_t decision;
		const char *qryattrs[1];
		const char *qryvalues[1];
		int qry_tags_found = 0;
		int am = 0;
		int sj = 0;
		int Part_count = 0;
		tag_t *qry_tag_found_array = NULLTAG;
		tag_t DMLrevtag = NULLTAG;
		tag_t revtag = NULLTAG;
		tag_t PartTagSol = NULLTAG;
		tag_t *sol_part_tag = NULLTAG;
		char *type_name_value = NULL;
		char *sol_part_no_value = NULL;
		char *taskno_value = NULL;
		char *partno_value = NULL;
		char *MBOM_DMLErr = NULL;


		qryattrs[0] = "item_id";

		ITKCALL(AOM_ask_value_string(primary_object, "item_id", &taskno_value));
		printf("\n\t TASK NO is :%s", taskno_value);
		fflush(stdout);

		qryvalues[0] = (char *)taskno_value;

		if (AOM_ask_value_string(secondary_object, "current_id", &partno_value) == ITK_ok)
		    printf("\n part_No Value :--------------------   %s\n", partno_value);
		fflush(stdout);

		ITKCALL(ITEM_find_items_by_key_attributes(1, qryattrs, qryvalues, &qry_tags_found, &qry_tag_found_array));
		if (qry_tags_found > 0)
		{
		    printf("\n Count: %d", qry_tags_found);
		    fflush(stdout);

		    for (am = 0; am < qry_tags_found; am++)
		    {

		        DMLrevtag = qry_tag_found_array[am];
		        ITKCALL(ITEM_ask_latest_rev(DMLrevtag, &revtag));
		        ITKCALL(AOM_ask_value_string(revtag, "object_type", &type_name_value));
		        printf("\n     object  type_name :: %s\n", type_name_value);
		        fflush(stdout);

		        if (tc_strcmp(type_name_value, "T5_MBOMTASKRevision") == 0)
		        {
		            ITKCALL(AOM_ask_value_tags(revtag, "CMHasSolutionItem", &Part_count, &sol_part_tag));
		            printf("\n Total No of Part attached to this task is : %d", Part_count);
		            fflush(stdout);
		            for (sj = 0; sj < Part_count; sj++)
		            {
		                PartTagSol = sol_part_tag[sj];
		                ITKCALL(AOM_ask_value_string(PartTagSol, "item_id", &sol_part_no_value));
		                printf("\n   Part no inside task :: %s\n", sol_part_no_value);
		                fflush(stdout);
		                if (tc_strcmp(sol_part_no_value, partno_value) == 0)
		                {
		                    printf("\n same part Number matched valiadtion will pop up to the user");
		                    fflush(stdout);
		                    MBOM_DMLErr = NULL;
		                    MBOM_DMLErr = (char *)MEM_alloc(200);
		                    tc_strcpy(MBOM_DMLErr, "Part No:-");
		                    tc_strcat(MBOM_DMLErr, sol_part_no_value);
		                    tc_strcat(MBOM_DMLErr, " Is Already Attached with this MBOM DML / Task");
		                    EMH_clear_errors();
		                    EMH_store_error_s1(EMH_severity_error, ITK_errStore1, MBOM_DMLErr);
		                    decision = EPM_nogo;
		                    return ITK_errStore1;
		                }
		            }
		        }
		    }
		}

	  /*Same  Part with diffrent revision validation *************/
		/*************ADDED BY AMOL********************/

		}
			if(DMLRevision)
					MEM_free(DMLRevision);

		return error_code;

}

extern  int DLLAPI mbom_dml_gmdml_part_attach( METHOD_message_t *msg, va_list args )
{
	int error_code	= ITK_ok;
	char   type_name[TCTYPE_name_size_c+1];
	char   type_name2[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
    tag_t	objTypeTag		= NULLTAG;
	tag_t	Sec_objTypeTag	= NULLTAG;
    tag_t  CurrentRoleTag = NULLTAG;
	tag_t  tsk_dml_rel_type = NULLTAG;
	tag_t  DMLRevTag = NULLTAG;
	tag_t class_id=NULLTAG;
	tag_t master=NULLTAG;
    tag_t*  DMLRevision = NULLTAG;
	tag_t*  MBOMstatus_list = NULLTAG;
	tag_t  CtrlObjQry = NULLTAG;
    char*	prim_type_name	= NULL;
	char*	sec_type_name	= NULL;
	char	*roleName =NULL;
	char*			GMDMLErr	= NULL;
	char*			part_name	= NULL;
	char*			class_name	= NULL;
	char*			DMLtype	= NULL;
	char*			DMLDRStatus	= NULL;
	char*			DMLNumber	= NULL;
	char*			DMLFrmToDR	= NULL;
	char*			owning_group_val	= NULL;
	char*			owning_user_val	= NULL;
	char*			part_DRStatus	= NULL;
	char*			FromDR	= NULL;
    char*			TaskAnlyst	= NULL;
	char*			MMtaskValid	= NULL;
	char*	TaskAnlystUserID	= NULL;
	char*			username	= NULL;
	char*			TskAnalystErr	= NULL;
	char*			LatestPartDropErr	= NULL;
	char*			LatestPartRevID	= NULL;
	char*			SecObjRevId	= NULL;
	char*           Release_status_list=NULL;
	char*			part_type	= NULL;
	char*			GMDMLPrtErr	= NULL;
	char*			Owning_user	= NULL;
	char*           PartNo =NULL;
    int		count	= 0; 
	int		Flag_dr	= 0; 
	int		j	= 0; 
	int		BypassFlag	= 0;
	logical  	t5InProcess ;
	char    *qry_entryCntrl1[3]  		= {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1			= (char **) MEM_alloc(5 * sizeof(char *));
    tag_t latestrev = NULLTAG;
	char *NextRev =NULL;
	char *drop_prt_rev =NULL;
	int st_count_next_rev = 0;
	tag_t *status_list_nextRev = NULLTAG;
	int cnt_next=0;
	char *WSO_Name_next_Rev =NULL;
	int GM_MBOM_Rel_status_flag = 0;
	char *MBOM_Rel_status_list = NULL;
	int part_st_count = 0;
	tag_t*    GM_MBOMstatus_list = NULLTAG;
	int iii = 0;
	int ii =0;

	printf("\n Calling GMDML Release Function.\n"); fflush(stdout);

	tag_t  primary_object = va_arg(args, tag_t);
	tag_t  secondary_object = va_arg(args, tag_t);
	tag_t  relation_type = va_arg(args, tag_t);
    tag_t	objTypeTag2	= NULLTAG;
	tag_t	*cntr_objects	= NULLTAG;
	int control_Object_Count	= 0;
	ITKCALL(QRY_find2("Control Objects...", &CtrlObjQry));
	qry_valuesCntrl1[0]="GMDML";
	qry_valuesCntrl1[1]="Partattach";
	qry_valuesCntrl1[2]="0";

	ITKCALL(QRY_execute(CtrlObjQry, 3, qry_entryCntrl1, qry_valuesCntrl1, &control_Object_Count, &cntr_objects));
	printf("\n MB/MM DML Control Object found : %d",control_Object_Count);fflush(stdout);

	if(control_Object_Count > 0)
	{
	
	printf("\n Calling A9_ValidationAtMMDML running.\n"); fflush(stdout);

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

	ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
	if (tsk_dml_rel_type!=NULLTAG)
	{
		ITKCALL(GRM_list_primary_objects_only(primary_object,tsk_dml_rel_type,&count,&DMLRevision));
		printf("\n Total Task found is : %d",count);fflush(stdout);
	}

	
	for (j=0;j<count;j++ )
	{
		DMLRevTag = DMLRevision[j];

		ITKCALL(POM_class_of_instance(DMLRevTag,&class_id));
		ITKCALL(POM_name_of_class(class_id,&class_name));
		printf("\n class_name is :%s",class_name); fflush(stdout);

		if(tc_strcmp(class_name,"T5_MBOMDMLRevision")==0)
		{
			ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_MBOMRlzType",&DMLtype));
			printf("\n APLDMLtype is :%s",DMLtype); fflush(stdout);

			if(tc_strcmp(DMLtype,"GM_MMDML") == 0)
			{
				ITKCALL(AOM_ask_value_string(secondary_object,"item_id",&PartNo));
				printf("\n PartNo :%s",PartNo); fflush(stdout);

				ITKCALL(AOM_UIF_ask_value(secondary_object,"owning_group",&owning_group_val));
				printf("\n owning_group_val is :%s",owning_group_val); fflush(stdout);

				ITKCALL(AOM_UIF_ask_value(secondary_object,"owning_user",&Owning_user));
				printf("\n Owning_user is_123 :%s",Owning_user); fflush(stdout);

				ITKCALL(AOM_ask_value_string(secondary_object, "current_revision_id", &drop_prt_rev));
				printf("\n drop_prt_rev Value :%s\n", drop_prt_rev);fflush(stdout);

				if((tc_strcmp(owning_group_val, "MBOM") == 0) ||((tc_strcmp(owning_group_val, "dba") == 0) && (tc_strcmp(Owning_user, "APL Loader (aplloader)") ==0)) )
				 {
				  
				  tm_fnd_Next_revision(PartNo, secondary_object, &latestrev);
				  if(latestrev != NULLTAG)
				  {
					ITKCALL(AOM_ask_value_string(latestrev, "current_revision_id", &NextRev));
					printf("\n NextRev Value :--------------------   %s\n", NextRev);fflush(stdout);

					if(tc_strcmp(drop_prt_rev, NextRev) == 0)
					{
						printf("Dropped object is latest Rev..");fflush(stdout);
						
						ITKCALL(WSOM_ask_release_status_list(secondary_object,&part_st_count,&GM_MBOMstatus_list));
						
						printf("\n Part status count is  : %d\n",part_st_count);fflush(stdout);
						if(part_st_count > 0)
						{
							
							GM_MBOM_Rel_status_flag = 0;
							MBOM_Rel_status_list = NULL;

							for (iii =0; iii <part_st_count; iii++)
							{
								ITKCALL(AOM_ask_name(GM_MBOMstatus_list[iii],&MBOM_Rel_status_list));
								printf("\n Part current release status is: %s\n",MBOM_Rel_status_list);fflush(stdout);
								if(tc_strcmp(MBOM_Rel_status_list,"T5_MBOMReleased") == 0)
								{ 
									printf("\n dropped part is  lastest & mbom released.");fflush(stdout);
									GM_MBOM_Rel_status_flag++;
									break;
								}
							}
							if(GM_MBOM_Rel_status_flag==0)
							{
							   printf("\n dropped part is not the lastest part-0");fflush(stdout);
							   LatestPartDropErr = NULL;
							   LatestPartDropErr = (char *)MEM_alloc(500);
							   tc_strcpy(LatestPartDropErr,"Latest Part is not MBOM Release.");
							   EMH_clear_errors();
							   EMH_store_error_s1(EMH_severity_error,ITK_errStore1,LatestPartDropErr);
							   return ITK_errStore1;
							}
													
						}
									
					}
					else
					{
						ITKCALL(WSOM_ask_release_status_list(latestrev, &st_count_next_rev, &status_list_nextRev));
						printf("\n st_count_next_rev :%d is\n", st_count_next_rev);fflush(stdout);
						if(st_count_next_rev>0)
						{
						  for(cnt_next = 0; cnt_next < st_count_next_rev; cnt_next++)
						   {
							   WSO_Name_next_Rev = NULL;
							   ITKCALL(AOM_ask_name(status_list_nextRev[cnt_next], &WSO_Name_next_Rev));
							   printf("\n WSO_Name_next_Rev is :%s\n", WSO_Name_next_Rev);fflush(stdout);
							   if(tc_strcmp(WSO_Name_next_Rev,"T5_MBOMReleased") == 0)
							   {
									printf("\n dropped part is not the lastest part");fflush(stdout);
									LatestPartDropErr = NULL;
									LatestPartDropErr = (char *)MEM_alloc(500);
									tc_strcpy(LatestPartDropErr,"Drag & Drop of part is not allowed. As next revision of part ");
									tc_strcat(LatestPartDropErr,PartNo);
									tc_strcat(LatestPartDropErr," is already MBOM Released.");
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_errStore1,LatestPartDropErr);
									return ITK_errStore1;

							   }
							   else
							   {

									part_st_count=0;
									GM_MBOMstatus_list=NULLTAG;
									ITKCALL(WSOM_ask_release_status_list(secondary_object,&part_st_count,&GM_MBOMstatus_list));
						
									printf("\n Part status count is  : %d\n",part_st_count);fflush(stdout);
									if(part_st_count > 0)
									{
										
										MBOM_Rel_status_list = NULL;
										GM_MBOM_Rel_status_flag =0;

										for (ii =0; ii <part_st_count; ii++)
										{
											ITKCALL(AOM_ask_name(GM_MBOMstatus_list[ii],&MBOM_Rel_status_list));
											printf("\n Part current release status is: %s\n",MBOM_Rel_status_list);fflush(stdout);
											if(tc_strcmp(MBOM_Rel_status_list,"T5_MBOMReleased") == 0)
											{ 
												printf("\n dropped part is mbom released-2.");fflush(stdout);
												GM_MBOM_Rel_status_flag++;
												
												break;
											}
										}
										if(GM_MBOM_Rel_status_flag==0)
										{
										   printf("\n dropped part is not mbom release-3");fflush(stdout);
										   LatestPartDropErr = NULL;
										   LatestPartDropErr = (char *)MEM_alloc(500);
										   tc_strcpy(LatestPartDropErr,"Part is not MBOM Release. Add MBOM Release part only.");
										   EMH_clear_errors();
										   EMH_store_error_s1(EMH_severity_error,ITK_errStore1,LatestPartDropErr);
										   return ITK_errStore1;
										}

									}
							  }
						   }
											
						}
									
					}
				  }
				 }
				  
			}
		}
     }
    }
	else{
		printf("\n No control objects are found \n");
	
	}
		
return error_code;
}

void  get_CtrlVal_MBOMLcsInf( char * Tsk_Own_Grp ,char  RevRuleInfo1[40],char  BVRInfo2[40],char  CurMskInfo3[40])
{
	 printf("\n ************** Ketan Inside get_CtrlVal_MBOMLcsInf ***************\n ");fflush(stdout);

	 char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	 char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *RevRule 			= NULL;
	 char *viewfrmCtrl		= NULL;
	 char *CurVwMask		= NULL;
	 //char *Info4Ctrl		= NULL;
	 //char *Info5Ctrl		= NULL;
	// char *Info6Ctrl		= NULL;
	// char *Info7Ctrl		= NULL;
	// char *Info8Ctrl		= NULL;
	// char *Info9Ctrl		= NULL;

	 if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLLcsInf";
				qry_valuesCntrl1[1]=Tsk_Own_Grp;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{
				
				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &RevRule);
				printf("\n RevRule: %s\n",RevRule);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &viewfrmCtrl);
				printf("\n viewfrmCtrl: %s\n",viewfrmCtrl);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &CurVwMask);
				printf("\n CurVwMask: %s\n",CurVwMask);fflush(stdout);

				tc_strcpy(RevRuleInfo1,RevRule);
				tc_strcpy(BVRInfo2,viewfrmCtrl);
				tc_strcpy(CurMskInfo3,CurVwMask);
					
			}
			else
			{
				//tc_strcpy(RevRuleInfo1,"ERC release and above");
				tc_strcpy(RevRuleInfo1,"MBOM Release and Above");//Deepti TZ1.55
				tc_strcpy(BVRInfo2,"MBOM View");
				tc_strcpy(CurMskInfo3,"bl_occ_t5_CurrentViewMaskM");
			}
}

int mbom_Child_Part_Rev_Checks(tag_t	task_rev_tag,int PartCnt, tag_t* PartTags,char	***SetChildRelErr,char* PlantCS,char*  closureRuleName,int *icount)
{
	
			EPM_decision_t decision;
			tag_t			AssyTag				= NULLTAG;
			char*			Part_no				= NULL;
			char*			Task_no				= NULL;
			 tag_t	item_rev_tag_p						= NULLTAG;
			char*		Part_type			=	NULL;
			char*			Part_CS				= NULL;
	        int n=0,j=0;
	        int count1 = 0;
	        int Flag = 0;
			int	ifail=0;
			tag_t	window								= NULLTAG;
			tag_t	rule								= NULLTAG;
			tag_t	top_line							= NULLTAG;
			tag_t	Childtop_line							= NULLTAG;
			tag_t  *children;
			tag_t  *totalchildren;
	        int   attribute_act_tak;
	        tag_t  	value_act_Tak;
	        int k = 0,Item_ID=0,childCnt=0;
	        char *Item_id = NULL;
         	tag_t	itemcldclass							= NULLTAG;
			char *Item_rev = NULL;
			char *Item_LCS = NULL;
			char *Item_Lcs_str = NULL;
         	tag_t  	item_rev_cld_tag_orig;
			tag_t  	item_rev_cld_tag;
	        int       st_count=0;
	        tag_t*    status_list;
	        char *  ChildRelErr = NULL;
			int       iLCS=0;
			int       cntLcs=0;
	       char* class_name=NULL;
    	   int	cntTask=0,iTask=0;
		   tag_t*  	prtTasks			=	NULLTAG;
		   tag_t  		prtTask				=	NULLTAG;
		   tag_t  		prtTask_Class		=	NULLTAG;
		   char*		prtTask_type		=	NULL;
		   char*		prtTaskName			=	NULL;
	        tag_t	relation_type = NULLTAG;
	        int count = 0;
			 int ii = 0;
	        tag_t *  rev_list;
			size_t	prtTaskLen	=	0;
			tag_t  CurrentRoleTag = NULLTAG;
			//char       roleName[SA_name_size_c+1];
			char*		roleName			=	NULL;
			char PlantIA[40];
			char PlantStore[40];
			char UserAgency[40];
			char ClosureRule[40];
	        char PlantOptCS[40];
	        char usrLocation[40];
			struct			BomChldStrut	ChldStrutBdySh[5000];
			int	StructCntBdyShProdPlan	= 0;
			int   childBS=0;
			tag_t objChild_BS		= NULLTAG;
			int	 iChildItemTag_BS	= 0;
			tag_t t_ChildItemRev_BS	= NULLTAG;
			char   *taskowning_groupVal=NULL;
			char   *Item_rev_Part_type=NULL; //TZ1.42 Deepti
			char   *Item_rev_ProjCode=NULL; //TZ1.42 Deepti

			// Added by Dhanashri // UATZ1.46
			char			*Cur_revision		= NULL;
			char			*Prtnoo		= NULL;
			char*		prtTask_type1		=	NULL;
			char*		prtTaskName1			=	NULL;
			char*		DMLNumberr				= NULL;
			char GetPlant[40];
			char GetPlant1[40];
			
			char*		DMLTyp				= NULL;
			//char			DMLTyp[TCTYPE_name_size_c+1];

		    tag_t  		prtTask1				=	NULLTAG;
		    tag_t  		prtTask_Class1		=	NULLTAG;
		    tag_t*  	prtTasks1			=	NULLTAG;

			int	cntTask1=0;
			int	iTask1=0;
			int	FlagGotDML=0;

			 tag_t			TskToDMLRel= NULLTAG;
			 tag_t			DMLRevTagg		= NULLTAG;
			 tag_t			DMLTypeTag		= NULLTAG;
			 tag_t*			DMLTagg		= NULLTAG;
			 
			 int CountDML=0;
			 int Counter=0;
			 
			 logical			isltstdmll;

			 char RevRuleInfo1[40];
			 char BVRInfo2[40];
					char	*designBORev		=	NULL;
					char	*designBO			=	NULL;

			//			 char    *qry_entryCntrl2[3]  = {"SYSCD","Information-5","Delete Indicator"};	
			//			 char	**qry_valuesCntrl2= (char **) MEM_alloc(5 * sizeof(char *));
			//
			//			 int cntrlcnt2=0;
			//			 int  control_number_found2=0;
			//
			//			 tag_t *list_of_WSO_cntrl_tags2=NULLTAG;
			//
			//			 tag_t   qryTagCntrl2     = NULLTAG;
			//			 int     n_entryCntrl2    = 3;	 
			char *Item_rev_ClrInd	=	NULL;
			char AplRvwLC[40];
			char AplWrkngLC[40];
			char AplRlzd[40];
			char Stdwrknglc[40];
			char Stdrlzdlc[40];
			char PltLcs[40];
			char StdPlant[40];
			char StdRevRule[40];
			char StdCLosRule[40];
			char StdView[40];
			 
			// End Of Code Added by Dhanashri // UATZ1.46

			printf("\n ************** Ketan Inside mbom_Child_Part_Rev_Checks ***************\n ");fflush(stdout);

           	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
			ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
			printf("\n\n  roleName : %s\n",roleName); fflush(stdout);


			//getPlantDetailsAttr(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency,ClosureRule,usrLocation);
			mbom_getPlantDetailsAttr(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency,ClosureRule,usrLocation);

			printf("\n PlantCS %s \n",PlantCS);fflush(stdout);
			printf("\n PlantAgency %s \n",PlantIA);fflush(stdout);
			printf("\n PlantStore %s \n",PlantStore);fflush(stdout);
			printf("\n UserAgency %s \n",UserAgency);fflush(stdout);
			printf("\n ClosureRule %s \n",ClosureRule);fflush(stdout); 
			printf("\n usrLocation %s \n",usrLocation);fflush(stdout); 
	

		//**********TZ3.46*********************//
		char *PlantNameP=NULL;
		PlantNameP=subString_mbom(roleName,3,4);
		printf( "PlantNameP:%s\n", PlantNameP);  
		
		//get_CtrlVal_APLStateInf(PlantNameP,"","",AplRlzd,"","","","","","","");//TZ1.46//Priti
		//get_CtrlVal_APLStateInf(PlantNameP,AplRvwLC,AplWrkngLC,AplRlzd,Stdwrknglc,Stdrlzdlc,PltLcs,StdPlant,StdRevRule,StdCLosRule,StdView);//TZ1.46//Priti

		//***********************************//

			 //Start for Child check
			for (k=0;k<PartCnt ;k++ )
			{
			//const char *qry_entries[1];
			//const char *qry_values[1];

			const char *qry_entries[2];//Multiple Item Queried Error Hemal
			const char *qry_values[2];//Multiple Item Queried Error Hemal

			int n_tags_found1=0;
			int BypassNACSFlag=0;
			 tag_t	*itemclass1							= NULLTAG;
			 tag_t	itemclassp1							= NULLTAG;

			printf("\n MBOM DML for k =:%d",k);fflush(stdout);
			AssyTag=PartTags[k];
			//BypassNACSFlag = NA_CS_Bypass_Checks(PartCnt,AssyTag,PlantCS);
			//printf("\t  BypassNACSFlag ...%d\n", BypassNACSFlag);
			//if(BypassNACSFlag == 1)
			//{
			//	printf("\t  Bypass Validations .\n");
			//	continue;
			//}
			//else
			//{
			//	printf("\t  Call Validations .\n");
			//}

	   	   ITKCALL(AOM_ask_value_string(task_rev_tag,"item_id",&Task_no));
		   printf("\t  Task_no ...%s\n", Task_no);fflush(stdout);

			GetPlantForDMLORTask(Task_no,GetPlant);
			printf("\n Hi GetPlant : %s",GetPlant);fflush(stdout);

			ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
			printf("\n MBOM DML Part_no  is :%s",Part_no);	fflush(stdout);
			//Below Commented code is not required as item_rev_tag_p is not used in code.
			//qry_entries[0] ="item_id";
			//qry_entries[1] ="object_type";//Multiple Item Queried Error Hemal
			//qry_values[0] =(char *)Part_no;
			//qry_values[1] ="Design";//Multiple Item Queried Error Hemal

			//ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found1, &itemclass1);
			//ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found1, &itemclass1);//Multiple Item Queried Error Hemal
			//printf("\n  n_tags_found1 [%d] ..............",n_tags_found1);fflush(stdout);
			//if(n_tags_found1>0)
			//itemclassp1 = itemclass1[0];

				ITKCALL(AOM_UIF_ask_value(AssyTag,"owning_group",&taskowning_groupVal));
				printf("\n  taskowning_groupVal => %s ..............\n",taskowning_groupVal);fflush(stdout);

				char Info3[40];
				//get_CtrlVal_APLLcsInf(taskowning_groupVal,RevRuleInfo1,BVRInfo2,Info3);//TZ3.46
				get_CtrlVal_MBOMLcsInf(taskowning_groupVal,RevRuleInfo1,BVRInfo2,Info3);//TZ3.46

				printf("\n Ketan closureRuleName => %s \n",closureRuleName);fflush(stdout);
				printf("\n Ketan RevRuleInfo1 => %s \n",RevRuleInfo1);fflush(stdout);
				printf("\n Ketan BVRInfo2 => %s \n",BVRInfo2);fflush(stdout);
				printf("\n Ketan Info3 => %s \n",Info3);fflush(stdout);



				//Added by sanjay
				// Control Object for Unconfigured Revision Check in APL
				char    *qryEntry[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
				char    *qryValues[3]= {"MBOM","UNCONFIGURED","0"};
				
				tag_t qryTagAplChk=NULLTAG;
				int qryCount=0;
				tag_t* qryResult=NULLTAG;
	 
				ITKCALL(QRY_find2("Control Objects...", &qryTagAplChk));
				if (qryTagAplChk)
				{
					printf("\n Control Object Query Found \n Going to call unconfigured Revision Check \n");fflush(stdout);
					ITKCALL(QRY_execute(qryTagAplChk, 3, qryEntry, qryValues, &qryCount, &qryResult));
					printf("\n Query Count for Unconfigured Revision is : %d\n",qryCount);fflush(stdout);
				}
				// Control Object for Unconfigured Revision Check in APL Code Ends for Control Object Check
	 
	 
	 
				if(qryCount>0) //  APL Unconfigured BOM Check
				{
					StructCntBdyShProdPlan = 0;
					ITKCALL(Get_Part_BOM_Lvl_Unconfigured(AssyTag,1,closureRuleName,RevRuleInfo1,BVRInfo2,ChldStrutBdySh,&StructCntBdyShProdPlan));
					printf("\n\t\t StructCntBdyShProdPlan:%d", StructCntBdyShProdPlan);fflush(stdout);
				}
				else{
					
					
					StructCntBdyShProdPlan = 0;
					ITKCALL(Get_Part_BOM_Lvl(AssyTag,1,closureRuleName,RevRuleInfo1,BVRInfo2,ChldStrutBdySh,&StructCntBdyShProdPlan));
					printf("\n\t\t StructCntBdyShProdPlan:%d", StructCntBdyShProdPlan);fflush(stdout);
				}// APL Unconfigured BOM Check - Code Ends


				//StructCntBdyShProdPlan=0;
				//ITKCALL(Get_Part_BOM_Lvl(AssyTag,1,closureRuleName,RevRuleInfo1,BVRInfo2,ChldStrutBdySh,&StructCntBdyShProdPlan));
				//printf("\n StructCntBdyShProdPlan:%d",StructCntBdyShProdPlan);fflush(stdout);

				childBS = 0;
				for (childBS = 1; childBS <= StructCntBdyShProdPlan; childBS++)
				{

				//const char *qry_entries[1];
				//const char *qry_values[1];

				const char *qry_entries[1];//Multiple Item Queried Error Hemal
				const char *qry_values[1];//Multiple Item Queried Error Hemal
				char	*CDMLNum	=	NULL;
				int n_tags_found2=0;
				tag_t	*itemclass2							= NULLTAG;
				cntLcs	=	0;

				objChild_BS		= NULLTAG;

				iChildItemTag_BS	= 0;
				t_ChildItemRev_BS	= NULLTAG;
				printf("\n111 Print Item ID==>%d,%d\n",childBS,StructCntBdyShProdPlan);fflush(stdout);

				objChild_BS=ChldStrutBdySh[childBS].child_objs;

				AOM_UIF_ask_value(objChild_BS,"item_id",&Item_id);
				printf("\n Child Part String is Item_id-->%s",Item_id);
				Item_rev_ClrInd	=	NULL;
				ITKCALL(AOM_ask_value_string(objChild_BS,"t5_ColourInd",&Item_rev_ClrInd));
				printf("\n Item_rev_ProjCode  is :%s",Item_rev_ClrInd);	fflush(stdout);

				designBORev		=	NULL;     
				designBO			=	NULL;     			
				getDesignType(objChild_BS, &designBORev,&designBO);
				printf("\n 111111After getDesignType : %s",designBO);fflush(stdout);

				qry_entries[0] ="item_id";
				//qry_entries[1] ="object_type";//Multiple Item Queried Error Hemal
				qry_values[0] = Item_id;
				//if (tc_strcmp(Item_rev_ClrInd,"C")==0)
				//{
					//qry_values[1] = "Colour Part";
					//qry_values[1] = "T5_ClrPart";
				//}
				//else
				//{
					//qry_values[1] = "Design";
					//Handle the different design child class.
					//tag_t	AssyTag			=	NULLTAG;
					//AssyTag=PartTags[k];
					printf("\nBefore getDesignType");fflush(stdout);
					designBORev		=	NULL;     
					designBO			=	NULL;     			
					getDesignType(objChild_BS, &designBORev,&designBO);
					printf("\nAfter getDesignType : %s",designBO);fflush(stdout);
					//qry_values[1] = designBO;

				//}//Multiple Item Queried Error Hemal

				//ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found2, &itemclass2);
				ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found2, &itemclass2);//Multiple Item Queried Error Hemal
				//itemcldclass = itemclass2[0];
				tag_t	item2						= NULLTAG;
				int t=0;
						for (t=0;t<n_tags_found2 ; t++)
							{
								char	*designBORevEE		=	NULL;
							   char	*designBOEE			=	NULL;
								item2 = itemclass2[t];
								tag_t itemltRev = NULLTAG;
			                 	ITKCALL(ITEM_ask_latest_rev(item2,&itemltRev));
							printf("\n Before getDesignType for EE parts");fflush(stdout);
							getDesignType(itemltRev, &designBORevEE,&designBOEE);
							printf("\nAfter getDesignType for EE parts : %s",designBOEE);fflush(stdout);
						if (tc_strcmp(designBO,designBOEE)==0)
							{
								   itemcldclass = itemclass2[t];
								CALLAPI(ITEM_list_all_revs (itemcldclass, &count1, &rev_list)); 
							}

							}


				AOM_UIF_ask_value(objChild_BS,"item_revision_id",&Item_rev);
				printf("\n Child Part String is Item_rev--->%s",Item_rev);

				ITKCALL(AOM_ask_value_string(objChild_BS,"t5_PartType",&Item_rev_Part_type));
				printf("\n Item_rev_Part_type  is :%s",Item_rev_Part_type);	fflush(stdout);

				//if( (strcmp(Item_rev_Part_type,"D")==0) || (strcmp(Item_rev_Part_type,"DC")==0) || (strcmp(Item_rev_Part_type,"DA")==0) ) //DEEPTI //TZ1.45Priti
				if( (strcmp(Item_rev_Part_type,"D")==0) || (strcmp(Item_rev_Part_type,"DC")==0) || (strcmp(Item_rev_Part_type,"DA")==0)||(strcmp(Item_rev_Part_type,"IM")==0)) //venkat added part type is IFD module
				{
					printf("\n Child Part Validation Bypass for Dummy Part Type..");	fflush(stdout);
					continue;
				}

				ITKCALL(AOM_ask_value_string(objChild_BS,"t5_ProjectCode",&Item_rev_ProjCode));
				printf("\n Item_rev_ProjCode  is :%s",Item_rev_ProjCode);	fflush(stdout);

				if( (strcmp(Item_rev_ProjCode,"1111")==0) ) //DEEPTI
				{
					printf("\n Child Part Validation Bypass for Standard Part ..");	fflush(stdout);
					continue;
				}


				//				ITKCALL(ITEM_ask_latest_rev(itemcldclass,&item_rev_cld_tag_orig));
				
				
				//				ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
				//				ITKCALL( GRM_list_primary_objects_only(item_rev_cld_tag_orig,relation_type,&cntTask,&prtTasks));
				//				printf("\nNo Of Task Found : %d",cntTask);fflush(stdout);
				//				if (cntTask>0)
				//				{
				//					for (iTask=0;iTask<cntTask;iTask++)
				//					{
				//						prtTask	=	prtTasks[iTask];
				//						ITKCALL (TCTYPE_ask_object_type(prtTask,&prtTask_Class));
				//						ITKCALL (TCTYPE_ask_name2(prtTask_Class,&prtTask_type));
				//
				//						printf("\nprtTask_type : %s",prtTask_type);fflush(stdout);
				//
				//						//if(tc_strcmp(type_class,"A9_APLTaskRevision")==0)
				//						if(tc_strcmp(prtTask_type,"T5_MBOMTASKRevision")==0)
				//						{
				//							prtTaskName	=	NULL;
				//							ITKCALL( AOM_ask_value_string(prtTask,"item_id",&prtTaskName));
				//							printf("\nprtTaskName : %s",prtTaskName);fflush(stdout);
				//							if (tc_strcmp(prtTaskName,Task_no)==0)
				//							{
				//								printf("\n Part attached to same task...!!!");fflush(stdout);
				//								cntLcs ++;
				//								break;
				//
				//							}
				//							prtTaskLen	=	tc_strlen(prtTaskName);
				//							if (prtTaskLen>0)
				//							{
				//								MEM_free(prtTaskName);
				//							}
				//						}
				//					}
				//					if (cntTask>0)
				//					{
				//						MEM_free(prtTasks);
				//					}
				//				}
				//Above code check the latest revision only, Due to that child validation on working so commented out.
				//Check all revision and any of the revision attached with same DML, by pass the child check. Hemal
				//ITEM_list_all_revs  (itemcldclass, &count1,  &rev_list );
				Flag = 0;
				printf("\n count1:%d \n",count1);fflush(stdout);
				ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
				for(ii = 0; ii < count1; ii++)
				{
					item_rev_cld_tag_orig	=	NULLTAG;
					cntTask		=	0;
					cntLcs		=	0;
					prtTasks	=	NULLTAG;
					item_rev_cld_tag_orig	=	rev_list[ii];

					// Added by Dhanashri // UATZ1.46
					Prtnoo=NULL;
					ITKCALL(AOM_ask_value_string(item_rev_cld_tag_orig,"item_id",&Prtnoo));
					printf("\n Prtnoo  is :%s",Prtnoo);	fflush(stdout);

					Cur_revision=NULL;
					ITKCALL(AOM_ask_value_string(item_rev_cld_tag_orig, "item_revision_id",&Cur_revision));
					printf("\n Cur_revision %s.....\n",Cur_revision);
					// End Of Code Added by Dhanashri // UATZ1.46

					ITKCALL( GRM_list_primary_objects_only(item_rev_cld_tag_orig,relation_type,&cntTask,&prtTasks));
					printf("\nNo Of Task Found : %d",cntTask);fflush(stdout);
					if (cntTask>0)
					{
						for (iTask=0;iTask<cntTask;iTask++)
						{
							prtTask_Class	=	NULLTAG;
							prtTask_type	=	NULL;
							prtTask			=	prtTasks[iTask];
							ITKCALL (TCTYPE_ask_object_type(prtTask,&prtTask_Class));
							ITKCALL (TCTYPE_ask_name2(prtTask_Class,&prtTask_type));
							printf("\nprtTask_type : %s",prtTask_type);fflush(stdout);

							if(tc_strcmp(prtTask_type,"T5_MBOMTASKRevision")==0)
							{
								prtTaskName	=	NULL;
								ITKCALL( AOM_ask_value_string(prtTask,"item_id",&prtTaskName));
								printf("\nprtTaskName : %s",prtTaskName);fflush(stdout);

								//char	*CDMLNum	=	NULL;
								CDMLNum= strtok( prtTaskName, "_" );
								printf("\nCDML NUMBER: %s",CDMLNum);fflush(stdout);

								//if (tc_strcmp(prtTaskName,Task_no)==0)
								//Added the or condition, If the part is in other task of same.
								if (tc_strcmp(prtTaskName,Task_no)==0 || tc_strstr(Task_no,CDMLNum)!=NULL)
								{
									printf("\n Part attached to same task...!!!");fflush(stdout);
									cntLcs ++;
								}
								prtTaskLen	=	tc_strlen(prtTaskName);
								if (prtTaskLen>0)
								{
									MEM_free(prtTaskName);
								}
								if(cntLcs>0)
								{
									break;
								}
							}
						}
					}
					if (cntTask>0)
					{
						MEM_free(prtTasks);
					}
					if(cntLcs>0)
					{
						break;
					}
				}
				printf("\n Part attached cntLcs : %d",cntLcs);fflush(stdout);
				if(cntLcs<=0)
				{
					ii = 0;
					FlagGotDML = 0;
					for (ii = 0; ii < count1; ii++)
					{
						item_rev_cld_tag = rev_list[ii];
						Prtnoo=NULL;
						ITKCALL(AOM_ask_value_string(item_rev_cld_tag,"item_id",&Prtnoo));
						printf("\n hi Prtnoo  is :%s",Prtnoo);	fflush(stdout);

						Cur_revision=NULL;
						ITKCALL(AOM_ask_value_string(item_rev_cld_tag, "item_revision_id",&Cur_revision));
						printf("\n hi Cur_revision %s.....\n",Cur_revision);

						ITKCALL(WSOM_ask_release_status_list(item_rev_cld_tag,&st_count,&status_list));
						printf("\n st_count:%d \n",st_count);fflush(stdout);
						//Commented, will declare where we display the error
						//						if (tc_strcmp(ChildRelErr,"NULL") !=0) MEM_free(ChildRelErr);
						//						ChildRelErr=(char *)MEM_alloc(100);
						//						tc_strcpy(ChildRelErr," ");
						if (st_count == 0)  /* No Status, so the Item is not yet Released */
						{
							printf("\n No Status, so the Item is not yet Released \n");fflush(stdout);

						}
						else
						{
								for (iLCS=0;iLCS<st_count ;iLCS++ )
								{
									ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
									printf("\n class_name: %s\n",class_name);fflush(stdout);

									//if(tc_strcmp(class_name,AplRlzd)==0) //TZ3.46
									//{
									//	cntLcs++;
									//	break;
									//}									
									if(tc_strcmp(UserAgency,"MBOM")==0)
									{
										if(tc_strcmp(class_name,"T5_MBOMReleased")==0)
										{
											cntLcs++;
											break;
										}
									}
									//									else if(tc_strcmp(UserAgency,"PUV")==0)
									//									{
									//										if(tc_strcmp(class_name,"T5_LcsAplvRlzd")==0)
									//										{
									//											cntLcs++;
									//											break;
									//										}
									//									}
								}
						}

						// Added by Dhanashri // UATZ1.46
						//Getting DML from Child partnumber
						printf("\n cntLcs: %d\n",cntLcs);fflush(stdout);
						printf("\n FlagGotDML: %d\n",FlagGotDML);fflush(stdout);

						if (cntLcs<=0 && FlagGotDML==0)
						 {
						    cntTask1=0;
						    iTask1=0;
						    prtTasks1=NULLTAG;
							ITKCALL( GRM_list_primary_objects_only(item_rev_cld_tag,relation_type,&cntTask1,&prtTasks1));
							printf("\n cntTask1 : %d",cntTask1);fflush(stdout);

							if (cntTask1>0)
							{
								for (iTask1=0;iTask1<cntTask1;iTask1++)
								{
									prtTask_Class1	=	NULLTAG;
									prtTask_type1	=	NULL;
									prtTask1			=	prtTasks1[iTask1];
									ITKCALL (TCTYPE_ask_object_type(prtTask1,&prtTask_Class1));
									ITKCALL (TCTYPE_ask_name2(prtTask_Class1,&prtTask_type1));
									printf("\nprtTask_type1 : %s",prtTask_type1);fflush(stdout);

									if(tc_strcmp(prtTask_type1,"T5_MBOMTASKRevision")==0)
									{
										prtTaskName1	=	NULL;
										ITKCALL( AOM_ask_value_string(prtTask1,"item_id",&prtTaskName1));
										printf("\n prtTaskName1 : %s",prtTaskName1);fflush(stdout);
											
										GetPlantForDMLORTask(prtTaskName1,GetPlant1);
										printf("\n Hi GetPlant : %s",GetPlant);fflush(stdout);
										printf("\n Hi GetPlant1 : %s",GetPlant1);fflush(stdout);
										
										if(tc_strcmp(GetPlant1,GetPlant)==0)
										{
										  TskToDMLRel= NULLTAG;
										  DMLRevTagg		= NULLTAG;
										  DMLTypeTag		= NULLTAG;
										  DMLTagg		= NULLTAG;

										  CountDML=0;
										  Counter=0;

										  DMLNumberr				= NULL;

											printf("\n Test dss .. ");fflush(stdout);
											ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &TskToDMLRel));
											if (TskToDMLRel!=NULLTAG)
											{
												ITKCALL(GRM_list_primary_objects_only(prtTask1,TskToDMLRel,&CountDML,&DMLTagg));
												printf("\n dss CountDML : %d",CountDML);fflush(stdout);

												for (Counter=0;Counter<CountDML ;Counter++ )
												{
													ITKCALL(ITEM_rev_sequence_is_latest(DMLTagg[Counter],&isltstdmll));
													printf("\n isltstdmll : %d\n",isltstdmll);fflush(stdout);

													if(isltstdmll != true)
													{
														printf("\n isltstdmll is not true .....\n");fflush(stdout);
													}else
													{
														printf("\n isltstdmll is  true .....\n");fflush(stdout);
														DMLRevTagg = DMLTagg[Counter];

														ITKCALL (TCTYPE_ask_object_type(DMLRevTagg,&DMLTypeTag));
														ITKCALL (TCTYPE_ask_name2(DMLTypeTag,&DMLTyp));
														printf("\n isltstdmll is  true test .....\n");fflush(stdout);

														if(tc_strcmp(DMLTyp,"T5_MBOMDMLRevision")==0)
														{
														    DMLNumberr	=	NULL;
															ITKCALL( AOM_ask_value_string(DMLRevTagg,"item_id",&DMLNumberr));
															printf("\n DMLNumberr : %s",DMLNumberr);fflush(stdout);
															FlagGotDML=1;	
															break;	
														}
													}
												}
											}
										}

									}
									if(FlagGotDML==1)
									{
										break;
									}
								}
							}
					     }

						// End Of Code Added by Dhanashri // UATZ1.46

					}

				}

				printf("\n cntLcs: %d\n",cntLcs);fflush(stdout);
				if (cntLcs<=0)
				{
					//Added by Hemal, Memory allocation
					//if (tc_strcmp(ChildRelErr,"NULL") !=0) MEM_free(ChildRelErr);
					//if (tc_strlen(ChildRelErr)>0) MEM_free(ChildRelErr);
					ChildRelErr	=	NULL;
					ChildRelErr	=	(char *)MEM_alloc(250);
					tc_strcpy(ChildRelErr," ");
					if(cnt==0)
					{
						cnt = 1;
						tc_strcat(ChildRelErr,"Child Part ");
						tc_strcat(ChildRelErr,Item_id);

						if(tc_strlen(DMLNumberr)>0)
						{
							tc_strcat(ChildRelErr," of DML ");
							tc_strcat(ChildRelErr,DMLNumberr);
						}
						//tc_strcat(ChildRelErr,",");	//Revision is comment out from error msg. Hemal
						//tc_strcat(ChildRelErr,Item_rev);
						tc_strcat(ChildRelErr,"  Of Parent Part ");
						tc_strcat(ChildRelErr,Part_no);
						tc_strcat(ChildRelErr," is not MBOM Released.\n");
						 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
					}
					else
					{
						tc_strcat(ChildRelErr,"Child Part ");
						tc_strcat(ChildRelErr,Item_id);
						if(tc_strlen(DMLNumberr)>0)
						{
							tc_strcat(ChildRelErr," of DML ");
							tc_strcat(ChildRelErr,DMLNumberr);
						}
						//tc_strcat(ChildRelErr,",");
						//tc_strcat(ChildRelErr,Item_rev);
						tc_strcat(ChildRelErr,"  Of Parent Part ");
						tc_strcat(ChildRelErr,Part_no);
						tc_strcat(ChildRelErr," is not MBOM Released.\n");
						cnt = cnt+1;
						 printf("\n ChildRelEr22r: %s\n",ChildRelErr);fflush(stdout);

					}
				if(cnt==1)
				{
					//tc_strcpy(SetChildRelErr,ChildRelErr);
					setAddStrMBOM(icount,SetChildRelErr,ChildRelErr);
					cntFlag = 1;
				}
				else
				{
					//tc_strcat(SetChildRelErr,ChildRelErr);
					setAddStrMBOM(icount,SetChildRelErr,ChildRelErr);
					cntFlag = 1;
				}
			}

				}
			} //End for Child check

	return 0;

}

int mbom_Prev_Part_Rev_Checks(int PartCnt, tag_t* PartTags,char	***SetChildRelErr,char* PlantCS,int *icount)
{
			EPM_decision_t decision;
			tag_t			AssyTag				= NULLTAG;
			char*			Part_no				= NULL;
			char*			Part_Rev				= NULL;
			char*			Part_Rev_copy				= NULL;
			char*			Part_rev_Id				= NULL;
			char*			PreRevOnly				= NULL;
			char*			RevOnly				= NULL;
			tag_t	All_item_tag		= NULLTAG;
    		 tag_t	item_rev_tag_p						= NULLTAG;
			char*		Part_type			=	NULL;
			char*			Part_CS				= NULL;
	        int n=0,j=0;
			tag_t	window								= NULLTAG;
			tag_t	rule								= NULLTAG;
			tag_t	top_line							= NULLTAG;
			tag_t	Childtop_line							= NULLTAG;
			tag_t  *children;
			tag_t  *totalchildren;
	        int   attribute_act_tak;
	        tag_t  	value_act_Tak;
	        int k = 0,Item_ID=0,childCnt=0;
	        char *Item_id = NULL;
         	tag_t	itemcldclass							= NULLTAG;
			char *Item_rev = NULL;
			char *Item_LCS = NULL;
			char *Item_Lcs_str = NULL;
         	tag_t  	item_rev_cld_tag;
			tag_t	*rev_list				= NULL;
	        int       ii=0;
	        int       RevFlag=0;
	        int       PreRevFlag=0;
	        int       st_count=0;
			int Item_count      =  0;
	        tag_t*    status_list;
	        char *  ChildRelErr = NULL;
			int       iLCS=0;
			int       cntLcs=0;
	        char* class_name=NULL;
	        tag_t	relation_type = NULLTAG;
	        int count = 0;
			tag_t*			PartPreTags			= NULLTAG;
			char*	itemidpre;
 			char*	itemidprerev;
	        tag_t			AssyPreTag				= NULLTAG;
			tag_t  CurrentRoleTag = NULLTAG;
			//char       roleName[SA_name_size_c+1];
			char* roleName=NULL;
			char PlantIA[40];
			char PlantStore[40];
			char UserAgency[40];
			char ClosureRule[40];
	        char PlantOptCS[40];
			char usrLocation[40];
			tag_t   qryTagCntrlobj1		= NULLTAG;
			tag_t*	list_of_cntrlprev_tags	= NULLTAG;
			char*	entryprev[4] = {"SYSCD","SUBSYSCD","Delete Indicator"};	
			int controlObjfoundprev	= 0;
			int	entry = 3;
			char	*ctrdesigngroup =	NULL;
			char	*designgrppr =	NULL;
			char	*itemidprerevv =	NULL;
			char**	valprev	= (char **) MEM_alloc(5 * sizeof(char *));
			valprev[0]="MBOMSkipprerev";
			valprev[1]="mbom_Prev_Part_Rev_Checks_Skip";
			valprev[2]="0";
			int v=0;
			int flagprevrev=0;
			tag_t *dprcbyfunc =NULLTAG;
			char * designgrpinfo = NULL;
			
			printf("\n ************** Ketan Inside mbom_Prev_Part_Rev_Checks ***************\n ");fflush(stdout);

           	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
			ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
			printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

			mbom_getPlantDetailsAttr(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency,ClosureRule,usrLocation);

			printf("\n PlantCS %s \n",PlantCS);fflush(stdout);
			printf("\n PlantAgency %s \n",PlantIA);fflush(stdout);
			printf("\n PlantStore %s \n",PlantStore);fflush(stdout);
			printf("\n UserAgency %s \n",UserAgency);fflush(stdout);
			printf("\n ClosureRule %s \n",ClosureRule);fflush(stdout);
			if(QRY_find2("Control Objects...", &qryTagCntrlobj1));

				for (k=0;k<PartCnt ;k++ )
				{
					int BypassNACSFlag =0;
					printf("\n MBOM DML for k_1 =:%d \n",k);fflush(stdout);
					AssyTag	= NULLTAG;
					AssyTag=PartTags[k];
					ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
					ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev));
					ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev_copy));
					ITKCALL(AOM_ask_value_string(AssyTag,"t5_DesignGrp",&designgrppr));
					//added by Gauri
					char *Part_type=NULL;
					ITKCALL(AOM_ask_value_string(AssyTag,"t5_PartType",&Part_type));
					printf("\n Part_type*********************** :- %s",Part_type);fflush(stdout);


					printf("\n Design group on part under soln:- %s",designgrppr);fflush(stdout);
					ITKCALL(ITEM_find_item (Part_no, &All_item_tag));
					ITKCALL(ITEM_list_all_revs (All_item_tag, &Item_count, &rev_list));
					printf("\n Eff:Total rev found: %d. \n", Item_count);fflush(stdout);

					if (qryTagCntrlobj1)
					{
						if(QRY_execute(qryTagCntrlobj1, entry, entryprev, valprev, &controlObjfoundprev, &list_of_cntrlprev_tags));
						if(controlObjfoundprev>0)
						{
							ITKCALL(AOM_ask_value_string(list_of_cntrlprev_tags[0],"t5_Userinfo1",&ctrdesigngroup));
							printf("\n Design Group in Info-1 :- %s",ctrdesigngroup);fflush(stdout);
												//Check to skip Non-Applicable Design group.
							if((tc_strstr(ctrdesigngroup,designgrppr)==NULL)) //Aniket
							{
								printf("\n 123");fflush(stdout);
								printf("\n Item ID:- \n",Part_no);fflush(stdout);
								printf("\n Skiping this revision due to not applicable to MBOM.... \n");fflush(stdout);
								continue;
							}
							else
							{
								printf("\n Continue for Applicable MBOM Design Group \n");fflush(stdout);

							}
		
						}
						else
						{
							printf("\n Control Object off.....................\n");fflush(stdout);

						}
					}


					// Check if Rev starts with "NR"
					RevOnly = NULL;
					RevOnly= strtok( Part_Rev_copy, ";" );
                    if (tc_strcmp(RevOnly, "NR") == 0) 
					{  
                        printf("\nSkipping previous revision check as the revision is NR.\n"); fflush(stdout);
                        continue;
                    }

					if(Item_count > 0)
					{
					    RevFlag = 0;
					    PreRevFlag = 0;
						for(ii=Item_count-1;ii>=0;ii--)
						{
						   RevOnly = NULL;
						   PreRevOnly = NULL;
						   ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));
    						printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);
							printf("\n Part_rev_Id: %s\n",Part_rev_Id);fflush(stdout);
						    if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
							{
                                RevFlag = 1;
							}
				        	printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
                            if(RevFlag == 1)
							{
	                           RevOnly= strtok( Part_Rev_copy, ";" );
	                           PreRevOnly= strtok( Part_rev_Id, ";" );
  							   printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
							   printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
                               if(tc_strcmp(RevOnly,PreRevOnly)!=0)
								{
									printf("\n Inside PreRevFlag =1 \n");fflush(stdout);
									PreRevFlag = 1;
								}
							}
				        	printf("\n PreRevFlag => %d.", PreRevFlag);fflush(stdout);
							if(PreRevFlag == 1)
							{
                                ITKCALL(WSOM_ask_release_status_list(rev_list[ii],&st_count,&status_list));
								if(st_count == 0)
								{
									printf("\n NO LCS Found for part : %d\n",st_count);fflush(stdout);
									break;
								}
								else
								{
									printf("\n Inside else \n");fflush(stdout);
									for (iLCS=0;iLCS<st_count ;iLCS++ )
									{
										ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
										printf("\n class_name: %s\n",class_name);fflush(stdout);
										if(tc_strcmp(UserAgency,"MBOM")==0)
										{
											if(tc_strcmp(class_name,"T5_MBOMReleased")==0)
											{
												printf("\n LCS Matched \n");fflush(stdout);
												cntLcs++;
												break;
											}
										}
									}
									printf("\n cntLcs inside : %d\n",cntLcs);fflush(stdout);
									break;
								}
							}  /// End Prev Rev  Flag Loop
						}
					}

					printf("\n cntLcs: %d\n",cntLcs);fflush(stdout);

					if (tc_strcmp(ChildRelErr,"NULL") !=0) MEM_free(ChildRelErr);
       			    ChildRelErr=(char *)MEM_alloc(100);
		         	tc_strcpy(ChildRelErr," ");

					if (cntLcs<=0 && PreRevFlag == 1)
					{
						if(tc_strcmp(Part_type,"D" )==0  || tc_strcmp(Part_type,"Dummy" )==0 )
						{

							printf("\n Previous Revision check for D part \n");fflush(stdout);
						}
						else
						{

							printf("\n Test 1 \n");fflush(stdout);
							if(cnt==0)
							{
								printf("\n Test 2 \n");fflush(stdout);
								cnt = 1;
								tc_strcat(ChildRelErr,"Previous Revision Part ");
								tc_strcat(ChildRelErr,Part_no);
								tc_strcat(ChildRelErr,",");
								tc_strcat(ChildRelErr,Part_rev_Id);
								tc_strcat(ChildRelErr," is not MBOM Released. Please release Previous Revision First\n");
								 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
							}
							else
							{
								printf("\n Test 3 \n");fflush(stdout);
								tc_strcat(ChildRelErr,"Previous Revision Part ");
								tc_strcat(ChildRelErr,Part_no);
								tc_strcat(ChildRelErr,",");
								tc_strcat(ChildRelErr,Part_rev_Id);
								tc_strcat(ChildRelErr," is not MBOM Released. Please release Previous Revision First\n");
								 printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
								cnt = cnt+1;
								 printf("\n ChildRelEr22r: %s\n",ChildRelErr);fflush(stdout);
							}
						}
						if(cnt==1)
						{
							printf("\n Test 4 \n");fflush(stdout);
							setAddStrMBOM(icount,SetChildRelErr,ChildRelErr);
							cntFlag = 1;
						}
						else
						{	
							printf("\n Test 5 \n");fflush(stdout);
							setAddStrMBOM(icount,SetChildRelErr,ChildRelErr);
							cntFlag = 1;
						}
					}
				}  //End for Previous check

	return 0;
}


int mbom_Hanging_Part_Checks(int PartCnt, tag_t* PartTags,char	***SetChildRelErr,char* PlantCS,int *icount)
{
			EPM_decision_t decision;
			tag_t			AssyTag				= NULLTAG;
			char*			Part_no				= NULL;
			 tag_t	item_rev_tag_p						= NULLTAG;
			char*		Part_type			=	NULL;
			char*			Part_CS				= NULL;
	        int n=0,j=0;
			tag_t	window								= NULLTAG;
			tag_t	rule								= NULLTAG;
			tag_t	top_line							= NULLTAG;
			tag_t	Childtop_line							= NULLTAG;
			tag_t  *children;
			tag_t  *totalchildren;
	        int   attribute_act_tak;
	        tag_t  	value_act_Tak;
	        int k = 0,Item_ID=0,childCnt=0;
	        char *Item_id = NULL;
         	tag_t	itemcldclass							= NULLTAG;
			tag_t   RawMstr		= NULLTAG;
			char *Item_rev = NULL;
			char *Item_LCS = NULL;
			char *Item_Lcs_str = NULL;
         	tag_t  	item_rev_cld_tag;
	        int       st_count=0;
	        tag_t*    status_list;
	        char *  ChildRelErr = NULL;
			int       iLCS=0;
			int       cntLcs=0;
	        char* class_name=NULL;
	        char * ItemName1 ;
			char * ItemRev ;
			char * ItemPType ;
			int  	n_parents=0;
			int * 	levels;
			int Retcount =0;
			tag_t RetRawPartTag = NULLTAG;
			tag_t * 	parents	 =NULLTAG;
			char *  HangingPrtErr = NULL;
			char	*ItemOType = NULL;

			// Start for Hanging Part check
			printf("\n ************** Ketan Inside mbom_Hanging_Part_Checks ***************\n ");fflush(stdout);
			for (k=0;k<PartCnt ;k++ )
				{
					int BypassNACSFlag =0;

					printf("\n MBOM DML for k_3 =:%d",k);fflush(stdout);
					ItemName1 = NULL;
					ItemRev = NULL;
					ItemPType = NULL;
					AssyTag=PartTags[k];

					ITKCALL(AOM_ask_value_string(AssyTag,"t5_PartType",&ItemPType));
					printf("\n Part type is :%s ..............",ItemPType);fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyTag,"object_type",&ItemOType));
					printf("\n child ItemOType:%s ..............",ItemOType);fflush(stdout);

					if(tc_strcmp(ItemPType,"V" )==0  || tc_strcmp(ItemPType,"CCVC" )==0 || tc_strcmp(ItemPType,"VC" )==0 ||  tc_strcmp(ItemPType,"VCCR" )==0 || tc_strcmp(ItemPType,"T" )==0 || tc_strcmp(ItemPType,"SA" )==0 || tc_strcmp(ItemPType,"M" )==0  || tc_strcmp(ItemPType,"D" )==0 || tc_strcmp(ItemPType,"DC" )==0 || tc_strcmp(ItemPType,"DA" )==0 || tc_strcmp(ItemPType,"G" )==0 ||  tc_strcmp(ItemOType,"T5_SparKitRevision")==0 || tc_strcmp(ItemPType,"EM")==0) //TZ1.45Priti
					{
						printf("\n Part Type is V/VC/VCCR/T/M/D/SP/SA/G/EM [[%s]]--->So continue No hanging part check..............",ItemPType);fflush(stdout);
						continue;
					}
					
					if(tc_strstr(ItemOType,"T5_RawPartRevision")!=NULL)
					{
							
						ITKCALL(getRawpart(AssyTag ,&Retcount,&RetRawPartTag));					
						if (Retcount>0)
						{
							printf("\n Raw Part Exist so Hanging part check is not applicable for raw part strcuture !!");
							continue;
						}
						
					}
					
					
					ITKCALL(PS_where_used_all(AssyTag,1,&n_parents,&levels,&parents));
					printf("\n No of Assy objects are n_parents : %d\n",n_parents);fflush(stdout);
					ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&ItemName1));
					printf("\n child ItemName1:%s ..............",ItemName1);fflush(stdout);
					ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&ItemRev));
					printf("\n child ItemRev:%s ..............",ItemRev);fflush(stdout);

					HangingPrtErr	=	NULL;
					HangingPrtErr	=	(char *)MEM_alloc(500);
					tc_strcpy(HangingPrtErr," ");


					printf("\n Part to MBOM DML to Task : %d",n_parents);fflush(stdout);
					if(n_parents<=0)
					{
							if(cnt==0)
							{
								cnt = 1;
								tc_strcat(HangingPrtErr,"PartNumber[");
								tc_strcat(HangingPrtErr,ItemName1);
								tc_strcat(HangingPrtErr,",");
								tc_strcat(HangingPrtErr,ItemRev);
								tc_strcat(HangingPrtErr,"]is Hanging.This part should have under some Assembly");
								 printf("\n ChildRelErr10: %s\n",HangingPrtErr);fflush(stdout);
							}
							else
							{
								tc_strcat(HangingPrtErr,"PartNumber[");
								tc_strcat(HangingPrtErr,ItemName1);
								tc_strcat(HangingPrtErr,",");
								tc_strcat(HangingPrtErr,ItemRev);
								tc_strcat(HangingPrtErr,"]is Hanging.This part should have under some Assembly");
								 printf("\n ChildRelErr11: %s\n",HangingPrtErr);fflush(stdout);
								cnt = cnt+1;
								 printf("\n ChildRelEr22r: %s\n",HangingPrtErr);fflush(stdout);
							}
						if(cnt==1)
						{
							//tc_strcpy(SetChildRelErr,HangingPrtErr);
							setAddStrMBOM(icount,SetChildRelErr,HangingPrtErr);
							cntFlag = 1;
						}
						else if(cnt>1)
						{
							//tc_strcat(SetChildRelErr,HangingPrtErr);
							setAddStrMBOM(icount,SetChildRelErr,HangingPrtErr);
							cntFlag = 1;
						}
					}
				}// End for Hanging Part check

	return 0;
}

//int mbom_Two_Rev_Same_Day_Checks(int PartCnt, tag_t* PartTags,char	***SetChildRelErr,char* itemid,char* PlantCS,int *icount)
int mbom_Two_Rev_Same_Day_Checks(tag_t Task_rev_tag,int PartCnt, tag_t* PartTags,char	***SetChildRelErr,char* itemid,char* PlantCS,int *icount)
{
	EPM_decision_t decision;
	
	int	ifail=0;

	char*	Part_no				= NULL;
	char*	Part_type			= NULL;
	char*	Part_CS				= NULL;
	char*	Item_rev			= NULL;
	char*	Item_LCS			= NULL;
	char*	Item_Lcs_str		= NULL;
	char*	class_name			= NULL;
	char*	inp_Plant			= NULL;
	char*	task_Plant			= NULL;
	char*	current_name		= NULL;
	char*	creationdate		= NULL;
	char*	ClosureDate			= NULL;
	char*	ClosureDateDup		= NULL;
	char*	type_eff			= NULL;
	char*	rev_id				= NULL;
	char*	rev_id1				= NULL;
	char*	desid				= NULL;
	char*	dml_type			= NULL;
	char*	type_name_ref		= NULL;
	char*	pAccessDateDup 		= NULL;
	char*	IsPPPPMRlzErr1		= NULL;
	char*	SetIsPPPPMRlzErr1	= NULL;
	char*	Part_clr_ind		= NULL;
	char*	Item_id				= NULL;
	char*	ChildRelErr			= NULL;
	char*	ItemName1;
	char*	ItemRev;
	char*	ItemPType;
	char	req_id[ITEM_id_size_c+1];
	char	type_itemRev[TCTYPE_name_size_c+1];
	char	ChildRevtype_name[TCTYPE_name_size_c+1];
	char	pAccessDate[20];
	char	cCurrentAccessDate[20]={0};
	char*	DmlId;
	
	tag_t	window				= NULLTAG;
	tag_t	rule				= NULLTAG;
	tag_t	top_line			= NULLTAG;
	tag_t	Childtop_line		= NULLTAG;
	tag_t	AssyTag				= NULLTAG;
	tag_t	item_rev_tag_p		= NULLTAG;
	tag_t	view_type			= NULLTAG;
	tag_t	item_rev_tag		= NULLTAG;
	tag_t	itemTypeTag_cdss	= NULLTAG;
	tag_t*	itemclassp			= NULLTAG;
	tag_t	value_child_details	= NULLTAG;
	tag_t	itemclass			= NULLTAG;
	tag_t	itemclass_task		= NULLTAG;
	tag_t	objTypeRefTag		= NULLTAG;
	tag_t	item_rev_task		= NULLTAG;
	tag_t	reln_type_tag		= NULLTAG;
	tag_t	relation_type		= NULLTAG;
	tag_t*	PartDmlTags			= NULLTAG;
	tag_t	PartDmlTag			= NULLTAG;
	tag_t	item				= NULLTAG;
	tag_t*	DMLRevision			= NULLTAG;
	tag_t	itemcldclass		= NULLTAG;
	tag_t* 	parents				= NULLTAG;
	tag_t	DMLRevTag			= NULLTAG;
	tag_t*	children;
	tag_t*	totalchildren;
	tag_t  	value_act_Tak;
	tag_t	tsk_dml_rel_type;
	tag_t  	objTypeTag_eff;
	tag_t*  rev_list;
	tag_t  	item_rev_cld_tag;
	tag_t*  status_list;
		
	int		ik			= 0;
	int		st_count	= 0;
	int     iLCS		= 0;
	int     cntLcs		= 0;
	int  	n_parents	= 0;
	int		task_len	= 0;
	int		inp_len		= 0;
	int		ii			= 0;
	int		jj			= 0;
	int		count		= 0;
	int		cntErr		= 0;
	int		attribute_act_tak;
	int		k = 0,Item_ID=0,childCnt=0;
	int		n=0,j=0;
	int* 	levels;
	       
	logical is_latest;
   
	printf("\n ************** Ketan Inside mbom_Two_Rev_Same_Day_Checks ***************\n ");fflush(stdout);
	task_len=0;
	task_len=strlen(itemid);
	printf("\n  task_len ...%d\n", task_len);// length task
	inp_Plant=subString_mbom(itemid,14,task_len);
	printf("\n  inp_Plant after  ...%s\n", inp_Plant);//task
	
	char*	CurrentTask_no				= NULL;
	ITKCALL(AOM_ask_value_string(Task_rev_tag,"item_id",&CurrentTask_no));
	printf("\n CurrentTask_no => %s\n", CurrentTask_no);
				
	for (k=0;k<PartCnt ;k++ )
	{
		const char *attrs[1];
		const char *values[1];
		int n_tags_found=0;
		int		count1				= 0;
		int		count2				= 0;
		int		BypassNACSFlag		= 0;

		printf("\n for k_same rev =:%d \n",k);fflush(stdout);
		AssyTag=PartTags[k];

		ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
		printf("\n Part_no  is :%s \n",Part_no);	fflush(stdout);
		Part_clr_ind	=	NULL;
		ITKCALL(AOM_ask_value_string(AssyTag,"t5_ColourInd",&Part_clr_ind));
		attrs[0] ="item_id";
		values[0] = (char *)Part_no;
		
		char	*designBORev		=	NULL;
		char	*designBO			=	NULL;

		printf("\n Before getDesignType \n");fflush(stdout);
		getDesignType(AssyTag, &designBORev,&designBO);
		printf("\n After getDesignType : %s \n",designBO);fflush(stdout);

		ITKCALL(ITEM_find_items_by_key_attributes(1, attrs, values,&n_tags_found, &itemclassp));//Multiple Item Queried Error Hemal
		int t=0;
		tag_t	item2			=	NULLTAG;

		for (t=0;t<n_tags_found ; t++)
		{
			char	*designBORevEE		=	NULL;
			char	*designBOEE			=	NULL;
			item2 = itemclassp[t];
			tag_t itemltRev = NULLTAG;

			ITKCALL(ITEM_ask_latest_rev(item2,&itemltRev)); 
			printf("\n Before getDesignType for EE parts \n");fflush(stdout);
			getDesignType(itemltRev, &designBORevEE,&designBOEE);
			printf("\nAfter getDesignType for EE parts : %s \n",designBOEE);fflush(stdout);

			if (tc_strcmp(designBO,designBOEE)==0)
			{
				item = itemclassp[t];
				CALLAPI(ITEM_list_all_revs (item, &count1, &rev_list)); 
			}
		}

		if(item != NULLTAG )
		ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag_p));

		ITKCALL (TCTYPE_ask_object_type(item_rev_tag_p,&objTypeTag_eff));
		ITKCALL (TCTYPE_ask_name2(objTypeTag_eff,&type_eff));

		printf("\n type_eff class is => %s\n", type_eff);fflush(stdout);
                 
		if(item != NULLTAG )
		ITEM_ask_rev_id2( item_rev_tag_p,&rev_id);

		printf("\n rev_id is => %s\n", rev_id);fflush(stdout);
		printf("\n WSOM count1 => %d\n\n",count1);
		for (ii = 0; ii < count1; ii++)
		{
			ITEM_ask_rev_id2( rev_list[ii],&rev_id1);

			printf("\n rev_id1 is => %s\n", rev_id1);fflush(stdout);//diplay the previous revision
			printf("\n ii => %d\n",ii);

			if(tc_strcmp(rev_id,rev_id1)==0)
			{
				printf("\n Part[%s] is Attached to same DML so Continue  \n", Part_no);fflush(stdout);//diplay the previous revision
				continue;
			}

			GRM_find_relation_type("CMHasSolutionItem",&relation_type);
			GRM_list_primary_objects_only(rev_list[ii],relation_type,&count,&PartDmlTags);

			printf("\n Part to Task : %d \n",count);fflush(stdout);
			if(count >0)
			{
				for (ik=0;ik<count ;ik++ )
				{
					PartDmlTag=PartDmlTags[ik];//task pointer
					printf("\n INSIDE: \n");fflush(stdout);

					ITKCALL(TCTYPE_ask_object_type(PartDmlTag,&objTypeRefTag));//task pointer
					ITKCALL(TCTYPE_ask_name2(objTypeRefTag,&type_name_ref));
					printf("\n TCDCtype_name_ref isss :%s\n",type_name_ref);fflush(stdout);

					if(PartDmlTag == Task_rev_tag )
					{
						printf("\n Skiiping for same DML => %s \n",CurrentTask_no);fflush(stdout);
						continue;
					}
					
					if (strcmp(type_name_ref,"T5_MBOMTASKRevision")==0)
					{
						ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
						if (tsk_dml_rel_type!=NULLTAG)
						{
							ITKCALL(GRM_list_primary_objects_only(PartDmlTag,tsk_dml_rel_type,&count2,&DMLRevision));
							printf("\n DML Revision from Task : %d",count2);fflush(stdout);		//task to dml

							for (j=0;j<count2 ;j++ )
							{
								ITKCALL(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
								printf("\n is_latest : %d\n",is_latest);fflush(stdout);

								if(is_latest != true)
								{
									printf("\n is_latest is not true .....\n");fflush(stdout);
								}
								else
								{
									ITKCALL(AOM_ask_value_string(PartDmlTag, "item_id",&DmlId));
									printf("\n DmlId %s.....\n",DmlId);//previous revision's task
									DMLRevTag = DMLRevision[j];//DML
									ITKCALL(AOM_ask_value_string(DMLRevTag,"current_name",&current_name));
									printf("\n dml is :%s\n",current_name);fflush(stdout);
									task_len=0;
									task_len=strlen(DmlId);
									task_Plant=subString_mbom(DmlId,14,task_len);
									printf("\n task_Plant is : %s\n",task_Plant);fflush(stdout);

									if(tc_strcmp(inp_Plant,task_Plant)==0)
									{
										printf("\n inside plant check is :\n");fflush(stdout);

										ITKCALL(AOM_UIF_ask_value(DMLRevTag,"date_released",&ClosureDate));
										printf("\n ClosureDate : %s\n",ClosureDate);fflush(stdout);

										ClosureDateDup = subString_mbom(ClosureDate,0,11);
										printf("\n ClosureDateDup : %s\n",ClosureDateDup);fflush(stdout);
										getCurrentDateTime(cCurrentAccessDate);
										printf("\n  todays date111 is: %s\n",cCurrentAccessDate);
										pAccessDateDup = subString_mbom(cCurrentAccessDate,0,11);
										printf("\n  todays date is: %s\n",pAccessDateDup);

										IsPPPPMRlzErr1	=	NULL;
										IsPPPPMRlzErr1	=	(char *)MEM_alloc(250);
										tc_strcpy(IsPPPPMRlzErr1,"");
										if(tc_strcmp(ClosureDateDup,pAccessDateDup)==0)
										{
											if(cnt==0)
											{
												cnt = 1;
												tc_strcat(IsPPPPMRlzErr1,"\n Two revision of part ");
												tc_strcat(IsPPPPMRlzErr1,Part_no);
												tc_strcat(IsPPPPMRlzErr1," cannot be released on same day.\n");
												printf("\n IsPPPPMRlzErr: %s\n",IsPPPPMRlzErr1);fflush(stdout);

											}
											else
											{
												tc_strcat(IsPPPPMRlzErr1,"\n Two revision of part ");
												tc_strcat(IsPPPPMRlzErr1,Part_no);
												tc_strcat(IsPPPPMRlzErr1," cannot be released on same day..\n");
												cnt=cnt+1;
												printf("\n IsPPPPMRlzErr: %s\n",IsPPPPMRlzErr1);fflush(stdout);
											}
									        printf("\n cnt: %d\n",cnt);fflush(stdout);

											if(cnt==1)
											{
												setAddStrMBOM(icount,SetChildRelErr,IsPPPPMRlzErr1);
												cntFlag = 1;
											}
											else
											{
												setAddStrMBOM(icount,SetChildRelErr,IsPPPPMRlzErr1);
												cntFlag = 1;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}// End for two rev. on same day check

	return 0;
}

//venkat add


int fram_module_applicability_check(int PartCnt, tag_t* PartTags,char	***SetChildRelErr,char*	itemid,int *icount)
{

	EPM_decision_t decision;
	//printf("\n ************** venkat Inside fram_module_applicability_check ***************\n ");fflush(stdout);
	char    *fram_entryCntr1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**frame_valuesCntr1   = (char **) MEM_alloc(5 * sizeof(char *));


	tag_t   framqryTagCntr1					= NULLTAG;
	tag_t*	list_fram_tags					= NULLTAG;
	int     n_entryCntr1					= 3;
	int		fram_cnt						= 0;
	char*		Parttype					= NULL;
	char*		ModuleAddress				= NULL;
	char*		Module_attribute_name		= NULL;
	char*		mmtask						= NULL;
	char*		mbtask						= NULL;
	char*		partid						= NULL;
	char*		displayflagname				= NULL;

	char	*partowning_groupVal	=	NULL;
	char	*framChildName			=	NULL;
	char	*modulef9y02			=	NULL;
	char	*frameapplicability		=	NULL;
	char  RevRuleInfo1[40];
	char  closRuleInfo2[40];
    char  BVRInfo3[40];
	char  CurMskInfo4[40];

	int		j						= 0;
	int		framFlag				= 0;
	int		iCount					= 0;
	int		cnt						= 0;
	int		frmcntrlcnt				= 0;
	int		jcnt					= 0;
	int		PARTCount				= 0;
	tag_t		AssyTag				=	NULLTAG;
	tag_t		bl_Child_dv				=  NULLTAG;
	 struct			BomChldStrut	ChldStrutBdySh[5000];

	if( QRY_find2("Control Objects...", &framqryTagCntr1));
	if (framqryTagCntr1)
	{
		printf("\n query Control Object Frame module \n");fflush(stdout);
		frame_valuesCntr1[0]="Framemodule";
		frame_valuesCntr1[1]="framesignoff";  
		frame_valuesCntr1[2]="0";
		
		

		if(QRY_execute(framqryTagCntr1, n_entryCntr1, fram_entryCntr1, frame_valuesCntr1, &fram_cnt, &list_fram_tags));
		printf("\n INSIDE controlObjfound for Frame module checking is ==> %d\n",fram_cnt);fflush(stdout);

		if(fram_cnt>0)
		{
			printf("\n controlObjfound for Frame module checking is ==> %d\n",fram_cnt);fflush(stdout);
			for (frmcntrlcnt = 0; frmcntrlcnt < fram_cnt; frmcntrlcnt++)
			{

				ITKCALL( AOM_ask_value_string(list_fram_tags[frmcntrlcnt], "t5_Userinfo1", &Parttype));
				ITKCALL( AOM_ask_value_string(list_fram_tags[frmcntrlcnt], "t5_Userinfo2", &ModuleAddress));
				ITKCALL( AOM_ask_value_string(list_fram_tags[frmcntrlcnt], "t5_Userinfo3", &Module_attribute_name));
				ITKCALL( AOM_ask_value_string(list_fram_tags[frmcntrlcnt], "t5_Userinfo4", &mmtask));
				ITKCALL( AOM_ask_value_string(list_fram_tags[frmcntrlcnt], "t5_Userinfo5", &mbtask));
				ITKCALL( AOM_ask_value_string(list_fram_tags[frmcntrlcnt], "t5_Userinfo6", &modulef9y02));
				
				printf("\nFrame module part type : %s Module Address  : %s  and require attribute name : %s : %s :%s :%s\n",Parttype,ModuleAddress,Module_attribute_name,mbtask,mmtask,modulef9y02);fflush(stdout);
			}
			

		}
		else
		{
			printf("\nNo control object are found\n");fflush(stdout);
		}
	}

	printf("\n ************** Inside fram_module_applicability_check task id and part count: %s  : %d\n ",itemid,PartCnt);fflush(stdout);

	if ((tc_strstr(itemid,mmtask)!=NULL)||(tc_strstr(itemid,mbtask)!=NULL))
	{

		printf("\n ************** Inside fram_module_applicability_check task id and part count: %s  : %s :%s\n ",itemid,mmtask,mbtask);fflush(stdout);

		for (j=0;j<PartCnt ;j++ )
		{
			AssyTag=PartTags[j];
			
			ITKCALL(AOM_UIF_ask_value(AssyTag,"owning_group",&partowning_groupVal));
			ITKCALL( AOM_ask_value_string(AssyTag, "item_id", &partid));


			printf("\nPart owner and id11 : %s  :%s\n",partowning_groupVal ,partid);fflush(stdout);
			//if((tc_strstr(partowning_groupVal,"MBOM")!=NULL) &&( tc_strstr(partid,modulef9y02)!=NULL)) //part checking mbom owner AND SOLUTIONS FOLDER PART
			if( tc_strstr(partid,modulef9y02)!=NULL) //part checking mbom owner AND SOLUTIONS FOLDER PART
			{
				
					get_RRCRBVRCVm(RevRuleInfo1,closRuleInfo2,BVRInfo3,CurMskInfo4);

					printf("\n RevRuleInfo1 => %s \n",RevRuleInfo1);fflush(stdout);
					printf("\n closRuleInfo2 => %s \n",closRuleInfo2);fflush(stdout);
					printf("\n BVRInfo2 => %s \n",BVRInfo3);fflush(stdout);
					printf("\n Info3 => %s \n",CurMskInfo4);fflush(stdout);
					 
					ITKCALL(Get_Part_BOM_Lvl(AssyTag,1,closRuleInfo2,RevRuleInfo1,BVRInfo3,ChldStrutBdySh,&PARTCount));
					printf("\n frame PARTCount:%d",PARTCount);fflush(stdout);
					if (PARTCount >0)
					{
						printf("\n inside frame PARTCount:%d",PARTCount);fflush(stdout);

						jcnt=0;
					
						
						tag_t	t_ChildItemRev = NULLTAG;


						char* framChildNameRevid	= NULL;
											
						for (jcnt = 1; jcnt <= PARTCount; jcnt++)
						{
						   framFlag=0;
						   
						   bl_Child_dv	= NULLTAG;

						   bl_Child_dv=ChldStrutBdySh[jcnt].child_objs_bvr;

						   ITKCALL(AOM_ask_value_string(bl_Child_dv,"bl_item_item_id",&framChildName));
						   ITKCALL(AOM_ask_value_string(bl_Child_dv,"bl_rev_item_revision_id",&framChildNameRevid));
						   printf("\n framChildName Parts Id :%s :%s : %s",framChildName ,ModuleAddress,framChildNameRevid);;fflush(stdout);
						   
						  
						   if (tc_strstr(framChildName,ModuleAddress)!=NULL)
						   {

							   //char*	displayflagname1	=	NULL;

							   ITKCALL(AOM_ask_value_tag(bl_Child_dv,bomAttr_lineItemRevTag, &t_ChildItemRev));
								printf(" venkat BOM_line_ask_attribute_tag \n");fflush(stdout);
								if(t_ChildItemRev!=NULLTAG)
								{


								  // ITKCALL(AOM_ask_value_string(t_ChildItemRev,"t5_FrameApplicability",&displayflagname));
								   ITKCALL(AOM_ask_value_string(t_ChildItemRev,Module_attribute_name,&displayflagname));
								}

							printf("\n inside child part id matched with module address : %s ",displayflagname);;fflush(stdout);
							
							if (tc_strcmp(displayflagname,"")==0)
							{
								
								framFlag=framFlag+1;
							}
							printf("\n frame applicability flag is: %d",framFlag );;fflush(stdout);
							if (framFlag > 0)
							{
								
								frameapplicability	=	NULL;
								frameapplicability	=	(char *)MEM_alloc(250);
								tc_strcpy(frameapplicability," ");
								if(cnt==0)
								{
									cnt = 1;
									tc_strcat(frameapplicability,"Child Part no  ");
									tc_strcat(frameapplicability,framChildName);

									tc_strcat(frameapplicability,"  does not have Frame applicablity flag .\n ");
									
									
									 printf("\n frameapplicability: %s\n",frameapplicability);fflush(stdout);
								}
								else
								{
									tc_strcat(frameapplicability,"Child Part no  ");
									tc_strcat(frameapplicability,framChildName);

									tc_strcat(frameapplicability,"  does not have Frame applicablity flag .\n ");
									
									cnt = cnt+1;
									 printf("\n frameapplicability: %s\n",frameapplicability);fflush(stdout);

								}
								if(cnt==1)
								{
									
									setAddStrMBOM(icount,SetChildRelErr,frameapplicability);
									cntFlag = 1;
								}
								else
								{
									
									setAddStrMBOM(icount,SetChildRelErr,frameapplicability);
									cntFlag = 1;
								}
							}
						   }
						


					  }
					
				
			        }


		   }

	   }


	
	}
  return 0;
}
//venkat end


int mbom_Drg_Part_Checks(int PartCnt, tag_t* PartTags,char	***SetChildRelErr,char*	itemid,char* PlantCS,int *icount)
{
	
		EPM_decision_t decision;
		
		int		status			= 0;
		int     st_count		= 0;
		int     iLCS			= 0;
		int     cntLcs			= 0;
	    int  	n_parents		= 0;
		int* 	levels;
		int		task_len		= 0;
		int		inp_len			= 0;
		int		ii				= 0;
		int		jj				= 0;
		int		cntErr			= 0;
		int		Prt_len			= 0;
		int		AMDrwcntErr		= 0;
		int		PrtcntErr		= 0;
		int		DrwcntErr		= 0;
	    int		n_attchs		= 0;
		int		result			= 0;
		int		n				= 0,j=0;
		int		count=0,iPrt=0,nClhd=0,FlagGrpNA = 0,iCntl=0,cntCntrl=0,stampingdone=0,iGChld=0,cntTask=0,iTask=0;
		int		control_number_found;
		int		k = 0,Item_ID=0,childCnt=0;
		int		attribute_act_tak;

		tag_t		AssyTag					= NULLTAG;
		tag_t		item_rev_tag_p			= NULLTAG;
		tag_t		window					= NULLTAG;
		tag_t		rule					= NULLTAG;
		tag_t		top_line				= NULLTAG;
		tag_t		Childtop_line			= NULLTAG;
		tag_t*		children;
		tag_t*		totalchildren;
		tag_t  		value_act_Tak;
		tag_t		itemcldclass			= NULLTAG;
		tag_t  		item_rev_cld_tag;
		tag_t*		status_list;
		tag_t* 		parents					= NULLTAG;
		tag_t		item					= NULLTAG;
		tag_t  		objTypeTag_eff;
		tag_t*		rev_list;
		tag_t*		DMLRevision				= NULLTAG;
		tag_t		view_type				= NULLTAG;
		tag_t		item_rev_tag			= NULLTAG;
		tag_t		itemTypeTag_cdss		= NULLTAG;
		tag_t*		itemclassp				= NULLTAG;
		tag_t		value_child_details		= NULLTAG;
		tag_t		itemclass				= NULLTAG;
		tag_t		itemclass_task			= NULLTAG;
		tag_t		objTypeRefTag			= NULLTAG;
		tag_t		item_rev_task			= NULLTAG;
		tag_t		reln_type_tag			= NULLTAG;
		tag_t		tsk_dml_rel_type;
        tag_t		relation_type			= NULLTAG;
	    tag_t*		PartDmlTags				= NULLTAG;
        tag_t		PartDmlTag				= NULLTAG;
		tag_t		DMLRevTag				= NULLTAG;
        tag_t		DesignTag				= NULLTAG;
		tag_t		objTypeTag				= NULLTAG;
		tag_t		CurrentRoleTag			= NULLTAG;
		tag_t*		list_of_WSO_cntrl_tags	= NULLTAG;
    	tag_t		t_GChldItemRev;
		tag_t*		DgnChld					= NULLTAG;
		tag_t*		prtTasks				= NULLTAG;
		tag_t		prtTask					= NULLTAG;
		tag_t		prtTask_Class			= NULLTAG;
		tag_t		reln_type				= NULLTAG;
		tag_t		datasettype				= NULLTAG;
		
		logical is_latest;
		logical isCheckOut		= false;
		logical isDrwCheckOut	= false;
       	
		WSO_search_criteria_t  	criteria_CARDML;
		
		size_t	prtTaskLen	=	0;
	    
		char*		AssyNoBOMErr			= NULL;
	   	char*		DmlId;
		char*		FullBomErrString		= NULL;
		char*		prtTask_type			= NULL;
		char*		prtTaskName				= NULL;
		char*		Part_DrgNum				= NULL;
	    char*		Part_ModelIndicator		= NULL;
		char*		Part_CmpCode			= NULL;
		char*		Part_Creator			= NULL;
	    char*		SpareCriteriaDup		= NULL;
		char*		PlantName				= NULL;
	    char*		prtPlantCS				= NULL;
	    char*		prtCoatedInd			= NULL;
	    char*		prtClrInd				= NULL;
		char		pAccessDate[20];
		char		cCurrentAccessDate[20]={0};
       	char*		pAccessDateDup 			= NULL;
		char*		IsPPPPMRlzErr1			= NULL;
		char*		SetIsPPPPMRlzErr1		= NULL;
		char*		type_name1				= NULL;
		char*		Part_Type				= NULL;
		char*		Part_Proj				= NULL;
		char*		SubSyscd				= NULL;
		char		req_id[ITEM_id_size_c+1];
		char*		current_name			= NULL;
		char*		creationdate			= NULL;
		char*		ClosureDate				= NULL;
		char*		ClosureDateDup			= NULL;
		char		type_eff[TCTYPE_name_size_c+1];
		char*		parent_name				= NULL;
		char*		Part_clr_ind			= NULL;
		char*		SetPrtCheckOut			= NULL;
		char*		type_name			= NULL;
	    //char		type_name[TCTYPE_name_size_c+1];
		char*		SetAmDrgChk				= NULL;
		char*		Item_rev				= NULL;
		char*		Item_LCS				= NULL;
		char*		Item_Lcs_str			= NULL;
		char*		desid					= NULL;
		char*		dml_type				= NULL;
		char		type_name_ref[TCTYPE_name_size_c+1];
		char*		class_name				= NULL;
		char*		ItemName1 ;
		char*		ItemRev ;
		char*		ItemPType ;
		char*		inp_Plant				= NULL;
		char*		task_Plant				= NULL;
		char		type_itemRev[TCTYPE_name_size_c+1];
		char		ChildRevtype_name[TCTYPE_name_size_c+1];
		char*		Part_type				= NULL;
		char*		Part_CS					= NULL;
		char  		rev_id[ITEM_id_size_c+1];
		char*		Item_id					= NULL;
		char  		rev_id1[ITEM_id_size_c+1];
		char*		ChildRelErr				= NULL;
		char*		Part_no					= NULL;
	    
		GRM_relation_t *rellist;
			   
		if (!SetPrtCheckOut) MEM_free(SetPrtCheckOut);
		SetPrtCheckOut=(char *)MEM_alloc(1000);
		tc_strcpy(SetPrtCheckOut,"");

		printf("\n ************** Ketan Inside mbom_Drg_Part_Checks ***************\n ");fflush(stdout);

		for (k=0;k<PartCnt ;k++ )
		{
				const char *attrs[1]; 
				const char *values[1];

				int n_tags_found=0;
				int BypassNACSFlag=0;
				tag_t	*itemclassp	= NULLTAG;
				tag_t item = NULLTAG;
				
				printf("\n for k =:%d",k);fflush(stdout);
				
				AssyTag=PartTags[k];

				ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
				printf("\n mbom_Drg_Part_Checks Part_no  is :%s",Part_no);fflush(stdout);
				
				Prt_len=0;
				Prt_len=strlen(Part_no);
				
				printf("\n Prt_len is :%d",Prt_len);fflush(stdout);
				
				Part_clr_ind	=	NULL;
				ITKCALL(AOM_ask_value_string(AssyTag,"t5_ColourInd",&Part_clr_ind));
				
				if (tc_strcmp(Part_clr_ind,"C")==0)
				{
					continue;
				}
				attrs[0] ="item_id";
				values[0] = (char *)Part_no;
				
				char	*designBORev		=	NULL;
				char	*designBO			=	NULL;
				
				printf("\n Before getDesignType \n");fflush(stdout);
				getDesignType(AssyTag, &designBORev,&designBO);
				printf("\n After getDesignType : %s \n",designBO);fflush(stdout);
				ITKCALL(ITEM_find_items_by_key_attributes(1, attrs, values,&n_tags_found, &itemclassp));
				
				int t=0;
				tag_t	item2			=	NULLTAG;

				for (t=0;t<n_tags_found ; t++)
				{
					char	*designBORevEE		=	NULL;
					char	*designBOEE			=	NULL;
					item2 = itemclassp[t];
					tag_t itemltRev = NULLTAG;
					
					ITKCALL(ITEM_ask_latest_rev(item2,&itemltRev));
					printf("\n Before getDesignType for EE parts \n");fflush(stdout);
					getDesignType(itemltRev, &designBORevEE,&designBOEE);
					printf("\n After getDesignType for EE parts : %s \n",designBOEE);fflush(stdout);
					
					if (tc_strcmp(designBO,designBOEE)==0)
					{
						   item = itemclassp[t];
					}

				}

			if(item != NULLTAG )
			ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag_p));

			char	*partowning_groupVal	=	NULL;
			ITKCALL(AOM_UIF_ask_value(AssyTag,"owning_group",&partowning_groupVal));

			printf("\n partowning_groupVal: %s \n",partowning_groupVal);fflush(stdout);

			if( (Prt_len==16 || Prt_len==14) && tc_strstr(partowning_groupVal,"MBOM")!=NULL) // && (nlsStrCmp(OrganizationIDDup,"APLPUNE")==0 || nlsStrCmp(OrganizationIDDup,"APLAHD")==0 || nlsStrCmp(OrganizationIDDup,"APLJSR")==0 || nlsStrCmp(OrganizationIDDup,"APLLKO")==0 || nlsStrCmp(OrganizationIDDup,"APLPNR")==0 || nlsStrCmp(OrganizationIDDup,"APLDWD")==0))
			{
				ITKCALL(AOM_ask_value_string(AssyTag,"t5_PartType",&Part_type));
				printf("\n mbom_Drg_Part_Checks Part_type  is: %s",Part_type);fflush(stdout);

				ITKCALL(AOM_ask_value_string(AssyTag,"t5_DrawingInd",&Part_DrgNum));
				printf("\n mbom_Drg_Part_Checks Part_DrgNum  is: %s",Part_DrgNum);fflush(stdout);

				ITKCALL(AOM_ask_value_string(AssyTag,"t5_ModelIndicator",&Part_ModelIndicator));
				printf("\n mbom_Drg_Part_Checks Part_ModelIndicator is: %s",Part_ModelIndicator);fflush(stdout);

				ITKCALL(AOM_ask_value_string(AssyTag,"t5_PrtCatCode",&Part_CmpCode));
				printf("\n mbom_Drg_Part_Checks Part_CmpCode  is: %s",Part_CmpCode);fflush(stdout);

				ITKCALL(AOM_UIF_ask_value(AssyTag,"owning_user",&Part_Creator));
				printf("\n mbom_Drg_Part_Checks Part_Creator  is: %s",Part_Creator);fflush(stdout);

				ITKCALL(AOM_UIF_ask_value(AssyTag,"t5_SpareCriteria",&SpareCriteriaDup));
				printf("\n mbom_Drg_Part_Checks SpareCriteriaDup  is: %s",SpareCriteriaDup);fflush(stdout);

				//Bypass Module, PTP and PTD part for drawing check
				if( (strcmp(Part_type,"M") == 0) || (tc_strstr(Part_no,"PTP")!=NULL || tc_strstr(Part_no,"PTD")!=NULL ) || (strcmp(Part_type,"SA") == 0 && strcmp(SpareCriteriaDup,"PHN") == 0 )  ||  ( strcmp(Part_CmpCode,"VC") == 0 &&  (strstr(Part_Creator,"loader")) ) )
				{
					printf("\n For system generated 14 digit parts like 35/36 CED coated parts Parts ,Drawing should not be com:"); fflush(stdout);
					continue ;
				}

				if(strcmp(Part_DrgNum,"D")!=0 && strstr(itemid,"AM")!=NULL)
				{

					printf("\n Task Number [%s] is : ",itemid);fflush(stdout);
					if(AMDrwcntErr==0)
					{
						AMDrwcntErr=1;
						setAddStrMBOM(icount,SetChildRelErr,"\n");
						setAddStrMBOM(icount,SetChildRelErr,"Below Part is 16/14 digit part and must have Drawing attachment and Drawing Indicator 'D'");
						setAddStrMBOM(icount,SetChildRelErr,"\n");
						setAddStrMBOM(icount,SetChildRelErr,Part_no);
	                    cntFlag = 1;
					}
					else
					{
						setAddStrMBOM(icount,SetChildRelErr,"\n");
						setAddStrMBOM(icount,SetChildRelErr,Part_no);
						AMDrwcntErr=AMDrwcntErr+1;
						printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
						cntFlag = 1;
					}

				}

				if( strcmp(Part_DrgNum,"D")==0)
				{
					printf("\n Inside mbom_Drg_Part_Checks Drawing Number D");fflush(stdout);
					ITKCALL(GRM_find_relation_type("IMAN_specification",&reln_type));
					if(reln_type != NULLTAG)
					{
						int atchmt = 0;
						tag_t  primary,objTypeTag=NULLTAG;

						ITKCALL(GRM_list_secondary_objects(AssyTag,reln_type,&n_attchs,&rellist));
						printf("\n Total n attches =%d\n",n_attchs);fflush(stdout);

						if(n_attchs>0)
						{
							isCheckOut=false;
							ITKCALL(RES_is_checked_out(AssyTag,&isCheckOut));
							if(isCheckOut)
							{
								printf("\n Part [%s] is  check out....",Part_no);fflush(stdout);
								if(PrtcntErr==0)
								{
									PrtcntErr=1;
									setAddStrMBOM(icount,SetChildRelErr,"Drwing Indicator for Below Part is D which is in Checkout State, Please Checkin Part before Release and then proceed");
									setAddStrMBOM(icount,SetChildRelErr,"\n");
									setAddStrMBOM(icount,SetChildRelErr,Part_no);
	                                cntFlag = 1;
								}
								else
								{
									setAddStrMBOM(icount,SetChildRelErr,"\n");
									setAddStrMBOM(icount,SetChildRelErr,Part_no);
									PrtcntErr=PrtcntErr+1;
									printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
									cntFlag = 1;
								}

							}

							for (atchmt= 0; atchmt < n_attchs; atchmt++)
							{
								printf("\n Inside loop ..............");fflush(stdout);
								primary=rellist[atchmt].secondary;
								
								ITKCALL(TCTYPE_ask_object_type(primary,&objTypeTag));
								ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
								printf("\n Type Name:%s ..............",type_name);fflush(stdout);
								if(strcmp(type_name,"ImanFile")==0)
								continue;

								result = AE_find_datasettype2("CMI2Drawing", &datasettype);
								printf("\nType found---->%d",result);fflush(stdout);

								ITKCALL(AOM_ask_value_string(primary,"object_name",&parent_name));
								printf("\n parent_name:%s ..............",parent_name);fflush(stdout);

								if( strcmp(type_name,"CMI2Drawing") ==0 )
								{

									isDrwCheckOut=false;
									ITKCALL(RES_is_checked_out(primary,&isDrwCheckOut));
									if(isDrwCheckOut)
									{
										if(DrwcntErr==0)
										{
											DrwcntErr=1;
											setAddStrMBOM(icount,SetChildRelErr,"\n Drwing attached to below Part is in Checkout State, Please Checkin Drawing before Release and then proceed");
											setAddStrMBOM(icount,SetChildRelErr,"\n");
											setAddStrMBOM(icount,SetChildRelErr,Part_no);
	                                       cntFlag = 1;
										}
										else
										{
											setAddStrMBOM(icount,SetChildRelErr,"\n");
											setAddStrMBOM(icount,SetChildRelErr,Part_no);
											DrwcntErr=DrwcntErr+1;
											printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
											cntFlag = 1;
										}

									}


								}

								if( strcmp(type_name,"ProDrw") ==0 ) // Creo drawing
								{
									isDrwCheckOut=false;
									ITKCALL(RES_is_checked_out(primary,&isDrwCheckOut));
									if(isDrwCheckOut)
									{
										if(DrwcntErr==0)
										{
											DrwcntErr=1;
											setAddStrMBOM(icount,SetChildRelErr,"\n Drwing attached to below Part is in Checkout State, Please Checkin Drawing before Release and then proceed");
											setAddStrMBOM(icount,SetChildRelErr,"\n");
											setAddStrMBOM(icount,SetChildRelErr,Part_no);
											cntFlag = 1;

										}
										else
										{
											setAddStrMBOM(icount,SetChildRelErr,"\n");
											setAddStrMBOM(icount,SetChildRelErr,Part_no);
											DrwcntErr=DrwcntErr+1;
											printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
											cntFlag = 1;
										}

									}
								}


								if( strcmp(type_name,"PDF") ==0 )
								{
									isDrwCheckOut=false;
									ITKCALL(RES_is_checked_out(primary,&isDrwCheckOut));
									if(isDrwCheckOut)
									{
										if(DrwcntErr==0)
										{
											DrwcntErr=1;
											setAddStrMBOM(icount,SetChildRelErr,"\n Drwing attached to below Part is in Checkout State, Please Checkin Drawing before Release and then proceed");
											setAddStrMBOM(icount,SetChildRelErr,"\n");
											setAddStrMBOM(icount,SetChildRelErr,Part_no);
                                        	cntFlag = 1;
										}
										else
										{
											setAddStrMBOM(icount,SetChildRelErr,"\n");
											setAddStrMBOM(icount,SetChildRelErr,Part_no);
											DrwcntErr=DrwcntErr+1;
											printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
										   cntFlag = 1;
										}

									}
								}

							}
						}
						else
						{
							printf("\n No of Attaches are zeroooo");fflush(stdout);

							if(cntErr==0)
							{
								cntErr=1;
								setAddStrMBOM(icount,SetChildRelErr,"\n Drwing Indicator for Below Part is D, Please attached Drawing to it and then Proceed:");
								setAddStrMBOM(icount,SetChildRelErr,"\n");
								setAddStrMBOM(icount,SetChildRelErr,Part_no);
	                           cntFlag = 1;
							}
							else
							{
								setAddStrMBOM(icount,SetChildRelErr,"\n");
								setAddStrMBOM(icount,SetChildRelErr,Part_no);
								cntErr=cntErr+1;
								printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
								cntFlag = 1;
							}

						}
					}

				}
				if(strcmp(Part_ModelIndicator,"Y")==0)
				{
					tag_t	Drft_Rel_tag	= NULLTAG;
					tag_t*	DataItemDoc_tag	= NULLTAG;
					tag_t	SecObjctDSTag	= NULLTAG;
					tag_t	DrftSpecTypeTag	= NULLTAG;
					
					//char   dRftSpectype_name[TCTYPE_name_size_c+1];
					char *dRftSpectype_name  =NULL;

					int Dataitemcount,id;

					int DrftDrwPrsnt,GrnRptAttchd = 0;

					printf("\n Inside mbom_Drg_Part_Checks Model Indicator Y \n");fflush(stdout);
					
					ITKCALL(GRM_find_relation_type("IMAN_specification", &Drft_Rel_tag));
					if (Drft_Rel_tag)
					{
						ITKCALL(GRM_list_secondary_objects_only(AssyTag,Drft_Rel_tag,&Dataitemcount,&DataItemDoc_tag));
						printf("\n T5TaskToPartCreateVal-->Data Item Count Value :------->>>>  %d\n",Dataitemcount);fflush(stdout);

						DrftDrwPrsnt = 0;
						GrnRptAttchd = 0;

						for (id=0;id<Dataitemcount;id++ )
						{
							SecObjctDSTag = DataItemDoc_tag[id];

							if(TCTYPE_ask_object_type(SecObjctDSTag,&DrftSpecTypeTag));
							if(TCTYPE_ask_name2(DrftSpecTypeTag,&dRftSpectype_name));

							printf("\n T5TaskToPartCreateVal-->Data Item attached to Part :: %s\n", dRftSpectype_name);fflush(stdout);

							if(strcmp(dRftSpectype_name,"ProDrw") ==0 || strcmp(dRftSpectype_name,"CMI2Drawing") ==0 || strcmp(dRftSpectype_name,"ProAsm") ==0)
							{
								DrftDrwPrsnt++;
							}

						}
						if (DrftDrwPrsnt > 0)
						{
							printf("\n T5TaskToPartCreateVal-->CAD/2D attached to the part------->>>>  %d\n",DrftDrwPrsnt);fflush(stdout);
						}
						else
						{
							cntErr=1;
							setAddStrMBOM(icount,SetChildRelErr,"\n Model Indicator for Below Part is Y, Part should have Catia/2D drawing attached");
							setAddStrMBOM(icount,SetChildRelErr,"\n");
							setAddStrMBOM(icount,SetChildRelErr,Part_no);
	                        cntFlag = 1;
						}
					}
				}
			}
		}

	return 0;

}

//sanket MBOM task signoff validation start

int NineDigitPrtTypVali(tag_t TaskRevTag,char ***SetChildRelErr,int *icount)
{
	tag_t    tsk_dml_rel_type =NULLTAG;
	int count1,DmlCnt,PartCnt1,k1;
	tag_t *DMLRevision =NULLTAG;
	tag_t DMLRevTag	   =NULLTAG;
	tag_t   DMLTypeTag   =NULLTAG;
	//char			DMLTyp[TCTYPE_name_size_c+1];
	char *DMLTyp  =NULL;
	char *Release_Type  =NULL;
	tag_t  *PartTags1   =NULL;
	tag_t AssyTag1  = NULLTAG;
	char *Part_no1  =NULL;
	char* SubStr = NULL;
	char *Part_Type =NULL;
	char *PartSet =NULL;
	int cnt =0;
	int ErrorFlag =0;


    printf("\n ***********Inside NineDigitPrtTypVali function************* ");fflush(stdout);
   
	ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
	if (tsk_dml_rel_type!=NULLTAG)
	   {
		  ITKCALL(GRM_list_primary_objects_only(TaskRevTag,tsk_dml_rel_type,&count1,&DMLRevision));
		  printf("\n MBOM DML Revision from Task : %d",count1); fflush(stdout);
	                   
          for (DmlCnt=0;DmlCnt<count1;DmlCnt++ )
		      {
			     DMLRevTag = DMLRevision[DmlCnt];

			     ITKCALL (TCTYPE_ask_object_type(DMLRevTag,&DMLTypeTag));
			     ITKCALL (TCTYPE_ask_name2(DMLTypeTag,&DMLTyp));
			    
                 if(tc_strcmp(DMLTyp,"T5_MBOMDMLRevision")==0)
				   {
					  ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_MBOMRlzType",&Release_Type));
					  printf("\n\t Release_Type is :%s",Release_Type);fflush(stdout);

					  if (tc_strcmp(Release_Type,"VCREST" )==0)
						 {
						    ITKCALL(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&PartCnt1,&PartTags1));
						    printf("\nNo of Parts attached with task : %d",PartCnt1);fflush(stdout);
							if (PartCnt1>0)
							   {
								  for (k1=0;k1<PartCnt1 ;k1++ )
									  {
										ErrorFlag =0;
										AssyTag1 =PartTags1[k1];
										
						                ITKCALL(AOM_ask_value_string(AssyTag1,"item_id",&Part_no1));
										printf("\n Part_no  is :%s",Part_no1);	fflush(stdout);

									    ITKCALL(AOM_ask_value_string(AssyTag1,"t5_PartType",&Part_Type));
							            printf("\n Part_Type is :%s",Part_Type);	fflush(stdout);
									    if (tc_strlen(Part_no1)==9)
                                           {
											 SubStr=subString_mbom(Part_no1,8,1);
											 if ((tc_strcmp(Part_Type,"V")!=0) && ((tc_strcmp(SubStr,"R")==0)||(tc_strcmp(SubStr,"L")==0)))
											    {
                                      
													ErrorFlag++;

													 if (tc_strcmp(PartSet,"NULL") !=0) MEM_free(PartSet);
                                                     PartSet =(char *)MEM_alloc(500);
														 
                                                     if (cnt==0)
													    {
														   cnt =1;
														   tc_strcpy(PartSet," ");
														   tc_strcat(PartSet,"\n");
														   tc_strcat(PartSet,"9 digit part should have part type Vehicle. Please get vaild value updated for below part.\n");
														   tc_strcat(PartSet,Part_no1);
																
														}
													  else
														{
														    tc_strcat(PartSet," , ");
  															tc_strcat(PartSet,Part_no1);
															tc_strcat(PartSet," , ");
															cnt = cnt+1;   
														}

													  printf("\n ErrorFlag : %d",ErrorFlag);fflush(stdout);
														if(ErrorFlag>0)
														  {

												             if(cnt==1)
									                           { 
																											  
									                              setAddStrMBOM(icount,SetChildRelErr,PartSet);
										                          cntFlag = 1;
									                            }
									                         else
									                            {
																											  
								                                  setAddStrMBOM(icount,SetChildRelErr,PartSet);
										                          cntFlag = 1;
									                            }
														   }
                                                   }
										   }

									}
								
                               }
						  }
				}
		}
	printf("\n ***********Exit from NineDigitPrtTypVali function************* ");fflush(stdout);

   
   }
   return 0;
}

/// PravinJ Start 

int CheckPrtRelsFrmPlant_MBOM (tag_t TaskTag,char ***SetChildRelErr,int *icount) 
{
	char* inp_Tsk_no=NULL;
	tag_t relation_type	=NULLTAG;
	tag_t	*prtList				=	NULLTAG;
	int prtcnt =0;
	int i,ii=0;
	tag_t prtTAG =NULLTAG;
	char* PartNumbr =NULL;
	char* itemobjecttype =NULL;
	int status_count			=0;
	tag_t*	status_list		=NULLTAG;
	char*  ReleaseStatus	=NULL;
	//char LcsAPLRlzd[40];
	//char LcsSTDRlzd[40];

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
    int cntrlcnt=0;
	int  control_number_found1=0;
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
    tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;
	int     error =0;
	int     errorFlg=0;
	char *partset =NULL;
	int   cnt =0;
	//int cntFlag = 0;


	printf("\n########### Inside CheckPrtRelsFrmPlant_MBOM PravinJ ###################\n");fflush(stdout);

	ITKCALL(AOM_ask_value_string(TaskTag,"item_id",&inp_Tsk_no));
	printf("\n inp_Tsk_no plj is :%s",inp_Tsk_no);	fflush(stdout);

	//pravin start
    tag_t TskToDMLRel = NULLTAG;
    tag_t DMLRevTagg = NULLTAG;
    tag_t DMLTypeTag = NULLTAG;
    tag_t *DMLTagg = NULLTAG;
    tag_t *PartTagsB = NULLTAG;
	int		CountDML	= 0;
	int		Counter	= 0;
	char *DMLTyp1=NULL;
	char *type_dml_name = NULL;
	char *Release_Type1 = NULL;
	char *DML_name1 = NULL;
	char *MbomRlsType = NULL;

	logical isltstdmll;
					ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &TskToDMLRel));
                    if (TskToDMLRel != NULLTAG)
                    {
                        ITKCALL(GRM_list_primary_objects_only(TaskTag, TskToDMLRel, &CountDML, &DMLTagg));
                        printf("\n\n\t\t dss CountDML : %d", CountDML);
                        fflush(stdout);
 
                        for (Counter = 0; Counter < CountDML; Counter++)
                        {
                            ITKCALL(ITEM_rev_sequence_is_latest(DMLTagg[Counter], &isltstdmll));
                            printf("\n\n\t\t isltstdmll : %d\n", isltstdmll);
                            fflush(stdout);
 
                            if (isltstdmll != true)
                            {
                                printf("\n\n\t\t isltstdmll is not true .....\n");
                                fflush(stdout);
                            }
                            else
                            {
                                printf("\n\n\t\t isltstdmll is  true .....\n");
                                fflush(stdout);
                                DMLRevTagg = DMLTagg[Counter];
 
                                ITKCALL(TCTYPE_ask_object_type(DMLRevTagg, &DMLTypeTag));
                                ITKCALL(TCTYPE_ask_name2(DMLTypeTag, &DMLTyp1));
                                printf("\n\n\t\t isltstdmll is  true test .....\n");
                                fflush(stdout);
 
                                if (tc_strcmp(DMLTyp1, "T5_MBOMDMLRevision") == 0)
                                {
                                    ITKCALL(AOM_ask_value_string(DMLRevTagg, "item_id", &DML_name1));
                                    printf("\n PravinJ Test1 DML_name1 founc : %s", DML_name1);
                                    fflush(stdout);
                                     
                                    ITKCALL(AOM_ask_value_string(DMLRevTagg, "t5_rlstype", &Release_Type1));
                                    printf("\n\t PravinJ ERC Release_Type1 is :%s", Release_Type1);
                                    fflush(stdout);

									ITKCALL(AOM_ask_value_string(DMLRevTagg,"t5_MBOMRlzType",&MbomRlsType));
									printf("\n PravinJ MBOM RlsType : %s\n",MbomRlsType);fflush(stdout);
								}
							}
						}
					}
 
	//pravin end

	ITKCALL(QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="ChangRefrnces";
		qry_valuesCntrl1[1]="MbomPrtRlsFrmPlnt";
		qry_valuesCntrl1[2]="0";
		
		ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	if (control_number_found1>0)
	{

	if((tc_strcmp(Release_Type1,"TODR") == 0) || (tc_strcmp(MbomRlsType,"GM_MMDML") == 0)) // ERC --GM // MBOM -- GM_MMDML

	{

	//PlantWiseRelStatGMDML(inp_Tsk_no,LcsAPLRlzd,LcsSTDRlzd);
	//printf("\n LcsAPLRlzd: %s \n",LcsAPLRlzd);

	ITKCALL(GRM_find_relation_type("CMReferences",&relation_type));
	if (relation_type != NULLTAG)
	{
		ITKCALL(GRM_list_secondary_objects_only(TaskTag,relation_type,&prtcnt,&prtList));
		printf("\nNumber of parts found in Reference Folder : %d",prtcnt);fflush(stdout);
		if (prtcnt > 0)
		{
			for (i=0;i<prtcnt;i++)
			{
				prtTAG=prtList[i];
				error =0;
				status_count =0;

                ITKCALL(AOM_ask_value_string(prtTAG,"object_type",&itemobjecttype));
				printf("\n itemobjecttype  is :%s",itemobjecttype);	fflush(stdout);
                if(tc_strcmp(itemobjecttype,"Design Revision") == 0)

				{

				ITKCALL(AOM_ask_value_string(prtTAG,"item_id",&PartNumbr));
				printf("\n PartNumbr  is :%s",PartNumbr);	fflush(stdout);

				ITKCALL(WSOM_ask_release_status_list(prtTAG,&status_count,&status_list));
				printf("\n status_count : %d",status_count);fflush(stdout);

				if ((status_count > 0))
				{

				for (ii= 0;ii<status_count;ii++)
				{
                    ReleaseStatus=NULL;
					ITKCALL(AOM_ask_name(status_list[ii], &ReleaseStatus));
					printf("\n ReleaseStatus %s \n",  ReleaseStatus);fflush(stdout);
					if (tc_strcmp(ReleaseStatus,"T5_MBOMReleased")==0)
					{
					  error++;
                      printf("\n part is released from MBOM.");fflush(stdout);
					  break;
					}
					
				}
				}
				printf("\n error : %d",error);fflush(stdout);
				if (error==0)
				{
					 
					 if (tc_strcmp(partset,"NULL") !=0) MEM_free(partset);
						 partset=(char *)MEM_alloc(1000);
						 
					 if (cnt==0)
					  {
						cnt =1;
						tc_strcpy(partset," ");
						tc_strcat(partset,"\n");
						tc_strcat(partset,"Below parts is not released from MBOM.\n");
						tc_strcat(partset,PartNumbr);
						
					  }
					  else
					   {
						  tc_strcat(partset," , ");
						  tc_strcat(partset,PartNumbr);
						
						  cnt = cnt+1;   
						   
					   }
					   
					   printf("\n Value of cnt is:%d",cnt);fflush(stdout);
					   printf("\n partset is: %s",partset);fflush(stdout);

					   if(cnt==1)
						 { 
							 printf("\n INSIDE if cnt...");fflush(stdout);
							 setAddStrMBOM(icount,SetChildRelErr,partset);
							 cntFlag = 1;
						  }
					   else
						  {
							  printf("\n INSIDE else cnt...");fflush(stdout);
							  setAddStrMBOM(icount,SetChildRelErr,partset);
							  cntFlag = 1;
						  }
				}

			}
            else
		{
		   printf("\n PravinJ object type is not Design Revision hence skiped...");fflush(stdout);
		}

            }


		}
	}
	}
	else
		{
		   printf("\n PravinJ ERC/MBOM DML Release type is not Gate Maturation  hence skiped...");fflush(stdout);
		}
	}


	return 0;
}


/// PravinJ End 



int PartQtyCheck(tag_t TaskTag, char ***SetChildRelErr,int *icount)
{
	tag_t   QueryTag           = NULLTAG;
	int     n_entry            = 2;
	char    *qry_entry[2]      = {"SYSCD","Delete Indicator"};
	char	**qry_values       = (char **) MEM_alloc(5 * sizeof(char *));
	int  control_number_found  =0;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;  
	int i;
	char *info1 	        =NULL;
	char *info2             =NULL;
    char *info3             =NULL;
    char *info4             =NULL;
    char *TaskNo            =NULL; 
    tag_t t_TaskToPart      =NULLTAG;
    int Partcnt,d;
    tag_t *ObjTag           =NULLTAG;
    tag_t PartTag           =NULLTAG;
    char *PartNo            =NULL;
    int n_Cnt,k;
	int Partqty;
	int QtyFlag =0;
	char *  qtypartset = NULL;
    int	PARTCount	= 0;
	int cnt =0;
	tag_t window =NULLTAG;
	tag_t	top_line = NULLTAG;
	tag_t  *children =NULLTAG;
	int ChildItemTag=0;
	tag_t   ChildItemRev=NULLTAG;
    char *childItemName =NULL;
	tag_t rule =NULLTAG;
	int rulefound=0;
	tag_t *closurerule = NULLTAG;
	tag_t CloseRule_tag = NULLTAG;
    char *ChldPrtQty = NULL;
	char *OwningGroup =NULL;
	char *PartType =NULL;

	tag_t bl_Child_dv =NULLTAG;
	
                                         
	printf("\n **********In side of PartQtyCheck function************** ");fflush(stdout);
	                                     
	ITKCALL(QRY_find2("Control Objects...", &QueryTag));
    if (QueryTag != NULLTAG)
	   {
		  printf("\n Control Object Query Found \n");fflush(stdout);
		  qry_values[0]="DUPMDL";
		  qry_values[1]="0";
				
		  ITKCALL(QRY_execute(QueryTag, n_entry, qry_entry, qry_values, &control_number_found, &list_of_WSO_cntrl_tags));
		}
    else
	    {
		  printf("\n Control Object Query not Found ");fflush(stdout);
	    }

	if(control_number_found>0)
	  {
	    for(i=0;i<control_number_found;i++)
		   {
              //ON/OFF/DML DR-status: ,DR0,AR0, (apply reverse in code.)
			  ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags[i], "t5_Userinfo1", &info1));
			  printf("\n Information1 is: %s\n",info1);fflush(stdout);

              //DML From TOO plant: ,DR0TODR1,AR0TOAR1,
			  ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags[i], "t5_Userinfo2", &info2));
	          printf("\n Information2 is: %s\n",info2);fflush(stdout);

              //CHild part type: ,M,D,
              ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags[i], "t5_Userinfo3", &info3));
	          printf("\n Information3 is: %s\n",info3);fflush(stdout);

              //Part Types:,V,VC,VCCR,
              ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags[i], "t5_Userinfo4", &info4));
		      printf("\n Information4 is: %s\n",info4);fflush(stdout);

              ITKCALL(AOM_ask_value_string(TaskTag,"item_id",&TaskNo));
	          printf("\n TaskNo is: %s\n",TaskNo);fflush(stdout);

              ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&t_TaskToPart));
              ITKCALL(GRM_list_secondary_objects_only(TaskTag,t_TaskToPart,&Partcnt,&ObjTag));
	          printf("\n Number of parts found : %d",Partcnt);fflush(stdout);

	          if (Partcnt>0)
	             {
		           for(d=0;d<Partcnt;d++)
		              {
			            PartTag=ObjTag[d];

			            ITKCALL(AOM_ask_value_string(PartTag,"item_id",&PartNo));
                        printf("\n Part number is: %s\n",PartNo);fflush(stdout);
                    
						ITKCALL(BOM_create_window (&window));
					    ITKCALL(CFM_find("MBOM Working and Above", &rule ));
						if (rule!=NULLTAG)
						{
							printf ("\n Revision rule found \n");fflush(stdout);

						}
	                    ITKCALL(BOM_set_window_config_rule(window,rule));
					    ITKCALL(PIE_find_closure_rules2("BOMViewClosureRuleMBOM",PIE_TEAMCENTER, &rulefound, &closurerule));
					    if (rulefound > 0)
			            {
				             CloseRule_tag = closurerule[0];
				             printf ("\n Closure rule found \n");fflush(stdout);
			            }
	                    ITKCALL(BOM_window_set_closure_rule(window,CloseRule_tag,0,NULL,NULL));
					    ITKCALL(BOM_set_window_pack_all (window, true));
                        ITKCALL(BOM_set_window_top_line(window, NULLTAG,PartTag ,NULLTAG, &top_line));
	                    ITKCALL(BOM_line_ask_child_lines (top_line, &PARTCount, &children));

                        printf("\n PARTCount:%d",PARTCount);fflush(stdout);

			            if(PARTCount>0)
                          {
							 if (tc_strcmp(qtypartset,"NULL") !=0) MEM_free(qtypartset);
                             qtypartset =(char *)MEM_alloc(2000);
                                        
							 for(k = 0; k <PARTCount; k++)
							  {
								  
								  bl_Child_dv=children[k];
								
							      ITKCALL(AOM_ask_value_string(bl_Child_dv,"bl_item_item_id",&childItemName));
							      printf("\n ChildPrtNumber=>%s",childItemName);fflush(stdout);

							      ITKCALL(AOM_ask_value_string(bl_Child_dv,"bl_rev_owning_group",&OwningGroup));
						          printf("\n Owning Group=>%s",OwningGroup);fflush(stdout);

								  ITKCALL(AOM_ask_value_string(bl_Child_dv,"bl_quantity",&ChldPrtQty));
						          printf("\n Part Quantity=>%s",ChldPrtQty);fflush(stdout);

								  ITKCALL(AOM_ask_value_string(bl_Child_dv,"bl_Design Revision_t5_PartType",&PartType));
						          printf("\n PartType=>%s",PartType);fflush(stdout);

		
                                  Partqty=0;
                                  Partqty=atoi(ChldPrtQty);
                                   
                                 if((tc_strcmp(PartType,"M")==0)&&(tc_strcmp(OwningGroup,"MBOM")==0))
                                      {
				                        if(tc_strstr(info1,"DUPMDL004")==NULL)
										 {
											
                                           if(Partqty<=1)
											  {
												 printf("\n child part qty is OK...");fflush(stdout);
									          }
										   else
											  {
													QtyFlag++;
													if(cnt==0)
													  {
														cnt = 1;
														tc_strcpy(qtypartset," ");
														tc_strcat(qtypartset,"\n");
                                                        tc_strcat(qtypartset,"Below submodules are allowed only with 1-quantity under vehicle. Please get quantity corrected.\n");
							                            tc_strcat(qtypartset,childItemName);
														
														printf("\n Other than 1 qty Not allowed for part:%s",childItemName);fflush(stdout);
														printf("\n qtypartset:%s",qtypartset);fflush(stdout);

														}
													  else
														 {
														   tc_strcat(qtypartset," , ");
                                                           tc_strcat(qtypartset,childItemName);
														   
														   cnt = cnt+1;
														  }

												}
											}
											else if(tc_strstr(info1,"DUPMDL005")==NULL)
													{
													 
													  if(Partqty!=0)
												        {
												          printf("\n child part qty is OK...");fflush(stdout);
														}
													  else
														{
															QtyFlag++;
														    if(cnt==0)
															  {
																cnt = 1;
                                                                tc_strcpy(qtypartset," ");
														        tc_strcat(qtypartset,"\n");
																tc_strcat(qtypartset,"Below submodules are allowed only with 1-quantity under vehicle. Please get quantity corrected.\n");
							                                    tc_strcat(qtypartset,childItemName);
																
																printf("\n Other than 1 qty Not allowed for part:%s",childItemName);fflush(stdout);
																printf("\n qtypartset:%s",qtypartset);fflush(stdout);

																}
															  else
																{
                                                                  tc_strcat(qtypartset," , ");
                                                                  tc_strcat(qtypartset,childItemName);
																  
																  cnt = cnt+1;
															    }

															}
														 }
											  else
												{
											       printf("\n Inside else OK...");fflush(stdout);

												}
											}
												printf("\n cnt:%d",cnt);fflush(stdout);
												printf("\n QtyFlag:%d",QtyFlag);fflush(stdout);
										}
										if(QtyFlag>0)
                                          {

										    if(cnt==1)
									          { 
																											  
									             setAddStrMBOM(icount,SetChildRelErr,qtypartset);
										         cntFlag = 1;
									           }
									         else
									           {
																											  
								                 setAddStrMBOM(icount,SetChildRelErr,qtypartset);
										         cntFlag = 1;
									            }

							              }
							}
                      }
               }
		    }
		}

  printf("\n **********Out side of PartQtyCheck function************** ");fflush(stdout);
												
 return 0;

}

int ModuleDupCheck(tag_t TaskTag, char ***SetChildRelErr,int *icount)
{

	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 2;
	char    *qry_entryCntrl1[2]  = {"SYSCD","Delete Indicator"};
	char	**qry_valuesCntrl1		= 	(char **) MEM_alloc(5 * sizeof(char *));
	int  control_number_found1=0;
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t   qryTagCntrl2     = NULLTAG;
	int     n_entryCntrl2    = 2;
	char    *qry_entryCntrl2[2]  = {"SYSCD","Delete Indicator"};
	char	**qry_valuesCntrl2		= 	(char **) MEM_alloc(5 * sizeof(char *));
	int  control_number_found2=0;
	tag_t *list_of_WSO_cntrl_tags2=NULLTAG;
	tag_t   qryTagCntrl3     = NULLTAG;
	int     n_entryCntrl3    = 3;
	char    *qry_entryCntrl3[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};
	char	**qry_valuesCntrl3		= 	(char **) MEM_alloc(5 * sizeof(char *));
	int  control_obj_found3=0;
	tag_t *list_of_WSO_cntrl_tags3=NULLTAG;
	int cntrlcnt;
	char *info1 			=NULL;
	char *info2             =NULL;
    char *info3             =NULL;
    char *info4             =NULL;
    char *DMLdr             =NULL;
    char *DmlDrCat          =NULL;
    tag_t dml_tsk_rel_type  =NULLTAG;
    int dmlcount,d;
    tag_t *DMLRevision     =NULLTAG;       
    char *TaskNo            =NULL;
    char *DesignGrp         =NULL; 
    tag_t t_TaskToPart      =NULLTAG;
    int Partcnt,d1;
    tag_t *ObjTag           =NULLTAG;
    tag_t PartTag           =NULLTAG;
    char *PartNo            =NULL;
    char *parttype          =NULL;
    char *ClrInd            =NULL;
    char *PrtDesignGrp      =NULL;
    char *PrtTypCat         =NULL;
    char *partNumber       =NULL;
    int n_Cnt,k,j;
    char *LatChildName     =NULL;
    int NonModulerFlag =0;
    int info1Flag =0;
	char *LatChildName1  =NULL;
    char *PartType2      =NULL;
    char* SubStr1 = NULL;
	char *inform1 =NULL;
	char *inform2 =NULL;
	char *inform3 =NULL;
	char *inform4 =NULL;
    int QtyFlag =0;
	char *  qtypartset = NULL;
	int duplFlag=0;
	int m;
	int finalduplFlag =0;
	char *DUPpartset =NULL;
	tag_t DMLRevTag =NULLTAG;
	char *PartType1 =NULL;
	char *DMLNumber =NULL;
	char *DMLDRStatus =NULL;
    int	PARTCount	= 0;
	int childBS;
	int cnt=0;
    tag_t window =NULLTAG;
	tag_t rule =NULLTAG;
	int rulefound=0;
	tag_t *closurerule = NULLTAG;
	tag_t CloseRule_tag = NULLTAG;
	tag_t	top_line = NULLTAG;
	tag_t  *children =NULLTAG;
	int ChildItemTag=0;
	tag_t   ChildItemRev=NULLTAG;
    char *childItemName =NULL;
	int ChildItemTag1=0;
	tag_t   ChildItemRev1=NULLTAG;
	char *childItemName1 =NULL;
	char *ChldPrtQty = NULL;
	char *OwningGroup =NULL;
	int Partqty=0;
	tag_t bl_Child_dv =NULLTAG;
	tag_t bl_Child_dv1 =NULLTAG;
	char *OwningGrp    =NULL;




    printf("\n ************** Inside of ModuleDupCheck function ****************  \n");fflush(stdout);

    ITKCALL(QRY_find2("Control Objects...", &qryTagCntrl1));
    
	if (qryTagCntrl1)
	  {
		 printf("\n Control Object Query Found \n");fflush(stdout);
		 qry_valuesCntrl1[0]="DUPMDL";
		 qry_valuesCntrl1[1]="0";

		 ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		 printf("\n control_number_found1: %d",control_number_found1);fflush(stdout);
	  }
   else
	  {
		 printf("\n Control Object Query not Found \n");fflush(stdout);
	  }

   ITKCALL(QRY_find2("Control Objects...", &qryTagCntrl2));
   if (qryTagCntrl2 != NULLTAG)
	  {
		  printf("\n Control Object Query Found2 \n");fflush(stdout);
		  qry_valuesCntrl2[0]="MDLDUP";
		  qry_valuesCntrl2[1]="0";

		  ITKCALL(QRY_execute(qryTagCntrl2, n_entryCntrl2, qry_entryCntrl2, qry_valuesCntrl2, &control_number_found2, &list_of_WSO_cntrl_tags2));
		  printf("\n control_number_found2: %d",control_number_found2);fflush(stdout);
	  }
	else
	  {
		 printf("\n Control Object Query not Found2 \n");fflush(stdout);
	  }

	 if(control_number_found1>0)
	   {
		 for(cntrlcnt=0;cntrlcnt<control_number_found1;cntrlcnt++)
			{
			   ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo1", &info1));
			   printf("\n Information1 is: %s\n",info1);fflush(stdout);

			   ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo2", &info2));
			   printf("\n Information2 is: %s\n",info2);fflush(stdout);

			   ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo3", &info3));
			   printf("\n Information3 is: %s\n",info3);fflush(stdout);

			   ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo4", &info4));
			   printf("\n Information4 is: %s\n",info4);fflush(stdout);

			   ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &dml_tsk_rel_type));
			   if (dml_tsk_rel_type!=NULLTAG)
				{
					ITKCALL(GRM_list_primary_objects_only(TaskTag,dml_tsk_rel_type,&dmlcount,&DMLRevision));
					printf("\n MBOM DML Revision from Task : %d",dmlcount); fflush(stdout);
				}
			  for (d=0;d<dmlcount;d++ )
				{
				  DMLRevTag = DMLRevision[d];

				  ITKCALL(AOM_ask_value_string(DMLRevTag,"item_id",&DMLNumber));
				  printf("\n DMLNumber is :%s",DMLNumber); fflush(stdout);

				  ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&DMLDRStatus));
				  printf("\n DMLDRStatus is :%s",DMLDRStatus); fflush(stdout);


			      if (tc_strcmp(DmlDrCat,"NULL") !=0) MEM_free(DmlDrCat);
			      DmlDrCat	=	(char *)MEM_alloc(50);

			      tc_strcpy(DmlDrCat,"");
			      tc_strcpy(DmlDrCat,",");
			      tc_strcat(DmlDrCat,DMLDRStatus);
			      tc_strcat(DmlDrCat,",");
			      printf("\n DmlDrCat.:%s",DmlDrCat);fflush(stdout);

			     if(tc_strstr(info1,DmlDrCat)==NULL)
				   {

					  printf("\n T2:TPL/Veh DML DR4 allowed..");fflush(stdout);

					  ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&t_TaskToPart));
					  ITKCALL(GRM_list_secondary_objects_only(TaskTag,t_TaskToPart,&Partcnt,&ObjTag));
					  printf("\n Number of parts found : %d",Partcnt);fflush(stdout);
                      
					  if (Partcnt>0)
						 {
							for(d1=0;d1<Partcnt;d1++)
							   {
								  PartTag	=ObjTag[d1];

								  ITKCALL(AOM_ask_value_string(PartTag,"item_id",&PartNo));
								  printf("\n item_id is: %s\n",PartNo);fflush(stdout);

								  ITKCALL(AOM_ask_value_string(PartTag,"t5_PartType",&parttype));
								  printf("\n Part type is: %s\n",parttype);fflush(stdout);

								  ITKCALL(AOM_ask_value_string(PartTag,"t5_ColourInd",&ClrInd));
								  printf("\n Colour Ind of Part is: %s\n",ClrInd);fflush(stdout);

								  ITKCALL(AOM_ask_value_string(PartTag,"t5_DesignGrp",&PrtDesignGrp));
								  printf("\n Design group of Part is: %s\n",PrtDesignGrp);fflush(stdout);

								  if (tc_strcmp(PrtTypCat,"NULL") !=0) MEM_free(PrtTypCat);
								  PrtTypCat	=	(char *)MEM_alloc(50);
								  tc_strcpy(PrtTypCat,"");
								  tc_strcpy(PrtTypCat,",");
								  tc_strcat(PrtTypCat,parttype);
								  tc_strcat(PrtTypCat,",");
							      printf("\n PrtTypCat.:%s",PrtTypCat);fflush(stdout);

								  if (tc_strcmp(ClrInd,"C")!=0)
									 {
										if(tc_strstr(info4,PrtTypCat)!=NULL)
										  {
											 NonModulerFlag=0;

						                     ITKCALL(BOM_create_window (&window));
					                         ITKCALL(CFM_find("MBOM Working and Above", &rule ));
						                     if(rule!=NULLTAG)
						                       {
							                      printf ("\n Revision rule found \n");fflush(stdout);

						                       }
	                                          ITKCALL(BOM_set_window_config_rule(window,rule));
					                          ITKCALL(PIE_find_closure_rules2("BOMViewClosureRuleMBOM",PIE_TEAMCENTER, &rulefound, &closurerule ));
			                                  if (rulefound > 0)
			                                   {
				                                  CloseRule_tag = closurerule[0];
				                                  printf ("\n Closure rule found \n");fflush(stdout);
			                                   }
	                                          ITKCALL(BOM_window_set_closure_rule(window,CloseRule_tag,0,NULL,NULL));
					                          ITKCALL(BOM_set_window_pack_all (window, true));
                                              ITKCALL(BOM_set_window_top_line(window, NULLTAG,PartTag ,NULLTAG, &top_line));
	                                          ITKCALL(BOM_line_ask_child_lines (top_line, &PARTCount, &children));

                                              printf("\n PARTCount:%d",PARTCount);fflush(stdout);
													   

										     ITKCALL(QRY_find2("Control Objects...", &qryTagCntrl3));
										     if(qryTagCntrl3 != NULLTAG)
												{
												   printf("\n Control Object Query Found \n");fflush(stdout);
												   qry_valuesCntrl3[0]="ModuleRel";
												   qry_valuesCntrl3[1]=PartNo;
												   qry_valuesCntrl3[2]="0";

												   ITKCALL(QRY_execute(qryTagCntrl3, n_entryCntrl3, qry_entryCntrl3, qry_valuesCntrl3, &control_obj_found3, &list_of_WSO_cntrl_tags3));
												 }
											  else
												 {
													printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
												 }
											  if(control_obj_found3>0)
												 {
													NonModulerFlag=1;
												    printf("\n It is 100 percentage modular BOM....\n");fflush(stdout); 
												 }
											   else
												 {

													if(PARTCount>0)
													  {
														
                                                        for (j=0; j<PARTCount; j++)
															{
															    NonModulerFlag=1;

																bl_Child_dv =children[j];

																ITKCALL(AOM_ask_value_string(bl_Child_dv,"bl_item_item_id",&childItemName));
							                                    printf("\n ChildPrtNumber=>%s",childItemName);fflush(stdout);

							                                    ITKCALL(AOM_ask_value_string(bl_Child_dv,"bl_Design Revision_t5_PartType",&PartType1));
						                                        printf("\n PartType=>%s",PartType1);fflush(stdout);

																ITKCALL(AOM_ask_value_string(bl_Child_dv,"bl_rev_owning_group",&OwningGrp));
						                                        printf("\n Owning OwningGrp=>%s",OwningGrp);fflush(stdout);

                                                                if((tc_strcmp(PartType1,"T")==0) && (tc_strcmp(OwningGrp,"MBOM")==0))
																  {
																	 NonModulerFlag=0;
																	 printf("\n T15:NonModulerFlag: [%d]\n",NonModulerFlag);fflush(stdout);
																	 break;
																  }
															   }
															}
														}
													 printf("\n T16:Final:NonModulerFlag: [%d]\n",NonModulerFlag);fflush(stdout);
													//If moduler BOM then check module address 
													 if(NonModulerFlag >0)
													   {
														 printf("\n T17:As moduler BOM then check module address: [%d] PartNo :%s \n",NonModulerFlag,PartNo);fflush(stdout);

														 info1Flag=0;
														 
														 for (k =0; k<PARTCount; k++)
														  {
															 info1Flag=0;
                                                             bl_Child_dv1 =children[k];
															 
							                                ITKCALL(AOM_ask_value_string(bl_Child_dv1,"bl_item_item_id",&childItemName1));
							                                printf("\n ChildPrtNumber=>%s",childItemName1);fflush(stdout);

							                                ITKCALL(AOM_ask_value_string(bl_Child_dv1,"bl_rev_owning_group",&OwningGroup));
						                                    printf("\n Owning Group=>%s",OwningGroup);fflush(stdout);

								                            ITKCALL(AOM_ask_value_string(bl_Child_dv1,"bl_quantity",&ChldPrtQty));
						                                    printf("\n Part Quantity=>%s",ChldPrtQty);fflush(stdout);

								                            ITKCALL(AOM_ask_value_string(bl_Child_dv1,"bl_Design Revision_t5_PartType",&PartType2));
						                                    printf("\n PartType2=>%s",PartType2);fflush(stdout);
	
															SubStr1=subString_mbom(childItemName1,4,5);
															printf("\n### T24:::Checking for module address for part [%s]",SubStr1);

															Partqty=0;
                                                            Partqty=atoi(ChldPrtQty);

															 if((tc_strstr(info3,PartType2)!=NULL)&&(tc_strcmp(OwningGroup,"MBOM")==0))
															   {
																 if(control_number_found2>0)
																   {
																	 for (m=0;m<control_number_found2;m++ )
																	 {
																		ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags2[m], "t5_Userinfo1", &inform1));
																		printf("\n Information1 is: %s\n",inform1);fflush(stdout);

																		ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags2[m], "t5_Userinfo2", &inform2));
																		printf("\n Information2 is: %s\n",inform2);fflush(stdout);

																		ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags2[m], "t5_Userinfo3", &inform3));
																		printf("\n Information3 is: %s\n",inform3);fflush(stdout);

																		ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags2[m], "t5_Userinfo4", &inform4));
																		printf("\n Information4 is: %s\n",inform4);fflush(stdout);

																		if(tc_strstr(inform1,SubStr1)!=NULL)
																		  {
																			 info1Flag=1;
																			 printf("\n  breaking......:info1Flag: %d",info1Flag);fflush(stdout);
																			 break;
																		  }
																		else if(tc_strstr(inform2,SubStr1)!=NULL)
																		 {
																			 info1Flag=1;
																			 printf("\n  breaking......:info2Flag: %d",info1Flag);fflush(stdout);
																			 break;
																		 }
																	    else if(tc_strstr(inform3,SubStr1)!=NULL)
																		 {
																			 info1Flag=1;
																			 printf("\n  breaking......:info3Flag: %d",info1Flag);fflush(stdout);
																			 break;
																		 }
																	    else if(tc_strstr(inform4,SubStr1)!=NULL)
																		 {
																			 info1Flag=1;
																			 printf("\n  breaking......:info4Flag: %d",info1Flag);fflush(stdout);
																			 break;
																		 }
																	    else
																		 {
																			 printf("\n  not found : %d",info1Flag);fflush(stdout);
																		 }
																	 }

																   }

																	if (info1Flag >0)
																	 {
																		printf("\n P52:duplication allowed for part:%s",childItemName1);fflush(stdout);
																	 }
																	 else
																	 { 
															

																		 printf("\n P52:duplication NOT allowed for part:%s",childItemName1);fflush(stdout);
																	
																		 if(Partqty>1)
																		 {
																			 duplFlag++;
																			 if (tc_strcmp(DUPpartset,"NULL") !=0) MEM_free(DUPpartset);
       			    		                                                     DUPpartset=(char *)MEM_alloc(1000);
		         			                                                     
																			 if (cnt==0)
																			  {
																				cnt =1;
																				tc_strcpy(DUPpartset," ");
																				tc_strcat(DUPpartset,"\n");
                                                                                tc_strcat(DUPpartset,"Below submodules are not allowed duplicated under vehicle. Please remove duplication.\n");
																				tc_strcat(DUPpartset,childItemName1);
																				
																			  }
																			  else
																			   {
																				  tc_strcat(DUPpartset," , ");
																				  tc_strcat(DUPpartset,childItemName1);
																				
																				  cnt = cnt+1;   
																				   
                                                                               }
																			   printf("\n Value of duplicate flag is:%d",duplFlag);fflush(stdout);
																			   printf("\n Value of cnt is:%d",cnt);fflush(stdout);
																			   printf("\n DUPpartset is: %s",DUPpartset);fflush(stdout);

																			   if (duplFlag>0)
										                                           {
										                                               if(cnt==1)
										                                                 { 
											                                                 printf("\n INSIDE IF cnt...");fflush(stdout);
										                                                     setAddStrMBOM(icount,SetChildRelErr,DUPpartset);
											                                                 cntFlag = 1;
										                                                  }
										                                                else
										                                                   {
										                                                      printf("\n INSIDE else cnt...");fflush(stdout);
											                                                  setAddStrMBOM(icount,SetChildRelErr,DUPpartset);
											                                                  cntFlag = 1;
										                                                    }
										                                            }

																		 }

																	 }
															   }
														  }
													   }  

													}
											   }
										}
								}
						}
				}
		}
	}

 printf("\n ************** Outside of ModuleDupCheck function ****************  \n");fflush(stdout);

return 0;

}

int DMLTypeDRFun(tag_t DMLObj)
{

	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 2;
	char    *qry_entryCntrl1[2]  = {"SYSCD","Delete Indicator"};
	char	**qry_valuesCntrl1		= 	(char **) MEM_alloc(5 * sizeof(char *));
	int  control_number_found1=0;
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	int cntrlcnt;
	char *sRLTPinfo1 			= NULL;
	char *sRLTPinfo2            = NULL;
	char *MBOMRlzType           = NULL;
	char *RelTypeCat            = NULL;

    printf("\n ************** Inside DMLTypeDRFun *************\n");fflush(stdout);

    ITKCALL(AOM_ask_value_string(DMLObj, "t5_MBOMRlzType", &MBOMRlzType));
	printf("\n MBOM DML Rlz type is: %s\n",MBOMRlzType);fflush(stdout);


	if (tc_strcmp(RelTypeCat,"NULL") !=0) MEM_free(RelTypeCat);
    RelTypeCat	=	(char *)MEM_alloc(50);

	tc_strcpy(RelTypeCat,"");
    tc_strcpy(RelTypeCat,",");
    tc_strcat(RelTypeCat,MBOMRlzType);
	tc_strcat(RelTypeCat,",");
	printf("\n DR:RelTypeCat.:%s",RelTypeCat);fflush(stdout);

	ITKCALL(QRY_find2("Control Objects...", &qryTagCntrl1));
	        if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="DMLTypMBOM";
				qry_valuesCntrl1[1]="0";
				
				ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
			}

			if (control_number_found1>0)
			{
				for(cntrlcnt=0;cntrlcnt<control_number_found1;cntrlcnt++)
					{
						ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo1", &sRLTPinfo1));
						printf("\n Information1 is: %s\n",sRLTPinfo1);fflush(stdout);

						ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo2", &sRLTPinfo2));
						printf("\n Information2 is: %s\n",sRLTPinfo2);fflush(stdout);

						if (tc_strstr(sRLTPinfo1,RelTypeCat)!=NULL || tc_strstr(sRLTPinfo2,RelTypeCat)!=NULL)
						{
						   printf("\n DR:DML eligible for DR-validation.");fflush(stdout);
			               return 1; 
						}
                        else
						{
							printf("\n DR:DML NOT eligible for DR-validation.");fflush(stdout);
			                return 0;
						}

					}


			}
			printf("\n ************** Outside DMLTypeDRFun *************\n");fflush(stdout);

	CLEANUP:
		return 0;

	EXIT:
		return 0;

}


int PartTypeDRFun(tag_t PartObj)
{


  char *parttype  =NULL;
  char *PartTypeCat          =NULL;
  tag_t   qryTagCntrl1     = NULLTAG;
  int     n_entryCntrl1    = 2;
  char    *qry_entryCntrl1[2]  = {"SYSCD","Delete Indicator"};
  char	**qry_valuesCntrl1		= 	(char **) MEM_alloc(5 * sizeof(char *));
  int  control_number_found1=0;
  tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
  int cntrlcnt;
  char *sRLTPinfo1 			= NULL;
  char *sRLTPinfo2            = NULL;




  printf("\n ************** Inside PartTypeDRFun *************\n");fflush(stdout);
  ITKCALL(AOM_ask_value_string(PartObj,"t5_PartType",&parttype));
  printf("\n Part type is: %s\n",parttype);fflush(stdout);

    if (tc_strcmp(PartTypeCat,"NULL") !=0) MEM_free(PartTypeCat);
    PartTypeCat	=	(char *)MEM_alloc(50);

	tc_strcpy(PartTypeCat,"");
    tc_strcpy(PartTypeCat,",");
    tc_strcat(PartTypeCat,parttype);
	tc_strcat(PartTypeCat,",");
  printf("\n DR:PartTypeCat.:%s",PartTypeCat);fflush(stdout);
  ITKCALL(QRY_find2("Control Objects...", &qryTagCntrl1));
	        if (qryTagCntrl1 != NULLTAG)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="PrtTypMBOM";
				qry_valuesCntrl1[1]="0";
				
				ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
			}

			if (control_number_found1>0)
			{
				for(cntrlcnt=0;cntrlcnt<control_number_found1;cntrlcnt++)
					{
						ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo1", &sRLTPinfo1));
						printf("\n Information1 is: %s\n",sRLTPinfo1);fflush(stdout);

						ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo2", &sRLTPinfo2));
						printf("\n Information2 is: %s\n",sRLTPinfo2);fflush(stdout);
						if (tc_strstr(sRLTPinfo1,parttype)!=NULL || tc_strstr(sRLTPinfo2,parttype)!=NULL)
						{
						   printf("\n DR:Part type eligible for DR-validation.");fflush(stdout);
			               return 1; 
						}
                        else
						{
							printf("\n DR:Part Type NOT eligible for DR-validation.");fflush(stdout);
			                return 0;
						}


					}
			}
			printf("\n ************** Outside PartTypeDRFun *************\n");fflush(stdout);

	CLEANUP:
		return 0;

	EXIT:
		return 0;


}


int ParentChildDrVali(tag_t TaskTag,char ***SetChildRelErr,int *icount)
{
	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 2;
	char    *qry_entryCntrl1[2]  = {"SYSCD","Delete Indicator"};
	char	**qry_valuesCntrl1		= 	(char **) MEM_alloc(5 * sizeof(char *));
	int  control_number_found1=0;
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	int cntrlcnt,j;
	char *sRLTPinfo1 			= NULL;
	char *DML_no              =NULL;
	char *MBOMRlzType           =NULL;
	char *cDRstatus             =NULL;
	char *ObjType               =NULL;
	char *  RelTypeCat          =NULL;
	int DMLtypflg=0;
	tag_t tsk_dml_rel_type      =NULLTAG;
	tag_t t_TaskToPart          =NULLTAG;
	int count =0;
	tag_t *TaskRevision = NULLTAG;
	tag_t *CCVList     = NULLTAG;
	tag_t PartTag = NULLTAG;
	char *TaskNo                =NULL;
	int CCVcnt =0;
	char *PartNo                =NULL;
    char *parttype              =NULL;
    char *partDR                =NULL;
	char *RevID                 =NULL;
    char *ClrInd                =NULL;
	char *PrtObjTyp             =NULL;
	char *ProjCode              =NULL;
	int Parttypflg;
	tag_t  	PrtCls =NULLTAG;
	char *PrtClass =NULL;
	tag_t	window	            =NULLTAG;
	tag_t	sn_rule			    =NULLTAG;
	tag_t	top_line	        =NULLTAG;
	char *partNumber            =NULLTAG;
	int n_Cnt,jcnt;
	tag_t  *children			=NULLTAG;
	tag_t bl_Child_dv		    =NULLTAG;
	char *LatChildName          =NULL;
	char *PartType1             =NULL;
	char *item_Rev_Seq          =NULL;
	char *ChildColInd           =NULL;
	char *PrtDRstus             =NULL;
	char *PrtProj               =NULL;
	char *PartSet               =NULL;
	char *DMLDRStr              =NULL;
	char *PRTDRStr             =NULL;
	tag_t  	DMLCls              =NULLTAG;
	char *dmlClass              =NULL;
	int DRDMLtypeflag=0;
	int GrpSuccessFlag=0;
	int iccv;
	int PRTSTVALU=0;
	int DMLSTVALU=0; 
	char *DRCaseSet             =NULL;
	tag_t qryTag                =NULLTAG;
	int n_entry                 =3;
	char    *qry_entry[3]  = {"ID","AR/DR Status","Name"};

	int    	num_to_sort =	1;
	char 	*keys[1] 	= 	{"creation_date"};
    int  	orders[1]  	=	{2};
	tag_t *part_tags            =NULLTAG;
	int  part_found             =0;
	char *PrtRlsStatus          =NULL;
	char *OwningGroup           =NULL;
	char	**qry_values= (char **) MEM_alloc(5 * sizeof(char *));
	int ChildAttached=0;
    tag_t TaskToPart1         =NULLTAG;
	int TaskCount             =0;
	tag_t *TaskList           =NULLTAG;
	int t;
    tag_t TaskTag1             =NULLTAG;
	char *TaskNo1              =NULL;
	int ErrorFlag =0;
	char *ErrorSet             =NULL;
	int cnt =0;
    tag_t TskToDMLRel =NULLTAG;
	int CountDML =0;
	tag_t *DMLTagg =NULLTAG;
	int f;
	tag_t DMLTag =NULLTAG;
	char *DMLNumber =NULL;
	char  RevRuleInfo1[40];
	char  closRuleInfo2[40];
    char  BVRInfo3[40];
	char  CurMskInfo4[40];
    struct			BomChldStrut	ChldStrutBdySh[5000];
    int	PARTCount	= 0;
	int childBS;
	
    printf("\n ************** Inside ParentChildDrVali Function *************\n");fflush(stdout);

	ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &TskToDMLRel));
	if (TskToDMLRel!=NULLTAG)
	   {
		  ITKCALL(GRM_list_primary_objects_only(TaskTag,TskToDMLRel,&CountDML,&DMLTagg));
		  printf("\n CountDML : %d",CountDML);fflush(stdout);

		 for (f=0;f<CountDML ;f++ )
			{
			   DMLTag =DMLTagg[f];
				
	           ITKCALL(AOM_ask_value_string(DMLTag, "item_id", &DML_no));
               ITKCALL(AOM_ask_value_string(DMLTag, "t5_MBOMRlzType", &MBOMRlzType));
	           ITKCALL(AOM_ask_value_string(DMLTag, "t5_cDRstatus", &cDRstatus));
	           ITKCALL(POM_class_of_instance(DMLTag,&DMLCls));
               ITKCALL(POM_name_of_class(DMLCls,&dmlClass));

               printf("\n item_id is: %s\n",DML_no);fflush(stdout);
	           printf("\n t5_MBOMRlzType is: %s\n",MBOMRlzType);fflush(stdout);
	           printf("\n t5_cDRstatus is: %s\n",cDRstatus);fflush(stdout);
	           printf("\n dmlClass is: %s\n",dmlClass);fflush(stdout);

               if (tc_strcmp(dmlClass,"T5_MBOMDMLRevision")==0)
                  {
		            DRDMLtypeflag=0;
		            DRDMLtypeflag= DMLTypeDRFun(DMLTag);
		            printf("\n DRDMLtypeflag:%d.",DRDMLtypeflag);fflush(stdout);

		           if (DRDMLtypeflag > 0)
		             {
			
					   ITKCALL(AOM_ask_value_string(TaskTag,"item_id",&TaskNo));
					   printf("\n TaskNo is: %s\n",TaskNo);fflush(stdout);

					   ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&t_TaskToPart));
                       ITKCALL(GRM_list_secondary_objects_only(TaskTag,t_TaskToPart,&CCVcnt,&CCVList));
	                   printf("\nNumber of parts found : %d",CCVcnt);fflush(stdout);
					   for (iccv=0;iccv<CCVcnt ;iccv++ )
					     {
                         
						  PartTag	=	CCVList[iccv];
						  if (tc_strcmp(PartSet,"NULL") !=0) MEM_free(PartSet);

						  ITKCALL(AOM_ask_value_string(PartTag,"item_id",&PartNo));
			              ITKCALL(AOM_ask_value_string(PartTag,"t5_PartType",&parttype));
						  ITKCALL(AOM_ask_value_string(PartTag,"t5_PartStatus",&partDR));
						  ITKCALL(AOM_ask_value_string(PartTag,"item_revision_id",&RevID));
						  ITKCALL(AOM_ask_value_string(PartTag,"t5_ColourInd",&ClrInd));
					      ITKCALL(POM_class_of_instance(PartTag,&PrtCls));
						  ITKCALL(POM_name_of_class(PrtCls,&PrtClass));
					      ITKCALL(AOM_ask_value_string(PartTag,"t5_ProjectCode",&ProjCode));

						  printf("\n item_id is: %s\n",PartNo);fflush(stdout);
						  printf("\n Part type is: %s\n",parttype);fflush(stdout);
						  printf("\n Part Status is: %s\n",partDR);fflush(stdout);
						  printf("\n Part Rev ID is: %s\n",RevID);fflush(stdout);
						  printf("\n Part Colour Indicator is: %s\n",ClrInd);fflush(stdout);
						  printf("\n Part class is: %s\n",PrtClass);fflush(stdout);
						  printf("\n Part proj code is: %s\n",ProjCode);fflush(stdout);

						  if((tc_strcmp(parttype,"D")==0)|| (tc_strcmp(parttype,"CP")==0) || (tc_strcmp(ProjCode,"1111")==0)|| (tc_strcmp(PrtClass,"T5_SparKit")==0))
						   {
							  printf("\n CPModule/Dummy/Sparekit skipped:[%s]\n",PartNo);fflush(stdout);
						   }
						  else
						   {

							 GrpSuccessFlag=0;
					         printf("\n DRVLI:Checking for BOM...");fflush(stdout);

							 Parttypflg=0;
					         Parttypflg= PartTypeDRFun(PartTag);
					         printf("\n DRVLI:Parttypflg:%d.",Parttypflg);fflush(stdout);
							 if (Parttypflg>0)
							 {
							   if((tc_strcmp(ClrInd,"Y")==0) || (tc_strcmp(ClrInd,"N")==0)||(tc_strcmp(PrtClass,"Design Revision")==0)) 
								 {

								     get_RRCRBVRCVm(RevRuleInfo1,closRuleInfo2,BVRInfo3,CurMskInfo4);

	                                 printf("\n RevRuleInfo1 => %s \n",RevRuleInfo1);fflush(stdout);
						             printf("\n closRuleInfo2 => %s \n",closRuleInfo2);fflush(stdout);
				                     printf("\n BVRInfo2 => %s \n",BVRInfo3);fflush(stdout);
				                     printf("\n Info3 => %s \n",CurMskInfo4);fflush(stdout);
                           
						             PARTCount=0;
                                     ITKCALL(Get_Part_BOM_Lvl(PartTag,1,closRuleInfo2,RevRuleInfo1,BVRInfo3,ChldStrutBdySh,&PARTCount));
						             printf("\n PARTCount:%d",PARTCount);fflush(stdout); 

									if (PARTCount>0)
									 {
											jcnt=0;
											
										   for (jcnt = 1; jcnt <= PARTCount; jcnt++)
											{
											   ErrorFlag=0;
											   GrpSuccessFlag=0;
                                               bl_Child_dv	= NULLTAG;

		        				               bl_Child_dv=ChldStrutBdySh[jcnt].child_objs_bvr;

											   ITKCALL(AOM_ask_value_string(bl_Child_dv,"bl_item_item_id",&LatChildName));
											   printf("\n LatChildName Parts Id :%s",LatChildName);

											   ITKCALL(AOM_ask_value_string(bl_Child_dv,"bl_rev_item_revision_id", &item_Rev_Seq));
											   printf("\n item_Rev_Seq :%s",item_Rev_Seq); fflush(stdout);
																
                                               ITKCALL(AOM_ask_value_string(bl_Child_dv,"bl_Design_t5_RevPartType",&PartType1));
											   printf("\nChildName Parts Type :%s",PartType1);

											   ITKCALL(AOM_ask_value_string(bl_Child_dv, "bl_T5_ClrPartRevision_t5_ColourInd", &ChildColInd ));
											   printf("\n Non-color part Indicator is--> : %s\n",ChildColInd); fflush(stdout);

											   ITKCALL(AOM_UIF_ask_value(bl_Child_dv,"bl_Design Revision_t5_PartStatus",&PrtDRstus));
											   printf("\n  Part DR status is : %s\n",PrtDRstus); fflush(stdout);

						                       ITKCALL(AOM_ask_value_string(bl_Child_dv,"bl_Design Revision_t5_ProjectCode",&PrtProj));
											   printf("\n  Part project code is : %s\n",PrtProj); fflush(stdout);
												   
											   ITKCALL(AOM_ask_value_string(bl_Child_dv,"bl_rev_release_status_list",&PrtRlsStatus));
											   printf("\n  Part relese status is : %s\n",PrtRlsStatus); fflush(stdout);

											   ITKCALL(AOM_ask_value_string(bl_Child_dv,"bl_rev_owning_group",&OwningGroup));
						                       printf("\n Owning Group is : %s",OwningGroup);fflush(stdout);


											   DMLDRStr=NULL;
									           PRTDRStr=NULL;
									           PRTSTVALU=0;
									           DMLSTVALU=0;

											   PRTDRStr=subString_mbom(PrtDRstus, 2, 1);
									           DMLDRStr=subString_mbom(cDRstatus, 2, 1);
									           printf("\n DR: DMLDRStr: %s",DMLDRStr);fflush(stdout);
									           printf("\n DR: PRTDRStr: %s",PRTDRStr);fflush(stdout);
									           PRTSTVALU=atoi(PRTDRStr);
									           DMLSTVALU=atoi(DMLDRStr);
									           printf("\n DR: PRTSTVALU: %d DMLSTVALU: %d",PRTSTVALU,DMLSTVALU);fflush(stdout);

											  if(tc_strcmp(OwningGroup,"MBOM")==0)
											    {

										
											     if((tc_strcmp(PartType1,"D")==0) || (tc_strcmp(PartType1,"CP")==0)|| (tc_strcmp(PrtProj,"1111")==0)|| (tc_strcmp(PrtProj,"T5_SparKit")==0))
									             {
										           printf("\n DRVLI:Obsolete/Dummy/Oscitem/Sparekit skipped:%s",LatChildName);fflush(stdout);
									             }
											     else if (tc_strstr(item_Rev_Seq,"NR")!=NULL)
											     {
												  if ((tc_strcmp(cDRstatus,"DR3P")==0)||(tc_strcmp(cDRstatus,"AR3P")==0))
												   {
													   if ((tc_strcmp(PrtDRstus,"DR4")==0)||(tc_strcmp(PrtDRstus,"AR4")==0)||(tc_strcmp(PrtDRstus,"AR5")==0)||(tc_strcmp(PrtDRstus,"DR5")==0)||(tc_strcmp(PrtDRstus,"DR3P")==0)||(tc_strcmp(PrtDRstus,"AR3P")==0))
													    {
														   printf("\n DR3P DML, SO ABOVE DR-STATUS CHILD PARTS ALLOWED:%s",LatChildName);fflush(stdout);
													       if((tc_strcmp(parttype,"G")==0)||(tc_strcmp(PrtClass,"Design Revision")==0))
													         {
														        GrpSuccessFlag=1;
														        printf("\n DR3P:One child part passed for group id:%s",LatChildName);fflush(stdout);
														        break;
													         }
													     }
													   else
													    {  
														   
														   ErrorFlag++;
														   printf("\n DRVLI:DR3P ERROR:%s",LatChildName);fflush(stdout);
														   printf("\n  Value of ErrorFlag is:%d",ErrorFlag);fflush(stdout);
														   PartSet=(char *)MEM_alloc(500);
														   if (tc_strstr(PartSet,LatChildName)==NULL)
														   {
															 
														      tc_strcat(PartSet,LatChildName);
														      
															  printf("\n DRVLI: Part added to error list1: %s",LatChildName);fflush(stdout);
														   }
											

													    }
                                                      
												   }
												   else
												     {
													   if (PRTSTVALU >= DMLSTVALU)
													    {
														   printf("\n DRVLI:child passed:[%s]\n",LatChildName);fflush(stdout);
														   if ((tc_strcmp(parttype,"G")==0)||(tc_strcmp(PrtClass,"Design Revision")==0))
														   {
															   GrpSuccessFlag=1;
														       printf("\n DRVLI:One child part passed for group id:%s",LatChildName);fflush(stdout);
														       break;
														   }
													    }
													   else
														{
															   printf("\n DRVLI:error child part1:%s",LatChildName);fflush(stdout);
															   PartSet=(char *)MEM_alloc(500);
															 
														      if (tc_strstr(PartSet,LatChildName)==NULL)
														         {
																    ErrorFlag++;
																    printf("\n  Value of ErrorFlag is:%d",ErrorFlag);fflush(stdout);
															        
														            tc_strcat(PartSet,LatChildName);
														            
															        printf("\n DRVLI: Part added to error list1: %s",LatChildName);fflush(stdout);
														         }
														 }
													  

												     }
											   }
											  else
												{
												  printf("\n DRVLI:Checking child part for any of the revision DR4/5:%s",LatChildName);fflush(stdout);
                                            

											      if (tc_strcmp(DRCaseSet,"NULL") !=0) MEM_free(DRCaseSet);
												  DRCaseSet=(char *)MEM_alloc(500);

												  if ((tc_strcmp(cDRstatus,"DR4")==0)|| (tc_strcmp(cDRstatus,"AR4")==0))
												  {
													  tc_strcpy(DRCaseSet,"DR4");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR5");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR4");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR5");
												  }
												  else if ((tc_strcmp(cDRstatus,"DR5")==0)|| (tc_strcmp(cDRstatus,"AR5")==0))
												  {
													  tc_strcpy(DRCaseSet,"DR5");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR5");
								
												  }
												  else if ((tc_strcmp(cDRstatus,"DR3P")==0)|| (tc_strcmp(cDRstatus,"AR3P")==0))
												  { 
													  tc_strcpy(DRCaseSet,"DR3P");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR4");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR5");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR3P");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR4");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR5");


												  }
												  else if ((tc_strcmp(cDRstatus,"DR3")==0)|| (tc_strcmp(cDRstatus,"AR3")==0))
												  {
													  tc_strcpy(DRCaseSet,"DR3");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR3P");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR4");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR5");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR3");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR3P");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR4");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR5");
													
												  }
												  else if ((tc_strcmp(cDRstatus,"DR2")==0)|| (tc_strcmp(cDRstatus,"AR2")==0))
												  {
													  tc_strcpy(DRCaseSet,"DR2");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR3");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR3P");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR4");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR5");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR2");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR3");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR3P");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR4");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR5");


												  }
												  else if ((tc_strcmp(cDRstatus,"DR1")==0)|| (tc_strcmp(cDRstatus,"AR1")==0))
												  {

													  tc_strcpy(DRCaseSet,"DR1");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR2");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR3");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR3P");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR4");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR5");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR1");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR2");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR3");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR3P");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR4");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR5");

							
												  }
												  else if ((tc_strcmp(cDRstatus,"DR0")==0)|| (tc_strcmp(cDRstatus,"AR0")==0))
												  {
													  tc_strcpy(DRCaseSet,"DR0");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR1");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR2");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR3");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR3P");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR4");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"DR5");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR0");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR1");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR2");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR3");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR3P");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR4");
													  tc_strcat(DRCaseSet,";");
													  tc_strcat(DRCaseSet,"AR5");


												  }

												  printf("\n DRCaseSet: [%s] \n",DRCaseSet);fflush(stdout);
												  //One of the release revision should be DR4/5 or AR4/5.

												  ITKCALL(QRY_find2("DRstatus_Part_Query", &qryTag));
												  if (qryTag!=NULLTAG)
												  {
                                                      
													  printf("\n DRstatus_Part_Query found");fflush(stdout);
													  qry_values[0]=LatChildName;
				                                      qry_values[1]=DRCaseSet;
													  qry_values[2]="T5_MBOMReleased";
													  
													 ITKCALL(QRY_execute_with_sort(qryTag, n_entry, qry_entry, qry_values, num_to_sort, keys, orders, &part_found, &part_tags));
													 printf("\n part_found: %d", part_found);fflush(stdout);
												  }

												  if (part_found==0)
													{
                                                            
                                                         printf("\n Release part not DR4/5:%s",LatChildName);fflush(stdout);
														 PartSet=(char *)MEM_alloc(500);
														 if (tc_strstr(PartSet,LatChildName)==NULL)
														   {
														       ErrorFlag++;
															   printf("\n  Value of ErrorFlag is:%d",ErrorFlag);fflush(stdout);
															   
														       tc_strcat(PartSet,LatChildName);
														            
															   printf("\n Part added to error list1:%s",LatChildName);fflush(stdout);
														   }
													  

														  /*
														  else
														   {
														       printf("\n Part need to check relation with same dml..");fflush(stdout);
												               ChildAttached = 0;

															   ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&TaskToPart1));
                                                               ITKCALL(GRM_list_primary_objects_only(bl_Child_dv,TaskToPart1,&TaskCount,&TaskList));
															   printf("\n Number of task found :: %d \n", TaskCount);fflush(stdout);
															   if (TaskCount>0)
																  {
																			  for (t=0;t<TaskCount ;t++ )
																			  {
																				  TaskTag1 = TaskList[t];
																				  ChildAttached = 0;

																				  ITKCALL(AOM_ask_value_string(TaskTag1,"item_id",&TaskNo1));
					                                                              printf("\n DRVLI:DML [%s] Task [%s] \n",DMLTag,TaskNo1);fflush(stdout);
																				  if (tc_strstr(TaskNo1,"PO")==NULL)
																				  {
																					  if (tc_strstr(DML_no,TaskNo1)!=NULL)
																					  {
																						  ChildAttached = 1;
																                          break;
																					  }
																				  }



																			  }
																			  if (ChildAttached >0)
																			  {
																				  printf("\n Part found attached to same dml..:%s",LatChildName);fflush(stdout);
																				  if ((tc_strcmp(parttype,"G")==0)|| (tc_strcmp(PrtClass,"Design Revision")==0))
																				  {
																					  GrpSuccessFlag=1;
														                              printf("\n BRAKE A:One child part passed for group id:%s",LatChildName);fflush(stdout);
														                              break;
																				  }
																			  }
																			  else
																		         {
																				    printf("\n Error child part4:%s",LatChildName);fflush(stdout);
																					if (tc_strstr(PartSet,LatChildName)==NULL)
														                               {
                                                                                           ErrorFlag++;
																                           printf("\n  Value of ErrorFlag is:%d",ErrorFlag);fflush(stdout);
															                               tc_strcpy(PartSet,",");
														                                   tc_strcat(PartSet,LatChildName);
														                                   
															                               printf("\n Part added to error list4:%s",LatChildName);fflush(stdout);
														                                }  
																				  
																			     }
																		  }


																     }*/

					                                        //}
															/*
														  else
													         {

															    printf("\n Checking next child part.");fflush(stdout);
											                    if((tc_strcmp(parttype,"G")==0)|| (tc_strcmp(PrtClass,"Design Revision")==0))
											                      {
												                     GrpSuccessFlag=1;
												                     printf("\n BRAKE:One child part passed for group id:%s",LatChildName);fflush(stdout);
												                     break;
											                      }

														     }
															 */
												  }
											    }
											}

                                            if (tc_strcmp(ErrorSet,"NULL") !=0) MEM_free(ErrorSet);
											ErrorSet=(char *)MEM_alloc(500);
											if (ErrorFlag>0)
											   {
												if(cnt==0)
												{
                                                   cnt=1;
                                                   tc_strcpy(ErrorSet," ");
												   tc_strcat(ErrorSet,"\n");
												   tc_strcat(ErrorSet,"At least one released revision of mentioned child parts of attaching part should have equal or above DR-status than DML.");
												   tc_strcat(ErrorSet,"\n");
												   tc_strcat(ErrorSet,PartSet);

												}
												else
												{ 
													tc_strcat(ErrorSet,",");
                                                    tc_strcat(ErrorSet,PartSet);
                                                    cnt++;
												}
												printf("\n ErrorSet:[%s]..",ErrorSet);fflush(stdout);
												printf("\n value of cnt is: %d",cnt);fflush(stdout);

												if(cnt==1)
										          { 
											            
										                setAddStrMBOM(icount,SetChildRelErr,ErrorSet);
											            cntFlag = 1;
										           }
										        else
										           {
										                 
											             setAddStrMBOM(icount,SetChildRelErr,ErrorSet);
											             cntFlag = 1;
										           }
											   }

									}

                               }
							}

						}
					else
					{
					   printf("\n DRVLI:Other DR-status part type..[%s]\n",PartNo);fflush(stdout);
					}

				}
			 }

		 }
	else
	 {
		printf("\n DRVLI:Other DML Type.\n");fflush(stdout);
	}
   }
  }
 }
 printf("\n ************** Out side ParentChildDrVali Function *************\n");fflush(stdout);

 return 0;
}

//sanket MBOM task signoff validation end



/**********************Priyanka**********************/

extern int DLLAPI mbom_dml_GMdml( METHOD_message_t *msg, va_list  args )
{
    tag_t	TaskTag		= va_arg(args, const tag_t);
	tag_t objTypeTag=NULLTAG;
	//char   type_name[TCTYPE_name_size_c+1];
	char *type_name   = NULL;
	char *item_id   = NULL;
	char *dmlprojCode   = NULL;
	char *DML_no = NULL;
	char *EcnType = NULL;
	char *cDMLDRStatus	=	NULL;
	char *cDMLFrmToDR	=	NULL;
	char *ERCBusiUt		=	NULL;
	char *ProductLine	=	NULL;
	char *roleName	=	NULL;
	//char roleName[SA_name_size_c+1];
	tag_t  CurrentRoleTag = NULLTAG;
	int SOR_MBOMDML_Val =0;
	//EPM_decision_t decision;

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

	

	if(TCTYPE_ask_object_type(TaskTag,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n     type_name for apl dml object %s\n", type_name);fflush(stdout);
	
	

	

	if(strcmp(type_name,"T5_MBOMDMLRevision")==0)
	{
		printf("\n inside class ChangeRequestRevision......\n");fflush(stdout);
		AOM_ask_value_string( TaskTag, "item_id", &item_id);
		AOM_ask_value_string( TaskTag, "t5_cprojectcode", &dmlprojCode);
		AOM_ask_value_string( TaskTag, "current_id", &DML_no);
		AOM_ask_value_string( TaskTag,"t5_MBOMRlzType",&EcnType);
		

		printf("\n item_id : %s\n",item_id);fflush(stdout);
		printf("\n Project Code : %s\n",dmlprojCode);fflush(stdout);
		printf("\n DML_no : %s\n",DML_no);fflush(stdout);
		printf("\n EcnType : %s\n",EcnType);fflush(stdout);
		if(tc_strstr(DML_no,"MM")!=NULL)
			{
				printf("\n Inside AM DML..\n");
				if(tc_strstr(roleName,"MBOM")!=NULL)
				{
					//added by sanket
					if(tc_strcmp(EcnType,"")==0)
				     {
					    printf("\n For MM DML MBOM Release Type is not NULL ERRORRRR");fflush(stdout);
					    EMH_clear_errors();
					    EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"For MM DML MBOM Release Type is not NULL. \nPlease Update MBOM Release Type.");
										
					    return ITK_errStore1;
			         }
					 //end

					SOR_MBOMDML_Val = tm_check_SOR_MBOMDML_Val_control_object ( "SORMBOMRLZ" , EcnType );
					if((tc_strcmp(EcnType,"GM_MMDML")==0))
					{
									
									
									printf("\nGate Maturation DML Validation ");fflush(stdout);
									ITKCALL(AOM_ask_value_string( TaskTag,"t5_cDRstatus",&cDMLDRStatus));
									printf("\nMBOM GM DML DR STATUS : %s",cDMLDRStatus);fflush(stdout);

									ITKCALL(AOM_ask_value_string( TaskTag,"t5_PlntToPlnt",&cDMLFrmToDR));
									printf("\nMBOM GM DML DR STATUS : %s",cDMLFrmToDR);fflush(stdout);

									if(tc_strcmp(cDMLDRStatus,"")==0)
									{
										printf("\nMBOM Gate Maturation DML DR Status is not NULL ERRORRRR");fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"MBOM Gate Maturation DML DR Status is not NULL. \nPlease Update DR status as NA.");
										//decision = EPM_nogo;
										return ITK_errStore1;
									}
									else if (tc_strcmp(cDMLDRStatus,"NA")!=0)
									{
										printf("\nMBOM GM DML DR Status is not NA...ERRORRRRRR");fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"MBOM Gate Maturation DML DR Status should be NA. \nPlease Update DR Status as NA.");
										//decision = EPM_nogo;
										return ITK_errStore1;
									}
									else
									{
										printf("\nMBOM GM DML having DR status : %s",cDMLDRStatus);fflush(stdout);
									}

									if(tc_strcmp(cDMLFrmToDR,"")==0)
									{
										printf("\n DRCHK:ERROR:81.\n"); fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"MBOM Gate Maturation DML FROM-TO DRGate value should not be NULL. \nPlease update it on DML.");
										return ITK_errStore1;
									}
									else
									{
										
											printf("\n GMD:Allowed for cDMLFrmToDR %s",cDMLFrmToDR);fflush(stdout);
										
									}
					}

					 if ( SOR_MBOMDML_Val > 0)
					{
									printf("\nAutoSor Validation ");fflush(stdout);
									ITKCALL(AOM_ask_value_string( TaskTag,"t5_ERCBusiUt",&ERCBusiUt));
									printf("\nERCBusiUt : %s",ERCBusiUt);fflush(stdout);

									ITKCALL(AOM_ask_value_string( TaskTag,"t5_ProductLine",&ProductLine));
									printf("\nProductLine : %s",ProductLine);fflush(stdout);

									if(tc_strcmp(ERCBusiUt,"")==0)
									{
										printf("\nProductLine value should not be NULL ERRORRRR");fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"DML Business Unit value should not be NULL. \nPlease Update it on DML.");
										return ITK_errStore1;
									}

									if(tc_strcmp(ProductLine,"")==0)
									{
										printf("\nVertical value should not be NULL ERRORRRR");fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"DML Vertical value should not be NULL. \nPlease Update it on DML.");
										return ITK_errStore1;
									}

					}
				}
			}
		

	}
	}

int gmdml_drstatus_change( EPM_action_message_t msg )
{

	int				error_code	= ITK_ok;
	int             ifail				= 0;		
		
	char*	Proj_Code				= NULL;
	char	*item_type				= NULL;
	char	*type_name				= NULL;
	//char    type_name[TCTYPE_name_size_c+1];
	char	*item_id				= NULL;
	char	*DML_no					= NULL;
	char	**DesignGroupList;
	char	*CurrentTask			= NULL;
	char    *parent_name			= NULL;
	char	*ecntypeVal				= NULL;
	char	*DMLFrmToDR				= NULL;
	char	*ToPlnt					= NULL;
	char	*FromPlnt				= NULL;
	char	*Part_no				= NULL;
	char	*exepath				= NULL;
	
	int		TaskCnt					=	0;
	int		count					=	0;
	int		CMRefcount				=	0;
	int		Mstr					=	0;
	int	  noAttachment,noTaskAttachment 	= 0;
	
	tag_t   APLTaskRevT         = NULLTAG;
	tag_t   dml_rev_tag         = NULLTAG;
	tag_t   objTypeTag			= NULLTAG;
	tag_t	rootTask			= NULLTAG;
	tag_t	*attachments		= NULLTAG;
	tag_t 	relation_type       = NULLTAG;
	tag_t 	tsk_Sol_rel_type    = NULLTAG;
	tag_t	*TaskRevision		= NULLTAG;
	tag_t	*TaskCMRef			= NULLTAG;
	tag_t	Assytag				= NULLTAG;

	tag_t *list_of_cntrl_tags=NULLTAG;
	tag_t   qryTagCntrl1     = NULLTAG;
	char command[512];

	char  *qry_eCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};
	char *qry_vCntrl[3]={"GMDRUpd","path","0"};
	int     n_entry   = 3;
	int  control_found =0;
	
	printf("\n ************** Priyanka  inside gmdml_drstatus_change***************\n ");fflush(stdout);


	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n gmdml_drstatus_change \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
    printf("\n CurrentTask00 => %s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n Parent Name => %s\n",parent_name);fflush(stdout);
	ITKCALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("\n Target Attachment11:%d\n",noAttachment);fflush(stdout);
	
	if(noAttachment > 0)
	{
		dml_rev_tag = attachments[0];
		ITKCALL(TCTYPE_ask_object_type(dml_rev_tag,&objTypeTag));
    	ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
		//ITKCALL(AOM_ask_value_string( dml_rev_tag, "current_id", &DML_no));
		ITKCALL(AOM_ask_value_string( dml_rev_tag, "item_id", &DML_no));
		printf("\n DML NO     %s\n", DML_no);fflush(stdout);
	}

	//if((strcmp(type_name,"T5_MBOMDMLRevision")==0 && (tc_strstr(DML_no,"MM")!=NULL)) || (type_name,"T5_APLDMLRevision")==0)
	if((strcmp(type_name,"T5_MBOMDMLRevision")==0 && (tc_strstr(DML_no,"MM")!=NULL)) || (tc_strcmp(type_name,"T5_APLDMLRevision")==0)) //venkat tc_strcmp added
	{
		    printf("\n inside class T5_MBOMDMLRevision......\n");fflush(stdout);
			ITKCALL(AOM_ask_value_string( dml_rev_tag, "item_id", &item_id));
			
			ITKCALL(AOM_ask_value_string( dml_rev_tag, "t5_cprojectcode", &Proj_Code));

			if (strcmp(type_name,"T5_MBOMDMLRevision")==0)
			{
			ITKCALL(AOM_ask_value_string( dml_rev_tag, "t5_MBOMRlzType", &ecntypeVal));
			}

			if (strcmp(type_name,"T5_APLDMLRevision")==0)
			{
			ITKCALL(AOM_ask_value_string( dml_rev_tag, "t5_EcnType", &ecntypeVal));
			}
			
			printf("\n inside class T5_MBOMDMLRevision......ecntypeVal : %s\n",ecntypeVal);fflush(stdout);

			if (tc_strcmp(ecntypeVal,"GM_MMDML")==0 || (tc_strcmp(ecntypeVal,"TODRAPL")==0))
				{
				if(QRY_find2("Control Objects...", &qryTagCntrl1));

				if (qryTagCntrl1)
				{
					printf("\n Control Object Query Found \n");fflush(stdout);

					if(QRY_execute(qryTagCntrl1, n_entry, qry_eCntrl, qry_vCntrl, & control_found, &list_of_cntrl_tags));
				}
				else
				{
					printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
				}
				
				if(control_found>0)
				{
					AOM_ask_value_string( list_of_cntrl_tags[0], "t5_Userinfo1", &exepath);
					printf("\n exepath: %s\n",exepath);fflush(stdout);

					tc_strcpy(command,exepath);
					tc_strcat(command," ");
					tc_strcat(command,DML_no);
					tc_strcat(command," ");
					printf("\n command : %s",command);fflush(stdout);
					system(command);
					printf("\n command executed....");fflush(stdout);

				}
				}
				else{
					printf("\n NOT GMDML......\n");fflush(stdout);
					
		}

				
	}
	else{
					printf("\n No proper class T5_MBOMDMLRevision......\n");fflush(stdout);
					
	}

	return error_code;
}
/**********************Priyanka**********************/
/**********VENKAT***********/
int mbom_Modular_Check(tag_t taskRev_tag, char ***SetChildRelErr,int *icount )
{
	char		 *Task_no				= NULL;
	char		 *class_nam				= NULL;
	char		 *DMLDRStatus			= NULL;
	char		 *DMLNumber				= NULL;
	char		 *Partid_no				= NULL;
	char		 *parttypeName			= NULL;
	char		 *PartTypeDec			= NULL;
	char		 *Partrevisionid		= NULL;
	char		 *TaskAccrcyVal			= NULL;
	char		 *IsMolarRlzErr1		= NULL;
	char	     *tempEr			    = NULL;
	logical is_latest_dml;
	

	tag_t			*DMLRevision					=NULLTAG;
	tag_t			qryTagCntrlAchk					=NULLTAG;
	tag_t			qryTagCntrlmdrlz				=NULLTAG;
	tag_t			*list_of_WSO_cntrl_tagsAchk		=NULLTAG;
	tag_t			*list_of_WSO_cntrl_tagsmdrlz	=NULLTAG;
	tag_t			*PartTaggs						=NULLTAG;
	tag_t			DMLRevTag						=NULLTAG;
	tag_t			ERCDMLTag						=NULLTAG;
	tag_t			objErcTypeTag					=NULLTAG;
	tag_t			AssyTagg						=NULLTAG;
	tag_t			tsk_dml_rel_type				=NULLTAG;
	tag_t			classd_id						=NULLTAG;
	tag_t			tsk_to_part_rel					=NULLTAG;
	tag_t			relation_type					=NULLTAG;
	tag_t			ERCDMLRevision					=NULLTAG;

	int			DmlCnt							=0;
	int			MbomAcryFlag					=0;
	int			n_entryCntrlAchk				=2;
	int			n_entryCntrlmdrlz				=3;
	int			control_number_foundAchk		=0;
	int			control_number_foundmdrlz		=0;
	int			count							=0;
	int			no_of_PartCnt					=0;
	int			kk								=0;
	int			MdlarBomtErr					=0;
	int			cnt								=0;
	int			error							=0;
	int			RevCnt							=0;
	int			count_ercDML					=0;
	int			TaskCnt							=0;

	char*	ERCDML								=NULL;
	char*	Dsg_grp								=NULL;
	char*	Plnt_code							=NULL;
	
	char*	ERCDMLno							=NULL;
	char*	RlsType								=NULL;
	char*	latestrevid							=NULL;
	char*	DmlTask								=NULL;

	//tag_t	latestrev			=NULLTAG;

	char    *qry_entryCntrlAchk[2]  = {"SYSCD","Delete Indicator"};	
	char	**qry_valuesCntrlAchk= (char **) MEM_alloc(5 * sizeof(char *));
	printf("\n ************** Inside mbom_Modular BomChecks 1111***************\n ");fflush(stdout);


	char    *qry_entryCntrlmdrlz[3]  =  {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrlmdrlz= (char **) MEM_alloc(5 * sizeof(char *));
	
    ITKCALL(AOM_ask_value_string(taskRev_tag,"item_id",&Task_no));
	printf("\t  Task_no ...%s\n", Task_no);fflush(stdout);

		if((tc_strstr(Task_no,"MBOM") != NULL)) //mbom
		{ 
			 printf("\ninside  MBOM Task \n "); fflush(stdout);
													
			ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
			if (tsk_dml_rel_type!=NULLTAG)
			{
				ITKCALL(GRM_list_primary_objects_only(taskRev_tag,tsk_dml_rel_type,&count,&DMLRevision));
				printf("\n MBOM DML Revision from Task : %d",count); fflush(stdout);
				for (DmlCnt=0;DmlCnt<count;DmlCnt++ )
				{
					 DMLRevTag = DMLRevision[DmlCnt];

					 ITKCALL(ITEM_rev_sequence_is_latest(DMLRevTag,&is_latest_dml));
					 printf("\n is_latest_dml : %d\n",is_latest_dml);fflush(stdout);

						if(is_latest_dml != true)
						{
							printf("\t  primary Objects ...%s\n", DmlTask);fflush(stdout);
							printf("\n is_latest_dml is not true .....\n");fflush(stdout);
						}
						else
						{
						  ITKCALL(POM_class_of_instance(DMLRevTag,&classd_id));
						  ITKCALL(POM_name_of_class(classd_id,&class_nam));
						  printf("\n class_name found :%s",class_nam); fflush(stdout);
							  if(tc_strcmp(class_nam,"T5_MBOMDMLRevision")==0)
							  {
								ERCDML=tc_strtok(Task_no,"_");
								Dsg_grp=tc_strtok(NULL,"_");
								Plnt_code=tc_strtok(NULL,"_");
								printf("\n ERC DML AND Design Gtroup :[%s] :[%s]:[%s]",ERCDML,Dsg_grp,Plnt_code); fflush(stdout);
								if(tc_strstr(ERCDML,"MB")!=NULL)
								  {

									ITKCALL(ITEM_find_item(ERCDML,&ERCDMLTag));
									ITKCALL(ITEM_ask_latest_rev(ERCDMLTag,&ERCDMLRevision)); //I tried different APIs this is working..
									ITKCALL(AOM_ask_value_string(ERCDMLRevision, "item_id", &ERCDMLno));	   
									ITKCALL(AOM_ask_value_string(ERCDMLRevision, "t5_rlstype", &RlsType));  
									ITKCALL(AOM_ask_value_string(ERCDMLRevision,"item_revision_id",&latestrevid));
									ITKCALL(AOM_ask_value_string(ERCDMLRevision,"t5_cDRstatus",&DMLDRStatus)); //ERCDMLDRStatus

								  }
								 else
								 {
									ITKCALL(AOM_ask_value_string(DMLRevTag, "item_id", &ERCDMLno));	   
									ITKCALL(AOM_ask_value_string(DMLRevTag, "t5_MBOMRlzType", &RlsType));  
									ITKCALL(AOM_ask_value_string(DMLRevTag,"item_revision_id",&latestrevid));
									ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&DMLDRStatus)); //MBOMDMLRevDRstatus
								 }

								 printf("\n RlsType : %s\n",RlsType);fflush(stdout);                
								 printf("\n ERCDMLno AND rev ID : %s :%s \n",ERCDMLno,latestrevid);fflush(stdout);
								  if ((tc_strcmp(RlsType ,"Veh")==0)|| (tc_strcmp(RlsType ,"VCREST")==0)|| (tc_strcmp(RlsType ,"MFG_SubMdRlz")==0))
								  {
										printf("\n DMLDRStatus is :%s",DMLDRStatus); fflush(stdout);
											if((tc_strcmp(DMLDRStatus,"DR1")==0)||(tc_strcmp(DMLDRStatus,"DR2")==0)||(tc_strcmp(DMLDRStatus,"DR3")==0)||(tc_strcmp(DMLDRStatus,"DR3P")==0)||(tc_strcmp(DMLDRStatus,"AR3P")==0)|| (tc_strcmp(DMLDRStatus,"DR4")==0)|| (tc_strcmp(DMLDRStatus,"DR5")==0) ||(tc_strcmp(DMLDRStatus,"AR3")==0)||(tc_strcmp(DMLDRStatus,"AR4")==0) || (tc_strcmp(DMLDRStatus,"AR5")==0))
											{
												printf("\n since DML is GREATER than DR2 so going for accuracy check");fflush(stdout);
												if(QRY_find2("Control Objects...", &qryTagCntrlAchk));
												 if (qryTagCntrlAchk)
												 {
													printf("\n Control Object Query Found \n");fflush(stdout);
													qry_valuesCntrlAchk[0]="AccrcyChk";
													qry_valuesCntrlAchk[1]="0";
													if(QRY_execute(qryTagCntrlAchk,n_entryCntrlAchk, qry_entryCntrlAchk, qry_valuesCntrlAchk, &control_number_foundAchk,&list_of_WSO_cntrl_tagsAchk));
													printf("\n Control Object Query  Found for Modular BOM  : %d\n",control_number_foundAchk);fflush(stdout);
													if (control_number_foundAchk>0)
													{
														ITKCALL(AOM_ask_value_tags(taskRev_tag,"CMHasSolutionItem",&no_of_PartCnt,&PartTaggs));
														printf("\n MBOM Task DML PartCnt: %d",no_of_PartCnt);fflush(stdout);
														if (no_of_PartCnt>0)
														{															
															for (kk=0;kk<no_of_PartCnt ;kk++ )
															{
																AssyTagg=NULLTAG;
																printf("\n MBOM DML for kk =:%d",kk);fflush(stdout);
																AssyTagg=PartTaggs[kk];
																ITKCALL(AOM_ask_value_string(AssyTagg,"item_id",&Partid_no));
																printf("\n MBOM DML Part_no is :%s",Partid_no);	fflush(stdout);
																ITKCALL(AOM_ask_value_string(AssyTagg,"t5_PartType",&parttypeName));
																printf("\n MBOM DML Parttype  is :%s",parttypeName);	fflush(stdout);									
																ITKCALL(AOM_ask_value_string(AssyTagg,"item_revision_id",&Partrevisionid));
																printf("\n MBOM DML AssyTag Partrevision := %s", Partrevisionid);fflush(stdout);
																if ((tc_strcmp(parttypeName,"V")==0)||(tc_strcmp(parttypeName,"VCCR")==0)) 
																{
																	if(QRY_find2("Control Objects...", &qryTagCntrlmdrlz)); 
																	 if (qryTagCntrlmdrlz)
																	 {
																		qry_valuesCntrlmdrlz[0]="ModuleRel";
																		qry_valuesCntrlmdrlz[1]=Partid_no;
																		qry_valuesCntrlmdrlz[2]="0";
																			if(QRY_execute(qryTagCntrlmdrlz,n_entryCntrlmdrlz,qry_entryCntrlmdrlz,qry_valuesCntrlmdrlz, &control_number_foundmdrlz, &list_of_WSO_cntrl_tagsmdrlz));
																			printf("\n Control Object Query  Found for ModuleRel BOM  : %d\n",control_number_foundmdrlz);fflush(stdout);
																			if (control_number_foundmdrlz>0)
																			{
																				printf("\n By pass the  this Vehilce  for Modular BOM Check\n");fflush(stdout);
																			}
																			else
																			{
																				
																				MbomAcryFlag=MbomAcryFlag+1;
																			}			
																	 }
																}									
															}
														}
														printf("\n MbomAcryFlag  := %d", MbomAcryFlag);fflush(stdout);
														
														if (MbomAcryFlag>0)
														{
															error=0;
															ITKCALL(AOM_ask_value_string(taskRev_tag,"t5_mbomAccuracyChk",&TaskAccrcyVal));
															printf("\n TaskModlarAccrcyVal  := %s", TaskAccrcyVal);fflush(stdout);
															if(tc_strcmp(TaskAccrcyVal,"PASS")!=0)
															{			
																error=error+1;	
															}

														}

													}
												   
											
												 }
											}
											else
											{
												
											  printf(" \n since DML DR Statues is less than or Eqal to  DR2 so no need to go  for accuracy check \n");fflush(stdout);
											}
								  }
								  else
								  {
									printf(" \n  ERCDML Release type  is other than Vehicle release type \n");fflush(stdout);
								  }
							
							  }

						}								
				}
			}
		}											
			if(error>0)
			{									
				IsMolarRlzErr1	=	NULL;
				IsMolarRlzErr1	=	(char *)MEM_alloc(550);							
				tc_strcpy(IsMolarRlzErr1,"");								
				if(cnt==0)
				{
					 cnt = 1;																																
					tc_strcat(IsMolarRlzErr1,"\n Accuracy check of Modular vehicle is either FAIL or Not Initiated. Check on View properties of Task.");
					tc_strcat(IsMolarRlzErr1,"\n");
					//tc_strcat(IsMolarRlzErr1," If Not Initiated---Plz run Manufacturing-->Planning-->APL Re-Sstructing-->MBOM VC Accuracy Report.\n");
					tc_strcat(IsMolarRlzErr1," If Not Initiated---> Plz run  Manufacturing-->MBOM-->Generate Report-->MBOM VC Accuracy Report.\n");
					//tc_strcat(IsMolarRlzErr1," If FAIL --- do signoff --> Unable to complete.\n");
					tc_strcat(IsMolarRlzErr1,"Please Contact PLM Support Team if required.");
					printf("\n IsMolarRlzErr1: %s\n",IsMolarRlzErr1);fflush(stdout);
				}
				else
				{
					 tc_strcat(IsMolarRlzErr1,"\n Accuracy check of Modular vehicle is either FAIL or Not Initiated. Check on View properties of Task.");
					 tc_strcat(IsMolarRlzErr1,"\n");
					 //tc_strcat(IsMolarRlzErr1," If Not Initiated---Plz run Manufacturing-->Planning-->APL Re-Structing-->MBOM VC Accuracy Report.\n");
					 tc_strcat(IsMolarRlzErr1," If Not Initiated---> Plz run  Manufacturing-->MBOM-->Generate Report-->MBOM VC Accuracy Report.\n");
					// tc_strcat(IsMolarRlzErr1," If FAIL --- do signoff --> Unable to complete.\n");
					 tc_strcat(IsMolarRlzErr1,"Please Contact PLM Support Team if required.");
					 printf("\n IsMolarRlzErr1: %s\n",IsMolarRlzErr1);fflush(stdout);
					
				}

					printf("\n cnt: %d\n",cnt);fflush(stdout);

				if(cnt==1)
				{
				  printf("\n cnt4: %d\n",cnt);fflush(stdout);

					setAddStrMBOM(icount,SetChildRelErr,IsMolarRlzErr1);
					cntFlag = 1;
					
				}
				else
				{
															
				setAddStrMBOM(icount,SetChildRelErr,IsMolarRlzErr1);
					cntFlag = 1;
					
				}
			}

	return 0;
}

int tm_GMDML_Signoff_vlidation_check_MBOM(EPM_action_message_t msg )
{
	int   ifail					= 0;
	int	  noAttachment=0,t=0;
	int TaskCnt=0;
    char	*object_type					= NULL;
	char*			parent_name				=NULL;
	char*			CurrentTask				=NULL;
	char*			releasetyp				=NULL;
	tag_t			*attachments			=NULLTAG;
	tag_t			rootTask				=NULLTAG;
	tag_t MBOMTaskTag = NULLTAG;
	int DMLcount = 0;
	tag_t *DmlTasksTags			= NULLTAG;
	int icount1 = 0;
	int icount2 = 0;
	int cntFlag = 0;
	char **SetGMErr1 = NULL;
	char **SetGMErr2 = NULL;
	char *itemid =NULL;
	tag_t   relation_with_dml	=	NULLTAG;

	printf("\n Inside tm_GMDML_Signoff_vlidation_check_MBOM...");
	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);

	ITKCALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		for(t=0;t<noAttachment;t++)
		{
			MBOMTaskTag=NULLTAG;
			MBOMTaskTag = attachments[t];
			ITKCALL(AOM_ask_value_string(MBOMTaskTag,"object_type",&object_type));
			printf("\n object_type is :%s\n",object_type);fflush(stdout);		
						
			if (strcmp(object_type, "T5_MBOMTASKRevision") == 0)
			{
				ITKCALL(AOM_ask_value_string(MBOMTaskTag, "item_id", &itemid));
				printf("\n itemid %s.....\n", itemid);fflush(stdout);

				ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&relation_with_dml));
                ITKCALL(GRM_list_primary_objects_only(MBOMTaskTag,relation_with_dml,&DMLcount,&DmlTasksTags));
				if(DMLcount > 0)
				{
				ITKCALL(AOM_ask_value_string(DmlTasksTags[0],"t5_rlstype",&releasetyp));
			    printf("\n releasetyp is :%s\n",releasetyp);fflush(stdout);
				if (strcmp(releasetyp, "TODR") == 0)
				{
					cntFlag = 0;
					icount1 = 0;												
					SetGMErr1 = NULL;																
					SetGMErr1 = (char **)MEM_alloc(1 * sizeof *SetGMErr1);
					
                    CheckPrtRelsFrmPlant_MBOM (MBOMTaskTag,&SetGMErr1,&icount1); 
				
					if(icount1 != 0)
					{
						cntFlag++;
					}
					
				}
				}
			}
		}
	}
 
	
    printf("\n cntFlag:%d", cntFlag);fflush(stdout);

	if(cntFlag==0)
	{
		return ITK_ok;

	}
	else
	{
		return ITK_errStore;	
	}
}


extern EPM_decision_t DLLAPI mbom_dml_signoff_checks_Func(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int status;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int count_child = 0;
	int   attribute_act_tak;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char *Item_id = NULL;
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	int i = 0;
	int j = 0;
	int n = 0;
	int stampingdone=0;
	int iGChld = 0;
	char*	itemid;
	char *  ChildRelErr = NULL;
	//char *  SetChildRelErr = NULL;
	char	**SetChildRelErr = NULL;//Make a string array
	char*	childPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char *type_name=NULL;
	//char  type_name[TCTYPE_name_size_c+1];
	
	char *type_itemRev=NULL;
	//char  type_itemRev[TCTYPE_name_size_c+1];
	char  ChildRevtype_name[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Childtop_line							= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag							= NULLTAG;
	tag_t	itemTypeTag_cdss							= NULLTAG;
	tag_t	*itemclassp	= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t	value_child_details							= NULLTAG;
	char  req_id[ITEM_id_size_c+1];
	tag_t  *children;
	tag_t  *totalchildren;
	tag_t  	value_act_Tak;
	tag_t  	item_rev_cld_tag;
	tag_t*			PartTags			= NULLTAG;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				ii				= 0;
	char*			value					=NULL;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	char*			Part_no				= NULL;
	int       st_count=0;
	int       iLCS=0;
	int       cntLcs=0;
	int				BypassNACSFlag=0;
	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	char ClosureRule[40];
	 char usrLocation[40];
	tag_t  CurrentRoleTag = NULLTAG;
	//char       roleName[SA_name_size_c+1]  ;
	char *roleName = NULL;
    cnt = 0;
	cntFlag = 0;

	int		icount	=	0;
	char	*tempErr	=	0;
	int		iLength	=	0;
	int		SOR_MBOMDML_Val = 0;
	int		SOR_task_signoff_val_cnt = 0;

	int	Part_task_checked_out_val_cnt = 0;

	printf("\n Ketan Inside mbom_dml_signoff_checks_Func %d.....\n",iNumAttch);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n mbom_dml_signoff_checks_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
    printf("\nCurrentTask: %s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name: %s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

	mbom_getPlantDetailsAttr(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency,ClosureRule,usrLocation);

	printf("\n PlantCS %s \n",PlantCS);
	printf("\n PlantOptCS %s \n",PlantOptCS);
	printf("\n PlantAgency %s \n",PlantIA);
	printf("\n PlantStore %s \n",PlantStore);
	printf("\n UserAgency %s \n",UserAgency);
	printf("\n ClosureRule %s \n",ClosureRule);

    if(tc_strcmp(CurrentTask,"Work On MBOM-DML" )==0)
	{
		printf("\n Inside Work On MBOM-DML \n");fflush(stdout);
 		ITKCALL( TCTYPE_find_type("T5_MBOMTASKRevision", NULL, &ItemTypeTag));

		printf("\n iNumAttch %d.....\n",iNumAttch);
		for (i=0; i < iNumAttch; i++)
		{
			tag_t objTypeTag = NULLTAG;
			tag_t objChildRevTag = NULLTAG;

			const char *qry_entries[1];
			const char *qry_values[1];


			int n_tags_found=0;
			tag_t*		itemclass	= NULLTAG;
			tag_t		item		= NULLTAG;

			ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
			printf("\n itemid %s.....\n",itemid);
			qry_entries[0] ="item_id";
			qry_values[0] = itemid;

			ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
			 item = itemclass[0];
			if(item != NULLTAG )
			ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

			printf("\n itemid %s \n",itemid);
			ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
			ITKCALL( TCTYPE_ask_name2( objTypeTag, &type_name) );
			printf("\t  type_name ...%s\n", type_name);
			if( objTypeTag == ItemTypeTag )
			{
				printf("\t \n objTypeTag == ItemTypeTag \n");

				ITKCALL (TCTYPE_ask_object_type(item_rev_tag,&itemTypeTag_cdss));
				ITKCALL (TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));

				printf("\t  type_itemRev ...%s\n", type_itemRev);
				SetChildRelErr = (char**)MEM_alloc( 1 * sizeof *SetChildRelErr );

				if(tc_strcmp(type_itemRev,"T5_MBOMTASKRevision" )==0)
				{
					SOR_MBOMDML_Val = tm_check_SOR_MBOMDML_Val_control_object ( "SORMBOMDMLVAL" , "ON" );
					if ( SOR_MBOMDML_Val > 0)
					{
							printf("\n\nControl Object found for SOR MBOM DML Validation");fflush(stdout);
							SOR_task_signoff_val_cnt = SOR_task_signoff_val_MBOM(item_rev_tag);
							if ( SOR_task_signoff_val_cnt > 0 )
							{
								decision = EPM_nogo;
								return decision;
							}
					}
					else
					{
						printf("\n\nControl Object not found for SOR MBOM DML Validation:SORMBOMDMLVAL");fflush(stdout);

					}

					ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCnt,&PartTags));
					printf("\n MBOM Task Part Count: %d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{

						GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
						printf("\n for k =:%d",k);fflush(stdout);

						/*************************Validation Control Object Based*************************/

						tag_t   qryTagCntrlobj		= NULLTAG;
						tag_t*	list_of_cntrl_tags	= NULLTAG;

						char*	qry_entryCntrlformat[4] = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};	
						

						int controlObjfound	= 0;
						int	n_entryCntrlobj = 4;

						//
						char**	qry_Part_task_checked_out_Validation	= (char **) MEM_alloc(5 * sizeof(char *));

						if(QRY_find2("Control Objects...", &qryTagCntrlobj));

						if (qryTagCntrlobj)
						{
							printf("\n Control Object Query Found \n");fflush(stdout);
							qry_Part_task_checked_out_Validation[0]="MBOM";
							qry_Part_task_checked_out_Validation[1]="Part_task_checked_out_Validation";
							qry_Part_task_checked_out_Validation[2]="0";
							qry_Part_task_checked_out_Validation[3]="Live";
							
							if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_Part_task_checked_out_Validation, &controlObjfound, &list_of_cntrl_tags));
						}
						else
						{
							printf("\n Control Object Query not Found  \n");fflush(stdout);
						}

						printf("\n controlObjfound for Part_task_checked_out_Validation is ==> %d\n",controlObjfound);fflush(stdout);

						if(controlObjfound>0)
						{
							printf("\n Live. Inside code for checking Part_task_checked_out_Validation \n");fflush(stdout);

							Part_task_checked_out_val_cnt = Part_task_checked_out_Validation(item_rev_tag);
							if ( Part_task_checked_out_val_cnt > 0 )
							{
								printf("\n Inside decision \n");fflush(stdout);
								decision = EPM_nogo;
								return decision;
							}
							
						}
						//

						char**	qry_valuesmbom_Child_Part_Rev_Checks	= (char **) MEM_alloc(5 * sizeof(char *));

						if(QRY_find2("Control Objects...", &qryTagCntrlobj));

						if (qryTagCntrlobj)
						{
							printf("\n Control Object Query Found \n");fflush(stdout);
							qry_valuesmbom_Child_Part_Rev_Checks[0]="MBOM";
							qry_valuesmbom_Child_Part_Rev_Checks[1]="mbom_Child_Part_Rev_Checks";
							qry_valuesmbom_Child_Part_Rev_Checks[2]="0";
							qry_valuesmbom_Child_Part_Rev_Checks[3]="Live";
							
							if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesmbom_Child_Part_Rev_Checks, &controlObjfound, &list_of_cntrl_tags));
						}
						else
						{
							printf("\n Control Object Query not Found  \n");fflush(stdout);
						}

						printf("\n controlObjfound for mbom_Child_Part_Rev_Checks is ==> %d\n",controlObjfound);fflush(stdout);

						if(controlObjfound>0)
						{
							printf("\n Live. Inside code for checking mbom_Child_Part_Rev_Checks \n");fflush(stdout);
							mbom_Child_Part_Rev_Checks(item_rev_tag,PartCnt,PartTags,&SetChildRelErr,PlantCS,ClosureRule,&icount); // Ketan
							printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
							printf("\n cntFlag_4: %d",cntFlag);fflush(stdout);
						}

						char**	qry_valuesPrevRevCheck	= (char **) MEM_alloc(5 * sizeof(char *));

						if(QRY_find2("Control Objects...", &qryTagCntrlobj));

						if (qryTagCntrlobj)
						{
							printf("\n Control Object Query Found \n");fflush(stdout);
							qry_valuesPrevRevCheck[0]="MBOM";
							qry_valuesPrevRevCheck[1]="mbom_Prev_Part_Rev_Checks";
							qry_valuesPrevRevCheck[2]="0";
							qry_valuesPrevRevCheck[3]="Live";
							
							if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesPrevRevCheck, &controlObjfound, &list_of_cntrl_tags));
						}
						else
						{
							printf("\n Control Object Query not Found  \n");fflush(stdout);
						}

						printf("\n controlObjfound for mbom_Prev_Part_Rev_Checks is ==> %d\n",controlObjfound);fflush(stdout);

						if(controlObjfound>0)
						{
							printf("\n Live. Inside code for checking mbom_Prev_Part_Rev_Checks \n");fflush(stdout);
							mbom_Prev_Part_Rev_Checks(PartCnt,PartTags,&SetChildRelErr,PlantCS,&icount); // Ketan
							printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
							printf("\n cntFlag_5: %d",cntFlag);fflush(stdout);
						}

						char**	qry_valuesHanging_Part_Checks	= (char **) MEM_alloc(5 * sizeof(char *));

						if(QRY_find2("Control Objects...", &qryTagCntrlobj));

						if (qryTagCntrlobj)
						{
							printf("\n Control Object Query Found \n");fflush(stdout);
							qry_valuesHanging_Part_Checks[0]="MBOM";
							qry_valuesHanging_Part_Checks[1]="mbom_Hanging_Part_Checks";
							qry_valuesHanging_Part_Checks[2]="0";
							qry_valuesHanging_Part_Checks[3]="Live";
							
							if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesHanging_Part_Checks, &controlObjfound, &list_of_cntrl_tags));
						}
						else
						{
							printf("\n Control Object Query not Found  \n");fflush(stdout);
						}

						printf("\n controlObjfound for mbom_Hanging_Part_Checks is ==> %d\n",controlObjfound);fflush(stdout);

						if(controlObjfound>0)
						{
							printf("\n Live. Inside code for checking mbom_Hanging_Part_Checks \n");fflush(stdout);
							mbom_Hanging_Part_Checks(PartCnt,PartTags,&SetChildRelErr,PlantCS,&icount); // Ketan
							printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
							printf("\n test cntFlag_7: %d",cntFlag);fflush(stdout);
						}
					
						char**	qry_valuesTwo_Rev_Same_Day_Checks	= (char **) MEM_alloc(5 * sizeof(char *));

						if(QRY_find2("Control Objects...", &qryTagCntrlobj));

						if (qryTagCntrlobj)
						{
							printf("\n Control Object Query Found \n");fflush(stdout);
							qry_valuesTwo_Rev_Same_Day_Checks[0]="MBOM";
							qry_valuesTwo_Rev_Same_Day_Checks[1]="mbom_Two_Rev_Same_Day_Checks";
							qry_valuesTwo_Rev_Same_Day_Checks[2]="0";
							qry_valuesTwo_Rev_Same_Day_Checks[3]="Live";
							
							if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesTwo_Rev_Same_Day_Checks, &controlObjfound, &list_of_cntrl_tags));
						}
						else
						{
							printf("\n Control Object Query not Found  \n");fflush(stdout);
						}

						printf("\n controlObjfound for mbom_Two_Rev_Same_Day_Checks is ==> %d\n",controlObjfound);fflush(stdout);

						if(controlObjfound>0)
						{
							printf("\n Live. Inside code for checking mbom_Two_Rev_Same_Day_Checks \n");fflush(stdout);
							mbom_Two_Rev_Same_Day_Checks(item_rev_tag,PartCnt,PartTags,&SetChildRelErr,itemid,PlantCS,&icount); // Ketan1111
							printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
							printf("\n test cntFlag_9: %d",cntFlag);fflush(stdout);
						}

						char**	qry_valuesmbom_Drg_Part_Checks	= (char **) MEM_alloc(5 * sizeof(char *));

						if(QRY_find2("Control Objects...", &qryTagCntrlobj));

						if (qryTagCntrlobj)
						{
							printf("\n Control Object Query Found \n");fflush(stdout);
							qry_valuesmbom_Drg_Part_Checks[0]="MBOM";
							qry_valuesmbom_Drg_Part_Checks[1]="mbom_Drg_Part_Checks";
							qry_valuesmbom_Drg_Part_Checks[2]="0";
							qry_valuesmbom_Drg_Part_Checks[3]="Live";
							
							if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesmbom_Drg_Part_Checks, &controlObjfound, &list_of_cntrl_tags));
						}
						else
						{
							printf("\n Control Object Query not Found  \n");fflush(stdout);
						}

						printf("\n controlObjfound for mbom_Drg_Part_Checks is ==> %d\n",controlObjfound);fflush(stdout);

						if(controlObjfound>0)
						{
							printf("\n Live. Inside code for checking mbom_Drg_Part_Checks \n");fflush(stdout);
							mbom_Drg_Part_Checks(PartCnt,PartTags,&SetChildRelErr,itemid,PlantCS,&icount); // Ketan
							printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
							printf("\n cntFlag_11: %d",cntFlag);fflush(stdout);
						}

						/*************************Validation Control Object Ended*************************/


						//venkat Start

						char    *fram_entryCntr1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
						char	**frame_valuesCntr1   = (char **) MEM_alloc(5 * sizeof(char *));


						tag_t   framqryTagCntr1					= NULLTAG;
						tag_t*	list_fram_tags					= NULLTAG;
						int     n_entryCntr1					= 3;
						int		fram_cnt						= 0;




						if( QRY_find2("Control Objects...", &framqryTagCntr1));
						if (framqryTagCntr1)
						{
							printf("\n venkat query Control Object Frame module \n");fflush(stdout);
							frame_valuesCntr1[0]="Framemodule";
							frame_valuesCntr1[1]="framesignoff";  
							frame_valuesCntr1[2]="0";
							
							

							if(QRY_execute(framqryTagCntr1, n_entryCntr1, fram_entryCntr1, frame_valuesCntr1, &fram_cnt, &list_fram_tags));
							printf("\n controlObjfound for Frame module checking is ==> %d\n",fram_cnt);fflush(stdout);

							if(fram_cnt>0)
							{
								printf("\n controlObjfound for Frame module checking is ==> %d\n",fram_cnt);fflush(stdout);
								fram_module_applicability_check(PartCnt,PartTags,&SetChildRelErr,itemid,&icount);

							}
							else
							{
								printf("\nNo control object are found\n");fflush(stdout);
							}
						}
						//venkat end


						NineDigitPrtTypVali(item_rev_tag,&SetChildRelErr,&icount);//sanket
					    printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
					    printf("\n cntFlag_12: %d",cntFlag);fflush(stdout);

					    ParentChildDrVali(item_rev_tag,&SetChildRelErr,&icount);//sanket
					    printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
					    printf("\n cntFlag_13: %d",cntFlag);fflush(stdout);

					    ModuleDupCheck(item_rev_tag,&SetChildRelErr,&icount); //sanket
					    printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
					    printf("\n cntFlag_14: %d",cntFlag);fflush(stdout);

						PartQtyCheck(item_rev_tag,&SetChildRelErr,&icount); //sanket
					    printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
					    printf("\n cntFlag_15: %d",cntFlag);fflush(stdout);

						mbom_Modular_Check(item_rev_tag,&SetChildRelErr,&icount);
						printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
					    printf("\n cntFlag_16: %d",cntFlag);fflush(stdout);
							

					} //End for Part

					CheckPrtRelsFrmPlant_MBOM (item_rev_tag,&SetChildRelErr,&icount); 
					printf("\n cntFlag_17: %d", cntFlag);
					fflush(stdout);

					printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
					
					if(cntFlag==1)
					{
						iLength	=	0;
						if (!tempErr) MEM_free(tempErr);
						for (i=0; i < icount; i++)
						{
							//printf("%s",SetChildRelErr[i]);fflush(stdout);
							tempErr	=	SetChildRelErr[i];
							iLength	=	iLength	+	tc_strlen(tempErr);
						}
						printf("iLength : %d",iLength);fflush(stdout);
						if (!tempErr) MEM_free(tempErr);
						tempErr	=	(char *)MEM_alloc(iLength+80);
						tc_strcpy(tempErr,"Task:-");
						tc_strcat(tempErr,itemid);// task number added in error pop up.......
						tc_strcat(tempErr,"\n");
						for (i=0; i < icount; i++)
						{
							//printf("%s",SetChildRelErr[i]);fflush(stdout);
							/* if(i==0)
								tc_strcpy(tempErr,SetChildRelErr[i]);
							else */
								tc_strcat(tempErr,SetChildRelErr[i]);
						}
						printf("\nPrinting Errors...!!!");fflush(stdout);
						printf("%s",tempErr);fflush(stdout);
						EMH_clear_errors();
						status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
						//printf("\n All Child Part is not TCM Released  %s \n",SetChildRelErr);
						//status=EMH_store_error_s2(EMH_severity_error,ITK_errStore,SetChildRelErr ,"Child Part Release Error");
						decision = EPM_nogo;
						return ITK_errStore;
					}
				}
			}
		}
	}
	else if(tc_strcmp(CurrentTask,"Acknowledge ERC Flown Task" )==0)
	{
		printf("\n Inside Acknowledge ERC Flown Task \n");fflush(stdout);

 		ITKCALL( TCTYPE_find_type("T5_MBOMTASKRevision", NULL, &ItemTypeTag));

		printf("\n iNumAttch %d.....\n",iNumAttch);
		for (i=0; i < iNumAttch; i++)
		{
			tag_t objTypeTag = NULLTAG;
			tag_t objChildRevTag = NULLTAG;

			const char *qry_entries[1];
			const char *qry_values[1];

			int n_tags_found=0;
			tag_t*		itemclass	= NULLTAG;
			tag_t		item		= NULLTAG;

			ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
			printf("\n itemid %s.....\n",itemid);
			qry_entries[0] ="item_id";
			qry_values[0] = itemid;

			ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
			 item = itemclass[0];
			if(item != NULLTAG )
			ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

			printf("\n itemid %s \n",itemid);
			ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
			ITKCALL( TCTYPE_ask_name2( objTypeTag, &type_name) );
			printf("\t  type_name ...%s\n", type_name);
			if( objTypeTag == ItemTypeTag )
			{
				printf("\t \n objTypeTag == ItemTypeTag \n");

				ITKCALL (TCTYPE_ask_object_type(item_rev_tag,&itemTypeTag_cdss));
				ITKCALL (TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));

				printf("\n  type_itemRev ...%s\n", type_itemRev);
				SetChildRelErr = (char**)MEM_alloc( 1 * sizeof *SetChildRelErr );

				if(tc_strcmp(type_itemRev,"T5_MBOMTASKRevision" )==0)
				{
					printf("\n Inside Class T5_MBOMTASKRevision \n");fflush(stdout);

					ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCnt,&PartTags));
					printf("\n MBOM Task Part Count: %d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						printf("\n Inside PartCnt  \n");fflush(stdout);

						GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
						printf("\n for k =:%d \n",k);fflush(stdout);

						tag_t   qryTagCntrlobj		= NULLTAG;
						tag_t*	list_of_cntrl_tags	= NULLTAG;

						char*	qry_entryCntrlformat[4] = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};	
						
						int controlObjfound	= 0;
						int	n_entryCntrlobj = 4;

						if(QRY_find2("Control Objects...", &qryTagCntrlobj));

						char**	qry_valuesPrevRevCheck	= (char **) MEM_alloc(5 * sizeof(char *));

						if(QRY_find2("Control Objects...", &qryTagCntrlobj));

						if (qryTagCntrlobj)
						{
							printf("\n Control Object Query Found \n");fflush(stdout);
							qry_valuesPrevRevCheck[0]="MBOM";
							qry_valuesPrevRevCheck[1]="mbom_Prev_Part_Rev_Checks";
							qry_valuesPrevRevCheck[2]="0";
							qry_valuesPrevRevCheck[3]="Live";
							
							if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesPrevRevCheck, &controlObjfound, &list_of_cntrl_tags));
						}
						else
						{
							printf("\n Control Object Query not Found  \n");fflush(stdout);
						}

						printf("\n controlObjfound for mbom_Prev_Part_Rev_Checks is ==> %d\n",controlObjfound);fflush(stdout);

						if(controlObjfound>0)
						{
							printf("\n Live. Inside code for checking mbom_Prev_Part_Rev_Checks \n");fflush(stdout);
							mbom_Prev_Part_Rev_Checks(PartCnt,PartTags,&SetChildRelErr,PlantCS,&icount); // Ketan
							printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
							printf("\n New : cntFlag_1: %d",cntFlag);fflush(stdout);
						}
				

					} //End for Part

					printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
					
					if(cntFlag==1)
					{
						iLength	=	0;
						if (!tempErr) MEM_free(tempErr);
						for (i=0; i < icount; i++)
						{
							//printf("%s",SetChildRelErr[i]);fflush(stdout);
							tempErr	=	SetChildRelErr[i];
							iLength	=	iLength	+	tc_strlen(tempErr);
						}
						printf("iLength : %d",iLength);fflush(stdout);
						if (!tempErr) MEM_free(tempErr);
						tempErr	=	(char *)MEM_alloc(iLength+80);
						tc_strcpy(tempErr,"Task:-");
						tc_strcat(tempErr,itemid);// task number added in error pop up.......
						tc_strcat(tempErr,"\n");
						for (i=0; i < icount; i++)
						{
							//printf("%s",SetChildRelErr[i]);fflush(stdout);
							/* if(i==0)
								tc_strcpy(tempErr,SetChildRelErr[i]);
							else */
								tc_strcat(tempErr,SetChildRelErr[i]);
						}
						printf("\nPrinting Errors...!!!");fflush(stdout);
						printf("%s",tempErr);fflush(stdout);
						EMH_clear_errors();
						status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
						//printf("\n All Child Part is not TCM Released  %s \n",SetChildRelErr);
						//status=EMH_store_error_s2(EMH_severity_error,ITK_errStore,SetChildRelErr ,"Child Part Release Error");
						decision = EPM_nogo;
						return ITK_errStore;
					}
						int PartsAttachToMBOMDml = 0;
						tag_t MBOMDMLRelation = NULLTAG;
						tag_t* TagOfParts = NULLTAG;
						tag_t* MBOMDMLTags = NULLTAG;
						int VehIteration = 0;
						int MBOMDMLCount =0;
						char* MBOMReleaseType = NULL;
						int VCRestFlag = 0;
						char * VehNameInMBOMTask = NULL;
						tag_t queryFoundCVBU = NULLTAG;
						char *qentryCtrCVBU[3] = {"SYSCD", "SUBSYSCD","Delete Indicator"};
						char **qvaluesCtrCVBU = (char **)MEM_alloc(5 * sizeof(char *));
						char **qvaluesU = (char **)MEM_alloc(5 * sizeof(char *));
						int cvbuCOLOR_count = 0;
						tag_t *cvbuCOLOR_tag = NULLTAG;
						int vehCOIterator =0;
						char* CoName = NULL;
						int cvbu_count = 0;
						tag_t* cvbu_tag = NULLTAG;

						int isD9W01checkReq = 0;

						ITKCALL(QRY_find2("Control Objects...", &queryFoundCVBU));
						if (queryFoundCVBU != NULLTAG)
						{
							qvaluesU[0] = "VCAuto";
							qvaluesU[1] = "CObject";
							qvaluesU[2] = "0";
							ITKCALL(QRY_execute(queryFoundCVBU, 3, qentryCtrCVBU, qvaluesU, &cvbu_count, &cvbu_tag));
							if(cvbu_count>0)
							{
								//vishal
								ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &MBOMDMLRelation));
								ITKCALL(GRM_list_primary_objects_only(item_rev_tag,MBOMDMLRelation,&MBOMDMLCount,&MBOMDMLTags));
								if(MBOMDMLCount>0)
								{
									ITKCALL(AOM_ask_value_string(MBOMDMLTags[0],"t5_MBOMRlzType",&MBOMReleaseType));
									printf("\n New MBOMReleaseType : [%s]\n",MBOMReleaseType);fflush(stdout);
									if(tc_strcmp(MBOMReleaseType,"VC Restructuring")==0 || tc_strcmp(MBOMReleaseType,"VCREST")==0)
									{
										VCRestFlag++;
									}
								}
								if(VCRestFlag>0)
								{
									ITKCALL(GRM_list_secondary_objects_only(item_rev_tag, tsk_part_sol_rel_type, &PartsAttachToMBOMDml, &TagOfParts));//part list and part count
									printf("\n New PartsAttachToMBOMDml : [%d]\n",PartsAttachToMBOMDml);fflush(stdout);
									for(VehIteration=0;VehIteration<PartsAttachToMBOMDml;VehIteration++)
									{							
										ITKCALL(AOM_ask_value_string(TagOfParts[VehIteration],"item_id",&VehNameInMBOMTask));
										if (queryFoundCVBU != NULLTAG)
										{
											printf("\n VehNtPrsnt Control Object Found\n");
											fflush(stdout);
											qvaluesCtrCVBU[0] = "VCAuto";
											qvaluesCtrCVBU[1] = VehNameInMBOMTask;
											qvaluesCtrCVBU[2] = "0";
											ITKCALL(QRY_execute(queryFoundCVBU, 3, qentryCtrCVBU, qvaluesCtrCVBU, &cvbuCOLOR_count, &cvbuCOLOR_tag));
											for(vehCOIterator=0;vehCOIterator<cvbuCOLOR_count;vehCOIterator++)
											{
												printf("\n Inside For loop: \n");fflush(stdout);
												ITKCALL(AOM_ask_value_string(cvbuCOLOR_tag[vehCOIterator], "current_name", &CoName));
												printf("\n CoName: %s\n", CoName);fflush(stdout);
												ITKCALL(AOM_delete(cvbuCOLOR_tag[vehCOIterator]));
												printf("Successfulluy deleted Control Object");
											}
										}
									}
								}
							}						
						}					
						else
						{
							printf("Control Object query not found");
						}
				}
			}
		}
	}
	decision = EPM_go;
	return decision;
}

// Ketan Added
extern EPM_decision_t DLLAPI Part_checked_out_Validation(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int status;
	
	tag_t	rootTask		=	NULLTAG;
	tag_t	item_rev_tag	= NULLTAG;
	tag_t*  pTagAttch;
	
	char*	CurrentTask				= NULL;
	char*	parent_name				= NULL;
	char*	Item_id					= NULL;
	char*	itemid;

	int iNumAttch	= 0;
	int i			= 0;
	int Item_ID		= 0;
	int	Part_task_checked_out_val_cnt = 0;
	//


	printf("\n Ketan Inside Part_checked_out_Validation .....\n");

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n Part_checked_out_Validation \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n CurrentTask: %s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n Parent Name: %s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	if(tc_strcmp(CurrentTask,"Manager Review" )==0)
	{
 		printf("\n Inside Manager Review Task \n");
		
		for (i=0; i < iNumAttch; i++)
		{
			const char *qry_entries[1];
			const char *qry_values[1];

			int n_tags_found=0;
			tag_t*		itemclass	= NULLTAG;
			tag_t		item		= NULLTAG;

			ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
			printf("\n Task itemid => %s\n",itemid);

			qry_entries[0] ="item_id";
			qry_values[0] = itemid;

			ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
			item = itemclass[0];
			if(item != NULLTAG )
			ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

		}

		tag_t   qryTagCntrlobj		= NULLTAG;
		tag_t*	list_of_cntrl_tags	= NULLTAG;

		char*	qry_entryCntrlformat[4] = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};	
		
		int controlObjfound	= 0;
		int	n_entryCntrlobj = 4;

		//
		char**	qry_Part_task_checked_out_Validation	= (char **) MEM_alloc(5 * sizeof(char *));

		if(QRY_find2("Control Objects...", &qryTagCntrlobj));

		if (qryTagCntrlobj)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_Part_task_checked_out_Validation[0]="MBOM";
			qry_Part_task_checked_out_Validation[1]="Part_task_checked_out_Validation";
			qry_Part_task_checked_out_Validation[2]="0";
			qry_Part_task_checked_out_Validation[3]="Live";
			
			if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_Part_task_checked_out_Validation, &controlObjfound, &list_of_cntrl_tags));
		}
		else
		{
			printf("\n Control Object Query not Found  \n");fflush(stdout);
		}

		printf("\n controlObjfound for Part_task_checked_out_Validation is ==> %d\n",controlObjfound);fflush(stdout);

		if(controlObjfound>0)
		{
			printf("\n Live. Inside code for checking Part_task_checked_out_Validation \n");fflush(stdout);

			Part_task_checked_out_val_cnt = Part_task_checked_out_Validation(item_rev_tag);
			if ( Part_task_checked_out_val_cnt > 0 )
			{
				printf("\n Inside decision \n");fflush(stdout);
				decision = EPM_nogo;
				return decision;
			}
			
		}
		
	}
	decision = EPM_go;
	return decision;
}
// Ended

// Added By Ketan
void stdstrcat_MBOM(char **src,char* dest)
{
    //printf("\n Inside Function gentplstrcat\n");fflush(stdout);

    // char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
     char * desc = dest ? dest : "NA";

    //printf("\n autoresizestrcat src len==%d",strlen(*src));
    //printf("\n autoresizestrcat desc len==%d",strlen(desc));
    const size_t a = strlen(*src);
    const size_t b = strlen(desc);
    const size_t size_ab = a + b + 2;
 
     //src = MEM_realloc(src, size_ab);

    *src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));


    tc_strcat(*src , desc);
 

}


//*****Prince S start function writing*****//
int MBOM_SA_JTPDF_CHECK_POINT( tag_t DMLLcmTag1 )
{
	int part_cnt       = 0;
	int prt_c		   = 0;
	int flag		   = 0;
	logical	isCheckOut = 0;
	int		dataset_count1		= 0;
	int		i_dataset1		= 0;
	int		JtPdfFlagset		= 0;
	int		JTPDFFlag		= 0;
	int     Flag_JT     =0;
	int     Flag_PDF    =0;

	char*	part_num		= NULL;
	char*	Part_numbers	= NULL;
	char*	parttype		= NULL;
	char*	DatasetNameOfObjTyp1 = NULL;
	tag_t	Dataset_Tag_Name1		= NULLTAG;
	tag_t	dataset_objNameType1		= NULLTAG;
	tag_t RendRel_tag = NULLTAG;

	tag_t Part_Tag			  = NULLTAG;
	tag_t part_tsk_rel1		  = NULLTAG;
	tag_t *Part_objects		  = NULLTAG; 
	tag_t*	dataset_secObjsList		= NULLTAG;
	tag_t*	dataset_secObjsList1		= NULLTAG;

	Part_numbers = (char *) MEM_alloc(3 * sizeof(char ));
	tc_strcpy(Part_numbers ,"");
	
	printf ("\n Prince Under the function MBOM_SA_JTPDF_CHECK_POINT \n");
	
	ITKCALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_rel1));
	printf ("\n Expanding Task to Parts relation\n");fflush(stdout);
	
	ITKCALL(GRM_list_secondary_objects_only(DMLLcmTag1, part_tsk_rel1, &part_cnt, &Part_objects));//part list and part count
	printf("\n New part_cnt : [%d]\n",part_cnt);fflush(stdout);

	if ( part_cnt > 0 )
	{
		for ( prt_c = 0; prt_c < part_cnt ; prt_c++ )
		{
			Part_Tag = Part_objects[prt_c];
	
			ITKCALL(AOM_UIF_ask_value(Part_Tag,"item_id",&part_num));//item name found
			printf("\n %d.part_num : [%s]\n",prt_c+1,part_num);fflush(stdout);
	
			ITKCALL(AOM_UIF_ask_value(Part_Tag,"t5_PartType",&parttype));//Part type found
			printf("\n part_type : [%s]\n",parttype);fflush(stdout);
	
			if(strcmp(parttype,"Stage Assembly")==0)
			{
				printf("\n Inside Stage Assembly \n");fflush(stdout);
				printf("\n sPDF check: Checking for IMAN_Rendering relation. \n");fflush(stdout);
				ITKCALL(GRM_find_relation_type("IMAN_Rendering",&RendRel_tag));
				if(RendRel_tag!=NULLTAG)
				{
					ITKCALL(GRM_list_secondary_objects_only(Part_Tag, RendRel_tag, &dataset_count1, &dataset_secObjsList1));
					printf("\n dataset_count ==> [%d]\n", dataset_count1);fflush(stdout);

					Flag_JT = 0;
					Flag_PDF= 0;
	            
					if (dataset_count1 > 0)
					{
						printf("\n Inside Dataset Count... \n");fflush(stdout);
						for (i_dataset1=0;i_dataset1<dataset_count1;i_dataset1++ )
						{   
							Dataset_Tag_Name1= dataset_secObjsList1[i_dataset1];
							TCTYPE_ask_object_type(Dataset_Tag_Name1,&dataset_objNameType1);
							if(dataset_objNameType1 != NULLTAG)
							{
								TCTYPE_ask_name2(dataset_objNameType1,&DatasetNameOfObjTyp1);
								printf("\n \t [%d]Sec Object Type is %s \n",i_dataset1,DatasetNameOfObjTyp1);fflush(stdout);
								if(tc_strcmp(DatasetNameOfObjTyp1,"DirectModel")==0)
								{
									printf ("\n JT Found %s \n",part_num);fflush(stdout);
									Flag_JT = 1;
								}
								else if(tc_strcmp(DatasetNameOfObjTyp1,"PDF")==0)
								{
									printf ("\n PDF Found %s \n",part_num);fflush(stdout);
									Flag_PDF = 1;
								}
							}
						}
					
					}
					printf ("\n Flag_JT=%d & Flag_PDF=%d  \n",Flag_JT,Flag_PDF);fflush(stdout);

					if (Flag_JT== 0 && Flag_PDF == 0)
					{
						printf ("\n Test 1 Inside error JT and PDF both not found.... \n");fflush(stdout);					
						JTPDFFlag=1;
						stdstrcat_MBOM(&Part_numbers,part_num);
						stdstrcat_MBOM(&Part_numbers,",");
					}
					else if (Flag_JT== 1 && Flag_PDF == 0)
					{
						printf ("\n Test 2 Inside error PDF not found.... \n");fflush(stdout);					
						JTPDFFlag=1;
						stdstrcat_MBOM(&Part_numbers,part_num);
						stdstrcat_MBOM(&Part_numbers,",");
					}
					else if (Flag_JT== 0 && Flag_PDF == 1)
					{
						printf ("\n Test 3 Inside error JT not found.... \n");fflush(stdout);					
						JTPDFFlag=1;
						stdstrcat_MBOM(&Part_numbers,part_num);
						stdstrcat_MBOM(&Part_numbers,",");
					}
				}
				else
				{
					printf ("\n NO Iman_rendering relationship found for stage assembly \n");fflush(stdout);
					JTPDFFlag=1;
					stdstrcat_MBOM(&Part_numbers,part_num);
					stdstrcat_MBOM(&Part_numbers,",");
				}
			}
			else
			{
				printf ("\n Part attch with MBOM task other than StageAssembly \n");fflush(stdout);	
			}
		}
	}
	printf ("\n JTPDFFlag  %d \n",JTPDFFlag);fflush(stdout);
	if (JTPDFFlag ==1)
	{
		printf("\n Jt PDF should be available before MBOM reviewer signoff. [%s]",Part_numbers);fflush(stdout);
		EMH_clear_errors();
		EMH_store_error_s2(EMH_severity_error,ITK_err,"\n JT/PDF not attached under MBOM stage assembly ,Please attach and proceed for approval.\n",Part_numbers);
		MEM_free(Part_numbers);
		return 1;
	}
	else
	{
		printf ("\n-------------- MBOM TASK STAGE ASSEMBLY JTPDF VALIDATION = Completed--------------------\n");fflush(stdout);
		return 0;
	}
}

//*****Prince end function writing*****//


//****Prince Singh Rule handler method start*****//
extern EPM_decision_t DLLAPI JTPDF_MBOM_Task_signoff_Validation(EPM_rule_message_t msg)
{
  EPM_decision_t decision;
	int status;
	
	tag_t	rootTask		=	NULLTAG;
	tag_t	item_rev_tag	= NULLTAG;
	tag_t*  pTagAttch;
	
	char*	CurrentTask				= NULL;
	char*	parent_name				= NULL;
	char*	Item_id					= NULL;
	char*	itemid;

	int iNumAttch	= 0;
	int i			= 0;
	int Item_ID		= 0;
	int	MBom_SA_Part_JTPDF_availibity_val_cnt = 0;

	printf("\n Prince Inside MBOM_SA_JTPDF_Validation .....\n");

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n Inside MBOM_SA_JTPDF_Validation \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n CurrentTask: %s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n Parent Name: %s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );
	if(tc_strcmp(CurrentTask,"Review The Changes" )==0)
	{
 		printf("\n Inside Review The Changes Task \n");
		
		for (i=0; i < iNumAttch; i++)
		{
			const char *qry_entries[1];
			const char *qry_values[1];

			int n_tags_found=0;
			tag_t*		itemclass	= NULLTAG;
			tag_t		item		= NULLTAG;

			ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
			printf("\n Task itemid => %s\n",itemid);

			qry_entries[0] ="item_id";
			qry_values[0] = itemid;

			ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
			item = itemclass[0];
			if(item != NULLTAG )
			ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

		}

		tag_t   qryTagCntrlobj		= NULLTAG;
		tag_t*	list_of_cntrl_tags	= NULLTAG;

		char*	qry_entryCntrlformat[4] = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};	
		
		int controlObjfound	= 0;
		int	n_entryCntrlobj = 4;

		//
		char**	qry_Mbom_SA_JTPDF_Validation	= (char **) MEM_alloc(5 * sizeof(char *));

		if(QRY_find2("Control Objects...", &qryTagCntrlobj));

		if (qryTagCntrlobj)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_Mbom_SA_JTPDF_Validation[0]="MBOM";
			qry_Mbom_SA_JTPDF_Validation[1]="MBOM_SA_JTPDF_CHECK_POINT";
			qry_Mbom_SA_JTPDF_Validation[2]="0";
			qry_Mbom_SA_JTPDF_Validation[3]="Live";
			
			if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_Mbom_SA_JTPDF_Validation, &controlObjfound, &list_of_cntrl_tags));
		}
		else
		{
			printf("\n Control Object Query not Found  \n");fflush(stdout);
		}

		printf("\n controlObjfound for MBOM_SA_JTPDF_CHECK_POINT is ==> %d\n",controlObjfound);fflush(stdout);

		if(controlObjfound>0)
		{
			printf("\n Live. Inside code for checking MBOM_SA_JTPDF_CHECK_POINT \n");fflush(stdout);

			MBom_SA_Part_JTPDF_availibity_val_cnt = MBOM_SA_JTPDF_CHECK_POINT(item_rev_tag);
			if ( MBom_SA_Part_JTPDF_availibity_val_cnt > 0 )
			{
				printf("\n Inside decision \n");fflush(stdout);
				decision = EPM_nogo;
				return decision;
			}
			
		}
		
	}
	decision = EPM_go;
	return decision;
}

//****Prince Singh Rule handler method end*****//

extern int mbom_user_assign_register_method(int *decision, va_list args)
{
    METHOD_id_t  method1;
    METHOD_id_t  method2;
    int ifail=0;
    char   type_name[TCTYPE_name_size_c+1];
    char   type_name1[TCTYPE_name_size_c+1];
    tag_t objTag = va_arg(args, tag_t);
    tag_t objTypeTag=NULLTAG;
	METHOD_id_t  method3; //sanket
	METHOD_id_t  method4; //sanket

	
	if( ITK_ok == EPM_register_action_handler("mbom_dml_task_assigment", "", mbom_dml_task_assigment))
	{
		//printf("\t\n Registered Action Handler mbom_dml_task_assigment \n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Action Handler mbom_dml_task_assigment\n");fflush(stdout);
	}

	if( ITK_ok == EPM_register_action_handler("mbom_dml_release", "", mbom_dml_release))
	{
		//printf("\t\n Registered Action Handler mbom_dml_release \n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Action Handler mbom_dml_release \n");fflush(stdout);
	}

	if( ITK_ok == EPM_register_action_handler("mbom_dml_claim", "", mbom_dml_claim))
	{
		//printf("\t\n Registered Action Handler mbom_dml_claim \n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Action Handler mbom_dml_claim \n");fflush(stdout);
	}

	if( ITK_ok == EPM_register_action_handler("mbom_epm_assign_participant", "", mbom_epm_assign_participant))
	{
		//printf("\t\n Registered Action Handler mbom_epm_assign_participant \n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Action Handler mbom_epm_assign_participant \n");fflush(stdout);
	}

	ifail = METHOD_find_method("CMHasSolutionItem", GRM_create_msg, &method2);
	if( ifail == ITK_ok )
	{
		//printf("\n Before register method for GRM_create_msg \n");
		if (method2.id != NULL)
		{
			if( METHOD_add_action(method2, METHOD_pre_action_type, (METHOD_function_t) mbom_dml_part_attach, NULL)!=ITK_ok)
			{
				//printf("Registered as METHOD_pre_action_type for A9_ValidationAtAMDML\n");
			}
		}
		else
		{
			printf("Method not found!GRM_create_msg\n");
		}
	}

     //sanket

	//ifail = METHOD_find_method("T5_MBOMDMLRevision", ITEM_create_msg, &method3);
	ifail = METHOD_find_method("T5_MBOMDMLRevision", TC_save_msg, &method3);
	if( ifail == ITK_ok )
	{
		//printf("\n Before register method for T5_MBOMDMLRevision \n");
		if (method3.id != NULL)
		{
			if( METHOD_add_action(method3, METHOD_post_action_type, (METHOD_function_t) createMBOM_Task, NULL)!=ITK_ok)
			{
				//printf("\n rrrrrrrrRegistered as Post-Action for T5_MBOMDMLRevision Creation\n");fflush(stdout);
			}
		}
		else
		{
			printf("\n Method not found for T5_MBOMDMLRevision !TC_save_msg\n");
		}
	}

	ifail = METHOD_find_method("CMReferences", GRM_create_msg, &method4);
	if( ifail == ITK_ok )
	{
		printf("\n Before register method for CMReferences. \n");
		if (method4.id != NULL)
		{
			if( METHOD_add_action(method4, METHOD_pre_action_type, (METHOD_function_t) mbom_dml_gmdml_part_attach, NULL)!=ITK_ok)
			printf("\n Method Registered as Pre-Action for CMReferences.\n");fflush(stdout);
		}
	}

	//sanket

	//****Priyanka Panda*****//
	//ifail = METHOD_find_method("T5_MBOMDMLRevision", IMAN_save_msg, &method1);
	ifail = METHOD_find_method("T5_MBOMDMLRevision", TC_save_msg, &method1);
	if( ifail == ITK_ok )
	{
		//printf("\n Before register method for T5_MBOMDMLRevision \n");
		if (method1.id != NULL)
		{
			if( METHOD_add_action(method1, METHOD_pre_action_type, (METHOD_function_t) mbom_dml_GMdml, NULL)!=ITK_ok)
			{
				//printf("\n rrrrrrrrRegistered as Pre-Action for T5_MBOMDMLRevision Creation\n");fflush(stdout);
			}
		}
		else
		{
			printf("\n Method not found for T5_MBOMDMLRevision !TC_save_msg\n");
		}
	}

	if( ITK_ok == EPM_register_action_handler("gmdml_drstatus_change", "", gmdml_drstatus_change))
	{
		//printf("\t\n Registered Action Handler gmdml_drstatus_change \n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Action Handler gmdml_drstatus_change \n");fflush(stdout);
	}
	//****Priyanka Panda*****//

	if( ITK_ok == EPM_register_rule_handler ("mbom_dml_signoff_checks_Func","This Handler is used to display message",(EPM_rule_handler_t)mbom_dml_signoff_checks_Func))
	{
		//printf("\t\n Registered Rule Handler mbom_dml_signoff_checks_Func\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Rule Handler mbom_dml_signoff_checks_Func\n");fflush(stdout);
	}
	if( ITK_ok == EPM_register_action_handler("tm_GMDML_Signoff_vlidation_check_MBOM", "", tm_GMDML_Signoff_vlidation_check_MBOM))
	{
		printf("\t\n Registered Action Handler tm_GMDML_Signoff_vlidation_check_MBOM \n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Action Handler tm_GMDML_Signoff_vlidation_check_MBOM \n");fflush(stdout);
	}

	if( ITK_ok == EPM_register_rule_handler ("Part_checked_out_Validation","This Handler is used to display message",(EPM_rule_handler_t)Part_checked_out_Validation))
	{
		//printf("\t\n Registered Rule Handler Part_checked_out_Validation\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Rule Handler Part_checked_out_Validation\n");fflush(stdout);
	}

	//****Prince Singh Rule handler register*****//
	if( ITK_ok == EPM_register_rule_handler ("JTPDF_MBOM_Task_signoff_Validation","This Handler is used to display message",(EPM_rule_handler_t)JTPDF_MBOM_Task_signoff_Validation))
	{
		printf("\t\n Registered Rule Handler JTPDF_MBOM_Task_signoff_Validation\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Rule Handler JTPDF_MBOM_Task_signoff_Validation\n");fflush(stdout);
	}
	//****Prince Singh handler register end*****//


	//venkat added

	
	if (ITK_ok == EPM_register_action_handler("mbom_dml_task_default_group", "", mbom_dml_task_default_group))
    {
        printf("\t\n Registered Action Handler mbom_dml_task_default_group\n");
        fflush(stdout);
    }
    else
    {
        printf("\t FAILED to register Action Handler mbom_dml_task_default_group\n");
        fflush(stdout);
    }
	 if (ITK_ok == EPM_register_rule_handler("mbom_dml_default_group_checks_Func", "This Handler is used to display message", (EPM_rule_handler_t)mbom_dml_default_group_checks_Func))
    {
        printf("\t\n Registered Rule Handler mbom_dml_default_group_checks_Func\n");
        fflush(stdout);
    }
    else
    {
        printf("\t FAILED to register Rule Handler mbom_dml_default_group_checks_Func\n");
        fflush(stdout);
    }
	
    return ITK_ok;
}

// Ketan Added 20072023 // for task submittion
int tm_MbomFtn_Call(void *return_data)
{
	int ifail = ITK_ok;

	tag_t	TaskTag			= NULLTAG;
	tag_t	DMLTag			= NULLTAG;
	tag_t	RootTag			= NULLTAG;
	tag_t	tTask			= NULLTAG;
	tag_t*	attachments		= NULLTAG;

	char*	TasktoSubmit	= NULL;
	char*   TaskNo			= NULL;
	char*   DMLNo			= NULL;
	char*	parent_name		= NULL;
	char*	tTask_name		= NULL;
	char*	parent_name1	= NULL;
	char*	Proj_Code		= NULL;

	int	  noAttachment	 	= 0;
			
	USERARG_get_tag_argument(&TaskTag);				// TaskTag              
	USERARG_get_tag_argument(&DMLTag);				// DMLTag               
	USERARG_get_tag_argument(&RootTag);				// RootTag          
	USERARG_get_tag_argument(&tTask);				// Current Assignment Tag
	USERARG_get_string_argument(&TasktoSubmit);		// TasktoSubmit  
	
	CALLAPI(AOM_ask_value_string(TaskTag,"item_id",&TaskNo));
	CALLAPI(AOM_ask_value_string(DMLTag,"item_id",&DMLNo));

	AOM_ask_value_string( DMLTag, "t5_cprojectcode", &Proj_Code);
	printf("\n DML Proj_Code => %s\n",Proj_Code);fflush(stdout);

	if(AOM_ask_value_string(RootTag,"object_name",&parent_name));
	printf("\n Parent Name => %s\n",parent_name);fflush(stdout);

	if(AOM_ask_value_string(tTask,"object_name",&tTask_name));
	printf("\n tTask_name => %s\n",tTask_name);fflush(stdout);

	if(EPM_ask_attachments(RootTag,EPM_target_attachment,&noAttachment,&attachments));
	printf("\n Ketan Target Attachment => %d\n",noAttachment);fflush(stdout);
	
	printf("\n Recieved Input argument in ITK tm_MbomFtn_Call(): TaskNo ==> [%s] || DMLNo ==>[%s] || RootTag ==> [%s] || TasktoSubmit ==> [%s] || tTask_name ==> [%s] \n",TaskNo,DMLNo,parent_name,TasktoSubmit,tTask_name);fflush(stdout);
	
	tag_t tSubProcessTag = NULLTAG;
	tag_t newProcess = NULLTAG;
	tag_t tJob		 = NULLTAG;
	tag_t Root_task	 = NULLTAG;
	tag_t* secondary_processes_tags	 = NULLTAG;

	tag_t tSubProcess = NULLTAG;

	int attachment_types[1] = {1};
	int attachmentTypes[1] = {EPM_interprocess_task_attachment};
	int cnt=0;
	char* TaskTagRevName = NULL;

	int attachmentType[] = { EPM_target_attachment };
	
	//SubProcess

	printf("\n Ketan WF Test 1\n");fflush(stdout);
	CALLAPI(EPM_find_process_template("MBOM Task BreakDown", &tSubProcessTag));
	
	printf("\n WF Test 2\n");fflush(stdout);
	CALLAPI(AOM_ask_value_string(TaskTag,"object_string",&TaskTagRevName));
	CALLAPI(EPM_create_process_deferred_start(TaskTagRevName, "MBOM Task BreakDown", tSubProcessTag, 1, &TaskTag, attachmentType, &tSubProcess));
	
	printf("\n WF Test 3\n");fflush(stdout);
	CALLAPI(EPM_ask_job(tTask, &tJob));

	CALLAPI(EPM_attach_sub_processes(tJob, 1, &tSubProcess)); //attach sub-workflow with parent process
	printf("\n WF Test 4\n");fflush(stdout);
	
	//get the sub process root task 
	tag_t tSubRootTask = NULLTAG;
	CALLAPI(EPM_ask_root_task(tSubProcess, &tSubRootTask));
	printf("\n WF Test 4.1\n");fflush(stdout);

	int iSubTarget = EPM_interprocess_task_attachment;
	
	CALLAPI(EPM_add_attachments(tTask, 1, &tSubRootTask, &iSubTarget));  //add attachment to sub-workflow root task

	CALLAPI(EPM_trigger_action(tSubRootTask, EPM_complete_action, "sub-workflow")); // trigger the sub-workflow.
	
	printf("\n Task submission End... \n");fflush(stdout);
			
	return ifail;

}

extern int AllUserServiceFnMbom(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
 
	int nargs = 5;
	int retValueType;
	int inputArgTypes[5] = {0};
	
	inputArgTypes[0] = USERARG_TAG_TYPE;	// TaskTag
	inputArgTypes[1] = USERARG_TAG_TYPE;	// DMLTag
	inputArgTypes[2] = USERARG_TAG_TYPE;	// RootTag
	inputArgTypes[3] = USERARG_TAG_TYPE;	// Current Assignment Tag
	inputArgTypes[4] = USERARG_STRING_TYPE; // TasktoSubmit
	
	retValueType = USERARG_STRING_TYPE ; 
	//printf("\n AllUserServiceFnMbom before....tm_MbomFtn_Call");fflush(stdout);  
	ifail=USERSERVICE_register_method("tm_MbomFtn_Call",(USER_function_t)tm_MbomFtn_Call,nargs,inputArgTypes,retValueType);
 
 return ifail;
 
}
// Ketan Ended 20072023

extern DLLAPI int tm_mbom_dml_assign_register_callbacks()
{
	 CUSTOM_register_exit("tm_mbom_dml_assign", "USER_init_module", (CUSTOM_EXIT_ftn_t)mbom_user_assign_register_method);

     //printf("\n ***~**** registered function tm_mbom_dml_assign\n");	fflush(stdout);

	 CUSTOM_register_exit("tm_mbom_dml_assign", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllUserServiceFnMbom); // Ketan Added 20072023

	 return ( ITK_ok );
}