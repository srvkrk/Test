
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:tm_CEDCoatedPart.c
*
* Description		: > This contains custom user service and handler. Implemented Custom ITK functions for CED Part Creation logic
> This ITK functions are called in Rich Client 
* Module  		        
* Since		    :    
* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 23/09/2019   	Sanjoy Mondal			    Initial Code
* 15/07/2025	Sanjoy Mondal				Change as per 14.3 include TPL in ESO validation
* -----------------------------------------------------------------------------
*
*****************************************************************************/				
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>

#define T5_WorkFlowHandlerErr (EMH_USER_error_base + 401)
#define T5_WorkFlowHandlerErr1 (EMH_USER_error_base + 402)
#define T5_WorkFlowHandlerErr2 (EMH_USER_error_base + 403)
#define T5_WorkFlowHandlerESOErr (EMH_USER_error_base + 701)
#define T5_WorkFlowHandlerAnxErr (EMH_USER_error_base + 702)
#define MAX_LINE_LEN 1024
#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_err 910001

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>            
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h>        
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/aom_prop.h>
#include <ics/ics2.h>
#include <ics/ics.h>
#include <property/idgeneration.h>
#include <Fnd0Participant/participant.h>
#include <tccore/item_msg.h>
#include <epm/signoff.h>


#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}



int sendESOStatusMail(tag_t dmlTag);
		
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}


typedef struct PartModel_
{
 int level;
 tag_t childItemRev;
 tag_t childBomLine;
} *PartModel; 


char *trimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int in_word=0;  /* word boundary logical check */
    int index=0;    /* index of the last non-space char*/

    /* validate input */
    if (!str)
        return str;

    while ((c=*src)){
        is_space=0;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;

        if(is_space == 0){
         /* Found a word */
            in_word = 1;
            *dst++ = *src++;  /* make the assignment first
                               * then increment
                               */
        } else if (is_space==1 && in_word==0) {
         /* Already going through a series of white-spaces */
            in_word=0;
            ++src;
        } else if (is_space==1 && in_word==1) {
         /* End of a word, dont mind copy white spaces here */
            in_word=0;
            *dst++ = *src++;
            index = (dst-str)-1; /* location of the last char */
        }
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

/* right trim */
char *rtrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int index=0;    /* index of the last non-space char */

    /* validate input */
    if (!str)
        return str;

    /* copy the string */
    while(*src){
        *dst++ = *src++;
        c = *src;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;
        else
            is_space=0;

        if (is_space==0 && *src)
            index = (src-str)+1;
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

/* left trim */
char *ltrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int index=0;    /* index of the first non-space char */

    /* validate input */
    if (!str)
        return str;

    /* skip leading white-spaces */
    while((c=*src)){ 
        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' '){
            ++src;
            ++index;
        } else
            break;
    }

    /* copy rest of the string */
    while(*src)
        *dst++ = *src++;

    /* terminate the string */
    *(src-index)='\0';

    return str;
}


void t5AddTagObjToSet(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		printf("\n ****t5AddTagObjToSet1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		printf("\n ****t5AddTagObjToSet2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}


char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


/* Function to add string into a set of string */
void t5AddStrToSetCED(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void t5SetAddInt(int *count,int **objlist,int obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****t5SetAddInt1");fflush(stdout);
		(*objlist) = (int *)malloc((*count ) * sizeof(int ));
	}
	else
	{
		//printf("\n **t5SetAddInt2");fflush(stdout);
		(*objlist) = (int *)realloc((*objlist),(*count ) * sizeof(int ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));


}


void setFindStr(char **str_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(str_list[k],str)==0)
		{
			*found=1;
			break;
		}

	}
}


void setFindInt(int *int_list,int count,int in,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(int_list[k]== in)
		{
			*found=1;
			break;
		}

	}
}


int t5GetItemRevisonCED(char* InputPart)
{
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;
	
	int n_tags_foundd2=0;
	int n_tags_foundd3=0;
	tag_t *tags_foundd3 = NULL;
	tag_t *tags_foundd2 = NULL;

	const char *attrss2[2];
	const char *valuess2[2];
	const char *attrss3[2];
	const char *valuess3[2];

	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)InputPart;
	values2[1] = "Design";
	if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
	}
	else
	{
		attrss2[0] ="item_id";
		attrss2[1] ="object_type";
		valuess2[0] = (char *)InputPart;
		valuess2[1] = "T5_EE_Part";
		if(ITEM_find_items_by_key_attributes(2,attrss2, valuess2, &n_tags_foundd2, &tags_foundd2)!=ITK_ok)PrintErrorStack();
		if (n_tags_foundd2>0)
		{
			OutPutTag= tags_foundd2[0];
		}
		else
		{
			attrss3[0] ="item_id";
			attrss3[1] ="object_type";
			valuess3[0] = (char *)InputPart;
			valuess3[1] = "T5_ClrPart";
			if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
			if (n_tags_foundd3>0)
			{
				OutPutTag= tags_foundd3[0];
			}
			else
			{
				//printf("\n FUN:Inside T5_ArchModule:%s.", InputPart);fflush(stdout);
				attrss3[0] ="item_id";
				attrss3[1] ="object_type";
				valuess3[0] = (char *)InputPart;
				valuess3[1] = "T5_ArchModule";
				if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
				//printf("\n FUN:T5_ArchModule part count :%d.", n_tags_foundd3);fflush(stdout);
				if (n_tags_foundd3>0)
				{
					OutPutTag= tags_foundd3[0];
				}
			}
		}
	}
	if(OutPutTag==NULLTAG)
	{
		printf("\n Tag for part no:%s.", InputPart);fflush(stdout);
	}
	else
	{
		printf("\n Tag for part no:%s.", InputPart);fflush(stdout);
	}

	return OutPutTag;	
}



int getItemTagByItemId(char* itemid, int *cnt, tag_t **items)
{
	int ifail = ITK_ok;
	tag_t *tags_found = NULL;
	int n_tags_found= 0;
	const char *attrs[1];
	const char *values[1];
	attrs[0]	= "item_id";
	values[0]	= itemid;


	ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);
	//printf("\n1111 No of tags ==>%d\n",n_tags_found);fflush(stdout);
	
	*cnt = n_tags_found;
	*items = tags_found;

	return ifail;
}

int queryLatestSpareKitRev(char* partno, tag_t* latestPart)
{
	int ifail = ITK_ok;
	tag_t partMstrTag = NULLTAG;
	tag_t partRev = NULLTAG;
	char* type = NULL;
	CALLAPI(ITEM_find_item(partno,&partMstrTag));
	
	if(partMstrTag!=NULLTAG)
	{
		CALLAPI(AOM_UIF_ask_value(partMstrTag,"object_type",&type));
		printf("\nType of the Part = %s\n",type);fflush(stdout);
		
		if(type!=NULL)
		{
			if(tc_strcmp(type, "Spare Kit")==0 || tc_strcmp(type, "Design")==0 )
			{
				//printf("\nPart type is Spare Kit part\n");fflush(stdout);
				
				CALLAPI(ITEM_ask_latest_rev(partMstrTag,&partRev));
				if(partRev !=NULLTAG)
				{
					*latestPart = partRev;
				}
				
			}
			
		}
		
	}
	
	return ifail;
}


int isLiveForSPIndUpWF(tag_t *contrlTag, logical *result)
{
	int ifail = ITK_ok;
	printf("\nIn function  isLiveForSPIndUpWF...\nCheck for control object CEDCreVl....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	
	qry_values[0] = "CEDCreVl";
	qry_values[1] = "CEDCreVl";
		
	CALLAPI(QRY_find2("Control Objects...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &contrlObjs));
	printf("\n Control objects CEDCreVl: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* usrInfo4 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{
			char* cntrlStr = NULL;
			CALLAPI(AOM_ask_value_string(cntrlObj,"object_string",&cntrlStr));
			printf("\n Control object ===>%s", cntrlStr);fflush(stdout);
			
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&usrInfo4));
			printf("\n Control object t5_Userinfo4 ===>%s", usrInfo4);fflush(stdout);
			if(tc_strstr(usrInfo4,"Design")!=NULL)
			{
				printf("\nLive for atatching Design in Spare Ind upd lifecycle\n");fflush(stdout);
				*result = TRUE;
			}			
			*contrlTag = cntrlObj;
			
		}
		
	}
	//T5_ControlObject	
	
	return ifail;
}


void setAddPartModel(int *count,PartModel **objlist,PartModel obj )
{

	*count=*count+1;
	printf("\n ****count==>%d", *count);fflush(stdout);
	if(*count==1)
	{
		//printf("\n ****setAddPartModel1");fflush(stdout);
		(*objlist) = (PartModel *)malloc((*count ) * sizeof(PartModel ));
		//printf("\n ***setAddPartModel2");fflush(stdout);
	}
	else
	{
		//printf("\n **setAddPartModel3");fflush(stdout);
		(*objlist) = (PartModel *)realloc((*objlist),(*count) * sizeof(PartModel ));
		//printf("\n ***setAddPartModel4");fflush(stdout);
		//printf("\n **setAddPartModel5");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
	printf("\n **setAddPartModel");fflush(stdout);
}

//Get latest parts WIP(if any) and latest Released
int getLatestReleasedAndWIPPart(tag_t partMaster,int *cnt, tag_t **partlist)
{
	int ifail = ITK_ok;
	int partRevCnt=0;
	tag_t* partRevTagObjs = NULL;
	tag_t partRevTag = NULLTAG;
	printf("\nStart of function ==> getLatestPartNew");fflush(stdout);
	if(partMaster == NULLTAG)
	{
		printf("\nDesign Master===> NULLTAG.Exit--> please check with admin");fflush(stdout);
		return ifail;
	}
	
	CALLAPI(ITEM_list_all_revs (partMaster, &partRevCnt, &partRevTagObjs));
	printf("\nPart Revision counts :%d\n",partRevCnt);fflush(stdout);
	
	if(partRevCnt>0)
	{
		int i=0;

		for(i=partRevCnt-1;i>=0;i--)
		{
			partRevTag = partRevTagObjs[i];
			char* itemId = NULL;
			char* partRev = NULL;
			char* checkedOut = NULL;
			char* rel_status = NULL;
			CALLAPI(AOM_ask_value_string(partRevTag,"item_id",&itemId))
			CALLAPI(AOM_ask_value_string(partRevTag,"item_revision_id",&partRev))
			CALLAPI(AOM_UIF_ask_value(partRevTag, "release_status_list", &rel_status))
			
			//checked_out
			CALLAPI(AOM_UIF_ask_value(partRevTag,"checked_out",&checkedOut));
			printf("\ngetLatestPartNew - Part object[%d]==>  %s,%s. Checkedout==>%s, Release status==>%s\n",i,itemId,partRev,checkedOut,rel_status);fflush(stdout);
			
			//Skip the checked out part
			if(tc_strcmp(checkedOut, "Y") == 0 )
			{
				continue;
			}
			t5AddTagObjToSet(cnt,partlist,partRevTag);
			if((tc_strstr(rel_status,"Released")!=NULL)||(tc_strstr(rel_status,"ERC Released")!=NULL))
			{
				break;
			}
			
					
		}

	}
	 
	
	return ifail;
}


int getNextRevisionId(char* lastrev, char** newRev)
{
	int ifail = ITK_ok;
	
	if(tc_strstr(lastrev,"NR;")!=NULL)
	{
		*newRev="A;1";
	}
	else if(tc_strstr(lastrev,"A;")!=NULL)
	{
		*newRev="B;1";
	}
	else if(tc_strstr(lastrev,"B;")!=NULL)
	{
		*newRev="C;1";
	}
	else if(tc_strstr(lastrev,"C;")!=NULL)
	{
		*newRev="D;1";
	}
	else if(tc_strstr(lastrev,"D;")!=NULL)
	{
		*newRev="E;1";
	}
	else if(tc_strstr(lastrev,"E;")!=NULL)
	{
		*newRev="F;1";
	}
	else if(tc_strstr(lastrev,"F;")!=NULL)
	{
		*newRev="G;1";
	}
	else if(tc_strstr(lastrev,"G;")!=NULL)
	{
		*newRev="H;1";
	}
	else if(tc_strstr(lastrev,"H;")!=NULL)
	{
		*newRev="I;1";
	}
	else if(tc_strstr(lastrev,"I;")!=NULL)
	{
		*newRev="J;1";
	}
	else if(tc_strstr(lastrev,"J;")!=NULL)
	{
		*newRev="K;1";
	}
	else if(tc_strstr(lastrev,"K;")!=NULL)
	{
		*newRev="L;1";
	}
	else if(tc_strstr(lastrev,"L;")!=NULL)
	{
		*newRev="M;1";
	}	
	else if(tc_strstr(lastrev,"M;")!=NULL)
	{
		*newRev="N;1";
	}
	else if(tc_strstr(lastrev,"N;")!=NULL)
	{
		*newRev="O;1";
	}
	else if(tc_strstr(lastrev,"O;")!=NULL)
	{
		*newRev="P;1";
	}
	else if(tc_strstr(lastrev,"P;")!=NULL)
	{
		*newRev="Q;1";
	}
	else if(tc_strstr(lastrev,"Q;")!=NULL)
	{
		*newRev="R;1";
	}
	else if(tc_strstr(lastrev,"R;")!=NULL)
	{
		*newRev="S;1";
	}
	else if(tc_strstr(lastrev,"S;")!=NULL)
	{
		*newRev="T;1";
	}
	else if(tc_strstr(lastrev,"T;")!=NULL)
	{
		*newRev="U;1";
	}	
	else if(tc_strstr(lastrev,"U;")!=NULL)
	{
		*newRev="V;1";
	}
	else if(tc_strstr(lastrev,"V;")!=NULL)
	{
		*newRev="W;1";
	}
	else if(tc_strstr(lastrev,"W;")!=NULL)
	{
		*newRev="X;1";
	}
	else if(tc_strstr(lastrev,"X;")!=NULL)
	{
		*newRev="Y;1";
	}
	else if(tc_strstr(lastrev,"Y;")!=NULL)
	{
		*newRev="Z;1";
	}		
	return ifail;
}

int reviseCEDCoatedBOM(tag_t partRevTag, char* plant, tag_t* newPartRevTag)
{
	int ifail = ITK_ok;
	
	//Check if the part is checked out
	if(partRevTag!=NULLTAG)
	{
		char* itemId = NULL;
		char* partRev = NULL;
		char* checkedOut = NULL;
		char* rel_status = NULL;
		tag_t newPartRev = NULLTAG;
		CALLAPI(AOM_ask_value_string(partRevTag,"item_id",&itemId))
		CALLAPI(AOM_ask_value_string(partRevTag,"item_revision_id",&partRev))
		CALLAPI(AOM_UIF_ask_value(partRevTag, "release_status_list", &rel_status))		
		CALLAPI(AOM_UIF_ask_value(partRevTag,"checked_out",&checkedOut));
		printf("\nSAN:reviseCEDCoatedBOM - Part object==>  %s,%s. Checkedout==>%s, Release status==>%s\n",itemId,partRev,checkedOut,rel_status);fflush(stdout);
			
		if(tc_strcmp(checkedOut,"Y")==0)
		{
			RES_checkin(partRevTag);
		
			CALLAPI(AOM_ask_value_string(partRevTag,"item_id",&itemId))
			CALLAPI(AOM_ask_value_string(partRevTag,"item_revision_id",&partRev))
			CALLAPI(AOM_UIF_ask_value(partRevTag, "release_status_list", &rel_status))		
			CALLAPI(AOM_UIF_ask_value(partRevTag,"checked_out",&checkedOut));
			printf("\nSAN:reviseCEDCoatedBOM - Part object==>  %s,%s. Checkedout==>%s, Release status==>%s\n",itemId,partRev,checkedOut,rel_status);fflush(stdout);
			
			
			
			
		}
		
		if(tc_strcmp(checkedOut,"Y")!=0)
		{
			char* newRev = NULL;
			CALLAPI(getNextRevisionId(partRev, &newRev));
			printf("\nNew Revision id:%s\n",newRev);fflush(stdout);
			CALLAPI(ITEM_copy_rev(partRevTag,newRev,&newPartRev));
			CALLAPI(AOM_refresh(partRevTag,0));
			CALLAPI(AOM_refresh(newPartRev,0));
			
			if(newPartRev!=NULLTAG)
			{
				*newPartRevTag = newPartRev;
			}
		}
	}
	
	return ifail;
	
}


int queryLatestSTDReleasedPartForPlant(char* partNo, char* objClass, char* plant, tag_t* latestSTDPart)
{
	int ifail = ITK_ok;
	tag_t partMstrTag = NULLTAG;
	char* type = NULL;
	
	printf("\nIn queryLatestSTDReleasedPartForPlant...\n\nInput parameters:\nPart No: %s\nObject Class: %s\nPlant: %s\n",partNo,objClass,plant);fflush(stdout);
	
	CALLAPI(ITEM_find_item(partNo,&partMstrTag));
	
	if(partMstrTag!=NULLTAG)
	{
		CALLAPI(AOM_ask_value_string(partMstrTag,"object_type",&type));
		printf("\nType of the Part = %s\n",type);fflush(stdout);
	}
	
	
	if(tc_strcmp(type,objClass)==0)
	{
		
		int partRevCnt = 0;	
		tag_t* partRevTagObjs = NULL;
		tag_t partRevTag = NULLTAG;
		
		CALLAPI(ITEM_list_all_revs (partMstrTag, &partRevCnt, &partRevTagObjs));
		printf("\n Part Revision counts :%d\n",partRevCnt);fflush(stdout);
		
		if(partRevCnt>0)
		{
			int i=0;

			for(i=partRevCnt-1;i>=0;i--)
			{
				partRevTag = partRevTagObjs[i];
				char* itemId = NULL;
				char* partRev = NULL;
				char* checkedOut = NULL;
				char* rel_status = NULL;
				CALLAPI(AOM_ask_value_string(partRevTag,"item_id",&itemId))
				CALLAPI(AOM_ask_value_string(partRevTag,"item_revision_id",&partRev))
				CALLAPI(AOM_UIF_ask_value(partRevTag, "release_status_list", &rel_status))
				
				//checked_out
				CALLAPI(AOM_UIF_ask_value(partRevTag,"checked_out",&checkedOut));
				printf("\nqueryLatestSTDReleasedPartForPlant:Part object[%d]==>  %s,%s. Checkedout==>%s, Release status==>%s\n",i,itemId,partRev,checkedOut,rel_status);fflush(stdout);
				
				//Skip the checked out part
				if(tc_strcmp(checkedOut, "Y") == 0 )
				{
					continue;
				}
				
				if(tc_strcmp(plant,"CAR")==0 && tc_strstr(rel_status,"STDSIC Released")!=NULL)
				{
				
					*latestSTDPart = partRevTag;
					break;
				}
				else if(tc_strcmp(plant,"CVBU JSR")==0 && tc_strstr(rel_status,"STDSIJ Released")!=NULL)
				{
					
					*latestSTDPart = partRevTag;
					break;
				}
				else if((tc_strcmp(plant,"CVBU LKO")==0 || tc_strcmp(plant,"PCBU LKO")==0)&& tc_strstr(rel_status,"STDSIL Released")!=NULL)
				{
					
					*latestSTDPart = partRevTag;
					break;
				}
				else if(tc_strcmp(plant,"CVBU PUNE")==0 && tc_strstr(rel_status,"STDSIP Released")!=NULL)
				{
					
					*latestSTDPart = partRevTag;
					break;
				}
				else if(tc_strcmp(plant,"DHARWAD")==0 && tc_strstr(rel_status,"STDSID Released")!=NULL)
				{
					*latestSTDPart = partRevTag;
					break;
				}
				else if(tc_strcmp(plant,"PCBU and CVBU")==0 && tc_strstr(rel_status,"STDSIP Released")!=NULL)
				{
					*latestSTDPart = partRevTag;
					break;
				}
				else if((tc_strcmp(plant,"CVBU PNR")==0 || tc_strcmp(plant,"SMALLCAR PNR")==0)&& tc_strstr(rel_status,"STDSIU Released")!=NULL)
				{
					*latestSTDPart = partRevTag;
					break;
				}				
				else if(tc_strcmp(plant,"SMALLCAR AHD")==0 && tc_strstr(rel_status,"STDSIA Released")!=NULL)
				{
					*latestSTDPart = partRevTag;
					break;
				}	
				else if(tc_strcmp(plant,"PUVBU")==0 && tc_strstr(rel_status,"STDSIV Released")!=NULL)
				{
					*latestSTDPart = partRevTag;
					break;
				}
				else if(tc_strcmp(plant,"ALL")==0 && tc_strstr(rel_status,"Released")!=NULL && tc_strstr(rel_status,"STDSI")!=NULL)
				{					
					*latestSTDPart = partRevTag;
					break;
				}
				else
				{
					//printf("\nINCORRECT INPUT PARAMETRES.Check the input parameters of the function......\n");fflush(stdout)
				}
				
			}	
			
			if(*latestSTDPart==NULLTAG)
			{
				printf("\nINCORRECT INPUT PARAMETRES or no data found. Please check..\n");fflush(stdout);
			}
		
		}
	}
	
	printf("\nEND of  queryLatestSTDReleasedPartForPlant...\n");fflush(stdout);
	return ifail;
}


int getControlObjForCEDandSPInd(tag_t *contrlTag, logical *result)
{
	int ifail = ITK_ok;
	printf("\nIn function  getControlObjForCEDandSPInd...\nCheck for control object CEDCreVl....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	
	qry_values[0] = "CEDCreVl";
	qry_values[1] = "CEDCreVl";
		
	CALLAPI(QRY_find2("Control Objects...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &contrlObjs));
	printf("\n Control objects CEDCreVl: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* usrInfo4 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{
			logical delInd = FALSE;
			char* name = NULL;
			char* userInfo1 = NULL;
			char* userInfo2 = NULL;
			char* userInfo3 = NULL;
			char* userInfo4 = NULL;
			char* userInfo5 = NULL;
			char* userInfo6 = NULL;
			char* userInfo7 = NULL;
			char* userInfo8 = NULL;
			char* userInfo9 = NULL;
			char* userInfo10 = NULL;
			
			CALLAPI(AOM_ask_value_string(cntrlObj,"object_string",&name));
			CALLAPI(AOM_ask_value_logical(cntrlObj,"t5_DelInd",&delInd));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_userinfo10",&userInfo10));
			
			printf("\nName:%s\nDelete Indicator:%d\nUser Info1:%s\nUser Info2:%s\nUser Info3:%s\nUser Info4:%s\nUser Info5:%s\nUser Info6:%s\nUser Info7:%s\nUser Info8:%s\nUser Info9:%s\nUser Info10:%s\n",name,delInd,userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9,userInfo10);fflush(stdout);
			
			
			
			*result = TRUE;
			*contrlTag = cntrlObj;
		}

	}

	return ifail;
}




int getControlObjForClientExec(tag_t *contrlTag, logical *result)
{
	int ifail = ITK_ok;
	printf("\nIn function  getControlObjForClientExec...\nCheck for control object CedPrtCre-CedPrtCre....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	
	qry_values[0] = "CedPrtCre";
	qry_values[1] = "CedPrtCre";
		
	CALLAPI(QRY_find2("Control Objects...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &contrlObjs));
	printf("\n Control objects CedPrtCre-CedPrtCre: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* usrInfo4 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{
			logical delInd = FALSE;
			char* name = NULL;
			char* userInfo1 = NULL;
			char* userInfo2 = NULL;
			char* userInfo3 = NULL;
			char* userInfo4 = NULL;
			char* userInfo5 = NULL;
			char* userInfo6 = NULL;
			char* userInfo7 = NULL;
			char* userInfo8 = NULL;
			char* userInfo9 = NULL;
			char* userInfo10 = NULL;
			
			CALLAPI(AOM_ask_value_string(cntrlObj,"object_string",&name));
			CALLAPI(AOM_ask_value_logical(cntrlObj,"t5_DelInd",&delInd));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_userinfo10",&userInfo10));
			
			printf("\nName:%s\nDelete Indicator:%d\nUser Info1:%s\nUser Info2:%s\nUser Info3:%s\nUser Info4:%s\nUser Info5:%s\nUser Info6:%s\nUser Info7:%s\nUser Info8:%s\nUser Info9:%s\nUser Info10:%s",name,delInd,userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9,userInfo10);fflush(stdout);
			
			
			
			*result = TRUE;
			*contrlTag = cntrlObj;
		}

	}

	return ifail;
}


int getCtrlTagClientExec(tag_t *contrlTag, logical *result)
{
	int ifail = ITK_ok;
	printf("\nIn function  getCtrlTagClientExec...\nCheck for control object CedSpUpd-CedSpUpd....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	
	qry_values[0] = "CedSpUpd";
	qry_values[1] = "CedSpUpd";
		
	CALLAPI(QRY_find2("Control Objects...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &contrlObjs));
	printf("\n Control objects CedSpUpd-CedSpUpd: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* usrInfo4 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{
			logical delInd = FALSE;
			char* name = NULL;
			char* userInfo1 = NULL;
			char* userInfo2 = NULL;
			char* userInfo3 = NULL;
			char* userInfo4 = NULL;
			char* userInfo5 = NULL;
			char* userInfo6 = NULL;
			char* userInfo7 = NULL;
			char* userInfo8 = NULL;
			char* userInfo9 = NULL;
			
			CALLAPI(AOM_ask_value_string(cntrlObj,"object_string",&name));
			CALLAPI(AOM_ask_value_logical(cntrlObj,"t5_DelInd",&delInd));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
			
			printf("\nName:%s\nDelete Indicator:%d\nUser Info1:%s\nUser Info2:%s\nUser Info3:%s\nUser Info4:%s\nUser Info5:%s\nUser Info6:%s\nUser Info7:%s\nUser Info8:%s\nUser Info9:%s",name,delInd,userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
			
			
			
			*result = TRUE;
			*contrlTag = cntrlObj;
		}

	}

	return ifail;
}


int tmUpdateSpareIndToTrue(tag_t partRev)
{
	int ifail = ITK_ok;
	char* partNumber = NULL;
	logical oldSpInd = false;
	logical newSpInd = false;
	tag_t PartSpareIndAttrID = NULLTAG;
	
	printf("\nUpdating spare indicator............\n");fflush(stdout);
	CALLAPI(AOM_ask_value_string(partRev,"object_string",&partNumber));	
	CALLAPI(AOM_ask_value_logical(partRev,"t5_SpareInd",&oldSpInd))	
	printf("\nSAN:UpdSPIND: Part Number: %s\nSpare Indicator: %d\n",partNumber,oldSpInd);fflush(stdout);
	
	if(oldSpInd)
	{
		newSpInd = false;
	}
	else
	{
		newSpInd = true;
	}
	newSpInd = true;//always true
	tag_t class_id = NULLTAG;
	char* class_name = NULL;
	
	CALLAPI(POM_class_of_instance(partRev,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));
	printf("\nSAN:UpdSPIND:class_name is :%s\n",class_name);fflush(stdout);
	
	CALLAPI(AOM_lock(partRev));
	CALLAPI(POM_attr_id_of_attr("t5_SpareInd",class_name,&PartSpareIndAttrID));
	CALLAPI(AOM_refresh(partRev,TRUE));
	CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
	
	CALLAPI(POM_set_attr_logical(1,&partRev,PartSpareIndAttrID,newSpInd));
	ifail = AOM_save_without_extensions(partRev);
	CALLAPI(AOM_unlock(partRev));
	
	CALLAPI(AOM_ask_value_logical(partRev,"t5_SpareInd",&newSpInd))	
	printf("\nSAN:UpdSPIND:Part Number: %s    New Spare Indicator: %d\n",partNumber,newSpInd);fflush(stdout);
	
	
	return ifail;
}




int tmUpdateSpareInd(tag_t partRev)
{
	int ifail = ITK_ok;
	char* partNumber = NULL;
	logical oldSpInd = false;
	logical newSpInd = false;
	tag_t PartSpareIndAttrID = NULLTAG;
	
	printf("\nUpdating spare indicator............\n");fflush(stdout);
	CALLAPI(AOM_ask_value_string(partRev,"object_string",&partNumber));	
	CALLAPI(AOM_ask_value_logical(partRev,"t5_SpareInd",&oldSpInd))	
	printf("\nSAN:UpdSPIND: Part Number: %s\nSpare Indicator: %d\n",partNumber,oldSpInd);fflush(stdout);
	
	if(oldSpInd)
	{
		newSpInd = false;
	}
	else
	{
		newSpInd = true;
	}
	tag_t class_id = NULLTAG;
	char* class_name = NULL;
	
	/*
	CALLAPI(POM_class_of_instance(partRev,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));
	printf("\nSAN:UpdSPIND:class_name is :%s\n",class_name);fflush(stdout);
	
	CALLAPI(AOM_lock(partRev));
	CALLAPI(POM_attr_id_of_attr("t5_SpareInd",class_name,&PartSpareIndAttrID));
	CALLAPI(AOM_refresh(partRev,TRUE));
	CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
	
	CALLAPI(POM_set_attr_logical(1,&partRev,PartSpareIndAttrID,newSpInd));
	CALLAPI(AOM_unlock(partRev));
	
	*/
	CALLAPI(AOM_lock(partRev));
	CALLAPI(AOM_set_value_logical(partRev,"t5_SpareInd",newSpInd));
	//CALLAPI(AOM_set_value_string(partRevTag,"t5_ColourInd",newColInd));
	CALLAPI(AOM_save_without_extensions(partRev));
	CALLAPI(AOM_refresh(partRev,0));
	CALLAPI(AOM_unlock(partRev));
	
	
	CALLAPI(AOM_ask_value_logical(partRev,"t5_SpareInd",&newSpInd))	
	printf("\nSAN:UpdSPIND:Part Number: %s    New Spare Indicator: %d\n",partNumber,newSpInd);fflush(stdout);
	
	
	

	return ifail;
}


int isEligibleForCEDPartCreation(tag_t partRevTag, logical* result)
{
	int ifail = ITK_ok;
	
	char* itemId12 = NULL;
	char* partLCS = NULL;	
	char* rel_status = NULL;
	char* partDesgGrp = NULL;
	int* setOfDesignGrp = NULL;
	int designCnt = 0;
	int i =0;
	
	logical spareIndicator = false;
	logical validLcs = false;
	logical validDesGrp = false;
	logical validDesignation = false;
	
	int partDesGrpInt = 0;
	char* desigStr = NULL;
	char* PartType = NULL;
	
	CALLAPI(AOM_ask_value_string(partRevTag,"item_id",&itemId12));//object_name item_id
	printf("\nSAN: isEligibleForCEDPartCreation:12 digit part no===>%s\n",itemId12);fflush(stdout);
	CALLAPI(AOM_ask_value_logical(partRevTag,"t5_SpareInd",&spareIndicator))
	
	printf("\nSAN: isEligibleForCEDPartCreation: Spare Indicator of the part %s =====>%d\n",itemId12,spareIndicator);fflush(stdout);
	
	
	//Check for LC State - STD1 released
	
	CALLAPI(AOM_UIF_ask_value(partRevTag,"release_status_list",&partLCS))
	printf("\n SAN: isEligibleForCEDPartCreation:LC State of part Rev: %s ", partLCS);fflush(stdout);
	
	if((tc_strstr(partLCS,"STDSIP Released")!=NULL)||(tc_strstr(partLCS,"STDSIC Released")!=NULL))//T5_LcsStdRlzd STDSIC Released
	{
		validLcs = true;
	}
	
	//Check for Design grp - 31 and 60 till 99 - t5_DesignGrp
	CALLAPI(AOM_ask_value_string(partRevTag,"t5_DesignGrp",&partDesgGrp));//object_name item_id
	printf("\nSAN: isEligibleForCEDPartCreation:Design Group===>%s\n",partDesgGrp);fflush(stdout);
	partDesGrpInt = atoi(partDesgGrp);
	//partDesGrpInt=67;
	printf("\nSAN: isEligibleForCEDPartCreation:Design Group in int format===>%d\n",partDesGrpInt);fflush(stdout);
	t5SetAddInt(&designCnt,&setOfDesignGrp,31);
	for(i=60;i<=99;i++)
	{
		t5SetAddInt(&designCnt,&setOfDesignGrp,i);
	}
	
	printf("\n SAN: isEligibleForCEDPartCreation:Size of Design group set ===>%d\n",designCnt);fflush(stdout);
	
	int found =0;
	setFindInt(setOfDesignGrp,designCnt,partDesGrpInt,&found);
	
	if(found==1)
	{
		printf("\nSAN: isEligibleForCEDPartCreation:Found Design group %s\n",partDesgGrp);fflush(stdout);
		validDesGrp = true;
	}
	else
	{
		printf("\n SAN: isEligibleForCEDPartCreation:NOT Found Design group %s\n",partDesgGrp);fflush(stdout);
		validDesGrp = false;
	}
	
	//Designation (9th and 10th digit)= For part 33,69,71,82, 86, 92 and 99 and for assemblies 01, 02 and 03 - 
	   /*
		find parttype -
		if assembly then check for 9th and 10th digit - it should be 01,02 and 03
		else
			it should be 33, 69,71,82,86,92 and 99
	 */
	 int len = 0;
	 len=strlen(itemId12);
	 if(len==12)
	 {
		 desigStr = subString(itemId12,8,2);
		 
		 //strncpy(desigStr, itemId12+8, 2);
	 
		if(desigStr!=NULL)
		{
			CALLAPI(AOM_UIF_ask_value(partRevTag,"t5_PartType",&PartType));
			printf("\n SAN: isEligibleForCEDPartCreation:PartType is :%s\n",PartType);fflush(stdout);
			
			if(tc_strcmp(PartType,"Assembly")==0)
			{
				if((tc_strcmp(desigStr,"01")==0 )|| (tc_strcmp(desigStr,"02")==0 ) || (tc_strcmp(desigStr,"03")==0 ))
				{
					validDesignation = true;
				}
				else
				{
					validDesignation = false;
				}
			}
			else
			{
				if((tc_strcmp(desigStr,"33")==0 )|| (tc_strcmp(desigStr,"69")==0 ) || (tc_strcmp(desigStr,"71")==0 )|| (tc_strcmp(desigStr,"82")==0 )|| (tc_strcmp(desigStr,"86")==0 )|| (tc_strcmp(desigStr,"92")==0 )|| (tc_strcmp(desigStr,"99")==0 ))
				{
					validDesignation = true;
				}
				else
				{
					validDesignation = false;
				}
			}
			
		}
		else
		{
			printf("\nSAN: isEligibleForCEDPartCreation:ERROR- desigStr is NULL. Should not have happen. Please check\n");fflush(stdout);
			validDesignation=false;
		}
	 }
	printf("\n SAN: isEligibleForCEDPartCreation:Designation of part %s===>%s\n",itemId12,desigStr);fflush(stdout);
	
	printf("\nspareIndicator:%d\nvalidLcs:%d\nvalidDesGrp:%d\nvalidDesignation:%d\n",spareIndicator,validLcs,validDesGrp,validDesignation);fflush(stdout);
	   
	if(spareIndicator && validLcs && validDesGrp && validDesignation)
	{
		*result = TRUE;
	}
	else
	{
		*result = FALSE;
	}
	
	return ifail;
} 




int relatePrimaryWithSecondaryObj(tag_t primaryTag, tag_t secondaryTag, char* relation )
{
	int ifail = ITK_ok;
	tag_t relation_type = NULLTAG;
	tag_t primSecRelation = NULLTAG;
	CALLAPI(GRM_find_relation_type(relation,&relation_type));
	if(relation_type!=NULLTAG)
	{
		CALLAPI(GRM_create_relation(primaryTag, secondaryTag, relation_type,  NULLTAG, &primSecRelation));
		CALLAPI(GRM_save_relation(primSecRelation));
	}
	else
	{
		printf("\nNo relation %s exists...Please check. Very serious error.\n",relation);fflush(stdout);
	}
	 
	return ifail;
}




int addStatusToTag(tag_t partTag,char* plant)
{
	int ifail = ITK_ok;
	tag_t   release_status =NULLTAG;
	char* ReleaseStatus = NULL;
	logical retain_released_date = TRUE;
	
	//APLC Working - T5_LcsAPLWrkg
	//APLA Working - T5_LcsAPLaWrkg
	
	//STDSIC Working- T5_LcsSTDWrkg
	//STDSIC Released - T5_LcsStdRlzd
	
	//ERC Released - T5_LcsErcRlzd
	
	if(tc_strcmp(plant,"CAR")==0 || tc_strcmp(plant,"PCBU")==0)
	{
		CALLAPI(RELSTAT_create_release_status("T5_LcsAPLWrkg",&release_status));
		CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

		if((strcmp(ReleaseStatus,"APLC Working")==0)||strcmp(ReleaseStatus,"T5_LcsAPLWrkg")==0 )
		{
			CALLAPI(RELSTAT_add_release_status(release_status,1,&partTag,retain_released_date)); 
		}
	}
	else if(tc_strcmp(plant,"CVBU JSR")==0)
	{
		CALLAPI(RELSTAT_create_release_status("T5_LcsAPLjWrkg",&release_status));
		CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

		if((strcmp(ReleaseStatus,"APLJ Working")==0)||strcmp(ReleaseStatus,"T5_LcsAPLjWrkg")==0 )
		{
			CALLAPI(RELSTAT_add_release_status(release_status,1,&partTag,retain_released_date)); 
		}
	}
	
	else if(tc_strcmp(plant,"CVBU PUNE")==0)
	{
		CALLAPI(RELSTAT_create_release_status("T5_LcsAPLpWrkg",&release_status));
		CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

		if((strcmp(ReleaseStatus,"APLP Working")==0)||strcmp(ReleaseStatus,"T5_LcsAPLpWrkg")==0 )
		{
			CALLAPI(RELSTAT_add_release_status(release_status,1,&partTag,retain_released_date)); 
		}
	}
	else if(tc_strcmp(plant,"DHARWAD")==0)
	{
		CALLAPI(RELSTAT_create_release_status("T5_LcsAPLdWrkg",&release_status));
		CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

		if((strcmp(ReleaseStatus,"APLD Working")==0)||strcmp(ReleaseStatus,"T5_LcsAPLdWrkg")==0 )
		{
			CALLAPI(RELSTAT_add_release_status(release_status,1,&partTag,retain_released_date)); 
		}
	}	
	else if(tc_strcmp(plant,"PCBU and CVBU")==0)
	{
		CALLAPI(RELSTAT_create_release_status("T5_LcsAPLpWrkg",&release_status));
		CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

		if((strcmp(ReleaseStatus,"APLP Working")==0)||strcmp(ReleaseStatus,"T5_LcsAPLpWrkg")==0 )
		{
			CALLAPI(RELSTAT_add_release_status(release_status,1,&partTag,retain_released_date)); 
		}
	}
	else if(tc_strcmp(plant,"CVBU PNR")==0 || tc_strcmp(plant,"SMALLCAR PNR")==0)
	{
		CALLAPI(RELSTAT_create_release_status("T5_LcsAPLuWrkg",&release_status));
		CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

		if((strcmp(ReleaseStatus,"APLU Working")==0)||strcmp(ReleaseStatus,"T5_LcsAPLuWrkg")==0 )
		{
			CALLAPI(RELSTAT_add_release_status(release_status,1,&partTag,retain_released_date)); 
		}
	}
	else if(tc_strcmp(plant,"SMALLCAR AHD")==0)
	{
		CALLAPI(RELSTAT_create_release_status("T5_LcsAPLaWrkg",&release_status));
		CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

		if((strcmp(ReleaseStatus,"APLA Working")==0)||strcmp(ReleaseStatus,"T5_LcsAPLaWrkg")==0 )
		{
			CALLAPI(RELSTAT_add_release_status(release_status,1,&partTag,retain_released_date)); 
		}
	}
	else if(tc_strcmp(plant,"PUVBU")==0)
	{
		CALLAPI(RELSTAT_create_release_status("T5_LcsAPLvWrkg",&release_status));
		CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

		if((strcmp(ReleaseStatus,"APLV Working")==0)||strcmp(ReleaseStatus,"T5_LcsAPLvWrkg")==0 )
		{
			CALLAPI(RELSTAT_add_release_status(release_status,1,&partTag,retain_released_date)); 
		}
	}
	else if(tc_strcmp(plant,"ALL")==0)
	{
		CALLAPI(RELSTAT_create_release_status("T5_LcsAPLWrkg",&release_status));
		CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

		if((strcmp(ReleaseStatus,"APLC Working")==0)||strcmp(ReleaseStatus,"T5_LcsAPLWrkg")==0 )
		{
			CALLAPI(RELSTAT_add_release_status(release_status,1,&partTag,retain_released_date)); 
		}
	}
	return ifail;
}



int createNewCEDCoatedPart(tag_t partRevTag, char* plant, tag_t* newCedPart)
{
	int ifail = ITK_ok;
	tag_t rev_type_tag = NULLTAG;
	tag_t rev_create_input_tag = NULLTAG;
	tag_t item_create_input_tag = NULLTAG;
	char* itemId12 = NULL;
	tag_t item_type_tag = NULLTAG;
	tag_t cedPartMaster = NULLTAG;
	char* itemId12rev = NULL;
	char* itemId12desc = NULL;
	char* ceditemId12desc = NULL;
	char* itemId12prtType = NULL;
	char* itemId12prjcode = NULL;
	char* itemId12DsgGrp = NULL;
	
	printf("\nSAN:creCEDPart: Inside CED Coated part creation logic...........\n");fflush(stdout);
	
	if(partRevTag == NULLTAG)
	{
		printf("\nSAN:creCEDPart::partRevTag tag is NULL. Do nothing.....\n");fflush(stdout);
		return ifail;
	}
	
	CALLAPI(AOM_ask_value_string(partRevTag,"item_id",&itemId12));//object_name item_id
	printf("\nSAN:creCEDPart:12 digit part no===>%s\n",itemId12);fflush(stdout);
	
	
	CALLAPI(AOM_ask_value_string(partRevTag,"item_revision_id",&itemId12rev));//object_name item_id
	printf("\nSAN:creCEDPart:12 digit part no revision===>%s\n",itemId12rev);fflush(stdout);	
	
	
	CALLAPI(AOM_ask_value_string(partRevTag,"object_desc",&itemId12desc));//Description
	printf("\nSAN:creCEDPart:12 digit part no description===>%s\n",itemId12desc);fflush(stdout);
	
	ceditemId12desc = (char*)MEM_alloc(strlen(itemId12desc)*sizeof(char) + 30);
	tc_strcpy(ceditemId12desc,"");
	tc_strcat(ceditemId12desc,"CED-");
	tc_strcat(ceditemId12desc,itemId12desc);
			
	printf("\nNew CED Part desc ceditemId12desc:%s\n",ceditemId12desc);fflush(stdout);	
	
	
	
	CALLAPI(AOM_ask_value_string(partRevTag,"t5_PartType",&itemId12prtType));//Part Type
	printf("\nSAN:creCEDPart:12 digit part no Part Type===>%s\n",itemId12prtType);fflush(stdout);
	
	CALLAPI(AOM_ask_value_string(partRevTag,"t5_ProjectCode",&itemId12prjcode));//Part Type
	printf("\nSAN:creCEDPart:12 digit part no Project Code===>%s\n",itemId12prjcode);fflush(stdout);
	
	
	CALLAPI(AOM_ask_value_string(partRevTag,"t5_DesignGrp",&itemId12DsgGrp));//Part Type
	printf("\nSAN:creCEDPart:12 digit part no Design Group===>%s\n",itemId12DsgGrp);fflush(stdout);
	
	//TCTYPE_find_type("Design Revision", NULL, &rev_type_tag);//T5_SparKitRevision
	
	
	
	TCTYPE_find_type("T5_SparKitRevision", NULL, &rev_type_tag);
	if(rev_type_tag!=NULLTAG)
	{
		
		tag_t cedLatestPartTag = NULLTAG;
		printf("\nSAN:creCEDPart:rev_type_tag Tag Found."); fflush(stdout);
		
		
		char* cedPartNo=(char *) MEM_alloc(20);
		tc_strcpy(cedPartNo,"");
		tc_strcpy(cedPartNo,itemId12);
		tc_strcat(cedPartNo,"35");
		
		printf("\nSAN:creCEDPart:14 digit  CED part no===>%s\n",cedPartNo);fflush(stdout);
		
		

		printf("\nCreating CED coated parts NR revision- first time.....\n");fflush(stdout);
		TCTYPE_construct_create_input(rev_type_tag, &rev_create_input_tag);
		AOM_set_value_string(rev_create_input_tag, "object_name", cedPartNo);
		AOM_set_value_string(rev_create_input_tag, "item_revision_id", "NR;1"); //itemId12rev
		
		AOM_set_value_string(rev_create_input_tag, "object_desc", ceditemId12desc); //itemId12rev
		AOM_set_value_string(rev_create_input_tag, "t5_PartType", itemId12prtType); //itemId12rev
		AOM_set_value_string(rev_create_input_tag, "t5_ProjectCode", itemId12prjcode); //itemId12rev
		AOM_set_value_string(rev_create_input_tag, "t5_DesignGrp", itemId12DsgGrp); //itemId12rev
		
		TCTYPE_find_type("T5_SparKit", NULL, &item_type_tag);
		if(item_type_tag!=NULLTAG)
		{
				printf("\nSAN:creCEDPart: item_type_tag Tag Found."); fflush(stdout);
				
				
		}
		TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag);

		AOM_set_value_string(item_create_input_tag, "item_id", cedPartNo);
		AOM_set_value_string(item_create_input_tag, "object_name", cedPartNo);
		AOM_set_value_tag(item_create_input_tag, "revision",rev_create_input_tag);

		//Create CED Part and its  Revision
		TCTYPE_create_object(item_create_input_tag, &cedPartMaster);
		
		if(cedPartMaster!=NULLTAG)
		{
			printf("\nSAN:creCEDPart: CED Part created."); fflush(stdout);					 
			AOM_save_with_extensions(cedPartMaster);				
		}
		
		
		//Get Item revision
		tag_t * ced_rev_list = NULL;
		int ced_item_count = 0;
		tag_t cedPartRev = NULLTAG;
		ITEM_list_all_revs (cedPartMaster, &ced_item_count, &ced_rev_list);
		
		if(ced_item_count>0)
		{
			cedPartRev = ced_rev_list[0];
			*newCedPart = cedPartRev;
		}
		
		
	}


	return ifail;
}



int creCEDCoatedParts(tag_t* partRevList, int cnt)
{
	int ifail = ITK_ok;
	int i=0;
	printf("\n\n*******************Inside CED PART CREATION LOGIC*********************************\n");fflush(stdout);	
	printf("\ncnt===>%d\n",cnt);fflush(stdout);
	
	
	
	tag_t partRev = NULLTAG;
	for(i=0;i<cnt;i++)
	{
		char* partnm = NULL;
		char* itmid = NULL;
		tag_t partMstr = NULLTAG;
		
		partRev = partRevList[i];
		
		CALLAPI(AOM_ask_value_string(partRev,"object_string",&partnm))
		printf("\n111...Creating CED Coated for part %s\n",partnm);fflush(stdout);
		
		
		CALLAPI(ITEM_ask_item_of_rev(partRev,&partMstr));
		CALLAPI(AOM_ask_value_string(partMstr,"item_id",&itmid))
		printf("\n222..Part Master ID %s\n",itmid);fflush(stdout);
		
		char* cedPartNo=(char *) MEM_alloc(20);
		tc_strcpy(cedPartNo,"");
		tc_strcpy(cedPartNo,itmid);
		tc_strcat(cedPartNo,"35");

		printf("\n333...14 digit  CED part no===>%s\n",cedPartNo);fflush(stdout);
		
		int cnt1=0;
		tag_t* cedTags = NULL;
		CALLAPI(AOM_ask_value_tags(partRev,"T5_HasSpareKit",&cnt1,&cedTags));
		
		printf("\n\ni===>%d\n",i);fflush(stdout);
		printf("\n4444..... cnt1===>%d\n",cnt1);fflush(stdout);
		
		logical flagCEDPartCre = false;
		if(cnt1>0)
		{
			printf("\n5555... Already having CED coated parts and is related to the part revision\n");fflush(stdout);
			
			printf("\nCheck if correct ced coated part is attached to the part rev\n");fflush(stdout);
			int k =0;
			logical flag = false;
			logical flag1 = false;
			for(k=0;k<cnt1;k++)
			{
				char* cedid = NULL;
				flag = false;
				CALLAPI(AOM_ask_value_string(cedTags[k],"item_id",&cedid));
				printf("\ncedPartNo=%s cedid=%s\n",cedPartNo,cedid);fflush(stdout);
				if(tc_strcmp(cedPartNo,cedid)==0)
				{
					printf("\nAlready correct CED part attached to the part rev, so skip this part revision...\n");fflush(stdout);
					flag = true;
					flag1 = true;
					//Check correct master is attached to the ced part if not then attach it.
					printf("\nCheck correct master is attached to the ced part if not then attach it.\n");fflush(stdout);
					int cnt3 = 0;
					tag_t* prtmstrTags = NULL;
					
					CALLAPI(AOM_ask_value_tags(cedTags[k],"T5_SpareKitForPart",&cnt3,&prtmstrTags));
					
					if(cnt3>0)
					{
						flag1 = true;
						int l=0;
						tag_t  prtMstrObj= NULLTAG;
						for(l=0;l<cnt3;l++)
						{
							char* prtmstid = NULL;
							CALLAPI(AOM_ask_value_string(prtmstrTags[l],"item_id",&prtmstid));
							printf("\nitmid=%s prtmstid=%s\n",itmid,prtmstid);fflush(stdout);
							
							if(tc_strcmp(itmid,prtmstid)==0)
							{
								printf("\nCorrect Part master is already attched to the ced part\n");fflush(stdout);
								flag1 = false;
								break;
							}
						}
					}
						
					if(flag1)
					{
						//Not correct master is attched to ced part so attach it.
						printf("\nNot correct master is attched to ced part so attach correct master to it.\n");fflush(stdout);
						CALLAPI(relatePrimaryWithSecondaryObj(cedTags[k],partMstr,"T5_SpareKitForPart"));
						printf("\nPart Master %s is related to the CED Part %s\n",itmid,cedPartNo);fflush(stdout);							
						
					}
					
					
					
					break;
				}
				
				
			}
			if(flag)
			{
				//skip this part. all relations are correct
				printf("\nSkip the part %s for ced part creation...\n",partnm);fflush(stdout);
				continue;
			}
			else
			{
				printf("\nNot correct CED coated part is present/related to the part revision...\n");fflush(stdout);
				flagCEDPartCre = true;
			}
			
		}
		printf("\nFlag for CED Part creation(flagCEDPartCre): %d\n");fflush(stdout);
		if(flagCEDPartCre || cnt1==0)
		{
			tag_t cedLatestPartTag = NULLTAG;
			CALLAPI(queryLatestSpareKitRev(cedPartNo,&cedLatestPartTag));
			if(cedLatestPartTag!=NULLTAG)
			{
				char* cedPartNo1 = NULL;
				CALLAPI(AOM_ask_value_string(cedLatestPartTag,"item_id",&cedPartNo1))
				if(tc_strcmp(cedPartNo,cedPartNo1)==0)
				{
					printf("\n6666... Already having CED coated parts but not related to the part revision\n");fflush(stdout);
					//Relate the CED Part with partrev
					
					//CALLAPI(relatePrimaryWithSecondaryObj(partRev,cedLatestPartTag,"T5_HasSpareKit")); //sanjoy commenting - due to sparekit part relation validation issue - sco 404
					printf("\nPart Revision %s is related to the CED Part %s\n",partnm,cedPartNo);fflush(stdout);
					
					//Check master is attached to the ced part rev
					int cnt2 = 0;
					tag_t* mstrTags = NULL;
					CALLAPI(AOM_ask_value_tags(cedLatestPartTag,"T5_SpareKitForPart",&cnt2,&mstrTags));
					printf("\n7777..... cnt2===>%d\n",cnt2);fflush(stdout);
					if(cnt2==0)
					{
						printf("\n8888.. No master related to spare kit\n");fflush(stdout);
						CALLAPI(relatePrimaryWithSecondaryObj(cedLatestPartTag,partMstr,"T5_SpareKitForPart"));
						printf("\nPart Master %s is related to the CED Part %s\n",itmid,cedPartNo);fflush(stdout);
					}
					if(cnt2>0)
					{
						logical flg = true;
						//Check if any other master is attached or not
						printf("\n9999.. Check if any other master is attached. If attached then attach then attach the correct one..\n");fflush(stdout);
						int j=0;
						for(j=0;j<cnt2;j++)
						{
							char* mstrid = NULL;
							flg = true;
							CALLAPI(AOM_ask_value_string(mstrTags[j],"item_id",&mstrid))
							printf("\nitmid=%s mstrid=%s\n",itmid,mstrid);fflush(stdout);
							if(tc_strcmp(itmid,mstrid)==0)
							{
								printf("\naaa.. Already master is attached...\n");fflush(stdout);
								flg = false;
								break;
							}
						}
						
						if(flg)
						{
							printf("\nbbbb.. No master related to spare kit\n");fflush(stdout);
							CALLAPI(relatePrimaryWithSecondaryObj(cedLatestPartTag,partMstr,"T5_SpareKitForPart"));
							printf("\nPart Master %s is related to the CED Part %s\n",itmid,cedPartNo);fflush(stdout);
		
						}
					}
				}
				
			}
			else
			{
				printf("\nNo CED Part . Need to create it...\n");fflush(stdout);
				tag_t newCedPart = NULLTAG;
				CALLAPI(createNewCEDCoatedPart(partRev, "ALL", &newCedPart))
				if(newCedPart!=NULLTAG)
				{
					//Relate this part to the 12 digit part. //No need to revise
					//CALLAPI(relatePrimaryWithSecondaryObj(partRev,newCedPart,"T5_HasSpareKit"));//sanjoy commenting - due to sparekit part relation validation issue - sco 404
					//Also relate this ced part with master.
					CALLAPI(relatePrimaryWithSecondaryObj(newCedPart,partMstr,"T5_SpareKitForPart"));
					
					//Add status
					CALLAPI(addStatusToTag(newCedPart,"ALL"));
				}				
				
			}
			
		}
		
		
		if(cedPartNo!=NULL)MEM_free(cedPartNo);
	}
	
	printf("\n\n*******************Finished CED PART CREATION LOGIC*********************************\n");fflush(stdout);
	return ifail;
}



int  tm_UpdateSpIndFunc(EPM_action_message_t  msg)
{
	int ifail = ITK_ok;
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	rootTask = NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	char* dmlNo = NULL;
	
	printf("\ntm_UpdateSpIndFunc function statrs....\n",username);fflush(stdout);
	POM_get_user(&username,&user_tag);
	printf("\nSAN:tm_UpdateSpIndFunc:username :%s....\n",username);fflush(stdout);
	
	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nSAN:tm_UpdateSpIndFunc:Root task found");fflush(stdout);
	
	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
	printf("\nSAN:tm_UpdateSpIndFunc:Current Task:%s\n",currentTaskName);fflush(stdout);
	
	if(tc_strcmp(currentTaskName, "Create CED Coated Parts") != 0 )
	{
		printf("\nSAN:tm_UpdateSpIndFunc:The Current Task is not Create CED Coated Parts ");fflush(stdout);
		//return ifail;
	}

	CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
	printf("\nSAN:tm_UpdateSpIndFunc:Parent Name:%s\n",parentTaskName);fflush(stdout);	
	
	if(tc_strcmp(parentTaskName, "Spare indicator updation WF") != 0 )//
	{
		printf("\nThe Life cycle is not Spare indicator updation WF ");fflush(stdout);
		//return ifail;
	}
	
	CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
	if(targetobjects_count > 0)
	{
		int i=0;
		tag_t objectTypeTag = NULLTAG;
		char  *type_name = NULL;
		char* dmlReleaseType = NULL;
		char* dmlRelTypeDisplayStr = NULL;
		tag_t dmlTag = NULLTAG;
		for(i=0;i<targetobjects_count;i++)
		{
			CALLAPI(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
			CALLAPI(TCTYPE_ask_name2( objectTypeTag, &type_name));
			printf("\nSAN:tm_UpdateSpIndFunc:type_name ==> %s\n", type_name);fflush(stdout);
			if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
			{
				CALLAPI(AOM_ask_value_string(targetobjects[i],"t5_rlstype",&dmlReleaseType));
				CALLAPI(AOM_UIF_ask_value(targetobjects[i],"t5_rlstype",&dmlRelTypeDisplayStr));
				printf("\nSAN:tm_UpdateSpIndFunc:DML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);	fflush(stdout);
				if(tc_strcmp(dmlReleaseType,"SPIUP")==0)
				{
					dmlTag=targetobjects[i];
					break;
				}
				
				
			}
		}
		if(dmlTag==NULLTAG)
		{
			printf("\nSAN:tm_UpdateSpIndFunc:Target Object is not ERC DML Revision or not of correct release type-SPIUP");fflush(stdout);
			return ifail;
		}
		
		CALLAPI(AOM_ask_value_string(dmlTag,"item_id",&dmlNo));
		printf("\nSAN:tm_UpdateSpIndFunc:Target Object is ERC DML Revision==>%s ",dmlNo);fflush(stdout);
		
		//Check for client live -if yes then execute client code.
		
		
		//get control object
		tag_t contrlObj = NULLTAG;
		logical flag = FALSE;
		char* userInfo8 = NULL;
		CALLAPI(isLiveForSPIndUpWF(&contrlObj,&flag)); //Check for CEDCreVl-CEDCreVl control object and flag true if userinfo4=Design
		
		printf("\nIs Live for Design class in SPIUP Release process: %d\n",flag);fflush(stdout);

		//Get userinfo8. If Client then execute the client code.
		if(contrlObj == NULLTAG)
		{
			printf("\nSAN:tm_UpdateSpIndFunc:NO Control object  CEDCreVl-CEDCreVl found. Skipping Spare Indicator Updation and CED creation process.Please contact Admin");fflush(stdout);
			return ifail;			
		}
		else
		{
			CALLAPI(AOM_ask_value_string(contrlObj,"t5_Userinfo8",&userInfo8));
			printf("\nSAN:tm_UpdateSpIndFunc:UserInfo8[%s]",userInfo8);fflush(stdout);
			
		}
		if(tc_strstr(userInfo8,"ClientSPUPD")!=NULL)
		{
			//Execute the client logic.
			printf("\nSAN:tm_UpdateSpIndFunc:Execute the client logic for SPIUP");fflush(stdout);
			
			tag_t CntrlTag = NULLTAG;
			logical res = FALSE;
			
			CALLAPI(getCtrlTagClientExec(&CntrlTag,&res));
			
			if(CntrlTag!=NULLTAG)
			{
				char* shellpath = NULL;
				char* sysCmnd = NULL;
				printf("\nIs Client execution control object found: %d\n",res);fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(CntrlTag,"t5_Userinfo1",&shellpath));
				
				printf("\nSAN:tm_UpdateSpIndFunc: \nshellpath[%s]\n",shellpath);fflush(stdout);
				
				sysCmnd=(char *) MEM_alloc(400);
				tc_strcpy(sysCmnd,shellpath);
				tc_strcat(sysCmnd," ");
				tc_strcat(sysCmnd,dmlNo);
			
				printf("\n Start-- Calling shell script using client system command: %s\n",sysCmnd);fflush(stdout);
				system(sysCmnd);
				
				printf("\n End --- Calling shell script using client system command: %s\n",sysCmnd);fflush(stdout);	
				
				MEM_free(sysCmnd);
				
			}
			else
			{
				printf("\nIs NO Client execution control object found: CedSpUpd-CedSpUpd %d\n",res);fflush(stdout);
			}
			
			
			
			
			
			
			
			
		}
		else
		{
			printf("\nSAN:tm_UpdateSpIndFunc:Execute the handler logic for SPIUP");fflush(stdout);
			//Get the DML task
			tag_t *dmlTaskTagObjects = NULL;
			tag_t dmlTaskTag = NULLTAG;
			int taskCnt = 0;
			CALLAPI(AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects));
			printf("\nSAN:tm_UpdateSpIndFunc:ERC Task Count:%d\n",taskCnt);fflush(stdout);
			
			if(taskCnt>0)
			{
				int i=0;
				char* object_type = NULL;
				tag_t* eligiblePartTagList = NULL;
				int cedpartCnt = 0;		

			
				for(i=0;i<taskCnt;i++)
				{
					dmlTaskTag = dmlTaskTagObjects[i];
					CALLAPI(AOM_ask_value_string(dmlTaskTag,"object_type",&object_type));
					printf("\nSAN:tm_UpdateSpIndFunc:object_type is :%s\n",object_type);fflush(stdout);
					if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
					{
						int partCnt=0;
						tag_t *partTagObjects = NULL;
						tag_t partTag = NULLTAG;
						char* dmlAnalystName = NULL;					
						
						CALLAPI(AOM_UIF_ask_value(dmlTaskTag,"Analyst",&dmlAnalystName));
						printf("\nDml Task Analyst_name:%s\n",dmlAnalystName);fflush(stdout);

						CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMReferences",&partCnt,&partTagObjects));
						printf("\nPart Count:%d\n",partCnt);fflush(stdout);
						
						if(partCnt>0)
						{
							int j=0;
							char* part_object_type = NULL;
							char* partNo = NULL;
							for(j=0;j<partCnt;j++)
							{
								partTag = partTagObjects[j];
								CALLAPI(AOM_ask_value_string(partTag,"object_type",&part_object_type));
								printf("\nobject_type of part is :%s\n",part_object_type);fflush(stdout);
								
								CALLAPI(AOM_ask_value_string(partTag,"item_id",&partNo));
								printf("\nItem ID:%s\n",partNo);fflush(stdout);
								
								if(flag && contrlObj!=NULLTAG)//For Design attached to Reference folder of dml task
								{
									if(tc_strcmp(part_object_type,"Design")==0)
									{
										//Get the eligible part revs that needed to be updated spare indicator.
										int cnt =0;
										tag_t* partListTag = NULL;
										tag_t partRevTag = NULLTAG;
										CALLAPI(getLatestReleasedAndWIPPart(partTag,&cnt, &partListTag))
										if(cnt>0)
										{
											int m = 0;
											char* partname = NULL;
											for(m=0;m<cnt;m++)
											{
												partRevTag = partListTag[m];
												CALLAPI(AOM_ask_value_string(partRevTag,"object_string",&partname));
												printf("\nSAN:tm_UpdateSpIndFunc: Latest Part1111: %s\n",partname);fflush(stdout);
												CALLAPI(tmUpdateSpareInd(partRevTag));//Update the spare indicator if true then update to false and vice versa
												//CALLAPI(tmUpdateSpareIndToTrue(partRevTag));//Update the spare indicator to true
												
												
											}
										}
										else
										{
											printf("\nSAN:CreCED: No eligible part rev found to be updated\n");fflush(stdout);
										}
										//Update of spare indicator finished.
										
									}
									
								}
								else//For Design Revision attached to reference folder of Dml task
								{
									if(tc_strcmp(part_object_type,"Design Revision")==0)
									{
										printf("\nSAN:tm_UpdateSpIndFunc: For design revion logic .. updating sp ind...\n");fflush(stdout);
										CALLAPI(tmUpdateSpareInd(partTag));
									}
								}							
								
								
							}


						}
						
						
					}
				}//End of for loop
				

			}
			
			//IMAN_reference
			
						
			
		}
		
		

	}
	
	return ifail;
}



int  tm_CreateCEDCoatPartforSpareIndUpdDmlFunc(EPM_action_message_t  msg)
{
	int ifail = ITK_ok;
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	rootTask = NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	char* dmlNo = NULL;
	
	printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc: Start of Handler tm_CreateCEDCoatPartforSpareIndUpdDmlFunc....\n",username);fflush(stdout);
	POM_get_user(&username,&user_tag);
	printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc: username :%s....\n",username);fflush(stdout);
	
	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:Root task found");fflush(stdout);
	
	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
	printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:Current Task:%s\n",currentTaskName);fflush(stdout);
	
	if(tc_strcmp(currentTaskName, "Create CED Coated Parts") != 0 )
	{
		printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:The Current Task is not Create CED Coated Parts ");fflush(stdout);
		//return ifail;
	}

	CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
	printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:Parent Name:%s\n",parentTaskName);fflush(stdout);	
	
	if(tc_strcmp(parentTaskName, "Spare indicator updation WF") != 0 )//
	{
		printf("\nThe Life cycle is not Spare indicator updation WF ");fflush(stdout);
		//return ifail;
	}
	
	CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
	if(targetobjects_count > 0)
	{
		int i=0;
		tag_t objectTypeTag = NULLTAG;
		char  *type_name = NULL;
		char* dmlReleaseType = NULL;
		char* dmlRelTypeDisplayStr = NULL;
		tag_t dmlTag = NULLTAG;
		for(i=0;i<targetobjects_count;i++)
		{
			CALLAPI(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
			CALLAPI(TCTYPE_ask_name2( objectTypeTag, &type_name));
			printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:type_name ==> %s\n", type_name);fflush(stdout);
			if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
			{
				CALLAPI(AOM_ask_value_string(targetobjects[i],"t5_rlstype",&dmlReleaseType));
				CALLAPI(AOM_UIF_ask_value(targetobjects[i],"t5_rlstype",&dmlRelTypeDisplayStr));
				printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:DML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);	fflush(stdout);
				if(tc_strcmp(dmlReleaseType,"SPIUP")==0)
				{
					dmlTag=targetobjects[i];
					break;
				}
				
				
			}
		}
		if(dmlTag==NULLTAG)
		{
			printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:Target Object is not ERC DML Revision or not of correct release type-SPIUP");fflush(stdout);
			return ifail;
		}
		
		CALLAPI(AOM_ask_value_string(dmlTag,"item_id",&dmlNo));
		printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:Target Object is ERC DML Revision==>%s ",dmlNo);fflush(stdout);
		
		
		//Check for client live -if yes then execute client code.
		
		
		//get control object
		tag_t contrlObj = NULLTAG;
		logical flag = FALSE;
		char* userInfo8 = NULL;
		CALLAPI(isLiveForSPIndUpWF(&contrlObj,&flag)); //Check for CEDCreVl-CEDCreVl control object and flag true if userinfo4=Design
		
		printf("\nIs Live for Design class in SPIUP Release process: %d\n",flag);fflush(stdout);

		//Get userinfo8. If Client then execute the client code.
		if(contrlObj == NULLTAG)
		{
			printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:NO Control object  CEDCreVl-CEDCreVl found. Skipping Spare Indicator Updation and CED creation process.Please contact Admin");fflush(stdout);
			return ifail;			
		}
		else
		{
			CALLAPI(AOM_ask_value_string(contrlObj,"t5_Userinfo8",&userInfo8));
			printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:UserInfo8[%s]",userInfo8);fflush(stdout);
			
		}
		if(tc_strstr(userInfo8,"ClientSPUPD")!=NULL)
		{
			//Execute the client logic.
			printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc: Already Executed the client logic for SPIUP. Exit the handler. Not required.");fflush(stdout);
			
			return ifail;
			
		}
		else
		{
			printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc: Execute the client handler logic tm_CreateCEDCoatPartforSpareIndUpdDmlFunc for SPIUP. .");fflush(stdout);
			//Get the DML task
			tag_t *dmlTaskTagObjects = NULL;
			tag_t dmlTaskTag = NULLTAG;
			int taskCnt = 0;
			CALLAPI(AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects));
			printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:ERC Task Count:%d\n",taskCnt);fflush(stdout);
			
			if(taskCnt>0)
			{
				int i=0;
				char* object_type = NULL;
				tag_t* eligiblePartTagList = NULL;
				int cedpartCnt = 0;	
				/* tag_t contrlObj = NULLTAG;	
				
				//get control object
				contrlObj = NULLTAG;
				logical flag = FALSE;
				
				
				CALLAPI(isLiveForSPIndUpWF(&contrlObj,&flag)); //check if control object is there and whethher to execute for Design
				printf("\nIs Live for Design class in SPIUP Release process: %d\n",flag);fflush(stdout); */
							
				for(i=0;i<taskCnt;i++)
				{
					dmlTaskTag = dmlTaskTagObjects[i];
					CALLAPI(AOM_ask_value_string(dmlTaskTag,"object_type",&object_type));
					printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:object_type is :%s\n",object_type);fflush(stdout);
					if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
					{
						int partCnt=0;
						tag_t *partTagObjects = NULL;
						tag_t partTag = NULLTAG;
						char* dmlAnalystName = NULL;					
						
						CALLAPI(AOM_UIF_ask_value(dmlTaskTag,"Analyst",&dmlAnalystName));
						printf("\nDml Task Analyst_name:%s\n",dmlAnalystName);fflush(stdout);

						CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMReferences",&partCnt,&partTagObjects));
						printf("\nPart Count:%d\n",partCnt);fflush(stdout);
						

						

						if(partCnt>0)
						{
							int j=0;
							char* part_object_type = NULL;
							char* partNo = NULL;
							for(j=0;j<partCnt;j++)
							{
								partTag = partTagObjects[j];
								CALLAPI(AOM_ask_value_string(partTag,"object_type",&part_object_type));
								printf("\nobject_type of part is :%s\n",part_object_type);fflush(stdout);
								
								CALLAPI(AOM_ask_value_string(partTag,"item_id",&partNo));
								printf("\nItem ID:%s\n",partNo);fflush(stdout);
								
								if(flag && contrlObj!=NULLTAG)
								{
									if(tc_strcmp(part_object_type,"Design")==0)
									{

										//Create CED coated parts for eligible parts
										tag_t partRevObj = NULLTAG;
										CALLAPI(queryLatestSTDReleasedPartForPlant(partNo,"Design","ALL",&partRevObj));
										if(partRevObj!=NULLTAG)
										{
											logical isValid = false;
											char* partname = NULL;
											CALLAPI(AOM_ask_value_string(partRevObj,"object_string",&partname));
											printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc: Latest STD Released Part: %s\n",partname);fflush(stdout);
											CALLAPI(isEligibleForCEDPartCreation(partRevObj,&isValid));
											//isValid = true;
											printf("\nSAN:CEDCre:: Is Eligible part for CED part creation====>%d\n",isValid);fflush(stdout);
											if(isValid)
											{
												printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:Part ADDED to eligible Part Set====>%s\n",partname);fflush(stdout);
												t5AddTagObjToSet(&cedpartCnt,&eligiblePartTagList,partRevObj); 	
											}
											else
											{
												printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:NOT VALID PART---Skipping part %s for CED part creation........\n",partname);fflush(stdout);
											}	
											
										}
										
										
									}								
								}
								else
								{
									if(tc_strcmp(part_object_type,"Design Revision")==0)
									{
										logical isValid = false;
										CALLAPI(isEligibleForCEDPartCreation(partTag,&isValid));
										printf("\nSAN:CEDCre:: Is Eligible part for CED part creation111====>%d\n",isValid);fflush(stdout);
										if(isValid)
										{
											printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:Part ADDED to eligible Part Set111====>%s\n",partNo);fflush(stdout);
											t5AddTagObjToSet(&cedpartCnt,&eligiblePartTagList,partTag); 	
										}
										else
										{
											printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:NOT VALID PART---Skipping part %s for CED part creation111........\n",partNo);fflush(stdout);
										}										
									}
								}

							}
						}
					}
				}//End of for loop
				
				printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:Eligible Part count for CED Part creation===>%d\n",cedpartCnt);fflush(stdout);
				logical flagCed = FALSE;
				char* userInfo5 = NULL;
				if(contrlObj !=NULLTAG)
				{
					CALLAPI(AOM_ask_value_string(contrlObj,"t5_Userinfo5",&userInfo5));
					printf("\nSAN:user info 5>%s\n",userInfo5);fflush(stdout);
					if(userInfo5==NULL) userInfo5="";
					if(tc_strstr(userInfo5,"YES")!=NULL)
					{
						flagCed = TRUE;
					}
				}
				printf("\nIs Live for Design class in SPIUP Release process and CED part create: %d\n",flagCed);fflush(stdout);			
				if(flagCed)
				{
					CALLAPI(creCEDCoatedParts(eligiblePartTagList,cedpartCnt));

				}
				
			}
			
			//IMAN_reference
			
			
		}
			
		
		
		

	}
	
	return ifail;
}



int isAllowedForCEDCreation(tag_t *contrlTag, logical *result)
{
	int ifail = ITK_ok;
	printf("\nCheck for control object CEDCreVl....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "CEDCreVl";
	qry_values[1] = "CEDCreVl";
	qry_values[2] = "FALSE";
		
	CALLAPI(QRY_find2("Control Objects...", &query));
	CALLAPI(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	printf("\n Control objects CEDCreVl: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* usrInfo2 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{
			char* cntrlStr = NULL;
			CALLAPI(AOM_ask_value_string(cntrlObj,"object_string",&cntrlStr));
			printf("\n Control object ===>%s", cntrlStr);fflush(stdout);
			
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&usrInfo2));
			printf("\n Control object user info 2 ===>%s", usrInfo2);fflush(stdout);
			if(tc_strstr(usrInfo2,"YES")!=NULL)
			{
				printf("\nLive for creating CED coated parts through lifecycle\n");fflush(stdout);
				*result = TRUE;
			}			
			*contrlTag = cntrlObj;
			
		}
		
	}
	//T5_ControlObject	
	
	return ifail;
}




int getRevisionRuleObject(char *revisionRuleName, tag_t *revisonRuleObj)
{
	int ifail = ITK_ok;
	int flagRevRule =0;
	//get the Revision Rule Object
	

	CALLAPI(CFM_find(revisionRuleName, revisonRuleObj));
	if (revisonRuleObj != NULL)
	{
		//printf("\nFind revRule\n");fflush(stdout);
		flagRevRule = 1;
		
	}
	
	//printf("\n flagRevRule=>[%d] ",flagRevRule);fflush(stdout);
	
	return ifail;
}

int getClosureRuleObject(char* closureRuleName,tag_t *closureRuleObj)
{
	int ifail = ITK_ok;
	PIE_scope_t scope;
	int closureTagCnt = 0;
	tag_t *closureTags = NULL;
	int flagClosureRule = 0;
	//get the Revision Rule Object
	


	scope=PIE_TEAMCENTER;
	CALLAPI(PIE_find_closure_rules2(closureRuleName,scope,&closureTagCnt,&closureTags));
	//printf("\n closureTagCnt:%d ..............",closureTagCnt);fflush(stdout);
	if(closureTagCnt==1)
	{
		*closureRuleObj=closureTags[0];
		flagClosureRule=1;
	}
	//printf("\n flagClosureRule=>[%d] ",flagClosureRule);fflush(stdout);
	
	return ifail;
}

int getBomViewRevObject(tag_t partRevObj,char* bvrName, tag_t* bomViewObj)
{
	int ifail = ITK_ok;
	const char	*prog_name 		="getBomViewRevObject";
	tag_t partMaster 		= NULLTAG;
	int n_bom_views         = 0;
	tag_t *bom_views        = NULL;
	tag_t viewObj 			= NULLTAG;
	tag_t view_type 		= NULLTAG;
	char* view_type_name = NULL;
	char* partNumber = NULL;
	char* partRev = NULL;
	if(partRevObj == NULLTAG)
	{
		//printf("\ngetBomViewRevObject: Part Object is NULLTAG\n");fflush(stdout);
		return ifail;
	}	
	// Get the Item from the revision
	CALLAPI(ITEM_ask_item_of_rev(partRevObj, &partMaster)); 
	
	//Get the tags of all bom views related to the Item.
	CALLAPI(ITEM_list_bom_views(partMaster, &n_bom_views, &bom_views ));
	CALLAPI(AOM_ask_value_string(partRevObj,"item_id",&partNumber));
	CALLAPI(AOM_ask_value_string(partRevObj,"item_revision_id",&partRev));
	//printf("\n Part number===>%s,%s\n",partNumber,partRev);fflush(stdout);	


	if(n_bom_views>0)
	{
		int j = 0;
		//printf("\nSAN: %s.%s having below bom views...\n", partNumber,partRev);fflush(stdout);
		for(j=0;j<n_bom_views;j++)
		{
			//Get the view type of the BOMView
			CALLAPI(PS_ask_bom_view_type(bom_views[j],&view_type))
			
			//Get the name of the view type
			CALLAPI(PS_ask_view_type_name(view_type, &view_type_name));
			//printf("\nView Type===>%s\n", view_type_name);fflush(stdout);
			
			
			if(tc_strcmp(view_type_name, bvrName) == 0 )
			{
				viewObj = bom_views[j];
				break;
			}						
		}
		*bomViewObj = viewObj;
		
	}
	return ifail;
	
}

int tmExpandPartAndGetCEDPartListsRecursive(tag_t partRevObj,int reqLevel,int *level,char* bvrViewName,tag_t partRevisionRule,char* closureRuleName,PartModel** partModelList, int * partModelListCnt)
{
	int ifail = ITK_ok;
	const char				*prog_name 		="tmExpandPartAndGetCEDPartListsRecursive";
	//printf("\nStart of tmExpandPartAndGetCEDPartListsRecursive....\n");fflush(stdout);
	
	//printf("\nSAN:level====>%d\n",*level);fflush(stdout);
	//printf("\nSAN: reqLevel====>%d\n",reqLevel);fflush(stdout);
	
	if(*level>=reqLevel)
	{
		return ifail;
	}
	char* partNumberStr = NULL;
	tag_t bomViewObj = NULLTAG;
	int flagBvr = 0;
	CALLAPI(AOM_ask_value_string(partRevObj,"item_id",&partNumberStr))
	//printf("\nSAN: partNumberStr====>%s\n",partNumberStr);fflush(stdout);
	CALLAPI(getBomViewRevObject(partRevObj,bvrViewName, &bomViewObj));
	if(bomViewObj != NULLTAG)
	{
		//printf("\n BOM View Obj not null........\n");fflush(stdout);
		flagBvr = 1;
	}
	else
	{
		flagBvr = 0;
	}
	//printf("\n flagBvr================>%d\n", flagBvr);fflush(stdout);
	
	tag_t closureRuleObj = NULLTAG;
	int flagClosureRule = 0;
	CALLAPI(getClosureRuleObject(closureRuleName,&closureRuleObj));
	if(closureRuleObj!=NULLTAG)
	{
		
		//printf("\n Closure Rule not null........\n");fflush(stdout);
		flagClosureRule = 1;
	}
	else
	{
		//printf("\n Closure Rule NULL........\n");fflush(stdout);
		flagClosureRule = 0;
	}
	
	//printf("\n flagClosureRule================>%d\n", flagClosureRule);fflush(stdout);
	
	tag_t window = NULLTAG;
	ITKCALL(BOM_create_window (&window));
	ITKCALL(BOM_set_window_config_rule(window,partRevisionRule));
	if(flagClosureRule ==1)
		ITKCALL(BOM_window_set_closure_rule(window,closureRuleObj,0,NULL,NULL));
	
	tag_t t_ItemTag 		= NULLTAG;
	tag_t top_line			= NULLTAG;
	tag_t  *childs		    = NULLTAG;
	int child_count         = 0;
	int i=0;
	if(flagBvr == 1)
	{
		CALLAPI(BOM_set_window_top_line(window, t_ItemTag,partRevObj ,bomViewObj, &top_line));
		CALLAPI(BOM_line_ask_child_lines (top_line, &child_count, &childs));
		//printf("\nNo of child objects are n : %d\n",child_count);fflush(stdout);
		
		*level = *level + 1;
		//tag_t childItemTag = NULLTAG;
		tag_t childItemRevObj = NULLTAG;
		char* partNumberStr1 = NULL;
		char* partNameStr = NULL;
		PartModel partMdl = NULL;
		//lineVectorLeaf = (BOMLineVector)malloc( sizeof(BOMLineVector ));

		for (i = 0; i< child_count; i++)
		{
			CALLAPI(BOM_line_unpack (childs[i]));
			CALLAPI(AOM_ask_value_tag(childs[i], "bl_revision", &childItemRevObj));
			if(childItemRevObj != NULLTAG)
			{
				
				CALLAPI(AOM_ask_value_string(childItemRevObj,"item_id",&partNumberStr1));
				//printf("\n partNumberStr1================>%s\n", partNumberStr1);fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(childItemRevObj,"object_string",&partNameStr));
				//printf("\n partNameStr================>%s\n", partNameStr);fflush(stdout);

				
				
				tag_t stdPartRevObj = NULLTAG;
				CALLAPI(queryLatestSTDReleasedPartForPlant(partNumberStr1,"Design","ALL",&stdPartRevObj));
				
				if(stdPartRevObj!=NULLTAG)
				{
					logical isValid = false;
					char* partname = NULL;
					CALLAPI(AOM_ask_value_string(stdPartRevObj,"object_string",&partname));
					//printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc: Latest STD Released Part: %s\n",partname);fflush(stdout);
					CALLAPI(isEligibleForCEDPartCreation(stdPartRevObj,&isValid));
					//isValid = true;
					//printf("\nSAN:CEDCre:: Is Eligible part for CED part creation====>%d\n",isValid);fflush(stdout);
					if(isValid)
					{
						//printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:Part ADDED to eligible Part Set====>%s\n",partname);fflush(stdout);
						partMdl = (PartModel)malloc(sizeof(PartModel));
						partMdl->level = *level;
						partMdl->childItemRev = stdPartRevObj;
						partMdl->childBomLine = childs[i];
					
						setAddPartModel(partModelListCnt, partModelList, partMdl);	
					}
					else
					{
						//printf("\nSANtm_CreateCEDCoatPartforSpareIndUpdDmlFunc:NOT VALID PART---Skipping part %s for CED part creation........\n",partname);fflush(stdout);
					}						

				}
				else
				{
					//printf("\nPart %s is not STD Released. So skipping this part...\n",partNameStr);fflush(stdout);
					//continue;
				}
				

				
				
				//printf("\n partModelListCnt from partmodel================>%d\n", *partModelListCnt);fflush(stdout);
				tmExpandPartAndGetCEDPartListsRecursive(childItemRevObj,reqLevel,level,bvrViewName,partRevisionRule,closureRuleName,partModelList, partModelListCnt);
			}
		}
		
		
		*level = *level - 1;
	}
	
	return ifail;
	
}

int tmExpandPartAndGetCEDPartLists(tag_t partRevObj, int reqLevel, PartModel** partModelList, int *partModelListCnt, char* bvrViewName, char * revisionRuleName, char* closureRuleName)
{
	int ifail = ITK_ok;
	const char				*prog_name 		="tmExpandPartAndGetCEDPartLists";
	printf("\nStart of tmExpandPartAndGetCEDPartLists......\n");fflush(stdout);
	int level = 0;
	tag_t bomViewObj = NULLTAG;
	int flagRevRule = 0;

	tag_t partRevisionRule = NULLTAG;
	//printf("\nRevision rule name:====>%s",revisionRuleName);fflush(stdout);
	CALLAPI(getRevisionRuleObject(revisionRuleName,&partRevisionRule));
	
	if(partRevisionRule !=NULLTAG)
	{
		//printf("\n Revision Rule not null........\n");fflush(stdout);
		flagRevRule = 1;
	}
	else
	{
		flagRevRule = 0;
	}
	
	//printf("\n flagRevRule============>[%d] ",flagRevRule);fflush(stdout);
	
		
	CALLAPI(getBomViewRevObject(partRevObj,bvrViewName, &bomViewObj));
	
	
	if(bomViewObj == NULLTAG)
	{
		//printf("\n BOM VIEW Revision does not exist........\n");fflush(stdout);
		return ifail;
	}
	else
	{
		if(flagRevRule == 1)
		{
			CALLAPI(tmExpandPartAndGetCEDPartListsRecursive(partRevObj,reqLevel,&level,bvrViewName,partRevisionRule,closureRuleName,partModelList, partModelListCnt));
		}
	}
	
	printf("\nEnd of tmExpandPartAndGetCEDPartLists......\n");fflush(stdout);
	
	return ifail;
}






int tmAutoCreateCEDCoatedPartsOfDmlNotUsed(tag_t dmlTag)
{
	int ifail = ITK_ok;
	
	printf("\nStart of tmAutoCreateCEDCoatedPartsOfDml......\n");fflush(stdout);
	//create on control object. If control obj is live then proceed.
	tag_t contrlObj = NULLTAG;
	logical flag = FALSE;
	
	//printf("\nLOGIC TO BE IMPLAMENTED..............\n");fflush(stdout);
	CALLAPI(isAllowedForCEDCreation(&contrlObj,&flag)); //If userinfo2 is YES for CEDCreVl
	printf("\nflag===>%d\n",flag);fflush(stdout);
	
	if(flag && contrlObj!=NULLTAG)
	{
		logical flag1 = FALSE;// set this value and implement later on some more properties of control object
		char* userInfo6 = NULL;
		CALLAPI(AOM_ask_value_string(contrlObj,"t5_Userinfo6",&userInfo6));
		if(userInfo6==NULL) userInfo6="";
		printf("\nUser info 6 of the control obj : %s\n",userInfo6);fflush(stdout);
		
		if(tc_strstr(userInfo6,"YES")!=NULL)
		{
			flag1 = TRUE;
			
		}
		
		
		printf("\nAuto CED part creation flag1:%d\n",flag1);fflush(stdout);
		
		if(flag1 && dmlTag!=NULLTAG)
		{
			printf("\nLIVE FOR CED CREATION in workflow....\n");fflush(stdout);
			int taskCnt = 0;
			tag_t* dmlTasks = NULL;
			tag_t taskTag = NULLTAG;
			char* dmlRlzType = NULL;
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlRlzType));
			printf("\n Release Type: %s\n",dmlRlzType);fflush(stdout);
			
			//get the dml task object
			CALLAPI(AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTasks));
			
			printf("\n No of Tasks of the DML is %d\n",taskCnt);fflush(stdout);
			if(taskCnt>0)
			{
				int i= 0;
				for(i=0;i<taskCnt;i++)
				{
					char* taskType = NULL;
					taskTag = dmlTasks[i];
					CALLAPI(AOM_ask_value_string(taskTag,"object_type",&taskType));
					printf("\n Class of Task is %s\n",taskType);fflush(stdout);
					
					if(tc_strcmp(taskType,"T5_ChangeTaskRevision")==0)
					{
						tag_t* eligiblePartTagList = NULL;
						int cedpartCnt = 0;	
						char* dmlAnalystName = NULL;
						CALLAPI(AOM_UIF_ask_value(taskTag,"Analyst",&dmlAnalystName));
						printf("\nDml Task Analyst_name:%s\n",dmlAnalystName);fflush(stdout);
						
						if(tc_strcmp(dmlRlzType,"Veh")==0)
						{
							printf("\nFor Vehicle Release DML .......\n");fflush(stdout);
							int partRevCnt =0;
							tag_t* partRevTags = NULL;
							CALLAPI(AOM_ask_value_tags(taskTag,"CMHasSolutionItem",&partRevCnt,&partRevTags));
							printf("\nPart Rev Count:%d\n",partRevCnt);fflush(stdout);
							
							if(partRevCnt>0)
							{
								int j =0; 
								int partModelListCnt = 0;
								PartModel * partModelList;
								for(j=0;j<partRevCnt; j++)
								{
									tag_t partRev = NULLTAG;
									char* partType = NULL;																	
									partRev = partRevTags[j];
									
									CALLAPI(AOM_ask_value_string(partRev,"object_type",&partType));
									if(tc_strcmp(partType,"Design Revision")==0)
									{
										tmExpandPartAndGetCEDPartLists(partRev,99, &partModelList, &partModelListCnt, "view", "Latest Working", "");
									}
									
								}
								
								int lvl = 0;
								int k=0;
								char* partNoStr =  NULL;
								tag_t partObj = NULLTAG;
								printf("\nEligible part list count: %d\n",partModelListCnt);fflush(stdout);
								for(k=0;k<partModelListCnt;k++)
								{
									//lvl = (*(partModelList[0] + i))->level; 
									lvl = partModelList[k]->level; 
									printf("\nlvl====>%d",lvl);fflush(stdout);
									partObj = partModelList[k]->childItemRev;
									CALLAPI(AOM_ask_value_string(partObj,"item_id",&partNoStr));
									printf(" partNoStr====>%s",partNoStr);fflush(stdout);
									
									t5AddTagObjToSet(&cedpartCnt,&eligiblePartTagList,partObj);
								}
								printf("\n");fflush(stdout);
								
							}
						}
						else if(tc_strcmp(dmlRlzType,"TODR")==0)
						{
							printf("\nFor Gate Maturation DML .......\n");fflush(stdout);
							int partRevCnt =0;
							tag_t* partRevTags = NULL;
							CALLAPI(AOM_ask_value_tags(taskTag,"CMReferences",&partRevCnt,&partRevTags));
							printf("\nPart Rev Count:%d\n",partRevCnt);fflush(stdout);
							
							if(partRevCnt>0)
							{
								int j =0; 
								int partModelListCnt = 0;
								PartModel * partModelList;
								for(j=0;j<partRevCnt; j++)
								{
									tag_t partRev = NULLTAG;
									char* partType = NULL;																	
									partRev = partRevTags[j];
									
									CALLAPI(AOM_ask_value_string(partRev,"object_type",&partType));
									if(tc_strcmp(partType,"Design Revision")==0)
									{
										tmExpandPartAndGetCEDPartLists(partRev,99, &partModelList, &partModelListCnt, "view", "Latest Working", "");
									}
									
								}
								
								int lvl = 0;
								int k=0;
								char* partNoStr =  NULL;
								tag_t partObj = NULLTAG;
								printf("\nEligible part list count: %d\n",partModelListCnt);fflush(stdout);
								for(k=0;k<partModelListCnt;k++)
								{
									//lvl = (*(partModelList[0] + i))->level; 
									lvl = partModelList[k]->level; 
									printf("\nlvl====>%d",lvl);fflush(stdout);
									partObj = partModelList[k]->childItemRev;
									CALLAPI(AOM_ask_value_string(partObj,"item_id",&partNoStr));
									printf(" partNoStr====>%s",partNoStr);fflush(stdout);
									
									t5AddTagObjToSet(&cedpartCnt,&eligiblePartTagList,partObj);
								}
								printf("\n");fflush(stdout);
															
							}
							
						}
						else if(tc_strcmp(dmlRlzType,"SCR")==0)
						{
							
							if(tc_strstr(userInfo6,"SCRLIVE")!=NULL)
							{
								printf("\nTO be implemented for SVR Cluster Release type DML .......\n");fflush(stdout);
								
								tag_t platformRevTag = NULLTAG;
								tag_t variantRuleTag = NULLTAG;
								int itemRevCnt =0;
								tag_t* itemRevTags = NULL;
								int j = 0;	
								int pltFormnCnt = 0;
								tag_t* platformRevTagList = NULL;
								int variantCnt =0;
								tag_t* variantRuleList=NULL;
									
								CALLAPI(AOM_ask_value_tags(taskTag,"CMReferences",&itemRevCnt,&itemRevTags));
								printf("\nItem  Rev Count in references folder of the task:%d\n",itemRevCnt);fflush(stdout);
								
								if(itemRevCnt>0)
								{
									for(j=0;j<itemRevCnt;j++)
									{
										tag_t itemRev = NULLTAG;
										char* itemType = NULL;																	
										itemRev = itemRevTags[j];
										CALLAPI(AOM_ask_value_string(itemRev,"object_type",&itemType));
										printf("\nItem Type:%s\n",itemType);fflush(stdout);
										if(tc_strcmp(itemType,"T5_PlatformRevision")==0)
										{
											
											t5AddTagObjToSet(&pltFormnCnt,&platformRevTagList,itemRev);
										}
										if(tc_strcmp(itemType,"VariantRule")==0)
										{
											t5AddTagObjToSet(&variantCnt,&variantRuleList,itemRev);
										}
											
									}
									
									printf("\npltFormnCnt==>%d\nvariantCnt==>%d\n",pltFormnCnt,variantCnt);fflush(stdout);
									if(pltFormnCnt>0 && variantCnt>0)
									{
										printf("\nGot Platform Revision and Variant Rule\n");fflush(stdout);
										platformRevTag = platformRevTagList[0];
										variantRuleTag = variantRuleList[0];
										
										
										if(platformRevTag!=NULLTAG && variantRuleTag!=NULLTAG)
										{
											char* platFormName = NULL;
											char* variantName = NULL;
											CALLAPI(AOM_ask_value_string(platformRevTag,"object_name",&platFormName));
											CALLAPI(AOM_ask_value_string(variantRuleTag,"object_name",&variantName));
											
											
											printf("\nPlatform Revision:%s\nVariant Rule:%s\n",platFormName,variantName);fflush(stdout);	
											
											//Get Revision Rule object
											tag_t   rule	=NULLTAG;
											int rulefound = 0;
											tag_t* closurerule = NULL;
											tag_t close_tag = NULLTAG;
											tag_t   bom_window=NULLTAG;
											tag_t   top_line=NULLTAG;
											PIE_scope_t scope;
											//tag_t   bom_variant_rule=NULLTAG;
											CALLAPI(getRevisionRuleObject("Latest Working",&rule));
											if(PIE_find_closure_rules2( "BOMLineskipforunconfigured",scope, &rulefound, &closurerule ));
											if (rulefound > 0)
											{
												close_tag = closurerule[0];
												printf ("closure rule found \n");fflush(stdout);
												// MEM_free(tags_found);
											}
											CALLAPI(BOM_create_window (&bom_window)); 
											CALLAPI(BOM_set_window_top_line(bom_window, NULLTAG, platformRevTag, NULLTAG, &top_line));
											CALLAPI(BOM_set_window_config_rule(bom_window, rule));
											if(close_tag!=NULLTAG) CALLAPI(BOM_window_set_closure_rule(bom_window,close_tag,0,NULL,NULL));
											char *vname = NULL;	
																					
											tag_t varrule_tags[]={variantRuleTag};
											CALLAPI(BOM_window_hide_variants (bom_window));
											CALLAPI(BOM_window_hide_unconfigured(bom_window));
											CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,varrule_tags))   ;
											CALLAPI(BOM_window_hide_variants (bom_window));
											CALLAPI(BOM_window_hide_unconfigured(bom_window));

											int var_list_count;
											tag_t *variant_rule_list=NULL;
											int rule_count=0;
											int k =0;
											tag_t   *bom_variant_rules=NULLTAG;
											BOM_window_ask_variant_rules(bom_window,&rule_count,&bom_variant_rules);

											printf("\n RULE COUNT===%d", rule_count); fflush(stdout);	
											for(k=0;k<rule_count;k++)
											{
												variantRuleTag=bom_variant_rules[k];
												CALLAPI(AOM_ask_value_string(variantRuleTag,"object_string", &vname));
												printf("\n VR2[%d]=%s",k,vname);fflush(stdout);
											}
											printf("\n After inside bom_window-----\n"); fflush(stdout);			
											int n_lines1;
											tag_t *lines;
											int x;
											char *parent_child=NULL;
											parent_child=(char *)MEM_alloc( 200 );
											if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
											printf("\n Child LIne1=%d",n_lines1);fflush(stdout);
											for(x=0;x<n_lines1;x++)
											{

												tag_t childline=lines[x];
												
											//	setAddTagP(&moduleTagList_cnt,&retModules,lines[x]);
												
												//retModules=lines;               //Returning the modules of CCV
												tag_t child_item;
												char *bl_item_id;
												char *bl_item_name=NULL;
												CALLAPI(AOM_ask_value_string(childline, "bl_item_item_id", &bl_item_id ));
												CALLAPI(AOM_ask_value_string(childline, "bl_item_object_name", &bl_item_name ));
												printf("\n [%d] bl_item_id1=%s bl_item_name==%s",x,bl_item_id,bl_item_name);fflush(stdout);
												
												//Sanjoy - TZ 1.52
												//tag_t childItemTag = NULLTAG;
												tag_t childItemRevObj = NULLTAG;
												CALLAPI(BOM_line_unpack (childline));
												CALLAPI(AOM_ask_value_tag(childline, "bl_revision", &childItemRevObj))
												
												if(childItemRevObj!=NULLTAG)
												{
													int j =0; 
													int partModelListCnt = 0;
													PartModel * partModelList;
													
													tag_t partRev = NULLTAG;
													char* partType = NULL;																	
													partRev = childItemRevObj;
													
													CALLAPI(AOM_ask_value_string(partRev,"object_type",&partType));
													if(tc_strcmp(partType,"Design Revision")==0)
													{
														tmExpandPartAndGetCEDPartLists(partRev,99, &partModelList, &partModelListCnt, "view", "Latest Working", "");
													}
													
													
													
													int lvl = 0;
													int k=0;
													char* partNoStr =  NULL;
													tag_t partObj = NULLTAG;
													printf("\nEligible part list count: %d\n",partModelListCnt);fflush(stdout);
													for(k=0;k<partModelListCnt;k++)
													{
														//lvl = (*(partModelList[0] + i))->level; 
														lvl = partModelList[k]->level; 
														printf("\nlvl====>%d",lvl);fflush(stdout);
														partObj = partModelList[k]->childItemRev;
														CALLAPI(AOM_ask_value_string(partObj,"item_id",&partNoStr));
														printf(" partNoStr====>%s",partNoStr);fflush(stdout);
														
														t5AddTagObjToSet(&cedpartCnt,&eligiblePartTagList,partObj);
													}
													printf("\n");fflush(stdout);													
												}
												
												
												//End Sanjoy												
												
												
												tag_t bom_window1;
												tag_t top_line1;
												int n_lines2;
												tag_t *lines2;
												if(BOM_line_ask_child_lines(childline, &n_lines2, &lines2));
												printf("\n Child LIne2=%d",n_lines2);fflush(stdout);
												int y;
												for(y=0;y<   n_lines2;y++)
												{

													tag_t childline2=lines2[y];
													char *bl_item_id2;
													CALLAPI(AOM_ask_value_string(childline2, "bl_item_item_id", &bl_item_id2 ));
													
													tc_strcpy(parent_child,"");
													tc_strcat(parent_child,bl_item_id);
													tc_strcat(parent_child,"-");
													tc_strcat(parent_child,bl_item_name);
													tc_strcat(parent_child,"#");
													tc_strcat(parent_child,bl_item_id2);
													
													//collection_add(&v, parent_child);
													
													//setAddStrP(&str_count,&bom_list,parent_child);
													
													//printf("\n[%d] bl_item_id2=%s %s",y,bl_item_id2, parent_child);fflush(stdout);
												}

											}											
											
										}
										else
										{
											printf("\nPlatform and Variant NULL Tag.. Check..\n");fflush(stdout);
										}

										
									}
									else
									{
										printf("\nCheck either Platform Revision or Variant Rule or both is not present in Reference folder.\n");fflush(stdout);
										return ifail;
									}
									
								}
								else
								{
									printf("\nPlatform Revision and Variant is not attached to the reference folder\n");fflush(stdout);
								}
								
								
								
								
							}
							else
							{
								printf("\nNot Live for SVR Cluster Release Type DML\n");fflush(stdout);
								return ifail;
							}
							
							
						}
						else
						{
							printf("\n%s is Not VALID RELEASE TYPE DML for CED PART CREATION.....\n",dmlRlzType);fflush(stdout);
						}
						
						printf("\nSAN:CEDCre111:Eligible Part count for CED Part creation===>%d\n",cedpartCnt);fflush(stdout);
						CALLAPI(creCEDCoatedParts(eligiblePartTagList,cedpartCnt));
						
					}
					else
					{
						printf("\n Task is not of type T5_ChangeTaskRevision. So Skip this...\n");fflush(stdout);
					}
					
					
				}
				
			}
			else
			{
				printf("\n No task is attached for the DML.ERROR\n");fflush(stdout);
			}
		}
		else
		{
			printf("\n NOT LIVE FOR CED CREATION or dml object is null. please check with admin\n");fflush(stdout);
		}
		
		
	}
	else
	{
		//NOT LIVE FOR CED CREATION in workflow....
		
		printf("\nNOT LIVE FOR CED CREATION in workflow....\n");fflush(stdout);
	}

	
	
	printf("\nEnd of tmAutoCreateCEDCoatedPartsOfDml......\n");fflush(stdout);
	return ifail;
}






int tmAutoCreateCEDCoatedPartsOfDml(tag_t dmlTag)
{
	int ifail = ITK_ok;
	
	printf("\nStart of tmAutoCreateCEDCoatedPartsOfDml......\n");fflush(stdout);
	//create on control object. If control obj is live then proceed.
	tag_t contrlObj = NULLTAG;
	logical flag = FALSE;
	
	//printf("\nLOGIC TO BE IMPLAMENTED..............\n");fflush(stdout);
	CALLAPI(isAllowedForCEDCreation(&contrlObj,&flag)); //If userinfo2 is YES for CEDCreVl
	printf("\nflag===>%d\n",flag);fflush(stdout);
	
	if(flag && contrlObj!=NULLTAG)
	{
		logical flag1 = FALSE;// set this value and implement later on some more properties of control object
		char* userInfo6 = NULL;
		CALLAPI(AOM_ask_value_string(contrlObj,"t5_Userinfo6",&userInfo6));
		if(userInfo6==NULL) userInfo6="";
		printf("\nUser info 6 of the control obj : %s\n",userInfo6);fflush(stdout);
		
		if(tc_strstr(userInfo6,"YES")!=NULL)
		{
			flag1 = TRUE;
			
		}
		
		
		printf("\nAuto CED part creation flag1:%d\n",flag1);fflush(stdout);
		
		if(flag1 && dmlTag!=NULLTAG)
		{
			printf("\nLIVE FOR CED CREATION in workflow....\n");fflush(stdout);
			int taskCnt = 0;
			tag_t* dmlTasks = NULL;
			tag_t taskTag = NULLTAG;
			char* dmlRlzType = NULL;
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlRlzType));
			printf("\n Release Type: %s\n",dmlRlzType);fflush(stdout);
			
			//get the dml task object
			CALLAPI(AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTasks));
			
			printf("\n No of Tasks of the DML is %d\n",taskCnt);fflush(stdout);
			if(taskCnt>0)
			{
				int i= 0;
				for(i=0;i<taskCnt;i++)
				{
					char* taskType = NULL;
					taskTag = dmlTasks[i];
					CALLAPI(AOM_ask_value_string(taskTag,"object_type",&taskType));
					printf("\n Class of Task is %s\n",taskType);fflush(stdout);
					
					if(tc_strcmp(taskType,"T5_ChangeTaskRevision")==0)
					{
						tag_t* eligiblePartTagList = NULL;
						int cedpartCnt = 0;	
						char* dmlAnalystName = NULL;
						CALLAPI(AOM_UIF_ask_value(taskTag,"Analyst",&dmlAnalystName));
						printf("\nDml Task Analyst_name:%s\n",dmlAnalystName);fflush(stdout);
						
						if(tc_strcmp(dmlRlzType,"Veh")==0)
						{
							printf("\nFor Vehicle Release DML .......\n");fflush(stdout);
							int partRevCnt =0;
							tag_t* partRevTags = NULL;
							CALLAPI(AOM_ask_value_tags(taskTag,"CMHasSolutionItem",&partRevCnt,&partRevTags));
							printf("\nPart Rev Count:%d\n",partRevCnt);fflush(stdout);
							
							if(partRevCnt>0)
							{
								int j =0; 
								int partModelListCnt = 0;
								PartModel * partModelList;
								for(j=0;j<partRevCnt; j++)
								{
									tag_t partRev = NULLTAG;
									char* partType = NULL;																	
									partRev = partRevTags[j];
									
									CALLAPI(AOM_ask_value_string(partRev,"object_type",&partType));
									if(tc_strcmp(partType,"Design Revision")==0)
									{
										tmExpandPartAndGetCEDPartLists(partRev,99, &partModelList, &partModelListCnt, "view", "Latest Working", "");
									}
									
								}
								
								int lvl = 0;
								int k=0;
								char* partNoStr =  NULL;
								tag_t partObj = NULLTAG;
								printf("\nEligible part list count: %d\n",partModelListCnt);fflush(stdout);
								for(k=0;k<partModelListCnt;k++)
								{
									//lvl = (*(partModelList[0] + i))->level; 
									lvl = partModelList[k]->level; 
									printf("\nlvl====>%d",lvl);fflush(stdout);
									partObj = partModelList[k]->childItemRev;
									CALLAPI(AOM_ask_value_string(partObj,"item_id",&partNoStr));
									printf(" partNoStr====>%s",partNoStr);fflush(stdout);
									
									t5AddTagObjToSet(&cedpartCnt,&eligiblePartTagList,partObj);
								}
								printf("\n");fflush(stdout);
								
							}
						}
						else if(tc_strcmp(dmlRlzType,"TODR")==0)
						{
							printf("\nFor Gate Maturation DML .......\n");fflush(stdout);
							
							int partCnt = 0;
							tag_t* partTags = NULL;
							
							printf("\nSAN:tm_createCedCoatedParts: For Gate Maturation DML logic\n");fflush(stdout);
							CALLAPI(AOM_ask_value_tags(taskTag,"CMReferences",&partCnt,&partTags))
							printf("\nSAN:tm_createCedCoatedParts: No of parts in the task : %d\n",partCnt);fflush(stdout);
							
							if(partCnt>0)
							{
								int iPrt =0;
								tag_t partTag = NULLTAG;
								char* sPartClass = NULL;
								char* sPartNo = NULL;
								char* sPartType = NULL;
								int partModelListCnt = 0;
								PartModel * partModelList;								
								
								for(iPrt=0;iPrt<partCnt;iPrt++)
								{
									if(iPrt>=1) continue;
									partTag = partTags[iPrt];
									CALLAPI(AOM_ask_value_string(partTag,"object_type",&sPartClass));
									printf("\nSAN:tm_createCedCoatedParts: Part Class: [%s]",sPartClass);fflush(stdout);
									
									if(tc_strcmp(sPartClass,"Design Revision")==0)
									{
										CALLAPI(AOM_ask_value_string(partTag,"item_id",&sPartNo));
										CALLAPI(AOM_ask_value_string(partTag,"t5_PartType",&sPartType));
										printf("SAN:tm_createCedCoatedParts: Part No[%s] Part Type: [%s]\n",sPartNo,sPartType);fflush(stdout);
										
										if(tc_strcmp(sPartType,"CCVC")==0)
										{
											tag_t CCVSnpSht_Rel_Type = NULLTAG;													
											tag_t* snapShotTags = NULL;
											int snpShtCnt = 0;
											tag_t snapShotTag = NULLTAG;
											tag_t snapShotTypeTag = NULLTAG;
											char   *snapShotTypeName = NULL;
											char* sSnapShotNo = NULL;
											tag_t  ModlRevTag = NULLTAG;
											tag_t snapBomWindow = NULLTAG;
											tag_t snapBOMlineTag = NULLTAG;
											int chldSnpBOMlineCnt = 0;
											tag_t* snpBomLineTags = NULL;
											int ar = 0;
											tag_t snpBomLineTag = NULLTAG;
											char* sArcModuleNo = NULL;
											tag_t ArcMdlNo_tag = NULLTAG;
											tag_t ArcMdlNo_tg = NULLTAG;													
											//if part type == CCVC then check for snapshot
											printf("\n %s is a CCVC vehicle-- Check for the snapshot\n", sPartNo);fflush(stdout);
											
											CALLAPI(GRM_find_relation_type("T5_PartHasSnapShot", &CCVSnpSht_Rel_Type));
											if(CCVSnpSht_Rel_Type!=NULLTAG)
											{
												snpShtCnt = 0;
												CALLAPI(GRM_list_secondary_objects_only(partTag,CCVSnpSht_Rel_Type,&snpShtCnt,&snapShotTags));
												printf("\n SAN:tm_createCedCoatedParts: No of Snapshots attached to ccvc[%s] is [%d]", sPartNo,snpShtCnt);fflush(stdout);
												
												if(snpShtCnt>0)
												{
													snapShotTag = snapShotTags[0];
													
													CALLAPI(TCTYPE_ask_object_type(snapShotTag,&snapShotTypeTag));
													CALLAPI(TCTYPE_ask_name2(snapShotTypeTag,&snapShotTypeName));
													printf("\n SAN:tm_createCedCoatedParts: snapShotTypeName:: [%s] \n",snapShotTypeName); fflush(stdout);
													
													if(tc_strcmp(snapShotTypeName,"Snapshot")==0)
													{
														CALLAPI(AOM_ask_value_string(snapShotTag,"object_name",&sSnapShotNo));
														printf("\n SAN:tm_createCedCoatedParts: SnapshotName:[%s]\n",sSnapShotNo);fflush(stdout);
														
														CALLAPI(AOM_ask_value_tag(snapShotTag,"topLine",&ModlRevTag));
														
														CALLAPI(BOM_create_window_from_snapshot(snapShotTag,&snapBomWindow));
														
														CALLAPI(BOM_set_window_top_line(snapBomWindow, NULLTAG, ModlRevTag, NULLTAG, &snapBOMlineTag));
														CALLAPI(BOM_line_ask_child_lines(snapBOMlineTag, &chldSnpBOMlineCnt, &snpBomLineTags));
														
														printf("\n SAN:tm_createCedCoatedParts: CCV Arch Node Count:%d:",chldSnpBOMlineCnt);fflush(stdout);
														
														for(ar =0 ; ar < chldSnpBOMlineCnt; ar++)
														{
															snpBomLineTag = snpBomLineTags[ar];
															CALLAPI(AOM_ask_value_string(snpBomLineTag,"bl_item_item_id",&sArcModuleNo));
															//printf("\n Arc_Node:%d:%d: sArcModuleNo:%s ......\n",chldSnpBOMlineCnt,ar,sArcModuleNo);fflush(stdout);
															ArcMdlNo_tag= t5GetItemRevisonCED(sArcModuleNo);
															if(ArcMdlNo_tag==NULLTAG)
															{
																printf("\n CCV:ArcMdlNo_tag is NULL.\n");fflush(stdout);
																//return 0;
															}
															else
															{
																CALLAPI((ITEM_ask_latest_rev (ArcMdlNo_tag, &ArcMdlNo_tg)));
																if(ArcMdlNo_tg==NULLTAG)
																{
																	printf("\n CCV:Object not found ArcMdlNo_tg...!!\n");fflush(stdout);
																	//return 0;
																}
																else
																{
																	//Get Modules from Arc Nodes
																	tag_t MdlBOMwindow = NULLTAG;
																	tag_t MdltagRule = NULLTAG;
																	int MdlCount = 0;
																	tag_t* POclosRul = NULL;
																	tag_t POcloseRul_tag = NULLTAG;
																	tag_t MdlBOMline = NULLTAG;
																	int MdlchildCount=0;
																	tag_t* MdlTopBLchildLine = NULL;
																	char* sPartNum = NULLTAG;
																	PIE_scope_t scope;
																	CALLAPI(BOM_create_window(&MdlBOMwindow));
																	CALLAPI(CFM_find("ERC release and above", &MdltagRule));
																	CALLAPI(BOM_set_window_config_rule( MdlBOMwindow, MdltagRule ))
																	CALLAPI(PIE_find_closure_rules2("BOMLineskipforunconfigured",scope, &MdlCount, &POclosRul ))
																	if (MdlCount > 0)
																	{
																		POcloseRul_tag = POclosRul[0];
																		//printf ("CCV: POcloseRul_tag closure rule found \n");fflush(stdout);
																	}
																	CALLAPI(BOM_window_set_closure_rule(MdlBOMwindow,POcloseRul_tag, 0, NULL,NULL ));
																	CALLAPI(BOM_set_window_top_line(MdlBOMwindow, NULLTAG, ArcMdlNo_tg, NULLTAG, &MdlBOMline))
																	CALLAPI(BOM_line_ask_child_lines(MdlBOMline, &MdlchildCount, &MdlTopBLchildLine))
																	printf("\n Arc_Node:%d:%d: sArcModuleNo:%s ",chldSnpBOMlineCnt,ar,sArcModuleNo);fflush(stdout);
																	printf("\t No of Module:%d ",MdlchildCount);fflush(stdout);
																	
																	CALLAPI(BOM_close_window(MdlBOMwindow));
																	
																	CALLAPI(AOM_ask_value_string(ArcMdlNo_tg,"item_id",&sPartNum));
																	printf("\t Part No to be expanded:%s ",sPartNum);fflush(stdout);
																	//tmExpandPartAndGetCEDPartLists(ArcMdlNo_tg,99, &partModelList, &partModelListCnt, "view", "ERC release and above", "BOMLineskipforunconfigured");
																	tmExpandPartAndGetCEDPartLists(ArcMdlNo_tg,99, &partModelList, &partModelListCnt, "view", "ERC release and above", "");
																	//tmExpandPartAndGetCEDPartLists(ArcMdlNo_tg,99, &partModelList, &partModelListCnt, "view", "Latest Working", "");
																	
																}
																
															}
															
															
														}
														
														
													}
													
													//tmExpandPartAndGetCEDPartLists(snapShotTag,99, &partModelList, &partModelListCnt, "view", "Latest Working", "");
													
													
												}
												else
												{
													//solve the bom - TODO
												}
												
											}
											else
											{
												//Solve the bom to get unit module - TODO
											}												
										}
																						
									}
									else
									{
										printf("\n SAN:tm_createCedCoatedParts: Part Class:[%s] is not Valid. Skip this part",sPartClass);fflush(stdout);
									}											
								}
								
								int lvl = 0;
								int k=0;
								char* partNoStr =  NULL;
								tag_t partObj = NULLTAG;
								printf("\nEligible part list count: %d\n",partModelListCnt);fflush(stdout);
								for(k=0;k<partModelListCnt;k++)
								{
									//lvl = (*(partModelList[0] + i))->level; 
									lvl = partModelList[k]->level; 
									printf("\nlvl====>%d",lvl);fflush(stdout);
									partObj = partModelList[k]->childItemRev;
									CALLAPI(AOM_ask_value_string(partObj,"item_id",&partNoStr));
									printf(" partNoStr====>%s",partNoStr);fflush(stdout);
									
									t5AddTagObjToSet(&cedpartCnt,&eligiblePartTagList,partObj);
								}
								printf("\n");fflush(stdout);								
							}
									
																
							
							
/* 							int partRevCnt =0;
							tag_t* partRevTags = NULLTAG;
							CALLAPI(AOM_ask_value_tags(taskTag,"CMReferences",&partRevCnt,&partRevTags));
							printf("\nPart Rev Count:%d\n",partRevCnt);fflush(stdout);
							
							if(partRevCnt>0)
							{
								int j =0; 
								int partModelListCnt = 0;
								PartModel * partModelList;
								for(j=0;j<partRevCnt; j++)
								{
									tag_t partRev = NULLTAG;
									char* partType = NULL;																	
									partRev = partRevTags[j];
									
									CALLAPI(AOM_ask_value_string(partRev,"object_type",&partType));
									if(tc_strcmp(partType,"Design Revision")==0)
									{
										tmExpandPartAndGetCEDPartLists(partRev,99, &partModelList, &partModelListCnt, "view", "Latest Working", "");
									}
									
								}
								
								int lvl = 0;
								int k=0;
								char* partNoStr =  NULL;
								tag_t partObj = NULLTAG;
								printf("\nEligible part list count: %d\n",partModelListCnt);fflush(stdout);
								for(k=0;k<partModelListCnt;k++)
								{
									//lvl = (*(partModelList[0] + i))->level; 
									lvl = partModelList[k]->level; 
									printf("\nlvl====>%d",lvl);fflush(stdout);
									partObj = partModelList[k]->childItemRev;
									CALLAPI(AOM_ask_value_string(partObj,"item_id",&partNoStr));
									printf(" partNoStr====>%s",partNoStr);fflush(stdout);
									
									t5AddTagObjToSet(&cedpartCnt,&eligiblePartTagList,partObj);
								}
								printf("\n");fflush(stdout);
															
							} */
							
						}
						else if(tc_strcmp(dmlRlzType,"SCR")==0)
						{
							
							if(tc_strstr(userInfo6,"SCRLIVE")!=NULL)
							{
								printf("\nTO be implemented for SVR Cluster Release type DML .......\n");fflush(stdout);
								
								tag_t platformRevTag = NULLTAG;
								tag_t variantRuleTag = NULLTAG;
								int itemRevCnt =0;
								tag_t* itemRevTags = NULL;
								int j = 0;	
								int pltFormnCnt = 0;
								tag_t* platformRevTagList = NULL;
								int variantCnt =0;
								tag_t* variantRuleList=NULL;
									
								CALLAPI(AOM_ask_value_tags(taskTag,"CMReferences",&itemRevCnt,&itemRevTags));
								printf("\nItem  Rev Count in references folder of the task:%d\n",itemRevCnt);fflush(stdout);
								
								if(itemRevCnt>0)
								{
									for(j=0;j<itemRevCnt;j++)
									{
										tag_t itemRev = NULLTAG;
										char* itemType = NULL;																	
										itemRev = itemRevTags[j];
										CALLAPI(AOM_ask_value_string(itemRev,"object_type",&itemType));
										printf("\nItem Type:%s\n",itemType);fflush(stdout);
										if(tc_strcmp(itemType,"T5_PlatformRevision")==0)
										{
											
											t5AddTagObjToSet(&pltFormnCnt,&platformRevTagList,itemRev);
										}
										if(tc_strcmp(itemType,"VariantRule")==0)
										{
											t5AddTagObjToSet(&variantCnt,&variantRuleList,itemRev);
										}
											
									}
									
									printf("\npltFormnCnt==>%d\nvariantCnt==>%d\n",pltFormnCnt,variantCnt);fflush(stdout);
									if(pltFormnCnt>0 && variantCnt>0)
									{
										printf("\nGot Platform Revision and Variant Rule\n");fflush(stdout);
										platformRevTag = platformRevTagList[0];
										variantRuleTag = variantRuleList[0];
										
										
										if(platformRevTag!=NULLTAG && variantRuleTag!=NULLTAG)
										{
											char* platFormName = NULL;
											char* variantName = NULL;
											CALLAPI(AOM_ask_value_string(platformRevTag,"object_name",&platFormName));
											CALLAPI(AOM_ask_value_string(variantRuleTag,"object_name",&variantName));
											
											
											printf("\nPlatform Revision:%s\nVariant Rule:%s\n",platFormName,variantName);fflush(stdout);	
											
											//Get Revision Rule object
											tag_t   rule	=NULLTAG;
											int rulefound = 0;
											tag_t* closurerule = NULL;
											tag_t close_tag = NULLTAG;
											tag_t   bom_window=NULLTAG;
											tag_t   top_line=NULLTAG;
											PIE_scope_t scope;
											//tag_t   bom_variant_rule=NULLTAG;
											CALLAPI(getRevisionRuleObject("Latest Working",&rule));
											if(PIE_find_closure_rules2( "BOMLineskipforunconfigured",scope, &rulefound, &closurerule ));
											if (rulefound > 0)
											{
												close_tag = closurerule[0];
												printf ("closure rule found \n");fflush(stdout);
												// MEM_free(tags_found);
											}
											CALLAPI(BOM_create_window (&bom_window)); 
											CALLAPI(BOM_set_window_top_line(bom_window, NULLTAG, platformRevTag, NULLTAG, &top_line));
											CALLAPI(BOM_set_window_config_rule(bom_window, rule));
											if(close_tag!=NULLTAG) CALLAPI(BOM_window_set_closure_rule(bom_window,close_tag,0,NULL,NULL));
											
											char *vname = NULL;												

											tag_t varrule_tags[]={variantRuleTag};
											CALLAPI(BOM_window_hide_variants (bom_window));
											CALLAPI(BOM_window_hide_unconfigured(bom_window));
											CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,varrule_tags))   ;
											CALLAPI(BOM_window_hide_variants (bom_window));
											CALLAPI(BOM_window_hide_unconfigured(bom_window));

											int var_list_count;
											tag_t *variant_rule_list=NULL;
											int rule_count=0;
											int k =0;
											tag_t   *bom_variant_rules=NULL;
											BOM_window_ask_variant_rules(bom_window,&rule_count,&bom_variant_rules);

											printf("\n RULE COUNT===%d", rule_count); fflush(stdout);	
											for(k=0;k<rule_count;k++)
											{
												variantRuleTag=bom_variant_rules[k];
												CALLAPI(AOM_ask_value_string(variantRuleTag,"object_string", &vname));
												printf("\n VR2[%d]=%s",k,vname);fflush(stdout);
											}
											printf("\n After inside bom_window-----\n"); fflush(stdout);			
											int n_lines1;
											tag_t *lines;
											int x;
											char *parent_child=NULL;
											parent_child=(char *)MEM_alloc( 200 );
											if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
											printf("\n Child LIne1=%d",n_lines1);fflush(stdout);
											for(x=0;x<n_lines1;x++)
											{

												tag_t childline=lines[x];
												
											//	setAddTagP(&moduleTagList_cnt,&retModules,lines[x]);
												
												//retModules=lines;               //Returning the modules of CCV
												tag_t child_item;
												char *bl_item_id;
												char *bl_item_name=NULL;
												CALLAPI(AOM_ask_value_string(childline, "bl_item_item_id", &bl_item_id ));
												CALLAPI(AOM_ask_value_string(childline, "bl_item_object_name", &bl_item_name ));
												printf("\n [%d] bl_item_id1=%s bl_item_name==%s",x,bl_item_id,bl_item_name);fflush(stdout);
												
												//Sanjoy - TZ 1.52
												//tag_t childItemTag = NULLTAG;
												tag_t childItemRevObj = NULLTAG;
												CALLAPI(BOM_line_unpack (childline));
												CALLAPI(AOM_ask_value_tag(childline, "bl_revision", &childItemRevObj))
												
												if(childItemRevObj!=NULLTAG)
												{
													int j =0; 
													int partModelListCnt = 0;
													PartModel * partModelList;
													
													tag_t partRev = NULLTAG;
													char* partType = NULL;																	
													partRev = childItemRevObj;
													
													CALLAPI(AOM_ask_value_string(partRev,"object_type",&partType));
													if(tc_strcmp(partType,"Design Revision")==0)
													{
														tmExpandPartAndGetCEDPartLists(partRev,99, &partModelList, &partModelListCnt, "view", "Latest Working", "");
													}
													
													
													
													int lvl = 0;
													int k=0;
													char* partNoStr =  NULL;
													tag_t partObj = NULLTAG;
													printf("\nEligible part list count: %d\n",partModelListCnt);fflush(stdout);
													for(k=0;k<partModelListCnt;k++)
													{
														//lvl = (*(partModelList[0] + i))->level; 
														lvl = partModelList[k]->level; 
														printf("\nlvl====>%d",lvl);fflush(stdout);
														partObj = partModelList[k]->childItemRev;
														CALLAPI(AOM_ask_value_string(partObj,"item_id",&partNoStr));
														printf(" partNoStr====>%s",partNoStr);fflush(stdout);
														
														t5AddTagObjToSet(&cedpartCnt,&eligiblePartTagList,partObj);
													}
													printf("\n");fflush(stdout);													
												}
												
												
												//End Sanjoy												
												
												
												tag_t bom_window1;
												tag_t top_line1;
												int n_lines2;
												tag_t *lines2;
												if(BOM_line_ask_child_lines(childline, &n_lines2, &lines2));
												printf("\n Child LIne2=%d",n_lines2);fflush(stdout);
												int y;
												for(y=0;y<   n_lines2;y++)
												{

													tag_t childline2=lines2[y];
													char *bl_item_id2;
													CALLAPI(AOM_ask_value_string(childline2, "bl_item_item_id", &bl_item_id2 ));
													
													tc_strcpy(parent_child,"");
													tc_strcat(parent_child,bl_item_id);
													tc_strcat(parent_child,"-");
													tc_strcat(parent_child,bl_item_name);
													tc_strcat(parent_child,"#");
													tc_strcat(parent_child,bl_item_id2);
													
													//collection_add(&v, parent_child);
													
													//setAddStrP(&str_count,&bom_list,parent_child);
													
													//printf("\n[%d] bl_item_id2=%s %s",y,bl_item_id2, parent_child);fflush(stdout);
												}

											}											
											
										}
										else
										{
											printf("\nPlatform and Variant NULL Tag.. Check..\n");fflush(stdout);
										}

										
									}
									else
									{
										printf("\nCheck either Platform Revision or Variant Rule or both is not present in Reference folder.\n");fflush(stdout);
										return ifail;
									}
									
								}
								else
								{
									printf("\nPlatform Revision and Variant is not attached to the reference folder\n");fflush(stdout);
								}
								
								
								
								
							}
							else
							{
								printf("\nNot Live for SVR Cluster Release Type DML\n");fflush(stdout);
								return ifail;
							}
							
							
						}
						else
						{
							printf("\n%s is Not VALID RELEASE TYPE DML for CED PART CREATION.....\n",dmlRlzType);fflush(stdout);
						}
						
						printf("\nSAN:CEDCre111:Eligible Part count for CED Part creation===>%d\n",cedpartCnt);fflush(stdout);
						CALLAPI(creCEDCoatedParts(eligiblePartTagList,cedpartCnt));
						
					}
					else
					{
						printf("\n Task is not of type T5_ChangeTaskRevision. So Skip this...\n");fflush(stdout);
					}
					
					
				}
				
			}
			else
			{
				printf("\n No task is attached for the DML.ERROR\n");fflush(stdout);
			}
		}
		else
		{
			printf("\n NOT LIVE FOR CED CREATION or dml object is null. please check with admin\n");fflush(stdout);
		}
		
		
	}
	else
	{
		//NOT LIVE FOR CED CREATION in workflow....
		
		printf("\nNOT LIVE FOR CED CREATION in workflow....\n");fflush(stdout);
	}

	
	
	printf("\nEnd of tmAutoCreateCEDCoatedPartsOfDml......\n");fflush(stdout);
	return ifail;
}




int isDR3PandAboveDML(tag_t dmlTag, logical *result)
{
	int ifail = ITK_ok;
	*result = FALSE;
	if(dmlTag != NULLTAG)
	{
		char* objTyp = NULL;
		CALLAPI(AOM_ask_value_string(dmlTag,"object_type",&objTyp));
		printf("\nDML object type: [%s]", objTyp);fflush(stdout);
		if(tc_strcmp(objTyp,"ChangeRequestRevision")==0)
		{
			char* relzType = NULL;
			char* dmlProjCode = NULL;
			char* plntToPlnt = NULL;
			char* dmlDrStatus = NULL;
			char* tagetPlant = NULL;
			
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&relzType));
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_cprojectcode",&dmlProjCode));
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_PlntToPlnt",&plntToPlnt));
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_cDRstatus",&dmlDrStatus));
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_TargetPlant",&tagetPlant));
			printf("\nRelease Type: %s\nDML Project Code: %s\nFromPlantToPlant: %s\nDml Dr Status:%s\nTarget Pant: %s\n",relzType,dmlProjCode,plntToPlnt,dmlDrStatus,tagetPlant);fflush(stdout);
			
			if(tc_strcmp(relzType,"TODR")==0)
			{
				
				if(plntToPlnt!=NULL)
				{
					if(tc_strcmp(plntToPlnt,"AR3 to AR3P")==0 || tc_strcmp(plntToPlnt,"DR3 to DR3P")==0  ||tc_strcmp(plntToPlnt,"AR3P to AR4")==0 || tc_strcmp(plntToPlnt,"DR3P to DR4")==0 || tc_strcmp(plntToPlnt,"DR3 to DR4")==0 || tc_strcmp(plntToPlnt,"AR3 to AR4")==0)
					{
						*result = TRUE;
					}
				}
				
			}
			else if(tc_strcmp(relzType,"Veh")==0 || tc_strcmp(relzType,"SCR")==0)
			{
				if(dmlDrStatus!=NULL)
				{
					if(tc_strcmp(dmlDrStatus,"DR3P")==0 || tc_strcmp(dmlDrStatus,"AR3P")==0 || tc_strcmp(dmlDrStatus,"DR4")==0 || tc_strcmp(dmlDrStatus,"AR4")==0 || tc_strcmp(dmlDrStatus,"DR5")==0 || tc_strcmp(dmlDrStatus,"AR5")==0)
					{
						*result = TRUE;
					}
				}
			}
			else
			{
				printf("\nThe DML Release Type is not Veh/TODR/SCR\n");fflush(stdout);
			}
			
		}
		else
		{
			printf("\nNot a valid DML Revision object\n");fflush(stdout);
		}
	}		
	
	
	return ifail;
}



int  tm_CreateCEDCoatedPartsFunc(EPM_action_message_t  msg)
{
	int ifail = ITK_ok;
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	rootTask = NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	char* dmlNo = NULL;
	char* userInfo7 = NULL;
	char* userInfo1 = NULL;
	
	//Check live for this action handler based on control object
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
	logical clientFlag = FALSE;
	CALLAPI(getControlObjForCEDandSPInd(&cntrlObj,&liveFlag)); //Check if control object CEDCreVl-CEDCreVl is present and returns TRUE
	
	printf("\nLive for Auto CED Part Creation for valid DML type==>%d\n",liveFlag);fflush(stdout);
	if(!liveFlag)
		return ifail;
	
	if(cntrlObj!=NULLTAG)
	{
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
		printf("\nUser Info 7 of the control object CEDCreVl-CEDCreVl is ===> %s\n",userInfo7);fflush(stdout);
		
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
		
		printf("\nUser Info 1 of the control object CEDCreVl-CEDCreVl is ===> %s\n",userInfo1);fflush(stdout); //For checking the release type
		if(userInfo1==NULL)
			userInfo1="";
		
		if(userInfo7!=NULL)
		{
			if(tc_strstr(userInfo7,"YES")!=NULL)
			{
				liveFlag =TRUE;
				if(tc_strstr(userInfo7,"CEDCLIENT")!=NULL)
				{
					clientFlag = TRUE;
				}
				
			}
			else
			{
				liveFlag = FALSE;
			}
		}
		else
		{
			liveFlag = FALSE;
		}
	}
	else
	{
		printf("\nNULL Control Object\n");fflush(stdout);
		liveFlag=FALSE;
	}
	
	
	
	printf("\nLive for Auto CED Part Creation ==>%d\n",liveFlag);fflush(stdout);
	
	if(!liveFlag)
	{
		printf("\n\n*******************************************8NOT LIVE for Auto CED Part Creation*****************************************************\n\n");fflush(stdout);
		return ifail;
	}
	
	printf("\nLive for Auto CED Part Creation through client code ==>%d\n",clientFlag);fflush(stdout);
	
	printf("\nSAN:CEDCre:Start of Handler tm_CreateCEDCoatedParts....\n",username);fflush(stdout);
	POM_get_user(&username,&user_tag);
	printf("\nSAN:CEDCre:username :%s....\n",username);fflush(stdout);
	
	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nSAN:CEDCre:Root task found");fflush(stdout);
	
	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
	printf("\nSAN:CEDCre:Current Task:%s\n",currentTaskName);fflush(stdout);
	


	CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
	printf("\nSAN:CEDCre:Parent Name:%s\n",parentTaskName);fflush(stdout);	
	

	
	CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
	if(targetobjects_count > 0)
	{
		int i=0;
		tag_t objectTypeTag = NULLTAG;
		char  *type_name = NULL;
		char* dmlReleaseType = NULL;
		char* dmlRelTypeDisplayStr = NULL;
		tag_t dmlTag = NULLTAG;
		for(i=0;i<targetobjects_count;i++)
		{
			CALLAPI(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
			CALLAPI(TCTYPE_ask_name2( objectTypeTag, &type_name));
			printf("\nSAN:CEDCre:type_name ==> %s\n", type_name);fflush(stdout);
			if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
			{
				CALLAPI(AOM_ask_value_string(targetobjects[i],"t5_rlstype",&dmlReleaseType));
				CALLAPI(AOM_UIF_ask_value(targetobjects[i],"t5_rlstype",&dmlRelTypeDisplayStr));
				printf("\nSAN:CEDCre:DML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);	fflush(stdout);
				//if(tc_strstr(dmlReleaseType,"Veh")==0 || tc_strcmp(dmlReleaseType,"SCR")==0  || tc_strcmp(dmlReleaseType,"TODR")==0) //‘Vehicle release’,’SVR cluster release ‘and ‘Gate maturation //Veh, SCR,TODR
				if(tc_strstr(userInfo1,dmlReleaseType)!=NULL)
				{
					dmlTag=targetobjects[i];
					break;
				}
				
				
			}
		}
		if(dmlTag==NULLTAG)
		{
			printf("\nSAN:CEDCre:Target Object is not ERC DML Revision or Release Type of DML is not Veh, SCR or TODR ");fflush(stdout);
			return ifail;
		}
		
		
		
		CALLAPI(AOM_ask_value_string(dmlTag,"item_id",&dmlNo));
		printf("\nSAN:CEDCre:Target Object is ERC DML Revision==>%s ",dmlNo);fflush(stdout);
		
		
		
		
		
		
		
		

		if(clientFlag)
		{
			printf("\nExecute through client code......\n");fflush(stdout);
			tag_t CntrlTag = NULLTAG;
			logical res = FALSE;
			char* shellpath = NULL;

			char* sysCmnd = NULL;
			char* dmlNmb = NULL;
			logical delInd = TRUE;
			
			CALLAPI(getControlObjForClientExec(&CntrlTag,&res));
			printf("\nIs run allowed though client==>%d\n",res);fflush(stdout);
			if(res && CntrlTag!=NULLTAG)
			{
				printf("\nValid control object FOUND CedPrtCre-CedPrtCre. Ready to GO!!!!! \n");fflush(stdout);
				
				CALLAPI(AOM_ask_value_logical(CntrlTag,"t5_DelInd",&delInd));
				printf("\nDelete Indicator==>%d\n",delInd);fflush(stdout);
				
				if(!delInd)
				{
					CALLAPI(AOM_ask_value_string(dmlTag,"item_id",&dmlNmb));
					CALLAPI(AOM_ask_value_string(CntrlTag,"t5_Userinfo1",&shellpath));

					
					sysCmnd=(char *) MEM_alloc(400);
					tc_strcpy(sysCmnd,shellpath);
					tc_strcat(sysCmnd," ");
					tc_strcat(sysCmnd,dmlNmb);
					printf("\n Start-- Calling shell file tm_createCedCoatedParts.sh using client system command: %s\n",sysCmnd);fflush(stdout);
					system(sysCmnd);
					
					printf("\n End --- Calling shell file tm_createCedCoatedParts.sh using client system command: %s\n",sysCmnd);fflush(stdout);
					
					MEM_free(sysCmnd);
					
				}
				else
				{
					printf("\nNot Live for Client execution--- delete indicator of CedPrtCre-CedPrtCre====>%d\n",delInd);fflush(stdout);
				}
				

				
				
			}
			else
			{
				printf("\n No Valid control object found CedPrtCre-CedPrtCre \n");fflush(stdout);
			}
			
			
		}
		else
		{
			logical drFlg = false;
			CALLAPI(isDR3PandAboveDML(dmlTag,&drFlg));
			printf("\nDR flag for creating CED coated parts: %d\n",drFlg);fflush(stdout);
			
			if(drFlg)
			{
				printf("\nExecute through API tmAutoCreateCEDCoatedPartsOfDml......\n");fflush(stdout);
				CALLAPI(tmAutoCreateCEDCoatedPartsOfDml(dmlTag));
			}
			
			else
			{
				printf("\nNot Valid DR state of the DML %s for creation of CED coated parts.. Exiting....\n", dmlNo);fflush(stdout);
			}
		}
			
		

		
		printf("\nEND of tm_CreateCEDCoatedPartsFunc.........\n");fflush(stdout);
		//IMAN_reference
		
		
	}
	
	return ifail;
}





int tmCEDCoatedPartUserServ(void *retValue)
{
	printf("\n SAN:CED Service:Start----tmCEDCoatedPartUserServ....\n");fflush(stdout);
	
	const char	*prog_name 	="CEDCoatedPartUserServ";
	
	int ifail = ITK_ok;
	int array_size = 0;
	tag_t* tag_array = NULL;
	USERSERVICE_array_t 	array_struct;
	
	tag_t dmlRevTag = NULLTAG;
	USERARG_get_tag_argument(&dmlRevTag);
	
	logical  result = false;
	
	if(dmlRevTag !=NULLTAG)
	{
		CALLAPI(isDR3PandAboveDML(dmlRevTag, &result));
		printf("\nIs DR 4 and above DML: %d\n",result);fflush(stdout);
		
		if(result)
		{
			char* dmlNumber = NULL;
		
			CALLAPI(AOM_ask_value_string(dmlRevTag,"object_string",&dmlNumber))
			printf("\nSAN:CED Serv:DML Revison selected =====>%s\n",dmlNumber);
			
			CALLAPI(tmAutoCreateCEDCoatedPartsOfDml(dmlRevTag));
		}

					
	}
	//printf("After returning Value\n");fflush(stdout);	
	printf("\n SAN:CED Service:End----tmCEDCoatedPartUserServ....\n");fflush(stdout);
	return ifail;	
	
}


int CEDCoatedPartUserServ(void *retValue)
{
	printf("\n SAN:CEDCoatedPartUserServ:Start----CEDCoatedPartUserServ....\n");fflush(stdout);
	
	const char	*prog_name 	="CEDCoatedPartUserServ";
	
	int ifail = ITK_ok;
	int array_size = 0;
	tag_t* tag_array = NULL;
	USERSERVICE_array_t 	array_struct;
	
	tag_t partRevTag = NULLTAG;
	USERARG_get_tag_argument(&partRevTag);
	
	logical  result = false;
	if(partRevTag !=NULLTAG)
	{
		char* partNumber = NULL;
		CALLAPI(AOM_ask_value_string(partRevTag,"object_string",&partNumber))
		printf("\nSAN:CEDCoatedPartUserServ:Part Number=====>%s\n",partNumber);
		
		tag_t dataSetTag = NULLTAG;
		USERARG_get_tag_argument(&dataSetTag);
		if(dataSetTag!=NULLTAG)
		{
			char* datasetnameStr = NULL;
			CALLAPI(AOM_ask_value_string(dataSetTag,"object_string",&datasetnameStr));
			printf("\n dataset %s ........................\n",datasetnameStr);fflush(stdout);
			//CALLAPI(AOM_delete_from_parent(dataSetTag,dmlTag))
			//printf("\n deleting dataset %s is COMPLETED........................\n",datasetnameStr);fflush(stdout);
		}
		
		logical isValid = TRUE;
		

		CALLAPI(isEligibleForCEDPartCreation(partRevTag,&isValid));	
		printf("\nSAN:CEDCoatedPartUserServ: Is Eligible part for CED part creation====>%d\n",isValid);fflush(stdout);
		//For testing
		//isValid = TRUE;
		if(!isValid)
		{
			printf("\nSAN:CEDCoatedPartUserServ:NOT VALID PART---Skipping part %s for CED part creation........\n",partNumber);fflush(stdout);
		}
		else
		{
			tag_t newCedPrtTag = NULLTAG;
			CALLAPI(createNewCEDCoatedPart(partRevTag,"ALL",&newCedPrtTag))
										
			//Stamp APL Working status
			CALLAPI(addStatusToTag(newCedPrtTag,"ALL"));
		}
		
	}
	//printf("After returning Value\n");fflush(stdout);	
	printf("\n SAN:CEDCoatedPartUserServ:End----CEDCoatedPartUserServ....\n");fflush(stdout);
	return ifail;	
	
}



/*Start - ESO - CR-FY22-0049*/

int isESODmlDR4andAboveDML(tag_t dmlTag, logical *result)
{
	int ifail = ITK_ok;
	*result = FALSE;
	if(dmlTag != NULLTAG)
	{
		char* objTyp = NULL;
		CALLAPI(AOM_ask_value_string(dmlTag,"object_type",&objTyp));
		printf("\nESO:DML object type: [%s]", objTyp);fflush(stdout);
		if(tc_strcmp(objTyp,"ChangeRequestRevision")==0)
		{
			char* relzType = NULL;
			char* plntToPlnt = NULL;
			char* dmlDrStatus = NULL;
			
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&relzType));
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_PlntToPlnt",&plntToPlnt));
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_cDRstatus",&dmlDrStatus));
			printf("\nESO:Release Type: %s\nESO:FromPlantToPlant: %s\nESO:Dml Dr Status:%s\n",relzType,plntToPlnt,dmlDrStatus);fflush(stdout);
			
			if(tc_strcmp(relzType,"TODR")==0)
			{
				
				if(plntToPlnt!=NULL)
				{
					if(tc_strcmp(plntToPlnt,"AR3 to AR4")==0 || tc_strcmp(plntToPlnt,"DR3 to DR4")==0  ||tc_strcmp(plntToPlnt,"AR3P to AR4")==0 || tc_strcmp(plntToPlnt,"DR3P to DR4")==0 )
					{
						*result = TRUE;
					}
				}
				
			}
			else 
			{
				if(dmlDrStatus!=NULL)
				{
					if(tc_strcmp(dmlDrStatus,"DR4")==0 || tc_strcmp(dmlDrStatus,"AR4")==0 || tc_strcmp(dmlDrStatus,"DR5")==0 || tc_strcmp(dmlDrStatus,"AR5")==0)
					{
						*result = TRUE;
					}
				}
			}

			
		}
		else
		{
			printf("\nNot a valid DML Revision object\n");fflush(stdout);
		}
	}		
	
	
	return ifail;
}




int isLiveForESOReview(tag_t *contrlTag, logical *result)
{
	int ifail = ITK_ok;
	printf("\nESO: Check for control object ESOREV....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "ESOREV";
	qry_values[1] = "ESOREV";
	qry_values[2] = "FALSE";
		
	CALLAPI(QRY_find2("Control Objects...", &query));
	CALLAPI(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	printf("\nESO:Control objects ESOREV: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		//char* usrInfo3 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{
			char* cntrlStr = NULL;
			CALLAPI(AOM_ask_value_string(cntrlObj,"object_string",&cntrlStr));
			printf("\nESO: Control object ===>%s", cntrlStr);fflush(stdout);
						
			*result = TRUE;
			*contrlTag = cntrlObj;
			printf("\nESO: Live for ESO Status Review parts through lifecycle\n");fflush(stdout);
			
		}
		
	}
	
	return ifail;
}


int  tm_CheckApplicableForESORevFun(EPM_action_message_t  msg)
{
	int ifail = ITK_ok;

	const char * prog_name ="tm_CheckApplicableForESOReviewFn";
	char*	username 	=	NULL;
	tag_t	user_tag	=	NULLTAG;
	tag_t	rootTask	= NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
	
	CALLAPI(isLiveForESOReview(&cntrlObj,&liveFlag)); //Check if control object CEDCreVl-CEDCreVl is present and returns TRUE
	
	printf("\nESO: Live for ESO Review for valid DML type==>%d\n",liveFlag);fflush(stdout);	
	if(!liveFlag)
	{
		printf("\nESO: NOT Live for ESO Review- Check for control object ESOREV");fflush(stdout);
		return ifail;
	}
	if(cntrlObj != NULLTAG && liveFlag)
	{
		POM_get_user(&username,&user_tag);
		printf("\nESO: Starting for username :%s....\n",username);fflush(stdout);
		
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		printf("\nESO: Root task found");fflush(stdout);
		
		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
		printf("\nESO: Current Task:%s\n",currentTaskName);fflush(stdout);

		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
		printf("\nESO: Parent Name:%s\n",parentTaskName);fflush(stdout);	
		
		CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
		
		if(targetobjects_count > 0)
		{
			int i =0;
			tag_t objectTypeTag = NULLTAG;
			char *type_name = NULL;
			char* dmlReleaseType = NULL;			
			char* dmlRelTypeDisplayStr = NULL;
			char* dmlBusUnit	=	NULL;
			char* dmlBusUnitStr	=	NULL;
			char* userInfo1	=	NULL;
			char* userInfo2	= NULL;
			char* userInfo3	=	NULL;
			char* userInfo4	=	NULL;
			char* userInfo5	=	NULL;
			
			
			
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
			
			printf("\nESORev Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5);fflush(stdout);
			
			for(i=0;i<targetobjects_count;i++)
			{
				CALLAPI(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
				CALLAPI(TCTYPE_ask_name2( objectTypeTag, &type_name));
				printf("\nESO: type_name ==> %s\n", type_name);fflush(stdout);
				
				if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
				{
					tag_t dmlTag = NULLTAG;
					dmlTag = targetobjects[i];
					
					CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlReleaseType));
					CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_rlstype",&dmlRelTypeDisplayStr));
					CALLAPI(AOM_ask_value_string(dmlTag,"t5_ERCBusiUt",&dmlBusUnit));
					CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_ERCBusiUt",&dmlBusUnitStr));
					
					printf("\nESO: DML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);fflush(stdout);
					printf("\nESO: DML Business Unit:%s===>%s\n",dmlBusUnit,dmlBusUnitStr);fflush(stdout);
					
					char* dmlBusUnitS = NULL;
					dmlBusUnitS = (char*)MEM_alloc(200);
					tc_strcpy(dmlBusUnitS,",");
					tc_strcat(dmlBusUnitS,dmlBusUnit);
					tc_strcat(dmlBusUnitS,",");
					printf("\nESO: dmlBusUnitS:%s\n",dmlBusUnitS);fflush(stdout);
					if(tc_strstr(userInfo1,dmlBusUnitS)!=NULL)
					{
						//if((tc_strcmp(dmlReleaseType,"Veh")==0))
						if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);	
						if(tc_strstr(userInfo2,dmlReleaseType)!=NULL)
						{
							printf("\nESO: DML Release Type %s is valid for ESO sign off step", dmlRelTypeDisplayStr);fflush(stdout);
							 
							logical  result = false;							
							
							CALLAPI(isESODmlDR4andAboveDML(dmlTag, &result));
							printf("\nESO: Is DR 4 and above DML: %d\n",result);fflush(stdout);
							//result =true;
							if(result)
							{
								//If TODR dml then check it is migrating vehicle/CCV  or Engine Module
								
								//Get the DML task
								tag_t *dmlTaskTagObjects = NULL;
								tag_t dmlTaskTag = NULLTAG;
								int taskCnt = 0;								
								CALLAPI(AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects));
								printf("\nESO: DML ERC Task Count:%d\n",taskCnt);fflush(stdout);
								
								if(taskCnt>0)
								{
									int j=0;
									char* object_type	=	NULL;
									
									for(j=0;j<taskCnt;j++)
									{
										dmlTaskTag = dmlTaskTagObjects[j];
										CALLAPI(AOM_ask_value_string(dmlTaskTag,"object_type",&object_type));
										printf("\nESO: DML Task object_type is :%s\n",object_type);fflush(stdout);
										
										if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
										{
											int partCnt=0;
											tag_t *partTagObjects = NULL;
											tag_t partTag = NULLTAG;
											CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMReferences",&partCnt,&partTagObjects));
											//CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMHasSolutionItem",&partCnt,&partTagObjects));
											printf("\nESO:Part Count:%d\n",partCnt);fflush(stdout);
											
											if(partCnt>0)
											{
												int p=0;
												char* part_object_type = NULL;
												char* partNo = NULL;
												char* partType = NULL;
												
												for(p=0;p<partCnt;p++)
												{
													partTag = partTagObjects[p];
													CALLAPI(AOM_ask_value_string(partTag,"object_type",&part_object_type));
													printf("\nESO: object_type of part is :%s\n",part_object_type);fflush(stdout);
													
													if(tc_strcmp(part_object_type,"Design Revision")==0)
													{
														CALLAPI(AOM_ask_value_string(partTag,"item_id",&partNo));
														printf("\nESO: Item ID:%s\n",partNo);fflush(stdout);
														//t5_PartType
														
														CALLAPI(AOM_ask_value_string(partTag,"t5_PartType",&partType));
														printf("\nESO: Part Type of the part:%s\n",partType);fflush(stdout);
														
														if(tc_strcmp(userInfo4,partType) == 0 || tc_strcmp(partType,"V")==0 || tc_strcmp(partType,"CCVC")==0 || tc_strcmp(partType,"VCCR")==0)
														{
															printf("\nESO: Vehicle: APPLICABLE FOR ESO STEP");fflush(stdout);
															ifail = sendESOStatusMail(dmlTag);//For sending Mail
															ifail = 1001;
															return ifail; //Go to error path
														}
														else if(tc_strcmp(partType,"M")==0 || tc_strcmp(partType,"T")==0)//CR-FY24-0033 - For Part Type Module and Design Group 00, 26
														{
															printf("\nESO: Part Type Module");fflush(stdout);
															char* desGrp = NULL;
															ifail = AOM_ask_value_string(partTag,"t5_DesignGrp",&desGrp);
															printf("\nESO: Design Group: %s\n", desGrp);fflush(stdout);
															if(tc_strcmp(desGrp,"00")==0 || tc_strcmp(desGrp,"26")==0)
															{
																printf("\nESO: Module : APPLICABLE FOR ESO STEP");fflush(stdout);
																ifail = sendESOStatusMail(dmlTag);//For sending Mail
																ifail = 1001;
																return ifail; //Go to error path
															}
														}
														
													}
													
													
													
													
												}
											}
											
											
										}
										
										
									}
								}
								
								
								
								
								
								
								
							
							}
							else
							{
								printf("\nESO: Not a DR 4 and above DML: ESO step not applicable");fflush(stdout);
							}
							
							
							

						}						
					}
					else
					{
						if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);
						printf("\nESO: Not Valid Business Unit.Not applicable for ESO");fflush(stdout);
					}
					
					
				}
			}
		}	
				
	}

	if(ifail!=0)
	{
		printf("\nESO: Valid to go to ESO Sign off Step");fflush(stdout);
	}
	else
	{
		printf("\nESO: DML not applicable for ESO Step");fflush(stdout);
	}
	
	return ifail;
	
}




int  tm_CheckApplicableForESODevFun(EPM_action_message_t  msg)
{
	int ifail = ITK_ok;

	const char * prog_name ="tm_CheckApplicableForESODevFun";
	char*	username 	=	NULL;
	tag_t	user_tag	=	NULLTAG;
	tag_t	rootTask	= NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
	
	CALLAPI(isLiveForESOReview(&cntrlObj,&liveFlag)); //Check if control object CEDCreVl-CEDCreVl is present and returns TRUE
	
	printf("\nESO: Live for ESO Review for valid DML type==>%d\n",liveFlag);fflush(stdout);	
	if(!liveFlag)
	{
		printf("\nESO: NOT Live for ESO Review- Check for control object ESOREV");fflush(stdout);
		return ifail;
	}
	if(cntrlObj != NULLTAG && liveFlag)
	{
		POM_get_user(&username,&user_tag);
		printf("\nESO: Starting for username :%s....\n",username);fflush(stdout);
		
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		printf("\nESO: Root task found");fflush(stdout);
		
		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
		printf("\nESO: Current Task:%s\n",currentTaskName);fflush(stdout);

		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
		printf("\nESO: Parent Name:%s\n",parentTaskName);fflush(stdout);	
		
		CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
		
		if(targetobjects_count > 0)
		{
			int i =0;
			tag_t objectTypeTag = NULLTAG;
			char *type_name = NULL;
			char* dmlReleaseType = NULL;			
			char* dmlRelTypeDisplayStr = NULL;
			char* dmlBusUnit	=	NULL;
			char* dmlBusUnitStr	=	NULL;
			char* userInfo1	=	NULL;
			char* userInfo2	= NULL;
			char* userInfo3	=	NULL;
			char* userInfo4	=	NULL;
			char* userInfo5	=	NULL;
			
			
			
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
			
			printf("\nESORev Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5);fflush(stdout);
			
			for(i=0;i<targetobjects_count;i++)
			{
				CALLAPI(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
				CALLAPI(TCTYPE_ask_name2( objectTypeTag, &type_name));
				printf("\nESO: type_name ==> %s\n", type_name);fflush(stdout);
				
				if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
				{
					tag_t dmlTag = NULLTAG;
					dmlTag = targetobjects[i];
					
					CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlReleaseType));
					CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_rlstype",&dmlRelTypeDisplayStr));
					CALLAPI(AOM_ask_value_string(dmlTag,"t5_ERCBusiUt",&dmlBusUnit));
					CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_ERCBusiUt",&dmlBusUnitStr));
					
					printf("\nESO: DML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);fflush(stdout);
					printf("\nESO: DML Business Unit:%s===>%s\n",dmlBusUnit,dmlBusUnitStr);fflush(stdout);
					
					char* dmlBusUnitS = NULL;
					dmlBusUnitS = (char*)MEM_alloc(200);
					tc_strcpy(dmlBusUnitS,",");
					tc_strcat(dmlBusUnitS,dmlBusUnit);
					tc_strcat(dmlBusUnitS,",");
					printf("\nESO: dmlBusUnitS:%s\n",dmlBusUnitS);fflush(stdout);
					if(tc_strstr(userInfo1,dmlBusUnitS)!=NULL)
					{
						//if((tc_strcmp(dmlReleaseType,"Veh")==0))
						if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);
						if(tc_strstr(userInfo2,dmlReleaseType)!=NULL)	
						{
							printf("\nESO: DML Release Type %s is valid for ESO sign off step", dmlRelTypeDisplayStr);fflush(stdout);
							 
							logical  result = false;							
							
							CALLAPI(isESODmlDR4andAboveDML(dmlTag, &result));
							printf("\nESO: Is DR 4 and above DML: %d\n",result);fflush(stdout);
							//result =true;
							if(result)
							{
								//If TODR dml then check it is migrating vehicle/CCV  or Engine Module
								
								//Get the DML task
								tag_t *dmlTaskTagObjects = NULL;
								tag_t dmlTaskTag = NULLTAG;
								int taskCnt = 0;								
								CALLAPI(AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects));
								printf("\nESO: DML ERC Task Count:%d\n",taskCnt);fflush(stdout);
								
								if(taskCnt>0)
								{
									int j=0;
									char* object_type	=	NULL;
									
									for(j=0;j<taskCnt;j++)
									{
										dmlTaskTag = dmlTaskTagObjects[j];
										CALLAPI(AOM_ask_value_string(dmlTaskTag,"object_type",&object_type));
										printf("\nESO: DML Task object_type is :%s\n",object_type);fflush(stdout);
										
										if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
										{
											int partCnt=0;
											tag_t *partTagObjects = NULL;
											tag_t partTag = NULLTAG;
											CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMReferences",&partCnt,&partTagObjects));
											//CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMHasSolutionItem",&partCnt,&partTagObjects));
											printf("\nESO:Part Count:%d\n",partCnt);fflush(stdout);
											
											if(partCnt>0)
											{
												int p=0;
												char* part_object_type = NULL;
												char* partNo = NULL;
												char* partType = NULL;
												
												for(p=0;p<partCnt;p++)
												{
													partTag = partTagObjects[p];
													CALLAPI(AOM_ask_value_string(partTag,"object_type",&part_object_type));
													printf("\nESO: object_type of part is :%s\n",part_object_type);fflush(stdout);
													
													if(tc_strcmp(part_object_type,"Design Revision")==0)
													{
														CALLAPI(AOM_ask_value_string(partTag,"item_id",&partNo));
														printf("\nESO: Item ID:%s\n",partNo);fflush(stdout);
														//t5_PartType
														
														CALLAPI(AOM_ask_value_string(partTag,"t5_PartType",&partType));
														printf("\nESO: Part Type of the part:%s\n",partType);fflush(stdout);
														
														if(tc_strcmp(userInfo4,partType) == 0 || tc_strcmp(partType,"V")==0 || tc_strcmp(partType,"CCVC")==0 || tc_strcmp(partType,"VCCR")==0)
														{
															
															
															printf("\nESO: APPLICABLE FOR ESO STEP- check for eso object");fflush(stdout);
															
															//Get ESO Status object
															int esoCnt =0;
															tag_t* esoTags = NULL;
															CALLAPI(AOM_ask_value_tags(partTag,"T5_PartEsoRel",&esoCnt,&esoTags));
															
															if(esoCnt>0)
															{
																int m =0;
																for(m=0;m<esoCnt;m++)
																{
																	
																	printf("\n %s has ESO status. \n",partNo);fflush(stdout);
																	tag_t esoTag = NULLTAG;
																	char* esoStatusStr = NULL;
																	esoTag = esoTags[m];
																	
																	CALLAPI(AOM_ask_value_string(esoTag,"t5_ESOStatus",&esoStatusStr));
																	printf("\nESO: t5_ESOStatus:%s\n",esoStatusStr);fflush(stdout);
																	
																	
																	//DR4 Release without ESO
																	
																	if(tc_strstr(esoStatusStr,"DR4 without ESO")!=NULL || tc_strcmp(esoStatusStr,"DR4 without ESO (Head Engineering Approval)")==0)
																	{
																		printf("\nGo to eso deviation path\n");fflush(stdout);
																		ifail = 1001;
																		return ifail; //Go to error path
																	}																	
																	
																}

																														

															}
															else
															{
																//check for ESO objects exists for the mentioned part but may not be related to the part.
															}
															

														}
														else if(tc_strcmp(partType,"M")==0 || tc_strcmp(partType,"T")==0)//CR-FY24-0033 - For Part Type Module and Design Group 00, 26
														{
															printf("\nESO: Part Type Module");fflush(stdout);
															char* desGrp = NULL;
															ifail = AOM_ask_value_string(partTag,"t5_DesignGrp",&desGrp);
															printf("\nESO: Design Group: %s\n", desGrp);fflush(stdout);
															if(tc_strcmp(desGrp,"00")==0 || tc_strcmp(desGrp,"26")==0)
															{
																printf("\nESO: APPLICABLE FOR ESO STEP- check for eso object");fflush(stdout);
																
																//Get ESO Status object
																int esoCnt =0;
																tag_t* esoTags = NULL;
																CALLAPI(AOM_ask_value_tags(partTag,"T5_PartEsoRel",&esoCnt,&esoTags));
																
																if(esoCnt>0)
																{
																	int m =0;
																	for(m=0;m<esoCnt;m++)
																	{
																		
																		printf("\n %s has ESO status. \n",partNo);fflush(stdout);
																		tag_t esoTag = NULLTAG;
																		char* esoStatusStr = NULL;
																		esoTag = esoTags[m];
																		
																		CALLAPI(AOM_ask_value_string(esoTag,"t5_ESOStatus",&esoStatusStr));
																		printf("\nESO: t5_ESOStatus:%s\n",esoStatusStr);fflush(stdout);
																		
																		
																		//DR4 Release without ESO
																		
																		if(tc_strstr(esoStatusStr,"DR4 without ESO")!=NULL || tc_strcmp(esoStatusStr,"DR4 without ESO (Head Engineering Approval)")==0)
																		{
																			printf("\nGo to eso deviation path\n");fflush(stdout);
																			ifail = 1001;
																			return ifail; //Go to error path
																		}																	
																		
																	}

																															

																}
																else
																{
																	//check for ESO objects exists for the mentioned part but may not be related to the part.
																}
															}
														}
														
													}
													
													
													
													
												}
											}
											
											
										}
										
										
									}
								}
								
								
								
								
								
								
								
							
							}
							else
							{
								printf("\nESO: Not a DR 4 and above DML: ESO step not applicable");fflush(stdout);
							}
							
							
							

						}						
					}
					else
					{
						if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);
						printf("\nESO: Not Valid Business Unit.Not applicable for ESO");fflush(stdout);
					}
					
					
				}
			}
		}	
				
	}

	if(ifail!=0)
	{
		printf("\nESO: Valid to go to ESO Sign off Step");fflush(stdout);
	}
	else
	{
		printf("\nESO: DML not applicable for ESO Step");fflush(stdout);
	}
	
	return ifail;
	
}



int  tm_CheckApplicableForESODevFunPVPSE(EPM_action_message_t  msg)
{
	int ifail = ITK_ok;

	const char * prog_name ="tm_CheckApplicableForESODevFunPVPSE";
	char*	username 	=	NULL;
	tag_t	user_tag	=	NULLTAG;
	tag_t	rootTask	= NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
	
	CALLAPI(isLiveForESOReview(&cntrlObj,&liveFlag)); //Check if control object CEDCreVl-CEDCreVl is present and returns TRUE
	
	printf("\nESO: tm_CheckApplicableForESODevFunPVPSE -Live for ESO Review for valid DML type==>%d\n",liveFlag);fflush(stdout);	
	if(!liveFlag)
	{
		printf("\nESO: NOT Live for ESO Review- Check for control object ESOREV");fflush(stdout);
		return ifail;
	}
	if(cntrlObj != NULLTAG && liveFlag)
	{
		POM_get_user(&username,&user_tag);
		printf("\nESO: Starting for username :%s....\n",username);fflush(stdout);
		
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		printf("\nESO: Root task found");fflush(stdout);
		
		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
		printf("\nESO: Current Task:%s\n",currentTaskName);fflush(stdout);

		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
		printf("\nESO: Parent Name:%s\n",parentTaskName);fflush(stdout);	
		
		CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
		
		if(targetobjects_count > 0)
		{
			int i =0;
			tag_t objectTypeTag = NULLTAG;
			char *type_name = NULL;
			char* dmlReleaseType = NULL;			
			char* dmlRelTypeDisplayStr = NULL;
			char* dmlBusUnit	=	NULL;
			char* dmlBusUnitStr	=	NULL;
			char* userInfo1	=	NULL;
			char* userInfo2	= NULL;
			char* userInfo3	=	NULL;
			char* userInfo4	=	NULL;
			char* userInfo5	=	NULL;
			
			
			
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
			
			printf("\nESORev Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5);fflush(stdout);
			
			for(i=0;i<targetobjects_count;i++)
			{
				CALLAPI(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
				CALLAPI(TCTYPE_ask_name2( objectTypeTag, &type_name));
				printf("\nESO: type_name ==> %s\n", type_name);fflush(stdout);
				
				if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
				{
					tag_t dmlTag = NULLTAG;
					dmlTag = targetobjects[i];
					
					CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlReleaseType));
					CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_rlstype",&dmlRelTypeDisplayStr));
					CALLAPI(AOM_ask_value_string(dmlTag,"t5_ERCBusiUt",&dmlBusUnit));
					CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_ERCBusiUt",&dmlBusUnitStr));
					
					printf("\nESO: DML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);fflush(stdout);
					printf("\nESO: DML Business Unit:%s===>%s\n",dmlBusUnit,dmlBusUnitStr);fflush(stdout);
					
					char* dmlBusUnitS = NULL;
					dmlBusUnitS = (char*)MEM_alloc(200);
					tc_strcpy(dmlBusUnitS,",");
					tc_strcat(dmlBusUnitS,dmlBusUnit);
					tc_strcat(dmlBusUnitS,",");
					printf("\nESO: dmlBusUnitS:%s\n",dmlBusUnitS);fflush(stdout);
					if(tc_strstr(userInfo1,dmlBusUnitS)!=NULL)
					{
						//if((tc_strcmp(dmlReleaseType,"Veh")==0))
						if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);
						if(tc_strstr(userInfo2,dmlReleaseType)!=NULL)	
						{
							printf("\nESO: DML Release Type %s is valid for ESO sign off step", dmlRelTypeDisplayStr);fflush(stdout);
							 
							logical  result = false;							
							
							CALLAPI(isESODmlDR4andAboveDML(dmlTag, &result));
							printf("\nESO: Is DR 4 and above DML: %d\n",result);fflush(stdout);
							//result =true;
							if(result)
							{
								//If TODR dml then check it is migrating vehicle/CCV  or Engine Module
								
								//Get the DML task
								tag_t *dmlTaskTagObjects = NULL;
								tag_t dmlTaskTag = NULLTAG;
								int taskCnt = 0;								
								CALLAPI(AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects));
								printf("\nESO: DML ERC Task Count:%d\n",taskCnt);fflush(stdout);
								
								if(taskCnt>0)
								{
									int j=0;
									char* object_type	=	NULL;
									
									for(j=0;j<taskCnt;j++)
									{
										dmlTaskTag = dmlTaskTagObjects[j];
										CALLAPI(AOM_ask_value_string(dmlTaskTag,"object_type",&object_type));
										printf("\nESO: DML Task object_type is :%s\n",object_type);fflush(stdout);
										
										if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
										{
											int partCnt=0;
											tag_t *partTagObjects = NULL;
											tag_t partTag = NULLTAG;
											CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMReferences",&partCnt,&partTagObjects));
											//CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMHasSolutionItem",&partCnt,&partTagObjects));
											printf("\nESO:Part Count:%d\n",partCnt);fflush(stdout);
											
											if(partCnt>0)
											{
												int p=0;
												char* part_object_type = NULL;
												char* partNo = NULL;
												char* partType = NULL;
												
												for(p=0;p<partCnt;p++)
												{
													partTag = partTagObjects[p];
													CALLAPI(AOM_ask_value_string(partTag,"object_type",&part_object_type));
													printf("\nESO: object_type of part is :%s\n",part_object_type);fflush(stdout);
													
													if(tc_strcmp(part_object_type,"Design Revision")==0)
													{
														CALLAPI(AOM_ask_value_string(partTag,"item_id",&partNo));
														printf("\nESO: Item ID:%s\n",partNo);fflush(stdout);
														//t5_PartType
														
														CALLAPI(AOM_ask_value_string(partTag,"t5_PartType",&partType));
														printf("\nESO: Part Type of the part:%s\n",partType);fflush(stdout);
														
														if(tc_strcmp(userInfo4,partType) == 0 || tc_strcmp(partType,"V")==0 || tc_strcmp(partType,"CCVC")==0 || tc_strcmp(partType,"VCCR")==0)
														{
															
															
															printf("\nESO: APPLICABLE FOR ESO STEP- check for eso object");fflush(stdout);
															
															//Get ESO Status object
															int esoCnt =0;
															tag_t* esoTags = NULL;
															CALLAPI(AOM_ask_value_tags(partTag,"T5_PartEsoRel",&esoCnt,&esoTags));
															
															if(esoCnt>0)
															{
																int m =0;
																for(m=0;m<esoCnt;m++)
																{
																	
																	printf("\n %s has ESO status. \n",partNo);fflush(stdout);
																	tag_t esoTag = NULLTAG;
																	char* esoStatusStr = NULL;
																	esoTag = esoTags[m];
																	
																	CALLAPI(AOM_ask_value_string(esoTag,"t5_ESOStatus",&esoStatusStr));
																	printf("\nESO: t5_ESOStatus:%s\n",esoStatusStr);fflush(stdout);
																	
																	
																	//DR4 Release without ESO
																	
																	if(tc_strstr(esoStatusStr,"AR4 without ESO")!=NULL || tc_strcmp(esoStatusStr,"AR4 without ESO (Head PSE Approval)")==0)
																	{
																		printf("\nPV-PSE Go to eso deviation path\n");fflush(stdout);
																		ifail = 1001;
																		return ifail; //Go to error path
																	}																	
																	
																}

																														

															}
															else
															{
																//check for ESO objects exists for the mentioned part but may not be related to the part.
															}
															

														}
														else if(tc_strcmp(partType,"M")==0 || tc_strcmp(partType,"T")==0)//CR-FY24-0033 - For Part Type Module and Design Group 00, 26
														{
															printf("\nESO: Part Type Module");fflush(stdout);
															char* desGrp = NULL;
															ifail = AOM_ask_value_string(partTag,"t5_DesignGrp",&desGrp);
															printf("\nESO: Design Group: %s\n", desGrp);fflush(stdout);
															if(tc_strcmp(desGrp,"00")==0 || tc_strcmp(desGrp,"26")==0)
															{
																printf("\nESO: APPLICABLE FOR ESO STEP- check for eso object");fflush(stdout);
																
																//Get ESO Status object
																int esoCnt =0;
																tag_t* esoTags = NULL;
																CALLAPI(AOM_ask_value_tags(partTag,"T5_PartEsoRel",&esoCnt,&esoTags));
																
																if(esoCnt>0)
																{
																	int m =0;
																	for(m=0;m<esoCnt;m++)
																	{
																		
																		printf("\n %s has ESO status. \n",partNo);fflush(stdout);
																		tag_t esoTag = NULLTAG;
																		char* esoStatusStr = NULL;
																		esoTag = esoTags[m];
																		
																		CALLAPI(AOM_ask_value_string(esoTag,"t5_ESOStatus",&esoStatusStr));
																		printf("\nESO: t5_ESOStatus:%s\n",esoStatusStr);fflush(stdout);
																		
																		
																		//DR4 Release without ESO
																		
																		if(tc_strstr(esoStatusStr,"DR4 without ESO")!=NULL || tc_strcmp(esoStatusStr,"DR4 without ESO (Head Engineering Approval)")==0)
																		{
																			printf("\nGo to eso deviation path\n");fflush(stdout);
																			ifail = 1001;
																			return ifail; //Go to error path
																		}																	
																		
																	}

																															

																}
																else
																{
																	//check for ESO objects exists for the mentioned part but may not be related to the part.
																}
															}
														}
														
													}
													
													
													
													
												}
											}
											
											
										}
										
										
									}
								}
								
								
								
								
								
								
								
							
							}
							else
							{
								printf("\nESO: Not a DR 4 and above DML: ESO step not applicable");fflush(stdout);
							}
							
							
							

						}						
					}
					else
					{
						if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);
						printf("\nESO: Not Valid Business Unit.Not applicable for ESO");fflush(stdout);
					}
					
					
				}
			}
		}	
				
	}

	if(ifail!=0)
	{
		printf("\nESO: Valid to go to ESO Sign off Step");fflush(stdout);
	}
	else
	{
		printf("\nESO: DML not applicable for ESO Step");fflush(stdout);
	}
	
	return ifail;
	
}



int getTCObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULL;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find2("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\n getLatestPart: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}

int tmCreateESOStatus(tag_t partTag, char* esoStatStr, char* grNumber, char* grDateStr, char* esoRemark, char* esoDesgnRemark)
{
	int ifail = ITK_ok;	
	tag_t contrlObj = NULLTAG;
	logical liveFlag = FALSE;
	tag_t cntrlObj = NULLTAG;
	
	CALLAPI(isLiveForESOReview(&cntrlObj,&liveFlag)); //Check if control object CEDCreVl-CEDCreVl is present and returns TRUE
	printf("\nESO: Live for ESO Status creatione==>%d\n",liveFlag);fflush(stdout);	
	if(!liveFlag)
	{
		printf("\nESO: NOT Live for ESO Status creation- Check for control object ESOREV");fflush(stdout);
		return ifail;
	}
	if(cntrlObj != NULLTAG && liveFlag)
	{
		
		char* userInfo1	=	NULL;
		char* userInfo2	= NULL;
		char* userInfo3	=	NULL;
		char* userInfo4	=	NULL;
		char* userInfo5	=	NULL;
		char* userInfo6	=	NULL;
		char* userInfo7	=	NULL;
		
		
		
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
		
		printf("\nESORev Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\nt5_Userinfo6:[%s]\nt5_Userinfo7:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7);fflush(stdout);
		

		
		char* partNum = NULL;
		char* partDesc = NULL;
		char* rev = NULL;
		char* revStr = NULL;
		char* seq = NULL;
		date_t grDate;
		char* seqStr = NULL;
		
		int cnt =0;
		tag_t * esoTags = NULL;
		char*	username				=NULL;
		char* sessionUser = NULL;
		tag_t	user_tag				=NULLTAG;
		int creFlag =0;
		char* partRelStatus = NULL;
		
		POM_get_user(&username,&user_tag);
		POM_get_user_id(&sessionUser);
		printf("\nESO:Session username :%s,%s....\n",username, sessionUser);fflush(stdout);


		ITK_string_to_date(grDateStr,&grDate);

		CALLAPI(AOM_ask_value_string(partTag,"item_id",&partNum));
		printf("\nESO:partNum: %s",partNum); fflush(stdout);			
		
		CALLAPI (AOM_UIF_ask_value(partTag,"item_revision_id",&rev));
		printf("\nESO::rev:%s\n",rev); fflush(stdout);
		
		if(tc_strstr(rev,";") != NULL)
		{
			revStr = tc_strtok ( rev,";") ;
			seqStr = tc_strtok ( NULL,";") ;	
		}
		
		printf("\nESO:seqStr:%s",seqStr); fflush(stdout);
		CALLAPI (AOM_UIF_ask_value(partTag,"sequence_id",&seq));
		printf("\nESO:seq:%s",seq); fflush(stdout);
		
		//Check whether the part selected is ERC Released or above
		CALLAPI(AOM_UIF_ask_value(partTag,"release_status_list",&partRelStatus))
		printf("\nESO:LC State of Part: %s ", partRelStatus);fflush(stdout);
		if((tc_strstr(partRelStatus,"Released")!=NULL)||(tc_strstr(partRelStatus,"ERC Released")!=NULL))
		{
			creFlag =0;
		}
		else
		{
			printf("\nESO Part is not Released");fflush(stdout);
			creFlag ++;
		}
		
		//Check that part selected already has ESO status
		CALLAPI(AOM_ask_value_tags(partTag,"T5_PartEsoRel",&cnt,&esoTags));
		
		if(cnt>0)
		{
			printf("\nESO:Selected part already has ESO status and related to the part\n");fflush(stdout);
			//todo - check correct eso object is attached.
			
			int m =0;
			char* esoItemId1 = NULL;
			char* esoNum = NULL;
			esoItemId1 = (char*)MEM_alloc(strlen(partNum)*sizeof(char) + 30);
			tc_strcpy(esoItemId1,"");
			tc_strcat(esoItemId1,"ESO_");
			tc_strcat(esoItemId1,partNum);
			tc_strcat(esoItemId1,"_");
			tc_strcat(esoItemId1,rev);
			tc_strcat(esoItemId1,"_");
			tc_strcat(esoItemId1,seqStr);
			
			printf("\n esoItemId1==> %s\n",esoItemId1);fflush(stdout);
			
			for(m=0;m<cnt;m++)
			{
				tag_t esoObj = NULLTAG;
				esoObj = esoTags[m];
				
				CALLAPI(AOM_ask_value_string(esoObj,"item_id",&esoNum));
				printf("\nESO:esoNum: %s",esoNum); fflush(stdout);
				
				if(tc_strcmp(esoItemId1,esoNum)==0)
				{
					printf("\n ESO object %s is already attached to the part %s. No need to create again ESO object \n",esoItemId1,partNum );fflush(stdout);
					creFlag++;
					break;
				}
				
				
				
			}
			
			if(esoItemId1)MEM_free(esoItemId1);
			
		}
		else
		{
			//check if eso object is already present but may not be related to the part.
			
			char* esoItemId2 = NULL;
			tag_t esoTag2 = NULLTAG;
			
			
			esoItemId2 = (char*)MEM_alloc(strlen(partNum)*sizeof(char) + 30);
			tc_strcpy(esoItemId2,"");
			tc_strcat(esoItemId2,"ESO_");
			tc_strcat(esoItemId2,partNum);
			tc_strcat(esoItemId2,"_");
			tc_strcat(esoItemId2,rev);
			tc_strcat(esoItemId2,"_");
			tc_strcat(esoItemId2,seqStr);
			
			printf("\n esoItemId2==> %s\n",esoItemId2);fflush(stdout);
			
			CALLAPI(getTCObject(esoItemId2,"T5_ESOStRevision",&esoTag2));fflush(stdout);
			
			if(esoTag2 != NULLTAG)
			{
				printf("\nESO object %s already present but not related to the Vehicle %s. Going to relate the ESO object to the part",esoItemId2,partNum);fflush(stdout);
				creFlag++;
				CALLAPI(relatePrimaryWithSecondaryObj(partTag,esoTag2,"T5_PartEsoRel"));
				
			}
			else
			{
				creFlag = 0;
			}
			
			
			
			
		}
		
		
		
		//Create ESO part -item_id
		
		if(creFlag==0)
		{
			char* esoItemId = NULL;
			tag_t esoTag = NULLTAG;
			
			
			esoItemId = (char*)MEM_alloc(strlen(partNum)*sizeof(char) + 30);
			tc_strcpy(esoItemId,"");
			tc_strcat(esoItemId,"ESO_");
			tc_strcat(esoItemId,partNum);
			tc_strcat(esoItemId,"_");
			tc_strcat(esoItemId,rev);
			tc_strcat(esoItemId,"_");
			tc_strcat(esoItemId,seqStr);
			
			printf("\n ESO:New ESO No Created Is: [%s]",esoItemId);fflush(stdout);
			
			//check if already ESO status is present in plm but not related.
			
			CALLAPI(getTCObject(esoItemId,"T5_ESOStRevision",&esoTag));fflush(stdout);
			if(esoTag != NULLTAG)
			{
				printf("\nESO:Already ESO tag is there with id %s",esoItemId);fflush(stdout);
				//todo - if not related . relate the eso object to the part
				
			}
			else
			{
				tag_t rev_type_tag = NULLTAG;
				tag_t rev_create_input_tag = NULLTAG;
				tag_t item_create_input_tag = NULLTAG;
				tag_t item_type_tag = NULLTAG;
				tag_t esoStatusTag = NULLTAG;
				printf("\nESO:Creating ESO Status NR revision- first time.....\n");fflush(stdout);
				TCTYPE_find_type("T5_ESOStRevision", NULL, &rev_type_tag);
				
				if(rev_type_tag!=NULLTAG)
				{
					TCTYPE_construct_create_input(rev_type_tag, &rev_create_input_tag);
					AOM_set_value_string(rev_create_input_tag, "object_name", esoItemId);
					AOM_set_value_string(rev_create_input_tag, "item_revision_id", "NR;1");
					
					
					
					
					AOM_set_value_string(rev_create_input_tag, "t5_ESOStatusNo", esoItemId);
					AOM_set_value_string(rev_create_input_tag, "t5_ESOPartNo", partNum);
					AOM_set_value_string(rev_create_input_tag, "t5_ESOPartRev", rev);
					AOM_set_value_string(rev_create_input_tag, "t5_ESOStatus", esoStatStr);
					AOM_set_value_string(rev_create_input_tag, "t5_GRnumb", grNumber);
					AOM_set_value_string(rev_create_input_tag, "t5_ESORemark", esoRemark);
					AOM_set_value_date(rev_create_input_tag, "t5_GRDate", grDate);
					AOM_set_value_string(rev_create_input_tag, "t5_ESODesRemark", esoDesgnRemark);
					
					
					TCTYPE_find_type("T5_ESOSt", NULL, &item_type_tag);
					if(item_type_tag!=NULLTAG)
					{
							printf("\nSAN:creCEDPart: item_type_tag Tag Found."); fflush(stdout);
							
							
					}
					TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag);

					AOM_set_value_string(item_create_input_tag, "item_id", esoItemId);
					AOM_set_value_string(item_create_input_tag, "object_name", esoItemId);
					AOM_set_value_tag(item_create_input_tag, "revision",rev_create_input_tag);

					//Create ESO status and its  Revision
					TCTYPE_create_object(item_create_input_tag, &esoStatusTag);
					
					if(esoStatusTag!=NULLTAG)
					{
						printf("\nESO:ESO Status part created."); fflush(stdout);					 
						AOM_save_with_extensions(esoStatusTag);				
					}
					//Get ESO Status Item revision
					tag_t * eso_rev_list = NULL;
					int eso_item_count = 0;
					tag_t esoStatusRevTag = NULLTAG;
					ITEM_list_all_revs (esoStatusTag, &eso_item_count, &eso_rev_list);
					
					if(eso_item_count>0)
					{
						esoStatusRevTag = eso_rev_list[0];
						
						if(esoStatusRevTag!=NULLTAG)
						{
							
							CALLAPI(relatePrimaryWithSecondaryObj(partTag,esoStatusRevTag,"T5_PartEsoRel"));
							CALLAPI(relatePrimaryWithSecondaryObj(esoStatusRevTag,partTag,"T5_EsoPartRel"));
							
						}									
						
					}
																			
										
				}
				
				
			}
			
		
					
			if(esoItemId)MEM_free(esoItemId);
		
		}

	
	

	
				
	
	
		

		
		
		
	}
		
	
	
	
	return ifail;
}



int tmCreateESOStatusNew(tag_t partTag, char* esoStatStr, char* grNumber, char* grDateStr, char* esoRemark, char* esoDesgnRemark, char** resultStr)
{
	int ifail = ITK_ok;	
	tag_t contrlObj = NULLTAG;
	logical liveFlag = FALSE;
	tag_t cntrlObj = NULLTAG;
	*resultStr ="FALSE";
	
	CALLAPI(isLiveForESOReview(&cntrlObj,&liveFlag)); //Check if control object CEDCreVl-CEDCreVl is present and returns TRUE
	printf("\nESO: Live for ESO Status creatione==>%d\n",liveFlag);fflush(stdout);	
	if(!liveFlag)
	{
		printf("\nESO: NOT Live for ESO Status creation- Check for control object ESOREV");fflush(stdout);
		*resultStr ="FALSE";
		return ifail;
	}
	if(cntrlObj != NULLTAG && liveFlag)
	{
		
		char* userInfo1	=	NULL;
		char* userInfo2	= NULL;
		char* userInfo3	=	NULL;
		char* userInfo4	=	NULL;
		char* userInfo5	=	NULL;
		char* userInfo6	=	NULL;
		char* userInfo7	=	NULL;
		
		
		
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
		
		printf("\nESORev Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\nt5_Userinfo6:[%s]\nt5_Userinfo7:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7);fflush(stdout);
		

			
		char* partNum = NULL;
		char* partDesc = NULL;
		char* rev = NULL;
		char* revStr = NULL;
		char* seq = NULL;
		date_t grDate;
		char* seqStr = NULL;
		
		int cnt =0;
		tag_t * esoTags = NULL;
		char*	username				=NULL;
		char* sessionUser = NULL;
		tag_t	user_tag				=NULLTAG;
		int creFlag =0;
		char* partRelStatus = NULL;
		
		POM_get_user(&username,&user_tag);
		POM_get_user_id(&sessionUser);
		printf("\nESO:Session username :%s,%s....\n",username, sessionUser);fflush(stdout);


		ITK_string_to_date(grDateStr,&grDate);

		CALLAPI(AOM_ask_value_string(partTag,"item_id",&partNum));
		printf("\nESO:partNum: %s",partNum); fflush(stdout);			
		
		CALLAPI (AOM_UIF_ask_value(partTag,"item_revision_id",&rev));
		printf("\nESO::rev:%s\n",rev); fflush(stdout);
		
		if(tc_strstr(rev,";") != NULL)
		{
			revStr = tc_strtok ( rev,";") ;
			seqStr = tc_strtok ( NULL,";") ;	
		}
		
		printf("\nESO:seqStr:%s",seqStr); fflush(stdout);
		CALLAPI (AOM_UIF_ask_value(partTag,"sequence_id",&seq));
		printf("\nESO:seq:%s",seq); fflush(stdout);
		
		//Check whether the part selected is ERC Released or above
		CALLAPI(AOM_UIF_ask_value(partTag,"release_status_list",&partRelStatus))
		printf("\nESO:LC State of Part: %s ", partRelStatus);fflush(stdout);
		

		//Not required- ESO object can be created om working part also
		if(tc_strcmp(userInfo6,"YES")==0)
		{
			if((tc_strstr(partRelStatus,"Released")!=NULL)||(tc_strstr(partRelStatus,"ERC Released")!=NULL))
			{
				creFlag =0;
			}
			else
			{
				printf("\nESO Part is not Released");fflush(stdout);
				creFlag ++;
				
			}
		}
		if(creFlag >0)
		{
			*resultStr ="PARTNOTRELEASED";
			printf("\n ESO creation  not allowed for working part \n");fflush(stdout);
			return ifail;
		}
		
		
		//Check that part selected already has ESO status
		CALLAPI(AOM_ask_value_tags(partTag,"T5_PartEsoRel",&cnt,&esoTags));
		
		if(cnt>0)
		{
			printf("\nESO:Selected part already has ESO status and related to the part\n");fflush(stdout);
			//todo - check correct eso object is attached.
			
			int m =0;
			char* esoItemId1 = NULL;
			char* esoNum = NULL;
			esoItemId1 = (char*)MEM_alloc(strlen(partNum)*sizeof(char) + 30);
			tc_strcpy(esoItemId1,"");
			tc_strcat(esoItemId1,"ESO_");
			tc_strcat(esoItemId1,partNum);
			tc_strcat(esoItemId1,"_");
			tc_strcat(esoItemId1,rev);
			tc_strcat(esoItemId1,"_");
			tc_strcat(esoItemId1,seqStr);
			
			printf("\n esoItemId1==> %s\n",esoItemId1);fflush(stdout);
			
			for(m=0;m<cnt;m++)
			{
				tag_t esoObj = NULLTAG;
				esoObj = esoTags[m];
				
				CALLAPI(AOM_ask_value_string(esoObj,"item_id",&esoNum));
				printf("\nESO:esoNum: %s",esoNum); fflush(stdout);
				
				if(tc_strcmp(esoItemId1,esoNum)==0)
				{
					printf("\n ESO object %s is already attached to the part %s. No need to create again ESO object \n",esoItemId1,partNum );fflush(stdout);
					creFlag++;
					*resultStr ="ESOALREADYEXIST";
					break;
				}
				
				
				
			}
			
			if(esoItemId1)MEM_free(esoItemId1);
			
		}
		else
		{
			//check if eso object is already present but may not be related to the part.
			
			char* esoItemId2 = NULL;
			tag_t esoTag2 = NULLTAG;
			
			
			esoItemId2 = (char*)MEM_alloc(strlen(partNum)*sizeof(char) + 30);
			tc_strcpy(esoItemId2,"");
			tc_strcat(esoItemId2,"ESO_");
			tc_strcat(esoItemId2,partNum);
			tc_strcat(esoItemId2,"_");
			tc_strcat(esoItemId2,rev);
			tc_strcat(esoItemId2,"_");
			tc_strcat(esoItemId2,seqStr);
			
			printf("\n esoItemId2==> %s\n",esoItemId2);fflush(stdout);
			
			CALLAPI(getTCObject(esoItemId2,"T5_ESOStRevision",&esoTag2));fflush(stdout);
			
			if(esoTag2 != NULLTAG)
			{
				printf("\nESO object %s already present but not related to the Vehicle %s. Going to relate the ESO object to the part",esoItemId2,partNum);fflush(stdout);
				creFlag++;
				CALLAPI(relatePrimaryWithSecondaryObj(partTag,esoTag2,"T5_PartEsoRel"));
				*resultStr ="ESOEXISTBUTNOTRELATED";
				
			}
			else
			{
				creFlag = 0;
			}
			
			
			
			
		}
		
		
		
		//Create ESO part -item_id
		
		if(creFlag==0)
		{
			char* esoItemId = NULL;
			tag_t esoTag = NULLTAG;
			
			
			esoItemId = (char*)MEM_alloc(strlen(partNum)*sizeof(char) + 30);
			tc_strcpy(esoItemId,"");
			tc_strcat(esoItemId,"ESO_");
			tc_strcat(esoItemId,partNum);
			tc_strcat(esoItemId,"_");
			tc_strcat(esoItemId,rev);
			tc_strcat(esoItemId,"_");
			tc_strcat(esoItemId,seqStr);
			
			printf("\n ESO:New ESO No Created Is: [%s]",esoItemId);fflush(stdout);
			
			//check if already ESO status is present in plm but not related.
			
			CALLAPI(getTCObject(esoItemId,"T5_ESOStRevision",&esoTag));fflush(stdout);
			if(esoTag != NULLTAG)
			{
				printf("\nESO:Already ESO tag is there with id %s",esoItemId);fflush(stdout);
				//todo - if not related . relate the eso object to the part
				*resultStr ="ESOEXISTBUTNOTRELATED";
				
			}
			else
			{
				tag_t rev_type_tag = NULLTAG;
				tag_t rev_create_input_tag = NULLTAG;
				tag_t item_create_input_tag = NULLTAG;
				tag_t item_type_tag = NULLTAG;
				tag_t esoStatusTag = NULLTAG;
				printf("\nESO:Creating ESO Status NR revision- first time.....\n");fflush(stdout);
				TCTYPE_find_type("T5_ESOStRevision", NULL, &rev_type_tag);
				
				if(rev_type_tag!=NULLTAG)
				{
					TCTYPE_construct_create_input(rev_type_tag, &rev_create_input_tag);
					AOM_set_value_string(rev_create_input_tag, "object_name", esoItemId);
					AOM_set_value_string(rev_create_input_tag, "item_revision_id", "NR;1");
					
					
					
					
					AOM_set_value_string(rev_create_input_tag, "t5_ESOStatusNo", esoItemId);
					AOM_set_value_string(rev_create_input_tag, "t5_ESOPartNo", partNum);
					AOM_set_value_string(rev_create_input_tag, "t5_ESOPartRev", rev);
					AOM_set_value_string(rev_create_input_tag, "t5_ESOStatus", esoStatStr);
					AOM_set_value_string(rev_create_input_tag, "t5_GRnumb", grNumber);
					AOM_set_value_string(rev_create_input_tag, "t5_ESORemark", esoRemark);
					AOM_set_value_string(rev_create_input_tag, "t5_ESODesRemark", esoDesgnRemark);
					AOM_set_value_date(rev_create_input_tag, "t5_GRDate", grDate);
					
					
					TCTYPE_find_type("T5_ESOSt", NULL, &item_type_tag);
					if(item_type_tag!=NULLTAG)
					{
							printf("\nSAN:creCEDPart: item_type_tag Tag Found."); fflush(stdout);
							
							
					}
					TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag);

					AOM_set_value_string(item_create_input_tag, "item_id", esoItemId);
					AOM_set_value_string(item_create_input_tag, "object_name", esoItemId);
					AOM_set_value_tag(item_create_input_tag, "revision",rev_create_input_tag);

					//Create ESO status and its  Revision
					TCTYPE_create_object(item_create_input_tag, &esoStatusTag);
					
					if(esoStatusTag!=NULLTAG)
					{
						printf("\nESO:ESO Status part created."); fflush(stdout);					 
						AOM_save_with_extensions(esoStatusTag);				
					}
					//Get ESO Status Item revision
					tag_t * eso_rev_list = NULL;
					int eso_item_count = 0;
					tag_t esoStatusRevTag = NULLTAG;
					ITEM_list_all_revs (esoStatusTag, &eso_item_count, &eso_rev_list);
					
					if(eso_item_count>0)
					{
						esoStatusRevTag = eso_rev_list[0];
						
						if(esoStatusRevTag!=NULLTAG)
						{
							
							CALLAPI(relatePrimaryWithSecondaryObj(partTag,esoStatusRevTag,"T5_PartEsoRel"));
							CALLAPI(relatePrimaryWithSecondaryObj(esoStatusRevTag,partTag,"T5_EsoPartRel"));
							
						}									
						
					}
					
					*resultStr ="TRUE";
																			
										
				}
				
				
			}
			
		
					
			if(esoItemId)MEM_free(esoItemId);
		
		}

	
	

		
				

	
	

		
		
		
	}
		
	
	
	
	return ifail;
}



int tmESOStatusCreServ(void *retValue)
{
	printf("\n ESO: Service:Start----tmESOStatusCreServ....\n");fflush(stdout);
	
	const char	*prog_name 	="tmESOStatusCreServ";
	
	int ifail = ITK_ok;
	int array_size = 0;
	tag_t* tag_array = NULL;
	USERSERVICE_array_t 	array_struct;
	
	tag_t partTag = NULLTAG;
	char* esoStatus = NULL;
	char* grNumber = NULL;
	char* grDateStr = NULL;
	char* esoRemark = NULL;
	char* esoDesgnRemark = NULL;
	USERARG_get_tag_argument(&partTag);
	USERARG_get_string_argument(&esoStatus);
	USERARG_get_string_argument(&grNumber);
	USERARG_get_string_argument(&grDateStr);
	USERARG_get_string_argument(&esoRemark);
	USERARG_get_string_argument(&esoDesgnRemark);
	
	printf("\nESO status:%s\nGR Number:%s\nGR Date:%s\nESO Remark:%s\nESO Designer Remark:%s",esoStatus,grNumber,grDateStr,esoRemark,esoDesgnRemark);fflush(stdout);
	
	if(partTag !=NULLTAG)
	{
		
		printf("ESO:Got the part tag object");fflush(stdout);
		//tmCreateESOStatus(tag_t partTag, char* esoStatStr, char* grNumber, char* grDateStr, char* esoRemark)
		CALLAPI(tmCreateESOStatus(partTag, esoStatus, grNumber, grDateStr,esoRemark,esoDesgnRemark));
					
	}
	//printf("After returning Value\n");fflush(stdout);	
	printf("\n ESO:CED Service:End----tmESOStatusCreServ....\n");fflush(stdout);
	return ifail;	
	
}



//new version of ESO object creation.
int tmESOStatusCreServNew(void *retValue)
{
	printf("\n ESO: Service:Start----tmESOStatusCreServNew....\n");fflush(stdout);
	
	const char	*prog_name 	="tmESOStatusCreServNew";
	
	int ifail = ITK_ok;
	int array_size = 0;
	tag_t* tag_array = NULL;
	USERSERVICE_array_t 	array_struct;
	
	tag_t partTag = NULLTAG;
	char* esoStatus = NULL;
	char* grNumber = NULL;
	char* grDateStr = NULL;
	char* esoRemark = NULL;
	char* esoDesgnRemark = NULL;

	char *resultStr = NULL;
	char * resultStr1 = NULL;	
	
	USERARG_get_tag_argument(&partTag);
	USERARG_get_string_argument(&esoStatus);
	USERARG_get_string_argument(&grNumber);
	USERARG_get_string_argument(&grDateStr);
	USERARG_get_string_argument(&esoRemark);
	USERARG_get_string_argument(&esoDesgnRemark);
	
	printf("\nESO status:%s\nGR Number:%s\nGR Date:%s\nESO Remark:%s\nESO Designer Remark:%s",esoStatus,grNumber,grDateStr,esoRemark,esoDesgnRemark);fflush(stdout);
	
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );
	
	if(partTag !=NULLTAG)
	{
		
		printf("ESO:Got the part tag object");fflush(stdout);
		//tmCreateESOStatus(tag_t partTag, char* esoStatStr, char* grNumber, char* grDateStr, char* esoRemark)
		//CALLAPI(tmCreateESOStatus(partTag, esoStatus, grNumber, grDateStr,esoRemark));
		
		CALLAPI(tmCreateESOStatusNew(partTag, esoStatus, grNumber, grDateStr,esoRemark,esoDesgnRemark, &resultStr));
					
	}
	//printf("After returning Value\n");fflush(stdout);	
	//printf("\n ESO:CED Service:End----tmESOStatusCreServ....\n");fflush(stdout);
	//return ifail;	
	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nANX: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	MEM_free(resultStr1);
	printf("After returning Value\n");fflush(stdout);	
	printf("\n ESO:Service:End----tmESOStatusCreServNew....\n");fflush(stdout);
	return ifail;	
	
}




EPM_decision_t tm_ValidateESOSignOffFn( EPM_rule_message_t msg)
{
	EPM_decision_t	decision = EPM_go;
	int ifail = ITK_ok;
	//char* dmlRelTypeDisplayStr = NULL;
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	rootTask = NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	const char * prog_name ="tm_ValidateESOSignOffFn";
	tag_t dmlTag = NULLTAG;
	
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
		
	POM_get_user(&username,&user_tag);
	printf("\nStarting for username :%s....\n",username);fflush(stdout);
	
	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nRoot task found");fflush(stdout);
	
	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
	printf("\nCurrent Task:%s\n",currentTaskName);fflush(stdout);

	CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
	printf("\nParent Name:%s\n",parentTaskName);fflush(stdout);	
	
	CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
	printf("\ntargetobjects_count:%d\n",targetobjects_count);fflush(stdout);	
	
	CALLAPI(isLiveForESOReview(&cntrlObj,&liveFlag));
	
	
	printf("\n Live for ESO check in rule handler ===> %d\n",liveFlag);fflush(stdout);
	
	if(liveFlag && cntrlObj!=NULLTAG)
	{
		
		char* userInfo8 = NULL;
		char* userInfo5 = NULL;
		char* userInfo4 = NULL;

		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
		printf("\nESO: userinfo8:%s    userinfo5: %s  userinfo4: %s\n",userInfo8, userInfo5,userInfo4);fflush(stdout);
		
		if(tc_strcmp(userInfo8,"YES")==0)
		{
			printf("\nESO: Live for rule handler check for ESO....\n");fflush(stdout);
			if(targetobjects_count > 0)
			{
				int i =0;
				tag_t objectTypeTag = NULLTAG;
				char *type_name = NULL;
				
				for(i=0;i<targetobjects_count;i++)
				{
					CALLAPI(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
					CALLAPI(TCTYPE_ask_name2( objectTypeTag, &type_name));
					printf("\ntype_name ==> %s\n", type_name);fflush(stdout);
					if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
					{
					    dmlTag = targetobjects[i];
						break;										
							
					}
				}
				
				if(dmlTag !=NULLTAG)
				{
					//Get the DML task
					tag_t *dmlTaskTagObjects = NULL;
					tag_t dmlTaskTag = NULLTAG;
					int taskCnt = 0;								
					CALLAPI(AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects));
					printf("\nESO: DML ERC Task Count:%d\n",taskCnt);fflush(stdout);
					
					if(taskCnt>0)
					{
						int j=0;
						char* object_type	=	NULL;
						for(j=0;j<taskCnt;j++)
						{
							dmlTaskTag = dmlTaskTagObjects[j];
							CALLAPI(AOM_ask_value_string(dmlTaskTag,"object_type",&object_type));
							printf("\nESO: DML Task object_type is :%s\n",object_type);fflush(stdout);
							if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
							{
								int partCnt=0;
								tag_t *partTagObjects = NULL;
								tag_t partTag = NULLTAG;
								CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMReferences",&partCnt,&partTagObjects));
								//CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMHasSolutionItem",&partCnt,&partTagObjects));
								printf("\nESO:Part Count:%d\n",partCnt);fflush(stdout);
								if(partCnt>0)
								{
									int p=0;
									char* part_object_type = NULL;
									char* partNo = NULL;
									char* partType = NULL;
									
									for(p=0;p<partCnt;p++)
									{
										partTag = partTagObjects[p];
										CALLAPI(AOM_ask_value_string(partTag,"object_type",&part_object_type));
										printf("\nESO: object_type of part is :%s\n",part_object_type);fflush(stdout);
										
										if(tc_strcmp(part_object_type,"Design Revision")==0)
										{
											CALLAPI(AOM_ask_value_string(partTag,"item_id",&partNo));
											printf("\nESO: Item ID:%s\n",partNo);fflush(stdout);
											//t5_PartType
											
											CALLAPI(AOM_ask_value_string(partTag,"t5_PartType",&partType));
											printf("\nESO: Part Type of the part:%s\n",partType);fflush(stdout);
											
											if(tc_strcmp(userInfo4,partType)==0 || tc_strcmp(partType,"V")==0 || tc_strcmp(partType,"CCVC")==0 || tc_strcmp(partType,"VCCR") == 0)
											{
												printf("\nESO: APPLICABLE FOR ESO STEP");fflush(stdout);
												
												//Get ESO Status object
												int esoCnt =0;
												tag_t* esoTags = NULL;
												CALLAPI(AOM_ask_value_tags(partTag,"T5_PartEsoRel",&esoCnt,&esoTags));
												
												if(esoCnt==0)
												{
													printf("\n %s does not has ESO status. Please create ESO status\n",partNo);fflush(stdout);
													char* buff = NULL;
													ifail=T5_WorkFlowHandlerESOErr;
													buff = (char*)MEM_alloc(200*sizeof(char));
													sprintf(buff, "No ESO Status object found for the part[%s].", partNo);
													EMH_store_error_s1(EMH_severity_error,ifail,buff);
													decision = EPM_nogo;
													if(buff)MEM_free(buff);
													return decision;
												}
												
												if(esoCnt >0 )
												{
													//Check if ESO object is there but check if correct ESO object is attached to the part.
													char* esoItemId = NULL;
													char* rev = NULL;
													char* revStr = NULL;
													char* seqStr = NULL;
													int esoFlag =0;
													
													int p= 0;
													
													CALLAPI (AOM_UIF_ask_value(partTag,"item_revision_id",&rev));
													printf("\nESO::rev:%s\n",rev); fflush(stdout);
													
													if(tc_strstr(rev,";") != NULL)
													{
														revStr = tc_strtok ( rev,";") ;
														seqStr = tc_strtok ( NULL,";") ;	
													}
													
													printf("\nESO :validatesignoff:seqStr:%s",seqStr); fflush(stdout);													
													esoItemId = (char*)MEM_alloc(strlen(partNo)*sizeof(char) + 30);
													tc_strcpy(esoItemId,"");
													tc_strcat(esoItemId,"ESO_");
													tc_strcat(esoItemId,partNo);
													tc_strcat(esoItemId,"_");
													tc_strcat(esoItemId,rev);
													tc_strcat(esoItemId,"_");
													tc_strcat(esoItemId,seqStr);
													for(p=0;p<esoCnt;p++)
													{
														tag_t esoTg = NULLTAG;
														char* esoNum = NULL;
														esoTg = esoTags[p];
														
														CALLAPI(AOM_ask_value_string(esoTg,"item_id",&esoNum));
														printf("\nESO:esoNum: %s",esoNum); fflush(stdout);

														if(tc_strcmp(esoItemId,esoNum)==0)
														{
															printf("\n ESO object %s is already attached to the part %s. No need to create again ESO object \n",esoItemId,partNo );fflush(stdout);
															esoFlag++;
															break;
														}
																			
													}
													if(esoFlag ==0)
													{
														printf("\n %s does not has ESO status. Please create ESO status\n",partNo);fflush(stdout);
														char* buff = NULL;
														ifail=T5_WorkFlowHandlerESOErr;
														buff = (char*)MEM_alloc(200*sizeof(char));
														sprintf(buff, "No ESO Status object %s found for the part[%s].", esoItemId, partNo);
														EMH_store_error_s1(EMH_severity_error,ifail,buff);
														decision = EPM_nogo;
														if(buff)MEM_free(buff);
														return decision;													
													}

													
												}
											
											}
											else if(tc_strcmp(partType,"M")==0 || tc_strcmp(partType,"T")==0)//CR-FY24-0033 - For Part Type Module and Design Group 00, 26
											{
												printf("\nESO: Part Type Module");fflush(stdout);
												char* desGrp = NULL;
												ifail = AOM_ask_value_string(partTag,"t5_DesignGrp",&desGrp);
												printf("\nESO: Design Group: %s\n", desGrp);fflush(stdout);
												if(tc_strcmp(desGrp,"00")==0 || tc_strcmp(desGrp,"26")==0)
												{
													//Get ESO Status object
													int esoCnt =0;
													tag_t* esoTags = NULL;
													CALLAPI(AOM_ask_value_tags(partTag,"T5_PartEsoRel",&esoCnt,&esoTags));
													
													if(esoCnt==0)
													{
														printf("\n %s does not has ESO status. Please create ESO status\n",partNo);fflush(stdout);
														char* buff = NULL;
														ifail=T5_WorkFlowHandlerESOErr;
														buff = (char*)MEM_alloc(200*sizeof(char));
														sprintf(buff, "No ESO Status object found for the part[%s].", partNo);
														EMH_store_error_s1(EMH_severity_error,ifail,buff);
														decision = EPM_nogo;
														if(buff)MEM_free(buff);
														return decision;
													}
													
													if(esoCnt >0 )
													{
														//Check if ESO object is there but check if correct ESO object is attached to the part.
														char* esoItemId = NULL;
														char* rev = NULL;
														char* revStr = NULL;
														char* seqStr = NULL;
														int esoFlag =0;
														
														int p= 0;
														
														CALLAPI (AOM_UIF_ask_value(partTag,"item_revision_id",&rev));
														printf("\nESO::rev:%s\n",rev); fflush(stdout);
														
														if(tc_strstr(rev,";") != NULL)
														{
															revStr = tc_strtok ( rev,";") ;
															seqStr = tc_strtok ( NULL,";") ;	
														}
														
														printf("\nESO :validatesignoff:seqStr:%s",seqStr); fflush(stdout);													
														esoItemId = (char*)MEM_alloc(strlen(partNo)*sizeof(char) + 30);
														tc_strcpy(esoItemId,"");
														tc_strcat(esoItemId,"ESO_");
														tc_strcat(esoItemId,partNo);
														tc_strcat(esoItemId,"_");
														tc_strcat(esoItemId,rev);
														tc_strcat(esoItemId,"_");
														tc_strcat(esoItemId,seqStr);
														for(p=0;p<esoCnt;p++)
														{
															tag_t esoTg = NULLTAG;
															char* esoNum = NULL;
															esoTg = esoTags[p];
															
															CALLAPI(AOM_ask_value_string(esoTg,"item_id",&esoNum));
															printf("\nESO:esoNum: %s",esoNum); fflush(stdout);

															if(tc_strcmp(esoItemId,esoNum)==0)
															{
																printf("\n ESO object %s is already attached to the part %s. No need to create again ESO object \n",esoItemId,partNo );fflush(stdout);
																esoFlag++;
																break;
															}
																				
														}
														if(esoFlag ==0)
														{
															printf("\n %s does not has ESO status. Please create ESO status\n",partNo);fflush(stdout);
															char* buff = NULL;
															ifail=T5_WorkFlowHandlerESOErr;
															buff = (char*)MEM_alloc(200*sizeof(char));
															sprintf(buff, "No ESO Status object %s found for the part[%s].", esoItemId, partNo);
															EMH_store_error_s1(EMH_severity_error,ifail,buff);
															decision = EPM_nogo;
															if(buff)MEM_free(buff);
															return decision;													
														}

														
													}
																									

												}
											}										
																						
											
										
										}
										
										
										
										
									}									
								}
																				
								
							}
							
						}
					}
					
			
				}
				
				
			}
			
			
	
						
		}
		else
		{
			printf("\n NOT Live for rule handler check for ESO sign off....\n");fflush(stdout);
		}
		

	}
	

	return decision;
}




int  isApplicableForESOReviewForDml(tag_t dmlTag, logical *output)
{
	int ifail = ITK_ok;

	const char * prog_name ="isApplicableForESOReview";
	char*	username 	=	NULL;
	tag_t	user_tag	=	NULLTAG;
	tag_t	cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
	
	*output = FALSE;
	
	POM_get_user(&username,&user_tag);
	printf("\nESO: Starting for username :%s....\n",username);fflush(stdout);

	if(dmlTag==NULLTAG)
	{
		printf("\n Null Dml Tag passed.. Exiting from the function isApplicableForESOReview\n");fflush(stdout);
	}
	CALLAPI(isLiveForESOReview(&cntrlObj,&liveFlag));
	if(!liveFlag)
	{
		printf("\nESO: NOT Live for ESO Review- Check for control object ESOREV");fflush(stdout);
		return ifail;
	}
	
	if(cntrlObj != NULLTAG && liveFlag)
	{
		

		char* dmlReleaseType = NULL;			
		char* dmlRelTypeDisplayStr = NULL;
		char* dmlBusUnit	=	NULL;
		char* dmlBusUnitStr	=	NULL;
		char* userInfo1	=	NULL;
		char* userInfo2	= NULL;
		char* userInfo3	=	NULL;
		char* userInfo4	=	NULL;
		char* userInfo5	=	NULL;		
		
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
		
		printf("\nESORev Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5);fflush(stdout);		
		
		CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlReleaseType));
		CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_rlstype",&dmlRelTypeDisplayStr));
		CALLAPI(AOM_ask_value_string(dmlTag,"t5_ERCBusiUt",&dmlBusUnit));
		CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_ERCBusiUt",&dmlBusUnitStr));
		
		printf("\nESO: DML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);fflush(stdout);
		printf("\nESO: DML Business Unit:%s===>%s\n",dmlBusUnit,dmlBusUnitStr);fflush(stdout);
		char* dmlBusUnitS = NULL;
		dmlBusUnitS = (char*)MEM_alloc(200);
		tc_strcpy(dmlBusUnitS,",");
		tc_strcat(dmlBusUnitS,dmlBusUnit);
		tc_strcat(dmlBusUnitS,",");
		printf("\nESO: dmlBusUnitS:%s\n",dmlBusUnitS);fflush(stdout);		

		if(tc_strstr(userInfo1,dmlBusUnitS)!=NULL)
		{
			//if((tc_strcmp(dmlReleaseType,"Veh")==0))
			if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);	
			if(tc_strstr(userInfo2,dmlReleaseType)!=NULL)	
			{
				printf("\nESO: DML Release Type %s is valid for ESO sign off step", dmlRelTypeDisplayStr);fflush(stdout);
				 
				logical  result = false;							
				
				CALLAPI(isESODmlDR4andAboveDML(dmlTag, &result));
				printf("\nESO: Is DR 4 and above DML: %d\n",result);fflush(stdout);
				//result =true;
				if(result)
				{
					//If TODR dml then check it is migrating vehicle/CCV  or Engine Module
					
					//Get the DML task
					tag_t *dmlTaskTagObjects = NULL;
					tag_t dmlTaskTag = NULLTAG;
					int taskCnt = 0;								
					CALLAPI(AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects));
					printf("\nESO: DML ERC Task Count:%d\n",taskCnt);fflush(stdout);
					
					if(taskCnt>0)
					{
						int j=0;
						char* object_type	=	NULL;
						
						for(j=0;j<taskCnt;j++)
						{
							dmlTaskTag = dmlTaskTagObjects[j];
							CALLAPI(AOM_ask_value_string(dmlTaskTag,"object_type",&object_type));
							printf("\nESO: DML Task object_type is :%s\n",object_type);fflush(stdout);
							
							if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
							{
								int partCnt=0;
								tag_t *partTagObjects = NULL;
								tag_t partTag = NULLTAG;
								CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMReferences",&partCnt,&partTagObjects));
								//CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMHasSolutionItem",&partCnt,&partTagObjects));
								printf("\nESO:Part Count:%d\n",partCnt);fflush(stdout);
								
								if(partCnt>0)
								{
									int p=0;
									char* part_object_type = NULL;
									char* partNo = NULL;
									char* partType = NULL;
									
									for(p=0;p<partCnt;p++)
									{
										partTag = partTagObjects[p];
										CALLAPI(AOM_ask_value_string(partTag,"object_type",&part_object_type));
										printf("\nESO: object_type of part is :%s\n",part_object_type);fflush(stdout);
										
										if(tc_strcmp(part_object_type,"Design Revision")==0)
										{
											CALLAPI(AOM_ask_value_string(partTag,"item_id",&partNo));
											printf("\nESO: Item ID:%s\n",partNo);fflush(stdout);
											//t5_PartType
											
											CALLAPI(AOM_ask_value_string(partTag,"t5_PartType",&partType));
											printf("\nESO: Part Type of the part:%s\n",partType);fflush(stdout);
											
											if(tc_strcmp(userInfo4,partType) == 0 || tc_strcmp(partType,"V")==0 || tc_strcmp(partType,"CCVC")==0 || tc_strcmp(partType,"VCCR")== 0)
											{
												printf("\nESO: APPLICABLE FOR ESO STEP - check for eso object");fflush(stdout);
												*output = TRUE;
												return ifail; //Go to error path
											}
											else if(tc_strcmp(partType,"M")==0 || tc_strcmp(partType,"T")==0)//CR-FY24-0033 - For Part Type Module and Design Group 00, 26
											{
												printf("\nESO: Part Type Module");fflush(stdout);
												char* desGrp = NULL;
												ifail = AOM_ask_value_string(partTag,"t5_DesignGrp",&desGrp);
												printf("\nESO: Design Group: %s\n", desGrp);fflush(stdout);
												if(tc_strcmp(desGrp,"00")==0 || tc_strcmp(desGrp,"26")==0)
												{
													printf("\nESO: Module : APPLICABLE FOR ESO STEP");fflush(stdout);
													*output = TRUE;
													return ifail; //Go to error path
												}
											}
											
										}
										
										
										
										
									}
								}
								
								
							}
							
							
						}
					}
					
					
					
					
					
					
					
				
				}
				else
				{
					printf("\nESO: Not a DR 4 and above DML: ESO step not applicable");fflush(stdout);
				}
				
				
				

			}						
		}
		else
		{
			if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);
			printf("\nESO: Not Valid Business Unit.Not applicable for ESO");fflush(stdout);
		}
		
					
		
	}
	
	
	
	

		



	
	return ifail;
	
}



int  isApplicableForESOReview(tag_t dmlTask, logical *output)
{
	int ifail = ITK_ok;

	const char * prog_name ="isApplicableForESOReview";
	char*	username 	=	NULL;
	tag_t	user_tag	=	NULLTAG;
	tag_t	cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
	
	*output = FALSE;
	
	POM_get_user(&username,&user_tag);
	printf("\nESO: Starting for username :%s....\n",username);fflush(stdout);

	if(dmlTask==NULLTAG)
	{
		printf("\n Null Dml Task Tag passed.. Exiting from the function isApplicableForESOReview\n");fflush(stdout);
	}
	CALLAPI(isLiveForESOReview(&cntrlObj,&liveFlag));
	if(!liveFlag)
	{
		printf("\nESO: NOT Live for ESO Review- Check for control object ESOREV");fflush(stdout);
		return ifail;
	}
	
	if(cntrlObj != NULLTAG && liveFlag)
	{
		
		tag_t* dmlTags = NULL;
		tag_t dmlTag = NULLTAG;
		tag_t tsk_dml_rel_type = NULLTAG;
		int taskcnt = 0;
		
		char* dmlReleaseType = NULL;			
		char* dmlRelTypeDisplayStr = NULL;
		char* dmlBusUnit	=	NULL;
		char* dmlBusUnitStr	=	NULL;
		char* userInfo1	=	NULL;
		char* userInfo2	= NULL;
		char* userInfo3	=	NULL;
		char* userInfo4	=	NULL;
		char* userInfo5	=	NULL;		
		
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
		
		printf("\nESORev Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5);fflush(stdout);

		//Get the dml tag from dml task
		CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
        if (tsk_dml_rel_type!=NULLTAG)
		{
			int jy =0;
			int dmlCnt = 0;
			CALLAPI(GRM_list_primary_objects_only(dmlTask,tsk_dml_rel_type,&dmlCnt,&dmlTags));
			printf("\n\n\t\t DML Revision from Task: %d",dmlCnt);fflush(stdout);
			
			for (jy=0;jy<dmlCnt ;jy++ )
			{
				logical is_latest = false;
				
				if(ITEM_rev_sequence_is_latest(dmlTags[jy],&is_latest));
				printf("\n\n\t\t is_latest MR is : %d\n",is_latest);fflush(stdout);

				if(is_latest != true)
				{
					printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
				}
				else
				{
					dmlTag = dmlTags[jy];

				}
			}			

			
		}
		
		if(dmlTag == NULLTAG)
		{
			printf("\n isApplicableForESOReview ... Null Dml Tag found for the DML Task.Exiting....\n");fflush(stdout);
		}

		
		
		CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlReleaseType));
		CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_rlstype",&dmlRelTypeDisplayStr));
		CALLAPI(AOM_ask_value_string(dmlTag,"t5_ERCBusiUt",&dmlBusUnit));
		CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_ERCBusiUt",&dmlBusUnitStr));
		
		printf("\nESO: DML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);fflush(stdout);
		printf("\nESO: DML Business Unit:%s===>%s\n",dmlBusUnit,dmlBusUnitStr);fflush(stdout);
		char* dmlBusUnitS = NULL;
		dmlBusUnitS = (char*)MEM_alloc(200);
		tc_strcpy(dmlBusUnitS,",");
		tc_strcat(dmlBusUnitS,dmlBusUnit);
		tc_strcat(dmlBusUnitS,",");
		printf("\nESO: dmlBusUnitS:%s\n",dmlBusUnitS);fflush(stdout);		

		if(tc_strstr(userInfo1,dmlBusUnitS)!=NULL)
		{
			//if((tc_strcmp(dmlReleaseType,"Veh")==0))
			if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);
			if(tc_strstr(userInfo2,dmlReleaseType)!=NULL)	
			{
				printf("\nESO: DML Release Type %s is valid for ESO sign off step", dmlRelTypeDisplayStr);fflush(stdout);
				 
				logical  result = false;							
				
				CALLAPI(isESODmlDR4andAboveDML(dmlTag, &result));
				printf("\nESO: Is DR 4 and above DML: %d\n",result);fflush(stdout);
				//result =true;
				if(result)
				{
					//If TODR dml then check it is migrating vehicle/CCV  or Engine Module
					
					//Get the DML task
					tag_t *dmlTaskTagObjects = NULL;
					tag_t dmlTaskTag = NULLTAG;
					int taskCnt = 0;								
					CALLAPI(AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects));
					printf("\nESO: DML ERC Task Count:%d\n",taskCnt);fflush(stdout);
					
					if(taskCnt>0)
					{
						int j=0;
						char* object_type	=	NULL;
						
						for(j=0;j<taskCnt;j++)
						{
							dmlTaskTag = dmlTaskTagObjects[j];
							CALLAPI(AOM_ask_value_string(dmlTaskTag,"object_type",&object_type));
							printf("\nESO: DML Task object_type is :%s\n",object_type);fflush(stdout);
							
							if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
							{
								int partCnt=0;
								tag_t *partTagObjects = NULL;
								tag_t partTag = NULLTAG;
								CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMReferences",&partCnt,&partTagObjects));
								//CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMHasSolutionItem",&partCnt,&partTagObjects));
								printf("\nESO:Part Count:%d\n",partCnt);fflush(stdout);
								
								if(partCnt>0)
								{
									int p=0;
									char* part_object_type = NULL;
									char* partNo = NULL;
									char* partType = NULL;
									
									for(p=0;p<partCnt;p++)
									{
										partTag = partTagObjects[p];
										CALLAPI(AOM_ask_value_string(partTag,"object_type",&part_object_type));
										printf("\nESO: object_type of part is :%s\n",part_object_type);fflush(stdout);
										
										if(tc_strcmp(part_object_type,"Design Revision")==0)
										{
											CALLAPI(AOM_ask_value_string(partTag,"item_id",&partNo));
											printf("\nESO: Item ID:%s\n",partNo);fflush(stdout);
											//t5_PartType
											
											CALLAPI(AOM_ask_value_string(partTag,"t5_PartType",&partType));
											printf("\nESO: Part Type of the part:%s\n",partType);fflush(stdout);
											
											if(tc_strcmp(userInfo4,partType) == 0 || tc_strcmp(partType,"V")==0 || tc_strcmp(partType,"CCVC")==0 || tc_strcmp(partType,"VCCR")==0)
											{
												printf("\nESO: APPLICABLE FOR ESO STEP - check for eso object");fflush(stdout);
												*output = TRUE;
												return ifail; //Go to error path
											}
											else if(tc_strcmp(partType,"M")==0 || tc_strcmp(partType,"T")==0)//CR-FY24-0033 - For Part Type Module and Design Group 00, 26
											{
												printf("\nESO: Part Type Module");fflush(stdout);
												char* desGrp = NULL;
												ifail = AOM_ask_value_string(partTag,"t5_DesignGrp",&desGrp);
												printf("\nESO: Design Group: %s\n", desGrp);fflush(stdout);
												if(tc_strcmp(desGrp,"00")==0 || tc_strcmp(desGrp,"26")==0)
												{
													printf("\nESO: Module : APPLICABLE FOR ESO STEP");fflush(stdout);
													*output = TRUE;
													return ifail; //Go to error path
												}
											}											
											
										}
										
										
										
										
									}
								}
								
								
							}
							
							
						}
					}
					
					
					
					
					
					
					
				
				}
				else
				{
					printf("\nESO: Not a DR 4 and above DML: ESO step not applicable");fflush(stdout);
				}
				
				
				

			}						
		}
		else
		{
			if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);
			printf("\nESO: Not Valid Business Unit.Not applicable for ESO");fflush(stdout);
		}
		
					
		
	}
	
	
	
	

		



	
	return ifail;
	
}



int  isDR4DmlForESOReview(tag_t cntrlObj, tag_t dmlTask, logical *output)
{
	int ifail = ITK_ok;

	const char * prog_name ="isDR4DmlForESOReview";
	char*	username 	=	NULL;
	tag_t	user_tag	=	NULLTAG;
	
	
	*output = FALSE;
	
	POM_get_user(&username,&user_tag);
	printf("\nESO:isDR4DmlForESOReview Starting for username :%s....\n",username);fflush(stdout);

	if(dmlTask==NULLTAG)
	{
		printf("\n Null Dml Task Tag passed.. Exiting from the function isApplicableForESOReview\n");fflush(stdout);
		return ifail;
	}
	
	
	if(cntrlObj != NULLTAG)
	{
		
		tag_t* dmlTags = NULL;
		tag_t dmlTag = NULLTAG;
		tag_t tsk_dml_rel_type = NULLTAG;
		int taskcnt = 0;
		
		char* dmlReleaseType = NULL;			
		char* dmlRelTypeDisplayStr = NULL;
		char* dmlBusUnit	=	NULL;
		char* dmlBusUnitStr	=	NULL;
		char* userInfo1	=	NULL;
		char* userInfo2	= NULL;
		char* userInfo3	=	NULL;
		char* userInfo4	=	NULL;
		char* userInfo5	=	NULL;		
		
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
		
		printf("\nESORev Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5);fflush(stdout);

		//Get the dml tag from dml task
		CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
        if (tsk_dml_rel_type!=NULLTAG)
		{
			int jy =0;
			int dmlCnt = 0;
			CALLAPI(GRM_list_primary_objects_only(dmlTask,tsk_dml_rel_type,&dmlCnt,&dmlTags));
			printf("\n\n\t\t DML Revision from Task: %d",dmlCnt);fflush(stdout);
			
			for (jy=0;jy<dmlCnt ;jy++ )
			{
				logical is_latest = false;
				
				if(ITEM_rev_sequence_is_latest(dmlTags[jy],&is_latest));
				printf("\n\n\t\t is_latest MR is : %d\n",is_latest);fflush(stdout);

				if(is_latest != true)
				{
					printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
				}
				else
				{
					dmlTag = dmlTags[jy];

				}
			}			

			
		}
		
		if(dmlTag == NULLTAG)
		{
			printf("\n isApplicableForESOReview ... Null Dml Tag found for the DML Task.Exiting....\n");fflush(stdout);
		}

		
		
		CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlReleaseType));
		CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_rlstype",&dmlRelTypeDisplayStr));
		CALLAPI(AOM_ask_value_string(dmlTag,"t5_ERCBusiUt",&dmlBusUnit));
		CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_ERCBusiUt",&dmlBusUnitStr));
		
		printf("\nESO: DML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);fflush(stdout);
		printf("\nESO: DML Business Unit:%s===>%s\n",dmlBusUnit,dmlBusUnitStr);fflush(stdout);
		char* dmlBusUnitS = NULL;
		dmlBusUnitS = (char*)MEM_alloc(200);
		tc_strcpy(dmlBusUnitS,",");
		tc_strcat(dmlBusUnitS,dmlBusUnit);
		tc_strcat(dmlBusUnitS,",");
		printf("\nESO: dmlBusUnitS:%s\n",dmlBusUnitS);fflush(stdout);		

		if(tc_strstr(userInfo1,dmlBusUnitS)!=NULL)
		{
			//if((tc_strcmp(dmlReleaseType,"Veh")==0))
			if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);	
			if(tc_strstr(userInfo2,dmlReleaseType)!=NULL)	
			{
				printf("\nESO: DML Release Type %s is valid for ESO sign off step", dmlRelTypeDisplayStr);fflush(stdout);
				 
				logical  result = false;							
				
				CALLAPI(isESODmlDR4andAboveDML(dmlTag, &result));
				printf("\nESO: Is DR 4 and above DML: %d\n",result);fflush(stdout);
				//result =true;
				if(result)
				{

					
					*output = TRUE;
					return ifail;
					
				
				}
				else
				{
					printf("\nESO: Not a DR 4 and above DML: ESO step not applicable");fflush(stdout);
				}
				
				
				

			}						
		}
		else
		{
			if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);
			printf("\nESO: Not Valid Business Unit.Not applicable for ESO");fflush(stdout);
		}
		
		
					
		
	}
	
	
	
	

		



	
	return ifail;
	
}



EPM_decision_t tm_ValidateESOSignOffTaskFn( EPM_rule_message_t msg)
{
	EPM_decision_t	decision = EPM_go;
	int ifail = ITK_ok;
	//char* dmlRelTypeDisplayStr = NULL;
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	rootTask = NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	const char * prog_name ="tm_ValidateESOSignOffTaskFn";
	tag_t dmlTaskTag = NULLTAG;
	
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
		
	POM_get_user(&username,&user_tag);
	//printf("\nStarting for username :%s....\n",username);fflush(stdout);
	
	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	//printf("\nRoot task found");fflush(stdout);
	
	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
	//printf("\nCurrent Task:%s\n",currentTaskName);fflush(stdout);

	CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
	//printf("\nParent Name:%s\n",parentTaskName);fflush(stdout);	
	
	CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
	//printf("\ntargetobjects_count:%d\n",targetobjects_count);fflush(stdout);	
	
	CALLAPI(isLiveForESOReview(&cntrlObj,&liveFlag));
	
	
	printf("\n Live for ESO check in rule handler ===> %d\n",liveFlag);fflush(stdout);
	
	if(liveFlag && cntrlObj!=NULLTAG)
	{
		
		char* userInfo8 = NULL;
		char* userInfo5 = NULL;
		char* userInfo4 = NULL;

		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
		printf("\nESO: userinfo8:%s    userinfo5: %s  userinfo4: %s\n",userInfo8, userInfo5,userInfo4);fflush(stdout);
		
		if(tc_strcmp(userInfo8,"YES")==0)
		{
			
			
			printf("\nESO: Live for rule handler check for ESO....\n");fflush(stdout);
			if(targetobjects_count > 0)
			{
				int i =0;
				tag_t objectTypeTag = NULLTAG;
				char *type_name = NULL;
				
				for(i=0;i<targetobjects_count;i++)
				{
					CALLAPI(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
					CALLAPI(TCTYPE_ask_name2( objectTypeTag, &type_name));
					printf("\ntype_name ==> %s\n", type_name);fflush(stdout);
					if (tc_strcmp(type_name,"T5_ChangeTaskRevision")==0)
					{
					    dmlTaskTag = targetobjects[i];
						break;										
							
					}
				}
				
				if(dmlTaskTag !=NULLTAG)
				{
					char* object_type = NULL;

					CALLAPI(AOM_ask_value_string(dmlTaskTag,"object_type",&object_type));
					printf("\nESO: DML Task object_type is :%s\n",object_type);fflush(stdout);
					if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
					{
						int partCnt=0;
						tag_t *partTagObjects = NULL;
						tag_t partTag = NULLTAG;
						logical output = false;
						//Check if the DML is DR4 and Veh/GM dml.
						CALLAPI(isDR4DmlForESOReview(cntrlObj,dmlTaskTag,&output));
						printf("\n is Dr4 dml for ESO review ===> %d\n",output);fflush(stdout);
						
						if(output)
						{
							
							CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMReferences",&partCnt,&partTagObjects));
							//CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMHasSolutionItem",&partCnt,&partTagObjects));
							printf("\nESO:Part Count:%d\n",partCnt);fflush(stdout);
							if(partCnt>0)
							{
								int p=0;
								char* part_object_type = NULL;
								char* partNo = NULL;
								char* partType = NULL;
								
								for(p=0;p<partCnt;p++)
								{
									partTag = partTagObjects[p];
									CALLAPI(AOM_ask_value_string(partTag,"object_type",&part_object_type));
									printf("\nESO: object_type of part is :%s\n",part_object_type);fflush(stdout);
									
									if(tc_strcmp(part_object_type,"Design Revision")==0)
									{
										CALLAPI(AOM_ask_value_string(partTag,"item_id",&partNo));
										printf("\nESO: Item ID:%s\n",partNo);fflush(stdout);
										//t5_PartType
										
										CALLAPI(AOM_ask_value_string(partTag,"t5_PartType",&partType));
										printf("\nESO: Part Type of the part:%s\n",partType);fflush(stdout);
										
										if(tc_strcmp(userInfo4,partType)==0 || tc_strcmp(partType,"V")==0 || tc_strcmp(partType,"CCVC")==0 || tc_strcmp(partType,"VCCR")==0)
										{
											printf("\nESO: APPLICABLE FOR ESO STEP");fflush(stdout);
											
											//check if applicable for ESO.
											
											//Get ESO Status object
											int esoCnt =0;
											tag_t* esoTags = NULL;
											CALLAPI(AOM_ask_value_tags(partTag,"T5_PartEsoRel",&esoCnt,&esoTags));
											
											if(esoCnt==0)
											{
												printf("\n %s does not has ESO status. Please create ESO status\n",partNo);fflush(stdout);
												char* buff = NULL;
												ifail=T5_WorkFlowHandlerESOErr;
												buff = (char*)MEM_alloc(300*sizeof(char));
												sprintf(buff, "No ESO Status object found for the part[%s]. Please create ESO object.\nSelect the Vehicle/CCVC.Go to File-->New-->Document Management-->Create ESO Object", partNo);
												EMH_store_error_s1(EMH_severity_error,ifail,buff);
												decision = EPM_nogo;
												if(buff)MEM_free(buff);
												return decision;
											}
											
											if(esoCnt >0 )
											{
												//Check if ESO object is there but check if correct ESO object is attached to the part.
												char* esoItemId = NULL;
												char* rev = NULL;
												char* revStr = NULL;
												char* seqStr = NULL;
												int esoFlag =0;
												
												int p= 0;
												
												CALLAPI (AOM_UIF_ask_value(partTag,"item_revision_id",&rev));
												printf("\nESO::rev:%s\n",rev); fflush(stdout);
												
												if(tc_strstr(rev,";") != NULL)
												{
													revStr = tc_strtok ( rev,";") ;
													seqStr = tc_strtok ( NULL,";") ;	
												}
												
												printf("\nESO :validatesignoff:seqStr:%s",seqStr); fflush(stdout);													
												esoItemId = (char*)MEM_alloc(strlen(partNo)*sizeof(char) + 30);
												tc_strcpy(esoItemId,"");
												tc_strcat(esoItemId,"ESO_");
												tc_strcat(esoItemId,partNo);
												tc_strcat(esoItemId,"_");
												tc_strcat(esoItemId,rev);
												tc_strcat(esoItemId,"_");
												tc_strcat(esoItemId,seqStr);
												for(p=0;p<esoCnt;p++)
												{
													tag_t esoTg = NULLTAG;
													char* esoNum = NULL;
													esoTg = esoTags[p];
													
													CALLAPI(AOM_ask_value_string(esoTg,"item_id",&esoNum));
													printf("\nESO:esoNum: %s",esoNum); fflush(stdout);

													if(tc_strcmp(esoItemId,esoNum)==0)
													{
														printf("\n ESO object %s is already attached to the part %s. No need to create again ESO object \n",esoItemId,partNo );fflush(stdout);
														esoFlag++;
														break;
													}
																		
												}
												if(esoFlag ==0)
												{
													printf("\n %s does not has correct ESO status. Please create ESO status\n",partNo);fflush(stdout);
													char* buff = NULL;
													ifail=T5_WorkFlowHandlerESOErr;
													buff = (char*)MEM_alloc(300*sizeof(char));
													sprintf(buff, "No ESO Status object [%s] attached to the part[%s]. Please create ESO object.\nSelect the Vehicle/CCVC.Go to File-->New-->Document Management-->Create ESO Object", esoItemId, partNo);
													EMH_store_error_s1(EMH_severity_error,ifail,buff);
													decision = EPM_nogo;
													if(buff)MEM_free(buff);
													return decision;													
												}

												
												
												if(esoItemId) MEM_free(esoItemId);
											}
										}
										else if(tc_strcmp(partType,"M")==0 || tc_strcmp(partType,"T")==0)//CR-FY24-0033 - For Part Type Module and Design Group 00, 26
										{
											printf("\nESO: Part Type Module");fflush(stdout);
											char* desGrp = NULL;
											ifail = AOM_ask_value_string(partTag,"t5_DesignGrp",&desGrp);
											printf("\nESO: Design Group: %s\n", desGrp);fflush(stdout);
											if(tc_strcmp(desGrp,"00")==0 || tc_strcmp(desGrp,"26")==0)
											{
												printf("\nESO: APPLICABLE FOR ESO STEP");fflush(stdout);
												
												//check if applicable for ESO.
												
												//Get ESO Status object
												int esoCnt =0;
												tag_t* esoTags = NULL;
												CALLAPI(AOM_ask_value_tags(partTag,"T5_PartEsoRel",&esoCnt,&esoTags));
												
												if(esoCnt==0)
												{
													printf("\n %s does not has ESO status. Please create ESO status\n",partNo);fflush(stdout);
													char* buff = NULL;
													ifail=T5_WorkFlowHandlerESOErr;
													buff = (char*)MEM_alloc(300*sizeof(char));
													sprintf(buff, "No ESO Status object found for the part[%s]. Please create ESO object.\nSelect the Vehicle/CCVC.Go to File-->New-->Document Management-->Create ESO Object", partNo);
													EMH_store_error_s1(EMH_severity_error,ifail,buff);
													decision = EPM_nogo;
													if(buff)MEM_free(buff);
													return decision;
												}
											
												if(esoCnt >0 )
												{
													//Check if ESO object is there but check if correct ESO object is attached to the part.
													char* esoItemId = NULL;
													char* rev = NULL;
													char* revStr = NULL;
													char* seqStr = NULL;
													int esoFlag =0;
													
													int p= 0;
													
													CALLAPI (AOM_UIF_ask_value(partTag,"item_revision_id",&rev));
													printf("\nESO::rev:%s\n",rev); fflush(stdout);
													
													if(tc_strstr(rev,";") != NULL)
													{
														revStr = tc_strtok ( rev,";") ;
														seqStr = tc_strtok ( NULL,";") ;	
													}
													
													printf("\nESO :validatesignoff:seqStr:%s",seqStr); fflush(stdout);													
													esoItemId = (char*)MEM_alloc(strlen(partNo)*sizeof(char) + 30);
													tc_strcpy(esoItemId,"");
													tc_strcat(esoItemId,"ESO_");
													tc_strcat(esoItemId,partNo);
													tc_strcat(esoItemId,"_");
													tc_strcat(esoItemId,rev);
													tc_strcat(esoItemId,"_");
													tc_strcat(esoItemId,seqStr);
													for(p=0;p<esoCnt;p++)
													{
														tag_t esoTg = NULLTAG;
														char* esoNum = NULL;
														esoTg = esoTags[p];
														
														CALLAPI(AOM_ask_value_string(esoTg,"item_id",&esoNum));
														printf("\nESO:esoNum: %s",esoNum); fflush(stdout);

														if(tc_strcmp(esoItemId,esoNum)==0)
														{
															printf("\n ESO object %s is already attached to the part %s. No need to create again ESO object \n",esoItemId,partNo );fflush(stdout);
															esoFlag++;
															break;
														}
																			
													}
													if(esoFlag ==0)
													{
														printf("\n %s does not has correct ESO status. Please create ESO status\n",partNo);fflush(stdout);
														char* buff = NULL;
														ifail=T5_WorkFlowHandlerESOErr;
														buff = (char*)MEM_alloc(300*sizeof(char));
														sprintf(buff, "No ESO Status object [%s] attached to the part[%s]. Please create ESO object.\nSelect the Vehicle/CCVC.Go to File-->New-->Document Management-->Create ESO Object", esoItemId, partNo);
														EMH_store_error_s1(EMH_severity_error,ifail,buff);
														decision = EPM_nogo;
														if(buff)MEM_free(buff);
														return decision;													
													}

													
													
													if(esoItemId) MEM_free(esoItemId);
												}												
												
											}
										}										
										
									}
									
									
									
									
								}									
							}
																			
														
							
						}
						else
						{
							printf("\n not applicable eso check\n");fflush(stdout);
						}
						

					}
					

					
			
				}
				
				
			}
			
			
	
						
		}
		else
		{
			printf("\n NOT Live for rule handler check for ESO sign off....\n");fflush(stdout);
		}
		

	}
	

	return decision;
}






int isLiveForESOSendMail(tag_t *contrlTag, logical *result)
{
	int ifail = ITK_ok;
	printf("\nESO: Check for control object ESOMAIL....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "ESOMAIL";
	qry_values[1] = "ESOMAIL";
	qry_values[2] = "FALSE";
		
	CALLAPI(QRY_find2("Control Objects...", &query));
	CALLAPI(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	printf("\nESO:Control objects ESOMAIL: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* usrInfo3 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{
			char* cntrlStr = NULL;
			CALLAPI(AOM_ask_value_string(cntrlObj,"object_string",&cntrlStr));
			printf("\nESO: Control object ===>%s", cntrlStr);fflush(stdout);
			
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&usrInfo3));
			printf("\nESO: Control object user info 3 ===>%s", usrInfo3);fflush(stdout);
/* 			if(tc_strstr(usrInfo3,"YES")!=NULL)
			{
				printf("\nESO: Live for ESO  Mail Send  through lifecycle\n");fflush(stdout);
				*result = TRUE;
			} */
			printf("\nESO: Live for ESO  Mail Send  through lifecycle\n");fflush(stdout);
			*result = TRUE;			
			*contrlTag = cntrlObj;
			
		}
		
	}
	
	return ifail;
}

int isESODmlGivenDRandAboveDML(tag_t dmlTag, tag_t cntrlObj, logical *result)
{
	int ifail = ITK_ok;
	*result = FALSE;
	if(dmlTag != NULLTAG)
	{
		char* objTyp = NULL;
		CALLAPI(AOM_ask_value_string(dmlTag,"object_type",&objTyp));
		printf("\nESO:DML object type: [%s]", objTyp);fflush(stdout);
		if(tc_strcmp(objTyp,"ChangeRequestRevision")==0)
		{
			char* relzType = NULL;
			
			char* plntToPlnt1 = NULL;
			
			char* dmlDrStatus1 = NULL;
			char* userInfo1	=	NULL;
			char* userInfo2	= NULL;
			char* userInfo3	=	NULL;
			char* userInfo4	=	NULL;
			char* userInfo5	=	NULL;
			char* userInfo6	=	NULL;
			char* userInfo7	=	NULL;
			char* userInfo8	=	NULL;
			char* userInfo9	=	NULL;
			
			
			
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
			
			
			printf("\nESORev Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\nt5_Userinfo6:[%s]\nt5_Userinfo7:[%s]\nt5_Userinfo8:[%s]\nt5_Userinfo9:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);			
			
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&relzType));
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_PlntToPlnt",&plntToPlnt1));
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_cDRstatus",&dmlDrStatus1));
			printf("\nESO:Release Type: %s\nESO:FromPlantToPlant: %s\nESO:Dml Dr Status:%s\n",relzType,plntToPlnt1,dmlDrStatus1);fflush(stdout);
				
			
					
			
			if(tc_strcmp(relzType,"TODR")==0)
			{
				char* plntToPlnt = NULL;
				plntToPlnt = (char*)MEM_alloc(30);
				tc_strcpy(plntToPlnt,"");
				tc_strcat(plntToPlnt,",");
				tc_strcat(plntToPlnt,plntToPlnt1);
				tc_strcat(plntToPlnt,",");
				printf("\n ESO:From Pant to Plant - Modified [%s]",plntToPlnt);fflush(stdout);					
					
				if(plntToPlnt!=NULL)
				{
					//if(tc_strcmp(plntToPlnt,"AR3 to AR4")==0 || tc_strcmp(plntToPlnt,"DR3 to DR4")==0  ||tc_strcmp(plntToPlnt,"AR3P to AR4")==0 || tc_strcmp(plntToPlnt,"DR3P to DR4")==0 )
					if(tc_strstr(userInfo4,plntToPlnt)!=NULL)
					{
						*result = TRUE;
					}
				}
				if(plntToPlnt)MEM_free(plntToPlnt);
				
			}
			else 
			{
				char* dmlDrStatus = NULL;
				dmlDrStatus = (char*)MEM_alloc(30);
				tc_strcpy(dmlDrStatus,"");
				tc_strcat(dmlDrStatus,",");
				tc_strcat(dmlDrStatus,dmlDrStatus1);
				tc_strcat(dmlDrStatus,",");
				printf("\nESO:From DML DR Status - Modified [%s]",dmlDrStatus);fflush(stdout);	
				if(dmlDrStatus!=NULL)
				{
					//if(tc_strcmp(dmlDrStatus,"DR4")==0 || tc_strcmp(dmlDrStatus,"AR4")==0 || tc_strcmp(dmlDrStatus,"DR5")==0 || tc_strcmp(dmlDrStatus,"AR5")==0)
					if(tc_strstr(userInfo5,dmlDrStatus)!=NULL)
					{
						*result = TRUE;
					}
				}
				if(dmlDrStatus)MEM_free(dmlDrStatus);
			}
			
			
		}
		else
		{
			printf("\nNot a valid DML Revision object\n");fflush(stdout);
		}
	}		
	
	
	return ifail;
}

int addStatusToESORevTag_deprecated(tag_t esoTag)
{
	int ifail = ITK_ok;
	tag_t   release_status =NULLTAG;
	char* ReleaseStatus = NULL;
	logical retain_released_date = TRUE;
	
	//APLC Working - T5_LcsAPLWrkg
	//APLA Working - T5_LcsAPLaWrkg
	
	//STDSIC Working- T5_LcsSTDWrkg
	//STDSIC Released - T5_LcsStdRlzd
	
	//ERC Released - T5_LcsErcRlzd
	CALLAPI(RELSTAT_create_release_status("T5_LcsErcRlzd",&release_status));
	CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

	if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0 )
	{
		CALLAPI(RELSTAT_add_release_status(release_status,1,&esoTag,retain_released_date)); 
	}	
	
	return ifail;
}

int addStatusToESORevTag(tag_t esoTag)
{
	int ifail = ITK_ok;
	tag_t   release_status =NULLTAG;
	char* ReleaseStatus = NULL;
	logical retain_released_date = TRUE;
	
	//APLC Working - T5_LcsAPLWrkg
	//APLA Working - T5_LcsAPLaWrkg
	
	//STDSIC Working- T5_LcsSTDWrkg
	//STDSIC Released - T5_LcsStdRlzd
	
	//ERC Released - T5_LcsErcRlzd
	CALLAPI(RELSTAT_create_release_status("T5_LcsErcRlzd",&release_status));
	CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

	if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0 )
	{
		CALLAPI(RELSTAT_add_release_status(release_status,1,&esoTag,retain_released_date)); 
	}	
	
	return ifail;
}


int  tm_ESOSendMailFun(EPM_action_message_t  msg)
{
	int ifail = ITK_ok;

	const char * prog_name ="tm_ESOSendMailFun";
	char*	username 	=	NULL;
	tag_t	user_tag	=	NULLTAG;
	tag_t	rootTask	= NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
	int applForESO = 0;
	
	CALLAPI(isLiveForESOSendMail(&cntrlObj,&liveFlag)); //Check if control object ESOMAIL-ESOMAIL is present and returns TRUE
	
	printf("\nESO: Live for ESO MAIL notification==>%d\n",liveFlag);fflush(stdout);	
	if(!liveFlag)
	{
		printf("\nESO: Not Live for ESO MAIL notification- Check for control object ESOMAIL");fflush(stdout);
		return ifail;
	}
	if(cntrlObj != NULLTAG && liveFlag)
	{
		POM_get_user(&username,&user_tag);
		printf("\nESO: Starting for username :%s....\n",username);fflush(stdout);
		
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		printf("\nESO: Root task found");fflush(stdout);
		
		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
		printf("\nESO: Current Task:%s\n",currentTaskName);fflush(stdout);

		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
		printf("\nESO: Parent Name:%s\n",parentTaskName);fflush(stdout);	
		
		CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
		
		if(targetobjects_count > 0)
		{
			int i =0;
			tag_t objectTypeTag = NULLTAG;
			char *type_name = NULL;
			char* dmlReleaseType = NULL;			
			char* dmlRelTypeDisplayStr = NULL;
			char* dmlBusUnit	=	NULL;
			char* dmlBusUnitStr	=	NULL;
			char* userInfo1	=	NULL;
			char* userInfo2	= NULL;
			char* userInfo3	=	NULL;
			char* userInfo4	=	NULL;
			char* userInfo5	=	NULL;
			char* userInfo6	=	NULL;
			char* userInfo7	=	NULL;
			char* userInfo8	=	NULL;
			char* userInfo9	=	NULL;
			
			
			
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
			
			
			printf("\nESORev Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\nt5_Userinfo6:[%s]\nt5_Userinfo7:[%s]\nt5_Userinfo8:[%s]\nt5_Userinfo9:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
			
			for(i=0;i<targetobjects_count;i++)
			{
				CALLAPI(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
				CALLAPI(TCTYPE_ask_name2( objectTypeTag, &type_name));
				printf("\nESO: type_name ==> %s\n", type_name);fflush(stdout);
				
				if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
				{
					tag_t dmlTag = NULLTAG;
					applForESO = 0;
					dmlTag = targetobjects[i];
					
					CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlReleaseType));
					CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_rlstype",&dmlRelTypeDisplayStr));
					CALLAPI(AOM_ask_value_string(dmlTag,"t5_ERCBusiUt",&dmlBusUnit));
					CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_ERCBusiUt",&dmlBusUnitStr));
					
					printf("\nESO: DML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);fflush(stdout);
					printf("\nESO: DML Business Unit:%s===>%s\n",dmlBusUnit,dmlBusUnitStr);fflush(stdout);
					char* dmlBusUnitS = NULL;
					dmlBusUnitS = (char*)MEM_alloc(200);
					tc_strcpy(dmlBusUnitS,",");
					tc_strcat(dmlBusUnitS,dmlBusUnit);
					tc_strcat(dmlBusUnitS,",");
					printf("\nESO: dmlBusUnitS:%s\n",dmlBusUnitS);fflush(stdout);					

					if(tc_strstr(userInfo1,dmlBusUnitS)!=NULL)
					{
						//if((tc_strcmp(dmlReleaseType,"Veh")==0))
						if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);	
						if(tc_strstr(userInfo2,dmlReleaseType)!=NULL)	
						{
							printf("\nESO: DML Release Type %s is valid for ESO mail send", dmlRelTypeDisplayStr);fflush(stdout);
							 
							logical  result = false;							
							
							CALLAPI(isESODmlGivenDRandAboveDML(dmlTag, cntrlObj, &result));
							printf("\nESO: Is DR 4 and above DML?: [%d]\n",result);fflush(stdout);
							//result =true;
							if(result)
							{
								if(tc_strcmp(dmlReleaseType,"TODR")==0)
								{
									//If TODR dml then check it is migrating vehicle/CCV  or Engine Module
									
									//Get the DML task
									tag_t *dmlTaskTagObjects = NULL;
									tag_t dmlTaskTag = NULLTAG;
									int taskCnt = 0;								
									CALLAPI(AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects));
									printf("\nESO: DML ERC Task Count:%d\n",taskCnt);fflush(stdout);
									
									if(taskCnt>0)
									{
										int j=0;
										char* object_type	=	NULL;
										
										for(j=0;j<taskCnt;j++)
										{
											dmlTaskTag = dmlTaskTagObjects[j];
											CALLAPI(AOM_ask_value_string(dmlTaskTag,"object_type",&object_type));
											printf("\nESO: DML Task object_type is :%s\n",object_type);fflush(stdout);
											
											if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
											{
												int partCnt=0;
												tag_t *partTagObjects = NULL;
												tag_t partTag = NULLTAG;
												CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMReferences",&partCnt,&partTagObjects));
												//CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMHasSolutionItem",&partCnt,&partTagObjects));
												printf("\nESO:Part Count:%d\n",partCnt);fflush(stdout);
												
												if(partCnt>0)
												{
													int p=0;
													char* part_object_type = NULL;
													char* partNo = NULL;
													char* partType = NULL;
													
													for(p=0;p<partCnt;p++)
													{
														
														partTag = partTagObjects[p];
														CALLAPI(AOM_ask_value_string(partTag,"object_type",&part_object_type));
														printf("\nESO: object_type of part is :%s\n",part_object_type);fflush(stdout);
														
														if(tc_strcmp(part_object_type,"Design Revision")==0)
														{
															char* partTypeS = NULL;
															CALLAPI(AOM_ask_value_string(partTag,"item_id",&partNo));
															printf("\nESO: Item ID:%s\n",partNo);fflush(stdout);
															//t5_PartType
															
															CALLAPI(AOM_ask_value_string(partTag,"t5_PartType",&partType));
															printf("\nESO: Part Type of the part:%s\n",partType);fflush(stdout);
															
															partTypeS = (char*)MEM_alloc(20);
															tc_strcpy(partTypeS,",");
															tc_strcat(partTypeS,partType);
															tc_strcat(partTypeS,",");
															printf("\nESO: Mod Part Type of the part:%s\n",partTypeS);fflush(stdout);
															logical isEngine = FALSE;
															if(tc_strcmp(partType,"M")==0 || tc_strcmp(partType,"T")==0)
															{
																printf("\nESO: Part Type Module");fflush(stdout);
																char* desGrp = NULL;
																ifail = AOM_ask_value_string(partTag,"t5_DesignGrp",&desGrp);
																printf("\nESO: Design Group: %s\n", desGrp);fflush(stdout);
																if(tc_strcmp(desGrp,"00")==0 || tc_strcmp(desGrp,"26")==0)
																{																
																	isEngine = TRUE;																	
																}																
															}
															printf("\nIs Engine:[%d]",isEngine);fflush(stdout);
															
															if(tc_strstr(userInfo6,partTypeS)!=NULL || tc_strcmp(partType,"V")==0 || tc_strcmp(partType,"CCVC")==0|| tc_strcmp(partType,"VCCR")==0 || isEngine)
															{
																//Get for ESO object.
																int esoCnt =0;
																tag_t* esoTags = NULL;
																CALLAPI(AOM_ask_value_tags(partTag,"T5_PartEsoRel",&esoCnt,&esoTags));
																
																if(esoCnt >0 )
																{
																	//Check if ESO object is there but check if correct ESO object is attached to the part.
																	char* esoItemId = NULL;
																	char* rev = NULL;
																	char* revStr = NULL;
																	char* seqStr = NULL;
																	//int esoFlag =0;
																	
																	int p= 0;
																	
																	CALLAPI (AOM_UIF_ask_value(partTag,"item_revision_id",&rev));
																	printf("\nESO::rev:%s\n",rev); fflush(stdout);
																	
																	if(tc_strstr(rev,";") != NULL)
																	{
																		revStr = tc_strtok ( rev,";") ;
																		seqStr = tc_strtok ( NULL,";") ;	
																	}
																	
																	printf("\nESO :validatesignoff:seqStr:%s",seqStr); fflush(stdout);													
																	esoItemId = (char*)MEM_alloc(strlen(partNo)*sizeof(char) + 30);
																	tc_strcpy(esoItemId,"");
																	tc_strcat(esoItemId,"ESO_");
																	tc_strcat(esoItemId,partNo);
																	tc_strcat(esoItemId,"_");
																	tc_strcat(esoItemId,rev);
																	tc_strcat(esoItemId,"_");
																	tc_strcat(esoItemId,seqStr);
																	for(p=0;p<esoCnt;p++)
																	{
																		tag_t esoTg = NULLTAG;
																		char* esoNum = NULL;
																		esoTg = esoTags[p];
																		
																		CALLAPI(AOM_ask_value_string(esoTg,"item_id",&esoNum));
																		printf("\nESO:esoNum: %s",esoNum); fflush(stdout);

																		if(tc_strcmp(esoItemId,esoNum)==0)
																		{
																			//Check for LC state of ESO tag. if not released then stamp to ERC Released.
																			//esoFlag++;
																			char* esoRelStat = NULL;
																			
																			CALLAPI(AOM_UIF_ask_value(esoTg,"release_status_list",&esoRelStat));
																			printf("\nESO:SAN Release status list of ESO object: %s\n",esoRelStat);fflush(stdout);
																			if((tc_strstr(esoRelStat,"T5_LcsErcRlzd")!= NULL) || (tc_strstr(esoRelStat,"ERC Released")!= NULL))
																			{
																				//CALLAPI(addStatusToESORevTag(esoTg));
																				printf("\nSAN: Already ERC Released. No need to stamp again!!!\n");fflush(stdout);
																				
																			}
																			else
																			{
																				CALLAPI(addStatusToESORevTag(esoTg));
																				printf("\nSAN: ERC Released Stamped on ESO Object  %s\n",esoItemId);fflush(stdout);
																				//printf("\nAlready ERC Released. No need to stamp again!!!\n");fflush(stdout);
																			}
																			

																		}
																							
																	}

																	
																}																
																
																
																
																//End ESO object logic.
																
																
																
																printf("\nESO: APPLICABLE FOR ESO MAIL NOTIFICATION STEP");fflush(stdout);
																applForESO++;
																//break; //Go to error path
															} 
															if(partTypeS) MEM_free(partTypeS);
															
														}
														
														
														
														
													}
												}
												
												
											}
											
											
										}
									}
																	
								}

								else
								{
									//to be implemented for Module Release
									//applForESO++;
								}
	
								
							
							}
							else
							{
								printf("\nESO: Not  DR 2 and above DML: ESO Mail notification not applicable");fflush(stdout);
							}
							
							
							

						}
						else
						{
							printf("\nESO: Not Valid DML Release Type.Not applicable for ESO Mail Notification");fflush(stdout);
						}
						
					}
					else
					{
						if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);
						printf("\nESO: Not Valid Business Unit.Not applicable for ESO Mail Notification");fflush(stdout);
					}
					
					
					
				
					printf("\nESO: Is appliocable for ESO?: [%d]\n",applForESO);fflush(stdout);
					if(applForESO>0)
					{
						char* dmlNmb = NULL;
						char*	shellpath	=	NULL;
						char*	sysCmnd	=	NULL;
						char*	clientFlg = NULL;
						printf("\nESO: Valid to go to ESO - execute the client code to send mail.");fflush(stdout);
						
						
						CALLAPI(AOM_ask_value_string(dmlTag,"item_id",&dmlNmb));
						CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&shellpath));
						//CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo1));
						CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&clientFlg));

						if(tc_strstr(clientFlg,",CLIENT,")!= NULL)
						{
							sysCmnd=(char *) MEM_alloc(400);
							tc_strcpy(sysCmnd,shellpath);
							tc_strcat(sysCmnd," ");
							tc_strcat(sysCmnd,dmlNmb);
							printf("\n Start-- Calling shell file tm_sendESOMailNotif.sh using client system command: %s\n",sysCmnd);fflush(stdout);
							system(sysCmnd);
							
							printf("\n End --- Calling shell file tm_sendESOMailNotif.sh using client system command: %s\n",sysCmnd);fflush(stdout);
							
							MEM_free(sysCmnd);							
						}
						else
						{
							printf("\nESO: Shell script execution not live. Check info3 of control object ESOMAIL\n");fflush(stdout);
						}

					}
					else
					{
						printf("\nESO: DML not applicable for ESO Step");fflush(stdout);
					}
					
					
					
				}
			}
		}	
				
	}
	
	
	return ifail;
	
}

/*End -ESO - CR-FY22-0049*/

/*****Start of CR CR-FY24-0083 - ESO mail notification after user creates ESO Part and sign off the Task *****/
int isLiveForESOMailNotif(tag_t *contrlTag, logical *result)
{
	int ifail = ITK_ok;
	printf("\nESO: Check for control object ESONOTIF....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "ESONOTIF";
	qry_values[1] = "ESONOTIF";
	qry_values[2] = "FALSE";
		
	ifail = QRY_find2("Control Objects...", &query);
	ifail = QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs);
	printf("\nESO:Control objects ESONOTIF: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* usrInfo3 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{
			char* cntrlStr = NULL;
			ifail = AOM_ask_value_string(cntrlObj,"object_string",&cntrlStr);
			printf("\nESO: Control object ===>%s", cntrlStr);fflush(stdout);

			printf("\nESO: Live for ESO  Status Notification lifecycle\n");fflush(stdout);
			*result = TRUE;			
			*contrlTag = cntrlObj;
			
		}
		
	}
	
	return ITK_ok;
}

int isESOStepApplicable(tag_t dmlTag, logical* isAplicable)
{
	int ifail = ITK_ok;
	logical liveFlag = FALSE;
	tag_t cntrlObj = NULLTAG;
	*isAplicable = FALSE;
	const char * prog_name ="isESOStepApplicable";
	
	CALLAPI(isLiveForESOReview(&cntrlObj,&liveFlag));
	
	printf("\nESO: Live for ESO Step for valid DML type==>%d\n",liveFlag);fflush(stdout);	
	if(!liveFlag)
	{
		printf("\nESO: NOT Live for ESO Step- Check for control object ESOREV");fflush(stdout);
		return ITK_ok;
	}
	
	if(cntrlObj != NULLTAG && liveFlag)
	{
		char* userInfo1	=	NULL;
		char* userInfo2	=   NULL;
		char* userInfo3	=	NULL;
		char* userInfo4	=	NULL;
		char* userInfo5	=	NULL;
		tag_t objectTypeTag = NULLTAG;
		char* type_name = NULL;
		char* dmlReleaseType = NULL;			
		char* dmlRelTypeDisplayStr = NULL;
		char* dmlBusUnit	=	NULL;
		char* dmlBusUnitStr	=	NULL;		
		
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));

		printf("\nESORev Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5);fflush(stdout);
		
		CALLAPI(TCTYPE_ask_object_type (dmlTag, &objectTypeTag));
		CALLAPI(TCTYPE_ask_name2( objectTypeTag, &type_name));
		printf("\nESO: type_name ==> %s\n", type_name);fflush(stdout);
		
		if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
		{
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlReleaseType));
			CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_rlstype",&dmlRelTypeDisplayStr));
			CALLAPI(AOM_ask_value_string(dmlTag,"t5_ERCBusiUt",&dmlBusUnit));
			CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_ERCBusiUt",&dmlBusUnitStr));

			printf("\nESO: DML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);fflush(stdout);
			printf("\nESO: DML Business Unit:%s===>%s\n",dmlBusUnit,dmlBusUnitStr);fflush(stdout);

			char* dmlBusUnitS = NULL;
			dmlBusUnitS = (char*)MEM_alloc(200);
			tc_strcpy(dmlBusUnitS,",");
			tc_strcat(dmlBusUnitS,dmlBusUnit);
			tc_strcat(dmlBusUnitS,",");
			printf("\nESO: dmlBusUnitS:%s\n",dmlBusUnitS);fflush(stdout);
			
			if(tc_strstr(userInfo1,dmlBusUnitS)!=NULL)
			{
				if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);	
				if(tc_strstr(userInfo2,dmlReleaseType)!=NULL)
				{
					printf("\nESO: DML Release Type %s is valid for ESO sign off step", dmlRelTypeDisplayStr);fflush(stdout);
					 
					logical  result = false;							
					
					CALLAPI(isESODmlDR4andAboveDML(dmlTag, &result));
					printf("\nESO: Is DR 4 and above DML: %d\n",result);fflush(stdout);
					//result =true;
					if(result)
					{
						//If TODR dml then check it is migrating vehicle/CCV  or Engine Module
						
						//Get the DML task
						tag_t *dmlTaskTagObjects = NULL;
						tag_t dmlTaskTag = NULLTAG;
						int taskCnt = 0;								
						CALLAPI(AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects));
						printf("\nESO: DML ERC Task Count:%d\n",taskCnt);fflush(stdout);
						
						if(taskCnt>0)
						{
							int j=0;
							char* object_type	=	NULL;
							
							for(j=0;j<taskCnt;j++)
							{
								dmlTaskTag = dmlTaskTagObjects[j];
								CALLAPI(AOM_ask_value_string(dmlTaskTag,"object_type",&object_type));
								printf("\nESO: DML Task object_type is :%s\n",object_type);fflush(stdout);
								
								if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
								{
									int partCnt=0;
									tag_t *partTagObjects = NULL;
									tag_t partTag = NULLTAG;
									CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMReferences",&partCnt,&partTagObjects));
									//CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMHasSolutionItem",&partCnt,&partTagObjects));
									printf("\nESO:Part Count:%d\n",partCnt);fflush(stdout);
									
									if(partCnt>0)
									{
										int p=0;
										char* part_object_type = NULL;
										char* partNo = NULL;
										char* partType = NULL;
										
										for(p=0;p<partCnt;p++)
										{
											partTag = partTagObjects[p];
											CALLAPI(AOM_ask_value_string(partTag,"object_type",&part_object_type));
											printf("\nESO: object_type of part is :%s\n",part_object_type);fflush(stdout);
											
											if(tc_strcmp(part_object_type,"Design Revision")==0)
											{
												CALLAPI(AOM_ask_value_string(partTag,"item_id",&partNo));
												printf("\nESO: Item ID:%s\n",partNo);fflush(stdout);
												//t5_PartType
												
												CALLAPI(AOM_ask_value_string(partTag,"t5_PartType",&partType));
												printf("\nESO: Part Type of the part:%s\n",partType);fflush(stdout);
												
												if(tc_strcmp(userInfo4,partType) == 0 || tc_strcmp(partType,"V")==0 || tc_strcmp(partType,"CCVC")==0 || tc_strcmp(partType,"VCCR")==0)
												{
													printf("\nESO: Vehicle: APPLICABLE FOR ESO STEP");fflush(stdout);
													*isAplicable = TRUE; 
													break;
												}
												else if(tc_strcmp(partType,"M")==0 || tc_strcmp(partType,"T")==0)//CR-FY24-0033 - For Part Type Module and Design Group 00, 26
												{
													printf("\nESO: Part Type Module");fflush(stdout);
													char* desGrp = NULL;
													ifail = AOM_ask_value_string(partTag,"t5_DesignGrp",&desGrp);
													printf("\nESO: Design Group: %s\n", desGrp);fflush(stdout);
													if(tc_strcmp(desGrp,"00")==0 || tc_strcmp(desGrp,"26")==0)
													{
														printf("\nESO: Module : APPLICABLE FOR ESO STEP");fflush(stdout);
														*isAplicable = TRUE;
														break;
													}
												}
												
											}
											
											
											
											
										}
									}
									
									
								}
								
								
							}
						}
						
						
						
						
						
						
						
					
					}
					else
					{
						printf("\nESO: Not a DR 4 and above DML: ESO step not applicable");fflush(stdout);
					}
					
					
					

				}	
			}
			
		}
	}
	
	
	
	printf("\nESO: Is Applicable for ESO step: [%d]\n",isAplicable);fflush(stdout);
	
	return ITK_ok;
}

/****************End *****************************/

/*Start- ESO Report Services*/

/*typedef struct PartDet_
{
	char partNumber[20];
	char parRev[10];
	char partDesc[200];
	char partDRStatus[10];
	char partApplicableESO[10];
	char partOwnerDesUnit[50];
	char esoNumber[30];
	char esoStatus[50];
}PartDet;
*/

typedef struct PartDet_
{
	char partNumber[20];
	char parRev[10];
	char partDesc[200];
	char partDRStatus[10];
	char partApplicableESO[10];
	char partOwnerDesUnit[50];
	char esoNumber[30];
	char esoStatus[50];	
	char partOwner[200];
	char partLCStatus[200];
	char partProject[50];
	char partDesgGrp[100];
	char partCS[50];
	char partType[50];
	char partModDesc[300];
	char partColorInd[50];
	char partCoatedInd[50];
	char partDrwInd[50];
	char esoGrNo[50];
	char esoGrDateNo[50];
	char esoRemark[300];
	char esoCreator[100];
	char esoCreationDate[40];
	
}PartDet;


void setAddPartDet(int *count,PartDet **objlist,PartDet obj )
{

	*count=*count+1;
	//printf("\n ****count==>%d", *count);fflush(stdout);
	if(*count==1)
	{
		//printf("\n ****setAddPartModel1");fflush(stdout);
		(*objlist) = (PartDet *)malloc((*count ) * sizeof(PartDet ));
		//printf("\n ***setAddPartModel2");fflush(stdout);
	}
	else
	{
		//printf("\n **setAddPartModel3");fflush(stdout);
		(*objlist) = (PartDet *)realloc((*objlist),(*count) * sizeof(PartDet ));
		//printf("\n ***setAddPartModel4");fflush(stdout);
		//printf("\n **setAddPartModel5");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
	//printf("\n **setAddPartModel");fflush(stdout);
}


int getProjectTag(char *projNo, char *object_type, tag_t *projTag)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULL;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Name";
	
	qry_values[0] = object_type;
	qry_values[1] = projNo;
		
	CALLAPI(QRY_find2("General...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\n SAN:getProjectTag: count==>%d\n", count);fflush(stdout);

	if(count>0)
	{
		*projTag = itemObj[count-1];
	}
	
	return ifail;
}

void remove_multi_new_line(char* string)
{
  size_t length = strlen(string);
  while((length>0) && (string[length-1] == '\n'))
  {
      --length;
      string[length] ='\0';
  }
}


int getClsValueFrmICSTag( tag_t  IcsClsTag , char *clsKeyAtrrId,char **AttrVal)
{
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	char   *Ptype_name = NULL;
	//char   Stype_name[TCTYPE_name_size_c+1];
	//char   relation_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	tag_t *ClsObjTag = NULL;
	tag_t*    status_list;
	
	

	if(TCTYPE_ask_object_type(IcsClsTag,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&Ptype_name));
	//printf("\n getClsValueFrmICSTag IcsClsTag  Ptype_name :: %s\n", Ptype_name); fflush(stdout);

	
	//Create Relation between Intent and Vehicle.
	int partRevCnt=0;
                tag_t* partRevTagObjs = NULL;
                tag_t partRevTag = NULLTAG;
	if(IcsClsTag!=NULLTAG)
	{
		char * 	theClassId =NULL;
			int  	theAttributeCount;
			int * 	theAttributeIds;
			int * 	theAttributeValCounts;
			char ** 	theAttributeValues;
			tag_t 	theICOTag=NULLTAG;
			//printf("\n  input clsKeyAtrrId[%s]",clsKeyAtrrId); fflush(stdout);
			char keyPrefix[10];
			tc_strcpy(keyPrefix,"-");
			tc_strcat(keyPrefix,clsKeyAtrrId);
			//printf("\n  input keyPrefix[%s]",keyPrefix); fflush(stdout);
			const char * 	key_lov_id=keyPrefix; //cls attr id for ChassisTypeNo_TYP_APPRVL_NO
			char * 	key_lov_name;
			int  	options;
			int i;
			int keyfound=0;
			int  	n_lov_entries;
			char ** 	lov_keys;
			char ** 	lov_values;
			logical * 	deprecated_staus;
			char * 	owning_site;
			char *keyLovOfCCVNo=(char*) MEM_alloc( 1 * sizeof(lov_keys) );
			int  	n_shared_sites;
			char ** 	shared_sites ;
			theICOTag=IcsClsTag;
			//CALLAPI(ICS_ask_attribute_value(theICOTag,"8066",&AttrKeyValue))
			if(ICS_ask_attribute_value(IcsClsTag,clsKeyAtrrId,&AttrKeyValue))
			
			//printf("\n AttrKeyValue=%s key_lov_id=%s",AttrKeyValue,key_lov_id); fflush(stdout);
			
			if(AttrKeyValue)
			{
				*AttrVal = AttrKeyValue;
			
			if(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			//CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			//printf("\n key_lov_name=%s n_lov_entries=%d options=%d",key_lov_name,n_lov_entries,options); fflush(stdout);
/* 				for(i=0;i<n_lov_entries;i++)								
				{
					printf("\n lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);
					
					if(tc_strcasecmp(AttrKeyValue,lov_keys[i])==0)
					{
						printf("\n Mascot lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);
						
						if(lov_values[i])
						{
							tc_strdup(lov_values[i],&RetAttrVal);
						}
						*AttrVal=RetAttrVal;
						break;
					}
					
					
					
				} */
			}
			else
			{
				*AttrVal="";
				return ITK_ok;
			}
	}						
			//printf("\n RetAttrVal=%s ",RetAttrVal); fflush(stdout);
			

	return ITK_ok;

}


typedef struct EsoPartDet_
{
	char partNumber[20];
	char parRev[10];
	char esoNumber[30];
	char esoStatus[100];	
}EsoPartDet;


void setAddEsoPartDet(int *count,EsoPartDet **objlist,EsoPartDet obj )
{

	*count=*count+1;
	//printf("\n ****count==>%d", *count);fflush(stdout);
	if(*count==1)
	{
		//printf("\n ****setAddPartModel1");fflush(stdout);
		(*objlist) = (EsoPartDet *)malloc((*count ) * sizeof(EsoPartDet ));
		//printf("\n ***setAddPartModel2");fflush(stdout);
	}
	else
	{
		//printf("\n **setAddPartModel3");fflush(stdout);
		(*objlist) = (EsoPartDet *)realloc((*objlist),(*count) * sizeof(EsoPartDet ));
		//printf("\n ***setAddPartModel4");fflush(stdout);
		//printf("\n **setAddPartModel5");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
	//printf("\n **setAddPartModel");fflush(stdout);
}



int sendESOStatusMail(tag_t dmlTag)
{
	int ifail = ITK_ok;
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
	printf("\nESOMAIL: Send ESO Status Mail.....\n");fflush(stdout);
	
	ifail = isLiveForESOMailNotif(&cntrlObj,&liveFlag); //Check if control object ESONOTIF-ESONOTIF is present and returns TRUE
	
	printf("\nESOMAIL: Live for ESO STATUS MAIL notification==>%d\n",liveFlag);fflush(stdout);	
	if(!liveFlag)
	{
		printf("\nESO: Not Live for ESO STATUS MAIL notification- Check for control object ESONOTIF");fflush(stdout);
		return ITK_ok;
	}
	
	if(dmlTag != NULLTAG)
	{
		EsoPartDet * partDetailList1 = NULL;
		int partDetailCnt1 =0;
		char* dmlNoS = NULL;
		tag_t *dmlTaskTagObjects = NULL;
		tag_t dmlTaskTag = NULLTAG;
		int taskCnt = 0;
		char* dmlReleaseType = NULL;
		char* dmlRelTypeDisplayStr = NULL;
		
		if(AOM_ask_value_string(dmlTag,"item_id",&dmlNoS));
		if(AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlReleaseType));
		if(AOM_UIF_ask_value(dmlTag,"t5_rlstype",&dmlRelTypeDisplayStr));
		
		if(AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects));
		//printf("\nESO REP: For DML %s,  ERC Task Count:%d\n",dmlNoS, taskCnt);fflush(stdout);
		
				
		if(taskCnt>0)
		{
			int j=0;
			char* object_type	=	NULL;
			
			for(j=0;j<taskCnt;j++)
			{
				dmlTaskTag = dmlTaskTagObjects[j];
				if(AOM_ask_value_string(dmlTaskTag,"object_type",&object_type));
				//printf("\nESO REP: DML Task object_type is :%s\n",object_type);fflush(stdout);
				
				if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
				{
					int partCnt=0;
					tag_t *partTagObjects = NULL;
					tag_t partTag = NULLTAG;
					
					if(tc_strcmp(dmlReleaseType,"TODR")==0)
					{
						if(AOM_ask_value_tags(dmlTaskTag,"CMReferences",&partCnt,&partTagObjects));
						
					}
					else if(tc_strcmp(dmlReleaseType,"Veh")==0)
					{
						if(AOM_ask_value_tags(dmlTaskTag,"CMHasSolutionItem",&partCnt,&partTagObjects));
					}							
					//printf("\nESO:Part Count:%d\n",partCnt);fflush(stdout);
					
					if(partCnt>0)
					{
						int p=0;
						char* part_object_type = NULL;
						char* partNo = NULL;
						char* partType = NULL;
						
						for(p=0;p<partCnt;p++)
						{
							
							partTag = partTagObjects[p];
							if(AOM_ask_value_string(partTag,"object_type",&part_object_type));
							//printf("\nESO REP: object_type of part is :%s\n",part_object_type);fflush(stdout);
							
							if(tc_strcmp(part_object_type,"Design Revision")==0)
							{
								

								if(AOM_ask_value_string(partTag,"t5_PartType",&partType));
								//printf("\nESO REP: Part Type of the part:%s\n",partType);fflush(stdout);
								logical isEngine = FALSE;
								if(tc_strcmp(partType,"M")==0 || tc_strcmp(partType,"T")==0)
								{
									printf("\nESO: Part Type Module");fflush(stdout);
									char* desGrp = NULL;
									ifail = AOM_ask_value_string(partTag,"t5_DesignGrp",&desGrp);
									printf("\nESO: Design Group: %s\n", desGrp);fflush(stdout);
									if(tc_strcmp(desGrp,"00")==0 || tc_strcmp(desGrp,"26")==0)
									{																
										isEngine = TRUE;																	
									}																
								}										
							
								if(tc_strcmp(partType,"VC")==0 || tc_strcmp(partType,"V")==0 || tc_strcmp(partType,"CCVC")==0 || tc_strcmp(partType,"VCCR")==0 || isEngine )
								{
									//printf("\nESO REP: APPLICABLE FOR ESO REPORT");fflush(stdout);
									char* partRevStr = NULL;
									char* partDescStr = NULL;
									char* partDRStatStr = NULL;
									char* partOwnerDesUntStr = NULL;
									
									char* partNum = NULL;
									char* rev = NULL;
									char* revStr = NULL;
									char* seq = NULL;
									char* seqStr = NULL;
									
									if(AOM_ask_value_string(partTag,"item_id",&partNum));
									//printf("\nESO REP:partNum: %s",partNum); fflush(stdout);			
									
									if (AOM_UIF_ask_value(partTag,"item_revision_id",&rev));
									//printf("\nESO REP::rev:%s\n",rev); fflush(stdout);
									
									if(tc_strstr(rev,";") != NULL)
									{
										revStr = tc_strtok ( rev,";") ;
										seqStr = tc_strtok ( NULL,";") ;	
									}
									
									//printf("\nESO REP:seqStr:%s",seqStr); fflush(stdout);
									if (AOM_UIF_ask_value(partTag,"sequence_id",&seq));
									//printf("\nESO REP:seq:%s",seq); fflush(stdout);
								
									if(AOM_ask_value_string(partTag,"item_revision_id",&partRevStr));

									if (AOM_ask_value_string(partTag,"object_desc",&partDescStr));
									if (AOM_ask_value_string(partTag,"t5_PartStatus",&partDRStatStr));
									if (AOM_ask_value_string(partTag,"t5_DsgnOwn",&partOwnerDesUntStr));

									EsoPartDet partDetail;
									tc_strcpy(partDetail.partNumber,partNum);
									tc_strcpy(partDetail.parRev,partRevStr);
									
									
								

									
									
									int esoCnt =0;
									tag_t* esoTags = NULL;
									if(AOM_ask_value_tags(partTag,"T5_PartEsoRel",&esoCnt,&esoTags));
									
									if(esoCnt >0)
									{

										int m =0;
										char* esoItemId = NULL;
										char* esoNum = NULL;
										int esoflag = 0;
										esoItemId = (char*)MEM_alloc(strlen(partNum)*sizeof(char) + 30);
										tc_strcpy(esoItemId,"");
										tc_strcat(esoItemId,"ESO_");
										tc_strcat(esoItemId,partNum);
										tc_strcat(esoItemId,"_");
										tc_strcat(esoItemId,rev);
										tc_strcat(esoItemId,"_");
										tc_strcat(esoItemId,seqStr);
										
										//printf("\n esoItemId==> %s\n",esoItemId);fflush(stdout);
										
										for(m=0;m<esoCnt;m++)
										{
											tag_t esoTag = NULLTAG;
											esoTag = esoTags[m];
											
											if(AOM_ask_value_string(esoTag,"item_id",&esoNum));
											//printf("\nESO REP:esoNum: %s",esoNum); fflush(stdout);
											
											if(tc_strcmp(esoItemId,esoNum)==0)
											{
												
												char* esoNumberStr = NULL;
												char* esoStatusStr = NULL;
												esoflag++;
												
																											
												if (AOM_ask_value_string(esoTag,"item_id",&esoNumberStr));
												if (AOM_ask_value_string(esoTag,"t5_ESOStatus",&esoStatusStr));
												
												if(esoNumberStr != NULL)
												{
													tc_strcpy(partDetail.esoNumber,esoNumberStr);//todo
												}
												else
												{
													tc_strcpy(partDetail.esoNumber,"");//todo
												}
												
												if(esoStatusStr != NULL)
												{
													tc_strcpy(partDetail.esoStatus,esoStatusStr);//todo
												}
												else
												{
													tc_strcpy(partDetail.esoStatus,"");//todo
												}															
												
												

											}
											
											
											
										}
										
										if(esoflag ==0)
										{
											//printf("\nIncorrect ESO Status attached to the part\n");fflush(stdout);
											tc_strcpy(partDetail.esoNumber,"");
											tc_strcpy(partDetail.esoStatus,"");
											
										}
									
										if(esoItemId)MEM_free(esoItemId);														
											
																				
										//To-do more 

									
									}
									else
									{
										char* esoItemId2 = NULL;
										tag_t esoTag2 = NULLTAG;
										char* esoNumberStr = NULL;
										char* esoStatusStr = NULL;													
										
										esoItemId2 = (char*)MEM_alloc(strlen(partNum)*sizeof(char) + 30);
										tc_strcpy(esoItemId2,"");
										tc_strcat(esoItemId2,"ESO_");
										tc_strcat(esoItemId2,partNum);
										tc_strcat(esoItemId2,"_");
										tc_strcat(esoItemId2,rev);
										tc_strcat(esoItemId2,"_");
										tc_strcat(esoItemId2,seqStr);
										
										//printf("\n esoItemId2==> %s\n",esoItemId2);fflush(stdout);
										if(getTCObject(esoItemId2,"T5_ESOStRevision",&esoTag2));fflush(stdout);
										
										if(esoTag2 != NULLTAG)
										{
											if (AOM_ask_value_string(esoTag2,"item_id",&esoNumberStr));
											if (AOM_ask_value_string(esoTag2,"t5_ESOStatus",&esoStatusStr));
											
											if(esoNumberStr != NULL)
											{
												tc_strcpy(partDetail.esoNumber,esoNumberStr);//todo
											}
											else
											{
												tc_strcpy(partDetail.esoNumber,"");//todo
											}
											
											if(esoStatusStr != NULL)
											{
												tc_strcpy(partDetail.esoStatus,esoStatusStr);//todo
											}
											else
											{
												tc_strcpy(partDetail.esoStatus,"");//todo
											}
																								
										}
										else
										{
											tc_strcpy(partDetail.esoNumber,"");
											tc_strcpy(partDetail.esoStatus,"");
											
										}
										
										
										if(esoItemId2)MEM_free(esoItemId2);														
									}													
									


									
									setAddEsoPartDet(&partDetailCnt1, &partDetailList1, partDetail);
									


								} 
								
								
							}
							
							
							
							
						}
					}
												
			
				}
				
				
				
				
			}
			
		}
								
		char* dmlBusUnit = NULL;		
		char* dmlSynopsis = NULL;
		char* dmlDRStat = NULL;

		

		
		if(AOM_ask_value_string(dmlTag,"t5_ERCBusiUt",&dmlBusUnit));
		if(AOM_ask_value_string(dmlTag,"t5_cDRstatus",&dmlDRStat));
		
						
		
		
		//Send Mail
		

		tag_t Envelop_object	= NULLTAG;
		//char* username		= NULL;
		//char* user_email	= NULL;
		char* mail_subject	= NULL;
		char* mail_body		= NULL;							
		
		mail_subject	= (char *) MEM_alloc(100 * sizeof(char ));
		mail_body		= (char *) MEM_alloc(5000 *partDetailCnt1* sizeof(char ));						
		
		tc_strcpy(mail_subject,"ESO status DML will appear for review");
		
		tc_strcpy(mail_body,"DML No : ");
		tc_strcat(mail_body,dmlNoS);						
		tc_strcat(mail_body,"\nBusiness Unit: ");
		tc_strcat(mail_body,dmlBusUnit);
		tc_strcat(mail_body,"\nDML AR/DR Status: ");
		tc_strcat(mail_body,dmlDRStat);
		
		tc_strcat(mail_body,"\n\nBelow are the Parts Details:");
		
		
		if(partDetailCnt1>0)
		{
			int j=0;
			for(j=0;j<partDetailCnt1;j++)
			{
				EsoPartDet partDet;
				partDet = partDetailList1[j];
				
				char* buffSno = NULL;
				
				buffSno = (char*)MEM_alloc(20 * sizeof(char));
				
				sprintf(buffSno,"%d",j+1);
				tc_strcat(mail_body,"\n");
				tc_strcat(mail_body,buffSno);
				tc_strcat(mail_body,"\tPartNumber: ");
				tc_strcat(mail_body,partDet.partNumber);
				tc_strcat(mail_body,";");
				tc_strcat(mail_body,partDet.parRev);
				tc_strcat(mail_body,"\n");
				tc_strcat(mail_body,"\tESO Number: ");
				tc_strcat(mail_body,partDet.esoNumber);
				tc_strcat(mail_body,"\n");
				tc_strcat(mail_body,"\tESO Status: ");
				tc_strcat(mail_body,partDet.esoStatus);
				
				MEM_free(buffSno);
				
				
				
			}
		}
		else
		{
			//tc_strcat(mail_body,"\nNo Parts attached to the DML");
		}
		
		//char* role = NULL;
		
		int no = 0;
		tag_t *members = NULL;
		
		if(tc_strcmp(dmlBusUnit,"CVBU")==0 )
		{
			ifail = SA_find_groupmember_by_rolename ("ESO_Status_Reviewer","DML_Participants_Group_CV",NULL,&no,&members);
		}
		else
		{
			ifail = SA_find_groupmember_by_rolename ("ESO_Status_Reviewer","DML_Participants_Group",NULL,&no,&members);
		}
		

		
		printf("\n No of Members:[%d]\n",no);fflush(stdout);
		
		printf("\nmail_subject : %s",mail_subject);fflush(stdout);
		printf("\nmail_body : %s",mail_body);fflush(stdout);
		
	
		
		ifail = MAIL_create_envelope(mail_subject,mail_body,&Envelop_object);

		if(Envelop_object)
		{
			printf("\nEnvelop_object : object created.");
			
		}
		

		ifail = MAIL_initialize_envelope2(Envelop_object,mail_subject,mail_body);
		
		int j = 0;
		tag_t usertag=NULLTAG;
		for(j=0;j<no;j++)
		{
			ifail = SA_ask_groupmember_user(members[j],&usertag);
			ifail = MAIL_add_envelope_receiver(Envelop_object,usertag);
		}
		
		if(MAIL_add_external_receiver(Envelop_object,MAIL_send_cc,"sanjoym.ttl@tatamotors.com"));

		ifail = MAIL_send_envelope(Envelop_object);							
		printf("\n Mail sent successfully\n");fflush(stdout);						
		
		MEM_free(mail_body);
		MEM_free(mail_subject);
		//MEM_free(user_email);
		
		
	}
	
			
	
	printf("\nESOMAIL: END.....\n");fflush(stdout);
	return ITK_ok;
}

/* ESO Mail notification *************************** Start *****************************/
int  tm_ESOStatusMailNotifFun(EPM_action_message_t  msg)
{
	int ifail = ITK_ok;

	const char * prog_name ="tm_ESOStatusMailNotifFun";
	char*	username 	=	NULL;
	tag_t	user_tag	=	NULLTAG;
	tag_t	rootTask	= NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
	logical applForESO = FALSE;
	
	ifail = isLiveForESOMailNotif(&cntrlObj,&liveFlag); //Check if control object ESONOTIF-ESONOTIF is present and returns TRUE
	
	printf("\nESO: Live for ESO STATUS MAIL notification==>%d\n",liveFlag);fflush(stdout);	
	if(!liveFlag)
	{
		printf("\nESO: Not Live for ESO STATUS MAIL notification- Check for control object ESONOTIF");fflush(stdout);
		return ifail;
	}
	if(cntrlObj != NULLTAG && liveFlag)
	{
		POM_get_user(&username,&user_tag);
		printf("\nESO: Starting for username :%s....\n",username);fflush(stdout);
		
		ifail = EPM_ask_root_task(msg.task,&rootTask);
		printf("\nESO: Root task found");fflush(stdout);
		
		ifail = AOM_ask_value_string(msg.task,"object_name",&currentTaskName);
		printf("\nESO: Current Task:%s\n",currentTaskName);fflush(stdout);

		ifail = AOM_ask_value_string(rootTask,"object_name",&parentTaskName);
		printf("\nESO: Parent Name:%s\n",parentTaskName);fflush(stdout);	
		
		ifail = EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects);
		
		if(targetobjects_count > 0)
		{
			int i =0;
			tag_t objectTypeTag = NULLTAG;
			char *type_name = NULL;
			char* dmlReleaseType = NULL;			
			char* dmlRelTypeDisplayStr = NULL;
			char* dmlBusUnit	=	NULL;
			char* dmlBusUnitStr	=	NULL;
			char* userInfo1	=	NULL;
			char* userInfo2	= NULL;
			char* userInfo3	=	NULL;
			char* userInfo4	=	NULL;
			char* userInfo5	=	NULL;
			char* userInfo6	=	NULL;
			char* userInfo7	=	NULL;
			char* userInfo8	=	NULL;
			char* userInfo9	=	NULL;
			
			
			
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));//Business Unit
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));//Release Type
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
			
			
			printf("\nESONOTIF Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\nt5_Userinfo6:[%s]\nt5_Userinfo7:[%s]\nt5_Userinfo8:[%s]\nt5_Userinfo9:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
			
			for(i=0;i<targetobjects_count;i++)
			{
				if(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
				if(TCTYPE_ask_name2( objectTypeTag, &type_name));
				printf("\nESO: type_name ==> %s\n", type_name);fflush(stdout);
				
				if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
				{
					tag_t dmlTag = NULLTAG;
					applForESO = FALSE;
					dmlTag = targetobjects[i];
					
					ifail = isESOStepApplicable(dmlTag,&applForESO);
					
					printf("\n Is Applicable for ESO for mail notification: [%d]\n",applForESO);fflush(stdout);
					
					
					if(applForESO)
					{
						PartDet * partDetailList1 = NULL;
						int partDetailCnt1 =0;
						char* dmlNoS = NULL;
						tag_t *dmlTaskTagObjects = NULL;
						tag_t dmlTaskTag = NULLTAG;
						int taskCnt = 0;
						
						if(AOM_ask_value_string(dmlTag,"item_id",&dmlNoS));
						if(AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlReleaseType));
						if(AOM_UIF_ask_value(dmlTag,"t5_rlstype",&dmlRelTypeDisplayStr));
						
						if(AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects));
						//printf("\nESO REP: For DML %s,  ERC Task Count:%d\n",dmlNoS, taskCnt);fflush(stdout);
						
								
						if(taskCnt>0)
						{
							int j=0;
							char* object_type	=	NULL;
							
							for(j=0;j<taskCnt;j++)
							{
								dmlTaskTag = dmlTaskTagObjects[j];
								if(AOM_ask_value_string(dmlTaskTag,"object_type",&object_type));
								//printf("\nESO REP: DML Task object_type is :%s\n",object_type);fflush(stdout);
								
								if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
								{
									int partCnt=0;
									tag_t *partTagObjects = NULL;
									tag_t partTag = NULLTAG;
									
									if(tc_strcmp(dmlReleaseType,"TODR")==0)
									{
										if(AOM_ask_value_tags(dmlTaskTag,"CMReferences",&partCnt,&partTagObjects));
										
									}
									else if(tc_strcmp(dmlReleaseType,"Veh")==0)
									{
										if(AOM_ask_value_tags(dmlTaskTag,"CMHasSolutionItem",&partCnt,&partTagObjects));
									}							
									//printf("\nESO:Part Count:%d\n",partCnt);fflush(stdout);
									
									if(partCnt>0)
									{
										int p=0;
										char* part_object_type = NULL;
										char* partNo = NULL;
										char* partType = NULL;
										
										for(p=0;p<partCnt;p++)
										{
											
											partTag = partTagObjects[p];
											if(AOM_ask_value_string(partTag,"object_type",&part_object_type));
											//printf("\nESO REP: object_type of part is :%s\n",part_object_type);fflush(stdout);
											
											if(tc_strcmp(part_object_type,"Design Revision")==0)
											{
												

												if(AOM_ask_value_string(partTag,"t5_PartType",&partType));
												//printf("\nESO REP: Part Type of the part:%s\n",partType);fflush(stdout);
												logical isEngine = FALSE;
												if(tc_strcmp(partType,"M")==0 || tc_strcmp(partType,"T")==0)
												{
													printf("\nESO: Part Type Module");fflush(stdout);
													char* desGrp = NULL;
													ifail = AOM_ask_value_string(partTag,"t5_DesignGrp",&desGrp);
													printf("\nESO: Design Group: %s\n", desGrp);fflush(stdout);
													if(tc_strcmp(desGrp,"00")==0 || tc_strcmp(desGrp,"26")==0)
													{																
														isEngine = TRUE;																	
													}																
												}										
											
												if(tc_strcmp(partType,"VC")==0 || tc_strcmp(partType,"V")==0 || tc_strcmp(partType,"CCVC")==0 || tc_strcmp(partType,"VCCR")==0 || isEngine )
												{
													//printf("\nESO REP: APPLICABLE FOR ESO REPORT");fflush(stdout);
													char* partRevStr = NULL;
													char* partDescStr = NULL;
													char* partDRStatStr = NULL;
													char* partOwnerDesUntStr = NULL;
													
													char* partNum = NULL;
													char* rev = NULL;
													char* revStr = NULL;
													char* seq = NULL;
													char* seqStr = NULL;
													
													if(AOM_ask_value_string(partTag,"item_id",&partNum));
													//printf("\nESO REP:partNum: %s",partNum); fflush(stdout);			
													
													if (AOM_UIF_ask_value(partTag,"item_revision_id",&rev));
													//printf("\nESO REP::rev:%s\n",rev); fflush(stdout);
													
													if(tc_strstr(rev,";") != NULL)
													{
														revStr = tc_strtok ( rev,";") ;
														seqStr = tc_strtok ( NULL,";") ;	
													}
													
													//printf("\nESO REP:seqStr:%s",seqStr); fflush(stdout);
													if (AOM_UIF_ask_value(partTag,"sequence_id",&seq));
													//printf("\nESO REP:seq:%s",seq); fflush(stdout);
												
													if(AOM_ask_value_string(partTag,"item_revision_id",&partRevStr));

													if (AOM_ask_value_string(partTag,"object_desc",&partDescStr));
													if (AOM_ask_value_string(partTag,"t5_PartStatus",&partDRStatStr));
													if (AOM_ask_value_string(partTag,"t5_DsgnOwn",&partOwnerDesUntStr));

													PartDet partDetail;
													tc_strcpy(partDetail.partNumber,partNum);
													tc_strcpy(partDetail.parRev,partRevStr);
													tc_strcpy(partDetail.partDesc,partDescStr);
													tc_strcpy(partDetail.partDRStatus ,partDRStatStr);//t5_PartStatus
													
													
													//Get Classification object
													int clsCnt = 0;
													tag_t* ClsObjTag = NULL;
													tag_t ccvMstrTag = NULLTAG;
													if(ITEM_ask_item_of_rev(partTag,&ccvMstrTag));
													if(AOM_ask_value_tags(ccvMstrTag,"IMAN_classification",&clsCnt,&ClsObjTag));
													//if(ICS_ask_classification_object(partTag,&ClsObjTag));
													//printf("\n classified object count[%d] for CCVC/Vehicle[%s] !!",clsCnt,partNo); fflush(stdout);
													
													if(clsCnt>0)
													{
														char* esoApplicable = NULL;
														if(getClsValueFrmICSTag(*ClsObjTag , "8103",&esoApplicable));
														//printf("\nESO applicable for the part %s ==> %s\n",partNo,esoApplicable);fflush(stdout);
														if(esoApplicable!=NULL)
														{
															tc_strcpy(partDetail.partApplicableESO,esoApplicable);
														}
														else
														{
															tc_strcpy(partDetail.partApplicableESO,"");//todo
														}
													}
													else
													{
														tc_strcpy(partDetail.partApplicableESO,"");//todo
													}
													
													tc_strcpy(partDetail.partOwnerDesUnit,partOwnerDesUntStr);//t5_DsgnOwn		

													
													
													int esoCnt =0;
													tag_t* esoTags = NULL;
													if(AOM_ask_value_tags(partTag,"T5_PartEsoRel",&esoCnt,&esoTags));
													
													if(esoCnt >0)
													{

														int m =0;
														char* esoItemId = NULL;
														char* esoNum = NULL;
														int esoflag = 0;
														esoItemId = (char*)MEM_alloc(strlen(partNum)*sizeof(char) + 30);
														tc_strcpy(esoItemId,"");
														tc_strcat(esoItemId,"ESO_");
														tc_strcat(esoItemId,partNum);
														tc_strcat(esoItemId,"_");
														tc_strcat(esoItemId,rev);
														tc_strcat(esoItemId,"_");
														tc_strcat(esoItemId,seqStr);
														
														//printf("\n esoItemId==> %s\n",esoItemId);fflush(stdout);
														
														for(m=0;m<esoCnt;m++)
														{
															tag_t esoTag = NULLTAG;
															esoTag = esoTags[m];
															
															if(AOM_ask_value_string(esoTag,"item_id",&esoNum));
															//printf("\nESO REP:esoNum: %s",esoNum); fflush(stdout);
															
															if(tc_strcmp(esoItemId,esoNum)==0)
															{
																
																char* esoNumberStr = NULL;
																char* esoStatusStr = NULL;
																esoflag++;
																
																															
																if (AOM_ask_value_string(esoTag,"item_id",&esoNumberStr));
																if (AOM_ask_value_string(esoTag,"t5_ESOStatus",&esoStatusStr));
																
																if(esoNumberStr != NULL)
																{
																	tc_strcpy(partDetail.esoNumber,esoNumberStr);//todo
																}
																else
																{
																	tc_strcpy(partDetail.esoNumber,"");//todo
																}
																
																if(esoStatusStr != NULL)
																{
																	tc_strcpy(partDetail.esoStatus,esoStatusStr);//todo
																}
																else
																{
																	tc_strcpy(partDetail.esoStatus,"");//todo
																}															
																
																

															}
															
															
															
														}
														
														if(esoflag ==0)
														{
															//printf("\nIncorrect ESO Status attached to the part\n");fflush(stdout);
															tc_strcpy(partDetail.esoNumber,"");
															tc_strcpy(partDetail.esoStatus,"");
															
														}
													
														if(esoItemId)MEM_free(esoItemId);														
															
																								
														//To-do more 

													
													}
													else
													{
														char* esoItemId2 = NULL;
														tag_t esoTag2 = NULLTAG;
														char* esoNumberStr = NULL;
														char* esoStatusStr = NULL;													
														
														esoItemId2 = (char*)MEM_alloc(strlen(partNum)*sizeof(char) + 30);
														tc_strcpy(esoItemId2,"");
														tc_strcat(esoItemId2,"ESO_");
														tc_strcat(esoItemId2,partNum);
														tc_strcat(esoItemId2,"_");
														tc_strcat(esoItemId2,rev);
														tc_strcat(esoItemId2,"_");
														tc_strcat(esoItemId2,seqStr);
														
														//printf("\n esoItemId2==> %s\n",esoItemId2);fflush(stdout);
														if(getTCObject(esoItemId2,"T5_ESOStRevision",&esoTag2));fflush(stdout);
														
														if(esoTag2 != NULLTAG)
														{
															if (AOM_ask_value_string(esoTag2,"item_id",&esoNumberStr));
															if (AOM_ask_value_string(esoTag2,"t5_ESOStatus",&esoStatusStr));
															
															if(esoNumberStr != NULL)
															{
																tc_strcpy(partDetail.esoNumber,esoNumberStr);//todo
															}
															else
															{
																tc_strcpy(partDetail.esoNumber,"");//todo
															}
															
															if(esoStatusStr != NULL)
															{
																tc_strcpy(partDetail.esoStatus,esoStatusStr);//todo
															}
															else
															{
																tc_strcpy(partDetail.esoStatus,"");//todo
															}
																												
														}
														else
														{
															tc_strcpy(partDetail.esoNumber,"");
															tc_strcpy(partDetail.esoStatus,"");
															
														}
														
														
														if(esoItemId2)MEM_free(esoItemId2);														
													}													
													


													
													setAddPartDet(&partDetailCnt1, &partDetailList1, partDetail);
													


												} 
												
												
											}
											
											
											
											
										}
									}
																
							
								}
								
								
								
								
							}
							
						}
												
						char* dmlBusUnit = NULL;		
						char* dmlSynopsis = NULL;
						char* dmlDRStat = NULL;
						char* dmlCreator = NULL;
						char* dmlReviewer = NULL;
						char* dmlprojCode	=	NULL;
						char* vertical = NULL;
						
						
						if(AOM_ask_value_string(dmlTag,"object_name",&dmlSynopsis));
						remove_multi_new_line(dmlSynopsis);
						STRNG_replace_str(dmlSynopsis,"\"","",&dmlSynopsis);
						STRNG_replace_str(dmlSynopsis,","," ",&dmlSynopsis);
						
						if(AOM_ask_value_string(dmlTag,"t5_ERCBusiUt",&dmlBusUnit));
						if(AOM_ask_value_string(dmlTag,"t5_cDRstatus",&dmlDRStat));
						if(AOM_UIF_ask_value(dmlTag,"requestor_user_id",&dmlCreator));
						if(AOM_UIF_ask_value(dmlTag,"ChangeReviewBoard",&dmlReviewer));
						if(AOM_ask_value_string(dmlTag,"t5_cprojectcode",&dmlprojCode));
						if(AOM_ask_value_string(dmlTag,"t5_ProductLine",&vertical));
										
						
						
						//Send Mail
						

						tag_t Envelop_object	= NULLTAG;
						//char* username		= NULL;
						//char* user_email	= NULL;
						char* mail_subject	= NULL;
						char* mail_body		= NULL;							
						
						mail_subject	= (char *) MEM_alloc(100 * sizeof(char ));
						mail_body		= (char *) MEM_alloc(5000 *partDetailCnt1* sizeof(char ));						
						
						tc_strcpy(mail_subject,"ESO status DML will appear for review");
						
						tc_strcpy(mail_body,"DML No : ");
						tc_strcat(mail_body,dmlNoS);						
						tc_strcat(mail_body,"\nBusiness Unit: ");
						tc_strcat(mail_body,dmlBusUnit);
						tc_strcat(mail_body,"\nDML AR/DR Status: ");
						tc_strcat(mail_body,dmlDRStat);
						
						tc_strcat(mail_body,"\n\nBelow are the Parts Details:");
						
						
						if(partDetailCnt1>0)
						{
							int j=0;
							for(j=0;j<partDetailCnt1;j++)
							{
								PartDet partDet;
								partDet = partDetailList1[j];
								
								char* buffSno = NULL;
								
								buffSno = (char*)MEM_alloc(20 * sizeof(char));
								
								sprintf(buffSno,"%d",j+1);
								tc_strcat(mail_body,"\n");
								tc_strcat(mail_body,buffSno);
								tc_strcat(mail_body,"\tPartNumber: ");
								tc_strcat(mail_body,partDet.partNumber);
								tc_strcat(mail_body,";");
								tc_strcat(mail_body,partDet.parRev);
								tc_strcat(mail_body,"\n");
								tc_strcat(mail_body,"\tESO Number: ");
								tc_strcat(mail_body,partDet.esoNumber);
								tc_strcat(mail_body,"\n");
								tc_strcat(mail_body,"\tESO Status: ");
								tc_strcat(mail_body,partDet.esoStatus);
								
								MEM_free(buffSno);
								
								
								
							}
						}
						else
						{
							//tc_strcat(mail_body,"\nNo Parts attached to the DML");
						}
						
						//char* role = NULL;
						
						int no = 0;
						tag_t *members = NULL;
						
						
						if(userInfo2 != NULL)
						{
							if(tc_strlen(userInfo2) >0)
							{
								ifail = SA_find_groupmember_by_rolename ("ESO_Status_Reviewer",userInfo2,NULL,&no,&members);
							}
							else
							{
								if(tc_strcmp(dmlBusUnit,"CVBU")==0 )
								{
									ifail = SA_find_groupmember_by_rolename ("ESO_Status_Reviewer","DML_Participants_Group_CV",NULL,&no,&members);
								}
								else
								{
									ifail = SA_find_groupmember_by_rolename ("ESO_Status_Reviewer","DML_Participants_Group",NULL,&no,&members);
								}
							}
						}
						else
						{
							if(tc_strcmp(dmlBusUnit,"CVBU")==0 )
							{
								ifail = SA_find_groupmember_by_rolename ("ESO_Status_Reviewer","DML_Participants_Group_CV",NULL,&no,&members);
							}
							else
							{
								ifail = SA_find_groupmember_by_rolename ("ESO_Status_Reviewer","DML_Participants_Group",NULL,&no,&members);
							}
								
						}

						
						printf("\n No of Members:[%d]\n",no);fflush(stdout);
						
						printf("\nmail_subject : %s",mail_subject);fflush(stdout);
						printf("\nmail_body : %s",mail_body);fflush(stdout);
						
					
						
						ifail = MAIL_create_envelope(mail_subject,mail_body,&Envelop_object);

						if(Envelop_object)
						{
							printf("\nEnvelop_object : object created.");
							
						}
						

						ifail = MAIL_initialize_envelope2(Envelop_object,mail_subject,mail_body);
						
						int j = 0;
						tag_t usertag=NULLTAG;
						for(j=0;j<no;j++)
						{
							ifail = SA_ask_groupmember_user(members[j],&usertag);
							ifail = MAIL_add_envelope_receiver(Envelop_object,usertag);
						}
						
						if(MAIL_add_external_receiver(Envelop_object,MAIL_send_cc,"sanjoym.ttl@tatamotors.com"));

						ifail = MAIL_send_envelope(Envelop_object);							
						printf("\n Mail sent successfully\n");fflush(stdout);						
						
						MEM_free(mail_body);
						MEM_free(mail_subject);
						//MEM_free(user_email);
						
						
					}
					
					
				}
			}
		}	
				
	}
	
	
	return ITK_ok;
	
}
/* ESO Mail notification *************************** End *****************************/


int executeESOStatusReportLogic( char* DatefromStr, char* DatetoStr, char*** bufferedXmlStrOut, int *buff_cnt )
{
	int ifail = ITK_ok;
	
	date_t   dateArray[2];
	date_t dateFrom;
	date_t dateTo;
	
	const char * select_attrs[]={"puid"};
	char **dmlRelType = (char **) MEM_alloc(20 * sizeof(char *));
	
	int n_dmls = 0;
	int n_cols = 0;
	void ***values = NULL;	
	
	
	printf("\nQuery executing based on - Date Range: %s to %s\n",DatefromStr,DatetoStr);fflush(stdout);
	
	ITK_string_to_date(DatefromStr,&dateFrom);		
	ITK_string_to_date(DatetoStr,&dateTo);
	
	dateArray[0]=dateFrom;
	dateArray[1]=dateTo;
	
	dmlRelType[0]="TODR";
	dmlRelType[1]="Veh";
	dmlRelType[2]="Gate Maturation";
	dmlRelType[3]="Vehicle Release";
	dmlRelType[4]="MR";
	dmlRelType[5]="Module Release";

	
	//Step 1-   Creates a new enquiry.
	ifail = POM_enquiry_create ("find_dml_objs" );		
	//Step 2 - add the list to the select clause of the query
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_add_select_attrs ("find_dml_objs","ChangeRequestRevision",1,select_attrs);
	}	
	//Step 3a - create a date value object.
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_set_date_value ("find_dml_objs","expr_dates", 2 ,(const date_t*)dateArray,POM_enquiry_bind_value);
	}		
	//Step 4a - create an expression for pom creation_date = Date using the value "expr_dates" 
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_set_attr_expr ("find_dml_objs","expr_dates_between","ChangeRequestRevision","date_released",POM_enquiry_between,"expr_dates");
	}		
	// Step 3b - Create a string value object
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_set_string_value ("find_dml_objs","dml_rel_type",6,(const char**)dmlRelType,POM_enquiry_bind_value);
	}
	//  Step 4b - create an expression for POM_enquiry_in using the value "dml_rel_type" 
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_set_attr_expr ("find_dml_objs","expr_dmlRelType_in","ChangeRequestRevision","t5_rlstype",POM_enquiry_in,"dml_rel_type");
	}
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_set_expr ("find_dml_objs","expr_AND_expression","expr_dates_between",POM_enquiry_and,"expr_dmlRelType_in");
	}
	//Step 6 - Set the where clause of the query to the specified expression
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_set_where_expr ("find_dml_objs","expr_AND_expression");
	}		
	// Step 7 Order by clause 
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_add_order_attr ("find_dml_objs","ChangeRequestRevision", "date_released", POM_enquiry_asc_order);
	}	
	//Step 8 - Executes the query and fetches the data.
	if (ifail == ITK_ok)
	{
		ifail = POM_enquiry_execute("find_dml_objs", &n_dmls ,&n_cols, &values );
	}		
	//Step 9 - Delete the query and its sub-queries
	if (ifail == ITK_ok)
	{
		ifail = POM_enquiry_delete("find_dml_objs");
	}
	
	printf("\n No of DMLs==>%d\n",n_dmls);fflush(stdout);
	
	t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<?xml version='1.0' encoding='UTF-8'?>");
	t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<ESOStatusReport>");
	
	tag_t dmlTag = NULLTAG;
	char* partno = NULL;
	char* dmlReleaseType = NULL;			
	char* dmlRelTypeDisplayStr = NULL;
	char* dmlBusUnit	=	NULL;
	char* dmlBusUnitStr	=	NULL;
	char* creationDt = NULL;
	char* drstatS = NULL;
	char* drstatS1 = NULL;
	char * dmlRelStatS = NULL;
	char* dmlRelDateS = NULL;
	int dmlCnt = 0;
	
	tag_t* dmlObjSet = NULL;
	
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
	char* userInfo1 = NULL;
	
	ifail = isLiveForESOReview(&cntrlObj,&liveFlag); //Check if control object ESOREV-ESOREV is present and returns TRUE
	if(cntrlObj!= NULLTAG)
	{
		ifail = AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1);
	}
	printf("\nReport is applicable for business unit (ESOREV control object userinfo1:)[%s]\n",userInfo1);fflush(stdout);	
	
	if(n_dmls > 0)
	{
		int i=0;
			
		for (i = 0; i < n_dmls; i++ )
		{
			dmlTag  = *(tag_t*)(values[i][0]);
			
			if(dmlTag!=NULLTAG)
			{
				CALLAPI(AOM_ask_value_string(dmlTag,"item_id",&partno));
				CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlReleaseType));
				CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_rlstype",&dmlRelTypeDisplayStr));
				CALLAPI(AOM_ask_value_string(dmlTag,"t5_ERCBusiUt",&dmlBusUnit));
				CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_ERCBusiUt",&dmlBusUnitStr));
				CALLAPI(AOM_UIF_ask_value(dmlTag,"creation_date",&creationDt));
				CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_cDRstatus",&drstatS));
				CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_PlntToPlnt",&drstatS1));
				CALLAPI(AOM_UIF_ask_value(dmlTag,"release_status_list",&dmlRelStatS));
				CALLAPI(AOM_UIF_ask_value(dmlTag,"date_released",&dmlRelDateS));
				
				char* dmlBusUnitS = NULL;
				dmlBusUnitS = (char*)MEM_alloc(200);
				tc_strcpy(dmlBusUnitS,",");
				tc_strcat(dmlBusUnitS,dmlBusUnit);
				tc_strcat(dmlBusUnitS,",");
				printf("\nESO Report: dmlBusUnitS:%s\n",dmlBusUnitS);fflush(stdout);				
				
				int applicable =0;
				if(tc_strstr(userInfo1,dmlBusUnitS)!=NULL && tc_strstr(dmlRelStatS,"Released")!=NULL)
				{
					if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);
					tag_t *dmlTaskTagObjects = NULL;
					tag_t dmlTaskTag = NULLTAG;
					int taskCnt = 0;								
					CALLAPI(AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects));
					
					if(taskCnt>0)
					{
						int j=0;
						char* object_type	=	NULL;
						
						for(j=0;j<taskCnt;j++)
						{
							dmlTaskTag = dmlTaskTagObjects[j];
							CALLAPI(AOM_ask_value_string(dmlTaskTag,"object_type",&object_type));
							
							if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
							{
								int partCnt=0;
								tag_t *partTagObjects = NULL;
								tag_t partTag = NULLTAG;
								
								if(tc_strcmp(dmlReleaseType,"TODR")==0)
								{
									CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMReferences",&partCnt,&partTagObjects));
								}
								else if(tc_strcmp(dmlReleaseType,"Veh")==0)
								{
									CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMHasSolutionItem",&partCnt,&partTagObjects));
								}
								else
								{
									printf("\nInvalid DML Type. Should not come here\n");fflush(stdout);
								}
								
								if(partCnt>0)
								{
									int p=0;
									char* part_object_type = NULL;
									char* partType = NULL;
									for(p=0;p<partCnt;p++)
									{
										partTag = partTagObjects[p];
										CALLAPI(AOM_ask_value_string(partTag,"object_type",&part_object_type));

										if(tc_strcmp(part_object_type,"Design Revision")==0)
										{
											CALLAPI(AOM_ask_value_string(partTag,"t5_PartType",&partType));
											logical isEngine = FALSE;
											if(tc_strcmp(partType,"M")==0 || tc_strcmp(partType,"T")==0)
											{
												printf("\nESO: Part Type Module");fflush(stdout);
												char* desGrp = NULL;
												ifail = AOM_ask_value_string(partTag,"t5_DesignGrp",&desGrp);
												printf("\nESO: Design Group: %s\n", desGrp);fflush(stdout);
												if(tc_strcmp(desGrp,"00")==0 || tc_strcmp(desGrp,"26")==0)
												{																
													isEngine = TRUE;																	
												}																
											}
											printf("\nIs Engine:[%d]",isEngine);fflush(stdout);												
											if(tc_strcmp(partType,"VC") == 0 || tc_strcmp(partType,"V")==0 || tc_strcmp(partType,"CCVC")==0 || tc_strcmp(partType,"VCCR")==0  || isEngine)
											{
												applicable++;
												break;
											}
										}
											
									}
																			
								}
								
							}
															
						}
						
					}
					
				}
				else
				{
					
					if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);
				}
				
				
				if(applicable >0)
				{
					//printf("\n[%d] - %s  Release Type: %s     Business Unit:%s      Creation Date: %s		Release Date: %s",i,partno,dmlReleaseType,dmlBusUnit,creationDt, dmlRelDateS);fflush(stdout);

					t5AddTagObjToSet(&dmlCnt,&dmlObjSet,dmlTag);
					}
				else
				{
					//printf("\n Not Applicable - [%d] - %s  Release Type: %s     Business Unit:%s      Creation Date: %s		Release Date: %s",i,partno,dmlReleaseType,dmlBusUnit,creationDt,dmlRelDateS);fflush(stdout);

				}
					
			}
			
		}
	}
	
	printf("\nVdhicle DML Count ===>%d",dmlCnt);fflush(stdout);
	
	if(dmlCnt >0)
	{
		int k = 0;
		for(k=0;k<dmlCnt;k++)
		{
			tag_t dmlTagObj = NULLTAG;
			dmlTagObj = dmlObjSet[k];
			if(dmlTagObj!=NULLTAG)
			{
				t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<DMLDetails>");
				
				PartDet * partDetailList1 = NULL;
				int partDetailCnt1 =0;
				char* dmlNoS = NULL;
				tag_t *dmlTaskTagObjects = NULL;
				tag_t dmlTaskTag = NULLTAG;
				int taskCnt = 0;
				
				CALLAPI(AOM_ask_value_string(dmlTagObj,"item_id",&dmlNoS));
				CALLAPI(AOM_ask_value_string(dmlTagObj,"t5_rlstype",&dmlReleaseType));
				CALLAPI(AOM_UIF_ask_value(dmlTagObj,"t5_rlstype",&dmlRelTypeDisplayStr));
				
				CALLAPI(AOM_ask_value_tags(dmlTagObj,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects));
				//printf("\nESO REP: For DML %s,  ERC Task Count:%d\n",dmlNoS, taskCnt);fflush(stdout);
				
				if(taskCnt>0)
				{
					int j=0;
					char* object_type	=	NULL;
					
					for(j=0;j<taskCnt;j++)
					{
						dmlTaskTag = dmlTaskTagObjects[j];
						CALLAPI(AOM_ask_value_string(dmlTaskTag,"object_type",&object_type));
						//printf("\nESO REP: DML Task object_type is :%s\n",object_type);fflush(stdout);
						
						if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
						{
							int partCnt=0;
							tag_t *partTagObjects = NULL;
							tag_t partTag = NULLTAG;
							
							if(tc_strcmp(dmlReleaseType,"TODR")==0)
							{
								CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMReferences",&partCnt,&partTagObjects));
								
							}
							else if(tc_strcmp(dmlReleaseType,"Veh")==0)
							{
								CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMHasSolutionItem",&partCnt,&partTagObjects));
							}
							else
							{
								CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMHasSolutionItem",&partCnt,&partTagObjects));
							}
							
							//printf("\nESO:Part Count:%d\n",partCnt);fflush(stdout);
							
							if(partCnt>0)
							{
								int p=0;
								char* part_object_type = NULL;
								char* partNo = NULL;
								char* partType = NULL;
								
								for(p=0;p<partCnt;p++)
								{
									
									partTag = partTagObjects[p];
									CALLAPI(AOM_ask_value_string(partTag,"object_type",&part_object_type));
									//printf("\nESO REP: object_type of part is :%s\n",part_object_type);fflush(stdout);
									
									if(tc_strcmp(part_object_type,"Design Revision")==0)
									{
										

										CALLAPI(AOM_ask_value_string(partTag,"t5_PartType",&partType));
										//printf("\nESO REP: Part Type of the part:%s\n",partType);fflush(stdout);
										logical isEngine = FALSE;
										if(tc_strcmp(partType,"M")==0 || tc_strcmp(partType,"T")==0)
										{
											printf("\nESO: Part Type Module");fflush(stdout);
											char* desGrp = NULL;
											ifail = AOM_ask_value_string(partTag,"t5_DesignGrp",&desGrp);
											printf("\nESO: Design Group: %s\n", desGrp);fflush(stdout);
											if(tc_strcmp(desGrp,"00")==0 || tc_strcmp(desGrp,"26")==0)
											{																
												isEngine = TRUE;																	
											}																
										}										
									
										if(tc_strcmp(partType,"VC")==0 || tc_strcmp(partType,"V")==0 || tc_strcmp(partType,"CCVC")==0 || tc_strcmp(partType,"VCCR")==0 || isEngine )
										{
											//printf("\nESO REP: APPLICABLE FOR ESO REPORT");fflush(stdout);
											char* partRevStr = NULL;
											char* partDescStr = NULL;
											char* partDRStatStr = NULL;
											char* partOwnerDesUntStr = NULL;
											
											char* partNum = NULL;
											char* rev = NULL;
											char* revStr = NULL;
											char* seq = NULL;
											char* seqStr = NULL;
											
											//aditional attributes
											char *partOwnerStr = NULL;
											char *partLCStatusStr = NULL;
											char *partProjectStr = NULL;
											char *partDesgGrpStr = NULL;
											char *partCSStr = NULL;
											char *partTypeStr = NULL;
											char *partModDescStr = NULL;
											char *partColorIndStr = NULL;
											char *partCoatedIndStr = NULL;
											char *partDrwIndStr = NULL;
											
											
											CALLAPI (AOM_UIF_ask_value(partTag,"owning_user",&partOwnerStr));
											CALLAPI(AOM_UIF_ask_value(partTag,"release_status_list",&partLCStatusStr));
											STRNG_replace_str(partLCStatusStr,","," ",&partLCStatusStr);
											
											CALLAPI(AOM_ask_value_string(partTag,"t5_ProjectCode",&partProjectStr));
											CALLAPI(AOM_UIF_ask_value(partTag,"t5_DesignGrp",&partDesgGrpStr));
											
											CALLAPI(AOM_UIF_ask_value(partTag,"t5_PartType",&partTypeStr));
											
											CALLAPI(AOM_ask_value_string(partTag,"t5_DocRemarks",&partModDescStr));
											STRNG_replace_str(partModDescStr,","," ",&partModDescStr);
											CALLAPI(AOM_ask_value_string(partTag,"t5_ColourInd",&partColorIndStr));
											CALLAPI(AOM_ask_value_string(partTag,"t5_Coated",&partCoatedIndStr));
											CALLAPI(AOM_ask_value_string(partTag,"t5_DrawingInd",&partDrwIndStr));
											
											
											
											
											
											
											CALLAPI(AOM_ask_value_string(partTag,"item_id",&partNum));
											//printf("\nESO REP:partNum: %s",partNum); fflush(stdout);			
											
											CALLAPI (AOM_UIF_ask_value(partTag,"item_revision_id",&rev));
											//printf("\nESO REP::rev:%s\n",rev); fflush(stdout);
											
											if(tc_strstr(rev,";") != NULL)
											{
												revStr = tc_strtok ( rev,";") ;
												seqStr = tc_strtok ( NULL,";") ;	
											}
											
											//printf("\nESO REP:seqStr:%s",seqStr); fflush(stdout);
											CALLAPI (AOM_UIF_ask_value(partTag,"sequence_id",&seq));
											//printf("\nESO REP:seq:%s",seq); fflush(stdout);
										
											CALLAPI(AOM_ask_value_string(partTag,"item_revision_id",&partRevStr));

											CALLAPI (AOM_ask_value_string(partTag,"object_desc",&partDescStr));
											CALLAPI (AOM_ask_value_string(partTag,"t5_PartStatus",&partDRStatStr));
											CALLAPI (AOM_ask_value_string(partTag,"t5_DsgnOwn",&partOwnerDesUntStr));
											
											
																						

											PartDet partDetail;
											tc_strcpy(partDetail.partNumber,partNum);
											tc_strcpy(partDetail.parRev,partRevStr);
											tc_strcpy(partDetail.partDesc,partDescStr);
											tc_strcpy(partDetail.partDRStatus ,partDRStatStr);//t5_PartStatus
											
											//additional attr
											tc_strcpy(partDetail.partOwner ,partOwnerStr);
											tc_strcpy(partDetail.partLCStatus ,partLCStatusStr);
											tc_strcpy(partDetail.partProject ,partProjectStr);
											tc_strcpy(partDetail.partDesgGrp ,partDesgGrpStr);
											partCSStr = " ";//To do sanjoy
											tc_strcpy(partDetail.partCS ,partCSStr);
											tc_strcpy(partDetail.partType ,partTypeStr);
											tc_strcpy(partDetail.partModDesc ,partModDescStr);
											tc_strcpy(partDetail.partColorInd ,partColorIndStr);
											tc_strcpy(partDetail.partCoatedInd ,partCoatedIndStr);
											tc_strcpy(partDetail.partDrwInd ,partDrwIndStr);
											
											
											
											
											
											//Get Classification object
											int clsCnt = 0;
											tag_t* ClsObjTag = NULL;
											tag_t ccvMstrTag = NULLTAG;
											if(ITEM_ask_item_of_rev(partTag,&ccvMstrTag));
											if(AOM_ask_value_tags(ccvMstrTag,"IMAN_classification",&clsCnt,&ClsObjTag));
											//CALLAPI(ICS_ask_classification_object(partTag,&ClsObjTag));
											//printf("\n classified object count[%d] for CCVC/Vehicle[%s] !!",clsCnt,partNo); fflush(stdout);
											
											if(clsCnt>0)
											{
												char* esoApplicable = NULL;
												if(getClsValueFrmICSTag(*ClsObjTag , "8103",&esoApplicable));
												//printf("\nESO applicable for the part %s ==> %s\n",partNo,esoApplicable);fflush(stdout);
												if(esoApplicable!=NULL)
												{
													tc_strcpy(partDetail.partApplicableESO,esoApplicable);
												}
												else
												{
													tc_strcpy(partDetail.partApplicableESO,"");//todo
												}
											}
											else
											{
												tc_strcpy(partDetail.partApplicableESO,"");//todo
											}
											
											tc_strcpy(partDetail.partOwnerDesUnit,partOwnerDesUntStr);//t5_DsgnOwn		

											
											
											int esoCnt =0;
											tag_t* esoTags = NULL;
											if(AOM_ask_value_tags(partTag,"T5_PartEsoRel",&esoCnt,&esoTags));
											
											if(esoCnt >0)
											{

												int m =0;
												char* esoItemId = NULL;
												char* esoNum = NULL;
												int esoflag = 0;
												esoItemId = (char*)MEM_alloc(strlen(partNum)*sizeof(char) + 30);
												tc_strcpy(esoItemId,"");
												tc_strcat(esoItemId,"ESO_");
												tc_strcat(esoItemId,partNum);
												tc_strcat(esoItemId,"_");
												tc_strcat(esoItemId,rev);
												tc_strcat(esoItemId,"_");
												tc_strcat(esoItemId,seqStr);
												
												//printf("\n esoItemId==> %s\n",esoItemId);fflush(stdout);
												
												for(m=0;m<esoCnt;m++)
												{
													tag_t esoTag = NULLTAG;
													esoTag = esoTags[m];
													
													CALLAPI(AOM_ask_value_string(esoTag,"item_id",&esoNum));
													//printf("\nESO REP:esoNum: %s",esoNum); fflush(stdout);
													
													if(tc_strcmp(esoItemId,esoNum)==0)
													{
														
														char* esoNumberStr = NULL;
														char* esoStatusStr = NULL;
														char *esoGrNoStr = NULL;
														char *esoGrDateNoStr = NULL;
														char *esoRemarkStr = NULL;
														char *esoCreatorStr = NULL;
														char * esoCreationDateStr = NULL;
														esoflag++;
														
																													
														CALLAPI (AOM_ask_value_string(esoTag,"item_id",&esoNumberStr));
														CALLAPI (AOM_ask_value_string(esoTag,"t5_ESOStatus",&esoStatusStr));
														
														CALLAPI (AOM_ask_value_string(esoTag,"t5_GRnumb",&esoGrNoStr));
														CALLAPI (AOM_UIF_ask_value(esoTag,"t5_GRDate",&esoGrDateNoStr));
														CALLAPI (AOM_ask_value_string(esoTag,"t5_ESORemark",&esoRemarkStr));
														CALLAPI (AOM_UIF_ask_value(esoTag,"owning_user",&esoCreatorStr));
														CALLAPI (AOM_UIF_ask_value(esoTag,"creation_date",&esoCreationDateStr));
														
														
														if(esoNumberStr != NULL)
														{
															tc_strcpy(partDetail.esoNumber,esoNumberStr);//todo
														}
														else
														{
															tc_strcpy(partDetail.esoNumber,"");//todo
														}
														
														if(esoStatusStr != NULL)
														{
															tc_strcpy(partDetail.esoStatus,esoStatusStr);//todo
														}
														else
														{
															tc_strcpy(partDetail.esoStatus,"");//todo
														}															
														
														if(esoGrNoStr != NULL)
														{
															tc_strcpy(partDetail.esoGrNo,esoGrNoStr);//todo
														}
														else
														{
															tc_strcpy(partDetail.esoGrNo,"");//todo
														}
														if(esoGrDateNoStr != NULL)
														{
															tc_strcpy(partDetail.esoGrDateNo,esoGrDateNoStr);//todo
														}
														else
														{
															tc_strcpy(partDetail.esoGrDateNo,"");//todo
														}
														if(esoRemarkStr != NULL)
														{
															tc_strcpy(partDetail.esoRemark,esoRemarkStr);//todo
														}
														else
														{
															tc_strcpy(partDetail.esoRemark,"");//todo
														}
														if(esoCreatorStr != NULL)
														{
															tc_strcpy(partDetail.esoCreator,esoCreatorStr);//todo
														}
														else
														{
															tc_strcpy(partDetail.esoCreator,"");//todo
														}
														if(esoCreationDateStr != NULL)
														{
															tc_strcpy(partDetail.esoCreationDate,esoCreationDateStr);//todo
														}
														else
														{
															tc_strcpy(partDetail.esoCreationDate,"");//todo
														}
														

													}
													
													
													
												}
												
												if(esoflag ==0)
												{
													//printf("\nIncorrect ESO Status attached to the part\n");fflush(stdout);
													tc_strcpy(partDetail.esoNumber,"");
													tc_strcpy(partDetail.esoStatus,"");
													
												}
											
												if(esoItemId)MEM_free(esoItemId);														
													
																						
												//To-do more 

											
											}
											else
											{
												char* esoItemId2 = NULL;
												tag_t esoTag2 = NULLTAG;
												char* esoNumberStr = NULL;
												char* esoStatusStr = NULL;
												char *esoGrNoStr = NULL;
												char *esoGrDateNoStr = NULL;
												char *esoRemarkStr = NULL;
												char *esoCreatorStr = NULL;
												char * esoCreationDateStr = NULL;												
												
												esoItemId2 = (char*)MEM_alloc(strlen(partNum)*sizeof(char) + 30);
												tc_strcpy(esoItemId2,"");
												tc_strcat(esoItemId2,"ESO_");
												tc_strcat(esoItemId2,partNum);
												tc_strcat(esoItemId2,"_");
												tc_strcat(esoItemId2,rev);
												tc_strcat(esoItemId2,"_");
												tc_strcat(esoItemId2,seqStr);
												
												//printf("\n esoItemId2==> %s\n",esoItemId2);fflush(stdout);
												CALLAPI(getTCObject(esoItemId2,"T5_ESOStRevision",&esoTag2));fflush(stdout);
												
												if(esoTag2 != NULLTAG)
												{
													CALLAPI (AOM_ask_value_string(esoTag2,"item_id",&esoNumberStr));
													CALLAPI (AOM_ask_value_string(esoTag2,"t5_ESOStatus",&esoStatusStr));
													CALLAPI (AOM_ask_value_string(esoTag2,"t5_GRnumb",&esoGrNoStr));
													CALLAPI (AOM_UIF_ask_value(esoTag2,"t5_GRDate",&esoGrDateNoStr));
													CALLAPI (AOM_ask_value_string(esoTag2,"t5_ESORemark",&esoRemarkStr));
													CALLAPI (AOM_UIF_ask_value(esoTag2,"owning_user",&esoCreatorStr));
													CALLAPI (AOM_UIF_ask_value(esoTag2,"creation_date",&esoCreationDateStr));
													
													
													if(esoNumberStr != NULL)
													{
														tc_strcpy(partDetail.esoNumber,esoNumberStr);//todo
													}
													else
													{
														tc_strcpy(partDetail.esoNumber,"");//todo
													}
													
													if(esoStatusStr != NULL)
													{
														tc_strcpy(partDetail.esoStatus,esoStatusStr);//todo
													}
													else
													{
														tc_strcpy(partDetail.esoStatus,"");//todo
													}
													if(esoGrNoStr != NULL)
													{
														tc_strcpy(partDetail.esoGrNo,esoGrNoStr);//todo
													}
													else
													{
														tc_strcpy(partDetail.esoGrNo,"");//todo
													}
													if(esoGrDateNoStr != NULL)
													{
														tc_strcpy(partDetail.esoGrDateNo,esoGrDateNoStr);//todo
													}
													else
													{
														tc_strcpy(partDetail.esoGrDateNo,"");//todo
													}
													if(esoRemarkStr != NULL)
													{
														tc_strcpy(partDetail.esoRemark,esoRemarkStr);//todo
													}
													else
													{
														tc_strcpy(partDetail.esoRemark,"");//todo
													}
													if(esoCreatorStr != NULL)
													{
														tc_strcpy(partDetail.esoCreator,esoCreatorStr);//todo
													}
													else
													{
														tc_strcpy(partDetail.esoCreator,"");//todo
													}
													if(esoCreationDateStr != NULL)
													{
														tc_strcpy(partDetail.esoCreationDate,esoCreationDateStr);//todo
													}
													else
													{
														tc_strcpy(partDetail.esoCreationDate,"");//todo
													}													
																									
												}
												else
												{
													tc_strcpy(partDetail.esoNumber,"");
													tc_strcpy(partDetail.esoStatus,"");
													tc_strcpy(partDetail.esoGrNo,"");
													tc_strcpy(partDetail.esoGrDateNo,"");
													tc_strcpy(partDetail.esoRemark,"");
													tc_strcpy(partDetail.esoCreator,"");
													tc_strcpy(partDetail.esoCreationDate,"");
													
													
												}
												
												
												if(esoItemId2)MEM_free(esoItemId2);														
											}													
											


											
											setAddPartDet(&partDetailCnt1, &partDetailList1, partDetail);
											


										} 
										
										
									}
									
									
									
									
								}
							}
														
					
						}
						
						
						
						
					}
					
				}
				
				
				
				
				//Report - data
				
				char* dmlSynopsis = NULL;
				char* dmlDRStat = NULL;
				
				char* dmlReviewer = NULL;
				char* dmlprojCode	=	NULL;
				char* vertical = NULL;
				char* dmlRelStat = NULL;
				char* dmlRelDate = NULL;
				char* projdesc = NULL;
				char* vehClass = NULL;
				
				//additional attributes
				char* dmlCreator = NULL;
				char* dmlCreationDate = NULL;
				char* dmlOwner = NULL;//owning_user
				char* dmlDesgnGrp = NULL;//t5_crdesigngroup
				char* dmlVertical = NULL;//t5_ProductLine
				char* dmlWbsNo = NULL;//t5_ERCWBS
				//char* dmlWbsDesc = NULL;
				char* dmlReason = NULL;//t5_reason
				
				char* dmlBusinessUnit = NULL;
				
				
				CALLAPI(AOM_ask_value_string(dmlTagObj,"object_name",&dmlSynopsis));
				remove_multi_new_line(dmlSynopsis);
				STRNG_replace_str(dmlSynopsis,"\"","",&dmlSynopsis);
				STRNG_replace_str(dmlSynopsis,","," ",&dmlSynopsis);
				
				CALLAPI(AOM_ask_value_string(dmlTagObj,"t5_ERCBusiUt",&dmlBusinessUnit));
				
				CALLAPI(AOM_ask_value_string(dmlTagObj,"t5_cDRstatus",&dmlDRStat));
				
				CALLAPI(AOM_UIF_ask_value(dmlTagObj,"ChangeReviewBoard",&dmlReviewer));
				CALLAPI(AOM_ask_value_string(dmlTagObj,"t5_cprojectcode",&dmlprojCode));
				CALLAPI(AOM_ask_value_string(dmlTagObj,"t5_ProductLine",&vertical));
				CALLAPI(AOM_UIF_ask_value(dmlTagObj,"release_status_list",&dmlRelStat));
				STRNG_replace_str(dmlRelStat,","," ",&dmlRelStat);								
				CALLAPI(AOM_UIF_ask_value(dmlTagObj,"date_released",&dmlRelDate));
				
				
				//Addtional Attribute
				CALLAPI(AOM_UIF_ask_value(dmlTagObj,"requestor_user_id",&dmlCreator));
				CALLAPI(AOM_UIF_ask_value(dmlTagObj,"creation_date",&dmlCreationDate));
				CALLAPI(AOM_UIF_ask_value(dmlTagObj,"owning_user",&dmlOwner));
				CALLAPI(AOM_UIF_ask_value(dmlTagObj,"t5_crdesigngroup",&dmlDesgnGrp));
				CALLAPI(AOM_ask_value_string(dmlTagObj,"t5_ProductLine",&dmlVertical));
				CALLAPI(AOM_ask_value_string(dmlTagObj,"t5_ERCWBS",&dmlWbsNo));
				//CALLAPI(AOM_ask_value_string(dmlTagObj,"t5_reason",&dmlReason));
				
				int resCnt = 0;
				char** reasondesc = NULL;
				CALLAPI(AOM_ask_displayable_values(dmlTagObj,"t5_reason",&resCnt, &reasondesc));		
				printf("\n resCnt : %d \n",resCnt); fflush(stdout);
				if(resCnt>0) 
					dmlReason = reasondesc[0];
				
				//CALLAPI(getERCReleasedDate(dmlTagObj,&dmlRelDate));
				printf("\n Release Date  DML: %s ", dmlRelDate);fflush(stdout);

				if(dmlprojCode!=NULL)
				{
					tag_t projTag = NULLTAG;
					CALLAPI(getProjectTag(dmlprojCode, "T5_Project", &projTag));
					if(projTag!=NULLTAG)
					{
						CALLAPI(AOM_ask_value_string(projTag,"t5_ProjectDesc",&projdesc));
						remove_multi_new_line(projdesc);
						STRNG_replace_str(projdesc,"\"","",&projdesc);
						STRNG_replace_str(projdesc,","," ",&projdesc);
						CALLAPI(AOM_ask_value_string(projTag,"t5_VehicleClass",&vehClass));
					}
				}
				
				
				char* dmlNoBuf = (char *)MEM_alloc(200 * sizeof(char));;
				char* dmlBusUnitBuf = (char *)MEM_alloc(200 * sizeof(char));;
				char* dmlSynopsisBuf = (char *)MEM_alloc(300 * sizeof(char));;
				char* dmlprojCodeBuf = (char *)MEM_alloc(200 * sizeof(char));;
				char* projdescBuf = (char *)MEM_alloc(500 * sizeof(char));;
				char* dmlRelStatBuf = (char *)MEM_alloc(200 * sizeof(char));;
				char* dmlRelTypeDisplayStrBuf = (char *)MEM_alloc(200 * sizeof(char));;
				char* dmlDRStatBuf = (char *)MEM_alloc(200 * sizeof(char));;
				char* dmlRelDateBuf = (char *)MEM_alloc(200 * sizeof(char));;
				
				char* dmlCreatorBuf = (char *)MEM_alloc(200 * sizeof(char));;
				char* dmlCreationDateBuf = (char *)MEM_alloc(200 * sizeof(char));;
				char* dmlOwnerBuf = (char *)MEM_alloc(200 * sizeof(char));;
				char* dmlDesgnGrpBuf = (char *)MEM_alloc(200 * sizeof(char));;
				char* dmlVerticalBuf = (char *)MEM_alloc(200 * sizeof(char));;
				char* dmlWbsNoBuf = (char *)MEM_alloc(200 * sizeof(char));;
				char* dmlReasonBuf = (char *)MEM_alloc(500 * sizeof(char));;
				
							
								
				sprintf(dmlNoBuf,"<DMLNo>%s</DMLNo>",dmlNoS);
				t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,dmlNoBuf);
				
				sprintf(dmlBusUnitBuf,"<DMLBusUnit>%s</DMLBusUnit>",dmlBusinessUnit);
				t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,dmlBusUnitBuf);
				
				sprintf(dmlSynopsisBuf,"<DMLSynopsis>%s</DMLSynopsis>",dmlSynopsis);
				t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,dmlSynopsisBuf);

				sprintf(dmlprojCodeBuf,"<DMLProjCode>%s</DMLProjCode>",dmlprojCode);
				t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,dmlprojCodeBuf);

				sprintf(projdescBuf,"<DMLProjDesc>%s</DMLProjDesc>",projdesc);
				t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,projdescBuf);

				sprintf(dmlRelStatBuf,"<DMLRelStat>%s</DMLRelStat>",dmlRelStat);
				t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,dmlRelStatBuf);

				sprintf(dmlRelTypeDisplayStrBuf,"<DMLRelType>%s</DMLRelType>",dmlRelTypeDisplayStr);
				t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,dmlRelTypeDisplayStrBuf);

				sprintf(dmlDRStatBuf,"<DMLDRStat>%s</DMLDRStat>",dmlDRStat);
				t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,dmlDRStatBuf);

				sprintf(dmlRelDateBuf,"<DMLReleaseDate>%s</DMLReleaseDate>",dmlRelDate);
				t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,dmlRelDateBuf);
				
				
				//additional attributes
				sprintf(dmlCreatorBuf,"<DMLCreator>%s</DMLCreator>",dmlCreator);
				t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,dmlCreatorBuf);

				sprintf(dmlCreationDateBuf,"<DMLCreationDate>%s</DMLCreationDate>",dmlCreationDate);
				t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,dmlCreationDateBuf);

				sprintf(dmlOwnerBuf,"<DMLOwner>%s</DMLOwner>",dmlOwner);
				t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,dmlOwnerBuf);

				sprintf(dmlDesgnGrpBuf,"<DMLDesgGrp>%s</DMLDesgGrp>",dmlDesgnGrp);
				t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,dmlDesgnGrpBuf);

				sprintf(dmlVerticalBuf,"<DMLVertical>%s</DMLVertical>",dmlVertical);
				t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,dmlVerticalBuf);

				sprintf(dmlWbsNoBuf,"<DMLWbsNo>%s</DMLWbsNo>",dmlWbsNo);
				t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,dmlWbsNoBuf);

				sprintf(dmlReasonBuf,"<DMLReason>%s</DMLReason>",dmlReason);
				t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,dmlReasonBuf);


				
				
				if(dmlNoBuf != NULL) MEM_free(dmlNoBuf);
				if(dmlBusUnitBuf != NULL) MEM_free(dmlBusUnitBuf);
				if(dmlSynopsisBuf != NULL) MEM_free(dmlSynopsisBuf);
				if(dmlprojCodeBuf != NULL) MEM_free(dmlprojCodeBuf);
				if(projdescBuf != NULL) MEM_free(projdescBuf);
				if(dmlRelStatBuf != NULL) MEM_free(dmlRelStatBuf);
				if(dmlRelTypeDisplayStrBuf != NULL) MEM_free(dmlRelTypeDisplayStrBuf);
				if(dmlDRStatBuf != NULL) MEM_free(dmlDRStatBuf);
				if(dmlRelDateBuf != NULL) MEM_free(dmlRelDateBuf);
				
				
				
				if(dmlCreatorBuf != NULL) MEM_free(dmlCreatorBuf);
				if(dmlCreationDateBuf != NULL) MEM_free(dmlCreationDateBuf);
				if(dmlOwnerBuf != NULL) MEM_free(dmlOwnerBuf);
				if(dmlDesgnGrpBuf != NULL) MEM_free(dmlDesgnGrpBuf);
				if(dmlVerticalBuf != NULL) MEM_free(dmlVerticalBuf);
				if(dmlWbsNoBuf != NULL) MEM_free(dmlWbsNoBuf);
				if(dmlReasonBuf != NULL) MEM_free(dmlReasonBuf);
				
				
				
				
				if(partDetailCnt1>0)
				{
					int ii1=0;
					for(ii1=0;ii1<partDetailCnt1;ii1++)
					{
						PartDet partDet;
						partDet = partDetailList1[ii1];

						char* partNumberBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* parRevBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* partDRStatusBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* partDescBuf = (char *)MEM_alloc(300 * sizeof(char));;
						char* partApplicableESOBuf = (char *)MEM_alloc(200 * sizeof(char));;
						char* esoNumberBuf = (char *)MEM_alloc(200 * sizeof(char));
						char* esoStatusBuf = (char *)MEM_alloc(200 * sizeof(char));;
						
						char* partOwnerDesUntStrBuf = (char *)MEM_alloc(200 * sizeof(char));;;
						char *partOwnerStrBuf = (char *)MEM_alloc(200 * sizeof(char));;;
						char *partLCStatusStrBuf = (char *)MEM_alloc(200 * sizeof(char));;;
						char *partProjectStrBuf = (char *)MEM_alloc(200 * sizeof(char));;;
						char *partDesgGrpStrBuf = (char *)MEM_alloc(200 * sizeof(char));;;
						char *partCSStrBuf = (char *)MEM_alloc(200 * sizeof(char));;;
						char *partTypeStrBuf = (char *)MEM_alloc(50 * sizeof(char));;;
						char *partModDescStrBuf = (char *)MEM_alloc(500 * sizeof(char));;;
						char *partColorIndStrBuf = (char *)MEM_alloc(50 * sizeof(char));;;;
						char *partCoatedIndStrBuf = (char *)MEM_alloc(50 * sizeof(char));;;;
						char *partDrwIndStrBuf = (char *)MEM_alloc(50 * sizeof(char));;;;
						char *esoGrNoStrBuf = (char *)MEM_alloc(50 * sizeof(char));;;;
						char *esoGrDateNoStrBuf = (char *)MEM_alloc(50 * sizeof(char));;;;
						char *esoRemarkStrBuf = (char *)MEM_alloc(500 * sizeof(char));
						char *esoCreatorStrBuf = (char *)MEM_alloc(100 * sizeof(char));
						char * esoCreationDateStrBuf = (char *)MEM_alloc(50 * sizeof(char));						
						
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartDetails>");
					
						sprintf(partNumberBuf,"<PartNo>%s</PartNo>",partDet.partNumber);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,partNumberBuf);
						
						sprintf(parRevBuf,"<PartRev>%s</PartRev>",partDet.parRev);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,parRevBuf);
						
						sprintf(partDRStatusBuf,"<PartDRStatus>%s</PartDRStatus>",partDet.partDRStatus);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,partDRStatusBuf);
						
						sprintf(partDescBuf,"<PartDesc>%s</PartDesc>",partDet.partDesc);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,partDescBuf);
						
						sprintf(partApplicableESOBuf,"<PartAppForESO>%s</PartAppForESO>",partDet.partApplicableESO);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,partApplicableESOBuf);
						
						sprintf(esoNumberBuf,"<ESONum>%s</ESONum>",partDet.esoNumber);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,esoNumberBuf);
						
						sprintf(esoStatusBuf,"<ESOStatus>%s</ESOStatus>",partDet.esoStatus);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,esoStatusBuf);
						
						//Additinal Attr
						
						sprintf(partOwnerDesUntStrBuf,"<PartOwnerDesUnit>%s</PartOwnerDesUnit>",partDet.partOwnerDesUnit);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,partOwnerDesUntStrBuf);
						
						sprintf(partOwnerStrBuf,"<PartOwner>%s</PartOwner>",partDet.partOwner);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,partOwnerStrBuf);
						
						sprintf(partLCStatusStrBuf,"<PartLCStatus>%s</PartLCStatus>",partDet.partLCStatus);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,partLCStatusStrBuf);
						
						sprintf(partProjectStrBuf,"<PartProject>%s</PartProject>",partDet.partProject);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,partProjectStrBuf);						

						sprintf(partDesgGrpStrBuf,"<PartDesgGrp>%s</PartDesgGrp>",partDet.partDesgGrp);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,partDesgGrpStrBuf);


						sprintf(partCSStrBuf,"<PartCS>%s</PartCS>",partDet.partCS);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,partCSStrBuf);
						
						sprintf(partTypeStrBuf,"<PartType>%s</PartType>",partDet.partType);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,partTypeStrBuf);
						
						sprintf(partModDescStrBuf,"<PartModDesc>%s</PartModDesc>",partDet.partModDesc);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,partModDescStrBuf);

						

						sprintf(partCoatedIndStrBuf,"<PartCoatedInd>%s</PartCoatedInd>",partDet.partCoatedInd);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,partCoatedIndStrBuf);
						
						sprintf(partColorIndStrBuf,"<PartColorInd>%s</PartColorInd>",partDet.partColorInd);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,partColorIndStrBuf);
						sprintf(partDrwIndStrBuf,"<PartDrwInd>%s</PartDrwInd>",partDet.partDrwInd);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,partDrwIndStrBuf);	
						sprintf(esoGrNoStrBuf,"<EsoGrNo>%s</EsoGrNo>",partDet.esoGrNo);						
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,esoGrNoStrBuf);
						
						sprintf(esoGrDateNoStrBuf,"<EsoGrDateNo>%s</EsoGrDateNo>",partDet.esoGrDateNo);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,esoGrDateNoStrBuf);
						
						sprintf(esoRemarkStrBuf,"<EsoRemark>%s</EsoRemark>",partDet.esoRemark);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,esoRemarkStrBuf);
						
						sprintf(esoCreatorStrBuf,"<EsoCreator>%s</EsoCreator>",partDet.esoCreator);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,esoCreatorStrBuf);
						
						sprintf(esoCreationDateStrBuf,"<EsoCreationDate>%s</EsoCreationDate>",partDet.esoCreationDate);
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,esoCreationDateStrBuf);							
						
						
						
						t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"</PartDetails>");
						
						
						
						if(partNumberBuf != NULL) MEM_free(partNumberBuf);
						if(parRevBuf != NULL) MEM_free(parRevBuf);
						if(partDRStatusBuf != NULL) MEM_free(partDRStatusBuf);
						if(partDescBuf != NULL) MEM_free(partDescBuf);
						if(partApplicableESOBuf != NULL) MEM_free(partApplicableESOBuf);
						if(esoNumberBuf != NULL) MEM_free(esoNumberBuf);
						if(esoStatusBuf != NULL) MEM_free(esoStatusBuf);

						if(partOwnerDesUntStrBuf != NULL) MEM_free(partOwnerDesUntStrBuf);
						if(partOwnerStrBuf != NULL) MEM_free(partOwnerStrBuf);
						if(partLCStatusStrBuf != NULL) MEM_free(partLCStatusStrBuf);
						if(partProjectStrBuf != NULL) MEM_free(partProjectStrBuf);
						if(partDesgGrpStrBuf != NULL) MEM_free(partDesgGrpStrBuf);
						if(partCSStrBuf != NULL) MEM_free(partCSStrBuf);
						if(partTypeStrBuf != NULL) MEM_free(partTypeStrBuf);		
						if(partModDescStrBuf != NULL) MEM_free(partModDescStrBuf);
						if(partColorIndStrBuf != NULL) MEM_free(partColorIndStrBuf);
						if(partCoatedIndStrBuf != NULL) MEM_free(partCoatedIndStrBuf);
						if(partDrwIndStrBuf != NULL) MEM_free(partDrwIndStrBuf);
						if(esoGrNoStrBuf != NULL) MEM_free(esoGrNoStrBuf);
						if(esoGrDateNoStrBuf != NULL) MEM_free(esoGrDateNoStrBuf);
						if(esoRemarkStrBuf != NULL) MEM_free(esoRemarkStrBuf);
						if(esoCreatorStrBuf != NULL) MEM_free(esoCreatorStrBuf);
						if(esoCreationDateStrBuf != NULL) MEM_free(esoCreationDateStrBuf);						
						
						
					}
				}
				else
				{
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartDetails>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartNo></PartNo>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartRev></PartRev>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartDRStatus></PartDRStatus>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartDesc></PartDesc>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartAppForESO></PartAppForESO>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<ESONum></ESONum>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<ESOStatus></ESOStatus>");
					
					
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartOwnerDesUnit></PartOwnerDesUnit>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartOwner></PartOwner>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartLCStatus></PartLCStatus>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartProject></PartProject>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartDesgGrp></PartDesgGrp>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartCS></PartCS>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartType></PartType>");

					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartModDesc></PartModDesc>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartColorInd></PartColorInd>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartCoatedInd></PartCoatedInd>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartDrwInd></PartDrwInd>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<EsoGrNo></EsoGrNo>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<EsoGrDateNo></EsoGrDateNo>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<EsoRemark></EsoRemark>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<EsoCreator></EsoCreator>");
					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<EsoCreationDate></EsoCreationDate>");					


					t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"</PartDetails>");
				}
				
				
				
				
				
				t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"</DMLDetails>");				
			}

		}
	}
	else
	{
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<DMLDetails>");

		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<DMLNo></DMLNo>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<DMLBusUnit></DMLBusUnit>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<DMLSynopsis></DMLSynopsis>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<DMLProjCode></DMLProjCode>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<DMLProjDesc></DMLProjDesc>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<DMLRelStat></DMLRelStat>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<DMLRelType></DMLRelType>");	
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<DMLDRStat></DMLDRStat>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<DMLReleaseDate></DMLReleaseDate>");

		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<DMLCreator></DMLCreator>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<DMLCreationDate></DMLCreationDate>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<DMLOwner></DMLOwner>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<DMLDesgGrp></DMLDesgGrp>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<DMLVertical></DMLVertical>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<DMLWbsNo></DMLWbsNo>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<DMLReason></DMLReason>");	
		
		
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartDetails>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartNo></PartNo>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartRev></PartRev>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartDRStatus></PartDRStatus>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartDesc></PartDesc>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartAppForESO></PartAppForESO>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<ESONum></ESONum>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<ESOStatus></ESOStatus>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartOwnerDesUnit></PartOwnerDesUnit>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartOwner></PartOwner>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartLCStatus></PartLCStatus>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartProject></PartProject>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartDesgGrp></PartDesgGrp>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartCS></PartCS>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartType></PartType>");

		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartModDesc></PartModDesc>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartColorInd></PartColorInd>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartCoatedInd></PartCoatedInd>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<PartDrwInd></PartDrwInd>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<EsoGrNo></EsoGrNo>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<EsoGrDateNo></EsoGrDateNo>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<EsoRemark></EsoRemark>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<EsoCreator></EsoCreator>");
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"<EsoCreationDate></EsoCreationDate>");		
		
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"</PartDetails>");
		
		t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"</DMLDetails>");	
		
	}
	
	t5AddStrToSetCED(buff_cnt,bufferedXmlStrOut,"</ESOStatusReport>");

	
	
	
	return ifail;
}


int tmESOStatusReportServ(void *retValue)
{
	const char	*prog_name 	="tmESOStatusReportServ";
	int ifail = ITK_ok;
	int array_size = 0; 
	char **string_array 	= NULL;
	USERSERVICE_array_t 	array_struct;
	int buff_cnt=0;
	char** bufferedXmlStrOut = NULL;;	
	printf("\n Start----tmESOStatusReportServ....\n");fflush(stdout);
	char* Datefrom = NULL;
	char* Dateto = NULL;
		
	//USERARG_get_string_argument(&releaseStatusStr);
	USERARG_get_string_argument(&Datefrom);
	USERARG_get_string_argument(&Dateto);
	//print input parameters
	printf("\nDatefrom==>%s\nDateto==>%s\n",Datefrom,Dateto);fflush(stdout);
		
	//end print input parameters
	


	//CALLAPI(dmlReleaseBetweenDates_new(Datefrom,Dateto,releaseStatusStr,PlantDup, projlen, Project_code_ids, colmnLen, additional_attrs, Planner,&bufferedXmlStrOut,&buff_cnt));
	
	CALLAPI(executeESOStatusReportLogic( Datefrom, Dateto, &bufferedXmlStrOut, &buff_cnt ));
	
	
	int m =0;
	//printf("\nESO Report Buff count=%d\n",buff_cnt);fflush(stdout);
	array_size = buff_cnt;
	string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
	
	for(m=0;m<buff_cnt;m++)
	{
		//printf("\n%s",bufferedXmlStrOut[m]);fflush(stdout);
		string_array[m] = bufferedXmlStrOut[m];
	}

	//printf("\nBefore returning Value\n");fflush(stdout);

	ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);

	if (array_struct.length != 0)
	*((USERSERVICE_array_t*) retValue) = array_struct;				

	//printf("After returning Value\n");fflush(stdout);	
	printf("\n End----tmESOStatusReportServ....\n");fflush(stdout);
	return ifail;
}



/*End - ESO Report Services */

/*Start - Annexure Header Workflow */

int isLiveForAnxHeader(tag_t *contrlTag, logical *result)
{
	int ifail = ITK_ok;
	printf("\nANX: Check for control object ESOMAIL....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "ANXHEDWF";
	qry_values[1] = "ANXHEDWF";
	qry_values[2] = "FALSE";
		
	CALLAPI(QRY_find2("Control Objects...", &query));
	CALLAPI(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	printf("\nANX:Control objects ANXHEDWF: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* usrInfo3 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{
			char* cntrlStr = NULL;
			CALLAPI(AOM_ask_value_string(cntrlObj,"object_string",&cntrlStr));
			printf("\nANX: Control object ===>%s", cntrlStr);fflush(stdout);
			
			CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&usrInfo3));
			printf("\nANX: Control object user info 3 ===>%s", usrInfo3);fflush(stdout);
			if(tc_strstr(usrInfo3,"YES")!=NULL)
			{
				printf("\nANX: Live for Annex header Creation\n");fflush(stdout);
				*result = TRUE;
			}			
			*contrlTag = cntrlObj;
			
		}
		
	}
	
	return ifail;
}
//partTag, anxDesc, anxProjCode, anxStnNumb
int tmCreateAnnexHeader(tag_t partTag, char* anxDesc, char* anxProjCode, char* anxStnNumb, char** resultStr)
{
	int ifail = ITK_ok;	
	tag_t contrlObj = NULLTAG;
	logical liveFlag = FALSE;
	tag_t cntrlObj = NULLTAG;
	
	*resultStr ="FALSE";
	CALLAPI(isLiveForAnxHeader(&cntrlObj,&liveFlag)); //Check if control object CEDCreVl-CEDCreVl is present and returns TRUE
	printf("\nANX: Live for Annexure Header creatione==>%d\n",liveFlag);fflush(stdout);	
	if(!liveFlag)
	{
		printf("\nANX: NOT Live for ANX Header creation- Check for control object ANXHEDWF");fflush(stdout);
		*resultStr ="FALSE";
		return ifail;
	}
	if(cntrlObj != NULLTAG && liveFlag)
	{
		
		char* userInfo1	=	NULL;
		char* userInfo2	= NULL;
		char* userInfo3	=	NULL;
		char* userInfo4	=	NULL;
		char* userInfo5	=	NULL;
		char* userInfo6	=	NULL;
		char* userInfo7	=	NULL;
		char* userInfo8	=	NULL;
		char* userInfo9	=	NULL;
		char* userInfo10	=	NULL;
		
		
		
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_userinfo10",&userInfo10));
		
		printf("\nANXHEDWF Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\nt5_Userinfo6:[%s]\nt5_Userinfo7:[%s]\nt5_Userinfo8:[%s]\nt5_Userinfo9:[%s]\nt5_Userinfo10:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9,userInfo10);fflush(stdout);
		
		if (tc_strcmp(userInfo6,"YES")==0)
		{
			
			char* partNum = NULL;
			char* partDesc = NULL;
			char* rev = NULL;
			char* revStr = NULL;
			char* seq = NULL;
			date_t grDate;
			
			int cnt =0;
			tag_t * esoTags = NULL;
			char*	username				=NULL;
			char* sessionUser = NULL;
			tag_t	user_tag				=NULLTAG;
			int creFlag =0;
			char* partRelStatus = NULL;
			char* partTypeStr = NULL;
			
			POM_get_user(&username,&user_tag);
			POM_get_user_id(&sessionUser);
			printf("\nANX:Session username :%s,%s....\n",username, sessionUser);fflush(stdout);
			
			if(tc_strstr(userInfo7,username) != NULL || tc_strstr(userInfo7,sessionUser))//allow to create - temporary workaround -
			{
				
				//ITK_string_to_date(grDateStr,&grDate);

				CALLAPI(AOM_ask_value_string(partTag,"item_id",&partNum));
				printf("\nANX:partNum: %s",partNum); fflush(stdout);			
				
				CALLAPI (AOM_UIF_ask_value(partTag,"item_revision_id",&rev));
				printf("\nANX::rev:%s\n",rev); fflush(stdout);
				
				if(tc_strstr(rev,";") != NULL)
				{
					revStr = tc_strtok ( rev,";") ;
					//seqStr = tc_strtok ( NULL,";") ;	
				}
				

				CALLAPI (AOM_UIF_ask_value(partTag,"sequence_id",&seq));
				printf("\nANX:seq:%s",seq); fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(partTag,"t5_PartType",&partTypeStr));
				printf("\nANX:Part Type of Part: %s ", partTypeStr);fflush(stdout);
				//Check whether the part selected is ERC Released or above
				CALLAPI(AOM_UIF_ask_value(partTag,"release_status_list",&partRelStatus))
				printf("\nANX:LC State of Part: %s ", partRelStatus);fflush(stdout);
				if((tc_strstr(partRelStatus,"Released")!=NULL)||(tc_strstr(partRelStatus,"ERC Released")!=NULL))
				{
					creFlag =0;
				}
				else if((tc_strcmp(partTypeStr,"D")==0) && ((tc_strstr(partNum,userInfo8)!=NULL)) || (tc_strcmp(userInfo9,"STNBYPASS")==0))
				{
					printf("\nANX Valid STN part type selected");fflush(stdout);
					creFlag++;
				}
				else if(tc_strcmp(userInfo10,"BYPASS")==0)
				{
					printf("\nANX Bypass part type");fflush(stdout);
					creFlag++;
				}
				

				printf("\nANX:CED Cre Flag: %d ", creFlag);fflush(stdout);
				
				
				//Create ESO part -item_id
				
				if(creFlag!=0)
				{
					char* esoItemId = NULL;
					tag_t esoTag = NULLTAG;
					
					esoItemId = (char*)MEM_alloc(strlen(anxStnNumb)*sizeof(char) + 30);
					tc_strcpy(esoItemId,"");
					tc_strcat(esoItemId,anxStnNumb);
					tc_strcat(esoItemId,"_Annexure");

					
					printf("\nANX:New Annexure Header No Created Is: [%s]",esoItemId);fflush(stdout);
					
					//check if already ESO status is present in plm but not related.
					
					CALLAPI(getTCObject(esoItemId,"T5_AnxHeaderRevision",&esoTag));fflush(stdout);
					if(esoTag != NULLTAG)
					{
						printf("\nANX:Already Annexure Header tag is there with id %s",esoItemId);fflush(stdout);
						*resultStr ="DUPLICATE";
					}
					else
					{
						tag_t rev_type_tag = NULLTAG;
						tag_t rev_create_input_tag = NULLTAG;
						tag_t item_create_input_tag = NULLTAG;
						tag_t item_type_tag = NULLTAG;
						tag_t esoStatusTag = NULLTAG;
						printf("\nANX:Creating Annexure Header NR revision- first time.....\n");fflush(stdout);
						TCTYPE_find_type("T5_AnxHeaderRevision", NULL, &rev_type_tag);
						
						if(rev_type_tag!=NULLTAG)
						{
							TCTYPE_construct_create_input(rev_type_tag, &rev_create_input_tag);
							AOM_set_value_string(rev_create_input_tag, "object_name", esoItemId);
							AOM_set_value_string(rev_create_input_tag, "item_revision_id", "A;1");
							
							
							
	
							AOM_set_value_string(rev_create_input_tag, "t5_AnxDesc", anxDesc);
							AOM_set_value_string(rev_create_input_tag, "object_desc", anxDesc);
							AOM_set_value_string(rev_create_input_tag, "t5_AnxProjectNm", anxProjCode);
							AOM_set_value_string(rev_create_input_tag, "t5_AnxStnNum", anxStnNumb);
							AOM_set_value_string(rev_create_input_tag, "t5_AnxNumber", esoItemId);

							
							
							TCTYPE_find_type("T5_AnxHeader", NULL, &item_type_tag);
							if(item_type_tag!=NULLTAG)
							{
									printf("\nANX: item_type_tag Tag Found."); fflush(stdout);
									
									
							}
							TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag);

							AOM_set_value_string(item_create_input_tag, "item_id", esoItemId);
							AOM_set_value_string(item_create_input_tag, "object_name", esoItemId);
							AOM_set_value_tag(item_create_input_tag, "revision",rev_create_input_tag);

							//Create ESO status and its  Revision
							TCTYPE_create_object(item_create_input_tag, &esoStatusTag);
							
							if(esoStatusTag!=NULLTAG)
							{
								printf("\nANX:ANX Header  created."); fflush(stdout);					 
								AOM_save_with_extensions(esoStatusTag);				
							}
							//Get ESO Status Item revision
							tag_t * eso_rev_list = NULL;
							int eso_item_count = 0;
							tag_t esoStatusRevTag = NULLTAG;
							ITEM_list_all_revs (esoStatusTag, &eso_item_count, &eso_rev_list);
							
							if(eso_item_count>0)
							{
								esoStatusRevTag = eso_rev_list[0];
								
								if(esoStatusRevTag!=NULLTAG)
								{
									
									CALLAPI(relatePrimaryWithSecondaryObj(partTag,esoStatusRevTag,"T5_TcPrtHasAnx"));
									CALLAPI(relatePrimaryWithSecondaryObj(esoStatusRevTag,partTag,"T5_AnxForPart"));
									
								}									
								
							}
																					
												
						}
						
						*resultStr = "TRUE";
					}
					
				
							
				}
				else
				{
					*resultStr = "INVALIDPART";
				}
		
				
				
			}
			else
			{
				*resultStr ="NOACCESS";
			}
			
	
			
			

			
					
		}
		else
		{
			*resultStr ="FALSE";
		}
		
		

		
		
		
	}
		
	
	
	
	return ifail;
}



int tmAnxHeaderCreServ(void *retValue)
{
	printf("\n STN: Service:Start----tmAnxHeaderCreServ....\n");fflush(stdout);
	
	const char	*prog_name 	="tmAnxHeaderCreServ";
	
	int ifail = ITK_ok;
	int array_size = 0;
	tag_t* tag_array = NULL;
	USERSERVICE_array_t 	array_struct;
	
	tag_t partTag = NULLTAG;
	char* anxDesc = NULL;
	char* anxProjCode = NULL;
	char* anxStnNumb = NULL;
	char *resultStr = NULL;
	char * resultStr1 = NULL;
;
	USERARG_get_tag_argument(&partTag);
	USERARG_get_string_argument(&anxDesc);
	USERARG_get_string_argument(&anxProjCode);
	USERARG_get_string_argument(&anxStnNumb);
	
	printf("\nAnx Description:%s\nAnx Project Code:%s\nAnx STN Numb:%s\n",anxDesc,anxProjCode,anxStnNumb);fflush(stdout);
	
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );
	if(partTag !=NULLTAG)
	{
		
		printf("STN:Got the part tag object");fflush(stdout);
		//tmCreateESOStatus(tag_t partTag, char* esoStatStr, char* grNumber, char* grDateStr, char* esoRemark)
		CALLAPI(tmCreateAnnexHeader(partTag, anxDesc, anxProjCode, anxStnNumb, &resultStr));
		
		printf("\nANX: Output result string: %s", resultStr);fflush(stdout);
					
	}
	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nANX: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	MEM_free(resultStr1);
	printf("After returning Value\n");fflush(stdout);	
	printf("\n STN:Annex Header  Service:End----tmAnxHeaderCreServ....\n");fflush(stdout);
	return ifail;	
	
}




EPM_decision_t tm_ValidateToSubmitAnnexureWFFn( EPM_rule_message_t msg)
{
	EPM_decision_t	decision = EPM_go;
	int ifail = ITK_ok;
	//char* dmlRelTypeDisplayStr = NULL;
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	rootTask = NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	const char * prog_name ="tm_ValidateToSubmitAnnexureWFFn";
	
	
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
		
	POM_get_user(&username,&user_tag);
	printf("\nStarting for username :%s....\n",username);fflush(stdout);
	
	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nRoot task found");fflush(stdout);
	
	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
	printf("\nCurrent Task:%s\n",currentTaskName);fflush(stdout);

	CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
	printf("\nParent Name:%s\n",parentTaskName);fflush(stdout);	
	
	CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
	printf("\ntargetobjects_count:%d\n",targetobjects_count);fflush(stdout);	
	
	//CALLAPI(isLiveForESOReview(&cntrlObj,&liveFlag));
	

	CALLAPI(isLiveForAnxHeader(&cntrlObj,&liveFlag)); //Check if control object CEDCreVl-CEDCreVl is present and returns TRUE
	printf("\nANX: Live for Annexure Header creatione==>%d\n",liveFlag);fflush(stdout);	
	if(!liveFlag)
	{
		//printf("\nANX: NOT Live for ANX Header creation- Check for control object ANXHEDWF");fflush(stdout);
		printf("\nANX:Not Live for submitting part to this workflow. Please contact PLM Admin Team\n");fflush(stdout);
		char* buff = NULL;
		ifail=T5_WorkFlowHandlerAnxErr;
		buff = (char*)MEM_alloc(200*sizeof(char));
		sprintf(buff, "Not Live for submitting part to this workflow. Please contact PLM Admin Team");
		EMH_store_error_s1(EMH_severity_error,ifail,buff);
		decision = EPM_nogo;
		if(buff)MEM_free(buff);
		return decision;
	}
	printf("\n Live for Annexure WF  check in rule handler ===> %d\n",liveFlag);fflush(stdout);
	if(cntrlObj != NULLTAG && liveFlag)
	{
		
		char* userInfo1	=	NULL;
		char* userInfo2	= 	NULL;
		char* userInfo3	=	NULL;
		char* userInfo4	=	NULL;
		char* userInfo5	=	NULL;
		char* userInfo6	=	NULL;
		char* userInfo7	=	NULL;
		char* userInfo8	=	NULL;
		char* userInfo9	=	NULL;
		char* userInfo10	=	NULL;
		
		
		
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_userinfo10",&userInfo10));
		
		printf("\nANXHEDWF Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\nt5_Userinfo6:[%s]\nt5_Userinfo7:[%s]\nt5_Userinfo8:[%s]\nt5_Userinfo9:[%s]\nt5_Userinfo10:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9,userInfo10);fflush(stdout);
		if (tc_strstr(userInfo1,",YES,")!=NULL)
		{
			decision = EPM_nogo;
			if(targetobjects_count > 0)
			{
				int i = 0;
				tag_t objectTypeTag = NULLTAG;
				char *type_name = NULL;
				tag_t partTag = NULLTAG;
				
				for(i=0;i<targetobjects_count;i++)
				{
					CALLAPI(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
					CALLAPI(TCTYPE_ask_name2( objectTypeTag, &type_name));
					printf("\ntype_name ==> %s\n", type_name);fflush(stdout);
					if (tc_strcmp(type_name,"Design Revision")==0)
					{
						
					    partTag = targetobjects[i];
						break;										
							
					}					
					
				}
				
				if(partTag!=NULLTAG)
				{
					char* partNo = NULL;
					char* partType = NULL;
					
					CALLAPI(AOM_ask_value_string(partTag,"item_id",&partNo));
					printf("\nANX: Item ID:%s\n",partNo);fflush(stdout);
					//t5_PartType

					CALLAPI(AOM_ask_value_string(partTag,"t5_PartType",&partType));
					printf("\nANX: Part Type of the part:%s\n",partType);fflush(stdout);
					
					if(tc_strcmp(partType,"D")==0)
					{
						//allowed
						
						
						if(tc_strstr(partNo,"STN")!=NULL || tc_strstr(userInfo2,",BYPASS_STN,")!=NULL)
						{
							printf("\nValid STN Part");fflush(stdout);
							decision = EPM_go;
							return decision;
						}
						else
						{
							printf("\n %s is not valid STN Part. You cannot submit this part to this workflow\n",partNo);fflush(stdout);
							char* buff = NULL;
							ifail=T5_WorkFlowHandlerAnxErr;
							buff = (char*)MEM_alloc(200*sizeof(char));
							sprintf(buff, "%s is not valid STN Part. You cannot submit this part to Annexure Workflow.", partNo);
							EMH_store_error_s1(EMH_severity_error,ifail,buff);
							decision = EPM_nogo;
							if(buff)MEM_free(buff);
							return decision;						
						}
					}
					else
					{
						//Not allowed
							printf("\n %s is not valid STN Part. You cannot submit this part to this workflow\n",partNo);fflush(stdout);
							char* buff = NULL;
							ifail=T5_WorkFlowHandlerAnxErr;
							buff = (char*)MEM_alloc(200*sizeof(char));
							sprintf(buff, "%s is not valid STN Part. You cannot submit this part to Annexure Workflow.", partNo);
							EMH_store_error_s1(EMH_severity_error,ifail,buff);
							decision = EPM_nogo;
							if(buff)MEM_free(buff);
							return decision;						
					}
				}
				else
				{
					printf("\nThe object submitted is not valid STN Part. You cannot submit this part to this workflow\n");fflush(stdout);
					char* buff = NULL;
					ifail=T5_WorkFlowHandlerAnxErr;
					buff = (char*)MEM_alloc(200*sizeof(char));
					sprintf(buff, "The object submitted is not valid STN Part. You cannot submit this part to this workflow");
					EMH_store_error_s1(EMH_severity_error,ifail,buff);
					decision = EPM_nogo;
					if(buff)MEM_free(buff);
					return decision;							
				}
				
			}
		}
		else
		{
			printf("\n Not Live for submitting part to this workflow. Please contact PLM Admin Team\n");fflush(stdout);
			char* buff = NULL;
			ifail=T5_WorkFlowHandlerAnxErr;
			buff = (char*)MEM_alloc(200*sizeof(char));
			sprintf(buff, "Not Live for submitting part to this workflow. Please contact PLM Admin Team");
			EMH_store_error_s1(EMH_severity_error,ifail,buff);
			decision = EPM_nogo;
			if(buff)MEM_free(buff);
			return decision;
		}
		
	}		
	
	

	


	return decision;
}




EPM_decision_t tm_ValidateAnxHeaderSignOffFn( EPM_rule_message_t msg)//tm_ValidateAnxHeaderSignOffFn
{
	EPM_decision_t	decision = EPM_go;
	int ifail = ITK_ok;
	//char* dmlRelTypeDisplayStr = NULL;
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	rootTask = NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	const char * prog_name ="tm_ValidateAnxHeaderSignOffFn";
	tag_t dmlTag = NULLTAG;
	
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
		
	POM_get_user(&username,&user_tag);
	printf("\nStarting for username :%s....\n",username);fflush(stdout);
	
	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nRoot task found");fflush(stdout);
	
	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
	printf("\nCurrent Task:%s\n",currentTaskName);fflush(stdout);

	CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
	printf("\nParent Name:%s\n",parentTaskName);fflush(stdout);	
	
	CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
	printf("\ntargetobjects_count:%d\n",targetobjects_count);fflush(stdout);	
	
	//CALLAPI(isLiveForESOReview(&cntrlObj,&liveFlag));
	
	
	printf("\n To be implemented Live for ESO check in rule handler ===> %d\n",liveFlag);fflush(stdout);
	


	return decision;
}




int tmCreateAnnexHeaderNew(char* anxDesc, char* anxProjCode, char* anxStnNumb, char** resultStr)
{
	int ifail = ITK_ok;	
	tag_t contrlObj = NULLTAG;
	logical liveFlag = FALSE;
	tag_t cntrlObj = NULLTAG;
	
	*resultStr ="FALSE";
	CALLAPI(isLiveForAnxHeader(&cntrlObj,&liveFlag)); //Check if control object CEDCreVl-CEDCreVl is present and returns TRUE
	printf("\nANX: Live for Annexure Header creatione==>%d\n",liveFlag);fflush(stdout);	
	if(!liveFlag)
	{
		printf("\nANX: NOT Live for ANX Header creation- Check for control object ANXHEDWF");fflush(stdout);
		*resultStr ="FALSE";
		return ifail;
	}
	if(cntrlObj != NULLTAG && liveFlag)
	{
		
		char* userInfo1	=	NULL;
		char* userInfo2	= 	NULL;
		char* userInfo3	=	NULL;
		char* userInfo4	=	NULL;
		char* userInfo5	=	NULL;
		char* userInfo6	=	NULL;
		char* userInfo7	=	NULL;
		char* userInfo8	=	NULL;
		char* userInfo9	=	NULL;
		char* userInfo10	=	NULL;
		
		
		
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
		CALLAPI(AOM_ask_value_string(cntrlObj,"t5_userinfo10",&userInfo10));
		
		printf("\nANXHEDWF Control object information:\nt5_Userinfo1:[%s]\nt5_Userinfo2:[%s]\nt5_Userinfo3:[%s]\nt5_Userinfo4:[%s]\nt5_Userinfo5:[%s]\nt5_Userinfo6:[%s]\nt5_Userinfo7:[%s]\nt5_Userinfo8:[%s]\nt5_Userinfo9:[%s]\nt5_Userinfo10:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9,userInfo10);fflush(stdout);
		
		if (tc_strcmp(userInfo6,"YES")==0)
		{
			

			char*	username				=NULL;
			char* sessionUser = NULL;
			tag_t	user_tag				=NULLTAG;

			
			POM_get_user(&username,&user_tag);
			POM_get_user_id(&sessionUser);
			printf("\nANX:Session username :%s,%s....\n",username, sessionUser);fflush(stdout);
			
			if(tc_strstr(userInfo7,username) != NULL || tc_strstr(userInfo7,sessionUser))//allow to create - temporary workaround -
			{
				

			
				char* esoItemId = NULL;
				tag_t esoTag = NULLTAG;
				
				esoItemId = (char*)MEM_alloc(strlen(anxStnNumb)*sizeof(char) + 30);
				tc_strcpy(esoItemId,"");
				tc_strcat(esoItemId,anxStnNumb);
				tc_strcat(esoItemId,"_Annexure");

				
				printf("\nANX:New Annexure Header No Created Is: [%s]",esoItemId);fflush(stdout);
				
				//check if already ESO status is present in plm but not related.
				
				CALLAPI(getTCObject(esoItemId,"T5_AnxHeaderRevision",&esoTag));fflush(stdout);
				if(esoTag != NULLTAG)
				{
					printf("\nANX:Already Annexure Header tag is there with id %s",esoItemId);fflush(stdout);
					*resultStr ="DUPLICATE";
				}
				else
				{
					tag_t rev_type_tag = NULLTAG;
					tag_t rev_create_input_tag = NULLTAG;
					tag_t item_create_input_tag = NULLTAG;
					tag_t item_type_tag = NULLTAG;
					tag_t esoStatusTag = NULLTAG;
					printf("\nANX:Creating Annexure Header NR revision- first time.....\n");fflush(stdout);
					TCTYPE_find_type("T5_AnxHeaderRevision", NULL, &rev_type_tag);
					
					if(rev_type_tag!=NULLTAG)
					{
						TCTYPE_construct_create_input(rev_type_tag, &rev_create_input_tag);
						AOM_set_value_string(rev_create_input_tag, "object_name", esoItemId);
						AOM_set_value_string(rev_create_input_tag, "item_revision_id", "A;1");
						
						
						

						AOM_set_value_string(rev_create_input_tag, "t5_AnxDesc", anxDesc);
						AOM_set_value_string(rev_create_input_tag, "object_desc", anxDesc);
						AOM_set_value_string(rev_create_input_tag, "t5_AnxProjectNm", anxProjCode);
						AOM_set_value_string(rev_create_input_tag, "t5_AnxStnNum", anxStnNumb);
						AOM_set_value_string(rev_create_input_tag, "t5_AnxNumber", esoItemId);

						
						
						TCTYPE_find_type("T5_AnxHeader", NULL, &item_type_tag);
						if(item_type_tag!=NULLTAG)
						{
								printf("\nANX: item_type_tag Tag Found."); fflush(stdout);
								
								
						}
						TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag);

						AOM_set_value_string(item_create_input_tag, "item_id", esoItemId);
						AOM_set_value_string(item_create_input_tag, "object_name", esoItemId);
						AOM_set_value_tag(item_create_input_tag, "revision",rev_create_input_tag);

						//Create ESO status and its  Revision
						TCTYPE_create_object(item_create_input_tag, &esoStatusTag);
						
						if(esoStatusTag!=NULLTAG)
						{
							printf("\nANX:ANX Header  created."); fflush(stdout);					 
							AOM_save_with_extensions(esoStatusTag);				
						}

																				
											
					}
					
					*resultStr = "TRUE";
				}
				
			
						


				
				
			}
			else
			{
				*resultStr ="NOACCESS";
			}
			
	
			
			

			
					
		}
		else
		{
			*resultStr ="FALSE";
		}
		
		

		
		
		
	}
		
	
	
	
	return ifail;
}



int tmAnxHeaderCreServNew(void *retValue)
{
	printf("\n STN: Service:Start----tmAnxHeaderCreServNew....\n");fflush(stdout);
	
	const char	*prog_name 	="tmAnxHeaderCreServNew";
	
	int ifail = ITK_ok;
	int array_size = 0;
	tag_t* tag_array = NULL;
	USERSERVICE_array_t 	array_struct;
	
	
	char* anxDesc = NULL;
	char* anxProjCode = NULL;
	char* anxStnNumb = NULL;
	char *resultStr = NULL;
	char * resultStr1 = NULL;
;
	//USERARG_get_tag_argument(&partTag);
	USERARG_get_string_argument(&anxDesc);
	USERARG_get_string_argument(&anxProjCode);
	USERARG_get_string_argument(&anxStnNumb);
	
	printf("\nAnx Description:%s\nAnx Project Code:%s\nAnx STN Numb:%s\n",anxDesc,anxProjCode,anxStnNumb);fflush(stdout);
	
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );

	//tmCreateESOStatus(tag_t partTag, char* esoStatStr, char* grNumber, char* grDateStr, char* esoRemark)
	CALLAPI(tmCreateAnnexHeaderNew(anxDesc, anxProjCode, anxStnNumb, &resultStr));
	
	printf("\nANX: Output result string: %s", resultStr);fflush(stdout);
					

	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nANX: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	MEM_free(resultStr1);
	printf("After returning Value\n");fflush(stdout);	
	printf("\n STN:Annex Header  Service:End----tmAnxHeaderCreServ....\n");fflush(stdout);
	return ifail;	
	
}



/* End - Annexure Header Workflow */

/*Generic Handler */

//Rule Handler for checking sign off comment mandatory in performsignoff of Review Task

EPM_decision_t tm_CheckSignOffCommentFn( EPM_rule_message_t msg)
{
	EPM_decision_t decision = EPM_go;
	int ifail = ITK_ok;
	//implement your logic
	tag_t user_tag = NULLTAG;
	char* username = NULL;
	EPM_signoff_decision_t desc = EPM_no_decision;
	char* comments = NULL;
	date_t decision_date = NULLDATE;
	
	POM_get_user(&username,&user_tag);
	printf("\nStarting for username :%s....\n",username);fflush(stdout);	

	CALLAPI(EPM_ask_decision(msg.task,user_tag,&desc,&comments,&decision_date));
	
	
	printf("\ncomments ==> %s\n",comments);fflush(stdout);
	
	if(comments == NULL)
	{
		
		char* buff = NULL;
		ifail=T5_WorkFlowHandlerESOErr;
		buff = (char*)MEM_alloc(200*sizeof(char));
		sprintf(buff, "Sign off Comment is mandatory. Kindly enter comments before sign off");
		EMH_store_error_s1(EMH_severity_error,ifail,buff);
		decision = EPM_nogo;
		if(buff)MEM_free(buff);
		return decision; 						
	}
	else
	{
		if(tc_strcmp(comments,"")==0)
		{
			char* buff = NULL;
			ifail=T5_WorkFlowHandlerESOErr;
			buff = (char*)MEM_alloc(200*sizeof(char));
			sprintf(buff, "Sign off Comment is blank. Kindly enter comments before sign off");
			EMH_store_error_s1(EMH_severity_error,ifail,buff);
			decision = EPM_nogo;
			if(buff)MEM_free(buff);
			return decision; 						
		}
	}	
	
	return decision;
}

//EPM-check-signoff-comments [-decision= approve | reject ]

EPM_decision_t tm_EPM_check_signoff_commentsFn( EPM_rule_message_t msg)
{
	EPM_decision_t	decision = EPM_go;
	int ifail = ITK_ok;

	char*	username = NULL;
	tag_t	user_tag = NULLTAG;
	tag_t	rootTask = NULLTAG;
	int cnt = 0;
	tag_t* signOffTags = NULL;

	
	const char * prog_name ="tm_EPM_check_signoff_commentsFn";


	POM_get_user(&username,&user_tag);
	printf("\nStarting for username :%s....\n",username);fflush(stdout);
	
	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nRoot task found");fflush(stdout);	
	
	CALLAPI(EPM_ask_attachments(msg.task, EPM_signoff_attachment,&cnt, &signOffTags))
	
	
	printf("\n No of Sign off Tags ===> %d\n",cnt);fflush(stdout);
	
	if(cnt>0)
	{
		//int n=0;
		tag_t signOffTag = NULLTAG;
		EPM_signoff_decision_t decsn = EPM_no_decision;
		char* comments = NULL;
		date_t decision_date = NULLDATE;
		
		signOffTag = signOffTags[0];
		
		ifail = EPM_ask_signoff_decision(signOffTag, &decsn, &comments, &decision_date);
		printf("\ncomments ==> %s\n",comments);fflush(stdout);
	
		if(comments == NULL)
		{
			
			char* buff = NULL;
			ifail=T5_WorkFlowHandlerESOErr;
			buff = (char*)MEM_alloc(200*sizeof(char));
			sprintf(buff, "Sign off Comment is mandatory. Kindly enter comments before sign off");
			EMH_store_error_s1(EMH_severity_error,ifail,buff);
			decision = EPM_nogo;
			if(buff)MEM_free(buff);
			return decision; 						
		}
		else
		{
			if(tc_strcmp(comments,"")==0)
			{
				char* buff = NULL;
				ifail=T5_WorkFlowHandlerESOErr;
				buff = (char*)MEM_alloc(200*sizeof(char));
				sprintf(buff, "Sign off Comment is blank. Kindly enter comments before sign off");
				EMH_store_error_s1(EMH_severity_error,ifail,buff);
				decision = EPM_nogo;
				if(buff)MEM_free(buff);
				return decision; 						
			}
		}	
				
		
		
		
	}

	
	
	return decision;
	
}

extern DLLAPI int  tmESORev_save_method(METHOD_message_t *msg, va_list args)
{
	int ifail = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	
	tag_t objTypeTag = NULLTAG;
	char* object_type_name = NULL;
	
	char	*esoPartNum		= NULL;
	char	*esoParRevSeq		= NULL;
	char	*esoPartRelzState	= NULL;
	
	
	printf("\nInside Save method of T5ESOStatus Rev !!!!!!!!!!!!!!!!..................\n");fflush(stdout);
	//TO DO
	
	if(objTag != NULLTAG)
	{
		if(TCTYPE_ask_object_type(objTag,&objTypeTag));
		if(TCTYPE_ask_name2(objTypeTag,&object_type_name));
		printf("\nESOSAVE: Object Type Name is := %s", object_type_name);fflush(stdout);
		
		if(tc_strcmp(object_type_name,"T5_ESOStRevision")==0)
		{
			tag_t sessionUserTag = NULLTAG;
			char* sessionUserName = NULL;
			char* userid = NULL;
			tag_t current_role_tag = NULLTAG;
			char* rolename = NULL;
			
			tag_t groupTag = NULLTAG;
			char* groupname = NULL;
			//tag_t current_groupmember_tag = NULLTAG;
			char* esoStatusStr = NULL;
			
			POM_get_user(&sessionUserName,&sessionUserTag);
			SA_ask_user_identifier2	(sessionUserTag,&userid);		
			SA_ask_current_role(&current_role_tag);			
			SA_ask_role_name2(current_role_tag, &rolename);
			printf ("\nESOSAVE: Logged in user:%s %s\n",userid,sessionUserName);fflush(stdout);	

			POM_ask_group(&groupname, &groupTag);
			
						
			printf("\nRole Name: %s\nGroup Name: %s\n",rolename,groupname);fflush(stdout);
			
			if(AOM_ask_value_string(objTag,"t5_ESOStatus",&esoStatusStr));
			printf("\nESO Status:[%s]\n",esoStatusStr);fflush(stdout);
									
			if(AOM_ask_value_string(objTag,"current_id",&esoPartNum)!=ITK_ok) PrintErrorStack();
			if(AOM_ask_value_string(objTag,"object_string",&esoParRevSeq)!=ITK_ok) PrintErrorStack();
			if(AOM_UIF_ask_value(objTag,"release_status_list",&esoPartRelzState)!=ITK_ok) PrintErrorStack();
			printf("\nesoParRevSeq : %s	ReleaseStatus : %s",esoParRevSeq,esoPartRelzState);

			if(tc_strcmp(userid,"ercpsup")!=0 && tc_strcmp(userid,"loader")!=0 && tc_strcmp(userid,"infodba")!=0 && tc_strcmp(groupname,"PLM_Support_Group")!=0 &&tc_strcmp(groupname,"dba")!=0 )
			{
				
				if(tc_strstr(esoPartRelzState,"ERC Released")!=NULL)
				{
					printf("\nESO Part %s Already ERC Released. You don't have access to edit ERC Released ESO Part\n",esoPartNum);fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err,"ESO Part is ERC Released, You don't have access to edit");
					return ITK_err;
				}
							
				
			}

			tag_t cntrlObj = NULLTAG;
			logical liveFlag = false;
			ifail = isLiveForESOReview(&cntrlObj,&liveFlag);
		
		
			if(cntrlObj!=NULLTAG)
			{		
				char* userInfo10 = NULL;
				
				ifail = AOM_ask_value_string(cntrlObj,"t5_userinfo10",&userInfo10);
				
				if(userInfo10==NULL) userInfo10="";
				
				if(tc_strcmp(userInfo10,"ON")==0)
				{
					//ESO_PV_Head_Eng_Reviewer is not used. Instead use PV_ESO_HEAD_REVIEW_GROUP and CV_ESO_HEAD_REVIEW_GROUP
					if(tc_strcmp(esoStatusStr,"DR4 without ESO (Head Engineering Approval)")==0 && (tc_strcmp(rolename,"PV_ESO_HEAD_REVIEW_GROUP")==0 || tc_strcmp(rolename,"ESO_PV_Head_Eng_Reviewer")==0))
					{
						printf("\n Should not be able to edit...\n");fflush(stdout);
						
						printf("\nPV_ESO_HEAD_REVIEW_GROUP should not be able to edit ESO object\n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"\nEdit Access Denied.\nPV_ESO_HEAD_REVIEW_GROUP should not be able to edit ESO object having ESO status as \"DR4 without ESO (Head Engineering Approval)\"");
						return ITK_err;				
						
					}
					//DML_Participants_Group::PSE_ESO_HEAD_REVIEW_GROUP
					if(tc_strcmp(esoStatusStr,"AR4 without ESO (Head PSE Approval)")==0 && tc_strcmp(rolename,"PSE_ESO_HEAD_REVIEW_GROUP")==0)
					{
						printf("\n Should not be able to edit...\n");fflush(stdout);
						
						printf("\nPV_ESO_HEAD_REVIEW_GROUP should not be able to edit ESO object\n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"\nEdit Access Denied.\nPSE_ESO_HEAD_REVIEW_GROUP should not be able to edit ESO object having ESO status as \"AR4 without ESO (Head PSE Approval)\"");
						return ITK_err;				
						
					}
					//CV_ESO_HEAD_REVIEW_GROUP
					if(tc_strcmp(esoStatusStr,"DR4 without ESO (Head Engineering Approval)")==0 && tc_strcmp(rolename,"CV_ESO_HEAD_REVIEW_GROUP")==0)
					{
						printf("\n Should not be able to edit...\n");fflush(stdout);
						
						printf("\nPV_ESO_HEAD_REVIEW_GROUP should not be able to edit ESO object\n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"\nEdit Access Denied.\nCV_ESO_HEAD_REVIEW_GROUP should not be able to edit ESO object having ESO status as \"DR4 without ESO (Head Engineering Approval)\"");
						return ITK_err;				
						
					}				
					
					
				}
				else
				{
					printf("\n Not live for checkout validation, userInfo10 [%s] \n", userInfo10);fflush(stdout);
				}
				

			}
			else
			{
				printf("\n Not live for checkout validation\n");fflush(stdout);
			}

									
			
			
		}
	}
	
	
	return ifail;
}

extern DLLAPI int esoCheckOutValidation(METHOD_message_t *msg, va_list args)
{
	int ifail = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag,item_tag = NULLTAG;

	char *type_name = NULL;
	char	*esoPartNum		= NULL;
	char	*esoParRevSeq		= NULL;
	char	*esoPartRelzState	= NULL;

		tag_t sessionUserTag = NULLTAG;
		char* sessionUserName = NULL;
		char* userid = NULL;
		tag_t current_role_tag = NULLTAG;
		char* rolename = NULL;
		
		tag_t groupTag = NULLTAG;
		char* groupname = NULL;

	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
	//POM_get_user(&username,&user_tag);
	printf("\nesoCheckOutValidation PreAction objTypeTag [%s]\n",type_name);fflush(stdout);

	if(strcmp(type_name,"T5_ESOStRevision")==0)
	{
		
		
		//tag_t current_groupmember_tag = NULLTAG;
		char* esoStatusStr = NULL;
		
		POM_get_user(&sessionUserName,&sessionUserTag);
		SA_ask_user_identifier2	(sessionUserTag,&userid);		
		SA_ask_current_role(&current_role_tag);			
		SA_ask_role_name2(current_role_tag, &rolename);
		printf ("\nESOSAVE: Logged in user:%s %s\n",userid,sessionUserName);fflush(stdout);	

		POM_ask_group(&groupname, &groupTag);
		
					
		printf("\nRole Name: %s\nGroup Name: %s\n",rolename,groupname);fflush(stdout);
		
		if(AOM_ask_value_string(objTag,"t5_ESOStatus",&esoStatusStr));
		printf("\nESO Status:[%s]\n",esoStatusStr);fflush(stdout);
								
		if(AOM_ask_value_string(objTag,"current_id",&esoPartNum)!=ITK_ok) PrintErrorStack();
		if(AOM_ask_value_string(objTag,"object_string",&esoParRevSeq)!=ITK_ok) PrintErrorStack();
		if(AOM_UIF_ask_value(objTag,"release_status_list",&esoPartRelzState)!=ITK_ok) PrintErrorStack();
		printf("\nesoParRevSeq : %s	ReleaseStatus : %s",esoParRevSeq,esoPartRelzState);

		if(tc_strcmp(userid,"ercpsup")!=0 && tc_strcmp(userid,"loader")!=0 && tc_strcmp(userid,"infodba")!=0 && tc_strcmp(groupname,"PLM_Support_Group")!=0 && tc_strcmp(groupname,"dba")!=0)
		{
			
			if(tc_strstr(esoPartRelzState,"ERC Released")!=NULL)
			{
				printf("\nESO Part %s Already ERC Released. You don't have access to edit ERC Released ESO Part\n",esoPartNum);fflush(stdout);
				EMH_store_error_s1(EMH_severity_error,ITK_err,"ESO Part is ERC Released, You don't have access to edit");
				return ITK_err;
			}
						
			
		}

		tag_t cntrlObj = NULLTAG;
		logical liveFlag = false;
		ifail = isLiveForESOReview(&cntrlObj,&liveFlag);
	
	
		if(cntrlObj!=NULLTAG)
		{		
			char* userInfo10 = NULL;
			
			ifail = AOM_ask_value_string(cntrlObj,"t5_userinfo10",&userInfo10);
			
			if(userInfo10==NULL) userInfo10="";
			
			if(tc_strcmp(userInfo10,"ON")==0)
			{
				//ESO_PV_Head_Eng_Reviewer is not used. Instead use PV_ESO_HEAD_REVIEW_GROUP and CV_ESO_HEAD_REVIEW_GROUP
				if(tc_strcmp(esoStatusStr,"DR4 without ESO (Head Engineering Approval)")==0 && (tc_strcmp(rolename,"PV_ESO_HEAD_REVIEW_GROUP")==0 || tc_strcmp(rolename,"ESO_PV_Head_Eng_Reviewer")==0))
				{
					printf("\n Should not be able to edit...\n");fflush(stdout);
					
					printf("\nPV_ESO_HEAD_REVIEW_GROUP should not be able to edit ESO object\n");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,"\nEdit Access Denied.\nPV_ESO_HEAD_REVIEW_GROUP should not be able to edit ESO object having ESO status as \"DR4 without ESO (Head Engineering Approval)\"");
					return ITK_err;				
					
				}
				//DML_Participants_Group::PSE_ESO_HEAD_REVIEW_GROUP
				if(tc_strcmp(esoStatusStr,"AR4 without ESO (Head PSE Approval)")==0 && tc_strcmp(rolename,"PSE_ESO_HEAD_REVIEW_GROUP")==0)
				{
					printf("\n Should not be able to edit...\n");fflush(stdout);
					
					printf("\nPV_ESO_HEAD_REVIEW_GROUP should not be able to edit ESO object\n");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,"\nEdit Access Denied.\nPSE_ESO_HEAD_REVIEW_GROUP should not be able to edit ESO object having ESO status as \"AR4 without ESO (Head PSE Approval)\"");
					return ITK_err;				
					
				}
				//CV_ESO_HEAD_REVIEW_GROUP
				if(tc_strcmp(esoStatusStr,"DR4 without ESO (Head Engineering Approval)")==0 && tc_strcmp(rolename,"CV_ESO_HEAD_REVIEW_GROUP")==0)
				{
					printf("\n Should not be able to edit...\n");fflush(stdout);
					
					printf("\nPV_ESO_HEAD_REVIEW_GROUP should not be able to edit ESO object\n");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,"\nEdit Access Denied.\nCV_ESO_HEAD_REVIEW_GROUP should not be able to edit ESO object having ESO status as \"DR4 without ESO (Head Engineering Approval)\"");
					return ITK_err;				
					
				}				
				
				
			}
			else
			{
				printf("\n Not live for checkout validation, userInfo10 [%s] \n", userInfo10);fflush(stdout);
			}
			

		}
		else
		{
			printf("\n Not live for checkout validation\n");fflush(stdout);
		}

								

			 		
	}
	if(strcmp(type_name,"T5_TSCompRevision")==0)
	{
		
		char *tsPartNum=NULL;
		char *tsParRevSeq=NULL;
		char *tsPartRelzState=NULL;
		
		POM_get_user(&sessionUserName,&sessionUserTag);
		SA_ask_user_identifier2	(sessionUserTag,&userid);		
		SA_ask_current_role(&current_role_tag);			
		SA_ask_role_name2(current_role_tag, &rolename);
		printf ("\ntsSAVE: Logged in user:%s %s\n",userid,sessionUserName);fflush(stdout);	

		POM_ask_group(&groupname, &groupTag);
		
					
		printf("\nRole Name: %s\nGroup Name: %s\n",rolename,groupname);fflush(stdout);
		
		
								
		if(AOM_ask_value_string(objTag,"current_id",&tsPartNum)!=ITK_ok) PrintErrorStack();
		if(AOM_ask_value_string(objTag,"object_string",&tsParRevSeq)!=ITK_ok) PrintErrorStack();
		if(AOM_UIF_ask_value(objTag,"release_status_list",&tsPartRelzState)!=ITK_ok) PrintErrorStack();
		printf("\ntsParRevSeq : %s	ReleaseStatus : %s",tsParRevSeq,tsPartRelzState);

		if(tc_strcmp(userid,"ercpsup")!=0 && tc_strcmp(userid,"loader")!=0 && tc_strcmp(userid,"infodba")!=0 && tc_strcmp(groupname,"PLM_Support_Group")!=0 && tc_strcmp(groupname,"dba")!=0)
		{
			
			if(tc_strstr(tsPartRelzState,"Release")!=NULL)
			{
				printf("\nTechnical Specification Header %s Already ERC Released. You don't have access to edit ERC Released Technical Specification without revise and check-out Part \n",tsPartNum);fflush(stdout);
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Technical Specification Header is ERC Released, You don't have access to edit");
				return ITK_err;
			}
			else if(tc_strlen(tsPartRelzState)<=0)
			{
				printf("\n there is no status found for Technical Specification Header %s ,therefore Check-Out not allowed\n",tsPartNum);fflush(stdout);
				EMH_store_error_s1(EMH_severity_error,ITK_err,"there is no status found for Technical Specification Header, therefore Check-Out not allowed");
				return ITK_err;
			}
			else if(tc_strstr(tsPartRelzState,"Working")!=NULL || tc_strstr(tsPartRelzState,"Review")!=NULL)
			{
				printf("\n there is ERC Review/Working status found for Technical Specification Header %s ,therefore Check-Out  allowed\n",tsPartNum);fflush(stdout);
			}
			else	
			{
				printf("\n there is no Review/Working status found for Technical Specification Header %s ,therefore Check-Out not allowed\n",tsPartNum);fflush(stdout);
				EMH_store_error_s1(EMH_severity_error,ITK_err,"there is no Review/Working status found for Technical Specification Header, therefore Check-Out not allowed");
				return ITK_err;
			}
			
		}

		
								

			 		
	}
	return ITK_ok;
}

//Sanjoy start color vf

/******************Sanjoy Color Change Option in VF DML Start****************************/
int isLiveColorReview(tag_t *contrlTag, logical *result)
{
	int ifail = ITK_ok;
	//printf("\nSAN:VF: Check for control object VFColorREV....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "VFColorREV";
	qry_values[1] = "VFColorREV";
	qry_values[2] = "FALSE";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	//printf("\nESO:Control objects VFColorREV: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		//char* usrInfo3 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{
			char* cntrlStr = NULL;
			if(AOM_ask_value_string(cntrlObj,"object_string",&cntrlStr));
			printf("\nESO: Control object ===>%s", cntrlStr);fflush(stdout);
			
			*result = TRUE;
			*contrlTag = cntrlObj;
			printf("\nSAN:VF: Live for Color Review parts through lifecycle\n");fflush(stdout);
			
		}
		
	}
	
	return ifail;
}


int getOptionValueStr(tag_t ConfigCtx,char* child_bl_formula,char * optionStr, char** optionValueStr)
{

	printf( "\n\t**********In checkClrSchemeChange funtion now ***************");
	int ifail = ITK_ok;
	tag_t  ConfigCtxObjTypeTag=NULLTAG;
	char   *Config_CtxType = NULL;
	char*	 SmVCContext			= NULL;
	char*	 SmCrIDContext			= NULL;

	if(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
	if(TCTYPE_ask_name2(ConfigCtxObjTypeTag,&Config_CtxType));
	//printf( "\n\t Config relation Config_CtxType :%s ..",Config_CtxType);

	if(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
	//printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);fflush(stdout);

	if(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
	//printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);fflush(stdout);


	char *qry_entriesOptFam[] = {"ID"};
	char **qry_valuesOptFam = (char **) MEM_alloc(50 * sizeof(char *));
	tag_t Optfmly_tag = NULLTAG;
	tag_t queryTagOptFam = NULLTAG;
	tag_t *revOptFam=NULL;
	int resultCountOptFam=0,n_entriesOptFam=1,j=0;

	char *qry_entriesOptFamVal[] = {"Thread ID","ID"};
	char **qry_valuesOptFamVal = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t OptfmlyVal_tag = NULLTAG;
	tag_t queryTagOptFamVal = NULLTAG;
	tag_t *revOptFamVal=NULL;
	int resultCountOptFamVal=0,n_entriesOptFamVal=2,i=0;
	char* OptValName=NULL;
	char* OptfmlyName=NULL;
	char* VariantFormulaStr=NULL;
	char* VariantFormulaStrOptionVal=NULL;
	VariantFormulaStr=(char *)MEM_alloc(300);
	VariantFormulaStrOptionVal=(char *)MEM_alloc(300);

	if(QRY_find2("Cfg0OptionFamiliesFromIDs", &queryTagOptFam));
	//printf("\n After IFERR_REPORT : QRY_find \n");fflush(stdout);
	if (queryTagOptFam)
	{
		//printf("2.Found Query \n");fflush(stdout);
	}
	else
	{
		//printf("Not Found Query");fflush(stdout);
	}
	 qry_valuesOptFam[0] = SmCrIDContext;
	if(QRY_execute(queryTagOptFam, n_entriesOptFam, qry_entriesOptFam, qry_valuesOptFam, &resultCountOptFam, &revOptFam));
	//printf(" \n resultCountOptFam : %d\n", resultCountOptFam); fflush(stdout);

	for (j=0;j<resultCountOptFam;j++ )
	{
		//printf( "\n\t****************In option family loop now *************");

		int Flag_child_bl_Found=0;
		int Flag_other_bl_Found=0;
		Optfmly_tag = revOptFam[j];
		CALLAPI(AOM_ask_value_string(Optfmly_tag,"object_name",&OptfmlyName));
		//printf("\n\t OptfmlyName Object String Type is :%s",OptfmlyName);	fflush(stdout);
		
		if(tc_strcmp(OptfmlyName,optionStr)!=0)
		{
			//printf("\nSkip it... As optionStr[%s] and OptfmlyName[%s] not same\n",optionStr,OptfmlyName);fflush(stdout);
			continue;
		}
		tc_strcpy(VariantFormulaStr,"");
		if (tc_strstr(OptfmlyName," ")!=NULL)
		{
			tc_strcat(VariantFormulaStr,"'");
			tc_strcat(VariantFormulaStr,OptfmlyName);
			tc_strcat(VariantFormulaStr,"'");
		}
		else
		{
			tc_strcat(VariantFormulaStr,OptfmlyName);
		}
		tc_strcat(VariantFormulaStr," = ");
		printf("\n\t VariantFormulaStr is :<%s>",VariantFormulaStr);	fflush(stdout);



		if(QRY_find2("__Cfg0OptionValuesFromOptionFamilyIDs", &queryTagOptFamVal));
		//printf("\n After IFERR_REPORT : QRY_find \n");fflush(stdout);
		if (queryTagOptFamVal)
		{
			//printf("Found Query __Cfg0OptionValuesFromOptionFamilyIDs \n");fflush(stdout);
		}
		else
		{
			//printf("Not Found Query __Cfg0OptionValuesFromOptionFamilyIDs ");fflush(stdout);
		}
		qry_valuesOptFamVal[0]= OptfmlyName;
		qry_valuesOptFamVal[1]= SmCrIDContext;
		if(QRY_execute(queryTagOptFamVal, n_entriesOptFamVal, qry_entriesOptFamVal, qry_valuesOptFamVal, &resultCountOptFamVal, &revOptFamVal));
		for (i=0;i<resultCountOptFamVal;i++ )
		{
			printf("\n\t***************** In option value loop now *******************");

			OptfmlyVal_tag = revOptFamVal[i];
			CALLAPI(AOM_ask_value_string(OptfmlyVal_tag,"object_name",&OptValName));
			printf("\n\t Value Object String  is :%s",OptValName);	fflush(stdout);
			
			tc_strcpy(VariantFormulaStrOptionVal,"");
			tc_strcat(VariantFormulaStrOptionVal,VariantFormulaStr);

			if (tc_strstr(OptValName," ")!=NULL)
			{
				tc_strcat(VariantFormulaStrOptionVal,"'");
				tc_strcat(VariantFormulaStrOptionVal,OptValName);
				tc_strcat(VariantFormulaStrOptionVal,"'");
			}
			else
			{
				tc_strcat(VariantFormulaStrOptionVal,OptValName);
			}

			//printf("\n\t Final VariantFormulaStr is :<%s> \n",VariantFormulaStrOptionVal);	fflush(stdout);
			
			if (tc_strstr(child_bl_formula,VariantFormulaStrOptionVal)!=NULL)
			{
				printf("\n\t child_bl_formula =[%s] &&  VariantFormulaStrOptionVal = [%s] \n",child_bl_formula,VariantFormulaStrOptionVal);

				printf("\n\t Matched for VariantFormulaStr is :<%s> \n",VariantFormulaStrOptionVal);	fflush(stdout);
				*optionValueStr = VariantFormulaStrOptionVal;
				return ITK_ok;
				
			}
			else
			{

			}


		}/// end of option value loop
		

	}/// end of option family loop
	
	return ITK_ok;;
}


int checkClrVF(tag_t ConfigCtx, char* child_bl_formula_prev, char* child_bl_formula_curr, logical* flag)
{
	int ifail = ITK_ok;
	
	char* optionValuePrevStr = NULL;
	char* optionValueCurrStr = NULL;
	
	char* optValSchemeNoCurrStr = NULL;
	char* optValSchemeNoPrevStr = NULL;
	
	
	
	
	
	printf("\nchild_bl_formula_prev[%s]\nchild_bl_formula_curr[%s]\n",child_bl_formula_prev,child_bl_formula_curr); fflush(stdout);
	if(child_bl_formula_prev != NULL)
	{
		CALLAPI(getOptionValueStr(ConfigCtx,child_bl_formula_prev,"COLOUR-BOM", &optionValuePrevStr));
		CALLAPI(getOptionValueStr(ConfigCtx,child_bl_formula_prev,"SCHEME-NO", &optValSchemeNoPrevStr));

		if(child_bl_formula_curr != NULL)
		{
						
			CALLAPI(getOptionValueStr(ConfigCtx,child_bl_formula_curr,"COLOUR-BOM", &optionValueCurrStr));
			CALLAPI(getOptionValueStr(ConfigCtx,child_bl_formula_curr,"SCHEME-NO", &optValSchemeNoCurrStr));	

			
			printf("\n For Prev line item COLOR-BOM Value is==============> %s\n",optionValuePrevStr);
			printf("\n For Current line item COLOR-BOM Value is==============> %s\n",optionValueCurrStr);

			printf("\n For Prev line item COLOR-BOM Value is==============> %s\n",optValSchemeNoPrevStr);
			printf("\n For Current line item COLOR-BOM Value is==============> %s\n",optValSchemeNoCurrStr);	
				
			
			
			if(tc_strcmp(optionValuePrevStr,optionValueCurrStr)==0 || tc_strcmp(optValSchemeNoPrevStr,optValSchemeNoCurrStr)==0 )
			{
				*flag = true;
				printf("\nSAN:Colpor related options changed");fflush(stdout);
				return ifail;
			}
			
		}
		else
		{
			printf("\n child_bl_formula_curr is null");fflush(stdout);
		}
		
	}
	
	
	
	return ifail;
}


int tmCheckColorChange(tag_t ArcModRevTag,tag_t moduleObject,tag_t ConfigCtx, char* objectId, char* objectrevId, char* child_bl_formula_prev, char* occ_effec_prev,char* occUidOnRel, char* occuid ,logical* allowed)
{
	int ifail = ITK_ok;
	
	printf("\n Inside ----tmCheckColorChange ...to implement the logic........\n");
	
	printf("\noccUidOnRel: [%s]  occuid: [%s]",occUidOnRel,occuid);fflush(stdout);
	
	
	int bvr_count = 0;
	tag_t* bvrs = NULL;
	tag_t bvr = NULLTAG;
	ifail = ITEM_rev_list_bom_view_revs(ArcModRevTag,&bvr_count, &bvrs);

	printf("\n test...bvr count is...%d",bvr_count);fflush(stdout);	
	if (bvr_count)
	{
		bvr = bvrs[0];
	}
	else
	{
		return ifail;
	}
	
	int n_occs = 0;
	tag_t* occsal = NULL;
	ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal );
	
	printf("\n test...n_occs is...%d",n_occs);fflush(stdout);
	
	
	
	//Get the item_id of the Arch Module
	char* archId = NULL;
	
	CALLAPI(AOM_ask_value_string(ArcModRevTag,"item_id",&archId));
	
	printf("\nSAN:tmCheckColorChange: Checking for ArchID[%s], Child Module[%s;%s], old occ id:[%s] \nVariant formula prev[%s]\n Occ Effectivity prev : [%s]",archId,objectId,objectrevId,occuid,child_bl_formula_prev,occ_effec_prev);fflush(stdout);
	
	tag_t window = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t top_line = NULLTAG;
	tag_t* chldTagLst = NULL;
	int chldCnt = 0;


	CALLAPI(PREF_set_logical_value("PSEShowUnconfigdEffPref",false));
	CALLAPI(BOM_create_window (&window));
	CALLAPI(CFM_find( "Latest Working", &rule ));
	
	
	CALLAPI(BOM_set_window_config_rule( window, rule ));
	CALLAPI(BOM_set_window_pack_all (window, false));
	CALLAPI(BOM_set_window_top_line (window, NULLTAG,ArcModRevTag, NULLTAG, &top_line));
	if(BOM_set_window_top_line_bvr(window,bvr,&top_line));

	//if(BOM_line_ask_all_child_lines(top_line,&count,&child));
	//printf("\n count::::::::>>>>>>>> %d\n",count);		
	
	if(top_line != NULLTAG)
	{
		tag_t* child_lines = NULL;
		int nChld = 0;
		int ij=0;
		//int childId = 0;
		//int childRevSeq = 0;
		char* child_id = NULL;
		char* child_rev_seq = NULL;			
		
		
		CALLAPI(BOM_line_ask_child_lines (top_line, &nChld, &child_lines));
		//CALLAPI(BOM_line_ask_all_child_lines (top_line, &nChld, &child_lines));
		
		printf("\nNo of child objects of  Arc Mod Rev are : %d",nChld);fflush(stdout);

		
		for(ij=0;ij<nChld;ij++)
		{
			ifail = AOM_ask_value_string(child_lines[ij],"bl_item_item_id",&child_id);
			ifail = AOM_ask_value_string(child_lines[ij],"bl_rev_item_revision_id",&child_rev_seq);

			printf("\n %d ==> child_id [%s;%s]",ij+1,child_id,child_rev_seq);fflush(stdout);
			
			if(tc_strcmp(child_id,objectId)==0 && tc_strcmp(child_rev_seq,objectrevId)==0)
			{
				//add to the set to compare the VF change.
				t5AddTagObjToSet(&chldCnt,&chldTagLst,child_lines[ij]);
			}

			
		}

		
	}
	
	printf("\nChild Line Tag count to compare for change in Color VF===> %d",chldCnt);fflush(stdout);
	
	if(chldCnt > 0)
	{
		int i=0;
		//int occEffec = 0;
		char* occ_effec_curr = NULL;
		char* child_bl_formula_curr = NULL;
		for(i=0;i<chldCnt;i++)
		{
			
			CALLAPI(AOM_ask_value_string(chldTagLst[i],"bl_occ_effectivity",&occ_effec_curr));
			CALLAPI(AOM_ask_value_string(chldTagLst[i], "bl_formula", &child_bl_formula_curr))
			printf("\nocc_effec_curr[%s]\t child_bl_formula_curr[%s]\n",occ_effec_curr,child_bl_formula_curr); fflush(stdout);
			
			CALLAPI(checkClrVF(ConfigCtx,child_bl_formula_prev,child_bl_formula_curr,allowed));
			

			
		}
	}
	
	
	
	
	CALLAPI(BOM_close_window(window));	
	
	
	
	return ifail;
}



int  tm_IsVFColorOptionModifiedFn(EPM_action_message_t  msg)
{
	int ifail = ITK_ok;
	const char * prog_name ="tm_IsVFColorOptionModifiedFn";
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
	
	CALLAPI(isLiveColorReview(&cntrlObj,&liveFlag));
	printf("\nSAN:VF:tm_IsVFColorOptionModifiedFn.. Live for Color Review for valid DML type==>%d\n",liveFlag);fflush(stdout);	
	if(!liveFlag)
	{
		printf("\nSAN:VF: NOT Live for Color Review- Check for control object VFColorREV");fflush(stdout);
		return ifail;
	}
	
	if(cntrlObj != NULLTAG && liveFlag)
	{
		tag_t rootTask = NULLTAG;
		int targetobjects_count = 0;
		tag_t* targetobjects = NULL;
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		printf("\nSAN:VF: Root task found");fflush(stdout);
		
		CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects));
		
		if(targetobjects_count > 0)
		{
			int i=0;
			tag_t objectTypeTag = NULLTAG;
			char *type_name = NULL;			
			
			for(i=0;i<targetobjects_count;i++)
			{
				CALLAPI(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
				CALLAPI(TCTYPE_ask_name2( objectTypeTag, &type_name));
				printf("\nESO: type_name ==> %s\n", type_name);fflush(stdout);
				
				if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
				{
					tag_t dmlTag = NULLTAG;
					dmlTag = targetobjects[i];
					char* dmlReleaseType = NULL;
					char* dmlRelTypeDisplayStr = NULL;
					char** moduleList = NULL;
					int moduleCnt = 0;
					
					CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlReleaseType));
					CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_rlstype",&dmlRelTypeDisplayStr));
					
					printf("\nESO: DML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);fflush(stdout);
					
					if(tc_strcmp(dmlReleaseType,"UVF")==0)
					{
						//Get the DML Task
						tag_t *dmlTaskTagObjects = NULL;
						tag_t dmlTaskTag = NULLTAG;
						int taskCnt = 0;
						
						//Set the BOM expansion preference to true
						logical prefOrig = false;
						logical pref = false;
						
						CALLAPI(PREF_ask_logical_value("PSEShowUnconfigdEffPref",0,&prefOrig));
						printf("\n Before: PSEShowUnconfigdEffPref====================> %d\n",prefOrig);fflush(stdout);
						
						CALLAPI(PREF_set_logical_value("PSEShowUnconfigdEffPref",true));
						CALLAPI(PREF_ask_logical_value("PSEShowUnconfigdEffPref",0,&pref));
						printf("\n After: PSEShowUnconfigdEffPref====================> %d\n",pref);fflush(stdout);

						
						CALLAPI(AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects));
						printf("\nESO: DML ERC Task Count:%d\n",taskCnt);fflush(stdout);
						
						if(taskCnt>0)
						{
							int jt = 0;
							char* object_type	=	NULL;
							for(jt=0;jt<taskCnt;jt++)
							{
								dmlTaskTag = dmlTaskTagObjects[jt];
								CALLAPI(AOM_ask_value_string(dmlTaskTag,"object_type",&object_type));
								printf("\nESO: DML Task object_type is :%s\n",object_type);fflush(stdout);
								
								if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
								{
									
									tag_t DmlItemsRelation = NULLTAG;
									int count = 0;
									tag_t* moduleObjects = NULL;
									//Get the attached modules.
									
									if(GRM_find_relation_type("T5_ModuleVF_to_Change",&DmlItemsRelation));
									if(DmlItemsRelation != NULLTAG)
									{
										if(GRM_list_secondary_objects_only(dmlTaskTag,DmlItemsRelation,&count,&moduleObjects));
										printf("\n Module count is : %d",count);
										if(count >0)
										{
											int j=0;
											char* objecttype = NULL;
											char* objectId = NULL;
											char* objectrevId = NULL;
											char* objectdesc = NULL;
											char* objectrelstatus = NULL;
											char* objectDRstatus = NULL;
											char* Part_type = NULL;
											
											tag_t probj = NULLTAG;
											tag_t primaryobjtype = NULLTAG;
											char   *primaryobj_name = NULL;
											char   *OccUIDattr				= NULL;
											
											
											for(j=0;j<count;j++)
											{
												printf("\n************************* %d SAN:Start********************************\n",j+1);fflush(stdout);
												logical allowed = FALSE;
												CALLAPI(AOM_ask_value_string(moduleObjects[j],"object_type",&objecttype));
												CALLAPI(AOM_ask_value_string(moduleObjects[j],"item_id",&objectId));
												CALLAPI(AOM_ask_value_string(moduleObjects[j],"item_revision_id",&objectrevId));
												CALLAPI(AOM_ask_value_string(moduleObjects[j],"object_desc",&objectdesc));
												CALLAPI(AOM_UIF_ask_value(moduleObjects[j],"release_status_list",&objectrelstatus));
												CALLAPI(AOM_ask_value_string(moduleObjects[j],"t5_PartStatus",&objectDRstatus));
												CALLAPI(AOM_ask_value_string(moduleObjects[j],"t5_PartType",&Part_type));

												printf("\nmoduleObjects Part_type  is :%s\n",Part_type);	fflush(stdout);
												printf("moduleObjects objecttype = [%s]\n",objecttype);fflush(stdout);
												printf("moduleObjects objectId = [%s]\n",objectId);fflush(stdout);
												printf("moduleObjects objectrevId = [%s]\n",objectrevId);fflush(stdout);
												printf("moduleObjects objectdesc = [%s]\n",objectdesc);fflush(stdout);
												printf("moduleObjects objectrelstatus = [%s]\n",objectrelstatus);fflush(stdout);
												printf("moduleObjects objectDRstatus = [%s]\n",objectDRstatus);fflush(stdout);
												
												//Get Occurence ID on Part
												
												if(GRM_find_relation(dmlTaskTag,moduleObjects[j],DmlItemsRelation,&probj));
												if (TCTYPE_ask_object_type(probj,&primaryobjtype)!=ITK_ok);
												if (TCTYPE_ask_name2(primaryobjtype,&primaryobj_name)!=ITK_ok);
												printf("\nSAN:ColorVF: primaryobj_name-------->  :%s\n", primaryobj_name);fflush(stdout);
												if(tc_strcmp(primaryobj_name,"T5_ModuleVF_to_Change")==0) 
												{
													printf("\nSAN:ColorVF: Inside getting BOMUID Attr \n"); fflush(stdout);
													ifail = AOM_UIF_ask_value(probj,"t5_Occurance_UID",&OccUIDattr);
													printf("\n SAN:ColorVF: OccUIDattr--------> :%s\n",OccUIDattr);fflush(stdout);
												
												}
												
												
												if(tc_strcmp(Part_type,"M")==0)
												{
													int n_parents			= 0;
													int *levels				= 0;
													tag_t* parents = NULL;
													int jd = 0;
													tag_t ArchAssyTag = NULLTAG;
													char* ChildUID = NULL;
													int flagArc = 0;
													char* child_bl_formula = NULL;
													char* occ_effec_old = NULL;
													//int occEffec = 0;
													tag_t ConfigCtx = NULLTAG;
													CALLAPI(PS_where_used_all(moduleObjects[j],1,&n_parents,&levels,&parents));
													printf("\nSAN:ColorVF: where_used count of objects are : %d",n_parents); fflush(stdout);
													
													for (jd=0;jd<n_parents;jd++ )
													{
														ArchAssyTag = NULLTAG;
														char* Arch_obj = NULL;
														tag_t  ArchobjTypeTag	= NULLTAG;
														char *Archtype_name = NULL;
														
														
														ArchAssyTag=parents[jd];
														
														CALLAPI(AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj))//PrintErrorStack();
														//printf("\nSAN:ColorVF: Architecture Object Drag Drop is :%s",Arch_obj);	fflush(stdout);

														CALLAPI(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag))//PrintErrorStack();
														CALLAPI(TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name))//PrintErrorStack();
														printf("\nSAN:ColorVF: Drag Drop Architecture Type Name is := %s", Archtype_name);fflush(stdout);
														
														if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
														{
															tag_t master = NULLTAG;
															char* Arch_obj_str = NULL;
															tag_t relation_dep=	NULLTAG;
															int countConfigCtx = 0;
															tag_t  *ConfigCtxSecObject	= NULLTAG;
															//flagArc = 0;
															
															//printf("\n to do....\n");fflush(stdout);
															printf("\nSAN:ColorVF: Architecture Object Drag Drop is :%s",Arch_obj);fflush(stdout);
															
															CALLAPI(ITEM_ask_item_of_rev(ArchAssyTag, &master));
															CALLAPI(AOM_ask_value_string(master,"item_id",&Arch_obj_str))//PrintErrorStack();
															printf("\n\t Architecture Object String Type is :%s",Arch_obj_str); fflush(stdout);

															CALLAPI(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep))//PrintErrorStack();
															if(relation_dep != NULLTAG)
															{
																printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);
																CALLAPI(GRM_list_secondary_objects_only(master,relation_dep,&countConfigCtx,&ConfigCtxSecObject))//PrintErrorStack();
															}

															
															printf("\n\t Configuration Context count is : %d",countConfigCtx);
															//test sanjoy
															//countConfigCtx = 1;
															if(countConfigCtx > 0)
															{
																ConfigCtx = NULLTAG;
																//ConfigCtx=ConfigCtxSecObject[0];
																tag_t window = NULLTAG;
																tag_t rule = NULLTAG;
																tag_t top_line = NULLTAG;
																
																int n_occs = 0;
																tag_t* occsal = NULL;
																
																int bvr_count = 0;
																tag_t* bvrs = NULL;
																tag_t bvr = NULLTAG;
																ifail = ITEM_rev_list_bom_view_revs(ArchAssyTag,&bvr_count, &bvrs);

																printf("\n test...bvr count is...%d",bvr_count);fflush(stdout);	
																if (bvr_count)
																{
																	bvr = bvrs[0];
																}
																else
																{
																	return ifail;
																}
																													
																ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal );
																
																printf("\n test...n_occs is...%d",n_occs);fflush(stdout);
																

																//PSEShowUnconfigdEffPref
																ConfigCtx=ConfigCtxSecObject[0];
																CALLAPI(PREF_set_logical_value("PSEShowUnconfigdEffPref",true));
																CALLAPI(PREF_ask_logical_value("PSEShowUnconfigdEffPref",0,&pref));
																printf("\n After1111: PSEShowUnconfigdEffPref====================> %d\n",pref);fflush(stdout);													
																CALLAPI(BOM_create_window (&window)!=ITK_ok)
																CALLAPI(CFM_find( "Latest Working", &rule )!=ITK_ok)
																CALLAPI(BOM_set_window_config_rule( window, rule )!=ITK_ok)
																CALLAPI(BOM_set_window_pack_all (window, false)!=ITK_ok)
																if(BOM_set_window_top_line (window, NULLTAG,ArchAssyTag, NULLTAG, &top_line)!=ITK_ok)PrintErrorStack();
																
																if(top_line != NULLTAG)
																{
																	int n_BL = 0;
																	int p = 0;
																	tag_t* children = NULL;
																	//CALLAPI(BOM_line_ask_child_lines(top_line, &n_BL, &children))
																	CALLAPI(BOM_line_ask_all_child_lines (top_line, &n_BL, &children));
																	//CALLAPI(BOM_line_subset_child_lines_occs(top_line,n_occs,occsal,&n_BL, &children));
																	printf("\n\t No of child objects are n : %d",n_BL);fflush(stdout);
																	
																	for (p=0;p<n_BL ;p++ )
																	{
																		tag_t Childobject = NULLTAG;
																		char* child_item_id = NULL;
																		child_bl_formula = NULL;
																		//int uidType = 0;
																		ChildUID = NULL;
																		occ_effec_old = NULL;

																		Childobject=children[p];
																		
																		if(AOM_ask_value_string(Childobject, "bl_occurrence_uid", &ChildUID));
																		printf("\n SAN:ChildUID ===============>>>>>>1111 %s \n",ChildUID);fflush(stdout);

																		if((tc_strcmp(ChildUID,OccUIDattr)==0))
																		{
																			CALLAPI(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ))
																			printf("\n\t Design Object ===> :: %s",child_item_id); fflush(stdout);

																			CALLAPI(AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula ))
																			printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula); fflush(stdout);												
																			//printf("\n uid not equal %s\t-  %s",ChildUID,OccUIDattr);fflush(stdout);

																			CALLAPI(AOM_ask_value_string(Childobject,"bl_occ_effectivity",&occ_effec_old))																	
																			flagArc++;
																			break;
																			
																		}
																		

																		

																		
																	
																		
																	}
																	
																	
																	
																}
																
																CALLAPI(BOM_close_window(window));
																
															}

															
															
														}
														
														printf("\n flagArc=============> %d\n",flagArc);fflush(stdout);
														if(flagArc >0)
														{
															break;
														}
														
														
													}
													
													//To write function to check the logic.
													printf("\n flagArc1111=============> %d\n",flagArc);fflush(stdout);
													if(flagArc >0)
													{
														allowed = FALSE;
														CALLAPI(tmCheckColorChange(ArchAssyTag,moduleObjects[j],ConfigCtx, objectId,objectrevId,child_bl_formula,occ_effec_old,OccUIDattr,ChildUID, &allowed));

														if(allowed)
														{
															t5AddStrToSetCED(&moduleCnt, &moduleList,objectId);
															
														}													
													}
													
														
													
												}

												printf("\n************************* %d SAN:End********************************\n",j+1);fflush(stdout);
																			
											}
										}
									}
														
									
								}
								
							}
						}
					
						CALLAPI(PREF_set_logical_value("PSEShowUnconfigdEffPref",prefOrig));
						CALLAPI(PREF_ask_logical_value("PSEShowUnconfigdEffPref",0,&pref));
						printf("\n Revert to original state: PSEShowUnconfigdEffPref====================> %d\n",pref);fflush(stdout);
					}
					
					printf("\nmoduleCnt=========> %d\n",moduleCnt);fflush(stdout);
					if(moduleCnt > 0)
					{
						printf("\n Go to Color Team Review\n");fflush(stdout);
						ifail = 1002;
						break;
						
					}
					else
					{
						printf("\n Go to Normal workflow\n");fflush(stdout);
						ifail = ITK_ok;
						
					}
				
				}
				
			}
		}
		
	}

	
	
	return ifail;
	
}

/******************Sanjoy Color Change Option in VF DML End****************************/

/******************Get Dmls ************************************/

int getEsoApplicableDmls( char* DatefromStr, char* DatetoStr, tag_t** tagSetOut, int *tag_cnt )
{
	int ifail = ITK_ok;
	
	date_t   dateArray[2];
	date_t dateFrom;
	date_t dateTo;
	
	const char * select_attrs[]={"puid"};
	char **dmlRelType = (char **) MEM_alloc(20 * sizeof(char *));
	
	int n_dmls = 0;
	int n_cols = 0;
	void ***values = NULL;	
	
	
	printf("\nQuery executing based on - Date Range: %s to %s\n",DatefromStr,DatetoStr);fflush(stdout);
	
	ITK_string_to_date(DatefromStr,&dateFrom);		
	ITK_string_to_date(DatetoStr,&dateTo);
	
	dateArray[0]=dateFrom;
	dateArray[1]=dateTo;
	
	dmlRelType[0]="TODR";
	dmlRelType[1]="Veh";
	dmlRelType[2]="Gate Maturation";
	dmlRelType[3]="Vehicle Release";
	dmlRelType[4]="MR";
	dmlRelType[5]="Module Release";

	
	//Step 1-   Creates a new enquiry.
	ifail = POM_enquiry_create ("find_dml_objs" );		
	//Step 2 - add the list to the select clause of the query
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_add_select_attrs ("find_dml_objs","ChangeRequestRevision",1,select_attrs);
	}	
	//Step 3a - create a date value object.
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_set_date_value ("find_dml_objs","expr_dates", 2 ,(const date_t*)dateArray,POM_enquiry_bind_value);
	}		
	//Step 4a - create an expression for pom creation_date = Date using the value "expr_dates" 
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_set_attr_expr ("find_dml_objs","expr_dates_between","ChangeRequestRevision","date_released",POM_enquiry_between,"expr_dates");
	}		
	// Step 3b - Create a string value object
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_set_string_value ("find_dml_objs","dml_rel_type",6,(const char**)dmlRelType,POM_enquiry_bind_value);
	}
	//  Step 4b - create an expression for POM_enquiry_in using the value "dml_rel_type" 
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_set_attr_expr ("find_dml_objs","expr_dmlRelType_in","ChangeRequestRevision","t5_rlstype",POM_enquiry_in,"dml_rel_type");
	}
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_set_expr ("find_dml_objs","expr_AND_expression","expr_dates_between",POM_enquiry_and,"expr_dmlRelType_in");
	}
	//Step 6 - Set the where clause of the query to the specified expression
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_set_where_expr ("find_dml_objs","expr_AND_expression");
	}		
	// Step 7 Order by clause 
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_add_order_attr ("find_dml_objs","ChangeRequestRevision", "date_released", POM_enquiry_asc_order);
	}	
	//Step 8 - Executes the query and fetches the data.
	if (ifail == ITK_ok)
	{
		ifail = POM_enquiry_execute("find_dml_objs", &n_dmls ,&n_cols, &values );
	}		
	//Step 9 - Delete the query and its sub-queries
	if (ifail == ITK_ok)
	{
		ifail = POM_enquiry_delete("find_dml_objs");
	}
	
	printf("\n No of DMLs==>%d\n",n_dmls);fflush(stdout);
	
		
	tag_t dmlTag = NULLTAG;
	char* partno = NULL;
	char* dmlReleaseType = NULL;			
	char* dmlRelTypeDisplayStr = NULL;
	char* dmlBusUnit	=	NULL;
	char* dmlBusUnitStr	=	NULL;
	char* creationDt = NULL;
	char* drstatS = NULL;
	char* drstatS1 = NULL;
	char * dmlRelStatS = NULL;
	char* dmlRelDateS = NULL;
	
	
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
	char* userInfo1 = NULL;
	
	ifail = isLiveForESOReview(&cntrlObj,&liveFlag); //Check if control object ESOREV-ESOREV is present and returns TRUE
	if(cntrlObj!= NULLTAG)
	{
		ifail = AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1);
	}
	printf("\nReport is applicable for business unit (ESOREV control object userinfo1:)[%s]\n",userInfo1);fflush(stdout);	
	
	if(n_dmls > 0)
	{
		int i=0;
			
		for (i = 0; i < n_dmls; i++ )
		{
			dmlTag  = *(tag_t*)(values[i][0]);
			
			if(dmlTag!=NULLTAG)
			{
				CALLAPI(AOM_ask_value_string(dmlTag,"item_id",&partno));
				CALLAPI(AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlReleaseType));
				CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_rlstype",&dmlRelTypeDisplayStr));
				CALLAPI(AOM_ask_value_string(dmlTag,"t5_ERCBusiUt",&dmlBusUnit));
				CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_ERCBusiUt",&dmlBusUnitStr));
				CALLAPI(AOM_UIF_ask_value(dmlTag,"creation_date",&creationDt));
				CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_cDRstatus",&drstatS));
				CALLAPI(AOM_UIF_ask_value(dmlTag,"t5_PlntToPlnt",&drstatS1));
				CALLAPI(AOM_UIF_ask_value(dmlTag,"release_status_list",&dmlRelStatS));
				CALLAPI(AOM_UIF_ask_value(dmlTag,"date_released",&dmlRelDateS));
				
				char* dmlBusUnitS = NULL;
				dmlBusUnitS = (char*)MEM_alloc(200);
				tc_strcpy(dmlBusUnitS,",");
				tc_strcat(dmlBusUnitS,dmlBusUnit);
				tc_strcat(dmlBusUnitS,",");
				printf("\nESO Report: dmlBusUnitS:%s\n",dmlBusUnitS);fflush(stdout);				
				
				int applicable =0;
				if(tc_strstr(userInfo1,dmlBusUnitS)!=NULL && tc_strstr(dmlRelStatS,"Released")!=NULL)
				{
					if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);
					tag_t *dmlTaskTagObjects = NULL;
					tag_t dmlTaskTag = NULLTAG;
					int taskCnt = 0;								
					CALLAPI(AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects));
					
					if(taskCnt>0)
					{
						int j=0;
						char* object_type	=	NULL;
						
						for(j=0;j<taskCnt;j++)
						{
							dmlTaskTag = dmlTaskTagObjects[j];
							CALLAPI(AOM_ask_value_string(dmlTaskTag,"object_type",&object_type));
							
							if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
							{
								int partCnt=0;
								tag_t *partTagObjects = NULL;
								tag_t partTag = NULLTAG;
								
								if(tc_strcmp(dmlReleaseType,"TODR")==0)
								{
									CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMReferences",&partCnt,&partTagObjects));
								}
								else if(tc_strcmp(dmlReleaseType,"Veh")==0)
								{
									CALLAPI(AOM_ask_value_tags(dmlTaskTag,"CMHasSolutionItem",&partCnt,&partTagObjects));
								}
								else
								{
									printf("\nInvalid DML Type. Should not come here\n");fflush(stdout);
								}
								
								if(partCnt>0)
								{
									int p=0;
									char* part_object_type = NULL;
									char* partType = NULL;
									for(p=0;p<partCnt;p++)
									{
										partTag = partTagObjects[p];
										CALLAPI(AOM_ask_value_string(partTag,"object_type",&part_object_type));

										if(tc_strcmp(part_object_type,"Design Revision")==0)
										{
											CALLAPI(AOM_ask_value_string(partTag,"t5_PartType",&partType));
											logical isEngine = FALSE;
											if(tc_strcmp(partType,"M")==0 || tc_strcmp(partType,"T")==0)
											{
												printf("\nESO: Part Type Module");fflush(stdout);
												char* desGrp = NULL;
												ifail = AOM_ask_value_string(partTag,"t5_DesignGrp",&desGrp);
												printf("\nESO: Design Group: %s\n", desGrp);fflush(stdout);
												if(tc_strcmp(desGrp,"00")==0 || tc_strcmp(desGrp,"26")==0)
												{																
													isEngine = TRUE;																	
												}																
											}
											printf("\nIs Engine:[%d]",isEngine);fflush(stdout);												
											if(tc_strcmp(partType,"VC") == 0 || tc_strcmp(partType,"V")==0 || tc_strcmp(partType,"CCVC")==0 || tc_strcmp(partType,"VCCR")==0  || isEngine)
											{
												applicable++;
												break;
											}
										}
											
									}
																			
								}
								
							}
															
						}
						
					}
					
				}
				else
				{
					
					if(dmlBusUnitS!=NULL) MEM_free(dmlBusUnitS);
				}
				
				
				if(applicable >0)
				{


					t5AddTagObjToSet(tag_cnt,tagSetOut,dmlTag);
				}
				else
				{

					//don't add
					//t5AddTagObjToSet(tag_cnt,tagSetOut,dmlTag); //testing
				}
					
			}
			
		}
	}
	
	printf("\nESO Applicable DML Count ===>%d",*tag_cnt);fflush(stdout);
	
	
	
	
	return ifail;
}


int tmGetDmlEsoServFn(void *retValue)
{
	
	printf("\n Start----tmGetDmlEsoServFn....\n");fflush(stdout);
	
	const char	*prog_name 	="tmGetDmlEsoServFn";
	
	int ifail = ITK_ok;
	int array_size = 0;
	tag_t* tag_array = NULL;
	USERSERVICE_array_t 	array_struct;
	
	int tag_cnt=0;
	tag_t* tagSetOut = NULL;
	
	
	char* datefrom = NULL;
	char* dateto = NULL;
	
	USERARG_get_string_argument(&datefrom);
	USERARG_get_string_argument(&dateto);		

	//print input parameters
	printf("datefrom==>%s\ndateto==>%s\n",datefrom,dateto);fflush(stdout);
	
	
	CALLAPI(getEsoApplicableDmls( datefrom, dateto, &tagSetOut,&tag_cnt));
	
	int m =0;
	printf("\nTag count=%d\n",tag_cnt);fflush(stdout);
	array_size = tag_cnt;
	if(tag_cnt<=0)
	{
		printf("111 After returning Value\n");fflush(stdout);	
		printf("\n 111 End----tmGetDmlEsoServFn....\n");fflush(stdout);
		return ifail;
	}
	
	tag_array = (tag_t*)MEM_alloc(array_size * sizeof(tag_t));
	
	for(m=0;m<tag_cnt;m++)
	{
		tag_array[m] = tagSetOut[m];
	}

	printf("\nBefore returning Value\n");fflush(stdout);

	
	ifail = USERSERVICE_return_tag_array((const tag_t*)tag_array,array_size,&array_struct);

	if (array_struct.length != 0)
	*((USERSERVICE_array_t*) retValue) = array_struct;				

	printf("After returning Value\n");fflush(stdout);	
	printf("\n End----tmGetDmlEsoServFn....\n");fflush(stdout);
	return ifail;
}


/*******************ESO Report NEW END *****************************/


extern int CEDCoatedPartCreationFn(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	int n_args = 2;
	int ret_value_type;
	int *input_arg_type;
	input_arg_type=(int *)MEM_alloc(n_args * sizeof(int));
	
	input_arg_type[0]=USERARG_TAG_TYPE;//Part Object
	input_arg_type[1]=USERARG_TAG_TYPE;//Dataset object
	ret_value_type = USERARG_VOID_TYPE;
 	
	
	//printf("\n CEDCoatedPartCreationFn: Before registering CEDCoatedPartUserServ userservice...");  
	ifail=USERSERVICE_register_method("CEDCoatedPartUserServ",(USER_function_t)CEDCoatedPartUserServ,n_args,input_arg_type,ret_value_type);
	
	ifail=USERSERVICE_register_method("tmCEDCoatedPartUserServ",(USER_function_t)tmCEDCoatedPartUserServ,n_args,input_arg_type,ret_value_type);
	
	
	
	//ESO Status creation services start
	
	int n_args1 = 6;
	int ret_value_type1;
	int *input_arg_type1;
	input_arg_type1=(int *)MEM_alloc(n_args1 * sizeof(int));
	
	input_arg_type1[0]=USERARG_TAG_TYPE;//Part Object
	input_arg_type1[1]=USERARG_STRING_TYPE;//Eso status 
	input_arg_type1[2]=USERARG_STRING_TYPE;//gr number
	input_arg_type1[3]=USERARG_STRING_TYPE;//gr date
	input_arg_type1[4]=USERARG_STRING_TYPE;//eso remark
	input_arg_type1[5]=USERARG_STRING_TYPE;//eso designer remark
	ret_value_type1 = USERARG_VOID_TYPE;
	
	//printf("\n ESO: Status creation services start: Before registering tmESOStatusCreServ userservice...");  
	ifail=USERSERVICE_register_method("tmESOStatusCreServ",(USER_function_t)tmESOStatusCreServ,n_args1,input_arg_type1,ret_value_type1);
	

	//ESO Status creation services start
	
	int n_args4 = 6;
	int ret_value_type4;
	int *input_arg_type4;
	input_arg_type4=(int *)MEM_alloc(n_args4 * sizeof(int));
	
	input_arg_type4[0]=USERARG_TAG_TYPE;//Part Object
	input_arg_type4[1]=USERARG_STRING_TYPE;//Eso status 
	input_arg_type4[2]=USERARG_STRING_TYPE;//gr number
	input_arg_type4[3]=USERARG_STRING_TYPE;//gr date
	input_arg_type4[4]=USERARG_STRING_TYPE;//eso remark
	input_arg_type4[5]=USERARG_STRING_TYPE;//eso designer remark
	ret_value_type4 = USERARG_STRING_TYPE;
	
	//printf("\n ESO: Status creation services start: Before registering tmESOStatusCreServ userservice...");  
	ifail=USERSERVICE_register_method("tmESOStatusCreServNew",(USER_function_t)tmESOStatusCreServNew,n_args4,input_arg_type4,ret_value_type4);
	
	//printf("\n CEDCoatedPartCreationFn: After registering tmESOStatusCreServ userservice...."); 
	
	
	//printf("\n CEDCoatedPartCreationFn: After registering tmESOStatusCreServ userservice...."); 
	
	//Start - ESO Status Report Service
	
	int n_args5 = 2;
	int ret_value_type5;
	int *input_arg_type5;
	input_arg_type5=(int *)MEM_alloc(n_args5 * sizeof(int));
	
	input_arg_type5[0]=USERARG_STRING_TYPE;//From Date
	input_arg_type5[1]=USERARG_STRING_TYPE;//To Date 
	ret_value_type5 = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE;
	
	//printf("\n ESO: Status creation services start: Before registering tmESOStatusCreServ userservice...");  
	ifail=USERSERVICE_register_method("tmESOStatusReportServ",(USER_function_t)tmESOStatusReportServ,n_args5,input_arg_type5,ret_value_type5);
		
	//End ESO Status Report Service
	
	
	

	
	
	//Annexure Header Creation - Start
	
	int n_args2 = 4;
	int ret_value_type2;
	int *input_arg_type2;
	input_arg_type2=(int *)MEM_alloc(n_args2 * sizeof(int));
	
	input_arg_type2[0]=USERARG_TAG_TYPE;//Part Object
	input_arg_type2[1]=USERARG_STRING_TYPE;//Anx Description 
	input_arg_type2[2]=USERARG_STRING_TYPE;//Anx Project Code
	input_arg_type2[3]=USERARG_STRING_TYPE;//Anx STN Number
	ret_value_type2 = USERARG_STRING_TYPE;
	
	//printf("\n STN: Annexuse Header creation services start: Before registering tmAnxHeaderCreServ userservice...");  
	ifail=USERSERVICE_register_method("tmAnxHeaderCreServ",(USER_function_t)tmAnxHeaderCreServ,n_args2,input_arg_type2,ret_value_type2);
	
	//printf("\n STN: Annexuse Header creation services End: After registering tmAnxHeaderCreServ userservice...."); 	
	
	
	int n_args3 = 3;
	int ret_value_type3;
	int *input_arg_type3;
	input_arg_type3=(int *)MEM_alloc(n_args3 * sizeof(int));
	
	
	input_arg_type3[0]=USERARG_STRING_TYPE;//Anx Description 
	input_arg_type3[1]=USERARG_STRING_TYPE;//Anx Project Code
	input_arg_type3[2]=USERARG_STRING_TYPE;//Anx STN Number
	ret_value_type3 = USERARG_STRING_TYPE;
	
	//printf("\n STN: Annexuse Header creation services start: Before registering tmAnxHeaderCreServNew userservice...");  
	ifail=USERSERVICE_register_method("tmAnxHeaderCreServNew",(USER_function_t)tmAnxHeaderCreServNew,n_args3,input_arg_type3,ret_value_type3);
	
	//printf("\n STN: Annexuse Header creation services End: After registering tmAnxHeaderCreServNew userservice...."); 	
	
	//Annexure Header Creation - End
	
	int n_args6 = 2;
	int ret_value_type6;
	int *input_arg_type6;
	input_arg_type6=(int *)MEM_alloc(n_args6 * sizeof(int));
	
	input_arg_type6[0]=USERARG_STRING_TYPE;//From Date
	input_arg_type6[1]=USERARG_STRING_TYPE;//To Date 
	ret_value_type6 = USERARG_TAG_TYPE+USERARG_ARRAY_TYPE;
	
	
	ifail=USERSERVICE_register_method("tmGetDmlEsoServ",(USER_function_t)tmGetDmlEsoServFn,n_args6,input_arg_type6,ret_value_type6);
		

	
	return ifail;
}

extern int tm_CEDCoatedPart_register_method(int *decision, va_list args)
{
    int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
    //printf("\ntm_CEDCoatedPart_register_method: Before registering action handlers....");            
	ifail = EPM_register_action_handler("tm_CreateCEDCoatedParts", "tm_CreateCEDCoatedParts",tm_CreateCEDCoatedPartsFunc);	
	
	//ifail = EPM_register_action_handler("tm_UpdateSpIndAndCreateCEDPart", "tm_UpdateSpIndAndCreateCEDPart",tm_UpdateSpIndAndCreateCEDPartFunc);//For testing
	
	ifail = EPM_register_action_handler("tm_UpdateSpInd", "tm_UpdateSpInd",tm_UpdateSpIndFunc);
	ifail = EPM_register_action_handler("tm_CreateCEDCoatPartforSpareIndUpdDml", "tm_CreateCEDCoatPartforSpareIndUpdDml",tm_CreateCEDCoatPartforSpareIndUpdDmlFunc);//This is used

	
   //Define Rule/Action handler here
   //printf("\n ESO: tm_CEDCoatedPart_register_method: tm_CheckApplicableForESORev: Before registering action handlers....");
   ifail = EPM_register_action_handler("tm_CheckApplicableForESORev", "tm_CheckApplicableForESORev",tm_CheckApplicableForESORevFun);
   
   ifail = EPM_register_action_handler("tm_CheckApplicableForESODev", "tm_CheckApplicableForESODev",tm_CheckApplicableForESODevFun);
   ifail = EPM_register_action_handler("tm_CheckApplicableForESODevPVPSE", "tm_CheckApplicableForESODevPVPSE",tm_CheckApplicableForESODevFunPVPSE);

   	ifail = EPM_register_rule_handler (
							"tm_ValidateESOSignOff",
							"tm_ValidateESOSignOff",
							(EPM_rule_handler_t)tm_ValidateESOSignOffFn
							);
							
   	ifail = EPM_register_rule_handler (
							"tm_ValidateESOSignOffTask",
							"tm_ValidateESOSignOffTask",
							(EPM_rule_handler_t)tm_ValidateESOSignOffTaskFn
							);
							

	ifail = EPM_register_action_handler("tm_IsVFColorOptionModified", "tm_IsVFColorOptionModified",tm_IsVFColorOptionModifiedFn);
  
   ifail = EPM_register_action_handler("tm_ESOSendMail", "tm_ESOSendMail",tm_ESOSendMailFun);//For updating LC status
   
   ifail = EPM_register_action_handler("tm_ESOStatusMailNotif", "tm_ESOStatusMailNotif",tm_ESOStatusMailNotifFun);

//TZ -ESO - mail - Sanjoy -  End   

//Annexure Header Creation - Start

   	ifail = EPM_register_rule_handler (
							"tm_ValidateAnxHeaderSignOff",
							"tm_ValidateAnxHeaderSignOff",
							(EPM_rule_handler_t)tm_ValidateAnxHeaderSignOffFn
							);
							
   	ifail = EPM_register_rule_handler (
							"tm_ValidateToSubmitAnnexureWF",
							"tm_ValidateToSubmitAnnexureWF",
							(EPM_rule_handler_t)tm_ValidateToSubmitAnnexureWFFn
							);								

//Annexure Header Creation - End

 //Generic Handlers - Sanjoy
   	ifail = EPM_register_rule_handler (
							"tm_CheckSignOffComment",
							"To check signoff comment mandatory for Review Task",
							(EPM_rule_handler_t)tm_CheckSignOffCommentFn
							); 

   	ifail = EPM_register_rule_handler (
							"tm_EPM_check_signoff_comments",
							"Custom To check signoff comment mandatory for Review Task",
							(EPM_rule_handler_t)tm_EPM_check_signoff_commentsFn
							);  
					
  
  //End Generic Handlers - Sanjoy
  
  /*Start- Sanjoy ESO Revison - save validation */
  
  METHOD_id_t method;
  
  METHOD_id_t  esoCheckOutValMethod;
  
  if ( METHOD_find_method("T5_ESOStRevision", "IMAN_save", &method) !=ITK_ok);

  if (method.id != NULL)
	{
		//printf("\n Method is found for IMAN_save_msg on T5_ESOStRevision (ESO Status Revision)\n");fflush(stdout);
		if( METHOD_add_action(method, METHOD_pre_action_type, (METHOD_function_t) tmESORev_save_method, NULL)!=ITK_ok);
   
		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}else
	{
		//printf("\n !!!!!!!!!!!Method not found!!!!!!!!!!\n");fflush(stdout);
	}
	  
  if(METHOD_find_method(RES_Type, RES_checkout_msg,&esoCheckOutValMethod) !=ITK_ok);
  
	if (esoCheckOutValMethod.id != NULL)
	{
		//printf("\nInside esoCheckOutValMethod\n");	fflush(stdout);
		if( METHOD_add_action(esoCheckOutValMethod, METHOD_pre_action_type, (METHOD_function_t) esoCheckOutValidation, NULL)!=ITK_ok);
	}
  
  
  /*End - Sanjoy ESO Status Rev - save validation   */  
	
    return ifail;
}



extern DLLAPI int tm_CEDCoatedPart_register_callbacks ()
{	
    int ifail    = ITK_ok;
	//printf("\ntm_CEDCoatedPart_register_callbacks:Before registoring....");  
    ifail=CUSTOM_register_exit ( "tm_CEDCoatedPart", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_CEDCoatedPart_register_method);
	//printf("\nttm_CEDCoatedPart_register_callbacks: After registoring....");
	
	//printf("\n Started- Registering user service function CEDCoatedPartCreationFn...");
	ifail=CUSTOM_register_exit ( "tm_CEDCoatedPart", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)CEDCoatedPartCreationFn);//user service not use
	//printf("\n Completed- Registering user service function CEDCoatedPartCreationFn...");
	
  return ( ITK_ok );
}

