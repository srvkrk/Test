/****************************************************************************************************
*  File	           :   tm_std_dml_assign.c ( File name )
*  Project         :   PLM TCUA Project-STDS1.		     
*  Modification History :
*  Date			Modified By			TZ			Modification Notes
*  20/06/18		Priti Pagar			1.35		STDSI Sign off validations-1. Previous revision not released check
																		   2. Child part not released
																		   3. AMDML validations bypass
																		   4. Two revision can not be released on same day
																		   5. Next revision of part exists with DR>DR3
																		   6. PP/PM DML for part released error
*******************************************************************************************************/
#include <ae/tool.h>
#include <fclasses/tc_date.h>
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <ae/datasettype.h>
#include <Fnd0Participant/participant.h>
//#include <tccore/iman_msg.h> Removed for TC-14.3
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h> Removed for TC-14.3
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h> Removed for TC-14.3
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h> Removed for TC-14.3
//#include <tccore/imantype.h> Removed for TC-14.3
//#include <sa/imanfile.h> Removed for TC-14.3
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h> Removed for TC-14.3
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
//#include <epm/cr_effectivity.h> Removed for TC-14.3
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#include "tm_apl_std_common_function.c"
#define NULLDATE   (POM_null_date()) 

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002

int cnt = 0;
int cntFlag = 0;
int cntFlagprev = 0;
int cntFlagprevhchk = 0; //pl922201
int epacnt = 0;
int cntEPAFlag = 0;
int cntSVRFlag = 0;


//#define ITK_CALL 	 \
//status=X; 	 \
//if (status != ITK_ok)  	 \
//{	 \
//int	 index = 0;	 \
//int	 n_ifails = 0;	 \
//const int*	 severities = 0;	 \
//const int*	 ifails = 0;	 \
//const char**	texts = NULL;	 \
//\
//EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
//printf("%3d error with #X\n", n_ifails);	 \
//for( index=0; index<n_ifails; index++)	 \
//{	 \
//printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
//}	 \
//return status;	 \
//}	 \
//;

struct RBQUStrut
{
    // char DML_num[40];
    // char Part_num[40];

    char* DML_num;
    char* Part_num;

} *get_RBQUStrut;

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
void setAddTAG_STD(int *count,tag_t **objlist,tag_t obj ) // Added By Ketan 
{
 
	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTAG_11");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
 
	}
	else
	{
		//printf("\n ****setAddTAG_12");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
 
	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}



//Sagar Start TZ 1.54
void tm_FindNxtRev(char *req_item,tag_t t_currentRevision, tag_t* t_NextRevision)
{
	int		Item_count			=	0;
	int		RevFlag				=	0;
	int		NextRevFlag 		=	0;
	int		ii					=	0;
	int		iRevLength			=	0;

	char	*Part_Rev			=	NULL;
	char	*Part_Rev_copy		=	NULL;
	char	*Part_rev_Id		=	NULL;
	char	*RevOnly			=	NULL;
	char	*NextRevOnly		=	NULL;
	char	*tmpNextRev			=	NULL;
	char	*Part_next_rev_Id	=	NULL;

	tag_t	All_item_tag		=	NULLTAG;
	tag_t	*rev_list			=	NULLTAG;

	printf("\n In tm_FindNxtRev() : %s",req_item);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev));
	printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev_copy));
	printf("\n Part_Rev_copy: %s\n",Part_Rev_copy);fflush(stdout);

	//ITKCALL(ITEM_list_all_revs (All_item_tag, &Item_count, &rev_list));
	ITKCALL(AOM_ask_value_tags(t_currentRevision,"revision_list",&Item_count,&rev_list));
	printf("\nRevision Count : %d",Item_count);fflush(stdout);


	if(Item_count > 0)
	{
		RevFlag		=	0;
		NextRevFlag	=	0;

		for(ii=0;ii<Item_count;ii++)
		{
			RevOnly		=	NULL;
			NextRevOnly	=	NULL;

			ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));

			printf("\nPart number : %s, Part_Rev(Task): %s, and Part_rev_Id(Loop): %s, [ii = %d]\n",req_item,Part_Rev,Part_rev_Id,ii);fflush(stdout);
			
			if(tc_strcmp(Part_Rev,Part_rev_Id)==0)	//If Part`s revision ID in Task matched to the rev Id in for loop.
			{
				RevFlag = 1;
			}
			printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
			
			if(RevFlag == 1)
			{
				printf("\n Revision matched... Finding Next Revision... \n");fflush(stdout);
				if (ii == (Item_count-1)) //If current revision(ii) is the Latest revision then return NULLTAG.
				{
					printf("\n No Next Revision Found... This itself is the Latest Revision...Returning NULLTAG [ii = %d] \n",ii);fflush(stdout);
					*t_NextRevision	=	NULLTAG;
				}
				else //If current revision(ii) is Not the Latest revision then return Next Rev(ii+1) tag.
				{
					printf("\n Next Revision Found... \n");fflush(stdout);
					*t_NextRevision	=	rev_list[ii+1];
					break;
				}
			}
		}
	}
}
//Sagar End TZ 1.54

//added by vishal
//void getTaskOwningValue(char* itemidtask, char* PLtaskvalue)   //vishal function
//{
//
//        char        *Task_no            = NULL;
//        char        *Dsgn_No			= NULL;
//        char		*PLT_name			= NULL;
//
//        printf("********** Inside Function getTaskOwningValue *********");fflush(stdout);
//        
//        printf("\n DML TASK ID is = %s",itemidtask);fflush(stdout);
//        
//        Task_no=tc_strtok(itemidtask,"_");	
//        printf("\n Task_no:%s\n",Task_no);fflush(stdout);
//        Dsgn_No = tc_strtok(NULL,"_");
//        printf("\n Dsgn_No:%s\n",Dsgn_No);fflush(stdout);
//        PLT_name = tc_strtok(NULL,"_");
//        printf("\n PLT_name:%s\n",PLT_name);fflush(stdout);
//
//        if(tc_strcmp(PLT_name,"APLA")==0)
//        {
//            tc_strcpy(PLtaskvalue,"APLAHD");
//        }
//        else if (tc_strcmp(PLT_name,"APLD")==0)
//        {
//            tc_strcpy(PLtaskvalue,"APLDWD");
//        }
//        else if (tc_strcmp(PLT_name,"APLC")==0)
//        {
//            tc_strcpy(PLtaskvalue,"APLCAR");
//        }
//        else if (tc_strcmp(PLT_name,"APLV")==0)
//        {
//            tc_strcpy(PLtaskvalue,"APLUV");
//        }
//        else if (tc_strcmp(PLT_name,"APLP")==0)
//        {
//            tc_strcpy(PLtaskvalue,"APLPUNE");
//        }
//        else if (tc_strcmp(PLT_name,"APLU")==0)
//        {
//            tc_strcpy(PLtaskvalue,"APLPNR");
//        }
//        else if (tc_strcmp(PLT_name,"APLL")==0)
//        {
//            tc_strcpy(PLtaskvalue,"APLLKO");
//        }
//        else if (tc_strcmp(PLT_name,"APLJ")==0)
//        {
//            tc_strcpy(PLtaskvalue,"APLJSR");
//        }
//        else
//        {
//            tc_strcpy(PLtaskvalue,"APLPUNE");
//        }
//    
//    printf("\n PLtaskvalue:%s\n",PLtaskvalue);fflush(stdout);
//
//    printf("********** Exiting Function getTaskOwningValue *********");fflush(stdout);
//
//}
int AssignSTDAnalyst(tag_t APLTaskRevT)
{
	char*			Task_no				= NULL;
	char*			Dsgn_Grp			= NULL;
	char*			Proj_Code			= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	char*			APL_Task_Grp		= NULL;
	char*			PLT_CodeS		= NULL;
	char*			PLT_CodeSuffix		= NULL;
	char			type_namee_task[TCTYPE_name_size_c+1];
	char*			TaskAssignee		= NULL;
	//char*			rolename			= NULL;
	//char*			userid				= NULL;
	//API change
	char *rolename = NULL;
	char *userid = NULL;
	//char				userid[SA_user_size_c+1];
	int   ifail				= 0;


	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			*ParticipantRel			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			ParticipantRelTag		= NULLTAG;
	tag_t			ObjTypTask			= NULLTAG;


	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	int				count		= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int				stdCnt				= 0;
	int				analystFnd			= 0;
	int				extUsrCnt			= 0; //DEEPTI TZ1.44
	int				oldusrcount			= 0; //DEEPTI TZ1.44
	tag_t			*OldParticipantRel			= NULLTAG;//DEEPTI TZ1.44
	tag_t			OldParticipantRelTag		= NULLTAG;//DEEPTI TZ1.44
	tag_t			OldObjTypTask			= NULLTAG;//DEEPTI TZ1.44
	//API change
	//char			Oldtype_namee_task[TCTYPE_name_size_c+1];//DEEPTI TZ1.44
	char *Oldtype_namee_task = NULL;

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	
	// Added by Dhanashri for Projectwise Mapping
	char  Projj[40];
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int FlaggAssignSTDAnalyst=0;
	int countt=0;
	int b=0;
	int z=0;
	tag_t	*GmFound1 = NULLTAG;
	char *Object_Name  =  NULL;

	tag_t			role_tag		= NULLTAG;
	// Added by Dhanashri for Projectwise Mapping

	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *PltCodeFrmCntrl 	  = NULL;
	 char *PltCodeSufx 	  = NULL;

	 // Ketan Added
	char* Temp_Dsgn_No	= NULL;
	char* Temp_Task_no	= NULL;

	int max_char_size = 80;
	Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));
	//
	char* CO_Dsgn_Grp	= NULL;


	printf("\n Inside AssignSTDAnalyst \n");

	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_crdesigngroup",&Dsgn_Grp));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_cprojectcode",&Proj_Code));
	printf("\n\n\t\t APL DML Cre:AssignSTDAnalyst:Task_no  is :%s",Task_no);	fflush(stdout);
	tc_strcpy(Temp_Task_no,Task_no);
	printf("\n Ketan for STD Planner Temp_Task_no :%s",Temp_Task_no);	fflush(stdout);

	printf("\n\n\t\t APL DML Cre:AssignSTDAnalyst:Dsgn_Grp  is :%s",Dsgn_Grp);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignSTDAnalyst:Proj_Code  is :%s",Proj_Code);	fflush(stdout);

	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);fflush(stdout);

	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));
	PLT_CodeSuffix=(char *) MEM_alloc(100 * sizeof(char *));
	PltCodeSufx=subString(PLT_Code,3,1);
	printf("\n PltCodeSufx:%s",PltCodeSufx);fflush(stdout);
		
	// Ketan Added for MBOM 

	if((tc_strstr(Temp_Task_no,"MB_")!=NULL)||(tc_strstr(Temp_Task_no,"MM_")!=NULL))
	{
		printf("\n Inside MB_/MM_ Task for STD Planner\n");
		
		Temp_Dsgn_No=(char *) MEM_alloc(100 * sizeof(char *));

		printf("\n Before Dsgn_No ==> %s\n",Dsgn_No);
		tc_strcpy(Temp_Dsgn_No,Dsgn_No);
		
		Dsgn_No = subString(Temp_Dsgn_No,0,2);
		printf("\n After Dsgn_No ==> %s\n",Dsgn_No);  
		
	}

	// Ketan Added for CO/CL/SP Task 
	
	if((tc_strstr(Temp_Task_no,"CO")!=NULL)||(tc_strstr(Temp_Task_no,"CL")!=NULL)||(tc_strstr(Temp_Task_no,"SP")!=NULL))
	//if(tc_strstr(Temp_Task_no,"CO")!=NULL)
	{
		printf("\n Inside CO/CL/SP Task for STD Planner\n");fflush(stdout);
		CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_crdesigngroup",&CO_Dsgn_Grp));
		printf("\n CO_Dsgn_Grp ==> %s\n",CO_Dsgn_Grp);fflush(stdout);  
		
		Dsgn_No=(char *) MEM_alloc(100 * sizeof(char *));
		tc_strcpy(Dsgn_No,CO_Dsgn_Grp);
		printf("\n STD Planner : CO/CL/SP Dsgn_No ==> %s \n",Dsgn_No);fflush(stdout);

	}

	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="APLPltInf";
		qry_valuesCntrl1[1]=PLT_Code;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	else
	{
		printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
	}	
	
	printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

	if(control_number_found1>0)
	{			
		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &PltCodeFrmCntrl);
		printf("\n PltCodeFrmCntrl: %s\n",PltCodeFrmCntrl);fflush(stdout);
		//AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo10", &PltCodeSufx);
		//printf("\n PltCodeSufx: %s\n",PltCodeSufx);fflush(stdout);
		tc_strcpy(PLT_CodeS,PltCodeFrmCntrl);	
		tc_strcpy(PLT_CodeSuffix,PltCodeSufx);
	}
	else
	{
		tc_strcpy(PLT_CodeS,"PUNE");
		tc_strcpy(PLT_CodeSuffix,"P");
	}
	printf("\n PLT_CodeS: %s\n",PLT_CodeS);fflush(stdout);
	printf("\n PLT_CodeSuffix: %s\n",PLT_CodeSuffix);fflush(stdout);
	
	// Added By Dhanashri for projectwise mapping// 

	APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(APL_Plnr_Grp,"STD");
	tc_strcat(APL_Plnr_Grp,PLT_CodeS);
	tc_strcpy(Projj,Proj_Code);
	printf("\n Projj :[%s]\n",Projj);fflush(stdout);

	// End Of code Added By Dhanashri for projectwise mapping// 

	printf("\n Test0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);fflush(stdout);

	CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&oldusrcount,&OldParticipantRel));//DEEPTI TZ1.44
	printf("\n oldusrcount to delete  :%d\n",oldusrcount);fflush(stdout);
	for(extUsrCnt=0;extUsrCnt<oldusrcount;extUsrCnt++)
	{
		printf("\n Removing old user :%d\n",extUsrCnt);fflush(stdout);
		OldParticipantRelTag = OldParticipantRel[extUsrCnt];
						
		printf("\n 11 Inside remving the relation...");fflush(stdout);

		if(TCTYPE_ask_object_type(OldParticipantRelTag,&OldObjTypTask));
		if(TCTYPE_ask_name2(OldObjTypTask,&Oldtype_namee_task));
		printf("\n 11Task: Participants Name: %s", Oldtype_namee_task);fflush(stdout);

		if ((tc_strcmp(Oldtype_namee_task,"Analyst")==0))
		{
			printf("\n Removing the user..");fflush(stdout);

			AOM_lock(APLTaskRevT);
			//API change
			//ITKCALL(ITEM_rev_remove_participant (APLTaskRevT,OldParticipantRelTag)!=ITK_ok);
			ITKCALL(PARTICIPANT_remove_participant (APLTaskRevT,OldParticipantRelTag)!=ITK_ok);
			AOM_save_with_extensions(APLTaskRevT); //09/05
			AOM_unlock(APLTaskRevT);
		}
		
	}

	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));
	if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\n Analyst : No of Role found in Group are :%d\n",num_of_roles);fflush(stdout);

	if(num_of_roles>0)
	{
		FlaggAssignSTDAnalyst=0; // by dss for projectwise mapping.

		for (i=0;i<num_of_roles ;i++ )
		{
				CALLAPI(SA_ask_role_name2(role_tags[i],&rolename));
				printf("\n Rol Name :[%d][%s]\n",i,rolename);fflush(stdout);
				printf("\n Dsgn_No [%s]\n",Dsgn_No);fflush(stdout);

				if(strstr(rolename,"STD") && strstr(rolename,Dsgn_No) && strstr(rolename,"Analyst") && strstr(rolename,"Default")==NULL ) 
				{
					printf("\n Analyst : Match Found\n");fflush(stdout);
					role_tag = role_tags[i];
					CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
					printf("\n Analyst : No of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
					if(num_of_members>0)
					{
						tag_t*	ptypes		= NULLTAG;
						tag_t*	ptypes2		= NULLTAG;
						int p1=0;
						int p2=0;

						for (j=0;j<num_of_members ;j++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
							//API change
							//CALLAPI(SA_ask_user_identifier(user_tag,userid));
							CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
							printf("\n Analyst : User ID Name :[%s]\n",userid);fflush(stdout);
						 
							// Added by Dhanashri for projectwise mapping//
							ProjectAccessFound=0;
							Gmcnt1=0;
							GmFound1 = NULLTAG;
							GetProjectUserAccessDetails(Projj,userid,&Gmcnt1,&GmFound1);
							printf("\n Analyst : Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
							
							countt=0;
							for(countt==0;countt<Gmcnt1;countt++)
							{
									Object_Name  =  NULL;
									CALLAPI(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
									printf("\n Analyst : after func :  %s",Object_Name);fflush(stdout);
								
									if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,Dsgn_No) && strstr(Object_Name,"Analyst") && strstr(Object_Name,"Default")==NULL) 
									{
										printf("\n Analyst : Condition Satisfy... ");fflush(stdout);
										ProjectAccessFound=1;
										break;
									}
							}
							printf("\n Analyst : ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
							// Added by Dhanashri for projectwise mapping//
							
							if(ProjectAccessFound==1)
							{
								//TCTYPE_find_type("Analyst", "Analyst", &participant_type);
								//EPM_create_participant(member_tags[j], participant_type, &participant_tag);
								//GRM_find_relation_type("HasParticipant", &relation_type);
								//GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
								//GRM_save_relation(relation);
								//printf("\n APL Planner Assigned..to : [%s]\n",userid);fflush(stdout);
								FlaggAssignSTDAnalyst=1;

								TCTYPE_find_type("Analyst", "Analyst", &participant_type);
								printf("\n STD Analyst Test 3333 \n");fflush(stdout);
								setAddTAG_STD(&p1,&ptypes,participant_type);
								printf("\n STD Analyst Test 3333.1 \n");fflush(stdout);
								setAddTAG_STD(&p2,&ptypes2,member_tags[j]);
								printf("\n STD Analyst Test ended 4444 \n");fflush(stdout);
							}
						}
						tag_t* participant_list = NULLTAG;
						logical bypass_assignable_check =true;
						int k = 0;

						tag_t   type1TypeTag			= NULLTAG;

						char*    type1type_name;
						printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
						for(k=0;k<p2;k++)
						{
							tag_t type1 = ptypes[k];
							if(type1 != NULLTAG )
							{
								if(TCTYPE_ask_object_type(type1,&type1TypeTag));
								if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
								printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
							}
							else
							{
								printf("\n type is NULL \n");fflush(stdout);
							}
						}

						CALLAPI(PARTICIPANT_add_participants(APLTaskRevT,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
					}
					if(FlaggAssignSTDAnalyst==1)
					{
						printf("\n Analyst : Break \n");fflush(stdout);
						break;
					}
				}// Role matches  
		}

		printf("\n Analyst : FlaggAssignSTDAnalyst: %d \n",FlaggAssignSTDAnalyst);fflush(stdout);

		if(FlaggAssignSTDAnalyst==0)
		{
			printf("\n Ketan Inside Default Group for Analyst \n");fflush(stdout);
			APL_Plnr_Grp = NULL;
			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"STD");
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,PLT_CodeS);
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,"Default");
			printf("\n Test Planner Group Name:[%s]\n",APL_Plnr_Grp);
			z=0;
			for (z=0;z<num_of_roles ;z++ )
			{
				CALLAPI(SA_ask_role_name2(role_tags[z],&rolename));
				printf("\nRol Name :[%d][%s]\n",z,rolename);
				if(strstr(rolename,APL_Plnr_Grp))
				{
					printf("\n Got Default Group");
					CALLAPI(SA_find_groupmember_by_role(role_tags[z],group_tag,&num_of_members,&member_tags));
					printf("\n No of Group Members found in Group/Role are :%d\n",num_of_members);
					if(num_of_members>0)
					{
						b=0;

						tag_t*	ptypes		= NULLTAG;
						tag_t*	ptypes2		= NULLTAG;
						int p1=0;
						int p2=0;

						for (b=0;b<num_of_members ;b++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[b],&user_tag));
							//API change
							CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
							printf("\n User ID Name :[%s]\n",userid);
							// TCTYPE_find_type("Analyst", "Analyst", &participant_type);
							// EPM_create_participant(member_tags[b], participant_type, &participant_tag);
							// GRM_find_relation_type("HasParticipant", &relation_type);
							// GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							// GRM_save_relation(relation);
							// printf("\n APL Planner Assigned..to : [%s]\n",userid);fflush(stdout);

							TCTYPE_find_type("Analyst", "Analyst", &participant_type);
							printf("\n Default STD Analyst Test 3333 \n");fflush(stdout);
							setAddTAG_STD(&p1,&ptypes,participant_type);
							printf("\n Default STD Analyst Test 3333.1 \n");fflush(stdout);
							setAddTAG_STD(&p2,&ptypes2,member_tags[b]);
							printf("\n Default STD Analyst Test ended 4444 \n");fflush(stdout);
							
						}
						tag_t* participant_list = NULLTAG;
						logical bypass_assignable_check =true;
						int k = 0;

						tag_t   type1TypeTag			= NULLTAG;

						char*    type1type_name;
						printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
						for(k=0;k<p2;k++)
						{
							tag_t type1 = ptypes[k];
							if(type1 != NULLTAG )
							{
								if(TCTYPE_ask_object_type(type1,&type1TypeTag));
								if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
								printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
							}
							else
							{
								printf("\n type is NULL \n");fflush(stdout);
							}
						}

						CALLAPI(PARTICIPANT_add_participants(APLTaskRevT,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
					}
				}
			}
		}        
	} // if(num_of_roles>0)

	return ITK_ok;
}

int AssignSTDReviewerPR(tag_t APLTaskRevT)
{
	char*			Task_no				= NULL;
	char*			Task_no1				= NULL;
	char*			Dsgn_Grp			= NULL;
	char*			Proj_Code			= NULL;
	char*			dmlnum			= NULL;
	char*			DMLNo				= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	char*			PLT_CodeS		= NULL;
	char*			APLDML		= NULL;
	//char*			rolename			= NULL;
	//char*			userid				= NULL;
	char*			member_name				= NULL;
	char*			PRTaskCreator				= NULL;
	char*	 tsk_name		= NULL;
	char		   *PltNm =NULL;
	char		   *Tasknumber =NULL;
	//API change
	char* rolename = NULL;
	char* userid = NULL;
	//char			rolename[SA_name_size_c+1];
	//char				userid[SA_user_size_c+1];
	int   ifail				= 0;
	char TaskCpy[25];

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			*ParticipantRel			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t APLTask= NULLTAG;
	tag_t  	item_rev_cld_tag;

	int				count		= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int				FlaggAssignReviewerPR					= 0;

	int n_tags_found=0;
	tag_t	*tags_found							= NULLTAG;
	tag_t tsk_dml_rel_type;
	tag_t *DMLRevision = NULLTAG;
	int count1=0;
	int Task=0;
	int FlagOtherTsk=0;

	logical			flgRoleFnd			= false;

	// Added by Dhanashri for Projectwise Mapping
				
	char  Projj[40];
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int FlaggAssignSTDReviewer=0;
	int countt=0;
	int b=0;
	int z=0;
	tag_t	*GmFound1 = NULLTAG;
	char *Object_Name  =  NULL;

	tag_t			role_tag		= NULLTAG;
	// Added by Dhanashri for Projectwise Mapping

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *PltCodeFrmCntrl 	  = NULL;

	printf("\n Inside AssignSTDReviewerPR \n");

	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	printf("\n\n\t\t APL DML Cre:AssignSTDReviewerPR:Task_no  is :%s",Task_no);	fflush(stdout);

	DMLNo=tc_strtok(Task_no,"_");
	printf("\nTest0.11..DMLNo:[%s],[%s]\n",DMLNo,Task_no);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);

	APLDML=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(APLDML,DMLNo);
	tc_strcat(APLDML,"_");
	tc_strcat(APLDML,PLT_Code);
	printf("\n APLDML: [%s]\n",APLDML);


	const char *qry_entries[1];
	const char *qry_values[1];

	qry_entries[0] ="item_id";
	qry_values[0] = APLDML;


	ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &tags_found);
	printf("\n tags_found : %d\n",n_tags_found);fflush(stdout);

	itemcldclass = tags_found[0];
	ITKCALL(ITEM_ask_latest_rev(itemcldclass,&item_rev_cld_tag));

	CALLAPI(AOM_ask_value_string(item_rev_cld_tag,"t5_cprojectcode",&Proj_Code));
	printf("\n APL DML Cre:AssignAPLReviewer:Proj_Code  is :%s",Proj_Code);	fflush(stdout);

	CALLAPI(AOM_ask_value_string(item_rev_cld_tag,"item_id",&dmlnum));
	printf("\n APL DML Cre:AssignAPLReviewer:dmlnum  is :%s",dmlnum);	fflush(stdout);
	
	ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
	if (tsk_dml_rel_type!=NULLTAG)
	 {
		ITKCALL(GRM_list_secondary_objects_only(item_rev_cld_tag,tsk_dml_rel_type,&count1,&DMLRevision));
		printf("\n DML Revision from Task : %d",count1);fflush(stdout);		//task to dml
	 }

	if(count1>0)
	{
		 for(Task=0;Task<count1;Task++)
		{
			APLTask=DMLRevision[Task];
			ITKCALL(AOM_ask_value_string(APLTask,"item_id",&tsk_name));
			printf("\n tsk_name is :%s\n",tsk_name);fflush(stdout);

			if(tc_strstr(tsk_name,"_PR")==NULL)
			{
				printf(" \n Got Task Other THan PR Task");fflush(stdout);
				FlagOtherTsk=1;
				break;
			}

		}
	}

	printf(" \n FlagOtherTsk: [%d]",FlagOtherTsk);fflush(stdout);

	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));

	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="APLPltInf";
		qry_valuesCntrl1[1]=PLT_Code;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	else
	{
		printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
	}	
	
	printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

	if(control_number_found1>0)
	{			
		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &PltCodeFrmCntrl);
		printf("\n PltCodeFrmCntrl: %s\n",PltCodeFrmCntrl);fflush(stdout);
		tc_strcpy(PLT_CodeS,PltCodeFrmCntrl);					
	}
	else
	{
		tc_strcpy(PLT_CodeS,"PUNE");
	}
	printf("\n PLT_CodeS: %s\n",PLT_CodeS);fflush(stdout);
	
	// Added By Dhanashri for projectwise mapping// 

	APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(APL_Plnr_Grp,"STD");
	tc_strcat(APL_Plnr_Grp,PLT_CodeS);
	tc_strcpy(Projj,Proj_Code);
	printf("\n Projj :[%s]\n",Projj);fflush(stdout);

	// End Of code Added By Dhanashri for projectwise mapping// 

	printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);

	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

	if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\n PR Reviewer : No of Role found in Group are :%d\n",num_of_roles);
	flgRoleFnd=false;
	if(num_of_roles>0)
	{
		FlaggAssignReviewerPR=0;
		for (i=0;i<num_of_roles ;i++ )
		{
				CALLAPI(SA_ask_role_name2(role_tags[i],&rolename));
				printf("\n PR Reviewer : Rol Name :[%d][%s]\n",i,rolename);
				
				if(FlagOtherTsk==1)
				{
						CALLAPI(AOM_ask_value_string(APLTask,"item_id",&Task_no1));
						CALLAPI(AOM_ask_value_string(APLTask,"t5_crdesigngroup",&Dsgn_Grp));
						
						printf("\n APL DML Cre:AssignAPLReviewer:Task_no1  is :[%s]",Task_no1);	fflush(stdout);
						printf("\n APL DML Cre:AssignAPLReviewer:Dsgn_Grp  is :[%s]",Dsgn_Grp);	fflush(stdout);
						if( (Dsgn_Grp==NULL) || (tc_strcmp(Dsgn_Grp,"")==0) )
						{				
								printf("\n testt1");	fflush(stdout);
								tc_strcpy(TaskCpy,Task_no1);

								Tasknumber = strtok( TaskCpy, "_" );
								Dsgn_Grp  = strtok ( NULL, "_" );
								PltNm  = strtok ( NULL, "_" );

								printf("\n dss Tasknumber : %s",Tasknumber); fflush(stdout);
								printf("\n dss Dsgn_Grp : %s",Dsgn_Grp); fflush(stdout);
								printf("\n dss PltNm : %s",PltNm); fflush(stdout);
						}

				if( (tc_strstr(rolename,"STD")!=NULL) && (tc_strstr(rolename,"Reviewer")!=NULL) && (tc_strstr(rolename,Dsgn_Grp)!=NULL) && (tc_strstr(rolename,"Default")==NULL) )
				{
					printf("\n PR Reviewer : hi ..Match Found\n");
				
						CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
						printf("\n PR Reviewer :  No of Group Members found in Group/Role are :%d\n",num_of_roles);
						if(num_of_members>0)
						{
							tag_t*	ptypes		= NULLTAG;
							tag_t*	ptypes2		= NULLTAG;
							int p1=0;
							int p2=0;

							for (j=0;j<num_of_members ;j++  )
							{
								ITKCALL(AOM_ask_value_string(member_tags[j],"user_name",&member_name)!=ITK_ok);
								printf("\n PR Reviewer :  member_name :[%s]\n",member_name);

								CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
								CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
								printf("\n PR Reviewer : User ID Name :[%s]\n",userid);

									// Added by Dhanashri for projectwise mapping//
									ProjectAccessFound=0;
									Gmcnt1=0;
									GmFound1 = NULLTAG;
									GetProjectUserAccessDetails(Projj,userid,&Gmcnt1,&GmFound1);
									printf("\n PR Reviewer : Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
									
									countt=0;
									for(countt==0;countt<Gmcnt1;countt++)
									{
											Object_Name  =  NULL;
											CALLAPI(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
											printf("\n after func :  %s",Object_Name);fflush(stdout);
										
											//if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,Dsgn_No) && strstr(Object_Name,"Reviewer") && strstr(Object_Name,"Default")==NULL) 
											if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,Dsgn_Grp) && strstr(Object_Name,"Reviewer") && strstr(Object_Name,"Default")==NULL) // Added By Ketan
											{
												printf("\n PR Reviewer : Condition Satisfy... ");fflush(stdout);
												ProjectAccessFound=1;
												break;
											}
									}
									printf("\n PR Reviewer : ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
									// Added by Dhanashri for projectwise mapping//

									if(ProjectAccessFound==1)
									{
										// TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
										// EPM_create_participant(member_tags[j], participant_type, &participant_tag);
										// GRM_find_relation_type("HasParticipant", &relation_type);
										// CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&count,&ParticipantRel));
										// 
										// GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
										// GRM_save_relation(relation);
										// printf("\n TestParticipent PR Reviewer Assigned..DoneXXXX\n");
										FlaggAssignReviewerPR=1;
										
										TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
										printf("\n PR Reviewer ChangeSpecialist1 Test 3333 \n");fflush(stdout);
										setAddTAG_STD(&p1,&ptypes,participant_type);
										printf("\n PR Reviewer ChangeSpecialist1 Test 3333.1 \n");fflush(stdout);
										setAddTAG_STD(&p2,&ptypes2,member_tags[j]);
										printf("\n PR Reviewer ChangeSpecialist1 Test ended 4444 \n");fflush(stdout);
									}	
							}
							tag_t* participant_list = NULLTAG;
							logical bypass_assignable_check =true;
							int k = 0;

							tag_t   type1TypeTag			= NULLTAG;

							char*    type1type_name;
							printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
							for(k=0;k<p2;k++)
							{
								tag_t type1 = ptypes[k];
								if(type1 != NULLTAG )
								{
									if(TCTYPE_ask_object_type(type1,&type1TypeTag));
									if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
									printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
								}
								else
								{
									printf("\n type is NULL \n");fflush(stdout);
								}
							}
							CALLAPI(PARTICIPANT_add_participants(APLTaskRevT,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
						}
						
						if(FlaggAssignReviewerPR==1)
						{
							printf("\n FlaggAssignReviewerPR: 1 \n");
							break;
						}
			}
		  }
		}

		if(FlaggAssignReviewerPR==0)
		{
			printf("\n Ketan Inside Default Group for PR Reviewer \n");fflush(stdout);

			APL_Plnr_Grp = NULL;
			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"STD");
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,PLT_CodeS);
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,"Default");
			printf("\n Test Planner Group Name:[%s]\n",APL_Plnr_Grp);
			i=0;
			for (i=0;i<num_of_roles ;i++ )
			{
				CALLAPI(SA_ask_role_name2(role_tags[i],&rolename));
				printf("\n Rol Name :[%d][%s]\n",i,rolename);
				if(strstr(rolename,APL_Plnr_Grp))
				{
					printf("\n Got Default Group");
					CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
					printf("\n No of Group Members found in Group/Role are :%d\n",num_of_roles);
					if(num_of_members>0)
					{
						tag_t*	ptypes		= NULLTAG;
						tag_t*	ptypes2		= NULLTAG;
						int p1=0;
						int p2=0;

						for (j=0;j<num_of_members ;j++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
							//API change
							CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
							printf("\n User ID Name :[%s]\n",userid);
							// TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
							// EPM_create_participant(member_tags[j], participant_type, &participant_tag);
							// GRM_find_relation_type("HasParticipant", &relation_type);
							// CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&count,&ParticipantRel));
							// printf("\n count :[%d]\n",count);
							// GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							// GRM_save_relation(relation);
							// printf("\n TestParticipent Assigned..DoneXXXX\n");

							TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
							printf("\n Default PR ChangeSpecialist1 Test 3333 \n");fflush(stdout);
							setAddTAG_STD(&p1,&ptypes,participant_type);
							printf("\n Default PR ChangeSpecialist1 Test 3333.1 \n");fflush(stdout);
							setAddTAG_STD(&p2,&ptypes2,member_tags[j]);
							printf("\n Default PR ChangeSpecialist1 Test ended 4444 \n");fflush(stdout);
							
						}
						tag_t* participant_list = NULLTAG;
						logical bypass_assignable_check =true;
						int k = 0;

						tag_t   type1TypeTag			= NULLTAG;

						char*    type1type_name;
						printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
						for(k=0;k<p2;k++)
						{
							tag_t type1 = ptypes[k];
							if(type1 != NULLTAG )
							{
								if(TCTYPE_ask_object_type(type1,&type1TypeTag));
								if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
								printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
							}
							else
							{
								printf("\n type is NULL \n");fflush(stdout);
							}
						}

						CALLAPI(PARTICIPANT_add_participants(APLTaskRevT,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
					}
				}
			}
		}
	}




	return ITK_ok;
}

int AssignSTDReviewer(tag_t APLTaskRevT)
{
	char*			Task_no				= NULL;
	char*			Dsgn_Grp			= NULL;
	char*			Proj_Code			= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	char*			APL_Task_Grp		= NULL;
	char*			PLT_CodeS		= NULL;
	char*			PLT_CodeSuffix		= NULL;
	//char*			rolename			= NULL;
	//char*			userid				= NULL;

	//API change
	char* rolename = NULL;
	char* userid = NULL;
	//char			rolename[SA_name_size_c+1];
	//char				userid[SA_user_size_c+1];
	int   ifail				= 0;

	tag_t			*ParticipantRel			= NULLTAG;
	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	int				num_of_roles		= 0;
	int				count		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;

	//logical			flgRoleFnd			= false;

	tag_t			ParticipantRelTag		= NULLTAG;
	tag_t			ObjTypTask			= NULLTAG;
	int				stdCnt				= 0;
	int				ChangeSpeciaFnd		= 0;
	char			type_namee_task[TCTYPE_name_size_c+1];
	char*			TaskAssignee		= NULL;

	int				extUsrCnt			= 0; //DEEPTI TZ1.44
	int				oldusrcount			= 0; //DEEPTI TZ1.44
	tag_t			*OldParticipantRel			= NULLTAG;//DEEPTI TZ1.44
	tag_t			OldParticipantRelTag		= NULLTAG;//DEEPTI TZ1.44
	tag_t			OldObjTypTask			= NULLTAG;//DEEPTI TZ1.44
	//API change
	//char			Oldtype_namee_task[TCTYPE_name_size_c+1];//DEEPTI TZ1.44
	char *Oldtype_namee_task = NULL;

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	
	// Added by Dhanashri for Projectwise Mapping
				
	char  Projj[40];
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int FlaggAssignSTDReviewer=0;
	int countt=0;
	int b=0;
	int z=0;
	tag_t	*GmFound1 = NULLTAG;
	char *Object_Name  =  NULL;

	tag_t			role_tag		= NULLTAG;
	// Added by Dhanashri for Projectwise Mapping

	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *PltCodeFrmCntrl 	  = NULL;
	 char *PltCodeSufx 	  = NULL;

	 // Ketan Added
	char* Temp_Dsgn_No		= NULL;
	char* Temp_Task_no		= NULL;

	int max_char_size = 80;
	Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));
	//
	char* CO_Dsgn_Grp	= NULL;

	printf("\n Inside AssignSTDReviewer  \n");

	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_crdesigngroup",&Dsgn_Grp));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_cprojectcode",&Proj_Code));
	printf("\n\n\t\t APL DML Cre:AssignSTDReviewer:Task_no  is :%s",Task_no);	fflush(stdout);

	tc_strcpy(Temp_Task_no,Task_no);
	printf("\n Ketan for STD Reviewer Temp_Task_no:%s",Temp_Task_no);	fflush(stdout);

	printf("\n\n\t\t APL DML Cre:AssignSTDReviewer:Dsgn_Grp  is :%s",Dsgn_Grp);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignSTDReviewer:Proj_Code  is :%s",Proj_Code);	fflush(stdout);

	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);

	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));
	PLT_CodeSuffix=(char *) MEM_alloc(100 * sizeof(char *));
	PltCodeSufx=subString(PLT_Code,3,1);
	printf("\n PltCodeSufx:%s",PltCodeSufx);fflush(stdout);
	
	// Ketan Added for MBOM 
	if((tc_strstr(Temp_Task_no,"MB_")!=NULL)||(tc_strstr(Temp_Task_no,"MM_")!=NULL))
	{
		printf("\n Inside MB_/MM_ Task for STD Reviewer  \n");
		
		Temp_Dsgn_No=(char *) MEM_alloc(100 * sizeof(char *));

		printf("\n Before Dsgn_No ==> %s\n",Dsgn_No);
		tc_strcpy(Temp_Dsgn_No,Dsgn_No);
		
		Dsgn_No = subString(Temp_Dsgn_No,0,2);
		printf("\n After Dsgn_No ==> %s\n",Dsgn_No);  
		
	}

	// Ketan Added for CO/CL/SP Task 

	if((tc_strstr(Temp_Task_no,"CO")!=NULL)||(tc_strstr(Temp_Task_no,"CL")!=NULL)||(tc_strstr(Temp_Task_no,"SP")!=NULL))
	//if(tc_strstr(Temp_Task_no,"CO")!=NULL)
	{
		printf("\n Inside CO/CL/SP Task for STD Reviewer\n");fflush(stdout);
		CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_crdesigngroup",&CO_Dsgn_Grp));
		printf("\n CO_Dsgn_Grp ==> %s\n",CO_Dsgn_Grp);fflush(stdout);  
		
		Dsgn_No=(char *) MEM_alloc(100 * sizeof(char *));
		tc_strcpy(Dsgn_No,CO_Dsgn_Grp);
		printf("\n STD Reviewer : CO/CL/SP Dsgn_No ==> %s \n",Dsgn_No);fflush(stdout);

	}
			

	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="APLPltInf";
		qry_valuesCntrl1[1]=PLT_Code;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	else
	{
		printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
	}	
	
	printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

	if(control_number_found1>0)
	{			
		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &PltCodeFrmCntrl);
		printf("\n PltCodeFrmCntrl: %s\n",PltCodeFrmCntrl);fflush(stdout);
		//AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo10", &PltCodeSufx);
		//printf("\n PltCodeSufx: %s\n",PltCodeSufx);fflush(stdout);
		tc_strcpy(PLT_CodeS,PltCodeFrmCntrl);	
		tc_strcpy(PLT_CodeSuffix,PltCodeSufx);
	}
	else
	{
		tc_strcpy(PLT_CodeS,"PUNE");
		tc_strcpy(PLT_CodeSuffix,"P");
	}
	printf("\n PLT_CodeS: %s\n",PLT_CodeS);fflush(stdout);
	printf("\n PLT_CodeSuffix: %s\n",PLT_CodeSuffix);fflush(stdout);
	
	// Added By Dhanashri for projectwise mapping// 

	APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(APL_Plnr_Grp,"STD");
	tc_strcat(APL_Plnr_Grp,PLT_CodeS);
	tc_strcpy(Projj,Proj_Code);
	printf("\n Projj :[%s]\n",Projj);fflush(stdout);

	// End Of code Added By Dhanashri for projectwise mapping// 

	printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);

	CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&oldusrcount,&OldParticipantRel));//DEEPTI TZ1.44
	printf("\n oldusrcount to delete  :%d\n",oldusrcount);fflush(stdout);
	for(extUsrCnt=0;extUsrCnt<oldusrcount;extUsrCnt++)
	{
		printf("\n For STD Reviewer Removing old user :%d\n",extUsrCnt);fflush(stdout);
		OldParticipantRelTag = OldParticipantRel[extUsrCnt];
						
		printf("\n For STD Reviewer  Inside remving the relation...");fflush(stdout);

		if(TCTYPE_ask_object_type(OldParticipantRelTag,&OldObjTypTask));
		if(TCTYPE_ask_name2(OldObjTypTask,&Oldtype_namee_task));
		printf("\n For STD Reviewer Task: Participants Name: %s", Oldtype_namee_task);fflush(stdout);

		if ((tc_strcmp(Oldtype_namee_task,"ChangeSpecialist1")==0))
		{
			printf("\n  For STD Reviewer  Removing the user..");fflush(stdout);

			AOM_lock(APLTaskRevT);
			//API change
			//ITKCALL(ITEM_rev_remove_participant (APLTaskRevT,OldParticipantRelTag)!=ITK_ok);
			ITKCALL(PARTICIPANT_remove_participant(APLTaskRevT,OldParticipantRelTag)!=ITK_ok);
			AOM_save_with_extensions(APLTaskRevT);  //09/05
			AOM_unlock(APLTaskRevT);
		}
		
	}

	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

	 if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\n Reviewer : No of Role found in Group are :%d\n",num_of_roles);

	//flgRoleFnd=false;
	if(num_of_roles>0)
	{
		FlaggAssignSTDReviewer=0; // by dss for projectwise mapping.

		for (i=0;i<num_of_roles ;i++ )
		{
				CALLAPI(SA_ask_role_name2(role_tags[i],&rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
				printf("\n Dsgn_No [%s]\n",Dsgn_No);fflush(stdout);

				if(strstr(rolename,"STD") && strstr(rolename,Dsgn_No) && strstr(rolename,"Reviewer") && strstr(rolename,"Default")==NULL ) 
				{
					printf("\n Reviewer : Match Found\n");fflush(stdout);
					role_tag = role_tags[i];
					CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
					printf("\n Reviewer : No of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
					if(num_of_members>0)
					{
						tag_t*	ptypes		= NULLTAG;
						tag_t*	ptypes2		= NULLTAG;
						int p1=0;
						int p2=0;

						for (j=0;j<num_of_members ;j++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
							CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
							printf("\n Reviewer : User ID Name :[%s]\n",userid);fflush(stdout);
						
							// Added by Dhanashri for projectwise mapping//
							ProjectAccessFound=0;
							Gmcnt1=0;
							GmFound1 = NULLTAG;
							GetProjectUserAccessDetails(Projj,userid,&Gmcnt1,&GmFound1);
							printf("\n Reviewer : Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
							
							countt=0;
							for(countt==0;countt<Gmcnt1;countt++)
							{
									Object_Name  =  NULL;
									CALLAPI(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
									printf("\n Reviewer : after func :  %s",Object_Name);fflush(stdout);
								
									if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,Dsgn_No) && strstr(Object_Name,"Reviewer") && strstr(Object_Name,"Default")==NULL) 
									{
										printf("\n Reviewer : Condition Satisfy... ");fflush(stdout);
										ProjectAccessFound=1;
										break;
									}
							}
							printf("\n Reviewer : ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
							// Added by Dhanashri for projectwise mapping//
							
							if(ProjectAccessFound==1)
							{
								// TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
								// EPM_create_participant(member_tags[j], participant_type, &participant_tag);
								// GRM_find_relation_type("HasParticipant", &relation_type);
								// GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
								// GRM_save_relation(relation);
								// printf("\n APL Planner Assigned..to : [%s]\n",userid);fflush(stdout);
								FlaggAssignSTDReviewer=1;

								TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
								printf("\n ChangeSpecialist1 Test 3333 \n");fflush(stdout);
								setAddTAG_STD(&p1,&ptypes,participant_type);
								printf("\n ChangeSpecialist1 Test 3333.1 \n");fflush(stdout);
								setAddTAG_STD(&p2,&ptypes2,member_tags[j]);
								printf("\n ChangeSpecialist1 Test ended 4444 \n");fflush(stdout);
							}
						}
						tag_t* participant_list = NULLTAG;
						logical bypass_assignable_check =true;
						int k = 0;

						tag_t   type1TypeTag			= NULLTAG;

						char*    type1type_name;
						printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
						for(k=0;k<p2;k++)
						{
							tag_t type1 = ptypes[k];
							if(type1 != NULLTAG )
							{
								if(TCTYPE_ask_object_type(type1,&type1TypeTag));
								if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
								printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
							}
							else
							{
								printf("\n type is NULL \n");fflush(stdout);
							}
						}

						CALLAPI(PARTICIPANT_add_participants(APLTaskRevT,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
					}
					
					if(FlaggAssignSTDReviewer==1)
					{
						printf("\n Reviewer : Break \n");fflush(stdout);
						break;
					}
				}// Role matches  
		}

		printf("\n FlaggAssignSTDReviewer: %d \n",FlaggAssignSTDReviewer);fflush(stdout);

		if(FlaggAssignSTDReviewer==0)
		{
			printf("\n Ketan Inside Default Group for Reviewer \n");fflush(stdout);

			APL_Plnr_Grp = NULL;
			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"STD");
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,PLT_CodeS);
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,"Default");
			printf("\n Test Planner Group Name:[%s]\n",APL_Plnr_Grp);
			z=0;
			for (z=0;z<num_of_roles ;z++ )
			{
				CALLAPI(SA_ask_role_name2(role_tags[z],&rolename));
				printf("\nRol Name :[%d][%s]\n",z,rolename);
				if(strstr(rolename,APL_Plnr_Grp))
				{
					printf("\n Got Default Group");
					CALLAPI(SA_find_groupmember_by_role(role_tags[z],group_tag,&num_of_members,&member_tags));
					printf("\n No of Group Members found in Group/Role are :%d\n",num_of_members);
					if(num_of_members>0)
					{
						b=0;

						tag_t*	ptypes		= NULLTAG;
						tag_t*	ptypes2		= NULLTAG;
						int p1=0;
						int p2=0;

						for (b=0;b<num_of_members ;b++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[b],&user_tag));
							//API change
							CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
							printf("\n User ID Name :[%s]\n",userid);
							// TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
							// EPM_create_participant(member_tags[b], participant_type, &participant_tag);
							// GRM_find_relation_type("HasParticipant", &relation_type);
							// GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							// GRM_save_relation(relation);
							// printf("\n APL Planner Assigned..to : [%s]\n",userid);fflush(stdout);

							TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
							printf("\n Default ChangeSpecialist1 Test 3333 \n");fflush(stdout);
							setAddTAG_STD(&p1,&ptypes,participant_type);
							printf("\n Default ChangeSpecialist1 Test 3333.1 \n");fflush(stdout);
							setAddTAG_STD(&p2,&ptypes2,member_tags[b]);
							printf("\n Default ChangeSpecialist1 Test ended 4444 \n");fflush(stdout);
							
						}
						tag_t* participant_list = NULLTAG;
						logical bypass_assignable_check =true;
						int k = 0;

						tag_t   type1TypeTag			= NULLTAG;

						char*    type1type_name;
						printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
						for(k=0;k<p2;k++)
						{
							tag_t type1 = ptypes[k];
							if(type1 != NULLTAG )
							{
								if(TCTYPE_ask_object_type(type1,&type1TypeTag));
								if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
								printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
							}
							else
							{
								printf("\n type is NULL \n");fflush(stdout);
							}
						}

						CALLAPI(PARTICIPANT_add_participants(APLTaskRevT,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
					}
				}
			}
		}        
	} // if(num_of_roles>0)

	return ITK_ok;
}
void getEPAPlantName(char* EPAPlantName, char* EPAvalue)   //added by vishal
{

		printf("\n\n ******** INSIDE getEPAPlantName FUNCTION *************\n\n");fflush(stdout);

        if(tc_strcmp(EPAPlantName,"AHD")==0)// Added by prasad
        {
            tc_strcpy(EPAvalue,"APLAHD");
        }
		else if(tc_strcmp(EPAPlantName,"SND")==0) // Added by Ketan // 22012026
        {
            tc_strcpy(EPAvalue,"APLSND");
        }
        else if (tc_strcmp(EPAPlantName,"DHARWAD")==0)
        {
            tc_strcpy(EPAvalue,"APLDWD");
        }
        else if (tc_strcmp(EPAPlantName,"CAR")==0)
        {
            tc_strcpy(EPAvalue,"APLCAR");
        }
        else if (tc_strcmp(EPAPlantName,"CVBU PUNE")==0)
        {
            tc_strcpy(EPAvalue,"APLPUNE");
        }
        else if (tc_strcmp(EPAPlantName,"CVBU PNR")==0)
        {
            tc_strcpy(EPAvalue,"APLPNR");
        }
        else if (tc_strcmp(EPAPlantName,"CVBU LKO")==0)
        {
            tc_strcpy(EPAvalue,"APLLKO");
        }
        else if (tc_strcmp(EPAPlantName,"CVBU JSR")==0)
        {
            tc_strcpy(EPAvalue,"APLJSR");
        }
		else if (tc_strcmp(EPAPlantName,"")==0)
        {
            tc_strcpy(EPAvalue,"APLPUNE");
        }
        else
        {
            tc_strcpy(EPAvalue,"APLPUNE");
        }
    
    printf("\n EPAvalue:%s\n",EPAvalue);fflush(stdout);

	printf("\n\n ******** EXITING getEPAPlantName FUNCTION *************\n\n");fflush(stdout);

}

int SynchronousDMLRel(char* APLDMLNum, char *Plant, int *SynchFlag)
{

	//*iifail          = USC_OKAY;
    int   ifail				= 0;
	int				i,j,k,l		=	0;
	int				m,n,p,q		=	0;
	int				TabSize		=	0;
	int				DsgnFlag	=	0;
	int				DsgnFound	=	0;
	int				DCRCnt	=	0;
	int				dml_count	=	0;
	int				task_count	=	0;
	int  DCRDsgnSetCNT	 =	0;
	int  DMLDsgnSetCNT	 =	0;
	int  AplDmlObjSetCNT =	0;
	int  v =	0;

	char*	ERCDMLNum	=   NULL;
	char*	TempGetS	=   NULL;
	char*	TempGetSDup	=   NULL;
	char*	b_value		=	NULL;
	char*	b_name		=	NULL;
	char*	ERCDml		=	NULL;
	char*	ERCDmlDup	=	NULL;
	char*	PLItemCls	=	NULL;
	char*	PLItemClsDup=	NULL;
	char*	WbsId		=	NULL;
	char*	WbsIdDup	=	NULL;
	char*	LfCyDML		=	NULL;
	char*	LfCyDMLDup	=	NULL;
	char*	TskDgnGrp	=	NULL;
	char*	TskDgnGrpDup=	NULL;
	char*	AplPlant	=	NULL;
	char*	DCRDsgn		=	NULL;
	char*	AplDmlObj	=	NULL;
	char*	TempWbsId	=	NULL;
	char*	TempAPLDml	=	NULL;
	char*	ERCDmlTyp	=	NULL;
	char*	ERCDmlTypDup=	NULL;
	char*	SynchDML	=	NULL;
	char*	SynchDMLDup	=	NULL;
	char*	DCRDate		=	NULL;
	char*	DCRDateDup	=	NULL;
	char*	DMLDate		=	NULL;
	char*	DMLDateDup	=	NULL;

	tag_t*	DMLObjSet	=	NULLTAG;
	tag_t*	AMDMLObjSet	=	NULLTAG;
	tag_t*	DcrMObjs	=	NULLTAG;
	tag_t*	DCRRelObjs	=	NULLTAG;
	tag_t*	DcrSO		=	NULLTAG;
	tag_t*	soDMLs		=	NULLTAG;
	tag_t*	SetOfTasks	=	NULLTAG;
	tag_t*	PlItem		=	NULLTAG;
	//tag_t*	AplDmlObjSet=	NULLTAG;
	tag_t*	SoLCObj		=	NULLTAG;
	tag_t*	SynchCtrlObj=	NULLTAG;
	tag_t*	ERCObjSet	=	NULLTAG;
	tag_t*	soDcrObj	=	NULLTAG;
	tag_t*  task_obj_tag   =	NULLTAG;

	tag_t   DMLObj		=	NULLTAG;
	tag_t   DcrMstrObj	=	NULLTAG;
	tag_t   TempDcrObj	=	NULLTAG;
	tag_t	ERCDMLObj	=	NULLTAG;
	tag_t   ERCDMLQTag	=	NULLTAG;
	tag_t   APLDMLQTag	=	NULLTAG;
	tag_t   relation_with_dml	=	NULLTAG;
	tag_t   dml_task	=	NULLTAG;
	tag_t	masterObj	=	NULLTAG;
	tag_t	LCMObj		=	NULLTAG;
	//tag_t	AplDmlObj	=	NULLTAG;
	tag_t	SynchObj	=	NULLTAG;
	tag_t	edmltodcr	=	NULLTAG;

	char*  dbScp		=	NULL;
	char **DCRDsgnSet	= (char **) MEM_alloc(40 * sizeof(char *));
	char **DMLDsgnSet	= (char **) MEM_alloc(40 * sizeof(char *));
	char **AplDmlObjSet = (char **) MEM_alloc(40 * sizeof(char *));

	printf("\nInside SynchronousDMLRel func ");fflush(stdout);

	int n_count =	5;
    char *SYNCqry_entry[5] = {"SYSCD","SUBSYSCD","Information-1","Information-4","Delete Indicator"};
    char **SYNCqry_values = (char **) MEM_alloc(50 * sizeof(char *));
    int SyncDmlCount=0;
    tag_t  SYNCCntrl_obj_Qtag	=	NULLTAG;
    tag_t  *QRY_SYNCcntrlobj = NULLTAG;
    char *SYNCinfo1 	   = NULL;
	char *SYNCinfo2 	   = NULL;
	char *SYNCinfo3 	   = NULL;
	char *SYNCinfo4 	   = NULL;
	char *SYNCinfo5 	   = NULL;
	char *SYNCinfo6 	   = NULL;
	char *SYNCinfo7 	   = NULL;
	char *SYNCinfo8 	   = NULL;
	char *SYNCinfo9 	   = NULL;
	//Control obj contains DCR and ERC cut off date (creation date) in info2 and info3 respectively

	if(QRY_find2("Control Objects...", &SYNCCntrl_obj_Qtag));
	if(SYNCCntrl_obj_Qtag!=NULLTAG)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		printf("\n Control Object Query Found passed plant in query is %s \n",Plant);fflush(stdout);
		SYNCqry_values[0] = "SynchDML";
		SYNCqry_values[1] = "RelProc";
		SYNCqry_values[2] = "Live";
		SYNCqry_values[3] = Plant;
		SYNCqry_values[4] = "0";

		ITKCALL(QRY_execute(SYNCCntrl_obj_Qtag, n_count, SYNCqry_entry, SYNCqry_values, &SyncDmlCount, &QRY_SYNCcntrlobj));
    	printf("\nNo. of control object found : %d",SyncDmlCount);fflush(stdout);

		if(SyncDmlCount>0)
		{
			printf("\nSynchDML Control object found...! lets begin ..!");fflush(stdout);

			 ITKCALL(AOM_ask_value_string( QRY_SYNCcntrlobj[0], "t5_Userinfo1", &SYNCinfo1));
    		 printf("\n SYNCinfo1 : %s",SYNCinfo1);fflush(stdout);
			 ITKCALL(AOM_ask_value_string( QRY_SYNCcntrlobj[0], "t5_Userinfo2", &SYNCinfo2));
    		 printf("\n SYNCinfo2 : %s",SYNCinfo2);fflush(stdout);
			 ITKCALL(AOM_ask_value_string( QRY_SYNCcntrlobj[0], "t5_Userinfo3", &SYNCinfo3));
    		 printf("\n SYNCinfo3 : %s",SYNCinfo3);fflush(stdout);
			 ITKCALL(AOM_ask_value_string( QRY_SYNCcntrlobj[0], "t5_Userinfo4", &SYNCinfo4));
    		 printf("\n SYNCinfo4 : %s",SYNCinfo4);fflush(stdout);
			 ITKCALL(AOM_ask_value_string( QRY_SYNCcntrlobj[0], "t5_Userinfo5", &SYNCinfo5));
    		 printf("\n SYNCinfo5 : %s",SYNCinfo5);fflush(stdout);
			 ITKCALL(AOM_ask_value_string( QRY_SYNCcntrlobj[0], "t5_Userinfo6", &SYNCinfo6));
    		 printf("\n SYNCinfo6 : %s",SYNCinfo6);fflush(stdout);
			 ITKCALL(AOM_ask_value_string( QRY_SYNCcntrlobj[0], "t5_Userinfo7", &SYNCinfo7));
    		 printf("\n SYNCinfo7 : %s",SYNCinfo7);fflush(stdout);
			 ITKCALL(AOM_ask_value_string( QRY_SYNCcntrlobj[0], "t5_Userinfo8", &SYNCinfo8));
    		 printf("\n SYNCinfo8 : %s",SYNCinfo8);fflush(stdout);
			 ITKCALL(AOM_ask_value_string( QRY_SYNCcntrlobj[0], "t5_Userinfo9", &SYNCinfo9));
    		 printf("\n SYNCinfo9 : %s",SYNCinfo9);fflush(stdout);
		}
		else
		{
			printf("\n\nSynchCtrlObj not found\n\n");fflush(stdout);
		    *SynchFlag = 1;
		    return ifail;
		}
	}
	else
	{
		    printf("\n\n Control object query not found\n\n");fflush(stdout);
		    *SynchFlag = 1;
		    return ifail;
	}

	printf("\n APL DML Num and Plant is=[%s] [%s]\n",APLDMLNum,Plant);

	TempAPLDml=(char *)MEM_alloc(80);
	tc_strcpy(TempAPLDml,"");
	tc_strcpy(TempAPLDml,APLDMLNum);

	ERCDMLNum = tc_strtok(TempAPLDml,"_");
	printf("\n ERCDMLNum : %s",ERCDMLNum);fflush(stdout);

	printf("\n\nQuerying ERC DMLs above defined date in SynchCtrlObj ");fflush(stdout);

	 char    *qry_ERCDMLNum[2]  	= 	{"Item ID","Created After"};
	 char	 **qry_valuesERCDML	= 	(char **) MEM_alloc(5 * sizeof(char *));
	 char 	 *keys[] 	= 	{"creation_date"};  // creation date of dml should be more than dcr controlobject ercdml date SYNCinfo3
	 int     num_to_sort =	1;
	 int  	 orders[]  	=	{1};
	 int     n_ent = 2;
	 int     control_num_found   =   0;

    if(QRY_find2("Item Revision...", &ERCDMLQTag));
    if(ERCDMLQTag!=NULLTAG)
	{
	 printf("\n\n\nfor ERC DML Item Revision query found"); fflush(stdout);
	 qry_valuesERCDML[0]= ERCDMLNum;
	 qry_valuesERCDML[1]= SYNCinfo3;
	 //qry_valuesERCDML[2]= SYNCinfo3;

	 if(QRY_execute_with_sort(ERCDMLQTag, n_ent, qry_ERCDMLNum, qry_valuesERCDML,num_to_sort, keys, orders, &control_num_found, &DMLObjSet));
	 printf("\n\nNo. of Item Revision found : %d",control_num_found);fflush(stdout);
	 int r=control_num_found-1;
	 printf("\n   r is control_num_found less 1 :%d",r); fflush(stdout);
	 if(r>=0)
		{
		 DMLObj=DMLObjSet[r];
		 ITKCALL(GRM_find_relation_type("CMImplements",&edmltodcr));
		 if((edmltodcr!=NULLTAG)&&(DMLObj!=NULLTAG))
			{
			  printf("\n\n\nfor ERC DML to DCR objects\n"); fflush(stdout);
			  ITKCALL(GRM_list_secondary_objects_only(DMLObj,edmltodcr,&DCRCnt,&DcrMObjs));
			  printf("Size of DCR Objs=[%d]\n",DCRCnt);fflush(stdout);
			  int t =0;
			  DsgnFlag = 0;
			if(DCRCnt>0)
			 {
			  for(t=0;t<DCRCnt;t++)
			  {
				TempDcrObj=NULLTAG;
			  TempDcrObj=DcrMObjs[t];
			  ITKCALL(AOM_ask_value_string(TempDcrObj,"item_id",&TempGetS));
			  printf("\n TempGetS ...%s", TempGetS);fflush(stdout);

			  char   *qry_DCR[2]  	= 	{"Item ID","Created After"};
	          char	 **qry_DCRval	= 	(char **) MEM_alloc(5 * sizeof(char *));
	          char 	 *keysDCR[] 	= 	{"creation_date"};  // creation date of dml should be more than dcr controlobject ercdml date SYNCinfo2
	          int     DCR_to_sort =	1;
	          int  	  DCRorders[]  	=	{1};
	          int     dcr_num_found   =  0;

			   qry_DCRval[0]=TempGetS;
			   qry_DCRval[1]=SYNCinfo2;
			   //qry_DCRval[2]=SYNCinfo3;
			   if(QRY_execute_with_sort(ERCDMLQTag, n_ent, qry_DCR, qry_DCRval,DCR_to_sort, keysDCR, DCRorders, &dcr_num_found, &soDcrObj));
	           printf("\n\nNo. of Item Revision for DCR found : %d",dcr_num_found);fflush(stdout);
			   if(dcr_num_found==0)
				{
				   printf("\n DCR found but below cut off date as set in SynchCtrlObj...\n"); fflush(stdout);
				   *SynchFlag = 1;
				   return ifail;
			    }
				//DsgnFlag = 0;
				ITKCALL(AOM_UIF_ask_value(TempDcrObj,"t5_DcrDesgGrp",&b_name));
			    printf("\n b_name ...%s", b_name);fflush(stdout);
				if(tc_strstr(b_name,"NA")!=NULL)
				{
					printf("\n 'NA' design group is selected in DCR ..."); fflush(stdout);
					*SynchFlag = 1;
					return ifail;
				}
				else if (tc_strcmp(b_name,"")!=0)
				{
					DsgnFlag =1;
					int v=0,g=0,DCRFlag=0;
					printf("\n Design group is selected in DCR ..."); fflush(stdout);
					for(g=0;g<DCRDsgnSetCNT;g++)
					{
						printf("\n Design group DCR  checking in DCRset befpore adding  ..."); fflush(stdout);
						printf("\n\n DCRDsgnSet found : %s at  %d",DCRDsgnSet[g],g);fflush(stdout);
						printf("\n b_name ...%s", b_name);fflush(stdout);
						if(tc_strcmp(DCRDsgnSet[g],b_name)==0)
						{
							DCRFlag++;
							printf("\n\n  DCRFlag found in DCRDsgnSet:  %d",DCRFlag);fflush(stdout);
						}
					}
					if(DCRFlag == 0)
					{
					  DCRDsgnSet[DCRDsgnSetCNT]=b_name;
					  printf("\n DCR Added in DCRDsgnSet ...!!"); fflush(stdout);
					  DCRDsgnSetCNT++;
					  for(v=0;v<DCRDsgnSetCNT;v++)
					   {
				        printf("\n DCRDsgnSet found : %s at  %d\n",DCRDsgnSet[v],v);fflush(stdout);
					   }
					}

				}
				else
				{
					printf("\n design group not found in DCR ..."); fflush(stdout);
					*SynchFlag = 1;
					return ifail;
				}

			}
			if(DsgnFlag == 0)
			 {
				printf("\n Not any design group is there in DCR ..."); fflush(stdout);
				*SynchFlag = 1;
				return ifail;
			}

		    }
			else
			{
				printf("\n DCR Not FOUND ..."); fflush(stdout);
				*SynchFlag = 1;
				return ifail;
			}
	    }
		else
		{
			printf("\n\n\nfor ERC DML nulltag or dcr relation is nulltag ..!"); fflush(stdout);
			*SynchFlag = 1;
			return ifail;
		}

	}
	else
    {
      printf("\n\nERC DML not found or found but below cut off date as set in SynchCtrlObj\n\n");fflush(stdout);
      *SynchFlag = 1;
      return ifail;
    }
	}
	char *DCRTypeDup	= NULL;
	int e=0;
	for(e=0;e<DCRCnt;e++)
	{
    ITKCALL(AOM_ask_value_string(DcrMObjs[e],"item_id",&TempGetS));
	printf("\n\t  TempGetS ...%s", TempGetS);fflush(stdout);

	ITKCALL(WSOM_ask_object_type2(DcrMObjs[e],&DCRTypeDup));
	printf("\n DCRTypeDup  %s \n",DCRTypeDup);

	ITKCALL(GRM_find_relation_type("CMImplementedBy",&relation_with_dml));
    ITKCALL(GRM_list_primary_objects_only(DcrMObjs[e],relation_with_dml,&dml_count,&soDMLs));
	printf("\nSize of ERC DMLObjs attached to DCR=[%d]\n\n",dml_count);fflush(stdout);
	}
	//printf("\nSize of ERC DMLObjs attached to DCR=[%d]\n\n",dml_count);fflush(stdout);

	if(dml_count>0)
	{
		for(l=0;l<dml_count;l++)
		{
			 ERCDMLObj	= NULLTAG;
			char *ERCDml	= NULL;
			char *ERCDmlDup	= NULL;
			//tag_t*PlItem= NULL;
			char *ERCDmlTyp	= NULL;
			char *ERCDmlTypDup= NULL;

			ERCDMLObj = soDMLs[l];
			ITKCALL(WSOM_ask_object_type2(ERCDMLObj,&ERCDmlTypDup));
			printf("\n obj typeofDML %s \n",ERCDmlTypDup);
			if(tc_strcmp(ERCDmlTypDup,"ChangeRequestRevision")==0)
			{
				printf("\n ERC dML found objtypeofDML %s \n",ERCDmlTypDup);
			}
			else
			{
				continue;
			}

			ITKCALL(AOM_UIF_ask_value(ERCDMLObj,"item_id",&ERCDml));
			printf("\nERC DML attached to DCR is=[%s] ",ERCDml);fflush(stdout);

			//Checking if ERC DML creation date is same or later than set in SynchCtrlObj

		    char   *qry_ERCDml[2]  	= 	{"Item ID","Created After"};
	        char   **qry_ERCDmlval	= 	(char **) MEM_alloc(5 * sizeof(char *));
	        char   *keysERCDml[] 	= 	{"creation_date"};  // creation date of dml should be more than dcr controlobject ercdml date SYNCinfo3
	        int    ERCDmlto_sort =	1;
	        int    ERCDmlorders[]  	=	{1};
	        int    ERCDml_num_found =  0;

			qry_ERCDmlval[0] = ERCDml;
			qry_ERCDmlval[1] = SYNCinfo3;
			//qry_ERCDmlval[2] = SYNCinfo3;
			if(QRY_execute_with_sort(ERCDMLQTag, n_ent, qry_ERCDml, qry_ERCDmlval,ERCDmlto_sort, keysERCDml, ERCDmlorders, &ERCDml_num_found, &ERCObjSet));
	        printf("\n\nNo. of Item Revision found : %d",ERCDml_num_found);fflush(stdout);

			if(ERCDml_num_found==0)
			{
			   printf("\n\nERC DML not found or found but below cut off date as set in SynchCtrlObj...\n\n");fflush(stdout);
			   *SynchFlag = 1;
			   return ifail;
			}

            ITKCALL(AOM_UIF_ask_value(ERCDMLObj,"item_id",&ERCDml));
			printf("\nERC DML attached to DCR is=[%s] ",ERCDml);fflush(stdout);
			ITKCALL(AOM_ask_value_string(ERCDMLObj,"t5_rlstype",&ERCDmlTyp));
			printf("\nERC DML attached to DCR is=[%s] and Release type=[%s]",ERCDml,ERCDmlTyp);fflush(stdout);

			if(tc_strcmp(ERCDmlTyp,"XO")==0)
			{
				continue;
			}
			ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&dml_task));
			if(dml_task!=NULLTAG)
			{

			 ITKCALL(GRM_list_secondary_objects_only(ERCObjSet[0],dml_task,&task_count,&PlItem));
		     printf("\n task_count = %d",task_count);

		    if(task_count > 1) // ignore one ERC task - CmTaskIt
		    {
		  		for(m=0;m<task_count;m++)
		  		{
					PLItemCls		= NULL;
					PLItemClsDup	= NULL;
					WbsId			= NULL;
					WbsIdDup		= NULL;
					LfCyDML		= NULL;
					LfCyDMLDup	= NULL;
					TempWbsId		= NULL;

					ITKCALL(AOM_ask_value_string(PlItem[m],"object_type",&PLItemCls));
		  			printf("\nClassname of object is:%s\n",PLItemCls);fflush(stdout);
		  			if(tc_strcmp(PLItemCls,"T5_APLDMLRevision")==0)
		  			{
						ITKCALL(AOM_ask_value_string(PlItem[m],"item_id",&WbsId));
					    printf("\nAPL DML No : %s and \n ",WbsId);fflush(stdout);

					    printf("\nMain DML plant is [%s] and APL DML plant is [%s] \n",Plant,WbsId);fflush(stdout);

						if(tc_strstr(WbsId,Plant)!=NULL)
		  				{
							ITKCALL(AOM_UIF_ask_value(PlItem[m],"release_status_list",&LfCyDML));
							printf("\nAPL DML No : %s   and LCS is: %s\n",WbsId,LfCyDML);fflush(stdout);

							if (tc_strstr(LfCyDML,SYNCinfo5)!=NULL || tc_strstr(LfCyDML,SYNCinfo6)!=NULL || tc_strstr(LfCyDML,SYNCinfo7)!=NULL || tc_strstr(LfCyDML,SYNCinfo8)!=NULL)
							{
								printf("\nAPL DML  is above apl released ..!!\n\n");fflush(stdout);
								//Copying (only APLRlz DMLs to set other than passed APL DML in function)
								if (tc_strstr(LfCyDML,SYNCinfo5)!=NULL)
								{
									printf("\nAPL DML  is above apl released ..2 !!\n\n");fflush(stdout);
									if (tc_strcmp(APLDMLNum,WbsId)!=0)
									{
										printf("\nAPL DML  is above apl released . checking 3 .!\n\n");fflush(stdout);
										int v2 =0;
										//add apl dml to set AplDmlObjSet
										AplDmlObjSet[AplDmlObjSetCNT]= WbsId;
										for(v2=0;v2<=AplDmlObjSetCNT;v2++)
										{
											printf("\nAplDmlObjSet is : %s  at %d\n",AplDmlObjSet[v2],v2);fflush(stdout);
										}
										printf("\nAPLAplDmlObjSetCNT  is : %d\n",AplDmlObjSetCNT);fflush(stdout);
										AplDmlObjSetCNT++;
									}
								}
							   tag_t APLDML_TASK_tag  = NULLTAG;
                               tag_t task_rev_tag    = NULLTAG;
                               char* TaskType = NULL;
                               int   n_tasksFnd           = 0;

                               ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&APLDML_TASK_tag));
                               if(APLDML_TASK_tag!=NULLTAG)
                               {
								printf("\nAPL DML  task  checking.!\n\n");fflush(stdout);
                               	ITKCALL((GRM_list_secondary_objects_only(PlItem[m], APLDML_TASK_tag, &n_tasksFnd, &task_obj_tag )));
								printf("\n Tasks are present %d .....\n",n_tasksFnd);fflush(stdout);
							    if(n_tasksFnd>0)
                               	{
									tag_t apl_task =NULLTAG;
									printf("\n Tasks present %d .....\n",n_tasksFnd);fflush(stdout);
									for(n=0;n<n_tasksFnd;n++)
									{

										apl_task = task_obj_tag[n];
										int v3 =0;
										ITKCALL(AOM_UIF_ask_value(apl_task,"t5_crdesigngroup",&TskDgnGrp));  //t5designgroup
										printf("\nAPL DML No TskDgnGrp is : %s \n",TskDgnGrp);fflush(stdout);
										if(tc_strcmp(TskDgnGrp,"")!=0)
										{
											DMLDsgnSet[DMLDsgnSetCNT] = TskDgnGrp;

											printf("\nAPL DML No TskDgnGrp is added to set : %s \n",TskDgnGrp);fflush(stdout);
											for(v3=0;v3<=DMLDsgnSetCNT;v3++)
											{
											  printf("\n\nAPL DML DMLDsgnSet is : %s  at %d\n",DMLDsgnSet[v3],v3);fflush(stdout);
											}
											DMLDsgnSetCNT++;
											printf("\nDMLDsgnSetCNT TskDgnGrp found cnt is : %d \n",DMLDsgnSetCNT);fflush(stdout);
										}
									}

                               	}
							   }
							   else
							   {
								   printf("\n APLDML_TASK_tag is nulltag .....\n");fflush(stdout);
							   }

							}
							else
							{
								printf("\n Below APLRlz APL DML present for ERC DML");
								*SynchFlag = 0;
								 return ifail;
							}
						}
						else
						{
							printf("\n APL DML Plant not matched");
						}
		  		   }
		  		   else if(tc_strcmp(PLItemClsDup,"T5_ChangeTaskRevision")==0)
		  		   {
		  				printf("\n ERC Task found so continue ");fflush(stdout);
		  		   }
				}
			}
			else
		    {
		    	printf("\n No APL DML present for ERC DML");
				*SynchFlag = 0;
				 return ifail;
			}
		  }
	    }

	}
	else
	{
		printf("\nNo ERC DML found attached to DCR\n\n");fflush(stdout);
		*SynchFlag = 1;
		return ifail;
	}

	printf("\n...Size(DCRDsgnSetCNT) = %d",DCRDsgnSetCNT);
	printf("\n...Size(DMLDsgnSetCNT) = %d",DMLDsgnSetCNT);
	printf("\n...Size(AplDmlObjSetCNT) = %d",AplDmlObjSetCNT);

	if (DCRDsgnSetCNT>0)
	{
		i = 0;
		int w1=0,w2=0;
		for(k=0;k<DCRDsgnSetCNT;k++)
		{
			DCRDsgn	= NULL;
			DCRDsgn = DCRDsgnSet[k];
			DsgnFound	=	0;
			printf("\n\nDCRDsgn is : %s \n",DCRDsgn);fflush(stdout);

           for(w1=0;w1<DMLDsgnSetCNT;w1++)
			{
			    printf("\nAPL DML DMLDsgnSet   found is : %s  at %d\n",DMLDsgnSet[w1],w1);fflush(stdout);
			   if(tc_strcmp(DMLDsgnSet[w1],DCRDsgn)==0)
				{
				 DsgnFound++;
				 printf("\n...Size(DsgnFound) = %d",DsgnFound);
				}
			}
			if (DsgnFound<0)
			{
				printf("\n %s Design group task NOT found APL Released\n",DCRDsgn);
			}
			else
			{
				printf("\n %s Design group task found APL Released\n",DCRDsgn);
				i++;
			}
		}
		printf("\n...Size(DCRDsgnSetCNT) = %d",DCRDsgnSetCNT);
		printf("\n...Size(i) = %d",i);
	}

	if (i == DCRDsgnSetCNT)
	{
		printf("\n\n All the DCR design group tasks are APL Released ..!\n");
		*SynchFlag = 1;

		if (AplDmlObjSetCNT>0)
		{
			for(p=0;p<AplDmlObjSetCNT;p++)
			{
				//Submitting other pending APLRlz DMLs
				SoLCObj		=	NULL;
				SynchDML	=	NULL;
				SynchDMLDup	=	NULL;
			    AplDmlObj	=	NULL;

				AplDmlObj	= AplDmlObjSet[p];
				printf("\nAPL DML AplDmlObjSet is : %s  at %d \n",AplDmlObjSet[p],p);fflush(stdout);
				printf("\nAPL DML AplDmlObj is : %s  \n",AplDmlObj);fflush(stdout);

				char    *qry_APLDML[2]  	= 	{"Item ID","Created After"};
	            char	 **qry_valuesAPLDML	= 	(char **) MEM_alloc(5 * sizeof(char *));
	            char 	 *KEYS[] 	= 	{"creation_date"};  // creation date of dml should be more than dcr controlobject ercdml date SYNCinfo3
	            int     num_sort =	1;
	            int  	 ORDER[]  	=	{1};
	            int     n_etr = 2;
	            int     con_found   =   0;

			  if(QRY_find2("Item Revision...", &APLDMLQTag));
		      if(APLDMLQTag!=NULLTAG)
	           {
	             printf("\n\n\nfor ERC DML Item Revision query found"); fflush(stdout);
	             qry_valuesAPLDML[0]= AplDmlObj;
				 qry_valuesAPLDML[1]= SYNCinfo3;
				 //qry_valuesAPLDML[2]= SYNCinfo3;

	             if(QRY_execute_with_sort(APLDMLQTag, n_etr, qry_APLDML, qry_valuesAPLDML,num_sort, KEYS, ORDER, &con_found, &AMDMLObjSet));
	             printf("\n\nNo. of Item Revision found : %d",con_found);fflush(stdout);
	             int apldml =con_found-1;
	             printf("\n\t Size of apldml  r is :%d",apldml); fflush(stdout);
	            if(apldml>=0)
	            {
				  tag_t AMDMLDMLObj = NULLTAG;
				  tag_t APLDMLRevTag = NULLTAG;
				  tag_t APLDMLTag = NULLTAG;
	              AMDMLDMLObj=AMDMLObjSet[apldml];

				 ITKCALL(ITEM_ask_item_of_rev( AMDMLObjSet[0], &APLDMLTag));
				 ITKCALL(ITEM_ask_latest_rev(APLDMLTag,&APLDMLRevTag));
				 // Need to submit each in stdsi epa LC and update sync attribute accordingly
				if(APLDMLRevTag!=NULLTAG)
				{
				 ITKCALL(AOM_ask_value_string(APLDMLRevTag,"t5_SynchDML",&SynchDML));
				 printf("\nAPL DML SynchDML attribute is  : %s and ",SynchDML);fflush(stdout);
				 if(tc_strcmp(SynchDML,"Y")==0)
					{
						printf("\n need to set SynchrnousDML of DML object Attribute as blank ...1");fflush(stdout);
						ITKCALL(AOM_lock(APLDMLRevTag));
						ITKCALL(AOM_set_value_string(APLDMLRevTag,"t5_SynchDML",""));
						ITKCALL( AOM_save_with_extensions(APLDMLRevTag) );
						ITKCALL( AOM_unlock(APLDMLRevTag) );
						ITKCALL(AOM_ask_value_string(APLDMLRevTag,"t5_SynchDML",&SynchDML));
						printf("\nAPL DML SynchDML attribute is  : %s and ",SynchDML);fflush(stdout);
				 	}

				 tag_t template_tag = NULLTAG;
				 tag_t test_job_a = NULLTAG;
				 int attachment_types = 1;
				 printf("\n Finding Release Process Template\n");fflush(stdout);


				printf("\n SYNCinfo9  allow dml to submit in workflow if matched : %s",SYNCinfo9);fflush(stdout);

				//if dml type is WT then submit it into STD LC
				 if(tc_strcmp(SYNCinfo9,"WorkflowSubmit")==0)
				  {
					ITKCALL(EPM_find_template2("STDSI DML WorkFlow",0,&template_tag));
					if (template_tag!=NULLTAG)
					{
						printf("\n Submit APL DML of release type WT in to STDSI DML WorkFlow\n");fflush(stdout);
						ITKCALL(EPM_create_process("STD DML Process","",template_tag,1, &APLDMLRevTag,&attachment_types,&test_job_a));
						printf("\n Submit STD DML in to workflow process complete\n");fflush(stdout);
					}

					printf("\n After Submitted the DML into LC ... removing 'Synch DML' 'Y' tag if present\n");fflush(stdout);

					ITKCALL(AOM_ask_value_string(APLDMLRevTag,"t5_SynchDML",&SynchDML));
					printf("\nAPL DML SynchDML attribute is  : %s and ",SynchDML);fflush(stdout);


				  }
				  else
				  {
					  printf("\n else loop  update SYNCinfo9 to WorkflowSubmit  for workflow Process Template\n");fflush(stdout);
				   }
				}

			   }
		    }
		  }
		}
	}
	else
	{
		printf("\n\n Not all the DCR design group tasks are APL Released\n");
		*SynchFlag = 0;

		//Setting 'Synch DML' value to Y as DML is stopped
		if (AplDmlObjSetCNT>0)
		{
			for(q=0;q<AplDmlObjSetCNT;q++)
			{
				SynchDML	=	NULL;
				SynchDMLDup	=	NULL;
				AplDmlObj	=	NULL;

				AplDmlObj	= AplDmlObjSet[q];
				printf("\nAPL DML AplDmlObjSet is : %s  at %d \n",AplDmlObjSet[q],q);fflush(stdout);
				printf("\nAPL DML AplDmlObj is : %s  \n",AplDmlObj);fflush(stdout);

				char    *qry_APLDML[2]  	= 	{"Item ID","Created After"};
	            char	 **qry_valuesAPLDML	= 	(char **) MEM_alloc(5 * sizeof(char *));
	            char 	 *KEYS[] 	= 	{"creation_date"};  // creation date of dml should be more than dcr controlobject ercdml date SYNCinfo3
	            int     num_sort =	1;
	            int  	 ORDER[]  	=	{1};
	            int     n_etr = 2;
	            int     con_found   =   0;

			  if(QRY_find2("Item Revision...", &APLDMLQTag));
		      if(APLDMLQTag!=NULLTAG)
	           {
	             printf("\n\n\nfor ERC DML Item Revision query found"); fflush(stdout);
	             qry_valuesAPLDML[0]= AplDmlObj;
				 qry_valuesAPLDML[1]= SYNCinfo3;
				 //qry_valuesAPLDML[2]= SYNCinfo3;

	             if(QRY_execute_with_sort(APLDMLQTag, n_etr, qry_APLDML, qry_valuesAPLDML,num_sort, KEYS, ORDER, &con_found, &AMDMLObjSet));
	             printf("\n\nNo. of Item Revision found : %d",con_found);fflush(stdout);
	             int apldml =con_found-1;
	             printf("\n\t Size of apldml  r is :%d",apldml); fflush(stdout);

				if(apldml>=0)
	            {
				  tag_t AMDMLDMLObj = NULLTAG;
				  tag_t APLDMLRevTag = NULLTAG;
				  tag_t APLDMLTag = NULLTAG;
	              AMDMLDMLObj=AMDMLObjSet[apldml];

				 ITKCALL(ITEM_ask_item_of_rev( AMDMLObjSet[0], &APLDMLTag));
				 ITKCALL(ITEM_ask_latest_rev(APLDMLTag,&APLDMLRevTag));
				if(APLDMLRevTag!=NULLTAG)
				{
			      ITKCALL(AOM_ask_value_string(APLDMLRevTag,"t5_SynchDML",&SynchDML));
			      printf("SynchrnousDML attribute of APLDMLRevTag is :%s\n",SynchDML);fflush(stdout);
			      if(tc_strcmp(SynchDML,"Y")==0)
			      {
			      	continue;
			      }
			      else
			      {
			      	
					ITKCALL(AOM_lock(APLDMLRevTag));
					ITKCALL(AOM_set_value_string(APLDMLRevTag,"t5_SynchDML","Y"));
					ITKCALL(AOM_save_with_extensions(APLDMLRevTag));
					ITKCALL(AOM_unlock(APLDMLRevTag));  
			      	ITKCALL(AOM_ask_value_string(APLDMLRevTag,"t5_SynchDML",&SynchDML));
			      	printf("SynchrnousDML of DML object is :%s\n",SynchDML);fflush(stdout);
			      
			      }
				}
				
			   }
			 }
			}
		}
	}

	printf("\n at exit of SynchronousDMLRel func ");fflush(stdout);
	return ifail;
}

static int t5UpdateLifecycleStateSTD_DMLTask(tag_t object_tag, char* lifecycleStateName, char* lcstoremove,char *epa_plantName)
{
	int n_values_checkin = 0;
	int cunt1 = 0;
	int flag = 0;
	int				ifail=0;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;
    logical stat  ;
	char*			value					=NULL;
	char cNextDate[20]={0};

	char *class_name = NULL;
	char *Release_Status = NULL;

	tag_t		class_id				=     NULLTAG;
	tag_t		tReleaseStatusList_checkin=NULLTAG;
	tag_t*		attr_tags_checkin		=	NULLTAG;
	tag_t			status_rel					= NULLTAG;
	tag_t*    status_list1=NULLTAG;
	int              st_count1 = 0;
	int				st_count_1 = 0;
	int				DMLFlag =0;

	tag_t*    status_list;
	tag_t*    status_list_1=NULLTAG;
	tag_t	*rev_list				= NULL;
	int       ii=0;
	int       RevFlag=0;
	int       PreRevFlag=0;
	int       st_count=0;
	int Item_count      =  0;
	char*			PreRevOnly				= NULL;
	char*			RevOnly				= NULL;
	char*			Part_Rev				= NULL;
	char*			Part_Rev_copy				= NULL;
	char*			Part_rev_Id				= NULL;
	char*			PlantLCSFlag				= NULL;
	int       iLCS=0;
	int       cntLcs=0;
	WSOM_open_ended_status_t  	open_ended_or_stock_out;
	char cCurrentAccessDate[20]={0};
	date_t Ltest_date_2;
	date_t *Rel_start_end_values	= NULL;
	int	n_dates 	= 0;
	int	n_effectivities 		= 0;
	int	jj 		= 0;
    char	*old_to_date			= NULL;
	logical date_is_valid  ;
	date_t Ltest_date_1;
	date_t *Lstart_end_date			= NULL;
	tag_t	Leff_d				= NULLTAG;
	tag_t	*effectivities_tag		= NULL;

	logical		*is_it_null_checkin		=   NULL;
	logical		*is_it_empty_checkin	=   NULL;
	logical		log1;
	logical		checkout1;
	logical			retain							= 0;

	char*			Part_no				= NULL;
	char		   *WSO_Name	=	NULL;
	const char *qry_entries[2];//Multiple Item Queried Error
	const char *qry_values[2];//Multiple Item Queried Error
	int n_tags_found=0;
	tag_t	*itemclassp	= NULLTAG;
	tag_t item = NULLTAG;
	char	*Part_clr_ind	=	NULL;
	printf("\n inside t5UpdateLifecycleStateSTD_DMLTask: [%s:%s]\n ",lifecycleStateName,lcstoremove);fflush(stdout);
	ITKCALL(WSOM_ask_release_status_list(object_tag,&st_count_1,&status_list_1));         //**VB**
	printf("\n st_count1 :%d is\n",st_count_1);fflush(stdout);
	if(st_count_1>0)
	{
		for (cnt=0;cnt< st_count_1;cnt++ )
		{
			WSO_Name=NULL;
			ITKCALL(AOM_ask_name(status_list_1[cnt],&WSO_Name));
			printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
			if(tc_strcmp(WSO_Name,"")!=0)
			{
				//if (tc_strcmp(WSO_Name,"T5_LcsSTDWrkg")==0)
				if (tc_strcmp(WSO_Name,lifecycleStateName)==0)
				{
					DMLFlag = 1;
				}
			}
		}
	}

	tag_t	relation_type						= NULLTAG;
	int dmlTskcount=0;
	int ek=0;
	int epaSamePlantFnd=0;
	tag_t*			PartDmlTaskTags			= NULLTAG;
	tag_t			PartDmlTaskTag				= NULLTAG;
	tag_t			objTypeRefTag						= NULLTAG;
	char			*type_name_ref=NULL;
	char			*epaTaskId=NULL;
	char			*Part_no_epaCheck=NULL;

	ITKCALL(AOM_ask_value_string(object_tag,"item_id",&Part_no_epaCheck));
	printf("\n\n\t\t Part_no_epaCheck  is :%s",Part_no_epaCheck);	fflush(stdout);

	ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
	if (relation_type!=NULLTAG)
	{
		printf("\n\n\t\t relation_type is not null tag");	fflush(stdout);
		ITKCALL(GRM_list_primary_objects_only(object_tag,relation_type,&dmlTskcount,&PartDmlTaskTags));
		printf("\n dmlTskcount is :%d\n",dmlTskcount);fflush(stdout);
		if(dmlTskcount >0)
		{
			
			for (ek=0;ek<dmlTskcount ;ek++ )
			{
				PartDmlTaskTag=NULLTAG;
				PartDmlTaskTag=PartDmlTaskTags[ek];//task pointer
				printf("\n\n\t\t INSIDE: ");fflush(stdout);
				
				if (PartDmlTaskTag!=NULLTAG)
				{
					objTypeRefTag	=	NULLTAG;
					type_name_ref			=	NULL;

					ITKCALL(TCTYPE_ask_object_type(PartDmlTaskTag,&objTypeRefTag));//task pointer
					ITKCALL(TCTYPE_ask_name2(objTypeRefTag,&type_name_ref));

					printf("\n\n\t\t type_name_ref:%s",type_name_ref);fflush(stdout);

					if (strcmp(type_name_ref,"T5_EPATaskRevision")==0)
					{
						epaTaskId=NULL;
						ITKCALL(AOM_ask_value_string(PartDmlTaskTag, "item_id",&epaTaskId));
						printf("\n\n\t\t epaTaskId:%s:%s",epaTaskId,epa_plantName);fflush(stdout);
						if(tc_strstr(epaTaskId,epa_plantName)!=NULL)
						{
							epaSamePlantFnd++;
							break;
							
						}
					}
				}
			}
		}
	}
	else
	{
		printf("\n\n\t\t relation_type is null tag");	fflush(stdout);
	}

	if(epaSamePlantFnd>0)
	{
		return 0;
	}

	if((strcmp(lcstoremove,"NA")==0 && DMLFlag == 0))
	{
		printf("\n Inside NA....");fflush(stdout);
		//API change
		if (RELSTAT_create_release_status(lifecycleStateName,&status_rel));
		if(RELSTAT_add_release_status(status_rel,1,&object_tag,retain)); 
	}
else
   {
	CALLAPI(POM_class_of_instance(object_tag,&class_id));
	CALLAPI(POM_name_of_class(class_id,&class_name));
	printf("\n class_name is :%s\n",class_name);fflush(stdout);

	CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
	CALLAPI(WSOM_ask_release_status_list(object_tag,&st_count1,&status_list1));
	printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

	CALLAPI(POM_unload_instances (1,&object_tag));
	CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
	CALLAPI(POM_is_loaded(object_tag,&log1));
	if(log1 == 1)
	{
		 printf(" Load Success\n " );
	}
	else
	printf("Load Failure\n"  );

	CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin) );
	printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
	if(n_values_checkin>0)
	{
		CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
		printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);
        flag = 0;
		for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
		{
			printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
			if(AOM_ask_name(attr_tags_checkin[cunt1], &Release_Status));
		   printf("\n  Release_Status changes done: for workspaceobject     %s\n", Release_Status);fflush(stdout);
            if( (tc_strstr(lifecycleStateName,"T5_LcsStd")!=NULL) && (tc_strstr(lifecycleStateName,"Rlzd")!=NULL) )
            {
				if( (tc_strcmp(Release_Status,lcstoremove)==0))
				{
				CALLAPI(POM_unload_instances (1,&object_tag));
				CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
				CALLAPI(POM_is_loaded(object_tag,&log1));

				//CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,flag,1));
				CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,cunt1,1));
				printf("\n cunt 1 == 0 removedd is :%d\n",cunt1);fflush(stdout);

				CALLAPI(POM_save_instances(1,&object_tag,1));

				CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));

				CALLAPI(AOM_lock(object_tag));

				CALLAPI(AOM_save_with_extensions(object_tag));
				CALLAPI(AOM_refresh(object_tag,1));
				 CALLAPI(AOM_unlock(object_tag));
				 //PlantLCSFlag = "CAR";
				}
			}

			if( (tc_strcmp(Release_Status,lifecycleStateName)==0))
				{
				CALLAPI(POM_unload_instances (1,&object_tag));
				CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
				CALLAPI(POM_is_loaded(object_tag,&log1));

				//CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,flag,1));
				CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,cunt1,1));
				printf("\n cunt 1 == 0 removedd is :%d\n",cunt1);fflush(stdout);

				CALLAPI(POM_save_instances(1,&object_tag,1));

				CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));

				CALLAPI(AOM_lock(object_tag));

				CALLAPI(AOM_save_with_extensions(object_tag));
				CALLAPI(AOM_refresh(object_tag,1));
				 CALLAPI(AOM_unlock(object_tag));
				 //PlantLCSFlag = "CAR";
				}


		}

	}
	if (DMLFlag == 0)
	{
		//API change
		if (RELSTAT_create_release_status(lifecycleStateName,&status_rel));
		if(RELSTAT_add_release_status(status_rel,1,&object_tag,retain));
	}
	//if (tc_strcmp(class_name,"Design_0_Revision_alt")==0 || tc_strcmp(class_name,"Design Revision")==0 || tc_strcmp(class_name,"T5_ClrPartRevision")==0) //Deepti TZ3.52
	if ((tc_strcmp(class_name,"T5_APLDMLRevision")!=0) && (tc_strcmp(class_name,"T5_APLTaskRevision")!=0) && (tc_strcmp(class_name,"T5_EPARevision")!=0) && (tc_strcmp(class_name,"T5_EPATaskRevision")!=0))
	{
		CALLAPI(WSOM_ask_effectivity_mode(&stat));

	//	getCurrentDateTime(cCurrentAccessDate);
	//API change
		//CALLAPI(PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag));
		//CALLAPI(PROP_ask_value_string(propEff_tag,&value)); 
		CALLAPI(AOM_ask_value_string(status_rel,"effectivity_text",&value));
		getNextDate(cNextDate);
		printf("\n cNextDate:%s",cNextDate);

		CALLAPI(ITK_string_to_date(cNextDate, &test_date_1 ));
		CALLAPI(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));

		start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

		printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

		start_end_date[0] = test_date_1;
		start_end_date[1] = test_date_2;

		CALLAPI(WSOM_status_clear_effectivities (status_rel));
		CALLAPI(WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
		CALLAPI(AOM_save_with_extensions(eff_d));
		CALLAPI(AOM_save_with_extensions(status_rel));
		CALLAPI(AOM_refresh(status_rel,0));

         // Start Privious Rev and stamp the close date
		 CALLAPI(AOM_ask_value_string(object_tag,"item_revision_id",&Part_Rev));
		 CALLAPI(AOM_ask_value_string(object_tag,"item_revision_id",&Part_Rev_copy));
		 printf("\n Part_Rev: %s", Part_Rev);fflush(stdout);
		 printf("\n Part_Rev_copy: %s", Part_Rev_copy);fflush(stdout);

		ITKCALL(AOM_ask_value_string(object_tag,"item_id",&Part_no));
		printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);
		Part_clr_ind	=	NULL;
		ITKCALL(AOM_ask_value_string(object_tag,"t5_ColourInd",&Part_clr_ind));
		printf("\n\n\t\t Part_clr_ind  is :%s",Part_clr_ind);	fflush(stdout);

		qry_entries[0] ="item_id";
		qry_entries[1] ="object_type";//Multiple Item Queried Error
		qry_values[0] = Part_no;
		if (tc_strcmp(Part_clr_ind,"C")==0)
		{
			qry_values[1] = "T5_ClrPart";//Multiple Item Queried Error Hemal
		}
		else
		{
			//qry_values[1] = "Design";//Multiple Item Queried Error Hemal
			//Handle the different design child class.
			char	*designBORev		=	NULL;
			char	*designBO			=	NULL;
			tag_t	AssyTag			=	NULLTAG;
			//AssyTag=PartTags[k];
			printf("\nBefore getDesignType");fflush(stdout);
			getDesignType(object_tag, &designBORev,&designBO);
			printf("\nAfter getDesignType : %s",designBO);fflush(stdout);
			qry_values[1] = designBO;

		}//Multiple Item Queried Error
		//ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclassp);
		ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found, &itemclassp);//Multiple Item Queried Error
		//ITKCALL(ITEM_find_item(Part_no,&itemclassp));
		item = itemclassp[0];

		CALLAPI(ITEM_list_all_revs (item, &Item_count, &rev_list));
		printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);
			if(Item_count > 0)
			{
				RevFlag = 0;
				PreRevFlag = 0;
				for(ii=Item_count-1;ii>=0;ii--)
				{
				   RevOnly = NULL;
				   PreRevOnly = NULL;
				   CALLAPI(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));
					printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);
					printf("\n Part_rev_Id: %s\n",Part_rev_Id);fflush(stdout);
					if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
					{
						RevFlag = 1;
					}
					printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
					if(RevFlag == 1)
					{
					   RevOnly= strtok( Part_Rev_copy, ";" );
					   PreRevOnly= strtok( Part_rev_Id, ";" );
					   printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
					   printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
					   if(tc_strcmp(RevOnly,PreRevOnly)!=0)
						{
						  PreRevFlag = 1;
						}
					}
					printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
					if(PreRevFlag == 1)
					{
						CALLAPI(WSOM_ask_release_status_list(rev_list[ii],&st_count,&status_list));
						if(st_count == 0)
						{
						printf("\n NO LCS Found for part : %d\n",st_count);fflush(stdout);
						break;
						}
						else
						{
							for (iLCS=0;iLCS<st_count ;iLCS++ )
							{
									CALLAPI(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
									printf("\n class_name: %s\n",class_name);fflush(stdout);
									//if(tc_strcmp(PlantLCSFlag,"CAR")==0)
									//{
									if(tc_strcmp(class_name,lifecycleStateName)==0)
									{
										getCurrentDateTime(cCurrentAccessDate);
										printf("\n Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);
										if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &Ltest_date_2 )))
										{
											return ifail;
										}
										if(ITK_ok != (ifail = WSOM_status_ask_effectivities (status_list[iLCS],&n_effectivities, &effectivities_tag) )) return ifail;
										printf("\n Eff:n_effectivities count:[%d] \n",n_effectivities);fflush(stdout);
										if(n_effectivities > 0)
										{
											for(jj=0;jj<n_effectivities;jj++)
											{
												//API change
												//if(ITK_ok != (ifail = WSOM_effectivity_ask_dates(effectivities_tag[jj],&n_dates,&Rel_start_end_values,&open_ended_or_stock_out )))return ifail;
												if(ITK_ok != (ifail =  WSOM_eff_ask_dates(status_list[jj],effectivities_tag[jj],&n_dates,&Rel_start_end_values,&open_ended_or_stock_out )))return ifail;

												printf("\n Eff:no of Rel_start_end_value:%d\n", n_dates);fflush(stdout);
												if(n_dates > 0)
												{
													if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
													{
														return ifail;
													}
													printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
													if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 )))
													{
														return ifail;
													}
													printf(" and  DATE_string_to_date_t..\n");fflush(stdout);
													if(date_is_valid != true)
													{
														printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
													}
													else
													{
														printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
													}
												}
												else
												{
													printf("\n EFF1:NO Eff date available, so setting closure date....");fflush(stdout);
												}
											}

											Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
											Lstart_end_date[0] = Ltest_date_1;
											Lstart_end_date[1] = Ltest_date_2;

											printf("\n ERCReview--EFF:Clearing effectivities...");fflush(stdout);
											if(ITK_ok != (ifail = WSOM_status_clear_effectivities (status_list[iLCS])))
											{
												return ifail;
											}

											printf("\n ERCReview--EFF:Creating effectivities...");fflush(stdout);
											if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_list[iLCS], NULLTAG, 2,Lstart_end_date, EFFECTIVITY_closed, &Leff_d )))
											{
												return ifail;
											}
											printf("\n ERCReview--EFF:Saving effectivities...");fflush(stdout);
											if(ITK_ok != (ifail = AOM_save_with_extensions(Leff_d)))
											{
												return ifail;
											}
											printf("\n ERCReview--EFF:Saving Revision...");fflush(stdout);
											if(ITK_ok != (ifail = AOM_save_with_extensions(status_list[iLCS])))
											{
												return ifail;
											}
											printf("\n ERCReview--EFF:Refreshing Revision...");fflush(stdout);
											if(ITK_ok != (ifail = AOM_refresh( status_list[iLCS], 0 )))
											{
												return ifail;
											}
										}
										
										break;

									}
							}
						printf("\n cntLcs inside : %d\n",cntLcs);fflush(stdout);
						break;
						}
					}  /// End Prev Rev  Flag Loop
				}
			} /// End Prev Rev

	}
		else if(tc_strcmp(class_name,"VariantRule")==0)
		{
			CALLAPI(WSOM_ask_effectivity_mode(&stat));

		//	getCurrentDateTime(cCurrentAccessDate);
		//API change
			//CALLAPI(PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag));
			//CALLAPI(PROP_ask_value_string(propEff_tag,&value));

			CALLAPI(AOM_ask_value_string(status_rel,"effectivity_text",&value));

			getNextDate(cNextDate);
			printf("\n cNextDate:%s",cNextDate);

			CALLAPI(ITK_string_to_date(cNextDate, &test_date_1 ));
			CALLAPI(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));

			start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

			printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

			start_end_date[0] = test_date_1;
			start_end_date[1] = test_date_2;

			CALLAPI(WSOM_status_clear_effectivities (status_rel));
			CALLAPI(WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
			CALLAPI(AOM_save_with_extensions(eff_d));
			CALLAPI(AOM_save_with_extensions(status_rel));
			CALLAPI(AOM_refresh(status_rel,0));
		}
	}

	return 0;
}

//static int t5UpdateLifecycleStateSTD(tag_t object_tag, char* lifecycleStateName, char* lcstoremove)
//{
//	int n_values_checkin = 0;
//	int cunt1 = 0;
//	int flag = 0;
//	int				ifail=0;
//	date_t *start_end_date = NULL;
//	tag_t eff_d = NULLTAG;
//	date_t test_date_1;
//	date_t test_date_2;
//	tag_t    	    propEff_tag				    =NULLTAG;
//    logical stat  ;
//	char*			value					=NULL;
//	char cNextDate[20]={0};
//
//	char *class_name = NULL;
//	char *Release_Status = NULL;
//
//	tag_t		class_id				=     NULLTAG;
//	tag_t		tReleaseStatusList_checkin=NULLTAG;
//	tag_t*		attr_tags_checkin		=	NULLTAG;
//	tag_t			status_rel					= NULLTAG;
//	tag_t*    status_list1=NULLTAG;
//	int              st_count1 = 0;
//	int				st_count_1 = 0;
//	int				DMLFlag =0;
//
//	tag_t*    status_list;
//	tag_t*    status_list_1=NULLTAG;
//	tag_t	*rev_list				= NULL;
//	int       ii=0;
//	int       RevFlag=0;
//	int       PreRevFlag=0;
//	int       st_count=0;
//	int Item_count      =  0;
//	char*			PreRevOnly				= NULL;
//	char*			RevOnly				= NULL;
//	char*			Part_Rev				= NULL;
//	char*			Part_Rev_copy				= NULL;
//	char*			Part_rev_Id				= NULL;
//	char*			PlantLCSFlag				= NULL;
//	int       iLCS=0;
//	int       cntLcs=0;
//	WSOM_open_ended_status_t  	open_ended_or_stock_out;
//	char cCurrentAccessDate[20]={0};
//	date_t Ltest_date_2;
//	date_t *Rel_start_end_values	= NULL;
//	int	n_dates 	= 0;
//	int	n_effectivities 		= 0;
//	int	jj 		= 0;
//    char	*old_to_date			= NULL;
//	logical date_is_valid  ;
//	date_t Ltest_date_1;
//	date_t *Lstart_end_date			= NULL;
//	tag_t	Leff_d				= NULLTAG;
//	tag_t	*effectivities_tag		= NULL;
//
//	logical		*is_it_null_checkin		=   NULL;
//	logical		*is_it_empty_checkin	=   NULL;
//	logical		log1;
//	logical		checkout1;
//	logical			retain							= 0;
//
//	char*			Part_no				= NULL;
//	char		   *WSO_Name	=	NULL;
//	const char *qry_entries[2];//Multiple Item Queried Error
//	const char *qry_values[2];//Multiple Item Queried Error
//	int n_tags_found=0;
//	tag_t	*itemclassp	= NULLTAG;
//	tag_t item = NULLTAG;
//	char	*Part_clr_ind	=	NULL;
//	printf("\n inside t5UpdateLifecycleStateSTD: [%s:%s]\n ",lifecycleStateName,lcstoremove);fflush(stdout);
//	ITKCALL(WSOM_ask_release_status_list(object_tag,&st_count_1,&status_list_1));         //**VB**
//	printf("\n st_count1 :%d is\n",st_count_1);fflush(stdout);
//	if(st_count_1>0)
//	{
//		//sun
//		tag_t attr = NULLTAG;
//        CALLAPI(POM_attr_id_of_attr( "release_status_list", "WorkspaceObject", &attr));//attri id tag
//		for (cnt=0;cnt< st_count_1;cnt++ )
//		{
//			//WSO_Name=NULL;
//			//ITKCALL(AOM_ask_name(status_list_1[cnt],&WSO_Name));
//			//printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
//			//sun
//			 char* name=NULL;
//            ITKCALL(AOM_ask_value_string(status_list_1[cnt], "name", &name));
//			printf("\n release status name is :%s\n",name);fflush(stdout);
//			 if(tc_strcmp(name,"T5_aborted")==0) 
//			{
//                    printf("\n Sunny Name = %s \n",name);fflush(stdout);
//                    tag_t status_to_delete = status_list_1[cnt];
//                    CALLAPI(POM_refresh_instances_any_class(1, &object_tag,POM_modify_lock));
//                    CALLAPI(POM_remove_from_attr(1, &object_tag,attr,cnt, 1));            
//                    logical unload = true; 
//                    CALLAPI(POM_save_instances(1, &object_tag,unload));                                              
//                    CALLAPI(POM_refresh_instances_any_class(1, &status_to_delete,POM_delete_lock));
//                    CALLAPI(POM_delete_instances(1,&status_to_delete));  
//			}
//			//sun end
//			if(tc_strcmp(name,"")!=0)
//			{
//				//if (tc_strcmp(WSO_Name,"T5_LcsSTDWrkg")==0)
//				if (tc_strcmp(name,lifecycleStateName)==0)
//				{
//					DMLFlag = 1;
//				}
//			}
//		}
//	}
//	if((strcmp(lcstoremove,"NA")==0 && DMLFlag == 0))
//	{
//		printf("\n Inside NA....");fflush(stdout);
//		//API change
//		if (RELSTAT_create_release_status(lifecycleStateName,&status_rel));
//		if(RELSTAT_add_release_status(status_rel,1,&object_tag,retain));
//	}
//else
//   {
//	CALLAPI(POM_class_of_instance(object_tag,&class_id));
//	CALLAPI(POM_name_of_class(class_id,&class_name));
//	printf("\n class_name is :%s\n",class_name);fflush(stdout);
//
//	CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
//	CALLAPI(WSOM_ask_release_status_list(object_tag,&st_count1,&status_list1));
//	printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);
//
//	CALLAPI(POM_unload_instances (1,&object_tag));
//	CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
//	CALLAPI(POM_is_loaded(object_tag,&log1));
//	if(log1 == 1)
//	{
//		 printf(" Load Success\n " );
//	}
//	else
//	printf("Load Failure\n"  );
//
//	CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin) );
//	printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
//	if(n_values_checkin>0)
//	{
//		CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
//		printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);
//        flag = 0;
//		for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
//		{
//			printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
//			if(AOM_ask_name(attr_tags_checkin[cunt1], &Release_Status));
//		   printf("\n  Release_Status changes done: for workspaceobject     %s\n", Release_Status);fflush(stdout);
//            if( (tc_strstr(lifecycleStateName,"T5_LcsStd")!=NULL) && (tc_strstr(lifecycleStateName,"Rlzd")!=NULL) )
//            {
//				if( (tc_strcmp(Release_Status,lcstoremove)==0))
//				{
//				CALLAPI(POM_unload_instances (1,&object_tag));
//				CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
//				CALLAPI(POM_is_loaded(object_tag,&log1));
//
//				//CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,flag,1));
//				CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,cunt1,1));
//				printf("\n cunt 1 == 0 removedd is :%d\n",cunt1);fflush(stdout);
//
//				CALLAPI(POM_save_instances(1,&object_tag,1));
//
//				CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));
//
//				CALLAPI(AOM_lock(object_tag));
//
//				CALLAPI(AOM_save_with_extensions(object_tag));
//				CALLAPI(AOM_refresh(object_tag,1));
//				 CALLAPI(AOM_unlock(object_tag));
//				 //PlantLCSFlag = "CAR";
//				}
//			}
//
//			if( (tc_strcmp(Release_Status,lifecycleStateName)==0))
//				{
//				CALLAPI(POM_unload_instances (1,&object_tag));
//				CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
//				CALLAPI(POM_is_loaded(object_tag,&log1));
//
//				//CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,flag,1));
//				CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,cunt1,1));
//				printf("\n cunt 1 == 0 removedd is :%d\n",cunt1);fflush(stdout);
//
//				CALLAPI(POM_save_instances(1,&object_tag,1));
//
//				CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));
//
//				CALLAPI(AOM_lock(object_tag));
//
//				CALLAPI(AOM_save_with_extensions(object_tag));
//				CALLAPI(AOM_refresh(object_tag,1));
//				 CALLAPI(AOM_unlock(object_tag));
//				 //PlantLCSFlag = "CAR";
//				}
//
//
//		}
//
//	}
//	if (DMLFlag == 0)
//	{
//		//API change
//		if (RELSTAT_create_release_status(lifecycleStateName,&status_rel));
//		if(RELSTAT_add_release_status(status_rel,1,&object_tag,retain));
//	}
//	//if (tc_strcmp(class_name,"Design_0_Revision_alt")==0 || tc_strcmp(class_name,"Design Revision")==0 || tc_strcmp(class_name,"T5_ClrPartRevision")==0) //Deepti TZ3.52
//	if ((tc_strcmp(class_name,"T5_APLDMLRevision")!=0) && (tc_strcmp(class_name,"T5_APLTaskRevision")!=0) && (tc_strcmp(class_name,"T5_EPARevision")!=0) && (tc_strcmp(class_name,"T5_EPATaskRevision")!=0))
//	{
//		CALLAPI(WSOM_ask_effectivity_mode(&stat));
//
//	//	getCurrentDateTime(cCurrentAccessDate);
//	//API change
//		//CALLAPI(PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag));
//		//CALLAPI(PROP_ask_value_string(propEff_tag,&value));
//
//		CALLAPI(AOM_ask_value_string(status_rel,"effectivity_text",&value));
//
//		getNextDate(cNextDate);
//		printf("\n cNextDate:%s",cNextDate);
//
//		CALLAPI(ITK_string_to_date(cNextDate, &test_date_1 ));
//		CALLAPI(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));
//
//		start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
//
//		printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");
//
//		start_end_date[0] = test_date_1;
//		start_end_date[1] = test_date_2;
//
//		CALLAPI(WSOM_status_clear_effectivities (status_rel));
//		CALLAPI(WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
//		CALLAPI(AOM_save_with_extensions(eff_d));
//		CALLAPI(AOM_save_with_extensions(status_rel));
//		CALLAPI(AOM_refresh(status_rel,0));
//
//         // Start Privious Rev and stamp the close date
//		 CALLAPI(AOM_ask_value_string(object_tag,"item_revision_id",&Part_Rev));
//		 CALLAPI(AOM_ask_value_string(object_tag,"item_revision_id",&Part_Rev_copy));
//		 printf("\n Part_Rev: %s", Part_Rev);fflush(stdout);
//		 printf("\n Part_Rev_copy: %s", Part_Rev_copy);fflush(stdout);
//
//		ITKCALL(AOM_ask_value_string(object_tag,"item_id",&Part_no));
//		printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);
//		Part_clr_ind	=	NULL;
//		ITKCALL(AOM_ask_value_string(object_tag,"t5_ColourInd",&Part_clr_ind));
//		printf("\n\n\t\t Part_clr_ind  is :%s",Part_clr_ind);	fflush(stdout);
//
//		qry_entries[0] ="item_id";
//		qry_entries[1] ="object_type";//Multiple Item Queried Error
//		qry_values[0] = Part_no;
//		if (tc_strcmp(Part_clr_ind,"C")==0)
//		{
//			qry_values[1] = "T5_ClrPart";//Multiple Item Queried Error Hemal
//		}
//		else
//		{
//			//qry_values[1] = "Design";//Multiple Item Queried Error Hemal
//			//Handle the different design child class.
//			char	*designBORev		=	NULL;
//			char	*designBO			=	NULL;
//			tag_t	AssyTag			=	NULLTAG;
//			//AssyTag=PartTags[k];
//			printf("\nBefore getDesignType");fflush(stdout);
//			getDesignType(object_tag, &designBORev,&designBO);
//			printf("\nAfter getDesignType : %s",designBO);fflush(stdout);
//			qry_values[1] = designBO;
//
//		}//Multiple Item Queried Error
//		//ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclassp);
//		ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found, &itemclassp);//Multiple Item Queried Error
//		//ITKCALL(ITEM_find_item(Part_no,&itemclassp));
//		item = itemclassp[0];
//
//		CALLAPI(ITEM_list_all_revs (item, &Item_count, &rev_list));
//		printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);
//			if(Item_count > 0)
//			{
//				RevFlag = 0;
//				PreRevFlag = 0;
//				for(ii=Item_count-1;ii>=0;ii--)
//				{
//				   RevOnly = NULL;
//				   PreRevOnly = NULL;
//				   CALLAPI(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));
//					printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);
//					printf("\n Part_rev_Id: %s\n",Part_rev_Id);fflush(stdout);
//					if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
//					{
//						RevFlag = 1;
//					}
//					printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
//					if(RevFlag == 1)
//					{
//					   RevOnly= strtok( Part_Rev_copy, ";" );
//					   PreRevOnly= strtok( Part_rev_Id, ";" );
//					   printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
//					   printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
//					   if(tc_strcmp(RevOnly,PreRevOnly)!=0)
//						{
//						  PreRevFlag = 1;
//						}
//					}
//					printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
//					if(PreRevFlag == 1)
//					{
//						CALLAPI(WSOM_ask_release_status_list(rev_list[ii],&st_count,&status_list));
//						if(st_count == 0)
//						{
//						printf("\n NO LCS Found for part : %d\n",st_count);fflush(stdout);
//						break;
//						}
//						else
//						{
//							for (iLCS=0;iLCS<st_count ;iLCS++ )
//							{
//									CALLAPI(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
//									printf("\n class_name: %s\n",class_name);fflush(stdout);
//									//if(tc_strcmp(PlantLCSFlag,"CAR")==0)
//									//{
//									if(tc_strcmp(class_name,lifecycleStateName)==0)
//									{
//										getCurrentDateTime(cCurrentAccessDate);
//										printf("\n Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);
//										if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &Ltest_date_2 )))
//										{
//											return ifail;
//										}
//										if(ITK_ok != (ifail = WSOM_status_ask_effectivities (status_list[iLCS],&n_effectivities, &effectivities_tag) )) return ifail; 
//										printf("\n Eff:n_effectivities count:[%d] \n",n_effectivities);fflush(stdout);
//										if(n_effectivities > 0)
//										{
//											for(jj=0;jj<n_effectivities;jj++)
//											{
//												//API changes
//												//if(ITK_ok != (ifail = WSOM_effectivity_ask_dates(effectivities_tag[jj],&n_dates,&Rel_start_end_values,&open_ended_or_stock_out )))return ifail;
//												if(ITK_ok != (ifail =  WSOM_eff_ask_dates(status_list[jj],effectivities_tag[jj],&n_dates,&Rel_start_end_values,&open_ended_or_stock_out )))return ifail;
//												printf("\n Eff:no of Rel_start_end_value:%d\n", n_dates);fflush(stdout);
//												if(n_dates > 0)
//												{
//													if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
//													{
//														return ifail;
//													}
//													printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
//													if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 )))
//													{
//														return ifail;
//													}
//													printf(" and  DATE_string_to_date_t..\n");fflush(stdout);
//													if(date_is_valid != true)
//													{
//														printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
//													}
//													else
//													{
//														printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
//													}
//												}
//												else
//												{
//													printf("\n EFF1:NO Eff date available, so setting closure date....");fflush(stdout);
//												}
//											}
//
//											Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
//											Lstart_end_date[0] = Ltest_date_1;
//											Lstart_end_date[1] = Ltest_date_2;
//
//											printf("\n ERCReview--EFF:Clearing effectivities...");fflush(stdout);
//											if(ITK_ok != (ifail = WSOM_status_clear_effectivities (status_list[iLCS])))
//											{
//												return ifail;
//											}
//
//											printf("\n ERCReview--EFF:Creating effectivities...");fflush(stdout);
//											if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_list[iLCS], NULLTAG, 2,Lstart_end_date, EFFECTIVITY_closed, &Leff_d )))
//											{
//												return ifail;
//											}
//											printf("\n ERCReview--EFF:Saving effectivities...");fflush(stdout);
//											if(ITK_ok != (ifail = AOM_save_with_extensions(Leff_d)))
//											{
//												return ifail;
//											}
//											printf("\n ERCReview--EFF:Saving Revision...");fflush(stdout);
//											if(ITK_ok != (ifail = AOM_save_with_extensions(status_list[iLCS])))
//											{
//												return ifail;
//											}
//											printf("\n ERCReview--EFF:Refreshing Revision...");fflush(stdout);
//											if(ITK_ok != (ifail = AOM_refresh( status_list[iLCS], 0 )))
//											{
//												return ifail;
//											}
//										}
//										
//										break;
//
//									}
//							}
//						printf("\n cntLcs inside : %d\n",cntLcs);fflush(stdout);
//						break;
//						}
//					}  /// End Prev Rev  Flag Loop
//				}
//			} /// End Prev Rev
//
//	}
//		else if(tc_strcmp(class_name,"VariantRule")==0)
//		{
//			CALLAPI(WSOM_ask_effectivity_mode(&stat));
//
//		//	getCurrentDateTime(cCurrentAccessDate);
//		//API change
//			//CALLAPI(PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag));
//			//CALLAPI(PROP_ask_value_string(propEff_tag,&value));
//
//			CALLAPI(AOM_ask_value_string(status_rel,"effectivity_text",&value));
//
//			getNextDate(cNextDate);
//			printf("\n cNextDate:%s",cNextDate);
//
//			CALLAPI(ITK_string_to_date(cNextDate, &test_date_1 ));
//			CALLAPI(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));
//
//			start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
//
//			printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");
//
//			start_end_date[0] = test_date_1;
//			start_end_date[1] = test_date_2;
//
//			CALLAPI(WSOM_status_clear_effectivities (status_rel));
//			CALLAPI(WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
//			CALLAPI(AOM_save_with_extensions(eff_d));
//			CALLAPI(AOM_save_with_extensions(status_rel));
//			CALLAPI(AOM_refresh(status_rel,0));
//		}
//	}
//
//	return 0;
//}
void getPlantwiseRevRule_std(char* DML_Plant_tok, char* RevRule, char* Cvalue)   //vishal function
{

	printf("********** Inside Function getPlantwiseRevRule *********");fflush(stdout);

	if(tc_strcmp(DML_Plant_tok,"APLA")==0)
	{
		tc_strcpy(RevRule,"STDA Released and Above");
		tc_strcpy(Cvalue,"AHD");
	}
	else if (tc_strcmp(DML_Plant_tok,"APLS")==0) // Added By Ketan // 22012026 // 
	{
		tc_strcpy(RevRule,"STDS Released and Above");
		tc_strcpy(Cvalue,"SND");
	}
	else if (tc_strcmp(DML_Plant_tok,"APLD")==0)
	{
		tc_strcpy(RevRule,"STDD Released and Above");
		tc_strcpy(Cvalue,"DWD");
	}
	else if (tc_strcmp(DML_Plant_tok,"APLC")==0)
	{
		tc_strcpy(RevRule,"STDC Released and Above");
		tc_strcpy(Cvalue,"CAR");
	}
	else if (tc_strcmp(DML_Plant_tok,"APLP")==0)
	{
		tc_strcpy(RevRule,"STDP Released and Above");
		tc_strcpy(Cvalue,"PUNE");
	}
	else if (tc_strcmp(DML_Plant_tok,"APLU")==0)
	{
		tc_strcpy(RevRule,"STDU Released and Above");
		tc_strcpy(Cvalue,"PNR");
	}
	else if (tc_strcmp(DML_Plant_tok,"APLL")==0)
	{
		tc_strcpy(RevRule,"STDL Released and Above");
		tc_strcpy(Cvalue,"LKO");
	}
	else if (tc_strcmp(DML_Plant_tok,"APLJ")==0)
	{
		tc_strcpy(RevRule,"STDJ Released and Above");
		tc_strcpy(Cvalue,"JSR");
	}
	else
	{
		printf("\n wrong plant type \n");fflush(stdout);
	}
    
    printf("\n RevRule:%s\n",RevRule);fflush(stdout);

    printf("********** Exiting Function getPlantwiseRevRule *********");fflush(stdout);

}

int tm_std_dml_assign( EPM_action_message_t msg )
{

		int   ifail				= 0;
		int	  noAttachment,t,n_attchs,i,m,noTaskAttachment,l;
		int  attype = 1;
		int  count = 1;
		int  TaskCnt = 1;
		tag_t			parent_task				=NULLTAG;
		tag_t			rootTask				=NULLTAG;
		tag_t			*attachments			=NULLTAG;
		tag_t			*Taskattachments			=NULLTAG;
		tag_t			item					=NULLTAG;
		tag_t			*Dml_Task_Tag					=NULLTAG;
	    tag_t DMLTag = NULLTAG;
	    tag_t			APLDMLRevTag		= NULLTAG;
	    tag_t*			TaskRevision		= NULLTAG;

		tag_t			*objTypeTagTask			= NULLTAG;
	    tag_t	relation_type,relation	,propTag	= NULLTAG;

		//GRM_relation_t			*secondary_objects	;
		tag_t			primary					=NULLTAG;
		tag_t			*secondary_objects					=NULLTAG;
		tag_t			remove					= NULLTAG;
		tag_t			user_tag				=NULLTAG;
		tag_t			job						= NULLTAG;
		tag_t		   Analystusertag			= NULLTAG;
     	tag_t			TaskRevTag			= NULLTAG;
		char		*job_name					= NULL;
		char		*job_name_new				= NULL;


		char*			parent_name				=NULL;
		char*			object_type				=NULL;
		char*			Analyst_name			=NULL;
		char*			DmlAnalyst_name			=NULL;

		char*			Dml_no					=NULL;
		char*			CurrentTask				=NULL;
		char*			TaskName				=NULL;
		char*			username				=NULL;
		char*			ImplbyTaskNo			=NULL;
		char*			token					=NULL;
		char*			Tasktoken					=NULL;
        char*			Dml_ecntype					=NULL;

		tag_t query_tag_Control_object = NULLTAG;
		tag_t* results_CO = NULLTAG;
		int entry_count_CO = 3;
		int num_found_CO = 0;
		int COIterator = 0;
		char* userid = NULL;
		char* Dml_no_dup = NULL;
		char* DML_Plant_tok = NULL;
		char* DML_No_tok = NULL;
		char* Cvalue = NULL;
		char* RevRuleInfo1 =NULL;
		char* entries_CO[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};
		char** values_CO = (char **) MEM_alloc(5 * sizeof(char *));
		if(QRY_find2("Control Objects...", &query_tag_Control_object));
		POM_get_user(&username,&user_tag);
		printf("\nStarting for username :%s....\n",username);fflush(stdout);
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		printf("\n tm_std_dml_assign \n"); fflush(stdout);
		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	   printf("\nCurrentTask:%s\n",CurrentTask);
		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		printf("\nParent Name:%s\n",parent_name);fflush(stdout);


			CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
			printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
			 if(noAttachment > 0)
			{
			   for(t=0;t<noAttachment;t++)
			   {
				   DMLTag = attachments[t];
				  AOM_ask_value_string(attachments[t],"object_type",&object_type);
				  printf("\n object_type is :%s\n",object_type);fflush(stdout);
     			  if(strcmp(object_type,"T5_APLDMLRevision")==0)
				  {
					CALLAPI(AOM_ask_value_string(attachments[t],"current_id",&Dml_no));
					printf("\n Dml_no is :%s\n",Dml_no);fflush(stdout);

					CALLAPI(AOM_ask_value_string(attachments[t],"current_id",&Dml_no_dup));
					printf("\n Dml_no_dup is :%s\n",Dml_no_dup);fflush(stdout);
					DML_No_tok = tc_strtok(Dml_no_dup,"_");
					printf("\n DML_No_tok is :%s\n",DML_No_tok);fflush(stdout);
					DML_Plant_tok = tc_strtok(NULL,"_");
					printf("\n DML_Plant_tok is :%s\n",DML_Plant_tok);fflush(stdout);
					CALLAPI(AOM_ask_value_string(attachments[t],"t5_EcnType",&Dml_ecntype));
                    printf("\n Dml_ecntype is :%s\n",Dml_ecntype);fflush(stdout);
					RevRuleInfo1=(char *) MEM_alloc(1 * sizeof(char *));
					Cvalue = (char *) MEM_alloc(1 * sizeof(char *));					
					getPlantwiseRevRule_std(DML_Plant_tok,RevRuleInfo1,Cvalue);
					printf("\n Cvalue : %s", Cvalue);fflush(stdout);
					
					if(query_tag_Control_object!= NULLTAG)
					{
						printf("\n inside control object ");fflush(stdout);
						values_CO[0]="AutoAssignAby";
						values_CO[1]=Cvalue;
						values_CO[2]="0";
						if (QRY_execute(query_tag_Control_object, entry_count_CO, entries_CO, values_CO, &num_found_CO, &results_CO));
						printf("\n num_found_CO found : %d", num_found_CO);fflush(stdout);
						CALLAPI(AOM_ask_value_string( results_CO[0], "t5_Userinfo1", &userid));
						printf("\n APL Abeyance User: %s\n",userid);fflush(stdout);
					}
					else{
						printf("\n control object is nulltag ");fflush(stdout);
					}

				   if (DMLTag != NULLTAG)
				    {
							int oldusrcount = 0;
							int PIterator = 0;
							tag_t* ParticipantsTag= NULLTAG;
							tag_t AnalystTag = NULLTAG;
							char* ParticipantName = NULL;
							int ParticipantFlag = 0;
							GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
							CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&count,&TaskRevision));
							printf("\n\n\t\t APL DML Cre:ERC DML to Task : %d",count);fflush(stdout);
						    for (TaskCnt=0;TaskCnt<count ;TaskCnt++)
							{
								ParticipantFlag = 0;
								TaskRevTag = TaskRevision[TaskCnt];
								CALLAPI(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
								printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
								CALLAPI(TCTYPE_find_type("Analyst", "Analyst", &AnalystTag));
								CALLAPI(PARTICIPANT_ask_participants(TaskRevTag, AnalystTag, &oldusrcount, &ParticipantsTag));
								for(PIterator=0;PIterator<oldusrcount;PIterator++)
								{
									printf("\n\n\t\t Checking for participants \n");fflush(stdout);
									CALLAPI(AOM_ask_value_string(ParticipantsTag[PIterator],"object_string",&ParticipantName));
									printf("\n\n\t\t ParticipantName is :%s",ParticipantName);fflush(stdout);
									if(tc_strcmp(ParticipantName,userid)==0)
									{
										ParticipantFlag++;
									}
								}
								printf("\n ParticipantFlag = %d \n",ParticipantFlag);fflush(stdout);
								if(strcmp(object_type,"T5_APLTaskRevision")==0)
								{
									if (tc_strcmp(Dml_ecntype,"TOODMLR")==0)
									{
									  printf("\n Dml_ecntype is too dml \n");fflush(stdout);								      
								      if(AssignSTDReviewer(TaskRevTag));
									}
									else
									{
										if(ParticipantFlag>0)
										{
											if(AssignSTDReviewer(TaskRevTag));
										}
										else{
											if(AssignSTDAnalyst(TaskRevTag));
											if(AssignSTDReviewer(TaskRevTag));
										}
									}
								}								  
								if (TaskRevTag != NULLTAG)
								{								
									tag_t                            TaskClosureDtAttrId=NULLTAG; 
									date_t                           Task_Release_date =NULLDATE;
									
									printf("\n Inside setting blank date");fflush(stdout);
									CALLAPI(AOM_lock(DMLTag));
									CALLAPI(POM_attr_id_of_attr("date_released","T5_APLDMLRevision",&TaskClosureDtAttrId));
									CALLAPI(AOM_refresh(DMLTag,TRUE));
									CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
									CALLAPI(POM_set_attr_date(1,&DMLTag,TaskClosureDtAttrId,Task_Release_date));

									CALLAPI(AOM_save_with_extensions(DMLTag)); //09/05
									CALLAPI(AOM_unlock(DMLTag));
									//CALLAPI(AOM_refresh(DMLTag,TRUE));
									CALLAPI(AOM_refresh(DMLTag,FALSE)); // Ketan Modified

									CALLAPI(AOM_lock(TaskRevTag));
									CALLAPI(POM_attr_id_of_attr("date_released","T5_APLTaskRevision",&TaskClosureDtAttrId));
									CALLAPI(AOM_refresh(TaskRevTag,TRUE));
									CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
									CALLAPI(POM_set_attr_date(1,&TaskRevTag,TaskClosureDtAttrId,Task_Release_date));
									CALLAPI(AOM_save_with_extensions(TaskRevTag)); //09/05
									CALLAPI(AOM_unlock(TaskRevTag));
									//CALLAPI(AOM_refresh(TaskRevTag,TRUE));
									CALLAPI(AOM_refresh(TaskRevTag,FALSE)); // Ketan Modified								
								}
							}
			        }
		       }
			 }
			}

		return ITK_ok;
}

int tm_std_task_assign( EPM_action_message_t msg )
{

		int   ifail				= 0;
		int	  noAttachment,t,n_attchs,i,m,noTaskAttachment,l;
		int  attype = 1;
		int  count = 1;
		int  TaskCnt = 1;
		tag_t			parent_task				=NULLTAG;
		tag_t			rootTask				=NULLTAG;
		tag_t			*attachments			=NULLTAG;
		tag_t			*Taskattachments			=NULLTAG;
		tag_t			item					=NULLTAG;
		tag_t			*Dml_Task_Tag					=NULLTAG;
	    tag_t TaskTag = NULLTAG;
	    tag_t			APLDMLRevTag		= NULLTAG;
	    tag_t*			TaskRevision		= NULLTAG;

		tag_t			*objTypeTagTask			= NULLTAG;
	    tag_t	relation_type,relation	,propTag	= NULLTAG;
		tag_t			primary					=NULLTAG;
		tag_t			*secondary_objects					=NULLTAG;
		tag_t			remove					= NULLTAG;
		tag_t			user_tag				=NULLTAG;
		tag_t			job						= NULLTAG;
		tag_t		   Analystusertag			= NULLTAG;
        char*			parent_name				=NULL;
		char*			object_type				=NULL;
		char*			Analyst_name			=NULL;
		char*			DmlAnalyst_name			=NULL;

		char*			Task_no					=NULL;
		char*			CurrentTask				=NULL;
		char*			username				=NULL;
		
		

		tag_t	qryTagCntrl =	NULLTAG;
	    int	control_number_found	=	0;
	    tag_t	*list_of_WSO_cntrl_tags	=	NULLTAG;
	    char    *qry_entryCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	    char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));
	    int     n_entryCntrl    = 3;

	   CALLAPI(QRY_find2("Control Objects...", &qryTagCntrl));
	   if (qryTagCntrl!=NULLTAG)
	   {
							
			qry_valuesCntrl[0]="TskAssignPlanner";
			qry_valuesCntrl[1]="TskAssignPlanner";
			qry_valuesCntrl[2]="0";
							
			CALLAPI(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &list_of_WSO_cntrl_tags));
			printf("\nNumber of control object found :%d",control_number_found);fflush(stdout);
	   }
	   if (control_number_found>0)
	   {
			POM_get_user(&username,&user_tag);
			printf("\nStarting for username :%s....\n",username);fflush(stdout);
			CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
			printf("\n tm_std_task_assign \n"); fflush(stdout);
			CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
		    printf("\nCurrentTask:%s\n",CurrentTask);
			CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
			printf("\nParent Name:%s\n",parent_name);fflush(stdout);

			CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
			printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
			if(noAttachment > 0)
			{
				for(t=0;t<noAttachment;t++)
				  {
					  TaskTag = attachments[t];
					  char*	Analyst		=NULL;
		              char*	ChangeSpec1	=NULL;
					  AOM_ask_value_string(TaskTag,"object_type",&object_type);
					  printf("\n object_type issss :%s\n",object_type);fflush(stdout);
					  if(strcmp(object_type,"T5_APLTaskRevision")==0)
					  {
						CALLAPI(AOM_ask_value_string(TaskTag,"current_id",&Task_no));
						CALLAPI(AOM_UIF_ask_value(TaskTag,"Analyst",&Analyst));
						CALLAPI(AOM_UIF_ask_value(TaskTag,"ChangeSpecialist1",&ChangeSpec1));
						printf("\n Task_no is :%s\n",Task_no);fflush(stdout);
						printf("\n Analyst is :%s\n",Analyst);fflush(stdout);
						printf("\n ChangeSpec1 is :%s\n",ChangeSpec1);fflush(stdout);
						if ((TaskTag != NULLTAG)&&(Analyst != NULL)&&(ChangeSpec1 != NULL))
						{
							if((tc_strstr(Analyst,"STD")==NULL)&&(tc_strstr(ChangeSpec1,"STD")==NULL))
							{
							   if(AssignSTDAnalyst(TaskTag));
							   if(AssignSTDReviewer(TaskTag));
								   
						
								tag_t                            TaskClosureDtAttrId=NULLTAG; 
								date_t                           Task_Release_date =NULLDATE;
							 
								printf("\n Inside setting blank date");fflush(stdout);
								CALLAPI(AOM_lock(TaskTag));
								CALLAPI(POM_attr_id_of_attr("date_released","T5_APLTaskRevision",&TaskClosureDtAttrId));
								CALLAPI(AOM_refresh(TaskTag,TRUE));
								CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
								CALLAPI(POM_set_attr_date(1,&TaskTag,TaskClosureDtAttrId,Task_Release_date));
								CALLAPI(AOM_save_with_extensions(TaskTag)); //09/05
								CALLAPI(AOM_unlock(TaskTag));
								//CALLAPI(AOM_refresh(TaskTag,TRUE));
								CALLAPI(AOM_refresh(TaskTag,FALSE)); // Ketan Modified
							}
							                    
			        }
			       }
		       }
			 }

	   }
			
 return ITK_ok;

}
//muskan
extern EPM_decision_t DLLAPI tm_Taskcountvalidation(EPM_rule_message_t msg)
{ 
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;
	char*			t5current_name				=NULL;
	logical			t5InProcess;
	char*			procedure_name				= NULL;
	tag_t			primary_obj_type_tag		= NULLTAG;
	char			*type_name1					= NULL;
	tag_t *attachments = NULLTAG;
	char *parent_name =NULL;
	tag_t tsk_dml_rel_type;
	int t;
	int Dmlname=0;
    int task_Count=0;
	tag_t taskLcmTag = NULLTAG;
	tag_t DMLTag = NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	tag_t   *TaskRevision = NULLTAG;
    tag_t *task_List = NULLTAG;
	tag_t Rel_Typ_tag = NULLTAG;
	tag_t rootTask =NULLTAG;
    int count=0;
	int count1=0;
	int countDML=0;
	EPM_decision_t decision = EPM_go;
	tag_t	relation_type = NULLTAG;
	char *dmlno_1=NULL;
 
    printf("\n in side function tm_Taskcountvalidation."); fflush(stdout);
    ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	  
	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&count,&attachments));
	printf("\n EPM_ask_attachments of :: %d",count);
    if(count > 0)
	 {
	     taskLcmTag = attachments[0];
	 }

	ITKCALL(TCTYPE_ask_object_type(taskLcmTag,&primary_obj_type_tag));
	ITKCALL(TCTYPE_ask_name2(primary_obj_type_tag, &type_name1));
	printf("\nDCR_attach_method-->Primary_object type_name is:%s",type_name1);fflush(stdout);
	/*
	if(strcmp(type_name1,"T5_APLTaskRevision")==0)
	 {
		ITKCALL(AOM_ask_value_string(taskLcmTag,"current_id",&t5current_name));
		printf("\n\n\t\t t5current_name is : %s",t5current_name);fflush(stdout);
 
        ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
	    ITKCALL(GRM_list_primary_objects_only(taskLcmTag,tsk_dml_rel_type,&countDML,&DMLRevision));
        printf("\n\t\t APL DML Revision from Task : %d",countDML); fflush(stdout);

   for(t=0;t<countDML;t++)
	{

		ITKCALL(AOM_UIF_ask_value(DMLRevision[0],"item_id",& dmlno_1));
		printf("\n dmlno_1s:%s",dmlno_1);fflush(stdout);
        DMLTag = DMLRevision[t];
		ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
		ITKCALL(GRM_list_secondary_objects_only(DMLTag,relation_type,&count1,&TaskRevision));
		printf("\n\n\t\t APL DML to Task : %d",count1);fflush(stdout);
		if(count1==1)
		 {
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_warning,ITK_err, "Selected task is not allowed to submit into the STDSI workflow.Please submit the dml into STDSI workflow,as their is only one task under the dml");
				decision = EPM_nogo;
		                    
		  }	
		  else{
				decision = EPM_go;
		        }

	    }
		  }	
		  

	
		else{
		    }
			*/

return decision;
}// muskan


extern EPM_decision_t DLLAPI tm_ChkdmlActiveinWF(EPM_rule_message_t msg)
{
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;
	char*			t5current_name				=NULL;
	logical			t5InProcess;
	char*			procedure_name				= NULL;
	tag_t			primary_obj_type_tag		= NULLTAG;
	char			*type_name1					= NULL;

	tag_t *attachments = NULLTAG;
	tag_t *parents = NULLTAG;
	tag_t DMLLcmTag = NULLTAG;
	tag_t Rel_tag = NULLTAG;
	int itemcount=0;
	tag_t *ItemDoc_tag = NULLTAG;
    tag_t task_tag =NULLTAG;
	char *TaskLcstate=NULL;
	char *Task_Number=NULL;
	tag_t	qryTagCntrl =	NULLTAG;
	int	control_number_found	=	0;
	tag_t	*list_of_WSO_cntrl_tags	=	NULLTAG;
	char    *qry_entryCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));
	int     n_entryCntrl    = 3;
	
	
	EPM_decision_t decision = EPM_go;
	int ifail=0,count=0,n_parents=0,i=0;


	ITKCALL(QRY_find2("Control Objects...", &qryTagCntrl));
	if (qryTagCntrl!=NULLTAG)
	 {
							
			qry_valuesCntrl[0]="ChkdmlActvInLC";
			qry_valuesCntrl[1]="ChkdmlActvInLC";
			qry_valuesCntrl[2]="0";
							
			ITKCALL(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &list_of_WSO_cntrl_tags));
			printf("\nNumber of control object found :%d",control_number_found);fflush(stdout);
	 }

	 if (control_number_found>0)
	 {
		 
		ITKCALL(EPM_ask_root_task(msg.task,&root_task));
		printf("\n in side function tm_ChkdmlActiveinWF."); fflush(stdout);

		ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
		printf("\nCurrentTask:%s\n",CurrentTask);
		tag_t rootTask =NULLTAG;
		char *parent_name =NULL;

		ITKCALL(EPM_ask_root_task(msg.task,&rootTask));

		ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	    printf("\nParent Name:%s\n",parent_name);fflush(stdout);

		ITKCALL(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
		printf("\n EPM_ask_attachments of :: %d",count);

		if(count > 0)
		{
			DMLLcmTag = attachments[0];
		}

		ITKCALL(TCTYPE_ask_object_type(DMLLcmTag,&primary_obj_type_tag));
		ITKCALL(TCTYPE_ask_name2(primary_obj_type_tag, &type_name1));
		printf("\nDCR_attach_method-->Primary_object type_name is:%s",type_name1);fflush(stdout);
		if(strcmp(type_name1,"T5_APLTaskRevision")==0)
		{
			ITKCALL(AOM_ask_value_string(DMLLcmTag,"current_id",&t5current_name));
			printf("\n\n\t\t t5current_name is : %s",t5current_name);fflush(stdout);

			ITKCALL(EPM_ask_active_job_for_target(DMLLcmTag,&n_parents,&parents));
			printf("\n EPM_ask_active_job_for_target------>%d\n",n_parents); fflush(stdout);
			if (n_parents > 0)
			{
				ITKCALL(EPM_ask_procedure_name2(parents[0],&procedure_name));
				printf("\n procedure_nameprocedure_name----->%s\n",procedure_name); fflush(stdout);
			}
			

			if (n_parents>1)
			{

				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_warning,ITK_err, "DML already submitted in Lifecycle ... You can not submit it again.. abort DML -check with PLM admin..");
				decision = EPM_nogo;
			
			}else
			{
				decision = EPM_go;
			}
		}else
		{
			decision = EPM_nogo;

		}
		

	 }else
	 {
		 decision = EPM_go;
	 }

							
	return decision;
}
//Indira

extern EPM_decision_t DLLAPI tm_ChkReleaseStatusValidation(EPM_rule_message_t msg)
{
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;
	char*			t5current_name				=NULL;
	tag_t			primary_obj_type_tag		= NULLTAG;
	char			*type_name1					= NULL;

	tag_t *attachments = NULLTAG;
	tag_t DMLLcmTag = NULLTAG;
	tag_t	qryTagCntrl =	NULLTAG;
	int	control_number_found	=	0;
	tag_t	*list_of_WSO_cntrl_tags	=	NULLTAG;
	char    *qry_entryCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));
	int     n_entryCntrl    = 3;
	
	
	//indira

	int st_count	= 0;
	int Statusflag	= 0;
	int cnt		= 0;
	tag_t	*status_list = NULLTAG;
	char* rel_status_Name	= NULL;
	char* relstatusinfo1	= NULL;
	char* relstatusinfo2	= NULL;
    char* relstatusinfo3	= NULL;
	char* relstatusinfo4	= NULL;
	char *apl_dr_status	    = NULL;
	char *dml_drstatus	    = NULL;

	
	EPM_decision_t decision = EPM_go;
	int count=0;


	ITKCALL(QRY_find2("Control Objects...", &qryTagCntrl));
	if (qryTagCntrl!=NULLTAG)
	 {
							
			qry_valuesCntrl[0]="ChkdmlActstdrelease";
			qry_valuesCntrl[1]="ChkdmlActstdrelease";
			qry_valuesCntrl[2]="0";
							
			ITKCALL(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &list_of_WSO_cntrl_tags));
			printf("\n indira Number of control object found1 :%d",control_number_found);fflush(stdout);
	 }

	 if (control_number_found > 0)
	 {
		ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags[0], "t5_Userinfo1", &relstatusinfo1));
		ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags[0], "t5_Userinfo2", &relstatusinfo2));
        ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags[0], "t5_Userinfo3", &relstatusinfo3));
		ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags[0], "t5_Userinfo4", &relstatusinfo4));

		printf("\n in side function relstatusinfo1 and relstatusinfo2222222222 relstatusinfo1 : %s , relstatusinfo2 : %s , relstatusinfo3: %s , relstatusinfo4:%s",relstatusinfo1,relstatusinfo2,relstatusinfo3,relstatusinfo4); fflush(stdout);
		ITKCALL(EPM_ask_root_task(msg.task,&root_task));
		printf("\n in side function tm_tsk_dml_release_status_valid."); fflush(stdout);

		ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
		printf("\nCurrentTask:%s\n",CurrentTask);
		tag_t rootTask =NULLTAG;
		char *parent_name =NULL;
		char *object_name=NULL;

		ITKCALL(EPM_ask_root_task(msg.task,&rootTask));

		ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	    printf("\nParent Name:%s\n",parent_name);fflush(stdout);

		ITKCALL(EPM_ask_attachments(root_task,EPM_target_attachment,&count,&attachments));
		printf("\n EPM_ask_attachments of :: %d",count);

		if(count > 0)
		{
			DMLLcmTag = attachments[0];
		}

		ITKCALL(TCTYPE_ask_object_type(DMLLcmTag,&primary_obj_type_tag));
		ITKCALL(TCTYPE_ask_name2(primary_obj_type_tag, &type_name1));
		printf("\nDCR_attach_method-->Primary_object type_name is:%s",type_name1);fflush(stdout);


						  
 //muskan 
        if(tc_strcmp(type_name1,"T5_APLDMLRevision")==0)

		{
			printf("\n I AM INSIDE"); fflush(stdout);
		 ITKCALL(AOM_ask_value_string(DMLLcmTag , "object_name", &object_name)); 
		printf("\n object_name : %s",object_name);fflush(stdout);

		ITKCALL(AOM_ask_value_string(DMLLcmTag , "t5_cDRstatus", &apl_dr_status)); 
		printf("\n apl_dr_status %s",apl_dr_status);fflush(stdout);
        }
	    
        //muskan

        //muskan
		if(tc_strcmp(type_name1,"T5_APLTaskRevision")==0)
		{
			tag_t	tsk_dml_rel_type		= NULLTAG;
			tag_t*	DMLRevision				= NULLTAG;
			tag_t	DMLRevTag				= NULLTAG;
			int count_DML				= 0;
			int j						= 0;

			ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
			if (tsk_dml_rel_type!=NULLTAG)
			{
			   ITK_CALL(GRM_list_primary_objects_only(DMLLcmTag,tsk_dml_rel_type,&count_DML,&DMLRevision));
			   printf("\n APL DML Revision from Task : %d",count_DML); fflush(stdout);

			   char *dml_item_id = NULL;
			   ITKCALL(AOM_ask_value_string(DMLRevision[0] , "item_id", &dml_item_id)); //  t5_cDRstatus
			   printf("\n dml_item_id : %s",dml_item_id);fflush(stdout);
			     
			   
			   ITKCALL(AOM_ask_value_string(DMLRevision[0] , "t5_cDRstatus", &dml_drstatus)); //  t5_cDRstatus
			   printf("\n dml_drstatus : %s",dml_drstatus);fflush(stdout);			   
			}
        }

		
		
		if((strcmp(type_name1,"T5_APLDMLRevision")==0) && ((tc_strcmp(apl_dr_status,"DR0")== 0) || (tc_strcmp(apl_dr_status,"DR1")== 0) ||  (tc_strcmp(apl_dr_status,"DR2")== 0) || (tc_strcmp(apl_dr_status,"DR3")== 0) || (tc_strcmp(apl_dr_status,"DR3P")== 0)))
		{
			printf("\n Inside T5_APLDMLRevision \n");fflush(stdout);

			ITKCALL(AOM_ask_value_string(DMLLcmTag,"current_id",&t5current_name));
			printf("\n\n\t\t t5current_name is : %s",t5current_name);fflush(stdout);
		
			ITKCALL(WSOM_ask_release_status_list(DMLLcmTag,&st_count,&status_list));
			printf("\nindira  st_count1 :%d \n",st_count);fflush(stdout);
		
			if(st_count>0)
			{
				for (cnt =0;cnt <st_count ; cnt++)
				{
					rel_status_Name=NULL;
					ITKCALL(AOM_ask_name(status_list[cnt],&rel_status_Name));
					printf("\n rel_status_Name is and cnt :%s : %d\n",rel_status_Name,cnt);fflush(stdout);
		
					if(tc_strcmp(rel_status_Name,"")!=0)
					{
						if ((tc_strstr(rel_status_Name,relstatusinfo1)!=NULL)&& (tc_strstr(rel_status_Name,relstatusinfo2)!=NULL)) 
						{
							printf("\n inside release status rel_status_Name is :%s\n",rel_status_Name);fflush(stdout);
							Statusflag = 1;
							break;
						}
						else if((tc_strstr(rel_status_Name,relstatusinfo3)!=NULL) && (tc_strstr(rel_status_Name,relstatusinfo4)!=NULL) )  //NEED TO ADD MUSKAN
						{
		                    printf("\n inside release status rel_status_Name is muskan validation :%s\n",rel_status_Name);fflush(stdout);
							Statusflag = 1;
							break;    
						}
					}
				}
			}
			else
			{
				printf("\n else indira  st_count1 :%d \n",st_count);fflush(stdout);
			}
		
			if (Statusflag > 0)
			{
				 EMH_clear_errors();
				 EMH_store_error_s1(EMH_severity_error,ITK_err, " Already submitted in Lifecycle or Release status is STDSI RELEASED, APL working ... You can not submit it again.. abort DML -check with PLM admin..");
			    decision = EPM_nogo;
			}
			else
			{
				printf("\n else decision indira  st_count1 :%d \n",st_count);fflush(stdout);
				decision = EPM_go;
			}
		}
		else if((strcmp(type_name1,"T5_APLTaskRevision")==0) && ((tc_strcmp(dml_drstatus,"DR0")== 0) || (tc_strcmp(dml_drstatus,"DR1")== 0) ||  (tc_strcmp(dml_drstatus,"DR2")== 0) || (tc_strcmp(dml_drstatus,"DR3")== 0) || (tc_strcmp(dml_drstatus,"DR3P")== 0)))
		{
			printf("\n Inside T5_APLTaskRevision \n");fflush(stdout);

			ITKCALL(AOM_ask_value_string(DMLLcmTag,"current_id",&t5current_name));
			printf("\n\n\t\t t5current_name is : %s",t5current_name);fflush(stdout);
		
			ITKCALL(WSOM_ask_release_status_list(DMLLcmTag,&st_count,&status_list));
			printf("\nindira  st_count1 :%d \n",st_count);fflush(stdout);
		
			if(st_count>0)
			{
				for (cnt =0;cnt <st_count ; cnt++)
				{
					rel_status_Name=NULL;
		
					ITKCALL(AOM_ask_name(status_list[cnt],&rel_status_Name));
					printf("\n rel_status_Name is and cnt :%s : %d\n",rel_status_Name,cnt);fflush(stdout);
		
					if(tc_strcmp(rel_status_Name,"")!=0)
					{
						if ((tc_strstr(rel_status_Name,relstatusinfo1)!=NULL)&& (tc_strstr(rel_status_Name,relstatusinfo2)!=NULL)) 
						{
							printf("\n inside release status rel_status_Name is :%s\n",rel_status_Name);fflush(stdout);
							Statusflag = 1;
							break;
						}
						else if((tc_strstr(rel_status_Name,relstatusinfo3)!=NULL) && (tc_strstr(rel_status_Name,relstatusinfo4)!=NULL) )  //NEED TO ADD MUSKAN
						{
		                    printf("\n inside release status rel_status_Name is muskan validation :%s\n",rel_status_Name);fflush(stdout);
							Statusflag = 1;
							break;    
						}
					}
				}
			}   
			else
			{
				printf("\n else indira  st_count1 :%d \n",st_count);fflush(stdout);
			}
			if (Statusflag > 0)
			{
				 EMH_clear_errors();
				 EMH_store_error_s1(EMH_severity_error,ITK_err, " Already submitted in Lifecycle or Release status is STDSI RELEASED, APL working ... You can not submit it again.. abort DML -check with PLM admin..");
			    decision = EPM_nogo;
			}
			else
			{
				 printf("\n else decision indira  st_count1 :%d \n",st_count);fflush(stdout);
				decision = EPM_go;
			}
		} 
		else
		{ 
			printf("\n muskan EPM_go done successfully :%d \n");fflush(stdout);
			decision = EPM_go;
		}
	 }
	 else
	 {
		 decision = EPM_go;
         printf("\n muskan 2 done successfully :%d \n");fflush(stdout);
	 }	
	 printf("\n final decision indira  st_count1 :%d \n",st_count);fflush(stdout);
	return decision;
}

int std_dml_claim( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *itemid 	   = NULL;
	char	*lcsStdwrkng							= NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;

	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	int              st_count1 = 0;
	int              cnt = 0;
	int              DMLFlag = 0;
	int              PartFlag = 0;

	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
	tag_t  CurrentRoleTag = NULLTAG;
	//API change
	char *roleName = NULL;
	//char       roleName[SA_name_size_c+1]  ;
	tag_t*    status_list1=NULLTAG;
	tag_t*    status_list1_assy=NULLTAG;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char *Part_Coated = NULL;
	char *Part_ColourInd = NULL;
	char *Part_Type = NULL;
	char **DesignGroupList;
	char *WSO_Name = NULL;
	//API change
	//char   type_name[TCTYPE_name_size_c+1];
	char   *type_name = NULL;
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	char RevisionRule[40];
	char ClosureRule[40];
	char BVR[40];
	char APLDmlPlnt[40];
	char STDDmlPlnt[40];

	tag_t			tsk_dml_rel_type    = NULLTAG;
	int countDml=0,djj=0;
	tag_t *DMLRevision = NULLTAG;
	tag_t			DMLRevTag			= NULLTAG;
	tag_t			class_id1			= NULLTAG;
	char *class_name1= NULL;
	char *DMLtype= NULL;


	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside std_dml_claim handler  111***************\n ");fflush(stdout);

	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}


	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n std_dml_claim1 \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);

	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n type_name changes done: for workspaceobject %s\n", type_name);fflush(stdout);
	}

	AOM_ask_value_string( DMLTag, "item_id", &itemid);
	printf("\n itemid : %s\n",itemid);

		char LcsStdWrkg[40];
		char LcsStdRlzd[40];

		GetPlantWiseRelStat(itemid,LcsStdWrkg,LcsStdRlzd);
		printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
		printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);

		//strcpy(lcsToset,"T5_LcsSTDWrkg");
		  strcpy(lcsToset,LcsStdWrkg);


	if(strcmp(type_name,"T5_APLTaskRevision")==0 || strcmp(CurrentTask,"Create EPA")==0)
	{
		    printf("\n inside class T5_APLTaskRevision......\n");fflush(stdout);
			AOM_ask_value_string( DMLTag, "item_id", &item_id);
			AOM_ask_value_string( DMLTag, "current_id", &DML_no);
			AOM_ask_value_strings(DMLTag,"t5_crdesigngroup",&num,&DesignGroupList);
			//AOM_ask_value_string(DMLTag,"t5_rlstype",&RlsType);
			AOM_ask_value_string( DMLTag, "t5_crdesigngroup", &Proj_Code);


			ITKCALL(WSOM_ask_release_status_list(DMLTag,&st_count1,&status_list1));
			printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

			if(st_count1>0)
			{
				for (cnt=0;cnt< st_count1;cnt++ )
				{
					WSO_Name=NULL;
					ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
					printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
					if(tc_strcmp(WSO_Name,"")!=0)
						{
							//if (tc_strcmp(WSO_Name,"T5_LcsSTDWrkg")==0)
							if (tc_strcmp(WSO_Name,LcsStdWrkg)==0)
							{
								DMLFlag = 1;
							}
						}
				}
			}

			if(DMLFlag == 0)
			{
				printf("\n DML: Inside Release status Creation \n");fflush(stdout);
				//API change
				CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
				CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
				printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
				CALLAPI(RELSTAT_add_release_status(status2,1,&DMLTag,retain));
			}
			
			//Deepti Added TZ1.53
			ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
			if (tsk_dml_rel_type!=NULLTAG)
			{
				ITKCALL(GRM_list_primary_objects_only(DMLTag,tsk_dml_rel_type,&countDml,&DMLRevision));
				printf("\n\t\t APL DML Revision from Task : %d",countDml); fflush(stdout);
			}


			for (djj=0;djj<countDml;djj++ )
			{
				DMLRevTag = DMLRevision[djj];

				ITKCALL(POM_class_of_instance(DMLRevTag,&class_id1));
				ITKCALL(POM_name_of_class(class_id1,&class_name1));
				printf("\n\t class_name found1 :%s",class_name1); fflush(stdout);

				if(tc_strcmp(class_name1,"T5_APLDMLRevision")==0)
				{
					ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_EcnType",&DMLtype));
					printf("\n\t APLDMLtype is :%s",DMLtype); fflush(stdout);
					break;
				}

			}

			//Deepti Added TZ1.53

			ITKCALL(SA_ask_current_role(&CurrentRoleTag));
			ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
			printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

			printf("\n Proj_Code : %s\n",Proj_Code);fflush(stdout);
			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n DML_no : %s\n",DML_no);fflush(stdout);
			printf("\n RlsType : %s\n",RlsType);fflush(stdout);
			printf("\n num is : %d\n",num);fflush(stdout);
			printf("\n Item created first time only with item_id \n");fflush(stdout);
			if (DMLTag != NULLTAG)
			 {
					
				if(tc_strcmp(DMLtype,"AMDML")!=0)
				{
					printf("\n Inside Test 1\n");fflush(stdout);
					PartCnt=0;
					getPlantDetailsAttr_Std(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency,RevisionRule,ClosureRule,BVR,APLDmlPlnt,STDDmlPlnt);//TZ1.41
					printf("\n PlantCS %s \n",PlantCS);
					printf("\n PlantOptCS %s \n",PlantOptCS);
					printf("\n PlantAgency %s \n",PlantIA);
					printf("\n PlantStore %s \n",PlantStore);
					printf("\n UserAgency %s \n",UserAgency);

					CALLAPI(AOM_ask_value_tags(DMLTag,"CMHasSolutionItem",&PartCnt,&PartTags));
					printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];

							PartFlag = 0;
							st_count1 = 0;
			            	ITKCALL(WSOM_ask_release_status_list(AssyTag,&st_count1,&status_list1_assy));
							printf("\n #######st_count1 :%d is\n",st_count1);fflush(stdout);

							if(st_count1>0)
							{
								for (cnt=0;cnt< st_count1;cnt++ )
								{
									WSO_Name=NULL;
									
									ITKCALL(AOM_ask_name(status_list1_assy[cnt],&WSO_Name));
									printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
									if(tc_strcmp(WSO_Name,"")!=0)
										{
											//if (tc_strcmp(WSO_Name,LcsStdWrkg)==0 )
											if (tc_strcmp(WSO_Name,LcsStdWrkg)==0 || tc_strcmp(WSO_Name,LcsStdRlzd)==0) // Added By Ketan TZ 1.76
											{
												printf("\n Release status matched. \n");fflush(stdout);
												PartFlag = 1;
											}
										}
								}
							}
							printf("\n #######PartFlag :%d is\n",PartFlag);fflush(stdout);
							if(PartFlag == 0)
							{
								printf("\n Part: Inside Release status Creation \n");fflush(stdout);
								//API change
								CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
								CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
								printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
								CALLAPI(RELSTAT_add_release_status(status2,1,&AssyTag,retain));
							}
						}
					}
				}	


				tag_t                            TaskClosureDtAttrId=NULLTAG; 
				date_t                           Task_Release_date =NULLDATE;

				CALLAPI(AOM_lock(DMLTag));
				CALLAPI(POM_attr_id_of_attr("date_released","T5_APLTaskRevision",&TaskClosureDtAttrId));
				CALLAPI(AOM_refresh(DMLTag,TRUE));
				CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
				CALLAPI(POM_set_attr_date(1,&DMLTag,TaskClosureDtAttrId,Task_Release_date));
				CALLAPI(AOM_save_with_extensions(DMLTag));
				CALLAPI(AOM_unlock(DMLTag));

			}


				


	}
	if(strcmp(type_name,"T5_APLTaskRevision")==0 || strcmp(CurrentTask,"Review the Changes")==0)
	{
   /********************** Gss 2.49 For Generating 35-36 Parts at reviewer Claim of APL Reviewer *****************/
   /********************** This need to  be implemented if required now it is moved to ERC *****************/
	}
	else
	   {
	     	printf("\n No proper class class T5_APLDMLRevision......\n");fflush(stdout);
	   }

	return error_code;
}




int AssignSTDAnalystPR(tag_t APLTaskRevT)
{
	char*			Task_no				= NULL;
	char*			Dsgn_Grp			= NULL;
	char*			Proj_Code			= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	char*			PLT_CodeS		= NULL;
	//char*			rolename			= NULL;
	//char*			userid				= NULL;
	char*			member_name				= NULL;
	char*			PRTaskCreator				= NULL;
	char*			type_namee				= NULL;

	//API change
	char *rolename = NULL;
	char *userid = NULL;
	//char			rolename[SA_name_size_c+1];
	//char				userid[SA_user_size_c+1];
	int   ifail				= 0;

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			*ParticipantRel			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	int				count		= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int				FlaggAssignAnalystPR					= 0;

	logical			flgRoleFnd			= false;
	tag_t	participant_type2	= NULLTAG;
	tag_t	participant_tag2	= NULLTAG;
	printf("\n Inside AssignSTDAnalystPR \n");

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *PltCodeFrmCntrl 	  = NULL;


	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_crdesigngroup",&Dsgn_Grp));
	CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_cprojectcode",&Proj_Code));
	printf("\n\n\t\t APL DML Cre:AssignSTDAnalystPR:Task_no  is :%s",Task_no);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignSTDAnalystPR:Dsgn_Grp  is :%s",Dsgn_Grp);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignSTDAnalystPR:Proj_Code  is :%s",Proj_Code);	fflush(stdout);

	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);

	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));

	//****************************TZ1.46****************************************//

			if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLPltInf";
				qry_valuesCntrl1[1]=PLT_Code;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{			
				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &PltCodeFrmCntrl);
				printf("\n PltCodeFrmCntrl: %s\n",PltCodeFrmCntrl);fflush(stdout);
				tc_strcpy(PLT_CodeS,PltCodeFrmCntrl);					
			}
			else
				{
				tc_strcpy(PLT_CodeS,"PUNE");
				}
				printf("\n PLT_CodeS: %s\n",PLT_CodeS);fflush(stdout);
				//****************************************************************//


	APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(APL_Plnr_Grp,"STD");
	tc_strcat(APL_Plnr_Grp,PLT_CodeS);


	//APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	//tc_strcpy(APL_Plnr_Grp,"STD");
	//tc_strcat(APL_Plnr_Grp,PLT_CodeS);
	printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);

	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));
	 if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\nNo of Role found in Group are :%d\n",num_of_roles);

	ITKCALL(AOM_UIF_ask_value(APLTaskRevT,"owning_user",&PRTaskCreator));
	printf("\n\n\t\t PRTaskCreator  is :%s",PRTaskCreator);fflush(stdout);


	flgRoleFnd=false;
	if(num_of_roles>0)
	{
		for (i=0;i<num_of_roles ;i++ )
		{
				CALLAPI(SA_ask_role_name2(role_tags[i],&rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);
				//if(strstr(rolename,"STD") && !strstr(rolename,"STD"))
				if( (tc_strstr(rolename,"STD")!=NULL) && (tc_strstr(rolename,"Analyst")!=NULL) && (tc_strstr(rolename,"Default")==NULL) )
				{
					printf("\nMatch Found\n");
				
						CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
						printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);
						if(num_of_members>0)
						{
							for (j=0;j<num_of_members ;j++  )
							{
								ITKCALL(AOM_ask_value_string(member_tags[j],"user_name",&member_name)!=ITK_ok);
								printf("\n member_name :[%s]\n",member_name);

								CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
								//API change
								CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
								printf("\nUser ID Name :[%s]\n",userid);
								printf("\n PRTaskCreator :[%s]\n",PRTaskCreator);
						
								if(tc_strstr(PRTaskCreator,member_name)!=NULL)
								{
									/*
									printf("\n Got same user ....\n");
									ITKCALL(EPM_get_participanttype ("Analyst",&participant_type2)!=ITK_ok);
									ITKCALL(EPM_create_participant(member_tags[j],participant_type2,&participant_tag2)!=ITK_ok);
									AOM_lock(APLTaskRevT);			
									ITKCALL(ITEM_rev_add_participant(APLTaskRevT,participant_tag2)!=ITK_ok);
									AOM_save_with_extensions(APLTaskRevT);
									AOM_unlock(APLTaskRevT);
									printf("\n AnalystPR Assigned..DoneXXXX\n");
									*/
									
									TCTYPE_find_type("Analyst", "Analyst", &participant_type);
									EPM_create_participant(member_tags[j], participant_type, &participant_tag);
									GRM_find_relation_type("HasParticipant", &relation_type);
									CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&count,&ParticipantRel));
									GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
									GRM_save_relation(relation);
									FlaggAssignAnalystPR=1;
									printf("\n TestParticipent Analyst PR Assigned..DoneXXXX\n");
									break;
								}
							}
						}
						
						if(FlaggAssignAnalystPR==1)
						{
							printf("\n FlaggAssignAnalystPR: 1 \n");
							break;
						}
			}
		}

		if(FlaggAssignAnalystPR==0)
		{
			printf("\n FlaggAssignAnalystPR: 0 \n");

			APL_Plnr_Grp = NULL;
			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"STD");
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,PLT_CodeS);
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,"Default");
			printf("\n Test Planner Group Name:[%s]\n",APL_Plnr_Grp);
			printf("\n Test Planner Group Name:[%s]\n",APL_Plnr_Grp);
			i=0;
			for (i=0;i<num_of_roles ;i++ )
			{
				CALLAPI(SA_ask_role_name2(role_tags[i],&rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);
				if(strstr(rolename,APL_Plnr_Grp))
				{
					printf("\n Got Default Group");
					CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
					printf("\n No of Group Members found in Group/Role are :%d\n",num_of_members);
					if(num_of_members>0)
					{
						for (j=0;j<num_of_members ;j++  )
						{
							/*
							ITKCALL(EPM_get_participanttype ("Analyst",&participant_type2)!=ITK_ok);
							ITKCALL(EPM_create_participant(member_tags[j],participant_type2,&participant_tag2)!=ITK_ok);
							AOM_lock(APLTaskRevT);			
							ITKCALL(ITEM_rev_add_participant(APLTaskRevT,participant_tag2)!=ITK_ok);
							AOM_save_with_extensions(APLTaskRevT);
							AOM_unlock(APLTaskRevT);
							printf("\n AnalystPR Assigned..DoneXXXX\n");
							*/
							
							CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
							//API change
							CALLAPI(SA_ask_user_identifier2(user_tag,&userid));
							printf("\nUser ID Name :[%s]\n",userid);
							TCTYPE_find_type("Analyst", "Analyst", &participant_type);
							EPM_create_participant(member_tags[j], participant_type, &participant_tag);
							GRM_find_relation_type("HasParticipant", &relation_type);
							CALLAPI(GRM_list_secondary_objects_only(APLTaskRevT,relation_type,&count,&ParticipantRel));
							printf("\n count :[%d]\n",count);
							//if(count == 0)
							//{
							GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							GRM_save_relation(relation);
							printf("\n TestParticipent Assigned..DoneXXXX\n");
							//}
							//else
							//{
							//printf("\n Already Assigned..DoneXXXX\n");
							//}
							
						}
					}

				}


			}

		}
	}
	return ITK_ok;
}





//int CheckforColBasicDMLReleaseSTD(int partCnt,tag_t	sTaskTag, tag_t* partsTags,char* lcsToset,char* SetStdRelErr)
int CheckforColBasicDMLReleaseSTD(int partCnt,tag_t	sTaskTag, tag_t* partsTags,char* lcsToset,char ***SetStdRelErr,int *icount) // added by dss 1.53
{

	int				ifail				=	ITK_ok;
	int				status				=	0;

	char*			type_name			=	NULL;
	char*			type_nameCH			=	NULL;
	char			*SubSyscd			= NULL;
	char*			t5Task_name			=	NULL;
	char*			inp_Tsk_no			=	NULL;
	char*			chldLcsRlzd			=	NULL;
	char*			NRRevEPASet			=	NULL;
	// Sagar Start TZ 1.52
	char*			TaskID	=	NULL;
	char*			tmp_TaskID	=	NULL;
	char*			NonColPrtDRStatus	=	NULL;
	char*			NonColPrt_Plant	=	NULL;
	char*			ColPrt_Plant	=	NULL;
	tag_t           Prt_Task_Rel_Typ =	NULLTAG;
	// Sagar End TZ 1.52

	char			*Rlztype			=	NULL;
	char			*NonColPrt			=	NULL;
	char			*ColPrtNo			=	NULL;//DEEPTI TZ3.52

	tag_t			tsk_dml_rel_type	=	NULLTAG;
	tag_t			APLDMLRevTag		=	NULLTAG;
	tag_t			ERCDMLRevTag		=	NULLTAG;
	tag_t			PartTag				=	NULLTAG;
	tag_t			objTypeTag			=	NULLTAG;
	tag_t			ChRDsgnTag			=	NULLTAG;
	tag_t			objTypeTagCH		=	NULLTAG;


	tag_t*			APLDMLRevision		=	NULLTAG;
	tag_t*			ERCDMLRevision		=	NULLTAG;	
	tag_t*			status_list			=	NULLTAG;
	tag_t			*list_of_WSO_cntrl_tags=NULLTAG;

	WSO_search_criteria_t  	criteria_Gcontrol;

	int countAPLDml			=	0;
	int countERCDml			=	0;	
	int j					=	0;
	int iPrt				=	0;
	int isColorDML			=	0;
	logical					is_latest;    
	int iChRItem			=	0;
	int iStCnt				=	0;
	int chkDnFlg			=	0;
	int	control_number_found= 0;
	int	cntCntrl= 0;
	int iCntl = 0;
	int TaskRlzFlg = 0;
	int cntFlag2 = 0;


	//if (!NRRevEPASet) MEM_free(NRRevEPASet);
	//NRRevEPASet=(char *)MEM_alloc(2000);
	//tc_strcpy(NRRevEPASet," ");


	printf("\n###########Inside CheckforColBasicDMLReleaseSTD###################\n");fflush(stdout);

	status = AOM_ask_value_string(sTaskTag,"current_name",&t5Task_name);

	CALLAPI(AOM_ask_value_string(sTaskTag,"item_id",&inp_Tsk_no));
	printf("\n\n\t\t inp_Tsk_no  is = %s",inp_Tsk_no);	fflush(stdout);

	// Sagar Start TZ 1.52
	TaskID = (char *)MEM_alloc(100);
	tc_strcpy(TaskID,inp_Tsk_no);
	
	tmp_TaskID = strtok(TaskID,"_");	
	tmp_TaskID = strtok(NULL,"_");	
	ColPrt_Plant = strtok(NULL,"_");
	printf("\n ColPrt_Plant = %s  \n",ColPrt_Plant);fflush(stdout);
	// Sagar End TZ 1.52

	//########Validation made control object based as in TCE#####//
	WSOM_clear_search_criteria(&criteria_Gcontrol);
	strcpy(criteria_Gcontrol.name,"BasicPrtRlsChk");
	strcpy(criteria_Gcontrol.class_name,"T5_ControlObject");
	status	= WSOM_search(criteria_Gcontrol, &control_number_found, &list_of_WSO_cntrl_tags);
	printf("\ncontrol_number_found = %d",control_number_found);fflush(stdout);
	if (control_number_found>0)
	{
		cntCntrl	=	0;
		for (iCntl=0;iCntl<control_number_found;iCntl++ )
		{
			AOM_ask_value_string( list_of_WSO_cntrl_tags[iCntl], "t5_SubSyscd", &SubSyscd);
			printf("\n\nSubSyscd = %s",SubSyscd);fflush(stdout);
			if ((tc_strcmp(SubSyscd,"Live")==0))
			{
				cntCntrl++;
				MEM_free(list_of_WSO_cntrl_tags);
				break;
			}
		}
	}

	printf("\n cntCntrl= %d",cntCntrl);fflush(stdout);
	//#############################################################//

	if(cntCntrl>0)
	{
		printf("\n Check to be executed as control object found");fflush(stdout);
	
		ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
		if (tsk_dml_rel_type!=NULLTAG)
		 {

			ITKCALL(GRM_list_primary_objects_only(sTaskTag,tsk_dml_rel_type,&countAPLDml,&APLDMLRevision));
			printf("\n\n\t\t DML Revision from Task = %d",countAPLDml);fflush(stdout);		//task to dml

			for (j=0;j<countAPLDml ;j++ )
			{
				ITKCALL(ITEM_rev_sequence_is_latest(APLDMLRevision[j],&is_latest));
				printf("\n\n\t\t is_latest = %d\n",is_latest);fflush(stdout);

				if(is_latest != true)
				{
					printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
				}else
				{
					APLDMLRevTag = APLDMLRevision[j];//DML

					// Sagar Start TZ 1.52
					ITKCALL(AOM_ask_value_string(APLDMLRevTag, "t5_rlstype",&Rlztype));
					printf("\n Rlztype = %s \n",Rlztype);fflush(stdout);								
					if ( (tc_strcmp(Rlztype,"Colour Part Release")==0) || (tc_strcmp(Rlztype,"Colour Modification Release")==0) || (tc_strcmp(Rlztype,"CP")==0)|| (tc_strcmp(Rlztype,"CM")==0))
					{
						isColorDML=1;
						printf("\n isColorDML = %d \n",isColorDML);fflush(stdout);
						break;
					}

					/*if (APLDMLRevTag!=NULLTAG)
					 {

						ITKCALL(GRM_list_primary_objects_only(APLDMLRevTag,tsk_dml_rel_type,&countERCDml,&ERCDMLRevision));
						printf("\n\n\t\t DML Revision from Task : %d",countERCDml);fflush(stdout);		//task to dml

						for (j=0;j<countERCDml ;j++ )
						{
							ITKCALL(ITEM_rev_sequence_is_latest(ERCDMLRevision[j],&is_latest));
							printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);

							if(is_latest != true)
							{
								printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
							}else
							{
								ERCDMLRevTag = ERCDMLRevision[j];//DML
								ITKCALL(AOM_ask_value_string(ERCDMLRevTag, "t5_rlstype",&Rlztype));
								printf("\n Rlztype %s.....\n",Rlztype);fflush(stdout);								
								if ( (tc_strcmp(Rlztype,"Colour Part Release")==0) || (tc_strcmp(Rlztype,"Colour Modification Release")==0) || (tc_strcmp(Rlztype,"CP")==0)|| (tc_strcmp(Rlztype,"CM")==0))
								{
									isColorDML=1;
									break;
								}
							}
						}
					 }*/ 
					// Sagar End TZ 1.52
				}
			}
		 }
		  if(isColorDML==1)
			{
			 
			  for (iPrt=0;iPrt<partCnt ;iPrt++ )
				{
				  printf("\niPrt : %d",iPrt);fflush(stdout);

					PartTag	=	partsTags[iPrt];
					ITKCALL(AOM_ask_value_string(PartTag, "t5_NcPartNo",&NonColPrt));
					printf("\n NonColPrt = %s\n",NonColPrt);fflush(stdout);
					
					ITKCALL(AOM_ask_value_string(PartTag, "item_id",&ColPrtNo));
					printf("\n ColPrtNo = %s\n",ColPrtNo);fflush(stdout);	//DEEPTI TZ3.52	

					//const char *qry_entries[2];//Multiple Item Queried Error
					//const char *qry_values[2];//Multiple Item Queried Error

					const char *qry_entries[1];//Multiple Item Queried Error	//Deepti TZ3.52
					const char *qry_values[1];//Multiple Item Queried Error	//Deepti TZ3.52

					int			n_tags_found=0;
					tag_t		*itemclass	=	NULLTAG;
					tag_t		item		=	NULLTAG;
								
					qry_entries[0] ="item_id";
					//qry_entries[1] ="object_type";//Multiple Item Queried Error	//Deepti TZ3.52
					qry_values[0] = NonColPrt;
					//qry_values[1] = "Design";//Multiple Item Queried Error	//Deepti TZ3.52

					//ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
					ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);//Multiple Item Queried Error
					if(n_tags_found>0)
					{
						item = itemclass[0];
						if(item != NULLTAG )
						{
							if(TCTYPE_ask_object_type(item,&objTypeTag));

							//Asks a type for its name. Return String, which need to free once used.
							if(TCTYPE_ask_name2(objTypeTag,&type_name));
							printf("\n\n\t\t AssyTag type_name = %s", type_name);fflush(stdout);

							//if (tc_strcmp(type_name,"Design Revision")==0 || tc_strcmp(type_name,"Design_0_Revision_alt")==0) //Deepti TZ3.52
							//{
								
										int	nCRItem			=	0;
										int	cntCldTask		=	0;
										int st_count		=	0;

										// Sagar Start TZ 1.52
										char *NonClr_TaskID = NULL;
										char *TaskID2 = NULL;
										char *tmp_TaskID2 = NULL;
										char *NonColPrt_Plant = NULL;
										int Tsk_count		=	0;
										int i = 0;
										tag_t *Tsk_list = NULLTAG;
										tag_t NonClr_Task = NULLTAG;
										// Sagar End TZ 1.52

										tag_t		*CRitem_revs_tag		=	NULLTAG;
										
										ITKCALL(AOM_ask_value_tags(item,"revision_list",&nCRItem,&CRitem_revs_tag));
										printf("\n No of Non-color Item revisions : %d",nCRItem);fflush(stdout);								
										
										for(iChRItem=nCRItem-1;iChRItem>=0;iChRItem--)
										{
											printf("\nNo of iChRItem : %d",iChRItem);fflush(stdout);
											ChRDsgnTag=NULLTAG;
											ChRDsgnTag	=	CRitem_revs_tag[iChRItem];
											
											objTypeTagCH=NULLTAG;
											if(TCTYPE_ask_object_type(ChRDsgnTag,&objTypeTagCH));

											//Asks a type for its name. Return String, which need to free once used.
											type_nameCH=NULL;
											if(TCTYPE_ask_name2(objTypeTagCH,&type_nameCH));
											printf("\n\n\t\t AssyTag type_nameCH := %s", type_nameCH);fflush(stdout);

											
											// Sagar Start TZ 1.52
											ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&Prt_Task_Rel_Typ));
											ITKCALL(GRM_list_primary_objects_only(ChRDsgnTag,Prt_Task_Rel_Typ,&Tsk_count,&Tsk_list));
											
											if (Tsk_count>0)
											{
												printf("\n Task count found for NonClor Part = %d ", Tsk_count);fflush(stdout);

												for(i=0;i<Tsk_count;i++)
												{
													NonClr_Task = NULLTAG;
													NonClr_Task = Tsk_list[i];
													
													ITKCALL(AOM_ask_value_string(NonClr_Task, "item_id",&NonClr_TaskID));
													printf("\n NonClr_TaskID %s.....\n",NonClr_TaskID);fflush(stdout);
													
													TaskID2 = (char *)MEM_alloc(100);
													tc_strcpy(TaskID2,NonClr_TaskID);
													printf("\n TaskID2 = %s\n",TaskID2);fflush(stdout);

													tmp_TaskID2 = strtok(TaskID2,"_");
													tmp_TaskID2 = strtok(NULL,"_");
													NonColPrt_Plant = strtok(NULL,"_");
													printf("\n NonColPrt_Plant = %s  \n",NonColPrt_Plant);fflush(stdout);

													if (tc_strcmp(ColPrt_Plant,NonColPrt_Plant)==0)
													{
														printf("\n Plant Matched for Color and NonColor Part \n");fflush(stdout);

														ITKCALL(AOM_ask_value_string(ChRDsgnTag, "t5_PartStatus",&NonColPrtDRStatus));
														printf("\n NonColPrt DR Status = %s \n",NonColPrtDRStatus);fflush(stdout);

														if ( (tc_strcmp(NonColPrtDRStatus,"DR3")==0) || (tc_strcmp(NonColPrtDRStatus,"AR3")==0) ||(tc_strcmp(NonColPrtDRStatus,"DR4")==0) || (tc_strcmp(NonColPrtDRStatus,"AR4")==0) || (tc_strcmp(NonColPrtDRStatus,"DR5")==0) || (tc_strcmp(NonColPrtDRStatus,"AR5")==0) || (tc_strcmp(NonColPrtDRStatus,"DR3P")==0) || (tc_strcmp(NonColPrtDRStatus,"AR3P")==0) )      // ...DR3 gate added TZ 1.81  
														{
															//if (tc_strcmp(type_nameCH,"Design_0_Revision_alt")==0 || tc_strcmp(type_nameCH,"Design Revision")==0 )	//Deepti TZ3.52
															//{											
															ITKCALL(WSOM_ask_release_status_list(ChRDsgnTag,&st_count,&status_list));
															printf("\n\n\t\t Child Status Count  is :%d",st_count);	fflush(stdout);
															if (st_count>0)
															{
																for (iStCnt=0;iStCnt<st_count ;iStCnt++ )// 	T5_LcsStdRlzd
																{
																	char* c_st_class_name	=	NULL;
																	ITKCALL(AOM_ask_value_string(status_list[iStCnt],"object_name",&c_st_class_name));
																	printf("\n c_st_class_name: %s:lcsToset %s\n",c_st_class_name,lcsToset);fflush(stdout);													
																	if( (tc_strcmp(c_st_class_name,lcsToset)==0) )
																	{
																		//if (!NRRevEPASet) MEM_free(NRRevEPASet);
//																		NRRevEPASet=NULL;
//																		NRRevEPASet=(char *)MEM_alloc(500);
//																		tc_strcpy(NRRevEPASet," ");
//
//																		printf("\n No Revision of non-colour %s is STDSI released",NonColPrt);fflush(stdout);
//																		if(chkDnFlg==0)
//																		{
//																			 tc_strcat(NRRevEPASet,"\n Following Basic Parts are Not Released by STDSI \n");																	 
//																			 chkDnFlg=1;
//																		}																	
//																		 
//																		 tc_strcat(NRRevEPASet,"Non-Colour part ");																 
//																		 tc_strcat(NRRevEPASet,NonColPrt);														
//																		 tc_strcat(NRRevEPASet," is not released from STDSI ");														
//																		 tc_strcat(NRRevEPASet,"\n");	
//																		 
//																		 setAddStrFuction(icount,SetStdRelErr,NRRevEPASet);
                                                              printf("\n Revision of Basic Part is found to be STDS released %s is STDSI released",NonColPrt);fflush(stdout);
																		 cntFlag2 = 1;

																		 break;
																		
																		

																	}
																}
															}
															else
															{
																printf("\n Non-Colour part has no status, so part is not released from any agency");fflush(stdout);
															}
															//}
														}
														else
														{
															printf("\n NonColPrt DR Status != DR4/AR4/DR5/AR5/DR3P/AR3P \n");fflush(stdout);
														}
													}
													else
													{
														printf("\n Plant Not Matched for Color and NonColor Part \n");fflush(stdout);
													}
												}
											}											
											// Sagar End TZ 1.52
										}

									if (cntFlag2==0)
										{


																	    NRRevEPASet=NULL;
																		NRRevEPASet=(char *)MEM_alloc(500);
																		tc_strcpy(NRRevEPASet," ");

																		printf("\n Nk Testing No Revision of non-colour %s is STDSI released",NonColPrt);fflush(stdout);
																		if(chkDnFlg==0)
																		{
																			 tc_strcat(NRRevEPASet,"\n Following Basic Parts are Not Released by STDSI \n");																	 
																			 chkDnFlg=1;
																		}																	
																		 
																		 tc_strcat(NRRevEPASet,"Non-Colour part ");																 
																		 tc_strcat(NRRevEPASet,NonColPrt);														
																		 tc_strcat(NRRevEPASet," is not released from STDSI ");														
																		 tc_strcat(NRRevEPASet,"\n");	
																		 
																		 setAddStrFuction(icount,SetStdRelErr,NRRevEPASet);
																		 cntFlag=1;

																		
										}
							//}
						}
					}
				}								

				
				printf("\n NRRevEPASet:%s cntFlag:%d",NRRevEPASet,cntFlag);fflush(stdout);
				
				/*
				if(strlen(NRRevEPASet)>10)
				{
					//tc_strcat(SetStdRelErr,NRRevEPASet);	
					setAddStrFuction(icount,SetStdRelErr,NRRevEPASet); // added by dss 1.53
					cntFlag = 1;
				}
				*/
			}
	}

	return 0;
}

//Sagar Start TZ 1.52
/******************************************************************************************************
FUNCTION	  : STDSIFindNxtRevPart.
DESCRIPTION	  : Check is to be provided which will not allow the Sign-off of a DML if next revision of part is LcsSTDRlzd
PASSED PARAMETERS : Task object to validate
******************************************************************************************************/
//int STDSIFindNxtRevPart(tag_t Task_tag,char *SetStdRelErr)
int STDSIFindNxtRevPart(tag_t Task_tag,char	***SetStdRelErr,int *icount) // added by dss 1.53
{
	int Part_Count = 0;
	int i = 0;
	int j = 0;
	int k = 0;
	int l = 0;
	int m = 0;
	int n = 0;
	int p = 0;
	int q = 0;
	int st_count = 0;
	int st_count2 = 0;
	int st_count3 = 0;
	int st_count4 = 0;
	int STD_Rlz_Flag = 0;
	int NxtRevTask_Count= 0;
	int NxtRevDML_Count = 0;
	int Task_STD_Rlz_Flag = 0;
	int AMDML_Count = 0;
	int AMDML_STD_Rlz_Flag = 0;
	int NextRevFlag = 0;
	int flagforAssmEpa = 0;


	char *TaskTypeName1 = NULL;
	char *TaskTypeName2 = NULL;
	char *TaskID = NULL;
	char *TaskID2 = NULL;
	char *TaskRevID = NULL;
	char *myPlant = NULL;
	char *TempPlant = NULL;
	char *tmp_TaskID = NULL;
	char *PartID = NULL;
	char *PartRevID = NULL;
	char *PartRlzStatusName = NULL;
	char *SkpPrevRev = NULL;
	char *NxtPartRevID = NULL;
	char *NxtPartRlzStatusName = NULL;
	char *NxtRevTaskID = NULL;
	char *NxtRevTaskID2 = NULL;
	char *NxtRevTaskRevID = NULL;
	char *tmp_NxtRevTaskID = NULL;
	char *NxtRev_EPAPlant = NULL;
	char *EPAPlant = NULL;
	char *NxtRev_myPlant = NULL;
	char *NxtRev_TempPlant = NULL;
	char *DML_Type = NULL;
	char *NxtRevDMLID = NULL;
	char *NxtRevDMLRevID = NULL;
	char *TaskRlzStatusName = NULL;
	char *Task_DtRlz = NULL;
	char *AMDMLID = NULL;
	char *AMDMLRevID = NULL;
	char *AMDMLRlzStatusName = NULL;
	char *AMDML_DtRlz = NULL;
	char *AMDML_ECNType = NULL;
	char *NxtRevMsg = NULL;
	char LcsStdWrkg[40];
	char LcsStdRlzd[40];
	

	tag_t TaskTypeTag1 = NULLTAG;
	tag_t TaskTypeTag2 = NULLTAG;
	tag_t Rel_Typ_tag = NULLTAG;
	tag_t *Part_List = NULLTAG;
    tag_t CurrentPart = NULLTAG;
	tag_t *PartRlzStatus = NULLTAG;
	tag_t NextRev = NULLTAG;
	tag_t *NxtPartRlzStatus = NULLTAG;
	tag_t Prt_Task_RelType_tag = NULLTAG;
	tag_t *NxtRevTask_Tag = NULLTAG;
	tag_t NxtRevTaskTag = NULLTAG;
	tag_t Rel_Typ_tag2 = NULLTAG;
	tag_t *NxtRevDML_tag = NULLTAG;
	tag_t NextRevDML = NULLTAG;
	tag_t DMLTypeTag = NULLTAG;
	tag_t *TaskRlzStatus = NULLTAG;
	tag_t *AMDML_tag = NULLTAG;
	tag_t AMDML = NULLTAG;
	tag_t *AMDMLRlzStatus = NULL;

	printf("\n In STDSIFindNxtRevPart()... \n");fflush(stdout);
	
	ITKCALL(TCTYPE_ask_object_type(Task_tag,&TaskTypeTag1));
	ITKCALL(TCTYPE_ask_name2(TaskTypeTag1,&TaskTypeName1));
	printf("\n TaskTypeName1 : %s   \n",TaskTypeName1);fflush(stdout);

	if(tc_strcmp(TaskTypeName1,"T5_APLTaskRevision")== 0)
	{
		printf("\n APL Task Found... \n");fflush(stdout);
		ITKCALL(AOM_ask_value_string(Task_tag,"item_id",&TaskID));
		ITKCALL(AOM_ask_value_string(Task_tag,"item_revision_id",&TaskRevID));
		printf("\n Task Name : %s / %s  \n",TaskID,TaskRevID);fflush(stdout);
		
		TaskID2 = (char *)MEM_alloc(100);
		tc_strcpy(TaskID2,TaskID);
		printf("\n TaskID2 = %s\n",TaskID2);fflush(stdout);

		tmp_TaskID = strtok(TaskID2,"_");
		tmp_TaskID = strtok(NULL,"_");
		myPlant = strtok(NULL,"_");
		printf("\n myPlant : %s  \n",myPlant);fflush(stdout);

		TempPlant = (char *)MEM_alloc(100);
		tc_strcpy(TempPlant,myPlant);

		printf("\n Plant found from Task Name is(TempPlant): %s\n",TempPlant);fflush(stdout);

		GetPlantWiseRelStat(TaskID,LcsStdWrkg,LcsStdRlzd);
		printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);fflush(stdout);
		printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);fflush(stdout);


		if ((tc_strstr(TaskID,"PP") != NULL) || (tc_strstr(TaskID,"PM") != NULL) || (tc_strstr(TaskID,"JP") != NULL) || (tc_strstr(TaskID,"JM") != NULL) || (tc_strstr(TaskID,"LP") != NULL) || (tc_strstr(TaskID,"LM") != NULL) || (tc_strstr(TaskID,"AM") != NULL))
		{
			ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&Rel_Typ_tag));  
			ITKCALL(GRM_list_secondary_objects_only(Task_tag, Rel_Typ_tag, &Part_Count,&Part_List)); 
			printf("\n Part_Count : %d\n",Part_Count);fflush(stdout);

			for(i=0;i<Part_Count;i++)
			{
				CurrentPart = Part_List[i];

				ITKCALL(AOM_ask_value_string(CurrentPart,"item_id",&PartID));
				ITKCALL(AOM_ask_value_string(CurrentPart,"item_revision_id",&PartRevID));
				printf("\n Part Number(CurrentPart) : %s/%s \n",PartID,PartRevID);fflush(stdout);
				ITKCALL(WSOM_ask_release_status_list(CurrentPart,&st_count,&PartRlzStatus));

				for(j=0;j<st_count;j++)
				{
					AOM_ask_name(PartRlzStatus[j], &PartRlzStatusName);
					printf("\n Part`s Release Status(CurrentPart) : %s \n",PartRlzStatusName);fflush(stdout);
				}

				//ITKCALL(AOM_ask_value_string(CurrentPart,"t5_SkipPrevRevSTD",&SkpPrevRev));
				//printf("\n t5_SkipPrevRevSTD (CurrentPart) : %s \n",SkpPrevRev);fflush(stdout);

				tm_FindNxtRev(PartID,CurrentPart,&NextRev);	//TZ 1.53

				if (NextRev != NULLTAG)
				{
					STD_Rlz_Flag = 0; //TZ 1.53
					printf("\n Next revision of part found \n");fflush(stdout);
					ITKCALL(AOM_ask_value_string(NextRev,"item_revision_id",&NxtPartRevID));
					printf("\n Part Number(NextRev) : %s/%s \n",PartID,NxtPartRevID);fflush(stdout);
					ITKCALL(WSOM_ask_release_status_list(NextRev,&st_count2,&NxtPartRlzStatus));
		            
					if (st_count2>0)
		            {
						printf("\n Number of status found on Next revision of part = %d\n",st_count2);fflush(stdout);
						for(k=0;k<st_count2;k++)
						{
							AOM_ask_name(NxtPartRlzStatus[k], &NxtPartRlzStatusName);
							printf("\n Part`s Release Status(NextRev) : %s \n",NxtPartRlzStatusName);fflush(stdout);

							if (tc_strcmp(NxtPartRlzStatusName,LcsStdRlzd)== 0)	//TZ 1.53
							{								
								STD_Rlz_Flag++;
								printf("\n STD_Rlz_Flag (NextRev) = %d ",STD_Rlz_Flag);fflush(stdout);
								printf("\n Next revision of part is STD Released \n");fflush(stdout);
								break;
							}
						}
		            }
					else
					{
						printf("\n No Status found on Next revision of part \n");fflush(stdout);
					}
					
					ITKCALL(GRM_find_relation_type("CMHasSolutionItem", &Prt_Task_RelType_tag));
					ITKCALL(GRM_list_primary_objects_only(NextRev,Prt_Task_RelType_tag,&NxtRevTask_Count,&NxtRevTask_Tag));
					printf("\n NxtRevTask_Count = %d ",NxtRevTask_Count);fflush(stdout);
					
					if (NxtRevTask_Count>0)
					{
						printf("\n Number of Tasks found for Next revision of part = %d\n",NxtRevTask_Count);fflush(stdout);
						
						for(q=0;q<NxtRevTask_Count;q++)
						{
							NxtRevTaskTag = NULLTAG;
							TaskTypeTag2 = NULLTAG;
							TaskTypeName2 = NULL;
							NxtRevTaskID = NULL;
							NxtRevTaskID2 = NULL;

							NxtRevTaskTag = NxtRevTask_Tag[q];
							if (NxtRevTaskTag!=NULLTAG)		//Added for Memory Handling
							{
								ITKCALL(TCTYPE_ask_object_type(NxtRevTaskTag,&TaskTypeTag2));
								
								if (TaskTypeTag2!=NULLTAG)	//Added for Memory Handling
								{
									ITKCALL(TCTYPE_ask_name2(TaskTypeTag2,&TaskTypeName2));
									printf("\n TaskTypeName2 : %s   \n",TaskTypeName2);fflush(stdout);

									if(tc_strcmp(TaskTypeName2,"T5_EPATaskRevision")== 0)
									{
										printf("\n EPA Task found for Next revision of part \n");fflush(stdout);

										ITKCALL(AOM_ask_value_string(NxtRevTaskTag,"item_id",&NxtRevTaskID));
										ITKCALL(AOM_ask_value_string(NxtRevTaskTag,"item_revision_id",&NxtRevTaskRevID));
										printf("\n EAP Task Name (NextRev): %s / %s  \n",NxtRevTaskID,NxtRevTaskRevID);fflush(stdout);
										
										NxtRevTaskID2 = (char*)malloc(100);
										tc_strcpy(NxtRevTaskID2,NxtRevTaskID);

										tmp_NxtRevTaskID = NULL;
										tmp_NxtRevTaskID = strtok(NxtRevTaskID2,"_");
										tmp_NxtRevTaskID = strtok(NULL,"_");
										NxtRev_EPAPlant = strtok(NULL,"_");
										printf("\n NxtRev_EPAPlant = %s  \n",NxtRev_EPAPlant);fflush(stdout);

										EPAPlant = (char*)malloc(100);
										tc_strcpy(EPAPlant,NxtRev_EPAPlant);
										printf("\n Compairing TempPlant: [%s] and EPAPlant: [%s] \n",TempPlant,EPAPlant);fflush(stdout);
										
										if (tc_strcmp(TempPlant,EPAPlant)== 0)
										{
											printf("\n EPA plant Matched for Next revision of part \n");fflush(stdout);
											flagforAssmEpa ++;
											break;
										}
										else
										{
											printf("\n EPA plant Not Matched for Next revision of part \n");fflush(stdout);
										}
									}
									else
									{
										printf("\n EPA Task Not found for Next revision of part \n");fflush(stdout);
									}
								}
							}
						}
					}


					if ( (STD_Rlz_Flag > 0) && (flagforAssmEpa ==0) )
					{
						printf("\n Next revision of part is STD Released with No EPA \n");fflush(stdout);

						GRM_find_relation_type("CMHasSolutionItem", &Prt_Task_RelType_tag);
						GRM_list_primary_objects_only(NextRev,Prt_Task_RelType_tag,&NxtRevTask_Count,&NxtRevTask_Tag);
						printf("\n NxtRevTask_Count = %d ",NxtRevTask_Count);fflush(stdout);
						
						if (NxtRevTask_Count>0)
						{
							printf("\n Task count for Next revision of part = %d\n",NxtRevTask_Count);fflush(stdout);
							
							for(l=0;l<NxtRevTask_Count;l++)
							{
								NxtRevTaskTag = NULLTAG;
								TaskTypeTag2 = NULLTAG;
								TaskTypeName2 = NULL;
								NxtRevTaskID = NULL;
								NxtRevTaskID2 = NULL;
								NextRevFlag = 0;

								NxtRevTaskTag = NxtRevTask_Tag[l];

								ITKCALL(TCTYPE_ask_object_type(NxtRevTaskTag,&TaskTypeTag2));
								ITKCALL(TCTYPE_ask_name2(TaskTypeTag2,&TaskTypeName2));
								printf("\n TaskTypeName2 : %s   \n",TaskTypeName2);fflush(stdout);

								if(tc_strcmp(TaskTypeName2,"T5_APLTaskRevision")== 0)
								{
									printf("\n APL Task Found for Next Rev of Part... \n");fflush(stdout);

									ITKCALL(AOM_ask_value_string(NxtRevTaskTag,"item_id",&NxtRevTaskID));
									ITKCALL(AOM_ask_value_string(NxtRevTaskTag,"item_revision_id",&NxtRevTaskRevID));
									printf("\n Task Name (NextRev): %s / %s  \n",NxtRevTaskID,NxtRevTaskRevID);fflush(stdout);
									
									NxtRevTaskID2 = (char*)malloc(100);
									tc_strcpy(NxtRevTaskID2,NxtRevTaskID);

									tmp_NxtRevTaskID = NULL;
									tmp_NxtRevTaskID = strtok(NxtRevTaskID2,"_");
									tmp_NxtRevTaskID = strtok(NULL,"_");
									NxtRev_myPlant = strtok(NULL,"_");
									printf("\n NxtRev_myPlant : %s  \n",NxtRev_myPlant);fflush(stdout);

									NxtRev_TempPlant = (char*)malloc(100);
									tc_strcpy(NxtRev_TempPlant,NxtRev_myPlant);
									printf("\n NxtRev_TempPlant : %s  \n",NxtRev_TempPlant);fflush(stdout);

									if ( (tc_strcmp(NxtRev_TempPlant,TempPlant) == 0) && ( (tc_strstr(NxtRevTaskID,"PP") != NULL) || (tc_strstr(NxtRevTaskID,"PM") != NULL) || (tc_strstr(NxtRevTaskID,"JP") != NULL) || (tc_strstr(NxtRevTaskID,"JM") != NULL) || (tc_strstr(NxtRevTaskID,"LP") != NULL) || (tc_strstr(NxtRevTaskID,"LM") != NULL) ) )
									{
										ITKCALL(WSOM_ask_release_status_list(NxtRevTaskTag,&st_count3,&TaskRlzStatus));
										printf("\n st_count3 (Task) = %d ",st_count3);fflush(stdout);
										
										if (st_count3>0)
										{
											for(n=0;n<st_count3;n++)
											{
												AOM_ask_name(TaskRlzStatus[n], &TaskRlzStatusName);
												printf("\n TaskRlzStatusName (NextRev) : %s \n",TaskRlzStatusName);fflush(stdout);

												if (tc_strcmp(TaskRlzStatusName,LcsStdRlzd)== 0)	//TZ 1.53
												{
													Task_STD_Rlz_Flag++;
													printf("\n Task_STD_Rlz_Flag = %d ",Task_STD_Rlz_Flag);fflush(stdout);
													printf("\n APL Task for Next Rev of Part is STD Released from same plant \n");fflush(stdout);
													break;
												}
											}
										}

										ITKCALL(AOM_UIF_ask_value(NxtRevTaskTag,"date_released",&Task_DtRlz));
										printf("\n Task_DtRlz (NextRev): %s   \n",Task_DtRlz);fflush(stdout);

										if ( (Task_STD_Rlz_Flag > 0) && (Task_DtRlz != NULL) )
										{
											NextRevFlag = 1;
											printf("\n NextRevFlag = %d ",NextRevFlag);fflush(stdout);
											printf("\n APL Task for Next Rev of Part is STD Released from same plant and has Released Dt. \n");fflush(stdout);
											break;
										}

									}
									else if( (tc_strcmp(NxtRev_TempPlant,TempPlant) == 0) &&  (tc_strstr(NxtRevTaskID,"AM") != NULL) )
									{
										GRM_find_relation_type("T5_DMLTaskRelation", &Rel_Typ_tag2);
										GRM_list_primary_objects_only(NxtRevTaskTag,Rel_Typ_tag2,&AMDML_Count,&AMDML_tag);   
										printf("\n AMDML_Count = %d",AMDML_Count);fflush(stdout);
										if (AMDML_Count>0)
										{
											for(n=0;n<AMDML_Count;n++)
											{
												AMDML = AMDML_tag[n];

												ITKCALL(AOM_ask_value_string(AMDML,"item_id",&AMDMLID));
												ITKCALL(AOM_ask_value_string(AMDML,"item_revision_id",&AMDMLRevID));
												printf("\n AM DML Name (NextRev): %s / %s  \n",AMDMLID,AMDMLRevID);fflush(stdout);

												ITKCALL(WSOM_ask_release_status_list(AMDML,&st_count4,&AMDMLRlzStatus));
												printf("\n st_count4 (AMDML) = %d ",st_count4);fflush(stdout);

												if (st_count4>0)
												{
													for(p=0;p<st_count4;p++)
													{
														AOM_ask_name(AMDMLRlzStatus[p], &AMDMLRlzStatusName);
														printf("\n AMDMLRlzStatusName (NextRev) : %s \n",AMDMLRlzStatusName);fflush(stdout);

														if (tc_strcmp(AMDMLRlzStatusName,LcsStdRlzd)== 0)	//TZ 1.53
														{
															AMDML_STD_Rlz_Flag++;
															printf("\n AMDML_STD_Rlz_Flag = %d ",AMDML_STD_Rlz_Flag);fflush(stdout);
															printf("\n AM DML for Next Rev of Part is STD Released from same plant \n");fflush(stdout);
															break;
														}
													}
												}

												ITKCALL(AOM_UIF_ask_value(AMDML,"date_released",&AMDML_DtRlz));
												printf("\n AMDML_DtRlz (NextRev): %s   \n",AMDML_DtRlz);fflush(stdout);

												ITKCALL(AOM_ask_value_string(AMDML,"t5_EcnType",&AMDML_ECNType));
												printf("\n AMDML_ECNType (NextRev): %s   \n",AMDML_ECNType);fflush(stdout);

												if ((tc_strcmp(AMDML_ECNType,"AMDML")!= 0))
												{
													printf("\n AMDML_ECNType != AMDML \n");fflush(stdout);

													if ( (AMDML_STD_Rlz_Flag > 0) && (AMDML_DtRlz != NULL) )
													{
														NextRevFlag = 1;
														printf("\n AM DML for Next Rev of Part is STD Released from same plant and has Released Dt.\n");fflush(stdout);
														break;
													}
												}
											}
										}
									}
								}
							}
						}

						if (NextRevFlag == 1)
						{
							//if (!NxtRevMsg) MEM_free(NxtRevMsg);
							NxtRevMsg	=	NULL;
							NxtRevMsg=(char *)MEM_alloc(500);		

							// Show Error Message
							printf("\n Next Official Revision of Below Parts exist Hence not allowed to Release DML of Old Revision\n");fflush(stdout);
							
							tc_strcpy(NxtRevMsg," ");
							tc_strcat(NxtRevMsg,"\n Next Official Revision of Below Parts exist Hence not allowed to Release DML of Old Revision\n");
							tc_strcat(NxtRevMsg,"Part No: ");
							tc_strcat(NxtRevMsg,PartID);
							tc_strcat(NxtRevMsg," Next Rev: ");
							tc_strcat(NxtRevMsg,NxtPartRevID);
							tc_strcat(NxtRevMsg," LCS:");
							tc_strcat(NxtRevMsg,NxtPartRlzStatusName);
							tc_strcat(NxtRevMsg," Next Rev Task: ");
							tc_strcat(NxtRevMsg,NxtRevTaskID);
							tc_strcat(NxtRevMsg,"\n");

							printf("\n NxtRevMsg = %s \n",NxtRevMsg);fflush(stdout);
							//tc_strcat(SetStdRelErr,NxtRevMsg);
							setAddStrFuction(icount,SetStdRelErr,NxtRevMsg); // added by dss 1.53
							cntFlag = 1;
							//setAddStrFuction(icount,SetStdRelErr,NxtRevMsg);							
						}
					}
				}
				else
				{
					printf("\n No next revision of part\n");fflush(stdout);
				}
			}
		}	
	}
	return 0;
}

/******************************************************************************************************
FUNCTION	  : GMDML_Prt_DR4_DR5_Check.
DESCRIPTION	  : Check is to be provided which will not allow the Sign-off of GM DML if:
				Case 1: Part DR4/5, No EPA, Task STD Rlz from same plant and has closure date. (Show Validation Error Msg)
				Case 2: Part DR4/5, Has EPA, EPA Task is STD Rlz but EPA is not Std Rlzd from same plant. (Show Validation Error Msg)
				Case 3: Part DR4/5, Has EPA, EPA Task and EPA both are Std Rlzd from same plant.
				Case 4: Part DR4/5, either EPA Task or NonEPA Task is Std Rlzd from same plant.
PASSED PARAMETERS : Part object to validate, Plant Name.
******************************************************************************************************/
//int GMDML_Prt_DR4_DR5_Check(tag_t Part_tag, char *InPlant,char *SetStdRelErr)
int GMDML_Prt_DR4_DR5_Check(tag_t Part_tag, char *InPlant,char *LcsStdRlzd,char ***SetStdRelErr,int *icount,int *Err_Flg)
{
	int i = 0;
	int j = 0;
	int k = 0;
	int l = 0;
	int Task_Count = 0;
	int No_EPA_Flag = 0;
	int EPA_Flag = 0;
	int st_count1 = 0;
	int st_count2 = 0;
	int Task_STD_Rlz_Flag = 0;
	int EPA_Count = 0;
	int EPA_STD_Rlz_Flag =0;
	int Task_Clsr_Flag =0;

	char *PartID = NULL;
	char *PartRevID = NULL;
	char *PartDRStatus = NULL;
	char *PartClrInd = NULL;
	char *TaskTypeName = NULL;
	char *TaskID = NULL;
	char *TaskID2 = NULL;
	char *TaskRevID = NULL;
	char *tmp_TaskID = NULL;
	char *EPAPlant = NULL;
	char *NonEPAPlant = NULL;
	char *TaskRlzStatusName = NULL;
	char *EPAType = NULL;
	char *EPAID = NULL;
	char *EPARlzStatusName = NULL;
	char *TaskClosureDt = NULL;
	char *PartDR4DR5Msg = NULL;

	//Added by Hemal start
	char	*Part_Rev_copy	=	NULL;
	char	*RevOnly		=	NULL;
	tag_t	t_prev_rev		=	NULLTAG;
	//Added by Hemal Ends

	tag_t Prt_Task_RelType_tag = NULLTAG;
	tag_t *Task_tag = NULLTAG;
	tag_t TaskTag = NULLTAG;
	tag_t TaskTypeTag = NULLTAG;
	tag_t *TaskRlzStatus = NULLTAG;
	tag_t Task_DML_RelType_tag = NULLTAG;
	tag_t *EPA_List = NULLTAG;
	tag_t EPATag = NULLTAG;
	tag_t *EPARlzStatus = NULLTAG;	

	printf("\n In GMDML_Prt_DR4_DR5_Check function... \n");fflush(stdout);
	printf("\n Value of Plant [%s]\n",InPlant);fflush(stdout);
	printf("\n LcsStdRlzd [%s]\n",LcsStdRlzd);fflush(stdout);	//TZ 1.53
	
	ITKCALL(AOM_ask_value_string(Part_tag,"item_id",&PartID));
	ITKCALL(AOM_ask_value_string(Part_tag,"item_revision_id",&PartRevID));
	ITKCALL(AOM_ask_value_string(Part_tag,"t5_PartStatus",&PartDRStatus));
	ITKCALL(AOM_ask_value_string(Part_tag,"t5_ColourInd",&PartClrInd));
	ITKCALL(AOM_ask_value_string(Part_tag,"item_revision_id",&Part_Rev_copy));
	printf("\n Part Number : %s / %s, DR Status: %s, Color Indicator: %s : Revision Copy\n",PartID,PartRevID,PartDRStatus,PartClrInd,Part_Rev_copy);fflush(stdout);
	
	//Below code is based on control object
	//Query the control object CLRCCVSTDCHLDRLZ
	
	char    *qry_entryCntrl1[3]  	= 	{"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1		= 	(char **) MEM_alloc(5 * sizeof(char *));
	tag_t	qryTagCntrl1			=	NULLTAG;
	int     n_entryCntrl1    		= 	3;
	int		control_number_found	=	0;
	tag_t	*list_of_WSO_cntrl_tags	=	NULLTAG;
	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	
	if (qryTagCntrl1!=NULLTAG)
	{
		
		printf("\ntm_chk_CLRCCVC_BOM_APLRLZ Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="STDGMDMLRLZ";
		qry_valuesCntrl1[1]="STDGMDMLRLZ";
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found, &list_of_WSO_cntrl_tags));
		printf("\ntm_chk_CLRCCVC_BOM_APLRLZ No. of control object found : %d",control_number_found);fflush(stdout);
		if (control_number_found>0)
		{
			if ( (tc_strcmp(PartDRStatus,"DR4")== 0) || (tc_strcmp(PartDRStatus,"AR4")== 0) || (tc_strcmp(PartDRStatus,"DR5")== 0) || (tc_strcmp(PartDRStatus,"AR5")== 0) || (tc_strcmp(PartDRStatus,"DR3P")== 0) || (tc_strcmp(PartDRStatus,"AR3P")== 0) )
			{
				printf("\n Part`s DR status is = DR4/AR4/DR5/AR5/DR3P/AR3P \n");fflush(stdout);
				
				Task_Count	=	0;
				if (Task_tag)
				{
					MEM_free(Task_tag);
				}
				Task_tag	=	NULLTAG;
				GRM_find_relation_type("CMHasSolutionItem", &Prt_Task_RelType_tag);
				GRM_list_primary_objects_only(Part_tag,Prt_Task_RelType_tag,&Task_Count,&Task_tag);
				printf("\n Task_Count = %d ",Task_Count);fflush(stdout);
				
				if (Task_Count>0)
				{
					Task_STD_Rlz_Flag = 0;	//TZ 1.53
					EPA_STD_Rlz_Flag = 0;	//TZ 1.53
					EPA_Flag = 0;
					for(i=0;i<Task_Count;i++)
					{
						TaskTag = Task_tag[i];
						TaskID2 = NULL;
						//Task_STD_Rlz_Flag = 0;	//TZ 1.53
						Task_Clsr_Flag = 0;
						//EPA_STD_Rlz_Flag = 0;		//TZ 1.53
						No_EPA_Flag = 0;
						

						ITKCALL(TCTYPE_ask_object_type(TaskTag,&TaskTypeTag));
						ITKCALL(TCTYPE_ask_name2(TaskTypeTag,&TaskTypeName));
						printf("\n TaskTypeName : %s   \n",TaskTypeName);fflush(stdout);
						printf("\n EPA counter : %d   \n",i);fflush(stdout);
						
						TaskID		=	NULL;
						TaskRevID	=	NULL;
						ITKCALL(AOM_ask_value_string(TaskTag,"item_id",&TaskID));
						ITKCALL(AOM_ask_value_string(TaskTag,"item_revision_id",&TaskRevID));

						if (tc_strcmp(TaskTypeName,"T5_EPATaskRevision")== 0)
						{					
							//EPA_Flag = 1; set value only plant matched
							printf("\n EPA Task Name : %s / %s  \n",TaskID,TaskRevID);fflush(stdout);
							if (TaskID2)
							{
								MEM_free(TaskID2);
							}
							TaskID2	=	NULL;
							TaskID2 = (char *)MEM_alloc(100);
							tc_strcpy(TaskID2,TaskID);
							printf("\n TaskID2 = %s\n",TaskID2);fflush(stdout);

							tmp_TaskID = strtok(TaskID2,"_");
							tmp_TaskID = strtok(NULL,"_");
							EPAPlant = strtok(NULL,"_");
							printf("\n EPAPlant : %s  \n",EPAPlant);fflush(stdout);

							if (tc_strcmp(InPlant,EPAPlant)==0)
							{
								EPA_Flag = 1;
								printf("\n EPA Plant Matched for EPA Task ...\n");fflush(stdout);
								printf("\n Finding EPA from EPA Task ...\n");fflush(stdout);
													

								GRM_find_relation_type("T5_DMLTaskRelation", &Task_DML_RelType_tag);
								EPA_Count	=	0;
								EPA_List	=	NULL;
								GRM_list_primary_objects_only(TaskTag,Task_DML_RelType_tag,&EPA_Count,&EPA_List);
								printf("\n EPA_Count = %d \n",EPA_Count);fflush(stdout);

								if (EPA_Count>0)
								{
									printf("\n EPA found from EPA Task ...\n");fflush(stdout);
									
									for(k=0;k<EPA_Count;k++)
									{
										EPATag	=	NULLTAG;
										EPATag = EPA_List[k];							
										
										EPAID	=	NULL;
										ITKCALL(AOM_ask_value_string(EPATag,"item_id",&EPAID));
										printf("\n EPAID (EPATag): %s   \n",EPAID);fflush(stdout);

										EPAType	=	NULL;
										ITKCALL(AOM_ask_value_string(EPATag,"t5_EpaType",&EPAType));
										printf("\n EPAType (EPATag): %s   \n",EPAType);fflush(stdout);
										
										st_count2	=	0;
										EPARlzStatus	=	NULL;
										ITKCALL(WSOM_ask_release_status_list(EPATag,&st_count2,&EPARlzStatus));
										printf("\n st_count2 (EPATag) = %d ",st_count1);fflush(stdout);

										if (st_count2>0)
										{
											for (l=0;l<st_count2;l++)
											{	
												EPARlzStatusName	=	NULL;
												AOM_ask_name(EPARlzStatus[l], &EPARlzStatusName);
												printf("\n EPARlzStatusName (EPATag) : %s \n",EPARlzStatusName);fflush(stdout);

												if (tc_strcmp(EPARlzStatusName,LcsStdRlzd)== 0)		//TZ 1.53
												{
													EPA_STD_Rlz_Flag = 1; // EPA is STD Rlzd from same plant			//TZ 1.53								
													printf("\n EPA is STD Rlzd from same plant \n");fflush(stdout);											
													break;
												}
												else
												{
													EPA_STD_Rlz_Flag = 0;					//TZ 1.53						
													printf("\n EPA is not STD Rlzd from same plant \n");fflush(stdout);
												}
											}
											
										}							
									}
									
									//if EPA is in working codition then fetch previous revision.
									//Below code has been commented as Not required to check previous revision as confirm by Nana Sir
									printf("\n EPA_STD_Rlz_Flag = %d ",EPA_STD_Rlz_Flag);fflush(stdout);
		//							if (EPA_STD_Rlz_Flag	==	0)
		//							{
		//								//calling recursive function
		//								RevOnly	= strtok( Part_Rev_copy, ";" );
		//								printf("\nEPA Working : %s,%s,%s",PartID,RevOnly,EPARlzStatusName);fflush(stdout);
		//								if (tc_strcmp(RevOnly,"NR")!=0)
		//								{
		//									t_prev_rev	=	NULLTAG;
		//									tm_fnd_Prev_Official_Revision(PartID,Part_tag, &t_prev_rev);
		//									if (t_prev_rev!=NULLTAG)
		//									{
		//										printf("\nWorking EPA...");fflush(stdout);
		//										break;
		//										//GMDML_Prt_DR4_DR5_Check(t_prev_rev, InPlant,LcsStdRlzd,SetStdRelErr,icount,Err_Flg);
		//									}
		//								}
		//							}//If condition ends
								}
								if (EPA_STD_Rlz_Flag == 1)
								{
									printf("\n EPA FAL IS RELEASED, SO BREAK THE LOOP...");fflush(stdout);
									break;
									//return 0;
								}
								/*if (EPA_Flag==0 && t_prev_rev!=NULLTAG)
								{
									GMDML_Prt_DR4_DR5_Check(t_prev_rev, InPlant,LcsStdRlzd,SetStdRelErr,icount,Err_Flg);
								}*/
							}
							else
							{
								printf("\n EPA Plant Not Matched...\n");fflush(stdout);
							}
							//if EPA is released then no need to check further, break the loop -- Need to check (because before release the EPA, DML must be release
							
						}
					}//EPA FOR LOOP ENDS
					//EPA Checking flag complete
						printf("\nEPA_Flag : %d ",EPA_Flag);fflush(stdout);
						if (EPA_Flag==0)
						{
							// EPA Not Found... Checking Task
							ITKCALL(AOM_ask_value_string(Part_tag,"item_id",&PartID));
							ITKCALL(AOM_ask_value_string(Part_tag,"item_revision_id",&PartRevID));
							printf("\nTask Part Number : %s, Revision : %s",PartID,PartRevID);fflush(stdout);
							
							Task_Count	=	0;
							Task_tag	=	NULLTAG;
							GRM_find_relation_type("CMHasSolutionItem", &Prt_Task_RelType_tag);
							
							GRM_list_primary_objects_only(Part_tag,Prt_Task_RelType_tag,&Task_Count,&Task_tag);
							printf("\n Task_Count = %d ",Task_Count);fflush(stdout);
							printf("\nInside Task part number : %s, Part revision : %s, Task Number : %s, Task_Count : %d",PartID,PartRevID,TaskID,Task_Count);fflush(stdout);
							i=0; // added by dss backend tz//
							No_EPA_Flag = 0; // added by dss backend tz//
							for(i=0;i<Task_Count;i++)
							{
								// added by dss backend tz//
								TaskTag = NULLTAG;
								TaskTag = Task_tag[i];
																
								ITKCALL(TCTYPE_ask_object_type(TaskTag,&TaskTypeTag));
								ITKCALL(TCTYPE_ask_name2(TaskTypeTag,&TaskTypeName));
								printf("\n TaskTypeName : %s   \n",TaskTypeName);fflush(stdout);
								printf("\n nonEPA counter : %d   \n",i);fflush(stdout);
								
								TaskID		=	NULL;
								TaskRevID	=	NULL;
								ITKCALL(AOM_ask_value_string(TaskTag,"item_id",&TaskID));
								ITKCALL(AOM_ask_value_string(TaskTag,"item_revision_id",&TaskRevID));
								// end of code added by dss backend tz//
								printf("\n TASK  counter : %d   \n",i);fflush(stdout);
								if (tc_strcmp(TaskTypeName,"T5_APLTaskRevision")== 0)
								{
									printf("\n EPA Not Found, checking Task\n");fflush(stdout);
									No_EPA_Flag = 1;
									printf("\n No_EPA_Flag = %d ",No_EPA_Flag);fflush(stdout);
									
									TaskID2	=	NULL;
									TaskID2 = (char *)MEM_alloc(100);
									tc_strcpy(TaskID2,TaskID);
									printf("\n TaskID2 = %s\n",TaskID2);fflush(stdout);

									tmp_TaskID = strtok(TaskID2,"_");
									tmp_TaskID = strtok(NULL,"_");
									NonEPAPlant = strtok(NULL,"_");
									printf("\n NonEPAPlant : %s  \n",NonEPAPlant);fflush(stdout);

									if (tc_strcmp(InPlant,NonEPAPlant)==0)
									{
										printf("\n Plant Matched for NONEPA Task...\n");fflush(stdout);
										ITKCALL(WSOM_ask_release_status_list(TaskTag,&st_count1,&TaskRlzStatus));
										printf("\n st_count1 (TaskTag) = %d ",st_count1);fflush(stdout);
										
										if (st_count1>0)
										{
											for(j=0;j<st_count1;j++)
											{
												AOM_ask_name(TaskRlzStatus[j], &TaskRlzStatusName);
												printf("\n TaskRlzStatusName (TaskTag) : %s \n",TaskRlzStatusName);fflush(stdout);

												ITKCALL(AOM_UIF_ask_value(TaskTag,"date_released",&TaskClosureDt));
												printf("\n Task`s date_released (TaskTag): %s   \n",TaskClosureDt);fflush(stdout);

												if ( (tc_strcmp(TaskRlzStatusName,LcsStdRlzd)== 0) && (tc_strlen(TaskClosureDt)>0))	// TZ 1.53
												{			
													Task_STD_Rlz_Flag = 1; // Task (NonEPATask) is STD Rlzd from same plant 		// TZ 1.53							
													printf("\n Task (NonEPATask) is STD Rlzd from same plant \n");fflush(stdout);										
													break;																	
												}
												else
												{											
													printf("\n Task (NonEPATask) is not STD Rlzd from same plant \n");fflush(stdout);
												}
											}
											printf("\n Task_STD_Rlz_Flag = %d ",Task_STD_Rlz_Flag);fflush(stdout);
										}		
																
									}
									else
									{
										printf("\n Plant Not Matched...\n");fflush(stdout);
									}
								}

								if (Task_STD_Rlz_Flag == 1)
								{
									printf("\n Task_STD_Rlz_Flag = 1  .... Breaking Task for loop...\n");fflush(stdout);
									break;
									//return 0;
								}
							}
						}
						
						
					//}
				}

				if (!PartDR4DR5Msg) MEM_free(PartDR4DR5Msg);
				PartDR4DR5Msg=(char *)MEM_alloc(2000);
				tc_strcpy(PartDR4DR5Msg," ");		
				
				*Err_Flg = 0;
				printf("\n Outer Task_STD_Rlz_Flag = %d and No_EPA_Flag = %d",Task_STD_Rlz_Flag,No_EPA_Flag);fflush(stdout);	//TZ 1.53
				printf("\n Outer EPA_STD_Rlz_Flag = %d and EPA_Flag = %d ",EPA_STD_Rlz_Flag,EPA_Flag);fflush(stdout);		//TZ 1.53
				if (EPA_Flag == 1 && EPA_STD_Rlz_Flag == 0)   // Case 3: Part DR4/5, Has EPA, and EPA is Std Rlzd from same plant.	//TZ 1.53
				{
					printf("\n Part is having DR status >= DR4/AR4, Has EPA, and EPA is Std Working from same plant\n");fflush(stdout);
				}
				else if ((Task_STD_Rlz_Flag == 1) && (No_EPA_Flag == 1))  // Case 4: Part DR4/5, NonEPA Task is Std Rlzd from same plant.	//TZ 1.53
				{
					printf("\n Part is having DR status >= DR4/AR4, NonEPA Task is Std Rlzd from same plant\n");fflush(stdout);
				}
				else if ( (Task_STD_Rlz_Flag == 0) && (No_EPA_Flag == 1) )  // Case 1: Part DR4/5, No EPA, and NONEPA Task is not STD Rlz from same plant .	//TZ 1.53
				{
					printf("\n Printing Non-EPA Task Error ...\n");fflush(stdout);	//TZ 1.53
					//Show Validation Message
					if ( (tc_strcmp(PartClrInd,"C")== 0) )
					{
						tc_strcat(PartDR4DR5Msg,"\n Color Part No: ");
						tc_strcat(PartDR4DR5Msg,PartID);
						tc_strcat(PartDR4DR5Msg,"/");
						tc_strcat(PartDR4DR5Msg,PartRevID);
						tc_strcat(PartDR4DR5Msg," which is not STDSI released, DML No: ");
						tc_strcat(PartDR4DR5Msg,TaskID);
						tc_strcat(PartDR4DR5Msg,". Released through Connected DML/PR Task. \n");

						printf("\n PartDR4DR5Msg = %s \n",PartDR4DR5Msg);fflush(stdout);
						cntFlag = 1;
						*Err_Flg = 1;
						//tc_strcat(SetStdRelErr,PartDR4DR5Msg);
						setAddStrFuction(icount,SetStdRelErr,PartDR4DR5Msg);
					}
					else
					{
						tc_strcat(PartDR4DR5Msg,"\n Non-Color Part No: ");
						tc_strcat(PartDR4DR5Msg,PartID);
						tc_strcat(PartDR4DR5Msg,"/");
						tc_strcat(PartDR4DR5Msg,PartRevID);
						tc_strcat(PartDR4DR5Msg," which is not STDSI released, DML No: ");
						tc_strcat(PartDR4DR5Msg,TaskID);
						tc_strcat(PartDR4DR5Msg,". Released through AMDML/Connected DML. \n");

						printf("\n PartDR4DR5Msg = %s \n",PartDR4DR5Msg);fflush(stdout);
						cntFlag = 1;
						*Err_Flg = 1;
						//tc_strcat(SetStdRelErr,PartDR4DR5Msg);
						setAddStrFuction(icount,SetStdRelErr,PartDR4DR5Msg);
					}		
				}
				else if ( (EPA_STD_Rlz_Flag == 0) && (EPA_Flag == 1))  // Case 2: Part DR4/5, Has EPA, but EPA is not STD Rlzd from same plant.		//TZ 1.53
				{
		//			printf("\n Printing EPA Task Error ...\n");fflush(stdout);
		//			//Show Validation Message
		//			if ( (tc_strcmp(PartClrInd,"C")== 0) )
		//			{
		//				tc_strcat(PartDR4DR5Msg,"\n Color Part No: ");
		//				tc_strcat(PartDR4DR5Msg,PartID);
		//				tc_strcat(PartDR4DR5Msg,"/");
		//				tc_strcat(PartDR4DR5Msg,PartRevID);
		//				tc_strcat(PartDR4DR5Msg," which is not STDSI released, DML No: ");
		//				tc_strcat(PartDR4DR5Msg,EPAID);
		//				tc_strcat(PartDR4DR5Msg,". Released through Connected DML/PR Task. \n");
		//
		//				printf("\n PartDR4DR5Msg = %s \n",PartDR4DR5Msg);fflush(stdout);
		//				cntFlag = 1;
		//				*Err_Flg = 1;
		//				//tc_strcat(SetStdRelErr,PartDR4DR5Msg);
		//				setAddStrFuction(icount,SetStdRelErr,PartDR4DR5Msg);
		//				//Added by Hemal
		//				return 0;
		//			}
		//			else
		//			{
		//				tc_strcat(PartDR4DR5Msg,"\n Non-Color Part No: ");
		//				tc_strcat(PartDR4DR5Msg,PartID);
		//				tc_strcat(PartDR4DR5Msg,"/");
		//				tc_strcat(PartDR4DR5Msg,PartRevID);
		//				tc_strcat(PartDR4DR5Msg," which is not STDSI released, DML No: ");
		//				tc_strcat(PartDR4DR5Msg,EPAID);
		//				tc_strcat(PartDR4DR5Msg,". Released through AMDML/Connected DML. \n");
		//
		//				printf("\n PartDR4DR5Msg = %s \n",PartDR4DR5Msg);fflush(stdout);
		//				cntFlag = 1;
		//				*Err_Flg = 1;
		//				//tc_strcat(SetStdRelErr,PartDR4DR5Msg);
		//				setAddStrFuction(icount,SetStdRelErr,PartDR4DR5Msg);
		//				return 0;
		//			}		
				}

			}
			else
			{
				printf("\n Part`s DR status is != DR4/AR4/DR5/AR5/DR3P/AR3P \n");fflush(stdout);
				//recursive function call
		//		printf("\nNO DR3P above Part: %s,%s",PartID,PartRevID);fflush(stdout);
		//		
		//		RevOnly	= strtok( Part_Rev_copy, ";" );
		//		printf("\nNO DR3P above Part : %s,%s",PartID,RevOnly);fflush(stdout);
		//		if (tc_strcmp(RevOnly,"NR")!=0)
		//		{
		//			t_prev_rev	=	NULLTAG;
		//			tm_fnd_Prev_Official_Revision(PartID,Part_tag, &t_prev_rev);
		//			if (t_prev_rev!=NULLTAG)
		//			{
		//				GMDML_Prt_DR4_DR5_Check(t_prev_rev, InPlant,LcsStdRlzd,SetStdRelErr,icount,Err_Flg);
		//			}
		//		}
			}
		}

	}
	return 0;
}


//Sagar End TZ 1.52

//#######################################################################################//
//Child part validation-1. CHild part NR of parent is released from same DML or not
//						2. CHild part of parent is present in same plant EPA or not
//#######################################################################################//

//TZ1.42 --DEEPTI
//int Child_std_validation(int partCnt,tag_t	sTaskTag, tag_t* partsTags,char* lcsToset,char* SetStdRelErr,char *RevisionRl,char *ClosureRl,char *ViewBVR)
int Child_std_validation(int partCnt,tag_t	sTaskTag, tag_t* partsTags,char* lcsToset,char	***SetStdRelErr,char *RevisionRl,char *ClosureRl,char *ViewBVR,int *icount) // added by dss 1.53
{

	int				ifail				=	ITK_ok;
	int				status				=	0;
	char*			Part_no				=	NULL;
	char*			Part_Type			=	NULL;
	char*			CItemName			=	NULL;
	char*			CItemRev			=	NULL;
	char*			CPart_no			=	NULL;
	char*			CPart_Rev			=	NULL;
	char *			ChildRelErr			=	NULL;
	char*			type_name			=	NULL;
	char*			type_nameCH			=	NULL;
	char*			t5CTask_name		=	NULL;
	char*			t5Task_name			=	NULL;
	char*			TaskId				=	NULL;
	char*			tsk_Plant			=	NULL;
	char*			inp_Tsk_no			=	NULL;
	//char*			inp_Plant			=	NULL;
	char*			ClosureDatetsk		=	NULL;
	char*			ReleaseStatustsk	=	NULL;
	char*			CPart_IdNR			=	NULL;
	char*			CPart_RevNR			=	NULL;
	char*			NRTaskId			=	NULL;
	char*			epa_Plant			=	NULL;
	char*			ReleaseStatusepa	=	NULL;
	char*			NRRevEPASet			=	NULL;
	char*			NRRevDMLSet			=	NULL;
	char*			NrDmlID				=	NULL;


	tag_t			DesignTag			=	NULLTAG;
	tag_t			ChRDsgnTag			=	NULLTAG;
	tag_t			objTypeTag			=	NULLTAG;
	tag_t			objTypeTagCH		=	NULLTAG;
	tag_t			window				=	NULLTAG;
	tag_t			rule				=	NULLTAG;
	tag_t			top_line			=	NULLTAG;
	tag_t	  		relation_type		=	NULLTAG;
	tag_t	  		relation_type_task	=	NULLTAG;
	tag_t	  		t_ChildItemRev		=	NULLTAG;
	tag_t	  		PartTskTag			=	NULLTAG;
	tag_t	  		itemTypeTag_class	=	NULLTAG;
	tag_t	  		NRParttskTag		=	NULLTAG;
	tag_t	  		NRitemTypeTag_class	=	NULLTAG;

	tag_t*			DgnChld				=	NULLTAG;
	tag_t*  		prtTasks			=	NULLTAG;
	tag_t  			prtTask				=	NULLTAG;	
	tag_t*			status_list			=	NULLTAG;
	tag_t*			status_listTask		=	NULLTAG;
	tag_t*			PartTaskTags		=	NULLTAG;
	tag_t*			NRPartTskTags		=	NULLTAG;
	tag_t*			epa_status_list		=	NULLTAG;

	int				iPrt=0,nClhd=0,iChld=0,cntTask=0,iTask=0,iSameTask=0,iChRItem=0;
	int				iChildItemTag=0;
	int st_count			=	0;
	int iStCnt				=	0;
	int chldLcsRlzd			=	0;
	int count_task			=	0;
	int cnt_tk				=	0;
	int st_tskCnt			=	0;
	int stlst				=	0;
	int TaskRlzFlg			=	0;
	int epaRlzFlg			=	0;
	int NRcount_task		=	0;
	int Precnt				=	0;
	int preEpaFlg			=	0;
	int st_epacount			=	0;
	int NRinEPA				=	0;
	int preTaskNrFlg		=	0;
	int chNrRelzFlg			=	0;
	int n_tags_found2=0;

	tag_t		itemNR		=	NULLTAG;
	tag_t	*itemclass2							= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t *  rev_list;
	char	*object_type = NULL;

	char*			BVRAsPerPartOwner				= NULL;
	char*			Item_id						= NULL;
	char*			Part_owning_groupVal				= NULL;
	struct			BomChldStrut	ChldStrutBdySh[5000];
	int				StructCntBdyShProdPlan	= 0;
	int cntLcs=0;
	int childBS = 0;
	int				count1=0;

	tag_t			objChild_BS		= NULLTAG;
	tag_t			class_id				=     NULLTAG;
	char *class_name= NULL;

	const char *qry_entries[2];//Multiple Item Queried Error
	const char *qry_values[2];//Multiple Item Queried Error

	char inp_Plant[40];

	int iSameTaskAllChildRev=0;

	char			type_class[TCTYPE_name_size_c+1];
	//API change
	//char			NRtype_class[TCTYPE_name_size_c+1];
	char *NRtype_class = NULL;
	tag_t	objChild_bvr1 = NULLTAG;
	char	*Child_Qty	     = NULL;
	char		   *PlantName =NULL;
	char		   *CSPlant =NULL;
	tag_t  CurrentRoleTag = NULLTAG;
	//API change
	char *roleName = NULL;
	//char   roleName[SA_name_size_c+1]  ;
	PlantName = (char*) MEM_alloc(100);
	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	char STDDmlPlnt[40];
	char RevisionRule[40];
	char ClosureRule[40];
	char BVR[40];
	char APLDmlPlnt[40];
	char GetBomlnmkindicator[100];

	//added by vishal
	char		*itemidtask;
    char        *PLtaskvalue = NULL;
    PLtaskvalue = (char *)MEM_alloc(1 * sizeof(char *));
	int chNrRelzFlgNext=0;

	/*
	if (!NRRevEPASet) MEM_free(NRRevEPASet);
	NRRevEPASet=(char *)MEM_alloc(2000);
	tc_strcpy(NRRevEPASet," ");

	if (!NRRevDMLSet) MEM_free(NRRevDMLSet);
	NRRevDMLSet=(char *)MEM_alloc(2000);
	tc_strcpy(NRRevDMLSet," ");
	*/

	printf("\n###########Inside STDSI Child part checks###################\n");fflush(stdout);

	status = AOM_ask_value_string(sTaskTag,"current_name",&t5Task_name);

	CALLAPI(AOM_ask_value_string(sTaskTag,"item_id",&inp_Tsk_no));
	printf("\n\n\t\t inp_Tsk_no  is :%s",inp_Tsk_no);	fflush(stdout);

	GetPlantForDMLORTask(inp_Tsk_no,inp_Plant);
	//inp_Plant=subString(inp_Tsk_no,14,strlen(inp_Tsk_no));
	printf("\t  inp_Plant after  ...%s\n", inp_Plant);


	// Control Object for Unconfigured Revision Check in STDSI - Palash
	char    *qryEntry[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qryValues[3]= {"STDSI","UNCONFIGURED","0"};
	
    tag_t qryTagSTDSIChk=NULLTAG;
    int qryCount=0;
    tag_t* qryResult=NULLTAG;

	ITKCALL(QRY_find2("Control Objects...", &qryTagSTDSIChk));
	if (qryTagSTDSIChk)
	{
	    printf("\n Control Object Query Found \n Going to call unconfigured Revision Check \n");fflush(stdout);
	    ITKCALL(QRY_execute(qryTagSTDSIChk, 3, qryEntry, qryValues, &qryCount, &qryResult));
		printf("\n Query Count for Unconfigured Revision is : %d\n",qryCount);fflush(stdout);
	}
	// Control Object for Unconfigured Revision Check in STDSI - Palash - Code Ends for Control Object Check


	if (partCnt>0)
	{
		for (iPrt=0;iPrt<partCnt ;iPrt++ )
		{
			printf("\niPrt : %d",iPrt);fflush(stdout);

			DesignTag	=	partsTags[iPrt];
			
			/* Abineshwar STD Validation Child part Validation removal for Part in EPA */
			char    *qryEntryTasHasEPA[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
			char    *qryValuesTasHasEPA[3]= {"STDSI","TASKHASEPA","0"};

            tag_t qryTagSTDSITaskHasEPA=NULLTAG;
            int qryCountTaskHasEPA=0;
            tag_t* qryResultTaskHasEPA=NULLTAG;

            ITKCALL(QRY_find2("Control Objects...", &qryTagSTDSITaskHasEPA));
            if (qryTagSTDSITaskHasEPA)
            {
                printf("\n Control Object Query Found For Qry Task Has EPA \n");fflush(stdout);
                ITKCALL(QRY_execute(qryTagSTDSITaskHasEPA, 3, qryEntryTasHasEPA, qryValuesTasHasEPA, &qryCountTaskHasEPA, &qryResultTaskHasEPA));
            	printf("\n Control Object Query Count For Qry Task Has EPA =%d",qryCountTaskHasEPA);fflush(stdout);
            }
			if(qryCountTaskHasEPA > 0)
			{
	            tag_t *ObjRefRnce;
                int NoObjRefs;
                int *ObjLevels;
                char **ObjctRelatins=NULL;
	            ITKCALL(WSOM_where_referenced2(DesignTag, 1,&NoObjRefs,&ObjLevels,&ObjRefRnce,&ObjctRelatins));
	            
	            int RefCounter = 0;
	            int PartISInPlantEPA = 0;
				
				tag_t  CurrentRoleTagObj = NULLTAG;
			    char   *RoleNameObj = NULL;
			    char   *PlantNameObj =NULL;
			    PlantNameObj = (char*) MEM_alloc(100);
			    ITKCALL(SA_ask_current_role(&CurrentRoleTagObj));
			    ITKCALL(SA_ask_role_name2(CurrentRoleTagObj,&RoleNameObj))
			    printf("\n\n  RoleNameObj  is : %s\n",RoleNameObj); fflush(stdout);
			    PlantNameObj=subString(RoleNameObj,3,4);
			    printf( "PlantNameObj is :%s\n", PlantNameObj);
				
	            for(RefCounter = 0; RefCounter < NoObjRefs; RefCounter++)
	            {
	            	tag_t ObjTypeRefTag = NULLTAG;
	            	char*  ObjTypeName;
	            	ITKCALL(TCTYPE_ask_object_type(ObjRefRnce[RefCounter],&ObjTypeRefTag));
					
	            	if (ObjTypeRefTag !=NULLTAG)
	            	{
	            		ITKCALL(TCTYPE_ask_name2(ObjTypeRefTag,&ObjTypeName)); 
			    		printf( "\n ObjTypeName is :%s", ObjTypeName);
			    		
	            		if (strcmp(ObjTypeName,"T5_EPATaskRevision")==0)
	            		{
	            			char* EPATaskName = NULL;
	            			if( AOM_ask_value_string(ObjRefRnce[RefCounter],"item_id",&EPATaskName)!=ITK_ok);
	            			
	            			char* EPATaskID = NULL;
	            			EPATaskID=subString(EPATaskName,0,2);
			    			printf( "\n EPATaskID is :%s", EPATaskID);
							
							char* EPAPlantOwningObj = NULL;
							AOM_UIF_ask_value(ObjRefRnce[RefCounter],"owning_group",&EPAPlantOwningObj);
							printf("\n EPAPlantOwningObj =%s",EPAPlantOwningObj);fflush(stdout);
			    			
	            			
	            			if(tc_strcmp(PlantNameObj,"STDJ") == 0)
	            			{
	            				if(tc_strcmp(EPAPlantOwningObj,"STDJSR")==0)
	            				{
	            					printf("\n Plant Specific JSR EPA Found");
	            					PartISInPlantEPA = 1;
	            					break;
	            				}
	            			}
	            			else if (tc_strcmp(PlantNameObj,"STDP") == 0)
	            			{
	            				if(tc_strcmp(EPAPlantOwningObj,"STDPUNE")==0)
	            				{
	            					PartISInPlantEPA = 1;
	            					printf("\n Plant Specific PUNE EPA Found");
	            					break;
	            				}
	            			}
	            			else if (tc_strcmp(PlantNameObj,"STDL") == 0)
	            			{
	            				if(tc_strcmp(EPAPlantOwningObj,"STDLKO")==0)
	            				{
	            					PartISInPlantEPA = 1;
	            					printf("\n Plant Specific LKO EPA Found");
	            					break;
	            				}
	            			}
	            			else if (tc_strcmp(PlantNameObj,"STDD") == 0)
	            			{
	            				if(tc_strcmp(EPAPlantOwningObj,"STDDWD")==0)
	            				{
	            					PartISInPlantEPA = 1;
	            					printf("\n Plant Specific DWD EPA Found");
	            					break;
	            				}
	            			}
	            			else if (tc_strcmp(PlantNameObj,"STDU") == 0)
	            			{
	            				if(tc_strcmp(EPAPlantOwningObj,"STDUTK")==0)
	            				{
	            					PartISInPlantEPA = 1;
	            					printf("\n Plant Specific UTK EPA Found");
	            					break;
	            				}
	            			}
	            		}
	            	}
			    }
	            if (PartISInPlantEPA == 1)
	            {
	            	continue;
	            }
			}
			else
			{
				printf("\n STDSI,TASKHASEPA Control Object is disabled");fflush(stdout);
			}
		    /* Abineshwar STD Validation Child part Validation removal for Part in EPA */
			
			
			
			
			//Asks an object for its type. Return tag_t as output
			if(TCTYPE_ask_object_type(DesignTag,&objTypeTag));

			//Asks a type for its name. Return String, which need to free once used.
			if(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n\n\t\t AssyTag type_name := %s", type_name);fflush(stdout);

			//if (tc_strcmp(type_name,"Design Revision")==0)	 //Deepti TZ3.52
			//{
				CALLAPI(AOM_ask_value_string(DesignTag,"item_id",&Part_no));
				printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);

				CALLAPI(AOM_ask_value_string(DesignTag,"t5_PartType",&Part_Type));
				printf("\n\n\t\t Part_Type  is :%s",Part_Type);	fflush(stdout);
				
				/**Added By Manindra for Skip the STD Validation If Parent's CS is F18 for CVBU**/
				ITKCALL(SA_ask_current_role(&CurrentRoleTag));
				ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
				printf("\n\n  roleName  is : %s\n",roleName); fflush(stdout);
				PlantName=subString(roleName,3,4);
				printf( "PlantName is :%s\n", PlantName);

				if(tc_strstr(PlantName,"STD"))
				{
				getPlantDetailsAttr_Std(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency,RevisionRule,ClosureRule,BVR,APLDmlPlnt,STDDmlPlnt);
				}
				else
				{
				getPlantDetailsAttr_Std_Rls_type(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency,RevisionRule,ClosureRule,BVR,APLDmlPlnt,STDDmlPlnt);
				}
				//cbb Function
				printf("\n PlantCS is %s \n",PlantCS);
				if(tc_strcmp(PlantName,"STDC")!= 0)
				{
					CALLAPI(AOM_ask_value_string(DesignTag,PlantCS,&CSPlant));
					printf("\n\n\t\t Part's make buy indicator is :%s",CSPlant);fflush(stdout);
					
					if(tc_strcmp(CSPlant,"F18")==0)
					{
						printf("\n Part's make buy indicator is F18 TYPE hence continue....");fflush(stdout);
						continue;
					}
					
				}
				/****Code ended by Manindra*****/

				//Added By Dhanashri for skip prev rev UATZ1.42//
				 char*			SkipPrevRevSTD				= NULL;
				 ITKCALL(AOM_ask_value_string(DesignTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
				 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
				 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
					
					//if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
					if(tc_strlen(SkipPrevRevSTD)>0)
					{
						printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
						continue;
					}
				//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//


				//Explode the BOM
				/*nClhd	=	0;
				CALLAPI(BOM_create_window (&window));
				CALLAPI(CFM_find( "Latest Working", &rule));
				CALLAPI(BOM_set_window_config_rule( window, rule ));
				CALLAPI(BOM_set_window_top_line(window, null_tag,DesignTag , null_tag, &top_line));
				CALLAPI(BOM_line_ask_child_lines (top_line, &nClhd, &DgnChld));*/

				ITKCALL(AOM_UIF_ask_value(DesignTag,"owning_group",&Part_owning_groupVal));
				printf("\n\n\t\t Part_no  Part_owning_groupVal is :%s",Part_owning_groupVal);fflush(stdout);

				if (tc_strcmp(BVRAsPerPartOwner,"NULL") !=0) MEM_free(BVRAsPerPartOwner);
				BVRAsPerPartOwner=(char *)MEM_alloc(100);

				//TZ3.46
				char BVRInfo2[40];
				char Info1[40];
				char Info3[40];
				//----------------vishal start -----------------------------------------

				ITKCALL(AOM_ask_value_string(sTaskTag,"item_id",&itemidtask));
				printf("\t  item_id ...%s\n", itemidtask);fflush(stdout);
				
				getTaskOwningValue(itemidtask, PLtaskvalue); //vishal

				printf("\n  Plant name of Task is :%s ..............",PLtaskvalue);fflush(stdout);
				get_CtrlVal_APLLcsInf(PLtaskvalue,Info1,BVRInfo2,Info3);//vishal

				//----------------vishal end -----------------------------------------
				//get_CtrlVal_APLLcsInf(Part_owning_groupVal,Info1,BVRInfo2,Info3);//TZ3.46
				tc_strcpy(BVRAsPerPartOwner,BVRInfo2);

				StructCntBdyShProdPlan	= 0;

				if(qryCount>0) // Changed by Palash for STDS Unconfigured BOM Check
				{
					ITKCALL(Get_Part_BOM_Lvl_Unconfigured(DesignTag,1,ClosureRl,RevisionRl,BVRAsPerPartOwner,ChldStrutBdySh,&StructCntBdyShProdPlan));
				}
				else{
					ITKCALL(Get_Part_BOM_Lvl(DesignTag,1,ClosureRl,RevisionRl,BVRAsPerPartOwner,ChldStrutBdySh,&StructCntBdyShProdPlan));
				} //// Changed by Palash for STDS Unconfigured BOM Check - Code Ends
	
				printf("\n\t\t StructCntBdyShProdPlan:%d",StructCntBdyShProdPlan);fflush(stdout);

				iChld=0;
				for (iChld=1;iChld<=StructCntBdyShProdPlan ;iChld++ )
				{				
					cntLcs=0;
					iSameTask	=	0;
					objChild_BS		= NULLTAG;
					objChild_BS=ChldStrutBdySh[iChld].child_objs;
					char	*Part_clr_ind	=	NULL;

					ITKCALL(AOM_UIF_ask_value(objChild_BS,"item_id",&Item_id));
					printf("\n\n\t EPA Child Part String is Item_id-->%s",Item_id);	fflush(stdout);

					// added by dss 1.53
					char   *Item_rev_Part_type=NULL; 
					char   *Item_rev_Part_CSvalue=NULL; 
					char   *Item_rev=NULL; 
					char   *childMakeBuy=NULL; 
					AOM_UIF_ask_value(objChild_BS,"item_revision_id",&Item_rev);
					printf("\n\n\t Child Part String is Item_rev--->%s",Item_rev);
					
					//Added By Manindra For skiping child part validation if its qty is ZERO*******
					
					objChild_bvr1	     = NULLTAG;
					Child_Qty			 = NULL;
					objChild_bvr1=ChldStrutBdySh[iChld].child_objs_bvr;
					AOM_ask_value_string(objChild_bvr1,"bl_quantity",&Child_Qty);
					printf("\nChild part [%s] is having its Qty==>[%s]\n",Item_id,Child_Qty);fflush(stdout);

					ITKCALL(AOM_ask_value_string(objChild_BS,"t5_PartType",&Item_rev_Part_type));
					printf("\n\n\t\t Item_rev_Part_type  is :%s",Item_rev_Part_type);	fflush(stdout);
					
					//Added By Manindra For skiping child part having CS F18 *******
					ITKCALL(AOM_ask_value_string(objChild_BS,PlantCS,&childMakeBuy));
					printf("\n\n\t\t childMakeBuy  is :%s",childMakeBuy);	fflush(stdout);

					printf("\n Nishant: PlantCS is [%s]",CSPlant);fflush(stdout);
					
					if(tc_strcmp(PlantName,"STDC")!= 0)
					{
						if ((tc_strcmp(CSPlant,"F")==0) || (tc_strcmp(CSPlant,"F30")==0) || (tc_strcmp(CSPlant,"F40")==0))       //&& (tc_strcmp(childMakeBuy,"F18")==0))
						{
							
							printf("\n Parent part Make buy is having F/F30/F40 hence child make buy check is not required to check --> hence continue....");fflush(stdout);
							continue;
							
						}
						
					}
					printf("\n Nishant: after PlantCS bypass is [%s]",CSPlant);fflush(stdout);

					//Ended By Manindra for CS validation
					//if( (strcmp(Item_rev_Part_type,"D")==0) || (strcmp(Item_rev_Part_type,"DC")==0)|| (strcmp(Item_rev_Part_type,"IFD")==0) || (strcmp(Item_rev_Part_type,"DA")==0) ) 
					if( (strcmp(Item_rev_Part_type,"D")==0) || (strcmp(Item_rev_Part_type,"DC")==0)|| (strcmp(Item_rev_Part_type,"IFD")==0) || (strcmp(Item_rev_Part_type,"DA")==0) || (strcmp(Item_rev_Part_type,"IM")==0))  //venkat addded Part is IFD Module
					{
						printf("\n\n\t\t Child Part Validation Bypass for Dummy Part Type......");	fflush(stdout);
						continue;
					}
					//end added by dss 1.53 

					Part_clr_ind	=	NULL;
					ITKCALL(AOM_ask_value_string(objChild_BS,"t5_ColourInd",&Part_clr_ind));
					printf("\n\n\t EPA Child Part String is Part_clr_ind-->%s",Part_clr_ind);	fflush(stdout);

					qry_entries[0] ="item_id";
					qry_entries[1] ="object_type";//Multiple Item Queried Error
					qry_values[0] = Item_id;
					if (tc_strcmp(Part_clr_ind,"C")==0)
					{
						qry_values[1] = "T5_ClrPart";//Multiple Item Queried Error Hemal
					}
					else
					{
						//qry_values[1] = "Design";//Multiple Item Queried Error Hemal
						//Handle the different design child class.
						char	*designBORev		=	NULL;
						char	*designBO			=	NULL;
						//tag_t	AssyTag			=	NULLTAG;
						//AssyTag=PartTags[k];
						printf("\nBefore getDesignType");fflush(stdout);
						getDesignType(objChild_BS, &designBORev,&designBO);
						printf("\nAfter getDesignType : %s",designBO);fflush(stdout);
						qry_values[1] = designBO;

					}//Multiple Item Queried Error

					//ITKCALL(ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found2, &itemclass2));
					ITKCALL(ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found2, &itemclass2));//Multiple Item Queried Error
					if(n_tags_found2>0)
					{
						//itemcldclass = itemclass2[0];

						//ITKCALL(ITEM_list_all_revs(itemcldclass, &count1,&rev_list ));

						CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
						CALLAPI(GRM_list_primary_objects_only(objChild_BS,relation_type,&cntTask,&prtTasks));

						printf("\nNo of Child Task Found : %d",cntTask);fflush(stdout);
						//Check Child is attached with same Task or not.
						if (cntTask>0)
						{
							//iSameTask	=	0;
							for (iTask=0;iTask<cntTask;iTask++)
							{
								prtTask	=	NULLTAG;
								prtTask	=	prtTasks[iTask];
								//current_id
								CALLAPI(AOM_ask_value_string(prtTask,"object_type",&object_type));
								printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
								if(strcmp(object_type,"T5_APLTaskRevision")==0)
								{									
									status = AOM_ask_value_string(prtTask,"item_id",&t5CTask_name);
									printf("\nName of Input task: %s",inp_Tsk_no);fflush(stdout);
									printf("\nName of child task: %s",t5CTask_name);fflush(stdout);

									if (tc_strcmp(inp_Tsk_no,t5CTask_name)==0)
									{
										//Parent and child are in same Task.
										iSameTask++;
										printf("\nChild Part %s and Parent Parent Part is in Same Task : %s, count : %d",CItemName,t5CTask_name,iSameTask);fflush(stdout);
										break;
									}
								}
							}
							if (iSameTask>0)
							{
								//If Parent and child are in same task part validation will not be called.
								//return ifail;
							}
						}

							if(iSameTask == 0)
							{
								//Query the All revision of the child part
								//check any one revision release from same plant or not.
								//if any revision release from same plant validation will not be call
								//else validation error will be added in string.

								//const char *qry_entries[1];
								//const char *qry_values[1];
								int			n_tags_found=0;
								//tag_t		*itemclass	=	NULLTAG;
								//tag_t		item		=	NULLTAG;


								printf("\n Child Part Number %s.....\n",Item_id);
								//qry_entries[0] ="item_id";
								//qry_values[0] = Item_id;

								//Find Item by its ID.
								//ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
								//if(n_tags_found>0)
								//{
									//item = itemclass[0];
									//if(item != NULLTAG )
									if(objChild_BS != NULLTAG )
									{
										int	nCRItem			=	0;
										int	cntCldTask		=	0;
										int st_count		=	0;

										tag_t		*CRitem_revs_tag		=	NULLTAG;
										//tag_t*  	ChRTask				=	NULLTAG;
										//List all item revsion
										//ITKCALL(ITEM_list_all_revs(item,&nCRItem,&CRitem_revs_tag));
										ITKCALL(AOM_ask_value_tags(objChild_BS,"revision_list",&nCRItem,&CRitem_revs_tag));
										printf("\nNo of CHild Item revisions : %d",nCRItem);fflush(stdout);
										//printf("\n No of Child Task Found : %d",nCRItem);fflush(stdout);

										chldLcsRlzd=0;
										TaskRlzFlg=0;
										NRinEPA=0;
										//for (iChRItem=0;iChRItem<nCRItem ;iChRItem++ )
										for(iChRItem=nCRItem-1;iChRItem>=0;iChRItem--)
										{
											printf("\nNo of iChRItem : %d",iChRItem);fflush(stdout);
											ChRDsgnTag=NULLTAG;
											ChRDsgnTag	=	CRitem_revs_tag[iChRItem];

											//Added TZ 1.43//
											objTypeTagCH=NULLTAG;
											if(TCTYPE_ask_object_type(ChRDsgnTag,&objTypeTagCH));

											//Asks a type for its name. Return String, which need to free once used.
											type_nameCH=NULL;
											if(TCTYPE_ask_name2(objTypeTagCH,&type_nameCH));
											printf("\n\n\t\t AssyTag type_nameCH := %s", type_nameCH);fflush(stdout);
											
											CALLAPI(POM_class_of_instance(objTypeTagCH,&class_id));
											CALLAPI(POM_name_of_class(class_id,&class_name));
											printf("\n class_name is :%s\n",class_name);fflush(stdout);
											
											//Add color part in if condition remaining
											
											//if (tc_strcmp(type_nameCH,"Design_0_Revision_alt")==0 || tc_strcmp(type_nameCH,"Design Revision")==0 )	//Deepti TZ3.52
											//{				

											CALLAPI(AOM_ask_value_string(ChRDsgnTag,"item_id",&CPart_no));
											printf("\n\n\t\t Child Part_no  is :%s",CPart_no);	fflush(stdout);

											CALLAPI(AOM_ask_value_string(ChRDsgnTag,"item_revision_id",&CPart_Rev));
											printf("\n\n\t\t Child Part_no  is :%s",CPart_Rev);	fflush(stdout);

											ITKCALL(WSOM_ask_release_status_list(ChRDsgnTag,&st_count,&status_list));
											printf("\n\n\t\t Child Status Count  is :%d",st_count);	fflush(stdout);
											if (st_count>0)
											{
												for (iStCnt=0;iStCnt<st_count ;iStCnt++ )// 	T5_LcsStdRlzd
												{
													char* c_st_class_name	=	NULL;
													ITKCALL(AOM_ask_value_string(status_list[iStCnt],"object_name",&c_st_class_name));
													printf("\n c_st_class_name: %s:lcsToset %s\n",c_st_class_name,lcsToset);fflush(stdout);
													if(tc_strcmp(c_st_class_name,lcsToset)==0)
													{
														printf("\n Revision %s of child part %s of parent %s is STDSI released",CPart_Rev,CPart_no,Part_no);fflush(stdout);
														chldLcsRlzd=1;
														break;

													}
												}
											}
											else
											{
												printf("\n%s has no status, so part is not released from any agency",CPart_no);fflush(stdout);
											}

											//Started by Deepti fro TZ1.57 as per CR TCUA/CR/PLM SYS/STDS/21/0002//
											if(chldLcsRlzd==0) 
											{
												
												tag_t	  		relation_type_allchildRev	=	NULLTAG;
												tag_t*			prtTasks_allchildRev		=	NULLTAG;
												tag_t	  		prtTask_allchildRev		=	NULLTAG;
												char *object_type_allchildRev=NULL;
												char *t5CTask_name_allchildRev=NULL;

												int cntTask_allchildRev=0;
												int iTaskChldRev=0;
												iSameTaskAllChildRev=0;


												CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&relation_type_allchildRev));
												CALLAPI(GRM_list_primary_objects_only(ChRDsgnTag,relation_type_allchildRev,&cntTask_allchildRev,&prtTasks_allchildRev));
												printf("\n cntTask_allchildRev: %d",cntTask_allchildRev);fflush(stdout);
												if (cntTask_allchildRev>0)
												{
													for (iTaskChldRev=0;iTaskChldRev<cntTask_allchildRev;iTaskChldRev++)
													{
														prtTask_allchildRev	=	NULLTAG;
														prtTask_allchildRev	=	prtTasks_allchildRev[iTaskChldRev];
														
														if(prtTask_allchildRev != NULLTAG )
														{
															object_type_allchildRev=NULL;
															t5CTask_name_allchildRev=NULL;
															//current_id
															CALLAPI(AOM_ask_value_string(prtTask_allchildRev,"object_type",&object_type_allchildRev));
															printf("\n\n\t\t object_type is_allchildRev :%s",object_type_allchildRev);fflush(stdout);
															if(strcmp(object_type_allchildRev,"T5_APLTaskRevision")==0)
															{									
																status = AOM_ask_value_string(prtTask_allchildRev,"item_id",&t5CTask_name_allchildRev);
																printf("\nName of Input task: %s",inp_Tsk_no);fflush(stdout);
																printf("\nName of child task_allchildRev: %s::%s",t5CTask_name_allchildRev,inp_Tsk_no);fflush(stdout);

																if (strcmp(inp_Tsk_no,t5CTask_name_allchildRev)==0)
																{
																	//Parent and child are in same Task.
																	iSameTaskAllChildRev++;
																	printf("\nChecking other Rev of Child Part and Parent Part is in Same Task : %s, count : %d",t5CTask_name_allchildRev,iSameTaskAllChildRev);fflush(stdout);
																	break;
																}
															}
														}
													}
												}
											
											}
											if(iSameTaskAllChildRev>0)break;

											//Ended by Deepti fro TZ1.57 as per CR TCUA/CR/PLM SYS/STDS/21/0002//
										//}
											
										}
										printf("\n iSameTaskAllChildRev: %d::%d",chldLcsRlzd,iSameTaskAllChildRev);fflush(stdout);
										//if(chldLcsRlzd==0) 
										if(chldLcsRlzd==0 && iSameTaskAllChildRev==0) 
										{
											chNrRelzFlg=0;
											//tag_t		itemNR		=	NULLTAG;
											printf("\n No revision of child part %s of parent %s seems released from STDSI, checking for NR in EPA and its DML",CPart_no,Part_no);fflush(stdout);

											iChRItem=0;
											//for (iChRItem=0;iChRItem<nCRItem ;iChRItem++ )
											for(iChRItem=nCRItem-1;iChRItem>=0;iChRItem--)
											{
												printf("\nNo of iChRItem : %d",iChRItem);fflush(stdout);
												ChRDsgnTag=NULLTAG;
												ChRDsgnTag	=	CRitem_revs_tag[iChRItem];								

												CPart_Rev=NULL;
												CALLAPI(AOM_ask_value_string(ChRDsgnTag,"item_revision_id",&CPart_Rev));
												printf("\n\n\t\t Child Part Rev  is :%s",CPart_Rev);	fflush(stdout);

												objTypeTagCH=NULLTAG;
												if(TCTYPE_ask_object_type(ChRDsgnTag,&objTypeTagCH));

												//Asks a type for its name. Return String, which need to free once used.
												type_nameCH=NULL;
												if(TCTYPE_ask_name2(objTypeTagCH,&type_nameCH));
												printf("\n\n\t\t AssyTag type_nameCH := %s", type_nameCH);fflush(stdout);
											
												//if (tc_strcmp(type_nameCH,"Design_0_Revision_alt")==0 || tc_strcmp(type_nameCH,"Design Revision")==0 ) //Deepti TZ3.52
												//{
													//if(tc_strcmp(CPart_Rev,"NR")==0)
													if(tc_strstr(CPart_Rev,"NR")!=NULL)
													{
														printf("\n Found NR Revision of %s",CPart_no);fflush(stdout);
														itemNR=CRitem_revs_tag[iChRItem];
														chNrRelzFlgNext=1;
														break;
													}
												//}
											}

											//added by Sanjay
											char *NRREVchk =NULL;
											printf("\n chNrRelzFlgNext: %d \n",chNrRelzFlgNext);	fflush(stdout);

											if (chNrRelzFlgNext==0)
											{  
												NRREVchk=(char *)MEM_alloc(500);
												tc_strcpy(NRREVchk," ");
												printf("\n Added by sanjay \n");	fflush(stdout);											
												NRREVchk=NULL;
												NRREVchk=(char *)MEM_alloc(500);
												tc_strcpy(NRREVchk," ");
												tc_strcat(NRREVchk," NR Revision of child part ");																 
												tc_strcat(NRREVchk,CPart_no);
												tc_strcat(NRREVchk," is not present in the system");
												tc_strcat(NRREVchk,"\n");
												setAddStrFuction(icount,SetStdRelErr,NRREVchk); 
												printf("\n loop ended ----------------- \n");	fflush(stdout);
												break;

											}
											
											//itemNR = itemclass[0];
											if(itemNR != NULLTAG )
											{
												CALLAPI(AOM_ask_value_string(itemNR,"item_id",&CPart_IdNR));
												printf("\n\n\t\t  CHild Name : CPart_IdNR  is :%s",CPart_IdNR);	fflush(stdout);

												CALLAPI(AOM_ask_value_string(itemNR,"item_revision_id",&CPart_RevNR));
												printf("\n\n\t\t  CHild Rev : CPart_RevNR  is :%s",CPart_RevNR);	fflush(stdout);

												//Checking whether NR is in EPA of same plant or not//

												epaRlzFlg=0;
												relation_type_task=NULLTAG;
												GRM_find_relation_type("CMHasSolutionItem",&relation_type_task);
												GRM_list_primary_objects_only(itemNR,relation_type_task,&NRcount_task,&NRPartTskTags);
												if(NRcount_task >0)
												{							
													for (Precnt=0;Precnt<NRcount_task ;Precnt++ )
													{
														NRParttskTag=NULLTAG;
														NRitemTypeTag_class=NULLTAG;
														NRParttskTag=NRPartTskTags[Precnt];
														ITKCALL (TCTYPE_ask_object_type(NRParttskTag,&NRitemTypeTag_class));
														ITKCALL (TCTYPE_ask_name2(NRitemTypeTag_class,&NRtype_class));

														printf("\n  NRtype_class ...%s\n", NRtype_class);

														NRTaskId=NULL;
														ITKCALL(AOM_ask_value_string(NRParttskTag, "item_id",&NRTaskId));
														printf("\n NRTaskId %s.....\n",NRTaskId);

														if(tc_strcmp(NRtype_class,"T5_EPATaskRevision")==0)
														{
															epa_Plant=NULL;
															epa_Plant=subString(NRTaskId,22,strlen(NRTaskId));
															printf("\t  epa_Plant after  ...%s\n", epa_Plant);

															if(tc_strcmp(inp_Plant,epa_Plant)==0)
															{
																ITKCALL(WSOM_ask_release_status_list(NRParttskTag,&st_epacount,&epa_status_list));
																for (stlst = 0; stlst < st_epacount; stlst++)
																{
																	printf("\n stlst:%d",stlst);fflush(stdout);

																	ReleaseStatusepa=NULL;
																	AOM_ask_name(epa_status_list[stlst], &ReleaseStatusepa);
																	printf("\n ReleaseStatusepa %s \n",  ReleaseStatusepa);fflush(stdout);
																	if( (tc_strcmp(ReleaseStatusepa,lcsToset)!=0) && (stlst==(st_epacount-1)) )
																	{
																		//if (!NRRevEPASet) MEM_free(NRRevEPASet);
																		NRRevEPASet=NULL;
																		NRRevEPASet=(char *)MEM_alloc(500);
																		tc_strcpy(NRRevEPASet," ");

																		NRinEPA=1;
																		if(preEpaFlg==0)
																		{
																			 tc_strcat(NRRevEPASet,"\n Following child parts are under STDSI working EPA. Please release the child part by finalizing EPA \n");																	 
																			 preEpaFlg=1;
																		}
																		 //tc_strcat(NRRevEPASet,"\n");
																		 tc_strcat(NRRevEPASet,CPart_RevNR);//Manindra change and introducing Revision with sequence
																		 tc_strcat(NRRevEPASet," Revision of part ");																 
																		 tc_strcat(NRRevEPASet,CPart_IdNR);
																		 tc_strcat(NRRevEPASet," of parent ");
																		 tc_strcat(NRRevEPASet,Part_no);
																		 tc_strcat(NRRevEPASet," is contained in EPA Task ");
																		 tc_strcat(NRRevEPASet,NRTaskId);
																		 tc_strcat(NRRevEPASet,"\n");

																		 setAddStrFuction(icount,SetStdRelErr,NRRevEPASet); // added by dss 1.53
																		 cntFlag = 1;

																		 break;
																	}
																}														
																
															}
														}
													}

													if(NRinEPA==0)
													{
														//if (!NRRevDMLSet) MEM_free(NRRevDMLSet);
														NRRevDMLSet=NULL;
														NRRevDMLSet=(char *)MEM_alloc(500);
														tc_strcpy(NRRevDMLSet," ");

														if(preTaskNrFlg==0)
														{
															tc_strcat(NRRevDMLSet,"\n Child Part NR of Parent is not STDSI Released From Plant DML.Please release the child part from STDS1.\n");																	 
															preTaskNrFlg=1;
														}
														//Added By Manindra For Child Quantity Zero
														if (tc_strcmp(Child_Qty,"0")==0)
														{
															printf("\n Child Part Quantity is [%s] ,hence bypass the validation",Child_Qty);fflush(stdout);
														}
														else
														{
															printf("\n Inside else Conidtion of Child part as its Qty is [%s]",Child_Qty);fflush(stdout);
															tc_strcat(NRRevDMLSet,CPart_RevNR);//Manindra change and introducing Revision with sequence
															tc_strcat(NRRevDMLSet," Revision of child part ");																 
															tc_strcat(NRRevDMLSet,CPart_IdNR);
															tc_strcat(NRRevDMLSet," of parent ");
															tc_strcat(NRRevDMLSet,Part_no);
															tc_strcat(NRRevDMLSet," is not STDSI Released from plant.");
															tc_strcat(NRRevDMLSet,"\n");

															setAddStrFuction(icount,SetStdRelErr,NRRevDMLSet); // added by dss 1.53
															cntFlag = 1;
														}
													}

												}
												else
												{
													NRRevDMLSet=NULL;
													NRRevDMLSet=(char *)MEM_alloc(500);
													tc_strcpy(NRRevDMLSet," ");
													
													//Added By Manindra for Child Quantity Zero
													if (tc_strcmp(Child_Qty,"0")==0)
													{
														printf("\n Child Part Quantity is Zero hence bypass the validation");fflush(stdout);
													}
													else
													{
														printf("\n Inside else Conidtion of Child part as its Qty is [%s]",Child_Qty);fflush(stdout);
														tc_strcat(NRRevDMLSet,CPart_RevNR);//Manindra change and introducing Revision with sequence
														tc_strcat(NRRevDMLSet," Revision of child part ");																 
														tc_strcat(NRRevDMLSet,CPart_IdNR);
														tc_strcat(NRRevDMLSet," of parent ");
														tc_strcat(NRRevDMLSet,Part_no);
														tc_strcat(NRRevDMLSet," is neither STDSI Released nor attached to any task");
														tc_strcat(NRRevDMLSet,"\n");
														setAddStrFuction(icount,SetStdRelErr,NRRevDMLSet); // added by dss 1.53
														cntFlag = 1;
													}
													
												}				


											}



											
										}//chldLcsRlzd=0
									}
								//}
							}
					}
					//printf("\n ChildRelEr22r: %s\n",SetStdRelErr);fflush(stdout);
				}
			//}
		}

		printf("\n NRRevDMLSet:%s",NRRevDMLSet);fflush(stdout);
		printf("\n NRRevEPASet:%s",NRRevEPASet);fflush(stdout);
		
			/*
			if(strlen(NRRevDMLSet)>10)
			{
				//tc_strcat(SetStdRelErr,NRRevDMLSet);	
				setAddStrFuction(icount,SetStdRelErr,NRRevDMLSet); // added by dss 1.53
				cntFlag = 1;
			}
			if(strlen(NRRevEPASet)>10)
			{
				//tc_strcat(SetStdRelErr,NRRevEPASet);	
				setAddStrFuction(icount,SetStdRelErr,NRRevEPASet); // added by dss 1.53
				cntFlag = 1;
			}
			*/
	}

	return 0;
}



//#######################################################################################//
//This validation will ensure that the two revision of parts can not be released on same day
//#######################################################################################//
//int STD_Two_Rev_Same_Day_Checks_P(int PartCnt, tag_t* PartTags,char* SetStdRelErr,char* itemid)
int STD_Two_Rev_Same_Day_Checks_P(int PartCnt, tag_t* PartTags,char  ***SetStdRelErr,char* itemid,int *icount) // added by dss 1.53
{
			int				j			=	0;
			int				task_len	=	0;
			int				kTask		=	0;
			int				count		=	0;
			int				Pre_count	=	0;
			int				k			=	0;

			

			char*			Part_no				= NULL;	        
			//char			*inp_Plant			= NULL;
			//char			*task_Plant			= NULL;
			char*			current_name		= NULL;
			char*			ClosureDate			= NULL;
			char*			ClosureDateDup		= NULL;
			char*			DmlId				= NULL;
			char			pAccessDate[20];
			char			cCurrentAccessDate[20]={0};
       		char *			pAccessDateDup 		= NULL;
			char *			twoRevRlzErr1		= NULL;
			
			//API chnage
			//char  			rev_id1[ITEM_id_size_c+1];
			char *rev_id1 = NULL;
			//char			type_name_ref[TCTYPE_name_size_c+1];
			char *type_name_ref = NULL;
			char			*Part_Rev			=	NULL;

		    tag_t			*DMLRevision		= NULLTAG;	    
			tag_t			objTypeRefTag		= NULLTAG;			
			tag_t			tsk_dml_rel_type	= NULLTAG;
        	tag_t			relation_type		= NULLTAG;
        	tag_t			relation_type2		= NULLTAG;
        	tag_t			AssyPreTag			= NULLTAG;
			tag_t			DMLRevTag			= NULLTAG;	        
			tag_t*			PartDmlTags			= NULLTAG;
			tag_t*			PartPreTags			= NULLTAG;
			tag_t			PartDmlTag			= NULLTAG;
			tag_t			AssyTag				= NULLTAG;
			logical			is_latest;     

			char LcsStdWrkg[40];
			char LcsStdRlzd[40];
			char inp_Plant[40];
			char task_Plant[40];
		  
	      

		// Start for two rev. on same day check
		//if (tc_strcmp(twoRevRlzErr1,"NULL")==0) MEM_free(twoRevRlzErr1);
		//twoRevRlzErr1=(char *)MEM_alloc(100);
		//tc_strcpy(twoRevRlzErr1,"");

		printf("\n ##############Inside two revision released on same day check###########");fflush(stdout);
				task_len=0;
				task_len=strlen(itemid);
				printf("\t  task_len ...%d\n", task_len);// length task
				//inp_Plant=subString(itemid,14,task_len);
				GetPlantForDMLORTask(itemid,inp_Plant);	
				printf("\t  inp_Plant after  ...%s\n", inp_Plant);//task

				char  ItemIDCpy[40];
				tc_strcpy(ItemIDCpy,itemid);
				GetPlantWiseRelStat(ItemIDCpy,LcsStdWrkg,LcsStdRlzd);
				printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
				printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);

				for (k=0;k<PartCnt ;k++ )
				{
					AssyPreTag=NULLTAG;
					const char *attrs[1];
					const char *values[1];
					int n_tags_found=0;
	                int				count1				= 0;
	                int				BypassNACSFlag				= 0;

					printf("\n\n\t\t for k_same rev =:%d",k);fflush(stdout);
					AssyTag=PartTags[k];
					ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
					printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);

					//Added By Dhanashri for skip prev rev UATZ1.42//
					 char*			SkipPrevRevSTD				= NULL;
					 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
					 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
					printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
					
					//if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
					if(tc_strlen(SkipPrevRevSTD)>0)
					{
						printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
						continue;
					}
					//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

					//Logic for getting previous revision//
//					GRM_find_relation_type("IMAN_based_on",&relation_type2);
//					GRM_list_secondary_objects_only(AssyTag,relation_type2,&Pre_count,&PartPreTags);
//					printf("\n\n\t\tPrev_Rev_Checks Pre_count: %d",Pre_count);fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev));
					printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);

					if(strstr(Part_Rev,"NR"))
					{
						printf("\n Previous revision function can not be called as current revision has NR revision");fflush(stdout);
					}
					else
					{
						printf("\n Calling function to get Previous revision ");fflush(stdout);
						tm_fnd_Prev_Official_Revision(Part_no,AssyTag,&AssyPreTag);//TZ 1.43
					}

					//if(Pre_count>0)
					if(AssyPreTag)
					{					

					//AssyPreTag=PartPreTags[0];
					///////////////////////////////////////			
					
					//API change
						ITEM_ask_rev_id2( AssyPreTag, &rev_id1);

						printf("\n rev_id1 is  ---->%s\n", rev_id1);fflush(stdout);//diplay the previous revision					

						//Added By Dhanashri for skip prev rev UATZ1.42//
						 char*			SkipPrevRevSTD1				= NULL;
						 ITKCALL(AOM_ask_value_string(AssyPreTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD1));
						 printf("\n\n\t\t SkipPrevRevSTD1  is :%s",SkipPrevRevSTD1);	fflush(stdout);
						 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD1)  is :%d",tc_strlen(SkipPrevRevSTD1));	fflush(stdout);
					
							//if(tc_strcmp(SkipPrevRevSTD1,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD1,"") !=0)
							if(tc_strlen(SkipPrevRevSTD1)>0)
							{
								printf("\n\n\t\t Inside SkipPrevRevSTD1 not null...");	fflush(stdout);
								continue;
							}
						//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

						GRM_find_relation_type("CMHasSolutionItem",&relation_type);
						GRM_list_primary_objects_only(AssyPreTag,relation_type,&count,&PartDmlTags);

						printf("\n\n\t\t Part to ERC DML to Task : %d",count);fflush(stdout);
						if(count >0)
						{
					   for (kTask=0;kTask<count ;kTask++ )
					   {
						PartDmlTag=PartDmlTags[kTask];//task pointer
						printf("\n\n\t\t INSIDE: ");fflush(stdout);



							ITKCALL(TCTYPE_ask_object_type(PartDmlTag,&objTypeRefTag));//task pointer
							ITKCALL(TCTYPE_ask_name2(objTypeRefTag,&type_name_ref));
							printf("\nTCDCtype_name_ref isss :%s\n",type_name_ref);fflush(stdout);

							  if (strcmp(type_name_ref,"T5_APLTaskRevision")==0)
								{
									//ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
//									if (tsk_dml_rel_type!=NULLTAG)
//									 {
//
//										ITKCALL(GRM_list_primary_objects_only(PartDmlTag,tsk_dml_rel_type,&count1,&DMLRevision));
//										printf("\n\n\t\t DML Revision from Task : %d",count1);fflush(stdout);		//task to dml
//
//										for (j=0;j<count1 ;j++ )
//										{
//											ITKCALL(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
//											printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);
//
//											if(is_latest != true)
//											{
//												printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
//											}else
//											{
												ITKCALL(AOM_ask_value_string(PartDmlTag, "item_id",&DmlId));
												printf("\n DmlId %s.....\n",DmlId);//previous revision's task
//												DMLRevTag = DMLRevision[j];//DML
//												ITKCALL(AOM_ask_value_string(DMLRevTag,"current_name",&current_name));
//												printf("\n\n\t\t dml is :%s\n",current_name);fflush(stdout);
//												task_len=0;
//												task_len=strlen(DmlId);
												//task_Plant=subString(DmlId,14,task_len);
												GetPlantForDMLORTask(DmlId,task_Plant);	
												printf("\n task_Plant is : %s\n",task_Plant);fflush(stdout);

												if(tc_strcmp(inp_Plant,task_Plant)==0)
												{
													printf("\n inside plant check is :\n");fflush(stdout);

													//ITKCALL(AOM_UIF_ask_value(DMLRevTag,"date_released",&ClosureDate));
													ITKCALL(AOM_UIF_ask_value(PartDmlTag,"date_released",&ClosureDate));
													printf("\n ClosureDate : %s\n",ClosureDate);fflush(stdout);//28-Oct-2017 14:12

													ClosureDateDup = subString(ClosureDate,0,11);
													printf("\n ClosureDateDup : %s\n",ClosureDateDup);fflush(stdout);
													getCurrentDateTime(cCurrentAccessDate);
													printf("\n  todays date111 is: %s\n",cCurrentAccessDate);
													pAccessDateDup = subString(cCurrentAccessDate,0,11);
													printf("\n  todays date is: %s\n",pAccessDateDup);
													
													if(strlen(ClosureDateDup)>2)
													{
														if(tc_strcmp(ClosureDateDup,pAccessDateDup)==0)
														{
															twoRevRlzErr1=NULL;
															twoRevRlzErr1=(char *)MEM_alloc(100);
															tc_strcpy(twoRevRlzErr1," ");

															tc_strcat(twoRevRlzErr1,"\n Two revision of part ");
															tc_strcat(twoRevRlzErr1,Part_no);
															tc_strcat(twoRevRlzErr1," cannot be released on same day.");
												
															setAddStrFuction(icount,SetStdRelErr,twoRevRlzErr1); //added by dss 1.53
															cntFlag=1;
															printf("\n twoRevRlzErr1: %s\n",twoRevRlzErr1);fflush(stdout);	

														  }
													}
												}

											//}

									//}
								//  }

							  }


				  }
				}
				}
				else
					{
					printf("\n Previous revision does not exist for part %s",Part_no);fflush(stdout);
					}
			
				} 
				/*
				if(strlen(twoRevRlzErr1)>10)
				{
					//tc_strcat(SetStdRelErr,twoRevRlzErr1);
					setAddStrFuction(icount,SetStdRelErr,twoRevRlzErr1); //added by dss 1.53
					cntFlag=1;
				}
				*/

	return 0;
}
//###############################################################################################//
//##Check will not allow the Sign-off of a DML if Next Official Revision of  Parts exist with DR Status > DR3 so user has to Release Latest Revision only##//
//###############################################################################################//

//int Next_Rev_Gt_DR3_Exists_Check(int PartCnt, tag_t* PartTags,char* SetStdRelErr,char* itemid)
int Next_Rev_Gt_DR3_Exists_Check(int PartCnt, tag_t* PartTags,char	***SetStdRelErr,char* itemid,int *icount) // added by dss 1.53
{

	int				task_len			= 0;
	int				k,j					= 0;
	int				st_ok_Flg			= 0;
	int				cnt_next			= 0;
	int				count_task			= 0;
	int				cnt_tk				= 0;
	int				count_dml_1			= 0;
	int				st_count_dml		= 0;
	int				NextRevFlagDml		= 0;
	int				flagerror			= 0;
	int				st_count			= 0;
	int				dmlstlst			= 0;
	int				control_number_found= 0;
	int				cntCntrl			= 0;
	int				iCntl				= 0;
	int				status				= 0;

	//char			*inp_Plant			= NULL;
	//char			*tsk_Plant			= NULL;
	char			*Part_no			= NULL;
	char			*Desc_obj_lt_Rev	= NULL;
	char			*Desc_obj_Inp_Part	= NULL;
	char			*part_DRStatus		= NULL;
	char			*WSO_Name_next_Rev	= NULL;
	char			*ReleaseStatusDML	= NULL;
	char			*TaskId				= NULL;
	char			*Revision			= NULL;
	char			*Temp				= NULL;
	char			*attchdPart			= NULL;
	char			*SubSyscd			= NULL;

	//API change
	//char			type_class[TCTYPE_name_size_c+1];
	char *type_class = NULL;

	char			type_dml[TCTYPE_name_size_c+1];

	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;

	tag_t			AssyTag				= NULLTAG;
	tag_t			master				= NULLTAG;
	tag_t			latestrev			= NULLTAG;
	tag_t			relation_type_task	= NULLTAG;
	tag_t			PartTskTag			= NULLTAG;
	tag_t			itemTypeTag_class	= NULLTAG;
	tag_t			tsk_dml_rel_type_1	= NULLTAG;
	tag_t			DMLRevTag_Prt		= NULLTAG;
	tag_t			itemTypeTag_Dml		= NULLTAG;

	tag_t*			status_list			= NULLTAG;
	tag_t*			dml_status_list		= NULLTAG;
	tag_t*			PartTaskTags		= NULLTAG;
	tag_t*			DMLRevision_Prt		= NULLTAG;
	tag_t*			list_of_WSO_cntrl_tags= NULLTAG;

	char LcsStdWrkg[40];
	char LcsStdRlzd[40];
	char lcsAplRlzd[40];
	char inp_Plant[40];
	char tsk_Plant[40];
	char LcsAplWrkg[40];
	

	WSO_search_criteria_t  	criteria_Gcontrol;

	logical			is_latest_dml;

				printf("\n ############Inside Next_Rev_Gt_DR3_Exists_Check : Next revision DML with STDSI Check###########");fflush(stdout);
				task_len=0;
				task_len=strlen(itemid);
				printf("\t  task_len ...%d\n", task_len);// length task
				GetPlantForDMLORTask(itemid,inp_Plant);
				//inp_Plant=subString(itemid,14,task_len);
				printf("\t  inp_Plant after  ...%s\n", inp_Plant);

				char  ItemIDCpy[40];
				tc_strcpy(ItemIDCpy,itemid);
				GetPlantWiseRelStat(ItemIDCpy,LcsStdWrkg,LcsStdRlzd);
				printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
				printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);

				GetPlantWiseRelStatAtAPL(ItemIDCpy,LcsAplWrkg,lcsAplRlzd); //TZ3.46	
				printf("\n LcsAplWrkg:%s",LcsAplWrkg);fflush(stdout);
				printf("\n lcsAplRlzd:%s",lcsAplRlzd);fflush(stdout);
	
//				printf( "item_id:%s\n", ItemIDCpy);
//				Dsgn_No=tc_strtok(ItemIDCpy,"_");
//				printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,ItemIDCpy);
//				Dsgn_No = tc_strtok(NULL,"_");
//				printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,ItemIDCpy);
//				PLT_Code = tc_strtok(NULL,"_");
//				printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,ItemIDCpy);

//				if(tc_strcmp(PLT_Code,"APLP")==0)
//				{
//				strcpy(lcsAplRlzd,"T5_LcsAplpRlzd");
//			   }else
//				if(tc_strcmp(PLT_Code,"APLV")==0)
//				{
//				strcpy(lcsAplRlzd,"T5_LcsAplvRlzd");
//				}else
//				if(tc_strcmp(PLT_Code,"APLD")==0)
//				{
//				strcpy(lcsAplRlzd,"T5_LcsApldRlzd");
//				}else
//				if(tc_strcmp(PLT_Code,"APLC")==0)
//				{
//				strcpy(lcsAplRlzd,"T5_LcsAplRlzd");
//				}else
//				if(tc_strcmp(PLT_Code,"APLJ")==0)
//				{
//				strcpy(lcsAplRlzd,"T5_LcsApljRlzd");
//				}else
//				if(tc_strcmp(PLT_Code,"APLL")==0)
//				{
//				strcpy(lcsAplRlzd,"T5_LcsApllRlzd");
//				}else
//				if(tc_strcmp(PLT_Code,"APLA")==0)
//				{
//				strcpy(lcsAplRlzd,"T5_LcsAplaRlzd");
//				}else
//				if(tc_strcmp(PLT_Code,"APLU")==0)
//				{
//				strcpy(lcsAplRlzd,"T5_LcsApluRlzd");
//				}else
//				if(tc_strcmp(PLT_Code,"APLS")==0)
//				{
//				strcpy(lcsAplRlzd,"T5_LcsAplsRlzd");
//				}else
//				{
//				strcpy(lcsAplRlzd,"T5_LcsAplRlzd");
//				}

	//			printf("\n lcsAplRlzd:%s",lcsAplRlzd);fflush(stdout);

				//########Validation made control object based as in TCE#####//
				WSOM_clear_search_criteria(&criteria_Gcontrol);
				strcpy(criteria_Gcontrol.name,"NxtRevDrChk");
				strcpy(criteria_Gcontrol.class_name,"T5_ControlObject");
				status	= WSOM_search(criteria_Gcontrol, &control_number_found, &list_of_WSO_cntrl_tags);
				printf("\ncontrol_number_found : %d",control_number_found);fflush(stdout);
				if (control_number_found>0)
				{
					cntCntrl	=	0;
					for (iCntl=0;iCntl<control_number_found;iCntl++ )
					{
						AOM_ask_value_string( list_of_WSO_cntrl_tags[iCntl], "t5_SubSyscd", &SubSyscd);
						printf("\n\nSubSyscd : %s",SubSyscd);fflush(stdout);
						if ((tc_strcmp(SubSyscd,"Live")==0))
						{
							cntCntrl++;
							MEM_free(list_of_WSO_cntrl_tags);
							break;
						}
					}
				}

				printf("\n cntCntrl:%d",cntCntrl);fflush(stdout);

				if(cntCntrl>0)
				{
					printf("\n Check to be executed as control object found");fflush(stdout);

				//###########################################################//

				if((tc_strstr(itemid,"PP")!=NULL || tc_strstr(itemid,"PM")!=NULL  || tc_strstr(itemid,"JP")!=NULL  || tc_strstr(itemid,"JM")!=NULL  || tc_strstr(itemid,"LP")!=NULL  || tc_strstr(itemid,"LM")!=NULL))
				{
					for (k=0;k<PartCnt ;k++ )
					{				

						printf("\n\n\t\t for k =:%d",k);fflush(stdout);
						AssyTag=PartTags[k];
						latestrev=NULLTAG;
						NextRevFlagDml=0;

						ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
						printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);

						//Added By Dhanashri for skip prev rev UATZ1.42//
						 char*			SkipPrevRevSTD				= NULL;
						 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
						  printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
						 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
					
							//if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
							if(tc_strlen(SkipPrevRevSTD)>0)
							{
								printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
								continue;
							}
						//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

						if (AOM_ask_value_string(AssyTag,"current_revision_id",&Desc_obj_Inp_Part)==ITK_ok)
						printf("\n Desc_obj_Inp_Part Value is :  %s\n",Desc_obj_Inp_Part);

//						if( AOM_ask_value_string(AssyTag,"t5_PartStatus",&part_DRStatus)==ITK_ok)
//						printf("\n part_DRStatus Value :  %s\n",part_DRStatus);
//
//						if((!tc_strcmp(part_DRStatus,"DR0")) || (!tc_strcmp(part_DRStatus,"DR1")) || (!tc_strcmp(part_DRStatus,"DR2")) || (!tc_strcmp(part_DRStatus,"DR3")))
//						continue;
//
//						if( (strlen(part_DRStatus)==0) || !tc_strcmp(part_DRStatus,"DR4") || !tc_strcmp(part_DRStatus,"DR5")|| !tc_strcmp(part_DRStatus,"NA") || !tc_strcmp(part_DRStatus,"AR4") || !tc_strcmp(part_DRStatus,"AR5"))
//						//if( !tc_strcmp(part_DRStatus,"DR4") || !tc_strcmp(part_DRStatus,"DR5")|| !tc_strcmp(part_DRStatus,"NA") || !tc_strcmp(part_DRStatus,"AR4") || !tc_strcmp(part_DRStatus,"AR5"))
//						{

//							if(ITEM_ask_item_of_rev ( AssyTag,&master) );//Commented in TZ1.43
//							if(ITEM_ask_latest_rev(master,&latestrev));//Commented in TZ1.43

							tm_fnd_Next_revision(Part_no,AssyTag,&latestrev); //TZ1.43



							if(latestrev != NULLTAG)
							{
								if (AOM_ask_value_string(latestrev,"current_revision_id",&Desc_obj_lt_Rev)==ITK_ok)
								printf("\n Desc_obj_lt_Rev Value is : %s\n",Desc_obj_lt_Rev);

								if( AOM_ask_value_string(latestrev,"t5_PartStatus",&part_DRStatus)==ITK_ok)
								printf("\n part_DRStatus Value :  %s\n",part_DRStatus);

								if((!tc_strcmp(part_DRStatus,"DR0")) || (!tc_strcmp(part_DRStatus,"DR1")) || (!tc_strcmp(part_DRStatus,"DR2")) || (!tc_strcmp(part_DRStatus,"DR3")) || (!tc_strcmp(part_DRStatus,"AR0")) || (!tc_strcmp(part_DRStatus,"AR1")) || (!tc_strcmp(part_DRStatus,"AR2")) || (!tc_strcmp(part_DRStatus,"AR3")) )
								continue;

								if( (strlen(part_DRStatus)==0) || !tc_strcmp(part_DRStatus,"DR4") || !tc_strcmp(part_DRStatus,"DR5")|| !tc_strcmp(part_DRStatus,"NA") || !tc_strcmp(part_DRStatus,"AR4") || !tc_strcmp(part_DRStatus,"AR5") || !tc_strcmp(part_DRStatus,"DR3P") || !tc_strcmp(part_DRStatus,"AR3P"))
								{

								if (AOM_ask_value_string(latestrev,"item_revision_id",&Revision)==ITK_ok)
								printf("\n Revision Value is : %s\n",Revision);

								if(tc_strcmp(Desc_obj_Inp_Part,Desc_obj_lt_Rev)==0)
								{
									printf("Task Part object is latest ..");fflush(stdout);
								}
								else
								{
									printf("Task Part object is not latest ..");fflush(stdout);

									ITKCALL(WSOM_ask_release_status_list(latestrev,&st_count,&status_list));
									printf("\n st_count :%d is\n",st_count);fflush(stdout);

									if(st_count>0)
											{
												st_ok_Flg=0;
												for (cnt_next=0;cnt_next< st_count;cnt_next++ )
												{
													WSO_Name_next_Rev=NULL;
													ITKCALL(AOM_ask_name(status_list[cnt_next],&WSO_Name_next_Rev));
													printf("\n WSO_Name_next_Rev is :%s\n",WSO_Name_next_Rev);fflush(stdout);

													if ((tc_strcmp(WSO_Name_next_Rev,lcsAplRlzd)==0)||(tc_strcmp(WSO_Name_next_Rev,LcsStdWrkg)==0) || (tc_strcmp(WSO_Name_next_Rev,LcsStdRlzd)==0))
													{
														st_ok_Flg=1;
													}

												}
												if(st_ok_Flg==1)
												{
													GRM_find_relation_type("CMHasSolutionItem",&relation_type_task);
													GRM_list_primary_objects_only(latestrev,relation_type_task,&count_task,&PartTaskTags);
													if(count_task >0)
													{
														//NextRevFlagDml=0;
														for (cnt_tk=0;cnt_tk<count_task ;cnt_tk++ )
														{
															PartTskTag=PartTaskTags[cnt_tk];
															ITKCALL (TCTYPE_ask_object_type(PartTskTag,&itemTypeTag_class));
															ITKCALL (TCTYPE_ask_name2(itemTypeTag_class,&type_class));

															printf("\t  type_class ...%s\n", type_class);
															if(tc_strcmp(type_class,"T5_APLTaskRevision")==0)
															{
																ITKCALL(AOM_ask_value_string(PartTskTag, "item_id",&TaskId));
																printf("\n TaskId %s.....\n",TaskId);

																if(tc_strstr(TaskId,"APL")==NULL) continue;
																if(tc_strstr(TaskId,"_PR")!=NULL) continue;

																//tsk_Plant=subString(TaskId,14,strlen(TaskId));
																GetPlantForDMLORTask(TaskId,tsk_Plant);
																printf("\t  tsk_Plant after  ...%s\n", tsk_Plant);
																
																if(tc_strcmp(inp_Plant,tsk_Plant)==0)
																{
																	//ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type_1));
																	//if (tsk_dml_rel_type_1!=NULLTAG)
																	//{
																		//ITKCALL(GRM_list_primary_objects_only(PartTskTag,tsk_dml_rel_type_1,&count_dml_1,&DMLRevision_Prt));
																		//printf("\n\n\t\t DML Revision from Task : %d",count_dml_1);fflush(stdout);

																		//for (j=0;j<count_dml_1 ;j++ )
																		//{
																		//	ITKCALL(ITEM_rev_sequence_is_latest(DMLRevision_Prt[j],&is_latest_dml));
																		//	printf("\n\n\t\t is_latest_dml : %d\n",is_latest_dml);fflush(stdout);

																		//	if(is_latest_dml != true)
																		//	{
																			//	printf("\n\n\t\t is_latest_dml is not true .....\n");fflush(stdout);
																		//	}else
																			//{
																			//	DMLRevTag_Prt = DMLRevision_Prt[j];

																			//	ITKCALL (TCTYPE_ask_object_type(DMLRevTag_Prt,&itemTypeTag_Dml));
																			//	ITKCALL (TCTYPE_ask_name(itemTypeTag_Dml,type_dml));

																				//if(tc_strcmp(type_dml,"T5_APLDMLRevision")==0)
																				//{
																					//ITKCALL(WSOM_ask_release_status_list(DMLRevTag_Prt,&st_count_dml,&dml_status_list));
																					ITKCALL(WSOM_ask_release_status_list(PartTskTag,&st_count_dml,&dml_status_list));
																					for (dmlstlst = 0; dmlstlst < st_count_dml; dmlstlst++)
																					{
																						AOM_ask_name(dml_status_list[dmlstlst], &ReleaseStatusDML);
																						printf("\n ReleaseStatusDML %s \n",  ReleaseStatusDML);fflush(stdout);
																						if(tc_strcmp(ReleaseStatusDML,LcsStdRlzd)==0)
																						{
																							NextRevFlagDml=1;
																							break;
																						}
																					}																						
																				//}
																			//}
																		//}
																	//}
																}
															}
														}
													}

														if(NextRevFlagDml==0)
														{			

															attchdPart=NULL;
															attchdPart=(char *)MEM_alloc(1000);

															Temp=NULL;
															Temp=(char *)MEM_alloc(1000);												
															
															tc_strcpy(Temp,"\nNext Official Revision ");
															tc_strcat(Temp,Part_no);
															tc_strcat(Temp,",");
															tc_strcat(Temp,Revision);
															tc_strcat(Temp,",DR Status-");
															tc_strcat(Temp,part_DRStatus);
															tc_strcat(Temp," of part ");
															tc_strcat(Temp,Part_no);
															tc_strcat(Temp," exists with DR status > DR3. So, please release latest revision only.");															
															tc_strcpy(attchdPart,Temp);

															printf("%s",attchdPart); fflush(stdout);

															//tc_strcat(SetStdRelErr,attchdPart);	
															setAddStrFuction(icount,SetStdRelErr,attchdPart); //added by dss 1.53
															cntFlag = 1;

														}

												}//st_ok_flg end
											}
								}
							}
							else
								{
									printf("\n Next revision Part DR status:%s, which is not greater than DR3",part_DRStatus);fflush(stdout);
								}
						}
						else
							{
								printf("\n No next revision of part");fflush(stdout);
							}
//						}
//						else
//						{
//							printf("\n Part DR status:%s",part_DRStatus);fflush(stdout);
//						}
					}
				}
				}
				else
				{
					printf("\n Control object not found for check execution");fflush(stdout);
				}

			

			return 0;

}

//Added by dss 1.54 // 
int tm_BOMResolveForAPLModulesFunc(tag_t SVRTag, char* itemid,char* revrule, char* closurerulename ,char* BVRInfo2,char	***SetChildRelErr, int *icount2)
{

	//int		ifail 				=   ITK_ok;
	char	*tasknumber			=	NULL;
	char	*type_name			=	NULL;
	char	*type_nameP			=	NULL;
	char	*type_name2			=	NULL;
	char	*tsk_object_name	=	NULL;
	char	*ClrSVROnly			=	NULL;
	char	*tmpSVR				=	NULL;
	char	*nonClrSvr			=	NULL;
	char	*clrSlr				=	NULL;
	char	*qry_entries3[1]	= {"Name"};
	char	*qry_entries10[1]	= {"ID"};
	//char	*itemid;
	char	*svrName			=	NULL;
	char	*t5_SchmPlant		=	NULL;
	char	*t5_ClSrl			=	NULL;
	char	*arch_item_id		=	NULL;
	char	*Archtype_name		=	NULL;
	char	**rulename			=	NULL;
	char	**rulevalue			=	NULL;
	char	*item_Rev_Seq		=	NULL;
	char	*StagePartNo		=	NULL;
	char	*Stage_item_Rev_Seq	=	NULL;
	char	*StagePartType		=	NULL;
	char	*ModPartNo			=	NULL;
	char	*ModPartType		=	NULL;
	char	*ModPartLine		=	NULL;
	char	*ModItem_Rev		=	NULL;
	char	*ModItem_Seq		=	NULL;
	char	*ChildColInd		=	NULL;
	char	*Item_ID_str		=	NULL;
	char	*ModPartAct			=	NULL;

	char	**valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));
	char	**valuesPlatfrom = (char **) MEM_alloc(1 * sizeof(char *));

	char			*Temp				= NULL;

	date_t  eff_date;

	tag_t	objTypeTag			=	NULLTAG;
	tag_t	ItemTypeTag			=	NULLTAG;
	tag_t	*PartTags			=	NULLTAG;
	tag_t	t_svr				=	NULLTAG;
	tag_t	ClrVariqueryTag		=	NULLTAG;
	tag_t	*ColVRule_tags		=	NULLTAG;
	tag_t	*t5_clrscm			=	NULLTAG;
	tag_t	PlatformTag			=	NULLTAG;
	tag_t	*tags_found			=	NULLTAG;
	tag_t	item_tag			=	NULLTAG;
	tag_t	PlatformTypeTag		=	NULLTAG;
	tag_t	PlatformRevTag		=	NULLTAG;
	tag_t	PlatformRevTypeTag	=	NULLTAG;
	tag_t   e_block				=	NULLTAG;
	tag_t	*lines2				=	NULLTAG;
	tag_t	*lines3				=	NULLTAG;
	tag_t	PartChildobj		=	NULLTAG;
	tag_t	StageChildobj		=	NULLTAG;
	tag_t   t_ChildItemRev		=	NULLTAG;


	int		PartCnt			=	0;
	int		n_entriesV		=	1;
	int		n_entriesP		=	1;
	int		n_tags_found	=	0;
	int		n_count			=	0;
	int		ClrCnt = 0;
	int		iSVR = 0;
	int		count_clrscm	=	0;
	int		rulefound		=	0;
	int		count			=	0;
	int		ichld			=	0;
	int		n_lines2		=	0;
	int		n_lines3		=	0;
	int		iMod			=	0;
	int		iMod1			=	0;
	int		NonClrPartlevel =	0;
	int		iChildItemTag	=   0;
	int		Revformula;
	const char *qry_entries[1];
	const char *qry_values[1];
	struct	BomChldStrut	ChldStrutBdySh[5000];
	
	tag_t	*itemclass			=	NULLTAG;
	tag_t	item				=	NULLTAG;
	tag_t	tsk_HSI_rel_type	=	NULLTAG;
	tag_t	t5_appl_SVR			=	NULLTAG;
	tag_t	item_rev_tag		=	NULLTAG;
	tag_t	bom_wnd				=	NULLTAG;
	tag_t	rule				=	NULLTAG;
	tag_t	*closurerule		=	NULLTAG;
	tag_t	close_tag			=	NULLTAG;
	//API change
	int p_count = 0;
	tag_t   *bom_variant_rule	=	NULLTAG;
	tag_t  	objTypeTag1			=	NULLTAG;
	tag_t	top_lne				=	NULLTAG;
	tag_t	*ArchNodeLines		=	NULLTAG;
	tag_t	VarientRuletag		=	NULLTAG;
	tag_t	*ColIndChilds		=	NULLTAG;
	tag_t	Childobject			=	NULLTAG;
	char   *taskowning_groupVal =	NULL;
char cCurrentAccessDate[20]={0};
char cCurrentAccessDate1[20]={0};
	logical  	verdict;
	
	int countstmnt=0;
	int countstmnt1=0;
	char			*attchdPart			= NULL;


	char    *qry_entryCntrlformat[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrlformat= (char **) MEM_alloc(5 * sizeof(char *));
	tag_t   qryTagCntrlobj     = NULLTAG;
	int     n_entryCntrlobj    = 3;

			int controlObjfound=0;
			tag_t *list_of_cntrl_tags=NULLTAG;

			if(QRY_find2("Control Objects...", &qryTagCntrlobj));
			if (qryTagCntrlobj)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrlformat[0]="BOMResolvedForSVRChk";
				qry_valuesCntrlformat[1]="Live";
				qry_valuesCntrlformat[2]="0";
				
				if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
			}
			else
			{
				printf("\n Control Object Query not Found for tm_BOMResolveForAPLModules... \n");fflush(stdout);
			}	
			
			printf("\n controlObjfound for tm_BOMResolveForAPLModules is : %d\n",controlObjfound);fflush(stdout);

			if(controlObjfound>0)
			{
				char *sinfo2 	   = NULL;
				AOM_ask_value_string( list_of_cntrl_tags[0], "t5_Userinfo2", &sinfo2);
				printf("\n\n\t\t sinfo2 : %s\n",sinfo2);fflush(stdout);


				if(tc_strcmp(sinfo2,"STD")==0)
				{
						char *pltfrm 	   = NULL;
						AOM_ask_value_string( list_of_cntrl_tags[0], "t5_Userinfo3", &pltfrm);
						printf("\n\n\t\t sinfo3 : %d\n",pltfrm);fflush(stdout); // info3 contains platform
						printf("\npltfrm ...%s\n", pltfrm);fflush(stdout);

						char *sinfo4 	   = NULL;
						AOM_ask_value_string( list_of_cntrl_tags[0], "t5_Userinfo4", &sinfo4); // info4 contains MB4Z01
						printf("\n\n\t\t sinfo4 : %s\n",sinfo4);fflush(stdout); 

						char *sinfo5 	   = NULL;
						AOM_ask_value_string( list_of_cntrl_tags[0], "t5_Userinfo5", &sinfo5); // info5 contains MB5Z01
						printf("\n\n\t\t sinfo5 : %s\n",sinfo5);fflush(stdout); 

						char *sinfo6 	   = NULL;
						AOM_ask_value_string( list_of_cntrl_tags[0], "t5_Userinfo6", &sinfo6); // info6 contains PB
						printf("\n\n\t\t sinfo6 : %s\n",sinfo6);fflush(stdout); 

						char *sinfo7 	   = NULL;
						AOM_ask_value_string( list_of_cntrl_tags[0], "t5_Userinfo7", &sinfo7); // info7 contains TB
						printf("\n\n\t\t sinfo7 : %s\n",sinfo7);fflush(stdout); 

						char *svr 	   = NULL;
						ITKCALL(AOM_ask_value_string(SVRTag,"current_name",&svr));
						printf("\n\n\t\t svr  is :%s",svr); fflush(stdout);

						//char	*cGroupname							=	NULL;
						//tm_GetGroupFromDML(itemid, &cGroupname);
						//printf("\n hi Role Name :%s",cGroupname);fflush(stdout);

						//char	revrule[40];
						//char	BVRInfo2[40];
						//char	Info3[40];

						//get_CtrlVal_APLLcsInf(cGroupname,revrule,BVRInfo2,Info3);
						printf("\n hi Revision Rule : %s , BVR : %s ",revrule,BVRInfo2);fflush(stdout);

						printf("\nclosurerulename ...%s\n", closurerulename);fflush(stdout);
						
						
						if(QRY_find2("Platform", &PlatformTag));
						if (PlatformTag) 
						{ 
							printf("\nFound Query PlatformTag"); fflush(stdout); 
						}
						else 
						{
							printf("\nNot Found Query PlatformTag"); fflush(stdout);		
							return 0;
						}
						printf("\nPlatform : %s",pltfrm); fflush(stdout);
						valuesPlatfrom[0] = pltfrm;//Platform	
						if(QRY_execute(PlatformTag, n_entriesP, qry_entries10, valuesPlatfrom, &n_tags_found, &tags_found));
						printf("\n\n\n Platform count is-------->  : %d",n_tags_found);fflush(stdout);
						if (n_tags_found > 0)
						{		
							item_tag = tags_found[0];//Platform Tag

							ITKCALL(TCTYPE_ask_object_type(item_tag,&PlatformTypeTag));
							ITKCALL(TCTYPE_ask_name2(PlatformTypeTag,&type_nameP));
							printf("\n Platform name------> %s\n",type_nameP);fflush(stdout);
							
							ITKCALL(ITEM_ask_latest_rev(item_tag , &PlatformRevTag));
							ITKCALL(TCTYPE_ask_object_type(PlatformRevTag,&PlatformRevTypeTag));
							ITKCALL(TCTYPE_ask_name2(PlatformRevTypeTag,&type_name2));
							printf("\n Platform name2------> %s\n",type_name2);fflush(stdout);

							if(tc_strcmp(type_name2,"T5_PlatformRevision")==0)
							{
								nonClrSvr	=	(char	*)MEM_alloc(50);
								tc_strcpy(nonClrSvr,svr);		
								printf("\nnonClrSvr : %s",nonClrSvr);fflush(stdout);

								//Query Variant Rule
								if(QRY_find2("VariantRule", &ClrVariqueryTag));

								if (ClrVariqueryTag)
								{
									printf("\nFound Query VariantRule"); fflush(stdout);
								}else
								{
									printf("\nNot Found Query VariantRule"); fflush(stdout);			
									return 0;
								}

								valuesNonColSvr[0] = nonClrSvr;
								if(QRY_execute(ClrVariqueryTag, n_entriesV, qry_entries3, valuesNonColSvr, &ClrCnt, &ColVRule_tags));
								printf("\n Colour VariantRule count is-------->  : %d",ClrCnt);fflush(stdout);

								if(ClrCnt)
								{
									getCurrentDateTime(cCurrentAccessDate);
									printf("\n Before exploding time is : %s\n",cCurrentAccessDate);

									VarientRuletag	=	NULLTAG;
									svrName			=	NULL;
									VarientRuletag	=	ColVRule_tags[0];//Variant Rule Tag
									
									ITKCALL(AOM_ask_value_string(VarientRuletag, "object_name",&svrName));
									printf("\n svrName : %s",svrName);fflush(stdout);

									//printf("\n eff_date_temp:%s",eff_date_temp);

									//CALLAPI(ITK_string_to_date(eff_date_temp, &eff_date ));

									printf("\n eff_date Date Set");fflush(stdout);
									
									ITKCALL(BOM_create_window(&bom_wnd ));
									//ITKCALL(CFM_find("ERC release and above APLC", &rule));
									ITKCALL(CFM_find(revrule, &rule));
									ITKCALL(BOM_set_window_config_rule(bom_wnd, rule));


									//ITKCALL(AOM_refresh(rule, TRUE));
									
									//ITKCALL(CFM_rule_set_date(rule, eff_date));

									//ITKCALL(AOM_refresh(rule, FALSE));				


									//ITKCALL(PIE_find_closure_rules("BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
									//API change
									//ITKCALL(PIE_find_closure_rules(closurerulename,PIE_TEAMCENTER, &rulefound, &closurerule ));
									ITKCALL(PIE_find_closure_rules2(closurerulename,PIE_TEAMCENTER, &rulefound, &closurerule )); 
									printf ("\nrule count %d \n",rulefound);fflush(stdout);
									if (rulefound > 0)
									{
										close_tag = closurerule[0];
										printf ("closure rule found \n"); fflush(stdout);
									}

										
									ITKCALL(BOM_window_set_closure_rule( bom_wnd,close_tag, 0, rulename,rulevalue ));
							
									ITKCALL(BOM_set_window_pack_all(bom_wnd, FALSE));
									ITKCALL(BOM_set_window_top_line( bom_wnd, NULLTAG, PlatformRevTag, NULLTAG, &top_lne ));
									//API change
									//ITKCALL(BOM_window_ask_variant_rule( bom_wnd, &bom_variant_rule ));
									ITKCALL(BOM_window_ask_variant_rules( bom_wnd,&p_count, &bom_variant_rule )); 

									ITKCALL(TCTYPE_ask_object_type(bom_variant_rule[0],&objTypeTag1));
									ITKCALL(TCTYPE_ask_name2(objTypeTag1,&Archtype_name));
									printf("\n Archtype_name------> %s\n",Archtype_name);fflush(stdout);

									ITKCALL( ITEM_ask_rev_variants ( PlatformRevTag, &e_block ));
									printf(" ITEM_ask_rev_variants..\n");fflush(stdout);


					/*
					int LPCpart,p1 = 0;
													int selectedPartPresent = 0;
													  tag_t  *LatestPchildPart=NULLTAG;
													  tag_t   LatestPchildPartobject=NULLTAG;
													  char* LatestP_child_item_id = NULL;
													if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
													//if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
													if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
													if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
													if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
													if(BOM_set_window_top_line (window, NULLTAG, latestParentAssyTag, NULLTAG, &top_line)!=ITK_ok)PrintErrorStack();
													printf("\n inside bom_window-----555\n"); fflush(stdout);
													if(BOM_line_ask_child_lines (top_line, &LPCpart, &LatestPchildPart));
													printf("\n\n\t\t No of child objects are n 555 : %d\n",LPCpart);fflush(stdout);
					*/
									//return ifail;//SEEEEEEEEEE
									int FlagPBPart=0;
									int FlagTBPart=0;

									if(top_lne!=NULLTAG)
									{
										ITKCALL(BOM_line_ask_child_lines(top_lne, &n_count, &ArchNodeLines));
										printf("\n n_count --------> : %d\n", n_count);

										ITKCALL(BOM_window_hide_unconfigured(bom_wnd));
										ITKCALL(BOM_window_show_variants(bom_wnd));
										ITKCALL(BOM_window_apply_variant_configuration(bom_wnd,1,&VarientRuletag));
										ITKCALL(BOM_window_hide_variants(bom_wnd));
										ITKCALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
										printf("\n count --------> : %d\n", count); fflush(stdout);//Find Architecture Node
												
										if (count >0)
										{
											FlagPBPart=0;   
											FlagTBPart=0;   
											for (ichld=0;ichld<count ;ichld++ )
											{
												if(Childobject) Childobject=NULLTAG;
												Childobject=ColIndChilds[ichld];

												ITKCALL(AOM_ask_value_string(Childobject, "bl_item_item_id", &arch_item_id ));
												printf("\n arch_item_id ..:%s\n",arch_item_id); fflush(stdout);
												
												//if(tc_strcmp(closurerulename,"BOMLineskipforunconfiguredAPLC")==0)
												//{
													//if((tc_strstr(arch_item_id,"MB4Z01")!=NULL) || (tc_strstr(arch_item_id,"MB5Z01")!=NULL))
													if((tc_strstr(arch_item_id,sinfo4)!=NULL) || (tc_strstr(arch_item_id,sinfo5)!=NULL))
													{
														//Find the APL modules and explode
														if(lines2) lines2=NULL;

														ITKCALL(BOM_line_ask_child_lines(Childobject, &n_lines2, &lines2));
														printf("\n Child parts count--> %d\n",n_lines2);fflush(stdout);

														if(n_lines2 > 0)
														{
															for (iMod=0;iMod<n_lines2 ;iMod++ )
															{
																if(PartChildobj) PartChildobj=NULLTAG;
																if(lines3) lines3=NULLTAG;
																n_lines3=0;
																if(ModPartNo) ModPartNo=NULL;
																if(item_Rev_Seq) item_Rev_Seq=NULL;
																if(ModPartType) ModPartType=NULL;
																if(taskowning_groupVal) taskowning_groupVal=NULL;
																
																PartChildobj=lines2[iMod];

																ITKCALL(AOM_ask_value_string(PartChildobj, "bl_item_item_id", &ModPartNo ));
																printf("\n No of Modules Under Architechtures --> : %s\n",ModPartNo); fflush(stdout);
																
																ITKCALL(AOM_ask_value_string(PartChildobj, "bl_rev_item_revision_id", &item_Rev_Seq));
																printf("\n item_Rev_Seq --> : %s\n",item_Rev_Seq); fflush(stdout);
																
																ITKCALL(AOM_ask_value_string(PartChildobj, "bl_Design_t5_RevPartType", &ModPartType ));
																printf("\n Part type Modules Under Architechtures --> : %s\n",ModPartType); fflush(stdout);
																
																iChildItemTag=0;
																t_ChildItemRev=NULLTAG;
																//API Change
																//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
																//BOM_line_ask_attribute_tag(PartChildobj, iChildItemTag, &t_ChildItemRev);

																AOM_ask_value_tag(PartChildobj,bomAttr_lineItemRevTag,&t_ChildItemRev);

																if(t_ChildItemRev!=NULLTAG)
																{
																	ITKCALL(AOM_UIF_ask_value(t_ChildItemRev,"owning_group",&taskowning_groupVal));											
																	printf("\n  taskowning_groupVal:%s ..............",taskowning_groupVal);fflush(stdout);
																	
																		n_lines3=0;
																		ITKCALL(Get_Part_BOM_Lvl(t_ChildItemRev,1,closurerulename,revrule,BVRInfo2,ChldStrutBdySh,&n_lines3));
																		printf("\n\t\t n_lines3:%d",n_lines3);fflush(stdout);
																	
																	printf("\n Stage Assembly count n_lines3--> %d\n",n_lines3);fflush(stdout);

																	getCurrentDateTime(cCurrentAccessDate1);
																	printf("\n After exploding till PB/TB time is : %s\n",cCurrentAccessDate1);

																	if(n_lines3 > 0)
																	{
																		for (iMod1=1;iMod1<=n_lines3 ;iMod1++ )
																		{
																			if(StageChildobj) StageChildobj=NULLTAG;	
																			if(StagePartNo) StagePartNo=NULL;
																			if(Stage_item_Rev_Seq) Stage_item_Rev_Seq=NULL;
																			if(StagePartType) StagePartType=NULL;
																			
																			StageChildobj=ChldStrutBdySh[iMod1].child_objs_bvr;
																			
																			ITKCALL(AOM_ask_value_string(StageChildobj, "bl_item_item_id", &StagePartNo ));
																			printf("\n StagePartNo --> : %s\n",StagePartNo); fflush(stdout);
																			
																			ITKCALL(AOM_ask_value_string(StageChildobj, "bl_rev_item_revision_id", &Stage_item_Rev_Seq));
																			printf("\n Stage_item_Rev_Seq --> : %s\n",Stage_item_Rev_Seq); fflush(stdout);
																			
																			ITKCALL(AOM_ask_value_string(StageChildobj, "bl_Design_t5_RevPartType", &StagePartType ));
																			printf("\n StagePartType --> : %s\n",StagePartType); fflush(stdout);
																			
																			//if(tc_strstr(StagePartNo,"PB")!=NULL || tc_strstr(StagePartNo,"TB")!=NULL)
																			if(tc_strstr(StagePartNo,sinfo6)!=NULL) // sinfo6 contains PB
																			{
																				printf("\n PB exists so no prob\n"); fflush(stdout);
																				FlagPBPart=1;
																				//Check Release Status, if APL Release np else Error
																				char LcsStdWrkg[40];
																				char LcsStdRlzd[40];
																				GetPlantWiseRelStat(itemid,LcsStdWrkg,LcsStdRlzd);
																				printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
																				printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);


																				int iChildItemTag=0;
																				tag_t t_ChildItemRev=NULLTAG;
																				//API change
																				//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
																				//BOM_line_ask_attribute_tag(StageChildobj, iChildItemTag, &t_ChildItemRev);

																				AOM_ask_value_tag(StageChildobj,bomAttr_lineItemRevTag,&t_ChildItemRev);


																				int	nCRItem			=	0;
																				int iChRItem		=	0;
																				tag_t		*CRitem_revs_tag		=	NULLTAG;

																				ITKCALL(AOM_ask_value_tags(t_ChildItemRev,"revision_list",&nCRItem,&CRitem_revs_tag));
																				printf("\nNo of CHild Item revisions : %d",nCRItem);fflush(stdout);

																				int st_ok_Flg=0;
																				for(iChRItem=nCRItem-1;iChRItem>=0;iChRItem--)
																				{
																					tag_t			ChRDsgnTag			=	NULLTAG;
																					char*			CPart_no			=	NULL;
																					char*			CPart_Rev			=	NULL;
																					
																					printf("\nNo of iChRItem : %d",iChRItem);fflush(stdout);
																					ChRDsgnTag=NULLTAG;
																					ChRDsgnTag	=	CRitem_revs_tag[iChRItem];

																					ITKCALL(AOM_ask_value_string(ChRDsgnTag,"item_id",&CPart_no));
																					printf("\n\n\t\t Child Part_no  is :%s",CPart_no);	fflush(stdout);

																					ITKCALL(AOM_ask_value_string(ChRDsgnTag,"item_revision_id",&CPart_Rev));
																					printf("\n\n\t\t Child Part_no  is :%s",CPart_Rev);	fflush(stdout);

																					tag_t*			status_list			= NULLTAG;
																					int st_count=0;
																					ITKCALL(WSOM_ask_release_status_list(ChRDsgnTag,&st_count,&status_list));
																					printf("\n st_count :%d is\n",st_count);fflush(stdout);

																					if(st_count>0)
																							{
																								int cnt_next=0;
																								st_ok_Flg=0;
																								for (cnt_next=0;cnt_next< st_count;cnt_next++ )
																								{
																									char			*WSO_Name_next_Rev	= NULL;
																									WSO_Name_next_Rev=NULL;
																									ITKCALL(AOM_ask_name(status_list[cnt_next],&WSO_Name_next_Rev));
																									printf("\n WSO_Name_next_Rev is :%s\n",WSO_Name_next_Rev);fflush(stdout);

																									if ((tc_strcmp(WSO_Name_next_Rev,LcsStdRlzd)==0))
																									//if ((tc_strcmp(WSO_Name_next_Rev,"LcsAplpRlzd")==0))
																									{
																										st_ok_Flg=1;
																										printf("\n st_ok_Flg set to 1 ...");fflush(stdout);
																										break;

																									}

																								}
																																																
																							  }//if(st_count>0)
																						if(st_ok_Flg==1)
																						{
																							printf("\n hi st_ok_Flg set to 1 ...");fflush(stdout);
																							break;
																						}

																				}

																				if(st_ok_Flg==0)
																				{														
																					attchdPart=NULL;
																					attchdPart=(char *)MEM_alloc(1000);

																					Temp=NULL;
																					Temp=(char *)MEM_alloc(1000);												
																																		
																					tc_strcpy(Temp,"\n");
																					tc_strcat(Temp,StagePartNo);
																												
																					tc_strcpy(attchdPart,Temp);

																					printf("attchdPart: %s",attchdPart); fflush(stdout);

																					if(countstmnt1==0)
																					{
																						char		*Temp11				= NULL;

																						Temp11=NULL;
																						Temp11=(char *)MEM_alloc(1000);												
																																			
																						tc_strcpy(Temp11,"\n");
																						tc_strcat(Temp11,"No any Revision of below mention PartNumber in SVR:[");
																						tc_strcat(Temp11,svr);
																						tc_strcat(Temp11,"] are not Release from STDSI");

																						setAddStrFuction(icount2,SetChildRelErr,Temp11);
																						countstmnt1++;
																						cntSVRFlag = 1;
																					}
																					//tc_strcat(SetStdRelErr,attchdPart);	
																					setAddStrFuction(icount2,SetChildRelErr,attchdPart);
																				}
																			}
																			
																			if(tc_strstr(StagePartNo,sinfo7)!=NULL) // sinfo7 contains TB
																			{
																				printf("\n TB exists so no prob\n"); fflush(stdout);
																				FlagTBPart=1;
																				//Check Release Status, if APL Release np else Error
																				//Check Release Status, if APL Release np else Error
																				char LcsStdWrkg[40];
																				char LcsStdRlzd[40];
																				GetPlantWiseRelStat(itemid,LcsStdWrkg,LcsStdRlzd);
																				printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
																				printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);


																				int iChildItemTag=0;
																				tag_t t_ChildItemRev=NULLTAG;
																				//API change
																				//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
																				//BOM_line_ask_attribute_tag(StageChildobj, iChildItemTag, &t_ChildItemRev);

																				AOM_ask_value_tag (StageChildobj,bomAttr_lineItemRevTag, &t_ChildItemRev);

																				int	nCRItem			=	0;
																				int iChRItem		=	0;
																				tag_t		*CRitem_revs_tag		=	NULLTAG;

																				ITKCALL(AOM_ask_value_tags(t_ChildItemRev,"revision_list",&nCRItem,&CRitem_revs_tag));
																				printf("\nNo of CHild Item revisions : %d",nCRItem);fflush(stdout);

																				int st_ok_Flg=0;
																				for(iChRItem=nCRItem-1;iChRItem>=0;iChRItem--)
																				{
																					tag_t			ChRDsgnTag			=	NULLTAG;
																					char*			CPart_no			=	NULL;
																					char*			CPart_Rev			=	NULL;
																					
																					printf("\nNo of iChRItem : %d",iChRItem);fflush(stdout);
																					ChRDsgnTag=NULLTAG;
																					ChRDsgnTag	=	CRitem_revs_tag[iChRItem];

																					ITKCALL(AOM_ask_value_string(ChRDsgnTag,"item_id",&CPart_no));
																					printf("\n\n\t\t Child Part_no  is :%s",CPart_no);	fflush(stdout);

																					ITKCALL(AOM_ask_value_string(ChRDsgnTag,"item_revision_id",&CPart_Rev));
																					printf("\n\n\t\t Child Part_no  is :%s",CPart_Rev);	fflush(stdout);

																					tag_t*			status_list			= NULLTAG;
																					int st_count=0;
																					ITKCALL(WSOM_ask_release_status_list(ChRDsgnTag,&st_count,&status_list));
																					printf("\n st_count :%d is\n",st_count);fflush(stdout);

																					if(st_count>0)
																							{
																								int cnt_next=0;
																								st_ok_Flg=0;
																								for (cnt_next=0;cnt_next< st_count;cnt_next++ )
																								{
																									char			*WSO_Name_next_Rev	= NULL;
																									WSO_Name_next_Rev=NULL;
																									ITKCALL(AOM_ask_name(status_list[cnt_next],&WSO_Name_next_Rev));
																									printf("\n WSO_Name_next_Rev is :%s\n",WSO_Name_next_Rev);fflush(stdout);

																									if ((tc_strcmp(WSO_Name_next_Rev,LcsStdRlzd)==0))
																									//if ((tc_strcmp(WSO_Name_next_Rev,"LcsAplpRlzd")==0))
																									{
																										st_ok_Flg=1;
																										printf("\n st_ok_Flg set to 1 ...");fflush(stdout);
																										break;

																									}

																								}
																																																
																							  }//if(st_count>0)
																						if(st_ok_Flg==1)
																						{
																							printf("\n hi st_ok_Flg set to 1 ...");fflush(stdout);
																							break;
																						}

																				}

																				if(st_ok_Flg==0)
																				{														
																					attchdPart=NULL;
																					attchdPart=(char *)MEM_alloc(1000);

																					Temp=NULL;
																					Temp=(char *)MEM_alloc(1000);												
																																		
																					tc_strcpy(Temp,"\n");
																					tc_strcat(Temp,StagePartNo);
																												
																					tc_strcpy(attchdPart,Temp);

																					printf("attchdPart: %s",attchdPart); fflush(stdout);

																					if(countstmnt1==0)
																					{
																						char		*Temp11				= NULL;

																						Temp11=NULL;
																						Temp11=(char *)MEM_alloc(1000);												
																																			
																						tc_strcpy(Temp11,"\n");
																						tc_strcat(Temp11,"No any Revision of below mention PartNumber in SVR:[");
																						tc_strcat(Temp11,svr);
																						tc_strcat(Temp11,"] are not Release from STDSI");

																						setAddStrFuction(icount2,SetChildRelErr,Temp11);
																						countstmnt1++;
																						cntSVRFlag = 1;
																					}
																					//tc_strcat(SetStdRelErr,attchdPart);	
																					setAddStrFuction(icount2,SetChildRelErr,attchdPart);
																				}
																			}

																		}
																	}
																}

															}//for loop
														}//if(n_lines2 > 0)
													}
												//}
											
											}
										}
										//error
										printf("\n FlagPBPart: %d", FlagPBPart); fflush(stdout);	
										printf("\n FlagTBPart: %d", FlagTBPart); fflush(stdout);	
										if(FlagPBPart==0)
										{
											attchdPart=NULL;
											attchdPart=(char *)MEM_alloc(1000);

											Temp=NULL;
											Temp=(char *)MEM_alloc(1000);												
																								
											tc_strcpy(Temp,"\n");
											tc_strcat(Temp,svr);
																																				
											tc_strcpy(attchdPart,Temp);

											printf("attchdPart: %s",attchdPart); fflush(stdout);

											if(countstmnt==0)
											{
												setAddStrFuction(icount2,SetChildRelErr,"\n PB Part not found under SVR: ");
												countstmnt++;
												cntSVRFlag = 1;
											}
											//tc_strcat(SetStdRelErr,attchdPart);	
											setAddStrFuction(icount2,SetChildRelErr,attchdPart);
				
										}

										if(FlagTBPart==0)
										{
											attchdPart=NULL;
											attchdPart=(char *)MEM_alloc(1000);

											Temp=NULL;
											Temp=(char *)MEM_alloc(1000);												
																								
											tc_strcpy(Temp,"\n");
											tc_strcat(Temp,svr);
																																				
											tc_strcpy(attchdPart,Temp);

											printf("attchdPart: %s",attchdPart); fflush(stdout);

											if(countstmnt==0)
											{
												setAddStrFuction(icount2,SetChildRelErr,"\n TB Part not found under SVR ");
												countstmnt++;
												cntSVRFlag = 1;
											}
											//tc_strcat(SetStdRelErr,attchdPart);	
											setAddStrFuction(icount2,SetChildRelErr,attchdPart);

										}
										// End error
										
									}
								}
								else
								{
									printf("\nSVR Not Query VariantRule"); fflush(stdout);	
								}
							}
						}
						else 
						{
							printf ("\n  Platform not found [%s]\n", t5_SchmPlant); fflush(stdout);	
						}

		
				} // if(tc_strcmp(sinfo1,"APL")==0)

			} //if(controlObjfound>0) 

}
//End of code Added by dss 1.54 // 

int GMDML_Part_Release_Check_STD(int PartCnt, tag_t* PartTags,char	***SetChildRelErr,int *icount,char* itemid)
{

	int				task_len			= 0;
	int				k,j					= 0;
	int				st_ok_Flg			= 0;
	int				cnt_next			= 0;
	int				count_task			= 0;
	int				cnt_tk				= 0;
	int				count_dml_1			= 0;
	int				st_count_dml		= 0;
	int				NextRevFlagDml		= 0;
	int				flagerror			= 0;
	int				st_count			= 0;
	int				dmlstlst			= 0;
	int				control_number_found= 0;
	int				cntCntrl			= 0;
	int				iCntl				= 0;
	int				status				= 0;

	//char			*inp_Plant			= NULL;
	//char			*tsk_Plant			= NULL;
	char			*Part_no			= NULL;
	char			*Desc_obj_lt_Rev	= NULL;
	char			*Desc_obj_Inp_Part	= NULL;
	char			*part_DRStatus		= NULL;
	char			*WSO_Name_next_Rev	= NULL;
	char			*ReleaseStatusDML	= NULL;
	char			*TaskId				= NULL;
	char			*Revision			= NULL;
	char			*Temp				= NULL;
	char			*attchdPart			= NULL;
	char			*SubSyscd			= NULL;

	char			type_class[TCTYPE_name_size_c+1];
	char			type_dml[TCTYPE_name_size_c+1];

	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			Part_Type2			= NULL;

	tag_t			AssyTag				= NULLTAG;
	tag_t			master				= NULLTAG;
	tag_t			latestrev			= NULLTAG;
	tag_t			relation_type_task	= NULLTAG;
	tag_t			PartTskTag			= NULLTAG;
	tag_t			itemTypeTag_class	= NULLTAG;
	tag_t			tsk_dml_rel_type_1	= NULLTAG;
	tag_t			DMLRevTag_Prt		= NULLTAG;
	tag_t			itemTypeTag_Dml		= NULLTAG;

	tag_t*			status_list			= NULLTAG;
	tag_t*			dml_status_list		= NULLTAG;
	tag_t*			PartTaskTags		= NULLTAG;
	tag_t*			DMLRevision_Prt		= NULLTAG;
	tag_t*			list_of_WSO_cntrl_tags= NULLTAG;
	
	int countstmnt=0;

	char LcsStdWrkg[40];
	char LcsStdRlzd[40];
	char lcsAplRlzd[40];
	char inp_Plant[40];
	char tsk_Plant[40];

	WSO_search_criteria_t  	criteria_Gcontrol;

	logical			is_latest_dml;

				printf("\n ############Inside GMDML_Part_Release_Check_STD : Next revision DML with STDSI Check###########");fflush(stdout);
				
				task_len=0;
				task_len=strlen(itemid);
				printf("\t  task_len ...%d\n", task_len);// length task
				GetPlantForDMLORTask(itemid,inp_Plant);
				//inp_Plant=subString(itemid,14,task_len);
				printf("\t  inp_Plant after  ...%s\n", inp_Plant);


				// Control Object Base 

					int cntt=0;
					int FlagGot=0;

					tag_t			CntrlTag		= NULLTAG;

					tag_t query1 = NULLTAG;
					int n_entries1=2;
					int n_found1=0;
  				    tag_t	*CntrlObjs	= NULLTAG;

					logical	delInd	= false;

					char *Info1 	   = NULL;

					char
					 *qry_entry[2] = {"SUBSYSCD", "SYSCD"},
					 *qry_vall[2] =  {"TODR", "LIVE"};

					//del indicator

					ITKCALL(QRY_find2("ControlObjQry", &query1));
					printf("\n After fins qryyy-- ");fflush(stdout);
					ITKCALL(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
					printf("\n n_found1: %d", n_found1);fflush(stdout);

					if(n_found1>0)
					{
						for (cntt = 0; cntt < n_found1; cntt++)
						{
							CntrlTag=NULLTAG;
							CntrlTag=CntrlObjs[cntt];

							AOM_ask_value_string( CntrlTag, "t5_Userinfo1", &Info1);
							printf("\n Info1: %s\n",Info1);fflush(stdout);

							AOM_ask_value_logical( CntrlTag, "t5_DelInd", &delInd);
							printf("\n delInd: %d\n",delInd);fflush(stdout);

							if(tc_strstr(Info1,inp_Plant)!=NULL &&  delInd==false)
							{
								printf("\n inside got plant .. ");fflush(stdout);
								FlagGot=1;
								break;
							}
				
						}

					}
					printf("\n FlagGot: %d", FlagGot);fflush(stdout);
				///

			 if(FlagGot==1)
			  {
				char  ItemIDCpy[40];
				tc_strcpy(ItemIDCpy,itemid);
				GetPlantWiseRelStat(ItemIDCpy,LcsStdWrkg,LcsStdRlzd);
				printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
				printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);				
	
				//###########################################################//

					for (k=0;k<PartCnt ;k++ )
					{				
						printf("\n\n\t\t for k =:%d",k);fflush(stdout);

						AssyTag=NULLTAG;
						AssyTag=PartTags[k];

						Part_no=NULL;
						ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
						printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);
	
						Revision=NULL;
						ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Revision));
						printf("\n\n\t\t Revision  is :%s",Revision);	fflush(stdout);

						//skip prev rev //
						 char*			SkipPrevRevSTD				= NULL;
						 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
						 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
						 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
					
							if(tc_strlen(SkipPrevRevSTD)>0)
							{
								printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
								continue;
							}
						//skip prev rev//

						ITKCALL(AOM_ask_value_string(AssyTag,"t5_PartType",&Part_Type2));
			printf("\n\n\t EPA Child Part String is Part_Type-->%s",Part_Type2);	fflush(stdout);
			if((strcmp(Part_Type2,"D")==0)|| (strcmp(Part_Type2,"DC")==0)|| (strcmp(Part_Type2,"DA")==0))
			{
				continue;
			}

									ITKCALL(WSOM_ask_release_status_list(AssyTag,&st_count,&status_list));
									printf("\n st_count :%d is\n",st_count);fflush(stdout);

									if(st_count>0)
											{
												st_ok_Flg=0;
												for (cnt_next=0;cnt_next< st_count;cnt_next++ )
												{
													WSO_Name_next_Rev=NULL;
													ITKCALL(AOM_ask_name(status_list[cnt_next],&WSO_Name_next_Rev));
													printf("\n WSO_Name_next_Rev is :%s\n",WSO_Name_next_Rev);fflush(stdout);

													if ((tc_strcmp(WSO_Name_next_Rev,LcsStdRlzd)==0))
													{
														st_ok_Flg=1;
													}

												}
												
												if(st_ok_Flg==0)
												{														
													attchdPart=NULL;
													attchdPart=(char *)MEM_alloc(1000);

													Temp=NULL;
													Temp=(char *)MEM_alloc(1000);												
																										
													tc_strcpy(Temp,"\n");
													tc_strcat(Temp,Part_no);
													tc_strcat(Temp,",");
													tc_strcat(Temp,Revision);
																											
													tc_strcpy(attchdPart,Temp);

													printf("attchdPart: %s",attchdPart); fflush(stdout);

													if(countstmnt==0)
													{
														setAddStrFuction(icount,SetChildRelErr,"\nBelow mention PartNumbers are not Release from STDSI, Please release through AMDML(created for GM DML)/Basic ERC DML:");
														countstmnt++;
														cntFlag = 1;
													}
													setAddStrFuction(icount,SetChildRelErr,attchdPart);
													
												}

										  }//if(st_count>0)
							}
						} //if(FlagGot==1)

			return 0;

}

int WTDML_Part_Release_Check_STD(int PartCnt, tag_t* PartTags,char	***SetChildErr,int *icount,tag_t TaskObj)
{
	
	int				task_len			= 0;
	int k=0;
	char inp_Plant[40];
	task_len=0;
	char			*taskNum				= NULL;
	
	
	ITKCALL(AOM_ask_value_string(TaskObj,"item_id",&taskNum);fflush(stdout));
	task_len=strlen(taskNum);
	
	printf("\t  task_len ...%d\n", task_len);// length task
	GetPlantForDMLORTask(taskNum,inp_Plant);
	printf("\t  inp_Plant after  ...%s\n", inp_Plant);
	
	char			*wtTemp				= NULL;
	char			*wtattchdPart			= NULL;
	
	for (k=0;k<PartCnt ;k++ )
		{
			tag_t			AssyTag				= NULLTAG;
			tag_t	latestrev	=	NULLTAG;
			tag_t UsePartMaster = NULLTAG;
			char *selectedname=NULL;
			char *aPrtNum=NULL;
			char *curentname=NULL;
			char *PrtType=NULL;
			char *PrtLcstate=NULL;
			char *PrtNum=NULL;
			
			printf("\n loop number=%d",PartCnt);fflush(stdout);
			
			AssyTag=PartTags[k];
			
			ITKCALL(AOM_UIF_ask_value(AssyTag,"item_id",&aPrtNum);fflush(stdout));
			printf("\n Part Number:%s ..............",aPrtNum);fflush(stdout);
			
			if(ITEM_find_item(aPrtNum,&UsePartMaster)!=ITK_ok);
			printf("\n selected part part UseMaster found------>");fflush(stdout);
			
			ITKCALL(ITEM_ask_latest_rev(UsePartMaster,&latestrev));
			if( AOM_ask_value_string(AssyTag,"object_string",&selectedname)==ITK_ok)
			printf("\n selected revision item tag---------------> %s\n",selectedname);fflush(stdout);

			if (latestrev!=NULLTAG)
			{
				if( AOM_ask_value_string(latestrev,"object_string",&curentname)==ITK_ok)
				printf("\n selected latest revision---------------> %s\n",curentname);fflush(stdout);
			}
			
			ITKCALL(AOM_ask_value_string(latestrev,"t5_PartType",&PrtType));
			printf("\n selected parts PrtType:%s ..............",PrtType);fflush(stdout);
			
			/*
			WT check for all types of part
			if ((tc_strcmp(PrtType,"A")==0)||(tc_strcmp(PrtType,"C")==0))
			{
				printf("\n Valid Assy/Component for [%s][%s] ",curentname,PrtType);fflush(stdout);
			}
			else
			{
				continue;
			}*/

			
			ITKCALL(AOM_UIF_ask_value(latestrev,"release_status_list",&PrtLcstate);fflush(stdout));
			printf("\n selected parts Lc State:%s ..............",PrtLcstate);fflush(stdout);
			
			
			ITKCALL(AOM_UIF_ask_value(latestrev,"item_id",&PrtNum);fflush(stdout));
			printf("\n selected parts Part Number:%s ..............",PrtNum);fflush(stdout);
		
			if(tc_strstr(PrtLcstate,"Obsolete")!=NULL)
			{
				
				printf("\n Part is already in Obsolete Vault in attached task task.");fflush(stdout);
				
				continue;
				
			}
			else
			 {
				printf("\n Part is not in Obsolete Vault.");fflush(stdout);
			 }
			 
			if(tc_strstr(PrtLcstate,"Released")==NULL)
			 {
				 printf("\n selected part error Pls checkin the latest Revision to Release Vault.");fflush(stdout);
				 													
				wtattchdPart=NULL;
				wtattchdPart=(char *)MEM_alloc(1000);

				wtTemp=NULL;
				wtTemp=(char *)MEM_alloc(1000);												
																	
				tc_strcpy(wtTemp," ");
				tc_strcat(wtTemp,"DML is for Transfering Part to Obsolete Vault, Ensure Latest Revision of Part must be in Release Vault.");
				tc_strcat(wtTemp,"\n");
				//tc_strcat(wtTemp,"Latest Revision of Part should be in Release Vault");
				//tc_strcat(wtTemp,"\n");
				tc_strcat(wtTemp,"Pls Contact ERC Latest Rev of ");
				tc_strcat(wtTemp,PrtNum);
				tc_strcat(wtTemp," is not in Release Vault.");
				tc_strcat(wtTemp,"\n");													
				tc_strcpy(wtattchdPart,wtTemp);

				printf("wtattchdPart: %s",wtattchdPart); fflush(stdout);
				
				setAddStrFuction(icount,SetChildErr,wtattchdPart);
			 }
			 
			 int n_parents=0;
			 int jd=0;
			int *levels = 0;
			tag_t *parents = NULLTAG;
			
			ITKCALL(PS_where_used_all(latestrev,1,&n_parents,&levels,&parents));
			printf("\n\t selected parts parents part (where_used count of objects are) : %d\n",n_parents); fflush(stdout);
				
			
			if(n_parents>0)
			{
			  for (jd=0;jd<n_parents;jd++ )
			  {
				char*	 ParentPartNum			= NULL;
				tag_t ParentAssyTagTypeTag=NULLTAG;
				tag_t ParentAssyTag = NULLTAG;
				//API change
				//char   ParentAssyTagType_name[TCTYPE_name_size_c+1];
				char *ParentAssyTagType_name = NULL;
				
				int n_PPrtTskCnt=0;
				tag_t *PPrtTskObjSO=NULLTAG;
				tag_t 	Ppart_tsk_rel_typ 	= NULLTAG;	
				int allowFlag=0;
	
				
				ParentAssyTag=parents[jd];
				ITKCALL(AOM_ask_value_string(ParentAssyTag,"item_id",&ParentPartNum));    //003915
				printf("\n\t selected part Parent Part number:%s",ParentPartNum);	fflush(stdout);

				if(TCTYPE_ask_object_type(ParentAssyTag,&ParentAssyTagTypeTag));
				if(TCTYPE_ask_name2(ParentAssyTagTypeTag,&ParentAssyTagType_name));
				printf("\n\t selected part Parent tag := %s", ParentAssyTagType_name);fflush(stdout); //ItemRevision

				if (tc_strcmp(ParentAssyTagType_name,"T5_ArchModuleRevision")==0)
				{
					
				}
				
				if(GRM_list_primary_objects_only(ParentAssyTag,Ppart_tsk_rel_typ,&n_PPrtTskCnt,&PPrtTskObjSO)!=ITK_ok)PrintErrorStack();
				printf("\n selected part's parent part's task n_PPrtTskCnt %d.\n",n_PPrtTskCnt); fflush(stdout);
				if (n_PPrtTskCnt > 0)
				{
					int j=0;
					for (j=0;j<n_PPrtTskCnt;j++ )
					{
						
						tag_t		PPrttsk_dml_rel_type	= NULLTAG;
						char*	 PPrtTasknum = NULL;
						int  PPrtdmlcount=0;
						tag_t*		PPrtDMLRevision			= NULLTAG;
						logical		is_latest;
						tag_t		PPrtDMLRevTag			= NULLTAG;
						tag_t PPrtclass_id1=NULLTAG;
						char *PPrtclass_name1= NULL;
						char *PPrtDmlName= NULL;
						char		*PPrtDMLtype				= NULL;
						
						if( AOM_ask_value_string(PPrtTskObjSO[j],"item_revision_id",&PPrtTasknum)==ITK_ok)
						printf("\n DmlNumb and Task name %s.\n",PPrtTasknum); fflush(stdout);
					
						ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &PPrttsk_dml_rel_type));
						
						if (PPrttsk_dml_rel_type!=NULLTAG)
						{
							
							ITKCALL(GRM_list_primary_objects_only(PPrtTskObjSO[j],PPrttsk_dml_rel_type,&PPrtdmlcount,&PPrtDMLRevision));
							printf("\n\n\t\t DML Revision from Task : %d",PPrtdmlcount);fflush(stdout);		//task to dml
							int dp=0;
							for (dp=0;dp<PPrtdmlcount ;dp++ )
								{
									ITKCALL(ITEM_rev_sequence_is_latest(PPrtDMLRevision[dp],&is_latest));
									printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);

									if(is_latest != true)
									{
										printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
									}else
									{
										PPrtDMLRevTag = PPrtDMLRevision[dp];//DML
										
										ITKCALL(POM_class_of_instance(PPrtDMLRevTag,&PPrtclass_id1));
										ITKCALL(POM_name_of_class(PPrtclass_id1,&PPrtclass_name1));
										printf("\n\n\t\t class_name found1 MR :%s",PPrtclass_name1);


										ITKCALL(AOM_ask_value_string(PPrtDMLRevTag, "item_id",&PPrtDmlName));
										printf("\n PPrtDmlName %s.....\n",PPrtDmlName);
										
										ITKCALL(AOM_ask_value_string(PPrtDMLRevTag,"t5_rlstype",&PPrtDMLtype));
										
										printf("\n PPrtDMLtype %s.....\n",PPrtDMLtype);

										if((tc_strcmp(PPrtclass_name1,"ChangeRequestRevision")==0) && (tc_strcmp(PPrtDMLtype,"WT")==0))
											{
											
												printf("\nt5AffdPartsVal.mth : Allowing to attach child part to WT task as parent is attached to other or same WT DML");fflush(stdout);
												allowFlag = 1;
												break;
											}
											else
											{
												printf("\n DR ");fflush(stdout);
											}
									}
								}
						
							
						}
					}//parent part taskfor loop
				}
				else
				{
					printf("\nt5AffdPartsVal.mth : Part Rev do not have task attached to it");
				}
				
				if ( allowFlag == 0 )
				{
					char *PPrtPrtNum=NULL;
					char *PPrtPrtType=NULL;
					char *PPrtLcstate=NULL;
					char *latestParentAssname=NULL;
					char *ParentAssyname=NULL;
					tag_t latestParentAssyTag = NULLTAG;
					 tag_t   window,rule,top_line = NULLTAG;
					ITKCALL(AOM_ask_value_string(ParentAssyTag, "item_id",&PPrtPrtNum));
					printf("\n PPrtPrtNum %s.....\n",PPrtPrtNum);fflush(stdout);
					
					ITKCALL(AOM_ask_value_string(ParentAssyTag, "t5_PartType",&PPrtPrtType));
					printf("\n PPrtPrtType %s.....\n",PPrtPrtType);fflush(stdout);
					
					ITKCALL(AOM_UIF_ask_value(ParentAssyTag,"release_status_list",&PPrtLcstate);fflush(stdout));
					printf("\n Part Lc State:%s ..............",PPrtLcstate);fflush(stdout);
					if( (tc_strcmp( PPrtPrtType,"CKDVC") == 0))//CKD vc
						{
							printf("allowing child of CKDVC Parents");
						}
						else if( (tc_strcmp( PPrtPrtType,"D") != 0))//not dummy
						{

							//ITKCALL(ITEM_ask_latest_rev(ParentAssyTag,&latestParentAssyTag));
							tag_t PPrtPrtMaster = NULLTAG;
							if(ITEM_find_item(PPrtPrtNum,&PPrtPrtMaster)!=ITK_ok)PrintErrorStack();
							printf("\n UseMaster found------>");fflush(stdout);
							
							ITKCALL(ITEM_ask_latest_rev(PPrtPrtMaster,&latestParentAssyTag));
							if( AOM_ask_value_string(ParentAssyTag,"object_string",&ParentAssyname)==ITK_ok)
							printf("\n selected parent revision---------------> %s\n",ParentAssyname);fflush(stdout);

							if (latestParentAssyTag!=NULLTAG)
							{
								if( AOM_ask_value_string(latestParentAssyTag,"object_string",&latestParentAssname)==ITK_ok)
								printf("\n latest revision---------------> %s\n",latestParentAssname);fflush(stdout);
							}

							if(tc_strcmp(latestParentAssname,ParentAssyname)!=0)
							{
								//EMH_store_error_s1(EMH_severity_error,ITK_err,"Please attach latest Parts to the task.");
								//return 1;
								
								//selected part's parent part's child part number to check weater selected part is present in child part or not
								
								int LPCpart,p1 = 0;
								int selectedPartPresent = 0;
								  tag_t  *LatestPchildPart=NULLTAG;
								  tag_t   LatestPchildPartobject=NULLTAG;
								  char* LatestP_child_item_id = NULL;
								if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
								//if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
								if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
								if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
								if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
								if(BOM_set_window_top_line (window, NULLTAG, latestParentAssyTag, NULLTAG, &top_line)!=ITK_ok)PrintErrorStack();
								printf("\n inside bom_window-----555\n"); fflush(stdout);
								if(BOM_line_ask_child_lines (top_line, &LPCpart, &LatestPchildPart));
								printf("\n\n\t\t No of child objects are n 555 : %d\n",LPCpart);fflush(stdout);
								
								if (LPCpart >0)
								{
									for (p1=0;p1<LPCpart ;p1++ )
									{
										LatestP_child_item_id = NULL;
										if(LatestPchildPartobject) LatestPchildPartobject=NULLTAG;
										LatestPchildPartobject=LatestPchildPart[p1];
										ITKCALL(AOM_ask_value_string(LatestPchildPartobject, "bl_item_item_id", &LatestP_child_item_id ));
										printf("\n\t Parents child part ===> :: %s",LatestP_child_item_id); fflush(stdout);
										printf("\n\t selected  part ===> :: %s",PPrtPrtNum); fflush(stdout);
										
										if(tc_strcmp(aPrtNum,LatestP_child_item_id)==0)
										{
											selectedPartPresent=1;
											printf("\n\t Design Object ===> :: %s",LatestP_child_item_id); fflush(stdout);
														
											char*	 LatestPPrtLcstate			= NULL;
											ITKCALL(AOM_UIF_ask_value(latestParentAssyTag,"release_status_list",&LatestPPrtLcstate);fflush(stdout));
											printf("\n Part Lc State:%s ..............",PrtLcstate);fflush(stdout);

											if(tc_strstr(LatestPPrtLcstate,"Obsolete")!=NULL)
											{
												
												printf("\n error latest parent Part is already in Obsolete Vault hence  allowed to attach to task.");fflush(stdout);	
											}

											else if(tc_strstr(LatestPPrtLcstate,"Released")!=NULL)
											 {
												 
												 int TaskCnt=0,partCnt=0,t=0,p=0;
												 tag_t		*SetOfDmlTasksTag		= NULLTAG;
												 tag_t		TaskRevTag			= NULLTAG;
												 tag_t		*SetOfPartTags			= NULLTAG;
												 tag_t PartTag = NULLTAG;
												 char *PartNum=NULL;
												 char *DmlId=NULL;
												 
												 printf("\n error Pls checkin the latest Revision to Release Vault.");fflush(stdout);
												// ITK_CALL(AOM_ask_value_string(DMLRev,"item_id",&DmlId));

													 AOM_ask_value_tags(TaskObj,"CMHasSolutionItem",&partCnt,&SetOfPartTags);
													 int partFoundinTask=0;
													 if (partCnt)
													 {
														 for(p=0;p<partCnt;p++)
														 {
															 PartTag=SetOfPartTags[p];
															 ITKCALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
															 
															 printf("\n Part attached to task %s ..............",PartNum);fflush(stdout);
															 
															if(tc_strcmp(PartNum,LatestP_child_item_id)==0)
															{
																printf("\n allow parent part is attached to WT DML itself. hence we can attach the part.DML number %s,Part Number %s",DmlId,LatestP_child_item_id);fflush(stdout);
																partFoundinTask++;
																break;
															}
														 }
													 }
													 if(partFoundinTask==0)
													 {
														 char* t5NotHangingPart1 = NULL ;
														t5NotHangingPart1 = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
														tc_strcpy(t5NotHangingPart1,"");
														tc_strcat(t5NotHangingPart1,"\n");
														tc_strcat(t5NotHangingPart1,"DML is for Transfering Part to Obsolete Vault");
														tc_strcat(t5NotHangingPart1,"Parent Assy latest Revision should not content solution items parts.");
														tc_strcat(t5NotHangingPart1,"Parent Assembly  ");
														tc_strcat(t5NotHangingPart1,LatestP_child_item_id);
														tc_strcat(t5NotHangingPart1," latest revision is in  ");
														tc_strcat(t5NotHangingPart1,LatestPPrtLcstate);
														tc_strcat(t5NotHangingPart1," of Child Part ");
														tc_strcat(t5NotHangingPart1,PrtNum);
														tc_strcat(t5NotHangingPart1,"\n");
														//tc_strcat(t5NotHangingPart1,"  Withdraw TPL DML. \n");
														
														
														//tc_strcat(t5NotHangingPart1,", Please remove the part from assembly, Release Parent assembly DML first to add part in WITHDRAW TPL dml.");
														printf("\n error11111111 %s",t5NotHangingPart1);fflush(stdout);
														//EMH_store_error_s1(EMH_severity_error,ITK_err,t5NotHangingPart1);
														//return 1;
														setAddStrFuction(icount,SetChildErr,t5NotHangingPart1);
													 }
											 }
											 else
											 {
												 
													char* t5NotHangingPart1 = NULL ;
													t5NotHangingPart1 = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
													tc_strcpy(t5NotHangingPart1,"");
													tc_strcat(t5NotHangingPart1,"\n");
													tc_strcat(t5NotHangingPart1,"DML is for Transfering Part to Obsolete Vault");
													tc_strcat(t5NotHangingPart1,"Parent Assy latest Revision should not content solution items parts.");
													tc_strcat(t5NotHangingPart1,"Parent Assembly  ");
													tc_strcat(t5NotHangingPart1,LatestP_child_item_id);
													tc_strcat(t5NotHangingPart1," latest revision is in  ");
													tc_strcat(t5NotHangingPart1,LatestPPrtLcstate);
													tc_strcat(t5NotHangingPart1," of Child Part ");
													tc_strcat(t5NotHangingPart1,PrtNum);
													tc_strcat(t5NotHangingPart1,"  Withdraw TPL DML. \n");
													tc_strcat(t5NotHangingPart1,"\n");
													//tc_strcat(t5NotHangingPart1,", Please remove the part from assembly, Release Parent assembly DML first to add part in WITHDRAW TPL dml.");
													printf("\n error22222 %s",t5NotHangingPart1);fflush(stdout);
													//EMH_store_error_s1(EMH_severity_error,ITK_err,t5NotHangingPart1);
													//return 1;
													setAddStrFuction(icount,SetChildErr,t5NotHangingPart1);
											 }
										}
									}
									
								}
								
								if(selectedPartPresent==0)
								{
									
									char*	 LatestPPrtLcstate			= NULL;
									ITKCALL(AOM_UIF_ask_value(latestParentAssyTag,"release_status_list",&LatestPPrtLcstate);fflush(stdout));
									printf("\n Part Lc State:%s ..............",PrtLcstate);fflush(stdout);

									if(tc_strstr(LatestPPrtLcstate,"Obsolete")!=NULL)
									{
										
										printf("\n allow latest parent Part is %s Vault hence  allowed to attach to task.",LatestPPrtLcstate);fflush(stdout);	
									}

									else if(tc_strstr(LatestPPrtLcstate,"Released")!=NULL)
									 {
										 printf("\n allow latest parent Part is already in %s vault hence  allowed to attach to task.",LatestPPrtLcstate);fflush(stdout);
									 }
									 else
									 {
										 
											char* t5NotHangingPart1 = NULL ;
											t5NotHangingPart1 = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
											tc_strcpy(t5NotHangingPart1,"");
											tc_strcat(t5NotHangingPart1,"\n");
											tc_strcpy(t5NotHangingPart1,"DML is for Transfering Part to Obsolete Vault,Next Official is not ERC Released/STDSI Released Please check with ERC.");
											//tc_strcat(t5NotHangingPart1,"\n");
											//tc_strcpy(t5NotHangingPart1,"Parent Next Official is not ERC Released/STDSI Released Please check with ERC.");
											tc_strcat(t5NotHangingPart1,"\n");
											tc_strcat(t5NotHangingPart1,"Child part ");
											tc_strcat(t5NotHangingPart1,PrtNum);
											tc_strcat(t5NotHangingPart1,"Parent Assembly ");
											tc_strcat(t5NotHangingPart1,PPrtPrtNum);
											tc_strcat(t5NotHangingPart1," is in Life cycle state ");
											tc_strcat(t5NotHangingPart1,LatestPPrtLcstate);
											tc_strcat(t5NotHangingPart1,"\n");
											//tc_strcat(t5NotHangingPart1,", Please remove the part from assembly, Release Parent assembly DML first to add part in WITHDRAW TPL dml.");
											printf("\n error33333 %s",t5NotHangingPart1);fflush(stdout);
											//EMH_store_error_s1(EMH_severity_error,ITK_err,t5NotHangingPart1);
											//return 1;
											setAddStrFuction(icount,SetChildErr,t5NotHangingPart1);
									 }
								}
								else
								{
									printf("\n selected part %s is is peresnt into  parent assembly=%s",aPrtNum,LatestP_child_item_id);fflush(stdout);
								}
		
								
							}
							else if(tc_strcmp(latestParentAssname,ParentAssyname)==0)
							{
								printf("\n parent part is latest");fflush(stdout);	
								printf("\n selected parent revision---------------> %s\n",ParentAssyname);fflush(stdout);
								printf("\n latest revision---------------> %s\n",latestParentAssname);fflush(stdout);
								
								char*	 ParentAssyLcstate			= NULL;
								ITKCALL(AOM_UIF_ask_value(ParentAssyTag,"release_status_list",&ParentAssyLcstate);fflush(stdout));
								printf("\n Part Lc State:%s ..............",ParentAssyLcstate);fflush(stdout);
								
																					 int TaskCnt=0,partCnt=0,t=0,p=0;
								 tag_t		*SetOfDmlTasksTag		= NULLTAG;
								 tag_t		TaskRevTag			= NULLTAG;
								 tag_t		*SetOfPartTags			= NULLTAG;
								 tag_t PartTag = NULLTAG;
								 char *PartNum=NULL;
								 char *DmlId=NULL;
								 
								 printf("\n error Pls checkin the latest Revision to Release Vault.");fflush(stdout);
								// ITK_CALL(AOM_ask_value_string(DMLRev,"item_id",&DmlId));
																									
								// CALLAPI(AOM_ask_value_string(TaskObj,"item_id",&DMLNum);fflush(stdout));
								// printf("\nDML number  of selected object part :%s\n",DMLNum);fflush(stdout);
								// CALLAPI(AOM_ask_value_tags(TaskObj,"T5_DMLTaskRelation",&TaskCnt,&SetOfDmlTasksTag));
								 
								 // printf("\n set size of task :%d",TaskCnt);fflush(stdout);
								
									 AOM_ask_value_tags(TaskObj,"CMHasSolutionItem",&partCnt,&SetOfPartTags);
									 
									 printf("\n set size of part attached to task :%d",partCnt);fflush(stdout);
									 int partFoundinTask=0;
									 int q=0;
									 if (partCnt>0)
									 {
										 for(q=0;q<partCnt;q++)
										 {
											 PartTag=SetOfPartTags[q];
											 ITKCALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
											 
											 printf("\n Part attached to task %s ..............",PartNum);fflush(stdout);
											 
											if(tc_strcmp(PartNum,ParentAssyname)==0)
											{
												printf("\n allow parent part is attached to WT DML itself. hence we can attach the part.DML number %s,Part Number %s",DmlId,ParentAssyname);fflush(stdout);
												partFoundinTask++;
												break;
											}
											
										 }
										 if(partFoundinTask==0)
										 {
											 if(tc_strstr(ParentAssyLcstate,"Obsolete")==NULL)
												{
													printf("\n check in DML-taskParent Assembly=%s is in Life cycle state =%s Part cannot be attached to Withdraw TPL DML.",ParentAssyname,ParentAssyLcstate);fflush(stdout);
													char* t5NotHangingPart1 = NULL ;
													t5NotHangingPart1 = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
													tc_strcpy(t5NotHangingPart1,"");
													tc_strcat(t5NotHangingPart1,"\n");
													tc_strcat(t5NotHangingPart1,"DML is for Transfering Part to Obsolete Vault,Parent Assy should not content solution items parts.");
													tc_strcat(t5NotHangingPart1,"Parent Assembly ");
													tc_strcat(t5NotHangingPart1,ParentAssyname);
													tc_strcat(t5NotHangingPart1," is in Life cycle state ");
													tc_strcat(t5NotHangingPart1,ParentAssyLcstate);
													tc_strcat(t5NotHangingPart1,"Child part ");
													tc_strcat(t5NotHangingPart1,PrtNum);
													tc_strcat(t5NotHangingPart1,"\n");
													//tc_strcat(t5NotHangingPart1,", Part cannot be attached to Withdraw TPL DML.");
													printf("\n error44444 %s",t5NotHangingPart1);fflush(stdout);
													//EMH_store_error_s1(EMH_severity_error,ITK_err,t5NotHangingPart1);
													//return 1;
													setAddStrFuction(icount,SetChildErr,t5NotHangingPart1);
												}
										 }
									 }
									 else
									 {
										 
										if(tc_strstr(ParentAssyLcstate,"Obsolete")==NULL)
										{
											printf("\n check in Parent Assembly=%s is in Life cycle state =%s Part cannot be attached to Withdraw TPL DML.",ParentAssyname,ParentAssyLcstate);fflush(stdout);
											
											char* t5NotHangingPart1 = NULL ;
											t5NotHangingPart1 = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
											tc_strcpy(t5NotHangingPart1,"");
											tc_strcat(t5NotHangingPart1,"\n");
											tc_strcat(t5NotHangingPart1,"DML is for Transfering Part to Obsolete Vault,Parent Assy should not content solution parts.");
											tc_strcat(t5NotHangingPart1,"Parent Assembly ");
											tc_strcat(t5NotHangingPart1,ParentAssyname);
											tc_strcat(t5NotHangingPart1," is in Life cycle state ");
											tc_strcat(t5NotHangingPart1,ParentAssyLcstate);
											tc_strcat(t5NotHangingPart1,"Child part ");
											tc_strcat(t5NotHangingPart1,PrtNum);
											tc_strcat(t5NotHangingPart1,"\n");
											//tc_strcat(t5NotHangingPart1,", Part cannot be attached to Withdraw TPL DML.");
											printf("\n error55555 %s",t5NotHangingPart1);fflush(stdout);
											setAddStrFuction(icount,SetChildErr,t5NotHangingPart1);
											//EMH_store_error_s1(EMH_severity_error,ITK_err,t5NotHangingPart1);
											//return 1;
										}
									 }
								 }

						
							}
						else
						{
							printf("\nt5AffdPartsVal.mth : Part is dummy or contains underscore hence allowing ParentPartType:%s ParentPartNoDup:%s",PPrtPrtType,PPrtPrtNum);fflush(stdout);
						}
				}
				else if ( allowFlag == 1 )
				{
					printf("\nt5AffdPartsVal.mth : Allow to attach child part to task");fflush(stdout);
				}

			  }//parent part for loop
			}
			/**********SPARE KIT RELATIONS CKECK************/
			int cnt1=0;
			tag_t* SpKitPartTags = NULLTAG;
			int allowFlagspkPrt=0;
			//ITKCALL(PS_where_used_all(latestrev,1,&n_parents,&levels,&parents));
			ITKCALL(AOM_ask_value_tags(latestrev,"T5_HasSpareKit",&cnt1,&SpKitPartTags));
			printf("\n\t selected parts has spare kit relation : %d\n",cnt1); fflush(stdout);
			jd=0;	
			
			if(cnt1>0)
			{
			  for (jd=0;jd<cnt1;jd++ )
			  {
				char*	 ParentPartNum			= NULL;
				tag_t ParentAssyTagTypeTag=NULLTAG;
				tag_t ParentAssyTag = NULLTAG;
				//API change
				//char   ParentAssyTagType_name[TCTYPE_name_size_c+1];
				char *ParentAssyTagType_name = NULL;
				
				int n_PPrtTskCnt=0;
				tag_t *PPrtTskObjSO=NULLTAG;
				tag_t 	Ppart_tsk_rel_typ 	= NULLTAG;	
				int allowFlag=0;
	
				
				ParentAssyTag=SpKitPartTags[jd];
				ITKCALL(AOM_ask_value_string(ParentAssyTag,"item_id",&ParentPartNum));    //003915
				printf("\n\t selected part Parent Part number:%s",ParentPartNum);	fflush(stdout);

				if(TCTYPE_ask_object_type(ParentAssyTag,&ParentAssyTagTypeTag));
				if(TCTYPE_ask_name2(ParentAssyTagTypeTag,&ParentAssyTagType_name));
				printf("\n\t selected part Parent tag := %s", ParentAssyTagType_name);fflush(stdout); //ItemRevision

				if (tc_strcmp(ParentAssyTagType_name,"T5_ArchModuleRevision")==0)
				{
					
				}
				
				if(GRM_list_primary_objects_only(ParentAssyTag,Ppart_tsk_rel_typ,&n_PPrtTskCnt,&PPrtTskObjSO)!=ITK_ok)PrintErrorStack();
				printf("\n selected part's parent part's task n_PPrtTskCnt %d.\n",n_PPrtTskCnt); fflush(stdout);
				if (n_PPrtTskCnt > 0)
				{
					int j=0;
					for (j=0;j<n_PPrtTskCnt;j++ )
					{
						
						tag_t		PPrttsk_dml_rel_type	= NULLTAG;
						char*	 PPrtTasknum = NULL;
						int  PPrtdmlcount=0;
						tag_t*		PPrtDMLRevision			= NULLTAG;
						logical		is_latest;
						tag_t		PPrtDMLRevTag			= NULLTAG;
						tag_t PPrtclass_id1=NULLTAG;
						char *PPrtclass_name1= NULL;
						char *PPrtDmlName= NULL;
						char		*PPrtDMLtype				= NULL;
						
						if( AOM_ask_value_string(PPrtTskObjSO[j],"item_revision_id",&PPrtTasknum)==ITK_ok)
						printf("\n DmlNumb and Task name %s.\n",PPrtTasknum); fflush(stdout);
					
						ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &PPrttsk_dml_rel_type));
						
						if (PPrttsk_dml_rel_type!=NULLTAG)
						{
							
							ITKCALL(GRM_list_primary_objects_only(PPrtTskObjSO[j],PPrttsk_dml_rel_type,&PPrtdmlcount,&PPrtDMLRevision));
							printf("\n\n\t\t DML Revision from Task : %d",PPrtdmlcount);fflush(stdout);		//task to dml
							int dp=0;
							for (dp=0;dp<PPrtdmlcount ;dp++ )
								{
									ITKCALL(ITEM_rev_sequence_is_latest(PPrtDMLRevision[dp],&is_latest));
									printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);

									if(is_latest != true)
									{
										printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
									}else
									{
										PPrtDMLRevTag = PPrtDMLRevision[dp];//DML
										
										ITKCALL(POM_class_of_instance(PPrtDMLRevTag,&PPrtclass_id1));
										ITKCALL(POM_name_of_class(PPrtclass_id1,&PPrtclass_name1));
										printf("\n\n\t\t class_name found1 MR :%s",PPrtclass_name1);


										ITKCALL(AOM_ask_value_string(PPrtDMLRevTag, "item_id",&PPrtDmlName));
										printf("\n PPrtDmlName %s.....\n",PPrtDmlName);
										
										ITKCALL(AOM_ask_value_string(PPrtDMLRevTag,"t5_rlstype",&PPrtDMLtype));
										
										printf("\n PPrtDMLtype %s.....\n",PPrtDMLtype);

										if((tc_strcmp(PPrtclass_name1,"ChangeRequestRevision")==0) && (tc_strcmp(PPrtDMLtype,"WT")==0))
											{
											
												printf("\nt5AffdPartsVal.mth : Allowing to attach child part to WT task as parent is attached to other or same WT DML");fflush(stdout);
												allowFlag = 1;
												break;
											}
											else
											{
												printf("\n DR ");fflush(stdout);
											}
									}
								}
						
							
						}
					}//parent part taskfor loop
				}
				else
				{
					printf("\nt5AffdPartsVal.mth : Part Rev do not have task attached to it");
				}
				
				if ( allowFlag == 0 )
				{
					char *PPrtPrtNum=NULL;
					char *PPrtPrtType=NULL;
					char *PPrtLcstate=NULL;
					char *latestParentAssname=NULL;
					char *ParentAssyname=NULL;
					tag_t latestParentAssyTag = NULLTAG;
					 tag_t   window,rule,top_line = NULLTAG;
					ITKCALL(AOM_ask_value_string(ParentAssyTag, "item_id",&PPrtPrtNum));
					printf("\n PPrtPrtNum %s.....\n",PPrtPrtNum);fflush(stdout);
					
					ITKCALL(AOM_ask_value_string(ParentAssyTag, "t5_PartType",&PPrtPrtType));
					printf("\n PPrtPrtType %s.....\n",PPrtPrtType);fflush(stdout);
					
					ITKCALL(AOM_UIF_ask_value(ParentAssyTag,"release_status_list",&PPrtLcstate);fflush(stdout));
					printf("\n Part Lc State:%s ..............",PPrtLcstate);fflush(stdout);
					if( (tc_strcmp( PPrtPrtType,"CKDVC") == 0))//CKD vc
						{
							printf("allowing child of CKDVC Parents");
						}
						else if( (tc_strcmp( PPrtPrtType,"D") != 0))//not dummy
						{

							//ITKCALL(ITEM_ask_latest_rev(ParentAssyTag,&latestParentAssyTag));
							tag_t PPrtPrtMaster = NULLTAG;
							if(ITEM_find_item(PPrtPrtNum,&PPrtPrtMaster)!=ITK_ok)PrintErrorStack();
							printf("\n UseMaster found------>");fflush(stdout);
							
							ITKCALL(ITEM_ask_latest_rev(PPrtPrtMaster,&latestParentAssyTag));
							if( AOM_ask_value_string(ParentAssyTag,"object_string",&ParentAssyname)==ITK_ok)
							printf("\n selected parent revision---------------> %s\n",ParentAssyname);fflush(stdout);

							if (latestParentAssyTag!=NULLTAG)
							{
								if( AOM_ask_value_string(latestParentAssyTag,"object_string",&latestParentAssname)==ITK_ok)
								printf("\n latest revision---------------> %s\n",latestParentAssname);fflush(stdout);
							}

							if(tc_strcmp(latestParentAssname,ParentAssyname)!=0)
							{
								//EMH_store_error_s1(EMH_severity_error,ITK_err,"Please attach latest Parts to the task.");
								//return 1;
								
								//selected part's parent part's child part number to check weater selected part is present in child part or not
								
								int LPCpart,p1 = 0;
								int selectedPartPresent = 0;
								  tag_t  *LatestPchildPart=NULLTAG;
								  tag_t   LatestPchildPartobject=NULLTAG;
								  char* LatestP_child_item_id = NULL;
								if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
								//if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
								if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
								if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
								if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
								if(BOM_set_window_top_line (window, NULLTAG, latestParentAssyTag, NULLTAG, &top_line)!=ITK_ok)PrintErrorStack();
								printf("\n inside bom_window-----555\n"); fflush(stdout);
								if(BOM_line_ask_child_lines (top_line, &LPCpart, &LatestPchildPart));
								printf("\n\n\t\t No of child objects are n 555 : %d\n",LPCpart);fflush(stdout);
								
								if (LPCpart >0)
								{
									for (p1=0;p1<LPCpart ;p1++ )
									{
										LatestP_child_item_id = NULL;
										if(LatestPchildPartobject) LatestPchildPartobject=NULLTAG;
										LatestPchildPartobject=LatestPchildPart[p1];
										ITKCALL(AOM_ask_value_string(LatestPchildPartobject, "bl_item_item_id", &LatestP_child_item_id ));
										printf("\n\t Parents child part ===> :: %s",LatestP_child_item_id); fflush(stdout);
										printf("\n\t selected  part ===> :: %s",PPrtPrtNum); fflush(stdout);
										
										if(tc_strcmp(aPrtNum,LatestP_child_item_id)==0)
										{
											selectedPartPresent=1;
											printf("\n\t Design Object ===> :: %s",LatestP_child_item_id); fflush(stdout);
														
											char*	 LatestPPrtLcstate			= NULL;
											ITKCALL(AOM_UIF_ask_value(latestParentAssyTag,"release_status_list",&LatestPPrtLcstate);fflush(stdout));
											printf("\n Part Lc State:%s ..............",PrtLcstate);fflush(stdout);

											if(tc_strstr(LatestPPrtLcstate,"Obsolete")!=NULL)
											{
												
												printf("\n error latest parent Part is already in Obsolete Vault hence  allowed to attach to task.");fflush(stdout);	
											}

											else if(tc_strstr(LatestPPrtLcstate,"Released")!=NULL)
											 {
												 
												 int TaskCnt=0,partCnt=0,t=0,p=0;
												 tag_t		*SetOfDmlTasksTag		= NULLTAG;
												 tag_t		TaskRevTag			= NULLTAG;
												 tag_t		*SetOfPartTags			= NULLTAG;
												 tag_t PartTag = NULLTAG;
												 char *PartNum=NULL;
												 char *DmlId=NULL;
												 
												 printf("\n error Pls checkin the latest Revision to Release Vault.");fflush(stdout);
												// ITK_CALL(AOM_ask_value_string(DMLRev,"item_id",&DmlId));

													 AOM_ask_value_tags(TaskObj,"CMHasSolutionItem",&partCnt,&SetOfPartTags);
													 int partFoundinTask=0;
													 if (partCnt)
													 {
														 for(p=0;p<partCnt;p++)
														 {
															 PartTag=SetOfPartTags[p];
															 ITKCALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
															 
															 printf("\n Part attached to task %s ..............",PartNum);fflush(stdout);
															 
															if(tc_strcmp(PartNum,LatestP_child_item_id)==0)
															{
																printf("\n allow parent part is attached to WT DML itself. hence we can attach the part.DML number %s,Part Number %s",DmlId,LatestP_child_item_id);fflush(stdout);
																partFoundinTask++;
																break;
															}
														 }
													 }
													 if(partFoundinTask==0)
													 {
														 char* t5NotHangingPart1 = NULL ;
														t5NotHangingPart1 = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
														tc_strcpy(t5NotHangingPart1,"");
														tc_strcat(t5NotHangingPart1,"\n");
														tc_strcat(t5NotHangingPart1,"DML is for Transfering Part to Obsolete Vault");
														tc_strcat(t5NotHangingPart1,"Spare Kit part latest Revision should not content solution items parts.");
														tc_strcat(t5NotHangingPart1,"Spare Kit part  ");
														tc_strcat(t5NotHangingPart1,LatestP_child_item_id);
														tc_strcat(t5NotHangingPart1," latest revision is in  ");
														tc_strcat(t5NotHangingPart1,LatestPPrtLcstate);
														tc_strcat(t5NotHangingPart1," of Child Part ");
														tc_strcat(t5NotHangingPart1,PrtNum);
														tc_strcat(t5NotHangingPart1,"\n");
														//tc_strcat(t5NotHangingPart1,"  Withdraw TPL DML. \n");
														
														
														//tc_strcat(t5NotHangingPart1,", Please remove the part from assembly, Release Parent assembly DML first to add part in WITHDRAW TPL dml.");
														printf("\n error11111111 %s",t5NotHangingPart1);fflush(stdout);
														//EMH_store_error_s1(EMH_severity_error,ITK_err,t5NotHangingPart1);
														//return 1;
														setAddStrFuction(icount,SetChildErr,t5NotHangingPart1);
													 }
											 }
											 else
											 {
												 
													char* t5NotHangingPart1 = NULL ;
													t5NotHangingPart1 = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
													tc_strcpy(t5NotHangingPart1,"");
													tc_strcat(t5NotHangingPart1,"\n");
													tc_strcat(t5NotHangingPart1,"DML is for Transfering Part to Obsolete Vault");
													tc_strcat(t5NotHangingPart1,"Spare Kit part latest Revision should not content solution items parts.");
													tc_strcat(t5NotHangingPart1,"Spare Kit part  ");
													tc_strcat(t5NotHangingPart1,LatestP_child_item_id);
													tc_strcat(t5NotHangingPart1," latest revision is in  ");
													tc_strcat(t5NotHangingPart1,LatestPPrtLcstate);
													tc_strcat(t5NotHangingPart1," of Child Part ");
													tc_strcat(t5NotHangingPart1,PrtNum);
													tc_strcat(t5NotHangingPart1,"  Withdraw TPL DML. \n");
													tc_strcat(t5NotHangingPart1,"\n");
													//tc_strcat(t5NotHangingPart1,", Please remove the part from assembly, Release Parent assembly DML first to add part in WITHDRAW TPL dml.");
													printf("\n error22222 %s",t5NotHangingPart1);fflush(stdout);
													//EMH_store_error_s1(EMH_severity_error,ITK_err,t5NotHangingPart1);
													//return 1;
													setAddStrFuction(icount,SetChildErr,t5NotHangingPart1);
											 }
										}
									}
									
								}
								
								if(selectedPartPresent==0)
								{
									
									char*	 LatestPPrtLcstate			= NULL;
									ITKCALL(AOM_UIF_ask_value(latestParentAssyTag,"release_status_list",&LatestPPrtLcstate);fflush(stdout));
									printf("\n Part Lc State:%s ..............",PrtLcstate);fflush(stdout);

									if(tc_strstr(LatestPPrtLcstate,"Obsolete")!=NULL)
									{
										
										printf("\n allow latest parent Part is %s Vault hence  allowed to attach to task.",LatestPPrtLcstate);fflush(stdout);	
									}

									else if(tc_strstr(LatestPPrtLcstate,"Released")!=NULL)
									 {
										 printf("\n allow latest parent Part is already in %s vault hence  allowed to attach to task.",LatestPPrtLcstate);fflush(stdout);
									 }
									 else
									 {
										 
											char* t5NotHangingPart1 = NULL ;
											t5NotHangingPart1 = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
											tc_strcpy(t5NotHangingPart1,"");
											tc_strcat(t5NotHangingPart1,"\n");
											tc_strcpy(t5NotHangingPart1,"DML is for Transfering Part to Obsolete Vault,Next Official is not ERC Released/STDSI Released Please check with ERC.");
											//tc_strcat(t5NotHangingPart1,"\n");
											//tc_strcpy(t5NotHangingPart1,"Parent Next Official is not ERC Released/STDSI Released Please check with ERC.");
											tc_strcat(t5NotHangingPart1,"\n");
											tc_strcat(t5NotHangingPart1,"Child part ");
											tc_strcat(t5NotHangingPart1,PrtNum);
											tc_strcat(t5NotHangingPart1,"Spare Kit part ");
											tc_strcat(t5NotHangingPart1,PPrtPrtNum);
											tc_strcat(t5NotHangingPart1," is in Life cycle state ");
											tc_strcat(t5NotHangingPart1,LatestPPrtLcstate);
											tc_strcat(t5NotHangingPart1,"\n");
											//tc_strcat(t5NotHangingPart1,", Please remove the part from assembly, Release Parent assembly DML first to add part in WITHDRAW TPL dml.");
											printf("\n error33333 %s",t5NotHangingPart1);fflush(stdout);
											//EMH_store_error_s1(EMH_severity_error,ITK_err,t5NotHangingPart1);
											//return 1;
											setAddStrFuction(icount,SetChildErr,t5NotHangingPart1);
									 }
								}
								else
								{
									printf("\n selected part %s is is peresnt into  parent assembly=%s",aPrtNum,LatestP_child_item_id);fflush(stdout);
								}
		
								
							}
							else if(tc_strcmp(latestParentAssname,ParentAssyname)==0)
							{
								printf("\n parent part is latest");fflush(stdout);	
								printf("\n selected parent revision---------------> %s\n",ParentAssyname);fflush(stdout);
								printf("\n latest revision---------------> %s\n",latestParentAssname);fflush(stdout);
								
								char*	 ParentAssyLcstate			= NULL;
								ITKCALL(AOM_UIF_ask_value(ParentAssyTag,"release_status_list",&ParentAssyLcstate);fflush(stdout));
								printf("\n Part Lc State:%s ..............",ParentAssyLcstate);fflush(stdout);
								
																					 int TaskCnt=0,partCnt=0,t=0,p=0;
								 tag_t		*SetOfDmlTasksTag		= NULLTAG;
								 tag_t		TaskRevTag			= NULLTAG;
								 tag_t		*SetOfPartTags			= NULLTAG;
								 tag_t PartTag = NULLTAG;
								 char *PartNum=NULL;
								 char *DmlId=NULL;
								 
								 printf("\n error Pls checkin the latest Revision to Release Vault.");fflush(stdout);
								// ITK_CALL(AOM_ask_value_string(DMLRev,"item_id",&DmlId));
																									
								// CALLAPI(AOM_ask_value_string(TaskObj,"item_id",&DMLNum);fflush(stdout));
								// printf("\nDML number  of selected object part :%s\n",DMLNum);fflush(stdout);
								// CALLAPI(AOM_ask_value_tags(TaskObj,"T5_DMLTaskRelation",&TaskCnt,&SetOfDmlTasksTag));
								 
								 // printf("\n set size of task :%d",TaskCnt);fflush(stdout);
								
									 AOM_ask_value_tags(TaskObj,"CMHasSolutionItem",&partCnt,&SetOfPartTags);
									 
									 printf("\n set size of part attached to task :%d",partCnt);fflush(stdout);
									 int partFoundinTask=0;
									 int q=0;
									 if (partCnt>0)
									 {
										 for(q=0;q<partCnt;q++)
										 {
											 PartTag=SetOfPartTags[q];
											 ITKCALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
											 
											 printf("\n Part attached to task %s ..............",PartNum);fflush(stdout);
											 
											if(tc_strcmp(PartNum,ParentAssyname)==0)
											{
												printf("\n allow parent part is attached to WT DML itself. hence we can attach the part.DML number %s,Part Number %s",DmlId,ParentAssyname);fflush(stdout);
												partFoundinTask++;
												break;
											}
											
										 }
										 if(partFoundinTask==0)
										 {
											 if(tc_strstr(ParentAssyLcstate,"Obsolete")==NULL)
												{
													printf("\n check in DML-taskParent Assembly=%s is in Life cycle state =%s Part cannot be attached to Withdraw TPL DML.",ParentAssyname,ParentAssyLcstate);fflush(stdout);
													char* t5NotHangingPart1 = NULL ;
													t5NotHangingPart1 = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
													tc_strcpy(t5NotHangingPart1,"");
													tc_strcat(t5NotHangingPart1,"\n");
													tc_strcat(t5NotHangingPart1,"DML is for Transfering Part to Obsolete Vault,Parent Assy should not content solution items parts.");
													tc_strcat(t5NotHangingPart1,"Spare Kit part ");
													tc_strcat(t5NotHangingPart1,ParentAssyname);
													tc_strcat(t5NotHangingPart1," is in Life cycle state ");
													tc_strcat(t5NotHangingPart1,ParentAssyLcstate);
													tc_strcat(t5NotHangingPart1,"Child part ");
													tc_strcat(t5NotHangingPart1,PrtNum);
													tc_strcat(t5NotHangingPart1,"\n");
													//tc_strcat(t5NotHangingPart1,", Part cannot be attached to Withdraw TPL DML.");
													printf("\n error44444 %s",t5NotHangingPart1);fflush(stdout);
													//EMH_store_error_s1(EMH_severity_error,ITK_err,t5NotHangingPart1);
													//return 1;
													setAddStrFuction(icount,SetChildErr,t5NotHangingPart1);
												}
										 }
									 }
									 else
									 {
										 
										if(tc_strstr(ParentAssyLcstate,"Obsolete")==NULL)
										{
											printf("\n check in Parent Assembly=%s is in Life cycle state =%s Part cannot be attached to Withdraw TPL DML.",ParentAssyname,ParentAssyLcstate);fflush(stdout);
											
											char* t5NotHangingPart1 = NULL ;
											t5NotHangingPart1 = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
											tc_strcpy(t5NotHangingPart1,"");
											tc_strcat(t5NotHangingPart1,"\n");
											tc_strcat(t5NotHangingPart1,"DML is for Transfering Part to Obsolete Vault,Parent Assy should not content solution parts.");
											tc_strcat(t5NotHangingPart1,"Spare Kit part ");
											tc_strcat(t5NotHangingPart1,ParentAssyname);
											tc_strcat(t5NotHangingPart1," is in Life cycle state ");
											tc_strcat(t5NotHangingPart1,ParentAssyLcstate);
											tc_strcat(t5NotHangingPart1,"Child part ");
											tc_strcat(t5NotHangingPart1,PrtNum);
											tc_strcat(t5NotHangingPart1,"\n");
											//tc_strcat(t5NotHangingPart1,", Part cannot be attached to Withdraw TPL DML.");
											printf("\n error55555 %s",t5NotHangingPart1);fflush(stdout);
											setAddStrFuction(icount,SetChildErr,t5NotHangingPart1);
											//EMH_store_error_s1(EMH_severity_error,ITK_err,t5NotHangingPart1);
											//return 1;
										}
									 }
								 }

						
							}
						else
						{
							printf("\nt5AffdPartsVal.mth : Part is dummy or contains underscore hence allowing ParentPartType:%s ParentPartNoDup:%s",PPrtPrtType,PPrtPrtNum);fflush(stdout);
						}
				}
				else if ( allowFlag == 1 )
				{
					printf("\nt5AffdPartsVal.mth : Allow to attach child part to task");fflush(stdout);
				}

			  }//parent part for loop
			}
		}
return 0;
}


//muskan function of previous revision check 
void tm_fnd_Prev_Official_Rev2 ( tag_t  t_currentRevision,tag_t *t_previousRevision, const char *inp_Plant,tag_t *t_epaTask)
{
    if (t_previousRevision) *t_previousRevision = t_currentRevision;
    if (t_epaTask)          *t_epaTask          = NULLTAG;

    tag_t   item               = NULLTAG; // current revision's Item
    int     rev_count          = 0;       // number of revisions
    tag_t  *rev_list           = NULL;    // array of all revisions (descending)
    int     cur_idx            = -1;      // index of current revision in rev_list

    tag_t   relation_type_task = NULLTAG;

    ITKCALL(ITEM_ask_item_of_rev(t_currentRevision, &item));
    ITKCALL(ITEM_list_all_revs(item, &rev_count, &rev_list));
    if (rev_count <= 1 || rev_list == NULL) goto CLEANUP;

    
    for (int i = 0; i < rev_count; i++)
		{
        if (rev_list[i] == t_currentRevision) 
			{ 
			cur_idx = i; break; 
			}
    }
    if (cur_idx <= 0) goto CLEANUP; 

    ITKCALL(GRM_find_relation_type("CMHasSolutionItem", &relation_type_task));
    printf("\n\n ############## Inside muskan function of previous rev ##############\n"); fflush(stdout);

    
    for (int i = cur_idx - 1; i >= 0; i--) 
		{

        int    n_prim = 0;    // number of primary objects on CMHasSolutionItem
        tag_t *prim   = NULL; // array of primary objects

        ITKCALL(GRM_list_primary_objects_only(rev_list[i], relation_type_task, &n_prim, &prim));
        if (n_prim <= 0 || prim == NULL)
			{ 
			if (prim) MEM_free(prim); continue;
			}

            for (int p = 0; p < n_prim; p++)
			{
            if (prim[p] == NULLTAG) continue;

            tag_t typeTag = NULLTAG;
            char *typeNm  = NULL;
            ITKCALL(TCTYPE_ask_object_type(prim[p], &typeTag));
            ITKCALL(TCTYPE_ask_name2(typeTag, &typeNm));

            /* We only care about EPA tasks */
            if (!typeNm || tc_strcmp(typeNm, "T5_EPATaskRevision") != 0)
				{
                if (typeNm) MEM_free(typeNm);
                continue;
            }

            char *taskId = NULL;
            ITKCALL(AOM_ask_value_string(prim[p], "item_id", &taskId));
            printf("\t  item_id is : %s\n", (taskId ? taskId : "<null>")); fflush(stdout);

            logical hit = FALSE;
            if (!inp_Plant || tc_strlen(inp_Plant) == 0) 
				{
                hit = TRUE; /* accept any plant if none provided */
                printf("\t  inp_Plant previous rev  ...%s\n", (inp_Plant ? inp_Plant : "<empty>"));
            } 
			else if (taskId && tc_strstr(taskId, inp_Plant) != NULL)
				{
                hit = TRUE; /* plant code appears in EPA item_id */
            }

            if (hit) 
				{
                
                if (t_previousRevision) *t_previousRevision = rev_list[i];
                if (t_epaTask)          *t_epaTask          = prim[p];

               
                if (taskId) MEM_free(taskId);
                if (typeNm) MEM_free(typeNm);
                MEM_free(prim);
                goto CLEANUP;
            }

            if (taskId) MEM_free(taskId);
            if (typeNm) MEM_free(typeNm);
        }

        MEM_free(prim);
    }

CLEANUP:
    if (rev_list) MEM_free(rev_list);
    return;
}



// muskan function of previous revison end 



//##############################################################################################################################################//
//This validation will ensure the release of previous revisions of part in DML
//1. Previous revision of part is released from same plant DML
//2. Previous revision of part is contained in same plant DML
//3. Previous revision of part is contanied in same plant SMDML-Rework point-Logic to carry forward previous revision changes into current revision
//###############################################################################################################################################//

//int Prev_Rev_Checks(int PartCnt, tag_t* PartTags,char* SetStdRelErr,char* itemid,char* ProjectCode)
int Prev_Rev_Checks(int PartCnt, tag_t* PartTags,char ***SetStdRelErr,char* itemid,char* ProjectCode,int *icountprev)
{

	int				task_len			= 0;
	int				k,j					= 0;
	int				st_ok_Flg			= 0;
	int				cnt_next			= 0;
	int				count_task			= 0;
	int				cnt_tk				= 0;
	int				count_dml_1			= 0;
	int				st_count_dml		= 0;
	int				NextRevFlagDml		= 0;
	int				flagerror			= 0;
	int				st_count			= 0;
	int				dmlstlst			= 0;
	int				Pre_count			= 0;
	int				Precnt				= 0;
	int				precount_task		= 0;
	int				preEpaFlg			= 0;
	int				stlst				= 0;
	int				st_epacount			= 0;
	int				epaRlzFlg			= 0;
	int				smRlzFlg			= 0;
	int				prevRevinEPA		= 0;
	int				precount_task1		= 0;
	int				tskRlzFlg			= 0;
	int				st_prt				= 0;
	int				prtRlzFlg			= 0;
	int				count1				= 0;
	int				st_dmlCnt			= 0;
	int				dmlRlzFlg			= 0;
	int				FlagPrevPartRlzd	= 0;

	//char			*inp_Plant			= NULL;
	char			*inp_PlntLstLtr		= NULL;
	char			*epa_Plant			= NULL;
	char			*Part_no			= NULL;
	char			*Desc_obj_lt_Rev	= NULL;
	char			*Desc_obj_Inp_Part	= NULL;
	char			*part_DRStatus		= NULL;
	char			*WSO_Name_next_Rev	= NULL;
	char			*ReleaseStatusDML	= NULL;
	char			*Revision			= NULL;
	char			*pre_revision		= NULL;
	char			*itemidpre			= NULL;
	char			*epaTaskId			= NULL;
	char			*PreTaskId			= NULL;
	char			*PreTaskId1			= NULL;
	char			*Preepa_Plant		= NULL;
	char			*PrevRevEPASet		= NULL;
	char			*ReleaseStatusepa	= NULL;
	char			*Part_Rev			= NULL;
	//char			*Pretask_Plant		= NULL;
	char			*Pretask_Plant1		= NULL;
	char			*dmlId				= NULL;
	char			*ClosureDate		= NULL;
	char			*ReleaseStatuspart	= NULL;
	char			*DmlName			= NULL;
	char			*dml_Plant			= NULL;
	char			*ClosureDateDML		= NULL;
	char			*ReleaseStatusdml	= NULL;
	char			*PrevRevDMLSet		= NULL;
	char			*Cur_revision		= NULL;

	
	char*			type_class			=NULL;		//Added for Memory Handling
	char*			Pretype_class			=NULL;		//Added for Memory Handling

	char			type_dml[TCTYPE_name_size_c+1];
	
	char			Pretype_class1[TCTYPE_name_size_c+1];
	
	char *Pretype_class2 = NULL;

	tag_t			AssyTag				= NULLTAG;
	tag_t			master				= NULLTAG;
	tag_t			latestrev			= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			relation_type_task	= NULLTAG;
	tag_t			PartepaTag			= NULLTAG;
	tag_t			itemTypeTag_class	= NULLTAG;
	tag_t			tsk_dml_rel_type_1	= NULLTAG;
	tag_t			DMLRevTag_Prt		= NULLTAG;
	tag_t			AssyPreTag			= NULLTAG;
	tag_t           AssyEPATag         = NULLTAG;
	tag_t			PreParttskTag		= NULLTAG;

	tag_t			PreitemTypeTag_class= NULLTAG;
	tag_t			PreitemTypeTag_class1= NULLTAG;
	tag_t			PreitemTypeTag_class2= NULLTAG;
	tag_t			PreParttskTag1		= NULLTAG;
	tag_t			tsk_dml_rel_type	= NULLTAG;
	tag_t			DMLRevTag			= NULLTAG;
	tag_t*			status_listDml		= NULLTAG;

	tag_t*			status_list			= NULLTAG;
	tag_t*			dml_status_list		= NULLTAG;
	tag_t*			PartEpaTags			= NULLTAG;
	tag_t*			DMLRevision_Prt		= NULLTAG;
	tag_t*			PartPreTags			= NULLTAG;
	tag_t*			PrePartTskTags		= NULLTAG;
	tag_t*			PrePartTskTags1		= NULLTAG;
	tag_t*			epa_status_list		= NULLTAG;
	tag_t*			prt_status_list		= NULLTAG;
	tag_t*			DMLRevision			= NULLTAG;
           
	char LcsStdWrkg[40];
	char LcsStdRlzd[40];
	char inp_Plant[40];
	char Pretask_Plant[40];

	logical			CurrentRevInEPA2;
	logical			is_latest;

	
	/*
	if (!PrevRevEPASet) MEM_free(PrevRevEPASet);
	PrevRevEPASet=(char *)MEM_alloc(2000);
	tc_strcpy(PrevRevEPASet," ");
	
	if (!PrevRevDMLSet) MEM_free(PrevRevDMLSet);
	PrevRevDMLSet=(char *)MEM_alloc(2000);
	tc_strcpy(PrevRevDMLSet," ");
	*/
	printf("\n\n ##############Inside Previous revision checks##############");fflush(stdout);

    char  ItemIDCpy[40];
    tc_strcpy(ItemIDCpy,itemid);
	GetPlantWiseRelStat(ItemIDCpy,LcsStdWrkg,LcsStdRlzd);
	printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);fflush(stdout);
	printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);fflush(stdout);

				task_len=0;
				task_len=strlen(itemid);
				printf("\t  TaskName is :  %s\n", itemid);fflush(stdout);
				printf("\t  task_len ...%d\n", task_len);fflush(stdout);// length task
				//inp_Plant=subString(itemid,14,task_len);
				GetPlantForDMLORTask(itemid,inp_Plant);	
				printf("\t  inp_Plant after  ...%s\n", inp_Plant);

				inp_PlntLstLtr=subString(itemid,17,task_len);
				printf("\t  inp_PlntLstLtr after  ...%s\n", inp_PlntLstLtr);
				printf("\t  input ProjectCode  ...%s\n", ProjectCode);
				
				for (k=0;k<PartCnt ;k++ )
				{
					  //muskan  
					  
                  cntFlagprev = 0;
                  cntFlagprevhchk = 0;
                  CurrentRevInEPA2 = false;
                  prevRevinEPA = 0;

              
					printf("\n\n\t\t Prev_Rev_Checks:for k_1 =:%d",k);fflush(stdout);
					AssyTag=NULLTAG;
					AssyTag=PartTags[k];
					AssyPreTag=NULLTAG;
					AssyEPATag=NULLTAG;

					ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
					printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyTag, "item_revision_id",&Cur_revision));
					printf("\n Cur_revision %s.....\n",Cur_revision);

					//Added By Dhanashri for skip prev rev UATZ1.42//
						 char*			SkipPrevRevSTD				= NULL;
						 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
						 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
						printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
					
							//if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
							if(tc_strlen(SkipPrevRevSTD)>0)
							{
								printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
								continue;
							}
					//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//


					//Finding whether current revision is in EPA or not//
					ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type_task));
					ITKCALL(GRM_list_primary_objects_only(AssyTag,relation_type_task,&count_task,&PartEpaTags));
					if(count_task >0)
					{						
						for (cnt_tk=0;cnt_tk<count_task ;cnt_tk++ )
						{
							printf("\n cnt_tk %d.....\n",cnt_tk);fflush(stdout);//Added for Memory Handling
							PartepaTag=NULLTAG;				//Added for Memory Handling
							PartepaTag=PartEpaTags[cnt_tk];
							if (PartepaTag!=NULLTAG)		//Added for Memory Handling
							{
								itemTypeTag_class	=	NULLTAG; //Added for Memory Handling
								type_class			=	NULL; //Added for Memory Handling

								ITKCALL(TCTYPE_ask_object_type(PartepaTag,&itemTypeTag_class));
								if (itemTypeTag_class!=NULLTAG)		//Added for Memory Handling
								{
								
									ITKCALL (TCTYPE_ask_name2(itemTypeTag_class,&type_class));

									printf("\t  type_class ...%s\n", type_class);fflush(stdout);
									if(tc_strcmp(type_class,"T5_EPATaskRevision")==0)
									{
										epaTaskId	=	NULL;
										ITKCALL(AOM_ask_value_string(PartepaTag, "item_id",&epaTaskId));
										printf("\n epaTaskId %s.....\n",epaTaskId);fflush(stdout);

										/*epa_Plant=subString(epaTaskId,22,strlen(epaTaskId));
										printf("\t  epa_Plant after  ...%s\n", epa_Plant);
										
										if(tc_strcmp(inp_Plant,epa_Plant)==0)
										{
											CurrentRevInEPA2=true;
										}*/

										if(tc_strstr(epaTaskId,inp_Plant)!=NULL)
										{
											printf("\n Matching Plant Found for prev...");fflush(stdout);
											CurrentRevInEPA2=true;
											break;
										}
										else
										{
											printf("\n Matching Plant not Found  for prev...");fflush(stdout);
										}


									}
								}else
								{
									printf("\t  For prev rev itemTypeTag_class NULL TAG Found !!!");fflush(stdout);
								}
							}else
							{
								printf("\t  For prev PartepaTag NULL TAG Found !!!");fflush(stdout);
							}
						}
					}

                  


					//#################################################//
					
//					GRM_find_relation_type("IMAN_based_on",&relation_type);
//					GRM_list_secondary_objects_only(AssyTag,relation_type,&Pre_count,&PartPreTags);
//					printf("\n\n\t\tPrev_Rev_Checks Pre_count: %d",Pre_count);fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev));
					printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);
                     
                      

					if(strstr(Part_Rev,"NR"))
					{
						printf("\n Previous revision function can not be called as current revision has NR revision");fflush(stdout);
					}
				
					else
					{
						printf("\n Calling function to get Previous revision ");fflush(stdout);
						tm_fnd_Prev_Official_Rev2(AssyTag,&AssyPreTag,inp_Plant,&AssyEPATag);//TZ 1.43
					}				
										
					
					if(AssyPreTag)
					{
					prevRevinEPA=0;
					prtRlzFlg=0;
					dmlRlzFlg=0;
					FlagPrevPartRlzd=0;
					
					ITKCALL(AOM_ask_value_string(AssyPreTag, "item_id",&itemidpre));
					printf("\n itemidpre %s.....\n",itemidpre);

					ITKCALL(AOM_ask_value_string(AssyPreTag, "item_revision_id",&pre_revision));
					printf("\n pre_revision %s.....\n",pre_revision);

					//Added By Dhanashri for skip prev rev UATZ1.42//
					 char*			SkipPrevRevSTD1				= NULL;
					 ITKCALL(AOM_ask_value_string(AssyPreTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD1));
					 printf("\n\n\t\t SkipPrevRevSTD1  is :%s",SkipPrevRevSTD1);	fflush(stdout);
					 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD1)  is :%d",tc_strlen(SkipPrevRevSTD1));	fflush(stdout);
					
							//if(tc_strcmp(SkipPrevRevSTD1,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD1,"") !=0)
							if(tc_strlen(SkipPrevRevSTD1)>0)
							{
								printf("\n\n\t\t Inside SkipPrevRevSTD1 not null...");	fflush(stdout);
								continue;
							}
					//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

					ITKCALL(AOM_ask_value_string(AssyPreTag, "t5_PartStatus",&part_DRStatus));
					printf("\n part_DRStatus %s.....\n",part_DRStatus);

					ITKCALL(WSOM_ask_release_status_list(AssyPreTag,&st_prt,&prt_status_list));
					for (stlst = 0; stlst < st_prt; stlst++)
					{
						AOM_ask_name(prt_status_list[stlst], &ReleaseStatuspart);
						printf("\n ReleaseStatuspart %s \n",  ReleaseStatuspart);fflush(stdout);
						if(tc_strcmp(ReleaseStatuspart,LcsStdRlzd)==0)
						{
							prtRlzFlg=1;
						}
					}

					
					// CODE ADDED BY DHANASHRI //
					int cntt=0;
					int FlagGotProj=0;
                   int Flagprev=0; //muskan 

					tag_t			CntrlTag		= NULLTAG;

					tag_t query1 = NULLTAG;
					int n_entries1=2;
					int n_found1=0;
  				    tag_t	*CntrlObjs	= NULLTAG;

					char *Info1 	   = NULL;

					char
					 *qry_entry[2] = {"SUBSYSCD", "SYSCD"},
					 *qry_vall[2] =  {"PROJ", "PREVREV"};

					ITKCALL(QRY_find2("ControlObjQry", &query1));
					printf("\n After fins qryyy-- ");fflush(stdout);
					ITKCALL(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
					printf("\n n_found1: %d", n_found1);fflush(stdout);

					if(n_found1>0)
					{
						for (cntt = 0; cntt < n_found1; cntt++)
						{
							CntrlTag=NULLTAG;
							CntrlTag=CntrlObjs[cntt];

							AOM_ask_value_string( CntrlTag, "t5_Userinfo1", &Info1);
							printf("\n Info1: %s\n",Info1);fflush(stdout);

							if(tc_strcmp(Info1,ProjectCode)==0)
							{
								FlagGotProj=1;
								break;
							}
				
						}

					}

					printf("\n FlagGotProj: %d", FlagGotProj);fflush(stdout);


					int cnttSkpRev=0;
					int FlagSkpRev=0;

					tag_t			CntrlTagSkpRev		= NULLTAG;

					tag_t query1SkpRev = NULLTAG;
					int n_entries1SkpRev=2;
					int n_found1SkpRev=0;
  				    tag_t	*CntrlObjsSkpRev	= NULLTAG;

					char *Info1SkpRev 	   = NULL;

					char
					 *qry_entrySkpRev[2] = {"SUBSYSCD", "SYSCD"},
					 *qry_vallSkpRev[2] =  {"SKIP", "PREVREV"};

					ITKCALL(QRY_find2("ControlObjQry", &query1SkpRev));
					printf("\n After fins qryyy-- ");fflush(stdout);
					ITKCALL(QRY_execute(query1SkpRev, n_entries1SkpRev, qry_entrySkpRev, qry_vallSkpRev, &n_found1SkpRev, &CntrlObjsSkpRev));
					printf("\n n_found1SkpRev: %d", n_found1SkpRev);fflush(stdout);

					if(n_found1SkpRev>0)
					{
						for (cnttSkpRev = 0; cnttSkpRev < n_found1SkpRev; cnttSkpRev++)
						{
							CntrlTagSkpRev=NULLTAG;
							CntrlTagSkpRev=CntrlObjsSkpRev[cnttSkpRev];

							AOM_ask_value_string( CntrlTagSkpRev, "t5_Userinfo1", &Info1SkpRev);
							printf("\n itemid: %s\n",itemid);fflush(stdout);
							printf("\n Info1SkpRev: %s\n",Info1SkpRev);fflush(stdout);

							if(tc_strstr(itemid,Info1SkpRev)!=NULL)
							{
								FlagSkpRev=1;
								break;
							}
				
						}

					}

					printf("\n FlagSkpRev: %d", FlagSkpRev);fflush(stdout);


					if(CurrentRevInEPA2!=true)
					{
						
						printf("\n Current revision is not in epa of same plant, checking whether previous revision is in epa of same plant");fflush(stdout);						
						
						epaRlzFlg=0;
					                       
                         if (AssyEPATag != NULLTAG)
                          {
                            

							ITKCALL(WSOM_ask_release_status_list(AssyEPATag,&st_epacount,&epa_status_list));

							for (stlst = 0; stlst < st_epacount; stlst++)
							{
								AOM_ask_name(epa_status_list[stlst], &ReleaseStatusepa);

								printf("\n ReleaseStatusepa22222222 %s \n",  ReleaseStatusepa);fflush(stdout);
								if(tc_strcmp(ReleaseStatusepa,LcsStdRlzd)!=0 && (stlst==st_epacount-1) )
								{	
									ITKCALL(AOM_ask_value_string(AssyEPATag, "item_id",&PreTaskId));
									printf("\n PreTaskId11111111 %s.....\n",PreTaskId);fflush(stdout);
									prevRevinEPA=1;
									/*
									if(preEpaFlg==0)
									{
										 tc_strcat(PrevRevEPASet,"\nPlease release this EPA Task from STDS1.\n");
										 tc_strcat(PrevRevEPASet,"OR\n");
										 tc_strcat(PrevRevEPASet,"Put the current revision of part under same EPA or new EPA.");
										 preEpaFlg=1;
									}
									*/

										//if (!PrevRevEPASet) MEM_free(PrevRevEPASet);
										PrevRevEPASet=NULL;
										PrevRevEPASet=(char *)MEM_alloc(1000);
										tc_strcpy(PrevRevEPASet," ");


									 tc_strcat(PrevRevEPASet,"\nBelow Previous Revisions are not release from STDSI:");	
									 tc_strcat(PrevRevEPASet,"\n");
									 tc_strcat(PrevRevEPASet,"Previous Revision (");
									 tc_strcat(PrevRevEPASet,pre_revision);
									 tc_strcat(PrevRevEPASet,") Of Part ");
									 tc_strcat(PrevRevEPASet,Part_no);
									 tc_strcat(PrevRevEPASet," is contained in EPA Task ");
									 tc_strcat(PrevRevEPASet,PreTaskId);
									 tc_strcat(PrevRevEPASet,"\n");	
									 setAddStrFuction(icountprev,SetStdRelErr,PrevRevEPASet);
									cntFlagprev = 1;
									cntFlagprevhchk= 1; 
                                                 
									printf("\n cntFlagprev = %d  ** ",cntFlagprev);fflush(stdout);
									printf("\n cntFlagprevhchk = %d  ** ",cntFlagprev);fflush(stdout);

                                

									 //Added By Dhanashri Skip Previous Revision UATZ1.42//

									 /*
									 1. Softcheck for this check (pending)
									 2. Set SkipPrevRev on prev rev tag till it get the released prev rev
									 */
									 if(FlagSkpRev==1)
									 {
									  ITKCALL(AOM_lock(AssyPreTag));
									  ITKCALL(AOM_set_value_string(AssyPreTag,"t5_SkipPrevRevSTD",Cur_revision));
									  ITKCALL(AOM_save_with_extensions(AssyPreTag) );
									  ITKCALL(AOM_unlock(AssyPreTag));
			
									  //get the prev rev of AssyPreTag and set 	t5_SkipPrevRevSTD if its not released from plant.
										tag_t			AssyPreTagCpy			= NULLTAG;
										AssyPreTagCpy=AssyPreTag;

									   FindPrevRevLabel:
										printf("\n inside FindPrevRevLabel ");fflush(stdout);
									  
										const char *qry_entries[2];//Multiple Item Queried Error
										const char *qry_values[2];//Multiple Item Queried Error
										int n_tags_found=0;
										tag_t	*itemclassp	= NULLTAG;
										tag_t item = NULLTAG;
										int Item_count      =  0;
										tag_t	*rev_list				= NULL;

										int PreRevFlag=0;
										int RevFlag=0;
										int ii=0;
										int LCSi=0;

										char			*prev_rev		= NULL;
										char			*Part_rev_Id		= NULL;
										char			*Part_Rev_copy		= NULL;
										char			*RevOnly		= NULL;
										char			*PreRevOnly		= NULL;
										char*			class_name=NULL;
										char	*Part_clr_ind		=	NULL;

										int stat_count=0;
										tag_t*			stat_list;
										int FlagPrevRevRlzd=0;
										
									   ITKCALL(AOM_ask_value_string(AssyPreTagCpy, "item_revision_id",&prev_rev));
									   ITKCALL(AOM_ask_value_string(AssyPreTagCpy, "item_revision_id",&Part_Rev_copy));
									   printf("\n prev_rev %s.....\n",prev_rev);fflush(stdout);
									   printf("\n Part_Rev_copy %s.....\n",Part_Rev_copy);fflush(stdout);

									   Part_clr_ind	=	NULL;
										ITKCALL(AOM_ask_value_string(AssyPreTagCpy,"t5_ColourInd",&Part_clr_ind));
										printf("\n Part_clr_ind %s.....\n",Part_clr_ind);fflush(stdout);
										
										qry_entries[0] ="item_id";
										qry_entries[1] ="object_type";//Multiple Item Queried Error
										qry_values[0] = Part_no;
										if (tc_strcmp(Part_clr_ind,"C")==0)
										{
											qry_values[1] = "T5_ClrPart";//Multiple Item Queried Error Hemal
										}
										else
										{
											//qry_values[1] = "Design";//Multiple Item Queried Error Hemal
											//Handle the different design child class.
											char	*designBORev		=	NULL;
											char	*designBO			=	NULL;
											//tag_t	AssyTag			=	NULLTAG;
											//AssyTag=PartTags[k];
											printf("\nBefore getDesignType");fflush(stdout);
											getDesignType(AssyPreTagCpy, &designBORev,&designBO);
											printf("\nAfter getDesignType : %s",designBO);fflush(stdout);
											qry_values[1] = designBO;


										}//Multiple Item Queried Error
										//ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclassp);
										ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found, &itemclassp);//Multiple Item Queried Error
										
										item = itemclassp[0];

										ITKCALL(ITEM_list_all_revs (item, &Item_count, &rev_list));
										printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);

										if(Item_count > 0)
										{
											RevFlag = 0;
											PreRevFlag = 0;
											for(ii=Item_count-1;ii>=0;ii--)
											{
											   RevOnly = NULL;
											   PreRevOnly = NULL;
											   ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));
												printf("\n Part_rev_Id: %s\n",Part_rev_Id);fflush(stdout);
												if(tc_strcmp(prev_rev,Part_rev_Id)==0)
												{
													RevFlag = 1;
												}
												printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
												if(RevFlag == 1)
												{
												   RevOnly= strtok( Part_Rev_copy, ";" );
												   PreRevOnly= strtok( Part_rev_Id, ";" );
												   printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
												   printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
												   if(tc_strcmp(RevOnly,PreRevOnly)!=0)
													{
													  PreRevFlag = 1;
													}
												}
												printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
												if(PreRevFlag == 1)
												{
													//set t5SkipPrevRev if not released from plant
													printf("\n check whether part released from plant");fflush(stdout);
													ITKCALL(WSOM_ask_release_status_list(rev_list[ii],&stat_count,&stat_list));
													if(stat_count == 0)
													{
														printf("\n NO LCS Found for part : %d\n",stat_count);fflush(stdout);
														//break;
													}
													else
													{
														for (LCSi=0;LCSi<stat_count ;LCSi++ )
														{
															ITKCALL(AOM_ask_value_string(stat_list[LCSi],"object_name",&class_name));
															printf("\n class_name: %s\n",class_name);fflush(stdout);
															
															if(tc_strcmp(class_name,LcsStdRlzd)==0)
															{
																FlagPrevRevRlzd=1;
																break;
															}
														}
														printf("\n FlagPrevRevRlzd : %d\n",FlagPrevRevRlzd);fflush(stdout);
													   
													}

													if(FlagPrevRevRlzd==0)
													{
														  printf("\n set t5SkipPrevRev and goto FindPrevRevLabel");fflush(stdout);
														  ITKCALL(AOM_lock(rev_list[ii]));
														  ITKCALL(AOM_set_value_string(rev_list[ii],"t5_SkipPrevRevSTD",Cur_revision));
														  ITKCALL(AOM_save_with_extensions(rev_list[ii]) );
														  ITKCALL(AOM_unlock(rev_list[ii]));

														  AssyPreTagCpy=rev_list[ii];
														  goto FindPrevRevLabel;
													}
													else
													{
														printf("\n Found Release revision Part_rev_Id: [%s]\n",Part_rev_Id);fflush(stdout);
														break;
													}

												} // if(PreRevFlag == 1)
											} // for(ii=Item_count-1;ii>=0;ii--)
										} //if(Item_count > 0)
									  } // if(FlagSkpRev==1)
									 //End of Code Added By Dhanashri Skip Previous Revision UATZ1.42//
									}
								}
								break;

					         } // epatag null
							
					}

						if(CurrentRevInEPA2!=true)
						{
							printf("\n Current revision is not in epa of same plant, checking whether previous revision is in SMDML of same plant");fflush(stdout);						
							
							epaRlzFlg=0;
							PrePartTskTags=NULLTAG;
							GRM_list_primary_objects_only(AssyPreTag,relation_type_task,&precount_task,&PrePartTskTags);
							if(precount_task >0)
							{							
								for (Precnt=0;Precnt<precount_task ;Precnt++ )
								{
									PreParttskTag=NULLTAG;
									PreParttskTag=PrePartTskTags[Precnt];
									ITKCALL (TCTYPE_ask_object_type(PreParttskTag,&PreitemTypeTag_class2));
									ITKCALL (TCTYPE_ask_name2(PreitemTypeTag_class2,&Pretype_class2));

									printf("\t  Pretype_class2 ...%s\n", Pretype_class2);

									ITKCALL(AOM_ask_value_string(PreParttskTag, "item_id",&PreTaskId));
									printf("\n PreTaskId %s.....\n",PreTaskId);


									if(tc_strcmp(Pretype_class2,"T5_APLTaskRevision")==0)
									{

										//Pretask_Plant=subString(PreTaskId,17,strlen(PreTaskId));
										GetPlantForDMLORTask(PreTaskId,Pretask_Plant);	
										printf("\t  Pretask_Plant after  ...%s\n", Pretask_Plant);
										
										dmlId=subString(PreTaskId,2,2);
										printf("\n dmlId:%s",dmlId);fflush(stdout);

										if(tc_strcmp(dmlId,"SM")==0 && (tc_strcmp(inp_PlntLstLtr,Pretask_Plant)==0))
										{

											ITKCALL(WSOM_ask_release_status_list(PreParttskTag,&st_epacount,&epa_status_list));
											for (stlst = 0; stlst < st_epacount; stlst++)
											{
												AOM_ask_name(epa_status_list[stlst], &ReleaseStatusepa);
												printf("\n ReleaseStatusepa %s \n",  ReleaseStatusepa);fflush(stdout);
												if(tc_strcmp(ReleaseStatusepa,LcsStdRlzd)!=0 && (stlst==st_epacount-1))
												{
													//smRlzFlg=1;
													///break;
													printf("\n Previous revision of part is contanied in SMDML which is not stdsi released, carry forward previous revision changes into current revision");fflush(stdout);
													//#############Logic to carry forward previous revision changes#############//



													//##########################################################################//
												}
											}
										}
									}
								}							
								
							}
						}

						if(prevRevinEPA==0)
						{
							///////START OF CODE COMMENTED BY PRITI//AS NO NEED TO CHECK PREVIOUS REVISION DML & TASKFOR RELEASE STATUS//////////////////
//							GRM_list_primary_objects_only(AssyPreTag,relation_type_task,&precount_task1,&PrePartTskTags1);
//							tskRlzFlg=0;
//							if(precount_task1 >0)
//							{							
//								for (Precnt=0;Precnt<precount_task1 ;Precnt++ )
//								{
//									PreParttskTag1=PrePartTskTags1[Precnt];
//									ITKCALL (TCTYPE_ask_object_type(PreParttskTag1,&PreitemTypeTag_class1));
//									ITKCALL (TCTYPE_ask_name(PreitemTypeTag_class1,Pretype_class1));
//
//									printf("\t  Pretype_class1 ...%s\n", Pretype_class1);
//
//									ITKCALL(AOM_ask_value_string(PreParttskTag1, "item_id",&PreTaskId1));
//									printf("\n PreTaskId1 %s.....\n",PreTaskId1);
//
//
//									if(tc_strcmp(Pretype_class1,"T5_APLTaskRevision")==0)
//									{
//
//										Pretask_Plant1=subString(PreTaskId1,17,strlen(PreTaskId1));
//										printf("\t  Pretask_Plant1 after  ...%s\n", Pretask_Plant1);
//
//										ITKCALL(AOM_UIF_ask_value(PreParttskTag1,"date_released",&ClosureDate));
//										printf("\n ClosureDate : %s\n",ClosureDate);fflush(stdout);
//
//										if(tc_strcmp(Pretask_Plant1,inp_Plant)==0)
//										{
//											ITKCALL(WSOM_ask_release_status_list(PreParttskTag1,&st_count,&status_list));
//											for (stlst = 0; stlst < st_count; stlst++)
//											{
//												AOM_ask_name(status_list[stlst], &ReleaseStatusepa);
//												printf("\n ReleaseStatusepa %s \n",  ReleaseStatusepa);fflush(stdout);
//												if(tc_strcmp(ReleaseStatusepa,LcsStdRlzd)==0)
//												{
//													tskRlzFlg=1;
//												}
//											}
//										}
//
//										if( (tskRlzFlg==1) && (strlen(ClosureDate)>2) && (prtRlzFlg==1))
//										{
//											FlagPrevPartRlzd=1;
//											break;
//										}
//										
//									}
//								}
//							}
//
//										//#####Check wthether DML is released or not############//
//										if(precount_task1 >0)
//										{	
//											for (Precnt=0;Precnt<precount_task1 ;Precnt++ )
//											{
//												PreParttskTag1=PrePartTskTags1[Precnt];
//												ITKCALL (TCTYPE_ask_object_type(PreParttskTag1,&PreitemTypeTag_class1));
//												ITKCALL (TCTYPE_ask_name(PreitemTypeTag_class1,Pretype_class1));
//
//												printf("\t  Pretype_class1 ...%s\n", Pretype_class1);
//
//												ITKCALL(AOM_ask_value_string(PreParttskTag1, "item_id",&PreTaskId1));
//												printf("\n PreTaskId1 %s.....\n",PreTaskId1);
//
//
//												if(tc_strcmp(Pretype_class1,"T5_APLTaskRevision")==0)
//												{
//													ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
//													if (tsk_dml_rel_type!=NULLTAG)
//													 {
//
//														ITKCALL(GRM_list_primary_objects_only(PreParttskTag1,tsk_dml_rel_type,&count1,&DMLRevision));
//														printf("\n\n\t\t DML Revision from Task : %d",count1);fflush(stdout);		//task to dml
//
//														for (j=0;j<count1 ;j++ )
//														{
//															ITKCALL(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
//															printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);
//
//															if(is_latest != true)
//															{
//																printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
//															}else
//															{
//																DMLRevTag = DMLRevision[j];//DML
//
//																ITKCALL(AOM_ask_value_string(DMLRevTag, "item_id",&DmlName));
//																printf("\n DmlName %s.....\n",DmlName);//previous revision's DML																
//
//																dml_Plant=subString(DmlName,11,strlen(DmlName));
//																printf("\n dml_Plant is : %s\n",dml_Plant);fflush(stdout);
//
//																if(tc_strcmp(inp_Plant,dml_Plant)==0)
//																{
//																	printf("\n inside plant check is :\n");fflush(stdout);
//
//																	ITKCALL(AOM_UIF_ask_value(DMLRevTag,"date_released",&ClosureDateDML));
//																	printf("\n ClosureDateDML : %s\n",ClosureDateDML);fflush(stdout);
//																	if(strlen(ClosureDateDML)>2) 
//																	{
//																		ITKCALL(WSOM_ask_release_status_list(DMLRevTag,&st_dmlCnt,&status_listDml));
//																		for (stlst = 0; stlst < st_dmlCnt; stlst++)
//																		{
//																			AOM_ask_name(status_listDml[stlst], &ReleaseStatusdml);
//																			printf("\n ReleaseStatusdml %s \n",  ReleaseStatusdml);fflush(stdout);
//																			if( (tc_strcmp(ReleaseStatusdml,LcsStdRlzd)==0))
//																			{
//																				dmlRlzFlg=1;
//																				break;
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													 }
//												}
//											}
//										}																
//
//										//#######################################################//
//										printf("\n dmlRlzFlg:%d \t FlagPrevPartRlzd:%d",dmlRlzFlg,FlagPrevPartRlzd);fflush(stdout);
										printf("\n prtRlzFlg:%d ",prtRlzFlg);fflush(stdout);

										//if( (dmlRlzFlg==0) && (FlagPrevPartRlzd==0))
										if( prtRlzFlg==0) //TZ1.43-As no need to check for DML and TAsk release for part release
										{
											PrevRevDMLSet=NULL;
											PrevRevDMLSet=(char *)MEM_alloc(1000);
											tc_strcpy(PrevRevDMLSet," ");

											 tc_strcat(PrevRevDMLSet,"\nBelow Previous Revisions are skipped for release from STDSI:");	
											 tc_strcat(PrevRevDMLSet,"\nPrevious Revision (");
											 tc_strcat(PrevRevDMLSet,pre_revision);
											 tc_strcat(PrevRevDMLSet,") Of Part ");
											 tc_strcat(PrevRevDMLSet,Part_no);
											// tc_strcat(PrevRevDMLSet," is contained in DML ");//TZ1.43
											// tc_strcat(PrevRevDMLSet,DmlName);
											// tc_strcat(PrevRevDMLSet," which is not released from STDSI ");	
											 tc_strcat(PrevRevDMLSet,"  is not released from STDSI ");	
											 
											setAddStrFuction(icountprev,SetStdRelErr,PrevRevDMLSet);
											cntFlagprev = 1;

											printf("\n cntFlagprev = %d  ##\n",cntFlagprev);fflush(stdout);

											//Added By Dhanashri Skip Previous Revision UATZ1.42//

												 /*
												 1. Softcheck for this check (pending)
												 2. Set SkipPrevRev on prev rev tag till it get the released prev rev
												 */
												 if(FlagSkpRev==1)
												 {
												  ITKCALL(AOM_lock(AssyPreTag));
												  ITKCALL(AOM_set_value_string(AssyPreTag,"t5_SkipPrevRevSTD",Cur_revision));
												  ITKCALL(AOM_save_with_extensions(AssyPreTag) );
												  ITKCALL(AOM_unlock(AssyPreTag));
	
												  //get the prev rev of AssyPreTag and set 	t5_SkipPrevRevSTD if its not released from plant.
													tag_t			AssyPreTagCpy			= NULLTAG;
												    AssyPreTagCpy=AssyPreTag;

												   FindPrevRevLabel1:
													printf("\n inside FindPrevRevLabel ");fflush(stdout);
												  
												  	const char *qry_entries[2];//Multiple Item Queried Error
													const char *qry_values[2];//Multiple Item Queried Error
													int n_tags_found=0;
													tag_t	*itemclassp	= NULLTAG;
													tag_t item = NULLTAG;
													int Item_count      =  0;
													tag_t	*rev_list				= NULL;

													int PreRevFlag=0;
													int RevFlag=0;
													int ii=0;
													int LCSi=0;

													char			*prev_rev		= NULL;
													char			*Part_rev_Id		= NULL;
													char			*Part_Rev_copy		= NULL;
													char			*RevOnly		= NULL;
													char			*PreRevOnly		= NULL;
													char*			class_name=NULL;

													int stat_count=0;
													tag_t*			stat_list;
													int FlagPrevRevRlzd=0;
													char	*Part_clr_ind	=	NULL;
													
												   ITKCALL(AOM_ask_value_string(AssyPreTagCpy, "item_revision_id",&prev_rev));
												   ITKCALL(AOM_ask_value_string(AssyPreTagCpy, "item_revision_id",&Part_Rev_copy));
												   printf("\n prev_rev %s.....\n",prev_rev);fflush(stdout);
												   printf("\n Part_Rev_copy %s.....\n",Part_Rev_copy);fflush(stdout);
												   Part_clr_ind	=	NULL;
													ITKCALL(AOM_ask_value_string(AssyPreTagCpy,"t5_ColourInd",&Part_clr_ind));
													 printf("\n Part_clr_ind %s.....\n",Part_clr_ind);fflush(stdout);
													
													qry_entries[0] ="item_id";
													qry_entries[1] ="object_type";//Multiple Item Queried Error
													qry_values[0] = Part_no;
													if (tc_strcmp(Part_clr_ind,"C")==0)
													{
														qry_values[1] = "T5_ClrPart";//Multiple Item Queried Error Hemal
													}
													else
													{
														//qry_values[1] = "Design";//Multiple Item Queried Error Hemal
														//Handle the different design child class.
														char	*designBORev		=	NULL;
														char	*designBO			=	NULL;
														//tag_t	AssyTag			=	NULLTAG;
														//AssyTag=PartTags[k];
														printf("\nBefore getDesignType");fflush(stdout);
														getDesignType(AssyPreTagCpy, &designBORev,&designBO);
														printf("\nAfter getDesignType : %s",designBO);fflush(stdout);
														qry_values[1] = designBO;

													}//Multiple Item Queried Error
													//ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclassp);
													ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found, &itemclassp);//Multiple Item Queried Error
													
													item = itemclassp[0];

													ITKCALL(ITEM_list_all_revs (item, &Item_count, &rev_list));
													printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);

													if(Item_count > 0)
													{
														RevFlag = 0;
														PreRevFlag = 0;
														for(ii=Item_count-1;ii>=0;ii--)
														{
														   RevOnly = NULL;
														   PreRevOnly = NULL;
														   ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));
															printf("\n Part_rev_Id: %s\n",Part_rev_Id);fflush(stdout);
															if(tc_strcmp(prev_rev,Part_rev_Id)==0)
															{
																RevFlag = 1;
															}
															printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
															if(RevFlag == 1)
															{
															   RevOnly= strtok( Part_Rev_copy, ";" );
															   PreRevOnly= strtok( Part_rev_Id, ";" );
															   printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
															   printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
															   if(tc_strcmp(RevOnly,PreRevOnly)!=0)
																{
																  PreRevFlag = 1;
																}
															}
															printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
															if(PreRevFlag == 1)
															{
																//set t5SkipPrevRev if not released from plant
																printf("\n check whether part released from plant");fflush(stdout);
																ITKCALL(WSOM_ask_release_status_list(rev_list[ii],&stat_count,&stat_list));
																if(stat_count == 0)
																{
																	printf("\n NO LCS Found for part : %d\n",stat_count);fflush(stdout);
																	//break;
																}
																else
																{
																	for (LCSi=0;LCSi<stat_count ;LCSi++ )
																	{
																		ITKCALL(AOM_ask_value_string(stat_list[LCSi],"object_name",&class_name));
																		printf("\n class_name: %s\n",class_name);fflush(stdout);
																		
																		if(tc_strcmp(class_name,LcsStdRlzd)==0)
																		{
																			FlagPrevRevRlzd=1;
																			break;
																		}
																	}
																	printf("\n FlagPrevRevRlzd : %d\n",FlagPrevRevRlzd);fflush(stdout);
																   
																}

																if(FlagPrevRevRlzd==0)
																{
																	  printf("\n set t5SkipPrevRev and goto FindPrevRevLabel");fflush(stdout);
																	  ITKCALL(AOM_lock(rev_list[ii]));
																	  ITKCALL(AOM_set_value_string(rev_list[ii],"t5_SkipPrevRevSTD",Cur_revision));
																	  ITKCALL(AOM_save_with_extensions(rev_list[ii]) );
																	  ITKCALL(AOM_unlock(rev_list[ii]));

																	  AssyPreTagCpy=rev_list[ii];
																	  goto FindPrevRevLabel1;
																}
																else
																{
																	printf("\n Found Release revision Part_rev_Id: [%s]\n",Part_rev_Id);fflush(stdout);
																	break;
																}

															} // if(PreRevFlag == 1)
														} // for(ii=Item_count-1;ii>=0;ii--)
													} //if(Item_count > 0)
											      } // if(FlagSkpRev==1)
												 //End of Code Added By Dhanashri Skip Previous Revision UATZ1.42//

										}
						}

						
					}
				}

				printf("\n PrevRevDMLSet:%s",PrevRevDMLSet);fflush(stdout);
				printf("\n PrevRevEPASet:%s",PrevRevEPASet);fflush(stdout);

/*
				if(strlen(PrevRevDMLSet)>10)
						{
							tc_strcat(SetStdRelErr,PrevRevDMLSet);	
							//cntFlag = 1;
						}
						if(strlen(PrevRevEPASet)>10)
						{
							tc_strcat(SetStdRelErr,PrevRevEPASet);	
							//cntFlag = 1;
						}
					
	*/
				
				
			return 0;

}

//int Prev_Rev_Checks_SMDML(int PartCnt, tag_t* PartTags,char* SetStdRelErr,char* itemid,char* ProjectCode,char *STDDmlPlnt)
int Prev_Rev_Checks_SMDML(int PartCnt, tag_t* PartTags,char	***SetStdRelErr,char* itemid,char* ProjectCode,char *STDDmlPlnt,int *icount) // added by dss 1.53
{
	
	char			*PrevRevSMDMLSet		= NULL;
	char  ItemIDCpy[40];
	char LcsStdWrkg[40];
	char LcsStdRlzd[40];
	char inp_Plant[40];
	char Pretask_Plant[40];
	int				task_len			= 0;
	char			*inp_PlntLstLtr		= NULL;
	char			*Cur_revision		= NULL;
	char			*Part_no			= NULL;
	int				count_task			= 0;
	tag_t*			PartEpaTags			= NULLTAG;
	int				cnt_tk				= 0;
	tag_t			PartepaTag			= NULLTAG;
	tag_t			itemTypeTag_class	= NULLTAG;
	char			*epaTaskId			= NULL;
	char*			type_class			=NULL;
	char			*epa_Plant			= NULL;
	logical			CurrentRevInEPA2;
	char			*Part_Rev			= NULL;
	int				prevRevinEPA		= 0;
	int				prtRlzFlg			= 0;
	int				dmlRlzFlg			= 0;
	int				stlst				= 0,st_dmlcount=0,smdmlErrorCnt=0,k=0;

	char			*itemidpre			= NULL;
	char			*pre_revision		= NULL;
	char			*ReleaseStatuspart		= NULL;
	char			*PreTaskId		= NULL;
	tag_t*			prt_status_list		= NULLTAG;

	tag_t			AssyTag				= NULLTAG;
	tag_t			AssyPreTag			= NULLTAG;
	tag_t			relation_type_task	= NULLTAG;
	int				st_prt				= 0	,	Precnt=0,smDmlFnd=0;
	tag_t*			PrePartTskTags		= NULLTAG;
	int				precount_task		= 0,smRlzFlg=0;
	tag_t			PreParttskTag		= NULLTAG;
	tag_t			PreitemTypeTag_class2= NULLTAG;
	//char			Pretype_class2[TCTYPE_name_size_c+1];
	char*			Pretype_class2;
	char			*dmlId				= NULL;
	char			*ReleaseStatusdml				= NULL;
	char			*STDDmlPlntSM				= NULL;
	tag_t*			dml_status_list		= NULLTAG;

	//if (!PrevRevSMDMLSet) MEM_free(PrevRevSMDMLSet);
	//PrevRevSMDMLSet=(char *)MEM_alloc(2000);
	//tc_strcpy(PrevRevSMDMLSet," ");

	printf("\n\n ##############Inside Previous revision SM checks##############");fflush(stdout);

   
	//tc_strcpy(ItemIDCpy,itemid);
	GetPlantWiseRelStat(itemid,LcsStdWrkg,LcsStdRlzd);
	printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);fflush(stdout);
	printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);fflush(stdout);

	task_len=0;
	task_len=strlen(itemid);
	printf("\t  TaskName is :  %s\n", itemid);fflush(stdout);
	printf("\t  task_len ...%d\n", task_len);fflush(stdout);// length task
	GetPlantForDMLORTask(itemid,inp_Plant);	
	printf("\t  inp_Plant after  ...%s\n", inp_Plant);fflush(stdout);

	inp_PlntLstLtr=subString(itemid,17,task_len);
	printf("\t  inp_PlntLstLtr after  ...%s\n", inp_PlntLstLtr);fflush(stdout);
	printf("\t  input ProjectCode  ...%s,PartCnt %d\n", ProjectCode,PartCnt);fflush(stdout);

	STDDmlPlntSM= strtok( STDDmlPlnt, " " );

	printf("\t  STDDmlPlntSM %s\n", STDDmlPlntSM);fflush(stdout);
	
	for (k=0;k<PartCnt ;k++ )
	{					
		printf("\n\n\t\t Prev_Rev_Checks:for k_1 =:%d",k);fflush(stdout);
		AssyTag=PartTags[k];
		
		AssyPreTag=NULLTAG;
		PartEpaTags=NULLTAG;
		CurrentRevInEPA2=false;


		ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
		printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);

		ITKCALL(AOM_ask_value_string(AssyTag, "item_revision_id",&Cur_revision));
		printf("\n Cur_revision %s.....\n",Cur_revision);fflush(stdout);

		ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type_task));
		ITKCALL(GRM_list_primary_objects_only(AssyTag,relation_type_task,&count_task,&PartEpaTags));
		printf("\n count_task %d.....\n",count_task);fflush(stdout);
		if(count_task >0)
		{						
			for (cnt_tk=0;cnt_tk<count_task ;cnt_tk++ )
			{
				printf("\n cnt_tk %d.....\n",cnt_tk);fflush(stdout);
				PartepaTag=NULLTAG;
				PartepaTag=PartEpaTags[cnt_tk];
				if (PartepaTag!=NULLTAG)//Added by Hemal to check object is NULL or not
				{
					itemTypeTag_class	=	NULLTAG;
					type_class			=	NULL;
					ITKCALL(TCTYPE_ask_object_type(PartepaTag,&itemTypeTag_class));
					
					if (itemTypeTag_class!=NULLTAG)//Added by Hemal to check object is NULL or not
					{
						ITKCALL(TCTYPE_ask_name2(itemTypeTag_class,&type_class));

						printf("\t  type_class ...%s\n", type_class);fflush(stdout);
						if(tc_strcmp(type_class,"T5_EPATaskRevision")==0)
						{
							epaTaskId	=	NULL;//Added by Hemal
							ITKCALL(AOM_ask_value_string(PartepaTag, "item_id",&epaTaskId));
							printf("\n epaTaskId %s.....\n",epaTaskId);fflush(stdout);
							
							/*epa_Plant	=	NULL;//Added by Hemal
							epa_Plant=subString(epaTaskId,22,strlen(epaTaskId));
							printf("\t  epa_Plant after  ...%s\n", epa_Plant);fflush(stdout);
							
							if(tc_strcmp(inp_Plant,epa_Plant)==0)
							{
								CurrentRevInEPA2=true;
								break;
							}*/
							if(tc_strstr(epaTaskId,inp_Plant)!=NULL)
							{
								printf("\n Matching Plant Found...");fflush(stdout);
								CurrentRevInEPA2=true;
								break;
							}
							else
							{
								printf("\n Matching Plant not Found...");fflush(stdout);
							}
						}
					}else
					{
						printf("\t  itemTypeTag_class NULL TAG Found !!!");fflush(stdout);
					}
				}
				else
				{
					printf("\t  PartepaTag NULL TAG Found !!!");fflush(stdout);
				}
			}
			printf("\t  Loop End !!!!");fflush(stdout);

		}

			ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev));
		printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);

		if(strstr(Part_Rev,"NR"))
		{
			printf("\n Previous revision function can not be called as current revision has NR revision");fflush(stdout);
		}
		else
		{
			printf("\n Calling function to get Previous revision ");fflush(stdout);
			tm_fnd_Prev_Official_Revision(Part_no,AssyTag,&AssyPreTag);//TZ 1.43
		}				
							
	if(AssyPreTag)
		{
			prtRlzFlg=0;
			ITKCALL(AOM_ask_value_string(AssyPreTag, "item_id",&itemidpre));
			printf("\n itemidpre %s.....\n",itemidpre);fflush(stdout);

			ITKCALL(AOM_ask_value_string(AssyPreTag, "item_revision_id",&pre_revision));
			printf("\n pre_revision %s.....\n",pre_revision);	fflush(stdout);					

			ITKCALL(WSOM_ask_release_status_list(AssyPreTag,&st_prt,&prt_status_list));
			for (stlst = 0; stlst < st_prt; stlst++)
			{
				AOM_ask_name(prt_status_list[stlst], &ReleaseStatuspart);
				printf("\n ReleaseStatuspart %s \n",  ReleaseStatuspart);fflush(stdout);
				if(tc_strcmp(ReleaseStatuspart,LcsStdRlzd)==0)
				{
					prtRlzFlg=1;
				}
			}

			if((CurrentRevInEPA2!=true) && (prtRlzFlg>0))
			{
				printf("\n Current revision is not in epa of same plant, checking whether previous revision is in SMDML of same plant");fflush(stdout);						
				
				Precnt=0;
				PrePartTskTags=NULLTAG;
				smDmlFnd=0;
				GRM_list_primary_objects_only(AssyPreTag,relation_type_task,&precount_task,&PrePartTskTags);
				if(precount_task >0)
				{							
					smRlzFlg=0;					 //deepak changed before for loop
					
					for (Precnt=0;Precnt<precount_task ;Precnt++ )
					{
						PreParttskTag=NULLTAG;
						PreParttskTag=PrePartTskTags[Precnt];

						if (PreParttskTag!=NULLTAG)//Added by Hemal
						{
							PreitemTypeTag_class2	=	NULLTAG;
							Pretype_class2			=	NULL;
							ITKCALL (TCTYPE_ask_object_type(PreParttskTag,&PreitemTypeTag_class2));
							//ITKCALL (TCTYPE_ask_name(PreitemTypeTag_class2,Pretype_class2));
							ITKCALL (TCTYPE_ask_name2(PreitemTypeTag_class2,&Pretype_class2));

							printf("\t  Pretype_class2 ...%s\n", Pretype_class2);fflush(stdout);	
							
						//	smRlzFlg=0;     // deepak commented, added before for loop 
							

							if(tc_strcmp(Pretype_class2,"T5_SMDMLTaskRevision")==0)
							{
								PreTaskId	=	NULL;
								ITKCALL(AOM_ask_value_string(PreParttskTag, "item_id",&PreTaskId));
								printf("\n deepak PreTaskId %s.....\n",PreTaskId);	fflush(stdout);									

								//Pretask_Plant=subString(PreTaskId,17,strlen(PreTaskId));
								//Pretask_Plant	=	NULL;
								GetPlantForDMLORTask(PreTaskId,Pretask_Plant);	
								printf("\t  deepak Pretask_Plant after  ...%s:::: %s", Pretask_Plant,STDDmlPlnt);fflush(stdout);
								
								dmlId	=	NULL;
								dmlId=subString(PreTaskId,2,2);
								printf("\n dmlId:%s",dmlId);fflush(stdout);

								if(tc_strcmp(dmlId,"SM")==0 && (tc_strcmp(Pretask_Plant,STDDmlPlnt)==0))
								{

									smDmlFnd++;
									stlst = 0;
									ITKCALL(WSOM_ask_release_status_list(PreParttskTag,&st_dmlcount,&dml_status_list));
									for (stlst = 0; stlst < st_dmlcount; stlst++)
									{
										AOM_ask_name(dml_status_list[stlst], &ReleaseStatusdml);
										printf("\n ReleaseStatusdml %s :::LcsStdRlzd %s\n",  ReleaseStatusdml,LcsStdRlzd);fflush(stdout);
										if(tc_strcmp(ReleaseStatusdml,LcsStdRlzd)!=0 )
										{
											
											printf("\n Previous revision of part is contanied in SMDML which is not stdsi released, carry forward previous revision changes into current revision");fflush(stdout);
											//#############Logic to carry forward previous revision changes#############//



											//##########################################################################//
										}
										else
										{
											smRlzFlg++;
										
										}
									}
								}
							}
						}
					}
					printf("\n smRlzFlg %d :: smDmlFnd %d",smRlzFlg,smDmlFnd);fflush(stdout);
					if((smRlzFlg==0) && (smDmlFnd>0))
					{
						printf("\n 111 smdmlErrorCnt %d" ,smdmlErrorCnt);fflush(stdout);
						 if(smdmlErrorCnt==0)
						 {
							 	//if (!PrevRevSMDMLSet) MEM_free(PrevRevSMDMLSet);
								PrevRevSMDMLSet=NULL;
								PrevRevSMDMLSet=(char *)MEM_alloc(1000);
								tc_strcpy(PrevRevSMDMLSet," ");


							 tc_strcat(PrevRevSMDMLSet,"\n Below Previous Revision of Part is attached to SM-DML which is not STDSI released.Please release the SM-DML.");	
							 tc_strcat(PrevRevSMDMLSet,"\n");
							 tc_strcat(PrevRevSMDMLSet,itemidpre);
							 tc_strcat(PrevRevSMDMLSet,":");
							 tc_strcat(PrevRevSMDMLSet,pre_revision);
							 tc_strcat(PrevRevSMDMLSet,";SM-DML Task :");
							 tc_strcat(PrevRevSMDMLSet,PreTaskId);	
							 smdmlErrorCnt++;

							 setAddStrFuction(icount,SetStdRelErr,PrevRevSMDMLSet); //added by dss 1.53
							 cntFlag = 1;
							 printf("\n 111 PrevRevSMDMLSet %s" ,PrevRevSMDMLSet);fflush(stdout);
						 }
						 else
						 {
							 PrevRevSMDMLSet=NULL;
							 PrevRevSMDMLSet=(char *)MEM_alloc(1000);
							 tc_strcpy(PrevRevSMDMLSet," ");

							 tc_strcat(PrevRevSMDMLSet,"\n");
							 tc_strcat(PrevRevSMDMLSet,itemidpre);
							 tc_strcat(PrevRevSMDMLSet,":");
							 tc_strcat(PrevRevSMDMLSet,pre_revision);
							 tc_strcat(PrevRevSMDMLSet,";SM-DML Task :");
							 tc_strcat(PrevRevSMDMLSet,PreTaskId);	
							 smdmlErrorCnt++;

							 setAddStrFuction(icount,SetStdRelErr,PrevRevSMDMLSet); //added by dss 1.53
							 cntFlag = 1;
							 printf("\n 1112222 PrevRevSMDMLSet %s" ,PrevRevSMDMLSet);fflush(stdout);
						 }
					}
					
				}

				
			}

		}
	}

	printf("\n PrevRevSMDMLSet:%s",PrevRevSMDMLSet);fflush(stdout);

/*
	if(smdmlErrorCnt>0)
	{
		//tc_strcat(SetStdRelErr,PrevRevSMDMLSet);	
		setAddStrFuction(icount,SetStdRelErr,PrevRevSMDMLSet); //added by dss 1.53
		cntFlag = 1;
	}
	*/
		
	return 0;

}
//########################################################################################//
//At the time of sign off of APL AMDML, this validation will ensure whether the PP/PM DML
//for part is released or not.
//########################################################################################//

//int AMDML_Std_Validation(int PartCnt,tag_t	sTaskTag, tag_t* PartTags,char* SetStdRelErr)
int AMDML_Std_Validation(int PartCnt,tag_t	sTaskTag, tag_t* PartTags,char	***SetStdRelErr,int *icount) // added by dss 1.53
{

			int k = 0;
			int cnt1 = 0;
			int ppDMLFnd=0;
			int             st_count			= 0;
			int				n_refs				= 0;
			int				task_len			= 0;
			int				inp_len				= 0;
			int				cntErr				= 0;
			int				ifail				= ITK_ok;
			int				 *levels			= 0;
			int				n_tags_found1=0;
			int				cntSt=0;
			int				errCount=0;
			int				dmlcount=0;
			int				j=0;
			int				task_project_tags_found=0;
			int				part_project_tags_found=0;
			int				dml_project_tags_found=0;
			int				bypassChk=0;

			char			*Item_id = NULL;
			char*			ChildDml;
			char *  IsPPPPMRlzErr = NULL;
			char *  SetIsPPPPMRlzErr = NULL;
			char*			Part_no				= NULL;
			char*			Part_Rev				= NULL;
			char*			Part_DRStatus				= NULL;
			char*			inp_task_no			= NULL;
			char*			class_name=NULL;
			char			task_type_Proj[TCTYPE_name_size_c+1];
			char			dml_type_Proj[TCTYPE_name_size_c+1];
			//char			*inp_Plant			= NULL;
			//char			*task_Plant			= NULL;
			char            *desid				= NULL;
			char            *task_projCode		= NULL;
			char			*dml_type			= NULL;
			char			*DMLDRStatus		= NULL;
			char			*dmlId				= NULL;
			char			*task_PlantName		= NULL;
			// API change
			//char			type_name_ref[TCTYPE_name_size_c+1];
			char *type_name_ref = NULL;
			char			**relations			= NULL;
			char*			lcsToset			= NULL;
			char*			dml_projCode		= NULL;
			char*			part_PlantName		= NULL;
			char			Part_type_Proj[TCTYPE_name_size_c+1];
			char*			dml_PlantName		= NULL;

			tag_t			item_rev_tag_p				= NULLTAG;
			tag_t			objTypeRefTag				= NULLTAG;
			tag_t			AssyTag						= NULLTAG;
			tag_t			*referencers				= NULLTAG;
			tag_t			item1						= NULLTAG;
			tag_t			tsk_dml_rel_type;
			tag_t			ObjTypTaskProj				= NULLTAG;
			tag_t			ObjTypDMLProj				= NULLTAG;
			tag_t			ObjTypPartProj				= NULLTAG;



			tag_t*    status_list;
			tag_t	*itemclass1							= NULLTAG;
			tag_t			relation_type= NULLTAG;
			tag_t			PartDmlTaskTag				= NULLTAG;
			tag_t			DmlRevTag			= NULLTAG;

			tag_t*			PartDmlTaskTags			= NULLTAG;
			tag_t*			DMLRevision			= NULLTAG;
			tag_t	*task_projectclass	= NULLTAG;
			tag_t	*dml_projectclass	= NULLTAG;
			tag_t	task_project_item	= NULLTAG;
			tag_t	dml_project_item	= NULLTAG;
			tag_t	part_project_item	= NULLTAG;
			tag_t	*part_projectclass	= NULLTAG;

			const char *attrs[1];
		    const char *values[1];
			const char *task_project_qry_entries[1];
		    const char *task_project_qry_values[1];
			
			const char *part_project_qry_entries[1];
		    const char *part_project_qry_values[1];

			const char *dml_project_qry_entries[1];
		    const char *dml_project_qry_values[1];

			char inp_Plant[40];
			char task_Plant[40];

			tag_t Rel_Typ_tag2 = NULLTAG; //Deepti TZ1.53
			int AMDML_Count = 0;
			int amCnt = 0;
			int aplRestDMLDnd = 0;
			int AMDML_Count1 = 0;
			int aCn = 0;
			int amStCnt = 0;
			int TaskRelease = 0;
			int amdmlRlzdLcsFnd = 0;
			int AMDMLErrorFlag = 0;
			tag_t *AMDML_tag = NULLTAG;
			tag_t *AMDML_tag1 = NULLTAG;
			tag_t Rel_Typ_tag_AM = NULLTAG;
			tag_t AMDML = NULLTAG;
			tag_t AMDML1 = NULLTAG;
			char *AMDMLID = NULL;
			char *AMDMLID1 = NULL;
			char *AMDML_ECNType = NULL;
			char *AMDML_ECNType1 = NULL;
			char *AMDML_DtRlz = NULL;
			char *AMDMLRlzStatusName = NULL;


			

			lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
			printf("\n Inside t5StdAMDMLValidation_Check_Func_New ....\n");
			cntErr = 0;

			ITKCALL(AOM_ask_value_string(sTaskTag,"item_id",&inp_task_no));
			printf("\n\n\t\t t5StdAMDMLValidation_Check_Func_New :inp_task_no  is :%s",inp_task_no);	fflush(stdout);

			if(strstr(inp_task_no,"AM"))
			{
				
				//Start Deepti TZ1.53  To check ecnttype of AMDML
				GRM_find_relation_type("T5_DMLTaskRelation", &Rel_Typ_tag2);
				GRM_list_primary_objects_only(sTaskTag,Rel_Typ_tag2,&AMDML_Count,&AMDML_tag);   
				printf("\n AMDML_Count = %d",AMDML_Count);fflush(stdout);
				if (AMDML_Count>0)
				{
					for(amCnt=0;amCnt<AMDML_Count;amCnt++)
					{
						AMDML = AMDML_tag[amCnt];

						ITKCALL(AOM_ask_value_string(AMDML,"item_id",&AMDMLID));
						ITKCALL(AOM_ask_value_string(AMDML,"t5_EcnType",&AMDML_ECNType));
						printf("\n 111 AMDML_ECNType : %s   \n",AMDML_ECNType);fflush(stdout);
						if ((tc_strcmp(AMDML_ECNType,"APLSTR")== 0))
						{
							aplRestDMLDnd++;
						}
						

					}
				}

				if(aplRestDMLDnd>0)
				{
												
				
					inp_len=0;
					inp_len=strlen(inp_task_no);
					if(strstr(inp_task_no,"NONERC"))
					{
						//inp_Plant=subString(inp_task_no,18,inp_len);
						GetPlantForDMLORTask(inp_task_no,inp_Plant);	
					}
					else
					{
						//inp_Plant=subString(inp_task_no,14,inp_len);
						GetPlantForDMLORTask(inp_task_no,inp_Plant);
					}
					printf("\n inp_Plant:%s",inp_Plant);fflush(stdout);

	
					char  ItemIDCpy[40];
					char LcsStdWrkg[40];
					char LcsStdRlzd[40];
					tc_strcpy(ItemIDCpy,inp_task_no);
					GetPlantWiseRelStat(ItemIDCpy,LcsStdWrkg,LcsStdRlzd); //TZ3.46
					printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
					printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);
					strcpy(lcsToset,LcsStdRlzd);

					printf("\n t5StdAMDMLValidation_Check_Func ..............");fflush(stdout);
					for (k=0;k<PartCnt ;k++ )
					{
						printf("\n\n\t\t STD DML Cre:for k =:%d",k);fflush(stdout);
						ppDMLFnd=0;
						AMDMLErrorFlag=0;
						TaskRelease=0;
						AssyTag=PartTags[k];

						ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
						printf("\n\n\t\t STD DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);

						ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev));
						printf("\n\n\t\t STD DML Cre:Part_Rev  is :%s",Part_Rev);	fflush(stdout);

						//Added By Dhanashri for skip prev rev UATZ1.42//

						 char*			SkipPrevRevSTD				= NULL;
						 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
						 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
						 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
						   
						  //if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
						  if(tc_strlen(SkipPrevRevSTD)>0)
						  {
							printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
							continue;
						  }
						//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//


						
						ITKCALL(AOM_ask_value_string(AssyTag,"t5_PartStatus",&Part_DRStatus));
						printf("\n\n\t\t STD DML Cre:Part_DRStatus  is :%s",Part_DRStatus);	fflush(stdout);

						n_refs=0;
						PartDmlTaskTags=NULLTAG;
						ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
						ITKCALL(GRM_list_primary_objects_only(AssyTag,relation_type,&n_refs,&PartDmlTaskTags));
						printf("\n\n\t\t n_refs ==%d",n_refs);fflush(stdout);
						
						if (n_refs >0)
						{
							for (cnt1=0;cnt1<n_refs ;cnt1++ )
							{
								PartDmlTaskTag=PartDmlTaskTags[cnt1];//task pointer
								printf("\n\n\t\t INSIDE EPA_Part_PP_DML_Rlzd_Checks: ");fflush(stdout);
								
								ITKCALL(TCTYPE_ask_object_type(PartDmlTaskTag,&objTypeRefTag));
								ITKCALL(TCTYPE_ask_name2(objTypeRefTag,&type_name_ref));
								printf("\nTCDCtype_name_ref isss :%s\n",type_name_ref);fflush(stdout);
								if (strcmp(type_name_ref,"T5_APLTaskRevision")==0)
								{

									if( AOM_ask_value_string(PartDmlTaskTag,"item_id",&desid)!=ITK_ok);
									printf("\n saveCS_method::Design Revision Item ID %s:ItemIDCpy %s\n", desid,ItemIDCpy);fflush(stdout);

									if(strcmp(ItemIDCpy,desid)==0)	//Deepti TZ1.53
									{
										TaskRelease=1;
										continue;
									}


									else{
         
									//sunny_added

									char *dmlNo=NULL;
									char  *orgTaskVar;
									char *dupdesid=NULL;
                                    tc_strdup(desid,&dupdesid);
                                    tc_strdup(ItemIDCpy,&orgTaskVar);
                                    printf("~~~~~Sunny~~~~ORGINOL TASK Variable~~~~%s\n",orgTaskVar);
                                    printf("~~~~~Sunny~~~~Desid~~~~%s\n",dupdesid);
                                    //ORIGINAL Variable- ItemIDCpy
									dmlNo=tc_strtok(dupdesid,"_");
                                    printf("~~~~~Sunny~~~~DML NO~~~~%s\n",dmlNo);
									//if((tc_strstr(ItemIDCpy,dmlNo)!=NULL) &&  (tc_strstr(ItemIDCpy,designGrop)!=NULL) && (tc_strstr(ItemIDCpy,plantName)!=NULL))
									if((tc_strstr(ItemIDCpy,dmlNo)!=NULL))
									
									{
									  printf("~~~~~~Skip for PR Task~~~~~~~~~\n");
									  continue;
									}
								}



									if( AOM_ask_value_string(PartDmlTaskTag,"t5_cprojectcode",&task_projCode)!=ITK_ok);
									printf("\n task_projCode %s\n", task_projCode);fflush(stdout);

									dml_type=subString(desid,2,2);
									ChildDml=subString(desid,0,10);
									printf("\ndml_type:%s",dml_type);fflush(stdout);
									printf("\n ChildDml:%s",ChildDml);fflush(stdout);

									task_len=0;
									task_len=strlen(desid);
									if(strstr(desid,"NONERC"))
									{
										//task_Plant=subString(desid,18,task_len);
										GetPlantForDMLORTask(desid,task_Plant);	
									}
									else
									{
										//task_Plant=subString(desid,14,task_len);
										GetPlantForDMLORTask(desid,task_Plant);	
									}
									printf("\n task_Plant:%s",task_Plant);fflush(stdout);
									printf("\n inp_Plant:%s",inp_Plant);fflush(stdout);

									st_count=0;
									status_list=NULLTAG;
									ITKCALL(WSOM_ask_release_status_list(PartDmlTaskTag,&st_count,&status_list));
									printf("\n st_count:%d",st_count);fflush(stdout);

									//IsPPPPMRlzErr=NULL;
									//IsPPPPMRlzErr=(char *)MEM_alloc(3000);
									//tc_strcpy(IsPPPPMRlzErr," ");

									if(tc_strcmp(inp_Plant,task_Plant)==0)
									{
										
										amdmlRlzdLcsFnd=0;
										if(tc_strcmp(dml_type,"AM")==0) //Deepti TZ1.53
										{
											ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &Rel_Typ_tag_AM)); //Deepti TZ1.53
											ITKCALL(GRM_list_primary_objects_only(PartDmlTaskTag,Rel_Typ_tag_AM,&AMDML_Count1,&AMDML_tag1));   
											printf("\n AMDML_Count1 = %d",AMDML_Count1);fflush(stdout);
											if (AMDML_Count1>0)
											{
												for(aCn=0;aCn<AMDML_Count1;aCn++)
												{
													AMDML1 = AMDML_tag1[aCn];
													ITKCALL(AOM_ask_value_string(AMDML1,"item_id",&AMDMLID1));
													ITKCALL(AOM_ask_value_string(AMDML1,"t5_EcnType",&AMDML_ECNType1));
													printf("\n AMDML_ECNType1: %s   \n",AMDML_ECNType1);fflush(stdout);
													if ((tc_strcmp(desid,inp_task_no)!= 0))
													{
													if ((tc_strcmp(AMDML_ECNType1,"AMDML")!= 0))
														{
															ITKCALL(AOM_UIF_ask_value(PartDmlTaskTag,"date_released",&AMDML_DtRlz));
															printf("\n AMDML_DtRlz (NextRev): %s   \n",AMDML_DtRlz);fflush(stdout);
															
															if (st_count>0)
															{
																for(amStCnt=0;amStCnt<st_count;amStCnt++)
																{
																	AOM_ask_name(status_list[amStCnt], &AMDMLRlzStatusName);
																	printf("\n AMDMLRlzStatusName (NextRev) : %s \n",AMDMLRlzStatusName);fflush(stdout);

																	if (tc_strcmp(AMDMLRlzStatusName,lcsToset)== 0)
																	{
																		amdmlRlzdLcsFnd++;
																		break;
																	}
																}
															}

															if((amdmlRlzdLcsFnd>0) && ((AMDML_DtRlz != NULL)))
															{
																TaskRelease = 1;
																break;
															}
															else
															{
																IsPPPPMRlzErr=NULL;
																IsPPPPMRlzErr=(char *)MEM_alloc(500);
																tc_strcpy(IsPPPPMRlzErr," ");

																if(AMDMLErrorFlag>1)
																{
																	tc_strcat(IsPPPPMRlzErr," OR ");	
																}
																tc_strcat(IsPPPPMRlzErr,"AM Series DML Task ");
																tc_strcat(IsPPPPMRlzErr,desid);
																tc_strcat(IsPPPPMRlzErr," for Part ");
																tc_strcat(IsPPPPMRlzErr,Part_no);
																tc_strcat(IsPPPPMRlzErr," is not STDSI Released.\n");
																tc_strcat(IsPPPPMRlzErr," Please Release DML from STDS first and try respective DML.\n");
																cntErr=cntErr+1;	
																AMDMLErrorFlag++;
																
																setAddStrFuction(icount,SetStdRelErr,IsPPPPMRlzErr); // added by dss 1.53
																cntFlag = 1;

															
															}
															
														}
												}
													}
												
												}
										}

										if( (tc_strcmp(dml_type,"PP")==0) || (tc_strcmp(dml_type,"PM")==0) || (tc_strcmp(dml_type,"JP")==0) || (tc_strcmp(dml_type,"JM")==0) || (tc_strcmp(dml_type,"LP")==0) || (tc_strcmp(dml_type,"LM")==0))
										{
											
											if (st_count>0)
											{
												for(cntSt=0;cntSt<st_count;cntSt++)
												{

													ITKCALL(AOM_ask_value_string(status_list[cntSt],"object_name",&class_name));
													printf("\n class_name: %s\n",class_name);fflush(stdout);

													//if( (tc_strcmp(lcsToset,class_name)==0) && (cntSt==st_count-1))
													if( (tc_strcmp(lcsToset,class_name)==0) )
													{
														TaskRelease = 1;
														break;
													
													}
													else
													{
//														IsPPPPMRlzErr=NULL;
//														IsPPPPMRlzErr=(char *)MEM_alloc(500);
//														tc_strcpy(IsPPPPMRlzErr," ");
//
//														if(AMDMLErrorFlag>0)
//														{
//															tc_strcat(IsPPPPMRlzErr," OR ");	
//														}
//														tc_strcat(IsPPPPMRlzErr,"PP/PM Series DML Task ");
//														tc_strcat(IsPPPPMRlzErr,desid);
//														tc_strcat(IsPPPPMRlzErr," for Part ");
//														tc_strcat(IsPPPPMRlzErr,Part_no);
//														tc_strcat(IsPPPPMRlzErr," is not STDSI Released.\n");
//														tc_strcat(IsPPPPMRlzErr," Please Release DML from STDS first and try respective DML.\n");
//														cntErr=cntErr+1;
//													
//														setAddStrFuction(icount,SetStdRelErr,IsPPPPMRlzErr); // added by dss 1.53
//														cntFlag = 1;

													}
												}


											}
											
										}									
									}

									if(TaskRelease==1)
									{
										break;
									}
								}
								
							}

							if(TaskRelease==0)
							{
								IsPPPPMRlzErr=NULL;
								IsPPPPMRlzErr=(char *)MEM_alloc(500);
								tc_strcpy(IsPPPPMRlzErr," ");

								if(AMDMLErrorFlag>0)
								{
									tc_strcat(IsPPPPMRlzErr," OR ");	
								}
								tc_strcat(IsPPPPMRlzErr,"PP/PM Series DML Task ");
								tc_strcat(IsPPPPMRlzErr,desid);
								tc_strcat(IsPPPPMRlzErr," for Part ");
								tc_strcat(IsPPPPMRlzErr,Part_no);
								tc_strcat(IsPPPPMRlzErr," is not STDSI Released.\n");
								tc_strcat(IsPPPPMRlzErr," Please Release DML from STDS first and try respective DML.\n");
								cntErr=cntErr+1;
								
								setAddStrFuction(icount,SetStdRelErr,IsPPPPMRlzErr); // added by dss 1.53
								cntFlag = 1;

							}
							
							/*
							if(TaskRelease==0)
							{
								printf("\n IsPPPPMRlzErr:%s",IsPPPPMRlzErr);fflush(stdout);
								if (cntErr>0)
								{
									if(strlen(IsPPPPMRlzErr)>10)
								
									{
										//tc_strcat(SetStdRelErr,IsPPPPMRlzErr);
										setAddStrFuction(icount,SetStdRelErr,IsPPPPMRlzErr); // added by dss 1.53
										cntFlag = 1;
									}
								}
							}
							*/
						}


					}
				} //Deepti TZ1.53
			}

	return 0;

}


//TZ1.42 compilation DEEPTI for DML Released
int std_dml_release( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;
	char			*ClosureDate		= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
	char* WTlcsToset=NULL;//WT changes
    char* lcsToset=NULL;
    char* lcsToremove=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;


	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;
	tag_t         CurrentRoleTag = NULLTAG;

	//API Change
	char *roleName = NULL;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;

	char cNextDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char **DesignGroupList;
	//API change
	//char   type_name[TCTYPE_name_size_c+1];
	char *type_name = NULL;
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;

	int st_count_dml=0; //Added by Deepti
	int iLCS=0; //Added by Deepti
	char*			releasest_name			= NULL;//Added by Deepti
	tag_t*			status_list			=	NULLTAG;//Added by Deepti
	int   releaseStatusFnd			= 0;//Added by Deepti
	int   taskreleaseStatusFnd			= 0;//Added by Deepti
	int   dmlreleaseStatusFnd			= 0;//Added by Deepti
	int   task_st_count			= 0;//Added by Deepti
	int   dml_st_count			= 0;//Added by Deepti
	int   taskLCS				= 0;//Added by Deepti
	int   dmlLCS				= 0;//Added by Deepti
	char*			dml_releasest_name		= NULL;
	char*			task_releasest_name	= NULL;
	tag_t *task_status_list;
	tag_t *dml_status_list;
	char cCurrentAccessDate[20]={0};
	char cCurrentAccessDate1[20]={0};
	date_t			Task_Release_date;
	date_t			DML_Release_date;
	tag_t  TaskClosureDtAttrId = NULLTAG;
	tag_t  DMLClosureDtAttrId = NULLTAG;
	tag_t  Closure = NULLTAG;
	tag_t  Maturity = NULLTAG;
	tag_t  Disposition = NULLTAG;
	char   *TaskName	= NULL;
	char*	 DMLtype		= NULL;
	char	 *PlantNameP		= NULL;



	WTlcsToset =(char *) MEM_alloc(20 * sizeof(char *));//WT Changes
	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
	lcsToremove =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside std_dml_release***************\n ");fflush(stdout);
   //strcpy(lcsToset,"T5_LcsStdRlzd");

	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}


	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n std_dml_release \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	// Control Object for Calling EXE // Added By Ketan TZ 1.75

	char*	qry_entryCntrl_STD[3]	= {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char*	qry_valuesCntrl_STD[3]	= {"STD","Stamping","0"};
	
    tag_t	qryTagCntrl_STD				= NULLTAG;
    tag_t*	list_of_WSO_cntrl_tags_STD	= NULLTAG;

	int n_entryCntrl_STD			= 3;
	int control_number_found_STD	= 0;;

	CALLAPI(QRY_find2("Control Objects...", &qryTagCntrl_STD));

	if (qryTagCntrl_STD)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPI(QRY_execute(qryTagCntrl_STD, n_entryCntrl_STD, qry_entryCntrl_STD, qry_valuesCntrl_STD, &control_number_found_STD, &list_of_WSO_cntrl_tags_STD));

		printf("\n control_number_found_STD is : %d\n",control_number_found_STD);fflush(stdout);
	}

	if(control_number_found_STD>0)
	{
		printf("\n Control Object Based Execution for STD DML Stamping\n");fflush(stdout);

	    char* STD_DML_no = NULL;
		
		AOM_ask_value_string( DMLTag,"item_id",&STD_DML_no);
		printf("\n STD_DML_no => %s \n",STD_DML_no);fflush(stdout);

		char* t5_Userinfo1_STD = NULL;
		char cmd_STD[100];

		tag_t STD_obj = list_of_WSO_cntrl_tags_STD[0];
		CALLAPI(AOM_ask_value_string(STD_obj,"t5_Userinfo1",&t5_Userinfo1_STD));	
		sprintf(cmd_STD,"%s %s",t5_Userinfo1_STD,STD_DML_no);
		printf("\n Ketan Excuting Command = %s \n",cmd_STD);fflush(stdout);
		system(cmd_STD);
		printf("\n After executing Command \n");fflush(stdout);
	}
	else
	{
		printf("\n Non - Control Object Based Execution STD DML Stamping \n");fflush(stdout);
		
		if(strcmp(type_name,"T5_APLDMLRevision")==0)
		{
			    printf("\n inside class T5_APLDMLRevision......\n");fflush(stdout);
				AOM_ask_value_string( DMLTag, "item_id", &item_id);
				AOM_ask_value_string( DMLTag, "current_id", &DML_no);
				AOM_ask_value_strings(DMLTag,"t5_crdesigngroup",&num,&DesignGroupList);
				//AOM_ask_value_string(DMLTag,"t5_rlstype",&RlsType);
				AOM_ask_value_string( DMLTag, "t5_cprojectcode", &Proj_Code);

				printf("\n Proj_Code : %s\n",Proj_Code);fflush(stdout);
				printf("\n item_id : %s\n",item_id);fflush(stdout);
				printf("\n DML_no : %s\n",DML_no);fflush(stdout);
				printf("\n RlsType : %s\n",RlsType);fflush(stdout);
				printf("\n num is : %d\n",num);fflush(stdout);

				//strcpy(lcsToremove,"NA");
				//**********TZ3.46*********************//
				ITKCALL(SA_ask_current_role(&CurrentRoleTag));
				ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
				printf("\n\n  roleName : %s\n",roleName); fflush(stdout);		
				
				char AplRvwLC[40];
				char AplWrkngLC[40];
				char AplRlzd[40];
				char Stdwrknglc[40];
				char Stdrlzdlc[40];
				char PltLcs[40];
				char StdPlant[40];
				char StdRevRule[40];
				char StdCLosRule[40];
				char StdView[40];
				PlantNameP=subString(roleName,3,4);
				printf( "PlantNameP:%s\n", PlantNameP);  
				
				//get_CtrlVal_APLStateInf(PlantNameP,"","","",Stdwrknglc,Stdrlzdlc,"","","","","");//TZ1.46//Priti
				get_CtrlVal_STDStateInf(PlantNameP,AplRvwLC,AplWrkngLC,AplRlzd,Stdwrknglc,Stdrlzdlc,PltLcs,StdPlant,StdRevRule,StdCLosRule,StdView);//TZ1.46//Priti

				strcpy(WTlcsToset,"Obsolete");//WT Chnages
				strcpy(lcsToset,Stdrlzdlc);
				strcpy(lcsToremove,Stdwrknglc);
				//***********************************//


		    				printf("\n Item created first time only with item_id \n");fflush(stdout);
		                    if (DMLTag != NULLTAG)
							 {
								ITKCALL(AOM_ask_value_string(DMLTag,"t5_EcnType",&DMLtype));//TZ1.43
								printf("\n\t APLDMLtype is :%s",DMLtype); fflush(stdout);//TZ1.43

								GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
								 /// Solution Item start

								CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&count,&TaskRevision));
								printf("\n\n\t\t APL DML Cre:ERC DML to Task : %d",count);fflush(stdout);
							
								for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
								{
									TaskRevTag = TaskRevision[TaskCnt];

									CALLAPI(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
									printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);

									CALLAPI(AOM_ask_value_string(TaskRevTag,"item_id",&TaskName));//TZ1.43
									printf("\n\n\t\t TaskName is :%s",TaskName);fflush(stdout);//TZ1.43


									if(strcmp(object_type,"T5_APLTaskRevision")==0)
									{
										PartCnt=0;

										//taskreleaseStatusFnd=0;
										ITKCALL(WSOM_ask_release_status_list(TaskRevTag,&task_st_count,&task_status_list));
										
										for (taskLCS=0;taskLCS<task_st_count ;taskLCS++ )
										{
											ITKCALL(AOM_ask_value_string(task_status_list[taskLCS],"object_name",&task_releasest_name));
											printf("\n task_releasest_name: %s\n",task_releasest_name);fflush(stdout);
											if(tc_strcmp(task_releasest_name,lcsToset)==0)
											{
												taskreleaseStatusFnd++;
												break;
											}
										}

									}
							  }  /// Solution Item end

							dmlreleaseStatusFnd=0;
			
							if(taskreleaseStatusFnd==count)
							{
								ITKCALL(WSOM_ask_release_status_list(DMLTag,&dml_st_count,&dml_status_list));
								for (dmlLCS=0;dmlLCS<dml_st_count ;dmlLCS++ )
								{
									ITKCALL(AOM_ask_value_string(dml_status_list[dmlLCS],"object_name",&dml_releasest_name));
									printf("\n dml_releasest_name: %s\n",dml_releasest_name);fflush(stdout);
									if(tc_strcmp(dml_releasest_name,lcsToset)==0)
									{
										dmlreleaseStatusFnd++;
									}
								}
								printf("\n\n\t\t dmlreleaseStatusFnd := %d", dmlreleaseStatusFnd);fflush(stdout);
								
								
								getCurrentDateTime(cCurrentAccessDate);
								printf("\n For DML cCurrentAccessDate:%s",cCurrentAccessDate);fflush(stdout);
								ITKCALL(ITK_string_to_date(cCurrentAccessDate, &DML_Release_date ));

								CALLAPI(AOM_lock(DMLTag));
								CALLAPI(POM_attr_id_of_attr("date_released","T5_APLDMLRevision",&DMLClosureDtAttrId));
								CALLAPI(POM_attr_id_of_attr("CMClosure","T5_APLDMLRevision",&Closure)); //1.43
								CALLAPI(POM_attr_id_of_attr("CMMaturity","T5_APLDMLRevision",&Maturity));//1.43
								CALLAPI(POM_attr_id_of_attr("CMDisposition","T5_APLDMLRevision",&Disposition));//1.43
								CALLAPI(AOM_refresh(DMLTag,TRUE));
								CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
								CALLAPI(POM_set_attr_date(1,&DMLTag,DMLClosureDtAttrId,DML_Release_date));
								if(POM_set_attr_string(1,&DMLTag,Closure ,"Closed"));//1.43
								if(POM_set_attr_string(1,&DMLTag,Maturity,"Complete"));//1.43
								if(POM_set_attr_string(1,&DMLTag,Disposition,"Approved"));//1.43
								
								CALLAPI(AOM_save_with_extensions(DMLTag));
								CALLAPI(AOM_unlock(DMLTag));

								
								if(dmlreleaseStatusFnd==0)	//Deepti TZ3.52
								{
									status = t5UpdateLifecycleStateSTD(DMLTag, lcsToset,lcsToremove);
								}
							 }

						 }

		}
		else
		{
		  	printf("\n No proper class class T5_APLDMLRevision......\n");fflush(stdout);
		}
	}

	return error_code;
}

int std_pr_stamp_bypass ( EPM_action_message_t msg )
{

	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *itemid 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	char*			value					=NULL;

	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	int              st_count1 = 0;
	int              cnt = 0;
	int              DMLFlag = 0;
	int              PartFlag = 0;

	tag_t*    status_list1=NULLTAG;

	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char *Part_Coated = NULL;
	char *Part_ColourInd = NULL;
	char *Part_Type = NULL;
	char **DesignGroupList;
	char *WSO_Name = NULL;
	//API change
	//char   type_name[TCTYPE_name_size_c+1];
	char *type_name = NULL;
	

	
	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside std_pr_stamp_bypass***************\n ");fflush(stdout);

	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}


	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n std_pr_stamp_bypass \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n 1 CurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n 1 Parent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf(" 1 Target Attachment:%d\n",noAttachment);fflush(stdout);

	 if(noAttachment > 0)
	{
		DMLTag = attachments[0];
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n   1  type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	ITKCALL(AOM_ask_value_string( DMLTag, "item_id", &itemid));
	printf("\n 1 itemid:%s\n",itemid);fflush(stdout);

	char LcsStdWrkg[40];
	char LcsStdRlzd[40];

	GetPlantWiseRelStat(itemid,LcsStdWrkg,LcsStdRlzd);
	printf("\n 1 LcsStdWrkg: %s \n",LcsStdWrkg);fflush(stdout);
	printf("\n 1 LcsStdRlzd: %s \n",LcsStdRlzd);fflush(stdout);

	strcpy(lcsToset,LcsStdRlzd);


	if(strcmp(type_name,"T5_APLTaskRevision")==0)
	{
		    printf("\n inside class T5_APLTaskRevision......\n");fflush(stdout);
			ITKCALL(AOM_ask_value_string( DMLTag, "item_id", &item_id));
			ITKCALL(AOM_ask_value_string( DMLTag, "current_id", &DML_no));

			ITKCALL(WSOM_ask_release_status_list(DMLTag,&st_count1,&status_list1));
			printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

			if(st_count1>0)
			{
				for (cnt=0;cnt< st_count1;cnt++ )
				{
					WSO_Name=NULL;
					ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
					printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
					if(tc_strcmp(WSO_Name,"")!=0)
						{
							if (tc_strcmp(WSO_Name,LcsStdRlzd)==0)
							{
								DMLFlag = 1;
							}
						}
				}
			}

			if(DMLFlag == 0)
			{
				//API change
				CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
				CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
				printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
				CALLAPI(RELSTAT_add_release_status(status2,1,&DMLTag,retain));
			}

			if (DMLTag != NULLTAG)
			{

				tag_t                            TaskClosureDtAttrId=NULLTAG; 
				date_t                           Task_Release_date =NULLDATE;

				printf("\n ******************* Inside setting blannk date..");fflush(stdout);
				CALLAPI(AOM_lock(DMLTag));
				CALLAPI(POM_attr_id_of_attr("date_released","T5_APLTaskRevision",&TaskClosureDtAttrId));
				CALLAPI(AOM_refresh(DMLTag,TRUE));
				CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
				CALLAPI(POM_set_attr_date(1,&DMLTag,TaskClosureDtAttrId,Task_Release_date));
				CALLAPI(AOM_save_with_extensions(DMLTag));
				CALLAPI(AOM_unlock(DMLTag));
				//CALLAPI(AOM_refresh(DMLTag,TRUE));
				CALLAPI(AOM_refresh(DMLTag,FALSE)); // Ketan Modified

			}

	}

	return error_code;

}

int pr_task_stamping( EPM_action_message_t msg )
{
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;

	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
	char* WTlcsToset=NULL;//WT changes
    char* lcsToset=NULL;
    char* lcstoremove=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;
     logical stat  ;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *itemid 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";
	char*			value					=NULL;
	char*			b2changetType					=NULL;	//Deepti Added TZ1.53


	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	tag_t			tsk_dml_rel_type    = NULLTAG;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;

	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
	int				jj					= 0;
	int				countDml			= 0;
	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t			Fndrelation			= NULLTAG;
	tag_t			DMLRevTag			= NULLTAG;
	tag_t			class_id1			= NULLTAG;

	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;

	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char **DesignGroupList;
	char *class_name1= NULL;
	//API Change
	//char   type_name[TCTYPE_name_size_c+1];
	char   *type_name = NULL;
	char*	 DMLtype		= NULL;

	char	*parttype=NULL;
	tag_t			DerivedsvrRelationTAG= NULLTAG;
	int				countSVR				= 0;
	tag_t*			TaskSVRRevision		= NULLTAG;
		tag_t			TaskSVRRevisionTag		= NULLTAG;

	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;
	date_t Release_date;
	
	WTlcsToset =(char *) MEM_alloc(20 * sizeof(char *));//WT Changes
	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
	lcstoremove =(char *) MEM_alloc(20 * sizeof(char *));

	int		prtreleaseStatusFnd		=	0;
	int		prt_st_count			=	0;
	tag_t	*prt_status_list		=	NULLTAG;
	int		dmlLCS					=	0;
	char	*dml_releasest_name		=	NULL;

    printf("\n **************inside pr_task_stamping***************\n ");fflush(stdout);

   	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}


	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n pr_task_stamping \n"); fflush(stdout);

	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	if(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	if(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	 if(noAttachment > 0)
	{
		TaskRevTag = attachments[0];
		if(TCTYPE_ask_object_type(TaskRevTag,&objTypeTag));
    	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	AOM_ask_value_string( TaskRevTag, "item_id", &itemid);
	char LcsStdWrkg[40];
	char LcsStdRlzd[40];
	char epaPlant[40];

	GetPlantWiseRelStat(itemid,LcsStdWrkg,LcsStdRlzd);
	printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
	printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);

	strcpy(WTlcsToset,"Obsolete");//WT changes
	strcpy(lcsToset,LcsStdRlzd);
	strcpy(lcstoremove,LcsStdWrkg);


	GetEPAPlantCode(itemid,epaPlant);
	printf("\n epaPlant: %s \n",epaPlant);fflush(stdout);
		
	// Control Object for Calling EXE // Added By Ketan TZ 1.75

	char*	qry_entryCntrl_PR[3]	= {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char*	qry_valuesCntrl_PR[3]	= {"PR","Stamping","0"};
	
    tag_t	qryTagCntrl_PR				= NULLTAG;
    tag_t*	list_of_WSO_cntrl_tags_PR	= NULLTAG;

	int n_entryCntrl_PR			= 3;
	int control_number_found_PR = 0;;

	CALLAPI(QRY_find2("Control Objects...", &qryTagCntrl_PR));

	if (qryTagCntrl_PR)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPI(QRY_execute(qryTagCntrl_PR, n_entryCntrl_PR, qry_entryCntrl_PR, qry_valuesCntrl_PR, &control_number_found_PR, &list_of_WSO_cntrl_tags_PR));

		printf("\n control_number_found_PR is : %d\n",control_number_found_PR);fflush(stdout);
	}

	if(control_number_found_PR>0)
	{
		printf("\n Control Object Based Execution for PR Stamping\n");fflush(stdout);

	    char* STD_Task_no = NULL;
		
		AOM_ask_value_string(TaskRevTag,"item_id",&STD_Task_no);

		printf("\n STD_Task_no => %s \n",STD_Task_no);fflush(stdout);

		char* t5_Userinfo1_PR = NULL;
		char cmd_PR[100];

		tag_t PR_obj = list_of_WSO_cntrl_tags_PR[0];
		CALLAPI(AOM_ask_value_string(PR_obj,"t5_Userinfo1",&t5_Userinfo1_PR));	
		sprintf(cmd_PR,"%s %s",t5_Userinfo1_PR,STD_Task_no);
		printf("\n Ketan Excuting Command = %s \n",cmd_PR);fflush(stdout);
		system(cmd_PR);
		printf("\n After executing Command \n");fflush(stdout);
	}
	else
	{
		printf("\n Non - Control Object Based Execution for PR/Indivisual Stamping \n");fflush(stdout);

		if(strcmp(type_name,"T5_APLTaskRevision")==0)
		{
		    printf("\n inside class T5_APLTaskRevision......\n");fflush(stdout);
			AOM_ask_value_string( TaskRevTag, "item_id", &item_id);
			AOM_ask_value_string( TaskRevTag, "current_id", &DML_no);
			AOM_ask_value_strings(TaskRevTag,"t5_crdesigngroup",&num,&DesignGroupList);
			AOM_ask_value_string( TaskRevTag, "t5_cprojectcode", &Proj_Code);
			ITKCALL(AOM_ask_value_string( TaskRevTag, "t5_b2changetype", &b2changetType));	//Deepti Added TZ1.53

			printf("\n Proj_Code : %s\n",Proj_Code);fflush(stdout);
			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n DML_no : %s\n",DML_no);fflush(stdout);
			printf("\n num is : %d\n",num);fflush(stdout);
			printf("\n b2changetType is : %s\n",b2changetType);fflush(stdout);

			//Added by Priti TZ 1.43 //DO not stamp Part if DML of AMDML type or change type is NONERC

			
				ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
				if (tsk_dml_rel_type!=NULLTAG)
				{
					ITKCALL(GRM_list_primary_objects_only(TaskRevTag,tsk_dml_rel_type,&countDml,&DMLRevision));
					printf("\n\t\t APL DML Revision from Task : %d",countDml); fflush(stdout);
				}


				for (jj=0;jj<countDml;jj++ )
				{
					DMLRevTag = DMLRevision[j];

					ITKCALL(POM_class_of_instance(DMLRevTag,&class_id1));
					ITKCALL(POM_name_of_class(class_id1,&class_name1));
					printf("\n\t class_name found1 :%s",class_name1); fflush(stdout);

					if(tc_strcmp(class_name1,"T5_APLDMLRevision")==0)
					{
						ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_EcnType",&DMLtype));
						//printf("\n\t APLDMLtype is :%s",DMLtype); fflush(stdout);
						//break;
					}

				}
				//******************************************Added by Priti ENDS****************************//
        	                      
						   //CALLAPI(AOM_set_value_string(TaskRevTag,"CMClosureDate",cCurrentAccessDate));

						// CALLAPI(AOM_lock(TaskRevTag));
						// CALLAPI(AOM_set_value_date	(TaskRevTag,"date_released",Release_date));
						// CALLAPI(AOM_save_with_extensions(TaskRevTag));
						// CALLAPI(AOM_unlock(TaskRevTag));
						
						if(tc_strcmp(DMLtype,"AMDML")!=0)// Added by Anita
						{
							printf("\n\t APLDMLtype is :%s",DMLtype); fflush(stdout);//// Added by Anita
						
								//Part Stamping
		    					PartCnt=0;
								CALLAPI(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
								printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
								if (PartCnt>0)
								{
									GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
									for (k=0;k<PartCnt ;k++ )
									{
										printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
										AssyTag=PartTags[k];

										CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
										printf("\n\n\t\t APL DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);

										if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
										if(TCTYPE_ask_name2(objTypeTag,&type_name1));
										printf("\n\n\t\t APL DML Cre:AssyTag type_name1 := %s", type_name1);fflush(stdout);

										CALLAPI(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
										printf("\n\n\t\t APL DML Cre:AssyTag PartTypeStr := %s", PartTypeStr);fflush(stdout);

										//if (tc_strcmp(type_name1,"Design Revision")==0 || tc_strcmp(type_name1,"Part Revision")==0 || tc_strcmp(type_name1,"Colour Part Revision")==0 )//Colour part type added Hemal //Deepti TZ3.52
										//{
											//Added By Dhanashri for skip prev rev UATZ1.42//
											 char*			SkipPrevRevSTD				= NULL;
											 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
											 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
											 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
												
												//if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
												if(tc_strlen(SkipPrevRevSTD)>0)
												{
													printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
													continue;
												}
											//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//
											//Check LCS if released not to go for stamping
											//Hemal Start
											prtreleaseStatusFnd=0;
		
											ITKCALL(WSOM_ask_release_status_list(AssyTag,&prt_st_count,&prt_status_list));
											for (dmlLCS=0;dmlLCS<prt_st_count ;dmlLCS++ )
											{
												ITKCALL(AOM_ask_value_string(prt_status_list[dmlLCS],"object_name",&dml_releasest_name));
												printf("\n dml_releasest_name: %s\n",dml_releasest_name);fflush(stdout);
												if(tc_strcmp(dml_releasest_name,lcsToset)==0)
												{
													prtreleaseStatusFnd++;
												}
											}

											printf("\n\n\t\t prtreleaseStatusFnd := %d", prtreleaseStatusFnd);fflush(stdout);
												
											/*****Added by Shubham*****/

											CALLAPI(AOM_ask_value_string(AssyTag,"t5_PartType",&parttype));
											printf("\n\n\t\t APL DML Cre:parttype  is :%s",parttype);	fflush(stdout);
											
											if (tc_strcmp(parttype,"CCVC")==0)
											{
											GRM_find_relation_type("T5_DerivedFromSVR",&DerivedsvrRelationTAG);	
											GRM_list_secondary_objects_only(AssyTag,DerivedsvrRelationTAG,&countSVR,&TaskSVRRevision);
											printf("\n\t APL DML Task SVR Count : %d",countSVR);fflush(stdout);

											TaskSVRRevisionTag=TaskSVRRevision[0];
											status = t5UpdateLifecycleStateSTD(TaskSVRRevisionTag,lcsToset,"NA");
											}

										/*****End by Shubham*****/
											
											printf("\n\n\t\t DMLtype := %s", DMLtype);fflush(stdout);
											if (prtreleaseStatusFnd==0)
											{
												if( (tc_strcmp(DMLtype,"AMDML")!=0) || (!strstr(item_id,"NONERC")) ) //Added in TZ1.43
												{
													//if(tc_strcmp(DMLtype,"WT")!=0)//WT Changes
													if(tc_strcmp(DMLtype,"WT")==0)//Deepti Added TZ1.53
													{
														printf("\n\n\t\t in function pr_task_stamping attached to WT DML parts  WTlcsToset := %s", WTlcsToset);fflush(stdout);
														status = t5UpdateLifecycleStateSTD(AssyTag, WTlcsToset,lcstoremove);
													}
													else
													{
														//status = t5UpdateLifecycleStateSTD(AssyTag, lcsToset,lcstoremove);
														status = t5UpdateLifecycleStateSTD_DMLTask(AssyTag, lcsToset,lcstoremove,epaPlant);
													}														
													
												}
											}
											//Hemal Ends
										//}
									}
								}
								
						}//Added by Anita
						
						//Task Stamping

						getCurrentDateTime(cCurrentAccessDate);
						printf("\n cCurrentAccessDate:%s",cCurrentAccessDate);
						CALLAPI(ITK_string_to_date(cCurrentAccessDate, &Release_date ));

						 //CALLAPI(ITK_set_bypass(TRUE));
							tag_t  DtRlzd = NULLTAG;
							tag_t  Closure = NULLTAG;
							tag_t  Maturity = NULLTAG;
							tag_t  Disposition = NULLTAG;
							
						   CALLAPI(AOM_lock(TaskRevTag));
						   CALLAPI(POM_attr_id_of_attr("date_released","T5_APLTaskRevision",&DtRlzd));
						   CALLAPI(POM_attr_id_of_attr("CMClosure","T5_APLTaskRevision",&Closure));
						   CALLAPI(POM_attr_id_of_attr("CMMaturity","T5_APLTaskRevision",&Maturity));
						   CALLAPI(POM_attr_id_of_attr("CMDisposition","T5_APLTaskRevision",&Disposition));

						   if(AOM_refresh(TaskRevTag,TRUE));
						   if(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
						   if(POM_set_attr_date(1,&TaskRevTag,DtRlzd,Release_date));
						   if(POM_set_attr_string(1,&TaskRevTag,Closure,"Closed"));
						   if(POM_set_attr_string(1,&TaskRevTag,Maturity,"Complete"));
						   if(POM_set_attr_string(1,&TaskRevTag,Disposition,"Approved"));

						   //CALLAPI(AOM_set_value_string(TaskRevTag,"CMClosure","Closed"));
						   //CALLAPI(AOM_set_value_string(TaskRevTag,"CMMaturity","Complete"));
						   //CALLAPI(AOM_set_value_string(TaskRevTag,"CMDisposition","Approved"));

						   if(AOM_save_with_extensions(TaskRevTag));
						   //if(AOM_refresh(TaskRevTag,TRUE));
						   if(AOM_refresh(TaskRevTag,FALSE)); // Ketan Modified
						   // CALLAPI(AOM_save_with_extensions(TaskRevTag));
						   // CALLAPI(AOM_unlock(TaskRevTag));

						   printf("\n date set to ...cCurrentAccessDate:%s",cCurrentAccessDate);
							
							//Hemal Start
						   prtreleaseStatusFnd=0;
		
							ITKCALL(WSOM_ask_release_status_list(TaskRevTag,&prt_st_count,&prt_status_list));
							for (dmlLCS=0;dmlLCS<prt_st_count ;dmlLCS++ )
							{
								ITKCALL(AOM_ask_value_string(prt_status_list[dmlLCS],"object_name",&dml_releasest_name));
								printf("\n dml_releasest_name: %s\n",dml_releasest_name);fflush(stdout);
								if(tc_strcmp(dml_releasest_name,lcsToset)==0)
								{
									prtreleaseStatusFnd++;
								}
							}

							printf("\n\n\t\t prtreleaseStatusFnd := %d", prtreleaseStatusFnd);fflush(stdout);

							if(prtreleaseStatusFnd==0)
							{
							   status = t5UpdateLifecycleStateSTD(TaskRevTag, lcsToset,lcstoremove);				   

							}

							
							//Hemal Ends
						   
		}
		else
		{
			printf("\n No proper class class T5_APLDMLRevision......\n");fflush(stdout);
		}
	}

	return error_code;
}

int AMDML_Bypass_Checks(tag_t Task_Tag)
{
	int			count				= 0;
	int			j					= 0;

	char		*DmlName			= NULL;
	char		*DmlEcn				= NULL;
	char		*TaskName			= NULL;

	tag_t		tsk_dml_rel_type	= NULLTAG;
	tag_t		DMLRevTag			= NULLTAG;

	tag_t*		DMLRevision			= NULLTAG;

	logical		is_latest;	

	printf("\n Inside AMDML_Bypass_Checks");fflush(stdout);

	ITKCALL(AOM_ask_value_string(Task_Tag, "item_id",&TaskName));
	printf("\n TaskName %s.....\n",TaskName);

	if(tc_strstr(TaskName,"AM"))
	{
		ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
		if (tsk_dml_rel_type!=NULLTAG)
		 {

			ITKCALL(GRM_list_primary_objects_only(Task_Tag,tsk_dml_rel_type,&count,&DMLRevision));
			printf("\n\n\t\t DML Revision from Task : %d",count);fflush(stdout);		//task to dml

			for (j=0;j<count ;j++ )
			{
				ITKCALL(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
				printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);

				if(is_latest != true)
				{
					printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
				}else
				{
					DMLRevTag = DMLRevision[j];//DML

					ITKCALL(AOM_ask_value_string(DMLRevTag, "item_id",&DmlName));
					printf("\n DmlName %s.....\n",DmlName);

					ITKCALL(AOM_ask_value_string(DMLRevTag, "t5_EcnType",&DmlEcn));
					printf("\n DmlEcn %s.....\n",DmlEcn);

					if(tc_strcmp(DmlEcn,"AMDML")==0)
					{
						printf("\n Bypass Validations as AMDML of type AM");fflush(stdout);
						return 1;
					}
					else
					{
						printf("\n Call all Validations as AMDML is not of type AM");fflush(stdout);
						return 0;
					}
				}
			}
		 }
	}
	else
	{
		printf("\n Given task is not of AMDML");fflush(stdout);
		return 0;
	}
        		
	           

	return 0;

}

//CCV Checks starts
//Multiple module solve check at STDSI
//tm_chkMultipleSolveBOM_STD input as Task and find the SVR attached with Task applied it on platform
//if morethan one module has been solved, in that case error should be prompted
int tm_chkMultipleSolveBOM_STD(tag_t t_tasktag,char	***SetChildRelErr,int *icount)
{
	int		status;
	int		pltcnt					=	0;
	int		iplt					=	0;
	int		ipltf					=	0;
	int		ivar					=	0;
	int		n_bom_views				=	0;
	int		rulefound				=	0;
	int		n_count					=	0;
	int		count					=	0;
	int		ichld					=	0;
	int		n_lines2				=	0;
	int		iChildItemTag			=	0;
	int		dmlcount				=	0;
	int		idml					=	0;
	int		st_count				=	0;
	int		iaplrlz					=	0;
	int		ist						=	0;

	char	*roleName				=	NULL;
	char	*objecttype				=	NULL;
	char	*objectname				=	NULL;
	char	*Archtype_name			=	NULL;
	char	*arch_item_id			=	NULL;
	char	*ModPartNo				=	NULL;
	char	*item_Rev_Seq			=	NULL;
	char	*item_Rev_DRStatus		=	NULL;
	char	*class_name1			=	NULL;
	char	*apl_dr_status			=	NULL;
	char	*itemid					=	NULL;
	char	*cGroupname				=	NULL;
	char	*ErrString				=	NULL;
	char	*release_name			=	NULL;
	char	*moduleNumber			=	NULL;
	char	**rulename				=	NULL;
	char	**rulevalue				=	NULL;
	
	char	PlantName[40];
	char 	LcsSTDWrkg[40];
	char 	LcsSTDRlzd[40];

	tag_t	CurrentRoleTag			=	NULLTAG;
	tag_t	t_TaskToRef				=	NULLTAG;
	tag_t	t_TaskToPart			=	NULLTAG;
	tag_t	t_CCVCHasSnapShot		=	NULLTAG;
	tag_t	t_platform				=	NULLTAG;
	tag_t	t_primary				=	NULLTAG;
	tag_t	t_variant				=	NULLTAG;
	tag_t	bom_view				=	NULLTAG;
	tag_t	item					=	NULLTAG;
	tag_t	bom_window				=	NULLTAG;
	tag_t	rule					=	NULLTAG;
	tag_t	close_tag				=	NULLTAG;
	tag_t	top_lne					=	NULLTAG;
	//API change
	tag_t   *bom_variant_rule = NULLTAG;
	//API change
	int p_count;
	//tag_t   bom_variant_rule		=	NULLTAG;
	tag_t  	objTypeTag1				=	NULLTAG;
	tag_t	Childobject				=	NULLTAG;
	tag_t	t_ChildItemRev			=	NULLTAG;
	tag_t	t_DMLTaskRel			=	NULLTAG;
	tag_t	PartChildobj			=	NULLTAG;
	tag_t	DMLRevTag				=	NULLTAG;
	tag_t	class_id1				=	NULLTAG;

	tag_t	*pltList				=	NULLTAG;
	tag_t	*bom_views				=	NULLTAG;
	tag_t	*closurerule			=	NULLTAG;
	tag_t	*ArchNodeLines			=	NULLTAG;
	tag_t	*ColIndChilds			=	NULLTAG;
	tag_t	*lines2					=	NULLTAG;
	tag_t	*DMLRevision			=	NULLTAG;
	tag_t	*status_list			=	NULLTAG;
	

	printf("\nInside tm_chkMultipleSolveBOM_STD");fflush(stdout);

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

	char    *qry_entryCntrl1[3]  	= 	{"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1		= 	(char **) MEM_alloc(5 * sizeof(char *));
	tag_t	qryTagCntrl1			=	NULLTAG;
	int     n_entryCntrl1    		= 	3;
	int		control_number_found	=	0;
	tag_t	*list_of_WSO_cntrl_tags	=	NULLTAG;

	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	
	if(qryTagCntrl1!=NULLTAG)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="STDCCVRlzDuplicate";
		qry_valuesCntrl1[1]="STDCCVRlzDuplicate";;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found, &list_of_WSO_cntrl_tags));
		printf("\nNo. of control object found : %d",control_number_found);fflush(stdout);
		//if(control_number_found>0)
		{
			ITKCALL(GRM_find_relation_type("CMReferences",&t_TaskToRef));//Reference Items
			ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&t_TaskToPart));//Solution Item
			ITKCALL(GRM_find_relation_type("T5_PartHasSnapShot",&t_CCVCHasSnapShot));//Part Has Snap Shot
			ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&t_DMLTaskRel));//Part Has Snap Shot
			
			ITKCALL(AOM_ask_value_string(t_tasktag,"item_id",&itemid));
			printf("\t  itemid ...%s\n", itemid);fflush(stdout);
				
			tm_GetGroupFromDML(itemid, &cGroupname);
			printf("\ngroup Name :%s",cGroupname);fflush(stdout);
			GetPlantForDMLORTask( itemid ,PlantName);
			printf("\nPlantName :%s",PlantName);fflush(stdout);
			
			GetPlantWiseRelStat(itemid,LcsSTDWrkg,LcsSTDRlzd);
			printf("\n LcsSTDWrkg: %s \n",LcsSTDWrkg);
			printf("\n LcsSTDRlzd: %s \n",LcsSTDRlzd);
			
			char ERCClosureRule[40];
			//API change
			//char STDClosureRule[40];
			char *STDClosureRule = NULL;
			STDClosureRule = (char *)MEM_alloc(1 * sizeof(char *));
			char RevisionRule[40];
			char BVR[40];
			getPlantWiseRRCCDriverVC(roleName,RevisionRule,STDClosureRule,ERCClosureRule,BVR);
			printf("\nSTDSI Closure rule : %s, Revision Rule : %s ",STDClosureRule,RevisionRule);fflush(stdout);
			
			// char	RevRuleInfo1[40];
			// char	BVRInfo2[40];
			// char	currviewmask[40];
			// get_CtrlVal_APLLcsInf(cGroupname,RevRuleInfo1,BVRInfo2,currviewmask);
			//printf("\nRevision Rule : %s , BVR : %s , View Mask : %s \n",RevRuleInfo1,BVRInfo2,currviewmask);fflush(stdout);
										
			//Get DML from Task
			if (t_DMLTaskRel!=NULLTAG)
			{
				ITKCALL(GRM_list_primary_objects_only(t_tasktag,t_DMLTaskRel,&dmlcount,&DMLRevision));//Get DML from task
				printf("\n\t\t APL DML Revision from Task : %d",dmlcount); fflush(stdout);
				for (idml=0;idml<dmlcount ;idml++ )
				{
					DMLRevTag = DMLRevision[idml];					
					ITKCALL(POM_class_of_instance(DMLRevTag,&class_id1));
					ITKCALL(POM_name_of_class(class_id1,&class_name1));
					printf("\n\t class_name found1 :%s",class_name1); fflush(stdout);

					if(tc_strcmp(class_name1,"T5_APLDMLRevision")==0)
					{
						ITKCALL(AOM_ask_value_string( DMLRevTag, "t5_cDRstatus", &apl_dr_status));
						printf("\n erc_dmlrelztype: %s\n",apl_dr_status);fflush(stdout);
					}
				}
			}
			if (t_TaskToRef!=NULLTAG)
			{
				printf("\nFetch SVR from task");fflush(stdout);

				ITKCALL(GRM_list_secondary_objects_only(t_tasktag,t_TaskToRef,&pltcnt,&pltList));
				printf("\nNumber of SVRS found in Reference Item : %d",pltcnt);fflush(stdout);
				if (pltcnt>0)
				{
					for(iplt=0;iplt<pltcnt;iplt++)
					{
						printf("\nFind Platform");fflush(stdout);
						t_platform	=	pltList[iplt];
						if(AOM_ask_value_string(t_platform,"object_type",&objecttype));
						if(AOM_ask_value_string(t_platform,"object_name",&objectname));
						printf("\nObject name : %s and type : %s",objectname,objecttype);fflush(stdout);
						if(tc_strcmp(objecttype,"T5_PlatformRevision")==0)
						{
							printf("\nPlatform found...");fflush(stdout);
							t_primary	=	t_platform;
							//t_primary	=	pltList[iplt];
							break;
						}
					}
					for(ivar=0;ivar<pltcnt;ivar++)
					{
						printf("\nFind attached variant rule");fflush(stdout);
						t_variant	=	pltList[ivar];

						if(AOM_ask_value_string(t_variant,"object_type",&objecttype));
						if(AOM_ask_value_string(t_variant,"object_name",&objectname));
						printf("\nObject name : %s and type : %s",objectname,objecttype);fflush(stdout);
						if(tc_strcmp(objecttype,"VariantRule")==0)
						{
							printf("\ninside VariantRule found");fflush(stdout);
							//if (ipltf==0)
							{
								//ipltf++;
								printf("\nVariant Rule found in relation"); fflush(stdout);
								if(t_variant!=NULLTAG)
								{
									if (t_primary!=NULLTAG)
									{
										printf("\nt_primary is not nulltag");fflush(stdout);
									}
									if ( ITEM_ask_item_of_rev( t_primary, &item ));
									if ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));
									printf("\nView found check.......%d\n",n_bom_views); fflush(stdout);
									bom_view = bom_views[0];

									if (bom_view!=NULLTAG)
									{
										if (BOM_create_window( &bom_window ));
										//ITKCALL(CFM_find("APLC release and above", &rule));
										ITKCALL(CFM_find(RevisionRule, &rule));
										printf("\nView found check.......%d\n",n_bom_views); fflush(stdout);
										ITKCALL(BOM_set_window_config_rule(bom_window, rule));
										//ITKCALL(PIE_find_closure_rules("BOMLineskipforunconfiguredAPLC",PIE_TEAMCENTER, &rulefound, &closurerule ));
										//API Change
										ITKCALL(PIE_find_closure_rules2(STDClosureRule,PIE_TEAMCENTER, &rulefound, &closurerule ));

										printf ("\nrule count %d \n",rulefound);fflush(stdout);
										if (rulefound > 0)
										{
											close_tag = closurerule[0];
											printf ("closure rule found \n"); fflush(stdout);
										}

										ITKCALL(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));
										ITKCALL(BOM_set_window_pack_all(bom_window, FALSE));
										ITKCALL(BOM_set_window_top_line( bom_window, NULLTAG, t_primary, NULLTAG, &top_lne ));
										//API change
										//ITKCALL(BOM_window_ask_variant_rule( bom_window, &bom_variant_rule ));
										ITKCALL(BOM_window_ask_variant_rules( bom_window,&p_count, &bom_variant_rule ));

										//ITKCALL(TCTYPE_ask_object_type(bom_variant_rule,&objTypeTag1));
										ITKCALL(TCTYPE_ask_object_type(bom_variant_rule[0],&objTypeTag1));
										ITKCALL(TCTYPE_ask_name2(objTypeTag1,&Archtype_name));
										printf("\n Archtype_name------> %s\n",Archtype_name);fflush(stdout);

										if(top_lne!=NULLTAG)
										{
											ITKCALL(BOM_line_ask_child_lines(top_lne, &n_count, &ArchNodeLines));
											printf("\n n_count --------> : %d\n", n_count);

											ITKCALL(BOM_window_hide_unconfigured(bom_window));
											ITKCALL(BOM_window_show_variants(bom_window));
											ITKCALL(BOM_window_apply_variant_configuration(bom_window,1,&t_variant));
											ITKCALL(BOM_window_hide_variants(bom_window));
											ITKCALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
											printf("\n count --------> : %d\n", count); fflush(stdout);//Find Architecture Node
											if (count >0)
											{	
												for (ichld=0;ichld<count ;ichld++ )
												{
													if(Childobject) Childobject=NULLTAG;
													Childobject=ColIndChilds[ichld];

													ITKCALL(AOM_ask_value_string(Childobject, "bl_item_item_id", &arch_item_id ));
													printf("\n arch_item_id ..:%s\n",arch_item_id); fflush(stdout);
													//if (tc_strcmp(apl_dr_status,item_Rev_DRStatus)==0)
													//Check for BIW module and bolted module
													if(lines2) lines2=NULL;
													ITKCALL(BOM_line_ask_child_lines(Childobject, &n_lines2, &lines2));
													printf("\n Child parts count--> %d\n",n_lines2);fflush(stdout);
													if (n_lines2==1)
													{
														if(PartChildobj) PartChildobj=NULLTAG;
														if(ModPartNo) ModPartNo=NULL;
														if(item_Rev_Seq) item_Rev_Seq=NULL;
														PartChildobj=lines2[0];

														ITKCALL(AOM_ask_value_string(PartChildobj, "bl_item_item_id", &ModPartNo ));
														printf("\n No of Modules Under Architechtures --> : %s\n",ModPartNo); fflush(stdout);
															
														ITKCALL(AOM_ask_value_string(PartChildobj, "bl_rev_item_revision_id", &item_Rev_Seq));
														printf("\n item_Rev_Seq --> : %s\n",item_Rev_Seq); fflush(stdout);

														//fprintf(fp,"%s,%s,%s,%s\n",objectname,arch_item_id,ModPartNo,item_Rev_DRStatus);fflush(fp);
													}
													else if(n_lines2>1)
													{
														int imulti	=	0;
														int imod	=	0;
														char	*tmpPartNum	=	NULL;
														
														for (imod=0;imod<n_lines2;imod++)
														{
															moduleNumber	=	NULL;
															ITKCALL(AOM_ask_value_string(lines2[imod],"bl_item_item_id",&moduleNumber));
															printf("\t  moduleNumber ...%s\n", moduleNumber);fflush(stdout);
															
															if (imod==0)
															{
																tmpPartNum	=	NULL;
																tmpPartNum	=	(char*)MEM_alloc(tc_strlen(moduleNumber)+2);
																tc_strcpy(tmpPartNum,moduleNumber);
																printf("\nTemp Module Number : %s",tmpPartNum);fflush(stdout);
															}
															else
															{
																if(tc_strcmp(tmpPartNum,moduleNumber)!=0)
																{
																	imulti++;
																}
																else
																{
																	printf("\nP	art Number are same %s",moduleNumber);fflush(stdout);
																}
															}
														}
														if(imulti>0)
														{
															printf("\nMore than one Module solve");fflush(stdout);
															ErrString	=	NULL;
															ErrString	=	(char	*)MEM_alloc(300);
															tc_strcpy(ErrString,"More than one module solved in Architecture Node ");
															tc_strcat(ErrString,arch_item_id);
															tc_strcat(ErrString," After SVR ");
															tc_strcat(ErrString,objectname);
															tc_strcat(ErrString," applied on platform.\n");
															setAddStrFuction(icount,SetChildRelErr,ErrString);
														}
													}
													else
													{
														printf("\nNo child found in arch node : %s",arch_item_id);
														//fprintf(fp,"%s,%s,0\n",objectname,arch_item_id);fflush(stdout);
													}
												}																						
											}
										}
									}
								}
							}
						}
					}
				}
				else
				{
					printf("\nNo SVR attached with Task");fflush(stdout);
				}
			}
		}
	}

	return status;
}

//CCV check for Module STDSI Released
//Shubham

int tm_Is_Any_Child_STDRlz(tag_t	t_child,char	*cAPLRlzd, char	*cDRStat, int	*iRlCnt, int *iDRCnt)
{
	int		status;
	int		st_count		=	0;
	int		ist				=	0;

	char	*cPartNumber	=	NULL;
	char	*cRevision		=	NULL;
	char	*cRlzStat		=	NULL;
	char	*cDRStatus		=	NULL;

	char	*RevOnly		=	NULL;
	char	*Part_Rev		=	NULL;
	char	*TaskClosureDt	=	NULL;

	tag_t	*status_list	=	NULLTAG;
	tag_t	t_prev_rev		=	NULLTAG;

	printf("\nInside tm_Is_Any_Child_STDRlz");fflush(stdout);
	
	ITKCALL(AOM_ask_value_string(t_child, "item_id", &cPartNumber ));
															
	ITKCALL(AOM_ask_value_string(t_child, "item_revision_id", &cRevision));
	ITKCALL(AOM_ask_value_string(t_child,"item_revision_id",&Part_Rev));

	//ITKCALL(AOM_ask_value_string(t_child, "t5_PartStatus", &cDRStatus));
	
	RevOnly= strtok( Part_Rev, ";" );
	printf("\nCCV STD Rev Only : %s",RevOnly);fflush(stdout);
	printf("\nCCV STDPart Number : %s, Revision  : %s",cPartNumber,cRevision,cDRStatus);fflush(stdout);
	

			int n_tags_found  = 0;
			const char *attrs[1];
			attrs[0] ="item_id";
			const char *values[1];
			values[0] = (char *)cPartNumber;
		//	tag_t	*itemTAG			=	NULLTAG;
			tag_t	itemTAG			=	NULLTAG;
			int count1  = 0;
			int cnt1  = 0;
			tag_t *  rev_list= NULLTAG;
			//API change
			char *rev_id1 = NULL;
			char	*cPartStsus	=	NULL;

           // ITEM_find_items_by_key_attributes(1, attrs, values,&n_tags_found, &itemTAG);
		   ITEM_ask_item_of_rev(t_child,&itemTAG);
			printf("\n*********TAG & PART TAG Found for Validation***********************");

			ITEM_list_all_revs  (itemTAG, &count1,  &rev_list ); 
			printf("\nRev count1:- %d\n\n",count1);

			for (cnt1 = 0; cnt1 < count1; cnt1++)
			{
			ITEM_ask_rev_id2( rev_list[cnt1], &rev_id1);
			printf("\n rev_id are  ---->%s\n", rev_id1);fflush(stdout);

			ITKCALL(AOM_ask_value_string(rev_list[cnt1], "t5_PartStatus", &cPartStsus ));
			printf("\n t5_PartStatus :%s is\n",cPartStsus);fflush(stdout);


//				ITKCALL(WSOM_ask_release_status_list(t_child,&st_count,&status_list));
			ITKCALL(WSOM_ask_release_status_list(rev_list[cnt1],&st_count,&status_list));
			printf("\nCCV STD st_count :%d is\n",st_count);fflush(stdout);
			
			for(ist=0;ist<st_count;ist++)
			{
			cRlzStat	=	NULL;
			ITKCALL(AOM_ask_name(status_list[ist],&cRlzStat));
			printf("\nCCV STD cRlzStat is :%s, %s\n",cRlzStat,cAPLRlzd);fflush(stdout);

			ITKCALL(AOM_UIF_ask_value(status_list[ist],"date_released",&TaskClosureDt));
			printf("\nCCV STD Task date_released (TaskTag): %s   \n",TaskClosureDt);fflush(stdout);

			if ((tc_strcmp(cRlzStat,cAPLRlzd)==0) && (tc_strlen(TaskClosureDt)>0))
			{
			*iRlCnt	=	*iRlCnt+1;
			printf("\nCCV STD Part is found APL Released : %d",*iRlCnt);fflush(stdout);

				if((tc_strcmp(cDRStat,"DR5")==0 || tc_strcmp(cDRStat,"AR5")==0) && (tc_strcmp(cDRStatus,"DR5")==0 || tc_strcmp(cDRStatus,"AR5")==0))
				{
					*iDRCnt	=	*iDRCnt+1;
				}
				else if((tc_strcmp(cDRStat,"DR4")==0 || tc_strcmp(cDRStat,"AR4")==0) && (tc_strcmp(cDRStatus,"DR5")==0 || tc_strcmp(cDRStatus,"AR5")==0 || 
					tc_strcmp(cDRStatus,"DR4")==0 || tc_strcmp(cDRStatus,"AR4")==0))
				{
					*iDRCnt	=	*iDRCnt+1;
				}
				else if((tc_strcmp(cDRStat,"DR3P")==0 || tc_strcmp(cDRStat,"AR3P")==0) && 
					(tc_strcmp(cDRStatus,"DR5")==0 || tc_strcmp(cDRStatus,"AR5")==0 || tc_strcmp(cDRStatus,"DR4")==0 || 
					tc_strcmp(cDRStatus,"AR4")==0 || tc_strcmp(cDRStatus,"DR3P")==0 || tc_strcmp(cDRStatus,"AR3P")==0 ))
				{
					*iDRCnt	=	*iDRCnt+1;
				}
				else if((tc_strcmp(cDRStat,"DR3")==0 || tc_strcmp(cDRStat,"AR3")==0) && 
					(tc_strcmp(cDRStatus,"DR5")==0 || tc_strcmp(cDRStatus,"AR5")==0 || 
					tc_strcmp(cDRStatus,"DR4")==0 || tc_strcmp(cDRStatus,"AR4")==0 || 
					tc_strcmp(cDRStatus,"DR3P")==0 || tc_strcmp(cDRStatus,"AR3P")==0 || tc_strcmp(cDRStatus,"DR3")==0 || tc_strcmp(cDRStatus,"AR3")==0 ))
				{
					*iDRCnt	=	*iDRCnt+1;
				}
				else if((tc_strcmp(cDRStat,"DR2")==0 || tc_strcmp(cDRStat,"AR2")==0) && 
					(tc_strcmp(cDRStatus,"DR5")==0 || tc_strcmp(cDRStatus,"AR5")==0 || tc_strcmp(cDRStatus,"DR4")==0 || 
					tc_strcmp(cDRStatus,"AR4")==0 || tc_strcmp(cDRStatus,"DR3P")==0 || tc_strcmp(cDRStatus,"AR3P")==0 || 
					tc_strcmp(cDRStatus,"DR3")==0 || tc_strcmp(cDRStatus,"AR3")==0 || tc_strcmp(cDRStatus,"DR2")==0 || tc_strcmp(cDRStatus,"AR2")==0 ))
				{
					*iDRCnt	=	*iDRCnt+1;
				}
				else if((tc_strcmp(cDRStat,"DR1")==0 || tc_strcmp(cDRStat,"AR1")==0) && 
					(tc_strcmp(cDRStatus,"DR5")==0 || tc_strcmp(cDRStatus,"AR5")==0 || tc_strcmp(cDRStatus,"DR4")==0 || 
					tc_strcmp(cDRStatus,"AR4")==0 || tc_strcmp(cDRStatus,"DR3P")==0 || tc_strcmp(cDRStatus,"AR3P")==0 || 
					tc_strcmp(cDRStatus,"DR3")==0 || tc_strcmp(cDRStatus,"AR3")==0 || tc_strcmp(cDRStatus,"DR2")==0 || 
					tc_strcmp(cDRStatus,"AR2")==0 || tc_strcmp(cDRStatus,"DR1")==0 || tc_strcmp(cDRStatus,"AR1")==0 ))
				{
					*iDRCnt	=	*iDRCnt+1;
				}
				else if((tc_strcmp(cDRStat,"DR0")==0 || tc_strcmp(cDRStat,"AR0")==0) && 
					(tc_strcmp(cDRStatus,"DR5")==0 || tc_strcmp(cDRStatus,"AR5")==0 || tc_strcmp(cDRStatus,"DR4")==0 || 
					tc_strcmp(cDRStatus,"AR4")==0 || tc_strcmp(cDRStatus,"DR3P")==0 || tc_strcmp(cDRStatus,"AR3P")==0 || 
					tc_strcmp(cDRStatus,"DR3")==0 || tc_strcmp(cDRStatus,"AR3")==0 || tc_strcmp(cDRStatus,"DR2")==0 || 
					tc_strcmp(cDRStatus,"AR2")==0 || tc_strcmp(cDRStatus,"DR1")==0 || tc_strcmp(cDRStatus,"AR1")==0 || 
					tc_strcmp(cDRStatus,"DR0")==0 || tc_strcmp(cDRStatus,"AR0")==0))
				{
					*iDRCnt	=	*iDRCnt+1;
				}
			break;
			}
				}
	
	printf("\nCCV STD RevOnly : %s",RevOnly);fflush(stdout);
		printf("\n****************Code validated successfully*************");fflush(stdout);

	/*if(tc_strcmp(RevOnly,"NR")==0)
	{
		printf("\nCCV STD Part revision is NR, so retun");fflush(stdout);
		return status;
	}

	*/
	printf("\nCCV STD *iRlCnt : %d and *iDRCnt : %d",*iRlCnt,*iDRCnt);fflush(stdout);
	if (*iRlCnt > 0 && *iDRCnt > 0)
	{
		printf("\nCCV STD DR and Part LCS is validated successfully");fflush(stdout);
		return status;
	}
	else
	{
		printf("\nCCV STD Find the previous revision and check DR and LCS...");fflush(stdout);
		//check previous revision
		if (tc_strcmp(RevOnly,"NR")!=0)
		{
			tm_fnd_Prev_Official_Revision(cPartNumber,t_child, &t_prev_rev);
		}
		if (t_prev_rev!=NULLTAG)
		{
			 tm_Is_Any_Child_STDRlz(t_prev_rev,cAPLRlzd, cDRStat, iRlCnt, iDRCnt);
		}
		
	}
}
	return status;
}

int tm_Is_Any_Clr_STD_Child_Rlz(tag_t	t_child,char	*cAPLRlzd, int	*iRlCnt)
{
	int		st_count		=	0;
	int		ist				=	0;

	char	*cPartNumber	=	NULL;
	char	*cRevision		=	NULL;
	char	*cRevisionP		=	NULL;
	char	*cRlzStat		=	NULL;
	char	*cDRStatus		=	NULL;
	char	*RevOnly		=	NULL;
	char	*TaskClosureDt	=	NULL;

	tag_t	*status_list	=	NULLTAG;
	tag_t	t_prev_rev		=	NULLTAG;

	printf("\nInside tm_Is_Any_Clr_STD_Child_Rlz");fflush(stdout);
	
	ITKCALL(AOM_ask_value_string(t_child, "item_id", &cPartNumber ));
															
	ITKCALL(AOM_ask_value_string(t_child, "item_revision_id", &cRevision));
	ITKCALL(AOM_ask_value_string(t_child, "item_revision_id", &cRevisionP));

	ITKCALL(AOM_ask_value_string(t_child, "t5_PartStatus", &cDRStatus));

	printf("\nCLR STD CCV Part Number : %s, Revision : %s, DR Status : %s",cPartNumber,cRevision,cDRStatus);fflush(stdout);
	
	ITKCALL(WSOM_ask_release_status_list(t_child,&st_count,&status_list));
	printf("\nCLR STD CCV st_count :%d is\n",st_count);fflush(stdout);
	for(ist=0;ist<st_count;ist++)
	{
		cRlzStat	=	NULL;
		ITKCALL(AOM_ask_name(status_list[ist],&cRlzStat));
		printf("\nCLR STD CCV cRlzStat is :%s, %s\n",cRlzStat,cAPLRlzd);fflush(stdout);
		
		ITKCALL(AOM_UIF_ask_value(status_list[ist],"date_released",&TaskClosureDt));
		printf("\nCLR STD CCV Task`s date_released (TaskTag): %s   \n",TaskClosureDt);fflush(stdout);

		if ((tc_strcmp(cRlzStat,cAPLRlzd)==0) && (tc_strlen(TaskClosureDt)>0))
		{		
			*iRlCnt	=	*iRlCnt+1;
			printf("\nCLR STD CCV Part is found APL Released : %d",*iRlCnt);fflush(stdout);
			break;
		}
	}
	RevOnly	= strtok( cRevisionP, ";" );
	printf("\nCLAR STD CCCV RevOnly : %s ",RevOnly);fflush(stdout);
	if(tc_strcmp(RevOnly,"NR")==0)
	{
		printf("\nCLR STD CCV Part revision is NR, so retun");fflush(stdout);
		return 0;
	}
	printf("\n*iRlCnt : %d ",*iRlCnt);fflush(stdout);
	if (*iRlCnt > 0 )
	{
		printf("\nCLR STD CCV Part LCS is validated successfully");fflush(stdout);
		return 0;
	}
	else
	{
		printf("\nCLR STD CCV Find the previous revision and check DR and LCS...");fflush(stdout);
		//check previous revision
		if (tc_strcmp(RevOnly,"NR")!=0)
		{
			tm_fnd_Prev_Official_Revision(cPartNumber,t_child, &t_prev_rev);
		}
		
		if (t_prev_rev!=NULLTAG)
		{
			 tm_Is_Any_Clr_STD_Child_Rlz(t_prev_rev,cAPLRlzd, iRlCnt);
		}
		
	}

}

int tm_chk_CCVC_BOM_STDRLZ(tag_t t_tasktag,char	***SetChildRelErr,int *icount)
{
	int		status;
	int		dmlcount			=	0;
	int		idml				=	0;
	int		isvr				=	0;
	int		iapldmlcnt			=	0;
	int		refCnt				=	0;
	int		prtcnt				=	0;
	int		iprt				=	0;
	int		n_bom_views			=	0;
	int		rulefound			=	0;
	int		archcnt				=	0;
	int		ichld				=	0;
	int		chldcnt				=	0;
	int		n_count				=	0;
	int		iChildItemTag		=	0;
	int		iaplrlz				=	0;

	char	*cTaskNumber		=	NULL;
	char	*APLDML_name		=	NULL;
	char	*cGroupname			=	NULL;
	char	*cSVRNumber			=	NULL;
	char	*svr_name			=	NULL;
	char	*cPartNumber		=	NULL;
	char	*arch_item_id		=	NULL;
	char	*ModPartNo			=	NULL;
	char	*item_Rev_Seq		=	NULL;
	char	*ErrString			=	NULL;
	char	*RoleName			=	NULL;
	char	*item_Rev_PrtType	=	NULL;
	char	*cPart_Type			=	NULL;

	char	**rulename				=	NULL;
	char	**rulevalue				=	NULL;

	char	PlantName[40];
	char 	LcsSTDWrkg[40];
	char 	LcsSTDRlzd[40];

	tag_t	t_has_solution		=	NULLTAG;
	tag_t	t_has_reference		=	NULLTAG;
	tag_t	t_dmltask			=	NULLTAG;
	tag_t	t_dml				=	NULLTAG;
	tag_t	APLDMLTypeTag		=	NULLTAG;
	tag_t	t_svr				=	NULLTAG;
	tag_t	t_part				=	NULLTAG;
	tag_t 	t_Platform			=	NULLTAG;
	tag_t	bom_view			=	NULLTAG;
	tag_t	t_PlatformRev		=	NULLTAG;
	tag_t	bom_window			=	NULLTAG;
	tag_t	t_revisionrule		=	NULLTAG;
	tag_t	t_closurerule		=	NULLTAG;
	tag_t	top_line			=	NULLTAG;
	//API change
	//tag_t   bom_variant_rule	=	NULLTAG;
	tag_t   *bom_variant_rule	=	NULLTAG;
	int p_count = 0;

	tag_t   t_archnode			=	NULLTAG;
	tag_t   PartChildobj		=	NULLTAG;
	tag_t   t_ChildItemRev		=	NULLTAG;
	tag_t   CurrentRoleTag		=	NULLTAG;

	tag_t	*DMLRevision		=	NULL;
	tag_t	*refTags			=	NULL;
	tag_t	*prtList			=	NULL;
	tag_t	*bom_views			=	NULL;
	tag_t	*t_closureruleList	=	NULL;
	tag_t	*archList			=	NULL;
	tag_t	*childTags			=	NULL;
	tag_t	*ArchNodeLines		=	NULL;

	printf("\nInside tm_chk_CCVC_BOM_STDRLZ");fflush(stdout);

	//fetch releation tag.
	ITKCALL(GRM_find_relation_type("CMReferences",&t_has_reference));//Reference Items
	ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&t_has_solution));//Solution Item
	ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&t_dmltask));//task to dml tag
	
	ITKCALL(AOM_ask_value_string(t_tasktag,"item_id",&cTaskNumber));
	printf("\tCLR STD CCV cTaskNumber ...%s\n", cTaskNumber);fflush(stdout);

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&RoleName));
	printf("\n\nCLR STD CCV  RoleName : %s\n",RoleName); fflush(stdout);

	char ERCClosureRule[40];
	char STDClosureRule[40];
	char RevisionRule[40];
	char BVR[40];
	getPlantWiseRRCCForCCV(RoleName,RevisionRule,STDClosureRule,ERCClosureRule,BVR);
	printf("\nCLR STD CCV STDSI Closure rule : %s",STDClosureRule);fflush(stdout);
	printf("\nCLR STD CCV STDSI Revision rule : %s",RevisionRule);fflush(stdout);
				
	tm_GetGroupFromDML(cTaskNumber, &cGroupname);
	printf("\nCLR STD CCV Task Number : %s, Group Name : %s",cTaskNumber,cGroupname);fflush(stdout);

	GetPlantForDMLORTask( cTaskNumber,PlantName);
	printf("\nCLR STD CCV PlantName :%s",PlantName);fflush(stdout);

	GetPlantWiseRelStat(cTaskNumber,LcsSTDWrkg,LcsSTDRlzd);
	printf("\nCLR STD CCV LcsSTDWrkg: %s \n",LcsSTDWrkg);
	printf("\nCLR STD CCV LcsSTDRlzd: %s \n",LcsSTDRlzd);

	//return 0;
	//Below code is based on control object
	//Query the control object CLRCCVSTDCHLDRLZ
	
	char    *qry_entryCntrl1[3]  	= 	{"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1		= 	(char **) MEM_alloc(5 * sizeof(char *));
	tag_t	qryTagCntrl1			=	NULLTAG;
	int     n_entryCntrl1    		= 	3;
	int		control_number_found	=	0;
	tag_t	*list_of_WSO_cntrl_tags	=	NULLTAG;
	if(QRY_find2("Control Objects...", &qryTagCntrl1));

	if (qryTagCntrl1!=NULLTAG)
	{
		printf("\ntm_chk_CCVC_BOM_STDRLZ Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="STDCLRCCVCHLDRLZ";
		qry_valuesCntrl1[1]="STDCLRCCVCHLDRLZ";
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found, &list_of_WSO_cntrl_tags));
		printf("\ntm_chk_CCVC_BOM_STDRLZ No. of control object found : %d",control_number_found);fflush(stdout);
		
		if(control_number_found>0)
		{
			if (t_dmltask!=NULLTAG)
			{
				ITKCALL(GRM_list_primary_objects_only(t_tasktag,t_dmltask,&dmlcount,&DMLRevision));//Get DML from task
				printf("\n\t\t APL DML Revision from Task : %d",dmlcount); fflush(stdout);

				for (idml=0;idml<dmlcount ;idml++ )
				{
					t_dml	=	DMLRevision[idml];

					ITKCALL(TCTYPE_ask_object_type(t_dml,&APLDMLTypeTag));
					ITKCALL(TCTYPE_ask_name2(APLDMLTypeTag,&APLDML_name));
					printf("\ntm_apl_colour_part_generation APLDML_name : %s",APLDML_name);fflush(stdout);

					if (tc_strcmp(APLDML_name,"T5_APLDMLRevision")==0)
					{
						printf("\nAPL DML Found...");fflush(stdout);
						iapldmlcnt++;
						break;
					}
				}
			}
				
			
			if (t_dml!=NULLTAG && iapldmlcnt>0)
			{
				//find references attached with DML
				ITKCALL(AOM_ask_value_tags(t_dml,"CMReferences",&refCnt,&refTags));
				printf("\nCLR STD CCV refCnt : %d",refCnt);fflush(stdout);

				if (refCnt>0)
				{
					for (isvr=0;isvr<refCnt ;isvr++ )
					{
						svr_name		=	NULL;
						t_svr			=	NULLTAG;
						t_svr			=	refTags[isvr];
						ITKCALL(AOM_ask_value_string(t_svr,"object_name",&svr_name))
						printf("\nCLR STD CCV svr_name: %s",svr_name);fflush(stdout);
						
						tm_Platform_From_SVR(t_svr,&t_Platform);
						if(t_Platform!=NULLTAG)
						{
							char	*objecttype		=	NULL;
							char	*objectname		=	NULL;
							if(AOM_ask_value_string(t_Platform,"object_type",&objecttype));
							if(AOM_ask_value_string(t_Platform,"object_name",&objectname));

							printf("\nCLR STD CCV Object type : %s, Obaject name : %s",objecttype,objectname);fflush(stdout);

							ITKCALL (ITEM_list_bom_views( t_Platform, &n_bom_views, &bom_views ));
							printf("\nCLR STD CCV Number of Platform view : %d",n_bom_views);fflush(stdout);
							if(n_bom_views>0)
							{
								bom_view	=	bom_views[0];
							}
							
							ITKCALL(ITEM_ask_latest_rev(t_Platform, &t_PlatformRev));
						}

						//Found part from task
						ITKCALL(GRM_list_secondary_objects_only(t_tasktag,t_has_solution,&prtcnt,&prtList));
						printf("\nCLR STD CCVNumber of Part attached with task : %d",prtcnt);fflush(stdout);

						if (prtcnt>0)
						{
							for (iprt=0;iprt<prtcnt ;iprt++ )
							{
								cPartNumber	=	NULL;
								cPart_Type	=	NULL;
								t_part	=	NULLTAG;
								t_part	=	prtList[iprt];
								
								ITKCALL(AOM_ask_value_string(t_part,"item_id",&cPartNumber))
								printf("\nCLR STD CCV svr_name: %s",cPartNumber);fflush(stdout);

								ITKCALL(AOM_ask_value_string(t_part,"t5_PartType",&cPart_Type));
								printf("\n\n\t\tCLR STD CCV Part_Type  is :%s",cPart_Type);	fflush(stdout);
								
								if (tc_strcmp(cPart_Type,"CCVC")!=0)
								{
									printf("\nCLR STD CCV Part type is not CCVC, so continue...");fflush(stdout);
									continue;
								}

								if (tc_strstr(svr_name,cPartNumber)!=NULL)
								{
									printf("\nCLR STD CCV isvr : %d, iprt :%d, SVR %s and Part number : %s matched ",isvr,iprt,svr_name,cPartNumber);fflush(stdout);

									//bom explosion
									if (bom_view!=NULLTAG && t_Platform!=NULLTAG)
									{
										bom_window		=	NULLTAG;
										t_revisionrule	=	NULLTAG;
										if (BOM_create_window( &bom_window ));
										//get revision rule RevRuleInfo1
										//if set revision rule then unconfigured revision found in structure so commented below line of code
										//CFM_find --> Finds the revision rule, either stored in the database or modified in the current session.
										if (CFM_find(RevisionRule,&t_revisionrule));
										//BOM_set_window_config_rule --> Sets the Revision (configuration) Rule for the window.
										if (BOM_set_window_config_rule( bom_window, t_revisionrule));

										rulefound			=	0;
										t_closureruleList	=	NULLTAG;
										//if(PIE_find_closure_rules( cAPLClosureRule,PIE_TEAMCENTER, &rulefound, &t_closureruleList ));
										if(PIE_find_closure_rules2(STDClosureRule,PIE_TEAMCENTER, &rulefound, &t_closureruleList ));
										printf ("\nCLR STD CCV rule count %d \n",rulefound);fflush(stdout);
										
										if (rulefound > 0)
										{
											t_closurerule = t_closureruleList[0];
											printf ("CLR STD CCV closure rule found \n"); fflush(stdout);
										}

										top_line	=	NULLTAG;

										ITKCALL(BOM_window_set_closure_rule( bom_window,t_closurerule, 0, rulename,rulevalue ));
										ITKCALL(BOM_set_window_pack_all(bom_window, FALSE));
										ITKCALL(BOM_set_window_top_line(bom_window, NULLTAG, t_PlatformRev, NULLTAG, &top_line));

										//API change
										//ITKCALL(BOM_window_ask_variant_rule( bom_window, &bom_variant_rule ));
										ITKCALL(BOM_window_ask_variant_rules( bom_window,&p_count, &bom_variant_rule ));

										if(top_line!=NULLTAG)
										{
											n_count	=	0;
											ArchNodeLines	=	0;
											ITKCALL(BOM_line_ask_child_lines(top_line, &n_count, &ArchNodeLines));
											printf("\nCLR STD CCV n_count --------> : %d\n", n_count);
											ITKCALL(BOM_window_hide_unconfigured(bom_window));
											ITKCALL(BOM_window_show_variants(bom_window));
											ITKCALL(BOM_window_apply_variant_configuration(bom_window,1,&t_svr));
											ITKCALL(BOM_window_hide_variants(bom_window));

											archcnt	=	0;
											archList	=	NULLTAG;
											ITKCALL(BOM_line_ask_child_lines(top_line, &archcnt, &archList));
											printf("\nCLR STD CCV Number of Arch node found : %d",archcnt);fflush(stdout);

											if (archcnt>0)
											{
												for (ichld=0;ichld<archcnt ;ichld++ )
												{
													t_archnode	=	NULLTAG;
													t_archnode	=	archList[ichld];
													arch_item_id	=	NULL;
													if(AOM_ask_value_string(t_archnode,"bl_item_item_id",&arch_item_id));
													printf("\nCLR STD CCV Arch Node number : %s",arch_item_id);fflush(stdout);

													childTags=NULLTAG;
													chldcnt	=	0;
													ITKCALL(BOM_line_ask_child_lines(t_archnode, &chldcnt, &childTags));
													printf("\nCLR STD CCV Child parts count--> %d\n",chldcnt);fflush(stdout);
													//For testing
													ITKCALL(BOM_window_hide_unconfigured(bom_window));
													if (chldcnt==1)
													{
														if(PartChildobj) PartChildobj	=	NULLTAG;
														if(ModPartNo) ModPartNo	=	NULL;
														if(item_Rev_Seq) item_Rev_Seq	=	NULL;
														PartChildobj	=	childTags[0];

														ITKCALL(AOM_ask_value_string(PartChildobj, "bl_item_item_id", &ModPartNo ));
														printf("\nCLR STD CCV No of Modules Under Architechtures --> : %s\n",ModPartNo); fflush(stdout);
														
														iChildItemTag=0;
														t_ChildItemRev=NULLTAG;
														//API change
														//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag); 
														//BOM_line_ask_attribute_tag(PartChildobj, iChildItemTag, &t_ChildItemRev);

														AOM_ask_value_tag (PartChildobj,bomAttr_lineItemRevTag, &t_ChildItemRev);
														
														ITKCALL(AOM_ask_value_string(t_ChildItemRev, "t5_PartType", &item_Rev_PrtType));
														printf("\nCLR STD CCV item_Rev_PrtType --> : %s\n",item_Rev_PrtType); fflush(stdout);
														if(tc_strcmp(item_Rev_PrtType,"D")==0 || tc_strcmp(item_Rev_PrtType,"DA")==0 || tc_strcmp(item_Rev_PrtType,"DC")==0 || tc_strcmp(item_Rev_PrtType,"IFD")==0 || tc_strcmp(item_Rev_PrtType,"IM")==0)
														{
															printf("\nCLR STD CCV Dummy Module, so bypass");fflush(stdout);
															continue;
														}												

														iaplrlz	=	0;
														tm_Is_Any_Clr_STD_Child_Rlz(t_ChildItemRev,LcsSTDRlzd, &iaplrlz);

														printf("\nCLR STD CCV STD Released flag : %d",iaplrlz);fflush(stdout);

														if(iaplrlz == 0 )
														{
															ErrString	=	NULL;
															ErrString	=	(char	*)MEM_alloc(300);
															tc_strcpy(ErrString,"No revision of Part ");
															tc_strcat(ErrString,ModPartNo);
															//tc_strcat(ErrString,"/");
															//tc_strcat(ErrString,item_Rev_Seq);
															tc_strcat(ErrString," under SVR, ");
															tc_strcat(ErrString,svr_name);
															tc_strcat(ErrString," is released from STDSI from your plant.\n");
															setAddStrFuction(icount,SetChildRelErr,ErrString);
														}
													}
													else if (chldcnt > 1)
													{
														printf("\nMore than one child found....!!!");fflush(stdout);
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

int tm_chkSnapShotBOM_STDRLZ(tag_t t_tasktag,char	***SetChildRelErr,int *icount)
{
	int		status;
	int		pltcnt					=	0;
	int		iplt					=	0;
	int		ipltf					=	0;
	int		ivar					=	0;
	int		n_bom_views				=	0;
	int		rulefound				=	0;
	int		n_count					=	0;
	int		count					=	0;
	int		ichld					=	0;
	int		chldcnt					=	0;
	int		iChildItemTag			=	0;
	int		dmlcount				=	0;
	int		idml					=	0;
	int		st_count				=	0;
	int		iaplrlz					=	0;
	int		iapldr					=	0;
	int		ist						=	0;
	int		prtcnt					=	0;
	int		svrcnt					=	0;
	int		iprt					=	0;
	int		snpcnt					=	0;
	int 	Item_ID					= 	0;
	int 	archcnt					= 	0;

	char	*RoleName				=	NULL;
	char	*objecttype				=	NULL;
	char	*objectname				=	NULL;
	char	*Archtype_name			=	NULL;
	char	*arch_item_id			=	NULL;
	char	*ModPartNo				=	NULL;
	char	*item_Rev_Seq			=	NULL;
	char	*item_Rev_DRStatus		=	NULL;
	char	*item_Rev_PrtType		=	NULL;
	char	*class_name1			=	NULL;
	char	*apl_dr_status			=	NULL;
	char	*itemid					=	NULL;
	char	*cGroupname				=	NULL;
	char	*ErrString				=	NULL;
	char	*release_name			=	NULL;
	char	*CCVNumber				=	NULL;		
	char	*Item_ID_str			=	NULL;
	char	*moduleNumber			=	NULL;
	
	char	**rulename				=	NULL;
	char	**rulevalue				=	NULL;
	
	char	PlantName[40];
	char 	LcsSTDWrkg[40];
	char 	LcsSTDRlzd[40];

	tag_t	CurrentRoleTag			=	NULLTAG;
	tag_t	t_TaskToRef				=	NULLTAG;
	tag_t	t_TaskToPart			=	NULLTAG;
	tag_t	t_CCVCHasSnapShot		=	NULLTAG;
	tag_t	t_Derived_SVR			=	NULLTAG;
	tag_t	t_platform				=	NULLTAG;
	tag_t	t_primary				=	NULLTAG;
	tag_t	t_variant				=	NULLTAG;
	tag_t	bom_view				=	NULLTAG;
	tag_t	item					=	NULLTAG;
	tag_t	bom_window				=	NULLTAG;
	tag_t	rule					=	NULLTAG;
	tag_t	close_tag				=	NULLTAG;
	tag_t	top_lne					=	NULLTAG;
//	tag_t   bom_variant_rule		=	NULLTAG;
//	tag_t  	objTypeTag1				=	NULLTAG;
	tag_t	Childobject				=	NULLTAG;
	tag_t	t_ChildItemRev			=	NULLTAG;
	tag_t	t_DMLTaskRel			=	NULLTAG;
	tag_t	PartChildobj			=	NULLTAG;
	tag_t	DMLRevTag				=	NULLTAG;
	tag_t	class_id1				=	NULLTAG;
	tag_t	t_CCVCtag				=	NULLTAG;
	tag_t	t_snapshot				=	NULLTAG;
	tag_t 	item_rev_tags			= 	NULLTAG;
	tag_t 	window					= 	NULLTAG;
	tag_t 	top_line				= 	NULLTAG;
	tag_t 	t_archnode				= 	NULLTAG;

	tag_t	*pltList				=	NULLTAG;
	tag_t	*bom_views				=	NULLTAG;
	tag_t	*closurerule			=	NULLTAG;
	tag_t	*ArchNodeLines			=	NULLTAG;
	tag_t	*ColIndChilds			=	NULLTAG;
	tag_t	*lines2					=	NULLTAG;
	tag_t	*DMLRevision			=	NULLTAG;
	tag_t	*status_list			=	NULLTAG;
	tag_t	*prtList				=	NULLTAG;
	tag_t	*svrList				=	NULLTAG;
	tag_t	*snpList				=	NULLTAG;
	tag_t	*archList				=	NULLTAG;
	tag_t	*childTags				=	NULLTAG;

	printf("\nInside tm_chkSnapShotBOM_STDRLZ");fflush(stdout);

	//ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	//ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
	//printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

	char    *qry_entryCntrl1[3]  	= 	{"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1		= 	(char **) MEM_alloc(5 * sizeof(char *));
	tag_t	qryTagCntrl1			=	NULLTAG;
	int     n_entryCntrl1    		= 	3;
	int		control_number_found	=	0;
	tag_t	*list_of_WSO_cntrl_tags	=	NULLTAG;
	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	
	if(qryTagCntrl1!=NULLTAG)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="STDCCVSSRBOM";
		qry_valuesCntrl1[1]="STDCCVSSRBOM";;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found, &list_of_WSO_cntrl_tags));
		printf("\nNo. of control object found : %d",control_number_found);fflush(stdout);
		if(control_number_found>0)
		{
			ITKCALL(GRM_find_relation_type("CMReferences",&t_TaskToRef));//Reference Items
			ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&t_TaskToPart));//Solution Item
			ITKCALL(GRM_find_relation_type("T5_PartHasSnapShot",&t_CCVCHasSnapShot));//Part Has ERC Snap Shot
			ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&t_DMLTaskRel));//Part Has Snap Shot
			ITKCALL(GRM_find_relation_type("T5_DerivedFromSVR",&t_Derived_SVR));
			
			ITKCALL(SA_ask_current_role(&CurrentRoleTag));
			ITKCALL(SA_ask_role_name2(CurrentRoleTag,&RoleName))
			printf("\n\n  RoleName : %s\n",RoleName); fflush(stdout);
			
			char ERCClosureRule[40];
			char STDClosureRule[40];
			char RevisionRule[40];
			char BVR[40];
			getPlantWiseRRCCForCCV(RoleName,RevisionRule,STDClosureRule,ERCClosureRule,BVR);
			printf("\nSTDSI Closure rule : %s",STDClosureRule);fflush(stdout);
			
			ITKCALL(AOM_ask_value_string(t_tasktag,"item_id",&itemid));
			printf("\t  itemid ...%s\n", itemid);fflush(stdout);
				
			tm_GetGroupFromDML(itemid, &cGroupname);
			printf("\ngroup Name :%s",cGroupname);fflush(stdout);
			GetPlantForDMLORTask( itemid ,PlantName);
			printf("\nPlantName :%s",PlantName);fflush(stdout);
			
			GetPlantWiseRelStat(itemid,LcsSTDWrkg,LcsSTDRlzd);
			printf("\n LcsSTDWrkg: %s \n",LcsSTDWrkg);
			printf("\n LcsSTDRlzd: %s \n",LcsSTDRlzd);
			
			//GetPlantWiseRelStatAtAPL(itemid,LcsAplWrkg,LcsAplRlzd);
			//printf("\n LcsAplWrkg: %s \n",LcsAplWrkg);
			//printf("\n LcsAplRlzd: %s \n",LcsAplRlzd);
			
			//char	RevRuleInfo1[40];
			//char	BVRInfo2[40];
			//char	currviewmask[40];
			//get_CtrlVal_APLLcsInf(cGroupname,RevRuleInfo1,BVRInfo2,currviewmask);
			//printf("\nRevision Rule : %s , BVR : %s , View Mask : %s \n",RevRuleInfo1,BVRInfo2,currviewmask);fflush(stdout);
										
			//Get DML from Task
			if (t_DMLTaskRel!=NULLTAG)
			{
				ITKCALL(GRM_list_primary_objects_only(t_tasktag,t_DMLTaskRel,&dmlcount,&DMLRevision));//Get DML from task
				printf("\n\t\t APL DML Revision from Task : %d",dmlcount); fflush(stdout);
				for (idml=0;idml<dmlcount ;idml++ )
				{
					DMLRevTag = DMLRevision[idml];					
					ITKCALL(POM_class_of_instance(DMLRevTag,&class_id1));
					ITKCALL(POM_name_of_class(class_id1,&class_name1));
					printf("\n\t class_name found1 :%s",class_name1); fflush(stdout);

					if(tc_strcmp(class_name1,"T5_APLDMLRevision")==0)
					{
						ITKCALL(AOM_ask_value_string( DMLRevTag, "t5_cDRstatus", &apl_dr_status));
						printf("\n erc dr gate: %s\n",apl_dr_status);fflush(stdout);
					}
				}
			}
			if (t_TaskToRef!=NULLTAG)
			{
				printf("\nFetch SVR from task");fflush(stdout);

				ITKCALL(GRM_list_secondary_objects_only(t_tasktag,t_TaskToRef,&pltcnt,&pltList));
				printf("\nNumber of SVRS found in Reference Item : %d",pltcnt);fflush(stdout);
				if (pltcnt>0)
				{
					for(iplt=0;iplt<pltcnt;iplt++)
					{
						printf("\nFind Platform");fflush(stdout);
						t_platform	=	pltList[iplt];
						if(AOM_ask_value_string(t_platform,"object_type",&objecttype));
						if(AOM_ask_value_string(t_platform,"object_name",&objectname));
						printf("\nObject name : %s and type : %s",objectname,objecttype);fflush(stdout);
						if(tc_strcmp(objecttype,"T5_PlatformRevision")==0)
						{
							printf("\nPlatform found...");fflush(stdout);
							t_primary	=	t_platform;
							//t_primary	=	pltList[iplt];
							break;
						}
					}
				}
				else
				{
					printf("\nNo SVR attached with Task");fflush(stdout);
				}
			}
			if(t_TaskToPart!=NULLTAG)
			{
				ITKCALL(GRM_list_secondary_objects_only(t_tasktag,t_TaskToPart,&prtcnt,&prtList));
				printf("\nNumber of Part attached with task : %d",prtcnt);fflush(stdout);
				if(prtcnt>0)
				{
					for(iprt=0;iprt<prtcnt;iprt++)
					{
						t_CCVCtag	=	NULLTAG;
						t_CCVCtag	=	prtList[iprt];
						CCVNumber	=	NULL;
						ITKCALL(AOM_ask_value_string(t_CCVCtag,"item_id",&CCVNumber));
						printf("\nCCV Number : %s",CCVNumber);fflush(stdout);
						
						ITKCALL(GRM_find_relation_type("T5_DerivedFromSVR",&t_Derived_SVR));
						if(t_Derived_SVR!=NULLTAG)
						{
							svrcnt	=	0;
							svrList	=	NULLTAG;
							ITKCALL(GRM_list_secondary_objects_only(t_CCVCtag,t_Derived_SVR,&svrcnt,&svrList));
							printf("\nNumber of svr attached with CCV : %d",svrcnt);fflush(stdout);
							
							if(svrcnt>0)
							{
								t_variant	=	NULLTAG;
								t_variant	=	svrList[0];
								objectname	=	NULL;
								if(AOM_ask_value_string(t_variant,"object_name",&objectname));
								printf("\n123Object name : %s ",objectname);fflush(stdout);
								//Find the ERC Snap Shot Attached with CCV
								ITKCALL(GRM_find_relation_type("T5_PartHasAPLSnapShot",&t_CCVCHasSnapShot));
								if (t_CCVCHasSnapShot!=NULLTAG)
								{
									snpcnt	=	0;
									snpList	=	NULLTAG;
									ITKCALL(GRM_list_secondary_objects_only(t_CCVCtag,t_CCVCHasSnapShot,&snpcnt,&snpList));
									printf("\nNumber of Snap Shot attached : %d",snpcnt);fflush(stdout);
									
									//BOM explosion with Snapshot
									if (snpcnt>0)
									{
										t_snapshot	=	NULLTAG;
										t_snapshot	=	snpList[0];
										item_rev_tags	=	NULLTAG;
										
										char	*snapshotname	=	NULL;
										ITKCALL(AOM_ask_value_string(t_snapshot,"object_name",&snapshotname));
										printf("\nSnap shot name : %s",snapshotname);fflush(stdout);
										ITKCALL(AOM_ask_value_tag(t_snapshot,"topLine",&item_rev_tags));
										
										window		=	NULLTAG;
										top_line	=	NULLTAG;
										
										ITKCALL(BOM_create_window_from_snapshot(t_snapshot,&window));
										ITKCALL(BOM_set_window_pack_all (window, FALSE));
										ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
										//ITKCALL(BOM_window_set_absocc_edit_mode(window, TRUE));
										
										Item_ID	=	0;
										Item_ID_str	=	NULL;

										//API change
										//ITKCALL(BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
										//ITKCALL(BOM_line_ask_attribute_string(top_line, Item_ID, &Item_ID_str));

										AOM_UIF_ask_value(top_line, "bl_item_item_id", &Item_ID_str);
										printf("\nItem_ID_str###:%s",Item_ID_str);fflush(stdout);
										
										//Set closure rule
										//API change
										ITKCALL(PIE_find_closure_rules2("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));
										//ITKCALL(PIE_find_closure_rules(STDClosureRule,PIE_TEAMCENTER, &rulefound, &closurerule ));
										//ITKCALL(PIE_find_closure_rules("BOMLineskipforunconfiguredAPLC",PIE_TEAMCENTER, &rulefound, &closurerule ));
										printf ("\nrule count %d \n",rulefound);fflush(stdout);
										if (rulefound > 0)
										{
											close_tag = closurerule[0];
											printf ("closure rule found \n"); fflush(stdout);
											ITKCALL(BOM_window_set_closure_rule( window,close_tag, 0, rulename,rulevalue ));
										}
																				
										ITKCALL(BOM_window_hide_unconfigured(window));
										ITKCALL(BOM_window_show_variants(window));
										ITKCALL(BOM_window_apply_variant_configuration(window,1,&t_variant));
										ITKCALL(BOM_window_hide_variants(window));
										
										archcnt	=	0;
										archList	=	NULLTAG;
										ITKCALL(BOM_line_ask_child_lines(top_line, &archcnt, &archList));
										printf("\nNumber of Arch node found : %d",archcnt);fflush(stdout);
										if(archcnt>0)
										{
											//STDSI Released check start
											for (ichld=0;ichld<archcnt ;ichld++ )
											{
												//if(t_archnode!=NULLTAG)
												t_archnode	=	NULLTAG;
												t_archnode	=	archList[ichld];
												arch_item_id	=	NULL;
												if(AOM_ask_value_string(t_archnode,"bl_item_item_id",&arch_item_id));
												printf("\nArch Node number : %s",arch_item_id);fflush(stdout);
												
												//if(childTags!=NULLTAG) 
												childTags=NULLTAG;
												chldcnt	=	0;
												ITKCALL(BOM_line_ask_child_lines(t_archnode, &chldcnt, &childTags));
												printf("\n Child parts count--> %d\n",chldcnt);fflush(stdout);
												if(chldcnt==1)
												{
													if(PartChildobj) PartChildobj=NULLTAG;
													if(ModPartNo) ModPartNo=NULL;
													if(item_Rev_Seq) item_Rev_Seq=NULL;
													PartChildobj=childTags[0];
													
													ITKCALL(AOM_ask_value_string(PartChildobj, "bl_item_item_id", &ModPartNo ));
													printf("\n ENo of Modules Under Architechtures --> : %s\n",ModPartNo); fflush(stdout);
															
													ITKCALL(AOM_ask_value_string(PartChildobj, "bl_rev_item_revision_id", &item_Rev_Seq));
													printf("\nE item_Rev_Seq --> : %s\n",item_Rev_Seq); fflush(stdout);

													iChildItemTag=0;
													t_ChildItemRev=NULLTAG;
													//API change
													//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
													//BOM_line_ask_attribute_tag(PartChildobj, iChildItemTag, &t_ChildItemRev);

													AOM_ask_value_tag (PartChildobj,bomAttr_lineItemRevTag, &t_ChildItemRev);
													
													ITKCALL(AOM_ask_value_string(t_ChildItemRev, "t5_PartType", &item_Rev_PrtType));
													printf("\nE item_Rev_PrtType --> : %s\n",item_Rev_PrtType); fflush(stdout);
													if(tc_strcmp(item_Rev_PrtType,"D")==0 || tc_strcmp(item_Rev_PrtType,"DA")==0 || tc_strcmp(item_Rev_PrtType,"DC")==0 || tc_strcmp(item_Rev_PrtType,"IFD")==0 || tc_strcmp(item_Rev_PrtType,"IM")==0)
													{
														printf("\nDummy Module, so bypass");fflush(stdout);
														continue;
													}
													
													ITKCALL(AOM_ask_value_string(t_ChildItemRev, "t5_PartStatus", &item_Rev_DRStatus));
													printf("\n item_Rev_Seq --> : %s, DML DR : %s\n",item_Rev_DRStatus,apl_dr_status); fflush(stdout);
													printf("%s,%s\n",arch_item_id,ModPartNo);fflush(stdout);
													
//													ITKCALL(WSOM_ask_release_status_list(t_ChildItemRev,&st_count,&status_list));
//													printf("\n st_count :%d is\n",st_count);fflush(stdout);
//													iaplrlz	=	0;
//													for(ist=0;ist<st_count;ist++)
//													{
//														release_name	=	NULL;
//														ITKCALL(AOM_ask_name(status_list[ist],&release_name));
//														printf("\n release_name is :%s%s\n",release_name,LcsSTDRlzd);fflush(stdout);
//
//														if ((tc_strcmp(release_name,LcsSTDRlzd)==0))
//														{
//															iaplrlz=1;
//															break;
//														}
//													}

													iaplrlz	=	0;
													iapldr	=	0;
													tm_Is_Any_Child_STDRlz(t_ChildItemRev,LcsSTDRlzd, apl_dr_status, &iaplrlz, &iapldr);
													printf("\nModPartNo : %s, iaplrlz : %d, iapldr : %d",ModPartNo,iaplrlz,iapldr);fflush(stdout);

													printf("\niapl flag : %d",iaplrlz);fflush(stdout);
													if(iaplrlz==0)
													{
														ErrString	=	NULL;
														ErrString	=	(char	*)MEM_alloc(300);
														tc_strcpy(ErrString,"No Revision of Part ");
														tc_strcat(ErrString,ModPartNo);
														tc_strcat(ErrString," under SVR, ");
														tc_strcat(ErrString,objectname);
														tc_strcat(ErrString,"is released from STDSI for your plant.\n");
														setAddStrFuction(icount,SetChildRelErr,ErrString);
													}
																										
													printf("\niapl flag : %d",iapldr);fflush(stdout);
													if(iapldr==0)
													{
														ErrString	=	NULL;
														ErrString	=	(char	*)MEM_alloc(300);
														tc_strcpy(ErrString,"No Revision of Part ");
														tc_strcat(ErrString,ModPartNo);
														tc_strcat(ErrString," under SVR, ");
														tc_strcat(ErrString,objectname);
														tc_strcat(ErrString," is having DR Status equal or higher than DR status of DML DR Status ");
														tc_strcat(ErrString,apl_dr_status);
														tc_strcat(ErrString,".\n");
														setAddStrFuction(icount,SetChildRelErr,ErrString);
													}
												}
												else if(chldcnt>1)
												{
													int imulti	=	0;
													int imod	=	0;
													char	*tmpPartNum	=	NULL;
													
													for (imod=0;imod<chldcnt;imod++)
													{
														ITKCALL(AOM_ask_value_string(childTags[imod],"bl_item_item_id",&moduleNumber));
														printf("\t  moduleNumber ...%s\n", moduleNumber);fflush(stdout);
														
														if (imod==0)
														{
															tmpPartNum	=	NULL;
															tmpPartNum	=	(char*)MEM_alloc(tc_strlen(moduleNumber)+2);
															tc_strcpy(tmpPartNum,moduleNumber);
															printf("\nTemp Module Number : %s",tmpPartNum);fflush(stdout);
														}
														else
														{
															if(tc_strcmp(tmpPartNum,moduleNumber)!=0)
															{
																imulti++;
															}
															else
															{
																printf("\nP	art Number are same %s",moduleNumber);fflush(stdout);
															}
														}
													}
													if(imulti>0)
													{
														printf("\nMore than one Module solve");fflush(stdout);
														ErrString	=	NULL;
														ErrString	=	(char	*)MEM_alloc(300);
														tc_strcpy(ErrString,"More than one module solved in Architecture Node ");
														tc_strcat(ErrString,arch_item_id);
														tc_strcat(ErrString," After SVR ");
														tc_strcat(ErrString,objectname);
														tc_strcat(ErrString," applied on platform.\n");
														setAddStrFuction(icount,SetChildRelErr,ErrString);
													}
													else{
														if(PartChildobj) PartChildobj=NULLTAG;
														if(ModPartNo) ModPartNo=NULL;
														if(item_Rev_Seq) item_Rev_Seq=NULL;
														PartChildobj=childTags[0];
														
														ITKCALL(AOM_ask_value_string(PartChildobj, "bl_item_item_id", &ModPartNo ));
														printf("\n No of Modules Under Architechtures --> : %s\n",ModPartNo); fflush(stdout);
																
														ITKCALL(AOM_ask_value_string(PartChildobj, "bl_rev_item_revision_id", &item_Rev_Seq));
														printf("\n item_Rev_Seq --> : %s\n",item_Rev_Seq); fflush(stdout);

														iChildItemTag=0;
														t_ChildItemRev=NULLTAG;
														//API chanhge
														//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
														//BOM_line_ask_attribute_tag(PartChildobj, iChildItemTag, &t_ChildItemRev);

														AOM_ask_value_tag (PartChildobj,bomAttr_lineItemRevTag, &t_ChildItemRev);
														
														ITKCALL(AOM_ask_value_string(t_ChildItemRev, "t5_PartType", &item_Rev_PrtType));
														printf("\n item_Rev_PrtType --> : %s\n",item_Rev_PrtType); fflush(stdout);
														if(tc_strcmp(item_Rev_PrtType,"D")==0 || tc_strcmp(item_Rev_PrtType,"DA")==0 || tc_strcmp(item_Rev_PrtType,"DC")==0 || tc_strcmp(item_Rev_PrtType,"IFD")==0 || tc_strcmp(item_Rev_PrtType,"IM")==0)
														{
															printf("\nDummy Module, so bypass");fflush(stdout);
															continue;
														}
														
														ITKCALL(AOM_ask_value_string(t_ChildItemRev, "t5_PartStatus", &item_Rev_DRStatus));
														printf("\n item_Rev_Seq --> : %s, DML DR : %s\n",item_Rev_DRStatus,apl_dr_status); fflush(stdout);
													
													
														ITKCALL(WSOM_ask_release_status_list(t_ChildItemRev,&st_count,&status_list));
														printf("\n st_count :%d is\n",st_count);fflush(stdout);
														iaplrlz	=	0;
//														for(ist=0;ist<st_count;ist++)
//														{
//															release_name	=	NULL;
//															ITKCALL(AOM_ask_name(status_list[ist],&release_name));
//															printf("\n release_name is :%s%s\n",release_name,LcsSTDRlzd);fflush(stdout);
//
//															if ((tc_strcmp(release_name,LcsSTDRlzd)==0))
//															{
//																iaplrlz=1;
//																break;
//															}
//														}

														iaplrlz	=	0;
														iapldr	=	0;
														tm_Is_Any_Child_STDRlz(t_ChildItemRev,LcsSTDRlzd, apl_dr_status, &iaplrlz, &iapldr);
														printf("\nModPartNo : %s, iaplrlz : %d, iapldr : %d",ModPartNo,iaplrlz,iapldr);fflush(stdout);

														printf("\niapl flag : %d",iaplrlz);fflush(stdout);
														if(iaplrlz==0)
														{
															ErrString	=	NULL;
															ErrString	=	(char	*)MEM_alloc(300);
															tc_strcpy(ErrString,"No Revision of Part ");
															tc_strcat(ErrString,ModPartNo);
															tc_strcat(ErrString," under SVR, ");
															tc_strcat(ErrString,objectname);
															tc_strcat(ErrString,"is released from STDSI for your plant.\n");
															setAddStrFuction(icount,SetChildRelErr,ErrString);
														}

														//Check DR Status of the Part with DML DR status
														printf("\niapl flag : %d",iapldr);fflush(stdout);
														if(iapldr==0)
														{
															ErrString	=	NULL;
															ErrString	=	(char	*)MEM_alloc(300);
															tc_strcpy(ErrString,"No Revision of Part ");
															tc_strcat(ErrString,ModPartNo);
															tc_strcat(ErrString," under SVR, ");
															tc_strcat(ErrString,objectname);
															tc_strcat(ErrString,"is having DR Status equal or higher than DR status of DML DR Status ");
															tc_strcat(ErrString,apl_dr_status);
															tc_strcat(ErrString,".\n");
															setAddStrFuction(icount,SetChildRelErr,ErrString);
														}
													}
												}
												else
												{
												}
												
											}
										}
									}
									
								}
								else
								{
									printf("\nPart Has Snapshot relation has nulltag");
								}
							}
							else
							{
								printf("\nNO svr attach with CCV");fflush(stdout); 
							}
						}
					}
				}
			}
		}
	}

	return status;
}

//CCV APL Module release check
int tm_CCV_STD_APL_Module_Chk(tag_t t_tasktag,char	***SetChildRelErr,int *icount)
{
	int 	status;
	int		pltcnt					=	0;
	int		iplt					=	0;
	int		ivar					=	0;
	int		n_bom_views				=	0;
	int		rulefound				=	0;
	int		n_count					=	0;
	int		archcnt					=	0;
	int		ichld					=	0;
	int		chldcnt					=	0;
	int		iChildItemTag			=	0;
	int		iaplrlz					=	0;
	
	char	*loginuser				=	NULL;
	char	*cTaskNumber			=	NULL;
	char	*type_itemRev			=	NULL;
	char	*getPlantViewName		=	NULL;
	char	*cGroupname				=	NULL;
	
	char	*RoleName				=	NULL;
	//char	*BVR					=	NULL;
	char	*objecttype				=	NULL;
	char	*objectname				=	NULL;
	char	*arch_item_id			=	NULL;
	char	*ModPartNo				=	NULL;
	char	*item_Rev_Seq			=	NULL;
	char	*item_Rev_PrtType		=	NULL;
	char	*item_Rev_DRStatus		=	NULL;
	char	*ErrString				=	NULL;
	
	char	cCurrentAccessDate[20]={0};
	char	PlantName[40];
	char 	LcsSTDWrkg[40];
	char 	LcsSTDRlzd[40];
	//API change
	//char	cSTDClosureRule[40];
	char *cSTDClosureRule = NULL;
	cSTDClosureRule = (char *)MEM_alloc(1 * sizeof(char *));
	char	cSTDRevisionRule[40];
	char	cERCClosureRule[40];
	char	BVR[40];
	
	char	**rulename				=	NULL;
	char	**rulevalue				=	NULL;
	
	tag_t	itemTypeTag_cdss		=	NULLTAG;
	tag_t	t_TaskToRef				=	NULLTAG;
	tag_t	t_DMLTaskRel			=	NULLTAG;
	tag_t	t_CCVCHasSnapShot		=	NULLTAG;
	tag_t	t_TaskToPart			=	NULLTAG;
	tag_t	CurrentRoleTag			=	NULLTAG;
	tag_t	t_platform				=	NULLTAG;
	tag_t	t_variant				=	NULLTAG;
	tag_t	bom_view				=	NULLTAG;
	tag_t	bom_window				=	NULLTAG;
	tag_t	rule					=	NULLTAG;
	tag_t	close_tag				=	NULLTAG;
	tag_t	top_line				=	NULLTAG;
	//API change
	tag_t   *bom_variant_rule		=	NULLTAG;
	int p_count=0;
	//tag_t   bom_variant_rule		=	NULLTAG;
	tag_t   t_archnode				=	NULLTAG;
	tag_t   PartChildobj			=	NULLTAG;
	tag_t   t_primary				=	NULLTAG;
	tag_t   item					=	NULLTAG;
	tag_t   t_ChildItemRev			=	NULLTAG;
	
	tag_t	*pltList				=	NULLTAG;
	tag_t	*bom_views				=	NULLTAG;
	tag_t	*closurerule			=	NULLTAG;
	tag_t	*ArchNodeLines			=	NULLTAG;
	tag_t	*archList				=	NULLTAG;
	tag_t	*childTags				=	NULLTAG;
	
	printf("\nInside tm_CCV_STD_APL_Module_Chk");fflush(stdout);
	
	POM_get_user_id(&loginuser);
	printf("\nStarting for taskbreskdownnn :%s....\n",loginuser);fflush(stdout);
	getCurrentDateTime(cCurrentAccessDate);
	printf("\n Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);
	
	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&RoleName))
	printf("\n\n  RoleName : %s\n",RoleName); fflush(stdout);
	
	ITKCALL(AOM_ask_value_string(t_tasktag,"item_id",&cTaskNumber));
	printf("\t  cTaskNumber ...%s\n", cTaskNumber);fflush(stdout);
	
	ITKCALL (TCTYPE_ask_object_type(t_tasktag,&itemTypeTag_cdss));
	ITKCALL (TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));
	printf("\nGrp 98 type_itemRev : %s",type_itemRev);fflush(stdout);
	
	ITKCALL(GRM_find_relation_type("CMReferences",&t_TaskToRef));//Reference Items
	ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&t_DMLTaskRel));//DML TASK RELATION
	ITKCALL(GRM_find_relation_type("T5_PartHasAPLSnapShot",&t_CCVCHasSnapShot));//Part Has APLC Snap Shot
	ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&t_TaskToPart));//Solution Item
	
	char    *qry_entryCntrl1[3]  	= 	{"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1		= 	(char **) MEM_alloc(5 * sizeof(char *));
	tag_t	qryTagCntrl1			=	NULLTAG;
	int     n_entryCntrl1    		= 	3;
	int		control_number_found	=	0;
	tag_t	*list_of_WSO_cntrl_tags	=	NULLTAG;
	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	
	if(qryTagCntrl1!=NULLTAG)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="STDCCVAPLPrt";
		qry_valuesCntrl1[1]="STDCCVAPLPrt";;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found, &list_of_WSO_cntrl_tags));
		printf("\ncreateSnapShot_APL No. of control object found : %d",control_number_found);fflush(stdout);
		
		if(control_number_found>0)
		{
			printf("\nControl object found, proceed for APL Module check...");fflush(stdout);
			if (tc_strcmp(type_itemRev,"T5_APLTaskRevision")==0)
			{
				getPlantViewName=NULL;
				tm_GetViewFromDML(cTaskNumber, &getPlantViewName);
				printf("\nCCV STD getPlantViewName : %s",getPlantViewName);fflush(stdout);
				tm_GetGroupFromDML(cTaskNumber, &cGroupname);
				printf("\nCCV STD group Name :%s",cGroupname);fflush(stdout);
				
				GetPlantForDMLORTask( cTaskNumber ,PlantName);
				printf("\nCCV STD PlantName :%s",PlantName);fflush(stdout);
				getPlantWiseRRCCForCCV(RoleName,cSTDRevisionRule,cSTDClosureRule,cERCClosureRule,BVR);
				printf("\nSTDSI Closure rule : %s",cSTDClosureRule);fflush(stdout);
				printf("\nSTDSI Revision rule : %s",cSTDRevisionRule);fflush(stdout);
						
				GetPlantWiseRelStat(cTaskNumber,LcsSTDWrkg,LcsSTDRlzd);
				printf("\n LcsSTDWrkg: %s \n",LcsSTDWrkg);
				printf("\n LcsSTDRlzd: %s \n",LcsSTDRlzd);
				
				if (t_TaskToRef!=NULLTAG)
				{
					ITKCALL(GRM_list_secondary_objects_only(t_tasktag,t_TaskToRef,&pltcnt,&pltList));
					printf("\nNumber of SVRS found in Reference Item : %d",pltcnt);fflush(stdout);
					
					if(pltcnt>0)
					{
						for(iplt=0;iplt<pltcnt;iplt++)
						{
							printf("\nFind Platform");fflush(stdout);
							t_platform	=	pltList[iplt];
							if(AOM_ask_value_string(t_platform,"object_type",&objecttype));
							if(AOM_ask_value_string(t_platform,"object_name",&objectname));
							printf("\nObject name : %s and type : %s",objectname,objecttype);fflush(stdout);
							if(tc_strcmp(objecttype,"T5_PlatformRevision")==0)
							{
								printf("\nPlatform found...");fflush(stdout);
								t_primary	=	t_platform;
								//t_primary	=	pltList[iplt];
								break;
							}
						}
						
						if (t_primary!=NULLTAG)
						{
							for(ivar=0;ivar<pltcnt;ivar++)
							{
								printf("\nFind attached variant rule");fflush(stdout);
								t_variant	=	pltList[ivar];
								
								if(AOM_ask_value_string(t_variant,"object_type",&objecttype));
								if(AOM_ask_value_string(t_variant,"object_name",&objectname));
								printf("\nObject name : %s and type : %s",objectname,objecttype);fflush(stdout);
								if(tc_strcmp(objecttype,"VariantRule")==0)
								{
									printf("\ninside VariantRule found");fflush(stdout);
									
									if (t_primary!=NULLTAG)
									{
										printf("\nt_primary is not nulltag");fflush(stdout);
									}
									if ( ITEM_ask_item_of_rev( t_primary, &item ));
									if ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));
									printf("\nView found check.......%d\n",n_bom_views); fflush(stdout);
									bom_view = bom_views[0];
									
									if (bom_view!=NULLTAG)
									{
										bom_window	=	NULLTAG;
										rule		=	NULLTAG;
										if (BOM_create_window( &bom_window ));
										ITKCALL(CFM_find(cSTDRevisionRule, &rule));
										printf("\nView found check.......%d\n",n_bom_views); fflush(stdout);
										ITKCALL(BOM_set_window_config_rule(bom_window, rule));
										
										rulefound	=	0;
										closurerule	=	NULLTAG;
										
										//API change
										ITKCALL(PIE_find_closure_rules2(cSTDClosureRule,PIE_TEAMCENTER, &rulefound, &closurerule ));
										printf ("\nrule count %d \n",rulefound);fflush(stdout);
										if (rulefound > 0)
										{
											close_tag = closurerule[0];
											printf ("closure rule found \n"); fflush(stdout);
										}
										
										top_line	=	NULLTAG;
										ITKCALL(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));
										ITKCALL(BOM_set_window_pack_all(bom_window, FALSE));
										ITKCALL(BOM_set_window_top_line( bom_window, NULLTAG, t_primary, NULLTAG, &top_line ));
										//API change
										//ITKCALL(BOM_window_ask_variant_rule( bom_window, &bom_variant_rule ));
										ITKCALL(BOM_window_ask_variant_rules( bom_window,&p_count, &bom_variant_rule ));
										
										if(top_line!=NULLTAG)
										{
											n_count			=	0;
											ArchNodeLines	=	0;
											ITKCALL(BOM_line_ask_child_lines(top_line, &n_count, &ArchNodeLines));
											printf("\n n_count --------> : %d\n", n_count);
											
											ITKCALL(BOM_window_hide_unconfigured(bom_window));
											ITKCALL(BOM_window_show_variants(bom_window));
											ITKCALL(BOM_window_apply_variant_configuration(bom_window,1,&t_variant));
											ITKCALL(BOM_window_hide_variants(bom_window));
											
											archcnt	=	0;
											archList	=	NULLTAG;
											ITKCALL(BOM_line_ask_child_lines(top_line, &archcnt, &archList));
											printf("\nNumber of Arch node found : %d",archcnt);fflush(stdout);
											
											for (ichld=0;ichld<archcnt ;ichld++ )
											{
												t_archnode	=	NULLTAG;
												t_archnode	=	archList[ichld];
												arch_item_id	=	NULL;
												if(AOM_ask_value_string(t_archnode,"bl_item_item_id",&arch_item_id));
												//printf("\nArch Node number : %s",arch_item_id);fflush(stdout);
												
												childTags=NULLTAG;
												chldcnt	=	0;
												ITKCALL(BOM_line_ask_child_lines(t_archnode, &chldcnt, &childTags));
												//printf("\n Child parts count--> %d\n",chldcnt);fflush(stdout);
												
												if(chldcnt==1)
												{
													if(PartChildobj) PartChildobj=NULLTAG;
													if(ModPartNo) ModPartNo=NULL;
													if(item_Rev_Seq) item_Rev_Seq=NULL;
													PartChildobj=childTags[0];
													
													ITKCALL(AOM_ask_value_string(PartChildobj, "bl_item_item_id", &ModPartNo ));
															
													ITKCALL(AOM_ask_value_string(PartChildobj, "bl_rev_item_revision_id", &item_Rev_Seq));
													
													if(tc_strstr(ModPartNo,"B4Z01")!=NULL || tc_strstr(ModPartNo,"B5Z01")!=NULL)
													{
														printf("\nAPL MODULE FOUND...");fflush(stdout);
														printf("\n ModPartNo --> : %s\n",ModPartNo); fflush(stdout);
														printf("\n item_Rev_Seq --> : %s\n",item_Rev_Seq); fflush(stdout);
														//Check Part is released
														
														iChildItemTag=0;
														t_ChildItemRev=NULLTAG;

														//API change
														//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
														//BOM_line_ask_attribute_tag(PartChildobj, iChildItemTag, &t_ChildItemRev);

														AOM_ask_value_tag (PartChildobj,bomAttr_lineItemRevTag, &t_ChildItemRev);

														
														tag_t	objTypeTag	=	NULLTAG;
														char	*type_name	=	NULL;
														if(TCTYPE_ask_object_type(t_ChildItemRev,&objTypeTag));
														if(TCTYPE_ask_name2(objTypeTag,&type_name));
														printf("\nChild part type : %s",type_name);fflush(stdout);
														
														ITKCALL(AOM_ask_value_string(t_ChildItemRev, "t5_PartType", &item_Rev_PrtType));
														printf("\n item_Rev_PrtType --> : %s\n",item_Rev_PrtType); fflush(stdout);
														if(tc_strcmp(item_Rev_PrtType,"D")==0 || tc_strcmp(item_Rev_PrtType,"DA")==0 || tc_strcmp(item_Rev_PrtType,"DC")==0 || tc_strcmp(item_Rev_PrtType,"IFD")==0 || tc_strcmp(item_Rev_PrtType,"IM")==0)
														{
															printf("\nDummy Module, so bypass");fflush(stdout);
															continue;
														}
														//int		st_count		=	0;
														//tag_t	*status_list	=	NULLTAG;
														//ITKCALL(WSOM_ask_release_status_list(t_ChildItemRev,&st_count,&status_list));
														//printf("\n st_count :%d is\n",st_count);fflush(stdout);
														//iaplrlz	=	0;
														tag_t	queryPart	=	NULLTAG;
														int		n_entries	=	2;
														int    	num_to_sort =	1;
														char 	*keys[1] 	= 	{"creation_date"};
														int  	orders[1]  	=	{2};
														int		n_found		=	0;
														tag_t   *results	=	NULL;
														char 	*qry_part_entries[2] = {"Item ID","Release Status"};
														char 	*qry_part_values[2] = {"*",LcsSTDRlzd};
														ITKCALL(QRY_find2("Item Revision...", &queryPart));
														qry_part_values[0]=	ModPartNo;
														
														QRY_execute_with_sort(queryPart, n_entries, qry_part_entries, qry_part_values, num_to_sort, keys, orders, &n_found, &results);
														printf("\nNo of STD Release Part %s found : %d",ModPartNo,n_found);fflush(stdout);
														
														//printf("\nInside item_Rev_Seq --> : %s\n",item_Rev_DRStatus); fflush(stdout);
														if(n_found>0)
														{
														}
														else{
															printf("\nNO Part revision found...");fflush(stdout);
															ErrString	=	NULL;
															ErrString	=	(char	*)MEM_alloc(300);
															tc_strcpy(ErrString,"No Revision Of Part Number ");
															tc_strcat(ErrString, ModPartNo);
															tc_strcat(ErrString," is released from STDSI ");
															//tc_strcat(ErrString,", equal or higher DR status of DML ");
															//tc_strcat(ErrString,ToDR);
															//tc_strcat(ErrString,"\n");
															setAddStrFuction(icount,SetChildRelErr,ErrString);
														}
													}
												}
												else{
													//printf("\nNO Module Found...");fflush(stdout);
												}
											}
											
										}
										else{
											printf("\nTop line is NULLTAG...");fflush(stdout);
										}
									}
									else{
										printf("\n bom view is null");fflush(stdout);
									}
								}
								else{
									printf("\nObject is not SVR...");fflush(stdout);
								}
							}
						}
						else{
							printf("\nPlatform tag not found in Reference Items");fflush(stdout);
						}
					}
					else{
						printf("\nNO SVR and Platform attached with Task");fflush(stdout);
					}
				}
				else{
					printf("\nReference Items is NULL");fflush(stdout);
				}
				
			}
			else{
				printf("\nObject type is not APL TASK...");fflush(stdout);
			}
		}
		else{
			printf("\nNO Control object found...");fflush(stdout);
		 }
	}
	else{
		printf("\nQuery tag is not found...");fflush(stdout);
	}
	
	return status;
}
//CCV Snapshot creation

int createSnapShot_STD(tag_t taskObject)
{
	int		status					=	0;
	int		CCVcnt					=	0;
	int		pltcnt					=	0;
	int		iplt					=	0;
	int		ivar					=	0;
	int		n_bom_views				=	0;
	int		rulefound				=	0;
	int		n_lines1				=	0;
	int		iccv					=	0;
	int		isnpcrt					=	0;
	
	char	*loginuser				=	NULL;
	char	*cTaskNumber			=	NULL;
	char	*type_itemRev			=	NULL;
	char	*getPlantViewName		=	NULL;
	char	*cGroupname				=	NULL;
	char	*cSTDRevisionRule		=	NULL;
	char	*cSTDClosureRule		=	NULL;
	cSTDClosureRule = (char *)MEM_alloc(1 * sizeof(char *));
	char	*objecttype				=	NULL;
	char	*objectname				=	NULL;
	char	*itemId12				=	NULL;
	char	*childsvrname			=	NULL;
	char	*VehName				=	NULL;
	char	*CCVNumber				=	NULL;
	char	*TempVal				=	NULL;
	char	*getBVR					=	NULL;
	char	*tmcurrenttime			=	NULL;
	
	char 	**rulename 				= 	NULL;
	char 	**rulevalue 			= 	NULL;
	
	char	cCurrentAccessDate[20]={0};
	char	PlantName[40];
	
	tag_t	t_TaskToRef				=	NULLTAG;
	tag_t	t_TaskToPart			=	NULLTAG;
	tag_t	t_CCVCHasSnapShot		=	NULLTAG;
	tag_t	itemTypeTag_cdss		=	NULLTAG;
	tag_t	t_pltfrm				=	NULLTAG;
	tag_t	t_primary				=	NULLTAG;
	tag_t	t_variant				=	NULLTAG;
	tag_t	view_type				=	NULLTAG;
	tag_t	item					=	NULLTAG;
	tag_t	bom_view				=	NULLTAG;
	tag_t	t_revisionrule			=	NULLTAG;
	tag_t	t_closurerule			=	NULLTAG;
	tag_t	top_line				=	NULLTAG;
	tag_t	CCVTag					=	NULLTAG;
	tag_t	bom_window				=	NULLTAG;
	tag_t   snapshot				=	NULLTAG;
	tag_t   Rel_task            	= 	NULLTAG;
	
	tag_t	*CCVList				=	NULLTAG;
	tag_t	*pltList				=	NULLTAG;
	tag_t	*bom_views				=	NULLTAG;
	tag_t	*t_closureruleList		=	NULLTAG;
	tag_t	*lines					=	NULLTAG;
	
	printf("\nInside createSnapShot_STD");fflush(stdout);
	
	ITKCALL(GRM_find_relation_type("CMReferences",&t_TaskToRef));//Reference Items
	ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&t_TaskToPart));//Solution Item
	ITKCALL(GRM_find_relation_type("T5_PartHasSTDSnapShot",&t_CCVCHasSnapShot));//Part Has Snap Shot
	
	POM_get_user_id(&loginuser);
	printf("\nStarting for taskbreskdownnn :%s....\n",loginuser);fflush(stdout);
	getCurrentDateTime(cCurrentAccessDate);
	printf("\n Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);
	STRNG_replace_str(cCurrentAccessDate," ","_",&tmcurrenttime);
	STRNG_replace_str(tmcurrenttime,":","_",&tmcurrenttime);
	STRNG_replace_str(tmcurrenttime,"-","_",&tmcurrenttime);

	ITKCALL(AOM_ask_value_string(taskObject,"item_id",&cTaskNumber));
	printf("\t  cTaskNumber ...%s\n", cTaskNumber);fflush(stdout);
	
	ITKCALL (TCTYPE_ask_object_type(taskObject,&itemTypeTag_cdss));
	ITKCALL (TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));
	printf("\nCCV STDS type_itemRev : %s",type_itemRev);fflush(stdout);
	
	char    *qry_entryCntrl1[3]  	= 	{"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1		= 	(char **) MEM_alloc(5 * sizeof(char *));
	tag_t	qryTagCntrl1			=	NULLTAG;
	int     n_entryCntrl1    		= 	3;
	int		control_number_found	=	0;
	tag_t	*list_of_WSO_cntrl_tags	=	NULLTAG;
	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	
	if(qryTagCntrl1!=NULLTAG)
	{
		if(qryTagCntrl1!=NULLTAG)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrl1[0]="STDCCVCreate";
			qry_valuesCntrl1[1]="STDCCVCreate";
			qry_valuesCntrl1[2]="0";
			
			if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found, &list_of_WSO_cntrl_tags));
			printf("\ncreateSnapShot_APL No. of control object found : %d",control_number_found);fflush(stdout);
			
			if (control_number_found>0)
			{
				if (tc_strcmp(type_itemRev,"T5_APLTaskRevision")==0)
				{
					getPlantViewName=NULL;
					tm_GetViewFromDML(cTaskNumber, &getPlantViewName);
					printf("\nCCV STD getPlantViewName : %s",getPlantViewName);fflush(stdout);
					tm_GetGroupFromDML(cTaskNumber, &cGroupname);
					printf("\nCCV STD group Name :%s",cGroupname);fflush(stdout);
					
					GetPlantForDMLORTask( cTaskNumber ,PlantName);
					printf("\nCCV STD PlantName :%s",PlantName);fflush(stdout);
					tm_getSTDReleasedCtxtForCCV(PlantName,&cSTDRevisionRule,&cSTDClosureRule,&getBVR);
					printf("\nCCV STD STDRevision Rule : %s, STD Closure Rule : %s",cSTDRevisionRule,cSTDRevisionRule);fflush(stdout);
					//Fetch SVR and Platform attached with Task from reference items
					if(t_TaskToRef!=NULLTAG)
					{
						ITKCALL(GRM_list_secondary_objects_only(taskObject,t_TaskToPart,&CCVcnt,&CCVList));
						printf("\nNumber of SVRS found in Reference Item : %d",CCVcnt);fflush(stdout);
						
						ITKCALL(GRM_list_secondary_objects_only(taskObject,t_TaskToRef,&pltcnt,&pltList));
						printf("\nNumber of SVRS found in Reference Item : %d",pltcnt);fflush(stdout);
						
						if(pltcnt>0)
						{
							for(iplt=0;iplt<pltcnt;iplt++)
							{
								printf("\nFind Platform");fflush(stdout);
								t_pltfrm	=	pltList[iplt];
								if(AOM_ask_value_string(t_pltfrm,"object_type",&objecttype));
								if(AOM_ask_value_string(t_pltfrm,"object_name",&objectname));
								printf("\nObject name : %s and type : %s",objectname,objecttype);fflush(stdout);
								if(tc_strcmp(objecttype,"T5_PlatformRevision")==0)
								{
									printf("\nPlatform found...");fflush(stdout);
									t_primary	=	t_pltfrm;
									break;
								}
							}
							if(t_primary!=NULLTAG)
							{
								for(ivar=0;ivar<pltcnt;ivar++)
								{
									printf("\nFind attached variant rule");fflush(stdout);
									t_variant	=	pltList[ivar];
									
									if(AOM_ask_value_string(t_variant,"object_type",&objecttype));
									if(AOM_ask_value_string(t_variant,"object_name",&objectname));
									printf("\nObject name : %s and type : %s",objectname,objecttype);fflush(stdout);
									
									if(tc_strcmp(objecttype,"VariantRule")==0)
									{
										printf("\nVariant Rule found in relation"); fflush(stdout);
										printf("\nSTD CCV View name : %s ",getPlantViewName);fflush(stdout);
										if(PS_find_view_type(getPlantViewName, &view_type));
										printf("\nSTD CCV PS_find_view_type is found......\n" ); fflush(stdout);
										
										//For Testing
										// if(isnpcrt==1)
										// {
											// continue;
										// }
										if ( view_type != NULLTAG )
										{
											if ( ITEM_ask_item_of_rev( t_pltfrm, &item ));
											if ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));
											bom_view = bom_views[0];
										}
										else
										{
											printf("\nView not found check.......\n"); fflush(stdout);
										}
										if(bom_view!=NULLTAG)
										{
											printf(" before BOM_create_window..\n");fflush(stdout);
											if (BOM_create_window( &bom_window ));
											if (CFM_find(cSTDRevisionRule,&t_revisionrule));
											if (BOM_set_window_config_rule( bom_window, t_revisionrule));
											
											//API change
											if(PIE_find_closure_rules2( cSTDClosureRule,PIE_TEAMCENTER, &rulefound, &t_closureruleList ));
											printf ("rule count %d \n",rulefound);fflush(stdout);
											
											if (rulefound > 0)
											{
												t_closurerule = t_closureruleList[0];
												printf ("closure rule found \n");fflush(stdout);
												// MEM_free(tags_found);
											}
											
											if(BOM_window_set_closure_rule( bom_window,t_closurerule, 0, rulename,rulevalue ));
											if(BOM_set_window_pack_all(bom_window, TRUE));
											if(BOM_set_window_top_line( bom_window, NULLTAG, t_pltfrm, NULLTAG, &top_line ));
											printf( " After BOM_set_window_top_line..\n");fflush(stdout);
											
											if (top_line!=NULLTAG )
											{
												if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines))   ;
												printf("\n before hiide LLlast Before setting option n_lines1: %d \n", n_lines1);
												
												if(bom_window != NULLTAG)
												{
													printf("\n before inside bom_window-----\n"); fflush(stdout);
													if(BOM_window_hide_unconfigured(bom_window));
													if(BOM_window_show_variants(bom_window));
													
													VehName=(char *) MEM_alloc(20);
													printf("\n to find impacted items\n");fflush(stdout);
													//   ItemObj = taskList[k];
													if(AOM_ask_value_string(t_variant,"object_name",&childsvrname));
													
													printf("\nSVR Name : %s",childsvrname);fflush(stdout);
													
													itemId12 = tc_strtok(childsvrname,"_");
													printf("\nItem number : %s",itemId12);fflush(stdout);
													
													for(iccv=0;iccv<CCVcnt;iccv++)
													{
														CCVTag	=	CCVList[iccv];
														ITKCALL(AOM_ask_value_string(CCVTag, "item_id", &CCVNumber ));
														printf("\n CCVNumber --> : %s\n",CCVNumber); fflush(stdout);
														
														if(tc_strstr(CCVNumber,itemId12)!=NULL)
														{
															printf("\nCCV found for SVR");fflush(stdout);
															break;
														}
													}
													TempVal	=	(char	*)MEM_alloc(tc_strlen(childsvrname)+tc_strlen(loginuser)+tc_strlen(tmcurrenttime)+50);
													tc_strcpy(TempVal,childsvrname);
													tc_strcat(TempVal,"_");
													tc_strcat(TempVal,loginuser);
													tc_strcat(TempVal,"_");
													tc_strcat(TempVal,tmcurrenttime);
													tc_strcat(TempVal,"_Snapshot");
													
													printf("\nSnapshot name: %s",TempVal);fflush(stdout);
													
													if(BOM_window_apply_variant_configuration(bom_window,1,&t_variant));
													if(BOM_window_hide_variants(bom_window));
													
													if(BOM_create_snapshot(bom_window,TempVal,"STD Snapshot for SVR",&snapshot));
													
													if(snapshot!=NULLTAG)
													{
														if(AOM_save_with_extensions( snapshot) )
														if(AOM_refresh(snapshot,1));
														if(AOM_unlock(snapshot));
														//isnpcrt	=	1; //it is used for testing
													}
													else{
														printf("\nsnapshot tag is null");fflush(stdout);
													}
													
													if(CCVTag!=NULLTAG)
													{
														if(t_CCVCHasSnapShot != NULLTAG)
														{
															if(GRM_create_relation(CCVTag,snapshot,t_CCVCHasSnapShot,NULLTAG,&Rel_task));
															if(GRM_save_relation(Rel_task));
														}
													}
												
												}
											}
										}
									}
									else{
										printf("\nSTD CCV not Item Type is not Variant Rule");fflush(stdout);
									}
								}
							}
							else{
								printf("\nSTD CCV t_primary is NULLTAG");fflush(stdout);
							}
						}
						else
						{
							printf("\nNO Platform and SVR foun in Referece Items.");fflush(stdout);
						}
					}
				}
				else
				{
					printf("\nType is not APL task ");fflush(stdout);
				}
			}
		}
	}
	
	return	status;
}

int	createSnapshotGMSTD(tag_t	taskObject)
{
	int		status					=	ITK_ok;
	int		pltcnt					=	0;
	int		iplt					=	0;
	int		n_bom_views				=	0;
	int		rulefound				=	0;
	int		dmlcount				=	0;
	int		idml					=	0;

	char	cCurrentAccessDate[20]={0};

	char*	loginuser				=	NULL;
	char*	cTaskNumber				=	NULL;
	char*	type_itemRev			=	NULL;
	char*	getPlantViewName		=	NULL;
	char*	cGroupname				=	NULL;
	char	PlantName[40]			;
	char*	cSTDRevisionRule		=	NULL;
	char*	cSTDClosureRule			=	NULL;
	cSTDClosureRule = (char *)MEM_alloc(1 * sizeof(char *));
	char*	cCCVNumber				=	NULL;
	char*	cCCVPrttype				=	NULL;
	char*	cSVRName				=	NULL;
	char*	objecttype				=	NULL;
	char*	objectname				=	NULL;
	char*	VehName					=	NULL;
	char*	childsvrname			=	NULL;
	char*	TempVal					=	NULL;
	char*	getBVR					=	NULL;
	char*	tmcurrenttime			=	NULL;
	char*	class_name1				=	NULL;
	char*	apl_rlz_type			=	NULL;
	char*	apl_proj				=	NULL;
	char*	sUserInfo1				=	NULL;

	char**	rulename 				= 	NULL;
	char**	rulevalue 				= 	NULL;

	tag_t	t_TaskToRef				=	NULLTAG;
	tag_t	t_TaskToPart			=	NULLTAG;
	tag_t	t_CCVCHasSnapShot		=	NULLTAG;
	tag_t	itemTypeTag_cdss		=	NULLTAG;
	tag_t	t_ccvc					=	NULLTAG;
	tag_t	t_SVRtag				=	NULLTAG;
	tag_t	t_Platform				=	NULLTAG;
	tag_t	t_PlatformRev			=	NULLTAG;
	tag_t	bom_view				=	NULLTAG;
	tag_t	view_type				=	NULLTAG;
	tag_t	bom_window				=	NULLTAG;
	tag_t	t_revisionrule			=	NULLTAG;
	tag_t	t_closurerule			=	NULLTAG;
	tag_t	top_line				=	NULLTAG;
	tag_t   snapshot				=	NULLTAG;
	tag_t   Rel_task				= 	NULLTAG;
	tag_t   t_DMLTaskRel			= 	NULLTAG;
	tag_t   DMLRevTag				= 	NULLTAG;
	tag_t   class_id1				= 	NULLTAG;

	tag_t*	pltList					=	NULLTAG;
	tag_t*	bom_views				=	NULLTAG;
	tag_t*	t_closureruleList		=	NULLTAG;
	tag_t*	DMLRevision				=	NULLTAG;

	printf("\nInside createSnapshotGMAPL\n");fflush(stdout);

	ITKCALL(GRM_find_relation_type("CMReferences",&t_TaskToRef));//Reference Items
	ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&t_TaskToPart));//Solution Item
	ITKCALL(GRM_find_relation_type("T5_PartHasSTDSnapShot",&t_CCVCHasSnapShot));//Part Has Snap Shot

	POM_get_user_id(&loginuser);
	printf("\nStarting for taskbreskdownnn :%s....\n",loginuser);fflush(stdout);
	getCurrentDateTime(cCurrentAccessDate);
	printf("\n Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);
	STRNG_replace_str(cCurrentAccessDate," ","_",&tmcurrenttime);

	ITKCALL(AOM_ask_value_string(taskObject,"item_id",&cTaskNumber));
	printf("\t  cTaskNumber ...%s\n", cTaskNumber);fflush(stdout);

	ITKCALL (TCTYPE_ask_object_type(taskObject,&itemTypeTag_cdss));
	ITKCALL (TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));
	printf("\nGrp 98 type_itemRev : %s",type_itemRev);fflush(stdout);

	char    *qry_entryCntrl1[3]  	= 	{"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1		= 	(char **) MEM_alloc(5 * sizeof(char *));
	tag_t	qryTagCntrl1			=	NULLTAG;
	int     n_entryCntrl1    		= 	3;
	int		control_number_found	=	0;
	tag_t	*list_of_WSO_cntrl_tags	=	NULLTAG;
	if(QRY_find2("Control Objects...", &qryTagCntrl1));

	if (qryTagCntrl1!=NULLTAG)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="STDCCVGMCreate";
		qry_valuesCntrl1[1]="STDCCVGMCreate";;
		qry_valuesCntrl1[2]="0";

		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found, &list_of_WSO_cntrl_tags));
		printf("\ncreateSnapShot_APL No. of control object found : %d",control_number_found);fflush(stdout);

		if (control_number_found>0)
		{
			AOM_ask_value_string( list_of_WSO_cntrl_tags[0], "t5_Userinfo1", &sUserInfo1);
			printf("\n sUserInfo1: %s\n",sUserInfo1);fflush(stdout);

			if (tc_strcmp(type_itemRev,"T5_APLTaskRevision")==0)
			{
				getPlantViewName=NULL;
				tm_GetViewFromDML(cTaskNumber, &getPlantViewName);
				printf("\nGrp98 getPlantViewName : %s",getPlantViewName);fflush(stdout);
				tm_GetGroupFromDML(cTaskNumber, &cGroupname);
				printf("\ngroup Name :%s",cGroupname);fflush(stdout);

				GetPlantForDMLORTask( cTaskNumber ,PlantName);
				printf("\nPlantName :%s",PlantName);fflush(stdout);
				//tm_getAPLReleasedCtxt(PlantName,&cAPLRevisionRule,&cAPLClosureRule);
				tm_getSTDReleasedCtxtForCCV(PlantName,&cSTDRevisionRule,&cSTDClosureRule,&getBVR);
				printf("\nAPLRevision Rule : %s, APL Closure Rule : %s",cSTDRevisionRule,cSTDClosureRule);fflush(stdout);
				ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&t_DMLTaskRel));
				if (t_DMLTaskRel!=NULLTAG)
				{
					//tc_strcpy(FromToDR,"DR3P");
					ITKCALL(GRM_list_primary_objects_only(taskObject,t_DMLTaskRel,&dmlcount,&DMLRevision));//Get DML from task
					printf("\n\t\t APL DML Revision from Task : %d",dmlcount); fflush(stdout);
					
					for (idml=0;idml<dmlcount ;idml++ )
					{
						DMLRevTag = DMLRevision[idml];					
						ITKCALL(POM_class_of_instance(DMLRevTag,&class_id1));
						ITKCALL(POM_name_of_class(class_id1,&class_name1));
						printf("\n\t class_name found1 :%s",class_name1); fflush(stdout);

						if(tc_strcmp(class_name1,"T5_APLDMLRevision")==0)
						{
							ITKCALL(AOM_ask_value_string( DMLRevTag, "t5_rlstype", &apl_rlz_type));//TODR
							printf("\n apl_rlz_type: %s\n",apl_rlz_type);fflush(stdout);

							ITKCALL(AOM_ask_value_string( DMLRevTag, "t5_cprojectcode", &apl_proj));
							printf("\n apl_proj: %s\n",apl_proj);fflush(stdout);
						}
					}
					//return status;
				}
				if (tc_strstr(sUserInfo1,apl_proj)!=NULL)
				{
					//Fetch CCV attached with Task Reference Folder
					if (t_TaskToRef!=NULLTAG)
					{
						ITKCALL(GRM_list_secondary_objects_only(taskObject,t_TaskToRef,&pltcnt,&pltList));
						printf("\nNumber of SVRS found in Reference Item : %d",pltcnt);fflush(stdout);
						
						if (pltList>0)
						{
							for(iplt=0;iplt<pltcnt;iplt++)
							{
								t_ccvc	=	pltList[iplt];

								if (t_ccvc!=NULLTAG)
								{
									itemTypeTag_cdss	=	NULLTAG;
									type_itemRev		=	NULL;
									ITKCALL (TCTYPE_ask_object_type(t_ccvc,&itemTypeTag_cdss));
									ITKCALL (TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));
									printf("\nCCVC type_itemRev : %s",type_itemRev);fflush(stdout);

									if (tc_strcmp(type_itemRev,"VariantRule")==0)
									{
										continue;
									}
									else
									{
										//check part type is CCVC
										ITKCALL(AOM_ask_value_string(t_ccvc,"item_id",&cCCVNumber));
										ITKCALL(AOM_ask_value_string(t_ccvc,"t5_PartType",&cCCVPrttype));

										printf("\nPart Number : %s, Part type : %s ",cCCVNumber,cCCVPrttype);fflush(stdout);

										//Find SVR attached with CCVC
										t_SVRtag	=	NULLTAG;
										tm_Find_SVR_FROM_CCV(t_ccvc, &t_SVRtag);

										if (t_SVRtag!=NULLTAG)
										{
											//Find platform from SVR
											ITKCALL(AOM_ask_value_string(t_SVRtag,"object_name",&cSVRName));
											printf("\nCCV Number : %s --> SVR name : %s ",cCCVNumber,cSVRName);fflush(stdout);
											tm_Platform_From_SVR(t_SVRtag,&t_Platform);

											if(t_Platform!=NULLTAG)
											{
												//Create Snapshot logic start
												ITKCALL(AOM_ask_value_string(t_Platform,"object_type",&objecttype));
												ITKCALL(AOM_ask_value_string(t_Platform,"object_name",&objectname));

												printf("\nPlatform name : %s, Platform type : %s",objectname,objecttype);fflush(stdout);

												ITKCALL (ITEM_list_bom_views( t_Platform, &n_bom_views, &bom_views ));
												printf("\nCCV APL GM Number of Platform view : %d",n_bom_views);fflush(stdout);
												
												ITKCALL(ITEM_ask_latest_rev(t_Platform, &t_PlatformRev));
												
												if (t_PlatformRev!=NULLTAG)
												{
													ITKCALL(PS_find_view_type(getPlantViewName, &view_type));
													printf("\n PS_find_view_type is found......\n" ); fflush(stdout);

													if ( view_type != NULLTAG )
													{
														//if ( ITEM_ask_item_of_rev( t_PlatformRev, &item ));
														//if ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));
														bom_view = bom_views[0];
													}
													if (bom_view!=NULLTAG)
													{
														printf(" before BOM_create_window..\n");fflush(stdout);
														ITKCALL (BOM_create_window( &bom_window ));
														ITKCALL (CFM_find(cSTDRevisionRule,&t_revisionrule));
														ITKCALL (BOM_set_window_config_rule( bom_window, t_revisionrule));

														//API change
														ITKCALL(PIE_find_closure_rules2( cSTDClosureRule,PIE_TEAMCENTER, &rulefound, &t_closureruleList ));
														printf ("rule count %d \n",rulefound);fflush(stdout);

														if (rulefound > 0)
														{
															t_closurerule = t_closureruleList[0];
															printf ("closure rule found \n");fflush(stdout);
															// MEM_free(tags_found);
														}
														ITKCALL(BOM_window_set_closure_rule( bom_window,t_closurerule, 0, rulename,rulevalue ));

														ITKCALL(BOM_set_window_pack_all(bom_window, TRUE));
														ITKCALL(BOM_set_window_top_line( bom_window, NULLTAG, t_PlatformRev, NULLTAG, &top_line ));
														printf( " After BOM_set_window_top_line..\n");fflush(stdout);

														if (top_line!=NULLTAG)
														{
															printf("\n before inside bom_window-----\n"); fflush(stdout);
															ITKCALL(BOM_window_hide_unconfigured(bom_window));
															ITKCALL(BOM_window_show_variants(bom_window));

															VehName=(char *) MEM_alloc(30);
															printf("\n to find impacted items\n");fflush(stdout);

															ITKCALL(AOM_ask_value_string(t_SVRtag,"object_name",&childsvrname));

															printf("\nSVR Name : %s, CCV Number : %s",childsvrname,cCCVNumber);fflush(stdout);

															TempVal	=	(char	*)MEM_alloc(tc_strlen(cCCVNumber)+tc_strlen(loginuser)+tc_strlen(tmcurrenttime)+50);
															tc_strcpy(TempVal,childsvrname);
															tc_strcat(TempVal,"_");
															tc_strcat(TempVal,loginuser);
															tc_strcat(TempVal,"_");
															tc_strcat(TempVal,tmcurrenttime);
															tc_strcat(TempVal,"_GM_Snapshot");
															printf("\nSnapshot name: %s",TempVal);fflush(stdout);

															ITKCALL(BOM_window_apply_variant_configuration(bom_window,1,&t_SVRtag));
															ITKCALL(BOM_window_hide_variants(bom_window));

															ITKCALL(BOM_create_snapshot(bom_window,TempVal,"APL Snapshot for SVR",&snapshot));

															if(snapshot!=NULLTAG)
															{
																ITKCALL(AOM_save_with_extensions( snapshot) )
																ITKCALL(AOM_refresh(snapshot,1));
																ITKCALL(AOM_unlock(snapshot));
															}
															else{
																printf("\nsnapshot tag is null");fflush(stdout);
															}

															if (t_ccvc!=NULLTAG && snapshot!=NULLTAG)
															{
																if (t_CCVCHasSnapShot!=NULLTAG)
																{
																	if(GRM_create_relation(t_ccvc,snapshot,t_CCVCHasSnapShot,NULLTAG,&Rel_task));
																	if(GRM_save_relation(Rel_task));
																	printf("\nRelation is created successfully with CCVC");fflush(stdout);
																}
																else
																{
																	printf("\nt_CCVCHasSnapShot relation is nulltag");fflush(stdout);
																}
															}
															else
															{
																printf("\neither ccvc is nulltag ot snapshot is nulltag");fflush(stdout);
															}

														}
														else
														{
															printf("\ntop_line is NULLTAG");fflush(stdout);
														}

													}
													else
													{
														printf("\nbom_view is NULLTAG");fflush(stdout);
													}

												}
												else
												{
													printf("\nt_PlatformRev is NULLTAG...");fflush(stdout);
												}
											}
											else
											{
												printf("\nt_Platform is NULLTAG");fflush(stdout);
											}
										}
										else
										{
											printf("\nt_SVRtag is NULLTAG");fflush(stdout);
										}

									}
								}
								else
								{
									printf("\nt_ccvc is null tag");fflush(stdout);
								}
							}
						}
						else
						{
							printf("\nNo parts attached in reference folder");fflush(stdout);
						}
					}
					else
					{
						printf("\nReference tag is nulltag");fflush(stdout);
					}
				}
				else
				{
					printf("\nproject not found in control object STDCCVGMCreate");fflush(stdout);
				}
			}
			else
			{
				printf("\nitem type is not T5_APLTaskRevision");fflush(stdout);
			}
		}
		else
		{
			printf("\nAPLCCVGMDML control object not found");fflush(stdout);
		}

	}
	else
	{
		printf("\nControl object query tag is NULLTAG");fflush(stdout);
	}

	return status;
}

//CCV GATE MATURATION CHECKS
int tm_CCV_GMDML_DR_Check_STD(tag_t t_tasktag,char	***SetChildRelErr,int *icount)
{
	int	status;
	
	int		pltcnt					=	0;
	int		iplt					=	0;
	int		n_bom_views				=	0;
	int 	rulefound				= 	0;
	int 	n_count					= 	0;
	int 	archcnt					= 	0;
	int 	ichld					= 	0;
	int 	chldcnt					= 	0;
	int 	iChildItemTag			= 	0;
	int 	dmlcount				= 	0;
	int 	idml					= 	0;
	int 	ivlddr					= 	0;
	
	char	cCurrentAccessDate[20]={0};
	char	PlantName[40];
	
	char	*loginuser				=	NULL;
	char	*cTaskNumber			=	NULL;
	char	*type_itemRev			=	NULL;
	char	*cSTDClosureRule		=	NULL;
	cSTDClosureRule = (char *)MEM_alloc(1 * sizeof(char *));
	char	*cSTDRevisionRule		=	NULL;
	char	*objecttype				=	NULL;
	char	*objectname				=	NULL;
	char	*CCVNumber				=	NULL;
	char	*CCVParttype			=	NULL;
	char	*cSVRName				=	NULL;
	char	*Archtype_name			=	NULL;
	char	*arch_item_id			=	NULL;
	char	*ModPartNo				=	NULL;
	char	*item_Rev_Seq			=	NULL;
	char	*moduleNumber			=	NULL;
	char	*item_Rev_PrtType		=	NULL;
	char	*item_Rev_DRStatus		=	NULL;
	char	*apl_dr_status			=	NULL;
	char	*ErrString				=	NULL;
	char	*FromToDR 				=	NULL;
	char	*ToDR 					=	NULL;
	char	*apl_rlz_type			=	NULL;
	char	*class_name1			=	NULL;
	char	*getBVR					=	NULL;
	char	*getPlantViewName		=	NULL;
	char	*cGroupname				=	NULL;
	char	*apl_proj				=	NULL;
	char	*sUserInfo1				=	NULL;
	
	char	**rulename				=	NULL;
	char	**rulevalue				=	NULL;
	
	char 	LcsSTDWrkg[40];
	char 	LcsSTDRlzd[40];
	
	tag_t	t_TaskToRef				=	NULLTAG;
	tag_t	t_DMLTaskRel			=	NULLTAG;
	tag_t	t_CCVCHasSnapShot		=	NULLTAG;
	tag_t	itemTypeTag_cdss		=	NULLTAG;
	tag_t	t_CCVTag				=	NULLTAG;
	tag_t 	t_SVRtag				=	NULLTAG;
	tag_t 	t_Platform				=	NULLTAG;
	tag_t 	item					=	NULLTAG;
	tag_t 	bom_view				=	NULLTAG;
	tag_t	bom_window				=	NULLTAG;
	tag_t	t_revisionrule			=	NULLTAG;
	tag_t	t_closurerule			=	NULLTAG;
	//API change
	tag_t   *bom_variant_rule		=	NULLTAG;
	int p_count = 0;
	//tag_t   bom_variant_rule		=	NULLTAG;
	tag_t   objTypeTag1				=	NULLTAG;
	tag_t   top_line				=	NULLTAG;
	tag_t   t_PlatformRev			=	NULLTAG;
	tag_t   t_archnode				=	NULLTAG;
	tag_t   PartChildobj			=	NULLTAG;
	tag_t   t_ChildItemRev			=	NULLTAG;
	tag_t   DMLRevTag				=	NULLTAG;
	tag_t	class_id1				=	NULLTAG;
	
	tag_t	*pltList				=	NULLTAG;
	tag_t	*bom_views				=	NULLTAG;
	tag_t	*t_closureruleList		=	NULLTAG;
	tag_t	*ArchNodeLines			=	NULLTAG;
	tag_t	*archList				=	NULLTAG;
	tag_t	*childTags				=	NULLTAG;
	tag_t	*DMLRevision			=	NULLTAG;
	
	printf("\nInside tm_CCV_GMDML_DR_Check_APL");fflush(stdout);
	
	POM_get_user_id(&loginuser);
	printf("\nStarting for taskbreskdownnn :%s....\n",loginuser);fflush(stdout);
	getCurrentDateTime(cCurrentAccessDate);
	printf("\n Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_tasktag,"item_id",&cTaskNumber));
	printf("\t  cTaskNumber ...%s\n", cTaskNumber);fflush(stdout);
	
	ITKCALL (TCTYPE_ask_object_type(t_tasktag,&itemTypeTag_cdss));
	ITKCALL (TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));
	printf("\nGrp 98 type_itemRev : %s",type_itemRev);fflush(stdout);
	
	ITKCALL(GRM_find_relation_type("CMReferences",&t_TaskToRef));//Reference Items
	ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&t_DMLTaskRel));//DML TASK RELATION
	ITKCALL(GRM_find_relation_type("T5_PartHasAPLSnapShot",&t_CCVCHasSnapShot));//Part Has APLC Snap Shot
	
	char    *qry_entryCntrl1[3]  	= 	{"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1		= 	(char **) MEM_alloc(5 * sizeof(char *));
	tag_t	qryTagCntrl1			=	NULLTAG;
	int     n_entryCntrl1    		= 	3;
	int		control_number_found	=	0;
	tag_t	*list_of_WSO_cntrl_tags	=	NULLTAG;
	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	
	if(qryTagCntrl1!=NULLTAG)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="STDCCVGMDML";
		qry_valuesCntrl1[1]="STDCCVGMDML";;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found, &list_of_WSO_cntrl_tags));
		printf("\ncreateSnapShot_APL No. of control object found : %d",control_number_found);fflush(stdout);
		
		if(control_number_found>0)
		{
			AOM_ask_value_string( list_of_WSO_cntrl_tags[0], "t5_Userinfo1", &sUserInfo1);
			printf("\n sUserInfo1: %s\n",sUserInfo1);fflush(stdout);

			if (tc_strcmp(type_itemRev,"T5_APLTaskRevision")==0)
			{
				//Revision Rule and other code pending
				getPlantViewName=NULL;
				tm_GetViewFromDML(cTaskNumber, &getPlantViewName);
				printf("\nCCV STD getPlantViewName : %s",getPlantViewName);fflush(stdout);
				tm_GetGroupFromDML(cTaskNumber, &cGroupname);
				printf("\nCCV STD group Name :%s",cGroupname);fflush(stdout);
						
				GetPlantForDMLORTask( cTaskNumber ,PlantName);
				printf("\nCCV STD PlantName :%s",PlantName);fflush(stdout);
				tm_getSTDReleasedCtxtForCCV(PlantName,&cSTDRevisionRule,&cSTDClosureRule,&getBVR);
				printf("\nCCV STD STDRevision Rule : %s, STD Closure Rule : %s",cSTDRevisionRule,cSTDRevisionRule);fflush(stdout);
						
				GetPlantWiseRelStat(cTaskNumber,LcsSTDWrkg,LcsSTDRlzd);
				printf("\n LcsSTDWrkg: %s \n",LcsSTDWrkg);
				printf("\n LcsSTDRlzd: %s \n",LcsSTDRlzd);
			
				if (t_DMLTaskRel!=NULLTAG)
				{
					FromToDR =	NULL;
					FromToDR =	(char*)MEM_alloc(20);
					//tc_strcpy(FromToDR,"DR3P");
					ITKCALL(GRM_list_primary_objects_only(t_tasktag,t_DMLTaskRel,&dmlcount,&DMLRevision));//Get DML from task
					printf("\n\t\t APL DML Revision from Task : %d",dmlcount); fflush(stdout);
					
					for (idml=0;idml<dmlcount ;idml++ )
					{
						DMLRevTag = DMLRevision[idml];					
						ITKCALL(POM_class_of_instance(DMLRevTag,&class_id1));
						ITKCALL(POM_name_of_class(class_id1,&class_name1));
						printf("\n\t class_name found1 :%s",class_name1); fflush(stdout);

						if(tc_strcmp(class_name1,"T5_APLDMLRevision")==0)
						{
							ITKCALL(AOM_ask_value_string( DMLRevTag, "t5_rlstype", &apl_rlz_type));//TODR
							printf("\n apl_rlz_type: %s\n",apl_rlz_type);fflush(stdout);

							ITKCALL(AOM_ask_value_string( DMLRevTag, "t5_cprojectcode", &apl_proj));
							printf("\n apl_proj: %s\n",apl_proj);fflush(stdout);

							if(tc_strcmp(apl_rlz_type,"TODR")==0)
							{
								printf("\nAPL Release type Gate Maturation Found...");fflush(stdout);
								ITKCALL(AOM_ask_value_string( DMLRevTag, "t5_PlntToPlnt", &apl_dr_status));//TODR
								printf("\n apl_dr_status: %s\n",apl_dr_status);fflush(stdout);
								tc_strcpy(FromToDR,apl_dr_status);
								
								char	*temp	=	NULL;
								char	*temp1	=	NULL;
								temp	=	strtok(FromToDR," ");
								temp1	=	strtok(NULL," ");
								printf("\n temp : %s\n",temp);fflush(stdout);
								ToDR	=	strtok(NULL," ");
								
								printf("\n ToDR : %s\n",ToDR);fflush(stdout);
							}
						}
					}
					//return status;
				}
				if (tc_strstr(sUserInfo1,apl_proj)!=NULL)
				{
					if (t_TaskToRef!=NULLTAG)
					{
						ITKCALL(GRM_list_secondary_objects_only(t_tasktag,t_TaskToRef,&pltcnt,&pltList));
						printf("\nNumber of SVRS found in Reference Item : %d",pltcnt);fflush(stdout);
						
						if(pltcnt>0)
						{
							//Find the CCV Part attach with reference item.
							//Find the SVR attached with CCV(Derived From SVR Relation).
							//Find the Platform from  SVR.
							for(iplt=0;iplt<pltcnt;iplt++)
							{
								t_CCVTag	=	pltList[iplt];
								if(AOM_ask_value_string(t_CCVTag,"object_type",&objecttype));
								if(AOM_ask_value_string(t_CCVTag,"object_name",&objectname));
								printf("\nObject_type : %s, Object_name : %s",objecttype,objectname);fflush(stdout);
								
								if(tc_strcmp(objecttype,"VariantRule")==0)
								{
									continue;
								}
								else if(tc_strcmp(objecttype,"Design Revision")==0)
								{
									printf("\nCCV GM APL Design Revision Found...");fflush(stdout);
									
									//check part type is CCV or nor
									//Other than CCV part should be bypassed
									ITKCALL(AOM_ask_value_string(t_CCVTag, "item_id", &CCVNumber ));
									printf("\n CCVNumber --> : %s\n",CCVNumber); fflush(stdout);
									
									ITKCALL(AOM_ask_value_string(t_CCVTag, "t5_PartType", &CCVParttype ));
									printf("\n CCVParttype --> : %s\n",CCVParttype); fflush(stdout);
									
									if(tc_strcmp(CCVParttype,"CCVC")==0)
									{
										//Find the SVR attached with CCVC
										t_SVRtag	=	NULLTAG;
										tm_Find_SVR_FROM_CCV(t_CCVTag, &t_SVRtag);
										if(t_SVRtag!=NULLTAG)
										{
											if(AOM_ask_value_string(t_SVRtag,"object_name",&cSVRName));
											printf("\nCCV Number : %s --> SVR name : %s ",CCVNumber,cSVRName);fflush(stdout);
											//Find Platform from SVR
											tm_Platform_From_SVR(t_SVRtag,&t_Platform);
											if(t_Platform!=NULLTAG)
											{
												//Create the BOM Window and do the 2 level explosion
												
												if (ITEM_ask_item_of_rev( t_Platform, &item ));
												if(item!=NULLTAG)
												{
													printf("\nItem is not null Tag");fflush(stdout);
												}
												else{
													printf("\nItem is null Tag");fflush(stdout);
												}
												//if (ITEM_list_bom_views( item, &n_bom_views, &bom_views ));
												if (ITEM_list_bom_views( t_Platform, &n_bom_views, &bom_views ));
												printf("\nCCV APL GM Number of Platform view : %d",n_bom_views);fflush(stdout);
												
												ITKCALL(ITEM_ask_latest_rev(t_Platform, &t_PlatformRev));
												if(n_bom_views>0)
												{
													bom_view	=	bom_views[0];
													if(bom_view!=NULLTAG)
													{
														//Create BOM Window
														bom_window		=	NULLTAG;
														t_revisionrule	=	NULLTAG;
														printf(" before BOM_create_window..\n");fflush(stdout);
														if (BOM_create_window( &bom_window ));
														if (CFM_find(cSTDRevisionRule,&t_revisionrule));
														if (BOM_set_window_config_rule( bom_window, t_revisionrule));
														
														rulefound			=	0;
														t_closureruleList	=	NULLTAG;
														//if(PIE_find_closure_rules( cAPLClosureRule,PIE_TEAMCENTER, &rulefound, &t_closureruleList ));
														//API change
														if(PIE_find_closure_rules2(cSTDClosureRule,PIE_TEAMCENTER, &rulefound, &t_closureruleList ));
														printf ("rule count %d \n",rulefound);fflush(stdout);
														
														if (rulefound > 0)
														{
															t_closurerule = t_closureruleList[0];
															printf ("closure rule found \n"); fflush(stdout);
														}
														
														top_line	=	NULLTAG;
														
														ITKCALL(BOM_window_set_closure_rule( bom_window,t_closurerule, 0, rulename,rulevalue ));
														ITKCALL(BOM_set_window_pack_all(bom_window, FALSE));
														ITKCALL(BOM_set_window_top_line( bom_window, NULLTAG, t_PlatformRev, NULLTAG, &top_line ));

														//API change "BOM_window_ask_variant_rule" used twice comment one of them

														//ITKCALL(BOM_window_ask_variant_rule( bom_window, &bom_variant_rule ));
														
														//ITKCALL(BOM_window_ask_variant_rule( bom_window, &bom_variant_rule ));

														ITKCALL(BOM_window_ask_variant_rules( bom_window,&p_count, &bom_variant_rule ));
											
														ITKCALL(TCTYPE_ask_object_type(bom_variant_rule[0],&objTypeTag1));
														ITKCALL(TCTYPE_ask_name2(objTypeTag1,&Archtype_name));
														printf("\n Archtype_name------> %s\n",Archtype_name);fflush(stdout);
														
														if(top_line!=NULLTAG)
														{
															n_count	=	0;
															ArchNodeLines	=	0;
															ITKCALL(BOM_line_ask_child_lines(top_line, &n_count, &ArchNodeLines));
															printf("\n n_count --------> : %d\n", n_count);
															
															ITKCALL(BOM_window_hide_unconfigured(bom_window));
															ITKCALL(BOM_window_show_variants(bom_window));
															ITKCALL(BOM_window_apply_variant_configuration(bom_window,1,&t_SVRtag));
															ITKCALL(BOM_window_hide_variants(bom_window));
															
															archcnt	=	0;
															archList	=	NULLTAG;
															ITKCALL(BOM_line_ask_child_lines(top_line, &archcnt, &archList));
															printf("\nNumber of Arch node found : %d",archcnt);fflush(stdout);
															
															if (archcnt >0)
															{
																for (ichld=0;ichld<archcnt ;ichld++ )
																{
																	t_archnode	=	NULLTAG;
																	t_archnode	=	archList[ichld];
																	arch_item_id	=	NULL;
																	if(AOM_ask_value_string(t_archnode,"bl_item_item_id",&arch_item_id));
																	printf("\nArch Node number : %s",arch_item_id);fflush(stdout);
																	
																	childTags=NULLTAG;
																	chldcnt	=	0;
																	ITKCALL(BOM_line_ask_child_lines(t_archnode, &chldcnt, &childTags));
																	printf("\n Child parts count--> %d\n",chldcnt);fflush(stdout);
																	
																	if(chldcnt==1)
																	{
																		if(PartChildobj) PartChildobj=NULLTAG;
																		if(ModPartNo) ModPartNo=NULL;
																		if(item_Rev_Seq) item_Rev_Seq=NULL;
																		PartChildobj=childTags[0];
																		
																		ITKCALL(AOM_ask_value_string(PartChildobj, "bl_item_item_id", &ModPartNo ));
																		printf("\n No of Modules Under Architechtures --> : %s\n",ModPartNo); fflush(stdout);
																			
																		ITKCALL(AOM_ask_value_string(PartChildobj, "bl_rev_item_revision_id", &item_Rev_Seq));
																		printf("\n item_Rev_Seq --> : %s\n",item_Rev_Seq); fflush(stdout);
																		
																		iChildItemTag=0;
																		t_ChildItemRev=NULLTAG;
																		//API change
																		//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
																		//BOM_line_ask_attribute_tag(PartChildobj, iChildItemTag, &t_ChildItemRev);

																		AOM_ask_value_tag (PartChildobj,bomAttr_lineItemRevTag, &t_ChildItemRev);
																		
																		tag_t	objTypeTag	=	NULLTAG;
																		char	*type_name	=	NULL;
																		if(TCTYPE_ask_object_type(t_ChildItemRev,&objTypeTag));
																		if(TCTYPE_ask_name2(objTypeTag,&type_name));
																		printf("\nChild part type : %s",type_name);fflush(stdout);
																		
																		item_Rev_PrtType	=	NULL;
																		ITKCALL(AOM_ask_value_string(t_ChildItemRev, "t5_PartType", &item_Rev_PrtType));
																		printf("\n item_Rev_PrtType --> : %s\n",item_Rev_PrtType); fflush(stdout);
																		
																		item_Rev_DRStatus	=	NULL;
																		ITKCALL(AOM_ask_value_string(t_ChildItemRev, "t5_PartStatus", &item_Rev_DRStatus));
																		printf("\n item_Rev_Seq --> : %s, DML DR : %s\n",item_Rev_DRStatus,ToDR); fflush(stdout);
																		
																		//DR Status check
																		if(tc_strcmp(item_Rev_PrtType,"D")==0 || tc_strcmp(item_Rev_PrtType,"DA")==0 || tc_strcmp(item_Rev_PrtType,"DC")==0 || tc_strcmp(item_Rev_PrtType,"IFD")==0 || tc_strcmp(item_Rev_PrtType,"IM")==0)
																		{
																			printf("\nDummy Module, so bypass");fflush(stdout);
																			continue;
																		}
																	}
																	else if(chldcnt>1)
																	{
																		int imulti	=	0;
																		int imod	=	0;
																		char	*tmpPartNum	=	NULL;
																		
																		for (imod=0;imod<chldcnt;imod++)
																		{
																			moduleNumber	=	NULL;
																			ITKCALL(AOM_ask_value_string(childTags[imod],"bl_item_item_id",&moduleNumber));
																			printf("\t  moduleNumber ...%s\n", moduleNumber);fflush(stdout);
																			
																			if (imod==0)
																			{
																				tmpPartNum	=	NULL;
																				tmpPartNum	=	(char*)MEM_alloc(tc_strlen(moduleNumber)+2);
																				tc_strcpy(tmpPartNum,moduleNumber);
																				printf("\nTemp Module Number : %s",tmpPartNum);fflush(stdout);
																			}
																			else
																			{
																				if(tc_strcmp(tmpPartNum,moduleNumber)!=0)
																				{
																					imulti++;
																				}
																				else
																				{
																					printf("\nP	art Number are same %s",moduleNumber);fflush(stdout);
																				}
																			}
																		}
																		
																		if(imulti>0)
																		{
																			printf("\nMore than one Module solve");fflush(stdout);
																			ErrString	=	NULL;
																			ErrString	=	(char	*)MEM_alloc(300);
																			tc_strcpy(ErrString,"More than one module solved in Architecture Node ");
																			tc_strcat(ErrString,arch_item_id);
																			tc_strcat(ErrString," After SVR ");
																			tc_strcat(ErrString,objectname);
																			tc_strcat(ErrString," applied on platform.\n");
																			setAddStrFuction(icount,SetChildRelErr,ErrString);
																		}
																		else
																		{
																			if(PartChildobj) PartChildobj=NULLTAG;
																			if(ModPartNo) ModPartNo=NULL;
																			if(item_Rev_Seq) item_Rev_Seq=NULL;
																			PartChildobj=childTags[0];
																			
																			ITKCALL(AOM_ask_value_string(PartChildobj, "bl_item_item_id", &ModPartNo ));
																			printf("\nmul No of Modules Under Architechtures --> : %s\n",ModPartNo); fflush(stdout);
																					
																			ITKCALL(AOM_ask_value_string(PartChildobj, "bl_rev_item_revision_id", &item_Rev_Seq));
																			printf("\nmul item_Rev_Seq --> : %s\n",item_Rev_Seq); fflush(stdout);

																			iChildItemTag=0;
																			t_ChildItemRev=NULLTAG;
																			//API change
																			//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
																			//BOM_line_ask_attribute_tag(PartChildobj, iChildItemTag, &t_ChildItemRev);

																			AOM_ask_value_tag (PartChildobj,bomAttr_lineItemRevTag, &t_ChildItemRev);
																			
																			tag_t	objTypeTag	=	NULLTAG;
																			char	*type_name	=	NULL;
																			if(TCTYPE_ask_object_type(t_ChildItemRev,&objTypeTag));
																			if(TCTYPE_ask_name2(objTypeTag,&type_name));
																			printf("\n More than Child part type : %s",type_name);fflush(stdout);
																			
																			item_Rev_PrtType	=	NULL;
																			ITKCALL(AOM_ask_value_string(t_ChildItemRev, "t5_PartType", &item_Rev_PrtType));
																			printf("\n item_Rev_PrtType --> : %s\n",item_Rev_PrtType); fflush(stdout);
																			
																			item_Rev_DRStatus	=	NULL;
																			ITKCALL(AOM_ask_value_string(t_ChildItemRev, "t5_PartStatus", &item_Rev_DRStatus));
																			printf("\n item_Rev_Seq --> : %s, DML DR : %s\n",item_Rev_DRStatus,ToDR); fflush(stdout);
																			
																			if(tc_strcmp(item_Rev_PrtType,"D")==0 || tc_strcmp(item_Rev_PrtType,"DA")==0 || tc_strcmp(item_Rev_PrtType,"DC")==0 || tc_strcmp(item_Rev_PrtType,"IFD")==0 || tc_strcmp(item_Rev_PrtType,"IM")==0)
																			{
																				printf("\nDummy Module, so bypass");fflush(stdout);
																				continue;
																			}
																		}
																	}
																	else{
																		printf("\nNO Part found under module");fflush(stdout);
																	}
																	
																	//Query the part APL Release and above and check any revision validate the DML DR Gate
																	{
																		ivlddr	=	0;
																		if(item_Rev_DRStatus!=NULL && ToDR!=NULL)//DR GATE validation start
																		{
																			tag_t	queryPart	=	NULLTAG;
																			int		n_entries	=	2;
																			int    	num_to_sort =	1;
																			char 	*keys[1] 	= 	{"creation_date"};
																			int  	orders[1]  	=	{2};
																			int		n_found		=	0;
																			tag_t   *results	=	NULL;
																			char 	*qry_part_entries[2] = {"Item ID","Release Status"};
																			char 	*qry_part_values[2] = {"*",LcsSTDRlzd};
																			ITKCALL(QRY_find2("Item Revision...", &queryPart));
																			qry_part_values[0]=	ModPartNo;
																			
																			QRY_execute_with_sort(queryPart, n_entries, qry_part_entries, qry_part_values, num_to_sort, keys, orders, &n_found, &results);
																			printf("\nNo of APL Release Part %s found : %d",ModPartNo,n_found);fflush(stdout);
																			
																			printf("\nInside item_Rev_Seq --> : %s, DML DR : %s\n",item_Rev_DRStatus,ToDR); fflush(stdout);
																			if(n_found>0)
																			{
																				int	iipr	=	0;
																				for(iipr=0;iipr<n_found;iipr++)
																				{
																					tag_t	t_APLPart	=	NULLTAG;
																					char	*cAPLDR		=	NULL;
																					t_APLPart	=	results[iipr];
																					ITKCALL(AOM_ask_value_string(t_APLPart, "t5_PartStatus", &cAPLDR));
																					printf("\n cAPLDR --> : %s\n",cAPLDR); fflush(stdout);
																					
																					if((tc_strcmp(ToDR,"DR5")==0 || tc_strcmp(ToDR,"AR5")==0) && (tc_strcmp(cAPLDR,"DR5")==0 || tc_strcmp(cAPLDR,"AR5")==0))
																					{
																						ivlddr++;
																						break;
																					}
																					if((tc_strcmp(ToDR,"DR4")==0 || tc_strcmp(ToDR,"AR4")==0) && (tc_strcmp(cAPLDR,"DR5")==0 || tc_strcmp(cAPLDR,"AR5")==0 || tc_strcmp(cAPLDR,"DR4")==0 || tc_strcmp(cAPLDR,"AR4")==0))
																					{
																						ivlddr++;
																						break;
																					}
																					if((tc_strcmp(ToDR,"DR3P")==0 || tc_strcmp(ToDR,"AR3P")==0) && (tc_strcmp(cAPLDR,"DR5")==0 || tc_strcmp(cAPLDR,"AR5")==0 || tc_strcmp(cAPLDR,"DR4")==0 || tc_strcmp(cAPLDR,"AR4")==0 || tc_strcmp(cAPLDR,"DR3P")==0 || tc_strcmp(cAPLDR,"AR3P")==0))
																					{
																						ivlddr++;
																						break;
																					}
																					if((tc_strcmp(ToDR,"DR3")==0 || tc_strcmp(ToDR,"AR3")==0) && (tc_strcmp(cAPLDR,"DR5")==0 || tc_strcmp(cAPLDR,"AR5")==0 || tc_strcmp(cAPLDR,"DR4")==0 || tc_strcmp(cAPLDR,"AR4")==0 || tc_strcmp(cAPLDR,"DR3P")==0 || tc_strcmp(cAPLDR,"AR3P")==0 || tc_strcmp(cAPLDR,"DR3")==0 || tc_strcmp(cAPLDR,"AR3")==0))
																					{
																						ivlddr++;
																						break;
																					}
																					if((tc_strcmp(ToDR,"DR2")==0 || tc_strcmp(ToDR,"AR2")==0) && (tc_strcmp(cAPLDR,"DR5")==0 || tc_strcmp(cAPLDR,"AR5")==0 || tc_strcmp(cAPLDR,"DR4")==0 || tc_strcmp(cAPLDR,"AR4")==0 || tc_strcmp(cAPLDR,"DR3P")==0 || tc_strcmp(cAPLDR,"AR3P")==0 || tc_strcmp(cAPLDR,"DR3")==0 || tc_strcmp(cAPLDR,"AR3")==0 || tc_strcmp(cAPLDR,"DR2")==0 || tc_strcmp(cAPLDR,"AR2")==0))
																					{
																						ivlddr++;
																						break;
																					}
																					if((tc_strcmp(ToDR,"DR1")==0 || tc_strcmp(ToDR,"AR1")==0) && (tc_strcmp(cAPLDR,"DR5")==0 || tc_strcmp(cAPLDR,"AR5")==0 || tc_strcmp(cAPLDR,"DR4")==0 || tc_strcmp(cAPLDR,"AR4")==0 || tc_strcmp(cAPLDR,"DR3P")==0 || tc_strcmp(cAPLDR,"AR3P")==0 || tc_strcmp(cAPLDR,"DR3")==0 || tc_strcmp(cAPLDR,"AR3")==0 || tc_strcmp(cAPLDR,"DR2")==0 || tc_strcmp(cAPLDR,"AR2")==0 || tc_strcmp(cAPLDR,"DR1")==0 || tc_strcmp(cAPLDR,"AR1")==0))																	
																					{
																						ivlddr++;
																						break;
																					}
																				}
																			}
																			else{
																				printf("\nPart Number %s No Revision released from STDSI",ModPartNo);fflush(stdout);
																			}
																		}
																		
																		if(ivlddr==0 && chldcnt >0)
																		{
																			ErrString	=	NULL;
																			ErrString	=	(char	*)MEM_alloc(300);
																			tc_strcpy(ErrString,"No Revision Of Part Number ");
																			tc_strcat(ErrString, ModPartNo);
																			tc_strcat(ErrString," having DR Status ");
																			tc_strcat(ErrString,", equal or higher DR status of DML ");
																			tc_strcat(ErrString,ToDR);
																			tc_strcat(ErrString,"\n");
																			setAddStrFuction(icount,SetChildRelErr,ErrString);
																		}
																	}
																}
															}
														}
													}
													else{
														printf("\nCCV GM AT APL BOM_VIEW IS NULLTAG");fflush(stdout);
													}
												}
												else{
													printf("\n Platform found NO view, so not proceed...");fflush(stdout);
												}
												
											}
											else{
												printf("\n t_Platform is NULLTAG, so not proceed...");fflush(stdout);
											}
										}
										else{
											printf("\nSVR IS NULLTAG");fflush(stdout);
										}
										
									}
									else{
										printf("\nPart type is not CCVC");fflush(stdout);
									}
								}
								else{
									printf("\nPart type is neither variant rule nor Design Revision");fflush(stdout);
									continue;
								}
							}//end of iplt loop.
							
						}
						else{
							printf("\nCCV APL GM  Zero Part attached with Reference Items");fflush(stdout);
						}
					}
				}
				else
				{
					printf("\nProject code not foud in control object STDCCVGMDML");fflush(stdout);
				}
			}
			else{
				printf("CCV STD GM Object type is not APL Task Revision");fflush(stdout);
			}
		}
	}
	else{
		printf("\nSTD GM DML qryTagCntrl1 not found...");fflush(stdout);
	}
	
	return status;
}


//venkat start
int std_dml_task_default_group( EPM_action_message_t msg )
{
    int error_code				 = ITK_ok;
    int ifail					 = 0;
    int noAttachment			 = 0;
    int DefaultPlannerflag		 = 0;
    int count					 = 0;
    int TaskCnt					 = 0;
    char *CurrentTask			 = NULL;
    char *parent_name			 = NULL;
    char *Aplreviwergroup		 = NULL;
    char *Aplplannergroup		 = NULL;
    char *DisAplplannergroup	 = NULL;
    char *DisAplreviwergroup	 = NULL;
    char *item_id				 = NULL;
    char *DML_no				 = NULL;
    char *type_name				 = NULL;

    tag_t rootTask				 = NULLTAG;
    tag_t *attachments			 = NULLTAG;
    tag_t *TaskRevision			 = NULLTAG;
    tag_t dml_rev_tag			 = NULLTAG;
    tag_t objTypeTag			 = NULLTAG;
    tag_t relation_type			 = NULLTAG;
    tag_t qryTagCntrl			 = NULLTAG;
    tag_t *Dflt_grp_cntrl_tags	 = NULLTAG;

    char *Plantname				 = NULL;
    char *group					 = NULL;
    char *planner				 = NULL;
    char *Department			 = NULL;
    char *plannerplant			 = NULL;
    char *info1					 = NULL;
    char *info2					 = NULL;

    int DefaultGrpflag			 = 0;
    int control_number_found	 = 0;
    int n_entrycoCntrl			 = 3;

	char *qry_dlt_grp_entryCntrl[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
    char **qry_dlt_grp_valuesCntrl = (char **)MEM_alloc(5 * sizeof(char *));

	tag_t tTask	= msg.task;

    printf("\n **************inside std_dml_default_group***************\n ");fflush(stdout);

    fflush(stdout);

    ITKCALL(EPM_ask_root_task(msg.task, &rootTask));
    printf("\n STD_dml_task_assigment \n");
    fflush(stdout);

    ITKCALL(AOM_ask_value_string(msg.task, "object_name", &CurrentTask));
    printf("\nCurrentTask:%s\n", CurrentTask);
    ITKCALL(AOM_ask_value_string(rootTask, "object_name", &parent_name));
    printf("\nParent Name:%s\n", parent_name);
    fflush(stdout);
    ITKCALL(EPM_ask_attachments(rootTask, EPM_target_attachment, &noAttachment, &attachments));
    printf("Target Attachment:%d\n", noAttachment);
    fflush(stdout);

	if (QRY_find2("Control Objects...", &qryTagCntrl));
       
    if (qryTagCntrl)
    {
        printf("\nDefault group Control Object Query Found \n");
        fflush(stdout);
        qry_dlt_grp_valuesCntrl[0] = "StdPlannerandReviewer";
        qry_dlt_grp_valuesCntrl[1] = "DefaultGroup";

        qry_dlt_grp_valuesCntrl[2] = "0";

        if (QRY_execute(qryTagCntrl, n_entrycoCntrl, qry_dlt_grp_entryCntrl, qry_dlt_grp_valuesCntrl, &control_number_found, &Dflt_grp_cntrl_tags));
            
    }
    printf("\nNo of control object found for default group:%d\n", control_number_found);
    fflush(stdout);

    if (control_number_found > 0)
    {

		ITKCALL(AOM_ask_value_string(Dflt_grp_cntrl_tags[0],"t5_Userinfo1",&info1));
		ITKCALL(AOM_ask_value_string(Dflt_grp_cntrl_tags[0],"t5_Userinfo2",&info2));
		printf("\n STD lannerandReviewer info1: %s",info1);fflush(stdout);
		printf("\n STD lannerandReviewer info2: %s",info2);fflush(stdout);

		if (noAttachment > 0)
		{
			dml_rev_tag = attachments[0];
			if (TCTYPE_ask_object_type(dml_rev_tag, &objTypeTag))
				;
			if (TCTYPE_ask_name2(objTypeTag, &type_name))
				;
			printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);
			fflush(stdout);
		}

		//if (tc_strcmp(CurrentTask,"Is_Default_Grp_chk")==0)
		if (tc_strstr(CurrentTask,info1)!=NULL)
		{
			printf("\n **************inside std_dml_default_group and task is  Is_Default_Grp_chk***************\n ");
				fflush(stdout);

				ITKCALL(AOM_ask_value_string(dml_rev_tag, "item_id", &item_id));
				ITKCALL(AOM_ask_value_string(dml_rev_tag, "current_id", &DML_no));
				printf("\n\n\t\t current task item id  %s: %s", item_id, DML_no);
				fflush(stdout);
				if (dml_rev_tag != NULLTAG)
				{


					tag_t	relation_type	= NULLTAG;
					tag_t*	AnaPart_objects	= NULLTAG;
					int		anaPart_cnt	= 0;
					int		anaCngptcnt = 0;

					char*	tcParobject_name	= NULL;
					char*	ChangeDMUReviewr	= NULL;
					char*	AnaDgnReviewr	= NULL;
					char*	anlstDsngrReviewGrp	= NULL;
					tag_t	ObjTypDmlCRB	= NULLTAG;

					ITKCALL(GRM_find_relation_type("HasParticipant", &relation_type));
					ITKCALL(GRM_list_secondary_objects_only(dml_rev_tag, relation_type, &anaPart_cnt, &AnaPart_objects));
					printf("\n Venkat partcipant_cnt : [%d]\n",anaPart_cnt);fflush(stdout);
					if (anaPart_cnt > 0)
					{
						for (anaCngptcnt= 0; anaCngptcnt<anaPart_cnt;anaCngptcnt++ )
						{
							
							tcParobject_name	= NULL;
							AnaDgnReviewr		= NULL;
							anlstDsngrReviewGrp	= NULL;
							ObjTypDmlCRB		= NULLTAG;
							

							ITKCALL(TCTYPE_ask_object_type(AnaPart_objects[anaCngptcnt],&ObjTypDmlCRB));
						
							
							ITKCALL( TCTYPE_ask_name2	(ObjTypDmlCRB,&tcParobject_name));
							
							printf("\n\n\t\t tcParobject_name :   %s\n",tcParobject_name);
							fflush(stdout);
							if (tc_strcmp(tcParobject_name,"Analyst")==0)
							{
							
								ITKCALL(AOM_UIF_ask_value(AnaPart_objects[anaCngptcnt],"fnd0AssigneeUser",&AnaDgnReviewr));
								ITKCALL(AOM_UIF_ask_value(AnaPart_objects[anaCngptcnt],"assignee",&Aplplannergroup));
								printf("\n TASK: Analyst: [%s] Group: [%s] ",AnaDgnReviewr,Aplplannergroup);fflush(stdout);
								if (tc_strstr(Aplplannergroup, "Default") != NULL)
								{
									printf("\nplanner DefultGroup has been found");
									fflush(stdout);
									DefaultGrpflag++;
									break;
									
								}
								
							}
							else
							{

								printf("\n inside else : ChangeSpecialist1:\n");fflush(stdout);
								if (tc_strcmp(tcParobject_name,"ChangeSpecialist1")==0)
								{
								
									ITKCALL(AOM_UIF_ask_value(AnaPart_objects[anaCngptcnt],"fnd0AssigneeUser",&ChangeDMUReviewr));
									ITKCALL(AOM_UIF_ask_value(AnaPart_objects[anaCngptcnt],"assignee",&Aplreviwergroup));
									printf("\n TASK: DMU Reviewer: [%s] Group: [%s] ",ChangeDMUReviewr,Aplreviwergroup);fflush(stdout);
									if (tc_strstr(Aplreviwergroup, "Default") != NULL)
									{
										printf("\n Reviewr DefultGroup has been found");
										fflush(stdout);
										DefaultGrpflag++;
										break;
									 
									}
								}
							}

						}
					}
					/*AOM_UIF_ask_value(dml_rev_tag, "Analyst", &Aplplannergroup);
					printf("\n\n\t\t STD Planner Assigned Gropu and display group : %s", Aplplannergroup);
					fflush(stdout);

					if (tc_strstr(Aplplannergroup, "Default") != NULL)
					{
						printf("\n STD Planner DefultGroup has been found");
						fflush(stdout);
						DefaultGrpflag++;
					}

					ITKCALL(AOM_UIF_ask_value(dml_rev_tag, "ChangeSpecialist1", &Aplreviwergroup));

					printf("\n\n\t\t STD Planner Assigned Group AND Visible Reviewew Group: %s", Aplreviwergroup);
					fflush(stdout);
					if (tc_strstr(Aplreviwergroup, "Default") != NULL)
					{
						printf("\n Reviewr DefultGroup has been found");
						fflush(stdout);
						DefaultGrpflag++;
					}*/
				}
			

			printf("\n\n\t\t STD Planner and reviewr Assigned Group flag: %d ", DefaultGrpflag);
			fflush(stdout);
			if (DefaultGrpflag > 0)
			{
				printf("\n Task is assigned planner and reviewr to Default group..... \n");
				fflush(stdout);
				return 123;
			}
			else
			{

				printf("\n Task planner and reviewr group is assigned  as per group..... \n");
				fflush(stdout);
				return 0;
			}
		}


		//second condition
		//if (tc_strcmp(CurrentTask,"DefaultstdAnaRevAssign")==0)
		if (tc_strstr(CurrentTask,info2)!=NULL)
		{
			printf("\n **************inside std_dml_default_group and TASK is DefaultstdAssignment***************\n ");fflush(stdout);
			char    *participant_name           =NULL;
			char    *mode                       =NULL;
			char	*cuser						=NULL;
			char	*role						=NULL;
			char	*group						=NULL;
			tag_t	usertag						= NULLTAG;



			tag_t	participant_relation_type	= NULLTAG;
			tag_t*	participant_objects	= NULLTAG;
			int		participant_cnt	= 0;
			int		ParCngptcnt = 0;

			char*	Parobject_name	= NULL;
			char*	ChangeDMUReviewr	= NULL;
			char*	AnaDgnReviewr	= NULL;
			char*	anlstDsngrReviewGrp	= NULL;
			tag_t	Par_ObjTypDmlCRB	= NULLTAG;

			ITKCALL(GRM_find_relation_type("HasParticipant", &participant_relation_type));
			ITKCALL(GRM_list_secondary_objects_only(dml_rev_tag, participant_relation_type, &participant_cnt, &participant_objects));
			printf("\n HasParticipant partcipant_cnt : [%d]\n",participant_cnt);fflush(stdout);
			if (participant_cnt > 0)
			{
				for (ParCngptcnt= 0; ParCngptcnt<participant_cnt;ParCngptcnt++ )
				{
					
					Parobject_name	= NULL;
					AnaDgnReviewr		= NULL;
					anlstDsngrReviewGrp	= NULL;
					Par_ObjTypDmlCRB		= NULLTAG;
					

					ITKCALL(TCTYPE_ask_object_type(participant_objects[ParCngptcnt],&Par_ObjTypDmlCRB));
				
					
					ITKCALL( TCTYPE_ask_name2	(Par_ObjTypDmlCRB,&Parobject_name));
					
					printf("\n\n\t\t Analyst and ChangeSpecialist1 tcParobject_name :   %s\n",Parobject_name);
					fflush(stdout);
					if (tc_strcmp(Parobject_name,"Analyst")==0)
					{
					
						ITKCALL(AOM_UIF_ask_value(participant_objects[ParCngptcnt],"fnd0AssigneeUser",&AnaDgnReviewr));
						ITKCALL(AOM_UIF_ask_value(participant_objects[ParCngptcnt],"assignee",&participant_name));
						printf("\n TASK: Analyst: [%s] Group: [%s] ",AnaDgnReviewr,participant_name);fflush(stdout);
						if (tc_strstr(participant_name, "Default") != NULL)
						{
							printf("\nplanner DefultGroup has been found");
					   
							cuser	= NULL;
							group	= NULL;
							usertag	= NULLTAG;

							group=tc_strtok(participant_name,"(");
							printf("\n participant group 1:[%s], participant_name :[%s]\n",group,participant_name);fflush(stdout);
							cuser = tc_strtok(NULL,")");
							printf("\n participant.. group 2:[%s], USER : [%s]\n",group,cuser);fflush(stdout);
							ITKCALL(SA_find_user2(cuser,&usertag));
								
							ITKCALL( EPM_assign_responsible_party(tTask, usertag ));
										
							printf("\n resourcePool Asiigned as responsible party...\n");fflush(stdout);
							break;
						}
						
					}
					else
					{

						printf("\n inside else : ChangeSpecialist1\n");fflush(stdout);
						participant_name	= NULLTAG;
						if (tc_strcmp(Parobject_name,"ChangeSpecialist1")==0)
						{
						
							ITKCALL(AOM_UIF_ask_value(participant_objects[ParCngptcnt],"fnd0AssigneeUser",&ChangeDMUReviewr));
							ITKCALL(AOM_UIF_ask_value(participant_objects[ParCngptcnt],"assignee",&participant_name));
							printf("\n TASK: DMU Reviewer: [%s] Group: [%s] ",ChangeDMUReviewr,participant_name);fflush(stdout);
							if (tc_strstr(participant_name, "Default") != NULL)
							{
								group=tc_strtok(participant_name,"(");
								printf("\n participant group 1:[%s], participant_name :[%s]\n",group,participant_name);fflush(stdout);
								cuser = tc_strtok(NULL,")");
								printf("\n participant.. group 2:[%s], USER : [%s]\n",group,cuser);fflush(stdout);
								ITKCALL(SA_find_user2(cuser,&usertag));

								ITKCALL( EPM_assign_responsible_party(tTask, usertag ));
											
								printf("\n resourcePool Asiigned as responsible party.....\n");fflush(stdout);
								break;
							}
						
							
						}
					}
				}
			}

			/*ITKCALL(AOM_UIF_ask_value(dml_rev_tag,"Analyst",&participant_name));
			printf("\n VENKAT ANALYST %s \n",participant_name);
			if (tc_strstr(participant_name, "Default") != NULL)
			{
				printf("\nplanner DefultGroup has been found");
						   
				cuser	= NULL;
				group	= NULL;
				usertag	= NULLTAG;

				group=tc_strtok(participant_name,"(");
				printf("\n participant group 1:[%s], participant_name :[%s]\n",group,participant_name);fflush(stdout);
				cuser = tc_strtok(NULL,")");
				printf("\n participant.. group 2:[%s], USER : [%s]\n",group,cuser);fflush(stdout);
				ITKCALL(SA_find_user2(cuser,&usertag));
					
				ITKCALL( EPM_assign_responsible_party(tTask, usertag ));
							
				printf("\n resourcePool Asiigned as responsible party...\n");fflush(stdout);
			}
			else
			{
				participant_name	= NULL;

				ITKCALL(AOM_UIF_ask_value(dml_rev_tag,"ChangeSpecialist1",&participant_name));
				printf("\nReviewer DefultGroup has been found : %s",participant_name);

				if (tc_strstr(participant_name, "Default") != NULL)
				{
					group=tc_strtok(participant_name,"(");
					printf("\n participant group 1:[%s], participant_name :[%s]\n",group,participant_name);fflush(stdout);
					cuser = tc_strtok(NULL,")");
					printf("\n participant.. group 2:[%s], USER : [%s]\n",group,cuser);fflush(stdout);
					ITKCALL(SA_find_user2(cuser,&usertag));

					ITKCALL( EPM_assign_responsible_party(tTask, usertag ));
								
					printf("\n resourcePool Asiigned as responsible party.....\n");fflush(stdout);
				}
			}*/
		}
    
	}
	return error_code;
}

//find next date
////////////////////////////////////sonu reviewer mail approver start//////////////
//sonu mail approval///////////////////////////////////////////////////////////////
///int Reviewer_Mail_Function( EPM_action_message_t msg)
 int Reviewer_Mail_Function(EPM_action_message_t msg)
{
	int error_code = ITK_ok;
	tag_t			root_task=NULLTAG;
	char*			CurrentTask				=NULL;
	char*			t5current_name				=NULL;
	char*			procedure_name				=NULL;
	char*			taskStatus				=NULL;
	char*			ParentTaskNam				=NULL;
	char* IndNum = NULL;
	char* IndDummyRefNo = NULL;
	char* Indcurrent_desc = NULL;
	char* Indt5WBS = NULL;
	char* Indt5IndWbsDes = NULL;
	char* Indt5_IndPlatform = NULL;
	char *taskname = NULL;
	tag_t Ind_PT_rel_type	= NULLTAG;
	tag_t dml_CRB_rel_type = NULLTAG;

	tag_t *taskAttachments = NULLTAG;
	tag_t *parents = NULLTAG;
	tag_t *subtask = NULLTAG;
	tag_t IndobjTag = NULLTAG;
	tag_t DmlCRBTag = NULLTAG;
	tag_t subtskTAG = NULLTAG;
	tag_t* DmlCRB                = NULLTAG;
	tag_t ObjTypDmlCRB            = NULLTAG;
	
	char * command    = NULL;
	command = (char *)MEM_alloc(500);
	char *type_name7           = NULL;
	

	EPM_decision_t decision = EPM_go;
	int ifail=0,count=0,n_parents=0;
	int attachmentCount=0;
	int NumOfAtchm=0;
	int tskcount,BreakFlag=0;
	int sonu=0;
	int jk=0;
	int CRBcount         = 0;
	char* childParentTaskNam = NULL;

	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
	printf("\n\n\t\t Root task found for MailIndentManagerReviewLC"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);

	ITK_CALL(AOM_ask_value_string(msg.task,"parent_name",&childParentTaskNam));
    printf("\n childParentTask: %s \n",childParentTaskNam);fflush(stdout);

	ITK_CALL(EPM_ask_sub_tasks(root_task,&tskcount,&subtask));
	printf("\n tskcount:%d\n",tskcount);fflush(stdout);
	
	for(sonu=0;sonu<tskcount;sonu++)
	{
		subtskTAG=subtask[sonu];
		
		ITK_CALL(AOM_ask_value_string(subtskTAG,"fnd0Status",&taskStatus));
		printf("\n taskStatus:%s",taskStatus);fflush(stdout);
		if(BreakFlag==0)
		{
			if((tc_strcmp(taskStatus,"Started")==0)||(tc_strcmp(taskStatus,"Pending")==0))
			{
				//AOM_ask_value_string(subtskTAG,"fnd0AllWorkflows",&ParentTaskNam);
				//printf("\n ParentTaskNam:%s",ParentTaskNam);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(subtskTAG,"object_name",&taskname));
				printf("\n taskname :%s ",taskname);fflush(stdout);

				if(tc_strcmp(taskname,"Review the Changes")==0)
				{
					EPM_ask_attachments(root_task,EPM_target_attachment,&attachmentCount,&taskAttachments);
					printf("\n attachmentCount:[%d]\n",attachmentCount);

					if(attachmentCount > 0)
					{
						for (NumOfAtchm=0;NumOfAtchm<attachmentCount ;NumOfAtchm++ )
						{
							IndobjTag = NULLTAG;
							char*			Indobjtype					= NULL;
							IndobjTag = taskAttachments[NumOfAtchm];
							
							WSOM_ask_object_type2(IndobjTag,&Indobjtype);
							printf("\n IndobjTag type in Assign parti----->[%s]",Indobjtype); fflush(stdout);
							
						
							if(tc_strcasecmp(Indobjtype,"T5_APLTaskRevision")==0)
							{
							char*		IndentApprover		= NULL;
							char*		firsttok		= NULL;
							char*		Secondtok		= NULL;
							char*		Thirdtok		= NULL;
							char*       user_name       = NULL;
							char*       mailId       = NULL;
							tag_t IndentApproverTag = NULLTAG;
							tag_t person_tag = NULLTAG;
							firsttok=(char *) MEM_alloc(500 * sizeof(char *));
							Secondtok=(char *) MEM_alloc(500 * sizeof(char *));
							Thirdtok=(char *) MEM_alloc(500 * sizeof(char *));
							AOM_ask_value_string(IndobjTag,"change_specialist1_user_id",&IndentApprover);
							printf("IndentApprover ::  %s\n", IndentApprover);fflush(stdout);
							
							if(SA_find_user2(IndentApprover, &IndentApproverTag)!=ITK_ok)PrintErrorStack();
							
							if(SA_ask_user_person (IndentApproverTag,&person_tag)!=ITK_ok)PrintErrorStack();
							POM_ask_user_name(person_tag, &user_name);
							printf("user_name ::  %s\n", user_name);fflush(stdout);
							if(SA_ask_person_email_address(person_tag,&mailId)!=ITK_ok)PrintErrorStack();
							tc_strcpy(Thirdtok,"");
							tc_strcpy(Thirdtok,user_name);
							tc_strcat(Thirdtok," ");
							tc_strcat(Thirdtok,"(");
							tc_strcat(Thirdtok,IndentApprover);//IndentApprover
							tc_strcat(Thirdtok,")");
							printf("Thirdtok ::  %s\n", Thirdtok);fflush(stdout);
							
							
							
							/* if(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
							if (dml_CRB_rel_type!=NULLTAG)
							{
							printf("\n ADPR:P28:DML to Has participant. \n");fflush(stdout);
							if(GRM_list_secondary_objects_only(IndobjTag,dml_CRB_rel_type,&CRBcount,&DmlCRB)!=ITK_ok)PrintErrorStack();
							printf("\n ADPR:CV:P29: DmlCRB count: %d",CRBcount);fflush(stdout);
							for (jk=0;jk<CRBcount ;jk++ )
							{
								//type_name7=NULL;
							DmlCRBTag = DmlCRB[jk];
							if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
							if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
							printf("\n ADPR:CV:P30:CE02: Participants Name: %s", type_name7);fflush(stdout);
					       if (tc_strcmp(type_name7,"ChangeSpecialist1")==0)
							{
								
							  AOM_ask_value_string(DmlCRBTag,"fnd0AssigneeUser",&IndentApprover);
							  printf("IndentApprover ::  %s\n", IndentApprover);fflush(stdout);
						      firsttok=tc_strtok(IndentApprover,"/");
						      Secondtok=tc_strtok(NULL,"/");
						      Thirdtok=tc_strtok(NULL,"/");
							  printf("Thirdtok ::  %s\n", Thirdtok);fflush(stdout);
							  break;
							}
							
							}
							} */
							
					
							char  *WebserviceShellpath	  = NULL;
							char  *doublete	  = NULL;
							//envSub = (char *) MEM_alloc( 250 * sizeof(char) );
							//envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
							WebserviceShellpath = (char *) MEM_alloc( 1000 * sizeof(char) );
							doublete = (char *) MEM_alloc( 1000 * sizeof(char) );
							tc_strcpy(doublete,"");
							 tc_strcat(doublete,"\"");
						
								AOM_ask_value_string(IndobjTag,"item_id",&IndNum);
								printf("\n STDDMLNum [%s]",IndNum);fflush(stdout);
							
								tc_strcpy(WebserviceShellpath,"");
								tc_strcpy(WebserviceShellpath,"/home/apldev/Sonu");
								printf("\n WebserviceShell path  %s\n",WebserviceShellpath);fflush(stdout);
								tc_strcpy(command,"");
								printf("\n inside pFirst_webservice condition \n");
								tc_strcat(command,"/home/apldev/Sonu/");
								tc_strcat(command,"pFirst_webservice_CV.sh");
								tc_strcat(command," ");
								tc_strcat(command,doublete);
								tc_strcat(command,IndNum);
								tc_strcat(command,doublete);
								tc_strcat(command," ");
								tc_strcat(command,doublete);
								tc_strcat(command,"CV");
								tc_strcat(command,doublete);
								tc_strcat(command," ");
								tc_strcat(command,doublete);
								tc_strcat(command,childParentTaskNam);
								tc_strcat(command,doublete);
								tc_strcat(command," ");
								tc_strcat(command,doublete);
								tc_strcat(command,Thirdtok);
								tc_strcat(command,doublete);
								tc_strcat(command," ");
								tc_strcat(command,doublete);
								tc_strcat(command,taskname);
								tc_strcat(command,doublete);
								tc_strcat(command," ");
								tc_strcat(command,doublete);
								tc_strcat(command,mailId);
								tc_strcat(command,doublete);
								tc_strcat(command," ");
								printf("\n Berfor excute Command ----------: %s", command);
								system(command);
								BreakFlag=1;
							
							}
						}
					}
				}
			}
		}
	}

	return error_code;
}

///////////////////////////////////reviewer mail approver end//////////////////////

int getMonthfun(char *month)
{
    if(tc_strcmp(month,"Jan")==0)
    {
        return 1;
    }
    else if(tc_strcmp(month,"Feb")==0)
    {
        return 2;
    }
    else if(tc_strcmp(month,"Mar")==0)
    {
        return 3;
    }
    else if(tc_strcmp(month,"Apr")==0)
    {
        return 4;
    }
    else if(tc_strcmp(month,"May")==0)
    {
        return 5;
    }
    else if(tc_strcmp(month,"Jun")==0)
    {
        return 6;
    }
    else if(tc_strcmp(month,"Jul")==0)
    {
        return 7;
    }
    else if(tc_strcmp(month,"Aug")==0)
    {
        return 8;
    }
    else if(tc_strcmp(month,"Sep")==0)
    {
        return 9;
    } 
    else if(tc_strcmp(month,"Oct")==0)
    {
        return 10;
    }
    else if(tc_strcmp(month,"Nov")==0)
    {
        return 11;
    }
    else if(tc_strcmp(month,"Dec")==0)
    {
        return 12;
    }
	else
	{
		printf("Invalid ");
		return 0;
	}
}

int isLeapYear(int year) {
    if (year % 4 == 0) {
        if (year % 100 == 0) {
            if (year % 400 == 0)
                return 1; // Leap year
            else
                return 0; // Not a leap year
        }
        return 1; // Leap year
    }
    return 0; // Not a leap year
}

// Function to get the number of days in a month
int daysInMonth(int month, int year) {
    // Array of days in each month
    int days[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    
    // Adjust for February in leap years
    if (month == 2 && isLeapYear(year))
        return 29;
    
    return days[month - 1];
}

void nextDateFun(int day, int month, int year, char dateReturn[], char *time) {
	printf("\n day %d",day);fflush(stdout); 
	printf("\n month %d",month);fflush(stdout);
	printf("\n year %d",year);fflush(stdout);
	printf("\n time %s",time);fflush(stdout);
    int daysInCurrentMonth = daysInMonth(month, year);
    
    // Increment the day
    day++;
    
    // Check if we need to move to the next month
    if (day > daysInCurrentMonth) {
        day = 1;
        month++;
        
        // Check if we need to move to the next year
        if (month > 12) {
            month = 1;
            year++;
        }
    }
    
    // Print the next date
    printf("Next date: %02d-%02d-%d\n", day, month, year);fflush(stdout);

	char cMonth[30];
	getMonth(month,cMonth);
	printf( "\n cMonth:%s", cMonth);fflush(stdout);

	char dayStr[10];
	sprintf(dayStr, "%d", day);
    printf("\n dayStr : %s\n", dayStr);fflush(stdout);
	
	char yearStr[20];
	sprintf(yearStr, "%d", year);
    printf("\n yearStr : %s\n", yearStr);fflush(stdout);

	tc_strcpy(dateReturn," ");
	tc_strcat(dateReturn,dayStr);
	tc_strcat(dateReturn,"-");
	tc_strcat(dateReturn,cMonth);
	tc_strcat(dateReturn,"-");
	tc_strcat(dateReturn,yearStr);
	tc_strcat(dateReturn," ");
	tc_strcat(dateReturn,time);
	printf("\n dateReturn %s",dateReturn);fflush(stdout);

}


//prince Rule Handler for WT Validation and Stamping on part and Task

extern EPM_decision_t DLLAPI WTValidationsAndReleaseStatus(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int status;
	tag_t rootTask = NULLTAG;
	tag_t qryTagCntrl= NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t dml_rev_tag = NULLTAG;
	tag_t task_rev_tag = NULLTAG;
	tag_t user_tag = NULLTAG;
	tag_t *TargetAttch = NULLTAG;
	tag_t *member_tags = NULLTAG;
	char *CurrentTask = NULL;
	char *parent_name = NULL;
	char *Task_no = NULL;
	char *DML_no = NULL;
	int	 iNumAttch = 0;
	int	 n_entrycoCntrl	= 3;
	char *type_name = NULL; 
	tag_t relation_Tag = NULLTAG;
	tag_t *Dml_tag = NULLTAG;
	int DMLcount=0;
	char *releaseTypeDML=NULL;

	tag_t tsk_dml_rel_type = NULLTAG;
	tag_t solFolTag = NULLTAG;
	tag_t *solFoldPartTag = NULLTAG;
	int	partCount = 0;
	int xx=0;
	char *solFoldPartNumber = NULL;
	tag_t partStatus = NULLTAG;
	tag_t partStatusTask = NULLTAG;
	char	**SetWTErr = NULL;
	SetWTErr = (char**)MEM_alloc( 1 * sizeof *SetWTErr );
	int icount1=0;
	int		iLength	=	0;
	char	*tempErr	=	0;
	int i=0;
	logical retain=false;
	char LcsStdWrkg[40];
	char LcsStdRlzd[40];
	tag_t qryTagCntrl1 = NULLTAG;
	char *qry_entryCntrl1[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
    char **qry_valuesCntrl1 = (char **)MEM_alloc(5 * sizeof(char *));
	int n_entryCntrl1 = 3;
	int control_number_found1 = 0;
	tag_t *list_of_WSO_cntrl_tags1 = NULLTAG;

	//Effectivity
	int numOfReleaseStatus = 0;
	tag_t *valuesOfReleaseStatus = NULLTAG;
	char *releaseStatusListOnPart		= NULL ; 
	tag_t previousRevisionTag = NULLTAG;
	date_t partDateReleasedOfPreRev;
	char* partDateReleasedOfPreRevToStr	= NULL;
	char currentDate[20]={0};
	date_t	test_date_1;
	date_t	test_date_2;
	date_t*	start_end_date	= NULL;
	tag_t eff_d	= NULLTAG;
	int iii = 0;

	
	char AplRlzdLc[40];
    char AplRvwLC[40]; 
    char AplWrkngLC[40];
    char Stdwrknglc[40];
    char Stdrlzdlc[40];
    char PltLcs[40];
    char StdPlant[40];
    char StdRevRule[40];
    char StdCLosRule[40];
    char StdView[40];

	
	printf("\nInside WTValidationsAndReleaseStatus");fflush(stdout);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n WTValidationsAndReleaseStatus\n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);

	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);

	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &TargetAttch) );
	printf("\nNo of Target Attachements:%d\n",iNumAttch);fflush(stdout);
	if (iNumAttch>0)
	{	
		task_rev_tag = TargetAttch[0];
		ITKCALL(TCTYPE_ask_object_type(task_rev_tag,&objTypeTag));
		ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
		printf("\n workspaceobject  type_name  %s\n", type_name);fflush(stdout);

		ITKCALL(AOM_ask_value_string( task_rev_tag, "item_id", &Task_no));
		printf("\n Task Number item_id %s ",Task_no);
		
		ITKCALL(GRM_find_relation_type("CMHasSolutionItem", &solFolTag));
		ITKCALL(GRM_list_secondary_objects_only(task_rev_tag,solFolTag,&partCount,&solFoldPartTag));

		printf("\n\n\t\t Number of part under solution folder : %d",partCount);fflush(stdout);

		QRY_find2("Control Objects...", &qryTagCntrl1);
		if (qryTagCntrl1)
    	{
        	printf("\n Control Object Query Found For WT Validation\n");fflush(stdout);
			qry_valuesCntrl1[0] = "WTValidation";
        	qry_valuesCntrl1[1] = "WTValidation";
        	qry_valuesCntrl1[2] = "0";
			ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			printf("\nNumber of control object found :%d", control_number_found1);fflush(stdout);
			if(control_number_found1>0)
			{
				printf("\n\n\t\t calling WT signoff function");fflush(stdout);
				WTDML_Part_Release_Check_STD(partCount,solFoldPartTag,&SetWTErr,&icount1,task_rev_tag);
				printf("\n\n\t\t end calling WT signoff function");fflush(stdout);
				printf("\n\n\t\t error count %d",icount1);fflush(stdout);
			}
			else
			{
				printf("\n\n\t\t control object not found WTValidation" );fflush(stdout);
			}
		}
		printf("\n\n\t\t error count %d",icount1);fflush(stdout);
		if(icount1>0)
		{
			iLength	=	0;
			if (!tempErr) MEM_free(tempErr);
			i=0;
			if (!tempErr) MEM_free(tempErr);
			int i=0;
			for (i=0; i < icount1; i++)
			{
				//printf("%s",SetChildRelErr[i]);fflush(stdout);
				tempErr	=	SetWTErr[i];
				iLength	=	iLength	+	tc_strlen(tempErr);
			}
			printf("iLength : %d",iLength);fflush(stdout);
			if (!tempErr) MEM_free(tempErr);
			tempErr	=	(char *)MEM_alloc(iLength+20);
			i=0;
			for (i=0; i < icount1; i++)
			{
				//printf("%s",SetChildRelErr[i]);fflush(stdout);
				if(i==0)
					tc_strcpy(tempErr,SetWTErr[i]);
				else
					tc_strcat(tempErr,SetWTErr[i]);
			}
			printf("\nPrinting Errors...!!!");fflush(stdout);
			printf("%s",tempErr);fflush(stdout);
			EMH_clear_errors();
			status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
			decision = EPM_nogo;
			return decision;
		}
		else
		{
			ITKCALL( RELSTAT_create_release_status("Obsolete", &partStatus));
			for(xx=0;xx<partCount;xx++)
			{
				ITKCALL(AOM_ask_value_string( solFoldPartTag[xx], "item_id", &solFoldPartNumber));
				printf("\n Part Number under solution folder is  %s ",solFoldPartNumber);
				ITKCALL(RELSTAT_add_release_status(partStatus, 1, &solFoldPartTag[xx], retain));

				//logic for printing effectivity
				ITKCALL(AOM_ask_value_tags(solFoldPartTag[xx], "release_status_list", &numOfReleaseStatus, &valuesOfReleaseStatus ));
				printf("\n Total Release Status  %d ",numOfReleaseStatus);fflush(stdout);

				if(numOfReleaseStatus>0)
				{
					char *copyTaskNumber = NULL;
					copyTaskNumber= malloc(1000 * sizeof(char) );
					strcpy(copyTaskNumber,Task_no);
					char* Dsgn_No = NULL;
					char* PLT_Code = NULL;
					Dsgn_No = tc_strtok(copyTaskNumber, "_");
					printf("\nTest0.11..Dsgn_No:[%s],[%s]\n", Dsgn_No, copyTaskNumber);fflush(stdout);
					Dsgn_No = tc_strtok(NULL, "_");
					printf("\nTest0.12..Dsgn_No:[%s],[%s]\n", Dsgn_No, copyTaskNumber);fflush(stdout);
					PLT_Code = tc_strtok(NULL, "_");
					printf("\nTest0.13..PLT_Code:[%s],[%s]\n", PLT_Code, copyTaskNumber);fflush(stdout);

					//function calling to get release status
					get_CtrlVal_APLStateInf(PLT_Code, AplRvwLC, AplWrkngLC, AplRlzdLc, Stdwrknglc, Stdrlzdlc, PltLcs, StdPlant, StdRevRule, StdCLosRule, StdView);
					for(iii=0;iii<numOfReleaseStatus;iii++)
					{
						ITKCALL(AOM_ask_value_string(valuesOfReleaseStatus[iii],"object_name",&releaseStatusListOnPart));
						printf("\n object_name of release status is %s",releaseStatusListOnPart);fflush(stdout);
						if(tc_strcmp(releaseStatusListOnPart,AplRlzdLc)==0 || tc_strcmp(releaseStatusListOnPart,Stdrlzdlc)==0 || tc_strcmp(releaseStatusListOnPart,"T5_MBOMReleased")==0 )
						{
							ITKCALL(AOM_ask_value_date(valuesOfReleaseStatus[iii],"date_released",&partDateReleasedOfPreRev));
							ITKCALL(ITK_date_to_string(partDateReleasedOfPreRev, &partDateReleasedOfPreRevToStr));
							printf("\n date release is %s",partDateReleasedOfPreRevToStr);fflush(stdout);
							
							if(partDateReleasedOfPreRevToStr != NULL)
							{
								char* dateNo = NULL;
								int dateNoInt=0;
								dateNo = tc_strtok(partDateReleasedOfPreRevToStr, "-");
								dateNoInt = atoi(dateNo);
								printf("\n dateNo  and int value  is %s ,%d ",dateNo,dateNoInt);fflush(stdout);

								char *DateMonth=NULL;
								int DateMonthInt=0;
								DateMonth = tc_strtok(NULL, "-");
								printf("\n DateMonth is %s",DateMonth);fflush(stdout);
								DateMonthInt = getMonthfun(DateMonth);
								printf("\n DateMonthInt is %d",DateMonthInt);fflush(stdout);

								char *DateMonthYear=NULL;
								int DateMonthYearInt = 0;
								DateMonthYear = tc_strtok(NULL, " ");
								printf("\n DateMonthYear  %s",DateMonthYear);fflush(stdout);
								DateMonthYearInt = atoi(DateMonthYear);
								printf("\n DateMonthYearInt  [%d]",DateMonthYearInt);fflush(stdout); 

								char *time = NULL;
								time = tc_strtok(NULL,"");
								printf("\n time %s",time);fflush(stdout); 
								char NextDateToBeStamp[30];
								printf("\n nextDateFun \n");fflush(stdout); 
								nextDateFun(dateNoInt, DateMonthInt, DateMonthYearInt,NextDateToBeStamp,time);
								printf("\n NextDateToBeStamp %s",NextDateToBeStamp);fflush(stdout); 

								getNextDate(currentDate);
								printf("Next Day Date %s",currentDate);fflush(stdout);

								ITKCALL(ITK_string_to_date(NextDateToBeStamp, &test_date_1 ));
								ITKCALL(ITK_string_to_date(currentDate, &test_date_2 ));

								start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
								start_end_date[0] = test_date_1;
								start_end_date[1] = test_date_2;

								ITKCALL(WSOM_status_clear_effectivities (valuesOfReleaseStatus[iii]));
								ITKCALL(WSOM_effectivity_create_with_dates(valuesOfReleaseStatus[iii], NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
								ITKCALL(AOM_save_without_extensions(eff_d));
								ITKCALL(AOM_save_without_extensions(valuesOfReleaseStatus[iii]));
							}
							else
							{
								printf("\n Date Release not present........");
							}
						}
						else
						{
							printf("\n Release status present on part is not released...");
						}
					}

				}
				else
				{
					printf("\n Release Status List count is  %d",numOfReleaseStatus);
				}
			}
			GetPlantWiseRelStat(Task_no,LcsStdWrkg,LcsStdRlzd);
			printf("\n LcsStdWrkg1: %s \n",LcsStdWrkg);fflush(stdout);
			printf("\n LcsStdRlzd1: %s \n",LcsStdRlzd);fflush(stdout);
			ITKCALL( RELSTAT_create_release_status(LcsStdRlzd, &partStatusTask));
			printf("\nLCS Updated on task1111");fflush(stdout);
			ITKCALL(RELSTAT_add_release_status(partStatusTask, 1, &task_rev_tag, retain));

			printf("\nLCS Updated on task");fflush(stdout);
			decision = EPM_go;
			return decision; 
		}
	}
	return decision;
}

//Action Handler for STDSI Stamping On APL DML, APL Task & parts cbb

int CRReleaseStatusStampOnDml( EPM_action_message_t msg ) 
{
	EPM_decision_t decision;
	int status;
	tag_t rootTask = NULLTAG;
	tag_t qryTagCntrl = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t dml_rev_tag = NULLTAG;
	tag_t task_rev_tag = NULLTAG;
	tag_t user_tag = NULLTAG;
	tag_t *TargetAttch = NULLTAG;
	tag_t *member_tags = NULLTAG;
	char *CurrentTask = NULL;
	char *parent_name = NULL;
	char *Task_no = NULL;
	char *DML_no = NULL;
	int	iNumAttch =0;
	int	n_entrycoCntrl = 3;
	char *type_name = NULL;
	char LcsStdWrkg[40];
	char LcsStdRlzd[40];
	tag_t partStatusTask = NULLTAG;
	logical retain=false;
	tag_t tsk_dml_rel_type = NULLTAG;
	int	TaskCount = 0;
	tag_t *taskTag = NULLTAG;
	int count = 0;
	int PartCnt = 0;
	int st_count1 = 0;
	int PartFlag =0 ;
	int k;
	
	tag_t*    status_list1_assy         = NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;                
	tag_t*			PartTags		    = NULLTAG;
	int				TaskCnt				= 0;
	tag_t			AssyTag				= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	char*			object_type			= NULL;
	char           *TaskName	        = NULL;
	char*           PLT_Code            = NULL;
    tag_t	relation_type1, relation_type,relation	,propTag	= NULLTAG;

	char AplRlzdLc[40];
    char AplRvwLC[40]; 
    char AplWrkngLC[40];
    char Stdwrknglc[40];
    char Stdrlzdlc[40];
    char PltLcs[40];
    char StdPlant[40];
    char StdRevRule[40];
    char StdCLosRule[40];
    char StdView[40];

	tag_t CurrentRoleTag = NULLTAG;
    char *roleName=NULL;
    char *PlantName = NULL;

	//Effectivity
	char *solFoldPartNumber = NULL;
	int numOfReleaseStatus = 0;
	tag_t *valuesOfReleaseStatus = NULLTAG;
	char *releaseStatusListOnPart		= NULL ; 
	tag_t previousRevisionTag = NULLTAG;
	date_t partDateReleasedOfPreRev;
	char* partDateReleasedOfPreRevToStr	= NULL;
	char currentDate[20]={0};
	date_t	test_date_1;
	date_t	test_date_2;
	date_t*	start_end_date	= NULL;
	tag_t eff_d	= NULLTAG;
	int iii = 0;


		printf("\nInside CRReleaseStatusStampOnDml");fflush(stdout);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n CRReleaseStatusStampOnDml\n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout); 

	char* group =(char*) MEM_alloc(200);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &TargetAttch) );
	printf("\nNo of Target Attachements:%d\n",iNumAttch);fflush(stdout);

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
    ITKCALL(SA_ask_role_name2(CurrentRoleTag, &roleName));

	printf("\n\n  roleName : %s\n", roleName);
	fflush(stdout);
	PlantName = subString(roleName, 3, 4);
	printf("PlantName:%s\n", PlantName);

	if (iNumAttch>0)
	{	
		dml_rev_tag = TargetAttch[0];
		ITKCALL(TCTYPE_ask_object_type(dml_rev_tag,&objTypeTag));
		ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
		printf("\n workspaceobject  type_name00000000   %s\n", type_name);fflush(stdout);


		if(tc_strcmp(type_name,"T5_APLDMLRevision")==0)
		{
			ITKCALL(AOM_ask_value_string( dml_rev_tag, "item_id", &DML_no));
			printf("\n DML Number item_id %s ",DML_no);
			ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
			ITKCALL(GRM_list_secondary_objects_only(dml_rev_tag,relation_type,&count,&TaskRevision));
			printf("\n\n\t\t APL DML Cre:ERC DML to Task : %d",count);fflush(stdout);

					for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
								{
									TaskRevTag = TaskRevision[TaskCnt];

									ITKCALL(AOM_ask_value_string( TaskRevTag, "item_id", &Task_no));
									printf("\n Task Number item_id %s ",Task_no);

									ITKCALL(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
									printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);

									if(strcmp(object_type,"T5_APLTaskRevision")==0)
									{
										int PartCnt = 0;
										char* Dsgn_No = NULL;
										//char* PLT_Code = NULL;
										Dsgn_No = tc_strtok(Task_no, "_");
										printf("\nTest0.11..Dsgn_No:[%s],[%s]\n", Dsgn_No, Task_no);fflush(stdout);
										Dsgn_No = tc_strtok(NULL, "_");
										printf("\nTest0.12..Dsgn_No:[%s],[%s]\n", Dsgn_No, Task_no);fflush(stdout);
										PLT_Code = tc_strtok(NULL, "_");
										printf("\nTest0.13..PLT_Code:[%s],[%s]\n", PLT_Code, Task_no);fflush(stdout);										
										ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type1));
										ITKCALL(GRM_list_secondary_objects_only(TaskRevTag,relation_type1,&PartCnt,&PartTags));
										printf("\n\n\t\t APL DML Cre:PartCnt : %d",PartCnt);fflush(stdout);										
										if (PartCnt>0)
										{
											for (k=0;k<PartCnt ;k++ )
											{
												get_CtrlVal_APLStateInf(PLT_Code, AplRvwLC, AplWrkngLC, AplRlzdLc, Stdwrknglc, Stdrlzdlc, PltLcs, StdPlant, StdRevRule, StdCLosRule, StdView);

												printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
												AssyTag=PartTags[k];

												// PartFlag = 0;
												// st_count1 = 0;
												// ITKCALL(WSOM_ask_release_status_list(AssyTag,&st_count1,&status_list1_assy));
												// printf("\n #######st_count1 :%d is\n",st_count1);fflush(stdout);																																				
											
												printf("\n Stamping to be stamp on DML Stdrlzdlc: %s \n",Stdrlzdlc);fflush(stdout);
												ITKCALL( RELSTAT_create_release_status(Stdrlzdlc, &partStatusTask));
												//ITKCALL( RELSTAT_create_release_status("T5_LcsStdRlzd", &partStatusTask));
												ITKCALL(RELSTAT_add_release_status(partStatusTask, 1, &AssyTag, retain));
												printf("\nLCS Updated on TASK at STD Level");fflush(stdout);

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ working
printf("\n Effectivity ++++++++++++++++++++++++  \n");
												ITKCALL(AOM_ask_value_string( AssyTag, "item_id", &solFoldPartNumber));
												printf("\n Part Number under solution folder is  %s ",solFoldPartNumber);
												//ITKCALL(RELSTAT_add_release_status(partStatus, 1, &solFoldPartTag[xx], retain));

												//logic for printing effectivity
												ITKCALL(AOM_ask_value_tags(AssyTag, "release_status_list", &numOfReleaseStatus, &valuesOfReleaseStatus ));
												printf("\n Total Release Status  %d ",numOfReleaseStatus);fflush(stdout);

												if(numOfReleaseStatus>0)
												{
													// char *copyTaskNumber = NULL;
													// copyTaskNumber= malloc(1000 * sizeof(char) );
													// tc_strcpy(copyTaskNumber,Task_no);
													// char* Dsgn_No = NULL;
													// char* PLT_Code = NULL;
													// printf("\nTest0.11..Dsgn_No:[%s],[%s]\n", Dsgn_No, copyTaskNumber);fflush(stdout);
													// Dsgn_No = tc_strtok(copyTaskNumber, "_");
													// printf("\nTest0.11..Dsgn_No:[%s],[%s]\n", Dsgn_No, copyTaskNumber);fflush(stdout);
													// Dsgn_No = tc_strtok(NULL, "_");
													// printf("\nTest0.12..Dsgn_No:[%s],[%s]\n", Dsgn_No, copyTaskNumber);fflush(stdout);
													// PLT_Code = tc_strtok(NULL, "_");
													// printf("\nTest0.13..PLT_Code:[%s],[%s]\n", PLT_Code, copyTaskNumber);fflush(stdout);
													printf("\nCCCCCCCCCCCC   PLT_Code:[%s]\n", PLT_Code);fflush(stdout);
													//function calling to get release status
													get_CtrlVal_APLStateInf(PLT_Code, AplRvwLC, AplWrkngLC, AplRlzdLc, Stdwrknglc, Stdrlzdlc, PltLcs, StdPlant, StdRevRule, StdCLosRule, StdView);
													for(iii=0;iii<numOfReleaseStatus;iii++)
													{
														ITKCALL(AOM_ask_value_string(valuesOfReleaseStatus[iii],"object_name",&releaseStatusListOnPart));
														printf("\n object_name of release status is %s",releaseStatusListOnPart);fflush(stdout);
														if(tc_strcmp(releaseStatusListOnPart,Stdrlzdlc)==0)
														{
															ITKCALL(AOM_ask_value_date(valuesOfReleaseStatus[iii],"date_released",&partDateReleasedOfPreRev));
															ITKCALL(ITK_date_to_string(partDateReleasedOfPreRev, &partDateReleasedOfPreRevToStr));
															printf("\n date release is %s",partDateReleasedOfPreRevToStr);fflush(stdout);
															
															// if(partDateReleasedOfPreRevToStr != NULL)
															// {
																char* dateNo = NULL;
																int dateNoInt=0;
																dateNo = tc_strtok(partDateReleasedOfPreRevToStr, "-");
																dateNoInt = atoi(dateNo);
																printf("\n dateNo  and int value  is %s ,%d ",dateNo,dateNoInt);fflush(stdout);

																char *DateMonth=NULL;
																int DateMonthInt=0;
																DateMonth = tc_strtok(NULL, "-");
																printf("\n DateMonth is %s",DateMonth);fflush(stdout);
																DateMonthInt = getMonthfun(DateMonth);
																printf("\n DateMonthInt is %d",DateMonthInt);fflush(stdout);

																char *DateMonthYear=NULL;
																int DateMonthYearInt = 0;
																DateMonthYear = tc_strtok(NULL, " ");
																printf("\n DateMonthYear  %s",DateMonthYear);fflush(stdout);
																DateMonthYearInt = atoi(DateMonthYear);
																printf("\n DateMonthYearInt  [%d]",DateMonthYearInt);fflush(stdout); 

																char *time = NULL;
																time = tc_strtok(NULL,"");
																printf("\n time %s",time);fflush(stdout); 
																char NextDateToBeStamp[30];
																printf("\n nextDateFun \n");fflush(stdout); 
																nextDateFun(dateNoInt, DateMonthInt, DateMonthYearInt,NextDateToBeStamp,time);
																printf("\n NextDateToBeStamp %s",NextDateToBeStamp);fflush(stdout); 

																getNextDate(currentDate);
																printf("Next Day Date %s",currentDate);fflush(stdout);

																ITKCALL(ITK_string_to_date(currentDate, &test_date_1 ));
																ITKCALL(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));

																start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
																start_end_date[0] = test_date_1;
																start_end_date[1] = test_date_2;

																ITKCALL(WSOM_status_clear_effectivities (valuesOfReleaseStatus[iii]));
																ITKCALL(WSOM_effectivity_create_with_dates(valuesOfReleaseStatus[iii], NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
																ITKCALL(AOM_save_without_extensions(eff_d));
																ITKCALL(AOM_save_without_extensions(valuesOfReleaseStatus[iii]));
															// }
															// else
															// {
															// 	printf("\n Date Release not present........");
															// }
														}
														else
														{
															printf("\n Release status present on part is not released...");
														}
													}

												}
												else
												{
													printf("\n Release Status List count is  %d",numOfReleaseStatus);
												}


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++=



												
											}
										}  								

										get_CtrlVal_APLStateInf(PLT_Code, AplRvwLC, AplWrkngLC, AplRlzdLc, Stdwrknglc, Stdrlzdlc, PltLcs, StdPlant, StdRevRule, StdCLosRule, StdView);
										printf("\n Stamping to be stamp on DML Stdrlzdlc: %s \n",Stdrlzdlc);fflush(stdout);
										ITKCALL( RELSTAT_create_release_status(Stdrlzdlc, &partStatusTask));
										//ITKCALL( RELSTAT_create_release_status("T5_LcsStdRlzd", &partStatusTask));
										ITKCALL(RELSTAT_add_release_status(partStatusTask, 1, &TaskRevTag, retain));
										printf("\nLCS Updated on TASK at STD Level");fflush(stdout);						

									}
							  }  

			char* Dsgn_No = NULL;
			char* PLT_Code = NULL;
					
			Dsgn_No = tc_strtok(DML_no, "_");
			printf("\nTest0.11..Dsgn_No:[%s],[%s]\n", Dsgn_No, DML_no);fflush(stdout);
			PLT_Code = tc_strtok(NULL, "_");
			printf("\nTest0.13..PLT_Code:[%s],[%s]\n", PLT_Code, DML_no);fflush(stdout);

			get_CtrlVal_APLStateInf(PLT_Code, AplRvwLC, AplWrkngLC, AplRlzdLc, Stdwrknglc, Stdrlzdlc, PltLcs, StdPlant, StdRevRule, StdCLosRule, StdView);			
				printf("\n Stamping to be stamp on DML Stdrlzdlc: %s \n",Stdrlzdlc);fflush(stdout);
				ITKCALL( RELSTAT_create_release_status(Stdrlzdlc, &partStatusTask));
				ITKCALL(RELSTAT_add_release_status(partStatusTask, 1, &dml_rev_tag, retain));
				printf("\nLCS Updated on DML at STD Level");fflush(stdout);
			

			printf("\nLCS Updated on DML");fflush(stdout);
		}
		
	}

}

//Action Handler for Stamping On APL DML, APL Task and STD DMl

int WTReleaseStatusStampOnDml( EPM_action_message_t msg ) 
{
	EPM_decision_t decision;
	int status;
	tag_t rootTask = NULLTAG;
	tag_t qryTagCntrl = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t dml_rev_tag = NULLTAG;
	tag_t task_rev_tag = NULLTAG;
	tag_t user_tag = NULLTAG;
	tag_t *TargetAttch = NULLTAG;
	tag_t *member_tags = NULLTAG;
	char *CurrentTask = NULL;
	char *parent_name = NULL;
	char *Task_no = NULL;
	char *DML_no = NULL;
	int	iNumAttch =0;
	int	n_entrycoCntrl = 3;
	char *type_name = NULL;
	char LcsStdWrkg[40];
	char LcsStdRlzd[40];
	tag_t partStatusTask = NULLTAG;
	logical retain=false;
	tag_t tsk_dml_rel_type = NULLTAG;
	int	TaskCount = 0;
	tag_t *taskTag = NULLTAG;


	char AplRlzdLc[40];
    char AplRvwLC[40]; 
    char AplWrkngLC[40];
    char Stdwrknglc[40];
    char Stdrlzdlc[40];
    char PltLcs[40];
    char StdPlant[40];
    char StdRevRule[40];
    char StdCLosRule[40];
    char StdView[40];

	tag_t CurrentRoleTag = NULLTAG;
    char *roleName=NULL;
    char *PlantName = NULL;

	//APL Release Date
	char cCurrentAccessDate[20] = {0};
	date_t Release_date=NULLDATE;
	tag_t qryTagCntrl1 = NULLTAG;
	char *qry_entryCntrl1[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
	char **qry_valuesCntrl1 = (char **)MEM_alloc(5 * sizeof(char *));
	int n_entryCntrl1 = 3;
	int control_number_found1 = 0;
	tag_t *list_of_WSO_cntrl_tags1 = NULLTAG;
	char *ExePath = NULL;
	char *syscommand = NULL;
	char *cpyDMLNo = NULL;
	
	printf("\nInside WTReleaseStatusStampOnDml");fflush(stdout);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n WTReleaseStatusStampOnDml\n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout); 

	char* group =(char*) MEM_alloc(200);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &TargetAttch) );
	printf("\nNo of Target Attachements:%d\n",iNumAttch);fflush(stdout);

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
    ITKCALL(SA_ask_role_name2(CurrentRoleTag, &roleName));

	printf("\n\n  roleName : %s\n", roleName);
	fflush(stdout);
	PlantName = subString(roleName, 3, 4);
	printf("PlantName:%s\n", PlantName);

	if (iNumAttch>0)
	{	
		dml_rev_tag = TargetAttch[0];
		ITKCALL(TCTYPE_ask_object_type(dml_rev_tag,&objTypeTag));
		ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
		printf("\n workspaceobject  type_name00000000   %s\n", type_name);fflush(stdout);
		if(tc_strcmp(type_name,"T5_APLDMLRevision")==0)
		{
			ITKCALL(AOM_ask_value_string( dml_rev_tag, "item_id", &DML_no));
			printf("\n DML Number item_id %s ",DML_no);

			//changes
			cpyDMLNo = (char *)MEM_alloc(500);
			tc_strcpy(cpyDMLNo, DML_no);
			printf("\n Copy DML number is,  %s\n", cpyDMLNo);fflush(stdout);

			char* Dsgn_No = NULL;
			char* PLT_Code = NULL;
					
			Dsgn_No = tc_strtok(DML_no, "_");
			printf("\nTest0.11..Dsgn_No:[%s],[%s]\n", Dsgn_No, DML_no);fflush(stdout);
			PLT_Code = tc_strtok(NULL, "_");
			printf("\nTest0.13..PLT_Code:[%s],[%s]\n", PLT_Code, DML_no);fflush(stdout);

			//function calling to get release status
			get_CtrlVal_APLStateInf(PLT_Code, AplRvwLC, AplWrkngLC, AplRlzdLc, Stdwrknglc, Stdrlzdlc, PltLcs, StdPlant, StdRevRule, StdCLosRule, StdView);
			if(tc_strstr(PlantName,"APL")!=NULL)
			{
				printf("\n Stamping to be stamp on DML AplRlzdLc: %s \n",AplRlzdLc);fflush(stdout);
				ITKCALL( RELSTAT_create_release_status(AplRlzdLc, &partStatusTask));
				ITKCALL(RELSTAT_add_release_status(partStatusTask, 1, &dml_rev_tag, retain));
				printf("\nLCS Updated on DML at APL Level");fflush(stdout);

				//APL Release Date Stamp on APL DML And APL Task

				QRY_find2("Control Objects...", &qryTagCntrl1);
				if (qryTagCntrl1)
				{
					printf("\n Control Object Query Found For WT Validation\n");fflush(stdout);
					qry_valuesCntrl1[0] = "WTAPLReleaseDateStamp";
					qry_valuesCntrl1[1] = "WTAPLReleaseDateStamp";
					qry_valuesCntrl1[2] = "0";
					ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
					printf("\nNumber of control object found :%d", control_number_found1);fflush(stdout);

					if(control_number_found1>0)
					{
						getCurrentDateTime(cCurrentAccessDate);
						printf("\n AcCurrentAccessDate:%s", cCurrentAccessDate);
						ITKCALL(AOM_ask_value_string(list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &ExePath));
						printf("\n Information one  :%s \n", ExePath);fflush(stdout);
						syscommand = (char *)MEM_alloc(500);
						tc_strcpy(syscommand, ExePath);
						tc_strcat(syscommand, " ");
						tc_strcat(syscommand, cpyDMLNo);
			
						printf("\ncommand : %s", syscommand);
						printf("\n consuming utility to update APL Release Date Start");fflush(stdout);
						system(syscommand);
						printf("\n consuming utility to update APL Release Date end");fflush(stdout);
					}
				}
			}
			else if(tc_strstr(PlantName,"STD")!=NULL)
			{
				printf("\n Stamping to be stamp on DML Stdrlzdlc: %s \n",Stdrlzdlc);fflush(stdout);
				ITKCALL( RELSTAT_create_release_status(Stdrlzdlc, &partStatusTask));
				ITKCALL(RELSTAT_add_release_status(partStatusTask, 1, &dml_rev_tag, retain));
				printf("\nLCS Updated on DML at STD Level");fflush(stdout);
			}
			else
			{
				printf("\n LCS not valod for plant");
			}

			printf("\nLCS Updated on DML");fflush(stdout);
		}
		else
		{
			ITKCALL(AOM_ask_value_string( dml_rev_tag, "item_id", &Task_no));
			printf("\n Task Number item_id %s ",Task_no);

			char* Dsgn_No = NULL;
			char* PLT_Code = NULL;
			Dsgn_No = tc_strtok(Task_no, "_");
			printf("\nTest0.11..Dsgn_No:[%s],[%s]\n", Dsgn_No, Task_no);fflush(stdout);
			Dsgn_No = tc_strtok(NULL, "_");
			printf("\nTest0.12..Dsgn_No:[%s],[%s]\n", Dsgn_No, Task_no);fflush(stdout);
			PLT_Code = tc_strtok(NULL, "_");
			printf("\nTest0.13..PLT_Code:[%s],[%s]\n", PLT_Code, Task_no);fflush(stdout);

			//function calling to get release status
			get_CtrlVal_APLStateInf(PLT_Code, AplRvwLC, AplWrkngLC, AplRlzdLc, Stdwrknglc, Stdrlzdlc, PltLcs, StdPlant, StdRevRule, StdCLosRule, StdView);

			if(tc_strstr(PlantName,"APL")!=NULL)
			{
				printf("\nStamping to be stamp on DML AplRlzdLc: %s \n",AplRlzdLc);fflush(stdout);
				ITKCALL( RELSTAT_create_release_status(AplRlzdLc, &partStatusTask));
				ITKCALL(RELSTAT_add_release_status(partStatusTask, 1, &dml_rev_tag, retain));
				printf("\nLCS Updated on DML at APL lecvel");fflush(stdout);
			}
			else if(tc_strstr(PlantName,"STD")!=NULL)
			{
				printf("\nStamping to be stamp on DML Stdrlzdlc: %s \n",Stdrlzdlc);fflush(stdout);
				ITKCALL( RELSTAT_create_release_status(Stdrlzdlc, &partStatusTask));
				ITKCALL(RELSTAT_add_release_status(partStatusTask, 1, &dml_rev_tag, retain));
				printf("\nLCS Updated on DML at STD Level");fflush(stdout);
			}
			else
			{
				printf("\n LCS not valod for plant");
			}
			printf("\nLCS Updated on DML");fflush(stdout);
		}
	}

}

extern EPM_decision_t DLLAPI std_dml_default_group_checks_Func(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int status;
	tag_t			rootTask				=NULLTAG;
	tag_t			qryTagCntrl				=NULLTAG;
	tag_t			objTypeTag				=NULLTAG;
	tag_t			dml_rev_tag				=NULLTAG;
	tag_t			user_tag 				=NULLTAG;
	tag_t			*TargetAttch			=NULLTAG;
	tag_t			*member_tags			=NULLTAG;

	tag_t			*Dflt_grp_cntrl_tags	=NULLTAG;
	

	char			*CurrentTask			=NULL;
	char			*parent_name			=NULL;
	char			*Task_no				=NULL;
	char			*DML_no					=NULL;
	char			*Aplplannergroup				=NULL;
	char			*DisAplplannergroup				=NULL;
	char			*Aplreviwergroup				=NULL;
	char			*Stdreviwergroup				=NULL;
	char			*AplParticipant					=NULL;
	char			*Dsgn_No						= NULL;
	char			*PLT_Code						= NULL;
	char			*DmlNO							= NULL;
	char			*PLT_CodeS						= NULL;
	char			*APL_Plnr_Grp					= NULL;
	char			*userid							= NULL;
	char			*Plantname							= NULL;
	char			*Planner							= NULL;
	char			*CurrentDgnGrp						= NULL;

	char			*type_name							=NULL;
	char 			rolename[SA_name_size_c+1];

	int				iNumAttch			=0;
	int				n_entrycoCntrl		=3;

	int				grp_control_number_found		=0;
	int				defaultgroupplannerflag			=0;
	int				defaultgroupreviewerflag		=0;
	int				*num_of_members					=0;


	char*		ReviwerPlantname	= NULL;
	char*		ReviwerCurrentDgnGrp	= NULL;
	char*		Reviwer	= NULL;
	char*		TskGrp	= NULL;
	char*		info3	= NULL;

	Plantname=(char *) MEM_alloc(100 * sizeof(char *));
	ReviwerPlantname=(char *) MEM_alloc(100 * sizeof(char *));
	CurrentDgnGrp=(char *) MEM_alloc(100 * sizeof(char *));
	ReviwerCurrentDgnGrp=(char *) MEM_alloc(100 * sizeof(char *));
	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));
	Planner=(char *) MEM_alloc(100 * sizeof(char *));
	Reviwer=(char *) MEM_alloc(100 * sizeof(char *));

	char    *qry_dlt_grp_entryCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};
	char	**qry_dlt_grp_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));

	printf("\nInside STD_dml_default_group_checks_Func");fflush(stdout);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n STD_dml_default_group_checks_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);

	char* group =(char*) MEM_alloc(200);

	
	if(QRY_find2("Control Objects...", &qryTagCntrl));
	if (qryTagCntrl)
	{
		printf("\nDefault group Control Object Query Found \n");fflush(stdout);
		qry_dlt_grp_valuesCntrl[0]="StdPlannerandReviewer";
		qry_dlt_grp_valuesCntrl[1]="DefaultGroup";
	
		qry_dlt_grp_valuesCntrl[2]="0";

		if(QRY_execute(qryTagCntrl, n_entrycoCntrl, qry_dlt_grp_entryCntrl, qry_dlt_grp_valuesCntrl, &grp_control_number_found, &Dflt_grp_cntrl_tags));
	}
	printf("\nNo of control object found for default group:%d\n",grp_control_number_found);fflush(stdout);

	if (grp_control_number_found >0)
	{

		ITKCALL(AOM_ask_value_string(Dflt_grp_cntrl_tags[0],"t5_Userinfo3",&info3));
		//ITKCALL(AOM_ask_value_string(Dflt_grp_cntrl_tags[0],"t5_Userinfo2",&info2));
		printf("\n STD designeranddReviewer info3: %s ",info3);fflush(stdout);
	
		ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &TargetAttch) );
		printf("\nNo of Target Attachements:%d\n",iNumAttch);fflush(stdout);

		if (iNumAttch>0)
		{	dml_rev_tag = TargetAttch[0];
			ITKCALL(TCTYPE_ask_object_type(dml_rev_tag,&objTypeTag));
    		ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			
			
			 printf("\n workspaceobject  type_name :   %s\n", type_name);fflush(stdout);

			//if (tc_strcmp(CurrentTask,"DefaultGroup")==0)
			if (tc_strcmp(CurrentTask,info3)==0)
			{

				ITKCALL(AOM_ask_value_string( dml_rev_tag, "item_id", &Task_no));
				ITKCALL(AOM_ask_value_string( dml_rev_tag, "current_id", &DML_no));
				ITKCALL(AOM_ask_value_string( dml_rev_tag, "t5_crdesigngroup", &TskGrp));
				printf("\n\n\t\t current task item id and group : %s and %s",Task_no,TskGrp);fflush(stdout);

				
				char* DMLNO		=tc_strtok(Task_no,"_");
				char* Dsgn_No	=tc_strtok(NULL,"_");
				char* DMLPlant	=tc_strtok(NULL,"_");

				printf("\n\n\t\t inside STD task :DMLNO : Designgrp:DMLPlant  : [%s][%s][%s]",DMLNO,Dsgn_No,DMLPlant);fflush(stdout);
		
				/*ITKCALL(AOM_UIF_ask_value( dml_rev_tag, "Analyst", &DisAplplannergroup));
				printf("\n\n\t\t STD Planner Assigned Group :  %s\n",DisAplplannergroup);fflush(stdout); //APLCAR/00_APLC_Planner/APLPlanner
				
				Plantname	=tc_strtok(DisAplplannergroup,"/"); //APLCAR
				CurrentDgnGrp	=tc_strtok(NULL,"/");			//00_APLC_Planner
				Planner	=tc_strtok(NULL,"/");					//APLPlanner
				
				printf("\n\nplant group and planner :  [%s] : [%s] AND [%s]\n",Plantname,CurrentDgnGrp,Planner);fflush(stdout);
				
				printf("\n\ncurrent group and dml group;  %s and %s\n",CurrentDgnGrp,Dsgn_No);fflush(stdout);


				if((tc_strstr(CurrentDgnGrp,"STD")!=NULL) && (tc_strstr(CurrentDgnGrp,"Analyst")!=NULL)&& (tc_strstr(CurrentDgnGrp,"Default")==NULL ))				
				{
					printf("\n STD Analyst is assigned as per group\n");fflush(stdout);
					defaultgroupplannerflag++;
				}

				ITKCALL(AOM_UIF_ask_value( dml_rev_tag, "ChangeSpecialist1", &Stdreviwergroup));
				printf("\n\n\t\t STD Assigned  reviewer Group :  %s\n",Stdreviwergroup);fflush(stdout);

				ReviwerPlantname	=tc_strtok(Stdreviwergroup,"/");
				ReviwerCurrentDgnGrp	=tc_strtok(NULL,"/");
				Reviwer	=tc_strtok(NULL,"/");

				printf("\n\nBefore Reviewer:Plant group and reviewer:[%s]: %s and %s\n",ReviwerPlantname,ReviwerCurrentDgnGrp,Reviwer);fflush(stdout);
				
				if( (tc_strstr(ReviwerPlantname,"STD")!=NULL) && (tc_strstr(ReviwerCurrentDgnGrp,"Reviewer")!=NULL) && (tc_strstr(ReviwerCurrentDgnGrp,"Default")==NULL) )					
				{
					printf("\n std  reviewer as per group\n");fflush(stdout);
					defaultgroupreviewerflag++;

				}
				*/

				tag_t	relation_type	= NULLTAG;
				tag_t*	Part_objects	= NULLTAG;
				int		part_cnt	= 0;

				char*	tcParobject_name	= NULL;
				char*	changeDMUReviewGrp	= NULL;
				char*	AnaDgnReviewr	= NULL;
				char*	anlstDsngrReviewGrp	= NULL;
				tag_t	ObjTypDmlCRB	= NULLTAG;

				ITKCALL(GRM_find_relation_type("HasParticipant", &relation_type));
				ITKCALL(GRM_list_secondary_objects_only(dml_rev_tag, relation_type, &part_cnt, &Part_objects));
				printf("\n partcipant_cnt : [%d]\n",part_cnt);fflush(stdout);
				if (part_cnt > 0)
				{
					int ptcnt = 0;

					for (ptcnt= 0; ptcnt<part_cnt;ptcnt++ )
					{
						
						tcParobject_name	= NULL;
						AnaDgnReviewr		= NULL;
						anlstDsngrReviewGrp	= NULL;
						ObjTypDmlCRB		= NULLTAG;
						
						ITKCALL(TCTYPE_ask_object_type(Part_objects[ptcnt],&ObjTypDmlCRB));
					
						
						ITKCALL( TCTYPE_ask_name2	(ObjTypDmlCRB,&tcParobject_name));
						
						printf("\n\n\t\t Analyst and ChangeSpecialist1 tcParobject_name :   %s\n",tcParobject_name);
						fflush(stdout);
						if (tc_strcmp(tcParobject_name,"Analyst")==0)
						{
						
							ITKCALL(AOM_UIF_ask_value(Part_objects[ptcnt],"fnd0AssigneeUser",&AnaDgnReviewr));
							ITKCALL(AOM_UIF_ask_value(Part_objects[ptcnt],"assignee",&anlstDsngrReviewGrp));
							printf("\n TASK: Analyst: [%s] Group: [%s] ",AnaDgnReviewr,anlstDsngrReviewGrp);fflush(stdout);
							// TASK: DMU Reviewer: [Ketan Bhut (kbb910337)] Group: [MBOM/MBOM_Default/Ketan Bhut (kbb910337)]

							Plantname = tc_strtok(anlstDsngrReviewGrp, "/"); // APLCAR
							CurrentDgnGrp = tc_strtok(NULL, "/");           // 00_APLC_Planner
							Planner = tc_strtok(NULL, "/");                 // APLPlanner

							printf("\n\n\t\t plant group and Desinger :  [%s] : [%s] :[%s] AND [%s]\n", Plantname, CurrentDgnGrp, Planner, Dsgn_No);fflush(stdout);
							
							if ((tc_strstr(CurrentDgnGrp, "STD") != NULL) && (tc_strstr(CurrentDgnGrp, "Analyst") != NULL) && (tc_strstr(CurrentDgnGrp, "Default") == NULL))
							{
								printf("\n STD Analyst is assigned to as per group\n");
								fflush(stdout);
								defaultgroupplannerflag++;
							}
							
						}
						else
						{
							printf("\n\n\t INSIDE condition Analyst and ChangeSpecialist1 tcParobject_name :   %s\n",tcParobject_name);
							fflush(stdout);
							if (tc_strcmp(tcParobject_name,"ChangeSpecialist1")==0)
							{
							
								ITKCALL(AOM_UIF_ask_value(Part_objects[ptcnt],"fnd0AssigneeUser",&AnaDgnReviewr));
								ITKCALL(AOM_UIF_ask_value(Part_objects[ptcnt],"assignee",&changeDMUReviewGrp));
								printf("\n TASK: DMU Reviewer: [%s] Group: [%s] ",AnaDgnReviewr,changeDMUReviewGrp);fflush(stdout);
								// TASK: DMU Reviewer: [Ketan Bhut (kbb910337)] Group: [MBOM/MBOM_Default/Ketan Bhut (kbb910337)]
								
								
								ReviwerPlantname = tc_strtok(changeDMUReviewGrp, "/");
								ReviwerCurrentDgnGrp = tc_strtok(NULL, "/");
								Reviwer = tc_strtok(NULL, "/");

								printf("\n\n\t\tBefore Reviewer:Plant group and reviewer:[%s] : [%s] and [%s]\n", ReviwerPlantname, ReviwerCurrentDgnGrp, Reviwer);
								// Before Reviewer:Plant group and reviewer:[MBOM] : [00_MBOM_Managers] and [Amar Kate (akk923977)]
								fflush(stdout);

								
								if ((tc_strstr(ReviwerCurrentDgnGrp, "STD") != NULL)  && (tc_strstr(ReviwerCurrentDgnGrp, "Reviewer") != NULL) && (tc_strstr(ReviwerCurrentDgnGrp, "Default") == NULL))
								{
									printf("\n STD reviewer is assigned to as per group\n");
									fflush(stdout);
									defaultgroupreviewerflag++;
								}
								
								
							}
							else
							{
								printf("\n No  Analyst and Change Specialist1 \n");fflush(stdout);
									
							}
						}
					}
					
				}
				

				printf("\n\n Both analyst and Reviewer flag  : %d and %d",defaultgroupplannerflag,defaultgroupreviewerflag);fflush(stdout);
				
				if ((defaultgroupplannerflag == 0 ) && (defaultgroupreviewerflag == 0))
				{
					printf("\n\n Both analyst and Reviewer flag  : %d",defaultgroupplannerflag,defaultgroupreviewerflag);fflush(stdout);

					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err, "Please assign Analyst and ChangeSpecialist1.");
					decision = EPM_nogo;
					return ITK_err;

				}
				else if (defaultgroupplannerflag == 0)
				{
					printf("\n\n inside planner flag ");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err, "Please assign Analyst.");
					decision = EPM_nogo;
					return ITK_err;
				}
				else if (defaultgroupreviewerflag == 0)
				{
					printf("\n\n inside Reviwer flag ");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err, "Please assign ChangeSpecialist1");
					decision = EPM_nogo;
					return ITK_err;

				}
				else
				{

					decision = EPM_go;
				}
			}
			
		}
	
	}
	else
	{
		printf("\n\n Default group control objects are not found  : %d",grp_control_number_found);fflush(stdout);
		decision = EPM_go;
	
	}
	
	return decision;

}
//venkat end



int Save_APLTask_Msg( METHOD_message_t *msg, va_list  args )
{

    tag_t	TaskTag		= va_arg(args, const tag_t);

	tag_t	EM_Tag				= NULLTAG;
	tag_t	DeptHead_Tag		= NULLTAG;
	tag_t	participant_type	= NULLTAG;
	tag_t	participant_tag		= NULLTAG;
	tag_t	relation_type		= NULLTAG;
	tag_t	relation			= NULLTAG;
	tag_t	participant_type2	= NULLTAG;
	tag_t	participant_type3	= NULLTAG;
	tag_t	participant_type4	= NULLTAG;
	tag_t	participant_type5	= NULLTAG;
	tag_t	participant_tag2	= NULLTAG;
	tag_t	participant_tag3	= NULLTAG;
	tag_t	participant_tag4	= NULLTAG;
	tag_t	participant_tag5	= NULLTAG;
	tag_t	relation_type2		= NULLTAG;
	tag_t	relation2			= NULLTAG;
	tag_t	objTypeTag			= NULLTAG;
	tag_t	objTypeTag2			= NULLTAG;
	tag_t	objTypeTag3			= NULLTAG;
	tag_t	objTypeTag4			= NULLTAG;
	tag_t	CR_rel_type			= NULLTAG;
	tag_t	CR_Asgn_Part		= NULLTAG;
	tag_t	ObjTypCR			= NULLTAG;
	tag_t	Grp_tag				= NULLTAG;
	tag_t	Grp_tag1			= NULLTAG;
	tag_t	Grp_tag2			= NULLTAG;
	tag_t	Grp_tag3			= NULLTAG;
	tag_t	CR_GrHd_Tag			= NULLTAG;
	tag_t	CR_GrHd_Tag1			= NULLTAG;
	tag_t	CR_GrHd_Tag2			= NULLTAG;
	tag_t	CR_EM_Tag			= NULLTAG;

	int		error_code	= ITK_ok;
	int		ifail		= 0; 
	int		Relcount	= 0; 
	int		jk			= 0; 
	int		No_EM		= 0; 
	int		iii			= 0; 
	int		ii			= 0; 
	int		ij			= 0; 
	int		No_GH		= 0; 
	int		No_GH1		= 0; 
	int		No_GH2		= 0; 
	
	char *itemid 			= NULL;
	char *PRTaskRlzd 			= NULL;
	char *ChangeType 			= NULL;
	char *EstPlanner 	   = NULL;
	char *EstReviewer 	   = NULL;
	char *EstPlntName 	   = NULL;
	char *CR_PlantName 	   = NULL;
	char *CR_GrpHead 	   = NULL;
	char *CRAssignee 	   = NULL;
	char *groupName 	   = NULL;
	char *PsdRoleName 	   = NULL;
	char *member_name 	   = NULL;
	char *member_name1 	   = NULL;
	char *member_name2 	   = NULL;
	char*		PRTaskCreator				= NULL;

	//const char*   CR_EM_role = "CR_ERC_EM";
	const char*   ES_Planner_role = "ES_Planner";
	const char*   ES_Reviewer_role = "ES_Reviewer";

	tag_t *tags_found = NULL;
	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t* RelCRTags = NULLTAG;
	tag_t*  EMTags		= NULLTAG;
	tag_t*  GHTags		= NULLTAG;
	tag_t*  GHTags1		= NULLTAG;
	tag_t*  GHTags2		= NULLTAG;

	//API change
	//char   type_name[TCTYPE_name_size_c+1];
	char   *type_name =NULL;
	char   type_name1[TCTYPE_name_size_c+1];
	char   type_name2[TCTYPE_name_size_c+1];
	char   type_name3[TCTYPE_name_size_c+1];
	char   userid[SA_user_size_c+1];
	WSO_search_criteria_t  	criteria;

	groupName = (char	*)MEM_alloc(100);
	PsdRoleName = (char	*)MEM_alloc(100);
	tc_strcpy(groupName,"EstimateSheet_WF");
	printf("\n MT: groupName  --> %s\n",groupName);   fflush(stdout);

    printf("\n **************inside Save_CR_Msg***************\n ");fflush(stdout);

	if(TCTYPE_ask_object_type(TaskTag,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

	AOM_ask_value_string( TaskTag, "item_id", &itemid);
	printf("\n itemid     %s\n", itemid);fflush(stdout);

	//AOM_ask_value_logical( TaskTag,"t5_PrTaskRelSTD", &PRTaskRlzd);
	//printf("\n PRTaskRlzd     %s\n", PRTaskRlzd);fflush(stdout);

	//AOM_ask_value_string( TaskTag, "t5_b2changetype", &ChangeType);
	//printf("\n ChangeType     %s\n", ChangeType);fflush(stdout);

	//if(strcmp(type_name,"T5_APLTaskRevision")==0  &&  strcmp(PRTaskRlzd,"True")==0  && strcmp(ChangeType,"PR")==0 && tc_strstr(itemid,"_PR")!=NULL)
	if(strcmp(type_name,"T5_APLTaskRevision")==0  && tc_strstr(itemid,"_PR")!=NULL)
	{
		printf("\n inside PR Task created by User... ");fflush(stdout);

		 //printf("\n Test1 ");   fflush(stdout);
		 //AssignSTDAnalystPR(TaskTag);

		 printf("\n Test2 ");   fflush(stdout);
		 AssignSTDReviewerPR(TaskTag);

	}
    return error_code;
}

int CheckPrtRelsFrmPlant_STD(tag_t TaskTag,char ***SetChildRelErr,int *icount) 
{
	char* inp_Tsk_no=NULL;
	tag_t relation_type	=NULLTAG;
	tag_t	*prtList				=	NULLTAG;
	int prtcnt =0;
	int i,ii=0;
	tag_t prtTAG =NULLTAG;
	char* PartNumbr =NULL;
	int status_count			=0;
	tag_t*	status_list		=NULLTAG;
	char*  ReleaseStatus	=NULL;
	char LcsAPLRlzd[40];
	char LcsSTDRlzd[40];

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
    int cntrlcnt=0;
	int  control_number_found1=0;
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
    tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;
	int     error =0;
	int     errorFlg=0;
	char *partset =NULL;
	int   cnt =0;


	printf("\n###########Inside CheckPrtRelsFrmPlant_STD###################\n");fflush(stdout);

	ITKCALL(AOM_ask_value_string(TaskTag,"item_id",&inp_Tsk_no));
	printf("\n inp_Tsk_no  is :%s",inp_Tsk_no);	fflush(stdout);

	ITKCALL(QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="ChangRefrnces";
		qry_valuesCntrl1[1]="PrtRlsFrmPlnt";
		qry_valuesCntrl1[2]="0";
		
		ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	if (control_number_found1>0)
	{
	if(tc_strstr(inp_Tsk_no,"MM") !=NULL)
	{

	PlantWiseRelStatGMDML(inp_Tsk_no,LcsAPLRlzd,LcsSTDRlzd);
	printf("\n LcsSTDRlzd: %s \n",LcsSTDRlzd);

	ITKCALL(GRM_find_relation_type("CMReferences",&relation_type));
	if (relation_type != NULLTAG)
	{
		ITKCALL(GRM_list_secondary_objects_only(TaskTag,relation_type,&prtcnt,&prtList));
		printf("\nNumber of parts found in Reference Folder : %d",prtcnt);fflush(stdout);
		if (prtcnt > 0)
		{
			for (i=0;i<prtcnt;i++)
			{
				prtTAG=prtList[i];
				error =0;
				status_count =0;

				ITKCALL(AOM_ask_value_string(prtTAG,"item_id",&PartNumbr));
				printf("\n PartNumbr  is :%s",PartNumbr);	fflush(stdout);

				ITKCALL(WSOM_ask_release_status_list(prtTAG,&status_count,&status_list));
				printf("\n status_count : %d",status_count);fflush(stdout);

				if ((status_count>0)&&(tc_strcmp(LcsSTDRlzd,"") !=0))
				{
				
				for (ii= 0;ii<status_count;ii++)
				{
                    ReleaseStatus=NULL;
					ITKCALL(AOM_ask_name(status_list[ii], &ReleaseStatus));
					printf("\n ReleaseStatus %s \n",  ReleaseStatus);fflush(stdout);
					if (tc_strcmp(ReleaseStatus,LcsSTDRlzd)==0)
					{
					  error++;
                      printf("\n part is released from plant.");fflush(stdout);
					  break;
					}
					
				}
				}
				printf("\n error : %d",error);fflush(stdout);
				if (error==0)
				{
					 
					 if (tc_strcmp(partset,"NULL") !=0) MEM_free(partset);
						 partset=(char *)MEM_alloc(1000);
						 
					 if (cnt==0)
					  {
						cnt =1;
						tc_strcpy(partset," ");
						tc_strcat(partset,"\n");
						tc_strcat(partset,"Below parts is not released from plant.\n");
						tc_strcat(partset,PartNumbr);
						
					  }
					  else
					   {
						  tc_strcat(partset," , ");
						  tc_strcat(partset,PartNumbr);
						
						  cnt = cnt+1;   
						   
					   }
					   
					   printf("\n Value of cnt is:%d",cnt);fflush(stdout);
					   printf("\n partset is: %s",partset);fflush(stdout);

					   if(cnt==1)
						 { 
							 printf("\n INSIDE if cnt...");fflush(stdout);
							 setAddStrFuction(icount,SetChildRelErr,partset);
							 cntFlag = 1;
						  }
					   else
						  {
							  printf("\n INSIDE else cnt...");fflush(stdout);
							  setAddStrFuction(icount,SetChildRelErr,partset);
							  cntFlag = 1;
						  }
				}
            }


		}
	}
	}
	}


	return 0;
}

//////////////////////////cbb STD validations calling ///////////////////////////////////////
int apl_std_dml_signoff_checks_Func( EPM_action_message_t msg )
{
	//int ifail = ITK_ok;
	int errorrpt = 0;
	EPM_decision_t decision;
	int status,i1;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int count_child = 0;
	int   attribute_act_tak;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char *Item_id = NULL;
	//muskan//
	char *AplStdRemarks = NULL;
	char *StdtaskDecision = NULL;
	char *StdTaskDecisionDate = NULL;
	//muskan//
	
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	int i = 0;
	int j = 0;
	int n = 0;
	int stampingdone=0;
	int iGChld = 0;
	char*	itemid;
	char*	itemid1;
	char *  ChildRelErr = NULL;
	//char *  SetStdRelErr = NULL; //added by dss 1.53
	char	**SetStdRelErr = NULL;//Make a string array added by dss 1.53
	int		icount	=	0;//added for dynamic memory allocation; added by dss 1.53
	int		icountprev	=	0;//added for dynamic memory allocation; added by dss 1.53
	char  **SetPrevRevNotification=NULL;
	char*	childPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char *dml_no_id=NULL;	//Deepti  Added TZ1.53
	char *dml_ecnType=NULL;	//Deepti  Added TZ1.53
	//API change
	//char  type_name[TCTYPE_name_size_c+1];
	char *type_name = NULL;

	//API change
	//char  type_itemRev[TCTYPE_name_size_c+1];
	char *type_itemRev = NULL;
	char  ChildRevtype_name[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Childtop_line							= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag							= NULLTAG;
	tag_t	item_rev_tag1							= NULLTAG;
	tag_t	itemTypeTag_cdss							= NULLTAG;
	tag_t	*itemclassp	= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t	value_child_details							= NULLTAG;
	char  req_id[ITEM_id_size_c+1];
	tag_t  *children;
	tag_t  *totalchildren;
	tag_t  	value_act_Tak;
	tag_t  	item_rev_cld_tag;
	tag_t*			PartTags			= NULLTAG;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				ii				= 0;
	char*			value					=NULL;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	char*			Part_no				= NULL;
	int       st_count=0;
	int       iLCS=0;
	int       cntLcs=0;
	int				BypassNACSFlag=0;
	int				BypassAMDMLFlag=0;



    tag_t dml_rev_tag = NULLTAG;
	char			*DML_no					=NULL;
	tag_t*			TaskRevision		= NULLTAG;
	int       TaskCnt=0;
	tag_t			TaskRevTag			= NULLTAG;

	char* SetOfError = NULL ;
	SetOfError = (char* ) malloc ( 500000 * sizeof ( char ) ) ;
	tc_strcpy(SetOfError,"");
	int Ecnt=0;
	tag_t			DMLRevTagg		= NULLTAG;

	

	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	char STDDmlPlnt[40];
	tag_t  CurrentRoleTag = NULLTAG;
	char *TaskTypeName = NULL;
	char *EPAPlant = NULL;
	//API change
	char *roleName = NULL;
	char		   *PlantName =NULL;
	tag_t			StampAssyPreTag			= NULLTAG;
	char*			StampPart_no				=	NULL;
	char*			StampPart_Rev			=	NULL;
	//API change
	char *stamprev_id1 = NULL;
	char *lcsToset=NULL;
	tag_t	relation_type						= NULLTAG;
	cnt = 0;
	cntFlag = 0;
	char	**SetGMErr = NULL;
	tag_t*	prtTasks1		=	NULLTAG;
	tag_t TaskTypeTag1 = NULLTAG;
	int icount1,cntTask1,st_count2=0;
	tag_t TaskTypeTag = NULLTAG;
	char *EPARlzStatusName = NULL;
	char* EPAATaskID2 = NULL;
	char* EPAATasknum = NULL;
	tag_t*    status_list_1=NULLTAG;
	tag_t* EPARlzStatus = NULL;
	char *tmp_EPAATaskID = NULL;
	char ***SetChildRelErr;
	int *i1count=0;
	char	*tempErr	=	0;//1.45 added for dynamic memory allocation
	int		iLength	=	0;//1.45 added for dynamic memory allocation

	tag_t*			RefPartTags			= NULLTAG;
	int				RefPartCnt				= 0;
	char RevisionRule[40];
	char ClosureRule[40];
	char BVR[40];
	char APLDmlPlnt[40];
	char *task_po_check=NULL;
	int		error_code	= ITK_ok;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    SetGMErr = (char**)MEM_alloc( 1 * sizeof *SetGMErr );
    char	**ChangeRefRelErr = NULL;
	ChangeRefRelErr = (char**)MEM_alloc( 1 * sizeof *ChangeRefRelErr );
	int		Errcnt	=	0;

	printf("\n Calling apl_std_dml_signoff_checks_Func %d.....\n",iNumAttch);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n apl_std_dml_signoff_checks_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
    printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );
	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);
	PlantName=subString(roleName,3,4);
	printf( "PlantName:%s\n", PlantName);

	getPlantDetailsAttr_Std_Rls_type(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency,RevisionRule,ClosureRule,BVR,APLDmlPlnt,STDDmlPlnt);//TZ1.41
	printf("\n PlantCS %s \n",PlantCS);
	printf("\n PlantOptCS %s \n",PlantOptCS);
	printf("\n PlantAgency %s \n",PlantIA);
	printf("\n PlantStore %s \n",PlantStore);
	printf("\n UserAgency %s \n",UserAgency);
	printf("\n STDDmlPlnt %s \n",STDDmlPlnt);
    printf( "\t\t\t PlantName:%s\n", PlantName);
   //  if(tc_strcmp(CurrentTask,"Create EPA" )==0)
	//{
	ITKCALL( TCTYPE_find_type("T5_APLTaskRevision", NULL, &ItemTypeTag));
	printf("\n iNumAttch %d.....\n",iNumAttch);
	for (i=0; i < iNumAttch; i++)
	{
		dml_rev_tag = pTagAttch[i];
		tag_t objTypeTag = NULLTAG;
		tag_t objChildRevTag = NULLTAG;
		const char *qry_entries[1];
		const char *qry_values[1];
//		char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
//		char **values = (char **) MEM_alloc(1 * sizeof(char *));
		int n_tags_found=0;
		tag_t	*itemclass	= NULLTAG;
		tag_t item = NULLTAG;
		char *PlanBusiness_Unit=NULL;

	ITKCALL(AOM_ask_value_string( dml_rev_tag, "item_id", &DML_no));
	printf("\n DML Number item_id %s ",DML_no);  //chetan
	ITKCALL(AOM_ask_value_string( dml_rev_tag, "t5_ERCBusiUt", &PlanBusiness_Unit));
	printf("\n PlanBusiness_Unit.. %s \n",PlanBusiness_Unit);fflush(stdout);
	
		char    *qry_entryCntrl7[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
		char	**qry_valuesCntrl7= (char **) MEM_alloc(5 * sizeof(char *));
		int cntrlcnt=0;
		int  control_number_found7=0;
		tag_t *list_of_WSO_cntrl_tags7=NULLTAG;
		tag_t   qryTagCntrl7     = NULLTAG;
		int     n_entryCntrl7    = 3;
		 
		if(QRY_find2("Control Objects...", &qryTagCntrl7));
		if (qryTagCntrl7)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrl7[0]="KSP";

			qry_valuesCntrl7[1]="BYPASS";
			
			qry_valuesCntrl7[2]="0";
			
		if(QRY_execute(qryTagCntrl7, n_entryCntrl7, qry_entryCntrl7, qry_valuesCntrl7, &control_number_found7, &list_of_WSO_cntrl_tags7));
		}
		else
		{
			printf("\n KSP BYPASS Control Object Query not Found \n");fflush(stdout);
		}

		printf("\n control_number_found7 is : %d\n",control_number_found7);fflush(stdout);
			
	if(control_number_found7>0)
	{
	if(tc_strstr(PlanBusiness_Unit,"CV")!=NULL)
	{
		ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
		ITKCALL(GRM_list_secondary_objects_only(dml_rev_tag,relation_type,&count,&TaskRevision));
		printf("\n\n\t\t APL DML Cre:ERC DML to Task : %d",count);fflush(stdout);

	for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
	{
		TaskRevTag = TaskRevision[TaskCnt];
		ITKCALL(AOM_ask_value_string(TaskRevTag, "item_id",&itemid));
		printf("\n itemid %s.....\n",itemid);
		qry_entries[0] ="item_id";
		qry_values[0] = itemid;

		ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
		 item = itemclass[0];
		if(item != NULLTAG )
		ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));
					
		int PartCntB1,icount_Clr2basedf=0;
		tag_t*			PartTagsB1		= NULLTAG;
		char*			PrntStampPart_no				= NULL;

		//muskan code start//
		
		/*		if(tc_strcmp(PlantName,"STDC")!= 0)
				{
			    ITKCALL(AOM_ask_value_string(pTagAttch[i],"t5_AplStdRemrks",&AplStdRemarks));
				 printf("\nAplStdRemarks is: %s",AplStdRemarks);
				
					 if(strcmp(AplStdRemarks,"")==0)
						{
							printf("\n  under the error  statment\n");fflush(stdout);
							char *t5MlStIntialErr=NULL;



							t5MlStIntialErr = (char *) MEM_alloc( 1000 * sizeof(char) );
							strcpy(t5MlStIntialErr,"");
							strcpy(t5MlStIntialErr,"Please fill APL/STDS remark before signoff the task.\n Select the Task ->Go to ->Manufacturing Menu->Implementation-->APL/STDS Reamrk Update");//manindra Added Path
							
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStIntialErr);
							return 1;
	
						}

			  ITKCALL(AOM_ask_value_string(pTagAttch[i],"t5_StdTaskDecision",&StdtaskDecision));
				   printf("\nStdtaskDecision is: %s",StdtaskDecision);
				 
				 if(strcmp(StdtaskDecision,"")==0)

						{
							printf("\n  under the error  statment\n");fflush(stdout);
							char *t5MlStIntialErr=NULL;



							t5MlStIntialErr = (char *) MEM_alloc( 1000 * sizeof(char) );
							strcpy(t5MlStIntialErr,"");
							strcpy(t5MlStIntialErr,"Please fill STD Decision on Task before signoff the Task.\n Select the Task ->Go to ->Manufacturing Menu->Implementation-->APL/STDS Reamrk Update"); //manindra Added Path
							
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStIntialErr);
							return 1;
	
						}

                    ITKCALL(AOM_ask_value_string(pTagAttch[i],"t5_StdTaskDecisionDate",&StdTaskDecisionDate));
                       printf("\nStdTaskDecisionDate is: %s",StdTaskDecisionDate);
	                
					if(strcmp(StdTaskDecisionDate,"")==0)

							{
								printf("\n  under the error  statment\n");fflush(stdout);
								char *t5MlStIntialErr=NULL;

 

								t5MlStIntialErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStIntialErr,"");
								strcpy(t5MlStIntialErr,"Please fill STD Decision Date against APL-Task before signoff the Task.\n Select the Task ->Go to ->Manufacturing Menu->Implementation-->APL/STDS Reamrk Update");//manindra Added Path
								
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStIntialErr);
								return 1;
		
							}

			   	}  */
                   //muskan end of code//
		
		printf("\n Akhilesh entering validation code .....\n");
		
		ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCntB1,&PartTagsB1));
			printf("\n\n\t\t APL DML Cre:Now PartCntB1:%d",PartCntB1);fflush(stdout);
			
		/*********** check for part stamp attribute for TZ UA1.73 SCO 9643********/
		
		char    *qry_entryCntrl1[2]  = {"SYSCD","Delete Indicator"};	
		char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
		int cntrlcnt=0;
		int  control_number_found1=0;
		tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
		tag_t   qryTagCntrl1     = NULLTAG;
		int     n_entryCntrl1    = 2;
		 
		if(QRY_find2("Control Objects...", &qryTagCntrl1));
		if (qryTagCntrl1)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrl1[0]="SMEPAStampCntObj";
			
			qry_valuesCntrl1[1]="0";
			
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		}
		else
		{
			printf("\n Akki Control Object Query not Found \n");fflush(stdout);
		}

		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
		
		int allErrMsg=0;
		char* AllerrorDup = NULL ;
		AllerrorDup = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
		tc_strcpy(AllerrorDup,"");
		
		if(control_number_found1>0)
		{
			
			for (i1=0; i1 < PartCntB1; i1++)
			{
				tag_t objTypeTag = NULLTAG;
				tag_t objChildRevTag = NULLTAG;
				const char *qry_entries1[1];
				const char *qry_values1[1];			
				int n_tags_found1   =0;
				tag_t	*itemclass1	= NULLTAG;
				tag_t item1         = NULLTAG;

				ITKCALL(AOM_ask_value_string(PartTagsB1[i1], "item_id",&itemid1));
				printf("\n itemid1 %s.....\n",itemid1);
				qry_entries1[0] ="item_id";
				qry_values1[0] = itemid1;
				ITEM_find_items_by_key_attributes(1, qry_entries1, qry_values1,&n_tags_found1, &itemclass1);
				 item1 = itemclass1[0];											
				if(tc_strstr(PlantName,"APL")!=NULL)
				{						
					if((tc_strstr(PlantName,"APLC")!=NULL) || (tc_strstr(PlantName,"APLJ")!=NULL) || (tc_strstr(PlantName,"APLL")!=NULL) || (tc_strstr(PlantName,"APLU")!=NULL) || (tc_strstr(PlantName,"APLP")!=NULL) || (tc_strstr(PlantName,"APLD")!=NULL) )
					{			
						ITKCALL(AOM_ask_value_string(PartTagsB1[i1],"item_revision_id",&StampPart_Rev));
						ITKCALL(AOM_ask_value_string(PartTagsB1[i1],"item_id",&PrntStampPart_no));						// For Akki reference						
						printf("\n Neww Validation start from here");
						ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
						ITKCALL( GRM_list_primary_objects_only(PartTagsB1[i1],relation_type,&cntTask1,&prtTasks1));
						printf("\n cntTask1 : %d",cntTask1);fflush(stdout);
						int epaflag=0;														
						if (cntTask1 > 0)
						{
							for (j=0;j<cntTask1;j++ )
							{
								
								ITKCALL(TCTYPE_ask_object_type(prtTasks1[j],&TaskTypeTag));
								ITKCALL(TCTYPE_ask_name2(TaskTypeTag,&TaskTypeName));
								printf("\n TaskTypeName is %s\n",TaskTypeName); fflush(stdout);
																	
							 	if (tc_strcmp(TaskTypeName,"T5_EPATaskRevision")== 0)
								{
								
									if( AOM_ask_value_string(prtTasks1[j],"item_id",&EPAATasknum)==ITK_ok)
									printf("\n Task Attched is %s\n",EPAATasknum); fflush(stdout);														
									tmp_EPAATaskID = strtok(EPAATasknum,"_");
									tmp_EPAATaskID = strtok(NULL,"_");
									EPAPlant = strtok(NULL,"_");
									printf("\n EPAPlant : %s  \n",EPAPlant);fflush(stdout);
									EPARlzStatusName	=	NULL;
									ITKCALL(AOM_UIF_ask_value(prtTasks1[j], "release_status_list", &EPARlzStatusName));
									printf("\n st_count2 (EPATag) = %s ",EPARlzStatusName);fflush(stdout);

											printf("\n EPARlzStatusName (EPATag) : %s \n",EPARlzStatusName);fflush(stdout);
											printf("\n PlantName (EPATag) : %s \n",PlantName);fflush(stdout);
											printf("\n EPAPlant (EPATag) : %s \n",EPAPlant);fflush(stdout);
											
											if(((tc_strstr(PlantName,"APLJ")!=NULL) && (tc_strstr(EPAPlant,"APLJ")!=NULL )&& (tc_strstr(EPARlzStatusName,"STDSIJ Working")!= NULL)) ||
										    ((tc_strstr(PlantName,"APLL")!=NULL) && (tc_strstr(EPAPlant,"APLL")!=NULL)&& (tc_strstr(EPARlzStatusName,"STDSIL Working")!= NULL)) ||
										    ((tc_strstr(PlantName,"APLU")!=NULL) && (tc_strstr(EPAPlant,"APLU")!=NULL) && (tc_strstr(EPARlzStatusName,"STDSIU Working")!= NULL)) ||
										    ((tc_strstr(PlantName,"APLP")!=NULL) && (tc_strstr(EPAPlant,"APLP")!=NULL )&& (tc_strstr(EPARlzStatusName,"STDSIP Working")!= NULL)) ||
										    ((tc_strstr(PlantName,"APLD")!=NULL) && (tc_strstr(EPAPlant,"APLD")!=NULL )&& (tc_strstr(EPARlzStatusName,"STDSID Working")!= NULL)) ||
										    ((tc_strstr(PlantName,"APLA")!=NULL) && (tc_strstr(EPAPlant,"APLA")!=NULL )&& (tc_strstr(EPARlzStatusName,"STDSIA Working")!= NULL)) ||
										    ((tc_strstr(PlantName,"APLS")!=NULL) && (tc_strstr(EPAPlant,"APLS")!=NULL )&& (tc_strstr(EPARlzStatusName,"STDSIS Working")!= NULL)) ||
										    ((tc_strstr(PlantName,"APLC")!=NULL) && (tc_strstr(EPAPlant,"APLC")!=NULL) && (tc_strstr(EPARlzStatusName,"STDSIC Working")!= NULL)))
											{
												
												epaflag=1;
												break;
											}														
								    }
							}
						}
						printf("\n Neww Validation END  here");
						/***************End of Neww validation for SM/EPA check by Akhilesh **************/
						StampAssyPreTag			= NULLTAG;
						if(epaflag==0)
						{
							if(tc_strstr(StampPart_Rev,"NR") != NULL)
							{
								printf("\n Previous revision function can not be called as current revision has NR revision");fflush(stdout);
								
							}
							else
							{
								printf("\n Akki Calling function to get Previous revision ");fflush(stdout);
								
								tm_fnd_Prev_Official_Revision(PrntStampPart_no,PartTagsB1[i1],&StampAssyPreTag);//TZ 1.43
							}
						
							if(StampAssyPreTag)
							{								
								char*			CpyRefDescValue				= NULL;

								ITEM_ask_rev_id2( StampAssyPreTag, &stamprev_id1);
								printf("\n stamprev_id1 is  ---->%s\n", stamprev_id1);fflush(stdout);//diplay the previous revision																																		 								
								ITKCALL(AOM_ask_value_string(StampAssyPreTag,"t5_JdlStoreLocation",&CpyRefDescValue));
								printf("\n\n\t\t Value of Akki CpyRefDescValue  is :%s",CpyRefDescValue);	fflush(stdout);

								if((CpyRefDescValue!=NULL)&&(tc_strcmp(CpyRefDescValue,"")!=0))
								{
									printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);
									if(tc_strstr(PlantName,"APLJ")!=NULL)
									{
										if( tc_strstr(CpyRefDescValue,"EPAJ")!=NULL || tc_strstr(CpyRefDescValue,"SMJ")!=NULL)
										{
											printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);											
											char* errorDup = NULL ;
											errorDup = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
											tc_strcpy(errorDup,"");
											tc_strcat(errorDup,"This Part ");
											tc_strcat(errorDup,PrntStampPart_no);
											tc_strcat(errorDup," previous rev is attached with EPA or SM in TCE, first release it there.");
											allErrMsg=1;
											tc_strcat(AllerrorDup,errorDup);
											printf("\n For APLJ msggg Error Msg :[%s]",AllerrorDup);fflush(stdout);
										}
									}
									else if(tc_strstr(PlantName,"APLP")!=NULL)
									{
										if( tc_strstr(CpyRefDescValue,"EPAP")!=NULL || tc_strstr(CpyRefDescValue,"SMP")!=NULL)
										{
											printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);											
											char* errorDup = NULL ;
											errorDup = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
											tc_strcpy(errorDup,"");
											tc_strcat(errorDup,"This Part ");
											tc_strcat(errorDup,PrntStampPart_no);
											tc_strcat(errorDup," previous rev is attached with EPA or SM in TCE, first release it there.");
											allErrMsg=1;
											tc_strcat(AllerrorDup,errorDup);
											printf("\n For APLP msggg Error Msg :[%s]",AllerrorDup);fflush(stdout);								
										}
									}
									 else if(tc_strstr(PlantName,"APLL")!=NULL)
									{
										if( tc_strstr(CpyRefDescValue,"EPAL")!=NULL || tc_strstr(CpyRefDescValue,"SML")!=NULL)
										{
											printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);									
											char* errorDup = NULL ;
											errorDup = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
											tc_strcpy(errorDup,"");
											tc_strcat(errorDup,"This Part ");
											tc_strcat(errorDup,PrntStampPart_no);
											tc_strcat(errorDup," previous rev is attached with EPA or SM in TCE, first release it there.");
											allErrMsg=1;
											tc_strcat(AllerrorDup,errorDup);
											printf("\n For APLL msggg Error Msg :[%s]",AllerrorDup);fflush(stdout);
										}
									}
									else if(tc_strstr(PlantName,"APLD")!=NULL)
									{
										if( tc_strstr(CpyRefDescValue,"EPAD")!=NULL || tc_strstr(CpyRefDescValue,"SMD")!=NULL)
										{
											printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);										
											char* errorDup = NULL ;
											errorDup = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
											tc_strcpy(errorDup,"");
											tc_strcat(errorDup,"This Part ");
											tc_strcat(errorDup,PrntStampPart_no);
											tc_strcat(errorDup," previous rev is attached with EPA or SM in TCE, first release it there.");
											allErrMsg=1;
											tc_strcat(AllerrorDup,errorDup);
											printf("\n For APLD msggg Error Msg :[%s]",AllerrorDup);fflush(stdout);
										}
									}
									else if(tc_strstr(PlantName,"APLU")!=NULL)
									{
										if( tc_strstr(CpyRefDescValue,"EPAU")!=NULL || tc_strstr(CpyRefDescValue,"SMU")!=NULL)
										{
											printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);											
											char* errorDup = NULL ;
											errorDup = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
											tc_strcpy(errorDup,"");
											tc_strcat(errorDup,"This Part ");
											tc_strcat(errorDup,PrntStampPart_no);
											tc_strcat(errorDup," previous rev is attached with EPA or SM in TCE, first release it there.");
											allErrMsg=1;
											tc_strcat(AllerrorDup,errorDup);
											printf("\n For APLU msggg Error Msg :[%s]",AllerrorDup);fflush(stdout);
										}
									}
									else if(tc_strstr(PlantName,"APLA")!=NULL)
									{
										if( tc_strstr(CpyRefDescValue,"EPAA")!=NULL || tc_strstr(CpyRefDescValue,"SMA")!=NULL)
										{
											printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);										
											char* errorDup = NULL ;
											errorDup = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
											tc_strcpy(errorDup,"");
											tc_strcat(errorDup,"This Part ");
											tc_strcat(errorDup,PrntStampPart_no);
											tc_strcat(errorDup," previous rev is attached with EPA or SM in TCE, first release it there.");
											allErrMsg=1;
											tc_strcat(AllerrorDup,errorDup);
											printf("\n For APLC msggg Error Msg :[%s]",AllerrorDup);fflush(stdout);
										}
									}
									else if(tc_strstr(PlantName,"APLS")!=NULL)
									{
										if( tc_strstr(CpyRefDescValue,"EPAS")!=NULL || tc_strstr(CpyRefDescValue,"SMS")!=NULL)
										{
											printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);										
											char* errorDup = NULL ;
											errorDup = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
											tc_strcpy(errorDup,"");
											tc_strcat(errorDup,"This Part ");
											tc_strcat(errorDup,PrntStampPart_no);
											tc_strcat(errorDup," previous rev is attached with EPA or SM in TCE, first release it there.");
											allErrMsg=1;
											tc_strcat(AllerrorDup,errorDup);
											printf("\n For APLC msggg Error Msg :[%s]",AllerrorDup);fflush(stdout);
										}
									}
									else if(tc_strstr(PlantName,"APLC")!=NULL)
									{
										if( tc_strstr(CpyRefDescValue,"EPAC")!=NULL || tc_strstr(CpyRefDescValue,"SMC")!=NULL)
										{
											printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);										
											char* errorDup = NULL ;
											errorDup = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
											tc_strcpy(errorDup,"");
											tc_strcat(errorDup,"This Part ");
											tc_strcat(errorDup,PrntStampPart_no);
											tc_strcat(errorDup," previous rev is attached with EPA or SM in TCE, first release it there.");
											allErrMsg=1;
											tc_strcat(AllerrorDup,errorDup);
											printf("\n For APLC msggg Error Msg :[%s]",AllerrorDup);fflush(stdout);
										}
									 }
													
								}
							}
				     	}	
					}
				}
			}

			if(allErrMsg>0)
			{                        
				printf("\n Final Error Msg :[%s]",AllerrorDup);fflush(stdout);
				//tc_strcpy(SetOfError,AllerrorDup);
				tc_strcat(AllerrorDup,"\n");
				tc_strcat(SetOfError,AllerrorDup);
			    Ecnt=1;
                printf("\n Final Error Msg :[%s]",SetOfError);fflush(stdout);
			    printf("\n Ecnt :[%d]",Ecnt);fflush(stdout);			
			}
		}
					
			printf("\n Akhilesh Exiting validation code .....\n");
			//Sanket
			printf("\n Calling CheckPrtRelsFrmPlant_STD ..... \n");

			CheckPrtRelsFrmPlant_STD(item_rev_tag,&ChangeRefRelErr,&Errcnt); //added by dss 1.53
			printf("\n cntFlag_6: %d",cntFlag);fflush(stdout);

			if(cntFlag==1)
			{
				iLength	=	0;
				if (!tempErr) MEM_free(tempErr);
				i=0;
				for (i=0; i < Errcnt; i++)
				{
					tempErr	=	ChangeRefRelErr[i];
					iLength	=	iLength	+	tc_strlen(tempErr);
				}
				printf("iLength : %d",iLength);fflush(stdout);
				if (!tempErr) MEM_free(tempErr);
				tempErr	=	(char *)MEM_alloc(iLength+20);
				i=0;
				for (i=0; i < Errcnt; i++)
				{
					if(i==0)
						tc_strcpy(tempErr,ChangeRefRelErr[i]);
					else
						tc_strcat(tempErr,ChangeRefRelErr[i]);
				}
				printf("\nPrinting Errors...!!!");fflush(stdout);
				printf("%s",tempErr);fflush(stdout);
				tc_strcat(tempErr,"\n");
				tc_strcat(SetOfError,tempErr);
				printf("\n SetOfError: %s\n", SetOfError);//fflush(DmlRelFile);
				//tc_strcpy(SetOfError,tempErr);
				Ecnt=1;
			}
		    //Sanket
			printf("\n itemid %s \n",itemid);
			ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
			ITKCALL( TCTYPE_ask_name2( objTypeTag, &type_name) );
			printf("\t  type_name ...%s\n", type_name);
			printf("\t \n objTypeTag == ItemTypeTag \n");
			ITKCALL (TCTYPE_ask_object_type(item_rev_tag,&itemTypeTag_cdss));
			ITKCALL (TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));
			printf("\t  type_itemRev ...%s\n", type_itemRev);
			SetStdRelErr = (char**)MEM_alloc( 1 * sizeof *SetStdRelErr );
			SetPrevRevNotification = (char**)MEM_alloc( 1 * sizeof *SetPrevRevNotification );

			if(tc_strcmp(type_itemRev,"T5_APLTaskRevision" )==0)
			{
			  tag_t			TskToDMLRel= NULLTAG;
			 // tag_t			DMLRevTagg		= NULLTAG;
			  tag_t			DMLTypeTag		= NULLTAG;
			  tag_t*	    DMLTagg		    = NULLTAG;
			  int           CountDML        = 0;
			  int           Counter         = 0;			  		
			  char          *DMLTyp         = NULL;
			  char*			ProjectCode		= NULL;
			  char*			Release_Type	= NULL;
			  logical		isltstdmll;
			

				printf("\n\n\t\t Test dss .. ");fflush(stdout);
				ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &TskToDMLRel));
				if (TskToDMLRel!=NULLTAG)
				{
					ITKCALL(GRM_list_primary_objects_only(item_rev_tag,TskToDMLRel,&CountDML,&DMLTagg));
					printf("\n\n\t\t dss CountDML : %d",CountDML);fflush(stdout);

					for (Counter=0;Counter<CountDML ;Counter++ )
					{
						ITKCALL(ITEM_rev_sequence_is_latest(DMLTagg[Counter],&isltstdmll));
						printf("\n\n\t\t isltstdmll : %d\n",isltstdmll);fflush(stdout);

						if(isltstdmll != true)
						{
							printf("\n\n\t\t isltstdmll is not true .....\n");fflush(stdout);
						}
						else
						{
							printf("\n\n\t\t isltstdmll is  true .....\n");fflush(stdout);
							DMLRevTagg = DMLTagg[Counter];

							ITKCALL (TCTYPE_ask_object_type(DMLRevTagg,&DMLTypeTag));
							ITKCALL (TCTYPE_ask_name2(DMLTypeTag,&DMLTyp));
							printf("\n DMLTyp= %s \n",DMLTyp);fflush(stdout);

							if(tc_strcmp(DMLTyp,"T5_APLDMLRevision")==0)
							{
							  AOM_ask_value_string( DMLRevTagg, "t5_cprojectcode", &ProjectCode);
  							  printf("\n ProjectCode : %s\n",ProjectCode);fflush(stdout);

							  ITKCALL(AOM_ask_value_string(DMLRevTagg,"t5_rlstype",&Release_Type));
							  printf("\n\t Release_Type is :%s",Release_Type);fflush(stdout);

							  ITKCALL(AOM_ask_value_string(DMLRevTagg,"item_id",&dml_no_id));	//Deepti Added TZ1.53
							  printf("\n\t dml_no_id is :%s",dml_no_id);fflush(stdout);

							   if(tc_strstr(dml_no_id,"AM")!=NULL)
							   {
								    ITKCALL(AOM_ask_value_string(DMLRevTagg,"t5_EcnType",&dml_ecnType));
									printf("\n\t dml_ecnType is :%s",dml_ecnType);fflush(stdout);
							  
							   }
																					
							}
						}
					}
				}

				//Start Adding code for bypass using control object
	
				char    *qry_entryCntrlBypass[4]  	    = 	{"SYSCD","SUBSYSCD","Information-1","Delete Indicator"};	
				char	**qry_valuesCntrlBypass		    = 	(char **) MEM_alloc(5 * sizeof(char *));
				tag_t	qryTagCntrlBypass			    =	NULLTAG;
				int     n_entryCntrlBypass   		    = 	4;
				int		control_number_foundBypass	    =	0;
				tag_t	*list_of_WSO_cntrl_tagsBypass	=	NULLTAG;

				if(QRY_find2("Control Objects...", &qryTagCntrlBypass));
				
				if(qryTagCntrlBypass!=NULLTAG)
				{
					printf("\n Control Object Query Found \n");fflush(stdout);
					qry_valuesCntrlBypass[0]="STD_VALID";
					qry_valuesCntrlBypass[1]="StdCmpltBypass";;
					qry_valuesCntrlBypass[2]=itemid;
					qry_valuesCntrlBypass[3]="0";
					
					if(QRY_execute(qryTagCntrlBypass, n_entryCntrlBypass, qry_entryCntrlBypass, qry_valuesCntrlBypass, &control_number_foundBypass, &list_of_WSO_cntrl_tagsBypass));
					printf("\n No. of control object found for bypass..: %d",control_number_foundBypass);fflush(stdout);
					
					if(control_number_foundBypass>0)
					{
						printf("\n Control object foudn .hence moving to bypass all validation and allow signoff.");fflush(stdout);
						goto BYPASSVALIDATIONS;
					}
					
				}				
						//End Adding code for bypass using control object

	//**Complete BoM check*//	
	  int       PartCntB,icount_Clr2basedf    =0;
	  tag_t*	PartTagsB		= NULLTAG;
	  char	**SetChildRelSTDBomCmErr = NULL;
	  SetChildRelSTDBomCmErr = (char**)MEM_alloc( 1 * sizeof *SetChildRelSTDBomCmErr );
	
		ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCntB,&PartTagsB));
			printf("\n\n\t\t APL DML Cre:Now PartCntB:%d",PartCntB);fflush(stdout);

			//No need
		/*	if (PartCntB>0)
			{			
			   if((tc_strcmp(Release_Type,"Veh")==0) || (tc_strcmp(Release_Type,"CP")==0) || (tc_strcmp(Release_Type,"CM")==0) )
			   {		
				    CompareColorToBase(item_rev_tag,"STD",PartCntB,PartTagsB,&SetChildRelSTDBomCmErr,&icount_Clr2basedf);
					printf("\n SetChildRelSTDBomCmErr icount_Clr2basedf : %d",icount_Clr2basedf);fflush(stdout);			
			   }

		       if ((tc_strcmp(Release_Type,"CP")==0) || (tc_strcmp(Release_Type,"CM")==0)|| (tc_strcmp(Release_Type,"SVR")==0))
			   {		
				    CompareColorToBaseSVR(item_rev_tag,"STD",PartCntB,PartTagsB,&SetChildRelSTDBomCmErr,&icount_Clr2basedf);
					printf("\n SetChildRelSTDBomCmErr icount_Clr2basedf : %d",icount_Clr2basedf);fflush(stdout);			
			   }

					if(icount_Clr2basedf>0)
					{
						iLength	=	0;
						if (!tempErr) MEM_free(tempErr);
						i=0;
						for (i=0; i < icount_Clr2basedf; i++)
						{
							tempErr	=	SetChildRelSTDBomCmErr[i];
							iLength	=	iLength	+	tc_strlen(tempErr);
						}
						printf("Bom Comapre Check : %d",iLength);fflush(stdout);
						if (!tempErr) MEM_free(tempErr);
						tempErr	=	(char *)MEM_alloc(iLength+20);
						i=0;
						printf("\nBefore For loop Bom Comapre Check");fflush(stdout);
						for (i=0; i < icount_Clr2basedf; i++)
						{
							if(i==0)
								tc_strcpy(tempErr,SetChildRelSTDBomCmErr[i]);
							else
								tc_strcat(tempErr,SetChildRelSTDBomCmErr[i]);
						}
						printf("\n Bom Comapre Check Printing Errors...!!!");fflush(stdout);
						printf("%s",tempErr);fflush(stdout);
						tc_strcat(tempErr,"\n");
						tc_strcat(SetOfError,tempErr);
						printf("\n SetOfError: %s\n", SetOfError);//fflush(DmlRelFile);
						//tc_strcpy(SetOfError,tempErr);
						Ecnt=1;					
					}			
			}
			*/	
		//**Complete BoM check*//
		//Start Deepti BOM Check for Vehicle

			int icount_ebommbom_bom=0;
			int icount_aplModCheck=0;
			char**	SetChildRelAPLModErr		= NULL;
			char**	SetChildRel_CV_Check_STDErr = NULL;

				if((tc_strcmp(Release_Type,"CP")==0) || (tc_strcmp(Release_Type,"CM")==0) ||  (tc_strcmp(Release_Type,"Veh")==0) || ((tc_strstr(itemid,"AM")!=NULL) && (tc_strcmp(dml_ecnType,"APLSTR")==0)))
				{
					printf("\n Inside Test123 \n");fflush(stdout);

					char *ecn_ReleaseType=NULL;
					if (!ecn_ReleaseType) MEM_free(ecn_ReleaseType);
					ecn_ReleaseType	=	(char *)MEM_alloc(20);
					SetChildRelAPLModErr		= (char**)MEM_alloc( 1 * sizeof *SetChildRelAPLModErr );
					SetChildRel_CV_Check_STDErr = (char**)MEM_alloc( 1 * sizeof *SetChildRel_CV_Check_STDErr );

					if((tc_strstr(itemid,"AM")!=NULL) && (tc_strcmp(dml_ecnType,"APLSTR")==0))
					{
						tc_strcpy(ecn_ReleaseType,dml_ecnType);
					}
					else
					{
						tc_strcpy(ecn_ReleaseType,Release_Type);
					}
					
					printf("\n ecn_ReleaseType => %s \n",ecn_ReleaseType);fflush(stdout);
					ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCnt,&PartTags));
					printf("\n APL DML Cre:Now PartCnt:%d \n",PartCnt);fflush(stdout);
					
					// Ketan Started
					printf("\n Ketan123 Check Start : CV_Check_STD_BOM_Accuracy \n",PartCnt);fflush(stdout);
					char    *qry_entryCntrl_CV_Check[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
					char	**qry_valuesCntrl_CV_Check   = (char **) MEM_alloc(5 * sizeof(char *));
					tag_t   qryTagCntrl_CV_Check     = NULLTAG;
					int  n_entryCntrl_CV_Check			= 3;
					int  control_number_found_CV_Check	= 0;
					tag_t* list_of_WSO_cntrl_tags_CV_Check=NULLTAG;

					if(QRY_find2("Control Objects...", &qryTagCntrl_CV_Check));
					if (qryTagCntrl_CV_Check)
					{
						printf("\n Control Object Query Found \n");fflush(stdout);

						qry_valuesCntrl_CV_Check[0]="CV_Check";
						qry_valuesCntrl_CV_Check[1]="STD_BOM_Accuracy";
						qry_valuesCntrl_CV_Check[2]="0";
						
						if(QRY_execute(qryTagCntrl_CV_Check, n_entryCntrl_CV_Check, qry_entryCntrl_CV_Check, qry_valuesCntrl_CV_Check, &control_number_found_CV_Check, &list_of_WSO_cntrl_tags_CV_Check));
					}

					printf("\n CV_Check_STD_BOM_Accuracy : control_number_found_CV_Check is => %d\n",control_number_found_CV_Check);fflush(stdout);

					if(control_number_found_CV_Check>0)
					{
						printf("\n Ketan Inside Live : CV_Check_STD_BOM_Accuracy \n");fflush(stdout);

						int icount_STD_BOM_Accuracy=0;
						
						CV_Check_STD_BOM_Accuracy(item_rev_tag,PartCnt,"STD",ecn_ReleaseType,PartTags,&SetChildRel_CV_Check_STDErr,&icount_STD_BOM_Accuracy);
						printf("\n icount_STD_BOM_Accuracy => %d \n",icount_STD_BOM_Accuracy);fflush(stdout);

						if(icount_STD_BOM_Accuracy>0)
						{
							printf("\n Inside Error \n");fflush(stdout);
							iLength	=	0;
							if (!tempErr) MEM_free(tempErr);
							i=0;
							for (i=0; i < icount_STD_BOM_Accuracy; i++)
							{
								tempErr	=	SetChildRel_CV_Check_STDErr[i];
								iLength	=	iLength	+	tc_strlen(tempErr);
							}
							printf("\n CV_Check_STD_BOM_Accuracy EBOM-MBOM iLength : %d",iLength);fflush(stdout);
							if (!tempErr) MEM_free(tempErr);
							tempErr	=	(char *)MEM_alloc(iLength+20);
							i=0;
							printf("\n Before For loop");fflush(stdout);
							for (i=0; i < icount_STD_BOM_Accuracy; i++)
							{
								if(i==0)
									tc_strcpy(tempErr,SetChildRel_CV_Check_STDErr[i]);
								else
									tc_strcat(tempErr,SetChildRel_CV_Check_STDErr[i]);
							}
							printf("\n CV_Check_STD_BOM_Accuracy EBOM-MBOM Printing Errors...!!!");fflush(stdout);
							printf("%s",tempErr);fflush(stdout);
							tc_strcat(tempErr,"\n");
							tc_strcat(SetOfError,tempErr);
							printf("\n SetOfError: %s\n", SetOfError);//fflush(DmlRelFile);
						    Ecnt=1;
						}
					}
					else
					{
						printf("\n CV_Check_STD_BOM_Accuracy control object is not Live. \n");fflush(stdout);
					}
					// Ended

					ITKCALL(Check_STDModPresent(item_rev_tag,PartCnt,"STD",ecn_ReleaseType,PartTags,&SetChildRelAPLModErr,&icount_aplModCheck));
					printf("\n Check_STDModPresent icount_aplModCheck : %d",icount_aplModCheck);fflush(stdout);

					if(icount_aplModCheck>0)
					{
						iLength	=	0;
						if (!tempErr) MEM_free(tempErr);
						i=0;
						for (i=0; i < icount_aplModCheck; i++)
						{
							tempErr	=	SetChildRelAPLModErr[i];
							iLength	=	iLength	+	tc_strlen(tempErr);
						}
						printf("Check_APLModPresent EBOM-MBOM iLength : %d",iLength);fflush(stdout);
						if (!tempErr) MEM_free(tempErr);
						tempErr	=	(char *)MEM_alloc(iLength+20);
						i=0;
						printf("\nBefore For loop");fflush(stdout);
						for (i=0; i < icount_aplModCheck; i++)
						{
							if(i==0)
								tc_strcpy(tempErr,SetChildRelAPLModErr[i]);
							else
								tc_strcat(tempErr,SetChildRelAPLModErr[i]);
						}
						printf("\n Check_APLModPresent EBOM-MBOM Printing Errors...!!!");fflush(stdout);
						printf("%s",tempErr);fflush(stdout);
						tc_strcat(tempErr,"\n");
						tc_strcat(SetOfError,tempErr);
						printf("\n SetOfError: %s\n", SetOfError);//fflush(DmlRelFile);
						//tc_strcpy(SetOfError,tempErr);
						Ecnt=1;
					
					}
						//Check_STDModPresentSVR(item_rev_tag,"APL",&SetChildRelAPLModErr,&icount_ebommbom_bom);   //cbb change
						printf("\n Check_STDModPresentSVR icount_ebommbom : %d",icount_ebommbom_bom);fflush(stdout);

				    if(icount_ebommbom_bom>0)
					{
						iLength	=	0;
						if (!tempErr) MEM_free(tempErr);
						i=0;
						for (i=0; i < icount_ebommbom_bom; i++)
						{
							tempErr	=	SetChildRelAPLModErr[i];
							iLength	=	iLength	+	tc_strlen(tempErr);
						}
						printf("Missing/Duplication Error : %d",iLength);fflush(stdout);
						if (!tempErr) MEM_free(tempErr);
						tempErr	=	(char *)MEM_alloc(iLength+20);
						i=0;
						printf("\nBefore For loop");fflush(stdout);
						for (i=0; i < icount_ebommbom_bom; i++)
						{
							if(i==0)
								tc_strcpy(tempErr,SetChildRelAPLModErr[i]);
							else
								tc_strcat(tempErr,SetChildRelAPLModErr[i]);
						}
						printf("\n Missing/Duplication Error :..!!!");fflush(stdout);
						printf("%s",tempErr);fflush(stdout);
						tc_strcat(tempErr,"\n");
						tc_strcat(SetOfError,tempErr);
						printf("\n SetOfError: %s\n", SetOfError);//fflush(DmlRelFile);
						//tc_strcpy(SetOfError,tempErr);
						Ecnt=1;
					
					}

					Check_APLModuleDuplicate(item_rev_tag,PartCnt,PartTags,&SetChildRelAPLModErr,&icount_ebommbom_bom);
					printf("\n Check_APLModuleDuplicate icount_ebommbom : %d",icount_ebommbom_bom);fflush(stdout);
					
					Check_APLModuleQTY(item_rev_tag,PartCnt,PartTags,&SetChildRelAPLModErr,&icount_ebommbom_bom);
					printf("\n Check_APLModuleQTY icount_ebommbom : %d",icount_ebommbom_bom);fflush(stdout);
		/*
					if((tc_strcmp(Release_Type,"CP")==0) || (tc_strcmp(Release_Type,"CM")==0))
					{
						Check_APLModuleColourSuffix(item_rev_tag,"STD",PartCnt,PartTags,&SetChildRelAPLModErr,&icount_ebommbom_bom);
						printf("\n Check_APLModuleColourSuffix icount_ebommbom : %d",icount_ebommbom_bom);fflush(stdout);
					}

					if(icount_ebommbom_bom>0)
					{
						iLength	=	0;
						if (!tempErr) MEM_free(tempErr);
						i=0;
						for (i=0; i < icount_ebommbom_bom; i++)
						{
							tempErr	=	SetChildRelAPLModErr[i];
							iLength	=	iLength	+	tc_strlen(tempErr);
						}
						printf("EBOM-MBOM iLength : %d",iLength);fflush(stdout);
						if (!tempErr) MEM_free(tempErr);
						tempErr	=	(char *)MEM_alloc(iLength+20);
						i=0;
						printf("\nBefore For loop");fflush(stdout);
						for (i=0; i < icount_ebommbom_bom; i++)
						{
							if(i==0)
								tc_strcpy(tempErr,SetChildRelAPLModErr[i]);
							else
								tc_strcat(tempErr,SetChildRelAPLModErr[i]);
						}
						printf("\n EBOM-MBOM Printing Errors...!!!");fflush(stdout);
						printf("%s",tempErr);fflush(stdout);
						tc_strcat(tempErr,"\n");
						tc_strcat(SetOfError,tempErr);
						printf("\n SetOfError: %s\n", SetOfError);//fflush(DmlRelFile);
						//tc_strcpy(SetOfError,tempErr);
						Ecnt=1;
					
					}
		*/
					int icount_ebommSupp=0;
					//Check_ERCModSuppress(item_rev_tag,PartCnt,"APL",ecn_ReleaseType,PartTags,&SetChildRelAPLModErr,&icount_ebommSupp); //cbb change
					printf("\n Check_ERCModSuppress icount_ebommSupp : %d",icount_ebommSupp);fflush(stdout);
					
					if(icount_ebommSupp>0)
					{
						iLength	=	0;
						if (!tempErr) MEM_free(tempErr);
						i=0;
						for (i=0; i < icount_ebommSupp; i++)
						{
							tempErr	=	SetChildRelAPLModErr[i];
							iLength	=	iLength	+	tc_strlen(tempErr);
						}
						printf("EBOM-MBOM iLength : %d",iLength);fflush(stdout);
						if (!tempErr) MEM_free(tempErr);
						tempErr	=	(char *)MEM_alloc(iLength+20);
						i=0;
						printf("\nBefore For loop");fflush(stdout);
						for (i=0; i < icount_ebommSupp; i++)
						{
							if(i==0)
								tc_strcpy(tempErr,SetChildRelAPLModErr[i]);
							else
								tc_strcat(tempErr,SetChildRelAPLModErr[i]);
						}
						printf("\n EBOM-MBOM Printing Errors...!!!");fflush(stdout);
						printf("%s",tempErr);fflush(stdout);
						tc_strcat(tempErr,"\n");
						tc_strcat(SetOfError,tempErr);
						printf("\n SetOfError: %s\n", SetOfError);//fflush(DmlRelFile);
						//tc_strcpy(SetOfError,tempErr);
						Ecnt=1;
					}
				
				
				}
	/*
	    if(tc_strcmp(Release_Type,"TODR")==0)
	    {
			RefPartCnt=0;
			RefPartTags=NULLTAG;
		    ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMReferences",&RefPartCnt,&RefPartTags));
			printf("\n\n\t\t Number of parts in GM DML Task = %d",RefPartCnt);fflush(stdout);
			tag_t PartTag = NULLTAG;
			tag_t *PartRev_list = NULL;
			tag_t PartRevTag = NULLTAG;
			int j =0;
			int k =0;
			int Rev_count =0;
			int Err_Flg = 0;
			char *TaskID = NULL;
			char *TaskID2 = NULL;
			char *tmp_TaskID2 = NULL;
			  char*			Part_Type2				= NULL;
			char *InPlant = NULL;
			char LcsStdWrkg[40];
			char LcsStdRlzd[40];

			ITKCALL(AOM_ask_value_string(item_rev_tag,"item_id",&TaskID));
			printf("\n TaskID = %s\n",TaskID);fflush(stdout);
			
			TaskID2 = (char *)MEM_alloc(100);
			tc_strcpy(TaskID2,TaskID);
			printf("\n TaskID2 = %s\n",TaskID2);fflush(stdout);

			tmp_TaskID2 = strtok(TaskID2,"_");
			tmp_TaskID2 = strtok(NULL,"_");
			InPlant = strtok(NULL,"_");
			printf("\n InPlant = %s  \n",InPlant);fflush(stdout);

			GetPlantWiseRelStat(TaskID,LcsStdWrkg,LcsStdRlzd);	// TZ 1.53
			printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);fflush(stdout);	// TZ 1.53
			printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);fflush(stdout);	// TZ 1.53

			if (RefPartCnt>0)
			{
				printf("\n Number of Parts in GM DML Task = %d",RefPartCnt);fflush(stdout);
				for(j=0;j<RefPartCnt;j++)
				{
					PartTag = NULLTAG;
					char	*type_name		=	NULL;
					tag_t	objTypeTag		=	NULLTAG;

					if(TCTYPE_ask_object_type(RefPartTags[j],&objTypeTag));
					if(TCTYPE_ask_name2(objTypeTag,&type_name));
					printf("\n type_name : %s",type_name);fflush(stdout);

					if (tc_strcmp(type_name,"Folder")==0)
					{
						printf("\nGM DML Part type is folder, so bypass...");fflush(stdout);
						continue;
					}
					//Folder bypass ends Hemal
					ITKCALL(ITEM_ask_item_of_rev(RefPartTags[j], &PartTag));					
					Part_Type2	=	NULL;
					ITKCALL(AOM_ask_value_string(RefPartTags[j],"t5_PartType",&Part_Type2));
					printf("\n\n\t EPA Child Part String is Part_Type-->%s",Part_Type2);	fflush(stdout);
					if((strcmp(Part_Type2,"D")==0)|| (strcmp(Part_Type2,"DC")==0)|| (strcmp(Part_Type2,"DA")==0))
					{
						continue;
					}
					ITKCALL(ITEM_ask_item_of_rev(RefPartTags[j], &PartTag));
					ITKCALL(ITEM_list_all_revs(PartTag, &Rev_count,&PartRev_list));
					printf("\n\t Rev_count is = %d",Rev_count);fflush(stdout);

					GMDML_Prt_DR4_DR5_Check(RefPartTags[j],InPlant,LcsStdRlzd,&SetGMErr,&icount1,&Err_Flg);
				
				}				
			}

			if(cntFlag==1)
			{
				iLength	=	0;
				if (!tempErr) MEM_free(tempErr);
				i=0;
				for (i=0; i < icount1; i++)
				{
					tempErr	=	SetGMErr[i];
					iLength	=	iLength	+	tc_strlen(tempErr);
				}
				printf("iLength : %d",iLength);fflush(stdout);
				if (!tempErr) MEM_free(tempErr);
				tempErr	=	(char *)MEM_alloc(iLength+20);
				i=0;
				for (i=0; i < icount1; i++)
				{
					if(i==0)
						tc_strcpy(tempErr,SetGMErr[i]);
					else
						tc_strcat(tempErr,SetGMErr[i]);
				}
				printf("\nPrinting Errors...!!!");fflush(stdout);
				printf("%s",tempErr);fflush(stdout);
				tc_strcat(tempErr,"\n");
				tc_strcat(SetOfError,tempErr);
				printf("\n SetOfError: %s\n", SetOfError);//fflush(DmlRelFile);
				//tc_strcpy(SetOfError,tempErr);
				Ecnt=1;
			}
				tm_CCV_GMDML_DR_Check_STD(item_rev_tag,&SetGMErr,&icount1);
				printf("\nAfter Function call of CCV GM icount : %d",icount1);fflush(stdout);
			if (icount1>0)
			{
				iLength	=	0;
				if (!tempErr) MEM_free(tempErr);
				i=0;
				for (i=0; i < icount1; i++)
				{
					tempErr	=	SetGMErr[i];
					iLength	=	iLength	+	tc_strlen(tempErr);
				}
				printf("iLength : %d",iLength);fflush(stdout);
				if (!tempErr) MEM_free(tempErr);
				tempErr	=	(char *)MEM_alloc(iLength+20);
				i=0;
				for (i=0; i < icount1; i++)
				{
					if(i==0)
						tc_strcpy(tempErr,SetGMErr[i]);
					else
						tc_strcat(tempErr,SetGMErr[i]);
				}
				printf("\nPrinting Errors...!!!");fflush(stdout);
				printf("%s",tempErr);fflush(stdout);
				tc_strcat(tempErr,"\n");
				tc_strcat(SetOfError,tempErr);
				printf("\n SetOfError: %s\n", SetOfError);//fflush(DmlRelFile);
				//tc_strcpy(SetOfError,tempErr);
				Ecnt=1;
			}
			if (icount1==0)
			{
				//Create Snapshot
				createSnapshotGMSTD(item_rev_tag);
			}
		}
		

		if((tc_strcmp(Release_Type,"CP")==0) || (tc_strcmp(Release_Type,"CM")==0) ) //ADDED by DEEPTI TZ1.55 BackendTZ
		{
		
			tm_amsm_colour_nonColour_part_sm_restructuring(item_rev_tag); 
		
		}
		
		if(tc_strcmp(Release_Type,"CP")==0)
		{
			tm_chk_CCVC_BOM_STDRLZ(item_rev_tag,&SetStdRelErr,&icount);

			printf("\nAfter Function call tm_chk_CCVC_BOM_STDRLZ icount : %d",icount);fflush(stdout);
			if (icount>0)
			{
				iLength	=	0;
				if (!tempErr) MEM_free(tempErr);
				i=0;
				for (i=0; i < icount; i++)
				{
					tempErr	=	SetStdRelErr[i];
					iLength	=	iLength	+	tc_strlen(tempErr);
				}
				printf("iLength : %d",iLength);fflush(stdout);
				if (!tempErr) MEM_free(tempErr);
				tempErr	=	(char *)MEM_alloc(iLength+20);
				i=0;
				for (i=0; i < icount; i++)
				{
					if(i==0)
						tc_strcpy(tempErr,SetStdRelErr[i]);
					else
						tc_strcat(tempErr,SetStdRelErr[i]);
				}
				printf("\nPrinting Errors for CLR CCV...!!!");fflush(stdout);
				printf("%s",tempErr);fflush(stdout);
				tc_strcat(tempErr,"\n");
				tc_strcat(SetOfError,tempErr);
				printf("\n SetOfError: %s\n", SetOfError);//fflush(DmlRelFile);
				//tc_strcpy(SetOfError,tempErr);
				Ecnt=1;
			}
		}

	// Aded by dss 1.54 
	    if(tc_strcmp(Release_Type,"SVR")==0)
		{
		   	int				Part_SCnt			= 0;
			tag_t*			Part_STags			= NULLTAG;
			tag_t			AssyTag				= NULLTAG;
			char *type_name1                    = NULL;
			int             icount2             = 0;
			char	       **SetSVRErr          = NULL;
			SetSVRErr = (char**)MEM_alloc( 1 * sizeof *SetSVRErr );
			 cntSVRFlag = 0;

					ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMReferences",&Part_SCnt,&Part_STags));
					printf("\n\n\t\t inside SVR Rlzd type :%d",Part_SCnt);fflush(stdout);

					if (Part_SCnt>0)
					{
						int gh=0;
						for (gh=0;gh<Part_SCnt ;gh++ )
						{
							printf("\n SVR: for gh =:%d",gh);fflush(stdout);
							AssyTag				= NULLTAG;
							AssyTag=Part_STags[gh];

							tag_t objTypeTag1 = NULLTAG;
							if(TCTYPE_ask_object_type(AssyTag,&objTypeTag1));
							if(TCTYPE_ask_name2(objTypeTag1,&type_name1));
							printf("\n SVR: type_name := %s", type_name1);fflush(stdout);

							if(strcmp(type_name1,"VariantRule")==0) // SVR
							{
								tm_BOMResolveForAPLModulesFunc(AssyTag,itemid,RevisionRule,ClosureRule,BVR,&SetSVRErr,&icount2);
							}
						}

						printf("\n icount2 : %d\n",icount2);fflush(stdout);
						if(cntSVRFlag==1)
						{
							iLength	=	0;
							if (!tempErr) MEM_free(tempErr);
							i=0;
							for (i=0; i < icount2; i++)
							{
								tempErr	=	SetSVRErr[i];
								iLength	=	iLength	+	tc_strlen(tempErr);
							}
							printf("iLength : %d",iLength);fflush(stdout);
							if (!tempErr) MEM_free(tempErr);
							tempErr	=	(char *)MEM_alloc(iLength+20);
							i=0;
							for (i=0; i < icount2; i++)
							{
								if(i==0)
									tc_strcpy(tempErr,SetSVRErr[i]);
								else
									tc_strcat(tempErr,SetSVRErr[i]);
							}
							printf("\nPrinting Errors...!!!");fflush(stdout);
							printf("%s",tempErr);fflush(stdout);
							tc_strcat(tempErr,"\n");
							tc_strcat(SetOfError,tempErr);
							printf("\n SetOfError: %s\n", SetOfError);//fflush(DmlRelFile);
							//tc_strcpy(SetOfError,tempErr);
							Ecnt=1;						
						}					
					}
	    }
	if(tc_strcmp(Release_Type,"Veh")==0)
	{
		tag_t	qryTagCntrlEbomMBom		        = NULLTAG;
		int     n_entryCntrlEMBOM               = 3;
		int		control_number_foundEMBOM       = 0;
		tag_t	*list_of_WSO_cntrl_tagsEMBOM	= NULLTAG;
		char	*cUserInfo1				        = NULLTAG;

		char    *qry_entryCntrlEMBOM[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	//DEEPTI TZ1.52
		char	**qry_valuesCntrlEMBOM= (char **) MEM_alloc(5 * sizeof(char *));//DEEPTI TZ1.52

		printf("\n Control Object Query Found for EBOM-MBOM Check\n");fflush(stdout);
		qry_valuesCntrlEMBOM[0]="STDCCVChk";
		qry_valuesCntrlEMBOM[1]="STDCCVChk";
		qry_valuesCntrlEMBOM[2]="0";

		if(QRY_find2("Control Objects...", &qryTagCntrlEbomMBom));
		
		if(qryTagCntrlEbomMBom!=NULLTAG)
		{
			if(QRY_execute(qryTagCntrlEbomMBom, n_entryCntrlEMBOM, qry_entryCntrlEMBOM, qry_valuesCntrlEMBOM, &control_number_foundEMBOM, &list_of_WSO_cntrl_tagsEMBOM));
			printf("\n\n\t\t control_number_foundEMBOM =:%d",control_number_foundEMBOM);fflush(stdout);

			if (control_number_foundEMBOM>0)
			{
				ITKCALL(AOM_ask_value_string(list_of_WSO_cntrl_tagsEMBOM[0], "t5_Userinfo1",&cUserInfo1));
				
				printf("\nProject code :%s, User Info : %s",ProjectCode,cUserInfo1);fflush(stdout);
				if (tc_strstr(cUserInfo1,ProjectCode)!=NULL)
				{
					tm_chkSnapShotBOM_STDRLZ(item_rev_tag,&SetGMErr,&icount1);
					tm_CCV_STD_APL_Module_Chk(item_rev_tag,&SetGMErr,&icount1);

					printf("\nAfter Function call of CCV Veh dml error icount : %d",icount1);fflush(stdout);
					if (icount1>0)
					{
						iLength	=	0;
						if (!tempErr) MEM_free(tempErr);
						i=0;
						for (i=0; i < icount1; i++)
						{
							tempErr	=	SetGMErr[i];
							iLength	=	iLength	+	tc_strlen(tempErr);
						}
						printf("iLength : %d",iLength);fflush(stdout);
						if (!tempErr) MEM_free(tempErr);
						tempErr	=	(char *)MEM_alloc(iLength+20);
						i=0;
						for (i=0; i < icount1; i++)
						{
							if(i==0)
								tc_strcpy(tempErr,SetGMErr[i]);
							else
								tc_strcat(tempErr,SetGMErr[i]);
						}
						printf("\nPrinting Errors...!!!");fflush(stdout);
						printf("%s",tempErr);fflush(stdout);
						tc_strcat(tempErr,"\n");
						tc_strcat(SetOfError,tempErr);
						printf("\n SetOfError: %s\n", SetOfError);//fflush(DmlRelFile);
						//tc_strcpy(SetOfError,tempErr);
						Ecnt=1;
					}
				}
			}
		}

	}
	//Ended by Hemal for CCV
*/
		if(tc_strcmp(Release_Type,"WT")==0)
		{
				PartTags=NULLTAG;
				PartCnt=0;
				icount1=0;
				char	**SetWTErr = NULL;
				SetWTErr = (char**)MEM_alloc( 1 * sizeof *SetWTErr );
				
				ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCnt,&PartTags));
				
				printf("\n\n\t\t Number of partnumbers in WT DML Task :%d",PartCnt);fflush(stdout);
				
				printf("\n\n\t\t calling WT signoff function");fflush(stdout);
				WTDML_Part_Release_Check_STD(PartCnt,PartTags,&SetWTErr,&icount1,pTagAttch[i]);
				printf("\n\n\t\t end calling WT signoff function");fflush(stdout);
				printf("\n\n\t\t error count %d",icount1);fflush(stdout);
				if(icount1>0)
				{
					iLength	=	0;
					if (!tempErr) MEM_free(tempErr);
					i=0;
					if (!tempErr) MEM_free(tempErr);
					int i=0;
					for (i=0; i < icount1; i++)
					{
						tempErr	=	SetWTErr[i];
						iLength	=	iLength	+	tc_strlen(tempErr);
					}
					printf("iLength : %d",iLength);fflush(stdout);
					if (!tempErr) MEM_free(tempErr);
					tempErr	=	(char *)MEM_alloc(iLength+20);
					i=0;
					for (i=0; i < icount1; i++)
					{
						if(i==0)
							tc_strcpy(tempErr,SetWTErr[i]);
						else
							tc_strcat(tempErr,SetWTErr[i]);
					}
					printf("\nPrinting Errors...!!!");fflush(stdout);
					printf("%s",tempErr);fflush(stdout);
					tc_strcat(tempErr,"\n");
					tc_strcat(SetOfError,tempErr);
					printf("\n SetOfError: %s\n", SetOfError);//fflush(DmlRelFile);
					//tc_strcpy(SetOfError,tempErr);
				    Ecnt=1;
				}
		}
		else
		{
			    char *changetype		=NULL;

				ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCnt,&PartTags));
				printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);
				ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_b2changetype",&changetype));
				printf("\n\t hi changetype is :%s",changetype); fflush(stdout);
				if( (tc_strstr(itemid,"_PR")!=NULL) && (PartCnt==0) && (tc_strcmp(changetype,"PR" )==0) )
				{
					tc_strcat(SetOfError,"\n");			
					tc_strcat(SetOfError,"PR Task Should Have Atleast One Part");
					Ecnt=1;
					printf("\n SetOfError: %s\n", SetOfError);//fflush(DmlRelFile);
				}

			//##############Bypass All the validations if AMDML of type AM###############//
			BypassAMDMLFlag = AMDML_Bypass_Checks(item_rev_tag);
			printf("\t  BypassAMDMLFlag ...%d\n", BypassAMDMLFlag);	
		
			if(BypassAMDMLFlag==1)
			{
				printf("\n Bypass all validations as AMDML of type AM");fflush(stdout);
				goto BYPASSVALIDATIONS;
			}
			else
			{
				printf("\n Call all validations as DML is not of type AM");fflush(stdout);
			}
			//############################################################################//

			if (PartCnt>0)
			{
				char       *carryOver_check      = NULL;
				int        carryOverErr          = 0;
				char	   *PlantName123         = NULL;
				tag_t      CurrentRoleTag        = NULLTAG;
				char       *roleName             = NULL;
				
				/**Added By Manindra for Skip the STD Validation of Carry over stamping for CVBU**/
				ITKCALL(SA_ask_current_role(&CurrentRoleTag));
				ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
				printf("\n\n  roleName  is : %s\n",roleName); fflush(stdout);
				PlantName123=subString(roleName,3,4);
				printf( "PlantName123 is :%s\n", PlantName123);

				ITKCALL(AOM_ask_value_string( item_rev_tag, "t5_CarryOverCheckStatusSTD", &carryOver_check));
				printf("\n carryOver_check.. %s \n",carryOver_check);fflush(stdout);

				printf("\n deepak Before2 APLC2 Carryover required \n");   //Added by deepak For CAR Plant TZ1.87
                fflush(stdout);
				
				if(tc_strcmp(PlantName123,"APLC")== 0)      //cbb changes
				{


					printf("\n deepak Before APLC2 Control Object Query Run for Carryover required \n");   //Added by deepak For CAR Plant TZ1.87
					fflush(stdout);							
				
								char    *qry_entryCntrl2d[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
								char	**qry_valuesCntrl2d= (char **) MEM_alloc(5 * sizeof(char *));
								
								tag_t   qryTagCntrl2d			= NULLTAG;
								tag_t*	list_of_WSO_cntrl_tagsd = NULLTAG;
								
								int     n_entryCntrl2d			= 3;
								int		control_number_foundd	= 0;
								
								if( QRY_find2("Control Objects...", &qryTagCntrl2d));
								if (qryTagCntrl2d)
								{
									printf("\n Before Control Object Query Found \n");fflush(stdout);
									qry_valuesCntrl2d[0]="Carryover";
									qry_valuesCntrl2d[1]="CAR";  
									qry_valuesCntrl2d[2]="0";
									
								if(QRY_execute(qryTagCntrl2d, n_entryCntrl2d, qry_entryCntrl2d, qry_valuesCntrl2d, &control_number_foundd, &list_of_WSO_cntrl_tagsd));
								
								
								if (control_number_foundd > 0)	

									printf("\n Carryover APLC2 Control Object Query Found \n");fflush(stdout);

									if(strcmp(carryOver_check,"")==0)
									{
										carryOverErr++;
										tc_strcat(SetOfError,"\n");
										tc_strcat(SetOfError,"Please run the CarryOver Part Stamping before Signoff the Task.\n Select the Task ->Go to ->Manufacturing Menu->Implementation-->Carryover Part Stamping for STDSI");	
										Ecnt=1;						
										printf("\n SetOfError: %s\n", SetOfError);//fflush(DmlRelFile);	
									}


								}

						     else
									{
												printf("\n query Carryover APLC2 not found");
												fflush(stdout);
									}

								

				//End  by deepak For CAR Plant TZ1.87
					
				}
				/**Ended By Manindra for Skip the STD Validation of Carry over stamping for CVBU**/
				if(carryOverErr==0)
				{			
					GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
					printf("\n\n\t\t for k =:%d",k);fflush(stdout);

					printf("\n cntFlag_1: %d",cntFlag);fflush(stdout);

					//AMDML_Std_Validation(PartCnt,item_rev_tag,PartTags,SetStdRelErr); //TZ1.42--Deepti
					AMDML_Std_Validation(PartCnt,item_rev_tag,PartTags,&SetStdRelErr,&icount); //added by dss 1.53
					
					printf("\n cntFlag_2: %d",cntFlag);fflush(stdout);

					//**********TZ3.46*********************//				
					char LcsStdWrkg[40];
					char LcsStdRlzd[40];

					GetPlantWiseRelStat(itemid,LcsStdWrkg,LcsStdRlzd);
					printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
					printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);
					strcpy(lcsToset,LcsStdRlzd);
					CheckforColBasicDMLReleaseSTD(PartCnt,item_rev_tag, PartTags,lcsToset,&SetStdRelErr,&icount); //added by dss 1.53
					printf("\n cntFlag_6: %d",cntFlag);fflush(stdout);
					Child_std_validation(PartCnt,item_rev_tag, PartTags,lcsToset,&SetStdRelErr,RevisionRule,ClosureRule,BVR,&icount); //added by dss 1.53
					printf("\n cntFlag_3: %d",cntFlag);fflush(stdout);
					STD_Two_Rev_Same_Day_Checks_P(PartCnt,PartTags,&SetStdRelErr,itemid,&icount); //added by dss 1.53
					printf("\n cntFlag_4: %d",cntFlag);fflush(stdout);
					Next_Rev_Gt_DR3_Exists_Check(PartCnt,PartTags,&SetStdRelErr,itemid,&icount); //added by dss 1.53
					printf("\n cntFlag_5: %d",cntFlag);fflush(stdout);
					Prev_Rev_Checks_SMDML(PartCnt,PartTags,&SetStdRelErr,itemid,ProjectCode,STDDmlPlnt,&icount); ;
				}
		    } //End for Part
		 
		    printf("\n hi ..cntFlag: %d\n",cntFlag);fflush(stdout);
			if(cntFlag==1)
			{
				iLength	=	0;
				if (!tempErr) MEM_free(tempErr);
				int ii=0;
				for (ii=0; ii < icount; ii++)
				{
					tempErr	=	SetStdRelErr[ii];
					iLength	=	iLength	+	tc_strlen(tempErr);
				}
				printf("iLength : %d",iLength);fflush(stdout);
				if (!tempErr) MEM_free(tempErr);
				tempErr	=	(char *)MEM_alloc(iLength+20);
				for (ii=0; ii < icount; ii++)
				{
					
					if(ii==0)
					tc_strcpy(tempErr,SetStdRelErr[ii]);
					else
					tc_strcat(tempErr,SetStdRelErr[ii]);
				}
				printf("\nPrinting Errors...!!!");fflush(stdout);
				printf("%s",tempErr);fflush(stdout);
				tc_strcat(tempErr,"\n");
				tc_strcat(SetOfError,tempErr);
				printf("\n SetOfError: %s\n", SetOfError);//fflush(DmlRelFile);
				//tc_strcpy(SetOfError,tempErr);
				Ecnt=1;
			}
			else //TZ1.42--DEEPTI
			{
				printf("\n Inside else of no error");fflush(stdout);
				if (PartCnt>0)
				{
					logical retain=false;
					task_po_check=NULL;
					char* POSTATUS = NULL ;
					POSTATUS = (char* ) malloc ( 500000 * sizeof ( char ) ) ;
					ITKCALL(AOM_ask_value_string( item_rev_tag, "t5_POCheckStatus", &task_po_check));
					printf("\n task_po_check.. %s \n",task_po_check);fflush(stdout);
					if((strcmp(task_po_check,"")==0) || (strcmp(task_po_check,"POCHKFAIL")==0) || (strcmp(task_po_check,"POCHKFAIL")==0))
					{	
						char* POSTATUS = NULL ;
						POSTATUS = (char* ) malloc ( 500000 * sizeof ( char ) ) ;
						tc_strcpy(POSTATUS,"");
						tc_strcat(POSTATUS,"POCHKBYPS");
						printf("\n POSTATUS %s \n",POSTATUS);fflush(stdout);
						ITKCALL(AOM_lock(item_rev_tag));
						ITKCALL(AOM_set_value_string(item_rev_tag,"t5_POCheckStatus", POSTATUS));
						ITKCALL(AOM_save_without_extensions(item_rev_tag));
						ITKCALL(AOM_unlock(item_rev_tag));
						printf("\n task_po_check.. %s \n",task_po_check);fflush(stdout);	
					}
					else
					{				
						//decision = EPM_go;
						//return decision;
					}
					
					if((tc_strstr(dml_no_id,"AM")!=NULL) && (tc_strcmp(dml_ecnType,"TOODMLR")!= 0))		//Deepti TZ1.53
					{
						if((tc_strcmp(changetype,"CARRYOVER")!=0) && (tc_strstr(dml_no_id,"CO")==NULL))
						{
							Prev_Rev_Checks(PartCnt,PartTags,&SetPrevRevNotification,itemid,ProjectCode,&icountprev);
							printf("\n inside am SetPrevRevNotification: %s\n",SetPrevRevNotification);fflush(stdout);
						}
					}
					else if(tc_strstr(dml_no_id,"AM")==NULL) 
					{
						if((tc_strcmp(changetype,"CARRYOVER")!=0) && (tc_strstr(dml_no_id,"CO")==NULL))
						{
							Prev_Rev_Checks(PartCnt,PartTags,&SetPrevRevNotification,itemid,ProjectCode,&icountprev);
							printf("\n inside non-am SetPrevRevNotification: %s\n",SetPrevRevNotification);fflush(stdout);
						}
					}
					if(cntFlagprev==1 && cntFlagprevhchk == 0) //pl922201.ttl
					{	
						printf("\n I Am inside Softcheck cntFlagprev = %d  cntFlagprevhchk = %d  ",cntFlagprev,cntFlagprevhchk);fflush(stdout); //pl922201

						iLength	=	0;
						if (!tempErr) MEM_free(tempErr);
						int ij=0;
						for (ij=0; ij < icountprev; ij++)
						{
							tempErr	=	SetPrevRevNotification[ij];
							iLength	=	iLength	+	tc_strlen(tempErr);
						}
						printf("iLength : %d",iLength);fflush(stdout);
						if (!tempErr) MEM_free(tempErr);
						tempErr	=	(char *)MEM_alloc(iLength+20);
						for (ij=0; ij < icountprev; ij++)
						{
							
							if(ij==0)
							tc_strcpy(tempErr,SetPrevRevNotification[ij]);
							else
							tc_strcat(tempErr,SetPrevRevNotification[ij]);
						}
						printf("\nPrinting Errors prev rev...!!!");fflush(stdout);
						printf("%s",tempErr);fflush(stdout);
						tc_strcat(tempErr,"\n");
						tc_strcat(SetOfError,tempErr);
						printf("\n SetOfError: %s\n", SetOfError);//fflush(DmlRelFile);
						//tc_strcpy(SetOfError,tempErr);
						Ecnt=1;
						printf("\n Test2");fflush(stdout);
					}
					else if(cntFlagprev==1 && cntFlagprevhchk == 1) //pl922201.ttl
					{							
						printf("\n I Am inside Hardcheck cntFlagprev = %d  cntFlagprevhchk = %d  ",cntFlagprev,cntFlagprevhchk);fflush(stdout); //pl922201
					
						iLength	=	0;
						if (!tempErr) MEM_free(tempErr);
						int ij=0;
						//for (ij=0; ij < icount; ij++)
						for (ij=0; ij < icountprev; ij++)
						{
							tempErr	=	SetPrevRevNotification[ij];
							iLength	=	iLength	+	tc_strlen(tempErr);
						}
						printf("iLength : %d",iLength);fflush(stdout);
						if (!tempErr) MEM_free(tempErr);
						tempErr	=	(char *)MEM_alloc(iLength+20);
						for (ij=0; ij < icountprev; ij++)
						{
							
							if(ij==0)
							tc_strcpy(tempErr,SetPrevRevNotification[ij]);
							else
							tc_strcat(tempErr,SetPrevRevNotification[ij]);
						}
						printf("\nPrinting Errors prev rev...!!!");fflush(stdout);
						printf("%s",tempErr);fflush(stdout);
						tc_strcat(tempErr,"\n");
						tc_strcat(SetOfError,tempErr);
						printf("\n SetOfError: %s\n", SetOfError);//fflush(DmlRelFile);
						//tc_strcpy(SetOfError,tempErr);	
						Ecnt=1;	

					}
				}
				
			}
		}//else of if(tc_strcmp(Release_Type,"TODR")==0)
	  }
    }
}
else
{
	printf("\n DML Flown to STD Workflow \n");
	return ITK_errStore;
}
}
else
{
	printf("\n DML Flown to STD Workflow \n");
	return ITK_errStore;
}

}
	//Ecnt=1;
    printf("\nEcnt: %d",Ecnt);fflush(stdout);
	if(Ecnt==1)
    {
		time_t now;
		struct tm *now_tm;
		char ReleasedDateTime_str[26] = {'\0'};
		char *Filename = NULL;
		char *LocPath = NULL;
		char *FileLoc = NULL;
		FILE *DmlRelFile = NULL;
		tag_t qryTagCntrl4 = NULLTAG;
		int control_number_found4 = 0;
		tag_t *list_of_WSO_cntrl_tags4 = NULL;
		char *qry_entryCntrl4[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
		char **qry_valuesCntrl4 = (char **)MEM_alloc(3 * sizeof(char *));

		if (!qry_valuesCntrl4) {
			printf("Memory allocation failed!\n");
			return -1;
		}

		// Get Current Time and Format it
		time(&now);
		now_tm = localtime(&now);
		strftime(ReleasedDateTime_str, 26, "%d%m%y%H%M%S", now_tm);
		printf("\n\n ReleasedDateTime_str: [%s]", ReleasedDateTime_str);

		// Initialize Query Values
		qry_valuesCntrl4[0] = "KSP";
		qry_valuesCntrl4[1] = "Rls_type";
		qry_valuesCntrl4[2] = "0";

		// Execute Query
		ITKCALL(QRY_find2("Control Objects...", &qryTagCntrl4));

		if (qryTagCntrl4 != NULLTAG) {
			printf("\nControl Object Query Found\n");

			ITKCALL(QRY_execute(qryTagCntrl4, 3, qry_entryCntrl4, qry_valuesCntrl4, &control_number_found4, &list_of_WSO_cntrl_tags4));
			
			if (control_number_found4 > 0) {
				ITKCALL(AOM_ask_value_string(list_of_WSO_cntrl_tags4[0], "t5_Userinfo1", &LocPath));
				printf("\n LocPath: %s\n", LocPath);

				// Allocate Memory for Filename & File Location
				Filename = (char *)MEM_alloc(200 * sizeof(char));
				FileLoc = (char *)MEM_alloc(500 * sizeof(char));

				if (!Filename || !FileLoc) {
					printf("Memory allocation failed!\n");
					return -1;
				}
				strcpy(Filename, "");
				strcpy(Filename, DML_no);
				strcat(Filename, "_PrintErrorRep_");
				strcat(Filename, ReleasedDateTime_str);
				strcat(Filename, ".txt");

				printf("\n Filename: %s", Filename);

				strcpy(FileLoc, LocPath);
				strcat(FileLoc, Filename);
				printf("\n FileLoc: %s\n", FileLoc);

				// Open File for Writing
				DmlRelFile = fopen(FileLoc, "w");
				if (DmlRelFile == NULL) {
					printf("\nError: Could not open file: %s\n", FileLoc);
					return -1;
				}

				fprintf(DmlRelFile, "************** Printing Error Report **************\n");
				printf("\n SetOfError:  %s\n", SetOfError);fflush(stdout);
				fprintf(DmlRelFile,"\n%s\n",SetOfError);fflush(DmlRelFile);
				fprintf(DmlRelFile, "\n************** END **************\n");

				//fclose(DmlRelFile);
				printf("\n File written successfully\n");
			} else {
				printf("\nNo control objects found.\n");
			}
		} else {
			printf("\nControl Object Query Not Found.\n");
		}

		// Free allocated memory
		// if (qry_valuesCntrl4) MEM_free(qry_valuesCntrl4);
		// if (Filename) MEM_free(Filename);
		// if (FileLoc) MEM_free(FileLoc);
		// }
		// else{
		// 	printf("\n +++++++++++++++++++++++++++++++++++++ \n");fflush(stdout);
		//  	return ITK_ok;
		// }
			printf("\nCompleted....");fflush(stdout);



			char* dataSetName = NULL;
			tag_t	datasettype = NULLTAG;
			tag_t	tool 		= NULLTAG;
			tag_t	Newdataset 	= NULLTAG;
			tag_t	filetag 	= NULLTAG;
			IMF_file_t	fileDescriptor;
		// 	//char * relation_type_name = NULL;
		// 	//tag_t  	relation_type = NULLTAG;
			tag_t  	relation    = NULLTAG;
			AE_reference_type_t 	AE_PART_OF;
		// 		char ReleasedDateTime_str[26] = {'\0'};
		// 		char *Filename = NULL;
		// 		char *FileLoc = NULL;
		// 		Filename = (char *)MEM_alloc(200 * sizeof(char));
		// 		FileLoc = (char *)MEM_alloc(500 * sizeof(char));

			char* TempPartvalue1 = NULL;
			TempPartvalue1=(char *)MEM_alloc(100);
			tc_strcpy(TempPartvalue1,"");
			tc_strcpy(TempPartvalue1,DML_no); 
			printf("\t DML Number   : %s \n",TempPartvalue1); fflush(stdout);

			dataSetName = (char *) MEM_alloc( 300 * sizeof(char) );
			tc_strcpy(dataSetName,TempPartvalue1);
			tc_strcat(dataSetName,"_PrintErrorRep_");
			tc_strcat(dataSetName,ReleasedDateTime_str);
			tc_strcat(dataSetName, ".txt");

			printf("\ncomp1....");fflush(stdout);

			ITKCALL(AE_find_datasettype2("Text", &datasettype));
			printf("\ncomp12....");fflush(stdout);
			ITKCALL(AE_find_tool2("Notepad", &tool));
			printf("\ncomp123....");fflush(stdout);
			ITKCALL(AE_create_dataset_with_id(datasettype, dataSetName, "", NULL, NULL, &Newdataset));
			printf("\ncomp1234....");fflush(stdout);
			ITKCALL(AE_set_dataset_tool(Newdataset, tool));
			printf("\ncomp12345....");fflush(stdout);
			ITKCALL(AE_set_dataset_format2(Newdataset, "TEXT_REF"));
			printf("\ncomp123456....");fflush(stdout);
			ITKCALL(AOM_save_without_extensions(Newdataset));
			printf("\ncomp1234567....");fflush(stdout);

			printf("\n IMF_fmsfile_Filename: %s", Filename);
			printf("\n IMF_fmsfile_FileLoc: %s\n", FileLoc);

			ITKCALL(IMF_fmsfile_import(FileLoc, Filename, SS_TEXT, &filetag, &fileDescriptor));
			printf("\ncomp12345678....");fflush(stdout);
		
			

			if(filetag == NULLTAG)
			{
				printf("file tag not found.....");fflush(stdout);
			}
			else
			{
				printf("\nFile tag found...");fflush(stdout);
			}

		 	printf("\ncomp123....");fflush(stdout);

			 ITKCALL(AOM_refresh(Newdataset, TRUE));
			 ITKCALL(AE_add_dataset_named_ref2(Newdataset, "Text", AE_PART_OF, filetag))
			 ITKCALL(AOM_save_without_extensions(Newdataset))
 
			 char* DML_Num = NULL;
			 ITKCALL(AOM_ask_value_string(DMLRevTagg,"item_id",&DML_Num));
			 printf("\nDML_Num %s ",DML_Num);fflush(stdout);
			 
			 if(GRM_find_relation_type("IMAN_reference", &relation_type)!=ITK_ok)PrintErrorStack();
			 if(relation_type != NULLTAG)
			 {
				 ITKCALL(GRM_create_relation(DMLRevTagg,Newdataset,relation_type, NULLTAG, &relation))
				 if(relation != NULLTAG)
				 {
					 printf("\nThe dataset is attached to the Reference folder of DML");fflush(stdout);
				 }
				 else
				 {
					 printf("\nThe dataset is not attached to the Reference folder of DML. Please check");fflush(stdout);
				 }
				 ITKCALL(GRM_save_relation(relation))
			 }

			 if(dataSetName!=NULL) MEM_free(dataSetName);
			//if(relation_type_name!=NULL) MEM_free(relation_type_name);
			
			if(Filename!=NULL) MEM_free(Filename);
			if(FileLoc!=NULL) MEM_free(FileLoc);
	}
	else{
		printf("\n +++++++++++++++++++++++++++++++++++++ \n");fflush(stdout);
		return ITK_ok;
	}
			printf("\n44444444444....");fflush(stdout);

	if(Ecnt>0)
	{
		printf("\nECN COUNT 1111111111111111");fflush(stdout);
		return ITK_errStore;
	}
	else
	{
		printf("\nECN COUNT 00000000000000000000");fflush(stdout);	
		return ITK_ok;
	}
	printf("\nDone....");fflush(stdout);

 	BYPASSVALIDATIONS:
 	return error_code;
}

////////////////////////////////////////////////////    END   /////////////////////////////////

int FindPartLCS(tag_t PartTg,char *PartLCS)
{
    int	ifail = ITK_ok;
    int Prtstatus_count = 0;
    int pii;
    tag_t*    prtstatus_list = NULLTAG;
    char* ReleaseStatus;

    tc_strcpy(PartLCS," ");

    ITKCALL(WSOM_ask_release_status_list(PartTg,&Prtstatus_count,&prtstatus_list));
    printf("\n Prtstatus_count : %d",Prtstatus_count);fflush(stdout);

    
    for (pii= 0;pii<Prtstatus_count;pii++)
    {
        ReleaseStatus=NULL;
        ITKCALL(AOM_ask_name(prtstatus_list[pii], &ReleaseStatus));
        strcat(PartLCS,ReleaseStatus);
        strcat(PartLCS,",");
        printf("\n ReleaseStatus %s \n",  ReleaseStatus);fflush(stdout);
        printf("\n  before PartLCS : %s\n",PartLCS); fflush(stdout);
    }

    return ifail;

}
int FindDMLLCS(tag_t DML_tagC1,char* LCSofDML)
{
    int	ifail = ITK_ok;
    int DMLstatus_count = 0;
    int dii;
    tag_t* DMLstatus_list = NULLTAG;
    char* DMLReleaseStatus;

    tc_strcpy(LCSofDML," ");
                                               
    ITKCALL(WSOM_ask_release_status_list(DML_tagC1,&DMLstatus_count,&DMLstatus_list));
    printf("\n  DMLstatus_count : %d",DMLstatus_count);fflush(stdout);

    for (dii= 0;dii<DMLstatus_count;dii++)
    {
        DMLReleaseStatus=NULL;
        ITKCALL(AOM_ask_name(DMLstatus_list[dii], &DMLReleaseStatus));
        strcat(LCSofDML,DMLReleaseStatus);
        strcat(LCSofDML,",");
        printf("\n before LCSofDML : %s \n",LCSofDML); fflush(stdout);
        printf("\n DMLReleaseStatus %s \n",  DMLReleaseStatus);fflush(stdout);
    }

    return ifail;
}

extern EPM_decision_t DLLAPI std_dml_signoff_checks_Func(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int status,i1;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int count_child = 0;
	int   attribute_act_tak;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char *Item_id = NULL;
	//muskan//
	char *AplStdRemarks = NULL;
	char *StdtaskDecision = NULL;
	char *StdTaskDecisionDate = NULL;
	//muskan//
	
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	int i = 0;
	int j = 0;
	int n = 0;
	int stampingdone=0;
	int iGChld = 0;
	char*	itemid;
	char*	itemid1;
	char *  ChildRelErr = NULL;
	//char *  SetStdRelErr = NULL; //added by dss 1.53
	char	**SetStdRelErr = NULL;//Make a string array added by dss 1.53
	int		icount	=	0;//added for dynamic memory allocation; added by dss 1.53
	int		icountprev	=	0;//added for dynamic memory allocation; added by dss 1.53
	char  **SetPrevRevNotification=NULL;
	char*	childPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char *dml_no_id=NULL;	//Deepti  Added TZ1.53
	char *dml_ecnType=NULL;	//Deepti  Added TZ1.53
	//API change
	//char  type_name[TCTYPE_name_size_c+1];
	char *type_name = NULL;

	//API change
	//char  type_itemRev[TCTYPE_name_size_c+1];
	char *type_itemRev = NULL;
	char* type_itemRev1 = NULL;
	char  ChildRevtype_name[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Childtop_line							= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag							= NULLTAG;
	tag_t	item_rev_tag1							= NULLTAG;
	tag_t	itemTypeTag_cdss							= NULLTAG;
	tag_t   itemTypeTag_cdss1  = NULLTAG;
	tag_t	*itemclassp	= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t	value_child_details							= NULLTAG;
	char  req_id[ITEM_id_size_c+1];
	tag_t  *children;
	tag_t  *totalchildren;
	tag_t  	value_act_Tak;
	tag_t  	item_rev_cld_tag;
	tag_t*			PartTags			= NULLTAG;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				ii				= 0;
	char*			value					=NULL;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	char*			Part_no				= NULL;
	int       st_count=0;
	int       iLCS=0;
	int       cntLcs=0;
	int				BypassNACSFlag=0;
	int				BypassAMDMLFlag=0;
	
	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	char STDDmlPlnt[40];
	tag_t  CurrentRoleTag = NULLTAG;
	char *TaskTypeName = NULL;
	char *EPAPlant = NULL;
	//API change
	char *roleName = NULL;
	char		   *PlantName =NULL;
	tag_t			StampAssyPreTag			= NULLTAG;
	char*			StampPart_no				=	NULL;
	char*			StampPart_Rev			=	NULL;
	//API change
	char *stamprev_id1 = NULL;
	char *lcsToset=NULL;
	tag_t	relation_type						= NULLTAG;
	cnt = 0;
	cntFlag = 0;
	char	**SetGMErr = NULL;
	tag_t*	prtTasks1		=	NULLTAG;
	tag_t TaskTypeTag1 = NULLTAG;
	int icount1=0;
	int cntTask1=0;
	int st_count2=0;
	tag_t TaskTypeTag = NULLTAG;
	char *EPARlzStatusName = NULL;
	char* EPAATaskID2 = NULL;
	char* EPAATasknum = NULL;
	tag_t*    status_list_1=NULLTAG;
	tag_t* EPARlzStatus = NULL;
	char *tmp_EPAATaskID = NULL;
	char ***SetChildRelErr;
	int *i1count=0;
	char	*tempErr	=	0;//1.45 added for dynamic memory allocation
	int		iLength	=	0;//1.45 added for dynamic memory allocation


//Added By Dhanashri For Gate Maturation DML Validation at STDSI UATZ 1.45//
	tag_t*			RefPartTags			= NULLTAG;
	int				RefPartCnt				= 0;
//End of Code Added By Dhanashri For Gate Maturation DML Validation at STDSI UATZ 1.45//

	char RevisionRule[40];
	char ClosureRule[40];
	char BVR[40];
	char APLDmlPlnt[40];
	char *task_po_check=NULL;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    SetGMErr = (char**)MEM_alloc( 1 * sizeof *SetGMErr );
    char	**ChangeRefRelErr = NULL;
	ChangeRefRelErr = (char**)MEM_alloc( 1 * sizeof *ChangeRefRelErr );
	int		Errcnt	=	0;

	printf("\n Calling std_dml_signoff_checks_Func %d.....\n",iNumAttch);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n std_dml_signoff_checks_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);
	
	PlantName=subString(roleName,3,4);
	printf( "PlantName:%s\n", PlantName);

	getPlantDetailsAttr_Std(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency,RevisionRule,ClosureRule,BVR,APLDmlPlnt,STDDmlPlnt);//TZ1.41
	printf("\n PlantCS %s \n",PlantCS);
	printf("\n PlantOptCS %s \n",PlantOptCS);
	printf("\n PlantAgency %s \n",PlantIA);
	printf("\n PlantStore %s \n",PlantStore);
	printf("\n UserAgency %s \n",UserAgency);
	printf("\n STDDmlPlnt %s \n",STDDmlPlnt);

     if(tc_strcmp(CurrentTask,"Create EPA" )==0)
	{
 	
	
	ITKCALL( TCTYPE_find_type("T5_APLTaskRevision", NULL, &ItemTypeTag));

	printf("\n iNumAttch %d.....\n",iNumAttch);
	for (i=0; i < iNumAttch; i++)
	{
		tag_t objTypeTag = NULLTAG;
		tag_t objChildRevTag = NULLTAG;

		const char *qry_entries[1];
		const char *qry_values[1];

//		char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
//		char **values = (char **) MEM_alloc(1 * sizeof(char *));

		int n_tags_found=0;

		 tag_t	*itemclass							= NULLTAG;

		  tag_t item = NULLTAG;

		ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
		printf("\n itemid %s.....\n",itemid);
		qry_entries[0] ="item_id";
		qry_values[0] = itemid;

		ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
		 item = itemclass[0];
		if(item != NULLTAG )
		ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));
		
			
		int PartCntB1,icount_Clr2basedf=0;
		tag_t*			PartTagsB1		= NULLTAG;
		char*			PrntStampPart_no				= NULL;

		//muskan code start//
		
				if(tc_strcmp(PlantName,"STDC")!= 0)
				{
			    ITKCALL(AOM_ask_value_string(pTagAttch[i],"t5_AplStdRemrks",&AplStdRemarks));
				 printf("\nAplStdRemarks is: %s",AplStdRemarks);
				
					 if(strcmp(AplStdRemarks,"")==0)
						{
							printf("\n  under the error  statment\n");fflush(stdout);
							char *t5MlStIntialErr=NULL;



							t5MlStIntialErr = (char *) MEM_alloc( 1000 * sizeof(char) );
							strcpy(t5MlStIntialErr,"");
							strcpy(t5MlStIntialErr,"Please fill APL/STDS remark before signoff the task.\n Select the Task ->Go to ->Manufacturing Menu->Implementation-->APL/STDS Reamrk Update");//manindra Added Path
							
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStIntialErr);
							return 1;
	
						}

			  ITKCALL(AOM_ask_value_string(pTagAttch[i],"t5_StdTaskDecision",&StdtaskDecision));
				   printf("\nStdtaskDecision is: %s",StdtaskDecision);
				 
				 if(strcmp(StdtaskDecision,"")==0)

						{
							printf("\n  under the error  statment\n");fflush(stdout);
							char *t5MlStIntialErr=NULL;



							t5MlStIntialErr = (char *) MEM_alloc( 1000 * sizeof(char) );
							strcpy(t5MlStIntialErr,"");
							strcpy(t5MlStIntialErr,"Please fill STD Decision on Task before signoff the Task.\n Select the Task ->Go to ->Manufacturing Menu->Implementation-->APL/STDS Reamrk Update"); //manindra Added Path
							
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStIntialErr);
							return 1;
	
						}

                    ITKCALL(AOM_ask_value_string(pTagAttch[i],"t5_StdTaskDecisionDate",&StdTaskDecisionDate));
                       printf("\nStdTaskDecisionDate is: %s",StdTaskDecisionDate);
	                
					if(strcmp(StdTaskDecisionDate,"")==0)

							{
								printf("\n  under the error  statment\n");fflush(stdout);
								char *t5MlStIntialErr=NULL;

 

								t5MlStIntialErr = (char *) MEM_alloc( 1000 * sizeof(char) );
								strcpy(t5MlStIntialErr,"");
								strcpy(t5MlStIntialErr,"Please fill STD Decision Date against APL-Task before signoff the Task.\n Select the Task ->Go to ->Manufacturing Menu->Implementation-->APL/STDS Reamrk Update");//manindra Added Path
								
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_err,t5MlStIntialErr);
								return 1;
		
							}

				}
//muskan end of code//


				/********************** am927460 RBQU DML **********************************/

				ITKCALL (TCTYPE_ask_object_type(item_rev_tag,&itemTypeTag_cdss1));
				ITKCALL (TCTYPE_ask_name2(itemTypeTag_cdss1,&type_itemRev1));

				printf("\t  type_itemRev1 ...%s\n", type_itemRev1);

                    char* DML_rlstype = NULL;
                    char** relations  = NULL;
                    
                    char* rlstypeofDML = NULL;
                    char LcsSTD[40];
                    char LcsAPL[40];
                    
                    //LcsSTD = (char *)MEM_alloc(50 * sizeof(char *));
                    char* DMLCat = NULL;

                    tag_t* PtrTags = NULLTAG;
                    tag_t PartTg =NULLTAG;
                    tag_t DML_tagC = NULLTAG;
                    tag_t DML_tagC1 = NULLTAG;
                    tag_t DMLTaskRel = NULLTAG;
                    tag_t* DMLTagList = NULLTAG;
                    tag_t* DMLTagList1 = NULLTAG;
                    tag_t* 	referencers  = NULLTAG;
                    tag_t referencers_tag = NULLTAG;

                    int pc;
                    int dmlc = 0;
                    int Ptrcnt = 0;
                    int DMLcnt = 0;
                    int DMLcnt1 = 0;
                    int* levels=0;
	                int n_referencers = 0;
                    int falg = 0;
                    int dmlc1 = 0;
                    int RBQUFlag = 0;
                    int countofDML = 0;
                

                    struct RBQUStrut RBQUStructObj[1000];

                    if(tc_strcmp(type_itemRev1,"T5_APLTaskRevision")==0)
                    {
                        printf("\n\n Inside T5_APLTaskRevision");fflush(stdout);

                        ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &DMLTaskRel));
                        if (DMLTaskRel != NULLTAG)
                        {
                            ITKCALL(GRM_list_primary_objects_only(item_rev_tag, DMLTaskRel, &DMLcnt, &DMLTagList));
                            printf("\n\n\t  CountDML : %d", DMLcnt);fflush(stdout);

                            for(dmlc = 0; dmlc < DMLcnt; dmlc++)
                            {
                                char* RBQUDML = NULL;
                                char* NewDML_Num = NULL;
                                char* DML_Num = NULL;
                                char* PLT_Code = NULL;

                                DML_tagC = DMLTagList[dmlc];
                                ITKCALL(AOM_ask_value_string(DML_tagC,"t5_rlstype",&DML_rlstype));
                                printf("\n\n DML_rlstype : %s",DML_rlstype);fflush(stdout);

                                ITKCALL(AOM_ask_value_string(DML_tagC,"item_id",&RBQUDML));
                                printf("\n\n DML_no : %s",RBQUDML);fflush(stdout);

                                NewDML_Num = (char *)MEM_alloc(20);
                                tc_strcpy(NewDML_Num, RBQUDML);
                                DML_Num = tc_strtok(NewDML_Num, "_");
                                PLT_Code = tc_strtok(NULL, "_");
								printf("\n\n PLT_Code : %s",PLT_Code);fflush(stdout);

                                if(tc_strcmp(DML_rlstype,"RBQU")==0)
                                {
                                   
                                    ITKCALL(AOM_ask_value_tags(item_rev_tag, "CMReferences", &Ptrcnt, &PtrTags));
                                    printf("\n\n PartCnt:%d", Ptrcnt);fflush(stdout);

                                    if (Ptrcnt > 0)
                                    {
                                        for (pc = 0; pc < Ptrcnt; pc++)
                                        {
                                            RBQUFlag = 0;
                                            int l;
                                            char* PartItemID = NULL;
                                            char* PartLCS = NULL;
                                            PartLCS = (char *)MEM_alloc(100 * sizeof(char *));

                                            printf("\n\n pc = : %d", pc);fflush(stdout);
                                            PartTg = PtrTags[pc];
                                            ITKCALL(AOM_ask_value_string(PartTg, "item_id", &PartItemID));
                                            printf("\n PartItemID :  %s\n",PartItemID); fflush(stdout);

                                            FindPartLCS(PartTg,PartLCS);                                          
                                            printf("\n After for PartLCS : %s\n",PartLCS); fflush(stdout);

                                            ITKCALL(WSOM_where_referenced2(PartTg,1,&n_referencers,&levels,&referencers,&relations));
                                            printf("\n n_referencers : %d\n",n_referencers); fflush(stdout);
                                            DMLCat = (char *)MEM_alloc(50);
                                            tc_strcpy(DMLCat," ");

                                            for(l=0;l<n_referencers;l++)
                                            {
                                                char* Tsk_no = NULL;
                                                char* Taskobjecttype = NULL;

                                                referencers_tag = NULLTAG;
                                                referencers_tag = referencers[l];

                                                ITKCALL(AOM_ask_value_string(referencers_tag,"object_type",&Taskobjecttype));
                                                printf("\n Taskobjecttype : %s \n",Taskobjecttype); fflush(stdout);

                                                if(tc_strcmp(Taskobjecttype,"T5_APLTaskRevision")==0)
                                                {
                                                    ITKCALL(AOM_ask_value_string(referencers_tag,"item_id",&Tsk_no));
                                                    printf("\n Tsk_no : %s \n",Tsk_no); fflush(stdout);

                                                    ITKCALL(GRM_list_primary_objects_only(referencers_tag, DMLTaskRel, &DMLcnt1, &DMLTagList1));
                                                    printf("\n\n\t  DMLcnt1 : %d", DMLcnt1);fflush(stdout);

                                                    for(dmlc1 = 0; dmlc1 < DMLcnt1; dmlc1++)
                                                    {
                                                        char* DML_ItemId = NULL;
                                                        char* DML_rlstype1 = NULL;
                                                        char* LCSofDML = NULL;
                                                        LCSofDML = (char *)MEM_alloc(100 * sizeof(char *));
                                                       
                                                        DML_tagC1 = DMLTagList1[dmlc1];
                                                        ITKCALL(AOM_ask_value_string(DML_tagC1,"item_id",&DML_ItemId));
                                                        printf("\n\n DML_ItemId : %s",DML_ItemId);fflush(stdout);
                                                        
                                                        ITKCALL(AOM_ask_value_string(DML_tagC1,"t5_rlstype",&DML_rlstype1));
                                                        printf("\n\n DML_rlstype1 : %s",DML_rlstype1);fflush(stdout);

                                                        FindDMLLCS(DML_tagC1,LCSofDML);

                                                        // ITKCALL(AOM_UIF_ask_value(DML_tagC1,"release_status_list",&LCSofDML));
                                                        printf("\n After LCSofDML : %s \n",LCSofDML); fflush(stdout);

                                                        if((tc_strcmp(DML_rlstype1,"RBQU")!=0) && (tc_strcmp(DML_rlstype1,"TODR")!=0) && (tc_strstr(DML_ItemId,PLT_Code)!=NULL))
                                                        {
															
                                                            PlantWiseRelStatGMDML(Tsk_no,LcsAPL,LcsSTD);
                                                            printf("\n\n LcsSTD from PlantWiseRelStatGMDML : %s",LcsSTD);fflush(stdout);
                                                            printf("\n\n PartLCS : %s",PartLCS);fflush(stdout);
                                                            printf("\n\n LCSofDML : %s",LCSofDML);fflush(stdout);

                                                            if(tc_strstr(PartLCS,LcsSTD)!=NULL)
                                                            {
                                                                printf("\n Part is released \n"); fflush(stdout);
                                                            }
                                                            else
                                                            {
                                                                printf("\n Part is not released so checking DML\n"); fflush(stdout);
                                                                if(tc_strstr(LCSofDML,LcsSTD)!=NULL)
                                                                {

                                                                    printf("\n DML attached to RBQU DML change reference part is already released \n"); fflush(stdout);
                                                                }
                                                                else
                                                                {
                                                                    printf("\n Please release DML : %s first \n",DML_ItemId); fflush(stdout);

                                                                    if(tc_strcmp(DMLCat," ")==0)
                                                                    {
                                                                        tc_strcpy(DMLCat,DML_ItemId);
                                                                    }
                                                                    else
                                                                    {
                                                                        tc_strcat(DMLCat,",");
                                                                        tc_strcat(DMLCat,DML_ItemId);
                                                                    }
                                                                    RBQUFlag++;
                                                                                                                                
                                                                }
                                                            }
                                                            
                                                        }
                                                        else
                                                        {
                                                            printf("\n DML is either RBQU or TODR \n"); fflush(stdout);
                                                        }

                                                    }
                                                }
                                                else
                                                {
                                                    printf("\n Task is not APLTask \n"); fflush(stdout);
                                                }
                                            }
                                            printf("\n RBQUFlag : %d \n",RBQUFlag); fflush(stdout);
                                            if(RBQUFlag>0)
                                            {
                                                printf("\n Copying DML into structure \n"); fflush(stdout);
                                                countofDML = countofDML +1;
                                                RBQUStructObj[countofDML].Part_num = PartItemID;
                                                RBQUStructObj[countofDML].DML_num = DMLCat;    
                                                printf("\n RBQUStructObj[countofDML].Part_num : %s \n",RBQUStructObj[countofDML].Part_num); fflush(stdout);
                                                printf("\n RBQUStructObj[countofDML].DML_num : %s \n", RBQUStructObj[countofDML].DML_num); fflush(stdout);
                                                

                                            }


                                        }
                                        printf("\n countofDML : %d \n",countofDML); fflush(stdout); 
                                        char *Validation = NULL;
                                        Validation = (char *)MEM_alloc(3000 * sizeof(char));
                                        tc_strcpy(Validation," ");
                                        int vali;
                                        if(countofDML>0)
                                        {
                                            printf("\n countofDML : %d \n",countofDML); fflush(stdout); 

                                            for( vali=1 ; vali <= countofDML;vali++)
                                            {
                                                if(tc_strcmp(Validation," ")==0)
                                                {
                                                    tc_strcat(Validation,"Part : ");
                                                    tc_strcat(Validation,RBQUStructObj[vali].Part_num);
                                                    tc_strcat(Validation," is attached to DML/DML's : ");
                                                    tc_strcat(Validation,RBQUStructObj[vali].DML_num);
                                                    tc_strcat(Validation," . Please release these DML first. \n");
                                                }
                                                else
                                                {
                                                    tc_strcat(Validation,"Part : ");
                                                    tc_strcat(Validation,RBQUStructObj[vali].Part_num);
                                                    tc_strcat(Validation," is attached to DML/DML's : ");
                                                    tc_strcat(Validation,RBQUStructObj[vali].DML_num);
                                                    tc_strcat(Validation," . Please release these DML first. \n");
                                                }
                                                
                                            }
                                            printf("\n Validation %s \n",Validation); fflush(stdout);
											EMH_store_error_s1(EMH_severity_error,ITK_errStore1,Validation);
											decision = EPM_nogo;
											return ITK_errStore1;
                                        }

                                     
                         
                                    }
                                    else
                                    {
                                        printf("\n\n Parts attached in CMReferences folder of RBQU :%d ",Ptrcnt);fflush(stdout);
                                    }
                                }
                                else
                                {
                                    printf("\n\n DML Release type is not RBQU ");fflush(stdout);
                                }
                            }
                            
                        }
                    }
                    else
                    {
                        printf("\n\n Task is not APL Task Revision ");fflush(stdout);
                    }
                    
                  
                    /********************** End of RBQU DML **********************************/
		
		printf("\n Akhilesh entering validation code .....\n");
		
		ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCntB1,&PartTagsB1));
			printf("\n\n\t\t APL DML Cre:Now PartCntB1:%d",PartCntB1);fflush(stdout);

		//Added by Amar
		printf("\n Amar Start Finding CS_Parent_Child_Checks ...!!!\n");
		char    *qry_entryCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
		char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));
		
		tag_t   qryTagCntrl			= NULLTAG;
		tag_t*	list_of_WSO_cntrl_tags = NULLTAG;
		
		int     n_entryCntrl					= 3;
		int		control_number_found_NullCSCheckAtStd	= 0;

		char	*closureRuleName1	= NULL;
		int APLclosureRulecount=0;
		//char	*Plant_Suffix		= NULL;

		char **SetChildRelErr = NULL;;
		SetChildRelErr = (char**)MEM_alloc( 20 * sizeof *SetChildRelErr );

		int n_closure_tags;
		tag_t closure_tag;
		tag_t *closure_tags;
		PIE_scope_t scope;
		
		if( QRY_find2("Control Objects...", &qryTagCntrl));
		if (qryTagCntrl)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrl[0]="NullCSCheckAtStd";
			qry_valuesCntrl[1]="PV";  
			qry_valuesCntrl[2]="0";
			
			if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found_NullCSCheckAtStd, &list_of_WSO_cntrl_tags));
		}
		else
		{
			printf("\n Control Object Query not Found \n");fflush(stdout);
		}	
			
		printf("\n control_number_found_NullCSCheckAtStd is : %d\n",control_number_found_NullCSCheckAtStd);fflush(stdout);
		
		if(control_number_found_NullCSCheckAtStd>0)
		{
			 CS_Parent_Child_Checks_std(PartCntB1,item_rev_tag, PartTagsB1, &SetChildRelErr, PlantCS, ClosureRule, &icount);
		     printf("\n SetChildRelErr: %s\n", SetChildRelErr);fflush(stdout);

			 if (icount > 0)
             {
                 iLength = 0;
                 if (!tempErr)
                     MEM_free(tempErr);
                 i = 0;
                 for (i = 0; i < icount; i++)
                 { 
                     tempErr = SetChildRelErr[i];
                     iLength = iLength + tc_strlen(tempErr);
                 }
                 printf("CS_Parent_Child_Checks EBOM-MBOM iLength : %d", iLength);
                 fflush(stdout);
                 if (!tempErr)
                     MEM_free(tempErr);
                 tempErr = (char *)MEM_alloc(iLength + 60);
                 tc_strcpy(tempErr, "Task:-"); // task number added in error pop up.......
                 tc_strcat(tempErr, itemid);   // task number added in error pop up.......
                 tc_strcat(tempErr, "\n");     //
                 i = 0;
                 printf("\nBefore For loop");
                 fflush(stdout);
                 for (i = 0; i < icount; i++)
                 {
                     /* if(i==0)
                         tc_strcpy(tempErr,SetChildRelErr[i]);
                     else */
                     tc_strcat(tempErr, SetChildRelErr[i]);
                 }
                 printf("\n CS_Parent_Child_Checks EBOM-MBOM Printing Errors...!!!");
                 fflush(stdout);
                 printf("%s", tempErr);
                 fflush(stdout);
                 EMH_clear_errors();
                 status = EMH_store_error_s1(EMH_severity_error, ITK_Prjerr, tempErr);
                 decision = EPM_nogo;
                 return ITK_errStore;
             }
		     
		}	 
		
		//End
			
		/*********** Akhilesh code to check for part stamp attribute for TZ UA1.73 SCO 9643********/
		
		char    *qry_entryCntrl1[2]  = {"SYSCD","Delete Indicator"};	
		char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

		int cntrlcnt=0;
		int  control_number_found1=0;

		tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

		tag_t   qryTagCntrl1     = NULLTAG;
		int     n_entryCntrl1    = 2;
		 
		if(QRY_find2("Control Objects...", &qryTagCntrl1));
		if (qryTagCntrl1)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrl1[0]="SMEPAStampCntObj";
			
			qry_valuesCntrl1[1]="0";
			
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		}
		else
		{
			printf("\n Akki Control Object Query not Found \n");fflush(stdout);
		}

		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
		
		int allErrMsg=0;
		char* AllerrorDup = NULL ;
		AllerrorDup = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
		tc_strcpy(AllerrorDup,"");
		
		if(control_number_found1>0)
		{
			
			for (i1=0; i1 < PartCntB1; i1++)
			{
				tag_t objTypeTag = NULLTAG;
				tag_t objChildRevTag = NULLTAG;

				const char *qry_entries1[1];
				const char *qry_values1[1];
				
				int n_tags_found1=0;

				 tag_t	*itemclass1							= NULLTAG;

				  tag_t item1 = NULLTAG;
				ITKCALL(AOM_ask_value_string(PartTagsB1[i1], "item_id",&itemid1));
				printf("\n itemid1 %s.....\n",itemid1);
				qry_entries1[0] ="item_id";
				qry_values1[0] = itemid1;
				ITEM_find_items_by_key_attributes(1, qry_entries1, qry_values1,&n_tags_found1, &itemclass1);
				 item1 = itemclass1[0];
				// if(item1 != NULLTAG )
				// ITKCALL(ITEM_ask_latest_rev(item1,&item_rev_tag1));
											
				if(tc_strstr(PlantName,"STD")!=NULL)
				{
						
					if((tc_strstr(PlantName,"STDC")!=NULL) || (tc_strstr(PlantName,"STDJ")!=NULL) || (tc_strstr(PlantName,"STDL")!=NULL) || (tc_strstr(PlantName,"STDU")!=NULL) || (tc_strstr(PlantName,"STDP")!=NULL) || (tc_strstr(PlantName,"STDD")!=NULL) )
					{
			
						ITKCALL(AOM_ask_value_string(PartTagsB1[i1],"item_revision_id",&StampPart_Rev));
						ITKCALL(AOM_ask_value_string(PartTagsB1[i1],"item_id",&PrntStampPart_no));						// For Akki reference
						
						/*********** Neww Validation for SM/EPA Check Akhilesh ********************/
						
						printf("\n Neww Validation start from here");
						ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
						ITKCALL( GRM_list_primary_objects_only(PartTagsB1[i1],relation_type,&cntTask1,&prtTasks1));
						printf("\n cntTask1 : %d",cntTask1);fflush(stdout);
						int epaflag=0;														
						if (cntTask1 > 0)
						{
							for (j=0;j<cntTask1;j++ )
							{
								
								ITKCALL(TCTYPE_ask_object_type(prtTasks1[j],&TaskTypeTag));
								ITKCALL(TCTYPE_ask_name2(TaskTypeTag,&TaskTypeName));
																	
								if (tc_strcmp(TaskTypeName,"T5_EPATaskRevision")== 0)
								{
								
									if( AOM_ask_value_string(prtTasks1[j],"item_id",&EPAATasknum)==ITK_ok)
									printf("\n Task Attched is %s\n",EPAATasknum); fflush(stdout);
									
									//tc_strcpy(EPAATaskID2,EPAATasknum);
									//printf("\n EPAATaskID2 = %s\n",EPAATaskID2);fflush(stdout);
									
									tmp_EPAATaskID = strtok(EPAATasknum,"_");
									tmp_EPAATaskID = strtok(NULL,"_");
									EPAPlant = strtok(NULL,"_");
									printf("\n EPAPlant : %s  \n",EPAPlant);fflush(stdout);
									EPARlzStatusName	=	NULL;
									//ITKCALL(WSOM_ask_release_status_list(prtTasks1[j],&st_count2,&EPARlzStatusName));
									ITKCALL(AOM_UIF_ask_value(prtTasks1[j], "release_status_list", &EPARlzStatusName));
									printf("\n st_count2 (EPATag) = %s ",EPARlzStatusName);fflush(stdout);
									
									//if (st_count2>0)
									//{
										//for (l=0;l<st_count2;l++)
										//{	
											
											//AOM_ask_name(EPARlzStatus[l], &EPARlzStatusName);
											printf("\n EPARlzStatusName (EPATag) : %s \n",EPARlzStatusName);fflush(stdout);
											printf("\n PlantName (EPATag) : %s \n",PlantName);fflush(stdout);
											printf("\n EPAPlant (EPATag) : %s \n",EPAPlant);fflush(stdout);
											
											if(((tc_strstr(PlantName,"STDJ")!=NULL) && (tc_strstr(EPAPlant,"APLJ")!=NULL )&& (tc_strstr(EPARlzStatusName,"STDSIJ Working")!= NULL)) ||
											((tc_strstr(PlantName,"STDL")!=NULL) && (tc_strstr(EPAPlant,"APLL")!=NULL)&& (tc_strstr(EPARlzStatusName,"STDSIL Working")!= NULL)) ||
											((tc_strstr(PlantName,"STDU")!=NULL) && (tc_strstr(EPAPlant,"APLU")!=NULL) && (tc_strstr(EPARlzStatusName,"STDSIU Working")!= NULL)) ||
											((tc_strstr(PlantName,"STDP")!=NULL) && (tc_strstr(EPAPlant,"APLP")!=NULL )&& (tc_strstr(EPARlzStatusName,"STDSIP Working")!= NULL)) ||
											((tc_strstr(PlantName,"STDD")!=NULL) && (tc_strstr(EPAPlant,"APLD")!=NULL )&& (tc_strstr(EPARlzStatusName,"STDSID Working")!= NULL)) ||
											((tc_strstr(PlantName,"STDA")!=NULL) && (tc_strstr(EPAPlant,"APLA")!=NULL )&& (tc_strstr(EPARlzStatusName,"STDSIA Working")!= NULL)) ||
											((tc_strstr(PlantName,"STDS")!=NULL) && (tc_strstr(EPAPlant,"APLS")!=NULL )&& (tc_strstr(EPARlzStatusName,"STDSIS Working")!= NULL)) ||
											((tc_strstr(PlantName,"STDC")!=NULL) && (tc_strstr(EPAPlant,"APLC")!=NULL) && (tc_strstr(EPARlzStatusName,"STDSIC Working")!= NULL)))
											{
												
												epaflag=1;
												break;
											}
											
										//}
										
									//}
									
								}
							}
						}
						printf("\n Neww Validation END  here");
						/***************End of Neww validation for SM/EPA check by Akhilesh **************/
						StampAssyPreTag			= NULLTAG;
						if(epaflag==0)
						{
							if(tc_strstr(StampPart_Rev,"NR") != NULL)
							{
								printf("\n Previous revision function can not be called as current revision has NR revision");fflush(stdout);
								
							}
							else
							{
								printf("\n Akki Calling function to get Previous revision ");fflush(stdout);
								
								tm_fnd_Prev_Official_Revision(PrntStampPart_no,PartTagsB1[i1],&StampAssyPreTag);//TZ 1.43
							}
						
							if(StampAssyPreTag)
							{					
									//API change
								ITEM_ask_rev_id2( StampAssyPreTag, &stamprev_id1);

								printf("\n stamprev_id1 is  ---->%s\n", stamprev_id1);fflush(stdout);//diplay the previous revision					

								
								char*			CpyRefDescValue				= NULL;
													 
								//ITKCALL(AOM_ask_value_string(PartTagsB1[i1],"t5_JdlStoreLocation",&CpyRefDescValue));
								ITKCALL(AOM_ask_value_string(StampAssyPreTag,"t5_JdlStoreLocation",&CpyRefDescValue));
								printf("\n\n\t\t Value of Akki CpyRefDescValue  is :%s",CpyRefDescValue);	fflush(stdout);
								
								//if(tc_strcmp(CpyRefDescValue,"")!=0)
								if((CpyRefDescValue!=NULL)&&(tc_strcmp(CpyRefDescValue,"")!=0))
								{
									printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);

									if(tc_strstr(PlantName,"STDJ")!=NULL)
									 {
										if( tc_strstr(CpyRefDescValue,"EPAJ")!=NULL || tc_strstr(CpyRefDescValue,"SMJ")!=NULL)
										{
											printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);
											
											char* errorDup = NULL ;
											errorDup = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
											tc_strcpy(errorDup,"");
											tc_strcat(errorDup,"This Part ");
											tc_strcat(errorDup,PrntStampPart_no);
											tc_strcat(errorDup," previous rev is attached with EPA or SM in TCE, first release it there.");
											allErrMsg=1;
											tc_strcat(AllerrorDup,errorDup);
											printf("\n For APLJ msggg Error Msg :[%s]",AllerrorDup);fflush(stdout);
											
											//EMH_clear_errors();
										//	EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorDup);
											//return ITK_errStore1;

										}
									 }
									 else if(tc_strstr(PlantName,"STDP")!=NULL)
									 {
										 if( tc_strstr(CpyRefDescValue,"EPAP")!=NULL || tc_strstr(CpyRefDescValue,"SMP")!=NULL)
										 {
											printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);
											
											char* errorDup = NULL ;
											errorDup = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
											tc_strcpy(errorDup,"");
											tc_strcat(errorDup,"This Part ");
											tc_strcat(errorDup,PrntStampPart_no);
											tc_strcat(errorDup," previous rev is attached with EPA or SM in TCE, first release it there.");
											allErrMsg=1;
											tc_strcat(AllerrorDup,errorDup);
											printf("\n For APLP msggg Error Msg :[%s]",AllerrorDup);fflush(stdout);
											
											//EMH_clear_errors();
											//EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorDup);
											//return ITK_errStore1;

										}
									 }
									 else if(tc_strstr(PlantName,"STDL")!=NULL)
									 {
										if( tc_strstr(CpyRefDescValue,"EPAL")!=NULL || tc_strstr(CpyRefDescValue,"SML")!=NULL)
										 {
											printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);
											
											char* errorDup = NULL ;
											errorDup = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
											tc_strcpy(errorDup,"");
											tc_strcat(errorDup,"This Part ");
											tc_strcat(errorDup,PrntStampPart_no);
											tc_strcat(errorDup," previous rev is attached with EPA or SM in TCE, first release it there.");
											allErrMsg=1;
											tc_strcat(AllerrorDup,errorDup);
											printf("\n For APLL msggg Error Msg :[%s]",AllerrorDup);fflush(stdout);
											
											//EMH_clear_errors();
											//EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorDup);
											//return ITK_errStore1;

										}
									 }
									 else if(tc_strstr(PlantName,"STDD")!=NULL)
									 {
										 if( tc_strstr(CpyRefDescValue,"EPAD")!=NULL || tc_strstr(CpyRefDescValue,"SMD")!=NULL)
										 {
											printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);
											
											char* errorDup = NULL ;
											errorDup = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
											tc_strcpy(errorDup,"");
											tc_strcat(errorDup,"This Part ");
											tc_strcat(errorDup,PrntStampPart_no);
											tc_strcat(errorDup," previous rev is attached with EPA or SM in TCE, first release it there.");
											allErrMsg=1;
											tc_strcat(AllerrorDup,errorDup);
											printf("\n For APLD msggg Error Msg :[%s]",AllerrorDup);fflush(stdout);
											
											//EMH_clear_errors();
											//EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorDup);
											//return ITK_errStore1;

										}
									 }
									 else if(tc_strstr(PlantName,"STDU")!=NULL)
									 {
										 if( tc_strstr(CpyRefDescValue,"EPAU")!=NULL || tc_strstr(CpyRefDescValue,"SMU")!=NULL)
										 {
											printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);
											
											char* errorDup = NULL ;
											errorDup = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
											tc_strcpy(errorDup,"");
											tc_strcat(errorDup,"This Part ");
											tc_strcat(errorDup,PrntStampPart_no);
											tc_strcat(errorDup," previous rev is attached with EPA or SM in TCE, first release it there.");
											allErrMsg=1;
											tc_strcat(AllerrorDup,errorDup);
											printf("\n For APLU msggg Error Msg :[%s]",AllerrorDup);fflush(stdout);
											
											//EMH_clear_errors();
											//EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorDup);
											//return ITK_errStore1;

										}
									 }
									 else if(tc_strstr(PlantName,"STDC")!=NULL)
									 {
										 if( tc_strstr(CpyRefDescValue,"EPAC")!=NULL || tc_strstr(CpyRefDescValue,"SMC")!=NULL)
										 {
											printf("\n 111..CpyRefDescValue is :%s\n",CpyRefDescValue);fflush(stdout);
											
											char* errorDup = NULL ;
											errorDup = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
											tc_strcpy(errorDup,"");
											tc_strcat(errorDup,"This Part ");
											tc_strcat(errorDup,PrntStampPart_no);
											tc_strcat(errorDup," previous rev is attached with EPA or SM in TCE, first release it there.");
											allErrMsg=1;
											tc_strcat(AllerrorDup,errorDup);
											printf("\n For APLC msggg Error Msg :[%s]",AllerrorDup);fflush(stdout);
											
											//EMH_clear_errors();
											//EMH_store_error_s1(EMH_severity_error,ITK_errStore1,errorDup);
											//return ITK_errStore1;

										}
									 }
													
								}
							}
					}	
					}
				}
			}
			if(allErrMsg>0)
			{
				printf("\n Final Error Msg :[%s]",AllerrorDup);fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_errStore1,AllerrorDup);
				return ITK_errStore1;
			}
		}
					
		printf("\n Akhilesh Exiting validation code .....\n");	
		/*********** End of Akhilesh code to check for part stamp attribute for TZ UA1.73 SCO 9643********/

		//Sanket

		printf("\n Calling CheckPrtRelsFrmPlant_STD ..... \n");

			CheckPrtRelsFrmPlant_STD(item_rev_tag,&ChangeRefRelErr,&Errcnt); //added by dss 1.53
			printf("\n cntFlag_6: %d",cntFlag);fflush(stdout);

			if(cntFlag==1)
			 {
				iLength	=	0;
				if (!tempErr) MEM_free(tempErr);
				i=0;
				for (i=0; i < Errcnt; i++)
				{
					//printf("%s",SetChildRelErr[i]);fflush(stdout);
					tempErr	=	ChangeRefRelErr[i];
					iLength	=	iLength	+	tc_strlen(tempErr);
				}
				printf("iLength : %d",iLength);fflush(stdout);
				if (!tempErr) MEM_free(tempErr);
				tempErr	=	(char *)MEM_alloc(iLength+20);
				i=0;
				for (i=0; i < Errcnt; i++)
				{
					//printf("%s",SetChildRelErr[i]);fflush(stdout);
					if(i==0)
						tc_strcpy(tempErr,ChangeRefRelErr[i]);
					else
						tc_strcat(tempErr,ChangeRefRelErr[i]);
				}
				printf("\nPrinting Errors...!!!");fflush(stdout);
				printf("%s",tempErr);fflush(stdout);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
				decision = EPM_nogo;
				return ITK_errStore;
			 }

		//Sanket

		printf("\n itemid %s \n",itemid);
		ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
		ITKCALL( TCTYPE_ask_name2( objTypeTag, &type_name) );
		printf("\t  type_name ...%s\n", type_name);
		if( objTypeTag == ItemTypeTag )
		{
			printf("\t \n objTypeTag == ItemTypeTag \n");

			ITKCALL (TCTYPE_ask_object_type(item_rev_tag,&itemTypeTag_cdss));
			ITKCALL (TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));

			printf("\t  type_itemRev ...%s\n", type_itemRev);
			//Added by dss 1.53
			//if (!SetStdRelErr) MEM_free(SetStdRelErr);
			//SetStdRelErr=(char *)MEM_alloc(5000);
           // tc_strcpy(SetStdRelErr,"");
			//ALLOCATE MEMORY FOR ERROR MESSAGE.
			SetStdRelErr = (char**)MEM_alloc( 1 * sizeof *SetStdRelErr );
			//Added by dss 1.53

				//if (!SetPrevRevNotification) MEM_free(SetPrevRevNotification);
				//SetPrevRevNotification=(char *)MEM_alloc(5000);
				//tc_strcpy(SetPrevRevNotification,"");
				SetPrevRevNotification = (char**)MEM_alloc( 1 * sizeof *SetPrevRevNotification );

			if(tc_strcmp(type_itemRev,"T5_APLTaskRevision" )==0)
			{
			  // Code Added by Dhanashri to get DML from Task////
			  tag_t			TskToDMLRel= NULLTAG;
			  tag_t			DMLRevTagg		= NULLTAG;
			  tag_t			DMLTypeTag		= NULLTAG;
			  tag_t*			DMLTagg		= NULLTAG;

			  int CountDML=0;
			  int Counter=0;

			  logical			isltstdmll;

			//API change
			 // char			DMLTyp[TCTYPE_name_size_c+1];
			 char *DMLTyp = NULL;
			  char*			ProjectCode				= NULL;
			  char*			Release_Type				= NULL;
			

				printf("\n\n\t\t Test dss .. ");fflush(stdout);
				ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &TskToDMLRel));
				if (TskToDMLRel!=NULLTAG)
				{
					ITKCALL(GRM_list_primary_objects_only(item_rev_tag,TskToDMLRel,&CountDML,&DMLTagg));
					printf("\n\n\t\t dss CountDML : %d",CountDML);fflush(stdout);

					for (Counter=0;Counter<CountDML ;Counter++ )
					{
						ITKCALL(ITEM_rev_sequence_is_latest(DMLTagg[Counter],&isltstdmll));
						printf("\n\n\t\t isltstdmll : %d\n",isltstdmll);fflush(stdout);

						if(isltstdmll != true)
						{
							printf("\n\n\t\t isltstdmll is not true .....\n");fflush(stdout);
						}else
						{
							printf("\n\n\t\t isltstdmll is  true .....\n");fflush(stdout);
							DMLRevTagg = DMLTagg[Counter];

							ITKCALL (TCTYPE_ask_object_type(DMLRevTagg,&DMLTypeTag));
							ITKCALL (TCTYPE_ask_name2(DMLTypeTag,&DMLTyp));
							printf("\n DMLTyp= %s \n",DMLTyp);fflush(stdout);
							//printf("\n\n\t\t isltstdmll is  true test .....\n");fflush(stdout);

							if(tc_strcmp(DMLTyp,"T5_APLDMLRevision")==0)
							{
							  AOM_ask_value_string( DMLRevTagg, "t5_cprojectcode", &ProjectCode);
  							  printf("\n ProjectCode : %s\n",ProjectCode);fflush(stdout);

							  ITKCALL(AOM_ask_value_string(DMLRevTagg,"t5_rlstype",&Release_Type));
							  printf("\n\t Release_Type is :%s",Release_Type);fflush(stdout);

							  ITKCALL(AOM_ask_value_string(DMLRevTagg,"item_id",&dml_no_id));	//Deepti Added TZ1.53
							  printf("\n\t dml_no_id is :%s",dml_no_id);fflush(stdout);

							  if(tc_strstr(dml_no_id,"AM")!=NULL)
							  {
								 ITKCALL(AOM_ask_value_string(DMLRevTagg,"t5_EcnType",&dml_ecnType));
									printf("\n\t dml_ecnType is :%s",dml_ecnType);fflush(stdout);
							  
							  }
																					
							}
						}
					}
				}


			  //End Of Code Added by Dhanashri ////

			  	//Added By Dhanashri For Gate Maturation DML Validation at STDSI UATZ 1.45//
				  printf("\n\t Release_Type is :%s",Release_Type);fflush(stdout);



				//Start Adding code for bypass using control object
	
				char    *qry_entryCntrlBypass[4]  	= 	{"SYSCD","SUBSYSCD","Information-1","Delete Indicator"};	
				char	**qry_valuesCntrlBypass		= 	(char **) MEM_alloc(5 * sizeof(char *));
				tag_t	qryTagCntrlBypass			=	NULLTAG;
				int     n_entryCntrlBypass   		= 	4;
				int		control_number_foundBypass	=	0;
				tag_t	*list_of_WSO_cntrl_tagsBypass	=	NULLTAG;

				if(QRY_find2("Control Objects...", &qryTagCntrlBypass));
				
				if(qryTagCntrlBypass!=NULLTAG)
				{
					printf("\n Control Object Query Found \n");fflush(stdout);
					qry_valuesCntrlBypass[0]="STD_VALID";
					qry_valuesCntrlBypass[1]="StdCmpltBypass";;
					qry_valuesCntrlBypass[2]=itemid;
					qry_valuesCntrlBypass[3]="0";
					
					if(QRY_execute(qryTagCntrlBypass, n_entryCntrlBypass, qry_entryCntrlBypass, qry_valuesCntrlBypass, &control_number_foundBypass, &list_of_WSO_cntrl_tagsBypass));
					printf("\n No. of control object found for bypass..: %d",control_number_foundBypass);fflush(stdout);
					
					if(control_number_foundBypass>0)
					{
						printf("\n Control object foudn .hence moving to bypass all validation and allow signoff.");fflush(stdout);
						goto BYPASSVALIDATIONS;
					}
					
				}
				
				
				//End Adding code for bypass using control object


	//**Complete BoM check*//	
	int PartCntB,icount_Clr2basedf=0;

	  tag_t*			PartTagsB		= NULLTAG;
	  char	**SetChildRelSTDBomCmErr = NULL;
	  SetChildRelSTDBomCmErr = (char**)MEM_alloc( 1 * sizeof *SetChildRelSTDBomCmErr );
	
		ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCntB,&PartTagsB));
			printf("\n\n\t\t APL DML Cre:Now PartCntB:%d",PartCntB);fflush(stdout);
			if (PartCntB>0)
			{
			
			if((tc_strcmp(Release_Type,"Veh")==0) || (tc_strcmp(Release_Type,"CP")==0) || (tc_strcmp(Release_Type,"CM")==0) )
			{
			
				CompareColorToBase(item_rev_tag,"STD",PartCntB,PartTagsB,&SetChildRelSTDBomCmErr,&icount_Clr2basedf);
									printf("\n SetChildRelSTDBomCmErr icount_Clr2basedf : %d",icount_Clr2basedf);fflush(stdout);
			
			}

		if ((tc_strcmp(Release_Type,"CP")==0) || (tc_strcmp(Release_Type,"CM")==0)|| (tc_strcmp(Release_Type,"SVR")==0))
			{
			
				CompareColorToBaseSVR(item_rev_tag,"STD",PartCntB,PartTagsB,&SetChildRelSTDBomCmErr,&icount_Clr2basedf);
									printf("\n SetChildRelSTDBomCmErr icount_Clr2basedf : %d",icount_Clr2basedf);fflush(stdout);
			
			}

							if(icount_Clr2basedf>0)
								{
									iLength	=	0;
									if (!tempErr) MEM_free(tempErr);
									i=0;
									for (i=0; i < icount_Clr2basedf; i++)
									{
										tempErr	=	SetChildRelSTDBomCmErr[i];
										iLength	=	iLength	+	tc_strlen(tempErr);
									}
									printf("Bom Comapre Check : %d",iLength);fflush(stdout);
									if (!tempErr) MEM_free(tempErr);
									tempErr	=	(char *)MEM_alloc(iLength+20);
									i=0;
									printf("\nBefore For loop Bom Comapre Check");fflush(stdout);
									for (i=0; i < icount_Clr2basedf; i++)
									{
										//printf("\n 111 SetChildErr %s",SetChildRelSTDBomCmErr[i]);fflush(stdout);
										if(i==0)
											tc_strcpy(tempErr,SetChildRelSTDBomCmErr[i]);
										else
											tc_strcat(tempErr,SetChildRelSTDBomCmErr[i]);
									}
									printf("\n Bom Comapre Check Printing Errors...!!!");fflush(stdout);
									printf("%s",tempErr);fflush(stdout);
									EMH_clear_errors();
									status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
									decision = EPM_nogo;
									return ITK_errStore;
								
								}
			
			}
				
		//**Complete BoM check*//

				//Start Deepti BOM Check for Vehicle

				int icount_ebommbom_bom=0;
				int icount_aplModCheck=0;
				char**	SetChildRelAPLModErr		= NULL;
				char**	SetChildRel_CV_Check_STDErr = NULL;


				if((tc_strcmp(Release_Type,"CP")==0) || (tc_strcmp(Release_Type,"CM")==0) ||  (tc_strcmp(Release_Type,"Veh")==0) || ((tc_strstr(itemid,"AM")!=NULL) && (tc_strcmp(dml_ecnType,"APLSTR")==0)))
				{
					printf("\n Inside Test123 \n");fflush(stdout);

					char *ecn_ReleaseType=NULL;
					if (!ecn_ReleaseType) MEM_free(ecn_ReleaseType);
					ecn_ReleaseType	=	(char *)MEM_alloc(20);

					SetChildRelAPLModErr		= (char**)MEM_alloc( 1 * sizeof *SetChildRelAPLModErr );
					SetChildRel_CV_Check_STDErr = (char**)MEM_alloc( 1 * sizeof *SetChildRel_CV_Check_STDErr );

					if((tc_strstr(itemid,"AM")!=NULL) && (tc_strcmp(dml_ecnType,"APLSTR")==0))
					{
						tc_strcpy(ecn_ReleaseType,dml_ecnType);
					}
					else
					{
						tc_strcpy(ecn_ReleaseType,Release_Type);
					}
					
					printf("\n ecn_ReleaseType => %s \n",ecn_ReleaseType);fflush(stdout);

					ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCnt,&PartTags));
					printf("\n APL DML Cre:Now PartCnt:%d \n",PartCnt);fflush(stdout);

					//ITKCALL(Check_APLModPresent(item_rev_tag,PartCnt,"STD",ecn_ReleaseType,PartTags,&SetChildRelAPLModErr,&icount_aplModCheck));
					//printf("\n Check_APLModPresent icount_aplModCheck : %d",icount_aplModCheck);fflush(stdout);
					
					// Ketan Started
					printf("\n Ketan123 Check Start : CV_Check_STD_BOM_Accuracy \n",PartCnt);fflush(stdout);

					char    *qry_entryCntrl_CV_Check[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
					char	**qry_valuesCntrl_CV_Check   = (char **) MEM_alloc(5 * sizeof(char *));

					tag_t   qryTagCntrl_CV_Check     = NULLTAG;

					int  n_entryCntrl_CV_Check			= 3;
					int  control_number_found_CV_Check	= 0;

					tag_t* list_of_WSO_cntrl_tags_CV_Check=NULLTAG;

					if(QRY_find2("Control Objects...", &qryTagCntrl_CV_Check));
					if (qryTagCntrl_CV_Check)
					{
						printf("\n Control Object Query Found \n");fflush(stdout);

						qry_valuesCntrl_CV_Check[0]="CV_Check";
						qry_valuesCntrl_CV_Check[1]="STD_BOM_Accuracy";
						qry_valuesCntrl_CV_Check[2]="0";
						
						if(QRY_execute(qryTagCntrl_CV_Check, n_entryCntrl_CV_Check, qry_entryCntrl_CV_Check, qry_valuesCntrl_CV_Check, &control_number_found_CV_Check, &list_of_WSO_cntrl_tags_CV_Check));
					}

					printf("\n CV_Check_STD_BOM_Accuracy : control_number_found_CV_Check is => %d\n",control_number_found_CV_Check);fflush(stdout);

					if(control_number_found_CV_Check>0)
					{
						printf("\n Ketan Inside Live : CV_Check_STD_BOM_Accuracy \n");fflush(stdout);

						int icount_STD_BOM_Accuracy=0;
						
						CV_Check_STD_BOM_Accuracy(item_rev_tag,PartCnt,"STD",ecn_ReleaseType,PartTags,&SetChildRel_CV_Check_STDErr,&icount_STD_BOM_Accuracy);
						printf("\n icount_STD_BOM_Accuracy => %d \n",icount_STD_BOM_Accuracy);fflush(stdout);

						if(icount_STD_BOM_Accuracy>0)
						{
							printf("\n Inside Error \n");fflush(stdout);
							iLength	=	0;
							if (!tempErr) MEM_free(tempErr);
							i=0;
							for (i=0; i < icount_STD_BOM_Accuracy; i++)
							{
								tempErr	=	SetChildRel_CV_Check_STDErr[i];
								iLength	=	iLength	+	tc_strlen(tempErr);
							}
							printf("\n CV_Check_STD_BOM_Accuracy EBOM-MBOM iLength : %d",iLength);fflush(stdout);
							if (!tempErr) MEM_free(tempErr);
							tempErr	=	(char *)MEM_alloc(iLength+20);
							i=0;
							printf("\n Before For loop");fflush(stdout);
							for (i=0; i < icount_STD_BOM_Accuracy; i++)
							{
								if(i==0)
									tc_strcpy(tempErr,SetChildRel_CV_Check_STDErr[i]);
								else
									tc_strcat(tempErr,SetChildRel_CV_Check_STDErr[i]);
							}
							printf("\n CV_Check_STD_BOM_Accuracy EBOM-MBOM Printing Errors...!!!");fflush(stdout);
							printf("%s",tempErr);fflush(stdout);
							EMH_clear_errors();
							status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
							decision = EPM_nogo;
							return ITK_errStore;
						}
					}
					else
					{
						printf("\n CV_Check_STD_BOM_Accuracy control object is not Live. \n");fflush(stdout);
					}
					// Ended

					ITKCALL(Check_STDModPresent(item_rev_tag,PartCnt,"STD",ecn_ReleaseType,PartTags,&SetChildRelAPLModErr,&icount_aplModCheck));
					printf("\n Check_STDModPresent icount_aplModCheck : %d",icount_aplModCheck);fflush(stdout);

					if(icount_aplModCheck>0)
					{
						iLength	=	0;
						if (!tempErr) MEM_free(tempErr);
						i=0;
						for (i=0; i < icount_aplModCheck; i++)
						{
							tempErr	=	SetChildRelAPLModErr[i];
							iLength	=	iLength	+	tc_strlen(tempErr);
						}
						printf("Check_APLModPresent EBOM-MBOM iLength : %d",iLength);fflush(stdout);
						if (!tempErr) MEM_free(tempErr);
						tempErr	=	(char *)MEM_alloc(iLength+20);
						i=0;
						printf("\nBefore For loop");fflush(stdout);
						for (i=0; i < icount_aplModCheck; i++)
						{
							if(i==0)
								tc_strcpy(tempErr,SetChildRelAPLModErr[i]);
							else
								tc_strcat(tempErr,SetChildRelAPLModErr[i]);
						}
						printf("\n Check_APLModPresent EBOM-MBOM Printing Errors...!!!");fflush(stdout);
						printf("%s",tempErr);fflush(stdout);
						EMH_clear_errors();
						status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
						decision = EPM_nogo;
						return ITK_errStore;
					
					}

					//vaibhav_k added check for STD 

					Check_STDModPresentSVR(item_rev_tag,"STD",&SetChildRelAPLModErr,&icount_ebommbom_bom);
					printf("\n Check_STDModPresentSVR icount_ebommbom : %d",icount_ebommbom_bom);fflush(stdout);



				if(icount_ebommbom_bom>0)
					{
						iLength	=	0;
						if (!tempErr) MEM_free(tempErr);
						i=0;
						for (i=0; i < icount_ebommbom_bom; i++)
						{
							tempErr	=	SetChildRelAPLModErr[i];
							iLength	=	iLength	+	tc_strlen(tempErr);
						}
						printf("Missing/Duplication Error : %d",iLength);fflush(stdout);
						if (!tempErr) MEM_free(tempErr);
						tempErr	=	(char *)MEM_alloc(iLength+20);
						i=0;
						printf("\nBefore For loop");fflush(stdout);
						for (i=0; i < icount_ebommbom_bom; i++)
						{
							//printf("\n 111 SetChildErr %s",SetChildRelAPLModErr[i]);fflush(stdout);
							if(i==0)
								tc_strcpy(tempErr,SetChildRelAPLModErr[i]);
							else
								tc_strcat(tempErr,SetChildRelAPLModErr[i]);
						}
						printf("\n Missing/Duplication Error :..!!!");fflush(stdout);
						printf("%s",tempErr);fflush(stdout);
						EMH_clear_errors();
						status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
						decision = EPM_nogo;
						return ITK_errStore;
					
					}

					Check_APLModuleDuplicate(item_rev_tag,PartCnt,PartTags,&SetChildRelAPLModErr,&icount_ebommbom_bom);
					printf("\n Check_APLModuleDuplicate icount_ebommbom : %d",icount_ebommbom_bom);fflush(stdout);
					
					Check_APLModuleQTY(item_rev_tag,PartCnt,PartTags,&SetChildRelAPLModErr,&icount_ebommbom_bom);
					printf("\n Check_APLModuleQTY icount_ebommbom : %d",icount_ebommbom_bom);fflush(stdout);

					if((tc_strcmp(Release_Type,"CP")==0) || (tc_strcmp(Release_Type,"CM")==0))
					{
						Check_APLModuleColourSuffix(item_rev_tag,"STD",PartCnt,PartTags,&SetChildRelAPLModErr,&icount_ebommbom_bom);
						printf("\n Check_APLModuleColourSuffix icount_ebommbom : %d",icount_ebommbom_bom);fflush(stdout);
					}

					if(icount_ebommbom_bom>0)
					{
						iLength	=	0;
						if (!tempErr) MEM_free(tempErr);
						i=0;
						for (i=0; i < icount_ebommbom_bom; i++)
						{
							tempErr	=	SetChildRelAPLModErr[i];
							iLength	=	iLength	+	tc_strlen(tempErr);
						}
						printf("EBOM-MBOM iLength : %d",iLength);fflush(stdout);
						if (!tempErr) MEM_free(tempErr);
						tempErr	=	(char *)MEM_alloc(iLength+20);
						i=0;
						printf("\nBefore For loop");fflush(stdout);
						for (i=0; i < icount_ebommbom_bom; i++)
						{
							//printf("\n 111 SetChildErr %s",SetChildRelAPLModErr[i]);fflush(stdout);
							if(i==0)
								tc_strcpy(tempErr,SetChildRelAPLModErr[i]);
							else
								tc_strcat(tempErr,SetChildRelAPLModErr[i]);
						}
						printf("\n EBOM-MBOM Printing Errors...!!!");fflush(stdout);
						printf("%s",tempErr);fflush(stdout);
						EMH_clear_errors();
						status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
						decision = EPM_nogo;
						return ITK_errStore;
					
					}

					int icount_ebommSupp=0;
					Check_ERCModSuppress(item_rev_tag,PartCnt,"STD",ecn_ReleaseType,PartTags,&SetChildRelAPLModErr,&icount_ebommSupp);
					printf("\n Check_ERCModSuppress icount_ebommSupp : %d",icount_ebommSupp);fflush(stdout);
					
					if(icount_ebommSupp>0)
					{
						iLength	=	0;
						if (!tempErr) MEM_free(tempErr);
						i=0;
						for (i=0; i < icount_ebommSupp; i++)
						{
							tempErr	=	SetChildRelAPLModErr[i];
							iLength	=	iLength	+	tc_strlen(tempErr);
						}
						printf("EBOM-MBOM iLength : %d",iLength);fflush(stdout);
						if (!tempErr) MEM_free(tempErr);
						tempErr	=	(char *)MEM_alloc(iLength+20);
						i=0;
						printf("\nBefore For loop");fflush(stdout);
						for (i=0; i < icount_ebommSupp; i++)
						{
							//printf("\n 111 SetChildErr %s",SetChildRelAPLModErr[i]);fflush(stdout);
							if(i==0)
								tc_strcpy(tempErr,SetChildRelAPLModErr[i]);
							else
								tc_strcat(tempErr,SetChildRelAPLModErr[i]);
						}
						printf("\n EBOM-MBOM Printing Errors...!!!");fflush(stdout);
						printf("%s",tempErr);fflush(stdout);
						EMH_clear_errors();
						status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
						decision = EPM_nogo;
						return ITK_errStore;
					
					}
				
				
				}
				//End Deepti BOM Check for Vehicle




	   if(tc_strcmp(Release_Type,"TODR")==0)
	  // if(tc_strcmp(Release_Type,"DL")==0)
	     {
			RefPartCnt=0;
			RefPartTags=NULLTAG;
		    ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMReferences",&RefPartCnt,&RefPartTags));
			printf("\n\n\t\t Number of parts in GM DML Task = %d",RefPartCnt);fflush(stdout);
			
			// Sagar Start TZ 1.52
			tag_t PartTag = NULLTAG;
			tag_t *PartRev_list = NULL;
			tag_t PartRevTag = NULLTAG;
			int j =0;
			int k =0;
			int Rev_count =0;
			int Err_Flg = 0;
			char *TaskID = NULL;
			char *TaskID2 = NULL;
			char *tmp_TaskID2 = NULL;
			  char*			Part_Type2				= NULL;
			char *InPlant = NULL;
			char LcsStdWrkg[40];
			char LcsStdRlzd[40];

			ITKCALL(AOM_ask_value_string(item_rev_tag,"item_id",&TaskID));
			printf("\n TaskID = %s\n",TaskID);fflush(stdout);
			
			TaskID2 = (char *)MEM_alloc(100);
			tc_strcpy(TaskID2,TaskID);
			printf("\n TaskID2 = %s\n",TaskID2);fflush(stdout);

			tmp_TaskID2 = strtok(TaskID2,"_");
			tmp_TaskID2 = strtok(NULL,"_");
			InPlant = strtok(NULL,"_");
			printf("\n InPlant = %s  \n",InPlant);fflush(stdout);

			GetPlantWiseRelStat(TaskID,LcsStdWrkg,LcsStdRlzd);	// TZ 1.53
			printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);fflush(stdout);	// TZ 1.53
			printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);fflush(stdout);	// TZ 1.53

			if (RefPartCnt>0)
			{
				printf("\n Number of Parts in GM DML Task = %d",RefPartCnt);fflush(stdout);
				for(j=0;j<RefPartCnt;j++)
				{
					PartTag = NULLTAG;
					//PartTag = RefPartTags[j];
					//Check object type, if it is folder type then bypass the Folder type in code Hemal
					char	*type_name		=	NULL;
					tag_t	objTypeTag		=	NULLTAG;

					if(TCTYPE_ask_object_type(RefPartTags[j],&objTypeTag));
					if(TCTYPE_ask_name2(objTypeTag,&type_name));
					printf("\n type_name : %s",type_name);fflush(stdout);

					if (tc_strcmp(type_name,"Folder")==0)
					{
						printf("\nGM DML Part type is folder, so bypass...");fflush(stdout);
						continue;
					}
					//Folder bypass ends Hemal
					ITKCALL(ITEM_ask_item_of_rev(RefPartTags[j], &PartTag));					
					//ITKCALL(AOM_ask_value_string(PartTag,"t5_PartType",&Part_Type2));//Commented by Hemal, as Parttag is Design not Design revision
					Part_Type2	=	NULL;
					ITKCALL(AOM_ask_value_string(RefPartTags[j],"t5_PartType",&Part_Type2));
					printf("\n\n\t EPA Child Part String is Part_Type-->%s",Part_Type2);	fflush(stdout);
					if((strcmp(Part_Type2,"D")==0)|| (strcmp(Part_Type2,"DC")==0)|| (strcmp(Part_Type2,"DA")==0))
					{
						continue;
					}
					ITKCALL(ITEM_ask_item_of_rev(RefPartTags[j], &PartTag));
					ITKCALL(ITEM_list_all_revs(PartTag, &Rev_count,&PartRev_list));
					printf("\n\t Rev_count is = %d",Rev_count);fflush(stdout);

					GMDML_Prt_DR4_DR5_Check(RefPartTags[j],InPlant,LcsStdRlzd,&SetGMErr,&icount1,&Err_Flg);
					
					//check for only the current parts attached with DML, no need to check all revision as confirm by Nana Sir.
					//If Part is in EPA, then allow release the GMDML.
					//If Not in EPA then DML must be release
//					if (Rev_count>0)
//					{
//						printf("\n Revision found... \n");fflush(stdout);
//						
//						for(k=0;k<Rev_count;k++)
//						{
//							PartRevTag = NULLTAG;
//							PartRevTag = PartRev_list[k];
//							Err_Flg = 0;
//
//							printf("\n Calling GMDML_Prt_DR4_DR5_Check function \n");fflush(stdout);
//							//GMDML_Prt_DR4_DR5_Check(PartRevTag,InPlant,SetStdRelErr);
//							GMDML_Prt_DR4_DR5_Check(PartRevTag,InPlant,LcsStdRlzd,&SetGMErr,&icount1,&Err_Flg); // TZ 1.53
//							
//							printf("\n Err_Flg = %d \n",Err_Flg);fflush(stdout);
//							if(Err_Flg==1)
//							{
//								printf("\n Err_Flg = %d \n",Err_Flg);fflush(stdout);
//								break;
//							}
//						}						
//					}					
				}				
			}			 
			// Sagar End TZ 1.52
			//Below Function has been commneted as per Nana Sir Suggestion(Hemal)
			//GMDML_Part_Release_Check_STD(RefPartCnt,RefPartTags,&SetGMErr,&icount1,itemid);

			if(cntFlag==1)
			 {
							iLength	=	0;
							if (!tempErr) MEM_free(tempErr);
							i=0;
							for (i=0; i < icount1; i++)
							{
								//printf("%s",SetChildRelErr[i]);fflush(stdout);
								tempErr	=	SetGMErr[i];
								iLength	=	iLength	+	tc_strlen(tempErr);
							}
							printf("iLength : %d",iLength);fflush(stdout);
							if (!tempErr) MEM_free(tempErr);
							tempErr	=	(char *)MEM_alloc(iLength+20);
							i=0;
							for (i=0; i < icount1; i++)
							{
								//printf("%s",SetChildRelErr[i]);fflush(stdout);
								if(i==0)
									tc_strcpy(tempErr,SetGMErr[i]);
								else
									tc_strcat(tempErr,SetGMErr[i]);
							}
							printf("\nPrinting Errors...!!!");fflush(stdout);
							printf("%s",tempErr);fflush(stdout);
							EMH_clear_errors();
							status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
							decision = EPM_nogo;
							return ITK_errStore;
			 }
			//CCV Gate Maturation Check Start
			//Code commented due to error in workflow
			tm_CCV_GMDML_DR_Check_STD(item_rev_tag,&SetGMErr,&icount1);
			printf("\nAfter Function call of CCV GM icount : %d",icount1);fflush(stdout);
			if (icount1>0)
			{
				iLength	=	0;
				if (!tempErr) MEM_free(tempErr);
				i=0;
				for (i=0; i < icount1; i++)
				{
					//printf("%s",SetChildRelErr[i]);fflush(stdout);
					tempErr	=	SetGMErr[i];
					iLength	=	iLength	+	tc_strlen(tempErr);
				}
				printf("iLength : %d",iLength);fflush(stdout);
				if (!tempErr) MEM_free(tempErr);
				tempErr	=	(char *)MEM_alloc(iLength+20);
				i=0;
				for (i=0; i < icount1; i++)
				{
					//printf("%s",SetChildRelErr[i]);fflush(stdout);
					if(i==0)
						tc_strcpy(tempErr,SetGMErr[i]);
					else
						tc_strcat(tempErr,SetGMErr[i]);
				}
				printf("\nPrinting Errors...!!!");fflush(stdout);
				printf("%s",tempErr);fflush(stdout);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
				decision = EPM_nogo;
				return ITK_errStore;
			}
			if (icount1==0)
			{
				//Create Snapshot
				createSnapshotGMSTD(item_rev_tag);
			}

		 }
    //End Of Code Added By Dhanashri For Gate Maturation DML Validation at STDSI UATZ 1.45//


		if((tc_strcmp(Release_Type,"CP")==0) || (tc_strcmp(Release_Type,"CM")==0) ) //ADDED by DEEPTI TZ1.55 BackendTZ
		{
		
			tm_amsm_colour_nonColour_part_sm_restructuring(item_rev_tag); 
		
		}
		//FIRST LEVEL CCVC CHILD PART (MODULE) RELEASE CHECK //1.57
		
		if(tc_strcmp(Release_Type,"CP")==0)
		{
			tm_chk_CCVC_BOM_STDRLZ(item_rev_tag,&SetStdRelErr,&icount);

			printf("\nAfter Function call tm_chk_CCVC_BOM_STDRLZ icount : %d",icount);fflush(stdout);
			if (icount>0)
			{
				iLength	=	0;
				if (!tempErr) MEM_free(tempErr);
				i=0;
				for (i=0; i < icount; i++)
				{
					//printf("%s",SetChildRelErr[i]);fflush(stdout);
					tempErr	=	SetStdRelErr[i];
					iLength	=	iLength	+	tc_strlen(tempErr);
				}
				printf("iLength : %d",iLength);fflush(stdout);
				if (!tempErr) MEM_free(tempErr);
				tempErr	=	(char *)MEM_alloc(iLength+20);
				i=0;
				for (i=0; i < icount; i++)
				{
					//printf("%s",SetChildRelErr[i]);fflush(stdout);
					if(i==0)
						tc_strcpy(tempErr,SetStdRelErr[i]);
					else
						tc_strcat(tempErr,SetStdRelErr[i]);
				}
				printf("\nPrinting Errors for CLR CCV...!!!");fflush(stdout);
				printf("%s",tempErr);fflush(stdout);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
				decision = EPM_nogo;
				return ITK_errStore;
			}
		}

	// Aded by dss 1.54 
	   if(tc_strcmp(Release_Type,"SVR")==0)
		{
		   	int				Part_SCnt			= 0;
			tag_t*			Part_STags			= NULLTAG;
			tag_t			AssyTag				= NULLTAG;

			//API change
			//char  type_name1[TCTYPE_name_size_c+1];
			char *type_name1 = NULL;

			int icount2=0;
				char	**SetSVRErr = NULL;

			SetSVRErr = (char**)MEM_alloc( 1 * sizeof *SetSVRErr );

			 cntSVRFlag = 0;

					ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMReferences",&Part_SCnt,&Part_STags));
					printf("\n\n\t\t inside SVR Rlzd type :%d",Part_SCnt);fflush(stdout);

					if (Part_SCnt>0)
					{
						int gh=0;
						for (gh=0;gh<Part_SCnt ;gh++ )
						{
							printf("\n SVR: for gh =:%d",gh);fflush(stdout);
							AssyTag				= NULLTAG;
							AssyTag=Part_STags[gh];

							tag_t objTypeTag1 = NULLTAG;
							if(TCTYPE_ask_object_type(AssyTag,&objTypeTag1));
							if(TCTYPE_ask_name2(objTypeTag1,&type_name1));
							printf("\n SVR: type_name := %s", type_name1);fflush(stdout);

							if(strcmp(type_name1,"VariantRule")==0) // SVR
							{
								tm_BOMResolveForAPLModulesFunc(AssyTag,itemid,RevisionRule,ClosureRule,BVR,&SetSVRErr,&icount2);
							}
						}

						printf("\n icount2 : %d\n",icount2);fflush(stdout);
						if(cntSVRFlag==1)
						{
							iLength	=	0;
							if (!tempErr) MEM_free(tempErr);
							i=0;
							for (i=0; i < icount2; i++)
							{
								//printf("%s",SetChildRelErr[i]);fflush(stdout);
								tempErr	=	SetSVRErr[i];
								iLength	=	iLength	+	tc_strlen(tempErr);
							}
							printf("iLength : %d",iLength);fflush(stdout);
							if (!tempErr) MEM_free(tempErr);
							tempErr	=	(char *)MEM_alloc(iLength+20);
							i=0;
							for (i=0; i < icount2; i++)
							{
								//printf("%s",SetChildRelErr[i]);fflush(stdout);
								if(i==0)
									tc_strcpy(tempErr,SetSVRErr[i]);
								else
									tc_strcat(tempErr,SetSVRErr[i]);
							}
							printf("\nPrinting Errors...!!!");fflush(stdout);
							printf("%s",tempErr);fflush(stdout);
							EMH_clear_errors();
							status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
							decision = EPM_nogo;
							return ITK_errStore;
						}
						
					}
			}
	// End of code Aded by dss 1.54 
	// Added by Hemal for CCV
	//commented by Hemal, as there is issue in Workflow, so commented below code
	if(tc_strcmp(Release_Type,"Veh")==0)
	{
		tag_t	qryTagCntrlEbomMBom		=	NULLTAG;
		int     n_entryCntrlEMBOM    = 3;
		int		control_number_foundEMBOM=0;
		tag_t	*list_of_WSO_cntrl_tagsEMBOM	=	NULLTAG;
		char	*cUserInfo1				=	NULLTAG;

		char    *qry_entryCntrlEMBOM[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	//DEEPTI TZ1.52
		char	**qry_valuesCntrlEMBOM= (char **) MEM_alloc(5 * sizeof(char *));//DEEPTI TZ1.52

		printf("\n Control Object Query Found for EBOM-MBOM Check\n");fflush(stdout);
		qry_valuesCntrlEMBOM[0]="STDCCVChk";
		qry_valuesCntrlEMBOM[1]="STDCCVChk";
		qry_valuesCntrlEMBOM[2]="0";

		if(QRY_find2("Control Objects...", &qryTagCntrlEbomMBom));
		
		if(qryTagCntrlEbomMBom!=NULLTAG)
		{
			if(QRY_execute(qryTagCntrlEbomMBom, n_entryCntrlEMBOM, qry_entryCntrlEMBOM, qry_valuesCntrlEMBOM, &control_number_foundEMBOM, &list_of_WSO_cntrl_tagsEMBOM));
			printf("\n\n\t\t control_number_foundEMBOM =:%d",control_number_foundEMBOM);fflush(stdout);

			if (control_number_foundEMBOM>0)
			{
				ITKCALL(AOM_ask_value_string(list_of_WSO_cntrl_tagsEMBOM[0], "t5_Userinfo1",&cUserInfo1));
				
				printf("\nProject code :%s, User Info : %s",ProjectCode,cUserInfo1);fflush(stdout);
				if (tc_strstr(cUserInfo1,ProjectCode)!=NULL)
				{
					tm_chkSnapShotBOM_STDRLZ(item_rev_tag,&SetGMErr,&icount1);
					tm_CCV_STD_APL_Module_Chk(item_rev_tag,&SetGMErr,&icount1);

					printf("\nAfter Function call of CCV Veh dml error icount : %d",icount1);fflush(stdout);
					if (icount1>0)
					{
						iLength	=	0;
						if (!tempErr) MEM_free(tempErr);
						i=0;
						for (i=0; i < icount1; i++)
						{
							//printf("%s",SetChildRelErr[i]);fflush(stdout);
							tempErr	=	SetGMErr[i];
							iLength	=	iLength	+	tc_strlen(tempErr);
						}
						printf("iLength : %d",iLength);fflush(stdout);
						if (!tempErr) MEM_free(tempErr);
						tempErr	=	(char *)MEM_alloc(iLength+20);
						i=0;
						for (i=0; i < icount1; i++)
						{
							//printf("%s",SetChildRelErr[i]);fflush(stdout);
							if(i==0)
								tc_strcpy(tempErr,SetGMErr[i]);
							else
								tc_strcat(tempErr,SetGMErr[i]);
						}
						printf("\nPrinting Errors...!!!");fflush(stdout);
						printf("%s",tempErr);fflush(stdout);
						EMH_clear_errors();
						status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
						decision = EPM_nogo;
						return ITK_errStore;
					}
				}
			}
		}

	}
	//Ended by Hemal for CCV

		if(tc_strcmp(Release_Type,"WT")==0)
			{
				PartTags=NULLTAG;
				PartCnt=0;
				icount1=0;
				char	**SetWTErr = NULL;
				SetWTErr = (char**)MEM_alloc( 1 * sizeof *SetWTErr );
				
				ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCnt,&PartTags));
				
				printf("\n\n\t\t Number of partnumbers in WT DML Task :%d",PartCnt);fflush(stdout);
				
				printf("\n\n\t\t calling WT signoff function");fflush(stdout);
				WTDML_Part_Release_Check_STD(PartCnt,PartTags,&SetWTErr,&icount1,pTagAttch[i]);
				printf("\n\n\t\t end calling WT signoff function");fflush(stdout);
				printf("\n\n\t\t error count %d",icount1);fflush(stdout);
				if(icount1>0)
				{
					iLength	=	0;
					if (!tempErr) MEM_free(tempErr);
					i=0;
					if (!tempErr) MEM_free(tempErr);
					int i=0;
					for (i=0; i < icount1; i++)
					{
						//printf("%s",SetChildRelErr[i]);fflush(stdout);
						tempErr	=	SetWTErr[i];
						iLength	=	iLength	+	tc_strlen(tempErr);
					}
					printf("iLength : %d",iLength);fflush(stdout);
					if (!tempErr) MEM_free(tempErr);
					tempErr	=	(char *)MEM_alloc(iLength+20);
					i=0;
					for (i=0; i < icount1; i++)
					{
						//printf("%s",SetChildRelErr[i]);fflush(stdout);
						if(i==0)
							tc_strcpy(tempErr,SetWTErr[i]);
						else
							tc_strcat(tempErr,SetWTErr[i]);
					}
					printf("\nPrinting Errors...!!!");fflush(stdout);
					printf("%s",tempErr);fflush(stdout);
					EMH_clear_errors();
					status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
					decision = EPM_nogo;
					return ITK_errStore;
				}
			}
		else
		  {
    		ITKCALL(AOM_ask_value_tags(item_rev_tag,"CMHasSolutionItem",&PartCnt,&PartTags));
			printf("\n\n\t\t APL DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);

			//ADDED BY DHANASHRI TZ1.41 FOR PR TASK VALIDATION//
				char *changetype		=NULL;

				ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_b2changetype",&changetype));
				printf("\n\t hi changetype is :%s",changetype); fflush(stdout);

				//if( (tc_strstr(itemid,"_PR")!=NULL) && (tc_strcmp(changetype,"PR" )==0) && PartCnt==0 )
				if( (tc_strstr(itemid,"_PR")!=NULL) && (PartCnt==0) && (tc_strcmp(changetype,"PR" )==0) )
					{
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"PR Task Should Have Atleast One Part");
						return ITK_errStore1;
					}
			//END OF CODE ADDED BY DHANASHRI TZ1.41 FOR PR TASK VALIDATION//


			//##############Bypass All the validations if AMDML of type AM###############//
			BypassAMDMLFlag = AMDML_Bypass_Checks(item_rev_tag);
			printf("\t  BypassAMDMLFlag ...%d\n", BypassAMDMLFlag);	
		
			if(BypassAMDMLFlag==1)
			{
				printf("\n Bypass all validations as AMDML of type AM");fflush(stdout);
				goto BYPASSVALIDATIONS;
			}
			else
			{
				printf("\n Call all validations as DML is not of type AM");fflush(stdout);
			}
			//############################################################################//

			if (PartCnt>0)
			{
				
				
				
				//Added by Deepti TZ1.58

				char *carryOver_check=NULL;
				int carryOverErr=0;
				char		   *PlantName123 =NULL;
				tag_t  CurrentRoleTag = NULLTAG;
				//API change
				char   *roleName = NULL;
				
				/**Added By Manindra for Skip the STD Validation of Carry over stamping for CVBU**/
				ITKCALL(SA_ask_current_role(&CurrentRoleTag));
				ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
				printf("\n\n  roleName  is : %s\n",roleName); fflush(stdout);
				PlantName123=subString(roleName,3,4);
				printf( "PlantName123 is :%s\n", PlantName123);

				ITKCALL(AOM_ask_value_string( item_rev_tag, "t5_CarryOverCheckStatusSTD", &carryOver_check));
				printf("\n carryOver_check.. %s \n",carryOver_check);fflush(stdout);

				printf("\n deepak Before1 STDC Carryover required \n");   //Added by deepak For CAR Plant TZ1.87
                fflush(stdout);
				
				if(tc_strcmp(PlantName123,"STDC")== 0)
				{
					
					
					printf("\n deepak Before STDC Control Object Query Run for Carryover required \n");   //Added by deepak For CAR Plant TZ1.87
			    	fflush(stdout);							
				
								char    *qry_entryCntrl2d[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
								char	**qry_valuesCntrl2d= (char **) MEM_alloc(5 * sizeof(char *));
								
								tag_t   qryTagCntrl2d			= NULLTAG;
								tag_t*	list_of_WSO_cntrl_tagsd = NULLTAG;
								
								int     n_entryCntrl2d			= 3;
								int		control_number_foundd	= 0;
								
								if( QRY_find2("Control Objects...", &qryTagCntrl2d));
								if (qryTagCntrl2d)
								{
									printf("\n Before Control Object Query Found \n");fflush(stdout);
									qry_valuesCntrl2d[0]="Carryover";
									qry_valuesCntrl2d[1]="CAR";  
									qry_valuesCntrl2d[2]="0";
									
								if(QRY_execute(qryTagCntrl2d, n_entryCntrl2d, qry_entryCntrl2d, qry_valuesCntrl2d, &control_number_foundd, &list_of_WSO_cntrl_tagsd));
								
								
								if (control_number_foundd > 0)	

									
									{	
									printf("\n Carryover STDC Control Object Query Found \n");fflush(stdout);

					
					
										if(strcmp(carryOver_check,"")==0)
										{
											carryOverErr++;
											EMH_clear_errors();
											status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Please run the CarryOver Part Stamping before Signoff the Task.\n Select the Task ->Go to ->Manufacturing Menu->Implementation-->Carryover Part Stamping for STDSI");
											decision = EPM_nogo;
											return ITK_errStore;				
										}

									}

									    else
                                    {
                                        printf("\n query Carryover not found");
                                        fflush(stdout);
                                    }


							    }

	         
						

				            //End  by deepak For CAR Plant TZ1.87

						

				}
				/**Ended By Manindra for Skip the STD Validation of Carry over stamping for CVBU**/
				if(carryOverErr==0)
				{
				
				
					GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
					printf("\n\n\t\t for k =:%d",k);fflush(stdout);

					printf("\n cntFlag_1: %d",cntFlag);fflush(stdout);

					//AMDML_Std_Validation(PartCnt,item_rev_tag,PartTags,SetStdRelErr); //TZ1.42--Deepti
					AMDML_Std_Validation(PartCnt,item_rev_tag,PartTags,&SetStdRelErr,&icount); //added by dss 1.53
					
					printf("\n cntFlag_2: %d",cntFlag);fflush(stdout);

					//**********TZ3.46*********************//				
					char LcsStdWrkg[40];
					char LcsStdRlzd[40];

					GetPlantWiseRelStat(itemid,LcsStdWrkg,LcsStdRlzd);
					printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);
					printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);
					strcpy(lcsToset,LcsStdRlzd);
				//***********************************//

	//				if(tc_strcmp(roleName,"STDP")==0)
	//				{
	//					strcpy(lcsToset,"T5_LcsStdpRlzd");
	//				}
	//				else if(tc_strcmp(roleName,"STDD")==0)
	//				{
	//					strcpy(lcsToset,"T5_LcsStddRlzd");
	//				}
	//				else if(tc_strcmp(roleName,"STDC")==0)
	//				{
	//					strcpy(lcsToset,"T5_LcsStdRlzd");
	//					
	//				}
	//				else if(tc_strcmp(roleName,"STDJ")==0)
	//				{
	//					strcpy(lcsToset,"T5_LcsStdjRlzd");
	//				}
	//				else if(tc_strcmp(roleName,"STDL")==0)
	//				{
	//					strcpy(lcsToset,"T5_LcsStdlRlzd");
	//				}
	//				else if(tc_strcmp(roleName,"STDA")==0)
	//				{
	//					strcpy(lcsToset,"T5_LcsStdaRlzd");
	//				}
	//				else if((tc_strcmp(roleName,"STDU")==0))
	//				{
	//					strcpy(lcsToset,"T5_LcsStduRlzd");
	//				}
	//				else
	//				{
	//					strcpy(lcsToset,"T5_LcsStdRlzd");
	//				}
					//STDSIFindNxtRevPart(item_rev_tag,SetStdRelErr); // Sagar TZ 1.52
					STDSIFindNxtRevPart(item_rev_tag,&SetStdRelErr,&icount); //added by dss 1.53

					//CheckforColBasicDMLReleaseSTD(PartCnt,item_rev_tag, PartTags,lcsToset,SetStdRelErr); 
					CheckforColBasicDMLReleaseSTD(PartCnt,item_rev_tag, PartTags,lcsToset,&SetStdRelErr,&icount); //added by dss 1.53
					printf("\n cntFlag_6: %d",cntFlag);fflush(stdout);

					//Child_std_validation(PartCnt,item_rev_tag, PartTags,lcsToset,SetStdRelErr,RevisionRule,ClosureRule,BVR); //TZ1.42--Deepti
					Child_std_validation(PartCnt,item_rev_tag, PartTags,lcsToset,&SetStdRelErr,RevisionRule,ClosureRule,BVR,&icount); //added by dss 1.53
					printf("\n cntFlag_3: %d",cntFlag);fflush(stdout);

					//STD_Two_Rev_Same_Day_Checks_P(PartCnt,PartTags,SetStdRelErr,itemid);
					STD_Two_Rev_Same_Day_Checks_P(PartCnt,PartTags,&SetStdRelErr,itemid,&icount); //added by dss 1.53
					printf("\n cntFlag_4: %d",cntFlag);fflush(stdout);

					//Next_Rev_Gt_DR3_Exists_Check(PartCnt,PartTags,SetStdRelErr,itemid);
					Next_Rev_Gt_DR3_Exists_Check(PartCnt,PartTags,&SetStdRelErr,itemid,&icount); //added by dss 1.53
					printf("\n cntFlag_5: %d",cntFlag);fflush(stdout);

					//CheckforColBasicDMLReleaseSTD(PartCnt,item_rev_tag, PartTags,lcsToset,SetStdRelErr); 
					//printf("\n cntFlag_6: %d",cntFlag);fflush(stdout);

					//Prev_Rev_Checks_SMDML(PartCnt,PartTags,SetStdRelErr,itemid,ProjectCode,STDDmlPlnt);
					Prev_Rev_Checks_SMDML(PartCnt,PartTags,&SetStdRelErr,itemid,ProjectCode,STDDmlPlnt,&icount); //added by dss 1.53

					//Prev_Rev_Checks(PartCnt,PartTags,SetPrevRevNotification,itemid,ProjectCode);
					//printf("\n cntFlag_6: %d",cntFlag);fflush(stdout);
				}


		 } //End for Part
		 
		   printf("\n hi ..cntFlag: %d\n",cntFlag);fflush(stdout);
			//if (tc_strcmp(SetChildRelErr,"NULL")!=0)
			if(cntFlag==1)
			{
				/*printf("\n All Child Part is not Released  Error %s \n",SetStdRelErr);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,SetStdRelErr);
				//printf("\n All Child Part is not TCM Released  %s \n",SetChildRelErr);
				//status=EMH_store_error_s2(EMH_severity_error,ITK_errStore,SetChildRelErr ,"Child Part Release Error");
				decision = EPM_nogo;
				return ITK_errStore;
				*/

							iLength	=	0;
							if (!tempErr) MEM_free(tempErr);
							int ii=0;
							for (ii=0; ii < icount; ii++)
							{
								tempErr	=	SetStdRelErr[ii];
								iLength	=	iLength	+	tc_strlen(tempErr);
							}
							printf("iLength : %d",iLength);fflush(stdout);
							if (!tempErr) MEM_free(tempErr);
							tempErr	=	(char *)MEM_alloc(iLength+20);
							for (ii=0; ii < icount; ii++)
							{
								
								if(ii==0)
								tc_strcpy(tempErr,SetStdRelErr[ii]);
								else
								tc_strcat(tempErr,SetStdRelErr[ii]);
							}
							printf("\nPrinting Errors...!!!");fflush(stdout);
							printf("%s",tempErr);fflush(stdout);
							EMH_clear_errors();
							status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);						
							decision = EPM_nogo;
							return ITK_errStore;

			}
			else //TZ1.42--DEEPTI
			{
				printf("\n Inside else of no error");fflush(stdout);
				if (PartCnt>0)
				{
					task_po_check=NULL;
					ITKCALL(AOM_ask_value_string( item_rev_tag, "t5_POCheckStatus", &task_po_check));
					printf("\n task_po_check.. %s \n",task_po_check);fflush(stdout);
					if(strcmp(task_po_check,"")==0)
					{
						EMH_clear_errors();
						status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Please run the PO check before Signoff the Task.\n Select the Task ->Go to ->Manufacturing Menu->Implementaion-->PO Checks");
						decision = EPM_nogo;
						return ITK_errStore;				
					}
					else if(strcmp(task_po_check,"POCHKFAIL")==0)
					{
						EMH_clear_errors();
						status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"PO Check fails.Please check the PO Report attached with Task. ");
						decision = EPM_nogo;
						return ITK_errStore;				
					}
					else if(strcmp(task_po_check,"POCHKPASS")==0)
					{
						//decision = EPM_go;
						//return decision;			
					}
					else
					{				
						//decision = EPM_go;
						//return decision;
					}

					//if((nlsStrStr(sTaskName,"CO")==NULL) && (nlsStrCmp(tChngTypDup, "CARRYOVER") !=0))
					
					if((tc_strstr(dml_no_id,"AM")!=NULL) && (tc_strcmp(dml_ecnType,"TOODMLR")!= 0))		//Deepti TZ1.53
					{
						if((tc_strcmp(changetype,"CARRYOVER")!=0) && (tc_strstr(dml_no_id,"CO")==NULL))
						{
						
							//Prev_Rev_Checks(PartCnt,PartTags,SetPrevRevNotification,itemid,ProjectCode);
							Prev_Rev_Checks(PartCnt,PartTags,&SetPrevRevNotification,itemid,ProjectCode,&icountprev);
							printf("\n inside am SetPrevRevNotification: %s\n",SetPrevRevNotification);fflush(stdout);
							//printf("\n tc_strlen(SetPrevRevNotification): %d\n",tc_strlen(SetPrevRevNotification));fflush(stdout);
						}
					}
					else if(tc_strstr(dml_no_id,"AM")==NULL) 
					{
						if((tc_strcmp(changetype,"CARRYOVER")!=0) && (tc_strstr(dml_no_id,"CO")==NULL))
						{
							//Prev_Rev_Checks(PartCnt,PartTags,SetPrevRevNotification,itemid,ProjectCode);
							Prev_Rev_Checks(PartCnt,PartTags,&SetPrevRevNotification,itemid,ProjectCode,&icountprev);
							printf("\n inside non-am SetPrevRevNotification: %s\n",SetPrevRevNotification);fflush(stdout);
							//printf("\n tc_strlen(SetPrevRevNotification): %d\n",tc_strlen(SetPrevRevNotification));fflush(stdout);
						}
					}


					/* if(tc_strlen(SetPrevRevNotification)>0)
							{
								printf("\n inside %s \n",SetPrevRevNotification);fflush(stdout);
								EMH_clear_errors();
								status=EMH_store_error_s1(EMH_severity_information,ITK_Prjerr,SetPrevRevNotification);
								printf("\n Test2");fflush(stdout);
								//decision = EPM_go;
							}
					*/
					if(cntFlagprev==1 && cntFlagprevhchk == 0) //pl922201.ttl
					{	
								printf("\n I Am inside Softcheck cntFlagprev = %d  cntFlagprevhchk = %d  ",cntFlagprev,cntFlagprevhchk);fflush(stdout); //pl922201

									iLength	=	0;
									if (!tempErr) MEM_free(tempErr);
									int ij=0;
									//for (ij=0; ij < icount; ij++)
									for (ij=0; ij < icountprev; ij++)
									{
										tempErr	=	SetPrevRevNotification[ij];
										iLength	=	iLength	+	tc_strlen(tempErr);
									}
									printf("iLength : %d",iLength);fflush(stdout);
									if (!tempErr) MEM_free(tempErr);
									tempErr	=	(char *)MEM_alloc(iLength+20);
									//for (ij=0; ij < icount; ij++)
									for (ij=0; ij < icountprev; ij++)
									{
										
										if(ij==0)
										tc_strcpy(tempErr,SetPrevRevNotification[ij]);
										else
										tc_strcat(tempErr,SetPrevRevNotification[ij]);
									}
									printf("\nPrinting Errors prev rev...!!!");fflush(stdout);
									printf("%s",tempErr);fflush(stdout);
									EMH_clear_errors();
									status=EMH_store_error_s1(EMH_severity_information,ITK_Prjerr,tempErr);	
									printf("\n Test2");fflush(stdout);
									//decision = EPM_go;
									//return EMH_severity_information;



						}
						else if(cntFlagprev==1 && cntFlagprevhchk == 1) //pl922201.ttl
						{
							

							printf("\n I Am inside Hardcheck cntFlagprev = %d  cntFlagprevhchk = %d  ",cntFlagprev,cntFlagprevhchk);fflush(stdout); //pl922201

						
									iLength	=	0;
									if (!tempErr) MEM_free(tempErr);
									int ij=0;
									//for (ij=0; ij < icount; ij++)
									for (ij=0; ij < icountprev; ij++)
									{
										tempErr	=	SetPrevRevNotification[ij];
										iLength	=	iLength	+	tc_strlen(tempErr);
									}
									printf("iLength : %d",iLength);fflush(stdout);
									if (!tempErr) MEM_free(tempErr);
									tempErr	=	(char *)MEM_alloc(iLength+20);
									//for (ij=0; ij < icount; ij++)
									for (ij=0; ij < icountprev; ij++)
									{
										
										if(ij==0)
										tc_strcpy(tempErr,SetPrevRevNotification[ij]);
										else
										tc_strcat(tempErr,SetPrevRevNotification[ij]);
									}
									printf("\nPrinting Errors prev rev...!!!");fflush(stdout);
									printf("%s",tempErr);fflush(stdout);
									EMH_clear_errors();

									printf("\nAdded Hardcheck");fflush(stdout);

									status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr); //pl922201
									decision = EPM_nogo;
									return ITK_errStore;


						}
				}
				
			}
		}//else of if(tc_strcmp(Release_Type,"TODR")==0)
	  }
    }

  }
 }
 BYPASSVALIDATIONS:
	decision = EPM_go;
	return decision;
}

extern EPM_decision_t DLLAPI DRStatusCondition(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int status;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int count_child = 0;
	int   attribute_act_tak;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char *Item_id = NULL;
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	int i = 0;
	int j = 0;
	int n = 0;
	int stampingdone=0;
	int iGChld = 0;
	char*	itemid;
	char *  ChildRelErr = NULL;
	char *  SetStdRelErr = NULL;
	char*	childPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	char  type_name[TCTYPE_name_size_c+1];

	char  type_itemRev[TCTYPE_name_size_c+1];
	char  ChildRevtype_name[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Childtop_line							= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag							= NULLTAG;
	tag_t	itemTypeTag_cdss							= NULLTAG;
	tag_t	*itemclassp	= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t	value_child_details							= NULLTAG;
	char  req_id[ITEM_id_size_c+1];
	tag_t  *children;
	tag_t  *totalchildren;
	tag_t  	value_act_Tak;
	tag_t  	item_rev_cld_tag;
	tag_t*			PartTags			= NULLTAG;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				ii				= 0;
	char*			value					=NULL;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	char*			Part_no				= NULL;
	int       st_count=0;
	int       iLCS=0;
	int       cntLcs=0;
	int				BypassNACSFlag=0;
	int				BypassAMDMLFlag=0;
	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	tag_t  CurrentRoleTag = NULLTAG;
	//API change
	char *roleName = NULL;
   cnt = 0;
  cntFlag = 0;

char *DML_DRStatus		=NULL;
char *Proj_Code		=NULL;
char *EcnType		=NULL;
char *Rlztype		=NULL;
char *PlntPlnt		=NULL;
char   *frmplnt=NULL;
tag_t			DMLRevTag			= NULLTAG;
tag_t			tsk_dml_rel_type	= NULLTAG;

	printf("\n Calling DRStatusCondition %d.....\n",iNumAttch);fflush(stdout);


	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n DRStatusCondition \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
   printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);


	//getPlantDetailsAttr_Std(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency);
	//printf("\n PlantCS %s \n",PlantCS);fflush(stdout);
	//printf("\n PlantOptCS %s \n",PlantOptCS);fflush(stdout);
	//printf("\n PlantAgency %s \n",PlantIA);fflush(stdout);
	//printf("\n PlantStore %s \n",PlantStore);fflush(stdout);
	//printf("\n UserAgency %s \n",UserAgency);fflush(stdout);


	printf("\n iNumAttch %d.....\n",iNumAttch);fflush(stdout);
	for (i=0; i < iNumAttch; i++)
	{
		tag_t objTypeTag = NULLTAG;
		tag_t objChildRevTag = NULLTAG;

		const char *qry_entries[1];
		const char *qry_values[1];

//		char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
//		char **values = (char **) MEM_alloc(1 * sizeof(char *));

		int n_tags_found=0;

		 tag_t	*itemclass							= NULLTAG;

		  tag_t item = NULLTAG;
	tag_t*			ERCDMLRevision			= NULLTAG;
	int count1=0;
logical			is_latest; 



		ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
		printf("\n itemid %s.....\n",itemid);fflush(stdout);
		qry_entries[0] ="item_id";
		qry_values[0] = itemid;

		ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
		 item = itemclass[0];
		if(item != NULLTAG )
		ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

		ITKCALL( AOM_ask_value_string(item_rev_tag,"t5_cDRstatus",&DML_DRStatus))
		printf("\n DML_DRStatus Value :--------------------   %s\n",DML_DRStatus); fflush(stdout);

		ITKCALL( AOM_ask_value_string(item_rev_tag,"t5_cprojectcode",&Proj_Code))
		printf("\n Proj_Code Value :--------------------   %s\n",Proj_Code); fflush(stdout);

		ITKCALL(AOM_ask_value_string(item_rev_tag, "t5_EcnType",&EcnType));
		printf("\n EcnType %s.....\n",EcnType);fflush(stdout);


					// CODE ADDED BY DHANASHRI //
					int cntt=0;
					int FlagGotProj=0;

					tag_t			CntrlTag		= NULLTAG;

					tag_t query1 = NULLTAG;
					int n_entries1=2;
					int n_found1=0;
  				    tag_t	*CntrlObjs	= NULLTAG;

					char *Info1 	   = NULL;

					char
					 *qry_entry[2] = {"SUBSYSCD", "SYSCD"},
					 *qry_vall[2] =  {"PROJ", "PREVREV"};

					ITKCALL(QRY_find2("ControlObjQry", &query1));
					printf("\n After fins qryyy-- ");fflush(stdout);
					ITKCALL(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
					printf("\n n_found1: %d", n_found1);fflush(stdout);

					if(n_found1>0)
					{
						for (cntt = 0; cntt < n_found1; cntt++)
						{
							CntrlTag=NULLTAG;
							CntrlTag=CntrlObjs[cntt];

							AOM_ask_value_string( CntrlTag, "t5_Userinfo1", &Info1);
							printf("\n Info1: %s\n",Info1);fflush(stdout);

							if(tc_strcmp(Info1,Proj_Code)==0)
							{
								FlagGotProj=1;
								break;
							}
				
						}

					}

					printf("\n FlagGotProj: %d", FlagGotProj);fflush(stdout);

					// END OF CODE ADDED BY DHANASHRI //



if(tc_strcmp(EcnType,"XO")==0)
		{
		ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
		if (tsk_dml_rel_type!=NULLTAG)
		 {

			ITKCALL(GRM_list_primary_objects_only(item_rev_tag,tsk_dml_rel_type,&count1,&ERCDMLRevision));
			printf("\n\n\t\t DML Revision from Task : %d",count1);fflush(stdout);		//task to dml

			for (j=0;j<count1 ;j++ )
			{
				ITKCALL(ITEM_rev_sequence_is_latest(ERCDMLRevision[j],&is_latest));
				printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);

				if(is_latest != true)
				{
					printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
				}else
				{
					DMLRevTag = ERCDMLRevision[j];//DML

					ITKCALL(AOM_ask_value_string(DMLRevTag, "t5_rlstype",&Rlztype));
					printf("\n Rlztype %s.....\n",Rlztype);fflush(stdout);

					if(tc_strcmp(Rlztype,"XO")==0)
					{
						ITKCALL(AOM_ask_value_string(DMLRevTag, "t5_PlntToPlnt",&PlntPlnt));
						printf("\n PlntPlnt %s.....\n",PlntPlnt);fflush(stdout);

						if( (tc_strstr(PlntPlnt,"DR")!=NULL) || (tc_strstr(PlntPlnt,"DR")!=NULL) )
						{
						  printf("\n Inside DR AR ...");fflush(stdout);
						  //PlantName=subString(RoleName,5,3);
						  frmplnt=subString(PlntPlnt,7,3);
						   printf("\n frmplnt %s.....\n",frmplnt);fflush(stdout);

							if( (tc_strcmp(frmplnt,"DR4")==0)|| (tc_strcmp(frmplnt,"DR5")==0) || (tc_strcmp(frmplnt,"AR4")==0) || (tc_strcmp(frmplnt,"AR5")==0) || (tc_strcmp(frmplnt,"DR3P")==0) || (tc_strcmp(frmplnt,"AR3P")==0))
							{
									decision = EPM_go;
							}
							else if(FlagGotProj==1)
							{
								if( (tc_strcmp(frmplnt,"DR3")==0)|| (tc_strcmp(frmplnt,"AR3")==0) || (tc_strcmp(frmplnt,"DR4")==0)|| (tc_strcmp(frmplnt,"DR5")==0) || (tc_strcmp(frmplnt,"AR4")==0) || (tc_strcmp(frmplnt,"AR5")==0) || (tc_strcmp(frmplnt,"DR3P")==0) || (tc_strcmp(frmplnt,"AR3P")==0))
								{
										decision = EPM_go;
								}
							}
							else
							{
								decision = EPM_nogo;
							}

						}

					}
		
				}
			}
		 }
	}

    int SynchFlag=0;
    int n_ent =	5;
    char *SYNCqry_entry[5] = {"SYSCD","SUBSYSCD","Information-1","Information-4","Delete Indicator"};
    char **SYNCqry_values = (char **) MEM_alloc(50 * sizeof(char *));
    int SyncDmlCount=0;
    int lengDml =0;
	int isValid = 0;
    tag_t  SYNCCntrl_obj_Qtag	=	NULLTAG;
    tag_t  *QRY_SYNCcntrlobj = NULLTAG;
    char *SYNCinf1 	   = NULL;
    char *SYNCinf2 	   = NULL;
    char *SYNCinf3 	   = NULL;
    char *SYNCinf4 	   = NULL;
    char *Plant =NULL;
    char *DmlobjTyp= NULL;
	char *DmlobjID= NULL;
	char* SynchDML	=	NULL;

	  ITKCALL(WSOM_ask_object_type2(item_rev_tag,&DmlobjTyp));
	  printf("\n DmlobjTyp %s: ",DmlobjTyp);fflush(stdout);
	  ITKCALL(AOM_ask_value_string(item_rev_tag, "item_id",&DmlobjID));
	  printf("\n DmlobjID %s.....\n",DmlobjID);fflush(stdout);

        if(QRY_find2("Control Objects...", &SYNCCntrl_obj_Qtag));
        if((SYNCCntrl_obj_Qtag!=NULLTAG) && (tc_strcmp(DmlobjTyp,"T5_APLDMLRevision")==0))
        {
			lengDml =tc_strlen(DmlobjID);
			printf("\nNo. of lengDml found : %d",lengDml);fflush(stdout);
			if(lengDml>=15)
			{
				Plant=subString(DmlobjID,11,4);
				printf("\n Plant : %s",Plant);fflush(stdout);
			}
        	printf("\n Control Object Query Found \n");fflush(stdout);
        	SYNCqry_values[0] = "SynchDML";
        	SYNCqry_values[1] = "RelProc";
        	SYNCqry_values[2] = "Live";
        	SYNCqry_values[3] = Plant;
        	SYNCqry_values[4] = "0";
          
        	ITKCALL(QRY_execute(SYNCCntrl_obj_Qtag, n_ent, SYNCqry_entry, SYNCqry_values, &SyncDmlCount, &QRY_SYNCcntrlobj));
          	printf("\nNo. of control object found : %d",SyncDmlCount);fflush(stdout);
          
        	if(SyncDmlCount>0)
        	{
        		printf("\nSynchDML Control object found...! lets begin ..!");fflush(stdout);
          
        		 ITKCALL(AOM_ask_value_string( QRY_SYNCcntrlobj[0], "t5_Userinfo1", &SYNCinf1));
          		 printf("\n SYNCinfo1 : %s",SYNCinf1);fflush(stdout);
        		 ITKCALL(AOM_ask_value_string( QRY_SYNCcntrlobj[0], "t5_Userinfo2", &SYNCinf2));
          		 printf("\n SYNCinfo2 : %s",SYNCinf2);fflush(stdout);
        		 ITKCALL(AOM_ask_value_string( QRY_SYNCcntrlobj[0], "t5_Userinfo3", &SYNCinf3));
          		 printf("\n SYNCinfo3 : %s",SYNCinf3);fflush(stdout);
        		 ITKCALL(AOM_ask_value_string( QRY_SYNCcntrlobj[0], "t5_Userinfo4", &SYNCinf4));
          		 printf("\n SYNCinfo4 : %s",SYNCinf4);fflush(stdout);
        	}
        	else
        	{
        		printf("\n\nSynchCtrlObj not found\n\n");fflush(stdout);
        	    SynchFlag = 1;
        	}
        }

		if( (tc_strcmp(DML_DRStatus,"DR4")==0)|| (tc_strcmp(DML_DRStatus,"DR5")==0) || (tc_strcmp(DML_DRStatus,"AR4")==0) || (tc_strcmp(DML_DRStatus,"AR5")==0) || (tc_strcmp(DML_DRStatus,"AR3P")==0)|| (tc_strcmp(DML_DRStatus,"DR3P")==0))
		{
			printf("\n test1");fflush(stdout);
			if(SyncDmlCount>0)
	        {
	        	
	        	printf("\n\nSynchronousDMLRel function starts ...\n");fflush(stdout);
	        	ITKCALL(SynchronousDMLRel(DmlobjID,SYNCinf4,&SynchFlag));
	        
	        	printf("\n\nSynchFlag = %d \n\n",SynchFlag);fflush(stdout);
	        	if(SynchFlag == 1)
	        	{
	        		isValid	=	1;
					printf("\n isValid = %d \n\n",isValid);fflush(stdout);
					decision = EPM_go;
	        	}
				else
				{
					decision = EPM_nogo;
					ITKCALL(AOM_lock(item_rev_tag));
					ITKCALL(AOM_set_value_string(item_rev_tag,"t5_SynchDML","Y"));
					ITKCALL( AOM_save_with_extensions(item_rev_tag) );
					ITKCALL( AOM_unlock(item_rev_tag) );
			      	ITKCALL(AOM_ask_value_string(item_rev_tag,"t5_SynchDML",&SynchDML));
			      	printf("SynchrnousDML of DML object is :%s\n",SynchDML);fflush(stdout);
				}
			}
			else
			{
				decision = EPM_go;
			}
		}
		else if(FlagGotProj==1)
		{
			printf("\n test2");fflush(stdout);
			if( (tc_strcmp(DML_DRStatus,"DR3")==0)|| (tc_strcmp(DML_DRStatus,"AR3")==0) || (tc_strcmp(DML_DRStatus,"DR4")==0)|| (tc_strcmp(DML_DRStatus,"DR5")==0) || (tc_strcmp(DML_DRStatus,"AR4")==0) || (tc_strcmp(DML_DRStatus,"AR5")==0) || (tc_strcmp(DML_DRStatus,"AR3P")==0)|| (tc_strcmp(DML_DRStatus,"DR3P")==0))
			{
				printf("\n test3");fflush(stdout);
				if(SyncDmlCount>0)
		    	{
		    		printf("\n\nSynchronousDMLRel function starts ...\n");fflush(stdout);
		    		ITKCALL(SynchronousDMLRel(itemid,SYNCinf4,&SynchFlag));
		    
		    		printf("\n\nSynchFlag = %d \n\n",SynchFlag);fflush(stdout);
		    		if(SynchFlag == 1)
		    		{
		    			isValid	=	1;
						printf("\n isValid = %d \n\n",isValid);fflush(stdout);
						decision = EPM_go;
		    		}
					else
					{
						decision = EPM_nogo;
						ITKCALL(AOM_lock(item_rev_tag));
					    ITKCALL(AOM_set_value_string(item_rev_tag,"t5_SynchDML","Y"));
					    ITKCALL( AOM_save_with_extensions(item_rev_tag) );
					    ITKCALL( AOM_unlock(item_rev_tag) );
			      	    ITKCALL(AOM_ask_value_string(item_rev_tag,"t5_SynchDML",&SynchDML));
			      	    printf("SynchrnousDML of DML object is :%s\n",SynchDML);fflush(stdout);
					}
				}
				else
				{
					decision = EPM_go;
				}
			}
		}
		else
		{
			decision = EPM_nogo;
		}

		printf("\n END BYEE");fflush(stdout);


	}

	return decision;
}

static int t5UpdateLifecycleStateEPA(tag_t object_tag, char* lifecycleStateName,char* lifecycleStateNameToremove)
{
	tag_t			status_rel					= NULLTAG;
	logical			retain						= 0;
	int				ifail						= 0;
	tag_t			class_id					= NULLTAG;
	char			*class_name					= NULL;
	tag_t			tReleaseStatusList_checkin	= NULLTAG;
	int             st_count1					= 0;
	tag_t*			status_list1				= NULLTAG;
	int				n_values_checkin			= 0;
	tag_t*			attr_tags_checkin			= NULLTAG;
	
	logical			*is_it_null_checkin			=   NULL;
	logical			*is_it_empty_checkin		=   NULL;
	int				cunt1						= 0;
	char			*Release_Status				= NULL;
	logical			log1;
    logical			stat  ;
	tag_t    	    propEff_tag				    =	NULLTAG;
	char*			value						=	NULL;
	char			cNextDate[20]={0};
	date_t			test_date_1;
	date_t			test_date_2;
	tag_t			eff_d						= NULLTAG;
	date_t			*start_end_date				= NULL;

	printf("\n **************t5UpdateLifecycleStateEPA*************** %s:%s\n ",lifecycleStateName,lifecycleStateNameToremove);fflush(stdout);
	if(strcmp(lifecycleStateNameToremove,"NA")==0)
	{
		printf("\n Inside NA....");fflush(stdout);
		//API change
		CALLAPI(RELSTAT_create_release_status(lifecycleStateName,&status_rel));
		CALLAPI(RELSTAT_add_release_status(status_rel,1,&object_tag,retain));
	}
	else
	{
		CALLAPI(POM_class_of_instance(object_tag,&class_id));
		CALLAPI(POM_name_of_class(class_id,&class_name));
		printf("\n class_name is :%s\n",class_name);fflush(stdout);

		CALLAPI(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
		CALLAPI(WSOM_ask_release_status_list(object_tag,&st_count1,&status_list1));
		printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);
		
		CALLAPI(POM_unload_instances (1,&object_tag));
		CALLAPI(POM_load_instances(1,&object_tag,class_id,1));
		CALLAPI(POM_is_loaded(object_tag,&log1));
		if(log1 == 1)
		{
			 printf("For EPA Rlzd Load Success\n " );fflush(stdout);
		}
		else
		printf("For EPA Rlzd  Load Failure\n"  );fflush(stdout);

		CALLAPI( POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin) );
		printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
		if(n_values_checkin>0)
		{
			CALLAPI( POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
			printf("\n For EPA Rlzd n_values11 is :%d\n",n_values_checkin);fflush(stdout);

			for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
			{
				printf("\n For EPA Rlzd Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
				
				CALLAPI(AOM_ask_name(attr_tags_checkin[cunt1], &Release_Status));
				printf("\n  For EPA Rlzd Release_Status changes done: for workspaceobject     %s\n", Release_Status);fflush(stdout);
				
				if(tc_strcmp(Release_Status,lifecycleStateNameToremove)==0 )
				{
					CALLAPI(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,cunt1,1));
					printf("\n For EPA Rlzd cunt 1 == 0 removedd is :%d\n",cunt1);fflush(stdout);

					CALLAPI(POM_save_instances(1,&object_tag,1));

					CALLAPI(POM_refresh_instances(1,&object_tag,class_id,2));

					CALLAPI(AOM_lock(object_tag));

					CALLAPI(AOM_save_with_extensions(object_tag));
					CALLAPI(AOM_refresh(object_tag,1));
					CALLAPI(AOM_unlock(object_tag));
				}

			}


		}

		//API change
		if (RELSTAT_create_release_status(lifecycleStateName,&status_rel));
		if(RELSTAT_add_release_status(status_rel,1,&object_tag,retain));

		if (tc_strcmp(class_name,"Design_0_Revision_alt")==0 || tc_strcmp(class_name,"Design Revision")==0 )
		{
			CALLAPI(WSOM_ask_effectivity_mode(&stat));
			//API change
			//CALLAPI(PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag));
			//CALLAPI(PROP_ask_value_string(propEff_tag,&value));

			CALLAPI(AOM_ask_value_string(status_rel,"effectivity_text",&value));

			getNextDate(cNextDate);
			printf("\n For EPA Rlzd  cNextDate:%s",cNextDate);fflush(stdout);

			CALLAPI(ITK_string_to_date(cNextDate, &test_date_1 ));
			CALLAPI(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 )); 

			start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

			printf( "\n For EPA Rlzd  Setting release date effectivity  \n");fflush(stdout);

			start_end_date[0] = test_date_1;
			start_end_date[1] = test_date_2;

			CALLAPI(WSOM_status_clear_effectivities (status_rel));
			CALLAPI(WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
			CALLAPI(AOM_save_with_extensions(eff_d));
			CALLAPI(AOM_save_with_extensions(status_rel));
			CALLAPI(AOM_refresh(status_rel,0));
		}
	
	
	}
	
	return 0;
}

int std_epa_working( EPM_action_message_t msg )
{

	int		status;
	int 	error_code	= ITK_ok;
	tag_t		rootTask		= NULLTAG;
	char		*CurrentTask	= NULL;
	char        *parent_name	= NULL;
	int			 noAttachment 	= 0;
	tag_t		*attachments	= NULLTAG;
	tag_t		 EPATag			= NULLTAG;
	tag_t		 objTypeTag     = NULLTAG;
	//API change
	//char	type_name[TCTYPE_name_size_c+1];
	char *type_name = NULL;
	char	*item_id = NULL;
	char	*epa_no = NULL;
	char	*epa_plant = NULL;
	char	*object_type = NULL;
    char*	lcsToset=NULL;
    char*	lcsToremove=NULL;
	tag_t	relation_type= NULLTAG;
	tag_t*	EPATaskRevision		= NULLTAG;
	int TaskCnt=0;
	tag_t			EPATaskRevTag			= NULLTAG;
	int   ifail						= 0;
	int   count						= 0;
	int   PartCnt					= 0;
	int   k							= 0;
	int   st_count					= 0;
	int   epatask_st_count			= 0;
	int   iLCS						= 0;
	int   epaLCS					= 0;
	int   epataskLCS				= 0;
	int   releaseStatusFnd			= 0;
	int   epareleaseStatusFnd		= 0;
	int   epataskreleaseStatusFnd	= 0;
	int   epa_st_count				= 0;
	tag_t*			PartTags				= NULLTAG;
	tag_t			AssyTag					= NULLTAG;
	char*			Part_no					= NULL;
	char*			PartTypeStr				= NULL;
	tag_t			tsk_part_sol_rel_type	= NULLTAG;
	char*			type_name1				= NULL;
	char*			releasest_name			= NULL;
	char*			epa_releasest_name		= NULL;
	char*			epatask_releasest_name	= NULL;
	char*			EPATask_Num				= NULL;
	char*			epatask_no				= NULL;
	char*			DML_No					= NULL;
	char*			PLT_Code					= NULL;
	tag_t			EPAClosureDtAttrId=NULLTAG;
	tag_t			CurrentRoleTag=NULLTAG;
	//API change
	char *roleName = NULL;
	char			*PlantNameP				= NULL;

	tag_t*			status_list;
	tag_t*			epa_status_list;
	tag_t*			epatask_status_list;
	date_t			epa_EPA_Release_date =NULLDATE; 


	//lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
	if (tc_strcmp(lcsToset,"NULL") !=0) MEM_free(lcsToset); 
	if (tc_strcmp(lcsToremove,"NULL") !=0) MEM_free(lcsToremove);
	
	lcsToset=(char *)MEM_alloc(20);
	lcsToremove =(char *) MEM_alloc(20);

    printf("\n **************inside std_epa_working***************\n ");fflush(stdout);

	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n inside std_epa_working \n"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n EPA CurrentTask:%s\n",CurrentTask);
	CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n EPA Parent Name:%s\n",parent_name);fflush(stdout);
	CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("EPA Target Attachment:%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		EPATag = attachments[0];
		CALLAPI(TCTYPE_ask_object_type(EPATag,&objTypeTag));
    	CALLAPI(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n  EPA type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_EPARevision")==0)
	{
		printf("\n inside class T5_EPARevision......\n");fflush(stdout);
		AOM_ask_value_string( EPATag, "item_id", &item_id);
		AOM_ask_value_string( EPATag, "current_id", &epa_no);
		AOM_ask_value_string( EPATag, "t5_EpaPlantA", &epa_plant);
		
		printf("\n  EPA Details.. %s:%s:%s\n", item_id,epa_no,epa_plant);fflush(stdout);

		strcpy(lcsToremove,"NA");

			//**********TZ3.46*********************//
			ITKCALL(SA_ask_current_role(&CurrentRoleTag));
			ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
			printf("\n\n  roleName : %s\n",roleName); fflush(stdout);			
			
			char AplRvwLC[40];
			char AplWrkngLC[40];
			char AplRlzd[40];
			char Stdwrknglc[40];
			char Stdrlzdlc[40];
			char PltLcs[40];
			char StdPlant[40];
			char StdRevRule[40];
			char StdCLosRule[40];
			char StdView[40];
			PlantNameP=subString(roleName,3,4);
			printf( "PlantNameP:%s\n", PlantNameP);  
			
			//get_CtrlVal_APLStateInf(PlantNameP,"","","",Stdwrknglc,Stdrlzdlc,"","","","","");//TZ1.46//Priti
			get_CtrlVal_STDStateInf(PlantNameP,AplRvwLC,AplWrkngLC,AplRlzd,Stdwrknglc,Stdrlzdlc,PltLcs,StdPlant,StdRevRule,StdCLosRule,StdView);//TZ1.46//Priti

			strcpy(lcsToset,Stdwrknglc);
			//***********************************//		

		printf("\n\n\t\t lcsToset := %s", lcsToset);fflush(stdout);
		epareleaseStatusFnd=0;
		
		ITKCALL(WSOM_ask_release_status_list(EPATag,&epa_st_count,&epa_status_list));
		for (epaLCS=0;epaLCS<epa_st_count ;epaLCS++ )
		{
			ITKCALL(AOM_ask_value_string(epa_status_list[epaLCS],"object_name",&epa_releasest_name));
			printf("\n epa_releasest_name: %s\n",epa_releasest_name);fflush(stdout);
			if(tc_strcmp(epa_releasest_name,lcsToset)==0)
			{
				epareleaseStatusFnd++;
			}
		}

		printf("\n\n\t\t epareleaseStatusFnd := %d", epareleaseStatusFnd);fflush(stdout);
		if(epareleaseStatusFnd==0)
		{
			status = t5UpdateLifecycleStateSTD(EPATag, lcsToset,lcsToremove);
		}	
		

		if (EPATag != NULLTAG)
		{
			CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
			/// Solution Item start

			CALLAPI(GRM_list_secondary_objects_only(EPATag,relation_type,&count,&EPATaskRevision));
			printf("\n\n\t\t EPA to EPA Task : %d",count);fflush(stdout);
			for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
			{
				EPATaskRevTag = EPATaskRevision[TaskCnt];
				CALLAPI(AOM_ask_value_string(EPATaskRevTag,"object_type",&object_type));
				printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
				if(strcmp(object_type,"T5_EPATaskRevision")==0)
				{
					epataskreleaseStatusFnd=0;
					ITKCALL(WSOM_ask_release_status_list(EPATaskRevTag,&epatask_st_count,&epatask_status_list));
					
					for (epataskLCS=0;epataskLCS<epatask_st_count ;epataskLCS++ )
					{
						ITKCALL(AOM_ask_value_string(epatask_status_list[epataskLCS],"object_name",&epatask_releasest_name));
						printf("\n epatask_releasest_name: %s\n",epatask_releasest_name);fflush(stdout);
						if(tc_strcmp(epatask_releasest_name,lcsToset)==0)
						{
							epataskreleaseStatusFnd++;
						}
					}

					printf("\n\n\t\t epataskreleaseStatusFnd := %d", epataskreleaseStatusFnd);fflush(stdout);
					if(epataskreleaseStatusFnd==0)
					{
						status = t5UpdateLifecycleStateSTD(EPATaskRevTag, lcsToset,lcsToremove);
					}
					
					
					CALLAPI(AOM_ask_value_tags(EPATaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
					printf("\n\n\t\t EPA PartCnt:%d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t EPA Part Cnt:for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];

							CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
							printf("\n\n\t\t APL DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);

							if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
							if(TCTYPE_ask_name2(objTypeTag,&type_name1));
							printf("\n\n\t\t APL DML Cre:AssyTag type_name1 := %s", type_name1);fflush(stdout);

							CALLAPI(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
							printf("\n\n\t\t APL DML Cre:AssyTag PartTypeStr := %s", PartTypeStr);fflush(stdout);
							
							releaseStatusFnd=0;

							//if (tc_strcmp(type_name1,"Design Revision")==0 || tc_strcmp(type_name1,"Part Revision")==0 )	//Deepti TZ3.52
							//{
								ITKCALL(WSOM_ask_release_status_list(AssyTag,&st_count,&status_list));
								for (iLCS=0;iLCS<st_count ;iLCS++ )
								{
									ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&releasest_name));
									printf("\n releasest_name: %s\n",releasest_name);fflush(stdout);
									if(tc_strcmp(releasest_name,lcsToset)==0)
									{
										releaseStatusFnd++;
									}
								}

								printf("\n\n\t\t releaseStatusFnd := %d", releaseStatusFnd);fflush(stdout);
								if(releaseStatusFnd==0)
								{
									status = t5UpdateLifecycleStateSTD(AssyTag, lcsToset,lcsToremove);
								}
							//}
						}
					
					
					}

					CALLAPI(AOM_lock(EPATaskRevTag));
					CALLAPI(POM_attr_id_of_attr("date_released","T5_EPATaskRevision",&EPAClosureDtAttrId));
					CALLAPI(AOM_refresh(EPATaskRevTag,TRUE));
					CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
					CALLAPI(POM_set_attr_date(1,&EPATaskRevTag,EPAClosureDtAttrId,epa_EPA_Release_date));
					

					CALLAPI(AOM_save_with_extensions(EPATaskRevTag));
					CALLAPI(AOM_unlock(EPATaskRevTag)); 

				}
			}

			CALLAPI(AOM_lock(EPATag));
			CALLAPI(POM_attr_id_of_attr("date_released","T5_EPARevision",&EPAClosureDtAttrId));
			CALLAPI(AOM_refresh(EPATag,TRUE));
			CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
			CALLAPI(POM_set_attr_date(1,&EPATag,EPAClosureDtAttrId,epa_EPA_Release_date));
			

			CALLAPI(AOM_save_with_extensions(EPATag));
			CALLAPI(AOM_unlock(EPATag)); 
		}
	}
	else if(strcmp(type_name,"T5_EPATaskRevision")==0)
	{
			printf("\n inside class T5_EPATaskRevision......\n");fflush(stdout);
			AOM_ask_value_string( EPATag, "item_id", &item_id);
			AOM_ask_value_string( EPATag, "current_id", &epatask_no);
			//AOM_ask_value_string( EPATag, "t5_EpaPlantA", &epa_plant);
			
			printf("\n  EPA Details.. %s:%s\n", item_id,epa_no);fflush(stdout);

			EPATask_Num=tc_strtok(epatask_no,"_");
			DML_No = tc_strtok(NULL,"_");
			PLT_Code = tc_strtok(NULL,"_");
			printf("\n PLT_Code:[%s],[%s]\n",EPATask_Num,DML_No,PLT_Code);

			strcpy(lcsToremove,"NA");

			if(tc_strcmp(PLT_Code,"APLP")==0)
			{
				strcpy(lcsToset,"T5_LcsSTDpWrkg");
			}
			else if(tc_strcmp(PLT_Code,"APLD")==0)
			{
				strcpy(lcsToset,"T5_LcsSTDdWrkg");
			}
			else if(tc_strcmp(PLT_Code,"APLC")==0)
			{
				strcpy(lcsToset,"T5_LcsSTDWrkg");
			}
			else if(tc_strcmp(PLT_Code,"APLJ")==0)
			{
				strcpy(lcsToset,"T5_LcsSTDjWrkg");
			}
			else if(tc_strcmp(PLT_Code,"APLL")==0)
			{
				strcpy(lcsToset,"T5_LcsSTDlWrkg");
			}
			else if(tc_strcmp(PLT_Code,"APLA")==0)
			{
				strcpy(lcsToset,"T5_LcsSTDaWrkg");
			}
			else if((tc_strcmp(PLT_Code,"APLU")==0))
			{
				strcpy(lcsToset,"T5_LcsSTDuWrkg");
			}
			else if(tc_strcmp(PLT_Code,"APLS")==0) // Added By Ketan // 22012026
			{
				strcpy(lcsToset,"T5_LcsSTDsWrkg");
			}
			else
			{
				strcpy(lcsToset,"T5_LcsSTDWrkg");
			}

			epataskreleaseStatusFnd=0;
		
			ITKCALL(WSOM_ask_release_status_list(EPATag,&epatask_st_count,&epatask_status_list));
					
			for (epataskLCS=0;epataskLCS<epatask_st_count ;epataskLCS++ )
			{
				ITKCALL(AOM_ask_value_string(epatask_status_list[epataskLCS],"object_name",&epatask_releasest_name));
				printf("\n epatask_releasest_name: %s\n",epatask_releasest_name);fflush(stdout);
				if(tc_strcmp(epatask_releasest_name,lcsToset)==0)
				{
					epataskreleaseStatusFnd++;
				}
			}

			printf("\n\n\t\t epataskreleaseStatusFnd := %d", epataskreleaseStatusFnd);fflush(stdout);
			if(epataskreleaseStatusFnd==0)
			{
				status = t5UpdateLifecycleStateSTD(EPATag, lcsToset,lcsToremove);
			}
			
			CALLAPI(AOM_ask_value_tags(EPATag,"CMHasSolutionItem",&PartCnt,&PartTags));
			printf("\n\n\t\t EPA PartCnt:%d",PartCnt);fflush(stdout);
			if (PartCnt>0)
			{
				GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
				for (k=0;k<PartCnt ;k++ )
				{
					printf("\n\n\t\t EPA Part Cnt:for k =:%d",k);fflush(stdout);
					AssyTag=PartTags[k];

					CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
					printf("\n\n\t\t APL DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);

					if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
					if(TCTYPE_ask_name2(objTypeTag,&type_name1));
					printf("\n\n\t\t APL DML Cre:AssyTag type_name1 := %s", type_name1);fflush(stdout);

					CALLAPI(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
					printf("\n\n\t\t APL DML Cre:AssyTag PartTypeStr := %s", PartTypeStr);fflush(stdout);
					
					releaseStatusFnd=0;

					//if (tc_strcmp(type_name1,"Design Revision")==0 || tc_strcmp(type_name1,"Part Revision")==0 )	//Deepti TZ3.52
					//{
						ITKCALL(WSOM_ask_release_status_list(AssyTag,&st_count,&status_list));
						for (iLCS=0;iLCS<st_count ;iLCS++ )
						{
							ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&releasest_name));
							printf("\n releasest_name: %s\n",releasest_name);fflush(stdout);
							if(tc_strcmp(releasest_name,lcsToset)==0)
							{
								releaseStatusFnd++;
							}
						}

						printf("\n\n\t\t releaseStatusFnd := %d", releaseStatusFnd);fflush(stdout);
						if(releaseStatusFnd==0)
						{
							status = t5UpdateLifecycleStateSTD(AssyTag, lcsToset,lcsToremove);
						}
					//}
				}
			
			
			}

			CALLAPI(AOM_lock(EPATag));
			CALLAPI(POM_attr_id_of_attr("date_released","T5_EPATaskRevision",&EPAClosureDtAttrId));
			CALLAPI(AOM_refresh(EPATag,TRUE));
			CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
			CALLAPI(POM_set_attr_date(1,&EPATag,EPAClosureDtAttrId,epa_EPA_Release_date));
			

			CALLAPI(AOM_save_with_extensions(EPATag));
			CALLAPI(AOM_unlock(EPATag)); 
	
	
	}
	
	if (tc_strcmp(lcsToset,"NULL") !=0) MEM_free(lcsToset);
	return error_code;

}

int std_epa_rlzd( EPM_action_message_t msg )
{

	int		status;
	int 	error_code	= ITK_ok;
	tag_t		rootTask		= NULLTAG;
	char		*CurrentTask	= NULL;
	char        *parent_name	= NULL;
	int			 noAttachment 	= 0;
	tag_t		*attachments	= NULLTAG;
	tag_t		 EPATag			= NULLTAG;
	tag_t		 objTypeTag     = NULLTAG;

	//API change
	//char	type_name[TCTYPE_name_size_c+1];
	char *type_name = NULL;

	char	*item_id = NULL;
	char	*epa_no = NULL;
	char	*epa_plant = NULL;
	char	*object_type = NULL;
    char*	lcsToset=NULL;
    char*	lcsToremove=NULL;
	tag_t	relation_type= NULLTAG;
	tag_t*	EPATaskRevision		= NULLTAG;
	int TaskCnt=0;
	tag_t			EPATaskRevTag			= NULLTAG;
	int   ifail						= 0;
	int   count						= 0;
	int   PartCnt					= 0;
	int   k							= 0;
	int   st_count					= 0;
	int   epatask_st_count			= 0;
	int   iLCS						= 0;
	int   epaLCS					= 0;
	int   epataskLCS				= 0;
	int   releaseStatusFnd			= 0;
	int   epareleaseStatusFnd		= 0;
	int   epataskreleaseStatusFnd	= 0;
	int   epa_st_count				= 0;
	tag_t*			PartTags				= NULLTAG;
	tag_t			AssyTag					= NULLTAG;
	char*			Part_no					= NULL;
	char*			PartTypeStr				= NULL;
	tag_t			tsk_part_sol_rel_type	= NULLTAG;
	char*			type_name1				= NULL;
	char*			releasest_name			= NULL;
	char*			epa_releasest_name		= NULL;
	char*			epatask_releasest_name	= NULL;
	tag_t*			status_list;
	tag_t*			epa_status_list;
	tag_t*			epatask_status_list;
	date_t			EPA_Release_date;
	date_t			EPATask_Release_date;
	char cCurrentAccessDate[20]={0};
	char cCurrentAccessDate1[20]={0};
	tag_t  EPATaskClosureDtAttrId = NULLTAG;
	tag_t  EPAClosureDtAttrId = NULLTAG;
	tag_t			CurrentRoleTag=NULLTAG;
	//API change
	char *roleName = NULL;


	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
	lcsToremove =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside std_epa_rlzd***************\n ");fflush(stdout);

	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n inside std_epa_rlzd \n"); fflush(stdout);

	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n EPA CurrentTask:%s\n",CurrentTask);
	CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n EPA Parent Name:%s\n",parent_name);fflush(stdout);
	CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	printf("EPA Target Attachment:%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
		EPATag = attachments[0];
		CALLAPI(TCTYPE_ask_object_type(EPATag,&objTypeTag));
    	CALLAPI(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\n  EPA type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	}

	if(strcmp(type_name,"T5_EPARevision")==0)
	{
		printf("\n inside class T5_EPARevision......\n");fflush(stdout);
		AOM_ask_value_string( EPATag, "item_id", &item_id);
		AOM_ask_value_string( EPATag, "current_id", &epa_no);
		AOM_ask_value_string( EPATag, "t5_EpaPlantA", &epa_plant);
		
		printf("\n  EPA Details.. %s:%s:%s\n", item_id,epa_no,epa_plant);fflush(stdout);

		strcpy(lcsToremove,"NA");

//		if(tc_strcmp(epa_plant,"CVBU PUNE")==0)
//		{
//			strcpy(lcsToset,"T5_LcsStdpRlzd");
//			strcpy(lcsToremove,"T5_LcsSTDpWrkg");
//		}
////		else if(tc_strcmp(PLT_Code,"APLV")==0)
////		{
////			strcpy(lcsToset,"T5_LcsStdRlzd");
////		}
//		else if(tc_strcmp(epa_plant,"DHARWAD")==0)
//		{
//			strcpy(lcsToset,"T5_LcsStddRlzd");
//			strcpy(lcsToremove,"T5_LcsSTDdWrkg");
//		}
//		else if(tc_strcmp(epa_plant,"CAR")==0)
//		{
//			strcpy(lcsToset,"T5_LcsStdRlzd");
//			strcpy(lcsToremove,"T5_LcsSTDWrkg");
//		}
//		else if(tc_strcmp(epa_plant,"CVBU JSR")==0)
//		{
//			strcpy(lcsToset,"T5_LcsStdjRlzd");
//			strcpy(lcsToremove,"T5_LcsSTDjWrkg");
//		}
//		else if(tc_strcmp(epa_plant,"CVBU LKO")==0)
//		{
//			strcpy(lcsToset,"T5_LcsStdlRlzd");
//			strcpy(lcsToremove,"T5_LcsSTDlWrkg");
//		}
//		else if(tc_strcmp(epa_plant,"SMALLCAR AHD")==0)
//		{
//			strcpy(lcsToset,"T5_LcsStdaRlzd");
//			strcpy(lcsToremove,"T5_LcsSTDaWrkg");
//		}
//		else if((tc_strcmp(epa_plant,"CVBU PNR")==0) || (tc_strcmp(epa_plant,"SMALLCAR PNR")==0))
//		{
//			strcpy(lcsToset,"T5_LcsStduRlzd");
//			strcpy(lcsToremove,"T5_LcsSTDuWrkg");
//		}
////		else if(tc_strcmp(epa_plant,"APLS")==0)
////		{
////			strcpy(lcsToset,"T5_LcsSTDsRlzd");
////		}
//		else
//		{
//			strcpy(lcsToset,"T5_LcsStdRlzd");
//			strcpy(lcsToremove,"T5_LcsSTDWrkg");
//		}

		//**********TZ3.46*********************//
			ITKCALL(SA_ask_current_role(&CurrentRoleTag));
			ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
			printf("\n\n  roleName : %s\n",roleName); fflush(stdout);		
			
			char AplRvwLC[40];
			char AplWrkngLC[40];
			char AplRlzd[40];
			char Stdwrknglc[40];
			char Stdrlzdlc[40];
			char PltLcs[40];
			char StdPlant[40];
			char StdRevRule[40];
			char StdCLosRule[40];
			char StdView[40];
			char *PlantNameP = NULL;
			PlantNameP=subString(roleName,3,4);
			printf( "PlantNameP:%s\n", PlantNameP);  
			
			//get_CtrlVal_APLStateInf(PlantNameP,"","","",Stdwrknglc,Stdrlzdlc,"","","","","");//TZ1.46//Priti
			get_CtrlVal_STDStateInf(PlantNameP,AplRvwLC,AplWrkngLC,AplRlzd,Stdwrknglc,Stdrlzdlc,PltLcs,StdPlant,StdRevRule,StdCLosRule,StdView);//TZ1.46//Priti

			strcpy(lcsToset,Stdrlzdlc);
			strcpy(lcsToremove,Stdwrknglc);
			//***********************************//

		
		epareleaseStatusFnd=0;
		
		ITKCALL(WSOM_ask_release_status_list(EPATag,&epa_st_count,&epa_status_list));
		for (epaLCS=0;epaLCS<epa_st_count ;epaLCS++ )
		{
			ITKCALL(AOM_ask_value_string(epa_status_list[epaLCS],"object_name",&epa_releasest_name));
			printf("\n epa_releasest_name: %s\n",epa_releasest_name);fflush(stdout);
			if(tc_strcmp(epa_releasest_name,lcsToset)==0)
			{
				epareleaseStatusFnd++;
			}
		}


		if (EPATag != NULLTAG)
		{
			CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
			/// Solution Item start

			CALLAPI(GRM_list_secondary_objects_only(EPATag,relation_type,&count,&EPATaskRevision));
			printf("\n\n\t\t EPA to EPA Task : %d",count);fflush(stdout);
			for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
			{
				EPATaskRevTag = EPATaskRevision[TaskCnt];
				CALLAPI(AOM_ask_value_string(EPATaskRevTag,"object_type",&object_type));
				printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
				if(strcmp(object_type,"T5_EPATaskRevision")==0)
				{
					epataskreleaseStatusFnd=0;
					ITKCALL(WSOM_ask_release_status_list(EPATaskRevTag,&epatask_st_count,&epatask_status_list));
					
					for (epataskLCS=0;epataskLCS<epatask_st_count ;epataskLCS++ )
					{
						ITKCALL(AOM_ask_value_string(epatask_status_list[epataskLCS],"object_name",&epatask_releasest_name));
						printf("\n epatask_releasest_name: %s\n",epatask_releasest_name);fflush(stdout);
						if(tc_strcmp(epatask_releasest_name,lcsToset)==0)
						{
							epataskreleaseStatusFnd++;
						}
					}

					
					
					CALLAPI(AOM_ask_value_tags(EPATaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
					printf("\n\n\t\t EPA PartCnt:%d",PartCnt);fflush(stdout);
					if (PartCnt>0)
					{
						GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
						for (k=0;k<PartCnt ;k++ )
						{
							printf("\n\n\t\t EPA Part Cnt:for k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];

							CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
							printf("\n\n\t\t APL DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);

							if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
							if(TCTYPE_ask_name2(objTypeTag,&type_name1));
							printf("\n\n\t\t APL DML Cre:AssyTag type_name1 := %s", type_name1);fflush(stdout);

							CALLAPI(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
							printf("\n\n\t\t APL DML Cre:AssyTag PartTypeStr := %s", PartTypeStr);fflush(stdout);
							
							releaseStatusFnd=0;

							//if (tc_strcmp(type_name1,"Design Revision")==0 || tc_strcmp(type_name1,"Part Revision")==0 )	//Deepti TZ3.52
							//{
								//Added By Dhanashri for skip prev rev UATZ1.42//
								 char*			SkipPrevRevSTD				= NULL;
								 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
								 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
								 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
					   
								  //if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
								  if(tc_strlen(SkipPrevRevSTD)>0)
								  {
								 	printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
								 	continue;
								  }
								//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

								ITKCALL(WSOM_ask_release_status_list(AssyTag,&st_count,&status_list));
								for (iLCS=0;iLCS<st_count ;iLCS++ )
								{
									ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&releasest_name));
									printf("\n releasest_name: %s\n",releasest_name);fflush(stdout);
									if(tc_strcmp(releasest_name,lcsToset)==0)
									{
										releaseStatusFnd++;
									}
								}

								printf("\n\n\t\t releaseStatusFnd := %d", releaseStatusFnd);fflush(stdout);
								if(releaseStatusFnd==0)
								{
									status = t5UpdateLifecycleStateSTD(AssyTag, lcsToset,lcsToremove);
								}
							//}
						}
					
					
					}

					getCurrentDateTime(cCurrentAccessDate1);
					printf("\n For EPA cCurrentAccessDate1:%s",cCurrentAccessDate1);fflush(stdout);
					ITKCALL(ITK_string_to_date(cCurrentAccessDate1, &EPATask_Release_date ));

					CALLAPI(AOM_lock(EPATaskRevTag));
					CALLAPI(POM_attr_id_of_attr("date_released","T5_EPATaskRevision",&EPATaskClosureDtAttrId));
					CALLAPI(AOM_refresh(EPATaskRevTag,TRUE));
					CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
					CALLAPI(POM_set_attr_date(1,&EPATaskRevTag,EPATaskClosureDtAttrId,EPATask_Release_date));

					CALLAPI(AOM_save_with_extensions(EPATaskRevTag));
					CALLAPI(AOM_unlock(EPATaskRevTag));

					printf("\n\n\t\t epataskreleaseStatusFnd := %d", epataskreleaseStatusFnd);fflush(stdout);
					if(epataskreleaseStatusFnd==0)
					{
						status = t5UpdateLifecycleStateSTD(EPATaskRevTag, lcsToset,lcsToremove);
					}					

				}
			}

			getCurrentDateTime(cCurrentAccessDate);
			printf("\n For EPA cCurrentAccessDate:%s",cCurrentAccessDate);fflush(stdout);
			ITKCALL(ITK_string_to_date(cCurrentAccessDate, &EPA_Release_date ));

			CALLAPI(AOM_lock(EPATag));
			CALLAPI(POM_attr_id_of_attr("date_released","T5_EPARevision",&EPAClosureDtAttrId));
			CALLAPI(AOM_refresh(EPATag,TRUE));
			CALLAPI(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
			CALLAPI(POM_set_attr_date(1,&EPATag,EPAClosureDtAttrId,EPA_Release_date));
			CALLAPI(AOM_set_value_string(EPATag,"t5_EpaStatus","F"));


			CALLAPI(AOM_save_with_extensions(EPATag));
			CALLAPI(AOM_unlock(EPATag));

			printf("\n\n\t\t epareleaseStatusFnd := %d", epareleaseStatusFnd);fflush(stdout);
			if(epareleaseStatusFnd==0)
			{
				status = t5UpdateLifecycleStateSTD(EPATag, lcsToset,lcsToremove);
			}
		}

	}
	
	
	return error_code;

}

/*********Start  Added by Deepti for EPA Sign off*******************************************/
int EPA_Prev_Part_Rev_TwoRev_Rlzd_Checks(char* epanosignoff,int PartCnt, tag_t* PartTags,char* SetChildRelErr,char *LcstobeChecked,char *PlantName,char *APLDmlPlnt,char *epaTaskNo)
{

	int k=0;
	int g=0;
	int h=0;
	int l=0;
	int z=0;
	int x=0;

	int Item_count=0;
	int RevFlag=0;
	int PreRevFlag=0;
	int ii=0;
	int st_count=0;
	int iLCS=0;
	int cntLcs=0;
	int dmlTskcount=0;
	int epaSamePlantFnd=0;
	int dmlcount=0;
	int j=0;
	int revOnSameEpa=0;
	tag_t			AssyTag				= NULLTAG;
	char*			Part_no				= NULL;
	char*			Part_Rev			= NULL;
	char*			Part_rev_Id			= NULL;
	char*			Part_Rev_copy		= NULL;
	char*			ClosureDate			= NULL;
	char*			ClosureDateDup		= NULL;
	tag_t			All_item_tag		= NULLTAG;
	tag_t			*rev_list				= NULL;
	char*			PreRevOnly				= NULL;
	char*			RevOnly					= NULL;
	char*			class_name				= NULL;
	char*			epaTaskId				= NULL;
	char*			epaId					= NULL;
	char*			ECNType					= NULL;
	tag_t*			status_list;
	tag_t*			effectivities;
	char *			ChildRelErr = NULL;
	tag_t			relation_type= NULLTAG;
	tag_t*			PartDmlTaskTags			= NULLTAG;
	tag_t*			EPARevision				= NULLTAG;
	tag_t*			DmlRevision				= NULLTAG;
	tag_t			PartDmlTaskTag			= NULLTAG;
	tag_t			DMLRevTag				= NULLTAG;
	tag_t			EpaRevTag				= NULLTAG;
	tag_t			objTypeRefTag						= NULLTAG;
	//API change
	//char			type_name_ref[TCTYPE_name_size_c+1];
	char *type_name_ref = NULL;
	tag_t tsk_dml_rel_type;
	char cCurrentAccessDate[20]={0};
    char* pAccessDateDup 	= NULL;
	char*  IsEPARlzErr1 = NULL;
	char*  IsDMLRlzErr1 = NULL;
	char*  TaskId = NULL;
	char*  PrevRevItemID = NULL;
	char*  PrevRevItemSeq = NULL;
	char*  PreSMTaskId = NULL;
	char*  dmlId = NULL;
	int smdmlEpaErrorCnt=0;
    tag_t			AssyPreTag			= NULLTAG;
	char PreSMtask_Plant[40];
	char			*inp_PlntLstLtr		= NULL;
	char			*ReleaseStatusSMDML		= NULL;
	int smlst=0,st_dmlcount=0,smRlzFlg=0;
	tag_t *dml_status_list;
	char			*PrevRevSMDMLEPASet		= NULL;
	char  ItemIDCpy[40];
	char  LcsStdWrkg[40];
	char  LcsStdRlzd[40];

	printf("\n Calling EPA_Prev_Part_Rev_TwoRev_Rlzd_Checks *****\n");fflush(stdout);

	 
    tc_strcpy(ItemIDCpy,epaTaskNo);
	GetPlantWiseRelStat(ItemIDCpy,LcsStdWrkg,LcsStdRlzd);
	printf("\n LcsStdWrkg: %s \n",LcsStdWrkg);fflush(stdout);
	printf("\n LcsStdRlzd: %s \n",LcsStdRlzd);fflush(stdout);



	for (k=0;k<PartCnt ;k++ )
	{
		printf("\n\n\t\t Part Cn : =:%d",k);fflush(stdout);
		AssyTag=NULLTAG;
		AssyTag=PartTags[k];
		cntLcs=0;
		PreRevFlag = 0;
		AssyPreTag=NULLTAG;

		ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
		ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev));
		ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev_copy));


		ITKCALL(ITEM_find_item (Part_no, &All_item_tag));
		ITKCALL(ITEM_list_all_revs (All_item_tag, &Item_count, &rev_list));
		printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);

		//Added By Dhanashri for skip prev rev UATZ1.42//
		 char*			SkipPrevRevSTD				= NULL;
		 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
		 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
		 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
			
		//if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
		if(tc_strlen(SkipPrevRevSTD)>0)
		{
			printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
			continue;
		}

		// Check All Previous Revision 
		if(strstr(Part_Rev,"NR"))
		{
			printf("\n in EPA Previous revision function can not be called as current revision has NR revision");fflush(stdout);
		}
		else
		{
			ITKCALL(AOM_ask_value_tags(AssyTag,"revision_list",&Item_count,&rev_list));
			printf("\nTotal Revisions : %d",Item_count);fflush(stdout);

			if(Item_count > 0)
			{
				RevFlag		=	0;
				PreRevFlag	=	0;

				for(ii=Item_count-1;ii>=0;ii--)
				{
					RevOnly		=	NULL;
					PreRevOnly	=	NULL;

					ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));

					printf("\n\nCurrent Part_Rev %s and Part_rev_Id: %s\n",Part_Rev,Part_rev_Id);fflush(stdout);
					if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
					{
						RevFlag = 1;
					}
					printf("\n RevFlag : %d.", RevFlag);fflush(stdout);

					if(RevFlag == 1)
					{
						RevOnly		= strtok( Part_Rev_copy, ";" );
						PreRevOnly	= strtok( Part_rev_Id, ";" );
						printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
						printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
						if(tc_strcmp(RevOnly,PreRevOnly)!=0)
						{
							PreRevFlag = 1;
							
						}

						printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);

						if(PreRevFlag == 1)
						{
							printf("\n --------------------------------------------------------------");fflush(stdout);

							printf("\n Previous Found");fflush(stdout);
							
							printf("\n Previous_Revision : %s.", PreRevOnly);fflush(stdout);

							ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
							ITKCALL(GRM_list_primary_objects_only(rev_list[ii],relation_type,&dmlTskcount,&PartDmlTaskTags));
							if(dmlTskcount >0)
							{
								
								for (l=0;l<dmlTskcount ;l++ )
								{
									PartDmlTaskTag=PartDmlTaskTags[l];//task pointer
									printf("\n\n\t\t Inside: ");fflush(stdout);

									ITKCALL(TCTYPE_ask_object_type(PartDmlTaskTag,&objTypeRefTag));//task pointer
									ITKCALL(TCTYPE_ask_name2(objTypeRefTag,&type_name_ref));
									if (strcmp(type_name_ref,"T5_EPATaskRevision")==0)						//FOR EPA TASK REVISION
									{
										
										ITKCALL(AOM_ask_value_string(PartDmlTaskTag, "item_id",&epaTaskId));
										if(tc_strstr(epaTaskId,APLDmlPlnt)!=NULL)
										{
									
											epaSamePlantFnd++;
											ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
											if (tsk_dml_rel_type!=NULLTAG)
											{
												ITKCALL(GRM_list_primary_objects_only(PartDmlTaskTag,tsk_dml_rel_type,&dmlcount,&EPARevision));
												for (j=0;j<dmlcount ;j++ )
												{
													EpaRevTag = EPARevision[j];
													ITKCALL(AOM_ask_value_string(EpaRevTag, "item_id",&epaId));
													printf("\n Previous EPA ID %s.....\n",epaId);

													printf("\n Current EPA ID %s.....\n",epanosignoff);

													if(tc_strcmp(epaId,epanosignoff)!=0)
													{
														//ITK_CALL(POM_attr_id_of_attr("date_released","T5_APLDMLRevision",&DMLClosureDtAttrId));
														//ITK_CALL(POM_set_attr_date(1,&itemrev,DMLClosureDtAttrId,test_date_2));

														ITKCALL(AOM_UIF_ask_value(EpaRevTag,"date_released",&ClosureDate));
														printf("\n ClosureDate : %s\n",ClosureDate);fflush(stdout);//28-Oct-2017 14:12

														ClosureDateDup = subString(ClosureDate,0,11);
														printf("\n ClosureDateDup : %s\n",ClosureDateDup);fflush(stdout);
														getCurrentDateTime(cCurrentAccessDate);
														printf("\n  todays date111 is: %s\n",cCurrentAccessDate);
														pAccessDateDup = subString(cCurrentAccessDate,0,11);
														printf("\n  todays date is: %s\n",pAccessDateDup);

														//if (tc_strcmp(IsEPARlzErr1,"NULL")==0) MEM_free(IsEPARlzErr1);
														IsEPARlzErr1=NULL;
														IsEPARlzErr1=(char *)MEM_alloc(100);
														tc_strcpy(IsEPARlzErr1,"");
														if(tc_strcmp(ClosureDateDup,pAccessDateDup)==0)
														{

															if(epacnt==0)
															{
																epacnt = 1;

																tc_strcat(IsEPARlzErr1,"\n Two revision of part ");
																tc_strcat(IsEPARlzErr1,Part_no);
																tc_strcat(IsEPARlzErr1," cannot be released on same day.\n");
																printf("\n IsEPARlzErr1: %s\n",IsEPARlzErr1);fflush(stdout);

															}
															else
															{
																tc_strcat(IsEPARlzErr1,"\n Two revision of part ");
																tc_strcat(IsEPARlzErr1,Part_no);
																tc_strcat(IsEPARlzErr1," cannot be released on same day..\n");
																epacnt=epacnt+1;
																printf("\n IsEPARlzErr1: %s\n",IsEPARlzErr1);fflush(stdout);
															}
															printf("\n epacnt: %d\n",epacnt);fflush(stdout);

															if(epacnt==1)
															{
																tc_strcat(SetChildRelErr,IsEPARlzErr1);
																cntEPAFlag = 1;
															}
															else
															{
																tc_strcat(SetChildRelErr,IsEPARlzErr1);
																cntEPAFlag = 1;
															}
														}
													}

													
												}
											
											}
										}
									}
									/*else if(strcmp(type_name_ref,"T5_SMDMLTaskRevision")==0)
									{
										ITKCALL(AOM_ask_value_string(PartDmlTaskTag, "item_id",&PreSMTaskId));
										printf("\n PreSMTaskId %s.....\n",PreSMTaskId);	fflush(stdout);

										GetPlantForDMLORTask(PreSMTaskId,PreSMtask_Plant);	
										printf("\t  PreSMtask_Plant after  ...%s\n %s", PreSMtask_Plant,PlantName);
										
										dmlId=subString(PreSMTaskId,2,2);
										printf("\n dmlId:%s",dmlId);fflush(stdout);

										if(tc_strcmp(dmlId,"SM")==0 && (tc_strcmp(PlantName,PreSMtask_Plant)==0))
										{

											smlst = 0;
											ITKCALL(WSOM_ask_release_status_list(PartDmlTaskTag,&st_dmlcount,&dml_status_list));
											for (smlst = 0; smlst < st_dmlcount; smlst++)
											{
												AOM_ask_name(dml_status_list[smlst], &ReleaseStatusSMDML);
												printf("\n ReleaseStatusepa %s :::LcsStdRlzd %s\n",  ReleaseStatusSMDML,LcsStdRlzd);fflush(stdout);
												if(tc_strcmp(ReleaseStatusSMDML,LcsStdRlzd)!=0 )
												{
													//smRlzFlg=1;
													///break;
													
													printf("\n Previous revision of part is contanied in SMDML which is not stdsi released, carry forward previous revision changes into current revision");fflush(stdout);
													//#############Logic to carry forward previous revision changes#############//



													//##########################################################################//
												}
												else
												{
													smRlzFlg++;
												
												}
											}
										}	
									
									
									}*/
								
								}

								/*if(smRlzFlg==0)
								{
									
									if(smdmlEpaErrorCnt==0)
									{
										tc_strcat(PrevRevSMDMLEPASet,"\n Below Previous Revision of Part is attached to SM-DML which is not STDSI released.Please release the SM-DML.");
										tc_strcat(PrevRevSMDMLEPASet,"\n");
										tc_strcat(PrevRevSMDMLEPASet,PrevRevItemID);
										tc_strcat(PrevRevSMDMLEPASet,":");
										tc_strcat(PrevRevSMDMLEPASet,PrevRevItemSeq);
										tc_strcat(PrevRevSMDMLEPASet,";SM-DML Task :");
										tc_strcat(PrevRevSMDMLEPASet,PreSMTaskId);	
										smdmlEpaErrorCnt++;
									}
									else
									{
										tc_strcat(PrevRevSMDMLEPASet,"\n");
										tc_strcat(PrevRevSMDMLEPASet,PrevRevItemID);
										tc_strcat(PrevRevSMDMLEPASet,":");
										tc_strcat(PrevRevSMDMLEPASet,PrevRevItemSeq);
										tc_strcat(PrevRevSMDMLEPASet,";SM-DML Task :");
										tc_strcat(PrevRevSMDMLEPASet,PreSMTaskId);	
										smdmlEpaErrorCnt++;
									}
								}*/

								if(epaSamePlantFnd==0)
								{

									for (z=0;z<dmlTskcount ;z++ )
									{
										PartDmlTaskTag=PartDmlTaskTags[z];//task pointer
										printf("\n\n\t\t INSIDE: ");fflush(stdout);

										ITKCALL(TCTYPE_ask_object_type(PartDmlTaskTag,&objTypeRefTag));//task pointer
										ITKCALL(TCTYPE_ask_name2(objTypeRefTag,&type_name_ref));
										
										if (strcmp(type_name_ref,"T5_APLTaskRevision")==0)						//FOR APL DML TASK
										{
											ITKCALL(AOM_ask_value_string(PartDmlTaskTag, "item_id",&TaskId));
											if(tc_strstr(TaskId,APLDmlPlnt)!=NULL)								// FIND APLC IN 22PP800563_00_APLC
											{
												epaSamePlantFnd++;

												ITKCALL(AOM_ask_value_string(PartDmlTaskTag, "item_id",&epaId));
												printf("\n DML ID: %s.....\n",epaId);														

												//ITK_CALL(POM_attr_id_of_attr("date_released","T5_APLDMLRevision",&DMLClosureDtAttrId));
												//ITK_CALL(POM_set_attr_date(1,&itemrev,DMLClosureDtAttrId,test_date_2));

												ITKCALL(AOM_UIF_ask_value(PartDmlTaskTag,"date_released",&ClosureDate));
												printf("\n ClosureDate : %s\n",ClosureDate);fflush(stdout);//28-Oct-2017 14:12

												ClosureDateDup = subString(ClosureDate,0,11);
												printf("\n ClosureDateDup : %s\n",ClosureDateDup);fflush(stdout);
												getCurrentDateTime(cCurrentAccessDate);
												printf("\n  todays date111 is: %s\n",cCurrentAccessDate);
												pAccessDateDup = subString(cCurrentAccessDate,0,11);
												printf("\n  todays date is: %s\n",pAccessDateDup);

												//if (tc_strcmp(IsDMLRlzErr1,"NULL")==0) MEM_free(IsDMLRlzErr1);
												IsDMLRlzErr1=NULL;
												IsDMLRlzErr1=(char *)MEM_alloc(100);
												tc_strcpy(IsDMLRlzErr1,"");
												if(tc_strcmp(ClosureDateDup,pAccessDateDup)==0)
												{

													if(epacnt==0)
													{
														epacnt = 1;

														tc_strcat(IsDMLRlzErr1,"\n Two revision of part ");
														tc_strcat(IsDMLRlzErr1,Part_no);
														tc_strcat(IsDMLRlzErr1," cannot be released on same day.\n");
														printf("\n IsDMLRlzErr1: %s\n",IsDMLRlzErr1);fflush(stdout);

													}
													else
													{
														tc_strcat(IsDMLRlzErr1,"\n Two revision of part ");
														tc_strcat(IsDMLRlzErr1,Part_no);
														tc_strcat(IsDMLRlzErr1," cannot be released on same day..\n");
														epacnt=epacnt+1;
														printf("\n IsDMLRlzErr1: %s\n",IsDMLRlzErr1);fflush(stdout);
													}
													printf("\n epacnt: %d\n",epacnt);fflush(stdout);

													if(epacnt==1)
													{
														tc_strcat(SetChildRelErr,IsDMLRlzErr1);
														cntEPAFlag = 1;
													}
													else
													{
														tc_strcat(SetChildRelErr,IsDMLRlzErr1);
														cntEPAFlag = 1;
													}
												}						
											}
										}
									}
								}


								//For AM DML
								if(epaSamePlantFnd==0)
								{

									for (z=0;z<dmlTskcount ;z++ )
									{
										PartDmlTaskTag=PartDmlTaskTags[z];//task pointer
										printf("\n\n\t\t INSIDE: ");fflush(stdout);

										ITKCALL(TCTYPE_ask_object_type(PartDmlTaskTag,&objTypeRefTag));//task pointer
										ITKCALL(TCTYPE_ask_name2(objTypeRefTag,&type_name_ref));
										
										if (strcmp(type_name_ref,"T5_APLTaskRevision")==0)				//FOR AM DML TASK
										{
											ITKCALL(AOM_ask_value_string(PartDmlTaskTag, "item_id",&TaskId));
											if(tc_strstr(TaskId,APLDmlPlnt)!=NULL)
											{
										
												epaSamePlantFnd++;
												ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
												if (tsk_dml_rel_type!=NULLTAG)
												{
													ITKCALL(GRM_list_primary_objects_only(PartDmlTaskTag,tsk_dml_rel_type,&dmlcount,&DmlRevision));
													for (x=0;x<dmlcount ;x++ )
													{
														DMLRevTag = DmlRevision[x];
														ITKCALL(AOM_ask_value_string(DMLRevTag, "item_id",&epaId));
														printf("\n epaId %s.....\n",epaId);

														if (tc_strstr(epaId,"AM")!=NULL)
														{
															printf("\nAM DML found");fflush(stdout);
															ITKCALL(AOM_ask_value_string(DMLRevTag, "t5_EcnType",&ECNType));
															printf("\n ECN Type %s.....\n",ECNType);

															int n_entries11 =	3;
															char *qry_entries11[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
															char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
															int resultCount11=0;
															tag_t	Cntl_obj_Qtag11	=	NULLTAG;
															tag_t *qry_cntrlobj11= NULLTAG;
															char	*cUserinfo1	=	NULLTAG;

															if(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));

															if (Cntl_obj_Qtag11!=NULLTAG)
															{
																qry_values11[0] =	"ECNType" ;
																qry_values11[1] =	PlantName ; //need to change
																qry_values11[2] =	"0" ;

																ITKCALL(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
																printf("\nNo. of control object found : %d",resultCount11);fflush(stdout);

																if (resultCount11>0)
																{
																	printf("\nControl object found");fflush(stdout);
																	ITKCALL(AOM_ask_value_string( qry_cntrlobj11[0], "t5_Userinfo1", &cUserinfo1));
																	printf("\n cUserinfo1: %s\n",cUserinfo1);fflush(stdout);

																	if (strcmp(cUserinfo1, ECNType) != 0)
																	{
																		printf("\nECN Type not AMDML");fflush(stdout);


																		ITKCALL(AOM_UIF_ask_value(DMLRevTag,"date_released",&ClosureDate));
																		printf("\n ClosureDate : %s\n",ClosureDate);fflush(stdout);//28-Oct-2017 14:12

																		ClosureDateDup = subString(ClosureDate,0,11);
																		printf("\n ClosureDateDup : %s\n",ClosureDateDup);fflush(stdout);
																		getCurrentDateTime(cCurrentAccessDate);
																		printf("\n  todays date111 is: %s\n",cCurrentAccessDate);
																		pAccessDateDup = subString(cCurrentAccessDate,0,11);
																		printf("\n  todays date is: %s\n",pAccessDateDup);

																		//if (tc_strcmp(IsDMLRlzErr1,"NULL")==0) MEM_free(IsDMLRlzErr1);
																		IsDMLRlzErr1=NULL;
																		IsDMLRlzErr1=(char *)MEM_alloc(100);
																		tc_strcpy(IsDMLRlzErr1,"");
																		if(tc_strcmp(ClosureDateDup,pAccessDateDup)==0)
																		{

																			if(epacnt==0)
																			{
																				epacnt = 1;

																				tc_strcat(IsDMLRlzErr1,"\n Two revision of part ");
																				tc_strcat(IsDMLRlzErr1,Part_no);
																				tc_strcat(IsDMLRlzErr1," cannot be released on same day.\n");
																				printf("\n IsDMLRlzErr1: %s\n",IsDMLRlzErr1);fflush(stdout);

																			}
																			else
																			{
																				tc_strcat(IsDMLRlzErr1,"\n Two revision of part ");
																				tc_strcat(IsDMLRlzErr1,Part_no);
																				tc_strcat(IsDMLRlzErr1," cannot be released on same day..\n");
																				epacnt=epacnt+1;
																				printf("\n IsDMLRlzErr1: %s\n",IsDMLRlzErr1);fflush(stdout);
																			}
																			printf("\n epacnt: %d\n",epacnt);fflush(stdout);

																			if(epacnt==1)
																			{
																				tc_strcat(SetChildRelErr,IsDMLRlzErr1);
																				cntEPAFlag = 1;
																			}
																			else
																			{
																				tc_strcat(SetChildRelErr,IsDMLRlzErr1);
																				cntEPAFlag = 1;
																			}
																		}
																		
																	}
																	else
																	{
																		printf("\nECN Type AMDML");fflush(stdout);
																	}



																}
															}	

														}

														//ITK_CALL(POM_attr_id_of_attr("date_released","T5_APLDMLRevision",&DMLClosureDtAttrId));
														//ITK_CALL(POM_set_attr_date(1,&itemrev,DMLClosureDtAttrId,test_date_2));

														
													}
												
												}
											}
										}


									}
								}



							}
						}
					}
				}
			}
		}



		// EPA PARTS PREVIOUS REVISION NOT RELEASE CHECK COMMENTED BY RITIK
		//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

		//COMMENTED BY DEEPTI TZ1.43
		/*if(Item_count > 0)
		{
			RevFlag = 0;
			PreRevFlag = 0;
			for(ii=Item_count-1;ii>=0;ii--)
			{
				RevOnly = NULL;
				PreRevOnly = NULL;
				ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));
				printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);
				printf("\n Part_rev_Id: %s\n",Part_rev_Id);fflush(stdout);
				if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
				{
					RevFlag = 1;
				}
				printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
				if(RevFlag == 1)
				{
					RevOnly= strtok( Part_Rev_copy, ";" );
					PreRevOnly= strtok( Part_rev_Id, ";" );
					printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
					printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
					if(tc_strcmp(RevOnly,PreRevOnly)!=0)
					{
						PreRevFlag = 1;
					}
				}
				printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
				if(PreRevFlag == 1)
				{
					//Added By Dhanashri for skip prev rev UATZ1.42//
					 char*			SkipPrevRevSTD1				= NULL;
					 ITKCALL(AOM_ask_value_string(rev_list[ii],"t5_SkipPrevRevSTD",&SkipPrevRevSTD1));
					 printf("\n\n\t\t SkipPrevRevSTD1  is :%s",SkipPrevRevSTD1);	fflush(stdout);
					 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD1)  is :%d",tc_strlen(SkipPrevRevSTD1));	fflush(stdout);
					   
								  //if(tc_strcmp(SkipPrevRevSTD1,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD1,"") !=0)
								  if(tc_strlen(SkipPrevRevSTD1)>0)
								  {
								 	printf("\n\n\t\t Inside SkipPrevRevSTD1 not null...");	fflush(stdout);
								 	continue;
								  }
					//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

					ITKCALL(WSOM_ask_release_status_list(rev_list[ii],&st_count,&status_list));
					if(st_count == 0)
					{
						printf("\n NO LCS Found for part : %d\n",st_count);fflush(stdout);
						break;
					}
					else
					{
						for (iLCS=0;iLCS<st_count ;iLCS++ )
						{
							ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
							printf("\n class_name: %s\n",class_name);fflush(stdout);
							
							if(tc_strcmp(class_name,LcstobeChecked)==0)
							{
								cntLcs++;
								break;
							}
							
						}
						printf("\n cntLcs inside : %d\n",cntLcs);fflush(stdout);
						break;
					}
				}  /// End Prev Rev  Flag Loop

			}
		}*/

		/*if(Item_count > 0)
		{
		
			if(strstr(Part_Rev,"NR"))
			{
				printf("\n in EPA Previous revision function can not be called as current revision has NR revision");fflush(stdout);
			}
			else
			{
				PreRevFlag = 0;
				printf("\n in EPA Calling function to get Previous revision ");fflush(stdout);
				tm_fnd_Prev_Official_Revision(Part_no,AssyTag,&AssyPreTag);//TZ 1.43
				if(AssyPreTag)
				{
					//Added By Dhanashri for skip prev rev UATZ1.42//
					PreRevFlag = 1;
					char*			SkipPrevRevSTD1				= NULL;
					ITKCALL(AOM_ask_value_string(AssyPreTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD1));
					printf("\n\n\t\t SkipPrevRevSTD1  is :%s",SkipPrevRevSTD1);	fflush(stdout);
					printf("\n\n\t\t tc_strlen(SkipPrevRevSTD1)  is :%d",tc_strlen(SkipPrevRevSTD1));	fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyPreTag,"item_id",&PrevRevItemID));
					printf("\n\n\t\t PrevRevItemID  is :%s",PrevRevItemID);	fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyPreTag,"item_revision_id",&PrevRevItemSeq));
					printf("\n\n\t\t PrevRevItemSeq  is :%s",PrevRevItemSeq);	fflush(stdout);

					

					//if(tc_strcmp(SkipPrevRevSTD1,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD1,"") !=0)
					if(tc_strlen(SkipPrevRevSTD1)>0)
					{
						printf("\n\n\t\t Inside SkipPrevRevSTD1 not null...");	fflush(stdout);
						continue;
					}
					//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

					ITKCALL(WSOM_ask_release_status_list(AssyPreTag,&st_count,&status_list));
					if(st_count == 0)
					{
						printf("\n NO LCS Found for part : %d\n",st_count);fflush(stdout);
						
					}
					else
					{
						for (iLCS=0;iLCS<st_count ;iLCS++ )
						{
							ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
							printf("\n class_name: %s\n",class_name);fflush(stdout);
							
							if(tc_strcmp(class_name,LcstobeChecked)==0)
							{
								cntLcs++;
								break;
							}
							
						}
						printf("\n cntLcs inside : %d\n",cntLcs);fflush(stdout);
						
					}				
				
				}
			}
				
		}
		
		//if (tc_strcmp(ChildRelErr,"NULL") !=0) MEM_free(ChildRelErr);
		ChildRelErr=NULL;
		ChildRelErr=(char *)MEM_alloc(100);
		tc_strcpy(ChildRelErr," ");

		revOnSameEpa=0;*/

		/*if (cntLcs<=0 && PreRevFlag == 1)
		{
			ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
			ITKCALL(GRM_list_primary_objects_only(AssyPreTag,relation_type,&dmlTskcount,&PartDmlTaskTags));
			if(dmlTskcount >0)
			{
				
				for (g=0;g<dmlTskcount ;g++ )
				{
					PartDmlTaskTag=PartDmlTaskTags[g];//task pointer
					printf("\n\n\t\t INSIDE: ");fflush(stdout);

					ITKCALL(TCTYPE_ask_object_type(PartDmlTaskTag,&objTypeRefTag));//task pointer
					ITKCALL(TCTYPE_ask_name2(objTypeRefTag,&type_name_ref));

					printf("\n\n\t\t type_name_ref:%s",type_name_ref);fflush(stdout);

					if (strcmp(type_name_ref,"T5_EPATaskRevision")==0)
					{
						
						ITKCALL(AOM_ask_value_string(PartDmlTaskTag, "item_id",&epaTaskId));
						printf("\n\n\t\t epaTaskId:%s:%s",epaTaskId,APLDmlPlnt);fflush(stdout);
						if(tc_strstr(epaTaskId,APLDmlPlnt)!=NULL)
						{
					
							epaSamePlantFnd++;
							ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
							if (tsk_dml_rel_type!=NULLTAG)
							{
								ITKCALL(GRM_list_primary_objects_only(PartDmlTaskTag,tsk_dml_rel_type,&dmlcount,&EPARevision));
								for (h=0;h<dmlcount ;h++ )
								{
									EpaRevTag = EPARevision[h];
									ITKCALL(AOM_ask_value_string(EpaRevTag, "item_id",&epaId));
									printf("\n epaId %s.....\n",epaId);fflush(stdout);

									if(strcmp(epaId,epanosignoff)==0)
									{
										revOnSameEpa++;
									}
								}
							}
						}
					}
				}
			}
			
			
			if(revOnSameEpa==0)
			{
				if(epacnt==0)
				{
					epacnt = 1;
					tc_strcat(ChildRelErr,"Previous Revision Part ");
					tc_strcat(ChildRelErr,Part_no);
					tc_strcat(ChildRelErr,",");
					tc_strcat(ChildRelErr,PrevRevItemSeq);
					tc_strcat(ChildRelErr," is not STDSI Released. Please release Previous Revision First.\n");
					printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
				}
				else
				{
					tc_strcat(ChildRelErr,"Previous Revision Part ");
					tc_strcat(ChildRelErr,Part_no);
					tc_strcat(ChildRelErr,",");
					tc_strcat(ChildRelErr,PrevRevItemSeq);
					tc_strcat(ChildRelErr," is not STDSI Released. Please release Previous Revision First\n");
					printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
					epacnt = epacnt+1;
					printf("\n ChildRelEr22r: %s\n",ChildRelErr);fflush(stdout);
				}

				if(epacnt==1)
				{
					tc_strcpy(SetChildRelErr,ChildRelErr);
					cntEPAFlag = 1;
				}
				else
				{
					tc_strcat(SetChildRelErr,ChildRelErr);
					cntEPAFlag = 1;
				}
			}
		
		}*/

		//if(cntLcs>0 && PreRevFlag == 1)
		//{
			//ITKCALL(WSOM_status_ask_effectivities(status_list[iLCS],n_effectivities,&effectivities));


		//}

	
	}

	printf("\n PrevRevSMDMLEPASet:%s",PrevRevSMDMLEPASet);fflush(stdout);
	if(smdmlEpaErrorCnt>0)
	{
		tc_strcat(SetChildRelErr,PrevRevSMDMLEPASet);	
	}

	return 0;
}

int EPA_Part_PP_DML_Rlzd_Checks(char *epaTaskNo,int PartCnt, tag_t* PartTags,char* SetChildRelErr,char *LcstobeChecked,char *PlantName,char *APLDmlPlnt)
{
	EPM_decision_t decision;
	int k=0;
	int k1=0;
	int errorCnt=0;
	int cntLcs=0;
	int task_st_count=0;
	int dmlTskcount=0;
	int tskCnt=0;
	tag_t			AssyTag				= NULLTAG;
	tag_t			PartDmlTaskTag				= NULLTAG;
	char*			Part_no				= NULL;
	char*			Part_Rev			= NULL;
	char*			TaskId			= NULL;
	char*			Part_Rev_copy		= NULL;
	tag_t			relation_type= NULLTAG;
	tag_t*			PartDmlTaskTags			= NULLTAG;
	tag_t			objTypeRefTag						= NULLTAG;
	//API change
	//char			type_name_ref[TCTYPE_name_size_c+1];
	char *type_name_ref = NULL;
	char*			ClosureDate			= NULL;
	char*			DMLList				= NULL;
	char*			class_name			= NULL;
	char*			IsDMLRlzErr1			= NULL;
	char*			EPA_Num			= NULL;
	char*			EPA_DML_Num			= NULL;
	tag_t *task_status_list;

	
	printf("\n Calling EPA_Part_PP_DML_Rlzd_Checks .....\n");fflush(stdout);
	
	

	EPA_Num=tc_strtok(epaTaskNo,"_");
	EPA_DML_Num = tc_strtok(NULL,"_");
	printf("\n EPA_Num :[%s],EPA_DML_Num %s \n",EPA_Num,EPA_DML_Num);fflush(stdout);
	
	if (tc_strcmp(DMLList,"NULL")==0) MEM_free(DMLList);
	DMLList=(char *)MEM_alloc(1000);


	for (k=0;k<PartCnt ;k++ )
	{
		printf("\n\n\t\t Part Cn : =:%d",k);fflush(stdout);
		AssyTag=PartTags[k];
		cntLcs=0;

		ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
		ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev));
		ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev_copy));

		printf("\n\n\t\t Part_no : =:%s: Part_Rev ==%s",Part_no,Part_Rev);fflush(stdout);

					//Added By Dhanashri for skip prev rev UATZ1.42//
					 char*			SkipPrevRevSTD				= NULL;
					 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
					 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
					 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
			
						//if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
						if(tc_strlen(SkipPrevRevSTD)>0)
						{
						printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
						continue;
						}
					//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//

		ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&relation_type));
		ITKCALL(GRM_list_primary_objects_only(AssyTag,relation_type,&dmlTskcount,&PartDmlTaskTags));
		printf("\n\n\t\t dmlTskcount ==%d",dmlTskcount);fflush(stdout);
		if(dmlTskcount >0)
		{
			
			for (k1=0;k1<dmlTskcount ;k1++ )
			{
				cntLcs=0;
				PartDmlTaskTag=PartDmlTaskTags[k1];//task pointer
				printf("\n\n\t\t INSIDE EPA_Part_PP_DML_Rlzd_Checks: ");fflush(stdout);

				ITKCALL(TCTYPE_ask_object_type(PartDmlTaskTag,&objTypeRefTag));
				ITKCALL(TCTYPE_ask_name2(objTypeRefTag,&type_name_ref));
				printf("\n\n\t\t INSIDE EPA_Part_PP_DML_Rlzd_Checks type_name_ref %s: ",type_name_ref);fflush(stdout);

				if (strcmp(type_name_ref,"T5_APLTaskRevision")==0)
				{
					
					ITKCALL(AOM_ask_value_string(PartDmlTaskTag, "item_id",&TaskId));
					printf("\n\n\t\t DML PLant Details %s:%s:%s ",TaskId,APLDmlPlnt,EPA_DML_Num);fflush(stdout);
					if(tc_strstr(TaskId,APLDmlPlnt)!=NULL)
					{
						printf("\n\n\t\t Plant DML Task Found !!! ");fflush(stdout);
						
						if(tc_strstr(TaskId,EPA_DML_Num)!=NULL)
						{
							printf("\n\n\t\t Matched DML NO !!! ");fflush(stdout);
							
							ITKCALL(AOM_UIF_ask_value(PartDmlTaskTag,"date_released",&ClosureDate));
							printf("\n ClosureDate : %s\n",ClosureDate);fflush(stdout);
							ITKCALL(WSOM_ask_release_status_list(PartDmlTaskTag,&task_st_count,&task_status_list));
							if(task_st_count == 0)
							{
								printf("\n NO LCS Found for Plant Task : %d\n",task_st_count);fflush(stdout);
								//break;
							}
							else
							{
								for (tskCnt=0;tskCnt<task_st_count ;tskCnt++ )
								{
									ITKCALL(AOM_ask_value_string(task_status_list[tskCnt],"object_name",&class_name));
									printf("\n class_name: %s\n",class_name);fflush(stdout);
									
									if(tc_strcmp(class_name,LcstobeChecked)==0)
									{
										cntLcs++;
										break;
									}
									
								}
								printf("\n cntLcs inside : %d\n",cntLcs);fflush(stdout);
								//break;
							}
							if((cntLcs>0) && (strcmp(ClosureDate,"")!=0))
							{
								break;
							}
							//if((cntLcs==0) && (strcmp(ClosureDate,"")==0)) //TZ1.43 Deepti
							if(cntLcs==0)							
							{	
								if(errorCnt==0)
								{
									tc_strcpy(DMLList,TaskId);							
								}
								else
								{
									if((tc_strstr(DMLList,TaskId)!=NULL))
									{
										printf("\n IN DML List DMLList : %s,Task %s already found!!\n",DMLList,TaskId);fflush(stdout);
									}
									else
									{
										printf("\n Adding IN DML List DMLList : %s,Task %s !\n",DMLList,TaskId);fflush(stdout);
										tc_strcat(DMLList,";");
										tc_strcat(DMLList,TaskId);
									}
								}
								errorCnt++;	
								printf("\n DMLList : %s\n",DMLList);fflush(stdout);

							}
							//break;
						}
					
					}
				
				}
			}
		}

		/*if (tc_strcmp(IsDMLRlzErr1,"NULL")==0) MEM_free(IsDMLRlzErr1);
		IsDMLRlzErr1=(char *)MEM_alloc(1000);
		tc_strcpy(IsDMLRlzErr1,"");
		if(errorCnt>0)
		{
			if(epacnt==0)
			{
				epacnt = 1;

				tc_strcat(IsDMLRlzErr1,"\n DML Task ");
				tc_strcat(IsDMLRlzErr1,DMLList);
				tc_strcat(IsDMLRlzErr1," are not released by STDSI.\n");
				tc_strcat(IsDMLRlzErr1," First release these DMLs/DML Task before releasing EPA.\n");
				printf("\n IsDMLRlzErr1: %s\n",IsDMLRlzErr1);fflush(stdout);

			}
			else
			{
				tc_strcat(IsDMLRlzErr1,"\n DML Task ");
				tc_strcat(IsDMLRlzErr1,DMLList);
				tc_strcat(IsDMLRlzErr1," are not released by STDSI.\n");
				tc_strcat(IsDMLRlzErr1," First release these DMLs/DML Task before releasing EPA.\n");
				epacnt=epacnt+1;
				printf("\n IsDMLRlzErr1: %s\n",IsDMLRlzErr1);fflush(stdout);
			}
			printf("\n epacnt: %d\n",epacnt);fflush(stdout);

			if(epacnt==1)
			{
				tc_strcat(SetChildRelErr,IsDMLRlzErr1);
				cntEPAFlag = 1;
			}
			else
			{
				tc_strcat(SetChildRelErr,IsDMLRlzErr1);
				cntEPAFlag = 1;
			}		
		
		}*/
	
	
	}
	if (tc_strcmp(IsDMLRlzErr1,"NULL")==0) MEM_free(IsDMLRlzErr1);
	IsDMLRlzErr1=(char *)MEM_alloc(1000);
	tc_strcpy(IsDMLRlzErr1,"");
	if (cntLcs==0)
	{
	
		if(errorCnt>0)
		{
			if(epacnt==0)
			{
				epacnt = 1;

				tc_strcat(IsDMLRlzErr1,"\n DML Task ");
				tc_strcat(IsDMLRlzErr1,DMLList);
				tc_strcat(IsDMLRlzErr1," are not released by STDSI.\n");
				tc_strcat(IsDMLRlzErr1," First release any of these DMLs/DML Task before releasing EPA.\n");
				printf("\n IsDMLRlzErr1: %s\n",IsDMLRlzErr1);fflush(stdout);

			}
			else
			{
				tc_strcat(IsDMLRlzErr1,"\n DML Task ");
				tc_strcat(IsDMLRlzErr1,DMLList);
				tc_strcat(IsDMLRlzErr1," are not released by STDSI.\n");
				tc_strcat(IsDMLRlzErr1," First release any of these DMLs/DML Task before releasing EPA.\n");
				epacnt=epacnt+1;
				printf("\n IsDMLRlzErr1: %s\n",IsDMLRlzErr1);fflush(stdout);
			}
			printf("\n epacnt: %d\n",epacnt);fflush(stdout);

			if(epacnt==1)
			{
				tc_strcat(SetChildRelErr,IsDMLRlzErr1);
				cntEPAFlag = 1;
			}
			else
			{
				tc_strcat(SetChildRelErr,IsDMLRlzErr1);
				cntEPAFlag = 1;
			}		
		
		}
	}
	
	return 0;
}

int EPA_Child_Part_Rlzd_Checks(int PartCnt,char	*epa_plant, tag_t* PartTags,char* SetChildRelErr,char *LcstobeChecked,char *PlantName,char *RevisionRl,char *ClosureRl,char *ViewBVR)
{

	EPM_decision_t decision;
	int				k=0;
	int				st_count=0;
	int				cntLcs=0;
	int				count1=0;
	int				ii=0;
	int				iLCS=0;
	tag_t			AssyTag				= NULLTAG;
	tag_t   AssyTag1         = NULLTAG;
	char*           ppartid = NULL;
	int             ipart=0;
	int             Partflag= 0;
	char*			Part_no				= NULL;
	char*			Part_owning_groupVal				= NULL;
	char*			BVRAsPerPartOwner				= NULL;
	char*			Item_id				= NULL;
	char*			ChildRelErr				= NULL;
	char*			class_name				= NULL;
	char*			Part_Type				= NULL;
	struct			BomChldStrut	ChldStrutBdySh[5000];
	int				StructCntBdyShProdPlan	= 0;
	int				childBS	= 0;
	tag_t			objChild_BS		= NULLTAG;
	const char *qry_entries[2];
	const char *qry_values[2];
	int n_tags_found2=0;
	tag_t	*itemclass2							= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t	item_rev_cld_tag							= NULLTAG;
	tag_t *  rev_list;
	tag_t*    status_list;

	//added by vishal
	char        *EPAvalue = NULL;
    EPAvalue = (char *)MEM_alloc(1 * sizeof(char *));

	// Control Object for Unconfigured Revision Check in STDSI - Palash
	char    *qryEntry[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qryValues[3]= {"STDSI","UNCONFIGURED","0"};
	
    tag_t qryTagSTDSIChk=NULLTAG;
    int qryCount=0;
    tag_t* qryResult=NULLTAG;

	ITKCALL(QRY_find2("Control Objects...", &qryTagSTDSIChk));
	if (qryTagSTDSIChk)
	{
	    printf("\n Control Object Query Found \n Going to call unconfigured Revision Check \n");fflush(stdout);
	    ITKCALL(QRY_execute(qryTagSTDSIChk, 3, qryEntry, qryValues, &qryCount, &qryResult));
		printf("\n Query Count for Unconfigured Revision is : %d\n",qryCount);fflush(stdout);
	}
	// Control Object for Unconfigured Revision Check in STDSI - Palash - Code Ends for Control Object Check

	for (k=0;k<PartCnt ;k++ )
	{
		AssyTag=PartTags[k];
		cntLcs=0;

		ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
		printf("\n\n\t\t APL DML Cre:Part_no  is :%s",Part_no);	fflush(stdout);

		ITKCALL(AOM_UIF_ask_value(AssyTag,"owning_group",&Part_owning_groupVal));
		printf("\n\n\t\t Part_no  Part_owning_groupVal is :%s",Part_owning_groupVal);fflush(stdout);

		//Added By Dhanashri for skip prev rev UATZ1.42//
		 char*			SkipPrevRevSTD				= NULL;
		 ITKCALL(AOM_ask_value_string(AssyTag,"t5_SkipPrevRevSTD",&SkipPrevRevSTD));
		 printf("\n\n\t\t SkipPrevRevSTD  is :%s",SkipPrevRevSTD);	fflush(stdout);
		 printf("\n\n\t\t tc_strlen(SkipPrevRevSTD)  is :%d",tc_strlen(SkipPrevRevSTD));	fflush(stdout);
			
						//if(tc_strcmp(SkipPrevRevSTD,"NULL") !=0 || tc_strcmp(SkipPrevRevSTD,"") !=0)
						if(tc_strlen(SkipPrevRevSTD)>0)
						{
						printf("\n\n\t\t Inside SkipPrevRevSTD not null...");	fflush(stdout);
						continue;
						}
		//End Of Code Added By Dhanashri for skip prev rev UATZ1.42//


		if (tc_strcmp(BVRAsPerPartOwner,"NULL") !=0) MEM_free(BVRAsPerPartOwner);
		BVRAsPerPartOwner=(char *)MEM_alloc(100);

		//TZ3.46
				char BVRInfo2[40];
				char Info1[40];
				char Info3[40];

				//added by vishal
				
				getEPAPlantName(epa_plant,EPAvalue);

				get_CtrlVal_APLLcsInf(EPAvalue,Info1,BVRInfo2,Info3); 

				//get_CtrlVal_APLLcsInf(Part_owning_groupVal,Info1,BVRInfo2,Info3);//TZ3.46
				tc_strcpy(BVRAsPerPartOwner,BVRInfo2);

		StructCntBdyShProdPlan=0;

		if(qryCount>0) // Changed by Palash for STDS Unconfigured BOM Check
		{
			ITKCALL(Get_Part_BOM_Lvl_Unconfigured(AssyTag,1,ClosureRl,RevisionRl,BVRAsPerPartOwner,ChldStrutBdySh,&StructCntBdyShProdPlan));
		}
		else{
			ITKCALL(Get_Part_BOM_Lvl(AssyTag,1,ClosureRl,RevisionRl,BVRAsPerPartOwner,ChldStrutBdySh,&StructCntBdyShProdPlan));
		}// Changed by Palash for STDS Unconfigured BOM Check - Code Ends


		printf("\n\t\t StructCntBdyShProdPlan:%d",StructCntBdyShProdPlan);fflush(stdout);

		childBS = 0;
		for (childBS = 1; childBS <= StructCntBdyShProdPlan; childBS++)
		{
			cntLcs=0;
			objChild_BS		= NULLTAG;
			objChild_BS=ChldStrutBdySh[childBS].child_objs;
			char	*Part_clr_ind	=	NULL;
			
			
			//Starting to handle EPA Manindra child part release quantity Zero ***
	
			tag_t	objChild_bvr1epa = NULLTAG;	
			char	*Child_QtyEPA	     = NULL;			
			objChild_bvr1epa	     = NULLTAG;
			Child_QtyEPA			 = NULL;
			objChild_bvr1epa=ChldStrutBdySh[childBS].child_objs_bvr;
			

			ITKCALL(AOM_UIF_ask_value(objChild_BS,"item_id",&Item_id));
			printf("\n\n\t EPA Child Part String is Item_id-->%s",Item_id);	fflush(stdout);
			
			AOM_ask_value_string(objChild_bvr1epa,"bl_quantity",&Child_QtyEPA);
			printf("\nChild part [%s] is having its Qty==>[%s]\n",Item_id,Child_QtyEPA);fflush(stdout);
			if (tc_strcmp(Child_QtyEPA,"0")==0)
			{
				printf("\n Child Part Quantity is [%s] ,hence bypass the validation for the part [%s]",Child_QtyEPA,Item_id);fflush(stdout);
				continue;
			}
			///End to handle EPA Manindra child part release quantity Zero ***
			
			ITKCALL(AOM_UIF_ask_value(objChild_BS,"item_id",&Item_id));
			printf("\n\n\t EPA Child Part String is Item_id-->%s",Item_id);	fflush(stdout);

			Part_clr_ind	=	NULL;
			ITKCALL(AOM_ask_value_string(objChild_BS,"t5_ColourInd",&Part_clr_ind));
			printf("\n\n\t EPA Child Part String is Part_clr_ind-->%s",Part_clr_ind);	fflush(stdout);

			ITKCALL(AOM_ask_value_string(objChild_BS,"t5_PartType",&Part_Type));
			printf("\n\n\t EPA Child Part String is Part_Type-->%s",Part_Type);	fflush(stdout);

       //muskan code of child part error bypass//

            ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
			printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);

		    Partflag=0;       
           for (ipart=0; ipart<PartCnt ; ipart++ )
         {   
	     
		  printf("\n\n\t\t muskan  EPA PartCnt:%d",PartCnt);fflush(stdout);

          tag_t AssyTag1 = NULLTAG;
          AssyTag1= PartTags[ipart];
		  char* ppartid = NULL;
		  
		 ITKCALL(AOM_ask_value_string(AssyTag1,"item_id",&ppartid));

        printf("\n\n\t\t epa part no  is :%s",ppartid); fflush(stdout); //123 //456
 

		   if(strcmp(ppartid,Item_id)==0)
		 {
           printf("under epa child part bypass code");fflush(stdout);
		   Partflag=1;
		   break;
		   
		   }

     }  
//end muskan code for child part//











			if((strcmp(Part_Type,"D")==0)|| (strcmp(Part_Type,"DC")==0)|| (strcmp(Part_Type,"DA")==0))
			{
				continue;
			}

			qry_entries[0] ="item_id";
			qry_entries[1] ="object_type";//Multiple Item Queried Error
			qry_values[0] = Item_id;
			if (tc_strcmp(Part_clr_ind,"C")==0)
			{
				qry_values[1] = "T5_ClrPart";//Multiple Item Queried Error Hemal
			}
			else
			{
				//qry_values[1] = "Design";//Multiple Item Queried Error Hemal
				//Handle the different design child class.
				char	*designBORev		=	NULL;
				char	*designBO			=	NULL;
				//tag_t	AssyTag			=	NULLTAG;
				//AssyTag=PartTags[k];
				printf("\nBefore getDesignType");fflush(stdout);
				getDesignType(objChild_BS, &designBORev,&designBO);
				printf("\nAfter getDesignType : %s",designBO);fflush(stdout);
				qry_values[1] = designBO;


			}//Multiple Item Queried Error

			//ITKCALL(ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found2, &itemclass2));
			ITKCALL(ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found2, &itemclass2));////Multiple Item Queried Error
			itemcldclass = itemclass2[0];

			ITKCALL(ITEM_list_all_revs(itemcldclass, &count1,&rev_list ));
			for (ii = 0; ii < count1; ii++)
			{
				item_rev_cld_tag = rev_list[ii];

				ITKCALL(WSOM_ask_release_status_list(item_rev_cld_tag,&st_count,&status_list));
				printf("\n st_count:%d \n",st_count);fflush(stdout);
				if (tc_strcmp(ChildRelErr,"NULL") !=0) MEM_free(ChildRelErr);
				ChildRelErr=(char *)MEM_alloc(100);
				tc_strcpy(ChildRelErr," ");
				if (st_count == 0)  /* No Status, so the Item is not yet Released */
				{
					printf("\n No Status, so the Item is not yet Released \n");

				}
				else
				{

						for (iLCS=0;iLCS<st_count ;iLCS++ )
						{
							ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
							printf("\n class_name: %s:%s\n",class_name,LcstobeChecked);fflush(stdout);
							if(tc_strcmp(class_name,LcstobeChecked)==0)
							{
								cntLcs++;
								break;
							}
						}
				}
			}

			printf("\n cntLcs: %d\n",cntLcs);fflush(stdout);
			if (cntLcs<=0)
			{    //partflag of child part error bypass//
				if (Partflag==0){
				if(epacnt==0)
				{
					epacnt = 1;
					tc_strcat(ChildRelErr,"Child Part ");
					tc_strcat(ChildRelErr,Item_id);
					//tc_strcat(ChildRelErr,",");
					//tc_strcat(ChildRelErr,Item_rev);
					tc_strcat(ChildRelErr,"  Of Parent Part ");
					tc_strcat(ChildRelErr,Part_no);
					tc_strcat(ChildRelErr," is not STDSI Released from Plant.\n");
					printf("\n ChildRelErr11: %s\n",ChildRelErr);fflush(stdout);
				}
				else
				{
					tc_strcat(ChildRelErr,"Child Part ");
					tc_strcat(ChildRelErr,Item_id);
					//tc_strcat(ChildRelErr,",");
					//tc_strcat(ChildRelErr,Item_rev);
					tc_strcat(ChildRelErr,"  Of Parent Part ");
					tc_strcat(ChildRelErr,Part_no);
					tc_strcat(ChildRelErr," is not STDSI Released from Plant.\n");
					epacnt = epacnt+1;
					printf("\n ChildRelEr22r: %s\n",ChildRelErr);fflush(stdout);
				}
				if(epacnt==1)
				{
					tc_strcpy(SetChildRelErr,ChildRelErr);
					cntEPAFlag = 1;
				}
				else
				{
					tc_strcat(SetChildRelErr,ChildRelErr);
					cntEPAFlag = 1;
				}}
			}				

		}
	
	}


	return 0;

}

int EPA_Prev_Part_Rev_Finalize_Checks(char* epaitemid, tag_t epa_rev_tag1, int PartCnt, tag_t* PartTags,char* SetChildRelErr, char* lcsToset, char* Plant, char* lcsStd_wrkng)        /// Added by Ritik
{

	int k,a,w,ii,precount_task,PreRevFlag,Item_count,Precnt,st_dmlcount,stlst1,WSOMcount,RevFlag=0;
	
	char*			Part_no					= NULL;
	char*			Part_Rev				= NULL;
	char*			Part_Rev_copy			= NULL;
	char*  			IsDMLRlzErr1 			= NULL;
	char*  			PrevRevItemID 			= NULL;
	char*  			PrevRevItemSeq 			= NULL;
    char* 			t5_EpaStatus			= NULL;
    char* 			EPA_item_id 			= NULL;
	char*			Pretype_class2 			= NULL;
	char* 			PreTaskId 				= NULL;
	char*			ReleaseStatusdml1		= NULL;
	char*			ReleaseStatusEPA		= NULL;
	char* 			t5_EpaPlantA			= NULL;
	char*			t5_EpaPlantALOVString	= NULL;
	char*			Part_prev_rev_Id 		= NULL;
	char*			RevOnly					= NULL;
	char*			PreRevOnly				= NULL;
	char*			Part_rev_Id				= NULL;

	tag_t 			t5_EpaPlantALOV			= NULLTAG;
    tag_t			AssyPreTag				= NULLTAG;
	tag_t			relation_type_task		= NULLTAG;
    tag_t			All_item_tag			= NULLTAG;
    tag_t			AssyTag					= NULLTAG;
	tag_t			PreParttskTag			= NULLTAG;
	tag_t			PreitemTypeTag_class2	= NULLTAG;
	
	tag_t*          rev_list				= NULLTAG;
	tag_t*			PrePartTskTags			= NULLTAG;
	tag_t*			dml_status_list1		= NULLTAG;
	tag_t*			EPA_status_list1		= NULLTAG;
	
	int PreRevFlag1		= 0;

	if (tc_strcmp(IsDMLRlzErr1,"NULL")==0) MEM_free(IsDMLRlzErr1);
	IsDMLRlzErr1=(char *)MEM_alloc(1000);
	tc_strcpy(IsDMLRlzErr1,"");

	printf("\n Calling EPA_Prev_Part_Rev_Finalize_Checks *****\n");fflush(stdout);

	//FOR ALL SOLUTION PARTS
	for (k=0;k<PartCnt ;k++ )
	{
		AssyTag=NULLTAG;
		AssyTag=PartTags[k];
		
		AssyPreTag=NULLTAG;

		ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
		ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev));
		ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Part_Rev_copy));

		printf("\n Item ID & Revision: %s/%s\n",Part_no,Part_Rev);fflush(stdout);

		//CHECK ALL PREVIOUS REVISIONS
		if(strstr(Part_Rev,"NR"))
		{
			printf("\n in EPA Previous revision function can not be called as current revision has NR revision");fflush(stdout);
		}
		else
		{
			ITKCALL(AOM_ask_value_tags(AssyTag,"revision_list",&Item_count,&rev_list));
			printf("\nTotal Revisions : %d",Item_count);fflush(stdout);

			if(Item_count > 0)
			{
				RevFlag		=	0;
				PreRevFlag	=	0;

				for(ii=Item_count-1;ii>=0;ii--)
				{
					RevOnly		=	NULL;
					PreRevOnly	=	NULL;

					ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));

					printf("\n\nCurrent Part_Rev %s and Part_rev_Id: %s\n",Part_Rev,Part_rev_Id);fflush(stdout);
					if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
					{
						RevFlag = 1;
					}
					printf("\n RevFlag : %d.", RevFlag);fflush(stdout);

					if(RevFlag == 1)
					{
						RevOnly		= strtok( Part_Rev, ";" );
						PreRevOnly	= strtok( Part_rev_Id, ";" );
						printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
						printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
						if(tc_strcmp(RevOnly,PreRevOnly)!=0)
						{
							PreRevFlag = 1;
							
						}
						printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);						

						if(PreRevFlag == 1)
						{
						
							printf("\n Previous Found");fflush(stdout);
							
							printf("\n Previous_Revision : %s.", PreRevOnly);fflush(stdout);

							//AFTER GETTING PREVIOUS REVISION
							ITKCALL(AOM_ask_value_string(rev_list[ii],"item_id",&PrevRevItemID));
							printf("\n\n\t\t PrevRevItemID  is :%s",PrevRevItemID);	fflush(stdout);

							ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&PrevRevItemSeq));
							printf("\n\n\t\t PrevRevItemSeq  is :%s",PrevRevItemSeq);	fflush(stdout);

							//CHECK RELEASED STATUS --> IF PREVIOUS REVISION STD RELEASED THEN SKIP
							ITKCALL(WSOM_ask_release_status_list(rev_list[ii],&st_dmlcount,&dml_status_list1));

							for (stlst1 = 0; stlst1 < st_dmlcount; stlst1++)
							{
								AOM_ask_name(dml_status_list1[stlst1], &ReleaseStatusdml1);

								printf("\n\n\t\t Prev_Rev_Release_Status :%s",ReleaseStatusdml1);	fflush(stdout);
								printf("\n\n\t\t Plant_wise_release_Status_STD_Released :%s",lcsToset);	fflush(stdout);
								
								if(tc_strcmp(ReleaseStatusdml1,lcsToset)==0 )
								{									
									printf("\n Previous revision is STD released, So Skipp");fflush(stdout);

									PreRevFlag1 = 1;								
								}
							}

							printf("\n Part is STD Working");fflush(stdout);
							printf("\n\n\t\t PreRevFlag1: %d",PreRevFlag1);	fflush(stdout);

							if(PreRevFlag1==0)
							{
								printf("\n Previous revision is not STD released");fflush(stdout);

								GRM_find_relation_type("CMHasSolutionItem",&relation_type_task);

								//CHECK PRIMARY OBJECTS FOR EPA TASK REVISION
								GRM_list_primary_objects_only(rev_list[ii],relation_type_task,&precount_task,&PrePartTskTags);

								for (Precnt=0;Precnt<precount_task ;Precnt++ )
								{
									PreParttskTag=NULLTAG;
									PreParttskTag=PrePartTskTags[Precnt];
									ITKCALL (TCTYPE_ask_object_type(PreParttskTag,&PreitemTypeTag_class2));
									ITKCALL (TCTYPE_ask_name2(PreitemTypeTag_class2,&Pretype_class2));

									printf("\t  Primary_Object_Type ...%s\n", Pretype_class2);fflush(stdout);	
															
									if(tc_strcmp(Pretype_class2,"T5_EPATaskRevision")==0)
									{	
										ITKCALL(AOM_ask_value_string(PreParttskTag, "item_id",&PreTaskId));
										printf("\n Primary_Object_ID %s.....\n",PreTaskId);	fflush(stdout);

										//CONCAT EPA TASK FOR EPA REVISION
										char*	EPATask;

										EPATask = strtok(PreTaskId, "_");

										char    *qry_entryItemRevformat[2]  = {"Type","Item ID"};	
										char	**qry_valuesItemRevformat= (char **) MEM_alloc(5 * sizeof(char *));

										int     n_entry    = 2;
										int 	QRYObjfound=0;

										tag_t   QRYItemRev     	= NULLTAG;
										tag_t*	EPA_Revision_tags	=NULLTAG;

										if( QRY_find2("Item Revision...", &QRYItemRev));
										if (QRYItemRev)
										{
											printf("\n Control Object Query Found \n");fflush(stdout);
											qry_valuesItemRevformat[0]="EPA Revision";
											qry_valuesItemRevformat[1]=EPATask;

											if(QRY_execute(QRYItemRev, n_entry, qry_entryItemRevformat, qry_valuesItemRevformat, &QRYObjfound, &EPA_Revision_tags));
										}
										else
										{
											printf("\n Item Revision... Query not Found \n");fflush(stdout);
										}	
										
										if(QRYObjfound>0)
										{
											for(a=0;a<QRYObjfound;a++)
											{
												//EPA REVISION FOUND
												ITKCALL (AOM_ask_value_string( EPA_Revision_tags[a], "item_id", &EPA_item_id));
												printf("\n EPA_Item_ID: %s\n",EPA_item_id);fflush(stdout);

												ITKCALL (AOM_ask_value_string( EPA_Revision_tags[a], "t5_EpaPlantA", &t5_EpaPlantA));

												printf("\n EPA_PLANT: %s\n",t5_EpaPlantA);fflush(stdout);

												printf("\n CO_wise_PLANT: %s\n",Plant);fflush(stdout);

												if(tc_strstr(t5_EpaPlantA,Plant)!=NULL) //PLANT WISE EPA CHECK
												{

													printf("\n Previous EPA ID %s.....\n",EPA_item_id);

													printf("\n Current EPA ID %s.....\n",epaitemid);

													if(tc_strcmp(EPA_item_id,epaitemid)!=0)												 
													{
														// Release status basis
														printf("\n Ritik_Get_EPA_Rev_Released_Status");fflush(stdout);

														ITKCALL(WSOM_ask_release_status_list(EPA_Revision_tags[a],&WSOMcount,&EPA_status_list1));

														printf("\n Release_Status_Count: %d\n",WSOMcount);fflush(stdout);												

														for (w = 0; w < WSOMcount; w++)
														{
															ITKCALL(AOM_ask_name(EPA_status_list1[w], &ReleaseStatusEPA));

															printf("\n\n\t\t EPA_Release_Status :%s",ReleaseStatusEPA);	fflush(stdout);
															printf("\n\n\t\t Plant_wise_release_Status_STD_Working :%s",lcsStd_wrkng);	fflush(stdout);

															if(tc_strcmp(ReleaseStatusEPA,lcsStd_wrkng)==0 )
															{															
																tc_strcpy(IsDMLRlzErr1, "");
																tc_strcat(IsDMLRlzErr1,"\n Previous Revision ");
																tc_strcat(IsDMLRlzErr1,PrevRevItemSeq);
																tc_strcat(IsDMLRlzErr1," of Part ");
																tc_strcat(IsDMLRlzErr1,PrevRevItemID);
																tc_strcat(IsDMLRlzErr1,"  is contained in EPA ");
																tc_strcat(IsDMLRlzErr1,EPA_item_id);
																tc_strcat(IsDMLRlzErr1, " which is not Finalized, Please Finalize this EPA Task.");
																tc_strcat(SetChildRelErr,IsDMLRlzErr1);
																printf("\n SetChildRelErr: %s\n",SetChildRelErr);fflush(stdout);
																cntEPAFlag = 1;
															}
														}
													}
												}												
											}
										}								
									}
								}
							}
						}
					}
				}				
			}
		}
	}	
	return 0;
} // End by Ritik

int  Prev_Rev_Checks_SMDML_EPA(tag_t* EPATaskRevision,int taskcount,char* SetStdRelErr,char *lcsToset,char *PlantName)
{

	EPM_decision_t decision;
	tag_t			EPATaskTag				= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			AssyPreTag				= NULLTAG;
	char			*EPA_Task_no			= NULL;
	char			*epaPrtRev			= NULL;
	char			*Part_rev_Id			= NULL;
	char			*Part_No_Pre			= NULL;
	char			*epaPrtNo			= NULL;
	tag_t*			PartTags			= NULLTAG;

	int k=0;
	int prtCnt=0,stlst = 0,st_dmlcount=0;
	int PartCnt=0,smDmlFnd=0,smRlzFlg=0,precount_task=0;
	int ii=0,Precnt=0;
	int RevFlag=0;
	int smdmlErrorCnt=0;
	int n_entries_Prt_Prev=2;
	tag_t   queryTag_Prt_Prev     = NULLTAG;
	char **qry_values_Prt_Prev = (char **) MEM_alloc(10 * sizeof(char *));
	char *qry_entries_Prt_Prev[2] = {"ID","Release Status"};
	int resultCount_Prt_Prev =0;

	int num_to_sort_Prt_Prev =1;
	char *keys_Prt_Prev [1] = {"creation_date"};
	int  	 orders_Prt_Prev [1]  ={1};
 	char	**qry_valuesCntrl_Prt_Prev= (char **) MEM_alloc(5 * sizeof(char *));
	tag_t *Rev_Prt_Prev=NULLTAG;
	tag_t			relation_type_task	= NULLTAG;
	tag_t*			PrePartTskTags			= NULLTAG;
	tag_t			PreParttskTag		= NULLTAG;
	tag_t			PreitemTypeTag_class2= NULLTAG;
	//API change
	//char			Pretype_class2[TCTYPE_name_size_c+1];
	char *Pretype_class2 = NULL;
	char			*dmlId				= NULL;
	char			*ReleaseStatusdml				= NULL;
	tag_t*			dml_status_list		= NULLTAG;
	char			*PrevRevSMDMLSet		= NULL;
	char			*PreTaskId		= NULL;
	char Pretask_Plant[40];

	if (!PrevRevSMDMLSet) MEM_free(PrevRevSMDMLSet);
	PrevRevSMDMLSet=(char *)MEM_alloc(2000);
	tc_strcpy(PrevRevSMDMLSet," ");
	printf("\n\n ##############Inside Prev_Rev_Checks_SMDML_EPA ##############");fflush(stdout);

	
	for (k=0;k<taskcount ;k++ )
	{					
		printf("\n\n\t\t Prev_Rev_Checks:for k_1 =:%d",k);fflush(stdout);
		EPATaskTag=EPATaskRevision[k];
		

		ITKCALL(AOM_ask_value_string(EPATaskTag,"item_id",&EPA_Task_no));
		printf("\n\n\t\t EPA_Task_no  is :%s",EPA_Task_no);	fflush(stdout);

		ITKCALL(AOM_ask_value_tags(EPATaskTag,"CMHasSolutionItem",&PartCnt,&PartTags));
		printf("\n\n\t\t EPA PartCnt:%d",PartCnt);fflush(stdout);
		if (PartCnt>0)
		{
			for(prtCnt=0;prtCnt<PartCnt;prtCnt++)
			{
				AssyTag=PartTags[prtCnt];

				RevFlag=0;
				
				ITKCALL(AOM_ask_value_string(AssyTag, "item_id",&epaPrtNo));
				printf("\n epaPrtNo %s.....\n",epaPrtNo);fflush(stdout);

				ITKCALL(AOM_ask_value_string(AssyTag, "item_revision_id",&epaPrtRev));
				printf("\n epaPrtRev %s.....\n",epaPrtRev);	fflush(stdout);

				if(QRY_find2("DriverVCQuerySM", &queryTag_Prt_Prev));
				printf("\n After IFERR_REPORT : QRY_find2 \n");fflush(stdout);

				qry_values_Prt_Prev[0] = epaPrtNo ;
				qry_values_Prt_Prev[1] = lcsToset ;
				
				if(QRY_execute_with_sort(queryTag_Prt_Prev, n_entries_Prt_Prev, qry_entries_Prt_Prev, qry_values_Prt_Prev, num_to_sort_Prt_Prev, keys_Prt_Prev, orders_Prt_Prev, &resultCount_Prt_Prev, &Rev_Prt_Prev));
				printf("\n resultCount_Prt_Prev %d \n",resultCount_Prt_Prev);fflush(stdout);
				if (resultCount_Prt_Prev>0)
				{
				
					for(ii=resultCount_Prt_Prev-1;ii>=0;ii--)
					{
					
						AssyPreTag=Rev_Prt_Prev[ii];
						
						smDmlFnd=0;
						smRlzFlg=0;

						ITKCALL(AOM_ask_value_string(AssyPreTag,"item_revision_id",&Part_rev_Id));
						ITKCALL(AOM_ask_value_string(AssyPreTag,"item_id",&Part_No_Pre));

						printf("\n Part_No_Pre %s:%s \n",Part_rev_Id,Part_No_Pre);fflush(stdout);

						if(tc_strcmp(epaPrtRev,Part_rev_Id)==0)
						{
							RevFlag = 1;
							break;
						}
						else
						{
							GRM_find_relation_type("CMHasSolutionItem",&relation_type_task);

							GRM_list_primary_objects_only(AssyPreTag,relation_type_task,&precount_task,&PrePartTskTags);
							printf("\n precount_task %d \n",precount_task);fflush(stdout);
							if(precount_task >0)
							{							
								for (Precnt=0;Precnt<precount_task ;Precnt++ )
								{
									PreParttskTag=NULLTAG;
									PreParttskTag=PrePartTskTags[Precnt];
									ITKCALL (TCTYPE_ask_object_type(PreParttskTag,&PreitemTypeTag_class2));
									ITKCALL (TCTYPE_ask_name2(PreitemTypeTag_class2,&Pretype_class2));

									printf("\t  Pretype_class2 ...%s\n", Pretype_class2);fflush(stdout);	
									
									//smRlzFlg=0;
									

									if(tc_strcmp(Pretype_class2,"T5_SMDMLTaskRevision")==0)
									{	
										ITKCALL(AOM_ask_value_string(PreParttskTag, "item_id",&PreTaskId));
										printf("\n PreTaskId %s.....\n",PreTaskId);	fflush(stdout);									

										GetPlantForDMLORTask(PreTaskId,Pretask_Plant);	
										printf("\t  Pretask_Plant after  ...%s:::: %s", Pretask_Plant,PlantName);
										
										dmlId=subString(PreTaskId,2,2);
										printf("\n dmlId:%s",dmlId);fflush(stdout);

										if(tc_strcmp(dmlId,"SM")==0 && (tc_strcmp(Pretask_Plant,PlantName)==0))
										{
											smDmlFnd++;
											stlst = 0;
											ITKCALL(WSOM_ask_release_status_list(PreParttskTag,&st_dmlcount,&dml_status_list));
											for (stlst = 0; stlst < st_dmlcount; stlst++)
											{
												AOM_ask_name(dml_status_list[stlst], &ReleaseStatusdml);
												printf("\n ReleaseStatusdml %s :::lcsToset %s\n",  ReleaseStatusdml,lcsToset);fflush(stdout);
												if(tc_strcmp(ReleaseStatusdml,lcsToset)!=0 )
												{
													
													printf("\n Previous revision of part is contanied in SMDML which is not stdsi released, carry forward previous revision changes into current revision");fflush(stdout);
													//#############Logic to carry forward previous revision changes#############//



													//##########################################################################//
												}
												else
												{
													smRlzFlg++;
												
												}
											}
										}	
									}
								}

								printf("\n in EPA smRlzFlg %d :: smDmlFnd %d",smRlzFlg,smDmlFnd);fflush(stdout);
								if((smRlzFlg==0) && (smDmlFnd>0))
								{
									printf("\n 111 smdmlErrorCnt %d" ,smdmlErrorCnt);fflush(stdout);
									 if(smdmlErrorCnt==0)
									 {
										 tc_strcat(PrevRevSMDMLSet,"\n Below Previous Revision of Part is attached to SM-DML which is not STDSI released.Please release the SM-DML.");	
										 tc_strcat(PrevRevSMDMLSet,"\n");
										 tc_strcat(PrevRevSMDMLSet,Part_No_Pre);
										 tc_strcat(PrevRevSMDMLSet,":");
										 tc_strcat(PrevRevSMDMLSet,Part_rev_Id);
										 tc_strcat(PrevRevSMDMLSet,";SM-DML Task :");
										 tc_strcat(PrevRevSMDMLSet,PreTaskId);	
										 smdmlErrorCnt++;
										 cntEPAFlag = 1;
										 printf("\n 111 PrevRevSMDMLSet %s" ,PrevRevSMDMLSet);fflush(stdout);
									 }
									 else
									 {
										 tc_strcat(PrevRevSMDMLSet,"\n");
										 tc_strcat(PrevRevSMDMLSet,Part_No_Pre);
										 tc_strcat(PrevRevSMDMLSet,":");
										 tc_strcat(PrevRevSMDMLSet,Part_rev_Id);
										 tc_strcat(PrevRevSMDMLSet,";SM-DML Task :");
										 tc_strcat(PrevRevSMDMLSet,PreTaskId);	
										 smdmlErrorCnt++;
										 cntEPAFlag = 1;
										 printf("\n 1112222 PrevRevSMDMLSet %s" ,PrevRevSMDMLSet);fflush(stdout);
									 }
								}
							}
						
						
						}
					
					
					}
				
				
				
				
				}

			
			
			
			}
		
		
		}
	}


	printf("\n PrevRevSMDMLSet in EPA Singoff:%s",PrevRevSMDMLSet);fflush(stdout);

	if(smdmlErrorCnt>0)
	{
		tc_strcat(SetStdRelErr,PrevRevSMDMLSet);	
	}


	return 0;



}

extern EPM_decision_t DLLAPI epa_signoff_checks_Func(EPM_rule_message_t msg)
{

	EPM_decision_t decision;
	tag_t		 rootTask			= NULLTAG;
	char		*CurrentTask		= NULL;
	char        *parent_name		= NULL;
	char        *epaitemid			= NULL;
	int			iNumAttch = 0;
	int			i = 0;
	tag_t		* pTagAttch;
	//API change
	//char		type_name[TCTYPE_name_size_c+1];
	char *type_name = NULL;
	const char *qry_entries[1];
	const char *qry_values[1];
	int n_tags_found=0;
	int TaskCnt=0;
	int PartCnt=0;
	int count=0;
	tag_t	*itemclass							= NULLTAG;
	tag_t	item								= NULLTAG;
	tag_t	epa_rev_tag							= NULLTAG;
	tag_t	ItemTypeTag							= NULLTAG;
	tag_t	relation_type						= NULLTAG;
	tag_t*	EPATaskRevision						= NULLTAG;
	tag_t	EPATaskRevTag						= NULLTAG;
	char	*object_type						= NULL;
	char	*SetChildRelErr						= NULL;
	char	*EpaFinInf							= NULL;
	char	*epa_plant							= NULL;
	char	*epaTaskNo							= NULL;
	char	*lcsToset							= NULL;
	//char	*lcsStdwrkng							= NULL;
	char	*PlantName							= NULL;
	tag_t*	PartTags							= NULLTAG;
	tag_t	CurrentRoleTag						= NULLTAG;
	//API change
	char *RoleName = NULL;
	char	PlantCS[40];
	char	PlantOptCS[40];
	char	PlantIA[40];
	char	PlantStore[40];
	char	UserAgency[40];
	char	RevisionRule[40];
	char	ClosureRule[40];
	char	STDDmlPlnt[40];
	char	BVR[40];
	char	APLDmlPlnt[40];
	int		status=0;
	int		errCnt=0;
	cntEPAFlag=0;
	epacnt=0;
	char	*epa_po_check						= NULL;

	printf("\n Calling epa_signoff_checks_Func .....\n");fflush(stdout);
	
	

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n epa_signoff_checks_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	if (!SetChildRelErr) MEM_free(SetChildRelErr);
	SetChildRelErr=(char *)MEM_alloc(5000);
	tc_strcpy(SetChildRelErr,"");

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&RoleName))
	printf("\n\n  RoleName : %s\n",RoleName); fflush(stdout);

	PlantName=subString(RoleName,3,4);
    printf( "PlantName:%s\n", PlantName);fflush(stdout);

	getPlantDetailsAttr_Std(RoleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency,RevisionRule,ClosureRule,BVR,APLDmlPlnt,STDDmlPlnt);//TZ1.41

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

	//*************TZ3.46*****************//	
	char AplRvwLC[40];
	char AplWrkngLC[40];
	char AplRlzd[40];
	char Stdwrknglc[40];
	char Stdrlzdlc[40];
	char PltLcs[40];
	char StdPlant[40];
	char StdRevRule[40];
	char StdCLosRule[40];
	char StdView[40];
	
	//get_CtrlVal_APLStateInf(PlantName,"","","",Stdwrknglc,Stdrlzdlc,"","","","","");//TZ1.46//Priti
	get_CtrlVal_STDStateInf(PlantName,AplRvwLC,AplWrkngLC,AplRlzd,Stdwrknglc,Stdrlzdlc,PltLcs,StdPlant,StdRevRule,StdCLosRule,StdView);//TZ1.46//Priti

	//strcpy(lcsToset,"T5_LcsStdRlzd");	
	strcpy(lcsToset,Stdrlzdlc);		
	//*****************************************//

	printf("\n STD Working LCS %s.....\n",Stdwrknglc);fflush(stdout);

	
	if(tc_strcmp(CurrentTask,"Finalize the EPA")==0)
	{
		ITKCALL( TCTYPE_find_type("T5_EPARevision", NULL, &ItemTypeTag));
		for (i=0; i < iNumAttch; i++)
		{
			tag_t		objTypeTag = NULLTAG;

			ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&epaitemid));
			printf("\n epa itemid %s.....\n",epaitemid);fflush(stdout);

			qry_entries[0] ="item_id";
			qry_values[0] = epaitemid;

			ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
			item = itemclass[0];
			if(item != NULLTAG )
			ITKCALL(ITEM_ask_latest_rev(item,&epa_rev_tag));
			
			ITKCALL( TCTYPE_ask_object_type (pTagAttch[i], &objTypeTag));
			ITKCALL( TCTYPE_ask_name2( objTypeTag, &type_name) );
			printf("\t  epa type_name ...%s\n", type_name);fflush(stdout);

			if( objTypeTag == ItemTypeTag )
			{
				ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
				ITKCALL(GRM_list_secondary_objects_only(epa_rev_tag,relation_type,&count,&EPATaskRevision));

				ITKCALL(AOM_ask_value_string( epa_rev_tag, "t5_EpaPlantA", &epa_plant));

				if(tc_strcmp(epa_plant,"CVBU PUNE")==0)
				{
					if(tc_strstr(RoleName,"STDP")!=NULL)
					{
						printf("\t SignoffP EPA of as per user location ");fflush(stdout);	
					}
					else
					{
						errCnt++;		
					}
				}
				else if(tc_strcmp(epa_plant,"DHARWAD")==0)
				{
					if(tc_strstr(RoleName,"STDD")!=NULL)
					{
						printf("\t SignoffD EPA of as per user location ");fflush(stdout);	
					}
					else
					{
						errCnt++;		
					}
				}
				else if((tc_strcmp(epa_plant,"CAR")==0) || (tc_strcmp(epa_plant,"PlantName1")==0))
				{
					if(tc_strstr(RoleName,"STDC")!=NULL)
					{
						printf("\t SignoffC EPA of as per user location ");fflush(stdout);	
					}
					else
					{
						errCnt++;		
					}
					
				}
				else if(tc_strcmp(epa_plant,"CVBU JSR")==0)
				{
					if(tc_strstr(RoleName,"STDJ")!=NULL)
					{
						printf("\t SignoffJ EPA of as per user location ");fflush(stdout);	
					}
					else
					{
						errCnt++;		
					}
				}
				else if(tc_strcmp(epa_plant,"CVBU LKO")==0)
				{
					if(tc_strstr(RoleName,"STDL")!=NULL)
					{
						printf("\t SignoffJ EPA of as per user location ");fflush(stdout);	
					}
					else
					{
						errCnt++;		
					}
				}
				//else if(tc_strcmp(epa_plant,"SMALLCAR AHD")==0)
				else if(tc_strcmp(epa_plant,"AHD")==0)// Added by prasad 
				{
					printf("\t Prasad Inside AHD Plant ");fflush(stdout);
					if(tc_strstr(RoleName,"STDA")!=NULL)
					{
						printf("\t SignoffA EPA of as per user location ");fflush(stdout);
			
					}
					else
					{
						errCnt++;		
					}
				}

				else if(tc_strcmp(epa_plant,"SANAND")==0)// Added by prasad 
				{
					printf("\t Prasad Inside SANAND Plant ");fflush(stdout);
					if(tc_strstr(RoleName,"STDS")!=NULL)
					{
						printf("\t SignoffA EPA of as per user location ");fflush(stdout);
			
					}
					else
					{
						errCnt++;		
					}
				}
				else if((tc_strcmp(epa_plant,"CVBU PNR")==0) || (tc_strcmp(epa_plant,"SMALLCAR PNR")==0))
				{
					if(tc_strstr(RoleName,"STDU")!=NULL)
					{
						printf("\t SignoffU EPA of as per user location ");fflush(stdout);	
					}
					else
					{
						errCnt++;		
					}
				}

				if(errCnt>0)
				{
					printf("\n Showing error of group & role");fflush(stdout);
					EMH_clear_errors();
					status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Please select proper Group and Role before finalizing the EPA.");
					decision = EPM_nogo;
					return ITK_errStore;
				}
				errCnt=0;

				printf("\n\n\t\t EPA to EPA Task : %d",count);fflush(stdout);
				if(count>0)
				{
					for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
					{
						EPATaskRevTag = EPATaskRevision[TaskCnt];
						ITKCALL(AOM_ask_value_string(EPATaskRevTag,"object_type",&object_type));
						printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
						if(strcmp(object_type,"T5_EPATaskRevision")==0)
						{
							ITKCALL(AOM_ask_value_string( EPATaskRevTag, "item_id", &epaTaskNo));
							
							ITKCALL(AOM_ask_value_tags(EPATaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
							printf("\n\n\t\t EPA PartCnt:%d",PartCnt);fflush(stdout);
							if (PartCnt>0)
							{
//								if(tc_strcmp(epa_plant,"CVBU PUNE")==0)
//								{
//									strcpy(lcsToset,"T5_LcsStdpRlzd");
//								}
//								else if(tc_strcmp(epa_plant,"DHARWAD")==0)
//								{
//									strcpy(lcsToset,"T5_LcsStddRlzd");
//								}
//								else if(tc_strcmp(epa_plant,"CAR")==0)
//								{
//									strcpy(lcsToset,"T5_LcsStdRlzd");
//									
//								}
//								else if(tc_strcmp(epa_plant,"CVBU JSR")==0)
//								{
//									strcpy(lcsToset,"T5_LcsStdjRlzd");
//								}
//								else if(tc_strcmp(epa_plant,"CVBU LKO")==0)
//								{
//									strcpy(lcsToset,"T5_LcsStdlRlzd");
//								}
//								else if(tc_strcmp(epa_plant,"SMALLCAR AHD")==0)
//								{
//									strcpy(lcsToset,"T5_LcsStdaRlzd");
//								}
//								else if((tc_strcmp(epa_plant,"CVBU PNR")==0) || (tc_strcmp(epa_plant,"PlantName7")==0))
//								{
//									strcpy(lcsToset,"T5_LcsStduRlzd");
//								}
//								else
//								{
//									strcpy(lcsToset,"T5_LcsStdRlzd");
//								}
								
								//added by Ritik
								printf("\n Before EPA_Prev_Part_Rev_Finalize_Checks\n");fflush(stdout);
								EPA_Prev_Part_Rev_Finalize_Checks(epaitemid,epa_rev_tag,PartCnt,PartTags,SetChildRelErr,lcsToset,PltLcs,Stdwrknglc); 						
								printf("\n After EPA_Prev_Part_Rev_Finalize_Checks Error SetChildRelErr: %s:%d\n",SetChildRelErr,cntEPAFlag);fflush(stdout);
								//End by Ritik

								EPA_Prev_Part_Rev_TwoRev_Rlzd_Checks(epaitemid,PartCnt,PartTags,SetChildRelErr,lcsToset,PlantName,APLDmlPlnt,epaTaskNo);
								printf("\n After Prev Rev Part Error SetChildRelErr: %s:%d\n",SetChildRelErr,cntEPAFlag);fflush(stdout);
								
								EPA_Part_PP_DML_Rlzd_Checks(epaTaskNo,PartCnt,PartTags,SetChildRelErr,lcsToset,PlantName,APLDmlPlnt);
								printf("\n After PP DML Rlzd Error SetChildRelErr: %s:%d\n",SetChildRelErr,cntEPAFlag);fflush(stdout);

								EPA_Child_Part_Rlzd_Checks(PartCnt,epa_plant,PartTags,SetChildRelErr,lcsToset,PlantName,RevisionRule,ClosureRule,BVR); //added by vishal
								//EPA_Child_Part_Rlzd_Checks(PartCnt,PartTags,SetChildRelErr,lcsToset,PlantName,RevisionRule,ClosureRule,BVR);
								printf("\n After Child Part Rlzd Error SetChildRelErr: %s:%d\n",SetChildRelErr,cntEPAFlag);fflush(stdout);

								// Added By Amar
								char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
								char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

								tag_t   qryTagCntrl1			= NULLTAG;
								tag_t*	list_of_WSO_cntrl_tags1 = NULLTAG;

								int     n_entryCntrl1					= 3;
								int		control_number_found_EpaCheck	= 0;

								if(QRY_find2("Control Objects...", &qryTagCntrl1));
								if (qryTagCntrl1)
								{
									printf("\n Control Object Query Found \n");fflush(stdout);
									qry_valuesCntrl1[0]="EpaCheckMandatory";
									qry_valuesCntrl1[1]="EpaCheckMandatory";
									qry_valuesCntrl1[2]="0";
									
									if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found_EpaCheck, &list_of_WSO_cntrl_tags1));
								}
									
								printf("\n Amar control_number_found_EpaCheck is : %d\n",control_number_found_EpaCheck);fflush(stdout);

								if(control_number_found_EpaCheck>0) //Kate
								{	
									if((tc_strcmp(epa_plant,"CAR")==0) || (tc_strcmp(epa_plant,"AHD")==0) || (tc_strcmp(epa_plant,"SANAND")==0))
									{	
										int icount_aplModCheck=0;
										char	**SetChildRelAPLModErr = NULL;
										int icount_ebommbom_bom=0;
										char *ecn_ReleaseType=NULL;

										char	*tempErr	=	0;
										int		iLength	=	0;
										
										ITKCALL(Check_STDModPresent(epa_rev_tag,PartCnt,"STD",ecn_ReleaseType,PartTags,&SetChildRelAPLModErr,&icount_aplModCheck));
										printf("\n Amar Check_STDModPresent icount_aplModCheck : %d",icount_aplModCheck);fflush(stdout);					

										if(icount_aplModCheck>0)
										{
											iLength	=	0;
											if (!tempErr) MEM_free(tempErr);
											i=0;
											for (i=0; i < icount_aplModCheck; i++)
											{
												tempErr	=	SetChildRelAPLModErr[i];
												iLength	=	iLength	+	tc_strlen(tempErr);
											}
											printf("Check_APLModPresent EBOM-MBOM iLength : %d",iLength);fflush(stdout);
											if (!tempErr) MEM_free(tempErr);
											tempErr	=	(char *)MEM_alloc(iLength+20);
											i=0;
											printf("\nBefore For loop");fflush(stdout);
											for (i=0; i < icount_aplModCheck; i++)
											{
												if(i==0)
													tc_strcpy(tempErr,SetChildRelAPLModErr[i]);
												else
													tc_strcat(tempErr,SetChildRelAPLModErr[i]);
											}
											printf("\n Check_APLModPresent EBOM-MBOM Printing Errors...!!!");fflush(stdout);
											printf("%s",tempErr);fflush(stdout);
											EMH_clear_errors();
											status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
											decision = EPM_nogo;
											return ITK_errStore;
										
										}
										
										Check_APLModuleQTY(epa_rev_tag,PartCnt,PartTags,&SetChildRelAPLModErr,&icount_ebommbom_bom);
										printf("\n Amar Check_APLModuleQTY icount_ebommbom : %d",icount_ebommbom_bom);fflush(stdout);

										Check_APLModuleDuplicate(epa_rev_tag,PartCnt,PartTags,&SetChildRelAPLModErr,&icount_ebommbom_bom);
										printf("\n Amar Check_APLModuleDuplicate icount_ebommbom : %d",icount_ebommbom_bom);fflush(stdout);

										Check_STDModPresentSVR(epa_rev_tag,"STD",&SetChildRelAPLModErr,&icount_ebommbom_bom);
										printf("\n Amar Check_STDModPresentSVR icount_ebommbom : %d",icount_ebommbom_bom);fflush(stdout);
										
										if(icount_ebommbom_bom>0)
										{
											iLength	=	0;
											if (!tempErr) MEM_free(tempErr);
											i=0;
											for (i=0; i < icount_ebommbom_bom; i++)
											{
												tempErr	=	SetChildRelAPLModErr[i];
												iLength	=	iLength	+	tc_strlen(tempErr);
											}
											printf("Missing/Duplication Error : %d",iLength);fflush(stdout);
											if (!tempErr) MEM_free(tempErr);
											tempErr	=	(char *)MEM_alloc(iLength+20);
											i=0;
											printf("\nBefore For loop");fflush(stdout);
											for (i=0; i < icount_ebommbom_bom; i++)
											{
												//printf("\n 111 SetChildErr %s",SetChildRelAPLModErr[i]);fflush(stdout);
												if(i==0)
													tc_strcpy(tempErr,SetChildRelAPLModErr[i]);
												else
													tc_strcat(tempErr,SetChildRelAPLModErr[i]);
											}
											printf("\n Missing/Duplication Error :..!!!");fflush(stdout);
											printf("%s",tempErr);fflush(stdout);
											EMH_clear_errors();
											status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
											decision = EPM_nogo;
											return ITK_errStore;
										
										}

									}
									
								}
								else
								{
									printf("\n Amar Else Control object is off \n");fflush(stdout);
								}
								// ended
								
							}	
						
						}	
					}

					Prev_Rev_Checks_SMDML_EPA(EPATaskRevision,count,SetChildRelErr,lcsToset,StdPlant);
					printf("\n After Child Part Rlzd Error SetChildRelErr: %s:%d\n",SetChildRelErr,cntEPAFlag);fflush(stdout);//TZ1.53

				}
				else
				{
					printf("\n NO EPA TASK FOUND.. ");fflush(stdout);
//					EMH_clear_errors();
//					if (!EpaFinInf) MEM_free(EpaFinInf);
//					EpaFinInf=(char *)MEM_alloc(5000);
//					tc_strcpy(EpaFinInf,"No EPA Task is Found for this EPA.Do you want to Finalize this EPA?");
//
//					printf("\n befor showing softcheck  %d :%s\n",status,EpaFinInf);
//
//					status=EMH_store_error_s2(EMH_severity_warning,ITK_err, "EMH_severity_warning",EpaFinInf);
//					printf("\n after showing softcheck  %d \n",status);
					//decision = EPM_nogo;
					//return EMH_severity_information;

				
				}
			
			
			}
			printf("\n cntEPAFlag. %d \n",cntEPAFlag);fflush(stdout);
			if(cntEPAFlag==1)
			{
				printf("\n Showing error for epa finalization.. %s \n",SetChildRelErr);fflush(stdout);
				EMH_clear_errors();
				status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,SetChildRelErr);
				printf("\n All Child Part is not TCM Released  %s \n",SetChildRelErr);fflush(stdout);
				decision = EPM_nogo;
				return ITK_errStore;
			}
			else
			{
				//TZ1.42--DEEPTI
				if (count>0)
				{
					ITKCALL(AOM_ask_value_string( epa_rev_tag, "t5_POCheckStatus", &epa_po_check));
					printf("\n epa_po_check.. %s \n",epa_po_check);fflush(stdout);
					if(strcmp(epa_po_check,"")==0)
					{
						EMH_clear_errors();
						status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"Please run the PO check before finalizing the EPA.\n Select the EPA ->Go to ->Manufacturing Menu->Implementaion-->PO Checks");
						decision = EPM_nogo;
						return ITK_errStore;				
					}
					else if(strcmp(epa_po_check,"POCHKFAIL")==0)
					{
						EMH_clear_errors();
						status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,"PO Check fails.Please check the PO Report attached with EPA. ");
						decision = EPM_nogo;
						return ITK_errStore;				
					}
					else if(strcmp(epa_po_check,"POCHKPASS")==0)
					{
						//decision = EPM_go;
						//return decision;			
					}
					else
					{				
						//decision = EPM_go;
						//return decision;
					}
				}
				else
				{
					printf("\n NO Task under EPA..");fflush(stdout);
				}
				
			
			}
		}
	
	}

	decision = EPM_go;
	return decision;



}

extern int DLLAPI epa_part_attach( METHOD_message_t *msg, va_list  args )
{
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	//API change
	//char   type_name[TCTYPE_name_size_c+1];
	char   *type_name = NULL;
	//API change
	//char   type_name2[TCTYPE_name_size_c+1];
	char   *type_name2 = NULL;
	char   *relation_name = NULL;
	//char   relation_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;


	tag_t  primary_object = va_arg(args, tag_t);
	tag_t  secondary_object = va_arg(args, tag_t);
	tag_t  relation_type = va_arg(args, tag_t);

	ITKCALL(TCTYPE_ask_object_type(primary_object,&objTypeTag));
	ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n     epa_part_attach primary_object  type_name :: %s\n", type_name); fflush(stdout);

//	ITKCALL(TCTYPE_ask_object_type(secondary_object,&objTypeTag2));
//	ITKCALL(TCTYPE_ask_name(objTypeTag2,type_name2));
//	printf("\n     epa_part_attach secondary_object  type_name2 :: %s\n", type_name2); fflush(stdout);

	ITKCALL(POM_get_user_id (&username));
	printf("\n\n  epa_part_attach Session login User1 : %s\n",username); fflush(stdout);
	
	if(tc_strcmp(type_name,"T5_EPATaskRevision")==0)
	{
		
		ITKCALL(TCTYPE_ask_object_type(secondary_object,&objTypeTag2));
		ITKCALL(TCTYPE_ask_name2(objTypeTag2,&type_name2));
		printf("\n     epa_part_attach secondary_object  type_name2 :: %s\n", type_name2); fflush(stdout);


		if(relation_type != NULLTAG)
		{
			ITKCALL(TCTYPE_ask_name2( relation_type, &relation_name));
		}

		if(tc_strcmp(relation_name,"CMHasSolutionItem")==0)
		{
			if(tc_strcmp(type_name2,"Design Revision")==0)
			{
				if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
				{
					//EMH_store_error_s1(EMH_severity_warning,ITK_err,"You cannot add parts from SolutionItem of the EPA Task Revision manually.");//DEEPTI TZ1.41
					//return ITK_err; //Will do in Next TZ
				}
			
			}
		
		}

	}

	return ITK_ok;

}

//muskan code of epa part delete start//
//extern int DLLAPI epa_part_delete( METHOD_message_t *msg, va_list  args  )
//{
//	
//	tag_t objTypeTag2=NULLTAG;
//	char* Pri_type_name = NULL;
//	char   *type_name = NULL;
//	tag_t object = va_arg(args, tag_t);
//	char   *type_name2 = NULL;    
//	char   *username  = NULL;
//    tag_t objTypeTag = NULLTAG;
//	tag_t primaryObjTag = NULLTAG;
//	tag_t PobjTypeTag = NULLTAG;
//	tag_t secondaryObjTag = NULLTAG;
//	tag_t SecobjTypeTag = NULLTAG;
//	char* Sec_type_name = NULL;
//	char* groupName = NULL;
//	tag_t groupTag = NULLTAG;
//
//    
//	ITKCALL(TCTYPE_ask_object_type(object, &objTypeTag));
//    ITKCALL(TCTYPE_ask_name2(objTypeTag, &type_name));
//    printf("\n  primary_object   type_name %s\n", type_name);
//
//	
//	ITKCALL(GRM_ask_primary (object,&primaryObjTag)); 
//	ITKCALL(TCTYPE_ask_object_type(primaryObjTag, &PobjTypeTag));
//    ITKCALL(TCTYPE_ask_name2(PobjTypeTag, &Pri_type_name));
//	printf("\n Primary object  Pri_type_name %s\n", Pri_type_name);
//     
//	 POM_ask_group(&groupName, &groupTag);
//	 
//     printf("\n\n  epa_part_delete groupName : %s\n",groupName); fflush(stdout);
//	ITKCALL(POM_get_user_id (&username));
//	printf("\n\n  epa_part_delete Session login User1 : %s\n",username); fflush(stdout);
//	
//	if(tc_strcmp(Pri_type_name,"T5_EPATaskRevision")==0)
//	{
//		ITKCALL(GRM_ask_secondary (object,&secondaryObjTag));
//		ITKCALL(TCTYPE_ask_object_type(secondaryObjTag, &SecobjTypeTag));
//		ITKCALL(TCTYPE_ask_name2(SecobjTypeTag, &Sec_type_name));
//		printf("\n Secondary object  Sec_type_name %s\n", Sec_type_name);
//	
//
//		if(tc_strcmp(type_name,"CMHasSolutionItem")==0)
//		{
//			if(tc_strcmp(Sec_type_name,"Design Revision")==0)
//			{
//				
//				if(tc_strcmp(groupName,"dba")==0 || tc_strcmp(groupName,"PLM_Support_Group")==0)
//				{
//					printf(" Part removal is done");
//	
//				}
//			else {
//
//				printf("\n EPA part Deletion Validation -Part Removal from epa is not allowed. Please contact non erc PLM_Support_Group");fflush(stdout);
//									EMH_clear_errors();
//									EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Part Removal from epa is not allowed. Please contact non erc PLM_Support_Group");
//									return ITK_errStore1;
//			}
//			}
//		
//		}
//
//	}
//	
//	return ITK_ok;
//
//}

//end of code epa part delete//






/*********End  Added by Deepti for EPA Sign off*******************************************/

extern EPM_decision_t DLLAPI STD_dml_VCsignoff_checks_Func(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int status;

	int		i						=	0;
	int		iNumAttch				=	0;
	int     n_entryCntrl1    		= 	3;
	int		control_number_found	=	0;
	int		CountDML				=	0;
	int		Counter					=	0;
	int		icount					=	0;
	int		iLength					=	0;
	int		iattach					=	0;

	char	*CurrentTask			=	NULL;
	char	*parent_name			=	NULL;
	char	*roleName				=	NULL;
	char	*type_name				=	NULL;
	char	*type_itemRev			=	NULL;
	char	*DMLTyp					=	NULL;
	char	*ProjectCode			=	NULL;
	char	*Release_Type			=	NULL;
	char	*cUserInfo1				=	NULL;
	char	*tempErr				=	NULL;
	char	*itemid					=	NULL;

	char	**SetChildRelErr		=	NULL;

	tag_t	rootTask				=	NULLTAG;
	tag_t	CurrentRoleTag			=	NULLTAG;
	tag_t	qryTagCntrl1			=	NULLTAG;
	tag_t	ItemTypeTag				=	NULLTAG;
	tag_t	item_rev_tag			=	NULLTAG;
	tag_t	objTypeTag				=	NULLTAG;
	tag_t	itemTypeTag_cdss		=	NULLTAG;
	tag_t	TskToDMLRel				=	NULLTAG;
	tag_t	DMLRevTagg				=	NULLTAG;
	tag_t	DMLTypeTag				=	NULLTAG;
	
	tag_t	*DMLTagg				=	NULLTAG;
	tag_t	*pTagAttch				=	NULLTAG;
	tag_t	*list_of_WSO_cntrl_tags	=	NULLTAG;

	logical	isltstdmll;

	printf("\nInside apl_dml_VCsignoff_checks_Func");fflush(stdout);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n apl_dml_VCsignoff_checks_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName));
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

	char    *qry_entryCntrl1[3]  	= 	{"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1		= 	(char **) MEM_alloc(5 * sizeof(char *));
	
	
	
	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	if(qryTagCntrl1!=NULLTAG)
	{
		//printf("\n Control Object Query Found \n");fflush(stdout);
		//qry_valuesCntrl1[0]="APLCCVRlzDuplicate";
		//qry_valuesCntrl1[1]="APLCCVRlzDuplicate";;
		//qry_valuesCntrl1[2]="0";
		
		//if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found, &list_of_WSO_cntrl_tags));
		//printf("\nNo. of control object found : %d",control_number_found);fflush(stdout);
		
		//if(control_number_found>0)
		{
			//ITKCALL(AOM_ask_value_string(list_of_WSO_cntrl_tags[0], "t5_Userinfo1",&cUserInfo1));

			if(tc_strcmp(CurrentTask,"Run BOM Check STDS")==0)
			{
				ITKCALL( TCTYPE_find_type("T5_APLTaskRevision", NULL, &ItemTypeTag));
				printf("\n iNumAttch %d.....\n",iNumAttch);fflush(stdout);

				for (iattach=0;iattach<iNumAttch ;iattach++ )
				{
					const char *qry_entries[1];
					const char *qry_values[1];

					int		n_tags_found	=	0;
					tag_t	*itemclass		=	NULLTAG;
					tag_t	item			=	NULLTAG;

					ITKCALL(AOM_ask_value_string(pTagAttch[iattach], "item_id",&itemid));
					printf("\n itemid %s.....\n",itemid);fflush(stdout);
					qry_entries[0] ="item_id";
					qry_values[0] = itemid;

					ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
					item = itemclass[0];
					if(item != NULLTAG )
					ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

					printf("\n itemid %s \n",itemid);fflush(stdout);
					ITKCALL( TCTYPE_ask_object_type (pTagAttch[iattach], &objTypeTag));
					ITKCALL( TCTYPE_ask_name2( objTypeTag, &type_name) );
					printf("\t  type_name ...%s\n", type_name);fflush(stdout);
					if( objTypeTag == ItemTypeTag )
					{
						printf("\t \n objTypeTag == ItemTypeTag \n");fflush(stdout);
						
						ITKCALL (TCTYPE_ask_object_type(item_rev_tag,&itemTypeTag_cdss));
						ITKCALL (TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));

						printf("\t  type_itemRev ...%s\n", type_itemRev);fflush(stdout);

						SetChildRelErr = (char**)MEM_alloc( 1 * sizeof *SetChildRelErr );

						if(tc_strcmp(type_itemRev,"T5_APLTaskRevision" )==0)
						{
							TskToDMLRel		= NULLTAG;
							DMLRevTagg		= NULLTAG;
			  				DMLTypeTag		= NULLTAG;
							DMLTagg			= NULLTAG;

							ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &TskToDMLRel));
							if (TskToDMLRel!=NULLTAG)
							{
								ITKCALL(GRM_list_primary_objects_only(item_rev_tag,TskToDMLRel,&CountDML,&DMLTagg));
								printf("\n\n\t\t CountDML : %d",CountDML);fflush(stdout);

								for (Counter=0;Counter<CountDML ;Counter++ )
								{
									ITKCALL(ITEM_rev_sequence_is_latest(DMLTagg[Counter],&isltstdmll));
									printf("\n\n\t\t isltstdmll : %d\n",isltstdmll);fflush(stdout);

									if(isltstdmll != true)
									{
										printf("\n\n\t\t isltstdmll is not true .....\n");fflush(stdout);
									}
									else
									{
										printf("\n\n\t\t isltstdmll is  true .....\n");fflush(stdout);
										DMLRevTagg = DMLTagg[Counter];

										ITKCALL (TCTYPE_ask_object_type(DMLRevTagg,&DMLTypeTag));
										ITKCALL (TCTYPE_ask_name2(DMLTypeTag,&DMLTyp));
										printf("\n\n\t\t isltstdmll is  true test .....\n");fflush(stdout);

										if(tc_strcmp(DMLTyp,"T5_APLDMLRevision")==0)
										{
											AOM_ask_value_string( DMLRevTagg, "t5_cprojectcode", &ProjectCode);
											printf("\n ProjectCode : %s\n",ProjectCode);fflush(stdout);

											ITKCALL(AOM_ask_value_string(DMLRevTagg,"t5_rlstype",&Release_Type));
											printf("\n\t Release_Type is :%s",Release_Type);fflush(stdout);
										}
									}
								}

								//if (tc_strcmp(Release_Type,"Veh")==0 && tc_strstr(ProjectCode,cUserInfo1)!=NULL)
								if (tc_strcmp(Release_Type,"Veh")==0)
								{
									printf("\nBefore Duplicate module check.");fflush(stdout);
									tm_chkMultipleSolveBOM_STD(item_rev_tag,&SetChildRelErr,&icount); ////Code commented due to error in workflow
									printf("\nAfter Duplicate module check");fflush(stdout); 
									
									if (icount>0)
									{
										iLength	=	0;
										if (!tempErr) MEM_free(tempErr);
										i=0;
										for (i=0; i < icount; i++)
										{
											//printf("%s",SetChildRelErr[i]);fflush(stdout);
											tempErr	=	SetChildRelErr[i];
											iLength	=	iLength	+	tc_strlen(tempErr);
										}
										printf("iLength : %d",iLength);fflush(stdout);
										if (!tempErr) MEM_free(tempErr);
										tempErr	=	(char *)MEM_alloc(iLength+20);
										i=0;
										for (i=0; i < icount; i++)
										{
											//printf("%s",SetChildRelErr[i]);fflush(stdout);
											if(i==0)
												tc_strcpy(tempErr,SetChildRelErr[i]);
											else
												tc_strcat(tempErr,SetChildRelErr[i]);
										}
										printf("\nPrinting Errors...!!!");fflush(stdout);
										printf("%s",tempErr);fflush(stdout);
										EMH_clear_errors();
										status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
										decision = EPM_nogo;
										return ITK_errStore;
									}
									if (icount==0)
									{
										printf("\nBefore Snap shot creation start...");fflush(stdout);
										createSnapShot_STD(item_rev_tag); //Code commented due to error in workflow
										printf("\nAfter Snap shot creation start...");fflush(stdout);
									}
									
								}
								else
								{
									printf("\nRelease type is not Vehicle Release or proct not found in control object.");fflush(stdout);
								}
							}
							else
							{
								printf("\nTskToDMLRel is NULLTAG.");fflush(stdout);
							}
						}
					}
				}
			}
		}
		//else
		//{
		//	printf("\nAPLCCVRlzDuplicate control object not found.");fflush(stdout);
		//}
	}
	
	decision = EPM_go;
	return decision;
}

extern EPM_decision_t DLLAPI STD_dml_CCVsignoff_checks_Func(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int status;

	int		i						=	0;
	int		iNumAttch				=	0;
	int     n_entryCntrl1    		= 	3;
	int		control_number_found	=	0;
	int		CountDML				=	0;
	int		Counter					=	0;
	int		icount					=	0;
	int		iLength					=	0;
	int		iattach					=	0;

	char	*CurrentTask			=	NULL;
	char	*parent_name			=	NULL;
	char	*roleName				=	NULL;
	char	*type_name				=	NULL;
	char	*type_itemRev			=	NULL;
	char	*DMLTyp					=	NULL;
	char	*ProjectCode			=	NULL;
	char	*Release_Type			=	NULL;
	char	*cUserInfo1				=	NULL;
	char	*tempErr				=	NULL;
	char	*itemid					=	NULL;

	char	**SetChildRelErr		=	NULL;

	tag_t	rootTask				=	NULLTAG;
	tag_t	CurrentRoleTag			=	NULLTAG;
	tag_t	qryTagCntrl1			=	NULLTAG;
	tag_t	ItemTypeTag				=	NULLTAG;
	tag_t	item_rev_tag			=	NULLTAG;
	tag_t	objTypeTag				=	NULLTAG;
	tag_t	itemTypeTag_cdss		=	NULLTAG;
	tag_t	TskToDMLRel				=	NULLTAG;
	tag_t	DMLRevTagg				=	NULLTAG;
	tag_t	DMLTypeTag				=	NULLTAG;
	
	tag_t	*DMLTagg				=	NULLTAG;
	tag_t	*pTagAttch				=	NULLTAG;
	tag_t	*list_of_WSO_cntrl_tags	=	NULLTAG;

	logical	isltstdmll;

	printf("\nInside apl_dml_CCVsignoff_checks_Func");fflush(stdout);

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\n apl_dml_CCVsignoff_checks_Func \n"); fflush(stdout);

	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCurrentTask:%s\n",CurrentTask);fflush(stdout);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName));
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

	char    *qry_entryCntrl1[3]  	= 	{"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1		= 	(char **) MEM_alloc(5 * sizeof(char *));
	
	
	
	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	if(qryTagCntrl1!=NULLTAG)
	{
		//printf("\n Control Object Query Found \n");fflush(stdout);
		//qry_valuesCntrl1[0]="APLCCVRlzDuplicate";
		//qry_valuesCntrl1[1]="APLCCVRlzDuplicate";;
		//qry_valuesCntrl1[2]="0";
		
		//if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found, &list_of_WSO_cntrl_tags));
		//printf("\nNo. of control object found : %d",control_number_found);fflush(stdout);
		
		//if(control_number_found>0)
		{
			//ITKCALL(AOM_ask_value_string(list_of_WSO_cntrl_tags[0], "t5_Userinfo1",&cUserInfo1));

			if(tc_strcmp(CurrentTask,"Check CCV STDS")==0)
			{
				ITKCALL( TCTYPE_find_type("T5_APLTaskRevision", NULL, &ItemTypeTag));
				printf("\n iNumAttch %d.....\n",iNumAttch);fflush(stdout);

				for (iattach=0;iattach<iNumAttch ;iattach++ )
				{
					const char *qry_entries[1];
					const char *qry_values[1];

					int		n_tags_found	=	0;
					tag_t	*itemclass		=	NULLTAG;
					tag_t	item			=	NULLTAG;

					ITKCALL(AOM_ask_value_string(pTagAttch[iattach], "item_id",&itemid));
					printf("\n itemid %s.....\n",itemid);fflush(stdout);
					qry_entries[0] ="item_id";
					qry_values[0] = itemid;

					ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
					item = itemclass[0];
					if(item != NULLTAG )
					ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

					printf("\n itemid %s \n",itemid);fflush(stdout);
					ITKCALL( TCTYPE_ask_object_type (pTagAttch[iattach], &objTypeTag));
					ITKCALL( TCTYPE_ask_name2( objTypeTag, &type_name) );
					printf("\t  type_name ...%s\n", type_name);fflush(stdout);
					if( objTypeTag == ItemTypeTag )
					{
						printf("\t \n objTypeTag == ItemTypeTag \n");fflush(stdout);
						
						ITKCALL (TCTYPE_ask_object_type(item_rev_tag,&itemTypeTag_cdss));
						ITKCALL (TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));

						printf("\t  type_itemRev ...%s\n", type_itemRev);fflush(stdout);

						SetChildRelErr = (char**)MEM_alloc( 1 * sizeof *SetChildRelErr );

						if(tc_strcmp(type_itemRev,"T5_APLTaskRevision" )==0)
						{
							TskToDMLRel		= NULLTAG;
							DMLRevTagg		= NULLTAG;
			  				DMLTypeTag		= NULLTAG;
							DMLTagg			= NULLTAG;

							ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &TskToDMLRel));
							if (TskToDMLRel!=NULLTAG)
							{
								ITKCALL(GRM_list_primary_objects_only(item_rev_tag,TskToDMLRel,&CountDML,&DMLTagg));
								printf("\n\n\t\t CountDML : %d",CountDML);fflush(stdout);

								for (Counter=0;Counter<CountDML ;Counter++ )
								{
									ITKCALL(ITEM_rev_sequence_is_latest(DMLTagg[Counter],&isltstdmll));
									printf("\n\n\t\t isltstdmll : %d\n",isltstdmll);fflush(stdout);

									if(isltstdmll != true)
									{
										printf("\n\n\t\t isltstdmll is not true .....\n");fflush(stdout);
									}
									else
									{
										printf("\n\n\t\t isltstdmll is  true .....\n");fflush(stdout);
										DMLRevTagg = DMLTagg[Counter];

										ITKCALL (TCTYPE_ask_object_type(DMLRevTagg,&DMLTypeTag));
										ITKCALL (TCTYPE_ask_name2(DMLTypeTag,&DMLTyp));
										printf("\n\n\t\t isltstdmll is  true test .....\n");fflush(stdout);

										if(tc_strcmp(DMLTyp,"T5_APLDMLRevision")==0)
										{
											AOM_ask_value_string( DMLRevTagg, "t5_cprojectcode", &ProjectCode);
											printf("\n ProjectCode : %s\n",ProjectCode);fflush(stdout);

											ITKCALL(AOM_ask_value_string(DMLRevTagg,"t5_rlstype",&Release_Type));
											printf("\n\t Release_Type is :%s",Release_Type);fflush(stdout);
										}
									}
								}

								//if (tc_strcmp(Release_Type,"Veh")==0 && tc_strstr(ProjectCode,cUserInfo1)!=NULL)
								if (tc_strcmp(Release_Type,"Veh")==0)
								{
									printf("\nBefore Duplicate module check.");fflush(stdout);
									//tm_chkMultipleSolveBOM(item_rev_tag,&SetChildRelErr,&icount); //called in work on DML
									printf("\nAfter Duplicate module check");fflush(stdout); 
									
//									if (icount>0)
//									{
//										iLength	=	0;
//										if (!tempErr) MEM_free(tempErr);
//										i=0;
//										for (i=0; i < icount; i++)
//										{
//											//printf("%s",SetChildRelErr[i]);fflush(stdout);
//											tempErr	=	SetChildRelErr[i];
//											iLength	=	iLength	+	tc_strlen(tempErr);
//										}
//										printf("iLength : %d",iLength);fflush(stdout);
//										if (!tempErr) MEM_free(tempErr);
//										tempErr	=	(char *)MEM_alloc(iLength+20);
//										i=0;
//										for (i=0; i < icount; i++)
//										{
//											//printf("%s",SetChildRelErr[i]);fflush(stdout);
//											if(i==0)
//												tc_strcpy(tempErr,SetChildRelErr[i]);
//											else
//												tc_strcat(tempErr,SetChildRelErr[i]);
//										}
//										printf("\nPrinting Errors...!!!");fflush(stdout);
//										printf("%s",tempErr);fflush(stdout);
//										EMH_clear_errors();
//										status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
//										decision = EPM_nogo;
//										return ITK_errStore;
//									}
								}
								else
								{
									printf("\nRelease type is not Vehicle Release or proct not found in control object.");fflush(stdout);
								}
							}
							else
							{
								printf("\nTskToDMLRel is NULLTAG.");fflush(stdout);
							}
						}
					}
				}
			}
		}
		//else
		//{
		//	printf("\nAPLCCVRlzDuplicate control object not found.");fflush(stdout);
		//}
	}
	
	decision = EPM_go;
	return decision;
}

int  tm_Is_Veh_Cond_STD(EPM_action_message_t msg)
{
	int		ifail				=	ITK_ok;
	int		count				=	0;
	int		Dml_cnt				=	0;
	int		iattach				=	0;

	char*	username			=	NULL;
	char*	CurrentTask			=	NULL;
	char*	task_result			=	NULL;
	char*	parent_name			=	NULL;
	char*	object_type			=	NULL;
	char*	DML_No				=	NULL;
	char*	DmlProj				=	NULL;
	char*	DMLtype				=	NULL;
	char*	task_No				=	NULL;

	tag_t	user_tag			=	NULLTAG;
	tag_t	root_task			=	NULLTAG;
	tag_t	objTag				=	NULLTAG;
	tag_t	DMLToTaskRel		=	NULLTAG;
	tag_t	DMLRevTag			=	NULLTAG;

	tag_t*	attachments			=	NULLTAG;
	tag_t*	Dml_objects			=	NULLTAG;

	printf("\nInside tm_Is_Veh_Cond_STD");fflush(stdout);

	ifail = POM_get_user(&username,&user_tag);
	printf("\n\t Starting for username :%s....\n",username);fflush(stdout);

	ifail = EPM_ask_root_task(msg.task,&root_task);
	printf("\n\t Root task found");fflush(stdout);

	ifail = AOM_ask_value_string(msg.task,"object_name",&CurrentTask);
	printf("\n\t CurrentTask:%s\n",CurrentTask);fflush(stdout);

	ifail = AOM_ask_value_string(msg.task,"task_result",&task_result);
	printf("\n\t task_result:%s\n",task_result);fflush(stdout);

	ifail = AOM_ask_value_string(root_task,"object_name",&parent_name);
	printf("\n\t Parent Name:%s\n",parent_name);fflush(stdout);

	ifail = EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments);
	printf("\n\n\t\t EPM_ask_attachments of :: %d\n",count); fflush(stdout);
	
	if(count > 0)
	{
		for(iattach=0;iattach<count;iattach++)
		{
			printf("\n******* INSIDE Attachments  ********\n");fflush(stdout);

			ITKCALL(AOM_ask_value_string(attachments[iattach],"object_type",&object_type));
			printf("\n object_type is :%s\n",object_type);fflush(stdout);

			ITKCALL(AOM_ask_value_string(attachments[iattach],"item_id",&task_No));
			printf("\n task_No is :%s\n",task_No);fflush(stdout);

			if (tc_strcmp(object_type,"T5_APLTaskRevision")==0)
			{
				objTag = attachments[iattach];

				ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &DMLToTaskRel));
				ITKCALL (GRM_list_primary_objects_only(objTag,DMLToTaskRel,&Dml_cnt,&Dml_objects));

				if (Dml_cnt>0)
				{
					DMLRevTag	=	Dml_objects[0];

					ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_cprojectcode",&DmlProj));
					printf("\n111DML Project code : %s",DmlProj);fflush(stdout);

					ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype));
					printf("\n Release type : %s",DMLtype);fflush(stdout);

					ITKCALL(AOM_ask_value_string(DMLRevTag,"item_id",&DML_No));
					printf("\n DML_No : %s",DML_No);fflush(stdout);

					if (tc_strstr(DML_No,"AM")!=NULL)
					{
						printf("\nAM DML found");fflush(stdout);
						ITKCALL(EPM_set_task_result(msg.task,EPM_RESULT_False));
						printf("\n EPM_RESULT_False inside : %d",ifail); fflush(stdout);
						//return ifail;
						return ITK_ok;
					}
					else
					{
						if (tc_strcmp(DMLtype,"Veh")==0)
						{
							int n_entries11 =	3;
							char *qry_entries11[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
							char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
							int resultCount11=0;
							tag_t	Cntl_obj_Qtag11	=	NULLTAG;
							tag_t *qry_cntrlobj11= NULLTAG;
							char	*cUserinfo1	=	NULLTAG;

							if(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));

							if (Cntl_obj_Qtag11!=NULLTAG)
							{
								qry_values11[0] =	"tm_is_veh_std" ;
								qry_values11[1] =	"tm_is_veh_std" ;
								qry_values11[2] =	"0" ;

								ITKCALL(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
								printf("\nNo. of control object found : %d",resultCount11);fflush(stdout);

								if (resultCount11>0)
								{
									printf("\nControl object found");fflush(stdout);
									ITKCALL(AOM_ask_value_string( qry_cntrlobj11[0], "t5_Userinfo1", &cUserinfo1));
									printf("\n cUserinfo1: %s\n",cUserinfo1);fflush(stdout);
									if (tc_strstr(cUserinfo1,DmlProj)!=NULL)
									{
										printf("\nDML project code found under control object");fflush(stdout);
										ITKCALL( EPM_set_task_result(msg.task,EPM_RESULT_True));
										printf("\n EPM_RESULT_True inside : %d",ifail); fflush(stdout);
										return ITK_ok;
									}
									else
									{
										printf("\nDML project code not found under control object");fflush(stdout);
										ITKCALL(EPM_set_task_result(msg.task,EPM_RESULT_False));
										printf("\n EPM_RESULT_False inside : %d",ifail); fflush(stdout);
										return ITK_ok;
									}
								}
								else
								{
									printf("\nNo control object found");fflush(stdout);
									ITKCALL(EPM_set_task_result(msg.task,EPM_RESULT_False));
									printf("\n EPM_RESULT_False inside : %d",ifail); fflush(stdout);
									return ITK_ok;
								}
							}
							else
							{
								printf("\nControl object query not found...");fflush(stdout);
								ITKCALL(EPM_set_task_result(msg.task,EPM_RESULT_False));
								printf("\n EPM_RESULT_False inside : %d",ifail); fflush(stdout);
								return ITK_ok;
							}
						}
						else
						{
							printf("\nDML is not Vehicle release");fflush(stdout);
							ITKCALL(EPM_set_task_result(msg.task,EPM_RESULT_False));
							printf("\n EPM_RESULT_False inside : %d",ifail); fflush(stdout);
							return ITK_ok;
						}
					}

				}
				else
				{
					printf("\nNo DML found");fflush(stdout);
					ITKCALL(EPM_set_task_result(msg.task,EPM_RESULT_False));
					printf("\n EPM_RESULT_False inside : %d",ifail); fflush(stdout);
					return ITK_ok;
				}

			}
		}
	}

	return ITK_ok;
}

// Added By Ketan
void stdstrcat(char **src,char* dest)
{
    //printf("\n Inside Function gentplstrcat\n");fflush(stdout);

    // char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
     char * desc = dest ? dest : "NA";

    //printf("\n autoresizestrcat src len==%d",strlen(*src));
    //printf("\n autoresizestrcat desc len==%d",strlen(desc));
    const size_t a = strlen(*src);
    const size_t b = strlen(desc);
    const size_t size_ab = a + b + 2;
 
     //src = MEM_realloc(src, size_ab);

    *src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));


    tc_strcat(*src , desc);
 

}

int STD_Task_Part_checked_out_Validation( tag_t DMLLcmTag ) 
{
	int part_cnt			= 0;
	int prt_c				= 0;
	int Task_flag			= 0;
	int Part_flag			= 0;

	logical	isCheckOut_Part	= 0;
	logical	isCheckOut_Task = 0;

	char*	part_num		= NULL;
	char*	Part_numbers	= NULL;
	char*	TaskNo			= NULL;

	tag_t Part_Tag			  = NULLTAG;
	tag_t part_tsk_rel		  = NULLTAG;
	tag_t *Part_objects		  = NULLTAG;

	Part_numbers = (char *) MEM_alloc(3 * sizeof(char ));
	tc_strcpy(Part_numbers ,"");
	
	printf ("\n Ketan Inside the function STD_Task_Part_checked_out_Validation \n");
	
	// Validation For Task
	ITKCALL(AOM_UIF_ask_value(DMLLcmTag,"item_id",&TaskNo));
	printf("\n TaskNo : [%s]",TaskNo);fflush(stdout);

	ITKCALL(RES_is_checked_out(DMLLcmTag,&isCheckOut_Task));
	printf ("\n isCheckOut_Task => %d \n",isCheckOut_Task);fflush(stdout);

	if ( isCheckOut_Task == 1 )
	{
		printf("\n [%s] is Checked out....",TaskNo);fflush(stdout);
		Task_flag++;
	}

	if (Task_flag > 0)
	{
		printf("\n Please Check-In Task before signoff. [%s]",TaskNo);fflush(stdout);
		
		EMH_clear_errors();
		EMH_store_error_s2(EMH_severity_error,ITK_err,"\n Please Check-In Task before signoff.\n",TaskNo);
		return 1;

	}
	else
	{
		printf ("\n-------------- Task is OK--------------------\n");fflush(stdout);
	}
	
	// Validation For Part
	ITKCALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_rel));
	printf ("\n Expanding Task to Parts relation\n");fflush(stdout);
	
	ITKCALL(GRM_list_secondary_objects_only(DMLLcmTag, part_tsk_rel, &part_cnt, &Part_objects));
	printf("\n part_cnt : [%d]\n",part_cnt);fflush(stdout);
	
	if ( part_cnt > 0 )
	{
		for ( prt_c = 0; prt_c < part_cnt ; prt_c++ )
		{
			Part_Tag = Part_objects[prt_c];
			
			ITKCALL(AOM_UIF_ask_value(Part_Tag,"item_id",&part_num));
			printf("\n part_num : [%s]",part_num);fflush(stdout);
			
			ITKCALL(RES_is_checked_out(Part_Tag,&isCheckOut_Part));

			printf ("\n isCheckOut_Part => %d \n",isCheckOut_Part);fflush(stdout);

			if ( isCheckOut_Part == 1 )
			{
				printf ("\n Test 1 \n");fflush(stdout);
				if(tc_strcmp(Part_numbers,"")!=0)
				{
					printf ("\n Test 2 \n");fflush(stdout);
					stdstrcat(&Part_numbers,part_num);
					stdstrcat(&Part_numbers,",");
				}
				else
				{
					printf ("\n Test 3 \n");fflush(stdout);
					stdstrcat(&Part_numbers,part_num);
					stdstrcat(&Part_numbers,",");
					
				}

				printf("\n [%s] is Checked out....",part_num);fflush(stdout);
				Part_flag++;
			}
		}
	}
	if ( Part_flag > 0 )
	{
		printf("\n Please Check-In all Part's before signoff. [%s]",Part_numbers);fflush(stdout);
		
		EMH_clear_errors();
		EMH_store_error_s2(EMH_severity_error,ITK_err,"\n Please Check-In all Part's before signoff.\n",Part_numbers);
		MEM_free(Part_numbers);
		return 1;

	}
	else
	{
		printf ("\n-------------- Part is OK. Part_task_checked_out_Validation = Completed--------------------\n");fflush(stdout);
		return 0;
	}
}
// Ended

// Ketan Added // TZ 1.76
extern EPM_decision_t DLLAPI STD_Checked_out_Validation(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int status;
	
	tag_t	rootTask		=	NULLTAG;
	tag_t	item_rev_tag	= NULLTAG;
	tag_t*  pTagAttch;
	
	char*	CurrentTask				= NULL;
	char*	parent_name				= NULL;
	char*	Item_id					= NULL;
	char*	itemid;

	int iNumAttch	= 0;
	int i			= 0;
	int Item_ID		= 0;
	int	STD_Part_task_checked_out_val_cnt = 0;
	
	printf("\n Ketan Inside STD_Checked_out_Validation .....\n");

	ITKCALL(EPM_ask_root_task(msg.task,&rootTask));
	
	ITKCALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\n CurrentTask: %s\n",CurrentTask);
	ITKCALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\n Parent Name: %s\n",parent_name);fflush(stdout);
	ITKCALL( EPM_ask_attachments( rootTask, EPM_target_attachment, &iNumAttch, &pTagAttch) );

	if(tc_strcmp(CurrentTask,"Review the Changes")==0)
	{
 		printf("\n Inside Review the Changes Task \n");
		
		for (i=0; i < iNumAttch; i++)
		{
			const char *qry_entries[1];
			const char *qry_values[1];

			int n_tags_found=0;
			tag_t*		itemclass	= NULLTAG;
			tag_t		item		= NULLTAG;

			ITKCALL(AOM_ask_value_string(pTagAttch[i], "item_id",&itemid));
			printf("\n Task itemid => %s\n",itemid);

			qry_entries[0] ="item_id";
			qry_values[0] = itemid;

			ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
			item = itemclass[0];
			if(item != NULLTAG )
			ITKCALL(ITEM_ask_latest_rev(item,&item_rev_tag));

		}

		tag_t   qryTagCntrlobj		= NULLTAG;
		tag_t*	list_of_cntrl_tags	= NULLTAG;

		char*	qry_entryCntrlformat[4] = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};	
		
		int controlObjfound	= 0;
		int	n_entryCntrlobj = 4;

		//
		char**	qry_Part_task_checked_out_Validation	= (char **) MEM_alloc(5 * sizeof(char *));

		if(QRY_find2("Control Objects...", &qryTagCntrlobj));

		if (qryTagCntrlobj)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_Part_task_checked_out_Validation[0]="STD";
			qry_Part_task_checked_out_Validation[1]="STD_Checked_out_Validation";
			qry_Part_task_checked_out_Validation[2]="0";
			qry_Part_task_checked_out_Validation[3]="Live";
			
			if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_Part_task_checked_out_Validation, &controlObjfound, &list_of_cntrl_tags));
		}
		else
		{
			printf("\n Control Object Query not Found  \n");fflush(stdout);
		}

		printf("\n controlObjfound for STD_Checked_out_Validation is ==> %d\n",controlObjfound);fflush(stdout);

		if(controlObjfound>0)
		{
			printf("\n Live. Inside code for checking Validation \n");fflush(stdout);

			STD_Part_task_checked_out_val_cnt = STD_Task_Part_checked_out_Validation(item_rev_tag);
			if ( STD_Part_task_checked_out_val_cnt > 0 )
			{
				printf("\n Inside decision \n");fflush(stdout);
				decision = EPM_nogo;
				return decision;
			}
			
		}
		
	}
	decision = EPM_go;
	return decision;
}
// Ended

extern int std_user_assign_register_method(int *decision, va_list args)
{
    METHOD_id_t  method1;
    METHOD_id_t  method2;
	METHOD_id_t  method;
	METHOD_id_t  method4;
    METHOD_id_t  method5;
    
    int ifail=0;
   // *decision = ALL_CUSTOMIZATIONS ;
    char   type_name[TCTYPE_name_size_c+1];
    char   type_name1[TCTYPE_name_size_c+1];
    tag_t objTag = va_arg(args, tag_t);
    tag_t objTypeTag=NULLTAG;

   if( ITK_ok == EPM_register_action_handler("tm_std_dml_assign", "", tm_std_dml_assign))
   {
		printf("\t\n Registered Action Handler std_user_assign_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler tm_std_dml_assign\n");fflush(stdout);
   }
   if( ITK_ok == EPM_register_action_handler("tm_std_task_assign", "", tm_std_task_assign))
   {
		printf("\t\n Registered Action Handler tm_std_task_assign\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler tm_std_task_assign\n");fflush(stdout);
   }
   if(ITK_ok ==  EPM_register_rule_handler ("tm_activeInWorkflow","Check Validation with ActiveInWorkflow", (EPM_rule_handler_t) tm_ChkdmlActiveinWF))
   {
		printf("\t\n Registered rule  tm_activeInWorkflow.................\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register rule Handler tm_activeInWorkflow\n");fflush(stdout);
   }
   //muskan
    if(ITK_ok ==  EPM_register_rule_handler ("tm_Taskcountvalidation","Check Validation with tm_Taskcountvalidation", (EPM_rule_handler_t) tm_Taskcountvalidation))
   {
		printf("\t\n Registered rule  tm_Taskcountvalidation.................\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register rule Handler tm_Taskcountvalidation\n");fflush(stdout);
   }
   //muskan
    if( ITK_ok == EPM_register_rule_handler("tm_tsk_dml_release_status_valid", "dml and task Release status Validation", (EPM_rule_handler_t)tm_ChkReleaseStatusValidation))
   {
		printf("\t\n Registered Action Handler tm_tsk_dml_release_status_valid\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler tm_tsk_dml_release_status_valid\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_rule_handler ("std_dml_signoff_checks_Func","This Handler is used to display message",(EPM_rule_handler_t)std_dml_signoff_checks_Func))
   {
		printf("\t\n Registered Rule Handler std_dml_signoff_checks_Func\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler std_dml_signoff_checks_Func\n");fflush(stdout);
   }
   if( ITK_ok == EPM_register_action_handler("apl_std_dml_signoff_checks_Func", "", apl_std_dml_signoff_checks_Func))
   {
		printf("\t\n Registered Action Handler apl_std_dml_signoff_checks_Func\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler apl_std_dml_signoff_checks_Func\n");fflush(stdout);
   }
   if( ITK_ok == EPM_register_action_handler("CRReleaseStatusStampOnDml", "", CRReleaseStatusStampOnDml))
   {
		printf("\t\n Registered Action Handler CRReleaseStatusStampOnDml\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler CRReleaseStatusStampOnDml\n");fflush(stdout);
   }
	if( ITK_ok == EPM_register_action_handler("std_dml_claim", "", std_dml_claim))
   {
		printf("\t\n Registered Action Handler std_dml_claim_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler std_dml_claim_register_method\n");fflush(stdout);
   }


   if( ITK_ok == EPM_register_action_handler("std_dml_release", "", std_dml_release))
   {
		printf("\t\n Registered Action Handler std_dml_release_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler std_dml_release_register_method\n");fflush(stdout);
   }

   ifail = METHOD_find_method("T5_APLTaskRevision", TC_save_msg, &method);
   if (method.id != NULL)
   {
			ifail = METHOD_add_action(method, METHOD_post_action_type, (METHOD_function_t) Save_APLTask_Msg, NULL)!=ITK_ok;
			printf("\n rrrrrrrrRegistered as Post-Action for T5_APLTaskRevision Save\n");fflush(stdout);
   }else
		{
			printf("\n Method not found!TC_save_msg\n");fflush(stdout);
		}


  if( ITK_ok == EPM_register_action_handler("pr_task_stamping", "", pr_task_stamping))
   {
		printf("\t\n Registered Action Handler pr_task_stamping\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler pr_task_stamping\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_rule_handler ("DRStatusCondition","This Handler is used to display message",(EPM_rule_handler_t)DRStatusCondition))
   {
		printf("\t\n Registered Rule Handler DRStatusCondition\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler DRStatusCondition\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("std_epa_working", "", std_epa_working))
   {
		printf("\t\n Registered Action Handler std_epa_working_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler std_epa_working_register_method\n");fflush(stdout);
   }

    if( ITK_ok == EPM_register_action_handler("std_pr_stamp_bypass", "", std_pr_stamp_bypass))		// Deepti Added TZ1.53
   {
		printf("\t\n Registered Action Handler std_pr_stamp_bypass_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler std_pr_stamp_bypass_register_method\n");fflush(stdout);
   }

   	//Added by Hemal to Check DML release type is Vehicle or not
   if( ITK_ok == EPM_register_action_handler("tm_Is_Veh_Cond_STD", "", tm_Is_Veh_Cond_STD))
   {
		printf("\t\n Registered Action Handler tm_Is_Veh_Cond_STD\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler tm_Is_Veh_Cond_STD\n");fflush(stdout);
   }

   //TZ1.55
    //Added By Hemal
    if( ITK_ok == EPM_register_rule_handler ("STD_dml_VCsignoff_checks_Func","This Handler is used to display message",(EPM_rule_handler_t)STD_dml_VCsignoff_checks_Func))
   {
		printf("\t\n Registered Rule Handler STD_dml_VCsignoff_checks_Func\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler STD_dml_VCsignoff_checks_Func\n");fflush(stdout);
   }
   //Added By Hemal
    if( ITK_ok == EPM_register_rule_handler ("STD_dml_CCVsignoff_checks_Func","This Handler is used to display message",(EPM_rule_handler_t)STD_dml_CCVsignoff_checks_Func))
   {
		printf("\t\n Registered Rule Handler STD_dml_CCVsignoff_checks_Func\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler STD_dml_CCVsignoff_checks_Func\n");fflush(stdout);
   }

    //TZ1.41
   if( ITK_ok == EPM_register_rule_handler("epa_signoff_checks_Func","This Handler is used to display message",(EPM_rule_handler_t)epa_signoff_checks_Func))
   {
		printf("\t\n Registered Rule Handler epa_signoff_checks_Func\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler epa_signoff_checks_Func\n");fflush(stdout);
   }

   if( ITK_ok == EPM_register_action_handler("std_epa_rlzd", "", std_epa_rlzd))
   {
		printf("\t\n Registered Action Handler std_epa_rlzd_register_method\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler std_epa_rlzd_register_method\n");fflush(stdout);
   }

	ifail = METHOD_find_method("CMHasSolutionItem", GRM_create_msg, &method4);
	if( ifail == ITK_ok )
	{
		printf("\n Before register method for GRM_create_msg in epa part attach \n");
		if (method4.id != NULL)
		{
			if( METHOD_add_action(method4, METHOD_pre_action_type, (METHOD_function_t) epa_part_attach, NULL)!=ITK_ok)
			printf("Registered as METHOD_pre_action_type for epa_part_attach\n");
		}
		else
		printf("Method not found!GRM_create_msg\n");
	}


	//muskan code of epa part delete//
//ifail = METHOD_find_method("ImanRelation", TC_delete_msg,&method5);
//	 if (ifail == ITK_ok)
//	    {
//		if (method5.id != NULL)
//		{
//			if( METHOD_add_action(method5, METHOD_pre_action_type, (METHOD_function_t)epa_part_delete, NULL)!=ITK_ok)
//				printf("n Register METHOD_pre_action_type for epa_part_delete n");fflush(stdout);
//		}
//		else 
	//		printf("\n TC_delete_msg...method not Found \n");fflush(stdout);
	//}
	

//muskan ap part delete code

	if( ITK_ok == EPM_register_rule_handler ("STD_Checked_out_Validation","This Handler is used to display message",(EPM_rule_handler_t)STD_Checked_out_Validation)) // Added by Ketan TZ 1.76
	{
		printf("\t\n Registered Rule Handler STD_Checked_out_Validation\n");fflush(stdout);
	}
	else
	{
		printf("\t FAILED to register Rule Handler STD_Checked_out_Validation\n");fflush(stdout);
	}


//TZ 1.80
	 if( ITK_ok == EPM_register_action_handler("std_dml_task_default_group", "", std_dml_task_default_group)) 
   {
		printf("\t\n Registered Action Handler std_dml_task_default_group\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler std_dml_task_default_group\n");fflush(stdout);
   }
   //////////////////////sonu handler//////////////////
     if( ITK_ok == EPM_register_action_handler("Reviewer_Mail_Approver", "", Reviewer_Mail_Function))
   {
		printf("\t\n Registered Action Handler Reviewer_Mail_Approver\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Action Handler Reviewer_Mail_Approver\n");fflush(stdout);
   }
   ////////////////sonu handler end////////////////////

   if( ITK_ok == EPM_register_rule_handler ("std_dml_default_group_checks_Func","This Handler is used to display message",(EPM_rule_handler_t)std_dml_default_group_checks_Func))
   {
		printf("\t\n Registered Rule Handler std_dml_default_group_checks_Func\n");fflush(stdout);
   }else
   {
		printf("\t FAILED to register Rule Handler std_dml_default_group_checks_Func\n");fflush(stdout);
   }

   //TZ 1.80 WT Check handler
	if( ITK_ok == EPM_register_rule_handler ("WTValidationsAndReleaseStatus","This Handler is used to validate WT Check and give Error message",(EPM_rule_handler_t)WTValidationsAndReleaseStatus)) 
    {
		printf("\t\n Registered Action Handler WTValidationsAndReleaseStatus\n");fflush(stdout);
    }else
    {
		printf("\t FAILED to register Action Handler WTValidationsAndReleaseStatus\n");fflush(stdout);
    }

	if( ITK_ok == EPM_register_action_handler("WTReleaseStatusStampOnDml", "", WTReleaseStatusStampOnDml)) 
    {
		printf("\t\n Registered Action Handler WTReleaseStatusStampOnDml\n");fflush(stdout);
    }else
    {
		printf("\t FAILED to register Action Handler WTReleaseStatusStampOnDml\n");fflush(stdout);
    }


    return ITK_ok;
}

int tm_PRtaskFn_Call(void *return_data)
{
	int ifail = ITK_ok;

	tag_t	TaskTag			= NULLTAG;
	tag_t	DMLTag			= NULLTAG;
	tag_t	RootTag			= NULLTAG;
	tag_t	tTask			= NULLTAG;
	tag_t*	attachments		= NULLTAG;

	char*	TasktoSubmit	= NULL;
	char*   TaskNo			= NULL;
	char*   DMLNo			= NULL;
	char*	parent_name		= NULL;
	char*	tTask_name		= NULL;
	char*	parent_name1	= NULL;
	

	int	  noAttachment	 	= 0;
			
	USERARG_get_tag_argument(&TaskTag);				// TaskTag              
	USERARG_get_tag_argument(&DMLTag);				// DMLTag               
	USERARG_get_tag_argument(&RootTag);				// RootTag          
	USERARG_get_tag_argument(&tTask);				// Current Assignment Tag
	USERARG_get_string_argument(&TasktoSubmit);		// TasktoSubmit
	
	printf("\n In side tm_PRtaskFn_Call... \n");fflush(stdout);
	
	CALLAPI(AOM_ask_value_string(TaskTag,"item_id",&TaskNo));
	CALLAPI(AOM_ask_value_string(DMLTag,"item_id",&DMLNo));

	if(AOM_ask_value_string(RootTag,"object_name",&parent_name));
	printf("\n Parent Name => %s\n",parent_name);fflush(stdout);

	if(AOM_ask_value_string(tTask,"object_name",&tTask_name));
	printf("\n tTask_name => %s\n",tTask_name);fflush(stdout);

	if(EPM_ask_attachments(RootTag,EPM_target_attachment,&noAttachment,&attachments));
	printf("\n  Target Attachment => %d\n",noAttachment);fflush(stdout);
	
	printf("\n Recieved Input argument in ITK tm_PRtaskFn_Call(): TaskNo ==> [%s] || DMLNo ==>[%s] || RootTag ==> [%s] || TasktoSubmit ==> [%s] || tTask_name ==> [%s] \n",TaskNo,DMLNo,parent_name,TasktoSubmit,tTask_name);fflush(stdout);
	
	tag_t tSubProcessTag = NULLTAG;
	tag_t newProcess = NULLTAG;
	tag_t tJob		 = NULLTAG;
	tag_t Root_task	 = NULLTAG;
	tag_t* secondary_processes_tags	 = NULLTAG;

	tag_t tSubProcess = NULLTAG;

	int attachment_types[1] = {1};
	int attachmentTypes[1] = {EPM_interprocess_task_attachment};
	int cnt=0;
	char* TaskTagRevName = NULL;

	int attachmentType[] = { EPM_target_attachment };
	
	//SubProcess

	printf("\n WF Test 1\n");fflush(stdout);
	CALLAPI(EPM_find_process_template("Partial Task Lifecycle", &tSubProcessTag));
	
	printf("\n WF Test 2\n");fflush(stdout);
	CALLAPI(AOM_ask_value_string(TaskTag,"object_string",&TaskTagRevName));
	CALLAPI(EPM_create_process_deferred_start(TaskTagRevName, "Partial Task Lifecycle", tSubProcessTag, 1, &TaskTag, attachmentType, &tSubProcess));
	
	printf("\n WF Test 3\n");fflush(stdout);
	CALLAPI(EPM_ask_job(tTask, &tJob));

	CALLAPI(EPM_attach_sub_processes(tJob, 1, &tSubProcess)); //attach sub-workflow with parent process
	printf("\n WF Test 4\n");fflush(stdout);
	
	//get the sub process root task 
	tag_t tSubRootTask = NULLTAG;
	CALLAPI(EPM_ask_root_task(tSubProcess, &tSubRootTask));
	printf("\n WF Test 4.1\n");fflush(stdout);

	int iSubTarget = EPM_interprocess_task_attachment;
	
	CALLAPI(EPM_add_attachments(tTask, 1, &tSubRootTask, &iSubTarget));  //add attachment to sub-workflow root task

	CALLAPI(EPM_trigger_action(tSubRootTask, EPM_complete_action, "sub-workflow")); // trigger the sub-workflow.
	
	printf("\n PR Task submission End... \n");fflush(stdout);
			
	return ifail;

}

extern int AllUserServiceFnPR(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
 
	int nargs = 5;
	int retValueType;
	int inputArgTypes[5] = {0};
	
	inputArgTypes[0] = USERARG_TAG_TYPE;	// TaskTag
	inputArgTypes[1] = USERARG_TAG_TYPE;	// DMLTag
	inputArgTypes[2] = USERARG_TAG_TYPE;	// RootTag
	inputArgTypes[3] = USERARG_TAG_TYPE;	// Current Assignment Tag
	inputArgTypes[4] = USERARG_STRING_TYPE; // TasktoSubmit
	
	retValueType = USERARG_STRING_TYPE ;  
	ifail=USERSERVICE_register_method("tm_PRtaskFn_Call",(USER_function_t)tm_PRtaskFn_Call,nargs,inputArgTypes,retValueType);
 
 return ifail;
 
}

extern DLLAPI int tm_std_dml_assign_register_callbacks()
{
	 CUSTOM_register_exit("tm_std_dml_assign", "USER_init_module", (CUSTOM_EXIT_ftn_t)std_user_assign_register_method);
	 CUSTOM_register_exit("tm_std_dml_assign", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllUserServiceFnPR);

     printf("\n registered function tm_std_dml_assign\n");	fflush(stdout);

	 return ( ITK_ok );
}