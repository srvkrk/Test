/user/cvprod/sourav/MBOM_MCCMAINDASHBOARD/tm_mbom_mccmaindashboard -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
