/user/cvprod/sourav/MBOM_MCC_LibAndSystemDataCompare/tm_mbom_mcc_libandsystemdatacompare -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
