/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query MBOM MCC applicable released Module and print it's properties. 
*  File Name    :   tm_mbom_mcc_lib_data_collect.c
*  Created on   :   Oct 27th, 2025
*  Executable   :   tm_mbom_mcc_lib_data_collect
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     27/10/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int TC_MBOMMCCValid_Module_Details(FILE *VRpt)
{	
	//trimwhitespace(PType);
	char *item_id_str = NULL;
	char *item_project_str = NULL;
	char *item_id_strDup = NULL;
	char *item_project_strDup = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 3;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	tag_t DesRev_tag = NULLTAG;
	int ChldCount = 0;
	tag_t *PartChildTags = NULLTAG;
	int iFail = ITK_ok;
	
	tag_t ModAddctrlquery = NULLTAG;
	int ModAddctrl_n_found = 0;
	tag_t* ModAddCntrlObjs = NULLTAG;
	//char* modinfo01Str = NULL;
	//char* modinfo02Str = NULL;
	char* modinfo03Str = NULL;
	//char* modinfo04Str = NULL;
	char* MODULE_ADDRESS = NULL;
	ITK_CALL(QRY_find2("Control Objects...",&ModAddctrlquery));
	if(ModAddctrlquery != NULLTAG)
	{
		printf("\n [Control Objects...] Found Successfully..!!\n");fflush(stdout);
		char *ModAddctrl_qry_entries[2]  = {"SYSCD","SUBSYSCD"};
		char *ModAddctrl_qry_values[2]  = {"MBOMMCCvalidAdd","MBOMMCCvalidAddSub"};
		ITK_CALL(QRY_execute(ModAddctrlquery,2, ModAddctrl_qry_entries, ModAddctrl_qry_values, &ModAddctrl_n_found, &ModAddCntrlObjs));
		printf("\n Control Objects...:ModAddctrl_n_found: [%d]",ModAddctrl_n_found);fflush(stdout);
		if(ModAddctrl_n_found>0)
		{
			//ITK_CALL(AOM_ask_value_string(ModAddCntrlObjs[0],"t5_Userinfo1",&modinfo01Str));
			//ITK_CALL(AOM_ask_value_string(ModAddCntrlObjs[0],"t5_Userinfo2",&modinfo02Str));
			  ITK_CALL(AOM_ask_value_string(ModAddCntrlObjs[0],"t5_Userinfo3",&modinfo03Str));
			//ITK_CALL(AOM_ask_value_string(ModAddCntrlObjs[0],"t5_Userinfo4",&modinfo04Str));
			//printf("\n modinfo01Str: [%s]",modinfo01Str);fflush(stdout);
			//printf("\n modinfo02Str: [%s]",modinfo02Str);fflush(stdout);
			  printf("\n modinfo03Str: [%s]",modinfo03Str);fflush(stdout);
			//printf("\n modinfo04Str: [%s]",modinfo04Str);fflush(stdout);
			MODULE_ADDRESS = (char *) MEM_alloc(2000);
			tc_strcpy(MODULE_ADDRESS,modinfo03Str);
			//tc_strcat(MODULE_ADDRESS,modinfo02Str);
			//tc_strcat(MODULE_ADDRESS,modinfo03Str);
			//tc_strcat(MODULE_ADDRESS,modinfo04Str);
		}
		printf("\n MODULE_ADDRESS: [%s]\n",MODULE_ADDRESS);fflush(stdout);
	}
	
	ITK_CALL(QRY_find2("MCC_ERC_Released_Latest_Revision",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query [MCC_ERC_Released_Latest_Revision] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[3]  = {"Item ID","Part Type","Type"};
		char *cValues[3]  = {MODULE_ADDRESS,"M","Design Revision"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf("\n Query [MCC_ERC_Released_Latest_Revision] Found..!!\n");fflush(stdout);
			for (i = 0; i < n_itemobj_found; i++)
			{
				DesRev_tag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&item_id_str));
				if(tc_strlen(item_id_str)>0)
				{
					tc_strdup(item_id_str,&item_id_strDup);
				}
				else
				{
					tc_strdup("--",&item_id_strDup);
					printf("\n Part_No Value is NULL..!!");fflush(stdout);
				}
				
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_ProjectCode",&item_project_str));
				if(tc_strlen(item_project_str)>0)
				{
					tc_strdup(item_project_str,&item_project_strDup);
				}
				else
				{
					tc_strdup("--",&item_project_strDup);
					printf("\n Part Project Code Value is NULL..!!");fflush(stdout);
				}
				
				if(tc_strlen(item_id_strDup)==14)
				{
					fprintf(VRpt,"%s^%s^\n",item_id_strDup,item_project_strDup);fflush(VRpt);
				}
				else
				{
					printf(" Part_No is Not Valid..!!\n");fflush(stdout);
				}	
			}
		}
		else
		{
			printf(" Query [MCC_ERC_Released_Latest_Revision] Not Found..!!\n");fflush(stdout);
		}
	}
	else
	{
		printf(" [MCC_ERC_Released_Latest_Revision] Query Tag Not Found..!!\n");fflush(stdout);
	}
	
	return iFail;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"mbom_mcc_libdata_collect");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".txt");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	 
    fpOutput_file = fopen(RptFile, "w");
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	
	printf("\n Function1: MBOM MCC Valid Module Details Find Start\n");fflush(stdout);
	TC_MBOMMCCValid_Module_Details(fpOutput_file);
	printf("\n Function1: MBOM MCC Valid Module Details Find Find End\n");fflush(stdout);
	fclose(fpOutput_file);
	printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout); 
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_mbom_mcc_lib_data_collect.c
* // ./linkitk -o tm_mbom_mcc_lib_data_collect tm_mbom_mcc_lib_data_collect.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_MCC_Library_Data_Collect/tm_mbom_mcc_lib_data_collect .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_MCC_Library_Data_Collect/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_MCC_Library_Data_Collect/usage.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_MCC_Library_Data_Collect/SendEmail.sh .
* // ./tm_mbom_mcc_lib_data_collect -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_mbom_mcc_lib_data_collect -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/