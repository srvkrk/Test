/user/cvprod/sourav/MBOM_MCC_Library_Data_Collect/tm_mbom_mcc_lib_data_collect -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
