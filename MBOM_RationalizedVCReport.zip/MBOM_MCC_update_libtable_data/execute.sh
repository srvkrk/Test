/user/cvprod/sourav/MBOM_MCC_update_libtable_data/tm_mbom_mcc_update_libtable_data -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i="mcc_valid_system_submodule.txt"
