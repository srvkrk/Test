/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Update MCC Library Table Data After Reading Data From Input File 
*  File Name    :   tm_mbom_mcc_update_libtable_data.c
*  Created on   :   Oct 24th, 2025
*  Usage        :   tm_mbom_mcc_update_libtable_data
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     24/10/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

char* TC_SubMod_Check_Status(char* SubModAddr, char* SubModNo, char* SubModDesc, char* SubModRev, char* SubModSeq, char* SubModPlat, char* SubModProjCode, char* SubModArDr, char* CrDate, char* RlzdDate, char* puncs, char* lkncs, char* jsrcs, char* utkcs, char* dwdcs)
{
	//trimwhitespace(SubModAddr);
	//trimwhitespace(SubModNo);
	tag_t tSubItemobj = NULLTAG;
	int n_subentries = 1;
	int n_subitemobj_found = 0;
	tag_t* tsubitemobj_results = NULLTAG;
	char *SubMod_Chk_Stat = NULL;
	tag_t tsubmodnolib_rev = NULLTAG;
	tag_t ttablerow_rev = NULLTAG;
	int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
	char *Tbl_SubModNo = NULL;
	
	ITK_CALL(QRY_find2("MCC_MBOM_Module_Address_Query",&tSubItemobj));
    if(tSubItemobj != NULLTAG)
	{
		printf("\n Query [MCC_MBOM_Module_Address_Query] Tag Found Successfully..!!\n");fflush(stdout);
		char *cSubEntries[1]  = {"ID"};
		char *cSubValues[1]  = {SubModAddr};
		//char *cValues[1]  = {"A1A01"};
	    ITK_CALL(QRY_execute(tSubItemobj, n_subentries, cSubEntries, cSubValues, &n_subitemobj_found, &tsubitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",n_subitemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_subitemobj_found > 0)
		{
			printf("\n MCC MBOM SubModule Address Revision Exist So Continue For Table Data Updation..!!\n");fflush(stdout);
			tsubmodnolib_rev = tsubitemobj_results[0];
			ITK_CALL(AOM_ask_table_rows(tsubmodnolib_rev,"t5_MBOMSubModTbl", &n_valid_rows,&valid_rowsTag));
			printf("\n No of Table Row: [%d]  | For MBOM SubModule Address:  [%s]\n", n_valid_rows, SubModAddr);fflush(stdout);
			if(n_valid_rows>0)
			{
				for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
				{
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_submoduleno", &Tbl_SubModNo));	
					printf("\n Table SubModule No: [%s]",Tbl_SubModNo);fflush(stdout);
					if(Tbl_SubModNo!=NULL)trimwhitespace(Tbl_SubModNo);
					if(tc_strcmp(SubModNo,Tbl_SubModNo)==0)
					{
						printf("\n Input SubModule No And Table SubModule No Matched..!!\n");fflush(stdout);
						tc_strdup("YES",&SubMod_Chk_Stat);
						printf("\n Update Start..!!\n");fflush(stdout);
						ttablerow_rev = valid_rowsTag[iValCnt];
						ITK_CALL(AOM_lock(ttablerow_rev));
						ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_submoduleno",SubModNo));
						ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_rev",SubModRev));
						ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_seq",SubModSeq));
						ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_desc",SubModDesc));
						//ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_productline",SubModProd_StrDup));
						ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_platform",SubModPlat));
						ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_projectcode",SubModProjCode));
						ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_drarstatus",SubModArDr));
						//ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_maxdrarstatus",SubModMaxStatus_StrDup));
						//ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_vehlink",SubModVLink_StrDup));
						//ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_linkvehcount",SubModVCount_StrDup));
						//ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_linkplatformcount",SubModVPlat_StrDup));
						ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_creationdate",CrDate));
						ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_releasedate",RlzdDate));
						ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_MBOMTblRowInfo1",puncs));
						ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_MBOMTblRowInfo2",lkncs));
						ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_MBOMTblRowInfo3",jsrcs));
						ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_MBOMTblRowInfo4",utkcs));
						ITK_CALL(AOM_set_value_string(valid_rowsTag[iValCnt],"t5_MBOMTblRowInfo5",dwdcs));
						ITK_CALL(AOM_save_with_extensions(valid_rowsTag[iValCnt]));
						ITK_CALL(AOM_unlock(ttablerow_rev));
						printf("\n Update End..!!\n");fflush(stdout);
					    goto jump;
					}
					else
					{
						printf("\n Input SubModule No And Table SubModule Not Matched..!!\n");fflush(stdout);
					} 
				}
			}
			else
			{
				printf("\n No Table Row Found For Input SubModule Address: [%s], SubModAddr_StrDup\n");fflush(stdout);
				tc_strdup("NO",&SubMod_Chk_Stat);
			}
		}
		else
		{
			printf("\n SubModule Address Revision Not Found..!!\n");fflush(stdout);
			tc_strdup("NO",&SubMod_Chk_Stat);
		}
	}
	else
	{
		printf("\n Query [MCC_MBOM_Module_Address_Query] Tag Not Found..!!\n");fflush(stdout);
		tc_strdup("NO",&SubMod_Chk_Stat);
	}
	if(tc_strlen(SubMod_Chk_Stat)>0)
	{
		printf("\n SubMod_Chk_Stat Status Already Found..!!\n");fflush(stdout);
	}
	else
	{
		tc_strdup("NO",&SubMod_Chk_Stat);
	}
	
	jump:
	      printf("\n Input SubModule No And Table SubModule No Matched..!!\n");fflush(stdout);
		  
	return SubMod_Chk_Stat;
}

char* TC_ModAddr_Check_Status(char* ModAddr)
{
	//trimwhitespace(ModAddr);
	tag_t tDesItemobj = NULLTAG;
	int n_nrentries = 1;
	int n_nritemobj_found = 0;
	tag_t* tdesitemobj_results = NULLTAG;
	char *Mod_Chk_Stat = NULL;
	
	ITK_CALL(QRY_find2("MCC_MBOM_Module_Address_Query",&tDesItemobj));
    if(tDesItemobj != NULLTAG)
	{
		printf("\n Query [MCC_MBOM_Module_Address_Query] Tag Found Successfully..!!\n");fflush(stdout);
		char *cNREntries[1]  = {"ID"};
		char *cNRValues[1]  = {ModAddr};
		//char *cValues[1]  = {"A1A01"};
	    ITK_CALL(QRY_execute(tDesItemobj, n_nrentries, cNREntries, cNRValues, &n_nritemobj_found, &tdesitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",n_nritemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_nritemobj_found > 0)
		{
			printf(" MBOM SubModule Address Found..!!\n");fflush(stdout);
			tc_strdup("YES",&Mod_Chk_Stat);
		}
		else
		{
			tc_strdup("NO",&Mod_Chk_Stat);
		}
	}
	else
	{
		printf(" Query [MCC_MBOM_Module_Address_Query] Tag Not Found..!!\n");fflush(stdout);
		tc_strdup("YES",&Mod_Chk_Stat);
	}
	return Mod_Chk_Stat;
}

int ITK_user_main(int argc,char* argv[])
{
	char *message;
	char *loggedInUser = NULL;
	char *inp_file_str = NULL;
	char *inp_file_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	char *item_aggrgrp_str = NULL;
	char *item_aggrgrp_strDup = NULL;
	char *item_aggr_str = NULL;
	char *item_aggr_strDup = NULL;
	char *item_modgrp_str = NULL;
	char *item_modgrp_strDup = NULL;
	char *item_mod_str = NULL;
	char *item_mod_strDup = NULL;
	char *item_modaddr_str = NULL;
	char *item_modaddr_strDup = NULL;
	char *item_id_str   = NULL;
	char *item_id_strDup  = NULL;
	char *item_desc_str = NULL;
	char *item_desc_strDup = NULL;
	char *item_rev_str    = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str    = NULL;
	char *item_seq_strDup = NULL;
	char *item_plat_str = NULL;
	char *item_plat_strDup = NULL;
	char *item_projcode_str = NULL;
	char *item_projcode_strDup = NULL;
	char *item_ardr_str = NULL;
	char *item_ardr_strDup = NULL;
	char *item_prttype_str = NULL;
	char *item_prttype_strDup = NULL;
	char *item_type_str = NULL;
	char *item_type_strDup = NULL;
	char *item_createdt_str = NULL;
	char *item_createdt_strDup = NULL;
	char *item_releasedt_str = NULL;
	char *item_releasedt_strDup = NULL;
	char *item_curdt_str = NULL;
	char *item_curdt_strDup = NULL;
	char *ModAddrChkStat = NULL;
	char* item_aggrgrp_str1 = NULL;
	char* item_aggrgrp_str2 = NULL;
	char* item_aggr_str1 = NULL;
	char* item_aggr_str2 = NULL;
	char* item_modgrp_str1 = NULL;
	char* item_modgrp_str2 = NULL;
	char* item_mod_str1 = NULL;
	char* item_mod_str2 = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tsubmodlib_rev = NULLTAG;
	char str[10];
	int num = 1;
	char *SubModChkStat = NULL;
	char* item_pun_cs_str = NULL;
	char* item_pun_cs_strDup = NULL;
	char* item_lkn_cs_str = NULL;
	char* item_lkn_cs_strDup = NULL;
	char* item_jsr_cs_str = NULL;
	char* item_jsr_cs_strDup = NULL;
	char* item_utk_cs_str = NULL;
	char* item_utk_cs_strDup = NULL;
	char* item_dwd_cs_str = NULL;
	char* item_dwd_cs_strDup = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
    inp_file_str = ITK_ask_cli_argument("-i=");
	trimwhitespace(inp_file_str);
	if(inp_file_str!=NULL)tc_strdup(inp_file_str,&inp_file_strDup);
	printf(" [1]: Input File_Name(inp_file_strDup): [%s]\n",inp_file_strDup);
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

    fpPart_List = fopen(inp_file_strDup, "r"); 
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{	
			item_aggrgrp_str=strtok(Buffer,"^");
			item_aggr_str=strtok(NULL,"^");
			item_modgrp_str=strtok(NULL,"^");
			item_mod_str=strtok(NULL,"^");
			item_modaddr_str=strtok(NULL,"^");
			item_id_str=strtok(NULL,"^");
			item_desc_str=strtok(NULL,"^");
			item_rev_str=strtok(NULL,"^");
			item_seq_str=strtok(NULL,"^");
			item_plat_str=strtok(NULL,"^");
			item_projcode_str=strtok(NULL,"^");
			item_ardr_str=strtok(NULL,"^");
			item_prttype_str=strtok(NULL,"^");
			item_type_str=strtok(NULL,"^");
			item_createdt_str=strtok(NULL,"^");
			item_releasedt_str=strtok(NULL,"^");
			item_curdt_str=strtok(NULL,"^");
			item_pun_cs_str=strtok(NULL,"^");
			item_lkn_cs_str=strtok(NULL,"^");
			item_jsr_cs_str=strtok(NULL,"^");
			item_utk_cs_str=strtok(NULL,"^");
			item_dwd_cs_str=strtok(NULL,"^");
			
			
			item_aggrgrp_str1=strtok(item_aggrgrp_str,"-");
			item_aggrgrp_str2=strtok(NULL, "");
			item_aggr_str1=strtok(item_aggr_str,"-");
			item_aggr_str2=strtok(NULL, "");
			item_modgrp_str1=strtok(item_modgrp_str,"-");
			item_modgrp_str2=strtok(NULL, "");
			item_mod_str1=strtok(item_mod_str,"-");
			item_mod_str2=strtok(NULL, "");
			
			if(item_aggrgrp_str2!=NULL)tc_strdup(item_aggrgrp_str2,&item_aggrgrp_strDup);
			if(item_aggr_str2!=NULL)tc_strdup(item_aggr_str2,&item_aggr_strDup);
			if(item_modgrp_str2!=NULL)tc_strdup(item_modgrp_str2,&item_modgrp_strDup);
			if(item_mod_str2!=NULL)tc_strdup(item_mod_str2,&item_mod_strDup);
			if(item_modaddr_str!=NULL)tc_strdup(item_modaddr_str,&item_modaddr_strDup);
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_desc_str!=NULL)tc_strdup(item_desc_str,&item_desc_strDup);
			if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
			if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
			if(item_plat_str!=NULL)tc_strdup(item_plat_str,&item_plat_strDup);
			if(item_projcode_str!=NULL)tc_strdup(item_projcode_str,&item_projcode_strDup);
			if(item_ardr_str!=NULL)tc_strdup(item_ardr_str,&item_ardr_strDup);
			if(item_prttype_str!=NULL)tc_strdup(item_prttype_str,&item_prttype_strDup);
			if(item_type_str!=NULL)tc_strdup(item_type_str,&item_type_strDup);
			if(item_createdt_str!=NULL)tc_strdup(item_createdt_str,&item_createdt_strDup);
			if(item_releasedt_str!=NULL)tc_strdup(item_releasedt_str,&item_releasedt_strDup);
			if(item_curdt_str!=NULL)tc_strdup(item_curdt_str,&item_curdt_strDup);
			if(item_pun_cs_str!=NULL)tc_strdup(item_pun_cs_str,&item_pun_cs_strDup);
			if(item_lkn_cs_str!=NULL)tc_strdup(item_lkn_cs_str,&item_lkn_cs_strDup);
			if(item_jsr_cs_str!=NULL)tc_strdup(item_jsr_cs_str,&item_jsr_cs_strDup);
			if(item_utk_cs_str!=NULL)tc_strdup(item_utk_cs_str,&item_utk_cs_strDup);
			if(item_dwd_cs_str!=NULL)tc_strdup(item_dwd_cs_str,&item_dwd_cs_strDup);
			
			printf("\n Line Details..!!");fflush(stdout);
			printf("\n Aggregate Group: [%s]\n",item_aggrgrp_strDup);fflush(stdout);
			printf("\n Aggregate: [%s]\n",item_aggr_strDup);fflush(stdout);
			printf("\n Module Group: [%s]\n",item_modgrp_strDup);fflush(stdout);
			printf("\n Module: [%s]\n",item_mod_strDup);fflush(stdout);
			printf("\n Module Address: [%s]\n",item_modaddr_strDup);fflush(stdout);
			printf("\n SubModule: [%s]\n",item_id_strDup);fflush(stdout);
			printf("\n Description: [%s]\n",item_desc_strDup);fflush(stdout);
			printf("\n Revision: [%s]\n",item_rev_strDup);fflush(stdout);
			printf("\n Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
			printf("\n Platform: [%s]\n",item_plat_strDup);fflush(stdout);
			printf("\n Project Code: [%s]\n",item_projcode_strDup);fflush(stdout);
			printf("\n AR/DR Status: [%s]\n",item_ardr_strDup);fflush(stdout);
			printf("\n Part Type: [%s]\n",item_prttype_strDup);fflush(stdout);
			printf("\n Item Type: [%s]\n",item_type_strDup);fflush(stdout);
			printf("\n Creation Date: [%s]\n",item_createdt_strDup);fflush(stdout);
			printf("\n Released Date: [%s]\n",item_releasedt_strDup);fflush(stdout);
			printf("\n Current Date: [%s]\n",item_curdt_strDup);fflush(stdout);
			printf("\n PUNE CS: [%s]\n",item_pun_cs_strDup);fflush(stdout);
			printf("\n LKN CS: [%s]\n",item_lkn_cs_strDup);fflush(stdout);
			printf("\n JSR CS: [%s]\n",item_jsr_cs_strDup);fflush(stdout);
			printf("\n UTK CS: [%s]\n",item_utk_cs_strDup);fflush(stdout);
			printf("\n DWD CS: [%s]\n",item_dwd_cs_strDup);fflush(stdout);
			printf("\n Line Details..!!");fflush(stdout);
			
			if((tc_strcmp(item_modaddr_strDup,"NA")!=0) && (tc_strcmp(item_modaddr_strDup," ")!=0) && (tc_strlen(item_modaddr_strDup)==5))
			{
				printf("\n Valid Module Address Found..!!");fflush(stdout);
				printf("\n Function1: SubModule Address in MCC Library Find Start");fflush(stdout);
				ModAddrChkStat = TC_ModAddr_Check_Status(item_modaddr_strDup);
				printf("\n Function1: SubModule Address in MCC Library Find End\n");fflush(stdout);
				if(tc_strcmp(ModAddrChkStat,"NO")==0)
				{
				   printf("\n !!!!!!!!! Module Address Not Present in Library !!!!!!!!!\n");fflush(stdout);
				}
				else
				{
					printf("\n Function2: SubModule No in MBOM MCC Library Find Start");fflush(stdout);
					SubModChkStat = TC_SubMod_Check_Status(item_modaddr_strDup,item_id_strDup,item_desc_strDup,item_rev_strDup,item_seq_strDup,item_plat_strDup,item_projcode_strDup,item_ardr_strDup,item_createdt_strDup,item_releasedt_strDup,item_pun_cs_strDup,item_lkn_cs_strDup,item_jsr_cs_strDup,item_utk_cs_strDup,item_dwd_cs_strDup);
					printf("\n Function2: SubModule No in MBOM MCC Library Find End\n");fflush(stdout);
					if(tc_strcmp(SubModChkStat,"YES")==0)
				    {
						printf("\n Table Data Updated..!!");fflush(stdout);		
					}
					else
					{
						printf("\n Table Data Insert Start..!!");fflush(stdout);
						ITK_CALL(QRY_find2("MCC_MBOM_Module_Address_Query",&tItemobj));
						if(tItemobj != NULLTAG)
						{
							printf("Query[MCC_MBOM_Module_Address_Query] Found Successfully..!!\n");fflush(stdout);
							char *cEntries[1]  = {"ID"};
							char *cValues[1]  = {item_modaddr_strDup};
							//char *cValues[1]  = {"A1A01"};
							ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
							printf("\n -----------------------------------------------\n");fflush(stdout);
							printf("\n No of Objects[MCC_MBOM_Module_Address_Query] Found: [%d]\n",n_itemobj_found);fflush(stdout);
							printf("\n -----------------------------------------------\n");fflush(stdout);
							if(n_itemobj_found > 0)
							{
								printf(" MBOM SubModule Address Revision Exist So, Continue For Table Data Append..!!\n");fflush(stdout);
								tsubmodlib_rev = titemobj_results[0];
								int row_new_index = 0;
								tag_t* table_rows_tag = NULLTAG;
								int property_index = 0;
								ITK_CALL(AOM_lock(tsubmodlib_rev));
								ITK_CALL(AOM_append_table_rows(tsubmodlib_rev, "t5_MBOMSubModTbl",1, &row_new_index, &table_rows_tag));
								//tostring(str, num);
								ITK_CALL(AOM_lock(table_rows_tag[0]));
								//ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_srno",str));
								ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_submoduleno",item_id_strDup));
								ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_rev",item_rev_strDup));
								ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_seq",item_seq_strDup));
								ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_desc",item_desc_strDup));
								//ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_productline",SubModProd_StrDup));
								ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_platform",item_plat_strDup));
								ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_projectcode",item_projcode_strDup));
								ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_drarstatus",item_ardr_strDup));
								//ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_maxdrarstatus",SubModMaxARDR_StrDup));
								//ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_vehlink",SubModVLink_StrDup));
								//ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_linkvehcount",SubModVCount_StrDup));
								//ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_linkplatformcount",SubModVPlat_StrDup));
								ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_creationdate",item_createdt_strDup));
								ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_releasedate",item_releasedt_strDup));
								ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_MBOMTblRowInfo1",item_pun_cs_strDup));
								ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_MBOMTblRowInfo2",item_lkn_cs_strDup));
								ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_MBOMTblRowInfo3",item_jsr_cs_strDup));
								ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_MBOMTblRowInfo4",item_utk_cs_strDup));
								ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_MBOMTblRowInfo5",item_dwd_cs_strDup));
								ITK_CALL(AOM_save_without_extensions(table_rows_tag[0]));
								ITK_CALL(AOM_unlock(table_rows_tag[0]));
								ITK_CALL(AOM_refresh(table_rows_tag[0],TRUE));			
								ITK_CALL(AOM_save_without_extensions(tsubmodlib_rev));
								ITK_CALL(AOM_unlock(tsubmodlib_rev));
								ITK_CALL(AOM_refresh(tsubmodlib_rev,TRUE));		
							}
							else
							{
							   printf("\n SubModule Library Not Found..!!\n");fflush(stdout);
							}					
						}
						else
						{
							printf(" Query[SubModuleLibraryDetails] Tag Not Found..!!");fflush(stdout);
						}
						if(titemobj_results)
						{
						   MEM_free(titemobj_results);
						}
						printf("\n Table Data Insert End..!!");fflush(stdout);
					}
				}
			}
			else
			{
				printf("\n Module Address Not Valid..!!");fflush(stdout);
			}
		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_mbom_mcc_update_libtable_data.c
* // ./linkitk -o tm_mbom_mcc_update_libtable_data tm_mbom_mcc_update_libtable_data.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_MCC_update_libtable_data/tm_mbom_mcc_update_libtable_data .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_MCC_update_libtable_data/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_MCC_update_libtable_data/usage.txt .
* // ./tm_mbom_mcc_update_libtable_data -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -i="mcc_valid_system_submodule.txt"
* // ./tm_mbom_mcc_update_libtable_data -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i="mcc_valid_system_submodule.txt"
*
***************************************************************************/