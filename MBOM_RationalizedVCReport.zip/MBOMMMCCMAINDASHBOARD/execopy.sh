scp infodba03@172.27.128.199:/user/infodba03/sourav/MCCMAINDASHBOARD/tm_mccmaindashboard .
