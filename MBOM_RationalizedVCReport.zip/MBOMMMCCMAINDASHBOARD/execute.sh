/user/cvprod/sourav/MBOMMMCCMAINDASHBOARD/tm_mbom_mccmaindashboard -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
