/user/cvprod/sourav/MBOM_MCC_new_moduleaddress_create/tm_mbom_mcc_new_moduleaddress_create -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i="mcc_valid_system_submodule.txt"
