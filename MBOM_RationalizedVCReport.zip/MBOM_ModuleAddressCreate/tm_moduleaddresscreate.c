/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Create New Module Address After Reading Data From Input File 
*  File Name    :   tm_moduleaddresscreate.c
*  Created on   :   Aug 27th, 2025
*  Usage        :   tm_moduleaddresscreate
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     27/08/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

int TC_ModAddrMod_Rel_Create(char *Module_Str, char *SubModule_StrDup)
{
	//trimwhitespace(Module_Str);
	//trimwhitespace(SubModule_StrDup);
	char *Module_StrDup = NULL;
	Module_StrDup = (char *) malloc(100*sizeof(char));
	int iFail = ITK_ok;
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tSubModuleqryobj = NULLTAG;
	int n_submoduleentries = 1;
	int n_submoduleitemobj_found = 0;
	tag_t* tsubmoduleitemobj_results = NULLTAG;
	tag_t tmod_rev = NULLTAG;
	tag_t tsubmodule_rev = NULLTAG;
	tag_t relation_foraward_type = NULLTAG;
	tag_t relation_backward_type = NULLTAG;
	tag_t relation_forward_found = NULLTAG;
	tag_t relation_backward_found = NULLTAG;
	tag_t relation_back_new = NULLTAG;
	tag_t relation_for_new = NULLTAG;
	
	if((tc_strcmp(Module_Str,"DASHBOARD MOUNTED,DRIVER INFO SYS-HMI")==0) || (tc_strcmp(Module_Str,"DASHBOARD MOUNTED DRIVER INFO SYS-HMI")==0))
	{
		tc_strcpy(Module_StrDup,"DASHBOARD MOUNTED DRIVER INFO SYS");
	}
	else
	{
		printf("\n Module Modification Not Required..!!\n");fflush(stdout);
		tc_strcpy(Module_StrDup,Module_Str);
	}
	ITK_CALL(QRY_find2("MCC_MBOM_Module_Query",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("Query[MCC_MBOM_Module_Query] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {Module_StrDup};
		//char *cValues[1]  = {"CONNECTIVITY"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[MBOM Module Revision] Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf(" [MBOM Module] Revision Exist So Continue For Relation Creation with MBOM Module Address..!!\n");fflush(stdout);
			tmod_rev = titemobj_results[0];
			printf("\n ~~~~~~~~ R E L A T I O N   C R E A T I O N    S T A R T ~~~~~~~~\n");fflush(stdout); 
			if(tmod_rev != NULLTAG)
			{
				ITK_CALL(QRY_find2("MCC_MBOM_Module_Address_Query",&tSubModuleqryobj));
				if(tSubModuleqryobj != NULLTAG)
				{
					printf("Query[MCC_MBOM_Module_Address_Query] Found Successfully..!!\n");fflush(stdout);
					char *cSubModuleEntries[1]  = {"ID"};
					char *cSubModuleValues[1]  = {SubModule_StrDup};
					//char *cAggrValues[1]  = {"G3A05"};
					ITK_CALL(QRY_execute(tSubModuleqryobj, n_submoduleentries, cSubModuleEntries, cSubModuleValues, &n_submoduleitemobj_found, &tsubmoduleitemobj_results));
					printf("\n -----------------------------------------------\n");fflush(stdout);
					printf("\n No of Objects[MBOM Module Address] Found: [%d]\n",n_submoduleitemobj_found);fflush(stdout);
					printf("\n -----------------------------------------------\n");fflush(stdout);
					if(n_submoduleitemobj_found > 0)
					{
						tsubmodule_rev = tsubmoduleitemobj_results[0];
						ITK_CALL(GRM_find_relation_type("T5_MBOMModToAddRel", &relation_foraward_type)); //Module To Module Address Relation
						ITK_CALL(GRM_find_relation(tmod_rev, tsubmodule_rev, relation_foraward_type ,&relation_forward_found));
						if(relation_forward_found)
						{
							printf("\n Forward Relation Already Exist with Module and Module Address Revision \n");fflush(stdout);
						}
						else
						{
							ITK_CALL(GRM_create_relation(tmod_rev, tsubmodule_rev, relation_foraward_type, NULLTAG, &relation_for_new));
							ITK_CALL(GRM_save_relation(relation_for_new));
							printf("\n Module and Module Address Revision Relation Created..!!");fflush(stdout);
						}
					}
					else
					{
						printf(" MBOM Module Address Details Not Found..!!\n");fflush(stdout);
					}								
				}
				else
				{
				  printf(" Query Tag [MCC_MBOM_Module_Address_Query] NULL..!!\n");fflush(stdout);
				}		
			}
			else
			{
				printf(" MBOM Module Revision Input Tag NULL..!!\n");fflush(stdout);
			}
			printf("\n ~~~~~~~~ R E L A T I O N  C R E A T I O N   E N D ~~~~~~~~\n");fflush(stdout); 
		}
		else
		{
		   printf(" MBOM Module Not Found..!!");fflush(stdout);
		}					
	}
	else
	{
		printf(" Query[MCC_MBOM_Module_Query] Tag Not Found..!!");fflush(stdout);
	}
	if(titemobj_results)
	{
	   MEM_free(titemobj_results);
	} 
	if(tsubmoduleitemobj_results)
	{
	   MEM_free(tsubmoduleitemobj_results);
	}
	
	return iFail;
}
	
int TC_ModAddr_Create(char *AggrGrp, char *Aggr, char *ModGrp, char *ModDesc, char *ModAddress)
{
	//trimwhitespace(AggrGrp);
	//trimwhitespace(Aggr);
	//trimwhitespace(ModGrp);
	//trimwhitespace(ModDesc);
	//trimwhitespace(ModAddress);
	int iFail = ITK_ok;
	tag_t SubModuleLibRevType = NULLTAG;
	tag_t SubModuleLibRevCreInput = NULLTAG;
	
	printf("\n #------------------------------------#\n");fflush(stdout);
	printf("\n Aggregate Group: [%s]\n",AggrGrp);fflush(stdout);
	printf("\n Aggregate: [%s]\n",Aggr);fflush(stdout);
	printf("\n Module Group: [%s]\n",ModGrp);fflush(stdout);
	printf("\n Module: [%s]\n",ModDesc);fflush(stdout);
	printf("\n Module Address: [%s]\n",ModAddress);fflush(stdout);
	printf("\n #------------------------------------#\n");fflush(stdout);
	
	ITK_CALL(TCTYPE_find_type("T5_MBOMLibAddRevision", NULL, &SubModuleLibRevType));
	if(SubModuleLibRevType != NULLTAG)
	{
		tag_t SubModuleLibType = NULLTAG;
		ITK_CALL(TCTYPE_construct_create_input(SubModuleLibRevType, &SubModuleLibRevCreInput));
		if(SubModuleLibRevCreInput != NULLTAG)
		{
			ITK_CALL(AOM_set_value_string(SubModuleLibRevCreInput, "item_revision_id", "A;1"));
			ITK_CALL(AOM_set_value_int(SubModuleLibRevCreInput, "sequence_id", 1)); 
			ITK_CALL(AOM_set_value_string(SubModuleLibRevCreInput, "object_desc", ModDesc));
			//ITK_CALL(AOM_set_value_string(SubModuleLibRevCreInput, "t5_MBOMAgrGrpName", AggrGrp));
			//ITK_CALL(AOM_set_value_string(SubModuleLibRevCreInput, "t5_MBOMAggName", Aggr));
			//ITK_CALL(AOM_set_value_string(SubModuleLibRevCreInput, "t5_MBOMModName", ModGrp));
			//ITK_CALL(AOM_set_value_string(SubModuleLibRevCreInput, "t5_MBOMModAddDesc", ModDesc));
			//ITK_CALL(AOM_set_value_string(SubModuleLibRevCreInput, "t5_MBOMModAdd", ModAddress));
			
			ITK_CALL(TCTYPE_find_type("T5_MBOMLibAdd", NULL, &SubModuleLibType));    
			if(SubModuleLibType != NULLTAG)
			{
				tag_t SubModuleLibCreInput  = NULLTAG;
				tag_t SubModuleTag = NULLTAG;
				ITK_CALL(TCTYPE_construct_create_input(SubModuleLibType, &SubModuleLibCreInput));
				
				ITK_CALL(AOM_set_value_string(SubModuleLibCreInput, "object_name", ModAddress));
				ITK_CALL(AOM_set_value_string(SubModuleLibCreInput, "item_id", ModAddress));
				
				ITK_CALL(TCTYPE_create_object(SubModuleLibCreInput, &SubModuleTag));
				if(SubModuleTag != NULLTAG)
				{
					tag_t latestSubModuleRevTag = NULLTAG;
					printf("\n SubModule Library Created successfully..!!\n");fflush(stdout);
					ITK_CALL(AOM_save_with_extensions(SubModuleTag));
					ITK_CALL(AOM_unlock(SubModuleTag));		
					ITK_CALL(AOM_refresh(SubModuleTag,1));
					
					ITK_CALL(ITEM_ask_latest_rev(SubModuleTag, &latestSubModuleRevTag));
					if(latestSubModuleRevTag != NULLTAG)
					{
						ITK_CALL(AOM_lock(latestSubModuleRevTag));
						ITK_CALL(AOM_set_value_string(latestSubModuleRevTag, "item_revision_id", "A;1"));
						ITK_CALL(AOM_set_value_int(latestSubModuleRevTag, "sequence_id", 1)); 
						ITK_CALL(AOM_set_value_string(latestSubModuleRevTag, "object_desc", ModDesc));
						ITK_CALL(AOM_set_value_string(latestSubModuleRevTag, "t5_MBOMAgrGrpName", AggrGrp));
						ITK_CALL(AOM_set_value_string(latestSubModuleRevTag, "t5_MBOMAggName", Aggr));
						ITK_CALL(AOM_set_value_string(latestSubModuleRevTag, "t5_MBOMModName", ModGrp));
						ITK_CALL(AOM_set_value_string(latestSubModuleRevTag, "t5_MBOMModAddDesc", ModDesc));
                        ITK_CALL(AOM_set_value_string(latestSubModuleRevTag, "t5_MBOMModAdd", ModAddress));						
						
						ITK_CALL(AOM_save_with_extensions(latestSubModuleRevTag));
						ITK_CALL(AOM_unlock(latestSubModuleRevTag));
						ITK_CALL(AOM_refresh(latestSubModuleRevTag,1));
					}
				}
				else
				{
					printf("\n SubModuleLibCreInput Tag is NULLTAG..!!\n");fflush(stdout);
				}
			}
			else
			{
				printf("\n SubModuleLibType Tag is NULLTAG..!!\n");fflush(stdout);
			}
		}
		else
		{
			printf("\n SubModuleLibRevCreInput Tag is NULLTAG..!!\n");fflush(stdout);
		}
	}
	else
	{
		printf("\n SubModuleLibRevType Tag is NULLTAG..!!\n");fflush(stdout);
	}
	
	return iFail;
}

char* TC_ModAddr_Check_Status(char* ModAddr)
{
	trimwhitespace(ModAddr);
	tag_t tDesItemobj = NULLTAG;
	int n_nrentries = 1;
	int n_nritemobj_found = 0;
	tag_t* tdesitemobj_results = NULLTAG;
	char *Mod_Chk_Stat = NULL;
	
	ITK_CALL(QRY_find2("MCC_MBOM_Module_Address_Query",&tDesItemobj));
    if(tDesItemobj != NULLTAG)
	{
		printf("\n Query [MCC_MBOM_Module_Address_Query] Tag Found Successfully..!!\n");fflush(stdout);
		char *cNREntries[1]  = {"ID"};
		char *cNRValues[1]  = {ModAddr};
		//char *cValues[1]  = {"A1A01"};
	    ITK_CALL(QRY_execute(tDesItemobj, n_nrentries, cNREntries, cNRValues, &n_nritemobj_found, &tdesitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",n_nritemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_nritemobj_found > 0)
		{
			printf(" SubModule Address Found..!!\n");fflush(stdout);
			tc_strdup("YES",&Mod_Chk_Stat);
		}
		else
		{
			tc_strdup("NO",&Mod_Chk_Stat);
		}
	}
	else
	{
		printf(" Query [MCC_MBOM_Module_Address_Query] Tag Not Found..!!\n");fflush(stdout);
		tc_strdup("YES",&Mod_Chk_Stat);
	}
	return Mod_Chk_Stat;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *inp_file_str = NULL;
	char *inp_file_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	char *item_aggrgrp_str = NULL;
	char *item_aggrgrp_strDup = NULL;
	char *item_aggr_str = NULL;
	char *item_aggr_strDup = NULL;
	char *item_modgrp_str = NULL;
	char *item_modgrp_strDup = NULL;
	char *item_mod_str = NULL;
	char *item_mod_strDup = NULL;
	char *item_modaddr_str = NULL;
	char *item_modaddr_strDup = NULL;
	char *ModAddrChkStat = NULL;
	char* item_aggrgrp_str1 = NULL;
	char* item_aggrgrp_str2 = NULL;
	char* item_aggr_str1 = NULL;
	char* item_aggr_str2 = NULL;
	char* item_modgrp_str1 = NULL;
	char* item_modgrp_str2 = NULL;
	char* item_mod_str1 = NULL;
	char* item_mod_str2 = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
    inp_file_str = ITK_ask_cli_argument("-i=");
	trimwhitespace(inp_file_str);
	if(inp_file_str!=NULL)tc_strdup(inp_file_str,&inp_file_strDup);
	printf(" [1]: Input File_Name(inp_file_strDup): [%s]\n",inp_file_strDup);
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

    fpPart_List = fopen(inp_file_strDup, "r");
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{	
			item_aggrgrp_str=strtok(Buffer,"^");
			item_aggr_str=strtok(NULL,"^");
			item_modgrp_str=strtok(NULL,"^");
			item_mod_str=strtok(NULL,"^");
			item_modaddr_str=strtok(NULL,"^");
			
			item_aggrgrp_str1=strtok(item_aggrgrp_str,"-");
			item_aggrgrp_str2=strtok(NULL, "");
			item_aggr_str1=strtok(item_aggr_str,"-");
			item_aggr_str2=strtok(NULL, "");
			item_modgrp_str1=strtok(item_modgrp_str,"-");
			item_modgrp_str2=strtok(NULL, "");
			item_mod_str1=strtok(item_mod_str,"-");
			item_mod_str2=strtok(NULL, "");
			
			if(item_aggrgrp_str2!=NULL)tc_strdup(item_aggrgrp_str2,&item_aggrgrp_strDup);
			if(item_aggr_str2!=NULL)tc_strdup(item_aggr_str2,&item_aggr_strDup);
			if(item_modgrp_str2!=NULL)tc_strdup(item_modgrp_str2,&item_modgrp_strDup);
			if(item_mod_str2!=NULL)tc_strdup(item_mod_str2,&item_mod_strDup);
			if(item_modaddr_str!=NULL)tc_strdup(item_modaddr_str,&item_modaddr_strDup);
			
			printf("\n Line Details..!!");fflush(stdout);
			printf("\n Aggregate Group: [%s]\n",item_aggrgrp_strDup);fflush(stdout);
			printf("\n Aggregate: [%s]\n",item_aggr_strDup);fflush(stdout);
			printf("\n Module Group: [%s]\n",item_modgrp_strDup);fflush(stdout);
			printf("\n Module: [%s]\n",item_mod_strDup);fflush(stdout);
			printf("\n Module Address: [%s]\n",item_modaddr_strDup);fflush(stdout);
			printf("\n Line Details..!!");fflush(stdout);
			
			if((tc_strcmp(item_modaddr_strDup,"NA")!=0) && (tc_strcmp(item_modaddr_strDup," ")!=0) && (tc_strlen(item_modaddr_strDup)==5))
			{
				printf("\n Valid Module Address Found..!!");fflush(stdout);
				printf("\n Function1: SubModule Address in MBOM MCC Library Find Start");fflush(stdout);
				ModAddrChkStat = TC_ModAddr_Check_Status(item_modaddr_strDup);
				printf("\n Function1: SubModule Address in MBOM MCC Library Find End\n");fflush(stdout);
				if(tc_strcmp(ModAddrChkStat,"NO")==0)
				{
				   printf("\n Function2: Module Address Creation Start\n");fflush(stdout);
				   TC_ModAddr_Create(item_aggrgrp_strDup,item_aggr_strDup,item_modgrp_strDup,item_mod_strDup,item_modaddr_strDup);
				   printf("\n Function2: Module Address Creation End\n");fflush(stdout);
				   printf("\n Function3: Module Address To Module Relation Creation Start\n");fflush(stdout);
				   TC_ModAddrMod_Rel_Create(item_modgrp_strDup,item_modaddr_strDup);
				   printf("\n Function3: Module Address To Module Relation Creation End\n");fflush(stdout);
				}
				else
				{
				   printf("\n Module Address Already Present..!!");fflush(stdout);
				}
			}
			else
			{
				printf("\n Module Address Not Valid..!!");fflush(stdout);
			}
		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_mcc_new_moduleaddress_create.c
* // ./linkitk -o tm_mcc_new_moduleaddress_create tm_mcc_new_moduleaddress_create.o
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/MCC_new_moduleaddress_create/tm_mcc_new_moduleaddress_create .
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/MCC_new_moduleaddress_create/exepatch.sh .
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/MCC_new_moduleaddress_create/Input.csv .
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/MCC_new_moduleaddress_create/usage.txt .
* // ./tm_mcc_new_moduleaddress_create -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_mcc_new_moduleaddress_create -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/
