/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   MCC MBOM Module Address Property Update After Reading Data From Input File 
*  File Name    :   tm_mbommoduleaddresspropupdate.c
*  Created on   :   Oct 23rd, 2025
*  Usage        :   tm_mbommoduleaddresspropupdate
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     23/10/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

int TC_ModAddr_Prop_Update(char* ModAddr, char* PropName, char* PropVal)
{
	tag_t tDesItemobj = NULLTAG;
	int n_nrentries = 1;
	int n_nritemobj_found = 0;
	tag_t* tdesitemobj_results = NULLTAG;
	int iFail = ITK_ok;
	int k = 0;
	tag_t addrrev = NULLTAG;
	
	ITK_CALL(QRY_find2("MCC_MBOM_Module_Address_Query",&tDesItemobj));
    if(tDesItemobj != NULLTAG)
	{
		printf("\n Query [MCC_MBOM_Module_Address_Query] Tag Found Successfully..!!\n");fflush(stdout);
		char *cNREntries[1]  = {"ID"};
		char *cNRValues[1]  = {ModAddr};
		//char *cValues[1]  = {"A1A01"};
	    ITK_CALL(QRY_execute(tDesItemobj, n_nrentries, cNREntries, cNRValues, &n_nritemobj_found, &tdesitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",n_nritemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_nritemobj_found > 0)
		{
			printf(" SubModule Address Found..!!\n");fflush(stdout);
			for(k = 0; k < n_nritemobj_found; k++)
			{
				addrrev = tdesitemobj_results[k];
				ITK_CALL(AOM_lock(addrrev));
				ITK_CALL(AOM_set_value_string(addrrev,PropName,PropVal));
			    ITK_CALL(AOM_save_without_extensions(addrrev));
				ITK_CALL(AOM_unlock(addrrev));
			}
		}
		else
		{
			printf(" SubModule Address Not Found..!!\n");fflush(stdout);
		}
	}
	else
	{
		printf(" Query [MCC_MBOM_Module_Address_Query] Tag Not Found..!!\n");fflush(stdout);
	}
	
	return iFail;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *inp_file_str = NULL;
	char *inp_file_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	char *item_modaddr_str = NULL;
	char *item_modaddr_strDup = NULL;
	char *item_propname_str = NULL;
	char *item_propname_strDup = NULL;
	char *item_propvalue_str = NULL;
	char *item_propvalue_strDup = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
    inp_file_str = ITK_ask_cli_argument("-i=");
	trimwhitespace(inp_file_str);
	if(inp_file_str!=NULL)tc_strdup(inp_file_str,&inp_file_strDup);
	printf(" [1]: Input File_Name(inp_file_strDup): [%s]\n",inp_file_strDup);
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

    fpPart_List = fopen(inp_file_strDup, "r");
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{	
			item_modaddr_str=strtok(Buffer,"^");
			item_propname_str=strtok(NULL,"^");
			item_propvalue_str=strtok(NULL,"^");

			if(item_modaddr_str!=NULL)tc_strdup(item_modaddr_str,&item_modaddr_strDup);
			if(item_propname_str!=NULL)tc_strdup(item_propname_str,&item_propname_strDup);
			if(item_propvalue_str!=NULL)tc_strdup(item_propvalue_str,&item_propvalue_strDup);
			
			printf("\n Line Details..!!");fflush(stdout);
			printf("\n Module Address: [%s]\n",item_modaddr_strDup);fflush(stdout);
			printf("\n Property Name: [%s]\n",item_propname_strDup);fflush(stdout);
			printf("\n Property Value: [%s]\n",item_propvalue_strDup);fflush(stdout);
			printf("\n Line Details..!!");fflush(stdout);
			
			if((tc_strcmp(item_modaddr_strDup,"NA")!=0) && (tc_strcmp(item_modaddr_strDup," ")!=0) && (tc_strlen(item_modaddr_strDup)==5))
			{
				printf("\n Function1: SubModule Address Property Update Start");fflush(stdout);
				TC_ModAddr_Prop_Update(item_modaddr_strDup,item_propname_strDup,item_propvalue_strDup);
				printf("\n Function1: SubModule Address Property Update End\n");fflush(stdout);
			}
			else
			{
				printf("\n Module Address Not Valid..!!");fflush(stdout);
			}
		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_mbommoduleaddresspropupdate.c
* // ./linkitk -o tm_mbommoduleaddresspropupdate tm_mbommoduleaddresspropupdate.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_ModuleAddressPropUpdate/tm_mbommoduleaddresspropupdate .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_ModuleAddressPropUpdate/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_ModuleAddressPropUpdate/usage.txt .
* // ./tm_mbommoduleaddresspropupdate -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_mbommoduleaddresspropupdate -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/
