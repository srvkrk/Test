/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Part Applicability Matrix Report
*  File Name    :   tm_partappmatrpt.c
*  Created on   :   December 26th, 2025
*  Usage        :   tm_partappmatrpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     26/12/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

FILE *Report = NULL;
int ctr = 0;
void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *inp_modadd_str = NULL;
	char *inp_modadd_strDup = NULL;
	char *inp_loginid_str = NULL;
	char *inp_loginid_strDup = NULL;
	char *inp_email_str = NULL;
	char *inp_email_strDup = NULL;
	char *SCRRptFile = (char *) malloc(100*sizeof(char));
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	inp_modadd_str = ITK_ask_cli_argument("-PartList=");
	inp_loginid_str = ITK_ask_cli_argument("-User=");
	inp_email_str = ITK_ask_cli_argument("-Email=");
	
	trimwhitespace(inp_modadd_str);
	trimwhitespace(inp_loginid_str);
	trimwhitespace(inp_email_str);
	if(inp_modadd_str!=NULL)tc_strdup(inp_modadd_str,&inp_modadd_strDup);
	if(inp_loginid_str!=NULL)tc_strdup(inp_loginid_str,&inp_loginid_strDup);
	if(inp_email_str!=NULL)tc_strdup(inp_email_str,&inp_email_strDup);
	
	printf(" [1]: Input Part List(inp_modadd_str): [%s]\n",inp_modadd_strDup);
	printf(" [2]: Input User Login ID(inp_loginid_strDup): [%s]\n",inp_loginid_strDup);
	printf(" [3]: Input User Email(inp_email_strDup): [%s]\n",inp_email_strDup);
	
	char GenDate[100] = "";
	char STDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	strftime(STDate,100,"%d %b, %Y (%A) %H:%M:%S %p",&when);
	printf(" Stylesheet TimeStamp: [%s]\n", STDate);fflush(stdout);
	
	printf("\n Generating XML Report File Name..!!");fflush(stdout);
	tc_strcpy(SCRRptFile,"/tmp/");
	tc_strcat(SCRRptFile,"PartAppMatReport");
	tc_strcat(SCRRptFile,"_");
	tc_strcat(SCRRptFile,GenDate);
	tc_strcat(SCRRptFile,".xml");
	//Report = fopen("/tmp/PartAppMatReport.xml","w");
	printf("\n Generated XML Report File Name: [%s]", SCRRptFile);fflush(stdout);
	
	Report = fopen(SCRRptFile,"w");
	if(Report == NULL)
	{
		printf("ERROR: Unable To Open XML File..!!\n");
		return -1;
	}
	else
	{
		printf("XML File Opened Successfully..!!\n");
	}
	write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
	write2xml(Report,"<MCCSCRReport>\n");
	write2xml(Report,"<DataRefreshDate>\n");
	write2xml(Report,"<LastDate>"); write2xml(Report,STDate); write2xml(Report,"</LastDate>\n");
	write2xml(Report,"</DataRefreshDate>\n");
	write2xml(Report,"<DataSheet1>\n");
	write2xml(Report,"<Input_ModAddr>"); if(tc_strlen(inp_modadd_strDup)>0) write2xml(Report,inp_modadd_strDup); else write2xml(Report,"NA"); write2xml(Report,"</Input_ModAddr>\n");
	write2xml(Report,"<Input_UserID>"); if(tc_strlen(inp_loginid_strDup)>0) write2xml(Report,inp_loginid_strDup); else write2xml(Report,"NA"); write2xml(Report,"</Input_UserID>\n");
	write2xml(Report,"<Input_EmaiID>"); if(tc_strlen(inp_email_strDup)>0) write2xml(Report,inp_email_strDup); else write2xml(Report,"NA"); write2xml(Report,"</Input_EmaiID>\n");
	write2xml(Report,"</DataSheet1>\n");	
    write2xml(Report,"</MCCSCRReport>\n");
    fclose(Report);
	
	printf("Exe Calling Shell Start..!!\n");fflush(stdout);
	char* ExecuteShellCommandLine = NULL;
	ExecuteShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
	tc_strcpy(ExecuteShellCommandLine,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MCCModuleAppMatrix/generatePartAppMatReport_ALL_STEPS_V1.sh");
	tc_strcat(ExecuteShellCommandLine," ");
	tc_strcat(ExecuteShellCommandLine,inp_modadd_strDup);
	tc_strcat(ExecuteShellCommandLine," ");
	tc_strcat(ExecuteShellCommandLine,inp_loginid_strDup);
	tc_strcat(ExecuteShellCommandLine," ");
	tc_strcat(ExecuteShellCommandLine,inp_email_strDup);
	system(ExecuteShellCommandLine);
	printf("Exe Calling Shell End..!!\n");fflush(stdout);
	
	printf("Current File To Original File Move Start..!!\n");fflush(stdout);
	char* ShellCommandLine = NULL;
	ShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
	tc_strcpy(ShellCommandLine,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MCCModuleAppMatrix/RemoveProcessFiles.sh");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,SCRRptFile);
	system(ShellCommandLine);
	printf("Current File To Original File Move End..!!\n");fflush(stdout);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_partappmatrpt.c
* // ./linkitk -o tm_partappmatrpt tm_partappmatrpt.o
* // scp uaprodtrl@172.22.97.18:/user/cvprod/sourav/MBOM_MCC_Module_Applicability_Matrix_Report/tm_partappmatrpt .
* // scp uaprodtrl@172.22.97.18:/user/cvprod/sourav/MBOM_MCC_Module_Applicability_Matrix_Report/exepatch.sh .
* // scp uaprodtrl@172.22.97.18:/user/cvprod/sourav/MBOM_MCC_Module_Applicability_Matrix_Report/usage.txt .
* // scp uaprodtrl@172.22.97.18:/user/cvprod/sourav/MBOM_MCC_Module_Applicability_Matrix_Report/SendEmail.sh .
* // ./tm_partappmatrpt -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -PartList="54881025R_A_1,54881525R_NR_1" -User="souravk.ttl" -Email="souravk.ttl@tatamotors.com"
* // ./tm_partappmatrpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -PartList="54881025R_A_1,54881525R_NR_1" -User="souravk.ttl" -Email="souravk.ttl@tatamotors.com"
*
***************************************************************************/
