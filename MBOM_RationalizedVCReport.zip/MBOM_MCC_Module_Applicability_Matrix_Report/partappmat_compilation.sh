./compile tm_partappmatrpt.c
./linkitk -o tm_partappmatrpt tm_partappmatrpt.o
chmod 777 tm_partappmatrpt*
