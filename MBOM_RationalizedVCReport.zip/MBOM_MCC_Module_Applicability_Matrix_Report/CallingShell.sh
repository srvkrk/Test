######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : DECEMBER-2025
#
#######################################################################################

. /user/uaprodtrl/.bash_profile

echo -e "\nIn Calling Shell Argument Print Started...."

echo "PartList: -----> "$1

echo "User: -----> "$2

echo "Email: -----> "$3

echo -e "\nIn Calling Shell Argument Print Ended...."

echo -e "\nRedirection(SSH:PLMPAPP2C7[172.22.97.18]) Part Applicability Execution Shell Started...."
ssh uaprodtrl@172.22.97.18 -n "sh /user/uaprodtrl/Sourav/ReportBuilderPartAppRpt/ExecuteShell.sh $1 $2 $3"
echo -e "\nRedirection(SSH:PLMPAPP2C7[172.22.97.18]) Part Applicability Execution Shell Ended...."

