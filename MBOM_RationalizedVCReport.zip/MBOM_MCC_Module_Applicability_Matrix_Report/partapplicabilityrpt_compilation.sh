./compile tm_PartApplicability_Rpt.c
./linkitk -o tm_PartApplicability_Rpt tm_PartApplicability_Rpt.o
chmod 777 tm_PartApplicability_Rpt*
