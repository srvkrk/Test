/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Generate Full MBOM MCC Library Details Report 
*  File Name    :   tm_mbom_mcc_library_details_rpt.c
*  Created on   :   Nov 19th, 2025
*  Usage        :   tm_mbom_mcc_library_details_rpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     19/11/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <math.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

FILE *Report = NULL;
int ctr = 0;
void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* MonthAbbreviation (char* MonthName)
{
	char *ResponseMonth = (char *) malloc(400*sizeof(char));
	printf("\n Input Month Name in String: --------> [%s]\n", MonthName);fflush(stdout);
	if(tc_strcmp(MonthName,"Jan")==0)
	{
		tc_strcpy(ResponseMonth,"01");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Feb")==0)
	{
		tc_strcpy(ResponseMonth,"02");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Mar")==0)
	{
		tc_strcpy(ResponseMonth,"03");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Apr")==0)
	{
		tc_strcpy(ResponseMonth,"04");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"May")==0)
	{
		tc_strcpy(ResponseMonth,"05");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Jun")==0)
	{
		tc_strcpy(ResponseMonth,"06");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Jul")==0)
	{
		tc_strcpy(ResponseMonth,"07");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Aug")==0)
	{
		tc_strcpy(ResponseMonth,"08");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Sep")==0)
	{
		tc_strcpy(ResponseMonth,"09");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Oct")==0)
	{
		tc_strcpy(ResponseMonth,"10");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Nov")==0)
	{
		tc_strcpy(ResponseMonth,"11");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else if(tc_strcmp(MonthName,"Dec")==0)
	{
		tc_strcpy(ResponseMonth,"12");
	    printf("\nIn Function - Month Count:  --------> [%s]", ResponseMonth);fflush(stdout);
	}
	else
	{
		printf("Invalid Number");
	}
	  
	return ResponseMonth;
}

char* TM_SubModAgeing (char* InputDt)
{
	char* FormatDate = (char *) malloc(400*sizeof(char));
	char* RespMonth = NULL;
	char* InpYear = NULL;
	char* InpMonth = NULL;
	char* InpRemainDay = NULL;
	char* InpSeperate = NULL;
	char* InpHour = NULL;
	char* InpMin = NULL;
	char* InpSec = NULL;
	char* InpRemainMinHour = NULL;
	char* InpDay = NULL;
	char* CurDay = NULL;
	char* CurMonth = NULL;
	char* CurYear = NULL;
	char* InpYearNew = (char *) malloc(30*sizeof(char));
	
	InpDay=strtok(InputDt,"-");
	InpMonth=strtok(NULL,"-");
	InpYear=strtok(NULL,"-");
	//tc_strcpy(InpYearNew,"20");
	//tc_strcat(InpYearNew,InpYear);
	tc_strcpy(InpYearNew,InpYear);
	//tc_strdup(InpYear,&InpYearNew);
	printf("\n Input Month: [%s]\n", InpMonth);fflush(stdout);
	RespMonth = MonthAbbreviation(InpMonth);
	printf("\n Input Day: [%s]\n", InpDay);fflush(stdout);
	printf("\n Input Month(MonthAbbreviation): [%s]\n", RespMonth);fflush(stdout);
	printf("\n Input Year: [%s]\n", InpYearNew);fflush(stdout);
	
	char CurDt[100] = "";
	time_t 	loc;
	struct 	tm when;
	time(&loc);
	when = *localtime(&loc);
	strftime(CurDt,100,"%d-%m-%Y",&when);
	printf(" Current Date: [%s]\n", CurDt);fflush(stdout);
	CurDay=strtok(CurDt,"-");
	CurMonth=strtok(NULL,"-");
	CurYear=strtok(NULL,"-");
	printf("\n Current Day: [%s]\n", CurDay);fflush(stdout);
	printf("\n Current Month: [%s]\n", CurMonth);fflush(stdout);
	printf("\n Current Year: [%s]\n", CurYear);fflush(stdout);
	
	int InpDayFinal = atoi(InpDay);
	int InpMonthFinal = atoi(RespMonth);
	int InpYearFinal = atoi(InpYearNew);
	int CurDayFinal = atoi(CurDay);
	int CurMonthFinal = atoi(CurMonth);
	int CurYearFinal = atoi(CurYear);
	
	struct tm tm1 = { 0 };
    struct tm tm2 = { 0 };

    /* date 1: 2024-12-11 */
    tm1.tm_year = CurYearFinal - 1900;
    tm1.tm_mon = CurMonthFinal - 1;
    tm1.tm_mday = CurDayFinal;
    tm1.tm_hour = tm1.tm_min = tm1.tm_sec = 0;
    tm1.tm_isdst = -1;

    /* date 2: 1990-10-02 */
    tm2.tm_year = InpYearFinal - 1900;
    tm2.tm_mon = InpMonthFinal - 1;
    tm2.tm_mday = InpDayFinal;
    tm2.tm_hour = tm2.tm_min = tm2.tm_sec = 0;
    tm2.tm_isdst = -1;

    time_t t1 = mktime(&tm1);
    time_t t2 = mktime(&tm2);

    double dt = difftime(t1, t2);
    int days = round(dt / 86400);

    printf("\n Excluding Current Day Difference: [%d] days\n", days);fflush(stdout);
	int difference = days + 1;
	printf("\n Including Current Day Difference: [%d] days\n", difference);fflush(stdout);
	
	char FormatDateStr[100];
	tostring(FormatDateStr, difference);
	
	tc_strcpy(FormatDate,FormatDateStr);
    printf("\n Formatted Difference Days: [%s]\n", FormatDate);fflush(stdout);
	  
	return FormatDate;
}

int TC_SubModuleDetails(FILE* DetRpt)
{
	int iFail = ITK_ok;
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	int j = 0;
	int k = 0;
	int l = 0;
    tag_t AggrGrpRev_tag = NULLTAG;
	tag_t AggrGrpToAggrRel = NULLTAG;
	int sec_countaggr = 0;
	tag_t* sec_aggrobjects = NULLTAG;
	tag_t AggrRev_tag = NULLTAG;
	tag_t AggrToModRel = NULLTAG;
	int sec_countmod = 0;
	tag_t* sec_modobjects = NULLTAG;
	tag_t ModRev_tag = NULLTAG;
	tag_t ModToSubModRel = NULLTAG;
	int sec_countsubmod = 0;
	tag_t* sec_submodobjects = NULLTAG;
	tag_t SubModRev_tag = NULLTAG;
	int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
	int iValCnt = 0;
	tag_t ttablerow_rev = NULLTAG;
	
	printf("\n Finding Query[MCC_MBOM_Aggregate_Group_Query]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("MCC_MBOM_Aggregate_Group_Query",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query [MCC_MBOM_Aggregate_Group_Query Tag] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {"*"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		printf("\n Total SubModule Library Aggregate Group Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		
		if(n_itemobj_found > 0)
		{
			for(i = 0; i < n_itemobj_found; i++)
			{
				char* aggrgrp_no = NULL;
	            char* aggrgrp_nodup = NULL;
				char* aggrgrp_name = NULL;
				char* aggrgrp_namedup = NULL;
				char* aggrgrp_desc = NULL;
				char* aggrgrp_descdup = NULL;
				int TotalAgrVar = 0;
				int TotalModVar = 0;
				int TotalSubModVar = 0;
				int TotalVar = 0;
				char aggrvariety[100];
				char modvariety[100];
				char submodvariety[100];
				char variety[100];
	
				AggrGrpRev_tag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"item_id",&aggrgrp_no));
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"object_name",&aggrgrp_name));
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"object_desc",&aggrgrp_desc));
				trimwhitespace(aggrgrp_no);
				trimwhitespace(aggrgrp_name);
				trimwhitespace(aggrgrp_desc);
				if(aggrgrp_no!=NULL)tc_strdup(aggrgrp_no,&aggrgrp_nodup);
				if(aggrgrp_name!=NULL)tc_strdup(aggrgrp_name,&aggrgrp_namedup);
				if(aggrgrp_desc!=NULL)tc_strdup(aggrgrp_desc,&aggrgrp_descdup);
				printf("\n Aggregate Group No(aggrgrp_nodup): [%s]\n", aggrgrp_nodup);
				printf("\n Aggregate Group Name(aggrgrp_namedup): [%s]\n", aggrgrp_namedup);
				printf("\n Aggregate Group Description(aggrgrp_descdup): [%s]\n", aggrgrp_descdup);
				//if(aggrgrp_namedup != NULL) STRNG_replace_str(aggrgrp_namedup,"&","&amp;",&aggrgrp_namedup);
				//if(aggrgrp_descdup != NULL) STRNG_replace_str(aggrgrp_descdup,"&","&amp;",&aggrgrp_descdup);
				//if(tc_strlen(aggrgrp_namedup)>0) STRNG_replace_str(aggrgrp_namedup,"&","&amp;",&aggrgrp_namedup);
				//if(tc_strlen(aggrgrp_descdup)>0) STRNG_replace_str(aggrgrp_descdup,"&","&amp;",&aggrgrp_descdup);
				STRNG_replace_str(aggrgrp_namedup,"&","And",&aggrgrp_namedup);
				STRNG_replace_str(aggrgrp_descdup,"&","And",&aggrgrp_descdup);
				
				if(aggrgrp_namedup != NULL)
				{
					STRNG_replace_str(aggrgrp_namedup,"&","&amp;",&aggrgrp_namedup);
					STRNG_replace_str(aggrgrp_namedup,"<","&lt;",&aggrgrp_namedup);
					STRNG_replace_str(aggrgrp_namedup,">","&gt;",&aggrgrp_namedup);
				}
				
				if(aggrgrp_descdup != NULL)
				{
					STRNG_replace_str(aggrgrp_descdup,"&","&amp;",&aggrgrp_descdup);
					STRNG_replace_str(aggrgrp_descdup,"<","&lt;",&aggrgrp_descdup);
					STRNG_replace_str(aggrgrp_descdup,">","&gt;",&aggrgrp_descdup);
				}
				
				ITK_CALL(GRM_find_relation_type("T5_MBOMAgrGrpToAggRel",&AggrGrpToAggrRel));
				if(AggrGrpToAggrRel!=NULLTAG)
				{									
				    printf("\n Sudo Folder Aggregate Details(T5_MBOMAgrGrpToAggRel) Relation Found..!!\n");fflush(stdout);
					ITK_CALL(GRM_list_secondary_objects_only(AggrGrpRev_tag, AggrGrpToAggrRel, &sec_countaggr, &sec_aggrobjects));
				    printf("\n Total Objects Found(T5_MBOMAgrGrpToAggRel): [%d]\n", sec_countaggr);
					if(sec_countaggr > 0)
					{
						TotalAgrVar = TotalAgrVar + sec_countaggr;
						for(j = 0; j < sec_countaggr; j++)
			            {
							char* aggr_no = NULL;
	                        char* aggr_nodup = NULL;
							char* aggr_name = NULL;
							char* aggr_namedup = NULL;
							char* aggr_desc = NULL;
							char* aggr_descdup = NULL; 
	
						    AggrRev_tag = sec_aggrobjects[j];
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"item_id",&aggr_no));
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"object_name",&aggr_name));
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"object_desc",&aggr_desc));
							trimwhitespace(aggr_no);
							trimwhitespace(aggr_name);
							trimwhitespace(aggr_desc);
							if(aggr_no!=NULL)tc_strdup(aggr_no,&aggr_nodup);
							if(aggr_name!=NULL)tc_strdup(aggr_name,&aggr_namedup);
							if(aggr_desc!=NULL)tc_strdup(aggr_desc,&aggr_descdup);
						    printf("\n Aggregate No(aggr_nodup): [%s]\n", aggr_nodup);
							printf("\n Aggregate Name(aggr_namedup): [%s]\n", aggr_namedup);
							printf("\n Aggregate Description(aggr_descdup): [%s]\n", aggr_descdup);
							//if(aggr_namedup != NULL) STRNG_replace_str(aggr_namedup,"&","&amp;",&aggr_namedup);
							//if(aggr_descdup != NULL) STRNG_replace_str(aggr_descdup,"&","&amp;",&aggr_descdup);
							//if(tc_strlen(aggr_namedup)>0) STRNG_replace_str(aggr_namedup,"&","&amp;",&aggr_namedup);
				            //if(tc_strlen(aggr_descdup)>0) STRNG_replace_str(aggr_descdup,"&","&amp;",&aggr_descdup);
							
							STRNG_replace_str(aggr_namedup,"&","And",&aggr_namedup);
				            STRNG_replace_str(aggr_descdup,"&","And",&aggr_descdup);
							
							if(aggr_namedup != NULL)
							{
								STRNG_replace_str(aggr_namedup,"&","&amp;",&aggr_namedup);
								STRNG_replace_str(aggr_namedup,"<","&lt;",&aggr_namedup);
								STRNG_replace_str(aggr_namedup,">","&gt;",&aggr_namedup);
							}
							
							if(aggr_descdup != NULL)
							{
								STRNG_replace_str(aggr_descdup,"&","&amp;",&aggr_descdup);
								STRNG_replace_str(aggr_descdup,"<","&lt;",&aggr_descdup);
								STRNG_replace_str(aggr_descdup,">","&gt;",&aggr_descdup);
							}
							
							ITK_CALL(GRM_find_relation_type("T5_MBOMAggToModRel",&AggrToModRel));
							if(AggrToModRel!=NULLTAG)
							{									
								printf("\n Sudo Folder Module Details(T5_MBOMAggToModRel) Relation Found..!!\n");fflush(stdout);
								ITK_CALL(GRM_list_secondary_objects_only(AggrRev_tag, AggrToModRel, &sec_countmod, &sec_modobjects));
								printf("\n Total Objects Found(T5_MBOMAggToModRel): [%d]\n", sec_countaggr);
								if(sec_countmod > 0)
								{
									TotalModVar = TotalModVar + sec_countmod;
									for(k = 0; k < sec_countmod; k++)
									{
										char* mod_no = NULL;
	                                    char* mod_nodup = NULL;
										char* mod_name = NULL;
										char* mod_namedup = NULL;
										char* mod_desc = NULL;
										char* mod_descdup = NULL;
										
										ModRev_tag = sec_modobjects[k];
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"item_id",&mod_no));
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"object_name",&mod_name));
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"object_desc",&mod_desc));
										trimwhitespace(mod_no);
										trimwhitespace(mod_name);
										trimwhitespace(mod_desc);
										if(mod_no!=NULL)tc_strdup(mod_no,&mod_nodup);
										if(mod_name!=NULL)tc_strdup(mod_name,&mod_namedup);
										if(mod_desc!=NULL)tc_strdup(mod_desc,&mod_descdup);
										printf("\n Module No(mod_nodup): [%s]\n", mod_nodup);
										printf("\n Module Name(mod_name): [%s]\n", mod_namedup);
										printf("\n Module Description(mod_desc): [%s]\n", mod_descdup);
										//if(mod_namedup != NULL) STRNG_replace_str(mod_namedup,"&","&amp;",&mod_namedup);
										//if(mod_descdup != NULL) STRNG_replace_str(mod_descdup,"&","&amp;",&mod_descdup);
										//if(tc_strlen(mod_namedup)>0) STRNG_replace_str(mod_namedup,"&","&amp;",&mod_namedup);
				                        //if(tc_strlen(mod_descdup)>0) STRNG_replace_str(mod_descdup,"&","&amp;",&mod_descdup);
										
										STRNG_replace_str(mod_namedup,"&","And",&mod_namedup);
				                        STRNG_replace_str(mod_descdup,"&","And",&mod_descdup);
										
										if(mod_namedup != NULL)
										{
											STRNG_replace_str(mod_namedup,"&","&amp;",&mod_namedup);
											STRNG_replace_str(mod_namedup,"<","&lt;",&mod_namedup);
											STRNG_replace_str(mod_namedup,">","&gt;",&mod_namedup);
										}
										
										if(mod_descdup != NULL)
										{
											STRNG_replace_str(mod_descdup,"&","&amp;",&mod_descdup);
											STRNG_replace_str(mod_descdup,"<","&lt;",&mod_descdup);
											STRNG_replace_str(mod_descdup,">","&gt;",&mod_descdup);
										}

                                        ITK_CALL(GRM_find_relation_type("T5_MBOMModToAddRel",&ModToSubModRel));
										if(ModToSubModRel!=NULLTAG)
										{									
											printf("\n Sudo Folder SubModule Details(T5_MBOMModToAddRel) Relation Found..!!\n");fflush(stdout);
											ITK_CALL(GRM_list_secondary_objects_only(ModRev_tag, ModToSubModRel, &sec_countsubmod, &sec_submodobjects));
											printf("\n Total Objects Found(T5_MBOMModToAddRel): [%d]\n", sec_countaggr);
											if(sec_countsubmod > 0)
											{
												TotalSubModVar = TotalSubModVar + sec_countsubmod;
												for(l = 0; l < sec_countsubmod; l++)
												{
													char* submod_no = NULL;
	                                                char* submod_nodup = NULL;
													char* submod_name = NULL;
													char* submod_namedup = NULL;
													char* submod_desc = NULL;
													char* submod_descdup = NULL;
													char* submod_address = NULL;
	                                                char* submod_addressdup = NULL;
	
													SubModRev_tag = sec_submodobjects[l];
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"item_id",&submod_no));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"object_name",&submod_name));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"object_desc",&submod_desc));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"item_id",&submod_address));
													trimwhitespace(submod_no);
													trimwhitespace(submod_name);
													trimwhitespace(submod_desc);
													trimwhitespace(submod_address);
													if(submod_no!=NULL)tc_strdup(submod_no,&submod_nodup);
													if(submod_name!=NULL)tc_strdup(submod_name,&submod_namedup);
													if(submod_desc!=NULL)tc_strdup(submod_desc,&submod_descdup);
													if(submod_address!=NULL)tc_strdup(submod_address,&submod_addressdup);
													printf("\n SubModule No(submod_nodup): [%s]\n", submod_nodup);
													printf("\n SubModule Name(submod_namedup): [%s]\n", submod_namedup);
													printf("\n SubModule Description(submod_descdup): [%s]\n", submod_descdup);
													printf("\n Module Address(submod_addressdup): [%s]\n", submod_addressdup);
													//if(submod_namedup != NULL) STRNG_replace_str(submod_namedup,"&","&amp;",&submod_namedup);
													//if(submod_descdup != NULL) STRNG_replace_str(submod_descdup,"&","&amp;",&submod_descdup);
													//if(submod_addressdup != NULL) STRNG_replace_str(submod_addressdup,"&","&amp;",&submod_addressdup);	
													//if(tc_strlen(submod_namedup)>0) STRNG_replace_str(submod_namedup,"&","&amp;",&submod_namedup);
				                                    //if(tc_strlen(submod_descdup)>0) STRNG_replace_str(submod_descdup,"&","&amp;",&submod_descdup);
													//if(tc_strlen(submod_addressdup)>0) STRNG_replace_str(submod_addressdup,"&","&amp;",&submod_addressdup);
													
													STRNG_replace_str(submod_namedup,"&","And",&submod_namedup);
				                                    STRNG_replace_str(submod_descdup,"&","And",&submod_descdup);
													STRNG_replace_str(submod_namedup,"""","",&submod_namedup);
													STRNG_replace_str(submod_descdup,"""","",&submod_descdup);
													
													if(submod_namedup != NULL)
													{
														STRNG_replace_str(submod_namedup,"&","&amp;",&submod_namedup);
														STRNG_replace_str(submod_namedup,"<","&lt;",&submod_namedup);
														STRNG_replace_str(submod_namedup,">","&gt;",&submod_namedup);
													}
													
													if(submod_descdup != NULL)
													{
														STRNG_replace_str(submod_descdup,"&","&amp;",&submod_descdup);
														STRNG_replace_str(submod_descdup,"<","&lt;",&submod_descdup);
														STRNG_replace_str(submod_descdup,">","&gt;",&submod_descdup);
													}
													
													ITK_CALL(AOM_ask_table_rows(SubModRev_tag,"t5_MBOMSubModTbl", &n_valid_rows,&valid_rowsTag));
													printf("\n No of Table Row [%d]  For SubModule  [%s]\n", n_valid_rows, submod_nodup);fflush(stdout);
													if(n_valid_rows>0)
													{
														for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
														{
															char* Tbl_SubModNo = NULL;
															char* Tbl_SubModNodup = NULL;
															char* Tbl_SubModRev = NULL;
															char* Tbl_SubModRevdup = NULL;
															char* Tbl_SubModSeq = NULL;
															char* Tbl_SubModSeqdup = NULL;
															char* Tbl_SubModDesc = NULL;
															char* Tbl_SubModDescdup = NULL;
															char* Tbl_SubModProd = NULL;
															char* Tbl_SubModProddup = NULL;
															char* Tbl_SubModPlat = NULL;
															char* Tbl_SubModPlatdup = NULL;
															char* Tbl_SubModProj = NULL;
															char* Tbl_SubModProjdup = NULL;
															char* Tbl_SubModDRAR = NULL;
															char* Tbl_SubModDRARdup = NULL;
															char* Tbl_SubModVehLink = NULL;
															//char* Tbl_SubModVehLinkdup = NULL;
															char* Tbl_SubModVehCount = NULL;
															char* Tbl_SubModVehPlat = NULL;
															char* Tbl_SubModMaxArDr = NULL;
															char* Tbl_SubModCreateDt = NULL;
															char* Tbl_NewSubModCreateDt = NULL;
															char* SubModAgeing = NULL;
															char* Tbl_SubModAgeingFinal = (char *) malloc(40*sizeof(char));
															char* Tbl_PUNCS = NULL;
															char* Tbl_LKNCS = NULL;
															char* Tbl_JSRCS = NULL;
															char* Tbl_UTKCS = NULL;
															char* Tbl_DWDCS = NULL;
															char* Tbl_DesGrp = NULL;
															
															
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_submoduleno",&Tbl_SubModNo));	
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_rev",&Tbl_SubModRev));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_seq",&Tbl_SubModSeq));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_desc",&Tbl_SubModDesc));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_productline",&Tbl_SubModProd));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_platform",&Tbl_SubModPlat));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_projectcode",&Tbl_SubModProj));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_drarstatus",&Tbl_SubModDRAR));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_vehlink",&Tbl_SubModVehLink));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_linkvehcount",&Tbl_SubModVehCount));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_linkplatformcount",&Tbl_SubModVehPlat));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_maxdrarstatus",&Tbl_SubModMaxArDr));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_creationdate",&Tbl_SubModCreateDt));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_creationdate",&Tbl_NewSubModCreateDt));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_MBOMTblRowInfo1",&Tbl_PUNCS));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_MBOMTblRowInfo2",&Tbl_LKNCS));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_MBOMTblRowInfo3",&Tbl_JSRCS));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_MBOMTblRowInfo4",&Tbl_UTKCS));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_MBOMTblRowInfo5",&Tbl_DWDCS));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_desgrp",&Tbl_DesGrp));
															
															trimwhitespace(Tbl_SubModNo);
															trimwhitespace(Tbl_SubModRev);
															trimwhitespace(Tbl_SubModSeq);
															trimwhitespace(Tbl_SubModDesc);
				                                            printf("\n SubModule Description Value Before Dup & Trim: --------> <%s>", Tbl_SubModDesc);fflush(stdout);
															STRNG_replace_str(Tbl_SubModDesc,","," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,";"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"\n"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"'"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"&","And",&Tbl_SubModDesc);
															trimwhitespace(Tbl_SubModProd);
															trimwhitespace(Tbl_SubModPlat);
															trimwhitespace(Tbl_SubModProj);
															trimwhitespace(Tbl_SubModDRAR);
													        if(Tbl_SubModNo!=NULL)tc_strdup(Tbl_SubModNo,&Tbl_SubModNodup);
															if(Tbl_SubModRev!=NULL)tc_strdup(Tbl_SubModRev,&Tbl_SubModRevdup);
															if(Tbl_SubModSeq!=NULL)tc_strdup(Tbl_SubModSeq,&Tbl_SubModSeqdup);
															if(Tbl_SubModDesc!=NULL)tc_strdup(Tbl_SubModDesc,&Tbl_SubModDescdup);
															if(Tbl_SubModProd!=NULL)tc_strdup(Tbl_SubModProd,&Tbl_SubModProddup);
															if(Tbl_SubModPlat!=NULL)tc_strdup(Tbl_SubModPlat,&Tbl_SubModPlatdup);
															if(Tbl_SubModProj!=NULL)tc_strdup(Tbl_SubModProj,&Tbl_SubModProjdup);
															if(Tbl_SubModDRAR!=NULL)tc_strdup(Tbl_SubModDRAR,&Tbl_SubModDRARdup);
													        printf("\n Table SubModule No(Tbl_SubModNodup): [%s]\n", Tbl_SubModNodup);
															printf("\n Table SubModule Rev(Tbl_SubModRevdup): [%s]",Tbl_SubModRevdup);fflush(stdout);
															printf("\n Table SubModule Seq(Tbl_SubModSeqdup): [%s]",Tbl_SubModSeqdup);fflush(stdout);
															printf("\n Table SubModule Description(Tbl_SubModDescdup): [%s]",Tbl_SubModDescdup);fflush(stdout);
															printf("\n Table SubModule Peoductline(Tbl_SubModProddup): [%s]",Tbl_SubModProddup);fflush(stdout);
															printf("\n Table SubModule Platform(Tbl_SubModPlatdup): [%s]",Tbl_SubModPlatdup);fflush(stdout);
															printf("\n Table SubModule Project Code(Tbl_SubModProjdup): [%s]",Tbl_SubModProjdup);fflush(stdout);
															printf("\n Table SubModule DR/AR(Tbl_SubModDRARdup): [%s]",Tbl_SubModDRARdup);fflush(stdout);
															printf("\n Table SubModule Vehicle-Link(Tbl_SubModVehLink): [%s]",Tbl_SubModVehLink);fflush(stdout);
															printf("\n Table SubModule Vehicle-Count(Tbl_SubModVehCount): [%s]",Tbl_SubModVehCount);fflush(stdout);
															printf("\n Table SubModule Vehicle-Platform(Tbl_SubModVehPlat): [%s]",Tbl_SubModVehPlat);fflush(stdout);
															printf("\n Table SubModule Max AR-DR(Tbl_SubModMaxArDr): [%s]",Tbl_SubModMaxArDr);fflush(stdout);
															printf("\n Table SubModule Creation_Date(Tbl_SubModCreateDt): [%s]",Tbl_SubModCreateDt);fflush(stdout);
															printf("\n Table SubModule New_Creation_Date(Tbl_NewSubModCreateDt): [%s]",Tbl_NewSubModCreateDt);fflush(stdout);
															printf("\n PUN CS(Tbl_PUNCS): [%s]",Tbl_PUNCS);fflush(stdout);
															printf("\n LKN CS(Tbl_LKNCS): [%s]",Tbl_LKNCS);fflush(stdout);
															printf("\n JSR CS(Tbl_JSRCS): [%s]",Tbl_JSRCS);fflush(stdout);
															printf("\n UTK CS(Tbl_UTKCS): [%s]",Tbl_UTKCS);fflush(stdout);
															printf("\n DWD CS(Tbl_DWDCS): [%s]",Tbl_DWDCS);fflush(stdout);
															printf("\n Design Group(Tbl_DesGrp): [%s]",Tbl_DesGrp);fflush(stdout);
															
															printf("\n @@@@@@@@@@@ Function: For Ageing Calculation Start..!!\n");fflush(stdout);
															SubModAgeing = TM_SubModAgeing(Tbl_SubModCreateDt);
															printf("\n SubModule Ageing: [%s]\n", SubModAgeing);fflush(stdout);
															//char* Tbl_SubModAgeingFinal = (char *) malloc(40*sizeof(char));
															tc_strcpy(Tbl_SubModAgeingFinal,Tbl_NewSubModCreateDt);
															tc_strcat(Tbl_SubModAgeingFinal," (");
															tc_strcat(Tbl_SubModAgeingFinal,SubModAgeing);
															tc_strcat(Tbl_SubModAgeingFinal,")");
															printf("\n @@@@@@@@@@@ Function: For Ageing Calculation End..!!\n");fflush(stdout);
															
															printf("\n >>>>>>>>>>>>>>> SubModule Library Details Start <<<<<<<<<<<<<<<<\n");fflush(stdout);
															printf("[1] Aggregate_Group: [%s]\n",aggrgrp_nodup);fflush(stdout);
															printf("[2] Aggregate_Group_Name: [%s]\n",aggrgrp_namedup);fflush(stdout);
															printf("[3] Aggregate_Group_Description: [%s]\n",aggrgrp_descdup);fflush(stdout);
															printf("[4] Aggregate: [%s]\n",aggr_nodup);fflush(stdout);
															printf("[5] Aggregate_Name: [%s]\n",aggr_namedup);fflush(stdout);
															printf("[6] Aggregate_Description: [%s]\n",aggr_descdup);fflush(stdout);
															printf("[7] Module: [%s]\n",mod_nodup);fflush(stdout);
															printf("[8] Module_Name: [%s]\n",mod_namedup);fflush(stdout);
															printf("[9] Module_Description: [%s]\n",mod_descdup);fflush(stdout);
															printf("[10] SubModule: [%s]\n",submod_nodup);fflush(stdout);
															printf("[11] SubModule_Name: [%s]\n",submod_namedup);fflush(stdout);
															printf("[12] SubModule_Description: [%s]\n",submod_descdup);fflush(stdout);
															printf("[13] Module_Address: [%s]\n",submod_addressdup);fflush(stdout);
															printf("[14] SubModule_No: [%s]\n",Tbl_SubModNodup);fflush(stdout);
															printf("[15] Revision: [%s]\n",Tbl_SubModRevdup);fflush(stdout);
															printf("[16] Sequence: [%s]\n",Tbl_SubModSeqdup);fflush(stdout);
															printf("[17] Description: [%s]\n",Tbl_SubModDescdup);fflush(stdout);
															printf("[18] Product Line: [%s]\n",Tbl_SubModProddup);fflush(stdout);
															printf("[19] Platform: [%s]\n",Tbl_SubModPlatdup);fflush(stdout);
															printf("[20] Project Code: [%s]\n",Tbl_SubModProjdup);fflush(stdout);
															printf("[21] DR/AR Status: [%s]\n",Tbl_SubModDRARdup);fflush(stdout);
															printf("[22] MAX AR/DR Status: [%s]\n",Tbl_SubModMaxArDr);fflush(stdout);
															printf("[23] Vehicle Linked: [%s]\n",Tbl_SubModVehLink);fflush(stdout);
															printf("[24] Vehicle Count: [%s]\n",Tbl_SubModVehCount);fflush(stdout);
															printf("[25] SubModule Ageing: [%s]\n",Tbl_SubModAgeingFinal);fflush(stdout);
															printf("[26] Vehicle Platform: [%s]\n",Tbl_SubModVehPlat);fflush(stdout);
															printf("[27] PUN CS: [%s]\n",Tbl_PUNCS);fflush(stdout);
															printf("[28] LKN CS: [%s]\n",Tbl_LKNCS);fflush(stdout);
															printf("[29] JSR CS: [%s]\n",Tbl_JSRCS);fflush(stdout);
															printf("[30] UTK CS: [%s]\n",Tbl_UTKCS);fflush(stdout);
															printf("[31] DWD CS: [%s]\n",Tbl_DWDCS);fflush(stdout);
															printf("[32] Design Group: [%s]\n",Tbl_DesGrp);fflush(stdout);
															tostring(aggrvariety, TotalAgrVar);
															tostring(modvariety, TotalModVar);
															tostring(submodvariety, TotalSubModVar);
															tostring(variety, n_valid_rows);
															printf("[22] Variety: [%s]\n",variety);fflush(stdout);
															printf("\n >>>>>>>>>>>>>>> SubModule Library Details End <<<<<<<<<<<<<<<<\n");fflush(stdout);
						
															if(tc_strlen(Tbl_SubModDescdup)>0) STRNG_replace_str(Tbl_SubModDescdup,"&","&amp;",&Tbl_SubModDescdup);
				                                            if(tc_strlen(Tbl_SubModProddup)>0) STRNG_replace_str(Tbl_SubModProddup,"&","&amp;",&Tbl_SubModProddup);
													        if(tc_strlen(Tbl_SubModPlatdup)>0) STRNG_replace_str(Tbl_SubModPlatdup,"&","&amp;",&Tbl_SubModPlatdup);
															
															write2xml(DetRpt,"<SubmoduleDetail>\n");
															write2xml(DetRpt,"<AggregateGrpName>"); if(tc_strlen(aggrgrp_namedup)>0) write2xml(DetRpt,aggrgrp_namedup); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</AggregateGrpName>\n");
															write2xml(DetRpt,"<AggregateGrpDesc>"); if(tc_strlen(aggrgrp_descdup)>0) write2xml(DetRpt,aggrgrp_descdup); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</AggregateGrpDesc>\n");
															write2xml(DetRpt,"<AggrVariety>"); if(tc_strlen(aggrvariety)>0) write2xml(DetRpt,aggrvariety); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</AggrVariety>\n");
														    write2xml(DetRpt,"<AggregateName>"); if(tc_strlen(aggr_namedup)>0) write2xml(DetRpt,aggr_namedup); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</AggregateName>\n");
															write2xml(DetRpt,"<AggregateDesc>"); if(tc_strlen(aggr_descdup)>0) write2xml(DetRpt,aggr_descdup); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</AggregateDesc>\n");
															write2xml(DetRpt,"<ModuleVariety>"); if(tc_strlen(modvariety)>0) write2xml(DetRpt,modvariety); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</ModuleVariety>\n");
														    write2xml(DetRpt,"<ModuleName>"); if(tc_strlen(mod_namedup)>0) write2xml(DetRpt,mod_namedup); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</ModuleName>\n");
															write2xml(DetRpt,"<ModuleDesc>"); if(tc_strlen(mod_descdup)>0) write2xml(DetRpt,mod_descdup); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</ModuleDesc>\n");
															write2xml(DetRpt,"<SubmoduleAddrVariety>"); if(tc_strlen(submodvariety)>0) write2xml(DetRpt,submodvariety); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</SubmoduleAddrVariety>\n");
														    write2xml(DetRpt,"<SubmoduleName>"); if(tc_strlen(submod_namedup)>0) write2xml(DetRpt,submod_namedup); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</SubmoduleName>\n");
															write2xml(DetRpt,"<SubmoduleDesc>"); if(tc_strlen(submod_descdup)>0) write2xml(DetRpt,submod_descdup); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</SubmoduleDesc>\n");
															write2xml(DetRpt,"<SubmoduleAdd>"); if(tc_strlen(submod_addressdup)>0) write2xml(DetRpt,submod_addressdup); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</SubmoduleAdd>\n");
															write2xml(DetRpt,"<SubmoduleDetailsVariety>"); if(tc_strlen(variety)>0) write2xml(DetRpt,variety); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</SubmoduleDetailsVariety>\n");
														    write2xml(DetRpt,"<TBL_SubmoduleNo>"); if(tc_strlen(Tbl_SubModNodup)>0) write2xml(DetRpt,Tbl_SubModNodup); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_SubmoduleNo>\n");
															write2xml(DetRpt,"<TBL_SubmoduleRev>"); if(tc_strlen(Tbl_SubModRevdup)>0) write2xml(DetRpt,Tbl_SubModRevdup); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_SubmoduleRev>\n");
															write2xml(DetRpt,"<TBL_SubmoduleSeq>"); if(tc_strlen(Tbl_SubModSeqdup)>0) write2xml(DetRpt,Tbl_SubModSeqdup); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_SubmoduleSeq>\n");
															write2xml(DetRpt,"<TBL_SubmoduleDesc>"); if(tc_strlen(Tbl_SubModDescdup)>0) write2xml(DetRpt,Tbl_SubModDescdup); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_SubmoduleDesc>\n");
															write2xml(DetRpt,"<TBL_SubmoduleProd>"); if(tc_strlen(Tbl_SubModProddup)>0) write2xml(DetRpt,Tbl_SubModProddup); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_SubmoduleProd>\n");
															write2xml(DetRpt,"<TBL_SubmodulePlat>"); if(tc_strlen(Tbl_SubModPlatdup)>0) write2xml(DetRpt,Tbl_SubModPlatdup); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_SubmodulePlat>\n");
															write2xml(DetRpt,"<TBL_SubmoduleProj>"); if(tc_strlen(Tbl_SubModProjdup)>0) write2xml(DetRpt,Tbl_SubModProjdup); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_SubmoduleProj>\n");
															write2xml(DetRpt,"<TBL_SubmoduleDrAr>"); if(tc_strlen(Tbl_SubModDRARdup)>0) write2xml(DetRpt,Tbl_SubModDRARdup); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_SubmoduleDrAr>\n");
															write2xml(DetRpt,"<TBL_SubmoduleMax>"); if(tc_strlen(Tbl_SubModMaxArDr)>0) write2xml(DetRpt,Tbl_SubModMaxArDr); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_SubmoduleMax>\n");
															write2xml(DetRpt,"<TBL_SubmoduleVariety>"); if(tc_strlen(variety)>0) write2xml(DetRpt,variety); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_SubmoduleVariety>\n");
															write2xml(DetRpt,"<TBL_SubmoduleVehLinkedFlag>"); if(tc_strlen(Tbl_SubModVehLink)>0) write2xml(DetRpt,Tbl_SubModVehLink); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_SubmoduleVehLinkedFlag>\n");
															write2xml(DetRpt,"<TBL_SubmoduleVehCount>"); if(tc_strlen(Tbl_SubModVehCount)>0) write2xml(DetRpt,Tbl_SubModVehCount); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_SubmoduleVehCount>\n");
															write2xml(DetRpt,"<TBL_SubmoduleAgeing>"); if(tc_strlen(Tbl_SubModAgeingFinal)>0) write2xml(DetRpt,Tbl_SubModAgeingFinal); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_SubmoduleAgeing>\n");
															write2xml(DetRpt,"<TBL_SubmoduleVehPlat>"); if(tc_strlen(Tbl_SubModVehPlat)>0) write2xml(DetRpt,Tbl_SubModVehPlat); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_SubmoduleVehPlat>\n");
															write2xml(DetRpt,"<TBL_Puncs>"); if(tc_strlen(Tbl_PUNCS)>0) write2xml(DetRpt,Tbl_PUNCS); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_Puncs>\n");
															write2xml(DetRpt,"<TBL_Lkncs>"); if(tc_strlen(Tbl_LKNCS)>0) write2xml(DetRpt,Tbl_LKNCS); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_Lkncs>\n");
															write2xml(DetRpt,"<TBL_Jsrcs>"); if(tc_strlen(Tbl_JSRCS)>0) write2xml(DetRpt,Tbl_JSRCS); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_Jsrcs>\n");
															write2xml(DetRpt,"<TBL_Utkcs>"); if(tc_strlen(Tbl_UTKCS)>0) write2xml(DetRpt,Tbl_UTKCS); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_Utkcs>\n");
															write2xml(DetRpt,"<TBL_Dwdcs>"); if(tc_strlen(Tbl_DWDCS)>0) write2xml(DetRpt,Tbl_DWDCS); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_Dwdcs>\n");
															write2xml(DetRpt,"<TBL_DesGr>"); if(tc_strlen(Tbl_DesGrp)>0) write2xml(DetRpt,Tbl_DesGrp); else write2xml(DetRpt,"NA"); write2xml(DetRpt,"</TBL_DesGr>\n");
															write2xml(DetRpt,"</SubmoduleDetail>\n");
														}
													}
													else
													{
														printf("\n No Table Row Found For Input SubModule: [%s], submod_nodup\n");fflush(stdout);
													} 
												}
											}
											else
											{
												printf("\n SubModule Not Found For Module: [%s]\n", mod_nodup);fflush(stdout);
											}
										}
										else
										{
											printf("\n Module Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
										}										
									}
								}
								else
								{
									printf("\n Module Not Found For Aggregate: [%s]\n", aggr_nodup);fflush(stdout);
								}
							}
							else
							{
								printf("\n Module Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n Aggregate Not Found For Aggregate Group: [%s]\n", aggrgrp_nodup);fflush(stdout);
					}
				}
				else
				{
					printf("\n Aggregate Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
				}
			}			
		}
		else
        {
			printf(" Aggregate Group Found Zero[0] on SubModuleLibraryAggrGrp..!!\n");fflush(stdout);
		}
	}
	else
    {
		printf(" Latest Released Design Revision for ERC Query Tag Not Found..!!\n");fflush(stdout);
    }
	
	return iFail;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	char STDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	strftime(STDate,100,"%d %b, %Y (%A)",&when);
	printf(" Stylesheet TimeStamp: [%s]\n", STDate);fflush(stdout);
	
	printf("\n Generating XML Report File Name..!!");fflush(stdout);
	Report = fopen("/tmp/MBOMSubModuleDashboardDetailsReport.xml","w");
	if(Report == NULL)
	{
		printf("ERROR: Unable To Open XML File..!!\n");
		return -1;
	}
	else
	{
		printf("XML File Opened Successfully..!!\n");
	}

	strftime(GenDate,100,"%d-%m-%Y %H:%M:%S",&when);
	write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
	write2xml(Report,"<SubMooduleDashboard>\n");
	write2xml(Report,"<DataRefreshDate>\n");
	write2xml(Report,"<LastDate>"); write2xml(Report,STDate); write2xml(Report,"</LastDate>\n");
	write2xml(Report,"</DataRefreshDate>\n");
	printf("\n >>>>>>>>>>111111111111111111111111111111111111111111111111111111111111111111111111<<<<<<<<<<<\n");fflush(stdout);
	printf("\n Function1: SubModule Library Details Print Start");fflush(stdout);
	TC_SubModuleDetails(Report);
	printf("\n Function1: SubModule Library Details Print End\n");fflush(stdout);
	printf("\n >>>>>>>>>>111111111111111111111111111111111111111111111111111111111111111111111111<<<<<<<<<<<\n");fflush(stdout);
	write2xml(Report,"</SubMooduleDashboard>\n");
	fclose(Report);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_mbom_mcc_library_details_rpt.c
* // ./linkitk -o tm_mbom_mcc_library_details_rpt tm_mbom_mcc_library_details_rpt.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_MCC_Library_Details_Report/tm_mbom_mcc_library_details_rpt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_MCC_Library_Details_Report/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_MCC_Library_Details_Report/usage.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_MCC_Library_Details_Report/SendEmail.sh .
* // ./tm_mbom_mcc_library_details_rpt -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_mbom_mcc_library_details_rpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_mbom_mcc_library_details_rpt -u=infodba -p=infodba123 -g=dba
*
***************************************************************************/