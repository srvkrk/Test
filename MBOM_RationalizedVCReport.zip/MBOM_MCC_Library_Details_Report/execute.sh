/user/cvprod/sourav/MBOM_MCC_Library_Details_Report/tm_mbom_mcc_library_details_rpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
