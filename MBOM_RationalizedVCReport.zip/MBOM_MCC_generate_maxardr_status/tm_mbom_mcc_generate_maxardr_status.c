/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Item
*  Description  :   Generate MAX AR or DR After Reading Data From Input File.
*  File Name    :   tm_mbom_mcc_generate_maxardr_status.c
*  Created on   :   Oct 25th, 2025
*  Usage        :   tm_mbom_mcc_generate_maxardr_status
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     25/10/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\


const char *DrOrder[] = {"NA","AR0","AR1","AR2","AR3","AR3P","AR4","AR5","DR0","DR1","DR2","DR3","DR3P","DR4","DR5"};
const int DrLength = 15;
char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

int ITK_user_main(int argc,char* argv[])
{
	int iFail = 0;
	char *message;
	char *loggedInUser = NULL;
	char *inp_file_str = NULL;
	char *inp_file_strDup = NULL;
	char *RptFile = (char *) malloc(200*sizeof(char));
	FILE *fpOutput_file = NULL;
	FILE *fpPart_List = NULL;
	int n_entries = 1;
	int i=0;
	int JtNo=0;
	int AsmPrt =0;
	int j=0;
	int k=0;
	int cnt=0;
	int Count =0;
	int actDrOrder =0, SubModuleAddressOrder=0;
	tag_t tItemobj = NULLTAG;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	char *PartID = NULL;
	char *DRStatus = NULL;
	char *Part_Rlz_Stat = NULL;
	char *part_type = NULL;
	char *Description = NULL;
	char *object_type = NULL;
	char *Part_ProjID = NULL;
	char *Part_DesgnGrp = NULL;
	char *Revision = NULL;
	tag_t dataset = NULLTAG;
	tag_t dataset2 = NULLTAG;
	char *inputfile=NULL;
	tag_t *Part_Status_List = NULLTAG;
	int Part_Status_Count = 0;
	char *Part_Rlz_Status = NULL;
	tag_t relation_type = NULLTAG;
	tag_t relation_type2 = NULLTAG;
	tag_t* rellist_JT = NULLTAG;
	int n_attchs_JT =0;
	tag_t* attachments = NULLTAG;
	tag_t itemrev = NULLTAG;
	int Part_Stat_Cnt = 0;
	tag_t *Part_Stat_Lst = NULLTAG;
	char * objtype=NULL;
	char * objtype1=NULL;
	char * PartRevID=NULL;
	int iGMDMLFnd	=	0;
	int	n_tskfund	=	0;
	int task = 0;
	int dmlcnt = 0;
	int *levelsaa;
	int Counter =0;;
	char	**relations	=  NULL;
	tag_t	tsk_dml_rel_type	=	NULLTAG;
	tag_t	*DMLRev	=	NULLTAG;
	tag_t	*referencers = NULLTAG;
	char* dmlNo = NULL;
	char* DmlType = NULL;
	char* PartNoTemp = NULL;
	char* DrStatusTemp = NULL;
	int CurrentDr = 0;
	int PreviousDr = 0;
	int HighestDr = 0;
	char* PreviousDrStatus = NULL;
	char* RevSeqTemp =NULL;	
	char* FinalRevSeq = NULL;	
	
	char *cEntries[1]  = {"Item ID"};
	//char *cEntries[2]  = {"Item ID","Revision"};
	char *inputline = NULL;
	char **cValues = (char **) MEM_alloc(50 * sizeof(char *));

    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	inp_file_str = ITK_ask_cli_argument("-i=");
	trimwhitespace(inp_file_str);
	if(inp_file_str!=NULL)tc_strdup(inp_file_str,&inp_file_strDup);
	printf(" [1]: Input File_Name(inp_file_strDup): [%s]\n",inp_file_strDup);
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"Output_MaxARDR_Status_Rpt_File");
	tc_strcat(RptFile,".txt");
	/* tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv"); */
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	
	fpPart_List = fopen(inp_file_strDup,"r");
	 
    fpOutput_file = fopen(RptFile, "w");
	//fprintf(fpOutput_file,"ADDRESS, PART_NO, REVSEQ, VEHICLE_LINK_STATUS, LINK_COUNT, PLATFORM_STATUS \n");fflush(fpOutput_file);
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fpPart_List)!=NULL)
		{
			printf("\n Input Part: [%s]",inputline); fflush(stdout);

			char *partNoIP = NULL;
			partNoIP = (char *)MEM_alloc(250);
			char *SubModuleAddress = NULL;
			SubModuleAddress = (char *)MEM_alloc(50);
			FinalRevSeq = (char *)MEM_alloc(500);
			PreviousDrStatus = (char *)MEM_alloc(50);
			PartNoTemp = (char *)MEM_alloc(50);
			DrStatusTemp = (char *)MEM_alloc(50);
			//HighestDr = (char *)MEM_alloc(50);
			RevSeqTemp = (char *)MEM_alloc(50);
			tc_strcpy(partNoIP, "");	
			tc_strcpy(SubModuleAddress, "");
			tc_strcpy(FinalRevSeq, "");
			tc_strcpy(PreviousDrStatus, "");
			tc_strcpy(PartNoTemp, "");
			tc_strcpy(DrStatusTemp, "");
			//tc_strcpy(HighestDr, "");
			tc_strcpy(RevSeqTemp, "");
			partNoIP = strtok(inputline,",");
			SubModuleAddress = strtok(NULL,",");


			printf("partNoIP----------->: [%s]\n",partNoIP);fflush(stdout);	
			printf("SubModuleAddress----------->: [%s]\n",SubModuleAddress);fflush(stdout);						
			cValues[0] = partNoIP;
			//cValues[1] = RevSeq;
			
			//ITK_CALL(QRY_find2("Item ID",&tItemobj));
			ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
			printf("\n Return Value From Query Find API is : [%d]", iFail);fflush(stdout);
			printf("\n Query Found Successfully...");fflush(stdout);

			ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
			printf("\n Return Value From Query Execute API is --------> [%d]", iFail);fflush(stdout);
			printf("\n No of item returned ----------------------> [%d]\n", n_itemobj_found);fflush(stdout);
			
				if(n_itemobj_found>0)
				{						

					for(k=0;k<n_itemobj_found;k++)
					{			
						itemrev=titemobj_results[k];																		
						ITK_CALL(AOM_ask_value_string(itemrev,"item_id",&PartID));
						ITK_CALL(AOM_ask_value_string(itemrev,"item_revision_id",&PartRevID));
						ITK_CALL(AOM_ask_value_string(itemrev,"t5_PartStatus",&DRStatus));
																							
						ITK_CALL(WSOM_ask_release_status_list(itemrev,&Part_Status_Count,&Part_Status_List));
						
						for(Count=0; Count<Part_Status_Count;Count++)
						{
							AOM_ask_name(Part_Status_List[Count], &Part_Rlz_Status);
							
							//printf("Part_Rlz_Status-----------> :%s\n",Part_Rlz_Status);fflush(stdout);		
							//if((tc_strcmp(Part_Rlz_Status,"T5_LcsErcRlzd")==0))
                            if((tc_strcmp(Part_Rlz_Status,"MBOM Released") == 0)||(tc_strcmp(Part_Rlz_Status,"T5_MBOMReleased") == 0)||
							   (tc_strcmp(Part_Rlz_Status,"APLC Released") == 0)||(tc_strcmp(Part_Rlz_Status,"T5_LcsAplRlzd") == 0)||
							   (tc_strcmp(Part_Rlz_Status,"APLP Released") == 0)||(tc_strcmp(Part_Rlz_Status,"T5_LcsAplpRlzd") == 0)||
							   (tc_strcmp(Part_Rlz_Status,"APLD Released") == 0)||(tc_strcmp(Part_Rlz_Status,"T5_LcsApldRlzd") == 0)||
							   (tc_strcmp(Part_Rlz_Status,"APLU Released") == 0)||(tc_strcmp(Part_Rlz_Status,"T5_LcsApluRlzd") == 0)||
							   (tc_strcmp(Part_Rlz_Status,"APLJ Released") == 0)||(tc_strcmp(Part_Rlz_Status,"T5_LcsApljRlzd") == 0)||
							   (tc_strcmp(Part_Rlz_Status,"APLL Released") == 0)||(tc_strcmp(Part_Rlz_Status,"T5_LcsApllRlzd") == 0)||
							   (tc_strcmp(Part_Rlz_Status,"APLA Released") == 0)||(tc_strcmp(Part_Rlz_Status,"T5_LcsAplaRlzd") == 0)||
							   (tc_strcmp(Part_Rlz_Status,"STDSIC Released") == 0)||(tc_strcmp(Part_Rlz_Status,"T5_LcsStdRlzd") == 0)||
							   (tc_strcmp(Part_Rlz_Status,"STDSIP Released") == 0)||(tc_strcmp(Part_Rlz_Status,"T5_LcsStdpRlzd") == 0)||
							   (tc_strcmp(Part_Rlz_Status,"STDSID Released") == 0)||(tc_strcmp(Part_Rlz_Status,"T5_LcsStddRlzd") == 0)||
							   (tc_strcmp(Part_Rlz_Status,"STDSIU Released") == 0)||(tc_strcmp(Part_Rlz_Status,"T5_LcsStduRlzd") == 0)||
							   (tc_strcmp(Part_Rlz_Status,"STDSIJ Released") == 0)||(tc_strcmp(Part_Rlz_Status,"T5_LcsStdjRlzd") == 0)||
							   (tc_strcmp(Part_Rlz_Status,"STDSIL Released") == 0)||(tc_strcmp(Part_Rlz_Status,"T5_LcsStdlRlzd") == 0)||
							   (tc_strcmp(Part_Rlz_Status,"STDSIA Released") == 0)||(tc_strcmp(Part_Rlz_Status,"T5_LcsStdaRlzd") == 0))								
							{
								printf("\n PartID -- PartRevID -- DRStatus ----------->: [%s] [%s] [%s]\n",PartID,PartRevID,DRStatus);fflush(stdout);	
								tc_strcpy(FinalRevSeq,PartRevID);
								for (i = 0; i < DrLength; i++) 
								{     
									if (strcmp(DRStatus, DrOrder[i]) == 0) 
									{
										CurrentDr = i;
										break;
									}
								}	
								printf("\n CurrentDr HighestDr Before ----------->: [%d] [%d]\n",CurrentDr,HighestDr);fflush(stdout);
								if(CurrentDr > HighestDr)
								{
									HighestDr=CurrentDr;
								}												
								printf("\n CurrentDr HighestDr After ----------->: [%d] [%d]\n",CurrentDr,HighestDr);fflush(stdout);
								printf("\n PartID FinalRevSeq DRStatus ----------->: [%s] [%s] [%s]\n",PartID,FinalRevSeq,DRStatus);fflush(stdout);											
							}					
						}
						
						Counter++;
						printf("\n Counter: [%d]",Counter); fflush(stdout);

					}
					
					fprintf(fpOutput_file,"%s^%s^%s^\n",SubModuleAddress,PartID,DrOrder[HighestDr]);fflush(fpOutput_file);
					HighestDr=0;
																																					
				}							
				printf("\n=============================================================================");fflush(stdout);
		}
        printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout); 		
	}
	else
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	
	fclose(fpOutput_file);					
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_mbom_mcc_generate_maxardr_status.c
* // ./linkitk -o tm_mbom_mcc_generate_maxardr_status tm_mbom_mcc_generate_maxardr_status.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_MCC_generate_maxardr_status/tm_mbom_mcc_generate_maxardr_status .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_MCC_generate_maxardr_status/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_MCC_generate_maxardr_status/usage.txt .
* // ./tm_mbom_mcc_generate_maxardr_status -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -i=input_maxardr_mcc_valid_system_submodule.txt
* // ./tm_mbom_mcc_generate_maxardr_status -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=input_maxardr_mcc_valid_system_submodule.txt
*
***************************************************************************/