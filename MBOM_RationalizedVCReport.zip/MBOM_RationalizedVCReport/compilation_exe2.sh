./compile tm_GenObsoleteStatus.c
./linkitk -o tm_GenObsoleteStatus tm_GenObsoleteStatus.o
chmod 777 tm_GenObsoleteStatus*
