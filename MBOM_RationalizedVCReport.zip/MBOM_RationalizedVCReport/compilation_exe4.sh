./compile tm_UsedinModule.c
./linkitk -o tm_UsedinModule tm_UsedinModule.o
chmod 777 tm_UsedinModule*
