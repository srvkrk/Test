/user/cvprod/sourav/MBOM_RationalizedVCReport/tm_RationalizedVCRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
