######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : JULY-2025
#
#######################################################################################

echo -e "\n~~~~~~~~~~ S H E L L   S T A R T E D ~~~~~~~~~~~~"

echo -e "\nIn Shell Argument Print Started...."

echo "Report File: -----> "$1

echo "Fine Report File: -----> "$2

echo -e "\nDuplicate To Unique File Sort Started...."
sort -u $1 -o $2
echo -e "\nDuplicate To Unique File Sort Ended...."

echo -e "\n~~~~~~~~~~ S H E L L   E N D E D ~~~~~~~~~~~~"
