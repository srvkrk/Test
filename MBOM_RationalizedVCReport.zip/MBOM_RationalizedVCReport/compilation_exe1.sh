./compile tm_RationalizedVCRpt.c
./linkitk -o tm_RationalizedVCRpt tm_RationalizedVCRpt.o
chmod 777 tm_RationalizedVCRpt*
