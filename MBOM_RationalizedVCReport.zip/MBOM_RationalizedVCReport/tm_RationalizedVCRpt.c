/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   File Based Rationalized VC Reports on Input (VehicleNo, Revision, Sequence)
*  File Name    :   tm_RationalizedVCRpt.c
*  Created on   :   July 10th, 2025
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     10/07/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

FILE *Report = NULL;
int ctr = 0;
void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

int bom_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, FILE* FP_OutputReport, char* VNo, char* VRev, char* VSeq)
{
		char* cItem_Id = NULL;
		char* cItem_RevSeq = NULL;
		char* cItem_Rev = NULL;
		char* cItem_Seq = NULL;
		char* cItem_Desc = NULL;
		char* cModAddress = NULL;
		char* cProdLine = NULL;
		char* cProdLineDup = NULL;
		char* cPlatform = NULL;
		char* cPlatformDup = NULL;
		char* cProjCode = NULL;
	    char* cProjCodeDup = NULL;
	    char* cDesGrp = NULL;
	    char* cDesGrpDup = NULL;
		char* cArDrStatus = NULL;
		char* cArDrStatusDup = NULL;
		char* cPartType = NULL;
		char* cPartTypeDup = NULL;
		char* cQuantity = NULL;
		char* cQuantityDup = NULL;
	    tag_t PrtMstrTag = NULLTAG;
	    char *MstrUOMTag = NULL;
	    char *MstrUOMTagDup = NULL;
		int j =0;
		int iFail = ITK_ok;
		int iNumber_SubChild = 0;
		tag_t tChild = NULLTAG;
		tag_t* tSubChild = NULLTAG;
		char* LibStatus = NULL;
		char* LibRevStatus = NULL;
		char* LibSeqStatus = NULL;
		char* LibGateStatus = NULL;
		char* LibMaxGateStatus = NULL;
		char* LibVehLinkFreqStatus = NULL;
		int yescount = 0;
		int nocount = 0;
		int maxdrpasscount = 0;
		int maxdrfailcount = 0;
		int compliance = 0;
		int totalcount = 0;
		double finalcompliance;
		char total[10];
		char totalpresent[10];
		char totalnotpresent[10];
		char complianceper[10];
		char maxdrpasscountdup[10];
		char maxdrfailcountdup[10];
		int maxcompliance = 0;
		int allcompliance = 0;
		double maxdrfinalcompliance;
		double alldrfinalcompliance;
		char* totalpresentDup = NULL;
		char* totalnotpresentDup = NULL;
		char* maxdrpasscountdupfinal = NULL;
		char* maxdrfailcountdupfinal = NULL;
		int slno = 1;
		char finalslno[10];
		char DTStamp[100] = "";
		time_t 	dtnow;
		struct 	tm dtwhen;
		time(&dtnow);
		dtwhen = *localtime(&dtnow);
		strftime(DTStamp,100,"%d_%b_%Y_%H_%M_%S",&dtwhen);
		printf(" Current TimeStamp: [%s]\n", DTStamp);fflush(stdout);
		
		for(j = 0; j < iSubSubNumber_Child; j++)
		{	
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cItem_Id));
			trimwhitespace(cItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", cItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_item_revision_id", &cItem_RevSeq));
			trimwhitespace(cItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", cItem_RevSeq);fflush(stdout);
			
			cItem_Rev=strtok(cItem_RevSeq,";");
			cItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", cItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", cItem_Seq);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartType", &cPartType));
			if(tc_strlen(cPartType)>0)
			{
				tc_strdup(cPartType,&cPartTypeDup);
			}
			else
			{
				tc_strdup("--",&cPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(cPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", cPartTypeDup);fflush(stdout);
			
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nChild_Level Part No: [%s]", cItem_Id);
			printf("\nChild_Level Part Revision: [%s]", cItem_Rev);
			printf("\nChild_Level Part Sequence: [%s]", cItem_Seq);
			printf("\nChild_Level Part Type: [%s]", cPartTypeDup);
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(cPartTypeDup)>0)
		    {
				if(tc_strcmp(cPartTypeDup,"Module")==0)
				{
				    fprintf(FP_OutputReport,"%s^%s^%s^\n",cItem_Id,cItem_Rev,cItem_Seq);fflush(FP_OutputReport);
				}
			}
			/* ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found: [%d]\n",iNumber_SubChild);fflush(stdout);
			if(iNumber_SubChild > 0)
			{
				printf("\n!!!!!!!!!! I N N E R  C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(tSubChild,iNumber_SubChild,FP_OutputReport,VNo,VRev,VSeq);
			} */
		}
		
	return iFail;
}

int TC_VehChild_Details(char* Vehicle,char* VehicleRev,char* VehicleSeq,char* VehicleRS,FILE* VehRpt)
{
	tag_t top_Sub_Child_bom_window = NULLTAG;
	tag_t topsubrule = NULLTAG;
	int subrulefound = 0;
	tag_t* subclosurerule = NULL;
	tag_t sub_close_tag = NULLTAG;
	char** subrulename = NULL;
    char** subrulevalue = NULL;
	tag_t t_top_Sub_Child = NULLTAG;
	int iFail = ITK_ok;
	int itopSubNumber_Child = 0;
	tag_t* ttop_BOM_Children = NULLTAG;
	char* ctopSubItem_Id = NULL;
	char* ctopSubItem_RevSeq = NULL;
	char* ctopSubItem_Desc = NULL;
	char* ctopSubItem_Rev = NULL;
	char* ctopSubItem_Seq = NULL;
	char* ctopSubModAddress = NULL;
	char* ctopSubProdLine = NULL;
	char* ctopSubProdLineDup = NULL;
	char* ctopSubPlatform = NULL;
	char* ctopSubPlatformDup = NULL;
	char* ctopSubProjCode = NULL;
	char* ctopSubProjCodeDup = NULL;
	char* ctopSubDesGrp = NULL;
	char* ctopSubDesGrpDup = NULL;
	char* ctopSubArDrStatus = NULL;
	char* ctopSubArDrStatusDup = NULL;
	char* ctopSubPartType = NULL;
	char* ctopSubPartTypeDup = NULL;
	char* ctopSubQuantity = NULL;
	char* ctopSubQuantityDup = NULL;
	tag_t PartMasterTag	= NULLTAG;
	char *MstrUnitTag = NULL;
	char *MstrUnitTagDup = NULL;
	PIE_scope_t scope;
    scope = PIE_TEAMCENTER;
	
	
	tag_t top_item = NULLTAG;
	ITK_CALL(ITEM_find_item(Vehicle, &top_item));
	printf("\n API[ITEM_find_item] Success..!!\n");fflush(stdout);
	tag_t topchildrev = NULLTAG;
	//ITK_CALL(ITEM_find_rev(top_child_item_id, child_item_revision_id, &Childrev));
	ITK_CALL(ITEM_find_revision(top_item, VehicleRS, &topchildrev));
	printf("\n API[ITEM_find_revision] Success..!!\n");fflush(stdout);
	if(topchildrev != NULLTAG)
    {	
		ITK_CALL(BOM_create_window(&top_Sub_Child_bom_window));
		printf("\n API[BOM_create_window] Success..!!\n");fflush(stdout);
		ITK_CALL(CFM_find("MBOM Release and Above", &topsubrule));
		//ITK_CALL(CFM_find(RevRule, &topsubrule));
		printf("\n API[CFM_find] Revision Rule Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_config_rule(top_Sub_Child_bom_window, topsubrule));
        printf("\n API[BOM_set_window_config_rule] Success..!!\n");fflush(stdout);		
		ITK_CALL(PIE_find_closure_rules2("BOMViewClosureRuleMBOM",PIE_TEAMCENTER, &subrulefound, &subclosurerule));
		printf("\n API[PIE_find_closure_rules2] Closure Rule Find Success..!!\n");fflush(stdout);
		printf("\n No of Rule Found: [%d]\n",subrulefound);fflush(stdout);
		if (subrulefound > 0)
		{
			sub_close_tag = subclosurerule[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(top_Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
		printf("\n API[BOM_window_set_closure_rule] Closure Rule Set Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_pack_all(top_Sub_Child_bom_window, TRUE));
		printf("\n API[BOM_set_window_pack_all] BOM Window Pack Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_top_line(top_Sub_Child_bom_window, NULLTAG, topchildrev, NULLTAG, &t_top_Sub_Child));
		printf("\n API[BOM_set_window_top_line] Top Line Set Success..!!\n");fflush(stdout);
	    if(t_top_Sub_Child != NULLTAG)
        {
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_item_id", &ctopSubItem_Id));
			trimwhitespace(ctopSubItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", ctopSubItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_rev_item_revision_id", &ctopSubItem_RevSeq));
			trimwhitespace(ctopSubItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", ctopSubItem_RevSeq);fflush(stdout);
			
			ctopSubItem_Rev=strtok(ctopSubItem_RevSeq,";");
			ctopSubItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", ctopSubItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", ctopSubItem_Seq);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartType", &ctopSubPartType));
			if(tc_strlen(ctopSubPartType)>0)
			{
				tc_strdup(ctopSubPartType,&ctopSubPartTypeDup);
			}
			else
			{
				tc_strdup("--",&ctopSubPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", ctopSubPartTypeDup);fflush(stdout);
			
			printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nTop_Level Part No: [%s]", ctopSubItem_Id);
			printf("\nTop_Level Rev: [%s]", ctopSubItem_Rev);
			printf("\nTop_Level Seq: [%s]", ctopSubItem_Seq);
			printf("\nTop_Level Part Type: [%s]", ctopSubPartTypeDup);	
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(ctopSubPartTypeDup)>0)
		    {
				if(tc_strcmp(ctopSubPartTypeDup,"Module")==0)
				{
				   fprintf(VehRpt,"%s^%s^%s^\n",ctopSubItem_Id,ctopSubItem_Rev,ctopSubItem_Seq);fflush(VehRpt);
				}
			}
			ITK_CALL(BOM_line_ask_all_child_lines(t_top_Sub_Child, &itopSubNumber_Child, &ttop_BOM_Children));
			printf("\n API[BOM_line_ask_all_child_lines] Child Find Success..!!\n");fflush(stdout);
			printf("\n No of Children Found: [%d]\n",itopSubNumber_Child);fflush(stdout);
			if(itopSubNumber_Child>0)
			{
				printf("\n!!!!!!!!! C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(ttop_BOM_Children, itopSubNumber_Child, VehRpt, Vehicle, VehicleRev, VehicleSeq);
			}
        }
	    ITK_CALL(BOM_close_window(top_Sub_Child_bom_window));
	    printf("\n API[BOM_close_window] BOM Window Close Success..!!\n");fflush(stdout);
	}
	return iFail;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	char *RptFile = (char *) malloc(100*sizeof(char));
	char *FinalRptFile = (char *) malloc(100*sizeof(char));
	tag_t DesRev_tag = NULLTAG;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str = NULL;
	char *item_seq_strDup = NULL;
	char *item_drar_str = NULL;
	char *item_drar_strDup = NULL;
	char *Veh_Desc = NULL;
	char *Veh_DescDup = NULL;
	char *vplat_str = NULL;
	char *vplat_strDup = NULL;
	char *inp_id_str = NULL;
	char *inp_rev_str = NULL;
	char *inp_seq_str = NULL;
	char *inp_email_str = NULL;
	char *inp_id_strDup = NULL;
	char *inp_rev_strDup = NULL;
	char *inp_seq_strDup = NULL;
	char *inp_email_strDup = NULL;
	char *inp_revseq_strdup = (char *) malloc(20*sizeof(char));
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	fpPart_List = fopen("PartList.txt","r");
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	//tc_strcpy(RptFile,"/tmp/");
	//tc_strcat(RptFile,"VCR");
	tc_strcpy(RptFile,"Output_RationalizedVCReport");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".txt");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Name Generated..!!");fflush(stdout);
	FILE* fpOutput_file = fopen(RptFile, "w");
	//fprintf(fpOutput_file,"PART_NO, PART_REV, PART_SEQ\n");fflush(fpOutput_file);
	if(fpOutput_file == NULL)
	{
		printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
						
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			inp_id_str=strtok(Buffer,"^");
			inp_rev_str=strtok(NULL,"^");
			inp_seq_str=strtok(NULL,"^");
			
			if(inp_id_str!=NULL)tc_strdup(inp_id_str,&inp_id_strDup);
			if(inp_rev_str!=NULL)tc_strdup(inp_rev_str,&inp_rev_strDup);
			if(inp_seq_str!=NULL)tc_strdup(inp_seq_str,&inp_seq_strDup);
			
			if(inp_id_strDup!=NULL)trimwhitespace(inp_id_strDup);
			if(inp_rev_strDup!=NULL)trimwhitespace(inp_rev_strDup);
			if(inp_seq_strDup!=NULL)trimwhitespace(inp_seq_strDup);
			
			tc_strcpy(inp_revseq_strdup,inp_rev_strDup);
			tc_strcat(inp_revseq_strdup,"*");
			tc_strcat(inp_revseq_strdup,inp_seq_strDup);
			printf(" Final: Part_Rev_Seq Value(inp_revseq_strdup): [%s]\n",inp_revseq_strdup);
			
			printf(" [1]: Input Part No(inp_id_strDup): [%s]\n",inp_id_strDup);
	        printf(" [2]: Input Part Rev(inp_rev_strDup): [%s]\n",inp_rev_strDup);
	        printf(" [3]: Input Part Seq(inp_seq_strDup): [%s]\n",inp_seq_strDup);
	
			printf("\n Finding Query[DesignRevision Sequence]..!!\n");fflush(stdout);
			ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
			if(tItemobj != NULLTAG)
			{
				printf("\n DesignRevision Sequence Query Found Successfully..!!\n");fflush(stdout);
				char *cEntries[2]  = {"Revision","ID"};
				char *cValues[2]  = {inp_revseq_strdup,inp_id_strDup};
				//char *cValues[2]  = {"A*2","51780353R"};
				ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n  No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
					printf(" Queried Design Revision & Sequence Found..!!\n");fflush(stdout);
					for(i = 0; i < n_itemobj_found; i++)
					{
						DesRev_tag = titemobj_results[i];
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&item_id_str));
						if(tc_strlen(item_id_str)>0)
						{
							tc_strdup(item_id_str,&item_id_strDup);
							trimwhitespace(item_id_strDup);
						}
						else
						{
							tc_strdup("--",&item_id_strDup);
							printf("\n Vehicle Number Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_revision_id",&item_revseq_str));
						if(tc_strlen(item_revseq_str)>0)
						{
							tc_strdup(item_revseq_str,&item_revseq_strDup);
							trimwhitespace(item_revseq_strDup);
						}
						else
						{
							tc_strdup("--",&item_revseq_strDup);
							printf("\n Vehicle Revision Sequence Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_revision_id",&Newitem_revseq_str));
						if(tc_strlen(Newitem_revseq_str)>0)
						{
							tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
							trimwhitespace(Newitem_revseq_strDup);
							item_rev_str=strtok(Newitem_revseq_strDup,";");
							item_seq_str=strtok(NULL,";");
							if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
							if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
							trimwhitespace(item_rev_strDup);
							trimwhitespace(item_seq_strDup);
						}
						else
						{
							tc_strdup("--",&Newitem_revseq_strDup);
							printf("\n [New]Vehicle Revision Sequence Value is NULL..!!");fflush(stdout);
						}
						printf("\n  Vehicle Number: [%s]\n",item_id_strDup);fflush(stdout);
						printf("\n  Vehicle Revision & Sequence: [%s]\n",item_revseq_strDup);fflush(stdout);
						printf("\n  Vehicle Revision: [%s]\n",item_rev_strDup);fflush(stdout);
						printf("\n  Vehicle Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
	
						printf("\n Function1: Vehicle Child Details Find Start\n");fflush(stdout);
						TC_VehChild_Details(item_id_strDup,item_rev_strDup,item_seq_strDup,item_revseq_strDup,fpOutput_file);
						printf("\n Function1: Vehicle Child Details Find End\n");fflush(stdout);
					}
				}
				else
				{
					printf(" Revision Found Zero[0] After DesRev_ERC_Rlzd Query..!!\n");fflush(stdout);
				}
			}
			else
			{
				printf(" DesRev_ERC_Rlzd Tag Not Found..!!\n");fflush(stdout);
			}
	    }
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	fclose(fpPart_List);
	fclose(fpOutput_file);
	printf(" All ERC Released Vehicles Compliance Report Generation End..!!\n");fflush(stdout);
	
	printf("\n Generating Unique Report File Name..!!");fflush(stdout);
	//tc_strcpy(RptFile,"/tmp/");
	//tc_strcat(RptFile,"UniqueRationalizedVCReport");
	tc_strcpy(FinalRptFile,"Input");
	tc_strcat(FinalRptFile,"_");
	tc_strcat(FinalRptFile,"GenObsoleteStatus");
	tc_strcat(FinalRptFile,".txt");
	printf("\n Final Report File Name: [%s]", FinalRptFile);fflush(stdout);
	printf("\n Unique Report File Name Generated..!!");fflush(stdout);
	printf("Duplicate File To Unique File Move Start..!!\n");fflush(stdout);
	char* ShellCommandLine = NULL;
	ShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
	tc_strcpy(ShellCommandLine,"/user/cvprod/sourav/RationalizedVCReport/DuplicateRemove.sh");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,RptFile);
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,FinalRptFile);
	system(ShellCommandLine);
	printf("Duplicate File To Unique File Move End..!!\n");fflush(stdout);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_RationalizedVCRpt.c
* // ./linkitk -o tm_RationalizedVCRpt tm_RationalizedVCRpt.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/RationalizedVCReport/tm_RationalizedVCRpt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/RationalizedVCReport/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/RationalizedVCReport/usage.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/RationalizedVCReport/SendEmail.sh .
* // ./tm_RationalizedVCRpt -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_RationalizedVCRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/