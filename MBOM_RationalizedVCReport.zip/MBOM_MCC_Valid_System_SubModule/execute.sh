/user/cvprod/sourav/MBOM_MCC_Valid_System_SubModule/tm_mbom_mcc_valid_system_submodule -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
