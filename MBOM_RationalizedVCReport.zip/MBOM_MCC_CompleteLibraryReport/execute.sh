/user/cvprod/sourav/MBOM_MCC_CompleteLibraryReport/tm_mbom_mcc_complete_library_report -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
