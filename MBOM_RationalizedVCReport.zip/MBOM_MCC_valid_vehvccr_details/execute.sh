/user/cvprod/sourav/MBOM_MCC_valid_vehvccr_details/tm_mbom_mcc_valid_vehvccr -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
