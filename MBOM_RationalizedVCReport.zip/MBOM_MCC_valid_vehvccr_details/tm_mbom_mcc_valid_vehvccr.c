/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query MBOM MCC applicable released Vehicle & Vehicle Combination CR on the basis of BVR Present or not  
*  File Name    :   tm_mbom_mcc_valid_vehvccr.c
*  Created on   :   Nov 11th, 2025
*  Executable   :   tm_mbom_mcc_valid_vehvccr
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     11/11/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int isValidLengthAndDigits(const char *str)
{
    int len = tc_strlen(str);

    if (len != 9 && len != 12)
        return 0;

    return 1;
}

char* TC_MBOMStatusCheck(tag_t PartRev_tag)
{
	int status = 0;
	tag_t *Stat_list = NULLTAG;
	tag_t Stat_tag = NULLTAG;
	int Stat_Cnt = 0;
	char *RlzStatusName = NULL;
	char *RlzStatusDup = NULL;
	int j = 0;

    ITK_CALL(WSOM_ask_release_status_list(PartRev_tag,&Stat_Cnt,&Stat_list));
    for(j=0;j<Stat_Cnt;j++)
	{
		Stat_tag = Stat_list[j];
		ITK_CALL(AOM_ask_name(Stat_tag, &RlzStatusName));
		printf("\n Part`s Release Status Name: [%s]\n",RlzStatusName);fflush(stdout);
		if ((tc_strcmp(RlzStatusName,"T5_MBOMReleased")==0) || (tc_strcmp(RlzStatusName,"MBOM Released")==0))
		{
			tc_strdup("YES",&RlzStatusDup);
		}
	}
	if(tc_strlen(RlzStatusDup)>0)
	{
	   printf("\n Part`s Release Status Return Already Received ");fflush(stdout);
	}
	else
	{
	   tc_strdup("NO",&RlzStatusDup);
	}

    return RlzStatusDup;
}

int TC_MCCValid_Details(char *PType, FILE *VRpt)
{	
	//trimwhitespace(PType);
	char *item_id_str = NULL;
	char *item_revseq_str = NULL;
	char *item_rev_str = NULL;
	char *item_seq_str = NULL;
	char *item_product_str = NULL;
	char *item_bypass_str = NULL;
	char *item_id_strDup = NULL;
	char *item_revseq_strDup = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	char *item_product_strDup = NULL;
	char *item_bypass_strDup = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 4;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	tag_t DesRev_tag = NULLTAG;
	int ChldCount = 0;
	tag_t *PartChildTags = NULLTAG;
	int iFail = ITK_ok;
	char *MBOMStatus = NULL;
	char *PartRelStatus = NULL;
	
	printf("\n Searched Part Type: [%s]\n", PType);fflush(stdout);
	ITK_CALL(QRY_find2("MCC_ERC_Released_Latest_Revision",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query [MCC_ERC_Released_Latest_Revision] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[4]  = {"Item ID","Release Status","Part Type","Type"};
		char *cValues[4]  = {"*","T5_MBOMReleased",PType,"Design Revision"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf("\n Query [MCC_ERC_Released_Latest_Revision] Found..!!\n");fflush(stdout);
			for (i = 0; i < n_itemobj_found; i++)
			{
				DesRev_tag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&item_id_str));
				if(tc_strlen(item_id_str)>0)
				{
					tc_strdup(item_id_str,&item_id_strDup);
				}
				else
				{
					tc_strdup("--",&item_id_strDup);
					printf("\n Part_No Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_revision_id",&item_revseq_str));
				if(tc_strlen(item_revseq_str)>0)
				{
					tc_strdup(item_revseq_str,&item_revseq_strDup);
					item_rev_strDup=tc_strtok(item_revseq_strDup,";");
					item_seq_strDup=tc_strtok(NULL,";");
				}
				else
				{
					tc_strdup("--",&item_revseq_strDup);
					tc_strdup("--",&item_rev_strDup);
					tc_strdup("--",&item_seq_strDup);
					printf("\n Part Rev_seq Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_Product",&item_product_str));
				if(tc_strlen(item_product_str)>0)
				{
					tc_strdup(item_product_str,&item_product_strDup);
				}
				else
				{
					tc_strdup("--",&item_product_strDup);
					printf("\n Part Product Line Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_SgrIntialAgency",&item_bypass_str));
				if(tc_strlen(item_bypass_str)>0)
				{
					tc_strdup(item_bypass_str,&item_bypass_strDup);
				}
				else
				{
					tc_strdup("NA",&item_bypass_strDup);
					printf("\n Part Bypass Value is NULL..!!");fflush(stdout);
				}
				//printf("\n Function1: MBOM Status Find Start");fflush(stdout);
                //MBOMStatus = TC_MBOMStatusCheck(DesRev_tag);
                //printf("\n Function1: MBOM Status Find End\n");fflush(stdout);
                //printf("\n Return MBOM Status: [%s]\n",MBOMStatus);fflush(stdout);
				//ITK_CALL(AOM_ask_value_tags(DesRev_tag,"ps_children",&ChldCount,&PartChildTags));
				//if(ChldCount>0)
				ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"release_status_list",&PartRelStatus));
				printf("\n \033[32m>>>>> Part Release Status: [%s]  🔥 \033[0m<<<<<<\n",PartRelStatus);fflush(stdout);
				if(((tc_strstr(PartRelStatus,"MBOM Released")!=NULL)||
				   (tc_strstr(PartRelStatus,"APLC Released")!=NULL)||
		           (tc_strstr(PartRelStatus,"APLP Released")!=NULL)||
		           (tc_strstr(PartRelStatus,"APLD Released")!=NULL)||
		           (tc_strstr(PartRelStatus,"APLU Released")!=NULL)||
		           (tc_strstr(PartRelStatus,"APLJ Released")!=NULL)||
		           (tc_strstr(PartRelStatus,"APLL Released")!=NULL)||
		           (tc_strstr(PartRelStatus,"APLA Released")!=NULL)||
				   (tc_strstr(PartRelStatus,"STDSIC Released")!=NULL)||
				   (tc_strstr(PartRelStatus,"STDSIP Released")!=NULL)||
				   (tc_strstr(PartRelStatus,"STDSID Released")!=NULL)||
				   (tc_strstr(PartRelStatus,"STDSIU Released")!=NULL)||
				   (tc_strstr(PartRelStatus,"STDSIJ Released")!=NULL)||
				   (tc_strstr(PartRelStatus,"STDSIL Released")!=NULL)||
				   (tc_strstr(PartRelStatus,"STDSIA Released")!=NULL))&&
				   (tc_strstr(PartRelStatus,"Obsolete")==NULL))
					{
						if(tc_strlen(item_bypass_strDup)>0)
						{
							if(tc_strcmp(item_bypass_strDup,"VEHICLE_MIGRATED_FOR_ECU_TRANSFER")==0)
							{
							   printf("\n Item Already ByPass...!!\n");fflush(stdout);
							}
							else
							{
								if(isValidLengthAndDigits(item_id_strDup))
                                {
								   printf("[1] Part_No: [%s]\n",item_id_strDup);fflush(stdout);
								   printf("[2] Revision: [%s]\n",item_rev_strDup);fflush(stdout);
								   printf("[3] Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
								   printf("[4] Product_Line: [%s]\n",item_product_strDup);fflush(stdout);
								   fprintf(VRpt,"%s^%s^%s^%s^\n",item_id_strDup,item_rev_strDup,item_seq_strDup,item_product_strDup);fflush(VRpt);
								}
								else
								{
									 printf("\n Part Length not Valid...!!\n");fflush(stdout);
								}
							}
						}
					}
			}
		}
		else
		{
			printf(" Query [MCC_ERC_Released_Latest_Revision] Not Found..!!\n");fflush(stdout);
		}
	}
	else
	{
		printf(" [MCC_ERC_Released_Latest_Revision] Query Tag Not Found..!!\n");fflush(stdout);
	}
	
	return iFail;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"mbom_mcc_valid_vehvccr");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".txt");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	 
    fpOutput_file = fopen(RptFile, "w");
    //fprintf(fpOutput_file,"PART_NO, REV, SEQ, PRODUCT_LINE\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	
	printf("\n Function1: MCC Valid Vehicle Details Find Start\n");fflush(stdout);
	TC_MCCValid_Details("V",fpOutput_file);
	printf("\n Function1: MCC Valid Vehicle Details Find End\n");fflush(stdout);
	
	printf("\n Function2: MCC Valid Vehicle Combination CR Details Find Start\n");fflush(stdout);
	TC_MCCValid_Details("VCCR",fpOutput_file);
	printf("\n Function2: MCC Valid Vehicle Combination CR Details Find End\n");fflush(stdout);
		
	//fprintf(fpOutput_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpOutput_file);	
	printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout); 
	
	printf("File Copy From Generated Location To Orginal Location Start..!!\n");fflush(stdout);
	char* ShellCommandLine = NULL;
	ShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
	tc_strcpy(ShellCommandLine,"/user/cvprod/sourav/MBOM_MCC_valid_vehvccr_details/ProcessFiles.sh");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,RptFile);
	system(ShellCommandLine);
	printf("File Copy From Generated Location To Orginal Location End..!!\n");fflush(stdout);
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_mbom_mcc_valid_vehvccr.c
* // ./linkitk -o tm_mbom_mcc_valid_vehvccr tm_mbom_mcc_valid_vehvccr.o
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_MCC_valid_vehvccr_details/tm_mbom_mcc_valid_vehvccr .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_MCC_valid_vehvccr_details/exepatch.sh .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_MCC_valid_vehvccr_details/usage.txt .
* // scp cvprod@172.22.99.106:/user/cvprod/sourav/MBOM_MCC_valid_vehvccr_details/SendEmail.sh .
* // ./tm_mbom_mcc_valid_vehvccr -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_mbom_mcc_valid_vehvccr -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_mbom_mcc_valid_vehvccr -u=loader -p=loader123 -g=dba
*
***************************************************************************/