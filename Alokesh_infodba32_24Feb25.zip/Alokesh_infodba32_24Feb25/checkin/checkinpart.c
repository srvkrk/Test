/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:checkinpart.c
*
* Description		: > This Utility is to do unit testing of functions .
* Module  		        
* Since		    :    

* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 18/05/2023   	Sanjoy Mondal			    Initial Code

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <tc/envelope.h>
#include <tccore/aom_prop.h>
#define MAX_LINE_LEN 10240
#define IFERR_ABORT(X)  (report_error( __FILE__, __LINE__, #X, X, TRUE))
#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))

static void ECHO(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int report_error(char *file, int line, char *call, int status,
    logical exit_on_error)
{
    if (status != ITK_ok)
    {
        int
            n_errors = 0;
        const int
            *severities = NULL,
            *statuses = NULL;
        const char
            **messages;

        EMH_ask_errors(&n_errors, &severities, &statuses, &messages);
        if (n_errors > 0)
        {
            ECHO("\n%s\n", messages[n_errors-1]);
            EMH_clear_errors();
        }
        else
        {
            char *error_message_string;
            //EMH_get_error_string (NULLTAG, status, &error_message_string);
            //ECHO("\n%s\n", error_message_string);
        }

        ECHO("error %d at line %d in %s\n", status, line, file);
        ECHO("%s\n", call);
        if (exit_on_error)
        {
            ECHO("%s", "Exiting program!\n");
            exit (status);
        }
    }
    return status;
}



/*
#define ITKCALL( argument )                                             \
{                                                                       \
    int retcode = argument;                                             \
    if ( retcode != ITK_ok ) {                                          \
        char* s;                                                        \
        printf( " "#argument "\n" );                                    \
        printf( "  returns [%d]\n", retcode );                          \
        EMH_ask_error_text (retcode, &s);                               \
        printf( "  Teamcenter ERROR: [%s]\n", s);           \
        printf( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
        if (s != 0) MEM_free (s);                                       \
    }                                                                   \
}*/


#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static void handle_itk_error
    ( int stat,                               /* <I> */
      int source_code_line,                   /* <I> */
      const char *source_code_file_name       /* <I> */
    );

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}




/************************START OF UTILITY FUNCTIONS**************************************/

/* right trim */
char *rtrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int index=0;    /* index of the last non-space char */

    /* validate input */
    if (!str)
        return str;

    /* copy the string */
    while(*src){
        *dst++ = *src++;
        c = *src;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;
        else
            is_space=0;

        if (is_space==0 && *src)
            index = (src-str)+1;
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

/* left trim */
char *ltrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int index=0;    /* index of the first non-space char */

    /* validate input */
    if (!str)
        return str;

    /* skip leading white-spaces */
    while((c=*src)){ 
        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' '){
            ++src;
            ++index;
        } else
            break;
    }

    /* copy rest of the string */
    while(*src)
        *dst++ = *src++;

    /* terminate the string */
    *(src-index)='\0';

    return str;
}


int getPartObjFromRevSeq(char* partnumber, char* rev, char* seq, tag_t *partObj)
{
	int ifail = ITK_ok;
	
	int  count 	= 0;
	tag_t *itemObjs = NULLTAG;
	char* revStr = NULL;
	int seqInt = 0;
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "Item ID";
	qry_entries[1] = "Type";
	//qry_entries[2] = "Sequence Id";
	
	qry_values[0] = partnumber;
	revStr = (char *) MEM_alloc( 10 * sizeof(char) );
	//tc_strcpy(revStr,"");
	tc_strcpy(revStr,rev);
	tc_strcat(revStr,";");
	tc_strcat(revStr,seq);
	
	qry_values[1] = "Design Revision";
	
	//trimLeading(revStr);
	char* revStr1 = NULL;
	char* revStr2 = NULL;
	revStr1 = ltrimString(revStr);
	revStr2 = rtrimString(revStr1);
	
	
		
	
	
	CALLAPI(QRY_find2("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObjs));
	printf("\n getPartObjFromRevSeq: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		int k=0;
		char* revS = NULL;
		for(k=0;k<count;k++)
		{
			CALLAPI(AOM_ask_value_string(itemObjs[k],"item_revision_id",&revS));
			
			if(revS==NULL) continue;
			if(tc_strcmp(revS,revStr2)==0)
			{
				*partObj = itemObjs[k];
				break;
			}
			
		}
	}
	
	if(revStr!=NULL) MEM_free(revStr);
	return ifail;	

}


/*************************END OF UTILITY FUNCTIONS*********************************************/





int tmCheckinPart(char* partNo, char* rev, char* seq)
{
	int ifail = ITK_ok;
	tag_t partTag = NULLTAG;
	CALLAPI(getPartObjFromRevSeq(partNo,rev,seq,&partTag));
	
	if(partTag!=NULLTAG)
	{
		logical chkOut = FALSE;
		char* partname = NULL;
		CALLAPI(AOM_ask_value_string(partTag,"object_string",&partname));
		printf("\nPart==>%s\n",partname);fflush(stdout);
		
		RES_is_checked_out(partTag,&chkOut);
		
		if(chkOut)
		{
			RES_checkin(partTag);
			
		}
		else
		{
			printf("\nPart %s;%s,%s is already checked in.\n",partNo,rev,seq);fflush(stdout);
		}
	}
	else
	{
		printf("\nPart %s;%s,%s not found.\n",partNo,rev,seq);fflush(stdout);
	}
	
	return ifail;
} 

int ITK_user_main(int argc, char* argv[])
{
	
	
	int ifail = ITK_ok;
	
	ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
	
	
	printf("\n*********** Start Of Main function ************* \n");fflush(stdout);	
	
	if(ITK_auto_login() == ITK_ok)	
	{
		char* username = NULL;
		tag_t user_tag = NULLTAG;
		char *partnumber = ITK_ask_cli_argument("-partno=");
		char *revision = ITK_ask_cli_argument("-rev=");
		char *seqno = ITK_ask_cli_argument("-seq=");
		
		ITK_set_journalling( TRUE );
		printf("\nSAN:PartCheckin: Login successfull.\n");fflush(stdout);
		
			
		
		POM_get_user(&username,&user_tag);
		printf("\nSAN:Session User Name[%s]\n",username);fflush(stdout);
		
		printf("\nSAN:Input Parameters:Input Part no:[%s;%s,%s]\n",partnumber,revision,seqno);fflush(stdout);
		
		ifail = tmCheckinPart(partnumber, revision,seqno);
		
		
	}
	

	
	
	printf("\n*********** End Of Main function ************* \n");fflush(stdout);
	ITK_exit_module(TRUE);
	return ITK_ok;
}



