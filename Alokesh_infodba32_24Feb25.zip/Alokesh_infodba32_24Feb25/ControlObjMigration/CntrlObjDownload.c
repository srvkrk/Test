/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File			 :   Cntrlobj.c
*  Author		 :   Sudhir
*  Module		 :   Control Object create in TCUA
*                            
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <ctype.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <ae/dataset.h>
#include <tccore/aom_prop.h>

static void handle_ifail(char *file, int line);
static void MultiExplosion (tag_t line, char *Plant, tag_t line1, int depth,FILE *fd,int reqLevel,int level);
static void MultiExplosionLinkInfo (tag_t line, char *Plant, tag_t line1, int depth,FILE *fd,char *Uidd,int reqLevel,int level);
#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;


void trimLeading(char * str)
{
    int index, i, j;

    index = 0;

    /* Find last index of whitespace character */
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }


    if(index != 0)
    {
        /* Shit all trailing characters to its left */
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; // Make sure that string is NULL terminated
    }
}

char* removeChar(char *str, char garbage) 
{

	int i=0;
    char s[500];
	char *retstr = NULL; 
	retstr=(char *)MEM_alloc(600);
	strcpy( s, str);
    while(s[i]!='\0')
    {
        if(s[i]==garbage)
        {
            s[i]='-';
        }
        i++;
    }  
	printf("FILENAME IS -->%s",s);
	strcpy( retstr, s);
	printf("\nretstr IS -->%s",retstr);

	return retstr;
}

int ITK_user_main(int argc,char* argv[])
{
	int z;
	int status;

	tag_t dml_type_tag                            = NULLTAG;
	tag_t object_create_input_tag                 = NULLTAG;
	tag_t new_object                              = NULLTAG;
	tag_t rev_type_tag                            = NULLTAG;
	
	FILE* fptr = NULL;
				
	char *inputfile = NULL;	
	char *inputline = NULL;
	
	char	*ControlObject			= NULL;
	char	*syscd		= NULL;
	char	*subsyscd	= NULL;
	char	*itemId	= NULL;
	
	
	char	*info1		= NULL;


	char	*info2		= NULL;

	char	*info3	= NULL;

	char	*info4		= NULL;

	int j=0;
	int flagFound=0;
	
	
	ITK_CALL(ITK_set_journalling( TRUE ));
	ITK_CALL(ITK_initialize_text_services (0));
	printf("\n\n\t Attempting Logging\n ");

	z=ITK_CALL(ITK_auto_login());
	if(z!=ITK_ok)
	{
		printf("\n\n\t OMG Login Not Successfull\n ");
	}
	else
	{
	  printf("\n\n\t Login Successfull\n ");
	}

	
	printf("\n\n\t Login Successfull\n ");
	fptr=fopen("input.txt","w");
	printf("\n file write .......");fflush(stdout);
	
	char *Information1=NULL;
	char *Information2=NULL;
	char *Information3=NULL;
	char *Information4=NULL;
	char *Information5=NULL;
	char *Information6=NULL;
	char *Information7=NULL;
	char *Information8=NULL;
	char *Information9=NULL;
	char *recordtype=NULL;
	char *Syscd=NULL;
	char *SubSyscd=NULL;
	char *control_objname=NULL;

	char *Information1Dup=NULL;
	char *Information2Dup=NULL;
	char *Information3Dup=NULL;
	char *Information4Dup=NULL;
	char *Information5Dup=NULL;
	char *Information6Dup=NULL;
	char *Information7Dup=NULL;
	char *Information8Dup=NULL;
	char *Information9Dup=NULL;
	char *recordtypeDup=NULL;
	char *SyscdDup=NULL;
	char *SubSyscdDup=NULL;
	char *control_objnameDup=NULL;

	logical XferDone = false;
	logical DelInd = false;
	char *userinfo10=NULL;
	char *XferDoneDup=NULL;
	char *DelIndDup=NULL;
	char *userinfo10Dup=NULL;

	const char* u = NULL;
    const char* p = NULL;
    const char* g = NULL;

    int
        //error_code = ITK_ok,
        n_entries = 2,
        n_found = 0,
        ii = 0;
	
    tag_t
        query = NULLTAG,
        *cntr_objects = NULL;
       

	char
        *qry_entries[2] = {"SYSCD","SUBSYSCD"},
        *qry_values[2]	= {"*","*"};

	u = ITK_ask_cli_argument( "-u=");
	p = ITK_ask_cli_argument( "-p=");
	g = ITK_ask_cli_argument( "-g=");

	if (ITK_init_module(u,p,g) == ITK_ok )
	{

    ITK_CALL(QRY_find2("Control Objects...", &query));
    ITK_CALL(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
    printf("\n n_found=>%d", n_found);fflush(stdout);
	
	//fprintf(fptr,"NAME~SYSCD~SUBSYSCD~Info1~Info2~Info3~Info4~Info5~Info6~Info7~Info8~Info9~RecordType~",control_objnameDup);
	for (j=0;j<n_found;j++)
	{
	
		ITK_CALL ( AOM_ask_value_string(cntr_objects[j],"t5_Userinfo1",&Information1));
		ITK_CALL ( AOM_ask_value_string(cntr_objects[j],"t5_Userinfo2",&Information2));
		ITK_CALL ( AOM_ask_value_string(cntr_objects[j],"t5_Userinfo3",&Information3));
		ITK_CALL ( AOM_ask_value_string(cntr_objects[j],"t5_Userinfo4",&Information4));
		ITK_CALL ( AOM_ask_value_string(cntr_objects[j],"t5_Userinfo5",&Information5));
		ITK_CALL ( AOM_ask_value_string(cntr_objects[j],"t5_Userinfo6",&Information6));
		ITK_CALL ( AOM_ask_value_string(cntr_objects[j],"t5_Userinfo7",&Information7));
		ITK_CALL ( AOM_ask_value_string(cntr_objects[j],"t5_Userinfo8",&Information8));
		ITK_CALL ( AOM_ask_value_string(cntr_objects[j],"t5_Userinfo9",&Information9));
		ITK_CALL ( AOM_ask_value_string(cntr_objects[j],"t5_RecordType",&recordtype));

		ITK_CALL ( AOM_ask_value_string(cntr_objects[j],"t5_Syscd",&Syscd));
		ITK_CALL ( AOM_ask_value_string(cntr_objects[j],"t5_SubSyscd",&SubSyscd));
		ITK_CALL ( AOM_ask_value_string(cntr_objects[j],"object_name",&control_objname));

		ITK_CALL ( AOM_ask_value_logical(cntr_objects[j],"t5_XferDone",&XferDone));
		ITK_CALL ( AOM_ask_value_logical(cntr_objects[j],"t5_DelInd",&DelInd));
		ITK_CALL ( AOM_ask_value_string(cntr_objects[j],"t5_userinfo10",&userinfo10));

		Information1Dup = strdup(Information1);
		Information2Dup = strdup(Information2);
		Information3Dup = strdup(Information3);
		Information4Dup = strdup(Information4);
		Information5Dup = strdup(Information5);
		Information6Dup = strdup(Information6);
		Information7Dup = strdup(Information7);
		Information8Dup = strdup(Information8);
		Information9Dup = strdup(Information9);
		SyscdDup = strdup(Syscd);
		SubSyscdDup = strdup(SubSyscd);
		control_objnameDup = strdup(control_objname);
		recordtypeDup = strdup(recordtype);

		if(XferDone == TRUE)
		{
			XferDoneDup= strdup("1");
		}
		else
		{
			XferDoneDup= strdup("0");
		}

		if(DelInd == TRUE)
		{
			DelIndDup= strdup("1");
		}
		else
		{
			DelIndDup= strdup("0");
		}
		
		userinfo10Dup= strdup(userinfo10);

		if(Information1Dup!=NULL)Information1Dup = removeChar(Information1Dup, '\n');
		if(Information2Dup!=NULL)Information2Dup = removeChar(Information2Dup, '\n');
		if(Information3Dup!=NULL)Information3Dup = removeChar(Information3Dup, '\n');
		if(Information4Dup!=NULL)Information4Dup = removeChar(Information4Dup, '\n');
		if(Information5Dup!=NULL)Information5Dup = removeChar(Information5Dup, '\n');
		if(Information6Dup!=NULL)Information6Dup = removeChar(Information6Dup, '\n');
		if(Information7Dup!=NULL)Information7Dup = removeChar(Information7Dup, '\n');
		if(Information8Dup!=NULL)Information8Dup = removeChar(Information8Dup, '\n');
		if(Information9Dup!=NULL)Information9Dup = removeChar(Information9Dup, '\n');
		if(SyscdDup!=NULL)SyscdDup = removeChar(SyscdDup, '\n');
		if(SubSyscdDup!=NULL)SubSyscdDup = removeChar(SubSyscdDup, '\n');
		if(control_objnameDup!=NULL)control_objnameDup = removeChar(control_objnameDup, '\n');
		if(recordtypeDup!=NULL)recordtypeDup = removeChar(recordtypeDup, '\n');

		/*if(XferDoneDup!=NULL)XferDoneDup = removeChar(XferDoneDup, '\n');
		if(DelIndDup!=NULL)DelIndDup = removeChar(DelIndDup, '\n');*/
		if(userinfo10Dup!=NULL)userinfo10Dup = removeChar(userinfo10Dup, '\n');

		 printf("\n Information1Dup=>[%s]", Information1Dup);fflush(stdout);
		 printf("\n Information2Dup=>[%s]", Information2Dup);fflush(stdout);
		 printf("\n Information3Dup=>[%s]", Information3Dup);fflush(stdout);
		 printf("\n Information4Dup=>[%s]", Information4Dup);fflush(stdout);
		 printf("\n Information5Dup=>[%s]", Information5Dup);fflush(stdout);
		 printf("\n Information6Dup=>[%s]", Information6Dup);fflush(stdout);
		 printf("\n Information7Dup=>[%s]", Information7Dup);fflush(stdout);
		 printf("\n Information8Dup=>[%s]", Information8Dup);fflush(stdout);
		 printf("\n Information9Dup=>[%s]", Information9Dup);fflush(stdout);
		 printf("\n SyscdDup=>[%s]", SyscdDup);fflush(stdout);
		 printf("\n SubSyscdDup=>[%s]", SubSyscdDup);fflush(stdout);
		 printf("\n control_objnameDup=>[%s]", control_objnameDup);fflush(stdout);
		 printf("\n recordtypeDup=>[%s]", recordtypeDup);fflush(stdout);

		 printf("\n XferDoneDup=>[%s]", XferDoneDup);fflush(stdout);
		 printf("\n DelIndDup=>[%s]", DelIndDup);fflush(stdout);
		 printf("\n userinfo10Dup=>[%s]", userinfo10Dup);fflush(stdout);
		

		if(tc_strlen(control_objnameDup)>0)
		{
			fprintf(fptr,"%s",control_objnameDup);
			fprintf(fptr,"~");
		}
		else
		{
			fprintf(fptr,"~");
		}
		
		if(tc_strlen(SyscdDup)>0)
		{
			fprintf(fptr,"%s",SyscdDup);
			fprintf(fptr,"~");
		}
		else
		{
			fprintf(fptr,"~");
		}
		
		if(tc_strlen(SubSyscdDup)>0)
		{
			fprintf(fptr,"%s",SubSyscdDup);
			fprintf(fptr,"~");
		}
		else
		{
			fprintf(fptr,"~");
		}

		if(tc_strlen(Information1Dup)>0)
		{
			fprintf(fptr,"%s",Information1Dup);
			fprintf(fptr,"~");
		}
		else
		{
			fprintf(fptr,"~");
		}
		
		if(tc_strlen(Information2Dup)>0)
		{
			fprintf(fptr,"%s",Information2Dup);
			fprintf(fptr,"~");
		}
		else
		{
			fprintf(fptr,"~");
		}

		if(tc_strlen(Information3Dup)>0)
		{
			fprintf(fptr,"%s",Information3Dup);
			fprintf(fptr,"~");
		}
		else
		{
			fprintf(fptr,"~");
		}

		if(tc_strlen(Information4Dup)>0)
		{
			fprintf(fptr,"%s",Information4Dup);
			fprintf(fptr,"~");
		}
		else
		{
			fprintf(fptr,"~");
		}
		
		if(tc_strlen(Information5Dup)>0)
		{
			fprintf(fptr,"%s",Information5Dup);
			fprintf(fptr,"~");
		}
		else
		{
			fprintf(fptr,"~");
		}
		
		if(tc_strlen(Information6Dup)>0)
		{
			fprintf(fptr,"%s",Information6Dup);
			fprintf(fptr,"~");
		}
		else
		{
			fprintf(fptr,"~");
		}

		if(tc_strlen(Information7Dup)>0)
		{
			fprintf(fptr,"%s",Information7Dup);
			fprintf(fptr,"~");
		}
		else
		{
			fprintf(fptr,"~");
		}
		
		if(tc_strlen(Information8Dup)>0)
		{
			fprintf(fptr,"%s",Information8Dup);
			fprintf(fptr,"~");
		}
		else
		{
			fprintf(fptr,"~");
		}

		if(tc_strlen(Information9Dup)>0)
		{
			fprintf(fptr,"%s",Information9Dup);
			fprintf(fptr,"~");
		}
		else
		{
			fprintf(fptr,"~");
		}

		if(tc_strlen(recordtypeDup)>0)
		{
			fprintf(fptr,"%s",recordtypeDup);
			fprintf(fptr,"~");
		}
		else
		{
			fprintf(fptr,"~");
		}

		if(tc_strlen(DelIndDup)==0)
		{
			fprintf(fptr,"1");
			fprintf(fptr,"~");
		}
		else
		{
			fprintf(fptr,"0");
			fprintf(fptr,"~");
		}

		if(tc_strlen(XferDoneDup)==0)
		{
			fprintf(fptr,"1");
			fprintf(fptr,"~");
		}
		else
		{
			fprintf(fptr,"0");
			fprintf(fptr,"~");
		}

		if(tc_strlen(userinfo10Dup)==0)
		{
			fprintf(fptr,"%s",userinfo10Dup);
			fprintf(fptr,"~");
		}
		else
		{
			fprintf(fptr,"~");
		}

		fprintf(fptr,"\n");
	 }
	 MEM_free(cntr_objects);
	 fclose(fptr);
	 
	}
	return ITK_ok;
}

