/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File			 :   Cntrlobj.c
*  Author		 :   Sudhir
*  Module		 :   Control Object create in TCUA
*                            
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <ctype.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <ae/dataset.h>
#include <tccore/aom_prop.h>

static void handle_ifail(char *file, int line);
static void MultiExplosion (tag_t line, char *Plant, tag_t line1, int depth,FILE *fd,int reqLevel,int level);
static void MultiExplosionLinkInfo (tag_t line, char *Plant, tag_t line1, int depth,FILE *fd,char *Uidd,int reqLevel,int level);
#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;
	
int ITK_user_main(int argc,char* argv[])
{
	int z;
	int status;

	tag_t dml_type_tag                            = NULLTAG;
	tag_t object_create_input_tag                 = NULLTAG;
	tag_t new_object                              = NULLTAG;
	tag_t ctrl_tag                            = NULLTAG;
	
	FILE* fptr = NULL;
				
	char *inputfile = NULL;	
	char *inputline = NULL;
	
	char	*ControlObject			= NULL;
	char	*syscd		= NULL;
	char	*subsyscd	= NULL;
	char	*itemId	= NULL;
	
	
	char	*info1		= NULL;


	char	*info2		= NULL;

	char	*info3	= NULL;

	char	*info4		= NULL;

	int j=0;
	int flagFound=0;
	char *Information1=NULL;
	char *Information2=NULL;
	char *Information3=NULL;
	char *Information4=NULL;
	char *Information5=NULL;
	char *Information6=NULL;
	char *Information7=NULL;
	char *Information8=NULL;
	char *Information9=NULL;
	char *DeleteInd=NULL;
	char *RecordType=NULL;
	char *Syscd=NULL;
	char *SubSyscd=NULL;
	char *control_objname=NULL;
	char *control_objnameDup=NULL;
	char *Information1Dup=NULL;
	char *Information2Dup=NULL;
	char *Information3Dup=NULL;
	char *Information4Dup=NULL;
	char *Information5Dup=NULL;
	char *Information6Dup=NULL;
	char *Information7Dup=NULL;
	char *Information8Dup=NULL;
	char *Information9Dup=NULL;
	char *DeleteIndDup=NULL;
	char *RecordTypeDup=NULL;
	char *Info4=NULL;

	//char *DeleteIndDup=NULL;
	char *XfrDoneDup=NULL;
	char *Information10Dup=NULL;
	//char *DeleteInd=NULL;
	char *XfrDone=NULL;
	char *Information10=NULL;

	logical			delind = false;
	
	char *SyscdDup=NULL;
	char *SubSyscdDup=NULL;
	char	*f	=NULL;
	char	result1 [ 100000 ] ;
	char	result2 [ 100000 ] ;

	const char* u = NULL;
    const char* p = NULL;
    const char* g = NULL;
    const char* ip = NULL;

	 int
        //error_code = ITK_ok,
        n_entries = 2,
        n_found = 0,
        ii,cnt = 0;
		int create_flag = 0;
		int i = 0;
	
    tag_t
        query = NULLTAG,
        *cntr_objects = NULLTAG;
       

	char
        *qry_entries[3] = {"SYSCD","SUBSYSCD","Record Type"},
        *qry_values[3]	= {"*","*","*"};
	
	
	ITK_CALL(ITK_set_journalling( TRUE ));
	ITK_CALL(ITK_initialize_text_services (0));
	printf("\n\n\t Attempting Logging\n ");fflush(stdout);

	z=ITK_CALL(ITK_auto_login());
	if(z!=ITK_ok)
	{
		printf("\n\n\t OMG Login Not Successfull\n ");fflush(stdout);
	}
	else
	{
	  printf("\n\n\t Login Successfull\n ");fflush(stdout);
	}

	u = ITK_ask_cli_argument( "-u=");
	p = ITK_ask_cli_argument( "-p=");
	g = ITK_ask_cli_argument( "-g=");
	ip = ITK_ask_cli_argument( "-i=");
	if (ITK_init_module(u,p,g) == ITK_ok )
	{
	

	
	printf("\n\n\t Login Successfull\n ");fflush(stdout);
	//fptr=fopen("/user/testcmi/devgroups/sudhir/ControlObject/ControlObjlist.csv","r");  // CMITEST
	//fptr=fopen("/user/infodba04/sudhir/ControlObject/ControlObjlist.csv","r"); // INFODBA04
	//fptr=fopen("/home/sss910100/ControlObject/controlobj.txt","r");  // UAPROD
	fptr=fopen(ip,"r");  // CVPROD
	printf("\n file read .......");fflush(stdout);
	if(fptr!=NULL)
	{
		inputline=(char *) MEM_alloc(50000);
		control_objname=(char *) MEM_alloc(500);
		while(fgets(inputline,50000,fptr)!=NULL)
		{
			for (i = 0; i < strlen(inputline); i++)
			{
				if ( inputline[i] == '\n' || inputline[i] == '\r' )
					inputline[i] = '\0';
			}
			while(1)
			{
				f = strstr(inputline,",,");
				if(f==NULL)
				{
					break;
				}

				strcpy(result2,f+1);					
				*(f+1)=' ';
				*(f+2)='\0';
				strcat(f,result2);
			 }
			 strcpy(result1,inputline);
			flagFound=0;
			printf("\n inputline .......%s\n",result1);fflush(stdout);
			//fputs(result1,stdout);

			control_objnameDup=tc_strtok(result1,"~");
			printf("\n control_objname [%s]",control_objnameDup);fflush(stdout);
			Syscd=tc_strtok(NULL,"~");
			printf("\n Syscd [%s]",Syscd);fflush(stdout);
			SubSyscd=tc_strtok(NULL,"~");
			printf("\n SubSyscd [%s]",SubSyscd);fflush(stdout);
			Information1Dup=tc_strtok(NULL,"~");
			printf("\n Information1Dup [%s]",Information1Dup);fflush(stdout);
			Information2Dup=tc_strtok(NULL,"~");
			printf("\n Information2Dup [%s]",Information2Dup);fflush(stdout);
			Information3Dup=tc_strtok(NULL,"~");
			printf("\n Information3Dup [%s]",Information3Dup);fflush(stdout);
			Information4Dup=tc_strtok(NULL,"~");
			printf("\n Information4Dup [%s]",Information4Dup);fflush(stdout);
			Information5Dup=tc_strtok(NULL,"~");
			printf("\n Information5Dup [%s]",Information5Dup);fflush(stdout);
			Information6Dup=tc_strtok(NULL,"~");
			printf("\n Information6Dup [%s]",Information6Dup);fflush(stdout);
			Information7Dup=tc_strtok(NULL,"~");
			printf("\n Information7Dup [%s]",Information7Dup);fflush(stdout);
			Information8Dup=tc_strtok(NULL,"~");
			printf("\n Information8Dup [%s]",Information8Dup);fflush(stdout);
			Information9Dup=tc_strtok(NULL,"~");
			printf("\n Information9Dup [%s]",Information9Dup);fflush(stdout);
			RecordTypeDup=tc_strtok(NULL,"~");
			printf("\n RecordTypeDup [%s]",RecordTypeDup);fflush(stdout);
			DeleteIndDup=tc_strtok(NULL,"~");
			printf("\n DeleteIndDup [%s]",DeleteIndDup);fflush(stdout);
			XfrDoneDup=tc_strtok(NULL,"~");
			printf("\n XfrDoneDup [%s]",XfrDoneDup);fflush(stdout);
			Information10Dup=tc_strtok(NULL,"~");
			printf("\n Information10Dup [%s]",Information10Dup);fflush(stdout);

			if(control_objnameDup)control_objname = strdup(control_objnameDup);
			if(Syscd)SyscdDup = strdup(Syscd);
			if(SubSyscd)SubSyscdDup = strdup(SubSyscd);
			if(Information1Dup!=NULL)Information1 = strdup(Information1Dup);
			if(Information2Dup!=NULL)Information2 = strdup(Information2Dup);
			if(Information3Dup!=NULL)Information3 = strdup(Information3Dup);
			if(Information4Dup!=NULL)Information4 = strdup(Information4Dup);
			printf("\n Information4 .......[%s]",Information4);fflush(stdout);
			if(Information5Dup!=NULL)Information5 = strdup(Information5Dup);
			if(Information6Dup!=NULL)Information6 = strdup(Information6Dup);
			if(Information7Dup!=NULL)Information7 = strdup(Information7Dup);
			if(Information8Dup!=NULL)Information8 = strdup(Information8Dup);
			if(Information9Dup!=NULL)Information9 = strdup(Information9Dup);
			if(RecordTypeDup!=NULL)
				RecordType = strdup(RecordTypeDup);
			else
				RecordType = strdup("");
			if(DeleteIndDup!=NULL)DeleteInd = strdup(DeleteIndDup);
			if(XfrDoneDup!=NULL)XfrDone = strdup(XfrDoneDup);
			if(Information10Dup!=NULL)Information10 = strdup(Information10Dup);
			
			/*tc_strcpy(control_objname,SyscdDup);
			tc_strcat(control_objname,",");
			tc_strcat(control_objname,SubSyscdDup);
			tc_strcat(control_objname,",");
			tc_strcat(control_objname,RecordType);*/
			
			printf("\n control_objname .......%s",control_objname);fflush(stdout);
			
			printf("\n SyscdDup .......%s",SyscdDup);fflush(stdout);
			printf("\n SubSyscdDup .......%s",SubSyscdDup);fflush(stdout);
			printf("\n Information1 .......%s",Information1);fflush(stdout);
			printf("\n Information2 .......%s",Information2);fflush(stdout);
			printf("\n Information3 .......%s",Information3);fflush(stdout);
			printf("\n Information4 .......%s",Information4);fflush(stdout);
			printf("\n RecordType .......%s",RecordType);fflush(stdout);
			printf("\n DeleteInd .......%s",DeleteInd);fflush(stdout);

			printf("\n XfrDone .......%s",XfrDone);fflush(stdout);
			printf("\n Information10 .......%s",Information10);fflush(stdout);
			
			if(control_objname!=NULL && tc_strlen(control_objname)>0)
			{
			

				printf("\nStatus 2"); fflush(stdout);
			qry_values[0] = SyscdDup;
			qry_values[1] = SubSyscdDup;
			qry_values[2] = RecordType;
			
			//qry_values[3] = Information2;
			//qry_values[4] = Information3;

			printf("\nStatus 1"); fflush(stdout);

			ITK_CALL(QRY_find2("Control Objects...", &query));
			if(query!=NULLTAG)
			{
				ITK_CALL(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
			}
			
			//n_found = 0; //First Time Create

			printf("\n n_found=====>%d", n_found);fflush(stdout);
			if(n_found==0)
			{
				create_flag = 0;
				ITK_CALL(TCTYPE_find_type("T5_ControlObject", "T5_ControlObject", &dml_type_tag));
				ITK_CALL(TCTYPE_construct_create_input(dml_type_tag, &object_create_input_tag));
				if(control_objname!=NULL && strlen(control_objname)>0)
				{
					ITK_CALL(AOM_set_value_string(object_create_input_tag,"object_name",control_objname));
					ITK_CALL(AOM_set_value_string(object_create_input_tag,"t5_SubSyscd",SyscdDup));
					ITK_CALL(AOM_set_value_string(object_create_input_tag,"t5_Syscd",SubSyscdDup));
					create_flag++;
				}
				
				printf("\n create_flag=>%d", create_flag);fflush(stdout);
				if(create_flag>=0)
				{
					ITK_CALL(TCTYPE_create_object(object_create_input_tag, &new_object));
					if(new_object !=NULLTAG)
					{
						if(AOM_lock(new_object))
						ITK_CALL(AOM_set_value_string(new_object,"object_name",control_objname));
						ITK_CALL(AOM_set_value_string(new_object,"t5_Syscd",SyscdDup));
						ITK_CALL(AOM_set_value_string(new_object,"t5_SubSyscd",SubSyscdDup));
						if(tc_strlen(Information1)>0)ITK_CALL(AOM_set_value_string(new_object,"t5_Userinfo1",Information1));
						if(tc_strlen(Information2)>0)ITK_CALL(AOM_set_value_string(new_object,"t5_Userinfo2",Information2));
						if(tc_strlen(Information3)>0)ITK_CALL(AOM_set_value_string(new_object,"t5_Userinfo3",Information3));
						if(tc_strlen(Information4)>0)ITK_CALL(AOM_set_value_string(new_object,"t5_Userinfo4",Information4));
						if(tc_strlen(Information5)>0)ITK_CALL(AOM_set_value_string(new_object,"t5_Userinfo5",Information5));
						if(tc_strlen(Information6)>0)ITK_CALL(AOM_set_value_string(new_object,"t5_Userinfo6",Information6));
						if(tc_strlen(Information7)>0)ITK_CALL(AOM_set_value_string(new_object,"t5_Userinfo7",Information7));
						if(tc_strlen(Information8)>0)ITK_CALL(AOM_set_value_string(new_object,"t5_Userinfo8",Information8));
						if(tc_strlen(Information9)>0)ITK_CALL(AOM_set_value_string(new_object,"t5_Userinfo9",Information9));
						if(tc_strlen(RecordType)>0)ITK_CALL(AOM_set_value_string(new_object,"t5_RecordType",RecordType));

						if(tc_strlen(Information10)>0) ITK_CALL(AOM_set_value_string(new_object,"t5_userinfo10",Information10));
						if(tc_strcmp(DeleteInd,"1")==0)
						{
							ITK_CALL(AOM_set_value_logical(new_object,"t5_DelInd",true));
						}
						else
						{
							ITK_CALL(AOM_set_value_logical(new_object,"t5_DelInd",false));
						}

						if(tc_strcmp(XfrDone,"1")==0)
						{
							ITK_CALL(AOM_set_value_logical(new_object,"t5_XferDone",true));
						}
						else
						{
							ITK_CALL(AOM_set_value_logical(new_object,"t5_XferDone",false));
						}

						//ITK_CALL(AOM_set_value_string(new_object,"t5_Userinfo2",Information2));
						//ITK_CALL(AOM_set_value_string(new_object,"t5_Userinfo3",Information3));
						//ITK_CALL(AOM_set_value_string(new_object,"t5_RecordType","1"));
						
						ITK_CALL(AOM_save_with_extensions(new_object));
						if(AOM_refresh(new_object,1));
						if(AOM_unlock(new_object));
						printf("\n CREATED %s",control_objname);fflush(stdout);
					}
				}
			}
			else
			{
				for(cnt=0;cnt<n_found;cnt++)
				{
					tag_t		 updateinfo1			=  NULLTAG;
					tag_t		 updateinfo2			=  NULLTAG;
					tag_t		 updateinfo3			=  NULLTAG;
					tag_t		 updateinfo4			=  NULLTAG;
					tag_t		 updateinfo5			=  NULLTAG;
					tag_t		 updateinfo6			=  NULLTAG;
					tag_t		 updateinfo7			=  NULLTAG;
					tag_t		 updateinfo8			=  NULLTAG;
					tag_t		 updateinfo9			=  NULLTAG;
					tag_t		 updateinfo10			=  NULLTAG;
					tag_t		 DelInd					=  NULLTAG;
					tag_t		 Xfr					=  NULLTAG;
					printf("\n Information1====>[%s]",Information1);fflush(stdout);
					printf("\n Information2====>[%s]",Information2);fflush(stdout);
					printf("\n Information3====>[%s]",Information3);fflush(stdout);
					printf("\n Information4====>[%s]",Information4);fflush(stdout);
					printf("\n Information5====>[%s]",Information5);fflush(stdout);
					printf("\n Information6====>[%s]",Information6);fflush(stdout);
					printf("\n Information7====>[%s]",Information7);fflush(stdout);
					printf("\n Information8====>[%s]",Information8);fflush(stdout);
					printf("\n Information9====>[%s]",Information9);fflush(stdout);
					printf("\n DeleteInd====>[%s]",DeleteInd);fflush(stdout);
					printf("\n XfrDone====>[%s]",XfrDone);fflush(stdout);
					printf("\n Information10====>[%s]",Information10);fflush(stdout);
					ctrl_tag = cntr_objects[cnt];
					AOM_refresh( ctrl_tag, POM_modify_lock);
					if(tc_strlen(Information1)>0)
					{
						POM_attr_id_of_attr("t5_Userinfo1", "T5_ControlObject", &updateinfo1);
						POM_set_attr_string(1, &ctrl_tag, updateinfo1, Information1);
					}
					if(tc_strlen(Information2)>0)
					{
						POM_attr_id_of_attr("t5_Userinfo2", "T5_ControlObject", &updateinfo2);
						POM_set_attr_string(1, &ctrl_tag, updateinfo2, Information2);
					}
					if(tc_strlen(Information3)>0)
					{
						POM_attr_id_of_attr("t5_Userinfo3", "T5_ControlObject", &updateinfo3);
						POM_set_attr_string(1, &ctrl_tag, updateinfo3, Information3);
					}
					if(tc_strlen(Information4)>0)
					{
						POM_attr_id_of_attr("t5_Userinfo4", "T5_ControlObject", &updateinfo4);
						POM_set_attr_string(1, &ctrl_tag, updateinfo4, Information4);
					}
					
					if(tc_strlen(Information5)>0)
					{
						POM_attr_id_of_attr("t5_Userinfo5", "T5_ControlObject", &updateinfo5);
						POM_set_attr_string(1, &ctrl_tag, updateinfo5, Information5);
					}
					if(tc_strlen(Information6)>0)
					{
						POM_attr_id_of_attr("t5_Userinfo6", "T5_ControlObject", &updateinfo6);
						POM_set_attr_string(1, &ctrl_tag, updateinfo6, Information6);
					}
					if(tc_strlen(Information7)>0)
					{
						POM_attr_id_of_attr("t5_Userinfo7", "T5_ControlObject", &updateinfo7);
						POM_set_attr_string(1, &ctrl_tag, updateinfo7, Information7);
					}
					if(tc_strlen(Information8)>0)
					{
						POM_attr_id_of_attr("t5_Userinfo8", "T5_ControlObject", &updateinfo8);
						POM_set_attr_string(1, &ctrl_tag, updateinfo8, Information8);
					}
					if(tc_strlen(Information9)>0)
					{
						POM_attr_id_of_attr("t5_Userinfo9", "T5_ControlObject", &updateinfo9);
						POM_set_attr_string(1, &ctrl_tag, updateinfo9, Information9);
					}

					if(tc_strlen(Information10)>0)
					{
						POM_attr_id_of_attr("t5_userinfo10", "T5_ControlObject", &updateinfo10);
						POM_set_attr_string(1, &ctrl_tag, updateinfo10, Information10);
					}

					if(tc_strcmp(DeleteInd,"1")==0)
					{
						POM_attr_id_of_attr("t5_DelInd", "T5_ControlObject", &DelInd);
						POM_set_attr_logical(1, &ctrl_tag, DelInd, true);
						//ITK_CALL(AOM_set_value_logical(new_object,"t5_DelInd",true));
					}
					else
					{
						POM_attr_id_of_attr("t5_DelInd", "T5_ControlObject", &DelInd);
						POM_set_attr_logical(1, &ctrl_tag, DelInd, false);
						//ITK_CALL(AOM_set_value_logical(new_object,"t5_DelInd",false));
					}

					if(tc_strcmp(XfrDone,"1")==0)
					{
						POM_attr_id_of_attr("t5_XferDone", "T5_ControlObject", &Xfr);
						POM_set_attr_logical(1, &ctrl_tag, Xfr, true);
						//ITK_CALL(AOM_set_value_logical(new_object,"t5_XferDone",true));
					}
					else
					{
						POM_attr_id_of_attr("t5_XferDone", "T5_ControlObject", &Xfr);
						POM_set_attr_logical(1, &ctrl_tag, Xfr, false);
						//ITK_CALL(AOM_set_value_logical(new_object,"t5_XferDone",false));
					}
					
					
					//POM_attr_id_of_attr("t5_RecordType", "T5_ControlObject", &updateinfo3);
					//POM_set_attr_string(1, &ctrl_tag, updateinfo3, RecordType);

					POM_save_instances(1, &ctrl_tag, false);
					printf("\n 6 Completed::POM_save_instances");fflush(stdout);
					AOM_refresh(ctrl_tag, POM_no_lock);
					
				}
			}
		}
		}
		MEM_free(cntr_objects);
	}////
	}
	 
	 fclose(fptr);
	 return ITK_ok;
}

