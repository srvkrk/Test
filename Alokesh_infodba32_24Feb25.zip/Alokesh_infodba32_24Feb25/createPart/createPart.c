/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:createPart.c
*
* Description		: > This Utility is to do unit testing of functions .
* Module  		        
* Since		    :    

* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 05/03/2021   	Sanjoy Mondal			    Initial Code

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <fclasses/tc_date.h>
#include <tccore/project.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <fclasses/tc_time.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <stdio.h>
#include <string.h>
#include <tc/folder.h>
#include <tccore/aom_prop.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/uom.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <tccore/releasestatus.h>
#include <time.h>
#include <fclasses/tc_basic.h>
#include <common/tc_deprecation_macros.h>

#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
	if(Debug)								\
	{										\
		printf(#X);							\
	}										\
	fflush(NULL);							\
	status=X; 								\
	if (status != ITK_ok ) 					\
	{										\
		int				index = 0;			\
		int				n_ifails = 0;		\
		const int*		severities = 0;		\
		const int*		ifails = 0;			\
		const char**	texts = NULL;		\
											\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else									\
	{										\
		if(Debug)							\
		printf("\tSUCCESS\n");				\
	}

#define ITK_err 910001
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static void handle_itk_error
    ( int stat,                               /* <I> */
      int source_code_line,                   /* <I> */
      const char *source_code_file_name       /* <I> */
    );

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}



/* right trim */
char *rtrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int index=0;    /* index of the last non-space char */

    /* validate input */
    if (!str)
        return str;

    /* copy the string */
    while(*src){
        *dst++ = *src++;
        c = *src;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;
        else
            is_space=0;

        if (is_space==0 && *src)
            index = (src-str)+1;
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

/* left trim */
char *ltrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int index=0;    /* index of the first non-space char */

    /* validate input */
    if (!str)
        return str;

    /* skip leading white-spaces */
    while((c=*src)){ 
        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' '){
            ++src;
            ++index;
        } else
            break;
    }

    /* copy rest of the string */
    while(*src)
        *dst++ = *src++;

    /* terminate the string */
    *(src-index)='\0';

    return str;
}


//Function start
void setAddTagObj(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}


void t5AddTagObjToSet(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

/* Function to add string into a set of string */
void t5AddStrToSet(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void t5FindStrInSet(char **str_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(str_list[k],str)==0)
		{
			*found=1;
			break;
		}

	}
}



char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


void setAddInt(int *count,int **objlist,int obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddInt1");fflush(stdout);
		(*objlist) = (int *)malloc((*count ) * sizeof(int ));
	}
	else
	{
		//printf("\n **setAddInt2");fflush(stdout);
		(*objlist) = (int *)realloc((*objlist),(*count ) * sizeof(int ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));


}


void setFindInt(int *int_list,int count,int in,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(int_list[k]== in)
		{
			*found=1;
			break;
		}

	}
}




void setFindTagInSet(tag_t *objlist,tag_t obj,int count,int *found)
{
	int k=0;
	*found=-1;
	for(k=0;k<count;k++)
	{		
		if(objlist[k]==obj)
		{
			*found=k;
			break;
		}
	}
}



void  getcurentMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

int tdays( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}

void NextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= tdays( month, year );//calling tdays function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getcurentMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

void CurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n CurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}







int getPartObjFromRevSeq(char* partnumber, char* rev, char* seq, tag_t *partObj)
{
	int ifail = ITK_ok;
	
	int  count 	= 0;
	tag_t *itemObjs = NULLTAG;
	char* revStr = NULL;
	int seqInt = 0;
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "Item ID";
	qry_entries[1] = "Type";
	//qry_entries[2] = "Sequence Id";
	
	qry_values[0] = partnumber;
	revStr = (char *) MEM_alloc( 10 * sizeof(char) );
	//tc_strcpy(revStr,"");
	tc_strcpy(revStr,rev);
	tc_strcat(revStr,";");
	tc_strcat(revStr,seq);
	printf("\nSAN:getPartObjFromRevSeq: revStr=========>%s\n",revStr);fflush(stdout);
	printf("\nSAN:getPartObjFromRevSeq: revStr==length=======>%d\n",strlen(revStr));fflush(stdout);
	qry_values[1] = "Design Revision";
	
	//trimLeading(revStr);
	char* revStr1 = NULL;
	char* revStr2 = NULL;
	revStr1 = ltrimString(revStr);
	revStr2 = rtrimString(revStr1);
	
	
		
	printf("\nSAN:getPartObjFromRevSeq: After trim revStr2=========>%s\n",revStr2);fflush(stdout);
	printf("\nSAN:getPartObjFromRevSeq: After trim revStr2==length=======>%d\n",strlen(revStr2));fflush(stdout);	
	
	ITK_CALL(QRY_find2("Item Revision...", &query));
	ITK_CALL(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObjs));
	printf("\n getPartObjFromRevSeq: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		int k=0;
		char* revS = NULL;
		for(k=0;k<count;k++)
		{
			ITK_CALL(AOM_ask_value_string(itemObjs[k],"item_revision_id",&revS));
			//printf("\n getPartObjFromRevSeq: revS==>%s", revS);fflush(stdout);
			//printf("\n getPartObjFromRevSeq: revS length==>%d", strlen(revS));fflush(stdout);
			if(revS==NULL) continue;
			if(tc_strcmp(revS,revStr2)==0)
			{
				*partObj = itemObjs[k];
				break;
			}
			
		}
	}
	
	if(revStr!=NULL) MEM_free(revStr);
	return ifail;	

}



/*********************Create Part ***********************/

int getPartMasterTag(char* partnumber, char* objType, tag_t *partObj)
{
	int ifail = ITK_ok;
	
	int  count 	= 0;
	tag_t *itemObjs = NULLTAG;
	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "Item ID";
	qry_entries[1] = "Type";
	
	qry_values[0] = partnumber;
	
	qry_values[1] = objType;
	
	
		
	if(QRY_find2("Item...", &query));
	if(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObjs));
	printf("\n getPartMasterTag: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		*partObj = itemObjs[0];
		
	}
	
	return ifail;	

}

int createPart(char* partnumber, char* objType, tag_t * partRevTag)
{
	int ifail = ITK_ok;
	char* objTypeRev = NULL;
	tag_t partRevType = NULLTAG;
	objTypeRev = (char*)MEM_alloc((tc_strlen(objType) + 15)*sizeof(char*));
	
	tc_strcpy(objTypeRev,objType);
	tc_strcat(objTypeRev," Revision");
	
	printf("\nobjTypeRev: [%s]",objTypeRev);fflush(stdout);
	
	ITK_CALL(TCTYPE_find_type(objTypeRev, NULL, &partRevType));
	
	if(partRevType != NULLTAG)
	{
		printf("\n Found type");fflush(stdout);
		tag_t partRevCreI = NULLTAG;
		tag_t partTagType = NULLTAG;
		tag_t partTag = NULLTAG;
		tag_t partTagCreI = NULLTAG;
		
		ITK_CALL(TCTYPE_construct_create_input(partRevType, &partRevCreI));
		ifail = AOM_set_value_string(partRevCreI, "item_id", partnumber);
		ifail = AOM_set_value_string(partRevCreI, "object_name", partnumber);
		ifail = AOM_set_value_string(partRevCreI, "item_revision_id", "NR;1");
		ifail = AOM_set_value_string(partRevCreI, "sequence_id", "1");
		ifail = AOM_set_value_string(partRevCreI, "t5_PartType", "M");
		ifail = AOM_set_value_string(partRevCreI, "object_desc", "Test Desc");
		ifail = AOM_set_value_string(partRevCreI, "t5_DesignGrp", "25");
		ifail = AOM_set_value_string(partRevCreI, "t5_ModuleAddress", "D1A06");
		ifail = AOM_set_value_string(partRevCreI, "t5_CategoryName", "D1A06");
		
		ifail = TCTYPE_find_type(objType, NULL, &partTagType);
		if(partTagType != NULLTAG)
		{
							
			ITK_CALL(TCTYPE_construct_create_input(partTagType, &partTagCreI));
			
			ifail = AOM_set_value_string(partTagCreI, "item_id", partnumber);
			ifail = AOM_set_value_string(partTagCreI, "object_name", partnumber);
			ifail = AOM_set_value_tag(partTagCreI, "revision",partRevCreI);
			ITK_CALL(TCTYPE_create_object(partTagCreI, &partTag));
			
			
		}

		if(partTag != NULLTAG)
		{
			printf("\n Part Object is created successfully. \n");fflush(stdout);
			
			//ifail = AOM_save(partTag);
			ITK_CALL(AOM_save_with_extensions(partTag));
			ifail = AOM_unlock(partTag);
			ifail = AOM_refresh(partTag,0);
		}
		else
		{
			printf("\n Object is NOT  created  \n");fflush(stdout);
			
		}
		tag_t partItem = NULLTAG;
		tag_t prtRevTag = NULLTAG;
		ITK_CALL(ITEM_find_item(partnumber,&partItem));
		if(partItem != NULLTAG)
		{
			ITK_CALL(ITEM_ask_latest_rev(partItem,&prtRevTag));
		}
		if(prtRevTag != NULLTAG)
		{
			ifail = AOM_lock(prtRevTag);
			//ifail = AOM_set_value_string(prtRevTag, "item_id", partnumber);
			ifail = AOM_set_value_string(prtRevTag, "object_name", partnumber);
			ifail = AOM_set_value_string(prtRevTag, "item_revision_id", "NR;1");
			ifail = AOM_set_value_string(prtRevTag, "sequence_id", "1");
			ifail = AOM_set_value_string(prtRevTag, "t5_PartType", "M");
			ifail = AOM_set_value_string(prtRevTag, "object_desc", "Test Desc2");
			ifail = AOM_set_value_string(prtRevTag, "t5_DesignGrp", "00");
			ifail = AOM_set_value_string(prtRevTag, "t5_ModuleAddress", "MD1A05");
			ifail = AOM_set_value_string(prtRevTag, "t5_CategoryName", "D1A05");
			ifail = AOM_unlock(prtRevTag);
			ifail = AOM_refresh(prtRevTag,0);
		}
		

	}
	MEM_free(objTypeRev);
	return ifail;
}


int ITK_user_main(int argc, char* argv[])
{
	
	int ifail = ITK_ok;
	char* partNo = NULL;
	printf("\n SAN:createPart: *********** Start Of  Main function of new creation of Part ************* \n");fflush(stdout);
	partNo = ITK_ask_cli_argument( "-prtNo=");
	
	

	if(ITK_auto_login() == ITK_ok)	
	{
		tag_t user_tag = NULLTAG;
		char* username = NULL;	
		tag_t partTag = NULLTAG;
		
				
		CALLAPI(ITK_set_journalling( TRUE ));
		printf("\n\nSAN:createPart: Login successfull.\n");fflush(stdout);		
		printf("\nSAN:createPart: argc==>%d\n",argc);		
		printf("\nSAN:createPart: Input argument: Part No [%s]\n",partNo);fflush(stdout);
		POM_get_user(&username,&user_tag);
		//printf("\nSAN:createPart: Session User Name[%s]\n",username);fflush(stdout);
		
		if(partNo!=NULL)
		{
			
			ifail = getPartMasterTag(partNo,"Design",&partTag);
			
			if(partTag == NULLTAG)
			{
				printf("\nPart[%s] not found in PLM DB\n",partNo);fflush(stdout);
				tag_t partRevTag = NULLTAG;
				
				ifail = createPart(partNo,"Design",&partRevTag);
				
			}
			else
			{
				printf("\nPart[%s] already exists in PLM DB\n",partNo);fflush(stdout);
			}

			
			
		}
		else
		{
			printf("\nCheck the input parameter of the shell script.\nWrong Input parameter as Part No no is NULL\n");fflush(stdout);
		}		
		

	
	
	}

	printf("\n SAN:createPart: *********** End Of Main function ************* \n");fflush(stdout);	
	return ifail;
}



