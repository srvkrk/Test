/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:tm_FdjDevRep.c
*
* Description		: > This Utility is to do unit testing of functions .
* Module  		        
* Since		    :    

* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 11/06/2022   	Poonam			    Initial Code

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom_prop.h>
#include <epm/epm_toolkit_tc_utils.h>

#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\
		
/*
#define ITKCALL( argument )                                             \
{                                                                       \
    int retcode = argument;                                             \
    if ( retcode != ITK_ok ) {                                          \
        char* s;                                                        \
        printf( " "#argument "\n" );                                    \
        printf( "  returns [%d]\n", retcode );                          \
        EMH_ask_error_text (retcode, &s);                               \
        printf( "  Teamcenter ERROR: [%s]\n", s);           \
        printf( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
        if (s != 0) MEM_free (s);                                       \
    }                                                                   \
}*/

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static void handle_itk_error
    ( int stat,                               /* <I> */
      int source_code_line,                   /* <I> */
      const char *source_code_file_name       /* <I> */
    );

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}


// Function to check if a character is printable
int isPrintable(char ch) {
    return ch >= 32 && ch <= 126;
}

void removeNonAsciiChars(char *str) {
    int i = 0;
    char ch;
    while ((ch = str[i]) != '\0') {
        if (!isPrintable(ch))
        {
            str[i] = ' ';
        }
        i++;
    }
}
//Function start
void setAddTagObj(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}


void t5AddTagObjToSet(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}


/* Function to add string into a set of string */
void t5AddStrToSet(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void t5FindStrInSet(char **str_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(str_list[k],str)==0)
		{
			*found=1;
			break;
		}

	}
}
char *replaceWord(const char *s, const char *oldW, 
                                 const char *newW) 
{ 
    char *result; 
    int i, cnt = 0; 
    int newWlen = strlen(newW); 
    int oldWlen = strlen(oldW); 
  
    // Counting the number of times old word 
    // occur in the string 
    for (i = 0; s[i] != '\0'; i++) 
    { 
        if (strstr(&s[i], oldW) == &s[i]) 
        { 
            cnt++; 
  
            // Jumping to index after the old word. 
            i += oldWlen - 1; 
        } 
    } 
  
    // Making new string of enough length 
    result = (char *)malloc(i + cnt * (newWlen - oldWlen) + 1); 
  
    i = 0; 
    while (*s) 
    { 
        // compare the substring with the result 
        if (strstr(s, oldW) == s) 
        { 
            tc_strcpy(&result[i], newW); 
            i += newWlen; 
            s += oldWlen; 
        } 
        else
            result[i++] = *s++; 
    } 
  
    result[i] = '\0'; 
    return result; 
}
///CODE START HERE
int t5GetItemRevison(char* InputPart)
{
	//MT start
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;
	
	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int n_tags_foundd2=0;
	int n_tags_foundd3=0;
	tag_t *tags_foundd3 = NULL;
	tag_t *tags_foundd2 = NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	const char *attrss3[2];
	const char *valuess3[2];
	//MT end
	//printf("\n FUN:part no :%s.", InputPart);fflush(stdout);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)InputPart;
	values2[1] = "Design";
	if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
	//printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
	}
	else
	{
		///printf("\n FUN:Inside T5_EE_Part:%s.", InputPart);fflush(stdout);
		attrss2[0] ="item_id";
		attrss2[1] ="object_type";
		valuess2[0] = (char *)InputPart;
		valuess2[1] = "T5_EE_Part";
		if(ITEM_find_items_by_key_attributes(2,attrss2, valuess2, &n_tags_foundd2, &tags_foundd2)!=ITK_ok)PrintErrorStack();
		//printf("\n FUN:EE part count :%d.", n_tags_foundd2);fflush(stdout);
		if (n_tags_foundd2>0)
		{
			OutPutTag= tags_foundd2[0];
		}
		else
		{
			//printf("\n FUN:Inside T5_ClrPart:%s.", InputPart);fflush(stdout);
			attrss3[0] ="item_id";
			attrss3[1] ="object_type";
			valuess3[0] = (char *)InputPart;
			valuess3[1] = "T5_ClrPart";
			if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
			//printf("\n FUN:T5_ClrPart part count :%d.", n_tags_foundd3);fflush(stdout);
			if (n_tags_foundd3>0)
			{
				OutPutTag= tags_foundd3[0];
			}
			else
			{
				//printf("\n FUN:Inside T5_ArchModule:%s.", InputPart);fflush(stdout);
				attrss3[0] ="item_id";
				attrss3[1] ="object_type";
				valuess3[0] = (char *)InputPart;
				valuess3[1] = "T5_ArchModule";
				if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
				//printf("\n FUN:T5_ArchModule part count :%d.", n_tags_foundd3);fflush(stdout);
				if (n_tags_foundd3>0)
				{
					OutPutTag= tags_foundd3[0];
				}
			}
		}
	}
	if(OutPutTag==NULLTAG)
	{
		//printf("\n FUN: NULL tag for part no:%s.", InputPart);fflush(stdout);
	}
	else
	{
		//printf("\n FUN: tag found for part no:%s.", InputPart);fflush(stdout);
	}
	/*if(attrs2) MEM_free(attrs2);
	if(attrss2) MEM_free(attrss2);
	if(values2) MEM_free(values2);
	if(valuess2) MEM_free(valuess2);*/

	return OutPutTag;	
}

int getItemRevObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find2("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\n tm_sendFDJMailRep: getItemRevObject: count==>%d\n", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}



int getGeneralObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Name";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find2("General...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\n tm_sendFDJMailRep: getGeneralObject: count==>%d\n", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}



typedef struct PartModel_
{
 int level;
 tag_t childItemRev;
 tag_t childBomLine;
} *PartModel; 

void setAddPartModel(int *count,PartModel **objlist,PartModel obj )
{

	*count=*count+1;
	//printf("\n ****count==>%d", *count);fflush(stdout);
	if(*count==1)
	{
		//printf("\n ****setAddPartModel1");fflush(stdout);
		(*objlist) = (PartModel *)malloc((*count ) * sizeof(PartModel ));
		//printf("\n ***setAddPartModel2");fflush(stdout);
	}
	else
	{
		//printf("\n **setAddPartModel3");fflush(stdout);
		(*objlist) = (PartModel *)realloc((*objlist),(*count) * sizeof(PartModel ));
		//printf("\n ***setAddPartModel4");fflush(stdout);
		//printf("\n **setAddPartModel5");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
	//printf("\n **setAddPartModel");fflush(stdout);
}



char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


void setAddInt(int *count,int **objlist,int obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddInt1");fflush(stdout);
		(*objlist) = (int *)malloc((*count ) * sizeof(int ));
	}
	else
	{
		//printf("\n **setAddInt2");fflush(stdout);
		(*objlist) = (int *)realloc((*objlist),(*count ) * sizeof(int ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));


}


void setFindInt(int *int_list,int count,int in,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(int_list[k]== in)
		{
			*found=1;
			break;
		}

	}
}


typedef struct PartDet_
{
	char partNumber[20];
	char parRev[10];
	char partDesc[200];
	char partDRStatus[10];
	char partApplicableFDJ[10];
	char partOwnerDesUnit[50];
	char fdjNumber[30];
	char fdjStatus[50];
}PartDet;


void setAddPartDet(int *count,PartDet **objlist,PartDet obj )
{

	*count=*count+1;
	//printf("\n ****count==>%d", *count);fflush(stdout);
	if(*count==1)
	{
		//printf("\n ****setAddPartModel1");fflush(stdout);
		(*objlist) = (PartDet *)malloc((*count ) * sizeof(PartDet ));
		//printf("\n ***setAddPartModel2");fflush(stdout);
	}
	else
	{
		//printf("\n **setAddPartModel3");fflush(stdout);
		(*objlist) = (PartDet *)realloc((*objlist),(*count) * sizeof(PartDet ));
		//printf("\n ***setAddPartModel4");fflush(stdout);
		//printf("\n **setAddPartModel5");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
	//printf("\n **setAddPartModel");fflush(stdout);
}


int getProjectTag(char *projNo, char *object_type, tag_t *projTag)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Name";
	
	qry_values[0] = object_type;
	qry_values[1] = projNo;
		
	CALLAPI(QRY_find2("General...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\n getProjectTag: count==>%d\n", count);fflush(stdout);

	if(count>0)
	{
		*projTag = itemObj[count-1];
	}
	
	return ifail;
}

char *t5TrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int in_word=0;  /* word boundary logical check */
    int index=0;    /* index of the last non-space char*/

    /* validate input */
    if (!str)
        return str;

    while ((c=*src)){
        is_space=0;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;

        if(is_space == 0){
         /* Found a word */
            in_word = 1;
            *dst++ = *src++;  /* make the assignment first
                               * then increment
                               */
        } else if (is_space==1 && in_word==0) {
         /* Already going through a series of white-spaces */
            in_word=0;
            ++src;
        } else if (is_space==1 && in_word==1) {
         /* End of a word, dont mind copy white spaces here */
            in_word=0;
            *dst++ = *src++;
            index = (dst-str)-1; /* location of the last char */
        }
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

void remove_multi_new_line(char* string)
{
  size_t length = strlen(string);
  while((length>0) && (string[length-1] == '\n'))
  {
      --length;
      string[length] ='\0';
  }
}


void  t5GetCurrentMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}


//declaration of date structure

struct date{
	int dd,mm,yy;
	};
//function to get yesterday's (previous) date
void getYesterdayDate(struct date *d){
	if(d->dd==1){
		if(d->mm==4||d->mm==6||d->mm==9||d->mm==11){
			d->dd=31;
			d->mm--;
		}
		else if(d->mm==3){
			if((d->yy%4)==0 && ((d->yy%100)!=0 || (d->yy%400)==0)) d->dd=29;
			else d->dd=28;
			d->mm--;
		}
		else if(d->mm==1){
			d->dd=31;
			d->yy--;
			d->mm=12;
		}
		else if(d->mm==2){
			d->dd=31;
			d->mm--;
		}
		else{
			d->dd=30;
			d->mm--;
		}
	}
	else{
		d->dd--;
	}
}


void t5GetPrevDate(char cprevAccessDate[30])
{
	int day, month, year, nd, nm, ny;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	
	struct date dt;

	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	
	dt.dd = day;
	dt.mm = month;
	dt.yy = year;
	
	printf( "Given date is %d:%d:%d\n", day, month, year );
   
	getYesterdayDate(&dt);
	nd = dt.dd;
	nm = dt.mm;
	ny = dt.yy;
	
    printf( "Prev  days date is %d:%d:%d\n", nd, nm, ny );
	t5GetCurrentMonth(nm,cMonth);
	//printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cprevAccessDate,strDay);
	tc_strcat(cprevAccessDate,"-");
	tc_strcat(cprevAccessDate,cMonth);
	tc_strcat(cprevAccessDate,"-");
	tc_strcat(cprevAccessDate,strYear);
	tc_strcat(cprevAccessDate," ");
	tc_strcat(cprevAccessDate,"00:00");
	//printf("\n cprevAccessDate:%s\n",cprevAccessDate);
}

void t5GetPrevDateTo(char cprevAccessDate[30])
{
	int day, month, year, nd, nm, ny;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	
	struct date dt;

	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	
	dt.dd = day;
	dt.mm = month;
	dt.yy = year;
	
	printf( "Given date is %d:%d:%d\n", day, month, year );
   
	getYesterdayDate(&dt);
	nd = dt.dd;
	nm = dt.mm;
	ny = dt.yy;
	
    printf( "Prev  days To date is %d:%d:%d\n", nd, nm, ny );
	t5GetCurrentMonth(nm,cMonth);
	//printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cprevAccessDate,strDay);
	tc_strcat(cprevAccessDate,"-");
	tc_strcat(cprevAccessDate,cMonth);
	tc_strcat(cprevAccessDate,"-");
	tc_strcat(cprevAccessDate,strYear);
	tc_strcat(cprevAccessDate," ");
	tc_strcat(cprevAccessDate,"23:59");
	//printf("\n cprevAccessDate:%s\n",cprevAccessDate);
}


void t5GetCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n t5GetCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);

	fflush(stdout);
}

int getTCObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find2("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\n getLatestPart: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}


int ITK_user_main(int argc, char* argv[])
{
	
	int ifail = ITK_ok;
	
	char*	fromDate = NULL;
	char* toDate = NULL;
	
	char fromDateStr[20]={0};
	char toDateStr[20]={0};
	
	fromDate = ITK_ask_cli_argument( "-FromDate=");
	
	toDate = ITK_ask_cli_argument( "-ToDate=");
	
	tc_strcpy(fromDateStr, fromDate);
	tc_strcat(fromDateStr," 00:00");
	printf("\nFrom Date ====> %s\n",fromDateStr);fflush(stdout); 
	
	tc_strcpy(toDateStr, toDate);
	tc_strcat(toDateStr," 00:00");
	printf("\nTo Date ====> %s\n",toDateStr);fflush(stdout); 
	
	
	date_t dateFrom;
	date_t dateTo;
	
	ITK_string_to_date(fromDateStr,&dateFrom);		
	ITK_string_to_date(toDateStr,&dateTo);
	
	if(ITK_auto_login() == ITK_ok)	
	{
		tag_t user_tag = NULLTAG;
		char* username = NULL;	
		//tag_t dmlTag = NULLTAG;
		ifail = ITK_ok;
		
		// char cCurrentAccessDate[20]={0};
		// char cPrevAccessDate[20]={0};
		// char cPrevAccessDateTo[20]={0};
		// char cCurrentAccessDateTo[20]={0};
		// char* cCurrentAccessDateTo1 = NULL;
		
		const char * select_attrs[]={"puid"};
		date_t   dateArray[2];
		//date_t dateFrom;
		//date_t dateTo;
		int n_dmls = 0;
        int n_cols = 0;
        void ***values = NULL;
		
	   // char fromDateStr[20]={0};
		//date_t dateFrom1;
		
		// char **dmlRelType = (char **) MEM_alloc(20 * sizeof(char *));
		// dmlRelType[0]="TODR";
		// dmlRelType[1]="Veh";
		// dmlRelType[2]="Gate Maturation";
		// dmlRelType[3]="Vehicle Release";

				
		ITK_CALL(ITK_set_journalling( TRUE ));
		printf("\n\ntm_FdjDevRep: Login successfull.\n");fflush(stdout);		
		printf("\ntm_FdjDevRep: argc==>%d\n",argc);		
		//printf("\ntm_FdjDevRep: Input argument: DML No[%s]\n",dmlNo);fflush(stdout);
		POM_get_user(&username,&user_tag);
		printf("\ntm_FdjDevRep: Session User Name[%s]\n",username);fflush(stdout);
		
		//t5GetCurrentDateTime(cCurrentAccessDate);


		//printf("\n Eff:Current date  is..:[%s]\n",cCurrentAccessDate);fflush(stdout);
		
		//cCurrentAccessDateTo1 = subString(cCurrentAccessDate,0,11);
		
		//tc_strcpy(cCurrentAccessDateTo, cCurrentAccessDateTo1);
		//tc_strcat(cCurrentAccessDateTo," 00:00");
		
		//printf("\n Eff:Current date TO  is..:[%s]\n",cCurrentAccessDateTo);fflush(stdout);

		//t5GetPrevDate(cPrevAccessDate);

		//printf("\n Eff:Yesterday date  is..:[%s]\n",cPrevAccessDate);fflush(stdout);

		//t5GetPrevDateTo(cPrevAccessDateTo);		
		
		//ITK_string_to_date(cPrevAccessDate,&dateFrom);fflush(stdout);
		//ITK_string_to_date(cCurrentAccessDate,&dateTo);
		
/* 		if(fromDt == NULL)
		{
			printf("\n Null input for fromDate...Exiting..\n");
			return ifail;
		}
		tc_strcpy(fromDateStr, fromDt);
		tc_strcat(fromDateStr," 00:00");
		printf("\nFrom Date ====> %s\n",fromDateStr);fflush(stdout); */
		
		//ITK_string_to_date(fromDateStr,&dateFrom1);
		
		//ITK_string_to_date(cCurrentAccessDateTo,&dateTo);
		
		//printf("\n Eff:Yesterday To date  is..:[%s]\n",cPrevAccessDateTo);fflush(stdout);
		
		//printf("\nQuery executing based on - Date Range: %s to %s\n",cPrevAccessDate,cCurrentAccessDateTo);fflush(stdout);
		
		dateArray[0]=dateFrom;
		//dateArray[0]=dateFrom1;
		dateArray[1]=dateTo;
		
	
	//Step 1-   Creates a new enquiry.
		ifail = POM_enquiry_create ("find_dml_objs" );		
		//Step 2 - add the list to the select clause of the query
		if(ifail == ITK_ok)
		{
			ifail = POM_enquiry_add_select_attrs ("find_dml_objs","T5_ERCIndRevision",1,select_attrs);
		}
		
		//Step 3a - create a date value object.
		if(ifail == ITK_ok)
		{
			ifail = POM_enquiry_set_date_value ("find_dml_objs","expr_dates", 2 ,(const date_t*)dateArray,POM_enquiry_bind_value);
		}		
		//Step 4a - create an expression for pom creation_date = Date using the value "expr_dates" 
		if(ifail == ITK_ok)
		{
			ifail = POM_enquiry_set_attr_expr ("find_dml_objs","expr_dates_between","T5_ERCIndRevision","creation_date",POM_enquiry_between,"expr_dates");
		}		
		
		if(ifail == ITK_ok)
		{
			ifail = POM_enquiry_set_where_expr ("find_dml_objs","expr_dates_between");
		}		
		// Step 7 Order by clause 
		if(ifail == ITK_ok)
		{
			ifail = POM_enquiry_add_order_attr ("find_dml_objs","T5_ERCIndRevision", "creation_date", POM_enquiry_asc_order);
			
			ifail = POM_enquiry_add_order_attr ("find_dml_objs","T5_ERCIndRevision", "t5RefNo", POM_enquiry_asc_order);
		}	
		//Step 8 - Executes the query and fetches the data.
		if (ifail == ITK_ok)
        {
            ifail = POM_enquiry_execute("find_dml_objs", &n_dmls ,&n_cols, &values );
        }		
		//Step 9 - Delete the query and its sub-queries
        if (ifail == ITK_ok)
        {
            ifail = POM_enquiry_delete("find_dml_objs");
        }
		
		printf("\n No of DMLs==>%d\n",n_dmls);fflush(stdout);


	
		int i = 0;
		tag_t indTag = NULLTAG;
		char* IndNo = NULL;
		char* dmlReleaseType = NULL;			
		char* dmlRelTypeDisplayStr = NULL;
		char* dmlBusUnit	=	NULL;
		char* dmlBusUnitStr	=	NULL;
		char* creationDt = NULL;
		char* drstatS = NULL;
		char* drstatS1 = NULL;
		int dmlCnt = 0;
		char * dmlRelStatS = NULL;
		char * IndRefNo = NULL;
		char * IndBU = NULL;
		char * IndcreationDtTime = NULL;
		char * IndcreationDt = NULL;
		char * Indt5ERCIndentee = NULL;
		char * Indt5Indentee = NULL;
		char * IndtPlatform = NULL;
		char * Indt5ERIndSec = NULL;
		char * IndDummyRefNo = NULL;
		char * IndCurrDec = NULL;
		char * IndERIndSec = NULL;
		char * Indt5PrjCode = NULL;
		char * IndPurOfInd = NULL;
		char * Indcreator = NULL;
		char * IndPrtIndCat = NULL;
		char * IndOwnUser = NULL;
		char * IndDesDt = NULL;
		char * Indlast_mod_date = NULL;
		char * Indt5WBS = NULL;
		char * Indt5IndWbsDes = NULL;
		char * Indt5PrtIndCat = NULL;
		char * Indt5IndVehno = NULL;
		char * tempPrevInt = NULL;
		tempPrevInt=(char *) MEM_alloc(150);
		tc_strcpy(tempPrevInt,"");
		
		char*			indDesigner		= NULL;
		char*			IndRelStat		= NULL;
		char * Indowning_user = NULL;
		char * indPrtRel = NULL;
		tag_t* dmlObjSet = NULLTAG;
		int	is = 0;		
		
		
		//UJJAWAL KUMAR
		
		char *Inf1val = (char *) malloc(20*sizeof(char));
		tag_t tSysQryobj = NULLTAG;
		int nSys_entries = 1;
		int nSys_Qryobj_found = 0;
		tag_t* tSysQryobj_results = NULLTAG;
		int z = 0;
		int n = 0;
		char* sysval = NULL;
		char* Info2String = NULL;
		char* t5_SubSyscd_Str = NULL;
		char* sinfo1Dup = NULL;
		char* sinfo1tok = NULL;
		char* PlatformDup = NULL;
		tag_t* CO_ObjectsSet = NULLTAG;
		tag_t queriedCO_Object = NULLTAG;
		
		ITK_CALL(QRY_find2("Control Objects...",&tSysQryobj));
		if(tSysQryobj!=NULLTAG)
		{
			printf("\n Control Objects... Query Found Successfully..!!\n");fflush(stdout);
			char *SysEntries[1]  = {"SYSCD"};
			char *SysValues[1]  = {"PartPlatform"};
			ITK_CALL(QRY_execute(tSysQryobj, nSys_entries, SysEntries, SysValues, &nSys_Qryobj_found, &tSysQryobj_results));
			printf("\n -----------------------------------------------\n");fflush(stdout);
			printf("\n UJJ No of PartPlatform CO Objects Found: [%d]\n",nSys_Qryobj_found);fflush(stdout);
			printf("\n -----------------------------------------------\n");fflush(stdout);
			if(nSys_Qryobj_found > 0)
			{
				for (n = 0; n < nSys_Qryobj_found; n++)
				{	
							
					//queriedCO_Object = tSysQryobj_results[n];
					
					AOM_ask_value_string(tSysQryobj_results[n],"t5_Syscd",&sysval);
					AOM_ask_value_string(tSysQryobj_results[n],"t5_SubSyscd",&t5_SubSyscd_Str);
					AOM_ask_value_string(tSysQryobj_results[n],"t5_Userinfo2",&Info2String);						
					
					printf("\n UJJ [%d] %s %s %s",n,sysval,t5_SubSyscd_Str,Info2String);fflush(stdout);						
															
					if(tSysQryobj_results[n]!=NULLTAG)
					{
						t5AddTagObjToSet(&z,&CO_ObjectsSet,tSysQryobj_results[n]);
					
						//printf("\n UJJ Added CO Object %d to  CO_ObjectsSet\n",n);fflush(stdout);
					}						
					
				}
			}
		}
		
				
		int j=0;
		char* CO_sysval				=	NULL;
		char* CO_t5_SubSyscd_Str	=	NULL;
		char* CO_Info2String		=	NULL;
		tag_t CO_Object = NULLTAG;		
		
		for(j=0;j<n;j++)
		{
						
			CO_Object = CO_ObjectsSet[j];					
			
			if (CO_Object != NULLTAG)
			{				
				AOM_ask_value_string(CO_Object,"t5_Syscd",&CO_sysval);						
				AOM_ask_value_string(CO_Object,"t5_SubSyscd",&CO_t5_SubSyscd_Str);						
				AOM_ask_value_string(CO_Object,"t5_Userinfo2",&CO_Info2String);				
				
				printf("\n UJJ-PRINT--> [%d] %s %s %s",j,CO_sysval,CO_t5_SubSyscd_Str,CO_Info2String);fflush(stdout);				
			}			
			
			if(tc_strcmp(CO_Info2String,"T5_ChangeTaskRevision")==0)
			{
				int partCnt=0;
				tag_t *partTagObjects = NULLTAG;
				tag_t partTag = NULLTAG;
			}
		}
		
		
		
		//n_dmls = 0;
		
		printf("\n UJJ No of DMLs==>%d\n",n_dmls);fflush(stdout);
		
		
		
		if(n_dmls > 0)
		{
			FILE * DmlRelFile		=NULL;
			DmlRelFile = fopen("Report.csv", "w");
			//fprintf(DmlRelFile,"Indent Ref. No,Indent Creation Date,User Reference No,Business Unit,Indenting Agency,Project Code,Last Modified Date,WBS,WBS Desc,Proto Indent Category,Vehicle/VC No.,HEAD OF PROTOTYPE PLANNING, Reviewer,Current Owner(Pending with Whom?),Approval Date,Current Status of the Indent (Same as like TCE),Claim/Unclaim Date,Current Stage of the Indent,Closure Date,Part Number,Revision/Sequence,Description of Item,Qty/Set,No. of Sets Req.,Part Category,I.R. Reqd.,TRSO,Supplier Name,TKO,DR Status,Remarks by Indentee,Remarks by Indenter,Remark,");fflush(DmlRelFile);
			//fprintf(DmlRelFile,"Indent Ref. No,User Reference No,STATUS,REMARKS,Project Code,Business Unit,WBS,PURPOSE OF INDENT,ENGINEER / RAISER,MANAGER / REVIEWER,CE APPROVAL DATE,TcUA (First person receiving "Proto Ind Review"),TcUA (Proto Ind Review , End Date),TcUA (Person who is closing New Proto Ind Review assignment),TcUA (New Proto ind Review, start date),Proto Indent Category,Desire Date,Creation Date,Indentees,Indentee Actor,t5_IndPlatform,Indenting Agency,Part Number,Revision/Sequence,Description of Item,Qty/Set,No. of Sets Req.,Part Category,I.R. Reqd.,TRSO,Supplier Name,TKO,DR Status,Remarks by Indentee,Remarks by Indenter,Remark,");fflush(DmlRelFile);
			
			//fprintf(DmlRelFile,"Indent-No,Current-Status,Indent-Desc,Project-Code,Indent-BU,Creation-Date,Indenting-Agency,Indent-Platform,Indenting-COC,Part-Number,Rev-Seq,Part-Desc");fflush(DmlRelFile);		
			
			fprintf(DmlRelFile,"INDENT_NO,CURRENT_STATUS,INDENT_DESC,PROJECT_CODE,INDENT_BU,CREATION_DATE,INDENTING_AGENCY,INDENT_PLATFORM,INDENTING_COC,PART_NUMBER,REV_SEQ,PART_DESC");fflush(DmlRelFile);		
						
			
			for (i = 0; i < n_dmls; i++ )
			{			
				printf("\n Next indent number ==>%d\n",i);fflush(stdout); 
				indTag  = *(tag_t*)(values[i][0]);
				if(indTag!=NULLTAG)
				{
					
					CALLAPI(AOM_ask_value_string(indTag,"t5RefNo",&IndRefNo));
					//fprintf(DmlRelFile,"\n %s,",IndRefNo);fflush(DmlRelFile);
					if(tc_strcmp(IndRefNo,tempPrevInt)==0)
					{
						continue;
					}
					else
					{
						tc_strcpy(tempPrevInt,IndRefNo);
					}
						
					CALLAPI(AOM_ask_value_string(indTag,"t5DummyRefNo",&IndDummyRefNo));
					CALLAPI(AOM_ask_value_string(indTag,"current_desc",&IndCurrDec));
					CALLAPI(AOM_ask_value_string(indTag,"t5PrjCode",&Indt5PrjCode));
					CALLAPI(AOM_ask_value_string(indTag,"t5ERCIndBU",&IndBU));
					CALLAPI(AOM_ask_value_string(indTag,"t5WBS",&Indt5WBS));
					CALLAPI(AOM_ask_value_string(indTag,"t5ERCIndPurpose",&IndPurOfInd));
					CALLAPI(AOM_UIF_ask_value(indTag,"owning_user",&IndOwnUser));
					CALLAPI(AOM_ask_value_string(indTag,"t5PrtIndCat",&IndPrtIndCat));
					CALLAPI(AOM_UIF_ask_value(indTag,"t5_Desire_Date",&IndDesDt));
					CALLAPI(AOM_UIF_ask_value(indTag,"creation_date",&IndcreationDtTime));
					CALLAPI(AOM_UIF_ask_value(indTag,"t5ERCIndentee",&Indt5ERCIndentee));
					CALLAPI(AOM_UIF_ask_value(indTag,"t5Indentee",&Indt5Indentee));
					CALLAPI(AOM_UIF_ask_value(indTag,"t5_IndPlatform",&IndtPlatform));
					CALLAPI(AOM_UIF_ask_value(indTag,"t5ERIndSec",&Indt5ERIndSec));
					
					IndcreationDt = subString(IndcreationDtTime,0,11);
					
					removeNonAsciiChars(IndDummyRefNo);
					STRNG_replace_str(IndDummyRefNo,","," ",&IndDummyRefNo);
					STRNG_replace_str(IndDummyRefNo,"&","&amp;",&IndDummyRefNo);
					STRNG_replace_str(IndDummyRefNo,"<","&lt;",&IndDummyRefNo);
					STRNG_replace_str(IndDummyRefNo,">","&gt;",&IndDummyRefNo);
					
					removeNonAsciiChars(IndCurrDec);
					STRNG_replace_str(IndCurrDec,","," ",&IndCurrDec);
					STRNG_replace_str(IndCurrDec,"&","&amp;",&IndCurrDec);
					STRNG_replace_str(IndCurrDec,"<","&lt;",&IndCurrDec);
					STRNG_replace_str(IndCurrDec,">","&gt;",&IndCurrDec);
										
										

					//fprintf(DmlRelFile,"%s,",IndDummyRefNo);fflush(DmlRelFile);
					//fprintf(DmlRelFile,"%s,",IndCurrDec);fflush(DmlRelFile);
					//fprintf(DmlRelFile,"%s,",Indt5PrjCode);fflush(DmlRelFile);
					//fprintf(DmlRelFile,"%s,",IndBU);fflush(DmlRelFile);
					//fprintf(DmlRelFile,"%s,",Indt5WBS);fflush(DmlRelFile);
					//fprintf(DmlRelFile,"%s,",IndPurOfInd);fflush(DmlRelFile);
					//fprintf(DmlRelFile,"%s,",Indcreator);fflush(DmlRelFile);
					
					//CALLAPI(AOM_ask_value_string(indTag,"t5ERIndSec",&IndERIndSec));
					
					//CALLAPI(AOM_UIF_ask_value(indTag,"last_mod_date",&Indlast_mod_date));
					//CALLAPI(AOM_ask_value_string(indTag,"last_mod_date",&Indlast_mod_date));
					
					//CALLAPI(AOM_ask_value_string(indTag,"t5IndWbsDes",&Indt5IndWbsDes));
					//CALLAPI(AOM_ask_value_string(indTag,"t5PrtIndCat",&Indt5PrtIndCat));
					//CALLAPI(AOM_ask_value_string(indTag,"t5IndVehno",&Indt5IndVehno));
					//CALLAPI(AOM_ask_value_string(indTag,"owning_user",&Indowning_user));
					//CALLAPI(AOM_ask_value_string(indTag,"t5PrtIndAct",&indDesigner));
					//CALLAPI(AOM_ask_value_string(indTag,"T5ERCDtl",&indPrtRel));
					//printf("\n T5ERCDtl ==>%s\n",indPrtRel);fflush(stdout);
					
					printf("\n t5RefNo  == [%s]", IndRefNo);fflush(stdout);
					
					tag_t job_Tag2    =     NULLTAG;
					tag_t jobtype_Tag2 =    NULLTAG;
					tag_t rootTask2    =    NULLTAG;
					tag_t* subtask   =      NULLTAG;
					tag_t subtaskobj  =      NULLTAG;
					
					//char dRftSpectype_name[TCTYPE_name_size_c+1];
					char *dRftSpectype_name=  NULL;
					char	*EIDLinfo2		=  NULL;
					char	*subtask1		=  NULL;
					int tskcount2=0;
					char	*parent_name2		=  NULL;
					
					if(EPM_get_current_job(indTag,&job_Tag2,&jobtype_Tag2));
					if(TCTYPE_ask_name2(jobtype_Tag2,&dRftSpectype_name));
					if(AOM_ask_value_string(job_Tag2,"object_name",&EIDLinfo2)) ;
					printf("\n Inside [%s] [%s] \n",dRftSpectype_name,EIDLinfo2);fflush(stdout);
					
					if(EPM_ask_root_task(job_Tag2,&rootTask2));               					    
					if(EPM_ask_sub_tasks(rootTask2,&tskcount2,&subtask));                           
					if(AOM_ask_value_string(rootTask2,"object_name",&parent_name2));
					printf("\n Parent Name2: %s",parent_name2);fflush(stdout);
					printf("No of subtasks = %d\n",tskcount2);fflush(stdout);
					int subtkC=0;
					
					char	*AMCPRevsubtask1			=  NULL;
					char	*AMCPRevsubtask1Performaer		=  NULL;
					char	*AMCPRevsubtasktype		=  NULL;
					char	*AMCPRevsubtaskState		=  NULL;
					char	*AMCPRevsubtaskValidSignOff		=  NULL;
					char	*AMCPRevsubtaskRev		=  NULL;
					char	*AMCPRevsubtaskEnDt		=  NULL;
					char	*AMCPRevsubtaskStDt		=  NULL;
					
					char	*MgrRevsubtask1		=  NULL;
					char	*MgrRevsubtask1Performaer		=  NULL;
					char	*MgrRevsubtasktype		=  NULL;
					char	*MgrRevsubtaskState		=  NULL;
					char	*MgrRevsubtaskValidSignOff		=  NULL;
					char	*MgrRevsubtaskRev		=  NULL;
					char	*MgrRevsubtaskEnDt		=  NULL;
					char	*MgrRevsubtaskStDt		=  NULL;
					
					char	*CERevsubtask1			=  NULL;
					char	*CERevsubtask1Performaer		=  NULL;
					char	*CERevsubtasktype		=  NULL;
					char	*CERevsubtaskState		=  NULL;
					char	*CERevsubtaskValidSignOff		=  NULL;
					char	*CERevsubtaskRev		=  NULL;
					char	*CERevsubtaskStDt		=  NULL;
					char	*CERevsubtaskEnDt		=  NULL;
					
					char	*PIRevsubtask1		=  NULL;
					char	*PIRevsubtask1Performaer		=  NULL;
					char	*PIRevsubtasktype		=  NULL;
					char	*PIRevsubtaskState		=  NULL;
					char	*PIRevsubtaskValidSignOff		=  NULL;
					char	*PIRevsubtaskRev		=  NULL;
					char	*PIRevsubtaskStDt		=  NULL;
					char	*PIRevsubtaskEnDt		=  NULL;
					
					char	*NPIRevsubtask1				=  NULL;
					char	*NPIRevsubtask1Performaer		=  NULL;
					char	*NPIRevsubtasktype		=  NULL;
					char	*NPIRevsubtaskState		=  NULL;
					char	*NPIRevsubtaskValidSignOff		=  NULL;
					char	*NPIRevsubtaskRev		=  NULL;
					char	*NPIRevsubtaskStDt		=  NULL;
					char	*NPIRevsubtaskEnDt		=  NULL;
						
					for (subtkC=0; subtkC< tskcount2; subtkC++)
					{
						
						subtask1		=  NULL;

						printf("\n subtkC: [%d]",subtkC);fflush(stdout);
						if(AOM_ask_value_string(subtask[subtkC],"object_name",&subtask1));
						printf("\n  subtask1is: [%s]",subtask1);fflush(stdout);
						
						
						
						if(tc_strcmp(subtask1, "Assign Mgr, Chf, Proto Reviewer") == 0)
						{
							AMCPRevsubtask1			=  NULL;
							AMCPRevsubtask1Performaer		=  NULL;
							AMCPRevsubtasktype		=  NULL;
							AMCPRevsubtaskState		=  NULL;
							AMCPRevsubtaskValidSignOff		=  NULL;
							AMCPRevsubtaskRev		=  NULL;
							AMCPRevsubtaskEnDt		=  NULL;
							AMCPRevsubtaskStDt		=  NULL;
						
							printf("\n subtkC: [%d]",subtkC);fflush(stdout);
							ITK_CALL(AOM_ask_value_string(subtask[subtkC],"object_name",&AMCPRevsubtask1));
							printf("\n  AMCPRevsubtask1: [%s]",AMCPRevsubtask1);fflush(stdout);
							
							STRNG_replace_str(AMCPRevsubtask1,","," ",&AMCPRevsubtask1);
							
							if( AOM_UIF_ask_value(subtask[subtkC],"fnd0Performer",&AMCPRevsubtask1Performaer));
							printf("\n AMCPRevsubtask1Performaer == [%s]", AMCPRevsubtask1Performaer);fflush(stdout);
							
							STRNG_replace_str(AMCPRevsubtask1Performaer,","," ",&AMCPRevsubtask1Performaer);
							
							ITK_CALL(AOM_ask_value_string(subtask[subtkC],"task_type",&AMCPRevsubtasktype));
							printf("\n  AMCPRevsubtasktype: [%s]",AMCPRevsubtasktype);fflush(stdout);
							
							ITK_CALL(AOM_ask_value_string(subtask[subtkC],"task_state",&AMCPRevsubtaskState));
							printf("\n  AMCPRevsubtaskState: [%s]",AMCPRevsubtaskState);fflush(stdout);
							
							if(AOM_ask_value_string(subtask[subtkC],"valid_signoffs",&AMCPRevsubtaskValidSignOff));
							printf("\n  AMCPRevsubtaskValidSignOff: [%s]",AMCPRevsubtaskValidSignOff);fflush(stdout);
							
							STRNG_replace_str(AMCPRevsubtaskValidSignOff,","," ",&AMCPRevsubtaskValidSignOff);

							if( AOM_UIF_ask_value(subtask[subtkC],"awp0Reviewers",&AMCPRevsubtaskRev));
							printf("\n AMCPRevsubtaskRev == [%s]", AMCPRevsubtaskRev);fflush(stdout);
							
							STRNG_replace_str(AMCPRevsubtaskRev,","," ",&AMCPRevsubtaskRev);
							
							if( AOM_UIF_ask_value(subtask[subtkC],"fnd0StartDate",&AMCPRevsubtaskStDt));
							printf("\n AMCPRevsubtaskStDt == [%s]", AMCPRevsubtaskStDt);fflush(stdout);
							
							if( AOM_UIF_ask_value(subtask[subtkC],"fnd0EndDate",&AMCPRevsubtaskEnDt));
							printf("\n AMCPRevsubtaskEnDt == [%s]", AMCPRevsubtaskEnDt);fflush(stdout);
							
							//fprintf(DmlRelFile,"%s,%s,%s,%s,%s,%s,%s,%s,",AMCPRevsubtask1,AMCPRevsubtask1Performaer,AMCPRevsubtasktype,AMCPRevsubtaskState,AMCPRevsubtaskValidSignOff,AMCPRevsubtaskRev,AMCPRevsubtaskStDt,AMCPRevsubtaskEnDt);fflush(DmlRelFile);

						}
							
						
						
						if(tc_strcmp(subtask1, "Manager Review") == 0)
						{
							MgrRevsubtask1		=  NULL;
							MgrRevsubtask1Performaer		=  NULL;
							MgrRevsubtasktype		=  NULL;
							MgrRevsubtaskState		=  NULL;
							MgrRevsubtaskValidSignOff		=  NULL;
							MgrRevsubtaskRev		=  NULL;
							MgrRevsubtaskEnDt		=  NULL;
							MgrRevsubtaskStDt		=  NULL;

							printf("\n subtkC: [%d]",subtkC);fflush(stdout);
							ITK_CALL(AOM_ask_value_string(subtask[subtkC],"object_name",&MgrRevsubtask1));
							printf("\n  MgrRevsubtask1: [%s]",MgrRevsubtask1);fflush(stdout);
							
							if( AOM_UIF_ask_value(subtask[subtkC],"fnd0Performer",&MgrRevsubtask1Performaer));
							printf("\n MgrRevsubtask1Performaer == [%s]", MgrRevsubtask1Performaer);fflush(stdout);
							
							STRNG_replace_str(MgrRevsubtask1Performaer,","," ",&MgrRevsubtask1Performaer);
							
							ITK_CALL(AOM_ask_value_string(subtask[subtkC],"task_type",&MgrRevsubtasktype));
							printf("\n  MgrRevsubtasktype: [%s]",MgrRevsubtasktype);fflush(stdout);
							
							ITK_CALL(AOM_ask_value_string(subtask[subtkC],"task_state",&MgrRevsubtaskState));
							printf("\n  MgrRevsubtaskState: [%s]",MgrRevsubtaskState);fflush(stdout);
							
							if(AOM_ask_value_string(subtask[subtkC],"valid_signoffs",&MgrRevsubtaskValidSignOff));
							printf("\n  MgrRevsubtaskValidSignOff: [%s]",MgrRevsubtaskValidSignOff);fflush(stdout);
							
							STRNG_replace_str(MgrRevsubtaskValidSignOff,","," ",&MgrRevsubtaskValidSignOff);

							if( AOM_UIF_ask_value(subtask[subtkC],"awp0Reviewers",&MgrRevsubtaskRev));
							printf("\n MgrRevsubtaskRev == [%s]", MgrRevsubtaskRev);fflush(stdout);
							
							STRNG_replace_str(MgrRevsubtaskRev,","," ",&MgrRevsubtaskRev);
							
							if( AOM_UIF_ask_value(subtask[subtkC],"fnd0StartDate",&MgrRevsubtaskStDt));
							printf("\n MgrRevsubtaskStDt == [%s]", MgrRevsubtaskStDt);fflush(stdout);
							
							if( AOM_UIF_ask_value(subtask[subtkC],"fnd0EndDate",&MgrRevsubtaskEnDt));
							printf("\n MgrRevsubtaskEnDt == [%s]", MgrRevsubtaskEnDt);fflush(stdout);
							
							//fprintf(DmlRelFile,"%s,%s,%s,%s,%s,%s,%s,%s,",MgrRevsubtask1,MgrRevsubtask1Performaer,MgrRevsubtasktype,MgrRevsubtaskState,MgrRevsubtaskValidSignOff,MgrRevsubtaskRev,MgrRevsubtaskStDt,MgrRevsubtaskEnDt);fflush(DmlRelFile);

						}
						
						
						
						
						if(tc_strcmp(subtask1, "Chief Eng Review") == 0)
						{
							
							CERevsubtask1			=  NULL;
							CERevsubtask1Performaer		=  NULL;
							CERevsubtasktype		=  NULL;
							CERevsubtaskState		=  NULL;
							CERevsubtaskValidSignOff		=  NULL;
							CERevsubtaskRev		=  NULL;
							CERevsubtaskStDt		=  NULL;
							CERevsubtaskEnDt		=  NULL;
						
							printf("\n subtkC: [%d]",subtkC);fflush(stdout);
							ITK_CALL(AOM_ask_value_string(subtask[subtkC],"object_name",&CERevsubtask1));
							printf("\n  CERevsubtask1: [%s]",CERevsubtask1);fflush(stdout);
							
							if( AOM_UIF_ask_value(subtask[subtkC],"fnd0Performer",&CERevsubtask1Performaer));
							printf("\n CERevsubtask1Performaer == [%s]", CERevsubtask1Performaer);fflush(stdout);
							
							STRNG_replace_str(CERevsubtask1Performaer,","," ",&CERevsubtask1Performaer);
							
							ITK_CALL(AOM_ask_value_string(subtask[subtkC],"task_type",&CERevsubtasktype));
							printf("\n  CERevsubtasktype: [%s]",CERevsubtasktype);fflush(stdout);
							
							ITK_CALL(AOM_ask_value_string(subtask[subtkC],"task_state",&CERevsubtaskState));
							printf("\n  CERevsubtaskState: [%s]",CERevsubtaskState);fflush(stdout);
							
							if(AOM_ask_value_string(subtask[subtkC],"valid_signoffs",&CERevsubtaskValidSignOff));
							printf("\n  CERevsubtaskValidSignOff: [%s]",CERevsubtaskValidSignOff);fflush(stdout);
							
							STRNG_replace_str(CERevsubtaskValidSignOff,","," ",&CERevsubtaskValidSignOff);

							if( AOM_UIF_ask_value(subtask[subtkC],"awp0Reviewers",&CERevsubtaskRev));
							printf("\n CERevsubtaskRev == [%s]", CERevsubtaskRev);fflush(stdout);
							
							STRNG_replace_str(CERevsubtaskRev,","," ",&CERevsubtaskRev);
							
							if( AOM_UIF_ask_value(subtask[subtkC],"fnd0StartDate",&CERevsubtaskStDt));
							printf("\n CERevsubtaskStDt == [%s]", CERevsubtaskStDt);fflush(stdout);
							
							if( AOM_UIF_ask_value(subtask[subtkC],"fnd0EndDate",&CERevsubtaskEnDt));
							printf("\n CERevsubtaskEnDt == [%s]", CERevsubtaskEnDt);fflush(stdout);
							
							//fprintf(DmlRelFile,"%s,%s,%s,%s,%s,%s,%s,%s,",CERevsubtask1,CERevsubtask1Performaer,CERevsubtasktype,CERevsubtaskState,CERevsubtaskValidSignOff,CERevsubtaskRev,CERevsubtaskStDt,CERevsubtaskEnDt);fflush(DmlRelFile);

						}
						
						
						
						if(tc_strcmp(subtask1, "Proto Ind Review") == 0)
						{
							
							PIRevsubtask1		=  NULL;
							PIRevsubtask1Performaer		=  NULL;
							PIRevsubtasktype		=  NULL;
							PIRevsubtaskState		=  NULL;
							PIRevsubtaskValidSignOff		=  NULL;
							PIRevsubtaskRev		=  NULL;
							PIRevsubtaskStDt		=  NULL;
							PIRevsubtaskEnDt		=  NULL;
						
							printf("\n subtkC: [%d]",subtkC);fflush(stdout);
							ITK_CALL(AOM_ask_value_string(subtask[subtkC],"object_name",&PIRevsubtask1));
							printf("\n  PIRevsubtask1: [%s]",PIRevsubtask1);fflush(stdout);
							
							if( AOM_UIF_ask_value(subtask[subtkC],"fnd0Performer",&PIRevsubtask1Performaer));
							printf("\n PIRevsubtask1Performaer == [%s]", PIRevsubtask1Performaer);fflush(stdout);
							
							STRNG_replace_str(PIRevsubtask1Performaer,","," ",&PIRevsubtask1Performaer);
							
							ITK_CALL(AOM_ask_value_string(subtask[subtkC],"task_type",&PIRevsubtasktype));
							printf("\n  PIRevsubtasktype: [%s]",PIRevsubtasktype);fflush(stdout);
							
							ITK_CALL(AOM_ask_value_string(subtask[subtkC],"task_state",&PIRevsubtaskState));
							printf("\n  PIRevsubtaskState: [%s]",PIRevsubtaskState);fflush(stdout);
							
							if(AOM_ask_value_string(subtask[subtkC],"valid_signoffs",&PIRevsubtaskValidSignOff));
							printf("\n  PIRevsubtaskValidSignOff: [%s]",PIRevsubtaskValidSignOff);fflush(stdout);
							
							STRNG_replace_str(PIRevsubtaskValidSignOff,","," ",&PIRevsubtaskValidSignOff);

							if( AOM_UIF_ask_value(subtask[subtkC],"awp0Reviewers",&PIRevsubtaskRev));
							printf("\n PIRevsubtaskRev == [%s]", PIRevsubtaskRev);fflush(stdout);
							
							STRNG_replace_str(PIRevsubtaskRev,","," ",&PIRevsubtaskRev);
							
							if( AOM_UIF_ask_value(subtask[subtkC],"fnd0StartDate",&PIRevsubtaskStDt));
							printf("\n PIRevsubtaskStDt == [%s]", PIRevsubtaskStDt);fflush(stdout);
							
							if( AOM_UIF_ask_value(subtask[subtkC],"fnd0EndDate",&PIRevsubtaskEnDt));
							printf("\n PIRevsubtaskEnDt == [%s]", PIRevsubtaskEnDt);fflush(stdout);
							
							//fprintf(DmlRelFile,"%s,%s,%s,%s,%s,%s,%s,%s,",PIRevsubtask1,PIRevsubtask1Performaer,PIRevsubtasktype,PIRevsubtaskState,PIRevsubtaskValidSignOff,PIRevsubtaskRev,PIRevsubtaskStDt,PIRevsubtaskEnDt);fflush(DmlRelFile);


						}
						
						
						
						
						if(tc_strcmp(subtask1, "New Proto Ind Review 1") == 0)
						{
							
							NPIRevsubtask1				=  NULL;
							NPIRevsubtask1Performaer		=  NULL;
							NPIRevsubtasktype		=  NULL;
							NPIRevsubtaskState		=  NULL;
							NPIRevsubtaskValidSignOff		=  NULL;
							NPIRevsubtaskRev		=  NULL;
							NPIRevsubtaskStDt		=  NULL;
							NPIRevsubtaskEnDt		=  NULL;
						
							printf("\n subtkC: [%d]",subtkC);fflush(stdout);
							ITK_CALL(AOM_ask_value_string(subtask[subtkC],"object_name",&NPIRevsubtask1));
							printf("\n  NPIRevsubtask1: [%s]",NPIRevsubtask1);fflush(stdout);
							
							STRNG_replace_str(NPIRevsubtask1,","," ",&NPIRevsubtask1);
							
							if( AOM_UIF_ask_value(subtask[subtkC],"fnd0Performer",&NPIRevsubtask1Performaer));
							printf("\n NPIRevsubtask1Performaer == [%s]", NPIRevsubtask1Performaer);fflush(stdout);
							
							STRNG_replace_str(NPIRevsubtask1Performaer,","," ",&NPIRevsubtask1Performaer);
							
							ITK_CALL(AOM_ask_value_string(subtask[subtkC],"task_type",&NPIRevsubtasktype));
							printf("\n  NPIRevsubtasktype: [%s]",NPIRevsubtasktype);fflush(stdout);
							
							ITK_CALL(AOM_ask_value_string(subtask[subtkC],"task_state",&NPIRevsubtaskState));
							printf("\n  NPIRevsubtaskState: [%s]",NPIRevsubtaskState);fflush(stdout);
							
							if(AOM_ask_value_string(subtask[subtkC],"valid_signoffs",&NPIRevsubtaskValidSignOff));
							printf("\n  NPIRevsubtaskValidSignOff: [%s]",NPIRevsubtaskValidSignOff);fflush(stdout);
							
							STRNG_replace_str(NPIRevsubtaskValidSignOff,","," ",&NPIRevsubtaskValidSignOff);

							if( AOM_UIF_ask_value(subtask[subtkC],"awp0Reviewers",&NPIRevsubtaskRev));
							printf("\n NPIRevsubtaskRev == [%s]", NPIRevsubtaskRev);fflush(stdout);
							
							STRNG_replace_str(NPIRevsubtaskRev,","," ",&NPIRevsubtaskRev);
							
							if( AOM_UIF_ask_value(subtask[subtkC],"fnd0StartDate",&NPIRevsubtaskStDt));
							printf("\n NPIRevsubtaskStDt == [%s]", NPIRevsubtaskStDt);fflush(stdout);
							
							if( AOM_UIF_ask_value(subtask[subtkC],"fnd0EndDate",&NPIRevsubtaskEnDt));
							printf("\n NPIRevsubtaskEnDt == [%s]", NPIRevsubtaskEnDt);fflush(stdout);
							
							//fprintf(DmlRelFile,"%s,%s,%s,%s,%s,%s,%s,%s,",NPIRevsubtask1,NPIRevsubtask1Performaer,NPIRevsubtasktype,NPIRevsubtaskState,NPIRevsubtaskValidSignOff,NPIRevsubtaskRev,NPIRevsubtaskStDt,NPIRevsubtaskEnDt);fflush(DmlRelFile);

						}
					}
					char* IndWFStatus = (char *)MEM_alloc(50 * sizeof(char));
					tc_strcpy(IndWFStatus,"");
					if((tc_strcmp(AMCPRevsubtaskEnDt,"")==0) || (tc_strcmp(AMCPRevsubtaskEnDt,NULL)==0))
					{
						tc_strcpy(IndWFStatus,"With Designer");
					}
					else if((tc_strcmp(MgrRevsubtaskEnDt,"")==0) || (tc_strcmp(MgrRevsubtaskEnDt,NULL)==0))
					{
						tc_strcpy(IndWFStatus,"With Manager");
					}
					else if((tc_strcmp(CERevsubtaskEnDt,"")==0) || (tc_strcmp(CERevsubtaskEnDt,NULL)==0))
					{
						tc_strcpy(IndWFStatus,"Chief Engg"); 
					}
					else if((tc_strcmp(PIRevsubtaskEnDt,"")==0) || (tc_strcmp(PIRevsubtaskEnDt,NULL)==0))
					{
						tc_strcpy(IndWFStatus,"Photo user"); 
					}
					else if((tc_strcmp(NPIRevsubtaskEnDt,"")==0) || (tc_strcmp(NPIRevsubtaskEnDt,NULL)==0))
					{
						tc_strcpy(IndWFStatus,"New Photo user"); 
					}
					else
					{
						tc_strcpy(IndWFStatus,"Indent Rlz");
					}

					tag_t           relation_type	= NULLTAG;
					int				secObj_count	= 0;
					tag_t           *secondary_list	= NULLTAG;
					tag_t           designObj		= NULLTAG;
					tag_t           relationObj		= NULLTAG;
						
						CALLAPI(GRM_find_relation_type("T5ERCDtl", &relation_type));
						if(relation_type != NULLTAG)
						{
							CALLAPI(GRM_list_secondary_objects_only(indTag, relation_type, &secObj_count, &secondary_list));
							//fprintf(IndExecutioLog,"Design Revision Count with Indent :: %d\n",secObj_count);  fflush(IndExecutioLog);
							printf("\n No of Parts in indent==>%d\n",secObj_count);fflush(stdout);
							if(secObj_count > 0)
							{
								int j=0;
								for(j=0; j<secObj_count; j++)
								{
									designObj = secondary_list[j];
								
									CALLAPI(GRM_find_relation(indTag, designObj, relation_type, &relationObj));
									if (relationObj != NULLTAG)
									{
									
									char*			designRevision		= NULL;
									char*			designRevisionID		= NULL;
									char*			designRevisionDesc		= NULL;
									char*			indDesignQtySet		= NULL;
									char*			indDesignReqQtySet		= NULL;
									char*			indPartIndCategory		= NULL;
									char*			indt5ERIndIRAvl		= NULL;
									char*			indTRSOStatus		= NULL;
									char*			indSupplierName		= NULL;
									char*			indTkoStatus		= NULL;
									char*			indPartStatus		= NULL;
									char*			ind_ERCIndRemarkIndente		= NULL;
									char*			indERCIndRemark		= NULL;
									char*			indRemarkForIndenticalPart		= NULL;
									char*			designRevisionDescNew		= NULL;
									char*			object_type			= NULL;
									CALLAPI(AOM_ask_value_string(designObj,"object_type",&object_type));
									printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
									if (tc_strcmp(object_type,"Design Revision")==0 || tc_strcmp(object_type,"T5_EE_PartRevision")==0 || tc_strcmp(object_type,"T5_ClrPartRevision")==0 )
									{
									CALLAPI(AOM_ask_value_string(designObj,"item_id",&designRevision));
									CALLAPI(AOM_ask_value_string(designObj,"current_revision_id",&designRevisionID));
									//CALLAPI(AOM_ask_value_int(designObj,"sequence_id",&designSeq));	
									CALLAPI(AOM_ask_value_string(designObj,"current_desc",&designRevisionDesc));	
									CALLAPI(AOM_ask_value_string(relationObj,"t5_ERCIndQtySet",&indDesignQtySet));									
									CALLAPI(AOM_ask_value_string(relationObj,"t5_ERCIndReqdSet",&indDesignReqQtySet));
									CALLAPI(AOM_ask_value_string(relationObj,"t5_PartIndCategory",&indPartIndCategory));
									CALLAPI(AOM_ask_value_string(relationObj,"t5ERIndIRAvl",&indt5ERIndIRAvl));
									CALLAPI(AOM_ask_value_string(relationObj,"t5_TRSOStatus",&indTRSOStatus));
									CALLAPI(AOM_ask_value_string(relationObj,"t5_SupplierName",&indSupplierName));
									CALLAPI(AOM_ask_value_string(relationObj,"t5_TkoStatus",&indTkoStatus));
									CALLAPI(AOM_ask_value_string(relationObj,"t5PartStatus",&indPartStatus));
									CALLAPI(AOM_ask_value_string(relationObj,"t5_ERCIndRemarkIndentee",&ind_ERCIndRemarkIndente));
									CALLAPI(AOM_ask_value_string(relationObj,"t5ERCIndRemark",&indERCIndRemark));	
									CALLAPI(AOM_ask_value_string(relationObj,"t5_RemarkForIndenticalPart",&indRemarkForIndenticalPart));
										
									STRNG_replace_str(designRevisionDesc,"\\n"," ",&designRevisionDesc);
									STRNG_replace_str(designRevisionDesc,","," ",&designRevisionDesc);
									STRNG_replace_str(indDesignQtySet,"\\n"," ",&indDesignQtySet);
									STRNG_replace_str(indDesignReqQtySet,"\\n"," ",&indDesignReqQtySet);
									STRNG_replace_str(indPartIndCategory,"\\n"," ",&indPartIndCategory);
									STRNG_replace_str(indt5ERIndIRAvl,"\\n"," ",&indt5ERIndIRAvl);
									STRNG_replace_str(indTRSOStatus,"\\n"," ",&indTRSOStatus);
									STRNG_replace_str(indSupplierName,"\\n"," ",&indSupplierName);
									STRNG_replace_str(indTkoStatus,"\\n"," ",&indTkoStatus);
									STRNG_replace_str(indPartStatus,"\\n"," ",&indPartStatus);
									STRNG_replace_str(ind_ERCIndRemarkIndente,"\\n"," ",&ind_ERCIndRemarkIndente);
									STRNG_replace_str(indERCIndRemark,"\\n"," ",&indERCIndRemark);
									STRNG_replace_str(indRemarkForIndenticalPart,"\\n"," ",&indRemarkForIndenticalPart);
										
									STRNG_replace_str(designRevisionDesc,"<","(",&designRevisionDesc);
									STRNG_replace_str(indDesignQtySet,"<","(",&indDesignQtySet);
									STRNG_replace_str(indDesignReqQtySet,"<","(",&indDesignReqQtySet);
									STRNG_replace_str(indPartIndCategory,"<","(",&indPartIndCategory);
									STRNG_replace_str(indt5ERIndIRAvl,"<","(",&indt5ERIndIRAvl);
									STRNG_replace_str(indTRSOStatus,"<","(",&indTRSOStatus);
									STRNG_replace_str(indSupplierName,"<","(",&indSupplierName);
									STRNG_replace_str(indTkoStatus,"<","(",&indTkoStatus);
									STRNG_replace_str(indPartStatus,"<","(",&indPartStatus);
									STRNG_replace_str(ind_ERCIndRemarkIndente,"<","(",&ind_ERCIndRemarkIndente);
									STRNG_replace_str(indERCIndRemark,"<","(",&indERCIndRemark);
									STRNG_replace_str(indRemarkForIndenticalPart,"<","(",&indRemarkForIndenticalPart);
									
									
									STRNG_replace_str(designRevisionDesc,">",")",&designRevisionDesc);
									STRNG_replace_str(indDesignQtySet,">",")",&indDesignQtySet);
									STRNG_replace_str(indDesignReqQtySet,">",")",&indDesignReqQtySet);
									STRNG_replace_str(indPartIndCategory,">",")",&indPartIndCategory);
									STRNG_replace_str(indt5ERIndIRAvl,">",")",&indt5ERIndIRAvl);
									STRNG_replace_str(indTRSOStatus,">",")",&indTRSOStatus);
									STRNG_replace_str(indSupplierName,">",")",&indSupplierName);
									STRNG_replace_str(indTkoStatus,">",")",&indTkoStatus);
									STRNG_replace_str(indPartStatus,">",")",&indPartStatus);
									STRNG_replace_str(ind_ERCIndRemarkIndente,">",")",&ind_ERCIndRemarkIndente);
									STRNG_replace_str(indERCIndRemark,">",")",&indERCIndRemark);
									STRNG_replace_str(indRemarkForIndenticalPart,">",")",&indRemarkForIndenticalPart);
									
									removeNonAsciiChars(designRevisionDesc);
									removeNonAsciiChars(indDesignQtySet);
									removeNonAsciiChars(indDesignReqQtySet);
									removeNonAsciiChars(indPartIndCategory);
									removeNonAsciiChars(indt5ERIndIRAvl);
									removeNonAsciiChars(indTRSOStatus);
									removeNonAsciiChars(indSupplierName);
									removeNonAsciiChars(indTkoStatus);
									removeNonAsciiChars(indPartStatus);
									removeNonAsciiChars(ind_ERCIndRemarkIndente);
									removeNonAsciiChars(indERCIndRemark);
									removeNonAsciiChars(indRemarkForIndenticalPart);
									char *designRevisionDesc1 = NULL;
									char *indDesignQtySet1 = NULL;
									char *indDesignReqQtySet1 = NULL;
									char *indt5ERIndIRAvl1 = NULL;
									char *indPartIndCategory1 = NULL;
									char *indTRSOStatus1 = NULL;
									char *indSupplierName1 = NULL;
									char *indTkoStatus1 = NULL;
									char *indPartStatus1 = NULL;
									char *ind_ERCIndRemarkIndente1 = NULL;
									char *indERCIndRemark1 = NULL;
									char *indRemarkForIndenticalPart1 = NULL;
									char *TotalQty = NULL;
									
									if(designRevisionDesc != NULL) STRNG_replace_str(designRevisionDesc,"&","&amp;",&designRevisionDesc1);
									if(indDesignQtySet != NULL) STRNG_replace_str(indDesignQtySet,"&","&amp;",&indDesignQtySet1);
									if(indDesignReqQtySet != NULL) STRNG_replace_str(indDesignReqQtySet,"&","&amp;",&indDesignReqQtySet1);
									if(indPartIndCategory != NULL) STRNG_replace_str(indPartIndCategory,"&","&amp;",&indPartIndCategory1);
									if(indt5ERIndIRAvl != NULL) STRNG_replace_str(indt5ERIndIRAvl,"&","&amp;",&indt5ERIndIRAvl1);
									if(indTRSOStatus != NULL) STRNG_replace_str(indTRSOStatus,"&","&amp;",&indTRSOStatus1);
									if(indSupplierName != NULL) STRNG_replace_str(indSupplierName,"&","&amp;",&indSupplierName1);
									if(indTkoStatus != NULL) STRNG_replace_str(indTkoStatus,"&","&amp;",&indTkoStatus1);
									if(indPartStatus != NULL) STRNG_replace_str(indPartStatus,"&","&amp;",&indPartStatus1);
									if(ind_ERCIndRemarkIndente != NULL) STRNG_replace_str(ind_ERCIndRemarkIndente,"&","&amp;",&ind_ERCIndRemarkIndente1);
									if(indERCIndRemark != NULL) STRNG_replace_str(indERCIndRemark,"&","&amp;",&indERCIndRemark1);
									if(indRemarkForIndenticalPart != NULL) STRNG_replace_str(indRemarkForIndenticalPart,"&","&amp;",&indRemarkForIndenticalPart1);
									
									//fprintf(DmlRelFile,"\n,,,,,,,,,,,,,,,,");fflush(DmlRelFile);
									//fprintf(DmlRelFile,"'%s,",designRevision);fflush(DmlRelFile);
									//fprintf(DmlRelFile,"%s,",designRevisionID);fflush(DmlRelFile);
									//fprintf(DmlRelFile,"%s,",indDesignQtySet);fflush(DmlRelFile);
									//fprintf(DmlRelFile,"%s,",indDesignReqQtySet);fflush(DmlRelFile);
									//fprintf(DmlRelFile,"%s,",TotalQty);fflush(DmlRelFile);
									
								/* 	
									Indent Number	
									User Reference number
									Current Status
									Description	
									Project Code	
									Project Platform	
									WBS	
									Reason	
									Creator	
									COC Manager	
									CE approval Date	
									Current user		
									Proto Sign off Date	
									Indent Category	
									Desire Date	
									Creation Date		
									Vehicle Program	
									Indenting Agency	
									Part number	
									Rev	
									Part Description	
									Required Qty/Set	
									Required Set		
									Status	
									Proto Received Date	
									Chief Engineer

									 */
									 
									 
									int k=0;
									char* CO_sysval_1			=	NULL;
									char* CO_t5_SubSyscd_Str_1	=	NULL;
									char* CO_Info2String_1		=	NULL;									
									
									char *IndtPlatform_FromCO			=  	NULL;
									IndtPlatform_FromCO = (char *) MEM_alloc( 100 * sizeof(char) );
									
									tag_t CO_Object_1 = NULLTAG;		
									
									for(k=0;k<nSys_Qryobj_found;k++)
									{
													
										CO_Object_1 = CO_ObjectsSet[k];					
										
										if (CO_Object_1 != NULLTAG)
										{				
											AOM_ask_value_string(CO_Object_1,"t5_Syscd",&CO_sysval_1);						
											AOM_ask_value_string(CO_Object_1,"t5_SubSyscd",&CO_t5_SubSyscd_Str_1);						
											AOM_ask_value_string(CO_Object_1,"t5_Userinfo2",&CO_Info2String_1);				
											
											printf("\n UJJ-PRINT--> [%d] %s %s %s",k,CO_sysval_1,CO_t5_SubSyscd_Str_1,CO_Info2String_1);fflush(stdout);				
										}

										if(tc_strstr(CO_Info2String_1,Indt5PrjCode)!=NULL)
										{
											printf("\n******* UJJ-FOUND Project %s found in Info-2 %s",Indt5PrjCode,CO_Info2String_1);fflush(stdout);
											
											tc_strcpy(IndtPlatform_FromCO,CO_t5_SubSyscd_Str_1);
											
											printf("\n******* UJJ-FOUND Project %s, PLatform-Node: %s",Indt5PrjCode,CO_t5_SubSyscd_Str_1);fflush(stdout);
											
											break;
										}
										
										
									}
									 
									 
									
									fprintf(DmlRelFile,"\n");fflush(DmlRelFile);
									fprintf(DmlRelFile,"%s,",IndRefNo);fflush(DmlRelFile); //Indent Number
									//fprintf(DmlRelFile,"%s,",IndDummyRefNo);fflush(DmlRelFile);//User Reference number	
									fprintf(DmlRelFile,"%s,",IndWFStatus);fflush(DmlRelFile);//Current Status	
									fprintf(DmlRelFile,"%s,",IndCurrDec);fflush(DmlRelFile);//Description	
									fprintf(DmlRelFile,"%s,",Indt5PrjCode);fflush(DmlRelFile);//Project Code
									fprintf(DmlRelFile,"%s,",IndBU);fflush(DmlRelFile);//Project Platform
									//fprintf(DmlRelFile,"%s,",Indt5WBS);fflush(DmlRelFile);//WBS
									//fprintf(DmlRelFile,"%s,",IndPurOfInd);fflush(DmlRelFile);//Reason
									//fprintf(DmlRelFile,"%s,",IndOwnUser);fflush(DmlRelFile);//Creator
									//fprintf(DmlRelFile,"%s,",MgrRevsubtaskRev);fflush(DmlRelFile);//COC Manager	
									//fprintf(DmlRelFile,"'%s,",CERevsubtaskEnDt);fflush(DmlRelFile);//CE approval Date
									//fprintf(DmlRelFile,"%s,",PIRevsubtaskRev);fflush(DmlRelFile);//Current user
									//fprintf(DmlRelFile,"'%s,",PIRevsubtaskEnDt);fflush(DmlRelFile);	
									//fprintf(DmlRelFile,"%s,",NPIRevsubtaskRev);fflush(DmlRelFile);	
									//fprintf(DmlRelFile,"'%s,",NPIRevsubtaskStDt);fflush(DmlRelFile);//Proto Sign off Date
									//fprintf(DmlRelFile,"%s,",IndPrtIndCat);fflush(DmlRelFile);//Indent Category
									//fprintf(DmlRelFile,"'%s,",IndDesDt);fflush(DmlRelFile);//Desire Date
									//fprintf(DmlRelFile,"'%s,",IndcreationDt);fflush(DmlRelFile);
									fprintf(DmlRelFile,"%s,",IndcreationDt);fflush(DmlRelFile);  //Creation Date	Printing in DD-MMM-YYY
									fprintf(DmlRelFile,"%s,",Indt5ERCIndentee);fflush(DmlRelFile);
									//fprintf(DmlRelFile,"%s,",Indt5Indentee);fflush(DmlRelFile);
									
									if (IndtPlatform_FromCO != NULL)
									{
										fprintf(DmlRelFile,"%s,",IndtPlatform_FromCO);fflush(DmlRelFile);//Project Platform
									}
									else
									{
										printf("\n******* UJJ-NOT-FOUND for ProjectCode %s",Indt5PrjCode);fflush(stdout);
											
										fprintf(DmlRelFile,"%s,",IndtPlatform);fflush(DmlRelFile);//Project Platform										
									}
																		
									//fprintf(DmlRelFile,"%s,",IndtPlatform);fflush(DmlRelFile);//Vehicle Program
									fprintf(DmlRelFile,"%s,",Indt5ERIndSec);fflush(DmlRelFile); //Indent Agency
									
									
									//fprintf(DmlRelFile,"'%s,%s,%s,%s,%s,Total Set,",designRevision,designRevisionID,designRevisionDesc1,indDesignQtySet1,indDesignReqQtySet1);fflush(DmlRelFile);
									
									fprintf(DmlRelFile,"'%s,%s,%s",designRevision,designRevisionID,designRevisionDesc1);fflush(DmlRelFile);//fprintf(DmlRelFile,"%s,",PIRevsubtaskState);
									//fprintf(DmlRelFile,"'%s,",PIRevsubtaskStDt);
									//fprintf(DmlRelFile,"%s,",CERevsubtaskRev);
									//fprintf(DmlRelFile,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,",designRevision,designRevisionID,designRevisionDesc1,indDesignQtySet1,indDesignReqQtySet1,indPartIndCategory1,indt5ERIndIRAvl1,indTRSOStatus1,indSupplierName1,indTkoStatus1,indPartStatus1,ind_ERCIndRemarkIndente1,indERCIndRemark1,indRemarkForIndenticalPart1);fflush(DmlRelFile);
									printf("\n ,,,,,,,,,,,,,,,,,,[%s],[%s],[%s],[%s],[%s],[%s],[%s],[%s],[%s],[%s],[%s],[%s],[%s],[%s],",designRevision,designRevisionID,designRevisionDesc1,indDesignQtySet1,indDesignReqQtySet1,indPartIndCategory1,indt5ERIndIRAvl1,indTRSOStatus1,indSupplierName1,indTkoStatus1,indPartStatus1,ind_ERCIndRemarkIndente1,indERCIndRemark1,indRemarkForIndenticalPart1);;fflush(stdout);
									}
								}
								}
							}
							else
							{
								//fprintf(DmlRelFile,"\n ,,,,,,,,,,,,,,,,,,,,,,,,,");fflush(DmlRelFile);
							}
						}
						else
						{
							//fprintf(DmlRelFile,"\n ,,,,,,,,,,,,,,,,,,,,,,,,,");fflush(DmlRelFile);
						}
						
					
				}
			}
		}

		
	}	
	

	
	
	printf("\n tm_FdjDevRep: *********** End Of Main function ************* \n");fflush(stdout);	
	return ITK_ok;
}



