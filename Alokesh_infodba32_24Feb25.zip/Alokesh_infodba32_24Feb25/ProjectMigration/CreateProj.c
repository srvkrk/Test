/****************************************************************************************************
* File           :		CreateProj.c
* Created By     :		Alokesh Ghosh
* Created On     :		15-Feb-2022
* Purpose        :		Creating project class data on TCUA from TCE data dumped in file.
* Modification History :  NA 
******************************************************************************************************/

#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <tc/tc_startup.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>	
#include <tccore/grm.h>
#include <string.h>
#include <tc/folder.h>
#include <pie/pie.h>
#include <tccore/item_msg.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <unistd.h>
#include <fclasses/tc_date.h>
#include <tccore/aom_prop.h>
#include <tccore/project.h>

#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_err 919002
#define ITK_SVR_err (EMH_USER_error_base + 8)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}


 
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
} 

static void handle_ifail( char * file, int line )
/*  Prints out the full error stack.*/
{
    int  i, n_errors;
    const int *severities;
    const int *ifails;
    const char **messages;
    EMH_ask_errors( &n_errors, &severities, &ifails, &messages );
    printf( "ERROR: (%s:%d)\n", file, line);
    for (i = 0; i < n_errors; i++)
    {
        printf( "    %6d: %s\n", ifails[i], messages[i] );
    }
    exit( EXIT_FAILURE );
}
;

int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}
void getNextMinute(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays,Hour,Minute,nHr,nMin;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;

	struct tm *timeptr1;
	char pAccessDate[30];
	char pAccessDate1[30];
	char cMonth[30];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	strHr[20];
	char	strMin[20];

	temp = time(NULL);
	struct tm* timeptr;
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);

	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);


	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	Hour=(timeptr->tm_hour);
	Minute=(timeptr->tm_min);


	printf( "Given date is %d:%d:%d  %d:%d\n", day, month, year ,Hour,Minute);

	ny= year;
	nm= month;
	nd= day;
	nHr=Hour;
	if (Minute==59)
	{
		if (Hour==23)
		{
			nHr=0;
			nMin=0;
			ndays= days( month, year );//calling days function
			if( ++nd > ndays )
			{
			   nd= 1;
			   if ( ++nm > 12 )
			   {
				 nm= 1;
				 ++ny;
				}
			}
		}
		else
		{
			nHr=Hour+1;
			nMin=0;
		}
	}
	else
	{
		nMin=Minute+1;
	}
    printf( "Given date is %d:%d:%d  %d:%d\n", day, month, year ,Hour,Minute);
    printf( "Next days date is %d:%d:%d  %d:%d\n", nd, nm, ny ,nHr,nMin);

	sprintf(strDay,"%d",nd);
	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);
	sprintf(strHr,"%d",nHr);
	sprintf(strMin,"%d",nMin);

	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,strHr);
	tc_strcat(cnextAccessDate,":");
	tc_strcat(cnextAccessDate,strMin);
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}


int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);fflush(stdout);
		  exit(0);
		}

		return iFail;
}

static int	validate_date ( char *date , logical *date_is_valid , date_t *the_dt )
{
    int      retcode    = ITK_ok;     /* Function return code */
    date_t   dt         = NULLDATE;   /* Date structure */
    int      month      = 0;          /* Month */
    int      day        = 0;          /* Day */
    int      year       = 0;          /* Year */
    int      hour       = 0;          /* Hour */ 
    int      minute     = 0;          /* Minutes */
    int      second     = 0;          /* Seconds */

    *date_is_valid = TRUE;

    /* Converts a date_t structure into the format specified  */
//    retcode = DATE_string_to_date ( date , "%d-%b-%Y %H:%M:%S" , &month , &day , &year , &hour , &minute , &second);				// working for " 21-August-2015" / ""
//    retcode = DATE_string_to_date ( date , "%m-%d-%y-%H:%M:%S" , &month , &day , &year , &hour , &minute , &second);				// working for  "07-21-2015-09:05:58"
    retcode = DATE_string_to_date ( date , "%y/%m/%d-%H:%M:%S" , &month , &day , &year , &hour , &minute , &second);
    if ( retcode != ITK_ok )
    {
        *date_is_valid = FALSE;
    }
    else
    {
        dt.month = month;
        dt.day   = day;
        dt.year  = year;
        dt.hour  = hour;
        dt.minute= minute;
        dt.second= second;

        *the_dt = dt;
    }

	printf("  ---return from validate_date....\n");

    return retcode;
}


extern int ITK_user_main( int argc, char **argv )
{
	/*START VARIABLE DECLARATION*/
	char *file1 = NULL;
	//char *Filename = NULL;
	char *DmlNumberDup = NULL;
	char *Parentsequence_id = NULL;
	char *ItemDesc = NULL;
	char *ItemRevDesc = NULL;
	char *PriorLevel = NULL;
	char *ReqDesc = NULL;
	char *reqtype = NULL;
	char *ReqOwneratt = NULL;
	char *Reqatt = NULL;
	char *level=NULL;
	char *inputfile=NULL;

	char *ProjectName			=NULL;
	char *t5ConfigID			=NULL;
	char *ProjectDesc			=NULL;
	char *t5DeptCode			=NULL;
	char *t5ProjectType			=NULL;
	char *t5VehicleClass		=NULL;
	char *t5ProjSubVehClass		=NULL;
	char *t5Gvw					=NULL;
	char *t5Program				=NULL;
	char *t5ProtoUnit			=NULL;
	char *status				=NULL;
	char *t5DsgnOwn				=NULL;
	char *ProjectID				=NULL;
	char *t5CommercialName		=NULL;
	char *Description			=NULL;
	char *t0AcorsProj			=NULL;
	char *t0BussUnitType		=NULL;
	char *t0ProjectClassfication=NULL;
	char *t5ProjWoNo			=NULL;
	char *t5ParentProductLine	=NULL;
	char *t5IndenterRef			=NULL;
	char *t5AdminPrpBy			=NULL;
	char *t5AdminChkBy			=NULL;
	char *t5AdminAppBy			=NULL;
	char *t5ProjTransferTo		=NULL;
	char *t5ProjCrePose			=NULL;
	char *t53DA					=NULL;
	char *t5DMU					=NULL;
	char *t5CFT					=NULL;

	char *t5PrjPJReqNO=NULL;
char *CreationDate=NULL;
char *Status=NULL;
char *t0OrgnID=NULL;
char *t5ProjEngineType=NULL;
char *t5ProjCcCapacity=NULL;
char *t5AdminRemark=NULL;
char *t5ProjFuelType=NULL;
char *t5ProjManFact=NULL;
char *t5ProjEmssnNorms=NULL;
char *t5ProjCylBore=NULL;
char *t5ProjBore=NULL;
char *t5ProjStrokes=NULL;
char *t5ProjSpFeature1=NULL;
char *t5ProjSpAggSys=NULL;
char *t5ProjTorque=NULL;
char *t5ProjSpFeature2=NULL;
char *t5ProjDia=NULL;
char *t5ProjSpFeature3=NULL;
char *t5ProjLoadCap=NULL;
char *t5ProjSpFeature4=NULL;
char *t5ProjSpFeature5=NULL;
char *t5RdProj=NULL;
char *t5RdProjDt=NULL;
char *t5ProjUpdRemark=NULL;
char *t5UpdatedBy=NULL;

	char *item_id_exist			=NULL;

	char *projid=NULL;
	char *projname=NULL;
	char *projdesc=NULL;
	char *inputline=NULL;
	char *user_id=NULL;

	char *PrjReqNo=NULL;

	char *Proj_type_name		=NULL;

	int status1 = 0;         

	char  type_name[TCTYPE_name_size_c+1];
	char  Rev_name[TCTYPE_name_size_c+1];
	char  secondtype_name[TCTYPE_name_size_c+1];

	char* Year = NULL;
    char* Month	= NULL;
    char* Day = NULL;
    char* Hours	= NULL;
    char* Min = NULL;
    char* Sec = NULL;
    char* MicroSec = NULL;
    char* PrtCreDateS = NULL;
    logical date_is_valid = FALSE;
    //date_t creationDate_D;
	PrtCreDateS = ( char * ) MEM_alloc(30);
	t5ProjWoNo  = ( char * ) MEM_alloc(100);
	t5ParentProductLine = ( char * ) MEM_alloc(100);
	t5ProjCrePose  = ( char * ) MEM_alloc(100);
	ProjectDesc  = ( char * ) MEM_alloc(250);
	Description  = ( char * ) MEM_alloc(250);
	int retcode = ITK_ok;

	int ifail;
	int n_items=0;
	int n_attchs=0;
	int cnt=0;
	int TotalCount=0;
	int RevCnt=0;
	int all=0;
	int stat;
															//tag_t a_datasettype;
	char userid[SA_user_size_c+1];
	logical retain=false;

	int i = 0;
	tag_t     *item_tags		    = NULL;
	tag_t     item					= NULLTAG;
	tag_t     *secondary_objects    = NULLTAG;
	tag_t     user_data			    = NULLTAG;
	tag_t     *relist			    = NULLTAG;
	tag_t     *RelationShip		    = NULLTAG;
	tag_t     Rel_type			    = NULLTAG;
	tag_t     reln_type				= NULLTAG;
	tag_t     objType;
	tag_t     primary;
	tag_t     tReqItem			    = NULLTAG;
	tag_t     second;
	tag_t     secondobjType;
	tag_t     RevType;
	tag_t     *user_tag				= NULLTAG;
	tag_t     user_tag1				= NULLTAG;
	tag_t     *projobj				= NULLTAG;
	tag_t	  proj_type				= NULLTAG;
	tag_t	  object_tag			= NULLTAG;
	tag_t	  parent_master			= NULLTAG;

	char
        *qry_entries[2] = {"Name","Type"},
        *qry_values[2]	= {"","T5_Project"};

	char
        *WBSqry_entries[1] = {"Work Order Number"},
        *WBSqry_values[1]	= {""};

	tag_t
        query = NULLTAG,
        *cntr_objects = NULLTAG,
        *wbs_objects = NULLTAG;
	int n_found = 0;
	int wbs_found = 0;

	//tag_t *projobj= NULLTAG;

	GRM_relation_t **  secondary_listl;
	GRM_relation_t **  relsecondary_listl;

	FILE *fp1;
	//if( ITK_init_module("infodba" ,"infodba","dba")!=ITK_ok) ;
    //ITK_CALL(ITK_set_journalling( TRUE ));
    int iFail = 0;
    iFail = ITK_auto_login();
	printf("\n Auto login .......");fflush(stdout);

	inputfile=ITK_ask_cli_argument("-i=");

	fp1=fopen(inputfile,"r");

	if(fp1 != NULL)
	{
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fp1)!=NULL)
		{
			/*for (i = 0; i < strlen(inputline); i++)
			{
				if ( inputline[i] == '\n' || inputline[i] == '\r' )
					inputline[i] = '\0';
			}*/

			tc_strcpy(t5ProjWoNo,"");
			tc_strcpy(t5ParentProductLine,"");
			tc_strcpy(t5ProjCrePose,"");
			tc_strcpy(ProjectDesc, "");
			tc_strcpy(Description, "");

			printf("\nContent is %s \n",inputline);
			ProjectName = tc_strtok(inputline,"~");
			printf("\n\nProjectName %s ",ProjectName); fflush(stdout);
			t5PrjPJReqNO = tc_strtok(NULL,"~");
			printf("\n\nt5PrjPJReqNO %s ",t5PrjPJReqNO); fflush(stdout);
			tc_strcpy(ProjectDesc, tc_strtok(NULL,"~"));
			printf("\n\nProjectDesc %s ",ProjectDesc); fflush(stdout);
			tc_strcpy(Description, tc_strtok(NULL,"~"));
			printf("\n\nDescription %s ",Description); fflush(stdout);
			CreationDate = tc_strtok(NULL,"~");
			printf("\n\nCreationDate %s ",CreationDate); fflush(stdout);
			Status = tc_strtok(NULL,"~");
			printf("\n\nStatus %s ",Status); fflush(stdout);
			t0BussUnitType = tc_strtok(NULL,"~");
			t0OrgnID = tc_strtok(NULL,"~");
			t0ProjectClassfication = tc_strtok(NULL,"~");
			t5ConfigID = tc_strtok(NULL,"~");
			t5ProjectType = tc_strtok(NULL,"~");
			t5VehicleClass = tc_strtok(NULL,"~");
			tc_strcpy(t5ParentProductLine, tc_strtok(NULL,"~"));
			t5DsgnOwn = tc_strtok(NULL,"~");
			t5ProtoUnit = tc_strtok(NULL,"~");
			t5DeptCode = tc_strtok(NULL,"~");
			t0AcorsProj = tc_strtok(NULL,"~");
			t5CommercialName = tc_strtok(NULL,"~");
			t5IndenterRef = tc_strtok(NULL,"~");
			t5ProjEngineType = tc_strtok(NULL,"~");
			tc_strcpy(t5ProjWoNo, tc_strtok(NULL,"~"));
			t5ProjCcCapacity = tc_strtok(NULL,"~");
			t5AdminPrpBy = tc_strtok(NULL,"~");
			t5AdminChkBy = tc_strtok(NULL,"~");
			t5AdminAppBy = tc_strtok(NULL,"~");
			t5AdminRemark = tc_strtok(NULL,"~");
			t5ProjFuelType = tc_strtok(NULL,"~");
			t5ProjManFact = tc_strtok(NULL,"~");
			t5ProjEmssnNorms = tc_strtok(NULL,"~");
			t5ProjCylBore = tc_strtok(NULL,"~");
			t5ProjBore = tc_strtok(NULL,"~");
			t5ProjStrokes = tc_strtok(NULL,"~");
			t5ProjSpFeature1 = tc_strtok(NULL,"~");
			t5ProjSpAggSys = tc_strtok(NULL,"~");
			t5ProjTorque = tc_strtok(NULL,"~");
			t5ProjSpFeature2 = tc_strtok(NULL,"~");
			t5ProjDia = tc_strtok(NULL,"~");
			t5ProjSpFeature3 = tc_strtok(NULL,"~");
			t5ProjLoadCap = tc_strtok(NULL,"~");
			t5ProjSpFeature4 = tc_strtok(NULL,"~");
			t5ProjSpFeature5 = tc_strtok(NULL,"~");
			t5ProjTransferTo = tc_strtok(NULL,"~");
			t53DA = tc_strtok(NULL,"~");
			t5RdProj = tc_strtok(NULL,"~");
			t5RdProjDt = tc_strtok(NULL,"~");
			tc_strcpy(t5ProjCrePose, tc_strtok(NULL,"~"));
			t5ProjUpdRemark = tc_strtok(NULL,"~");
			t5UpdatedBy = tc_strtok(NULL,"~");
			t5ProjSubVehClass = tc_strtok(NULL,"~");
			t5Program = tc_strtok(NULL,"~");
			t5Gvw = tc_strtok(NULL,"~");
			PrjReqNo = tc_strtok(NULL,"~");

			printf("\nAfter tc_strtok"); fflush(stdout);

			if(tc_strcmp(ProjectDesc, "")!=0 && tc_strcmp(Description, "")==0)
			{
				tc_strcpy(Description, ProjectDesc);
			}
			if(tc_strcmp(ProjectDesc, "")==0 && tc_strcmp(Description, "")!=0)
			{
				tc_strcpy(ProjectDesc, Description);
			}

			if(tc_strcmp(ProjectDesc, "")==0)
			{
				tc_strcpy(ProjectDesc, "-");
			}
			if(tc_strcmp(Description, "")==0)
			{
				tc_strcpy(Description, "-");
			}

			if(tc_strcmp(Description,"TDCV")==0 || tc_strcmp(ProjectDesc,"TDCV")==0)
			{
				continue;
			}
			printf("\nAfter Description"); fflush(stdout);

			if(tc_strcmp(t0BussUnitType,"")==0)
			{
				continue;
			}
			printf("\nAfter t0BussUnitType"); fflush(stdout);

			if(t5ParentProductLine != NULL)
			{
				if(tc_strcmp(t5ParentProductLine, "")!=0)
				{
					if(tc_strcmp(t5ParentProductLine,"PlantName1")==0)
					{
						tc_strcpy(t5ParentProductLine, "CAR");
					}
					else if(tc_strcmp(t5ParentProductLine,"PlantName8")==0)
					{
						tc_strcpy(t5ParentProductLine, "CVBU JSR");
					}
					else if(tc_strcmp(t5ParentProductLine,"PlantName9")==0)
					{
						tc_strcpy(t5ParentProductLine, "CVBU LKO");
					}
					else if(tc_strcmp(t5ParentProductLine,"PlantName2")==0)
					{
						tc_strcpy(t5ParentProductLine, "CVBU PNR");
					}
					else if(tc_strcmp(t5ParentProductLine,"PlantName3")==0)
					{
						tc_strcpy(t5ParentProductLine, "CVBU PUNE");
					}
					else if(tc_strcmp(t5ParentProductLine,"PlantName4")==0)
					{
						tc_strcpy(t5ParentProductLine, "PCBU");
					}
					else if(tc_strcmp(t5ParentProductLine,"PlantName5")==0)
					{
						tc_strcpy(t5ParentProductLine, "PCBU and CVBU");
					}
					else if(tc_strcmp(t5ParentProductLine,"PlantName10")==0)
					{
						tc_strcpy(t5ParentProductLine, "PCBU LKO");
					}
					else if(tc_strcmp(t5ParentProductLine,"PlantName6")==0)
					{
						tc_strcpy(t5ParentProductLine, "SMALLCAR AHD");
					}
					else if(tc_strcmp(t5ParentProductLine,"PlantName7")==0)
					{
						tc_strcpy(t5ParentProductLine, "SMALLCAR PNR");
					}
					else if(tc_strcmp(t5ParentProductLine,"PlantName11")==0)
					{
						tc_strcpy(t5ParentProductLine, "DHARWAD");
					}
					else if(tc_strcmp(t5ParentProductLine,"PlantName12")==0)
					{
						tc_strcpy(t5ParentProductLine, "TMLDL JSR");
					}
					else if(tc_strcmp(t5ParentProductLine,"PlantName13")==0)
					{
						tc_strcpy(t5ParentProductLine, "PUVBU");
					}
					else
					{
						tc_strcpy(t5ParentProductLine, "");
					}
				}
			}
			printf("\nAfter t5ParentProductLine"); fflush(stdout);

			if(t5ProjCrePose != NULL)
			{
				if(tc_strcmp(t5ProjCrePose,"Admin")!=0 && tc_strcmp(t5ProjCrePose,"Admin (NON-TML)")!=0 && tc_strcmp(t5ProjCrePose,"NPI")!=0 && tc_strcmp(t5ProjCrePose,"STANDARDIZATION,ERC")!=0)
				{
					tc_strcpy(t5ProjCrePose, "Admin");
				}
			}
			printf("\nAfter t5ProjCrePose"); fflush(stdout);

	        qry_entries[0] = "Name";
			qry_entries[1] = "Type";

			qry_values[0] = ProjectName;
			qry_values[1] = "T5_Project";

			if(t5ProjWoNo != NULL)
			{
				if(tc_strcmp(t5ProjWoNo, "")!=0)
				{
					wbs_found = 0;
			        WBSqry_entries[0] = "Work Order Number";
					WBSqry_values[0] = t5ProjWoNo;
					ITK_CALL(QRY_find2("Work_Order", &query));
					if(query!=NULLTAG)
					{
						ITK_CALL(QRY_execute(query, 1, WBSqry_entries, WBSqry_values, &wbs_found, &wbs_objects));
					}
					if(wbs_found < 1)
					{
						tc_strcpy(t5ProjWoNo,"");
					}
					else
					{
						tag_t wbsDt = NULLTAG;
						char* wbsUPDState = NULL;
						wbsDt = wbs_objects[0];
						ITK_CALL(AOM_ask_value_string(wbsDt,"t5UpToDateStatus",&wbsUPDState));
						if (wbsUPDState != NULL)
						{
							if (tc_strcmp(wbsUPDState,"Y")!=0)
							{
								tc_strcpy(t5ProjWoNo,"");
							}
						}
						else
						{
							tc_strcpy(t5ProjWoNo,"");
						}
					}
				}
			}
			printf("\nAfter t5ProjWoNo"); fflush(stdout);

			ITK_CALL(QRY_find2("General...", &query));
			if(query!=NULLTAG)
			{
				ITK_CALL(QRY_execute(query, 2, qry_entries, qry_values, &n_found, &cntr_objects));
			}
			printf("\n n_found=====>%d", n_found);fflush(stdout);
			
			if(n_found < 1)
			{	
				printf("\nProject Not found going for creation"); fflush(stdout);

				ITK_CALL(TCTYPE_find_type("T5_Project","T5_Project",&proj_type));
				ITK_CALL(TCTYPE_construct_create_input(proj_type, &object_tag));

				ITK_CALL(TCTYPE_ask_name2(proj_type,&Proj_type_name));
				printf("\n\nProject type is %s ",Proj_type_name); fflush(stdout);

				printf("\n\nProjectName %s ",ProjectName); fflush(stdout);
				ITK_CALL(AOM_set_value_string(object_tag,"item_id",ProjectName));
				printf("\n\nProjectName %s ",ProjectName); fflush(stdout);
				ITK_CALL(AOM_set_value_string(object_tag,"object_name",ProjectName));
				printf("\n\nProject Description %s ",ProjectDesc); fflush(stdout);

				if(PrjReqNo != NULL && tc_strcmp(PrjReqNo, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_PrjPJReqNO",PrjReqNo));
				}
				else{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_PrjPJReqNO","Migrated from TCE"));
				}

				//if(Description != NULL && tc_strcmp(Description, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"current_desc",Description));

				if(ProjectDesc != NULL && tc_strcmp(ProjectDesc, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"object_desc",ProjectDesc));
				printf("\n\nStatus %s ",Status); fflush(stdout);
				if(Status != NULL && tc_strcmp(Status, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_Status",Status));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_Status","Initiated"));
				}
				printf("\n\nt0BussUnitType %s ",t0BussUnitType); fflush(stdout);
				if(t0BussUnitType != NULL && tc_strcmp(t0BussUnitType, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_BussUnitType",t0BussUnitType));
				printf("\n\nt0OrgnID %s ",t0OrgnID); fflush(stdout);
				if(t0OrgnID != NULL && tc_strcmp(t0OrgnID, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjOrgnId",t0OrgnID));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjOrgnId","TML"));
				}
				printf("\n\nt0ProjectClassfication %s ",t0ProjectClassfication); fflush(stdout);
				if(t0ProjectClassfication != NULL && tc_strcmp(t0ProjectClassfication, "")!=0)
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjectClassfication",t0ProjectClassfication));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjectClassfication","NewGen"));
				}
				printf("\n\nt5ConfigID %s ",t5ConfigID); fflush(stdout);
				if(t5ConfigID != NULL && tc_strcmp(t5ConfigID, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_ConfigID",t5ConfigID));
				printf("\n\nt5ProjectType %s ",t5ProjectType); fflush(stdout);
				if(t5ProjectType != NULL && tc_strcmp(t5ProjectType, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjectType",t5ProjectType));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjectType","V"));
				}
				printf("\n\nt5VehicleClass %s ",t5VehicleClass); fflush(stdout);
				if(t5VehicleClass != NULL && tc_strcmp(t5VehicleClass, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_VehicleClass",t5VehicleClass));
				printf("\n\nt5ParentProductLine %s ",t5ParentProductLine); fflush(stdout);
				if(t5ParentProductLine != NULL && tc_strcmp(t5ParentProductLine, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_ParentProductLine",t5ParentProductLine));
				printf("\n\nt5DsgnOwn %s ",t5DsgnOwn); fflush(stdout);
				if(t5DsgnOwn != NULL && tc_strcmp(t5DsgnOwn, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_DsgnOwn",t5DsgnOwn));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_DsgnOwn","TELPUN"));
				}
				printf("\n\nt5ProtoUnit %s ",t5ProtoUnit); fflush(stdout);
				if(t5ProtoUnit != NULL && tc_strcmp(t5ProtoUnit, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProtoUnit",t5ProtoUnit));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProtoUnit","PROTOPUN"));
				}
				printf("\n\nt5DeptCode %s ",t5DeptCode); fflush(stdout);
				if(t5DeptCode != NULL && tc_strcmp(t5DeptCode, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_DeptCode",t5DeptCode));
				}
				else{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_DeptCode","01"));
				}
				printf("\n\nt0AcorsProj %s ",t0AcorsProj); fflush(stdout);
				if(t0AcorsProj != NULL && tc_strcmp(t0AcorsProj, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_AcrosProj",t0AcorsProj));
				printf("\n\nt5CommercialName %s ",t5CommercialName); fflush(stdout);
				if(t5CommercialName != NULL && tc_strcmp(t5CommercialName, "")!=0)
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_CommercialName",t5CommercialName));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_CommercialName","-"));
				}
				printf("\n\nt5IndenterRef %s ",t5IndenterRef); fflush(stdout);
				if(t5IndenterRef != NULL && tc_strcmp(t5IndenterRef, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_IndenterRef",t5IndenterRef));
				printf("\n\nt5ProjWoNo %s ",t5ProjWoNo); fflush(stdout);
				if(t5ProjWoNo != NULL && tc_strcmp(t5ProjWoNo, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjWoNo",t5ProjWoNo));
				printf("\n\nt5AdminPrpBy %s ",t5AdminPrpBy); fflush(stdout);
				if(t5AdminPrpBy != NULL && tc_strcmp(t5AdminPrpBy, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_AdminPrpBy",t5AdminPrpBy));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_AdminPrpBy","Migrated from TCE"));
				}
				printf("\n\nt5AdminChkBy %s ",t5AdminChkBy); fflush(stdout);
				if(t5AdminChkBy != NULL && tc_strcmp(t5AdminChkBy, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_AdminChkBy",t5AdminChkBy));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_AdminChkBy","Migrated from TCE"));
				}
				printf("\n\nt5AdminAppBy %s ",t5AdminAppBy); fflush(stdout);
				if(t5AdminAppBy != NULL && tc_strcmp(t5AdminAppBy, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_AdminAppBy",t5AdminAppBy));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_AdminAppBy","Migrated from TCE"));
				}
				printf("\n\nt5AdminRemark %s ",t5AdminRemark); fflush(stdout);
				if(t5AdminRemark != NULL && tc_strcmp(t5AdminRemark, "")!=0)
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_AdminRemark",t5AdminRemark));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_AdminRemark","Migrated from TCE"));
				}
				printf("\n\nt5ProjTransferTo %s ",t5ProjTransferTo); fflush(stdout);
				if(t5ProjTransferTo != NULL && tc_strcmp(t5ProjTransferTo, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjTransferTo",t5ProjTransferTo));
				printf("\n\nt53DA %s ",t53DA); fflush(stdout);
				if(t53DA != NULL && tc_strcmp(t53DA, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_3DA",t53DA));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_3DA","NA"));
				}
				printf("\n\nt5ProjCrePose %s ",t5ProjCrePose); fflush(stdout);
				if(t5ProjCrePose != NULL && tc_strcmp(t5ProjCrePose, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjCrePose",t5ProjCrePose));
				printf("\n\nt5ProjSubVehClass %s ",t5ProjSubVehClass); fflush(stdout);
				if(t5ProjSubVehClass != NULL && tc_strcmp(t5ProjSubVehClass, "")!=0)
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjSubVehClass",t5ProjSubVehClass));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjSubVehClass","NA"));
				}
				printf("\n\nt5Program %s ",t5Program); fflush(stdout);
				if(t5Program != NULL && tc_strcmp(t5Program, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_Program",t5Program));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_Program","NA"));
				}
				printf("\n\nt5Gvw %s ",t5Gvw); fflush(stdout);
				if(t5Gvw != NULL && tc_strcmp(t5Gvw, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_Gvw",t5Gvw));

				ITK_CALL(AOM_set_value_string(object_tag,"t5_CFT","NA"));
				ITK_CALL(AOM_set_value_string(object_tag,"t5_DMU","NA"));
				printf("\n\nt5_ProjectID %s ",ProjectName); fflush(stdout);
				ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjectID",ProjectName));
				printf("\n\nt5_ProjectDesc %s ",Description); fflush(stdout);
				if(Description != NULL) ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjectDesc",Description));
				printf("\n\nt5_ProjectName %s ",ProjectName); fflush(stdout);
				ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjectName",ProjectName));
				printf("\n\n\n"); fflush(stdout);
				ITK_CALL(AOM_set_value_string(object_tag,"t5_Description","Migrated from TCE"));

				if(TCTYPE_create_object(object_tag,&parent_master)!=ITK_ok) PrintErrorStack();
				if(AOM_save_without_extensions(parent_master)!=ITK_ok) PrintErrorStack();
				printf("\nGoing for Creation Date Update"); fflush(stdout);
				if(parent_master !=NULLTAG)
				{
					Year = NULL;
				    Month	= NULL;
				    Day = NULL;
				    Hours	= NULL;
				    Min = NULL;
				    Sec = NULL;
				    MicroSec = NULL;
				    date_is_valid = FALSE;
				    date_t creationDate_D;
					retcode = ITK_ok;

					Year=tc_strtok(CreationDate,"/");
					Month=tc_strtok(NULL,"/");
					Day=tc_strtok(NULL,"-");
					Hours=tc_strtok(NULL,":");
					Min=tc_strtok(NULL,":");
					Sec=tc_strtok(NULL,":");
					MicroSec=tc_strtok(NULL,":");
					tc_strcpy(PrtCreDateS,"");
					tc_strcpy(PrtCreDateS,Year);
					tc_strcat(PrtCreDateS,"/");
					tc_strcat(PrtCreDateS,Month);
					tc_strcat(PrtCreDateS,"/");
					tc_strcat(PrtCreDateS,Day);
					tc_strcat(PrtCreDateS,"-");
					tc_strcat(PrtCreDateS,Hours);
					tc_strcat(PrtCreDateS,":");
					tc_strcat(PrtCreDateS,Min);
					tc_strcat(PrtCreDateS,":");
					tc_strcat(PrtCreDateS,Sec);
					printf("New Creation Date is --> [%s]",PrtCreDateS); fflush(stdout);

					if(AOM_lock(parent_master)!=ITK_ok) PrintErrorStack();
					retcode = validate_date( PrtCreDateS , &date_is_valid , &creationDate_D );
					if ( retcode == ITK_ok )
					{
						if ( POM_set_creation_date(parent_master, creationDate_D)!=ITK_ok) PrintErrorStack();
					}
					if(AOM_save_without_extensions(parent_master)!=ITK_ok) PrintErrorStack();
					if(AOM_refresh(parent_master,1)!=ITK_ok) PrintErrorStack();
					if(AOM_unlock(parent_master)!=ITK_ok) PrintErrorStack();
				}
			}
			else
			{
				printf("\nProject found going for update"); fflush(stdout);

				object_tag = NULLTAG;
				object_tag = cntr_objects[0];

				ITK_CALL(AOM_lock(object_tag));
				if(PrjReqNo != NULL && tc_strcmp(PrjReqNo, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_PrjPJReqNO",PrjReqNo));
				}
				else{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_PrjPJReqNO","Migrated from TCE"));
				}

				//if(Description != NULL && tc_strcmp(Description, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"current_desc",Description));

				if(ProjectDesc != NULL && tc_strcmp(ProjectDesc, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"object_desc",ProjectDesc));
				printf("\n\nStatus %s ",Status); fflush(stdout);
				if(Status != NULL && tc_strcmp(Status, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_Status",Status));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_Status","Initiated"));
				}
				printf("\n\nt0BussUnitType %s ",t0BussUnitType); fflush(stdout);
				if(t0BussUnitType != NULL && tc_strcmp(t0BussUnitType, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_BussUnitType",t0BussUnitType));
				printf("\n\nt0OrgnID %s ",t0OrgnID); fflush(stdout);
				if(t0OrgnID != NULL && tc_strcmp(t0OrgnID, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjOrgnId",t0OrgnID));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjOrgnId","TML"));
				}
				printf("\n\nt0ProjectClassfication %s ",t0ProjectClassfication); fflush(stdout);
				if(t0ProjectClassfication != NULL && tc_strcmp(t0ProjectClassfication, "")!=0)
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjectClassfication",t0ProjectClassfication));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjectClassfication","NewGen"));
				}
				printf("\n\nt5ConfigID %s ",t5ConfigID); fflush(stdout);
				if(t5ConfigID != NULL && tc_strcmp(t5ConfigID, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_ConfigID",t5ConfigID));
				printf("\n\nt5ProjectType %s ",t5ProjectType); fflush(stdout);
				if(t5ProjectType != NULL && tc_strcmp(t5ProjectType, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjectType",t5ProjectType));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjectType","V"));
				}
				printf("\n\nt5VehicleClass %s ",t5VehicleClass); fflush(stdout);
				if(t5VehicleClass != NULL && tc_strcmp(t5VehicleClass, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_VehicleClass",t5VehicleClass));
				printf("\n\nt5ParentProductLine %s ",t5ParentProductLine); fflush(stdout);
				if(t5ParentProductLine != NULL && tc_strcmp(t5ParentProductLine, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_ParentProductLine",t5ParentProductLine));
				printf("\n\nt5DsgnOwn %s ",t5DsgnOwn); fflush(stdout);
				if(t5DsgnOwn != NULL && tc_strcmp(t5DsgnOwn, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_DsgnOwn",t5DsgnOwn));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_DsgnOwn","TELPUN"));
				}
				printf("\n\nt5ProtoUnit %s ",t5ProtoUnit); fflush(stdout);
				if(t5ProtoUnit != NULL && tc_strcmp(t5ProtoUnit, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProtoUnit",t5ProtoUnit));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProtoUnit","PROTOPUN"));
				}
				printf("\n\nt5DeptCode %s ",t5DeptCode); fflush(stdout);
				if(t5DeptCode != NULL && tc_strcmp(t5DeptCode, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_DeptCode",t5DeptCode));
				}
				else{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_DeptCode","01"));
				}
				printf("\n\nt0AcorsProj %s ",t0AcorsProj); fflush(stdout);
				if(t0AcorsProj != NULL && tc_strcmp(t0AcorsProj, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_AcrosProj",t0AcorsProj));
				printf("\n\nt5CommercialName %s ",t5CommercialName); fflush(stdout);
				if(t5CommercialName != NULL && tc_strcmp(t5CommercialName, "")!=0)
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_CommercialName",t5CommercialName));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_CommercialName","-"));
				}
				printf("\n\nt5IndenterRef %s ",t5IndenterRef); fflush(stdout);
				if(t5IndenterRef != NULL && tc_strcmp(t5IndenterRef, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_IndenterRef",t5IndenterRef));
				printf("\n\nt5ProjWoNo %s ",t5ProjWoNo); fflush(stdout);
				if(t5ProjWoNo != NULL && tc_strcmp(t5ProjWoNo, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjWoNo",t5ProjWoNo));
				printf("\nAfter WBS No\n"); fflush(stdout);
				printf("\n\nt5AdminPrpBy %s ",t5AdminPrpBy); fflush(stdout);
				if(t5AdminPrpBy != NULL && tc_strcmp(t5AdminPrpBy, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_AdminPrpBy",t5AdminPrpBy));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_AdminPrpBy","Migrated from TCE"));
				}
				printf("\n\nt5AdminChkBy %s ",t5AdminChkBy); fflush(stdout);
				if(t5AdminChkBy != NULL && tc_strcmp(t5AdminChkBy, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_AdminChkBy",t5AdminChkBy));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_AdminChkBy","Migrated from TCE"));
				}
				printf("\n\nt5AdminAppBy %s ",t5AdminAppBy); fflush(stdout);
				if(t5AdminAppBy != NULL && tc_strcmp(t5AdminAppBy, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_AdminAppBy",t5AdminAppBy));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_AdminAppBy","Migrated from TCE"));
				}
				printf("\n\nt5AdminRemark %s ",t5AdminRemark); fflush(stdout);
				if(t5AdminRemark != NULL && tc_strcmp(t5AdminRemark, "")!=0)
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_AdminRemark",t5AdminRemark));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_AdminRemark","Migrated from TCE"));
				}
				printf("\n\nt5ProjTransferTo %s ",t5ProjTransferTo); fflush(stdout);
				if(t5ProjTransferTo != NULL && tc_strcmp(t5ProjTransferTo, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjTransferTo",t5ProjTransferTo));
				printf("\n\nt53DA %s ",t53DA); fflush(stdout);
				if(t53DA != NULL && tc_strcmp(t53DA, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_3DA",t53DA));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_3DA","NA"));
				}
				printf("\n\nt5ProjCrePose %s ",t5ProjCrePose); fflush(stdout);
				if(t5ProjCrePose != NULL && tc_strcmp(t5ProjCrePose, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjCrePose",t5ProjCrePose));
				printf("\n\nt5ProjSubVehClass %s ",t5ProjSubVehClass); fflush(stdout);
				if(t5ProjSubVehClass != NULL && tc_strcmp(t5ProjSubVehClass, "")!=0)
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjSubVehClass",t5ProjSubVehClass));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjSubVehClass","NA"));
				}
				printf("\n\nt5Program %s ",t5Program); fflush(stdout);
				if(t5Program != NULL && tc_strcmp(t5Program, "")!=0){
					ITK_CALL(AOM_set_value_string(object_tag,"t5_Program",t5Program));
				}
				else
				{
					ITK_CALL(AOM_set_value_string(object_tag,"t5_Program","NA"));
				}
				printf("\n\nt5Gvw %s ",t5Gvw); fflush(stdout);
				if(t5Gvw != NULL && tc_strcmp(t5Gvw, "")!=0) ITK_CALL(AOM_set_value_string(object_tag,"t5_Gvw",t5Gvw));

				ITK_CALL(AOM_set_value_string(object_tag,"t5_CFT","NA"));
				ITK_CALL(AOM_set_value_string(object_tag,"t5_DMU","NA"));
				printf("\n\nt5_ProjectID %s ",ProjectName); fflush(stdout);
				ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjectID",ProjectName));
				printf("\n\nt5_ProjectDesc %s ",Description); fflush(stdout);
				if(Description != NULL) ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjectDesc",Description));
				printf("\n\nt5_ProjectName %s ",ProjectName); fflush(stdout);
				ITK_CALL(AOM_set_value_string(object_tag,"t5_ProjectName",ProjectName));
				printf("\n\n\n"); fflush(stdout);
				ITK_CALL(AOM_set_value_string(object_tag,"t5_Description","Migrated from TCE"));

				ITK_CALL(AOM_save_without_extensions(object_tag));
				ITK_CALL(AOM_unlock(object_tag));

				int no_revs = 0, x=0;
				tag_t* tags_revs = NULLTAG;
				ITK_CALL(ITEM_list_all_revs(object_tag,&no_revs,&tags_revs));
				printf("\nNo of Project Revisions found: %d",no_revs);
				if (no_revs > 0)
				{
					for (x = 0; x < no_revs; ++x)
					{
						tag_t projRevTag = NULLTAG;
						projRevTag = tags_revs[x];
						ITK_CALL(AOM_lock(projRevTag));
						if(ProjectDesc != NULL && tc_strcmp(ProjectDesc, "")!=0) ITK_CALL(AOM_set_value_string(projRevTag,"object_desc",ProjectDesc));
						ITK_CALL(AOM_save_without_extensions(projRevTag));
						ITK_CALL(AOM_unlock(projRevTag));
					}
				} 
			}

			tag_t projobj= NULLTAG;
			tag_t     tReqItem			    = NULLTAG;
			if(PROJ_find(ProjectName,&projobj)!=ITK_ok) PrintErrorStack();

			if(projobj == NULLTAG)
			{
				if(PROJ_create_project(ProjectName,ProjectName,ProjectDesc,&tReqItem)!=ITK_ok) 
				{
					printf("\nError Cretion of Project CODE:%s",ProjectName);
					PrintErrorStack();
				}
				else
				{
					printf("\nProject %s initiatied",ProjectName);
					if((AOM_refresh (tReqItem,1))!=ITK_ok) PrintErrorStack();
					if((AOM_save_with_extensions(tReqItem))!=ITK_ok) PrintErrorStack();
					if((AOM_unlock(tReqItem))!=ITK_ok) PrintErrorStack();
					printf("\nProject %s is successfully Created",ProjectName);

					/*strcpy (userid, "loader");
					if((SA_find_user(userid,&user_tag1))!=ITK_ok) PrintErrorStack();
					if((PROJ_add_members(tReqItem,1,&user_tag1))!=ITK_ok) PrintErrorStack();
					printf("\nloader : Member Added");

					logical logical_check = FALSE;
					if((PROJ_is_user_a_privileged_member(tReqItem,user_tag1,&logical_check)) !=ITK_ok) PrintErrorStack();
					if (!logical_check)
					{
						if((PROJ_add_author_members(tReqItem,1,&user_tag1))!=ITK_ok) PrintErrorStack();
						printf("\nloader : Author Added");
						if((AOM_refresh (tReqItem,1))!=ITK_ok) PrintErrorStack();
						if((AOM_save_with_extensions(tReqItem))!=ITK_ok) PrintErrorStack();
						if((AOM_unlock(tReqItem))!=ITK_ok) PrintErrorStack();
					}*/


					tag_t group_tag = NULLTAG;
					tag_t role_tag = NULLTAG;
					tag_t member_tag = NULLTAG;
					int num_of_roles = 0;
					tag_t* role_tags = NULLTAG;
					tag_t* member_tags = NULLTAG;
					int iR = 0;
					int jG = 0;
					char* rolename = NULL;
					char* usr_name = NULL;
					int num_of_members = 0;
					int found = 0;

					logical logical_check = FALSE;
					printf("\n OOTB Project doesnot exists  .......",ProjectName);fflush(stdout);
					if(SA_find_group("dba",&group_tag)!=ITK_ok) PrintErrorStack();
					if (group_tag != NULLTAG)
					{
						if(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags)!=ITK_ok) PrintErrorStack();
						if(num_of_roles>0)
						{
							found = 0;
							for (iR=0;iR<num_of_roles;iR++)
							{
								role_tag = role_tags[i];
								if(SA_ask_role_name2(role_tag,&rolename)!=ITK_ok) PrintErrorStack();
								if (tc_strcasecmp(rolename,"dba")==0)
								{
									if(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags)!=ITK_ok) PrintErrorStack();
									if(num_of_members>0)
									{
										for (jG=0;jG<num_of_members ;jG++)
										{
											member_tag = member_tags[jG];
											if(SA_ask_groupmember_user(member_tag,&user_tag1)!=ITK_ok) PrintErrorStack();
											if(AOM_UIF_ask_value(user_tag1,"object_string",&usr_name)!=ITK_ok) PrintErrorStack();
											if (tc_strstr(usr_name,"loader")!=NULL  && tc_strstr(usr_name,"aplloader")==NULL)
											{
												if((PROJ_add_members(tReqItem,1,&member_tag))!=ITK_ok) PrintErrorStack();
												printf("\nloader : Member Added %s", usr_name);

												logical logical_check = FALSE;
												if((PROJ_is_user_a_privileged_member(tReqItem,user_tag1,&logical_check)) !=ITK_ok) PrintErrorStack();
												if (!logical_check)
												{
													if((PROJ_add_author_members(tReqItem,1,&user_tag1))!=ITK_ok) PrintErrorStack();
													printf("\nloader : Author Added");
													if((AOM_refresh (tReqItem,1))!=ITK_ok) PrintErrorStack();
													if((AOM_save_with_extensions(tReqItem))!=ITK_ok) PrintErrorStack();
													if((AOM_unlock(tReqItem))!=ITK_ok) PrintErrorStack();
												}
												found++;
												break;
											}
										}
									}
								}
								if (found > 0) break;
							}
						}
					}

					strcpy (userid, "infodba");
					if((SA_find_user2(userid,&user_tag1))!=ITK_ok) PrintErrorStack();
					if((PROJ_add_members(tReqItem,1,&user_tag1))!=ITK_ok) PrintErrorStack();
					printf("\ninfodba : Member Added");

					logical_check = FALSE;
					if((PROJ_is_user_a_privileged_member(tReqItem,user_tag1,&logical_check)) !=ITK_ok) PrintErrorStack();
					if (!logical_check)
					{
						if((PROJ_add_author_members(tReqItem,1,&user_tag1))!=ITK_ok) PrintErrorStack();
						printf("\ninfodba : Author added");
						if((AOM_refresh (tReqItem,1))!=ITK_ok) PrintErrorStack();
						if((AOM_save_with_extensions(tReqItem))!=ITK_ok) PrintErrorStack();
						if((AOM_unlock(tReqItem))!=ITK_ok) PrintErrorStack();
					}

					/*if((PROJ_is_user_a_member(tReqItem,user_tag1,&retain))!=ITK_ok) PrintErrorStack();
					printf("\nuser id is \n%d",retain);fflush(stdout);
					if((PROJ_add_author_members(tReqItem,1,&user_tag1))!=ITK_ok) PrintErrorStack();
					if((PROJ_assign_team(projobj,1,&user_tag1,&user_tag1,1,&user_tag1))!=ITK_ok) PrintErrorStack();
					if( (PROJ_assign_objects(1 ,&projobj ,1 ,rev ))!=ITK_ok) PrintErrorStack();
					printf("\nAssigned to Project\n");fflush(stdout);*/
					
					if((AOM_refresh (tReqItem,1))!=ITK_ok) PrintErrorStack();
					if((AOM_save_with_extensions(tReqItem))!=ITK_ok) PrintErrorStack();
					if((AOM_unlock(tReqItem))!=ITK_ok) PrintErrorStack();
					printf("\nUnlocked");
				}
			}
			else
			{
				tag_t group_tag = NULLTAG;
				tag_t role_tag = NULLTAG;
				tag_t member_tag = NULLTAG;
				int num_of_roles = 0;
				tag_t* role_tags = NULLTAG;
				tag_t* member_tags = NULLTAG;
				int iR = 0;
				int jG = 0;
				char* rolename = NULL;
				char* usr_name = NULL;
				int num_of_members = 0;
				int found = 0;

				logical logical_check = FALSE;
				printf("\n OOTB Project %s already exists  .......",ProjectName);fflush(stdout);
				tReqItem = projobj;
				tc_strcpy (userid, "loader");
				if(SA_find_group("dba",&group_tag)!=ITK_ok) PrintErrorStack();
				if (group_tag != NULLTAG)
				{
					if(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags)!=ITK_ok) PrintErrorStack();
					if(num_of_roles>0)
					{
						found = 0;
						for (iR=0;iR<num_of_roles;iR++)
						{
							role_tag = role_tags[i];
							if(SA_ask_role_name2(role_tag,&rolename)!=ITK_ok) PrintErrorStack();
							if (tc_strcasecmp(rolename,"dba")==0)
							{
								if(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags)!=ITK_ok) PrintErrorStack();
								if(num_of_members>0)
								{
									for (jG=0;jG<num_of_members ;jG++)
									{
										member_tag = member_tags[jG];
										if(SA_ask_groupmember_user(member_tag,&user_tag1)!=ITK_ok) PrintErrorStack();
										if(AOM_UIF_ask_value(user_tag1,"object_string",&usr_name)!=ITK_ok) PrintErrorStack();
										if (tc_strstr(usr_name,"loader")!=NULL && tc_strstr(usr_name,"aplloader")==NULL)
										{
											printf("\n-------User: %s",usr_name); fflush(stdout);
											if((PROJ_is_user_a_member(tReqItem,user_tag1,&logical_check)) !=ITK_ok) PrintErrorStack();
											if (!logical_check)
											{
												if((PROJ_add_members(tReqItem,1,&member_tag))!=ITK_ok) PrintErrorStack();
												printf("\nMember added");
												if((AOM_refresh (tReqItem,1))!=ITK_ok) PrintErrorStack();
												if((AOM_save_with_extensions(tReqItem))!=ITK_ok) PrintErrorStack();
												if((AOM_unlock(tReqItem))!=ITK_ok) PrintErrorStack();
												printf("\nUnlocked");
											}
											else
											{
												printf("\nAlready a Member"); fflush(stdout);
											}

											logical_check = FALSE;
											if((PROJ_is_user_a_privileged_member(tReqItem,user_tag1,&logical_check)) !=ITK_ok) PrintErrorStack();
											if (!logical_check)
											{
												if((PROJ_add_author_members(tReqItem,1,&user_tag1))!=ITK_ok) PrintErrorStack();
												printf("\nAuthor added");
												if((AOM_refresh (tReqItem,1))!=ITK_ok) PrintErrorStack();
												if((AOM_save_with_extensions(tReqItem))!=ITK_ok) PrintErrorStack();
												if((AOM_unlock(tReqItem))!=ITK_ok) PrintErrorStack();
												printf("\nUnlocked");
											}
											else
											{
												printf("\n Already a Author"); fflush(stdout);
											}
											found++;
											break;
										}
									}
								}
							}
							if (found > 0) break;
						}
					}
				}
				//if((SA_find_user(userid,&user_tag1))!=ITK_ok) PrintErrorStack();
			}

			tc_strcpy(inputline,"");
		}
		MEM_free(inputline);
	}
                fclose (fp1);
				return ITK_ok;
}

