#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tccore/aom.h>
#include <ctype.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <math.h>
#define ITK_err 910001
int ifail = 0;
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
int ITK_CALL(int ifail)
{
	char* cError = NULL;
    if(ifail!=ITK_ok)
	{
	  EMH_ask_error_text(ifail, &cError);
	  printf("\n Error is : %s", cError);fflush(stdout);
	  exit(0);
	}
	return ifail;
}

int ITK_user_main(int argc, char* argv[])
{
    char* cError = NULL;
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		EMH_ask_error_text(ifail, &cError);
		printf("\nError is : %s", cError);fflush(stdout);
		exit(0);
	}

	FILE *fp;
	char* inputfile = NULL;
	char *inputline = NULL;
	inputfile = ITK_ask_cli_argument("-i=");
	if ( !inputfile )
    {
        printf("Must supply the \"-i\" option on command line to ITK executable....\n"); fflush(stdout);
        exit(0);
    }
	fp=fopen(inputfile,"r");
	if(fp!=NULL)
	{
		char *cEntries[2]  = {"Item ID","Revision"};
		char *qry_entries_d[2] = {"Name","Type"};
		char **cValues = (char **) MEM_alloc(2 * sizeof(char *));
		char **qry_values_d = (char **) MEM_alloc(2 * sizeof(char *));
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fp)!=NULL)
		{
			printf("\n Line: %s",inputline); fflush(stdout);
			char* partnumber = NULL;
			char* partrevseq = NULL;
			char* jtDataSetName = NULL;
			char* jtDataSetActNm = NULL;
			char* jtDataSetPath = NULL;
			partnumber = tc_strtok(inputline,",");
			partrevseq = tc_strtok(NULL,",");
			jtDataSetName = tc_strtok(NULL,",");
			jtDataSetActNm = tc_strtok(NULL,",");
			jtDataSetPath = tc_strtok(NULL,",");
			
			tag_t tItemobj = NULLTAG;
			int n_found = 0;
			int renderCnt = 0;
			int i =0 ;
			tag_t* itemobj_results = NULLTAG;
			tag_t* renderTags = NULLTAG;
			tag_t ParentTag = NULLTAG;
			tag_t relation_type = NULLTAG;
			tag_t relation = NULLTAG;
			tag_t objTypTag = NULLTAG;
			char* ObjTypeName = NULLTAG;
			printf("ParentPartNo-----------> :%s/%s-\n",partnumber,partrevseq);fflush(stdout);						
			cValues[0] = partnumber;
			cValues[1] = partrevseq;	
			ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
			ITK_CALL(QRY_execute(tItemobj, 2, cEntries, cValues, &n_found, &itemobj_results));
			if(n_found>0)
			{
				int JTPresent = 0;
				ParentTag = itemobj_results[0];
				ifail = GRM_find_relation_type("IMAN_Rendering",&relation_type);
				ifail = GRM_list_secondary_objects_only(ParentTag,relation_type,&renderCnt,&renderTags);
				if (renderCnt > 0)
				{
					for (i = 0; i < renderCnt; ++i)
					{
						ifail = TCTYPE_ask_object_type(renderTags[i],&objTypTag);
						ifail = TCTYPE_ask_name2(objTypTag,&ObjTypeName);
						printf("\t type => [%s] ",ObjTypeName); fflush(stdout);
						if (tc_strcmp(ObjTypeName,"DirectModel")==0)
						{
							JTPresent ++;
							break;
						}
					}
				}
				if (JTPresent == 0)
				{
					tag_t AlfDataSet_tag = NULLTAG;
					tag_t datasettype =NULLTAG;
					tag_t tool =NULLTAG;
					int nameRef_cnt =0;
					tag_t *namRefObject = NULL;
					int ref_count = 0;
					char **ref_list;
					tag_t filetag =  NULLTAG;
					IMF_file_t fileDescriptor;
					AE_reference_type_t tagRefType =  1;
					
					ifail = AE_find_datasettype2("DirectModel", &datasettype);
					printf("\n\t DirectModel Type found---->%d",ifail);fflush(stdout);
					printf("\n\t Creating New Dataset..."); fflush(stdout);
					ifail = AE_create_dataset_with_id(datasettype,jtDataSetName,jtDataSetName, NULL, NULL, &AlfDataSet_tag);
					printf("\n\t Dataset created for prt --->%s \n\t",jtDataSetName); fflush(stdout);
					ifail = AE_set_dataset_format2(AlfDataSet_tag, "BINARY_REF");
					ifail = AE_set_dataset_tool(AlfDataSet_tag,tool);
					ifail = AE_ask_dataset_named_refs(AlfDataSet_tag,&nameRef_cnt, &namRefObject);
					if (nameRef_cnt == 0)
					{
						ifail = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
						ifail = IMF_import_file(jtDataSetPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
						if (ifail == 41178)
						{
							ifail = IMF_import_file(jtDataSetPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
						}
						printf("\n\t File Imported--->%d",ifail); fflush(stdout);
						ifail = AOM_save_with_extensions(filetag);
						if (IMF_set_original_file_name2(filetag,jtDataSetActNm)!=ITK_ok);
						ifail = AOM_save_with_extensions(filetag);
						printf("\n\t File saved--->%d",ifail); fflush(stdout);
						ifail = AE_add_dataset_named_ref2(AlfDataSet_tag,ref_list[0],tagRefType,filetag);
						printf("\n\t AE_add_dataset_named_ref--->%d",ifail); fflush(stdout);
						AE_set_dataset_tool(AlfDataSet_tag,tool);
						ifail = AOM_save_with_extensions(AlfDataSet_tag);
						printf("\n\t AOM_save Dataset--->%d",ifail); fflush(stdout);
					}

					if (AlfDataSet_tag == NULLTAG)
					{
						printf("\nJT Dataset can't create / not found"); fflush(stdout);
						continue;
					}
					else
					{
						ifail = GRM_create_relation(ParentTag, AlfDataSet_tag, relation_type, NULLTAG, &relation);
						ifail = GRM_save_relation(relation);
						printf("\n\t Relation Created with Item Revision ---->%d\n\n",ifail); fflush(stdout);
					}
				}
				else
				{
					printf("\n\t JT Alresy Present with This Part\n\n"); fflush(stdout);
				}
			}
		}
	}

	ifail = ITK_exit_module(TRUE);
	printf("\nReturn Value is : %d", ifail);
	if (ifail == ITK_ok)
	{
		printf("\nTeamcenter Logout Success...");fflush(stdout);
	}
	else
	{
		EMH_ask_error_text(ifail, &cError);
		printf("\nError is : %s", cError);fflush(stdout);
	}
	return ITK_ok;
}
