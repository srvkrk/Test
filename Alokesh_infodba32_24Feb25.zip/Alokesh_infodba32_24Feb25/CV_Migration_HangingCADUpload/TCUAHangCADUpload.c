/* Copyright (c) 2021 Tata Technologies Limited (TTL). All Rights
 *Reserved.
 *
 *This software is the confidential and proprietary information of TTL.
 *You shall not disclose such confidential information and shall use it
 *only in accordance with the terms of the license agreement.
 *
 *File                  :   TCUAHangCADUpload.c
 *Author                :   Alokesh Ghosh
 *Created On   		 	:   10-Feb-2024
 *Module       		 	:	
 *Purpose      		 	:   
 *Modify                :

ProDpnd^-^-^-^11323910407^-^-^-^hex_screw_is1364.prt.8^plmpuvfs^/proj/omfcadhwvault/HNJ_WIP_Vault_Loc/hex_screw_is1364.prt.8^
ProDpnd^-^-^-^11341512303^hex_fl_screw_ts17130^A^1^hex_fl_screw_ts17130.prt.29^plmpuvfs^/proj/omfcadrvault/Rel_CAD/hex_fl_screw_ts17130.prt.29^
CREO Generic/Instance --->>>> Test1 (Success)
ProDpnd->Parent/Instance>>Part,Rev,Seq,DispName,  Generic>>Part,Rev,Seq,DispName,Host,relPath,

ProAsmMem^550742100237^B^2^550742100237.asm.6^plmpuvfs^/plm/REL/Vloc/5507/42/550742100237_B_2/550742100237.asm.6^-^-^-^263242103403.prt.2^plmpuvfs^/proj/omfcadrvault/Rel_CAD/263242103403.prt.2^
ProAsmMem^550742100238^B^2^550742100238.asm.7^plmpuvfs^/plm/REL/Vloc/5507/42/550742100238_B_2/550742100238.asm.7^-^-^-^263242103403.prt.2^plmpuvfs^/proj/omfcadrvault/Rel_CAD/263242103403.prt.2^
CREO Membership --->>>> Test2 (Success)
ProAsmMem->Parent>>Part,Rev,Seq,DispName,Host,relPath,  Child>>Part,Rev,Seq,DispName,Host,relPath,

ProAsmMemIns^550742100238^B^2^550742100238.asm.7^plmpuvfs^/plm/REL/Vloc/5507/42/550742100238_B_2/550742100238.asm.7^-^-^-^13150609288^split_pin_is549^NR^1^SPLIT_PIN_IS549^plmpuvfs^/proj/omfcadrvault/Rel_CAD/split_pin_is549.prt.3^
ProAsmMemIns^550746000061^E^4^550746000061.asm.53^plmpapp1c0^/plm/REL/Vloc/5507/46/550746000061_E_4/550746000061.asm.53^-^-^-^12080996029^-^-^-^HEX_THIN_NUT_IS13724^plmpuvfs^/proj/omfcadrvault/Rel_CAD/hex_thin_nut_is13724.prt.1^
CREO Membership --->>>> Test1 (Success)
ProAsmMemIns->Parent>>Part,Rev,Seq,DispName,Host,relPath,  Child-Instance>>Part,Rev,Seq,DispName, Child-Instance>Generic>>Part,Rev,Seq,DispName,,Host,relPath,

CREO Membership
ProAsmInsMem->Parent>>InstnaceName,GenericName,Part,Rev,Seq,GenericDispNm,Host,relPath,  Child>>InstnaceName,GenericName,Part,Rev,Seq,GenericDispNm,Host,relPath,

 ***************************************************************************/

#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>
#include <time.h>

#define ITK_err 910001
int iFail = 0;
int ITK_CALL(int iFail)
{
	char* cError = NULL;
	
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);fflush(stdout);
		  exit(0);
		}

		return iFail;
}

void GetDesignRevOFCadFile(tag_t* DataSetTag, tag_t* TargetTag)
{
	tag_t tmpDataSet = NULLTAG;
	tmpDataSet = *DataSetTag;
	tag_t IMANSpecTag = NULLTAG;
	int DsgnCnt = 0;
	int i=0;
	tag_t* DsgnsTags = NULLTAG;
	tag_t DsgnTag = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	char* GenricObjType = NULL;
	char* Item_Id = NULL;
	char* Revision_Id = NULL;
	char* ObjName = NULL;
	int DesgnRevFnd = 0;
	ITK_CALL(GRM_find_relation_type("IMAN_specification",&IMANSpecTag));
	ITK_CALL(GRM_list_primary_objects_only(tmpDataSet,IMANSpecTag,&DsgnCnt,&DsgnsTags));
	if (DsgnCnt > 0)
	{
		for (i = 0; i < DsgnCnt; ++i)
		{
			DsgnTag = DsgnsTags[i];
			ITK_CALL(TCTYPE_ask_object_type(DsgnTag,&objTypeTag));
			ITK_CALL(TCTYPE_ask_name2(objTypeTag,&GenricObjType));
			if (tc_strcmp(GenricObjType,"Design Revision")==0)
			{
				ITK_CALL(AOM_ask_value_string(DsgnTag,"item_id",&Item_Id));
				ITK_CALL(AOM_ask_value_string(DsgnTag,"item_revision_id",&Revision_Id));
				if (tc_strstr(Revision_Id,";")!=NULL)
				{
					ITK_CALL(AOM_ask_value_string(tmpDataSet,"object_name",&ObjName));
					if (tc_strcasecmp(Item_Id,ObjName)==0)
					{
						DesgnRevFnd = 1;
						*TargetTag = DsgnTag;
						break;
					}
				}
			}
		}
		if (DesgnRevFnd == 0)
		{
			*TargetTag = *DataSetTag;
		}
	}
	else
	{
		*TargetTag = *DataSetTag;
	}
}

void AddCREOMembership(tag_t* ParentObj, tag_t* ChildObj)
{
	tag_t CREOMem = NULLTAG;
	tag_t FndrelationCreoMem = NULLTAG;
	tag_t relationCre = NULLTAG;
	ITK_CALL(GRM_find_relation_type("Pro2_membership", & CREOMem));
	ITK_CALL(GRM_find_relation(*ParentObj, *ChildObj, CREOMem, &FndrelationCreoMem));
	if (FndrelationCreoMem == NULLTAG)
	{
		ITK_CALL(GRM_create_relation(*ParentObj, *ChildObj, CREOMem, NULLTAG, & relationCre));
		if (relationCre)
		{
			ITK_CALL(AOM_refresh(*ParentObj, 0));
            printf("\nBefore GRM_save_relation Pro2_membership\n"); fflush(stdout);
            ITK_CALL(GRM_save_relation(relationCre));
            printf("\n GRM_save_relation Pro2_membership\n"); fflush(stdout);
            ITK_CALL(AOM_refresh(*ParentObj, 0));
        }
	}
	else
	{
		printf("\nReleation Already Exists"); fflush(stdout);
	}
}

void CreateDataSet(char* CadFileDispNm, tag_t* ParentDataSetTag)
{
	char* dataSetActNm = NULL;
	char* CadFileDispNmDup = NULL;
	char* fullPath = NULL;
	fullPath = MEM_alloc(1000);
	tc_strcpy(fullPath,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/HangingCADDataMigrate/");
	tc_strcat(fullPath,CadFileDispNm);
	tc_strdup(CadFileDispNm,&CadFileDispNmDup);
	dataSetActNm = tc_strtok(CadFileDispNmDup,".");
	tag_t datasettype = NULLTAG;
	tag_t Newdataset = NULLTAG;
	tag_t tool = NULLTAG;
	tag_t filetag = NULLTAG;
	IMF_file_t fileDescriptor;
	AE_reference_type_t tagRefType =  1;
	int ref_count=0;
	int result = 0;
	char **ref_list;
	struct stat buffer;
	if (!stat(fullPath , &buffer))
	{
		printf("\n\t File exist .......%s\n",fullPath);fflush(stdout);
		printf("\nGoing to crate DataSet %s",CadFileDispNm); fflush(stdout);
		if (tc_strstr(CadFileDispNm,".prt."))
		{
			result = AE_find_datasettype2("ProPrt", &datasettype);
		}
		else if (tc_strstr(CadFileDispNm,".asm."))
		{
			result = AE_find_datasettype2("ProAsm", &datasettype);
		}

		int nameRef_cnt = 0;
		tag_t* namRefObject = NULLTAG;
		printf("\n\t Type found---->%d",result);fflush(stdout);
		result = AE_create_dataset_with_id(datasettype,dataSetActNm,dataSetActNm, NULL, NULL, &Newdataset);
		printf("\n\t Dataset created--->%s",dataSetActNm);fflush(stdout);
		result = AE_set_dataset_format2(Newdataset, "BINARY_REF");
		printf("\n\t Dataset format set--->%d",result);fflush(stdout);
		result = AE_set_dataset_tool(Newdataset,tool);
		printf("\n\t Tool set--->%d",result);fflush(stdout);fflush(stdout);
		result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
		printf("\n\t nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);
		if (nameRef_cnt == 0)
		{
			result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
			printf("\n\t Got reference list--->%d",result);fflush(stdout);
			result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
			printf("\n\t File Imported--->%d",result);fflush(stdout);
			if (result == 41178)
			{
				ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
			}
			result = AOM_save_with_extensions(filetag);
			printf("\n\t File saved--->%d",result);fflush(stdout);
			if (IMF_set_original_file_name2(filetag,CadFileDispNm)!=ITK_ok);
			result = AOM_save_with_extensions(filetag);
			printf("\n\t File saved--->%d  [%s]",result,CadFileDispNm); fflush(stdout);
			result = AE_add_dataset_named_ref2(Newdataset,ref_list[0],tagRefType,filetag);
			printf("\n\t AE_add_dataset_named_ref--->%d",result);fflush(stdout);
			AE_set_dataset_tool(Newdataset,tool);
			printf("\n\t Tool set--->%d",result);fflush(stdout);
			result = AOM_save_with_extensions(Newdataset);
			printf("\n\t AOM_save_with_extensions--->%d",result);fflush(stdout);
		}

		char* DataSetActName = NULL;
		ITK_CALL(AOM_UIF_ask_value(Newdataset,"object_string",&DataSetActName));
		if (tc_strstr(DataSetActName,";")!=NULL)
		{
			int i = 0;
			time_t t = time(NULL);
		    struct tm *currentTime = localtime(&t);
		    char formattedDate[20];
		    strftime(formattedDate, sizeof(formattedDate), "%d-%b-%Y", currentTime);
		    strcat(formattedDate, " 00:00");
		    printf("Today's date: %s\n", formattedDate);
			printf("\nDataSet not valid %s querying fresh dataset",DataSetActName); fflush(stdout);
			tag_t queryTag_d = NULLTAG;
			int resultCount_d = 0;
			tag_t* resulttags_d = NULLTAG;
			char *qry_entries_d[4] = {"Name","Created After","Owning User","Dataset Type"};
			char **qry_values_d = (char **) MEM_alloc(4 * sizeof(char *));
			ITK_CALL(QRY_find2("Dataset...", &queryTag_d));
			qry_values_d[0] = dataSetActNm;
			qry_values_d[1] = formattedDate;
			qry_values_d[2] = "loader*";
			qry_values_d[3] = "Creo*";
			ITK_CALL(QRY_execute(queryTag_d, 4, qry_entries_d, qry_values_d, &resultCount_d, &resulttags_d));
			if (resultCount_d > 0)
			{
				for (i = 0; i < resultCount_d; ++i)
				{
					Newdataset = resulttags_d[i];
					ITK_CALL(AOM_UIF_ask_value(Newdataset,"object_string",&DataSetActName));
					if (tc_strstr(DataSetActName,";")==NULL)
					{
						int DataSetNmRefCnt = 0;
						tag_t *DataSetNmRefObjs = NULLTAG;
						ITK_CALL(AE_ask_dataset_named_refs(Newdataset, &DataSetNmRefCnt, &DataSetNmRefObjs));
						if(DataSetNmRefCnt == 1)
						{
							char *GenericNmdRef = NULL;
							ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
							if (tc_strcasecmp(GenericNmdRef,CadFileDispNm)==0)
							{
								printf("\nMatch Found %s - %s",GenericNmdRef,CadFileDispNm);  fflush(stdout);
								*ParentDataSetTag = Newdataset;
								break;
							}
						}
					}
				}
			}
		}
		else
		{
			*ParentDataSetTag = Newdataset;
		}
		fullPath = NULL;
	}
	else
	{
		printf("\n\t File not exist for %s \n\n",fullPath);fflush(stdout);
	}
}

void CreateInstanceDataSet(char* InstanceDispNm, char* GenericFileDispNm, tag_t* ParentDataSetTag)
{
	tag_t datasettype = NULLTAG;
	tag_t Newdataset = NULLTAG;
	tag_t tool = NULLTAG;
	tag_t filetag = NULLTAG;
	IMF_file_t fileDescriptor;
	AE_reference_type_t tagRefType =  1;
	int ref_count=0;
	char **ref_list;
	printf("\nGoing to crate Instance DataSet %s",GenericFileDispNm); fflush(stdout);
	if (tc_strstr(GenericFileDispNm,".prt."))
	{
		ITK_CALL(AE_find_datasettype2("ProPrt", &datasettype));
	}
	else if (tc_strstr(GenericFileDispNm,".asm."))
	{
		ITK_CALL(AE_find_datasettype2("ProAsm", &datasettype));
	}
	ITK_CALL(AE_create_dataset_with_id(datasettype,InstanceDispNm,InstanceDispNm, NULL, NULL, &Newdataset));
	ITK_CALL(AE_set_dataset_format2(Newdataset, "BINARY_REF"));
	ITK_CALL(AE_set_dataset_tool(Newdataset,tool));
	ITK_CALL(AOM_save_with_extensions(Newdataset));
	printf("\nInstance DataSet Created"); fflush(stdout);

	char* DataSetActName = NULL;
	ITK_CALL(AOM_UIF_ask_value(Newdataset,"object_string",&DataSetActName));
	if (tc_strstr(DataSetActName,";")!=NULL)
	{
		int i = 0;
		int count_all = 0;
		tag_t* related_object_list = NULLTAG;
		time_t t = time(NULL);
	    struct tm *currentTime = localtime(&t);
	    char formattedDate[20];
	    strftime(formattedDate, sizeof(formattedDate), "%d-%b-%Y", currentTime);
	    strcat(formattedDate, " 00:00");
	    printf("Today's date: %s\n", formattedDate);
		printf("\nDataSet not valid %s querying fresh dataset",DataSetActName); fflush(stdout);
		tag_t queryTag_d = NULLTAG;
		int resultCount_d = 0;
		tag_t* resulttags_d = NULLTAG;
		char *qry_entries_d[4] = {"Name","Created After","Owning User","Dataset Type"};
		char **qry_values_d = (char **) MEM_alloc(4 * sizeof(char *));
		ITK_CALL(QRY_find2("Dataset...", &queryTag_d));
		qry_values_d[0] = InstanceDispNm;
		qry_values_d[1] = formattedDate;
		qry_values_d[2] = "loader*";
		qry_values_d[3] = "Creo*";
		ITK_CALL(QRY_execute(queryTag_d, 4, qry_entries_d, qry_values_d, &resultCount_d, &resulttags_d));
		if (resultCount_d > 0)
		{
			for (i = 0; i < resultCount_d; ++i)
			{
				Newdataset = resulttags_d[i];
				ITK_CALL(AOM_UIF_ask_value(Newdataset,"object_string",&DataSetActName));
				if (tc_strstr(DataSetActName,";")==NULL)
				{
					ITK_CALL(GRM_list_all_related_objects_only(Newdataset,&count_all,&related_object_list));
					if (count_all < 1)
					{
						*ParentDataSetTag = Newdataset;
						break;
					}
				}
			}
		}
	}
	else
	{
		*ParentDataSetTag = Newdataset;
	}
}

void CreateHangInstanceGenericRel(tag_t* Instance,tag_t* Generic)
{
	tag_t InstanceDup = NULLTAG;
	tag_t GenericDup = NULLTAG;
	InstanceDup = *Instance;
	GenericDup = *Generic;
	tag_t RelationGeneric = NULLTAG;
	tag_t RelationInstance = NULLTAG;
	tag_t FndrelationGeneric = NULLTAG;
	tag_t relationCreGen = NULLTAG;
	ITK_CALL(GRM_find_relation_type("IPEM_master_dependency",&RelationGeneric));
	ITK_CALL(GRM_find_relation_type("Pro2_instance",&RelationInstance));
	ITK_CALL(GRM_find_relation(*Instance, *Generic, RelationGeneric, &FndrelationGeneric));
	if (FndrelationGeneric == NULLTAG)
	{
		ITK_CALL(GRM_create_relation(*Instance, *Generic, RelationGeneric, NULLTAG, &relationCreGen));
		if (relationCreGen)
		{
			ITK_CALL(AOM_refresh(*Instance, 0));
            printf("\nBefore GRM_save_relation IPEM_master_dependency\n"); fflush(stdout);
            ITK_CALL(GRM_save_relation(relationCreGen));
            printf("\n GRM_save_relation IPEM_master_dependency\n"); fflush(stdout);
            ITK_CALL(AOM_refresh(*Instance, 0));
        }
	}
	ITK_CALL(AOM_refresh(*Generic, 0));
	ITK_CALL(AOM_refresh(*Instance, 0));
	FndrelationGeneric = NULLTAG;
	tag_t relationCreIns = NULLTAG;
	ITK_CALL(GRM_find_relation(*Generic, *Instance, RelationInstance, &FndrelationGeneric));
	if (FndrelationGeneric == NULLTAG)
	{
		ITK_CALL(GRM_create_relation(*Generic, *Instance, RelationInstance, NULLTAG, &relationCreIns));
		if (relationCreIns)
		{
			ITK_CALL(AOM_refresh(*Generic, 0));
            printf("\nBefore GRM_save_relation Pro2_instance\n"); fflush(stdout);
            ITK_CALL(GRM_save_relation(relationCreIns));
            printf("\n GRM_save_relation Pro2_instance\n"); fflush(stdout);
            ITK_CALL(AOM_refresh(*Generic, 0));
        }
	}
}

int ITK_user_main(int argc, char* argv[])
{
    char* cError = NULL;
	char* username = NULL;
	tag_t tuser = NULLTAG;
	iFail = ITK_auto_login();
	printf("\nReturn Value is : %d", iFail);fflush(stdout);
	if (iFail == ITK_ok)
	{
		printf("\nTeamcenter Login Success...");fflush(stdout);
		POM_get_user(&username, &tuser);
		printf("\nUsername = %s", username);fflush(stdout);
	}
	else
	{
		EMH_ask_error_text(iFail, &cError);
		printf("\nError is : %s", cError);fflush(stdout);
	}
	if (cError)
	{
		MEM_free(cError);
	}
	if (username)
	{
		MEM_free(username);
	}
	char *inputfile=NULL;
	char *inputline = NULL;
	char *DataSetActName = NULL;
	inputfile = ITK_ask_cli_argument("-i=");
	FILE *fp;
	tag_t queryTag_d = NULLTAG;
	fp=fopen(inputfile,"r");
	if(fp!=NULL)
	{
		const char delimiter[] = "^";
		int i = 0;
		int j = 0;
		char *token = NULL;
		char *DataSetObjType = NULL;
		inputline=(char *) MEM_alloc(1000);
		char *qry_entries_d[1] = {"Dataset Name"};
		char *qry_entries_ItmRev[2]  = {"Item ID","Revision"};
		char **qry_values_d = (char **) MEM_alloc(2 * sizeof(char *));
		char **qry_values_ItmRev = (char **) MEM_alloc(2 * sizeof(char *));
		int resultCount_d = 0;
		int resultCount_ItmRev = 0;
		tag_t* resulttags_d = NULLTAG;
		tag_t resulttag_d = NULLTAG;
		tag_t RelationGeneric = NULLTAG;
		tag_t RelationIMANSpec = NULLTAG;
		int cntGeneric = 0;
		int cntGenDtSet = 0;
		tag_t* tagsGenerics = NULLTAG;
		tag_t* tagsGenDtSets = NULLTAG;
		tag_t* resulttags_ItmRev = NULLTAG;
		tag_t tagGeneric = NULLTAG;
		tag_t datasetGeneric = NULLTAG;
		tag_t objTypeTag = NULLTAG;
		tag_t queryTag_ItmRev = NULLTAG;
		char* GenricObjType = NULL;
		tag_t RelationInstance = NULLTAG;
		ITK_CALL(GRM_find_relation_type("Pro2_instance",&RelationInstance));
		while(fgets(inputline,1000,fp)!=NULL)
		{
			char **strings;
    		strings = (char **)malloc(20 * sizeof(char *));
			printf("\n\n Input Part: %s",inputline); fflush(stdout);
			token = tc_strtok(inputline, delimiter);
		    int a = 0;
		    while (token != NULL && a < 20) {
		    	strings[a] = (char*)MEM_alloc( tc_strlen(token) *sizeof(char));
		        tc_strcpy(strings[a], token);
		        token = tc_strtok(NULL, delimiter);
		        a++;
		    }
		    ITK_CALL(QRY_find2("Item Revision...",&queryTag_ItmRev));
		    ITK_CALL(QRY_find2("Dataset Name", &queryTag_d));
		    ITK_CALL(GRM_find_relation_type("IPEM_master_dependency",&RelationGeneric));
		    ITK_CALL(GRM_find_relation_type("IMAN_specification",&RelationIMANSpec));
		    if (tc_strcmp(strings[0],"ProDpnd")==0)
		    {
		    	/*
		    	ProDpnd^-^-^-^11323910407^-^-^-^hex_screw_is1364.prt.8^plmpuvfs^/proj/omfcadhwvault/HNJ_WIP_Vault_Loc/hex_screw_is1364.prt.8^
				ProDpnd^-^-^-^11341512303^hex_fl_screw_ts17130^A^1^hex_fl_screw_ts17130.prt.29^plmpuvfs^/proj/omfcadrvault/Rel_CAD/hex_fl_screw_ts17130.prt.29^
				CREO Generic/Instance
				ProDpnd->Parent/Instance>>Part,Rev,Seq,DispName,  Generic>>Part,Rev,Seq,DispName,Host,relPath,
				*/
				int InstanceGenericExists = 0;
		    	qry_values_d[0] = strings[4];
				ITK_CALL(QRY_execute(queryTag_d, 1, qry_entries_d, qry_values_d, &resultCount_d, &resulttags_d));
				printf("\n\t ProDpnd [%s] >>> resultCount_d:[%d]",strings[4],resultCount_d);fflush(stdout);
				if(resultCount_d > 0)
				{
					for (i = 0; i < resultCount_d; ++i)
					{
						resulttag_d = resulttags_d[i];
						ITK_CALL(AOM_UIF_ask_value(resulttag_d,"object_string",&DataSetActName));
						if (tc_strstr(DataSetActName,";")!=NULL) { continue; }

						ITK_CALL(GRM_list_secondary_objects_only(resulttag_d,RelationGeneric,&cntGeneric,&tagsGenerics));
						if (cntGeneric > 0)
						{
							tagGeneric = tagsGenerics[0];
							ITK_CALL(TCTYPE_ask_object_type(tagGeneric,&objTypeTag));
							ITK_CALL(TCTYPE_ask_name2(objTypeTag,&GenricObjType));
							if (tc_strcmp(GenricObjType,"Design Revision")==0)
							{
								ITK_CALL(GRM_list_secondary_objects_only(tagGeneric,RelationIMANSpec,&cntGenDtSet,&tagsGenDtSets));
								if (cntGenDtSet > 0)
								{
									for(j=0;j<cntGenDtSet;j++)
									{
										datasetGeneric=tagsGenDtSets[j];
										ITK_CALL(AOM_ask_value_string(datasetGeneric,"object_type",&DataSetObjType));
										if(tc_strcmp(DataSetObjType,"ProAsm")==0 || tc_strcmp(DataSetObjType,"ProPrt")==0)
										{
											int DataSetNmRefCnt = 0;
											tag_t *DataSetNmRefObjs = NULLTAG;
											ITK_CALL(AE_ask_dataset_named_refs(datasetGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
											if(DataSetNmRefCnt == 1)
											{
												char *GenericNmdRef = NULL;
												ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
												if (tc_strcasecmp(GenericNmdRef,strings[8])==0)
												{
													printf("\nMatch Found %s - %s",GenericNmdRef,strings[8]);  fflush(stdout);
													/* Generic Design Rev Present - OK */
													InstanceGenericExists = 1;
													break;
												}
											}
										}
									}
									if (InstanceGenericExists == 1) { break; }
								}
							}
							else if (tc_strcmp(GenricObjType,"ProPrt")==0 || tc_strcmp(GenricObjType,"ProAsm")==0 || tc_strcmp(GenricObjType,"Creo part")==0 || tc_strcmp(GenricObjType,"Creo assembly")==0)
							{
								int DataSetNmRefCnt = 0;
								tag_t *DataSetNmRefObjs = NULLTAG;
								ITK_CALL(AE_ask_dataset_named_refs(tagGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
								if(DataSetNmRefCnt == 1)
								{
									char *GenericNmdRef = NULL;
									ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
									if (tc_strcasecmp(GenericNmdRef,strings[8])==0)
									{
										printf("\nMatch Found %s - %s",GenericNmdRef,strings[8]); fflush(stdout);
										InstanceGenericExists = 1;
										break;
									}
								}
							}
						}
					}
				}
				if (InstanceGenericExists == 0)
				{
					int DsgRevPresentGenericMatch = 0;
					int GenericDataSetExists = 0;
					tag_t DesignRevTagOFGeneric = NULLTAG;
					tag_t DataSetTagOFGeneric = NULLTAG;
					tag_t DesignRevTODataSetTagOFGeneric = NULLTAG;
					//Search with Design Rev
					if (tc_strcmp(strings[5],"-")!=0 && tc_strcmp(strings[6],"-")!=0 && tc_strcmp(strings[7],"-")!=0)
					{
						char* RevSeq = NULL;
						RevSeq=(char *) MEM_alloc(50);
						tc_strcpy(RevSeq,strings[6]);
						tc_strcpy(RevSeq,";");
						tc_strcpy(RevSeq,strings[7]);

						qry_values_ItmRev[0] = strings[5];
						qry_values_ItmRev[1] = RevSeq;
						ITK_CALL(QRY_execute(queryTag_ItmRev, 1, qry_entries_ItmRev, qry_values_ItmRev, &resultCount_ItmRev, &resulttags_ItmRev));
						if (resultCount_ItmRev > 0)
						{
							tagGeneric = resulttags_ItmRev[0];
							ITK_CALL(GRM_list_secondary_objects_only(tagGeneric,RelationIMANSpec,&cntGenDtSet,&tagsGenDtSets));
							if (cntGenDtSet > 0)
							{
								for(j=0;j<cntGenDtSet;j++)
								{
									datasetGeneric=tagsGenDtSets[j];
									ITK_CALL(AOM_ask_value_string(datasetGeneric,"object_type",&DataSetObjType));
									if(tc_strcmp(DataSetObjType,"ProAsm")==0 || tc_strcmp(DataSetObjType,"ProPrt")==0)
									{
										int DataSetNmRefCnt = 0;
										tag_t *DataSetNmRefObjs = NULLTAG;
										ITK_CALL(AE_ask_dataset_named_refs(datasetGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
										if(DataSetNmRefCnt == 1)
										{
											char *GenericNmdRef = NULL;
											ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
											if (tc_strcasecmp(GenericNmdRef,strings[8])==0)
											{
												/* Generic Design Rev Present - OK */
												printf("\nMatch Found %s - %s",GenericNmdRef,strings[8]);  fflush(stdout);
												DsgRevPresentGenericMatch = 1;
												DesignRevTagOFGeneric = tagGeneric;
												DesignRevTODataSetTagOFGeneric = datasetGeneric;
												break;
											}
										}
									}
								}
							}
						}
					}
					//If Search with Design Rev -> Not Found >>> Search with DataSet
					int GenericExists = 0;
					if (DsgRevPresentGenericMatch == 0)
					{
						char* tempDt = NULL;
						char* SearchDt = NULL;
						tc_strdup(strings[8],&tempDt);
						SearchDt = tc_strtok(tempDt,".");
						qry_values_d[0] = SearchDt;
						ITK_CALL(QRY_execute(queryTag_d, 1, qry_entries_d, qry_values_d, &resultCount_d, &resulttags_d));
						for(j=0;j<resultCount_d;j++)
						{
							datasetGeneric=resulttags_d[j];
							ITK_CALL(AOM_UIF_ask_value(datasetGeneric,"object_string",&DataSetActName));
							if (tc_strstr(DataSetActName,";")!=NULL) { continue; }

							ITK_CALL(AOM_ask_value_string(datasetGeneric,"object_type",&DataSetObjType));
							if(tc_strcmp(DataSetObjType,"ProAsm")==0 || tc_strcmp(DataSetObjType,"ProPrt")==0)
							{
								int DataSetNmRefCnt = 0;
								tag_t *DataSetNmRefObjs = NULLTAG;
								ITK_CALL(AE_ask_dataset_named_refs(datasetGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
								if(DataSetNmRefCnt == 1)
								{
									char *GenericNmdRef = NULL;
									ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
									if (tc_strcasecmp(GenericNmdRef,strings[8])==0)
									{
										/* Generic Design Rev Present - OK */
										printf("\nMatch Found %s - %s",GenericNmdRef,strings[8]);  fflush(stdout);
										GenericExists = 1;
										DataSetTagOFGeneric = datasetGeneric;
										break;
									}
								}
							}
						}
					}
					tag_t CreatedInstance = NULLTAG;
					tag_t CreatedGeneric = NULLTAG;
					if (DesignRevTagOFGeneric == NULLTAG && DataSetTagOFGeneric == NULLTAG)
					{
						printf("\n\t\t\t\tCASE 1: DesignRevTagOFGeneric=NULL || DataSetTagOFGeneric=NULL"); fflush(stdout);
						//Instance: strings[4]
						//CreateInstanceDataSet(strings[4], strings[8], &CreatedInstance); //Alokesh Temp Block
						//Generic: strings[8]
						CreateDataSet(strings[8], &CreatedGeneric);
						//Create Hanging Instance and Hanging Generic : BOTH
						//CreateHangInstanceGenericRel(&CreatedInstance,&CreatedGeneric); //Alokesh Temp Block
					}
					else if (DesignRevTagOFGeneric != NULLTAG && DataSetTagOFGeneric == NULLTAG)
					{
						printf("\n\t\t\t\tCASE 2: DesignRevTagOFGeneric != NULL || DataSetTagOFGeneric=NULL"); fflush(stdout);
						//Instance: strings[4]
						CreateInstanceDataSet(strings[4], strings[8], &CreatedInstance);
						//Generic: DesignRevTagOFGeneric >> Design Revision || DesignRevTODataSetTagOFGeneric >> Instance Rel
						//Create Hanging Instance and link with Generic Design Rev
						CreateHangInstanceGenericRel(&CreatedInstance,&DesignRevTODataSetTagOFGeneric);
					}
					else if (DesignRevTagOFGeneric == NULLTAG && DataSetTagOFGeneric != NULLTAG)
					{
						printf("\n\t\t\t\tCASE 3: DesignRevTagOFGeneric==NULL || DataSetTagOFGeneric != NULL"); fflush(stdout);
						//Instance: strings[4]
						CreateInstanceDataSet(strings[4], strings[8], &CreatedInstance);
						//Generic: DataSetTagOFGeneric >> DataSet (ProAsm / ProPrt)
						//Create Hanging Instance and link with Generic Hanging DataSet || Direct link with DataSet
						CreateHangInstanceGenericRel(&CreatedInstance,&DataSetTagOFGeneric);
					}
				}
		    }
		    else if (tc_strcmp(strings[0],"ProAsmMem")==0)
		    {
		    	/*
		    	ProAsmMem^550742100237^B^2^550742100237.asm.6^plmpuvfs^/plm/REL/Vloc/5507/42/550742100237_B_2/550742100237.asm.6^-^-^-^263242103403.prt.2^plmpuvfs^/proj/omfcadrvault/Rel_CAD/263242103403.prt.2^
				ProAsmMem^550742100238^B^2^550742100238.asm.7^plmpuvfs^/plm/REL/Vloc/5507/42/550742100238_B_2/550742100238.asm.7^-^-^-^263242103403.prt.2^plmpuvfs^/proj/omfcadrvault/Rel_CAD/263242103403.prt.2^
				CREO Membership
				ProAsmMem->Parent>>Part,Rev,Seq,DispName,Host,relPath,  Child>>Part,Rev,Seq,DispName,Host,relPath,
				*/
				tag_t ParentDataSetTag = NULLTAG; // Parent DataSet which CREO Membership need to build
				int ParentDsgRevPresent = 0;
				int ParentDataSet = 0;
		    	if (tc_strcmp(strings[1],"-")!=0 && tc_strcmp(strings[2],"-")!=0 && tc_strcmp(strings[3],"-")!=0)
				{
					char* RevSeq = NULL;
					RevSeq=(char *) MEM_alloc(50);
					tc_strcpy(RevSeq,strings[2]);
					tc_strcpy(RevSeq,";");
					tc_strcpy(RevSeq,strings[3]);
					qry_values_ItmRev[0] = strings[1];
					qry_values_ItmRev[1] = RevSeq;
					ITK_CALL(QRY_execute(queryTag_ItmRev, 1, qry_entries_ItmRev, qry_values_ItmRev, &resultCount_ItmRev, &resulttags_ItmRev));
					if (resultCount_ItmRev > 0)
					{
						tagGeneric = resulttags_ItmRev[0];
						ITK_CALL(GRM_list_secondary_objects_only(tagGeneric,RelationIMANSpec,&cntGenDtSet,&tagsGenDtSets));
						if (cntGenDtSet > 0)
						{
							for(j=0;j<cntGenDtSet;j++)
							{
								datasetGeneric=tagsGenDtSets[j];
								ITK_CALL(AOM_ask_value_string(datasetGeneric,"object_type",&DataSetObjType));
								if(tc_strcmp(DataSetObjType,"ProAsm")==0 || tc_strcmp(DataSetObjType,"ProPrt")==0)
								{
									int DataSetNmRefCnt = 0;
									tag_t *DataSetNmRefObjs = NULLTAG;
									ITK_CALL(AE_ask_dataset_named_refs(datasetGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
									if(DataSetNmRefCnt == 1)
									{
										char *GenericNmdRef = NULL;
										ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
										if (tc_strcasecmp(GenericNmdRef,strings[4])==0)
										{
											/* Generic Design Rev Present - OK */
											ParentDsgRevPresent = 1;
											ParentDataSetTag = datasetGeneric;
											break;
										}
									}
								}
							}
						}
					}
				}
				if (ParentDsgRevPresent == 0)
				{
					char* tempDt = NULL;
					char* SearchDt = NULL;
					tc_strdup(strings[4],&tempDt);
					SearchDt = tc_strtok(tempDt,".");
					qry_values_d[0] = SearchDt;
					ITK_CALL(QRY_execute(queryTag_d, 1, qry_entries_d, qry_values_d, &resultCount_d, &resulttags_d));
					for(j=0;j<resultCount_d;j++)
					{
						datasetGeneric=resulttags_d[j];
						ITK_CALL(AOM_UIF_ask_value(datasetGeneric,"object_string",&DataSetActName));
						if (tc_strstr(DataSetActName,";")!=NULL) { continue; }
						ITK_CALL(AOM_ask_value_string(datasetGeneric,"object_type",&DataSetObjType));
						if(tc_strcmp(DataSetObjType,"ProAsm")==0 || tc_strcmp(DataSetObjType,"ProPrt")==0)
						{
							int DataSetNmRefCnt = 0;
							tag_t *DataSetNmRefObjs = NULLTAG;
							ITK_CALL(AE_ask_dataset_named_refs(datasetGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
							if(DataSetNmRefCnt == 1)
							{
								char *GenericNmdRef = NULL;
								ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
								if (tc_strcasecmp(GenericNmdRef,strings[4])==0)
								{
									/* Generic Design Rev Present - OK */
									ParentDataSet = 1;
									ParentDataSetTag = datasetGeneric;
									break;
								}
							}
						}
					}
				}
				if (ParentDsgRevPresent == 0 && ParentDataSet == 0)
				{
					//strings[4] --> Get the Tag to "ParentDataSetTag"
					//Need to Create 1 Hanging ASM File --> Then proceed for Membership ||>> Map to "ParentDataSetTag"
					CreateDataSet(strings[4], &ParentDataSetTag);
				}

				tag_t ChildDataSetTag = NULLTAG; // Child/ProAsm Member DataSet which need to add in CREO Membership of Parent
				int ChildDsgRevPresent = 0;
				int ChildDataSet = 0;
				if (tc_strcmp(strings[7],"-")!=0 && tc_strcmp(strings[8],"-")!=0 && tc_strcmp(strings[9],"-")!=0)
				{
					char* RevSeq = NULL;
					RevSeq=(char *) MEM_alloc(50);
					tc_strcpy(RevSeq,strings[8]);
					tc_strcpy(RevSeq,";");
					tc_strcpy(RevSeq,strings[9]);
					qry_values_ItmRev[0] = strings[7];
					qry_values_ItmRev[1] = RevSeq;
					ITK_CALL(QRY_execute(queryTag_ItmRev, 1, qry_entries_ItmRev, qry_values_ItmRev, &resultCount_ItmRev, &resulttags_ItmRev));
					if (resultCount_ItmRev > 0)
					{
						tagGeneric = resulttags_ItmRev[0];
						ITK_CALL(GRM_list_secondary_objects_only(tagGeneric,RelationIMANSpec,&cntGenDtSet,&tagsGenDtSets));
						if (cntGenDtSet > 0)
						{
							for(j=0;j<cntGenDtSet;j++)
							{
								datasetGeneric=tagsGenDtSets[j];
								ITK_CALL(AOM_ask_value_string(datasetGeneric,"object_type",&DataSetObjType));
								if(tc_strcmp(DataSetObjType,"ProAsm")==0 || tc_strcmp(DataSetObjType,"ProPrt")==0)
								{
									int DataSetNmRefCnt = 0;
									tag_t *DataSetNmRefObjs = NULLTAG;
									ITK_CALL(AE_ask_dataset_named_refs(datasetGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
									if(DataSetNmRefCnt == 1)
									{
										char *GenericNmdRef = NULL;
										ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
										if (tc_strcasecmp(GenericNmdRef,strings[10])==0)
										{
											/* Generic Design Rev Present - OK */
											ChildDsgRevPresent = 1;
											ChildDataSetTag = tagGeneric;
											break;
										}
									}
								}
							}
						}
					}
				}
				if (ChildDsgRevPresent == 0)
				{
					char* tempDt = NULL;
					char* SearchDt = NULL;
					tc_strdup(strings[10],&tempDt);
					SearchDt = tc_strtok(tempDt,".");
					qry_values_d[0] = SearchDt;
					ITK_CALL(QRY_execute(queryTag_d, 1, qry_entries_d, qry_values_d, &resultCount_d, &resulttags_d));
					printf("\nCheck %s -- %d",SearchDt,resultCount_d); fflush(stdout);
					for(j=0;j<resultCount_d;j++)
					{
						datasetGeneric=resulttags_d[j];
						ITK_CALL(AOM_UIF_ask_value(datasetGeneric,"object_string",&DataSetActName));
						if (tc_strstr(DataSetActName,";")!=NULL) { continue; }
						ITK_CALL(AOM_ask_value_string(datasetGeneric,"object_type",&DataSetObjType));
						if(tc_strcmp(DataSetObjType,"ProAsm")==0 || tc_strcmp(DataSetObjType,"ProPrt")==0)
						{
							int DataSetNmRefCnt = 0;
							tag_t *DataSetNmRefObjs = NULLTAG;
							ITK_CALL(AE_ask_dataset_named_refs(datasetGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
							printf("\nDataSetNmRefObjs %d",DataSetNmRefCnt); fflush(stdout);
							if(DataSetNmRefCnt == 1)
							{
								char *GenericNmdRef = NULL;
								ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
								printf("\nDataSetNmRefObjs %s --- %s",GenericNmdRef,strings[10]); fflush(stdout);
								if (tc_strcasecmp(GenericNmdRef,strings[10])==0)
								{
									/* Generic Design Rev Present - OK */
									ChildDataSet = 1;
									ChildDataSetTag = datasetGeneric;
									break;
								}
							}
						}
					}
				}
				if (ChildDsgRevPresent == 0 && ChildDataSet == 0)
				{
					//strings[10] --> Get the Tag to "ChildDataSetTag"
					//Need to Create 1 Hanging ASM/Prt File --> Then proceed for Membership ||>> Map to "ChildDataSetTag"
					CreateDataSet(strings[10], &ChildDataSetTag);
				}

				if (ParentDataSetTag != NULLTAG && ChildDataSetTag != NULLTAG)
				{
					//Add to CREO Membership || ParentDataSetTag >> ChildDataSetTag (CREO Membership)
					AddCREOMembership(&ParentDataSetTag, &ChildDataSetTag);
				}
		    }
		    else if (tc_strcmp(strings[0],"ProAsmMemIns")==0)
		    {
		    	/*
		    	ProAsmMemIns^550742100238^B^2^550742100238.asm.7^plmpuvfs^/plm/REL/Vloc/5507/42/550742100238_B_2/550742100238.asm.7^-^-^-^13150609288^split_pin_is549^NR^1^SPLIT_PIN_IS549^plmpuvfs^/proj/omfcadrvault/Rel_CAD/split_pin_is549.prt.3^
				ProAsmMemIns^550746000061^E^4^550746000061.asm.53^plmpapp1c0^/plm/REL/Vloc/5507/46/550746000061_E_4/550746000061.asm.53^-^-^-^12080996029^-^-^-^HEX_THIN_NUT_IS13724^plmpuvfs^/proj/omfcadrvault/Rel_CAD/hex_thin_nut_is13724.prt.1^
				CREO Membership
				ProAsmMemIns->Parent>>Part,Rev,Seq,DispName,Host,relPath,  Child-Instance>>Part,Rev,Seq,DispName, Child-Instance>Generic>>Part,Rev,Seq,DispName,,Host,relPath,
				*/
				tag_t ParentDataSetTag = NULLTAG; // Parent DataSet which CREO Membership need to build
				int ParentDsgRevPresent = 0;
				int ParentDataSet = 0;
				
		    	if (tc_strcmp(strings[1],"-")!=0 && tc_strcmp(strings[2],"-")!=0 && tc_strcmp(strings[3],"-")!=0)
				{
					char* RevSeq = NULL;
					RevSeq=(char *) MEM_alloc(50);
					tc_strcpy(RevSeq,strings[2]);
					tc_strcpy(RevSeq,";");
					tc_strcpy(RevSeq,strings[3]);
					qry_values_ItmRev[0] = strings[1];
					qry_values_ItmRev[1] = RevSeq;
					ITK_CALL(QRY_execute(queryTag_ItmRev, 1, qry_entries_ItmRev, qry_values_ItmRev, &resultCount_ItmRev, &resulttags_ItmRev));
					if (resultCount_ItmRev > 0)
					{
						tagGeneric = resulttags_ItmRev[0];
						ITK_CALL(GRM_list_secondary_objects_only(tagGeneric,RelationIMANSpec,&cntGenDtSet,&tagsGenDtSets));
						if (cntGenDtSet > 0)
						{
							for(j=0;j<cntGenDtSet;j++)
							{
								datasetGeneric=tagsGenDtSets[j];
								ITK_CALL(AOM_ask_value_string(datasetGeneric,"object_type",&DataSetObjType));
								if(tc_strcmp(DataSetObjType,"ProAsm")==0 || tc_strcmp(DataSetObjType,"ProPrt")==0)
								{
									int DataSetNmRefCnt = 0;
									tag_t *DataSetNmRefObjs = NULLTAG;
									ITK_CALL(AE_ask_dataset_named_refs(datasetGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
									if(DataSetNmRefCnt == 1)
									{
										char *GenericNmdRef = NULL;
										ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
										if (tc_strcasecmp(GenericNmdRef,strings[4])==0)
										{
											printf("\nMatch Found Design Rev %s - %s",GenericNmdRef,strings[4]); fflush(stdout);
											/* Generic Design Rev Present - OK */
											ParentDsgRevPresent = 1;
											ParentDataSetTag = datasetGeneric;
											break;
										}
									}
								}
							}
						}
					}
				}
				if (ParentDsgRevPresent == 0)
				{
					char* tempDt = NULL;
					char* SearchDt = NULL;
					tc_strdup(strings[4],&tempDt);
					SearchDt = tc_strtok(tempDt,".");
					qry_values_d[0] = SearchDt;
					ITK_CALL(QRY_execute(queryTag_d, 1, qry_entries_d, qry_values_d, &resultCount_d, &resulttags_d));
					for(j=0;j<resultCount_d;j++)
					{
						datasetGeneric=resulttags_d[j];
						ITK_CALL(AOM_UIF_ask_value(datasetGeneric,"object_string",&DataSetActName));
						if (tc_strstr(DataSetActName,";")!=NULL) { continue; }
						ITK_CALL(AOM_ask_value_string(datasetGeneric,"object_type",&DataSetObjType));
						if(tc_strcmp(DataSetObjType,"ProAsm")==0 || tc_strcmp(DataSetObjType,"ProPrt")==0)
						{
							int DataSetNmRefCnt = 0;
							tag_t *DataSetNmRefObjs = NULLTAG;
							ITK_CALL(AE_ask_dataset_named_refs(datasetGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
							if(DataSetNmRefCnt == 1)
							{
								char *GenericNmdRef = NULL;
								ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
								if (tc_strcasecmp(GenericNmdRef,strings[4])==0)
								{
									printf("\nMatch Found Dataset %s - %s",GenericNmdRef,strings[4]); fflush(stdout);
									/* Generic Design Rev Present - OK */
									ParentDataSet = 1;
									ParentDataSetTag = datasetGeneric;
									break;
								}
							}
						}
					}
				}
				if (ParentDsgRevPresent == 0 && ParentDataSet == 0)
				{
					//strings[4] --> Get the Tag to "ParentDataSetTag"
					//Need to Create 1 Hanging ASM File --> Then proceed for Membership ||>> Map to "ParentDataSetTag"
					CreateDataSet(strings[4], &ParentDataSetTag);
				}
				tag_t ChildDataSetTag = NULLTAG; // Child ProPrt Instance/ProAsmI Member DataSet which need to add in CREO Membership of Parent
				int ChildDsgRevPresent = 0;
				int ChildDataSet = 0;
		    	qry_values_d[0] = strings[10];
				ITK_CALL(QRY_execute(queryTag_d, 1, qry_entries_d, qry_values_d, &resultCount_d, &resulttags_d));
				printf("\n\t resultCount_d:[%d]",resultCount_d);fflush(stdout);
				if(resultCount_d > 0)
				{
					for (i = 0; i < resultCount_d; ++i)
					{
						resulttag_d = resulttags_d[i];
						ITK_CALL(AOM_UIF_ask_value(resulttag_d,"object_string",&DataSetActName));
						if (tc_strstr(DataSetActName,";")!=NULL) { continue; }
						ITK_CALL(GRM_list_secondary_objects_only(resulttag_d,RelationGeneric,&cntGeneric,&tagsGenerics));
						if (cntGeneric > 0)
						{
							tagGeneric = tagsGenerics[0];
							ITK_CALL(TCTYPE_ask_object_type(tagGeneric,&objTypeTag));
							ITK_CALL(TCTYPE_ask_name2(objTypeTag,&GenricObjType));
							printf("\nGenricObjType : %s",GenricObjType); fflush(stdout);
							if (tc_strcmp(GenricObjType,"Design Revision")==0)
							{
								ITK_CALL(GRM_list_secondary_objects_only(tagGeneric,RelationIMANSpec,&cntGenDtSet,&tagsGenDtSets));
								if (cntGenDtSet > 0)
								{
									for(j=0;j<cntGenDtSet;j++)
									{
										datasetGeneric=tagsGenDtSets[j];
										ITK_CALL(AOM_ask_value_string(datasetGeneric,"object_type",&DataSetObjType));
										if(tc_strcmp(DataSetObjType,"ProAsm")==0 || tc_strcmp(DataSetObjType,"ProPrt")==0)
										{
											tag_t tmpTagFind = NULLTAG;
											tag_t FndrelationGeneric = NULLTAG;
											//check Linkage "datasetGeneric" with "tmpTagFind"
											GetDesignRevOFCadFile(&resulttag_d, &tmpTagFind);
											ITK_CALL(GRM_find_relation(datasetGeneric, tmpTagFind, RelationInstance, &FndrelationGeneric));
											if (FndrelationGeneric == NULLTAG)
											{
												continue;
											}
											int DataSetNmRefCnt = 0;
											tag_t *DataSetNmRefObjs = NULLTAG;
											ITK_CALL(AE_ask_dataset_named_refs(datasetGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
											if(DataSetNmRefCnt == 1)
											{
												char *GenericNmdRef = NULL;
												ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
												printf("\nGenricObjType %s - %s",GenericNmdRef,strings[15]); fflush(stdout);
												if (tc_strcasecmp(GenericNmdRef,strings[15])==0)
												{
													printf("\nInatnce Generic Match Found Desg Rev"); fflush(stdout);
													/* Generic Design Rev Present - OK */
													ChildDsgRevPresent = 1;
													//Find any Design Revision Present with This Instance OR Not ||>> resulttag_d || Then Link with that Dsgn Rev
													GetDesignRevOFCadFile(&resulttag_d, &ChildDataSetTag);
													break;
												}
											}
										}
									}
									if (ChildDsgRevPresent == 1) { break; }
								}
							}
							else if (tc_strcmp(GenricObjType,"ProPrt")==0 || tc_strcmp(GenricObjType,"ProAsm")==0 || tc_strcmp(GenricObjType,"Creo part")==0 || tc_strcmp(GenricObjType,"Creo assembly")==0)
							{
								int DataSetNmRefCnt = 0;
								tag_t *DataSetNmRefObjs = NULLTAG;
								ITK_CALL(AE_ask_dataset_named_refs(tagGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
								if(DataSetNmRefCnt == 1)
								{
									char *GenericNmdRef = NULL;
									ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
									printf("\nGenricObjType : %s - %s",GenericNmdRef,strings[15]); fflush(stdout);
									if (tc_strcasecmp(GenericNmdRef,strings[15])==0)
									{
										printf("\nInatnce Generic Match Found Dataset"); fflush(stdout);
										ChildDsgRevPresent = 1;
										//Find any Design Revision Present with This Instance OR Not ||>> resulttag_d || Then Link with that Dsgn Rev
										GetDesignRevOFCadFile(&resulttag_d, &ChildDataSetTag);
										break;
									}
								}
							}
						}
					}
				}

				/*if (ChildDsgRevPresent == 0 && ChildDataSet == 0) || NOT REQUIRED
				{
					//Instance Generic Dataset must be present as downloaded and executed first
				}*/
				if (ChildDataSetTag != NULLTAG && ParentDataSetTag != NULLTAG)
				{
					//Add ChildDataSetTag in CREO Membership of ParentDataSetTag
					AddCREOMembership(&ParentDataSetTag, &ChildDataSetTag);
				}
		    }
		    else if (tc_strcmp(strings[0],"ProAsmInsMem")==0)
		    {
		    	/*
		    	ProAsmInsMem^253403150179^253403150410^-^-^-^253403150410.asm.58^plmpapp1c0^/plm/REL/Vloc/2534/03/253403150410_A_2/253403150410.asm.58^253403150180^253403150409^-^-^-^253403150409.asm.38^plmpuvfs^/proj/omfcadrvault/Rel_CAD/253403150409.asm.38^
				ProAsmInsMem^253403150180^253403150409^-^-^-^253403150409.asm.38^plmpuvfs^/proj/omfcadrvault/Rel_CAD/253403150409.asm.38^253403155120^253403150409_CONROD^-^-^-^253403150409_conrod.prt.37^plmpuvfs^/plm/REL/Vloc/2534/03/253403150409_conrod_NR_2/253403150409_conrod.prt.37^
		    	CREO Membership
				ProAsmInsMem->Parent>>InstnaceName,GenericName,Part,Rev,Seq,GenericDispNm,Host,relPath,  Child>>InstnaceName,GenericName,Part,Rev,Seq,GenericDispNm,Host,relPath,
				*/
				tag_t ParentDataSetTag = NULLTAG; // Child ProPrt Instance/ProAsmI Member DataSet which need to add in CREO Membership of Parent
				tag_t ParentDsgnRevTag = NULLTAG;
				int ParentDsgRevPresent = 0;
		    	qry_values_d[0] = strings[1];
				ITK_CALL(QRY_execute(queryTag_d, 1, qry_entries_d, qry_values_d, &resultCount_d, &resulttags_d));
				printf("\n\t resultCount_d:[%d]",resultCount_d);fflush(stdout);
				if(resultCount_d > 0)
				{
					for (i = 0; i < resultCount_d; ++i)
					{
						resulttag_d = resulttags_d[i];
						ITK_CALL(AOM_UIF_ask_value(resulttag_d,"object_string",&DataSetActName));
						if (tc_strstr(DataSetActName,";")!=NULL) { continue; }
						ITK_CALL(GRM_list_secondary_objects_only(resulttag_d,RelationGeneric,&cntGeneric,&tagsGenerics));
						if (cntGeneric > 0)
						{
							tagGeneric = tagsGenerics[0];
							ITK_CALL(TCTYPE_ask_object_type(tagGeneric,&objTypeTag));
							ITK_CALL(TCTYPE_ask_name2(objTypeTag,&GenricObjType));
							if (tc_strcmp(GenricObjType,"Design Revision")==0)
							{
								ITK_CALL(GRM_list_secondary_objects_only(tagGeneric,RelationIMANSpec,&cntGenDtSet,&tagsGenDtSets));
								if (cntGenDtSet > 0)
								{
									for(j=0;j<cntGenDtSet;j++)
									{
										datasetGeneric=tagsGenDtSets[j];
										ITK_CALL(AOM_ask_value_string(datasetGeneric,"object_type",&DataSetObjType));
										if(tc_strcmp(DataSetObjType,"ProAsm")==0 || tc_strcmp(DataSetObjType,"ProPrt")==0)
										{
											tag_t tmpTagFind = NULLTAG;
											tag_t FndrelationGeneric = NULLTAG;
											//check Linkage "datasetGeneric" with "tmpTagFind"
											GetDesignRevOFCadFile(&resulttag_d, &tmpTagFind);
											ITK_CALL(GRM_find_relation(datasetGeneric, tmpTagFind, RelationInstance, &FndrelationGeneric));
											if (FndrelationGeneric == NULLTAG)
											{
												continue;
											}
											int DataSetNmRefCnt = 0;
											tag_t *DataSetNmRefObjs = NULLTAG;
											ITK_CALL(AE_ask_dataset_named_refs(datasetGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
											if(DataSetNmRefCnt == 1)
											{
												char *GenericNmdRef = NULL;
												ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
												if (tc_strcasecmp(GenericNmdRef,strings[6])==0)
												{
													/* Generic Design Rev Present - OK */
													ParentDsgRevPresent = 1;
													//Find any Design Revision Present with This Instance OR Not ||>> resulttag_d || Then Link with that Dsgn Rev
													ParentDataSetTag = resulttag_d;
													GetDesignRevOFCadFile(&resulttag_d, &ParentDsgnRevTag);
													break;
												}
											}
										}
									}
									if (ParentDsgRevPresent == 1) { break; }
								}
							}
							else if (tc_strcmp(GenricObjType,"ProPrt")==0 || tc_strcmp(GenricObjType,"ProAsm")==0 || tc_strcmp(GenricObjType,"Creo part")==0 || tc_strcmp(GenricObjType,"Creo assembly")==0)
							{
								int DataSetNmRefCnt = 0;
								tag_t *DataSetNmRefObjs = NULLTAG;
								ITK_CALL(AE_ask_dataset_named_refs(tagGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
								if(DataSetNmRefCnt == 1)
								{
									char *GenericNmdRef = NULL;
									ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
									if (tc_strcasecmp(GenericNmdRef,strings[6])==0)
									{
										ParentDsgRevPresent = 1;
										//Find any Design Revision Present with This Instance OR Not ||>> resulttag_d || Then Link with that Dsgn Rev
										ParentDataSetTag = resulttag_d;
										GetDesignRevOFCadFile(&resulttag_d, &ParentDsgnRevTag);
										break;
									}
								}
							}
						}
					}
				}

				if (ParentDataSetTag == NULLTAG)
				{
					//strings[10] --> Get the Tag to "ChildDataSetTag"
					//Need to Create 1 Hanging ASM/Prt File --> Then proceed for Membership ||>> Map to "ChildDataSetTag"
					CreateDataSet(strings[6], &ParentDataSetTag);
				}

				tag_t ChildDataSetTag = NULLTAG; // Child ProPrt Instance/ProAsmI Member DataSet which need to add in CREO Membership of Parent
				tag_t ChildDsgnRevTag = NULLTAG;
				int ChildDsgRevPresent = 0;
		    	qry_values_d[0] = strings[9];
				ITK_CALL(QRY_execute(queryTag_d, 1, qry_entries_d, qry_values_d, &resultCount_d, &resulttags_d));
				printf("\n\t resultCount_d:[%d]",resultCount_d);fflush(stdout);
				if(resultCount_d > 0)
				{
					for (i = 0; i < resultCount_d; ++i)
					{
						resulttag_d = resulttags_d[i];
						ITK_CALL(AOM_UIF_ask_value(resulttag_d,"object_string",&DataSetActName));
						if (tc_strstr(DataSetActName,";")!=NULL) { continue; }
						ITK_CALL(GRM_list_secondary_objects_only(resulttag_d,RelationGeneric,&cntGeneric,&tagsGenerics));
						if (cntGeneric > 0)
						{
							tagGeneric = tagsGenerics[0];
							ITK_CALL(TCTYPE_ask_object_type(tagGeneric,&objTypeTag));
							ITK_CALL(TCTYPE_ask_name2(objTypeTag,&GenricObjType));
							if (tc_strcmp(GenricObjType,"Design Revision")==0)
							{
								ITK_CALL(GRM_list_secondary_objects_only(tagGeneric,RelationIMANSpec,&cntGenDtSet,&tagsGenDtSets));
								if (cntGenDtSet > 0)
								{
									for(j=0;j<cntGenDtSet;j++)
									{
										datasetGeneric=tagsGenDtSets[j];
										ITK_CALL(AOM_ask_value_string(datasetGeneric,"object_type",&DataSetObjType));
										if(tc_strcmp(DataSetObjType,"ProAsm")==0 || tc_strcmp(DataSetObjType,"ProPrt")==0)
										{
											tag_t tmpTagFind = NULLTAG;
											tag_t FndrelationGeneric = NULLTAG;
											//check Linkage "datasetGeneric" with "tmpTagFind"
											GetDesignRevOFCadFile(&resulttag_d, &tmpTagFind);
											ITK_CALL(GRM_find_relation(datasetGeneric, tmpTagFind, RelationInstance, &FndrelationGeneric));
											if (FndrelationGeneric == NULLTAG)
											{
												continue;
											}
											int DataSetNmRefCnt = 0;
											tag_t *DataSetNmRefObjs = NULLTAG;
											ITK_CALL(AE_ask_dataset_named_refs(datasetGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
											if(DataSetNmRefCnt == 1)
											{
												char *GenericNmdRef = NULL;
												ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
												if (tc_strcasecmp(GenericNmdRef,strings[14])==0)
												{
													/* Generic Design Rev Present - OK */
													ChildDsgRevPresent = 1;
													//Find any Design Revision Present with This Instance OR Not ||>> resulttag_d || Then Link with that Dsgn Rev
													ChildDataSetTag = resulttag_d;
													GetDesignRevOFCadFile(&resulttag_d, &ChildDsgnRevTag);
													break;
												}
											}
										}
									}
									if (ChildDsgRevPresent == 1) { break; }
								}
							}
							else if (tc_strcmp(GenricObjType,"ProPrt")==0 || tc_strcmp(GenricObjType,"ProAsm")==0 || tc_strcmp(GenricObjType,"Creo part")==0 || tc_strcmp(GenricObjType,"Creo assembly")==0)
							{
								int DataSetNmRefCnt = 0;
								tag_t *DataSetNmRefObjs = NULLTAG;
								ITK_CALL(AE_ask_dataset_named_refs(tagGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
								if(DataSetNmRefCnt == 1)
								{
									char *GenericNmdRef = NULL;
									ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
									if (tc_strcasecmp(GenericNmdRef,strings[14])==0)
									{
										ChildDsgRevPresent = 1;
										//Find any Design Revision Present with This Instance OR Not ||>> resulttag_d || Then Link with that Dsgn Rev
										ChildDataSetTag = resulttag_d;
										GetDesignRevOFCadFile(&resulttag_d, &ChildDsgnRevTag);
										break;
									}
								}
							}
						}
					}
				}

				if (ChildDsgnRevTag == NULLTAG && ChildDataSetTag == NULLTAG)
				{
					//strings[14] --> Get the Tag to "ChildDataSetTag"
					//Need to Create 1 Hanging ASM/Prt File --> Then proceed for Membership ||>> Map to "ChildDataSetTag"
					CreateDataSet(strings[14], &ChildDataSetTag);
				}

				if (ParentDataSetTag != NULLTAG && ChildDsgnRevTag != NULLTAG)
				{
					printf("\n\t\tAlokesh 1\n"); fflush(stdout);
					//Add ChildDsgnRevTag in CREO Membership of ParentDsgnRevTag
					AddCREOMembership(&ParentDataSetTag, &ChildDsgnRevTag);
				}
				else if (ParentDataSetTag != NULLTAG && ChildDataSetTag != NULLTAG)
				{
					printf("\n\t\tAlokesh 2\n"); fflush(stdout);
					//Add ChildDataSetTag in CREO Membership of ParentDsgnRevTag
					AddCREOMembership(&ParentDataSetTag, &ChildDataSetTag);
				}

				/*if (ParentDsgnRevTag != NULLTAG && ChildDsgnRevTag != NULLTAG)
				{
					printf("\n\t\tAlokesh 1\n"); fflush(stdout);
					//Add ChildDsgnRevTag in CREO Membership of ParentDsgnRevTag
					AddCREOMembership(&ParentDsgnRevTag, &ChildDsgnRevTag);
				}
				else if (ParentDsgnRevTag != NULLTAG && ChildDsgnRevTag == NULLTAG && ChildDataSetTag != NULLTAG)
				{
					printf("\n\t\tAlokesh 2\n"); fflush(stdout);
					//Add ChildDataSetTag in CREO Membership of ParentDsgnRevTag
					AddCREOMembership(&ParentDsgnRevTag, &ChildDataSetTag);
				}
				else if (ParentDsgnRevTag == NULLTAG && ChildDsgnRevTag != NULLTAG && ParentDataSetTag != NULLTAG)
				{
					printf("\n\t\tAlokesh 3\n"); fflush(stdout);
					//Add ChildDsgnRevTag in CREO Membership of ParentDataSetTag
					AddCREOMembership(&ParentDataSetTag, &ChildDsgnRevTag);
				}
				else if (ParentDsgnRevTag == NULLTAG && ChildDsgnRevTag == NULLTAG && ParentDataSetTag != NULLTAG && ChildDataSetTag != NULLTAG)
				{
					printf("\n\t\tAlokesh 4\n"); fflush(stdout);
					//Add ChildDataSetTag in CREO Membership of ParentDataSetTag
					AddCREOMembership(&ParentDataSetTag, &ChildDataSetTag);
				}*/
		    }
		    else if (tc_strcmp(strings[0],"ProAsmInsMemProPrtAsm")==0)
		    {
		    	/*
		    	ProAsmInsMemProPrtAsm^253403150179^253403150410^-^-^-^253403150410.asm.58^plmpapp1c0^/plm/REL/Vloc/2534/03/253403150410_A_2/253403150410.asm.58^-^-^-^253403150409_skl.prt.32^plmpuvfs^/plm/CE/Vloc/2534/03/253403150409_skl_NR_2/253403150409_skl.prt.32^
				ProAsmInsMemProPrtAsm^253403150179^253403150410^-^-^-^253403150410.asm.58^plmpapp1c0^/plm/REL/Vloc/2534/03/253403150410_A_2/253403150410.asm.58^252503153206^B^3^252503153206.prt.8^plmpapp1c0^/plm/REL/Vloc/2525/03/252503153206_B_3/252503153206.prt.8^
		    	CREO Membership
				ProAsmInsMemProPrtAsm->Parent>>InstnaceName,GenericName,Part,Rev,Seq,GenericDispNm,Host,relPath,  Child>>Part,Rev,Seq,ChildDispName,ChildHost,ChildFullPath
				*/

				tag_t ParentDataSetTag = NULLTAG; // Child ProPrt Instance/ProAsmI Member DataSet which need to add in CREO Membership of Parent
				tag_t ParentDsgnRevTag = NULLTAG;
				int ParentDsgRevPresent = 0;
		    	qry_values_d[0] = strings[1];
				ITK_CALL(QRY_execute(queryTag_d, 1, qry_entries_d, qry_values_d, &resultCount_d, &resulttags_d));
				printf("\n\t resultCount_d:[%d]",resultCount_d);fflush(stdout);
				if(resultCount_d > 0)
				{
					for (i = 0; i < resultCount_d; ++i)
					{
						resulttag_d = resulttags_d[i];
						ITK_CALL(AOM_UIF_ask_value(resulttag_d,"object_string",&DataSetActName));
						if (tc_strstr(DataSetActName,";")!=NULL) { continue; }
						ITK_CALL(GRM_list_secondary_objects_only(resulttag_d,RelationGeneric,&cntGeneric,&tagsGenerics));
						if (cntGeneric > 0)
						{
							tagGeneric = tagsGenerics[0];
							ITK_CALL(TCTYPE_ask_object_type(tagGeneric,&objTypeTag));
							ITK_CALL(TCTYPE_ask_name2(objTypeTag,&GenricObjType));
							if (tc_strcmp(GenricObjType,"Design Revision")==0)
							{
								ITK_CALL(GRM_list_secondary_objects_only(tagGeneric,RelationIMANSpec,&cntGenDtSet,&tagsGenDtSets));
								if (cntGenDtSet > 0)
								{
									for(j=0;j<cntGenDtSet;j++)
									{
										datasetGeneric=tagsGenDtSets[j];
										ITK_CALL(AOM_ask_value_string(datasetGeneric,"object_type",&DataSetObjType));
										if(tc_strcmp(DataSetObjType,"ProAsm")==0 || tc_strcmp(DataSetObjType,"ProPrt")==0)
										{
											tag_t tmpTagFind = NULLTAG;
											tag_t FndrelationGeneric = NULLTAG;
											//check Linkage "datasetGeneric" with "tmpTagFind"
											GetDesignRevOFCadFile(&resulttag_d, &tmpTagFind);
											ITK_CALL(GRM_find_relation(datasetGeneric, tmpTagFind, RelationInstance, &FndrelationGeneric));
											if (FndrelationGeneric == NULLTAG)
											{
												continue;
											}
											int DataSetNmRefCnt = 0;
											tag_t *DataSetNmRefObjs = NULLTAG;
											ITK_CALL(AE_ask_dataset_named_refs(datasetGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
											if(DataSetNmRefCnt == 1)
											{
												char *GenericNmdRef = NULL;
												ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
												if (tc_strcasecmp(GenericNmdRef,strings[6])==0)
												{
													/* Generic Design Rev Present - OK */
													ParentDsgRevPresent = 1;
													//Find any Design Revision Present with This Instance OR Not ||>> resulttag_d || Then Link with that Dsgn Rev
													ParentDataSetTag = resulttag_d;
													GetDesignRevOFCadFile(&resulttag_d, &ParentDsgnRevTag);
													break;
												}
											}
										}
									}
									if (ParentDsgRevPresent == 1) { break; }
								}
							}
							else if (tc_strcmp(GenricObjType,"ProPrt")==0 || tc_strcmp(GenricObjType,"ProAsm")==0 || tc_strcmp(GenricObjType,"Creo part")==0 || tc_strcmp(GenricObjType,"Creo assembly")==0)
							{
								int DataSetNmRefCnt = 0;
								tag_t *DataSetNmRefObjs = NULLTAG;
								ITK_CALL(AE_ask_dataset_named_refs(tagGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
								if(DataSetNmRefCnt == 1)
								{
									char *GenericNmdRef = NULL;
									ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
									if (tc_strcasecmp(GenericNmdRef,strings[6])==0)
									{
										ParentDsgRevPresent = 1;
										//Find any Design Revision Present with This Instance OR Not ||>> resulttag_d || Then Link with that Dsgn Rev
										ParentDataSetTag = resulttag_d;
										GetDesignRevOFCadFile(&resulttag_d, &ParentDsgnRevTag);
										break;
									}
								}
							}
						}
					}
				}

				tag_t ChildDataSetTag = NULLTAG; // Child/ProAsm Member DataSet which need to add in CREO Membership of Parent
				int ChildDsgRevPresent = 0;
				int ChildDataSet = 0;
				if (tc_strcmp(strings[9],"-")!=0 && tc_strcmp(strings[10],"-")!=0 && tc_strcmp(strings[11],"-")!=0)
				{
					char* RevSeq = NULL;
					RevSeq=(char *) MEM_alloc(50);
					tc_strcpy(RevSeq,strings[10]);
					tc_strcpy(RevSeq,";");
					tc_strcpy(RevSeq,strings[11]);
					qry_values_ItmRev[0] = strings[9];
					qry_values_ItmRev[1] = RevSeq;
					ITK_CALL(QRY_execute(queryTag_ItmRev, 1, qry_entries_ItmRev, qry_values_ItmRev, &resultCount_ItmRev, &resulttags_ItmRev));
					if (resultCount_ItmRev > 0)
					{
						tagGeneric = resulttags_ItmRev[0];
						ITK_CALL(GRM_list_secondary_objects_only(tagGeneric,RelationIMANSpec,&cntGenDtSet,&tagsGenDtSets));
						if (cntGenDtSet > 0)
						{
							for(j=0;j<cntGenDtSet;j++)
							{
								datasetGeneric=tagsGenDtSets[j];
								ITK_CALL(AOM_ask_value_string(datasetGeneric,"object_type",&DataSetObjType));
								if(tc_strcmp(DataSetObjType,"ProAsm")==0 || tc_strcmp(DataSetObjType,"ProPrt")==0)
								{
									int DataSetNmRefCnt = 0;
									tag_t *DataSetNmRefObjs = NULLTAG;
									ITK_CALL(AE_ask_dataset_named_refs(datasetGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
									if(DataSetNmRefCnt == 1)
									{
										char *GenericNmdRef = NULL;
										ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
										if (tc_strcasecmp(GenericNmdRef,strings[12])==0)
										{
											/* Generic Design Rev Present - OK */
											ChildDsgRevPresent = 1;
											ChildDataSetTag = tagGeneric;
											break;
										}
									}
								}
							}
						}
					}
				}
				if (ChildDsgRevPresent == 0)
				{
					char* tempDt = NULL;
					char* SearchDt = NULL;
					tc_strdup(strings[12],&tempDt);
					SearchDt = tc_strtok(tempDt,".");
					qry_values_d[0] = SearchDt;
					ITK_CALL(QRY_execute(queryTag_d, 1, qry_entries_d, qry_values_d, &resultCount_d, &resulttags_d));
					printf("\nCheck %s -- %d",SearchDt,resultCount_d); fflush(stdout);
					for(j=0;j<resultCount_d;j++)
					{
						datasetGeneric=resulttags_d[j];
						ITK_CALL(AOM_UIF_ask_value(datasetGeneric,"object_string",&DataSetActName));
						if (tc_strstr(DataSetActName,";")!=NULL) { continue; }
						ITK_CALL(AOM_ask_value_string(datasetGeneric,"object_type",&DataSetObjType));
						if(tc_strcmp(DataSetObjType,"ProAsm")==0 || tc_strcmp(DataSetObjType,"ProPrt")==0)
						{
							int DataSetNmRefCnt = 0;
							tag_t *DataSetNmRefObjs = NULLTAG;
							ITK_CALL(AE_ask_dataset_named_refs(datasetGeneric, &DataSetNmRefCnt, &DataSetNmRefObjs));
							printf("\nDataSetNmRefObjs %d",DataSetNmRefCnt); fflush(stdout);
							if(DataSetNmRefCnt == 1)
							{
								char *GenericNmdRef = NULL;
								ITK_CALL(AOM_ask_value_string(DataSetNmRefObjs[0],"object_string",&GenericNmdRef));
								printf("\nDataSetNmRefObjs %s --- %s",GenericNmdRef,strings[12]); fflush(stdout);
								if (tc_strcasecmp(GenericNmdRef,strings[12])==0)
								{
									/* Generic Design Rev Present - OK */
									ChildDataSet = 1;
									ChildDataSetTag = datasetGeneric;
									break;
								}
							}
						}
					}
				}
				if (ChildDsgRevPresent == 0 && ChildDataSet == 0)
				{
					//strings[10] --> Get the Tag to "ChildDataSetTag"
					//Need to Create 1 Hanging ASM/Prt File --> Then proceed for Membership ||>> Map to "ChildDataSetTag"
					CreateDataSet(strings[12], &ChildDataSetTag);
				}

				if (ParentDataSetTag != NULLTAG && ChildDataSetTag != NULLTAG)
				{
					//Add to CREO Membership || ParentDataSetTag >> ChildDataSetTag (CREO Membership)
					AddCREOMembership(&ParentDataSetTag, &ChildDataSetTag);
				}
		    }

		    for (i = 0; i < 20; i++) {
		        strings[i] = NULL;
		    }
		}
	}
	fclose(fp);
	iFail = ITK_exit_module(TRUE);
	printf("\nReturn Value is : %d", iFail);
	if (iFail == ITK_ok)
	{
		printf("\nTeamcenter Logout Success...");fflush(stdout);
	}
	else
	{
		EMH_ask_error_text(iFail, &cError);
		printf("\nError is : %s", cError);fflush(stdout);
	}
	return iFail;
}
