/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2023  MNM.  ALL RIGHTS RESERVED
*
*------------------------------------------------------------------------------
* Filename		: EbomCadBomCheck.c
* Description	: This Utility Used For ERC Migrated Data DataSet Validation, BVR and CREO Membership Checking in CVPROD
* Module       	: Report
* Since		    : 2023
* ENVIRONMENT	: C++, ITK
* History       : Automated Data Validation instead of Mannual Data Checking Activity
*------------------------------------------------------------------------------
*    Date         	   Name														Description of Change
* 30/03/2023   	   Alokesh Ghosh		          								Cad Bom Expenstion
* -----------------------------------------------------------------------------
*
* Double JT File 															- Both CREO Mem & 2 Structure 	- Double_JT
* Double Data Set CREO / CATIA												- Both CREO Mem & 2 Structure 	- Multi_CREO / Multi_CATIA / Multi_PDF
* Duplicate Part in CREO Membership 										- Only CREO Mem 				- Duplicate_CREOMem
* If Asm / CAD Product file then BVR Must be Present 						- Both CREO Mem & 2 Structure	- BVR_Not_Present
* If Asm file then CREO Membership / Generic Must be Present 				- Only CREO Mem 				- CREOMem_Missing
* Revision Effectivity Correct Or Not (Using Lexical Analysis, NR < A < B) 	- 2 Structure (Part Query)		- Revision_Mismatch
* Double DataSet CATIA (CADProd with CIM2AuxPart, but not CADPart)			- Both CREO Mem & 2 Structure	- Extra_CADPrt
* CATIA cgr and CADPart both doesnot need to be present / cgr need delete	- Both CREO Mem & 2 Structure	- Extra_CGR_File
* If Drawing Ind : D then check Drw File									- Both CREO Mem & 2 Structure	- DRW_Not_Present
* Check Double Drw File														- Both CREO Mem & 2 Structure	- Multi_DRW
* If DRW present then PDF should be Present 								- Both CREO Mem & 2 Structure	- PDF_Not_Available
* Obj Name: *WELD_Report* (Iman Spec) -> Named Ref Extension must be .csv 	- Both CREO Mem & 2 Structure	- WELD_Report_NamedRef_Issue
* CMI2Drawing (Object Type) must be in the relation -> IMAN_spec 			- Both CREO Mem & 2 Structure	- CMI2Drawing_Relation_Issue
* 
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/aom_prop.h>
#include <ae/dataset.h>
#define ITK_err 910001

//FILE  *output = NULL;
FILE *outputTCE = NULL;
FILE *FinalFile = NULL;
int iFail = 0;
const char *revision_Order[] = {"NR", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a1", "b1", "c1", "d1", "e1", "f1", "g1", "h1", "i1", "j1", "k1", "l1", "m1", "n1", "o1", "p1", "q1", "r1", "s1", "t1", "u1", "v1", "w1", "x1", "y1", "z1", "a2", "b2", "c2", "d2", "e2", "f2", "g2", "h2", "i2", "j2", "k2", "l2", "m2", "n2", "o2", "p2", "q2", "r2", "s2", "t2", "u2", "v2", "w2", "x2", "y2", "z2", "a3", "b3", "c3", "d3", "e3", "f3", "g3", "h3", "i3", "j3", "k3", "l3", "m3", "n3", "o3", "p3", "q3", "r3", "s3", "t3", "u3", "v3", "w3", "x3", "y3", "z3", "a4", "b4", "c4", "d4", "e4", "f4", "g4", "h4", "i4", "j4", "k4", "l4", "m4", "n4", "o4", "p4", "q4", "r4", "s4", "t4", "u4", "v4", "w4", "x4", "y4", "z4", "a5", "b5", "c5", "d5", "e5", "f5", "g5", "h5", "i5", "j5", "k5", "l5", "m5", "n5", "o5", "p5", "q5", "r5", "s5", "t5", "u5", "v5", "w5", "x5", "y5", "z5", "a6", "b6", "c6", "d6", "e6", "f6", "g6", "h6", "i6", "j6", "k6", "l6", "m6", "n6", "o6", "p6", "q6", "r6", "s6", "t6", "u6", "v6", "w6", "x6", "y6", "z6", "a7", "b7", "c7", "d7", "e7", "f7", "g7", "h7", "i7", "j7", "k7", "l7", "m7", "n7", "o7", "p7", "q7", "r7", "s7", "t7", "u7", "v7", "w7", "x7", "y7", "z7", "a8", "b8", "c8", "d8", "e8", "f8", "g8", "h8", "i8", "j8", "k8", "l8", "m8", "n8", "o8", "p8", "q8", "r8", "s8", "t8", "u8", "v8", "w8", "x8", "y8", "z8", "a9", "b9", "c9", "d9", "e9", "f9", "g9", "h9", "i9", "j9", "k9", "l9", "m9", "n9", "o9", "p9", "q9", "r9", "s9", "t9", "u9", "v9", "w9", "x9", "y9", "z9"};
const int revision_length = 260;
int ctr=0;
char *GlobalIPPart = NULL;
char *GlobalIPRevSeq = NULL;
char **TcuaRvwEBOM;
int RvwEbomCnt = 0;

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);fflush(stdout);
		  exit(0);
		}

		return iFail;
}

void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

// Function to apply XSLT transformation to an XML file
/*int applyXSLTTransformation(const char* xmlFilePath, const char* xsltFilePath, const char* outputFilePath) {
    xmlDocPtr doc, xsl, result;

    // Initialize libxml2 and libxslt
    xmlInitParser();
    xsltInit();

    // Load the XML document
    doc = xmlParseFile(xmlFilePath);
    if (doc == NULL) {
        fprintf(stderr, "Failed to parse XML file: %s\n", xmlFilePath);
        return ITK_err;
    }

    // Load the XSLT stylesheet
    xsl = xmlParseFile(xsltFilePath);
    if (xsl == NULL) {
        fprintf(stderr, "Failed to load XSLT stylesheet: %s\n", xsltFilePath);
        xmlFreeDoc(doc);
        return ITK_err;
    }

    // Compile the XSLT stylesheet
    xsltStylesheetPtr xslSheet;
    xslSheet = xsltParseStylesheetDoc(xsl);
    if (xslSheet == NULL) {
        fprintf(stderr, "Failed to compile XSLT stylesheet.\n");
        xmlFreeDoc(doc);
        xmlFreeDoc(xsl);
        return ITK_err;
    }

    // Perform the transformation
    result = xsltApplyStylesheet(xslSheet, doc, NULL);
    if (result != NULL) {
        // Save the transformed result to the output file
        if (xmlSaveFormatFile(outputFilePath, result, 1) < 0) {
            fprintf(stderr, "Failed to save transformed XML to: %s\n", outputFilePath);
        } else {
            printf("Transformation successful. Output saved to: %s\n", outputFilePath);
        }

        // Cleanup
        xsltFreeStylesheet(xslSheet);
        xmlFreeDoc(result);
    } else {
        fprintf(stderr, "Transformation failed.\n");
    }

    xmlFreeDoc(doc);
    //xmlFreeDoc(xsl);
    // Cleanup libxml2 and libxslt
    xsltCleanupGlobals();
    xmlCleanupParser();

    return ITK_ok;
}*/

typedef struct IssueReportData {
    char *cnt;
    char *PartNo;
    char *RevSeq;
    char *IssueCat;
    char *IssueDesc;
    char *SuggSol;
} IssueRep;

typedef struct CadBOMChildData {
    char *ChildPartNo;
} CadBOMChildStruct;

typedef struct CadBOMParentData {
    char *PartNo;
    char *PartRev;
    char *PartSeq;
    int chldCnt;
    CadBOMChildStruct* CadBOMChild;
} CadBOMStruct;

typedef struct EBOMChildData {
    char *ChildPartNo;
    char *ChildPartRev;
    char *ChildPartSeq;
    char *PartType;
    char *t5PartCode;
    char *t5DrawingInd;
    char *t5DrawingNo;
    char *ProjectName;
    char *Designgroup;
    char *t5Material;
    char *t5RolledupWt;
    char *t5UQdup;
    char *UsesPartQty;
    char *t5PartStatus;
    char *owninguser;
} EBOMChildStruct;

typedef struct EBOMParentData {
    char *PartNo;
    char *PartRev;
    char *PartSeq;
    char *owninguser;
    int chldCnt;
    EBOMChildStruct* EBOMChild;
} EBOMStruct;

EBOMStruct* tcuaEBOMData;
int TcuaEbomSize = 0;
CadBOMStruct* tcuaCADBOMData;
int TcuaCadBomSize = 0;
IssueRep* IssueRepDt;
int issueDtCnt = 0;
int RepExtChk = 0;
int chk = 0;
char *RepExtChkChld;

int CheckTCUADML(char* Item_Id, char* Revision, char* Sequence)
{
	//CHECK DML
	int n_tskfund = 0;
	int *levelsaa;
	tag_t *referencers = NULLTAG;
	char **relations	=  NULL;
	int task = 0;
	tag_t tsk_dml_rel_type = NULLTAG;
	int dmlcnt = 0;
	tag_t *DMLRev = NULLTAG;
	char* DmlType = NULL;
	char* dmlNo = NULL ;
	char* dmlRelStat = NULL;
	int updRelzStatusDMLUA = 1;
	const int n_depth = 1;
	int k = 0;
	char* seqDup = NULL;
	char* CurName = NULL;
	tag_t tItemobj = NULLTAG;
	int n_itemobj_foundA = 0;
	char *cEntriesA[2]  = {"Item ID","Revision"};
	char **cValuesA = (char **) MEM_alloc(50 * sizeof(char *));
	tag_t* titemobj_resultsA = NULLTAG;
	tag_t iteamrevC = NULLTAG;
	seqDup=(char *) MEM_alloc(10 * sizeof(char *));
	tc_strcpy(seqDup, Revision);
	tc_strcat(seqDup, ";");
	tc_strcat(seqDup, Sequence);
	cValuesA[0] = Item_Id;
	cValuesA[1] = seqDup;
	ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
	ITK_CALL(QRY_execute(tItemobj, 2, cEntriesA, cValuesA, &n_itemobj_foundA, &titemobj_resultsA));
	if(n_itemobj_foundA>0)
	{
		iteamrevC = titemobj_resultsA[0];
		ITK_CALL(WSOM_where_referenced2((const tag_t)iteamrevC,n_depth,&n_tskfund,&levelsaa,&referencers,&relations));
		printf("\nNo of Reference Found : %d",n_tskfund);fflush(stdout);
		if(n_tskfund>0)
		{
			for(task=0;task<n_tskfund;task++)
			{
				ITK_CALL(AOM_UIF_ask_value(referencers[task], "current_name", &CurName));
				//printf("\nCurrent Name: %s - %s",CurName,relations[task]); fflush(stdout);
				if (tc_strcmp(CurName,"Parts For Gate Maturation")==0)
				{
					int n_tskfund1 = 0;
					int *levelsaa1;
					tag_t *referencers1 = NULLTAG;
					char **relations1	=  NULL;
					int task1=0;
					ITK_CALL(WSOM_where_referenced2((const tag_t)referencers[task],n_depth,&n_tskfund1,&levelsaa1,&referencers1,&relations1));
					if(n_tskfund1>0)
					{
						for(task1=0;task1<n_tskfund1;task1++)
						{
							ITK_CALL(AOM_UIF_ask_value(referencers1[task1], "current_name", &CurName));
							//printf("\nCurrent Name: %s - %s",CurName,relations[task1]); fflush(stdout);
							ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
							ITK_CALL(GRM_list_primary_objects_only(referencers1[task1],tsk_dml_rel_type,&dmlcnt,&DMLRev));
							//printf("\nNo of DML found : %d",dmlcnt);fflush(stdout);
							DmlType = NULL;
							dmlNo = NULL ;
							dmlRelStat = NULL;
							for(k=0;k<dmlcnt;k++)
							{
								ITK_CALL(AOM_ask_value_string(DMLRev[k],"object_type",&DmlType));
								ITK_CALL(AOM_ask_value_string(DMLRev[k],"item_id",&dmlNo));
								ITK_CALL(AOM_UIF_ask_value(DMLRev[k],"release_status_list",&dmlRelStat));
								//printf("\n DML number, DmlType %s,%s",dmlNo,DmlType,dmlRelStat);
								if (tc_strstr(dmlRelStat,"ERC Released")!=NULL)
								{
									printf("\nDR Update Skipped. Part Released with DML: %s - %s",dmlNo, DmlType); fflush(stdout);
									updRelzStatusDMLUA = 0;
									break;
								}
							}
							if (updRelzStatusDMLUA ==0)
							{
								break;
							}
						}
					}
				}
				else
				{
					ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
					ITK_CALL(GRM_list_primary_objects_only(referencers[task],tsk_dml_rel_type,&dmlcnt,&DMLRev));
					//printf("\nNo of DML found : %d",dmlcnt);fflush(stdout);
					DmlType = NULL;
					dmlNo = NULL ;
					dmlRelStat = NULL;
					for(k=0;k<dmlcnt;k++)
					{
						ITK_CALL(AOM_ask_value_string(DMLRev[k],"object_type",&DmlType));
						ITK_CALL(AOM_ask_value_string(DMLRev[k],"item_id",&dmlNo));
						ITK_CALL(AOM_UIF_ask_value(DMLRev[k],"release_status_list",&dmlRelStat));
						printf("\n DML number, DmlType %s,%s",dmlNo,DmlType,dmlRelStat);
						if (tc_strstr(dmlRelStat,"ERC Released")!=NULL)
						{
							printf("\nDR Update Skipped. Part Released with DML: %s - %s",dmlNo, DmlType); fflush(stdout);
							updRelzStatusDMLUA = 0;
							break;
						}
					}
				}
				if (updRelzStatusDMLUA ==0)
				{
					break;
				}
			}
		}
	}
	return updRelzStatusDMLUA;
}

int checkNamedRefFile(char* cItem_Id, char* cRevision, char* refname2, char* objtypename, char* IssueWithType)
{
	char *compNmdRef = NULL;
	compNmdRef = tc_strtok(refname2,".");

	char* IssueWith = (char*)MEM_alloc(sizeof(char) * 100);
	tc_strcpy(IssueWith,"Wrong Named Ref : ");
	tc_strcat(IssueWith,IssueWithType);

	//printf("\n\t refname2:[%s] ",refname2);
	if(tc_strcasecmp(compNmdRef, objtypename) != 0)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"Wrong Named Ref")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, IssueWith);
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen(IssueWith) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, IssueWith);
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,%s,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision,IssueWith);fflush(FinalFile);
		}
	}
}

int checkNamedRefFilePDF(char* cItem_Id, char* cRevision, char* refname2, char* objtypename, char* IssueWithType)
{
	char *compNmdRef = NULL;
	compNmdRef = tc_strtok(refname2,".");

	char* IssueWith = (char*)MEM_alloc(sizeof(char) * 100);
	tc_strcpy(IssueWith,"Wrong Named Ref : ");
	tc_strcat(IssueWith,IssueWithType);

	char *compNmdRefUP = NULL;
	char *objtypenameUP = NULL;
	tc_strupr(compNmdRef, &compNmdRefUP);
	tc_strupr(objtypename, &objtypenameUP);

	//printf("\n\t refname2:[%s] ",refname2);
	if(tc_strstr(compNmdRefUP, objtypenameUP) == NULL)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"Wrong Named Ref")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, IssueWith);
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen(IssueWith) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, IssueWith);
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,%s,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision,IssueWith);fflush(FinalFile);
		}
	}
}

void ChkDataSetRelation(tag_t* DesignRevisionTagPrt)
{
	//printf("\n\t\tChkDataSetRelation*************************Start"); fflush(stdout);
	tag_t ItemRevTag = NULLTAG;
	ItemRevTag = *DesignRevisionTagPrt;

	tag_t relation_type =NULLTAG;
	tag_t relation_type2 =NULLTAG;
	tag_t relation_type3 = NULLTAG;
	int lp = 0;
	int n_attchs_JT = 0;
	int JTNmdRef = 0;
	int PDFNmdRef = 0;
	int JtNo=0;	
	int PdfNo =0;
	char *DrawingInd = NULL;
	int DrawingIndStat = 0;
	int j=0;
	tag_t dataset = NULLTAG;
	char *objtypename = NULL;
	char *datasetDispNm = NULL;
	char *objtype=NULL;
	char* cItem_Id = NULL;
	char* cRevision =NULL;
	char* PartOwner1 = NULL;
	tag_t* rellist_JT =NULLTAG;

	ITK_CALL(AOM_ask_value_string(ItemRevTag,"item_id",&cItem_Id));
	ITK_CALL(AOM_ask_value_string(ItemRevTag,"item_revision_id",&cRevision));
	ITK_CALL(AOM_UIF_ask_value(ItemRevTag,"owning_user",&PartOwner1));
	printf("\nItem ID: %s %s - %s", cItem_Id,cRevision,PartOwner1);

	if (tc_strstr(PartOwner1,"loader")==NULL)
	{
		return;
	}

	ITK_CALL(AOM_ask_value_string(ItemRevTag,"t5_DrawingInd",&DrawingInd)!=ITK_ok);
	if (DrawingInd != NULL)
    {
    	//printf("\n\tDrawingInd : %s",DrawingInd);fflush(stdout);
    	if (tc_strcmp(DrawingInd,"D") == 0)
    	{
    		DrawingIndStat = 1;
    	}
    }

	ITK_CALL(GRM_find_relation_type("IMAN_Rendering",&relation_type));
	ITK_CALL(GRM_list_secondary_objects_only(ItemRevTag,relation_type,&n_attchs_JT,&rellist_JT));
	char    **JTNmStore     =  (char **) MEM_alloc(100 * sizeof(char *));
	int JTStoreCnt = 0; int FndS =0 ;
	char    **PDFNmStore     =  (char **) MEM_alloc(100 * sizeof(char *));
	int PDFStoreCnt = 0;
	char    **CADPartNmStore     =  (char **) MEM_alloc(100 * sizeof(char *));
	int CADPrtStoreCnt = 0;
	char    **CADProductNmStore     =  (char **) MEM_alloc(100 * sizeof(char *));
	int CADProdStoreCnt = 0;
	for(j=0;j<n_attchs_JT;j++)
	{
		dataset=rellist_JT[j];
		if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
		if( AOM_ask_value_string(dataset,"object_type",&objtype)!=ITK_ok);
		if(tc_strcmp(objtype,"DirectModel")==0)
		{
			char *cItem_IdUP = NULL;
			char *objtypenameUP = NULL;
			tc_strupr(cItem_Id, &cItem_IdUP);
			tc_strupr(objtypename, &objtypenameUP);

			if (tc_strstr(objtypenameUP, cItem_IdUP) != NULL)
			{
				if (JTStoreCnt == 0)
				{
					JTNmStore[0] = objtypename;
					JTStoreCnt++;
					JtNo++;
				}
				else
				{
					FndS = 0;
					for (lp = 0; lp < JTStoreCnt; ++lp)
					{
						if (tc_strcasecmp(JTNmStore[lp], objtypename)==0)
						{
							JtNo++;
							FndS = 1;
							break;
						}
					}
					if (FndS == 0)
					{
						JTNmStore[JTStoreCnt] = objtypename;
						JTStoreCnt++;
					}
				}
			}
			else
			{
				JtNo++;
			}

			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				JTNmdRef++;

				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"JT File");
			}
		}
		else if(tc_strcmp(objtype,"PDF")==0)
		{
			char *cItem_IdUP = NULL;
			char *objtypenameUP = NULL;
			tc_strupr(cItem_Id, &cItem_IdUP);
			tc_strupr(objtypename, &objtypenameUP);

			if (tc_strstr(objtypenameUP, cItem_IdUP) != NULL)
			{
				if (PDFStoreCnt == 0)
				{
					PDFNmStore[0] = objtypename;
					PDFStoreCnt++;
					PdfNo++;
				}
				else
				{
					FndS = 0;
					for (lp = 0; lp < PDFStoreCnt; ++lp)
					{
						if (tc_strcasecmp(PDFNmStore[lp], objtypename)==0)
						{
							PdfNo++;
							FndS = 1;
							break;
						}
					}
					if (FndS == 0)
					{
						PDFNmStore[PDFStoreCnt] = objtypename;
						PDFStoreCnt++;
					}
				}
			}
			else
			{
				PdfNo++;
			}

			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				PDFNmdRef++;

				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFilePDF(cItem_Id,cRevision,refname2,objtypename,"PDF File");
			}
		}
	}
	if (JtNo == 0)
	{
		fprintf(outputTCE,"%s,%s,JT_Not_Available\n",cItem_Id,cRevision);fflush(outputTCE);
	}
	else if(JtNo > 1)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Multi_JT")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"Multi_JT")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "Multi_JT");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Multi_JT") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Multi_JT");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,Multi_JT,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}

		//fprintf(output,"%s,%s,Multi_JT,Data Set,Manual Correction\n",cItem_Id,cRevision);fflush(output);
	}
	else if(JtNo == 1 && JTNmdRef == 0)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"JT_NamedRef_Missing")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Remigration of Part")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"JT_NamedRef_Missing")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "JT_NamedRef_Missing");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("JT_NamedRef_Missing") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "JT_NamedRef_Missing");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,JT_NamedRef_Missing,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,JT_NamedRef_Missing,Data Set,Remigration of Part\n",cItem_Id,cRevision);fflush(output);
	}
	if (PdfNo == 0 && DrawingIndStat==1)
	{
		fprintf(outputTCE,"%s,%s,PDF_Not_Available\n",cItem_Id,cRevision);fflush(outputTCE);
	}
	else if(PdfNo > 1 && DrawingIndStat==1)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Multi_PDF")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"Multi_PDF")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "Multi_PDF");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Multi_PDF") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Multi_PDF");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,Multi_PDF,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}

		//fprintf(output,"%s,%s,Multi_PDF,Data Set,Manual Correction\n",cItem_Id,cRevision);fflush(output);
	}
	else if(PdfNo == 1 && DrawingIndStat==1 && PDFNmdRef == 0)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"PDF_NamedRef_Missing")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Remigration of Part")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"PDF_NamedRef_Missing")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "PDF_NamedRef_Missing");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("PDF_NamedRef_Missing") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "PDF_NamedRef_Missing");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,PDF_NamedRef_Missing,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,PDF_NamedRef_Missing,Data Set,Remigration of Part\n",cItem_Id,cRevision);fflush(output);
	}

	int ProAsm =0;
	int ProPrt =0;
	int ProDrw =0;
	int CMI2CacheCgr =0;
	int CMI2AuxPart =0;
	int CMI2Part =0;
	int CMI2Product =0;
	int CMI2Drawing =0;
	int MSExcel =0;
	int ProAsmNmdRef =0;
	int ProPrtNmdRef =0;
	int ProDrwNmdRef =0;
	int CMI2CacheCgrNmdRef =0;
	int CMI2AuxPartNmdRef =0;
	int CMI2PartNmdRef =0;
	int CMI2ProductNmdRef =0;
	int CMI2DrawingNmdRef =0;
	int MSExcelNmdRef =0;

	n_attchs_JT = 0;
	rellist_JT = NULLTAG;
	ITK_CALL(GRM_find_relation_type("IMAN_specification",&relation_type2));
	ITK_CALL(GRM_list_secondary_objects_only(ItemRevTag,relation_type2,&n_attchs_JT,&rellist_JT));
	for(j=0;j<n_attchs_JT;j++)
	{
		dataset=rellist_JT[j];
		if( AOM_ask_value_string(dataset,"object_name",&datasetDispNm)!=ITK_ok);
		if( AOM_ask_value_string(dataset,"object_type",&objtype)!=ITK_ok);
		if(tc_strcmp(objtype,"ProAsm")==0)
		{
			ProAsm++;
			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				ProAsmNmdRef++;

				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"ProAsm File");
			}
			else
			{
				tag_t tRelationFind = NULLTAG;
				int n_attchs_Genric = 0;
				tag_t *rellist_Genric = NULLTAG;
				ITK_CALL(GRM_find_relation_type("IPEM_master_dependency",&tRelationFind));
				ITK_CALL(GRM_list_secondary_objects_only(dataset,tRelationFind,&n_attchs_Genric,&rellist_Genric));
				if(n_attchs_Genric > 0)
				{
					ProAsmNmdRef++;
				}
			}
		}
		else if(tc_strcmp(objtype,"ProPrt")==0)
		{
			ProPrt++;
			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				ProPrtNmdRef++;

				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"ProPrt File");
			}
			else
			{
				tag_t tRelationFind = NULLTAG;
				int n_attchs_Genric = 0;
				tag_t *rellist_Genric = NULLTAG;
				ITK_CALL(GRM_find_relation_type("IPEM_master_dependency",&tRelationFind));
				ITK_CALL(GRM_list_secondary_objects_only(dataset,tRelationFind,&n_attchs_Genric,&rellist_Genric));
				if(n_attchs_Genric > 0)
				{
					ProPrtNmdRef++;
				}
			}
		}
		else if(tc_strcmp(objtype,"ProDrw")==0)
		{
			ProDrw++;
			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				ProDrwNmdRef++;
				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"ProDrw File");
			}
		}
		else if(tc_strcmp(objtype,"CMI2CacheCgr")==0)
		{
			CMI2CacheCgr++;
			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				CMI2CacheCgrNmdRef++;
				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"CMI2CacheCgr File");
			}
		}
		else if(tc_strcmp(objtype,"CMI2AuxPart")==0)
		{
			CMI2AuxPart++;
			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				CMI2AuxPartNmdRef++;
				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"CMI2AuxPart File");
			}
		}
		else if(tc_strcmp(objtype,"CMI2Part")==0)
		{
			//CMI2Part++;
			char *cItem_IdUP = NULL;
			char *objtypenameUP = NULL;
			tc_strupr(cItem_Id, &cItem_IdUP);
			tc_strupr(datasetDispNm, &objtypenameUP);
			if (tc_strstr(objtypenameUP, cItem_IdUP) != NULL)
			{
				if (CADPrtStoreCnt == 0)
				{
					CADPartNmStore[0] = datasetDispNm;
					CADPrtStoreCnt++;
					CMI2Part++;
				}
				else
				{
					FndS = 0;
					for (lp = 0; lp < CADPrtStoreCnt; ++lp)
					{
						if (tc_strcasecmp(CADPartNmStore[lp], datasetDispNm)==0)
						{
							CMI2Part++;
							FndS = 1;
							break;
						}
					}
					if (FndS == 0)
					{
						CADPartNmStore[CADPrtStoreCnt] = datasetDispNm;
						CADPrtStoreCnt++;
					}
				}
			}
			else
			{
				CMI2Part++;
			}

			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				CMI2PartNmdRef++;
				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"CMI2Part File");
			}
		}
		else if(tc_strcmp(objtype,"CMI2Product")==0)
		{
			//CMI2Product++;
			char *cItem_IdUP = NULL;
			char *objtypenameUP = NULL;
			tc_strupr(cItem_Id, &cItem_IdUP);
			tc_strupr(datasetDispNm, &objtypenameUP);
			if (tc_strstr(objtypenameUP, cItem_IdUP) != NULL)
			{
				if (CADProdStoreCnt == 0)
				{
					CADProductNmStore[0] = datasetDispNm;
					CADProdStoreCnt++;
					CMI2Product++;
				}
				else
				{
					FndS = 0;
					for (lp = 0; lp < CADProdStoreCnt; ++lp)
					{
						if (tc_strcasecmp(CADProductNmStore[lp], datasetDispNm)==0)
						{
							CMI2Product++;
							FndS = 1;
							break;
						}
					}
					if (FndS == 0)
					{
						CADProductNmStore[CADProdStoreCnt] = datasetDispNm;
						CADProdStoreCnt++;
					}
				}
			}
			else
			{
				CMI2Product++;
			}

			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				CMI2ProductNmdRef++;
				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"CMI2Product File");
			}
		}
		else if(tc_strcmp(objtype,"CMI2Drawing")==0)
		{
			CMI2Drawing++;
			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				CMI2DrawingNmdRef++;

				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"CMI2Drawing File");
			}
		}
		else if(tc_strcmp(objtype,"MSExcel")==0)
		{
			MSExcel++;
			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				MSExcelNmdRef++;

				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"MSExcel File");
			}
		}

		if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
		if(tc_strstr(objtypename,"WELD_Report")!=NULL || tc_strstr(objtypename,"weld_report")!=NULL || tc_strstr(objtypename,"Weld_Report")!=NULL)
		{
			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				tag_t RefObject_d = NULLTAG;
				char *named_ref = NULL;
				RefObject_d = DtNmRefObjs[0];
				if (AOM_ask_value_string(RefObject_d,"object_string",&named_ref)!=ITK_ok);
				if (tc_strstr(named_ref,".csv") == NULL)
				{
					RepExtChk = 0;
					for (chk = 0; chk < issueDtCnt; ++chk)
					{
						/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"NamedRef_Not_CSV_WELD_Report")==0)
						{
							RepExtChk = 1;
						}*/
						if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
						{
							RepExtChk = 1;
							if (tc_strstr(IssueRepDt[chk].IssueCat,"NamedRef_Not_CSV_WELD_Report")==NULL)
							{
								tc_strcpy(RepExtChkChld, "");
								tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
								tc_strcat(RepExtChkChld, ",");
								tc_strcat(RepExtChkChld, "NamedRef_Not_CSV_WELD_Report");
								IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
								//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
								tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
							}
							break;
						}
					}
					if (RepExtChk == 0)
					{
						IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
						IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
						sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
						IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
						tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
						IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
						tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
						IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("NamedRef_Not_CSV_WELD_Report") *sizeof(char));
						tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "NamedRef_Not_CSV_WELD_Report");
						IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
						tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
						IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
						tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
						issueDtCnt++;
						fprintf(FinalFile,"\n%s,%s,%s,%s,NamedRef_Not_CSV_WELD_Report,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
					}
					//fprintf(output,"%s,%s,NamedRef_Not_CSV_WELD_Report,Data Set,Frontend/Backend Correction\n",cItem_Id,cRevision);fflush(output);
				}
			}
			else
			{
				RepExtChk = 0;
				for (chk = 0; chk < issueDtCnt; ++chk)
				{
					/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"No_NamedRef_WELD_Report")==0)
					{
						RepExtChk = 1;
					}*/
					if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Remigration of Part")==0)
					{
						RepExtChk = 1;
						if (tc_strstr(IssueRepDt[chk].IssueCat,"No_NamedRef_WELD_Report")==NULL)
						{
							tc_strcpy(RepExtChkChld, "");
							tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
							tc_strcat(RepExtChkChld, ",");
							tc_strcat(RepExtChkChld, "No_NamedRef_WELD_Report");
							IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
							//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
							tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
						}
						break;
					}
				}
				if (RepExtChk == 0)
				{
					IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
					IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
					sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
					IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
					tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
					IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
					tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
					IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("No_NamedRef_WELD_Report") *sizeof(char));
					tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "No_NamedRef_WELD_Report");
					IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
					tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
					IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
					tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
					issueDtCnt++;
					fprintf(FinalFile,"\n%s,%s,%s,%s,No_NamedRef_WELD_Report,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
				}
				//fprintf(output,"%s,%s,No_NamedRef_WELD_Report,Data Set,Remigration of Part\n",cItem_Id,cRevision);fflush(output);
			}
		}
	}

	int refCMI2Drawing = 0;
	int refProDrw = 0;
	n_attchs_JT = 0;
	int refCMI2DrawingWronfRel= 0;
	int refProDrwWronfRel= 0;
	rellist_JT = NULLTAG;
	ITK_CALL(GRM_find_relation_type("IMAN_reference",&relation_type3));
	ITK_CALL(GRM_list_secondary_objects_only(ItemRevTag,relation_type3,&n_attchs_JT,&rellist_JT));
	for(j=0;j<n_attchs_JT;j++)
	{
		dataset=rellist_JT[j];
		if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
		if( AOM_ask_value_string(dataset,"object_type",&objtype)!=ITK_ok);
		if((tc_strcmp(objtype,"CMI2Drawing")==0) && (strcmp(cItem_Id,objtypename)!=0))
		{
			refCMI2Drawing++;
		}
		if((tc_strcmp(objtype,"ProDrw")==0) && (strcmp(cItem_Id,objtypename)!=0))
		{
			refProDrw++;
		}
		if((tc_strcmp(objtype,"CMI2Drawing")==0) && (strcmp(cItem_Id,objtypename)==0))
		{
			refCMI2DrawingWronfRel++;
		}
		if((tc_strcmp(objtype,"ProDrw")==0) && (strcmp(cItem_Id,objtypename)==0))
		{
			refProDrwWronfRel++;
		}
	}

	if(refCMI2DrawingWronfRel > 0)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"CMI2Drawing_In_IMAN_reference")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"CMI2Drawing_In_IMAN_reference")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "CMI2Drawing_In_IMAN_reference");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("CMI2Drawing_In_IMAN_reference") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "CMI2Drawing_In_IMAN_reference");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,CMI2Drawing_In_IMAN_reference,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,CMI2Drawing_In_IMAN_reference,Data Set,Manual Correction\n",cItem_Id,cRevision);fflush(output);
	}
	if(refProDrwWronfRel > 0)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"ProDrw_In_IMAN_reference")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"ProDrw_In_IMAN_reference")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "ProDrw_In_IMAN_reference");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("ProDrw_In_IMAN_reference") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "ProDrw_In_IMAN_reference");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,ProDrw_In_IMAN_reference,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,ProDrw_In_IMAN_reference,Data Set,Manual Correction\n",cItem_Id,cRevision);fflush(output);
	}

	if(ProAsm == 0 && ProPrt == 0 && CMI2Part == 0 && CMI2Product == 0)
	{
		fprintf(outputTCE,"%s,%s,No_CAD_DataSet\n",cItem_Id,cRevision);fflush(outputTCE);
	}
	if (ProDrw == 0 && CMI2Drawing == 0 && refCMI2Drawing ==0 && refProDrw==0 && DrawingIndStat==1)
	{
		fprintf(outputTCE,"%s,%s,Drawing_Not_Available\n",cItem_Id,cRevision);fflush(outputTCE);
	}

	if(ProAsm > 1)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Multi_ProAsm")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"Multi_ProAsm")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "Multi_ProAsm");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Multi_ProAsm") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Multi_ProAsm");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,Multi_ProAsm,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,Multi_ProAsm,Data Set,Manual Correction\n",cItem_Id,cRevision);fflush(output);
	}
	if(ProPrt > 1)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Multi_ProPrt")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"Multi_ProPrt")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "Multi_ProPrt");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Multi_ProPrt") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Multi_ProPrt");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,Multi_ProPrt,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,Multi_ProPrt,Data Set,Manual Correction\n",cItem_Id,cRevision);fflush(output);
	}
	if(ProDrw > 1)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Multi_ProDrw")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"Multi_ProDrw")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "Multi_ProDrw");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Multi_ProDrw") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Multi_ProDrw");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,Multi_ProDrw,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,Multi_ProDrw,Data Set,Manual Correction\n",cItem_Id,cRevision);fflush(output);
	}
	/*
	Commented As discussed with Rajan- Multi Allowed
	if(CMI2CacheCgr > 1)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			//if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Multi_CMI2CacheCgr")==0)
			//{
				//RepExtChk = 1;
			//}
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"Multi_CMI2CacheCgr")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "Multi_CMI2CacheCgr");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Multi_CMI2CacheCgr") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Multi_CMI2CacheCgr");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
		}
		//fprintf(output,"%s,%s,Multi_CMI2CacheCgr,Data Set,Manual Correction\n",cItem_Id,cRevision);fflush(output);
	}
	if(CMI2AuxPart > 1)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			//if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Multi_CMI2AuxPart")==0)
			//{
				//RepExtChk = 1;
			//}
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"Multi_CMI2AuxPart")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "Multi_CMI2AuxPart");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Multi_CMI2AuxPart") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Multi_CMI2AuxPart");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
		}
		//fprintf(output,"%s,%s,Multi_CMI2AuxPart,Data Set,Manual Correction\n",cItem_Id,cRevision);fflush(output);
	}
	*/
	if(CMI2Part > 1)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Multi_CMI2Part")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"Multi_CMI2Part")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "Multi_CMI2Part");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Multi_CMI2Part") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Multi_CMI2Part");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,Multi_CMI2Part,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,Multi_CMI2Part,Data Set,Manual Correction\n",cItem_Id,cRevision);fflush(output);
	}
	if(CMI2Product > 1)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Multi_CMI2Product")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"Multi_CMI2Product")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "Multi_CMI2Product");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Multi_CMI2Product") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Multi_CMI2Product");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,Multi_CMI2Product,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,Multi_CMI2Product,Data Set,Manual Correction\n",cItem_Id,cRevision);fflush(output);
	}
	/*if(CMI2Drawing > 1)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"Multi_CMI2Drawing")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "Multi_CMI2Drawing");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Multi_CMI2Drawing") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Multi_CMI2Drawing");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,Multi_CMI2Drawing,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,Multi_CMI2Drawing,Data Set,Manual Correction\n",cItem_Id,cRevision);fflush(output);
	}*/
	/*if(MSExcel > 1)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			//if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Multi_MSExcel")==0)
			//{
			//	RepExtChk = 1;
			//}
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"Multi_MSExcel")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "Multi_MSExcel");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Multi_MSExcel") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Multi_MSExcel");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,Multi_MSExcel,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,Multi_MSExcel,Data Set,Manual Correction\n",cItem_Id,cRevision);fflush(output);
	}*/

	if(ProAsm == 1 && ProAsmNmdRef == 0)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"ProAsm_NamedRef_Missing")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Remigration of Part")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"ProAsm_NamedRef_Missing")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "ProAsm_NamedRef_Missing");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("ProAsm_NamedRef_Missing") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "ProAsm_NamedRef_Missing");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,ProAsm_NamedRef_Missing,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,ProAsm_NamedRef_Missing,Data Set,Remigration of Part\n",cItem_Id,cRevision);fflush(output);
	}
	if(ProPrt == 1 && ProPrtNmdRef == 0)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"ProPrt_NamedRef_Missing")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Remigration of Part")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"ProPrt_NamedRef_Missing")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "ProPrt_NamedRef_Missing");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("ProPrt_NamedRef_Missing") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "ProPrt_NamedRef_Missing");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,ProPrt_NamedRef_Missing,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,ProPrt_NamedRef_Missing,Data Set,Remigration of Part\n",cItem_Id,cRevision);fflush(output);
	}
	if(ProDrw == 1 && ProDrwNmdRef == 0)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"ProDrwNmdRef_Missing")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Remigration of Part")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"ProDrwNmdRef_Missing")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "ProDrwNmdRef_Missing");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("ProDrwNmdRef_Missing") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "ProDrwNmdRef_Missing");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,ProDrwNmdRef_Missing,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,ProDrwNmdRef_Missing,Data Set,Remigration of Part\n",cItem_Id,cRevision);fflush(output);
	}
	if(CMI2CacheCgr == 1 && CMI2CacheCgrNmdRef == 0)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"CMI2CacheCgrNmdRef_Missing")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Remigration of Part")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"CMI2CacheCgrNmdRef_Missing")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "CMI2CacheCgrNmdRef_Missing");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("CMI2CacheCgrNmdRef_Missing") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "CMI2CacheCgrNmdRef_Missing");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,CMI2CacheCgrNmdRef_Missing,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,CMI2CacheCgrNmdRef_Missing,Data Set,Remigration of Part\n",cItem_Id,cRevision);fflush(output);
	}
	if(CMI2AuxPart == 1 && CMI2AuxPartNmdRef == 0)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"CMI2AuxPartNmdRef_Missing")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Remigration of Part")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"CMI2AuxPartNmdRef_Missing")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "CMI2AuxPartNmdRef_Missing");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("CMI2AuxPartNmdRef_Missing") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "CMI2AuxPartNmdRef_Missing");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,CMI2AuxPartNmdRef_Missing,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,CMI2AuxPartNmdRef_Missing,Data Set,Remigration of Part\n",cItem_Id,cRevision);fflush(output);
	}
	if(CMI2Part == 1 && CMI2PartNmdRef == 0)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"CMI2PartNmdRef_Missing")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Remigration of Part")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"CMI2PartNmdRef_Missing")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "CMI2PartNmdRef_Missing");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("CMI2PartNmdRef_Missing") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "CMI2PartNmdRef_Missing");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,CMI2PartNmdRef_Missing,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,CMI2PartNmdRef_Missing,Data Set,Remigration of Part\n",cItem_Id,cRevision);fflush(output);
	}
	if(CMI2Product == 1 && CMI2ProductNmdRef == 0)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"CMI2ProductNmdRef_Missing")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Remigration of Part")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"CMI2ProductNmdRef_Missing")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "CMI2ProductNmdRef_Missing");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("CMI2ProductNmdRef_Missing") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "CMI2ProductNmdRef_Missing");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,CMI2ProductNmdRef_Missing,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,CMI2ProductNmdRef_Missing,Data Set,Remigration of Part\n",cItem_Id,cRevision);fflush(output);
	}
	if(CMI2Drawing == 1 && CMI2DrawingNmdRef == 0)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"CMI2DrawingNmdRef_Missing")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Remigration of Part")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"CMI2DrawingNmdRef_Missing")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "CMI2DrawingNmdRef_Missing");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("CMI2DrawingNmdRef_Missing") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "CMI2DrawingNmdRef_Missing");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,CMI2DrawingNmdRef_Missing,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,CMI2DrawingNmdRef_Missing,Data Set,Remigration of Part\n",cItem_Id,cRevision);fflush(output);
	}
	if(MSExcel == 1 && MSExcelNmdRef == 0)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"MSExcelNmdRef_Missing")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Remigration of Part")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"MSExcelNmdRef_Missing")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "MSExcelNmdRef_Missing");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("MSExcelNmdRef_Missing") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "MSExcelNmdRef_Missing");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,MSExcelNmdRef_Missing,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,MSExcelNmdRef_Missing,Data Set,Remigration of Part\n",cItem_Id,cRevision);fflush(output);
	}

	if(CMI2Product > 0 && CMI2AuxPart > 0 && CMI2Part > 0)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			/*if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"CMI2AuxPart_CMI2Part_Both_Present")==0)
			{
				RepExtChk = 1;
			}*/
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"CMI2AuxPart_CMI2Part_Both_Present")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "CMI2AuxPart_CMI2Part_Both_Present");
					IssueRepDt[chk].IssueCat = NULL;
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("CMI2AuxPart_CMI2Part_Both_Present") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "CMI2AuxPart_CMI2Part_Both_Present");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,CMI2AuxPart_CMI2Part_Both_Present,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,CMI2AuxPart_CMI2Part_Both_Present,Data Set,Manual Correction\n",cItem_Id,cRevision);fflush(output);
	}

	//if(ProAsm > 0 || CMI2Product > 0)
	if(ProAsm > 0)
	{
		//Check BVR Present Or Not on ItemRevTag
		int n_values_bvr=0;
		tag_t *bvr_assy_part = NULLTAG;
		ITK_CALL(ITEM_rev_list_bom_view_revs(ItemRevTag, &n_values_bvr, &bvr_assy_part));
		if(n_values_bvr < 1)
		{
			RepExtChk = 0;
			for (chk = 0; chk < issueDtCnt; ++chk)
			{
				if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"No_BVR_in_Assembly")==0)
				{
					RepExtChk = 1;
				}
			}
			if (RepExtChk == 0)
			{
				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
				IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
				sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
				IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
				IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
				IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("No_BVR_in_Assembly") *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "No_BVR_in_Assembly");
				IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Structure Manager") *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Structure Manager");
				IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
				issueDtCnt++;
				fprintf(FinalFile,"\n%s,%s,%s,%s,No_BVR_in_Assembly,Data Set,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,cRevision);fflush(FinalFile);
			}
			//fprintf(output,"%s,%s,No_BVR_in_Assembly,Structure Manager,Remigration of Part\n",cItem_Id,cRevision);fflush(output);
		}
	}
	//printf("\n\t\tChkDataSetRelation*************************End"); fflush(stdout);
}

void ChkDataSetCreoMem(tag_t* rellist_ProMem_DsgnRev)
{
	//printf("\n\t\tChkDataSetCreoMem*************************Start"); fflush(stdout);
	int n_entries = 1;
	int i=0;
	int JtNo=0;
	int j=0;
	int k=0;
	int n_genIns =0;
	tag_t tItemobj = NULLTAG;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	char *PartID = NULL;
	char *PartSequenceID = NULL;
	char *Part_Rlz_Stat = NULL;
	char *part_type = NULL;
	char *Description = NULL;
	char *object_type = NULL;
	char *Part_ProjID = NULL;
	char *Part_DesgnGrp = NULL;
	char *Revision = NULL;
	tag_t DataSet = NULLTAG;
	tag_t dataset2 = NULLTAG;
	char *inputfile=NULL;
	tag_t relation_type = NULLTAG;
	tag_t relation_type2 = NULLTAG;
	tag_t* rellist_JT = NULLTAG;
	int n_attchs_JT =0;
	tag_t* attachments = NULLTAG;
	tag_t itemrev = NULLTAG;
	int Part_Stat_Cnt = 0;
	tag_t *Part_Stat_Lst = NULLTAG;
	char * objtype=NULL;
	char * objtype1=NULL;
	char * PartRevID=NULL;
	char refname[AE_reference_size_c + 1];
	int referencenumberfound =0;
	int reftype =0;
	tag_t* refobject = NULLTAG;
	tag_t IPEMRelTag	= NULLTAG;
	tag_t* CreoGenTags = NULLTAG;
	int cnt=0;
	int ref_count_d = 0;
	tag_t* namRefObject_d = NULLTAG;
	tag_t reln_type_ProMem =NULLTAG;
	int n_attchs_ProMem = 0;
	JtNo=0;
	char *RlStatus = NULL;
	RlStatus = (char *)MEM_alloc(250);
	itemrev=*rellist_ProMem_DsgnRev;
	ITK_CALL(AOM_ask_value_string(itemrev,"item_id",&PartID));
	ITK_CALL(AOM_ask_value_string(itemrev,"item_revision_id",&PartRevID));
	int CADPresent = 0;
	int ProAsmPresent = 0;
	int ProAsmMembership = 0;
	int y=0;
	int z=0;

	tag_t ObjTypeTag = NULLTAG;
	char* ObjTypeNameProAsmMem = NULL; 

	char* ParentRevDup = (char*)MEM_alloc(sizeof(char) * 20);
	char* partentRev = NULL;
	char* partentSeq = NULL;
	strcpy(ParentRevDup,PartRevID);
	partentRev = strtok(ParentRevDup,";");
	partentSeq = strtok(NULL,";");
	
	ChkDataSetRelation(&itemrev);

	ITK_CALL(GRM_list_secondary_objects_only(itemrev,relation_type2,&cnt,&attachments));

	//Check for Double Data Set
	for(k=0;k<cnt;k++)
	{
		dataset2=attachments[k];
	
		if( AOM_ask_value_string(dataset2,"object_type",&objtype1)!=ITK_ok);
		
		
		if (tc_strcmp(objtype1,"ProAsm")==0)
		{
			ProAsmPresent = 1;
			int ref_count_d = 0;
			tag_t *namRefObject_d = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset2,&ref_count_d, &namRefObject_d));
			if(ref_count_d > 0)
			{
				CADPresent = 1;
				/// Pro Assembly member relationship
				ITK_CALL(GRM_find_relation_type("Pro2_membership",&reln_type_ProMem));
				ITK_CALL(GRM_list_secondary_objects_only(dataset2,reln_type_ProMem,&n_attchs_ProMem,&rellist_ProMem_DsgnRev));
				//printf("\n PRO ASM relation found <%d> \n",n_attchs_ProMem);fflush(stdout);
				if(n_attchs_ProMem>0)
				{
					ProAsmMembership = 1;
					int x=0;
					//Create another Loop and Check If there any Duplicate Part in CREO Membership and write in File
					char **MembershipPartArray = (char **) MEM_alloc(1000 * sizeof(char *));
					for(x=0; x < n_attchs_ProMem ; x++)
					{
						char *CreoMemPartID = NULL;
						tag_t CreoMemObj = NULLTAG;
						CreoMemObj = rellist_ProMem_DsgnRev[x];

						ITK_CALL(TCTYPE_ask_object_type(CreoMemObj, &ObjTypeTag));
						ITK_CALL(TCTYPE_ask_name2(ObjTypeTag, &ObjTypeNameProAsmMem));
						if(tc_strcmp(ObjTypeNameProAsmMem,"Design Revision")!=0)
						{
							continue;
						}

						ITK_CALL(AOM_ask_value_string(CreoMemObj,"item_id",&CreoMemPartID));
						int memArr = 0;
						int PartSearStat = 0;
						for(memArr = 0; memArr < x; memArr++)
						{
							if(tc_strcmp(MembershipPartArray[memArr],CreoMemPartID)==0)
							{
								PartSearStat = 1;
								break;
							}
						}
						if(PartSearStat == 0)
						{
							MembershipPartArray[x] = CreoMemPartID;
						}
						else
						{
							RepExtChk = 0;
							for (chk = 0; chk < issueDtCnt; ++chk)
							{
								if(tc_strcmp(IssueRepDt[chk].PartNo,PartID)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,PartRevID)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Duplicate_Revision_CREO_Membeship")==0)
								{
									RepExtChk = 1;
								}
							}
							if (RepExtChk == 0)
							{
								IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
								IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
								sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
								IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(PartID) *sizeof(char));
								tc_strcpy(IssueRepDt[issueDtCnt].PartNo, PartID);
								IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(PartRevID) *sizeof(char));
								tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, PartRevID);
								IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Duplicate_Revision_CREO_Membeship") *sizeof(char));
								tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Duplicate_Revision_CREO_Membeship");
								IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("CREO Membership") *sizeof(char));
								tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "CREO Membership");
								IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Backend Correction") *sizeof(char));
								tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Backend Correction");
								issueDtCnt++;
								fprintf(FinalFile,"\n%s,%s,%s,%s,Duplicate_Revision_CREO_Membeship,CREO Membership,",GlobalIPPart,GlobalIPRevSeq,PartID,PartRevID);fflush(FinalFile);
							}
							//fprintf(output,"%s,%s,Duplicate_Revision_CREO_Membeship,CREO Membership,Backend Correction\n",PartID,PartRevID);fflush(output);
							break;
						}
					}

					for(x=0; x < n_attchs_ProMem ; x++)
					{
						int prsntStruct = 0;
						char *CreoMemPartID = NULL;
						tag_t CreoMemObj = NULLTAG;
						CreoMemObj = rellist_ProMem_DsgnRev[x];

						ITK_CALL(TCTYPE_ask_object_type(CreoMemObj, &ObjTypeTag));
						ITK_CALL(TCTYPE_ask_name2(ObjTypeTag, &ObjTypeNameProAsmMem));
						if(tc_strcmp(ObjTypeNameProAsmMem,"Design Revision")!=0)
						{
							continue;
						}
						
						ITK_CALL(AOM_ask_value_string(CreoMemObj,"item_id",&CreoMemPartID));
						int recCreoMEM = 0;

						for (y = 0; y < TcuaCadBomSize; y++)
					    {
					    	if(tc_strcmp(PartID, tcuaCADBOMData[y].PartNo) == 0)
					    	{
					    		printf("\nCADBOM Success %s compare with %s --> Inset %s",tcuaCADBOMData[y].PartNo,PartID,CreoMemPartID);fflush(stdout);
					    		int nextPos = tcuaCADBOMData[y].chldCnt + 1;
					    		prsntStruct = 1;
					    		for (z = 0; z < nextPos; ++z)
					    		{
					    			if(tc_strcmp(CreoMemPartID, tcuaCADBOMData[y].CadBOMChild[z].ChildPartNo) == 0)
					    			{
					    				recCreoMEM = 1;
					    				break;
					    			}
					    		}
					    		if (recCreoMEM == 0)
					    		{
					    			tcuaCADBOMData[y].chldCnt = nextPos;
						    		tcuaCADBOMData[y].CadBOMChild = (CadBOMChildStruct*)MEM_realloc(tcuaCADBOMData[y].CadBOMChild, (nextPos+1) * sizeof(CadBOMChildStruct));
						    		tcuaCADBOMData[y].CadBOMChild[nextPos].ChildPartNo = (char*)MEM_alloc( tc_strlen(CreoMemPartID) *sizeof(char));
						    		tc_strcpy(tcuaCADBOMData[y].CadBOMChild[nextPos].ChildPartNo, CreoMemPartID);
					    		}
					    	}
					    }
					    if(prsntStruct == 0)
					    {
							printf("\n*********************************************CADBOM %d Mismatch-%s--> Inset %s",TcuaCadBomSize,PartID,CreoMemPartID);fflush(stdout);
						    tcuaCADBOMData[TcuaCadBomSize].PartNo = (char*)MEM_alloc( tc_strlen(PartID) *sizeof(char));
						    tcuaCADBOMData[TcuaCadBomSize].PartRev = (char*)MEM_alloc( tc_strlen(partentRev) *sizeof(char));
						    tcuaCADBOMData[TcuaCadBomSize].PartSeq = (char*)MEM_alloc( tc_strlen(partentSeq) *sizeof(char));
						    tc_strcpy(tcuaCADBOMData[TcuaCadBomSize].PartNo, PartID);
						    tc_strcpy(tcuaCADBOMData[TcuaCadBomSize].PartRev, partentRev);
						    tc_strcpy(tcuaCADBOMData[TcuaCadBomSize].PartSeq, partentSeq);
							tcuaCADBOMData[TcuaCadBomSize].chldCnt = 0;
							tcuaCADBOMData[TcuaCadBomSize].CadBOMChild = (CadBOMChildStruct*)MEM_alloc(1 * sizeof(CadBOMChildStruct));
							tcuaCADBOMData[TcuaCadBomSize].CadBOMChild[0].ChildPartNo = (char*)MEM_alloc( tc_strlen(CreoMemPartID) *sizeof(char));
							tc_strcpy(tcuaCADBOMData[TcuaCadBomSize].CadBOMChild[0].ChildPartNo, CreoMemPartID);
							TcuaCadBomSize++;
					    }
					    if(recCreoMEM == 0)
					    {
					    	//Recursive Call CADBOM Parent Part Is Not Present in Structure
							ChkDataSetCreoMem(&CreoMemObj);
					    }
					}
				}
			}
			else
			{
				tag_t tRelationFind = NULLTAG;
				int n_attchs_Genric = 0;
				tag_t *rellist_Genric = NULLTAG;
				ITK_CALL(GRM_find_relation_type("IPEM_master_dependency",&tRelationFind));
				ITK_CALL(GRM_list_secondary_objects_only(dataset2,tRelationFind,&n_attchs_Genric,&rellist_Genric));
				if(n_attchs_Genric > 0)
				{
					ProAsmMembership = 1;
					CADPresent = 1;
				}
				int x=0;
				ITK_CALL(GRM_find_relation_type("Pro2_membership",&reln_type_ProMem));
				ITK_CALL(GRM_list_secondary_objects_only(dataset2,reln_type_ProMem,&n_attchs_ProMem,&rellist_ProMem_DsgnRev));
				if(n_attchs_ProMem>0)
				{
					for(x=0; x < n_attchs_ProMem ; x++)
					{
						int prsntStruct = 0;
						char *CreoMemPartID = NULL;
						tag_t CreoMemObj = NULLTAG;
						CreoMemObj = rellist_ProMem_DsgnRev[x];
						ITK_CALL(AOM_ask_value_string(CreoMemObj,"item_id",&CreoMemPartID));
						int recCreoMEM = 0;

						for (y = 0; y < TcuaCadBomSize; y++)
					    {
					    	if(tc_strcmp(PartID, tcuaCADBOMData[y].PartNo) == 0)
					    	{
					    		printf("\nCADBOM Success %s compare with %s --> Inset %s",tcuaCADBOMData[y].PartNo,PartID,CreoMemPartID);fflush(stdout);
					    		int nextPos = tcuaCADBOMData[y].chldCnt + 1;
					    		prsntStruct = 1;
					    		for (z = 0; z < nextPos; ++z)
					    		{
					    			if(tc_strcmp(CreoMemPartID, tcuaCADBOMData[y].CadBOMChild[z].ChildPartNo) == 0)
					    			{
					    				recCreoMEM = 1;
					    				break;
					    			}
					    		}
					    		if (recCreoMEM == 0)
					    		{
					    			tcuaCADBOMData[y].chldCnt = nextPos;
						    		tcuaCADBOMData[y].CadBOMChild = (CadBOMChildStruct*)MEM_realloc(tcuaCADBOMData[y].CadBOMChild, (nextPos+1) * sizeof(CadBOMChildStruct));
						    		tcuaCADBOMData[y].CadBOMChild[nextPos].ChildPartNo = (char*)MEM_alloc( tc_strlen(CreoMemPartID) *sizeof(char));
						    		tc_strcpy(tcuaCADBOMData[y].CadBOMChild[nextPos].ChildPartNo, CreoMemPartID);
					    		}
					    	}
					    }
					    if(prsntStruct == 0)
					    {
							printf("\n*********************************************CADBOM %d Mismatch-%s--> Inset %s",TcuaCadBomSize,PartID,CreoMemPartID);fflush(stdout);
						    tcuaCADBOMData[TcuaCadBomSize].PartNo = (char*)MEM_alloc( tc_strlen(PartID) *sizeof(char));
						    tcuaCADBOMData[TcuaCadBomSize].PartRev = (char*)MEM_alloc( tc_strlen(partentRev) *sizeof(char));
						    tcuaCADBOMData[TcuaCadBomSize].PartSeq = (char*)MEM_alloc( tc_strlen(partentSeq) *sizeof(char));
						    tc_strcpy(tcuaCADBOMData[TcuaCadBomSize].PartNo, PartID);
						    tc_strcpy(tcuaCADBOMData[TcuaCadBomSize].PartRev, partentRev);
						    tc_strcpy(tcuaCADBOMData[TcuaCadBomSize].PartSeq, partentSeq);
							tcuaCADBOMData[TcuaCadBomSize].chldCnt = 0;
							tcuaCADBOMData[TcuaCadBomSize].CadBOMChild = (CadBOMChildStruct*)MEM_alloc(1 * sizeof(CadBOMChildStruct));
							tcuaCADBOMData[TcuaCadBomSize].CadBOMChild[0].ChildPartNo = (char*)MEM_alloc( tc_strlen(CreoMemPartID) *sizeof(char));
							tc_strcpy(tcuaCADBOMData[TcuaCadBomSize].CadBOMChild[0].ChildPartNo, CreoMemPartID);
							TcuaCadBomSize++;
					    }
					    /*if(recCreoMEM == 0) //CREO Assembly Instance
					    {
					    	//Recursive Call CADBOM Parent Part Is Not Present in Structure
							ChkDataSetCreoMem(&CreoMemObj);
					    }*/
					}
				}
			}
			
		}
		else if (tc_strcmp(objtype1,"ProPrt")==0)
		{
			int ref_count_d = 0;
			tag_t *namRefObject_d = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset2,&ref_count_d, &namRefObject_d));

			if(ref_count_d > 0)
			{
				CADPresent = 1;
			}
			else
			{
				printf("\n%s,%s -----------------------------------------------------------------",PartID,PartRevID);fflush(stdout);

				tag_t tRelationFind = NULLTAG;
				int n_attchs_Genric = 0;
				tag_t *rellist_Genric = NULLTAG;
				ITK_CALL(GRM_find_relation_type("IPEM_master_dependency",&tRelationFind));
				ITK_CALL(GRM_list_secondary_objects_only(dataset2,tRelationFind,&n_attchs_Genric,&rellist_Genric));
				if(n_attchs_Genric > 0)
				{
					printf("\nIn Generic");fflush(stdout);
					CADPresent = 1;
				}
			}
		}
		else if (tc_strcmp(objtype1,"ProDrw")==0 || tc_strcmp(objtype1,"CMI2Part")==0 || tc_strcmp(objtype1,"CMI2Product")==0 || tc_strcmp(objtype1,"CMI2Drawing")==0)
		{
			CADPresent = 1;
		}
	}

	//printf("\nItem ID cRevision : %s %s", PartID,PartRevID);fflush(stdout);
	if(CADPresent == 0)
	{
		printf("\nPrinting");fflush(stdout);
		//Print In file No Data Set: Status-NO DataSet
		fprintf(outputTCE,"%s,%s,No_CAD_DataSet\n",PartID,PartRevID);fflush(outputTCE);
	}
	if(ProAsmMembership == 0 && ProAsmPresent == 1 && CADPresent == 1)
	{
		//Print In file: Status-CREO Membership Missing
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			if(tc_strcmp(IssueRepDt[chk].PartNo,PartID)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,PartRevID)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Missing_CREO_Membership")==0)
			{
				RepExtChk = 1;
			}
		}
		if (RepExtChk == 0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(PartID) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, PartID);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(PartRevID) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, PartRevID);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Missing_CREO_Membership") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Missing_CREO_Membership");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("CREO Membership") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "CREO Membership");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,%s,Missing_CREO_Membership,CREO Membership,",GlobalIPPart,GlobalIPRevSeq,PartID,PartRevID);fflush(FinalFile);
		}
		//fprintf(output,"%s,%s,Missing_CREO_Membership,CREO Membership,Remigration of Part\n",PartID,PartRevID);fflush(output);
	}
	//printf("\n\t\tChkDataSetCreoMem*************************End"); fflush(stdout);
}

int getchilds(int iNumber_Child,tag_t *tBOM_Children, int RevRuleType, char* PartentPartID, char* PartentRevision, char* PartOwningUser)
{
	//printf("\n\t\tgetchilds*************************Start"); fflush(stdout);
	int k = 0;
	char* cItem_Id = NULL;
	char* cRevision =NULL;
	int count1=0;
	tag_t *sub_childs=NULL;
	char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));
	int i=0;
	int n_found=0;
	int JtNo =0;
	int AsmPrt =0;
	tag_t query = NULLTAG;
	tag_t* cntr_objects = NULLTAG;
	int entries =2;
	char *qry_entries[2]  = {"Item ID","Revision"};
	tag_t query1 = NULLTAG;
	char **qry_values1 = (char **) MEM_alloc(50 * sizeof(char *));
	int n_found1=0;
	tag_t* cntr_objects1 = NULLTAG;
	int y= 0;
	char* ParentRevDup = (char*)MEM_alloc(sizeof(char) * 20);
	char* partentRev = NULL;
	char* partentSeq = NULL;

	char *t5_DesignGrp=NULL;
	char *t5_DrawingInd=NULL;
	char *t5_DrawingNo=NULL;
	char *t5_ProjectCode=NULL;
	char *t5_MatlClass=NULL;
	char *t5_ModelIndicator=NULL;
	char *bl_quantity=NULL;
	char *t5_RevPartType=NULL;
	char *linObjType = NULL;
	char *t5_PartStatus = NULL;
	char *owninguser = NULL;
	strcpy(ParentRevDup,PartentRevision);
	partentRev = strtok(ParentRevDup,";");
	partentSeq = strtok(NULL,";");

	for(i=0;i<iNumber_Child;i++)
	{
		int prsntStruct = 0;

		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_item_item_id", &cItem_Id));
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_rev_item_revision_id", &cRevision));
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "fnd0bl_line_object_type", &linObjType));
		if(tc_strcmp(linObjType,"ItemRevision")==0)
		{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 50 *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, "---");
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Part Created as ITEM") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Part Created as ITEM");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Creation") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Creation");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Backend Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Backend Correction");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,---,Part Created as ITEM,Part Creation,",GlobalIPPart,GlobalIPRevSeq,cItem_Id);fflush(FinalFile);

			printf("Object Type Issue %s ------ItemRevision----- Hence continue",cItem_Id);
			continue;
		}
		
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_Design Revision_t5_DesignGrp", &t5_DesignGrp ));
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_Design Revision_t5_DrawingInd", &t5_DrawingInd ));
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_Design Revision_t5_DrawingNo", &t5_DrawingNo ));
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_Design Revision_t5_ProjectCode", &t5_ProjectCode ));
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_Design Revision_t5_MatlClass", &t5_MatlClass ));
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_Design Revision_t5_ModelIndicator", &t5_ModelIndicator ));
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_quantity", &bl_quantity ));
		ITK_CALL(AOM_ask_value_string(tBOM_Children[i], "bl_Design Revision_t5_PartType", &t5_RevPartType ));
		ITK_CALL(AOM_ask_value_string(tBOM_Children[i], "bl_Design Revision_t5_PartStatus", &t5_PartStatus ));
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_rev_owning_user", &owninguser ));

		/*if (tc_strstr(owninguser, "loader")!= NULL)
		{
			printf("Not Migrated Data %s ----------- Hence continue",cItem_Id);
			continue;
		}*/

		printf("\nItem ID: %s --%s-- --------- %d", cItem_Id,cRevision,RevRuleType); fflush(stdout);

		if (cRevision == NULL)
		{
			printf("No Revision %s ----------- Hence continue",cItem_Id);
			continue;
		}
		else if(tc_strstr(cRevision,";") == NULL)
		{
			/*int RepExtChk = 0;
			int chk = 0;
			for (chk = 0; chk < issueDtCnt; ++chk)
			{
				if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Sequence Missing-Need to Delete")==0)
				{
					RepExtChk = 1;
				}
			}
			if (RepExtChk == 0)
			{
			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 50 *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, "-");
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Sequence Missing-Need to Delete") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Sequence Missing-Need to Delete");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Creation") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Creation");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Frontend Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Frontend Correction");
			issueDtCnt++;
			fprintf(FinalFile,"\n%s,%s,%s,-,Sequence Missing-Need to Delete,Part Creation,",GlobalIPPart,GlobalIPRevSeq,cItem_Id);fflush(FinalFile);
			}*/
			printf("No Revision %s ----------- Hence continue",cItem_Id);
			continue;
		}
		//Strt of Rev Eff Issue
		int rev_eff_issue = 0;
		char *highRev = NULL;
		char *highSeq = NULL;
		char *rev_id = NULL;
		char* cRevisionDup = (char*)MEM_alloc(sizeof(char) * 20);
		strcpy(cRevisionDup,cRevision);
		highRev = strtok(cRevisionDup,";");
		highSeq = strtok(NULL,";");
		int highRevPos = 0;
		int r = 0;
		if(RevRuleType == 2)
		{
		for (y = 0; y < TcuaEbomSize; y++)
		{
			if(tc_strcmp(PartentPartID, tcuaEBOMData[y].PartNo) == 0)
			{
				prsntStruct = 1;
	    		int nextPos = tcuaEBOMData[y].chldCnt + 1;
	    		tcuaEBOMData[y].chldCnt = nextPos;
	    		tcuaEBOMData[y].EBOMChild = (EBOMChildStruct*)MEM_realloc(tcuaEBOMData[y].EBOMChild, (nextPos+1) * sizeof(EBOMChildStruct));

	    		tcuaEBOMData[y].EBOMChild[nextPos].ChildPartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
				tcuaEBOMData[y].EBOMChild[nextPos].ChildPartRev = (char*)MEM_alloc( tc_strlen(highRev) *sizeof(char));
				tcuaEBOMData[y].EBOMChild[nextPos].ChildPartSeq = (char*)MEM_alloc( tc_strlen(highSeq) *sizeof(char));
				if(owninguser != NULL)
				{
					tcuaEBOMData[y].EBOMChild[nextPos].owninguser = (char*)MEM_alloc( tc_strlen(owninguser) *sizeof(char));
				}
				else
				{
					tcuaEBOMData[y].EBOMChild[nextPos].owninguser = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if(t5_PartStatus != NULL)
				{
					tcuaEBOMData[y].EBOMChild[nextPos].t5PartStatus = (char*)MEM_alloc( tc_strlen(t5_PartStatus) *sizeof(char));
				}
				else
				{
					tcuaEBOMData[y].EBOMChild[nextPos].t5PartStatus = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if(t5_RevPartType != NULL)
				{
					tcuaEBOMData[y].EBOMChild[nextPos].PartType = (char*)MEM_alloc( tc_strlen(t5_RevPartType) *sizeof(char));
				}
				else
				{
					tcuaEBOMData[y].EBOMChild[nextPos].PartType = (char*)MEM_alloc( 5 *sizeof(char));
				}
				//tcuaEBOMData[y].EBOMChild[nextPos].t5PartCode = (char*)MEM_alloc( tc_strlen(t5PartCode) *sizeof(char));
				if (t5_DrawingInd != NULL)
				{
					tcuaEBOMData[y].EBOMChild[nextPos].t5DrawingInd = (char*)MEM_alloc( tc_strlen(t5_DrawingInd) *sizeof(char));
				}
				else
				{
					tcuaEBOMData[y].EBOMChild[nextPos].t5DrawingInd = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if (t5_DrawingNo != NULL)
				{
					tcuaEBOMData[y].EBOMChild[nextPos].t5DrawingNo = (char*)MEM_alloc( tc_strlen(t5_DrawingNo) *sizeof(char));
				}
				else
				{
					tcuaEBOMData[y].EBOMChild[nextPos].t5DrawingNo = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if (t5_ProjectCode != NULL)
				{
					tcuaEBOMData[y].EBOMChild[nextPos].ProjectName = (char*)MEM_alloc( tc_strlen(t5_ProjectCode) *sizeof(char));
				}
				else
				{
					tcuaEBOMData[y].EBOMChild[nextPos].ProjectName = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if (t5_DesignGrp != NULL)
				{
					tcuaEBOMData[y].EBOMChild[nextPos].Designgroup = (char*)MEM_alloc( tc_strlen(t5_DesignGrp) *sizeof(char));
				}
				else
				{
					tcuaEBOMData[y].EBOMChild[nextPos].Designgroup = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if (t5_MatlClass != NULL)
				{
					tcuaEBOMData[y].EBOMChild[nextPos].t5Material = (char*)MEM_alloc( tc_strlen(t5_MatlClass) *sizeof(char));
				}
				else
				{
					tcuaEBOMData[y].EBOMChild[nextPos].t5Material = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if (bl_quantity != NULL)
				{
					tcuaEBOMData[y].EBOMChild[nextPos].UsesPartQty = (char*)MEM_alloc( tc_strlen(bl_quantity) *sizeof(char));
				}
				else
				{
					tcuaEBOMData[y].EBOMChild[nextPos].UsesPartQty = (char*)MEM_alloc( 5 *sizeof(char));
				}

	    		tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].ChildPartNo, cItem_Id);
			    tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].ChildPartRev, highRev);
			    tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].ChildPartSeq, highSeq);
			    if(owninguser != NULL)
			    {	
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].owninguser, owninguser);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].owninguser, "NA");
			    }
			    if(t5_PartStatus != NULL)
			    {	
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].t5PartStatus, t5_PartStatus);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].t5PartStatus, "NA");
			    }
			    if(t5_RevPartType != NULL)
			    {	
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].PartType, t5_RevPartType);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].PartType, "NA");
			    }
			    //tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].t5PartCode, t5PartCode);
			    if (t5_DrawingInd != NULL)
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].t5DrawingInd, t5_DrawingInd);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].t5DrawingInd, "NA");
			    }
			    if (t5_DrawingNo != NULL)
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].t5DrawingNo, t5_DrawingNo);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].t5DrawingNo, "NA");
			    }
			    if (t5_ProjectCode != NULL)
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].ProjectName, t5_ProjectCode);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].ProjectName, "NA");
			    }
			    if (t5_DesignGrp != NULL)
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].Designgroup, t5_DesignGrp);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].Designgroup, "NA");
			    }
			    if (t5_MatlClass != NULL)
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].t5Material, t5_MatlClass);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].t5Material, "NA");
			    }
			    if (bl_quantity != NULL)
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].UsesPartQty, bl_quantity);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].UsesPartQty, "0");
			    }
			    if (tcuaEBOMData[y].EBOMChild[nextPos].UsesPartQty == NULL)
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].UsesPartQty, "0");
			    }
			    else if (tc_strcmp(tcuaEBOMData[y].EBOMChild[nextPos].UsesPartQty,"")==0 || tc_strstr(tcuaEBOMData[y].EBOMChild[nextPos].UsesPartQty,"null")!=NULL)
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].UsesPartQty, "0");
			    }
			    //printf("\nUsesPartQty Source : %s-%s",tcuaEBOMData[y].EBOMChild[nextPos].UsesPartQty,tcuaEBOMData[y].EBOMChild[nextPos].ChildPartNo); fflush(stdout);
			}
		}

		if(prsntStruct == 0)
		{
			tcuaEBOMData[TcuaEbomSize].PartNo = (char*)MEM_alloc( tc_strlen(PartentPartID) *sizeof(char));
		    tc_strcpy(tcuaEBOMData[TcuaEbomSize].PartNo, PartentPartID);
		    tcuaEBOMData[TcuaEbomSize].PartRev = (char*)MEM_alloc( tc_strlen(partentRev) *sizeof(char));
			tc_strcpy(tcuaEBOMData[TcuaEbomSize].PartRev, partentRev);
			tcuaEBOMData[TcuaEbomSize].PartSeq = (char*)MEM_alloc( tc_strlen(partentSeq) *sizeof(char));
			tc_strcpy(tcuaEBOMData[TcuaEbomSize].PartSeq, partentSeq);
			tcuaEBOMData[TcuaEbomSize].owninguser = (char*)MEM_alloc( tc_strlen(PartOwningUser) *sizeof(char));
			tc_strcpy(tcuaEBOMData[TcuaEbomSize].owninguser, PartOwningUser);
			tcuaEBOMData[TcuaEbomSize].chldCnt = 0;

			tcuaEBOMData[TcuaEbomSize].EBOMChild = (EBOMChildStruct*)MEM_alloc(1 * sizeof(EBOMChildStruct));
			tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ChildPartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ChildPartRev = (char*)MEM_alloc( tc_strlen(highRev) *sizeof(char));
			tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ChildPartSeq = (char*)MEM_alloc( tc_strlen(highSeq) *sizeof(char));
			if(owninguser != NULL)
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].owninguser = (char*)MEM_alloc( tc_strlen(owninguser) *sizeof(char));
			}
			else
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].owninguser = (char*)MEM_alloc( 5 *sizeof(char));
			}
			if(t5_PartStatus != NULL)
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5PartStatus = (char*)MEM_alloc( tc_strlen(t5_PartStatus) *sizeof(char));
			}
			else
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5PartStatus = (char*)MEM_alloc( 5 *sizeof(char));
			}
			if(t5_RevPartType != NULL)
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].PartType = (char*)MEM_alloc( tc_strlen(t5_RevPartType) *sizeof(char));
			}
			else
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].PartType = (char*)MEM_alloc( 5 *sizeof(char));
			}
			//tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5PartCode = (char*)MEM_alloc( tc_strlen(t5PartCode) *sizeof(char));
			if (t5_DrawingInd != NULL)
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5DrawingInd = (char*)MEM_alloc( tc_strlen(t5_DrawingInd) *sizeof(char));
			}
			else
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5DrawingInd = (char*)MEM_alloc( 5 *sizeof(char));
			}
			if (t5_DrawingNo != NULL)
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5DrawingNo = (char*)MEM_alloc( tc_strlen(t5_DrawingNo) *sizeof(char));
			}
			else
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5DrawingNo = (char*)MEM_alloc( 5 *sizeof(char));
			}
			if (t5_ProjectCode != NULL)
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ProjectName = (char*)MEM_alloc( tc_strlen(t5_ProjectCode) *sizeof(char));
			}
			else
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ProjectName = (char*)MEM_alloc( 5 *sizeof(char));
			}
			if (t5_DesignGrp != NULL)
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].Designgroup = (char*)MEM_alloc( tc_strlen(t5_DesignGrp) *sizeof(char));
			}
			else
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].Designgroup = (char*)MEM_alloc( 5 *sizeof(char));
			}
			if (t5_MatlClass != NULL)
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5Material = (char*)MEM_alloc( tc_strlen(t5_MatlClass) *sizeof(char));
			}
			else
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5Material = (char*)MEM_alloc( 5 *sizeof(char));
			}
			//tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5RolledupWt = (char*)MEM_alloc( tc_strlen(t5RolledupWt) *sizeof(char));
			//tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5UQdup = (char*)MEM_alloc( tc_strlen(t5UQdup) *sizeof(char));
			if (bl_quantity != NULL)
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].UsesPartQty = (char*)MEM_alloc( tc_strlen(bl_quantity) *sizeof(char));
			}
			else
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].UsesPartQty = (char*)MEM_alloc( 5 *sizeof(char));
			}

			tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ChildPartNo, cItem_Id);
		    tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ChildPartRev, highRev);
		    tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ChildPartSeq, highSeq);
		    if(owninguser != NULL)
		    {	
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].owninguser, owninguser);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].owninguser, "NA");
		    }
		    if(t5_PartStatus != NULL)
		    {	
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5PartStatus, t5_PartStatus);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5PartStatus, "NA");
		    }
		    if(t5_RevPartType != NULL)
		    {	
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].PartType, t5_RevPartType);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].PartType, "NA");
		    }
		    //tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5PartCode, t5PartCode);
		    if (t5_DrawingInd != NULL)
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5DrawingInd, t5_DrawingInd);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5DrawingInd, "NA");
		    }
		    if (t5_DrawingNo != NULL)
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5DrawingNo, t5_DrawingNo);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5DrawingNo, "NA");
		    }
		    if (t5_ProjectCode != NULL)
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ProjectName, t5_ProjectCode);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ProjectName, "NA");
		    }
		    if (t5_DesignGrp != NULL)
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].Designgroup, t5_DesignGrp);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].Designgroup, "NA");
		    }
		    if (t5_MatlClass != NULL)
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5Material, t5_MatlClass);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5Material, "NA");
		    }
		    
		    //tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5RolledupWt, t5RolledupWt);
		    //tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5UQdup, t5UQdup);

		    if (bl_quantity != NULL)
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].UsesPartQty, bl_quantity);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].UsesPartQty, "0");
		    }
		    if (tcuaEBOMData[TcuaEbomSize].EBOMChild[0].UsesPartQty == NULL)
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].UsesPartQty, "0");
		    }
		    else if (tc_strcmp(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].UsesPartQty,"")==0 || tc_strstr(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].UsesPartQty,"null")!=NULL)
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].UsesPartQty, "0");
		    }
		    //printf("\nUsesPartQty Source : %s-%s",tcuaEBOMData[TcuaEbomSize].EBOMChild[0].UsesPartQty,tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ChildPartNo); fflush(stdout);
			TcuaEbomSize++;
		}
		}
		for (r = 0; r < revision_length; r++) 
		{     
			if (tc_strcmp(highRev, revision_Order[r]) == 0) 
			{
				highRevPos = r;
				break;
			}   
		}
		//Revision Effectivity Correct Or Not (Using Lexical Analysis, NR < A < B)
		if(RevRuleType == 1)
		{
			ITK_CALL(QRY_find2("Item Revision...",&query1));
			qry_values1[0] = cItem_Id;
			char *qry_entries1[1]  = {"Item ID"};
			ITK_CALL(QRY_execute(query1, 1, qry_entries1, qry_values1, &n_found1, &cntr_objects1));
		}
		else
		{
			ITK_CALL(QRY_find2("Item Revision...",&query1));
			qry_values1[0] = cItem_Id;
			qry_values1[1] = "T5_LcsErcRlzd";
			char *qry_entries1[2]  = {"Item ID","Release Status"};
			ITK_CALL(QRY_execute(query1, 2, qry_entries1, qry_values1, &n_found1, &cntr_objects1));
		}
		char* HighRevFinal = (char*)MEM_alloc(sizeof(char) * 20);
		char* HighSeqFinal = (char*)MEM_alloc(sizeof(char) * 20);
		tc_strcpy(HighRevFinal,"");
		tc_strcpy(HighSeqFinal,"");
		int HighRevSeqPos = 0;
		for (k = 0; k < n_found1; ++k)
		{
			char *actRev = NULL;
			char *actSeq = NULL;
			int actRevPos = 0;
			ITK_CALL(AOM_UIF_ask_value (cntr_objects1[k], "item_revision_id", &rev_id));
			if(tc_strstr(rev_id,";")==NULL)
			{
				int RepExtChk = 0;
    			int chk = 0;
				for (chk = 0; chk < issueDtCnt; ++chk)
				{
					if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Sequence Missing-Need to Delete")==0)
					{
						RepExtChk = 1;
					}
				}
				if (RepExtChk == 0)
				{
				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
				IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
				sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
				IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
				IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 50 *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, "-");
				IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Sequence Missing-Need to Delete") *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Sequence Missing-Need to Delete");
				IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Creation") *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Creation");
				IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Frontend Correction") *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Frontend Correction");
				issueDtCnt++;
				fprintf(FinalFile,"\n%s,%s,%s,-,Sequence Missing-Need to Delete,Part Creation,",GlobalIPPart,GlobalIPRevSeq,cItem_Id);fflush(FinalFile);
				}
				continue;
			}
			actRev = strtok(rev_id,";");
			actSeq =strtok(NULL,";");
			for (r = 0; r < revision_length; r++) 
			{     
				if (tc_strcmp(actRev, revision_Order[r]) == 0) 
				{
					actRevPos = r;
					break;
				}
			}

			if(tc_strcmp(highRev, "NR")==0 && tc_strcmp(actRev, "NR")!=0)
			{
				rev_eff_issue = 1;
				if (actRevPos >= HighRevSeqPos)
				{
					tc_strcpy(HighRevFinal,actRev);
					tc_strcpy(HighSeqFinal,actSeq);
					HighRevSeqPos = actRevPos;
				}
			}
			else if(tc_strcmp(highRev, "NR")!=0 && tc_strcmp(actRev, "NR")==0)
			{
				continue;
			}
			else if(tc_strcmp(highRev, actRev)==0)
			{
				int highSeqInt = 0;
				int actSeqInt = 0;
				highSeqInt = atoi(highSeq);
				actSeqInt = atoi(actSeq);
				//if(tc_strcmp(highSeq, actSeq) < 0)
				if(highSeqInt < actSeqInt)
				{
					rev_eff_issue = 1;
					tc_strcpy(HighRevFinal,actRev);
					tc_strcpy(HighSeqFinal,actSeq);
					HighRevSeqPos = actRevPos;
				}
			}
			else if(highRevPos > actRevPos)
			{
				continue;
			}
			else
			{
				rev_eff_issue = 1;
				if (actRevPos >= HighRevSeqPos)
				{
					tc_strcpy(HighRevFinal,actRev);
					tc_strcpy(HighSeqFinal,actSeq);
					HighRevSeqPos = actRevPos;
				}
			}
		}
		if(rev_eff_issue == 1 && RevRuleType == 1)
		{
			RepExtChk = 0;
			char *tempCopy = NULL;
			tempCopy = (char*)MEM_alloc( 50 *sizeof(char));
			tc_strcpy(tempCopy,cRevision);
			tc_strcat(tempCopy,"->");
			tc_strcat(tempCopy,HighRevFinal);
			tc_strcat(tempCopy,";");
			tc_strcat(tempCopy,HighSeqFinal);

			for (chk = 0; chk < issueDtCnt; ++chk)
			{
				if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,tempCopy)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Rev_Eff_Issue_Latest_Working")==0)
				{
					RepExtChk = 1;
				}
			}
			if (RepExtChk == 0)
			{
				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
				IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
				sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
				IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
				IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 50 *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, tempCopy);
				IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Rev_Eff_Issue_Latest_Working") *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Rev_Eff_Issue_Latest_Working");
				IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Structure Manager") *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Structure Manager");
				IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Backend Correction") *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Backend Correction");
				issueDtCnt++;
				fprintf(FinalFile,"\n%s,%s,%s,%s,Rev_Eff_Issue_Latest_Working,Structure Manager,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,tempCopy);fflush(FinalFile);
			}
			//fprintf(output,"%s,%s->%s;%s,Rev_Eff_Issue_Latest_Working,Structure Manager,Backend Correction\n",cItem_Id,cRevision,HighRevFinal,HighSeqFinal);fflush(output);
		}
		if(rev_eff_issue == 1 && RevRuleType == 2)
		{
			RepExtChk = 0;
			char *tempCopy = NULL;
			tempCopy = (char*)MEM_alloc( 50 *sizeof(char));
			tc_strcpy(tempCopy,cRevision);
			tc_strcat(tempCopy,"->");
			tc_strcat(tempCopy,HighRevFinal);
			tc_strcat(tempCopy,";");
			tc_strcat(tempCopy,HighSeqFinal);

			for (chk = 0; chk < issueDtCnt; ++chk)
			{
				if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,tempCopy)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Rev_Eff_Issue_ERC_Release_Above")==0)
				{
					RepExtChk = 1;
				}
			}
			if (RepExtChk == 0)
			{
				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
				IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
				sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
				IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
				IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 50 *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, tempCopy);
				IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Rev_Eff_Issue_ERC_Release_Above") *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Rev_Eff_Issue_ERC_Release_Above");
				IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Structure Manager") *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Structure Manager");
				IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Backend Correction") *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Backend Correction");
				issueDtCnt++;
				fprintf(FinalFile,"\n%s,%s,%s,%s,Rev_Eff_Issue_ERC_Release_Above,Structure Manager,",GlobalIPPart,GlobalIPRevSeq,cItem_Id,tempCopy);fflush(FinalFile);
			}
			//fprintf(output,"%s,%s->%s;%s,Rev_Eff_Issue_ERC_Release_Above,Structure Manager,Backend Correction\n",cItem_Id,cRevision,HighRevFinal,HighSeqFinal);fflush(output);
		}
		//End of Rev Eff Issue
		qry_values[0] = cItem_Id;
		qry_values[1] = cRevision;
		ITK_CALL(QRY_find2("Item Revision...",&query));
		ITK_CALL(QRY_execute(query, entries, qry_entries, qry_values, &n_found, &cntr_objects));
		if(n_found>0)
		{
			ChkDataSetRelation(&cntr_objects[0]);
		}

		int bomalreadyChk = 0;
		if(RevRuleType == 2)
		{
			for (y = 0; y < TcuaEbomSize; y++)
		    {
		    	if(tc_strcmp(cItem_Id, tcuaEBOMData[y].PartNo) == 0)
		    	{
		    		bomalreadyChk = 1;
		    	}
		    }

		    if(bomalreadyChk == 0)
		    {
				BOM_line_ask_all_child_lines(tBOM_Children[i],&count1,&sub_childs);
				if(count1>0)
				{
					getchilds(count1,sub_childs,RevRuleType,cItem_Id,cRevision,owninguser);
				}
			}
		}
		else
		{
			for (y = 0; y < RvwEbomCnt; y++)
		    {
		    	if(tc_strcmp(cItem_Id, TcuaRvwEBOM[y]) == 0)
		    	{
		    		bomalreadyChk = 1;
		    	}
		    }

		    if(bomalreadyChk == 0)
		    {	
		    	BOM_line_ask_all_child_lines(tBOM_Children[i],&count1,&sub_childs);
		    	if(count1>0)
				{
					TcuaRvwEBOM[RvwEbomCnt] = cItem_Id;
					TcuaRvwEBOM++;
					getchilds(count1,sub_childs,RevRuleType,cItem_Id,cRevision,owninguser);
				}
			}
		}
	}
	//printf("\n\t\tgetchilds*************************End"); fflush(stdout);
}

int ITK_user_main(int argc, char* argv[])
{
    int iFail = 0;
    char* cError = NULL;
	char* username = NULL;
	tag_t tuser = NULLTAG;
	char *loggedInUser = NULL;
	char *message;
	//iFail = ITK_auto_login();
	//printf("\nReturn Value is : %d", iFail);fflush(stdout);
	//ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	ITK_CALL(ITK_initialize_text_services (0));
    iFail = ITK_auto_login ();
    if (iFail != ITK_ok ) 
	{
        EMH_ask_error_text(iFail, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", iFail, message);
        MEM_free(message);
        return iFail;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}

	int n_entries = 1;
	int i=0;
	int JtNo=0;
	int j=0;
	int k=0;
	int n_genIns =0;
	tag_t tItemobj = NULLTAG;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	char *PartID = NULL;
	char *PartSequenceID = NULL;
	char *Part_Rlz_Stat = NULL;
	char *part_type = NULL;
	char *Description = NULL;
	char *object_type = NULL;
	char *Part_ProjID = NULL;
	char *Part_DesgnGrp = NULL;
	char *Revision = NULL;
	tag_t DataSet = NULLTAG;
	tag_t dataset2 = NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t relation_type2 = NULLTAG;
	tag_t* rellist_JT = NULLTAG;
	int n_attchs_JT =0;
	tag_t* attachments = NULLTAG;
	tag_t itemrev = NULLTAG;
	tag_t iteamrev2 = NULLTAG;
	tag_t iteamrev3 = NULLTAG;
	tag_t DesignPart = NULLTAG;
	int Part_Stat_Cnt = 0;
	tag_t *Part_Stat_Lst = NULLTAG;
	char * objtype=NULL;
	char * objtype1=NULL;
	char * PartRevID=NULL;
	char *PartOwner = NULL;
	char refname[AE_reference_size_c + 1];
	int referencenumberfound =0;
	int reftype =0;
	tag_t* refobject = NULLTAG;
	tag_t IPEMRelTag	= NULLTAG;
	tag_t* CreoGenTags = NULLTAG;
	int cnt=0;
	int ref_count_d = 0;
	tag_t* namRefObject_d = NULLTAG;
	tag_t reln_type_ProMem =NULLTAG;
	int n_attchs_ProMem = 0;
	tag_t* rellist_ProMem_DsgnRev =NULLTAG;
	char *inputline = NULL;
	int clidExists = 0;
	int newUsgQty = 0;
	int nloop = 0;
	char *exepathdup = NULL;
		exepathdup = (char *)MEM_alloc(1000);

	tcuaEBOMData = (EBOMStruct*)MEM_alloc(5000 * sizeof(EBOMStruct));
	tcuaCADBOMData = (CadBOMStruct*)MEM_alloc(5000 * sizeof(CadBOMStruct));
	IssueRepDt = (IssueRep*)MEM_alloc(1 * sizeof(IssueRep));
	TcuaRvwEBOM = (char **) MEM_alloc(5000 * sizeof(char *));

	RepExtChkChld = (char *)MEM_alloc(2000);
	tc_strcpy(RepExtChkChld, "");

	char *inputPart=NULL;
	inputPart = ITK_ask_cli_argument("-Part=");
	char *inputRev=NULL;
	inputRev = (char *)MEM_alloc(50);
	inputRev = ITK_ask_cli_argument("-Revision=");
	char *inputSeq=NULL;
	inputSeq = (char *)MEM_alloc(50);
	inputSeq = ITK_ask_cli_argument("-Sequence=");
	char *FinalFileName=NULL;
	FinalFileName = ITK_ask_cli_argument("-f=");

	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	char Data[100] = "";
	char outputFile[200] = "";
	strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"Report_%s_%s.txt",inputPart,Data);

	char outputFileTce[200] = "";
	tc_strcpy(outputFileTce,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MigrationDataValidation_RLZ/TCEOutput");
	tc_strcat(outputFileTce,outputFile);

	char outputFileTceCheck[200] = "";
	tc_strcpy(outputFileTceCheck,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MigrationDataValidation_RLZ/TCECheck");
	tc_strcat(outputFileTceCheck,outputFile);

	char tceEBOM[200] = "";
	tc_strcpy(tceEBOM,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MigrationDataValidation_RLZ/TceEBOM");
	tc_strcat(tceEBOM,outputFile);
	char tceCADBOM[200] = "";
	tc_strcpy(tceCADBOM,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MigrationDataValidation_RLZ/TceCADBOM");
	tc_strcat(tceCADBOM,outputFile);

	outputTCE = fopen(outputFileTceCheck,"w");
	if (outputTCE == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	FinalFile = fopen(FinalFileName,"a+");
	if (FinalFile == NULL)
	{ 
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	
	char **cValues = (char **) MEM_alloc(50 * sizeof(char *));
	char *RevSeq = NULL;
	RevSeq = (char *)MEM_alloc(50);
	tc_strcpy(RevSeq,inputRev);
	tc_strcat(RevSeq,";");
	tc_strcat(RevSeq,inputSeq);
	char *cEntries[2]  = {"Item ID","Revision"};

	GlobalIPPart = (char *)MEM_alloc(150);
	GlobalIPRevSeq = (char *)MEM_alloc(50);
	tc_strcpy(GlobalIPPart, inputPart);
	tc_strcpy(GlobalIPRevSeq, RevSeq);

	printf("\n\n Input Part: %s , %s",inputPart,RevSeq); fflush(stdout);				
	cValues[0] = inputPart;
	//cValues[1] = RevSeq;
	ITK_CALL(QRY_find2("Latest Item Revision for ERC",&tItemobj));
	//ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
	ITK_CALL(QRY_execute(tItemobj, 1, cEntries, cValues, &n_itemobj_found, &titemobj_results));
	DesignPart = titemobj_results[0];
	ITK_CALL(GRM_find_relation_type("IMAN_specification",&relation_type2));
	printf("\n No of Objects: %d",n_itemobj_found); fflush(stdout);
	for(i=0;i<n_itemobj_found;i++)
	{
		char *RlStatus = NULL;
		char *PartRevIDDup = NULL;
		char *Rev1 = NULL;
		char *Seq1 = NULL;
		RlStatus = (char *)MEM_alloc(250);
		iteamrev2=titemobj_results[i];
		itemrev=titemobj_results[i];
		iteamrev3=titemobj_results[i];
		ITK_CALL(AOM_ask_value_string(itemrev,"item_id",&PartID));
		ITK_CALL(AOM_ask_value_string(itemrev,"item_revision_id",&PartRevID));
		ITK_CALL(AOM_ask_value_string(itemrev,"item_revision_id",&PartRevIDDup));
		Rev1 = tc_strtok ( PartRevIDDup,";") ;
		Seq1 = tc_strtok ( NULL,";") ;
		tc_strcpy(GlobalIPRevSeq, Rev1);
		tc_strcat(GlobalIPRevSeq,";");
		tc_strcat(GlobalIPRevSeq,Seq1);

		ITK_CALL(AOM_UIF_ask_value(itemrev,"owning_user",&PartOwner));
		if (tc_strstr(PartOwner,"loader")==NULL)
		{
			fprintf(FinalFile,"\n%s,%s,%s,%s,%s,User Modified,",GlobalIPPart,GlobalIPRevSeq,PartID,PartRevID,PartOwner);fflush(FinalFile);
			tc_strcpy(exepathdup,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MigrationDataValidation_RLZ/RemoveProcessFilesBulk.sh");
			tc_strcat(exepathdup," ");
			tc_strcat(exepathdup,outputFileTceCheck);
			tc_strcat(exepathdup," ");
			tc_strcat(exepathdup,outputFileTce);
			tc_strcat(exepathdup," ");
			tc_strcat(exepathdup,tceEBOM);
			tc_strcat(exepathdup," ");
			tc_strcat(exepathdup,tceCADBOM);
			tc_strcat(exepathdup," ");

			system(exepathdup);
			break;
		}
		//******************************************CAD BOM CHECK START********************
		ChkDataSetCreoMem(&itemrev);
		//******************************************CAD BOM CHECK END********************

		//******************************************BVR CHECK START - ERC Released and ABOVE********************
		tag_t tWindow = NULLTAG;
		tag_t rule = NULLTAG;
		tag_t tBOMLine1 = NULLTAG;
		tag_t* tBOM_Children = NULLTAG;
		int iNumber_Child = 0;
		ITK_CALL(BOM_create_window( &tWindow));
		iFail = CFM_find( "ERC release and above", &rule );
		iFail = BOM_set_window_config_rule(tWindow, rule );
		tag_t closure_tag;
		PIE_scope_t scope;
		scope=PIE_TEAMCENTER;
		int n_closure_tags;
		tag_t* closure_tags;
		ITK_CALL(PIE_find_closure_rules2("BOMViewClosureRuleERC1",scope,&n_closure_tags,&closure_tags));
		if(n_closure_tags==1)
		{
			closure_tag=closure_tags[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(tWindow,closure_tag,0,NULL,NULL));
		ITK_CALL(BOM_set_window_top_line( tWindow, tItemobj, iteamrev2, NULLTAG, &tBOMLine1));
		ITK_CALL(BOM_line_ask_all_child_lines(tBOMLine1, &iNumber_Child, &tBOM_Children));
		//printf("\n Return Value From Child Line API is --------> %d", iFail);fflush(stdout);
		//printf("\n No of Children Found ---------> %d\n",iNumber_Child);fflush(stdout);
		if(iNumber_Child>0)
        {
        	int RevRuleType = 2;
			getchilds(iNumber_Child,tBOM_Children,RevRuleType,PartID,PartRevID,PartOwner);
		}
		tBOM_Children = NULLTAG;
		ITK_CALL(BOM_close_window(tWindow));
		//printf("\n Return Value From BOM Close Window API is --------> %d", iFail);fflush(stdout);
		//******************************************BVR CHECK END - ERC Released and ABOVE********************

		//******************************************BVR CHECK START - Latest Working for ERC********************
		tag_t tWindow1 = NULLTAG;
		tag_t rule1 = NULLTAG;
		tag_t tBOMLine = NULLTAG;
		ITK_CALL(BOM_create_window( &tWindow1));
		//iFail = CFM_find( "Latest Working for ERC View", &rule1 );
		iFail = CFM_find( "Latest Working", &rule1 );
		iFail = BOM_set_window_config_rule(tWindow1, rule1 );
		tag_t closure_tag1;
		PIE_scope_t scope1;
		scope1=PIE_TEAMCENTER;
		int n_closure_tags1;
		tag_t* closure_tags1;
		ITK_CALL(PIE_find_closure_rules2("BOMViewClosureRuleERC1",scope1,&n_closure_tags1,&closure_tags1));
		if(n_closure_tags1==1)
		{
			closure_tag1=closure_tags1[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(tWindow1,closure_tag1,0,NULL,NULL));
		ITK_CALL(BOM_set_window_top_line( tWindow1, tItemobj, iteamrev3, NULLTAG, &tBOMLine));
		ITK_CALL(BOM_line_ask_all_child_lines(tBOMLine, &iNumber_Child, &tBOM_Children));
		//printf("\n Return Value From For Latest Working --------> %d", iFail);fflush(stdout);
		//printf("\n No of Children Found For Latest Working---------> %d\n",iNumber_Child);fflush(stdout);
		if(iNumber_Child>0)
        {
        	int RevRuleType = 1;
			getchilds(iNumber_Child,tBOM_Children,RevRuleType,PartID,PartRevID,PartOwner);
		}
		tBOM_Children = NULLTAG;
		ITK_CALL(BOM_close_window(tWindow1));
		//printf("\n Return Value From BOM For Latest Working --------> %d", iFail);fflush(stdout);
		//******************************************BVR CHECK START - Latest Working for ERC********************

		tc_strcpy(exepathdup,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MigrationDataValidation_RLZ/DataExistanceChk_backend.sh");
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,outputFileTceCheck);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,outputFileTce);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,inputPart);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,Rev1);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,Seq1);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,tceEBOM);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,tceCADBOM);
		
		system(exepathdup);

		EBOMStruct* tceEBOMData = (EBOMStruct*)MEM_alloc(500 * sizeof(EBOMStruct));
		int y = 0;
		int z = 0;
		FILE *TCEEbomFile = NULL;
		int EbomMainSize = 0;
		TCEEbomFile = fopen(tceEBOM,"r");
		//TCEEbomFile = fopen("EBOM.txt","r");
		if (TCEEbomFile == NULL)
		{
			printf("No Data File Check in TCE\n");
		}
		else
		{
			inputline=(char *) MEM_alloc(2000);
			while(fgets(inputline,2000,TCEEbomFile)!=NULL)
			{
				char *PartNo = NULL;
			    char *PartRev = NULL;
			    char *PartSeq = NULL;
				char *ChildPartNo = NULL;
			    char *ChildPartRev = NULL;
			    char *ChildPartSeq = NULL;
			    char *PartType = NULL;
			    char *t5PartCode = NULL;
			    char *t5DrawingInd = NULL;
			    char *t5DrawingNo = NULL;
			    char *ProjectName = NULL;
			    char *Designgroup = NULL;
			    char *t5Material = NULL;
			    char *t5RolledupWt = NULL;
			    char *t5UQdup = NULL;
			    char *UsesPartQty = NULL;
			    char *t5PartStatus = NULL;
			    int prsntStruct = 0;
			    PartNo = tc_strtok(inputline,"^");
			    PartRev = tc_strtok(NULL,"^");
			    PartSeq = tc_strtok(NULL,"^");
				ChildPartNo = tc_strtok(NULL,"^");
			    ChildPartRev = tc_strtok(NULL,"^");
			    ChildPartSeq = tc_strtok(NULL,"^");
			    PartType = tc_strtok(NULL,"^");
			    t5PartCode = tc_strtok(NULL,"^");
			    t5DrawingInd = tc_strtok(NULL,"^");
			    t5DrawingNo = tc_strtok(NULL,"^");
			    ProjectName = tc_strtok(NULL,"^");
			    Designgroup = tc_strtok(NULL,"^");
			    t5Material = tc_strtok(NULL,"^");
			    t5RolledupWt = tc_strtok(NULL,"^");
			    t5UQdup = tc_strtok(NULL,"^");
			    UsesPartQty = tc_strtok(NULL,"^");
			    t5PartStatus = tc_strtok(NULL,"^");

			    for (y = 0; y < EbomMainSize; y++)
			    {
			    	if(tc_strcmp(PartNo, tceEBOMData[y].PartNo) == 0)
			    	{
			    		printf("\nSuccess %s compare with %s --> Inset %s",tceEBOMData[y].PartNo,PartNo,ChildPartNo);fflush(stdout);
			    		prsntStruct = 1;

			    		clidExists = 0;
			    		newUsgQty = 0;
			    		nloop = 0;
			    		for (nloop = 0; nloop <= tceEBOMData[y].chldCnt ; ++nloop)
			    		{
			    			if (tc_strcmp(tceEBOMData[y].EBOMChild[nloop].ChildPartNo,ChildPartNo)==0)
			    			{
			    				clidExists = 1;
			    				newUsgQty = atoi(tceEBOMData[y].EBOMChild[nloop].UsesPartQty) + atoi(UsesPartQty);
			    				tceEBOMData[y].EBOMChild[nloop].UsesPartQty = (char*)MEM_alloc( 20 *sizeof(char));
			    				sprintf(tceEBOMData[y].EBOMChild[nloop].UsesPartQty,"%d",newUsgQty);
			    				break;
			    			}
			    		}

			    		if(clidExists == 0)
			    		{
				    		int nextPos = tceEBOMData[y].chldCnt + 1;
				    		tceEBOMData[y].chldCnt = nextPos;
				    		tceEBOMData[y].EBOMChild = (EBOMChildStruct*)MEM_realloc(tceEBOMData[y].EBOMChild, (nextPos+1) * sizeof(EBOMChildStruct));

				    		tceEBOMData[y].EBOMChild[nextPos].ChildPartNo = (char*)MEM_alloc( tc_strlen(ChildPartNo) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].ChildPartRev = (char*)MEM_alloc( tc_strlen(ChildPartRev) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].ChildPartSeq = (char*)MEM_alloc( tc_strlen(ChildPartSeq) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].PartType = (char*)MEM_alloc( tc_strlen(PartType) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].t5PartCode = (char*)MEM_alloc( tc_strlen(t5PartCode) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].t5DrawingInd = (char*)MEM_alloc( tc_strlen(t5DrawingInd) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].t5DrawingNo = (char*)MEM_alloc( tc_strlen(t5DrawingNo) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].ProjectName = (char*)MEM_alloc( tc_strlen(ProjectName) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].Designgroup = (char*)MEM_alloc( tc_strlen(Designgroup) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].t5Material = (char*)MEM_alloc( tc_strlen(t5Material) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].t5RolledupWt = (char*)MEM_alloc( tc_strlen(t5RolledupWt) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].t5UQdup = (char*)MEM_alloc( tc_strlen(t5UQdup) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].UsesPartQty = (char*)MEM_alloc( tc_strlen(UsesPartQty) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].t5PartStatus = (char*)MEM_alloc( tc_strlen(t5PartStatus) *sizeof(char));

				    		tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].ChildPartNo, ChildPartNo);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].ChildPartRev, ChildPartRev);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].ChildPartSeq, ChildPartSeq);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].PartType, PartType);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].t5PartCode, t5PartCode);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].t5DrawingInd, t5DrawingInd);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].t5DrawingNo, t5DrawingNo);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].ProjectName, ProjectName);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].Designgroup, Designgroup);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].t5Material, t5Material);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].t5RolledupWt, t5RolledupWt);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].t5UQdup, t5UQdup);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].UsesPartQty, UsesPartQty);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].t5PartStatus, t5PartStatus);
						}
			    	}
			    }
			    if(prsntStruct == 0)
			    {
			    	printf("\n********************************************* %d Mismatch-%s-%s-%s--> Inset %s",EbomMainSize,PartNo,PartRev,PartSeq,ChildPartNo);fflush(stdout);
				    tceEBOMData[EbomMainSize].PartNo = (char*)MEM_alloc( tc_strlen(PartNo) *sizeof(char));
				    tc_strcpy(tceEBOMData[EbomMainSize].PartNo, PartNo);
				    tceEBOMData[EbomMainSize].PartRev = (char*)MEM_alloc( tc_strlen(PartRev) *sizeof(char));
					tc_strcpy(tceEBOMData[EbomMainSize].PartRev, PartRev);
					tceEBOMData[EbomMainSize].PartSeq = (char*)MEM_alloc( tc_strlen(PartSeq) *sizeof(char));
					tc_strcpy(tceEBOMData[EbomMainSize].PartSeq, PartSeq);
					tceEBOMData[EbomMainSize].chldCnt = 0;

					tceEBOMData[EbomMainSize].EBOMChild = (EBOMChildStruct*)MEM_alloc(1 * sizeof(EBOMChildStruct));
					tceEBOMData[EbomMainSize].EBOMChild[0].ChildPartNo = (char*)MEM_alloc( tc_strlen(ChildPartNo) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].ChildPartRev = (char*)MEM_alloc( tc_strlen(ChildPartRev) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].ChildPartSeq = (char*)MEM_alloc( tc_strlen(ChildPartSeq) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].PartType = (char*)MEM_alloc( tc_strlen(PartType) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].t5PartCode = (char*)MEM_alloc( tc_strlen(t5PartCode) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].t5DrawingInd = (char*)MEM_alloc( tc_strlen(t5DrawingInd) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].t5DrawingNo = (char*)MEM_alloc( tc_strlen(t5DrawingNo) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].ProjectName = (char*)MEM_alloc( tc_strlen(ProjectName) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].Designgroup = (char*)MEM_alloc( tc_strlen(Designgroup) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].t5Material = (char*)MEM_alloc( tc_strlen(t5Material) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].t5RolledupWt = (char*)MEM_alloc( tc_strlen(t5RolledupWt) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].t5UQdup = (char*)MEM_alloc( tc_strlen(t5UQdup) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].UsesPartQty = (char*)MEM_alloc( tc_strlen(UsesPartQty) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].t5PartStatus = (char*)MEM_alloc( tc_strlen(t5PartStatus) *sizeof(char));

					tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].ChildPartNo, ChildPartNo);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].ChildPartRev, ChildPartRev);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].ChildPartSeq, ChildPartSeq);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].PartType, PartType);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].t5PartCode, t5PartCode);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].t5DrawingInd, t5DrawingInd);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].t5DrawingNo, t5DrawingNo);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].ProjectName, ProjectName);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].Designgroup, Designgroup);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].t5Material, t5Material);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].t5RolledupWt, t5RolledupWt);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].t5UQdup, t5UQdup);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].UsesPartQty, UsesPartQty);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].t5PartStatus, t5PartStatus);
					EbomMainSize++;
			    }
			}
			inputline = NULL;
		}
		fclose(TCEEbomFile);

		FILE *TCECadBomFile = NULL;
		CadBOMStruct* tceCADBOMData = (CadBOMStruct*)MEM_alloc(500 * sizeof(CadBOMStruct));
		int CadBomMainSize = 0;
		y = 0;
		z = 0;
		TCECadBomFile = fopen(tceCADBOM,"r");
		//TCECadBomFile = fopen("CADBOM.txt","r");
		if (TCECadBomFile == NULL)
		{
			printf("No Data File Check in TCE\n");
		}
		else
		{
			inputline=(char *) MEM_alloc(2000);
			while(fgets(inputline,2000,TCECadBomFile)!=NULL)
			{
				char *PartNo = NULL;
				char *ChildPartNo = NULL;
				int prsntStruct = 0;
				PartNo = tc_strtok(inputline,"^");
				ChildPartNo = tc_strtok(NULL,"^");

				for (y = 0; y < CadBomMainSize; y++)
			    {
			    	if(tc_strcmp(PartNo, tceCADBOMData[y].PartNo) == 0)
			    	{
			    		printf("\nCADBOM Success %s compare with %s --> Inset %s",tceCADBOMData[y].PartNo,PartNo,ChildPartNo);fflush(stdout);
			    		prsntStruct = 1;
			    		int nextPos = tceCADBOMData[y].chldCnt + 1;
			    		tceCADBOMData[y].chldCnt = nextPos;
			    		tceCADBOMData[y].CadBOMChild = (CadBOMChildStruct*)MEM_realloc(tceCADBOMData[y].CadBOMChild, (nextPos+1) * sizeof(CadBOMChildStruct));
			    		tceCADBOMData[y].CadBOMChild[nextPos].ChildPartNo = (char*)MEM_alloc( tc_strlen(ChildPartNo) *sizeof(char));
			    		tc_strcpy(tceCADBOMData[y].CadBOMChild[nextPos].ChildPartNo, ChildPartNo);
			    	}
			    }
			    if(prsntStruct == 0)
			    {
			    	printf("\n*********************************************CADBOM %d Mismatch-%s--> Inset %s",CadBomMainSize,PartNo,ChildPartNo);fflush(stdout);
				    tceCADBOMData[CadBomMainSize].PartNo = (char*)MEM_alloc( tc_strlen(PartNo) *sizeof(char));
				    tc_strcpy(tceCADBOMData[CadBomMainSize].PartNo, PartNo);
					tceCADBOMData[CadBomMainSize].chldCnt = 0;
					tceCADBOMData[CadBomMainSize].CadBOMChild = (CadBOMChildStruct*)MEM_alloc(1 * sizeof(CadBOMChildStruct));
					tceCADBOMData[CadBomMainSize].CadBOMChild[0].ChildPartNo = (char*)MEM_alloc( tc_strlen(ChildPartNo) *sizeof(char));
					tc_strcpy(tceCADBOMData[CadBomMainSize].CadBOMChild[0].ChildPartNo, ChildPartNo);
					CadBomMainSize++;
			    }
			}
			inputline = NULL;
		}
		fclose(TCECadBomFile);

		int zz=0;
		int yy=0;
		int TceTcuaMatch=0;

		int parentFoundTCE = 0;

		char **childBomNoApp = (char **) MEM_alloc(2000 * sizeof(char *));
		int nobomStrucMng = 0;
		
		if(EbomMainSize > 0)
		{
	    for (y = 0; y < TcuaEbomSize; ++y)
	    {
	    	if (tc_strstr(tcuaEBOMData[y].owninguser,"loader") == NULL)
	    	{
	    		continue;
	    	}
	    	
	    	parentFoundTCE = 0;
	    	//printf("\nTCUA EBOMPrinting Part: %s -- %s -- %s",tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev,tcuaEBOMData[y].PartSeq);fflush(stdout);
	    	for (yy = 0; yy < EbomMainSize; ++yy)
		    {
		    	//printf("\nTCE EBOMPrinting Part: %s -- %s -- %s",tceEBOMData[yy].PartNo,tceEBOMData[yy].PartRev,tceEBOMData[yy].PartSeq);fflush(stdout);
		    	if(tc_strcasecmp(tcuaEBOMData[y].PartNo, tceEBOMData[yy].PartNo)==0)
		    	{
		    		parentFoundTCE = 1;
		    		if (tc_strcmp(tcuaEBOMData[y].PartRev,tceEBOMData[yy].PartRev)!= 0 || tc_strcmp(tcuaEBOMData[y].PartSeq,tceEBOMData[yy].PartSeq)!= 0)
		    		{
		    			int RepExtChk = 0;
		    			int chk = 0;
						for (chk = 0; chk < issueDtCnt; ++chk)
						{
							if(tc_strcmp(IssueRepDt[chk].PartNo,tcuaEBOMData[y].PartNo)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Incremental Loading of Part Required")==0)
							{
								RepExtChk = 1;
							}
						}
						if (RepExtChk == 0)
						{
			    			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
							IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
							sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
							IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].PartNo) *sizeof(char));
							tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].PartNo);
							IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 50 *sizeof(char));
							sprintf(IssueRepDt[issueDtCnt].RevSeq, "TCUA: %s;%s, TCE: %s;%s",tcuaEBOMData[y].PartRev,tcuaEBOMData[y].PartSeq,tceEBOMData[yy].PartRev,tceEBOMData[yy].PartSeq);
							IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 200 *sizeof(char));
							sprintf(IssueRepDt[issueDtCnt].IssueCat, "Incremental Loading of Part Required");
							IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Migration") *sizeof(char));
							tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Migration");
							IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Incremental Data Migration") *sizeof(char));
							tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Incremental Data Migration");
							issueDtCnt++;
							fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Incremental/Delete,Part Migration,%s;%s,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev,tcuaEBOMData[y].PartSeq,tceEBOMData[yy].PartRev,tceEBOMData[yy].PartSeq);fflush(FinalFile);
			    		}
		    		}
		    		else
		    		{
			    		if (tcuaEBOMData[y].chldCnt > tceEBOMData[yy].chldCnt)
			    		{
			    			for (z = 0; z <= tcuaEBOMData[y].chldCnt; ++z)
					    	{
					    		TceTcuaMatch=0;
					    		//printf("\n\t\tTCUA Child: %s -- %s -- %s -> %s", tcuaEBOMData[y].EBOMChild[z].ChildPartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq, tcuaEBOMData[y].EBOMChild[z].UsesPartQty);fflush(stdout);
					    		for (zz = 0; zz <= tceEBOMData[yy].chldCnt; ++zz)
						    	{
						    		if (tc_strcasecmp(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tceEBOMData[yy].EBOMChild[zz].ChildPartNo)==0)
						    		{
						    			//printf("\n\t\tTCE Child: %s -- %s -- %s -> %s", tceEBOMData[yy].EBOMChild[zz].ChildPartNo, tceEBOMData[yy].EBOMChild[zz].ChildPartRev, tceEBOMData[yy].EBOMChild[zz].ChildPartSeq, tceEBOMData[yy].EBOMChild[zz].UsesPartQty);fflush(stdout);
						    			TceTcuaMatch = 1;

						    			if (tc_strstr(tcuaEBOMData[y].EBOMChild[z].owninguser,"loader") == NULL)
								    	{
								    		continue;
								    	}

								    	if (tc_strcmp(tceEBOMData[yy].EBOMChild[zz].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartRev)!= 0 || tc_strcmp(tceEBOMData[yy].EBOMChild[zz].ChildPartSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq)!= 0)
							    		{
							    			//CHECK DML
											int updRelzStatusDMLUA = 1;
											updRelzStatusDMLUA = CheckTCUADML(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											
											if (updRelzStatusDMLUA == 1)
											{
							    			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 50 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "TCUA: %s;%s, TCE: %s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].ChildPartRev,tceEBOMData[yy].EBOMChild[zz].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 200 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "Incremental Loading of Part Required");
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Migration") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Migration");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Incremental Data Migration") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Incremental Data Migration");
											issueDtCnt++;
											fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Incremental/Delete,Part Migration,%s;%s,",GlobalIPPart,GlobalIPRevSeq,tceEBOMData[yy].EBOMChild[zz].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].ChildPartRev,tceEBOMData[yy].EBOMChild[zz].ChildPartSeq);fflush(FinalFile);
											}
											continue;
							    		}
						    			
						    			//Check All Params Qty / Part Type
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].PartType,tcuaEBOMData[y].EBOMChild[z].PartType)!=0)
						    			{
						    				if ((tc_strcmp(tceEBOMData[yy].EBOMChild[zz].PartType,"CP")==0 && tc_strcmp(tcuaEBOMData[y].EBOMChild[z].PartType,"CM")==0) || (tc_strcmp(tceEBOMData[yy].EBOMChild[zz].PartType,"D")==0 && tc_strcmp(tcuaEBOMData[y].EBOMChild[z].PartType,"IM")==0))
						    				{
						    					printf("\nPart Type OK\n"); fflush(stdout);
						    				}
						    				else
						    				{
						    				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "Part Type Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].PartType,tcuaEBOMData[y].EBOMChild[z].PartType);
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Property") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Property");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
											issueDtCnt++;
						    				fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Part Type Mismatch,Part Property,%s,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].PartType,tcuaEBOMData[y].EBOMChild[z].PartType);fflush(FinalFile);
						    				}
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].t5PartStatus,tcuaEBOMData[y].EBOMChild[z].t5PartStatus)!=0)
						    			{
						    				//CHECK DML
											int updRelzStatusDMLUA = 1;
											updRelzStatusDMLUA = CheckTCUADML(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											
											if (updRelzStatusDMLUA == 1)
											{
						    				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "DR/AR Status Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].t5PartStatus,tcuaEBOMData[y].EBOMChild[z].t5PartStatus);
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Property") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Property");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
											issueDtCnt++;
						    				fprintf(FinalFile,"\n%s,%s,%s,%s;%s,DR/AR Status Mismatch,Part Property,%s,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].t5PartStatus,tcuaEBOMData[y].EBOMChild[z].t5PartStatus);fflush(FinalFile);
						    				}
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd)!=0)
						    			{
						    				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "Drawing Indicator Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd);
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Property") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Property");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
											issueDtCnt++;
						    				fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Drawing Indicator Mismatch,Part Property,%s,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd);fflush(FinalFile);
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].ProjectName,tcuaEBOMData[y].EBOMChild[z].ProjectName)!=0)
						    			{
						    				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "Project Code Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].ProjectName,tcuaEBOMData[y].EBOMChild[z].ProjectName);
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Property") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Property");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
											issueDtCnt++;
						    				fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Project Code Mismatch,Part Property,%s,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].ProjectName,tcuaEBOMData[y].EBOMChild[z].ProjectName);fflush(FinalFile);
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].Designgroup,tcuaEBOMData[y].EBOMChild[z].Designgroup)!=0)
						    			{
						    				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "Design Group Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].Designgroup,tcuaEBOMData[y].EBOMChild[z].Designgroup);
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Property") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Property");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
											issueDtCnt++;
						    				fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Design Group Mismatch,Part Property,%s,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].Designgroup,tcuaEBOMData[y].EBOMChild[z].Designgroup);fflush(FinalFile);
						    			}

						    			int tceQty = 0;
						    			int tcuaQty = 0;
						    			int isAllDigits = 1;
						    			int dig = 0;
						    			if (tceEBOMData[yy].EBOMChild[zz].UsesPartQty != NULL)
						    			{
										    for (dig = 0; tceEBOMData[yy].EBOMChild[zz].UsesPartQty[dig] != '\0'; dig++) {
										        if (!isdigit(tceEBOMData[yy].EBOMChild[zz].UsesPartQty[dig])) {
										            if (tceEBOMData[yy].EBOMChild[zz].UsesPartQty[dig] != '.')
										        	{
										        		isAllDigits = 0;
										            	break;
										        	}
										        }
										    }
										}
									    if (isAllDigits==1) {
									        tceQty = atoi(tceEBOMData[yy].EBOMChild[zz].UsesPartQty);
									    }
									    isAllDigits = 1;
									    if (tcuaEBOMData[y].EBOMChild[z].UsesPartQty != NULL)
									    {
										    for (dig = 0; tcuaEBOMData[y].EBOMChild[z].UsesPartQty[dig] != '\0'; dig++) {
										        if (!isdigit(tcuaEBOMData[y].EBOMChild[z].UsesPartQty[dig])) {
										            if (tcuaEBOMData[y].EBOMChild[z].UsesPartQty[dig] != '.')
										        	{
										        		isAllDigits = 0;
										            	break;
										        	}
										        }
										    }
										}
									    if (isAllDigits==1) {
									        tcuaQty = atoi(tcuaEBOMData[y].EBOMChild[z].UsesPartQty);
									    }

									    if (tceQty != tcuaQty)
						    			//if(atoi(tceEBOMData[yy].EBOMChild[zz].UsesPartQty) != atoi(tcuaEBOMData[y].EBOMChild[z].UsesPartQty))
						    			{
						    				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 200 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "Part Quantity Mismatch [TCE:%s | TCUA:%s] Immediate Parent: %s;%s;%s",tceEBOMData[yy].EBOMChild[zz].UsesPartQty,tcuaEBOMData[y].EBOMChild[z].UsesPartQty,tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev,tcuaEBOMData[y].PartSeq);
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Structure Manager") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Structure Manager");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
											issueDtCnt++;
						    				fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Part Quantity Mismatch,Structure Manager,%s,%s,%s;%s;%s",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].UsesPartQty,tcuaEBOMData[y].EBOMChild[z].UsesPartQty,tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev,tcuaEBOMData[y].PartSeq);fflush(FinalFile);
						    			}
						    		}
						    	}
						    	if (TceTcuaMatch == 0)
						    	{
						    		int a1=0;
						    		int a2=0;
						    		int foundInCAD = 0;
						    		for (a1 = 0; a1 < TcuaCadBomSize; ++a1)
								    {
										if(tc_strcasecmp(tcuaCADBOMData[a1].PartNo, tcuaEBOMData[y].PartNo)==0)
										{
											for (a2 = 0; a2 <= tcuaCADBOMData[a1].chldCnt; ++a2)
					    					{
					    						if (tc_strcasecmp(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaCADBOMData[a1].CadBOMChild[a2].ChildPartNo)==0)
						    					{
													foundInCAD = 1;
													break;
												}
											}
										}
										if (foundInCAD == 1)
										{
											break;
										}
									}

									if (foundInCAD == 0)
									{
										tag_t tItemobjA = NULLTAG;
										char * cEntriesA[2] = {"Item ID","Revision"};
									 	char ** cValuesA = (char ** ) MEM_alloc(50 * sizeof(char * ));
									 	char * cRevisionA = NULL;
									    cRevisionA = (char * ) MEM_alloc(50);
									    int n_itemobj_foundA = 0;
										tag_t * titemobjA_results = NULLTAG;
										tag_t itemrev = NULLTAG;
										tag_t relation_type2 = NULLTAG;
										tag_t IPEMRelTag = NULLTAG;
										tag_t dataset2 = NULLTAG;
										int n_attchs_ProMem = 0;
										tag_t* rellist_ProMem_DsgnRev = NULLTAG;
										char* AsmPart = NULL;
										ITK_CALL(GRM_find_relation_type("IMAN_specification", & relation_type2));
										ITK_CALL(GRM_find_relation_type("Pro2_membership", & IPEMRelTag));
										tc_strcpy(cRevisionA,tcuaEBOMData[y].PartRev);
								    	tc_strcat(cRevisionA,";");
								    	tc_strcat(cRevisionA,tcuaEBOMData[y].PartSeq);
								    	cValuesA[0] = tcuaEBOMData[y].PartNo;
							      		cValuesA[1] = cRevisionA;
							      		ITK_CALL(QRY_find2("Item Revision...", & tItemobjA));
								    	ITK_CALL(QRY_execute(tItemobjA, 2, cEntriesA, cValuesA, & n_itemobj_foundA, & titemobjA_results));
								    	printf("\nQuery -> %s, %s ---> %d",cValuesA[0],cValuesA[1],n_itemobj_foundA); fflush(stdout);
								    	if (n_itemobj_foundA > 0)
								    	{
								    		itemrev = titemobjA_results[0];
								    		ITK_CALL(GRM_list_secondary_objects_only(itemrev, relation_type2, & cnt, & attachments));
								    		for (k = 0; k < cnt; k++) {
							            		dataset2 = attachments[k];
							            		ITK_CALL(AOM_ask_value_string(dataset2, "object_type", & objtype1));
									            if ((tc_strcmp(objtype1, "ProAsm") == 0)) 
									            {
													ITK_CALL(GRM_list_secondary_objects_only(dataset2,IPEMRelTag,&n_attchs_ProMem,&rellist_ProMem_DsgnRev));
													if(n_attchs_ProMem>0)
													{									
														int x=0;
														for(x=0; x < n_attchs_ProMem ; x++)
														{
															ITK_CALL(AOM_ask_value_string(rellist_ProMem_DsgnRev[x],"item_id",&AsmPart));
															printf(":: %s , %s\n",AsmPart,tcuaEBOMData[y].EBOMChild[z].ChildPartNo); fflush(stdout);
															if (tc_strcmp(AsmPart,tcuaEBOMData[y].EBOMChild[z].ChildPartNo)==0)
															{
																foundInCAD = 1;
																break;
															}
														}
													}
													break;
											    }
											}
								    	}
									}

						    		//Print TCUA PART as extra
						    		if (foundInCAD == 0)
						    		{
										//CHECK DML
										int updRelzStatusDMLUA = 1;
										updRelzStatusDMLUA = CheckTCUADML(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
										if (updRelzStatusDMLUA == 1 && tc_strcmp(tcuaEBOMData[y].EBOMChild[z].PartType,"D")!=0)
										{
							    		IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
										IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
										sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
										IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].PartNo) *sizeof(char));
										tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].PartNo);
										IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
										sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].PartRev, tcuaEBOMData[y].PartSeq);
										IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
										sprintf(IssueRepDt[issueDtCnt].IssueCat, "Extra Part in TCUA Structure: %s",tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
										IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Structure Manager") *sizeof(char));
										tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Structure Manager");
										IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Frontend/Backend Correction") *sizeof(char));
										tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Frontend/Backend Correction");
										issueDtCnt++;
										fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Extra Part in TCUA Structure,Structure Manager,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev, tcuaEBOMData[y].PartSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo);fflush(FinalFile);
										}
									}
						    		//fprintf(output,"%s,%s;%s,Extra Part in TCUA Structure: %s,Structure Manager,Frontend/Backend Correction\n",tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev,tcuaEBOMData[y].PartSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo);fflush(output);
						    	}
					    	}
			    		}
			    		else if(tcuaEBOMData[y].chldCnt < tceEBOMData[yy].chldCnt)
			    		{
			    			for (zz = 0; zz <= tceEBOMData[yy].chldCnt; ++zz)
					    	{
					    		TceTcuaMatch=0;
					    		//printf("\n\t\tTCE Child: %s -- %s -- %s -> %s", tceEBOMData[yy].EBOMChild[zz].ChildPartNo, tceEBOMData[yy].EBOMChild[zz].ChildPartRev, tceEBOMData[yy].EBOMChild[zz].ChildPartSeq, tceEBOMData[yy].EBOMChild[zz].UsesPartQty);fflush(stdout);
					    		for (z = 0; z <= tcuaEBOMData[y].chldCnt; ++z)
						    	{
						    		if (tc_strcasecmp(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tceEBOMData[yy].EBOMChild[zz].ChildPartNo)==0)
						    		{
						    			//printf("\n\t\tTCUA Child: %s -- %s -- %s -> %s", tcuaEBOMData[y].EBOMChild[z].ChildPartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq, tcuaEBOMData[y].EBOMChild[z].UsesPartQty);fflush(stdout);
						    			TceTcuaMatch = 1;

						    			if (tc_strstr(tcuaEBOMData[y].EBOMChild[z].owninguser,"loader") == NULL)
								    	{
								    		continue;
								    	}

								    	if (tc_strcmp(tceEBOMData[yy].EBOMChild[zz].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartRev)!= 0 || tc_strcmp(tceEBOMData[yy].EBOMChild[zz].ChildPartSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq)!= 0)
							    		{
											//CHECK DML
											int updRelzStatusDMLUA = 1;
											updRelzStatusDMLUA = CheckTCUADML(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											if (updRelzStatusDMLUA == 1)
											{
							    			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tceEBOMData[yy].EBOMChild[zz].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tceEBOMData[yy].EBOMChild[zz].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 50 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "TCUA: %s;%s, TCE: %s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].ChildPartRev,tceEBOMData[yy].EBOMChild[zz].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 200 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "Incremental Loading of Part Required");
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Migration") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Migration");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Incremental Data Migration") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Incremental Data Migration");
											issueDtCnt++;
											fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Incremental/Delete,Part Migration,%s;%s,",GlobalIPPart,GlobalIPRevSeq,tceEBOMData[yy].EBOMChild[zz].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].ChildPartRev,tceEBOMData[yy].EBOMChild[zz].ChildPartSeq);fflush(FinalFile);
											}
											continue;
							    		}
						    			
						    			//Check All Params Qty / Part Type
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].PartType,tcuaEBOMData[y].EBOMChild[z].PartType)!=0)
						    			{
						    				if ((tc_strcmp(tceEBOMData[yy].EBOMChild[zz].PartType,"CP")==0 && tc_strcmp(tcuaEBOMData[y].EBOMChild[z].PartType,"CM")==0) || (tc_strcmp(tceEBOMData[yy].EBOMChild[zz].PartType,"D")==0 && tc_strcmp(tcuaEBOMData[y].EBOMChild[z].PartType,"IM")==0))
						    				{
						    					printf("\nPart Type OK\n"); fflush(stdout);
						    				}
						    				else
						    				{
						    				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "Part Type Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].PartType,tcuaEBOMData[y].EBOMChild[z].PartType);
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Property") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Property");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
											issueDtCnt++;
						    				fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Part Type Mismatch,Part Property,%s,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].PartType,tcuaEBOMData[y].EBOMChild[z].PartType);fflush(FinalFile);
						    				}
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].t5PartStatus,tcuaEBOMData[y].EBOMChild[z].t5PartStatus)!=0)
						    			{
						    				//CHECK DML
											int updRelzStatusDMLUA = 1;
											updRelzStatusDMLUA = CheckTCUADML(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);

											if (updRelzStatusDMLUA == 1)
											{
						    				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "DR/AR Status Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].t5PartStatus,tcuaEBOMData[y].EBOMChild[z].t5PartStatus);
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Property") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Property");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
											issueDtCnt++;
						    				fprintf(FinalFile,"\n%s,%s,%s,%s;%s,DR/AR Status Mismatch,Part Property,%s,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].t5PartStatus,tcuaEBOMData[y].EBOMChild[z].t5PartStatus);fflush(FinalFile);
						    				}
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd)!=0)
						    			{
						    				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "Drawing Indicator Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd);
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Property") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Property");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
											issueDtCnt++;
						    				fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Drawing Indicator Mismatch,Part Property,%s,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd);fflush(FinalFile);
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].ProjectName,tcuaEBOMData[y].EBOMChild[z].ProjectName)!=0)
						    			{
						    				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "Project Code Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].ProjectName,tcuaEBOMData[y].EBOMChild[z].ProjectName);
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Property") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Property");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
											issueDtCnt++;
						    				fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Project Code Mismatch,Part Property,%s,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].ProjectName,tcuaEBOMData[y].EBOMChild[z].ProjectName);fflush(FinalFile);
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].Designgroup,tcuaEBOMData[y].EBOMChild[z].Designgroup)!=0)
						    			{
						    				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "Design Group Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].Designgroup,tcuaEBOMData[y].EBOMChild[z].Designgroup);
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Property") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Property");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
											issueDtCnt++;
						    				fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Design Group Mismatch,Part Property,%s,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].Designgroup,tcuaEBOMData[y].EBOMChild[z].Designgroup);fflush(FinalFile);
						    			}
						    			int tceQty = 0;
						    			int tcuaQty = 0;
						    			int isAllDigits = 1;
						    			int dig = 0;
						    			if (tceEBOMData[yy].EBOMChild[zz].UsesPartQty != NULL)
						    			{
										    for (dig = 0; tceEBOMData[yy].EBOMChild[zz].UsesPartQty[dig] != '\0'; dig++) {
										        if (!isdigit(tceEBOMData[yy].EBOMChild[zz].UsesPartQty[dig])) {
										            if (tceEBOMData[yy].EBOMChild[zz].UsesPartQty[dig] != '.')
										        	{
										        		isAllDigits = 0;
										            	break;
										        	}
										        }
										    }
										}
									    if (isAllDigits==1) {
									        tceQty = atoi(tceEBOMData[yy].EBOMChild[zz].UsesPartQty);
									    }
									    isAllDigits = 1;
									    if (tcuaEBOMData[y].EBOMChild[z].UsesPartQty != NULL)
									    {
										    for (dig = 0; tcuaEBOMData[y].EBOMChild[z].UsesPartQty[dig] != '\0'; dig++) {
										        if (!isdigit(tcuaEBOMData[y].EBOMChild[z].UsesPartQty[dig])) {
										            if (tcuaEBOMData[y].EBOMChild[z].UsesPartQty[dig] != '.')
										        	{
										        		isAllDigits = 0;
										            	break;
										        	}
										        }
										    }
										}
									    if (isAllDigits==1) {
									        tcuaQty = atoi(tcuaEBOMData[y].EBOMChild[z].UsesPartQty);
									    }

									    if (tceQty != tcuaQty)
						    			//if(atoi(tceEBOMData[yy].EBOMChild[zz].UsesPartQty) != atoi(tcuaEBOMData[y].EBOMChild[z].UsesPartQty))
						    			{
						    				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 200 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "Part Quantity Mismatch [TCE:%s | TCUA:%s] Immediate Parent: %s;%s;%s",tceEBOMData[yy].EBOMChild[zz].UsesPartQty,tcuaEBOMData[y].EBOMChild[z].UsesPartQty,tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev,tcuaEBOMData[y].PartSeq);
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Structure Manager") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Structure Manager");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
											issueDtCnt++;
						    				fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Part Quantity Mismatch,Structure Manager,%s,%s,%s;%s;%s",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].UsesPartQty,tcuaEBOMData[y].EBOMChild[z].UsesPartQty,tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev,tcuaEBOMData[y].PartSeq);fflush(FinalFile);
						    			}
						    		}
						    	}
						    	if (TceTcuaMatch == 0)
						    	{
						    		//Print TCE PART Missing
						    		IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
									IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
									sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
									IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].PartNo) *sizeof(char));
									tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].PartNo);
									IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
									sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].PartRev, tcuaEBOMData[y].PartSeq);
									IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
									sprintf(IssueRepDt[issueDtCnt].IssueCat, "Missing Part in TCUA Structure: %s",tceEBOMData[yy].EBOMChild[zz].ChildPartNo);
									IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Structure Manager") *sizeof(char));
									tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Structure Manager");
									IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
									tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
									issueDtCnt++;
						    		fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Missing Part in TCUA Structure,Structure Manager,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev, tcuaEBOMData[y].PartSeq,tceEBOMData[yy].EBOMChild[zz].ChildPartNo);fflush(FinalFile);
						    	}
					    	}
			    		}
			    		else
			    		{
			    			//Child Count Same now Check All Params Qty / Part Type
			    			for (zz = 0; zz <= tceEBOMData[yy].chldCnt; ++zz)
					    	{
					    		//printf("\n\t\tTCE Child: %s -- %s -- %s -> %s", tceEBOMData[yy].EBOMChild[zz].ChildPartNo, tceEBOMData[yy].EBOMChild[zz].ChildPartRev, tceEBOMData[yy].EBOMChild[zz].ChildPartSeq, tceEBOMData[yy].EBOMChild[zz].UsesPartQty);fflush(stdout);
					    		for (z = 0; z <= tcuaEBOMData[y].chldCnt; ++z)
						    	{
						    		if (tc_strcasecmp(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tceEBOMData[yy].EBOMChild[zz].ChildPartNo)==0)
						    		{
						    			if (tc_strstr(tcuaEBOMData[y].EBOMChild[z].owninguser,"loader") == NULL)
								    	{
								    		continue;
								    	}
								    	if (tc_strcmp(tceEBOMData[yy].EBOMChild[zz].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartRev)!= 0 || tc_strcmp(tceEBOMData[yy].EBOMChild[zz].ChildPartSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq)!= 0)
							    		{
											//CHECK DML
											int updRelzStatusDMLUA = 1;
											updRelzStatusDMLUA = CheckTCUADML(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											if (updRelzStatusDMLUA == 1)
											{
							    			IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tceEBOMData[yy].EBOMChild[zz].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tceEBOMData[yy].EBOMChild[zz].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 50 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "TCUA: %s;%s, TCE: %s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tceEBOMData[yy].EBOMChild[zz].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 200 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "Incremental Loading of Part Required");
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Migration") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Migration");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Incremental Data Migration") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Incremental Data Migration");
											issueDtCnt++;
											fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Incremental/Delete,Part Migration,%s;%s,",GlobalIPPart,GlobalIPRevSeq,tceEBOMData[yy].EBOMChild[zz].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].ChildPartRev,tceEBOMData[yy].EBOMChild[zz].ChildPartSeq);fflush(FinalFile);
											}
											continue;
							    		}
						    			//printf("\n\t\tTCUA Child: %s -- %s -- %s -> %s", tcuaEBOMData[y].EBOMChild[z].ChildPartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq, tcuaEBOMData[y].EBOMChild[z].UsesPartQty);fflush(stdout);
						    			//Check All Params Qty / Part Type
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].PartType,tcuaEBOMData[y].EBOMChild[z].PartType)!=0)
						    			{
						    				if ((tc_strcmp(tceEBOMData[yy].EBOMChild[zz].PartType,"CP")==0 && tc_strcmp(tcuaEBOMData[y].EBOMChild[z].PartType,"CM")==0) || (tc_strcmp(tceEBOMData[yy].EBOMChild[zz].PartType,"D")==0 && tc_strcmp(tcuaEBOMData[y].EBOMChild[z].PartType,"IM")==0))
						    				{
						    					printf("\nPart Type OK\n"); fflush(stdout);
						    				}
						    				else
						    				{
						    				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "Part Type Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].PartType,tcuaEBOMData[y].EBOMChild[z].PartType);
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Property") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Property");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
											issueDtCnt++;
						    				fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Part Type Mismatch,Part Property,%s,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].PartType,tcuaEBOMData[y].EBOMChild[z].PartType);fflush(FinalFile);
						    				}
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].t5PartStatus,tcuaEBOMData[y].EBOMChild[z].t5PartStatus)!=0)
						    			{
						    				//CHECK DML
											int updRelzStatusDMLUA = 1;
											updRelzStatusDMLUA = CheckTCUADML(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											if (updRelzStatusDMLUA == 1)
											{
						    				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "DR/AR Status Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].t5PartStatus,tcuaEBOMData[y].EBOMChild[z].t5PartStatus);
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Property") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Property");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
											issueDtCnt++;
						    				fprintf(FinalFile,"\n%s,%s,%s,%s;%s,DR/AR Status Mismatch,Part Property,%s,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].t5PartStatus,tcuaEBOMData[y].EBOMChild[z].t5PartStatus);fflush(FinalFile);
						    				}
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd)!=0)
						    			{
						    				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "Drawing Indicator Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd);
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Property") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Property");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
											issueDtCnt++;
						    				fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Drawing Indicator Mismatch,Part Property,%s,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd);fflush(FinalFile);
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].ProjectName,tcuaEBOMData[y].EBOMChild[z].ProjectName)!=0)
						    			{
						    				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "Project Code Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].ProjectName,tcuaEBOMData[y].EBOMChild[z].ProjectName);
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Property") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Property");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
											issueDtCnt++;
						    				fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Project Code Mismatch,Part Property,%s,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].ProjectName,tcuaEBOMData[y].EBOMChild[z].ProjectName);fflush(FinalFile);
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].Designgroup,tcuaEBOMData[y].EBOMChild[z].Designgroup)!=0)
						    			{
						    				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "Design Group Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].Designgroup,tcuaEBOMData[y].EBOMChild[z].Designgroup);
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Property") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Property");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
											issueDtCnt++;
						    				fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Design Group Mismatch,Part Property,%s,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].Designgroup,tcuaEBOMData[y].EBOMChild[z].Designgroup);fflush(FinalFile);
						    			}
						    			int tceQty = 0;
						    			int tcuaQty = 0;
						    			int isAllDigits = 1;
						    			int dig = 0;
						    			//printf("\nUsesPartQty : %s-%s",tcuaEBOMData[y].EBOMChild[z].UsesPartQty, tceEBOMData[yy].EBOMChild[zz].UsesPartQty); fflush(stdout);
						    			if (tceEBOMData[yy].EBOMChild[zz].UsesPartQty != NULL)
						    			{
										    for (dig = 0; tceEBOMData[yy].EBOMChild[zz].UsesPartQty[dig] != '\0'; dig++) {
										        if (!isdigit(tceEBOMData[yy].EBOMChild[zz].UsesPartQty[dig])) {
										            if (tceEBOMData[yy].EBOMChild[zz].UsesPartQty[dig] != '.')
										        	{
										        		isAllDigits = 0;
										            	break;
										        	}
										        }
										    }
										}
									    if (isAllDigits==1) {
									        tceQty = atoi(tceEBOMData[yy].EBOMChild[zz].UsesPartQty);
									    }
									    isAllDigits = 1;
									    if (tcuaEBOMData[y].EBOMChild[z].UsesPartQty != NULL)
									    {
										    for (dig = 0; tcuaEBOMData[y].EBOMChild[z].UsesPartQty[dig] != '\0'; dig++) {
										        if (!isdigit(tcuaEBOMData[y].EBOMChild[z].UsesPartQty[dig])) {
										            if (tcuaEBOMData[y].EBOMChild[z].UsesPartQty[dig] != '.')
										        	{
										        		isAllDigits = 0;
										            	break;
										        	}
										        }
										    }
										}
										if (tcuaEBOMData[y].EBOMChild[z].UsesPartQty != NULL)
									    {
									    	if (tc_strcmp(tcuaEBOMData[y].EBOMChild[z].UsesPartQty,"")!=0 && tc_strstr(tcuaEBOMData[y].EBOMChild[z].UsesPartQty,"null")==NULL)
									    	{
									    		if (isAllDigits==1) {
											        tcuaQty = atoi(tcuaEBOMData[y].EBOMChild[z].UsesPartQty);
											    }
									    	}
									    }
									    if (tceQty != tcuaQty)
						    			//if(atoi(tceEBOMData[yy].EBOMChild[zz].UsesPartQty) != atoi(tcuaEBOMData[y].EBOMChild[z].UsesPartQty))
						    			{
						    				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
											IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
											IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
											IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 200 *sizeof(char));
											sprintf(IssueRepDt[issueDtCnt].IssueCat, "Part Quantity Mismatch [TCE:%s | TCUA:%s] Immediate Parent: %s;%s;%s",tceEBOMData[yy].EBOMChild[zz].UsesPartQty,tcuaEBOMData[y].EBOMChild[z].UsesPartQty,tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev,tcuaEBOMData[y].PartSeq);
											IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Structure Manager") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Structure Manager");
											IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
											tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
											issueDtCnt++;
						    				fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Part Quantity Mismatch,Structure Manager,%s,%s,%s;%s;%s",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].UsesPartQty,tcuaEBOMData[y].EBOMChild[z].UsesPartQty,tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev,tcuaEBOMData[y].PartSeq);fflush(FinalFile);
						    			}
						    		}
						    	}
					    	}
			    		}
		    		}
			    	break;
		    	}
		    }
		    if(parentFoundTCE == 0)
		    {
		    	int dataChecked = 0;
		    	for (yy = 0; yy < nobomStrucMng; ++yy)
		    	{
		    		if (tc_strcmp(childBomNoApp[yy],tcuaEBOMData[y].PartNo)==0)
		    		{
		    			dataChecked = 1;
		    		}
		    	}
		    	if (dataChecked == 0)
		    	{
					int a1=0;
		    		int a2=0;
		    		int foundInCAD = 0;
		    		for (a1 = 0; a1 < TcuaCadBomSize; ++a1)
				    {
						if(tc_strcasecmp(tcuaCADBOMData[a1].PartNo, tcuaEBOMData[y].PartNo)==0)
						{
							foundInCAD = 1;
							break;
							/*for (a2 = 0; a2 <= tcuaCADBOMData[a1].chldCnt; ++a2)
	    					{
	    						if (tc_strcasecmp(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaCADBOMData[a1].CadBOMChild[a2].ChildPartNo)==0)
		    					{
									foundInCAD = 1;
									break;
								}
							}*/
						}
						/*if (foundInCAD == 1)
						{
							break;
						}*/
					}
					if (foundInCAD == 0)
					{
						tag_t queryAlo1 = NULLTAG;
						char *newRevSeq = NULL;
						char **qry_valuesAlo1 = (char **) MEM_alloc(50 * sizeof(char *));
						int n_foundAlo1 = 0;
						tag_t* cntr_objectsAlo1 = NULLTAG;
						tag_t tagItem1 = NULLTAG;
						tag_t relation_typeAlo2 = NULLTAG;
						int cntAlo = 0;
						tag_t* attachmentsAlo = NULLTAG;
						tag_t dataSetProe = NULLTAG;
						int alo = 0;
						char *objtypeAlo = NULLTAG;
						tag_t reln_type_ProMemAlo = NULLTAG;
						int n_attchs_ProMemAlo = 0;
						tag_t* rellist_ProMem_DsgnRevAlo = NULLTAG;
						newRevSeq = (char*)MEM_alloc(sizeof(char) * 20);
						ITK_CALL(QRY_find2("Item Revision...",&queryAlo1));
						tc_strcpy(newRevSeq,tcuaEBOMData[y].PartRev);
						tc_strcat(newRevSeq,";");
						tc_strcat(newRevSeq,tcuaEBOMData[y].PartSeq);
						qry_valuesAlo1[0] = tcuaEBOMData[y].PartNo;
						qry_valuesAlo1[1] = newRevSeq;
						char *qry_entries1[2]  = {"Item ID","Revision"};
						ITK_CALL(QRY_execute(queryAlo1, 2, qry_entries1, qry_valuesAlo1, &n_foundAlo1, &cntr_objectsAlo1));
						if (n_foundAlo1 > 0)
						{
							tagItem1 = cntr_objectsAlo1[0];
							ITK_CALL(GRM_find_relation_type("IMAN_specification",&relation_typeAlo2));
							ITK_CALL(GRM_list_secondary_objects_only(tagItem1,relation_typeAlo2,&cntAlo,&attachmentsAlo));
							if (cntAlo > 0)
							{
								for (alo = 0; alo < cntAlo; ++alo)
								{
									dataSetProe = attachmentsAlo[alo];
									ITK_CALL(AOM_ask_value_string(dataSetProe,"object_type",&objtypeAlo));
									if(tc_strcmp(objtypeAlo,"ProAsm")==0)
									{
										ITK_CALL(GRM_find_relation_type("Pro2_membership",&reln_type_ProMemAlo));
										ITK_CALL(GRM_list_secondary_objects_only(dataSetProe,reln_type_ProMemAlo,&n_attchs_ProMemAlo,&rellist_ProMem_DsgnRevAlo));
										if (n_attchs_ProMemAlo > 0)
										{
											foundInCAD = 1;
											break;
										}
									}
								}
							}
						}
					}
		    		if (foundInCAD == 0)
		    		{
				    	IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
						IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
						sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
						IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaEBOMData[y].PartNo) *sizeof(char));
						tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaEBOMData[y].PartNo);
						IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
						sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaEBOMData[y].PartRev, tcuaEBOMData[y].PartSeq);
						IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 200 *sizeof(char));
						sprintf(IssueRepDt[issueDtCnt].IssueCat, "Part has Structure in UA but not in TCE : Need to Delete Complete BVR/Structure");
						IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Structure Manager") *sizeof(char));
						tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Structure Manager");
						IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
						tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
						issueDtCnt++;
						fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Part has Structure in UA but not in TCE : Need to Delete Complete BVR/Structure,Structure Manager,",GlobalIPPart,GlobalIPRevSeq,tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev, tcuaEBOMData[y].PartSeq);fflush(FinalFile);
					}
				}
				for (yy = 0; yy <= tcuaEBOMData[y].chldCnt; ++yy)
		    	{
		    		dataChecked = 0;
		    		for (zz = 0; zz < nobomStrucMng; ++zz)
		    		{
		    			if (tc_strcmp(childBomNoApp[zz],tcuaEBOMData[y].EBOMChild[yy].ChildPartNo)==0)
			    		{
			    			dataChecked = 1;
			    		}
		    		}
		    		if (dataChecked == 0)
		    		{
		    			childBomNoApp[nobomStrucMng] = tcuaEBOMData[y].EBOMChild[yy].ChildPartNo;
		    			nobomStrucMng++;
		    		}
		    	}
		    }
	    }
		}
		else
		{
			printf("\nTCE Service Not Available : %d",EbomMainSize); fflush(stdout);
		}

		if(CadBomMainSize > 0)
		{
	    for (y = 0; y < TcuaCadBomSize; ++y)
	    {
	    	//printf("\nTCUA CADBOM Printing Parent Part: %s",tcuaCADBOMData[y].PartNo);fflush(stdout);
	    	for (yy = 0; yy < CadBomMainSize; ++yy)
		    {
		    	if (tc_strlen(tcuaCADBOMData[y].PartNo) <= tc_strlen(tceCADBOMData[yy].PartNo))
		    	{
		    	if(tc_strncasecmp(tceCADBOMData[yy].PartNo, tcuaCADBOMData[y].PartNo, tc_strlen(tcuaCADBOMData[y].PartNo)) == 0)
		    	{
		    		if (tcuaCADBOMData[y].chldCnt > tceCADBOMData[yy].chldCnt)
		    		{
		    			for (z = 0; z <= tcuaCADBOMData[y].chldCnt; ++z)
				    	{
				    		TceTcuaMatch=0;
				    		//printf("\n\t\tTCUA CADBOM Child: %s", tcuaCADBOMData[y].CadBOMChild[z].ChildPartNo);fflush(stdout);
				    		for (zz = 0; zz <= tceCADBOMData[yy].chldCnt; ++zz)
					    	{
					    		if (tc_strlen(tcuaCADBOMData[y].CadBOMChild[z].ChildPartNo) <= tc_strlen(tceCADBOMData[yy].CadBOMChild[zz].ChildPartNo))
					    		{
					    		if(tc_strncasecmp(tceCADBOMData[yy].CadBOMChild[zz].ChildPartNo, tcuaCADBOMData[y].CadBOMChild[z].ChildPartNo, tc_strlen(tcuaCADBOMData[y].CadBOMChild[z].ChildPartNo)) == 0)
					    		{
					    			TceTcuaMatch=1;
					    			break;
					    		}
					    		}
					    	}
					    	if (TceTcuaMatch == 0)
					    	{
					    		//Print TCUA PART as extra
					    		IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
								IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
								sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
								IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaCADBOMData[y].PartNo) *sizeof(char));
								tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaCADBOMData[y].PartNo);
								IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
								sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaCADBOMData[y].PartRev, tcuaCADBOMData[y].PartSeq);
								IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
								sprintf(IssueRepDt[issueDtCnt].IssueCat, "Extra Part in CREO Membership: %s",tcuaCADBOMData[y].CadBOMChild[z].ChildPartNo);
								IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("CREO Membership") *sizeof(char));
								tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "CREO Membership");
								IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Frontend/Backend Correction") *sizeof(char));
								tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Frontend/Backend Correction");
								issueDtCnt++;
					    		fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Extra Part in CREO Membership,CREO Membership,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaCADBOMData[y].PartNo,tcuaCADBOMData[y].PartRev, tcuaCADBOMData[y].PartSeq,tcuaCADBOMData[y].CadBOMChild[z].ChildPartNo);fflush(FinalFile);
					    	}
				    	}
		    		}
		    		if (tcuaCADBOMData[y].chldCnt < tceCADBOMData[yy].chldCnt)
		    		{
		    			for (z = 0; z <= tceCADBOMData[yy].chldCnt; ++z)
				    	{
		    				TceTcuaMatch=0;
		    				for (zz = 0; zz <= tcuaCADBOMData[y].chldCnt; ++zz)
					    	{
					    		if (tc_strlen(tcuaCADBOMData[y].CadBOMChild[zz].ChildPartNo) <= tc_strlen(tceCADBOMData[yy].CadBOMChild[z].ChildPartNo))
					    		{
					    		if(tc_strncasecmp(tceCADBOMData[yy].CadBOMChild[z].ChildPartNo, tcuaCADBOMData[y].CadBOMChild[zz].ChildPartNo, tc_strlen(tcuaCADBOMData[y].CadBOMChild[zz].ChildPartNo)) == 0)
					    		{
					    			TceTcuaMatch=1;
					    			break;
					    		}
					    		}
					    	}
					    	if (TceTcuaMatch == 0)
					    	{
					    		//Print TCE PART Missing
					    		IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
								IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
								sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
								IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(tcuaCADBOMData[y].PartNo) *sizeof(char));
								tc_strcpy(IssueRepDt[issueDtCnt].PartNo, tcuaCADBOMData[y].PartNo);
								IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 20 *sizeof(char));
								sprintf(IssueRepDt[issueDtCnt].RevSeq, "%s;%s",tcuaCADBOMData[y].PartRev, tcuaCADBOMData[y].PartSeq);
								IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( 100 *sizeof(char));
								sprintf(IssueRepDt[issueDtCnt].IssueCat, "Missing Part in CREO Membership: %s",tceCADBOMData[yy].CadBOMChild[z].ChildPartNo);
								IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("CREO Membership") *sizeof(char));
								tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "CREO Membership");
								IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
								tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
								issueDtCnt++;
								fprintf(FinalFile,"\n%s,%s,%s,%s;%s,Missing Part in CREO Membership,CREO Membership,%s,",GlobalIPPart,GlobalIPRevSeq,tcuaCADBOMData[y].PartNo,tcuaCADBOMData[y].PartRev, tcuaCADBOMData[y].PartSeq,tceCADBOMData[yy].CadBOMChild[z].ChildPartNo);fflush(FinalFile);
					    	}
		    			}
		    		}
		    		break;
		    	}
		    	}
		    }
	    }
		}
		else
		{
			printf("\nTCE Service Not Available : %d",CadBomMainSize); fflush(stdout);
		}
		FILE *TCEOpChk = NULL;
		TCEOpChk = fopen(outputFileTce,"r");
		if (TCEOpChk == NULL)
		{
			printf("No Data File Check in TCE\n");
		}
		else
		{
			inputline=(char *) MEM_alloc(1000);
			while(fgets(inputline,1000,TCEOpChk)!=NULL)
			{
				char *TmpItemID = NULL;
				char *TmpRevSeq = NULL;
				char *TmpIssType = NULL;
				TmpItemID = tc_strtok(inputline,",");
				TmpRevSeq = tc_strtok(NULL,",");
				TmpIssType = tc_strtok(NULL,",");

				IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
				IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
				sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
				IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(TmpItemID) *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].PartNo, TmpItemID);
				IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(TmpRevSeq) *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, TmpRevSeq);
				IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen(TmpIssType) *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, TmpIssType);
				IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
				IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Remigration of Part") *sizeof(char));
				tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Remigration of Part");
				issueDtCnt++;
				fprintf(FinalFile,"\n%s,%s,%s,%s,%s,Data Set,",GlobalIPPart,GlobalIPRevSeq,TmpItemID,TmpRevSeq,TmpIssType);fflush(FinalFile);
			}
		}
		fclose(TCEOpChk);

		printf("\n\n\n\nPrinting Final Data"); fflush(stdout);

		if (issueDtCnt == 0)
		{
			fprintf(FinalFile,"\n%s,%s,No Issue Found,",GlobalIPPart,GlobalIPRevSeq);fflush(FinalFile);
		}

		/*char *FPartIssueDup = NULL;
		FPartIssueDup=(char *) MEM_alloc(2000);
		tc_strcpy(FPartIssueDup,"");

		char *tmpString = NULL;
		tmpString=(char *) MEM_alloc(2000);
		char *SaveReportFileName = NULL;
		SaveReportFileName=(char *) MEM_alloc(200);
		char *SaveReportFileLoc = NULL;
		SaveReportFileLoc=(char *) MEM_alloc(200);
		char *dataSetName 		= NULL;
		dataSetName=(char *) MEM_alloc(200);
		strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
		sprintf(SaveReportFileName,"Report_%s_%s.csv",inputPart,Data);
		sprintf(SaveReportFileLoc,"/tmp/Report_%s_%s.xls",inputPart,Data);
		sprintf(dataSetName,"Report_%s_%s",inputPart,Data);

		FILE *Report = NULL;
		char *XMLFileName = NULL;
		XMLFileName=(char *) MEM_alloc(200);
		sprintf(XMLFileName,"/tmp/Report_%s_%s.xml",inputPart,Data);
		//Report=fopen("/tmp/MigrationValidationReport.xml","w");
		Report=fopen(XMLFileName,"w");
		if (Report == NULL)
		{
			printf("ERROR: XML Cannot open File\n");
			return -1;
		}
		strftime(Data,100,"%d-%m-%Y %H:%M:%S",&when);
		write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		write2xml(Report,"\n<PLMXML date=\"");
		write2xml(Report,Data);
		write2xml(Report,"\" PartNo=\"");
		write2xml(Report,inputPart);
		write2xml(Report,"\" RevSeq=\"");
		write2xml(Report,RevSeq);
		write2xml(Report,"\" >\n");

		if (issueDtCnt == 0)
		{
			write2xml(Report,"<DesignRevision>\n");
			write2xml(Report,"<field key =\"slNo\">");
			write2xml(Report,"---");
			write2xml(Report,"</field>\n");
			write2xml(Report,"<field key =\"item_id\">");
			write2xml(Report,"---");
			write2xml(Report,"</field>\n");
			write2xml(Report,"<field key =\"rev_seq\">");
			write2xml(Report,"---");
			write2xml(Report,"</field>\n");
			write2xml(Report,"<field key =\"issue_cat\">");
			write2xml(Report,"Status: OK");
			write2xml(Report,"</field>\n");
			write2xml(Report,"<field key =\"issue_type\">");
			write2xml(Report,"No Exception Found");
			write2xml(Report,"</field>\n");
			write2xml(Report,"<field key =\"sol_type\">");
			write2xml(Report,"---");
			write2xml(Report,"</field>\n");
			write2xml(Report,"</DesignRevision>\n");

			ITK_CALL(AOM_load(DesignPart));
			ITK_CALL(AOM_refresh(DesignPart,1));
			ITK_CALL(AOM_set_value_string(DesignPart,"t5_ErcIndName","0"));
			ITK_CALL(AOM_save(DesignPart));
		}
		else
		{
			ITK_CALL(AOM_load(DesignPart));
			ITK_CALL(AOM_refresh(DesignPart,1));
			ITK_CALL(AOM_set_value_string(DesignPart,"t5_ErcIndName","1"));
			ITK_CALL(AOM_save(DesignPart));

			printf("Total Issue: %d",issueDtCnt);fflush(stdout);
			for (y = 0; y < issueDtCnt; ++y)
		    {
		    	printf("\n-----------------------%s-%s-%s-%s-%s-%s",IssueRepDt[y].cnt,IssueRepDt[y].PartNo,IssueRepDt[y].RevSeq,IssueRepDt[y].IssueCat,IssueRepDt[y].IssueDesc,IssueRepDt[y].SuggSol);fflush(stdout);
		    	tc_strcpy(FPartIssueDup,IssueRepDt[y].IssueCat);
		    	if(tc_strstr(FPartIssueDup,"JT_Not_Available") != NULL)
		    	{
		    		STRNG_replace_str(FPartIssueDup,"JT_Not_Available","JT Dataset Not Available",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
		    	}
		    	if(tc_strstr(FPartIssueDup,"Multi_JT") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_JT","Multiple JT Dataset Present- Need to Delete",&tmpString);
					tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"JT_NamedRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"JT_NamedRef_Missing","Named Reference missing on JT Dataset",&tmpString);
					tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"PDF_Not_Available") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"PDF_Not_Available","PDF Dataset Not Available",&tmpString);
					tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"Multi_PDF") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_PDF","Multiple PDF Dataset Present- Need to Delete",&tmpString);
					tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"PDF_NamedRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"PDF_NamedRef_Missing","Named Reference missing on PDF Dataset",&tmpString);
					tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"NamedRef_Not_CSV_WELD_Report") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"NamedRef_Not_CSV_WELD_Report","Named Reference of WELD_Report is not .csv",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"No_NamedRef_WELD_Report") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"No_NamedRef_WELD_Report","Named Reference missing on WELD_Report",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"CMI2Drawing_In_IMAN_reference") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"CMI2Drawing_In_IMAN_reference","CATIA Drawing Relation Error, in IMAN_reference Relationship",&tmpString);
					tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"ProDrw_In_IMAN_reference") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"ProDrw_In_IMAN_reference","PROE Drawing Relation Error, in IMAN_reference Relationship",&tmpString);
					tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"No_CAD_DataSet") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"No_CAD_DataSet","CAD Dataset Not Available",&tmpString);
					tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"Drawing_Not_Available") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Drawing_Not_Available","Drawing Dataset Not Available",&tmpString);
					tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"Multi_ProAsm") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_ProAsm","Multiple PROE Assembly Dataset Present- Need to Delete",&tmpString);
					tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"Multi_ProPrt") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_ProPrt","Multiple PROE Part Dataset Present- Need to Delete",&tmpString);
					tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"Multi_ProDrw") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_ProDrw","Multiple PROE Drawing Dataset Present- Need to Delete",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"Multi_CMI2CacheCgr") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_CMI2CacheCgr","Multiple CMI2CacheCgr Dataset Present- Need to Delete",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"Multi_CMI2AuxPart") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_CMI2AuxPart","Multiple CMI2AuxPart Dataset Present- Need to Delete",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"Multi_CMI2Part") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_CMI2Part","Multiple CATIA Part Dataset Present- Need to Delete",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"Multi_CMI2Product") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_CMI2Product","Multiple CATIA Product Dataset Present- Need to Delete",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"Multi_CMI2Drawing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_CMI2Drawing","Multiple CATIA Drawing Dataset Present- Need to Delete",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"Multi_MSExcel") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_MSExcel","Multiple MSExcel Dataset Present- Need to Delete",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"ProAsm_NamedRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"ProAsm_NamedRef_Missing","Named Reference missing on PROE Assembly Dataset",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"ProPrt_NamedRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"ProPrt_NamedRef_Missing","Named Reference missing on PROE Part Dataset",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"ProDrwNmdRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"ProDrwNmdRef_Missing","Named Reference missing on PROE Drawing Dataset",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"CMI2CacheCgrNmdRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"CMI2CacheCgrNmdRef_Missing","Named Reference missing on CMI2CacheCgr Dataset",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"CMI2AuxPartNmdRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"CMI2AuxPartNmdRef_Missing","Named Reference missing on CMI2AuxPart Dataset",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"CMI2PartNmdRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"CMI2PartNmdRef_Missing","Named Reference missing on CATIA Part Dataset",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"CMI2ProductNmdRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"CMI2ProductNmdRef_Missing","Named Reference missing on CATIA Product Dataset",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"CMI2DrawingNmdRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"CMI2DrawingNmdRef_Missing","Named Reference missing on CATIA Drawing Dataset",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"MSExcelNmdRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"MSExcelNmdRef_Missing","Named Reference missing on MSExcel Dataset",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"CMI2AuxPart_CMI2Part_Both_Present") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"CMI2AuxPart_CMI2Part_Both_Present","Need to delete CMI2Part (CATIA Part), as CMI2Product (CATIA Product) and CMI2AuxPart both Present",&tmpString);
					tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"No_BVR_in_Assembly") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"No_BVR_in_Assembly","No BVR on Assembly",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"Duplicate_Revision_CREO_Membeship") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Duplicate_Revision_CREO_Membeship","Duplicate Design Revisions on CREO Membership",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"Missing_CREO_Membership") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Missing_CREO_Membership","Missing CREO Membership",&tmpString);
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"Rev_Eff_Issue_Latest_Working") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Rev_Eff_Issue_Latest_Working","Date Issue in Latest Working for ERC View (Structure Manager)",&tmpString);
					tc_strcpy(FPartIssueDup,tmpString);
				}
				if(tc_strstr(FPartIssueDup,"Rev_Eff_Issue_ERC_Release_Above") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Rev_Eff_Issue_ERC_Release_Above","Date Issue in ERC Released and Above View (Structure Manager)",&tmpString);
					tc_strcpy(FPartIssueDup,tmpString);
				}
				
				write2xml(Report,"<DesignRevision>\n");
				write2xml(Report,"<field key =\"slNo\">");
				write2xml(Report,IssueRepDt[y].cnt);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"item_id\">");
				write2xml(Report,IssueRepDt[y].PartNo);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"rev_seq\">");
				write2xml(Report,IssueRepDt[y].RevSeq);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"issue_cat\">");
				write2xml(Report,IssueRepDt[y].IssueDesc);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"issue_type\">");
				write2xml(Report,FPartIssueDup);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"sol_type\">");
				write2xml(Report,IssueRepDt[y].SuggSol);
				write2xml(Report,"</field>\n");
				write2xml(Report,"</DesignRevision>\n");
		    }
		}

	    write2xml(Report,"</PLMXML>\n");
		fclose(Report);

		int result = ITK_ok;
		result = applyXSLTTransformation(XMLFileName, "/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MigrationDataValidation_RLZ/Migrated_Data_Validation.xsl", SaveReportFileLoc);
		if (result != ITK_ok) {
	        printf("\nError in Generation\n"); fflush(stdout);
	        return -1;
	    }

		IMF_file_t	fileDescriptor;
		tag_t	datasettype = NULLTAG;
		tag_t	tool 		= NULLTAG;
		tag_t	Newdataset 	= NULLTAG;
		tag_t	filetag 	= NULLTAG;
		ITK_CALL(AE_find_datasettype2("MSExcel",&datasettype));
		ITK_CALL(AE_find_tool2("MSExcel", &tool));
		ITK_CALL(AE_create_dataset_with_id(datasettype,dataSetName,"",NULL,NULL,&Newdataset));
		ITK_CALL(AE_set_dataset_tool(Newdataset,tool));
		ITK_CALL(AE_set_dataset_format2(Newdataset,"BINARY_REF"));
		ITK_CALL(AOM_save(Newdataset));
		ITK_CALL(IMF_fmsfile_import(SaveReportFileLoc,SaveReportFileName,SS_BINARY,&filetag,&fileDescriptor));
		if(filetag == NULLTAG)
		{
			printf(" File Tag Not Found..!!\n");fflush(stdout);
			return -1;
		}
		ITK_CALL(AOM_refresh(Newdataset,TRUE));
		ITK_CALL(AE_add_dataset_named_ref2(Newdataset, "excel", AE_PART_OF, filetag));
		ITK_CALL(AOM_save(Newdataset));
		ITK_CALL(AOM_refresh(Newdataset,FALSE));

		tag_t Attachrelation_type = NULLTAG;
		tag_t Fndrelation = NULLTAG;
		tag_t SetRelation = NULLTAG;
		ITK_CALL(GRM_find_relation_type("TC_Attaches",&Attachrelation_type));
		ITK_CALL(GRM_find_relation( DesignPart, Newdataset, Attachrelation_type ,&Fndrelation));
		if(Fndrelation == NULLTAG)
		{
			ITK_CALL(GRM_create_relation(DesignPart, Newdataset, Attachrelation_type, NULLTAG, &SetRelation));
			printf("\n\t TC_Attaches GRM_create_relation");fflush(stdout);
			ITK_CALL(GRM_save_relation(SetRelation));
			printf("\n\t TC_Attaches GRM_save_relation\n");fflush(stdout);
		}*/

		tc_strcpy(exepathdup,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_MigrationDataValidation_RLZ/RemoveProcessFilesBulk.sh");
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,outputFileTceCheck);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,outputFileTce);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,tceEBOM);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,tceCADBOM);
		tc_strcat(exepathdup," ");

		system(exepathdup);

		/*FPartIssueDup = NULL;
		tmpString = NULL;
		SaveReportFileName = NULL;
		SaveReportFileLoc = NULL;
		XMLFileName = NULL;*/
	}
	printf("\n=============================================================================");fflush(stdout);

	RepExtChkChld = NULL;
	iFail = ITK_exit_module(TRUE);
	printf("\nReturn Value is : %d", iFail);
	if (iFail == ITK_ok)
	{
		printf("\nTeamcenter Logout Success...");fflush(stdout);
	}
	else
	{
		EMH_ask_error_text(iFail, &cError);
		printf("\nError is : %s", cError);fflush(stdout);
	}
	return ITK_ok;
}


