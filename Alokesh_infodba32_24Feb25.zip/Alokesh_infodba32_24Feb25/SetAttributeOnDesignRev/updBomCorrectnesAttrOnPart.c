/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Rupali Rane
*  Module               :   Populate properties on DesignRevision
*  Code                 :   update_props.c
*  Created on			:   23/02/2022
*  Usage 				:	update_props -u=<user> -pf=<password> -g=<group> -inputfile=<File with Item,Props> {[-update=latest_rev_only]|[-update=all_revs]}
*
*  InputFile format		:	First line should contain all the Real Names of properties. Always start with item_id. Ex: item_id^t5_PartType
*							Item Revisions should be enlisted with the properties to updated
*							Use caret symbol (^) as a separator between properties
*							Use comma (,) for array properties
*  Caution				:	Please ensure that the property names in first line match  with the property values in second line and onwards
*							GRM Relation properties are not supported
*
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <tccore/releasestatus.h>
#include <fclasses/tc_string.h>
#include <user_exits/user_exits.h>
#include <tccore/item_errors.h>
#include <tcinit/tcinit.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

const char *drOrder[] = {"NA", "DR0", "DR1", "DR2", "DR3", "DR3P", "DR4", "DR4P", "DR5", "AR0", "AR1", "AR2", "AR3", "AR3P", "AR4", "AR4P", "AR5"};

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
    }
	return return_code;
}

void printHelp()
{
	printf("\n-----------------------------------\n");
	printf("\t\tHELP\n");
	printf("\t\tupdate_props -u=<username> -p=<password> -g=<group> -inputfile=<Full path of file with Item Ids and Properties> {[-update=latest_rev_only]|[-update=all_revs]}\n");
	printf("\n-----------------------------------\n");
}

int addStatus (tag_t,char*);
int ITK_user_main(int argc, char* argv[])
{
	int ifail=ITK_ok;
	int i=0,j=0,k=0,propNo=0,propStart=0, statusExist=0, statusNo;
	double dNumber=0.0;
	float fNumber=0.0f;
	
	char* user=NULL;
	char* passwd=NULL;
	char* group=NULL;
	char* inputFile=NULL;
	char* usecase=NULL;
	char* itemProp=NULL;	
	char* tcProp=NULL;
	char* strToken=NULL;
	char* doubEndPtr;
	char* tcProperties[130];
	char* itemProperties[500];
	char* propTypeName;
	char* propValTypeName;
	char* exstatusName;
	char fLine[5000];
	char propFLine[500];
	char tmlRevId[20];
	char* CntrlName=(char *) MEM_alloc(250); 
	
	logical propModifiable;

	tag_t itemRev_t=NULLTAG, item_t=NULLTAG;
	tag_t relStatus=NULLTAG;
	tag_t *exRelStatus=NULLTAG;

	FILE *inFptr;

	PROP_type_t propType;
	PROP_value_type_t propValueType;

	if(argc!=6)
	{
		printHelp();
		return ITK_ok;
	}

	ITK_CALL(ITK_initialize_text_services(ITK_BATCH_TEXT_MODE));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));


	user=ITK_ask_cli_argument("-u=");
	passwd=ITK_ask_cli_argument("-p=");
	group=ITK_ask_cli_argument("-g=");
	inputFile=ITK_ask_cli_argument("-inputfile=");
	
	//usecase=ITK_ask_cli_argument("-update=");

	printf("\n user: %s   inputFile: [%s] \n",user,inputFile); fflush(stdout);

	usecase =(char *) MEM_alloc(20 * sizeof(char *));
	tc_strcpy(usecase,"all_revs");

	//printf(usecase);
	inFptr=fopen(inputFile,"r");

	if(inFptr==NULL)
	{
		printf("Failed to open inputfile. Please ensure the inputfile path exists\n"); fflush(stdout);
		return ITK_ok;
	}

	//if(TC_init_module(user,passwd,group)==ITK_ok)
	//{
		if(!feof(inFptr))
		{
			fgets(propFLine, sizeof fLine, inFptr);
			
			propFLine[strcspn(propFLine,"\r\n")]=0;
			
			tcProp=tc_strtok(propFLine,"~");
			
			while(tcProp)
			{
				tcProperties[propNo]=tcProp;
				tcProp=tc_strtok(NULL,"~");
				//printf("%s\n",tcProperties[propNo]);
				propNo++;
			}
		}
		while(fgets(fLine,sizeof fLine,inFptr)!=NULL && !feof( inFptr ))
		{
			if(tc_strcmp(usecase,"latest_rev_only")==0)
			{
				fLine[strcspn(fLine,"\r\n")]=0;
				itemProp=tc_strtok(fLine,"~");
				itemProperties[0]=itemProp;
				for(i=1;i<propNo;i++)
				{
					itemProperties[i]=tc_strtok(NULL,"~");
					//printf("%s\n",itemProperties[i]);
				}
				ITK_CALL(ITEM_find_item(itemProperties[0],&item_t));
				if(item_t)
				{
					ITK_CALL(ITEM_ask_latest_rev(item_t,&itemRev_t));
					propStart=1;
				}
				else
				{
					printf("Could not find Item %s\n",itemProperties[0]); fflush(stdout);
					//continue;
				}
			}
			else if(tc_strcmp(usecase,"all_revs")==0)
			{
				fLine[strcspn(fLine,"\r\n")]=0;
				itemProp=tc_strtok(fLine,"~");
				itemProperties[0]=itemProp;
				for(i=1;i<propNo;i++)
				{
					itemProperties[i]=tc_strtok(NULL,"~");
				}
				tc_strcpy(tmlRevId,"");
				tc_strcat(tmlRevId,itemProperties[1]);
				tc_strcat(tmlRevId,";");
				tc_strcat(tmlRevId,itemProperties[2]);
				ITK_CALL(ITEM_find_rev(itemProperties[0],tmlRevId,&itemRev_t));
				propStart=3;
			}
			
			if(itemRev_t!=NULLTAG)
			{
				printf("\n Revision Tag itemRev_t found for [%s] \n",itemProp); fflush(stdout);

				ITK_CALL(AOM_load(itemRev_t));
				for(i=propStart;i<propNo;i++)
				{
					if(tc_strlen(itemProperties[i])>0)
					{
						printf("Current Property being populated %s\n",tcProperties[i]); fflush(stdout);
						ITK_CALL(AOM_ask_property_type(itemRev_t,tcProperties[i],&propType,&propTypeName));
						switch (propType)
						{
							case PROP_attribute:
								{
									ITK_CALL(AOM_ask_value_type(itemRev_t,tcProperties[i],&propValueType,&propValTypeName));
									switch (propValueType)
										{
											case PROP_string:
												{
													printf("\n ---PROP_string--- \n"); fflush(stdout);
													ITK_CALL(AOM_is_modifiable(itemRev_t,tcProperties[i],&propModifiable));
													if(propModifiable)
													{
														if (tc_strcmp(tcProperties[i],"object_desc")==0)
														{
															tag_t itemMaster = NULLTAG;
															char* itemRevID = NULL;
															ITK_CALL(AOM_ask_value_string(itemRev_t,"item_id",&itemRevID));
															const char *attrs[1];
															const char *values[1];
															int MasterFnd = 0;
															tag_t* tags_found = NULLTAG;
															attrs[0] ="item_id";
															values[0] = (char *)itemRevID ;
															ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &MasterFnd, &tags_found));
															itemMaster=tags_found[0];

															ITK_CALL(AOM_lock(itemMaster));
															ITK_CALL(AOM_set_value_string(itemMaster,"object_desc",itemProperties[i]));
															ITK_CALL(AOM_save_without_extensions(itemMaster));
															ITK_CALL(AOM_unlock(itemMaster));
														}
														else if (tc_strcmp(tcProperties[i],"t5_PartStatus")==0)
														{
															//CHECK DML For DR
															int n_tskfund = 0;
															int *levelsaa;
															tag_t *referencers = NULLTAG;
															char **relations	=  NULL;
															int task = 0;
															tag_t tsk_dml_rel_type = NULLTAG;
															int dmlcnt = 0;
															tag_t *DMLRev = NULLTAG;
															char* DmlType = NULL;
															char* dmlNo = NULL ;
															char* dmlRelStat = NULL;
															int updDRStat = 1;
															int k = 0;
															char* CurName = NULL;
															ITKCALL(WSOM_where_referenced2((const tag_t)itemRev_t,(const int)1,&n_tskfund,&levelsaa,&referencers,&relations));
															printf("\nNo of Reference Found : %d",n_tskfund);fflush(stdout);

															if(n_tskfund>0)
															{
																for(task=0;task<n_tskfund;task++)
																{
																	ITK_CALL(AOM_UIF_ask_value(referencers[task], "current_name", &CurName));
																	if (tc_strcmp(CurName,"Parts For Gate Maturation")==0)
																	{
																		int n_tskfund1 = 0;
																		int *levelsaa1;
																		tag_t *referencers1 = NULLTAG;
																		char **relations1	=  NULL;
																		int task1=0;
																		ITK_CALL(WSOM_where_referenced2((const tag_t)referencers[task],(const int)1,&n_tskfund1,&levelsaa1,&referencers1,&relations1));
																		if(n_tskfund1>0)
																		{
																			for(task1=0;task1<n_tskfund1;task1++)
																			{
																				ITK_CALL(AOM_UIF_ask_value(referencers1[task1], "current_name", &CurName));
																				//printf("\nCurrent Name: %s - %s",CurName,relations[task1]); fflush(stdout);
																				ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
																				ITK_CALL(GRM_list_primary_objects_only(referencers1[task1],tsk_dml_rel_type,&dmlcnt,&DMLRev));
																				//printf("\nNo of DML found : %d",dmlcnt);fflush(stdout);
																				DmlType = NULL;
																				dmlNo = NULL ;
																				dmlRelStat = NULL;
																				for(k=0;k<dmlcnt;k++)
																				{
																					ITK_CALL(AOM_ask_value_string(DMLRev[k],"object_type",&DmlType));
																					ITK_CALL(AOM_ask_value_string(DMLRev[k],"item_id",&dmlNo));
																					ITK_CALL(AOM_UIF_ask_value(DMLRev[k],"release_status_list",&dmlRelStat));
																					//printf("\n DML number, DmlType %s,%s",dmlNo,DmlType,dmlRelStat);
																					if (tc_strstr(dmlRelStat,"ERC Released")!=NULL)
																					{
																						printf("\nDR Update Skipped. Part Released with DML: %s - %s",dmlNo, DmlType); fflush(stdout);
																						updDRStat = 0;
																						break;
																					}
																				}
																				if (updDRStat ==0)
																				{
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
																		ITKCALL(GRM_list_primary_objects_only(referencers[task],tsk_dml_rel_type,&dmlcnt,&DMLRev));
																		printf("\nNo of DML found : %d",dmlcnt);fflush(stdout);
																		DmlType = NULL;
																		dmlNo = NULL ;
																		dmlRelStat = NULL;
																		for(k=0;k<dmlcnt;k++)
																		{
																			ITKCALL(AOM_ask_value_string(DMLRev[k],"object_type",&DmlType));
																			ITKCALL(AOM_ask_value_string(DMLRev[k],"item_id",&dmlNo));
																			ITKCALL(AOM_UIF_ask_value(DMLRev[k],"release_status_list",&dmlRelStat));
																			printf("\n DML number, DmlType %s,%s",dmlNo,DmlType,dmlRelStat);
																			if (tc_strstr(dmlRelStat,"ERC Released")!=NULL)
																			{
																				printf("\nDR Update Skipped. Part Released with DML: %s - %s",dmlNo, DmlType); fflush(stdout);
																				updDRStat = 0;
																				break;
																			}
																		}
																	}
																	if (updDRStat ==0)
																	{
																		break;
																	}
																}
															}

															char *CurrentDRStaus = NULL;
															int currentDRVal = 0;
															int newDRVal = 0;
															int r = 0;
															ITK_CALL(AOM_ask_value_string(itemRev_t,"t5_PartStatus",&CurrentDRStaus));

															if (CurrentDRStaus != NULL)
															{
																if (tc_strcmp(CurrentDRStaus, "NA")==0 || tc_strcmp(CurrentDRStaus, "DR0")==0 || tc_strcmp(CurrentDRStaus, "")==0 || tc_strcmp(CurrentDRStaus, " ")==0)
																{
																	updDRStat = 1;
																}
																else
																{
																	for (r = 0; r < 17; r++) 
																	{
																		if (tc_strcasecmp(CurrentDRStaus, drOrder[r]) == 0)
																		{
																			currentDRVal = r;
																			break;
																		}
																	}
																	for (r = 0; r < 17; r++) 
																	{
																		if (tc_strcasecmp(itemProperties[i], drOrder[r]) == 0)
																		{
																			newDRVal = r;
																			break;
																		}
																	}
																	if (currentDRVal < newDRVal)
																	{
																		updDRStat = 1;
																	}
																	else
																	{
																		updDRStat = 0;
																	}
																}
															}
															else
															{
																updDRStat = 1;
															}

															if (updDRStat == 1)
															{
																printf("\nProceed for DR Update"); fflush(stdout);
															}
															else
															{
																printf("\nOLD:%s | NEW:%s |Part Linked with ERC Release DML / Having Higher or Equal DR, DR Update not allowed.",CurrentDRStaus,itemProperties[i]); fflush(stdout);
																continue;
															}
														}

														ITK_CALL(AOM_load(itemRev_t));
														ITK_CALL(AOM_refresh(itemRev_t,1));

														if (ifail =(AOM_set_value_string(itemRev_t,tcProperties[i],itemProperties[i])) != ITK_ok)
														{
															printf("\nERROR : NOT IN LOV %s \n",tcProperties[i]); fflush(stdout);
														}
														else
														{
															printf("\nSUCCESS\n"); fflush(stdout);
															ITK_CALL(AOM_save_without_extensions(itemRev_t));
														}
														ITK_CALL(AOM_refresh(itemRev_t,0));
													}
													break;
												}
											case PROP_logical:
												{
													printf("\n ---PROP_logical--- \n"); fflush(stdout);
													ITK_CALL(AOM_is_modifiable(itemRev_t,tcProperties[i],&propModifiable));
													if(propModifiable)
													{
														if(tc_strcasecmp(itemProperties[i],"true")==0)
														{
															ITK_CALL(AOM_load(itemRev_t));
															ITK_CALL(AOM_refresh(itemRev_t,1));
															ITK_CALL(AOM_set_value_logical(itemRev_t,tcProperties[i],true));
															ITK_CALL(AOM_save_without_extensions(itemRev_t));
															ITK_CALL(AOM_refresh(itemRev_t,0));
														}
														else
														{
															ITK_CALL(AOM_load(itemRev_t));
															ITK_CALL(AOM_refresh(itemRev_t,1));
															ITK_CALL(AOM_set_value_logical(itemRev_t,tcProperties[i],false));
															ITK_CALL(AOM_save_without_extensions(itemRev_t));
															ITK_CALL(AOM_refresh(itemRev_t,0));
														}
													}
													break;
												}
											case PROP_int:
												{
													printf("\n ---PROP_int--- \n"); fflush(stdout);
													ITK_CALL(AOM_is_modifiable(itemRev_t,tcProperties[i],&propModifiable));
													if(propModifiable)
													{
														k=atoi(itemProperties[i]);
														
														ITK_CALL(AOM_load(itemRev_t));
														ITK_CALL(AOM_refresh(itemRev_t,1));
														ITK_CALL(AOM_set_value_int(itemRev_t,tcProperties[i],k));
														ITK_CALL(AOM_save_without_extensions(itemRev_t));
														ITK_CALL(AOM_refresh(itemRev_t,0));
													}
												}
											case PROP_double:
												{
													printf("\n ---PROP_double--- \n"); fflush(stdout);
													ITK_CALL(AOM_is_modifiable(itemRev_t,tcProperties[i],&propModifiable));
													if(propModifiable)
													{
														dNumber=strtod(itemProperties[i],&doubEndPtr);
														ITK_CALL(AOM_load(itemRev_t));
														ITK_CALL(AOM_refresh(itemRev_t,1));
														ITK_CALL(AOM_set_value_double(itemRev_t,tcProperties[i],dNumber));
														ITK_CALL(AOM_save_without_extensions(itemRev_t));
														ITK_CALL(AOM_refresh(itemRev_t,0));
													}
												}
											case PROP_float: //All decimal values are double in TC
												{
													printf("\n ---PROP_float--- \n"); fflush(stdout);
													ITK_CALL(AOM_is_modifiable(itemRev_t,tcProperties[i],&propModifiable));
													if(propModifiable)
													{
														//fNumber=atof(itemProperties[i]);
														dNumber=strtod(itemProperties[i],&doubEndPtr);

														ITK_CALL(AOM_load(itemRev_t));
														ITK_CALL(AOM_refresh(itemRev_t,1));
														//ITK_CALL(AOM_set_value_double(itemRev_t,tcProperties[i],fNumber));
														ITK_CALL(AOM_set_value_double(itemRev_t,tcProperties[i],dNumber));
														ITK_CALL(AOM_save_without_extensions(itemRev_t));
														ITK_CALL(AOM_refresh(itemRev_t,0));
													}
												}
											default:
												{
													//printf("\n The property type for %s is not handled by this utility\n",tcProperties[i]); fflush(stdout);
													printf("\n The property type for %s is handled by this utility\n",tcProperties[i]); fflush(stdout);
													break;
												}
										}
									break;

								}

							case PROP_reference:
								{
									if(tc_strcmp(tcProperties[i],"release_status_list")==0)
									{
										ITK_CALL(AOM_ask_value_tags(itemRev_t,tcProperties[i],&statusNo,&exRelStatus));
										if(tc_strstr(itemProperties[i],","))
										{
											strToken=tc_strtok(itemProperties[i],",");
											while(strToken)
											{
												statusExist=0;
												if(statusNo>0)
												{
													for(k=0;k<statusNo;k++)
													{
														ITK_CALL(AOM_ask_value_string(exRelStatus[k],"object_name", &exstatusName));
														if(tc_strcmp(strToken,exstatusName)==0)
														{
															statusExist=1;
															TC_write_syslog("INFO : %s Status already exists. Skipping status addition\n",exstatusName);
															printf("INFO : %s Status already exists. Skipping status addition \n",exstatusName); fflush(stdout);
														}
													}
												}
												if(statusExist==0)
												{
													addStatus(itemRev_t,strToken);
												}
												strToken=tc_strtok(NULL,",");
											}
										}
										else
										{
											strToken=itemProperties[i];
											statusExist=0;
											if(statusNo>0)
											{
												for(k=0;k<statusNo;k++)
												{
													ITK_CALL(AOM_ask_value_string(exRelStatus[k],"object_name", &exstatusName));
													if(tc_strcmp(strToken,exstatusName)==0)
													{
														statusExist=1;
														TC_write_syslog("INFO : %d Status already exists. Skipping status addition\n",exstatusName);
														printf("INFO : %d Status already exists. Skipping status addition\n",exstatusName);
														 fflush(stdout);
													}
												}
											}
											if(statusExist==0)
											{
												addStatus(itemRev_t,strToken);
											}
										}
									}
									break;
								}
						}
					}
				}
				if(tc_strcmp(usecase,"latest_rev_only")==0) printf("%s values updated\n",itemProperties[0]); fflush(stdout);
				if(tc_strcmp(usecase,"all_revs")==0) printf("%s/%s values updated\n",itemProperties[0],tmlRevId); fflush(stdout);
			}
			else
			{
				printf("%s revision could not be found\n",itemProperties[0]); fflush(stdout);
			}
		}
	//}

	printf("\n Execution is completed........\n"); fflush(stdout);

	ITK_exit_module(true);
	return ITK_ok;
}

int addStatus(tag_t ItemRev_t,char* newStatusName)
{
	tag_t relStatus=NULLTAG;
	ITK_CALL(RELSTAT_create_release_status(newStatusName,&relStatus));
	ITK_CALL(RELSTAT_add_release_status(relStatus,1,&ItemRev_t,false));
	return ITK_ok;
}
