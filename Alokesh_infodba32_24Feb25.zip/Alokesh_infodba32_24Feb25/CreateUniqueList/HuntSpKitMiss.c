/* Copyright (c) 2021 Tata Technologies Limited (TTL). All Rights
 *Reserved.
 *
 *This software is the confidential and proprietary information of TTL.
 *You shall not disclose such confidential information and shall use it
 *only in accordance with the terms of the license agreement.
 *
 *File                  :   TCUAHangCADUpload.c
 *Author                :   Alokesh Ghosh
 *Created On   		 	:   10-Feb-2024
 *Module       		 	:	
 *Purpose      		 	:   
 *Modify                :

ProDpnd^-^-^-^11323910407^-^-^-^hex_screw_is1364.prt.8^plmpuvfs^/proj/omfcadhwvault/HNJ_WIP_Vault_Loc/hex_screw_is1364.prt.8^
ProDpnd^-^-^-^11341512303^hex_fl_screw_ts17130^A^1^hex_fl_screw_ts17130.prt.29^plmpuvfs^/proj/omfcadrvault/Rel_CAD/hex_fl_screw_ts17130.prt.29^
CREO Generic/Instance --->>>> Test1 (Success)
ProDpnd->Parent/Instance>>Part,Rev,Seq,DispName,  Generic>>Part,Rev,Seq,DispName,Host,relPath,

ProAsmMem^550742100237^B^2^550742100237.asm.6^plmpuvfs^/plm/REL/Vloc/5507/42/550742100237_B_2/550742100237.asm.6^-^-^-^263242103403.prt.2^plmpuvfs^/proj/omfcadrvault/Rel_CAD/263242103403.prt.2^
ProAsmMem^550742100238^B^2^550742100238.asm.7^plmpuvfs^/plm/REL/Vloc/5507/42/550742100238_B_2/550742100238.asm.7^-^-^-^263242103403.prt.2^plmpuvfs^/proj/omfcadrvault/Rel_CAD/263242103403.prt.2^
CREO Membership --->>>> Test2 (Success)
ProAsmMem->Parent>>Part,Rev,Seq,DispName,Host,relPath,  Child>>Part,Rev,Seq,DispName,Host,relPath,

ProAsmMemIns^550742100238^B^2^550742100238.asm.7^plmpuvfs^/plm/REL/Vloc/5507/42/550742100238_B_2/550742100238.asm.7^-^-^-^13150609288^split_pin_is549^NR^1^SPLIT_PIN_IS549^plmpuvfs^/proj/omfcadrvault/Rel_CAD/split_pin_is549.prt.3^
ProAsmMemIns^550746000061^E^4^550746000061.asm.53^plmpapp1c0^/plm/REL/Vloc/5507/46/550746000061_E_4/550746000061.asm.53^-^-^-^12080996029^-^-^-^HEX_THIN_NUT_IS13724^plmpuvfs^/proj/omfcadrvault/Rel_CAD/hex_thin_nut_is13724.prt.1^
CREO Membership --->>>> Test1 (Success)
ProAsmMemIns->Parent>>Part,Rev,Seq,DispName,Host,relPath,  Child-Instance>>Part,Rev,Seq,DispName, Child-Instance>Generic>>Part,Rev,Seq,DispName,,Host,relPath,

CREO Membership
ProAsmInsMem->Parent>>InstnaceName,GenericName,Part,Rev,Seq,GenericDispNm,Host,relPath,  Child>>InstnaceName,GenericName,Part,Rev,Seq,GenericDispNm,Host,relPath,

 ***************************************************************************/

#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>
#include <time.h>

#define ITK_err 910001
int iFail = 0;
int ITK_CALL(int iFail)
{
	char* cError = NULL;
	
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);fflush(stdout);
		  exit(0);
		}

		return iFail;
}


FILE  *output = NULL;

int ITK_user_main(int argc, char* argv[])
{
    int ifail = 0;
    char* cError = NULL;
	char* username = NULL;
	tag_t tuser = NULLTAG;
	iFail = ITK_auto_login();
	printf("\nReturn Value is : %d", iFail);fflush(stdout);
	int n_entries = 2;
	int i,j,k,l,m,n,cnt;
	tag_t tItemobj = NULLTAG;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	char *PartID = NULL;
	char *PartIDMaster = NULL;
	char *PartRevSeq =NULL;
	char *PartSequenceID = NULL;
	char *part_type = NULL;
	char *QuantityAttrId = NULL;
	char *Description = NULL;
	char *object_type = NULL;
	char *Part_ProjID = NULL;
	char *Part_DesgnGrp = NULL;
	char *Revision = NULL;
	tag_t DataSet = NULLTAG;
	char *inputfile=NULL;
	char * objtype1=NULL;
	tag_t* attachments =NULLTAG;
	tag_t* cntr_objects = NULLTAG;
	int iRev_Count = 0;
	tag_t* tRevList = NULLTAG;
	tag_t tWindow1 = NULLTAG;
	tag_t tBOMLine = NULLTAG;
	tag_t child_item=NULLTAG;
	tag_t child_rev=NULLTAG;
	char* cLevel = NULL;
	char* cRev_Name = NULL;
	char* cItem_Id = NULL;
	char* cRevision = NULL;
	char* cPartType = NULL;
	char* cSuppressInd = NULL;
	char* cParent = NULL;
	char* cOwn_Group = NULL;
	char* cOwn_User = NULL;
	char* cQuantity = NULL;
	char* cFind_No = NULL;
	char* cPacked = NULL;
	char* cDRAR = NULL;
	char* cPart_Type = NULL;
	tag_t rule = NULLTAG;
	tag_t rule1 = NULLTAG;
	
	tag_t dataset2 = NULLTAG;
	tag_t relation_type2 =NULLTAG;
	tag_t reln_type_ProMem =NULLTAG;
	int n_attchs_ProMem = 0;
	tag_t* rellist_ProMem_DsgnRev =NULLTAG;	
	int temp1 =0,z=0;
	int p = 0;
	int iNumber_Child = 0;
	char*   refnamePdf = NULL;
	char*   orig_Asmname = NULL;
	AE_reference_type_t     reftype;
	tag_t	refobject	=	NULLTAG;
	char *PartOwner = NULL;
	char *start_limit = NULL;
	char *end_limit = NULL;
	/*start_limit = ITK_ask_cli_argument("-s=");
	end_limit = ITK_ask_cli_argument("-e=");
	int strtl = 0;
	int endl = 0;
	int tot_asm_parts=0;
	if (start_limit != NULL)
	{
		if (tc_strcmp(start_limit,"")!=0)
		{
			strtl = atoi(start_limit);
		}
	}
	if (end_limit != NULL)
	{
		if (tc_strcmp(end_limit,"")!=0)
		{
			endl = atoi(end_limit);
		}
	}*/
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	char Data[100] = "";
	char outputFile[200] = "";
	strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"SPKitMissing_%s.txt",Data);		
	output = fopen(outputFile,"w");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
					
	char *cEntries[2]  = {"Item ID","Type"};
	char *inputline = NULL;
	char **cValues = (char **) MEM_alloc(50 * sizeof(char *));
	if (iFail == ITK_ok)
	{
		printf("\nTeamcenter Login Success...");fflush(stdout);
		POM_get_user(&username, &tuser);
		printf("\nUsername = %s", username);fflush(stdout);
	}
	else
	{
		EMH_ask_error_text(iFail, &cError);
		printf("\nError is : %s", cError);fflush(stdout);
	}
	if (cError)
	{
		MEM_free(cError);
	}
	if (username)
	{
		MEM_free(username);
	}
	tag_t itemrev = NULLTAG;
	char *posFileNm = (char*)MEM_alloc(250 * sizeof(char));
	tag_t iteamrev2 = NULLTAG;

	cEntries[0] ="object_type";
	cEntries[1] ="owning_user";
	cValues[0] = "Design";
	cValues[1] = "*loader*";

	ITK_CALL(ITEM_find_items_by_key_attributes(2, (const char **)cEntries, (const char **)cValues, &n_itemobj_found, &titemobj_results));
	printf("\n itemobj_found: %d",n_itemobj_found); fflush(stdout);

	/*if (endl > n_itemobj_found || endl==0)
	{
		endl = n_itemobj_found;
	}
	if (strtl > n_itemobj_found)
	{
		printf("\n Start Limit Greater than Total Data"); fflush(stdout);
		return ITK_ok;
	}*/
	
	//for(j=strtl;j<endl;j++)
	for(j=0;j<n_itemobj_found;j++)
	{
		int ktsCNT = 0;
		tag_t spKitRel = NULLTAG;
		logical	SpareInd1	= false;
		tag_t* rellist = NULL;
		ITK_CALL(ITEM_ask_latest_rev(titemobj_results[j],&itemrev));
		ITK_CALL(AOM_ask_value_logical(itemrev,"t5_SpareInd", &SpareInd1));
		if( SpareInd1==1 )
		{
			ITK_CALL(GRM_find_relation_type("T5_HasSpareKit",&spKitRel));
			ITK_CALL(GRM_list_secondary_objects_only(itemrev,spKitRel,&ktsCNT,&rellist));
			if (ktsCNT < 1)
			{
				ITK_CALL(AOM_ask_value_string(itemrev,"item_id",&PartID));
				ITK_CALL(AOM_ask_value_string(itemrev,"item_revision_id",&PartRevSeq));
				ITK_CALL(AOM_UIF_ask_value(itemrev,"owning_user",&PartOwner));
				fprintf(output,"%s,%s,%s,\n",PartID,PartRevSeq,PartOwner);fflush(output);
			}
		}
	}

	iFail = ITK_exit_module(TRUE);
	printf("\nReturn Value is : %d", iFail);
	if (iFail == ITK_ok)
	{
		printf("\nTeamcenter Logout Success...");fflush(stdout);
	}
	else
	{
		EMH_ask_error_text(iFail, &cError);
		printf("\nError is : %s", cError);fflush(stdout);
	}		
	fclose(output);
	return ITK_ok;
}
