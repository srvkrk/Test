/* Copyright (c) 2021 Tata Technologies Limited (TTL). All Rights
 *Reserved.
 *
 *This software is the confidential and proprietary information of TTL.
 *You shall not disclose such confidential information and shall use it
 *only in accordance with the terms of the license agreement.
 *
 *File                  :   
 *Author                :   
 *Created On   		 	:   
 *Module       		 	:	
 *Purpose      		 	:   
 *Modify                :

 ***************************************************************************/

#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>
#include <time.h>

#define ITK_err 910001
int iFail = 0;
int ITK_CALL(int iFail)
{
	char* cError = NULL;
	
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);fflush(stdout);
		  exit(0);
		}

		return iFail;
}


FILE  *output = NULL;

int ITK_user_main(int argc, char* argv[])
{
    int ifail = 0;
    char* cError = NULL;
	char* username = NULL;
	tag_t tuser = NULLTAG;
	iFail = ITK_auto_login();
	printf("\nReturn Value is : %d", iFail);fflush(stdout);
	if (iFail == ITK_ok)
	{
		printf("\nTeamcenter Login Success...");fflush(stdout);
		POM_get_user(&username, &tuser);
		printf("\nUsername = %s", username);fflush(stdout);
	}
	else
	{
		EMH_ask_error_text(iFail, &cError);
		printf("\nError is : %s", cError);fflush(stdout);
	}
	if (cError)
	{
		MEM_free(cError);
	}
	if (username)
	{
		MEM_free(username);
	}

	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	char Data[100] = "";
	char outputFile[200] = "";
	strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"SearchOP_%s.txt",Data);		
	output = fopen(outputFile,"w");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	fprintf(output,"SPARE_KIT_PART^REVISION^SEQUENCE^PROJECTNAME^T5DESIGNGROUP^PARTTYPE^CLASS^APPLICABLE_FOR_PART^SP_KIT_UA_CLASS^SP_KIT_Availability^SP_KIT->Part(Spare Kit is for Part)^APPLICABLE_PART_Availability^Part->SP_KIT(Part has Spare Kit)^APP_PART_Type^Has_SP_KIT_Type^Part_Spare_Indicator^\n"); fflush(output);

	char *inputline = NULL;
	char *prntData = NULL;
	char *inputfile=NULL;
	inputfile = ITK_ask_cli_argument("-i=");
	FILE *ipfile = fopen(inputfile,"r");
	if (ipfile == NULL)
	{
		printf("Invalid File Name\n");
	}
	else
	{
		prntData=(char *) MEM_alloc(2000);
		int n_itemobj_found = 0;
		tag_t* titemobj_results = NULL;
		char *cEntries[1]  = {"item_id"};
		char **cValues = (char **) MEM_alloc(2 * sizeof(char *));
		inputline=(char *) MEM_alloc(2000);
		while(fgets(inputline,2000,ipfile)!=NULL)
		{
			printf("\n%s",inputline); fflush(stdout);
			int j = 0;
			tc_strcpy(prntData,"");
			char *SpPart = NULL;
			char *Rev = NULL;
			char *Seq = NULL;
			char *Prj = NULL;
			char *dsgnGrp = NULL;
			char *PrtType = NULL;
			char *Cls = NULL;
			char *AppFrPart = NULL;
			SpPart = tc_strtok(inputline,"^");
			Rev = tc_strtok(NULL,"^");
			Seq = tc_strtok(NULL,"^");
			Prj = tc_strtok(NULL,"^");
			dsgnGrp = tc_strtok(NULL,"^");
			PrtType = tc_strtok(NULL,"^");
			Cls = tc_strtok(NULL,"^");
			AppFrPart = tc_strtok(NULL,"^");

			int PartPresent = 0;
			int PartToSpKit = 0;
			int SpkitPresent = 0;
			int SpKitToPart = 0;

			printf("\n%s--%s",SpPart,AppFrPart); fflush(stdout);

			char **cValues = (char **) MEM_alloc(1 * sizeof(char *));
			cValues[0] = SpPart;
			char* PartObjType2 = NULL;
			ITK_CALL(ITEM_find_items_by_key_attributes(1, (const char **)cEntries, (const char **)cValues, &n_itemobj_found, &titemobj_results));
			printf("\n itemobj_found: %d",n_itemobj_found); fflush(stdout);
			if (n_itemobj_found > 0)
			{
				SpkitPresent = 1;
				tag_t itemrev = NULLTAG;
				int ktsCNT = 0;
				tag_t spKitRel = NULLTAG;
				//logical	SpareInd	= false;
				tag_t* rellist = NULL;
				char* PartID = NULL;
				char* PartRevSeq = NULL;
				char* PartOwner = NULL;
				ITK_CALL(ITEM_ask_latest_rev(titemobj_results[0],&itemrev));
				ITK_CALL(AOM_UIF_ask_value(itemrev,"object_type",&PartObjType2));
				//ITK_CALL(AOM_ask_value_logical(itemrev,"t5_SpareInd", &SpareInd));
				//if( SpareInd==1 )
				//{
					ITK_CALL(GRM_find_relation_type("T5_SpareKitForPart",&spKitRel));
					ITK_CALL(GRM_list_secondary_objects_only(itemrev,spKitRel,&ktsCNT,&rellist));
					if (ktsCNT > 0)
					{
						for (j = 0; j < ktsCNT; ++j)
						{
							ITK_CALL(AOM_ask_value_string(rellist[j],"item_id",&PartID));
							ITK_CALL(AOM_UIF_ask_value(rellist[j],"owning_user",&PartOwner));
							if (tc_strcmp(PartID,AppFrPart)==0)
							{
								SpKitToPart = 1;
								break;
							}
						}
					}
				//}
				
			}
			cValues = NULL;
			char* SpareInd	= NULL;
			char* PartObjType = NULL;
			char* PartObjType1 = NULL;
			cValues = (char **) MEM_alloc(1 * sizeof(char *));
			cValues[0] = AppFrPart;
			ITK_CALL(ITEM_find_items_by_key_attributes(1, (const char **)cEntries, (const char **)cValues, &n_itemobj_found, &titemobj_results));
			printf("\n itemobj_found: %d",n_itemobj_found); fflush(stdout);
			if (n_itemobj_found > 0)
			{
				PartPresent = 1;
				tag_t itemrev = NULLTAG;
				int ktsCNT = 0;
				tag_t spKitRel = NULLTAG;
				tag_t* rellist = NULL;
				char* PartID = NULL;
				char* PartOwner = NULL;
				ITK_CALL(ITEM_ask_latest_rev(titemobj_results[0],&itemrev));
				ITK_CALL(AOM_UIF_ask_value(itemrev,"object_type",&PartObjType1));

				if (tc_strcmp(PartObjType1,"Design Revision")==0)
				{
				ITK_CALL(AOM_UIF_ask_value(itemrev,"t5_SpareInd", &SpareInd));
				//if( SpareInd==1 )
				//{
					ITK_CALL(GRM_find_relation_type("T5_HasSpareKit",&spKitRel));
					ITK_CALL(GRM_list_secondary_objects_only(itemrev,spKitRel,&ktsCNT,&rellist));
					printf("\nT5_HasSpareKit : %d -- %s",ktsCNT,SpareInd);
					if (ktsCNT > 0)
					{
						for (j = 0; j < ktsCNT; ++j)
						{
							ITK_CALL(AOM_ask_value_string(rellist[j],"item_id",&PartID));
							ITK_CALL(AOM_UIF_ask_value(rellist[j],"object_type",&PartObjType));
							ITK_CALL(AOM_UIF_ask_value(rellist[j],"owning_user",&PartOwner));
							printf("\nCompare --- %s -- %s",PartID,SpPart); fflush(stdout);
							if (tc_strcmp(PartID,SpPart)==0)
							{
								PartToSpKit = 1;
								break;
							}
						}
					}
				//}
				}
			}
			cValues = NULL;

			fprintf(output,"%s^%s^%s^%s^%s^%s^%s^%s^",SpPart,Rev,Seq,Prj,dsgnGrp,PrtType,Cls,AppFrPart);
			PartObjType2 == NULL ? fprintf(output,"-^") : fprintf(output,"%s^",PartObjType2);
			SpkitPresent > 0 ? fprintf(output,"Available^") : fprintf(output,"Missing^");
			SpKitToPart > 0 ? fprintf(output,"Available^") : fprintf(output,"Missing^");
			PartPresent > 0 ? fprintf(output,"Available^") : fprintf(output,"Missing^");
			PartToSpKit > 0 ? fprintf(output,"Available^") : fprintf(output,"Missing^");
			PartObjType1 == NULL ? fprintf(output,"-^") : fprintf(output,"%s^",PartObjType1); 
			PartObjType == NULL ? fprintf(output,"-^") : fprintf(output,"%s^",PartObjType); 
			SpareInd == NULL ? fprintf(output,"-^\n") : fprintf(output,"%s^\n",SpareInd); fflush(output);
		}
	}

	iFail = ITK_exit_module(TRUE);
	printf("\nReturn Value is : %d", iFail);
	if (iFail == ITK_ok)
	{
		printf("\nTeamcenter Logout Success...");fflush(stdout);
	}
	else
	{
		EMH_ask_error_text(iFail, &cError);
		printf("\nError is : %s", cError);fflush(stdout);
	}		
	fclose(output);
	return ITK_ok;
}
