/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
*------------------------------------------------------------------------------
* Filename		: autologin.c
* Description	: This Utility Mainly Used For AutoLogin in Teamcenter
* Module       	:	        
* Since		    :    
* ENVIRONMENT	: C++, ITK
* History       :
*------------------------------------------------------------------------------
*    Date         	   Name						Description of Change
* 30/03/2023   	   Lokendra Aporiya		          For QTY

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tccore/aom.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/aom_prop.h>
#include <ae/dataset.h>
#include <sa/tcfile.h>
#define ITK_err 910001

FILE  *output1 = NULL;
int iFail = 0;

int ITK_CALL(int iFail)
{
	char* cError = NULL;
	
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);fflush(stdout);
		  exit(0);
		}

		return iFail;
}

typedef struct PosFile {
    char* Nm1stTok;
	char* Nm2ndTok;
	char* Nm3rdTok;
	char* ParentPart;
	char* ChildPart;
	char* MatPos1;
	char* MatPos2;
	char* MatPos3;
	char* MatPos4;
	char* MatPos5;
	char* MatPos6;
	char* MatPos7;
	char* MatPos8;
	char* MatPos9;
	char* MatPos10;
	char* MatPos11;
	char* MatPos12;
	char* MatPos13;
	char* MatPos14;
	char* MatPos15;
	char* MatPos16;
	char* OtherArg;
	char* SuppressInd;
} PosMat;

/*int ValidateString (char *B)
{
    int i;
    for (i = 0; B[i] != '\0'; i++)
    {
        //if (!(B[i] >= 65 && B[i] <= 90) && !(B[i] >= 97 && B[i] <= 122) && !(B[i] >= 44 && B[i] <= 57) && !(B[i] >31 && B[i] <= 32))
        printf("%d-",B[i]); fflush(stdout);
        if (!(B[i] < 32 && B[i] > 126))
        {
            return 0;
        }
    }
    return 1;
}*/
int isPrintable(char ch) {
    return ch >= 32 && ch <= 126;
}
int ValidateString(char *str) {
    int i = 0;
    char ch;
    int stat=1;
    int cnt = 0;
    while ((ch = str[i]) != '\0') {
    	if (ch == ',')
    	{
    		cnt++;
    	}
    	if (cnt > 2)
    	{
    		break;
    	}
        if (!isPrintable(ch))
        {
            stat = 0;
            break;
        }
        i++;
    }
    return stat;
}

int ITK_user_main(int argc, char* argv[])
{
	    char* cError = NULL;
		char* username = NULL;
		tag_t tuser = NULLTAG;
		iFail = ITK_auto_login();
		printf("\nReturn Value is : %d", iFail);fflush(stdout);
		
		int n_entries = 2;
		int i,j,k,l,m,n,cnt;
		tag_t tItemobj = NULLTAG;
		int n_itemobj_found = 0;
		tag_t* titemobj_results = NULLTAG;

		char *PartID = NULL;
		char *PartRevSeq =NULL;
		char *PartSequenceID = NULL;
		char *part_type = NULL;
		char *QuantityAttrId = NULL;
		char *Description = NULL;
		char *object_type = NULL;
		char *Part_ProjID = NULL;
		char *Part_DesgnGrp = NULL;
		char *Revision = NULL;
		tag_t DataSet = NULLTAG;
		char *inputfile=NULL;
		char * objtype1=NULL;
		tag_t* attachments =NULLTAG;
		tag_t* cntr_objects = NULLTAG;
		
		
		int iRev_Count = 0;
		tag_t* tRevList = NULLTAG;
		tag_t tWindow = NULLTAG;
		tag_t tWindow1 = NULLTAG;
		tag_t tBOMLine = NULLTAG;
		tag_t tBOMLine1 = NULLTAG;
		
		tag_t child_item=NULLTAG;
		tag_t child_rev=NULLTAG;
		
		char* cLevel = NULL;
		char* cRev_Name = NULL;
		char* cItem_Id = NULL;
		char* cRevision = NULL;
		char* cParent = NULL;
		char* cOwn_Group = NULL;
		char* cOwn_User = NULL;
		char* cQuantity = NULL;
		char* cFind_No = NULL;
		char* cPacked = NULL;
		char* cDRAR = NULL;
		char* cPart_Type = NULL;
		tag_t rule = NULLTAG;
		tag_t rule1 = NULLTAG;
		tag_t iteamrev2 = NULLTAG;
		tag_t dataset2 = NULLTAG;
		tag_t relation_type2 =NULLTAG;
		tag_t reln_type_ProMem =NULLTAG;
		int n_attchs_ProMem = 0;
		tag_t* rellist_ProMem_DsgnRev =NULLTAG;	
		int bl_Suppress=0;
		logical bl_Suppress_log;
		char*   refnamePdf = NULL;
		char*   orig_Asmname = NULL;
		AE_reference_type_t     reftype;
		tag_t	refobject	=	NULLTAG;
		
		
		tag_t* tBOM_Children = NULLTAG;
		int iNumber_Child = 0;
		
		time_t 	now;
		struct 	tm when;
		time(&now);
		when = *localtime(&now);
		char Data[100] = "";
		char outputFile1[200] = "";
		strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
		sprintf(outputFile1,"StatusReport_%s.txt",Data);
		output1 = fopen(outputFile1,"w");
		if (output1 == NULL)
		{
			printf("ERROR: Cannot open File\n");
			return -1;
		}
				
	
		inputfile = ITK_ask_cli_argument("-i=");
		FILE *fp;
		fp=fopen(inputfile,"r");
		FILE *fpPosFile;
		
		char *cEntries[2]  = {"Item ID","Revision"};
		char *inputline = NULL;
		char *inputline1 = NULL;
		
		char **cValues = (char **) MEM_alloc(50 * sizeof(char *));
				
		if (iFail == ITK_ok)
		{
			printf("\nTeamcenter Login Success...");fflush(stdout);
			POM_get_user(&username, &tuser);
			printf("\nUsername = %s", username);fflush(stdout);
		}
		else
		{
			EMH_ask_error_text(iFail, &cError);
			printf("\nError is : %s", cError);fflush(stdout);
		}
		if (cError)
		{
			MEM_free(cError);
		}
		if (username)
		{
			MEM_free(username);
		}

		char* partRevSeqIP = (char *)MEM_alloc(50);
		
				if(fp!=NULL)
				{
					inputline=(char *) MEM_alloc(1000);
					while(fgets(inputline,1000,fp)!=NULL)
					{
						printf("\n\n Input Part: %s",inputline); fflush(stdout);
		
						char *partNoIP = NULL;
						char *partRevIP = NULL;
						char *partSeqIP = NULL;
						
						tc_strcpy(partRevSeqIP, "");							
						partNoIP = tc_strtok(inputline,",");
						partRevIP = tc_strtok(NULL,",");
						partSeqIP = tc_strtok(NULL,",");
						tc_strcpy(partRevSeqIP, partRevIP);
						tc_strcat(partRevSeqIP, ";");
						tc_strcat(partRevSeqIP, partSeqIP);

						printf("partNoIP-----------> :%s\n",partNoIP);fflush(stdout);						
						cValues[0] = partNoIP;
						cValues[1] = partRevSeqIP;
												
						//ITK_CALL(QRY_find2("Latest Released Design Revision for ERC",&tItemobj));	
						//ITK_CALL(QRY_find2("Latest Item Revision for ERC",&tItemobj));	
						ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
						ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
						if(n_itemobj_found>0)
						{
							PosMat* PosMatData = (PosMat*)MEM_alloc(1 * sizeof(PosMat));
							int MatFileRecCount = 0;
							char *posFileNm = (char*)MEM_alloc(250 * sizeof(char));
							tc_strcpy(posFileNm,"/proj/TMatrixFiles/");

							iteamrev2 = titemobj_results[0];
							char* owninguser = NULL;
							ITK_CALL(AOM_UIF_ask_value(iteamrev2, "owning_user", &owninguser ));
							printf("\nOwning User: %s",owninguser); fflush(stdout);
							ITKCALL(AOM_ask_value_string(iteamrev2,"item_id",&PartID));
							if (tc_strstr(owninguser, "loader")== NULL)
							{
								printf("Not Migrated Data %s ----------- Hence continue",PartID);
								continue;
							}
							int ProAsmFind = 0;
							
							ITKCALL(AOM_ask_value_string(iteamrev2,"item_revision_id",&PartRevSeq));
							//fprintf(output,"\n%s,%s,",PartID,PartRevSeq);fflush(output);
							printf("\n------->PartID PartRevSeq  :%s %s",partNoIP,PartRevSeq);fflush(stdout);					
							ITK_CALL(GRM_find_relation_type("IMAN_specification",&relation_type2));
							ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[0],relation_type2,&cnt,&attachments));
							for(k=0;k<cnt;k++)
							{
								dataset2=attachments[k];
								if( AOM_ask_value_string(dataset2,"object_type",&objtype1)!=ITK_ok);
								if (tc_strcmp(objtype1,"ProAsm")==0)
								{
									char* Nm1stTok = NULL;
									char* Nm2ndTok = NULL;
									char* Nm3rdTok = NULL;
									char* ParentPart = NULL;
									char* ChildPart = NULL;
									char* MatPos1 = NULL;
									char* MatPos2 = NULL;
									char* MatPos3 = NULL;
									char* MatPos4 = NULL;
									char* MatPos5 = NULL;
									char* MatPos6 = NULL;
									char* MatPos7 = NULL;
									char* MatPos8 = NULL;
									char* MatPos9 = NULL;
									char* MatPos10 = NULL;
									char* MatPos11 = NULL;
									char* MatPos12 = NULL;
									char* MatPos13 = NULL;
									char* MatPos14 = NULL;
									char* MatPos15 = NULL;
									char* MatPos16 = NULL;
									char* OtherArg = NULL;
									char* SuppressInd = NULL;
									MatFileRecCount = 0;

									ITK_CALL(AE_find_dataset_named_ref2(dataset2,0,&refnamePdf,&reftype,&refobject));
									if (refobject != NULLTAG)
									{
										ITK_CALL( IMF_ask_original_file_name2(refobject,&orig_Asmname));
										printf("\n ---orig_Asmname ----- :%s\n",orig_Asmname);
										Nm1stTok = tc_strtok(orig_Asmname,".");
										Nm2ndTok = tc_strtok(NULL,".");
										Nm3rdTok = tc_strtok(NULL,".");
										tc_strcat(posFileNm,Nm1stTok);
										tc_strcat(posFileNm,"_");
										tc_strcat(posFileNm,Nm3rdTok);
										tc_strcat(posFileNm,".pos");
										printf("Opening File --- %s",posFileNm); fflush(stdout);
										fpPosFile=fopen(posFileNm,"r");
										if(fpPosFile!=NULL)
										{
											ProAsmFind = 1;
											inputline1=(char *) MEM_alloc(2000);
											while(fgets(inputline1,2000,fpPosFile)!=NULL)
											{
												if(ValidateString(inputline1))
												{
												ParentPart = tc_strtok(inputline1,",");
												ChildPart = tc_strtok(NULL,",");
												MatPos1 = tc_strtok(NULL,",");
												MatPos2 = tc_strtok(NULL,",");
												MatPos3 = tc_strtok(NULL,",");
												MatPos4 = tc_strtok(NULL,",");
												MatPos5 = tc_strtok(NULL,",");
												MatPos6 = tc_strtok(NULL,",");
												MatPos7 = tc_strtok(NULL,",");
												MatPos8 = tc_strtok(NULL,",");
												MatPos9 = tc_strtok(NULL,",");
												MatPos10 = tc_strtok(NULL,",");
												MatPos11 = tc_strtok(NULL,",");
												MatPos12 = tc_strtok(NULL,",");
												MatPos13 = tc_strtok(NULL,",");
												MatPos14 = tc_strtok(NULL,",");
												MatPos15 = tc_strtok(NULL,",");
												MatPos16 = tc_strtok(NULL,",");
												OtherArg = tc_strtok(NULL,",");
												SuppressInd = tc_strtok(NULL,",");

												PosMatData = (PosMat*)MEM_realloc(PosMatData, (MatFileRecCount+1) * sizeof(PosMat));
												PosMatData[MatFileRecCount].ParentPart = (char*)MEM_alloc( tc_strlen(ParentPart) *sizeof(char));
												PosMatData[MatFileRecCount].ChildPart = (char*)MEM_alloc( tc_strlen(ChildPart) *sizeof(char));
												PosMatData[MatFileRecCount].MatPos1 = (char*)MEM_alloc( tc_strlen(MatPos1) *sizeof(char));
												PosMatData[MatFileRecCount].MatPos2 = (char*)MEM_alloc( tc_strlen(MatPos2) *sizeof(char));
												PosMatData[MatFileRecCount].MatPos3 = (char*)MEM_alloc( tc_strlen(MatPos3) *sizeof(char));
												PosMatData[MatFileRecCount].MatPos4 = (char*)MEM_alloc( tc_strlen(MatPos4) *sizeof(char));
												PosMatData[MatFileRecCount].MatPos5 = (char*)MEM_alloc( tc_strlen(MatPos5) *sizeof(char));
												PosMatData[MatFileRecCount].MatPos6 = (char*)MEM_alloc( tc_strlen(MatPos6) *sizeof(char));
												PosMatData[MatFileRecCount].MatPos7 = (char*)MEM_alloc( tc_strlen(MatPos7) *sizeof(char));
												PosMatData[MatFileRecCount].MatPos8 = (char*)MEM_alloc( tc_strlen(MatPos8) *sizeof(char));
												PosMatData[MatFileRecCount].MatPos9 = (char*)MEM_alloc( tc_strlen(MatPos9) *sizeof(char));
												PosMatData[MatFileRecCount].MatPos10 = (char*)MEM_alloc( tc_strlen(MatPos10) *sizeof(char));
												PosMatData[MatFileRecCount].MatPos11 = (char*)MEM_alloc( tc_strlen(MatPos11) *sizeof(char));
												PosMatData[MatFileRecCount].MatPos12 = (char*)MEM_alloc( tc_strlen(MatPos12) *sizeof(char));
												PosMatData[MatFileRecCount].MatPos13 = (char*)MEM_alloc( tc_strlen(MatPos13) *sizeof(char));
												PosMatData[MatFileRecCount].MatPos14 = (char*)MEM_alloc( tc_strlen(MatPos14) *sizeof(char));
												PosMatData[MatFileRecCount].MatPos15 = (char*)MEM_alloc( tc_strlen(MatPos15) *sizeof(char));
												PosMatData[MatFileRecCount].MatPos16 = (char*)MEM_alloc( tc_strlen(MatPos16) *sizeof(char));
												PosMatData[MatFileRecCount].OtherArg = (char*)MEM_alloc( tc_strlen(OtherArg) *sizeof(char));
												PosMatData[MatFileRecCount].SuppressInd = (char*)MEM_alloc( tc_strlen(SuppressInd) *sizeof(char));
												tc_strcpy(PosMatData[MatFileRecCount].ParentPart, ParentPart);
												tc_strcpy(PosMatData[MatFileRecCount].ChildPart, ChildPart);
												tc_strcpy(PosMatData[MatFileRecCount].MatPos1, MatPos1);
												tc_strcpy(PosMatData[MatFileRecCount].MatPos2, MatPos2);
												tc_strcpy(PosMatData[MatFileRecCount].MatPos3, MatPos3);
												tc_strcpy(PosMatData[MatFileRecCount].MatPos4, MatPos4);
												tc_strcpy(PosMatData[MatFileRecCount].MatPos5, MatPos5);
												tc_strcpy(PosMatData[MatFileRecCount].MatPos6, MatPos6);
												tc_strcpy(PosMatData[MatFileRecCount].MatPos7, MatPos7);
												tc_strcpy(PosMatData[MatFileRecCount].MatPos8, MatPos8);
												tc_strcpy(PosMatData[MatFileRecCount].MatPos9, MatPos9);
												tc_strcpy(PosMatData[MatFileRecCount].MatPos10, MatPos10);
												tc_strcpy(PosMatData[MatFileRecCount].MatPos11, MatPos11);
												tc_strcpy(PosMatData[MatFileRecCount].MatPos12, MatPos12);
												tc_strcpy(PosMatData[MatFileRecCount].MatPos13, MatPos13);
												tc_strcpy(PosMatData[MatFileRecCount].MatPos14, MatPos14);
												tc_strcpy(PosMatData[MatFileRecCount].MatPos15, MatPos15);
												tc_strcpy(PosMatData[MatFileRecCount].MatPos16, MatPos16);
												tc_strcpy(PosMatData[MatFileRecCount].OtherArg, OtherArg);
												tc_strcpy(PosMatData[MatFileRecCount].SuppressInd, SuppressInd);
												MatFileRecCount++;
												printf("\n\tParent: %s - Child: %s - Suppress Status: %s--",ParentPart, ChildPart, SuppressInd); fflush(stdout);
												}
												else
												{
													printf ("\nJUNK-CHARACTER-FOUND");fflush(stdout);
												}
											}
										}
										else
										{
											printf("File Open Failed--- %s",posFileNm); fflush(stdout);
											fprintf(output1,"%s,%s,POSFile not Available,\n",PartID,PartRevSeq);fflush(output1);
										}
										break;
									}
									else
									{
										fprintf(output1,"%s,%s,Named ref Missing,\n",PartID,PartRevSeq);fflush(output1);
									}
								}
							}
							if(ProAsmFind == 1)
							{		
								int finalStat = 0;
								/// Pro Assembly member relationship
								ITK_CALL(GRM_find_relation_type("Pro2_membership",&reln_type_ProMem));
								ITK_CALL(GRM_list_secondary_objects_only(dataset2,reln_type_ProMem,&n_attchs_ProMem,&rellist_ProMem_DsgnRev));
								printf("\n PRO ASM relation found <%d> \n",n_attchs_ProMem);fflush(stdout);
								char* AsmPart = NULL;
								char **MembershipPartArray = (char **) MEM_alloc(1000 * sizeof(char *));
								int MemArrIndx = 0;
								if(n_attchs_ProMem>0)
								{									
									int x=0;
									for(x=0; x < n_attchs_ProMem ; x++)
									{
										ITKCALL(AOM_ask_value_string(rellist_ProMem_DsgnRev[x],"item_id",&AsmPart));
										MembershipPartArray[MemArrIndx] = AsmPart;
										MemArrIndx++;
										//printf("\n Pro assembly member ------>%s \n",AsmPart);fflush(stdout);
										
									}
								}
						
								ITK_CALL(BOM_create_window( &tWindow));
							//	iFail = CFM_find( "ERC release and above", &rule );
							//	iFail = BOM_set_window_config_rule(tWindow, rule );
								ITK_CALL(BOM_set_window_pack_all(tWindow, false));
								ITK_CALL(BOM_set_window_top_line( tWindow, NULLTAG, iteamrev2, NULLTAG, &tBOMLine1));
								ITK_CALL(BOM_window_show_suppressed (tWindow));
								ITK_CALL(BOM_line_ask_child_lines(tBOMLine1, &iNumber_Child, &tBOM_Children));
								//ITK_CALL(BOM_line_ask_all_child_lines(tBOMLine1, &iNumber_Child, &tBOM_Children));
								
								printf("\n Return Value From Child Line API is --------> %d", iFail);fflush(stdout);
								printf("\n No of Children Found ---------> %d\n",iNumber_Child);fflush(stdout);
								if(iNumber_Child>0)
								{
									int flag =0;
									logical IsSuppres1;
									for(i=0;i<iNumber_Child;i++)
									{
										flag =0;
										tag_t bom_line_tag = NULLTAG;
										bom_line_tag = tBOM_Children[i];

										ITK_CALL(AOM_ask_value_string(bom_line_tag, "bl_item_item_id", &cItem_Id));
										ITK_CALL(AOM_ask_value_string(bom_line_tag, "bl_rev_item_revision_id", &cRevision));
										//ITK_CALL(BOM_line_look_up_attribute ("bl_is_occ_suppressed",&bl_Suppress));
										//ITK_CALL(BOM_line_ask_attribute_logical(bom_line_tag, bl_Suppress, &bl_Suppress_log));
										ITK_CALL(AOM_ask_value_logical(bom_line_tag,"bl_is_occ_suppressed",&bl_Suppress_log));
										if (bl_Suppress_log == 1)
										{
											for(m=0;m<MatFileRecCount;m++)
											{
												if(tc_strcmp(PosMatData[m].ChildPart,cItem_Id)==0)
												{	
													if (tc_strstr(PosMatData[m].SuppressInd,"True")==NULL)
													{
														flag =1;
														break;
													}
												}
											}
										}
										else
										{
											for(m=0;m<MatFileRecCount;m++)
											{
												if(tc_strcmp(PosMatData[m].ChildPart,cItem_Id)==0)
												{	
													if (tc_strstr(PosMatData[m].SuppressInd,"False")==NULL)
													{
														flag =2;
														break;
													}
												}
											}
										}
										
										if(flag == 1)
										{
											int bl_Suppress=0;
											logical bl_Suppress_log;
											int level0,pack_count;
											printf("\n Not Found In Cad Bom ------>%s \n",cItem_Id);fflush(stdout);
											//ITK_CALL(BOM_line_look_up_attribute ("bl_is_occ_suppressed",&bl_Suppress));
											//ITK_CALL(BOM_line_ask_attribute_logical(bom_line_tag, bl_Suppress, &bl_Suppress_log));
											ITK_CALL(AOM_ask_value_logical(bom_line_tag,"bl_is_occ_suppressed",&bl_Suppress_log));
											printf("\t bl_is_occ_suppressed \t\t "); fflush(stdout);
											if( AOM_ask_value_int(bom_line_tag,"bl_level_starting_0",&level0)!=ITK_ok);
											if( AOM_ask_value_int(bom_line_tag,"bl_pack_count",&pack_count)!=ITK_ok);
											printf("\t level0: [%d]",level0); fflush(stdout);
											printf("\t pack_count: [%d]",pack_count); fflush(stdout);
											if (bl_Suppress_log == 1)
											{
												//ITK_CALL(BOM_line_set_attribute_logical(bom_line_tag, bl_Suppress, false));
												ITK_CALL(AOM_set_value_logical(bom_line_tag, "bl_is_occ_suppressed", false));
												printf("\n\t ...Updated successfully"); fflush(stdout);
												fprintf(output1,"%s,%s,Update Success,%s,\n",PartID,PartRevSeq,cItem_Id);fflush(output1);
												ITK_CALL(BOM_save_window( tWindow ));
												finalStat = 1;
											}
										}
										else if (flag == 2)
										{
											int bl_Suppress=0;
											logical bl_Suppress_log;
											int level0,pack_count;
											printf("\n Not Found In Cad Bom ------>%s \n",cItem_Id);fflush(stdout);
											//ITK_CALL(BOM_line_look_up_attribute ("bl_is_occ_suppressed",&bl_Suppress));
											//ITK_CALL(BOM_line_ask_attribute_logical(bom_line_tag, bl_Suppress, &bl_Suppress_log));
											ITK_CALL(AOM_ask_value_logical(bom_line_tag,"bl_is_occ_suppressed",&bl_Suppress_log));
											printf("\t bl_is_occ_suppressed \t\t "); fflush(stdout);
											if( AOM_ask_value_int(bom_line_tag,"bl_level_starting_0",&level0)!=ITK_ok);
											if( AOM_ask_value_int(bom_line_tag,"bl_pack_count",&pack_count)!=ITK_ok);
											printf("\t level0: [%d]",level0); fflush(stdout);
											printf("\t pack_count: [%d]",pack_count); fflush(stdout);
											if (bl_Suppress_log == 1)
											{
												//ITK_CALL(BOM_line_set_attribute_logical(bom_line_tag, bl_Suppress, true));
												ITK_CALL(AOM_set_value_logical(bom_line_tag, "bl_is_occ_suppressed", false));
												printf("\n\t ...Updated successfully"); fflush(stdout);
												fprintf(output1,"%s,%s,Update Success,%s,\n",PartID,PartRevSeq,cItem_Id);fflush(output1);
												ITK_CALL(BOM_save_window( tWindow ));
												finalStat = 1;
											}
										}
									}									
								}
								else
								{
									printf("\n BOM Line Missing");fflush(stdout);
								}
								//ITK_CALL(BOM_save_window( tWindow ));
								//ITK_CALL(BOM_set_window_pack_all (tWindow, true));

								if (finalStat == 0)
								{
									printf("\n NO Issue Found In BOM Line Suppress Value as per CAD Translation Matrix");fflush(stdout);
								}

								ITK_CALL(BOM_close_window(tWindow));
								printf("\n Return Value From BOM Close Window API is --------> %d", iFail);fflush(stdout);		
							}
							else
							{
								printf("\n POS File Read fail / Named ref Missing");fflush(stdout);
							}		
						}
					}
				}
		iFail = ITK_exit_module(TRUE);
		printf("\nReturn Value is : %d", iFail);
		if (iFail == ITK_ok)
		{
			printf("\nTeamcenter Logout Success...");fflush(stdout);
		}
		else
		{
			EMH_ask_error_text(iFail, &cError);
			printf("\nError is : %s", cError);fflush(stdout);
		}
	fclose(output1);
	return ITK_ok;
}




