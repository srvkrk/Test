/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2023  MNM.  ALL RIGHTS RESERVED
*
*------------------------------------------------------------------------------
* Filename		: EbomCadBomCheck.c
* Description	: This Utility Used For Uploading of CREO Membership in CVPROD
* Module       	: Report
* Since		    : 2023
* ENVIRONMENT	: C++, ITK
* History       : 
*------------------------------------------------------------------------------
*    Date         	   Name														Description of Change
* -----------------------------------------------------------------------------
*
* 
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <ae/datasettype.h>
#include <tccore/grm.h>
#define ITK_err 910001

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);fflush(stdout);
		  exit(0);
		}

		return iFail;
}

typedef struct CadBOMChildData {
    char *ChildPartNo;
    char *ChildPartRev;
    char *ChildPartSeq;
} CadBOMChildStruct;

typedef struct CadBOMParentData {
    char *PartNo;
    char *PartRev;
    char *PartSeq;
    int chldCnt;
    CadBOMChildStruct* CadBOMChild;
} CadBOMStruct;

int ITK_user_main(int argc, char* argv[])
{
    int iFail = 0;
    char* cError = NULL;
	char* username = NULL;
	iFail = ITK_auto_login();
	printf("\nReturn Value is : %d", iFail);fflush(stdout);

	char *tceCADBOM=NULL;
	tceCADBOM = ITK_ask_cli_argument("-i=");
	char *inputline = NULL;

	FILE *NotFoundPart = NULL;
	NotFoundPart = fopen("PartNotPresentTCUA.txt","w");

	FILE *TCECadBomFile = NULL;
	CadBOMStruct* tceCADBOMData = (CadBOMStruct*)MEM_alloc(500 * sizeof(CadBOMStruct));
	int CadBomMainSize = 0;
	int y = 0;
	int z = 0;
	TCECadBomFile = fopen(tceCADBOM,"r");
	if (TCECadBomFile == NULL)
	{
		printf("No Data File Check in TCE\n");
	}
	else
	{
		inputline=(char *) MEM_alloc(2000);
		while(fgets(inputline,2000,TCECadBomFile)!=NULL)
		{
			char *PartNo = NULL;
			char *PartRev = NULL;
			char *PartSeq = NULL;
			char *ChildPartNo = NULL;
			char *ChildPartRev = NULL;
			char *ChildPartSeq = NULL;
			int prsntStruct = 0;
			PartNo = tc_strtok(inputline,"^");
			PartRev = tc_strtok(NULL,"^");
			PartSeq = tc_strtok(NULL,"^");
			ChildPartNo = tc_strtok(NULL,"^");
			ChildPartRev = tc_strtok(NULL,"^");
			ChildPartSeq = tc_strtok(NULL,"^");

			for (y = 0; y < CadBomMainSize; y++)
		    {
		    	if(tc_strcmp(PartNo, tceCADBOMData[y].PartNo) == 0)
		    	{
		    		printf("\nCADBOM Success %s compare with %s --> Inset %s",tceCADBOMData[y].PartNo,PartNo,ChildPartNo);fflush(stdout);
		    		prsntStruct = 1;
		    		int nextPos = tceCADBOMData[y].chldCnt + 1;
		    		tceCADBOMData[y].chldCnt = nextPos;
		    		tceCADBOMData[y].CadBOMChild = (CadBOMChildStruct*)MEM_realloc(tceCADBOMData[y].CadBOMChild, (nextPos+1) * sizeof(CadBOMChildStruct));
		    		tceCADBOMData[y].CadBOMChild[nextPos].ChildPartNo = (char*)MEM_alloc( tc_strlen(ChildPartNo) *sizeof(char));
		    		tceCADBOMData[y].CadBOMChild[nextPos].ChildPartRev = (char*)MEM_alloc( tc_strlen(ChildPartRev) *sizeof(char));
		    		tceCADBOMData[y].CadBOMChild[nextPos].ChildPartSeq = (char*)MEM_alloc( tc_strlen(ChildPartSeq) *sizeof(char));
		    		tc_strcpy(tceCADBOMData[y].CadBOMChild[nextPos].ChildPartNo, ChildPartNo);
		    		tc_strcpy(tceCADBOMData[y].CadBOMChild[nextPos].ChildPartRev, ChildPartRev);
		    		tc_strcpy(tceCADBOMData[y].CadBOMChild[nextPos].ChildPartSeq, ChildPartSeq);
		    	}
		    }
		    if(prsntStruct == 0)
		    {
		    	printf("\n*********************************************CADBOM %d Mismatch-%s--> Inset %s",CadBomMainSize,PartNo,ChildPartNo);fflush(stdout);
			    tceCADBOMData[CadBomMainSize].PartNo = (char*)MEM_alloc( tc_strlen(PartNo) *sizeof(char));
			    tceCADBOMData[CadBomMainSize].PartRev = (char*)MEM_alloc( tc_strlen(PartRev) *sizeof(char));
			    tceCADBOMData[CadBomMainSize].PartSeq = (char*)MEM_alloc( tc_strlen(PartSeq) *sizeof(char));
			    tc_strcpy(tceCADBOMData[CadBomMainSize].PartNo, PartNo);
			    tc_strcpy(tceCADBOMData[CadBomMainSize].PartRev, PartRev);
			    tc_strcpy(tceCADBOMData[CadBomMainSize].PartSeq, PartSeq);
				tceCADBOMData[CadBomMainSize].chldCnt = 0;
				tceCADBOMData[CadBomMainSize].CadBOMChild = (CadBOMChildStruct*)MEM_alloc(1 * sizeof(CadBOMChildStruct));
				tceCADBOMData[CadBomMainSize].CadBOMChild[0].ChildPartNo = (char*)MEM_alloc( (tc_strlen(ChildPartNo)+10) *sizeof(char));
				tceCADBOMData[CadBomMainSize].CadBOMChild[0].ChildPartRev = (char*)MEM_alloc( (tc_strlen(ChildPartRev)+10) *sizeof(char));
				tceCADBOMData[CadBomMainSize].CadBOMChild[0].ChildPartSeq = (char*)MEM_alloc( (tc_strlen(ChildPartSeq)+10) *sizeof(char));
				tc_strcpy(tceCADBOMData[CadBomMainSize].CadBOMChild[0].ChildPartNo, ChildPartNo);
				tc_strcpy(tceCADBOMData[CadBomMainSize].CadBOMChild[0].ChildPartRev, ChildPartRev);
				tc_strcpy(tceCADBOMData[CadBomMainSize].CadBOMChild[0].ChildPartSeq, ChildPartSeq);
				CadBomMainSize++;
		    }
		}
		inputline = NULL;
	}
	fclose(TCECadBomFile);

	tag_t tItemobj = NULLTAG;
	tag_t tItemobjChld = NULLTAG;
	int n_entries = 2;
	char * cEntries[2] = {
    "Item ID",
    "Revision"
 	};
 	char ** cValues = (char ** ) MEM_alloc(50 * sizeof(char * ));
 	char ** cValues2 = (char ** ) MEM_alloc(50 * sizeof(char * ));
 	char * cRevision = NULL;
    cRevision = (char * ) MEM_alloc(50);
    int n_itemobj_found = 0;
	tag_t * titemobj_results = NULLTAG;
	tag_t itemrev = NULLTAG;
	tag_t relation_type2 = NULLTAG;
	tag_t IPEMRelTag = NULLTAG;
	ITK_CALL(GRM_find_relation_type("IMAN_specification", & relation_type2));
	ITK_CALL(GRM_find_relation_type("Pro2_membership", & IPEMRelTag));
	int cnt = 0;
	tag_t * attachments = NULLTAG;
	int k = 0;
	tag_t dataset2 = NULLTAG;
	char *objtype1 = NULL;
	int n_itemobj_found_Chld = 0;
	tag_t * titemobj_results_Chld = NULLTAG;
	tag_t childRelObj = NULLTAG;
	tag_t Fndrelation2 = NULLTAG;
	tag_t relationCre = NULLTAG;

	if(CadBomMainSize > 0)
	{
	    for (y = 0; y < CadBomMainSize; ++y)
	    {
	    	printf("\n\n\nParent %d -> %s,%s,%s",y,tceCADBOMData[y].PartNo, tceCADBOMData[y].PartRev, tceCADBOMData[y].PartSeq); fflush(stdout);

	    	tc_strcpy(cRevision,tceCADBOMData[y].PartRev);
	    	tc_strcat(cRevision,";");
	    	tc_strcat(cRevision,tceCADBOMData[y].PartSeq);
	    	cValues[0] = tceCADBOMData[y].PartNo;
      		cValues[1] = cRevision;

      		ITK_CALL(QRY_find2("Item Revision...", & tItemobj));
	    	ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, & n_itemobj_found, & titemobj_results));
	    	printf("Main Part Found : %d - %s - %s",n_itemobj_found,tceCADBOMData[y].PartNo,cRevision); fflush(stdout);

	    	if(n_itemobj_found > 0)
	    	{
	    		itemrev = titemobj_results[0];
	    		ITK_CALL(GRM_list_secondary_objects_only(itemrev, relation_type2, & cnt, & attachments));
	    		for (k = 0; k < cnt; k++) {
            		dataset2 = attachments[k];
            		if (AOM_ask_value_string(dataset2, "object_type", & objtype1) != ITK_ok);
		            if ((tc_strcmp(objtype1, "ProAsm") == 0)) 
		            {
		            	/*if(tceCADBOMData[y].chldCnt > 0)
		            	{
							int z = 0;
							int cntCreoMemRels = 0;
							char* creorelnames = NULL;
							tag_t *CreoMemRels	= NULLTAG;
							GRM_list_all_related_objects_only(dataset2,&cntCreoMemRels,&CreoMemRels);
							printf("\nReleations Count : %d",cntCreoMemRels); fflush(stdout);
							for (z = 0; z < cntCreoMemRels; ++z)
							{
								if (AOM_ask_value_string(CreoMemRels[z],"type_string",&creorelnames)!=ITK_ok);
								if(tc_strcmp(creorelnames,"Creo membership")==0)
								{
									ITK_CALL(GRM_delete_relation(CreoMemRels[z]));
									printf("\nDeleting Releation : %d --- %s ",z,creorelnames); fflush(stdout);
								}
							}
							ITK_CALL(AOM_refresh(dataset2,1));
		            	}*/
		            	for (z = 0; z <= tceCADBOMData[y].chldCnt; ++z)
				    	{
				    		printf("\n\t--------%d -> %s,%s,%s",z,tceCADBOMData[y].CadBOMChild[z].ChildPartNo, tceCADBOMData[y].CadBOMChild[z].ChildPartRev, tceCADBOMData[y].CadBOMChild[z].ChildPartSeq); fflush(stdout);
				    		tc_strcpy(cRevision,tceCADBOMData[y].CadBOMChild[z].ChildPartRev);
					    	tc_strcat(cRevision,";");
					    	tc_strcat(cRevision,tceCADBOMData[y].CadBOMChild[z].ChildPartSeq);
					    	cValues2[0] = tceCADBOMData[y].CadBOMChild[z].ChildPartNo;
				      		cValues2[1] = cRevision;

				    		ITK_CALL(QRY_find2("Item Revision...", & tItemobjChld));
	    					ITK_CALL(QRY_execute(tItemobjChld, n_entries, cEntries, cValues2, & n_itemobj_found_Chld, & titemobj_results_Chld));
	    					printf("Main Part Found : %d",n_itemobj_found_Chld); fflush(stdout);
	    					if (n_itemobj_found_Chld > 0)
	    					{
	    						childRelObj = titemobj_results_Chld[0];
	    						ITK_CALL(GRM_find_relation(dataset2, childRelObj, IPEMRelTag, & Fndrelation2));
	    						if (Fndrelation2 == NULLTAG)
	    						{
	    							ITK_CALL(GRM_create_relation(dataset2, childRelObj, IPEMRelTag, NULLTAG, & relationCre));
	    							if (relationCre)
	    							{
	    								ITK_CALL(AOM_refresh(dataset2, 0));
					                    printf("\nBefore GRM_save_relation\n"); fflush(stdout);
					                    ITK_CALL(GRM_save_relation(relationCre));
					                    printf("\n GRM_save_relation:\n"); fflush(stdout);
					                    ITK_CALL(AOM_refresh(dataset2, 0));
					                }
	    						}
	    					}
	    					else
	    					{
	    						fprintf(NotFoundPart, "%s,%s,%s,%s,%s,%s,\n",tceCADBOMData[y].PartNo, tceCADBOMData[y].PartRev, tceCADBOMData[y].PartSeq,tceCADBOMData[y].CadBOMChild[z].ChildPartNo,tceCADBOMData[y].CadBOMChild[z].ChildPartRev,tceCADBOMData[y].CadBOMChild[z].ChildPartSeq); fflush(NotFoundPart);
	    						printf("Part Not Found %s-%s",tceCADBOMData[y].CadBOMChild[z].ChildPartNo,cRevision);
	    					}
				    	}
		            }
            	}
	    	}
	    }
	}

	iFail = ITK_exit_module(TRUE);
	printf("\nReturn Value is : %d", iFail);
	if (iFail == ITK_ok)
	{
		printf("\nTeamcenter Logout Success...");fflush(stdout);
	}
	else
	{
		EMH_ask_error_text(iFail, &cError);
		printf("\nError is : %s", cError);fflush(stdout);
	}
	return ITK_ok;
}