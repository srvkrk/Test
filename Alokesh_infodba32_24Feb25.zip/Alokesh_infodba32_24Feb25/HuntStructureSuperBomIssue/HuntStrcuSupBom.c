#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/aom_prop.h>
#include <ae/dataset.h>
#define ITK_err 910001

FILE  *output = NULL;
int iFail = 0;

typedef struct PosFile {
	char* ParentPart;
	char* ChildPart;
	char* MatPos1;
	char* MatPos2;
	char* MatPos3;
	char* MatPos4;
	char* MatPos5;
	char* MatPos6;
	char* MatPos7;
	char* MatPos8;
	char* MatPos9;
	char* MatPos10;
	char* MatPos11;
	char* MatPos12;
	char* MatPos13;
	char* MatPos14;
	char* MatPos15;
	char* MatPos16;
	char* OtherArg;
	char* SuppressInd;
} PosMat;

typedef struct StructureMgr {
	char* ParentPart;
	char* ChildPart;
	char* MatPos;
	logical SuppressInd;
} StrucMgr;

int ITK_CALL(int iFail)
{
	char* cError = NULL;
    if(iFail!=ITK_ok)
	{
	  EMH_ask_error_text(iFail, &cError);
	  printf("\n Error is : %s", cError);fflush(stdout);
	  exit(0);
	}
	return iFail;
}

int getchilds(int iNumber_Child,tag_t *tBOM_Children,char* PartNumber, char* PartRevSeq, char* posFileNm)
{
	int ifail = 0;
	int k=0,z=0;
	char* cItem_Id = NULL;
	char* cRevision =NULL;
	char* Tmatrix = NULL;
	char* DefaultTmatrix = NULL;
	int count1=0;
	tag_t *sub_childs=NULL;
	char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));
	int i=0;
	int j=0;
	int flag =0;
	int cnt =0;
	int n_found=0;
	int JtNo =0;
	int AsmPrt =0;
	int n_attchs_JT = 0;
	tag_t query = NULLTAG;
	tag_t* cntr_objects = NULLTAG;
	int entries =2;
	char *qry_entries[2]  = {"Item ID","Revision"};
	tag_t relation_type =NULLTAG;
	tag_t relation_type2 =NULLTAG;
	tag_t* rellist_JT =NULLTAG;
	tag_t* attachments =NULLTAG;
	tag_t dataset = NULLTAG;
	tag_t dataset2 = NULLTAG;
	char * objtype=NULL;
	char * objtype1=NULL;
	char * JTStatus =NULL;
	char *CadStatus = NULL;
	char *LatestRev 	= NULL;
	tag_t reva=NULLTAG;
	int Flag =0;
	char* PartType1 =NULL;
	char* PartType2 =NULL;
	int bl_Suppress=0;
	logical bl_Suppress_log;
	int statVal = 0;
	FILE *fpPosFile;
	char* blqty = NULL;
	char* ProFeatureID = NULL;
	int blqtyNum = 0;
	int stdpartprint = 0;
	PosMat* PosMatData = (PosMat*)MEM_alloc(1 * sizeof(PosMat));
	int MatFileRecCount = 0;
	StrucMgr* StrucData = (StrucMgr*)MEM_alloc(1 * sizeof(StrucMgr));
	int strucCnt = 0;
	char* cPartType = NULL;
	
	DefaultTmatrix="1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1";
	for(i=0;i<iNumber_Child;i++)
	{		
		ifail = (AOM_UIF_ask_value(tBOM_Children[i], "bl_item_item_id", &cItem_Id)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
		ifail = (AOM_UIF_ask_value(tBOM_Children[i], "bl_rev_item_revision_id", &cRevision)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
		ifail = (AOM_UIF_ask_value(tBOM_Children[i], "bl_plmxml_abs_xform", &Tmatrix)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
		ifail = (AOM_UIF_ask_value(tBOM_Children[i], "bl_quantity", &blqty)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
		ifail = (AOM_UIF_ask_value(tBOM_Children[i], "ProFeatureID", &ProFeatureID)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
		ifail = (AOM_UIF_ask_value(tBOM_Children[i], "bl_Design Revision_t5_PartType", &cPartType)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
		blqtyNum = atoi(blqty);
		printf("\nItem ID cRevision Tmatrix [%s] >: %s %s,%s",blqty,cItem_Id,cRevision,Tmatrix);fflush(stdout);
		//ifail = (BOM_line_look_up_attribute ("bl_is_occ_suppressed",&bl_Suppress)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
		//ifail = (BOM_line_ask_attribute_logical(tBOM_Children[i], bl_Suppress, &bl_Suppress_log));  if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
		ifail = (AOM_ask_value_logical(tBOM_Children[i], "bl_is_occ_suppressed", &bl_Suppress_log));  if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }	
		
		StrucData = (StrucMgr*)MEM_realloc(StrucData, (strucCnt+1) * sizeof(StrucMgr));
		StrucData[strucCnt].ParentPart = (char*)MEM_alloc( tc_strlen(PartNumber) *sizeof(char));
		StrucData[strucCnt].ChildPart = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
		StrucData[strucCnt].MatPos = (char*)MEM_alloc( tc_strlen(Tmatrix) *sizeof(char));
		tc_strcpy(StrucData[strucCnt].ParentPart, PartNumber);
		tc_strcpy(StrucData[strucCnt].ChildPart, cItem_Id);
		tc_strcpy(StrucData[strucCnt].MatPos, Tmatrix);
		StrucData[strucCnt].SuppressInd = bl_Suppress_log;
		strucCnt++;

		if (bl_Suppress_log == 0)
		{
			if (ProFeatureID == NULL && tc_strcmp(cPartType,"Group Id")!=0)
			{
				fprintf(output,"%s,%s,ProFeatureID_Missing,%d,%s,\n",PartNumber,PartRevSeq,iNumber_Child,cItem_Id);fflush(output);
			}
			else if (tc_strcmp(ProFeatureID,"")==0 && tc_strcmp(cPartType,"Group Id")!=0)
			{
				fprintf(output,"%s,%s,ProFeatureID_Missing,%d,%s,\n",PartNumber,PartRevSeq,iNumber_Child,cItem_Id);fflush(output);
			}
		}

		if (tc_strcmp(Tmatrix,"1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1")!=0 && bl_Suppress_log == 0)
		{
			flag=1;
			printf("-Not-DefaultTmatrix");fflush(stdout);
		}
		if (blqtyNum > 1 && tc_strlen(cItem_Id)==11 && tc_strcmp(Tmatrix,"1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1")==0 && stdpartprint == 0 && bl_Suppress_log == 0)
		{
			fprintf(output,"%s,%s,11_Digit_Part_Same_Pos,%d,%s,\n",PartNumber,PartRevSeq,iNumber_Child,cItem_Id);fflush(output);
			stdpartprint++;
		}									
	}
	//printf("\nAlokesh 1"); fflush(stdout);
	//if(flag==0)
	//{
	int posFilePresent = 0;
	fpPosFile=fopen(posFileNm,"r");
	//printf("\nAlokesh 2"); fflush(stdout);
	if(fpPosFile!=NULL)
	{
		const char delimiter[] = ",";
		char *token = NULL;
		posFilePresent = 1;
		char *inputline1=(char *) MEM_alloc(2000);
		while(fgets(inputline1,2000,fpPosFile)!=NULL)
		{
			//printf("\nAlokesh 10 - %s",inputline1); fflush(stdout);
		    token = strtok(inputline1, delimiter);
		    //printf("\nAlokesh 11"); fflush(stdout);
		    char strings[20][100];
		    int a = 0;
		    //printf("\nAlokesh 15"); fflush(stdout);
		    while (token != NULL && a < 20) {
		        tc_strcpy(strings[a], token);
		        token = strtok(NULL, delimiter);
		        a++;
		    }
		    //printf("\nAlokesh 3"); fflush(stdout);
		    PosMatData = (PosMat*)MEM_realloc(PosMatData, (MatFileRecCount+1) * sizeof(PosMat));
			PosMatData[MatFileRecCount].ParentPart = (char*)MEM_alloc( tc_strlen(strings[0]) *sizeof(char));
			PosMatData[MatFileRecCount].ChildPart = (char*)MEM_alloc( tc_strlen(strings[1]) *sizeof(char));
			PosMatData[MatFileRecCount].MatPos1 = (char*)MEM_alloc( tc_strlen(strings[2]) *sizeof(char));
			PosMatData[MatFileRecCount].MatPos2 = (char*)MEM_alloc( tc_strlen(strings[3]) *sizeof(char));
			PosMatData[MatFileRecCount].MatPos3 = (char*)MEM_alloc( tc_strlen(strings[4]) *sizeof(char));
			PosMatData[MatFileRecCount].MatPos4 = (char*)MEM_alloc( tc_strlen(strings[5]) *sizeof(char));
			PosMatData[MatFileRecCount].MatPos5 = (char*)MEM_alloc( tc_strlen(strings[6]) *sizeof(char));
			PosMatData[MatFileRecCount].MatPos6 = (char*)MEM_alloc( tc_strlen(strings[7]) *sizeof(char));
			PosMatData[MatFileRecCount].MatPos7 = (char*)MEM_alloc( tc_strlen(strings[8]) *sizeof(char));
			PosMatData[MatFileRecCount].MatPos8 = (char*)MEM_alloc( tc_strlen(strings[9]) *sizeof(char));
			PosMatData[MatFileRecCount].MatPos9 = (char*)MEM_alloc( tc_strlen(strings[10]) *sizeof(char));
			PosMatData[MatFileRecCount].MatPos10 = (char*)MEM_alloc( tc_strlen(strings[11]) *sizeof(char));
			PosMatData[MatFileRecCount].MatPos11 = (char*)MEM_alloc( tc_strlen(strings[12]) *sizeof(char));
			PosMatData[MatFileRecCount].MatPos12 = (char*)MEM_alloc( tc_strlen(strings[13]) *sizeof(char));
			PosMatData[MatFileRecCount].MatPos13 = (char*)MEM_alloc( tc_strlen(strings[14]) *sizeof(char));
			PosMatData[MatFileRecCount].MatPos14 = (char*)MEM_alloc( tc_strlen(strings[15]) *sizeof(char));
			PosMatData[MatFileRecCount].MatPos15 = (char*)MEM_alloc( tc_strlen(strings[16]) *sizeof(char));
			PosMatData[MatFileRecCount].MatPos16 = (char*)MEM_alloc( tc_strlen(strings[17]) *sizeof(char));
			PosMatData[MatFileRecCount].OtherArg = (char*)MEM_alloc( tc_strlen(strings[18]) *sizeof(char));
			PosMatData[MatFileRecCount].SuppressInd = (char*)MEM_alloc( tc_strlen(strings[19]) *sizeof(char));
			//printf("\nAlokesh 4"); fflush(stdout);
			tc_strcpy(PosMatData[MatFileRecCount].ParentPart, strings[0]);
			tc_strcpy(PosMatData[MatFileRecCount].ChildPart, strings[1]);
			tc_strcpy(PosMatData[MatFileRecCount].MatPos1, strings[2]);
			tc_strcpy(PosMatData[MatFileRecCount].MatPos2, strings[3]);
			tc_strcpy(PosMatData[MatFileRecCount].MatPos3, strings[4]);
			tc_strcpy(PosMatData[MatFileRecCount].MatPos4, strings[5]);
			tc_strcpy(PosMatData[MatFileRecCount].MatPos5, strings[6]);
			tc_strcpy(PosMatData[MatFileRecCount].MatPos6, strings[7]);
			tc_strcpy(PosMatData[MatFileRecCount].MatPos7, strings[8]);
			tc_strcpy(PosMatData[MatFileRecCount].MatPos8, strings[9]);
			tc_strcpy(PosMatData[MatFileRecCount].MatPos9, strings[10]);
			tc_strcpy(PosMatData[MatFileRecCount].MatPos10, strings[11]);
			tc_strcpy(PosMatData[MatFileRecCount].MatPos11, strings[12]);
			tc_strcpy(PosMatData[MatFileRecCount].MatPos12, strings[13]);
			tc_strcpy(PosMatData[MatFileRecCount].MatPos13, strings[14]);
			tc_strcpy(PosMatData[MatFileRecCount].MatPos14, strings[15]);
			tc_strcpy(PosMatData[MatFileRecCount].MatPos15, strings[16]);
			tc_strcpy(PosMatData[MatFileRecCount].MatPos16, strings[17]);
			tc_strcpy(PosMatData[MatFileRecCount].OtherArg, strings[18]);
			tc_strcpy(PosMatData[MatFileRecCount].SuppressInd, strings[19]);
			//printf("\nAlokesh 5"); fflush(stdout);
			MatFileRecCount++;
		}
		//printf("\nAlokesh 7"); fflush(stdout);
		fclose(fpPosFile);
		//printf("\nAlokesh 8"); fflush(stdout);
	}
	else
	{
		if(flag==0)
		{
			printf("File Open Failed--- %s",posFileNm); fflush(stdout);
			fprintf(output,"%s,%s,POSFile_not_Available-Default_T-Mat,%d,\n",PartNumber,PartRevSeq,iNumber_Child);fflush(output);
			statVal = 1;
		}
	}
	//printf("\nAlokesh 6"); fflush(stdout);
	int suppIssue=0;
	int defaultMatIssue=0;
	if (posFilePresent == 1)
	{
	for(i=0;i<strucCnt;i++)
	{
		for(j=0; j<MatFileRecCount; j++)
		{
			if (tc_strcasecmp(StrucData[i].ChildPart, PosMatData[j].ChildPart)==0)
			{
				if ((tc_strstr(PosMatData[j].SuppressInd,"True")!=NULL && StrucData[i].SuppressInd==1) || (tc_strstr(PosMatData[j].SuppressInd,"False")!=NULL && StrucData[i].SuppressInd==0))
			    {
			    	printf("-Supp OK-"); fflush(stdout);
			    }
			    else
			    {
			    	if (suppIssue == 0)
			    	{
			    		fprintf(output,"%s,%s,Wrong_Suppress_Indicator,%d,%s,\n",PartNumber,PartRevSeq,iNumber_Child,StrucData[i].ChildPart);fflush(output);
			    		suppIssue++;
			    	}
			    }

			    if (tc_strcmp(PosMatData[j].MatPos1,"1.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos2,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos3,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos4,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos5,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos6,"1.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos7,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos8,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos9,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos10,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos11,"1.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos12,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos13,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos14,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos15,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos16,"1.000000")==0)
			    {
			    	printf("-DeFault-"); fflush(stdout);
			    }
			    else
			    {
			    	if (tc_strcmp(StrucData[i].MatPos,"1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1")==0 && defaultMatIssue==0)
					{
						fprintf(output,"%s,%s,Deafault_T_Matrix,%d,%s,\n",PartNumber,PartRevSeq,iNumber_Child,PosMatData[j].ChildPart);fflush(output);
						defaultMatIssue++;
						statVal = 1;
					}
			    }
			    break;
			}
		}
		if (defaultMatIssue > 0 && suppIssue > 0)
		{
			break;
		}
	}
	}
	PosMatData = NULL;
	StrucData = NULL;
	//}
	printf("-END:getchilds-"); fflush(stdout);
	return statVal;
}


int ITK_user_main(int argc, char* argv[])
{
	int ifail = 0;
    char* cError = NULL;
	char* username = NULL;
	tag_t tuser = NULLTAG;
	iFail = ITK_auto_login();
	printf("\nReturn Value is : %d", iFail);fflush(stdout);
	int n_entries = 2;
	int i,j,k,l,m,n,cnt;
	tag_t tItemobj = NULLTAG;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	char *PartID = NULL;
	char *PartIDMaster = NULL;
	char *PartRevSeq =NULL;
	char *PartSequenceID = NULL;
	char *part_type = NULL;
	char *QuantityAttrId = NULL;
	char *Description = NULL;
	char *object_type = NULL;
	char *Part_ProjID = NULL;
	char *Part_DesgnGrp = NULL;
	char *Revision = NULL;
	tag_t DataSet = NULLTAG;
	char *inputfile=NULL;
	char * objtype1=NULL;
	tag_t* attachments =NULLTAG;
	tag_t* cntr_objects = NULLTAG;
	int iRev_Count = 0;
	tag_t* tRevList = NULLTAG;
	tag_t tWindow1 = NULLTAG;
	tag_t tBOMLine = NULLTAG;
	tag_t child_item=NULLTAG;
	tag_t child_rev=NULLTAG;
	char* cLevel = NULL;
	char* cRev_Name = NULL;
	char* cItem_Id = NULL;
	char* cRevision = NULL;
	char* cPartType = NULL;
	char* cSuppressInd = NULL;
	char* cParent = NULL;
	char* cOwn_Group = NULL;
	char* cOwn_User = NULL;
	char* cQuantity = NULL;
	char* cFind_No = NULL;
	char* cPacked = NULL;
	char* cDRAR = NULL;
	char* cPart_Type = NULL;
	tag_t rule = NULLTAG;
	tag_t rule1 = NULLTAG;
	
	tag_t dataset2 = NULLTAG;
	tag_t relation_type2 =NULLTAG;
	tag_t reln_type_ProMem =NULLTAG;
	int n_attchs_ProMem = 0;
	tag_t* rellist_ProMem_DsgnRev =NULLTAG;	
	int temp1 =0,z=0;
	int p = 0;
	int iNumber_Child = 0;
	char*   refnamePdf = NULL;
	char*   orig_Asmname = NULL;
	AE_reference_type_t     reftype;
	tag_t	refobject	=	NULLTAG;
	char *PartOwner = NULL;
	char *start_limit = NULL;
	char *end_limit = NULL;
	start_limit = ITK_ask_cli_argument("-s=");
	end_limit = ITK_ask_cli_argument("-e=");
	int strtl = 0;
	int endl = 0;
	int tot_asm_parts=0;
	if (start_limit != NULL)
	{
		if (tc_strcmp(start_limit,"")!=0)
		{
			strtl = atoi(start_limit);
		}
	}
	if (end_limit != NULL)
	{
		if (tc_strcmp(end_limit,"")!=0)
		{
			endl = atoi(end_limit);
		}
	}
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	char Data[100] = "";
	char outputFile[200] = "";
	strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"StrcutureIssue_%s_%d_%d.txt",Data,strtl,endl);		
	output = fopen(outputFile,"w");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
					
	char *cEntries[2]  = {"Item ID","Type"};
	char *inputline = NULL;
	char **cValues = (char **) MEM_alloc(50 * sizeof(char *));
	if (iFail == ITK_ok)
	{
		printf("\nTeamcenter Login Success...");fflush(stdout);
		POM_get_user(&username, &tuser);
		printf("\nUsername = %s", username);fflush(stdout);
	}
	else
	{
		EMH_ask_error_text(iFail, &cError);
		printf("\nError is : %s", cError);fflush(stdout);
	}
	if (cError)
	{
		MEM_free(cError);
	}
	if (username)
	{
		MEM_free(username);
	}
	tag_t itemrev = NULLTAG;
	char *posFileNm = (char*)MEM_alloc(250 * sizeof(char));
	tag_t iteamrev2 = NULLTAG;

	cEntries[0] ="object_type";
	cEntries[1] ="owning_user";
	cValues[0] = "Design";
	cValues[1] = "*loader*";

	/*cEntries[0] ="item_id";
	cEntries[1] ="object_type";
	cEntries[2] ="owning_user";
	cValues[0] = "518143700105";
	cValues[1] = "Design";
	cValues[2] = "*loader*";*/

	//ITK_CALL(QRY_find2("Design...",&tItemobj));
	ITK_CALL(ITEM_find_items_by_key_attributes(2, (const char **)cEntries, (const char **)cValues, &n_itemobj_found, &titemobj_results));
	printf("\n itemobj_found: %d",n_itemobj_found); fflush(stdout);

	if (endl > n_itemobj_found || endl==0)
	{
		endl = n_itemobj_found;
	}
	if (strtl > n_itemobj_found)
	{
		printf("\n Start Limit Greater than Total Data"); fflush(stdout);
		return ITK_ok;
	}
	
	for(j=strtl;j<endl;j++)
	{
		itemrev=titemobj_results[j];
		ifail = (AOM_ask_value_string(itemrev,"item_id",&PartIDMaster)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
		printf("\n\n %d- Master %s ->",j,PartIDMaster);fflush(stdout);
		if(itemrev != NULLTAG )
		{
			iteamrev2 = NULLTAG;
			ifail = (ITEM_ask_latest_rev(itemrev,&iteamrev2)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }

			tc_strcpy(posFileNm,"/proj/TMatrixFiles/");
			//iteamrev2 = titemobj_results[z];
			//iteamrev2 = *(tag_t*)(report[z][0]);

			ifail = (AOM_ask_value_string(iteamrev2,"item_id",&PartID)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
			ifail = (AOM_ask_value_string(iteamrev2,"item_revision_id",&PartRevSeq)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
			ifail = (AOM_UIF_ask_value(iteamrev2,"owning_user",&PartOwner)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
			if (tc_strstr(PartOwner,"aplloader")!=NULL)
			{
				continue;
			}
			if(tc_strstr(PartOwner,"loader")==NULL)
			{
				continue;
			}
			printf("%s-%s-",PartID,PartRevSeq); fflush(stdout);
			int ProAsmFind = 0;						
			ifail = (GRM_find_relation_type("IMAN_specification",&relation_type2)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
			ifail = (GRM_list_secondary_objects_only(iteamrev2,relation_type2,&cnt,&attachments)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
			for(k=0;k<cnt;k++)
			{
				dataset2=attachments[k];
				if( AOM_ask_value_string(dataset2,"object_type",&objtype1)!=ITK_ok);
				if (tc_strcmp(objtype1,"ProAsm")==0)
				{
					tot_asm_parts++;
					ifail = (AE_find_dataset_named_ref2(dataset2,0,&refnamePdf,&reftype,&refobject)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
					if (refobject != NULLTAG)
					{
						ifail = ( IMF_ask_original_file_name2(refobject,&orig_Asmname)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
						printf("\n ---orig_Asmname ----- :%s\n",orig_Asmname);
						char* Nm1stTok = NULL;
						char* Nm2ndTok = NULL;
						char* Nm3rdTok = NULL;
						Nm1stTok = tc_strtok(orig_Asmname,".");
						Nm2ndTok = tc_strtok(NULL,".");
						Nm3rdTok = tc_strtok(NULL,".");
						tc_strcat(posFileNm,Nm1stTok);
						tc_strcat(posFileNm,"_");
						tc_strcat(posFileNm,Nm3rdTok);
						tc_strcat(posFileNm,".pos");
						printf("POS File Name --- %s",posFileNm); fflush(stdout);
						ProAsmFind = 1;
						break;
					}
					else
					{
						ifail = (GRM_find_relation_type("IPEM_master_dependency",&relation_type2 )); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
						ifail = (GRM_list_secondary_objects_only(dataset2,relation_type2,&cnt,&attachments)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
						if (cnt > 0)
						{
							printf("\nCREO Instance - Skipping\n"); fflush(stdout);
						}
						else
						{
							fprintf(output,"%s,%s,ProASM Named ref Missing,\n",PartID,PartRevSeq);fflush(output);
							continue;
						}
					}
				}
			}
			if(ProAsmFind == 1)
			{
				ifail = (GRM_find_relation_type("Pro2_membership",&reln_type_ProMem)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
				ifail = (GRM_list_secondary_objects_only(dataset2,reln_type_ProMem,&n_attchs_ProMem,&rellist_ProMem_DsgnRev)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
				printf("\n PRO ASM relation found <%d>",n_attchs_ProMem);fflush(stdout);
				char* AsmPart = NULL;
				char **MembershipPartArray = (char **) MEM_alloc(1000 * sizeof(char *));
				int MemArrIndx = 0;
				if(n_attchs_ProMem>0)
				{									
					int x=0;
					for(x=0; x < n_attchs_ProMem ; x++)
					{
						ifail = (AOM_ask_value_string(rellist_ProMem_DsgnRev[x],"item_id",&AsmPart)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
						MembershipPartArray[MemArrIndx] = AsmPart;
						MemArrIndx++;
						printf("\n Pro assembly member ------>%s",AsmPart);fflush(stdout);
																
					}
				}
				else
				{
					fprintf(output,"%s,%s,CreoMemMissing,\n",PartID,PartRevSeq);fflush(output);
					continue;
				}
		
				tag_t tWindow = NULLTAG;
				tag_t tBOMLine1 = NULLTAG;
				tag_t* tBOM_Children = NULLTAG;
				ifail = (BOM_create_window( &tWindow)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
				ifail = (BOM_set_window_pack_all(tWindow, true)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
				ifail = (BOM_set_window_top_line( tWindow, NULLTAG, iteamrev2, NULLTAG, &tBOMLine1)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
				ifail = (BOM_window_show_suppressed (tWindow)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
				ifail = (BOM_line_ask_child_lines(tBOMLine1, &iNumber_Child, &tBOM_Children)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
				
				//printf("\n Return Value From Child Line API is --------> %d", iFail);fflush(stdout);
				printf("\n No of Children Found ---------> %d",iNumber_Child);fflush(stdout);
				temp1 =0;
				int Stmanager = 0;
				logical IsSuppres1;
				char **Ebom = (char **) MEM_alloc(1000 * sizeof(char *));
				char **EbomSppress = (char **) MEM_alloc(1000 * sizeof(char *));
				char **EbomPartType = (char **) MEM_alloc(1000 * sizeof(char *));
				char **Ebom2lvlGrp = (char **) MEM_alloc(1000 * sizeof(char *));
				int SupBom = 0;
				if(iNumber_Child>0)
				{
					int statVal = 0;	
					statVal = getchilds(iNumber_Child,tBOM_Children,PartID,PartRevSeq,posFileNm);	
					if (statVal == 1)
					{
						continue;
					}
					for(i=0;i<iNumber_Child;i++)
					{											
						tag_t bom_line_tag = NULLTAG;
						bom_line_tag = tBOM_Children[i];	
						ifail = (AOM_ask_value_string(bom_line_tag, "bl_item_item_id", &cItem_Id)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
						ifail = (AOM_ask_value_string(bom_line_tag, "bl_rev_item_revision_id", &cRevision)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
						ifail = (AOM_UIF_ask_value(bom_line_tag, "bl_Design Revision_t5_PartType", &cPartType)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
						ifail = (AOM_UIF_ask_value(bom_line_tag, "bl_is_occ_suppressed", &cSuppressInd)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
						Ebom[Stmanager] = cItem_Id;
						EbomSppress[Stmanager] = cSuppressInd;
						EbomPartType[Stmanager] = cPartType;
						Stmanager++;
						Ebom2lvlGrp[SupBom] = cItem_Id;
						SupBom++;
						if (tc_strcmp(cPartType,"Group Id")==0)
						{
							int iNumber_ChildG = 0;
							tag_t* tBOM_ChildrenG = NULLTAG;
							int g = 0;
							ifail = (BOM_line_ask_child_lines(bom_line_tag, &iNumber_ChildG, &tBOM_ChildrenG)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
							for(g=0;g<iNumber_ChildG;g++)
							{
								tag_t bom_line_tagG = NULLTAG;
								bom_line_tagG = tBOM_ChildrenG[g];	
								ifail = (AOM_ask_value_string(bom_line_tagG, "bl_item_item_id", &cItem_Id)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
								ifail = (AOM_ask_value_string(bom_line_tagG, "bl_rev_item_revision_id", &cRevision)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
								ifail = (AOM_UIF_ask_value(bom_line_tagG, "bl_Design Revision_t5_PartType", &cPartType)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
								ifail = (AOM_UIF_ask_value(bom_line_tagG, "bl_is_occ_suppressed", &cSuppressInd)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
								Ebom2lvlGrp[SupBom] = cItem_Id;
								SupBom++;
							}
						}
					}
				}	
				int flag =0, p=0;
				ifail = (BOM_close_window(tWindow)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
				for(k=0;k<MemArrIndx;k++)
				{						
					flag =0;								
					for(p=0;p<SupBom;p++)
					{
						if(tc_strcmp(MembershipPartArray[k],Ebom2lvlGrp[p])==0)
						{
							flag =1;
							break;
						}
					}
					if(flag ==0)
					{
						fprintf(output,"%s,%s,SuperBomMissing,%s,\n",PartID,PartRevSeq,MembershipPartArray[k]);fflush(output);
						break;
					}										
				}
				flag =0;
				p=0;
				for(k=0;k<Stmanager;k++)
				{						
					flag =0;								
					for(p=0;p<MemArrIndx;p++)
					{
						if(tc_strcmp(MembershipPartArray[p],Ebom[k])==0)
						{
							flag =1;
							break;
						}
					}
					
					if(flag ==0 && tc_strcmp(EbomSppress[k],"False")==0 && tc_strcmp(EbomPartType[k],"Group Id")!=0)
					{
						fprintf(output,"%s,%s,PartNotCAD_NeedToSuppress,%s,\n",PartID,PartRevSeq,Ebom[k]);fflush(output);
					}
				}
				MembershipPartArray = NULL;
				Ebom = NULL;
				EbomPartType = NULL;
				EbomSppress = NULL;
			}
			//printf("\n Return Value From BOM Close Window API is --------> %d", iFail);fflush(stdout);
		}
	}
	
	fprintf(output,"-,-,Total_ProAsmHunt,%d,\n",tot_asm_parts);fflush(output);

	iFail = ITK_exit_module(TRUE);
	printf("\nReturn Value is : %d", iFail);
	if (iFail == ITK_ok)
	{
		printf("\nTeamcenter Logout Success...");fflush(stdout);
	}
	else
	{
		EMH_ask_error_text(iFail, &cError);
		printf("\nError is : %s", cError);fflush(stdout);
	}		
	fclose(output);
	return ITK_ok;
}

