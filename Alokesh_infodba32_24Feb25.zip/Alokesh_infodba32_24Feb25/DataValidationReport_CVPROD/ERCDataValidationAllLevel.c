/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2023  MNM.  ALL RIGHTS RESERVED
*
*------------------------------------------------------------------------------
* Filename		: EbomCadBomCheck.c
* Description	: This Utility Used For ERC Migrated Data DataSet Validation, BVR and CREO Membership Checking in CVPROD
* Module       	: Report
* Since		    : 2023
* ENVIRONMENT	: C++, ITK
* History       : Automated Data Validation instead of Mannual Data Checking Activity
*------------------------------------------------------------------------------
*    Date         	   Name														Description of Change
* 30/03/2023   	   Alokesh Ghosh		          								Cad Bom Expenstion
* -----------------------------------------------------------------------------
*
* Double JT File 															- Both CREO Mem & 2 Structure 	- Double_JT
* Double Data Set CREO / CATIA												- Both CREO Mem & 2 Structure 	- Multi_CREO / Multi_CATIA / Multi_PDF
* Duplicate Part in CREO Membership 										- Only CREO Mem 				- Duplicate_CREOMem
* If Asm / CAD Product file then BVR Must be Present 						- Both CREO Mem & 2 Structure	- BVR_Not_Present
* If Asm file then CREO Membership / Generic Must be Present 				- Only CREO Mem 				- CREOMem_Missing
* Revision Effectivity Correct Or Not (Using Lexical Analysis, NR < A < B) 	- 2 Structure (Part Query)		- Revision_Mismatch
* Double DataSet CATIA (CADProd with CIM2AuxPart, but not CADPart)			- Both CREO Mem & 2 Structure	- Extra_CADPrt
* CATIA cgr and CADPart both doesnot need to be present / cgr need delete	- Both CREO Mem & 2 Structure	- Extra_CGR_File
* If Drawing Ind : D then check Drw File									- Both CREO Mem & 2 Structure	- DRW_Not_Present
* Check Double Drw File														- Both CREO Mem & 2 Structure	- Multi_DRW
* If DRW present then PDF should be Present 								- Both CREO Mem & 2 Structure	- PDF_Not_Available
* Obj Name: *WELD_Report* (Iman Spec) -> Named Ref Extension must be .csv 	- Both CREO Mem & 2 Structure	- WELD_Report_NamedRef_Issue
* CMI2Drawing (Object Type) must be in the relation -> IMAN_spec 			- Both CREO Mem & 2 Structure	- CMI2Drawing_Relation_Issue
* 
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/aom_prop.h>
#include <ae/dataset.h>
#define ITK_err 910001

//FILE  *output = NULL;
FILE *outputTCE = NULL;
int iFail = 0;
const char *revision_Order[] = {"NR", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a1", "b1", "c1", "d1", "e1", "f1", "g1", "h1", "i1", "j1", "k1", "l1", "m1", "n1", "o1", "p1", "q1", "r1", "s1", "t1", "u1", "v1", "w1", "x1", "y1", "z1", "a2", "b2", "c2", "d2", "e2", "f2", "g2", "h2", "i2", "j2", "k2", "l2", "m2", "n2", "o2", "p2", "q2", "r2", "s2", "t2", "u2", "v2", "w2", "x2", "y2", "z2", "a3", "b3", "c3", "d3", "e3", "f3", "g3", "h3", "i3", "j3", "k3", "l3", "m3", "n3", "o3", "p3", "q3", "r3", "s3", "t3", "u3", "v3", "w3", "x3", "y3", "z3", "a4", "b4", "c4", "d4", "e4", "f4", "g4", "h4", "i4", "j4", "k4", "l4", "m4", "n4", "o4", "p4", "q4", "r4", "s4", "t4", "u4", "v4", "w4", "x4", "y4", "z4", "a5", "b5", "c5", "d5", "e5", "f5", "g5", "h5", "i5", "j5", "k5", "l5", "m5", "n5", "o5", "p5", "q5", "r5", "s5", "t5", "u5", "v5", "w5", "x5", "y5", "z5", "a6", "b6", "c6", "d6", "e6", "f6", "g6", "h6", "i6", "j6", "k6", "l6", "m6", "n6", "o6", "p6", "q6", "r6", "s6", "t6", "u6", "v6", "w6", "x6", "y6", "z6", "a7", "b7", "c7", "d7", "e7", "f7", "g7", "h7", "i7", "j7", "k7", "l7", "m7", "n7", "o7", "p7", "q7", "r7", "s7", "t7", "u7", "v7", "w7", "x7", "y7", "z7", "a8", "b8", "c8", "d8", "e8", "f8", "g8", "h8", "i8", "j8", "k8", "l8", "m8", "n8", "o8", "p8", "q8", "r8", "s8", "t8", "u8", "v8", "w8", "x8", "y8", "z8", "a9", "b9", "c9", "d9", "e9", "f9", "g9", "h9", "i9", "j9", "k9", "l9", "m9", "n9", "o9", "p9", "q9", "r9", "s9", "t9", "u9", "v9", "w9", "x9", "y9", "z9"};
const int revision_length = 260;
int ctr=0;

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);fflush(stdout);
		  exit(0);
		}

		return iFail;
}

void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

// Function to apply XSLT transformation to an XML file
/*int applyXSLTTransformation(const char* xmlFilePath, const char* xsltFilePath, const char* outputFilePath) {
    xmlDocPtr doc, xsl, result;

    // Initialize libxml2 and libxslt
    xmlInitParser();
    xsltInit();

    // Load the XML document
    doc = xmlParseFile(xmlFilePath);
    if (doc == NULL) {
        fprintf(stderr, "Failed to parse XML file: %s\n", xmlFilePath);
        return ITK_err;
    }

    // Load the XSLT stylesheet
    xsl = xmlParseFile(xsltFilePath);
    if (xsl == NULL) {
        fprintf(stderr, "Failed to load XSLT stylesheet: %s\n", xsltFilePath);
        xmlFreeDoc(doc);
        return ITK_err;
    }

    // Compile the XSLT stylesheet
    xsltStylesheetPtr xslSheet;
    xslSheet = xsltParseStylesheetDoc(xsl);
    if (xslSheet == NULL) {
        fprintf(stderr, "Failed to compile XSLT stylesheet.\n");
        xmlFreeDoc(doc);
        xmlFreeDoc(xsl);
        return ITK_err;
    }

    // Perform the transformation
    result = xsltApplyStylesheet(xslSheet, doc, NULL);
    if (result != NULL) {
        // Save the transformed result to the output file
        if (xmlSaveFormatFile(outputFilePath, result, 1) < 0) {
            fprintf(stderr, "Failed to save transformed XML to: %s\n", outputFilePath);
        } else {
            printf("Transformation successful. Output saved to: %s\n", outputFilePath);
        }

        // Cleanup
        xsltFreeStylesheet(xslSheet);
        xmlFreeDoc(result);
    } else {
        fprintf(stderr, "Transformation failed.\n");
    }

    xmlFreeDoc(doc);
    //xmlFreeDoc(xsl);
    // Cleanup libxml2 and libxslt
    xsltCleanupGlobals();
    xmlCleanupParser();

    return ITK_ok;
}*/

typedef struct IssueReportData {
    char *cnt;
    char *PartNo;
    char *RevSeq;
    char *IssueCat;
    char *IssueDesc;
    char *SuggSol;
} IssueRep;

typedef struct CadBOMChildData {
    char *ChildPartNo;
} CadBOMChildStruct;

typedef struct CadBOMParentData {
    char *PartNo;
    char *PartRev;
    char *PartSeq;
    int chldCnt;
    CadBOMChildStruct* CadBOMChild;
} CadBOMStruct;

typedef struct EBOMChildData {
    char *ChildPartNo;
    char *ChildPartRev;
    char *ChildPartSeq;
    char *PartType;
    char *t5PartCode;
    char *t5DrawingInd;
    char *t5DrawingNo;
    char *ProjectName;
    char *Designgroup;
    char *t5Material;
    char *t5RolledupWt;
    char *t5UQdup;
    char *UsesPartQty;
    char *t5PartStatus;
    char *owninguser;
} EBOMChildStruct;

typedef struct EBOMParentData {
    char *PartNo;
    char *PartRev;
    char *PartSeq;
    char *owninguser;
    int chldCnt;
    EBOMChildStruct* EBOMChild;
} EBOMStruct;

typedef struct PosFile {
	char* ParentPart;
	char* ChildPart;
	char* MatPos1;
	char* MatPos2;
	char* MatPos3;
	char* MatPos4;
	char* MatPos5;
	char* MatPos6;
	char* MatPos7;
	char* MatPos8;
	char* MatPos9;
	char* MatPos10;
	char* MatPos11;
	char* MatPos12;
	char* MatPos13;
	char* MatPos14;
	char* MatPos15;
	char* MatPos16;
	char* OtherArg;
	char* SuppressInd;
} PosMat;

typedef struct StructureMgr {
	char* ParentPart;
	char* ChildPart;
	char* MatPos;
	logical SuppressInd;
} StrucMgr;

EBOMStruct* tcuaEBOMData;
int TcuaEbomSize = 0;
EBOMStruct* tcuaEBOMDataLatWrk;
int TcuaEbomSizeLatWrk = 0;
CadBOMStruct* tcuaCADBOMData;
int TcuaCadBomSize = 0;
IssueRep* IssueRepDt;
int issueDtCnt = 0;
int RepExtChk = 0;
int chk = 0;
char *RepExtChkChld;

int CheckTCUADML(char* Item_Id, char* Revision, char* Sequence)
{
	//CHECK DML
	int n_tskfund = 0;
	int *levelsaa;
	tag_t *referencers = NULLTAG;
	char **relations	=  NULL;
	int task = 0;
	tag_t tsk_dml_rel_type = NULLTAG;
	int dmlcnt = 0;
	tag_t *DMLRev = NULLTAG;
	char* DmlType = NULL;
	char* dmlNo = NULL ;
	char* dmlRelStat = NULL;
	int updRelzStatusDMLUA = 1;
	const int n_depth = 1;
	int k = 0;
	char* seqDup = NULL;
	char* CurName = NULL;
	tag_t tItemobj = NULLTAG;
	int n_itemobj_foundA = 0;
	char *cEntriesA[2]  = {"Item ID","Revision"};
	char **cValuesA = (char **) MEM_alloc(50 * sizeof(char *));
	tag_t* titemobj_resultsA = NULL;
	tag_t iteamrevC = NULLTAG;
	seqDup=(char *) MEM_alloc(10 * sizeof(char *));
	tc_strcpy(seqDup, Revision);
	tc_strcat(seqDup, ";");
	tc_strcat(seqDup, Sequence);
	cValuesA[0] = Item_Id;
	cValuesA[1] = seqDup;
	ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
	ITK_CALL(QRY_execute(tItemobj, 2, cEntriesA, cValuesA, &n_itemobj_foundA, &titemobj_resultsA));
	if(n_itemobj_foundA>0)
	{
		iteamrevC = titemobj_resultsA[0];
		ITK_CALL(WSOM_where_referenced2((const tag_t)iteamrevC,n_depth,&n_tskfund,&levelsaa,&referencers,&relations));
		printf("\nNo of Reference Found : %d",n_tskfund);fflush(stdout);
		if(n_tskfund>0)
		{
			for(task=0;task<n_tskfund;task++)
			{
				ITK_CALL(AOM_UIF_ask_value(referencers[task], "current_name", &CurName));
				//printf("\nCurrent Name: %s - %s",CurName,relations[task]); fflush(stdout);
				if (tc_strcmp(CurName,"Parts For Gate Maturation")==0)
				{
					int n_tskfund1 = 0;
					int *levelsaa1;
					tag_t *referencers1 = NULLTAG;
					char **relations1	=  NULL;
					int task1=0;
					ITK_CALL(WSOM_where_referenced2((const tag_t)referencers[task],n_depth,&n_tskfund1,&levelsaa1,&referencers1,&relations1));
					if(n_tskfund1>0)
					{
						for(task1=0;task1<n_tskfund1;task1++)
						{
							ITK_CALL(AOM_UIF_ask_value(referencers1[task1], "current_name", &CurName));
							//printf("\nCurrent Name: %s - %s",CurName,relations[task1]); fflush(stdout);
							ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
							ITK_CALL(GRM_list_primary_objects_only(referencers1[task1],tsk_dml_rel_type,&dmlcnt,&DMLRev));
							//printf("\nNo of DML found : %d",dmlcnt);fflush(stdout);
							DmlType = NULL;
							dmlNo = NULL ;
							dmlRelStat = NULL;
							for(k=0;k<dmlcnt;k++)
							{
								ITK_CALL(AOM_ask_value_string(DMLRev[k],"object_type",&DmlType));
								ITK_CALL(AOM_ask_value_string(DMLRev[k],"item_id",&dmlNo));
								ITK_CALL(AOM_UIF_ask_value(DMLRev[k],"release_status_list",&dmlRelStat));
								//printf("\n DML number, DmlType %s,%s",dmlNo,DmlType,dmlRelStat);
								if (tc_strstr(dmlRelStat,"ERC Released")!=NULL)
								{
									printf("\nDR Update Skipped. Part Released with DML: %s - %s",dmlNo, DmlType); fflush(stdout);
									updRelzStatusDMLUA = 0;
									break;
								}
							}
							if (updRelzStatusDMLUA ==0)
							{
								break;
							}
						}
					}
				}
				else
				{
					ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
					ITK_CALL(GRM_list_primary_objects_only(referencers[task],tsk_dml_rel_type,&dmlcnt,&DMLRev));
					//printf("\nNo of DML found : %d",dmlcnt);fflush(stdout);
					DmlType = NULL;
					dmlNo = NULL ;
					dmlRelStat = NULL;
					for(k=0;k<dmlcnt;k++)
					{
						ITK_CALL(AOM_ask_value_string(DMLRev[k],"object_type",&DmlType));
						ITK_CALL(AOM_ask_value_string(DMLRev[k],"item_id",&dmlNo));
						ITK_CALL(AOM_UIF_ask_value(DMLRev[k],"release_status_list",&dmlRelStat));
						printf("\n DML number, DmlType %s,%s",dmlNo,DmlType,dmlRelStat);
						if (tc_strstr(dmlRelStat,"ERC Released")!=NULL)
						{
							printf("\nDR Update Skipped. Part Released with DML: %s - %s",dmlNo, DmlType); fflush(stdout);
							updRelzStatusDMLUA = 0;
							break;
						}
					}
				}
				if (updRelzStatusDMLUA ==0)
				{
					break;
				}
			}
		}
	}
	return updRelzStatusDMLUA;
}

void AddIssueRepDt(char* cItem_Id, char* cRevision, char* IssueWith, char* IssueDesc, char* SuggSol)
{
	RepExtChk = 0;
	for (chk = 0; chk < issueDtCnt; ++chk)
	{
		if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,IssueDesc)==0)
		{
			RepExtChk = 1;
			if (tc_strstr(IssueRepDt[chk].IssueCat,IssueWith)==NULL)
			{
				tc_strcpy(RepExtChkChld, "");
				tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
				tc_strcat(RepExtChkChld, ",");
				tc_strcat(RepExtChkChld, IssueWith);
				IssueRepDt[chk].IssueCat = NULL;
				IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
				tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
			}
			break;
		}
	}
	if (RepExtChk == 0)
	{
		IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
		sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
		IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
		tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
		IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
		tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
		IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen(IssueWith) *sizeof(char));
		tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, IssueWith);
		IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen(IssueDesc) *sizeof(char));
		tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, IssueDesc);
		IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen(SuggSol) *sizeof(char));
		tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, SuggSol);
		issueDtCnt++;
	}
}

int checkNamedRefFile(char* cItem_Id, char* cRevision, char* refname2, char* objtypename, char* IssueWithType)
{
	char *compNmdRef = NULL;
	compNmdRef = tc_strtok(refname2,".");

	char* IssueWith = (char*)MEM_alloc(sizeof(char) * 100);
	tc_strcpy(IssueWith,"Wrong Named Ref : ");
	tc_strcat(IssueWith,IssueWithType);

	if(tc_strcasecmp(compNmdRef, objtypename) != 0)
	{
		AddIssueRepDt(cItem_Id,cRevision,IssueWith,"Data Set","Manual Correction");
	}
}

int checkNamedRefFilePDF(char* cItem_Id, char* cRevision, char* refname2, char* objtypename, char* IssueWithType)
{
	char *compNmdRef = NULL;
	compNmdRef = tc_strtok(refname2,".");

	char* IssueWith = (char*)MEM_alloc(sizeof(char) * 100);
	tc_strcpy(IssueWith,"Wrong Named Ref : ");
	tc_strcat(IssueWith,IssueWithType);

	char *compNmdRefUP = NULL;
	char *objtypenameUP = NULL;
	tc_strupr(compNmdRef, &compNmdRefUP);
	tc_strupr(objtypename, &objtypenameUP);

	//printf("\n\t refname2:[%s] ",refname2);
	if(tc_strstr(compNmdRefUP, objtypenameUP) == NULL)
	{
		AddIssueRepDt(cItem_Id,cRevision,IssueWith,"Data Set","Manual Correction");
	}
}

void ChkDataSetRelation(tag_t* DesignRevisionTagPrt)
{
	tag_t ItemRevTag = NULLTAG;
	ItemRevTag = *DesignRevisionTagPrt;

	tag_t relation_type =NULLTAG;
	tag_t relation_type2 =NULLTAG;
	tag_t relation_type3 = NULLTAG;
	int lp = 0;
	int n_attchs_JT = 0;
	int JTNmdRef = 0;
	int PDFNmdRef = 0;
	int JtNo=0;	
	int PdfNo =0;
	char *DrawingInd = NULL;
	int DrawingIndStat = 0;
	int j=0;
	tag_t dataset = NULLTAG;
	char *objtypename = NULL;
	char *datasetDispNm = NULL;
	char *objtype=NULL;
	char* cItem_Id = NULL;
	char* cRevision =NULL;
	char* PartOwner1 = NULL;
	tag_t* rellist_JT =NULL;
	/*tag_t ObjTypeTag = NULLTAG;
	char* ObjTypeNameProAsmMem = NULL;

	//Find Item Type
	ITK_CALL(TCTYPE_ask_object_type(ItemRevTag, &ObjTypeTag));
	ITK_CALL(TCTYPE_ask_name2(ObjTypeTag, &ObjTypeNameProAsmMem));
	printf("\nAlokesh 0 %s\n",ObjTypeNameProAsmMem); fflush(stdout);*/

	ITK_CALL(AOM_ask_value_string(ItemRevTag,"item_id",&cItem_Id));
	ITK_CALL(AOM_ask_value_string(ItemRevTag,"item_revision_id",&cRevision));
	ITK_CALL(AOM_UIF_ask_value(ItemRevTag,"owning_user",&PartOwner1));
	printf("\n\t\tChkDataSetRelation*************************Start"); fflush(stdout);
	printf("\nItem ID: %s %s - %s", cItem_Id,cRevision,PartOwner1);

	if (tc_strstr(PartOwner1,"loader")==NULL)
	{
		return;
	}
	logical checkout = 0;
	char* owning_group = NULL;
	ITK_CALL(AOM_UIF_ask_value(ItemRevTag,"owning_group",&owning_group));
	ITK_CALL(RES_is_checked_out(ItemRevTag,&checkout));
	printf("\n%s -- %s Owning User: %s -- Group : %s --- %d",cItem_Id,cRevision,PartOwner1,owning_group,checkout); fflush(stdout);
	if (checkout==1 && tc_strstr(PartOwner1,"loader")!=NULL && tc_strstr(PartOwner1,"aplloader")==NULL)
	{
		AddIssueRepDt(cItem_Id,cRevision,"Loader Data in Check-Out State","Part Property","Backend Correction");
	}
	if (tc_strstr(owning_group,"dba")!=NULL && tc_strstr(PartOwner1,"loader")!=NULL && tc_strstr(PartOwner1,"aplloader")==NULL)
	{
		AddIssueRepDt(cItem_Id,cRevision,"Loader Data in DBA Group : Change Ownership Required","Part Property","Backend Correction");
	}

	ITK_CALL(AOM_ask_value_string(ItemRevTag,"t5_DrawingInd",&DrawingInd)!=ITK_ok);
	if (DrawingInd != NULL)
    {
    	printf("\n\tDrawingInd : %s",DrawingInd);fflush(stdout);
    	if (tc_strcmp(DrawingInd,"D") == 0)
    	{
    		DrawingIndStat = 1;
    	}
    }
    //printf("\nAlokesh 1\n"); fflush(stdout);
	ITK_CALL(GRM_find_relation_type("IMAN_Rendering",&relation_type));
	ITK_CALL(GRM_list_secondary_objects_only(ItemRevTag,relation_type,&n_attchs_JT,&rellist_JT));
	char    **JTNmStore     =  (char **) MEM_alloc(100 * sizeof(char *));
	int JTStoreCnt = 0; int FndS =0 ;
	char    **PDFNmStore     =  (char **) MEM_alloc(100 * sizeof(char *));
	int PDFStoreCnt = 0;
	char    **CADPartNmStore     =  (char **) MEM_alloc(100 * sizeof(char *));
	int CADPrtStoreCnt = 0;
	char    **CADProductNmStore     =  (char **) MEM_alloc(100 * sizeof(char *));
	int CADProdStoreCnt = 0;
	//printf("\nAlokesh 2\n"); fflush(stdout);
	for(j=0;j<n_attchs_JT;j++)
	{
		dataset=rellist_JT[j];
		if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
		if( AOM_ask_value_string(dataset,"object_type",&objtype)!=ITK_ok);
		if(tc_strcmp(objtype,"DirectModel")==0)
		{
			char *cItem_IdUP = NULL;
			char *objtypenameUP = NULL;
			tc_strupr(cItem_Id, &cItem_IdUP);
			tc_strupr(objtypename, &objtypenameUP);

			if (tc_strstr(objtypenameUP, cItem_IdUP) != NULL)
			{
				if (JTStoreCnt == 0)
				{
					JTNmStore[0] = objtypename;
					JTStoreCnt++;
					JtNo++;
				}
				else
				{
					FndS = 0;
					for (lp = 0; lp < JTStoreCnt; ++lp)
					{
						if (tc_strcasecmp(JTNmStore[lp], objtypename)==0)
						{
							JtNo++;
							FndS = 1;
							break;
						}
					}
					if (FndS == 0)
					{
						JTNmStore[JTStoreCnt] = objtypename;
						JTStoreCnt++;
					}
				}
			}
			else
			{
				JtNo++;
			}

			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				JTNmdRef++;

				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"JT File");
			}
		}
		else if(tc_strcmp(objtype,"PDF")==0)
		{
			char *cItem_IdUP = NULL;
			char *objtypenameUP = NULL;
			tc_strupr(cItem_Id, &cItem_IdUP);
			tc_strupr(objtypename, &objtypenameUP);

			if (tc_strstr(objtypenameUP, cItem_IdUP) != NULL)
			{
				if (PDFStoreCnt == 0)
				{
					PDFNmStore[0] = objtypename;
					PDFStoreCnt++;
					PdfNo++;
				}
				else
				{
					FndS = 0;
					for (lp = 0; lp < PDFStoreCnt; ++lp)
					{
						if (tc_strcasecmp(PDFNmStore[lp], objtypename)==0)
						{
							PdfNo++;
							FndS = 1;
							break;
						}
					}
					if (FndS == 0)
					{
						PDFNmStore[PDFStoreCnt] = objtypename;
						PDFStoreCnt++;
					}
				}
			}
			else
			{
				PdfNo++;
			}

			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				PDFNmdRef++;

				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFilePDF(cItem_Id,cRevision,refname2,objtypename,"PDF File");
			}
		}
	}
	//printf("\nAlokesh 3\n"); fflush(stdout);
	if (JtNo == 0)
	{
		fprintf(outputTCE,"%s,%s,JT_Not_Available\n",cItem_Id,cRevision);fflush(outputTCE);
		printf("\nAlokesh 4\n"); fflush(stdout);
	}
	//Requested by Rajan - 14 Dec 2023
	/*else if(JtNo > 1)
	{
		//printf("\nAlokesh 5\n"); fflush(stdout);
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"Multi_JT")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "Multi_JT");
					IssueRepDt[chk].IssueCat = NULL;
					//MEM_free(IssueRepDt[chk].IssueCat);
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			//IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Multi_JT") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Multi_JT");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
		}
	}*/
	else if(JtNo == 1 && JTNmdRef == 0)
	{
		//printf("\nAlokesh 6\n"); fflush(stdout);
		AddIssueRepDt(cItem_Id,cRevision,"JT_NamedRef_Missing","Data Set","Manual Correction");
	}
	if (PdfNo == 0 && DrawingIndStat==1)
	{
		//printf("\nAlokesh 7\n"); fflush(stdout);
		fprintf(outputTCE,"%s,%s,PDF_Not_Available\n",cItem_Id,cRevision);fflush(outputTCE);
	}
	/*else if(PdfNo > 1 && DrawingIndStat==1)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"Multi_PDF")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "Multi_PDF");
					IssueRepDt[chk].IssueCat = NULL;
					//MEM_free(IssueRepDt[chk].IssueCat);
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			//IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Multi_PDF") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Multi_PDF");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
		}

		//fprintf(output,"%s,%s,Multi_PDF,Data Set,Manual Correction\n",cItem_Id,cRevision);fflush(output);
	}*/
	else if(PdfNo == 1 && DrawingIndStat==1 && PDFNmdRef == 0)
	{
		//printf("\nAlokesh 9\n"); fflush(stdout);
		AddIssueRepDt(cItem_Id,cRevision,"PDF_NamedRef_Missing","Data Set","Manual Correction");
	}

	int ProAsm =0;
	int ProPrt =0;
	int ProDrw =0;
	int CMI2CacheCgr =0;
	int CMI2AuxPart =0;
	int CMI2Part =0;
	int CMI2Product =0;
	int CMI2Drawing =0;
	int MSExcel =0;
	int ProAsmNmdRef =0;
	int ProPrtNmdRef =0;
	int ProDrwNmdRef =0;
	int CMI2CacheCgrNmdRef =0;
	int CMI2AuxPartNmdRef =0;
	int CMI2PartNmdRef =0;
	int CMI2ProductNmdRef =0;
	int CMI2DrawingNmdRef =0;
	int MSExcelNmdRef =0;
	//printf("\nAlokesh 10\n"); fflush(stdout);
	n_attchs_JT = 0;
	rellist_JT = NULLTAG;
	ITK_CALL(GRM_find_relation_type("IMAN_specification",&relation_type2));
	ITK_CALL(GRM_list_secondary_objects_only(ItemRevTag,relation_type2,&n_attchs_JT,&rellist_JT));
	for(j=0;j<n_attchs_JT;j++)
	{
		dataset=rellist_JT[j];
		if( AOM_ask_value_string(dataset,"object_name",&datasetDispNm)!=ITK_ok);
		if( AOM_ask_value_string(dataset,"object_type",&objtype)!=ITK_ok);
		if(tc_strcmp(objtype,"ProAsm")==0)
		{
			ProAsm++;
			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				ProAsmNmdRef++;

				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"ProAsm File");
			}
			else
			{
				tag_t tRelationFind = NULLTAG;
				int n_attchs_Genric = 0;
				tag_t *rellist_Genric = NULLTAG;
				ITK_CALL(GRM_find_relation_type("IPEM_master_dependency",&tRelationFind));
				ITK_CALL(GRM_list_secondary_objects_only(dataset,tRelationFind,&n_attchs_Genric,&rellist_Genric));
				if(n_attchs_Genric > 0)
				{
					ProAsmNmdRef++;
				}
			}
		}
		else if(tc_strcmp(objtype,"ProPrt")==0)
		{
			ProPrt++;
			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				ProPrtNmdRef++;

				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"ProPrt File");
			}
			else
			{
				tag_t tRelationFind = NULLTAG;
				int n_attchs_Genric = 0;
				tag_t *rellist_Genric = NULLTAG;
				ITK_CALL(GRM_find_relation_type("IPEM_master_dependency",&tRelationFind));
				ITK_CALL(GRM_list_secondary_objects_only(dataset,tRelationFind,&n_attchs_Genric,&rellist_Genric));
				if(n_attchs_Genric > 0)
				{
					ProPrtNmdRef++;
				}
			}
		}
		else if(tc_strcmp(objtype,"ProDrw")==0)
		{
			ProDrw++;
			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				ProDrwNmdRef++;
				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"ProDrw File");
			}
		}
		else if(tc_strcmp(objtype,"CMI2CacheCgr")==0)
		{
			CMI2CacheCgr++;
			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				CMI2CacheCgrNmdRef++;
				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"CMI2CacheCgr File");
			}
		}
		else if(tc_strcmp(objtype,"CMI2AuxPart")==0)
		{
			CMI2AuxPart++;
			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				CMI2AuxPartNmdRef++;
				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"CMI2AuxPart File");
			}
		}
		else if(tc_strcmp(objtype,"CMI2Part")==0)
		{
			//CMI2Part++;
			char *cItem_IdUP = NULL;
			char *objtypenameUP = NULL;
			tc_strupr(cItem_Id, &cItem_IdUP);
			tc_strupr(datasetDispNm, &objtypenameUP);
			if (tc_strstr(objtypenameUP, cItem_IdUP) != NULL)
			{
				if (CADPrtStoreCnt == 0)
				{
					CADPartNmStore[0] = datasetDispNm;
					CADPrtStoreCnt++;
					CMI2Part++;
				}
				else
				{
					FndS = 0;
					for (lp = 0; lp < CADPrtStoreCnt; ++lp)
					{
						if (tc_strcasecmp(CADPartNmStore[lp], datasetDispNm)==0)
						{
							CMI2Part++;
							FndS = 1;
							break;
						}
					}
					if (FndS == 0)
					{
						CADPartNmStore[CADPrtStoreCnt] = datasetDispNm;
						CADPrtStoreCnt++;
					}
				}
			}
			else
			{
				CMI2Part++;
			}

			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				CMI2PartNmdRef++;
				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"CMI2Part File");
			}
		}
		else if(tc_strcmp(objtype,"CMI2Product")==0)
		{
			//CMI2Product++;
			char *cItem_IdUP = NULL;
			char *objtypenameUP = NULL;
			tc_strupr(cItem_Id, &cItem_IdUP);
			tc_strupr(datasetDispNm, &objtypenameUP);
			if (tc_strstr(objtypenameUP, cItem_IdUP) != NULL)
			{
				if (CADProdStoreCnt == 0)
				{
					CADProductNmStore[0] = datasetDispNm;
					CADProdStoreCnt++;
					CMI2Product++;
				}
				else
				{
					FndS = 0;
					for (lp = 0; lp < CADProdStoreCnt; ++lp)
					{
						if (tc_strcasecmp(CADProductNmStore[lp], datasetDispNm)==0)
						{
							CMI2Product++;
							FndS = 1;
							break;
						}
					}
					if (FndS == 0)
					{
						CADProductNmStore[CADProdStoreCnt] = datasetDispNm;
						CADProdStoreCnt++;
					}
				}
			}
			else
			{
				CMI2Product++;
			}

			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				CMI2ProductNmdRef++;
				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"CMI2Product File");
			}
		}
		else if(tc_strcmp(objtype,"CMI2Drawing")==0)
		{
			CMI2Drawing++;
			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				CMI2DrawingNmdRef++;

				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"CMI2Drawing File");
			}
		}
		else if(tc_strcmp(objtype,"MSExcel")==0)
		{
			MSExcel++;
			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				MSExcelNmdRef++;

				char *refname2 = NULL;
				if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
				if (AOM_ask_value_string(DtNmRefObjs[0],"object_string",&refname2)!=ITK_ok);
				//checkNamedRefFile(cItem_Id,cRevision,refname2,objtypename,"MSExcel File");
			}
		}

		if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
		if(tc_strstr(objtypename,"WELD_Report")!=NULL || tc_strstr(objtypename,"weld_report")!=NULL || tc_strstr(objtypename,"Weld_Report")!=NULL)
		{
			int DtNmRefCnt = 0;
			tag_t *DtNmRefObjs = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
			if(DtNmRefCnt > 0)
			{
				tag_t RefObject_d = NULLTAG;
				char *named_ref = NULL;
				RefObject_d = DtNmRefObjs[0];
				if (AOM_ask_value_string(RefObject_d,"object_string",&named_ref)!=ITK_ok);
				if (tc_strstr(named_ref,".csv") == NULL)
				{
					AddIssueRepDt(cItem_Id,cRevision,"NamedRef_Not_CSV_WELD_Report","Data Set","Manual Correction");
				}
			}
			else
			{
				AddIssueRepDt(cItem_Id,cRevision,"No_NamedRef_WELD_Report","Data Set","Remigration of Part");
			}
		}
	}

	int refCMI2Drawing = 0;
	int refProDrw = 0;
	n_attchs_JT = 0;
	int refCMI2DrawingWronfRel= 0;
	int refProDrwWronfRel= 0;
	rellist_JT = NULLTAG;
	ITK_CALL(GRM_find_relation_type("IMAN_reference",&relation_type3));
	ITK_CALL(GRM_list_secondary_objects_only(ItemRevTag,relation_type3,&n_attchs_JT,&rellist_JT));
	for(j=0;j<n_attchs_JT;j++)
	{
		dataset=rellist_JT[j];
		if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
		if( AOM_ask_value_string(dataset,"object_type",&objtype)!=ITK_ok);
		if((tc_strcmp(objtype,"CMI2Drawing")==0) && (strcmp(cItem_Id,objtypename)!=0))
		{
			refCMI2Drawing++;
		}
		if((tc_strcmp(objtype,"ProDrw")==0) && (strcmp(cItem_Id,objtypename)!=0))
		{
			refProDrw++;
		}
		if((tc_strcmp(objtype,"CMI2Drawing")==0) && (strcmp(cItem_Id,objtypename)==0))
		{
			refCMI2DrawingWronfRel++;
		}
		if((tc_strcmp(objtype,"ProDrw")==0) && (strcmp(cItem_Id,objtypename)==0))
		{
			refProDrwWronfRel++;
		}
	}

	//printf("\nAlokesh 11\n"); fflush(stdout);
	if(refCMI2DrawingWronfRel > 0)
	{
		AddIssueRepDt(cItem_Id,cRevision,"CMI2Drawing_In_IMAN_reference","Data Set","Manual Correction");
	}
	//printf("\nAlokesh 102\n"); fflush(stdout);
	if(refProDrwWronfRel > 0)
	{
		AddIssueRepDt(cItem_Id,cRevision,"ProDrw_In_IMAN_reference","Data Set","Manual Correction");
	}

	//printf("\nAlokesh 103\n"); fflush(stdout);
	if(ProAsm == 0 && ProPrt == 0 && CMI2Part == 0 && CMI2Product == 0)
	{
		fprintf(outputTCE,"%s,%s,No_CAD_DataSet\n",cItem_Id,cRevision);fflush(outputTCE);
	}
	//printf("\nAlokesh 104\n"); fflush(stdout);
	if (ProDrw == 0 && CMI2Drawing == 0 && refCMI2Drawing ==0 && refProDrw==0 && DrawingIndStat==1)
	{
		fprintf(outputTCE,"%s,%s,Drawing_Not_Available\n",cItem_Id,cRevision);fflush(outputTCE);
	}

	//printf("\nAlokesh 105\n"); fflush(stdout);
	if(ProAsm > 1)
	{
		AddIssueRepDt(cItem_Id,cRevision,"Multi_ProAsm","Data Set","Manual Correction");
	}
	//printf("\nAlokesh 106\n"); fflush(stdout);
	if(ProPrt > 1)
	{
		AddIssueRepDt(cItem_Id,cRevision,"Multi_ProPrt","Data Set","Manual Correction");
	}
	//printf("\nAlokesh 107\n"); fflush(stdout);
	if(ProDrw > 1)
	{
		AddIssueRepDt(cItem_Id,cRevision,"Multi_ProDrw","Data Set","Manual Correction");
	}
	/*
	Commented As discussed with Rajan- Multi Allowed
	if(CMI2CacheCgr > 1)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			//if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Multi_CMI2CacheCgr")==0)
			//{
				//RepExtChk = 1;
			//}
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"Multi_CMI2CacheCgr")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "Multi_CMI2CacheCgr");
					IssueRepDt[chk].IssueCat = NULL;
					//MEM_free(IssueRepDt[chk].IssueCat);
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			//IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Multi_CMI2CacheCgr") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Multi_CMI2CacheCgr");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
		}
		//fprintf(output,"%s,%s,Multi_CMI2CacheCgr,Data Set,Manual Correction\n",cItem_Id,cRevision);fflush(output);
	}
	if(CMI2AuxPart > 1)
	{
		RepExtChk = 0;
		for (chk = 0; chk < issueDtCnt; ++chk)
		{
			//if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueCat,"Multi_CMI2AuxPart")==0)
			//{
				//RepExtChk = 1;
			//}
			if(tc_strcmp(IssueRepDt[chk].PartNo,cItem_Id)==0 && tc_strcmp(IssueRepDt[chk].RevSeq,cRevision)==0 && tc_strcmp(IssueRepDt[chk].IssueDesc,"Data Set")==0 && tc_strcmp(IssueRepDt[chk].SuggSol,"Manual Correction")==0)
			{
				RepExtChk = 1;
				if (tc_strstr(IssueRepDt[chk].IssueCat,"Multi_CMI2AuxPart")==NULL)
				{
					tc_strcpy(RepExtChkChld, "");
					tc_strcpy(RepExtChkChld, IssueRepDt[chk].IssueCat);
					tc_strcat(RepExtChkChld, ",");
					tc_strcat(RepExtChkChld, "Multi_CMI2AuxPart");
					IssueRepDt[chk].IssueCat = NULL;
					//MEM_free(IssueRepDt[chk].IssueCat);
					IssueRepDt[chk].IssueCat = (char*)MEM_alloc( tc_strlen(RepExtChkChld) *sizeof(char));
					//IssueRepDt[chk].IssueCat = (char*)MEM_realloc(IssueRepDt[chk].IssueCat, tc_strlen(RepExtChkChld) * sizeof(char));
					tc_strcpy(IssueRepDt[chk].IssueCat, RepExtChkChld);
				}
				break;
			}
		}
		if (RepExtChk == 0)
		{
			//IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( tc_strlen(cRevision) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, cRevision);
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Multi_CMI2AuxPart") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Multi_CMI2AuxPart");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Data Set") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Data Set");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Manual Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Manual Correction");
			issueDtCnt++;
		}
		//fprintf(output,"%s,%s,Multi_CMI2AuxPart,Data Set,Manual Correction\n",cItem_Id,cRevision);fflush(output);
	}
	*/
	//printf("\nAlokesh 108\n"); fflush(stdout);
	if(CMI2Part > 1)
	{
		AddIssueRepDt(cItem_Id,cRevision,"Multi_CMI2Part","Data Set","Manual Correction");
	}
	//printf("\nAlokesh 109\n"); fflush(stdout);
	if(CMI2Product > 1)
	{
		AddIssueRepDt(cItem_Id,cRevision,"Multi_CMI2Product","Data Set","Manual Correction");
	}
	//printf("\nAlokesh 110\n"); fflush(stdout);
	if(CMI2Drawing > 1)
	{
		AddIssueRepDt(cItem_Id,cRevision,"Multi_CMI2Drawing","Data Set","Manual Correction");
	}
	//printf("\nAlokesh 1011\n"); fflush(stdout);
	if(MSExcel > 1)
	{
		AddIssueRepDt(cItem_Id,cRevision,"Multi_MSExcel","Data Set","Manual Correction");
	}

	//printf("\nAlokesh 1012\n"); fflush(stdout);
	if(ProAsm == 1 && ProAsmNmdRef == 0)
	{
		AddIssueRepDt(cItem_Id,cRevision,"ProAsm_NamedRef_Missing","Data Set","Remigration of Part");
	}
	//printf("\nAlokesh 1013\n"); fflush(stdout);
	if(ProPrt == 1 && ProPrtNmdRef == 0)
	{
		AddIssueRepDt(cItem_Id,cRevision,"ProPrt_NamedRef_Missing","Data Set","Remigration of Part");
	}
	//printf("\nAlokesh 1014\n"); fflush(stdout);
	if(ProDrw == 1 && ProDrwNmdRef == 0)
	{
		AddIssueRepDt(cItem_Id,cRevision,"ProDrwNmdRef_Missing","Data Set","Remigration of Part");
	}
	//printf("\nAlokesh 1015\n"); fflush(stdout);
	if(CMI2CacheCgr == 1 && CMI2CacheCgrNmdRef == 0)
	{
		AddIssueRepDt(cItem_Id,cRevision,"CMI2CacheCgrNmdRef_Missing","Data Set","Remigration of Part");
	}
	//printf("\nAlokesh 1016\n"); fflush(stdout);
	if(CMI2AuxPart == 1 && CMI2AuxPartNmdRef == 0)
	{
		AddIssueRepDt(cItem_Id,cRevision,"CMI2AuxPartNmdRef_Missing","Data Set","Remigration of Part");
	}
	//printf("\nAlokesh 1017\n"); fflush(stdout);
	if(CMI2Part == 1 && CMI2PartNmdRef == 0)
	{
		AddIssueRepDt(cItem_Id,cRevision,"CMI2PartNmdRef_Missing","Data Set","Remigration of Part");
	}
	//printf("\nAlokesh 1018\n"); fflush(stdout);
	if(CMI2Product == 1 && CMI2ProductNmdRef == 0)
	{
		AddIssueRepDt(cItem_Id,cRevision,"CMI2ProductNmdRef_Missing","Data Set","Remigration of Part");
	}
	//printf("\nAlokesh 1019\n"); fflush(stdout);
	if(CMI2Drawing == 1 && CMI2DrawingNmdRef == 0)
	{
		AddIssueRepDt(cItem_Id,cRevision,"CMI2DrawingNmdRef_Missing","Data Set","Remigration of Part");
	}
	//printf("\nAlokesh 1020\n"); fflush(stdout);
	if(MSExcel == 1 && MSExcelNmdRef == 0)
	{
		AddIssueRepDt(cItem_Id,cRevision,"MSExcelNmdRef_Missing","Data Set","Remigration of Part");
	}
	//printf("\nAlokesh 1021\n"); fflush(stdout);
	if(CMI2Product > 0 && CMI2AuxPart > 0 && CMI2Part > 0)
	{
		AddIssueRepDt(cItem_Id,cRevision,"CMI2AuxPart_CMI2Part_Both_Present","Data Set","Manual Correction");
	}
	//printf("\nAlokesh 1022\n"); fflush(stdout);
	//if(ProAsm > 0 || CMI2Product > 0)
	if(ProAsm > 0)
	{
		//Check BVR Present Or Not on ItemRevTag
		int n_values_bvr=0;
		tag_t *bvr_assy_part = NULLTAG;
		ITK_CALL(ITEM_rev_list_bom_view_revs(ItemRevTag, &n_values_bvr, &bvr_assy_part));
		if(n_values_bvr < 1)
		{
			AddIssueRepDt(cItem_Id,cRevision,"No_BVR_in_Assembly","Structure Manager","Remigration of Part");
		}
	}
	printf("\n\t\tChkDataSetRelation*************************End"); fflush(stdout);
}

int ChkSuperBOMstructure(tag_t* StrucDsgnRev, char* IPItemID)
{
	int i=0;
	int j=0;
	int k=0;
	char *PartID = NULL;
	char *Revision = NULL;
	tag_t DataSet = NULLTAG;
	tag_t dataset2 = NULLTAG;
	char *inputfile=NULL;
	tag_t relation_type = NULLTAG;
	tag_t relation_type2 = NULLTAG;
	tag_t* rellist_JT = NULL;
	int n_attchs_JT =0;
	tag_t* attachments = NULL;
	tag_t itemrev = NULLTAG;
	int Part_Stat_Cnt = 0;
	tag_t *Part_Stat_Lst = NULLTAG;
	char * objtype=NULL;
	char * objtype1=NULL;
	char * PartRevID=NULL;
	char* refname = NULL;
	char* orig_Asmname = NULL;
	char* DataSetOwner = NULL;
	int referencenumberfound =0;
	AE_reference_type_t     reftype;
	tag_t refobject = NULLTAG;
	tag_t IPEMRelTag	= NULLTAG;
	tag_t* CreoGenTags = NULL;
	tag_t* rellist_ProMem_DsgnRev = NULL;
	int cnt=0;
	int ref_count_d = 0;
	tag_t* namRefObject_d = NULL;
	tag_t reln_type_ProMem =NULLTAG;
	int n_attchs_ProMem = 0;
	char *RlStatus = NULL;
	tag_t ObjTypeTag = NULLTAG;
	char* ObjTypeNameProAsmMem = NULL;
	RlStatus = (char *)MEM_alloc(250);
	itemrev=*StrucDsgnRev;

	ITK_CALL(TCTYPE_ask_object_type(itemrev, &ObjTypeTag));
	ITK_CALL(TCTYPE_ask_name2(ObjTypeTag, &ObjTypeNameProAsmMem));
	printf("\nObject Type %s\n",ObjTypeNameProAsmMem); fflush(stdout);
	if (tc_strcmp(ObjTypeNameProAsmMem,"Design Revision")==0)
	{
		return 1;
	}

	ITK_CALL(AOM_ask_value_string(itemrev,"item_id",&PartID));
	ITK_CALL(AOM_ask_value_string(itemrev,"item_revision_id",&PartRevID));
	printf("\n\t\tChkSuperBOMstructure*************************Start --%s--%s--",&PartID,&PartRevID); fflush(stdout);
	int CADPresent = 0;
	int ProAsmPresent = 0;
	int ProAsmMembership = 0;
	int y=0;
	int z=0;
	logical checkout = 0;
	char *tmpString = (char*)MEM_alloc(500 * sizeof(char));
	tc_strcpy(tmpString,"");

	char* TCOwner = NULL;
	char* owning_group = NULL;
	ITK_CALL(AOM_UIF_ask_value(itemrev,"owning_user",&TCOwner));
	ITK_CALL(AOM_UIF_ask_value(itemrev,"owning_group",&owning_group));
	ITK_CALL(RES_is_checked_out(itemrev,&checkout));
	printf("\n%s -- %s Owning User: %s -- Group : %s -- %d",PartID,PartRevID,TCOwner,owning_group,checkout); fflush(stdout);
	if (checkout==1 && tc_strstr(TCOwner,"loader")!=NULL && tc_strstr(TCOwner,"aplloader")==NULL)
	{
		AddIssueRepDt(PartID,PartRevID,"Loader Data in Check-Out State","Part Property","Backend Correction");
	}
	if (tc_strstr(owning_group,"dba")!=NULL && tc_strstr(TCOwner,"loader")!=NULL && tc_strstr(TCOwner,"aplloader")==NULL)
	{
		AddIssueRepDt(PartID,PartRevID,"Loader Data in DBA Group : Change Ownership Required","Part Property","Backend Correction");
	}

	char* PartID1 = NULL;
	char* PartRevID1 = NULL;
	tag_t query1 = NULLTAG;
	char **qry_values1 = (char **) MEM_alloc(100 * sizeof(char *));
	char* relStat = NULL;
	int n_found1 = 0;
	tag_t* cntr_objects1 = NULL;
	ITK_CALL(QRY_find2("Item Revision...",&query1));
	qry_values1[0] = IPItemID;
	char *qry_entries1[1]  = {"Item ID"};
	ITK_CALL(QRY_execute(query1, 1, qry_entries1, qry_values1, &n_found1, &cntr_objects1));
	if (n_found1 > 0)
	{
		for (k = 0; k < n_found1; ++k)
		{
			ITK_CALL(AOM_ask_value_string(cntr_objects1[k],"item_id",&PartID1));
			ITK_CALL(AOM_ask_value_string(cntr_objects1[k],"item_revision_id",&PartRevID1));
			ITK_CALL(AOM_UIF_ask_value(cntr_objects1[k],"release_status_list",&relStat));
			if (tc_strstr(relStat,"ERC Released")==NULL && tc_strstr(relStat,"Review")==NULL && tc_strstr(TCOwner,"loader")!=NULL && tc_strstr(TCOwner,"aplloader")==NULL)
			{
				AddIssueRepDt(PartID1,PartRevID1,"No ERC Status Flag","Part Property","Backend Correction");
			}

			ITK_CALL(AOM_UIF_ask_value(cntr_objects1[k],"owning_user",&TCOwner));
			ITK_CALL(AOM_UIF_ask_value(cntr_objects1[k],"owning_group",&owning_group));
			ITK_CALL(RES_is_checked_out(cntr_objects1[k],&checkout));
			if (checkout==1 && tc_strstr(TCOwner,"loader")!=NULL && tc_strstr(TCOwner,"aplloader")==NULL)
			{
				AddIssueRepDt(PartID1,PartRevID1,"Loader Data in Check-Out State","Part Property","Backend Correction");
			}
			if (tc_strstr(owning_group,"dba")!=NULL && tc_strstr(TCOwner,"loader")!=NULL && tc_strstr(TCOwner,"aplloader")==NULL)
			{
				AddIssueRepDt(PartID1,PartRevID1,"Loader Data in DBA Group : Change Ownership Required","Part Property","Backend Correction");
			}

		}
	}
	char* ParentRevDup = (char*)MEM_alloc(sizeof(char) * 20);
	char* partentRev = NULL;
	char* partentSeq = NULL;
	strcpy(ParentRevDup,PartRevID);
	partentRev = strtok(ParentRevDup,";");
	partentSeq = strtok(NULL,";");

	char *posFileNm = (char*)MEM_alloc(250 * sizeof(char));
	tc_strcpy(posFileNm,"/proj/TMatrixFiles/");

	PosMat* PosMatData = (PosMat*)MEM_alloc(1 * sizeof(PosMat));
	int MatFileRecCount = 0;
	StrucMgr* StrucData = (StrucMgr*)MEM_alloc(1 * sizeof(StrucMgr));
	int strucCnt = 0;

	ChkDataSetRelation(&itemrev);
	ITK_CALL(GRM_list_secondary_objects_only(itemrev,relation_type2,&cnt,&attachments));

	for(k=0;k<cnt;k++)
	{
		dataset2=attachments[k];
		if( AOM_ask_value_string(dataset2,"object_type",&objtype1)!=ITK_ok);
		if (tc_strcmp(objtype1,"ProAsm")==0)
		{
			ProAsmPresent = 1;
			int ref_count_d = 0;
			tag_t *namRefObject_d = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset2,&ref_count_d, &namRefObject_d));
			ITK_CALL(AOM_UIF_ask_value(dataset2,"owning_user",&DataSetOwner));
			if (tc_strstr(DataSetOwner,"loader")!=NULL && tc_strstr(DataSetOwner,"aplloader")==NULL && ref_count_d==1)
			{
				//logic for CREO Assembly - Super BOM, POS File Check, Multi Qty in Same pos
				ITK_CALL(AE_find_dataset_named_ref2(dataset2,0,&refname,&reftype,&refobject));
				if (refobject != NULLTAG)
				{
					ITK_CALL(IMF_ask_original_file_name2(refobject,&orig_Asmname));
					printf("\n ---orig_Asmname ----- :%s\n",orig_Asmname);
					char* Nm1stTok = NULL;
					char* Nm2ndTok = NULL;
					char* Nm3rdTok = NULL;
					Nm1stTok = tc_strtok(orig_Asmname,".");
					Nm2ndTok = tc_strtok(NULL,".");
					Nm3rdTok = tc_strtok(NULL,".");
					tc_strcat(posFileNm,Nm1stTok);
					tc_strcat(posFileNm,"_");
					tc_strcat(posFileNm,Nm3rdTok);
					tc_strcat(posFileNm,".pos");
					printf("POS File Name --- %s",posFileNm); fflush(stdout);
					int posFilePresent = 0;
					FILE *fpPosFile = fopen(posFileNm,"r");
					if(fpPosFile!=NULL)
					{
						const char delimiter[] = ",";
						char *token = NULL;
						char *inputline1=(char *) MEM_alloc(2000);
						while(fgets(inputline1,2000,fpPosFile)!=NULL)
						{
							posFilePresent++;
						    token = strtok(inputline1, delimiter);
						    char strings[20][100];
						    int a = 0;
						    while (token != NULL && a < 20) {
						        tc_strcpy(strings[a], token);
						        token = strtok(NULL, delimiter);
						        a++;
						    }
						    PosMatData = (PosMat*)MEM_realloc(PosMatData, (MatFileRecCount+1) * sizeof(PosMat));
							PosMatData[MatFileRecCount].ParentPart = (char*)MEM_alloc( tc_strlen(strings[0]) *sizeof(char));
							PosMatData[MatFileRecCount].ChildPart = (char*)MEM_alloc( tc_strlen(strings[1]) *sizeof(char));
							PosMatData[MatFileRecCount].MatPos1 = (char*)MEM_alloc( tc_strlen(strings[2]) *sizeof(char));
							PosMatData[MatFileRecCount].MatPos2 = (char*)MEM_alloc( tc_strlen(strings[3]) *sizeof(char));
							PosMatData[MatFileRecCount].MatPos3 = (char*)MEM_alloc( tc_strlen(strings[4]) *sizeof(char));
							PosMatData[MatFileRecCount].MatPos4 = (char*)MEM_alloc( tc_strlen(strings[5]) *sizeof(char));
							PosMatData[MatFileRecCount].MatPos5 = (char*)MEM_alloc( tc_strlen(strings[6]) *sizeof(char));
							PosMatData[MatFileRecCount].MatPos6 = (char*)MEM_alloc( tc_strlen(strings[7]) *sizeof(char));
							PosMatData[MatFileRecCount].MatPos7 = (char*)MEM_alloc( tc_strlen(strings[8]) *sizeof(char));
							PosMatData[MatFileRecCount].MatPos8 = (char*)MEM_alloc( tc_strlen(strings[9]) *sizeof(char));
							PosMatData[MatFileRecCount].MatPos9 = (char*)MEM_alloc( tc_strlen(strings[10]) *sizeof(char));
							PosMatData[MatFileRecCount].MatPos10 = (char*)MEM_alloc( tc_strlen(strings[11]) *sizeof(char));
							PosMatData[MatFileRecCount].MatPos11 = (char*)MEM_alloc( tc_strlen(strings[12]) *sizeof(char));
							PosMatData[MatFileRecCount].MatPos12 = (char*)MEM_alloc( tc_strlen(strings[13]) *sizeof(char));
							PosMatData[MatFileRecCount].MatPos13 = (char*)MEM_alloc( tc_strlen(strings[14]) *sizeof(char));
							PosMatData[MatFileRecCount].MatPos14 = (char*)MEM_alloc( tc_strlen(strings[15]) *sizeof(char));
							PosMatData[MatFileRecCount].MatPos15 = (char*)MEM_alloc( tc_strlen(strings[16]) *sizeof(char));
							PosMatData[MatFileRecCount].MatPos16 = (char*)MEM_alloc( tc_strlen(strings[17]) *sizeof(char));
							PosMatData[MatFileRecCount].OtherArg = (char*)MEM_alloc( tc_strlen(strings[18]) *sizeof(char));
							PosMatData[MatFileRecCount].SuppressInd = (char*)MEM_alloc( tc_strlen(strings[19]) *sizeof(char));
							tc_strcpy(PosMatData[MatFileRecCount].ParentPart, strings[0]);
							tc_strcpy(PosMatData[MatFileRecCount].ChildPart, strings[1]);
							tc_strcpy(PosMatData[MatFileRecCount].MatPos1, strings[2]);
							tc_strcpy(PosMatData[MatFileRecCount].MatPos2, strings[3]);
							tc_strcpy(PosMatData[MatFileRecCount].MatPos3, strings[4]);
							tc_strcpy(PosMatData[MatFileRecCount].MatPos4, strings[5]);
							tc_strcpy(PosMatData[MatFileRecCount].MatPos5, strings[6]);
							tc_strcpy(PosMatData[MatFileRecCount].MatPos6, strings[7]);
							tc_strcpy(PosMatData[MatFileRecCount].MatPos7, strings[8]);
							tc_strcpy(PosMatData[MatFileRecCount].MatPos8, strings[9]);
							tc_strcpy(PosMatData[MatFileRecCount].MatPos9, strings[10]);
							tc_strcpy(PosMatData[MatFileRecCount].MatPos10, strings[11]);
							tc_strcpy(PosMatData[MatFileRecCount].MatPos11, strings[12]);
							tc_strcpy(PosMatData[MatFileRecCount].MatPos12, strings[13]);
							tc_strcpy(PosMatData[MatFileRecCount].MatPos13, strings[14]);
							tc_strcpy(PosMatData[MatFileRecCount].MatPos14, strings[15]);
							tc_strcpy(PosMatData[MatFileRecCount].MatPos15, strings[16]);
							tc_strcpy(PosMatData[MatFileRecCount].MatPos16, strings[17]);
							tc_strcpy(PosMatData[MatFileRecCount].OtherArg, strings[18]);
							tc_strcpy(PosMatData[MatFileRecCount].SuppressInd, strings[19]);
							MatFileRecCount++;
						}
						fclose(fpPosFile);
					}

					tag_t tWindow = NULLTAG;
					tag_t tBOMLine1 = NULLTAG;
					tag_t* tBOM_Children = NULL;
					int iNumber_Child = 0;
					ITK_CALL(BOM_create_window( &tWindow));
					ITK_CALL(BOM_set_window_pack_all(tWindow, true));
					ITK_CALL(BOM_set_window_top_line( tWindow, NULLTAG, itemrev, NULLTAG, &tBOMLine1));
					ITK_CALL(BOM_window_show_suppressed (tWindow));
					ITK_CALL(BOM_line_ask_child_lines(tBOMLine1, &iNumber_Child, &tBOM_Children));
					printf("\n No of Children Found ---------> %d",iNumber_Child);fflush(stdout);

					ITK_CALL(GRM_find_relation_type("Pro2_membership",&reln_type_ProMem));
					ITK_CALL(GRM_list_secondary_objects_only(dataset2,reln_type_ProMem,&n_attchs_ProMem,&rellist_ProMem_DsgnRev));
					printf("\n PRO ASM relation found <%d>",n_attchs_ProMem);fflush(stdout);
					char* AsmPart = NULL;
					char **MembershipPartArray = (char **) MEM_alloc(1000 * sizeof(char *));
					int MemArrIndx = 0;
					tag_t ObjTypeTag = NULLTAG;
					char* ObjTypeNameProAsmMem = NULL;
					if(n_attchs_ProMem>0)
					{									
						int x=0;
						for(x=0; x < n_attchs_ProMem ; x++)
						{
							ITK_CALL(TCTYPE_ask_object_type(rellist_ProMem_DsgnRev[x], &ObjTypeTag));
							ITK_CALL(TCTYPE_ask_name2(ObjTypeTag, &ObjTypeNameProAsmMem));
							printf("\nAlokesh 0 %s\n",ObjTypeNameProAsmMem); fflush(stdout);
							
							if (tc_strcmp(ObjTypeNameProAsmMem,"Design Revision")==0)
							{
								ITK_CALL(AOM_ask_value_string(rellist_ProMem_DsgnRev[x],"item_id",&AsmPart));
								MembershipPartArray[MemArrIndx] = AsmPart;
								MemArrIndx++;
								printf("\n Pro assembly member ------>%s",AsmPart);fflush(stdout);
							}									
						}
					}
					else if (iNumber_Child > 0 || posFilePresent > 0)
					{
						//fprintf(output,"%s,%s,CreoMemMissing,\n",PartID,PartRevID);fflush(output);
						AddIssueRepDt(PartID,PartRevID,"Creo Membership Missing","CREO Membership","Backend Correction");
						continue;
					}
					char* cItem_Id = NULL;
					logical bl_Suppress_log;
					char* IPItemID = NULL;
					char* cRevision = NULL;
					char* Tmatrix = NULL;
					char* blqty = NULL;
					char* ProFeatureID = NULL;
					char* cPartType = NULL;
					int blqtyNum = 0;
					char* bl_Suppress = NULL;
					char* cSuppressInd = NULL;
					char* blUOM = NULL;
					int temp1 =0;
					int Stmanager = 0;
					int stdpartprint = 0;
					logical IsSuppres1;
					char **Ebom = (char **) MEM_alloc(1000 * sizeof(char *));
					char **EbomSppress = (char **) MEM_alloc(1000 * sizeof(char *));
					char **EbomPartType = (char **) MEM_alloc(1000 * sizeof(char *));
					char **Ebom2lvlGrp = (char **) MEM_alloc(1000 * sizeof(char *));
					char **EbomPartUOM = (char **) MEM_alloc(1000 * sizeof(char *));
					int SupBom = 0;
					if(iNumber_Child>0)
					{
						char* DefaultTmatrix = NULL;
						DefaultTmatrix="1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1";
						for(i=0;i<iNumber_Child;i++)
						{
							temp1 =0;
							ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_item_item_id", &cItem_Id));
							ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_rev_item_revision_id", &cRevision));
							ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_plmxml_abs_xform", &Tmatrix));
							ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_quantity", &blqty));
							ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "ProFeatureID", &ProFeatureID));
							ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_Design Revision_t5_PartType", &cPartType));
							blqtyNum = atoi(blqty);
							printf("\nItem ID cRevision Tmatrix [%s] >: %s %s,%s",blqty,cItem_Id,cRevision,Tmatrix);fflush(stdout);
							//ITK_CALL(BOM_line_look_up_attribute ("bl_is_occ_suppressed",&bl_Suppress));
							//ITK_CALL(BOM_line_ask_attribute_logical(tBOM_Children[i], bl_Suppress, &bl_Suppress_log));
							ITK_CALL(AOM_ask_value_logical(tBOM_Children[i], "bl_is_occ_suppressed", &bl_Suppress_log));
							
							StrucData = (StrucMgr*)MEM_realloc(StrucData, (strucCnt+1) * sizeof(StrucMgr));
							StrucData[strucCnt].ParentPart = (char*)MEM_alloc( tc_strlen(PartID) *sizeof(char));
							StrucData[strucCnt].ChildPart = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
							StrucData[strucCnt].MatPos = (char*)MEM_alloc( tc_strlen(Tmatrix) *sizeof(char));
							tc_strcpy(StrucData[strucCnt].ParentPart, PartID);
							tc_strcpy(StrucData[strucCnt].ChildPart, cItem_Id);
							tc_strcpy(StrucData[strucCnt].MatPos, Tmatrix);
							StrucData[strucCnt].SuppressInd = bl_Suppress_log;
							strucCnt++;

							if (bl_Suppress_log == 0)
							{
								if (ProFeatureID == NULL && tc_strcmp(cPartType,"Group Id")!=0 && bl_Suppress_log == 0)
								{
									//fprintf(output,"%s,%s,ProFeatureID_Missing,%d,%s,\n",PartID,PartRevID,iNumber_Child,cItem_Id);fflush(output);
									tc_strcpy(tmpString,"Proe FeatureID Missing : ");
									tc_strcat(tmpString,cItem_Id);
									AddIssueRepDt(PartID,PartRevID,tmpString,"Structure Manager","Backend Correction");
									temp1 = 1;
								}
								else if (tc_strcmp(ProFeatureID,"")==0 && tc_strcmp(cPartType,"Group Id")!=0 && bl_Suppress_log == 0)
								{
									//fprintf(output,"%s,%s,ProFeatureID_Missing,%d,%s,\n",PartID,PartRevID,iNumber_Child,cItem_Id);fflush(output);
									tc_strcpy(tmpString,"Proe FeatureID Missing : ");
									tc_strcat(tmpString,cItem_Id);
									AddIssueRepDt(PartID,PartRevID,tmpString,"Structure Manager","Backend Correction");
									temp1 = 1;
								}
							}

							/*if (tc_strcmp(Tmatrix,"1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1")!=0 && bl_Suppress_log == 0)
							{
								flag=1;
								printf("-Not-DefaultTmatrix");fflush(stdout);
							}*/
							if (temp1 > 0 && blqtyNum > 1 && tc_strlen(cItem_Id)==11 && tc_strcmp(Tmatrix,"1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1")==0 && stdpartprint == 0 && bl_Suppress_log == 0)
							{
								//fprintf(output,"%s,%s,11_Digit_Part_Same_Pos,%d,%s,\n",PartID,PartRevID,iNumber_Child,cItem_Id);fflush(output);
								tc_strcpy(tmpString,"11_Digit_Part_Same_Pos : ");
								tc_strcat(tmpString,cItem_Id);
								AddIssueRepDt(PartID,PartRevID,tmpString,"Structure Manager","Backend Correction");
								stdpartprint++;
							}									
						}

						int statVal = 0;
						int suppIssue=0;
						int defaultMatIssue=0;
						if (posFilePresent == 1)
						{
						for(i=0;i<strucCnt;i++)
						{
							for(j=0; j<MatFileRecCount; j++)
							{
								if (tc_strcasecmp(StrucData[i].ChildPart, PosMatData[j].ChildPart)==0)
								{
									if ((tc_strstr(PosMatData[j].SuppressInd,"True")!=NULL && StrucData[i].SuppressInd==1) || (tc_strstr(PosMatData[j].SuppressInd,"False")!=NULL && StrucData[i].SuppressInd==0))
								    {
								    	printf("-Supp OK-"); fflush(stdout);
								    }
								    else
								    {
								    	if (suppIssue == 0)
								    	{
								    		//fprintf(output,"%s,%s,Wrong_Suppress_Indicator,%d,%s,\n",PartID,PartRevID,iNumber_Child,StrucData[i].ChildPart);fflush(output);
								    		tc_strcpy(tmpString,"Wrong_Suppress_Indicator : ");
											tc_strcat(tmpString,StrucData[i].ChildPart);
											AddIssueRepDt(PartID,PartRevID,tmpString,"Structure Manager","Backend Correction");
								    		suppIssue++;
								    	}
								    }

								    if (tc_strcmp(PosMatData[j].MatPos1,"1.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos2,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos3,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos4,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos5,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos6,"1.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos7,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos8,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos9,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos10,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos11,"1.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos12,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos13,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos14,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos15,"0.000000000000000000000000000000")==0 && tc_strcmp(PosMatData[j].MatPos16,"1.000000")==0)
								    {
								    	printf("-DeFault-"); fflush(stdout);
								    }
								    else
								    {
								    	if (tc_strcmp(StrucData[i].MatPos,"1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1")==0 && defaultMatIssue==0)
										{
											//fprintf(output,"%s,%s,Deafault_T_Matrix,%d,%s,\n",PartID,PartRevID,iNumber_Child,PosMatData[j].ChildPart);fflush(output);
											tc_strcpy(tmpString,"Deafault_T_Matrix : ");
											tc_strcat(tmpString,PosMatData[j].ChildPart);
											AddIssueRepDt(PartID,PartRevID,tmpString,"Structure Manager","Backend Correction");
											defaultMatIssue++;
											statVal = 1;
										}
								    }
								    break;
								}
							}
							if (defaultMatIssue > 0 && suppIssue > 0)
							{
								break;
							}
						}
						}
						PosMatData = NULL;
						StrucData = NULL;
						if (statVal == 0)
						{
							for(i=0;i<iNumber_Child;i++)
							{											
								tag_t bom_line_tag = NULLTAG;
								bom_line_tag = tBOM_Children[i];	
								ITK_CALL(AOM_ask_value_string(bom_line_tag, "bl_item_item_id", &cItem_Id));
								ITK_CALL(AOM_ask_value_string(bom_line_tag, "bl_rev_item_revision_id", &cRevision));
								ITK_CALL(AOM_UIF_ask_value(bom_line_tag, "bl_Design Revision_t5_PartType", &cPartType));
								ITK_CALL(AOM_UIF_ask_value(bom_line_tag, "bl_is_occ_suppressed", &cSuppressInd));
								ITK_CALL(AOM_UIF_ask_value(bom_line_tag, "bl_uom", &blUOM));
								Ebom[Stmanager] = cItem_Id;
								EbomSppress[Stmanager] = cSuppressInd;
								EbomPartType[Stmanager] = cPartType;
								EbomPartUOM[Stmanager] = blUOM;
								Stmanager++;
								Ebom2lvlGrp[SupBom] = cItem_Id;
								SupBom++;
								if (tc_strcmp(cPartType,"Group Id")==0)
								{
									int iNumber_ChildG = 0;
									tag_t* tBOM_ChildrenG = NULL;
									int g = 0;
									ITK_CALL(BOM_line_ask_child_lines(bom_line_tag, &iNumber_ChildG, &tBOM_ChildrenG));
									for(g=0;g<iNumber_ChildG;g++)
									{
										tag_t bom_line_tagG = NULLTAG;
										bom_line_tagG = tBOM_ChildrenG[g];	
										ITK_CALL(AOM_ask_value_string(bom_line_tagG, "bl_item_item_id", &cItem_Id));
										ITK_CALL(AOM_ask_value_string(bom_line_tagG, "bl_rev_item_revision_id", &cRevision));
										ITK_CALL(AOM_UIF_ask_value(bom_line_tagG, "bl_Design Revision_t5_PartType", &cPartType));
										ITK_CALL(AOM_UIF_ask_value(bom_line_tagG, "bl_is_occ_suppressed", &cSuppressInd));
										Ebom2lvlGrp[SupBom] = cItem_Id;
										SupBom++;
									}
								}
							}
						}
					}	
					int flag =0, p=0;
					ITK_CALL(BOM_close_window(tWindow));
					int kl = 0;
					for(kl=0;kl<MemArrIndx;kl++)
					{						
						flag =0;								
						for(p=0;p<SupBom;p++)
						{
							if(tc_strcmp(MembershipPartArray[kl],Ebom2lvlGrp[p])==0)
							{
								flag =1;
								break;
							}
						}
						if(flag ==0)
						{
							//fprintf(output,"%s,%s,SuperBomMissing,%s,\n",PartID,PartRevID,MembershipPartArray[kl]);fflush(output);
							tc_strcpy(tmpString,"SuperBomMissing : ");
							tc_strcat(tmpString,MembershipPartArray[kl]);
							AddIssueRepDt(PartID,PartRevID,tmpString,"Structure Manager","Backend Correction");
							break;
						}										
					}
					flag =0;
					p=0;
					for(kl=0;kl<Stmanager;kl++)
					{						
						flag =0;								
						for(p=0;p<MemArrIndx;p++)
						{
							if(tc_strcmp(MembershipPartArray[p],Ebom[kl])==0)
							{
								flag =1;
								break;
							}
						}
						
						if(flag ==0 && tc_strcmp(EbomSppress[kl],"False")==0 && tc_strcmp(EbomPartType[kl],"Group Id")!=0)
						{
							//fprintf(output,"%s,%s,PartNotCAD_NeedToSuppress,%s,\n",PartID,PartRevID,Ebom[kl]);fflush(output);
							tc_strcpy(tmpString,"Part not in CAD- NeedToSuppress/NeedToAddInCREOMembership : ");
							tc_strcat(tmpString,Ebom[kl]);
							AddIssueRepDt(PartID,PartRevID,tmpString,"Structure Manager","Backend Correction");
						}
						
						if(flag ==0 && tc_strcmp(EbomSppress[kl],"False")==0 && tc_strcmp(EbomPartType[kl],"Group Id")==0 && (tc_strcmp(EbomPartUOM[kl],"each")==0 || tc_strcmp(EbomPartUOM[kl],"4-Nos")==0))
						{
							//fprintf(output,"%s,%s,PartNotCAD_NeedToSuppress,%s,\n",PartID,PartRevID,Ebom[kl]);fflush(output);
							tc_strcpy(tmpString,"User Action : Group ID not used in CAD : ");
							tc_strcat(tmpString,Ebom[kl]);
							AddIssueRepDt(PartID,PartRevID,tmpString,"Structure Manager","User need to Correct");
						}
					}
					MembershipPartArray = NULL;
					Ebom = NULL;
					EbomPartType = NULL;
					EbomSppress = NULL;
				}
			}
		}
	}

	tmpString = NULL;
	posFileNm = NULL;
	ParentRevDup = NULL;
	printf("\n\t\tChkSuperBOMstructure*************************END"); fflush(stdout);
	return 1;
}

void ChkDataSetCreoMem(tag_t* rellst_ProMem_DsgnRev)
{
	int n_entries = 1;
	int i=0;
	int JtNo=0;
	int j=0;
	int k=0;
	int n_genIns =0;
	tag_t tItemobj = NULLTAG;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULL;
	char *PartID = NULL;
	char *PartSequenceID = NULL;
	char *Part_Rlz_Stat = NULL;
	char *part_type = NULL;
	char *Description = NULL;
	char *object_type = NULL;
	char *Part_ProjID = NULL;
	char *Part_DesgnGrp = NULL;
	char *Revision = NULL;
	tag_t DataSet = NULLTAG;
	tag_t dataset2 = NULLTAG;
	char *inputfile=NULL;
	tag_t relation_type = NULLTAG;
	tag_t relation_type2 = NULLTAG;
	tag_t* rellist_JT = NULL;
	int n_attchs_JT =0;
	tag_t* attachments = NULL;
	tag_t itemrev = NULLTAG;
	int Part_Stat_Cnt = 0;
	tag_t *Part_Stat_Lst = NULLTAG;
	char * objtype=NULL;
	char * objtype1=NULL;
	char * PartRevID=NULL;
	char* refname = NULL;
	char* orig_Asmname = NULL;
	char* DataSetOwner = NULL;
	int referencenumberfound =0;
	AE_reference_type_t     reftype;
	tag_t refobject = NULLTAG;
	tag_t IPEMRelTag	= NULLTAG;
	tag_t* CreoGenTags = NULL;
	int cnt=0;
	int ref_count_d = 0;
	tag_t* namRefObject_d = NULL;
	tag_t* rellist_ProMem_DsgnRev = NULL;
	tag_t reln_type_ProMem =NULLTAG;
	int n_attchs_ProMem = 0;
	JtNo=0;
	char *RlStatus = NULL;
	RlStatus = (char *)MEM_alloc(250);
	itemrev=*rellst_ProMem_DsgnRev;
	ITK_CALL(AOM_ask_value_string(itemrev,"item_id",&PartID));
	ITK_CALL(AOM_ask_value_string(itemrev,"item_revision_id",&PartRevID));
	printf("\n\t\tChkDataSetCreoMem*************************Start -- %s ---- %s",PartID,PartRevID); fflush(stdout);
	int CADPresent = 0;
	int ProAsmPresent = 0;
	int ProAsmMembership = 0;
	int y=0;
	int z=0;

	char* TCOwner = NULL;
	char* owning_group = NULL;
	logical checkout = 0;
	ITK_CALL(AOM_UIF_ask_value(itemrev,"owning_user",&TCOwner));
	ITK_CALL(AOM_UIF_ask_value(itemrev,"owning_group",&owning_group));
	ITK_CALL(RES_is_checked_out(itemrev,&checkout));
	printf("\n%s -- %s Owning User: %s -- Group : %s -- %d",PartID,PartRevID,TCOwner,owning_group,checkout); fflush(stdout);
	if (checkout==1 && tc_strstr(TCOwner,"loader")!=NULL && tc_strstr(TCOwner,"aplloader")==NULL)
	{
		AddIssueRepDt(PartID,PartRevID,"Loader Data in Check-Out State","Part Property","Backend Correction");
	}
	if (tc_strstr(owning_group,"dba")!=NULL && tc_strstr(TCOwner,"loader")!=NULL && tc_strstr(TCOwner,"aplloader")==NULL)
	{
		AddIssueRepDt(PartID,PartRevID,"Loader Data in DBA Group : Change Ownership Required","Part Property","Backend Correction");
	}

	tag_t ObjTypeTag = NULLTAG;
	char* ObjTypeNameProAsmMem = NULL;

	char* ParentRevDup = (char*)MEM_alloc(sizeof(char) * 20);
	char* partentRev = NULL;
	char* partentSeq = NULL;
	strcpy(ParentRevDup,PartRevID);
	partentRev = strtok(ParentRevDup,";");
	partentSeq = strtok(NULL,";");

	//Find Item Type
	/*ITK_CALL(TCTYPE_ask_object_type(itemrev, &ObjTypeTag));
	ITK_CALL(TCTYPE_ask_name2(ObjTypeTag, &ObjTypeNameProAsmMem));
	printf("\nAlokesh 0 %s\n",ObjTypeNameProAsmMem); fflush(stdout);
	
	if (tc_strcmp(ObjTypeNameProAsmMem,"Design Revision")!=0)
	{
		return;
	}*/
	ChkDataSetRelation(&itemrev);
	ITK_CALL(GRM_list_secondary_objects_only(itemrev,relation_type2,&cnt,&attachments));

	//Check for Double Data Set
	for(k=0;k<cnt;k++)
	{
		dataset2=attachments[k];
	
		if( AOM_ask_value_string(dataset2,"object_type",&objtype1)!=ITK_ok);
		
		
		if (tc_strcmp(objtype1,"ProAsm")==0)
		{
			ProAsmPresent = 1;
			int ref_count_d = 0;
			tag_t *namRefObject_d = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset2,&ref_count_d, &namRefObject_d));
			if(ref_count_d > 0)
			{
				CADPresent = 1;
				/// Pro Assembly member relationship
				ITK_CALL(GRM_find_relation_type("Pro2_membership",&reln_type_ProMem));
				ITK_CALL(GRM_list_secondary_objects_only(dataset2,reln_type_ProMem,&n_attchs_ProMem,&rellist_ProMem_DsgnRev));
				//printf("\n PRO ASM relation found <%d> \n",n_attchs_ProMem);fflush(stdout);
				if(n_attchs_ProMem>0)
				{
					ProAsmMembership = 1;
					int x=0;
					//Create another Loop and Check If there any Duplicate Part in CREO Membership and write in File
					char **MembershipPartArray = (char **) MEM_alloc(1000 * sizeof(char *));
					for(x=0; x < n_attchs_ProMem ; x++)
					{
						char *CreoMemPartID = NULL;
						tag_t CreoMemObj = NULLTAG;
						CreoMemObj = rellist_ProMem_DsgnRev[x];

						ITK_CALL(TCTYPE_ask_object_type(CreoMemObj, &ObjTypeTag));
						ITK_CALL(TCTYPE_ask_name2(ObjTypeTag, &ObjTypeNameProAsmMem));
						if(tc_strcmp(ObjTypeNameProAsmMem,"Design Revision")!=0)
						{
							continue;
						}

						ITK_CALL(AOM_ask_value_string(CreoMemObj,"item_id",&CreoMemPartID));
						int memArr = 0;
						int PartSearStat = 0;
						for(memArr = 0; memArr < x; memArr++)
						{
							if(tc_strcmp(MembershipPartArray[memArr],CreoMemPartID)==0)
							{
								PartSearStat = 1;
								break;
							}
						}
						if(PartSearStat == 0)
						{
							MembershipPartArray[x] = CreoMemPartID;
						}
						else
						{
							AddIssueRepDt(PartID,PartRevID,"Duplicate_Revision_CREO_Membeship","CREO Membership","Backend Correction");
							break;
						}
					}

					for(x=0; x < n_attchs_ProMem ; x++)
					{
						int prsntStruct = 0;
						char *CreoMemPartID = NULL;
						tag_t CreoMemObj = NULLTAG;
						CreoMemObj = rellist_ProMem_DsgnRev[x];
						ITK_CALL(AOM_ask_value_string(CreoMemObj,"item_id",&CreoMemPartID));
						int recCreoMEM = 0;

						ITK_CALL(TCTYPE_ask_object_type(CreoMemObj, &ObjTypeTag));
						ITK_CALL(TCTYPE_ask_name2(ObjTypeTag, &ObjTypeNameProAsmMem));
						if(tc_strcmp(ObjTypeNameProAsmMem,"Design Revision")!=0)
						{
							continue;
						}

						for (y = 0; y < TcuaCadBomSize; y++)
					    {
					    	if(tc_strcmp(PartID, tcuaCADBOMData[y].PartNo) == 0)
					    	{
					    		printf("\nCADBOM Success %s compare with %s --> Inset %s",tcuaCADBOMData[y].PartNo,PartID,CreoMemPartID);fflush(stdout);
					    		int nextPos = tcuaCADBOMData[y].chldCnt + 1;
					    		prsntStruct = 1;
					    		for (z = 0; z < nextPos; ++z)
					    		{
					    			if(tc_strcmp(CreoMemPartID, tcuaCADBOMData[y].CadBOMChild[z].ChildPartNo) == 0)
					    			{
					    				recCreoMEM = 1;
					    				break;
					    			}
					    		}
					    		if (recCreoMEM == 0)
					    		{
					    			tcuaCADBOMData[y].chldCnt = nextPos;
						    		tcuaCADBOMData[y].CadBOMChild = (CadBOMChildStruct*)MEM_realloc(tcuaCADBOMData[y].CadBOMChild, (nextPos+1) * sizeof(CadBOMChildStruct));
						    		tcuaCADBOMData[y].CadBOMChild[nextPos].ChildPartNo = (char*)MEM_alloc( tc_strlen(CreoMemPartID) *sizeof(char));
						    		tc_strcpy(tcuaCADBOMData[y].CadBOMChild[nextPos].ChildPartNo, CreoMemPartID);
					    		}
					    	}
					    }
					    if(prsntStruct == 0)
					    {
							printf("\n*********************************************CADBOM %d Mismatch-%s--> Inset %s",TcuaCadBomSize,PartID,CreoMemPartID);fflush(stdout);
						    tcuaCADBOMData[TcuaCadBomSize].PartNo = (char*)MEM_alloc( tc_strlen(PartID) *sizeof(char));
						    tcuaCADBOMData[TcuaCadBomSize].PartRev = (char*)MEM_alloc( tc_strlen(partentRev) *sizeof(char));
						    tcuaCADBOMData[TcuaCadBomSize].PartSeq = (char*)MEM_alloc( tc_strlen(partentSeq) *sizeof(char));
						    tc_strcpy(tcuaCADBOMData[TcuaCadBomSize].PartNo, PartID);
						    tc_strcpy(tcuaCADBOMData[TcuaCadBomSize].PartRev, partentRev);
						    tc_strcpy(tcuaCADBOMData[TcuaCadBomSize].PartSeq, partentSeq);
							tcuaCADBOMData[TcuaCadBomSize].chldCnt = 0;
							tcuaCADBOMData[TcuaCadBomSize].CadBOMChild = (CadBOMChildStruct*)MEM_alloc(1 * sizeof(CadBOMChildStruct));
							tcuaCADBOMData[TcuaCadBomSize].CadBOMChild[0].ChildPartNo = (char*)MEM_alloc( tc_strlen(CreoMemPartID) *sizeof(char));
							tc_strcpy(tcuaCADBOMData[TcuaCadBomSize].CadBOMChild[0].ChildPartNo, CreoMemPartID);
							TcuaCadBomSize++;
					    }
					    if(recCreoMEM == 0)
					    {
					    	//Recursive Call CADBOM Parent Part Is Not Present in Structure
							ChkDataSetCreoMem(&CreoMemObj);
					    }
					}
				}
			}
			else
			{
				tag_t tRelationFind = NULLTAG;
				int n_attchs_Genric = 0;
				tag_t *rellist_Genric = NULLTAG;
				ITK_CALL(GRM_find_relation_type("IPEM_master_dependency",&tRelationFind));
				ITK_CALL(GRM_list_secondary_objects_only(dataset2,tRelationFind,&n_attchs_Genric,&rellist_Genric));
				if(n_attchs_Genric > 0)
				{
					ProAsmMembership = 1;
					CADPresent = 1;
				}
				int x=0;
				ITK_CALL(GRM_find_relation_type("Pro2_membership",&reln_type_ProMem));
				ITK_CALL(GRM_list_secondary_objects_only(dataset2,reln_type_ProMem,&n_attchs_ProMem,&rellist_ProMem_DsgnRev));
				if(n_attchs_ProMem>0)
				{
					for(x=0; x < n_attchs_ProMem ; x++)
					{
						int prsntStruct = 0;
						char *CreoMemPartID = NULL;
						tag_t CreoMemObj = NULLTAG;
						CreoMemObj = rellist_ProMem_DsgnRev[x];
						ITK_CALL(AOM_ask_value_string(CreoMemObj,"item_id",&CreoMemPartID));
						int recCreoMEM = 0;

						ITK_CALL(TCTYPE_ask_object_type(CreoMemObj, &ObjTypeTag));
						ITK_CALL(TCTYPE_ask_name2(ObjTypeTag, &ObjTypeNameProAsmMem));
						if(tc_strcmp(ObjTypeNameProAsmMem,"Design Revision")!=0)
						{
							continue;
						}

						for (y = 0; y < TcuaCadBomSize; y++)
					    {
					    	if(tc_strcmp(PartID, tcuaCADBOMData[y].PartNo) == 0)
					    	{
					    		printf("\nCADBOM Success %s compare with %s --> Inset %s",tcuaCADBOMData[y].PartNo,PartID,CreoMemPartID);fflush(stdout);
					    		int nextPos = tcuaCADBOMData[y].chldCnt + 1;
					    		prsntStruct = 1;
					    		for (z = 0; z < nextPos; ++z)
					    		{
					    			if(tc_strcmp(CreoMemPartID, tcuaCADBOMData[y].CadBOMChild[z].ChildPartNo) == 0)
					    			{
					    				recCreoMEM = 1;
					    				break;
					    			}
					    		}
					    		if (recCreoMEM == 0)
					    		{
					    			tcuaCADBOMData[y].chldCnt = nextPos;
						    		tcuaCADBOMData[y].CadBOMChild = (CadBOMChildStruct*)MEM_realloc(tcuaCADBOMData[y].CadBOMChild, (nextPos+1) * sizeof(CadBOMChildStruct));
						    		tcuaCADBOMData[y].CadBOMChild[nextPos].ChildPartNo = (char*)MEM_alloc( tc_strlen(CreoMemPartID) *sizeof(char));
						    		tc_strcpy(tcuaCADBOMData[y].CadBOMChild[nextPos].ChildPartNo, CreoMemPartID);
					    		}
					    	}
					    }
					    if(prsntStruct == 0)
					    {
							printf("\n*********************************************CADBOM %d Mismatch-%s--> Inset %s",TcuaCadBomSize,PartID,CreoMemPartID);fflush(stdout);
						    tcuaCADBOMData[TcuaCadBomSize].PartNo = (char*)MEM_alloc( tc_strlen(PartID) *sizeof(char));
						    tcuaCADBOMData[TcuaCadBomSize].PartRev = (char*)MEM_alloc( tc_strlen(partentRev) *sizeof(char));
						    tcuaCADBOMData[TcuaCadBomSize].PartSeq = (char*)MEM_alloc( tc_strlen(partentSeq) *sizeof(char));
						    tc_strcpy(tcuaCADBOMData[TcuaCadBomSize].PartNo, PartID);
						    tc_strcpy(tcuaCADBOMData[TcuaCadBomSize].PartRev, partentRev);
						    tc_strcpy(tcuaCADBOMData[TcuaCadBomSize].PartSeq, partentSeq);
							tcuaCADBOMData[TcuaCadBomSize].chldCnt = 0;
							tcuaCADBOMData[TcuaCadBomSize].CadBOMChild = (CadBOMChildStruct*)MEM_alloc(1 * sizeof(CadBOMChildStruct));
							tcuaCADBOMData[TcuaCadBomSize].CadBOMChild[0].ChildPartNo = (char*)MEM_alloc( tc_strlen(CreoMemPartID) *sizeof(char));
							tc_strcpy(tcuaCADBOMData[TcuaCadBomSize].CadBOMChild[0].ChildPartNo, CreoMemPartID);
							TcuaCadBomSize++;
					    }
					    /*if(recCreoMEM == 0) //CREO Assembly Instance
					    {
					    	//Recursive Call CADBOM Parent Part Is Not Present in Structure
							ChkDataSetCreoMem(&CreoMemObj);
					    }*/
					}
				}
			}
			
		}
		else if (tc_strcmp(objtype1,"ProPrt")==0)
		{
			int ref_count_d = 0;
			tag_t *namRefObject_d = NULLTAG;
			ITK_CALL(AE_ask_dataset_named_refs(dataset2,&ref_count_d, &namRefObject_d));

			if(ref_count_d > 0)
			{
				CADPresent = 1;
			}
			else
			{
				printf("\n%s,%s -----------------------------------------------------------------",PartID,PartRevID);fflush(stdout);

				tag_t tRelationFind = NULLTAG;
				int n_attchs_Genric = 0;
				tag_t *rellist_Genric = NULLTAG;
				ITK_CALL(GRM_find_relation_type("IPEM_master_dependency",&tRelationFind));
				ITK_CALL(GRM_list_secondary_objects_only(dataset2,tRelationFind,&n_attchs_Genric,&rellist_Genric));
				if(n_attchs_Genric > 0)
				{
					printf("\nIn Generic");fflush(stdout);
					CADPresent = 1;
				}
			}
		}
		else if (tc_strcmp(objtype1,"ProDrw")==0 || tc_strcmp(objtype1,"CMI2Part")==0 || tc_strcmp(objtype1,"CMI2Product")==0 || tc_strcmp(objtype1,"CMI2Drawing")==0)
		{
			CADPresent = 1;
		}
	}

	//printf("\nItem ID cRevision : %s %s", PartID,PartRevID);fflush(stdout);
	if(CADPresent == 0)
	{
		printf("\nPrinting");fflush(stdout);
		//Print In file No Data Set: Status-NO DataSet
		fprintf(outputTCE,"%s,%s,No_CAD_DataSet\n",PartID,PartRevID);fflush(outputTCE);
	}
	if(ProAsmMembership == 0 && ProAsmPresent == 1 && CADPresent == 1)
	{
		AddIssueRepDt(PartID,PartRevID,"Missing_CREO_Membership","CREO Membership","Remigration of Part");
		//Print In file: Status-CREO Membership Missing
	}
	printf("\n\t\tChkDataSetCreoMem*************************End"); fflush(stdout);
}

int getchilds(int iNumber_Child,tag_t *tBOM_Children, int RevRuleType, char* PartentPartID, char* PartentRevision, char* PartOwningUser, int CadStat)
{
	printf("\n\t\tgetchilds*************************Start --%s -- %s -- %s",PartentPartID,PartentRevision,PartOwningUser); fflush(stdout);

	int k = 0;
	char* cItem_Id = NULL;
	char* cRevision =NULL;
	int count1=0;
	tag_t *sub_childs=NULL;
	char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));
	int i=0;
	int n_found=0;
	int JtNo =0;
	int AsmPrt =0;
	tag_t query = NULLTAG;
	tag_t* cntr_objects = NULL;
	int entries =2;
	char *qry_entries[2]  = {"Item ID","Revision"};
	tag_t query1 = NULLTAG;
	char **qry_values1 = (char **) MEM_alloc(50 * sizeof(char *));
	int n_found1=0;
	tag_t* cntr_objects1 = NULL;
	int y= 0;
	char* ParentRevDup = (char*)MEM_alloc(sizeof(char) * 20);
	char* partentRev = NULL;
	char* partentSeq = NULL;

	char *t5_DesignGrp=NULL;
	char *t5_DrawingInd=NULL;
	char *t5_DrawingNo=NULL;
	char *t5_ProjectCode=NULL;
	char *t5_MatlClass=NULL;
	char *t5_ModelIndicator=NULL;
	char *bl_quantity=NULL;
	char *t5_RevPartType=NULL;
	char *linObjType = NULL;
	char *t5_PartStatus = NULL;
	char *owninguser = NULL;

	strcpy(ParentRevDup,PartentRevision);
	partentRev = strtok(ParentRevDup,";");
	partentSeq = strtok(NULL,";");

	for(i=0;i<iNumber_Child;i++)
	{
		int prsntStruct = 0;

		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_item_item_id", &cItem_Id));
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_rev_item_revision_id", &cRevision));
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "fnd0bl_line_object_type", &linObjType));
		if(tc_strcmp(linObjType,"ItemRevision")==0)
		{
			//IssueRepDt = (IssueRep*)MEM_realloc(IssueRepDt, (issueDtCnt+1) * sizeof(IssueRep));
			IssueRepDt[issueDtCnt].cnt = (char*)MEM_alloc( 10 *sizeof(char));
			sprintf(IssueRepDt[issueDtCnt].cnt, "%d", (issueDtCnt+1));
			IssueRepDt[issueDtCnt].PartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].PartNo, cItem_Id);
			IssueRepDt[issueDtCnt].RevSeq = (char*)MEM_alloc( 50 *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].RevSeq, "---");
			IssueRepDt[issueDtCnt].IssueCat = (char*)MEM_alloc( tc_strlen("Part Created as ITEM") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueCat, "Part Created as ITEM");
			IssueRepDt[issueDtCnt].IssueDesc = (char*)MEM_alloc( tc_strlen("Part Creation") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].IssueDesc, "Part Creation");
			IssueRepDt[issueDtCnt].SuggSol = (char*)MEM_alloc( tc_strlen("Backend Correction") *sizeof(char));
			tc_strcpy(IssueRepDt[issueDtCnt].SuggSol, "Backend Correction");
			issueDtCnt++;

			printf("Object Type Issue %s ------ItemRevision----- Hence continue",cItem_Id);
			continue;
		}
		
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_Design Revision_t5_DesignGrp", &t5_DesignGrp ));
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_Design Revision_t5_DrawingInd", &t5_DrawingInd ));
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_Design Revision_t5_DrawingNo", &t5_DrawingNo ));
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_Design Revision_t5_ProjectCode", &t5_ProjectCode ));
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_Design Revision_t5_MatlClass", &t5_MatlClass ));
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_Design Revision_t5_ModelIndicator", &t5_ModelIndicator ));
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_quantity", &bl_quantity ));
		ITK_CALL(AOM_ask_value_string(tBOM_Children[i], "bl_Design Revision_t5_PartType", &t5_RevPartType ));
		ITK_CALL(AOM_ask_value_string(tBOM_Children[i], "bl_Design Revision_t5_PartStatus", &t5_PartStatus ));
		ITK_CALL(AOM_UIF_ask_value(tBOM_Children[i], "bl_rev_owning_user", &owninguser ));

		/*if (tc_strstr(owninguser, "loader")!= NULL)
		{
			printf("Not Migrated Data %s ----------- Hence continue",cItem_Id);
			continue;
		}*/

		printf("\nItem ID: %s --%s-- --------- %d", cItem_Id,cRevision,RevRuleType); fflush(stdout);

		if (cRevision == NULL)
		{
			printf("No Revision %s ----------- Hence continue",cItem_Id);
			continue;
		}
		else if(tc_strstr(cRevision,";") == NULL)
		{
			printf("No Revision %s ----------- Hence continue",cItem_Id);
			continue;
		}

		int st=0;
		tag_t attached_object = NULLTAG;
        ITK_CALL(AOM_ask_value_tag(tBOM_Children[i], "bl_revision", &attached_object));
		st = ChkSuperBOMstructure(&attached_object,cItem_Id);

		//Strt of Rev Eff Issue
		int rev_eff_issue = 0;
		char *highRev = NULL;
		char *highSeq = NULL;
		char *rev_id = NULL;
		char* cRevisionDup = (char*)MEM_alloc(sizeof(char) * 20);
		strcpy(cRevisionDup,cRevision);
		highRev = strtok(cRevisionDup,";");
		highSeq = strtok(NULL,";");
		int highRevPos = 0;
		int r = 0;

		if(RevRuleType == 2)
		{
		for (y = 0; y < TcuaEbomSize; y++)
		{
			if(tc_strcmp(PartentPartID, tcuaEBOMData[y].PartNo) == 0)
			{
				prsntStruct = 1;
	    		int nextPos = tcuaEBOMData[y].chldCnt + 1;
	    		tcuaEBOMData[y].chldCnt = nextPos;
	    		tcuaEBOMData[y].EBOMChild = (EBOMChildStruct*)MEM_realloc(tcuaEBOMData[y].EBOMChild, (nextPos+1) * sizeof(EBOMChildStruct));

	    		tcuaEBOMData[y].EBOMChild[nextPos].ChildPartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
				tcuaEBOMData[y].EBOMChild[nextPos].ChildPartRev = (char*)MEM_alloc( tc_strlen(highRev) *sizeof(char));
				tcuaEBOMData[y].EBOMChild[nextPos].ChildPartSeq = (char*)MEM_alloc( tc_strlen(highSeq) *sizeof(char));
				if(owninguser != NULL)
				{
					tcuaEBOMData[y].EBOMChild[nextPos].owninguser = (char*)MEM_alloc( tc_strlen(owninguser) *sizeof(char));
				}
				else
				{
					tcuaEBOMData[y].EBOMChild[nextPos].owninguser = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if(t5_PartStatus != NULL)
				{
					tcuaEBOMData[y].EBOMChild[nextPos].t5PartStatus = (char*)MEM_alloc( tc_strlen(t5_PartStatus) *sizeof(char));
				}
				else
				{
					tcuaEBOMData[y].EBOMChild[nextPos].t5PartStatus = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if(t5_RevPartType != NULL)
				{
					tcuaEBOMData[y].EBOMChild[nextPos].PartType = (char*)MEM_alloc( tc_strlen(t5_RevPartType) *sizeof(char));
				}
				else
				{
					tcuaEBOMData[y].EBOMChild[nextPos].PartType = (char*)MEM_alloc( 5 *sizeof(char));
				}
				//tcuaEBOMData[y].EBOMChild[nextPos].t5PartCode = (char*)MEM_alloc( tc_strlen(t5PartCode) *sizeof(char));
				if (t5_DrawingInd != NULL)
				{
					tcuaEBOMData[y].EBOMChild[nextPos].t5DrawingInd = (char*)MEM_alloc( tc_strlen(t5_DrawingInd) *sizeof(char));
				}
				else
				{
					tcuaEBOMData[y].EBOMChild[nextPos].t5DrawingInd = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if (t5_DrawingNo != NULL)
				{
					tcuaEBOMData[y].EBOMChild[nextPos].t5DrawingNo = (char*)MEM_alloc( tc_strlen(t5_DrawingNo) *sizeof(char));
				}
				else
				{
					tcuaEBOMData[y].EBOMChild[nextPos].t5DrawingNo = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if (t5_ProjectCode != NULL)
				{
					tcuaEBOMData[y].EBOMChild[nextPos].ProjectName = (char*)MEM_alloc( tc_strlen(t5_ProjectCode) *sizeof(char));
				}
				else
				{
					tcuaEBOMData[y].EBOMChild[nextPos].ProjectName = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if (t5_DesignGrp != NULL)
				{
					tcuaEBOMData[y].EBOMChild[nextPos].Designgroup = (char*)MEM_alloc( tc_strlen(t5_DesignGrp) *sizeof(char));
				}
				else
				{
					tcuaEBOMData[y].EBOMChild[nextPos].Designgroup = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if (t5_MatlClass != NULL)
				{
					tcuaEBOMData[y].EBOMChild[nextPos].t5Material = (char*)MEM_alloc( tc_strlen(t5_MatlClass) *sizeof(char));
				}
				else
				{
					tcuaEBOMData[y].EBOMChild[nextPos].t5Material = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if (bl_quantity != NULL)
				{
					tcuaEBOMData[y].EBOMChild[nextPos].UsesPartQty = (char*)MEM_alloc( tc_strlen(bl_quantity) *sizeof(char));
				}
				else
				{
					tcuaEBOMData[y].EBOMChild[nextPos].UsesPartQty = (char*)MEM_alloc( 5 *sizeof(char));
				}

	    		tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].ChildPartNo, cItem_Id);
			    tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].ChildPartRev, highRev);
			    tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].ChildPartSeq, highSeq);
			    if(owninguser != NULL)
			    {	
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].owninguser, owninguser);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].owninguser, "NA");
			    }
			    if(t5_PartStatus != NULL)
			    {	
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].t5PartStatus, t5_PartStatus);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].t5PartStatus, "NA");
			    }
			    if(t5_RevPartType != NULL)
			    {	
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].PartType, t5_RevPartType);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].PartType, "NA");
			    }
			    //tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].t5PartCode, t5PartCode);
			    if (t5_DrawingInd != NULL)
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].t5DrawingInd, t5_DrawingInd);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].t5DrawingInd, "NA");
			    }
			    if (t5_DrawingNo != NULL)
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].t5DrawingNo, t5_DrawingNo);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].t5DrawingNo, "NA");
			    }
			    if (t5_ProjectCode != NULL)
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].ProjectName, t5_ProjectCode);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].ProjectName, "NA");
			    }
			    if (t5_DesignGrp != NULL)
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].Designgroup, t5_DesignGrp);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].Designgroup, "NA");
			    }
			    if (t5_MatlClass != NULL)
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].t5Material, t5_MatlClass);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].t5Material, "NA");
			    }
			    if (bl_quantity != NULL)
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].UsesPartQty, bl_quantity);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMData[y].EBOMChild[nextPos].UsesPartQty, "0");
			    }
			}
		}

		if(prsntStruct == 0)
		{
			tcuaEBOMData[TcuaEbomSize].PartNo = (char*)MEM_alloc( tc_strlen(PartentPartID) *sizeof(char));
		    tc_strcpy(tcuaEBOMData[TcuaEbomSize].PartNo, PartentPartID);
		    tcuaEBOMData[TcuaEbomSize].PartRev = (char*)MEM_alloc( tc_strlen(partentRev) *sizeof(char));
			tc_strcpy(tcuaEBOMData[TcuaEbomSize].PartRev, partentRev);
			tcuaEBOMData[TcuaEbomSize].PartSeq = (char*)MEM_alloc( tc_strlen(partentSeq) *sizeof(char));
			tc_strcpy(tcuaEBOMData[TcuaEbomSize].PartSeq, partentSeq);
			tcuaEBOMData[TcuaEbomSize].owninguser = (char*)MEM_alloc( tc_strlen(PartOwningUser) *sizeof(char));
			tc_strcpy(tcuaEBOMData[TcuaEbomSize].owninguser, PartOwningUser);
			tcuaEBOMData[TcuaEbomSize].chldCnt = 0;

			tcuaEBOMData[TcuaEbomSize].EBOMChild = (EBOMChildStruct*)MEM_alloc(1 * sizeof(EBOMChildStruct));
			tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ChildPartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ChildPartRev = (char*)MEM_alloc( tc_strlen(highRev) *sizeof(char));
			tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ChildPartSeq = (char*)MEM_alloc( tc_strlen(highSeq) *sizeof(char));
			if(owninguser != NULL)
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].owninguser = (char*)MEM_alloc( tc_strlen(owninguser) *sizeof(char));
			}
			else
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].owninguser = (char*)MEM_alloc( 5 *sizeof(char));
			}
			if(t5_PartStatus != NULL)
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5PartStatus = (char*)MEM_alloc( tc_strlen(t5_PartStatus) *sizeof(char));
			}
			else
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5PartStatus = (char*)MEM_alloc( 5 *sizeof(char));
			}
			if(t5_RevPartType != NULL)
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].PartType = (char*)MEM_alloc( tc_strlen(t5_RevPartType) *sizeof(char));
			}
			else
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].PartType = (char*)MEM_alloc( 5 *sizeof(char));
			}
			//tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5PartCode = (char*)MEM_alloc( tc_strlen(t5PartCode) *sizeof(char));
			if (t5_DrawingInd != NULL)
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5DrawingInd = (char*)MEM_alloc( tc_strlen(t5_DrawingInd) *sizeof(char));
			}
			else
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5DrawingInd = (char*)MEM_alloc( 5 *sizeof(char));
			}
			if (t5_DrawingNo != NULL)
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5DrawingNo = (char*)MEM_alloc( tc_strlen(t5_DrawingNo) *sizeof(char));
			}
			else
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5DrawingNo = (char*)MEM_alloc( 5 *sizeof(char));
			}
			if (t5_ProjectCode != NULL)
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ProjectName = (char*)MEM_alloc( tc_strlen(t5_ProjectCode) *sizeof(char));
			}
			else
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ProjectName = (char*)MEM_alloc( 5 *sizeof(char));
			}
			if (t5_DesignGrp != NULL)
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].Designgroup = (char*)MEM_alloc( tc_strlen(t5_DesignGrp) *sizeof(char));
			}
			else
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].Designgroup = (char*)MEM_alloc( 5 *sizeof(char));
			}
			if (t5_MatlClass != NULL)
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5Material = (char*)MEM_alloc( tc_strlen(t5_MatlClass) *sizeof(char));
			}
			else
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5Material = (char*)MEM_alloc( 5 *sizeof(char));
			}
			//tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5RolledupWt = (char*)MEM_alloc( tc_strlen(t5RolledupWt) *sizeof(char));
			//tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5UQdup = (char*)MEM_alloc( tc_strlen(t5UQdup) *sizeof(char));
			if (bl_quantity != NULL)
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].UsesPartQty = (char*)MEM_alloc( tc_strlen(bl_quantity) *sizeof(char));
			}
			else
			{
				tcuaEBOMData[TcuaEbomSize].EBOMChild[0].UsesPartQty = (char*)MEM_alloc( 5 *sizeof(char));
			}

			tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ChildPartNo, cItem_Id);
		    tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ChildPartRev, highRev);
		    tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ChildPartSeq, highSeq);
		    if(owninguser != NULL)
		    {	
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].owninguser, owninguser);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].owninguser, "NA");
		    }
		    if(t5_PartStatus != NULL)
		    {	
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5PartStatus, t5_PartStatus);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5PartStatus, "NA");
		    }
		    if(t5_RevPartType != NULL)
		    {	
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].PartType, t5_RevPartType);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].PartType, "NA");
		    }
		    //tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5PartCode, t5PartCode);
		    if (t5_DrawingInd != NULL)
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5DrawingInd, t5_DrawingInd);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5DrawingInd, "NA");
		    }
		    if (t5_DrawingNo != NULL)
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5DrawingNo, t5_DrawingNo);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5DrawingNo, "NA");
		    }
		    if (t5_ProjectCode != NULL)
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ProjectName, t5_ProjectCode);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].ProjectName, "NA");
		    }
		    if (t5_DesignGrp != NULL)
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].Designgroup, t5_DesignGrp);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].Designgroup, "NA");
		    }
		    if (t5_MatlClass != NULL)
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5Material, t5_MatlClass);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5Material, "NA");
		    }
		    
		    //tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5RolledupWt, t5RolledupWt);
		    //tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].t5UQdup, t5UQdup);

		    if (bl_quantity != NULL)
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].UsesPartQty, bl_quantity);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMData[TcuaEbomSize].EBOMChild[0].UsesPartQty, "0");
		    }
			TcuaEbomSize++;
		}
		}
		else
		{
		for (y = 0; y < TcuaEbomSizeLatWrk; y++)
		{
			if(tc_strcmp(PartentPartID, tcuaEBOMDataLatWrk[y].PartNo) == 0)
			{
				prsntStruct = 1;
	    		int nextPos = tcuaEBOMDataLatWrk[y].chldCnt + 1;
	    		tcuaEBOMDataLatWrk[y].chldCnt = nextPos;
	    		tcuaEBOMDataLatWrk[y].EBOMChild = (EBOMChildStruct*)MEM_realloc(tcuaEBOMDataLatWrk[y].EBOMChild, (nextPos+1) * sizeof(EBOMChildStruct));

	    		tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].ChildPartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
				tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].ChildPartRev = (char*)MEM_alloc( tc_strlen(highRev) *sizeof(char));
				tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].ChildPartSeq = (char*)MEM_alloc( tc_strlen(highSeq) *sizeof(char));
				if(owninguser != NULL)
				{
					tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].owninguser = (char*)MEM_alloc( tc_strlen(owninguser) *sizeof(char));
				}
				else
				{
					tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].owninguser = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if(t5_PartStatus != NULL)
				{
					tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].t5PartStatus = (char*)MEM_alloc( tc_strlen(t5_PartStatus) *sizeof(char));
				}
				else
				{
					tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].t5PartStatus = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if(t5_RevPartType != NULL)
				{
					tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].PartType = (char*)MEM_alloc( tc_strlen(t5_RevPartType) *sizeof(char));
				}
				else
				{
					tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].PartType = (char*)MEM_alloc( 5 *sizeof(char));
				}
				//tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].t5PartCode = (char*)MEM_alloc( tc_strlen(t5PartCode) *sizeof(char));
				if (t5_DrawingInd != NULL)
				{
					tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].t5DrawingInd = (char*)MEM_alloc( tc_strlen(t5_DrawingInd) *sizeof(char));
				}
				else
				{
					tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].t5DrawingInd = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if (t5_DrawingNo != NULL)
				{
					tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].t5DrawingNo = (char*)MEM_alloc( tc_strlen(t5_DrawingNo) *sizeof(char));
				}
				else
				{
					tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].t5DrawingNo = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if (t5_ProjectCode != NULL)
				{
					tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].ProjectName = (char*)MEM_alloc( tc_strlen(t5_ProjectCode) *sizeof(char));
				}
				else
				{
					tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].ProjectName = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if (t5_DesignGrp != NULL)
				{
					tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].Designgroup = (char*)MEM_alloc( tc_strlen(t5_DesignGrp) *sizeof(char));
				}
				else
				{
					tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].Designgroup = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if (t5_MatlClass != NULL)
				{
					tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].t5Material = (char*)MEM_alloc( tc_strlen(t5_MatlClass) *sizeof(char));
				}
				else
				{
					tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].t5Material = (char*)MEM_alloc( 5 *sizeof(char));
				}
				if (bl_quantity != NULL)
				{
					tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].UsesPartQty = (char*)MEM_alloc( tc_strlen(bl_quantity) *sizeof(char));
				}
				else
				{
					tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].UsesPartQty = (char*)MEM_alloc( 5 *sizeof(char));
				}

	    		tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].ChildPartNo, cItem_Id);
			    tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].ChildPartRev, highRev);
			    tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].ChildPartSeq, highSeq);
			    if(owninguser != NULL)
			    {	
			    	tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].owninguser, owninguser);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].owninguser, "NA");
			    }
			    if(t5_PartStatus != NULL)
			    {	
			    	tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].t5PartStatus, t5_PartStatus);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].t5PartStatus, "NA");
			    }
			    if(t5_RevPartType != NULL)
			    {	
			    	tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].PartType, t5_RevPartType);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].PartType, "NA");
			    }
			    //tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].t5PartCode, t5PartCode);
			    if (t5_DrawingInd != NULL)
			    {
			    	tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].t5DrawingInd, t5_DrawingInd);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].t5DrawingInd, "NA");
			    }
			    if (t5_DrawingNo != NULL)
			    {
			    	tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].t5DrawingNo, t5_DrawingNo);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].t5DrawingNo, "NA");
			    }
			    if (t5_ProjectCode != NULL)
			    {
			    	tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].ProjectName, t5_ProjectCode);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].ProjectName, "NA");
			    }
			    if (t5_DesignGrp != NULL)
			    {
			    	tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].Designgroup, t5_DesignGrp);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].Designgroup, "NA");
			    }
			    if (t5_MatlClass != NULL)
			    {
			    	tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].t5Material, t5_MatlClass);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].t5Material, "NA");
			    }
			    if (bl_quantity != NULL)
			    {
			    	tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].UsesPartQty, bl_quantity);
			    }
			    else
			    {
			    	tc_strcpy(tcuaEBOMDataLatWrk[y].EBOMChild[nextPos].UsesPartQty, "0");
			    }
			}
		}

		if(prsntStruct == 0)
		{
			tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].PartNo = (char*)MEM_alloc( tc_strlen(PartentPartID) *sizeof(char));
		    tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].PartNo, PartentPartID);
		    tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].PartRev = (char*)MEM_alloc( tc_strlen(partentRev) *sizeof(char));
			tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].PartRev, partentRev);
			tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].PartSeq = (char*)MEM_alloc( tc_strlen(partentSeq) *sizeof(char));
			tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].PartSeq, partentSeq);
			tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].owninguser = (char*)MEM_alloc( tc_strlen(PartOwningUser) *sizeof(char));
			tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].owninguser, PartOwningUser);
			tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].chldCnt = 0;

			tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild = (EBOMChildStruct*)MEM_alloc(1 * sizeof(EBOMChildStruct));
			tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].ChildPartNo = (char*)MEM_alloc( tc_strlen(cItem_Id) *sizeof(char));
			tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].ChildPartRev = (char*)MEM_alloc( tc_strlen(highRev) *sizeof(char));
			tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].ChildPartSeq = (char*)MEM_alloc( tc_strlen(highSeq) *sizeof(char));
			if(owninguser != NULL)
			{
				tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].owninguser = (char*)MEM_alloc( tc_strlen(owninguser) *sizeof(char));
			}
			else
			{
				tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].owninguser = (char*)MEM_alloc( 5 *sizeof(char));
			}
			if(t5_PartStatus != NULL)
			{
				tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5PartStatus = (char*)MEM_alloc( tc_strlen(t5_PartStatus) *sizeof(char));
			}
			else
			{
				tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5PartStatus = (char*)MEM_alloc( 5 *sizeof(char));
			}
			if(t5_RevPartType != NULL)
			{
				tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].PartType = (char*)MEM_alloc( tc_strlen(t5_RevPartType) *sizeof(char));
			}
			else
			{
				tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].PartType = (char*)MEM_alloc( 5 *sizeof(char));
			}
			//tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5PartCode = (char*)MEM_alloc( tc_strlen(t5PartCode) *sizeof(char));
			if (t5_DrawingInd != NULL)
			{
				tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5DrawingInd = (char*)MEM_alloc( tc_strlen(t5_DrawingInd) *sizeof(char));
			}
			else
			{
				tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5DrawingInd = (char*)MEM_alloc( 5 *sizeof(char));
			}
			if (t5_DrawingNo != NULL)
			{
				tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5DrawingNo = (char*)MEM_alloc( tc_strlen(t5_DrawingNo) *sizeof(char));
			}
			else
			{
				tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5DrawingNo = (char*)MEM_alloc( 5 *sizeof(char));
			}
			if (t5_ProjectCode != NULL)
			{
				tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].ProjectName = (char*)MEM_alloc( tc_strlen(t5_ProjectCode) *sizeof(char));
			}
			else
			{
				tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].ProjectName = (char*)MEM_alloc( 5 *sizeof(char));
			}
			if (t5_DesignGrp != NULL)
			{
				tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].Designgroup = (char*)MEM_alloc( tc_strlen(t5_DesignGrp) *sizeof(char));
			}
			else
			{
				tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].Designgroup = (char*)MEM_alloc( 5 *sizeof(char));
			}
			if (t5_MatlClass != NULL)
			{
				tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5Material = (char*)MEM_alloc( tc_strlen(t5_MatlClass) *sizeof(char));
			}
			else
			{
				tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5Material = (char*)MEM_alloc( 5 *sizeof(char));
			}
			//tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5RolledupWt = (char*)MEM_alloc( tc_strlen(t5RolledupWt) *sizeof(char));
			//tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5UQdup = (char*)MEM_alloc( tc_strlen(t5UQdup) *sizeof(char));
			if (bl_quantity != NULL)
			{
				tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].UsesPartQty = (char*)MEM_alloc( tc_strlen(bl_quantity) *sizeof(char));
			}
			else
			{
				tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].UsesPartQty = (char*)MEM_alloc( 5 *sizeof(char));
			}

			tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].ChildPartNo, cItem_Id);
		    tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].ChildPartRev, highRev);
		    tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].ChildPartSeq, highSeq);
		    if(owninguser != NULL)
		    {	
		    	tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].owninguser, owninguser);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].owninguser, "NA");
		    }
		    if(t5_PartStatus != NULL)
		    {	
		    	tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5PartStatus, t5_PartStatus);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5PartStatus, "NA");
		    }
		    if(t5_RevPartType != NULL)
		    {	
		    	tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].PartType, t5_RevPartType);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].PartType, "NA");
		    }
		    //tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5PartCode, t5PartCode);
		    if (t5_DrawingInd != NULL)
		    {
		    	tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5DrawingInd, t5_DrawingInd);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5DrawingInd, "NA");
		    }
		    if (t5_DrawingNo != NULL)
		    {
		    	tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5DrawingNo, t5_DrawingNo);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5DrawingNo, "NA");
		    }
		    if (t5_ProjectCode != NULL)
		    {
		    	tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].ProjectName, t5_ProjectCode);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].ProjectName, "NA");
		    }
		    if (t5_DesignGrp != NULL)
		    {
		    	tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].Designgroup, t5_DesignGrp);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].Designgroup, "NA");
		    }
		    if (t5_MatlClass != NULL)
		    {
		    	tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5Material, t5_MatlClass);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5Material, "NA");
		    }
		    
		    //tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5RolledupWt, t5RolledupWt);
		    //tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].t5UQdup, t5UQdup);

		    if (bl_quantity != NULL)
		    {
		    	tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].UsesPartQty, bl_quantity);
		    }
		    else
		    {
		    	tc_strcpy(tcuaEBOMDataLatWrk[TcuaEbomSizeLatWrk].EBOMChild[0].UsesPartQty, "0");
		    }
			TcuaEbomSizeLatWrk++;
		}
		}
		
		for (r = 0; r < revision_length; r++) 
		{     
			if (tc_strcmp(highRev, revision_Order[r]) == 0) 
			{
				highRevPos = r;
				break;
			}   
		}
		//Revision Effectivity Correct Or Not (Using Lexical Analysis, NR < A < B)
		if(RevRuleType == 1)
		{
			ITK_CALL(QRY_find2("Item Revision...",&query1));
			qry_values1[0] = cItem_Id;
			char *qry_entries1[1]  = {"Item ID"};
			ITK_CALL(QRY_execute(query1, 1, qry_entries1, qry_values1, &n_found1, &cntr_objects1));
		}
		else
		{
			ITK_CALL(QRY_find2("Item Revision...",&query1));
			qry_values1[0] = cItem_Id;
			qry_values1[1] = "T5_LcsErcRlzd";
			char *qry_entries1[2]  = {"Item ID","Release Status"};
			ITK_CALL(QRY_execute(query1, 2, qry_entries1, qry_values1, &n_found1, &cntr_objects1));
		}
		char* HighRevFinal = (char*)MEM_alloc(sizeof(char) * 20);
		char* HighSeqFinal = (char*)MEM_alloc(sizeof(char) * 20);
		tc_strcpy(HighRevFinal,"");
		tc_strcpy(HighSeqFinal,"");
		int HighRevSeqPos = 0;
		for (k = 0; k < n_found1; ++k)
		{
			char *actRev = NULL;
			char *actSeq = NULL;
			int actRevPos = 0;
			ITK_CALL(AOM_UIF_ask_value (cntr_objects1[k], "item_revision_id", &rev_id));

			char* TCOwner = NULL;
			char* owning_group = NULL;
			logical checkout = 0;
			ITK_CALL(AOM_UIF_ask_value(cntr_objects1[k],"owning_user",&TCOwner));
			ITK_CALL(AOM_UIF_ask_value(cntr_objects1[k],"owning_group",&owning_group));
			ITK_CALL(RES_is_checked_out(cntr_objects1[k],&checkout));
			printf("\n%s -- %s Owning User: %s -- Group : %s -- %d",cItem_Id,rev_id,TCOwner,owning_group,checkout); fflush(stdout);
			if (checkout==1 && tc_strstr(TCOwner,"loader")!=NULL && tc_strstr(TCOwner,"aplloader")==NULL)
			{
				AddIssueRepDt(cItem_Id,rev_id,"Loader Data in Check-Out State","Part Property","Backend Correction");
			}
			if (tc_strstr(owning_group,"dba")!=NULL && tc_strstr(TCOwner,"loader")!=NULL && tc_strstr(TCOwner,"aplloader")==NULL)
			{
				//printf("\n\t--------------------------%d ---- %s --- %s --------\n",RevRuleType,cItem_Id,rev_id); fflush(stdout);
				AddIssueRepDt(cItem_Id,rev_id,"Loader Data in DBA Group : Change Ownership Required","Part Property","Backend Correction");
			}

			actRev = strtok(rev_id,";");
			actSeq =strtok(NULL,";");
			for (r = 0; r < revision_length; r++) 
			{     
				if (tc_strcmp(actRev, revision_Order[r]) == 0) 
				{
					actRevPos = r;
					break;
				}
			}

			if(tc_strcmp(highRev, "NR")==0 && tc_strcmp(actRev, "NR")!=0)
			{
				rev_eff_issue = 1;
				if (actRevPos >= HighRevSeqPos)
				{
					tc_strcpy(HighRevFinal,actRev);
					tc_strcpy(HighSeqFinal,actSeq);
					HighRevSeqPos = actRevPos;
				}
			}
			else if(tc_strcmp(highRev, "NR")!=0 && tc_strcmp(actRev, "NR")==0)
			{
				continue;
			}
			else if(tc_strcmp(highRev, actRev)==0)
			{
				int highSeqInt = 0;
				int actSeqInt = 0;
				highSeqInt = atoi(highSeq);
				actSeqInt = atoi(actSeq);
				//if(tc_strcmp(highSeq, actSeq) < 0)
				if(highSeqInt < actSeqInt)
				{
					rev_eff_issue = 1;
					tc_strcpy(HighRevFinal,actRev);
					tc_strcpy(HighSeqFinal,actSeq);
					HighRevSeqPos = actRevPos;
				}
			}
			else if(highRevPos > actRevPos)
			{
				continue;
			}
			else
			{
				rev_eff_issue = 1;
				if (actRevPos >= HighRevSeqPos)
				{
					tc_strcpy(HighRevFinal,actRev);
					tc_strcpy(HighSeqFinal,actSeq);
					HighRevSeqPos = actRevPos;
				}
			}
		}
		if(rev_eff_issue == 1 && RevRuleType == 1)
		{
			//RepExtChk = 0;
			char *tempCopy = NULL;
			tempCopy = (char*)MEM_alloc( 50 *sizeof(char));
			tc_strcpy(tempCopy,cRevision);
			tc_strcat(tempCopy,"->");
			tc_strcat(tempCopy,HighRevFinal);
			tc_strcat(tempCopy,";");
			tc_strcat(tempCopy,HighSeqFinal);

			AddIssueRepDt(cItem_Id,tempCopy,"Rev_Eff_Issue_Latest_Working","Structure Manager","Backend Correction");
		}
		if(rev_eff_issue == 1 && RevRuleType == 2)
		{
			//RepExtChk = 0;
			char *tempCopy = NULL;
			tempCopy = (char*)MEM_alloc( 50 *sizeof(char));
			tc_strcpy(tempCopy,cRevision);
			tc_strcat(tempCopy,"->");
			tc_strcat(tempCopy,HighRevFinal);
			tc_strcat(tempCopy,";");
			tc_strcat(tempCopy,HighSeqFinal);

			AddIssueRepDt(cItem_Id,tempCopy,"Rev_Eff_Issue_ERC_Release_Above","Structure Manager","Backend Correction");
		}
		//End of Rev Eff Issue

		qry_values[0] = cItem_Id;
		qry_values[1] = cRevision;
		ITK_CALL(QRY_find2("Item Revision...",&query));
		ITK_CALL(QRY_execute(query, entries, qry_entries, qry_values, &n_found, &cntr_objects));
		if(n_found>0)
		{
			ChkDataSetRelation(&cntr_objects[0]);
		}

		int bomalreadyChk = 0;
		if(RevRuleType == 2)
		{
			for (y = 0; y < TcuaEbomSize; y++)
		    {
		    	if(tc_strcmp(cItem_Id, tcuaEBOMData[y].PartNo) == 0)
		    	{
		    		bomalreadyChk = 1;
		    	}
		    }

		    if(bomalreadyChk == 0)
		    {
				BOM_line_ask_all_child_lines(tBOM_Children[i],&count1,&sub_childs);
				if(count1>0)
				{
					if (CadStat == 1)
					{
						getchilds(count1,sub_childs,RevRuleType,cItem_Id,cRevision,owninguser,CadStat);
					}
				}
			}
		}
		else
		{
			for (y = 0; y < TcuaEbomSizeLatWrk; y++)
		    {
		    	if(tc_strcmp(cItem_Id, tcuaEBOMDataLatWrk[y].PartNo) == 0)
		    	{
		    		bomalreadyChk = 1;
		    	}
		    }

		    if(bomalreadyChk == 0)
		    {
				BOM_line_ask_all_child_lines(tBOM_Children[i],&count1,&sub_childs);
				if(count1>0)
				{
					if (CadStat == 1)
					{
						getchilds(count1,sub_childs,RevRuleType,cItem_Id,cRevision,owninguser,CadStat);
					}
				}
			}
		}
	}
	printf("\n\t\tgetchilds*************************End"); fflush(stdout);
}

int ITK_user_main(int argc, char* argv[])
{
    int iFail = 0;
    char* cError = NULL;
	char* username = NULL;
	tag_t tuser = NULLTAG;
	char *loggedInUser = NULL;
	char *message;
	//iFail = ITK_auto_login();
	//printf("\nReturn Value is : %d", iFail);fflush(stdout);
	//ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	ITK_CALL(ITK_initialize_text_services (0));
    iFail = ITK_auto_login ();
    if (iFail != ITK_ok ) 
	{
        EMH_ask_error_text(iFail, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", iFail, message);
        MEM_free(message);
        return iFail;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}

	int n_entries = 1;
	int i=0;
	int JtNo=0;
	int j=0;
	int k=0;
	int n_genIns =0;
	tag_t tItemobj = NULLTAG;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULL;
	char *PartID = NULL;
	char *PartSequenceID = NULL;
	char *Part_Rlz_Stat = NULL;
	char *part_type = NULL;
	char *Description = NULL;
	char *object_type = NULL;
	char *Part_ProjID = NULL;
	char *Part_DesgnGrp = NULL;
	char *Revision = NULL;
	tag_t DataSet = NULLTAG;
	tag_t dataset2 = NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t relation_type2 = NULLTAG;
	tag_t* rellist_JT = NULL;
	int n_attchs_JT =0;
	tag_t* attachments = NULL;
	tag_t itemrev = NULLTAG;
	tag_t iteamrev2 = NULLTAG;
	tag_t iteamrev3 = NULLTAG;
	tag_t DesignPart = NULLTAG;
	int Part_Stat_Cnt = 0;
	tag_t *Part_Stat_Lst = NULLTAG;
	char * objtype=NULL;
	char * objtype1=NULL;
	char * PartRevID=NULL;
	char *PartOwner = NULL;
	char refname[AE_reference_size_c + 1];
	int referencenumberfound =0;
	int reftype =0;
	tag_t IPEMRelTag	= NULLTAG;
	tag_t* CreoGenTags = NULL;
	int cnt=0;
	int ref_count_d = 0;
	tag_t* namRefObject_d = NULL;
	tag_t reln_type_ProMem =NULLTAG;
	int n_attchs_ProMem = 0;
	tag_t* rellist_ProMem_DsgnRev =NULL;
	char *inputline = NULL;
	int clidExists = 0;
	int newUsgQty = 0;
	int nloop = 0;
	char *exepathdup = NULL;
	char* tmpRevCol = NULL;
	tmpRevCol = (char*)MEM_alloc( 100 *sizeof(char));
	char* tmpCatCol = NULL;
	tmpCatCol = (char*)MEM_alloc( 250 *sizeof(char));
	exepathdup = (char *)MEM_alloc(1000);

	tcuaEBOMData = (EBOMStruct*)MEM_alloc(2000 * sizeof(EBOMStruct));
	tcuaEBOMDataLatWrk = (EBOMStruct*)MEM_alloc(2000 * sizeof(EBOMStruct));
	tcuaCADBOMData = (CadBOMStruct*)MEM_alloc(2000 * sizeof(CadBOMStruct));
	IssueRepDt = (IssueRep*)MEM_alloc(250 * sizeof(IssueRep));

	RepExtChkChld = (char *)MEM_alloc(500);
	tc_strcpy(RepExtChkChld, "");

	char *inputPart=NULL;
	inputPart = ITK_ask_cli_argument("-Part=");
	char *inputRev=NULL;
	inputRev = ITK_ask_cli_argument("-Revision=");
	char *inputSeq=NULL;
	inputSeq = ITK_ask_cli_argument("-Sequence=");

	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	char Data[100] = "";
	char outputFile[200] = "";
	strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"Report_%s_%s.txt",inputPart,Data);

	if (inputPart == NULL || inputRev == NULL || inputSeq == NULL)
	{
		printf("Arguments NULL"); fflush(stdout);
		return 1;
	}

	if (tc_strcmp(inputPart,"")==0 || tc_strcmp(inputRev,"")==0 || tc_strcmp(inputSeq,"")==0)
	{
		printf("Arguments BLANK"); fflush(stdout);

		FILE *Report = NULL;
		char *XMLFileName = NULL;
		XMLFileName=(char *) MEM_alloc(200);
		sprintf(XMLFileName,"/tmp/Report_%s.xml",Data);
		Report=fopen(XMLFileName,"w");
		if (Report == NULL)
		{
			printf("ERROR: XML Cannot open File\n");
			return -1;
		}
		strftime(Data,100,"%d-%m-%Y %H:%M:%S",&when);
		write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		write2xml(Report,"\n<PLMXML date=\"");
		write2xml(Report,Data);
		write2xml(Report,"\" PartNo=\"");
		write2xml(Report,"BLANK");
		write2xml(Report,"\" RevSeq=\"");
		write2xml(Report,"BLANK");
		write2xml(Report,"\" >\n");
		write2xml(Report,"<DesignRevision>\n");
		write2xml(Report,"<field key =\"slNo\">");
		write2xml(Report,"---");
		write2xml(Report,"</field>\n");
		write2xml(Report,"<field key =\"item_id\">");
		write2xml(Report,"---");
		write2xml(Report,"</field>\n");
		write2xml(Report,"<field key =\"rev_seq\">");
		write2xml(Report,"---");
		write2xml(Report,"</field>\n");
		write2xml(Report,"<field key =\"issue_cat\">");
		write2xml(Report,"BLANK Arguments");
		write2xml(Report,"</field>\n");
		write2xml(Report,"<field key =\"issue_type\">");
		write2xml(Report,"Please fill Part No, Revision, Sequence - Then click on Finish");
		write2xml(Report,"</field>\n");
		write2xml(Report,"<field key =\"sol_type\">");
		write2xml(Report,"---");
		write2xml(Report,"</field>\n");
		write2xml(Report,"</DesignRevision>\n");
		write2xml(Report,"</PLMXML>\n");
		fclose(Report);
		tc_strcpy(exepathdup,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_DataValidation/RemoveProcessFiles.sh");
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,"ABCD");
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,"ABCD");
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,"ABCD");
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,"ABCD");
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,XMLFileName);

		system(exepathdup);

		return 1;
	}

	char outputFileTce[200] = "";
	tc_strcpy(outputFileTce,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_DataValidation/TCEOutput");
	tc_strcat(outputFileTce,outputFile);

	char outputFileTceCheck[200] = "";
	tc_strcpy(outputFileTceCheck,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_DataValidation/TCECheck");
	tc_strcat(outputFileTceCheck,outputFile);

	char tceEBOM[200] = "";
	tc_strcpy(tceEBOM,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_DataValidation/TceEBOM");
	tc_strcat(tceEBOM,outputFile);
	char tceCADBOM[200] = "";
	tc_strcpy(tceCADBOM,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_DataValidation/TceCADBOM");
	tc_strcat(tceCADBOM,outputFile);

	//char	outputFile[200]	= "output.csv";
	//char outputFileTce1[200] = "";
	//tc_strcpy(outputFileTce1,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_DataValidation/");
	//tc_strcat(outputFileTce1,outputFile);
	//output = fopen(outputFileTce1,"w");
	//if (output == NULL)
	//{
		//printf("ERROR: Cannot open File\n");
		//return -1;
	//}

	outputTCE = fopen(outputFileTceCheck,"w");
	if (outputTCE == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	
	//char *cEntries[1]  = {"Item ID"};
	
	char **cValues = (char **) MEM_alloc(50 * sizeof(char *));
	/*if (iFail == ITK_ok)
	{
		printf("\nTeamcenter Login Success...");fflush(stdout);
		POM_get_user(&username, &tuser);
	}
	else
	{
		EMH_ask_error_text(iFail, &cError);
		printf("\nError is : %s", cError);fflush(stdout);
	}
	if (cError)
	{
		MEM_free(cError);
	}
	if (username)
	{
		MEM_free(username);
	}*/

	tag_t relation_typeNULL = NULLTAG;
	int cntRel = 0;
	tag_t *attachmentsRel = NULLTAG;
	int rl = 0;
	int CadStat = 0;
	char *objtype1N = NULL;
	tag_t datasetN = NULLTAG;

	char *RevSeq = NULL;
	RevSeq = (char *)MEM_alloc(50);
	tc_strcpy(RevSeq,inputRev);
	tc_strcat(RevSeq,";");
	tc_strcat(RevSeq,inputSeq);
	char *cEntries[2]  = {"Item ID","Revision"};

	printf("\n\n Input Part: %s , %s",inputPart,RevSeq); fflush(stdout);				
	cValues[0] = inputPart;
	cValues[1] = RevSeq;
	//ITK_CALL(QRY_find2("Latest Item Revision for ERC",&tItemobj));
	ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
	ITK_CALL(QRY_execute(tItemobj, 2, cEntries, cValues, &n_itemobj_found, &titemobj_results));
	DesignPart = titemobj_results[0];
	ITK_CALL(GRM_find_relation_type("IMAN_specification",&relation_type2));
	printf("\n No of Objects: %d",n_itemobj_found); fflush(stdout);
	for(i=0;i<n_itemobj_found;i++)
	{
		char *RlStatus = NULL;
		RlStatus = (char *)MEM_alloc(250);
		iteamrev2=titemobj_results[i];
		itemrev=titemobj_results[i];
		iteamrev3=titemobj_results[i];
		ITK_CALL(AOM_ask_value_string(itemrev,"item_id",&PartID));
		ITK_CALL(AOM_ask_value_string(itemrev,"item_revision_id",&PartRevID));
		ITK_CALL(AOM_UIF_ask_value(itemrev,"owning_user",&PartOwner));
		if (tc_strstr(PartOwner,"loader")==NULL)
		{
			break;
		}
		//INFO FIT Check

		ITK_CALL(GRM_list_secondary_objects_only(itemrev,relation_typeNULL,&cntRel,&attachmentsRel));
		for (rl = 0; rl <cntRel ; ++rl)
		{
			datasetN=attachmentsRel[rl];
			if( AOM_ask_value_string(datasetN,"object_type",&objtype1N)!=ITK_ok);
			if (tc_strcmp(objtype1N,"ProAsm")==0 || tc_strcmp(objtype1N,"ProPrt")==0 || tc_strcmp(objtype1N,"ProDrw")==0|| tc_strcmp(objtype1N,"CMI2Part")==0|| tc_strcmp(objtype1N,"CMI2Product")==0|| tc_strcmp(objtype1N,"CMI2Drawing")==0)
			{
				CadStat = 1;
				break;
			}
		}

		//******************************************CAD BOM CHECK START********************
		ChkDataSetCreoMem(&itemrev);
		//******************************************CAD BOM CHECK END********************

		//******************************************BVR CHECK START - ERC Released and ABOVE********************
		tag_t tWindow = NULLTAG;
		tag_t rule = NULLTAG;
		tag_t tBOMLine1 = NULLTAG;
		tag_t* tBOM_Children = NULL;
		int iNumber_Child = 0;
		ITK_CALL(BOM_create_window( &tWindow));
		ITK_CALL(CFM_find("ERC release and above",&rule));
		ITK_CALL(BOM_set_window_config_rule(tWindow, rule));
		tag_t closure_tag;
		PIE_scope_t scope;
		scope=PIE_TEAMCENTER;
		int n_closure_tags;
		tag_t* closure_tags;
		ITK_CALL(PIE_find_closure_rules2("BOMViewClosureRuleERC",scope,&n_closure_tags,&closure_tags));
		if(n_closure_tags==1)
		{
			closure_tag=closure_tags[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(tWindow,closure_tag,0,NULL,NULL));
		ITK_CALL(BOM_set_window_top_line( tWindow, tItemobj, iteamrev2, NULLTAG, &tBOMLine1));
		ITK_CALL(BOM_line_ask_all_child_lines(tBOMLine1, &iNumber_Child, &tBOM_Children));
		if(iNumber_Child>0)
        {
        	int RevRuleType = 2;
			getchilds(iNumber_Child,tBOM_Children,RevRuleType,PartID,PartRevID,PartOwner,CadStat);
		}
		tBOM_Children = NULLTAG;
		ITK_CALL(BOM_close_window(tWindow));
		//printf("\n Return Value From BOM Close Window API is --------> %d", iFail);fflush(stdout);
		//******************************************BVR CHECK END - ERC Released and ABOVE********************

		//******************************************BVR CHECK START - Latest Working for ERC********************
		tag_t tWindow1 = NULLTAG;
		tag_t rule1 = NULLTAG;
		tag_t tBOMLine = NULLTAG;
		ITK_CALL(BOM_create_window( &tWindow1));
		//iFail = CFM_find( "Latest Working for ERC View", &rule1 );
		iFail = CFM_find( "Latest Working", &rule1 );
		iFail = BOM_set_window_config_rule(tWindow1, rule1 );
		tag_t closure_tag1;
		PIE_scope_t scope1;
		scope1=PIE_TEAMCENTER;
		int n_closure_tags1;
		tag_t* closure_tags1;
		ITK_CALL(PIE_find_closure_rules2("BOMViewClosureRuleERC",scope1,&n_closure_tags1,&closure_tags1));
		if(n_closure_tags1==1)
		{
			closure_tag1=closure_tags1[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(tWindow1,closure_tag1,0,NULL,NULL));
		ITK_CALL(BOM_set_window_top_line( tWindow1, tItemobj, iteamrev3, NULLTAG, &tBOMLine));
		ITK_CALL(BOM_line_ask_all_child_lines(tBOMLine, &iNumber_Child, &tBOM_Children));
		//printf("\n Return Value From For Latest Working --------> %d", iFail);fflush(stdout);
		//printf("\n No of Children Found For Latest Working---------> %d\n",iNumber_Child);fflush(stdout);
		if(iNumber_Child>0)
        {
        	int RevRuleType = 1;
			getchilds(iNumber_Child,tBOM_Children,RevRuleType,PartID,PartRevID,PartOwner,CadStat);
		}
		tBOM_Children = NULLTAG;
		ITK_CALL(BOM_close_window(tWindow1));
		//printf("\n Return Value From BOM For Latest Working --------> %d", iFail);fflush(stdout);
		//******************************************BVR CHECK START - Latest Working for ERC********************

		tc_strcpy(exepathdup,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_DataValidation/DataExistanceChk.sh");
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,outputFileTceCheck);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,outputFileTce);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,inputPart);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,inputRev);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,inputSeq);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,tceEBOM);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,tceCADBOM);
		
		printf("\n%s\n",exepathdup); fflush(stdout);
		system(exepathdup);

		EBOMStruct* tceEBOMData = (EBOMStruct*)MEM_alloc(500 * sizeof(EBOMStruct));
		int y = 0;
		int z = 0;
		FILE *TCEEbomFile = NULL;
		int EbomMainSize = 0;
		TCEEbomFile = fopen(tceEBOM,"r");
		//TCEEbomFile = fopen("EBOM.txt","r");
		if (TCEEbomFile == NULL)
		{
			printf("No Data File Check in TCE\n");
		}
		else
		{
			inputline=(char *) MEM_alloc(2000);
			while(fgets(inputline,2000,TCEEbomFile)!=NULL)
			{
				char *PartNo = NULL;
			    char *PartRev = NULL;
			    char *PartSeq = NULL;
				char *ChildPartNo = NULL;
			    char *ChildPartRev = NULL;
			    char *ChildPartSeq = NULL;
			    char *PartType = NULL;
			    char *t5PartCode = NULL;
			    char *t5DrawingInd = NULL;
			    char *t5DrawingNo = NULL;
			    char *ProjectName = NULL;
			    char *Designgroup = NULL;
			    char *t5Material = NULL;
			    char *t5RolledupWt = NULL;
			    char *t5UQdup = NULL;
			    char *UsesPartQty = NULL;
			    char *t5PartStatus = NULL;
			    int prsntStruct = 0;
			    PartNo = tc_strtok(inputline,"^");
			    PartRev = tc_strtok(NULL,"^");
			    PartSeq = tc_strtok(NULL,"^");
				ChildPartNo = tc_strtok(NULL,"^");
			    ChildPartRev = tc_strtok(NULL,"^");
			    ChildPartSeq = tc_strtok(NULL,"^");
			    PartType = tc_strtok(NULL,"^");
			    t5PartCode = tc_strtok(NULL,"^");
			    t5DrawingInd = tc_strtok(NULL,"^");
			    t5DrawingNo = tc_strtok(NULL,"^");
			    ProjectName = tc_strtok(NULL,"^");
			    Designgroup = tc_strtok(NULL,"^");
			    t5Material = tc_strtok(NULL,"^");
			    t5RolledupWt = tc_strtok(NULL,"^");
			    t5UQdup = tc_strtok(NULL,"^");
			    UsesPartQty = tc_strtok(NULL,"^");
			    t5PartStatus = tc_strtok(NULL,"^");

			    for (y = 0; y < EbomMainSize; y++)
			    {
			    	if(tc_strcmp(PartNo, tceEBOMData[y].PartNo) == 0)
			    	{
			    		printf("\nSuccess %s compare with %s --> Inset %s",tceEBOMData[y].PartNo,PartNo,ChildPartNo);fflush(stdout);
			    		prsntStruct = 1;

			    		clidExists = 0;
			    		newUsgQty = 0;
			    		nloop = 0;
			    		for (nloop = 0; nloop <= tceEBOMData[y].chldCnt ; ++nloop)
			    		{
			    			if (tc_strcmp(tceEBOMData[y].EBOMChild[nloop].ChildPartNo,ChildPartNo)==0)
			    			{
			    				clidExists = 1;
			    				newUsgQty = atoi(tceEBOMData[y].EBOMChild[nloop].UsesPartQty) + atoi(UsesPartQty);
			    				tceEBOMData[y].EBOMChild[nloop].UsesPartQty = (char*)MEM_alloc( 20 *sizeof(char));
			    				sprintf(tceEBOMData[y].EBOMChild[nloop].UsesPartQty,"%d",newUsgQty);
			    				break;
			    			}
			    		}

			    		if(clidExists == 0)
			    		{
				    		int nextPos = tceEBOMData[y].chldCnt + 1;
				    		tceEBOMData[y].chldCnt = nextPos;
				    		tceEBOMData[y].EBOMChild = (EBOMChildStruct*)MEM_realloc(tceEBOMData[y].EBOMChild, (nextPos+1) * sizeof(EBOMChildStruct));

				    		tceEBOMData[y].EBOMChild[nextPos].ChildPartNo = (char*)MEM_alloc( tc_strlen(ChildPartNo) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].ChildPartRev = (char*)MEM_alloc( tc_strlen(ChildPartRev) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].ChildPartSeq = (char*)MEM_alloc( tc_strlen(ChildPartSeq) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].PartType = (char*)MEM_alloc( tc_strlen(PartType) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].t5PartCode = (char*)MEM_alloc( tc_strlen(t5PartCode) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].t5DrawingInd = (char*)MEM_alloc( tc_strlen(t5DrawingInd) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].t5DrawingNo = (char*)MEM_alloc( tc_strlen(t5DrawingNo) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].ProjectName = (char*)MEM_alloc( tc_strlen(ProjectName) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].Designgroup = (char*)MEM_alloc( tc_strlen(Designgroup) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].t5Material = (char*)MEM_alloc( tc_strlen(t5Material) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].t5RolledupWt = (char*)MEM_alloc( tc_strlen(t5RolledupWt) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].t5UQdup = (char*)MEM_alloc( tc_strlen(t5UQdup) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].UsesPartQty = (char*)MEM_alloc( tc_strlen(UsesPartQty) *sizeof(char));
							tceEBOMData[y].EBOMChild[nextPos].t5PartStatus = (char*)MEM_alloc( tc_strlen(t5PartStatus) *sizeof(char));

				    		tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].ChildPartNo, ChildPartNo);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].ChildPartRev, ChildPartRev);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].ChildPartSeq, ChildPartSeq);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].PartType, PartType);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].t5PartCode, t5PartCode);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].t5DrawingInd, t5DrawingInd);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].t5DrawingNo, t5DrawingNo);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].ProjectName, ProjectName);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].Designgroup, Designgroup);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].t5Material, t5Material);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].t5RolledupWt, t5RolledupWt);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].t5UQdup, t5UQdup);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].UsesPartQty, UsesPartQty);
						    tc_strcpy(tceEBOMData[y].EBOMChild[nextPos].t5PartStatus, t5PartStatus);
						}
			    	}
			    }
			    if(prsntStruct == 0)
			    {
			    	printf("\n********************************************* %d Mismatch-%s-%s-%s--> Inset %s",EbomMainSize,PartNo,PartRev,PartSeq,ChildPartNo);fflush(stdout);
				    tceEBOMData[EbomMainSize].PartNo = (char*)MEM_alloc( tc_strlen(PartNo) *sizeof(char));
				    tc_strcpy(tceEBOMData[EbomMainSize].PartNo, PartNo);
				    tceEBOMData[EbomMainSize].PartRev = (char*)MEM_alloc( tc_strlen(PartRev) *sizeof(char));
					tc_strcpy(tceEBOMData[EbomMainSize].PartRev, PartRev);
					tceEBOMData[EbomMainSize].PartSeq = (char*)MEM_alloc( tc_strlen(PartSeq) *sizeof(char));
					tc_strcpy(tceEBOMData[EbomMainSize].PartSeq, PartSeq);
					tceEBOMData[EbomMainSize].chldCnt = 0;

					tceEBOMData[EbomMainSize].EBOMChild = (EBOMChildStruct*)MEM_alloc(1 * sizeof(EBOMChildStruct));
					tceEBOMData[EbomMainSize].EBOMChild[0].ChildPartNo = (char*)MEM_alloc( tc_strlen(ChildPartNo) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].ChildPartRev = (char*)MEM_alloc( tc_strlen(ChildPartRev) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].ChildPartSeq = (char*)MEM_alloc( tc_strlen(ChildPartSeq) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].PartType = (char*)MEM_alloc( tc_strlen(PartType) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].t5PartCode = (char*)MEM_alloc( tc_strlen(t5PartCode) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].t5DrawingInd = (char*)MEM_alloc( tc_strlen(t5DrawingInd) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].t5DrawingNo = (char*)MEM_alloc( tc_strlen(t5DrawingNo) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].ProjectName = (char*)MEM_alloc( tc_strlen(ProjectName) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].Designgroup = (char*)MEM_alloc( tc_strlen(Designgroup) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].t5Material = (char*)MEM_alloc( tc_strlen(t5Material) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].t5RolledupWt = (char*)MEM_alloc( tc_strlen(t5RolledupWt) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].t5UQdup = (char*)MEM_alloc( tc_strlen(t5UQdup) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].UsesPartQty = (char*)MEM_alloc( tc_strlen(UsesPartQty) *sizeof(char));
					tceEBOMData[EbomMainSize].EBOMChild[0].t5PartStatus = (char*)MEM_alloc( tc_strlen(t5PartStatus) *sizeof(char));

					tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].ChildPartNo, ChildPartNo);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].ChildPartRev, ChildPartRev);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].ChildPartSeq, ChildPartSeq);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].PartType, PartType);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].t5PartCode, t5PartCode);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].t5DrawingInd, t5DrawingInd);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].t5DrawingNo, t5DrawingNo);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].ProjectName, ProjectName);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].Designgroup, Designgroup);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].t5Material, t5Material);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].t5RolledupWt, t5RolledupWt);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].t5UQdup, t5UQdup);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].UsesPartQty, UsesPartQty);
				    tc_strcpy(tceEBOMData[EbomMainSize].EBOMChild[0].t5PartStatus, t5PartStatus);
					EbomMainSize++;
			    }
			}
			inputline = NULL;
		}
		fclose(TCEEbomFile);

		FILE *TCECadBomFile = NULL;
		CadBOMStruct* tceCADBOMData = (CadBOMStruct*)MEM_alloc(500 * sizeof(CadBOMStruct));
		int CadBomMainSize = 0;
		y = 0;
		z = 0;
		TCECadBomFile = fopen(tceCADBOM,"r");
		//TCECadBomFile = fopen("CADBOM.txt","r");
		if (TCECadBomFile == NULL)
		{
			printf("No Data File Check in TCE\n");
		}
		else
		{
			inputline=(char *) MEM_alloc(2000);
			while(fgets(inputline,2000,TCECadBomFile)!=NULL)
			{
				char *PartNo = NULL;
				char *ChildPartNo = NULL;
				int prsntStruct = 0;
				PartNo = tc_strtok(inputline,"^");
				ChildPartNo = tc_strtok(NULL,"^");

				for (y = 0; y < CadBomMainSize; y++)
			    {
			    	if(tc_strcmp(PartNo, tceCADBOMData[y].PartNo) == 0)
			    	{
			    		printf("\nCADBOM Success %s compare with %s --> Inset %s",tceCADBOMData[y].PartNo,PartNo,ChildPartNo);fflush(stdout);
			    		prsntStruct = 1;
			    		int nextPos = tceCADBOMData[y].chldCnt + 1;
			    		tceCADBOMData[y].chldCnt = nextPos;
			    		tceCADBOMData[y].CadBOMChild = (CadBOMChildStruct*)MEM_realloc(tceCADBOMData[y].CadBOMChild, (nextPos+1) * sizeof(CadBOMChildStruct));
			    		tceCADBOMData[y].CadBOMChild[nextPos].ChildPartNo = (char*)MEM_alloc( tc_strlen(ChildPartNo) *sizeof(char));
			    		tc_strcpy(tceCADBOMData[y].CadBOMChild[nextPos].ChildPartNo, ChildPartNo);
			    	}
			    }
			    if(prsntStruct == 0)
			    {
			    	printf("\n*********************************************CADBOM %d Mismatch-%s--> Inset %s",CadBomMainSize,PartNo,ChildPartNo);fflush(stdout);
				    tceCADBOMData[CadBomMainSize].PartNo = (char*)MEM_alloc( tc_strlen(PartNo) *sizeof(char));
				    tc_strcpy(tceCADBOMData[CadBomMainSize].PartNo, PartNo);
					tceCADBOMData[CadBomMainSize].chldCnt = 0;
					tceCADBOMData[CadBomMainSize].CadBOMChild = (CadBOMChildStruct*)MEM_alloc(1 * sizeof(CadBOMChildStruct));
					tceCADBOMData[CadBomMainSize].CadBOMChild[0].ChildPartNo = (char*)MEM_alloc( tc_strlen(ChildPartNo) *sizeof(char));
					tc_strcpy(tceCADBOMData[CadBomMainSize].CadBOMChild[0].ChildPartNo, ChildPartNo);
					CadBomMainSize++;
			    }
			}
			inputline = NULL;
		}
		fclose(TCECadBomFile);

		int zz=0;
		int yy=0;
		int TceTcuaMatch=0;

		int parentFoundTCE = 0;

		char **childBomNoApp = (char **) MEM_alloc(1000 * sizeof(char *));
		int nobomStrucMng = 0;
		
		if(EbomMainSize > 0)
		{
	    for (y = 0; y < TcuaEbomSize; ++y)
	    {
	    	if (tc_strstr(tcuaEBOMData[y].owninguser,"loader") == NULL)
	    	{
	    		continue;
	    	}
	    	
	    	parentFoundTCE = 0;
	    	//printf("\nTCUA EBOMPrinting Part: %s -- %s -- %s",tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev,tcuaEBOMData[y].PartSeq);fflush(stdout);
	    	for (yy = 0; yy < EbomMainSize; ++yy)
		    {
		    	//printf("\nTCE EBOMPrinting Part: %s -- %s -- %s",tceEBOMData[yy].PartNo,tceEBOMData[yy].PartRev,tceEBOMData[yy].PartSeq);fflush(stdout);
		    	if(tc_strcasecmp(tcuaEBOMData[y].PartNo, tceEBOMData[yy].PartNo)==0)
		    	{
		    		parentFoundTCE = 1;
		    		if (tc_strcmp(tcuaEBOMData[y].PartRev,tceEBOMData[yy].PartRev)!= 0 || tc_strcmp(tcuaEBOMData[y].PartSeq,tceEBOMData[yy].PartSeq)!= 0)
		    		{
		    			int updRelzStatusDMLUA = 1;
						updRelzStatusDMLUA = CheckTCUADML(tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev,tcuaEBOMData[y].PartSeq);
						if (updRelzStatusDMLUA == 1)
						{
							tc_strcpy(tmpRevCol, "");
							sprintf(tmpRevCol, "TCUA: %s;%s, TCE: %s;%s",tcuaEBOMData[y].PartRev,tcuaEBOMData[y].PartSeq,tceEBOMData[yy].PartRev,tceEBOMData[yy].PartSeq);
			    			AddIssueRepDt(tcuaEBOMData[y].PartNo,tmpRevCol,"Incremental Loading of Part Required / Effectivity Issue","Part Migration","Incremental Data Migration");
						}
		    		}
		    		else
		    		{
			    		if (tcuaEBOMData[y].chldCnt > tceEBOMData[yy].chldCnt)
			    		{
			    			for (z = 0; z <= tcuaEBOMData[y].chldCnt; ++z)
					    	{
					    		TceTcuaMatch=0;
					    		//printf("\n\t\tTCUA Child: %s -- %s -- %s -> %s", tcuaEBOMData[y].EBOMChild[z].ChildPartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq, tcuaEBOMData[y].EBOMChild[z].UsesPartQty);fflush(stdout);
					    		for (zz = 0; zz <= tceEBOMData[yy].chldCnt; ++zz)
						    	{
						    		if (tc_strcasecmp(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tceEBOMData[yy].EBOMChild[zz].ChildPartNo)==0)
						    		{
						    			//printf("\n\t\tTCE Child: %s -- %s -- %s -> %s", tceEBOMData[yy].EBOMChild[zz].ChildPartNo, tceEBOMData[yy].EBOMChild[zz].ChildPartRev, tceEBOMData[yy].EBOMChild[zz].ChildPartSeq, tceEBOMData[yy].EBOMChild[zz].UsesPartQty);fflush(stdout);
						    			TceTcuaMatch = 1;

						    			if (tc_strstr(tcuaEBOMData[y].EBOMChild[z].owninguser,"loader") == NULL)
								    	{
								    		continue;
								    	}

								    	if (tc_strcmp(tceEBOMData[yy].EBOMChild[zz].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartRev)!= 0 || tc_strcmp(tceEBOMData[yy].EBOMChild[zz].ChildPartSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq)!= 0)
							    		{
							    			//CHECK DML
											int updRelzStatusDMLUA = 1;
											updRelzStatusDMLUA = CheckTCUADML(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											
											if (updRelzStatusDMLUA == 1)
											{
												tc_strcpy(tmpRevCol, "");
												sprintf(tmpRevCol, "TCUA: %s;%s, TCE: %s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].ChildPartRev,tceEBOMData[yy].EBOMChild[zz].ChildPartSeq);
								    			AddIssueRepDt(tceEBOMData[yy].EBOMChild[zz].ChildPartNo,tmpRevCol,"Incremental Loading of Part Required / Effectivity Issue","Part Migration","Incremental Data Migration");

											}
											continue;
							    		}

							    		int tceQty = 0;
						    			int tcuaQty = 0;
						    			int isAllDigits = 1;
						    			int dig = 0;
						    			if (tceEBOMData[yy].EBOMChild[zz].UsesPartQty != NULL)
						    			{
										    for (dig = 0; tceEBOMData[yy].EBOMChild[zz].UsesPartQty[dig] != '\0'; dig++) {
										        if (!isdigit(tceEBOMData[yy].EBOMChild[zz].UsesPartQty[dig])) {
										            if (tceEBOMData[yy].EBOMChild[zz].UsesPartQty[dig] != '.')
										        	{
										        		isAllDigits = 0;
										            	break;
										        	}
										        }
										    }
										}
									    if (isAllDigits==1) {
									        tceQty = atoi(tceEBOMData[yy].EBOMChild[zz].UsesPartQty);
									    }
									    isAllDigits = 1;
									    if (tcuaEBOMData[y].EBOMChild[z].UsesPartQty != NULL)
									    {
										    for (dig = 0; tcuaEBOMData[y].EBOMChild[z].UsesPartQty[dig] != '\0'; dig++) {
										        if (!isdigit(tcuaEBOMData[y].EBOMChild[z].UsesPartQty[dig])) {
										        	if (tcuaEBOMData[y].EBOMChild[z].UsesPartQty[dig] != '.')
										        	{
										        		isAllDigits = 0;
										            	break;
										        	}
										        }
										    }
										}
									    if (isAllDigits==1) {
									        tcuaQty = atoi(tcuaEBOMData[y].EBOMChild[z].UsesPartQty);
									    }

									    if (tceQty != tcuaQty)
						    			//if(atoi(tceEBOMData[yy].EBOMChild[zz].UsesPartQty) != atoi(tcuaEBOMData[y].EBOMChild[z].UsesPartQty))
						    			{
						    				tc_strcpy(tmpRevCol, "");
											sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											tc_strcpy(tmpCatCol,"");
											sprintf(tmpCatCol, "Part Quantity Mismatch [TCE:%s | TCUA:%s] Immediate Parent: %s;%s;%s",tceEBOMData[yy].EBOMChild[zz].UsesPartQty,tcuaEBOMData[y].EBOMChild[z].UsesPartQty,tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev,tcuaEBOMData[y].PartSeq);
								    		AddIssueRepDt(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tmpRevCol,tmpCatCol,"Structure Manager","Remigration of Part");
								    			
						    				//fprintf(output,"%s,%s;%s,Part Quantity Mismatch [TCE:%s | TCUA:%s],Structure Manager,Remigration of Part\n",tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].UsesPartQty,tcuaEBOMData[y].EBOMChild[z].UsesPartQty);fflush(output);
						    			}

							    		if (tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) != 14 && tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) != 12)
							    		{
							    			printf("\nExclude Part Property Check except 12 and 14 Digit Part"); fflush(stdout);
							    			continue;
							    		}
						    			
						    			//Check All Params Qty / Part Type
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].PartType,tcuaEBOMData[y].EBOMChild[z].PartType)!=0)
						    			{
						    				if ((tc_strcmp(tceEBOMData[yy].EBOMChild[zz].PartType,"CP")==0 && tc_strcmp(tcuaEBOMData[y].EBOMChild[z].PartType,"CM")==0) || (tc_strcmp(tceEBOMData[yy].EBOMChild[zz].PartType,"D")==0 && tc_strcmp(tcuaEBOMData[y].EBOMChild[z].PartType,"IM")==0))
						    				{
						    					printf("\nPart Type OK\n"); fflush(stdout);
						    				}
						    				else
						    				{
						    					tc_strcpy(tmpRevCol, "");
												sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
												tc_strcpy(tmpCatCol,"");
												sprintf(tmpCatCol, "Part Type Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].PartType,tcuaEBOMData[y].EBOMChild[z].PartType);
									    		AddIssueRepDt(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tmpRevCol,tmpCatCol,"Part Property","Remigration of Part");

						    				//fprintf(output,"%s,%s;%s,Part Type Mismatch [TCE:%s | TCUA:%s],Part Property,Remigration of Part\n",tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].PartType,tcuaEBOMData[y].EBOMChild[z].PartType);fflush(output);
						    				}
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].t5PartStatus,tcuaEBOMData[y].EBOMChild[z].t5PartStatus)!=0)
						    			{
						    				//CHECK DML
											int updRelzStatusDMLUA = 1;
											updRelzStatusDMLUA = CheckTCUADML(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											
											if (updRelzStatusDMLUA == 1)
											{
												tc_strcpy(tmpRevCol, "");
												sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
												tc_strcpy(tmpCatCol,"");
												sprintf(tmpCatCol, "DR/AR Status Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].t5PartStatus,tcuaEBOMData[y].EBOMChild[z].t5PartStatus);
									    		AddIssueRepDt(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tmpRevCol,tmpCatCol,"Part Property","Remigration of Part");

						    				//fprintf(output,"%s,%s;%s,Drawing Indicator Mismatch [TCE:%s | TCUA:%s],Part Property,Remigration of Part\n",tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd);fflush(output);
						    				}
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd)!=0)
						    			{
						    				tc_strcpy(tmpRevCol, "");
											sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											tc_strcpy(tmpCatCol,"");
											sprintf(tmpCatCol, "Drawing Indicator Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd);
								    		AddIssueRepDt(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tmpRevCol,tmpCatCol,"Part Property","Remigration of Part");

						    				//fprintf(output,"%s,%s;%s,Drawing Indicator Mismatch [TCE:%s | TCUA:%s],Part Property,Remigration of Part\n",tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd);fflush(output);
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].ProjectName,tcuaEBOMData[y].EBOMChild[z].ProjectName)!=0)
						    			{
						    				tc_strcpy(tmpRevCol, "");
											sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											tc_strcpy(tmpCatCol,"");
											sprintf(tmpCatCol, "Project Code Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].ProjectName,tcuaEBOMData[y].EBOMChild[z].ProjectName);
								    		AddIssueRepDt(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tmpRevCol,tmpCatCol,"Part Property","Remigration of Part");

						    				//fprintf(output,"%s,%s;%s,Project Code Mismatch [TCE:%s | TCUA:%s],Part Property,Remigration of Part\n",tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].ProjectName,tcuaEBOMData[y].EBOMChild[z].ProjectName);fflush(output);
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].Designgroup,tcuaEBOMData[y].EBOMChild[z].Designgroup)!=0)
						    			{
						    				tc_strcpy(tmpRevCol, "");
											sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											tc_strcpy(tmpCatCol,"");
											sprintf(tmpCatCol, "Design Group Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].Designgroup,tcuaEBOMData[y].EBOMChild[z].Designgroup);
								    		AddIssueRepDt(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tmpRevCol,tmpCatCol,"Part Property","Remigration of Part");

						    				//fprintf(output,"%s,%s;%s,Design Group Mismatch [TCE:%s | TCUA:%s],Part Property,Remigration of Part\n",tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].Designgroup,tcuaEBOMData[y].EBOMChild[z].Designgroup);fflush(output);
						    			}
						    		}
						    	}
						    	if (TceTcuaMatch == 0)
						    	{
						    		int a1=0;
						    		int a2=0;
						    		int foundInCAD = 0;
						    		for (a1 = 0; a1 < TcuaCadBomSize; ++a1)
								    {
										if(tc_strcasecmp(tcuaCADBOMData[a1].PartNo, tcuaEBOMData[y].PartNo)==0)
										{
											for (a2 = 0; a2 <= tcuaCADBOMData[a1].chldCnt; ++a2)
					    					{
					    						if (tc_strcasecmp(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaCADBOMData[a1].CadBOMChild[a2].ChildPartNo)==0)
						    					{
													foundInCAD = 1;
													break;
												}
											}
										}
										if (foundInCAD == 1)
										{
											break;
										}
									}

						    		//Print TCUA PART as extra
						    		if (foundInCAD == 0)
						    		{
						    			//CHECK DML
										int updRelzStatusDMLUA = 1;
										updRelzStatusDMLUA = CheckTCUADML(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
										
										if (updRelzStatusDMLUA == 1 && tc_strcmp(tcuaEBOMData[y].EBOMChild[z].PartType,"D")!=0)
										{
											tc_strcpy(tmpRevCol, "");
											sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].PartRev, tcuaEBOMData[y].PartSeq);
											tc_strcpy(tmpCatCol,"");
											sprintf(tmpCatCol, "Extra Part in TCUA Structure: %s",tcuaEBOMData[y].EBOMChild[z].ChildPartNo);
								    		AddIssueRepDt(tcuaEBOMData[y].PartNo,tmpRevCol,tmpCatCol,"Structure Manager","Frontend/Backend Correction");

										}
									}
						    		//fprintf(output,"%s,%s;%s,Extra Part in TCUA Structure: %s,Structure Manager,Frontend/Backend Correction\n",tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev,tcuaEBOMData[y].PartSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartNo);fflush(output);
						    	}
					    	}
			    		}
			    		else if(tcuaEBOMData[y].chldCnt < tceEBOMData[yy].chldCnt)
			    		{
			    			for (zz = 0; zz <= tceEBOMData[yy].chldCnt; ++zz)
					    	{
					    		TceTcuaMatch=0;
					    		//printf("\n\t\tTCE Child: %s -- %s -- %s -> %s", tceEBOMData[yy].EBOMChild[zz].ChildPartNo, tceEBOMData[yy].EBOMChild[zz].ChildPartRev, tceEBOMData[yy].EBOMChild[zz].ChildPartSeq, tceEBOMData[yy].EBOMChild[zz].UsesPartQty);fflush(stdout);
					    		for (z = 0; z <= tcuaEBOMData[y].chldCnt; ++z)
						    	{
						    		if (tc_strcasecmp(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tceEBOMData[yy].EBOMChild[zz].ChildPartNo)==0)
						    		{
						    			//printf("\n\t\tTCUA Child: %s -- %s -- %s -> %s", tcuaEBOMData[y].EBOMChild[z].ChildPartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq, tcuaEBOMData[y].EBOMChild[z].UsesPartQty);fflush(stdout);
						    			TceTcuaMatch = 1;

						    			if (tc_strstr(tcuaEBOMData[y].EBOMChild[z].owninguser,"loader") == NULL)
								    	{
								    		continue;
								    	}

								    	if (tc_strcmp(tceEBOMData[yy].EBOMChild[zz].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartRev)!= 0 || tc_strcmp(tceEBOMData[yy].EBOMChild[zz].ChildPartSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq)!= 0)
							    		{
							    			//CHECK DML
											int updRelzStatusDMLUA = 1;
											updRelzStatusDMLUA = CheckTCUADML(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											
											if (updRelzStatusDMLUA == 1)
											{
												tc_strcpy(tmpRevCol, "");
												sprintf(tmpRevCol, "TCUA: %s;%s, TCE: %s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].ChildPartRev,tceEBOMData[yy].EBOMChild[zz].ChildPartSeq);
												AddIssueRepDt(tceEBOMData[yy].EBOMChild[zz].ChildPartNo,tmpRevCol,"Incremental Loading of Part Required / Effectivity Issue","Part Migration","Incremental Data Migration");

											}
											continue;
							    		}

							    		int tceQty = 0;
						    			int tcuaQty = 0;
						    			int isAllDigits = 1;
						    			int dig = 0;
						    			if (tceEBOMData[yy].EBOMChild[zz].UsesPartQty != NULL)
						    			{
										    for (dig = 0; tceEBOMData[yy].EBOMChild[zz].UsesPartQty[dig] != '\0'; dig++) {
										        if (!isdigit(tceEBOMData[yy].EBOMChild[zz].UsesPartQty[dig])) {
										            if (tceEBOMData[yy].EBOMChild[zz].UsesPartQty[dig] != '.')
										        	{
										        		isAllDigits = 0;
										            	break;
										        	}
										        }
										    }
										}
									    if (isAllDigits==1) {
									        tceQty = atoi(tceEBOMData[yy].EBOMChild[zz].UsesPartQty);
									    }
									    isAllDigits = 1;
									    if (tcuaEBOMData[y].EBOMChild[z].UsesPartQty != NULL)
									    {
										    for (dig = 0; tcuaEBOMData[y].EBOMChild[z].UsesPartQty[dig] != '\0'; dig++) {
										        if (!isdigit(tcuaEBOMData[y].EBOMChild[z].UsesPartQty[dig])) {
										            if (tcuaEBOMData[y].EBOMChild[z].UsesPartQty[dig] != '.')
										        	{
										        		isAllDigits = 0;
										            	break;
										        	}
										        }
										    }
										}
									    if (isAllDigits==1) {
									        tcuaQty = atoi(tcuaEBOMData[y].EBOMChild[z].UsesPartQty);
									    }

									    if (tceQty != tcuaQty)
						    			//if(atoi(tceEBOMData[yy].EBOMChild[zz].UsesPartQty) != atoi(tcuaEBOMData[y].EBOMChild[z].UsesPartQty))
						    			{
						    				tc_strcpy(tmpRevCol, "");
						    				sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											tc_strcpy(tmpCatCol,"");
											sprintf(tmpCatCol, "Part Quantity Mismatch [TCE:%s | TCUA:%s] Immediate Parent: %s;%s;%s",tceEBOMData[yy].EBOMChild[zz].UsesPartQty,tcuaEBOMData[y].EBOMChild[z].UsesPartQty,tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev,tcuaEBOMData[y].PartSeq);
								    		AddIssueRepDt(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tmpRevCol,tmpCatCol,"Structure Manager","Remigration of Part");

						    				//fprintf(output,"%s,%s;%s,Part Quantity Mismatch [TCE:%s | TCUA:%s],Structure Manager,Remigration of Part\n",tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].UsesPartQty,tcuaEBOMData[y].EBOMChild[z].UsesPartQty);fflush(output);
						    			}

							    		if (tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) != 14 && tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) != 12)
							    		{
							    			printf("\nExclude Part Property Check except 12 and 14 Digit Part"); fflush(stdout);
							    			continue;
							    		}
						    			
						    			//Check All Params Qty / Part Type
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].PartType,tcuaEBOMData[y].EBOMChild[z].PartType)!=0)
						    			{
						    				if ((tc_strcmp(tceEBOMData[yy].EBOMChild[zz].PartType,"CP")==0 && tc_strcmp(tcuaEBOMData[y].EBOMChild[z].PartType,"CM")==0) || (tc_strcmp(tceEBOMData[yy].EBOMChild[zz].PartType,"D")==0 && tc_strcmp(tcuaEBOMData[y].EBOMChild[z].PartType,"IM")==0))
						    				{
						    					printf("\nPart Type OK\n"); fflush(stdout);
						    				}
						    				else
						    				{
						    					tc_strcpy(tmpRevCol, "");
												sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
												tc_strcpy(tmpCatCol,"");
												sprintf(tmpCatCol, "Part Type Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].PartType,tcuaEBOMData[y].EBOMChild[z].PartType);
									    		AddIssueRepDt(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tmpRevCol,tmpCatCol,"Part Property","Remigration of Part");

						    				//fprintf(output,"%s,%s;%s,Part Type Mismatch [TCE:%s | TCUA:%s],Part Property,Remigration of Part\n",tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].PartType,tcuaEBOMData[y].EBOMChild[z].PartType);fflush(output);
						    				}
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].t5PartStatus,tcuaEBOMData[y].EBOMChild[z].t5PartStatus)!=0)
						    			{
						    				//CHECK DML
											int updRelzStatusDMLUA = 1;
											updRelzStatusDMLUA = CheckTCUADML(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											
											if (updRelzStatusDMLUA == 1)
											{
												tc_strcpy(tmpRevCol, "");
												sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
												tc_strcpy(tmpCatCol,"");
												sprintf(tmpCatCol, "DR/AR Status Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].t5PartStatus,tcuaEBOMData[y].EBOMChild[z].t5PartStatus);
									    		AddIssueRepDt(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tmpRevCol,tmpCatCol,"Part Property","Remigration of Part");

						    				//fprintf(output,"%s,%s;%s,Drawing Indicator Mismatch [TCE:%s | TCUA:%s],Part Property,Remigration of Part\n",tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd);fflush(output);
						    				}
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd)!=0)
						    			{
						    				tc_strcpy(tmpRevCol, "");
											sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											tc_strcpy(tmpCatCol,"");
											sprintf(tmpCatCol, "Drawing Indicator Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd);
								    		AddIssueRepDt(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tmpRevCol,tmpCatCol,"Part Property","Remigration of Part");

						    				//fprintf(output,"%s,%s;%s,Drawing Indicator Mismatch [TCE:%s | TCUA:%s],Part Property,Remigration of Part\n",tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd);fflush(output);
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].ProjectName,tcuaEBOMData[y].EBOMChild[z].ProjectName)!=0)
						    			{
						    				tc_strcpy(tmpRevCol, "");
											sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											tc_strcpy(tmpCatCol,"");
											sprintf(tmpCatCol, "Project Code Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].ProjectName,tcuaEBOMData[y].EBOMChild[z].ProjectName);
								    		AddIssueRepDt(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tmpRevCol,tmpCatCol,"Part Property","Remigration of Part");

						    				//fprintf(output,"%s,%s;%s,Project Code Mismatch [TCE:%s | TCUA:%s],Part Property,Remigration of Part\n",tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].ProjectName,tcuaEBOMData[y].EBOMChild[z].ProjectName);fflush(output);
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].Designgroup,tcuaEBOMData[y].EBOMChild[z].Designgroup)!=0)
						    			{
						    				tc_strcpy(tmpRevCol, "");
											sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											tc_strcpy(tmpCatCol,"");
											sprintf(tmpCatCol, "Design Group Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].Designgroup,tcuaEBOMData[y].EBOMChild[z].Designgroup);
								    		AddIssueRepDt(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tmpRevCol,tmpCatCol,"Part Property","Remigration of Part");

						    				//fprintf(output,"%s,%s;%s,Design Group Mismatch [TCE:%s | TCUA:%s],Part Property,Remigration of Part\n",tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].Designgroup,tcuaEBOMData[y].EBOMChild[z].Designgroup);fflush(output);
						    			}
						    			
						    		}
						    	}
						    	if (TceTcuaMatch == 0)
						    	{
						    		tc_strcpy(tmpRevCol, "");
									sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].PartRev, tcuaEBOMData[y].PartSeq);
									tc_strcpy(tmpCatCol,"");
									sprintf(tmpCatCol, "Missing Part in TCUA Structure: %s",tceEBOMData[yy].EBOMChild[zz].ChildPartNo);
						    		AddIssueRepDt(tcuaEBOMData[y].PartNo,tmpRevCol,tmpCatCol,"Structure Manager","Frontend/Backend Correction");

						    		//Print TCE PART Missing
						    		//fprintf(output,"%s,%s;%s,Missing Part in TCUA Structure: %s,Structure Manager,Remigration of Part\n",tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev,tcuaEBOMData[y].PartSeq,tceEBOMData[yy].EBOMChild[zz].ChildPartNo);fflush(output);
						    	}
					    	}
			    		}
			    		else
			    		{
			    			//Child Count Same now Check All Params Qty / Part Type
			    			for (zz = 0; zz <= tceEBOMData[yy].chldCnt; ++zz)
					    	{
					    		//printf("\n\t\tTCE Child: %s -- %s -- %s -> %s", tceEBOMData[yy].EBOMChild[zz].ChildPartNo, tceEBOMData[yy].EBOMChild[zz].ChildPartRev, tceEBOMData[yy].EBOMChild[zz].ChildPartSeq, tceEBOMData[yy].EBOMChild[zz].UsesPartQty);fflush(stdout);
					    		for (z = 0; z <= tcuaEBOMData[y].chldCnt; ++z)
						    	{
						    		if (tc_strcasecmp(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tceEBOMData[yy].EBOMChild[zz].ChildPartNo)==0)
						    		{
						    			if (tc_strstr(tcuaEBOMData[y].EBOMChild[z].owninguser,"loader") == NULL)
								    	{
								    		continue;
								    	}
								    	if (tc_strcmp(tceEBOMData[yy].EBOMChild[zz].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartRev)!= 0 || tc_strcmp(tceEBOMData[yy].EBOMChild[zz].ChildPartSeq,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq)!= 0)
							    		{
							    			//CHECK DML
											int updRelzStatusDMLUA = 1;
											updRelzStatusDMLUA = CheckTCUADML(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											
											if (updRelzStatusDMLUA == 1)
											{
												tc_strcpy(tmpRevCol, "");
												sprintf(tmpRevCol, "TCUA: %s;%s, TCE: %s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].ChildPartRev,tceEBOMData[yy].EBOMChild[zz].ChildPartSeq);
								    			AddIssueRepDt(tceEBOMData[yy].EBOMChild[zz].ChildPartNo,tmpRevCol,"Incremental Loading of Part Required / Effectivity Issue","Part Migration","Incremental Data Migration");
											}
											continue;
							    		}

							    		int tceQty = 0;
						    			int tcuaQty = 0;
						    			int isAllDigits = 1;
						    			int dig = 0;
						    			if (tceEBOMData[yy].EBOMChild[zz].UsesPartQty != NULL)
						    			{
										    for (dig = 0; tceEBOMData[yy].EBOMChild[zz].UsesPartQty[dig] != '\0'; dig++) {
										        if (!isdigit(tceEBOMData[yy].EBOMChild[zz].UsesPartQty[dig])) {
										        	if (tceEBOMData[yy].EBOMChild[zz].UsesPartQty[dig] != '.')
										        	{
										        		isAllDigits = 0;
										            	break;
										        	}
										        }
										    }
										}
									    if (isAllDigits==1) {
									        tceQty = atoi(tceEBOMData[yy].EBOMChild[zz].UsesPartQty);
									    }
									    isAllDigits = 1;
									    if (tcuaEBOMData[y].EBOMChild[z].UsesPartQty != NULL)
									    {
										    for (dig = 0; tcuaEBOMData[y].EBOMChild[z].UsesPartQty[dig] != '\0'; dig++) {
										        if (!isdigit(tcuaEBOMData[y].EBOMChild[z].UsesPartQty[dig])) {
										            if (tcuaEBOMData[y].EBOMChild[z].UsesPartQty[dig] != '.')
										        	{
										        		isAllDigits = 0;
										            	break;
										        	}
										        }
										    }
										}
									    if (isAllDigits==1) {
									        tcuaQty = atoi(tcuaEBOMData[y].EBOMChild[z].UsesPartQty);
									    }

									    if (tceQty != tcuaQty)
						    			//if(atoi(tceEBOMData[yy].EBOMChild[zz].UsesPartQty) != atoi(tcuaEBOMData[y].EBOMChild[z].UsesPartQty))
						    			{
						    				tc_strcpy(tmpRevCol, "");
											sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											tc_strcpy(tmpCatCol,"");
											sprintf(tmpCatCol, "Part Quantity Mismatch [TCE:%s | TCUA:%s] Immediate Parent: %s;%s;%s",tceEBOMData[yy].EBOMChild[zz].UsesPartQty,tcuaEBOMData[y].EBOMChild[z].UsesPartQty,tcuaEBOMData[y].PartNo,tcuaEBOMData[y].PartRev,tcuaEBOMData[y].PartSeq);
								    		AddIssueRepDt(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tmpRevCol,tmpCatCol,"Structure Manager","Remigration of Part");

						    				//fprintf(output,"%s,%s;%s,Part Quantity Mismatch [TCE:%s | TCUA:%s],Structure Manager,Remigration of Part\n",tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].UsesPartQty,tcuaEBOMData[y].EBOMChild[z].UsesPartQty);fflush(output);
						    			}

							    		if (tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) != 14 && tc_strlen(tcuaEBOMData[y].EBOMChild[z].ChildPartNo) != 12)
							    		{
							    			printf("\nExclude Part Property Check except 12 and 14 Digit Part"); fflush(stdout);
							    			continue;
							    		}
							    		
						    			//printf("\n\t\tTCUA Child: %s -- %s -- %s -> %s", tcuaEBOMData[y].EBOMChild[z].ChildPartNo, tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq, tcuaEBOMData[y].EBOMChild[z].UsesPartQty);fflush(stdout);
						    			//Check All Params Qty / Part Type
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].PartType,tcuaEBOMData[y].EBOMChild[z].PartType)!=0)
						    			{
						    				if ((tc_strcmp(tceEBOMData[yy].EBOMChild[zz].PartType,"CP")==0 && tc_strcmp(tcuaEBOMData[y].EBOMChild[z].PartType,"CM")==0) || (tc_strcmp(tceEBOMData[yy].EBOMChild[zz].PartType,"D")==0 && tc_strcmp(tcuaEBOMData[y].EBOMChild[z].PartType,"IM")==0))
						    				{
						    					printf("\nPart Type OK\n"); fflush(stdout);
						    				}
						    				else
						    				{
						    					tc_strcpy(tmpRevCol, "");
												sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
												tc_strcpy(tmpCatCol,"");
												sprintf(tmpCatCol, "Part Type Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].PartType,tcuaEBOMData[y].EBOMChild[z].PartType);
									    		AddIssueRepDt(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tmpRevCol,tmpCatCol,"Part Property","Remigration of Part");

							    				//fprintf(output,"%s,%s;%s,Part Type Mismatch [TCE:%s | TCUA:%s],Part Property,Remigration of Part\n",tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].PartType,tcuaEBOMData[y].EBOMChild[z].PartType);fflush(output);
							    			}
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].t5PartStatus,tcuaEBOMData[y].EBOMChild[z].t5PartStatus)!=0)
						    			{
						    				//CHECK DML
											int updRelzStatusDMLUA = 1;
											updRelzStatusDMLUA = CheckTCUADML(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											
											if (updRelzStatusDMLUA == 1)
											{
												tc_strcpy(tmpRevCol, "");
												sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
												tc_strcpy(tmpCatCol,"");
												sprintf(tmpCatCol, "DR/AR Status Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].t5PartStatus,tcuaEBOMData[y].EBOMChild[z].t5PartStatus);
									    		AddIssueRepDt(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tmpRevCol,tmpCatCol,"Part Property","Remigration of Part");

						    				//fprintf(output,"%s,%s;%s,Drawing Indicator Mismatch [TCE:%s | TCUA:%s],Part Property,Remigration of Part\n",tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd);fflush(output);
						    				}
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd)!=0)
						    			{
						    				tc_strcpy(tmpRevCol, "");
											sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											tc_strcpy(tmpCatCol,"");
											sprintf(tmpCatCol, "Drawing Indicator Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd);
								    		AddIssueRepDt(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tmpRevCol,tmpCatCol,"Part Property","Remigration of Part");

						    				//fprintf(output,"%s,%s;%s,Drawing Indicator Mismatch [TCE:%s | TCUA:%s],Part Property,Remigration of Part\n",tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].t5DrawingInd,tcuaEBOMData[y].EBOMChild[z].t5DrawingInd);fflush(output);
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].ProjectName,tcuaEBOMData[y].EBOMChild[z].ProjectName)!=0)
						    			{
						    				tc_strcpy(tmpRevCol, "");
											sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											tc_strcpy(tmpCatCol,"");
											sprintf(tmpCatCol, "Project Code Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].ProjectName,tcuaEBOMData[y].EBOMChild[z].ProjectName);
								    		AddIssueRepDt(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tmpRevCol,tmpCatCol,"Part Property","Remigration of Part");

						    				//fprintf(output,"%s,%s;%s,Project Code Mismatch [TCE:%s | TCUA:%s],Part Property,Remigration of Part\n",tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].ProjectName,tcuaEBOMData[y].EBOMChild[z].ProjectName);fflush(output);
						    			}
						    			if(tc_strcasecmp(tceEBOMData[yy].EBOMChild[zz].Designgroup,tcuaEBOMData[y].EBOMChild[z].Designgroup)!=0)
						    			{
						    				tc_strcpy(tmpRevCol, "");
											sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].EBOMChild[z].ChildPartRev, tcuaEBOMData[y].EBOMChild[z].ChildPartSeq);
											tc_strcpy(tmpCatCol,"");
											sprintf(tmpCatCol, "Design Group Mismatch [TCE:%s | TCUA:%s]",tceEBOMData[yy].EBOMChild[zz].Designgroup,tcuaEBOMData[y].EBOMChild[z].Designgroup);
								    		AddIssueRepDt(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tmpRevCol,tmpCatCol,"Part Property","Remigration of Part");

						    				//fprintf(output,"%s,%s;%s,Design Group Mismatch [TCE:%s | TCUA:%s],Part Property,Remigration of Part\n",tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaEBOMData[y].EBOMChild[z].ChildPartRev,tcuaEBOMData[y].EBOMChild[z].ChildPartSeq,tceEBOMData[yy].EBOMChild[zz].Designgroup,tcuaEBOMData[y].EBOMChild[z].Designgroup);fflush(output);
						    			}
						    			
						    		}
						    	}
					    	}
			    		}
		    		}
			    	break;
		    	}
		    }

		    if(parentFoundTCE == 0)
		    {
		    	int dataChecked = 0;
		    	for (yy = 0; yy < nobomStrucMng; ++yy)
		    	{
		    		if (tc_strcmp(childBomNoApp[yy],tcuaEBOMData[y].PartNo)==0)
		    		{
		    			dataChecked = 1;
		    		}
		    	}

		    	if (dataChecked == 0)
		    	{
					int a1=0;
		    		int a2=0;
		    		int foundInCAD = 0;
		    		for (a1 = 0; a1 < TcuaCadBomSize; ++a1)
				    {
						if(tc_strcasecmp(tcuaCADBOMData[a1].PartNo, tcuaEBOMData[y].PartNo)==0)
						{
							foundInCAD = 1;
							break;
							//for (a2 = 0; a2 <= tcuaCADBOMData[a1].chldCnt; ++a2)
	    					//{
	    					//	if (tc_strcasecmp(tcuaEBOMData[y].EBOMChild[z].ChildPartNo,tcuaCADBOMData[a1].CadBOMChild[a2].ChildPartNo)==0)
		    				//	{
							//		foundInCAD = 1;
							//		break;
							//	}
							//}
						}
						//if (foundInCAD == 1)
						//{
						//	break;
						//}
					}
					if (foundInCAD == 0)
					{
						tag_t queryAlo1 = NULLTAG;
						char *newRevSeq = NULL;
						char **qry_valuesAlo1 = (char **) MEM_alloc(50 * sizeof(char *));
						int n_foundAlo1 = 0;
						tag_t* cntr_objectsAlo1 = NULL;
						tag_t tagItem1 = NULLTAG;
						tag_t relation_typeAlo2 = NULLTAG;
						int cntAlo = 0;
						tag_t* attachmentsAlo = NULL;
						tag_t dataSetProe = NULLTAG;
						int alo = 0;
						char *objtypeAlo = NULLTAG;
						tag_t reln_type_ProMemAlo = NULLTAG;
						int n_attchs_ProMemAlo = 0;
						tag_t* rellist_ProMem_DsgnRevAlo = NULL;
						newRevSeq = (char*)MEM_alloc(sizeof(char) * 20);
						ITK_CALL(QRY_find2("Item Revision...",&queryAlo1));
						tc_strcpy(newRevSeq,tcuaEBOMData[y].PartRev);
						tc_strcat(newRevSeq,";");
						tc_strcat(newRevSeq,tcuaEBOMData[y].PartSeq);
						qry_valuesAlo1[0] = tcuaEBOMData[y].PartNo;
						qry_valuesAlo1[1] = newRevSeq;
						char *qry_entries1[2]  = {"Item ID","Revision"};
						ITK_CALL(QRY_execute(queryAlo1, 2, qry_entries1, qry_valuesAlo1, &n_foundAlo1, &cntr_objectsAlo1));
						if (n_foundAlo1 > 0)
						{
							tagItem1 = cntr_objectsAlo1[0];
							ITK_CALL(GRM_find_relation_type("IMAN_specification",&relation_typeAlo2));
							ITK_CALL(GRM_list_secondary_objects_only(tagItem1,relation_typeAlo2,&cntAlo,&attachmentsAlo));
							if (cntAlo > 0)
							{
								for (alo = 0; alo < cntAlo; ++alo)
								{
									dataSetProe = attachmentsAlo[alo];
									ITK_CALL(AOM_ask_value_string(dataSetProe,"object_type",&objtypeAlo));
									if(tc_strcmp(objtypeAlo,"ProAsm")==0)
									{
										ITK_CALL(GRM_find_relation_type("Pro2_membership",&reln_type_ProMemAlo));
										ITK_CALL(GRM_list_secondary_objects_only(dataSetProe,reln_type_ProMemAlo,&n_attchs_ProMemAlo,&rellist_ProMem_DsgnRevAlo));
										if (n_attchs_ProMemAlo > 0)
										{
											foundInCAD = 1;
											break;
										}
									}
								}
							}
						}
					}

		    		if (foundInCAD == 0)
		    		{
		    			tc_strcpy(tmpRevCol, "");
						sprintf(tmpRevCol, "%s;%s",tcuaEBOMData[y].PartRev, tcuaEBOMData[y].PartSeq);
						tc_strcpy(tmpCatCol,"");
						sprintf(tmpCatCol, "Part has Structure in UA but not in TCE : Need to Delete Complete BVR/Structure");
			    		AddIssueRepDt(tcuaEBOMData[y].PartNo,tmpRevCol,tmpCatCol,"Structure Manager","Manual Correction");
					}
				}

				for (yy = 0; yy <= tcuaEBOMData[y].chldCnt; ++yy)
		    	{
		    		dataChecked = 0;
		    		for (zz = 0; zz < nobomStrucMng; ++zz)
		    		{
		    			if (tc_strcmp(childBomNoApp[zz],tcuaEBOMData[y].EBOMChild[yy].ChildPartNo)==0)
			    		{
			    			dataChecked = 1;
			    		}
		    		}
		    		if (dataChecked == 0)
		    		{
		    			childBomNoApp[nobomStrucMng] = tcuaEBOMData[y].EBOMChild[yy].ChildPartNo;
		    			nobomStrucMng++;
		    		}
		    	}
		    }
	    }
		}
		else
		{
			printf("\nTCE Service Not Available EBOM : %d",EbomMainSize); fflush(stdout);
		}

		//printf("\nCADBOM : %d -- %d",CadBomMainSize,TcuaCadBomSize); fflush(stdout);
		if(CadBomMainSize > 0)
		{
	    for (y = 0; y < TcuaCadBomSize; ++y)
	    {
	    	//printf("\nTCUA CADBOM Printing Parent Part: %s -- %d",tcuaCADBOMData[y].PartNo, tcuaCADBOMData[y].chldCnt);fflush(stdout);
	    	for (yy = 0; yy < CadBomMainSize; ++yy)
		    {
		    	//printf("\nTCE CADBOM Printing Parent Part: %s -- %d",tceCADBOMData[yy].PartNo, tceCADBOMData[yy].chldCnt);fflush(stdout);
		    	if (tc_strlen(tcuaCADBOMData[y].PartNo) <= tc_strlen(tceCADBOMData[yy].PartNo))
		    	{
		    	if(tc_strncasecmp(tceCADBOMData[yy].PartNo, tcuaCADBOMData[y].PartNo, tc_strlen(tcuaCADBOMData[y].PartNo)) == 0)
		    	//if(tc_strcasecmp(tcuaCADBOMData[y].PartNo, tceCADBOMData[yy].PartNo)==0)
		    	{
		    		if (tcuaCADBOMData[y].chldCnt > tceCADBOMData[yy].chldCnt)
		    		{
		    			for (z = 0; z <= tcuaCADBOMData[y].chldCnt; ++z)
				    	{
				    		TceTcuaMatch=0;
				    		//printf("\n\t\tTCUA CADBOM Child: %s", tcuaCADBOMData[y].CadBOMChild[z].ChildPartNo);fflush(stdout);
				    		for (zz = 0; zz <= tceCADBOMData[yy].chldCnt; ++zz)
					    	{
					    		//printf("\n\t\tTCE CADBOM Child: %s", tceCADBOMData[yy].CadBOMChild[zz].ChildPartNo);fflush(stdout);
					    		if (tc_strlen(tcuaCADBOMData[y].CadBOMChild[z].ChildPartNo) <= tc_strlen(tceCADBOMData[yy].CadBOMChild[zz].ChildPartNo))
					    		{
					    		if(tc_strncasecmp(tceCADBOMData[yy].CadBOMChild[zz].ChildPartNo, tcuaCADBOMData[y].CadBOMChild[z].ChildPartNo, tc_strlen(tcuaCADBOMData[y].CadBOMChild[z].ChildPartNo)) == 0)
					    		//if (tc_strstr(tceCADBOMData[yy].CadBOMChild[zz].ChildPartNo,tcuaCADBOMData[y].CadBOMChild[z].ChildPartNo)!=NULL)
					    		{
					    			TceTcuaMatch=1;
					    			break;
					    		}
					    		}
					    	}
					    	if (TceTcuaMatch == 0)
					    	{
					    		tc_strcpy(tmpRevCol, "");
								sprintf(tmpRevCol, "%s;%s",tcuaCADBOMData[y].PartRev, tcuaCADBOMData[y].PartSeq);
								tc_strcpy(tmpCatCol,"");
								sprintf(tmpCatCol, "Extra Part in CREO Membership: %s",tcuaCADBOMData[y].CadBOMChild[z].ChildPartNo);
					    		AddIssueRepDt(tcuaCADBOMData[y].PartNo,tmpRevCol,tmpCatCol,"CREO Membership","Frontend/Backend Correction");

					    		//fprintf(output,"%s,%s;%s,Extra Part in CREO Membership: %s,CREO Membership,Frontend/Backend Correction\n",tcuaCADBOMData[y].PartNo,tcuaCADBOMData[y].PartRev,tcuaCADBOMData[y].PartSeq,tcuaCADBOMData[y].CadBOMChild[z].ChildPartNo);fflush(output);
					    	}
				    	}
		    		}
		    		if (tcuaCADBOMData[y].chldCnt < tceCADBOMData[yy].chldCnt)
		    		{
		    			printf("\nMissing in CAD IF Condition"); fflush(stdout);
		    			for (z = 0; z <= tceCADBOMData[yy].chldCnt; ++z)
				    	{
		    				TceTcuaMatch=0;
		    				for (zz = 0; zz <= tcuaCADBOMData[y].chldCnt; ++zz)
					    	{
					    		printf("\n\tCAD BOM: %s ---- %s",tceCADBOMData[yy].CadBOMChild[z].ChildPartNo,tcuaCADBOMData[y].CadBOMChild[zz].ChildPartNo); fflush(stdout);
					    		if (tc_strlen(tcuaCADBOMData[y].CadBOMChild[zz].ChildPartNo) <= tc_strlen(tceCADBOMData[yy].CadBOMChild[z].ChildPartNo))
					    		{
					    		//if (tc_strstr(tceCADBOMData[yy].CadBOMChild[z].ChildPartNo,tcuaCADBOMData[y].CadBOMChild[zz].ChildPartNo)!=NULL)
					    		if(tc_strncasecmp(tceCADBOMData[yy].CadBOMChild[z].ChildPartNo, tcuaCADBOMData[y].CadBOMChild[zz].ChildPartNo, tc_strlen(tcuaCADBOMData[y].CadBOMChild[zz].ChildPartNo)) == 0)
					    		{
					    			printf("\n\tCAD BOM: MATCH FOUND ---> %d",z); fflush(stdout);
					    			TceTcuaMatch=1;
					    			break;
					    		}
					    		}
					    	}
					    	if (TceTcuaMatch == 0)
					    	{
					    		tc_strcpy(tmpRevCol, "");
								sprintf(tmpRevCol, "%s;%s",tcuaCADBOMData[y].PartRev, tcuaCADBOMData[y].PartSeq);
								tc_strcpy(tmpCatCol,"");
								sprintf(tmpCatCol, "Missing Part in CREO Membership: %s",tc_strtok(tceCADBOMData[yy].CadBOMChild[z].ChildPartNo,"<"));
					    		AddIssueRepDt(tcuaCADBOMData[y].PartNo,tmpRevCol,tmpCatCol,"CREO Membership","Remigration of Part");

					    		//fprintf(output,"%s,%s;%s,Missing Part in CREO Membership: %s,CREO Membership,Remigration of Part\n",tcuaCADBOMData[y].PartNo,tcuaCADBOMData[y].PartRev,tcuaCADBOMData[y].PartSeq,tceCADBOMData[yy].CadBOMChild[z].ChildPartNo);fflush(output);
					    	}
		    			}
		    		}
		    		break;
		    	}
		    	}
		    }
	    }
		}
		else
		{
			printf("\nTCE Service Not Available CADBOM : %d",CadBomMainSize); fflush(stdout);
		}

		FILE *TCEOpChk = NULL;
		printf("\nFile Name: %s\n",outputFileTce); fflush(stdout);
		TCEOpChk = fopen(outputFileTce,"r");
		if (TCEOpChk == NULL)
		{
			printf("No Data File Check in TCE\n");
		}
		else
		{
			inputline=(char *) MEM_alloc(250);
			while(fgets(inputline,250,TCEOpChk)!=NULL)
			{
				//printf("\n----Alokesh %s\n",inputline); fflush(stdout);
				char *TmpItemID = NULL;
				char *TmpRevSeq = NULL;
				char *TmpIssType = NULL;
				TmpItemID = tc_strtok(inputline,",");
				TmpRevSeq = tc_strtok(NULL,",");
				TmpIssType = tc_strtok(NULL,",");
				//printf("\n----Alokesh 4 %d\n",issueDtCnt); fflush(stdout);

	    		AddIssueRepDt(TmpItemID,TmpRevSeq,TmpIssType,"Data Set","Remigration of Part");
			}
		}
		fclose(TCEOpChk);
		//fclose(output);

		iteamrev2 = NULLTAG;
		itemrev = NULLTAG;
		iteamrev3 = NULLTAG;
		if (issueDtCnt > 0)
		{
			tag_t tItemobjA = NULLTAG;
			int n_itemobj_foundA = 0;
			tag_t *titemobj_resultsA = NULLTAG;
			char *cEntriesA[2]  = {"Item ID","Revision"};
			//printf("Alokesh X"); fflush(stdout);
			ITK_CALL(QRY_find2("Item Revision...",&tItemobjA));
			//printf("Alokesh 1 %s -- %s",cValues[0],cValues[1]); fflush(stdout);
			ITK_CALL(QRY_execute(tItemobjA, 2, cEntriesA, cValues, &n_itemobj_foundA, &titemobj_resultsA));
			//printf("Alokesh 2"); fflush(stdout);
			DesignPart = titemobj_resultsA[0];
			//printf("Alokesh 3"); fflush(stdout);
			ITK_CALL(AOM_load(DesignPart));
			//printf("Alokesh 4"); fflush(stdout);
			ITK_CALL(AOM_refresh(DesignPart,1));
			//printf("Alokesh 5"); fflush(stdout);
			ITK_CALL(AOM_set_value_string(DesignPart,"t5_ErcIndName","1"));
			//printf("Alokesh 6"); fflush(stdout);
			ITK_CALL(AOM_save_without_extensions(DesignPart));
			ITK_CALL(AOM_refresh(DesignPart,0));
			//printf("Alokesh 7"); fflush(stdout);
		}

		printf("\n\n\n\nPrinting Final Data"); fflush(stdout);

		char *FPartIssueDup = NULL;
		FPartIssueDup=(char *) MEM_alloc(250);
		tc_strcpy(FPartIssueDup,"");

		char *tmpString = NULL;
		tmpString=(char *) MEM_alloc(250);
		char *SaveReportFileName = NULL;
		SaveReportFileName=(char *) MEM_alloc(200);
		char *SaveReportFileLoc = NULL;
		SaveReportFileLoc=(char *) MEM_alloc(200);
		char *dataSetName 		= NULL;
		dataSetName=(char *) MEM_alloc(200);
		strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
		sprintf(SaveReportFileName,"Report_%s_%s.csv",inputPart,Data);
		sprintf(SaveReportFileLoc,"/tmp/Report_%s_%s.xls",inputPart,Data);
		sprintf(dataSetName,"Report_%s_%s",inputPart,Data);

		FILE *Report = NULL;
		char *XMLFileName = NULL;
		XMLFileName=(char *) MEM_alloc(200);
		sprintf(XMLFileName,"/tmp/Report_%s_%s.xml",inputPart,Data);
		//Report=fopen("/tmp/MigrationValidationReport.xml","w");
		Report=fopen(XMLFileName,"w");
		if (Report == NULL)
		{
			printf("ERROR: XML Cannot open File\n");
			return -1;
		}
		strftime(Data,100,"%d-%m-%Y %H:%M:%S",&when);
		write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		write2xml(Report,"\n<PLMXML date=\"");
		write2xml(Report,Data);
		write2xml(Report,"\" PartNo=\"");
		write2xml(Report,inputPart);
		write2xml(Report,"\" RevSeq=\"");
		write2xml(Report,RevSeq);
		write2xml(Report,"\" >\n");
		//fprintf(SaveReport,"PartNo:,%s,\n",inputPart); fflush(SaveReport);
		//fprintf(SaveReport,"RevSeq:,%s,\n",RevSeq); fflush(SaveReport);
		//fprintf(SaveReport,"Date:,%s,\n",Data); fflush(SaveReport);
		//fprintf(SaveReport,"Sr. No.,Part Number,Revision/Sequence,Issue Category,Issue Description,Suggested Soultion,\n"); fflush(SaveReport);

		if (issueDtCnt == 0)
		{
			write2xml(Report,"<DesignRevision>\n");
			write2xml(Report,"<field key =\"slNo\">");
			write2xml(Report,"---");
			write2xml(Report,"</field>\n");
			write2xml(Report,"<field key =\"item_id\">");
			write2xml(Report,"---");
			write2xml(Report,"</field>\n");
			write2xml(Report,"<field key =\"rev_seq\">");
			write2xml(Report,"---");
			write2xml(Report,"</field>\n");
			write2xml(Report,"<field key =\"issue_cat\">");
			write2xml(Report,"Status: OK");
			write2xml(Report,"</field>\n");
			write2xml(Report,"<field key =\"issue_type\">");
			write2xml(Report,"No Exception Found");
			write2xml(Report,"</field>\n");
			write2xml(Report,"<field key =\"sol_type\">");
			write2xml(Report,"---");
			write2xml(Report,"</field>\n");
			write2xml(Report,"</DesignRevision>\n");
			//fprintf(SaveReport,"---,---,---,OK,No Exception Found,---,\n"); fflush(SaveReport);

			ITK_CALL(AOM_load(DesignPart));
			ITK_CALL(AOM_refresh(DesignPart,1));
			ITK_CALL(AOM_set_value_string(DesignPart,"t5_ErcIndName","0"));
			ITK_CALL(AOM_save_without_extensions(DesignPart));
			ITK_CALL(AOM_refresh(DesignPart,0));
		}
		else
		{
			printf("Total Issue: %d",issueDtCnt);fflush(stdout);
			for (y = 0; y < issueDtCnt; ++y)
		    {
		    	printf("\n-----------------------%s-%s-%s-%s-%s-%s",IssueRepDt[y].cnt,IssueRepDt[y].PartNo,IssueRepDt[y].RevSeq,IssueRepDt[y].IssueCat,IssueRepDt[y].IssueDesc,IssueRepDt[y].SuggSol);fflush(stdout);
		    	//FPartIssueDup=(char *) MEM_alloc(tc_strlen(IssueRepDt[y].IssueCat) * sizeof(char));
		    	//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(IssueRepDt[y].IssueCat) * sizeof(char));
		    	tc_strcpy(FPartIssueDup,IssueRepDt[y].IssueCat);
		    	//printf("Alokesh : 1");fflush(stdout);
		    	if(tc_strstr(FPartIssueDup,"JT_Not_Available") != NULL)
		    	{
		    		STRNG_replace_str(FPartIssueDup,"JT_Not_Available","JT Dataset Not Available",&tmpString);
		    		//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
		    	}
		    	//printf("Alokesh : 2");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"Multi_JT") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_JT","Multiple JT Dataset Present- Need to Delete",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 3");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"JT_NamedRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"JT_NamedRef_Missing","Named Reference missing on JT Dataset",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 4");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"PDF_Not_Available") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"PDF_Not_Available","PDF Dataset Not Available",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 5");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"Multi_PDF") != NULL) 
				{
					//printf("\nIn Multi_PDF"); fflush(stdout);
					STRNG_replace_str(FPartIssueDup,"Multi_PDF","Multiple PDF Dataset Present- Need to Delete",&tmpString);
					//printf("\nIn Multi_PDF 1 %s -> %d",tmpString,tc_strlen(tmpString)); fflush(stdout);
					////FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, (tc_strlen(tmpString)*2) * sizeof(char));
					//printf("\nIn Multi_PDF 2"); fflush(stdout);
		    		tc_strcpy(FPartIssueDup,tmpString);
		    		//printf("\nIn Multi_PDF 3"); fflush(stdout);
				}
				//printf("Alokesh : 6");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"PDF_NamedRef_Missing") != NULL) 
				{
					//printf("\nIn Multi_PDF 4"); fflush(stdout);
					STRNG_replace_str(FPartIssueDup,"PDF_NamedRef_Missing","Named Reference missing on PDF Dataset",&tmpString);
					//printf("\nIn Multi_PDF 5"); fflush(stdout);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
					//printf("\nIn Multi_PDF 6"); fflush(stdout);
		    		tc_strcpy(FPartIssueDup,tmpString);
		    		//printf("\nIn Multi_PDF 7"); fflush(stdout);
				}
				//printf("Alokesh : 7");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"NamedRef_Not_CSV_WELD_Report") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"NamedRef_Not_CSV_WELD_Report","Named Reference of WELD_Report is not .csv",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 8");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"No_NamedRef_WELD_Report") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"No_NamedRef_WELD_Report","Named Reference missing on WELD_Report",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 9");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"CMI2Drawing_In_IMAN_reference") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"CMI2Drawing_In_IMAN_reference","CATIA Drawing Relation Error, in IMAN_reference Relationship",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 10");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"ProDrw_In_IMAN_reference") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"ProDrw_In_IMAN_reference","PROE Drawing Relation Error, in IMAN_reference Relationship",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 11");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"No_CAD_DataSet") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"No_CAD_DataSet","CAD Dataset Not Available",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 12");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"Drawing_Not_Available") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Drawing_Not_Available","Drawing Dataset Not Available",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 13");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"Multi_ProAsm") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_ProAsm","Multiple PROE Assembly Dataset Present- Need to Delete",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 14");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"Multi_ProPrt") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_ProPrt","Multiple PROE Part Dataset Present- Need to Delete",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 15");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"Multi_ProDrw") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_ProDrw","Multiple PROE Drawing Dataset Present- Need to Delete",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 16");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"Multi_CMI2CacheCgr") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_CMI2CacheCgr","Multiple CMI2CacheCgr Dataset Present- Need to Delete",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 17");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"Multi_CMI2AuxPart") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_CMI2AuxPart","Multiple CMI2AuxPart Dataset Present- Need to Delete",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 18");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"Multi_CMI2Part") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_CMI2Part","Multiple CATIA Part Dataset Present- Need to Delete",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 19");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"Multi_CMI2Product") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_CMI2Product","Multiple CATIA Product Dataset Present- Need to Delete",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 20");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"Multi_CMI2Drawing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_CMI2Drawing","Multiple CATIA Drawing Dataset Present- Need to Delete",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 21");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"Multi_MSExcel") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Multi_MSExcel","Multiple MSExcel Dataset Present- Need to Delete",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 22");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"ProAsm_NamedRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"ProAsm_NamedRef_Missing","Named Reference missing on PROE Assembly Dataset",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 23");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"ProPrt_NamedRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"ProPrt_NamedRef_Missing","Named Reference missing on PROE Part Dataset",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 24");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"ProDrwNmdRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"ProDrwNmdRef_Missing","Named Reference missing on PROE Drawing Dataset",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 25");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"CMI2CacheCgrNmdRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"CMI2CacheCgrNmdRef_Missing","Named Reference missing on CMI2CacheCgr Dataset",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 26");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"CMI2AuxPartNmdRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"CMI2AuxPartNmdRef_Missing","Named Reference missing on CMI2AuxPart Dataset",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 27");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"CMI2PartNmdRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"CMI2PartNmdRef_Missing","Named Reference missing on CATIA Part Dataset",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 28");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"CMI2ProductNmdRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"CMI2ProductNmdRef_Missing","Named Reference missing on CATIA Product Dataset",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 29");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"CMI2DrawingNmdRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"CMI2DrawingNmdRef_Missing","Named Reference missing on CATIA Drawing Dataset",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 30");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"MSExcelNmdRef_Missing") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"MSExcelNmdRef_Missing","Named Reference missing on MSExcel Dataset",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 31");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"CMI2AuxPart_CMI2Part_Both_Present") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"CMI2AuxPart_CMI2Part_Both_Present","Need to delete CMI2Part (CATIA Part), as CMI2Product (CATIA Product) and CMI2AuxPart both Present",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 32");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"No_BVR_in_Assembly") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"No_BVR_in_Assembly","No BVR on Assembly",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 33");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"Duplicate_Revision_CREO_Membeship") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Duplicate_Revision_CREO_Membeship","Duplicate Design Revisions on CREO Membership",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 34");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"Missing_CREO_Membership") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Missing_CREO_Membership","Missing CREO Membership",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 35");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"Rev_Eff_Issue_Latest_Working") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Rev_Eff_Issue_Latest_Working","Date Issue in Latest Working for ERC View (Structure Manager)",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 36");fflush(stdout);
				if(tc_strstr(FPartIssueDup,"Rev_Eff_Issue_ERC_Release_Above") != NULL) 
				{
					STRNG_replace_str(FPartIssueDup,"Rev_Eff_Issue_ERC_Release_Above","Date Issue in ERC Released and Above View (Structure Manager)",&tmpString);
					//FPartIssueDup = (char*)MEM_realloc(FPartIssueDup, tc_strlen(tmpString) * sizeof(char));
		    		tc_strcpy(FPartIssueDup,tmpString);
				}
				//printf("Alokesh : 37");fflush(stdout);
				//else tc_strcpy(FPartIssueDup, FPartIssueDup);
				
				write2xml(Report,"<DesignRevision>\n");
				write2xml(Report,"<field key =\"slNo\">");
				write2xml(Report,IssueRepDt[y].cnt);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"item_id\">");
				write2xml(Report,IssueRepDt[y].PartNo);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"rev_seq\">");
				write2xml(Report,IssueRepDt[y].RevSeq);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"issue_cat\">");
				write2xml(Report,IssueRepDt[y].IssueDesc);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"issue_type\">");
				write2xml(Report,FPartIssueDup);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"sol_type\">");
				write2xml(Report,IssueRepDt[y].SuggSol);
				write2xml(Report,"</field>\n");
				write2xml(Report,"</DesignRevision>\n");
				//fprintf(SaveReport,"%s,%s,%s,%s,%s,%s,\n",IssueRepDt[y].cnt,IssueRepDt[y].PartNo,IssueRepDt[y].RevSeq,IssueRepDt[y].IssueDesc,FPartIssueDup,IssueRepDt[y].SuggSol); fflush(SaveReport);
		    }
		}

	    write2xml(Report,"</PLMXML>\n");
		fclose(Report);

		//fclose(SaveReport);

		/*int result = ITK_ok;
		result = applyXSLTTransformation(XMLFileName, "/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_DataValidation/Migrated_Data_Validation.xsl", SaveReportFileLoc);
		if (result != ITK_ok) {
	        printf("\nError in Generation\n"); fflush(stdout);
	        return -1;
	    }
		//Save SaveReportFileName in Attaches Relation of Design Revision
		IMF_file_t	fileDescriptor;
		tag_t	datasettype = NULLTAG;
		tag_t	tool 		= NULLTAG;
		tag_t	Newdataset 	= NULLTAG;
		tag_t	filetag 	= NULLTAG;
		ITK_CALL(AE_find_datasettype2("MSExcel",&datasettype));
		ITK_CALL(AE_find_tool2("MSExcel", &tool));
		ITK_CALL(AE_create_dataset_with_id(datasettype,dataSetName,"",NULL,NULL,&Newdataset));
		ITK_CALL(AE_set_dataset_tool(Newdataset,tool));
		ITK_CALL(AE_set_dataset_format2(Newdataset,"BINARY_REF"));
		ITK_CALL(AOM_save_without_extensions(Newdataset));
		ITK_CALL(IMF_fmsfile_import(SaveReportFileLoc,SaveReportFileName,SS_BINARY,&filetag,&fileDescriptor));
		if(filetag == NULLTAG)
		{
			printf(" File Tag Not Found..!!\n");fflush(stdout);
			return -1;
		}
		ITK_CALL(AOM_refresh(Newdataset,TRUE));
		ITK_CALL(AE_add_dataset_named_ref2(Newdataset, "excel", AE_PART_OF, filetag));
		ITK_CALL(AOM_save_without_extensions(Newdataset));
		ITK_CALL(AOM_refresh(Newdataset,FALSE));
		tag_t Attachrelation_type = NULLTAG;
		tag_t Fndrelation = NULLTAG;
		tag_t SetRelation = NULLTAG;
		ITK_CALL(GRM_find_relation_type("TC_Attaches",&Attachrelation_type));
		ITK_CALL(GRM_find_relation( DesignPart, Newdataset, Attachrelation_type ,&Fndrelation));
		if(Fndrelation == NULLTAG)
		{
			ITK_CALL(GRM_create_relation(DesignPart, Newdataset, Attachrelation_type, NULLTAG, &SetRelation));
			printf("\n\t TC_Attaches GRM_create_relation");fflush(stdout);
			ITK_CALL(GRM_save_relation(SetRelation));
			printf("\n\t TC_Attaches GRM_save_relation\n");fflush(stdout);
		}*/

		tc_strcpy(exepathdup,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_DataValidation/RemoveProcessFiles.sh");
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,outputFileTceCheck);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,outputFileTce);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,tceEBOM);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,tceCADBOM);
		tc_strcat(exepathdup," ");
		tc_strcat(exepathdup,XMLFileName);

		system(exepathdup);

		FPartIssueDup = NULL;
		tmpString = NULL;
		SaveReportFileName = NULL;
		SaveReportFileLoc = NULL;
		XMLFileName = NULL;
	}
	printf("\n=============================================================================");fflush(stdout);

	RepExtChkChld = NULL;
	iFail = ITK_exit_module(TRUE);
	printf("\nReturn Value is : %d", iFail);
	if (iFail == ITK_ok)
	{
		printf("\nTeamcenter Logout Success...");fflush(stdout);
	}
	else
	{
		EMH_ask_error_text(iFail, &cError);
		printf("\nError is : %s", cError);fflush(stdout);
	}
	return ITK_ok;
}


