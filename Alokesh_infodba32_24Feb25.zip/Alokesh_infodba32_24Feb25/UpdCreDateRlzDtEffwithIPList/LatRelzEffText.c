#include <stdlib.h>
#include <stdarg.h>
#include <time.h>          
#include <unidefs.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <ae/datasettype.h>
#include <tccore/grm.h>
#include <fclasses/tc_date.h>
#include <tccore/releasestatus.h>
#define ITK_err 910001

const char *revision_Order[] = {"NR", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a1", "b1", "c1", "d1", "e1", "f1", "g1", "h1", "i1", "j1", "k1", "l1", "m1", "n1", "o1", "p1", "q1", "r1", "s1", "t1", "u1", "v1", "w1", "x1", "y1", "z1", "a2", "b2", "c2", "d2", "e2", "f2", "g2", "h2", "i2", "j2", "k2", "l2", "m2", "n2", "o2", "p2", "q2", "r2", "s2", "t2", "u2", "v2", "w2", "x2", "y2", "z2", "a3", "b3", "c3", "d3", "e3", "f3", "g3", "h3", "i3", "j3", "k3", "l3", "m3", "n3", "o3", "p3", "q3", "r3", "s3", "t3", "u3", "v3", "w3", "x3", "y3", "z3", "a4", "b4", "c4", "d4", "e4", "f4", "g4", "h4", "i4", "j4", "k4", "l4", "m4", "n4", "o4", "p4", "q4", "r4", "s4", "t4", "u4", "v4", "w4", "x4", "y4", "z4", "a5", "b5", "c5", "d5", "e5", "f5", "g5", "h5", "i5", "j5", "k5", "l5", "m5", "n5", "o5", "p5", "q5", "r5", "s5", "t5", "u5", "v5", "w5", "x5", "y5", "z5", "a6", "b6", "c6", "d6", "e6", "f6", "g6", "h6", "i6", "j6", "k6", "l6", "m6", "n6", "o6", "p6", "q6", "r6", "s6", "t6", "u6", "v6", "w6", "x6", "y6", "z6", "a7", "b7", "c7", "d7", "e7", "f7", "g7", "h7", "i7", "j7", "k7", "l7", "m7", "n7", "o7", "p7", "q7", "r7", "s7", "t7", "u7", "v7", "w7", "x7", "y7", "z7", "a8", "b8", "c8", "d8", "e8", "f8", "g8", "h8", "i8", "j8", "k8", "l8", "m8", "n8", "o8", "p8", "q8", "r8", "s8", "t8", "u8", "v8", "w8", "x8", "y8", "z8", "a9", "b9", "c9", "d9", "e9", "f9", "g9", "h9", "i9", "j9", "k9", "l9", "m9", "n9", "o9", "p9", "q9", "r9", "s9", "t9", "u9", "v9", "w9", "x9", "y9", "z9"};
const int revision_length = 260;

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);fflush(stdout);
		  exit(0);
		}

		return iFail;
}

int setDateAttributesOnItemRev(tag_t rev_t,char* CreDateTempS, char* partLastUpdateDate);

static int	validate_date2 ( char *date , logical *date_is_valid , date_t *the_dt )
{
    int      retcode    = ITK_ok;     /* Function return code */
    date_t   dt         = NULLDATE;   /* Date structure */
    int      month      = 0;          /* Month */
    int      day        = 0;          /* Day */
    int      year       = 0;          /* Year */
    int      hour       = 0;          /* Hour */ 
    int      minute     = 0;          /* Minutes */
    int      second     = 0;          /* Seconds */

    *date_is_valid = TRUE;

    char* Year = NULL;
    char* Month	= NULL;
    char* Day = NULL;
    char* Hours	= NULL;
    char* Min = NULL;
    char* Sec = NULL;
    char* MicroSec = NULL;
    char* PrtCreDateS = NULL;
	PrtCreDateS = ( char * ) MEM_alloc(30);
	printf("\nDateTempS:[%s]  \n",date); fflush(stdout);
	Year=strtok(date,"/");
	Month=strtok(NULL,"/");
	Day=strtok(NULL,"-");
	Hours=strtok(NULL,":");
	Min=strtok(NULL,":");
	Sec=strtok(NULL,":");
	MicroSec=strtok(NULL,":");
	strcpy(PrtCreDateS,"");
	strcpy(PrtCreDateS,Year);
	strcat(PrtCreDateS,"/");
	strcat(PrtCreDateS,Month);
	strcat(PrtCreDateS,"/");
	strcat(PrtCreDateS,Day);
	strcat(PrtCreDateS,"-");
	strcat(PrtCreDateS,Hours);
	strcat(PrtCreDateS,":");
	strcat(PrtCreDateS,Min);
	strcat(PrtCreDateS,":");
	strcat(PrtCreDateS,Sec);
	printf("New Date is --> [%s]",PrtCreDateS); fflush(stdout);

    /* Converts a date_t structure into the format specified  */
//    retcode = DATE_string_to_date ( date , "%d-%b-%Y %H:%M:%S" , &month , &day , &year , &hour , &minute , &second);				// working for " 21-August-2015" / ""
//    retcode = DATE_string_to_date ( date , "%m-%d-%y-%H:%M:%S" , &month , &day , &year , &hour , &minute , &second);				// working for  "07-21-2015-09:05:58"
    retcode = DATE_string_to_date ( PrtCreDateS , "%y/%m/%d-%H:%M:%S" , &month , &day , &year , &hour , &minute , &second);
    if ( retcode != ITK_ok )
    {
        *date_is_valid = FALSE;
    }
    else
    {
        dt.month = month;
        dt.day   = day;
        dt.year  = year;
        dt.hour  = hour;
        dt.minute= minute;
        dt.second= second;

        *the_dt = dt;
    }

	printf("  ---return from validate_date....\n");

    return retcode;
}

int setLifeCycle(tag_t itemRev,char* lifeCycleS)
{
	int status;
	tag_t   status2=NULLTAG;
	tag_t   release_status_object=NULLTAG;
	logical retain=false;
	char* lcsToset=NULL;
	tag_t class_id =     NULLTAG;
	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
	if(strcmp(lifeCycleS,"T5_LcsErcRlzd")==0)
	{
		printf("\n\t T5_LcsErcRlzd"); fflush(stdout);
		strcpy(lcsToset,"T5_LcsErcRlzd");
	}
	else
	{
		printf("\n\t T5_LcsReview"); fflush(stdout);
		strcpy(lcsToset,"T5_LcsReview");
	}
	printf("   InsetLifeCycle...lcsToset:[%s]\n\t ",lcsToset); fflush(stdout);
	//ITK_CALL(CR_create_release_status(lcsToset,&status2));
	ITK_CALL(RELSTAT_create_release_status(lcsToset,&status2));
	ITK_CALL(POM_attr_id_of_attr("release_status_list","Design_0_Revision_alt",&release_status_object));fflush(stdout);
	if(status2)
	{
		ITK_CALL(AOM_save_with_extensions(status2));
		ITK_CALL(AOM_refresh(status2,0));
		printf("   InsetLifeCycle...lcsToset:==> [%s] \n\t ",lcsToset); fflush(stdout);
		ITK_CALL(POM_refresh_instances(1, &itemRev, NULLTAG, POM_modify_lock));
		ITK_CALL(POM_class_of_instance(itemRev,&class_id));
		ITK_CALL(POM_load_instances(1,&itemRev,class_id,1));
		printf("   InsetLifeCycle...lcsToset:222[%s]",lcsToset); fflush(stdout);
		ITK_CALL(POM_set_attr_tag(1, &itemRev, release_status_object , status2 ));
		printf("   InsetLifeCycle...lcsToset:333[%s]",lcsToset); fflush(stdout);
		ITK_CALL(POM_save_instances(1,&itemRev,true));
	}
}

int  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
	  return 0;
}

void getNextDate(char *DatetoConvert,char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int ch1;
	int Monthas;
	int ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];
	char DateS[20];
	char CCMonth[30];
	char* strDay;
	char* strMon;
	char* strYear;
	char* cMonth ;
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
    strYear =  strtok(DatetoConvert,"/"); //1
    cMonth  =  strtok(NULL,"'/'"); //2
    strDay  =  strtok(NULL,"'/'"); //3
    Monthas =  atoi(cMonth);
	getMonth(Monthas,CCMonth);
	printf("\n\t strYear:%s",strYear); fflush(stdout);
	printf("\t CCMonth:%s",CCMonth); fflush(stdout);
	printf("\t strDay:%s",strDay); fflush(stdout);
	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,CCMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n\t cnextAccessDate:%s",cnextAccessDate); fflush(stdout);
}

int CreateEffctivity(tag_t itemrev,char *FromDate,char *ToDate,char *lifeCycleS)
{
	int status = 0;
	int ifail = 0;
	int status_count=0;
	int ss=0;
	int StatusFlg=0;
	char* ReleaseStatus=NULL;
	char* ReleaseStatus2=NULL;
	char* lcsToset=NULL;
	char* CurrentRelStatus=NULL;
	char FrmNextDate[20]={0};
	char ToNextDate[20]={0};
	logical retain_released_date =false;
	logical is_v7  ;
	date_t test_date_1;
	date_t DayTommorow ;
	date_t test_date_2;
	date_t *start_end_date = NULL;
	tag_t release_status =NULLTAG;
	tag_t release_status2 =NULLTAG;
	tag_t eff_d = NULLTAG;
	tag_t* status_list = NULLTAG;

	/******Start Release status Variable initialisation***********/
	int			st_relList_count		=0;
	int			Rel_cnt					=0;
	tag_t*		relstatus_list			=NULLTAG;
	char		*WSO_Name_RelVal		=NULL ;
	tag_t		tReleaseStatusList_checkin=NULLTAG;
	int			n_values_checkin			=0;
	int			cunt1					=	0;
	tag_t*		attr_tags_checkin		=	NULLTAG;
	logical		*is_it_null_checkin		=   NULL;
	logical		*is_it_empty_checkin	=   NULL;
	tag_t		class_id				=     NULLTAG;
	char		*class_name				=    NULL;
	logical		log1;
	tag_t propEff_tag =NULLTAG;
	char* EffDateValue =NULL;
	int EffectivityFlag=0;

	/******End Release status ariable initialisation***********/
	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
	if(strcmp(lifeCycleS,"T5_LcsErcRlzd")==0)
	{
		strcpy(lcsToset,"T5_LcsErcRlzd");
	}
	else
	{
		strcpy(lcsToset,"T5_LcsReview");
	}
	printf("\n\t   lcsToset:[%s]",lcsToset); fflush(stdout);
	printf("   FromDate..[%s]",FromDate); fflush(stdout);
	printf("   ToDate..[%s]",ToDate); fflush(stdout);
	ITK_CALL(WSOM_ask_release_status_list(itemrev,&status_count,&status_list));
	printf("\n\t   REV status_count: %d \n\t   ",status_count);fflush(stdout);
	if (status_count == 0)  // No Status, so the Item is not yet Released
	{
		printf("\n\t   No Status, so the Item is not yet Released...............\n\t "); fflush(stdout);
	}
	if(((strcmp(FromDate,"-")==0) || (strcmp(ToDate,"-")==0)) && (strcmp(lcsToset,"ERCREVIEW")==0))
	{
		if (status_count == 0)
		{
			//ITK_CALL(CR_create_release_status(lcsToset,&release_status2));
			ITK_CALL(RELSTAT_create_release_status(lcsToset,&release_status2));
			ITK_CALL(AOM_ask_name(release_status2, &ReleaseStatus2));
			printf("\n\t   Created ReleaseStatus2: %s",ReleaseStatus2);fflush(stdout);
			//ITK_CALL(EPM_add_release_status(release_status2,1,&itemrev,retain_released_date));
			ITK_CALL(RELSTAT_add_release_status(release_status2,1,&itemrev,retain_released_date));
		}
		return 0;
	}
	if (status_count > 0)  // No Status, so the Item is not yet Released
	{
		for(ss=0; ss<status_count ; ss++)
		{
			release_status=status_list[ss];

			ITK_CALL(AOM_ask_value_string(status_list[ss],"object_name",&CurrentRelStatus));
			printf("\t   ........CurrentRelStatus: %s ",CurrentRelStatus);fflush(stdout);
			if(strcmp(CurrentRelStatus,lcsToset)==0)
			{
				StatusFlg ++;
				//ITK_CALL(PROP_ask_property_by_name(status_list[ss],"effectivity_text",&propEff_tag));
				//ITK_CALL(PROP_ask_value_string(propEff_tag,&EffDateValue));
				ITK_CALL(AOM_UIF_ask_value(status_list[ss],"effectivity_text",&EffDateValue));
				printf("\t EffDateValue: [%s]",EffDateValue);fflush(stdout);
				if ((tc_strcmp(EffDateValue,"")==0) || (strlen(EffDateValue)==0))
				{
					EffectivityFlag=0;
				}
				else
				{
					EffectivityFlag=1;
				}
				break;
			}
		}
	}
	printf("\n\t   StatusFlg: [%d]  EffectivityFlag: [%d]",StatusFlg,EffectivityFlag);fflush(stdout);
	if((StatusFlg != 0) && (EffectivityFlag==1)) { return 0; }
	printf("\n\t   Removing previously created release status......\n\t   "); fflush(stdout);
	ITK_CALL(POM_class_of_instance(itemrev,&class_id));
	ITK_CALL(POM_name_of_class(class_id,&class_name));
	printf("\t   class_name is :%s\n\t   ",class_name);fflush(stdout);
	if(StatusFlg == 0)
	{
		release_status =NULLTAG;
		printf("\n\t   *********Stamping Releasing item*******......"); fflush(stdout);
		//ITK_CALL(CR_create_release_status(lcsToset,&release_status));
		ITK_CALL(RELSTAT_create_release_status(lcsToset,&release_status));
		ITK_CALL(AOM_ask_name(release_status, &ReleaseStatus));
		printf("\n\t   ******************* ReleaseStatus: %s",ReleaseStatus);fflush(stdout);
		ITK_CALL(WSOM_ask_release_status_list(itemrev,&status_count,&status_list));
		printf("\n\t   REV status_count after ERC Released Stamped: %d \n\t   ",status_count);fflush(stdout);
		//ITK_CALL(EPM_add_release_status(release_status,1,&itemrev,retain_released_date)); printf("\t   "); fflush(stdout);
		ITK_CALL(RELSTAT_add_release_status(release_status,1,&itemrev,retain_released_date)); printf("\t   "); fflush(stdout);
		ITK_CALL(WSOM_ask_effectivity_mode(&is_v7));
		printf("\n\t   is_v7:%d",is_v7); fflush(stdout);
		if(is_v7 != true) { printf("\t ------is_v7 is not true ....."); fflush(stdout); }
		else { printf("\t ------is_v7 is  true ....."); fflush(stdout); }
	}
	if((strcmp(FromDate,"-")!=0) && (strcmp(ToDate,"-")!=0))
	{
		getNextDate(FromDate,FrmNextDate);
		getNextDate(ToDate,ToNextDate);
		printf("\n\t   FrmNextDate:%s",FrmNextDate); fflush(stdout);
		printf(" ToNextDate:%s",ToNextDate); fflush(stdout);
		ITK_CALL(ITK_string_to_date(FrmNextDate, &test_date_1));
		ITK_CALL(ITK_string_to_date(ToNextDate, &test_date_2 ));
		start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
		start_end_date[0] = test_date_1;
		start_end_date[1] = test_date_2;
		ITK_CALL(WSOM_status_clear_effectivities(release_status));
		ITK_CALL(WSOM_effectivity_create_with_dates(release_status, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
		ITK_CALL(AOM_save_with_extensions(eff_d));
	}
	ITK_CALL(AOM_lock(release_status));
	ITK_CALL(AOM_save_without_extensions(release_status));
	ITK_CALL(AOM_refresh(release_status,0));
	ITK_CALL(AOM_unlock(release_status));
	printf("\t   effectivity done-------------:%s \n",FrmNextDate); fflush(stdout);
	return status;
}

int ITK_user_main(int argc, char* argv[])
{
	    int ifail = 0;
	    char* cError = NULL;
		char* username = NULL;
		tag_t tuser = NULLTAG;
		ifail = ITK_auto_login();
		printf("\nReturn Value is : %d", ifail);fflush(stdout);
		
		int n_entries = 2;
		int i;
		tag_t tItemobj = NULLTAG;
		int rsltCount = 0;
		tag_t* revTag = NULLTAG;

		char *PartID = NULL;
		char *PartSequenceID = NULL;
		char *part_type = NULL;
		char *Description = NULL;
		char *object_type = NULL;
		char *Part_ProjID = NULL;
		char *Part_DesgnGrp = NULL;
		char *Revision = NULL;
		tag_t DataSet = NULLTAG;
		tag_t RevObjTag = NULLTAG;
		char *inputfile=NULL;
		
		int Part_Stat_Cnt = 0;
		tag_t *Part_Stat_Lst = NULLTAG;
		int k=0;
		int countRev =0;
		int countRlz =0;
		char *Part_Rlz_Stat = NULL;

		char* highRev = (char*)MEM_alloc(sizeof(char) * 20);
		char* highSeq = (char*)MEM_alloc(sizeof(char) * 20);
		int highestPos = 0;
		int highRevPos = 0;
		int actRevPos = 0;
		char 			*rev_id						= NULL;
		int r =0;
		int z=0;
		char* actRev = NULL;
		char* actSeq = NULL;
		tag_t item_rev_tag = NULLTAG;
		int status_count=0;
		tag_t* relStatus_list;
		int ss = 0;
		char* Rel_Status = NULL;
		date_t Creation_date_t;
		char* CreationDt= NULL;
		logical date_is_validDR =false;
		date_t DRRelDate_tag;
		
		inputfile = ITK_ask_cli_argument("-i=");
		FILE *fp;
		fp=fopen(inputfile,"r");

		FILE *fp1;
		fp1 = fopen("NotUpdateEffectivity.txt","w");
		
		char *cEntries[2]  = {"Item ID","Revision"};
		char *inputline = NULL;
		
		char **cValues = (char **) MEM_alloc(50 * sizeof(char *));
				
		if (ifail == ITK_ok)
		{
			printf("\nTeamcenter Login Success...");fflush(stdout);
			POM_get_user(&username, &tuser);
			printf("\nUsername = %s", username);fflush(stdout);
		}
		else
		{
			EMH_ask_error_text(ifail, &cError);
			printf("\nError is : %s", cError);fflush(stdout);
		}
		if (cError)
		{
			MEM_free(cError);
		}
		if (username)
		{
			MEM_free(username);
		}
		
		if(fp!=NULL)
		{
			inputline=(char *) MEM_alloc(1000);
			while(fgets(inputline,1000,fp)!=NULL)
			{
				printf("\n\n Input Part: %s",inputline); fflush(stdout);

				char *partNoIP = NULL;
				char *partRevision = NULL;
				char *partRevIP = NULL;
				char *partSeqIP = NULL;
				char *partCreationDtIP = NULL;
				char *partEffFromDtIP = NULL;
				char *partEffToDtIP = NULL;
				char *partEffReleaseDate = NULL;
				char *partLastUpdateDate = NULL;
				char *RlzStatusTCE = NULL;
				partNoIP = (char *)MEM_alloc(150);
				tc_strcpy(partNoIP, "");
				partNoIP = strtok(inputline,",");
				partRevIP = strtok(NULL,",");
				partSeqIP = strtok(NULL,",");
				partCreationDtIP = strtok(NULL,",");
				partEffFromDtIP = strtok(NULL,",");
				partEffToDtIP = strtok(NULL,",");
				partEffReleaseDate = strtok(NULL,",");
				partLastUpdateDate = strtok(NULL,",");
				RlzStatusTCE = strtok(NULL,",");

				char *partEffFromDtIP2 = NULL;
				char *partEffToDtIP2 = NULL;
				tc_strdup(partEffFromDtIP,&partEffFromDtIP2);
				tc_strdup(partEffToDtIP,&partEffToDtIP2);

				partRevision = (char *)MEM_alloc(150);
				tc_strcpy(partRevision,"");
				tc_strcpy(partRevision,partRevIP);
				tc_strcat(partRevision,";");
				tc_strcat(partRevision,partSeqIP);

				printf("-----------> :%s -- %s -- %s\n",partNoIP,partRevIP,partSeqIP);fflush(stdout);
				cValues[0] = partNoIP;
				cValues[1] = partRevision;

				ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
				ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &rsltCount, &revTag));
				printf("\nNo of item returned ---------------------- %d\n",rsltCount);fflush(stdout);
				if(rsltCount > 0)
				{
					item_rev_tag = revTag[0];
					ifail = AOM_UIF_ask_value (item_rev_tag, "item_revision_id", &rev_id);
					printf("\n item_revision_id is:%s",rev_id); fflush(stdout);

					if(WSOM_ask_release_status_list(item_rev_tag, &status_count, &relStatus_list) != ITK_ok);
					if (status_count > 0)
					{
						for(ss=0; ss<status_count ; ss++)
						{
							if(AOM_ask_value_string(relStatus_list[ss],"object_name",&Rel_Status)!=ITK_ok);
							if (tc_strcmp(Rel_Status,"T5_LcsErcRlzd")==0)
							{
								if (tc_strcmp(RlzStatusTCE,"T5_LcsReview")==0)
								{
									tag_t PrtClass_id1 = NULLTAG;
									char *PartClass_name1 = NULL;
									tag_t PrtStatLst_AttrID1 = NULLTAG;
									int st_count1 = 0;	
									tag_t *status_list1 = NULLTAG;
									logical	log1;
									int PrtStatLst_Length1 = 0;
									tag_t *PrtStatLst_Attr_tag1 = NULLTAG;
									logical	*is_it_null1 = NULL;
									logical	*is_it_empty1 = NULL;
									int count1 = 0;
									char *PrtRlz_Status1 = NULL;

									printf("\n In Remove_Multiple_Status Function \n");fflush(stdout);
									ITK_CALL(POM_class_of_instance(item_rev_tag,&PrtClass_id1)); 
									ITK_CALL(POM_name_of_class(PrtClass_id1,&PartClass_name1));
									printf("\n Part Class Name is : %s\n",PartClass_name1);fflush(stdout);
									ITK_CALL(POM_attr_id_of_attr("release_status_list",PartClass_name1,&PrtStatLst_AttrID1));
									ITK_CALL(WSOM_ask_release_status_list(item_rev_tag,&st_count1,&status_list1));
									printf("\n st_count1 is : %d \n",st_count1);fflush(stdout);
									ITK_CALL(POM_unload_instances(1,&item_rev_tag));
									ITK_CALL(POM_load_instances(1,&item_rev_tag,PrtClass_id1,1));
									ITK_CALL(POM_is_loaded(item_rev_tag,&log1));
									if(log1 == 1)
									{
										printf(" Load Success\n " );fflush(stdout);
									}
									else
									{
										printf(" Load Failure\n"  );fflush(stdout);
									}
									ITK_CALL( POM_length_of_attr(item_rev_tag, PrtStatLst_AttrID1, &PrtStatLst_Length1) );
									ITK_CALL( POM_ask_attr_tags(item_rev_tag, PrtStatLst_AttrID1, 0, PrtStatLst_Length1, &PrtStatLst_Attr_tag1, &is_it_null1, &is_it_empty1 ));
									for(count1=0; count1<PrtStatLst_Length1;count1++)
									{
										AOM_ask_name(PrtStatLst_Attr_tag1[count1], &PrtRlz_Status1);
										printf("\n Release status is : %s",PrtRlz_Status1);fflush(stdout);					
										if((tc_strcmp(PrtRlz_Status1,"T5_LcsErcRlzd")==0))	
										{
											ITK_CALL(POM_remove_from_attr(1,&item_rev_tag,PrtStatLst_AttrID1,count1,1));
											ITK_CALL(POM_save_instances(1,&item_rev_tag,1));
											ITK_CALL(POM_refresh_instances(1,&item_rev_tag,PrtClass_id1,2));
											ITK_CALL(AOM_lock(item_rev_tag));
											ITK_CALL(AOM_save_without_extensions(item_rev_tag));
											ITK_CALL(AOM_refresh(item_rev_tag,1));
											ITK_CALL(AOM_unlock(item_rev_tag));
											printf("\n Release Status Removed Successfully \n");fflush(stdout);
											break;
										}
									}
									int RvwFlagExts = 0;
									ITK_CALL(AOM_refresh(item_rev_tag,1));
									ITK_CALL( POM_length_of_attr(item_rev_tag, PrtStatLst_AttrID1, &PrtStatLst_Length1) );
									ITK_CALL( POM_ask_attr_tags(item_rev_tag, PrtStatLst_AttrID1, 0, PrtStatLst_Length1, &PrtStatLst_Attr_tag1, &is_it_null1, &is_it_empty1 ));
									for(count1=0; count1<PrtStatLst_Length1;count1++)
									{
										AOM_ask_name(PrtStatLst_Attr_tag1[count1], &PrtRlz_Status1);
										printf("\n Release status is : %s",PrtRlz_Status1);fflush(stdout);					
										if((tc_strcmp(PrtRlz_Status1,"T5_LcsReview")==0))	
										{
											RvwFlagExts = 1;
											break;
										}
									}
									if(RvwFlagExts == 0)
									{
										//Insert New Review Flag (Previously not exists)
										ITK_CALL(setLifeCycle(item_rev_tag,RlzStatusTCE));
										ITK_CALL(CreateEffctivity(item_rev_tag, partEffFromDtIP2, partEffToDtIP2 , RlzStatusTCE));
									}
								}
								else
								{
									int      retcode    = ITK_ok;
									int      retcode2    = ITK_ok;
									int      retcode3    = ITK_ok;
									logical date_is_valid = FALSE;
									date_t EfftiveFromDate;
									date_t EfftiveToDate;
									date_t ReleaseDate;
									retcode = validate_date2 ( partEffFromDtIP , &date_is_valid , &EfftiveFromDate );
									if ( retcode != ITK_ok )
									{
										printf ( " Effectivity Start Date--error code %d --- %s\n\n", retcode,partEffFromDtIP); fflush(stdout);
										fprintf(fp1, "%s,EfftiveFromDateInvalid\n", partNoIP); fflush(stdout);
										break;
									}
									retcode2 = validate_date2 ( partEffToDtIP , &date_is_valid , &EfftiveToDate );
									if ( retcode2 != ITK_ok )
									{
										printf ( " Effectivity End Date--error code %d --- %s\n\n", retcode2,partEffToDtIP); fflush(stdout);
										fprintf(fp1, "%s,EfftiveToDateInvalid\n", partNoIP); fflush(stdout);
										break;
									}
									retcode3 = validate_date2 ( partEffReleaseDate , &date_is_valid , &ReleaseDate );
									if ( retcode3 != ITK_ok )
									{
										printf ( " Release Date--error code %d --- %s\n\n", retcode3,partEffReleaseDate); fflush(stdout);
										fprintf(fp1, "%s,ReleaseDateInvalid\n", partNoIP); fflush(stdout);
										break;
									}

									if(retcode == ITK_ok && retcode2 == ITK_ok && retcode3 == ITK_ok)
									{
										tag_t attr_idDR = NULLTAG;
										printf("\n\n\t\t Updating attribute 'Date Released' on flag [%s]....",Rel_Status);fflush(stdout);
										ITK_CALL (POM_attr_id_of_attr("date_released", "Design_0_Revision_alt", &attr_idDR));
										ITK_CALL(AOM_lock(relStatus_list[ss]));
										ITK_CALL (POM_set_attr_date(1, &relStatus_list[ss], attr_idDR, EfftiveFromDate));
										ITK_CALL (AOM_save_without_extensions(relStatus_list[ss]));
										ITK_CALL(AOM_refresh(relStatus_list[ss],1));
										ITK_CALL(AOM_unlock(relStatus_list[ss]));

										date_t *start_end_date = NULL;
										tag_t eff_d = NULLTAG;
										start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
										start_end_date[0] = EfftiveFromDate;
										start_end_date[1] = EfftiveToDate;

										ITK_CALL(WSOM_status_clear_effectivities(relStatus_list[ss]));
										ITK_CALL(WSOM_effectivity_create_with_dates(relStatus_list[ss], NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
										ITK_CALL(AOM_save_with_extensions(eff_d));

										printf("**********************************%s,%s\n", partNoIP,rev_id); fflush(stdout);
									}
									else
									{
										fprintf(fp1, "%s,RelDateInvalid\n", partNoIP); fflush(stdout);
									}
								}
							}
						}
					}

					ITK_CALL(AOM_refresh(item_rev_tag,1));
					if(WSOM_ask_release_status_list(item_rev_tag, &status_count, &relStatus_list) != ITK_ok);
					if (status_count > 0)
					{
						for(ss=0; ss<status_count ; ss++)
						{
							if(AOM_ask_value_string(relStatus_list[ss],"object_name",&Rel_Status)!=ITK_ok);
							if (tc_strcmp(Rel_Status,"T5_LcsReview")==0)
							{
								if (tc_strcmp(RlzStatusTCE,"T5_LcsErcRlzd")==0)
								{
									tag_t PrtClass_id1 = NULLTAG;
									char *PartClass_name1 = NULL;
									tag_t PrtStatLst_AttrID1 = NULLTAG;
									int st_count1 = 0;	
									tag_t *status_list1 = NULLTAG;
									logical	log1;
									int PrtStatLst_Length1 = 0;
									tag_t *PrtStatLst_Attr_tag1 = NULLTAG;
									logical	*is_it_null1 = NULL;
									logical	*is_it_empty1 = NULL;
									int count1 = 0;
									char *PrtRlz_Status1 = NULL;

									printf("\n In Remove_Multiple_Status Function \n");fflush(stdout);
									ITK_CALL(POM_class_of_instance(item_rev_tag,&PrtClass_id1)); 
									ITK_CALL(POM_name_of_class(PrtClass_id1,&PartClass_name1));
									printf("\n Part Class Name is : %s\n",PartClass_name1);fflush(stdout);
									ITK_CALL(POM_attr_id_of_attr("release_status_list",PartClass_name1,&PrtStatLst_AttrID1));
									ITK_CALL(WSOM_ask_release_status_list(item_rev_tag,&st_count1,&status_list1));
									printf("\n st_count1 is : %d \n",st_count1);fflush(stdout);
									ITK_CALL(POM_unload_instances(1,&item_rev_tag));
									ITK_CALL(POM_load_instances(1,&item_rev_tag,PrtClass_id1,1));
									ITK_CALL(POM_is_loaded(item_rev_tag,&log1));
									if(log1 == 1)
									{
										printf(" Load Success\n " );fflush(stdout);
									}
									else
									{
										printf(" Load Failure\n"  );fflush(stdout);
									}
									ITK_CALL( POM_length_of_attr(item_rev_tag, PrtStatLst_AttrID1, &PrtStatLst_Length1) );
									ITK_CALL( POM_ask_attr_tags(item_rev_tag, PrtStatLst_AttrID1, 0, PrtStatLst_Length1, &PrtStatLst_Attr_tag1, &is_it_null1, &is_it_empty1 ));
									for(count1=0; count1<PrtStatLst_Length1;count1++)
									{
										AOM_ask_name(PrtStatLst_Attr_tag1[count1], &PrtRlz_Status1);
										printf("\n Release status is : %s",PrtRlz_Status1);fflush(stdout);					
										if((tc_strcmp(PrtRlz_Status1,"T5_LcsReview")==0))	
										{
											ITK_CALL(POM_remove_from_attr(1,&item_rev_tag,PrtStatLst_AttrID1,count1,1));
											ITK_CALL(POM_save_instances(1,&item_rev_tag,1));
											ITK_CALL(POM_refresh_instances(1,&item_rev_tag,PrtClass_id1,2));
											ITK_CALL(AOM_lock(item_rev_tag));
											ITK_CALL(AOM_save_without_extensions(item_rev_tag));
											ITK_CALL(AOM_refresh(item_rev_tag,1));
											ITK_CALL(AOM_unlock(item_rev_tag));
											printf("\n Release Status Removed Successfully \n");fflush(stdout);
											break;
										}
									}
									int RvwFlagExts = 0;
									ITK_CALL(AOM_refresh(item_rev_tag,1));
									ITK_CALL( POM_length_of_attr(item_rev_tag, PrtStatLst_AttrID1, &PrtStatLst_Length1) );
									ITK_CALL( POM_ask_attr_tags(item_rev_tag, PrtStatLst_AttrID1, 0, PrtStatLst_Length1, &PrtStatLst_Attr_tag1, &is_it_null1, &is_it_empty1 ));
									for(count1=0; count1<PrtStatLst_Length1;count1++)
									{
										AOM_ask_name(PrtStatLst_Attr_tag1[count1], &PrtRlz_Status1);
										printf("\n Release status is : %s",PrtRlz_Status1);fflush(stdout);					
										if((tc_strcmp(PrtRlz_Status1,"T5_LcsErcRlzd")==0))	
										{
											RvwFlagExts = 1;
											break;
										}
									}
									if(RvwFlagExts == 0)
									{
										//Insert New Review Flag (Previously not exists)
										ITK_CALL(setLifeCycle(item_rev_tag,RlzStatusTCE));
										ITK_CALL(CreateEffctivity(item_rev_tag, partEffFromDtIP, partEffToDtIP , RlzStatusTCE));
									}
								}
								else
								{
									int      retcode    = ITK_ok;
									int      retcode2    = ITK_ok;
									int      retcode3    = ITK_ok;
									logical date_is_valid = FALSE;
									date_t EfftiveFromDate;
									date_t EfftiveToDate;
									date_t ReleaseDate;
									retcode = validate_date2 ( partEffFromDtIP , &date_is_valid , &EfftiveFromDate );
									if ( retcode != ITK_ok )
									{
										printf ( " Effectivity Start Date--error code %d --- %s\n\n", retcode,partEffFromDtIP); fflush(stdout);
										fprintf(fp1, "%s,EfftiveFromDateInvalid\n", partNoIP); fflush(stdout);
										break;
									}
									retcode2 = validate_date2 ( partEffToDtIP , &date_is_valid , &EfftiveToDate );
									if ( retcode2 != ITK_ok )
									{
										printf ( " Effectivity End Date--error code %d --- %s\n\n", retcode2,partEffToDtIP); fflush(stdout);
										fprintf(fp1, "%s,EfftiveToDateInvalid\n", partNoIP); fflush(stdout);
										break;
									}
									retcode3 = validate_date2 ( partEffReleaseDate , &date_is_valid , &ReleaseDate );
									if ( retcode3 != ITK_ok )
									{
										printf ( " Release Date--error code %d --- %s\n\n", retcode3,partEffReleaseDate); fflush(stdout);
										fprintf(fp1, "%s,ReleaseDateInvalid\n", partNoIP); fflush(stdout);
										break;
									}

									if(retcode == ITK_ok && retcode2 == ITK_ok && retcode3 == ITK_ok)
									{
										tag_t attr_idDR = NULLTAG;
										printf("\n\n\t\t Updating attribute 'Date Released' on flag [%s]....",Rel_Status);fflush(stdout);
										ITK_CALL (POM_attr_id_of_attr("date_released", "Design_0_Revision_alt", &attr_idDR));
										ITK_CALL(AOM_lock(relStatus_list[ss]));
										ITK_CALL (POM_set_attr_date(1, &relStatus_list[ss], attr_idDR, EfftiveFromDate));
										ITK_CALL (AOM_save_without_extensions(relStatus_list[ss]));
										ITK_CALL(AOM_refresh(relStatus_list[ss],1));
										ITK_CALL(AOM_unlock(relStatus_list[ss]));

										date_t *start_end_date = NULL;
										tag_t eff_d = NULLTAG;
										start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
										start_end_date[0] = EfftiveFromDate;
										start_end_date[1] = EfftiveToDate;

										ITK_CALL(WSOM_status_clear_effectivities(relStatus_list[ss]));
										ITK_CALL(WSOM_effectivity_create_with_dates(relStatus_list[ss], NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
										ITK_CALL(AOM_save_with_extensions(eff_d));

										printf("**********************************%s,%s\n", partNoIP,rev_id); fflush(stdout);
									}
									else
									{
										fprintf(fp1, "%s,RelDateInvalid\n", partNoIP); fflush(stdout);
									}
								}
							}
						}
					}
					
					ifail = setDateAttributesOnItemRev(item_rev_tag, partCreationDtIP, partLastUpdateDate);
				}
				else
				{
					fprintf(fp1, "%s,MultiRevision\n", partNoIP); fflush(stdout);
				}
			}
		}

		fclose(fp1);
		fclose(fp);

		ifail = ITK_exit_module(TRUE);
		printf("\nReturn Value is : %d", ifail);
		if (ifail == ITK_ok)
		{
			printf("\nTeamcenter Logout Success...");fflush(stdout);
		}
		else
		{
			EMH_ask_error_text(ifail, &cError);
			printf("\nError is : %s", cError);fflush(stdout);
		}
		
	
	return ITK_ok;
}

static int	validate_date ( char *date , logical *date_is_valid , date_t *the_dt )
{
    int      retcode    = ITK_ok;     /* Function return code */
    date_t   dt         = NULLDATE;   /* Date structure */
    int      month      = 0;          /* Month */
    int      day        = 0;          /* Day */
    int      year       = 0;          /* Year */
    int      hour       = 0;          /* Hour */ 
    int      minute     = 0;          /* Minutes */
    int      second     = 0;          /* Seconds */

    *date_is_valid = TRUE;

    /* Converts a date_t structure into the format specified  */
//    retcode = DATE_string_to_date ( date , "%d-%b-%Y %H:%M:%S" , &month , &day , &year , &hour , &minute , &second);				// working for " 21-August-2015" / ""
//    retcode = DATE_string_to_date ( date , "%m-%d-%y-%H:%M:%S" , &month , &day , &year , &hour , &minute , &second);				// working for  "07-21-2015-09:05:58"
    retcode = DATE_string_to_date ( date , "%y/%m/%d-%H:%M:%S" , &month , &day , &year , &hour , &minute , &second);
    if ( retcode != ITK_ok )
    {
        *date_is_valid = FALSE;
    }
    else
    {
        dt.month = month;
        dt.day   = day;
        dt.year  = year;
        dt.hour  = hour;
        dt.minute= minute;
        dt.second= second;

        *the_dt = dt;
    }

	printf("  ---return from validate_date....\n");

    return retcode;
}

int setDateAttributesOnItemRev(tag_t rev_t,char* CreDateTempS, char* partLastUpdateDate)
{
	int ifail = ITK_ok;
	int retcode = ITK_ok;  // Function return code

	ITK_initialize_text_services (0);

	logical bypass = TRUE;

	printf("\nCreDateTempS:[%s]  partLastUpdateDate:[%s] \n",CreDateTempS,partLastUpdateDate); fflush(stdout);

	if(strlen(CreDateTempS)> 1)
	{
		char* Year = NULL;
	    char* Month	= NULL;
	    char* Day = NULL;
	    char* Hours	= NULL;
	    char* Min = NULL;
	    char* Sec = NULL;
	    char* MicroSec = NULL;
	    char* PrtCreDateS = NULL;
		char* Year2 = NULL;
	    char* Month2	= NULL;
	    char* Day2 = NULL;
	    char* Hours2	= NULL;
	    char* Min2 = NULL;
	    char* Sec2 = NULL;
	    char* MicroSec2 = NULL;
		date_t creationDate_D;
	    logical date_is_valid = FALSE;

	    PrtCreDateS = ( char * ) MEM_alloc(30);

		ifail = AOM_lock(rev_t);

		Year=strtok(CreDateTempS,"/");
		Month=strtok(NULL,"/");
		Day=strtok(NULL,"-");
		Hours=strtok(NULL,":");
		Min=strtok(NULL,":");
		Sec=strtok(NULL,":");
		MicroSec=strtok(NULL,":");

		//printf("\n..1..%s",Year); fflush(stdout);
		strcpy(PrtCreDateS,"");
		strcpy(PrtCreDateS,Year);
		strcat(PrtCreDateS,"/");
		//printf("\n..2..%s",Month); fflush(stdout);
		strcat(PrtCreDateS,Month);
		strcat(PrtCreDateS,"/");
		//printf("\n..3..%s",Day); fflush(stdout);
		strcat(PrtCreDateS,Day);
		strcat(PrtCreDateS,"-");
		//printf("\n..4..%s",Hours); fflush(stdout);
		strcat(PrtCreDateS,Hours);
		strcat(PrtCreDateS,":");
		//printf("\n..5..%s",Min); fflush(stdout);
		strcat(PrtCreDateS,Min);
		strcat(PrtCreDateS,":");
		//printf("\n..6..%s",Sec); fflush(stdout);
		strcat(PrtCreDateS,Sec);

		printf("New Creation Date is --> [%s]",PrtCreDateS); fflush(stdout);
		
		retcode = validate_date( PrtCreDateS , &date_is_valid , &creationDate_D );
		if ( retcode != ITK_ok )
		{
			printf ( " Creation Date--error code %d\n\n", retcode); fflush(stdout);
			return EXIT_FAILURE;
		}

		ifail = POM_set_creation_date(rev_t, creationDate_D);

		ifail = ITK_set_bypass ( bypass );
		ifail = POM_set_modification_date(rev_t, creationDate_D);
		ifail = POM_set_env_info( POM_bypass_attr_update , false, 0, 0.0, NULLTAG, "");
		ifail = AOM_save_without_extensions(rev_t);
		ifail = AOM_unlock(rev_t);

		printf("\n Creation Date is updated [%s] \n",PrtCreDateS); fflush(stdout);
	}

	if(strlen(partLastUpdateDate)> 1)
	{
		char* Year = NULL;
	    char* Month	= NULL;
	    char* Day = NULL;
	    char* Hours	= NULL;
	    char* Min = NULL;
	    char* Sec = NULL;
	    char* MicroSec = NULL;
	    char* PrtCreDateS = NULL;
		char* Year2 = NULL;
	    char* Month2	= NULL;
	    char* Day2 = NULL;
	    char* Hours2	= NULL;
	    char* Min2 = NULL;
	    char* Sec2 = NULL;
	    char* MicroSec2 = NULL;
		date_t creationDate_D;
	    logical date_is_valid = FALSE;

	    PrtCreDateS = ( char * ) MEM_alloc(30);

		ifail = AOM_lock(rev_t);

		Year=strtok(partLastUpdateDate,"/");
		Month=strtok(NULL,"/");
		Day=strtok(NULL,"-");
		Hours=strtok(NULL,":");
		Min=strtok(NULL,":");
		Sec=strtok(NULL,":");
		MicroSec=strtok(NULL,":");

		//printf("\n..1..%s",Year); fflush(stdout);
		strcpy(PrtCreDateS,"");
		strcpy(PrtCreDateS,Year);
		strcat(PrtCreDateS,"/");
		//printf("\n..2..%s",Month); fflush(stdout);
		strcat(PrtCreDateS,Month);
		strcat(PrtCreDateS,"/");
		//printf("\n..3..%s",Day); fflush(stdout);
		strcat(PrtCreDateS,Day);
		strcat(PrtCreDateS,"-");
		//printf("\n..4..%s",Hours); fflush(stdout);
		strcat(PrtCreDateS,Hours);
		strcat(PrtCreDateS,":");
		//printf("\n..5..%s",Min); fflush(stdout);
		strcat(PrtCreDateS,Min);
		strcat(PrtCreDateS,":");
		//printf("\n..6..%s",Sec); fflush(stdout);
		strcat(PrtCreDateS,Sec);

		printf("New LastUpdate Date is --> [%s]",PrtCreDateS); fflush(stdout);
		
		retcode = validate_date( PrtCreDateS , &date_is_valid , &creationDate_D );
		if ( retcode != ITK_ok )
		{
			printf ( " LastUpdate Date--error code %d\n\n", retcode); fflush(stdout);
			return EXIT_FAILURE;
		}

		ifail = POM_set_modification_date(rev_t, creationDate_D);

		ifail = ITK_set_bypass ( bypass );
		ifail = POM_set_modification_date(rev_t, creationDate_D);
		ifail = POM_set_env_info( POM_bypass_attr_update , false, 0, 0.0, NULLTAG, "");
		ifail = AOM_save_without_extensions(rev_t);
		ifail = AOM_unlock(rev_t);

		printf("\n LastUpdate Date is updated [%s] \n",PrtCreDateS); fflush(stdout);
	}

	return 0;
}