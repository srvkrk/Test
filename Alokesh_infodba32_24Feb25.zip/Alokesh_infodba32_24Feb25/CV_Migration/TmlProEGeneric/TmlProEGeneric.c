#define TE_MAXLINELEN  128
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

FILE* fp=NULL;

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	fprintf(stderr,"Login fail !!: Error code = %d \n\n",ifail);
	CHECK_FAIL;
}
extern int ITK_user_main (int argc, char ** argv )
{
    int status;
	int n_tags_found= 0;
	int n_tags_found2= 0;
	int org_seq_id_int = 0;
	int i=0, hits=0;
	int resultCount =0;
	int n_entries = 1;
	int result;
	int lockFlag;
	int k, n_attchs=0;

	char *itemRevSeq = NULL;
	char *inputfile=NULL;
	char* genericName = NULL;
	char* genericRev = NULL;
	char* genericSeq = NULL;
	char* abc4 = NULL;
	char* abc5 = NULL;
	char* abc6 = NULL;
	char* abc7 = NULL;
	char* abc8 = NULL;
	char* abc9 = NULL;
	char* abc10 = NULL;
	char* abc11 = NULL;
	char* abc12 = NULL;
	char* abc13 = NULL;
	char* abc14 = NULL;
	char* abc15 = NULL;
	char* abc16 = NULL;
	char* abc17 = NULL;
	char* abc18 = NULL;
	char* abc19 = NULL;
	char* abc20 = NULL;
	char* abc21 = NULL;
	char* abc22 = NULL;
	char* abc23 = NULL;
	char* abc24 = NULL;
	char* abc25 = NULL;
	char* abc26 = NULL;
	char* abc27 = NULL;
	char* abc28 = NULL;
	char* abc29 = NULL;
	char* abc30 = NULL;
	char* abc31 = NULL;
	char* abc32 = NULL;
	char* abc33 = NULL;
	char* abc34 = NULL;
	char* abc35 = NULL;
	char* abc36 = NULL;
	char* abc37 = NULL;
	char* abc38 = NULL;
	char* abc39 = NULL;
	char* abc40 = NULL;
	char* abc41 = NULL;
	char* abc42 = NULL;
	char* abc43 = NULL;
	char* abc44 = NULL;
	char* abc45 = NULL;
	char* abc46 = NULL;
	char* abc47 = NULL;
	char* abc48 = NULL;
	char* abc49 = NULL;
	char* abc50 = NULL;
	char* abc51 = NULL;
	char* abc52 = NULL;
	char* abc53 = NULL;
	char* abc54 = NULL;
	char* abc55 = NULL;
	char* abc56 = NULL;
	char* abc57 = NULL;
	char* abc58 = NULL;
	char* abc59 = NULL;
	char* abc60 = NULL;
	char* abc61 = NULL;
	char* abc62 = NULL;
	char* abc63 = NULL;
	char* abc64 = NULL;
	char* abc65 = NULL;
	char* abc66 = NULL;
	char* abc67 = NULL;
	char* abc68 = NULL;
	char* abc69 = NULL;
	char* abc70 = NULL;
	char* abc71 = NULL;
	char* abc72 = NULL;
	char* abc73 = NULL;
	char* abc74 = NULL;
	char* abc75 = NULL;
	char* abc76 = NULL;
	char* abc77 = NULL;
	char* abc78 = NULL;
	char* abc79 = NULL;
	char* abc80 = NULL;
	char* abc81 = NULL;
	char* abc82 = NULL;
	char* abc83 = NULL;
	char* abc84 = NULL;
	char* abc85 = NULL;
	char* className = NULL;
	char* inputline=NULL;
	char* instanceNameTemp = NULL;
	char* instanceName = NULL;
	char* level = NULL;
	char* partnumber = NULL;

	char *req_item=NULL;
	char *req_child=NULL;
	//char *itemGeneric_RevSeq="NR;1";	//commented on 21.03.2017 for non-standard project Generic like 284646808217<284646800403>
	char *itemGeneric_RevSeq = NULL;
	char *item_rev = NULL;
	char *item_seq = NULL;
	char *ds_item_id = NULL;

	//char name[WSO_name_size_c+1];
	char* type_name = NULL ;
	char* type_name3 = NULL ;
	char* type_name4 = NULL;

	char
	*qry_entries4[1] = {"Name"},
	*qry_values4[1]	= {"*"};

	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));
	char **attrs2 = (char **) MEM_alloc(1 * sizeof(char *));
	char **values2 = (char **) MEM_alloc(1 * sizeof(char *));

	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	tag_t *tags_found = NULL;
	tag_t *tags_found2 = NULL;
	tag_t *list = NULLTAG;
	tag_t *revtag = NULLTAG;
	tag_t* secondary_objects = NULLTAG;

	tag_t queryTag = NULLTAG;
	tag_t item = NULLTAG;
	tag_t item2 = NULLTAG;
	tag_t revtag2 = NULLTAG;
	tag_t itemRevtag2 = NULLTAG;
	tag_t revtag3 = NULLTAG;
	tag_t tRelationFind = NULLTAG;
	tag_t relation = NULLTAG;
	tag_t revisiontag = NULLTAG;
	tag_t Fndrelation = NULLTAG;
	tag_t DataSetObjs = NULLTAG;
	tag_t firstItemDataSettag = NULLTAG;

//	ITK_CALL(ITK_init_module("loader" ,"loader7","dba")!=ITK_ok) ;
//	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
//	ITK_CALL(ITK_auto_login( ));
//	ITK_CALL(ITK_set_journalling( TRUE ));

	initialise();

	inputfile = ITK_ask_cli_argument("-i=");

	fp = fopen( inputfile, "r" );

	if(fp!=NULL)
	{
		inputline=(char *) MEM_alloc(1500);
		while(fgets(inputline,1500,fp)!=NULL)
		{
			fputs(inputline,stdout);

			//level=strtok(inputline,"^");
			//genericName=strtok(NULL,"^");
			genericName=strtok(inputline,"^");
			genericRev=strtok(NULL,"^");
			genericSeq=strtok(NULL,"^");
			abc4=strtok(NULL,"^");
			abc5=strtok(NULL,"^");
			abc6=strtok(NULL,"^");
			abc7=strtok(NULL,"^");
			abc8=strtok(NULL,"^");
			abc9=strtok(NULL,"^");
			abc10=strtok(NULL,"^");
			abc11=strtok(NULL,"^");
			abc12=strtok(NULL,"^");
			abc13=strtok(NULL,"^");
			abc14=strtok(NULL,"^");
			abc15=strtok(NULL,"^");
			abc16=strtok(NULL,"^");
			abc17=strtok(NULL,"^");
			abc18=strtok(NULL,"^");
			abc19=strtok(NULL,"^");
			abc20=strtok(NULL,"^");
			abc21=strtok(NULL,"^");
			abc22=strtok(NULL,"^");
			abc23=strtok(NULL,"^");
			abc24=strtok(NULL,"^");
			abc25=strtok(NULL,"^");
			abc26=strtok(NULL,"^");
			abc27=strtok(NULL,"^");
			abc28=strtok(NULL,"^");
			abc29=strtok(NULL,"^");
			abc30=strtok(NULL,"^");
			abc31=strtok(NULL,"^");
			abc32=strtok(NULL,"^");
			abc33=strtok(NULL,"^");
			abc34=strtok(NULL,"^");
			abc35=strtok(NULL,"^");
			abc36=strtok(NULL,"^");
			abc37=strtok(NULL,"^");
			abc38=strtok(NULL,"^");
			abc39=strtok(NULL,"^");
			abc40=strtok(NULL,"^");
			abc41=strtok(NULL,"^");
			abc42=strtok(NULL,"^");
			abc43=strtok(NULL,"^");
			abc44=strtok(NULL,"^");
			abc45=strtok(NULL,"^");
			abc46=strtok(NULL,"^");
			abc47=strtok(NULL,"^");
			abc48=strtok(NULL,"^");
			abc49=strtok(NULL,"^");
			abc50=strtok(NULL,"^");
			abc51=strtok(NULL,"^");
			abc52=strtok(NULL,"^");
			abc53=strtok(NULL,"^");
			abc54=strtok(NULL,"^");
			abc55=strtok(NULL,"^");
			abc56=strtok(NULL,"^");
			abc57=strtok(NULL,"^");
			abc58=strtok(NULL,"^");
			abc59=strtok(NULL,"^");
			abc60=strtok(NULL,"^");
			abc61=strtok(NULL,"^");
			abc62=strtok(NULL,"^");
			abc63=strtok(NULL,"^");
			abc64=strtok(NULL,"^");
			abc65=strtok(NULL,"^");
			abc66=strtok(NULL,"^");
			abc67=strtok(NULL,"^");
			abc68=strtok(NULL,"^");
			abc69=strtok(NULL,"^");
			abc70=strtok(NULL,"^");
			abc71=strtok(NULL,"^");
			abc72=strtok(NULL,"^");
			abc73=strtok(NULL,"^");
			abc74=strtok(NULL,"^");
			abc75=strtok(NULL,"^");
			abc76=strtok(NULL,"^");
			abc77=strtok(NULL,"^");
			abc78=strtok(NULL,"^");
			abc79=strtok(NULL,"^");
			abc80=strtok(NULL,"^");				//t5PFDModReqdS			//80
			abc81=strtok(NULL,"^");
			abc82=strtok(NULL,"^");
			abc83=strtok(NULL,"^");
			abc84=strtok(NULL,"^");
			abc85=strtok(NULL,"^");				//LeftRhPartDup			//85
			instanceNameTemp=strtok(NULL,"^");	//instanceName;Rev;Seq	//86

			printf("\n abc84:[%s] abc85:[%s]",abc84,abc85); fflush(stdout);
			printf("\n genericName:[%s] instanceNameTemp:[%s]",genericName,instanceNameTemp); fflush(stdout);

			if(strlen(instanceNameTemp) > 5)
			{
				instanceName=strtok(instanceNameTemp,";");
				item_rev=strtok(NULL,";");
				item_seq=strtok(NULL,";");

/*
char *c = "";
if ((c != NULL) && (c[0] == '\0')) {
   printf("c is empty\n");
}

or

if (c && !c[0]) {
  printf("c is empty\n");
}
*/
				itemRevSeq = NULL;
				itemRevSeq=(char *) MEM_alloc(32);
				strcpy(itemRevSeq,item_rev);
				strcat(itemRevSeq,";");
				strcat(itemRevSeq,item_seq);

				itemGeneric_RevSeq = NULL;
				itemGeneric_RevSeq =(char *) MEM_alloc(32);
				strcpy(itemGeneric_RevSeq , genericRev);
				strcat(itemGeneric_RevSeq , ";");
				strcat(itemGeneric_RevSeq , genericSeq);

				printf("\n "); fflush(stdout);

				if(instanceName)
				{
					attrs[0] ="item_id";
					values[0] = (char *)instanceName;
					ITK_CALL(ITEM_find_items_by_key_attributes(1,(const char **)attrs, (const char **)values, &n_tags_found, &tags_found));

					printf(" instance..n_tags_found:: %d\n",n_tags_found);

					if(n_tags_found>0)
					{
						item = tags_found[0];

						printf(" instance..Item Found:: %s  %s,%s\n",instanceName,item_rev,item_seq);

						//ITK_CALL(ITEM_find_revision(item,item_rev,&itemRevtag2));
						ITK_CALL(ITEM_find_revision(item,itemRevSeq,&itemRevtag2));

						char* projectcode = NULL;
						if (AOM_ask_value_string(itemRevtag2,"t5_ProjectCode",&projectcode)!=ITK_ok);
						if (tc_strstr(projectcode,"1111")!=NULL && tc_strlen(instanceName)==11)
						{
							printf("\n\t\t*****Skipping for Project Code : 1111\n"); fflush(stdout);
							continue;
						}

						ITK_CALL(GRM_list_secondary_objects_only(itemRevtag2 , NULLTAG , &n_attchs, &secondary_objects));
						printf(" instance..n_attchs == %d \n",n_attchs); fflush(stdout);

						for (k = 0; k < n_attchs; k++)
						{
							ITK_CALL(TCTYPE_ask_object_type(secondary_objects[k],&DataSetObjs));
							ITK_CALL(TCTYPE_ask_name2(DataSetObjs,&type_name3));

							printf("\n instance..type_name3:[%s]",type_name3);

							if (strstr(type_name3,"ProAsm")!=NULL || strstr(type_name3,"ProPrt")!=NULL )
							{
								firstItemDataSettag = secondary_objects[k];

								attrs2[0] ="item_id";
								values2[0] = (char *)genericName;
								
								//Querying with item id
								ITK_CALL(ITEM_find_items_by_key_attributes(1,(const char **)attrs2, (const char **)values2, &n_tags_found2, &tags_found2));
								printf(" instance..n_tags_found2:: %d",n_tags_found2);

								if(n_tags_found2>0)
								{
									item2 = tags_found2[0];
									ITK_CALL(ITEM_find_revision(item2,itemGeneric_RevSeq,&revtag3));

									if(revtag3 != NULLTAG)
									{
										ITK_CALL(GRM_find_relation_type("IPEM_master_dependency",&tRelationFind ));

										if(tRelationFind != NULLTAG)
										{
											ITK_CALL(TCTYPE_ask_name2(tRelationFind,&type_name));
											printf("\n instance..Type Name:%s ..............",type_name);fflush(stdout);
										}

										ITK_CALL( GRM_find_relation( firstItemDataSettag, revtag3, tRelationFind ,&Fndrelation));

										if(Fndrelation != NULLTAG)
										{
											printf("\n\t instance..Relation Already Exist.\n\n" ); fflush(stdout);
											//printf("\t deleting relation \n" ); fflush(stdout);
											//ITK_CALL(GRM_delete_relation(Fndrelation));
										}
										else
										{
											printf(" instance..GRM_create_relation before:\n");fflush(stdout);
											ITK_CALL(GRM_create_relation(firstItemDataSettag,revtag3,tRelationFind,NULLTAG,&relation));
											printf(" instance..GRM_create_relation:\n");fflush(stdout);

											if(relation != NULLTAG)
											{
												ITK_CALL(AOM_refresh (firstItemDataSettag,0));
												//printf(" instance..Before GRM_save_relation\n");fflush(stdout);
												ITK_CALL(GRM_save_relation(relation));
												printf(" instance..GRM_save_relation:\n\n");fflush(stdout);
											}
										}
										break;
									}
								}
							} // if condn for type_name3
						} //for loop n_attchs
					} //if(n_tags_found>0)
				} //if(instanceName)

				//Pro2_instance realtion
				if(genericName)
				{
					attrs[0] ="item_id";
					values[0] = (char *)genericName;
					ITK_CALL(ITEM_find_items_by_key_attributes(1,(const char **)attrs, (const char **)values, &n_tags_found, &tags_found));

					printf("\n\n generic..n_tags_found:: %d\n",n_tags_found);

					if(n_tags_found>0)
					{
						item = tags_found[0];

						printf(" generic..Item Found:: %s  %s\n",genericName,itemGeneric_RevSeq);

						ITK_CALL(ITEM_find_revision(item,itemGeneric_RevSeq,&itemRevtag2));

						ITK_CALL(GRM_list_secondary_objects_only(itemRevtag2 , NULLTAG , &n_attchs, &secondary_objects));
						printf(" generic..n_attchs == %d \n",n_attchs); fflush(stdout);

						for (k = 0; k < n_attchs; k++)
						{
							ITK_CALL(TCTYPE_ask_object_type(secondary_objects[k],&DataSetObjs));
							ITK_CALL(TCTYPE_ask_name2(DataSetObjs,&type_name3));

							printf(" generic..type_name3:[%s]\n",type_name3);

							if (strstr(type_name3,"ProAsm")!=NULL || strstr(type_name3,"ProPrt")!=NULL )
							{
								firstItemDataSettag = secondary_objects[k];

								attrs2[0] ="item_id";
								values2[0] = (char *)instanceName;
								
								//Querying with item id
								ITK_CALL(ITEM_find_items_by_key_attributes(1,(const char **)attrs2, (const char **)values2, &n_tags_found2, &tags_found2));
								printf(" generic..n_tags_found2:: %d  for itemRevSeq: %s \n",n_tags_found2,itemRevSeq);

								if(n_tags_found2>0)
								{
									item2 = tags_found2[0];
									ITK_CALL(ITEM_find_revision(item2,itemRevSeq,&revtag3));

									if(revtag3 != NULLTAG)
									{
										ITK_CALL(GRM_find_relation_type("Pro2_instance",&tRelationFind ));

										if(tRelationFind != NULLTAG)
										{
											ITK_CALL(TCTYPE_ask_name2(tRelationFind,&type_name));
											printf(" generic..Type Name:%s ..............\n",type_name);fflush(stdout);
										}

										ITK_CALL( GRM_find_relation( firstItemDataSettag, revtag3, tRelationFind ,&Fndrelation));

										if(Fndrelation != NULLTAG)
										{
											printf("\n generic..Relation Already Exist.\n\n" ); fflush(stdout);
											//printf("\t deleting relation \n" ); fflush(stdout);
											//ITK_CALL(GRM_delete_relation(Fndrelation));
										}
										else
										{
											printf(" generic..GRM_create_relation before:\n");fflush(stdout);
											ITK_CALL(GRM_create_relation(firstItemDataSettag,revtag3,tRelationFind,NULLTAG,&relation));
											printf(" generic..GRM_create_relation:\n");fflush(stdout);

											if(relation != NULLTAG)
											{
												ITK_CALL(AOM_refresh (firstItemDataSettag,0));
												//printf(" generic..Before GRM_save_relation\n");fflush(stdout);
												ITK_CALL(GRM_save_relation(relation));
												printf(" generic..GRM_save_relation:\n");fflush(stdout);
											}
										}
										break;
									}
								}
							} // if condn for type_name3
						} //for loop n_attchs
					} //if(n_tags_found>0)
				} // if(genericName)
			}
			else
			{
				printf("\t .... Part is not valid for Pro-Gen relation\n");fflush(stdout);
			}
		} //while 
	}


/*
	req_item = ITK_ask_cli_argument("-i=");
	req_child = ITK_ask_cli_argument("-j=");

	printf("\n input req_item :%s:::%s\n",req_item,req_child);fflush(stdout);

	if(req_item)
	{
		if(WSOM_find (req_item,&hits,&list) !=ITK_ok) PrintErrorStack();
		printf("\n hits :%d\n",hits);fflush(stdout);

		for (i=0;i<hits ;i++ )
		{
			if(WSOM_ask_object_type(list[i],type_name3)!=ITK_ok)PrintErrorStack();
			printf("\n type_name3333 :%s\n",type_name3);fflush(stdout);

			if (strcmp(type_name3,"ProAsm")==0 || strcmp(type_name3,"ProPrt")==0 )
			{
				if(req_child)
				{
					if(QRY_find("ProE Query", &queryTag));
					printf("\n After IFERR_REPORT : QRY_find \n");fflush(stdout);
					if (queryTag)
					{
						printf("Found Query \n");fflush(stdout);
					}
					else
					{
						printf("Not Found Query");fflush(stdout);
					}
					qry_values[0] = req_item ;
					if(QRY_execute(queryTag, n_entries, qry_entries4, qry_values, &resultCount, &revtag));

					if(resultCount>0)
					{
						//item = tags_found[0];
						printf(" Item already exists\n");fflush(stdout);
					}

					attrs[0] ="item_id";
					values[0] = (char *)req_child;
					//Querying with item id
					ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));
					printf(" n_tags_found:: %d\n",n_tags_found);

					if(n_tags_found>0)
					{
						item = tags_found[0];
						printf(" Item already exists .... %s\n",item_rev);
						ITK_CALL(ITEM_find_revision(item,item_rev,&revtag2));
						//result = ITEM_ask_name (revtag2, name);
						//printf("\n name:[%s]",name);fflush(stdout);

						result = AOM_lock( revtag2 );

						if(revtag2 != NULLTAG)
						{
							ITK_CALL(AOM_ask_value_int(revtag2,"sequence_id",&org_seq_id_int));
							printf("\norg_seq_id_int:[%d]\n",org_seq_id_int);

							//AOM_ask_value_string(tag_t object_tag,const char *  	prop_name, char **  	value	 ) 	;

							result = GRM_find_relation_type("IPEM_master_dependency",&tRelationFind );
							//result = GRM_find_relation_type("ImanRelation",&tRelationFind );

							printf("\n result :%d:\n",result);fflush(stdout);

							if(tRelationFind)
							{
								ITK_CALL(TCTYPE_ask_name(tRelationFind,type_name));
								printf("\n Type Name:%s ..............",type_name);fflush(stdout);
							}

							revisiontag = revtag[0];

							printf("\n GRM_create_relation before:\n");fflush(stdout);
							int  ifail1 =GRM_create_relation(revisiontag,revtag2,tRelationFind,NULLTAG,&relation);//PrintErrorStack();
							printf("\n GRM_create_relation:\n");fflush(stdout);

							if(relation)
							{
								printf("\nBefore GRM_save_relation\n");fflush(stdout);
								if(GRM_save_relation(relation)!=ITK_ok)//PrintErrorStack();
								printf("\n GRM_save_relation:\n");fflush(stdout);
							}
						}
						else
						{
							printf("Item Revision not found....\n");
						}

						result = AOM_unlock( revtag2 );
					}


				}
				break;
			}
		}
	} */
	ITK_CALL(POM_logout(false));
	return status;
}
