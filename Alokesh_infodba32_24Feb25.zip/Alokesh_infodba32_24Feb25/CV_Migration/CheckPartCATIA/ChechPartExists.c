/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:tm_altoz.c
*
* Description		: > This Utility is to do unit testing of functions .
* Module  		        
* Since		    :    

* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 16/06/2022   	Sanjoy Mondal			    Initial Code

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/aom_prop.h>
#include <ae/dataset.h>

//Ujjawal - (For Global Variables)
FILE 		*output 			= NULL;
FILE 		*notInCVProd 	= NULL;

#define MAX_LINE_LEN 10024
#define Debug TRUE
#define ITK_CALL(X)  	\
		if(Debug) \
		{ \
			printf(#X); 	\
		} \
		fflush(NULL); 	\
		status=X;  \
		if (status != ITK_ok )  \
		{ \
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
 \
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails); 	\
			for( index=0; index<n_ifails; index++) 	\
			{  \
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}  \
			return status; 	\
		}  \
		else \
		{ \
			if(Debug) 	\
			printf("\tSUCCESS\n");				\
		} \

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

int check_Part_CVPROD(char* moduleId, char* moduleRev, char* moduleSeq, int *result_count)
{
	int ifail 			= ITK_ok;
	tag_t   qryTag		= NULLTAG;
	int     n_entry		= 3;
	int     rsltCount	= 0;
	char    *qry_entry[3]  = {"Item ID", "Revision", "Release Status"};
	tag_t   *revTag   	= NULLTAG;
	char    **qry_values2     =  (char **) MEM_alloc(100 * sizeof(char *));
	char *revision = NULL;
	revision = (char	*)MEM_alloc(100);
	tc_strcpy(revision, moduleRev);
	tc_strcat(revision, ";");
	tc_strcat(revision, moduleSeq);
		
	if(QRY_find2("Item Revision...", &qryTag));
	if (!qryTag)
	{
		printf("\n NOT Found Query Item Revision... \n");fflush(stdout);
	}

	qry_values2[0] = moduleId;
	qry_values2[1] = revision;
	qry_values2[2] = "T5_LcsErcRlzd";
	printf("\nPart --> %s Revision --> %s... Status --> %s",qry_values2[0],qry_values2[1],qry_values2[2]); fflush(stdout);

	if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &revTag));
	if (rsltCount>0)
	{
		tag_t relation_type = NULLTAG;
		tag_t *attachments = NULLTAG;
		int cnt = 0;
		int ij = 0;
		tag_t dataset = NULLTAG;
		char *ObjectClassType = NULL;
		char *DrawingInd = NULL;
		char *ObjectName = NULL;
		int DrawingIndStat = 0;
		int DrawingFile = 0;
		int PDFFile = 0;
		int CADFile = 0;
		int JTFile = 0;
		int FinalJTCAD = 0;
		int FinalDRWPDF = 0;
		if(GRM_list_secondary_objects_only(revTag[0],relation_type,&cnt,&attachments))PrintErrorStack();
		for(ij=0;ij<cnt;ij++)
        {
        	dataset = attachments[ij];
        	if (AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok)   PrintErrorStack();
	        if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
            if ((strcmp(ObjectClassType,"ProPrt")==0) || (strcmp(ObjectClassType,"ProAsm")==0) || (strcmp(ObjectClassType,"CMI2Part")==0) || (strcmp(ObjectClassType,"CMI2Product")==0))
        	{
        		printf("\n\t\t CAD File Found :%s (%s)",ObjectClassType,ObjectName);fflush(stdout);
        		CADFile = 1;
        	}
        	if (strcmp(ObjectClassType,"DirectModel")==0)
        	{
        		printf("\n\t\t JT File Found :%s (%s)",ObjectClassType,ObjectName);fflush(stdout);
        		JTFile = 1;
        	}
        	if ((strcmp(ObjectClassType,"ProDrw")==0) || (strcmp(ObjectClassType,"CMI2Drawing")==0))
        	{
        		printf("\n\t\t DRAWING File Found :%s (%s)",ObjectClassType,ObjectName);fflush(stdout);
        		DrawingFile = 1;
        	}
        	if (strcmp(ObjectClassType,"PDF")==0)
        	{
        		printf("\n\t\t PDF File Found :%s (%s)",ObjectClassType,ObjectName);fflush(stdout);
        		PDFFile = 1;
        	}
        }
        if(CADFile == 1 && JTFile == 1)
        {
        	FinalJTCAD = 1;
        	printf("\nCAD File and JT File both Present");fflush(stdout);
        }
        else
        {
        	printf("\nEither CAD File or JT File or both Missing");fflush(stdout);
        }
        if (AOM_ask_value_string(revTag[0],"t5_DrawingInd",&DrawingInd)!=ITK_ok)   PrintErrorStack();
        if (DrawingInd != NULL)
        {
        	printf("\n\tDrawingInd : %s",DrawingInd);fflush(stdout);
        	if (tc_strcmp(DrawingInd,"D") == 0)
        	{
        		DrawingIndStat = 1;
        	}
        	else
        	{
        		FinalDRWPDF = 1;
        	}
        }
        if (DrawingIndStat == 1)
        {
        	if(DrawingFile == 1 && PDFFile == 1)
	        {
	        	FinalDRWPDF = 1;
	        	printf("\nDrawing and PDF both Present");fflush(stdout);
	        }
	        else
	        {
	        	printf("\nEither Drawing or PDF or both Missing");fflush(stdout);
	        }
        }

        if(FinalJTCAD == 1 && FinalDRWPDF == 1)
        {
        	printf("\n\t\tFinal Status: Skipped from Downloading\n");fflush(stdout);
			*result_count = 1;
        }
        else
        {
        	printf("\n\t\tFinal Status: Need to Download\n");fflush(stdout);
        	*result_count = 0;
        }
    }
    else
    {
    	printf("\n\t\tPart Rev Seq not Present in CVPROD. Final Status: Need to Download\n");fflush(stdout);
        *result_count = 0;
    }

	return ifail;
}


int ITK_user_main(int argc, char* argv[])
{
	
	
	int ifail = ITK_ok;

	char			Data[100]					= "";
	
	char 			*test						= (char*)MEM_alloc(sizeof(char) * 50);
	char			outputFile[200]				= "";
	char			notInCVProdFileNm[200]				= "";
	
	ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
	
	
	printf("\n SAN:updateVf: *********** Start Of Main function ************* \n");fflush(stdout);	
	
	if(ITK_auto_login() == ITK_ok)	
	{
		/***** Start Variable Declarations************/
		ifail = ITK_ok;
		tag_t user_tag = NULLTAG;
		char* username = NULL;		
		int ii = 0;
		int n_children = 0;		
		char *filepath = ITK_ask_cli_argument("-f=");		
		FILE * fp = NULL;

		char		*sep				= "_";
		int check_Part_CVPROD(char*,char*,char*,int*);

		/***** End Variable Declarations************/
		
		ITK_set_journalling( TRUE );
		printf("\nSAN:updateVf: Login successfull.\n");fflush(stdout);			
		
		POM_get_user(&username,&user_tag);
		printf("\nSAN:Session User Name[%s]\n",username);fflush(stdout);
		
		printf("\nSAN:Input Parameters:Input File:[%s]\n",filepath);fflush(stdout);

		time_t 	now;
		struct 	tm when;		
		time(&now);
		when = *localtime(&now);
		
		sprintf(outputFile,"Found_%s",filepath);
				
		output = fopen(outputFile,"w");
		if (output == NULL)
		{
			printf("ERROR: Cannot open File\n");
			return -1;
		}

		sprintf(notInCVProdFileNm,"Not_Found_%s",filepath);

		notInCVProd = fopen(notInCVProdFileNm,"w");
		if (notInCVProd == NULL)
		{
			printf("ERROR: Cannot open File\n");
			return -1;
		}

		char* destination = NULL;
		destination = (char *)MEM_alloc(200);

		fp = fopen(filepath, "r");		

		if(fp==NULL)
		{
			printf("\nCould not open the file %s. Kindly check.\n",filepath);fflush(stdout);
		}
		else
		{
			char buffer[MAX_LINE_LEN] ="";			
			int k = 0;
			printf("\nStart of Part form Main"); fflush(stdout);
			while(fgets(buffer, MAX_LINE_LEN,fp)!= NULL)
			{
				char* inpLine = NULL;
				inpLine = strdup(buffer);
				tc_strcpy(destination,"");
				STRNG_replace_str(inpLine,"\n","",&destination);
				tc_strcpy(inpLine,destination);
				char* moduleId = NULL;
				char* moduleRev = NULL;
				char* moduleSeq = NULL;
				moduleId = strtok(buffer,";");
				moduleRev =strtok(NULL,";");
				moduleSeq =strtok(NULL,";");
				int result_count = 0;
				tc_strcpy(destination,"");
				STRNG_clean_up_string(moduleSeq);
				STRNG_replace_str(moduleSeq,"_","",&destination);
				tc_strcpy(moduleSeq,destination);

				printf("\nInput Line %d : %s ; %s ; %s",++k,moduleId,moduleRev,moduleSeq);fflush(stdout);
				ifail = check_Part_CVPROD(moduleId,moduleRev,moduleSeq,&result_count);

				if(result_count == 0)
				{
					fprintf(notInCVProd, "%s\n",inpLine);fflush(notInCVProd);
				}
				else
				{
					fprintf(output, "%s\n",inpLine);fflush(output);
				}
			}
			printf("\nEnd of Part form Main"); fflush(stdout);
		}
	}
	else
	{
		printf("\nLogin Failed!\n\n");
	}	
	
	printf("\n *********** End Of Main function ************* \n");fflush(stdout);
	ITK_exit_module(TRUE);
	return ITK_ok;
}


