/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:tm_altoz.c
*
* Description		: > This Utility is to do unit testing of functions .
* Module  		        
* Since		    :    

* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 16/06/2022   	Sanjoy Mondal			    Initial Code

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/aom_prop.h>
#include <ae/dataset.h>

//Ujjawal - (For Global Variables)
FILE 		*output 			= NULL;
FILE 		*incremental_Creo 	= NULL;
FILE 		*incremental_Catia 	= NULL;
const char *revision_Order[] = {"NR", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a1", "b1", "c1", "d1", "e1", "f1", "g1", "h1", "i1", "j1", "k1", "l1", "m1", "n1", "o1", "p1", "q1", "r1", "s1", "t1", "u1", "v1", "w1", "x1", "y1", "z1", "a2", "b2", "c2", "d2", "e2", "f2", "g2", "h2", "i2", "j2", "k2", "l2", "m2", "n2", "o2", "p2", "q2", "r2", "s2", "t2", "u2", "v2", "w2", "x2", "y2", "z2", "a3", "b3", "c3", "d3", "e3", "f3", "g3", "h3", "i3", "j3", "k3", "l3", "m3", "n3", "o3", "p3", "q3", "r3", "s3", "t3", "u3", "v3", "w3", "x3", "y3", "z3", "a4", "b4", "c4", "d4", "e4", "f4", "g4", "h4", "i4", "j4", "k4", "l4", "m4", "n4", "o4", "p4", "q4", "r4", "s4", "t4", "u4", "v4", "w4", "x4", "y4", "z4", "a5", "b5", "c5", "d5", "e5", "f5", "g5", "h5", "i5", "j5", "k5", "l5", "m5", "n5", "o5", "p5", "q5", "r5", "s5", "t5", "u5", "v5", "w5", "x5", "y5", "z5", "a6", "b6", "c6", "d6", "e6", "f6", "g6", "h6", "i6", "j6", "k6", "l6", "m6", "n6", "o6", "p6", "q6", "r6", "s6", "t6", "u6", "v6", "w6", "x6", "y6", "z6", "a7", "b7", "c7", "d7", "e7", "f7", "g7", "h7", "i7", "j7", "k7", "l7", "m7", "n7", "o7", "p7", "q7", "r7", "s7", "t7", "u7", "v7", "w7", "x7", "y7", "z7", "a8", "b8", "c8", "d8", "e8", "f8", "g8", "h8", "i8", "j8", "k8", "l8", "m8", "n8", "o8", "p8", "q8", "r8", "s8", "t8", "u8", "v8", "w8", "x8", "y8", "z8", "a9", "b9", "c9", "d9", "e9", "f9", "g9", "h9", "i9", "j9", "k9", "l9", "m9", "n9", "o9", "p9", "q9", "r9", "s9", "t9", "u9", "v9", "w9", "x9", "y9", "z9"};
const int revision_length = 260;

#define MAX_LINE_LEN 10024
#define Debug TRUE
#define ITK_CALL(X)  	\
		if(Debug) \
		{ \
			printf(#X); 	\
		} \
		fflush(NULL); 	\
		status=X;  \
		if (status != ITK_ok )  \
		{ \
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
 \
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails); 	\
			for( index=0; index<n_ifails; index++) 	\
			{  \
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}  \
			return status; 	\
		}  \
		else \
		{ \
			if(Debug) 	\
			printf("\tSUCCESS\n");				\
		} \

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

int ITK_user_main(int argc, char* argv[])
{
	
	
	int ifail = ITK_ok;

	char			Data[100]					= "";
	
	char 			*test						= (char*)MEM_alloc(sizeof(char) * 50);
	char			outputFile[200]				= "";
	
	ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
	
	
	printf("\n SAN:updateVf: *********** Start Of Main function ************* \n");fflush(stdout);	
	
	if(ITK_auto_login() == ITK_ok)	
	{
		/***** Start Variable Declarations************/
		ifail = ITK_ok;
		tag_t user_tag = NULLTAG;
		char* username = NULL;		
		int ii = 0;
		int n_children = 0;		
		char *filepath = ITK_ask_cli_argument("-f=");		
		FILE * fp = NULL;

		char		*sep				= "_";
		int get_latest_rev(char*,char*,char*,char*,char*);

		/***** End Variable Declarations************/
		
		ITK_set_journalling( TRUE );
		printf("\nSAN:updateVf: Login successfull.\n");fflush(stdout);			
		
		POM_get_user(&username,&user_tag);
		printf("\nSAN:Session User Name[%s]\n",username);fflush(stdout);
		
		printf("\nSAN:Input Parameters:Input File:[%s]\n",filepath);fflush(stdout);
		
		/*Query the Parent - Architecture Module Revision */
		//int moduleIdCnt = 0;
		//char** moduleIdList = NULL;
		//int moduleRevCnt = 0;
		//char** moduleRevList = NULL;
		//int moduleVfCnt = 0;
		//char** moduleVfList = NULL;

		time_t 	now;
		struct 	tm when;		
		time(&now);
		when = *localtime(&now);
		
		strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
		sprintf(outputFile,"%s_output.csv",Data);
				
		//if(tc_strlen(stripBlanks(parttype)) == 0)
		//{
		//	print_requirement();
		//	return -1;
		//}		
		
		output = fopen(outputFile,"a+");
		if (output == NULL)
		{
			printf("ERROR: Cannot open File\n");
			return -1;
		}
		else
		{
			fprintf(output,"TCE_Part_Number,TCE_Rev,TCE_Seq,TCUA_Part_Number,TCUA_Rev,TCUA_Seq,UA_Create_Date,UA_Last_Update,UA_Part_Type,UA_Part_Platform,UA_Module,UA_Module_Address,UA_Module_Group,UA_Module_Name,UA_Module_Type,UA_Design_Group,UA_Project_Code,TCE_Design_Group,Type,Status\n");
			printf("outputFile File opened successfully.\n");
		}

		incremental_Creo = fopen("Incremental_CREO.txt","w");
		if (incremental_Creo == NULL)
		{
			printf("ERROR: Cannot open File\n");
			return -1;
		}
		else
		{
				printf("incremental_Creo File opened successfully.\n");
		}

		incremental_Catia = fopen("Incremental_CATIA.txt","w");
		if (incremental_Catia == NULL)
		{
			printf("ERROR: Cannot open File\n");
			return -1;
		}
		else
		{
				printf("incremental_Catia File opened successfully.\n");
		}
			
		//fprintf(output,"%s\n",test);
		//MEM_free(test);

		//Open file to read input.

		fp = fopen(filepath, "r");		

		if(fp==NULL)
		{
			printf("\nCould not open the file %s. Kindly check.\n",filepath);fflush(stdout);
		}
		else
		{
			char buffer[MAX_LINE_LEN] ="";			
			int k = 0;
			
			while(fgets(buffer, MAX_LINE_LEN,fp)!= NULL)
			{
				char* moduleId = NULL;
				char* moduleRev = NULL;
				char* moduleSeq = NULL;
				char* moduletype = NULL;
				char* dsgnGrp = NULL;
				moduleId = strtok(buffer,";");
				moduleRev =strtok(NULL,";");
				moduleSeq =strtok(NULL,";");
				dsgnGrp =strtok(NULL,";");
				moduletype =strtok(NULL,";");						
								
				printf("\n%s;%s====>%s <%s> [%s]\n",moduleId,moduleRev,moduleSeq,moduletype,dsgnGrp);fflush(stdout);

				//ifail = read_value_from_file(Filename);
				
				//Calling function to get latest details.

				ifail = get_latest_rev(moduleId,moduleRev,moduleSeq,moduletype,dsgnGrp);
				
				tag_t ArcModRevTag = NULLTAG;				
				
			}			
			
		}		

	}
	else
	{
		printf("\nLogin Failed!\n\n");
	}	
	
	printf("\n *********** End Of Main function ************* \n");fflush(stdout);
	ITK_exit_module(TRUE);
	return ITK_ok;
}

//Ujjawal

int get_latest_rev(char* moduleId, char* moduleRev, char* moduleSeq, char* moduletype, char* dsgnGrp)
{
	int				ifail 						= ITK_ok;
	int				z 							= 0;	
	tag_t			item_tag 					= NULLTAG;
	tag_t			rev_tag						= NULLTAG;
	char 			*rev_id						= NULL;
	char 			*obj_type					= NULL;
	char 			*seq_id 					= NULL;
	char 			*obj_id						= NULL;
	char 			*cre_date 					= NULL;
	char 			*lastmodified_date			= NULL;
	char *t5_PartType = NULL;
	char *t5_PartPlatform = NULL;
	char *t5_Module = NULL;
	char *t5_ModuleAddress = NULL;
	char *t5_Module_Group = NULL;
	char *t5_ModuleName = NULL;
	char *t5_ModuleType = NULL;
	char *t5_DesignGrp = NULL;
	char *t5_ProjectCode = NULL;

	//query logic
	tag_t   qryTag		= NULLTAG;
	int     n_entry		= 2;
	int     rsltCount	= 0;
	char    *qry_entry[2]  = {"Item ID", "Release Status"};
	tag_t   *revTag   = NULLTAG;
	tag_t   folder_tag   = NULLTAG;
	char    **qry_values2     =  (char **) MEM_alloc(50 * sizeof(char *));
	char 	*test2 				= (char*)MEM_alloc(sizeof(char) * 500);
	char	*final2				= (char*)MEM_alloc(sizeof(char) * 500);
	char* actRev = NULL;
	char* actSeq = NULL;
	int r = 0;
	int rpl = 0;

	char* highRev = (char*)MEM_alloc(sizeof(char) * 20);
	char* highSeq = (char*)MEM_alloc(sizeof(char) * 20);
	int highestPos = 0;
	int highRevPos = 0;
	int actRevPos = 0;
	
	if(QRY_find2("Item Revision...", &qryTag));
		if (qryTag)
		{
			//printf("\n CREVali:Found Query Latest Item Revision... \n");fflush(stdout);
		}
		else
		{
			//printf("\n CREVali:Not Found Query Latest Item Revision... \n");fflush(stdout);
		}

		//printf("\n Inside function get_latest_rev(): Incoming moduleID : %s\n",moduleId);fflush(stdout);

		qry_values2[0] = moduleId;
		qry_values2[1] = "T5_LcsErcRlzd";

		/*if(moduletype != NULL){
			if(tc_strcmp(moduletype,"CREO")!=0){
				moduletype = "CATIA";
			}
		}
		else{
			moduletype = "CATIA";
		}*/
		if(moduletype == NULL){
			moduletype = "CATIA";
		}
		else if(tc_strcmp(moduletype, "")==0)
		{
			moduletype = "CATIA";
		}

		if(QRY_execute(qryTag, 2, qry_entry, qry_values2, &rsltCount, &revTag));
		
		//printf(" \n CREVali:rsltCount:%d:", rsltCount); fflush(stdout);
		
		if (rsltCount>0)
		{
			ifail = AOM_UIF_ask_value (revTag[0], "item_revision_id", &rev_id);
			printf("\n item_revision_id is:%s",rev_id); fflush(stdout);
			highRev = strtok(rev_id,";");
			highSeq = strtok(NULL,";");
			highestPos = 0;

			for (r = 0; r < revision_length; r++) 
			{     
				if (strcmp(highRev, revision_Order[r]) == 0) 
				{
					highRevPos = r;
					break;
				}   
			}

			for (z=1;z<rsltCount;z++)
			{
				ifail = AOM_UIF_ask_value (revTag[z], "item_revision_id", &rev_id);
				printf("\n item_revision_id is:%s",rev_id); fflush(stdout);
				actRev = strtok(rev_id,";");
				actSeq =strtok(NULL,";");

				for (r = 0; r < revision_length; r++) 
				{     
					if (strcmp(actRev, revision_Order[r]) == 0) 
					{
						actRevPos = r;
						break;
					}   
				}

				if(tc_strcmp(highRev, "NR")==0 && tc_strcmp(actRev, "NR")!=0)
				{
					//This is high
					tc_strcpy(highRev, rev_id);
					tc_strcpy(highSeq, highSeq);
					highestPos = z;
					highRevPos = actRevPos;
				}
				else if(tc_strcmp(highRev, "NR")!=0 && tc_strcmp(actRev, "NR")==0)
				{
					//Previous Value is Highest
					continue;
				}
				//else if(tc_strcmp(highRev, actRev) > 0)
				else if(highRevPos > actRevPos)
				{
					//Previous Value is Highest
					continue;
				}
				else
				{
					tc_strcpy(highRev, rev_id);
					tc_strcpy(highSeq, highSeq);
					highestPos = z;
					highRevPos = actRevPos;
				}
			}

			//for (z=0;z<rsltCount;z++)
			//{
				ifail = AOM_ask_value_string (revTag[highestPos], "item_id", &obj_id);
				//printf("\n object_string is:::%s",obj_id);

				ifail = AOM_UIF_ask_value (revTag[highestPos], "item_revision_id", &rev_id);
				//printf("\n item_revision_id is:%s",rev_id);

				actRev = strtok(rev_id,";");
				actSeq =strtok(NULL,";");

				ifail = AOM_UIF_ask_value (revTag[highestPos], "t5_PartType", &t5_PartType);
				ifail = AOM_UIF_ask_value (revTag[highestPos], "t5_PartPlatform", &t5_PartPlatform);
				for (rpl = 0; rpl < strlen(t5_PartPlatform); rpl++)
				{
					if ( t5_PartPlatform[rpl] == '\n' || t5_PartPlatform[rpl] == '\r' || t5_PartPlatform[rpl] == ',')
						t5_PartPlatform[rpl] = '\0';
				}
				ifail = AOM_UIF_ask_value (revTag[highestPos], "t5_Module", &t5_Module);
				for (rpl = 0; rpl < strlen(t5_Module); rpl++)
				{
					if ( t5_Module[rpl] == '\n' || t5_Module[rpl] == '\r' || t5_Module[rpl] == ',')
						t5_Module[rpl] = '\0';
				}
				ifail = AOM_UIF_ask_value (revTag[highestPos], "t5_ModuleAddress", &t5_ModuleAddress);
				for (rpl = 0; rpl < strlen(t5_ModuleAddress); rpl++)
				{
					if ( t5_ModuleAddress[rpl] == '\n' || t5_ModuleAddress[rpl] == '\r' || t5_ModuleAddress[rpl] == ',')
						t5_ModuleAddress[rpl] = '\0';
				}
				ifail = AOM_UIF_ask_value (revTag[highestPos], "t5_Module_Group", &t5_Module_Group);
				for (rpl = 0; rpl < strlen(t5_Module_Group); rpl++)
				{
					if ( t5_Module_Group[rpl] == '\n' || t5_Module_Group[rpl] == '\r' || t5_Module_Group[rpl] == ',')
						t5_Module_Group[rpl] = '\0';
				}
				ifail = AOM_UIF_ask_value (revTag[highestPos], "t5_ModuleName", &t5_ModuleName);
				for (rpl = 0; rpl < strlen(t5_ModuleName); rpl++)
				{
					if ( t5_ModuleName[rpl] == '\n' || t5_ModuleName[rpl] == '\r' || t5_ModuleName[rpl] == ',')
						t5_ModuleName[rpl] = '\0';
				}
				ifail = AOM_UIF_ask_value (revTag[highestPos], "t5_ModuleType", &t5_ModuleType);
				for (rpl = 0; rpl < strlen(t5_ModuleType); rpl++)
				{
					if ( t5_ModuleType[rpl] == '\n' || t5_ModuleType[rpl] == '\r' || t5_ModuleType[rpl] == ',')
						t5_ModuleType[rpl] = '\0';
				}
				ifail = AOM_UIF_ask_value (revTag[highestPos], "t5_DesignGrp", &t5_DesignGrp);
				ifail = AOM_UIF_ask_value (revTag[highestPos], "t5_ProjectCode", &t5_ProjectCode);

				//printf("\n obj_type is:::%s",obj_type);

				ifail = AOM_ask_value_string (revTag[highestPos], "sequence_id", &seq_id);
				//printf("\n seq_id is:::%s",seq_id);

				//Creation Date creation_date
			    ifail = AOM_UIF_ask_value (revTag[highestPos], "creation_date", &cre_date);
				//printf("\n creation_date is:::%s",cre_date);

				//Date Modified last_mod_date 
				ifail = AOM_UIF_ask_value (revTag[highestPos], "last_mod_date", &lastmodified_date);
				//printf("\n last_mod_date is:::%s",lastmodified_date); 

				int CreoFile = 0;
				if(tc_strcmp(moduletype,"CREO")==0)
				{
					int j = 0;
					tag_t relation_type = NULLTAG;
					int n_attchs = 0;
					tag_t* rellist =NULLTAG;
					tag_t dataset = NULLTAG;
					ifail = GRM_find_relation_type("IMAN_specification", & relation_type);
					ifail = GRM_list_secondary_objects_only(revTag[highestPos],relation_type,&n_attchs,&rellist);
					for(j=0;j<n_attchs;j++)
					{
						char *objtype = NULL;
						dataset=rellist[j];
						if( AOM_ask_value_string(dataset,"object_type",&objtype)!=ITK_ok);
						if(tc_strcmp(objtype,"ProAsm")==0 || tc_strcmp(objtype,"ProPrt")==0  || tc_strcmp(objtype,"ProDrw")==0)
						{
							CreoFile = 1;
							break;
						}
					}
				}
			
				tc_strcpy(test2,"");
				tc_strcat(test2,moduleId);
				tc_strcat(test2,",");
				tc_strcat(test2,moduleRev);
				tc_strcat(test2,",");
				tc_strcat(test2,moduleSeq);
				tc_strcat(test2,",");
				tc_strcat(test2,obj_id);
				tc_strcat(test2,",");
				tc_strcat(test2,actRev);
				tc_strcat(test2,",");
				tc_strcat(test2,actSeq);
				tc_strcat(test2,",");
				tc_strcat(test2,cre_date);
				tc_strcat(test2,",");
				tc_strcat(test2,lastmodified_date);
				tc_strcat(test2,",");
				tc_strcat(test2,t5_PartType);
				tc_strcat(test2,",");
				tc_strcat(test2,t5_PartPlatform);
				tc_strcat(test2,",");
				tc_strcat(test2,t5_Module);
				tc_strcat(test2,",");
				tc_strcat(test2,t5_ModuleAddress);
				tc_strcat(test2,",");
				tc_strcat(test2,t5_Module_Group);
				tc_strcat(test2,",");
				tc_strcat(test2,t5_ModuleName);
				tc_strcat(test2,",");
				tc_strcat(test2,t5_ModuleType);
				tc_strcat(test2,",");
				tc_strcat(test2,t5_DesignGrp);
				tc_strcat(test2,",");
				tc_strcat(test2,t5_ProjectCode);
				tc_strcat(test2,",");
				tc_strcat(test2,dsgnGrp);
				tc_strcat(test2,",");
				tc_strcat(test2,moduletype);
				//tc_strcat(test2,"_");
				//tc_strcat(test2,seq_id);
				
				if(tc_strcmp(actRev,moduleRev)==0){
					if(tc_strcmp(moduletype,"CREO")==0 && CreoFile == 0)
					{
						tc_strcat(test2,",Incremental");
						tc_strcpy(final2,test2);
						fprintf(output,"%s\n",final2);
						fprintf(incremental_Creo,"%s\n",moduleId);
					}
					else
					{
						tc_strcat(test2,",Equal");
						tc_strcpy(final2,test2);
						fprintf(output,"%s\n",final2);
					}
				}
				else{
					if(tc_strcmp(actRev, "NR")==0 && tc_strcmp(moduleRev, "NR")!=0)
					{
						tc_strcat(test2,",Incremental");
						tc_strcpy(final2,test2);
						fprintf(output,"%s\n",final2);

						if(tc_strcmp(moduletype,"CREO")==0){
							fprintf(incremental_Creo,"%s\n",moduleId);
						}
						else{
							fprintf(incremental_Catia,"%s\n",moduleId);
						}
					}
					else if(tc_strcmp(actRev, "NR")!=0 && tc_strcmp(moduleRev, "NR")==0)
					{
						tc_strcat(test2,",CVProd_Latest");
						tc_strcpy(final2,test2);
						fprintf(output,"%s\n",final2);

						printf("\nLatest in CVProd. No Need for incremental migration TCE to TCUA : %s",moduleId); fflush(stdout);
					}
					else
					{
						for (r = 0; r < revision_length; r++) 
						{     
							if (strcmp(actRev, revision_Order[r]) == 0) 
							{
								actRevPos = r;
								break;
							}   
						}
						for (r = 0; r < revision_length; r++) 
						{     
							if (strcmp(moduleRev, revision_Order[r]) == 0) 
							{
								highRevPos = r;
								break;
							}   
						}

						//if(tc_strcmp(actRev, moduleRev) > 0)
						if(actRevPos > highRevPos)
						{
							tc_strcat(test2,",CVProd_Latest");
							tc_strcpy(final2,test2);
							fprintf(output,"%s\n",final2);

							printf("\nLatest in CVProd. No Need for incremental migration TCE to TCUA : %s",moduleId); fflush(stdout);
						}
						else
						{
							tc_strcat(test2,",Incremental");
							tc_strcpy(final2,test2);
							fprintf(output,"%s\n",final2);

							if(tc_strcmp(moduletype,"CREO")==0){
								fprintf(incremental_Creo,"%s\n",moduleId);
							}
							else{
								fprintf(incremental_Catia,"%s\n",moduleId);
							}
						}
					}
				}
				
				
			//}
			
		}
		else{
			tc_strcpy(test2,"");
			tc_strcat(test2,moduleId);
			tc_strcat(test2,",");
			tc_strcat(test2,moduleRev);
			tc_strcat(test2,",");
			tc_strcat(test2,moduleSeq);
			tc_strcat(test2,",-,-,-,-,-,-,-,-,-,-,-,-,-,-,");
			tc_strcat(test2,dsgnGrp);
			tc_strcat(test2,",");
			tc_strcat(test2,moduletype);
			tc_strcat(test2,",New");
			tc_strcpy(final2,test2);
			fprintf(output,"%s\n",final2);

			if(tc_strcmp(moduletype,"CREO")==0){
				fprintf(incremental_Creo,"%s\n",moduleId);
			}
			else{
				fprintf(incremental_Catia,"%s\n",moduleId);
			}
		}
		
//		MEM_free(rev_id);
		MEM_free(test2);
		MEM_free(final2);
		
	return ifail;
}



