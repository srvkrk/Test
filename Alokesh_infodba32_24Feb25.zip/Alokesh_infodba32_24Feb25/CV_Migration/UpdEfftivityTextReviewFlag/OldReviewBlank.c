/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
*------------------------------------------------------------------------------
* Filename		: autologin.c
* Description	: This Utility Mainly Used For AutoLogin in Teamcenter
* Module       	:	        
* Since		    :    
* ENVIRONMENT	: C++, ITK
* History       :
*------------------------------------------------------------------------------
*    Date         	   Name						Description of Change
* 30/03/2023   	   Lokendra Aporiya		          For Removing Flag

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_date.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001

const char *revision_Order[] = {"NR", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a1", "b1", "c1", "d1", "e1", "f1", "g1", "h1", "i1", "j1", "k1", "l1", "m1", "n1", "o1", "p1", "q1", "r1", "s1", "t1", "u1", "v1", "w1", "x1", "y1", "z1", "a2", "b2", "c2", "d2", "e2", "f2", "g2", "h2", "i2", "j2", "k2", "l2", "m2", "n2", "o2", "p2", "q2", "r2", "s2", "t2", "u2", "v2", "w2", "x2", "y2", "z2", "a3", "b3", "c3", "d3", "e3", "f3", "g3", "h3", "i3", "j3", "k3", "l3", "m3", "n3", "o3", "p3", "q3", "r3", "s3", "t3", "u3", "v3", "w3", "x3", "y3", "z3", "a4", "b4", "c4", "d4", "e4", "f4", "g4", "h4", "i4", "j4", "k4", "l4", "m4", "n4", "o4", "p4", "q4", "r4", "s4", "t4", "u4", "v4", "w4", "x4", "y4", "z4", "a5", "b5", "c5", "d5", "e5", "f5", "g5", "h5", "i5", "j5", "k5", "l5", "m5", "n5", "o5", "p5", "q5", "r5", "s5", "t5", "u5", "v5", "w5", "x5", "y5", "z5", "a6", "b6", "c6", "d6", "e6", "f6", "g6", "h6", "i6", "j6", "k6", "l6", "m6", "n6", "o6", "p6", "q6", "r6", "s6", "t6", "u6", "v6", "w6", "x6", "y6", "z6", "a7", "b7", "c7", "d7", "e7", "f7", "g7", "h7", "i7", "j7", "k7", "l7", "m7", "n7", "o7", "p7", "q7", "r7", "s7", "t7", "u7", "v7", "w7", "x7", "y7", "z7", "a8", "b8", "c8", "d8", "e8", "f8", "g8", "h8", "i8", "j8", "k8", "l8", "m8", "n8", "o8", "p8", "q8", "r8", "s8", "t8", "u8", "v8", "w8", "x8", "y8", "z8", "a9", "b9", "c9", "d9", "e9", "f9", "g9", "h9", "i9", "j9", "k9", "l9", "m9", "n9", "o9", "p9", "q9", "r9", "s9", "t9", "u9", "v9", "w9", "x9", "y9", "z9"};
const int revision_length = 260;

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);fflush(stdout);
		  exit(0);
		}

		return iFail;
}

int ITK_user_main(int argc, char* argv[])
{
	    int ifail = 0;
	    char* cError = NULL;
		char* username = NULL;
		tag_t tuser = NULLTAG;
		ifail = ITK_auto_login();
		printf("\nReturn Value is : %d", ifail);fflush(stdout);
		
		int n_entries = 1;
		int i;
		tag_t tItemobj = NULLTAG;
		int rsltCount = 0;
		tag_t* revTag = NULLTAG;

		char *PartID = NULL;
		char *PartSequenceID = NULL;
		char *part_type = NULL;
		char *Description = NULL;
		char *object_type = NULL;
		char *Part_ProjID = NULL;
		char *Part_DesgnGrp = NULL;
		char *Revision = NULL;
		tag_t DataSet = NULLTAG;
		tag_t RevObjTag = NULLTAG;
		char *inputfile=NULL;
		
		int Part_Stat_Cnt = 0;
		tag_t *Part_Stat_Lst = NULLTAG;
		int k=0;
		int countRev =0;
		int countRlz =0;
		char *Part_Rlz_Stat = NULL;

		char* highRev = (char*)MEM_alloc(sizeof(char) * 20);
		char* highSeq = (char*)MEM_alloc(sizeof(char) * 20);
		int highestPos = 0;
		int highRevPos = 0;
		int actRevPos = 0;
		char 			*rev_id						= NULL;
		int r =0;
		int z=0;
		char* actRev = NULL;
		char* actSeq = NULL;
		tag_t item_rev_tag = NULLTAG;
		int status_count=0;
		tag_t* relStatus_list;
		int ss = 0;
		char* Rel_Status = NULL;
		date_t Creation_date_t;
		char* CreationDt= NULL;
		logical date_is_validDR =false;
		date_t DRRelDate_tag;
		
		inputfile = ITK_ask_cli_argument("-i=");
		FILE *fp;
		fp=fopen(inputfile,"r");

		//FILE *fp1;
		//fp1 = fopen("Process.txt","w");
		
		char *cEntries[2]  = {"Item ID"};
		char *inputline = NULL;
		
		char **cValues = (char **) MEM_alloc(50 * sizeof(char *));
				
		if (ifail == ITK_ok)
		{
			printf("\nTeamcenter Login Success...");fflush(stdout);
			POM_get_user(&username, &tuser);
			printf("\nUsername = %s", username);fflush(stdout);
		}
		else
		{
			EMH_ask_error_text(ifail, &cError);
			printf("\nError is : %s", cError);fflush(stdout);
		}
		if (cError)
		{
			MEM_free(cError);
		}
		if (username)
		{
			MEM_free(username);
		}
		
		if(fp!=NULL)
		{
			inputline=(char *) MEM_alloc(1000);
			while(fgets(inputline,1000,fp)!=NULL)
			{
				printf("\n\n Input Part: %s",inputline); fflush(stdout);

				char *partNoIP = NULL;
				partNoIP = (char *)MEM_alloc(150);
				tc_strcpy(partNoIP, "");
				partNoIP = strtok(inputline,"^");
				printf("-----------> :%s \n",partNoIP);fflush(stdout);
				cValues[0] = partNoIP;

				ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
				ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &rsltCount, &revTag));
				printf("\nNo of item returned ---------------------- %d\n",rsltCount);fflush(stdout);
				if(rsltCount>0)
				{
					ifail = AOM_UIF_ask_value (revTag[0], "item_revision_id", &rev_id);
					printf("\n item_revision_id is:%s",rev_id); fflush(stdout);
					highRev = strtok(rev_id,";");
					highSeq = strtok(NULL,";");
					highestPos = 0;

					for (r = 0; r < revision_length; r++) 
					{     
						if (strcmp(highRev, revision_Order[r]) == 0) 
						{
							highRevPos = r;
							break;
						}   
					}

					for (z=1;z<rsltCount;z++)
					{
						ifail = AOM_UIF_ask_value (revTag[z], "item_revision_id", &rev_id);
						printf("\n item_revision_id is:%s",rev_id); fflush(stdout);
						actRev = strtok(rev_id,";");
						actSeq =strtok(NULL,";");

						for (r = 0; r < revision_length; r++) 
						{     
							if (strcmp(actRev, revision_Order[r]) == 0) 
							{
								actRevPos = r;
								break;
							}   
						}

						if(tc_strcmp(highRev, "NR")==0 && tc_strcmp(actRev, "NR")!=0)
						{
							tc_strcpy(highRev, actRev);
							tc_strcpy(highSeq, actSeq);
							highestPos = z;
							highRevPos = actRevPos;
						}
						else if(tc_strcmp(highRev, "NR")!=0 && tc_strcmp(actRev, "NR")==0)
						{
							continue;
						}
						else if(tc_strcmp(highRev, actRev)==0)
						{
							if(tc_strcmp(highSeq, actSeq) < 0)
							{
								tc_strcpy(highRev, actRev);
								tc_strcpy(highSeq, actSeq);
								highestPos = z;
								highRevPos = actRevPos;
							}
						}
						else if(highRevPos > actRevPos)
						{
							continue;
						}
						else
						{
							tc_strcpy(highRev, actRev);
							tc_strcpy(highSeq, actSeq);
							highestPos = z;
							highRevPos = actRevPos;
						}
					}

					//Highest Data -> revTag[highestPos]
					for (z=0;z<rsltCount;z++)
					{
						if (z == highestPos)
						{
							item_rev_tag = revTag[highestPos];
							ifail = AOM_UIF_ask_value (item_rev_tag, "item_revision_id", &rev_id);
							printf("\n item_revision_id is:%s",rev_id); fflush(stdout);

							if(WSOM_ask_release_status_list(item_rev_tag, &status_count, &relStatus_list) != ITK_ok);
							if (status_count > 0)
							{
								for(ss=0; ss<status_count ; ss++)
								{
									if(AOM_ask_value_string(relStatus_list[ss],"object_name",&Rel_Status)!=ITK_ok);
									if (tc_strcmp(Rel_Status,"T5_LcsReview")==0)
									{
										char *eff_text = NULL;
										if(AOM_ask_value_string(relStatus_list[ss],"effectivity_text",&eff_text)!=ITK_ok);
										if (eff_text == NULL)
										{
											ITK_CALL(AOM_ask_value_date(item_rev_tag,"creation_date",&Creation_date_t)!= ITK_ok);
											ITK_CALL(ITK_date_to_string(Creation_date_t, &CreationDt)!=ITK_ok);
											printf("\ncreation_date: %s ",CreationDt);fflush(stdout);

											ITK_CALL (DATE_string_to_date_t(CreationDt, &date_is_validDR, &DRRelDate_tag));
											printf("\t date_is_validDR: %d ", date_is_validDR);fflush(stdout);
											if (date_is_validDR > 0)
											{
												tag_t attr_idDR = NULLTAG;
												printf("\n\n\t\t Updating attribute 'Date Released' on flag [%s]....",Rel_Status);fflush(stdout);
												ITK_CALL (POM_attr_id_of_attr("date_released", "Design_0_Revision_alt", &attr_idDR));
												ITK_CALL(AOM_lock(relStatus_list[ss]));
												ITK_CALL (POM_set_attr_date(1, &relStatus_list[ss], attr_idDR, DRRelDate_tag));
												ITK_CALL (AOM_save_without_extensions(relStatus_list[ss]));
												ITK_CALL(AOM_refresh(relStatus_list[ss],1));
												ITK_CALL(AOM_unlock(relStatus_list[ss]));

												date_t test_date_1;
												date_t test_date_2;
												date_t *start_end_date = NULL;
												tag_t eff_d = NULLTAG;
												ITK_CALL(ITK_string_to_date(CreationDt, &test_date_1));
												ITK_CALL(ITK_string_to_date("31-Dec-9999 23:59", &test_date_2 ));

												start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
												start_end_date[0] = test_date_1;
												start_end_date[1] = test_date_2;

												ITK_CALL(WSOM_status_clear_effectivities(relStatus_list[ss]));
												ITK_CALL(WSOM_effectivity_create_with_dates(relStatus_list[ss], NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
												ITK_CALL(AOM_refresh(eff_d,TRUE));
												ITK_CALL(AOM_save_without_extensions(eff_d));
												ITK_CALL(AOM_refresh(eff_d,FALSE));

												printf("**********************************%s,%s\n", partNoIP,rev_id); fflush(stdout);
												//fprintf(fp1, "%s,%s\n", partNoIP,rev_id); fflush(fp1);
											}
										}
										else
										{
											printf("\n---- effectivity_text Already Present----- %s",eff_text); fflush(stdout);
										}
									}
								}
							}
						}
						else
						{
							item_rev_tag = revTag[z];
							ifail = AOM_UIF_ask_value (item_rev_tag, "item_revision_id", &rev_id);
							printf("\n item_revision_id is:%s",rev_id); fflush(stdout);

							if(WSOM_ask_release_status_list(item_rev_tag, &status_count, &relStatus_list) != ITK_ok);
							if (status_count > 0)
							{
								for(ss=0; ss<status_count ; ss++)
								{
									if(AOM_ask_value_string(relStatus_list[ss],"object_name",&Rel_Status)!=ITK_ok);
									if (tc_strcmp(Rel_Status,"T5_LcsReview")==0)
									{
										char *eff_text = NULL;
										int update_tag = 0;
										if(AOM_ask_value_string(relStatus_list[ss],"effectivity_text",&eff_text)!=ITK_ok);
										if (eff_text != NULL)
										{
											if(tc_strstr(eff_text, "9999") != NULL)
											{
												update_tag = 1;
											}
										}

										if (eff_text == NULL || update_tag == 1)
										{

											ITK_CALL(AOM_ask_value_date(item_rev_tag,"creation_date",&Creation_date_t)!= ITK_ok);
											ITK_CALL(ITK_date_to_string(Creation_date_t, &CreationDt)!=ITK_ok);
											printf("\ncreation_date: %s ",CreationDt);fflush(stdout);

											ITK_CALL (DATE_string_to_date_t(CreationDt, &date_is_validDR, &DRRelDate_tag));
											printf("\t date_is_validDR: %d ", date_is_validDR);fflush(stdout);
											if (date_is_validDR > 0)
											{
												tag_t attr_idDR = NULLTAG;
												printf("\n\n\t\t Updating attribute 'Date Released' on flag [%s]....",Rel_Status);fflush(stdout);
												ITK_CALL (POM_attr_id_of_attr("date_released", "Design_0_Revision_alt", &attr_idDR));
												ITK_CALL(AOM_lock(relStatus_list[ss]));
												ITK_CALL (POM_set_attr_date(1, &relStatus_list[ss], attr_idDR, DRRelDate_tag));
												ITK_CALL (AOM_save_without_extensions(relStatus_list[ss]));
												ITK_CALL(AOM_refresh(relStatus_list[ss],1));
												ITK_CALL(AOM_unlock(relStatus_list[ss]));

												date_t test_date_1;
												date_t test_date_2;
												date_t *start_end_date = NULL;
												tag_t eff_d = NULLTAG;
												ITK_CALL(ITK_string_to_date(CreationDt, &test_date_1));
												ITK_CALL(ITK_string_to_date(CreationDt, &test_date_2 ));

												start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
												start_end_date[0] = test_date_1;
												start_end_date[1] = test_date_2;

												ITK_CALL(WSOM_status_clear_effectivities(relStatus_list[ss]));
												ITK_CALL(WSOM_effectivity_create_with_dates(relStatus_list[ss], NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
												ITK_CALL(AOM_refresh(eff_d,TRUE));
												ITK_CALL(AOM_save_without_extensions(eff_d));
												ITK_CALL(AOM_refresh(eff_d,FALSE));

												printf("^^^^^^^^^^^^^^^^^^^^^^^^^^%s,%s\n", partNoIP,rev_id); fflush(stdout);
											}
										}
										else
										{
											printf("\n---- effectivity_text Already Present----- %s",eff_text); fflush(stdout);
										}
									}
								}
							}
						}
					}

					int countRev = 0;
					int countRlz = 0;
					tag_t RevObjTag = NULLTAG;
					int Part_Stat_Cnt = 0;
					tag_t *Part_Stat_Lst = NULLTAG;
					char *Part_Rlz_Stat = NULL;

					for(i=0;i<rsltCount;i++)
					{
						RevObjTag = revTag[i];
						countRev = 0;
						countRlz = 0;
						ITK_CALL(AOM_ask_value_string(RevObjTag,"item_id",&PartID));
						ITK_CALL(AOM_ask_value_string(RevObjTag,"item_revision_id",&Revision));
						printf("\nPartID :%s\n",PartID);fflush(stdout);
						printf("\nRevision :%s\n",Revision);fflush(stdout);
						
						ITK_CALL(WSOM_ask_release_status_list(RevObjTag,&Part_Stat_Cnt,&Part_Stat_Lst));
						printf("\nPart_Stat_Cnt = %d\n",Part_Stat_Cnt);fflush(stdout);

						for(k=0;k<Part_Stat_Cnt;k++)
						{
							AOM_ask_name(Part_Stat_Lst[k], &Part_Rlz_Stat);
							printf("\n Part`s Release status is : %s\n",Part_Rlz_Stat);fflush(stdout);
							if (tc_strcmp(Part_Rlz_Stat,"T5_LcsReview")==0)
							{
								countRev++;
							}
							if (tc_strcmp(Part_Rlz_Stat,"T5_LcsErcRlzd")==0 )
							{
								countRlz++;
							}
						}
						
						if(countRev > 1)
						{
							printf("Error ------------ %s,%s,MultiReview,%d,%d\n", PartID,Revision,countRev,countRlz ); fflush(stdout);
						}
						else if (countRlz > 1)
						{
							printf("Error ------------ %s,%s,MultiRelease,%d,%d\n", PartID,Revision,countRev,countRlz ); fflush(stdout);
						}
						else if(countRev > 0 && countRlz > 0)
						{
							printf("Deleteing ---------- %s,%s\n", PartID,Revision); fflush(stdout);

							tag_t PrtClass_id1 = NULLTAG;
							char *PartClass_name1 = NULL;
							tag_t PrtStatLst_AttrID1 = NULLTAG;
							int st_count1 = 0;	
							tag_t *status_list1 = NULLTAG;
							logical	log1;
							int PrtStatLst_Length1 = 0;
							tag_t *PrtStatLst_Attr_tag1 = NULLTAG;
							logical	*is_it_null1 = NULL;
							logical	*is_it_empty1 = NULL;
							int count1 = 0;
							char *PrtRlz_Status1 = NULL;

							printf("\n In Remove_Multiple_Status Function \n");fflush(stdout);
							ITK_CALL(POM_class_of_instance(RevObjTag,&PrtClass_id1)); 
							ITK_CALL(POM_name_of_class(PrtClass_id1,&PartClass_name1));
							printf("\n Part Class Name is : %s\n",PartClass_name1);fflush(stdout);
							ITK_CALL(POM_attr_id_of_attr("release_status_list",PartClass_name1,&PrtStatLst_AttrID1));
							ITK_CALL(WSOM_ask_release_status_list(RevObjTag,&st_count1,&status_list1));
							printf("\n st_count1 is : %d \n",st_count1);fflush(stdout);
							ITK_CALL(POM_unload_instances(1,&RevObjTag));
							ITK_CALL(POM_load_instances(1,&RevObjTag,PrtClass_id1,1));
							ITK_CALL(POM_is_loaded(RevObjTag,&log1));
							if(log1 == 1)
							{
								printf(" Load Success\n " );fflush(stdout);
							}
							else
							{
								printf(" Load Failure\n"  );fflush(stdout);
							}
							ITK_CALL( POM_length_of_attr(RevObjTag, PrtStatLst_AttrID1, &PrtStatLst_Length1) );
							ITK_CALL( POM_ask_attr_tags(RevObjTag, PrtStatLst_AttrID1, 0, PrtStatLst_Length1, &PrtStatLst_Attr_tag1, &is_it_null1, &is_it_empty1 ));
							for(count1=0; count1<PrtStatLst_Length1;count1++)
							{
								AOM_ask_name(PrtStatLst_Attr_tag1[count1], &PrtRlz_Status1);
								printf("\n Release status is : %s",PrtRlz_Status1);fflush(stdout);					
								if((tc_strcmp(PrtRlz_Status1,"T5_LcsReview")==0))	
								{
									ITK_CALL(POM_remove_from_attr(1,&RevObjTag,PrtStatLst_AttrID1,count1,1));
									ITK_CALL(POM_save_instances(1,&RevObjTag,1));
									ITK_CALL(POM_refresh_instances(1,&RevObjTag,PrtClass_id1,2));
									ITK_CALL(AOM_lock(RevObjTag));
									ITK_CALL(AOM_save_without_extensions(RevObjTag));
									ITK_CALL(AOM_refresh(RevObjTag,1));
									ITK_CALL(AOM_unlock(RevObjTag));
									printf("\n Release Status Removed Successfully \n");fflush(stdout);
									break;
								}
								
							}
						}
					}
				}
				
			}
		}

		//fclose(fp1);
		fclose(fp);

		ifail = ITK_exit_module(TRUE);
		printf("\nReturn Value is : %d", ifail);
		if (ifail == ITK_ok)
		{
			printf("\nTeamcenter Logout Success...");fflush(stdout);
		}
		else
		{
			EMH_ask_error_text(ifail, &cError);
			printf("\nError is : %s", cError);fflush(stdout);
		}
		
	
	return ITK_ok;
}

