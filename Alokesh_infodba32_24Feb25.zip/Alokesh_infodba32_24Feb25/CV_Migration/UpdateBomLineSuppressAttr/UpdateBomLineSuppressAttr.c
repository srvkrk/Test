/*=============================================================================
                Copyright (c) 2003-2005 UGS Corporation
                   Unpublished - All Rights Reserved
===============================================================================
File description:
    An example program to show listing a bill of materials using the BOM module
*/
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <tccore/releasestatus.h>
#include <tccore/aom_prop.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <tccore/tctype.h>
#include <tccore/aom.h>
#include <ctype.h>
#define Debug TRUE
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

/* this sequence is so common */
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

//static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;

static void initialise (void);
//static void initialise_attribute (char *name,  int *attribute);
static void Get_unpack_bom (tag_t bom_line_tag, tag_t line1, int depth);
static void print_bom (tag_t line, tag_t line1, int depth , tag_t ParentBomLine);
char* subString (char* mainStringf ,int fromCharf,int toCharf);

tag_t window = NULLTAG;
FILE* fp=NULL;
char* inputfile=NULL;
tag_t ParentBomLine = NULLTAG;
int Parentlevel = 0;
int ParentFlag = 0;

extern int ITK_user_main(int argc, char ** argv )
{
    int ifail=0;
    int h=0;
    int t=0;
    int org_seq_id_int = 0;
	int currseq=0;
	int referencenumberfound=0;
	int kk=0;
	int *number_found;

    char *req_item = NULL;
    char *seq_id = NULL;
    char *seq_idTmp = NULL;
    char *seq_idTmp2 = NULL;
    char *req_key = NULL;
	char *vol_name=NULL;
	char *nod_name=NULL;
	char *revisionID = NULL;
	//char *itemtype = NULL;
	char* username = NULL;

	tag_t *list_of_WSO_tags=NULLTAG;

	tag_t rev = NULLTAG;
	tag_t vol=NULLTAG;
	tag_t user_tag = NULLTAG;
	tag_t ParentBomLineTag = NULLTAG;

	WSO_search_criteria_t  	criteria;
	tag_t rev_zero_dset_tag;

    tag_t window2, rule, item_tag = null_tag, top_line;
	char refname[AE_reference_size_c + 1];
	char pathnamee[SS_MAXPATHLEN + 1];
	char orig_name[IMF_filename_size_c + 1];
	tag_t refobject = NULLTAG;
	AE_reference_type_t reftype;

    (void)argc;
    (void)argv;

//	if( ITK_init_module("loader" ,"loader7","dba")!=ITK_ok) ;
  ifail = ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
  CHECK_FAIL;
  ifail = ITK_auto_login();
  CHECK_FAIL;
//  ITK_CALL(ITK_set_journalling( TRUE ));

	printf("\n............Inside program to update Suppressed attribute on BOM............");fflush(stdout);

	initialise();

    req_item = ITK_ask_cli_argument("-i=");
	revisionID = ITK_ask_cli_argument("-j=");
	inputfile = ITK_ask_cli_argument("-f=");
 	//seq_id = ITK_ask_cli_argument("-k=");
	//itemtype = ITK_ask_cli_argument("-m=");
	//req_key = ITK_ask_cli_argument("-key=");

	seq_idTmp=(char *) MEM_alloc(5);
	tc_strcpy(seq_idTmp,revisionID);
	seq_idTmp2 = strtok(seq_idTmp,";");
	seq_id = strtok(NULL,";");

	printf("\nInput parameters-- req_item: %s  revisionID: %s  seq_id: %s  inputfile: %s \n",req_item,revisionID,seq_id,inputfile);fflush(stdout);

    if ( req_item && req_key )
    {
        printf("Cannot use both the \"-i\" and \"-key\" options on command line\n");
        exit(0);
    }
    else if ( !req_item && !req_key )
    {
        printf("Must supply the \"-i\" or \"-key\" option on command line\n");
        exit(0);
    }

    ifail = BOM_create_window (&window);
    CHECK_FAIL;
    ifail = CFM_find( "Latest Working", &rule );
    CHECK_FAIL;
    ifail = BOM_set_window_config_rule( window, rule );
    CHECK_FAIL;

	if ( req_item )
	{
		tag_t *tags_found = NULL;
		tag_t *rev1 = NULL;
		int n_tags_found= 0;
		int n_rev= 0;
		int t= 0;
		char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
		char **values = (char **) MEM_alloc(1 * sizeof(char *));
		attrs[0] ="item_id";
		values[0] = (char *)req_item;
		ifail = ITEM_find_items_by_key_attributes(1,(const char **)attrs, (const char **)values, &n_tags_found, &tags_found);
		MEM_free(attrs);
		MEM_free(values);
		CHECK_FAIL;
		if (n_tags_found == 0)
		{
			printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", req_item);
			exit (0);
		}
		else if (n_tags_found > 1)
		{
			MEM_free(tags_found);
			EMH_store_initial_error(EMH_severity_error,ITEM_multiple_items_returned);
			printf ( "More than one items matched with id %s\n", req_item);
			exit (0);
		}
		item_tag = tags_found[0];
		ifail = ITEM_find_revisions(item_tag,revisionID,&n_rev,&rev1);

		if (n_rev == 1)
		{
			rev = rev1[0];
		}
		else
		{
			for(h=0; h<n_rev; h++)
			{
				ifail = AOM_ask_value_int(rev1[h],"sequence_id",&org_seq_id_int);
				CHECK_FAIL;
				currseq = atoi(seq_id);
				printf("\n\t org_seq_id_int: %d",org_seq_id_int);
				printf("\n\t seq_id: %s",seq_id);
				printf("\n\t seq id is1 :%d",currseq);
				//rev = rev1[h];

				if(org_seq_id_int == currseq)
				{
					rev = rev1[h];
					printf("\t.. inside tag assign \n");

					break;
				}
			}
		}

		MEM_free(tags_found);
		// MEM_free(rev);
	}
	else // req_key being used
	{
		tag_t *tags_found = NULL;
		int n_tags_found = 0;
		ifail = ITEM_find_items_by_string(req_key, &n_tags_found, &tags_found);
		if (ifail == ITK_ok)
		{
			if (n_tags_found == 0)
			{
				printf ("ITEM_find_items_by_string returns success,  but didn't find %s\n", req_key);
				exit (0);
			}
			else if (n_tags_found > 1)
			{
				MEM_free(tags_found);
				EMH_store_initial_error(EMH_severity_error,ITEM_multiple_items_returned);
				printf ( "More than one items matched with key %s\n", req_key);
				exit (0);
			}
			else
			{
				item_tag = tags_found[0];
				MEM_free(tags_found);
			}
		}
	}

	if (item_tag == null_tag)
	{
		printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", req_item);
		exit (0);
	}

	ifail = BOM_set_window_top_line (window, null_tag, rev , null_tag, &top_line);
	CHECK_FAIL;

	ifail = BOM_window_show_suppressed ( window );
	CHECK_FAIL;

	ifail = BOM_line_unpack (top_line);
    CHECK_FAIL;

	POM_get_user(&username,&user_tag);
	printf("\n Session User:[%s]\n",username); fflush(stdout);

	Get_unpack_bom (top_line, NULLTAG, 0);
	ifail = BOM_save_window (window);

	ParentFlag = 0;
	print_bom (top_line, NULLTAG, 0 , ParentBomLineTag);

	ifail = BOM_save_window (window);
	printf("\n rrrrrr.......after BOM_save_window  ifail:%d\n",ifail); fflush(stdout);

	ifail = BOM_set_window_pack_all (window, true);    /* the default,  but let's be explicit */
	CHECK_FAIL;
	printf ("================================================\n");

    ITK_exit_module(true);

	return ifail;
}
static void Get_unpack_bom (tag_t bom_line_tag, tag_t line1, int depth)
{
	int ifail;
	int i, no_bom_lines , j , k=0;
	int n_tags_found= 0;
	int iChildItemTag;
	int level0=0;
	int pack_count=0;
	int PartStatusInBom = 0;
	int bl_Suppress = 0;
	int charFlag = 0;
	int ti = 0;
	int tmpStrlen = 0;

	char *name, *sequence_no;
	char *Item_id_par=NULL;
	char *word=NULL;
	//char *BomLine_name=NULL;
	char *Parent_name=NULL;
	char *Parent_Rev=NULL;
	char* inputline = NULL;
	char* inputlineTemp = NULL;
	char* ChildLevel = NULL;
	char* SuppressPart = NULL;
	char* a2 = NULL;
	char* a3 = NULL;
	char* a4 = NULL;
	char* a5 = NULL;
	char* a6 = NULL;
	char* a7 = NULL;
	char* a8 = NULL;
	char* a9 = NULL;
	char* suppressAttr = NULL;
	char* ImmidiateParent = NULL;
	char *p;
	char *tempstr=NULL;
	char *tempstrSup=NULL;
	//char tempstr[50]={0};

	tag_t *child_bom_lines;
	tag_t *tags_found = NULL;

	tag_t item=NULLTAG;
	tag_t reva=NULLTAG;
	tag_t t_ChildItemRev;

	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));

	logical bl_Suppress_log;

	depth ++;
	//ifail = BOM_line_ask_attribute_string (bom_line_tag, name_attribute, &name); //bl_line_name
	const char *prop_name = "bl_line_name";
	char **disp_values;
	int num_values = 0;
	ifail = AOM_ask_displayable_values(bom_line_tag, prop_name, &num_values, &disp_values);
	CHECK_FAIL;
	tc_strdup(disp_values[0],&name);

	word = strtok(name, "/");
	/* note that I know name is always defined,  but sometimes sequence number is unset.
	If that happens it returns NULL,  not an error.
	*/
	//ifail = BOM_line_ask_attribute_string (bom_line_tag, seqno_attribute, &sequence_no); //bl_sequence_no
	//CHECK_FAIL;

	//ifail = BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &iChildItemTag); //bl_revision
	//ifail = BOM_line_ask_attribute_tag(bom_line_tag, iChildItemTag, &t_ChildItemRev);
	ifail = AOM_ask_value_tag(bom_line_tag,"bl_revision",&t_ChildItemRev);
	CHECK_FAIL;

	attrs[0] ="item_id";
	values[0] = (char *)word;
	ifail = ITEM_find_items_by_key_attributes(1,(const char **)attrs, (const char **)values, &n_tags_found, &tags_found);
	CHECK_FAIL;

	item = tags_found[0];
	//printf("Item Found\n");

	if( AOM_ask_value_int(bom_line_tag,"bl_level_starting_0",&level0)!=ITK_ok);

	//for (i = 0; i < depth; i++)
	//	printf ("  ");

	ifail = BOM_line_ask_child_lines (bom_line_tag, &no_bom_lines, &child_bom_lines);
	CHECK_FAIL;

	if ((no_bom_lines == 0) && (level0 == 0) )
	{
		ifail = ITEM_ask_latest_rev(item,&reva);
		CHECK_FAIL;

		if( AOM_ask_value_string(reva,"item_id",&Item_id_par)!=ITK_ok);

		printf("\n\t ?????  ChildPart are not loaded found for Input Parent  %s  , Pls load Bom again ???\n",Item_id_par); fflush(stdout);
	}

	for (j = 0; j < no_bom_lines; j++)
	{
		ifail = BOM_line_unpack (child_bom_lines[j]);
        CHECK_FAIL;

		Get_unpack_bom (child_bom_lines[j], bom_line_tag, depth);
	}

	MEM_free (child_bom_lines);
	//MEM_free (name);
	//MEM_free (sequence_no);
}
static void print_bom (tag_t bom_line_tag, tag_t line1, int depth , tag_t ParentBomLine)
{
	int ifail;
	int i, no_bom_lines , j , k=0;
	int n_tags_found= 0;
	int iChildItemTag;
	int status=0;
	int level0=0;
	int pack_count=0;
	int PartStatusInBom = 0;
	int bl_Suppress = 0;
	int charFlag = 0;
	int ti = 0;
	int tmpStrlen = 0;

	char *name, *sequence_no;
	char *Item_id_par=NULL;
	char *word=NULL;
	//char *BomLine_name=NULL;
	char *Parent_name=NULL;
	char *Parent_Rev=NULL;
	char* inputline = NULL;
	char* inputlineTemp = NULL;
	char* ChildLevel = NULL;
	char* SuppressPart = NULL;
	char* a2 = NULL;
	char* a3 = NULL;
	char* a4 = NULL;
	char* a5 = NULL;
	char* a6 = NULL;
	char* a7 = NULL;
	char* a8 = NULL;
	char* a9 = NULL;
	char* suppressAttr = NULL;
	char* ImmidiateParent = NULL;
	char *p;
	char *tempstr=NULL;
	char *tempstrSup=NULL;
	//char tempstr[50]={0};

	tag_t *child_bom_lines;
	tag_t *tags_found = NULL;

	tag_t item=NULLTAG;
	tag_t reva=NULLTAG;
	tag_t t_ChildItemRev;

	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));

	logical bl_Suppress_log;

	depth ++;
	//ifail = BOM_line_ask_attribute_string (bom_line_tag, name_attribute, &name); //bl_line_name
	const char *prop_name = "bl_line_name";
	char **disp_values;
	int num_values = 0;
	ifail = AOM_ask_displayable_values(bom_line_tag, prop_name, &num_values, &disp_values);
	CHECK_FAIL;
	tc_strdup(disp_values[0],&name);

	word = strtok(name, "/");
	/* note that I know name is always defined,  but sometimes sequence number is unset.
	If that happens it returns NULL,  not an error.
	*/
	//ifail = BOM_line_ask_attribute_string (bom_line_tag, seqno_attribute, &sequence_no); //bl_sequence_no
	//CHECK_FAIL;

	//ifail = BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &iChildItemTag); //bl_revision
	//ifail = BOM_line_ask_attribute_tag(bom_line_tag, iChildItemTag, &t_ChildItemRev);
	ifail = AOM_ask_value_tag(bom_line_tag,"bl_revision",&t_ChildItemRev);
	CHECK_FAIL;

	attrs[0] ="item_id";
	values[0] = (char *)word;
	ifail = ITEM_find_items_by_key_attributes(1,(const char **)attrs, (const char **)values, &n_tags_found, &tags_found);
	CHECK_FAIL;

	item = tags_found[0];
	//printf("Item Found\n");

	ifail = ITEM_ask_latest_rev(item,&reva);
	CHECK_FAIL;


	////for (k = 0; k < depth-1; k++)
	////{
	////	printf ("\t");
	////}

	Item_id_par=NULL;
	//bl_Suppress_log=0;

	if( AOM_ask_value_string(reva,"item_id",&Item_id_par)!=ITK_ok);
	if( AOM_ask_value_int(bom_line_tag,"bl_level_starting_0",&level0)!=ITK_ok);
	if( AOM_ask_value_int(bom_line_tag,"bl_pack_count",&pack_count)!=ITK_ok);

	//printf("\n1.ItemID---->%s   level0: %d",Item_id_par,level0); fflush(stdout);

	if ((tc_strstr(Item_id_par,"_skel")!=NULL) || (tc_strstr(Item_id_par,"_SKEL")!=NULL) || (tc_strstr(Item_id_par,"_Skel")!=NULL) || (tc_strstr(Item_id_par,"_skeleton")!=NULL))
	{
		printf("\nItemID-->%s ",Item_id_par); fflush(stdout);
		printf("\t level0: [%d]",level0); fflush(stdout);
		printf("\t pack_count: [%d]",pack_count); fflush(stdout);

		//bl_Suppress=0;
		//ifail = BOM_line_look_up_attribute ("bl_is_occ_suppressed",&bl_Suppress);
		//CHECK_FAIL;
		//ifail = BOM_line_ask_attribute_logical(bom_line_tag, bl_Suppress, &bl_Suppress_log);
		ifail = AOM_ask_value_logical(bom_line_tag, "bl_is_occ_suppressed", &bl_Suppress_log);
		CHECK_FAIL;
		printf("\t bl_is_occ_suppressed= [%d] \t\t ",bl_Suppress_log); fflush(stdout);

		if (bl_Suppress_log == 0)
		{
			//ifail = BOM_line_set_attribute_logical(bom_line_tag, bl_Suppress, true);
			//CHECK_FAIL;
			printf("\n\t "); fflush(stdout);
			//ifail = BOM_line_set_attribute_logical(bom_line_tag, bl_Suppress, true);
			ifail = AOM_set_value_logical(bom_line_tag, "bl_is_occ_suppressed", true);
			CHECK_FAIL;
			printf("\n\t ifail= [%d] ...Updated successfully",ifail); fflush(stdout);

			ifail = BOM_save_window( window );
			CHECK_FAIL;
		}
		printf("\n"); fflush(stdout);
	}

	if (level0 < 3)
	{

		if (ParentBomLine != NULLTAG)
		{
			if( AOM_ask_value_string(ParentBomLine,"bl_item_item_id",&Parent_name)!=ITK_ok);
			if( AOM_ask_value_string(ParentBomLine,"bl_rev_item_revision_id",&Parent_Rev)!=ITK_ok);
		}
		else
		{
			Parent_name = NULL;
		}

		char *prtFirstChar;
		prtFirstChar=(char *) MEM_alloc(5);
		tc_strcpy(prtFirstChar,"");
		if (level0 == 2)
		{
			if (strstr(Parent_name,"")!=NULL)
			{
				tc_strcpy(prtFirstChar,"");
				tc_strcpy(prtFirstChar,subString(Parent_name,0,1));
				//printf ("\n level0: %d   prtFirstChar: %s",level0, prtFirstChar); fflush(stdout);
			}
			else
			{
				tc_strcpy(prtFirstChar,"");
			}
		}
		else
		{
			tc_strcpy(prtFirstChar,"");
		}

		if ((level0 < 2) || ( (level0 == 2) && ((tc_strcmp(prtFirstChar,"G") == 0) || (tc_strcmp(prtFirstChar,"g") == 0))) )
		{
			//printf("\n"); fflush(stdout);
			//printf("ItemID---->%s ",Item_id_par); fflush(stdout);
			//printf("\t level0: [%d]",level0); fflush(stdout);
			//printf("\t pack_count: [%d]",pack_count); fflush(stdout);
			//printf("\t Parent_name:[%s]",Parent_name); fflush(stdout);

			fp = fopen(inputfile,"r");
			if(fp == NULL)
			{
				printf ("\n Could not open inputfile file : %s\n", inputfile); fflush(stdout);
				exit( EXIT_FAILURE );
			}
			else
			{
				PartStatusInBom = 0;

				inputline=(char *) MEM_alloc(200);
				tempstr=(char *) MEM_alloc(100);

				strcpy(tempstr,"");
				strcpy(tempstr,Item_id_par);
				tmpStrlen = strlen(tempstr);

				charFlag = 0;
				if (tmpStrlen > 0)
				{
					for(ti=0;ti<tmpStrlen;ti++)
					{
						if (!isdigit(tempstr[ti]))
						{
							//printf ("\t--alpha---"); fflush(stdout);
							charFlag = 1;
							//printf ("  charFlag %d found hence converting to case sensitive...",charFlag); fflush(stdout);
							break;
						}
					}
				}

				while(fgets(inputline,200,fp)!=NULL)
				{
					inputlineTemp = malloc(200);
					tc_strcpy(inputlineTemp,inputline);

					ChildLevel=strtok(inputline,"^");
					SuppressPart=strtok(NULL,"^");
					a2=strtok(NULL,"^");
					a3=strtok(NULL,"^");
					a4=strtok(NULL,"^");
					a5=strtok(NULL,"^");
					a6=strtok(NULL,"^");
					a7=strtok(NULL,"^");
					a8=strtok(NULL,"^");
					suppressAttr=strtok(NULL,"^");
					ImmidiateParent=strtok(NULL,"^");

					//if ((atoi(ChildLevel) != 1) && (strncmp(ImmidiateParent,"G",1) != 0) ) //skip multi-level suppressed attribute stamping  check added on 07.07.2017
					//{
					//	continue;
					//}

					if (charFlag == 1)
					{
						//printf ("\n tempstr: [%s]  tmpStrlen: [%d]",tempstr,tmpStrlen); fflush(stdout);
						//printf ("\t--alpha found in string.....hence converting to case sensitive"); fflush(stdout);

						for (p = SuppressPart; *p != '\0'; ++p)
						{
							*p = tolower( *p );
						}

						if ((tc_strcmp(Item_id_par,SuppressPart) != 0) || (strncmp(Item_id_par,"G",1) == 0))
						{
							for (p = Item_id_par; *p != '\0'; ++p)
							{
								*p = tolower( *p );
							}
						}
						//printf("\n\t Entered SuppressPart in lower case is [%s]  Item_id_par:[%s]", SuppressPart,Item_id_par);
					}
					strcpy(tempstr,"");

					if (tc_strcmp(Parent_name,ImmidiateParent)!=0)
					{
						for (p = ImmidiateParent; *p != '\0'; ++p)
						{
							*p = toupper( *p );
						}
					}

					if ((tc_strstr(SuppressPart,"_swp")!=NULL) || (tc_strstr(SuppressPart,"_SWP")!=NULL))
					{
						tempstrSup=(char *) MEM_alloc(50);
						strcpy(tempstrSup,"");
						strcpy(tempstrSup,SuppressPart);

						for (p = tempstrSup; *p != '\0'; ++p)
						{
							*p = tolower( *p );
						}

						SuppressPart=(char *) MEM_alloc(50);
						strcpy(SuppressPart,"");
						SuppressPart=strtok(tempstrSup,"_swp");
					}

					/*if ((tc_strstr(Item_id_par,"_skel")!=NULL) && ((tc_strstr(SuppressPart,"_SKEL")!=NULL) || (tc_strstr(SuppressPart,"_skel")!=NULL)))
					{
						for (p = SuppressPart; *p != '\0'; ++p)
						{
							*p = tolower( *p );
						}

						if (tc_strcmp(Parent_name,ImmidiateParent)!=0)
						{
							for (p = ImmidiateParent; *p != '\0'; ++p)
							{
								*p = toupper( *p );
							}
						}

						printf("\n\t Entered SuppressPart in lower case is [%s]  Item_id_par:[%s]", SuppressPart,Item_id_par);
					}
					else
					{
						continue;
					}*/
					//if (tc_strstr(Item_id_par,"_skel")!=NULL)
					//{
					//	printf("\n\t SuppressPart:[%s]--Item_id_par:[%s]  ,  Parent_name: [%s]--ImmidiateParent:[%s]  ,  atoi(ChildLevel):[%d]--level0:[%d]", SuppressPart,Item_id_par,Parent_name,ImmidiateParent,atoi(ChildLevel),level0); fflush(stdout);
					//}
					//if (tc_strcmp(Parent_name,ImmidiateParent)==0)
					//{
					//	printf("\n\t ---Parent is matching...."); fflush(stdout);
					//}
					//if (tc_strcmp(Item_id_par,SuppressPart)==0)
					//{
					//	printf("\n\t ---Child is matching...."); fflush(stdout);
					//}
					//if (atoi(ChildLevel) == level0)
					//{
					//	printf("\n\t ---level is matching...."); fflush(stdout);
					//}

					if (((tc_strcmp(Item_id_par,SuppressPart)==0) && (tc_strcmp(Parent_name,ImmidiateParent)==0) && (atoi(ChildLevel) == level0)) /*|| ((tc_strstr(Item_id_par,"_skel")!=NULL) || (tc_strstr(Item_id_par,"_SKEL")!=NULL))*/)
					{
						printf("ItemID---->%s ",Item_id_par); fflush(stdout);
						printf("\t level0: [%d]",level0); fflush(stdout);
						printf("\t Parent_name: [%s]",Parent_name); fflush(stdout);
						printf("\t pack_count: [%d]",pack_count); fflush(stdout);

						printf("\n\t ---ChildLevel-ChildPart-Parent is matching...."); fflush(stdout);

						printf("\n\t "); fflush(stdout);
						fputs(inputlineTemp,stdout);

						//bl_Suppress=0;
						//ifail = BOM_line_look_up_attribute ("bl_is_occ_suppressed",&bl_Suppress);
						//CHECK_FAIL;
						//ifail = BOM_line_ask_attribute_logical(bom_line_tag, bl_Suppress, &bl_Suppress_log);
						ifail = AOM_ask_value_logical(bom_line_tag, "bl_is_occ_suppressed", &bl_Suppress_log);
						CHECK_FAIL;
						printf("\t bl_is_occ_suppressed= [%d] \t\t ",bl_Suppress_log); fflush(stdout);

						if (bl_Suppress_log == 0)
						{
							//ifail = BOM_line_set_attribute_logical(bom_line_tag, bl_Suppress, true);
							//CHECK_FAIL;
							printf("\n\t "); fflush(stdout);
							//ifail = BOM_line_set_attribute_logical(bom_line_tag, bl_Suppress, true);
							ifail = AOM_set_value_logical(bom_line_tag, "bl_is_occ_suppressed", true);
							CHECK_FAIL;
							printf("\n\t ifail= [%d] ...Updated successfully",ifail); fflush(stdout);

							ifail = BOM_save_window( window );
							CHECK_FAIL;
						}
						printf("\n\n"); fflush(stdout);

						continue;
					}
				}
			}
		}
	}
	//for (i = 0; i < depth; i++)
	//	printf ("  ");

	ifail = BOM_line_ask_child_lines (bom_line_tag, &no_bom_lines, &child_bom_lines);
	CHECK_FAIL;

	if ((no_bom_lines == 0) && (level0 == 0) )
	{
		printf("\n\t ?????  ChildPart are not loaded found for Input Parent  %s  , Pls load Bom again ???\n",Item_id_par); fflush(stdout);
	}

	if (no_bom_lines > 0)
	{
		Parentlevel = level0;
		ParentBomLine = bom_line_tag;
	}

	for (j = 0; j < no_bom_lines; j++)
	{
		print_bom (child_bom_lines[j], bom_line_tag, depth,ParentBomLine);
	}

	MEM_free (child_bom_lines);
	//MEM_free (name);
	//MEM_free (sequence_no);
}
static void initialise (void)
{
    int ifail;

    // <kc> pr#397778 July2595 exit if autologin() fail
    if ((ifail = ITK_auto_login()) != ITK_ok)
		fprintf(stderr,"Login fail !!: Error code = %d \n\n",ifail);
    CHECK_FAIL;

    // these tokens come from bom_attr.h
    /*initialise_attribute (bomAttr_lineName, &name_attribute);  //bl_line_name
    initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);  //bl_sequence_no
    ifail = BOM_line_look_up_attribute (bomAttr_lineParentTag, &parent_attribute); //bl_parent
    CHECK_FAIL;
    ifail = BOM_line_look_up_attribute (bomAttr_lineItemTag, &item_tag_attribute); //bl_item
    CHECK_FAIL;*/
}
/*static void initialise_attribute (char *name,  int *attribute)
{
    int ifail, mode;

    ifail = BOM_line_look_up_attribute (name, attribute);
    CHECK_FAIL;
    ifail = BOM_line_ask_attribute_mode (*attribute, &mode);
    CHECK_FAIL;
    if (mode != BOM_attribute_mode_string)
      { printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode);
        exit(0);
      }
}*/
void lower_string(char s[])
{
   int c = 0;

   while (s[c] != '\0') {
      if (s[c] >= 'A' && s[c] <= 'Z') {
         s[c] = s[c] + 32;
      }
      c++;
   }
}
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
        int i;
        char *retStringf;
        retStringf = (char*) malloc(3);
        for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
        *(retStringf+i) = '\0';
        return retStringf;
}
