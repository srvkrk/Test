/**********************************************************************************************************************************************************
**Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
**
** This software is the confidential and proprietary information of TTL.
** You shall not disclose such confidential information and shall use it
** only in accordance with the terms of the license agreement.
**
** SOURCE FILE NAME: get_part_status.c
**
** Functions:- This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's required information.
** 
**
**	Date					Author						Modification
**	28-Feb-2018				Kalpesh Gondhali			Code creation
**	12-Sept-2018			Kalpesh Gondhali			Starting 3 digits of part no. shouldn't be "900" (check added)
**	03-Oct-2018				Kalpesh Gondhali			Design Grp should be 00 to 99 (Check added)
**
** command to run:
** get_part_status -u=<username> -p=<password> -g=<group>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <qry/qry.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


FILE		*output 			= NULL;

char		*sep				= "^";

int run_item_query();
int get_part_status(tag_t, char* );

void print_requirement()
{
	printf(
	"\nHELP:\n"
	"get_part_status -u=<username> -pf=<password file path> -g=<group> -file=<name of input file>\n"
	"-------------------------------------------------------------------------------------------\n\n"
	);
}
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	char *retStringf = NULL;
	retStringf = (char	*)MEM_alloc(200);

	int i;
	//char *retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	//file 			= ITK_ask_cli_argument("-file=");
	
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%m_%Y",&when);
	sprintf(outputFile,"IncFile_%s.txt",Data);

	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	output = fopen(outputFile, "w");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = run_item_query();
		//CHECK_FAIL;
		
	fclose(output);
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}

/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
/*
int read_value_from_file(char* Filename)
{
	char			*part_no					= NULL;
	char			*rev_id						= NULL;
	char			*BitValue					= NULL;
	char			*ParamValue					= NULL;
	char			temp[10000];

	FILE		* fp 					= NULL;

	fp = fopen(Filename, "r");
	if (fp != NULL)
	{
		while (fgets(temp, 10000, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				part_no = strtok(temp, "^");
				printf("\nInput part_no:%s",part_no);

				

				ifail = set_attr_values(part_no, rev_id, itemid_para, rev_para, EPType, EPDesc, EPUnit, EPLen, EPValueList, ECUType, EPDidValue, EPReadable, EPApplicable, ECUVendor, ECUVersion, BitValue, ParamValue);
			}
			printf("\n***************************************\n");
			tc_strcpy(temp, "");
		}
	}
	else
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	return ifail;
}
*/


/**********************************************************************************************
    Function:       run_item_query
    Description:    This function queries the item into TC on the basis of it's object_type
					and owning user.
**********************************************************************************************/
int run_item_query()
{
	//int				status;
	int				ifail 						= ITK_ok;
	int				i	 						= 0;
	int				results						= 0;
	
	char			*entry0						= "Type";
	char			*entry1						= "Owning User";
	
	char			*type						= "Design";
	char			*user						= "loader (loader)";
	char			*object_id					= NULL;
	char			*part_type					= NULL;

	tag_t			query_tag					= NULLTAG;
	tag_t			*object_tag					= NULL;
	
	char**  		entries						= NULL;
	char**  		values						= NULL;
		
	entries		= (char**) MEM_alloc (sizeof(char*) * 20);
	values		= (char**) MEM_alloc (sizeof(char*) * 20);
	
	entries[0] 	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(entry0) + 20));
	values[0]  	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(type) + 20));
			
	entries[1] 	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(entry1) + 20));
	values[1]  	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(user) + 20));
			
	tc_strcpy(entries[0], "");	
	tc_strcpy(entries[0], entry0);
	tc_strcpy(values[0], "");	
	tc_strcpy(values[0], type);
	
	tc_strcpy(entries[1], "");
	tc_strcpy(entries[1], entry1);
	tc_strcpy(values[1], "");	
	tc_strcpy(values[1], user);
	
	ifail = QRY_ignore_case_on_search(TRUE);
	ifail = QRY_find2("get_design_part", &query_tag);
		
	if(query_tag == NULLTAG)
	{
		printf("\nQuery Not Found in TC....!!\n");
		return 0;
	}
	else
	{
		ifail = QRY_execute(query_tag,2, entries, values, &results, &object_tag);
		if(results > 0)
		{
			printf("\nTotal %d objects found\n", results);
			for(i=0;i<results;i++)
			{
				//ifail = AOM_UIF_ask_value(object_tag[i],"t5_RevPartType", &part_type);
				//if(tc_strcmp(part_type, "Module") == 0)
				ifail = ITEM_ask_id2 (object_tag[i], &object_id);
				printf("\nObjectId: %s ",object_id);
								
				int 			c 							= 0;
				int 			position 					= 1;
				int 			length						= 3;
				char			substr[10]					= "";

				while(c < length)
				{
					substr[c] = object_id[(position + c) - 1 ];
					c++;
				}
				substr[c] = '\0';
				
				printf(" substr:\"%s\" ", substr);
				
				if(tc_strcmp(substr, "900") != 0)
				{
					ifail = get_part_status(object_tag[i], object_id);
					//CHECK_FAIL;
					tc_strcpy(substr, "");
				}
				else
				{
					printf(" Part_No:%s starts with \"900\" Hence Skipped...!!\n", object_id);
					tc_strcpy(substr, "");
				}
			}
		}
		else
			{
				printf("Total %d object found\n",results);
				return 0;
			}
	}
	
	MEM_free(object_tag);

	return ifail;	
}


/********************************************************************************************
    Function:       get_part_status
    Description:    This function takes the item_tag and object_id as input and writes 
					item's information into a file.
********************************************************************************************/
int get_part_status(tag_t object_tag, char* object_id)
{
	//int				status;
	int				ifail 						= ITK_ok;
	int				count 						= 0;
	
	tag_t			latest_rev_tag				= NULLTAG;
	
	char 			*owner						= NULL;
	//char 			*status						= NULL;
	char 			*design_grp					= NULL;
	char 			*rev_rel_status				= NULL;
	char			*revision_id				= NULL;
	char			**strings					= NULL;
	char			*designGrps					= (char *) MEM_alloc(500);
	char *RevCreationDt =NULL;

	strcpy(designGrps,"00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99");
	
	char *test	= (char*)MEM_alloc(sizeof(char) * 500);
	char *test1 = (char*)MEM_alloc(sizeof(char) * 500);
	char *MonStr = (char*)MEM_alloc(sizeof(char) * 5);
	
	ifail =ITEM_ask_latest_rev (object_tag, &latest_rev_tag);
	//CHECK_FAIL;
	
	ifail = AOM_UIF_ask_value (latest_rev_tag, "t5_DesignGrp", &design_grp);
	printf("\nDesign group: %s", design_grp);
	
	if(tc_strstr(designGrps, design_grp) == 0)
	{
		printf("Doesn't have Design Group from [00] to [99]...!!\n");
		return 0;
	}
	else
	{
		ifail = AOM_UIF_ask_value(latest_rev_tag, "owning_user", &owner);
		printf("   Owner: %s  ",owner); fflush(stdout);
		ifail = AOM_UIF_ask_value (latest_rev_tag, "item_revision_id", &revision_id);
		ifail = AOM_UIF_ask_value (latest_rev_tag, "release_status_list", &rev_rel_status);
		ifail = AOM_UIF_ask_value (latest_rev_tag, "creation_date", &RevCreationDt);

		printf("Latest Rev_ID: %s ",revision_id); fflush(stdout);
		printf("\t Release Status: %s ",rev_rel_status); fflush(stdout);
		printf("\t RevCreationDt: %s ",RevCreationDt); fflush(stdout);

		if(tc_strcmp(owner, "loader (loader)") == 0)
		{	
			if(strstr(revision_id, ";") == 0)
			{
				printf("Doesn't have sequence hence skipped...!!\n"); fflush(stdout);
				return 0;
			}
			else
			{
				ifail = EPM__parse_string(revision_id,";", &count, &strings);

				tc_strcpy(test, "");
				tc_strcpy(test, object_id);
				tc_strcat(test,sep);
				tc_strcat(test,strings[0]);
				tc_strcat(test,sep);
				tc_strcat(test,strings[1]);
				tc_strcat(test,sep);
				fprintf(output,"%s",test); fflush(output);
			}

			if(tc_strlen(rev_rel_status) == 0 )
			{
				tc_strcpy(rev_rel_status, "");
				tc_strcpy(rev_rel_status, "ERC Working");
				printf("New status:%s\n", rev_rel_status); fflush(stdout);
				
				tc_strcpy(test1, "");
				tc_strcpy(test1,rev_rel_status);
				tc_strcat(test1,sep);
				fprintf(output,"%s",test1); fflush(output);
			}
			else
			{
				if(strstr(rev_rel_status, ",") == 0 )
				{
					tc_strcpy(test1, "");
					tc_strcpy(test1,rev_rel_status);
					tc_strcat(test1,sep);
					fprintf(output,"%s",test1); fflush(output);
				}
				else
				{
					char temp[100]  = "";
					//tc_strcpy(temp, rev_rel_status);
					//status = strtok(temp, ",");
					
					if (strstr(rev_rel_status, "ERC Release") != NULL )
					{
						tc_strcpy(test1, "");
						tc_strcpy(test1,"ERC Released");
						tc_strcat(test1,sep);
						fprintf(output,"%s",test1);	 fflush(output);
						tc_strcpy(temp, "");
					}
					else if (strstr(rev_rel_status, "ERC Review") != NULL )
					{
						tc_strcpy(test1, "");
						tc_strcpy(test1,"ERC Review");
						tc_strcat(test1,sep);
						fprintf(output,"%s",test1);	 fflush(output);
						tc_strcpy(temp, "");
					}
				}
			}

			if (RevCreationDt!=NULL)
			{
				tc_strcpy(MonStr,"");

				if (tc_strcmp(subString(RevCreationDt,3,3),"Jan")==0)	{ tc_strcpy(MonStr,"01");	}
				if (tc_strcmp(subString(RevCreationDt,3,3),"Feb")==0)	{ tc_strcpy(MonStr,"02");	}
				if (tc_strcmp(subString(RevCreationDt,3,3),"Mar")==0)	{ tc_strcpy(MonStr,"03");	}
				if (tc_strcmp(subString(RevCreationDt,3,3),"Apr")==0)	{ tc_strcpy(MonStr,"04");	}
				if (tc_strcmp(subString(RevCreationDt,3,3),"May")==0)	{ tc_strcpy(MonStr,"05");	}
				if (tc_strcmp(subString(RevCreationDt,3,3),"Jun")==0)	{ tc_strcpy(MonStr,"06");	}
				if (tc_strcmp(subString(RevCreationDt,3,3),"Jul")==0)	{ tc_strcpy(MonStr,"07");	}
				if (tc_strcmp(subString(RevCreationDt,3,3),"Aug")==0)	{ tc_strcpy(MonStr,"08");	}
				if (tc_strcmp(subString(RevCreationDt,3,3),"Sep")==0)	{ tc_strcpy(MonStr,"09");	}
				if (tc_strcmp(subString(RevCreationDt,3,3),"Oct")==0)	{ tc_strcpy(MonStr,"10");	}
				if (tc_strcmp(subString(RevCreationDt,3,3),"Nov")==0)	{ tc_strcpy(MonStr,"11");	}
				if (tc_strcmp(subString(RevCreationDt,3,3),"Dec")==0)	{ tc_strcpy(MonStr,"12");	}

				fprintf(output,"%s/%s/%s^\n",subString(RevCreationDt,7,4),MonStr,subString(RevCreationDt,0,2)); fflush(output);
			}
			else
			{
				fprintf(output,"-^\n"); fflush(output);
			}

			MEM_free(strings);
		}
		else
		{
			printf("Owner of rev:%s is different:%s hence skipped.\n", revision_id, owner); fflush(stdout);
			return 0;
		}
	}
	
	/*MEM_free(rev_rel_status);	
	MEM_free(revision_id);
	MEM_free(owner);
	MEM_free(test);
	MEM_free(test1);*/
	
	return ifail;
}
