/*************************************************************************************************************
* Copyright (c) 2022 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Alokesh Ghosh
*  Module		 :   Print all Latest ERC Released Design Part Numbers
*  Code			 :   part_Latest_ERC_Rlz.c
*  Created on	 :   Dec 21, 2022
*
* Modification History :
* S.No		Date		CR No	Modified By            Modification Notes
*			
*************************************************************************************************************/
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/aom_prop.h>
#include <ae/dataset.h>

//Ujjawal - (For Global Variables)
FILE 		*output 			= NULL;
FILE 		*notInCVProd 	= NULL;
const char *revision_Order[] = {"NR", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a1", "b1", "c1", "d1", "e1", "f1", "g1", "h1", "i1", "j1", "k1", "l1", "m1", "n1", "o1", "p1", "q1", "r1", "s1", "t1", "u1", "v1", "w1", "x1", "y1", "z1", "a2", "b2", "c2", "d2", "e2", "f2", "g2", "h2", "i2", "j2", "k2", "l2", "m2", "n2", "o2", "p2", "q2", "r2", "s2", "t2", "u2", "v2", "w2", "x2", "y2", "z2", "a3", "b3", "c3", "d3", "e3", "f3", "g3", "h3", "i3", "j3", "k3", "l3", "m3", "n3", "o3", "p3", "q3", "r3", "s3", "t3", "u3", "v3", "w3", "x3", "y3", "z3", "a4", "b4", "c4", "d4", "e4", "f4", "g4", "h4", "i4", "j4", "k4", "l4", "m4", "n4", "o4", "p4", "q4", "r4", "s4", "t4", "u4", "v4", "w4", "x4", "y4", "z4", "a5", "b5", "c5", "d5", "e5", "f5", "g5", "h5", "i5", "j5", "k5", "l5", "m5", "n5", "o5", "p5", "q5", "r5", "s5", "t5", "u5", "v5", "w5", "x5", "y5", "z5", "a6", "b6", "c6", "d6", "e6", "f6", "g6", "h6", "i6", "j6", "k6", "l6", "m6", "n6", "o6", "p6", "q6", "r6", "s6", "t6", "u6", "v6", "w6", "x6", "y6", "z6", "a7", "b7", "c7", "d7", "e7", "f7", "g7", "h7", "i7", "j7", "k7", "l7", "m7", "n7", "o7", "p7", "q7", "r7", "s7", "t7", "u7", "v7", "w7", "x7", "y7", "z7", "a8", "b8", "c8", "d8", "e8", "f8", "g8", "h8", "i8", "j8", "k8", "l8", "m8", "n8", "o8", "p8", "q8", "r8", "s8", "t8", "u8", "v8", "w8", "x8", "y8", "z8", "a9", "b9", "c9", "d9", "e9", "f9", "g9", "h9", "i9", "j9", "k9", "l9", "m9", "n9", "o9", "p9", "q9", "r9", "s9", "t9", "u9", "v9", "w9", "x9", "y9", "z9"};
const int revision_length = 260;

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static void handle_itk_error
    ( int stat,                               /* <I> */
      int source_code_line,                   /* <I> */
      const char *source_code_file_name       /* <I> */
    );

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc, char* argv[])
{
	int ifail = ITK_ok;
	CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	if(ITK_auto_login() == ITK_ok)	
	{
		printf("\n\nlogin successful\n");fflush(stdout);
		int objtyplen = 7;
		int rlztyplen = 1;
		int ownUsrlen = 1;
		const char* object_type_data[]={"Design Revision","T5_ClrPartRevision","T5_CkdDmyRevision","T5_DummyPartRevision","T5_DuraFitPartRevision","T5_EE_PartRevision","T5_RawPartRevision"};
		const char* fnd_lat_ERCRlz_lst=NULL;
		//const char* select_attrs[]={"item_id","item_revision_id","creation_date","last_mod_date","puid"};
		const char* select_attrs[]={"puid","item_revision_id"};
		const char *select_attrs_Item[] = { "item_id" };
		const char* release_status_data[]={"T5_LcsErcRlzd"};
		const char* owning_user_data[]={"loader"};
		int  rows = 0, columns = 0, i = 0;
		void ***report;
		char *pQry = "fnd_lat_ERCRlz_lst";
		
		CALLAPI(POM_enquiry_create(pQry));
		CALLAPI(POM_enquiry_add_select_attrs (pQry,"ItemRevision",1,select_attrs));
		CALLAPI(POM_enquiry_add_select_attrs(pQry, "Item", 1,select_attrs_Item));

		CALLAPI(POM_enquiry_set_string_value (pQry,"object_type_expr",objtyplen,object_type_data,POM_enquiry_bind_value));
		CALLAPI(POM_enquiry_set_attr_expr (pQry,"expr_object_type_in","ItemRevision","object_type",POM_enquiry_in,"object_type_expr"));

		CALLAPI(POM_enquiry_set_join_expr(pQry, "join_expr1","ItemRevision", "items_tag", POM_enquiry_equal, "Item", "puid"));
		//CALLAPI(POM_enquiry_set_join_expr(pQry, "join_expr2","ItemRevision", "release_status_list", POM_enquiry_equal, "ReleaseStatus", "puid"));
		CALLAPI(POM_enquiry_set_join_expr(pQry, "join_expr3","ItemRevision", "owning_user", POM_enquiry_equal, "User", "puid"));

		//CALLAPI(POM_enquiry_set_string_value (pQry,"release_stat_expr",rlztyplen,release_status_data,POM_enquiry_bind_value));
		//CALLAPI(POM_enquiry_set_attr_expr (pQry,"expr_rlz_stat_in","ReleaseStatus","name",POM_enquiry_in,"release_stat_expr"));

		CALLAPI(POM_enquiry_set_string_value (pQry,"own_user_expr",ownUsrlen,owning_user_data,POM_enquiry_bind_value));
		CALLAPI(POM_enquiry_set_attr_expr (pQry,"expr_own_user_in","User","user_id",POM_enquiry_in,"own_user_expr"));

		//CALLAPI(POM_enquiry_set_expr (pQry,"combine_expr","join_expr1", POM_enquiry_and, "join_expr2"));
		//CALLAPI(POM_enquiry_set_expr (pQry,"combine_expr1","combine_expr",POM_enquiry_and,"expr_object_type_in"));
		CALLAPI(POM_enquiry_set_expr (pQry,"combine_expr1","join_expr1",POM_enquiry_and,"expr_object_type_in"));

		CALLAPI(POM_enquiry_set_expr (pQry,"combine_expr2","combine_expr1",POM_enquiry_and,"join_expr3"));
		CALLAPI(POM_enquiry_set_expr (pQry,"combine_expr3","combine_expr2",POM_enquiry_and,"expr_own_user_in"));

		//CALLAPI(POM_enquiry_set_expr (pQry,"expr_AND_expression","combine_expr3",POM_enquiry_and,"expr_rlz_stat_in"));
		//CALLAPI(POM_enquiry_set_where_expr (pQry,"expr_AND_expression"));
		CALLAPI(POM_enquiry_set_where_expr (pQry,"combine_expr3"));

		CALLAPI(POM_enquiry_add_order_attr (pQry, "Item", "item_id", POM_enquiry_asc_order));

		printf("******Before Executing POM_enquiry_execute *********\n");fflush(stdout);
		CALLAPI(POM_enquiry_execute(pQry, &rows, &columns, &report));
		printf("******After Executing POM_enquiry_execute *********\n");fflush(stdout);
		CALLAPI(POM_enquiry_delete(pQry));
		printf(" \n number of rows %d and coloumn %d\n",rows,columns);fflush(stdout);

		if (rows != 0)
		{
			char *item_id = NULL;
			char *rev_id = NULL;
			char *actRev = NULL;
			char *actSeq = NULL;
			tag_t objtag =NULLTAG;
			char *previous_item = (char*)MEM_alloc(sizeof(char) * 30);
			char *print_data = (char*)MEM_alloc(sizeof(char) * 200);
			tc_strcpy(previous_item,"");
			FILE *output = NULL;
			int i = 0;
			int r = 0;
			char* highItmId = (char*)MEM_alloc(sizeof(char) * 250);
			char* highRev = (char*)MEM_alloc(sizeof(char) * 20);
			char* highSeq = (char*)MEM_alloc(sizeof(char) * 20);
			int highestPos = 0;
			int highRevPos = 0;
			int actRevPos = 0;

			char    *qry_latItmRev[3]  = {"Item ID"};
			tag_t   *revTagLatItm   = NULLTAG;
			int     rsltCountLatItm	= 0;
			char    **qry_valuesLatItm     =  (char **) MEM_alloc(100 * sizeof(char *));
			tag_t   qryTagLatItmRev		= NULLTAG;
			char 	*revIdLatRev = NULL;
			char* LatItmRevRev = (char*)MEM_alloc(sizeof(char) * 20);
			char* LatItmRevSeq = (char*)MEM_alloc(sizeof(char) * 20);

			time_t 	now;
			struct 	tm when;
			time(&now);
			when = *localtime(&now);
			char Data[100] = "";
			char outputFile[200] = "";
			strftime(Data,100,"%d_%m_%Y",&when);
			sprintf(outputFile,"Effectivity_Mismatch_%s.txt",Data);

			output = fopen(outputFile,"w");
			if (output == NULL)
			{
				printf("ERROR: Cannot open File\n");
				return -1;
			}
			
			objtag  = *(tag_t*)(report[0][0]);
			ifail = AOM_ask_value_string (objtag, "item_id", &item_id);
			tc_strcpy(highItmId, item_id);
			ifail = AOM_UIF_ask_value (objtag, "item_revision_id", &rev_id);
			printf("\n item_revision_id is:%s",rev_id); fflush(stdout);
			highRev = strtok(rev_id,";");
			highSeq = strtok(NULL,";");
			highestPos = 0;

			for (r = 0; r < revision_length; r++) 
			{     
				if (strcmp(highRev, revision_Order[r]) == 0) 
				{
					highRevPos = r;
					break;
				}   
			}

			for (i = 1; i < rows; i++ )
			{
				objtag  = *(tag_t*)(report[i][0]);

				ifail = AOM_ask_value_string (objtag, "item_id", &item_id);
				printf("\n %d object_string is:::%s",i,item_id); fflush(stdout);
				ifail = AOM_UIF_ask_value (objtag, "item_revision_id", &rev_id);
				actRev = strtok(rev_id,";");
				actSeq =strtok(NULL,";");

				for (r = 0; r < revision_length; r++) 
				{     
					if (strcmp(actRev, revision_Order[r]) == 0) 
					{
						actRevPos = r;
						break;
					}   
				}

				//Checking Start of High Revision
				if (strcmp(previous_item,item_id)==0)
				{
					if(tc_strcmp(highRev, "NR")==0 && tc_strcmp(actRev, "NR")!=0)
					{
						tc_strcpy(highItmId, item_id);
						tc_strcpy(highRev, actRev);
						tc_strcpy(highSeq, actSeq);
						highestPos = i;
						highRevPos = actRevPos;
					}
					else if(tc_strcmp(highRev, "NR")!=0 && tc_strcmp(actRev, "NR")==0)
					{
						continue;
					}
					else if(tc_strcmp(highRev, actRev)==0)
					{
						if(tc_strcmp(highSeq, actSeq) < 0)
						{
							tc_strcpy(highItmId, item_id);
							tc_strcpy(highRev, actRev);
							tc_strcpy(highSeq, actSeq);
							highestPos = i;
							highRevPos = actRevPos;
						}
					}
					//else if(tc_strcmp(highRev, actRev) > 0)
					else if(highRevPos > actRevPos)
					{
						continue;
					}
					else
					{
						tc_strcpy(highItmId, item_id);
						tc_strcpy(highRev, actRev);
						tc_strcpy(highSeq, actSeq);
						highestPos = i;
						highRevPos = actRevPos;
					}
				}
				//Checking End of High Revision
				else
				{
					tc_strcpy(LatItmRevRev, "");
					tc_strcpy(LatItmRevSeq, "");

					if(QRY_find2("Latest Item Revision...", &qryTagLatItmRev));
					if (qryTagLatItmRev)
					{
						printf("\nFound Query Latest Item Revision... \n");fflush(stdout);
					}
					qry_valuesLatItm[0] = highItmId;
					printf("\nPart --> %s",qry_valuesLatItm[0]); fflush(stdout);
					if(QRY_execute(qryTagLatItmRev, 1, qry_latItmRev, qry_valuesLatItm, &rsltCountLatItm, &revTagLatItm));
					
					if (rsltCountLatItm>0)
					{
						ifail = AOM_UIF_ask_value (revTagLatItm[0], "item_revision_id", &revIdLatRev);
						printf("\n item_revision_id is:%s",revIdLatRev); fflush(stdout);
						LatItmRevRev = strtok(revIdLatRev,";");
						LatItmRevSeq = strtok(NULL,";");
					}

					if(tc_strcmp(highRev, LatItmRevRev)!=0 || tc_strcmp(highSeq, LatItmRevSeq)!=0)
					{
						//Printing Last Object's Highest Data
					    tc_strcpy(print_data,"");
						tc_strcat(print_data,highItmId);
						tc_strcat(print_data,",");
						tc_strcat(print_data,highRev);
						tc_strcat(print_data,",");
						tc_strcat(print_data,highSeq);
						tc_strcat(print_data,",");
						tc_strcat(print_data,LatItmRevRev);
						tc_strcat(print_data,",");
						tc_strcat(print_data,LatItmRevSeq);
						tc_strcat(print_data,",");

						fprintf(output,"%s\n",print_data); fflush(output);
					}

					//Next Object Came, So Resetting
					tc_strcpy(previous_item,item_id);
					tc_strcpy(highItmId, item_id);
					tc_strcpy(highRev, actRev);
					tc_strcpy(highSeq, actSeq);
					highestPos = i;
					highRevPos = actRevPos;
				}
			}
			fclose(output);
		}
	}
	else
	{
		printf("\nLogin Failed!\n\n");
	}	
	
	printf("\n *********** End Of Main function ************* \n");fflush(stdout);
	ITK_exit_module(TRUE);
	return ifail;
}