/*************************************************************************************************************
* Copyright (c) 2022 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Alokesh Ghosh
*  Module		 :   Print all Latest ERC Released Design Part Numbers
*  Code			 :   part_Latest_ERC_Rlz.c
*  Created on	 :   Dec 21, 2022
*
* Modification History :
* S.No		Date		CR No	Modified By            Modification Notes
*			
*************************************************************************************************************/
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/aom_prop.h>
#include <ae/dataset.h>

//Ujjawal - (For Global Variables)
FILE 		*output 			= NULL;
FILE 		*notInCVProd 	= NULL;
const char *revision_Order[] = {"NR", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a1", "b1", "c1", "d1", "e1", "f1", "g1", "h1", "i1", "j1", "k1", "l1", "m1", "n1", "o1", "p1", "q1", "r1", "s1", "t1", "u1", "v1", "w1", "x1", "y1", "z1", "a2", "b2", "c2", "d2", "e2", "f2", "g2", "h2", "i2", "j2", "k2", "l2", "m2", "n2", "o2", "p2", "q2", "r2", "s2", "t2", "u2", "v2", "w2", "x2", "y2", "z2", "a3", "b3", "c3", "d3", "e3", "f3", "g3", "h3", "i3", "j3", "k3", "l3", "m3", "n3", "o3", "p3", "q3", "r3", "s3", "t3", "u3", "v3", "w3", "x3", "y3", "z3", "a4", "b4", "c4", "d4", "e4", "f4", "g4", "h4", "i4", "j4", "k4", "l4", "m4", "n4", "o4", "p4", "q4", "r4", "s4", "t4", "u4", "v4", "w4", "x4", "y4", "z4", "a5", "b5", "c5", "d5", "e5", "f5", "g5", "h5", "i5", "j5", "k5", "l5", "m5", "n5", "o5", "p5", "q5", "r5", "s5", "t5", "u5", "v5", "w5", "x5", "y5", "z5", "a6", "b6", "c6", "d6", "e6", "f6", "g6", "h6", "i6", "j6", "k6", "l6", "m6", "n6", "o6", "p6", "q6", "r6", "s6", "t6", "u6", "v6", "w6", "x6", "y6", "z6", "a7", "b7", "c7", "d7", "e7", "f7", "g7", "h7", "i7", "j7", "k7", "l7", "m7", "n7", "o7", "p7", "q7", "r7", "s7", "t7", "u7", "v7", "w7", "x7", "y7", "z7", "a8", "b8", "c8", "d8", "e8", "f8", "g8", "h8", "i8", "j8", "k8", "l8", "m8", "n8", "o8", "p8", "q8", "r8", "s8", "t8", "u8", "v8", "w8", "x8", "y8", "z8", "a9", "b9", "c9", "d9", "e9", "f9", "g9", "h9", "i9", "j9", "k9", "l9", "m9", "n9", "o9", "p9", "q9", "r9", "s9", "t9", "u9", "v9", "w9", "x9", "y9", "z9"};
const int revision_length = 260;


#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static void handle_itk_error
    ( int stat,                               /* <I> */
      int source_code_line,                   /* <I> */
      const char *source_code_file_name       /* <I> */
    );

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc, char* argv[])
{
	int ifail = ITK_ok;
	CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	if(ITK_auto_login() == ITK_ok)	
	{
		printf("\n\nlogin successful\n");fflush(stdout);
		char *ItemId = NULL;
		char *revId = NULL;
		char* ItemRev = (char*)MEM_alloc(sizeof(char) * 20);
		char* ItemSeq = (char*)MEM_alloc(sizeof(char) * 20);
		char* partType = NULL;
		char* projectCode = NULL;
		char* designGrp = NULL;
		int i = 0;
		FILE *output = NULL;
		time_t 	now;
		struct 	tm when;
		time(&now);
		when = *localtime(&now);
		char Data[100] = "";
		char outputFile[200] = "";
		strftime(Data,100,"%d_%m_%Y",&when);
		sprintf(outputFile,"IncFile_%s.txt",Data);

		output = fopen(outputFile,"w");
		if (output == NULL)
		{
			printf("ERROR: Cannot open File\n");
			return -1;
		}

		char *cEntries[1]  = {"Owning User"};
		char **cValues = (char **) MEM_alloc(50 * sizeof(char *));
		int n_itemobj_found = 0;
		int n_entries = 1;
		tag_t* titemobj_results = NULLTAG;
		tag_t tItemobj = NULLTAG;
		cValues[0] = "loader (loader)";
		CALLAPI(QRY_find2("Latest Released Design Revision for ERC",&tItemobj));
		CALLAPI(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n Return Value From Query Execute API is --------> %d", n_itemobj_found);fflush(stdout);
		if (n_itemobj_found > 0)
		{
			for (i = 0; i < n_itemobj_found; i++ )
			{
				tc_strcpy(ItemRev, "");
				tc_strcpy(ItemSeq, "");
				ifail = AOM_UIF_ask_value (titemobj_results[i], "item_id", &ItemId); if (ifail != ITK_ok) continue;
				ifail = AOM_UIF_ask_value (titemobj_results[i], "item_revision_id", &revId); if (ifail != ITK_ok) continue;
				ifail = AOM_UIF_ask_value (titemobj_results[i], "t5_PartType", &partType); if (ifail != ITK_ok) continue;
				ifail = AOM_UIF_ask_value (titemobj_results[i], "t5_ProjectCode", &projectCode); if (ifail != ITK_ok) continue;
				ifail = AOM_UIF_ask_value (titemobj_results[i], "t5_DesignGrp", &designGrp); if (ifail != ITK_ok) continue;
				if(tc_strstr(revId,";") != NULL)
				{
					ItemRev = tc_strtok(revId,";");
					ItemSeq = tc_strtok(NULL,";");
				}
				printf("%d ---- %s^%s^%s^%s^%s^%s^\n",i,ItemId,ItemRev,ItemSeq,partType,projectCode,designGrp); fflush(stdout);
				fprintf(output,"%s^%s^%s^%s^%s^%s^\n",ItemId,ItemRev,ItemSeq,partType,projectCode,designGrp); fflush(output);
			}
		}
	}
	else
	{
		printf("\nLogin Failed!\n\n");
	}	
	
	printf("\n *********** End Of Main function ************* \n");fflush(stdout);
	ITK_exit_module(TRUE);
	return ifail;
}