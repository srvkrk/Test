/*************************************************************************************************************************************
**Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
**
** This software is the confidential and proprietary information of TTL.
** You shall not disclose such confidential information and shall use it
** only in accordance with the terms of the license agreement.
**
** SOURCE FILE NAME: update_PTmodule.c
**
** Functions:-	This utility takes module id and it's revision id as input from file and queries it into teamcenter. 
				If found, get's the attribute values on the basis of module id and stamp it on specific attribute 
				of given revisions of perticular module and writes appropriate information into the file.
				(Required for Powertrain Onetime/Incremental uploading)
** 
**
**	Date							Author								Modification	
**	17-July-2018					Kalpesh Gondhali					Module Attribute value update.
**																		(For "Powertrain Modules" only)
**
** command to run:
** update_PTmodule -u=<username> -p=<password> -g=<group> -file=<Filename>
*************************************************************************************************************************************/

#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <time.h>
#include <stdio.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>


#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


#define PROP_UIF_set_value_msg		"PROP_UIF_set_value"
#define PROP_set_value_tag_msg		"PROP_set_value_tag"
#define PROP_set_value_string_msg   "PROP_set_value_string"

FILE 		*output 			= NULL;

int			ifail 				= ITK_ok;
char		*sep				= "^";

int read_value_from_file(char*);
int	get_attr_values(char*, char*);
int stamp_values(tag_t, char*, char*, char*, char*, char*);
int write_into_file(char*, char*, char*, char*, char*, char*, char*, char*);

void print_requirement()
{
	printf(
        " HELP:\n"
        " update_PTmodule -u=<username> -p=<password file> -g=<group> -file=<input Filename>\n"
        );	
}

struct PTModule_attr
	{
		char		*PT_aggr_grp;
		char		*PT_aggr;
		char		*PT_module_grp;
		char		*PT_module;
	};


/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	//int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Filename					= NULL;

	char 			Data[100]    				= "";
	char 			OutputFile[200]    			= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	Filename		= ITK_ask_cli_argument("-file=");
	
	time_t now;
	struct tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
	sprintf(OutputFile,"%s_PTmodule_attr_update.txt",Data);

	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Filename)) == 0)
	{
		print_requirement();
		return -1;
	}
	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	output = fopen(OutputFile,"a+");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}	
				
		ifail = read_value_from_file(Filename);

	fclose(output);
	printf("\n*********************\n");
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				ifail 					= ITK_ok;
	int				count	 				= 0;
	
	char 			*itemid					= NULL;
	char 			*revid					= NULL;
	char 			temp[500];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 500, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				itemid = strtok(temp, "^");
				printf("\nInput Item_id:%s",itemid);

				revid = strtok(NULL, "^");
				printf("\nInput rev_id:%s",revid);

				fprintf(output,"%s", itemid);
				fprintf(output,"%s%s",sep, revid);
								
				ifail = get_attr_values(itemid, revid);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	return ifail;
}


/********************************************************************************************
    Function:       get_attr_values
    Description:    This function takes the item_id and attr_value as input and stamps the 
					attr_value on specific attribute of latest revision of perticular item.
********************************************************************************************/

int get_attr_values(char* module_id, char* rev_id)
{
	//int				r_count 					= 0;
	int				i		 					= 0;
	
	tag_t			rev_tag						= NULLTAG;
	tag_t			*rev_list					= NULL;
	
	char 			*prt_type					= NULL;
	char 			*type						= "Module";
	
	ifail = ITEM_find_rev (module_id, rev_id, &rev_tag);
	if(ifail != ITK_ok)
	{
		printf("\nModule not found...!!");
		fprintf(output,"%s",sep);
		fprintf(output,"Module Not Found\n");
		return 0;
	}
	else
	{
		int 			c 							= 0;
		int 			position 					= 5;		
		int 			length						= 5;
		char			substr[10]					= "";

		while(c < length)
		{
			substr[c] = module_id[(position + c) - 1 ];
			c++;
		}
		substr[c] = '\0';
		
		printf("\nSubstring:%s", substr);
	
		char *module_address = (char*)MEM_alloc(sizeof (char) * 2);
		tc_strcpy(module_address, "");
		tc_strcpy(module_address, "M");
		tc_strcat(module_address, substr);

		printf("\nmodule_address:%s", module_address);

		struct PTModule_attr P1A01 = {"P-POWERTRAIN",
			"1-PETROL/ DIESEL ENGINE(BASE ENGINEERING)",
			"A-00-COMPLETE ENGINE ASSEMBLY WITH CLUTCH",
			"01-00-COMPLETE ENGINE ASSEMBLY WITH CLUTCH"
		};
		struct PTModule_attr P1B01 = {"P-POWERTRAIN",
			"1-PETROL/ DIESEL ENGINE(BASE ENGINEERING)",
			"B-01-ENGINE STRUCTURE ( BLOCK, HEAD & OIL SUMP)",
			"01-01-ENGINE STRUCTURE ( BLOCK, HEAD & OIL SUMP)"
		};
		struct PTModule_attr P1C01 = {"P-POWERTRAIN",
			"1-PETROL/ DIESEL ENGINE(BASE ENGINEERING)",
			"C-03-DRIVE PARTS -CRANK TRAIN SYSTEM",
			"01-03-DRIVE PARTS -CRANK TRAIN SYSTEM"
		};
		struct PTModule_attr P1D01 = {"P-POWERTRAIN",
			"1-PETROL/ DIESEL ENGINE(BASE ENGINEERING)",
			"D-05-VALVE TRAIN SYSTEM/TIMING DRIVE",
			"01-05-VALVE TRAIN SYSTEM/TIMING DRIVE"
		};
		struct PTModule_attr P1E01 = {"P-POWERTRAIN",
			"1-PETROL/ DIESEL ENGINE(BASE ENGINEERING)",
			"E-07-FUEL INJECTION  & COMBUSTION SYSTEM (PETROL, CNG)",
			"01-07-FUEL INJECTION  & COMBUSTION SYSTEM (PETROL, CNG)"
		};
		struct PTModule_attr P1F01 = {"P-POWERTRAIN",
			"1-PETROL/ DIESEL ENGINE(BASE ENGINEERING)",
			"F-09-AIR INTAKE SYSTEM& BREATHING SYSTEM (ENGINE MOUNTED)",
			"01-09-AIR INTAKE SYSTEM& BREATHING SYSTEM (ENGINE MOUNTED)"
		};
		struct PTModule_attr P1G01 = {"P-POWERTRAIN",
			"1-PETROL/ DIESEL ENGINE(BASE ENGINEERING)",
			"G-13-ENGINE MOUNTED AIR COMPRESSOR",
			"01-13-ENGINE MOUNTED AIR COMPRESSOR"
		};
		struct PTModule_attr P1H01 = {"P-POWERTRAIN",
			"1-PETROL/ DIESEL ENGINE(BASE ENGINEERING)",
			"H-14-EGR & BOOSTING SYSTEM (VALVE/COOLER/BY PASS & TURBOCHARGING)",
			"01-14-EGR & BOOSTING SYSTEM (VALVE/COOLER/BY PASS & TURBOCHARGING)"
		};
		struct PTModule_attr P1I01 = {"P-POWERTRAIN",
			"1-PETROL/ DIESEL ENGINE(BASE ENGINEERING)",
			"I-15-SENSORS/ACTUATORS/AUXILIARY DRIVE SYSTEM (FEAD)",
			"01-15-SENSORS/ACTUATORS/AUXILIARY DRIVE SYSTEM (FEAD)"
		};
		struct PTModule_attr P1J01 = {"P-POWERTRAIN",
			"1-PETROL/ DIESEL ENGINE(BASE ENGINEERING)",
			"J-18-LUBRICATION SYSTEM (OIL PUMP/FILTER/COOLER/REED VALVE ETC.)",
			"01-18-LUBRICATION SYSTEM (OIL PUMP/FILTER/COOLER/REED VALVE ETC.)"
		};
		struct PTModule_attr P1K01 = {"P-POWERTRAIN",
			"1-PETROL/ DIESEL ENGINE(BASE ENGINEERING)",
			"K-20-COOLING SYSTEM (BASE ENGINE)",
			"01-20-COOLING SYSTEM (BASE ENGINE)"
		};
		struct PTModule_attr P1L01 = {"P-POWERTRAIN",
			"1-PETROL/ DIESEL ENGINE(BASE ENGINEERING)",
			"L-22-ENGINE OIL, MOUNTS, LIFTING HOOK, NUMBER PLATE",
			"01-22-ENGINE OIL, MOUNTS, LIFTING HOOK, NUMBER PLATE"
		};
		struct PTModule_attr P1M01 = {"P-POWERTRAIN",
			"1-PETROL/ DIESEL ENGINE(BASE ENGINEERING)",
			"M-23-AC COMPRESSOR, POWER STEERING PUMP BRACKET",
			"01-23-AC COMPRESSOR, POWER STEERING PUMP BRACKET"
		};
		struct PTModule_attr P1N01 = {"P-POWERTRAIN",
			"1-PETROL/ DIESEL ENGINE(BASE ENGINEERING)",
			"N-25-CLUTCH SYSTEM",
			"01-25-CLUTCH SYSTEM"
		};
		struct PTModule_attr P2A01 = {"P-POWERTRAIN",
			"2-PETROL/ DIESEL ENGINE(VEHICLE APPLICATION)",
			"A-50-COOLING SYSTEM (VEHICLE LEVEL)",
			"01-50-COOLING SYSTEM (VEHICLE LEVEL)"
		};
		struct PTModule_attr P2B01 = {"P-POWERTRAIN",
			"2-PETROL/ DIESEL ENGINE(VEHICLE APPLICATION)",
			"B-21-AIR INTAKE SYSTEM (VEHICLE LEVEL/REMOTE MOUNTED)",
			"01-21-AIR INTAKE SYSTEM (VEHICLE LEVEL/REMOTE MOUNTED)"
		};
		struct PTModule_attr P2C01 = {"P-POWERTRAIN",
			"2-PETROL/ DIESEL ENGINE(VEHICLE APPLICATION)",
			"C-16-EMS CALIBRATION CONTROL: DIESEL/PETROL",
			"01-16-EMS CALIBRATION CONTROL: DIESEL/PETROL"
		};
		struct PTModule_attr P3A01 = {"P-POWERTRAIN",
			"3-TRANSMISSION AND DRIVELINES",
			"A-26-COMPLETE TRANSAXLE ASSEMBLY",
			"01-26-COMPLETE TRANSAXLE ASSEMBLY"
		};

		if(tc_strstr(substr, "P") !=0 )
		{
			if(tc_strcmp(substr, "P1A01") == 0)
			{
				ifail = stamp_values(rev_tag, module_address, P1A01.PT_aggr_grp, P1A01.PT_aggr, P1A01.PT_module_grp, P1A01.PT_module);
			}
			else if (tc_strcmp(substr, "P1B01") == 0)
			{
				ifail = stamp_values(rev_tag, module_address, P1B01.PT_aggr_grp, P1B01.PT_aggr, P1B01.PT_module_grp, P1B01.PT_module);
			}
			else if (tc_strcmp(substr, "P1C01") == 0)
			{
				ifail = stamp_values(rev_tag, module_address, P1C01.PT_aggr_grp, P1C01.PT_aggr, P1C01.PT_module_grp, P1C01.PT_module);
			}
			else if (tc_strcmp(substr, "P1D01") == 0)
			{
				ifail = stamp_values(rev_tag, module_address, P1D01.PT_aggr_grp, P1D01.PT_aggr, P1D01.PT_module_grp, P1D01.PT_module);
			}
			else if (tc_strcmp(substr, "P1E01") == 0)						
			{
				ifail = stamp_values(rev_tag, module_address, P1E01.PT_aggr_grp, P1E01.PT_aggr, P1E01.PT_module_grp, P1E01.PT_module);
			}
			else if (tc_strcmp(substr, "P1F01") == 0)
			{
				ifail = stamp_values(rev_tag, module_address, P1F01.PT_aggr_grp, P1F01.PT_aggr, P1F01.PT_module_grp, P1F01.PT_module);
			}
			else if (tc_strcmp(substr, "P1G01") == 0)
			{
				ifail = stamp_values(rev_tag, module_address, P1G01.PT_aggr_grp, P1G01.PT_aggr, P1G01.PT_module_grp, P1G01.PT_module);
			}
			else if (tc_strcmp(substr, "P1H01") == 0)
			{
				ifail = stamp_values(rev_tag, module_address, P1H01.PT_aggr_grp, P1H01.PT_aggr, P1H01.PT_module_grp, P1H01.PT_module);
			}
			else if (tc_strcmp(substr, "P1I01") == 0)
			{
				ifail = stamp_values(rev_tag, module_address, P1I01.PT_aggr_grp, P1I01.PT_aggr, P1I01.PT_module_grp, P1I01.PT_module);
			}
			else if (tc_strcmp(substr, "P1J01") == 0)
			{
				ifail = stamp_values(rev_tag, module_address, P1J01.PT_aggr_grp, P1J01.PT_aggr, P1J01.PT_module_grp, P1J01.PT_module);
			}
			else if (tc_strcmp(substr, "P1K01") == 0)
			{
				ifail = stamp_values(rev_tag, module_address, P1K01.PT_aggr_grp, P1K01.PT_aggr, P1K01.PT_module_grp, P1K01.PT_module);
			}
			else if (tc_strcmp(substr, "P1L01") == 0)
			{
				ifail = stamp_values(rev_tag, module_address, P1L01.PT_aggr_grp, P1L01.PT_aggr, P1L01.PT_module_grp, P1L01.PT_module);
			}
			else if (tc_strcmp(substr, "P1M01") == 0)
			{
				ifail = stamp_values(rev_tag, module_address, P1M01.PT_aggr_grp, P1M01.PT_aggr, P1M01.PT_module_grp, P1M01.PT_module);
			}
			else if (tc_strcmp(substr, "P1N01") == 0)
			{
				ifail = stamp_values(rev_tag, module_address, P1N01.PT_aggr_grp, P1N01.PT_aggr, P1N01.PT_module_grp, P1N01.PT_module);
			}
			else if (tc_strcmp(substr, "P2A01") == 0)
			{
				ifail = stamp_values(rev_tag, module_address, P2A01.PT_aggr_grp, P2A01.PT_aggr, P2A01.PT_module_grp, P2A01.PT_module);
			}
			else if (tc_strcmp(substr, "P2B01") == 0)
			{
				ifail = stamp_values(rev_tag, module_address, P2B01.PT_aggr_grp, P2B01.PT_aggr, P2B01.PT_module_grp, P2B01.PT_module);
			}
			else if (tc_strcmp(substr, "P2C01") == 0)
			{
				ifail = stamp_values(rev_tag, module_address, P2C01.PT_aggr_grp, P2C01.PT_aggr, P2C01.PT_module_grp, P2C01.PT_module);
			}
			else if(tc_strcmp(substr, "P3A01") == 0)
			{
				ifail = stamp_values(rev_tag, module_address, P3A01.PT_aggr_grp, P3A01.PT_aggr, P3A01.PT_module_grp, P3A01.PT_module);
			}
			else
			{
				printf("\nNo attr_value available for this module...!!");
				printf("\n********************************************\n");
				fprintf(output, "No value available\n");
				return 0;
			}
		}
		else
		{
			printf("\nIt's not a powertrain Module...!!\n");
			printf("\n*********************************\n");
			fprintf(output, "Not PT Module\n");
			return 0;
		}
		
	}
	return ifail;
}

/********************************************************************************************
    Function:       stamp_values
    Description:    This function takes module_attr values as input and stamp it on module
					revision.
********************************************************************************************/
int stamp_values(tag_t rev_tag, char* PT_module_address, char* PT_aggr_grp, char* PT_aggr, char* PT_module_grp, char* PT_module)
{
	int				j;
	char			PT_module_name[100]				= "";
	char			*PT_ModuleType					= "PLATFORM";
	char			*PT_Platform					= "X4";

	for(j=3; j<strlen(PT_module); j++)
	{
		PT_module_name[j-3] = PT_module[j];
	}
	PT_module_name[j-3] = '\0';
	printf("\nPT_module_name:%s", PT_module_name);

	ifail = AOM_refresh (rev_tag, 1);

	ifail = AOM_UIF_set_value (rev_tag, "t5_AggregateGroup", PT_aggr_grp);
	ifail = AOM_UIF_set_value (rev_tag, "t5_Aggregate", PT_aggr);
	ifail = AOM_UIF_set_value (rev_tag, "t5_Module_Group", PT_module_grp);
	ifail = AOM_UIF_set_value (rev_tag, "t5_Module", PT_module);
	ifail = AOM_UIF_set_value (rev_tag, "t5_ModuleName", PT_module_name);
	ifail = AOM_UIF_set_value (rev_tag, "t5_ModuleAddress", PT_module_address);
	ifail = AOM_UIF_set_value (rev_tag, "t5_ModuleType", PT_ModuleType);
	ifail = AOM_UIF_set_value (rev_tag, "t5_Platform", PT_Platform);

	ifail = AOM_save_without_extensions (rev_tag);
	ifail = AOM_refresh (rev_tag, 0);
	if(ifail == ITK_ok)
	{
		printf("\nAttribute Value stamped....!!\n");
		ifail = write_into_file(PT_aggr_grp, PT_aggr, PT_module_grp, PT_module, PT_module_name, PT_module_address, PT_ModuleType, PT_Platform);
		printf("\n*****************************\n");
	}
	else
	{
		printf("\nFailed to stamp Attribute value...!!\n");
		printf("\n************************************\n");
		return ifail;
	}
	return ifail;	
}

/********************************************************************************************
    Function:       write_into_file
    Description:    This function takes module_attr values as input from previous function and 
					write it into the file.(newly created)
********************************************************************************************/
int write_into_file(char* PT_aggr_grp, char* PT_aggr, char* PT_module_grp, char* PT_module, char* PT_module_name, char* PT_module_address, char* PT_ModuleType, char* PT_Platform)
{
	int			ifail 				= ITK_ok;
	
	char 		*test2 				= (char*)MEM_alloc(sizeof(char) * 500);
	char		*final2				= (char*)MEM_alloc(sizeof(char) * 500);

	tc_strcpy(test2, "");
	tc_strcpy(test2,sep);
	tc_strcat(test2,PT_aggr_grp);
	tc_strcat(test2,sep);
	tc_strcat(test2,PT_aggr);
	tc_strcat(test2,sep);
	tc_strcat(test2,PT_module_grp);
	tc_strcat(test2,sep);
	tc_strcat(test2,PT_module);
	tc_strcat(test2,sep);
	tc_strcat(test2,PT_module_name);
	tc_strcat(test2,sep);
	tc_strcat(test2,PT_module_address);
	tc_strcat(test2,sep);
	tc_strcat(test2,PT_ModuleType);
	tc_strcat(test2,sep);
	tc_strcat(test2,PT_Platform);

	tc_strcpy(final2,test2);
	
	fprintf(output,"%s\n",final2);	
	
	MEM_free(test2);	
	MEM_free(final2);	
	
	return ifail;
}
