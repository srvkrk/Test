/*=============================================================================
                Copyright (c) 2003-2005 UGS Corporation
                   Unpublished - All Rights Reserved
===============================================================================
File description:
    An example program to show listing a bill of materials using the BOM module
 */

#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tccore/aom_prop.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <pie/pie.h>
#include <tccore/tctype.h>
#include <tccore/aom.h>
#include <sa/sa.h>
#include <fclasses/tc_date.h>
#include <time.h>
#define Debug TRUE
#define ITK_CALL(X)                                                     \
                if(Debug)                                                               \
                {                                                                               \
                        printf(#X);                                                     \
                }                                                                               \
                fflush(NULL);                                                   \
                status=X;                                                               \
                if (status != ITK_ok )                                  \
                {                                                                               \
                        int                             index = 0;                      \
                        int                             n_ifails = 0;           \
                        const int*              severities = 0;         \
                        const int*              ifails = 0;                     \
                        const char**    texts = NULL;           \
                                                                                                \
                        EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);               \
                        printf("\t%3d error(s)\n", n_ifails);                                                   \
                        for( index=0; index<n_ifails; index++)                                                  \
                        {                                                                                                                               \
                                printf("\tError #%d, %s\n", ifails[index], texts[index]);       \
                        }                                                                                                                               \
                        return status;                                                                                                  \
                }                                                                                                                                       \
                else                                                                    \
                {                                                                               \
                        if(Debug)                                                       \
                        printf("\tSUCCESS\n");                          \
                }

/* this sequence is so common */
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

//static int PrintErrorStack( void )
///*
//*
//* PURPOSE : Function to dump the ITK error stack
//*
//* RETURN : causes program termination. If you made it here
//*          you're not coming back modified for cust.c to not call exit()
//*          but to just print the error stack
//*
//* NOTES : This version will always return ITK_ok, which is quite strange
//*           actually. But if the error reporting was "OK" then that makes
//*           sense
//*
//*/
//{
//    int iNumErrs = 0;
//    int *pSevLst = NULL;
//    int *pErrCdeLst = NULL;
//    char **pMsgLst = NULL;
//    register int i = 0;
//
//    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
//    fprintf( stderr, "Checkout Error(s): \n");
//	Write_To_Log("Checkout Error(s): \n");
//    for ( i = 0; i < iNumErrs; i++ )
//    {
//        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
//		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
//        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
//		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
//    }
////    	 919003: error_919003, "Modification Description"
////	 919003: error_919003, "Modification Description"
////	 919003: error_919003, "Part Type"
////	 919003: error_919003, "Part Type"
////	 919099: error_919099, "CAP_FOR_PISTON_ROD_PRT", "A", "2"
////	 919099: error_919099, "CAP_FOR_PISTON_ROD_PRT", "A", "2"
//
//    return ITK_ok;
//}

/*static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute, qunt_attribute, refjt_attribute;

static void initialise (void);
static void initialise_attribute (char *name,  int *attribute);
static int my_compare_function (tag_t line_1, tag_t line_2, void *client_data);*/


/*-------------------------------------------------------------------------------*/

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
        int i;
        char *retStringf;
        retStringf = (char*) malloc(3);
        for(i=0; i < toCharf; i++ )
        *(retStringf+i) = *(mainStringf+i+fromCharf);
        *(retStringf+i) = '\0';
        return retStringf;
}
int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

void getNextDate(char *DatetoConvert,char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int ch1;
	int Monthas;
	int ch;

	time_t	temp;

    date_t DayTommorow ;

 	struct tm *timeptr;
	struct tm *timeptr1;

	char pAccessDate[20];
	char pAccessDate1[20];
	char DateS[20];
	char CCMonth[30];

	char* strDay;
	char* strMon;
	char* strYear;
	char* cMonth ;

	temp = time(NULL);

	tc_strcpy(pAccessDate,"");

	//	timeptr = (struct tm *)localtime(&temp);
	//	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	//	day=timeptr->tm_mday;
	//	month=(timeptr->tm_mon)+1;
	//	year=(timeptr->tm_year+1900);

    strYear =  strtok(DatetoConvert,"/"); //1
    cMonth  =  strtok(NULL,"'/'"); //2
    strDay  =  strtok(NULL,"'/'"); //3
    Monthas =  atoi(cMonth);
	
	getMonth(Monthas,CCMonth);

	printf("\n strYear:%s\n",strYear); fflush(stdout);
	printf("\n CCMonth:%s\n",CCMonth); fflush(stdout);
	printf("\n strDay:%s\n",strDay); fflush(stdout);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,CCMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	
	printf("\n cnextAccessDate:%s\n",cnextAccessDate); fflush(stdout);
}
extern int ITK_user_main (int argc, char ** argv )
{
	int ifail;
	int status;
	int n_tags_found = 0;
	int n_entries = 2;
	int resultCount = 0;
	int j = 0;
	int status_count = 0;
	int count_rev = 0;
	int ii = 0;

	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));

	//char* inputfile=NULL;
	char* inputline=NULL;
	char* req_item=NULL;
	char* item_revision_id=NULL;
	char* item_sequence_id=NULL;
	char* itemRevSeq=NULL;
	char* itemRevSeq2=NULL;
	char* ItemRevStr=NULL;
	char* ReleaseStatus=NULL;
	char* effectivityDate=NULL;
	char* DReffectivityDate=NULL;
	char* releasedDate=NULL;
	char* DRreleasedDate=NULL;
	char* DRreleasedDate2=NULL;
	char* effectivityDateTmp=NULL;
	char* DReffectivityDateTmp=NULL;
	char* releasedDateTmp=NULL;
	char* DRreleasedDateTmp=NULL;
	char* rel_status = NULL;

	char RelDate[20]={0};

	date_t Rel_date_t;
	date_t DR_Rel_date_t;
	date_t DR_Rel_date_t2;
	date_t RelDate_tag;
	date_t DRRelDate_tag;

	tag_t *itemMstrTag = NULL;
	tag_t *rev_list = NULL;
	//tag_t *tags_found = NULL;
	tag_t* status_list=NULLTAG;

	//tag_t item_tag = NULLTAG;
	//tag_t latestRev = NULLTAG;
	tag_t item_rev_tag = NULLTAG;
	tag_t queryTag = NULLTAG;
	tag_t statuslist = NULLTAG;

	//FILE *fp = NULL;

	logical date_is_valid =false;
	logical date_is_validDR =false;


	//(void)argc;
	//(void)argv;

	//initialise();

	//inputfile = ITK_ask_cli_argument("-i=");

	//printf("\nInput inputfile: %s \n",inputfile);fflush(stdout);

	//printf("\nInput inputfile: %s \n",inputfile);fflush(stdout);
	
	inputline = ITK_ask_cli_argument("-i=");

	tag_t object_create_input_tag = NULLTAG;
	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));

	if(ITK_auto_login() == ITK_ok)	
	{
		
	ITK_CALL(ITK_set_bypass(true));
	//fp=fopen(inputfile,"r");
	//if(fp != NULL)
	//{
		//inputline=(char *) MEM_alloc(50);
		//while(fgets(inputline,50,fp)!=NULL)
		//{
			int ERCRevRlzCntFlag=0;
			int status_count=0;
			int ss=0;
			int ERCReviewStatusFlg=0;
			int creationDateFlag=0;
			int ERCRlzCntFlag=0;
			int ERCReviwCntFlag=0;
			int APLSTDRlzFlag=0;
			tag_t* relStatus_list;
			tag_t propEff_tag =NULLTAG;
			tag_t propDtReleased_tag =NULLTAG;
			char* Rel_Status = NULL;
			char* latest_rev_Rel_Stus = NULL;
			char* value =NULL;
			char* valueDtRzld =NULL;
			char* ItemRevDtRzld=NULL;
			char* RevCreationDt =NULL;
			date_t status_Rel_date_t;
			date_t ItemRev_Rel_date_t;
			tag_t owning_user = NULLTAG;
			char* userid = NULL;

			effectivityDateTmp =(char *) MEM_alloc(20);
			DReffectivityDateTmp =(char *) MEM_alloc(20);
			releasedDateTmp =(char *) MEM_alloc(20);
			DRreleasedDateTmp =(char *) MEM_alloc(20);


			//fputs(inputline,stdout);
			req_item=strtok(inputline,"^");

			printf("\n\n------------------------------------------Input item_id: [%s]  req_item: [%s]",inputline,req_item);fflush(stdout);

			attrs[0] ="item_id";
			values[0] = (char *)req_item;
			ifail = ITEM_find_items_by_key_attributes(1, (const char **)attrs, (const char **)values, &resultCount, &itemMstrTag);
			CHECK_FAIL;

			printf ("\n Queried Design Matsers count:  %d",resultCount);fflush(stdout);

			if(resultCount>0)
			{
				MEM_free(attrs);
				MEM_free(values);

				if(ITEM_list_all_revs (itemMstrTag[0], &count_rev, &rev_list)!=ITK_ok);

				printf ("\n Total rev found: %d",count_rev);fflush(stdout);

				for(j=0; j<count_rev; j++)
				{
					item_rev_tag = rev_list[j];

					if(AOM_ask_value_string(item_rev_tag,"item_revision_id",&ItemRevStr)!=ITK_ok);

					if( AOM_ask_owner( item_rev_tag, &owning_user )!=ITK_ok);
					if( SA_ask_user_identifier2(owning_user,&userid)!=ITK_ok);

					printf("\n\n %s^%s^%s^",req_item,ItemRevStr,userid); fflush(stdout);

					if(AOM_UIF_ask_value (item_rev_tag, "release_status_list", &rel_status)!=ITK_ok);


					if(WSOM_ask_release_status_list(item_rev_tag, &status_count, &relStatus_list) != ITK_ok);
					if (status_count > 0)
					{
						ERCRlzCntFlag=0;
						ERCReviwCntFlag=0;
						APLSTDRlzFlag=0;
						for(ss=0; ss<status_count ; ss++)
						{
							if(AOM_ask_value_string(relStatus_list[ss],"object_name",&Rel_Status)!=ITK_ok);
							if (tc_strcmp(Rel_Status,"T5_LcsReview")==0)
							{
								ERCReviwCntFlag=1;
							}
							if (tc_strcmp(Rel_Status,"T5_LcsErcRlzd")==0)
							{
								ERCRlzCntFlag++;
								ERCReviwCntFlag=0;
								break;
							}
						}
						latest_rev_Rel_Stus = (char *) MEM_alloc(20);
						if(ERCReviwCntFlag==1)
						{
							tc_strcpy(latest_rev_Rel_Stus,"");
							tc_strcpy(latest_rev_Rel_Stus,"T5_LcsReview");
						}
						if(ERCRlzCntFlag>0)
						{
							tc_strcpy(latest_rev_Rel_Stus,"");
							tc_strcpy(latest_rev_Rel_Stus,"T5_LcsErcRlzd");
						}
						for(ss=0; ss<status_count ; ss++)
						{
							if(AOM_ask_value_string(relStatus_list[ss],"object_name",&Rel_Status)!=ITK_ok);
							printf("\n\t Rel_Status: %s",Rel_Status);fflush(stdout);

							if ((tc_strstr(Rel_Status,"Apl")!=NULL) || (tc_strstr(Rel_Status,"APL")!=NULL)|| (tc_strstr(Rel_Status,"Std")!=NULL)|| (tc_strstr(Rel_Status,"STD")!=NULL))
							{
								APLSTDRlzFlag=1;
								printf("----skipping this release status"); fflush(stdout);
								continue;
							}
							else if ((tc_strcmp(Rel_Status,"T5_LcsReview")==0) && (ERCRlzCntFlag>0))
							{
								printf("----skipping this as ERC Released status is present.."); fflush(stdout);
								continue;
							}

							//if(ITK_ok != (ifail = PROP_ask_property_by_name(relStatus_list[ss],"effectivity_text",&propEff_tag)))return ifail;
							//if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail;
							if(ITK_ok != (ifail = AOM_UIF_ask_value(relStatus_list[ss],"effectivity_text",&value)))return ifail;

							ITK_CALL(ITK_set_bypass(true));
							if (AOM_ask_value_date(relStatus_list[ss],"date_released",&status_Rel_date_t)!=ITK_ok);
							if (ITK_date_to_string(status_Rel_date_t, &valueDtRzld)!=ITK_ok);
							printf("\t --effectivity_text is value : [%s]    --valueDtRzld: %s",value,valueDtRzld); fflush(stdout);

							
							if (AOM_ask_value_date(item_rev_tag,"date_released",&ItemRev_Rel_date_t)!=ITK_ok);
							if (ITK_date_to_string(ItemRev_Rel_date_t, &ItemRevDtRzld)!=ITK_ok);
							printf("\t --effectivity_text is value : [%s]    --ItemRevDtRzld: %s",value,ItemRevDtRzld); fflush(stdout);
							if (tc_strcmp(valueDtRzld,ItemRevDtRzld)!=0)
							{
								tag_t attr_idDR1 = NULLTAG;
								ITK_CALL(ITK_set_obj_edited_in_ic_context(item_rev_tag));
							 ITK_CALL(AOM_lock(item_rev_tag));
							 ITK_CALL (POM_attr_id_of_attr("date_released", "Design_0_Revision_alt", &attr_idDR1));
							 ITK_CALL(AOM_refresh(item_rev_tag,TRUE));
							ITK_CALL(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
							ITK_CALL(POM_set_attr_date(1,&item_rev_tag,attr_idDR1,status_Rel_date_t));
						  // ITK_CALL(AOM_set_value_date	(item_rev_tag,"date_released",status_Rel_date_t));
							ITK_CALL(AOM_save_without_extensions(item_rev_tag));
							ITK_CALL(AOM_unlock(item_rev_tag));
							}
						}
					}
				}
			}
			else
			{
				printf("\n\t Item Revision not Found for [%s :: %s]",req_item,itemRevSeq); fflush(stdout);
				//continue;
			}
			//printf("\n----------------------------------------------------\n");
		//} //while loop end
	//} // fp pointer if condn end
	}
	
    printf ("\n================================================\n");

    ITK_exit_module(true);

    return 0;
}

/*-------------------------------------------------------------------------------*/

/*static int my_compare_function (tag_t line_1, tag_t line_2, void * client_data)
{
    char *seq1, *seq2;
    int ifail, result;
    (void)client_data;
    ifail = BOM_line_ask_attribute_string (line_1, seqno_attribute, &seq1);
    CHECK_FAIL;
    ifail = BOM_line_ask_attribute_string (line_2, seqno_attribute, &seq2);
    CHECK_FAIL;
    if (seq1 == NULL || seq2 == NULL)
      result = 0;
    else
      result = strcmp (seq2, seq1); 
    MEM_free (seq1);
    MEM_free (seq2);
    return result;
}*/

/*-------------------------------------------------------------------------------*/

/*static void initialise (void)
{
    int ifail;

    if ((ifail = ITK_auto_login()) != ITK_ok)
       fprintf(stderr,"Login fail !!: Error code = %d \n\n",ifail);
    CHECK_FAIL;

    initialise_attribute (bomAttr_lineName, &name_attribute);
    initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
    initialise_attribute (bomAttr_occQty, &qunt_attribute);
    //initialise_attribute (bomAttr_JTDatasetTag , &refjt_attribute);
    ifail = BOM_line_look_up_attribute (bomAttr_lineParentTag, &parent_attribute);
    CHECK_FAIL;
    ifail = BOM_line_look_up_attribute (bomAttr_lineItemTag, &item_tag_attribute);
    CHECK_FAIL;
        ifail = BOM_line_look_up_attribute (bomAttr_JTDatasetTag, &refjt_attribute);
    CHECK_FAIL;
}*/

/*-------------------------------------------------------------------------------*/

/*static void initialise_attribute (char *name,  int *attribute)
{
    int ifail, mode;

    ifail = BOM_line_look_up_attribute (name, attribute);
    CHECK_FAIL;
    ifail = BOM_line_ask_attribute_mode (*attribute, &mode);
    CHECK_FAIL;
    if (mode != BOM_attribute_mode_string)
      { printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode);
        exit(0);
      }
}*/
