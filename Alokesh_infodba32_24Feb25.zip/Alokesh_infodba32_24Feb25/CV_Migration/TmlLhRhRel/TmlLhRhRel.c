/*****************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Rupali Rane
*  Module		 :   TCUA Proe Uploader
*  Code			 :   TmlLhRhRel.c
*  Created on	 :   Sep 27, 2016
*
*
* Modification History :
* S.No  Date			CR No	Modified By					Modification Notes
*
*
******************************************************************************************************************/
#define TE_MAXLINELEN  128
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

FILE* fp=NULL;

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	fprintf(stderr,"Login fail !!: Error code = %d \n\n",ifail);
	CHECK_FAIL;
}
extern int ITK_user_main (int argc, char ** argv )
{
    int status;
	int n_items_lh;
	int n_items_rh;
	int MstrCntLh = 0;
	int MstrCntRh = 0;
	int result = 0;
	int i=0;
	int n_attchs_lh = 0;
	int n_attchs_rh = 0;
	int LhDatasetFoundFlag = 0;
	int RhDatasetFoundFlag = 0;

	char* inputline=NULL;
	char *inputfile=NULL;
	char *LeftPrtInd = NULL;
	char *LeftPrt = NULL;
	char *RightPrtInd = NULL;
	char *RightPrt = NULL;
	char *LeftPrtRev = NULL;
	char *LeftPrtSeq = NULL;
	char *itemRevSeq = NULL;

	tag_t *lh_item_tag = NULLTAG;
	tag_t *rh_item_tag = NULLTAG;
	tag_t *SecObjs_lh = NULLTAG;
	tag_t *SecObjs_rh = NULLTAG;
	tag_t *SecObjs_lh2 = NULLTAG;
	tag_t *SecObjs_rh2 = NULLTAG;
	tag_t tRelation = NULLTAG;
	tag_t relationLH = NULLTAG;
	tag_t relationRH = NULLTAG;
	tag_t LeftRev = NULLTAG;
	tag_t RightRev = NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t secObjLhTypeTag = NULLTAG;
	tag_t secObjRhTypeTag = NULLTAG;
	tag_t LHItemDataSettag = NULLTAG;
	tag_t RHItemDataSettag = NULLTAG;
	tag_t tRel_CreoMerge = NULLTAG;
	tag_t FndrelationL = NULLTAG;
	tag_t FndrelationR = NULLTAG;
	tag_t relationCM = NULLTAG;

	WSO_search_criteria_t criteria;

	char* type_name = NULL ;
	char* type_name2 = NULL;
	char* type_name3 = NULL;

//	ITK_CALL(ITK_init_module("loader" ,"loader7","dba")!=ITK_ok) ;
//	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
//	ITK_CALL(ITK_auto_login( ));
//	ITK_CALL(ITK_set_journalling( TRUE ));

	initialise();

	inputfile = ITK_ask_cli_argument("-i=");

	fp = fopen( inputfile, "r" );

	if(fp!=NULL)
	{
		inputline=(char *) MEM_alloc(100);
		while(fgets(inputline,100,fp)!=NULL)
		{
			printf("\n---------------------------------------------------------------------------------------------------\n"); fflush(stdout);

			n_items_lh=0;
			n_items_rh=0;

			fputs(inputline,stdout);

			LeftPrtInd=strtok(inputline,"^");
			LeftPrt=strtok(NULL,"^");
			RightPrtInd=strtok(NULL,"^");
			RightPrt=strtok(NULL,"^");
			LeftPrtRev=strtok(NULL,"^");
			LeftPrtSeq=strtok(NULL,"^");

			printf("LeftPrtInd:[%s] LeftPrt:[%s] [%s , %s] RightPrtInd:[%s] RightPrt:[%s]",LeftPrtInd,LeftPrt,LeftPrtRev,LeftPrtSeq,RightPrtInd,RightPrt); fflush(stdout);

			if((LeftPrt!=NULL) && (RightPrt!=NULL))
			{
				if (tc_strstr(LeftPrtInd,"LH") !=NULL)
				{
					printf("\n\t ..1.."); fflush(stdout);

					WSOM_clear_search_criteria(&criteria);
					strcpy(criteria.name,LeftPrt);
					strcpy(criteria.class_name,"Design");
					WSOM_search(criteria,&n_items_lh,&lh_item_tag);
				}
				else if (tc_strstr(RightPrtInd,"LH") !=NULL)
				{
					printf("\n\t ..2.."); fflush(stdout);

					WSOM_clear_search_criteria(&criteria);
					strcpy(criteria.name,RightPrt);
					strcpy(criteria.class_name,"Design");
					WSOM_search(criteria,&n_items_lh,&lh_item_tag);
				}
				else
				{
					n_items_lh=0;
				}

				if (tc_strstr(RightPrtInd,"RH") !=NULL)
				{
					printf("\n\t ..3.."); fflush(stdout);

					WSOM_clear_search_criteria(&criteria);
					strcpy(criteria.name,RightPrt);
					strcpy(criteria.class_name,"Design");
					WSOM_search(criteria,&n_items_rh,&rh_item_tag);
				}
				else if (tc_strstr(LeftPrtInd,"RH") !=NULL)
				{
					printf("\n\t ..4.."); fflush(stdout);

					WSOM_clear_search_criteria(&criteria);
					strcpy(criteria.name,LeftPrt);
					strcpy(criteria.class_name,"Design");
					WSOM_search(criteria,&n_items_rh,&rh_item_tag);
				}
				else
				{
					n_items_rh=0;
				}

				printf("\n\t Count n_items LH:[%d]  \t RH: [%d]",n_items_lh,n_items_rh);fflush(stdout);

				if((n_items_lh > 0) && (n_items_rh > 0))
				{
					GRM_find_relation_type("T5_LRReln",&tRelation);
					if(tRelation != NULLTAG)
					{
						GRM_list_secondary_objects_only (lh_item_tag[0],tRelation,&MstrCntLh,&SecObjs_lh);
						GRM_list_secondary_objects_only (rh_item_tag[0],tRelation,&MstrCntRh,&SecObjs_rh);

						printf("\n\t Count MstrCntLh: [%d] \t MstrCntRh: [%d]",MstrCntLh, MstrCntRh);fflush(stdout);

						if(MstrCntLh <= 0)
						{
							printf("\n\t 1.T5_LRReln NOT Available.......");fflush(stdout);
							GRM_create_relation(lh_item_tag[0],rh_item_tag[0],tRelation,NULLTAG,&relationLH);
							GRM_save_relation(relationLH);
							printf("\n\t 1.relationLH between Design Master is Created & save sucessfully");
						}
						else
						{
							printf("\n\t 1.T5_LRReln is already available."); fflush(stdout);
						}

						if(MstrCntRh <= 0)
						{
							printf("\n\t 2.T5_LRReln NOT Available.......");fflush(stdout);
							GRM_create_relation(rh_item_tag[0],lh_item_tag[0],tRelation,NULLTAG,&relationRH);
							GRM_save_relation(relationRH);
							printf("\n\t 2.relationRH between Design Master is Created & save sucessfully\n");
						}
						else
						{
							printf("\n\t 2.T5_LRReln is already available.\n"); fflush(stdout);
						}
					}

					if((LeftPrtRev!=NULL) && (LeftPrtSeq!=NULL)&&(tc_strstr(LeftPrtRev,"")==NULL)&&(tc_strstr(LeftPrtRev,"null")==NULL))
					{
						itemRevSeq = NULL;
						itemRevSeq=(char *) MEM_alloc(32);
						strcpy(itemRevSeq,LeftPrtRev);
						strcat(itemRevSeq,";");
						strcat(itemRevSeq,LeftPrtSeq);
						//printf("2.itemRevSeq concated is --->%s\n\n",itemRevSeq);

						ITK_CALL(ITEM_find_revision(lh_item_tag[0],itemRevSeq,&LeftRev));
						ITK_CALL(ITEM_find_revision(rh_item_tag[0],itemRevSeq,&RightRev));

						if((LeftRev != NULLTAG) && (RightRev != NULLTAG))
						{
							result = GRM_find_relation_type("IMAN_specification", &relation_type);
							printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

							if(relation_type != NULLTAG)
							{
								if(GRM_list_secondary_objects_only(LeftRev , relation_type ,&n_attchs_lh,&SecObjs_lh2));
								printf("  1.item_tag SecObjs_lh2 list n_attchs_lh: [%d] \n\t",n_attchs_lh); fflush(stdout);

								if(n_attchs_lh>0)
								{
									for (i=0; i < n_attchs_lh; i++)
									{
										if(TCTYPE_ask_object_type(SecObjs_lh2[i],&secObjLhTypeTag));
										if(TCTYPE_ask_name2(secObjLhTypeTag,&type_name));
										printf("    LH..Part type_name is  :%s \n\t",type_name); fflush(stdout);

										if ((strcmp(type_name,"ProPrt")==0) || (strcmp(type_name,"ProAsm")==0))
										{
											LHItemDataSettag = SecObjs_lh2[i];

											printf("  LH Dataset found attached to Revision \n\t"); fflush(stdout);

											LhDatasetFoundFlag = 1;
											break;
										}
									}
								}

								if(GRM_list_secondary_objects_only(RightRev , relation_type ,&n_attchs_rh,&SecObjs_rh2));
								printf("  1.item_tag SecObjs_rh2 list n_attchs_rh: [%d] \n\t",n_attchs_rh); fflush(stdout);

								if(n_attchs_rh>0)
								{
									for (i=0; i < n_attchs_rh; i++)
									{
										if(TCTYPE_ask_object_type(SecObjs_rh2[i],&secObjRhTypeTag));
										if(TCTYPE_ask_name2(secObjRhTypeTag,&type_name2));
										printf("    RH..Part type_name2 is  :%s \n\t",type_name2); fflush(stdout);

										if ((strcmp(type_name2,"ProPrt")==0) || (strcmp(type_name2,"ProAsm")==0))
										{
											RHItemDataSettag = SecObjs_rh2[i];

											printf("  RH Dataset found attached to Revision \n\t"); fflush(stdout);

											RhDatasetFoundFlag = 1;
											break;
										}
									}
								}

								//if ((LhDatasetFoundFlag==1) || (RhDatasetFoundFlag==1))
								//printf(" LhDatasetFoundFlag:[%d]  \t RhDatasetFoundFlag: [%d]\n",LhDatasetFoundFlag,RhDatasetFoundFlag);fflush(stdout);

								printf(" RhDatasetFoundFlag: [%d]\n",RhDatasetFoundFlag);fflush(stdout);

								if (RhDatasetFoundFlag==1)
								{
									ITK_CALL(GRM_find_relation_type("Pro2_merge",&tRel_CreoMerge )); //Creo merge dependency for LH-RH

									if(tRel_CreoMerge != NULLTAG)
									{
										ITK_CALL(TCTYPE_ask_name2(tRel_CreoMerge,&type_name3));
										printf("\n CreoMerge..type_name3:%s ..............",type_name3);fflush(stdout);
									}

									ITK_CALL( GRM_find_relation( RHItemDataSettag, LeftRev, tRel_CreoMerge ,&FndrelationR));

									if(FndrelationR != NULLTAG)
									{
										printf("\n\t RH..Relation Already Exist.\n\n" ); fflush(stdout);
										//printf("\n\t hence deleting from Right.\n\n" ); fflush(stdout);
										//ITK_CALL(GRM_delete_relation(FndrelationR));
									}
									else
									{
										printf("\t RH..GRM_create_relation before\n");fflush(stdout);
										ITK_CALL(GRM_create_relation(RHItemDataSettag, LeftRev, tRel_CreoMerge, NULLTAG, &relationCM));
										printf("\t RH..GRM_create_relation after\n");fflush(stdout);

										if(relationCM != NULLTAG)
										{
											ITK_CALL(AOM_refresh (RHItemDataSettag,0));
											printf("\t RH..Before GRM_save_relation");fflush(stdout);
											ITK_CALL(GRM_save_relation(relationCM));
											printf("\t RH..After GRM_save_relation");fflush(stdout);
										}
									}

									/*ITK_CALL( GRM_find_relation( LHItemDataSettag, RightRev, tRel_CreoMerge ,&FndrelationL));		//commented on 09.06.2017
									if(FndrelationL != NULLTAG)
									{
										printf("\n\t FndrelationL...Relation Already Exist...hence deleting from left.\n\n" ); fflush(stdout);
										ITK_CALL(GRM_delete_relation(FndrelationL));
									}*/
								} //if (RhDatasetFoundFlag==1)
							} //if(relation_type) //IMAN_specification
						} //if((LeftRev != NULLTAG) && (RightRev != NULLTAG))
					} //if((LeftPrtRev) && (LeftPrtSeq))
				} //if((n_items_lh > 0) && (n_items_rh > 0))
				else
				{
					printf("\n DESIGN NOT FOUND IN DB.\n");fflush(stdout);
				}
			} //if((LeftPrt) && (RightPrt))
			else
			{
				printf("\n DESIGN NOT FOUND\n");fflush(stdout);
			}
		} //while(fgets(inputline,100,fp)!=NULL)
	} //if(fp!=NULL)
	else
	{
		printf("\n Input file [ %s ] NOT FOUND....\n",inputfile); fflush(stdout);
	}

	printf("\n---------------------------------------------------------------------------------------------------\n"); fflush(stdout);

	ITK_CALL(POM_logout(false));
	return status;
}
