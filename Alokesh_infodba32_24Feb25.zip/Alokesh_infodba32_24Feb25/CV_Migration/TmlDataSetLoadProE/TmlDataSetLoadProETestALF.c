/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Rupali Rane
*  Module		 :   TCUA DataSet Uploader
*  Code			 :   DataSetLoad.c
*  Created on	 :   Apr 25th, 2016
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/
#define TE_MAXLINELEN  128
#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

#define Debug TRUE
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

int setAttributesOnItemRev(tag_t* rev,char* desc)
{
	int status;

	printf("\nIn function setAttributesOnItemRev\n");
	//if (AOM_lock(*rev)!=ITK_ok);
	if (AOM_set_value_string(*rev,"object_desc",desc)!=ITK_ok);
	if (AOM_save(*rev)!=ITK_ok);
	//if (AOM_unlock(*rev)!=ITK_ok);
}
static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	fprintf(stderr,"Login fail !!: Error code = %d \n\n",ifail);
	CHECK_FAIL;
}
extern int ITK_user_main (int argc, char ** argv )
{
	int status=0;
	int result = 0;
	int count = 0;
	int iCounter1 = 0;
	int i = 0;
	int x = 0;
	int ref_count;
	int iCountSecondary = 0;
	int nameRef_cnt=0;
	int ii=0, itemcount=0, j=0;
	int sPartNumberTokint=0;
	int c=0 ,t=0;
	int lengthMinus=0;
	int n_attchs=0;
	int n_tags_found = 0;
	int n_entries = 2;
	int n_entries_d = 1;
	int n_found = 1;
	int dd = 0;
	int org_seq_id_int=0;
	int resultCount=0;
	int resultCount_d=0;
	int ref_count_d=0;
	int dataset_RevNo=0;
	int dataset_NewRevNo=0;
	int DatasetFlag=0;
	int DatasetRelFlag = 0;
	int DatasetExistFlag = 0;
	int ApplnOwnerFlag = 0;
	int ALFJtFlag=0;

	char *JTid1_Name =  NULL;
	char *value =  NULL;
	char *argstring1 =  NULL;
	char *argstring2 =  NULL;
	char *argstring3 =  NULL;
	char *user =  NULL;
	char *pass =  NULL;
	char *group =  NULL;
	char *itemId =  NULL;
	char *revisionID =  NULL;
	char *ItmSeqID =  NULL;
	char *ItemDesc = NULL;
	char *JTFileSeq = NULL;
	char *ClassName = NULL;
	char *ClassNmGI = NULL;
	char *SubTypeNm = NULL;
	char *DataItem = NULL;
	char *DataItemTemp = NULL;
	char *DataItemTemp1 = NULL;
	char *ApplnOwner = NULL;
	char *ApplnOwnerStr = NULL;
	char *RevApplnOwner = NULL;
	char *CreatedDate = NULL;
	char *ModifyDate = NULL;
	char *fullPath =  NULL;
	char *VaultLocation = NULL;
	char *HostName = NULL;
	char *Owner = NULL;
	char *ProjectCode = NULL;
	char *vault = NULL;
	char *InDatabase = NULL;
	char *Randomized = NULL;
	char *Superseded = NULL;
	char *Frozen =  NULL;
	char *LifeCycleState = NULL;
	char *FileStatus =  NULL;
	char *Externallymanaged = NULL;
	char *FileRegisteredBy = NULL;
	char *ShadowCopy =  NULL;
	char *Categoryname = NULL;
	char *Sitename =  NULL;
	char *WorkingFileName = NULL;
	char *WorkingpathFormat = NULL;
	char *BulkdataLocation = NULL;
	char *Bulkdata =  NULL;
	char *DataBasename = NULL;
	char *PartSequence = NULL;
	char *Status =  NULL;
	char *relation_input = NULL;
	char *file_type =  NULL;
	char *error_Text =  NULL;
	char *object_type = NULL;
	char *relation_form = NULL;
	char *creation_date = NULL;
	char *text =  NULL;
	char *JtTemp =  NULL;
	char *RevOwnUser =  NULL;

	char line[500] =  {'\0'};
	char pathbuff[1000];
	char result1 [ 10000 ] ;
	char result2 [ 10000 ] ;

	char **ref_list;
	char **ref_list_d;

	char *o = NULL;
	char *f = NULL;
	char *test11 = NULL;
	char *test12 = NULL;
	char *test13 = NULL;
	char *JTid = NULL;
	char *JTid1 = NULL;
	char *JTid2 = NULL;
	char *JTid1Tmp = NULL;
	char *Creator = NULL;
	char *aDatasetId = NULL;
	char *aDatasetRev = NULL;
	char *format=NULL;
	char *StrWeightArrayMain1=NULL;
	char *dataset_name=NULL;
	char *named_ref2=NULL;
	char *named_ref=NULL;
	char *named_refTemp=NULL;
	char *named_refTemp2=NULL;
	char *PdfDataItem=NULL;
	char *PdfDataItem1=NULL;
	char *object_string=NULL;
	char *DataSetNm = NULL;
	char *DataSetNm2 = NULL;
	char *DataSetNm3 = NULL;
	char *DataSetTmp = NULL;
	char *DataSetNmOrg = NULL;
	char *DataSetNmOrgTemp = NULL;
	char *DSTemp1 = NULL;
	char *DSTemp2 = NULL;
	char *DataSetNmOrg3 = NULL;
	char *itemRevSeq = NULL;
	char *itemRevSeq2 = NULL;
	char *ItemRevStr = NULL;
	char *relationstr = NULL;
	char *parent_name = NULL;
	char *partType = NULL;
	char *DatasetDesc = NULL;

	//Ujjawal Kumar
	char *refname2 = NULL;
	AE_reference_type_t     reftype2;
	tag_t refobject2	= NULLTAG;
	char   orig_name2[IMF_filename_size_c + 1];
	char *object_type2=NULL;

	char *inputfile=NULL;
	char *ErrorInputfile=NULL;
	//char *IncreStatus=NULL;
	char *inputline=NULL;
	char *drawingnumber;
	char *drawingtype;
	char *DatasetName;
	char *DatasetType;
	char *DatasetSeq;

	char type_name[TCTYPE_name_size_c+1] ;
	char type_name2[TCTYPE_name_size_c+1];
	char type_name3[TCTYPE_name_size_c+1];

	char **attrs = (char **) MEM_alloc(2 * sizeof(char *));
	char **values = (char **) MEM_alloc(2 * sizeof(char *));

	char **qry_entries = (char **) MEM_alloc(50 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));
	char **qry_values_d = (char **) MEM_alloc(10 * sizeof(char *));

	char ***qry_entries1 = (char ***) MEM_alloc(10 * sizeof(char *));
	char ***qry_values1 = (char ***) MEM_alloc(10 * sizeof(char *));

	FILE *input =  NULL;

	tag_t *status_list = NULLTAG;
	tag_t *namRefObject = NULL;
	tag_t *namRefObject_d = NULL;
	tag_t *rev=NULLTAG;
	tag_t *revtag_d=NULLTAG;
	tag_t* secondary_objects = NULLTAG;

	tag_t t_item =  NULLTAG;
	tag_t revision =  NULLTAG;
	tag_t release_status = NULLTAG;
	tag_t revstatus =  NULLTAG;
	tag_t datasettype =  NULLTAG;
	tag_t Newdataset =  NULLTAG;
	tag_t tool =  NULLTAG;
	tag_t filetag =  NULLTAG;
	tag_t datasetAvl = NULLTAG;
	tag_t aDataset = NULLTAG;
	tag_t item = NULLTAG;
	tag_t relation_type, relation , relationSpeci_type;
	tag_t secObjTypeTag	= NULLTAG;
	tag_t primary,objTypeTag,refobject=NULLTAG;
	tag_t datasetTag = NULLTAG;

	IMF_file_t fileDescriptor;
	AE_reference_type_t tagRefType =  1;

	date_t test = NULLDATE;
	date_t test1 = NULLDATE;

	tag_t query = NULLTAG;
	tag_t master = NULLTAG;
	tag_t latestrev	= NULLTAG;
	tag_t queryTag = NULLTAG;
	tag_t queryTag_d = NULLTAG;
	tag_t item_tag = NULLTAG;
	tag_t itemRevDataSet_tag = NULLTAG;
	tag_t itemRevDataSet_tag2 = NULLTAG;
	tag_t item_tag_data = NULLTAG;
	tag_t item_tag_data_rev = NULLTAG;
	tag_t RefObject_d = NULLTAG;
	tag_t Fndrelation = NULLTAG;
	tag_t FndSpeciRelation = NULLTAG;
	tag_t attr_id ;
	tag_t latestDataset ;
	tag_t owning_user = NULLTAG;

	tag_t *cntr_objects = NULL;
	tag_t *t_item1 = NULLTAG;
	tag_t *tags_found = NULL;

	char *qry_entries4[2] = {"Revision","ID"},
		 *qry_values4[2]	= {"*","*"};

	char *qry_entries4_d[3] = {"Dataset Name"},
		 *qry_values4_d[3]	= {"*"};

	FILE* fp=NULL;
	FILE* fpErr=NULL;

	char *qry_entries3[1] = {"ID"},
		 *qry_values3[1]	= {"*"};

	tag_t reln_type = NULLTAG;
	GRM_relation_t *rellist;
	int Flag_1 =0;
	char *itemId12 =NULL;
	char *itemId123 =NULL;

	char userid[SA_user_size_c+1];

	struct stat buffer;

	logical checkout = 0;

	int m = 0;

	inputfile = ITK_ask_cli_argument("-i=");
	ErrorInputfile = ITK_ask_cli_argument("-j=");
	//IncreStatus = ITK_ask_cli_argument("-k=");

//	if( ITK_init_module("loader" ,"loader7","dba")!=ITK_ok) ;
//	//if( ITK_init_module("infodba" ,"infodba","dba")!=ITK_ok) ;
//	if (ITK_initialize_text_services( ITK_BATCH_TEXT_MODE )!=ITK_ok);
//	//printf("\n Auto login 111");fflush(stdout);
//	//if (ITK_auto_login( )!=ITK_ok);
//	if (ITK_set_journalling( TRUE )!=ITK_ok);
//	printf("\n login .......122");fflush(stdout);

	initialise();


	if (tc_strcmp(ErrorInputfile,"")==0)
	{
		fpErr=fopen("Error_DatasetCrea.txt","a");
	}
	else
	{
		fpErr=fopen(ErrorInputfile,"a");
	}

	fp=fopen(inputfile,"r");
	if(fp!=NULL)
	{
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fp)!=NULL)
		{
			printf("\n\n"); fflush(stdout);
			fputs(inputline,stdout);

			if (strlen(inputline) < 10)
			{
				printf("...........1 .....[%d] [%s]",strlen(inputline),inputline); fflush(stdout);
				printf("    inputline is blank hence skipping....\n"); fflush(stdout);
				break;
			}

			itemId=strtok(inputline,"^");	//1		//TCPart or self/Reference drawing number
			revisionID=strtok(NULL,"^");	//2
			ItmSeqID=strtok(NULL,"^");		//3
			JTid1=strtok(NULL,"^");			//4
			fullPath=strtok(NULL,"^");		//5
			JTFileSeq=strtok(NULL,"^");		//6
			ClassName=strtok(NULL,"^");		//7
			SubTypeNm=strtok(NULL,"^");		//8		// Generic/Instance
			DataItemTemp=strtok(NULL,"^");	//9
			ApplnOwner=strtok(NULL,"^");	//10

			if (strcmp(SubTypeNm,"Instance") !=0 )	//skipping file exist check for instance dataset [09.01.2017]
			{
				if (!stat(fullPath , &buffer))
				{
					//printf("\n\t File exist .......%s\n",fullPath);fflush(stdout);
					;
				}
				else
				{
					printf("\n\t File not exist for [%s,%s,%s,%s], %s \n\n",itemId,revisionID,ItmSeqID,JTid1,fullPath);fflush(stdout);
					continue;
				}
			}

			ApplnOwnerStr =(char *) MEM_alloc(20);
			ClassNmGI =(char *) MEM_alloc(20);

			//DataSetNm2 = (char*)MEM_alloc( 2 * sizeof( char ) );
			DataSetNmOrg=(char *) MEM_alloc(240);
			strcpy(DataSetNmOrg,JTid1);

			DataSetNmOrg3=(char *) MEM_alloc(240);
			strcpy(DataSetNmOrg3,JTid1);

			if(tc_strstr(DataSetNmOrg3,"_")!=NULL)
			{
				DSTemp1 = strtok(DataSetNmOrg3,"_");
				DSTemp2 = strtok(NULL,"_");
				DSTemp2 = strtok(NULL,"_");

				printf("\n\t [%s] DSTemp1: %s  DSTemp2: %s ",JTid1, DSTemp1, DSTemp2); fflush(stdout);
			}

			DataSetNm2 = NULL;
			DataSetNm2=(char *) MEM_alloc(100);
			//strcpy(DataSetNm2,"");
			strcpy(DataSetNm2,JTid1);

			printf("  DataSetNm2:%s  strlen(DataSetNm2):%d",DataSetNm2,strlen(DataSetNm2)); fflush(stdout);

			itemId123 = NULL;
			itemId123 =(char *) MEM_alloc(50);

			/*if(strlen(DataSetNm2)>30)
			{
				if((tc_strstr(JTid1,".asm")!=NULL) || (tc_strstr(JTid1,".prt")!=NULL) || (tc_strstr(JTid1,".drw")!=NULL))
				{
					printf("\n\t ....1....");fflush(stdout);

					DatasetName=strtok(DataSetNm2,"."); //1
					DatasetType=strtok(NULL,".");		//2
					DatasetSeq=strtok(NULL,".");		//3

					printf(" DatasetName:%s  DatasetType:%s  DatasetSeq:%s",DatasetName,DatasetType,DatasetSeq); fflush(stdout);

					lengthMinus=strlen(DatasetType)+ strlen(DatasetSeq) + 3 ;
					//lengthMinus=strlen(DatasetType)+ strlen(DatasetSeq);

					//printf("\n\t DatasetName --->%s",DatasetName);
					printf("  lengthMinus --->%d  strlen(DataSetNm2):%d",lengthMinus,strlen(DataSetNm2)); fflush(stdout);

					JTid1 = NULL;
					JTid1=(char *) MEM_alloc(100);
					tc_strncpy(JTid1,DatasetName,((strlen(DataSetNm2))-lengthMinus));
					//strcpy(JTid1,DatasetName);

					JTid1[tc_strlen(JTid1)] = '\0';

					tc_strcat(JTid1,".");
					tc_strcat(JTid1,DatasetType);
					tc_strcat(JTid1,".");
					tc_strcat(JTid1,DatasetSeq);
				}
				else if((tc_strstr(JTid1,".jt")!=NULL) || (tc_strstr(JTid1,".pdf")!=NULL) )
				{
					printf("\n\t ....2....");fflush(stdout);

					DatasetName=strtok(DataSetNm2,"."); //1
					DatasetType=strtok(NULL,".");		//2

					printf(" DatasetName:%s  DatasetType:%s",DatasetName,DatasetType); fflush(stdout);

					//lengthMinus=strlen(DatasetType)+ 2 ;

					//printf("\n\t DatasetName --->%s",DatasetName);
					//printf("\n\t lengthMinus --->%d",lengthMinus);

					JTid1 = NULL;
					JTid1=(char *) MEM_alloc(100);
					//strncpy(JTid1,DatasetName,((strlen(DataSetNm2))-lengthMinus));
					tc_strcpy(JTid1,DatasetName);
					tc_strcat(JTid1,".");
					tc_strcat(JTid1,DatasetType);
				}
				printf("\n\t JTid1 truncated is --->%s",JTid1); fflush(stdout);
			}*/

			if(JTid1)
			{
				JTid2 = NULL;
				JTid2=(char *) MEM_alloc(100);
				tc_strncpy(JTid2,JTid1,(strlen(JTid1)+1));
			}

			DataSetTmp=NULL;
			DataSetTmp=(char *) MEM_alloc(100);
			tc_strcpy(DataSetTmp,JTid1);

			JTid1Tmp=NULL;
			JTid1Tmp=(char *) MEM_alloc(100);
			tc_strcpy(JTid1Tmp,JTid1);

			DataSetNm3=strtok(DataSetTmp,".");

			DataItem=NULL;
			DataItem=(char *) MEM_alloc(30);

			if(strlen(DataItemTemp)>30)
			{
				DataItemTemp1=strtok(DataItemTemp,".");
				if(strlen(DataItemTemp1)>30)
				{
					strncpy(DataItem,DataItemTemp1,29);
					DataItem[30] = '\0';
				}
				else
				{
					strcpy(DataItem,DataItemTemp1);
					DataItem[strlen(DataItemTemp1)] = '\0';
				}
				printf("\n\t ???????? DataItem is --->[%s]",DataItem); fflush(stdout);
				printf("\n\t ???????? DataItemTemp is ---> [%s]  ????????",DataItemTemp); fflush(stdout);
			}
			else
			{
				strcpy(DataItem,DataItemTemp);
				//DataItem[30] = '\0';
				DataItem[strlen(DataItemTemp)] = '\0';
			}

			itemRevSeq = NULL;
			itemRevSeq=(char *) MEM_alloc(32);
			tc_strcpy(itemRevSeq,revisionID);
			tc_strcat(itemRevSeq,"*");
			tc_strcat(itemRevSeq,ItmSeqID);

			itemRevSeq2 = NULL;
			itemRevSeq2=(char *) MEM_alloc(32);
			tc_strcpy(itemRevSeq2,revisionID);
			tc_strcat(itemRevSeq2,";");
			tc_strcat(itemRevSeq2,ItmSeqID);

			printf("\n\t itemId is ---> %s , %s , %s , %s",itemId,itemRevSeq,JTid1,fullPath); fflush(stdout);
			printf("\n\t CAD Sequence is ---> %s , ClassName-> %s , SubTypeNm-> %s , ApplnOwner-> %s",JTFileSeq,ClassName,SubTypeNm,ApplnOwner); fflush(stdout);
			printf("\n\t DataSetNm3 is --->%s , DataItem-> [%s]   , strlen(DataItem)->[%d]",DataSetNm3,DataItem,strlen(DataItem)); fflush(stdout);

			if(QRY_find("DesignRevision Sequence", &queryTag));
			printf("\n\t After IFERR_REPORT : QRY_find .... "); fflush(stdout);

			if (queryTag!=NULLTAG)
			{
				printf("Found Query 'DesignRevision Sequence' \n\t"); fflush(stdout);
			}
			else
			{
				printf("Not Found Query 'DesignRevision Sequence' \n\t"); fflush(stdout);

				ITK_CALL(POM_logout(false));
				return status;
			}

			qry_values[0] = itemRevSeq ;
			qry_values[1] = itemId;

			if(QRY_execute(queryTag, n_entries, qry_entries4, qry_values, &resultCount, &rev));

			printf(" [%s---%s]  n_entries:%d   resultCount:%d \n\t",itemRevSeq,itemId,n_entries,resultCount); fflush(stdout);

			ALFJtFlag=0;
			if((resultCount==0) && ((tc_strstr(JTid1,".jt")!=NULL) && ((tc_strstr(JTid1,"_ALF")!=NULL) || (tc_strstr(JTid1,"_alf")!=NULL) || (tc_strstr(JTid1,"_WELD")!=NULL))))
			{
				ALFJtFlag=1;

				printf("\n\t************** ALF-jt ****************\n\t"); fflush(stdout);

				ItemDesc=NULL;
				ItemDesc =(char *) MEM_alloc(20);
				strcpy(ItemDesc,"iPEM Override JT");

				result = GRM_find_relation_type("IMAN_Rendering", &relation_type);	//added on 06.07.2016 for ViewJTAssembly option for Assy and child
				printf("\n\t ALF-jt..GRM_find_relation_type ---->%d",result); fflush(stdout);

				if(QRY_find("Dataset Name", &queryTag_d));
				printf("  After IFERR_REPORT : QRY_find ....");fflush(stdout);
				if (queryTag_d)
				{
					printf("  Found Query 'Dataset Name' \n\t");fflush(stdout);
				}
				else
				{
					printf("  Not Found Query 'Dataset Name' \n\t");fflush(stdout);
				}
				qry_values_d[0] = itemId ;
				//qry_values_d[0] = DataSetNm3 ;

				if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
				printf("  ALF-jt..resultCount_d:[%d] \n\t",resultCount_d);fflush(stdout);

				if(resultCount_d > 0)
				{
					DatasetFlag = 0;

					for (j=0;j<resultCount_d;j++ )
					{
						itemRevDataSet_tag = revtag_d[j];

						if(TCTYPE_ask_object_type(itemRevDataSet_tag,&datasetTag));
						if(TCTYPE_ask_name(datasetTag,type_name3));
						//printf("    ALF-jt..Part type_name3 :%s \n\t",type_name3); fflush(stdout);

						if (strcmp(type_name3,"DirectModel")==0)
						{
							result = AE_ask_dataset (itemRevDataSet_tag,&item_tag_data_rev);
							//printf("\n\t ALF-jt..AE_ask_dataset--->%d\n\t ",result);fflush(stdout);

							if (AOM_ask_value_string(itemRevDataSet_tag,"object_application",&PdfDataItem)!=ITK_ok);
							printf("\n\t ALF-jt..PdfDataItem--->%s",PdfDataItem);fflush(stdout);

							result = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
							//printf("\n\t ALF-jt..ref_count_d Count--->%d \n\t ",ref_count_d);fflush(stdout);

							if(ref_count_d>0)
							{
								RefObject_d = namRefObject_d[0];

								if (AOM_ask_value_string(RefObject_d,"object_string",&named_ref2)!=ITK_ok);

								printf("\n\t ALF-jt..item_tag named_ref2:[%s]...JTid1:[%s] ",named_ref2,JTid1);

								named_ref=(char *) MEM_alloc(100);
								strcpy(named_ref,"");
								JtTemp=strtok(named_ref2,".");
								//printf("  JtTemp:[%s]",JtTemp);
								strcpy(named_ref,JtTemp);
								strcat(named_ref,".jt");

								printf("  named_ref:[%s]",named_ref);
								//printf("  named_ref:[%s]  and PdfDataItem:[%s] DataItem:[%s]",named_ref,PdfDataItem,DataItem);

								//if( (strcmp(named_ref,JTid1)==0) && (strcmp(PdfDataItem,DataItem)==0))	//old Condition
								//if (strcmp(named_ref,JTid1)==0)	//commented on 05.04.2017
								if ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0) )		//Condition Changed on 05.04.2017
								{
									DatasetFlag = 1;

									DatasetExistFlag = 1;

									printf("..already present and match found \n\t");
									break;
								}
							}
						}
						//else
						//{
						//	printf("\n\t\t jt..item_tag named_ref match not found hence continuing....\n\t");
						//	DatasetFlag = 0;
						//}
					}
					printf("\n\t ALF-jt..DatasetFlag:%d  already present",DatasetFlag);
				}
				else  ///New create dataset
				{
					DatasetFlag = 0;
				}

				if(DatasetFlag == 0)
				{
					result = AE_find_datasettype("DirectModel", &datasettype);
					printf("\n\t Type found---->%d",result);fflush(stdout);

					printf("\n\t Creating New Dataset..."); fflush(stdout);
					//result = AE_create_dataset_with_id(datasettype,DataSetNm3,ItemDesc, NULL, NULL, &Newdataset);
					//printf("\n\t Dataset created for prt --->%s \n\t\ ",DataSetNm3); fflush(stdout);
					result = AE_create_dataset_with_id(datasettype,itemId,ItemDesc, NULL, NULL, &Newdataset);
					printf("\n\t Dataset created for prt --->%s \n\t ",itemId); fflush(stdout);

					////if (AOM_set_value_string(Newdataset,"object_application","281832308207_reinfbkt.prt.3")!=ITK_ok);
					//if (AOM_set_value_string(Newdataset,"object_application",DataItem)!=ITK_ok);

					result = AE_set_dataset_format(Newdataset, "BINARY_REF");
					printf("\n\t Dataset format set--->%d",result); fflush(stdout);

					result = AE_set_dataset_tool(Newdataset,tool);
					printf("\n\t Tool set--->%d",result); fflush(stdout);

					result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
					printf("\n\t nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

					if (nameRef_cnt == 0)
					{
						result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
						printf("\n\t Got reference list--->%d \n\t ",result); fflush(stdout);

						//result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
						//printf("\n\t File Imported--->%d  [%s]",result,fullPath); fflush(stdout);

						if (IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor)!=ITK_ok);

						result = AOM_save(filetag);
						printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

						if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
						result = AOM_save(filetag);
						printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

						result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
						printf("\n\t ALF-jt..AE_add_dataset_named_ref--->%d",result); fflush(stdout);

						AE_set_dataset_tool(Newdataset,tool);
						printf("\n\t ALF-jt..Tool set--->%d",result); fflush(stdout);

						result = AOM_save(Newdataset);
						printf("\n\t ALF-jt..AOM_save--->%d",result); fflush(stdout);
					}

					DatasetExistFlag = 1;
				}
			}

			if((resultCount>0) || (ALFJtFlag==1))
			{
				printf(" Design Revision / ALFJtFlag=[%d] already exists in UA....resultCount: %d \n\t",ALFJtFlag,resultCount); fflush(stdout);

				for (j=0;j<resultCount;j++ )
				{
					DatasetExistFlag = 0;
					ApplnOwnerFlag = 0;
					tc_strcpy(ApplnOwnerStr,"");
					tc_strcpy(ClassNmGI,"");

					item_tag = rev[j];

					if( AOM_ask_owner( item_tag, &owning_user )!=ITK_ok);
					if( SA_ask_user_identifier(owning_user,userid)!=ITK_ok);

					printf(" ### j:[%d]    JTid1 is --->%s  itemRevSeq: [%s]  owning_user:[%s]",j, JTid1, itemRevSeq , userid); fflush(stdout);
					
					if (tc_strstr(userid,"loader")==NULL)
					{
						printf("\t  User revision is skipping.......\n\n"); fflush(stdout);
						continue;
					}

					////printf("\n\t "); fflush(stdout);

					if (RES_is_checked_out(item_tag,&checkout)!=ITK_ok);	//Added on 09.12.2017 to check design Revsion is in checked-out mode for owner "loader".
					printf("\n\t ???????????? 1.checkout:[%d] ",checkout); fflush(stdout);
					if (checkout > 0)
					{
						printf("\n\t DesignRev %s is in checkout condn for Part: [%s]  hence skipping dataset [%s]",itemRevSeq,itemId,JTid1); fflush(stdout);
						continue;
					}

					//printf("\n\t "); fflush(stdout);
					if (AOM_ask_value_string(item_tag,"item_revision_id",&ItemRevStr)!=ITK_ok);
					printf("\n\t  Item Revision==> [%s]",ItemRevStr); fflush(stdout);

					if (tc_strcmp(itemRevSeq2,ItemRevStr)!=0)		//check is added on 25.07.2016
					{
						printf("...ItemRevision is not matching hence continuing.. \n\t"); fflush(stdout);
						continue;
					}

					if (AOM_ask_value_string(item_tag,"object_desc",&ItemDesc)!=ITK_ok);
					printf("\n\t ItemDesc--object_desc:: [%s]\n\t",ItemDesc);


					if(tc_strstr(JTid1,".asm")!=NULL)
					{
						printf("\n\t************** asm ****************\n\t"); fflush(stdout);

						result = GRM_find_relation_type("IMAN_specification", &relation_type);
						printf("\n\t asm..GRM_find_relation_type ---->%d",result); fflush(stdout);

						if( (strlen(ApplnOwner) > 3) /* && (strcmp(ApplnOwner,"-")!=0) && (strcmp(ApplnOwner," ")!=0) */)
						{
							ApplnOwnerFlag = 1;

							if (tc_strstr(ApplnOwner,"Proe")!=NULL)
							{
								strcpy(ApplnOwnerStr,"ProEAsm");
								ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
							}
							else if (tc_strstr(ApplnOwner,"Catia")!=NULL)
							{
								strcpy(ApplnOwnerStr,"Cat-Product");
								ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
							}
							else
							{
								strcpy(ApplnOwnerStr,"");

								printf("\n\t asm..ApplnOwner string is not Valid to Set ---->%s,%s , %s",itemId,itemRevSeq,JTid1); fflush(stdout);
							}
						}

						if(tc_strstr(JTid1,"_swp") != NULL)
						{
							printf("\n\n\t **************swp-asm****************\n\t"); fflush(stdout);

							Flag_1=0;
							if (GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist)!=ITK_ok);
							printf("\n\t swp-asm..Total n attches =%d\n",n_attchs);

							itemId12 = strtok(JTid1Tmp,".");
							strcpy(itemId123,itemId12);
							printf("\t swp-asm..Name is --->%s\n\t ",itemId123);

							for (i= 0; i < n_attchs; i++)
							{
								primary=rellist[i].secondary;
								//relationstr=rellist[i].the_relation;
								//relationstr=rellist[i].the_relation; //Sudhir Kumar Srivastava - 09-May-2023 Warning removed in these code ,,, so if you are using this API GRM_list_secondary_objects.. then u need to take care of these types of warning
								ITK_CALL(AOM_ask_name(rellist[i].relation_type,&relationstr)); //Sudhir Kumar Srivastava - 09-May-2023
								printf("\n relationstr:%s ..............",relationstr);fflush(stdout); //Sudhir Kumar Srivastava - 09-May-2023

								if (TCTYPE_ask_object_type(primary,&objTypeTag)!=ITK_ok);
								//printf("\n\t "); fflush(stdout);
								if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);

								//printf("\n\t swp-asm..Type Name:%s ..............",type_name);fflush(stdout);

								if((strcmp(type_name,"ImanFile")==0) || (strcmp(type_name,"icm0")==0))
									continue;

								result = AE_find_datasettype("ProAsm", &datasettype);
								//printf("\n\t swp-asm..Type found---->%d",result);fflush(stdout);

								//printf("\n\t "); fflush(stdout);
								if (AOM_ask_value_string(primary,"object_name",&parent_name)!=ITK_ok);
								printf("\n\t"); fflush(stdout);
								//printf("\n\t swp-asm..parent_name:%s ..............",parent_name);fflush(stdout);

								//if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"ProAsm") ==0) //Alokesh strcmp -> strcasecmp (Ignore Cases)
								if(strcasecmp(parent_name,itemId123)==0 &&  strcmp(type_name,"ProAsm") ==0)
								{
									result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
									printf("\n\t swp-asm..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
									if(ref_count_d>0)
									{
										Flag_1 = 1;
										printf("\n\t swp-asm..Relationship already exist !!!!.......\n");fflush(stdout);

										DatasetRelFlag = 1;
										DatasetExistFlag = 1;

										break;
									}
									else
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t swp-asm..Got reference list--->%d",result);fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t swp-asm..File Imported--->%d",result);fflush(stdout);

										if (result == 41178)
										{
											ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
										}

										result = AOM_save(filetag);
										printf("\n\t swp-asm..File saved--->%d",result);fflush(stdout);

										result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
										printf("\n\t swp-asm..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

										AE_set_dataset_tool(primary,tool);
										printf("\n\t swp-asm..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										result = AOM_save(primary);
										printf("\n\t swp-asm..AOM_save--->%d",result);fflush(stdout);fflush(stdout);
										if(result == 0)
										{
											Flag_1 = 1;

											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
										}
									}
								}
							}
							if (Flag_1 == 0)
							{
								result = AE_find_datasettype("ProAsm", &datasettype);
								printf("\n\t swp-asm..Type found---->%d",result);fflush(stdout);

								result = AE_create_dataset_with_id(datasettype,itemId123,ItemDesc, NULL, NULL, &Newdataset);
								printf("\n\t swp-asm..Dataset created--->%s",itemId123);fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\n\t swp-asm..Dataset format set--->%d",result);fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t swp-asm..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t swp-asm..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t swp-asm..Got reference list--->%d",result);fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t swp-asm..File Imported--->%d",result);fflush(stdout);

									if (result == 41178)
									{
										ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t swp-asm..File saved--->%d",result);fflush(stdout);

									if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
									result = AOM_save(filetag);
									printf("\n\t swp-cgr-File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

									result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
									printf("\n\t swp-asm..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

									AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t swp-asm..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									printf("\n\t swp-asm..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AOM_save(Newdataset);
								}

								printf("\n\t swp-asm..GRM_find_relation_type ---->%d",result);fflush(stdout);

								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t swp-asm..Fndrelation ---->%d",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									printf("\n\t swp-asm..Relation Already Exist..........\n\n" );fflush(stdout);
								}
								else
								{
									result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
									printf("\n\t swp-asm..GRM_create_relation ---->%d",result);fflush(stdout);
									result = GRM_save_relation(relation);
									printf("\n\t swp-asm..GRM_save_relation ---->%d\n",result);fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
						else
						{
							Flag_1=0;
							if (GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist)!=ITK_ok);
							printf("\n\t asm..Total n attches =%d\n",n_attchs);

							itemId12 = strtok(JTid1Tmp,".");
							strcpy(itemId123,itemId12);

							printf("\t asm..Name is --->%s\n\t ",itemId123);

							for (i= 0; i < n_attchs; i++)
							{
								primary=rellist[i].secondary;
								//relationstr=rellist[i].the_relation;
								//relationstr=rellist[i].the_relation; //Sudhir Kumar Srivastava - 09-May-2023 Warning removed in these code ,,, so if you are using this API GRM_list_secondary_objects.. then u need to take care of these types of warning
								ITK_CALL(AOM_ask_name(rellist[i].relation_type,&relationstr)); //Sudhir Kumar Srivastava - 09-May-2023
								printf("\n relationstr:%s ..............",relationstr);fflush(stdout); //Sudhir Kumar Srivastava - 09-May-2023

								if (TCTYPE_ask_object_type(primary,&objTypeTag)!=ITK_ok);
								//printf("\n\t "); fflush(stdout);
								if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);

								//printf("\n\t asm..Type Name:%s ..............",type_name);fflush(stdout);

								if((strcmp(type_name,"ImanFile")==0) || (strcmp(type_name,"icm0")==0))
									continue;

								result = AE_find_datasettype("ProAsm", &datasettype);
								//printf("\n\t asm..Type found---->%d",result);fflush(stdout);

								//printf("\n\t "); fflush(stdout);
								if (AOM_ask_value_string(primary,"object_name",&parent_name)!=ITK_ok);
								printf("\n\t"); fflush(stdout);
								//printf("\n\t asm..parent_name:%s ..............",parent_name);fflush(stdout);

								//if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"ProAsm") ==0) //Alokesh strcmp -> strcasecmp (Ignore Cases)
								if(strcasecmp(parent_name,itemId123)==0 &&  strcmp(type_name,"ProAsm") ==0)
								{
									result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
									printf("\n\t asm..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
									if(ref_count_d > 0)
									{
										Flag_1 = 1;
										printf("\n\t asm..Relationship already exist !!!!.......\n\t ");fflush(stdout);

										RefObject_d = namRefObject_d[0];

										if (AOM_ask_value_string(RefObject_d,"object_string",&named_ref)!=ITK_ok);
										printf("\n\t asm..item_tag named_ref:[%s]  DataSetNmOrg: [%s]  JTid1:[%s]",named_ref,DataSetNmOrg,JTid1);

										if ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0) )		//Condition Changed on 05.04.2017
										{
											Flag_1 = 1;
											DatasetFlag = 1;
											printf("...already present and match found.\n");
											break;
										}
										else
										{
											printf("...match not found hence continuing ??? "); fflush(stdout);

											result = AE_ask_dataset (primary,&item_tag_data_rev);
											printf("\n\t asm..AE_ask_dataset--->%d",result);fflush(stdout);
											
											result = GRM_find_relation( item_tag, item_tag_data_rev, relation_type ,&Fndrelation);

											if(Fndrelation != NULLTAG)
											{
												printf("\t deleting relation \n" ); fflush(stdout);
												if (GRM_delete_relation(Fndrelation)!=ITK_ok);
											}

											Flag_1 = 0;
											DatasetFlag = 0;
										}

										//DatasetRelFlag = 1;
										//DatasetExistFlag = 1;

										break;
									}
									else
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t asm..Got reference list--->%d",result);fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t asm..File Imported--->%d",result);fflush(stdout);

										if (result == 41178)
										{
											ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
										}

										result = AOM_save(filetag);
										printf("\n\t asm..File saved--->%d",result);fflush(stdout);

										result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
										printf("\n\t asm..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

										AE_set_dataset_tool(primary,tool);
										printf("\n\t asm..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										result = AOM_save(primary);
										printf("\n\t asm..AOM_save--->%d",result);fflush(stdout);fflush(stdout);
										if(result == 0)
										{
											Flag_1 = 1;

											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
										}
									}
								}
								else
								{
									Flag_1 = 0;
									DatasetFlag = 0;
								}
							}
							
							if(QRY_find("Dataset Name", &queryTag_d));
							printf("  After IFERR_REPORT : QRY_find....");fflush(stdout);
							if (queryTag_d)
							{
								printf("  Found Query 'Dataset Name'");fflush(stdout);
							}
							else
							{
								printf("  Not Found Query 'Dataset Name'");fflush(stdout);
							}
							qry_values_d[0] = itemId ;

							if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
							printf("\n\t asm..resultCount_d:[%d]",resultCount_d);fflush(stdout);

							if(resultCount_d > 0)
							{
								DatasetFlag = 0;

								for (j=0;j<resultCount_d;j++ )
								{
									itemRevDataSet_tag = revtag_d[j];

									if(TCTYPE_ask_object_type(itemRevDataSet_tag,&datasetTag));
									if(TCTYPE_ask_name(datasetTag,type_name3));
									//printf("\n\t asm..Part type_name3 :%s",type_name3); fflush(stdout);

									if (strcmp(type_name3,"ProAsm")==0)
									{
										item_tag_data_rev = NULLTAG;

										result = AE_ask_dataset (itemRevDataSet_tag,&item_tag_data_rev);
										//printf("\n\t asm..AE_ask_dataset--->%d",result);fflush(stdout);

										result = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
										//printf("\n\t asm..ref_count_d Count--->%d \n\t ",ref_count_d);fflush(stdout);

										if(ref_count_d>0)
										{
											RefObject_d = namRefObject_d[0];

											printf("\t ");fflush(stdout);

											if (AOM_ask_value_string(RefObject_d,"object_string",&named_ref)!=ITK_ok);
											//printf("\n\t asm..item_tag named_ref:[%s]  JTid1:[%s]",named_ref,JTid1); fflush(stdout);

											//if (strcmp(named_ref,JTid1)==0)
											if ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0) )		//Condition Changed on 05.04.2017
											{
												DatasetFlag = 1;
												printf("\n\t asm..item_tag named_ref:[%s]  JTid1:[%s]...already present and match found.\n",named_ref,JTid1); fflush(stdout);
												break;
											}
											else
											{
												if (j == (resultCount_d - 1))
												{
													printf("\n\t asm.....match not found hence continuing..\n"); fflush(stdout);
												}
												DatasetFlag = 0;
											}
										}
									}
								}
								printf("\n\t asm..DatasetFlag:%d ",DatasetFlag); fflush(stdout);

								if(DatasetFlag == 1)
								{
									if(relation_type)
									{
										//printf("\n\t "); fflush(stdout);
										if (TCTYPE_ask_name(relation_type,type_name)!=ITK_ok);
										printf("\t asm..Type Name:%s ..............",type_name); fflush(stdout);
									}

									result = GRM_find_relation( item_tag, item_tag_data_rev, relation_type ,&Fndrelation);
									printf("\n\t asm..Fndrelation ---->%d \n\t",result); fflush(stdout);

									if(Fndrelation != NULLTAG)
									{
										DatasetRelFlag = 0;

										if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
										printf("  1.asm..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

										if(n_attchs>0)
										{
											for (i=0; i < n_attchs; i++)
											{
												if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
												if(TCTYPE_ask_name(secObjTypeTag,type_name2));
												printf("    1.asm..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

												if (strcmp(type_name2,"ProAsm")==0)
												{
													printf("  1.asm..Dataset is already attached to Revision \n\t"); fflush(stdout);

													printf("\n\t 1.asm..Relation Already Exist...........\n\n\t" );fflush(stdout);
													DatasetRelFlag = 1;
													DatasetExistFlag = 1;

													if (AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc)!=ITK_ok);
													printf("     1.asm..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);
													if (strcmp(ItemDesc,DatasetDesc) != 0)
													{
														printf("     1.asm..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

														setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
														if (AOM_save(secondary_objects[i])!=ITK_ok);
														if (AOM_unlock(secondary_objects[i])!=ITK_ok);
													}

													break;
												}
											}
										}
									}
									else
									{
										DatasetRelFlag = 0;
									}

									if (DatasetRelFlag == 0)
									{
										if (GRM_create_relation(item_tag, item_tag_data_rev, relation_type, NULL, &relation)!=ITK_ok);
										printf("\n\t 1.asm..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
										if (AOM_refresh (item_tag,0)!=ITK_ok);
										printf("\n\t ");
										if (AOM_refresh(relation,0)!=ITK_ok);
										result = GRM_save_relation(relation);
										printf("\n\t 1.asm..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

										DatasetExistFlag = 1;
									}
								}
							}
							else  ///New create dataset
							{
								DatasetFlag = 0;
							}

							if(DatasetFlag == 0)
							{
								//dataset_NewRevNo = dataset_RevNo +1;

								result = AE_find_datasettype("ProAsm", &datasettype);
								printf("\n\t Type found---->%d",result);fflush(stdout);

								//result = AE_find_dataset(itemId, &Newdataset);
								//if(Newdataset)
								//{
								//	printf("\n\t Dataset Found..."); fflush(stdout);
								//}
								//else
								//{
									printf("\n\t Creating New Dataset..."); fflush(stdout);

									result = AE_create_dataset_with_id(datasettype,itemId,ItemDesc, NULL, NULL, &Newdataset);
									printf("\n\t Dataset created for asm --->%s",itemId); fflush(stdout);

									result = AE_set_dataset_format(Newdataset, "BINARY_REF");
									printf("\n\t Dataset format set--->%d",result); fflush(stdout);

									result = AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t Tool set--->%d",result); fflush(stdout);
								//}

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t Got reference list--->%d",result); fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t File Imported--->%d",result); fflush(stdout);

									if (result == 41178)
									{
										ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

									if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
									result = AOM_save(filetag);
									printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

									result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
									printf("\n\t AE_add_dataset_named_ref--->%d",result); fflush(stdout);

									AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t Tool set--->%d",result); fflush(stdout);

									result = AOM_save(Newdataset);
									printf("\n\t AOM_save--->%d",result); fflush(stdout);
								}

								//result = POM_attr_id_of_attr("revision_number", "WorkspaceObject", &attr_id);
								//printf("\n\t POM_attr_id_of_attr--->%d",result); fflush(stdout);

								//result = AOM_lock(Newdataset);
								//printf("\n\t AOM_lock--->%d",result); fflush(stdout);

								//printf("\n\t dataset_NewRevNo --->%d",dataset_NewRevNo); fflush(stdout);

								//result = POM_set_attr_int( 1, &Newdataset, attr_id, dataset_NewRevNo);
								//printf("\n\t POM_set_attr_int--->%d",result); fflush(stdout);

								//result = AOM_save(Newdataset);
								//printf("\n\t **AOM_save--->%d",result); fflush(stdout);

								//result = AOM_unlock(Newdataset);
								//printf("\n\t AOM_unlock--->%d",result); fflush(stdout);

								////if(AOM_lock(Newdataset));
								////if(POM_set_attr_int( 1, &Newdataset, attr_id, dataset_NewRevNo))  PrintErrorStack();
								////if(AOM_save(Newdataset))PrintErrorStack();
								////if(AOM_unlock(Newdataset))PrintErrorStack();

								////result = POM_set_attr_int( 1, &Newdataset, attr_id, dataset_NewRevNo);
								////printf("\n\t NewRevNo set on Dataset--->%d",result); fflush(stdout);

								////result = AOM_save(Newdataset);
								////printf(" ......AOM_save--->%d",result); fflush(stdout);

								//result = GRM_find_relation_type("IMAN_specification", &relation_type);
								//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

								if(relation_type)
								{
									//printf("\n\t "); fflush(stdout);
									if (TCTYPE_ask_name(relation_type,type_name)!=ITK_ok);
									printf("\n\t Type Name:%s ..............",type_name);fflush(stdout);
								}

								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t Fndrelation ---->%d \n\t",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									DatasetRelFlag = 0;

									if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
									printf("  2.asm..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

									if(n_attchs>0)
									{
										for (i=0; i < n_attchs; i++)
										{
											if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
											if(TCTYPE_ask_name(secObjTypeTag,type_name2));
											printf("    2.asm..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

											if (strcmp(type_name2,"ProAsm")==0)
											{
												printf("  2.asm..Dataset is already attached to Revision \n\t"); fflush(stdout);

												printf("\n\t 2.asm..Relation Already Exist...........\n\n\t" );fflush(stdout);
												DatasetRelFlag = 1;
												DatasetExistFlag = 1;

												if (AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc)!=ITK_ok);
												printf("     2.asm..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);

												if (strcmp(ItemDesc,DatasetDesc) != 0)
												{
													printf("     2.asm..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

													setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
													if (AOM_save(secondary_objects[i])!=ITK_ok);
													if (AOM_unlock(secondary_objects[i])!=ITK_ok);
												}

												break;
											}
										}
									}
								}
								else
								{
									DatasetRelFlag = 0;
								}

								if (DatasetRelFlag == 0)
								{
									if (GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation)!=ITK_ok);
									printf("\n\t 2.asm..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
									if (AOM_refresh (item_tag,0)!=ITK_ok);
									printf("\n\t ");
									if (AOM_refresh(relation,0)!=ITK_ok);
									result = GRM_save_relation(relation);
									printf("\n\t 2.asm..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
					}
					//else if(tc_strstr(JTid1,".prt")!=NULL)
					else if((tc_strstr(JTid1,".prt")!=NULL)&&(strcmp(SubTypeNm,"-")==0))
					{
						printf("\n\t************** prt ****************\n\t"); fflush(stdout);

						//ItemDesc =(char *) MEM_alloc(20);
						//strcpy(ItemDesc,"ProPrt Document");

						result = GRM_find_relation_type("IMAN_specification", &relation_type);
						printf("\n\t prt..GRM_find_relation_type ---->%d",result); fflush(stdout);

						if( (strlen(ApplnOwner) > 3) /* && (strcmp(ApplnOwner,"-")!=0) && (strcmp(ApplnOwner," ")!=0) */)
						{
							ApplnOwnerFlag = 1;

							if (tc_strstr(ApplnOwner,"Proe")!=NULL)
							{
								strcpy(ApplnOwnerStr,"ProEPart");
								ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
							}
							else if (tc_strstr(ApplnOwner,"Catia")!=NULL)
							{
								strcpy(ApplnOwnerStr,"Cat-Part");
								ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
							}
							else
							{
								strcpy(ApplnOwnerStr,"");

								printf("\n\t prt..ApplnOwner string is not Valid to Set ---->%s,%s , %s",itemId,itemRevSeq,JTid1); fflush(stdout);
							}
						}

						if(tc_strstr(JTid1,"_swp") != NULL)
						{
							printf("\n\n\t **************swp-prt****************\n\t"); fflush(stdout);

							Flag_1=0;
							if (GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist)!=ITK_ok);
							printf("\n\t swp-prt..Total n attches =%d\n",n_attchs);

							itemId12 = strtok(JTid1,".");
							strcpy(itemId123,itemId12);
							printf("\t swp-prt..Name is --->%s\n\t ",itemId123);

							for (i= 0; i < n_attchs; i++)
							{
								primary=rellist[i].secondary;
								//relationstr=rellist[i].the_relation;
								//relationstr=rellist[i].the_relation; //Sudhir Kumar Srivastava - 09-May-2023 Warning removed in these code ,,, so if you are using this API GRM_list_secondary_objects.. then u need to take care of these types of warning
								ITK_CALL(AOM_ask_name(rellist[i].relation_type,&relationstr)); //Sudhir Kumar Srivastava - 09-May-2023
								printf("\n relationstr:%s ..............",relationstr);fflush(stdout); //Sudhir Kumar Srivastava - 09-May-2023

								if (TCTYPE_ask_object_type(primary,&objTypeTag)!=ITK_ok);
								//printf("\n\t "); fflush(stdout);
								if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);

								//printf("\n\t swp-prt..Type Name:%s ..............",type_name);fflush(stdout);

								if((strcmp(type_name,"ImanFile")==0) || (strcmp(type_name,"icm0")==0))
									continue;

								result = AE_find_datasettype("ProPrt", &datasettype);
								//printf("\n\t swp-prt..Type found---->%d",result);fflush(stdout);

								//printf("\n\t "); fflush(stdout);
								if (AOM_ask_value_string(primary,"object_name",&parent_name)!=ITK_ok);
								printf("\n\t"); fflush(stdout);
								//printf("\n\t swp-prt..parent_name:%s ..............",parent_name);fflush(stdout);

								//if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"ProPrt") ==0) //Alokesh strcmp -> strcasecmp (Ignore Cases)
								if(strcasecmp(parent_name,itemId123)==0 &&  strcmp(type_name,"ProPrt") ==0)
								{
									result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
									printf("\n\t swp-prt..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
									if(ref_count_d>0)
									{
										Flag_1 = 1;
										printf("\n\t swp-prt..Relationship already exist !!!!.......\n");fflush(stdout);

										DatasetRelFlag = 1;
										DatasetExistFlag = 1;

										break;
									}
									else
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t swp-prt..Got reference list--->%d",result);fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t swp-prt..File Imported--->%d",result);fflush(stdout);

										if (result == 41178)
										{
											ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
										}

										result = AOM_save(filetag);
										printf("\n\t swp-prt..File saved--->%d",result);fflush(stdout);

										result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
										printf("\n\t swp-prt..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

										AE_set_dataset_tool(primary,tool);
										printf("\n\t swp-prt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										result = AOM_save(primary);
										printf("\n\t swp-prt..AOM_save--->%d",result);fflush(stdout);fflush(stdout);
										if(result == 0)
										{
											Flag_1 = 1;

											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
										}
									}
								}
							}
							if (Flag_1 == 0)
							{
								result = AE_find_datasettype("ProPrt", &datasettype);
								printf("\n\t swp-prt..Type found---->%d",result);fflush(stdout);

								result = AE_create_dataset_with_id(datasettype,itemId123,ItemDesc, NULL, NULL, &Newdataset);
								printf("\n\t swp-prt..Dataset created--->%s",itemId123);fflush(stdout);

								result = AE_set_dataset_format2(Newdataset, "Binary");
								printf("\n\t swp-prt..Dataset format set--->%d",result);fflush(stdout);

								result = AE_ask_dataset_tool(Newdataset,&tool);
								printf("\n\t swp-prt..Tool Ask--->%d",result);fflush(stdout);fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t swp-prt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t swp-prt..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t swp-prt..Got reference list--->%d",result);fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t swp-prt..File Imported--->%d",result);fflush(stdout);

									if (result == 41178)
									{
										ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t swp-prt..File saved--->%d",result);fflush(stdout);

									if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
									result = AOM_save(filetag);
									printf("\n\t swp-cgr-File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

									result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
									printf("\n\t swp-prt..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

									AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t swp-prt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									printf("\n\t swp-prt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AOM_save(Newdataset);
								}

								printf("\n\t swp-prt..GRM_find_relation_type ---->%d",result);fflush(stdout);

								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t swp-prt..Fndrelation ---->%d",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									printf("\n\t swp-prt..Relation Already Exist...........\n\n" );fflush(stdout);
								}
								else
								{
									result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
									printf("\n\t swp-prt..GRM_create_relation ---->%d",result);fflush(stdout);
									result = GRM_save_relation(relation);
									printf("\n\t swp-prt..GRM_save_relation ---->%d\n",result);fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
						else
						{
							Flag_1=0;
							if (GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist)!=ITK_ok);
							printf("\n\t prt..Total n attches =%d\n",n_attchs);

							itemId12 = strtok(JTid1Tmp,".");
							strcpy(itemId123,itemId12);

							printf("\t prt..Name is --->%s\n\t ",itemId123);

							for (i= 0; i < n_attchs; i++)
							{
								primary=rellist[i].secondary;
								//relationstr=rellist[i].the_relation;
								//relationstr=rellist[i].the_relation; //Sudhir Kumar Srivastava - 09-May-2023 Warning removed in these code ,,, so if you are using this API GRM_list_secondary_objects.. then u need to take care of these types of warning
								ITK_CALL(AOM_ask_name(rellist[i].relation_type,&relationstr)); //Sudhir Kumar Srivastava - 09-May-2023
								printf("\n relationstr:%s ..............",relationstr);fflush(stdout); //Sudhir Kumar Srivastava - 09-May-2023

								if (TCTYPE_ask_object_type(primary,&objTypeTag)!=ITK_ok);
								//printf("\n\t "); fflush(stdout);
								if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);

								printf("\n\t prt..Type Name:%s ..............",type_name);fflush(stdout);

								if((strcmp(type_name,"ImanFile")==0) || (strcmp(type_name,"icm0")==0))
									continue;

								result = AE_find_datasettype("ProPrt", &datasettype);
								//printf("\n\t prt..Type found---->%d",result);fflush(stdout);

								//printf("\n\t "); fflush(stdout);
								if (AOM_ask_value_string(primary,"object_name",&parent_name)!=ITK_ok);
								printf("\n\t"); fflush(stdout);
								//printf("\n\t prt..parent_name:%s ..............",parent_name);fflush(stdout);

								//if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"ProPrt") ==0) //Alokesh strcmp -> strcasecmp (Ignore Cases)
								if(strcasecmp(parent_name,itemId123)==0 &&  strcmp(type_name,"ProPrt") ==0)
								{
									result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
									printf("\n\t prt..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
									if(ref_count_d > 0)
									{
										Flag_1 = 1;
										printf("\n\t prt..Relationship already exist !!!!.......\n\t ");fflush(stdout);

										RefObject_d = namRefObject_d[0];

										if (AOM_ask_value_string(RefObject_d,"object_string",&named_ref)!=ITK_ok);
										printf("\n\t prt..item_tag named_ref:[%s]  DataSetNmOrg: [%s]  JTid1:[%s]",named_ref,DataSetNmOrg,JTid1);

										if ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0) )		//Condition Changed on 05.04.2017
										{
											Flag_1 = 1;
											DatasetFlag = 1;
											printf("...already present and match found.\n");
											break;
										}
										else
										{
											printf("...match not found hence continuing ??? "); fflush(stdout);

											result = AE_ask_dataset (primary,&item_tag_data_rev);
											printf("\n\t prt..AE_ask_dataset--->%d",result);fflush(stdout);
											
											result = GRM_find_relation( item_tag, item_tag_data_rev, relation_type ,&Fndrelation);

											if(Fndrelation != NULLTAG)
											{
												printf("\t deleting relation \n" ); fflush(stdout);
												if (GRM_delete_relation(Fndrelation)!=ITK_ok);
											}

											Flag_1 = 0;
											DatasetFlag = 0;
										}

										//DatasetRelFlag = 1;
										//DatasetExistFlag = 1;

										break;
									}
									else
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t prt..Got reference list--->%d",result);fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t prt..File Imported--->%d",result);fflush(stdout);

										if (result == 41178)
										{
											ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
										}

										result = AOM_save(filetag);
										printf("\n\t prt..File saved--->%d",result);fflush(stdout);

										result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
										printf("\n\t prt..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

										AE_set_dataset_tool(primary,tool);
										printf("\n\t prt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										result = AOM_save(primary);
										printf("\n\t prt..AOM_save--->%d",result);fflush(stdout);fflush(stdout);
										if(result == 0)
										{
											Flag_1 = 1;

											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
										}
									}
								}
								else
								{
									Flag_1 = 0;
									DatasetFlag = 0;
								}
							}
							
							if(QRY_find("Dataset Name", &queryTag_d));
							printf("  After IFERR_REPORT : QRY_find....");fflush(stdout);
							if (queryTag_d)
							{
								printf("  Found Query 'Dataset Name'");fflush(stdout);
							}
							else
							{
								printf("  Not Found Query 'Dataset Name'");fflush(stdout);
							}
							qry_values_d[0] = itemId ;

							if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
							printf("\n\t prt..resultCount_d:[%d]",resultCount_d);fflush(stdout);

							if(resultCount_d > 0)
							{
								DatasetFlag = 0;

								for (j=0;j<resultCount_d;j++ )
								{
									itemRevDataSet_tag = revtag_d[j];

									if(TCTYPE_ask_object_type(itemRevDataSet_tag,&datasetTag));
									if(TCTYPE_ask_name(datasetTag,type_name3));
									//printf("\n\t prt..Part type_name3 :%s",type_name3); fflush(stdout);

									if (strcmp(type_name3,"ProPrt")==0)
									{
										item_tag_data_rev = NULLTAG;

										result = AE_ask_dataset (itemRevDataSet_tag,&item_tag_data_rev);
										//printf("\n\t prt..AE_ask_dataset--->%d",result);fflush(stdout);

										result = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
										//printf("\n\t prt..ref_count_d Count--->%d \n\t ",ref_count_d);fflush(stdout);

										if(ref_count_d>0)
										{
											RefObject_d = namRefObject_d[0];

											printf("\t ");fflush(stdout);

											if (AOM_ask_value_string(RefObject_d,"object_string",&named_ref)!=ITK_ok);
											//printf("\n\t prt..item_tag named_ref:[%s]  JTid1:[%s]",named_ref,JTid1); fflush(stdout);

											//if (strcmp(named_ref,JTid1)==0)
											if ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0) )		//Condition Changed on 05.04.2017
											{
												DatasetFlag = 1;
												printf("\n\t prt..item_tag named_ref:[%s]  JTid1:[%s]...already present and match found.\n",named_ref,JTid1); fflush(stdout);
												break;
											}
											else
											{
												if (j == (resultCount_d - 1))
												{
													printf("\n\t prt.....match not found hence continuing..\n"); fflush(stdout);
												}
												DatasetFlag = 0;
											}
										}
									}
								}
								printf("\n\t prt..DatasetFlag:%d ",DatasetFlag); fflush(stdout);

								if(DatasetFlag == 1)
								{
									if(relation_type)
									{
										//printf("\n\t "); fflush(stdout);
										if (TCTYPE_ask_name(relation_type,type_name)!=ITK_ok);
										printf("\t prt..Type Name:%s ..............",type_name); fflush(stdout);
									}

									result = GRM_find_relation( item_tag, item_tag_data_rev, relation_type ,&Fndrelation);
									printf("\n\t prt..Fndrelation ---->%d \n\t",result); fflush(stdout);

									if(Fndrelation != NULLTAG)
									{
										DatasetRelFlag = 0;

										if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
										printf("  1.prt..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

										if(n_attchs>0)
										{
											for (i=0; i < n_attchs; i++)
											{
												if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
												if(TCTYPE_ask_name(secObjTypeTag,type_name2));
												printf("    1.prt..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

												if (strcmp(type_name2,"ProPrt")==0)
												{
													printf("  1.prt..Dataset is already attached to Revision \n\t"); fflush(stdout);

													printf("\n\t 1.prt..Relation Already Exist...........\n\n\t" );fflush(stdout);
													DatasetRelFlag = 1;
													DatasetExistFlag = 1;

													//if (strcmp(SubTypeNm,"Generic")!=0)
													if(tc_strstr(ItemDesc,"Dummy ")==NULL)
													{
														if (AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc)!=ITK_ok);
														printf("     1.prt..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);
														if (strcmp(ItemDesc,DatasetDesc) != 0)
														{
															printf("     1.prt..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

															setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
															if (AOM_save(secondary_objects[i])!=ITK_ok);
															if (AOM_unlock(secondary_objects[i])!=ITK_ok);
														}
													}

													break;
												}
											}
										}
									}
									else
									{
										DatasetRelFlag = 0;
									}

									if (DatasetRelFlag == 0)
									{
										if (GRM_create_relation(item_tag, item_tag_data_rev, relation_type, NULL, &relation)!=ITK_ok);
										printf("\n\t 1.prt..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
										if (AOM_refresh (item_tag,0)!=ITK_ok);
										printf("\n\t ");
										if (AOM_refresh(relation,0)!=ITK_ok);
										result = GRM_save_relation(relation);
										printf("\n\t 1.prt..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

										DatasetExistFlag = 1;
									}
								}
							}
							else  ///New create dataset
							{
								DatasetFlag = 0;
							}

							if(DatasetFlag == 0)
							{
								//dataset_NewRevNo = dataset_RevNo +1;

								result = AE_find_datasettype("ProPrt", &datasettype);
								printf("\n\t Type found---->%d",result);fflush(stdout);

								//result = AE_find_dataset(itemId, &Newdataset);
								//if(Newdataset)
								//{
								//	printf("\n\t Dataset Found..."); fflush(stdout);
								//}
								//else
								//{
									printf("\n\t Creating New Dataset..."); fflush(stdout);

									result = AE_create_dataset_with_id(datasettype,itemId,ItemDesc, NULL, NULL, &Newdataset);
									printf("\n\t Dataset created for prt..--->%s",itemId); fflush(stdout);

									result = AE_set_dataset_format(Newdataset, "Binary");
									printf("\n\t Dataset format set--->%d",result); fflush(stdout);

									result = AE_ask_dataset_tool(Newdataset,&tool);
									printf("\n\t Dataset Tool Ask--->%d",result);fflush(stdout);

									result = AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t Tool set--->%d",result); fflush(stdout);
								//}

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t Got reference list--->%d",result); fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t File Imported--->%d",result); fflush(stdout);

									if (result == 41178)
									{
										ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

									if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
									result = AOM_save(filetag);
									printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

									result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
									printf("\n\t AE_add_dataset_named_ref--->%d",result); fflush(stdout);

									AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t Tool set--->%d",result); fflush(stdout);

									result = AOM_save(Newdataset);
									printf("\n\t AOM_save--->%d",result); fflush(stdout);
								}

								if(relation_type)
								{
									//printf("\n\t "); fflush(stdout);
									if (TCTYPE_ask_name(relation_type,type_name)!=ITK_ok);
									printf("\n\t Type Name:%s ..............",type_name);fflush(stdout);
								}

								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t Fndrelation ---->%d \n\t",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									DatasetRelFlag = 0;

									if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
									printf("  2.prt..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

									if(n_attchs>0)
									{
										for (i=0; i < n_attchs; i++)
										{
											if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
											if(TCTYPE_ask_name(secObjTypeTag,type_name2));
											printf("    2.prt..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

											if (strcmp(type_name2,"ProPrt")==0)
											{
												printf("  2.prt..Dataset is already attached to Revision \n\t"); fflush(stdout);

												printf("\n\t 2.prt..Relation Already Exist...........\n\n\t" );fflush(stdout);
												DatasetRelFlag = 1;
												DatasetExistFlag = 1;

												if (AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc)!=ITK_ok);
												printf("     2.prt..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);

												//if (strcmp(SubTypeNm,"Generic")!=0)
												if(tc_strstr(ItemDesc,"Dummy ")==NULL)
												{
													if (strcmp(ItemDesc,DatasetDesc) != 0)
													{
														printf("     2.prt..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

														setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
														if (AOM_save(secondary_objects[i])!=ITK_ok);
														if (AOM_unlock(secondary_objects[i])!=ITK_ok);
													}
												}

												break;
											}
										}
									}
								}
								else
								{
									DatasetRelFlag = 0;
								}

								if (DatasetRelFlag == 0)
								{
									if (GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation)!=ITK_ok);
									printf("\n\t 2.prt..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
									if (AOM_refresh (item_tag,0)!=ITK_ok);
									printf("\n\t ");
									if (AOM_refresh(relation,0)!=ITK_ok);
									result = GRM_save_relation(relation);
									printf("\n\t 2.prt..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
					}
					else if(tc_strstr(JTid1,".drw")!=NULL)
					{	
						printf("\n\t************** drw ****************\n\n\t"); fflush(stdout);

						if (strcmp(itemId,DataSetNm3)==0)	//self-drawing
						{
							result = GRM_find_relation_type("IMAN_specification", &relation_type);
						}
						else	//Reference-drawing
						{
							//result = GRM_find_relation_type("IMAN_reference", &relation_type); //Ujjawal Kumar on 17.0.2022 (For Reference Drg)
							result = GRM_find_relation_type("IMAN_specification", &relation_type);
						}
						printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

						Flag_1=0;
						if (GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist)!=ITK_ok);
						printf("\n\t drw..Total n attches =%d\n",n_attchs);

						itemId12 = strtok(JTid1Tmp,".");
						strcpy(itemId123,itemId12);

						printf("\t drw..Name is --->%s\n\t ",itemId123);

						for (i= 0; i < n_attchs; i++)
						{
							primary=rellist[i].secondary;
							//relationstr=rellist[i].the_relation;
							//relationstr=rellist[i].the_relation; //Sudhir Kumar Srivastava - 09-May-2023 Warning removed in these code ,,, so if you are using this API GRM_list_secondary_objects.. then u need to take care of these types of warning
								ITK_CALL(AOM_ask_name(rellist[i].relation_type,&relationstr)); //Sudhir Kumar Srivastava - 09-May-2023
								printf("\n relationstr:%s ..............",relationstr);fflush(stdout); //Sudhir Kumar Srivastava - 09-May-2023

							if (TCTYPE_ask_object_type(primary,&objTypeTag)!=ITK_ok);
							//printf("\n\t "); fflush(stdout);
							if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);

							//printf("\n\t drw..Type Name:%s ..............",type_name);fflush(stdout);

							if((strcmp(type_name,"ImanFile")==0) || (strcmp(type_name,"icm0")==0))
								continue;

							result = AE_find_datasettype("ProDrw", &datasettype);
							//printf("\n\t drw..Type found---->%d",result);fflush(stdout);

							//printf("\n\t "); fflush(stdout);
							if (AOM_ask_value_string(primary,"object_name",&parent_name)!=ITK_ok);
							printf("\n\t"); fflush(stdout);
							printf("\n\t drw..parent_name:%s ..............",parent_name);fflush(stdout);

							//if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"ProDrw") ==0) //Alokesh strcmp -> strcasecmp (Ignore Cases)
							if(strcasecmp(parent_name,itemId123)==0 &&  strcmp(type_name,"ProDrw") ==0)
							{
								result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
								printf("\n\t drw..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
								if(ref_count_d > 0)
								{
									Flag_1 = 1;
									printf("\n\t drw..Relationship already exist !!!!.......\n\t ");fflush(stdout);

									RefObject_d = namRefObject_d[0];

									if (AOM_ask_value_string(RefObject_d,"object_string",&named_ref)!=ITK_ok);
									printf("\n\t drw..item_tag named_ref:[%s]  DataSetNmOrg: [%s]  JTid1:[%s]",named_ref,DataSetNmOrg,JTid1);

									if ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0) )		//Condition Changed on 05.04.2017
									{
										Flag_1 = 1;
										DatasetFlag = 1;
										printf("...already present and match found.\n");
										break;
									}
									else
									{
										printf("...match not found hence continuing ??? "); fflush(stdout);

										result = AE_ask_dataset (primary,&item_tag_data_rev);
										printf("\n\t drw..AE_ask_dataset--->%d",result);fflush(stdout);
										
										result = GRM_find_relation( item_tag, item_tag_data_rev, relation_type ,&Fndrelation);

										if(Fndrelation != NULLTAG)
										{
											printf("\t deleting relation \n" ); fflush(stdout);
											if (GRM_delete_relation(Fndrelation)!=ITK_ok);
										}

										Flag_1 = 0;
										DatasetFlag = 0;
									}

									//DatasetRelFlag = 1;
									//DatasetExistFlag = 1;

									break;
								}
								else
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t drw..Got reference list--->%d",result);fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t drw..File Imported--->%d",result);fflush(stdout);

									if (result == 41178)
									{
										ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t drw..File saved--->%d",result);fflush(stdout);

									result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
									printf("\n\t drw..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

									AE_set_dataset_tool(primary,tool);
									printf("\n\t drw..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AOM_save(primary);
									printf("\n\t drw..AOM_save--->%d",result);fflush(stdout);fflush(stdout);
									if(result == 0)
									{
										Flag_1 = 1;

										DatasetRelFlag = 1;
										DatasetExistFlag = 1;
									}
								}
							}
							else
							{
								Flag_1 = 0;
								DatasetFlag = 0;
							}
						}

						if(QRY_find("Dataset Name", &queryTag_d));
						printf("  After IFERR_REPORT : QRY_find ....");fflush(stdout);
						if (queryTag_d)
						{
							printf("  Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						else
						{
							printf("  Not Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						qry_values_d[0] = DataSetNm3 ;

						if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
						printf("  drw..resultCount_d:[%d] \n\t",resultCount_d);fflush(stdout);

						if(resultCount_d > 0)
						{
							DatasetFlag = 0;
							for (j=0;j<resultCount_d;j++ )
							{
								itemRevDataSet_tag = revtag_d[j];

								if(TCTYPE_ask_object_type(itemRevDataSet_tag,&datasetTag));
								if(TCTYPE_ask_name(datasetTag,type_name3));
								printf("    drw..Part type_name3 :%s \n\t",type_name3); fflush(stdout);

								if (strcmp(type_name3,"ProDrw")==0)
								{
										item_tag_data_rev = NULLTAG;
									result = AE_ask_dataset (itemRevDataSet_tag,&item_tag_data_rev);

									//printf("\n\t drw..AE_ask_dataset--->%d",result);fflush(stdout);

									result = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
									//printf("\n\t drw..ref_count_d Count--->%d \n\t ",ref_count_d);fflush(stdout);

									if(ref_count_d>0)
									{
										RefObject_d = namRefObject_d[0];

										printf("\t ");fflush(stdout);
										if (AOM_ask_value_string(RefObject_d,"object_string",&named_ref)!=ITK_ok);
										//printf("\n\t drw..item_tag named_ref:[%s]  JTid1:[%s]",named_ref,JTid1); fflush(stdout);

										//if (strcmp(named_ref,JTid1)==0)
										if ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0) )	//Condition Changed on 05.04.2017
										{
											DatasetFlag = 1;
											printf("\n\t drw..item_tag named_ref:[%s]  JTid1:[%s]...already present and match found.\n",named_ref,JTid1); fflush(stdout);
											break;
										}
										else
										{
											if (j == (resultCount_d - 1))
											{
												printf("\n\t prt.....match not found hence continuing..\n"); fflush(stdout);
											}
											DatasetFlag = 0;
										}
									}
								}
							}
							printf("\n\t DatasetFlag:%d ",DatasetFlag); fflush(stdout);

							if(DatasetFlag == 1)
							{
								if(relation_type)
								{
									//printf("\n\t "); fflush(stdout);
									if (TCTYPE_ask_name(relation_type,type_name)!=ITK_ok);
									printf("\n\t Type Name:%s ..............",type_name);fflush(stdout);
								}

								result = GRM_find_relation( item_tag, item_tag_data_rev, relation_type ,&Fndrelation);
								printf("\n\t 1.drw..Fndrelation ---->%d \n\t",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									DatasetRelFlag = 0;

									if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
									printf("  1.item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

									if(n_attchs>0)
									{
										for (i=0; i < n_attchs; i++)
										{
											if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
											if(TCTYPE_ask_name(secObjTypeTag,type_name2));
											printf("    1.drw..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

											if (strcmp(type_name2,"ProDrw")==0)
											{
												printf("  1.drw..Dataset is already attached to Revision \n\t"); fflush(stdout);

												printf("\n\t 1.drw..Relation Already Exist...........\n\n\t" );fflush(stdout);
												DatasetRelFlag = 1;
												DatasetExistFlag = 1;
												if (AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc)!=ITK_ok);
												printf("     1.prt..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);
												if (strcmp(ItemDesc,DatasetDesc) != 0)
												{
													printf("     1.prt..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);
													setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
													if (AOM_save(secondary_objects[i])!=ITK_ok);
													if (AOM_unlock(secondary_objects[i])!=ITK_ok);
												}
												break;
											}
										}
									}
								}
								else
								{
									DatasetRelFlag = 0;
								}

								if (DatasetRelFlag == 0)
								{
									if (GRM_create_relation(item_tag, item_tag_data_rev, relation_type, NULL, &relation)!=ITK_ok);
									printf("\n\t 1.drw..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
									if (AOM_refresh (item_tag,0)!=ITK_ok);
									printf("\n\t ");
									if (AOM_refresh(relation,0)!=ITK_ok);
									result = GRM_save_relation(relation);
									printf("\t 1.drw..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
						else  ///New create dataset
						{
							DatasetFlag = 0;
						}

						if(DatasetFlag == 0)
						{
							result = AE_find_datasettype("ProDrw", &datasettype);
							printf("\n\t Type found---->%d",result);fflush(stdout);

							printf("\n\t Creating New Dataset..."); fflush(stdout);
							result = AE_create_dataset_with_id(datasettype,DataSetNm3,ItemDesc, NULL, NULL, &Newdataset);  //DataSetNm3
							printf("\n\t Dataset created for drw..--->%s",DataSetNm3); fflush(stdout);

							result = AE_set_dataset_format(Newdataset, "BINARY_REF");
							printf("\n\t Dataset format set--->%d",result); fflush(stdout);

							result = AE_set_dataset_tool(Newdataset,tool);
							printf("\n\t Tool set--->%d",result); fflush(stdout);

							result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
							printf("\n\t ****drw..nameRef_cnt Count--->%d",nameRef_cnt);fflush(stdout);

							if (nameRef_cnt == 0)
							{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\n\t Got reference list--->%d",result); fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\n\t drw..File Imported--->%d",result); fflush(stdout);

								if (result == 41178)
								{
									ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
								}

								result = AOM_save(filetag);
								printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

								if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
								result = AOM_save(filetag);
								printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\n\t AE_add_dataset_named_ref--->%d",result); fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t Tool set--->%d",result); fflush(stdout);

								result = AOM_save(Newdataset);
								printf("\n\t AOM_save--->%d",result); fflush(stdout);
							}

							if(relation_type)
							{
								//printf("\n\t "); fflush(stdout);
								if (TCTYPE_ask_name(relation_type,type_name)!=ITK_ok);
								printf("\n\t Type Name:%s ..............",type_name);fflush(stdout);
							}

							result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
							printf("\n\t 2.drw..Fndrelation ---->%d \n\t",result); fflush(stdout);

							if(Fndrelation != NULLTAG)
							{
								DatasetRelFlag = 0;

								if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
								printf("  2.item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

								if(n_attchs>0)
								{
									for (i=0; i < n_attchs; i++)
									{
										if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
										if(TCTYPE_ask_name(secObjTypeTag,type_name2));
										printf("    2.drw..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

										if (strcmp(type_name2,"ProDrw")==0)
										{
											printf("  2.drw..Dataset is already attached to Revision \n\t"); fflush(stdout);

											printf("\n\t 2.drw..Relation Already Exist...........\n\n\t" );fflush(stdout);
											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
											if (AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc)!=ITK_ok);
											printf("     2.prt..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);

											if (strcmp(ItemDesc,DatasetDesc) != 0)
											{
												printf("     2.prt..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

												setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
												if (AOM_save(secondary_objects[i])!=ITK_ok);
												if (AOM_unlock(secondary_objects[i])!=ITK_ok);
											}
											break;
										}
									}
								}
							}
							else
							{
								DatasetRelFlag = 0;
							}

							if (DatasetRelFlag == 0)
							{
								if (GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation)!=ITK_ok);
								printf("\n\t 2.drw..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
								if (AOM_refresh (item_tag,0)!=ITK_ok);
								printf("\n\t ");
								if (AOM_refresh(relation,0)!=ITK_ok);
								result = GRM_save_relation(relation);
								printf("\t 2.drw..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

								DatasetExistFlag = 1;
							}
						}
					}
					else if(tc_strstr(JTid1,".pdf")!=NULL)
					{
						printf("\n\t************** pdf ****************\n\t"); fflush(stdout);

						//ItemDesc =(char *) MEM_alloc(20);
						//strcpy(ItemDesc,"PDF Document");

						result = GRM_find_relation_type("IMAN_Rendering", &relation_type);
						printf("\n\t pdf..GRM_find_relation_type ---->%d",result); fflush(stdout);

						if(QRY_find("Dataset Name", &queryTag_d));
						printf("  After IFERR_REPORT : QRY_find ....");fflush(stdout);
						if (queryTag_d)
						{
							printf("  Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						else
						{
							printf("  Not Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						qry_values_d[0] = DataSetNm3 ;

						if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
						printf("  pdf..resultCount_d:[%d] \n\t",resultCount_d);fflush(stdout);

						if(resultCount_d > 0)
						{
							DatasetFlag = 0;

							for (j=0;j<resultCount_d;j++ )
							{
								itemRevDataSet_tag = revtag_d[j];

								if(TCTYPE_ask_object_type(itemRevDataSet_tag,&datasetTag));
								if(TCTYPE_ask_name(datasetTag,type_name3));
								printf("    pdf..Part type_name3 :%s \n\t",type_name3); fflush(stdout);

								if (strcmp(type_name3,"PDF")==0)
								{
									result = AE_ask_dataset (itemRevDataSet_tag,&item_tag_data_rev);
									printf("\n\t pdf..AE_ask_dataset--->%d\n\t ",result);fflush(stdout);

									if (AOM_ask_value_string(itemRevDataSet_tag,"object_application",&PdfDataItem)!=ITK_ok);
									printf("\n\t pdf..PdfDataItem--->%s",PdfDataItem);fflush(stdout);

									result = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
									printf("\n\t pdf..ref_count_d Count--->%d \n\t ",ref_count_d);fflush(stdout);

									if(ref_count_d>0)
									{
										RefObject_d = namRefObject_d[0];

										if (AOM_ask_value_string(RefObject_d,"object_string",&named_ref)!=ITK_ok);

										printf("\n\t pdf..item_tag named_ref:[%s] JTid1:[%s]  and ",named_ref,JTid1); fflush(stdout);
										printf(" PdfDataItem:[%s] DataItem:[%s]",PdfDataItem,DataItem); fflush(stdout);

										//if (strcmp(named_ref,JTid1)==0)
										//if( (strcmp(named_ref,JTid1)==0) && (strcmp(PdfDataItem,DataItem)==0))
										if( ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0) ) && (strcmp(PdfDataItem,DataItem)==0))	//Condition Changed on 05.04.2017
										{
											DatasetFlag = 1;
											printf("..already present and match found \n\t"); fflush(stdout);
											break;
										}
									}
								}
								//else
								//{
								//	printf("\n\t\t pdf..item_tag named_ref match not found hence continuing....\n\t");
								//	DatasetFlag = 0;
								//}
							}
							printf("\n\t pdf..DatasetFlag:%d ",DatasetFlag); fflush(stdout);

							if(DatasetFlag == 1)
							{
								if(relation_type)
								{
									//printf("\n\t "); fflush(stdout);
									if (TCTYPE_ask_name(relation_type,type_name)!=ITK_ok);
									printf("\n\t pdf..Type Name:%s ..............",type_name);fflush(stdout);
								}

								result = GRM_find_relation( item_tag, item_tag_data_rev, relation_type ,&Fndrelation);
								printf("\n\t pdf..Fndrelation ---->%d \n\t",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									DatasetRelFlag = 0;

									if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
									printf("  1.pdf..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

									if(n_attchs>0)
									{
										for (i=0; i < n_attchs; i++)
										{
											if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
											if(TCTYPE_ask_name(secObjTypeTag,type_name2));
											printf("    1.pdf..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

											if (strcmp(type_name2,"PDF")==0)
											{
												printf("  1.pdf..Dataset is already attached to Revision \n\t"); fflush(stdout);

												printf("\n\t 1.pdf..Relation Already Exist...........\n\n\t" );fflush(stdout);
												DatasetRelFlag = 1;
												DatasetExistFlag = 1;
												break;
											}
										}
									}
								}
								else
								{
									DatasetRelFlag = 0;
								}

								if (DatasetRelFlag == 0)
								{
									if (GRM_create_relation(item_tag, item_tag_data_rev, relation_type, NULL, &relation)!=ITK_ok);
									printf("\n\t 1.pdf..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
									if (AOM_refresh (item_tag,0)!=ITK_ok);
									printf("\n\t ");
									if (AOM_refresh(relation,0)!=ITK_ok);
									result = GRM_save_relation(relation);
									printf("\n\t 1.pdf..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
						else  ///New create dataset
						{
							DatasetFlag = 0;
						}

						if(DatasetFlag == 0)
						{
							result = AE_find_datasettype("PDF", &datasettype);
							printf("\n\t Type found---->%d",result);fflush(stdout);

							printf("\n\t Creating New Dataset..."); fflush(stdout);
							result = AE_create_dataset_with_id(datasettype,DataSetNm3,ItemDesc, NULL, NULL, &Newdataset);
							printf("\n\t Dataset created for prt --->%s \n\t\ ",DataSetNm3); fflush(stdout);

							////if (AOM_set_value_string(Newdataset,"object_application","282947610110.drw.31")!=ITK_ok);
							if (AOM_set_value_string(Newdataset,"object_application",DataItem)!=ITK_ok);

							result = AE_set_dataset_format(Newdataset, "BINARY_REF");
							printf("\n\t Dataset format set--->%d",result); fflush(stdout);

							result = AE_set_dataset_tool(Newdataset,tool);
							printf("\n\t Tool set--->%d",result); fflush(stdout);

							result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
							printf("\n\t ****pdf..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

							if (nameRef_cnt == 0)
							{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\n\t Got reference list--->%d",result); fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\n\t File Imported--->%d",result); fflush(stdout);

								if (result == 41178)
								{
									ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
								}

								result = AOM_save(filetag);
								printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

								if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
								result = AOM_save(filetag);
								printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\n\t AE_add_dataset_named_ref--->%d",result); fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t Tool set--->%d",result); fflush(stdout);

								result = AOM_save(Newdataset);
								printf("\n\t AOM_save--->%d",result); fflush(stdout);
							}

							//if (AOM_ask_value_string(Newdataset,"object_string",&object_string)!=ITK_ok);
							//printf("\n object_string iss :[%s]\n",object_string);

							//result = GRM_find_relation_type("IMAN_Rendering", &relation_type);
							//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

							if(relation_type)
							{
								//printf("\n\t "); fflush(stdout);
								if (TCTYPE_ask_name(relation_type,type_name)!=ITK_ok);
								printf("\n\t Type Name:%s ..............",type_name);fflush(stdout);
							}

							result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
							printf("\n\t Fndrelation ---->%d \n\t",result); fflush(stdout);

							if(Fndrelation != NULLTAG)
							{
								DatasetRelFlag = 0;

								if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
								printf("  2.pdf..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

								if(n_attchs>0)
								{
									for (i=0; i < n_attchs; i++)
									{
										if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
										if(TCTYPE_ask_name(secObjTypeTag,type_name2));
										printf("    2.pdf..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

										if (strcmp(type_name2,"PDF")==0)
										{
											printf("  2.pdf..Dataset is already attached to Revision \n\t"); fflush(stdout);

											printf("\n\t 2.pdf..Relation Already Exist...........\n\n\t" );fflush(stdout);
											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
											break;
										}
									}
								}
							}
							else
							{
								DatasetRelFlag = 0;
							}

							if (DatasetRelFlag == 0)
							{
								if (GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation)!=ITK_ok);
								printf("\n\t 2.pdf..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
								if (AOM_refresh (item_tag,0)!=ITK_ok);
								//printf("\n\t "); fflush(stdout);
								if (AOM_refresh(relation,0)!=ITK_ok);
								result = GRM_save_relation(relation);
								printf("\n\t 2.pdf..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

								DatasetExistFlag = 1;
							}
     					}
					}
					else if((tc_strstr(JTid1,".jt")!=NULL) && ((tc_strstr(JTid1,"_ALF")==NULL) && (tc_strstr(JTid1,"_alf")==NULL) && (tc_strstr(JTid1,"_WELD")==NULL)))
					{
						printf("\n\t************** jt ****************\n\t"); fflush(stdout);

						result = GRM_find_relation_type("IMAN_Rendering", &relation_type);			//added on 06.07.2016 for ViewJTAssembly option for Assy and child
						printf("\n\t jt..GRM_find_relation_type ---->%d \n\t",result); fflush(stdout);

						Flag_1=0;
						if (GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist)!=ITK_ok);
						printf("\n\t jt..Total n attches =%d\n",n_attchs);

						itemId12 = strtok(JTid1,".");
						strcpy(itemId123,itemId12);
						printf("\t jt..Name is --->%s ",itemId123);

						for (i= 0; i < n_attchs; i++)
						{
							primary=rellist[i].secondary;
							//relationstr=rellist[i].the_relation;
							//relationstr=rellist[i].the_relation; //Sudhir Kumar Srivastava - 09-May-2023 Warning removed in these code ,,, so if you are using this API GRM_list_secondary_objects.. then u need to take care of these types of warning
								ITK_CALL(AOM_ask_name(rellist[i].relation_type,&relationstr)); //Sudhir Kumar Srivastava - 09-May-2023
								printf("\n relationstr:%s ..............",relationstr);fflush(stdout); //Sudhir Kumar Srivastava - 09-May-2023

							//printf("\n\t "); fflush(stdout);
							if (TCTYPE_ask_object_type(primary,&objTypeTag)!=ITK_ok);
							//printf("\n\t "); fflush(stdout);
							if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);

							//printf("\n\t jt..Type Name:%s ..............",type_name);fflush(stdout);

							if((strcmp(type_name,"ImanFile")==0) || (strcmp(type_name,"icm0")==0))
								continue;

							result = AE_find_datasettype("DirectModel", &datasettype);
							//printf("\n\t jt..Type found---->%d",result);fflush(stdout);

							//printf("\n\t "); fflush(stdout);
							if (AOM_ask_value_string(primary,"object_name",&parent_name)!=ITK_ok);
							//printf("\n\t jt..parent_name:%s ..............",parent_name);fflush(stdout);

							//if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"DirectModel") ==0) //Alokesh strcmp -> strcasecmp (Ignore Cases)
							if(strcasecmp(parent_name,itemId123)==0 &&  strcmp(type_name,"DirectModel") ==0)
							{
								result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
								printf("\n\t jt..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
								if(ref_count_d>0)
								{
									Flag_1 = 1;
									printf("\n\t jt..Relationship already exist !!!!.......\n");fflush(stdout);

									DatasetRelFlag = 1;
									DatasetExistFlag = 1;

									//break;
								}
								else
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t jt..Got reference list--->%d",result);fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t jt..File Imported--->%d",result);fflush(stdout);

									if (result == 41178)
									{
										ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t jt..File saved--->%d",result);fflush(stdout);

									result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
									printf("\n\t jt..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

									AE_set_dataset_tool(primary,tool);
									printf("\n\t jt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									//sPartNumberTokint = atoi(JTFileSeq);
									//printf("\n Spec-cgr-Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
									//WSOM_set_revision(primary,sPartNumberTokint);

									printf("\n\t jt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AOM_save(primary);
									if(result == 0)
									{
										Flag_1 = 1;

										DatasetRelFlag = 1;
										DatasetExistFlag = 1;
									}
								}

								////////////////////////////////////////////////////////////////////////////
								if(DatasetRelFlag == 1)
								{
									if(relation_type)
									{
										//printf("\n\t "); fflush(stdout);
										if (TCTYPE_ask_name(relation_type,type_name)!=ITK_ok);
										printf("\t 11.jt..Type Name:%s ..............",type_name);fflush(stdout);
									}

									//result = GRM_find_relation( item_tag, primary, relation_type ,&Fndrelation);
									result = GRM_find_relation( item_tag, objTypeTag, relation_type ,&Fndrelation);
									printf("\n\t 11.jt..Fndrelation ---->%d \n\t",result); fflush(stdout);

									if(Fndrelation != NULLTAG)
									{
										DatasetRelFlag = 0;

										if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
										printf("  11.jt..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

										if(n_attchs>0)
										{
											for (i=0; i < n_attchs; i++)
											{
												if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
												if(TCTYPE_ask_name(secObjTypeTag,type_name2));
												printf("    11.jt..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

												if (strcmp(type_name2,"DirectModel")==0)
												{
													printf("  11.jt..Dataset is already attached to Revision \n\t"); fflush(stdout);

													printf("\n\t 11.jt..Relation Already Exist...........\n\n\t" );fflush(stdout);
													DatasetRelFlag = 1;
													DatasetExistFlag = 1;

													if (AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc)!=ITK_ok);
													printf("     11.jt..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);
													if (strcmp(ItemDesc,DatasetDesc) != 0)
													{
														printf("     11.jt..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

														setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
														if (AOM_save(secondary_objects[i])!=ITK_ok);
														if (AOM_unlock(secondary_objects[i])!=ITK_ok);
													}

													break;
												}
											}
										}
									}
									else
									{
										printf("     11.jt..JT attached to Design Revision but not having proper relation.....\n\t"); fflush(stdout);

										result = GRM_find_relation_type("IMAN_specification", &relationSpeci_type);

										result = GRM_find_relation( item_tag, primary, relationSpeci_type ,&FndSpeciRelation);
										printf("\n\t 11.jt.....FndSpeciRelation ---->%d \n\t",result); fflush(stdout);

										if(FndSpeciRelation != NULLTAG)
										{
											if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
											printf("  11.jt..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

											if(n_attchs>0)
											{
												for (i=0; i < n_attchs; i++)
												{
													if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
													if(TCTYPE_ask_name(secObjTypeTag,type_name2));
													printf("    11.jt..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

													if (strcmp(type_name2,"DirectModel")==0)
													{
														printf("  11.jt..Dataset is already attached to Revision \n\t"); fflush(stdout);

														if (GRM_delete_relation(FndSpeciRelation)!=ITK_ok);

														DatasetRelFlag = 0;

														result = GRM_create_relation(item_tag, primary, relation_type, NULL, &relation);
														printf("\n\t jt..GRM_create_relation ---->%d",result);fflush(stdout);
														result = GRM_save_relation(relation);
														printf("\n\t jt..GRM_save_relation ---->%d\n",result);fflush(stdout);

														DatasetRelFlag = 1;
														DatasetExistFlag = 1;

														break;
													}
												}
											}
										}

										//exit( EXIT_FAILURE );
									}
								}

								if ( DatasetExistFlag == 1 )
								{								
									break;
								}
								///////////////////////////////////////////////////////////////////////////
							}
						} // for loop end

						if (Flag_1 == 0)
						{
							result = AE_find_datasettype("DirectModel", &datasettype);
							printf("\n\t jt..Type found---->%d",result);fflush(stdout);

							result = AE_create_dataset_with_id(datasettype,itemId123,ItemDesc, NULL, NULL, &Newdataset);
							printf("\n\t jt..Dataset created--->%s",itemId123);fflush(stdout);

							result = AE_set_dataset_format(Newdataset, "BINARY_REF");
							printf("\n\t jt..Dataset format set--->%d",result);fflush(stdout);

							result = AE_set_dataset_tool(Newdataset,tool);
							printf("\n\t jt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

							result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
							printf("\n\t jt..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

							if (nameRef_cnt == 0)
							{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\n\t jt..Got reference list--->%d",result);fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\n\t jt..File Imported--->%d",result);fflush(stdout);

								if (result == 41178)
								{
									ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
								}

								result = AOM_save(filetag);
								printf("\n\t jt..File saved--->%d",result);fflush(stdout);

								if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
								result = AOM_save(filetag);
								printf("\n\t Spec-cgr-File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\n\t jt..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t jt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								printf("\n\t jt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AOM_save(Newdataset);
							}

							if(relation_type)
							{
								//printf("\n\t "); fflush(stdout);
								if (TCTYPE_ask_name(relation_type,type_name)!=ITK_ok);
								printf("\t jt..Type Name:%s ..............",type_name);fflush(stdout);
							}


							result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
							printf("\n\t jt..Fndrelation ---->%d",result); fflush(stdout);

							if(Fndrelation != NULLTAG)
							{
								printf("\n\t jt..Relation Already Exist...........\n\n" );fflush(stdout);
							}
							else
							{
								result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
								printf("\n\t jt..GRM_create_relation ---->%d",result);fflush(stdout);
								result = GRM_save_relation(relation);
								printf("\n\t jt..GRM_save_relation ---->%d\n",result);fflush(stdout);

								DatasetExistFlag = 1;
							}
						}
					}
					/*else if((tc_strstr(JTid1,".jt")!=NULL) && ((tc_strstr(JTid1,"_ALF")==NULL) && (tc_strstr(JTid1,"_alf")==NULL) && (tc_strstr(JTid1,"_WELD")==NULL)))
					{
						printf("\n\t************** jt ****************\n\t"); fflush(stdout);

						//ItemDesc =(char *) MEM_alloc(20);
						//strcpy(ItemDesc,"JT Document");

						//if (strcmp(ClassName,"ProAsm")==0)		// commented on 06.07.2016
						//{
						//	result = GRM_find_relation_type("IMAN_specification", &relation_type);
						//	printf("\n\t jt..GRM_find_relation_type ---->%d",result); fflush(stdout);
						//}
						//else if (strcmp(ClassName,"ProPrt")==0)
						//{
						//	result = GRM_find_relation_type("IMAN_Rendering", &relation_type);
						//	printf("\n\t jt..GRM_find_relation_type ---->%d",result); fflush(stdout);
						//}

						result = GRM_find_relation_type("IMAN_Rendering", &relation_type);			//added on 06.07.2016 for ViewJTAssembly option for Assy and child
						printf("\n\t jt..GRM_find_relation_type ---->%d",result); fflush(stdout);

						if(QRY_find("Dataset Name", &queryTag_d));
						printf("  After IFERR_REPORT : QRY_find ....");fflush(stdout);
						if (queryTag_d)
						{
							printf("  Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						else
						{
							printf("  Not Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						qry_values_d[0] = DataSetNm3 ;

						if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
						printf("  jt..resultCount_d:[%d] \n\t",resultCount_d);fflush(stdout);

						if(resultCount_d > 0)
						{
							DatasetFlag = 0;

							for (j=0;j<resultCount_d;j++ )
							{
								itemRevDataSet_tag = revtag_d[j];

								if(TCTYPE_ask_object_type(itemRevDataSet_tag,&datasetTag));
								if(TCTYPE_ask_name(datasetTag,type_name3));
								printf("    jt..Part type_name3 :%s \n\t",type_name3); fflush(stdout);

								if (strcmp(type_name3,"DirectModel")==0)
								{
									result = AE_ask_dataset (itemRevDataSet_tag,&item_tag_data_rev);
									printf(" jt..AE_ask_dataset--->%d\n\t ",result);fflush(stdout);

									if (AOM_ask_value_string(itemRevDataSet_tag,"object_application",&PdfDataItem)!=ITK_ok);

									if(strlen(PdfDataItem)>30)
									{
										PdfDataItem1 = NULL;
										PdfDataItem1=(char *) MEM_alloc(30);
										//PdfDataItem1=(char *) MEM_alloc(30 * sizeof(char *));
										strncpy(PdfDataItem1,PdfDataItem,29);

										//PdfDataItem=(char *) MEM_alloc(30 * sizeof(char *));
										PdfDataItem=(char *) MEM_alloc(30);
										strcpy(PdfDataItem,PdfDataItem1);

										PdfDataItem[strlen(PdfDataItem)] = '\0';
									}
									printf("\n\t jt..PdfDataItem--->%s",PdfDataItem);fflush(stdout);

									result = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
									printf("\n\t jt..ref_count_d Count--->%d \n\t ",ref_count_d);fflush(stdout);

									if(ref_count_d>0)
									{
										RefObject_d = namRefObject_d[0];

										if (AOM_ask_value_string(RefObject_d,"object_string",&named_ref2)!=ITK_ok);

										printf("\t jt..item_tag named_ref2:[%s]...JTid1:[%s] ",named_ref2,JTid1);

										named_ref=(char *) MEM_alloc(100);
										strcpy(named_ref,"");

										//JtTemp=strtok(named_ref2,".");	//commented on 03.10.2016
										//////printf("  JtTemp:[%s]",JtTemp);
										//strcpy(named_ref,JtTemp);
										//strcat(named_ref,".jt");
										//

										if(tc_strstr(named_ref2,"#")!=NULL)
										{
											JtTemp=strtok(named_ref2,"#");
											named_ref=strtok(NULL,"#");
											//printf("  JtTemp:[%s]",JtTemp);
										}
										else
										{
											strcpy(named_ref,named_ref2);
										}

										printf("  named_ref:[%s]  and PdfDataItem:[%s] DataItem:[%s]",named_ref,PdfDataItem,DataItem);

										if ((strcmp(ClassName,"ProPrtI")==0) || (strcmp(ClassName,"ProAsmI")==0) || ((strlen(itemId)==11) && (strcmp(ClassName,"ProPrt")==0)))
										{
											//if((strcmp(named_ref,JTid1)==0))
											if ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0) )		//Condition Changed on 05.04.2017
											{
												DatasetFlag = 1;
												printf("..1.already present and match found \n\t");
												break;
											}
										}
										else
										{
											//if (strcmp(named_ref,JTid1)==0)
											//if( (strcmp(named_ref,JTid1)==0) && (strcmp(PdfDataItem,DataItem)==0))
											if( ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0)) && (strcmp(PdfDataItem,DataItem)==0))	//Condition Changed on 05.04.2017
											{
												DatasetFlag = 1;
												printf("..2.already present and match found \n\t");
												break;
											}
										}
									}
								}
								//else
								//{
								//	printf("\n\t\t jt..item_tag named_ref match not found hence continuing....\n\t");
								//	DatasetFlag = 0;
								//}
							}
							printf("\n\t jt..DatasetFlag:%d ",DatasetFlag);

							if(DatasetFlag == 1)
							{
								//result = GRM_find_relation_type("IMAN_specification", &relation_type);
								//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

								if(relation_type)
								{
									//printf("\n\t "); fflush(stdout);
									if (TCTYPE_ask_name(relation_type,type_name)!=ITK_ok);
									printf("\t jt..Type Name:%s ..............",type_name);fflush(stdout);
								}

								result = GRM_find_relation( item_tag, item_tag_data_rev, relation_type ,&Fndrelation);
								printf("\n\t jt..Fndrelation ---->%d \n\t",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									DatasetRelFlag = 0;

									if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
									printf("  1.jt..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

									if(n_attchs>0)
									{
										for (i=0; i < n_attchs; i++)
										{
											if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
											if(TCTYPE_ask_name(secObjTypeTag,type_name2));
											printf("    1.jt..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

											if (strcmp(type_name2,"DirectModel")==0)
											{
												printf("  1.jt..Dataset is already attached to Revision \n\t"); fflush(stdout);

												printf("\n\t 1.jt..Relation Already Exist...........\n\n\t" );fflush(stdout);
												DatasetRelFlag = 1;
												DatasetExistFlag = 1;

												if (AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc)!=ITK_ok);
												printf("     1.jt..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);
												if (strcmp(ItemDesc,DatasetDesc) != 0)
												{
													printf("     1.jt..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

													setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
													if (AOM_save(secondary_objects[i])!=ITK_ok);
													if (AOM_unlock(secondary_objects[i])!=ITK_ok);
												}

												break;
											}
										}
									}
								}
								else
								{
									DatasetRelFlag = 0;
								}

								if (DatasetRelFlag == 0)
								{
									if (GRM_create_relation(item_tag, item_tag_data_rev, relation_type, NULL, &relation)!=ITK_ok);
									printf("\n\t 1.jt..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
									if (AOM_refresh (item_tag,0)!=ITK_ok);
									printf("\n\t ");
									if (AOM_refresh(relation,0)!=ITK_ok);
									result = GRM_save_relation(relation);
									printf("\n\t 1.jt..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
						else  ///New create dataset
						{
							DatasetFlag = 0;
						}

						if(DatasetFlag == 0)
						{
							result = AE_find_datasettype("DirectModel", &datasettype);
							printf("\n\t Type found---->%d",result);fflush(stdout);

							printf("\n\t Creating New Dataset..."); fflush(stdout);

							//result = AE_create_dataset_with_id(datasettype,DataSetNm3,ItemDesc, NULL, NULL, &Newdataset);
							//printf("\n\t Dataset created for jt --->%s \n\t\ ",DataSetNm3); fflush(stdout);
							result = AE_create_dataset_with_id(datasettype,itemId,ItemDesc, NULL, NULL, &Newdataset);
							printf("\n\t Dataset created for jt --->%s \n\t ",itemId); fflush(stdout);

							////if (AOM_set_value_string(Newdataset,"object_application","282947610110.drw.31")!=ITK_ok);
							if (((strlen(itemId)==11) || (tc_strstr(DataItem,"<")!=NULL)) && (tc_strstr(ClassName,"ProPrt")!=NULL))
							{
								printf("\n\t .....111111",result); fflush(stdout);
							}
							else
							{
								printf("\n\t .....1122",result); fflush(stdout);
								if (AOM_set_value_string(Newdataset,"object_application",DataItem)!=ITK_ok);
							}

							result = AE_set_dataset_format(Newdataset, "BINARY_REF");
							printf("\n\t Dataset format set--->%d",result); fflush(stdout);

							result = AE_set_dataset_tool(Newdataset,tool);
							printf("\n\t Tool set--->%d",result); fflush(stdout);

							result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
							printf("\n\t nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

							if (nameRef_cnt == 0)
							{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\n\t Got reference list--->%d \n\t ",result); fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\n\t File Imported--->%d  [%s]",result,fullPath); fflush(stdout);

								//if (result == 41178)
								if (result != 0)
								{
									ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
								}

								result = AOM_save(filetag);
								printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

								if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
								result = AOM_save(filetag);
								printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\n\t AE_add_dataset_named_ref--->%d",result); fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t Tool set--->%d",result); fflush(stdout);

								result = AOM_save(Newdataset);
								printf("\n\t AOM_save--->%d",result); fflush(stdout);
							}

							//if (AOM_ask_value_string(Newdataset,"object_string",&object_string)!=ITK_ok);
							//printf("\n object_string iss :[%s]\n",object_string);

							//result = GRM_find_relation_type("IMAN_specification", &relation_type);
							//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

							if(relation_type)
							{
								//printf("\n\t "); fflush(stdout);
								if (TCTYPE_ask_name(relation_type,type_name)!=ITK_ok);
								printf("\n\t Type Name:%s ..............",type_name);fflush(stdout);
							}

							result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
							printf("\n\t Fndrelation ---->%d \n\t",result); fflush(stdout);

							if(Fndrelation != NULLTAG)
							{
								DatasetRelFlag = 0;

								if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
								printf("  2.jt..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

								if(n_attchs>0)
								{
									for (i=0; i < n_attchs; i++)
									{
										if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
										if(TCTYPE_ask_name(secObjTypeTag,type_name2));
										printf("    2.jt..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

										if (strcmp(type_name2,"DirectModel")==0)
										{
											printf("  2.jt..Dataset is already attached to Revision \n\t"); fflush(stdout);

											printf("\n\t 2.jt..Relation Already Exist.\n\t" );fflush(stdout);
											DatasetRelFlag = 1;
											DatasetExistFlag = 1;

											if (AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc)!=ITK_ok);
											printf("     1.jt..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);
											if (strcmp(ItemDesc,DatasetDesc) != 0)
											{
												printf("     2.jt..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

												setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
												if (AOM_save(secondary_objects[i])!=ITK_ok);
												if (AOM_unlock(secondary_objects[i])!=ITK_ok);
											}

											break;
										}
									}
								}
							}
							else
							{
								DatasetRelFlag = 0;
							}

							if (DatasetRelFlag == 0)
							{
								if (GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation)!=ITK_ok);
								printf("\n\t 2.jt..GRM_create_relation ---->%d\n\t ",result); fflush(stdout);
								if (AOM_refresh (item_tag,0)!=ITK_ok);
								printf("\n\t ");
								if (AOM_refresh(relation,0)!=ITK_ok);
								result = GRM_save_relation(relation);
								printf("\n\t 2.jt..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

								DatasetExistFlag = 1;
							}
     					}

						//printf("    jt..DatasetFlag:%d  DatasetExistFlag:%d  DatasetRelFlag:%d \n\t",DatasetFlag,DatasetExistFlag,DatasetRelFlag); fflush(stdout);
						//if (DatasetExistFlag == 1)
						//{
						//	//printf("    jt..exit\n"); fflush(stdout);
						//	break;
						//}
					}*/
					else if((tc_strstr(JTid1,".jt")!=NULL) && ((tc_strstr(JTid1,"_ALF")!=NULL) || (tc_strstr(JTid1,"_alf")!=NULL) || (tc_strstr(JTid1,"_WELD")!=NULL)))
					{
						printf("\n\t************** ALF-jt ****************\n\t"); fflush(stdout);

						ItemDesc=NULL;
						ItemDesc =(char *) MEM_alloc(20);
						strcpy(ItemDesc,"iPEM Override JT");

						result = GRM_find_relation_type("IMAN_Rendering", &relation_type);	//added on 06.07.2016 for ViewJTAssembly option for Assy and child
						printf("\n\t ALF-jt..GRM_find_relation_type ---->%d",result); fflush(stdout);

						if(QRY_find("Dataset Name", &queryTag_d));
						printf("  After IFERR_REPORT : QRY_find ....");fflush(stdout);
						if (queryTag_d)
						{
							printf("  Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						else
						{
							printf("  Not Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						qry_values_d[0] = itemId ;
						//qry_values_d[0] = DataSetNm3 ;

						if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
						printf("  ALF-jt..resultCount_d:[%d] \n\t",resultCount_d);fflush(stdout);

						if(resultCount_d > 0)
						{
							DatasetFlag = 0;

							for (j=0;j<resultCount_d;j++ )
							{
								itemRevDataSet_tag = revtag_d[j];

								if(TCTYPE_ask_object_type(itemRevDataSet_tag,&datasetTag));
								if(TCTYPE_ask_name(datasetTag,type_name3));
								//printf("    ALF-jt..Part type_name3 :%s \n\t",type_name3); fflush(stdout);

								if (strcmp(type_name3,"DirectModel")==0)
								{
									result = AE_ask_dataset (itemRevDataSet_tag,&item_tag_data_rev);
									//printf("\n\t ALF-jt..AE_ask_dataset--->%d\n\t ",result);fflush(stdout);

									if (AOM_ask_value_string(itemRevDataSet_tag,"object_application",&PdfDataItem)!=ITK_ok);
									printf("\n\t ALF-jt..PdfDataItem--->%s",PdfDataItem);fflush(stdout);

									result = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
									//printf("\n\t ALF-jt..ref_count_d Count--->%d \n\t ",ref_count_d);fflush(stdout);

									if(ref_count_d>0)
									{
										RefObject_d = namRefObject_d[0];

										if (AOM_ask_value_string(RefObject_d,"object_string",&named_ref2)!=ITK_ok);

										printf("\n\t ALF-jt..item_tag named_ref2:[%s]...JTid1:[%s] ",named_ref2,JTid1);

										named_ref=(char *) MEM_alloc(100);
										strcpy(named_ref,"");
										JtTemp=strtok(named_ref2,".");
										//printf("  JtTemp:[%s]",JtTemp);
										strcpy(named_ref,JtTemp);
										strcat(named_ref,".jt");

										printf("  named_ref:[%s]",named_ref);
										//printf("  named_ref:[%s]  and PdfDataItem:[%s] DataItem:[%s]",named_ref,PdfDataItem,DataItem);

										//if( (strcmp(named_ref,JTid1)==0) && (strcmp(PdfDataItem,DataItem)==0))	//old Condition
										//if (strcmp(named_ref,JTid1)==0)	//commented on 05.04.2017
										if ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0) )		//Condition Changed on 05.04.2017
										{
											DatasetFlag = 1;

											DatasetExistFlag = 1;

											printf("..already present and match found \n\t");
											break;
										}
									}
								}
								//else
								//{
								//	printf("\n\t\t jt..item_tag named_ref match not found hence continuing....\n\t");
								//	DatasetFlag = 0;
								//}
							}
							printf("\n\t ALF-jt..DatasetFlag:%d  already present",DatasetFlag);
						}
						else  ///New create dataset
						{
							DatasetFlag = 0;
						}

						if(DatasetFlag == 0)
						{
							result = AE_find_datasettype("DirectModel", &datasettype);
							printf("\n\t Type found---->%d",result);fflush(stdout);

							printf("\n\t Creating New Dataset..."); fflush(stdout);
							//result = AE_create_dataset_with_id(datasettype,DataSetNm3,ItemDesc, NULL, NULL, &Newdataset);
							//printf("\n\t Dataset created for prt --->%s \n\t\ ",DataSetNm3); fflush(stdout);
							result = AE_create_dataset_with_id(datasettype,itemId,ItemDesc, NULL, NULL, &Newdataset);
							printf("\n\t Dataset created for prt --->%s \n\t\ ",itemId); fflush(stdout);

							////if (AOM_set_value_string(Newdataset,"object_application","281832308207_reinfbkt.prt.3")!=ITK_ok);
							//if (AOM_set_value_string(Newdataset,"object_application",DataItem)!=ITK_ok);

							result = AE_set_dataset_format(Newdataset, "BINARY_REF");
							printf("\n\t Dataset format set--->%d",result); fflush(stdout);

							result = AE_set_dataset_tool(Newdataset,tool);
							printf("\n\t Tool set--->%d",result); fflush(stdout);

							result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
							printf("\n\t nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

							if (nameRef_cnt == 0)
							{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\n\t Got reference list--->%d \n\t ",result); fflush(stdout);

								//result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								//printf("\n\t File Imported--->%d  [%s]",result,fullPath); fflush(stdout);

								if (IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor)!=ITK_ok);

								result = AOM_save(filetag);
								printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

								if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
								result = AOM_save(filetag);
								printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\n\t ALF-jt..AE_add_dataset_named_ref--->%d",result); fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t ALF-jt..Tool set--->%d",result); fflush(stdout);

								result = AOM_save(Newdataset);
								printf("\n\t ALF-jt..AOM_save--->%d",result); fflush(stdout);
							}

							DatasetExistFlag = 1;
						}
					}
					else if(tc_strstr(JTid1,".CATPart")!=NULL)
					{
						result = GRM_find_relation_type("IMAN_specification", &relation_type);
						printf("\n\t CATPart..GRM_find_relation_type ---->%d",result); fflush(stdout);

						if(tc_strstr(JTid1,"Spec")!=NULL)
						{
							if((tc_strstr(JTid1,"Spec")!=NULL) && (tc_strstr(JTid1,".CATPart")!=NULL) && (tc_strstr(JTid1,".cgr")!=NULL))
							{
								printf("\n\n\t **************cgr Spec CATPart CMI2CacheCgr****************\n\t"); fflush(stdout);

								Flag_1=0;
								if (GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist)!=ITK_ok);
								printf("\n\t Spec-cgr-CATPart..Total n attches =%d\n",n_attchs);

								itemId12 = strtok(JTid1,".");
								strcpy(itemId123,itemId12);
								//strcat(itemId123,".cgr"); //SOURAV KARAK - Impacts CATIA File - 27-Apr-2023
								printf("\t Spec-cgr-CATPart..Name is --->%s\n\t ",itemId123);

								for (i= 0; i < n_attchs; i++)
								{
									primary=rellist[i].secondary;
									//relationstr=rellist[i].the_relation;
									//relationstr=rellist[i].the_relation; //Sudhir Kumar Srivastava - 09-May-2023 Warning removed in these code ,,, so if you are using this API GRM_list_secondary_objects.. then u need to take care of these types of warning
								ITK_CALL(AOM_ask_name(rellist[i].relation_type,&relationstr)); //Sudhir Kumar Srivastava - 09-May-2023
								printf("\n relationstr:%s ..............",relationstr);fflush(stdout); //Sudhir Kumar Srivastava - 09-May-2023

									if (TCTYPE_ask_object_type(primary,&objTypeTag)!=ITK_ok);
									//printf("\n\t "); fflush(stdout);
									if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);

									//printf("\n\t Spec-cgr-CATPart..Type Name:%s ..............",type_name);fflush(stdout);

									if((strcmp(type_name,"ImanFile")==0) || (strcmp(type_name,"icm0")==0))
										continue;

									result = AE_find_datasettype("CMI2CacheCgr", &datasettype);
									//printf("\n\t Spec-cgr-CATPart..Type found---->%d",result);fflush(stdout);

									//printf("\n\t "); fflush(stdout);
									if (AOM_ask_value_string(primary,"object_name",&parent_name)!=ITK_ok);
									//printf("\n\t Spec-cgr-CATPart..parent_name:%s ..............",parent_name);fflush(stdout);

									//if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2CacheCgr") ==0) //Alokesh strcmp -> strcasecmp (Ignore Cases)
									if(strcasecmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2CacheCgr") ==0)
									{
										result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
										printf("\n\t Spec-cgr-CATPart..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
										if(ref_count_d>0)
										{
											Flag_1 = 1;
											printf("\n\t Spec-cgr-CATPart..Relationship already exist !!!!.......\n");fflush(stdout);

											DatasetRelFlag = 1;
											DatasetExistFlag = 1;

											break;
										}
										else
										{
											result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
											printf("\n\t Spec-cgr-CATPart..Got reference list--->%d",result);fflush(stdout);

											result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
											printf("\n\t Spec-cgr-CATPart..File Imported--->%d",result);fflush(stdout);

											if (result == 41178)
											{
												ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
											}

											result = AOM_save(filetag);
											printf("\n\t Spec-cgr-CATPart..File saved--->%d",result);fflush(stdout);

											result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
											printf("\n\t Spec-cgr-CATPart..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

											AE_set_dataset_tool(primary,tool);
											printf("\n\t Spec-cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

											//sPartNumberTokint = atoi(JTFileSeq);
											//printf("\n Spec-cgr-Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
											//WSOM_set_revision(primary,sPartNumberTokint);

											printf("\n\t Spec-cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

											result = AOM_save(primary);
											if(result == 0)
											{
												Flag_1 = 1;

												DatasetRelFlag = 1;
												DatasetExistFlag = 1;
											}
										}
									}
								}
								if (Flag_1 == 0)
								{
									//ItemDesc =(char *) MEM_alloc(20);
									//strcpy(ItemDesc,"Spec CMI2CacheCgr Document");

									result = AE_find_datasettype("CMI2CacheCgr", &datasettype);
									printf("\n\t Spec-cgr-CATPart..Type found---->%d",result);fflush(stdout);

									result = AE_create_dataset_with_id(datasettype,itemId123,ItemDesc, NULL, NULL, &Newdataset);
									printf("\n\t Spec-cgr-CATPart..Dataset created--->%s",itemId123);fflush(stdout);

									result = AE_set_dataset_format(Newdataset, "BINARY_REF");
									printf("\n\t Spec-cgr-CATPart..Dataset format set--->%d",result);fflush(stdout);

									result = AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t Spec-cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
									printf("\n\t Spec-cgr-CATPart..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

									if (nameRef_cnt == 0)
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t Spec-cgr-CATPart..Got reference list--->%d",result);fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t Spec-cgr-CATPart..File Imported--->%d",result);fflush(stdout);

										if (result == 41178)
										{
											ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
										}

										result = AOM_save(filetag);
										printf("\n\t Spec-cgr-CATPart..File saved--->%d",result);fflush(stdout);

										if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
										result = AOM_save(filetag);
										printf("\n\t Spec-cgr-File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

										result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
										printf("\n\t Spec-cgr-CATPart..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

										AE_set_dataset_tool(Newdataset,tool);
										printf("\n\t Spec-cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										printf("\n\t Spec-cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										result = AOM_save(Newdataset);
									}

									printf("\n\t Spec-cgr-CATPart..GRM_find_relation_type ---->%d",result);fflush(stdout);

									result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
									printf("\n\t Spec-cgr-CATPart..Fndrelation ---->%d",result); fflush(stdout);

									if(Fndrelation != NULLTAG)
									{
										printf("\n\t Spec-cgr-CATPart..Relation Already Exist...........\n\n" );fflush(stdout);
									}
									else
									{
										result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
										printf("\n\t Spec-cgr-CATPart..GRM_create_relation ---->%d",result);fflush(stdout);
										result = GRM_save_relation(relation);
										printf("\n\t Spec-cgr-CATPart..GRM_save_relation ---->%d\n",result);fflush(stdout);

										DatasetExistFlag = 1;
									}
								}
							}
							else
							{
								printf("\n\n\t **************Spec CATPart CMI2AuxPart****************\n\t"); fflush(stdout);

								Flag_1=0;
								if (GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist)!=ITK_ok);
								printf("\n\t Spec-CATPart-CMI2AuxPart..Total n attches = %d",n_attchs);

								itemId12 = strtok(JTid1,".");
								strcpy(itemId123,itemId12);
								printf("\n\t Spec-CATPart-CMI2AuxPart..Name is ---> %s\n\t ",itemId123); fflush(stdout);

								for (i= 0; i < n_attchs; i++)
								{
									primary=rellist[i].secondary;
									//relationstr=rellist[i].the_relation;
									//relationstr=rellist[i].the_relation; //Sudhir Kumar Srivastava - 09-May-2023 Warning removed in these code ,,, so if you are using this API GRM_list_secondary_objects.. then u need to take care of these types of warning
								ITK_CALL(AOM_ask_name(rellist[i].relation_type,&relationstr)); //Sudhir Kumar Srivastava - 09-May-2023
								printf("\n relationstr:%s ..............",relationstr);fflush(stdout); //Sudhir Kumar Srivastava - 09-May-2023

									//printf("\n\t "); fflush(stdout);
									if (TCTYPE_ask_object_type(primary,&objTypeTag)!=ITK_ok);
									printf("\t "); fflush(stdout);
									if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);

									//printf("\n\t Spec-CATPart-CMI2AuxPart..Type Name:%s ..............",type_name);fflush(stdout);

									if((strcmp(type_name,"ImanFile")==0) || (strcmp(type_name,"icm0")==0))
										continue;

									result = AE_find_datasettype("CMI2AuxPart", &datasettype);
									//printf("\n\t Spec-CATPart-CMI2AuxPart..Type found---->%d",result);fflush(stdout);

									printf("\t ");fflush(stdout);
									if (AOM_ask_value_string(primary,"object_name",&parent_name)!=ITK_ok);
									//printf("\n\t Spec-CATPart-CMI2AuxPart..parent_name:%s ..............",parent_name);fflush(stdout);

									//if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2AuxPart") ==0) //Alokesh strcmp -> strcasecmp (Ignore Cases)
									if(strcasecmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2AuxPart") ==0)
									{
										result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
										printf("\n\t Spec-CATPart-CMI2AuxPart..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
										if(ref_count_d>0)
										{
											Flag_1 = 1;
											printf("\n\t Spec-CATPart-CMI2AuxPart..Relationship already exist !!!!.......\n");fflush(stdout);

											DatasetRelFlag = 1;
											DatasetExistFlag = 1;

											break;
										}
										else
										{
											result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
											printf("\n\t 1.Spec-CATPart-CMI2AuxPart..Got reference list--->%d",result);fflush(stdout);

											result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
											printf("\n\t 1.Spec-CATPart-CMI2AuxPart..File Imported--->%d   [%s]",result,fullPath);fflush(stdout);

											if (result == 41178)
											{
												ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
											}

											result = AOM_save(filetag);
											printf("\n\t 1.Spec-CATPart-CMI2AuxPart..File saved--->%d",result);fflush(stdout);

											if (result == 7007)
											{
												Flag_1 = -1;

												break;
											}
											else
											{
												if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
												result = AOM_save(filetag);
												printf("\n\t 1.Spec-cgr-File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);
											}

											result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
											printf("\n\t 1.Spec-CATPart-CMI2AuxPart..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

											AE_set_dataset_tool(primary,tool);
											printf("\n\t 1.Spec-CATPart-CMI2AuxPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

											//sPartNumberTokint = atoi(JTFileSeq);
											//printf("\n Spec-cgr-Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
											//WSOM_set_revision(primary,sPartNumberTokint);

											printf("\n\t 1.Spec-CATPart-CMI2AuxPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

											result = AOM_save(primary);
											if(result == 0)
											{
												Flag_1 = 1;

												DatasetRelFlag = 1;
												DatasetExistFlag = 1;
											}
										}
									}
								}
								if (Flag_1 == 0)
								{
									//ItemDesc =(char *) MEM_alloc(20);
									//strcpy(ItemDesc,"Spec CMI2AuxPart Document");

									result = AE_find_datasettype("CMI2AuxPart", &datasettype);
									printf("\n\t Spec-CATPart-CMI2AuxPart..Type found----> %d",result);fflush(stdout);

									result = AE_create_dataset_with_id(datasettype,itemId123,ItemDesc, NULL, NULL, &Newdataset);
									printf("\n\t Spec-CATPart-CMI2AuxPart..Dataset created---> %s",itemId123);fflush(stdout);

									result = AE_set_dataset_format(Newdataset, "BINARY_REF");
									printf("\n\t Spec-CATPart-CMI2AuxPart..Dataset format set---> %d",result);fflush(stdout);

									result = AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t Spec-CATPart-CMI2AuxPart..Tool set---> %d",result);fflush(stdout);fflush(stdout);

									result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
									printf("\n\t Spec-CATPart-CMI2AuxPart..nameRef_cnt Count---> %d",nameRef_cnt);fflush(stdout);

									if (nameRef_cnt == 0)
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t Spec-CATPart-CMI2AuxPart..Got reference list---> %d",result);fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t Spec-CATPart-CMI2AuxPart..File Imported---> %d   [%s]",result,fullPath);fflush(stdout);

										if (result == 41178)
										{
											ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
										}

										result = AOM_save(filetag);
										printf("\n\t Spec-CATPart-CMI2AuxPart..File saved---> %d",result);fflush(stdout);

										if (result == 7007)
										{
											break;
										}
										else
										{
											if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
											result = AOM_save(filetag);
											printf("\n\t Spec-cgr-File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);
										}

										result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
										printf("\n\t Spec-CATPart-CMI2AuxPart..AE_add_dataset_named_ref---> %d",result);fflush(stdout);

										AE_set_dataset_tool(Newdataset,tool);
										printf("\n\t Spec-CATPart-CMI2AuxPart..Tool set---> %d",result);fflush(stdout);fflush(stdout);

										printf("\n\t Spec-CATPart-CMI2AuxPart..Tool set---> %d",result);fflush(stdout);fflush(stdout);

										result = AOM_save(Newdataset);
									}

									printf("\n\t Spec-CATPart-CMI2AuxPart..GRM_find_relation_type ----> %d",result);fflush(stdout);

									result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
									printf("\n\t Spec-CATPart-CMI2AuxPart..Fndrelation ----> %d",result); fflush(stdout);

									if(Fndrelation != NULLTAG)
									{
										printf("\n\t Spec-CATPart-CMI2AuxPart..Relation Already Exist...........\n\n" );fflush(stdout);
									}
									else
									{
										result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
										printf("\n\t Spec-CATPart-CMI2AuxPart..GRM_create_relation ----> %d",result);fflush(stdout);
										result = GRM_save_relation(relation);
										printf("\n\t Spec-CATPart-CMI2AuxPart..GRM_save_relation ----> %d\n",result);fflush(stdout);

										DatasetExistFlag = 1;
									}
								}
							}
						}
						else if((tc_strstr(JTid1,".CATPart")!=NULL) && (tc_strstr(JTid1,".cgr")!=NULL))
						{
							printf("\n\n\t **************cgr CMI2CacheCgr****************\n\t"); fflush(stdout);

							Flag_1=0;
							if (GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist)!=ITK_ok);
							printf("\n\t cgr-CATPart..Total n attches =%d\n",n_attchs); fflush(stdout);

							itemId12 = strtok(JTid1,".");
							strcpy(itemId123,itemId12);
							//strcat(itemId123,".cgr"); ////SOURAV KARAK - Impacts CATIA File - 27-Apr-2023
							printf("\t cgr-CATPart..Name is --->%s\n\t ",itemId123); fflush(stdout);

							for (i= 0; i < n_attchs; i++)
							{
								primary=rellist[i].secondary;
								//relationstr=rellist[i].the_relation;
								//relationstr=rellist[i].the_relation; //Sudhir Kumar Srivastava - 09-May-2023 Warning removed in these code ,,, so if you are using this API GRM_list_secondary_objects.. then u need to take care of these types of warning
								ITK_CALL(AOM_ask_name(rellist[i].relation_type,&relationstr)); //Sudhir Kumar Srivastava - 09-May-2023
								printf("\n relationstr:%s ..............",relationstr);fflush(stdout); //Sudhir Kumar Srivastava - 09-May-2023

								if (TCTYPE_ask_object_type(primary,&objTypeTag)!=ITK_ok);
								//printf("\n\t "); fflush(stdout);
								if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);

								//printf("\n\t cgr-CATPart..Type Name:%s ..............",type_name);fflush(stdout);

								if((strcmp(type_name,"ImanFile")==0) || (strcmp(type_name,"icm0")==0))
									continue;

								result = AE_find_datasettype("CMI2CacheCgr", &datasettype);
								//printf("\n\t cgr-CATPart..Type found---->%d",result);fflush(stdout);

								//printf("\n\t "); fflush(stdout);
								if (AOM_ask_value_string(primary,"object_name",&parent_name)!=ITK_ok);
								//printf("\n\t cgr-CATPart..parent_name:%s ..............",parent_name);fflush(stdout);

								//if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2CacheCgr") ==0) //Alokesh strcmp -> strcasecmp (Ignore Cases)
								if(strcasecmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2CacheCgr") ==0)
								{
									result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
									printf("\n\t cgr-CATPart..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
									if(ref_count_d>0)
									{
										Flag_1 = 1;
										printf("\n\t cgr-CATPart..Relationship already exist !!!!.......\n");fflush(stdout);

										DatasetRelFlag = 1;
										DatasetExistFlag = 1;

										break;
									}
									else
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t cgr-CATPart..Got reference list--->%d",result);fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t cgr-CATPart..File Imported--->%d",result);fflush(stdout);

										if (result == 41178)
										{
											ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
										}

										result = AOM_save(filetag);
										printf("\n\t cgr-CATPart..File saved--->%d",result);fflush(stdout);

										result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
										printf("\n\t cgr-CATPart..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

										AE_set_dataset_tool(primary,tool);
										printf("\n\t cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										//sPartNumberTokint = atoi(JTFileSeq);
										//printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
										//WSOM_set_revision(primary,sPartNumberTokint);

										printf("\n\t cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										result = AOM_save(primary);
										if(result == 0)
										{
											Flag_1 = 1;

											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
										}
									}
								}
							}
							if (Flag_1 == 0)
							{
								//ItemDesc =(char *) MEM_alloc(20);
								//strcpy(ItemDesc,"CMI2CacheCgr Document");

								result = AE_find_datasettype("CMI2CacheCgr", &datasettype);
								printf("\n\t cgr-CATPart..Type found---->%d",result);fflush(stdout);

								result = AE_create_dataset_with_id(datasettype,itemId123,ItemDesc, NULL, NULL, &Newdataset);
								printf("\n\t cgr-CATPart..Dataset created--->%s",itemId123);fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\n\t cgr-CATPart..Dataset format set--->%d",result);fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t cgr-CATPart..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t cgr-CATPart..Got reference list--->%d",result);fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t cgr-CATPart..File Imported--->%d",result);fflush(stdout);

									if (result == 41178)
									{
										ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t cgr-CATPart..File saved--->%d",result);fflush(stdout);

									if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
									result = AOM_save(filetag);
									printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

									result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
									printf("\n\t cgr-CATPart..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

									AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									printf("\n\t cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AOM_save(Newdataset);
								}

								result = GRM_find_relation_type("IMAN_specification", &relation_type);
								printf("\n\t cgr-CATPart..GRM_find_relation_type ---->%d",result);fflush(stdout);
								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t cgr-CATPart..Fndrelation ---->%d",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									printf("\n\t cgr-CATPart..Relation Already Exist...........\n\n" );fflush(stdout);
								}
								else
								{
									result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
									printf("\n\t cgr-CATPart..GRM_create_relation ---->%d",result);fflush(stdout);
									result = GRM_save_relation(relation);
									printf("\n\t cgr-CATPart..GRM_save_relation ---->%d\n",result);fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
						else if((tc_strstr(JTid1,".CATPart")!=NULL) && (tc_strstr(JTid1,"_swp")!=NULL))
						{
							printf("\n\n\t **************swp CATPart CMI2AuxPart****************\n\t"); fflush(stdout);

							Flag_1=0;
							if (GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist)!=ITK_ok);
							printf("\n\t swp-CATPart-CMI2AuxPart..Total n attches =%d\n",n_attchs);

							itemId12 = strtok(JTid1,".");
							strcpy(itemId123,itemId12);
							printf("\t swp-CATPart-CMI2AuxPart..Name is --->%s\n\t ",itemId123);

							for (i= 0; i < n_attchs; i++)
							{
								primary=rellist[i].secondary;
								//relationstr=rellist[i].the_relation;
								//relationstr=rellist[i].the_relation; //Sudhir Kumar Srivastava - 09-May-2023 Warning removed in these code ,,, so if you are using this API GRM_list_secondary_objects.. then u need to take care of these types of warning
								ITK_CALL(AOM_ask_name(rellist[i].relation_type,&relationstr)); //Sudhir Kumar Srivastava - 09-May-2023
								printf("\n relationstr:%s ..............",relationstr);fflush(stdout); //Sudhir Kumar Srivastava - 09-May-2023

								if (TCTYPE_ask_object_type(primary,&objTypeTag)!=ITK_ok);
								//printf("\n\t "); fflush(stdout);
								if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);

								//printf("\n\t swp-CATPart-CMI2AuxPart..Type Name:%s ..............",type_name);fflush(stdout);

								if((strcmp(type_name,"ImanFile")==0) || (strcmp(type_name,"icm0")==0))
									continue;

								result = AE_find_datasettype("CMI2AuxPart", &datasettype);
								//printf("\n\t swp-CATPart-CMI2AuxPart..Type found---->%d",result);fflush(stdout);

								//printf("\n\t "); fflush(stdout);
								if (AOM_ask_value_string(primary,"object_name",&parent_name)!=ITK_ok);
								//printf("\n\t swp-CATPart-CMI2AuxPart..parent_name:%s ..............",parent_name);fflush(stdout);

								//if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2AuxPart") ==0) //Alokesh strcmp -> strcasecmp (Ignore Cases)
								if(strcasecmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2AuxPart") ==0)
								{
									result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
									printf("\n\t swp-CATPart-CMI2AuxPart..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
									if(ref_count_d>0)
									{
										Flag_1 = 1;
										printf("\n\t swp-CATPart-CMI2AuxPart..Relationship already exist !!!!.......\n");fflush(stdout);

										DatasetRelFlag = 1;
										DatasetExistFlag = 1;

										break;
									}
									else
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t swp-CATPart-CMI2AuxPart..Got reference list--->%d",result);fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t swp-CATPart-CMI2AuxPart..File Imported--->%d",result);fflush(stdout);

										if (result == 41178)
										{
											ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
										}

										result = AOM_save(filetag);
										printf("\n\t swp-CATPart-CMI2AuxPart..File saved--->%d",result);fflush(stdout);

										result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
										printf("\n\t swp-CATPart-CMI2AuxPart..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

										AE_set_dataset_tool(primary,tool);
										printf("\n\t swp-CATPart-CMI2AuxPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										//sPartNumberTokint = atoi(JTFileSeq);
										//printf("\n swp-cgr-Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
										//WSOM_set_revision(primary,sPartNumberTokint);

										printf("\n\t swp-CATPart-CMI2AuxPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										result = AOM_save(primary);
										if(result == 0)
										{
											Flag_1 = 1;

											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
										}
									}
								}
							}
							if (Flag_1 == 0)
							{
								//ItemDesc =(char *) MEM_alloc(20);
								//strcpy(ItemDesc,"swp CMI2AuxPart Document");

								result = AE_find_datasettype("CMI2AuxPart", &datasettype);
								printf("\n\t swp-CATPart-CMI2AuxPart..Type found---->%d",result);fflush(stdout);

								result = AE_create_dataset_with_id(datasettype,itemId123,ItemDesc, NULL, NULL, &Newdataset);
								printf("\n\t swp-CATPart-CMI2AuxPart..Dataset created--->%s",itemId123);fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\n\t swp-CATPart-CMI2AuxPart..Dataset format set--->%d",result);fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t swp-CATPart-CMI2AuxPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t swp-CATPart-CMI2AuxPart..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t swp-CATPart-CMI2AuxPart..Got reference list--->%d",result);fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t swp-CATPart-CMI2AuxPart..File Imported--->%d",result);fflush(stdout);

									if (result == 41178)
									{
										ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t swp-CATPart-CMI2AuxPart..File saved--->%d",result);fflush(stdout);

									if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
									result = AOM_save(filetag);
									printf("\n\t swp-cgr-File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

									result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
									printf("\n\t swp-CATPart-CMI2AuxPart..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

									AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t swp-CATPart-CMI2AuxPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									printf("\n\t swp-CATPart-CMI2AuxPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AOM_save(Newdataset);
								}

								printf("\n\t swp-CATPart-CMI2AuxPart..GRM_find_relation_type ---->%d",result);fflush(stdout);

								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t swp-CATPart-CMI2AuxPart..Fndrelation ---->%d",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									printf("\n\t swp-CATPart-CMI2AuxPart..Relation Already Exist...........\n\n" );fflush(stdout);
								}
								else
								{
									result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
									printf("\n\t swp-CATPart-CMI2AuxPart..GRM_create_relation ---->%d",result);fflush(stdout);
									result = GRM_save_relation(relation);
									printf("\n\t swp-CATPart-CMI2AuxPart..GRM_save_relation ---->%d\n",result);fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
						else //For NON Spec files
						{
							printf("\n\n\t ************** NON Spec/cgr/swp CATPart ****************\n\t"); fflush(stdout);

							if( (strlen(ApplnOwner) > 3) /* && (strcmp(ApplnOwner,"-")!=0) && (strcmp(ApplnOwner," ")!=0) */)
							{
								ApplnOwnerFlag = 1;

								if (tc_strstr(ApplnOwner,"Proe")!=NULL)
								{
									strcpy(ApplnOwnerStr,"ProEPart");
									ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
								}
								else if (tc_strstr(ApplnOwner,"Catia")!=NULL)
								{
									strcpy(ApplnOwnerStr,"Cat-Part");
									ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
								}
								else
								{
									strcpy(ApplnOwnerStr,"");

									printf("\n\t CATPart..ApplnOwner string is not Valid to Set ---->%s,%s , %s",itemId,itemRevSeq,JTid1); fflush(stdout);
								}
							}

							if ( AOM_ask_value_string(item_tag,"t5_PartType",&partType)!=ITK_ok);

							/*
							SOURAV KARAK - It impacts CATIA File - 27-Apr-2023
							if (tc_strcmp(partType,"C") != 0)
							//if (strcmp(partType,"C") == 0 )
							//{
							//	printf("\n %s has Part Type to component[%s]\n",itemId,partType); fflush(stdout);
							//}
							//else
							{
								printf("\n\t %s Stamping the Part Type to component[C] before was [%s]\n\t",itemId,partType); fflush(stdout);

								if (AOM_lock(item_tag)!=ITK_ok);
								//printf("\n\t "); fflush(stdout);
								if  ( AOM_set_value_string(item_tag,"t5_PartType","C")!=ITK_ok);
								//printf("\n\t "); fflush(stdout);
								if (AOM_save(item_tag)!=ITK_ok);
								//printf("\n\t "); fflush(stdout);
								if (AOM_unlock(item_tag)!=ITK_ok);
							}
							else
							{
								printf("\n\t"); fflush(stdout);
							}*/

							Flag_1=0;
							if (GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist)!=ITK_ok);
							printf("\n\t CATPart..Total n attches =%d\n",n_attchs); fflush(stdout);

							itemId12 = strtok(JTid1,".");
							strcpy(itemId123,itemId12);
							printf("\t CATPart..Name is --->%s\n\t ",itemId123);

							for (i= 0; i < n_attchs; i++)
							{
								primary=rellist[i].secondary;
								//relationstr=rellist[i].the_relation;
								//relationstr=rellist[i].the_relation; //Sudhir Kumar Srivastava - 09-May-2023 Warning removed in these code ,,, so if you are using this API GRM_list_secondary_objects.. then u need to take care of these types of warning
								ITK_CALL(AOM_ask_name(rellist[i].relation_type,&relationstr)); //Sudhir Kumar Srivastava - 09-May-2023
								printf("\n relationstr:%s ..............",relationstr);fflush(stdout); //Sudhir Kumar Srivastava - 09-May-2023

								if (TCTYPE_ask_object_type(primary,&objTypeTag)!=ITK_ok);
								//printf("\n\t "); fflush(stdout);
								if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);

								//printf("\n\t CATPart..Type Name:%s ..............",type_name);fflush(stdout);

								if((strcmp(type_name,"ImanFile")==0) || (strcmp(type_name,"icm0")==0))
									continue;

								result = AE_find_datasettype("CMI2Part", &datasettype);
								//printf("\n\t CATPart..Type found---->%d",result);fflush(stdout);

								//printf("\n\t "); fflush(stdout);
								if (AOM_ask_value_string(primary,"object_name",&parent_name)!=ITK_ok);
								//printf("\n\t CATPart..parent_name:%s ..............",parent_name);fflush(stdout);

								//if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2Part") ==0) //Alokesh strcmp -> strcasecmp (Ignore Cases)
								if(strcasecmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2Part") ==0)
								{
									result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
									printf("\n\t CATPart..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
									if(ref_count_d>0)
									{
										Flag_1 = 1;
										printf("\n\t CATPart..Relationship already exist !!!!.......\n");fflush(stdout);

										DatasetRelFlag = 1;
										DatasetExistFlag = 1;

										break;
									}
									else
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t CATPart..Got reference list--->%d",result);fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t CATPart..File Imported--->%d",result);fflush(stdout);

										if (result == 41178)
										{
											if (IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
										}

										result = AOM_save(filetag);
										printf("\n\t CATPart..File saved--->%d",result);fflush(stdout);

										result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
										printf("\n\t CATPart..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

										AE_set_dataset_tool(primary,tool);
										printf("\n\t CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										//sPartNumberTokint = atoi(JTFileSeq);
										//printf("\n cgr-Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
										//WSOM_set_revision(primary,sPartNumberTokint);

										printf("\n\t CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										result = AOM_save(primary);
										if(result == 0)
										{
											Flag_1 = 1;

											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
										}
									}
								}
							}
							if (Flag_1 == 0)
							{
								//ItemDesc =(char *) MEM_alloc(20);
								//strcpy(ItemDesc,"CMI2Part Document");

								result = AE_find_datasettype("CMI2Part", &datasettype);
								printf("\n\t CATPart..Type found---->%d",result);fflush(stdout);

								result = AE_create_dataset_with_id(datasettype,itemId123,ItemDesc, NULL, NULL, &Newdataset);
								printf("\n\t CATPart..Dataset created--->%s",itemId123);fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\n\t CATPart..Dataset format set--->%d",result);fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t CATPart..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t CATPart..Got reference list--->%d",result);fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t CATPart..File Imported--->%d",result);fflush(stdout);

									if (result == 41178)
									{
										if (IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t CATPart..File saved--->%d",result);fflush(stdout);

									if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
									result = AOM_save(filetag);
									printf("\n\t cgr-File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

									result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
									printf("\n\t CATPart..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

									AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									printf("\n\t CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AOM_save(Newdataset);
								}

								printf("\n\t CATPart..GRM_find_relation_type ---->%d",result);fflush(stdout);

								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t CATPart..Fndrelation ---->%d",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									printf("\n\t CATPart..Relation Already Exist...........\n\n" );fflush(stdout);
								}
								else
								{
									result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
									printf("\n\t CATPart..GRM_create_relation ---->%d",result);fflush(stdout);
									result = GRM_save_relation(relation);
									printf("\n\t CATPart..GRM_save_relation ---->%d\n",result);fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
					}
					else if(tc_strstr(JTid1,".CATProduct")!=NULL)
					{
						printf("\n\n\t ************** CATProduct ****************\n\t"); fflush(stdout);

						if( (strlen(ApplnOwner) > 3) /* && (strcmp(ApplnOwner,"-")!=0) && (strcmp(ApplnOwner," ")!=0) */)
						{
							ApplnOwnerFlag = 1;

							if (tc_strstr(ApplnOwner,"Proe")!=NULL)
							{
								strcpy(ApplnOwnerStr,"ProEAsm");
								ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
							}
							else if (tc_strstr(ApplnOwner,"Catia")!=NULL)
							{
								strcpy(ApplnOwnerStr,"Cat-Product");
								ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
							}
							else
							{
								strcpy(ApplnOwnerStr,"");

								printf("\n\t CATPart..ApplnOwner string is not Valid to Set ---->%s,%s , %s",itemId,itemRevSeq,JTid1); fflush(stdout);
							}
						}

						Flag_1=0;
						if (GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist)!=ITK_ok);
						printf("\n\t CATProduct..Total n attches =%d\n",n_attchs);

						itemId12 = strtok(JTid1,".");
						strcpy(itemId123,itemId12);
						printf("\t CATProduct..Name is --->%s\n\t ",itemId123);

						for (i= 0; i < n_attchs; i++)
						{
							primary=rellist[i].secondary;
							//relationstr=rellist[i].the_relation;
							//relationstr=rellist[i].the_relation; //Sudhir Kumar Srivastava - 09-May-2023 Warning removed in these code ,,, so if you are using this API GRM_list_secondary_objects.. then u need to take care of these types of warning
								ITK_CALL(AOM_ask_name(rellist[i].relation_type,&relationstr)); //Sudhir Kumar Srivastava - 09-May-2023
								printf("\n relationstr:%s ..............",relationstr);fflush(stdout); //Sudhir Kumar Srivastava - 09-May-2023

							if (TCTYPE_ask_object_type(primary,&objTypeTag)!=ITK_ok);
							//printf("\n\t "); fflush(stdout);
							if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);

							//printf("\n\t CATProduct..Type Name:%s ..............",type_name);fflush(stdout);

							if((strcmp(type_name,"ImanFile")==0) || (strcmp(type_name,"icm0")==0))
								continue;

							result = AE_find_datasettype("CMI2Product", &datasettype);
							//printf("\n\t CATProduct..Type found---->%d",result);fflush(stdout);

							//printf("\n\t "); fflush(stdout);
							if (AOM_ask_value_string(primary,"object_name",&parent_name)!=ITK_ok);
							//printf("\n\t CATProduct..parent_name:%s ..............",parent_name);fflush(stdout);

							//if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2Product") ==0) //Alokesh strcmp -> strcasecmp (Ignore Cases)
							if(strcasecmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2Product") ==0)
							{
								result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
								printf("\n\t CATProduct..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
								if(ref_count_d>0)
								{
									Flag_1 = 1;
									printf("\n\t CATProduct..Relationship already exist !!!!.......\n");fflush(stdout);

									DatasetRelFlag = 1;
									DatasetExistFlag = 1;

									break;
								}
								else
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t CATProduct..Got reference list--->%d",result);fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t CATProduct..File Imported--->%d",result);fflush(stdout);

									if (result == 41178)
									{
										ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t CATProduct..File saved--->%d",result);fflush(stdout);

									result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
									printf("\n\t CATProduct..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

									AE_set_dataset_tool(primary,tool);
									printf("\n\t CATProduct..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									//sPartNumberTokint = atoi(JTFileSeq);
									//printf("\n cgr-Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
									//WSOM_set_revision(primary,sPartNumberTokint);

									printf("\n\t CATProduct..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AOM_save(primary);
									if(result == 0)
									{
										Flag_1 = 1;

										DatasetRelFlag = 1;
										DatasetExistFlag = 1;
									}
								}
							}
						}
						if (Flag_1 == 0)
						{
							//ItemDesc =(char *) MEM_alloc(20);
							//strcpy(ItemDesc,"CMI2Product Document");

							result = AE_find_datasettype("CMI2Product", &datasettype);
							printf("\n\t CATProduct..Type found---->%d",result);fflush(stdout);

							result = AE_create_dataset_with_id(datasettype,itemId123,ItemDesc, NULL, NULL, &Newdataset);
							printf("\n\t CATProduct..Dataset created--->%s",itemId123);fflush(stdout);

							result = AE_set_dataset_format(Newdataset, "BINARY_REF");
							printf("\n\t CATProduct..Dataset format set--->%d",result);fflush(stdout);

							result = AE_set_dataset_tool(Newdataset,tool);
							printf("\n\t CATProduct..Tool set--->%d",result);fflush(stdout);fflush(stdout);

							result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
							printf("\n\t CATProduct..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

							if (nameRef_cnt == 0)
							{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\n\t CATProduct..Got reference list--->%d",result);fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\n\t CATProduct..File Imported--->%d",result);fflush(stdout);

								result = AOM_save(filetag);
								printf("\n\t CATProduct..File saved--->%d",result);fflush(stdout);

								if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
								result = AOM_save(filetag);
								printf("\n\t cgr-File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\n\t CATProduct..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t CATProduct..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								printf("\n\t CATProduct..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AOM_save(Newdataset);
							}

							printf("\n\t CATProduct..GRM_find_relation_type ---->%d",result);fflush(stdout);

							result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
							printf("\n\t CATProduct..Fndrelation ---->%d",result); fflush(stdout);

							if(Fndrelation != NULLTAG)
							{
								printf("\n\t CATProduct..Relation Already Exist...........\n\n" );fflush(stdout);
							}
							else
							{
								result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
								printf("\n\t CATProduct..GRM_create_relation ---->%d",result);fflush(stdout);
								result = GRM_save_relation(relation);
								printf("\n\t CATProduct..GRM_save_relation ---->%d\n",result);fflush(stdout);

								DatasetExistFlag = 1;
							}
						}
					}
					else if(tc_strstr(JTid1,".CATDrawing")!=NULL)
					{
						printf("\n\t************** CATDrawing ****************\n\n\t"); fflush(stdout);

						//ItemDesc =(char *) MEM_alloc(20);
						//strcpy(ItemDesc,"CATDrawing Document");

						//result = GRM_find_relation_type("IMAN_specification", &relation_type);
						//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

						if (strcmp(itemId,DataSetNm3)==0)	//self-drawing
						{
							result = GRM_find_relation_type("IMAN_specification", &relation_type);
						}
						else	//Reference-drawing
						{
							//result = GRM_find_relation_type("IMAN_reference", &relation_type);  //Ujjawal Kumar on 17.0.2022 (For Reference Drg)
							result = GRM_find_relation_type("IMAN_specification", &relation_type);
						}
						printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);


						if(QRY_find("Dataset Name", &queryTag_d));
						printf("  After IFERR_REPORT : QRY_find ....");fflush(stdout);
						if (queryTag_d)
						{
							printf("  Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						else
						{
							printf("  Not Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						qry_values_d[0] = DataSetNm3 ;

						if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
						printf("  CATDrawing..resultCount_d:[%d] \n\t",resultCount_d);fflush(stdout);

						if(resultCount_d > 0)
						{
							DatasetFlag = 0;
							for (j=0;j<resultCount_d;j++ )
							{
								itemRevDataSet_tag = revtag_d[j];

								if(TCTYPE_ask_object_type(itemRevDataSet_tag,&datasetTag));
								if(TCTYPE_ask_name(datasetTag,type_name3));
								printf("    CATDrawing..Part type_name3 :%s \n\t",type_name3); fflush(stdout);

								if (strcmp(type_name3,"CMI2Drawing")==0)
								{
									result = AE_ask_dataset (itemRevDataSet_tag,&item_tag_data_rev);

									printf("\n\t CATDrawing..AE_ask_dataset--->%d",result);fflush(stdout);

									result = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
									printf("\n\t CATDrawing..ref_count_d Count--->%d \n\t ",ref_count_d);fflush(stdout);

									if(ref_count_d>0)
									{
										RefObject_d = namRefObject_d[0];

										if (AOM_ask_value_string(RefObject_d,"object_string",&named_ref)!=ITK_ok);
										printf("\n\t CATDrawing..item_tag named_ref:[%s]  JTid1:[%s]",named_ref,JTid1);

										//if (strcmp(named_ref,JTid1)==0)
										if ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0) )		//Condition Changed on 05.04.2017
										{
											DatasetFlag = 1;
											printf("...already present and match found\n");
											break;
										}
										else
										{
											printf("...match not found hence continuing..\n");
											DatasetFlag = 0;
										}
									}
								}
							}
							printf("\n\t DatasetFlag:%d ",DatasetFlag);

							if(DatasetFlag == 1)
							{
								if(relation_type)
								{
									//printf("\n\t "); fflush(stdout);
									if (TCTYPE_ask_name(relation_type,type_name)!=ITK_ok);
									printf("\n\t Type Name:%s ..............",type_name);fflush(stdout);
								}

								result = GRM_find_relation( item_tag, item_tag_data_rev, relation_type ,&Fndrelation);
								printf("\n\t 1.CATDrawing..Fndrelation ---->%d \n\t",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									DatasetRelFlag = 0;

									if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
									printf("  1.item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

									if(n_attchs>0)
									{
										for (i=0; i < n_attchs; i++)
										{
											if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
											if(TCTYPE_ask_name(secObjTypeTag,type_name2));
											printf("    1.CATDrawing..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

											if (strcmp(type_name2,"CMI2Drawing")==0)
											{
												printf("  1.CATDrawing..Dataset is already attached to Revision \n\t"); fflush(stdout);

												printf("\n\t 1.CATDrawing..Relation Already Exist...........\n\n\t" );fflush(stdout);
												DatasetRelFlag = 1;
												DatasetExistFlag = 1;
												break;
											}
										}
									}
								}
								else
								{
									DatasetRelFlag = 0;
								}

								if (DatasetRelFlag == 0)
								{
									if (GRM_create_relation(item_tag, item_tag_data_rev, relation_type, NULL, &relation)!=ITK_ok);
									printf("\n\t 1.CATDrawing..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
									if (AOM_refresh (item_tag,0)!=ITK_ok);
									if (AOM_refresh(relation,0)!=ITK_ok);
									result = GRM_save_relation(relation);
									printf("\t 1.CATDrawing..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
						else  //New create Drawing CATDrawing dataset
						{
							DatasetFlag = 0;
						}

						if(DatasetFlag == 0)
						{
							result = AE_find_datasettype("CMI2Drawing", &datasettype);
							printf("\n\t Type found---->%d",result);fflush(stdout);

							//result = AE_find_dataset(DataSetNm3, &Newdataset);
							//if(Newdataset)
							//{
							//	printf("\n\t Dataset Found..."); fflush(stdout);
							//}
							//else
							//{
								printf("\n\t Creating New Dataset..."); fflush(stdout);
								result = AE_create_dataset_with_id(datasettype,DataSetNm3,ItemDesc, NULL, NULL, &Newdataset);  //DataSetNm3
								printf("\n\t Dataset created for CATDrawing --->%s",DataSetNm3); fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\n\t Dataset format set--->%d",result); fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t Tool set--->%d",result); fflush(stdout);
							//}

							result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
							printf("\n\t ****CATDrawing..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

							if (nameRef_cnt == 0)
							{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\n\t Got reference list--->%d",result); fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\n\t File Imported--->%d",result); fflush(stdout);

								result = AOM_save(filetag);
								printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

								if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
								result = AOM_save(filetag);
								printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);


								if(Newdataset)
								{
									result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
									printf("\n\t AE_add_dataset_named_ref--->%d\n\n",result); fflush(stdout);

									//AE_set_dataset_tool(Newdataset,tool);
									//printf("\n\t Tool set--->%d",result); fflush(stdout);

									result = AOM_save(Newdataset);
									printf("\n\t AOM_save--->%d",result); fflush(stdout);
								}
								else
								{
									printf("\n\t ??? Unable to create DATASET for --->%s",DataSetNm3); fflush(stdout);

									//break;
								}
							}

							//if (AOM_ask_value_string(Newdataset,"object_string",&object_string)!=ITK_ok);
							//printf("\n object_string iss :[%s]\n",object_string);

							//result = GRM_find_relation_type("IMAN_specification", &relation_type);
							//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

							if(relation_type)
							{
								//printf("\n\t "); fflush(stdout);
								if (TCTYPE_ask_name(relation_type,type_name)!=ITK_ok);
								printf("\n\t Type Name:%s ..............",type_name);fflush(stdout);
							}

							result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
							printf("\n\t 2.CATDrawing..Fndrelation ---->%d \n\t",result); fflush(stdout);

							if(Fndrelation != NULLTAG)
							{
								DatasetRelFlag = 0;

								if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
								printf("  2.item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

								if(n_attchs>0)
								{
									for (i=0; i < n_attchs; i++)
									{
										if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
										if(TCTYPE_ask_name(secObjTypeTag,type_name2));
										printf("    2.CATDrawing..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

										if (strcmp(type_name2,"CMI2Drawing")==0)
										{
											printf("  2.CATDrawing..Dataset is already attached to Revision \n\t"); fflush(stdout);

											printf("\n\t 2.CATDrawing..Relation Already Exist...........\n\n\t" );fflush(stdout);
											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
											break;
										}
									}
								}
							}
							else
							{
								DatasetRelFlag = 0;
							}

							if (DatasetRelFlag == 0)
							{
								if (GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation)!=ITK_ok);
								printf("\n\t 2.CATDrawing..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
								if (AOM_refresh (item_tag,0)!=ITK_ok);
								if (AOM_refresh(relation,0)!=ITK_ok);
								result = GRM_save_relation(relation);
								printf("\t 2.CATDrawing..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

								DatasetExistFlag = 1;
							}
						}
					}
					else if(tc_strstr(JTid1,".csv")!=NULL)
					{
						Flag_1=0;

						result = GRM_find_relation_type("IMAN_specification", &relation_type);
						printf("\n csv..GRM_find_relation_type ---->%d",result);fflush(stdout);


						//ItemDesc =(char *) MEM_alloc(20);
						//strcpy(ItemDesc,"csv Ecxel Document");

						if (GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist)!=ITK_ok);
						printf("\n\t csv..Total n attches =%d\n",n_attchs);

						itemId12 = strtok(JTid1,".");  //1
						printf("  Name is --->%s \n\t ",itemId12);

						for (i= 0; i < n_attchs; i++)
						{
							//printf("\n Inside loop ..............");fflush(stdout);
							//primary=secondary_objects[i];

							primary=rellist[i].secondary;
							//relationstr=rellist[i].the_relation;
							//relationstr=rellist[i].the_relation; //Sudhir Kumar Srivastava - 09-May-2023 Warning removed in these code ,,, so if you are using this API GRM_list_secondary_objects.. then u need to take care of these types of warning
								ITK_CALL(AOM_ask_name(rellist[i].relation_type,&relationstr)); //Sudhir Kumar Srivastava - 09-May-2023
								printf("\n relationstr:%s ..............",relationstr);fflush(stdout); //Sudhir Kumar Srivastava - 09-May-2023

							if (TCTYPE_ask_object_type(primary,&objTypeTag)!=ITK_ok);
							if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);

							printf("\n csv..Type Name:%s ..............",type_name);fflush(stdout);

							if((strcmp(type_name,"ImanFile")==0) || (strcmp(type_name,"icm0")==0))
								continue;

							result = AE_find_datasettype("MSExcel", &datasettype);
							printf("\n\t csv..Type found---->%d",result);fflush(stdout);

							//printf("\n\t "); fflush(stdout);
							if (AOM_ask_value_string(primary,"object_name",&parent_name)!=ITK_ok);
							printf("\n\t csv..parent_name:%s ..............",parent_name);fflush(stdout);

							if(strcmp(parent_name,itemId12)==0 &&  strcmp(type_name,"MSExcel") ==0)
							{
								result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
								printf("\n\t ****csv..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
								if(ref_count_d>0)
								{
									Flag_1 = 1;
									printf("\n\t csv..Relationship already exist !!!!.......");fflush(stdout);
									break;
								}
								else
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t csv..Got reference list--->%d",result);fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t csv..File Imported--->%d",result);fflush(stdout);

									result = AOM_save(filetag);
									printf("\n\t csv..File saved--->%d \n\t ",result);fflush(stdout);

									if (IMF_set_original_file_name(filetag,itemId12)!=ITK_ok);
									result = AOM_save(filetag);
									printf("\n\t File saved--->%d  [%s]",result,itemId12); fflush(stdout);

									result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
									printf("\n\t csv..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

									AE_set_dataset_tool(primary,tool);
									printf("\n\t csv..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									//sPartNumberTokint = atoi(JTFileSeq);
									//printf("\n\t csv..Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
									//WSOM_set_revision(primary,sPartNumberTokint);

									printf("\n\t csv..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AOM_save(primary);
									if(result == 0)
									Flag_1 = 1;
								}
							}
						}

						if (Flag_1 == 0)
						{
							printf("\n\t csv..itemId12 found---->%s",itemId12);fflush(stdout);
							result = AE_find_datasettype("MSExcel", &datasettype);
							printf("\n\t csv..Type found---->%d",result);fflush(stdout);

							result = AE_create_dataset_with_id(datasettype,itemId12,ItemDesc, NULL, NULL, &Newdataset);
							printf("\n\t csv..Dataset Created---->%d",result);fflush(stdout);

							result = AE_set_dataset_format(Newdataset, "BINARY_REF");
							printf("\n\t csv..Dataset format set--->%d",result);fflush(stdout);

							result = AE_set_dataset_tool(Newdataset,tool);
							printf("\n\t csv..Tool set--->%d",result);fflush(stdout);fflush(stdout);

							result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
							printf("\n\t ****csv..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

							if (nameRef_cnt == 0)
							{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\n\t csv..Got reference list--->%d",result);fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\n\t csv..File Imported--->%d",result);fflush(stdout);

								result = AOM_save(filetag);
								printf("\n\t csv..File saved--->%d \n\t ",result);fflush(stdout);

								if (IMF_set_original_file_name(filetag,itemId12)!=ITK_ok);
								result = AOM_save(filetag);
								printf("\n\t File saved--->%d  [%s]",result,itemId12); fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\n\t csv..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t csv..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								//sPartNumberTokint = atoi(JTFileSeq);
								//printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
								//WSOM_set_revision(Newdataset,sPartNumberTokint);

								printf("\n\t csv..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AOM_save(Newdataset);
							}

							result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
							printf("\n\t csv..Fndrelation ---->%d",result); fflush(stdout);

							if(Fndrelation)
							{
								printf("\n\t csv..Relation Already Exist...........\n\n" );fflush(stdout);
							}
							else
							{
								result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
								printf("\n\t csv..GRM_create_relation ---->%d",result);fflush(stdout);
								result = GRM_save_relation(relation);
								printf("\n\t csv..GRM_save_relation ---->%d",result);fflush(stdout);
							}
						}
					}
					else
					{
						Flag_1=0;

						printf("\n\t******* Generic/Instance *********"); fflush(stdout);
						printf("\n\t SubTypeNm:[%s]",SubTypeNm);fflush(stdout);

						result = GRM_find_relation_type("IMAN_specification", &relation_type);
						printf("\n\t Generic/Instance..GRM_find_relation_type ---->%d",result); fflush(stdout);

						if( (strcmp(SubTypeNm,"Generic")==0) ||  (strcmp(SubTypeNm,"Instance")==0) )
						{
							if (tc_strstr(ClassName,"ProAsm")!=NULL)
							{
								strcpy(ClassNmGI,"ProAsm");
								ClassNmGI[strlen(ClassNmGI)] = '\0';
							}
							else if (tc_strstr(ClassName,"ProPrt")!=NULL)
							{
								strcpy(ClassNmGI,"ProPrt");
								ClassNmGI[strlen(ClassNmGI)] = '\0';
							}

							if (strcmp(ClassNmGI,"")==0)
							{
								printf("\n\t Generic/Instance..ClassNmGI [%s] is NULL hence do not creating dataset.....????",ClassNmGI); fflush(stdout);
								continue;
							}

							ApplnOwnerFlag = 1;

							if ( (tc_strstr(ApplnOwner,"Proe")!=NULL) || (strcmp(ApplnOwner,"-")==0) && (strcmp(ApplnOwner,"")==0))
							{
								if (tc_strstr(ClassName,"ProAsm")!=NULL)
								{
									strcpy(ApplnOwnerStr,"ProEAsm");
									ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
								}
								else if (tc_strstr(ClassName,"ProPrt")!=NULL)
								{
									strcpy(ApplnOwnerStr,"ProEPart");
									ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
								}
								else
								{
									strcpy(ApplnOwnerStr,"");

									printf("\n\t 2..Generic/Instance..ApplnOwner string is not Valid to Set ---->%s,%s , %s",itemId,itemRevSeq,JTid1); fflush(stdout);
								}
							}
							else if (tc_strstr(ApplnOwner,"Catia")!=NULL)
							{
								strcpy(ApplnOwnerStr,"Cat-Part");
								ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
							}
							else
							{
								strcpy(ApplnOwnerStr,"");

								printf("\n\t Generic/Instance..ApplnOwner string is not Valid to Set ---->%s,%s , %s",itemId,itemRevSeq,JTid1); fflush(stdout);
							}

							if(relation_type)
							{
								//printf("\n\t "); fflush(stdout);
								if(TCTYPE_ask_name(relation_type,type_name)!=ITK_ok);
								printf("\t Generic/Instance..Relation Type Name:%s ..............",type_name);fflush(stdout);
							}

							result = GRM_find_relation_type("IMAN_specification", &relation_type);
							printf("\n\t Generic/Instance..GRM_find_relation_type ---->%d \n\t",result);fflush(stdout);

							if (GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist)!=ITK_ok);
							printf("\n\t Generic/Instance..Total n attches= %d ",n_attchs);

							itemId12 = strtok(JTid1,".");  //1
							printf("\n\t Name is --->%s \n\t ",itemId12); fflush(stdout);

							for (i= 0; i < n_attchs; i++)
							{
								primary=rellist[i].secondary;
								//relationstr=rellist[i].the_relation;
								//relationstr=rellist[i].the_relation; //Sudhir Kumar Srivastava - 09-May-2023 Warning removed in these code ,,, so if you are using this API GRM_list_secondary_objects.. then u need to take care of these types of warning
								ITK_CALL(AOM_ask_name(rellist[i].relation_type,&relationstr)); //Sudhir Kumar Srivastava - 09-May-2023
								printf("\n relationstr:%s ..............",relationstr);fflush(stdout); //Sudhir Kumar Srivastava - 09-May-2023

								if(TCTYPE_ask_object_type(primary,&objTypeTag)!=ITK_ok);
								//printf("\n\t "); fflush(stdout);
								if(TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);


								if((strcmp(type_name,"ImanFile")==0) || (strcmp(type_name,"icm0")==0))
									continue;

								//printf("\n Generic/Instance..Type Name:%s ..............",type_name);fflush(stdout);

								result = AE_find_datasettype(ClassNmGI, &datasettype);
								printf("\n\t Generic/Instance..Type found---->%d",result);fflush(stdout);

								//printf("\n\t "); fflush(stdout);
								if(AOM_ask_value_string(primary,"object_name",&parent_name)!=ITK_ok);

								for (m = 0; parent_name[m]!='\0'; m++)
								{
									//printf("\n\t B.parent_name[m] : %c ",parent_name[m]); fflush(stdout);
									if (!isdigit(parent_name[m]))
									{
										if(parent_name[m] >= 'A' && parent_name[m] <= 'Z') {
											parent_name[m] = parent_name[m] + 32;	//convert string to lower-case
										}
									}
								}

								printf("\n\t Generic/Instance..Primary-parent_name: [%s] [%s]  type_name: [%s] =[%s].....",parent_name,itemId12,type_name,ClassNmGI);fflush(stdout);

								if(strcmp(parent_name,itemId12)==0 &&  strcmp(type_name,ClassNmGI) ==0)
								{
									if(strcmp(SubTypeNm,"Instance")==0)
									{
										Flag_1 = 1;
										printf("\n\t Instance..Relationship already exist !!!!.......");fflush(stdout);
										break;
									}
									else if(strcmp(SubTypeNm,"Generic")==0)
									{
										result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
										printf("\n\t ****Generic..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
										if(ref_count_d>0)
										{
											Flag_1 = 1;
											DatasetRelFlag = 1;
											DatasetExistFlag = 1;

											printf("\n\t Generic..Relationship already exist !!!!.......");fflush(stdout);

											//ITK_CALL(AE_ask_dataset_named_refs(secObj[revloop],&refnum,&namedRef_tag));

											//printf(" \n\t refnum: %d \n\t",refnum);fflush(stdout);
											//if(refnum > 0)
											//{
												//ITK_CALL(AE_find_datasettype("ProPrt", &datasettype));
												//ifail = AE_find_dataset_named_ref2(dataset2,k,&refname2,&reftype2,&refobject2);

												result = AE_find_dataset_named_ref2(primary,0,&refname2,&reftype2,&refobject2);
												printf("\n\t Generic..AE_find_dataset_named_ref2--->%d",result);fflush(stdout);
		
												result =  IMF_ask_original_file_name(refobject2,orig_name2);
												result =  AOM_ask_value_string(primary,"object_type",&object_type2);
												
												printf ("\nobject_type2 %s \n",object_type2);fflush(stdout);
												printf ("\norig_name2 %s \n",orig_name2);fflush(stdout);
												printf ("\nrefname2 %s \n",refname2);fflush(stdout);

												result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
												printf("\n\t Generic..Got reference list--->%d %s",result,ref_list[0]);fflush(stdout);

												result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
												printf("\n\t Generic..File Imported--->%d",result);fflush(stdout);

												result = AOM_save(filetag);
												printf("\n\t Generic..File saved--->%d \n\t ",result);fflush(stdout);

												if (IMF_set_original_file_name(filetag,DataSetNm2)!=ITK_ok);
												result = AOM_save(filetag);
												printf("\n\t File saved--->%d  [%s]",result,DataSetNm2); fflush(stdout);

												result = AOM_lock(primary);
												printf("\n\t AOM_lock --->%d \n\t ",result);fflush(stdout);

												printf("\n\t Ujjawal Kumar JUST BEFORE REPLACE...2222222222222 ");fflush(stdout);
												result = AE_replace_dataset_named_ref2(primary,refobject2,ref_list[0],tagRefType,filetag); //Alokesh Ghosh - Modified
												printf("\n\t AE_replace_dataset_named_ref2 --->%d \n\t ",result);fflush(stdout);

												result = AOM_save(primary);
												printf("\n\t AOM_save --->%d \n\t ",result);fflush(stdout);

												result = AOM_unlock(primary);
												printf("\n\t AOM_unlock --->%d \n\t ",result);fflush(stdout);
											//}
												break;

										}
										else
										{
											result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
											printf("\n\t Generic..Got reference list--->%d",result);fflush(stdout);

											result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
											printf("\n\t Generic..File Imported--->%d",result);fflush(stdout);

											result = AOM_save(filetag);
											printf("\n\t Generic..File saved--->%d \n\t ",result);fflush(stdout);

											if (IMF_set_original_file_name(filetag,itemId12)!=ITK_ok);
											result = AOM_save(filetag);
											printf("\n\t File saved--->%d  [%s]",result,itemId12); fflush(stdout);

											result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
											printf("\n\t Generic..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

											AE_set_dataset_tool(primary,tool);
											printf("\n\t Generic..Tool set--->%d",result);fflush(stdout);fflush(stdout);

											result = AOM_save(primary);
											if(result == 0)
											Flag_1 = 1;
										}
									}
								}
							}

							if (Flag_1 == 0)
							{
								printf("\n\t Generic/Instance..itemId found---->%s",itemId);fflush(stdout);
								result = AE_find_datasettype(ClassNmGI, &datasettype);
								printf("\n\t Generic/Instance..Type found---->%d",result);fflush(stdout);

								result = AE_create_dataset_with_id(datasettype,itemId,ItemDesc, NULL, NULL, &Newdataset);
								printf("\n\t Generic/Instance..Dataset Created---->%d [%s]",result,itemId);fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\n\t Generic/Instance..Dataset format set--->%d",result);fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t Generic/Instance..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t ****Generic/Instance..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if(strcmp(SubTypeNm,"Generic")==0)
								{
									if ((nameRef_cnt == 0) && ((strcmp(fullPath,"")!=0) && (strcmp(fullPath,"-")!=0)) )
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t Generic/Instance..Got reference list--->%d",result);fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t Generic/Instance..File Imported--->%d",result);fflush(stdout);

										result = AOM_save(filetag);
										printf("\n\t Generic/Instance..File saved--->%d \n\t ",result);fflush(stdout);

										if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
										result = AOM_save(filetag);
										printf("\n\t Generic/InstanceFile saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

										result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
										printf("\n\t Generic/Instance..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

										AE_set_dataset_tool(Newdataset,tool);
										printf("\n\t Generic/Instance..Tool set--->%d",result);fflush(stdout);fflush(stdout);
									}
								}

								result = AOM_save(Newdataset);

								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t Generic/Instance..Fndrelation ---->%d",result); fflush(stdout);

								if(Fndrelation!= NULLTAG)
								{
									printf("\n\t Generic/Instance..Relation Already Exist...........\n\n" );fflush(stdout);
								}
								else
								{
									result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
									printf("\n\t Generic/Instance..GRM_create_relation ---->%d",result);fflush(stdout);
									result = GRM_save_relation(relation);
									printf("\n\t Generic/Instance..GRM_save_relation ---->%d",result);fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
					}
//Commented on 20.01.2022 to avoid duplicate generic dataset
/*					else
					{
						printf("\n\t******* Generic/Instance *********"); fflush(stdout);
						printf("\n\t SubTypeNm:[%s]",SubTypeNm);fflush(stdout);

						result = GRM_find_relation_type("IMAN_specification", &relation_type);
						printf("\n\t Generic/Instance..GRM_find_relation_type ---->%d",result); fflush(stdout);

						if( (strcmp(SubTypeNm,"Generic")==0) ||  (strcmp(SubTypeNm,"Instance")==0) )
						{
							if (tc_strstr(ClassName,"ProAsm")!=NULL)
							{
								strcpy(ClassNmGI,"ProAsm");
								ClassNmGI[strlen(ClassNmGI)] = '\0';
							}
							else if (tc_strstr(ClassName,"ProPrt")!=NULL)
							{
								strcpy(ClassNmGI,"ProPrt");
								ClassNmGI[strlen(ClassNmGI)] = '\0';
							}

							if (strcmp(ClassNmGI,"")==0)
							{
								printf("\n\t Generic/Instance..ClassNmGI [%s] is NULL hence do not creating dataset.....????",ClassNmGI); fflush(stdout);
								continue;
							}

								ApplnOwnerFlag = 1;

								if ( (tc_strstr(ApplnOwner,"Proe")!=NULL) || (strcmp(ApplnOwner,"-")==0) && (strcmp(ApplnOwner,"")==0))
								{
									if (tc_strstr(ClassName,"ProAsm")!=NULL)
									{
										strcpy(ApplnOwnerStr,"ProEAsm");
										ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
									}
									else if (tc_strstr(ClassName,"ProPrt")!=NULL)
									{
										strcpy(ApplnOwnerStr,"ProEPart");
										ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
									}
									else
									{
										strcpy(ApplnOwnerStr,"");

										printf("\n\t 2..Generic/Instance..ApplnOwner string is not Valid to Set ---->%s,%s , %s",itemId,itemRevSeq,JTid1); fflush(stdout);
									}
								}
								else if (tc_strstr(ApplnOwner,"Catia")!=NULL)
								{
									strcpy(ApplnOwnerStr,"Cat-Part");
									ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
								}
								else
								{
									strcpy(ApplnOwnerStr,"");

									printf("\n\t Generic/Instance..ApplnOwner string is not Valid to Set ---->%s,%s , %s",itemId,itemRevSeq,JTid1); fflush(stdout);
								}

							if(relation_type)
							{
								//printf("\n\t "); fflush(stdout);
								if (TCTYPE_ask_name(relation_type,type_name)!=ITK_ok);
								printf("\t Generic/Instance..Type Name:%s ..............",type_name);fflush(stdout);
							}

							if(tc_strcmp(SubTypeNm,"Instance")==0)
							{
								DatasetRelFlag = 0;
								DatasetFlag = 0;
								DatasetExistFlag = 0;

								if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
								printf("  1.Generic/Instance..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

								if(n_attchs>0)
								{
									for (i=0; i < n_attchs; i++)
									{
										if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
										if(TCTYPE_ask_name(secObjTypeTag,type_name2));
										printf("    1.Generic/Instance..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

										//if (tc_strcmp(type_name2,"ProPrt")==0)
										if (tc_strcmp(type_name2,ClassNmGI)==0)
										{
											printf("  1.Generic/Instance..Dataset is already attached to Revision \n\t"); fflush(stdout);

											printf("\n\t 1.Generic/Instance..Relation Already Exist...........\n\n\t" );fflush(stdout);
											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
											DatasetFlag = 1;

											if (tc_strcmp(SubTypeNm,"Instance")==0)
											{
												if (AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc)!=ITK_ok);
												printf("     1.Generic/Instance..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);
												if (tc_strcmp(ItemDesc,DatasetDesc) != 0)
												{
													printf("     1.Generic/Instance..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

													setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
													if (AOM_save(secondary_objects[i])!=ITK_ok);
													if (AOM_unlock(secondary_objects[i])!=ITK_ok);
												}
											}
											break;
										}
									}
								}
							}
							else
							{
								if(QRY_find("Dataset Name", &queryTag_d));
								printf("  After IFERR_REPORT : QRY_find....");fflush(stdout);
								if (queryTag_d)
								{
									printf("  Found Query 'Dataset Name'");fflush(stdout);
								}
								else
								{
									printf("  Not Found Query 'Dataset Name'");fflush(stdout);
								}
								qry_values_d[0] = itemId ;

								if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
								printf("\n\t Generic/Instance..resultCount_d:[%d]",resultCount_d);fflush(stdout);

								if(resultCount_d > 0)
								{
									DatasetFlag = 0;

									for (j=0;j<resultCount_d;j++ )
									{
										itemRevDataSet_tag = revtag_d[j];

										if(TCTYPE_ask_object_type(itemRevDataSet_tag,&datasetTag));
										if(TCTYPE_ask_name(datasetTag,type_name3));
										printf("\n\t Generic/Instance..Part type_name3 :%s",type_name3); fflush(stdout);

										//if (strcmp(type_name3,"ProPrt")==0)
										if (strcmp(type_name3,ClassNmGI)==0)
										{
											result = AE_ask_dataset (itemRevDataSet_tag,&item_tag_data_rev);
											printf("\n\t Generic/Instance..AE_ask_dataset--->%d",result);fflush(stdout);

											result = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
											printf("\n\t Generic/Instance..ref_count_d Count--->%d \n\t ",ref_count_d);fflush(stdout);

											if((ref_count_d>0) && (strcmp(SubTypeNm,"Generic")==0))
											{
												RefObject_d = namRefObject_d[0];

												if (AOM_ask_value_string(RefObject_d,"object_string",&named_refTemp)!=ITK_ok);
												if (AOM_ask_value_string(RefObject_d,"object_string",&named_refTemp2)!=ITK_ok);
												printf("\n\t Generic/Instance..item_tag named_refTemp:[%s]  JTid1:[%s]",named_refTemp,JTid1);

												if(strlen(named_refTemp)>30)
												{
													if((tc_strstr(named_refTemp,".prt")!=NULL) || (tc_strstr(named_refTemp,".asm")!=NULL))
													{
														char *tempN1=strtok(named_refTemp,"."); //1
														char *tempN2=strtok(NULL,".");		//2
														//char *tempN3=strtok(NULL,".");		//3

														//printf(" tempN1:%s  tempN2:%s  tempN3:%s",tempN1,tempN2,tempN3); fflush(stdout);
														printf(" tempN1:%s  tempN2:%s ",tempN1,tempN2); fflush(stdout);

														//int lengthMinus1=strlen(tempN2)+ strlen(tempN3) + 3 ;
														int lengthMinus1=strlen(tempN2) + 1 ;
														printf(" lengthMinus --->%d",lengthMinus);

														named_ref = NULL;
														named_ref=(char *) MEM_alloc(100);
														strncpy(named_ref,tempN1,((strlen(named_refTemp))-lengthMinus1));
														strcat(named_ref,".");
														strcat(named_ref,tempN2);
														//strcat(named_ref,".");
														//strcat(named_ref,tempN3);
													}
												}
												else
												{
													named_ref = NULL;
													named_ref=(char *) MEM_alloc(100);
													strcpy(named_ref,named_refTemp);
												}

												if ((strcmp(named_ref,JTid1)==0) || (strcmp(named_refTemp2,DataSetNmOrg)==0))
												{
													DatasetFlag = 1;
													printf("...already present and match found.\n");
													break;
												}
												else
												{
													printf("...match not found hence continuing..\n");
													DatasetFlag = 0;
												}
											}
											if (strcmp(SubTypeNm,"Instance")==0)
											{
												DatasetFlag = 1;
												printf("...Instance already present and match found.\n");
												break;
											}
											else
											{
												printf("...Instance match not found hence continuing..\n");
												DatasetFlag = 0;
											}
										}
									}
									printf("\n\t Generic/Instance..DatasetFlag:%d ",DatasetFlag);

									if(DatasetFlag == 1)
									{
										if(relation_type!=NULLTAG)
										{
											//printf("\n\t "); fflush(stdout);
											if (TCTYPE_ask_name(relation_type,type_name)!=ITK_ok);
											printf("\t Generic/Instance..Type Name:%s ..............",type_name);fflush(stdout);
										}

										result = GRM_find_relation( item_tag, item_tag_data_rev, relation_type ,&Fndrelation);
										printf("\n\t Generic/Instance..Fndrelation ---->%d \n\t",result); fflush(stdout);

										if(Fndrelation != NULLTAG)
										{
											DatasetRelFlag = 0;

											if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
											printf("  1.Generic/Instance..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

											if(n_attchs>0)
											{
												for (i=0; i < n_attchs; i++)
												{
													if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
													if(TCTYPE_ask_name(secObjTypeTag,type_name2));
													printf("    1.Generic/Instance..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

													//if (strcmp(type_name2,"ProPrt")==0)
													if (strcmp(type_name2,ClassNmGI)==0)
													{
														printf("  1.Generic/Instance..Dataset is already attached to Revision \n\t"); fflush(stdout);

														printf("\n\t 1.Generic/Instance..Relation Already Exist...........\n\n\t" );fflush(stdout);
														DatasetRelFlag = 1;
														DatasetExistFlag = 1;

														if (strcmp(SubTypeNm,"Instance")==0)
														{
															if (AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc)!=ITK_ok);
															printf("     1.Generic/Instance..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);
															if (strcmp(ItemDesc,DatasetDesc) != 0)
															{
																printf("     1.Generic/Instance..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

																setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
																if (AOM_save(secondary_objects[i])!=ITK_ok);
																if (AOM_unlock(secondary_objects[i])!=ITK_ok);
															}
														}

														break;
													}
												}
											}
										}
										else
										{
											DatasetRelFlag = 0;
										}

										if (DatasetRelFlag == 0)
										{
											if (GRM_create_relation(item_tag, item_tag_data_rev, relation_type, NULL, &relation)!=ITK_ok);
											printf("\n\t 1.Generic/Instance..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
											if (AOM_refresh (item_tag,0)!=ITK_ok);
											printf("\n\t ");
											if (AOM_refresh(relation,0)!=ITK_ok);
											result = GRM_save_relation(relation);
											printf("\n\t 1.Generic/Instance..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

											DatasetExistFlag = 1;
										}
									}
								}
								else  ///New create dataset
								{
									DatasetFlag = 0;
								}
							}

							if(DatasetFlag == 0)
							{
								//dataset_NewRevNo = dataset_RevNo +1;

								result = AE_find_datasettype(ClassNmGI, &datasettype);
								printf("\n\t Type found---->%d",result);fflush(stdout);

								//result = AE_find_dataset(itemId, &Newdataset);
								//if(Newdataset)
								//{
								//	printf("\n\t Dataset Found..."); fflush(stdout);
								//}
								//else
								//{
									printf("\n\t Creating New Dataset..."); fflush(stdout);

									result = AE_create_dataset_with_id(datasettype,itemId,ItemDesc, NULL, NULL, &Newdataset);
									printf("\n\t Dataset created for Generic/Instance --->%s",itemId); fflush(stdout);

									result = AE_set_dataset_format(Newdataset, "BINARY_REF");
									printf("\n\t Dataset format set--->%d",result); fflush(stdout);

									result = AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t Tool set--->%d",result); fflush(stdout);
								//}

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if(strcmp(SubTypeNm,"Generic")==0)
								{
									if ((nameRef_cnt == 0) && ((strcmp(fullPath,"")!=0) && (strcmp(fullPath,"-")!=0)) )
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t Got reference list--->%d",result); fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t File Imported--->%d",result); fflush(stdout);

										result = AOM_save(filetag);
										printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

										if (IMF_set_original_file_name(filetag,DataSetNmOrg)!=ITK_ok);
										result = AOM_save(filetag);
										printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

										result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
										printf("\n\t AE_add_dataset_named_ref--->%d",result); fflush(stdout);

										AE_set_dataset_tool(Newdataset,tool);
										printf("\n\t Tool set--->%d",result); fflush(stdout);
									}
								}

								result = AOM_save(Newdataset);
								printf("\n\t AOM_save--->%d",result); fflush(stdout);

								//result = GRM_find_relation_type("IMAN_specification", &relation_type);
								//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

								if(relation_type != NULLTAG)
								{
									//printf("\n\t "); fflush(stdout);
									if (TCTYPE_ask_name(relation_type,type_name)!=ITK_ok);
									printf("\n\t Type Name: %s ..............",type_name);fflush(stdout);
								}

								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t Fndrelation ---->%d \n\t",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									DatasetRelFlag = 0;

									if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
									printf("  2.Generic/Instance..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

									if(n_attchs>0)
									{
										for (i=0; i < n_attchs; i++)
										{
											if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
											if(TCTYPE_ask_name(secObjTypeTag,type_name2));
											printf("    2.Generic/Instance..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

											//if (strcmp(type_name2,"ProPrt")==0)
											if (strcmp(type_name2,ClassNmGI)==0)
											{
												printf("  2.Generic/Instance..Dataset is already attached to Revision \n\t"); fflush(stdout);

												printf("\n\t 2.Generic/Instance..Relation Already Exist...........\n\n\t" );fflush(stdout);
												DatasetRelFlag = 1;
												DatasetExistFlag = 1;

												if (strcmp(SubTypeNm,"Instance")==0)
												{
													if (AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc)!=ITK_ok);
													printf("     2.Generic/Instance..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);
													if (strcmp(ItemDesc,DatasetDesc) != 0)
													{
														printf("     2.Generic/Instance..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

														setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
														if (AOM_save(secondary_objects[i])!=ITK_ok);
														if (AOM_unlock(secondary_objects[i])!=ITK_ok);
													}
												}

												break;
											}
										}
									}
								}
								else
								{
									DatasetRelFlag = 0;
								}

								if (DatasetRelFlag == 0)
								{
									if (GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation)!=ITK_ok);
									printf("\n\t 2.Generic/Instance..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
									if (AOM_refresh (item_tag,0)!=ITK_ok);
									printf("\n\t ");
									if (AOM_refresh(relation,0)!=ITK_ok);
									result = GRM_save_relation(relation);
									printf("\n\t 2.Generic/Instance..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
					} //end of else condn of generic/instance
*/
					if (ApplnOwnerFlag == 1)
					{
						printf("\n\t"); fflush(stdout);
						if (AOM_ask_value_string(item_tag,"t5_ApplicationOwner",&RevApplnOwner)!=ITK_ok);

						if( (tc_strcmp(RevApplnOwner,ApplnOwnerStr) != 0) || (tc_strcmp(RevApplnOwner,"") == 0) )
						{
							printf("\n\t Setting ApplicationOwner as '%s' instead of old '%s' for Part %s, %s , %s\n\n\t",ApplnOwnerStr,RevApplnOwner,itemId,itemRevSeq,JTid1); fflush(stdout);

							if(AOM_lock(item_tag)!=ITK_ok);
							//printf("\n\t "); fflush(stdout);
							if(AOM_set_value_string(item_tag,"t5_ApplicationOwner",ApplnOwnerStr)!=ITK_ok);
							//printf("\n\t "); fflush(stdout);
							if(AOM_save(item_tag)!=ITK_ok);
							//printf("\n\t "); fflush(stdout);
							if(AOM_unlock(item_tag)!=ITK_ok);
						}
						//else
						//{
						//	printf("\n\t ApplicationOwner is already set as %s \n\n",RevApplnOwner); fflush(stdout);
						//}
					}

					if (DatasetExistFlag == 1)
					{
						//printf("    DatasetExistFlag exit Flag\n"); fflush(stdout);
						break;
					}

				} //end of for loop
			} // end of DesignRevision Sequence query resultant
			else
			{
				printf("Item Revision not Found for [%s :: %s] \n\t",itemId,itemRevSeq); fflush(stdout);
			}
		}  // while end
	}  // fp file end
	else
	{
		printf("\n\n ??????Could not able to read file %s \n\n\t",inputfile); fflush(stdout);
	}

	if (fp)
		fclose(fp);

	printf("\n ");
	ITK_CALL(POM_logout(false));
	return status;
}
