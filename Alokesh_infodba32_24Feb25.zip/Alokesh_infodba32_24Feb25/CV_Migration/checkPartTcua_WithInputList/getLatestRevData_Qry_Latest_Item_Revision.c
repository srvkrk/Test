/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:tm_altoz.c
*
* Description		: > This Utility is to do unit testing of functions .
* Module  		        
* Since		    :    

* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 16/06/2022   	Sanjoy Mondal			    Initial Code

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>

//Ujjawal - (For Global Variables)
FILE 		*output 			= NULL;
FILE 		*incremental_Creo 	= NULL;
FILE 		*incremental_Catia 	= NULL;

#define MAX_LINE_LEN 10024
#define IFERR_ABORT(X)  (report_error( __FILE__, __LINE__, #X, X, TRUE))
#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))

static void ECHO(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int report_error(char *file, int line, char *call, int status,
    logical exit_on_error)
{
    if (status != ITK_ok)
    {
        int
            n_errors = 0;
        const int
            *severities = NULL,
            *statuses = NULL;
        const char
            **messages;

        EMH_ask_errors(&n_errors, &severities, &statuses, &messages);
        if (n_errors > 0)
        {
            ECHO("\n%s\n", messages[n_errors-1]);
            EMH_clear_errors();
        }
        else
        {
            char *error_message_string;
            EMH_get_error_string (NULLTAG, status, &error_message_string);
            ECHO("\n%s\n", error_message_string);
        }

        ECHO("error %d at line %d in %s\n", status, line, file);
        ECHO("%s\n", call);
        if (exit_on_error)
        {
            ECHO("%s", "Exiting program!\n");
            exit (status);
        }
    }
    return status;
}



/*
#define ITKCALL( argument )                                             \
{                                                                       \
    int retcode = argument;                                             \
    if ( retcode != ITK_ok ) {                                          \
        char* s;                                                        \
        printf( " "#argument "\n" );                                    \
        printf( "  returns [%d]\n", retcode );                          \
        EMH_ask_error_text (retcode, &s);                               \
        printf( "  Teamcenter ERROR: [%s]\n", s);           \
        printf( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
        if (s != 0) MEM_free (s);                                       \
    }                                                                   \
}*/


#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static void handle_itk_error
    ( int stat,                               /* <I> */
      int source_code_line,                   /* <I> */
      const char *source_code_file_name       /* <I> */
    );

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}




/*******************************************START OF UTILITY FUNCTIONS**************************************************/

/* right trim */
char *rtrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int index=0;    /* index of the last non-space char */

    /* validate input */
    if (!str)
        return str;

    /* copy the string */
    while(*src){
        *dst++ = *src++;
        c = *src;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;
        else
            is_space=0;

        if (is_space==0 && *src)
            index = (src-str)+1;
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

/* left trim */
char *ltrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int index=0;    /* index of the first non-space char */

    /* validate input */
    if (!str)
        return str;

    /* skip leading white-spaces */
    while((c=*src)){ 
        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' '){
            ++src;
            ++index;
        } else
            break;
    }

    /* copy rest of the string */
    while(*src)
        *dst++ = *src++;

    /* terminate the string */
    *(src-index)='\0';

    return str;
}
void setAddTagObj(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}


void t5AddTagObjToSet(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

/* Function to add string into a set of string */
void t5AddStrToSet(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void t5FindStrInSet(char **str_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(str_list[k],str)==0)
		{
			*found=1;
			break;
		}

	}
}

///CODE START HERE
int t5GetItemRevison(char* InputPart)
{
	//MT start
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;
	
	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int n_tags_foundd2=0;
	int n_tags_foundd3=0;
	tag_t *tags_foundd3 = NULL;
	tag_t *tags_foundd2 = NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	const char *attrss3[2];
	const char *valuess3[2];
	//MT end
	//printf("\n FUN:part no :%s.", InputPart);fflush(stdout);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)InputPart;
	values2[1] = "Design";
	if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
	//printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
	}
	else
	{
		///printf("\n FUN:Inside T5_EE_Part:%s.", InputPart);fflush(stdout);
		attrss2[0] ="item_id";
		attrss2[1] ="object_type";
		valuess2[0] = (char *)InputPart;
		valuess2[1] = "T5_EE_Part";
		if(ITEM_find_items_by_key_attributes(2,attrss2, valuess2, &n_tags_foundd2, &tags_foundd2)!=ITK_ok)PrintErrorStack();
		//printf("\n FUN:EE part count :%d.", n_tags_foundd2);fflush(stdout);
		if (n_tags_foundd2>0)
		{
			OutPutTag= tags_foundd2[0];
		}
		else
		{
			//printf("\n FUN:Inside T5_ClrPart:%s.", InputPart);fflush(stdout);
			attrss3[0] ="item_id";
			attrss3[1] ="object_type";
			valuess3[0] = (char *)InputPart;
			valuess3[1] = "T5_ClrPart";
			if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
			//printf("\n FUN:T5_ClrPart part count :%d.", n_tags_foundd3);fflush(stdout);
			if (n_tags_foundd3>0)
			{
				OutPutTag= tags_foundd3[0];
			}
			else
			{
				//printf("\n FUN:Inside T5_ArchModule:%s.", InputPart);fflush(stdout);
				attrss3[0] ="item_id";
				attrss3[1] ="object_type";
				valuess3[0] = (char *)InputPart;
				valuess3[1] = "T5_ArchModule";
				if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
				//printf("\n FUN:T5_ArchModule part count :%d.", n_tags_foundd3);fflush(stdout);
				if (n_tags_foundd3>0)
				{
					OutPutTag= tags_foundd3[0];
				}
			}
		}
	}
	if(OutPutTag==NULLTAG)
	{
		//printf("\n FUN: NULL tag for part no:%s.", InputPart);fflush(stdout);
	}
	else
	{
		//printf("\n FUN: tag found for part no:%s.", InputPart);fflush(stdout);
	}
	/*if(attrs2) MEM_free(attrs2);
	if(attrss2) MEM_free(attrss2);
	if(values2) MEM_free(values2);
	if(valuess2) MEM_free(valuess2);*/

	return OutPutTag;	
}

int getItemRevObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\n SAN:tm_sendESOMailRep: getItemRevObject: count==>%d\n", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}



int getGeneralObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Name";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find("General...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\n SAN:tm_sendESOMailRep: getGeneralObject: count==>%d\n", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}



typedef struct PartModel_
{
 int level;
 tag_t childItemRev;
 tag_t childBomLine;
} *PartModel; 

void setAddPartModel(int *count,PartModel **objlist,PartModel obj )
{

	*count=*count+1;
	//printf("\n ****count==>%d", *count);fflush(stdout);
	if(*count==1)
	{
		//printf("\n ****setAddPartModel1");fflush(stdout);
		(*objlist) = (PartModel *)malloc((*count ) * sizeof(PartModel ));
		//printf("\n ***setAddPartModel2");fflush(stdout);
	}
	else
	{
		//printf("\n **setAddPartModel3");fflush(stdout);
		(*objlist) = (PartModel *)realloc((*objlist),(*count) * sizeof(PartModel ));
		//printf("\n ***setAddPartModel4");fflush(stdout);
		//printf("\n **setAddPartModel5");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
	//printf("\n **setAddPartModel");fflush(stdout);
}



char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


void setAddInt(int *count,int **objlist,int obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddInt1");fflush(stdout);
		(*objlist) = (int *)malloc((*count ) * sizeof(int ));
	}
	else
	{
		//printf("\n **setAddInt2");fflush(stdout);
		(*objlist) = (int *)realloc((*objlist),(*count ) * sizeof(int ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));


}


void setFindInt(int *int_list,int count,int in,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(int_list[k]== in)
		{
			*found=1;
			break;
		}

	}
}





void setFindTagInSet(tag_t *objlist,tag_t obj,int count,int *found)
{
	int k=0;
	*found=-1;
	for(k=0;k<count;k++)
	{		
		if(objlist[k]==obj)
		{
			*found=k;
			break;
		}
	}
}



char *t5TrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int in_word=0;  /* word boundary logical check */
    int index=0;    /* index of the last non-space char*/

    /* validate input */
    if (!str)
        return str;

    while ((c=*src)){
        is_space=0;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;

        if(is_space == 0){
         /* Found a word */
            in_word = 1;
            *dst++ = *src++;  /* make the assignment first
                               * then increment
                               */
        } else if (is_space==1 && in_word==0) {
         /* Already going through a series of white-spaces */
            in_word=0;
            ++src;
        } else if (is_space==1 && in_word==1) {
         /* End of a word, dont mind copy white spaces here */
            in_word=0;
            *dst++ = *src++;
            index = (dst-str)-1; /* location of the last char */
        }
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

void remove_multi_new_line(char* string)
{
  size_t length = strlen(string);
  while((length>0) && (string[length-1] == '\n'))
  {
      --length;
      string[length] ='\0';
  }
}


void  t5GetCurrentMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}


//declaration of date structure

struct date{
	int dd,mm,yy;
	};
//function to get yesterday's (previous) date
void getYesterdayDate(struct date *d){
	if(d->dd==1){
		if(d->mm==4||d->mm==6||d->mm==9||d->mm==11){
			d->dd=31;
			d->mm--;
		}
		else if(d->mm==3){
			if((d->yy%4)==0 && ((d->yy%100)!=0 || (d->yy%400)==0)) d->dd=29;
			else d->dd=28;
			d->mm--;
		}
		else if(d->mm==1){
			d->dd=31;
			d->yy--;
			d->mm=12;
		}
		else if(d->mm==2){
			d->dd=31;
			d->mm--;
		}
		else{
			d->dd=30;
			d->mm--;
		}
	}
	else{
		d->dd--;
	}
}


void t5GetPrevDate(char cprevAccessDate[30])
{
	int day, month, year, nd, nm, ny;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	
	struct date dt;

	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	
	dt.dd = day;
	dt.mm = month;
	dt.yy = year;
	
	printf( "Given date is %d:%d:%d\n", day, month, year );
   
	getYesterdayDate(&dt);
	nd = dt.dd;
	nm = dt.mm;
	ny = dt.yy;
	
    printf( "Prev  days date is %d:%d:%d\n", nd, nm, ny );
	t5GetCurrentMonth(nm,cMonth);
	//printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cprevAccessDate,strDay);
	tc_strcat(cprevAccessDate,"-");
	tc_strcat(cprevAccessDate,cMonth);
	tc_strcat(cprevAccessDate,"-");
	tc_strcat(cprevAccessDate,strYear);
	tc_strcat(cprevAccessDate," ");
	tc_strcat(cprevAccessDate,"00:00");
	//printf("\n cprevAccessDate:%s\n",cprevAccessDate);
}

void t5GetPrevDateTo(char cprevAccessDate[30])
{
	int day, month, year, nd, nm, ny;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	
	struct date dt;

	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	
	dt.dd = day;
	dt.mm = month;
	dt.yy = year;
	
	printf( "Given date is %d:%d:%d\n", day, month, year );
   
	getYesterdayDate(&dt);
	nd = dt.dd;
	nm = dt.mm;
	ny = dt.yy;
	
    printf( "Prev  days To date is %d:%d:%d\n", nd, nm, ny );
	t5GetCurrentMonth(nm,cMonth);
	//printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cprevAccessDate,strDay);
	tc_strcat(cprevAccessDate,"-");
	tc_strcat(cprevAccessDate,cMonth);
	tc_strcat(cprevAccessDate,"-");
	tc_strcat(cprevAccessDate,strYear);
	tc_strcat(cprevAccessDate," ");
	tc_strcat(cprevAccessDate,"23:59");
	//printf("\n cprevAccessDate:%s\n",cprevAccessDate);
}


void t5GetCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n t5GetCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);

	fflush(stdout);
}

int getTCObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	printf("\n\n partNumber ===> [%s]\n",partNumber);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\n getLatestPart: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}


int getItemRevObj(char *partNumber, char* revId, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObjs = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	printf("\n\n partNumber ===> [%s]\n",partNumber);fflush(stdout);
	printf("\n\n revId ===> [%s]\n",revId);fflush(stdout);
	
	qry_entries[0] = "Item ID";
	
	qry_values[0] = partNumber;
	
		
	CALLAPI(QRY_find2("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 1, qry_entries, qry_values, &count, &itemObjs));
	printf("\n getItemRevObj: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		//*tcPart = itemObjs[count-1];
		int k=0;
		char* revS = NULL;		
		for(k=0;k<count;k++)
		{
			CALLAPI(AOM_ask_value_string(itemObjs[k],"item_revision_id",&revS));
			//printf("\n getItemRevObj: revS==>%s", revS);fflush(stdout);
			//printf("\n getItemRevObj: revS length==>%d", strlen(revS));fflush(stdout);
			if(revS==NULL) continue;
			if(tc_strcmp(revS,revId)==0)
			{
				*tcPart = itemObjs[k];
				break;
			}			
		}
	}
	
	return ifail;
}

int getItemRevObj_bkp(char *partNumber, char* revId, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObjs = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	printf("\n\n partNumber ===> [%s]\n",partNumber);fflush(stdout);
	printf("\n\n revId ===> [%s]\n",revId);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = "Design Revision";
	qry_values[1] = partNumber;
	
		
	CALLAPI(QRY_find2("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObjs));
	printf("\n getItemRevObj: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		//*tcPart = itemObjs[count-1];
		int k=0;
		char* revS = NULL;		
		for(k=0;k<count;k++)
		{
			CALLAPI(AOM_ask_value_string(itemObjs[k],"item_revision_id",&revS));
			//printf("\n getItemRevObj: revS==>%s", revS);fflush(stdout);
			//printf("\n getItemRevObj: revS length==>%d", strlen(revS));fflush(stdout);
			if(revS==NULL) continue;
			if(tc_strcmp(revS,revId)==0)
			{
				*tcPart = itemObjs[k];
				break;
			}			
		}
	}
	
	return ifail;
}

int getPartObjFromRevSeq(char* partnumber, char* rev, char* seq, tag_t *partObj)
{
	int ifail = ITK_ok;
	
	int  count 	= 0;
	tag_t *itemObjs = NULLTAG;
	char* revStr = NULL;
	int seqInt = 0;
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "Item ID";
	qry_entries[1] = "Type";
	//qry_entries[2] = "Sequence Id";
	
	qry_values[0] = partnumber;
	revStr = (char *) MEM_alloc( 10 * sizeof(char) );
	//tc_strcpy(revStr,"");
	tc_strcpy(revStr,rev);
	tc_strcat(revStr,";");
	tc_strcat(revStr,seq);
	printf("\nSAN:getPartObjFromRevSeq: revStr=========>%s\n",revStr);fflush(stdout);
	printf("\nSAN:getPartObjFromRevSeq: revStr==length=======>%d\n",strlen(revStr));fflush(stdout);
	qry_values[1] = "Design Revision";
	
	//trimLeading(revStr);
	char* revStr1 = NULL;
	char* revStr2 = NULL;
	revStr1 = ltrimString(revStr);
	revStr2 = rtrimString(revStr1);
	
	
		
	printf("\nSAN:getPartObjFromRevSeq: After trim revStr2=========>%s\n",revStr2);fflush(stdout);
	printf("\nSAN:getPartObjFromRevSeq: After trim revStr2==length=======>%d\n",strlen(revStr2));fflush(stdout);	
	
	CALLAPI(QRY_find("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObjs));
	printf("\n getPartObjFromRevSeq: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		int k=0;
		char* revS = NULL;
		for(k=0;k<count;k++)
		{
			CALLAPI(AOM_ask_value_string(itemObjs[k],"item_revision_id",&revS));
			printf("\n getPartObjFromRevSeq: revS==>%s", revS);fflush(stdout);
			printf("\n getPartObjFromRevSeq: revS length==>%d", strlen(revS));fflush(stdout);
			if(revS==NULL) continue;
			if(tc_strcmp(revS,revStr2)==0)
			{
				*partObj = itemObjs[k];
				break;
			}
			
		}
	}
	
	if(revStr!=NULL) MEM_free(revStr);
	return ifail;	

}


/*******************************************END OF UTILITY FUNCTIONS**************************************************/
void usage ()
{
    printf ("\nUSAGE:  \n");
    printf ("\ntm_updateVf -f=<input file path>\n\n");
    return;
}

void insert_object_into_folder(tag_t folder, tag_t object, int pos)
{
    IFERR_REPORT(AOM_refresh( folder, TRUE));
    IFERR_REPORT(FL_insert(folder, object, pos));
    IFERR_REPORT(AOM_save(folder));
    IFERR_REPORT(AOM_refresh( folder, FALSE));
}

void create_folder_in_home_folder(char *folder_name, tag_t *folder)
{
    char
        *user_name_string = NULL;
    tag_t
        user = NULLTAG, 
        home_folder = NULLTAG;

    IFERR_REPORT(POM_get_user(&user_name_string, &user));
    IFERR_REPORT(SA_ask_user_home_folder(user, &home_folder));

    printf("\nSAN:Creating Folder: Home-> %s\n", folder_name);
    IFERR_REPORT(FL_create(folder_name, "", folder));
    IFERR_REPORT(AOM_save(*folder));

    IFERR_REPORT(FL_insert(home_folder, *folder, -1));
    IFERR_REPORT(AOM_save(home_folder));
    IFERR_REPORT(AOM_refresh( home_folder, FALSE));
    MEM_free(user_name_string);
}

typedef struct ModuleDet_
{
	char partId[50];
	char parRev[20];
	char partNumber[70];
	char occId[200];
	char occEff[200];
	char occFromDate[20];
	char occToDate[20];
	char* variantFormula;
}ModuleDet;

void setAddModuleDet(int *count,ModuleDet **objlist,ModuleDet obj )
{

	*count=*count+1;
	if(*count==1)
	{
		(*objlist) = (ModuleDet *)malloc((*count ) * sizeof(ModuleDet ));
	}
	else
	{
		(*objlist) = (ModuleDet *)realloc((*objlist),(*count) * sizeof(ModuleDet ));
	}

	(*objlist)[*count-1] = obj;
}


void t5FindModuleInModuleSet(ModuleDet *module_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(module_list[k].partNumber,str)==0)
		{
			*found=1;
			break;
		}

	}
}




int updateVFofDestModule(tag_t archModuleRevTag, tag_t child_line, int* childIdCnt, char*** childIdList)
{
	int ifail = ITK_ok;

	int childId = 0;
	int childRevSeq = 0;
	char* child_id = NULL;
	char* child_rev_seq = NULL;
	char child_partNum[100];
	
	int effecId = 0;
	char* effec_id = NULL;
	char* occ_effec = NULL;
	int occEffec = 0;
	int vfFormId = 0;
	char* variant_formula = NULL;
	int findNoId = 0;
	char* find_no = NULL;
	char *sCustomTotalVF= NULL;	
	if (sCustomTotalVF != NULL) { sCustomTotalVF=NULL; }
	sCustomTotalVF=malloc(9000 * sizeof(char));
	
	char *sCustomANDVF= NULL;
	char *sCustomORVF= NULL;
	char* sCustomORVF1 = NULL;

	
	CALLAPI(BOM_line_look_up_attribute("bl_item_item_id",&childId));
	CALLAPI(BOM_line_look_up_attribute("bl_rev_item_revision_id",&childRevSeq));
	CALLAPI(BOM_line_ask_attribute_string(child_line,childId,&child_id));
	CALLAPI(BOM_line_ask_attribute_string(child_line,childRevSeq,&child_rev_seq));
	
	printf("\n child_id[%s] child_rev_seq[%s]",child_id,child_rev_seq);fflush(stdout);
	
	tc_strcpy(child_partNum,"");
	tc_strcat(child_partNum,child_id);
	tc_strcat(child_partNum,"_");
	tc_strcat(child_partNum,child_rev_seq);
	
	printf("\n child_partNum[%s]",child_partNum);fflush(stdout);
	

	
	CALLAPI(BOM_line_look_up_attribute("bl_has_date_effectivity",&effecId));
	CALLAPI(BOM_line_ask_attribute_string(child_line,effecId,&effec_id));
	
	printf("\n Effectivity ID[%s]",effec_id);fflush(stdout);
	
	CALLAPI(BOM_line_look_up_attribute("bl_occ_effectivity",&occEffec));
	CALLAPI(BOM_line_ask_attribute_string(child_line,occEffec,&occ_effec));
	
	printf("\n Effectivity[%s]",occ_effec);fflush(stdout);
	
	CALLAPI(BOM_line_look_up_attribute("bl_formula",&vfFormId));
	CALLAPI(BOM_line_ask_attribute_string(child_line,vfFormId,&variant_formula));
	
	printf("\n variant_formula[%s]",variant_formula);fflush(stdout);
	
	tc_strcpy(sCustomTotalVF,"");
	tc_strcat(sCustomTotalVF,variant_formula);
	printf("\n VFSubStr1 =>%s\n ",sCustomTotalVF);fflush(stdout);
	
	ITK_CALL(STRNG_replace_str(sCustomTotalVF,"AND ([Teamcenter]","& ([Teamcenter]",&sCustomANDVF));
	printf("\n sCustomANDVF-------> %s\n",sCustomANDVF);fflush(stdout);

	ITK_CALL(STRNG_replace_str(sCustomANDVF,"AND [Teamcenter]","& [Teamcenter]",&sCustomANDVF));
	printf("\n sCustomANDVF-------> %s\n",sCustomANDVF);fflush(stdout);

	ITK_CALL(STRNG_replace_str(sCustomANDVF," OR "," | ",&sCustomORVF1));
	printf("\n SAN....sCustomANDVF1-------> %s\n",sCustomORVF1);fflush(stdout);
	
	ITK_CALL(STRNG_replace_str(sCustomORVF1,"?","-",&sCustomORVF));
	//ITK_CALL(STRNG_replace_str(sCustomORVF1,"& [Teamcenter]'SEAT MOVEMENT – DRIVER SEAT' = 4W","",&sCustomORVF));
	//Sanjoy
	//ITK_CALL(STRNG_replace_str(sCustomORVF,"'SEAT MOVEMENT ? DRIVER SEAT'","'SEAT MOVEMENT – DRIVER SEAT'",&sCustomORVF));	
	printf("\n Final Variant Formula is-------> %s\n",sCustomORVF);fflush(stdout);
	
	
	//ITK_CALL(STRNG_replace_str(sCustomORVF," ? ","-",&sCustomORVF));
	//printf("\n 111...Final Variant Formula is-------> %s\n",sCustomORVF);fflush(stdout);
	//bl_item_object_type
	
	
	//bl_sequence_no
	
	CALLAPI(BOM_line_look_up_attribute("bl_sequence_no",&findNoId));
	CALLAPI(BOM_line_ask_attribute_string(child_line,findNoId,&find_no));
	
	printf("\n find_no[%s]",find_no);fflush(stdout);
	
	//Get Child Item Rev

	tag_t archModuleItemTag = NULLTAG;
	tag_t bv = NULLTAG;
	tag_t bvr = NULLTAG;	
	tag_t childModuleRevTag = NULLTAG;
	tag_t* bvrs = NULLTAG;
	int bvr_count = 0;
	tag_t* bvs = NULLTAG;
	int bv_count = 0;
	
	int objTypeId = 0;
	char* bl_object_Type = NULL;
	
	CALLAPI(BOM_line_look_up_attribute("bl_item_object_type",&objTypeId));
	CALLAPI(BOM_line_ask_attribute_string(child_line,objTypeId,&bl_object_Type));
	
	printf("\n bl_object_Type==>%s\n",bl_object_Type);fflush(stdout);
	

	CALLAPI(getItemRevObj(child_id,child_rev_seq,&childModuleRevTag));
	
	
	
	
	

	if(childModuleRevTag == NULLTAG)
	{
		printf("\n Child Module Rev[%s/%s] not found in PLM. Exiting the program....\n",child_id,child_rev_seq);fflush(stdout);
		return ifail;
	}
	
	printf("\nFound Architecture Module Rev Tag ....\n");fflush(stdout);
	CALLAPI(ITEM_ask_item_of_rev(archModuleRevTag, &archModuleItemTag));
	

	CALLAPI(ITEM_list_bom_views(archModuleItemTag, &bv_count, &bvs ));
	
	printf("\n BV Count: %d\n",bv_count);fflush(stdout);
	
	if(bv_count)
	{
		bv = bvs[0];
		MEM_free(bvs);
	}
	
	
	ifail = ITEM_rev_list_bom_view_revs(archModuleRevTag,&bvr_count, &bvrs);
	
	printf("\n BVR Count: %d\n",bvr_count);fflush(stdout);			
	
	if(bvr_count)
	{

		
		bvr = bvrs[0];
		MEM_free(bvrs);
		

	}

	if ( bv != NULLTAG )
	{
		ifail = AOM_unload( bv );					
			
	}				
						

					
	if(bvr != NULLTAG)
	{

		char* arcPlatform = NULL;


		
		CALLAPI(AOM_ask_value_string(archModuleRevTag,"t5_ArchPlatform",&arcPlatform));
		printf("\nSAN:Arch Platform===> [%s]\n",arcPlatform);fflush(stdout);
		
		//Get Child line of Dest Arch Node
		tag_t window = NULLTAG;
		tag_t rule = NULLTAG;
		tag_t top_line = NULLTAG;
		tag_t* child_lines = NULLTAG;
		int nChld = 0;
		//void t5AddStrToSet(int *count,char ***strset,char* str)
		//int childIdCnt = 0;
		//char** childIdList = NULL:
		
		CALLAPI(BOM_create_window (&window));
		CALLAPI(CFM_find( "Latest Working", &rule ));
		CALLAPI(BOM_set_window_config_rule( window, rule ));
		CALLAPI(BOM_set_window_pack_all (window, false));
		CALLAPI(BOM_set_window_top_line (window, NULLTAG,archModuleRevTag, NULLTAG, &top_line));

		if(top_line != NULLTAG)
		{
			int ij = 0;
			int uidType = 0;
			char * ChildUID = NULL;
			int chldFound = 0;
			

			
			int fndidlatest = 0;
			char* vformulaDest = NULL;
			
			char* child_id1 = NULL;
			char* child_rev_seq1 = NULL;
			char child_partNum1[100];
			
			tag_t dest_Child_Line = NULLTAG;
			
			
			CALLAPI(BOM_line_ask_child_lines (top_line, &nChld, &child_lines));
			printf("\nNo of child objects of dest Arc Mod Rev are : %d",nChld);fflush(stdout);
			
			for(ij=0;ij<nChld;ij++)
			{
				
				CALLAPI(BOM_line_ask_attribute_string(child_lines[ij],childId,&child_id1));
				CALLAPI(BOM_line_ask_attribute_string(child_lines[ij],childRevSeq,&child_rev_seq1));
				
				printf("\n child_id1[%s] child_rev_seq1[%s]",child_id1,child_rev_seq1);fflush(stdout);
				
				tc_strcpy(child_partNum1,"");
				tc_strcat(child_partNum1,child_id1);
				tc_strcat(child_partNum1,"_");
				tc_strcat(child_partNum1,child_rev_seq1);
				
				printf("\n child_partNum1[%s]",child_partNum1);fflush(stdout);				
				 
				if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
				if(BOM_line_ask_attribute_string(child_lines[ij], uidType, &ChildUID));
				printf("\n [%d] ChildUID ======>>> %s \n",ij +1, ChildUID);fflush(stdout);
				
				if(BOM_line_ask_attribute_string(child_lines[ij], vfFormId, &vformulaDest));
				printf("\n [%d] vformulaDest ======>>> %s \n",ij +1, vformulaDest);fflush(stdout);
				
				//t5FindStrInSet(*childIdList,*childIdCnt,ChildUID,&chldFound);
				//printf("\nChild found in the set==>%d\n",chldFound);fflush(stdout);
				
				if(tc_strcmp(child_partNum, child_partNum1)==0)
				{
					
					
					
					if(vformulaDest!=NULL)
					{
						if(tc_strcmp(vformulaDest,"")== 0)
						{
						
							dest_Child_Line = child_lines[ij];
							break;
							
						}						
					}
					else
					{
						dest_Child_Line = child_lines[ij];
						break;						
						
					}					
					
/*
					if(vformulaDest!=NULL)
					{
						if(tc_strcmp(vformulaDest,"")== 0)
						{
						
							if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
							if(BOM_line_set_attribute_string(child_lines[ij], fndidlatest,"True"));
							
							if(BOM_line_set_attribute_string(child_lines[ij],vfFormId,sCustomORVF));
							printf("\nSetting VF for child [%s] as %s\n",child_partNum,sCustomORVF);fflush(stdout);
							
							//if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
							if(BOM_line_set_attribute_string(child_lines[ij], fndidlatest,"False"));
							
						}						
					}
					else
					{
							if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
							if(BOM_line_set_attribute_string(child_lines[ij], fndidlatest,"True"));
							
							if(BOM_line_set_attribute_string(child_lines[ij],vfFormId,sCustomORVF));
							printf("\nSetting VF for child [%s] as %s\n",child_partNum,sCustomORVF);fflush(stdout);
							
							//if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
							if(BOM_line_set_attribute_string(child_lines[ij], fndidlatest,"False"));						
						
					}
					*/

							
				}

			}
			/*if(tc_strcmp(child_partNum1,"5442B4Z0160004_NR;1")==0)
			{
				ITK_CALL(STRNG_replace_str(sCustomORVF," & [Teamcenter]'ARMREST TYPE FOR 2ND ROW SEAT' = 'ARMREST WITH CUP HOLDER'","",&sCustomORVF));
				printf("\n 111...Final Variant Formula 5442B4Z0160004_NR;1 is-------> %s\n",sCustomORVF);fflush(stdout);				
			}*/
			if(dest_Child_Line != NULLTAG)
			{
				printf("\n Dest Child line have blank VF.. need to update ......\n");
				if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
				if(BOM_line_set_attribute_string(dest_Child_Line, fndidlatest,"True"));
				
				if(BOM_line_set_attribute_string(dest_Child_Line,vfFormId,sCustomORVF));
				printf("\nSetting VF for dest child [%s] as %s\n",child_partNum,sCustomORVF);fflush(stdout);
				
				//if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
				if(BOM_line_set_attribute_string(dest_Child_Line, fndidlatest,"False"));				
				
			}
			
			
			
			
		}
		
		CALLAPI(BOM_save_window(window));
		CALLAPI(BOM_close_window(window));
		

	

		
	
	}		
	
	
	return ifail;
}




int updateVFofDestModule_bkp(tag_t archModuleRevTag, tag_t child_line, int* childIdCnt, char*** childIdList)
{
	int ifail = ITK_ok;

	int childId = 0;
	int childRevSeq = 0;
	char* child_id = NULL;
	char* child_rev_seq = NULL;
	char child_partNum[100];
	
	int effecId = 0;
	char* effec_id = NULL;
	char* occ_effec = NULL;
	int occEffec = 0;
	int vfFormId = 0;
	char* variant_formula = NULL;
	int findNoId = 0;
	char* find_no = NULL;
	char *sCustomTotalVF= NULL;	
	if (sCustomTotalVF != NULL) { sCustomTotalVF=NULL; }
	sCustomTotalVF=malloc(9000 * sizeof(char));
	
	char *sCustomANDVF= NULL;
	char *sCustomORVF= NULL;

	
	CALLAPI(BOM_line_look_up_attribute("bl_item_item_id",&childId));
	CALLAPI(BOM_line_look_up_attribute("bl_rev_item_revision_id",&childRevSeq));
	CALLAPI(BOM_line_ask_attribute_string(child_line,childId,&child_id));
	CALLAPI(BOM_line_ask_attribute_string(child_line,childRevSeq,&child_rev_seq));
	
	printf("\n child_id[%s] child_rev_seq[%s]",child_id,child_rev_seq);fflush(stdout);
	
	tc_strcpy(child_partNum,"");
	tc_strcat(child_partNum,child_id);
	tc_strcat(child_partNum,"_");
	tc_strcat(child_partNum,child_rev_seq);
	
	printf("\n child_partNum[%s]",child_partNum);fflush(stdout);
	

	
	CALLAPI(BOM_line_look_up_attribute("bl_has_date_effectivity",&effecId));
	CALLAPI(BOM_line_ask_attribute_string(child_line,effecId,&effec_id));
	
	printf("\n Effectivity ID[%s]",effec_id);fflush(stdout);
	
	CALLAPI(BOM_line_look_up_attribute("bl_occ_effectivity",&occEffec));
	CALLAPI(BOM_line_ask_attribute_string(child_line,occEffec,&occ_effec));
	
	printf("\n Effectivity[%s]",occ_effec);fflush(stdout);
	
	CALLAPI(BOM_line_look_up_attribute("bl_formula",&vfFormId));
	CALLAPI(BOM_line_ask_attribute_string(child_line,vfFormId,&variant_formula));
	
	printf("\n variant_formula[%s]",variant_formula);fflush(stdout);
	
	tc_strcpy(sCustomTotalVF,"");
	tc_strcat(sCustomTotalVF,variant_formula);
	printf("\n VFSubStr1 =>%s\n ",sCustomTotalVF);fflush(stdout);
	
	ITK_CALL(STRNG_replace_str(sCustomTotalVF,"AND ([Teamcenter]","& ([Teamcenter]",&sCustomANDVF));
	printf("\n sCustomANDVF-------> %s\n",sCustomANDVF);fflush(stdout);

	ITK_CALL(STRNG_replace_str(sCustomANDVF,"AND [Teamcenter]","& [Teamcenter]",&sCustomANDVF));
	printf("\n sCustomANDVF-------> %s\n",sCustomANDVF);fflush(stdout);

	ITK_CALL(STRNG_replace_str(sCustomANDVF," OR "," | ",&sCustomORVF));
	printf("\n Final Variant Formula is-------> %s\n",sCustomORVF);fflush(stdout);	
	

	//bl_item_object_type
	
	
	//bl_sequence_no
	
	CALLAPI(BOM_line_look_up_attribute("bl_sequence_no",&findNoId));
	CALLAPI(BOM_line_ask_attribute_string(child_line,findNoId,&find_no));
	
	printf("\n find_no[%s]",find_no);fflush(stdout);
	
	//Get Child Item Rev

	tag_t archModuleItemTag = NULLTAG;
	tag_t bv = NULLTAG;
	tag_t bvr = NULLTAG;	
	tag_t childModuleRevTag = NULLTAG;
	tag_t* bvrs = NULLTAG;
	int bvr_count = 0;
	tag_t* bvs = NULLTAG;
	int bv_count = 0;
	
	int objTypeId = 0;
	char* bl_object_Type = NULL;
	
	CALLAPI(BOM_line_look_up_attribute("bl_item_object_type",&objTypeId));
	CALLAPI(BOM_line_ask_attribute_string(child_line,objTypeId,&bl_object_Type));
	
	printf("\n bl_object_Type==>%s\n",bl_object_Type);fflush(stdout);
	

	CALLAPI(getItemRevObj(child_id,child_rev_seq,&childModuleRevTag));
	
	
	
	
	

	if(childModuleRevTag == NULLTAG)
	{
		printf("\n Child Module Rev[%s/%s] not found in PLM. Exiting the program....\n",child_id,child_rev_seq);fflush(stdout);
		return ifail;
	}
	
	printf("\nFound Architecture Module Rev Tag ....\n");fflush(stdout);
	CALLAPI(ITEM_ask_item_of_rev(archModuleRevTag, &archModuleItemTag));
	

	CALLAPI(ITEM_list_bom_views(archModuleItemTag, &bv_count, &bvs ));
	
	printf("\n BV Count: %d\n",bv_count);fflush(stdout);
	
	if(bv_count)
	{
		bv = bvs[0];
		MEM_free(bvs);
	}
	
	
	ifail = ITEM_rev_list_bom_view_revs(archModuleRevTag,&bvr_count, &bvrs);
	
	printf("\n BVR Count: %d\n",bvr_count);fflush(stdout);			
	
	if(bvr_count)
	{

		
		bvr = bvrs[0];
		MEM_free(bvrs);
		

	}

	if ( bv != NULLTAG )
	{
		ifail = AOM_unload( bv );					
			
	}				
						

					
	if(bvr != NULLTAG)
	{

		char* arcPlatform = NULL;


		
		CALLAPI(AOM_ask_value_string(archModuleRevTag,"t5_ArchPlatform",&arcPlatform));
		printf("\nSAN:Arch Platform===> [%s]\n",arcPlatform);fflush(stdout);
		
		//Get Child line of Dest Arch Node
		tag_t window = NULLTAG;
		tag_t rule = NULLTAG;
		tag_t top_line = NULLTAG;
		tag_t* child_lines = NULLTAG;
		int nChld = 0;
		//void t5AddStrToSet(int *count,char ***strset,char* str)
		//int childIdCnt = 0;
		//char** childIdList = NULL:
		
		CALLAPI(BOM_create_window (&window));
		CALLAPI(CFM_find( "Latest Working", &rule ));
		CALLAPI(BOM_set_window_config_rule( window, rule ));
		CALLAPI(BOM_set_window_pack_all (window, false));
		CALLAPI(BOM_set_window_top_line (window, NULLTAG,archModuleRevTag, NULLTAG, &top_line));

		if(top_line != NULLTAG)
		{
			int ij = 0;
			int uidType = 0;
			char * ChildUID = NULL;
			int chldFound = 0;
			

			
			int fndidlatest = 0;
			char* vformulaDest = NULL;
			
			char* child_id1 = NULL;
			char* child_rev_seq1 = NULL;
			char child_partNum1[100];			
			
			CALLAPI(BOM_line_ask_child_lines (top_line, &nChld, &child_lines));
			printf("\nNo of child objects of dest Arc Mod Rev are : %d",nChld);fflush(stdout);
			
			for(ij=0;ij<nChld;ij++)
			{
				
				CALLAPI(BOM_line_ask_attribute_string(child_lines[ij],childId,&child_id1));
				CALLAPI(BOM_line_ask_attribute_string(child_lines[ij],childRevSeq,&child_rev_seq1));
				
				printf("\n child_id1[%s] child_rev_seq1[%s]",child_id1,child_rev_seq1);fflush(stdout);
				
				tc_strcpy(child_partNum1,"");
				tc_strcat(child_partNum1,child_id1);
				tc_strcat(child_partNum1,"_");
				tc_strcat(child_partNum1,child_rev_seq1);
				
				printf("\n child_partNum1[%s]",child_partNum1);fflush(stdout);				
				 
				if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
				if(BOM_line_ask_attribute_string(child_lines[ij], uidType, &ChildUID));
				printf("\n [%d] ChildUID ======>>> %s \n",ij +1, ChildUID);fflush(stdout);
				
				if(BOM_line_ask_attribute_string(child_lines[ij], vfFormId, &vformulaDest));
				printf("\n [%d] vformulaDest ======>>> %s \n",ij +1, vformulaDest);fflush(stdout);
				
				//t5FindStrInSet(*childIdList,*childIdCnt,ChildUID,&chldFound);
				//printf("\nChild found in the set==>%d\n",chldFound);fflush(stdout);
				
				if(tc_strcmp(child_partNum, child_partNum1)==0)
				{

					//if(chldFound == 0)
					{
						//Set the attributes
						
						//Variant Formula
						if(vformulaDest!=NULL)
						{
							if(tc_strcmp(vformulaDest,"")== 0)
							{
							
								if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
								if(BOM_line_set_attribute_string(child_lines[ij], fndidlatest,"True"));
								
								if(BOM_line_set_attribute_string(child_lines[ij],vfFormId,sCustomORVF));
								printf("\nSetting VF for child [%s] as %s\n",child_partNum,sCustomORVF);fflush(stdout);
								
								//if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
								if(BOM_line_set_attribute_string(child_lines[ij], fndidlatest,"False"));
							}						
						}
						else
						{
								if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
								if(BOM_line_set_attribute_string(child_lines[ij], fndidlatest,"True"));
								
								if(BOM_line_set_attribute_string(child_lines[ij],vfFormId,sCustomORVF));
								printf("\nSetting VF for child [%s] as %s\n",child_partNum,sCustomORVF);fflush(stdout);
								
								//if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
								if(BOM_line_set_attribute_string(child_lines[ij], fndidlatest,"False"));						
							
						}

						
						//t5AddStrToSet(childIdCnt, childIdList,ChildUID);
						
					}
					
							
				}

			}
			
		
			
			
			
			
		}
		
		CALLAPI(BOM_save_window(window));
		CALLAPI(BOM_close_window(window));
		

	

		
	
	}		
	
	
	return ifail;
}




int updateVFArchModuleRev(tag_t sourcArcModRevTag, tag_t destArcModRevTag)
{
	int ifail = ITK_ok;
	
	printf("\nInside updateVFArchModuleRev Module......\n");fflush(stdout);
	
	//Get Modules/Occurences of Source Module and add in DestArcModRevTag.
	
	tag_t window = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t top_line = NULLTAG;
	tag_t* child_lines = NULLTAG;
	int nChld = 0;
	ModuleDet* ModuleDetList = NULL;
	int ModuleCnt = 0;
	int childIdCnt = 0;
	char** childIdList = NULL;
	
	CALLAPI(BOM_create_window (&window));
	CALLAPI(CFM_find( "Latest Working", &rule ));
	CALLAPI(BOM_set_window_config_rule( window, rule ));
	CALLAPI(BOM_set_window_pack_all (window, false));
	CALLAPI(BOM_set_window_top_line (window, NULLTAG,sourcArcModRevTag, NULLTAG, &top_line));
	
	if(top_line != NULLTAG)
	{
		//Get BVR of Source Arch Module
		tag_t* bvrs = NULLTAG;
		tag_t bvr = NULLTAG;
		int bvr_count = 0;
		CALLAPI(ITEM_rev_list_bom_view_revs(sourcArcModRevTag, &bvr_count, &bvrs ));
		
		printf("\n BVR Count: %d\n",bvr_count);fflush(stdout);
		
		if(bvr_count > 0)
		{
			bvr = bvrs[0];
		}
		else
		{
			printf("\nNo BOM View Revision found for Sorce Arch Module.. exiting the function....\n");fflush(stdout);
			return ifail;
		}
		
		
		CALLAPI(BOM_line_ask_child_lines (top_line, &nChld, &child_lines));
		printf("\nNo of child objects of source Arc Mod Rev are : %d",nChld);fflush(stdout);
		
		int n_occs = 0;
		tag_t* occsal = NULLTAG;
				

		ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal );

		printf("\nNo of child occurence of source Arc Mod Rev are : %d",n_occs);fflush(stdout);

		//Delete the existing child line items of DestArcModRevTag.
		
		
		if(nChld > 0)
		{
			int i=0;
			tag_t child_line = NULLTAG;
			//ModuleDet moduleDetail;

			for(i=0;i<nChld;i++)
			{
				child_line = child_lines[i];
				
				if(child_line != NULLTAG)
				{

					CALLAPI(updateVFofDestModule(destArcModRevTag,child_line, &childIdCnt, &childIdList));	
				}					

			}
		}
		
	}

	CALLAPI(BOM_close_window(window));
	
	
	return ifail;
}


int removeChildItems(tag_t archModuleRevTag)
{
	int ifail;
	tag_t archModuleItemTag = NULLTAG;
	tag_t* bvs = NULLTAG;
	int bv_count = 0;
	int bvr_count = 0;
	tag_t* bvrs = NULLTAG;
	tag_t bv = NULLTAG;
	tag_t bvr =  NULLTAG;
	
	printf("\nREM: TO-DO - removeChildItems......\n");fflush(stdout);
	
	//printf("\nFound Architecture Module Rev Tag ....\n");fflush(stdout);
	CALLAPI(ITEM_ask_item_of_rev(archModuleRevTag, &archModuleItemTag));

	CALLAPI(ITEM_list_bom_views(archModuleItemTag, &bv_count, &bvs ));
	
	printf("\nREM: BV Count: %d\n",bv_count);fflush(stdout);
	
	if(bv_count)
	{
		bv = bvs[0];
		MEM_free(bvs);
	}

	
	ifail = ITEM_rev_list_bom_view_revs(archModuleRevTag,&bvr_count, &bvrs);
	
	printf("\nREM:BVR Count: %d\n",bvr_count);fflush(stdout);			
	
	if(bvr_count)
	{
		int n_occs = 0;
		tag_t* occs = NULLTAG;
		int i = 0;
		
		bvr = bvrs[0];
		MEM_free(bvrs);
		
		
		ifail = AOM_lock( bvr );
		ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occs );
		
		for (i = 0; i<n_occs; i++)
		{
			ifail = PS_delete_occurrence( bvr, occs[i] );
		}
		ifail = AOM_save( bvr );
		ifail = AOM_unlock( bvr );
		MEM_free(occs);
		
		
	}

	if ( bv != NULLTAG )
	{
		ifail = AOM_unload( bv );					
			
	}				
						
	
	
	
	return ifail;
}



int updateModuleVF(char * archnodeID, int moduleIdCnt,char ** moduleIdList, int moduleRevCnt,char ** moduleRevList,int moduleVfCnt,char ** moduleVfList)
{
	int ifail = ITK_ok;
	
	printf("\n Inside updateModuleVF....\n");fflush(stdout);
	
	
	tag_t ArcModRevTag = NULLTAG;
	
	CALLAPI(getTCObject(archnodeID, "T5_ArchModuleRevision", &ArcModRevTag))
	
	if(ArcModRevTag == NULLTAG )
	{
		printf("\n Arc Module [%s] not found !!!\n",archnodeID);
		return ifail;
	}

	tag_t window = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t top_line = NULLTAG;



	CALLAPI(BOM_create_window (&window));
	CALLAPI(CFM_find( "Latest Working", &rule ));
	CALLAPI(BOM_set_window_config_rule( window, rule ));
	CALLAPI(BOM_set_window_pack_all (window, false));
	CALLAPI(BOM_set_window_top_line (window, NULLTAG,ArcModRevTag, NULLTAG, &top_line));
	
	if(top_line != NULLTAG)
	{
		
		tag_t* child_lines = NULLTAG;
		int nChld = 0;
		int ij=0;
		int childId = 0;
		int childRevSeq = 0;
		char* child_id1 = NULL;
		char* child_rev_seq1 = NULL;
		
		CALLAPI(BOM_line_ask_child_lines (top_line, &nChld, &child_lines));
		printf("\nNo of child objects of  Arc Mod Rev are : %d",nChld);fflush(stdout);
		CALLAPI(BOM_line_look_up_attribute("bl_item_item_id",&childId));
		CALLAPI(BOM_line_look_up_attribute("bl_rev_item_revision_id",&childRevSeq));
		for(ij=0;ij<nChld;ij++)
		{
			CALLAPI(BOM_line_ask_attribute_string(child_lines[ij],childId,&child_id1));
			CALLAPI(BOM_line_ask_attribute_string(child_lines[ij],childRevSeq,&child_rev_seq1));

			printf("\n child_id1[%s] child_rev_seq1[%s]",child_id1,child_rev_seq1);fflush(stdout);
			
			int i=0;
			
			for(i=0; i<moduleIdCnt; i++)
			{
				printf("\n%s;%s==>%s\n",moduleIdList[i],moduleRevList[i],moduleVfList[i]);fflush(stdout);
				
				if(tc_strcmp(child_id1,moduleIdList[i]) ==0 && tc_strcmp(child_rev_seq1,moduleRevList[i])==0)
				{
					//update the VF of this child module.
					char *sCustomTotalVF= NULL;	
					if (sCustomTotalVF != NULL) { sCustomTotalVF=NULL; }
					sCustomTotalVF=malloc(9000 * sizeof(char));
					int fndidlatest = 0;
					int vfFormId = 0;

					char *sCustomANDVF= NULL;
					char *sCustomORVF= NULL;
					printf("\n variant_formula[%s]",moduleVfList[i]);fflush(stdout);

					tc_strcpy(sCustomTotalVF,"");
					tc_strcat(sCustomTotalVF,moduleVfList[i]);
					printf("\n VFSubStr1 =>%s\n ",sCustomTotalVF);fflush(stdout);

					ITK_CALL(STRNG_replace_str(sCustomTotalVF,"AND ([Teamcenter]","& ([Teamcenter]",&sCustomANDVF));
					printf("\n sCustomANDVF-------> %s\n",sCustomANDVF);fflush(stdout);

					ITK_CALL(STRNG_replace_str(sCustomANDVF,"AND [Teamcenter]","& [Teamcenter]",&sCustomANDVF));
					printf("\n sCustomANDVF-------> %s\n",sCustomANDVF);fflush(stdout);

					ITK_CALL(STRNG_replace_str(sCustomANDVF," OR "," | ",&sCustomORVF));
					
					printf("\n Final Variant Formula is-------> %s\n",sCustomORVF);fflush(stdout);					
									
					printf("\n Updating VF  ......\n");
					if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
					if(BOM_line_set_attribute_string(child_lines[ij], fndidlatest,"True"));
					
					CALLAPI(BOM_line_look_up_attribute("bl_formula",&vfFormId));

					if(BOM_line_set_attribute_string(child_lines[ij],vfFormId,sCustomORVF));
					printf("\nSetting VF for dest child [%s;%s] as %s\n",moduleIdList[i],moduleRevList[i],sCustomORVF);fflush(stdout);

					//if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
					if(BOM_line_set_attribute_string(child_lines[ij], fndidlatest,"False"));					
					
					
					
					free(sCustomTotalVF);
					
				}
				
				
			}			
			
		}
	
	
	}
	
	CALLAPI(BOM_save_window(window));
	CALLAPI(BOM_close_window(window));

	
	return ifail;
}

int ITK_user_main(int argc, char* argv[])
{
	
	
	int ifail = ITK_ok;

	char			Data[100]					= "";
	
	char 			*test						= (char*)MEM_alloc(sizeof(char) * 50);
	char			outputFile[200]				= "";
	
	ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
	
	
	printf("\n SAN:updateVf: *********** Start Of Main function ************* \n");fflush(stdout);	
	
	if(ITK_auto_login() == ITK_ok)	
	{
		/***** Start Variable Declarations************/
		ifail = ITK_ok;
		tag_t user_tag = NULLTAG;
		char* username = NULL;		
		int ii = 0;
		int n_children = 0;		
		char *filepath = ITK_ask_cli_argument("-f=");		
		FILE * fp = NULL;

		char* moduleId = (char*)MEM_alloc(sizeof(char) * 100);
		char* moduleRev = (char*)MEM_alloc(sizeof(char) * 100);
		char* moduleSeq = (char*)MEM_alloc(sizeof(char) * 100);
		char* dsgnGrp = (char*)MEM_alloc(sizeof(char) * 100);

		char		*sep				= "_";
		int get_latest_rev(char*,char*,char*,char*);

		/***** End Variable Declarations************/
		
		ITK_set_journalling( TRUE );
		printf("\nSAN:updateVf: Login successfull.\n");fflush(stdout);			
		
		POM_get_user(&username,&user_tag);
		printf("\nSession User Name[%s]\n",username);fflush(stdout);
		
		printf("\nInput Parameters:Input File:[%s]\n",filepath);fflush(stdout);

		time_t 	now;
		struct 	tm when;		
		time(&now);
		when = *localtime(&now);
		
		strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
		sprintf(outputFile,"%s_output.csv",Data);	
		
		output = fopen(outputFile,"w");
		if (output == NULL)
		{
			printf("ERROR: Cannot open File\n");
			return -1;
		}
		else
		{
			fprintf(output,"TCE_Part_Number,TCE_Rev,TCE_Seq,TCUA_Part_Number,TCUA_Rev,TCUA_Seq,UA_Create_Date,UA_Last_Update,Design_Group,Status\n");
			printf("outputFile File opened successfully.\n");fflush(stdout);
		}

		fp = fopen(filepath, "r");		

		if(fp==NULL)
		{
			printf("\nCould not open the file %s. Kindly check.\n",filepath);fflush(stdout);
		}
		else
		{
			char buffer[MAX_LINE_LEN] ="";			
			int k = 0;
			while(fgets(buffer, MAX_LINE_LEN,fp)!= NULL)
			{
				//printf("\nTest 8"); fflush(stdout);
				moduleId = strtok(buffer,";");
				moduleRev = strtok(NULL,";");
				moduleSeq = strtok(NULL,";");
				dsgnGrp = strtok(NULL,";");
								
				printf("\n%s --- %s --- %s --- %s \n",moduleId,moduleRev,moduleSeq,dsgnGrp);fflush(stdout);

				ifail = get_latest_rev(moduleId,moduleRev,moduleSeq,dsgnGrp);			
				//printf("\nTest 9"); fflush(stdout);
			}			
			
		}		

	}
	else
	{
		printf("\nLogin Failed!\n\n");
	}	
	
	printf("\n *********** End Of Main function ************* \n");fflush(stdout);
	ITK_exit_module(TRUE);
	return ITK_ok;
}

//Ujjawal

int get_latest_rev(char* moduleId, char* moduleRev, char* moduleSeq, char* dsgnGrp)
{
	int				ifail 						= ITK_ok;
	int				z 							= 0;	
	tag_t			item_tag 					= NULLTAG;
	tag_t			rev_tag						= NULLTAG;
	char 			*rev_id						= NULL;
	char 			*obj_type					= NULL;
	char 			*seq_id 					= NULL;
	char 			*obj_id						= NULL;
	char 			*cre_date 					= NULL;
	char 			*lastmodified_date			= NULL;
	printf("\nIn function get_latest_rev\n");fflush(stdout);
	//query logic
	tag_t   qryTag		= NULLTAG;
	int     n_entry		= 2;
	int     rsltCount	= 0;
	char    *qry_entry[2]  = {"Item ID", "Release Status"};
	tag_t   *revTag   = NULLTAG;
	tag_t   folder_tag   = NULLTAG;
	char    **qry_values2     =  (char **) MEM_alloc(50 * sizeof(char *));
	char 	*test2 				= (char*)MEM_alloc(sizeof(char) * 200);
	char	*final2				= (char*)MEM_alloc(sizeof(char) * 200);
	char* actRev = NULL;
	char* actSeq = NULL;
	
	if(QRY_find("Latest Item Revision...", &qryTag));
		if (qryTag)
		{
			//printf("\n CREVali:Found Query Latest Item Revision... \n");fflush(stdout);
		}
		else
		{
			//printf("\n CREVali:Not Found Query Latest Item Revision... \n");fflush(stdout);
		}

		//printf("\n Inside function get_latest_rev(): Incoming moduleID : %s\n",moduleId);fflush(stdout);

		qry_values2[0] = moduleId;
		qry_values2[1] = "T5_LcsErcRlzd";

		if(QRY_execute(qryTag, 2, qry_entry, qry_values2, &rsltCount, &revTag));
		
		printf(" \n CREVali:rsltCount:%d:", rsltCount); fflush(stdout);
		
		if (rsltCount>0)
		{
			//for (z=0;z<rsltCount;z++)
			//{
				ifail = AOM_ask_value_string (revTag[0], "item_id", &obj_id);
				//printf("\n object_string is:::%s",obj_id); fflush(stdout);

				ifail = AOM_UIF_ask_value (revTag[0], "item_revision_id", &rev_id);
				//printf("\n item_revision_id is:%s",rev_id); fflush(stdout);

				actRev = strtok(rev_id,";");
				actSeq =strtok(NULL,";");

				ifail = AOM_UIF_ask_value (revTag[0], "t5_PartType", &obj_type);
				//printf("\n obj_type is:::%s",obj_type); fflush(stdout);

				ifail = AOM_ask_value_string (revTag[0], "sequence_id", &seq_id);
				//printf("\n seq_id is:::%s",seq_id); fflush(stdout);

				//Creation Date creation_date
			    ifail = AOM_UIF_ask_value (revTag[0], "creation_date", &cre_date);
				//printf("\n creation_date is:::%s",cre_date); fflush(stdout);

				//Date Modified last_mod_date 
				ifail = AOM_UIF_ask_value (revTag[0], "last_mod_date", &lastmodified_date);
				//printf("\n last_mod_date is:::%s",lastmodified_date);  fflush(stdout);
			
				//printf("\nTest 1"); fflush(stdout);
				tc_strcpy(test2,"");
				tc_strcat(test2,moduleId);
				tc_strcat(test2,",");
				tc_strcat(test2,moduleRev);
				tc_strcat(test2,",");
				tc_strcat(test2,moduleSeq);
				tc_strcat(test2,",");
				tc_strcat(test2,obj_id);
				tc_strcat(test2,",");
				tc_strcat(test2,actRev);
				tc_strcat(test2,",");
				tc_strcat(test2,actSeq);
				tc_strcat(test2,",");
				tc_strcat(test2,cre_date);
				tc_strcat(test2,",");
				tc_strcat(test2,lastmodified_date);
				tc_strcat(test2,",");
				tc_strcat(test2,dsgnGrp);
				//tc_strcat(test2,"_");
				//tc_strcat(test2,seq_id);
				//printf("\nTest 2"); fflush(stdout);
				if(tc_strcmp(actRev,moduleRev)==0){
					tc_strcat(test2,",Equal");
					tc_strcpy(final2,test2);
					fprintf(output,"%s\n",final2); fflush(output);
					//printf("\nTest 3"); fflush(stdout);
				}
				else{
					if(tc_strcmp(actRev, "NR")==0 && tc_strcmp(moduleRev, "NR")!=0)
					{
						tc_strcat(test2,",Incremental");
						tc_strcpy(final2,test2);
						fprintf(output,"%s\n",final2); fflush(output);
						//printf("\nTest 4"); fflush(stdout);
					}
					else if(tc_strcmp(actRev, "NR")!=0 && tc_strcmp(moduleRev, "NR")==0)
					{
						tc_strcat(test2,",CVProd_Latest");
						tc_strcpy(final2,test2);
						fprintf(output,"%s\n",final2); fflush(output);

						printf("\nLatest in CVProd. No Need for incremental migration TCE to TCUA : %s",moduleId); fflush(stdout);
					}
					else
					{
						if(tc_strcmp(actRev, moduleRev) > 0)
						{
							tc_strcat(test2,",CVProd_Latest");
							tc_strcpy(final2,test2);
							fprintf(output,"%s\n",final2); fflush(output);

							printf("\nLatest in CVProd. No Need for incremental migration TCE to TCUA : %s",moduleId); fflush(stdout);
						}
						else
						{
							tc_strcat(test2,",Incremental");
							tc_strcpy(final2,test2);
							fprintf(output,"%s\n",final2); fflush(output);
							//printf("\nTest 5"); fflush(stdout);
						}
					}
				}
				
				
			//}
			
		}
		else{
			tc_strcpy(test2,"");
			tc_strcat(test2,moduleId);
			tc_strcat(test2,",");
			tc_strcat(test2,moduleRev);
			tc_strcat(test2,",");
			tc_strcat(test2,moduleSeq);
			tc_strcat(test2,",-,-,-,-,-,");
			tc_strcat(test2,dsgnGrp);
			tc_strcat(test2,",New");
			tc_strcpy(final2,test2);
			fprintf(output,"%s\n",final2); fflush(output);
			//printf("\nTest 6"); fflush(stdout);
		}
		
//		MEM_free(rev_id);
		//MEM_free(test2);
		//MEM_free(final2);
		//printf("\nTest 7"); fflush(stdout);
	return ifail;
}



