/*************************************************************************************************************
* Copyright (c) 2022 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Alokesh Ghosh
*  Module		 :   Check Part Exists in TCUA or not
*  Code			 :   getLatestRevData.c
*  Created on	 :   Dec 21, 2022
*
* Modification History :
* S.No		Date		CR No	Modified By            Modification Notes
*			
*************************************************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/aom_prop.h>
#include <ae/dataset.h>

#define MAX_LINE_LEN 10024
#define Debug TRUE
#define ITK_CALL(X)  	\
		if(Debug) \
		{ \
			printf(#X); 	\
		} \
		fflush(NULL); 	\
		status=X;  \
		if (status != ITK_ok )  \
		{ \
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
 \
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails); 	\
			for( index=0; index<n_ifails; index++) 	\
			{  \
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}  \
			return status; 	\
		}  \
		else \
		{ \
			if(Debug) 	\
			printf("\tSUCCESS\n");				\
		} \

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

//Ujjawal - (For Global Variables)
FILE 		*output 			= NULL;
FILE 		*notInCVProd 	= NULL;

int get_latest_rev(char* moduleId, char* moduleRev, char* moduleSeq, char* level)
{
	int				ifail 						= ITK_ok;
	int				z 							= 0;	
	tag_t			item_tag 					= NULLTAG;
	tag_t			rev_tag						= NULLTAG;
	char 			*rev_id						= NULL;
	char 			*obj_type					= NULL;
	char 			*seq_id 					= NULL;
	char 			*obj_id						= NULL;
	char 			*cre_date 					= NULL;
	char 			*lastmodified_date			= NULL;

	//query logic
	tag_t   qryTag		= NULLTAG;
	int     n_entry		= 3;
	int     rsltCount	= 0;
	char    *qry_entry[3]  = {"Item ID", "Revision", "Release Status"};
	tag_t   *revTag   = NULLTAG;
	tag_t   folder_tag   = NULLTAG;
	char    **qry_values2     =  (char **) MEM_alloc(100 * sizeof(char *));
	char 	*test2 				= (char*)MEM_alloc(sizeof(char) * 100);
	//char 	*revision 				= (char*)MEM_alloc(sizeof(char) * 100);
	char *revision = NULL;
	revision = (char	*)MEM_alloc(100);
	char* actRev = NULL;
	char* actSeq = NULL;
	char* highRev = (char*)MEM_alloc(sizeof(char) * 20);
	char* highSeq = (char*)MEM_alloc(sizeof(char) * 20);
	int highestPos = 0;

	tc_strcpy(revision, moduleRev);
	tc_strcat(revision, ";");
	tc_strcat(revision, moduleSeq);
		
	//printf(" \n CREVali:rsltCount:%d:", rsltCount); fflush(stdout);
	//if(tc_strcmp(level, "0")==0 || tc_strcmp(level, "1")==0)
	if(tc_strcmp(level, "0")==0)
	{
		printf("\nLevel 0 Level Skip"); fflush(stdout);
		fprintf(notInCVProd,"%s,\n",moduleId);
	}
	else
	{
		if(QRY_find2("Item Revision...", &qryTag));
		if (qryTag)
		{
			printf("\n CREVali:Found Query Latest Item Revision... \n");fflush(stdout);
		}
		else
		{
			//printf("\n CREVali:Not Found Query Latest Item Revision... \n");fflush(stdout);
		}

		//printf("\n Inside function get_latest_rev(): Incoming moduleID : %s\n",moduleId);fflush(stdout);

		qry_values2[0] = moduleId;
		qry_values2[1] = revision;
		qry_values2[2] = "T5_LcsErcRlzd";
		printf("\nPart --> %s Revision --> %s... Status --> %s",qry_values2[0],qry_values2[1],qry_values2[2]); fflush(stdout);

		if(QRY_execute(qryTag, 2, qry_entry, qry_values2, &rsltCount, &revTag));
		int partStatus = 0;
		int error_stat = 0;
		if (rsltCount>0)
		{
			ifail = AOM_UIF_ask_value (revTag[0], "item_revision_id", &rev_id);
			printf("\n item_revision_id is:%s",rev_id); fflush(stdout);
			highRev = strtok(rev_id,";");
			highSeq = strtok(NULL,";");
			highestPos = 0;

			for (z=1;z<rsltCount;z++)
			{
				ifail = AOM_UIF_ask_value (revTag[z], "item_revision_id", &rev_id);
				printf("\n item_revision_id is:%s",rev_id); fflush(stdout);
				actRev = strtok(rev_id,";");
				actSeq =strtok(NULL,";");

				if(tc_strcmp(highRev, "NR")==0 && tc_strcmp(actRev, "NR")!=0)
				{
					//This is high
					tc_strcpy(highRev, actRev);
					tc_strcpy(highSeq, actSeq);
					highestPos = z;
				}
				else if(tc_strcmp(highRev, "NR")!=0 && tc_strcmp(actRev, "NR")==0)
				{
					//Previous Value is Highest
					continue;
				}
				else if(tc_strcmp(highRev, actRev) > 0)
				{
					//Previous Value is Highest
					continue;
				}
				else
				{
					tc_strcpy(highRev, actRev);
					tc_strcpy(highSeq, actSeq);
					highestPos = z;
				}
			}

			tag_t relation_type = NULLTAG;
			tag_t *attachments = NULLTAG;
			int cnt = 0;
			int ij = 0;
			tag_t dataset = NULLTAG;
			char *ObjectClassType = NULL;
			char *ObjectName = NULL;
			ifail = (GRM_list_secondary_objects_only(revTag[highestPos],relation_type,&cnt,&attachments));
			for(ij=0;ij<cnt;ij++)
	        {
	        	dataset = attachments[ij];
		        ifail = (AOM_ask_value_string(dataset,"object_type",&ObjectClassType));
		        printf("\n\n ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

		        ifail = (AOM_ask_value_string(dataset,"object_name",&ObjectName));
                printf("\n\n object_name :%s\n",ObjectName);fflush(stdout);

                //if (strcmp(ObjectClassType,"DirectModel")==0 || strcmp(ObjectClassType,"ProPrt")==0 || strcmp(ObjectClassType,"ProDrw")==0)
                if ((strcmp(ObjectClassType,"ProPrt")==0) || (strcmp(ObjectClassType,"ProAsm")==0))
	        	{
	        		int cntProAsm =0;
	        		int DtNmRefCnt = 0;
	        		tag_t * DtNmRefObjs = NULLTAG;
	        		tag_t * attachmentsProAsm = NULLTAG;
					tag_t IPEMRelTag = NULLTAG;
					tag_t tRelationFind = NULLTAG;
					ifail = (GRM_find_relation_type("Pro2_membership", & IPEMRelTag));
					ifail = (GRM_find_relation_type("IPEM_master_dependency",&tRelationFind));
					if (tc_strcmp(ObjectClassType, "ProAsm") == 0)
		            {
		            	ifail = (GRM_list_secondary_objects_only(dataset, IPEMRelTag, & cntProAsm, & attachmentsProAsm));
		            	if (cntProAsm < 1)
		            	{
		            		error_stat = 1;
	        				break;
		            	}
		            	else
		            	{
		            		tag_t tWindow1 = NULLTAG;
							tag_t rule1 = NULLTAG;
							tag_t tBOMLine = NULLTAG;
							int iNumber_Child = 0;
							tag_t* tBOM_Children = NULLTAG;
							ifail = (BOM_create_window( &tWindow1));
							ifail = (CFM_find( "Latest Working", &rule1 ));
							ifail = (BOM_set_window_config_rule(tWindow1, rule1 ));
							ifail = (BOM_set_window_top_line( tWindow1, NULLTAG, revTag[highestPos], NULLTAG, &tBOMLine));
							ifail = (BOM_line_ask_all_child_lines(tBOMLine, &iNumber_Child, &tBOM_Children));
							if(iNumber_Child < 1)
					        {
					        	error_stat = 1;
	        					break;
							}
							else
							{
								partStatus = 1;
		            			break;
							}
							tBOM_Children = NULLTAG;
							ifail = (BOM_close_window(tWindow1));
		            	}
		            }
		            else if (tc_strcmp(ObjectClassType, "ProPrt") == 0)
		            {
		            	ifail = (AE_ask_dataset_named_refs(dataset,&DtNmRefCnt, &DtNmRefObjs));
		            	if (DtNmRefCnt < 1)
		            	{
			            	ifail = (GRM_list_secondary_objects_only(dataset, tRelationFind, & cntProAsm, & attachmentsProAsm));
			            	if (cntProAsm < 1)
			            	{
			            		error_stat = 1;
		        				break;
			            	}
			            	else
			            	{
			            		partStatus = 1;
			            		break;
			            	}
			            }
			            else
			            {
			            	partStatus = 1;
			            	break;
			            }
		            }
	        	}
	        	if ((strcmp(ObjectClassType,"ProDrw")==0) || (strcmp(ObjectClassType,"CMI2Part")==0) || (strcmp(ObjectClassType,"CMI2Product")==0) || (strcmp(ObjectClassType,"CMI2Drawing")==0))
	        	{
	        		partStatus = 1;
	        	}
	        }
	    }
	    if(partStatus == 1 && error_stat==0)
	    {
			ifail = AOM_ask_value_string (revTag[highestPos], "item_id", &obj_id);
			printf("\n object_string is:::%s",obj_id); fflush(stdout);

			ifail = AOM_UIF_ask_value (revTag[highestPos], "item_revision_id", &rev_id);
			printf("\n item_revision_id is:%s",rev_id); fflush(stdout);

			actRev = strtok(rev_id,";");
			actSeq =strtok(NULL,";");

			ifail = AOM_UIF_ask_value (revTag[highestPos], "t5_PartType", &obj_type);
			printf("\n obj_type is:::%s",obj_type); fflush(stdout);

			ifail = AOM_ask_value_string (revTag[highestPos], "sequence_id", &seq_id);
			printf("\n seq_id is:::%s",seq_id); fflush(stdout);

			//Creation Date creation_date
		    ifail = AOM_UIF_ask_value (revTag[highestPos], "creation_date", &cre_date);
			printf("\n creation_date is:::%s",cre_date); fflush(stdout);

			//Date Modified last_mod_date 
			ifail = AOM_UIF_ask_value (revTag[highestPos], "last_mod_date", &lastmodified_date);
			printf("\n last_mod_date is:::%s",lastmodified_date); fflush(stdout);
		
			tc_strcpy(test2,"");
			tc_strcat(test2,moduleId);
			tc_strcat(test2,",");
			tc_strcat(test2,moduleRev);
			tc_strcat(test2,",");
			tc_strcat(test2,moduleSeq);
			tc_strcat(test2,",");
			tc_strcat(test2,obj_id);
			tc_strcat(test2,",");
			tc_strcat(test2,actRev);
			tc_strcat(test2,",");
			tc_strcat(test2,actSeq);
			tc_strcat(test2,",");
			tc_strcat(test2,cre_date);
			tc_strcat(test2,",");
			tc_strcat(test2,lastmodified_date);
			tc_strcat(test2,",");
			tc_strcat(test2,level);
			
			fprintf(output,"%s\n",test2);
			printf("\nEnd of Write"); fflush(stdout);
			
		}
		else{
			printf("\nPart No not found in CVProd"); fflush(stdout);
			fprintf(notInCVProd,"%s,\n",moduleId);
		}
	}
	printf("\nEnd of Function"); fflush(stdout);
//		MEM_free(rev_id);
	//MEM_free(test2);
	//MEM_free(revision);
		
	return ifail;
}

int ITK_user_main(int argc, char* argv[])
{
	
	
	int ifail = ITK_ok;

	char			Data[100]					= "";
	
	char 			*test						= (char*)MEM_alloc(sizeof(char) * 50);
	char			outputFile[200]				= "";
	char			notInCVProdFileNm[200]				= "";
	
	ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
	
	
	printf("\n SAN:updateVf: *********** Start Of Main function ************* \n");fflush(stdout);	
	
	if(ITK_auto_login() == ITK_ok)	
	{
		/***** Start Variable Declarations************/
		ifail = ITK_ok;
		tag_t user_tag = NULLTAG;
		char* username = NULL;		
		int ii = 0;
		int n_children = 0;		
		char *filepath = ITK_ask_cli_argument("-f=");		
		FILE * fp = NULL;

		char		*sep				= "_";
		int get_latest_rev(char*,char*,char*,char*);

		/***** End Variable Declarations************/
		
		ITK_set_journalling( TRUE );
		printf("\nSAN:updateVf: Login successfull.\n");fflush(stdout);			
		
		POM_get_user(&username,&user_tag);
		printf("\nSAN:Session User Name[%s]\n",username);fflush(stdout);
		
		printf("\nSAN:Input Parameters:Input File:[%s]\n",filepath);fflush(stdout);
		
		/*Query the Parent - Architecture Module Revision */
		//int moduleIdCnt = 0;
		//char** moduleIdList = NULL;
		//int moduleRevCnt = 0;
		//char** moduleRevList = NULL;
		//int moduleVfCnt = 0;
		//char** moduleVfList = NULL;

		time_t 	now;
		struct 	tm when;		
		time(&now);
		when = *localtime(&now);
		
		//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
		//sprintf(outputFile,"%s_skipped_parts.csv",Data);
		sprintf(outputFile,"skipped_%s",filepath);
				
		//if(tc_strlen(stripBlanks(parttype)) == 0)
		//{
		//	print_requirement();
		//	return -1;
		//}		
		
		output = fopen(outputFile,"w");
		if (output == NULL)
		{
			printf("ERROR: Cannot open File\n");
			return -1;
		}
		else
		{
			fprintf(output,"TCE_Part_Number,TCE_Rev,TCE_Seq,TCUA_Part_Number,TCUA_Rev,TCUA_Seq,UA_Create_Date,UA_Last_Update,Level\n");
			printf("outputFile File opened successfully.\n");
		}

		sprintf(notInCVProdFileNm,"notInCVProd_%s",filepath);

		notInCVProd = fopen(notInCVProdFileNm,"w");
		if (notInCVProd == NULL)
		{
			printf("ERROR: Cannot open File\n");
			return -1;
		}
		else
		{
				printf("notInCVProd File opened successfully.\n");
		}
			
		//fprintf(output,"%s\n",test);
		//MEM_free(test);

		//Open file to read input.

		char* destination = NULL;
		destination = (char *)MEM_alloc(100);

		fp = fopen(filepath, "r");		

		if(fp==NULL)
		{
			printf("\nCould not open the file %s. Kindly check.\n",filepath);fflush(stdout);
		}
		else
		{
			char buffer[MAX_LINE_LEN] ="";			
			int k = 0;
			
			while(fgets(buffer, MAX_LINE_LEN,fp)!= NULL)
			{
				printf("\nStart of Part form Main"); fflush(stdout);
				char* level = NULL;
				char* moduleId = NULL;
				char* moduleRev = NULL;
				char* moduleSeq = NULL;
				char* prntPrt = NULL;
				prntPrt = strtok(buffer,";");
				level   = strtok(NULL,";");
				moduleId = strtok(NULL,";");
				moduleRev =strtok(NULL,";");
				moduleSeq =strtok(NULL,";");
				tc_strcpy(destination,"");
				STRNG_clean_up_string(moduleSeq);
				STRNG_replace_str(moduleSeq,"_","",&destination);
				tc_strcpy(moduleSeq,destination);

				printf("\n%s ; %s====>%s... [%s]\n",moduleId,moduleRev,moduleSeq,level);fflush(stdout);

				//ifail = read_value_from_file(Filename);
				
				//Calling function to get latest details.

				ifail = get_latest_rev(moduleId,moduleRev,moduleSeq,level);
				printf("\nEnd of Part form Main"); fflush(stdout);		
				
			}			
			
		}
		//MEM_free(destination);

	}
	else
	{
		printf("\nLogin Failed!\n\n");
	}	
	
	printf("\n *********** End Of Main function ************* \n");fflush(stdout);
	ITK_exit_module(TRUE);
	return ITK_ok;
}

