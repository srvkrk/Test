#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <bom/bom.h>
#include <bom/bom_attr.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <stdio.h>
#include <string.h>
#include <tc/folder.h>
#include <tccore/aom_prop.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/uom.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#define ITK_err 910001
int ifail = 0;
int childCount = 0;
//int processedChild = 0;
int finalAttach = 0;
int BomExpansionLimit = 0;
tag_t* ALFPartLines = NULLTAG;
int alflinesCnt = 0;
tag_t window = NULLTAG;
static void initialise (void);
static void initialise_attribute (char *name,  int *attribute);
//static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
static void Get_unpack_bom (tag_t bom_line_tag, tag_t line1, int depth, int processedChild, tag_t AlfDataSet_tag, char *ChildPart[], char *AlfJTFile[], char *ChildFeatureID[], char *ChildPosMat[], int StoreStatus);
static void expand_bom_line (tag_t bom_line_tag, tag_t line1, int depth, tag_t AlfDataSet_tag, char *ChildPart[], char *AlfJTFile[], char *ChildFeatureID[], char *ChildPosMat[]);
static void attach_alf_bom (tag_t bom_line_tag, tag_t line1, int depth, tag_t AlfDataSet_tag, char *ChildPart[], char *AlfJTFile[], char *ChildFeatureID[], char *ChildPosMat[], int removeOtherAlf);
static void remove_alf_bom (tag_t bom_line_tag, tag_t line1, int depth, tag_t AlfDataSet_tag, char *ChildPart[], char *AlfJTFile[], char *ChildFeatureID[], char *ChildPosMat[], int removeOtherAlf);
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
int ITK_CALL(int ifail)
{
	char* cError = NULL;
    if(ifail!=ITK_ok)
	{
	  EMH_ask_error_text(ifail, &cError);
	  printf("\n Error is : %s", cError);fflush(stdout);
	  exit(0);
	}
	return ifail;
}

/*static void initialise (void)
{
	// these tokens come from bom_attr.h
	initialise_attribute (bomAttr_lineName, &name_attribute); //bl_line_name
	initialise_attribute (bomAttr_occSeqNo, &seqno_attribute); //bl_sequence_no
	ifail = BOM_line_look_up_attribute (bomAttr_lineParentTag, &parent_attribute);
	CHECK_FAIL;
	ifail = BOM_line_look_up_attribute (bomAttr_lineItemTag, &item_tag_attribute); 
	CHECK_FAIL;
}

static void initialise_attribute (char *name,  int *attribute)
{
	int mode;
	ifail = BOM_line_look_up_attribute (name, attribute);
	CHECK_FAIL;
	ifail = BOM_line_ask_attribute_mode (*attribute, &mode);
	CHECK_FAIL;
	
	if (mode != BOM_attribute_mode_string)
	{	
		printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode); fflush(stdout);
		exit(0);
	}
}*/

int ITK_user_main(int argc, char* argv[])
{
    char* cError = NULL;
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		EMH_ask_error_text(ifail, &cError);
		printf("\nError is : %s", cError);fflush(stdout);
		exit(0);
	}

	FILE *fp;
	char* inputfile = NULL;
	char *inputline = NULL;
	//initialise();
	inputfile = ITK_ask_cli_argument("-i=");
	if ( !inputfile )
    {
        printf("Must supply the \"-i\" option on command line to ITK executable....\n"); fflush(stdout);
        exit(0);
    }
	fp=fopen(inputfile,"r");
	if(fp!=NULL)
	{
		char *cEntries[2]  = {"Item ID","Revision"};
		char *qry_entries_d[2] = {"Name","Type"};
		char **cValues = (char **) MEM_alloc(2 * sizeof(char *));
		char **qry_values_d = (char **) MEM_alloc(2 * sizeof(char *));
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fp)!=NULL)
		{
			printf("\n\n Line: %s",inputline); fflush(stdout);
			tag_t rule, item_tag = NULLTAG, top_line;
			childCount = 0;
			int processedChild = 0;
			finalAttach = 0;
			BomExpansionLimit = 0;
			alflinesCnt = 0;
			if(ALFPartLines) MEM_free(ALFPartLines);
			ALFPartLines = NULLTAG;
			char **ChildPart = (char **) MEM_alloc(99 * sizeof(char *));
			char **AlfJTFile = (char **) MEM_alloc(99 * sizeof(char *));
			char **ChildFeatureID = (char **) MEM_alloc(99 * sizeof(char *));
			char **ChildPosMat = (char **) MEM_alloc(99 * sizeof(char *));
			char* ParentPartNo = NULL;
			char* ParentPartRev = NULL;
			char* ParentPartSeq = NULL;
			char* DirLoc = NULL;
			ParentPartNo = tc_strtok(inputline,"^");
			ParentPartRev = tc_strtok(NULL,"^");
			ParentPartSeq = tc_strtok(NULL,"^");
			DirLoc = tc_strtok(NULL,"^");
			char *token = tc_strtok(NULL, "^");
			while(token != NULL)
			{
				if (tc_strcmp(token,"")!=0 && tc_strcmp(token,"\n")!=0)
				{
					printf("\nToken: --%s--",token); fflush(stdout);
					ChildPart[childCount] = token;
					AlfJTFile[childCount] = tc_strtok(NULL,"^");
					ChildFeatureID[childCount] = tc_strtok(NULL,"^");
					ChildPosMat[childCount] = tc_strtok(NULL,"^");
					childCount++;
					token = tc_strtok(NULL, "^");
				}
				else
				{
					break;
				}
			}
			printf("\nDepth Level %d",childCount); fflush(stdout);

			char* ALFJTFullPath = (char*)MEM_alloc(500 * sizeof(char));
			printf("\n%s",ChildPart[childCount-1]); fflush(stdout);
			char* ActALFJTName = (char*)MEM_alloc(tc_strlen(AlfJTFile[childCount-1]) * sizeof(char));
			tc_strcpy(ActALFJTName,AlfJTFile[childCount-1]);
			tc_strcpy(ALFJTFullPath,DirLoc);
			tc_strcat(ALFJTFullPath,"/");
			tc_strcat(ALFJTFullPath,AlfJTFile[childCount-1]);
			tag_t queryTag_d = NULLTAG;
			tag_t AlfDataSet_tag = NULLTAG; //ALF JT File Tag
			tag_t JTDt_tag = NULLTAG;
			tag_t datasetTag = NULLTAG;
			tag_t RefObject_d = NULLTAG;
			int resultCount_d = 0;
			int ref_count_d = 0;
			int j = 0;
			tag_t* revtag_d = NULLTAG;
			tag_t* namRefObject_d = NULLTAG;
			char* AlfSearch = (char*)MEM_alloc(100 * sizeof(char));
			char* type_nameAlfDt = NULL;
			char* JTDataItem = NULL;
			char* named_ref2 = NULL;
			AlfSearch = tc_strtok(ActALFJTName,".");
			//tc_strcat(AlfSearch,"*");
			qry_values_d[0] = AlfSearch;
			qry_values_d[1] = "DirectModel" ;
			ITK_CALL(QRY_find2("General...", &queryTag_d));
			ITK_CALL(QRY_execute(queryTag_d, 2, qry_entries_d, qry_values_d, &resultCount_d, &revtag_d));
			printf(".........JT DirectModel Found:[%d] \n\t",resultCount_d);fflush(stdout);
			int DatasetFlag = 0;
			if(resultCount_d > 0)
			{
				for (j=0;j<resultCount_d;j++ )
				{
					JTDt_tag = revtag_d[j];
					ifail = AOM_UIF_ask_value(JTDt_tag,"object_string",&JTDataItem);
					if (ifail != ITK_ok)
					{
						continue;
					}
					if (tc_strstr(JTDataItem,";")!=NULL)
					{
						continue;
					}
					if(TCTYPE_ask_object_type(JTDt_tag,&datasetTag));
					if(TCTYPE_ask_name2(datasetTag,&type_nameAlfDt));
					if (tc_strcmp(type_nameAlfDt,"DirectModel")==0)
					{
						ifail = AE_ask_dataset_named_refs(JTDt_tag,&ref_count_d, &namRefObject_d);
						CHECK_FAIL;
						printf("\n***%d -- %s |||||||||||",ref_count_d,JTDataItem); fflush(stdout);
						if(ref_count_d>0)
						{
							RefObject_d = namRefObject_d[0];
							ifail = AOM_ask_value_string(RefObject_d,"object_string",&named_ref2);
							CHECK_FAIL;
							//printf("\n\t [%d]  jt..item_tag named_ref2:[%s]...AlfJTnameM:[%s] ",j,named_ref2,AlfJTFile[childCount-1]); fflush(stdout);
							if (tc_strcasecmp(named_ref2,AlfJTFile[childCount-1])==0)
							{
								printf(" named_ref:[%s] and JTDataItem:[%s] AlfJTnameM:[%s]",named_ref2,JTDataItem,AlfJTFile[childCount-1]); fflush(stdout);
								DatasetFlag = 1;
								AlfDataSet_tag = JTDt_tag;
								printf("..already present and match found \n\t"); fflush(stdout);
							}
						}
						else
						{
							printf("\nDeleting Blank DataSet"); fflush(stdout);
							char *refname2 = NULL;
							tag_t *refobject2	= NULLTAG;
							int result1 = 0;
							int z = 0;
							printf("\n\tNeed to delete");fflush(stdout);
							ifail = GRM_list_all_related_objects_only(JTDt_tag,&result1,&refobject2);
							CHECK_FAIL;
							printf("\nReleations Count : %d",result1); fflush(stdout);
							for (z = 0; z < result1; ++z)
							{
								ifail = AOM_ask_value_string(refobject2[z],"type_string",&refname2);
								CHECK_FAIL;
								printf("\nDeleting Releation : %d --- %s",z,refname2); fflush(stdout);
								ifail = GRM_delete_relation(refobject2[z]);
								CHECK_FAIL;
							}
							ifail = AOM_refresh(JTDt_tag,1);
							CHECK_FAIL;
							ifail = AOM_delete(JTDt_tag);
							CHECK_FAIL;
						}
					}
				}
				printf("\n\t jt..Dataset Existance Flag:%d \n",DatasetFlag); fflush(stdout);
			}

			if (DatasetFlag == 0)
			{
				tag_t datasettype =NULLTAG;
				tag_t tool =NULLTAG;
				int nameRef_cnt =0;
				tag_t *namRefObject = NULL;
				int ref_count = 0;
				char **ref_list;
				tag_t filetag =  NULLTAG;
				IMF_file_t fileDescriptor;
				AE_reference_type_t tagRefType =  1;
				
				char* JTFileDesc =(char *) MEM_alloc(20);
				strcpy(JTFileDesc,"iPEM Override JT");
				ifail = AE_find_datasettype2("DirectModel", &datasettype);
				printf("\n\t Type found---->%d",ifail);fflush(stdout);
				printf("\n\t Creating New Dataset..."); fflush(stdout);
				char* upperALF = NULL;
				tc_strupr(ActALFJTName, &upperALF);
				ifail = AE_create_dataset_with_id(datasettype,upperALF,JTFileDesc, NULL, NULL, &AlfDataSet_tag);
				printf("\n\t Dataset created for prt --->%s \n\t",upperALF); fflush(stdout);
				ifail = AE_set_dataset_format2(AlfDataSet_tag, "BINARY_REF");
				ifail = AE_set_dataset_tool(AlfDataSet_tag,tool);
				ifail = AE_ask_dataset_named_refs(AlfDataSet_tag,&nameRef_cnt, &namRefObject);
				if (nameRef_cnt == 0)
				{
					ifail = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
					ifail = IMF_import_file(ALFJTFullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
					if (ifail == 41178)
					{
						ifail = IMF_import_file(ALFJTFullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
					}
					printf("\n\t File Imported--->%d",ifail); fflush(stdout);
					//ifail = AOM_refresh(filetag,1);
					ifail = AOM_save_with_extensions(filetag);
					//ifail = AOM_refresh(filetag,0);
					if (IMF_set_original_file_name2(filetag,AlfJTFile[childCount-1])!=ITK_ok);
					//ifail = AOM_refresh(filetag,1);
					ifail = AOM_save_with_extensions(filetag);
					//ifail = AOM_refresh(filetag,0);
					printf("\n\t File saved--->%d",ifail); fflush(stdout);
					ifail = AE_add_dataset_named_ref2(AlfDataSet_tag,ref_list[0],tagRefType,filetag);
					printf("\n\t AE_add_dataset_named_ref--->%d",ifail); fflush(stdout);
					AE_set_dataset_tool(AlfDataSet_tag,tool);
					ifail = AOM_refresh(AlfDataSet_tag,1);
					ifail = AOM_save_without_extensions(AlfDataSet_tag);
					ifail = AOM_refresh(AlfDataSet_tag,0);
					printf("\n\t AOM_save Dataset--->%d",ifail); fflush(stdout);
				}
			}

			if (AlfDataSet_tag == NULLTAG)
			{
				printf("ALF Dataset can't create / not found"); fflush(stdout);
				continue;
			}

			tag_t tItemobj = NULLTAG;
			int n_found = 0;
			int i = 0;
			tag_t* itemobj_results = NULLTAG;
			tag_t ParentTag = NULLTAG;
			int alflvl = 0;
			char *partRevSeqIP = (char *) MEM_alloc(50);
			tc_strcpy(partRevSeqIP, "");
			tc_strcpy(partRevSeqIP, ParentPartRev);
			tc_strcat(partRevSeqIP, ";");
			tc_strcat(partRevSeqIP, ParentPartSeq);
			printf("ParentPartNo-----------> :%s/%s-\n",ParentPartNo,partRevSeqIP);fflush(stdout);						
			cValues[0] = ParentPartNo;
			cValues[1] = partRevSeqIP;	
			ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
			ITK_CALL(QRY_execute(tItemobj, 2, cEntries, cValues, &n_found, &itemobj_results));
			if(n_found>0)
			{
				ParentTag = itemobj_results[0];

				ITK_CALL(BOM_create_window (&window));
			    ITK_CALL(CFM_find( "Latest Working", &rule ));
			    ITK_CALL(BOM_set_window_config_rule( window, rule ));
			    ITK_CALL(BOM_set_window_pack_all (window, FALSE));
				ITK_CALL(BOM_set_window_top_line (window, NULLTAG, ParentTag, NULLTAG, &top_line));
				ITK_CALL(BOM_window_set_absocc_edit_mode(window, TRUE));
				ITK_CALL(BOM_window_set_absocc_context(window, top_line));
				Get_unpack_bom(top_line, NULLTAG, 0, processedChild, AlfDataSet_tag, ChildPart, AlfJTFile, ChildFeatureID, ChildPosMat, 0);
				//expand_bom_line(top_line, NULLTAG, 0, AlfDataSet_tag, ChildPart, AlfJTFile, ChildFeatureID, ChildPosMat);
				if (finalAttach == 0 && alflinesCnt > 0)
				{
					printf("\n------------CREO ProFeatureID not match with AJT Translated Value then attaching to All Occurances\n"); fflush(stdout);
					for (i = 0; i < alflinesCnt; ++i)
					{
						attach_alf_bom (ALFPartLines[i], NULLTAG, 0, AlfDataSet_tag, ChildPart, AlfJTFile, ChildFeatureID, ChildPosMat, 0);
					}
					printf("\n------------FINISH ------ CREO ProFeatureID not match with AJT Translated Value then attached to All Occurances\n"); fflush(stdout);
				}
				if (finalAttach == 1 && alflinesCnt > 0)
				{
					printf("\n------------Removing exact ALF after found of Correct CREO ProFeatureID\n"); fflush(stdout);
					for (i = 0; i < alflinesCnt; ++i)
					{
						remove_alf_bom (ALFPartLines[i], NULLTAG, 0, AlfDataSet_tag, ChildPart, AlfJTFile, ChildFeatureID, ChildPosMat, 0);
					}
					printf("\n------------FINISH ------ Removing exact ALF after found of Correct CREO ProFeatureID\n"); fflush(stdout);
				}
				ITK_CALL(BOM_save_window (window));
				ITK_CALL(BOM_close_window(window));
			}
		}
	}

	ifail = ITK_exit_module(TRUE);
	printf("\nReturn Value is : %d", ifail);
	if (ifail == ITK_ok)
	{
		printf("\nTeamcenter Logout Success...");fflush(stdout);
	}
	else
	{
		EMH_ask_error_text(ifail, &cError);
		printf("\nError is : %s", cError);fflush(stdout);
	}
	return ITK_ok;
}

static void Get_unpack_bom (tag_t bom_line_tag, tag_t line1, int depth, int processedChild, tag_t AlfDataSet_tag, char *ChildPart[], char *AlfJTFile[], char *ChildFeatureID[], char *ChildPosMat[], int StoreStatus)
{
	int i, no_bom_lines , j;
	int level=0, levelP=0;
	int bl_Suppress=0;
	tag_t *child_bom_lines;
	char* ProFeatureID = NULL;
	char* BomLine_name = NULL;
	char* ProFeatureIDP = NULL;
	char* BomLine_nameP = NULL;
	logical bl_Suppress_log;
	depth ++;
	ITK_CALL(AOM_ask_value_int(bom_line_tag,"bl_level_starting_0",&level));
	ITK_CALL(AOM_ask_value_string(bom_line_tag,"bl_item_item_id",&BomLine_name));
	ITK_CALL(AOM_UIF_ask_value(bom_line_tag, "ProFeatureID", &ProFeatureID));
	//ITK_CALL(BOM_line_look_up_attribute ("bl_is_occ_suppressed",&bl_Suppress));
	//ITK_CALL(BOM_line_ask_attribute_logical(bom_line_tag, bl_Suppress, &bl_Suppress_log));
	ITK_CALL(AOM_ask_value_logical(bom_line_tag, "bl_is_occ_suppressed", &bl_Suppress_log));

	BomExpansionLimit ++;

	if (bl_Suppress_log == 0 && BomExpansionLimit < 100000)
	{
		if (line1 != NULLTAG)
		{
			ITK_CALL(AOM_ask_value_int(line1,"bl_level_starting_0",&levelP));
			ITK_CALL(AOM_ask_value_string(line1,"bl_item_item_id",&BomLine_nameP));
			ITK_CALL(AOM_UIF_ask_value(line1, "ProFeatureID", &ProFeatureIDP));
		}

		if (tc_strcasecmp(BomLine_name,ChildPart[processedChild])==0)
		{
			printf("\nL:%d--Item_ID:%s--ProFeatureID:%s \t\t\tParent:L:%d--Item_ID:%s--ProFeatureID:%s",level,BomLine_name,ProFeatureID,levelP,BomLine_nameP,ProFeatureIDP); fflush(stdout);
			if(tc_strcasecmp(ProFeatureID,ChildFeatureID[processedChild])==0)
			{
				if (processedChild == (childCount - 1))
				{
					if (StoreStatus == 0)
					{
						finalAttach++;
						printf("\n\n**********************ATTACH ALF FILE***************\n\n"); fflush(stdout);
						attach_alf_bom (bom_line_tag, NULLTAG, depth, AlfDataSet_tag, ChildPart, AlfJTFile, ChildFeatureID, ChildPosMat, 1);
					}
					else
					{
						printf("\n\n**********************STORE THIS LINE TO ATTACH ALF FILE ALL OCC IF NOT FINALLY FOUND***************\n\n"); fflush(stdout);
						ALFPartLines = (tag_t*)MEM_realloc(ALFPartLines, (alflinesCnt+1) * sizeof(tag_t));
						ALFPartLines[alflinesCnt] = bom_line_tag;
						alflinesCnt++;
					}
				}
				else
				{
					//expand only this line
					processedChild++;
					ifail = BOM_line_ask_child_lines (bom_line_tag, &no_bom_lines, &child_bom_lines); CHECK_FAIL;
					for (j = 0; j < no_bom_lines; j++)
					{
						ifail = BOM_line_unpack (child_bom_lines[j]);
				        CHECK_FAIL;
						Get_unpack_bom (child_bom_lines[j], bom_line_tag, depth, processedChild, AlfDataSet_tag, ChildPart, AlfJTFile, ChildFeatureID, ChildPosMat, StoreStatus);
					}
					if(child_bom_lines) MEM_free (child_bom_lines);
				}
			}
			else
			{
				
				if (processedChild == (childCount - 1))
				{
					printf("\n\n**********************STORE THIS LINE TO ATTACH ALF FILE ALL OCC IF NOT FINALLY FOUND***************\n\n"); fflush(stdout);
					ALFPartLines = (tag_t*)MEM_realloc(ALFPartLines, (alflinesCnt+1) * sizeof(tag_t));
					ALFPartLines[alflinesCnt] = bom_line_tag;
					alflinesCnt++;
				}
				else
				{
					printf("\n\n**********************Expand Multi level for STORE Occrance of final Part in this down line || wil use IF NOT FINALLY FOUND***************\n\n"); fflush(stdout);
					StoreStatus = 1; //Indicates it should store occrance instead of addition of ALF, If finally ALF not found then will attach to all atore occur
					processedChild++;
					ifail = BOM_line_ask_child_lines (bom_line_tag, &no_bom_lines, &child_bom_lines); CHECK_FAIL;
					for (j = 0; j < no_bom_lines; j++)
					{
						ifail = BOM_line_unpack (child_bom_lines[j]);
				        CHECK_FAIL;
						Get_unpack_bom (child_bom_lines[j], bom_line_tag, depth, processedChild, AlfDataSet_tag, ChildPart, AlfJTFile, ChildFeatureID, ChildPosMat, StoreStatus);
					}
					if(child_bom_lines) MEM_free (child_bom_lines);
				}
			}
		}
		else
		{
			//if (finalAttach == 0) //Commented for remove of Other Occurance ALF Files
			//{
				ifail = BOM_line_ask_child_lines (bom_line_tag, &no_bom_lines, &child_bom_lines); CHECK_FAIL;
				for (j = 0; j < no_bom_lines; j++)
				{
					ifail = BOM_line_unpack (child_bom_lines[j]);
			        CHECK_FAIL;
					Get_unpack_bom (child_bom_lines[j], bom_line_tag, depth, processedChild, AlfDataSet_tag, ChildPart, AlfJTFile, ChildFeatureID, ChildPosMat, StoreStatus);
				}
				if(child_bom_lines) MEM_free (child_bom_lines);
			//}
		}
	}
}

/*static void expand_bom_line (tag_t bom_line_tag, tag_t line1, int depth, tag_t AlfDataSet_tag, char *ChildPart[], char *AlfJTFile[], char *ChildFeatureID[], char *ChildPosMat[])
{

	//Temp Add
	int processedChild=0;
	//Temp Add

	char* BomLine_name = NULL;
	char* ProFeatureID = NULL;
	int level0 = 0;
	int i = 0;
	logical bl_Suppress_log;
	int no_bom_lines = 0;
	tag_t* child_bom_lines = NULLTAG;
	char* ChildLineID = NULL;
	char* ChildLineRevSeq = NULL;

	depth ++;
	int bl_Suppress=0;
	ITK_CALL(BOM_line_look_up_attribute ("bl_is_occ_suppressed",&bl_Suppress));
	ITK_CALL(AOM_ask_value_string(bom_line_tag,"bl_item_item_id",&BomLine_name));
	ITK_CALL(AOM_ask_value_int(bom_line_tag,"bl_level_starting_0",&level0));
	ITK_CALL(AOM_UIF_ask_value(bom_line_tag, "ProFeatureID", &ProFeatureID));
	ifail = BOM_line_ask_attribute_logical(bom_line_tag, bl_Suppress, &bl_Suppress_log);
	CHECK_FAIL;
	printf("\n Item: %s | level: [%d] bl_is_occ_suppressed= [%d] | ProFeatureID : [%s]",BomLine_name, level0, bl_Suppress_log,ProFeatureID); fflush(stdout);
	if (bl_Suppress_log == 0)
	{
		if (tc_strcasecmp(ProFeatureID,ChildFeatureID[processedChild])==0 || tc_strcasecmp(BomLine_name,ChildPart[processedChild])==0)
		{
			if (processedChild == (childCount - 1))
			{
				if(tc_strcasecmp(ProFeatureID,ChildFeatureID[processedChild])==0)
				{
					finalAttach++;
					attach_alf_bom (bom_line_tag, NULLTAG, depth, AlfDataSet_tag, ChildPart, AlfJTFile, ChildFeatureID, ChildPosMat, 1);
				}
				else
				{
					ALFPartLines = (tag_t*)MEM_realloc(ALFPartLines, (alflinesCnt+1) * sizeof(tag_t));
					ALFPartLines[alflinesCnt] = bom_line_tag;
					alflinesCnt++;
				}
			}
			else
			{
				//expand only this line
				processedChild++;
				ifail = BOM_line_ask_all_child_lines( bom_line_tag , &no_bom_lines , &child_bom_lines );
				CHECK_FAIL;
				for (i = 0; i < no_bom_lines; i++)
				{
					ifail = BOM_line_unpack (child_bom_lines[i]);
					CHECK_FAIL;
					if( AOM_ask_value_string(child_bom_lines[i],"bl_item_item_id",&ChildLineID)!=ITK_ok);
					if( AOM_ask_value_string(child_bom_lines[i],"bl_rev_item_revision_id",&ChildLineRevSeq)!=ITK_ok);
					ITK_CALL(AOM_UIF_ask_value(bom_line_tag, "ProFeatureID", &ProFeatureID));
					printf("\t\tFeatureID: %s -- %s -- %s",ProFeatureID,ChildFeatureID[processedChild],ChildFeatureID[processedChild-1]); fflush(stdout);
					expand_bom_line (child_bom_lines[i], bom_line_tag, depth, AlfDataSet_tag, ChildPart, AlfJTFile, ChildFeatureID, ChildPosMat);
				}
				if(child_bom_lines) MEM_free (child_bom_lines);
			}
		}
		else
		{
			if (finalAttach == 0)
			{
				ifail = BOM_line_ask_all_child_lines( bom_line_tag , &no_bom_lines , &child_bom_lines );
				CHECK_FAIL;
				for (i = 0; i < no_bom_lines; i++)
				{
					ifail = BOM_line_unpack (child_bom_lines[i]);
					CHECK_FAIL;
					if( AOM_ask_value_string(child_bom_lines[i],"bl_item_item_id",&ChildLineID)!=ITK_ok);
					if( AOM_ask_value_string(child_bom_lines[i],"bl_rev_item_revision_id",&ChildLineRevSeq)!=ITK_ok);
					expand_bom_line (child_bom_lines[i], bom_line_tag, depth, AlfDataSet_tag, ChildPart, AlfJTFile, ChildFeatureID, ChildPosMat);
				}
				if(child_bom_lines) MEM_free (child_bom_lines);
			}
		}
	}
}*/

static void attach_alf_bom (tag_t bom_line_tag, tag_t line1, int depth, tag_t AlfDataSet_tag, char *ChildPart[], char *AlfJTFile[], char *ChildFeatureID[], char *ChildPosMat[], int removeOtherAlf)
{
	AE_reference_type_t reftype;
	tag_t relation_type = NULLTAG;
	tag_t config_rule = NULLTAG;
	tag_t absoccContext = NULLTAG;
	tag_t alf_Relation = NULLTAG;
	tag_t datasetTag = NULLTAG;
	logical absOccEditMode;
	int n_Alfrel_item = 0;
	int j = 0;
	int referencenumberfound = 0;
	char* refname = NULL;
	char* Alforig_name = NULL;
	char* type_nameAlfDt = NULL;
	tag_t* Alfrel_items = NULLTAG;
	tag_t refobject = NULLTAG;
	ifail = GRM_find_relation_type("IMAN_Rendering",&relation_type);
	CHECK_FAIL;
	ifail = BOM_ask_window_config_rule(window,&config_rule);
	ifail = BOM_window_ask_absocc_edit_mode(window,&absOccEditMode);
	ifail = BOM_window_ask_absocc_context(window, &absoccContext);
	CHECK_FAIL;
	if(ifail == ITK_ok)
	{
		printf("\n\t Absolute context is Found\n"); fflush(stdout);
	}
	else
	{
		printf("\n\t ???? Absolute context is not Found......\n"); fflush(stdout);
	}
	if(absoccContext != NULLTAG)
	{
		printf("\n\t BOM_window_ask_absocc_context Found.\n"); fflush(stdout);
	}
	if((absOccEditMode == 1))
	{
		printf("\n\t BOM_window_ask_absocc_edit_mode is on\n"); fflush(stdout);
		int AlfAttachedFlag = 0;
		if (AlfDataSet_tag != NULLTAG)
		{
			ifail = BOM_line_ask_absocc_relation ( bom_line_tag, NULLTAG, "IMAN_Rendering", TRUE, &n_Alfrel_item, &Alfrel_items);
			CHECK_FAIL;
			printf("\t Total BOM_line_ask_absocc_relation n_Alfrel_item: %d\n",n_Alfrel_item); fflush(stdout);
			if (n_Alfrel_item > 0)
			{
				for(j=0;j<n_Alfrel_item;j++)
				{
					printf("\n\t ");
					tag_t datasetAlf = NULLTAG;
					ifail = GRM_ask_secondary (Alfrel_items[j], &datasetAlf);
					CHECK_FAIL;
					if(TCTYPE_ask_object_type(datasetAlf,&datasetTag));
					if(TCTYPE_ask_name2(datasetTag,&type_nameAlfDt));
					if (tc_strcmp(type_nameAlfDt,"DirectModel")==0)
					{
						if(AE_ask_dataset_ref_count(datasetAlf,&referencenumberfound));
						if (referencenumberfound > 0)
						{
							ITK_CALL(AE_find_dataset_named_ref2(datasetAlf,0,&refname,&reftype,&refobject));
							ITK_CALL(IMF_ask_original_file_name2(refobject,&Alforig_name));													
							printf("\n\t %d..Alforig_name is : %s   AlfJTname:%s",childCount,Alforig_name,AlfJTFile[childCount-1]); fflush(stdout);
							if(tc_strcasecmp(AlfJTFile[childCount-1],Alforig_name) == 0)
							{
								printf("\n\n\t ALF is already present in BomLine...\n"); fflush(stdout);
								AlfAttachedFlag = 1;
								//break;
							}
							else
							{
								//Remove other JT
								if (removeOtherAlf == 1)
								{
									char* InputALF = NULL;
									char* AttachedALF = NULL;
									tc_strdup(AlfJTFile[childCount-1],&InputALF);
									tc_strdup(Alforig_name,&AttachedALF);
									char *pos1 = tc_strstr(InputALF, "_ALF");
								    char *pos2 = tc_strstr(AttachedALF, "_ALF");
								    if (pos1 != NULL) {
								        memmove(pos1, pos1 + 5, tc_strlen(pos1 + 5) + 1);
								    }
								    if (pos2 != NULL) {
								        memmove(pos2, pos2 + 5, tc_strlen(pos2 + 5) + 1);
								    }
								    printf("\n\tAfter STRING Operation : %s ---- %s",InputALF,AttachedALF); fflush(stdout);
								    if (tc_strcasecmp(InputALF, AttachedALF)==0)
								    {
								    	printf("\n\tDelete this Relation ....................."); fflush(stdout);
								    	ITK_CALL(BOM_line_remove_absocc_relation(bom_line_tag,NULLTAG,Alfrel_items[j]));
								    	ifail = BOM_save_window( window );
										if(ifail == ITK_ok)
										{
											printf("\n\t BOM_save_window is set\n");
										}
										else
										{
											printf("\n\t ???? BOM_save_window is not set......\n");
										}
								    }
								}
							}
						}
						else
						{
							//Remove other JT
							if (removeOtherAlf == 1)
							{
								printf("\n\tRemove other JT Relation for NO Named reference"); fflush(stdout);
								char* InputALF = NULL;
								char* AttachedALF = NULL;
								tc_strdup(AlfJTFile[childCount-1],&InputALF);
								tc_strdup(Alforig_name,&AttachedALF);
								char *pos1 = tc_strstr(InputALF, "_ALF");
							    char *pos2 = tc_strstr(AttachedALF, "_ALF");
							    if (pos1 != NULL) {
							        memmove(pos1, pos1 + 5, tc_strlen(pos1 + 5) + 1);
							    }
							    if (pos2 != NULL) {
							        memmove(pos2, pos2 + 5, tc_strlen(pos2 + 5) + 1);
							    }
							    printf("\n\tAfter STRING Operation : %s ---- %s",InputALF,AttachedALF); fflush(stdout);
							    if (tc_strcasecmp(InputALF, AttachedALF)==0)
							    {
							    	printf("\n\tDelete this Relation ....................."); fflush(stdout);
							    	ITK_CALL(BOM_line_remove_absocc_relation(bom_line_tag,NULLTAG,Alfrel_items[j]));
							    	ifail = BOM_save_window( window );
									if(ifail == ITK_ok)
									{
										printf("\n\t BOM_save_window is set\n");
									}
									else
									{
										printf("\n\t ???? BOM_save_window is not set......\n");
									}
							    }
							}
						}
					}
				}
			}

			if (AlfAttachedFlag == 0)
			{
				ITK_CALL(BOM_refresh_window(window));
				printf("\n\t AlfAttachedFlag: %d \n\t ",AlfAttachedFlag); fflush(stdout);
				ITK_CALL(BOM_line_add_absocc_relation(bom_line_tag, relation_type, AlfDataSet_tag, &alf_Relation));
				//CHECK_FAIL;
				if (alf_Relation != NULLTAG)
				{
					printf("\n\t ALF relation created\n");
					ifail = BOM_save_window( window );
					CHECK_FAIL;
					if(ifail == ITK_ok)
					{
						printf("\n\t BOM_save_window is set\n");
					}
					else
					{
						printf("\n\t ???? BOM_save_window is not set......\n");
					}
				}
				else
				{
					printf("\n\t ALF relation NOT-CREATED \n\n");
				}
			}
		}
		else
		{
			printf("\n\t ALF-JT dataset tag NOT FOUND..... \n");
		}
	}
	else
	{
		printf("\t BOM_window_ask_absocc_edit_mode is OFF ??\n");
	}
}

static void remove_alf_bom (tag_t bom_line_tag, tag_t line1, int depth, tag_t AlfDataSet_tag, char *ChildPart[], char *AlfJTFile[], char *ChildFeatureID[], char *ChildPosMat[], int removeOtherAlf)
{
	AE_reference_type_t reftype;
	tag_t relation_type = NULLTAG;
	tag_t config_rule = NULLTAG;
	tag_t absoccContext = NULLTAG;
	tag_t alf_Relation = NULLTAG;
	tag_t datasetTag = NULLTAG;
	logical absOccEditMode;
	int n_Alfrel_item = 0;
	int j = 0;
	int referencenumberfound = 0;
	char* refname = NULL;
	char* Alforig_name = NULL;
	char* type_nameAlfDt = NULL;
	tag_t* Alfrel_items = NULLTAG;
	tag_t refobject = NULLTAG;
	ifail = GRM_find_relation_type("IMAN_Rendering",&relation_type);
	CHECK_FAIL;
	ifail = BOM_ask_window_config_rule(window,&config_rule);
	ifail = BOM_window_ask_absocc_edit_mode(window,&absOccEditMode);
	ifail = BOM_window_ask_absocc_context(window, &absoccContext);
	CHECK_FAIL;
	if(ifail == ITK_ok)
	{
		printf("\n\t Absolute context is Found\n"); fflush(stdout);
	}
	else
	{
		printf("\n\t ???? Absolute context is not Found......\n"); fflush(stdout);
	}
	if(absoccContext != NULLTAG)
	{
		printf("\n\t BOM_window_ask_absocc_context Found.\n"); fflush(stdout);
	}
	if((absOccEditMode == 1))
	{
		printf("\n\t BOM_window_ask_absocc_edit_mode is on\n"); fflush(stdout);
		int AlfAttachedFlag = 0;
		if (AlfDataSet_tag != NULLTAG)
		{
			ifail = BOM_line_ask_absocc_relation ( bom_line_tag, NULLTAG, "IMAN_Rendering", TRUE, &n_Alfrel_item, &Alfrel_items);
			CHECK_FAIL;
			printf("\t Total BOM_line_ask_absocc_relation n_Alfrel_item: %d\n",n_Alfrel_item); fflush(stdout);
			if (n_Alfrel_item > 0)
			{
				for(j=0;j<n_Alfrel_item;j++)
				{
					printf("\n\t ");
					tag_t datasetAlf = NULLTAG;
					ifail = GRM_ask_secondary (Alfrel_items[j], &datasetAlf);
					CHECK_FAIL;
					if(TCTYPE_ask_object_type(datasetAlf,&datasetTag));
					if(TCTYPE_ask_name2(datasetTag,&type_nameAlfDt));
					if (tc_strcmp(type_nameAlfDt,"DirectModel")==0)
					{
						if(AE_ask_dataset_ref_count(datasetAlf,&referencenumberfound));
						if (referencenumberfound > 0)
						{
							ITK_CALL(AE_find_dataset_named_ref2(datasetAlf,0,&refname,&reftype,&refobject));
							ITK_CALL(IMF_ask_original_file_name2(refobject,&Alforig_name));													
							printf("\n\t %d..Alforig_name is : %s   AlfJTname:%s",childCount,Alforig_name,AlfJTFile[childCount-1]); fflush(stdout);
							if(tc_strcasecmp(AlfJTFile[childCount-1],Alforig_name) == 0)
							{
								printf("\n\n\tAnother ALF is present in Incorrect BomLine...\n"); fflush(stdout);
						    	printf("\n\tDelete this Relation ....................."); fflush(stdout);
						    	ITK_CALL(BOM_line_remove_absocc_relation(bom_line_tag,NULLTAG,Alfrel_items[j]));
						    	ifail = BOM_save_window( window );
								if(ifail == ITK_ok)
								{
									printf("\n\t BOM_save_window is set\n");
								}
								else
								{
									printf("\n\t ???? BOM_save_window is not set......\n");
								}
							}
						}
						else
						{
							printf("\n\tRemove other JT Relation for NO Named reference"); fflush(stdout);
					    	ITK_CALL(BOM_line_remove_absocc_relation(bom_line_tag,NULLTAG,Alfrel_items[j]));
					    	ifail = BOM_save_window( window );
							if(ifail == ITK_ok)
							{
								printf("\n\t BOM_save_window is set\n");
							}
							else
							{
								printf("\n\t ???? BOM_save_window is not set......\n");
							}
						}
					}
				}
			}
		}
		else
		{
			printf("\n\t ALF-JT dataset tag NOT FOUND..... \n");
		}
	}
	else
	{
		printf("\t BOM_window_ask_absocc_edit_mode is OFF ??\n");
	}
}