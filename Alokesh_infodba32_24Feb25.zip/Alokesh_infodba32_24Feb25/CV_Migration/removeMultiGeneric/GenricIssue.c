/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
*------------------------------------------------------------------------------
* Filename		: autologin.c
* Description	: This Utility Mainly Used For AutoLogin in Teamcenter
* Module       	:	        
* Since		    :    
* ENVIRONMENT	: C++, ITK
* History       :
*------------------------------------------------------------------------------
*    Date         	   Name						Description of Change
* 30/03/2023   	   Saurabh Yadav		         delete relation if 1111 project code having name reference

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <stdio.h>
#include <string.h>
#include <tc/folder.h>
#include <tccore/aom_prop.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/uom.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#define ITK_err 910001

const char *revision_Order[] = {"NR", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a1", "b1", "c1", "d1", "e1", "f1", "g1", "h1", "i1", "j1", "k1", "l1", "m1", "n1", "o1", "p1", "q1", "r1", "s1", "t1", "u1", "v1", "w1", "x1", "y1", "z1", "a2", "b2", "c2", "d2", "e2", "f2", "g2", "h2", "i2", "j2", "k2", "l2", "m2", "n2", "o2", "p2", "q2", "r2", "s2", "t2", "u2", "v2", "w2", "x2", "y2", "z2", "a3", "b3", "c3", "d3", "e3", "f3", "g3", "h3", "i3", "j3", "k3", "l3", "m3", "n3", "o3", "p3", "q3", "r3", "s3", "t3", "u3", "v3", "w3", "x3", "y3", "z3", "a4", "b4", "c4", "d4", "e4", "f4", "g4", "h4", "i4", "j4", "k4", "l4", "m4", "n4", "o4", "p4", "q4", "r4", "s4", "t4", "u4", "v4", "w4", "x4", "y4", "z4", "a5", "b5", "c5", "d5", "e5", "f5", "g5", "h5", "i5", "j5", "k5", "l5", "m5", "n5", "o5", "p5", "q5", "r5", "s5", "t5", "u5", "v5", "w5", "x5", "y5", "z5", "a6", "b6", "c6", "d6", "e6", "f6", "g6", "h6", "i6", "j6", "k6", "l6", "m6", "n6", "o6", "p6", "q6", "r6", "s6", "t6", "u6", "v6", "w6", "x6", "y6", "z6", "a7", "b7", "c7", "d7", "e7", "f7", "g7", "h7", "i7", "j7", "k7", "l7", "m7", "n7", "o7", "p7", "q7", "r7", "s7", "t7", "u7", "v7", "w7", "x7", "y7", "z7", "a8", "b8", "c8", "d8", "e8", "f8", "g8", "h8", "i8", "j8", "k8", "l8", "m8", "n8", "o8", "p8", "q8", "r8", "s8", "t8", "u8", "v8", "w8", "x8", "y8", "z8", "a9", "b9", "c9", "d9", "e9", "f9", "g9", "h9", "i9", "j9", "k9", "l9", "m9", "n9", "o9", "p9", "q9", "r9", "s9", "t9", "u9", "v9", "w9", "x9", "y9", "z9"};
const int revision_length = 260;


int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);fflush(stdout);
		  exit(0);
		}

		return iFail;
}

int ITK_user_main(int argc, char* argv[])
{
    int iFail = 0;
    char* cError = NULL;
	char* username = NULL;
	tag_t tuser = NULLTAG;
	iFail = ITK_auto_login();
	printf("\nReturn Value is : %d", iFail);fflush(stdout);
	
	int n_entries = 1;
	int i=0;
	int JtNo=0;
	int j=0;
	int k=0;
	int n_genIns =0;
	tag_t tItemobj = NULLTAG;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int m=0;

	char *PartID = NULL;
	char *PartID_gen1= NULL;
	char *PartRevID_gen1= NULL;
	char *PartID_gen = NULL;
	char *PartRevID_gen = NULL;
	
	//char *PartSequenceID = NULL;
	char *Part_Rlz_Stat = NULL;
	char *part_type = NULL;
	char *Description = NULL;
	char *object_type = NULL;
	char *Part_ProjID = NULL;
	char *Part_DesgnGrp = NULL;
	char *Revision = NULL;
	tag_t DataSet = NULLTAG;
	tag_t dataset2 = NULLTAG;
	tag_t dataset3 = NULLTAG;
	tag_t dataset33 = NULLTAG;
	tag_t revobj1 = NULLTAG;
	tag_t named_ref2 = NULLTAG;
	char *inputfile=NULL;
	char *named_ref=NULL;
	tag_t item_tag_data_rev = NULLTAG;
	
	tag_t relation_type = NULLTAG;
	tag_t relation_type2 = NULLTAG;
	
	tag_t* rellist_JT = NULLTAG;
	int n_attchs_JT =0;
	tag_t* attachments = NULLTAG;
	tag_t* attachments2 = NULLTAG;
	tag_t* attachments22 = NULLTAG;
	
	tag_t itemrev = NULLTAG;
	
	
	int Part_Stat_Cnt = 0;
	tag_t *Part_Stat_Lst = NULLTAG;
	
	char * objtype=NULL;
	char * objtype1=NULL;
	char * objtype2=NULL;
	char * objtype22=NULL;
	char * PartRevID=NULL;
	char refname[AE_reference_size_c + 1];
	int referencenumberfound =0;
	int reftype =0;
	tag_t* refobject = NULLTAG;
	tag_t IPEMRelTag	= NULLTAG;
	tag_t* CreoGenTags = NULLTAG;
	int cnt=0;
	int cnt2=0;
	int ref_count_d = 0;
	tag_t* namRefObject_d = NULLTAG;
	
	
	
	FILE  *output = NULL;
	char	outputFile[200]	= "output.csv";
	
	output = fopen(outputFile,"w");
	
		if (output == NULL)
		{
			printf("ERROR: Cannot open File\n");
			return -1;
		}
		
	
	
	
	inputfile = ITK_ask_cli_argument("-i=");
	FILE *fp;
	fp=fopen(inputfile,"r");
	
	char *cEntries[1]  = {"Item ID"};
	char *inputline = NULL;
	
	char **cValues = (char **) MEM_alloc(50 * sizeof(char *));
			
	if (iFail == ITK_ok)
	{
		printf("\nTeamcenter Login Success...");fflush(stdout);
		POM_get_user(&username, &tuser);
		printf("\nUsername = %s", username);fflush(stdout);
	}
	else
	{
		EMH_ask_error_text(iFail, &cError);
		printf("\nError is : %s", cError);fflush(stdout);
	}
	if (cError)
	{
		MEM_free(cError);
	}
	if (username)
	{
		MEM_free(username);
	}
	
	if(fp!=NULL)
	{
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fp)!=NULL)
		{
			printf("\n\n Input Part: %s",inputline); fflush(stdout);
			char *partNoIP = NULL;
			partNoIP = (char *)MEM_alloc(250);
			char *InputPartType = NULL;
			InputPartType = (char *)MEM_alloc(50);
			tc_strcpy(partNoIP, "");	
			tc_strcpy(InputPartType, "");
			partNoIP = strtok(inputline,",");
			InputPartType = strtok(NULL,",");
			printf("partNoIP-----------> :%s\n",partNoIP);fflush(stdout);
			printf("InputPartType-----------> :%s\n",InputPartType);fflush(stdout);						
			cValues[0] = partNoIP;

			//ITK_CALL(QRY_find2("Item ID",&tItemobj));
			ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
			printf("\n Return Value From Query Find API is : %d", iFail);fflush(stdout);
			printf("\n Query Found Successfully...");fflush(stdout);

			ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
			printf("\n Return Value From Query Execute API is --------> %d", iFail);fflush(stdout);
		
			printf("\nNo of item returned ---------------------- %d\n",n_itemobj_found);fflush(stdout);
			
			ITK_CALL(GRM_find_relation_type("IMAN_specification",&relation_type2));
			tag_t relation_type3 = NULLTAG;
			ITK_CALL(GRM_find_relation_type("Pro2_instance",&relation_type3));
			
			for(i=0;i<n_itemobj_found;i++)
			{
				JtNo=0;
				char *RlStatus = NULL;
				RlStatus = (char *)MEM_alloc(250);
				
				itemrev=titemobj_results[i];

				ITK_CALL(AOM_ask_value_string(itemrev,"item_id",&PartID));
				ITK_CALL(AOM_ask_value_string(itemrev,"item_revision_id",&PartRevID));
				//ITK_CALL(AOM_ask_value_int(itemrev,"sequence_id",&PartSequenceID));
				ITK_CALL(GRM_list_secondary_objects_only(itemrev,relation_type2,&cnt,&attachments));
				if(cnt>0)
				{
					for(k=0;k<cnt;k++)
					{
						dataset2=attachments[k];
					
						if( AOM_ask_value_string(dataset2,"object_type",&objtype1)!=ITK_ok);
						if ((tc_strcmp(objtype1,"ProAsm")==0) || (tc_strcmp(objtype1,"ProPrt")==0))
						{
							printf("\n=================CAD DATA SET is Available====================");fflush(stdout);
							//ITK_CALL(AE_ask_dataset (dataset2,&item_tag_data_rev));
							ITK_CALL(GRM_find_relation_type("IPEM_master_dependency",&IPEMRelTag ));
							ITK_CALL(GRM_list_secondary_objects_only(dataset2,IPEMRelTag,&n_genIns,&CreoGenTags));
							printf("\n Return Valun_genInse From GRM_list_secondary_objects_only is : %d", n_genIns);fflush(stdout);
							
							if(n_genIns>1)
							{
								//printf("%s,%s\n",PartID,PartSequenceID);fflush(stdout);
								//fprintf(output, "%s,%s\n",PartID,PartSequenceID);fflush(output);
								fprintf(output,"%s,%s\n",PartID,PartRevID);fflush(output);
								
								int x=0;
								//Create another Loop and Check If there any Duplicate Part in CREO Membership and write in File
								char **MembershipPartArray = (char **) MEM_alloc(1000 * sizeof(char *));
								char **MembershipPartArrayRevSeq = (char **) MEM_alloc(1000 * sizeof(char *));
								int MemArrIndx = 0;
								for(x=0; x < n_genIns ; x++)
								{
									char *CreoMemPartID = NULL;
									char *CreoMemRevSeq = NULL;
									tag_t CreoMemObj = NULLTAG;
									CreoMemObj = CreoGenTags[x];
									ITK_CALL(AOM_ask_value_string(CreoMemObj,"item_id",&CreoMemPartID));
									ITK_CALL(AOM_ask_value_string(CreoMemObj,"item_revision_id",&CreoMemRevSeq));
									int memArr = 0;
									int PartSearStat = 0;
									int temp1 =0;
									int temp2 =0;
									char *highRev = NULL;
									char *highSeq = NULL;
									char *highRev1 = NULL;
									char *highSeq1 = NULL;
									tag_t Fndrelation = NULLTAG;
									char* cRevisionDup = (char*)MEM_alloc(sizeof(char) * 20);														
									char* cRevisionDup1 = (char*)MEM_alloc(sizeof(char) * 20);	
									char* var = (char*)MEM_alloc(sizeof(char) * 20);														
									char* var1 = (char*)MEM_alloc(sizeof(char) * 20);
									
									for(memArr = 0; memArr < MemArrIndx; memArr++)
									{
										if(tc_strcmp(MembershipPartArray[memArr],CreoMemPartID)==0)
										{
											strcpy(var,MembershipPartArrayRevSeq[memArr]);
											strcpy(var1,CreoMemRevSeq);
											
											strcpy(cRevisionDup,MembershipPartArrayRevSeq[memArr]);
											strcpy(cRevisionDup1,CreoMemRevSeq);
											highRev = strtok(cRevisionDup,";");
											highSeq = strtok(NULL,";");																
											highRev1 = strtok(cRevisionDup1,";");
											highSeq1 = strtok(NULL,";");																
											int r = 0;
											for (r = 0; r < revision_length; r++) 
											{     
												if (strcmp(highRev, revision_Order[r]) == 0) 
												{
													temp1 = r;
													break;
												}   
											}																	
											r = 0;
											for (r = 0; r < revision_length; r++) 
											{     
												if (strcmp(highRev1, revision_Order[r]) == 0) 
												{
													temp2 = r;
													break;
												}   
											}
											if(temp1<temp2)
											{
												printf("%s,%s,Lowest RevSeq\n",CreoMemPartID,var);fflush(stdout);
												tag_t query1 = NULLTAG;
												char **qry_values1 = (char **) MEM_alloc(50 * sizeof(char *));
												ITK_CALL(QRY_find2("Item Revision...",&query1));
												qry_values1[0] = CreoMemPartID;
												qry_values1[1] = var;
												int n_found1 =0;
												tag_t* cntr_objects1 = NULLTAG;
												tag_t revobj =NULLTAG;
																														
												char *qry_entries1[2]  = {"Item ID","Revision"};
												ITK_CALL(QRY_execute(query1, 2, qry_entries1, qry_values1, &n_found1, &cntr_objects1));
												printf("\n Return Value From Query Execute API is --------> %d", iFail);fflush(stdout);			
												printf("\nNo of item returned ---------------------- %d\n",n_found1);fflush(stdout);

												revobj = cntr_objects1[0];
                                                ITK_CALL(AOM_ask_value_string(revobj,"item_id",&PartID_gen1));
                                                ITK_CALL(AOM_ask_value_string(revobj,"item_revision_id",&PartRevID_gen1));
                                                printf("\n===gen part no is %s ",PartID_gen1);fflush(stdout);
                                                printf("\n===gen part revseq is %s ",PartRevID_gen1);fflush(stdout);
                                                
                                                ITK_CALL(GRM_list_secondary_objects_only(revobj,relation_type2,&cnt2,&attachments22));
                                                for(k=0;k<cnt;k++)
                                                {
                                                	dataset33=attachments22[k];
                                                    if( AOM_ask_value_string(dataset33,"object_type",&objtype22)!=ITK_ok);
                                                	if ((tc_strcmp(objtype22,"ProAsm")==0) || (tc_strcmp(objtype22,"ProPrt")==0))
                                                    {
                                                    	tag_t Fndrelation1 = NULLTAG;
                                                      	printf("\n=================CAD DATA SET is Available for generic data====================");fflush(stdout);
                                                		ITK_CALL(GRM_find_relation(dataset33,itemrev,relation_type3,&Fndrelation1));
                                                		if (Fndrelation1 != NULLTAG)
                                                		{
                                                			printf("Need to delete : %s - %s Pro2_instance from DataSet %s - %s",PartID,PartRevID,PartID_gen1,PartRevID_gen1); fflush(stdout);
                                                			//ITK_CALL(GRM_delete_relation(Fndrelation1));
                                                		}
                                                	}
                                                }
                                                
                                                ITK_CALL(AOM_refresh(dataset2,1));
                                                tag_t Fndrelation2 = NULLTAG;
                                                ITK_CALL(GRM_find_relation(dataset2,revobj,IPEMRelTag,&Fndrelation2));
                                               	ITK_CALL(GRM_delete_relation(Fndrelation2));
                                                    															
											}	
											else if(temp1 > temp2)
											{
												char **qry_values2 = (char **) MEM_alloc(50 * sizeof(char *));
												tag_t query2 = NULLTAG;
												ITK_CALL(QRY_find2("Item Revision...",&query2));
												qry_values2[0] = CreoMemPartID;
												qry_values2[1] = var1;
												int n_found2 =0;
												tag_t revobj1 =NULLTAG;
												tag_t* cntr_objects2 = NULLTAG;
												char *qry_entries2[2]  = {"Item ID","Revision"};
												ITK_CALL(QRY_execute(query2, 2, qry_entries2, qry_values2, &n_found2, &cntr_objects2));
												revobj1 = cntr_objects2[0];
												printf("\n Return Value From Query Execute API is --------> %d", iFail);fflush(stdout);			
												printf("\nNo of item returned ---------------------- %d\n",n_found2);fflush(stdout);	
									
                                                ITK_CALL(AOM_ask_value_string(revobj1,"item_id",&PartID_gen));
                                                ITK_CALL(AOM_ask_value_string(revobj1,"item_revision_id",&PartRevID_gen));
                                                printf("\n===gen part no is %s ",PartID_gen);fflush(stdout);
                                                printf("\n===gen part revseq is %s ",PartRevID_gen);fflush(stdout);
                                                
                                                ITK_CALL(GRM_list_secondary_objects_only(revobj1,relation_type2,&cnt2,&attachments2));
                                                for(k=0;k<cnt;k++)
                                                {
                                                	dataset3=attachments2[k];
                                                    if( AOM_ask_value_string(dataset3,"object_type",&objtype2)!=ITK_ok);
                                                	if ((tc_strcmp(objtype2,"ProAsm")==0) || (tc_strcmp(objtype2,"ProPrt")==0))
                                                    {
                                                    	tag_t Fndrelation = NULLTAG;
                                                      	printf("\n=================CAD DATA SET is Available for generic data====================");fflush(stdout);
                                                		ITK_CALL(GRM_find_relation(dataset3,itemrev,relation_type3,&Fndrelation));
                                                		if (Fndrelation != NULLTAG)
                                                		{
                                                			printf("Need to delete : %s - %s Pro2_instance from DataSet %s - %s",PartID,PartRevID,PartID_gen,PartRevID_gen); fflush(stdout);
                                                			//ITK_CALL(GRM_delete_relation(Fndrelation));
                                                		}
                                                	}
                                                }
                                                
                                                ITK_CALL(AOM_refresh(dataset2,1));
                                                tag_t Fndrelation2 = NULLTAG;
                                                ITK_CALL(GRM_find_relation(dataset2,revobj1,IPEMRelTag,&Fndrelation2));
                                                ITK_CALL(GRM_delete_relation(Fndrelation2));
                                                
												
												printf("%s,%s,Lowest RevSeq\n",CreoMemPartID,var1);fflush(stdout);
											}
											else if(temp1 == temp2)
											{
												printf("Alokesh 1"); fflush(stdout);
												int lowseq = 0;
												lowseq = atoi(highSeq) < atoi(highSeq1) ? atoi(highSeq) : atoi(highSeq1);
												printf("Alokesh 2"); fflush(stdout);
												tc_strcpy(var,"");
												printf("Alokesh 3"); fflush(stdout);
												sprintf(var,"%s;%d",highRev,lowseq);

												printf("%s,%s,Lowest RevSeq\n",CreoMemPartID,var);fflush(stdout);
												tag_t query1 = NULLTAG;
												char **qry_values1 = (char **) MEM_alloc(50 * sizeof(char *));
												ITK_CALL(QRY_find2("Item Revision...",&query1));
												qry_values1[0] = CreoMemPartID;
												qry_values1[1] = var;
												int n_found1 =0;
												tag_t* cntr_objects1 = NULLTAG;
												tag_t revobj =NULLTAG;
																														
												char *qry_entries1[2]  = {"Item ID","Revision"};
												ITK_CALL(QRY_execute(query1, 2, qry_entries1, qry_values1, &n_found1, &cntr_objects1));
												printf("\n Return Value From Query Execute API is --------> %d", iFail);fflush(stdout);			
												printf("\nNo of item returned ---------------------- %d\n",n_found1);fflush(stdout);

												revobj = cntr_objects1[0];
                                                ITK_CALL(AOM_ask_value_string(revobj,"item_id",&PartID_gen1));
                                                ITK_CALL(AOM_ask_value_string(revobj,"item_revision_id",&PartRevID_gen1));
                                                printf("\n===gen part no is %s ",PartID_gen1);fflush(stdout);
                                                printf("\n===gen part revseq is %s ",PartRevID_gen1);fflush(stdout);
                                                
                                                ITK_CALL(GRM_list_secondary_objects_only(revobj,relation_type2,&cnt2,&attachments22));
                                                for(k=0;k<cnt;k++)
                                                {
                                                	dataset33=attachments22[k];
                                                    if( AOM_ask_value_string(dataset33,"object_type",&objtype22)!=ITK_ok);
                                                	if ((tc_strcmp(objtype22,"ProAsm")==0) || (tc_strcmp(objtype22,"ProPrt")==0))
                                                    {
                                                    	tag_t Fndrelation1 = NULLTAG;
                                                      	printf("\n=================CAD DATA SET is Available for generic data====================");fflush(stdout);
                                                		ITK_CALL(GRM_find_relation(dataset33,itemrev,relation_type3,&Fndrelation1));
                                                		if (Fndrelation1 != NULLTAG)
                                                		{
                                                			printf("Need to delete : %s - %s Pro2_instance from DataSet %s - %s",PartID,PartRevID,PartID_gen1,PartRevID_gen1); fflush(stdout);
                                                			//ITK_CALL(GRM_delete_relation(Fndrelation1));
                                                		}
                                                	}
                                                }
                                                
                                                ITK_CALL(AOM_refresh(dataset2,1));
                                                tag_t Fndrelation2 = NULLTAG;
                                                ITK_CALL(GRM_find_relation(dataset2,revobj,IPEMRelTag,&Fndrelation2));
                                               	ITK_CALL(GRM_delete_relation(Fndrelation2));
											}

											PartSearStat = 1;
											break;
										}
									}
									if(PartSearStat == 0)
									{
										MembershipPartArray[MemArrIndx] = CreoMemPartID;
										MembershipPartArrayRevSeq[MemArrIndx]=CreoMemRevSeq;
										MemArrIndx++;
									}
									else
									{
										printf("%s,%s,Duplicate_Revision_CREO_Membeship\n",PartID,PartRevID);fflush(stdout);
										//fprintf(output,"%s,%s,Duplicate_Revision_CREO_Membeship\n",PartID,PartRevID);fflush(output);
									}
								}

								for(x=0; x < n_genIns ; x++)
								{
									tag_t CreoMemObj = NULLTAG;
									CreoMemObj = CreoGenTags[x];
									//ChkDataSetCreoMem(&CreoMemObj);
								}	
										
								
								
							}
							  
						}
					}
				}
			}
			printf("\n=============================================================================");fflush(stdout);
		}
	}
	iFail = ITK_exit_module(TRUE);
	printf("\nReturn Value is : %d", iFail);
	if (iFail == ITK_ok)
	{
		printf("\nTeamcenter Logout Success...");fflush(stdout);
	}
	else
	{
		EMH_ask_error_text(iFail, &cError);
		printf("\nError is : %s", cError);fflush(stdout);
	}
		
	//fclose(output);
	return ITK_ok;
}















/* ITK_CALL(AE_ask_dataset_ref_count(dataset2,&referencenumberfound));
													
													for(j=0;j<referencenumberfound;j++)
													{
														ITK_CALL(AE_find_dataset_named_ref(dataset2,j,refname,&reftype,&refobject));
													} */






