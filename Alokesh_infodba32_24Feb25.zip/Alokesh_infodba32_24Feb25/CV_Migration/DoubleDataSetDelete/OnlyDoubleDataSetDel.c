/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2023  MNM.  ALL RIGHTS RESERVED
*
*
*------------------------------------------------------------------------------
* Filename		: autologin.c
* Description	: This Utility Mainly Used For Multi DataSet Delete in Teamcenter
* Module       	:	        
* Since		    :    
* ENVIRONMENT	: C++, ITK
* History       :
*------------------------------------------------------------------------------
*    Date         	   Name						Description of Change
* 30/05/2023   	   Alokesh Ghosh		          

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <stdio.h>
#include <string.h>
#include <tc/folder.h>
#include <tccore/aom_prop.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/uom.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#define ITK_err 910001

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);fflush(stdout);
		  exit(0);
		}

		return iFail;
}

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

static void handle_itk_error
    ( int stat,                               /* <I> */
      int source_code_line,                   /* <I> */
      const char *source_code_file_name       /* <I> */
    );

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc, char* argv[])
{
    char* cError = NULL;
	char* username = NULL;
	tag_t tuser = NULLTAG;
	int ifail = ITK_ok;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	if(ITK_auto_login() == ITK_ok)	
	{
		int n_entries = 2;
		int i=0;
		int j=0;
		int k=0;
		int JtNo =0;
		int AsmPrt =0;
		int ProDrw = 0;
		tag_t tItemobj = NULLTAG;
		int n_itemobj_found = 0;
		tag_t* titemobj_results = NULLTAG;
		char *PartID = NULL;
		char *PartRevID = NULL;
		//int PartSequenceID = 0;
		char *part_type = NULL;
		char *Description = NULL;
		char *object_type = NULL;
		char *Part_ProjID = NULL;
		char *Part_DesgnGrp = NULL;
		char *Revision = NULL;
		tag_t* rellist_JT = NULLTAG;
		int n_attchs_JT =0;
		tag_t* attachments = NULLTAG;
		int cnt =0;
		tag_t relation_type = NULLTAG;
		tag_t relation_type2 = NULLTAG;
		tag_t itemrev = NULLTAG;
		tag_t dataset = NULLTAG;
		tag_t  dataset2 = NULLTAG;
		char * objtype=NULL;
		char * objtype1=NULL;
		int  rows = 0, columns = 0, intFirstJT=0;
		char * objtypename = NULL;
		
		char *inputline = NULL;
		//char *cEntries[2]  = {"Item ID","Revision"};
		char *cEntries[1]  = {"Item ID"};
		
		char **cValues = (char **) MEM_alloc(50 * sizeof(char *));

		char *inputfile=NULL;
		inputfile = ITK_ask_cli_argument("-i=");
		FILE *fp;
		fp=fopen(inputfile,"r");
		if(fp!=NULL)
		{
			inputline=(char *) MEM_alloc(1000);
			while(fgets(inputline,1000,fp)!=NULL)
			{
				printf("\n\n Input Part: %s",inputline); fflush(stdout);

				char *partNoIP = NULL;
				partNoIP = (char *)MEM_alloc(250);
				char *partRevSeqIP = NULL;
				partRevSeqIP = (char *)MEM_alloc(50);

				tc_strcpy(partNoIP, "");
				tc_strcpy(partRevSeqIP, "");
				partNoIP = strtok(inputline,",");
				partRevSeqIP = strtok(NULL,",");

				printf("\nAfter STRTOK %s, %s ",partNoIP,partRevSeqIP); fflush(stdout);
	

		ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
		cValues[0] = partNoIP;
		//cValues[1] = partRevSeqIP;

		//char *cValues[2]  = {"279018100401","NR;1"};
		//if (QRY_execute(tItemobj, n_entries, cEntries, cValues, &rows, &titemobj_results) != ITK_ok) PrintErrorStack();
		if (QRY_execute(tItemobj, 1, cEntries, cValues, &rows, &titemobj_results) != ITK_ok) PrintErrorStack();

		printf("\n Rows Returned: %d",rows); fflush(stdout);
		
		if (rows != 0)
		{
			//printf("\nNo of item returned ---------------------- %d\n",rows);fflush(stdout);
			ITK_CALL(GRM_find_relation_type("IMAN_Rendering",&relation_type));
			ITK_CALL(GRM_find_relation_type("IMAN_specification",&relation_type2));
			printf("\nAlokesh 4"); fflush(stdout);
			for(i=0;i<rows;i++)
			{
				itemrev=titemobj_results[i];
				//itemrev=*(tag_t*)(report[i][0]);
				
				ITK_CALL(AOM_ask_value_string(itemrev,"item_id",&PartID));
				printf("\nPart Number: %s",PartID); fflush(stdout);
				ITK_CALL(AOM_ask_value_string(itemrev,"item_revision_id",&PartRevID));
				//ITK_CALL(AOM_ask_value_int(itemrev,"sequence_id",&PartSequenceID));

				//Delete JT File / PDF which have wrong Named ref -- START
				/*ITK_CALL(GRM_list_secondary_objects_only(itemrev,relation_type,&n_attchs_JT,&rellist_JT));
				for(j=0;j<n_attchs_JT;j++)
				{
					dataset=rellist_JT[j];
					if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
					if( AOM_ask_value_string(dataset,"object_type",&objtype)!=ITK_ok);
					if(tc_strcmp(objtype,"DirectModel")==0 || tc_strcmp(objtype,"PDF")==0)
					{
						int result = 0;
						int ref_count_d = 0;
						tag_t *namRefObject_d = NULL;
						char *refname2 = NULL;
						tag_t *refobject2	= NULLTAG;
						int result1 = 0;
						int z = 0;
						result = AE_ask_dataset_named_refs(dataset,&ref_count_d, &namRefObject_d);
						if(ref_count_d > 0)
						{
							if (AOM_ask_value_string(namRefObject_d[0],"object_string",&refname2)!=ITK_ok);

							char *compNmdRef = NULL;
							compNmdRef = tc_strtok(refname2,".");
							printf("\n\t refname2:[%s] ",compNmdRef);
							//if(tc_strstr(refname2, PartID) == NULL)
							if(tc_strcasecmp(compNmdRef, objtypename) != 0 && tc_strstr(refname2, PartID) == NULL)
							{
								printf("\n\tNeed to delete");fflush(stdout);
								GRM_list_all_related_objects_only(dataset,&result1,&refobject2);
								printf("\nReleations Count : %d",result1); fflush(stdout);
								for (z = 0; z < result1; ++z)
								{
									if (AOM_ask_value_string(refobject2[z],"type_string",&refname2)!=ITK_ok);
									printf("\nDeleting Releation : %d --- %s",z,refname2); fflush(stdout);
									if (GRM_delete_relation(refobject2[z]) != ITK_ok) PrintErrorStack();
								}
								printf("\nAOM_delete Deleting Dataset : %s",PartID); fflush(stdout);
								if (AOM_refresh(dataset,1)) PrintErrorStack();
								if (AOM_delete(dataset) != ITK_ok) PrintErrorStack();
							}
						}
						else
						{
							printf("\n\tNeed to delete");fflush(stdout);
							GRM_list_all_related_objects_only(dataset,&result1,&refobject2);
							printf("\nReleations Count : %d",result1); fflush(stdout);
							for (z = 0; z < result1; ++z)
							{
								if (AOM_ask_value_string(refobject2[z],"type_string",&refname2)!=ITK_ok);
								printf("\nDeleting Releation : %d --- %s",z,refname2); fflush(stdout);
								if (GRM_delete_relation(refobject2[z]) != ITK_ok) PrintErrorStack();
							}
							printf("\nAOM_delete Deleting Dataset : %s",PartID); fflush(stdout);
							if (AOM_refresh(dataset,1)) PrintErrorStack();
							if (AOM_delete(dataset) != ITK_ok) PrintErrorStack();
						}
					}
				}*/
				//Delete File which have wrong Named ref -- END

				//Delete File Multi JT -- START
				JtNo = 0;
				if (AOM_refresh(itemrev,1)) PrintErrorStack();
				ITK_CALL(GRM_list_secondary_objects_only(itemrev,relation_type,&n_attchs_JT,&rellist_JT));
				for(j=0;j<n_attchs_JT;j++)
				{
					dataset=rellist_JT[j];
					if( AOM_ask_value_string(dataset,"object_type",&objtype)!=ITK_ok);
					if(tc_strcmp(objtype,"DirectModel")==0)
					{
						JtNo++;
					}
				}
				if(JtNo > 1)
				{
					intFirstJT = 0;
					for(j=0;j<n_attchs_JT;j++)
					{
						dataset=rellist_JT[j];
						if( AOM_ask_value_string(dataset,"object_type",&objtype)!=ITK_ok);
						if(tc_strcmp(objtype,"DirectModel")==0)
						{
							if (intFirstJT == 0)
							{
								printf("This is First Occ"); fflush(stdout);
								intFirstJT++;
								continue;
							}
							else
							{
								char *refname2 = NULL;
								tag_t *refobject2	= NULLTAG;
								int result1 = 0;
								int z = 0;
								printf("\n\tNeed to delete");fflush(stdout);
								GRM_list_all_related_objects_only(dataset,&result1,&refobject2);
								printf("\nReleations Count : %d",result1); fflush(stdout);
								for (z = 0; z < result1; ++z)
								{
									if (AOM_ask_value_string(refobject2[z],"type_string",&refname2)!=ITK_ok);
									printf("\nDeleting Releation : %d --- %s",z,refname2); fflush(stdout);
									if (GRM_delete_relation(refobject2[z]) != ITK_ok) PrintErrorStack();
								}
								printf("\nAOM_delete Deleting Dataset : %s",PartID); fflush(stdout);
								if (AOM_refresh(dataset,1)) PrintErrorStack();
								if (AOM_delete(dataset) != ITK_ok) PrintErrorStack();
							}
						}
					}
				}
				//Delete File Multi JT -- END

				//Delete File Multi PDF -- START
				JtNo = 0;
				if (AOM_refresh(itemrev,1)) PrintErrorStack();
				ITK_CALL(GRM_list_secondary_objects_only(itemrev,relation_type,&n_attchs_JT,&rellist_JT));
				for(j=0;j<n_attchs_JT;j++)
				{
					dataset=rellist_JT[j];
					if( AOM_ask_value_string(dataset,"object_type",&objtype)!=ITK_ok);
					if(tc_strcmp(objtype,"PDF")==0)
					{
						JtNo++;
					}
				}
				if(JtNo > 1)
				{
					intFirstJT = 0;
					for(j=0;j<n_attchs_JT;j++)
					{
						dataset=rellist_JT[j];
						if( AOM_ask_value_string(dataset,"object_type",&objtype)!=ITK_ok);
						if(tc_strcmp(objtype,"PDF")==0)
						{
							if (intFirstJT == 0)
							{
								printf("This is First Occ"); fflush(stdout);
								intFirstJT++;
								continue;
							}
							else
							{
								char *refname2 = NULL;
								tag_t *refobject2	= NULLTAG;
								int result1 = 0;
								int z = 0;
								printf("\n\tNeed to delete");fflush(stdout);
								GRM_list_all_related_objects_only(dataset,&result1,&refobject2);
								printf("\nReleations Count : %d",result1); fflush(stdout);
								for (z = 0; z < result1; ++z)
								{
									if (AOM_ask_value_string(refobject2[z],"type_string",&refname2)!=ITK_ok);
									printf("\nDeleting Releation : %d --- %s",z,refname2); fflush(stdout);
									if (GRM_delete_relation(refobject2[z]) != ITK_ok) PrintErrorStack();
								}
								printf("\nAOM_delete Deleting Dataset : %s",PartID); fflush(stdout);
								if (AOM_refresh(dataset,1)) PrintErrorStack();
								if (AOM_delete(dataset) != ITK_ok) PrintErrorStack();
							}
						}
					}
				}
				//Delete File Multi PDF -- END

				//Delete File Multi ProPrt / ProAsm / ProDrw which have wrong Named ref -- START
				/*ITK_CALL(GRM_list_secondary_objects_only(itemrev,relation_type2,&cnt,&attachments));
				for(k=0;k<cnt;k++)
				{
					dataset2=attachments[k];
					if( AOM_ask_value_string(dataset,"object_name",&objtypename)!=ITK_ok);
					if( AOM_ask_value_string(dataset2,"object_type",&objtype1)!=ITK_ok);
					if ((tc_strcmp(objtype1,"ProAsm")==0) || (tc_strcmp(objtype1,"ProPrt")==0) || (tc_strcmp(objtype1,"ProDrw")==0))
					{
						int result = 0;
						int ref_count_d = 0;
						tag_t *namRefObject_d = NULL;
						char *refname2 = NULL;
						tag_t *refobject2	= NULLTAG;
						int result1 = 0;
						int z = 0;
						result = AE_ask_dataset_named_refs(dataset2,&ref_count_d, &namRefObject_d);
						if(ref_count_d > 0)
						{
							if (AOM_ask_value_string(namRefObject_d[0],"object_string",&refname2)!=ITK_ok);

							char *compNmdRef = NULL;
							compNmdRef = tc_strtok(refname2,".");
							printf("\n\t refname2:[%s] ",compNmdRef);
							//if(tc_strstr(refname2, PartID) == NULL)
							if(tc_strcasecmp(compNmdRef, objtypename) != 0  && tc_strstr(refname2, PartID) == NULL)
							{
								int cnt3 = 0;
								int cnt4 = 0;
								int cnt5 = 0;
								int cnt6 = 0;
								tag_t* attachments3 = NULLTAG;
								tag_t relation_type3 = NULLTAG;
								tag_t relation_type4 = NULLTAG;
								tag_t relation_type5 = NULLTAG;
								tag_t relation_type6 = NULLTAG;
								ITK_CALL(GRM_find_relation_type("IPEM_master_dependency",&relation_type3));
								ITK_CALL(GRM_find_relation_type("Pro2_instance",&relation_type4));
								ITK_CALL(GRM_find_relation_type("Pro2_membership",&relation_type5));
								ITK_CALL(GRM_find_relation_type("Pro2_merge",&relation_type6));
								ITK_CALL(GRM_list_secondary_objects_only(dataset2,relation_type3,&cnt3,&attachments3));
								ITK_CALL(GRM_list_secondary_objects_only(dataset2,relation_type4,&cnt4,&attachments3));
								ITK_CALL(GRM_list_secondary_objects_only(dataset2,relation_type5,&cnt5,&attachments3));
								ITK_CALL(GRM_list_secondary_objects_only(dataset2,relation_type6,&cnt6,&attachments3));

								if (cnt3 == 0 && cnt4 == 0 && cnt5 == 0 && cnt6 == 0)
								{
									printf("\n\tNeed to delete");fflush(stdout);
									GRM_list_all_related_objects_only(dataset2,&result1,&refobject2);
									printf("\nReleations Count : %d",result1); fflush(stdout);
									for (z = 0; z < result1; ++z)
									{
										if (AOM_ask_value_string(refobject2[z],"type_string",&refname2)!=ITK_ok);
										printf("\nDeleting Releation : %d --- %s",z,refname2); fflush(stdout);
										if (GRM_delete_relation(refobject2[z]) != ITK_ok) PrintErrorStack();
									}
									printf("\nAOM_delete Deleting Dataset : %s",PartID); fflush(stdout);
									if (AOM_refresh(dataset2,1)) PrintErrorStack();
									if (AOM_delete(dataset2) != ITK_ok) PrintErrorStack();
								}
								else
								{
									FILE *errDtaSet = NULL;
									errDtaSet = fopen("WrongNamedRefwithReleation.txt","a+");
									fprintf(errDtaSet,"%s,%s,Need_to_Remove_Named_Ref_by_CheckOut\n",PartID,PartRevID); fflush(errDtaSet);
									fclose(errDtaSet);
								}
							}
						}
					}
				}*/
				//Delete File Multi ProPrt / ProAsm which have wrong Named ref -- END

				//Delete File Multi ProPrt / ProAsm -- START
				AsmPrt = 0;
				if (AOM_refresh(itemrev,1)) PrintErrorStack();
				ITK_CALL(GRM_list_secondary_objects_only(itemrev,relation_type2,&cnt,&attachments));
				for(k=0;k<cnt;k++)
				{
					dataset2=attachments[k];
					if( AOM_ask_value_string(dataset2,"object_type",&objtype1)!=ITK_ok);
					if ((tc_strcmp(objtype1,"ProAsm")==0) || (tc_strcmp(objtype1,"ProPrt")==0))
					{
						AsmPrt++;
					}
				}
				if(AsmPrt > 1)
				{
					tag_t  FisrtAppTag = NULLTAG;
					intFirstJT = 0;
					for(k=0;k<cnt;k++)
					{
						dataset2=attachments[k];
						if( AOM_ask_value_string(dataset2,"object_type",&objtype1)!=ITK_ok);
						if ((tc_strcmp(objtype1,"ProAsm")==0) || (tc_strcmp(objtype1,"ProPrt")==0))
						{
							if (intFirstJT == 0)
							{
								printf("This is First Occ"); fflush(stdout);
								FisrtAppTag = dataset2;
								intFirstJT++;
								continue;
							}
							else
							{
								char *refname2 = NULL;
								tag_t *refobject2	= NULLTAG;
								int result1 = 0;
								int z = 0;

								//Copy IPEM_master_dependency | Pro2_instance | Pro2_membership | Pro2_merge -> to FisrtAppTag || Pro2_drawing_model (For Drawing)
								tag_t Fndrelation = NULLTAG;
								int cnt3 = 0;
								int x = 0;
								tag_t relationOnDtSet = NULLTAG;
								tag_t* attachments3 = NULLTAG;
								tag_t relation_type3 = NULLTAG;
								tag_t relation_type4 = NULLTAG;
								tag_t relation_type5 = NULLTAG;
								tag_t relation_type6 = NULLTAG;
								ITK_CALL(GRM_find_relation_type("IPEM_master_dependency",&relation_type3));
								ITK_CALL(GRM_find_relation_type("Pro2_instance",&relation_type4));
								ITK_CALL(GRM_find_relation_type("Pro2_membership",&relation_type5));
								ITK_CALL(GRM_find_relation_type("Pro2_merge",&relation_type6));

								ITK_CALL(GRM_list_secondary_objects_only(dataset2,relation_type3,&cnt3,&attachments3));
								for(x=0 ; x < cnt3 ; x++)
								{
									relationOnDtSet=attachments3[x];
									ITK_CALL(GRM_find_relation(FisrtAppTag,relationOnDtSet,relation_type3,&Fndrelation));
									if(Fndrelation == NULLTAG)
									{
										tag_t relation3 = NULLTAG;
										ITK_CALL(GRM_create_relation(FisrtAppTag, relationOnDtSet, relation_type3, NULLTAG, &relation3));
										ITK_CALL(GRM_save_relation(relation3));
									}
								}
								ITK_CALL(GRM_list_secondary_objects_only(dataset2,relation_type4,&cnt3,&attachments3));
								for(x=0 ; x < cnt3 ; x++)
								{
									relationOnDtSet=attachments3[x];
									ITK_CALL(GRM_find_relation(FisrtAppTag,relationOnDtSet,relation_type4,&Fndrelation));
									if(Fndrelation == NULLTAG)
									{
										tag_t relation3 = NULLTAG;
										ITK_CALL(GRM_create_relation(FisrtAppTag, relationOnDtSet, relation_type4, NULLTAG, &relation3));
										ITK_CALL(GRM_save_relation(relation3));
									}
								}
								ITK_CALL(GRM_list_secondary_objects_only(dataset2,relation_type5,&cnt3,&attachments3));
								for(x=0 ; x < cnt3 ; x++)
								{
									relationOnDtSet=attachments3[x];
									ITK_CALL(GRM_find_relation(FisrtAppTag,relationOnDtSet,relation_type5,&Fndrelation));
									if(Fndrelation == NULLTAG)
									{
										tag_t relation3 = NULLTAG;
										ITK_CALL(GRM_create_relation(FisrtAppTag, relationOnDtSet, relation_type5, NULLTAG, &relation3));
										ITK_CALL(GRM_save_relation(relation3));
									}
								}
								ITK_CALL(GRM_list_secondary_objects_only(dataset2,relation_type6,&cnt3,&attachments3));
								for(x=0 ; x < cnt3 ; x++)
								{
									relationOnDtSet=attachments3[x];
									ITK_CALL(GRM_find_relation(FisrtAppTag,relationOnDtSet,relation_type6,&Fndrelation));
									if(Fndrelation == NULLTAG)
									{
										tag_t relation3 = NULLTAG;
										ITK_CALL(GRM_create_relation(FisrtAppTag, relationOnDtSet, relation_type6, NULLTAG, &relation3));
										ITK_CALL(GRM_save_relation(relation3));
									}
								}

								printf("\n\tNeed to delete");fflush(stdout);
								GRM_list_all_related_objects_only(dataset2,&result1,&refobject2);
								printf("\nReleations Count : %d",result1); fflush(stdout);
								for (z = 0; z < result1; ++z)
								{
									if (AOM_ask_value_string(refobject2[z],"type_string",&refname2)!=ITK_ok);
									printf("\nDeleting Releation : %d --- %s",z,refname2); fflush(stdout);
									if (GRM_delete_relation(refobject2[z]) != ITK_ok) PrintErrorStack();
								}
								printf("\nAOM_delete Deleting Dataset : %s",PartID); fflush(stdout);
								if (AOM_refresh(dataset2,1)) PrintErrorStack();
								if (AOM_delete(dataset2) != ITK_ok) PrintErrorStack();
							}
						}
					}
				}
				//Delete File Multi ProPrt / ProAsm -- END

				//Delete File Multi ProDrw -- START
				ProDrw = 0;
				if (AOM_refresh(itemrev,1)) PrintErrorStack();
				ITK_CALL(GRM_list_secondary_objects_only(itemrev,relation_type2,&cnt,&attachments));
				for(k=0;k<cnt;k++)
				{
					dataset2=attachments[k];
					if( AOM_ask_value_string(dataset2,"object_type",&objtype1)!=ITK_ok);
					if ((tc_strcmp(objtype1,"ProDrw")==0))
					{
						ProDrw++;
					}
				}
				if(ProDrw > 1)
				{
					tag_t  FisrtAppTag = NULLTAG;
					intFirstJT = 0;
					for(k=0;k<cnt;k++)
					{
						dataset2=attachments[k];
						if( AOM_ask_value_string(dataset2,"object_type",&objtype1)!=ITK_ok);
						if ((tc_strcmp(objtype1,"ProDrw")==0))
						{
							if (intFirstJT == 0)
							{
								printf("This is First Occ"); fflush(stdout);
								FisrtAppTag = dataset2;
								intFirstJT++;
								continue;
							}
							else
							{
								char *refname2 = NULL;
								tag_t *refobject2	= NULLTAG;
								int result1 = 0;
								int z = 0;

								//Copy Pro2_drawing_model (For Drawing)
								tag_t Fndrelation = NULLTAG;
								int cnt3 = 0;
								int x = 0;
								tag_t relationOnDtSet = NULLTAG;
								tag_t* attachments3 = NULLTAG;
								tag_t relation_type3 = NULLTAG;
								ITK_CALL(GRM_find_relation_type("Pro2_drawing_model",&relation_type3));

								ITK_CALL(GRM_list_secondary_objects_only(dataset2,relation_type3,&cnt3,&attachments3));
								for(x=0 ; x < cnt3 ; x++)
								{
									relationOnDtSet=attachments3[x];
									ITK_CALL(GRM_find_relation(FisrtAppTag,relationOnDtSet,relation_type3,&Fndrelation));
									if(Fndrelation == NULLTAG)
									{
										tag_t relation3 = NULLTAG;
										ITK_CALL(GRM_create_relation(FisrtAppTag, relationOnDtSet, relation_type3, NULLTAG, &relation3));
										ITK_CALL(GRM_save_relation(relation3));
									}
								}

								printf("\n\tNeed to delete");fflush(stdout);
								GRM_list_all_related_objects_only(dataset2,&result1,&refobject2);
								printf("\nReleations Count : %d",result1); fflush(stdout);
								for (z = 0; z < result1; ++z)
								{
									if (AOM_ask_value_string(refobject2[z],"type_string",&refname2)!=ITK_ok);
									printf("\nDeleting Releation : %d --- %s",z,refname2); fflush(stdout);
									if (GRM_delete_relation(refobject2[z]) != ITK_ok) PrintErrorStack();
								}
								printf("\nAOM_delete Deleting Dataset : %s",PartID); fflush(stdout);
								if (AOM_refresh(dataset2,1)) PrintErrorStack();
								if (AOM_delete(dataset2) != ITK_ok) PrintErrorStack();
							}
						}
					}
				}
				//Delete File Multi ProDrw -- END

				//Delete CMI2CacheCgr which have wrong Named ref -- START
				if (AOM_refresh(itemrev,1)) PrintErrorStack();
				ITK_CALL(GRM_list_secondary_objects_only(itemrev,relation_type2,&n_attchs_JT,&rellist_JT));
				for(j=0;j<n_attchs_JT;j++)
				{
					dataset=rellist_JT[j];
					if( AOM_ask_value_string(dataset,"object_type",&objtype)!=ITK_ok);
					if(tc_strcmp(objtype,"CMI2CacheCgr")==0)
					{
						int result = 0;
						int ref_count_d = 0;
						tag_t *namRefObject_d = NULL;
						char *refname2 = NULL;
						tag_t *refobject2	= NULLTAG;
						int result1 = 0;
						int z = 0;
						char *DataSetName = NULL;
						ITK_CALL(AOM_ask_value_string( dataset, "object_string", &DataSetName));
						result = AE_ask_dataset_named_refs(dataset,&ref_count_d, &namRefObject_d);
						if(ref_count_d > 0)
						{
							if (AOM_ask_value_string(namRefObject_d[0],"object_string",&refname2)!=ITK_ok);
							printf("\n\t refname2:[%s] ",refname2);
							char *tmpPartID = NULL;
							tmpPartID=(char *) MEM_alloc(200);
							tc_strcpy(tmpPartID,PartID);
							tc_strcat(tmpPartID,".cgr");
							if(tc_strstr(refname2, PartID) == NULL || tc_strcmp(DataSetName,tmpPartID)==0)
							{
								printf("\n\tNeed to delete");fflush(stdout);
								GRM_list_all_related_objects_only(dataset,&result1,&refobject2);
								printf("\nReleations Count : %d",result1); fflush(stdout);
								for (z = 0; z < result1; ++z)
								{
									if (AOM_ask_value_string(refobject2[z],"type_string",&refname2)!=ITK_ok);
									printf("\nDeleting Releation : %d --- %s",z,refname2); fflush(stdout);
									if (GRM_delete_relation(refobject2[z]) != ITK_ok) PrintErrorStack();
								}
								printf("\nAOM_delete Deleting Dataset : %s",PartID); fflush(stdout);
								if (AOM_refresh(dataset,1)) PrintErrorStack();
								if (AOM_delete(dataset) != ITK_ok) PrintErrorStack();
							}
						}
						else
						{
							printf("\n\tNeed to delete");fflush(stdout);
							GRM_list_all_related_objects_only(dataset,&result1,&refobject2);
							printf("\nReleations Count : %d",result1); fflush(stdout);
							for (z = 0; z < result1; ++z)
							{
								if (AOM_ask_value_string(refobject2[z],"type_string",&refname2)!=ITK_ok);
								printf("\nDeleting Releation : %d --- %s",z,refname2); fflush(stdout);
								if (GRM_delete_relation(refobject2[z]) != ITK_ok) PrintErrorStack();
							}
							printf("\nAOM_delete Deleting Dataset : %s",PartID); fflush(stdout);
							if (AOM_refresh(dataset,1)) PrintErrorStack();
							if (AOM_delete(dataset) != ITK_ok) PrintErrorStack();
						}
					}
				}
				//Delete CMI2CacheCgr File which have wrong Named ref -- END

				//Delete File Multi CMI2CacheCgr -- START
				JtNo = 0;
				if (AOM_refresh(itemrev,1)) PrintErrorStack();
				ITK_CALL(GRM_list_secondary_objects_only(itemrev,relation_type2,&n_attchs_JT,&rellist_JT));
				for(j=0;j<n_attchs_JT;j++)
				{
					dataset=rellist_JT[j];
					if( AOM_ask_value_string(dataset,"object_type",&objtype)!=ITK_ok);
					if(tc_strcmp(objtype,"CMI2CacheCgr")==0)
					{
						JtNo++;
					}
				}
				if(JtNo > 1)
				{
					intFirstJT = 0;
					for(j=0;j<n_attchs_JT;j++)
					{
						dataset=rellist_JT[j];
						if( AOM_ask_value_string(dataset,"object_type",&objtype)!=ITK_ok);
						if(tc_strcmp(objtype,"CMI2CacheCgr")==0)
						{
							if (intFirstJT == 0)
							{
								printf("This is First Occ"); fflush(stdout);
								intFirstJT++;
								continue;
							}
							else
							{
								char *refname2 = NULL;
								tag_t *refobject2	= NULLTAG;
								int result1 = 0;
								int z = 0;
								printf("\n\tNeed to delete");fflush(stdout);
								GRM_list_all_related_objects_only(dataset,&result1,&refobject2);
								printf("\nReleations Count : %d",result1); fflush(stdout);
								for (z = 0; z < result1; ++z)
								{
									if (AOM_ask_value_string(refobject2[z],"type_string",&refname2)!=ITK_ok);
									printf("\nDeleting Releation : %d --- %s",z,refname2); fflush(stdout);
									if (GRM_delete_relation(refobject2[z]) != ITK_ok) PrintErrorStack();
								}
								printf("\nAOM_delete Deleting Dataset : %s",PartID); fflush(stdout);
								if (AOM_refresh(dataset,1)) PrintErrorStack();
								if (AOM_delete(dataset) != ITK_ok) PrintErrorStack();
							}
						}
					}
				}
				//Delete File Multi CMI2CacheCgr -- END

				//Double DataSet CATIA (CADProd with CIM2AuxPart, but not CADPart)
				int CMI2Product = 0;
				int CMI2AuxPart = 0;
				int CMI2Part = 0;
				if (AOM_refresh(itemrev,1)) PrintErrorStack();
				ITK_CALL(GRM_list_secondary_objects_only(itemrev,relation_type2,&n_attchs_JT,&rellist_JT));
				for(j=0;j<n_attchs_JT;j++)
				{
					dataset=rellist_JT[j];
					if( AOM_ask_value_string(dataset,"object_type",&objtype)!=ITK_ok);
					if(tc_strcmp(objtype,"CMI2Product")==0)
					{
						CMI2Product++;
					}
					if(tc_strcmp(objtype,"CMI2AuxPart")==0)
					{
						CMI2AuxPart++;
					}
					if(tc_strcmp(objtype,"CMI2Part")==0)
					{
						CMI2Part++;
					}
				}
				if(CMI2Product > 0 && CMI2AuxPart > 0 && CMI2Part > 0)
				{
					for(j=0;j<n_attchs_JT;j++)
					{
						dataset=rellist_JT[j];
						if( AOM_ask_value_string(dataset,"object_type",&objtype)!=ITK_ok);
						if(tc_strcmp(objtype,"CMI2Part")==0)
						{
							char *refname2 = NULL;
							tag_t *refobject2	= NULLTAG;
							int result1 = 0;
							int z = 0;
							printf("\n\tNeed to delete");fflush(stdout);
							GRM_list_all_related_objects_only(dataset,&result1,&refobject2);
							printf("\nReleations Count : %d",result1); fflush(stdout);
							for (z = 0; z < result1; ++z)
							{
								if (AOM_ask_value_string(refobject2[z],"type_string",&refname2)!=ITK_ok);
								printf("\nDeleting Releation : %d --- %s",z,refname2); fflush(stdout);
								if (GRM_delete_relation(refobject2[z]) != ITK_ok) PrintErrorStack();
							}
							printf("\nAOM_delete Deleting Dataset : %s",PartID); fflush(stdout);
							if (AOM_refresh(dataset,1)) PrintErrorStack();
							if (AOM_delete(dataset) != ITK_ok) PrintErrorStack();
						}
					}
				}

				JtNo=0; AsmPrt=0;
			}
		}
			}
		}			
		printf("\n============ END Program=====================");fflush(stdout);
		
		ifail = ITK_exit_module(TRUE);
		//printf("\nReturn Value is : %d", ifail);
		if (ifail == ITK_ok)
		{
			//printf("\nTeamcenter Logout Success...");fflush(stdout);
		}
		else
		{
			EMH_ask_error_text(ifail, &cError);
			//printf("\nError is : %s", cError);fflush(stdout);
		}
		//fclose(output);
	}
	return ITK_ok;
}


