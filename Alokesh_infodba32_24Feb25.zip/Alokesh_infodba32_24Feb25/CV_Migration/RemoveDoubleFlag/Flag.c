/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
*------------------------------------------------------------------------------
* Filename		: autologin.c
* Description	: This Utility Mainly Used For AutoLogin in Teamcenter
* Module       	:	        
* Since		    :    
* ENVIRONMENT	: C++, ITK
* History       :
*------------------------------------------------------------------------------
*    Date         	   Name						Description of Change
* 30/03/2023   	   Lokendra Aporiya		          For Removing Flag

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/aom_prop.h>
#include <ae/dataset.h>
#define ITK_err 910001

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);fflush(stdout);
		  exit(0);
		}

		return iFail;
}

int ITK_user_main(int argc, char* argv[])
{
	    int iFail = 0;
	    char* cError = NULL;
		char* username = NULL;
		tag_t tuser = NULLTAG;
		iFail = ITK_auto_login();
		printf("\nReturn Value is : %d", iFail);fflush(stdout);
		
		int n_entries = 1;
		int i;
		tag_t tItemobj = NULLTAG;
		int n_itemobj_found = 0;
		tag_t* titemobj_results = NULLTAG;

		char *PartID = NULL;
		char *PartSequenceID = NULL;
		char *part_type = NULL;
		char *Description = NULL;
		char *object_type = NULL;
		char *Part_ProjID = NULL;
		char *Part_DesgnGrp = NULL;
		char *Revision = NULL;
		tag_t DataSet = NULLTAG;
		tag_t RevObjTag = NULLTAG;
		char *inputfile=NULL;
		
		int Part_Stat_Cnt = 0;
		tag_t *Part_Stat_Lst = NULLTAG;
		int k=0;
		int countRev =0;
		int countRlz =0;
		char *Part_Rlz_Stat = NULL;
		
		inputfile = ITK_ask_cli_argument("-i=");
		FILE *fp;
		fp=fopen(inputfile,"r");

		FILE *fp1;
		fp1 = fopen("Process.txt","w");
		
		char *cEntries[1]  = {"Item ID"};
		char *inputline = NULL;
		
		char **cValues = (char **) MEM_alloc(50 * sizeof(char *));
				
		if (iFail == ITK_ok)
		{
			printf("\nTeamcenter Login Success...");fflush(stdout);
			POM_get_user(&username, &tuser);
			printf("\nUsername = %s", username);fflush(stdout);
		}
		else
		{
			EMH_ask_error_text(iFail, &cError);
			printf("\nError is : %s", cError);fflush(stdout);
		}
		if (cError)
		{
			MEM_free(cError);
		}
		if (username)
		{
			MEM_free(username);
		}
		
				if(fp!=NULL)
				{
					inputline=(char *) MEM_alloc(1000);
					while(fgets(inputline,1000,fp)!=NULL)
					{
						printf("\n\n Input Part: %s",inputline); fflush(stdout);
		
						char *partNoIP = NULL;
						partNoIP = (char *)MEM_alloc(250);
																		
						tc_strcpy(partNoIP, "");					
						partNoIP = strtok(inputline,",");
												
						printf("partNoIP-----------> :%s\n",partNoIP);fflush(stdout);
												
						cValues[0] = partNoIP;

						//ITK_CALL(QRY_find2("Item ID",&tItemobj));
						ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
						printf("\n Return Value From Query Find API is : %d", iFail);fflush(stdout);
						printf("\n Query Found Successfully...");fflush(stdout);

						ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
						printf("\n Return Value From Query Execute API is --------> %d", iFail);fflush(stdout);
					
						printf("\nNo of item returned ---------------------- %d\n",n_itemobj_found);fflush(stdout);
						if(n_itemobj_found>0)
						{
							
							for(i=0;i<n_itemobj_found;i++)
							{
								RevObjTag = titemobj_results[i];
								countRev = 0;
								countRlz = 0;
								ITK_CALL(AOM_ask_value_string(RevObjTag,"item_id",&PartID));
								ITK_CALL(AOM_ask_value_string(RevObjTag,"item_revision_id",&Revision));
								printf("\nPartID :%s\n",PartID);fflush(stdout);
								printf("\nRevision :%s\n",Revision);fflush(stdout);
								
								ITK_CALL(WSOM_ask_release_status_list(RevObjTag,&Part_Stat_Cnt,&Part_Stat_Lst));
								printf("\nPart_Stat_Cnt = %d\n",Part_Stat_Cnt);fflush(stdout);
								
								/* ITK_CALL( POM_length_of_attr(Part_tag, PrtStatLst_AttrID, &PrtStatLst_Length3) );
								ITK_CALL( POM_ask_attr_tags(Part_tag, PrtStatLst_AttrID, 0, PrtStatLst_Length3, &PrtStatLst_Attr_tag3, &is_it_null3, &is_it_empty3 )); */
						
								for(k=0;k<Part_Stat_Cnt;k++)
								{
									AOM_ask_name(Part_Stat_Lst[k], &Part_Rlz_Stat);
									printf("\n Part`s Release status is : %s\n",Part_Rlz_Stat);fflush(stdout);
									if (tc_strcmp(Part_Rlz_Stat,"T5_LcsReview")==0)
									{
										countRev++;
									}
									if (tc_strcmp(Part_Rlz_Stat,"T5_LcsErcRlzd")==0 )
									{
										countRlz++;
									}
								}
								
								if(countRev > 1)
								{
									fprintf(fp1, "%s,%s,MultiReview,%d,%d\n", PartID,Revision,countRev,countRlz );
								}
								else if (countRlz > 1)
								{
									fprintf(fp1, "%s,%s,MultiRelease,%d,%d\n", PartID,Revision,countRev,countRlz );
								}
								else if(countRev > 0 && countRlz > 0)
								{
									fprintf(fp1, "%s,%s,Delete,%d,%d\n", PartID,Revision,countRev,countRlz );

									tag_t PrtClass_id1 = NULLTAG;
									char *PartClass_name1 = NULL;
									tag_t PrtStatLst_AttrID1 = NULLTAG;
									int st_count1 = 0;	
									tag_t *status_list1 = NULLTAG;
									logical	log1;
									int PrtStatLst_Length1 = 0;
									tag_t *PrtStatLst_Attr_tag1 = NULLTAG;
									logical	*is_it_null1 = NULL;
									logical	*is_it_empty1 = NULL;
									int count1 = 0;
									char *PrtRlz_Status1 = NULL;

									printf("\n In Remove_Multiple_Status Function \n");fflush(stdout);
									ITK_CALL(POM_class_of_instance(RevObjTag,&PrtClass_id1)); 
									ITK_CALL(POM_name_of_class(PrtClass_id1,&PartClass_name1));
									printf("\n Part Class Name is : %s\n",PartClass_name1);fflush(stdout);
									ITK_CALL(POM_attr_id_of_attr("release_status_list",PartClass_name1,&PrtStatLst_AttrID1));
									ITK_CALL(WSOM_ask_release_status_list(RevObjTag,&st_count1,&status_list1));
									printf("\n st_count1 is : %d \n",st_count1);fflush(stdout);
									ITK_CALL(POM_unload_instances(1,&RevObjTag));
									ITK_CALL(POM_load_instances(1,&RevObjTag,PrtClass_id1,1));
									ITK_CALL(POM_is_loaded(RevObjTag,&log1));
									if(log1 == 1)
									{
										printf(" Load Success\n " );fflush(stdout);
									}
									else
									{
										printf(" Load Failure\n"  );fflush(stdout);
									}
									ITK_CALL( POM_length_of_attr(RevObjTag, PrtStatLst_AttrID1, &PrtStatLst_Length1) );
									ITK_CALL( POM_ask_attr_tags(RevObjTag, PrtStatLst_AttrID1, 0, PrtStatLst_Length1, &PrtStatLst_Attr_tag1, &is_it_null1, &is_it_empty1 ));
									for(count1=0; count1<PrtStatLst_Length1;count1++)
									{
										AOM_ask_name(PrtStatLst_Attr_tag1[count1], &PrtRlz_Status1);
										printf("\n Release status is : %s",PrtRlz_Status1);fflush(stdout);					
										if((tc_strcmp(PrtRlz_Status1,"T5_LcsReview")==0))	
										{
											ITK_CALL(POM_remove_from_attr(1,&RevObjTag,PrtStatLst_AttrID1,count1,1));
											ITK_CALL(POM_save_instances(1,&RevObjTag,1));
											ITK_CALL(POM_refresh_instances(1,&RevObjTag,PrtClass_id1,2));
											ITK_CALL(AOM_lock(RevObjTag));
											ITK_CALL(AOM_save_without_extensions(RevObjTag));
											ITK_CALL(AOM_refresh(RevObjTag,1));
											ITK_CALL(AOM_unlock(RevObjTag));
											printf("\n Release Status Removed Successfully \n");fflush(stdout);
											break;
										}
										
									}
								}
								else
								{
									fprintf(fp1, "%s,%s,Ok,%d,%d\n", PartID,Revision,countRev,countRlz );
								}
							}
							printf("\n=============================================================================");fflush(stdout);
						}
						
					}
				}

			fclose(fp1);
			fclose(fp);

		iFail = ITK_exit_module(TRUE);
		printf("\nReturn Value is : %d", iFail);
		if (iFail == ITK_ok)
		{
			printf("\nTeamcenter Logout Success...");fflush(stdout);
		}
		else
		{
			EMH_ask_error_text(iFail, &cError);
			printf("\nError is : %s", cError);fflush(stdout);
		}
		
	
	return ITK_ok;
}


