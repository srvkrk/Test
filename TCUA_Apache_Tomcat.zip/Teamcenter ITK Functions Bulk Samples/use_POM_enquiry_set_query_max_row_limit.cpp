/* The function shows how to use POM_enquiry_set_query_max_row_limit with a large POM_Enquiry request.

It queries all 'ItemRevision' objects, a 100 at a time, and orders the objects by Item.item_id and ItemRevision.item_revision_id. 

Note: ITK_ERR is an personal error checking mechanism, replace with your own. */

void POM_Enquiry_ItemRevInASC_order2()
{
	int ifail = 0;
	int totalRows = 0;
	int rows = 0;
	int cols = 0;
	int offset = 0;
	void*** ppReport = nullptr;
	const char* pQry1 = "QueryItemRevASCBy100";
	const char* select_attrs_ItemRev[] = { "puid" };

	try
	{
		ITK_ERR(POM_enquiry_create(pQry1));
		ITK_ERR(POM_enquiry_add_select_attrs(pQry1, "ItemRevision", 1, select_attrs_ItemRev));

		/* limit ItemRevision.items_tag == item.puid */
		ITK_ERR(POM_enquiry_set_join_expr(pQry1, "join_expr1", "ItemRevision", "items_tag", POM_enquiry_equal, "Item", "puid"));
		ITK_ERR(POM_enquiry_set_where_expr(pQry1, "join_expr1"));

		/* order by 'Item.item_id' ASC */
		ITK_ERR(POM_enquiry_add_order_attr(pQry1, "Item", "item_id", POM_enquiry_asc_order));
		/* order by 'ItemRevision.item_revision_id' ASC */
		ITK_ERR(POM_enquiry_add_order_attr(pQry1, "ItemRevision", "item_revision_id", POM_enquiry_asc_order));

		do 
		{
			/* request the next 100 items */
			ITK_ERR(POM_enquiry_set_query_max_row_limit(pQry1, offset, 100));
			/* execute query */
			ITK_ERR(POM_enquiry_execute(pQry1, &rows, &cols, &ppReport));

			for (int i = 0; i < rows; i++)
			{
				void** col = ppReport[i];

				for (int j = 0; j < cols; j++)
				{
					if (j == 0)
					{
						char* UID = NULL;
						ITK__convert_tag_to_uid(*(tag_t*)col[j], &UID);
						printf("%s, ", UID); // print 'UID'
						MEM_free(UID);
					}
					else
						printf("%s, ", (char*)col[j]);
				}
				printf("\n");
			}

			if (ppReport != NULL)
			{
				MEM_free(ppReport);
				ppReport = nullptr;
			}

			totalRows += rows;
			printf("Rows: %d\n", rows);
			offset = offset + 100;
		} while (rows > 0);

		printf("Total Rows: %d\n", totalRows);
		ITK_ERR(POM_enquiry_delete(pQry1));
	}
	catch (const std::exception& err)
	{
		std::cout << "Error: " << err.what() << std::endl;
	}
}