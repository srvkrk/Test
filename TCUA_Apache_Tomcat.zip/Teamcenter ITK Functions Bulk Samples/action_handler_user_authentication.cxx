/*
This example consists of two files. File 'itk_gtac_exits.c' used to register the custom handler in Teamcenter and file 'user_authentication_handler.cpp' to show how the user authentication is implemented.

The build target is .dll/.so and "TC_customization_libraries" preference is used to load this runtime binary at start up. 
*/


/****** itk_gtac_exits.c *******/
#include <ict/ict_userservice.h>
#include <tccore/custom.h>
#include <user_exits/user_exits.h>

extern DLLAPI int register_pre_init_handlers(int* decision, va_list list);

extern DLLAPI int itk_gtac_exits_register_callbacks()
{
    TC_write_syslog("itk_gtac_exits_register_callbacks\n");

    CUSTOM_register_exit("itk_gtac_exits", "USER_preinit_module", (CUSTOM_EXIT_ftn_t)register_pre_init_handlers);

    return ITK_ok;
}

/****** user_authentication_handler.cpp *******/
#include <tc/tc_startup.h>
#include <pom/pom/pom_user_authentication.h>

#include <string>
#include <map>

/* Following script was used to register the key/secret (-k/-s) for a specific user in Teamcenter. The values for key/secret are user supplied. */
/*
@echo off
setlocal

set TC_ROOT=d:\Tc14.1\tc_root
set TC_DATA=d:\Tc14.1\tc_data
call %TC_DATA%\tc_profilevars.bat

cd %TC_ROOT%\bin

install -set_eim_key -u=gtac -p=gtac -g=dba -i=login -k=pXlxZe1gsWQzGwmE -s=Js2NGb3P3La8k8kgQ1

endlocal
*/

// See header file: %TC_ROOT%\include\pom\pom\pom_user_authentication.h  for more informaiton.

std::map<std::string, std::string> lookupMap{{"pXlxZe1gsWQzGwmE", "Js2NGb3P3La8k8kgQ1"}}; // add more 'user' key/secret values for different users to login.

extern "C" void register_user_authentication_handler(const char* user, const char* password, const char* key)
{
	logical status = false;

	TC_write_syslog("call register_user_authentication_handler");

	if (lookupMap.count(key) > 0) // lookupMap can also be your own custom lookup mechanism. 
	{
		status = POM_user_auth_default_checker(user, password);
		
		/* implement your user authentication here */

		POM_user_authentication_cb(lookupMap[key].c_str(), status);
	}
}

extern "C" int register_pre_init_handlers(int* decision, va_list list)
{
	TC_write_syslog("call register_pre_init_handlers");

	POM_set_user_authentication_fn(register_user_authentication_handler, NULL);

	return 0;
}