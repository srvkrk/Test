package com.tml.classification.modules;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
//import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.soa.exceptions.NotLoadedException;
import com.tml.techspec.dialogs.ModuleClassificationDialog;
import com.tml.techspec.dialogs.UpdateTechSpecDialog;

public class TechSpecUtil {	
	//
	public void invokeDlg(Shell shell,TCSession session,TCComponentItemRevision selectedObj)
	{
		 ICOValues val =null;
	/*selectedobject=(AIFComponentContext)((IStructuredSelection)selection).getFirstElement();
    
	   
    if(selectedobject.getComponent() instanceof TCComponentItemRevision)
    {
    	System.out.println("Allowed this option");
    }
    else
    {
    	System.out.println("part Type is not Vehicle/Module, option only valid for Vehicle/Module");
		
		 MessageBox messageBox1 = new MessageBox(shell, SWT.ICON_INFORMATION);
               messageBox1.setText("Information.");
               messageBox1.setMessage("Part Type Vehicle/Module Revision only allowed for this option ");
               messageBox1.open();  
               
               return null;
    }
    	
    TCComponentItemRevision selectedObj = (TCComponentItemRevision) selectedobject.getComponent();	*/
   String SelobjType= selectedObj.getType();
   try {
	System.out.println("selectedObj.getTCProperty.getDisplayableValue()="+selectedObj.getPropertyDisplayableValue("t5_TechSNumDes"));
} catch (NotLoadedException e2) {
	// TODO Auto-generated catch block
	e2.printStackTrace();
}
   System.out.println("\nSelobjType="+SelobjType);
   if(SelobjType.equals("T5_TSCompRevision"))
   {
	 
	   TCComponentItemRevision VCObj = null;
	try {
		VCObj = (TCComponentItemRevision) selectedObj.getTCProperty("t5_TechSpecForPart").getReferenceValue();
		System.out.println("VCObj:-"+VCObj);
		if(VCObj==null) //need to discuss for this msg
		{
			System.out.println("Tech Spec does not relate with any vehicle, so Update Technical specification attribute can't invoke");
			
			MessageBox.post(shell,"Tech Spec does not relate with any vehicle, so Update Technical specification attribute can't invoke !!!","WARNING",SWT.ICON_WARNING);
			
			/* MessageBox messageBox1 = new MessageBox(shell, SWT.ICON_INFORMATION);
	               messageBox1.setText("Warning.");
	               messageBox1.setMessage("Tech Spec does not relate with any vehicle, so Update Technical specification attribute can't invoke !!!");
	               messageBox1.open();  */
	               
	               return;
		}
		
	} catch (TCException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		if(VCObj!=null)
		{
			UpdateTechSpecDialog UpdTechObj= new UpdateTechSpecDialog(shell,session,VCObj,selectedObj);
		    UpdTechObj.open();
		}
	   
    
   }
   else
   {
		   String modulenum=null;
		   String SelectedObjType=null;
		   String BuinessUnit=null;
		   String revid=null;
		try {
			modulenum = selectedObj.getPropertyDisplayableValue("item_id");
			revid = selectedObj.getPropertyDisplayableValue("item_revision_id");
			System.out.println("modulenum====="+modulenum +"revid"+revid);
			//for VC Update
			SelectedObjType = selectedObj.getPropertyDisplayableValue("t5_PartType");
			System.out.println("SelectedObjType:-"+SelectedObjType);
			if(SelectedObjType.equals("Vehicle") || SelectedObjType.equals("Module") )
			{
				System.out.println("part Type is Vehicle/Module, process can execute");
			}
			else
			{
				
				System.out.println("part Type is not Vehicle/Module, option only valid for Vehicle/Module");
			
				MessageBox.post(shell,"Part Type Vehicle/Module Revision only allowed for this option !!","WARNING",SWT.ICON_WARNING);
				/* MessageBox messageBox1 = new MessageBox(shell, SWT.ICON_INFORMATION);
		               messageBox1.setText("Information.");
		               messageBox1.setMessage("Part Type Vehicle/Module Revision only allowed for this option ");
		               messageBox1.open();  */
		               
		               return ;
				
			}
			if(SelectedObjType.equals("Vehicle") )
			{
				TCComponent[] TechSpecObj=  selectedObj.getTCProperty("T5_VCSpec").getReferenceValueArray();
				if(TechSpecObj!=null && TechSpecObj.length>0)
				{
					BuinessUnit = TechSpecObj[0].getPropertyDisplayableValue("t5_VCClassName");
					System.out.println("BuinessUnit:----------  "+BuinessUnit);
				}
				
				
			}
			
			
			
		} catch (Exception  e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
			System.out.println("Selected part Number====="+selectedObj.toString());
			
			GetClassifiedAttr getProps= new GetClassifiedAttr(selectedObj,session);
			try {
				val=getProps.getICOProps();
			} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ModuleClassificationDialog updateDialog= null;//new ModuleClassificationDialog(shell,"","",modulenum,SelectedObjType,session);
			String moduleaddress="";
				
			if(SelectedObjType.equals("Vehicle"))
			{
				moduleaddress=BuinessUnit+"VCATTR01";
				//updateDialog= new ModuleClassificationDialog(shell,BuinessUnit+"VCATTR01",modulenum+"/NR;1",modulenum,SelectedObjType,session);
				//Added on 27082018
				
				
				
				try {
					TCComponent[] TechSpecObj=  selectedObj.getTCProperty("T5_VCSpec").getReferenceValueArray();
					System.out.println("TechSpecObj.length="+TechSpecObj.length);
					if(TechSpecObj!=null && TechSpecObj.length>0)
					{
						BuinessUnit = TechSpecObj[0].getPropertyDisplayableValue("t5_VCClassName");
						System.out.println("BuinessUnit:----------  "+BuinessUnit);
					}
					else
					{
						System.out.println("Vehicle does not relate with any Tech Spec, so Update Technical specification attribute can't invoke");
						
						MessageBox.post(shell,"Vehicle does not relate with any Tech Spec, so Update Technical specification attribute can't invoke !!!","WARNING",SWT.ICON_WARNING);
						/* MessageBox messageBox1 = new MessageBox(shell, SWT.ICON_INFORMATION);
				               messageBox1.setText("Warning.");
				               messageBox1.setMessage("Vehicle does not relate with any Tech Spec, so Update Technical specification attribute can't invoke !!!");
				               messageBox1.open();  */
				               
				               return ;
					}
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//End
			}
			else 
			{
				try {
					moduleaddress=selectedObj.getPropertyDisplayableValue("t5_ModuleAddress");
				} catch (NotLoadedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//updateDialog= new ModuleClassificationDialog(shell,"","",modulenum,SelectedObjType,session);
			}
			
			//updateDialog= new ModuleClassificationDialog(shell,moduleaddress,modulenum+"/NR;1",modulenum,SelectedObjType,session);
			updateDialog= new ModuleClassificationDialog(shell,moduleaddress,modulenum+"/"+revid,modulenum,SelectedObjType,session);
			if(val !=null)
				updateDialog.updateICOVal(val)	;
			updateDialog.open();
}	
	}
	
}
