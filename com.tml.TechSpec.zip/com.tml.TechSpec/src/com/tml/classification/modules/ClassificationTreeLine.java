package com.tml.classification.modules;

import java.util.ArrayList;

import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationObject;

public class ClassificationTreeLine {
	  private String classifiedObject;
	  private String moduleAddress;
	  private String objectid;
	  private String objectid_moduleAddress;
	  private TCComponentItemRevision itemrev;
	  private ClassificationObject clsobjs;
		private ArrayList<ClassificationTableLine> attrList;
	 public ClassificationTreeLine(String classifiedObject,
			String moduleAddress, String objectid,TCComponentItemRevision itemrev,ClassificationObject clsobjs) {
		super();
		this.classifiedObject = classifiedObject;
		this.moduleAddress = moduleAddress;
		this.itemrev = itemrev;
		this.clsobjs = clsobjs;
		this.objectid=objectid;
		attrList = new ArrayList<ClassificationTableLine> ();
	}

	
	@Override
	public String toString() {
		return "ClassificationTreeLine [classifiedObject=" + classifiedObject
				+ ", moduleAddress=" + moduleAddress + ", attrList=" + attrList
				+ "]";
	}
	public String getClassifiedObject() {
		return classifiedObject;
	}
	public void setClassifiedObject(String classifiedObject) {
		this.classifiedObject = classifiedObject;
	}
	public String getModuleAddress() {
		return moduleAddress;
	}
	public void setModuleAddress(String moduleAddress) {
		this.moduleAddress = moduleAddress;
	}
	public ArrayList<ClassificationTableLine> getAttrList() {
		return attrList;
	}
	public void setAttrList(ArrayList<ClassificationTableLine> attrList) {
		this.attrList = attrList;
	}


	public TCComponentItemRevision getItemrev() {
		return itemrev;
	}


	public void setItemrev(TCComponentItemRevision itemrev) {
		this.itemrev = itemrev;
	}


	public ClassificationObject getClsobjs() {
		return clsobjs;
	}


	public void setClsobjs(ClassificationObject clsobjs) {
		this.clsobjs = clsobjs;
	}


	public String getObjectid() {
		return objectid;
	}


	public void setObjectid(String objectid) {
		this.objectid = objectid;
	}


	public String getObjectid_moduleAddress() {
		return moduleAddress+"["+objectid+"]";
	}
	  
	  

}
