// Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
// ==================================================
// Copyright 2011.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

package com.tml.classification.modules;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Text;

import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationObject;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationProperty;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationPropertyValue;
import com.teamcenter.services.rac.classification._2007_01.Classification.CreateClassificationObjectsResponse;
import com.teamcenter.services.rac.classification._2007_01.Classification.UpdateClassificationObjectsResponse;
import com.teamcenter.services.rac.classification.ClassificationService;
import com.teamcenter.soa.client.model.ServiceData;

//import com.teamcenter.clientx.AppXSession;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;



/**
 *   This sample program create and update the standalone ICO.
 *
 *   The following data must be created before executing the test.
 *      Create a string attribute with ID=4001
 *      Create Class with ID=ICM4001
 *      Add the attribute 4001 to the class ICM4001.
 *      
 *   Refer TDoc for creating classification data.
 */
public class CreateOrUpdateICOSample
    
{
    ClassificationObject[]                  newICOs             = new ClassificationObject[1];
    CreateClassificationObjectsResponse     createICOResponse;
    UpdateClassificationObjectsResponse     updateICOResponse;
    private TCSession session;
    
    private Text text;
	private String ModuleAddress;
	private String ObjectID;
	private HashMap <String,Object> namevalueP;
	private ClassificationLineProvider tabLineModel;
	private ArrayList<ClassificationTableLine> classificationList;
	private Table table;
	private TableViewer tableViewer;
	private String moduleNum;
	private ClassificationObject clobj;
	private ServiceData data;
    /**
     *  This API create and update the standalone ICO object.
     * @throws ServiceException
     */
    public CreateOrUpdateICOSample(ClassificationObject clobj,String ModuleAddress,String ObjectID,String moduleNum,HashMap <String,Object> namevalueP,TCSession session) {
    	
    	
		super();
		// TODO Auto-generated constructor stub
		this.ModuleAddress=ModuleAddress;
		this.ObjectID=ObjectID;
		this.namevalueP=namevalueP;
		this.session=session;
		this.moduleNum=moduleNum;
		this.clobj=clobj;
		System.out.println("1ModuleAddress="+ModuleAddress);
		System.out.println("InstanceID="+ObjectID);
		System.out.println("session="+session);
		
		
	}
    
 
    public TCComponentItem  QryIcoTcComponent(TCSession tcsession,String item_id) throws TCException
    {
               
               System.out.println(" In Query for IcoTCComponent For ::"+item_id);
               
               TCComponentQueryType tccomponentquerytype = (TCComponentQueryType) tcsession.getTypeComponent("ImanQuery");
                   
                                            TCComponentQuery mmcomponentquery = (TCComponentQuery) tccomponentquerytype.find("Item ID");
                                            
                                            TCComponent []qryResults           = null;
                                            String []qryNames                                          = new String[]{"Item ID"};
                                            String []qryValues                                          = new String[1];
                                            
                                            qryValues[0]=item_id;
                                            //qryValues[1]="T9TCUAToTCETransfer";   
                                            
                                            
                                                 
                                            if (mmcomponentquery != null)
                                                 
                                            {
                                                 
                                            	qryResults= mmcomponentquery.execute( qryNames, qryValues );
                                            	return (TCComponentItem) qryResults[0];
                                                         
                                            }
                                            
                                            
                                            
                                            return null;
                                            
                                            
               
               
    }


protected boolean ServiceDataError(final ServiceData data)
{
	this.data=data;
    if(data.sizeOfPartialErrors() > 0)
    {
            for(int i = 0; i < data.sizeOfPartialErrors(); i++)
            {
                     for(String msg :
data.getPartialError(i).getMessages())
                             System.out.println("ServiceDataError:"+msg);
            }

            return true;
    }

    return false;
}

public ServiceData getServiceData()
{
	return this.data;
}

    
    public void testCreateAndUpdateICO()throws ServiceException
    {
        ClassificationService clsService = ClassificationService.getService(session);
        System.out.println("Calling Classification::createClassificationObjects() ...");

       
        ClassificationProperty[] ico_props = new ClassificationProperty[namevalueP.size()];
        ClassificationObject[] icos = new ClassificationObject[1];
int count=0;
TCComponentItemRevision ICOItemRev= null;
        for (Map.Entry<String, Object> entry : namevalueP.entrySet())
        {
        	/* ClassificationPropertyValue[] ico_prop_values1 = new ClassificationPropertyValue[1];
		    System.out.println(entry.getKey() + " = " + entry.getValue());        
	        ico_prop_values1[0] = new ClassificationPropertyValue();
	        ico_prop_values1[0].dbValue = (String) entry.getValue();
	        */
	        ClassificationPropertyValue propval= new ClassificationPropertyValue();
	        propval.dbValue= (String) entry.getValue();
	        ico_props[count] = new ClassificationProperty();
	        ico_props[count].attributeId =Integer.parseInt(entry.getKey()) ;
	        ico_props[count].values =new ClassificationPropertyValue[]{propval};//ico_prop_values1};// ico_prop_values1;
	        
	       // System.out.println(ico_props[count].attributeId + " = " + ico_prop_values1[0].dbValue);
	        System.out.println(ico_props[count].attributeId + " = " + propval.dbValue);
	        count++;
        }
        
        //Qry TcComponent 
        
        try {
        	
        	ICOItemRev=QryIcoTcComponent(session,moduleNum).getLatestItemRevision();
        	
        	System.out.println("ICOItemRev="+ICOItemRev);
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        //End 
        icos[0] = new ClassificationObject();
        icos[0].classId = ModuleAddress;
        icos[0].clsObjTag = null;
        icos[0].instanceId = ObjectID;
        icos[0].properties = ico_props;
        icos[0].unitBase = "METRIC";
        // wsoId is null for standalone ICO. 
        System.out.println("b4 ICOItemRev set ="+ICOItemRev);
        icos[0].wsoId = ICOItemRev;
        System.out.println("clobj="+clobj);
        // Create the ICO object
        if(clobj==null)
        {
        createICOResponse = clsService.createClassificationObjects( icos );
        
        if ( createICOResponse.data.sizeOfPartialErrors() > 0)
        {
         ServiceDataError(createICOResponse.data);
          //  throw new ServiceException( "ClassificationService.createClassificationObjects returned a partial Error.");
    }
        }
        System.out.println("... completed Classification::createClassificationObjects()");
      
        //if ( createICOResponse.clsObjs.length > 0 )
        if(clobj!=null)
        {
            // Set the data on classification property value for updating on ICO
        	int count1=0;
        	/*for (Map.Entry<String, Object> entry : namevalueP.entrySet())
            {
            icos[0].properties[count1].values[0].dbValue = (String) entry.getValue() ;
            count1++;
            }*/
            // Set the classification object tag to be updated.
          //  icos[0].clsObjTag = createICOResponse.clsObjs[0].clsObjTag;
            icos[0]=clobj;
            icos[0].properties = ico_props;
          updateICOResponse = clsService.updateClassificationObjects( icos );
            System.out.println("... completed Classification::updateClassificationObjects()");
            
            if ( updateICOResponse.data.sizeOfPartialErrors() > 0)
            {
            	 ServiceDataError(updateICOResponse.data);
                throw new ServiceException( "ClassificationService.updateClassificationObjects returned a partial Error.");
            
            }
            int objCount = updateICOResponse.clsObjs.length ;
            if ( objCount <= 0 )
            {
                System.out.println("Nothing was done");
            }
            else
            {               
                ClassificationObject[]  updatedICOs = new ClassificationObject[objCount];
                for ( int jnx = 0 ;jnx < objCount ; jnx++ )
                {
                    updatedICOs[jnx] = updateICOResponse.clsObjs[jnx];

                    System.out.println( "Class ID: " + updatedICOs[jnx].classId );
                    System.out.println( "ICO ID: " + updatedICOs[jnx].instanceId );
                    System.out.println( "Unit Base: " + updatedICOs[jnx].unitBase );
                    System.out.println( "WSO Id: " + updatedICOs[jnx].wsoId );
                    for( int attrIndex=0; attrIndex < updatedICOs[jnx].properties.length; attrIndex++)
                    {
                        if( updatedICOs[jnx].properties[attrIndex].attributeId == ico_props[0].attributeId )
                        {
                            System.out.println( " Updated Attr ID: " + ico_props[0].attributeId );
                           // if(updatedICOs[jnx].properties[attrIndex].values!= null)
                          //  System.out.println( "  Attr value: " + updatedICOs[jnx].properties[attrIndex].values[0].dbValue );
                        }
                    }
                 }
            }
                   
        }
    }
	
}
