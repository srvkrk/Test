package com.tml.classification.modules;

public class ClassificationTableLine {
	  private String SrlNo;
	  private String AttrID;
	  private String AttrName;
	  private String AttrValue;
	  private String Unit;
	  private String LovID;
	  private ClassificationTreeLine parent;
	public ClassificationTableLine(String srlNo, String attrID,
			String attrName, String attrValue, String unit, String lovID) {
		super();
		SrlNo = srlNo;
		AttrID = attrID;
		AttrName = attrName;
		AttrValue = attrValue;
		Unit = unit;
		LovID = lovID;
	}
	public String getSrlNo() {
		return SrlNo;
	}
	public void setSrlNo(String srlNo) {
		SrlNo = srlNo;
	}
	public String getAttrID() {
		return AttrID;
	}
	public void setAttrID(String attrID) {
		AttrID = attrID;
	}
	public String getAttrName() {
		return AttrName;
	}
	public void setAttrName(String attrName) {
		AttrName = attrName;
	}
	public String getAttrValue() {
		return AttrValue;
	}
	public void setAttrValue(String attrValue) {
		AttrValue = attrValue;
	}
	public String getUnit() {
		return Unit;
	}
	public void setUnit(String unit) {
		Unit = unit;
	}
	public String getLovID() {
		return LovID;
	}
	public void setLovID(String lovID) {
		LovID = lovID;
	}
	
	
	
	public ClassificationTreeLine getParent() {
		return parent;
	}
	public void setParent(ClassificationTreeLine parent) {
		this.parent = parent;
	}
	@Override
	public String toString() {
		return "ClassificationTableLine [SrlNo=" + SrlNo + ", AttrID=" + AttrID
				+ ", AttrName=" + AttrName + ", AttrValue=" + AttrValue
				+ ", Unit=" + Unit + ", LovID=" + LovID + "]";
	}
	  
	  
	  
	
	  
	  
	  

}
