// Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
// ==================================================
// Copyright 2011.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

package com.tml.classification.modules;

import com.teamcenter.rac.aif.AIFDesktop;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.services.rac.classification._2009_10.Classification.KeyLOVDefinition2;
import com.teamcenter.services.rac.classification._2009_10.Classification.KeyLOVEntry;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

//import com.teamcenter.clientx.AppXSession;
import com.teamcenter.services.rac.classification.ClassificationService;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;

/**
 *  This sample program get the keyLOV definitions for the specified key LOV id's.
 *  
 *  The following data must be created before executing this test.
 *     Create KeyLov with ID=-2894
 *     Add set of key value entries to -2894
 *     
 *  Refer TDoc for classification data creation
 *  
 */

public class GetKeyLOVs2Sample  
{
      
   /**
   * get the KeyLOV definitions from keyLOV ID's.
   * 
   * @throws ServiceException
   */
    public ArrayList<String> testGetKeyLOVs2(String lovid)throws ServiceException
    {
    	TCSession session = (TCSession)AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
        ClassificationService clsService = ClassificationService.getService(session);
        String[] keyLOVIds = new String[1];
        keyLOVIds[0] =lovid;
        System.out.println("Calling the SOA getKeyLOVs2");
        com.teamcenter.services.rac.classification._2009_10.Classification.GetKeyLOVsResponse2 response = clsService.getKeyLOVs2( keyLOVIds );
        if ( response.data.sizeOfPartialErrors() > 0)
           throw new ServiceException( "ClassificationService.getKeyLOVs2 returned a partial Error.");
        @SuppressWarnings("unchecked")
        Map<String, KeyLOVDefinition2> keyLOVs = response.keyLOVs;
        System.out.println("*****Lov Details******* "+keyLOVs.size());
        Set<String> keys = keyLOVs.keySet();
        ArrayList<String> lovlist=new ArrayList<String>();
        for(Iterator<String> itr = keys.iterator();itr.hasNext();)
        {
            String id = itr.next();
            KeyLOVDefinition2 lovDef = keyLOVs.get( id );
            System.out.println("KeyLOV Id             : "+lovDef.id);
            System.out.println("KeyLOV Name           : "+lovDef.name);
            System.out.println("KeyLOV Options        : "+lovDef.options);
            System.out.println("KeyLOV Owning Site    : "+lovDef.owningSite.getUid());
            System.out.println("KeyLOV tag         : "+lovDef.keyLovtag.getUid());
            System.out.println("KeyLOV Share Sites : "+lovDef.sharedSites);
            KeyLOVEntry[] keyLOVEntries =lovDef.keyLovEntries;

            System.out.println("Number of KeyLOV's : "+keyLOVEntries.length);
            System.out.println("*************************************************************");
            
           lovlist.add("");
            for(int i=0;i<keyLOVEntries.length;i++)
            {
                KeyLOVEntry keyLOVEntries1 = lovDef.keyLovEntries[i];
                System.out.println("KeyLOV Entry Key     : "+keyLOVEntries1.lovKey);
                System.out.println("KeyLOV Entry Value   : "+keyLOVEntries1.lovValue);
                System.out.println("Deprecated Status : "+keyLOVEntries1.deprecatedSatus);
                System.out.println("*************************************************************");
                lovlist.add(keyLOVEntries1.lovKey+" "+keyLOVEntries1.lovValue);
            }
        }
        
        return lovlist;

    }
}
