package com.tml.classification.modules;

import java.util.ArrayList;

import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentBOMLine;
import com.teamcenter.rac.kernel.TCComponentBOMWindow;
import com.teamcenter.rac.kernel.TCComponentBOMWindowType;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentRevisionRule;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationObject;
import com.teamcenter.soa.exceptions.NotLoadedException;



public class BOMExpansion {

	
	public BOMExpansion() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ClassificationTreeLine setclsValues(TCComponentItemRevision assemblyRevision,TCSession tcsession) throws TCException
	{
		
		  System.out.println("inside the   fun setclsValues= "+assemblyRevision.toDisplayString()); 
		 GetClassifiedAttr getProps= new GetClassifiedAttr(assemblyRevision,tcsession);
 		ClassificationTreeLine treeline=null;
 		String ModuleAddress=null;
 		String ObjectID=null;
 		String childrevDispStr=null;
 		String SelectedObjType=null;
			String BuinessUnit = null;
			String itemID=null;
			String revid=null;
 		ClassificationObject clsobjs=null;
 		try {
 			ICOValues icoval=getProps.getICOProps();
 			if(icoval != null)
   			{
					ModuleAddress=icoval.getCid();
					ObjectID=icoval.getIcoId();
					childrevDispStr=assemblyRevision.toDisplayString();
					clsobjs=icoval.getClsobjs();					
					
			    }
 			else
 			{
 				
 				try {
						SelectedObjType = assemblyRevision.getPropertyDisplayableValue("t5_PartType");
						System.out.println("SelectedObjType:-"+SelectedObjType);
	    				if(SelectedObjType.equals("Vehicle") )
	    				{
	    					TCComponent[] TechSpecObj=  assemblyRevision.getTCProperty("T5_VCSpec").getReferenceValueArray();
	    					if(TechSpecObj!=null && TechSpecObj.length>0)
	    					{
	    						BuinessUnit = TechSpecObj[0].getPropertyDisplayableValue("t5_VCClassName");
	    						System.out.println("BuinessUnit:----------  "+BuinessUnit);
	    						ModuleAddress=BuinessUnit+"VCATTR01";
	    						itemID=assemblyRevision.getPropertyDisplayableValue("item_id");
	    						revid=assemblyRevision.getPropertyDisplayableValue("item_revision_id");
	    						ObjectID=itemID+"/"+revid;
	    						childrevDispStr=assemblyRevision.toDisplayString();
	    						
	    					}
	    					
	    					
	    				}
	    				else
	    					//if(SelectedObjType.equals("Vehicle") )
		    				{
		    					//TCComponent[] TechSpecObj=  assemblyRevision.getTCProperty("T5_VCSpec").getReferenceValueArray();
		    					
		    						//BuinessUnit = TechSpecObj[0].getPropertyDisplayableValue("t5_VCClassName");
		    						//System.out.println("BuinessUnit:----------  "+BuinessUnit);
		    						ModuleAddress=assemblyRevision.getPropertyDisplayableValue("t5_ModuleAddress");
		    						System.out.println("ModuleAddress:----------  "+ModuleAddress);
		    						itemID=assemblyRevision.getPropertyDisplayableValue("item_id");
		    						revid=assemblyRevision.getPropertyDisplayableValue("item_revision_id");
		    						ObjectID=itemID+"/"+revid;
		    						childrevDispStr=assemblyRevision.toDisplayString();
		    						
		    					
		    					
		    					
		    				}
					} catch (NotLoadedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
 				
 			}
 			
 			System.out.println("ModuleAddress-  "+ModuleAddress +"BuinessUnit="+BuinessUnit +"itemID="+itemID +"revid="+revid +"ObjectID="+ObjectID +"childrevDispStr="+childrevDispStr);
 			treeline =new ClassificationTreeLine(childrevDispStr, ModuleAddress,ObjectID,assemblyRevision,clsobjs);
				//ClassifyList.add(treeline);
 		} catch (ServiceException e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
       return treeline;
       
	}
	
	public ArrayList<ClassificationTreeLine> getTCUAStructure(TCSession tcsession,TCComponentItemRevision assemblyRevision) throws TCException
    {

    //     TCComponentItemRevision assemblyRevision=(TCComponentItemRevision)assemblyRevision1;
		 ArrayList<ClassificationTreeLine> ClassifyList=new  ArrayList<ClassificationTreeLine>();

          TCComponent[] bvr = assemblyRevision.getRelatedComponents("structure_revisions");// get bvrs
          
          //if(bvr.length==0) return tcuabom;//Modified on 08-12-15
          
          /*System.out.println("Printing BVR");
          for(int k=0;k<bvr.length;k++)
          {
                 System.out.println(bvr[k].getObjectString());
          }
          
          TCComponent[] bv=assemblyRevision.getRelatedComponents("bom_view_tags");
          
          System.out.println("Printing BV");
          
          for(int k=0;k<bv.length;k++)
          {
                 System.out.println(bv[k].getObjectString());
          }
          */
          
          System.out.println("Listing All Revision Rule");
          
          TCComponentRevisionRule[] revrule=TCComponentRevisionRule.listAllRules(tcsession);
          String revrulename="Latest Working";
          TCComponentRevisionRule currentrevrule=null;
          for(int j=0;j<revrule.length;j++)
          {
                 
                 if(revrulename.equals(revrule[j].getProperty("object_name")))
                 {
                        currentrevrule=revrule[j];
                              break;
                 }
                 
                 //System.out.println(revrulename);
                 
          }
          
          System.out.println("Found the Revision Rule "+revrulename);
          
          TCComponentBOMWindowType bowWinType = (TCComponentBOMWindowType )tcsession.getTypeComponent("BOMWindow"); 
          TCComponentBOMWindow bomWin = bowWinType.create(currentrevrule);       // create bom window configured with the default revision rule 
          //TCComponentBOMLine bl= bomWin.setWindowTopLine(_tcItem, itemRev, null, null);
          
          //Modified on 08-12-15
          TCComponentBOMLine bl= bomWin.setWindowTopLine(null, assemblyRevision,null, null);
          
          //TCComponentBOMLine bl= bomWin.setWindowTopLine(null, assemblyRevision,null, bvr[0]);
          
          //To set the bomline for classification of Techspec's single level
         /* GetClassifiedAttr getProps= new GetClassifiedAttr(assemblyRevision,tcsession);
    		ClassificationTreeLine treeline=null;
    		String ModuleAddress=null;
    		String ObjectID=null;
    		String childrevDispStr=null;
    		String SelectedObjType=null;
			String BuinessUnit = null;
			String itemID=null;
			String revid=null;
    		ClassificationObject clsobjs=null;
    		try {
    			ICOValues icoval=getProps.getICOProps();
    			if(icoval != null)
      			{
					ModuleAddress=icoval.getCid();
					ObjectID=icoval.getIcoId();
					childrevDispStr=assemblyRevision.toDisplayString();
					clsobjs=icoval.getClsobjs();					
					
  			    }
    			else
    			{
    				
    				try {
						SelectedObjType = assemblyRevision.getPropertyDisplayableValue("t5_PartType");
						System.out.println("SelectedObjType:-"+SelectedObjType);
	    				if(SelectedObjType.equals("Vehicle") )
	    				{
	    					TCComponent[] TechSpecObj=  assemblyRevision.getTCProperty("T5_VCSpec").getReferenceValueArray();
	    					if(TechSpecObj!=null && TechSpecObj.length>0)
	    					{
	    						BuinessUnit = TechSpecObj[0].getPropertyDisplayableValue("t5_VCClassName");
	    						System.out.println("BuinessUnit:----------  "+BuinessUnit);
	    						ModuleAddress=BuinessUnit+"VCATTR01";
	    						itemID=assemblyRevision.getPropertyDisplayableValue("item_id");
	    						revid=assemblyRevision.getPropertyDisplayableValue("item_revision_id");
	    						ObjectID=itemID+"/"+revid;
	    						childrevDispStr=assemblyRevision.toDisplayString();
	    						
	    					}
	    					
	    					
	    				}
					} catch (NotLoadedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    				
    			}
    			
    			System.out.println("ModuleAddress-  "+ModuleAddress +"BuinessUnit="+BuinessUnit +"itemID="+itemID +"revid="+revid +"ObjectID="+ObjectID +"childrevDispStr="+childrevDispStr);
    			treeline =new ClassificationTreeLine(childrevDispStr, ModuleAddress,ObjectID,assemblyRevision,clsobjs);
				ClassifyList.add(treeline);
    		} catch (ServiceException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}*/
          System.out.println("b4 call fun ppassemblyRevision= "+assemblyRevision.toDisplayString()); 
          ClassifyList.add(setclsValues(assemblyRevision,tcsession));
          
           System.out.println("=========================================Getting TCUA  BOM/Global Alternate=============");
                 
          if (bl.hasChildren()){
                 
                        AIFComponentContext[] childContext = bl.getChildren();// used 1#.-> bl.getPackedLines()
                        
                        //TCComponentBOMLine[] childContext =bl.getPackedLines();
                        System.out.println("BOM Children count is "+childContext.length);
                        
                        System.out.println("=======================Listing Children=============");
                        for(int i = 0; i < childContext.length; i++){
                              //TCComponentBOMLine child = childContext[i];// unHased if unhased 1# -> (TCComponentBOMLine)childContext[i].getComponent();
                              TCComponentBOMLine child =  (TCComponentBOMLine)childContext[i].getComponent();
                              TCComponentItem item = child.getItem();
                              TCComponentItemRevision childItemrev=child.getItemRevision();

                      		/* getProps= new GetClassifiedAttr(childItemrev,tcsession);
                      		 treeline=null;
                      		try {
                      			ICOValues icoval=getProps.getICOProps();
                      			ModuleAddress=icoval.getCid();
                    			ObjectID=icoval.getIcoId();
                    			childrevDispStr=childItemrev.toDisplayString();
                    			clsobjs=icoval.getClsobjs();
                    			treeline =new ClassificationTreeLine(childrevDispStr, ModuleAddress,ObjectID,childItemrev,clsobjs);
                    			ClassifyList.add(treeline);
                      		} catch (ServiceException e) {
                      			// TODO Auto-generated catch block
                      			e.printStackTrace();
                      		}
                             */
                              System.out.println("b4 call fun childItemrev= "+childItemrev.toDisplayString()); 
                              ClassifyList.add(setclsValues(childItemrev,tcsession));
                              
                             
                        }
                        
                        System.out.println("====================END of Listing Children=============");
                 }
return ClassifyList;
    }

}
