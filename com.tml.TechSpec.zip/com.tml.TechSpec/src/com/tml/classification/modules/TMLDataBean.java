package com.tml.classification.modules;

import java.util.ArrayList;
import java.util.Iterator;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.swt.graphics.Image;

import com.teamcenter.rac.aif.AbstractAIFOperation;
import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.aif.kernel.AbstractAIFSession;
import com.teamcenter.rac.common.MultiTargetDataBean;
import com.teamcenter.rac.kernel.TCComponentBOMView;
import com.teamcenter.rac.kernel.TCException;


public class TMLDataBean extends MultiTargetDataBean {
	
	
	  private AIFComponentContext[] m_publishedTargets = null;
	 
	  
	  public TMLDataBean(AbstractAIFSession paramAbstractAIFSession, ISelection paramISelection,AIFComponentContext[] m_publishedTargets)
	  {
	    super(paramAbstractAIFSession, paramISelection);
	    this.m_publishedTargets = m_publishedTargets;
	    //  setTargetContexts(m_publishedTargets);
	   
	   
	  }
	  
	  protected AbstractAIFOperation[] getOperations()
	  {
	    
		  return new AbstractAIFOperation[1];
	  
	  }
	  
	  public String getCommandTitle()
	  {
	   
		  return "Errors!!";
	  }
	  
	  public String getCommandMessage()
	  {
	   
		  return "Tech Spec updation Errors";
	  }
	  
	  public Image getCommandIconImage()
	  {
	    return this.m_registry.getImage("delete.ICON");
	  }
	  
	  public String getCommandToolTip()
	  {
	   
	    return "tppokkljl";
	  }
	  
	  
	  
	  public AIFComponentContext[] getPublishedTargets()
	  {
	    return this.m_publishedTargets;
	  }
	  
	 
}
