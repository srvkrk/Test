package com.tml.techspec.handlers;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;

import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aif.kernel.InterfaceAIFComponent;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.commands.unreserve.UnReserveHandler;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCSession;
import com.tml.classification.modules.TechSpecUtil;
//import com.teamcenter.rac.tml.ui.modulecreation.ModuleInfoDialog;
import com.tml.techspec.dialogs.ModuleClassificationDialog;

public class TMLUnReserveHandler extends UnReserveHandler {
	
	
	protected void tcExecute()
		    throws Exception
		  {
		 InterfaceAIFComponent[] arrayOfInterfaceAIFComponent = getTargetComponents();
		 
		 TCComponentItemRevision itemrev=(TCComponentItemRevision) arrayOfInterfaceAIFComponent[0];
		 
		 Shell localShell = getActiveShell();
		 String parttype=null;
	    // MessageDialog.openQuestion(localShell,"CheckIn", "You must have to do classify before Check-In?" );
		 String classtype= arrayOfInterfaceAIFComponent[0].getType();
		 System.out.println("classtype="+classtype);
		 if(classtype.equals("Design Revision"))
		 {
	     parttype= itemrev.getProperty("t5_PartType");
	    System.out.println("parttype="+parttype);
		 }
		 else 
		 {
			 parttype= classtype;
		 }
		 
		 System.out.println("outside parttype="+parttype);		 
		 if(parttype.equals("Vehicle")||parttype.equals("T5_TSCompRevision")||parttype.equals("Module"))
		 {
			 System.out.println("allowed this option for parttype="+parttype);
			 AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
			    TCSession session=(TCSession) app.getSession();
			    new TechSpecUtil().invokeDlg(localShell, session, itemrev);	   
				  
		 }
		 super.tcExecute();	 
}	  		 
	 
	    // String classtype= arrayOfInterfaceAIFComponent[0].getType();
	    //System.out.println("parttype="+parttype);
	   // if()
	    

}
