package com.tml.techspec.dialogs;





import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.common.CommandTargetState;
import com.teamcenter.rac.common.ErrorTreeTableView;
import com.teamcenter.rac.common.MultiTargetControllerJob;
import com.teamcenter.rac.common.MultiTargetDataBean;
import com.teamcenter.rac.providers.TCComponentLabelProvider;
import com.teamcenter.rac.util.AdapterUtil;
import com.teamcenter.rac.util.InterfaceExceptionStack;
import com.teamcenter.rac.util.Registry;
import com.teamcenter.rac.common.Messages;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.CellLabelProvider;
import org.eclipse.jface.viewers.ColumnViewerToolTipSupport;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerCell;
import org.eclipse.jface.viewers.ViewerColumn;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;

	public final class TMLMultiTargetErrorDialog
	  extends MessageDialog
	{
	  protected final MultiTargetDataBean m_dataBean;
	  private Composite m_customComposite;
	  private ErrorTreeTableView m_treeTableView;
	  private IC_ErrorTree m_errorTree;
	  private Image[] m_images = new Image[3];
	  private Image m_commandImage;
	  private Button m_showAllCheckbox;
	  protected final Registry m_registry;
	  
	  public static boolean open(Shell paramShell, MultiTargetControllerJob paramMultiTargetControllerJob)
	  {
	    TMLMultiTargetErrorDialog localTMLMultiTargetErrorDialog = new TMLMultiTargetErrorDialog(paramShell, paramMultiTargetControllerJob);
	    return localTMLMultiTargetErrorDialog.open() == 0;
	  }
	  
	  public TMLMultiTargetErrorDialog(Shell paramShell, MultiTargetControllerJob paramMultiTargetControllerJob)
	  {
	    super(paramShell, "", null, "", 2, new String[] { IDialogConstants.OK_LABEL }, 0);
	    this.m_errorTree = new IC_ErrorTree(paramMultiTargetControllerJob);
	    this.m_dataBean = paramMultiTargetControllerJob.getDataBean();
	    this.m_registry = Registry.getRegistry(this.m_dataBean);
	    this.message = this.m_registry.getString("oneOrMoreFailed");
	    int i = 0;
	    i &= 0x10000000;
	    setShellStyle(getShellStyle() | i | 0x10);
	    Display localDisplay = Display.getDefault();
	    this.m_images[0] = this.m_registry.getImage("defaultError.ICON");
	    this.m_images[1] = new Image(localDisplay, localDisplay.getSystemImage(8).getImageData().scaledTo(16, 16));
	    this.m_images[2] = new Image(localDisplay, localDisplay.getSystemImage(2).getImageData().scaledTo(16, 16));
	    this.m_commandImage = this.m_dataBean.getCommandIconImage();
	  }
	  
	  public MultiTargetDataBean getDataBean()
	  {
	    return this.m_dataBean;
	  }
	  
	  protected Control createCustomArea(Composite paramComposite)
	  {
	    this.m_customComposite = new Composite(paramComposite, 0);
	    GridData localGridData = new GridData();
	    localGridData.grabExcessHorizontalSpace = true;
	    localGridData.grabExcessVerticalSpace = true;
	    localGridData.horizontalAlignment = 4;
	    localGridData.verticalAlignment = 4;
	    this.m_customComposite.setLayoutData(localGridData);
	    this.m_customComposite.setLayout(new GridLayout());
	    if (this.m_commandImage != null)
	    {
	      getShell().setText(this.m_dataBean.getCommandTitle());
	      getShell().setImage(this.m_dataBean.getCommandIconImage());
	    }
	    Composite localComposite = new Composite(this.m_customComposite, 0);
	    GridLayout localGridLayout = new GridLayout();
	    localGridLayout.numColumns = 1;
	    localComposite.setLayout(localGridLayout);
	    localGridData = new GridData();
	    localGridData.horizontalAlignment = 3;
	    localComposite.setLayoutData(localGridData);
	    this.m_showAllCheckbox = new Button(this.m_customComposite, 32);
	    this.m_showAllCheckbox.setText(Messages.getString("errorDlgShowAllCheckbox.MSG"));
	    this.m_showAllCheckbox.addSelectionListener(new SelectionListener()
	    {
	      public void widgetSelected(SelectionEvent paramAnonymousSelectionEvent)
	      {
	        TMLMultiTargetErrorDialog.this.m_treeTableView.getTreeViewer().refresh();
	      }
	      
	      public void widgetDefaultSelected(SelectionEvent paramAnonymousSelectionEvent)
	      {
	        widgetSelected(paramAnonymousSelectionEvent);
	      }
	    });
	    if ((this.m_errorTree.getRootNodes().size() == 1) || (this.m_errorTree.getRootNodes().size() == getOnlyErrors().size())) {
	      this.m_showAllCheckbox.setEnabled(false);
	    }
	    updateTableViewer();
	    return this.m_customComposite;
	  }
	  
	  public Point getCenterPoint()
	  {
	    Shell localShell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
	    Rectangle localRectangle = localShell.getBounds();
	    return new Point(localRectangle.x + localRectangle.width / 2, (localRectangle.y + localRectangle.height) / 2);
	  }
	  
	  protected Point getInitialLocation(Point paramPoint)
	  {
	    Point localPoint = getCenterPoint();
	    return new Point(localPoint.x - paramPoint.x / 2, localPoint.y - paramPoint.y / 2);
	  }
	  
	  private Image getStatusImage(Object paramObject)
	  {
	    if ((paramObject instanceof CommandTargetState))
	    {
	      CommandTargetState localCommandTargetState = (CommandTargetState)paramObject;
	      Exception localException = localCommandTargetState.getCaughtException();
	      if (localException != null) {
	        return this.m_images[0];
	      }
	    }
	    return this.m_commandImage;
	  }
	  
	  private void updateTableViewer()
	  {
	    if (this.m_treeTableView == null)
	    {
	      this.m_treeTableView = new ErrorTreeTableView();
	      this.m_treeTableView.createPartControl(this.m_customComposite);
	      this.m_treeTableView.getErrorColumn().setLabelProvider(new IC_ErrorColumnLabelProvider());
	      this.m_treeTableView.getItemColumn().setLabelProvider(new IC_ItemLabelProvider());
	      this.m_treeTableView.getTreeViewer().setContentProvider(new IC_JobContentProvider());
	      this.m_treeTableView.getTreeViewer().setInput(this.m_errorTree);
	      ColumnViewerToolTipSupport.enableFor(this.m_treeTableView.getTreeViewer(), 2);
	    }
	    this.m_treeTableView.getTreeViewer().getControl().setVisible(true);
	  }
	  
	  protected boolean customShouldTakeFocus()
	  {
	    return false;
	  }
	  
	  private static String[] removeRepeatedErrorsFromMessages(List<String> paramList)
	  {
	    LinkedHashMap localLinkedHashMap = new LinkedHashMap();
	    Iterator localIterator1 = paramList.iterator();
	    Object localObject2;
	    while (localIterator1.hasNext())
	    {
	      String localObject1 = (String)localIterator1.next();
	      localObject2 = (Integer)localLinkedHashMap.get(localObject1);
	      if (localObject2 != null) {
	        localLinkedHashMap.put(localObject1, Integer.valueOf(((Integer)localObject2).intValue() + 1));
	      } else {
	        localLinkedHashMap.put(localObject1, Integer.valueOf(1));
	      }
	    }
	    String[] localObject1 = new String[localLinkedHashMap.size()];
	    int i = 0;
	    Iterator localIterator2 = localLinkedHashMap.entrySet().iterator();
	    while (localIterator2.hasNext())
	    {
	      localObject2 = (Map.Entry)localIterator2.next();
	      StringBuffer localStringBuffer = new StringBuffer((String)((Map.Entry)localObject2).getKey());
	      if (((Integer)((Map.Entry)localObject2).getValue()).intValue() > 1) {
	        localStringBuffer.append(" (").append(((Integer)((Map.Entry)localObject2).getValue()).toString()).append(")");
	      }
	      localObject1[(i++)] = localStringBuffer.toString();
	    }
	    return localObject1;
	  }
	  
	  private List<IC_ErrorNode> getOnlyErrors()
	  {
	    ArrayList localArrayList = new ArrayList();
	    Iterator localIterator = this.m_errorTree.rootNodes.iterator();
	    while (localIterator.hasNext())
	    {
	      IC_ErrorNode localIC_ErrorNode = (IC_ErrorNode)localIterator.next();
	      if (localIC_ErrorNode.getCommandTargetState().getCaughtException() != null) {
	        localArrayList.add(localIC_ErrorNode);
	      }
	    }
	    return localArrayList;
	  }
	  
	  private class IC_ErrorColumnLabelProvider
	    extends CellLabelProvider
	  {
	    private IC_ErrorColumnLabelProvider() {}
	    
	    public void update(ViewerCell paramViewerCell)
	    {
	      TMLMultiTargetErrorDialog.IC_ErrorNode localIC_ErrorNode = (TMLMultiTargetErrorDialog.IC_ErrorNode)paramViewerCell.getElement();
	      paramViewerCell.setText(localIC_ErrorNode.getErrorStatus());
	      CommandTargetState localCommandTargetState = localIC_ErrorNode.getCommandTargetState();
	      if (localCommandTargetState != null) {
	        paramViewerCell.setImage(TMLMultiTargetErrorDialog.this.getStatusImage(localCommandTargetState));
	      }
	    }
	  }
	  
	  private class IC_ErrorNode
	  {
	    private String m_errorStatus;
	    private CommandTargetState m_commandTargetState = null;
	    private List<IC_ErrorNode> m_childNodes = new ArrayList();
	    private IC_ErrorNode parentNode = null;
	    
	    public IC_ErrorNode(CommandTargetState paramCommandTargetState)
	    {
	      this.m_commandTargetState = paramCommandTargetState;
	      this.m_errorStatus = paramCommandTargetState.getErrorStatus();
	      Exception localException = paramCommandTargetState.getCaughtException();
	      InterfaceExceptionStack localInterfaceExceptionStack = (InterfaceExceptionStack)AdapterUtil.getAdapter(localException, InterfaceExceptionStack.class);
	     // this.m_childNodes.add(new IC_ErrorNode(TMLMultiTargetErrorDialog.this, "hjfgfghfghdffd", this));
	     // this.m_childNodes.add(new IC_ErrorNode(TMLMultiTargetErrorDialog.this, "hjfgfghfghgrgdffd", this));
	    }
	    
	    public IC_ErrorNode(String paramString, IC_ErrorNode paramIC_ErrorNode)
	    {
	      this.parentNode = paramIC_ErrorNode;
	      this.m_errorStatus = paramString;
	    }
	    
	    public IC_ErrorNode getParentNode()
	    {
	      return this.parentNode;
	    }
	    
	    public String getErrorStatus()
	    {
	      return this.m_errorStatus;
	    }
	    
	    public List<IC_ErrorNode> getChildNodes()
	    {
	      return this.m_childNodes;
	    }
	    
	    public CommandTargetState getCommandTargetState()
	    {
	      return this.m_commandTargetState;
	    }
	  }
	  
	  private class IC_ErrorTree
	  {
	    private List<TMLMultiTargetErrorDialog.IC_ErrorNode> rootNodes = new ArrayList();
	    
	    public IC_ErrorTree(MultiTargetControllerJob paramMultiTargetControllerJob)
	    {
	      List localList = paramMultiTargetControllerJob.getCommandTargetStateList();
	      Iterator localIterator = localList.iterator();
	      while (localIterator.hasNext())
	      {
	        CommandTargetState localCommandTargetState = (CommandTargetState)localIterator.next();
	        this.rootNodes.add(new TMLMultiTargetErrorDialog.IC_ErrorNode(localCommandTargetState));
	      }
	    }
	    
	    public List<TMLMultiTargetErrorDialog.IC_ErrorNode> getRootNodes()
	    {
	      return this.rootNodes;
	    }
	  }
	  
	  private static class IC_ItemLabelProvider
	    extends TCComponentLabelProvider
	  {
	    protected void measure(Event paramEvent, Object paramObject)
	    {
	      if (((TMLMultiTargetErrorDialog.IC_ErrorNode)paramObject).getCommandTargetState() == null) {
	        return;
	      }
	      AIFComponentContext localAIFComponentContext = ((TMLMultiTargetErrorDialog.IC_ErrorNode)paramObject).getCommandTargetState().getAIFContext();
	      super.measure(paramEvent, localAIFComponentContext);
	    }
	    
	    protected void paint(Event paramEvent, Object paramObject)
	    {
	      if (((TMLMultiTargetErrorDialog.IC_ErrorNode)paramObject).getCommandTargetState() == null) {
	        return;
	      }
	      super.paint(paramEvent, ((TMLMultiTargetErrorDialog.IC_ErrorNode)paramObject).getCommandTargetState().getAIFContext());
	    }
	  }
	  
	  private class IC_JobContentProvider
	    implements ITreeContentProvider
	  {
	    private IC_JobContentProvider() {}
	    
	    public Object[] getChildren(Object paramObject)
	    {
	      return ((TMLMultiTargetErrorDialog.IC_ErrorNode)paramObject).getChildNodes().toArray();
	    }
	    
	    public Object getParent(Object paramObject)
	    {
	      return ((TMLMultiTargetErrorDialog.IC_ErrorNode)paramObject).getParentNode();
	    }
	    
	    public boolean hasChildren(Object paramObject)
	    {
	      return ((TMLMultiTargetErrorDialog.IC_ErrorNode)paramObject).getChildNodes().size() > 0;
	    }
	    
	    public void dispose() {}
	    
	    public void inputChanged(Viewer paramViewer, Object paramObject1, Object paramObject2) {}
	    
	    public Object[] getElements(Object paramObject)
	    {
	      List localList = ((TMLMultiTargetErrorDialog.IC_ErrorTree)paramObject).getRootNodes();
	      if (TMLMultiTargetErrorDialog.this.m_showAllCheckbox.getSelection()) {
	        return localList.toArray();
	      }
	      return TMLMultiTargetErrorDialog.this.getOnlyErrors().toArray();
	    }
	  }
	}

