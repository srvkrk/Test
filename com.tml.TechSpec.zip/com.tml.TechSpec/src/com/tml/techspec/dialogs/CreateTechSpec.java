package com.tml.techspec.dialogs;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
//import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;


//import com.teamcenter.com.TechSpecs.Activator;
import com.teamcenter.rac.aif.AIFDesktop;
import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.kernel.ListOfValuesInfo;
import com.teamcenter.rac.kernel.SoaUtil;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentDataset;
import com.teamcenter.rac.kernel.TCComponentForm;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentListOfValues;
import com.teamcenter.rac.kernel.TCComponentListOfValuesType;
import com.teamcenter.rac.kernel.TCComponentProject;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCComponentUser;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.services.ISessionService;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.rac.util.OSGIUtil;
import com.teamcenter.schemas.core._2006_03.datamanagement.ExtendedAttributes;
import com.teamcenter.rac.aif.AIFDesktop;
import com.teamcenter.rac.kernel.ServiceData;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentForm;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.rac.core.DataManagementService;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateIn;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateInput;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateOut;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateResponse;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.internal.rac.classification.ClassificationService;
import com.teamcenter.services.rac.core.DataManagementService;
import com.teamcenter.services.rac.core.ReservationService;
import com.teamcenter.services.rac.core._2006_03.DataManagement.CreateItemsResponse;
import com.teamcenter.services.rac.core._2006_03.DataManagement.ItemProperties;
import com.teamcenter.services.rac.query.SavedQueryService;
import com.teamcenter.services.rac.query._2010_04.SavedQuery.FindSavedQueriesCriteriaInput;
import com.teamcenter.services.rac.query._2010_04.SavedQuery.FindSavedQueriesResponse;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;

//Include the Saved Query Service Interface
import com.teamcenter.services.rac.query.SavedQueryService;

//Input and output structures for the service operations
//Note: the different namespace from the service interface
import com.teamcenter.services.rac.query._2006_03.SavedQuery.GetSavedQueriesResponse;
import com.teamcenter.services.rac.query._2007_09.SavedQuery.SavedQueriesResponse;
import com.teamcenter.services.rac.query._2008_06.SavedQuery.QueryInput;
import com.teamcenter.services.rac.query._2007_09.SavedQuery.QueryResults;

import com.teamcenter.services.rac.core.DataManagementService;
import com.teamcenter.soa.client.model.ModelObject;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.wb.swt.ResourceManager;

//import com.teamcenter.soa.client.model.ModelObject;

public class CreateTechSpec extends TitleAreaDialog {
	private Text txtA;
	private Text text_5;
	private Combo OwnerDesDept;
	private Combo OwnerDesUnit;
	private Combo VcSubClass;
	private Combo ProjCodeL;
	private Combo bucombo;
	private boolean isOkPressed;
	public Composite area1;
	private Shell parentshell;
	//private TCSession session;
	String newPartNumberGenrated = null;
	String FinalStr = null;
	/**
	 * Create the dialog.
	 * @param parentShell
	 */
	public CreateTechSpec(Shell parentShell) {
		super(parentShell);
		isOkPressed=false;
		this.parentshell=parentshell;
		
	}
	
	protected boolean isResizable() {
	    return true;
	}

	//private TCSession tcSession = null;
	private DataManagementService dservice = null;
	
	private TCComponentItem item = null;
	private TCComponentItemRevision itemRev = null;

	private TCComponentProject QryProj(TCSession session,String proj) throws TCException
	{
		
		//TCSession session;
		//proj="5042";		
		//String qryprojId = TempId.concat("*");
        System.out.println("proj: "+proj);
        String[] qvalue = { proj };
        String[] qname = { "Project ID" };
        System.out.println("proj Number: "+proj);
        TCComponentQueryType qtype = (TCComponentQueryType)session.getTypeComponent("ImanQuery");
        System.out.println("After getTypeComponent");
        TCComponentQuery query = (TCComponentQuery)qtype.find("QryProj");
        System.out.println("After qtype.find");
        TCComponent[] Qcomp = query.execute(qname, qvalue);
        System.out.println("Number of proj found in database =" + Qcomp.length);
        	for(int i=0;i<Qcomp.length;i++)
        	{
        		System.out.println("Proj FOUND BY QUERY "+Qcomp[i].toString());	        		        		
        	}
        
        if (Qcomp.length > 0)
        {
        	//int					latestObjindex			= -1;
        	//for(int i=0;i<Qcomp.length;i++)
        	//{
        		System.out.println("Proj FOUND BY QUERY "+Qcomp[0].toString());	      
        		
        		return (TCComponentProject) Qcomp[0];
        }
        
        return null;
		
	}
	
    //public void queryItems(TCSession tcSession)
	private void CreateTechSpecObj(TCSession tcSession,String itemclassName,String itemRevisionClass,String ProjCode,String OwnerDesDept,String OwnerDesUnit,String VCSubClass,String Desc,String businessunit)
    {

    	TCComponentQuery  query = null;

    	
    	System.out.println("Inside CreateTechSpecObj function with parameters");
		System.out.println("Input parameters are ProjCode: " + ProjCode + " OwnerDesDept: "+ OwnerDesDept +" OwnerDesUnit: "+ OwnerDesUnit +" VCSubClass: "+ VCSubClass +" Desc: "+ Desc +"businessunit="+businessunit);
		
        // Get the service stub.
        SavedQueryService queryService = SavedQueryService.getService(tcSession);
        DataManagementService dmService= DataManagementService.getService(tcSession);
      
       // DataManagementService dmService= DataManagementService.getService(tcSession);
        try
        {

            // *****************************
            // Execute the service operation
            // *****************************
            GetSavedQueriesResponse savedQueries = queryService.getSavedQueries();


            if (savedQueries.queries.length == 0)
            {
                System.out.println("There are no saved queries in the system.");
                return;
            }

            // Find one called 'Item Name'
            for (int i = 0; i < savedQueries.queries.length; i++)
            {

                if (savedQueries.queries[i].name.equals("TechSpecQry"))
                {
                    query = savedQueries.queries[i].query;
                    break;
                }
            }
        }
        catch (ServiceException e)
        {
            System.out.println("GetSavedQueries service request failed.");
            System.out.println(e.getMessage());
            return;
        }

        if (query == null)
        {
            System.out.println("There is not an 'Item Name' query.");
            return;
        }

        try
        {
            //Search for all Items, returning a maximum of 25 objects
        	String TempId=null;
			TempId="2590"+ProjCode;
			//TempId.concat("*);
			//TempId.concat("0001");
			System.out.println("TempId="+TempId);
            QueryInput savedQueryInput[] = new QueryInput[1];
            savedQueryInput[0] = new QueryInput();
            savedQueryInput[0].query = query;
            savedQueryInput[0].maxNumToReturn = 25;
            savedQueryInput[0].limitList = new TCComponent[0];
            savedQueryInput[0].entries = new String[]{"ID" };
            savedQueryInput[0].values = new String[1];
            savedQueryInput[0].values[0] = TempId+"*";

            
            //*****************************
            //Execute the service operation
            //*****************************
            SavedQueriesResponse savedQueryResult = queryService.executeSavedQueries(savedQueryInput);
            QueryResults found = savedQueryResult.arrayOfResults[0]; 
            
            System.out.println("");
            System.out.println("Found Items:");
            
            ServiceData sd = dmService.loadObjects( found.objectUIDS );
            
            if (sd.sizeOfPlainObjects() > 0)
	        {
            //for( int k =0; k< sd.sizeOfPlainObjects(); k++)
            //{
            	 TCComponentItem Item= (TCComponentItem) sd.getPlainObject(0);             
               
                System.out.println("Item="+Item.toDisplayString());
           // }
            
    	       
    	        	//int					latestObjindex			= -1;
    	        	//for(int i=0;i<Qcomp.length;i++)
    	        	//{
    	        		System.out.println("Total ITEMS FOUND BY QUERY "+sd.sizeOfPlainObjects());      		
    	        		
    	        			        		
    	        	
    		        	//System.out.println("\n\n\n\n latestTechObjindex =" + latestObjindex);
    		        	
    		            System.out.println("Query last Object=" +Item.toDisplayString());
    		           // TCComponentItem component = (TCComponentItem) Qcomp[0];
    		         	          
    		            String Partnumberstr = Item.getProperty("item_id");
    		           // String Partnumberstr =Qcomp[i].toString();
    		            System.out.println("TechSpecNumberstr: " + Partnumberstr);
    		            
    		          
    		            
    		            String Partnumberstrxxx = Partnumberstr.substring((Partnumberstr.length() - 4));
    		            System.out.println(" Partnumberstr last 4 digits are "  + Partnumberstrxxx);
    		            
    		           
    		           	 
    		            	System.out.println(" last 4 digits are not 0001 hence i am here ");
    		            	int last4Dig=Integer.parseInt(Partnumberstrxxx);
    		            	System.out.println(" last4Dig= "+last4Dig);
    		            	last4Dig=last4Dig+1;
    		            	System.out.println(" last4Dig= "+last4Dig);
    		            	
    		            	newPartNumberGenrated = String.format ("%04d", last4Dig);
    		            	System.out.println("Final Increment number"+newPartNumberGenrated);
    		            	
    		            	 FinalStr=TempId+newPartNumberGenrated;
    	        	//}
    	        }		        
    	        else
    	        {            
    	        	FinalStr = TempId.concat("0001");	            
    	            System.out.println("No Object Found hence creating partnum with last digits as 000: " + FinalStr);
    	        }
            //Create Started 
            TCComponentItem item;
	         TCComponentItemRevision itemRev;
	         TCComponentForm form;   
	                 
	         System.out.println("Inside Create Tech Spec with TS ID ="+FinalStr);     
	       
	         
	        // DataManagementService dmService= DataManagementService.getService(tcSession);
	         System.out.println("After DataManagementService");
	                 CreateIn itemDef = new CreateIn();
	                 CreateInput itemRevisionDef = new CreateInput();
            itemDef.data.boName = itemclassName;
            itemDef.data.stringProps.put("item_id", FinalStr);
            itemDef.data.stringProps.put("object_name", Desc);
            itemDef.data.stringProps.put("object_desc", Desc);
            itemDef.data.stringProps.put("fnd0RevisionId", "A");
            itemDef.data.stringProps.put("t5_ProjectCode", ProjCode);
           // itemDef.data.tagProps.put("owning_project", proj);
            System.out.println("After itemDef set");
            itemRevisionDef.boName = itemRevisionClass;
            itemRevisionDef.stringProps.put("object_desc", Desc);
            itemRevisionDef.stringProps.put("object_name", Desc);
            itemRevisionDef.stringProps.put("item_revision_id", "A");
            itemRevisionDef.stringProps.put("t5_DsgnDeptCpy", OwnerDesDept);
            itemRevisionDef.stringProps.put("t5_DsgnOwnCpy", OwnerDesUnit);
            itemRevisionDef.stringProps.put("t5_VCSubClass", VCSubClass); 
            //itemRevisionDef.stringProps.put("t5_TechSNumDes", Desc);
            itemRevisionDef.stringProps.put("t5_VCClassName", businessunit);
            System.out.println("After itemRevisionDef set");
            itemDef.data.compoundCreateInput.put("revision", new CreateInput[]{itemRevisionDef });

            try
            {
                    CreateResponse createObjResponse=	dmService.createObjects(new CreateIn[]{itemDef });

                   if(!ServiceDataError(createObjResponse.serviceData))
                    {
                             for(CreateOut out : createObjResponse.output)
                             {
                                     for(TCComponent obj : out.objects)
                                     {
                                              if(obj instanceof
                                           		   TCComponentItem)
                                                      item =(TCComponentItem) obj;
                                              else if(obj instanceof
                                           		   TCComponentItemRevision)
                                                      itemRev =(TCComponentItemRevision) obj;
                                              else if(obj instanceof
                                           		   TCComponentForm)
                                                      form =(TCComponentForm) obj;
                                     }
                             }
                    }
            }
            catch (ServiceException e) 
            {
                    e.printStackTrace();
                  
                    MessageBox.post(parentshell,"Not Created Successfully,refer the exception  !!","WARNING",SWT.ICON_WARNING);
                    
                  /*String  msgs= e.getMessage()+ " Not Created Successfully,refer the exception  !!";
              	  MessageBox msgbox = new MessageBox(new Shell(), SWT.ERROR);
                    msgbox.setText("Information.");
                    msgbox.setMessage(msgs);
                    msgbox.open(); */  
            }
            
            //End 
            
            
                
           
        }
        catch (Exception e)
        {
        	MessageBox.post(parentshell,"Not Created Successfully,refer the exception  !!","WARNING",SWT.ICON_WARNING);
        	  String  msgs= e.getMessage()+ " Not Created Successfully,refer the exception  !!";
          	  /*MessageBox msgbox = new MessageBox(new Shell(), SWT.ERROR);
                msgbox.setText("Information.");
                msgbox.setMessage(msgs);
                msgbox.open();   */
            System.out.println("Create service request failed.");
            System.out.println(e.getMessage());
            e.printStackTrace();
            return;
        }

    }
	
	//
	 protected boolean ServiceDataError(final ServiceData data)
     {
		 String msgs=null;
		 Shell shell=new Shell();
              if (data.sizeOfPartialErrors() > 0)
              {
            	 
                      for (int i = 0; i < data.sizeOfPartialErrors(); i++)
                      {
                               for (String msg :data.getPartialError(i).getMessages())
                               {
                                       System.out.println(msg);
                               
                               msgs=msgs+" "+msg;
                               }
                               
                      }
                      
                      MessageBox.post(parentshell,"Not Created Successfully,refer the exception  !!","WARNING",SWT.ICON_WARNING);
                     /* msgs= msgs+ " Not Created Successfully,refer the exception  !!";
                	  MessageBox msgbox = new MessageBox(shell, SWT.ERROR);
                      msgbox.setText("Information.");
                      msgbox.setMessage(msgs);
                      msgbox.open();*/   
                      return true;
              }
              if(data.sizeOfCreatedObjects()>0)
              {
            	  if(isOkPressed)
            	  CreateTechSpec.this.close();
            	  String createdobj=data.getCreatedObject(0).toDisplayString();
            	  try {
					data.getCreatedObject(0).getSession().getUser().getNewStuffFolder().add("contents", data.getCreatedObject(0));
				} catch (TCException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            	  
            	  
            	  msgs=createdobj+ " Created Successfully & added in NewStuffFolder!!";
            	  MessageBox.post(parentshell,msgs,"INFORMATION",SWT.ICON_INFORMATION);
            	 /* MessageBox msgbox = new MessageBox(shell, SWT.ICON_INFORMATION);
                  msgbox.setText("Information.");
                  msgbox.setMessage(msgs);
                  msgbox.open();  */ 
              }
              
              return false;
     }
	 
	private void CreateObject (TCSession tcSession,String itemclassName,String itemRevisionClass,String Proj,String OwnerDesDept,String OwnerDesUnit,String VCSubClass,String Desc,TCComponentProject proj) 
	{
		System.out.println("Inside CreateObject function with parameters");
		System.out.println("Input parameters are itemclassName: " + itemclassName + "itemRevisionClass:"+ itemRevisionClass+ "Proj= "+Proj + " OwnerDesDept: "+ OwnerDesDept +" OwnerDesUnit: "+ OwnerDesUnit +" VCSubClass: "+ VCSubClass +" Desc: "+ Desc );
		

	         TCComponentItem item;
	         TCComponentItemRevision itemRev;
	         TCComponentForm form;   
	                 
	         System.out.println("Inside DataManagementService");
	         
	       
	         
	         DataManagementService dmService= DataManagementService.getService(tcSession);
	         System.out.println("After DataManagementService");
	                 CreateIn itemDef = new CreateIn();
	                 CreateInput itemRevisionDef = new CreateInput();
	                 
	                 String TempId=null;
	     			TempId="2590"+Proj+"*";
	     			//TempId.concat(ProjCode);
	     			//TempId.concat("0001");
	     			System.out.println("TempId="+TempId);
	                 
	     			//queryItems(tcSession);
	     			System.out.println("queryItems called");
	                 
	                 itemDef.data.boName = itemclassName;
	                 itemDef.data.stringProps.put("item_id", "259050420999");
	                 itemDef.data.stringProps.put("object_name", Desc);
	                 itemDef.data.stringProps.put("object_desc", Desc);
	                 itemDef.data.stringProps.put("fnd0RevisionId", "A");
	                 itemDef.data.stringProps.put("t5_ProjectCode", proj);
	                // itemDef.data.tagProps.put("owning_project", proj);
	                 System.out.println("After itemDef set");
	                 itemRevisionDef.boName = itemRevisionClass;
	                 itemRevisionDef.stringProps.put("object_desc", Desc);
	                 itemRevisionDef.stringProps.put("object_name", Desc);
	                // itemRevisionDef.stringProps.put("item_revision_id", "A");
	                 //itemRevisionDef.stringProps.put("t5_DsgnDeptCpy", OwnerDesDept);
	                 //itemRevisionDef.stringProps.put("t5_DsgnOwnCpy", OwnerDesUnit);
	                 System.out.println("After itemRevisionDef set");
	                 itemDef.data.compoundCreateInput.put("revision", new CreateInput[]{itemRevisionDef });

	                 try
	                 {
	                         CreateResponse createObjResponse=	dmService.createObjects(new CreateIn[]{itemDef });

	                        if(!ServiceDataError(createObjResponse.serviceData))
	                         {
	                                  for(CreateOut out : createObjResponse.output)
	                                  {
	                                          for(TCComponent obj : out.objects)
	                                          {
	                                                   if(obj instanceof
	                                                		   TCComponentItem)
	                                                           item =(TCComponentItem) obj;
	                                                   else if(obj instanceof
	                                                		   TCComponentItemRevision)
	                                                           itemRev =(TCComponentItemRevision) obj;
	                                                   else if(obj instanceof
	                                                		   TCComponentForm)
	                                                           form =(TCComponentForm) obj;
	                                          }
	                                  }
	                         }
	                 }
	                 catch (ServiceException e) 
	                 {
	                         e.printStackTrace();
	                 }
	       
	        
	       
	}
	
	//
	private void CreateTechSpecObj1(TCSession session,String ProjCode,String OwnerDesDept,String OwnerDesUnit,String VCSubClass,String Desc)
	{
		
		//TCComponentItem pasteTargetItem = null;
		//TCComponentItem newCompItem;
		//boolean successFlag = true;
		
		System.out.println("Inside CreateTechSpecObj function with parameters");
		System.out.println("Input parameters are ProjCode: " + ProjCode + " OwnerDesDept: "+ OwnerDesDept +" OwnerDesUnit: "+ OwnerDesUnit +" VCSubClass: "+ VCSubClass +" Desc: "+ Desc );
		
		//session = getTCSession();
		//TCSession session=getTCSession();
		
		
		System.out.println("*****************session1.getUserName():"+session.getUserName());
			
			
		//DataManagementService dmService = DataManagementService.getService(session1);
		
		//CreateItemsResponse response = null;
		
		///
		//this.tcSession = session;
		this.dservice = DataManagementService.getService(session);
		try 
		{
			DataManagementService.ItemProperties[] properties = new DataManagementService.ItemProperties[1];
			DataManagementService.ItemProperties property = new DataManagementService.ItemProperties();
			TCComponentUser user = session.getUser();
			String TempId=null;
			TempId="2590"+ProjCode;
			//TempId.concat(ProjCode);
			//TempId.concat("0001");
			System.out.println("TempId="+TempId);
			
			//Start Qry
			System.out.println("B4 QryProj");
			TCComponentProject Proj=QryProj(session,ProjCode);
			System.out.println("After QryProj");
			String qryPartnumber = TempId.concat("*");
	        System.out.println("qryPartnumber: "+qryPartnumber);
	        String[] qvalue = { qryPartnumber };
	        String[] qname = { "ID" };
	        System.out.println("Session running: "+session.toString()+"TechSpec Number: "+qryPartnumber);
	        TCComponentQueryType qtype = (TCComponentQueryType)session.getTypeComponent("ImanQuery");
	        TCComponentQuery query = (TCComponentQuery)qtype.find("TechSpecQry");
	        TCComponent[] Qcomp = query.execute(qname, qvalue);
	        System.out.println("Number of TechSpec found in database =" + Qcomp.length);
	        	for(int i=0;i<Qcomp.length;i++)
	        	{
	        		System.out.println("XXXITEMS FOUND BY QUERY "+Qcomp[i].toString());	        		        		
	        	}
	        
	        if (Qcomp.length > 0)
	        {
	        	//int					latestObjindex			= -1;
	        	//for(int i=0;i<Qcomp.length;i++)
	        	//{
	        		System.out.println("ITEMS FOUND BY QUERY "+Qcomp[0].toString());      		
	        		
	        			        		
	        	
		        	//System.out.println("\n\n\n\n latestTechObjindex =" + latestObjindex);
		        	
		            System.out.println("Query last Object=" + Qcomp[0].toString());
		            TCComponentItem component = (TCComponentItem)Qcomp[0];
		         	          
		            String Partnumberstr = component.getProperty("item_id");
		           // String Partnumberstr =Qcomp[i].toString();
		            System.out.println("TechSpecNumberstr: " + Partnumberstr);
		            
		          
		            
		            String Partnumberstrxxx = Partnumberstr.substring((Partnumberstr.length() - 4));
		            System.out.println(" Partnumberstr last 4 digits are "  + Partnumberstrxxx);
		            
		           
		           	 
		            	System.out.println(" last 4 digits are not 0001 hence i am here ");
		            	int last4Dig=Integer.parseInt(Partnumberstrxxx);
		            	System.out.println(" last4Dig= "+last4Dig);
		            	last4Dig=last4Dig+1;
		            	System.out.println(" last4Dig= "+last4Dig);
		            	
		            	newPartNumberGenrated = String.format ("%04d", last4Dig);
		            	System.out.println("Final Increment number"+newPartNumberGenrated);
		            	
		            	 FinalStr=TempId+newPartNumberGenrated;
	        	//}
	        }		        
	        else
	        {            
	        	FinalStr = TempId.concat("0001");	            
	            System.out.println("No Object Found hence creating partnum with last digits as 000: " + FinalStr);
	        }
	        
	        
	        Map itemElemAttributes = new HashMap<String,Object>();
			itemElemAttributes.put("owning_project", Proj);
			
			
			 ExtendedAttributes[] extendedAttributes = new ExtendedAttributes[1];
		        ExtendedAttributes extendedAttributes2 = new ExtendedAttributes();
		    //    extendedAttributes2.objectType = "T5_TSComp";
		     //   extendedAttributes2.attributes = itemElemAttributes;
		        extendedAttributes[0] = extendedAttributes2;
			
			/*itemElemAttributes.put("t5_PartType", "A");
			itemElemAttributes.put("t5_DesignGrp", "00");
			itemElemAttributes.put("t5_ProjectCode", "2829");
			itemElemAttributes.put("gov_classification", "Cancel_CheckOut");*/
	       
	        System.out.println("Final TS number="+FinalStr);
	      //property.clientId = clientID;
			property.description = Desc;
			property.extendedAttributes = new DataManagementService.ExtendedAttributes[0];
			
			//property.extendedAttributes()
			property.itemId = FinalStr;
			property.name = Desc;
			property.revId = "A";
			property.type = "T5_TSComp";
			//property.uom = "";
			
			properties[0] = property;
		
			DataManagementService.CreateItemsResponse itemResp = dservice.createItems(properties, user.getHomeFolder(), "");
			
			if(itemResp.output.length > 0)
			{
				item = itemResp.output[0].item;
				itemRev = itemResp.output[0].itemRev;
				System.out.println("Tech Spec created itemRev="+itemRev);
			}
		
	        
	      }
	      catch (TCException e1)
	      {
	          e1.printStackTrace();
	      }
					
					
					
			//End Qry
			
			
			
		
		
		///
			//return null;
	}
			//End 
			
					

	private void processtechspecCre()
	{
		 TCComponentProject Proj=null;
		 //TCComponentProject Proj=QryProj(session,ProjCode);
		  System.out.println("Inside Ok_pressed for tech spec create");
		  	
//		  try {
//			  System.out.println("B4 QryProj func");
//			Proj=QryProj(session,"5042");
//			System.out.println("After QryProj func");
//		} catch (TCException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		  //Logic need to be build by rajesh
		  
			TCSession session= (TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
		
			//TCComponentProject Proj;
			
			
			
			try {
				 Proj = QryProj(session,ProjCodeL.getText());
			} catch (TCException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//ClassificationService cs= ClassificationService.getService(session);
			System.out.println("Calling CreateTechSpecObj Func");
			System.out.println("\nProjCodeL="+ProjCodeL.getText());			
			System.out.println("OwnerDesDept="+OwnerDesDept.getText());
			System.out.println("\nOwnerDesUnit="+OwnerDesUnit.getText() +"VcSubClass="+VcSubClass.getText() +"bucombo.getText()="+bucombo.getText());
			System.out.println("\nDesc=" +text_5.getText() );
			//CreateTechSpecObj(session,text.getText(),text_1.getText(),text_2.getText(),text_4.getText(),text_5.getText(),text_6.getText());
			
		if ((!ProjCodeL.getText().isEmpty()) && (!OwnerDesDept.getText().isEmpty()) && (!OwnerDesUnit.getText().isEmpty()) && (!VcSubClass.getText().isEmpty()) && (!text_5.getText().isEmpty()) && (!bucombo.getText().isEmpty()) )
		{		
			
			CreateTechSpecObj(session,"T5_TSComp","T5_TSCompRevision",ProjCodeL.getText(),OwnerDesDept.getText(),OwnerDesUnit.getText(),VcSubClass.getText(),text_5.getText(),bucombo.getText());
			System.out.println("After call CreateTechSpecObj Func");
		}
		else
		{
			System.out.println("selected values: " + ProjCodeL.getText() + OwnerDesDept.getText() + OwnerDesUnit.getText() + VcSubClass.getText() + text_5.getText() + bucombo.getText());
			System.out.println("Please select values against all properties");

			 MessageBox.post(parentshell,"All values are mandatory for creation of Technical Specification Header","ERROR",SWT.ICON_ERROR);
			/*MessageBox messageBox = new MessageBox(new Shell(), 289);
			messageBox.setText("ERROR");
			messageBox.setMessage("All values are mandatory for creation of Technical Specification Header");
			messageBox.open();*/
		}
	}
	

	


	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	protected Control createDialogArea(Composite parent) {
		setTitle("Create Technical Specification Header Dialog");
		TCSession session= (TCSession) AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		container.setLayout(new GridLayout(4, false));
		container.setLayoutData(new GridData(GridData.FILL_BOTH));
		new Label(container, SWT.NONE);
		
		Label lblNewLabel = new Label(container, SWT.CENTER);
		lblNewLabel.setText("Project Code");
		new Label(container, SWT.NONE);
		
		ProjCodeL = new Combo(container, SWT.NONE);
		ProjCodeL.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		
		Label lblNewLabel_1 = new Label(container, SWT.NONE);
		lblNewLabel_1.setText("Owner Desgin Dept");
		new Label(container, SWT.NONE);
		
		

		
		 OwnerDesDept = new Combo(container, SWT.NONE);
		OwnerDesDept.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		
		Label lblNewLabel_2 = new Label(container, SWT.NONE);
		lblNewLabel_2.setText("Owner Design Unit");
		new Label(container, SWT.NONE);
		
		OwnerDesUnit = new Combo(container, SWT.NONE);
		OwnerDesUnit.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		
		Label lblNewLabel_3 = new Label(container, SWT.NONE);
		lblNewLabel_3.setText("Rev");
		new Label(container, SWT.NONE);
		
		txtA = new Text(container, SWT.BORDER | SWT.READ_ONLY);
		txtA.setText("A");
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		
		Label lblNewLabel_4 = new Label(container, SWT.NONE);
		lblNewLabel_4.setText("VC Sub Class");
		new Label(container, SWT.NONE);
		
		VcSubClass = new Combo(container, SWT.NONE);
		VcSubClass.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		
		Label lblNewLabel_5 = new Label(container, SWT.NONE);
		lblNewLabel_5.setText("Techincal Specification Description");
		new Label(container, SWT.NONE);
		
		text_5 = new Text(container, SWT.BORDER);
		GridData gd_text_5 = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_text_5.widthHint = 325;
		text_5.setLayoutData(gd_text_5);
		text_5.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_FOREGROUND));
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		
		Label lblBusinessUnit = new Label(container, SWT.NONE);
		lblBusinessUnit.setText("Project Class");
		new Label(container, SWT.NONE);
		
		bucombo = new Combo(container, SWT.NONE);
		bucombo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		bucombo.add("HCV");
		bucombo.add("CAR");
		try {
		TCComponentListOfValuesType TypeLov = (TCComponentListOfValuesType)session.getTypeComponent("ListOfValues");
		{
		TCComponentListOfValues[] tmpcom;
		
			tmpcom = TypeLov.find("T5_OwnerDesignDeptLOV");
		
        if (tmpcom[0] != null) {
               ListOfValuesInfo LOVvalues = tmpcom[0].getListOfValues();
               String[] listValues = LOVvalues.getLOVDisplayValues();
               int listvaluelength = listValues.length;
               //OwnerDesDept.add("");
               for (int t = 0; t < listvaluelength; t++)
               {
                    System.out.print("\nOOOOOOOOOOOOOOOOO");
                    System.out.println("\nProjectLov=" + listValues[t]);
                    OwnerDesDept.add(listValues[t]);
                    
               
             }
        }
               TCComponentListOfValues[] OwnerDesUnitLov = TypeLov.find("T5_OwnerDesignUnitLOV");
               if (OwnerDesUnitLov[0] != null) {
            	   ListOfValuesInfo LOVvalues = OwnerDesUnitLov[0].getListOfValues();
            	   String[] listValues = LOVvalues.getLOVDisplayValues();
            	   int  listvaluelength = listValues.length;
                      //OwnerDesUnit.add("");
                      for (int t = 0; t < listvaluelength; t++)
                      {
                           System.out.print("\nOOOOOOOOOOOOOOOOO");
                           System.out.println("\nOwnerDesUnitLov=" + listValues[t]);
                           OwnerDesUnit.add(listValues[t]);
                           
                      
                    }
               }
                      TCComponentListOfValues[] VCSubClassLov = TypeLov.find("T5_SubCommnSet");
                      if (VCSubClassLov[0] != null) {
                    	  ListOfValuesInfo  LOVvalues = VCSubClassLov[0].getListOfValues();
                    	  String[]  listValues = LOVvalues.getLOVDisplayValues();
                          int   listvaluelength = listValues.length;
                          //VcSubClass.add("");
                             for (int t = 0; t < listvaluelength; t++)
                             {
                                  System.out.print("\nOOOOOOOOOOOOOOOOO");
                                  System.out.println("\nVCSubClassLov=" + listValues[t]);
                                  VcSubClass.add(listValues[t]);
                                  
                             
                           }
                      }
                      
                      TCComponentListOfValues[] ProjCodeLov = TypeLov.find("T5_Proj_codeLOV");
                      if (ProjCodeLov[0] != null) {
                    	  ListOfValuesInfo  LOVvalues = ProjCodeLov[0].getListOfValues();
                    	  String[]  listValues = LOVvalues.getLOVDisplayValues();
                          int   listvaluelength = listValues.length;
                          //VcSubClass.add("");
                             for (int t = 0; t < listvaluelength; t++)
                             {
                                  System.out.print("\nOOOOOOOOOOOOOOOOO");
                                  System.out.println("\nProjCodeLov=" + listValues[t]);
                                  ProjCodeL.add(listValues[t]);
                                  
                             
                           }
                      }
		
                      
		}
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		area1=area;
		return area;
	}

	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	protected void createButtonsForButtonBar(final Composite parent) {
		Button button_2 = createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL,
				true);
		button_2.setImage(ResourceManager.getPluginImage("com.tml.TechSpec", "icons/Ok_16x16.png"));
		
		button_2.addSelectionListener(new SelectionAdapter() {			
			public void widgetSelected(SelectionEvent e) {
				
			}
		});
		Button button = createButton(parent, IDialogConstants.NO_ID,
				IDialogConstants.NO_LABEL, true);
		button.setImage(ResourceManager.getPluginImage("com.tml.TechSpec", "icons/apply_16x16.png"));
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				//Rajesh
				 // String TechSpecAddress = null;
				 System.out.println("Inside apply_pressed for tech spec create before processtechspecCre call");
				processtechspecCre();
				 System.out.println("Inside apply_pressed for tech spec create after processtechspecCre call");
			}
		});
		button.setText("&Apply");
		
		Button button_1 = createButton(parent, IDialogConstants.NO_ID,
				IDialogConstants.NO_LABEL, true);
		button_1.setImage(ResourceManager.getPluginImage("com.tml.TechSpec", "icons/clear_16x16.png"));
		button_1.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				
				
				
Control[] ctrl=CreateTechSpec.this.area1.getChildren();

System.out.println("ctrl.length="+ctrl.length);

for(int i=0;i<ctrl.length;i++)
{
	System.out.println("ctrl.toString="+ctrl[i].toString());
	if(ctrl[i] instanceof Composite)
	{
Composite composite1=(Composite) ctrl[i];
Control[] ctrl1=composite1.getChildren();

for(int j=0;j<ctrl1.length;j++)

	{
	
	System.out.println("ctrl1.toString="+ctrl1[j].toString());
	
	if(ctrl1[j] instanceof Text )
		
	{
		Text ctrlText=(Text) ctrl1[j];
		if(ctrlText.isEnabled()==false)
			continue;
		if(ctrlText.getEditable()==false)
			continue;
	
		
		ctrlText.setText("");
	}
	else if(ctrl1[j] instanceof Combo )
		
	{
		
		Combo ctrlText=(Combo) ctrl1[j];
		
		if(ctrlText.isEnabled()==false)
			continue;
		
		
		ctrlText.setText("");
	}
	}
	}			
			}
}
			}
		);

		button_1.setText("&Clear");
		
		Button button_3 = createButton(parent, IDialogConstants.CANCEL_ID,
				IDialogConstants.CANCEL_LABEL, false);
		button_3.setImage(ResourceManager.getPluginImage("com.tml.TechSpec", "icons/close_16x16.png"));
	}

	
	@Override
	   protected void okPressed() {
	       // TODO Auto-generated method stub
		//Rajesh
		 // String TechSpecAddress = null;
		 System.out.println("Inside Ok_pressed for tech spec create before processtechspecCre call");
		 isOkPressed=true;
		processtechspecCre();
		 System.out.println("Inside Ok_pressed for tech spec create after processtechspecCre call");
	
	   }
	
	/**
	 * Return the initial size of the dialog.
	 */
	protected Point getInitialSize() {
		return new Point(736, 504);
	}
}
