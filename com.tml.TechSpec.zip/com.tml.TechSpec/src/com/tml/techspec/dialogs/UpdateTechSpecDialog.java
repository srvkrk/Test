package com.tml.techspec.dialogs;



import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ComboBoxCellEditor;
import org.eclipse.jface.viewers.EditingSupport;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TableTreeViewer;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.TreeViewerColumn;
import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.TableTree;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
//import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TreeColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;

import com.teamcenter.rac.aif.AbstractAIFOperation;
import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.common.CommandTargetState;
import com.teamcenter.rac.common.MultiTargetControllerJob;
import com.teamcenter.rac.common.TCTypeRenderer;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.util.AdapterUtil;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.rac.util.PlatformHelper;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.rac.classification._2007_01.Classification.ClassificationObject;
import com.teamcenter.services.rac.classification._2011_12.Classification.AttributeValues;
import com.teamcenter.services.rac.classification._2011_12.Classification.Value;
import com.teamcenter.soa.client.model.ServiceData;
import com.teamcenter.soa.exceptions.NotLoadedException;
import com.tml.classification.modules.BOMExpansion;
import com.tml.classification.modules.ClassificationLineProvider;
import com.tml.classification.modules.ClassificationTableLine;
import com.tml.classification.modules.ClassificationTreeLine;
import com.tml.classification.modules.CreateOrUpdateICOSample;
import com.tml.classification.modules.GetClassDescriptions;
import com.tml.classification.modules.GetClassifiedAttr;
import com.tml.classification.modules.GetKeyLOVs2Sample;
import com.tml.classification.modules.GetModuleAttributesForClasses;
import com.tml.classification.modules.ICOValues;
import com.tml.classification.modules.TMLDataBean;

import org.eclipse.wb.swt.ResourceManager;
import org.eclipse.wb.swt.SWTResourceManager;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;
import org.eclipse.swt.events.SelectionEvent;


public class UpdateTechSpecDialog extends TitleAreaDialog {
	private Text tsdesc;
	private String ModuleAddress;
	private String ObjectID;
	private TCSession session;
	private ClassificationLineProvider tabLineModel;
	private ArrayList<ClassificationTableLine> classificationList;
	private HashMap <String,Object> namevalueP;
	private Tree tree;
	
	private TreeViewer treeViewer;
	private Text tsbu;
	private ICOValues icoval;
	private Text tsnum;
	private String ModuleNum;
	private String SelObjType;
	private ClassificationObject clsobjs;
	private Text tsou;
	private Shell parentShell;
	private Text tsvsc;
	private Text tsodu;
	private Text tsodd;
	private TCComponentItemRevision ItemRev;
	private TCComponentItemRevision selectedObj;
	private List<CommandTargetState> m_commandTargetStateList;
	private AIFComponentContext localAIFComponentContext;
	private ArrayList<AIFComponentContext> localAIFComponentContextList;
	/**
	 * Create the dialog.
	 * @param parentShell
	 * @param selectedObj 
	 */
	public UpdateTechSpecDialog(Shell parentShell,TCSession session,TCComponentItemRevision ItemRev, TCComponentItemRevision selectedObj) {
		super(parentShell);
		
		this.session=session;
		this.ItemRev=ItemRev;
		this.selectedObj=selectedObj;
		this.parentShell=parentShell;
		namevalueP=new HashMap <String,Object>();
		m_commandTargetStateList = new ArrayList();
		localAIFComponentContextList= new ArrayList(); 
		
	}
	
	public void populateField()
	{
		System.out.println("2ModuleAddress="+ModuleAddress);
		System.out.println("2InstanceID="+ObjectID);
		try {
			tsdesc.setText(ModuleAddress);
			classificationList=new GetModuleAttributesForClasses(ModuleAddress,session).testgetGetAttributesForClasses();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		setTitle("Update Tech Spec Header ");
		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		container.setLayoutData(new GridData(GridData.FILL_BOTH));
		
		Group grpGeneralInfo = new Group(container, SWT.NONE);
		grpGeneralInfo.setForeground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		grpGeneralInfo.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		grpGeneralInfo.setEnabled(false);
		grpGeneralInfo.setText("General info");
		grpGeneralInfo.setBounds(0, 0, 757, 122);
		
		Label lblModuleAddress = new Label(grpGeneralInfo, SWT.NONE);
		lblModuleAddress.setFont(SWTResourceManager.getFont("Segoe UI", 8, SWT.BOLD));
		lblModuleAddress.setBounds(30, 51, 135, 15);
		lblModuleAddress.setText("Tech Spec Description");
		
		tsdesc = new Text(grpGeneralInfo, SWT.BORDER | SWT.READ_ONLY | SWT.MULTI);
		tsdesc.setBounds(203, 47, 213, 48);
		
		tsnum = new Text(grpGeneralInfo, SWT.BORDER);
		tsnum.setEditable(false);
		tsnum.setBounds(203, 19, 213, 21);
		//text_2.setText(ModuleNum);
		
		
		Label lblModuleNumber = new Label(grpGeneralInfo, SWT.NONE);
		lblModuleNumber.setFont(SWTResourceManager.getFont("Segoe UI", 8, SWT.BOLD));
		lblModuleNumber.setBounds(30, 23, 120, 15);
		//lblModuleNumber.setText("Module Number");
		System.out.println("SelObjType="+SelObjType);
		String ModuleVehicleNum=SelObjType +" Number";
		System.out.println("ModuleVehicleNum="+ModuleVehicleNum);
		lblModuleNumber.setText("Tech Spec Number");
		
		Label lblClassifiedInstanceName = new Label(grpGeneralInfo, SWT.NONE);
		lblClassifiedInstanceName.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblClassifiedInstanceName.setBounds(422, 25, 94, 15);
		lblClassifiedInstanceName.setText("Ownning User");
		
		tsou = new Text(grpGeneralInfo, SWT.BORDER);
		tsou.setBounds(544, 19, 213, 21);
		//text_3.setText(ObjectID);
		tsbu = new Text(grpGeneralInfo, SWT.BORDER | SWT.READ_ONLY);
		tsbu.setBounds(203, 101, 211, 21);
		//text_1.setText(ObjectID);
		//Setting TS value in dialog
		
		
		Label lblClassifiedInstanceId = new Label(grpGeneralInfo, SWT.NONE);
		lblClassifiedInstanceId.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblClassifiedInstanceId.setBounds(30, 104, 135, 15);
		lblClassifiedInstanceId.setText("Business Unit");
		//lblModuleNumber.
		Group grpClassificationPropertiesValues = new Group(container, SWT.NONE);
		grpClassificationPropertiesValues.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		grpClassificationPropertiesValues.setText("Classification Properties Values");
		grpClassificationPropertiesValues.setBounds(0, 128, 757, 455);
		
		 treeViewer = new TreeViewer(grpClassificationPropertiesValues, SWT.BORDER | SWT.FULL_SELECTION);
		tree = treeViewer.getTree();
		
		tree.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_FOREGROUND));
		tree.setLinesVisible(true);
		tree.setHeaderVisible(true);
		tree.setBounds(10, 27, 719, 418);
		
		TreeViewerColumn treeViewerColumn = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnNewColumn = treeViewerColumn.getColumn();
		tblclmnNewColumn.setWidth(122);
		tblclmnNewColumn.setText("Classified Objects");
	//	treeViewerColumn.setEditingSupport(new ClassificationEditingSupport1(treeViewer));
		
		TreeViewerColumn treeViewerColumn_1 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnNewColumn_1 = treeViewerColumn_1.getColumn();
		tblclmnNewColumn_1.setWidth(100);
		tblclmnNewColumn_1.setText("Attribute ID");
		//treeViewerColumn_1.setEditingSupport(new ClassificationEditingSupport2(treeViewer));
		
		TreeViewerColumn treeViewerColumn_2 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnNewColumn_2 = treeViewerColumn_2.getColumn();
		tblclmnNewColumn_2.setWidth(100);
		tblclmnNewColumn_2.setText("Attribute Name");
		//treeViewerColumn_2.setEditingSupport(new ClassificationEditingSupport3(treeViewer));
		
		TreeViewerColumn treeViewerColumn_3 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnAttributeValue = treeViewerColumn_3.getColumn();
		tblclmnAttributeValue.setWidth(100);
		tblclmnAttributeValue.setText("Attribute Value");
	//	treeViewerColumn_3.setEditingSupport(new ClassificationEditingSupport4(treeViewer));
		
		
		
//treeViewer.setContentProvider(ArrayContentProvider.getInstance());
		
treeViewerColumn_3.setEditingSupport(new EditingSupport(treeViewerColumn_3.getViewer()) {
			
			ArrayList<String> str;

			@Override
			protected void setValue(Object element, Object value) {
				
				
				
				String val=((ClassificationTableLine) element).getAttrValue();
				String lovid=((ClassificationTableLine) element).getLovID();
				int i;
				String b4Val="0";
				for( i=0;i<str.size();i++)
				{
					
					System.out.println(str.get(i)+":xdxddfdr::"+i);
					if(val.equals(str.get(i)))
					{
						b4Val=i+"";
						break;
					}
						
						
				}
				
				System.out.println("Before val::"+b4Val +" val="+val);
				System.out.println("value.toString()"+value.toString());
				try
				{
					if(Integer.parseInt(value.toString())<0)
					{
						value=b4Val;
						System.out.println("Input value does not exist in LOV, so choose value from LOV only");
						
						MessageBox.post(parentShell,"Input value does not exist in LOV, so choose value from LOV only or Contact PLM Administrator","WARNING",SWT.ICON_WARNING);
						
						/* MessageBox msgbox = new MessageBox(parentShell, SWT.ICON_INFORMATION);
				               msgbox.setText("Information.");
				               msgbox.setMessage("Input value does not exist in LOV, so choose value from LOV only or Contact PLM Administrator ");
				               msgbox.open();    */         
				             
						
					}
				} 
				catch(NumberFormatException e) 
				{ 
			       e.printStackTrace();
			    }
				if(Integer.parseInt(lovid)<0)
                {
		
			((ClassificationTableLine) element).setAttrValue(str.get(Integer.parseInt(value.toString())));
                }
				else
				{
					((ClassificationTableLine) element).setAttrValue(value.toString());
				}
				
			
			//	((MyModel) element).setAttributevalue("jkjhvghvgh");//value.toString());
				
				
				System.out.println(((ClassificationTableLine) element).toString());
				getViewer().update(element, null);
			}

			@Override
			protected Object getValue(Object element) {
				// We need to calculate back to the index
				
				String val=((ClassificationTableLine) element).getAttrValue();
				String lovid=((ClassificationTableLine) element).getLovID();
				if(Integer.parseInt(lovid)<0)
                {
			int i;	
			
			for( i=0;i<str.size();i++)
			{
				
				System.out.println(str.get(i)+":gfxfsdfsIDX::"+i);
			}
			
			
			System.out.println("str.indexOf(val)="+str.indexOf(val));
			
			boolean match=false;
			for( i=0;i<str.size();i++)
			{
				
				if(str.get(i).equals(val))
				{
					match=true;
					break;
				}
			}
				if(match==false)
				{
					i=0;
				}
				System.out.println(val+":IDX::"+i);
				return Integer.valueOf(i);
                }
				
				
				return val;
			}

			@Override
			protected CellEditor getCellEditor(Object element) {
				str=new ArrayList<String>();
				String val=((ClassificationTableLine) element).getAttrValue();
				String lovid=((ClassificationTableLine) element).getLovID();
				if(Integer.parseInt(lovid)<0)
                {
                	
                	try {
                		str=	new GetKeyLOVs2Sample().testGetKeyLOVs2(lovid);
                		
                		return new ComboBoxCellEditor(
        						treeViewer.getTree(), str.toArray(new String[str.size()]),SWT.READ_ONLY);
					} catch (ServiceException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
                	
                }
				
				
					return new TextCellEditor(treeViewer.getTree());
				
				
				
				
			}

			@Override
			protected boolean canEdit(Object element) {
				return true;
			}
		});
		
		/*CellEditor[] editors = new CellEditor[4];
	    editors[0] = new TextCellEditor(tree);
	    editors[1] = new TextCellEditor(tree);
	    editors[2] = new TextCellEditor(tree);
	    editors[3] = new ComboBoxCellEditor(tree);*/

		
		//lblModuleNumber.setText("lmnkmnk");
		
		
if(icoval!=null)
			
		{
			ModuleAddress=icoval.getCid();
			ObjectID=icoval.getIcoId();
			tsdesc.setText(ModuleAddress);
			tsbu.setText(ObjectID);
			clsobjs=icoval.getClsobjs();
			
			
			System.out.println("icoval!=null clsobjs="+clsobjs);
			
		}

String classdesc;

	/*classdesc = new GetClassDescriptions().getClassDesc(session,ModuleAddress);
	System.out.println("classdesc="+classdesc);
	text_3.setText(classdesc);
	*/
	Label lblVcSubClass = new Label(grpGeneralInfo, SWT.NONE);
	lblVcSubClass.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
	lblVcSubClass.setBounds(422, 50, 87, 21);
	lblVcSubClass.setText("VC Sub Class");
	
	tsvsc = new Text(grpGeneralInfo, SWT.BORDER);
	tsvsc.setText("<dynamic>");
	tsvsc.setBounds(544, 47, 213, 21);
	
	Label lblNewLabel = new Label(grpGeneralInfo, SWT.NONE);
	lblNewLabel.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
	lblNewLabel.setBounds(422, 74, 108, 21);
	lblNewLabel.setText("Owner Design Unit");
	
	tsodu = new Text(grpGeneralInfo, SWT.BORDER);
	tsodu.setBounds(544, 74, 213, 21);
	
	Label lblOwnerDesign = new Label(grpGeneralInfo, SWT.NONE);
	lblOwnerDesign.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
	lblOwnerDesign.setBounds(422, 104, 108, 18);
	lblOwnerDesign.setText("Owner Design Dept");
	
	tsodd = new Text(grpGeneralInfo, SWT.BORDER);
	tsodd.setBounds(544, 101, 213, 21);


//populateField();
System.out.println("Calling populateTable func");

if(icoval!=null)
{
	
	 Map<Object,AttributeValues> map2=icoval.getAttrValuesMap();
	for( Object key2 : map2.keySet())
     {
        System.out.println("keyw.get(key2)="+key2.getClass());
       
        System.out.println("kssl="+map2.get(key2).getClass());
       AttributeValues fv=map2.get(key2);
	       for(int f=0;f<classificationList.size();f++)
	       {
	    	   ClassificationTableLine tabline=classificationList.get(f);
	    	   
	    	   if(tabline.getAttrID().equals(key2.toString()))
	    		   
	    	   {
	    		 
	       
	    		  Value[] vals=  fv.values;
			      for(int x1=0;x1<vals.length;x1++)
			      {
			       System.out.println("key2"+key2+" Val:"+vals[x1].attrValue);		      
			       tabline.setAttrValue(vals[x1].attrValue);
			     
			      }
	    	   }
	       }
	  }
}
		
	
		
		TreeViewerColumn treeViewerColumn_4 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnNewColumn_3 = treeViewerColumn_4.getColumn();
		tblclmnNewColumn_3.setWidth(100);
		tblclmnNewColumn_3.setText("Unit");
		
		TreeViewerColumn treeViewerColumn_5 = new TreeViewerColumn(treeViewer, SWT.NONE);
		TreeColumn tblclmnNewColumn_4 = treeViewerColumn_5.getColumn();
		tblclmnNewColumn_4.setWidth(100);
		tblclmnNewColumn_4.setText("LovID");
		
		
		treeViewerColumn.setLabelProvider(new ColumnLabelProvider() {
			
			private TCComponent getComponent(Object paramObject)
		    {
		      AIFComponentContext localAIFComponentContext = (AIFComponentContext)AdapterUtil.getAdapter(paramObject, AIFComponentContext.class);
		      Assert.isNotNull(localAIFComponentContext);
		      TCComponent localTCComponent = (TCComponent)AdapterUtil.getAdapter(localAIFComponentContext.getComponent(), TCComponent.class);
		      Assert.isNotNull(localTCComponent);
		      return localTCComponent;
		    }
			
			
			public Image getImage(Object element) {
				if(element instanceof ClassificationTreeLine) 
		    	{
		    		ClassificationTreeLine p = (ClassificationTreeLine) element;
		    		TCComponentItemRevision tcobj=p.getItemrev();
		    		String classicon=null;
		    		try {
						String objecttype=tcobj.getPropertyDisplayableValue("t5_PartType");
						System.out.println("objecttype="+objecttype);
						if(objecttype.matches("Vehicle"))
						{
							classicon="icons/tmlpart_16.png";
						}
						else if (objecttype.matches("Module"))
						{
							classicon="icons/moduleIcon.png";
						}
						
						  
					} catch (NotLoadedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		    		
		    		
		    		Bundle bundle = FrameworkUtil.getBundle(this.getClass());
		    		// use the org.eclipse.core.runtime.Path as import
		    		System.out.println("classicon="+classicon);
		    		URL url = FileLocator.find(bundle,
		    		    new Path(classicon), null);
		    		ImageDescriptor imageDescriptor = ImageDescriptor.createFromURL(url);
		    		 
		    		//return TCTypeRenderer.getTypeImage(tcobj.getType(), null); //imageDescriptor.createImage();
		    		return imageDescriptor.createImage();
		    	}
		    	return null;
			}
		 
		    public String getText(Object element) {
		    	
		    	if(element instanceof ClassificationTreeLine) 
		    	{
		    		ClassificationTreeLine p = (ClassificationTreeLine) element;
		        return p.getClassifiedObject();
		    	}
		    	return null;
		    }
		});
		treeViewerColumn_1.setLabelProvider(new ColumnLabelProvider() {
			public Image getImage(Object element) {
			if(element instanceof ClassificationTableLine) 
	    	{
				ClassificationTableLine p = (ClassificationTableLine) element;
	    		Bundle bundle = FrameworkUtil.getBundle(this.getClass());
	    		// use the org.eclipse.core.runtime.Path as import
	    		URL url = FileLocator.find(bundle,
	    		    new Path("icons/AttrIcon16x16.png"), null);
	    		ImageDescriptor imageDescriptor = ImageDescriptor.createFromURL(url);
	    		return imageDescriptor.createImage();
	    		//return null;
	    	}
	    	return null;
		}
		   
		    public String getText(Object element) {
		    	if(element instanceof ClassificationTreeLine) 
		    	{
		    		ClassificationTreeLine p = (ClassificationTreeLine) element;
		        return p.getModuleAddress();
		    	}
		    	else if(element instanceof ClassificationTableLine)
		    	{
		    	ClassificationTableLine p = (ClassificationTableLine) element;
			        return p.getAttrID();
		    	}
		    	else
		    	{
		    		return null;
		    	}
		    }
		});
		
		treeViewerColumn_2.setLabelProvider(new ColumnLabelProvider() {
		   
		    public String getText(Object element) {
		    	if(element instanceof ClassificationTableLine)
		    	{
		    	ClassificationTableLine p = (ClassificationTableLine) element;
			        return p.getAttrName();
		    	}
		    	return null;
		    }
		});
		
		treeViewerColumn_3.setLabelProvider(new ColumnLabelProvider() {
		   
		    public String getText(Object element) {
		    	if(element instanceof ClassificationTableLine)
		    	{
		    	ClassificationTableLine p = (ClassificationTableLine) element;
		        return p.getAttrValue();
		    	}
		    	return null;
		    }
		});
		
		treeViewerColumn_4.setLabelProvider(new ColumnLabelProvider() {
		
		    public String getText(Object element) {
		    	
		    	if(element instanceof ClassificationTableLine)
		    	{
		    	ClassificationTableLine p = (ClassificationTableLine) element;
		        return p.getUnit();
		    	}
		    	return null;
		    }
		});
		
		treeViewerColumn_5.setLabelProvider(new ColumnLabelProvider() {
			
		    public String getText(Object element) {
		    	
		    	if(element instanceof ClassificationTableLine)
		    	{
		    	ClassificationTableLine p = (ClassificationTableLine) element;
		        return p.getLovID();
		    	}
		    	return null;
		    }
		});
		
		
		treeViewer.setContentProvider(new TreeContentProvider());//new TableContentProvider());
		//treeViewer.setLabelProvider(new TableLabelProvider(treeViewer));
		try {
			treeViewer.setInput( new BOMExpansion().getTCUAStructure(session, ItemRev));
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		treeViewer.expandAll();
		
		try {
			System.out.println("selectedObj.getObjectString"+selectedObj.getObjectString());
			System.out.println("selectedObj.DisplayString"+selectedObj.toDisplayString());
			tsnum.setText(selectedObj.getTCProperty("item_id").getDisplayableValue());
			tsou.setText(selectedObj.getTCProperty("owning_user").getDisplayableValue());
			System.out.println("11111selectedObj.getTCProperty.getDisplayableValue()="+selectedObj.getPropertyDisplayableValue("t5_TechSNumDes"));
			//System.out.println("ItemRev.getTCProperty.getDisplayableValue()111="+ItemRev.getTCProperty("t5_TechSNumDes").getDisplayableValue());
			tsdesc.setText(selectedObj.getPropertyDisplayableValue("object_desc"));
			tsbu.setText(selectedObj.getPropertyDisplayableValue("t5_VCClassName")); 
			tsvsc.setText(selectedObj.getPropertyDisplayableValue("t5_VCSubClass"));
			tsodu.setText(selectedObj.getPropertyDisplayableValue("t5_DsgnOwnCpy"));
			tsodd.setText(selectedObj.getPropertyDisplayableValue("t5_DsgnDeptCpy"));
		} catch (TCException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NotLoadedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Start Tree 
		//treeViewer.setInput(input)
		//viewer.setInput(File.listRoots());
		
		//End 
		
		
		
		
		return area;
	}
	public void updateICOVal(ICOValues val)
	{
		//text.setText(val.getCid());
		this.icoval=val;
		
		//classificationList.length
	}
	
	 public void populateTable() 
	    {
			// TODO Auto-generated method stub		
		

		 
		 
		 tabLineModel= new ClassificationLineProvider();
		 for(int i=0;i<classificationList.size();i++)
		 {
		 System.out.println("classificationList="+classificationList.get(i));
		 }
			tabLineModel.setClassificationLine(classificationList);
			
			 treeViewer.setContentProvider(new TableContentProvider());
			treeViewer.setInput( classificationList);
				
		
		}

	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		Button button = createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL,
				true);
		button.setImage(ResourceManager.getPluginImage("com.tml.TechSpec", "icons/Ok_16x16.png"));
		button.addSelectionListener(new SelectionAdapter() {
			/*@Override
			public void widgetSelected(SelectionEvent e) {
				
				//Rajesh
        		 // String ModuleAddress = null;
        		  System.out.println("going to call CreateOrUpdateICOSample");
        		  	AbstractAIFUIApplication app1=AIFUtility.getCurrentApplication();
        		  	
        		  	int itemCount = tree.getItemCount();
        		  	for(int itemIndex = 0; itemIndex < itemCount; itemIndex++) {
        		  	    TableItem item = tree.getItem(itemIndex);
        		  	  System.out.println("item.getText(1)="+item.getText(1));
        		  	  System.out.println("item.getText(3)="+item.getText(3));
        		  	  namevalueP.put(item.getText(1),item.getText(3))   ;
        		  	  
        		  	    }
        		  	
        		  	//ArrayList<ClassificationTableLine> classificationList1=(ArrayList<ClassificationTableLine>) treeViewer.getInput();
        		  //	System.out.println("treeViewer.getInput()="+treeViewer.get.getInput());
        		  //	 System.out.println("classificationList1 size="+classificationList1.size());
        		  	//for(int i=0;i<classificationList1.size();i++)
        			// {
        			// System.out.println("classificationList1="+classificationList1.get(i));
        			// }
        		  //	CreateOrUpdateICOSample CreUpdclassification= new CreateOrUpdateICOSample(app1.getDesktop().getShell(),ModuleAddress,ObjectID,session);
        		  //	CreUpdclassification.open();
					             		  
        		  //End
			}*/
			@Override
			public void widgetSelected(SelectionEvent e) {
			}
		});
		Button button_1 = createButton(parent, IDialogConstants.CANCEL_ID,
				IDialogConstants.CANCEL_LABEL, false);
		button_1.setImage(ResourceManager.getPluginImage("com.tml.TechSpec", "icons/close_16x16.png"));
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(773, 808);
	}
	
	@Override
	   protected void okPressed() {
	       // TODO Auto-generated method stub
		//Rajesh
		 // String ModuleAddress = null;
		  System.out.println("going to call CreateOrUpdateICOSample");
		  
		 
		  Map<ClassificationObject,HashMap<String, Object>> classmap=new HashMap<ClassificationObject,HashMap<String, Object>> ();
		  
		  	AbstractAIFUIApplication app1=AIFUtility.getCurrentApplication();
		  	
		  	
		  	ArrayList treelist=(ArrayList) treeViewer.getInput();
		  	System.out.println("treelist.Size()="+treelist.size());
		  	for(int i=0;i<treelist.size();i++)
		  	{
		  		if(treelist.get(i) instanceof ClassificationTreeLine)
		  		{
		  			 namevalueP=new HashMap <String,Object>();
		  			ClassificationTreeLine treeObj=(ClassificationTreeLine) treelist.get(i);
		  			ClassificationObject clsobjs=treeObj.getClsobjs();
		  			String moduleAddr=treeObj.getModuleAddress();
		  		//	StringTokenizer stk= new StringTokenizer(moduleAddr,"[]");
		  		//	ModuleAddress=stk.nextToken();
		  		//	ObjectID=stk.nextToken();
		  			ModuleAddress=treeObj.getModuleAddress();
		  			ObjectID=treeObj.getObjectid();
		  			ArrayList<ClassificationTableLine> treechildren=treeObj.getAttrList();
		  			try {
						ModuleNum= treeObj.getItemrev().getTCProperty("item_id").getDisplayableValue();
					} catch (TCException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
		  		
		  		System.out.println("treelist.getClass()="+treelist.getClass());
		  		System.out.println("treelist.tostring()="+treelist.toString());
		  		System.out.println("11ModuleNum="+ModuleNum);
		  
		  	
		  	for(int j=0;j<treechildren.size();j++)
		  	{


		  		if(treechildren.get(j) instanceof ClassificationTableLine)
		  		{
		  			ClassificationTableLine treeTabObj=(ClassificationTableLine) treechildren.get(j);
		  			
		  			String attrid=treeTabObj.getAttrID();
		  			String attrval=treeTabObj.getAttrValue();
		  			String lovId=treeTabObj.getLovID();

		  
		  	
		
		  	  
		  	 System.out.println("attrid="+attrid +"attrval="+attrval + "lovId="+lovId);
		  	 // namevalueP.put(item.getText(1),"v"+itemIndex)   ;
		  	 try
		  	 {
		  	 if(Integer.parseInt(lovId)<0)
		  	 {
		  		 if(attrval.trim().length()>0)
		  		 {
		  		namevalueP.put(attrid,new StringTokenizer(attrval," ").nextToken());
		  		 }
		  		 else
		  		 {
		  			namevalueP.put(attrid,attrval)   ;
		  		 }
		  	
		  	 }
		  	 else
		  	 {
		  		namevalueP.put(attrid,attrval)   ;
		  	 }
		  	} catch(NumberFormatException e) { 
			       e.printStackTrace();
			    }
		  	  
		  	    }
		  		
		  	
		  	 System.out.println("CreateOrUpdateICOSample clsobjs="+clsobjs);
		  	 CreateOrUpdateICOSample icos=new  CreateOrUpdateICOSample(clsobjs, ModuleAddress, ObjectID, ModuleNum,namevalueP, session);
		  	 try {
				icos.testCreateAndUpdateICO();
			} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  	 
		  /*	 finally
		  	 {
		  		 localAIFComponentContext = (AIFComponentContext)AdapterUtil.getAdapter(treeObj.getItemrev(), AIFComponentContext.class);
		  		
		  	   CommandTargetState cmdstate=new CommandTargetState(localAIFComponentContext,null);
		  		ServiceData data=icos.getServiceData();
		  		if(data.sizeOfPartialErrors() > 0)
		  	    {
		  	            for(int ij = 0; ij < data.sizeOfPartialErrors(); ij++)
		  	            {
		  	                     for(String msg :
		  	data.getPartialError(ij).getMessages())
		  	                     {
		  	                             System.out.println("ServiceDataError1:"+msg);
		  	                   cmdstate.setCaughtException(new TCException(msg));
		  	                     }
		  	            }
		  	          //System.out.println("localAIFComponentContext.toString()=:"+localAIFComponentContext.toString());
		  	          localAIFComponentContextList.add(localAIFComponentContext);
		  	          m_commandTargetStateList.add(cmdstate);
		  	            
		  		
		  	    }
	             

		  	 }*/
		  		}
		  		}
	}
		  	/*if(localAIFComponentContextList.size()>0)
		  	{
		  	AIFComponentContext[] selobjs=localAIFComponentContextList.toArray(new AIFComponentContext[localAIFComponentContextList.size()]);
		  	 System.out.println("selobjs="+selobjs.length);
		  	AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
		  	
            TCSession session=(TCSession) app.getSession();
            
            TMLDataBean databean= new TMLDataBean(session, null,selobjs);
           // databean.setTargetContexts(selobjs);

             MultiTargetControllerJob paramMultiTargetControllerJob=new MultiTargetControllerJob(new AbstractAIFOperation[1],databean );
            System.out.println("inside update status printing step");
            paramMultiTargetControllerJob.getCommandTargetStateList().addAll(m_commandTargetStateList);

            TMLMultiTargetErrorDialog.open(PlatformHelper.getCurrentShell(), paramMultiTargetControllerJob);
		  	}
		  	else
*/		  	{
		  		MessageBox.post(PlatformHelper.getCurrentShell(),"VC Attributes updated successfully  !!","INFORAMTION",SWT.ICON_INFORMATION);
		  	}
            System.out.println("inside update status printing step completed!!");

	
		  	
	       super.okPressed();
	   }
	//used to set the Title in the dialog window
	@Override
    protected void configureShell(Shell newShell) {
        super.configureShell(newShell);
        newShell.setText("TML Classification Window");
    } 
}

class TreeContentProvider implements ITreeContentProvider {
    @Override
    public boolean hasChildren(Object element) {
    	if(element instanceof ClassificationTreeLine)
    	{
    		
    		ClassificationTreeLine p = (ClassificationTreeLine) element;
    		TCComponentItemRevision tcrev= p.getItemrev();
    		AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
    		TCSession session=(TCSession) app.getSession();
    		GetClassifiedAttr getProps= new GetClassifiedAttr(tcrev,session);
    		String modaddress=p.getModuleAddress();
    		if(getProps!=null)
    		{
    			try {
    				if(getProps.getICOProps()!=null)
					modaddress=getProps.getICOProps().getCid();
				} catch (ServiceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		}
    		ArrayList<ClassificationTableLine> classificationList=new ArrayList<ClassificationTableLine>();
			try {
				classificationList = new GetModuleAttributesForClasses(modaddress,session).testgetGetAttributesForClasses();
			} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		
    		for(int k=0;k<classificationList.size();k++)
    		{
    			
    			classificationList.get(k).setParent(p);
    		}
    		p.setAttrList(classificationList);
    		return classificationList.size()==0? false:true;
    	}
    	else
    	{
    	return false;
    	}
    }

    @Override
    public Object getParent(Object element) {
    	if(element instanceof ClassificationTableLine)
    	{
    		ClassificationTableLine p = (ClassificationTableLine) element;
    		
    		return p.getParent();
    	}
    	
    	return null;
    }

    @Override
    public Object[] getElements(Object inputElement) {
    	
    	
        return ArrayContentProvider.getInstance().getElements(inputElement);
    }

    @Override
    public Object[] getChildren(Object parentElement) {
    	if(parentElement instanceof ClassificationTreeLine)
    	{
    		
    		ClassificationTreeLine p = (ClassificationTreeLine) parentElement;
    		TCComponentItemRevision tcrev= p.getItemrev();
    		AbstractAIFUIApplication app=AIFUtility.getCurrentApplication();
    		TCSession session=(TCSession) app.getSession();
    		GetClassifiedAttr getProps= new GetClassifiedAttr(tcrev,session);
    		String modaddress=p.getModuleAddress();
    		if(getProps!=null)
    		{
    			try {
    				if(getProps.getICOProps()!=null)
					modaddress=getProps.getICOProps().getCid();
				} catch (ServiceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		}
    		ArrayList<ClassificationTableLine> classificationList=new ArrayList<ClassificationTableLine>();
			try {
				classificationList = new GetModuleAttributesForClasses(modaddress,session).testgetGetAttributesForClasses();
			} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//Map<Object, AttributeValues> AttrValMap=getProps.getICOProps().getAttrValuesMap();
			try {
			if(getProps.getICOProps()!=null)
			{
			 Map<Object, AttributeValues> map2 = null;
			
				map2 = getProps.getICOProps().getAttrValuesMap();
			
				for( Object key2 : map2.keySet())
			     {
			        System.out.println("UpdateTechSpecDialog keyw.get(key2)="+key2.getClass());
			       
			        System.out.println("UpdateTechSpecDialog="+map2.get(key2).getClass());
			       AttributeValues fv=map2.get(key2);
				       for(int f=0;f<classificationList.size();f++)
				       {
				    	   ClassificationTableLine tabline=classificationList.get(f);
				    	   
				    	   if(tabline.getAttrID().equals(key2.toString()))
				    		   
				    	   {
				    		 
				       
				    		  Value[] vals=  fv.values;
						      for(int x1=0;x1<vals.length;x1++)
						      {
						       System.out.println("UpdateTechSpecDialog key2"+key2+" Val:"+vals[x1].attrValue);		      
						       tabline.setAttrValue(vals[x1].attrValue);
						     
						      }
				    	   }
				       }
				  }
				
			}
			} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
    		for(int k=0;k<classificationList.size();k++)
    		{
    			
    			classificationList.get(k).setParent(p);
    			
    		}
    		p.setAttrList(classificationList);
    		return classificationList.toArray();
    	}
    	else
    	{
    	return null;
    	}
    }

	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
		// TODO Auto-generated method stub
		
	}
}

 class TreeTableLabelProvider 	extends LabelProvider 	implements ITableLabelProvider {
	
	private TreeViewer treeViewer;
	
	

	
	
	
	/*static {
imageRegistry.put("smileImage", ImageDescriptor.createFromFile(
TableViewerExample.class,
"smile.jpg"));
}*/
	public TreeTableLabelProvider(TreeViewer treeViewer) {
		this.treeViewer = treeViewer;
	}
	
	
	
	
	  public String getColumnText(Object element, int columnIndex) {
		  ClassificationTableLine tabline = (ClassificationTableLine) element;
		  System.out.println("1columnIndex="+columnIndex);
	    switch (columnIndex) {
	    case 0:
	    	 System.out.println("1tabline.getSrlNo()="+tabline.getSrlNo());
		      return tabline.getSrlNo()+"";
		    case 1:
		    	System.out.println("1tabline.getAttrID()="+tabline.getAttrID());
		      return tabline.getAttrID();
		    case 2:
		    	System.out.println("1tabline.getAttrName()="+tabline.getAttrName());
		      return tabline.getAttrName();		      
		    case 3:
		    	System.out.println("1abline.getAttrValue()="+tabline.getAttrValue());
			  return tabline.getAttrValue();
		    case 4:
		    	System.out.println("1abline.UnitName()="+tabline.getUnit());
			  return tabline.getUnit();
		    case 5:
		    	System.out.println("1abline.getLovID()="+tabline.getLovID());
			  return tabline.getLovID();
	    }
	    
	    return "";
}




	@Override
	public Image getColumnImage(Object arg0, int arg1) {
		// TODO Auto-generated method stub
		return null;
	}









}


 
 
 class TreeTableContentProvider implements IStructuredContentProvider {
	  public Object[] getElements(Object inputElement) {
		  ArrayList<ClassificationTableLine> list= (ArrayList<ClassificationTableLine>) inputElement;
		  
		  Object[] obj=list.toArray();
		  
		  for(int x=0;x<obj.length;x++)
		  {
			  
			  System.out.println("GHH::"+obj[x].toString());
			  
		  }
	    return list.toArray();
	  }

	  public void dispose() {
	  }

	  

	@Override
	public void inputChanged(Viewer arg0, Object arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}
	}
