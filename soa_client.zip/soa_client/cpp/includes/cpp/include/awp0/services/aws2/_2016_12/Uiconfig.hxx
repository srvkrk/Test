/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef AWP0_SERVICES_AWS2__2016_12_UICONFIG_HXX
#define AWP0_SERVICES_AWS2__2016_12_UICONFIG_HXX

#include <teamcenter/soa/client/model/Fnd0AbstractCommand.hxx>
#include <teamcenter/soa/client/model/Fnd0Client.hxx>
#include <teamcenter/soa/client/model/Fnd0ClientScope.hxx>
#include <teamcenter/soa/client/model/Fnd0CommandCollection.hxx>
#include <teamcenter/soa/client/model/Fnd0UIConfigCollectionRel.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <awp0/services/aws2/AWS2_exports.h>

namespace Awp0
{
    namespace Services
    {
        namespace Aws2
        {
            namespace _2016_12
            {
                class Uiconfig;

class AWP0SOAAWS2STRONG_API Uiconfig
{
public:

    struct ClientConfigurations;
    struct ClientInput;
    struct ColumnConfig;
    struct ColumnConfigData;
    struct ColumnDefInfo;
    struct CommandCollectionInfo;
    struct CommandConfigData;
    struct ScopeInput;
    struct GetUIConfigInput;
    struct GetUIConfigResponse;

    /**
     * This structure contains command and column configuration data for the indicated client.
     */
    struct ClientConfigurations
    {
        /**
         * The client for which the configurations are applicable.
         */
        std::string client;
        /**
         * List of column configurations.
         */
        std::vector< Awp0::Services::Aws2::_2016_12::Uiconfig::ColumnConfigData > columnConfigurations;
        /**
         * List of command configurations.
         */
        std::vector< Awp0::Services::Aws2::_2016_12::Uiconfig::CommandConfigData > commandConfigurations;
    };

    /**
     * Specifies client input information including client name and hosting client name.
     */
    struct ClientInput
    {
        /**
         * The name of a client application, as represented by an instance of <b>Fnd0Client</b>
         * in the Teamcenter database. This value must match the value of fnd0ClientName property.
         */
        std::string clientName;
        /**
         * Specifies the name of a hosting Client application, as represented by an instance
         * of Fnd0Client, in the Teamcenter databases. This value must match a value of the
         * fnd0ClientName property. For example, if Client A is integrated with Client B and
         * the user can invoke Client B commands from within Client A, the input to getUiConfigs
         * would specify Client A as hosting Client and Client B as the Client. If the caller
         * wanted native commands for Client A, Client A would be specified as Client and hosting
         * Client would be empty.
         */
        std::string hostingClientName;
    };

    /**
     * This structure contains information for a column configuration within a client scope
     * URI. It contains a unique column config id, a list of column definition information,
     * and the default sort direction.
     */
    struct ColumnConfig
    {
        /**
         * The unique identifier of the column.
         */
        std::string columnConfigId;
        /**
         * How the columns are sorted. Valid values are Ascending and Descending.
         */
        std::string sortDirection;
        /**
         * Ordered list of column details.
         */
        std::vector< Awp0::Services::Aws2::_2016_12::Uiconfig::ColumnDefInfo > columns;
    };

    /**
     * This structure returns information about the column configuration definitions for
     * a scope, hosting client and client scope.
     */
    struct ColumnConfigData
    {
        /**
         * The scope for which the column data is applicable.
         */
        std::string scope;
        /**
         * The name of hosting client for which the list of column configurations is applicable.
         * This value must correspond to the value of the property fnd0ClientName for an Fnd0Client
         * object in the Teamcenter database.
         */
        std::string hostingClient;
        /**
         * The client scope for which the list of column configurations is applicable. This
         * must match a value of fnd0ClientScopeURI which is the unique identifier of a client
         * scope (Fnd0ClientScope).
         */
        std::string clientScopeURI;
        /**
         * List of column configuration details.
         */
        std::vector< Awp0::Services::Aws2::_2016_12::Uiconfig::ColumnConfig > columnConfigurations;
    };

    /**
     * Contains details about a specific column. This includes the type of object for which
     * the column is applicable, the name of the property displayed in the column, a flag
     * indicating if the column should be used to order information displayed in the client
     * and pixel width.
     */
    struct ColumnDefInfo
    {
        /**
         * The Business Object type for the value displayed in the column. This can be any valid
         * Teamcenter business object type.
         */
        std::string typeName;
        /**
         * The property name for the value displayed in the column.
         */
        std::string propertyName;
        /**
         * True if the column is used to sort the information displayed to the user.
         */
        bool sortByFlag;
        /**
         * The pixel width for the column. Valid pixel widths are integer values between1 and
         * 500.
         */
        int pixelWidth;
    };

    /**
     * Contains a command collection and indexes to its children commands or command collections.
     */
    struct CommandCollectionInfo
    {
        /**
         * If true ,the child is a command collection; otherwise, the child is a command.
         */
        std::vector< bool > childIsCollection;
        /**
         * If true, command or collection is visible; otherwise, the command or collection is
         * not visible.
         */
        std::vector< bool > childIsVisible;
        /**
         * Index of the child in either the CommandConfigData:commands list or the CommandConfigData:cmdsCollections
         * list. It is used by client to build the command hierarchy.
         */
        std::vector< int > childConfigIndex;
        /**
         * <b>Fnd0CommandCollection</b> object.
         */
        Teamcenter::Soa::Client::Model::Fnd0CommandCollection* commandCollection;
    };

    /**
     * This structure returns information about the command configuration definitions for
     * a client scope URI.
     */
    struct CommandConfigData
    {
        /**
         * The scope for which the command data is applicable.
         */
        std::string scopeName;
        /**
         * The hosting client for which the command data is applicable.
         */
        Teamcenter::Soa::Client::Model::Fnd0Client* hostingClient;
        /**
         * The client scope URI containing the list of command configurations.
         */
        Teamcenter::Soa::Client::Model::Fnd0ClientScope* clientScope;
        /**
         * List of all top level and child command collections in the client scope.
         */
        std::vector< Awp0::Services::Aws2::_2016_12::Uiconfig::CommandCollectionInfo > cmdCollections;
        /**
         * Index into cmdCollections list for top level command collections in the client scope.
         */
        std::vector< int > cmdCollectionIndex;
        /**
         * List of all command children accessible in the client scope.
         */
        std::vector< Teamcenter::Soa::Client::Model::Fnd0AbstractCommand* > commands;
        /**
         * List of all commandCollectionRel objects that associate top level command collections
         * with client scope.
         */
        std::vector< Teamcenter::Soa::Client::Model::Fnd0UIConfigCollectionRel* > commandCollectionRels;
    };

    /**
     * Contains scope input information including scope name and scope query parameter.
     */
    struct ScopeInput
    {
        /**
         * The name of a scope. For Site and current login user, this value should be empty.
         */
        std::string scopeName;
        /**
         * The query scope that is used to retrieve the UI configurations. Valid values are
         * Site, Group, Role, User, LoginUser, and AvailableForLoginUser. Site returns the configuration
         * defined for the site. Group returns the configuration defined for a specific Teamcenter
         * Group. Role returns the configuration defined for a specific Teamcenter Role. User
         * returns the configurations defined for a specific Teamcenter User. LoginUser returns
         * the current configuration defined for the current login user. AvailableForLoginUser
         * returns all the configurations available for the current login user. The value for
         * scopeName should be empty when scopeQueryParam is set to: "Site", "LoginUser" or
         * "AvailableForLoginUser".
         */
        std::string scopeQueryParam;
    };

    /**
     * Contains input information requiredto retrieve UI configurations from the Teamcenter
     * database.
     */
    struct GetUIConfigInput
    {
        /**
         * List of client scope URIs representing, for example location.sublocation in Active
         * Workspace. (Fnd0ClientScope::fnd0ClientScopeURI). If empty, the UI Configuration
         * for all client scopes are returned.
         */
        std::vector< std::string > clientScopeURIs;
        /**
         * The scope of the desired UI configuration information. This includes the name of
         * the scope (i.e. a user, group or role) and scope query parameter information.
         */
        Awp0::Services::Aws2::_2016_12::Uiconfig::ScopeInput scope;
        /**
         * Client information including client name and hosting client name.
         */
        Awp0::Services::Aws2::_2016_12::Uiconfig::ClientInput client;
    };

    /**
     * This structure returns information to the client about column configuration and command
     * applicability. The ServiceData contains information about errors encountered during
     * processing.
     */
    struct GetUIConfigResponse
    {
        /**
         * ServiceData structure containing errors and command, command collection and icon
         * objects. If there is an error retrieving the configuration information, the error
         * added to the ServiceData as a partial error.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
        /**
         * List of configuration information including command and column information.
         */
        std::vector< Awp0::Services::Aws2::_2016_12::Uiconfig::ClientConfigurations > uiConfigInfo;
    };




    /**
     * This operation returns information used by the client to render the User Interface.
     * The information returned includes command and column configuration information. This
     * operation replaces getUIConfigs operation, it returns the Awp0CommandCollectionRel
     * objects that associate the top level command collections to client scope in CommandConfigData2
     * structure instead of Awp0CommandCollection objects in CommandConfigData.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param getUiConfigsIn
     *        Contains input information required to retrieve UI configurations from the Teamcenter
     *        database.
     *
     * @return
     *         Returns: A list of command and column configurations based on the input provided
     *         to the operation. The following partial errors may be returned: 141112-Invalid Scope
     *         for the client. 141113-Invalid Client Scope.
     *
     * @deprecated
     *         As of ActiveWorkspace3.3, this operation is deprecated and created new SOA getUIConfigs3
     *         in AW3.3.0 release. So use new service definition Awp0::Soa::AWS2::UiConfig::getUIConfigs3.
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of ActiveWorkspace3.3, this operation is deprecated and created new SOA getUIConfigs3 in AW3.3.0 release. So use new service definition Awp0::Soa::AWS2::UiConfig::getUIConfigs3."))
#endif
    virtual Awp0::Services::Aws2::_2016_12::Uiconfig::GetUIConfigResponse getUIConfigs2 ( const std::vector< Awp0::Services::Aws2::_2016_12::Uiconfig::GetUIConfigInput >& getUiConfigsIn ) = 0;


protected:
    virtual ~Uiconfig() {}
};
            }
        }
    }
}

#include <awp0/services/aws2/AWS2_undef.h>
#endif

