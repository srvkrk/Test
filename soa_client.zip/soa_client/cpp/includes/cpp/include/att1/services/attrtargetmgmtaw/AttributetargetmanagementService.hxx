/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef ATT1_SERVICES_ATTRTARGETMGMTAW_ATTRIBUTETARGETMANAGEMENTSERVICE_HXX
#define ATT1_SERVICES_ATTRTARGETMGMTAW_ATTRIBUTETARGETMANAGEMENTSERVICE_HXX

#include <att1/services/attrtargetmgmtaw/_2015_03/Attributetargetmanagement.hxx>
#include <att1/services/attrtargetmgmtaw/_2015_10/Attributetargetmanagement.hxx>
#include <att1/services/attrtargetmgmtaw/_2017_06/Attributetargetmanagement.hxx>



#include <teamcenter/soa/client/Connection.hxx>
#include <new> // for size_t
#include <teamcenter/soa/common/MemoryManager.hxx>

#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable : 4996  )
#endif

#include <att1/services/attrtargetmgmtaw/AttrTargetMgmtAW_exports.h>

namespace Att1
{
    namespace Services
    {
        namespace Attrtargetmgmtaw
        {
            class AttributetargetmanagementService;

/**
 * Measurable Attribute and Target Management Service
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libatt1soaattrtargetmgmtawstrong.dll
 * </li>
 * <li type="disc">libatt1soaattrtargetmgmtawtypes.dll (runtime dependency)
 * </li>
 * </ul>
 */

class ATT1SOAATTRTARGETMGMTAWSTRONG_API AttributetargetmanagementService
    : public Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement,
             public Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement,
             public Att1::Services::Attrtargetmgmtaw::_2017_06::Attributetargetmanagement
{
public:
    static AttributetargetmanagementService* getService( Teamcenter::Soa::Client::Connection* );


    /**
     * This operation is used to assign measurable attributes (Att0MeasurableAttribute)
     * objects to given WorkspaceObject as input or output attributes for product validation
     * or measurement.
     * <br>
     * When an Att0MeasurableAttribute is assigned as input or output attribute, a save-as
     * operation is performed against the source attribute object and new relations will
     * be created to link the new Att0MeasurableAttribute with parent WorkspaceObject. Any
     * update on source attribute will not impact input or output attribute object, and
     * on the contrary.
     * <br>
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * 1. A system architect creates a product structure of logical blocks (Fnd0LogicalBlock),
     * and defines for each block its measurable attributes (Att0MeasurableAttribute). As
     * the design of the product architecture evolves, the system architect sets a logical
     * block attribute (Att0MeasurableAttribute) as an input of the validation context(WorkspaceObject),
     * the system builds a copy of the attribute for the validation context, and create
     * related links from input attribute to validation context.
     * <br>
     * 2. A system architect creates a product structure of logical blocks (Fnd0LogicalBlock),
     * and defines for each block its measurable attributes (Att0MeasurableAttribute), then
     * sets a logical block attribute (Att0MeasurableAttribute) as an output of the validation
     * context(WorkspaceObject).
     * <br>
     * However design changes and system architect needs to un-set the output attribute
     * for the validation context, the system deletes the output attributes as well as its
     * related output relations with validation context.
     * <br>
     * 3. A system architect creates a product structure of logical blocks (Fnd0LogicalBlock),
     * and defines for each block its measurable attributes (Att0MeasurableAttribute), then
     * sets a logical block attribute (Att0MeasurableAttribute) as an input of the validation
     * context(WorkspaceObject). However design changes and system architect needs to re-set
     * an input attribute as the output attribute of the validation context, the system
     * deletes the input attributes as well as its related input relations, then builds
     * a new copy of the source input attribute as an output attribute for the validation
     * context and creates related links from output attribute to validation context.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Attribute Target Management AW - This component consists of the Client and Enterprise
     * Tier code and constructs that support Attribute and Target related functionality
     * for Teamcenter Active Workspace application plus SOA, ITK and Preferences.
     *
     * @param inputs
     *        The measurable attribute assignment inputs.
     *
     * @param pref
     *        The measurable attribute assignment configuration.
     *
     * @return
     *         A map of client identifier to the Att0MeasurableAttribute objects. The following
     *         partial errors may be returned:
     *         <br>
     *         185401 - Invalid input or output parent object.
     *         <br>
     *         185405 - Input/output parent object is null.
     *         <br>
     *         185406 - The measurable attribute parameter is null.
     *         <br>
     *         185407 - The parent line must provide to set input/output measurable attribute.
     *         <br>
     *         185408 - The context line must provide to set input/output measurable attribute.
     *         <br>
     *         185409 - System does not support the given assign action.
     *         <br>
     *         185410 - The system does not support the "Assign" action on top lines.
     *
     */
    virtual Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::AssignMeasurableAttributesResponse assignMeasurableAttributes ( const std::vector< Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::AssignMeasurableAttributeInput >& inputs,
        const Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::AssignMeasurableAttributePref&  pref ) = 0;

    /**
     * This operation either creates a new measurable attribute object or modifies the existing
     * measurable attribute object depending on the input parameter.
     * <br>
     * Please refer to documentation for more details on Measurable Attribute object.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * Background
     * <br>
     * A Measurable Attribute is a characteristic of the system which can be externally
     * observed and has a target value or range in the context of the product, which must
     * be satisfied before the product is delivered. It consists of two parts. One is the
     * goal value and the other is the measured/validated value. A measurable attribute
     * may have more than one measured value (dependent of product maturity) and can be
     * seen in context of more than one application object.
     * <br>
     * Example: mass, cost, speed, pressure and other constituents of energy flow
     * <br>
     * <br>
     * 1.&nbsp;&nbsp;&nbsp;&nbsp;User wants to create a measurable attribute on the parent
     * object. For example, user wants to create a measurable attribute 'weight' on parent
     * object 'engine'.
     * <br>
     * 2.&nbsp;&nbsp;&nbsp;&nbsp;User has already created a measurable attribute on the
     * parent object and user wants to modify the properties of measurable attribute and
     * / or create a new measure value.
     * <br>
     * 3.&nbsp;&nbsp;&nbsp;&nbsp;The parent object is part of any assembly and now user
     * wants to override the value of measurable attribute properties in the context of
     * product. For example, Engine is part of assembly car and now user would like to change
     * the value of weight attribute on engine in the context of car.
     * <br>
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Attribute Target Management AW - This component consists of the Client and Enterprise
     * Tier code and constructs that support Attribute and Target related functionality
     * for Teamcenter Active Workspace application plus SOA, ITK and Preferences.
     *
     * @param inputs
     *        Information needed to create or modify the measurable attribute object.
     *
     * @return
     *         The response contains the list of measurable attribute objects which are either created
     *         or modified.
     *         <br>
     *         The following errors may be returned:
     *         <br>
     *         <br>
     *         185401 - Both the parent objects are NULL. Please provide value for either parentObj
     *         or parentLine input parameter.
     *         <br>
     *         185402 - Unable to create new measurable attribute. There is existing attribute on
     *         the parent object with the given name.
     *         <br>
     *         185403 - The input Measure Value type is not valid. Please contact the system administrator.
     *         <br>
     *         214116 - For any requested relation types the relation type name is invalid.
     *         <br>
     *         126214 - Unable to get Measurable Attributes because the provided context line does
     *         not have a BOMViewRevision.
     *
     * @deprecated
     *         As of Teamcenter 10.1.5, this operation does not support attachement of measurement
     *         datasets. Use the createOrUpdateMeasurableAttributes service operation.
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 10.1.5, this operation does not support attachement of measurement datasets. Use the createOrUpdateMeasurableAttributes service operation."))
#endif
    virtual Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::CreateOrModifyAttrResp createOrModifyMeasurableAttribute ( const std::vector< Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::CreateOrModifyAttrInput >& inputs ) = 0;

    /**
     * This operation gets the list of associated measurable attributes for the input parent
     * objects. A measurable attribute is a characteristic of the system which can be externally
     * observed and has a target value or range in the context of the product, which must
     * be satisfied before the product is delivered. It consists of two parts. One is the
     * goal value the other is the measured/validated value. A measurable attribute may
     * have more than one measured value (dependent of product maturity) and can be seen
     * in context of more than one application object.
     * <br>
     * Example: mass, cost, speed, pressure and other constituents of energy flow.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * 1.&nbsp;&nbsp;&nbsp;&nbsp;User has already created a measurable attribute on a parent
     * object and now user wants to see the list of attributes present on the object. For
     * example, user has created a measurable attribute 'mass' on 'Engine' and user wants
     * to see the value of attribute 'mass'.
     * <br>
     * 2.&nbsp;&nbsp;&nbsp;&nbsp;User wants to see overridden value of measurable attribute
     * on the parent object present in the assembly. For example, if 'Engine' is part of
     * 'Car' assembly and user has changed the value of 'mass' attribute on Engine in the
     * context of 'Car' then user wants to see the changed attribute value in context of
     * Car.
     * <br>
     * 3.&nbsp;&nbsp;&nbsp;&nbsp;User requires the list of measurable attributes associated
     * with the given model object of a validation contract.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Attribute Target Management AW - This component consists of the Client and Enterprise
     * Tier code and constructs that support Attribute and Target related functionality
     * for Teamcenter Active Workspace application plus SOA, ITK and Preferences.
     *
     * @param inputs
     *        A list of of parent objects to get associated measurable attributes.
     *
     * @return
     *         The response contains the list of associated measurable attributes objects with the
     *         parent objects provided in input.
     *         <br>
     *         <br>
     *         The following errors may be returned:
     *         <br>
     *         <br>
     *         185401 - Both the parent objects are NULL. Please provide value for either parentObj
     *         or parentLine input parameter.
     *         <br>
     *         214116 - For any requested relation types the relation type name is invalid.
     *         <br>
     *         126214 - Unable to get Measurable Attributes because the provided context line does
     *         not have a BOMViewRevision.
     *
     */
    virtual Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::GetMeasurableAttrResp getMeasurableAttributes ( const std::vector< Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::GetMeasurableAttrInput >& inputs ) = 0;

    /**
     * This operation assigns measurable attribute (Att0MeasurableAttribute) objects to
     * given WorkspaceObject as input or output attributes for product validation or measurement.
     * <br>
     * <br>
     * When an Att0MeasurableAttribute is assigned as input or output attribute, a save-as
     * operation is performed against the source attribute object and new relations will
     * be created to link the new Att0MeasurableAttribute with parent WorkspaceObject. Parent
     * Validaiton context (WorkspaceObject ) attribute can be set as Input or attribute
     * in associated Study(WorkspaceObject). Any update on source attribute will not impact
     * input or output attribute object, and on the contrary.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * 1. A system architect creates a product structure of logical blocks (Fnd0LogicalBlock),
     * and defines for each block its measurable attributes (Att0MeasurableAttribute). As
     * the design of the product architecture evolves, the system architect sets a logical
     * block attribute (Att0MeasurableAttribute) as an input of the validation context(WorkspaceObject),
     * the system builds a copy of the attribute for the validation context(WorkspaceObject),
     * and create related links from input attribute to validation context(WorkspaceObject).
     * System architect can set available Attribute from Validation Context (WorkspaceObject)
     * in Study(WorkspaceObject) as Input or Output for further specific analysis.
     * <br>
     * 2. A system architect creates a product structure of logical blocks (Fnd0LogicalBlock),
     * and defines for each block its measurable attributes (Att0MeasurableAttribute), then
     * sets a logical block attribute (Att0MeasurableAttribute) as an input or output of
     * the validation context(WorkspaceObject). System architect sets Validation Context(WorkspaceObject)
     * attribute as Input or Output on Study(WorkspaceObject). However design changes and
     * system architect needs to un-set the output attribute for the validation context(WorkspaceObject),
     * the system deletes the output attributes as well as its related output relations
     * with validation context(WorkspaceObject). If Validation Context(WorkspaceObject)
     * attribute is used in Study(WorkspaceObject) system will warn user to proceed or not
     * about attribute reference in Study(WorkspaceObject), before deleting its reference
     * from Study(WorkspaceObject). User can ignore or proceed.
     * <br>
     * 3. A system architect creates a product structure of logical blocks (Fnd0LogicalBlock),
     * and defines for each block its measurable attributes (Att0MeasurableAttribute), then
     * sets a logical block attribute (Att0MeasurableAttribute) as an input of the validation
     * context(WorkspaceObject). System architect sets Validation Context(WorkspaceObject)
     * attribute as Input or Output on Study(WorkspaceObject). However design changes and
     * system architect needs to re-set an input attribute as the output attribute of the
     * validation context(WorkspaceObject), the system deletes the input attributes as well
     * as its related input relations, then builds a new copy of the source input attribute
     * as an output attribute for the validation context(WorkspaceObject) and creates related
     * links from output attribute to validation context(WorkspaceObject). If Validation
     * Context(WorkspaceObject) attribute is referenced in Study(WorkspaceObject) and user
     * changes the direction of Validation Context(WorkspaceObject) attribute from input
     * to output or vice-versa, system will automatically change the direction of referenced
     * attribute in Study(WorkspaceObject). Before direction change, system will warn user
     * to proceed or not. User can ignore operation or proceed.
     * <br>
     * 4. A system architect creates a product structure of logical blocks (Fnd0LogicalBlock),
     * and defines for each block its measurable attributes (Att0MeasurableAttribute), then
     * sets a logical block attribute (Att0MeasurableAttribute) as an input of the validation
     * context(WorkspaceObject). System architect may set Validation Context(WorkspaceObject)
     * attribute as Input or Output on Study(WorkspaceObject). However in case of re-set
     * or change direction of Validation Context(WorkspaceObject) attribute, system will
     * not warn, if there is no impact on Studies. System will delete or change direction
     * of attribute in Validation Context(WorkspaceObject) only.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Attribute Target Management AW - This component consists of the Client and Enterprise
     * Tier code and constructs that support Attribute and Target related functionality
     * for Teamcenter Active Workspace application plus SOA, ITK and Preferences.
     *
     * @param inputs
     *        The measurable attribute assignment inputs.
     *
     * @param pref
     *        The measurable attribute assignment configuration.
     *
     * @return
     *         Returns:
     *         <br>
     *         A map of client identifier to the Att0MeasurableAttribute objects. The following
     *         partial errors may be returned:
     *         <br>
     *         <ul>
     *         <li type="disc">185401 - Invalid input or output parent object.
     *         </li>
     *         <li type="disc">185405 - Input/output parent object is null.
     *         </li>
     *         <li type="disc">185406 - The measurable attribute parameter is null.
     *         </li>
     *         <li type="disc">185407 - The parent line must provide to set input/output measurable
     *         attribute.
     *         </li>
     *         <li type="disc">185408 - The context line must provide to set input/output measurable
     *         attribute.
     *         </li>
     *         <li type="disc">185409 - System does not support the given assign action.
     *         </li>
     *         </ul>
     *
     */
    virtual Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::AssignMeasurableAttributesResponse2 assignMeasurableAttributes2 ( const std::vector< Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::AssignMeasurableAttributeInput2 >& inputs,
        const Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::AssignMeasurableAttributePref2&  pref ) = 0;

    /**
     * This operation either creates a new measurable attribute object or modifies the existing
     * measurable attribute object depending on the input parameter.
     * <br>
     * Please refer to documentation for more details on Measurable Attribute object.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * Background
     * <br>
     * A Measurable Attribute is a characteristic of the system which can be externally
     * observed and has a target value or range in the context of the product, which must
     * be satisfied before the product is delivered. It consists of two parts. One is the
     * goal value and the other is the measured/validated value. A measurable attribute
     * may have more than one measured value (dependent of product maturity) and can be
     * seen in context of more than one application object.
     * <br>
     * Example: mass, cost, speed, pressure and other constituents of energy flow
     * <br>
     * <br>
     * 1. User wants to create a measurable attribute on the parent object. For example,
     * user wants to create a measurable
     * <br>
     * attribute 'weight' on parent object 'engine'.
     * <br>
     * 2. User has already created a measurable attribute on the parent object and user
     * wants to update the properties of
     * <br>
     * measurable attribute and / or create a new measure value.
     * <br>
     * 3. The parent object is part of any assembly and now user wants to override the value
     * of measurable attribute
     * <br>
     * properties in the context of product. For example, Engine is part of assembly
     * car and now user would like to change
     * <br>
     * the value of weight attribute on engine in the context of car.
     * <br>
     * 4. User wants to attach a dataset to Measure Value object.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Attribute Target Management AW - This component consists of the Client and Enterprise
     * Tier code and constructs that support Attribute and Target related functionality
     * for Teamcenter Active Workspace application plus SOA, ITK and Preferences.
     *
     * @param inputs
     *        Information needed to create or update the measurable attribute object.
     *
     * @return
     *         The response contains the list of measurable attribute objects which are either created
     *         or modified.
     *         <br>
     *         The following errors may be returned:
     *         <br>
     *         <br>
     *         185401 - Both the parent objects are NULL. Please provide value for either parentObj
     *         or parentLine input parameter.
     *         <br>
     *         185402 - Unable to create new measurable attribute. There is existing attribute on
     *         the parent object with the given name.
     *         <br>
     *         185403 - The input Measure Value type is not valid. Please contact the system administrator.
     *         <br>
     *         214116 - For any requested relation types the relation type name is invalid.
     *         <br>
     *         126214 - Unable to get Measurable Attributes because the provided context line does
     *         not have a BOMViewRevision.
     *
     */
    virtual Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::CreateOrUpdateAttrResp createOrUpdateMeasurableAttribute ( const std::vector< Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::CreateOrUpdateAttrInput >& inputs ) = 0;

    /**
     * This operation gets the list of associated measurable attributes for the input parent
     * objects. A measurable attribute is a characteristic of the system which can be externally
     * observed and has a target value or range in the context of the product, which must
     * be satisfied before the product is delivered. It consists of two parts. One is the
     * goal value and the other is the measured and validated value. A measurable attribute
     * may have more than one measured value (dependent of product maturity) and can be
     * seen in context of more than one application object.
     * <br>
     * Example: mass, cost, speed, pressure and other constituents of energy flow
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * 1. User has already created a measurable attribute on a parent object and now user
     * wants to see the list of attributes present on the object. For example, user has
     * created a measurable attribute 'mass' on 'Engine' and user wants to see the value
     * of attribute 'mass'.
     * <br>
     * 2. User wants to see overridden value of measurable attribute on the parent object
     * present in the assembly. For example, if 'Engine' is part of 'Car' assembly and user
     * has changed the value of 'mass' attribute on Engine in the context of 'Car' then
     * user wants to see the changed attribute value in context of Car.
     * <br>
     * 3. User requires the list of measurable attributes associated with the given model
     * object of a validation contract.
     * <br>
     * 4. User has already created the measurable attribute on Crt0VldnContract object and
     * now user wants to set these attributes as Input or Output on Study object.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Attribute Target Management AW - This component consists of the Client and Enterprise
     * Tier code and constructs that support Attribute and Target related functionality
     * for Teamcenter Active Workspace application plus SOA, ITK and Preferences.
     *
     * @param inputs
     *        A list of parent objects to get associated measurable attributes.
     *
     * @return
     *         The response contains the list of associated measurable attributes objects with the
     *         parent objects provided in input.
     *         <br>
     *         <br>
     *         The following errors may be returned:
     *         <br>
     *         <br>
     *         185401 - Both the parent objects are NULL. Please provide value for either parentObj
     *         or parentLine input parameter.
     *         <br>
     *         214116 - For any requested relation types the relation type name is invalid.
     *         <br>
     *         126214 - Unable to get Measurable Attributes because the provided context line does
     *         not have a BOMViewRevision.
     *
     */
    virtual Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::GetMeasurableAttrResp2 getMeasurableAttributes2 ( const std::vector< Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::GetMeasurableAttrInput >& inputs ) = 0;

    /**
     * This operation is used to synchronize <i>Att0MeasurableAttribute</i> objects between
     * source <i>Att0MeasurableAttribute</i> instances and target <i>Att0MeasurableAttribute</i>
     * instances. This synchronization operation has two process flows: synchronize from
     * source <i>Att0MeasurableAttribute</i> instances to input <i>Att0MeasurableAttribute</i>
     * instances; and publish from output <i>Att0MeasurableAttribute</i> instances to source
     * <i>Att0MeasurableAttribute</i> instances.
     * <br>
     * <ul>
     * <li type="disc">When synchronize from source to input <i>Att0MeasurableAttribute</i>,
     * an update operation is done against input <i>Att0MeasurableAttribute</i> with latest
     * property values from source <i>Att0MeasurableAttribute</i>. Meanwhile copies the
     * latest <i>Att0MeasurableValue</i> of source <i>Att0MeasurableAttribute</i> and inserts
     * it into the input <i>Att0MeasurableAttribute</i>.
     * </li>
     * <li type="disc">When publish from output to source <i>Att0MeasurableAttribute</i>,
     * the latest <i>Att0MeasurableValue</i> is retrieved from output <i>Att0MeasurableAttribute</i>
     * and inserts it into the latest <i>Att0MeasurableValue</i> list on the source <i>Att0MeasurableAttribute</i>.
     * The source <i>Att0MeasurableAttribute</i> properties will not be updated. If there
     * is an issue during publication, the process stops and all modified objects are be
     * restored.
     * </li>
     * </ul>
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * <ul>
     * <li type="disc">A systems designer creates an analysis request with one or multiple
     * products. He adds the input elements, i.e. system block (<i>Fnd0LogicalBlock</i>),
     * to the analysis request, and set the input measurable attribute (<i>Att0MeasurableAttribute</i>)
     * from the system block to the analysis request. And then transfer the analysis request
     * to the simulation engineer via the workflow. While processing the analysis request,
     * the simulation engineer would be aware that some of input measurable attributes are
     * out-of-date, and he is able to use "Refresh" command to synchronize between the system
     * blocks' attributes and input attributes.
     * </li>
     * <li type="disc">A systems designer creates an analysis request with one or multiple
     * products. He adds the input elements, i.e. system block (<i>Fnd0LogicalBlock</i>),
     * to the analysis request, and set the output measurable attribute (<i>Att0MeasurableAttribute</i>)
     * from the system block to the analysis request. And then transfer the analysis request
     * to the simulation engineer via the workflow. The simulation engineer updates the
     * output measurable attributes according to the simulation test result. And then he
     * is able to use "Publish" command to synchronize between the output attributes and
     * system block's attributes.
     * </li>
     * </ul>
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Attribute Target Management AW - This component consists of the Client and Enterprise
     * Tier code and constructs that support Attribute and Target related functionality
     * for Teamcenter Active Workspace application plus SOA, ITK and Preferences.
     *
     * @param inputs
     *        The synchronization measurable attribute inputs
     *
     * @param pref
     *        The synchronization measurable attribute preference.
     *
     * @return
     *         A map of client identifier to the Att0MeasurableAttribute objects. The following
     *         partial errors may be returned:
     *         <br>
     *         <br>
     *         <ul>
     *         <li type="disc">185017 - The given object is invalid primary object for Input Measurable
     *         Attribute.
     *         </li>
     *         <li type="disc">185018 - The given object is invalid primary object for Output Measurable
     *         Attribute.
     *         </li>
     *         <li type="disc">185025 - Some input Att0MeasurableAttribute objects are out of date,
     *         publication could only be done when all input Att0MeasurableAttribute objects are
     *         up to date.
     *         </li>
     *         <li type="disc">185026 - The given synchronization candidates type does not match
     *         to the source object type.
     *         </li>
     *         <li type="disc">185027 - The validation object is not allowed to publish measurable
     *         attributes, because its release status is not match with pre-defined ones.
     *         </li>
     *         </ul>
     *
     */
    virtual Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::SyncMeasurableAttributeResponse synchronizeMeasuableAttributes ( const std::vector< Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::SyncMeasurableAttributeInput >& inputs,
        const Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::SyncMeasurableAttributePref&  pref ) = 0;

    /**
     * Adds a list of Measurable Attributes to the given object via the specified relation.
     * <br>
     * <br>
     * When the given object is the <b>WorkspaceObject</b>,
     * <br>
     * Add as Copy
     * <br>
     * This operation hard copies the input measurable attributes and adds the copied measurable
     * attributes to the <b>WorkspaceObject</b> via the specified relation.
     * <br>
     * Note, the input measurable attribute can't be added, if a measurable attribute exists
     * with the same name under the given <b>WorkspaceObject</b>.
     * <br>
     * Add as Reference
     * <br>
     * This operation adds the input measurable attributes to the <b>WorkspaceObject</b>
     * via the specified relation.
     * <br>
     * <br>
     * When the given object is the <b>Awb0Element</b>, it adds the input measurable attributes
     * to the underlying object for the given <b>Awb0Element</b>.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * <ul>
     * <li type="disc">Users add the measurable attributes as copy to the given <b>WorkspaceObject</b>
     * via the relation <b>Att0AttrRelation</b>.
     * </li>
     * <li type="disc">Users add the measurable attributes as reference to the given WorkspaceObject
     * via the relation <b>IMAN_reference</b>
     * </li>
     * <li type="disc">Users add the measurable attributes as copy to the given <b>Awb0Element</b>
     * via the relation <b>Att0AttrRelation</b>.
     * </li>
     * <li type="disc">Users add the measurable attributes as reference to the given <b>Awb0Element</b>
     * via the relation <b>IMAN_reference</b>
     * </li>
     * </ul>
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Attribute Target Management AW - This component consists of the Client and Enterprise
     * Tier code and constructs that support Attribute and Target related functionality
     * for Teamcenter Active Workspace application plus SOA, ITK and Preferences.
     *
     * @param inputs
     *        A list of structures contains details to add Measurable Attributes to the given object
     *        via the specified relation
     *
     * @return
     *         Contains a list of AttachMeasurableAttrOutput structures (which contain the added
     *         attributes and ignored attributes). Any created objects will be sent back in the
     *         standard ServiceData lists of created objects. Any failure will be returned with
     *         client id mapped to error message in the ServiceData list of partial errors.
     *         <br>
     *         <br>
     *         The following partial errors may be returned:
     *         <br>
     *         <ul>
     *         <li type="disc">185415 - The given object must be a type of WorkspaceObject or Awb0Element.
     *         </li>
     *         </ul>
     *
     */
    virtual Att1::Services::Attrtargetmgmtaw::_2017_06::Attributetargetmanagement::AttachMeasurableAttrResp attachMeasurableAttributes ( const std::vector< Att1::Services::Attrtargetmgmtaw::_2017_06::Attributetargetmanagement::AttachMeasurableAttrInput >& inputs ) = 0;


    SOA_CLASS_NEW_OPERATORS_WITH_IMPL("AttributetargetmanagementService")

};
        }
    }
}


#ifdef WIN32
#pragma warning ( pop )
#endif

#include <att1/services/attrtargetmgmtaw/AttrTargetMgmtAW_undef.h>
#endif

