/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef SMR1_SERVICES_MROCOREAW__2015_03_MROCOREAW_HXX
#define SMR1_SERVICES_MROCOREAW__2015_03_MROCOREAW_HXX

#include <teamcenter/soa/client/model/Item.hxx>
#include <teamcenter/soa/client/model/Lot.hxx>
#include <teamcenter/soa/client/model/PhysicalPartRevision.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <smr1/services/mrocoreaw/MROCoreAw_exports.h>

namespace Smr1
{
    namespace Services
    {
        namespace Mrocoreaw
        {
            namespace _2015_03
            {
                class Mrocoreaw;

class SMR1SOAMROCOREAWSTRONG_API Mrocoreaw
{
public:

    struct AssignLotInfo;
    struct CreateLotInfo;
    struct CreateAndAssignLotInfo;

    /**
     * This operation assigns the Lot to the PhysicalPart and deducts the quantity by the
     * specified size. If the Size is greater than the lot usage or the PhysicalPart quantity
     * then the error is thrown. If the physicalBOMLine is not provided then the specified
     * quantity is deducted from the Lot assigned to PhysicalPartRevision. If the physicalBOMLine
     * is provided then the specified quantity is deducted from the Lot that is assigned
     * to PhysicalPartRevision from the PhysicalBomLine, if the quantity is less than the
     * expected quantity then the missing PhysicalPart is created with the remaning quantity.
     */
    struct AssignLotInfo
    {
        /**
         * The PhysicalPartRevision object to which the lot will be assigned.
         */
        Teamcenter::Soa::Client::Model::PhysicalPartRevision* physicalPartRevision;
        /**
         * The Lot object which will be assigned.
         */
        Teamcenter::Soa::Client::Model::Lot* lot;
        /**
         * Integer quantity that will be deducted from the lot after the assignment.
         */
        int quantity;
    };

    /**
     * This operation creates a Lot for the PhysicalPart.
     */
    struct CreateLotInfo
    {
        /**
         * This is <b>Item</b> for which lot is being created.
         */
        Teamcenter::Soa::Client::Model::Item* designItem;
        /**
         * The lot number with which lot will get created.
         */
        std::string lotNumber;
        /**
         * The manufacturer ID of the lot to create.
         */
        std::string manufacturerID;
        /**
         * Integer quantity of the lot size.
         */
        int quantity;
        /**
         * The expiration date of lot.
         */
        Teamcenter::Soa::Common::DateTime expirationDate;
    };

    /**
     * A generic container that represents the parameters required to create, assign or
     * create with Assign a lot to physical part. By default, create with assign action
     * is performed. This is overridden by the create or the assign being turned on.
     */
    struct CreateAndAssignLotInfo
    {
        /**
         * The data necessary to support the create Lot action.
         */
        Smr1::Services::Mrocoreaw::_2015_03::Mrocoreaw::CreateLotInfo createLotInfo;
        /**
         * The data necessary to support the Assign Lot action.
         */
        Smr1::Services::Mrocoreaw::_2015_03::Mrocoreaw::AssignLotInfo assignLotInfo;
        /**
         * If 0 a new lot will be created.
         * <br>
         * If 1 lot will be assigned to physical part.
         * <br>
         * If 2 a new lot will be created and assigned to physical part.
         */
        int createAndAssign;
    };




    /**
     * This operation creates or/and assigns the Lot to the PhysicalPart .
     * <br>
     * If its assign it deducts the quantity by the specified size. If the Size is greater
     * than the lot usage or the PhysicalPart quantity then the error is thrown.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * MRO Core - MRO Core
     *
     * @param info
     *        A list of CreateAndAssignLotInfo structures which hold the information to create
     *        or/and assign the Lot to the PhysicalPart.
     *
     * @return
     *         There are no objects returned but in case of failure to delete the objects, errors
     *         are returned in the ServiceData. Following error conditions are handled and returned
     *         in the ServiceData:
     *         <br>
     *         <ul>
     *         <li type="disc">237031 if the lot Size is exhausted for the Lot Number.
     *         </li>
     *         <li type="disc">237069 if the lot expiration date is earlier than manufacturing date.
     *         </li>
     *         <li type="disc">237004 if the lot does not exist.
     *         </li>
     *         <li type="disc">237098 if the lot quantity is greator than the expected quantity.
     *         </li>
     *         <li type="disc">237099 if the lot does not match the PhysicalPart quantity.
     *         </li>
     *         <li type="disc">149008 if the lot is less than the expected quantity
     *         </li>
     *         <li type="disc">149010 if the lot Install Part Quantity is greater than the Lot Size.
     *         </li>
     *         <li type="disc">149011 if the lot Expiration Date has passed.
     *         </li>
     *         <li type="disc">149012 if the lot already exists with this Lot Number and Manufacturer
     *         ID.
     *         </li>
     *         <li type="disc">149013 if quantity to be installed does not match the expected quantity.
     *         </li>
     *         </ul>
     *
     */
    virtual Teamcenter::Soa::Client::ServiceData createAndAssignLot ( const std::vector< Smr1::Services::Mrocoreaw::_2015_03::Mrocoreaw::CreateAndAssignLotInfo >& info ) = 0;


protected:
    virtual ~Mrocoreaw() {}
};
            }
        }
    }
}

#include <smr1/services/mrocoreaw/MROCoreAw_undef.h>
#endif

