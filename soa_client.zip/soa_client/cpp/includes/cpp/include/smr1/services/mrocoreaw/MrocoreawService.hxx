/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef SMR1_SERVICES_MROCOREAW_MROCOREAWSERVICE_HXX
#define SMR1_SERVICES_MROCOREAW_MROCOREAWSERVICE_HXX

#include <smr1/services/mrocoreaw/_2015_03/Mrocoreaw.hxx>



#include <teamcenter/soa/client/Connection.hxx>
#include <new> // for size_t
#include <teamcenter/soa/common/MemoryManager.hxx>

#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable : 4996  )
#endif

#include <smr1/services/mrocoreaw/MROCoreAw_exports.h>

namespace Smr1
{
    namespace Services
    {
        namespace Mrocoreaw
        {
            class MrocoreawService;

/**
 * service for SOA MROCore
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libsmr1soamrocoreawstrong.dll
 * </li>
 * <li type="disc">libsmr1soamrocoreawtypes.dll (runtime dependency)
 * </li>
 * </ul>
 */

class SMR1SOAMROCOREAWSTRONG_API MrocoreawService
    : public Smr1::Services::Mrocoreaw::_2015_03::Mrocoreaw
{
public:
    static MrocoreawService* getService( Teamcenter::Soa::Client::Connection* );


    /**
     * This operation creates or/and assigns the Lot to the PhysicalPart .
     * <br>
     * If its assign it deducts the quantity by the specified size. If the Size is greater
     * than the lot usage or the PhysicalPart quantity then the error is thrown.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * MRO Core - MRO Core
     *
     * @param info
     *        A list of CreateAndAssignLotInfo structures which hold the information to create
     *        or/and assign the Lot to the PhysicalPart.
     *
     * @return
     *         There are no objects returned but in case of failure to delete the objects, errors
     *         are returned in the ServiceData. Following error conditions are handled and returned
     *         in the ServiceData:
     *         <br>
     *         <ul>
     *         <li type="disc">237031 if the lot Size is exhausted for the Lot Number.
     *         </li>
     *         <li type="disc">237069 if the lot expiration date is earlier than manufacturing date.
     *         </li>
     *         <li type="disc">237004 if the lot does not exist.
     *         </li>
     *         <li type="disc">237098 if the lot quantity is greator than the expected quantity.
     *         </li>
     *         <li type="disc">237099 if the lot does not match the PhysicalPart quantity.
     *         </li>
     *         <li type="disc">149008 if the lot is less than the expected quantity
     *         </li>
     *         <li type="disc">149010 if the lot Install Part Quantity is greater than the Lot Size.
     *         </li>
     *         <li type="disc">149011 if the lot Expiration Date has passed.
     *         </li>
     *         <li type="disc">149012 if the lot already exists with this Lot Number and Manufacturer
     *         ID.
     *         </li>
     *         <li type="disc">149013 if quantity to be installed does not match the expected quantity.
     *         </li>
     *         </ul>
     *
     */
    virtual Teamcenter::Soa::Client::ServiceData createAndAssignLot ( const std::vector< Smr1::Services::Mrocoreaw::_2015_03::Mrocoreaw::CreateAndAssignLotInfo >& info ) = 0;


    SOA_CLASS_NEW_OPERATORS_WITH_IMPL("MrocoreawService")

};
        }
    }
}


#ifdef WIN32
#pragma warning ( pop )
#endif

#include <smr1/services/mrocoreaw/MROCoreAw_undef.h>
#endif

