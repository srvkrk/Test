/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef CRT1_SERVICES_VALIDATIONCONTRACTAW__2015_10_VCMANAGEMENT_HXX
#define CRT1_SERVICES_VALIDATIONCONTRACTAW__2015_10_VCMANAGEMENT_HXX

#include <teamcenter/soa/client/model/Awb0Element.hxx>
#include <teamcenter/soa/client/model/Crt0ValidationLink.hxx>
#include <teamcenter/soa/client/model/Crt0VldnContractRevision.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <crt1/services/validationcontractaw/ValidationContractAW_exports.h>

namespace Crt1
{
    namespace Services
    {
        namespace Validationcontractaw
        {
            namespace _2015_10
            {
                class Vcmanagement;

class CRT1SOAVALIDATIONCONTRACTAWSTRONG_API Vcmanagement
{
public:

    struct AddStatusOfObject;
    struct AddStatusOfObjectsOutput;
    struct AreObjsAddedToAnalysisReqInput;
    struct AreObjsAddedToAnalysisReqResponse;

    /**
     * In the map the key is the <b>Awb0Element</b> object, which is checked to determine
     * if it is already added to the Analysis Request. The value is an <b>AddStatusOfObject</b>
     * object, corresponding to the <b>Awb0Element</b>.
     */
    typedef std::map< Teamcenter::Soa::Client::Model::Awb0Element*, AddStatusOfObject > AddStatusOfObjectsMap;

    /**
     * This structure contains an 'Added' status to indicate whether an <b>Awb0Element</b>
     * is added to an Analysis Request or not, and also contains a link which connects the
     * <b>Awb0Element</b> to the Analysis Request.
     */
    struct AddStatusOfObject
    {
        /**
         * Value of this boolean is true if <b>Awb0Element</b> object is added to Analysis Request,
         * else the value is false.
         */
        bool addStatus;
        /**
         * The tracelink which connects the Analysis Request and the <b>Awb0Element</b>. The
         * value is null if addStatus is false.
         */
        Teamcenter::Soa::Client::Model::Crt0ValidationLink* validationLink;
    };

    /**
     * This structure contains Request an Analysis Request (<b>Crt0VldnContractRevision</b>)
     * and an 'Added' status for each <b>Awb0Element</b> object, along with the tracelink
     * between the object and the Analysis Request.
     */
    struct AddStatusOfObjectsOutput
    {
        /**
         * The Analysis Request Revision (<b>Crt0VldnContractRevision</b>)..
         */
        Teamcenter::Soa::Client::Model::Crt0VldnContractRevision* analysisRequest;
        /**
         * This is a map (<b>Awb0Elements</b>/boolean) of each <b>Awb0Element</b> object and
         * its 'added' status.
         */
        AddStatusOfObjectsMap objectStatus;
    };

    /**
     * This structure contains objects to be added to an Analysis Request.
     */
    struct AreObjsAddedToAnalysisReqInput
    {
        /**
         * The Analysis Request Revision.
         */
        Teamcenter::Soa::Client::Model::Crt0VldnContractRevision* analysisRequest;
        /**
         * <b>Awb0Element</b> objects which will be checked to determine if they are already
         * added to the Analysis Request.
         */
        std::vector< Teamcenter::Soa::Client::Model::Awb0Element* > objects;
    };

    /**
     * This structure contains a set of <b>Crt0VldnContractRevision</b> objects with the
     * 'added' state and tracelink for each <b>Awb0Element</b> in <b>objectsStatusOutput</b>
     * and partial errors in <b>serviceData</b>.
     */
    struct AreObjsAddedToAnalysisReqResponse
    {
        /**
         * The set of <b>Crt0VldnContractRevision</b> objects with the 'added' state for each
         * <b>Awb0Element</b>.
         */
        std::vector< Crt1::Services::Validationcontractaw::_2015_10::Vcmanagement::AddStatusOfObjectsOutput > objectsStatusOutput;
        /**
         * This is a common data structure used to return sets of Teamcenter Data Model objects
         * and service exceptions from a service request
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };




    /**
     * Objects that need to be validated or analyzed must be added to an Analysis Request.
     * This operation adds or updates for validation or analysis purpose, all the objects
     * from the current Architecture Diagram of the input Analysis Request's (<b>Crt0VldnContractRevision</b>)
     * domain.
     * <br>
     * 1. If objects have not been previously added, all the current Architecture Diagram
     * elements are added to the Analysis Request.
     * <br>
     * 2. If objects have been previously added, they are removed and all the current Architecture
     * Diagram elements are added to the Analysis Request.
     * <br>
     * All the objects that are displayed in the diagram and those that meet the Analysis
     * Request's definition criteria are added to the Analysis Request. This includes any
     * displayed children of any object  in the diagram.
     * <br>
     * If the Analysis Definition contains more than one possible sections that can accept
     * an object, the object will be added to the first possible section.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * 1. Add the Domain's models, requirements, targets, test cases from the Architecture
     * <br>
     * diagram to the Analysis Request in a simplified manner.
     * <br>
     * Prior to creating an Analysis Request, specific elements    relavant for an analysis
     * or validation are turned ON in the domain, so that they appear on the Architecture
     * Diagram.  User selects a one step command in Active Workspace to add or update objects
     * from the Architecture Diagram to the Analysis Request in one go.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace Validation Contract - This is a component for Active Workspace Validation
     * Contract.
     *
     * @param input
     *        Analysis Requests (<b>Crt0VldnContractRevision</b>) whose diagram elements must be
     *        added for validation/analysis.
     *
     * @return
     *         The successfully updated Analysis Request objects are returned in the Updated list
     *         of the ServiceData. The following  partial errors may be retured:
     *         <br>
     *         <br>
     *         184021 :The object being added to the Analysis Request is not accepted by any section
     *         specified in the Analysis Request's definition.
     *
     */
    virtual Teamcenter::Soa::Client::ServiceData addObjectsForValidationFromDiagram ( const std::vector< Teamcenter::Soa::Client::Model::Crt0VldnContractRevision* >& input ) = 0;

    /**
     * Objects that need to be validated must be added to an Analysis Request. This operation
     * checks whether the input objects are already added to the input Analysis Request.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * <b>Give visual indication of objects added to the Analysis Request</b>:
     * <br>
     * Add a Product's component (<b>Awb0Element</b>) to an Analysis Request. When the same
     * component is again selected for adding to the Analysis Request, a visual indication
     * must be given to the user that it is already added.  This can be achieved for example
     * by greying out a command on the client.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace Validation Contract - This is a component for Active Workspace Validation
     * Contract.
     *
     * @param input
     *        Information of objects to be added to an Analysis Request.
     *
     * @return
     *         The set of <b>Crt0VldnContractRevision</b> objects with the 'added' state for each
     *         <b>Awb0Element</b>. Following partial errors may be returned.
     *         <br>
     *         <ul>
     *         <li type="disc">184006: There are no adapters defined for the <b>Awb0Element</b>.
     *         </li>
     *         </ul>
     *
     */
    virtual Crt1::Services::Validationcontractaw::_2015_10::Vcmanagement::AreObjsAddedToAnalysisReqResponse areObjectsAddedToAnalysisRequest ( const std::vector< Crt1::Services::Validationcontractaw::_2015_10::Vcmanagement::AreObjsAddedToAnalysisReqInput >& input ) = 0;


protected:
    virtual ~Vcmanagement() {}
};
            }
        }
    }
}

#include <crt1/services/validationcontractaw/ValidationContractAW_undef.h>
#endif

