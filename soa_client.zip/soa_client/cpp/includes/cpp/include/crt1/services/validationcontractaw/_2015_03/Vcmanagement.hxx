/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef CRT1_SERVICES_VALIDATIONCONTRACTAW__2015_03_VCMANAGEMENT_HXX
#define CRT1_SERVICES_VALIDATIONCONTRACTAW__2015_03_VCMANAGEMENT_HXX

#include <teamcenter/soa/client/model/Awb0Element.hxx>
#include <teamcenter/soa/client/model/Crt0ValidationLink.hxx>
#include <teamcenter/soa/client/model/Crt0VldnContractRevision.hxx>
#include <teamcenter/soa/client/model/WorkspaceObject.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <crt1/services/validationcontractaw/ValidationContractAW_exports.h>

namespace Crt1
{
    namespace Services
    {
        namespace Validationcontractaw
        {
            namespace _2015_03
            {
                class Vcmanagement;

class CRT1SOAVALIDATIONCONTRACTAWSTRONG_API Vcmanagement
{
public:

    struct AddedObjectInfo;
    struct AddObjsForValidationInput;
    struct AddResultsOfValidationInput;
    struct ContractDefnOutput;
    struct ContractDefnSection;
    struct GetObjectsAddForValidationInput;
    struct GetResultsOfValidationInput;
    struct GetValidationResultsResponse;
    struct ObjectAddedForValidationRespData;
    struct ObjectInfo;
    struct ObjectsAddForValidationResponse;
    struct ResultObjectInfo;
    struct ValidationResultsRespData;

    /**
     * This structure contains detailed information of the objects that are added to the
     * Validation Contract.
     */
    struct AddedObjectInfo
    {
        /**
         * Object that was added to the Validation Contract (<b>Crt0VldnContractRevision</b>)for
         * validation activity.
         */
        Teamcenter::Soa::Client::Model::Awb0Element* addedObject;
        /**
         * The trace link between the object and the validation contract (<b>Crt0VldnContractRevision</b>).
         */
        Teamcenter::Soa::Client::Model::Crt0ValidationLink* vcLink;
    };

    /**
     * This structure contains all information required to add objects to Validation Contract.
     */
    struct AddObjsForValidationInput
    {
        /**
         * This unique ID is used to identify return data elements and partial errors associated
         * with this input structure.
         */
        std::string clientId;
        /**
         * Tracelink of type "Crt0ValidationLink" to be created.
         */
        std::string traceLinkType;
        /**
         * Name of the "view" group's section where object needs to be added. Specify the section
         * name as in the Contract Definition's package file. The Contract Definition which
         * has the package file is specified when creating the Validation Contract.
         */
        std::string sectionName;
        /**
         * The Validation Contract Revision (<b>Crt0VldnContractRevision</b>) object.
         */
        Teamcenter::Soa::Client::Model::Crt0VldnContractRevision* start;
        /**
         * The Component (<b>Awb0Element</b>) that needs to be validated.
         */
        Teamcenter::Soa::Client::Model::Awb0Element* end;
        /**
         * The Context in which tracelink has to be created.
         * <br>
         * If endContext is not NULL, an in-context tracelink is created.
         * <br>
         * If endContext is NULL, a tracelink is created with underlying Awb0Element's <b>ItemRevision</b>.
         */
        Teamcenter::Soa::Client::Model::Awb0Element* endContext;
    };

    /**
     * This structure contains all information required to add result objects to Validation
     * Contract.
     */
    struct AddResultsOfValidationInput
    {
        /**
         * This unique ID is used to identify return data elements and partial errors associated
         * with this input structure.
         */
        std::string clientId;
        /**
         * Tracelink of type "<b>Crt0ValidationLink</b>" to be created.
         */
        std::string traceLinkType;
        /**
         * Name of the "results" group section where object needs to be added. Specify the section
         * name as in the Contract Definition's package file. The Contract Definition which
         * has the package file is specified when creating the Validation Contract.
         */
        std::string sectionName;
        /**
         * The Validation Contract Revision (<b>Crt0VldnContractRevision</b>) object.
         */
        Teamcenter::Soa::Client::Model::Crt0VldnContractRevision* vcRevision;
        /**
         * The result objects.
         */
        std::vector< Teamcenter::Soa::Client::Model::WorkspaceObject* > resultObjects;
    };

    /**
     * This structure contains detailed information of the Contract Definition (i.e. the
     * Contract Package that is attached to the Contract Definition).
     */
    struct ContractDefnOutput
    {
        /**
         * Section group name (Example: View, Results, etc).
         */
        std::string groupName;
        /**
         * A list of ContractDefnSection objects detailing Section information.
         */
        std::vector< Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::ContractDefnSection > contractDefnSections;
    };

    /**
     * This structure contains detailed information of the sections specified within a group
     * in a Contract Definition.
     */
    struct ContractDefnSection
    {
        /**
         * Display name of Contract Definition Section.
         */
        std::string displayName;
        /**
         * A list of object types and quantities that must be displayed in a section.
         */
        std::vector< Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::ObjectInfo > objectInfos;
        /**
         * Teamcenter object properties that must be displayed in a section. These properties
         * are common to all the objects in the section.
         */
        std::vector< std::string > propertyNames;
        /**
         * Teamcenter object property's display name.
         */
        std::vector< std::string > propertyDisplayNames;
    };

    /**
     * This structure contains information required to get the objects added to the validation
     * contract (<b>Crt0VldnContractRevision</b>).
     */
    struct GetObjectsAddForValidationInput
    {
        /**
         * This unique ID is used to identify return data elements and partial errors associated
         * with this input structure.
         */
        std::string clientId;
        /**
         * The validaton contract object to which objects have been added previously.
         */
        Teamcenter::Soa::Client::Model::Crt0VldnContractRevision* contractRevision;
        /**
         * The "Crt0ValidationLink" type that was used to add objects to the validation contract.
         */
        std::string tracelinkType;
    };

    /**
     * This structure contains information required to get the result objects that were
     * previously added to the validation contract (<b>Crt0VldnContractRevision</b>).
     */
    struct GetResultsOfValidationInput
    {
        /**
         * This unique ID is used to identify return data elements and partial errors associated
         * with this input structure.
         */
        std::string clientId;
        /**
         * The validaton contract object to which result objects have been previously added.
         */
        Teamcenter::Soa::Client::Model::Crt0VldnContractRevision* contractRevision;
        /**
         * The "<b>Crt0ValidationLink</b>" type that was used to add objects to the validation
         * contract.
         */
        std::string tracelinkType;
    };

    /**
     * This structure contains information about result objects that were previously added
     * to Validation Contracts.
     */
    struct GetValidationResultsResponse
    {
        /**
         * A list of ValidationResultsRespData that contains details about result objects that
         * were previously added to Validation Contracts.
         */
        std::vector< Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::ValidationResultsRespData > output;
        /**
         * Service Data.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * This structure contains detailed information about each input Validation Contract.
     */
    struct ObjectAddedForValidationRespData
    {
        /**
         * Information about objects that are added to the Validation Contract (<b>Crt0VldnContractRevision</b>).
         */
        std::vector< Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::AddedObjectInfo > addedToVCInfo;
        /**
         * ContractDefnOutput corresponding to the "view" group in the contract definition (<b>Crt0VCDefnRevision</b>).
         * "view" is group in the contract package file that is attached to the contract defintion
         * (<b>Crt0VCDefnRevision</b>). The contract definition (<b>Crt0VCDefnRevision</b>)
         * is required for creation of a validation contract (<b>Crt0VCDefnRevision</b>).
         */
        Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::ContractDefnOutput contractDefnInfo;
    };

    /**
     * This structure contains information of the object types and their quantities that
     * are expected to appear in a section.
     */
    struct ObjectInfo
    {
        /**
         * Teamcenter Business object type.
         */
        std::string type;
        /**
         * Number of objects of a given type. Allowed values are:
         * <br>
         * a. "0" (Zero)
         * <br>
         * <br>
         * b. Any positive number
         * <br>
         * Example: Value of 1 allows only one object of the given type in the section.
         * <br>
         * <br>
         * c. "*". Value of * allows any number of objects of the given type in the section.
         */
        std::string quantity;
    };

    /**
     * This structure contains information about objects added to Validation Contracts in
     * the output and errors in service data.
     */
    struct ObjectsAddForValidationResponse
    {
        /**
         * A list of ObjectsAddedForValidationRespData that contains details about objects added
         * to Validation Contracts.
         */
        std::vector< Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::ObjectAddedForValidationRespData > output;
        /**
         * Service data.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * This structure contains detailed information of the objects that are added to the
     * Validation Contract.
     */
    struct ResultObjectInfo
    {
        /**
         * Result object that is added to the Validation Contract (<b>Crt0VldnContractRevision</b>).
         */
        Teamcenter::Soa::Client::Model::WorkspaceObject* resultObj;
        /**
         * The trace link between the result object and the validation contract (<b>Crt0VldnContractRevision</b>).
         */
        Teamcenter::Soa::Client::Model::Crt0ValidationLink* vcLink;
    };

    /**
     * This structure contains detailed information about result objects added to each input
     * Validation Contract.
     */
    struct ValidationResultsRespData
    {
        /**
         * Information about result objects that were previously added to the Validation Contract
         * (<b>Crt0VldnContractRevision</b>).
         */
        std::vector< Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::ResultObjectInfo > resultObjInfo;
        /**
         * ContractDefnOutput corresponding to the "results" group in the contract definition
         * (<b>Crt0VCDefnRevision</b>). "results" is the group in the contract package file
         * that is attached to the contract definition (<b>Crt0VCDefnRevision</b>). The contract
         * definition (<b>Crt0VCDefnRevision</b>) is required for creation of a validation contract
         * (<b>Crt0VldnContractRevision</b>).
         */
        Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::ContractDefnOutput contractDefnInfo;
    };




    /**
     * Objects that need to be validated must be added to Validation Contracts. This operation
     * adds specified objects that need to be validated to the Valiation Contract. It does
     * this by creating tracelinks of the specified type between the Validation Contract
     * Revision and the specified Components to be validated.
     * <br>
     * Tracelink creation rules are mentioned below:
     * <br>
     * <br>
     * 1.&nbsp;&nbsp;&nbsp;&nbsp;If a Component (<b>Awb0Element</b>) and the Context are
     * specified, in-context tracelink is created.
     * <br>
     * 2.&nbsp;&nbsp;&nbsp;&nbsp;If a Component (<b>Awb0Element</b>) is specified but the
     * Context is not specified, the Item Revision corresponding to the Component is used
     * to created the tracelink.
     * <br>
     * <br>
     * The objects will be added to sections specified in the "view" group. The sections
     * in the "view" group are specified in the Contract Definition that is attached to
     * the Validation Contract.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * Use case 1: Add a Component in a Product for validation from the Validation Contract's
     * Domain. The Component can be at any level in the Product.
     * <br>
     * An in-context tracelink is created between the Component (<b>Awb0Element</b>) and
     * the Validation Contract. The Product is the context in which the tracelink is created.
     * <br>
     * <br>
     * Use case 2: Add a Product for validation from the Validation Contract's Domain
     * <br>
     * A  tracelink is created between the Product's Item Revision and the Validation Contract.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace Validation Contract - This is a component for Active Workspace Validation
     * Contract.
     *
     * @param input
     *        This structure contains all information required to add objects to Validation Contract.
     *
     * @return
     *         The following partial errors may be returned in the ServiceData:
     *         <br>
     *         35003: If the input Trace Link type is invalid.
     *         <br>
     *         35006: If the input Validation Contract is invalid.
     *         <br>
     *         35007: If the input object to the added to the Validaiton Contract is invalid.
     *         <br>
     *         184007: If the object cannot be added to the Analysis Request, because the specified
     *         Trace Link type is not (Crt0ValidationLink).
     *         <br>
     *         184008: If the object cannot be added to the Analysis Request, because the section
     *         name is empty.
     *         <br>
     *         184009: If the object cannot be added to the Analysis Request, because the component
     *         and the context are the same.
     *         <br>
     *         184010: If the object cannot be added to the Analysis Request, because the context
     *         of the component does not belong to the Analysis Request's domain.
     *         <br>
     *         184011: If the object cannot be added to the Analysis Request, because it exceeds
     *         the quantity of allowed objects for the specified section. The quantity of objects
     *         allowed for the section is specified in the Analysis definition.
     *         <br>
     *         184012: If the object cannot be added to the Analysis Request, because the specified
     *         section does not exist in the Analysis definition.
     *         <br>
     *         184015: If the object cannot be added to the Analysis Request, because it is already
     *         added to it.
     *         <br>
     *         184016: If the object cannot be added to the Analysis Request, because the current
     *         user does not have write privileges to the Analysis Request.
     *         <br>
     *         184017: If the object cannot be added to the Analysis Request, because the Analysis
     *         Request is released.
     *         <br>
     *         184018: If the object cannot be added to the Analysis Request, because the Analysis
     *         Request is checked out by another user.
     *
     */
    virtual Teamcenter::Soa::Client::ServiceData addObjectsForValidation ( const std::vector< Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::AddObjsForValidationInput >& input ) = 0;

    /**
     * After a validation activity, results need to be added to Validation Contracts. This
     * operation adds the specified result objects to the Validation Contract. Tracelinks
     * are created for the specified type between the <b>Crt0VldnContractRevision</b> and
     * the specified result objects.
     * <br>
     * The result objects will be added to sections specified in the "results" group. The
     * sections in the "results" group are specified in the contract definition revision
     * (<b>Crt0VCDefnRevision</b>) that is attached to the validation contract revision
     * (<b>Crt0VldnContractRevision</b>).
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace Validation Contract - This is a component for Active Workspace Validation
     * Contract.
     *
     * @param input
     *        Information of result objects to be added to Validation Contract
     *
     * @return
     *         The following partial errors may be returned:
     *         <br>
     *         184001: If the The object cannot be added to the Analysis Request, because the Analysis
     *         Request's definition does not have the input section.
     *         <br>
     *         184002: If the object cannot be added to the Analysis Request, because the Analysis
     *         Request's definition does not have a section for the object type.
     *         <br>
     *         184007: If the object cannot be added to the Analysis Request, because the specified
     *         Trace Link type is not Crt0ValidationLink.
     *         <br>
     *         184014: If the object cannot be added to the Analysis Request, because the input
     *         section defined in the Analysis Request's definition does not accept object type.
     *         <br>
     *         184015: If the object cannot be added to the Analysis Request, because it is already
     *         added to it.
     *         <br>
     *         184016: If the object cannot be added to the Analysis Request, because the current
     *         user does not have write privileges to the Analysis Request.
     *         <br>
     *         184017: If the object cannot be added to the Analysis Request, because the Analysis
     *         Request is released.
     *         <br>
     *         184018: If the object cannot be added to the Analysis Request, because the Analysis
     *         Request is checked out by another user.
     *
     */
    virtual Teamcenter::Soa::Client::ServiceData addValidationResults ( const std::vector< Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::AddResultsOfValidationInput >& input ) = 0;

    /**
     * This operation retrieves the information about objects added to Validation Contract
     * (<b>Crt0VldnContractRevision</b>) for validation activity. The below details are
     * retrieved.
     * <br>
     * <br>
     * 1.&nbsp;&nbsp;&nbsp;&nbsp;Objects added to Validation Contract (<b>Crt0VldnContractRevision</b>)
     * for validation activity.
     * <br>
     * 2.&nbsp;&nbsp;&nbsp;&nbsp;Complete information of the "view" group as specified in
     * the Contract definition (<b>Crt0VCDefnRevision</b>) that is attached to the Validation
     * Contract (<b>Crt0VldnContractRevision</b>).
     * <br>
     * 3.&nbsp;&nbsp;&nbsp;&nbsp;<b>Crt0ValidationLink</b> tracelinks that were created
     * when objects were added to the Validation Contract (<b>Crt0VldnContractRevision</b>).
     * <br>
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace Validation Contract - This is a component for Active Workspace Validation
     * Contract.
     *
     * @param input
     *        Validation Contracts (<b>Crt0VldnContractRevision</b>) whose information must be
     *        retreived.
     *
     * @return
     *         Information about the objects added to validation contracts, the sections where the
     *         objects have been added and the tracelinks are returned.
     *         <br>
     *         <br>
     *         The following partial errors may be returned:
     *         <br>
     *         184013: If the Analysis definition details cannot be retrieved, because no definition
     *         is attached to the Analysis Request.
     *
     */
    virtual Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::ObjectsAddForValidationResponse getObjectsAddedForValidation ( const std::vector< Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::GetObjectsAddForValidationInput >& input ) = 0;

    /**
     * This operation retrieves the information about result objects added to Validation
     * Contract (<b>Crt0VldnContractRevision</b>). The below details are retrieved.
     * <br>
     * <ul>
     * <li type="disc">Result objects that were added to Validation Contract (<b>Crt0VldnContractRevision</b>).
     * The result objects are generally added after a validation activity.
     * </li>
     * <li type="disc">Complete information of the "results" group as specified in the Contract
     * definition (<b>Crt0VCDefnRevision</b>) that is attached to the Validation Contract
     * (<b>Crt0VldnContractRevision</b>).
     * </li>
     * <li type="disc"><b>Crt0ValidationLink</b> tracelinks that were created when the result
     * objects were added to the Validation Contract (<b>Crt0VldnContractRevision</b>).
     * </li>
     * </ul>
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace Validation Contract - This is a component for Active Workspace Validation
     * Contract.
     *
     * @param input
     *        Validation Contracts (Crt0VldnContractRevision)whose information must be retreived.
     *
     * @return
     *         Information about the result objects that were previously added to validation contracts,
     *         the sections where the objects have been added and the tracelinks are returned.
     *         <br>
     *         <br>
     *         The following partial errors may be returned:
     *         <br>
     *         184013: If the Analysis definition details cannot be retrieved, because no definition
     *         is attached to the Analysis Request.
     *
     */
    virtual Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::GetValidationResultsResponse getValidationResults ( const std::vector< Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::GetResultsOfValidationInput >& input ) = 0;


protected:
    virtual ~Vcmanagement() {}
};
            }
        }
    }
}

#include <crt1/services/validationcontractaw/ValidationContractAW_undef.h>
#endif

