/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWP0NUMERICSEARCHFILTER_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWP0NUMERICSEARCHFILTER_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/POM_object.hxx>

#include <teamcenter/soa/client/model/Aws2_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAAWS2MODEL_API Awp0NumericSearchFilter : public Teamcenter::Soa::Client::Model::POM_object
{
public:
    const std::string& get_awp0filter_name();
    double get_awp0start_value();
    double get_awp0end_value();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awp0NumericSearchFilter")

   virtual ~Awp0NumericSearchFilter();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Aws2_undef.h>
#endif
