/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWB0SAVEDBOOKMARK_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWB0SAVEDBOOKMARK_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/WorkspaceObject.hxx>

#include <teamcenter/soa/client/model/Activeworkspacebom_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {
                class Awb0BookmarkProductData;


class TCSOAACTIVEWORKSPACEBOMMODEL_API Awb0SavedBookmark : public Teamcenter::Soa::Client::Model::WorkspaceObject
{
public:
    const std::string& get_awb0ActiveSublocation();
    Awb0BookmarkProductData* get_awb0ActiveProduct();
    const std::string& get_awb0ShareLevel();
    const Teamcenter::Soa::Client::ModelObjectVector& get_awb0SelectedElementPath();
    bool get_awb0PendingChanges();
    bool get_awb0IsStructModifiable();
    const Teamcenter::Soa::Client::ModelObjectVector& get_IMAN_specification();
    const Teamcenter::Soa::Client::ModelObjectVector& get_IMAN_reference();
    bool get_awb0AllowReadShare();
    bool get_awb0AllowWriteShare();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awb0SavedBookmark")

   virtual ~Awb0SavedBookmark();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Activeworkspacebom_undef.h>
#endif
