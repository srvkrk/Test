/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_ARM0REQUIREMENTELEMENT_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_ARM0REQUIREMENTELEMENT_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Awb0ConditionalElement.hxx>

#include <teamcenter/soa/client/model/Arm0activeworkspacereqmgmt_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAARM0ACTIVEWORKSPACEREQMGMTMODEL_API Arm0RequirementElement : public Teamcenter::Soa::Client::Model::Awb0ConditionalElement
{
public:
    const std::string& get_arm0Number();
    const std::string& get_arm0ClearText();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Arm0RequirementElement")

   virtual ~Arm0RequirementElement();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Arm0activeworkspacereqmgmt_undef.h>
#endif
