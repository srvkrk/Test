/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_S2CLSOCIALSUMMARY_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_S2CLSOCIALSUMMARY_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/POM_object.hxx>

#include <teamcenter/soa/client/model/S2clsocial_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {
                class POM_user;
                class S2clTag;


class TCSOAS2CLSOCIALMODEL_API S2clSocialSummary : public Teamcenter::Soa::Client::Model::POM_object
{
public:
    Teamcenter::Soa::Client::ModelObject* get_s2clSummaryForObject();
    int get_s2clTotalComments();
    int get_s2clTotalQuestions();
    int get_s2clTotalAnswered();
    int get_s2clTotalRatings();
    int get_s2clTotal5Star();
    int get_s2clTotal4Star();
    int get_s2clTotal3Star();
    int get_s2clTotal2Star();
    int get_s2clTotal1Star();
    int get_s2clTotalLikes();
    int get_s2clTotalFollows();
    double get_s2clAverageRating();
    int get_s2clTotalExperiences();
    size_t count_s2clSubscribers();
    POM_user* get_s2clSubscribers_at( size_t inx );
    const Teamcenter::Soa::Client::ModelObjectVector& get_s2clSubscriptions();
    const Teamcenter::Soa::Client::ModelObjectVector& get_s2clSendToList();
    const Teamcenter::Soa::Client::StringVector& get_s2clNotificationPreferences();
    size_t count_s2clTags();
    S2clTag* get_s2clTags_at( size_t inx );


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("S2clSocialSummary")

   virtual ~S2clSocialSummary();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/S2clsocial_undef.h>
#endif
