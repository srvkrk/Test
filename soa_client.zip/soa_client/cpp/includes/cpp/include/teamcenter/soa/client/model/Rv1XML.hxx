/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_RV1XML_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_RV1XML_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Dataset.hxx>

#include <teamcenter/soa/client/model/Relationshipviewer_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOARELATIONSHIPVIEWERMODEL_API Rv1XML : public Teamcenter::Soa::Client::Model::Dataset
{
public:


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Rv1XML")

   virtual ~Rv1XML();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Relationshipviewer_undef.h>
#endif
