/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_EWI0STEPEXECUTIONINFO_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_EWI0STEPEXECUTIONINFO_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Ewi0BaseExecutionInfo.hxx>

#include <teamcenter/soa/client/model/Ewi0electronicwi_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAEWI0ELECTRONICWIMODEL_API Ewi0StepExecutionInfo : public Teamcenter::Soa::Client::Model::Ewi0BaseExecutionInfo
{
public:
    const std::string& get_ewi0ExecutionStatus();
    int get_ewi0ExecutionPercentage();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Ewi0StepExecutionInfo")

   virtual ~Ewi0StepExecutionInfo();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Ewi0electronicwi_undef.h>
#endif
