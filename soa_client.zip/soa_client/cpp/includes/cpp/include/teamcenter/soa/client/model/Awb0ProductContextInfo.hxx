/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWB0PRODUCTCONTEXTINFO_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWB0PRODUCTCONTEXTINFO_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/RuntimeBusinessObject.hxx>

#include <teamcenter/soa/client/model/Activeworkspacebom_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAACTIVEWORKSPACEBOMMODEL_API Awb0ProductContextInfo : public Teamcenter::Soa::Client::Model::RuntimeBusinessObject
{
public:
    Teamcenter::Soa::Client::ModelObject* get_awb0Product();
    Teamcenter::Soa::Client::ModelObject* get_awb0CurrentRevRule();
    const Teamcenter::Soa::Client::ModelObjectVector& get_awb0SupportedFeatures();
    const Teamcenter::Soa::Common::DateTime& get_awb0EffDate();
    int get_awb0EffUnitNo();
    Teamcenter::Soa::Client::ModelObject* get_awb0EffEndItem();
    Teamcenter::Soa::Client::ModelObject* get_awb0AutoBookmark();
    Teamcenter::Soa::Client::ModelObject* get_awb0CurrentVariantRule();
    Teamcenter::Soa::Client::ModelObject* get_awb0VariantRuleOwningRev();
    Teamcenter::Soa::Client::ModelObject* get_awb0ContextObject();
    const std::string& get_awb0ClientScopeUri();
    const Teamcenter::Soa::Common::DateTime& get_awb0IndexUpdateDate();
    Teamcenter::Soa::Client::ModelObject* get_awb0ClosureRule();
    bool get_awb0UseGlobalRevisionRule();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awb0ProductContextInfo")

   virtual ~Awb0ProductContextInfo();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Activeworkspacebom_undef.h>
#endif
