/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_FND0SELECTION_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_FND0SELECTION_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/RuntimeBusinessObject.hxx>

#include <teamcenter/soa/client/model/Aws2_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAAWS2MODEL_API Fnd0Selection : public Teamcenter::Soa::Client::Model::RuntimeBusinessObject
{
public:
    const Teamcenter::Soa::Client::ModelObjectVector& get_fnd0SelectedObjects();
    Teamcenter::Soa::Client::ModelObject* get_fnd0ParentSelection();
    const std::string& get_fnd0ContextName();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Fnd0Selection")

   virtual ~Fnd0Selection();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Aws2_undef.h>
#endif
