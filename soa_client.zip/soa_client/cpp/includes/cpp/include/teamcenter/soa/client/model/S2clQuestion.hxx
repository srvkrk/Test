/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_S2CLQUESTION_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_S2CLQUESTION_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/S2clCommentary.hxx>

#include <teamcenter/soa/client/model/S2clsocial_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {
                class S2clAnswer;


class TCSOAS2CLSOCIALMODEL_API S2clQuestion : public Teamcenter::Soa::Client::Model::S2clCommentary
{
public:
    S2clAnswer* get_s2clBestAnswer();
    bool get_s2clIsOpen();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("S2clQuestion")

   virtual ~S2clQuestion();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/S2clsocial_undef.h>
#endif
