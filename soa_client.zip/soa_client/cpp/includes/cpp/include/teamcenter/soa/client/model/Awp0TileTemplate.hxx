/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWP0TILETEMPLATE_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWP0TILETEMPLATE_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/WorkspaceObject.hxx>

#include <teamcenter/soa/client/model/Aws2_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAAWS2MODEL_API Awp0TileTemplate : public Teamcenter::Soa::Client::Model::WorkspaceObject
{
public:
    const std::string& get_awp0TemplateId();
    int get_awp0ThemeIndex();
    const std::string& get_awp0Icon();
    const std::string& get_awp0Action();
    const Teamcenter::Soa::Client::IntVector& get_awp0Sizes();
    const Teamcenter::Soa::Client::StringVector& get_awp0ContentNames();
    Teamcenter::Soa::Client::ModelObject* get_awp0IconSource();
    int get_awp0ActionType();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awp0TileTemplate")

   virtual ~Awp0TileTemplate();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Aws2_undef.h>
#endif
