/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_SMR1SEARCHPROVIDER_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_SMR1SEARCHPROVIDER_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Fnd0BaseProvider.hxx>

#include <teamcenter/soa/client/model/Smr1mrocoreaw_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOASMR1MROCOREAWMODEL_API Smr1SearchProvider : public Teamcenter::Soa::Client::Model::Fnd0BaseProvider
{
public:


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Smr1SearchProvider")

   virtual ~Smr1SearchProvider();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Smr1mrocoreaw_undef.h>
#endif
