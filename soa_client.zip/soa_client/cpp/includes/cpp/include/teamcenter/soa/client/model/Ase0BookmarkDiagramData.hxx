/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_ASE0BOOKMARKDIAGRAMDATA_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_ASE0BOOKMARKDIAGRAMDATA_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Awb0BookmarkData.hxx>

#include <teamcenter/soa/client/model/Ase0activeworkspacesyseng_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAASE0ACTIVEWORKSPACESYSENGMODEL_API Ase0BookmarkDiagramData : public Teamcenter::Soa::Client::Model::Awb0BookmarkData
{
public:
    const std::string& get_ase0DiagramContent();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Ase0BookmarkDiagramData")

   virtual ~Ase0BookmarkDiagramData();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Ase0activeworkspacesyseng_undef.h>
#endif
