/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_RET1GROUPINGELEMENT_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_RET1GROUPINGELEMENT_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Ret1CostingElement.hxx>

#include <teamcenter/soa/client/model/Ret1retailaw_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOARET1RETAILAWMODEL_API Ret1GroupingElement : public Teamcenter::Soa::Client::Model::Ret1CostingElement
{
public:


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Ret1GroupingElement")

   virtual ~Ret1GroupingElement();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Ret1retailaw_undef.h>
#endif
