/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_S2CLTAG_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_S2CLTAG_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/POM_object.hxx>

#include <teamcenter/soa/client/model/S2clsocial_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {
                class POM_user;


class TCSOAS2CLSOCIALMODEL_API S2clTag : public Teamcenter::Soa::Client::Model::POM_object
{
public:
    const std::string& get_s2clTagName();
    bool get_s2clIsBlackListed();
    bool get_s2clIsWhiteListed();
    size_t count_s2clSubscribersFromSummary();
    POM_user* get_s2clSubscribersFromSummary_at( size_t inx );


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("S2clTag")

   virtual ~S2clTag();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/S2clsocial_undef.h>
#endif
