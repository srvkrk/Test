/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_S2CLCOMMENTARY_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_S2CLCOMMENTARY_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/WorkspaceObject.hxx>

#include <teamcenter/soa/client/model/S2clsocial_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {
                class WorkspaceObject;
                class WorkspaceObject;
                class WorkspaceObject;


class TCSOAS2CLSOCIALMODEL_API S2clCommentary : public Teamcenter::Soa::Client::Model::WorkspaceObject
{
public:
    WorkspaceObject* get_s2clTargetObject();
    S2clCommentary* get_s2clParentRootComment();
    int get_s2clRatingValue();
    const std::string& get_s2clCommentPlainText();
    WorkspaceObject* get_s2clForumObject();
    const std::string& get_s2clCommentRichText();
    size_t count_s2clContextObjects();
    WorkspaceObject* get_s2clContextObjects_at( size_t inx );
    const Teamcenter::Soa::Client::StringVector& get_s2clCellProperties();
    const Teamcenter::Soa::Client::ModelObjectVector& get_s2clDatasets();
    const std::string& get_s2clTargetObjectName();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("S2clCommentary")

   virtual ~S2clCommentary();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/S2clsocial_undef.h>
#endif
