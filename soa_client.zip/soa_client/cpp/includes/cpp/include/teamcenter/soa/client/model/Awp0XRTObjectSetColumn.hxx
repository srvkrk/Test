/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWP0XRTOBJECTSETCOLUMN_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWP0XRTOBJECTSETCOLUMN_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/RuntimeBusinessObject.hxx>

#include <teamcenter/soa/client/model/Aws2_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAAWS2MODEL_API Awp0XRTObjectSetColumn : public Teamcenter::Soa::Client::Model::RuntimeBusinessObject
{
public:
    const std::string& get_awp0PropertyName();
    const std::string& get_awp0PropertyDisplayName();
    bool get_awp0IsPropertyOnRelation();
    const std::string& get_awp0DataType();
    int get_awp0Length();
    bool get_awp0IsArray();
    int get_awp0ArrayLength();
    bool get_awp0UserSortable();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awp0XRTObjectSetColumn")

   virtual ~Awp0XRTObjectSetColumn();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Aws2_undef.h>
#endif
