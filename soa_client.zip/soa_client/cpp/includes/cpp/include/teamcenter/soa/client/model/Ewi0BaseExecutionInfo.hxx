/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_EWI0BASEEXECUTIONINFO_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_EWI0BASEEXECUTIONINFO_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/WorkspaceObject.hxx>

#include <teamcenter/soa/client/model/Ewi0electronicwi_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAEWI0ELECTRONICWIMODEL_API Ewi0BaseExecutionInfo : public Teamcenter::Soa::Client::Model::WorkspaceObject
{
public:
    const std::string& get_ewi0ExecutionComment();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Ewi0BaseExecutionInfo")

   virtual ~Ewi0BaseExecutionInfo();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Ewi0electronicwi_undef.h>
#endif
