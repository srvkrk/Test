/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_EWI0ATTACHMENTEXECUTIONINFO_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_EWI0ATTACHMENTEXECUTIONINFO_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Ewi0BaseExecutionInfo.hxx>

#include <teamcenter/soa/client/model/Ewi0electronicwi_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {
                class Dataset;


class TCSOAEWI0ELECTRONICWIMODEL_API Ewi0AttachmentExecutionInfo : public Teamcenter::Soa::Client::Model::Ewi0BaseExecutionInfo
{
public:
    size_t count_ewi0executionAttachment();
    Dataset* get_ewi0executionAttachment_at( size_t inx );


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Ewi0AttachmentExecutionInfo")

   virtual ~Ewi0AttachmentExecutionInfo();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Ewi0electronicwi_undef.h>
#endif
