/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_SMR1PHYSICALINSTANCE_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_SMR1PHYSICALINSTANCE_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Awb0PositionedElement.hxx>

#include <teamcenter/soa/client/model/Smr1mrocoreaw_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOASMR1MROCOREAWMODEL_API Smr1PhysicalInstance : public Teamcenter::Soa::Client::Model::Awb0PositionedElement
{
public:
    const std::string& get_smr1InstallationTime();
    bool get_smr1IsLot();
    bool get_smr1IsSerialized();
    const std::string& get_smr1LotNumber();
    Teamcenter::Soa::Client::ModelObject* get_smr1LotTag();
    const std::string& get_smr1MfgDate();
    const std::string& get_smr1MfgOrgId();
    const std::string& get_smr1PartNumber();
    const std::string& get_smr1PartUsage();
    const std::string& get_smr1PartUsed();
    const std::string& get_smr1PartUsedInternal();
    const std::string& get_smr1PhysicalUid();
    const std::string& get_smr1SerialNumber();
    const std::string& get_smr1Location();
    Teamcenter::Soa::Client::ModelObject* get_smr1AuthorizingDeviation();
    const Teamcenter::Soa::Common::DateTime& get_smr1PartInstallTime();
    const Teamcenter::Soa::Common::DateTime& get_smr1PartMfgDate();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Smr1PhysicalInstance")

   virtual ~Smr1PhysicalInstance();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Smr1mrocoreaw_undef.h>
#endif
