/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWV0BOMINDEXPSPROVIDER_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWV0BOMINDEXPSPROVIDER_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Awv0ProductStructureProvider.hxx>

#include <teamcenter/soa/client/model/Awv0activeworkspacevis_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAAWV0ACTIVEWORKSPACEVISMODEL_API Awv0BOMIndexPSProvider : public Teamcenter::Soa::Client::Model::Awv0ProductStructureProvider
{
public:


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awv0BOMIndexPSProvider")

   virtual ~Awv0BOMIndexPSProvider();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Awv0activeworkspacevis_undef.h>
#endif
