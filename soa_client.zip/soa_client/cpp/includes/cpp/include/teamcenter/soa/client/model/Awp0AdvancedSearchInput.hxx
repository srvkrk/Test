/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWP0ADVANCEDSEARCHINPUT_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWP0ADVANCEDSEARCHINPUT_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/RuntimeBusinessObject.hxx>

#include <teamcenter/soa/client/model/Aws2_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAAWS2MODEL_API Awp0AdvancedSearchInput : public Teamcenter::Soa::Client::Model::RuntimeBusinessObject
{
public:
    Teamcenter::Soa::Client::ModelObject* get_awp0AdvancedQueryName();
    Teamcenter::Soa::Client::ModelObject* get_awp0QuickSearchName();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awp0AdvancedSearchInput")

   virtual ~Awp0AdvancedSearchInput();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Aws2_undef.h>
#endif
