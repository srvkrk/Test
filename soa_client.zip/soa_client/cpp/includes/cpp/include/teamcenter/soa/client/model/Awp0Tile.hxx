/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWP0TILE_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWP0TILE_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/WorkspaceObject.hxx>

#include <teamcenter/soa/client/model/Aws2_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {
                class Awp0TileTemplate;


class TCSOAAWS2MODEL_API Awp0Tile : public Teamcenter::Soa::Client::Model::WorkspaceObject
{
public:
    const std::string& get_awp0TileId();
    const std::string& get_awp0Style();
    Awp0TileTemplate* get_awp0TileTemplate();
    const std::string& get_awp0DisplayName();
    const std::string& get_awp0Params();
    const std::string& get_awp0ObjectRefStr();
    const Teamcenter::Soa::Client::StringVector& get_awp0ContentValues();
    const Teamcenter::Soa::Client::StringVector& get_awp0Messages();
    Teamcenter::Soa::Client::ModelObject* get_awp0ObjectRef();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awp0Tile")

   virtual ~Awp0Tile();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Aws2_undef.h>
#endif
