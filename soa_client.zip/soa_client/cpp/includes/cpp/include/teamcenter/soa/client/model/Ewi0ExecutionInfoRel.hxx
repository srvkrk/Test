/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_EWI0EXECUTIONINFOREL_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_EWI0EXECUTIONINFOREL_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/ImanRelation.hxx>

#include <teamcenter/soa/client/model/Ewi0electronicwi_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {
                class MECollaborationContext;
                class POM_application_object;


class TCSOAEWI0ELECTRONICWIMODEL_API Ewi0ExecutionInfoRel : public Teamcenter::Soa::Client::Model::ImanRelation
{
public:
    MECollaborationContext* get_ewi0refCC();
    POM_application_object* get_ewi0creation_user();
    const Teamcenter::Soa::Common::DateTime& get_ewi0creation_date();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Ewi0ExecutionInfoRel")

   virtual ~Ewi0ExecutionInfoRel();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Ewi0electronicwi_undef.h>
#endif
