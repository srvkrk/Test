/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWB0VIEWERFEATURE_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWB0VIEWERFEATURE_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Awb0ProductFeature.hxx>

#include <teamcenter/soa/client/model/Activeworkspacebom_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAACTIVEWORKSPACEBOMMODEL_API Awb0ViewerFeature : public Teamcenter::Soa::Client::Model::Awb0ProductFeature
{
public:


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awb0ViewerFeature")

   virtual ~Awb0ViewerFeature();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Activeworkspacebom_undef.h>
#endif
