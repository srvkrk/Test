/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_SCW0COMPLIANCEINFO_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_SCW0COMPLIANCEINFO_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/RuntimeBusinessObject.hxx>

#include <teamcenter/soa/client/model/Scw0subscmplaw_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOASCW0SUBSCMPLAWMODEL_API Scw0ComplianceInfo : public Teamcenter::Soa::Client::Model::RuntimeBusinessObject
{
public:
    Teamcenter::Soa::Client::ModelObject* get_scw0CmplResult();
    Teamcenter::Soa::Client::ModelObject* get_scw0Exemption();
    const Teamcenter::Soa::Common::DateTime& get_scw0DateCalculated();
    const Teamcenter::Soa::Common::DateTime& get_scw0ExemptionExpires();
    const std::string& get_scw0FailureReason();
    Teamcenter::Soa::Client::ModelObject* get_scw0Regulation();
    const std::string& get_scw0Status();
    const std::string& get_scw0Threshold();
    const std::string& get_scw0AppliedExemption();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Scw0ComplianceInfo")

   virtual ~Scw0ComplianceInfo();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Scw0subscmplaw_undef.h>
#endif
