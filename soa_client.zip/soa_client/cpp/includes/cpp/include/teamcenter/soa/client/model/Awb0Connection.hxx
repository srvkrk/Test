/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWB0CONNECTION_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWB0CONNECTION_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Awb0ConditionalElement.hxx>

#include <teamcenter/soa/client/model/Activeworkspacebom_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAACTIVEWORKSPACEBOMMODEL_API Awb0Connection : public Teamcenter::Soa::Client::Model::Awb0ConditionalElement
{
public:
    Teamcenter::Soa::Client::ModelObject* get_awb0End1();
    Teamcenter::Soa::Client::ModelObject* get_awb0End2();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awb0Connection")

   virtual ~Awb0Connection();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Activeworkspacebom_undef.h>
#endif
