/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_S2CLENVELOPE_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_S2CLENVELOPE_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Envelope.hxx>

#include <teamcenter/soa/client/model/S2clsocial_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAS2CLSOCIALMODEL_API S2clEnvelope : public Teamcenter::Soa::Client::Model::Envelope
{
public:
    const Teamcenter::Soa::Client::ModelObjectVector& get_s2clAttachments();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("S2clEnvelope")

   virtual ~S2clEnvelope();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/S2clsocial_undef.h>
#endif
