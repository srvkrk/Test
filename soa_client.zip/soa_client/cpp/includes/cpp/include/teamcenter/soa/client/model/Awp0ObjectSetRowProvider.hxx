/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWP0OBJECTSETROWPROVIDER_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWP0OBJECTSETROWPROVIDER_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Fnd0BaseProvider.hxx>

#include <teamcenter/soa/client/model/Aws2_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAAWS2MODEL_API Awp0ObjectSetRowProvider : public Teamcenter::Soa::Client::Model::Fnd0BaseProvider
{
public:


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awp0ObjectSetRowProvider")

   virtual ~Awp0ObjectSetRowProvider();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Aws2_undef.h>
#endif
