/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_S2CLNOTIFICATION_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_S2CLNOTIFICATION_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/POM_object.hxx>

#include <teamcenter/soa/client/model/S2clsocial_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAS2CLSOCIALMODEL_API S2clNotification : public Teamcenter::Soa::Client::Model::POM_object
{
public:
    const std::string& get_s2clActionName();
    const std::string& get_s2clActionDescription();
    Teamcenter::Soa::Client::ModelObject* get_s2clTargetObject();
    const Teamcenter::Soa::Client::ModelObjectVector& get_s2clModifiedObjects();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("S2clNotification")

   virtual ~S2clNotification();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/S2clsocial_undef.h>
#endif
