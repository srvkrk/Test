/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWP0FULLTEXTSAVEDSEARCH_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWP0FULLTEXTSAVEDSEARCH_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/WorkspaceObject.hxx>

#include <teamcenter/soa/client/model/Aws2_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {
                class Awp0DateSearchFilter;
                class Awp0NumericSearchFilter;
                class Awp0StringSearchFilter;


class TCSOAAWS2MODEL_API Awp0FullTextSavedSearch : public Teamcenter::Soa::Client::Model::WorkspaceObject
{
public:
    const std::string& get_awp0search_string();
    bool get_awp0is_global_shared();
    size_t count_awp0date_filters();
    Awp0DateSearchFilter* get_awp0date_filters_at( size_t inx );
    size_t count_awp0numeric_filters();
    Awp0NumericSearchFilter* get_awp0numeric_filters_at( size_t inx );
    size_t count_awp0string_filters();
    Awp0StringSearchFilter* get_awp0string_filters_at( size_t inx );


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awp0FullTextSavedSearch")

   virtual ~Awp0FullTextSavedSearch();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Aws2_undef.h>
#endif
