/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWB0BOOKMARKPRODUCTDATA_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWB0BOOKMARKPRODUCTDATA_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Awb0BookmarkData.hxx>

#include <teamcenter/soa/client/model/Activeworkspacebom_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAACTIVEWORKSPACEBOMMODEL_API Awb0BookmarkProductData : public Teamcenter::Soa::Client::Model::Awb0BookmarkData
{
public:
    Teamcenter::Soa::Client::ModelObject* get_awb0Product();
    Teamcenter::Soa::Client::ModelObject* get_awb0RevisionRule();
    const Teamcenter::Soa::Common::DateTime& get_awb0EffectiveDate();
    Teamcenter::Soa::Client::ModelObject* get_awb0EndItem();
    const std::string& get_awb0OpenedOccurrence();
    const std::string& get_awb0SelectedOccurrence();
    int get_awb0EffectiveUnitNumber();
    bool get_awb0EffectiveNow();
    const Teamcenter::Soa::Client::ModelObjectVector& get_awb0SavedVariantRules();
    const Teamcenter::Soa::Client::ModelObjectVector& get_awb0VariantOwningItemRevs();
    bool get_awb0GlobalRevRuleBookmarked();
    Teamcenter::Soa::Client::ModelObject* get_awb0SelectedOccurrenceObj();
    Teamcenter::Soa::Client::ModelObject* get_awb0OpenedOccurrenceObject();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awb0BookmarkProductData")

   virtual ~Awb0BookmarkProductData();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Activeworkspacebom_undef.h>
#endif
