/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWB0BOMINDEXADMINDATA_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWB0BOMINDEXADMINDATA_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/POM_object.hxx>

#include <teamcenter/soa/client/model/Activeworkspacebom_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {
                class ItemRevision;
                class ClosureRule;


class TCSOAACTIVEWORKSPACEBOMMODEL_API Awb0BOMIndexAdminData : public Teamcenter::Soa::Client::Model::POM_object
{
public:
    const Teamcenter::Soa::Common::DateTimeVector& get_awb0EffDateVec();
    int get_awb0OccurrenceCount();
    const Teamcenter::Soa::Common::DateTime& get_awb0LastAccessDate();
    const Teamcenter::Soa::Client::IntVector& get_awb0EffUnitNoVec();
    const std::string& get_awb0WindowUid();
    const Teamcenter::Soa::Common::DateTime& get_awb0LastUpdateDate();
    int get_awb0IndexState();
    size_t count_awb0VariantRuleOwningRevs();
    ItemRevision* get_awb0VariantRuleOwningRevs_at( size_t inx );
    Teamcenter::Soa::Client::ModelObject* get_awb0Product();
    Teamcenter::Soa::Client::ModelObject* get_awb0BaseRevisionRule();
    const Teamcenter::Soa::Client::ModelObjectVector& get_awb0EffEndItemVec();
    const Teamcenter::Soa::Client::ModelObjectVector& get_awb0VariantRules();
    const Teamcenter::Soa::Client::StringVector& get_awb0Subscribers();
    ClosureRule* get_awb0ClosureRule();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awb0BOMIndexAdminData")

   virtual ~Awb0BOMIndexAdminData();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Activeworkspacebom_undef.h>
#endif
