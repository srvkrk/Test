/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWB0BOOKMARKDATA_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWB0BOOKMARKDATA_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/POM_object.hxx>

#include <teamcenter/soa/client/model/Activeworkspacebom_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAACTIVEWORKSPACEBOMMODEL_API Awb0BookmarkData : public Teamcenter::Soa::Client::Model::POM_object
{
public:
    Teamcenter::Soa::Client::ModelObject* get_awb0OwningObject();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awb0BookmarkData")

   virtual ~Awb0BookmarkData();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Activeworkspacebom_undef.h>
#endif
