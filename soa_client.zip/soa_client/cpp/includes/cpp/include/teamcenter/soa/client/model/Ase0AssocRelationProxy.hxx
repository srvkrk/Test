/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_ASE0ASSOCRELATIONPROXY_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_ASE0ASSOCRELATIONPROXY_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/RuntimeBusinessObject.hxx>

#include <teamcenter/soa/client/model/Ase0activeworkspacesyseng_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAASE0ACTIVEWORKSPACESYSENGMODEL_API Ase0AssocRelationProxy : public Teamcenter::Soa::Client::Model::RuntimeBusinessObject
{
public:
    Teamcenter::Soa::Client::ModelObject* get_ase0Relation();
    Teamcenter::Soa::Client::ModelObject* get_ase0EndObject();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Ase0AssocRelationProxy")

   virtual ~Ase0AssocRelationProxy();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Ase0activeworkspacesyseng_undef.h>
#endif
