/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWP0XRTOBJECTSETROW_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWP0XRTOBJECTSETROW_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/RuntimeBusinessObject.hxx>

#include <teamcenter/soa/client/model/Aws2_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAAWS2MODEL_API Awp0XRTObjectSetRow : public Teamcenter::Soa::Client::Model::RuntimeBusinessObject
{
public:
    Teamcenter::Soa::Client::ModelObject* get_awp0Relation();
    bool get_awp0IsCutAllowed();
    const std::string& get_awp0RelationTypeName();
    const std::string& get_awp0RelationTypeDisplayName();
    const std::string& get_awp0RefPropertyName();
    Teamcenter::Soa::Client::ModelObject* get_awp0Target();
    Teamcenter::Soa::Client::ModelObject* get_awp0Primary();
    Teamcenter::Soa::Client::ModelObject* get_awp0Secondary();
    Teamcenter::Soa::Client::ModelObject* get_awp0Relationship();
    bool get_is_modifiable();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awp0XRTObjectSetRow")

   virtual ~Awp0XRTObjectSetRow();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Aws2_undef.h>
#endif
