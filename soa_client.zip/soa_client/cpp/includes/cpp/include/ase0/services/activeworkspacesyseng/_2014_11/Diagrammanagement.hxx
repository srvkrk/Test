/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef ASE0_SERVICES_ACTIVEWORKSPACESYSENG__2014_11_DIAGRAMMANAGEMENT_HXX
#define ASE0_SERVICES_ACTIVEWORKSPACESYSENG__2014_11_DIAGRAMMANAGEMENT_HXX

#include <ase0/services/activeworkspacesyseng/_2012_10/Diagrammanagement.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <ase0/services/activeworkspacesyseng/ActiveWorkspaceSysEng_exports.h>

namespace Ase0
{
    namespace Services
    {
        namespace Activeworkspacesyseng
        {
            namespace _2014_11
            {
                class Diagrammanagement;

class ASE0SOAACTIVEWORKSPACESYSENGSTRONG_API Diagrammanagement
{
public:

    struct DiagramLegendData;
    struct DiagramLegendData1;
    struct DiagramLegendResponse;
    struct DiagramLegendResponse1;
    struct FilterData;
    struct FilterData1;
    struct TypeData1;

    /**
     * Structure represents the output data of the operation.
     */
    struct DiagramLegendData
    {
        /**
         * The name of the Legend.
         */
        std::string name;
        /**
         * The localized display name of the Legend.
         */
        std::string displayName;
        /**
         * The default layout of the view.  The value could be Incremental, Orthographic,Tree,Left
         * To Right, Right To Left etc.  This value is utilized by the Graph component.
         */
        std::string defaultLayout;
        /**
         * The list of object filters.
         */
        std::vector< Ase0::Services::Activeworkspacesyseng::_2014_11::Diagrammanagement::FilterData > objectGroup;
        /**
         * The list of relation filters.
         */
        std::vector< Ase0::Services::Activeworkspacesyseng::_2014_11::Diagrammanagement::FilterData > relationGroup;
    };

    /**
     * Structure represents the output data of the operation.
     */
    struct DiagramLegendData1
    {
        /**
         * The name of the Legend.
         */
        std::string name;
        /**
         * The localized display name of the Legend.
         */
        std::string displayName;
        /**
         * The default layout of the view.  The value could be Incremental, Orthographic,Tree,Left
         * To Right, Right To Left etc.  This value is utilized by the Graph component.
         */
        std::string defaultLayout;
        /**
         * The list of data of different types.
         */
        std::vector< Ase0::Services::Activeworkspacesyseng::_2014_11::Diagrammanagement::FilterData1 > groupData;
    };

    /**
     * Structure represents the output parameters of the operation.
     */
    struct DiagramLegendResponse
    {
        /**
         * The list of DiagramLegendData structures.
         */
        std::vector< Ase0::Services::Activeworkspacesyseng::_2014_11::Diagrammanagement::DiagramLegendData > legendData;
        /**
         * The information about how a Node or an Edge  is to be rendered based on the type
         * it represents is defined in this XML. For instance, a Node representing  the type
         * Ase0FunctionalElement is shown as a Tile.  This XML is read from the dataset specified
         * in the  preference SE_diagram_presentation_rules_file_name. A sample entry in the
         * XML files is as follows. <PresentationRule  type="Node" styleId="FunctionalStyle">
         * <Conditions operator="and"> <Type  value="Ase0FunctionalElement" operator="typeOf"
         * /> </Conditions> </PresentationRule>.
         */
        std::string presentationRulesXML;
        /**
         * The information about shapes assigned to types.  For instance, to show Traceability
         * as a line on the diagram, the parameters of the line are defined in the XML, like
         * lineWidth, lineStyle,lineColor. This XML is read from the dataset specified in the
         * preference SE_diagram_presentation_styles_file_name. A sample entry in the XML file
         * is as follows. <NodePresentation id="FunctionalStyle"> <parameter name="shape"><value>Tile</value></parameter>
         * </NodePresentation>
         */
        std::string presentationStylesXML;
        /**
         * The Service Data.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * Structure represents the output parameters of the operation.
     */
    struct DiagramLegendResponse1
    {
        /**
         * The list of DiagramLegendData structures.
         */
        std::vector< Ase0::Services::Activeworkspacesyseng::_2014_11::Diagrammanagement::DiagramLegendData1 > legendData;
        /**
         * The information about how a Node or an Edge is to be rendered based on the type it
         * represents is defined in this XML. For instance, a Node representing the type Ase0FunctionalElement
         * is shown as a Tile.  This XML is read from the dataset specified  in the preference
         * SE_diagram_presentation_rules_file_name. A sample entry in the XML files is as follows.
         * <PresentationRule type="Node" styleId="FunctionalStyle"> <Conditions operator="and">
         * <Type value="Ase0FunctionalElement" operator="typeOf" /> </Conditions> </PresentationRule>.
         */
        std::string presentationRulesXML;
        /**
         * The information about shapes assigned to types.  For instance, to show Traceability
         * as a line on the diagram, the parameters of the line are defined in the XML, like
         * lineWidth, lineStyle,lineColor. This XML is read from the dataset specified in the
         * preference SE_diagram_presentation_styles_file_name. A sample entry in the XML file
         * is as follows. <NodePresentation id="FunctionalStyle"> <parameter name="shape"><value>Tile</value></parameter>
         * </NodePresentation>
         */
        std::string presentationStylesXML;
        /**
         * The Service Data.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * Structure for representing information of a filter, including filter name, RGB values
     * to color the legend of the filter at client side.
     */
    struct FilterData
    {
        /**
         * The name of the filter. For objects, the values are Logical, Function, Requirement
         * and Items, and for relations, the values are Connectivity, Traceability and Structure.
         */
        std::string name;
        /**
         * The display name of the filter
         */
        std::string displayName;
        /**
         * The object or relation type information to be shown in the legend.
         */
        std::vector< Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::TypeData > types;
        /**
         * The color used for legend of this filter on the client.
         */
        Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::RGBValue color;
    };

    /**
     * Structure for representing information of a filter, including filter name, RGB values
     * to color the legend of the filter at client side.
     */
    struct FilterData1
    {
        /**
         * The name of the filter. For objects, the values are Logical, Function, Requirement
         * and Items, and for relations, the values are Connectivity, Traceability and Structure.
         */
        std::string name;
        /**
         * The display name of the filter
         */
        std::string displayName;
        /**
         * The object type information to be shown in the legend.
         */
        std::vector< Ase0::Services::Activeworkspacesyseng::_2014_11::Diagrammanagement::TypeData1 > types;
        /**
         * The color used for legend of this filter on the client.
         */
        Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::RGBValue color;
        /**
         * The type name of group to to be added in Legend.
         */
        std::string groupType;
    };

    /**
     * Structure containing the type information.
     */
    struct TypeData1
    {
        /**
         * The model name of the type.
         */
        std::string typeName;
        /**
         * The display name of the type
         */
        std::string displayName;
        /**
         * To decide whether the objects of this type are authorable.
         */
        bool isAuthorable;
    };




    /**
     * This operation returns a localized list of objects and relation types which are used
     * to  navigate the data on a diagram. This list of objects and relation types is the
     * filter which is applied  during the diagram navigation.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param viewName
     *        The name of the view for which the legend is to be populated.
     *
     * @return
     *         A list of supported objects and relation types. If there is no matching data for
     *         the input view, empty list will be returned. The following partial errors may be
     *         returned.
     *         <br>
     *         124003&nbsp;&nbsp;&nbsp;&nbsp;  if the configuration file does not exist on the server.
     *
     * @deprecated
     *         As of Teamcenter 10.1.5, this operation does not support ability to consider display
     *         rules for returned types and ability to define scope for creation of any category
     *         types. Use the getDiagramLegend4 service operation.
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 10.1.5, this operation does not support ability to consider display rules for returned types and ability to define scope for creation of any category types. Use the getDiagramLegend4 service operation."))
#endif
    virtual Ase0::Services::Activeworkspacesyseng::_2014_11::Diagrammanagement::DiagramLegendResponse getDiagramLegend2 ( const std::string&  viewName ) = 0;

    /**
     * This operation returns a localized list of objects, relation and port type names
     * which are used to navigate the data on a diagram. This list of object type names
     * is the filter which is applied during the diagram navigation. The type data returns
     * the flag to mention if the user has access to author the object type or not.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param viewName
     *        The name of the view for which the legend is to be populated.
     *
     * @return
     *         A list of supported objects and relation types. If there is no matching data for
     *         the input view, empty list will be returned. The following partial errors may be
     *         returned. 124003      if the configuration file does not exist on the server.
     *
     * @deprecated
     *         As of Teamcenter 10.1.5, this operation does not support ability to define scope
     *         for creation of any category types. Use the getDiagramLegend4 service operation.
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 10.1.5, this operation does not support ability to define scope for creation of any category types. Use the getDiagramLegend4 service operation."))
#endif
    virtual Ase0::Services::Activeworkspacesyseng::_2014_11::Diagrammanagement::DiagramLegendResponse1 getDiagramLegend3 ( const std::string&  viewName ) = 0;


protected:
    virtual ~Diagrammanagement() {}
};
            }
        }
    }
}

#include <ase0/services/activeworkspacesyseng/ActiveWorkspaceSysEng_undef.h>
#endif

