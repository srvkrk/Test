/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef EWI0_SERVICES_EWIA__2015_03_DATAMANAGEMENT_HXX
#define EWI0_SERVICES_EWIA__2015_03_DATAMANAGEMENT_HXX

#include <ewi0/services/ewia/_2012_10/Datamanagement.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <ewi0/services/ewia/Ewia_exports.h>

namespace Ewi0
{
    namespace Services
    {
        namespace Ewia
        {
            namespace _2015_03
            {
                class Datamanagement;

class EWI0SOAEWIASTRONG_API Datamanagement
{
public:

    struct LoadWorkPackageConfiguredInput;

    /**
     * A map of string key to the string value.
     */
    typedef std::map< std::string, std::string > StringMap;

    /**
     * This structure contains the parameters required to load a work package data in EWI.
     */
    struct LoadWorkPackageConfiguredInput
    {
        /**
         * The UID of the work package business object (CCobject or subtype of it).
         */
        std::string workPackageUid;
        /**
         * The UID of the current step in the navigated structure that needs to be loaded into
         * EWI.
         */
        std::string currentStepUid;
        /**
         * If true, the header properties are needed. The header proeprites are properties of
         * the work package object. They are needed usually only at the first time the work
         * package data is loaded.
         */
        bool loadHeaderProperties;
        /**
         * A map (string, string) containing the configuration parameters. The keys are the
         * parameter names, the values are the parameter values.The legal (key,value) pairs
         * are:
         * <br>
         * <ul>
         * <li type="disc">("revrule",The name of the revision rule to configure by)
         * </li>
         * <li type="disc">("date",The effective date in the format MM-dd-yyyy)
         * </li>
         * <li type="disc">("unitno",The effective unit number)
         * </li>
         * <li type="disc">("enditem",The UID of the End Item)
         * </li>
         * </ul>
         */
        StringMap configParamsMap;
    };




    /**
     * This operation loads work package data with optional configuration parameters to
     * the EWI (Electronic Work Instructions) application. Work package is a Collaboration
     * Context object packaging manufacturing structures with specific configuration settings.
     * The additionl configuration parameters can be used to apply further , on-demand,
     * configuration settings on top of the work package configuration.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param input
     *        A vector containing the input structures.
     *
     * @return
     *         The requested work package data.
     *         <br>
     *         The following partial errors may be returned:
     *         <br>
     *         <ul>
     *         <li type="disc">115001 - The operation "loadWorkPackageData" has failed because the
     *         input does not contain work package information. Please contact your system administrator.
     *         </li>
     *         <li type="disc">115002 - The creation of an Electronic Work Instruction object for
     *         the work package has failed. Please contact your system administrator.
     *         </li>
     *         <li type="disc">115003 - The creation of an Electronic Work Instruction object for
     *         the current step has failed. Please contact your system administrator.
     *         </li>
     *         <li type="disc">115004 - None of the preferred navigation structures are found in
     *         the selected work package. Either add a value to the preference "EWI_NavigationStructure"
     *         (in order to open a different navigation structure), or select a different work package.
     *         </li>
     *         <li type="disc">115007 - Teamcenter Electronic Work Instructions (EWI) license is
     *         not installed. Please contact your system administrator.
     *         </li>
     *         </ul>
     *
     */
    virtual Ewi0::Services::Ewia::_2012_10::Datamanagement::LoadWorkPackageDataResponse loadWorkPackageDataConfigured ( const std::vector< Ewi0::Services::Ewia::_2015_03::Datamanagement::LoadWorkPackageConfiguredInput >& input ) = 0;


protected:
    virtual ~Datamanagement() {}
};
            }
        }
    }
}

#include <ewi0/services/ewia/Ewia_undef.h>
#endif

