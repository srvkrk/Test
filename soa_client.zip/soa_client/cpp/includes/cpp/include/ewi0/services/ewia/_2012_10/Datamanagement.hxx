/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef EWI0_SERVICES_EWIA__2012_10_DATAMANAGEMENT_HXX
#define EWI0_SERVICES_EWIA__2012_10_DATAMANAGEMENT_HXX

#include <teamcenter/soa/client/model/ImanFile.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <ewi0/services/ewia/Ewia_exports.h>

namespace Ewi0
{
    namespace Services
    {
        namespace Ewia
        {
            namespace _2012_10
            {
                class Datamanagement;

class EWI0SOAEWIASTRONG_API Datamanagement
{
public:

    struct CortonaFileInput;
    struct CortonaFileOutput;
    struct CortonaFileResponse;
    struct FileTicketPair;
    struct GeneratePrintReportInput;
    struct GeneratePrintReportResponse;
    struct GetRelatedInputInfo;
    struct GetRelatedResponse;
    struct LoadWorkPackageDataResponse;
    struct LoadWorkPackageInput;
    struct ObjectRelationsInfo;
    struct PropertyInfo;
    struct RelatedObjectInfo;
    struct WorkPackageData;

    /**
     * The map of relations/properties to the type of objects to load from given related
     * objects.
     */
    typedef std::map< std::string, std::vector< std::string > > RelationsMap;

    /**
     * The input structure for cortona animation file.
     */
    struct CortonaFileInput
    {
        /**
         * The file object from which to get the animation file
         */
        Teamcenter::Soa::Client::Model::ImanFile* fileObject;
    };

    /**
     * The output structure which contains the file read ticket of the animation file.
     */
    struct CortonaFileOutput
    {
        /**
         * The file object for which cortona wrl file read ticket is returned.
         */
        Teamcenter::Soa::Client::Model::ImanFile* fileObject;
        /**
         * The file read ticket.
         */
        std::string fileReadTicket;
    };

    /**
     * The response of the cortona file soa.
     */
    struct CortonaFileResponse
    {
        /**
         * the vector of cortona file output.
         */
        std::vector< Ewi0::Services::Ewia::_2012_10::Datamanagement::CortonaFileOutput > output;
        /**
         * service data
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * A pair that handles a business object and its related file ticket.
     */
    struct FileTicketPair
    {
        /**
         * The business object.
         */
        Teamcenter::Soa::Client::ModelObject* busObject;
        /**
         * The ticket that corresponds to the file.
         */
        std::string ticket;
    };

    /**
     * The input object for generating report.
     */
    struct GeneratePrintReportInput
    {
        /**
         * The context object whose data will be printed.
         */
        std::string contextObject;
        /**
         * The scope configuration of the print.  i.e. Print the whole work package or single
         * step or single step with children, etc...
         */
        std::string reportScope;
    };

    /**
     * The GeneratePrintableReport SOA response object.
     */
    struct GeneratePrintReportResponse
    {
        /**
         * The service data.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
        /**
         * The list of context objects and matching report file tickets.
         */
        std::vector< Ewi0::Services::Ewia::_2012_10::Datamanagement::FileTicketPair > reportFilesInfo;
    };

    /**
     * This is a container of Business Objects and their relations to load. For every relation,
     * a list of specific types from that relation needs to be specified.
     */
    struct GetRelatedInputInfo
    {
        /**
         * The vector of business objects for which relations needs to be loaded.
         */
        std::vector< Teamcenter::Soa::Client::ModelObject* > businessObjects;
        /**
         * The map of relations to load. This map contains the name of the relation/property
         * and the list of types to load from the given relation/property.
         */
        RelationsMap relations;
    };

    /**
     * The response of get related soa operation
     */
    struct GetRelatedResponse
    {
        /**
         * The service data.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
        /**
         * the vector of related objects information
         */
        std::vector< Ewi0::Services::Ewia::_2012_10::Datamanagement::ObjectRelationsInfo > relatedObjectsInfo;
    };

    /**
     * The response of loadWorkPackageData for ewi.
     */
    struct LoadWorkPackageDataResponse
    {
        /**
         * The returned work package data.
         */
        std::vector< Ewi0::Services::Ewia::_2012_10::Datamanagement::WorkPackageData > workPackageDataInfo;
        /**
         * The service data.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * The input for LoadWorkPackageData
     */
    struct LoadWorkPackageInput
    {
        /**
         * The uid of the work package business object.
         */
        std::string workPackageUid;
        /**
         * The uid of the current step to load.
         */
        std::string currentStepUid;
        /**
         * Indicates whether the header properties are needed or not.
         */
        bool loadHeaderProperties;
    };

    /**
     * The information about related obejcts of a business object
     */
    struct ObjectRelationsInfo
    {
        /**
         * the object whose related objects are given
         */
        Teamcenter::Soa::Client::ModelObject* object;
        /**
         * the relation name
         */
        std::string relation;
        /**
         * the related objects vector
         */
        std::vector< Ewi0::Services::Ewia::_2012_10::Datamanagement::RelatedObjectInfo > relatedObjects;
    };

    /**
     * Holds the information of the property
     */
    struct PropertyInfo
    {
        /**
         * Holds the name of the property.
         */
        std::string propertyName;
        /**
         * Holds the value of the property.
         */
        std::string propertyValue;
    };

    /**
     * The information of the related object.
     */
    struct RelatedObjectInfo
    {
        /**
         * The related object such as dataset.
         */
        Teamcenter::Soa::Client::ModelObject* relatedObject;
        /**
         * A vector of file/ticket pairs.
         */
        std::vector< Ewi0::Services::Ewia::_2012_10::Datamanagement::FileTicketPair > fileTicketsVector;
    };

    /**
     * The data of the Ewi work package.
     */
    struct WorkPackageData
    {
        /**
         * Header properties that will be shown in Ewi location header.
         */
        std::vector< Ewi0::Services::Ewia::_2012_10::Datamanagement::PropertyInfo > headerProperties;
        /**
         * The work package business object whose uid is mentioned in the input.
         */
        Teamcenter::Soa::Client::ModelObject* workPackage;
        /**
         * The current step business object whose uid is mentioned in the input.
         */
        Teamcenter::Soa::Client::ModelObject* currentStep;
        /**
         * The uid of the next step. Null if current step is the last step in the work package.
         */
        std::string nextStepUid;
        /**
         * The uid of the next step. Null if the current step if the first step in the work
         * package.
         */
        std::string previousStepUid;
    };




    /**
     * Generates printable report for the EWI.
     *
     * @param input
     *        The input object for the report generation SOA.
     *
     * @return
     *         The printable report object.
     *
     */
    virtual Ewi0::Services::Ewia::_2012_10::Datamanagement::GeneratePrintReportResponse generatePrintableReport ( const std::vector< Ewi0::Services::Ewia::_2012_10::Datamanagement::GeneratePrintReportInput >& input ) = 0;

    /**
     * Returns the file read ticket of the Cortona 3D animation (.wrl) file from the given
     * Cortona build file.
     *
     * @param input
     *        the vector of cortona files for which read ticket is required.
     *
     * @return
     *         The file read ticket of animation file.
     *
     */
    virtual Ewi0::Services::Ewia::_2012_10::Datamanagement::CortonaFileResponse getCortonaAnimationFileTicket ( const std::vector< Ewi0::Services::Ewia::_2012_10::Datamanagement::CortonaFileInput >& input ) = 0;

    /**
     * This operation returns the given relation/property data of input business objects.
     * For every relation/property, you can specify the type of required objects you want
     * to load. In case you want to load all of the objects related, then pass empty list
     * of types.
     *
     * @param input
     *        the input
     *
     * @return
     *         The relations/properties data by given types.
     *
     */
    virtual Ewi0::Services::Ewia::_2012_10::Datamanagement::GetRelatedResponse getRelated ( const Ewi0::Services::Ewia::_2012_10::Datamanagement::GetRelatedInputInfo&  input ) = 0;

    /**
     * Load required work package data for Ewi.
     *
     * @param input
     *        The input vector.
     *
     * @return
     *         Required work package data for Ewi.
     *
     */
    virtual Ewi0::Services::Ewia::_2012_10::Datamanagement::LoadWorkPackageDataResponse loadWorkPackageData ( const std::vector< Ewi0::Services::Ewia::_2012_10::Datamanagement::LoadWorkPackageInput >& input ) = 0;


protected:
    virtual ~Datamanagement() {}
};
            }
        }
    }
}

#include <ewi0/services/ewia/Ewia_undef.h>
#endif

