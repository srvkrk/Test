/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef CAE1_SERVICES_CAEAW__2016_03_SIMULATIONMANAGEMENTAW_HXX
#define CAE1_SERVICES_CAEAW__2016_03_SIMULATIONMANAGEMENTAW_HXX

#include <teamcenter/soa/client/ModelObject.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <cae1/services/caeaw/CaeAw_exports.h>

namespace Cae1
{
    namespace Services
    {
        namespace Caeaw
        {
            namespace _2016_03
            {
                class Simulationmanagementaw;

class CAE1SOACAEAWSTRONG_API Simulationmanagementaw
{
public:





    /**
     * This operation captures the pedigree configuration in the provided product context
     * from the ActiveWorkspace client and attaches it to the CAE Item revision.
     * <br>
     * To use this operation, the user must have either a "simulation_author" or "rtt_author
     * license<b>".</b>
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * <b>Use Case 1:</b> User loads a configured structure in content view of  from Active
     * Workspace Client. and User creates a CAE Model Item in relation within the loaded
     * configured structure in content view.context. This will relate the created CAE Model
     * to  the loaded structure with a  CAE Relation.When executed, the operation checks
     * for all the preferences needed for pedigree operations and captures pedigree under
     * the provided CAE Model ItemRevision.
     * <br>
     * <br>
     * <b>Use Case 2:</b> User loads a configured structure inside in content view of Active
     * Workspace Client. and User creates a CAE Analysis Item  in relation within the loaded
     * contextconfigured structure in content view.  This will relate the created CAE Analysis
     * to  the loaded structure with a CAE Relation.When executed, the operation checks
     * for all the preferences needed for pedigree operations and captures pedigree under
     * the provided CAE Analysis ItemRevision.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * CAE Integrations - Provides custom extensions to the Tc data model to capture the
     * CAE data model; the services that provide behaviors that are specific to CAE clients
     * and the client side code that accesses the data model and services.
     *
     * @param productContextInfo
     *        Product context information from content view in Active Workspace Client.
     *
     * @param caeItemRevision
     *        <b>CAEItemRevision</b> types i.e. <b>CAEModelItemRevision</b> or <b>CAEAnalysisItemRevision</b>.
     *
     * @return
     *         The following partial errors may be returned:
     *         <br>
     *         <ul>
     *         <li type="disc">51000 - Internal error in AOM Module. Please report this to your
     *         system administrator.
     *         </li>
     *         <li type="disc">51003 - The current user does not have write access to the selected
     *         object.
     *         </li>
     *         <li type="disc">51001 - Object is locked for modify in another session.
     *         </li>
     *         <li type="disc">206872 - The Pedigree cannot be captured, because no relation exists
     *         as required by
     *         </li>
     *         <li type="disc">preference "CAE_pedigree_model_relationships/CAE_pedigree_analysis_relationships"
     *         of type
     *         </li>
     *         <li type="disc">"Model Pedigree/Analysis Pedigree".
     *         </li>
     *         </ul>
     *
     */
    virtual Teamcenter::Soa::Client::ServiceData captureAndAttachCAEPedigree ( Teamcenter::Soa::Client::ModelObject* productContextInfo,
        Teamcenter::Soa::Client::ModelObject* caeItemRevision ) = 0;


protected:
    virtual ~Simulationmanagementaw() {}
};
            }
        }
    }
}

#include <cae1/services/caeaw/CaeAw_undef.h>
#endif

