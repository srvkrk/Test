/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef S2CL_SERVICES_SERVICES_SOCIALCOLLABORATIONSERVICE_HXX
#define S2CL_SERVICES_SERVICES_SOCIALCOLLABORATIONSERVICE_HXX

#include <s2cl/services/services/_2012_10/Socialcollaboration.hxx>
#include <s2cl/services/services/_2014_11/Socialcollaboration.hxx>



#include <teamcenter/soa/client/Connection.hxx>
#include <new> // for size_t
#include <teamcenter/soa/common/MemoryManager.hxx>

#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable : 4996  )
#endif

#include <s2cl/services/services/Services_exports.h>

namespace S2cl
{
    namespace Services
    {
        namespace Services
        {
            class SocialcollaborationService;

/**
 * This service contains operations for creating and editing content within Social Collaboration.
 * Operations are provided to manage comments, subscriptions, notification preferences,
 * tags and to control subscriptions.
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libs2clsoaservicesstrong.dll
 * </li>
 * <li type="disc">libs2clsoaservicestypes.dll (runtime dependency)
 * </li>
 * </ul>
 */

class S2CLSOASOCIALSTRONG_API SocialcollaborationService
    : public S2cl::Services::Services::_2012_10::Socialcollaboration,
             public S2cl::Services::Services::_2014_11::Socialcollaboration
{
public:
    static SocialcollaborationService* getService( Teamcenter::Soa::Client::Connection* );


    /**
     * creates s2clcommentary object.
     *
     * @param request
     *        create comment request object
     *
     * @return
     *         returns response with comment uid
     *
     *
     * @exception ServiceException
     *           
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::CreateCommentResponse createComment ( const S2cl::Services::Services::_2012_10::Socialcollaboration::CreateCommentRequest&  request ) = 0;

    /**
     * delete s2clenvelopes based on object property isread=true and  iterval defined as
     * preference.
     *
     * @param request
     *        Request from client
     *
     * @return
     *         deleted s2clenvelopes
     *
     */
    virtual Teamcenter::Soa::Client::ServiceData deleteActivities ( const S2cl::Services::Services::_2012_10::Socialcollaboration::ActivityStreamRequest&  request ) = 0;

    /**
     * Delete a comment on a WSO.
     *
     * @param request
     *        request arg of type DeleteCommentRequest
     *
     * @return
     *         Delete comment operaiton response
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::DeleteCommentResponse deleteComment ( const S2cl::Services::Services::_2012_10::Socialcollaboration::DeleteCommentRequest&  request ) = 0;

    /**
     * fetch s2clenvelopes on uid provided by client.
     *
     * @param request
     *        request from client
     *
     * @return
     *         s2clenvelope  objects
     *
     */
    virtual Teamcenter::Soa::Client::ServiceData fetchActivities ( const S2cl::Services::Services::_2012_10::Socialcollaboration::ActivityStreamRequest&  request ) = 0;

    /**
     * fetch notification preferences for logged user.
     *
     * @param request
     *        Request from client
     *
     * @return
     *         List of preferences according to categories
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::NotificationPreferenceResponse fetchNotificationPreferences ( const S2cl::Services::Services::_2012_10::Socialcollaboration::NotificationPreferenceRequest&  request ) = 0;

    /**
     * ServiceData whose plainobjects consist of send to list.
     *
     * @param objectUid
     *        Uid of the object for which send to list is to be fetched
     *
     * @return
     *         user/group/role in send to list of the input object
     *
     */
    virtual Teamcenter::Soa::Client::ServiceData fetchSendToList ( const std::string&  objectUid ) = 0;

    /**
     * fetches the subscribers associcated with the input object.
     *
     * @param objectUid
     *        Uid of the object for which subscribers need to be fetched.
     *
     * @return
     *         subscribers objects associated with the input object
     *
     * @deprecated
     *         As of Teamcenter 9.1.3, this operation is deprecated and is no longer supported.
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 9.1.3, this operation is deprecated and is no longer supported."))
#endif
    virtual Teamcenter::Soa::Client::ServiceData fetchSubScribers ( const std::string&  objectUid ) = 0;

    /**
     * returnd the list of subscription preferenses names and thier values as per associated
     * group.
     *
     * @param request
     *        input parameter for getting auto subscription preferences.
     *
     * @return
     *         list of preferences ordered by group.
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::SubscriptionPreferenceResponse fetchSubscriptionPreferences ( const S2cl::Services::Services::_2012_10::Socialcollaboration::SubscriptionPreferenceRequest&  request ) = 0;

    /**
     * ServiceData whose plain objects consist of subscriptions which can consisist of users/groups/workspace
     * objects of the input object.
     *
     * @param objectUid
     *        Uid of the object for which subscribers need to be fetched
     *
     * @return
     *         subscription objects associated with the input object
     *
     * @deprecated
     *         As of Teamcenter 9.1.3, this operation is deprecated and is no longer supported.
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 9.1.3, this operation is deprecated and is no longer supported."))
#endif
    virtual Teamcenter::Soa::Client::ServiceData fetchSubscriptions ( const std::string&  objectUid ) = 0;

    /**
     * Return most trending objects in Teamcenter. Trending objects are those which have
     * most social commentary on them
     *
     * @return
     *         ServiceData whose plainobjects consist of WSO which are trending in given time frame
     *
     */
    virtual Teamcenter::Soa::Client::ServiceData fetchTrendingData (  ) = 0;

    /**
     * Gets all the tags available in the system. Alternatively returns all tags similar
     * to received argument
     *
     * @param startsWith
     *        Get all tag names starting with this value
     *
     * @return
     *         Returns array of strings
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::TagResponse getAllTags ( const std::string&  startsWith ) = 0;

    /**
     * Gets tags as string associated with current object.
     *
     * @param request
     *        Reqyest object
     *
     * @return
     *         Returns TargResponse having vector of strings
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::TagResponse getTags ( const S2cl::Services::Services::_2012_10::Socialcollaboration::TagRequest&  request ) = 0;

    /**
     * removes specific tags from object.
     *
     * @param request
     *        Request object
     *
     * @return
     *         Returns TagResponse which holds details of operation execution
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::TagResponse removeTags ( const S2cl::Services::Services::_2012_10::Socialcollaboration::TagRequest&  request ) = 0;

    /**
     * Set notification preferences.
     *
     * @param request
     *        Request object from client
     *
     * @return
     *         success status
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::NotificationPreferenceResponse setNotificationPreferences ( const S2cl::Services::Services::_2012_10::Socialcollaboration::NotificationPreferenceRequest&  request ) = 0;

    /**
     * sets the subscription preferences.
     *
     * @param input
     *        subscription preference request
     *
     * @return
     *         subscription pref response
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::SubscriptionPreferenceResponse setSubscriptionPreferences ( const S2cl::Services::Services::_2012_10::Socialcollaboration::SubscriptionPreferenceRequest&  input ) = 0;

    /**
     * sets tags on received object.
     *
     * @param request
     *        Request object
     *
     * @return
     *         returns TagResponse with success or failure boolean and message
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::TagResponse setTags ( const S2cl::Services::Services::_2012_10::Socialcollaboration::TagRequest&  request ) = 0;

    /**
     * service for subsribe/unsubscribe to social events.
     *
     * @param targetObjectUid
     *        Uid of object to be subscribed.
     *
     * @return
     *         subscribeToObject as populated by the server in response to operation execution
     *
     * @deprecated
     *         As of Teamcenter 9.1.3, this operation is deprecated and is no longer supported.
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 9.1.3, this operation is deprecated and is no longer supported."))
#endif
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::SubscriptionResponse subscribeToObject ( const std::string&  targetObjectUid ) = 0;

    /**
     * unsubscribes the object.
     *
     * @param targetObjectUid
     *        uid of the object to be unsubscribed.
     *
     * @return
     *         unsubscribeToObject as populated by the server in response to operation execution
     *
     * @deprecated
     *         As of Teamcenter 9.1.3, this operation is deprecated and is no longer supported.
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 9.1.3, this operation is deprecated and is no longer supported."))
#endif
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::SubscriptionResponse unSubscribeToObject ( const std::string&  targetObjectUid ) = 0;

    /**
     * Update plaintext and or rating value attributes of a comment.
     *
     * @param request
     *        UpdateCommentRequest object as received from the client
     *
     * @return
     *         UpdateCommentResponse as populated by the server in response to operation execution
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::UpdateCommentResponse updateComment ( const S2cl::Services::Services::_2012_10::Socialcollaboration::UpdateCommentRequest&  request ) = 0;

    /**
     * This performs a query for a <b>S2clScalarRating</b> object given a <b>WorkspaceObject</b>
     * and <b>User</b>. If multiple <b>S2clScalarRating</b> objects are found, only the
     * most recent is returned. Returned along with the rating object is the rating value
     * and all the summary rating information properties for that <b>WorkspaceObject</b>
     * to include, total ratings, average rating, total 5 star ratings, total 4 star ratings,
     * total 3 start ratings, total 2 star ratings and total 1 star ratings.  Multiple requests
     * for scalar rating objects based on a <b>WorkspaceObject</b> and  <b>User</b> can
     * be requested by passing in a list of input structures.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param scalarRatingRequest
     *        Data used to query for an existing <b>S2clScalarRating</b> object.
     *
     * @return
     *         The <b>S2clScalarRating</b> object identified by the input parameter clientId and
     *         the summary of ratings for the <b>WorkspaceObject</b>.  Any failure will be returned
     *         with the clientId mapped to the partial errors. The following partial errors may
     *         be returned.
     *         <br>
     *         <ul>
     *         <li type="disc">146003 The "Social Scalar Rating" data could not be found.
     *         </li>
     *         </ul>
     *
     */
    virtual S2cl::Services::Services::_2014_11::Socialcollaboration::ScalarRatingResponse fetchScalarRating ( const std::vector< S2cl::Services::Services::_2014_11::Socialcollaboration::ScalarRatingRequest >& scalarRatingRequest ) = 0;


    SOA_CLASS_NEW_OPERATORS_WITH_IMPL("SocialcollaborationService")

};
        }
    }
}


#ifdef WIN32
#pragma warning ( pop )
#endif

#include <s2cl/services/services/Services_undef.h>
#endif

