/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef S2CL_SERVICES_SERVICES__2012_10_SOCIALCOLLABORATION_HXX
#define S2CL_SERVICES_SERVICES__2012_10_SOCIALCOLLABORATION_HXX



#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <s2cl/services/services/Services_exports.h>

namespace S2cl
{
    namespace Services
    {
        namespace Services
        {
            namespace _2012_10
            {
                class Socialcollaboration;

class S2CLSOASOCIALSTRONG_API Socialcollaboration
{
public:

    struct ActivityStreamRequest;
    struct CategoryInfo;
    struct CreateCommentRequest;
    struct CreateCommentResponse;
    struct DeleteCommentRequest;
    struct DeleteCommentResponse;
    struct NotificationPreferenceRequest;
    struct NotificationPreferenceResponse;
    struct PreferenceInfo;
    struct SubscriptionPreferenceRequest;
    struct SubscriptionPreferenceResponse;
    struct SubscriptionResponse;
    struct TagRequest;
    struct TagResponse;
    struct UpdateCommentRequest;
    struct UpdateCommentResponse;

    /**
     * Holds information of attributes in terms of name and value
     */
    typedef std::map< std::string, std::string > AttributesNameValue;

    /**
     * Request object for fetchActivities/deleteActivities operation
     */
    struct ActivityStreamRequest
    {
        /**
         * Uid of object to be received from client
         */
        std::string objectUid;
    };

    /**
     * Category of Object.
     */
    struct CategoryInfo
    {
        /**
         * Name of Object category
         */
        std::string categoryName;
        /**
         * Preferences list
         */
        std::vector< S2cl::Services::Services::_2012_10::Socialcollaboration::PreferenceInfo > perferences;
    };

    /**
     * Request object for createComment operation
     */
    struct CreateCommentRequest
    {
        /**
         * comment plain text as entered by user
         */
        std::string plainText;
        /**
         * uid of the contextual object on which add comment button is clicked
         */
        std::string targetObjectUid;
        /**
         * Integer value of rating
         */
        int ratingValue;
        /**
         * Business Object Type of comment to be created. It should be one of following : S2clCommentary,
         * S2clQuestion, S2clAnswer, S2clScalarRating, S2clToggleRating, S2clExperience or any
         * of derived business objects
         */
        std::string commentType;
        /**
         * comment rich text as entered by user
         */
        std::string richText;
        /**
         * Vector of string uids of context objects to be set on commentary object
         */
        std::vector< std::string > contextObjectUids;
        /**
         * Vector of string uids of sendTo objects to be set on commentary object
         */
        std::vector< std::string > sendToObjectUids;
        /**
         * Comma Seperated tag object names.
         */
        std::string tagNameString;
        /**
         * Object name of the comment as specified by the user
         */
        std::string objectName;
    };

    /**
     * response from createComment operation
     */
    struct CreateCommentResponse
    {
        /**
         * uid of the comment object created by createComment operation
         */
        std::string commentUid;
        /**
         * determines if the service request resulted in success or failure.
         */
        bool isSuccess;
        /**
         * response message from server.
         */
        std::string message;
    };

    /**
     * Request object for deleteComment operation
     */
    struct DeleteCommentRequest
    {
        /**
         * Uid of the comment object that needs to be deleted
         */
        std::string commentObjectUid;
        /**
         * Uid of the target object whose social summary needs to be udpated
         */
        std::string targetObjectUid;
    };

    /**
     * Response object from deleteComment operation
     */
    struct DeleteCommentResponse
    {
        /**
         * Indicates whether operation was successful or not where true indicates successful
         * delete
         */
        bool success;
        /**
         * Optional message as returned by operation
         */
        std::string msg;
    };

    /**
     * Request object for fetch and set notification preferences operation.
     */
    struct NotificationPreferenceRequest
    {
        /**
         * Uid of object from client
         */
        std::string objectUid;
        /**
         * List od Object categories holding respective preferences
         */
        std::vector< S2cl::Services::Services::_2012_10::Socialcollaboration::CategoryInfo > categories;
    };

    /**
     * Server Responce for preference notification operations
     */
    struct NotificationPreferenceResponse
    {
        /**
         * Indicate if operation is successful or not
         */
        bool success;
        /**
         * Server message after operatrion if finished
         */
        std::string message;
        /**
         * List of category which holds respective perferences
         */
        std::vector< S2cl::Services::Services::_2012_10::Socialcollaboration::CategoryInfo > categories;
    };

    /**
     * Perference Name and Value pair.
     */
    struct PreferenceInfo
    {
        /**
         * Preference Name
         */
        std::string prefName;
        /**
         * Preference Value
         */
        bool prefValue;
        /**
         * display name of the preference property.
         */
        std::string prefDisplayName;
    };

    /**
     * Subscription preference request to fetch or set subscription preference operation.
     */
    struct SubscriptionPreferenceRequest
    {
        /**
         * uid of the user for whome the sauto subscription preferences have to be fetched/set.
         */
        std::string userUid;
        /**
         * categoru info
         */
        S2cl::Services::Services::_2012_10::Socialcollaboration::CategoryInfo categories;
    };

    /**
     * Server Responce for subscription preference  operations
     */
    struct SubscriptionPreferenceResponse
    {
        /**
         * denotes the operation is successful or not.
         */
        bool isSuccess;
        /**
         * success/failure message string from server.
         */
        std::string message;
        /**
         * category info
         */
        S2cl::Services::Services::_2012_10::Socialcollaboration::CategoryInfo categories;
    };

    /**
     * Response of subscribe service
     */
    struct SubscriptionResponse
    {
        /**
         * denotes success if true else failure.
         */
        bool success;
        /**
         * Response from server.
         */
        std::string message;
    };

    /**
     * Request object for all tagging related operations
     */
    struct TagRequest
    {
        /**
         * vector of tag names as string
         */
        std::vector< std::string > tagNames;
        /**
         * Uid of object on which tags need to be fetched or applied or removed
         */
        std::string objectUid;
    };

    /**
     * Response object for all tag related operations
     */
    struct TagResponse
    {
        /**
         * vector of tag names as string
         */
        std::vector< std::string > tagNames;
        /**
         * true indicating opeartion success and false indicating failure
         */
        bool success;
        /**
         * Operation execution message string
         */
        std::string msg;
    };

    /**
     * Request object for UpdateComment operation
     */
    struct UpdateCommentRequest
    {
        /**
         * UID of the commentary object which needs to be udpated
         */
        std::string commentObjectUid;
        /**
         * Attribute names versus values which need to be updated on object identified by received
         * comment object uid ob
         */
        AttributesNameValue attrNameValueMap;
    };

    /**
     * Response object from UpdateComment operation
     */
    struct UpdateCommentResponse
    {
        /**
         * Indicates whether operation was successful or not where true indicates successful
         * update
         */
        bool success;
        /**
         * Optional message as returned by the server on execution of operation
         */
        std::string msg;
    };




    /**
     * creates s2clcommentary object.
     *
     * @param request
     *        create comment request object
     *
     * @return
     *         returns response with comment uid
     *
     *
     * @exception ServiceException
     *           
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::CreateCommentResponse createComment ( const S2cl::Services::Services::_2012_10::Socialcollaboration::CreateCommentRequest&  request ) = 0;

    /**
     * delete s2clenvelopes based on object property isread=true and  iterval defined as
     * preference.
     *
     * @param request
     *        Request from client
     *
     * @return
     *         deleted s2clenvelopes
     *
     */
    virtual Teamcenter::Soa::Client::ServiceData deleteActivities ( const S2cl::Services::Services::_2012_10::Socialcollaboration::ActivityStreamRequest&  request ) = 0;

    /**
     * Delete a comment on a WSO.
     *
     * @param request
     *        request arg of type DeleteCommentRequest
     *
     * @return
     *         Delete comment operaiton response
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::DeleteCommentResponse deleteComment ( const S2cl::Services::Services::_2012_10::Socialcollaboration::DeleteCommentRequest&  request ) = 0;

    /**
     * fetch s2clenvelopes on uid provided by client.
     *
     * @param request
     *        request from client
     *
     * @return
     *         s2clenvelope  objects
     *
     */
    virtual Teamcenter::Soa::Client::ServiceData fetchActivities ( const S2cl::Services::Services::_2012_10::Socialcollaboration::ActivityStreamRequest&  request ) = 0;

    /**
     * fetch notification preferences for logged user.
     *
     * @param request
     *        Request from client
     *
     * @return
     *         List of preferences according to categories
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::NotificationPreferenceResponse fetchNotificationPreferences ( const S2cl::Services::Services::_2012_10::Socialcollaboration::NotificationPreferenceRequest&  request ) = 0;

    /**
     * ServiceData whose plainobjects consist of send to list.
     *
     * @param objectUid
     *        Uid of the object for which send to list is to be fetched
     *
     * @return
     *         user/group/role in send to list of the input object
     *
     */
    virtual Teamcenter::Soa::Client::ServiceData fetchSendToList ( const std::string&  objectUid ) = 0;

    /**
     * fetches the subscribers associcated with the input object.
     *
     * @param objectUid
     *        Uid of the object for which subscribers need to be fetched.
     *
     * @return
     *         subscribers objects associated with the input object
     *
     * @deprecated
     *         As of Teamcenter 9.1.3, this operation is deprecated and is no longer supported.
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 9.1.3, this operation is deprecated and is no longer supported."))
#endif
    virtual Teamcenter::Soa::Client::ServiceData fetchSubScribers ( const std::string&  objectUid ) = 0;

    /**
     * returnd the list of subscription preferenses names and thier values as per associated
     * group.
     *
     * @param request
     *        input parameter for getting auto subscription preferences.
     *
     * @return
     *         list of preferences ordered by group.
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::SubscriptionPreferenceResponse fetchSubscriptionPreferences ( const S2cl::Services::Services::_2012_10::Socialcollaboration::SubscriptionPreferenceRequest&  request ) = 0;

    /**
     * ServiceData whose plain objects consist of subscriptions which can consisist of users/groups/workspace
     * objects of the input object.
     *
     * @param objectUid
     *        Uid of the object for which subscribers need to be fetched
     *
     * @return
     *         subscription objects associated with the input object
     *
     * @deprecated
     *         As of Teamcenter 9.1.3, this operation is deprecated and is no longer supported.
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 9.1.3, this operation is deprecated and is no longer supported."))
#endif
    virtual Teamcenter::Soa::Client::ServiceData fetchSubscriptions ( const std::string&  objectUid ) = 0;

    /**
     * Return most trending objects in Teamcenter. Trending objects are those which have
     * most social commentary on them
     *
     * @return
     *         ServiceData whose plainobjects consist of WSO which are trending in given time frame
     *
     */
    virtual Teamcenter::Soa::Client::ServiceData fetchTrendingData (  ) = 0;

    /**
     * Gets all the tags available in the system. Alternatively returns all tags similar
     * to received argument
     *
     * @param startsWith
     *        Get all tag names starting with this value
     *
     * @return
     *         Returns array of strings
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::TagResponse getAllTags ( const std::string&  startsWith ) = 0;

    /**
     * Gets tags as string associated with current object.
     *
     * @param request
     *        Reqyest object
     *
     * @return
     *         Returns TargResponse having vector of strings
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::TagResponse getTags ( const S2cl::Services::Services::_2012_10::Socialcollaboration::TagRequest&  request ) = 0;

    /**
     * removes specific tags from object.
     *
     * @param request
     *        Request object
     *
     * @return
     *         Returns TagResponse which holds details of operation execution
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::TagResponse removeTags ( const S2cl::Services::Services::_2012_10::Socialcollaboration::TagRequest&  request ) = 0;

    /**
     * Set notification preferences.
     *
     * @param request
     *        Request object from client
     *
     * @return
     *         success status
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::NotificationPreferenceResponse setNotificationPreferences ( const S2cl::Services::Services::_2012_10::Socialcollaboration::NotificationPreferenceRequest&  request ) = 0;

    /**
     * sets the subscription preferences.
     *
     * @param input
     *        subscription preference request
     *
     * @return
     *         subscription pref response
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::SubscriptionPreferenceResponse setSubscriptionPreferences ( const S2cl::Services::Services::_2012_10::Socialcollaboration::SubscriptionPreferenceRequest&  input ) = 0;

    /**
     * sets tags on received object.
     *
     * @param request
     *        Request object
     *
     * @return
     *         returns TagResponse with success or failure boolean and message
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::TagResponse setTags ( const S2cl::Services::Services::_2012_10::Socialcollaboration::TagRequest&  request ) = 0;

    /**
     * service for subsribe/unsubscribe to social events.
     *
     * @param targetObjectUid
     *        Uid of object to be subscribed.
     *
     * @return
     *         subscribeToObject as populated by the server in response to operation execution
     *
     * @deprecated
     *         As of Teamcenter 9.1.3, this operation is deprecated and is no longer supported.
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 9.1.3, this operation is deprecated and is no longer supported."))
#endif
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::SubscriptionResponse subscribeToObject ( const std::string&  targetObjectUid ) = 0;

    /**
     * unsubscribes the object.
     *
     * @param targetObjectUid
     *        uid of the object to be unsubscribed.
     *
     * @return
     *         unsubscribeToObject as populated by the server in response to operation execution
     *
     * @deprecated
     *         As of Teamcenter 9.1.3, this operation is deprecated and is no longer supported.
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 9.1.3, this operation is deprecated and is no longer supported."))
#endif
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::SubscriptionResponse unSubscribeToObject ( const std::string&  targetObjectUid ) = 0;

    /**
     * Update plaintext and or rating value attributes of a comment.
     *
     * @param request
     *        UpdateCommentRequest object as received from the client
     *
     * @return
     *         UpdateCommentResponse as populated by the server in response to operation execution
     *
     */
    virtual S2cl::Services::Services::_2012_10::Socialcollaboration::UpdateCommentResponse updateComment ( const S2cl::Services::Services::_2012_10::Socialcollaboration::UpdateCommentRequest&  request ) = 0;


protected:
    virtual ~Socialcollaboration() {}
};
            }
        }
    }
}

#include <s2cl/services/services/Services_undef.h>
#endif

