/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWB0BOOKMARKSUBSETDATA_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWB0BOOKMARKSUBSETDATA_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Awb0BookmarkData.hxx>

#include <teamcenter/soa/client/model/ActiveworkspacebomMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAACTIVEWORKSPACEBOMMODELMNGD_API Awb0BookmarkSubsetData : public Teamcenter::Soa::Client::Model::Awb0BookmarkData
{
public:
    const Teamcenter::Soa::Client::StringVector& get_awb0OccurrenceList();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awb0BookmarkSubsetData")

   virtual ~Awb0BookmarkSubsetData();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/ActiveworkspacebomMngd_undef.h>
#endif
