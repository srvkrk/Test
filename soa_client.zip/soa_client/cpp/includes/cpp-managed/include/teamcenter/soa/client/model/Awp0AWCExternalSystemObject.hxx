/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWP0AWCEXTERNALSYSTEMOBJECT_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWP0AWCEXTERNALSYSTEMOBJECT_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/POM_object.hxx>

#include <teamcenter/soa/client/model/Aws2Mngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAAWS2MODELMNGD_API Awp0AWCExternalSystemObject : public Teamcenter::Soa::Client::Model::POM_object
{
public:
    const std::string& get_awp0ExternalSystemName();
    const std::string& get_awp0ExternalSystemURI();
    const Teamcenter::Soa::Client::StringVector& get_awp0PropertyNameList();
    const std::string& get_awp0ExternalSysObjClassName();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awp0AWCExternalSystemObject")

   virtual ~Awp0AWCExternalSystemObject();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Aws2Mngd_undef.h>
#endif
