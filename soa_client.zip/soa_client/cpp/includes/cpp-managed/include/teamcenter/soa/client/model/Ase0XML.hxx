/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_ASE0XML_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_ASE0XML_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Dataset.hxx>

#include <teamcenter/soa/client/model/Ase0activeworkspacesysengMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAASE0ACTIVEWORKSPACESYSENGMODELMNGD_API Ase0XML : public Teamcenter::Soa::Client::Model::Dataset
{
public:


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Ase0XML")

   virtual ~Ase0XML();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Ase0activeworkspacesysengMngd_undef.h>
#endif
