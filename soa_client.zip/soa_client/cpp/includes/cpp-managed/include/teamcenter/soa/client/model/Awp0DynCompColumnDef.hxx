/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWP0DYNCOMPCOLUMNDEF_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWP0DYNCOMPCOLUMNDEF_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Fnd0UIConfigurationObject.hxx>

#include <teamcenter/soa/client/model/Aws2Mngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {
                class ImanType;


class TCSOAAWS2MODELMNGD_API Awp0DynCompColumnDef : public Teamcenter::Soa::Client::Model::Fnd0UIConfigurationObject
{
public:
    const std::string& get_awp0PropertyName();
    Teamcenter::Soa::Common::AutoPtr<ImanType> get_awp0ObjectType();
    const std::string& get_awp0DynCompPropertyPath();
    const std::string& get_awp0ColumnDisplayName();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awp0DynCompColumnDef")

   virtual ~Awp0DynCompColumnDef();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Aws2Mngd_undef.h>
#endif
