/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_ATT1AROUTPUTATTRSPROVIDER_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_ATT1AROUTPUTATTRSPROVIDER_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Fnd0BaseProvider.hxx>

#include <teamcenter/soa/client/model/Att1attrtargetmgmtawMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAATT1ATTRTARGETMGMTAWMODELMNGD_API Att1AROutputAttrsProvider : public Teamcenter::Soa::Client::Model::Fnd0BaseProvider
{
public:


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Att1AROutputAttrsProvider")

   virtual ~Att1AROutputAttrsProvider();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Att1attrtargetmgmtawMngd_undef.h>
#endif
