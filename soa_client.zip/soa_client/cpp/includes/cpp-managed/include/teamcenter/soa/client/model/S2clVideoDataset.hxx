/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_S2CLVIDEODATASET_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_S2CLVIDEODATASET_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Dataset.hxx>

#include <teamcenter/soa/client/model/S2clsocialMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAS2CLSOCIALMODELMNGD_API S2clVideoDataset : public Teamcenter::Soa::Client::Model::Dataset
{
public:


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("S2clVideoDataset")

   virtual ~S2clVideoDataset();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/S2clsocialMngd_undef.h>
#endif
