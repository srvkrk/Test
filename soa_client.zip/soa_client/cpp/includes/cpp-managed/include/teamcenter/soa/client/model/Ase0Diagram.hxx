/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_ASE0DIAGRAM_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_ASE0DIAGRAM_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Awb0SavedBookmark.hxx>

#include <teamcenter/soa/client/model/Ase0activeworkspacesysengMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAASE0ACTIVEWORKSPACESYSENGMODELMNGD_API Ase0Diagram : public Teamcenter::Soa::Client::Model::Awb0SavedBookmark
{
public:
    const Teamcenter::Soa::Client::ModelObjectVector& get_Ase0DiagramRelation();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Ase0Diagram")

   virtual ~Ase0Diagram();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Ase0activeworkspacesysengMngd_undef.h>
#endif
