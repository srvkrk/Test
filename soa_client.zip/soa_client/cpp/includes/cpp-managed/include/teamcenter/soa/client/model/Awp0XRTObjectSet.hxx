/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWP0XRTOBJECTSET_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWP0XRTOBJECTSET_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/RuntimeBusinessObject.hxx>

#include <teamcenter/soa/client/model/Aws2Mngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAAWS2MODELMNGD_API Awp0XRTObjectSet : public Teamcenter::Soa::Client::Model::RuntimeBusinessObject
{
public:
    const Teamcenter::Soa::Client::ModelObjectVector& get_awp0ObjectSetRows();
    const Teamcenter::Soa::Client::ModelObjectVector& get_awp0ObjectSetColumns();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awp0XRTObjectSet")

   virtual ~Awp0XRTObjectSet();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Aws2Mngd_undef.h>
#endif
