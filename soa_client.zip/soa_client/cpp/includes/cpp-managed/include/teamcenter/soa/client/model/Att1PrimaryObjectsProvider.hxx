/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_ATT1PRIMARYOBJECTSPROVIDER_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_ATT1PRIMARYOBJECTSPROVIDER_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Fnd0BaseProvider.hxx>

#include <teamcenter/soa/client/model/Att1attrtargetmgmtawMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAATT1ATTRTARGETMGMTAWMODELMNGD_API Att1PrimaryObjectsProvider : public Teamcenter::Soa::Client::Model::Fnd0BaseProvider
{
public:


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Att1PrimaryObjectsProvider")

   virtual ~Att1PrimaryObjectsProvider();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Att1attrtargetmgmtawMngd_undef.h>
#endif
