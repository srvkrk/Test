/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWP0GATEWAYTILEREL_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWP0GATEWAYTILEREL_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/ImanRelation.hxx>

#include <teamcenter/soa/client/model/Aws2Mngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAAWS2MODELMNGD_API Awp0GatewayTileRel : public Teamcenter::Soa::Client::Model::ImanRelation
{
public:
    const std::string& get_awp0Group();
    const std::string& get_awp0SourceCollection();
    int get_awp0OrderNo();
    bool get_awp0Removed();
    int get_awp0Size();
    bool get_awp0Protected();
    bool get_awp0Live();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awp0GatewayTileRel")

   virtual ~Awp0GatewayTileRel();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Aws2Mngd_undef.h>
#endif
