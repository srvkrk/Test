/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_ATT1TARGETELEMENT_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_ATT1TARGETELEMENT_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Awb0ConditionalElement.hxx>

#include <teamcenter/soa/client/model/Att1attrtargetmgmtawMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAATT1ATTRTARGETMGMTAWMODELMNGD_API Att1TargetElement : public Teamcenter::Soa::Client::Model::Awb0ConditionalElement
{
public:


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Att1TargetElement")

   virtual ~Att1TargetElement();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Att1attrtargetmgmtawMngd_undef.h>
#endif
