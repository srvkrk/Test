/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_SAM1ASMAINTAINEDELEMENT_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_SAM1ASMAINTAINEDELEMENT_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Smr1PhysicalInstance.hxx>

#include <teamcenter/soa/client/model/Sam1asmaintainedawMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOASAM1ASMAINTAINEDAWMODELMNGD_API Sam1AsMaintainedElement : public Teamcenter::Soa::Client::Model::Smr1PhysicalInstance
{
public:


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Sam1AsMaintainedElement")

   virtual ~Sam1AsMaintainedElement();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Sam1asmaintainedawMngd_undef.h>
#endif
