/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_RET1ITEMELEMENT_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_RET1ITEMELEMENT_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Awb0ConditionalElement.hxx>

#include <teamcenter/soa/client/model/Ret1retailawMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOARET1RETAILAWMODELMNGD_API Ret1ItemElement : public Teamcenter::Soa::Client::Model::Awb0ConditionalElement
{
public:
    const Teamcenter::Soa::Client::ModelObjectVector& get_ret1ConfiguredDimensions();
    const Teamcenter::Soa::Client::ModelObjectVector& get_ret1MappedDimensions();
    const Teamcenter::Soa::Client::ModelObjectVector& get_ret1UsedDimensions();
    double get_ret1GrossUsage();
    Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  get_ret1Occurrence();
    bool get_ret1Active();
    const std::string& get_ret1ComponentName();
    bool get_ret1IsPrimary();
    const std::string& get_ret1MaterialDimension();
    double get_ret1WastePercent();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Ret1ItemElement")

   virtual ~Ret1ItemElement();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Ret1retailawMngd_undef.h>
#endif
