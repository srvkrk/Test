/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_DMA1PRINTCONFIGRUNTIME_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_DMA1PRINTCONFIGRUNTIME_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/RuntimeBusinessObject.hxx>

#include <teamcenter/soa/client/model/Dma1docmgmtawMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOADMA1DOCMGMTAWMODELMNGD_API Dma1PrintConfigRuntime : public Teamcenter::Soa::Client::Model::RuntimeBusinessObject
{
public:
    const std::string& get_dma1BannerPage();
    bool get_dma1Collate();
    const std::string& get_dma1Color();
    int get_dma1Copies();
    const std::string& get_dma1Orientation();
    const std::string& get_dma1PaperSizes();
    const std::string& get_dma1PrintConfigName();
    const std::string& get_dma1PrinterName();
    const std::string& get_dma1Range();
    double get_dma1Scale();
    const std::string& get_dma1SystemStamp();
    const std::string& get_dma1UserStamp();
    bool get_dma1StampsSupported();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Dma1PrintConfigRuntime")

   virtual ~Dma1PrintConfigRuntime();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Dma1docmgmtawMngd_undef.h>
#endif
