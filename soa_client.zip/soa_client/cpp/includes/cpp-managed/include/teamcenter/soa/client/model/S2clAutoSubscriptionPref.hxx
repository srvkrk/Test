/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_S2CLAUTOSUBSCRIPTIONPREF_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_S2CLAUTOSUBSCRIPTIONPREF_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/POM_object.hxx>

#include <teamcenter/soa/client/model/S2clsocialMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {
                class User;


class TCSOAS2CLSOCIALMODELMNGD_API S2clAutoSubscriptionPref : public Teamcenter::Soa::Client::Model::POM_object
{
public:
    bool get_s2clNewItem();
    bool get_s2clNewItemRevision();
    bool get_s2clTransferOfOwnership();
    bool get_s2clNewScalarRating();
    bool get_s2clNewExperience();
    bool get_s2clNewComment();
    bool get_s2clNewQuestion();
    bool get_s2clNewToggle();
    bool get_s2clReplyToComment();
    Teamcenter::Soa::Common::AutoPtr<User> get_s2clUser();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("S2clAutoSubscriptionPref")

   virtual ~S2clAutoSubscriptionPref();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/S2clsocialMngd_undef.h>
#endif
