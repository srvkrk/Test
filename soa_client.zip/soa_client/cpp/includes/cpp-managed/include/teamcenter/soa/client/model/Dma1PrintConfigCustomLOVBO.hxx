/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_DMA1PRINTCONFIGCUSTOMLOVBO_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_DMA1PRINTCONFIGCUSTOMLOVBO_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Fnd0ListOfValuesDynamic.hxx>

#include <teamcenter/soa/client/model/Dma1docmgmtawMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOADMA1DOCMGMTAWMODELMNGD_API Dma1PrintConfigCustomLOVBO : public Teamcenter::Soa::Client::Model::Fnd0ListOfValuesDynamic
{
public:


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Dma1PrintConfigCustomLOVBO")

   virtual ~Dma1PrintConfigCustomLOVBO();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Dma1docmgmtawMngd_undef.h>
#endif
