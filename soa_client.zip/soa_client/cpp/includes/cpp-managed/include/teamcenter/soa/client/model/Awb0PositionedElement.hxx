/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWB0POSITIONEDELEMENT_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWB0POSITIONEDELEMENT_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Awb0ConditionalElement.hxx>

#include <teamcenter/soa/client/model/ActiveworkspacebomMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAACTIVEWORKSPACEBOMMODELMNGD_API Awb0PositionedElement : public Teamcenter::Soa::Client::Model::Awb0ConditionalElement
{
public:
    const Teamcenter::Soa::Client::DoubleVector& get_awb0BoundingBox();
    const Teamcenter::Soa::Client::DoubleVector& get_awb0Transform();
    bool get_awb0IsTransformOverridden();
    const std::string& get_awb0LastSavedRefSet();
    const Teamcenter::Soa::Client::DoubleVector& get_awb0RelativeTransform();
    const std::string& get_awb0LogicalDesignator();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awb0PositionedElement")

   virtual ~Awb0PositionedElement();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/ActiveworkspacebomMngd_undef.h>
#endif
