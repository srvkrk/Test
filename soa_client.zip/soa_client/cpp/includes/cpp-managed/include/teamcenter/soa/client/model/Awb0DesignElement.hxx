/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWB0DESIGNELEMENT_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWB0DESIGNELEMENT_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Awb0PositionedElement.hxx>

#include <teamcenter/soa/client/model/ActiveworkspacebomMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAACTIVEWORKSPACEBOMMODELMNGD_API Awb0DesignElement : public Teamcenter::Soa::Client::Model::Awb0PositionedElement
{
public:


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awb0DesignElement")

   virtual ~Awb0DesignElement();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/ActiveworkspacebomMngd_undef.h>
#endif
