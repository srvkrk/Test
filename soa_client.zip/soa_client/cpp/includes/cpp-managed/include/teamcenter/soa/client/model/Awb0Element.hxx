/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWB0ELEMENT_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWB0ELEMENT_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/RuntimeBusinessObject.hxx>

#include <teamcenter/soa/client/model/ActiveworkspacebomMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAACTIVEWORKSPACEBOMMODELMNGD_API Awb0Element : public Teamcenter::Soa::Client::Model::RuntimeBusinessObject
{
public:
    Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  get_awb0Parent();
    const std::string& get_awb0Name();
    int get_awb0NumberOfChildren();
    bool get_is_modifiable();
    bool get_awb0IsStructModifiable();
    const std::string& get_awb0ElementId();
    const std::string& get_awb0ProductContextId();
    bool get_awb0IsElementSuppressed();
    Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  get_awb0Archetype();
    const std::string& get_awb0Sequence();
    const std::string& get_awb0Quantity();
    Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  get_awb0UoM();
    const std::string& get_awb0OccName();
    Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  get_awb0UnderlyingObject();
    const std::string& get_awb0DisplayedName();
    const std::string& get_awb0CopyStableId();
    const std::string& get_awb0UnderlyingObjectType();
    int get_awb0TraceLinkFlag();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awb0Element")

   virtual ~Awb0Element();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/ActiveworkspacebomMngd_undef.h>
#endif
