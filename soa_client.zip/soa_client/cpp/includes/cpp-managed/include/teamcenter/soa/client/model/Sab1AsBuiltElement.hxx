/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_SAB1ASBUILTELEMENT_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_SAB1ASBUILTELEMENT_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Smr1PhysicalInstance.hxx>

#include <teamcenter/soa/client/model/Sab1asbuiltawMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOASAB1ASBUILTAWMODELMNGD_API Sab1AsBuiltElement : public Teamcenter::Soa::Client::Model::Smr1PhysicalInstance
{
public:


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Sab1AsBuiltElement")

   virtual ~Sab1AsBuiltElement();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Sab1asbuiltawMngd_undef.h>
#endif
