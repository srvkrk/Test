/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_RET1COSTINGELEMENT_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_RET1COSTINGELEMENT_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Ret1ItemElement.hxx>

#include <teamcenter/soa/client/model/Ret1retailawMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOARET1RETAILAWMODELMNGD_API Ret1CostingElement : public Teamcenter::Soa::Client::Model::Ret1ItemElement
{
public:
    Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  get_ret1ConfiguredAgentCost();
    Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  get_ret1ConfiguredOverheadCost();
    Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  get_ret1ConfiguredVendor();
    const std::string& get_ret1ConfiguredVendorName();
    double get_ret1CostPerPiece();
    double get_ret1DutyCost();
    const Teamcenter::Soa::Common::DateTime& get_ret1EffectiveCostDate();
    const std::string& get_ret1IsLatestCost();
    const std::string& get_ret1IsLatestOverheadCost();
    double get_ret1OverheadMiscCost();
    const std::string& get_ret1OverheadMiscCostComment();
    double get_ret1RollupCost();
    double get_ret1TotalLineCost();
    Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  get_ret1UomTag();
    const Teamcenter::Soa::Client::ModelObjectVector& get_ret1ConfiguredCosts();
    int get_ret1NumConfiguredSkuCosts();
    const std::string& get_ret1SkuCostDiagnostics();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Ret1CostingElement")

   virtual ~Ret1CostingElement();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Ret1retailawMngd_undef.h>
#endif
