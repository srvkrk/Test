/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWB0CONDITIONALELEMENT_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWB0CONDITIONALELEMENT_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Awb0Element.hxx>

#include <teamcenter/soa/client/model/ActiveworkspacebomMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAACTIVEWORKSPACEBOMMODELMNGD_API Awb0ConditionalElement : public Teamcenter::Soa::Client::Model::Awb0Element
{
public:
    const std::string& get_awb0EffectivityFormula();
    const std::string& get_awb0ArchetypeEffFormula();
    const std::string& get_awb0ElementRevId();
    const Teamcenter::Soa::Client::ModelObjectVector& get_awb0ElementReleaseStatus();
    const std::string& get_awb0VariantFormula();
    const std::string& get_awb0ArchetypeName();
    const std::string& get_awb0ArchetypeRevName();
    const std::string& get_awb0ArchetypeId();
    const Teamcenter::Soa::Client::ModelObjectVector& get_awb0ArchetypeRevRelStatus();
    const Teamcenter::Soa::Common::DateTime& get_awb0ArchetypeRevReleaseDate();
    const std::string& get_awb0ArchetypeRevEffText();
    Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  get_awb0ArchetypeRevOwningUser();
    Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  get_awb0ArchetypeRevOwningGroup();
    Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  get_awb0ArchetypeRevLastModUser();
    const std::string& get_awb0ArchetypeRevId();
    const Teamcenter::Soa::Common::DateTime& get_awb0ArchetypeRevLastModDate();
    const std::string& get_awb0ArchetypeRevDescription();
    const std::string& get_awb0ArchTypeRevRelStatNames();
    const std::string& get_awb0HierarchicalNum();
    bool get_awb0IsPrecise();
    const std::string& get_awb0ElementEffId();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awb0ConditionalElement")

   virtual ~Awb0ConditionalElement();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/ActiveworkspacebomMngd_undef.h>
#endif
