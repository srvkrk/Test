/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWB0AUTOBOOKMARK_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWB0AUTOBOOKMARK_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/POM_object.hxx>

#include <teamcenter/soa/client/model/ActiveworkspacebomMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {
                class Awb0BookmarkProductData;
                class User;


class TCSOAACTIVEWORKSPACEBOMMODELMNGD_API Awb0AutoBookmark : public Teamcenter::Soa::Client::Model::POM_object
{
public:
    const std::string& get_awb0ActiveSublocation();
    Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  get_awb0OpenedObject();
    bool get_awb0PendingChanges();
    const Teamcenter::Soa::Common::DateTime& get_awb0LastSavedDateOfSBM();
    const Teamcenter::Soa::Common::DateTime& get_awb0LastAccessedDate();
    Teamcenter::Soa::Common::AutoPtr<Awb0BookmarkProductData> get_awb0ActiveProduct();
    Teamcenter::Soa::Common::AutoPtr<User> get_awb0User();
    const Teamcenter::Soa::Client::ModelObjectVector& get_awb0SelectedElementPath();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awb0AutoBookmark")

   virtual ~Awb0AutoBookmark();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/ActiveworkspacebomMngd_undef.h>
#endif
