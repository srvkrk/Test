/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_CRT1BOOKMARKARFILTERDATA_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_CRT1BOOKMARKARFILTERDATA_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Awb0BookmarkData.hxx>

#include <teamcenter/soa/client/model/Crt1validationcontractawMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOACRT1VALIDATIONCONTRACTAWMODELMNGD_API Crt1BookmarkARFilterData : public Teamcenter::Soa::Client::Model::Awb0BookmarkData
{
public:
    const std::string& get_crt1FilterInfo();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Crt1BookmarkARFilterData")

   virtual ~Crt1BookmarkARFilterData();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Crt1validationcontractawMngd_undef.h>
#endif
