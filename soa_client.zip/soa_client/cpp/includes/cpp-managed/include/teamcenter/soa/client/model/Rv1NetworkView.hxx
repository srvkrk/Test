/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_RV1NETWORKVIEW_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_RV1NETWORKVIEW_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Dataset.hxx>

#include <teamcenter/soa/client/model/RelationshipviewerMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOARELATIONSHIPVIEWERMODELMNGD_API Rv1NetworkView : public Teamcenter::Soa::Client::Model::Dataset
{
public:
    const Teamcenter::Soa::Client::StringVector& get_rv1_required_parameters();
    const Teamcenter::Soa::Client::StringVector& get_rv1_supported_inquiry();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Rv1NetworkView")

   virtual ~Rv1NetworkView();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/RelationshipviewerMngd_undef.h>
#endif
