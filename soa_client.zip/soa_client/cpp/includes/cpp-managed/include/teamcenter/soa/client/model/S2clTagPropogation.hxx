/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_S2CLTAGPROPOGATION_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_S2CLTAGPROPOGATION_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/POM_object.hxx>

#include <teamcenter/soa/client/model/S2clsocialMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAS2CLSOCIALMODELMNGD_API S2clTagPropogation : public Teamcenter::Soa::Client::Model::POM_object
{
public:
    const std::string& get_s2clParentObjectType();
    const std::string& get_s2clRelationType();
    const std::string& get_s2clSecondaryObjectType();
    int get_s2clSequenceId();
    const std::string& get_s2clTagPropagationDir();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("S2clTagPropogation")

   virtual ~S2clTagPropogation();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/S2clsocialMngd_undef.h>
#endif
