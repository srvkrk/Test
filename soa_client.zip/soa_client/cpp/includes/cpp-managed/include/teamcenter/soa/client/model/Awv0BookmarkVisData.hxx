/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWV0BOOKMARKVISDATA_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWV0BOOKMARKVISDATA_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/Awb0BookmarkData.hxx>

#include <teamcenter/soa/client/model/Awv0activeworkspacevisMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {
                class ImanFile;


class TCSOAAWV0ACTIVEWORKSPACEVISMODELMNGD_API Awv0BookmarkVisData : public Teamcenter::Soa::Client::Model::Awb0BookmarkData
{
public:
    Teamcenter::Soa::Common::AutoPtr<ImanFile> get_awv0VisBookmarkFile();


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awv0BookmarkVisData")

   virtual ~Awv0BookmarkVisData();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Awv0activeworkspacevisMngd_undef.h>
#endif
