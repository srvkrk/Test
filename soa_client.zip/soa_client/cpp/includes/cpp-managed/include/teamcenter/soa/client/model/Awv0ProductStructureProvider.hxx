/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

  Auto-generated source from Teamcenter Data Model.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SOA_CLIENT_MODEL_AWV0PRODUCTSTRUCTUREPROVIDER_HXX
#define TEAMCENTER_SOA_CLIENT_MODEL_AWV0PRODUCTSTRUCTUREPROVIDER_HXX

#include <new>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>

#include <teamcenter/soa/client/model/RuntimeBusinessObject.hxx>

#include <teamcenter/soa/client/model/Awv0activeworkspacevisMngd_exports.h>

namespace Teamcenter
{
    namespace Soa
    {
        namespace Client
        {
            namespace Model
            {


class TCSOAAWV0ACTIVEWORKSPACEVISMODELMNGD_API Awv0ProductStructureProvider : public Teamcenter::Soa::Client::Model::RuntimeBusinessObject
{
public:


   SOA_CLASS_NEW_OPERATORS_WITH_IMPL("Awv0ProductStructureProvider")

   virtual ~Awv0ProductStructureProvider();
};
            }
        }
    }
}
#include <teamcenter/soa/client/model/Awv0activeworkspacevisMngd_undef.h>
#endif
