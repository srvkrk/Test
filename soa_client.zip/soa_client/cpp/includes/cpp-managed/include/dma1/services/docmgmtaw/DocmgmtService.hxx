/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef DMA1_SERVICES_DOCMGMTAW_DOCMGMTSERVICE_HXX
#define DMA1_SERVICES_DOCMGMTAW_DOCMGMTSERVICE_HXX

#include <dma1/services/docmgmtaw/_2017_06/Docmgmt.hxx>



#include <teamcenter/soa/client/Connection.hxx>
#include <new> // for size_t
#include <teamcenter/soa/common/MemoryManager.hxx>

#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable : 4996  )
#endif

#include <dma1/services/docmgmtaw/DocMgmtAw_exports.h>

namespace Dma1
{
    namespace Services
    {
        namespace Docmgmtaw
        {
            class DocmgmtService;

/**
 * The service provides operations for Active Workspace Document Management batch print.
 * <br>
 * <br>
 * The getPrinterDefinition operation gets the printer configuration definition information
 * required for the Batch Print action from Active Workspace.
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libdma1soadocmgmtawstrongmngd.dll
 * </li>
 * <li type="disc">libdma1soadocmgmtawtypes.dll (runtime dependency)
 * </li>
 * </ul>
 */

class DMA1SOADOCMGMTAWSTRONGMNGD_API DocmgmtService
    : public Dma1::Services::Docmgmtaw::_2017_06::Docmgmt
{
public:
    static DocmgmtService* getService( Teamcenter::Soa::Client::Connection* );


    /**
     * This operation returns Print Configuration definition information from the <b>PrintConfiguration</b>
     * object defined in Teamcenter.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * The client wants to get the print configuration information required for the Batch
     * Printing action in Active Workspace.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace Document Management - Component for the template - dma1docmgmtaw
     *
     * @return
     *         The Print Configuration definition information. The following partial errors may
     *         be returned:
     *         <br>
     *         <br>
     *         515155 The PrintConfiguration class does not exist in the System
     *
     */
    virtual Dma1::Services::Docmgmtaw::_2017_06::Docmgmt::PrinterDefinitionResponse getPrinterDefinitions (  ) = 0;


    SOA_CLASS_NEW_OPERATORS_WITH_IMPL("DocmgmtService")

};
        }
    }
}


#ifdef WIN32
#pragma warning ( pop )
#endif

#include <dma1/services/docmgmtaw/DocMgmtAw_undef.h>
#endif

