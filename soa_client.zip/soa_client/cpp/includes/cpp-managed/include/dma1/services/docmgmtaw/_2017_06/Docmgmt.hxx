/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef DMA1_SERVICES_DOCMGMTAW__2017_06_DOCMGMT_HXX
#define DMA1_SERVICES_DOCMGMTAW__2017_06_DOCMGMT_HXX

#include <teamcenter/soa/client/model/Dma1PrintConfigRuntime.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <dma1/services/docmgmtaw/DocMgmtAw_exports.h>

namespace Dma1
{
    namespace Services
    {
        namespace Docmgmtaw
        {
            namespace _2017_06
            {
                class Docmgmt;

class DMA1SOADOCMGMTAWSTRONGMNGD_API Docmgmt
{
public:

    struct PrinterDefinitionResponse;

    /**
     * Printer Definition Response structure.
     */
    struct PrinterDefinitionResponse
    {
        /**
         * A list of Print Configuration Runtime business objects.  This business object contains
         * all print configuration information properties such as Print Configuration Name,
         * Printer Name, Paper Sizes, etc.
         */
        std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Dma1PrintConfigRuntime>  > printConfigurations;
        /**
         * Standard return; includes any error information.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };




    /**
     * This operation returns Print Configuration definition information from the <b>PrintConfiguration</b>
     * object defined in Teamcenter.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * The client wants to get the print configuration information required for the Batch
     * Printing action in Active Workspace.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace Document Management - Component for the template - dma1docmgmtaw
     *
     * @return
     *         The Print Configuration definition information. The following partial errors may
     *         be returned:
     *         <br>
     *         <br>
     *         515155 The PrintConfiguration class does not exist in the System
     *
     */
    virtual Dma1::Services::Docmgmtaw::_2017_06::Docmgmt::PrinterDefinitionResponse getPrinterDefinitions (  ) = 0;


protected:
    virtual ~Docmgmt() {}
};
            }
        }
    }
}

#include <dma1/services/docmgmtaw/DocMgmtAw_undef.h>
#endif

