/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef S2CL_SERVICES_SERVICES__2014_11_SOCIALCOLLABORATION_HXX
#define S2CL_SERVICES_SERVICES__2014_11_SOCIALCOLLABORATION_HXX

#include <teamcenter/soa/client/model/WorkspaceObject.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <s2cl/services/services/Services_exports.h>

namespace S2cl
{
    namespace Services
    {
        namespace Services
        {
            namespace _2014_11
            {
                class Socialcollaboration;

class S2CLSOASOCIALSTRONGMNGD_API Socialcollaboration
{
public:

    struct ScalarRatingOutput;
    struct ScalarRatingRequest;
    struct ScalarRatingResponse;

    /**
     * The retrieved scalar rating object if it exists for the requested <b>WorkspaceObject</b>
     * and <b>User</b>.
     */
    struct ScalarRatingOutput
    {
        /**
         * The clientId from the Rating Request input. This value is unchanged from the input,
         * and can be used by the caller to identify this data structure with the source input
         * data.
         */
        std::string clientId;
        /**
         * Rating value if it exists for a <b>WorkspaceObject</b> and <b>User</b>. Set to 0
         * if not rated. Set to 1 to 5 if rated.
         */
        int ratingValue;
        /**
         * The scalar rating object if the <b>WorkspaceObject</b> has been rated by requested
         * <b>User</b>.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::WorkspaceObject>  ratingObject;
        /**
         * The average rating value of all the ratings done on a <b>WorkspaceObject</b>.
         */
        double averageRating;
        /**
         * The total ratings for a <b>WorkspaceObject</b>.
         */
        int totalNumberOfRatings;
        /**
         * The total 1 star ratings for a <b>WorkspaceObject</b>.
         */
        int total1StarRatings;
        /**
         * The total 2 star ratings for a <b>WorkspaceObject</b>.
         */
        int total2StarRatings;
        /**
         * The total 3 star ratings for a <b>WorkspaceObject</b>.
         */
        int total3StarRatings;
        /**
         * The total 4 star ratings for a <b>WorkspaceObject</b>.
         */
        int total4StarRatings;
        /**
         * The total 5 star ratings for a <b>WorkspaceObject</b>.
         */
        int total5StarRatings;
    };

    /**
     * The input values needed to query a <b>S2clScalarRating</b> object.
     */
    struct ScalarRatingRequest
    {
        /**
         * A unique string supplied by the caller. This ID is used to identify return data elements
         * and partial errors associated with this input structure.
         */
        std::string clientId;
        /**
         * The <b>WorkspaceObject</b> UID string.
         */
        std::string objectUid;
        /**
         * The <b>User</b> UID string.
         */
        std::string userUid;
    };

    /**
     * List of scalar rating objects and associated data.
     */
    struct ScalarRatingResponse
    {
        /**
         * List of scalar rating objects and associated data. This provides the client application
         * a means of mapping the requested clientId to the rating object.
         */
        std::vector< S2cl::Services::Services::_2014_11::Socialcollaboration::ScalarRatingOutput > results;
        /**
         * Standard return;includes any error information.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };




    /**
     * This performs a query for a <b>S2clScalarRating</b> object given a <b>WorkspaceObject</b>
     * and <b>User</b>. If multiple <b>S2clScalarRating</b> objects are found, only the
     * most recent is returned. Returned along with the rating object is the rating value
     * and all the summary rating information properties for that <b>WorkspaceObject</b>
     * to include, total ratings, average rating, total 5 star ratings, total 4 star ratings,
     * total 3 start ratings, total 2 star ratings and total 1 star ratings.  Multiple requests
     * for scalar rating objects based on a <b>WorkspaceObject</b> and  <b>User</b> can
     * be requested by passing in a list of input structures.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param scalarRatingRequest
     *        Data used to query for an existing <b>S2clScalarRating</b> object.
     *
     * @return
     *         The <b>S2clScalarRating</b> object identified by the input parameter clientId and
     *         the summary of ratings for the <b>WorkspaceObject</b>.  Any failure will be returned
     *         with the clientId mapped to the partial errors. The following partial errors may
     *         be returned.
     *         <br>
     *         <ul>
     *         <li type="disc">146003 The "Social Scalar Rating" data could not be found.
     *         </li>
     *         </ul>
     *
     */
    virtual S2cl::Services::Services::_2014_11::Socialcollaboration::ScalarRatingResponse fetchScalarRating ( const std::vector< S2cl::Services::Services::_2014_11::Socialcollaboration::ScalarRatingRequest >& scalarRatingRequest ) = 0;


protected:
    virtual ~Socialcollaboration() {}
};
            }
        }
    }
}

#include <s2cl/services/services/Services_undef.h>
#endif

