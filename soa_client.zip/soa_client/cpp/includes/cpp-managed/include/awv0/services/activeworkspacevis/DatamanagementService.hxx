/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef AWV0_SERVICES_ACTIVEWORKSPACEVIS_DATAMANAGEMENTSERVICE_HXX
#define AWV0_SERVICES_ACTIVEWORKSPACEVIS_DATAMANAGEMENTSERVICE_HXX

#include <awv0/services/activeworkspacevis/_2015_03/Datamanagement.hxx>



#include <teamcenter/soa/client/Connection.hxx>
#include <new> // for size_t
#include <teamcenter/soa/common/MemoryManager.hxx>

#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable : 4996  )
#endif

#include <awv0/services/activeworkspacevis/ActiveWorkspaceVis_exports.h>

namespace Awv0
{
    namespace Services
    {
        namespace Activeworkspacevis
        {
            class DatamanagementService;

/**
 * This service interface provides operations that perform server side business logic
 * for the visualization integrations in Active Workspace. These operations help interrogate
 * and manipulate the Teamcenter data model for visualization data and aid with integrating
 * visualization enabled client applications with Teamcenter in a consistent way.
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libawv0soaactiveworkspacevisstrongmngd.dll
 * </li>
 * <li type="disc">libawv0soaactiveworkspacevistypes.dll (runtime dependency)
 * </li>
 * </ul>
 */

class AWV0SOAACTIVEWORKSPACEVISSTRONGMNGD_API DatamanagementService
    : public Awv0::Services::Activeworkspacevis::_2015_03::Datamanagement
{
public:
    static DatamanagementService* getService( Teamcenter::Soa::Client::Connection* );


    /**
     * This service operation is an extension to the service operation with the same name
     * located in the DataManagement Interface of the Visualization service library. This
     * extension allows the support of launching ActiveWorkspace specific objects such as
     * Awb0Element and Awb0ProductContextInfo.
     * <br>
     * <br>
     * This service generates a VVI information which is used to launch Teamcenter Visualization
     * viewers with selected objects from Teamcenter and preserve a two way communication
     * link between the viewer and the server.  This operation can return the VVI information
     * as a string buffer or as a read file ticket to a vvi/vfz file in the FMS transient
     * file volume. The "UseTransientVolume" option passed into the service via the Idinfo
     * structure controls how the VVI launch information is returned.
     * <br>
     * <br>
     * Obtaining the launch information as a string might be usefule to avoid setup and
     * use of the FMS system directly by the calling client.  It is the responsibility of
     * the client to determine how to use the returned string buffer.  For example, the
     * vvi string buffer(s) can be written out as a vvi or vfz file on the client and passed
     * to visualization, or the string buffer can be passed directly to embedded visualization
     * if using the PLMVis toolkit.
     * <br>
     * <br>
     * If returning the launch information as a FMS transient file ticket then the operation
     * requires the Teamcenter File Management System (FMS) to be installed (including FCC
     * and transient volumes) in order to retrieve the VVI file from the transient file
     * volume. When operating in this mode, the operation generates the launch file (VFZ
     * or VVI), stores it in the FMS transient volume, and returns the FMS ticket. The client
     * that initiated this operation is responsible for downloading the transient file (VVI
     * or VFZ) from the transient volume to a local file system using the transient ticket.
     * The transient (VVI or VFZ) file is consumed by the Teamcenter Visualization client.
     * The viewer establishs a server connection and loads the object(s) specified in the
     * VVI file.  Launch on multiple objects will generate a VFZ file (zip of all the vvi
     * files) and transient ticket of VFZ file would be sent to client.
     * <br>
     * <br>
     * NOTE: VVI and VFZ files are not intended to be persisted and should be generated
     * with each launch to Teamcenter Visualization. For example, the VVI format is not
     * guaranteed to be supported if the server or viewer is updated. VFZ files are used
     * if more than one object is launched at a time, while VVI files are used for single
     * objects.
     * <br>
     * <br>
     * As with the previous createLaunchInfo service operation located in the Visualization
     * library, this service supports launch on Teamcenter persistent objects like Dataset,
     * Item, ItemRevision, BOMViewRevision, BOMView. It also supports launch of selected
     * BOMLines of a configured structure from Structure Manager or BOPLines from Manufacturing
     * Process Planner, but in this case the caller must first create a VisStructureContext
     * object and make it the launched object. However with this operation you may also
     * launch objects of type Awb0Element and Awb0ProductContextInfo. See description of
     * IdInfo for details.
     * <br>
     * <br>
     * Valid launch object types and behavior such as priority order can be configured with
     * the Teamcenter Preferences VMU_Datasets, VMU_FileSearchOrder and VMU_RelationSearchOrder.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * This operation supports the mechanism of visualizing Teamcenter specific objects
     * in Teamcenter Visualization client.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace Visualization - Capability to support visualization features.
     *
     * @param idInfos
     *        A list of Teamcenter objects and related information that need to be visualized in
     *        Teamcenter Visualization. For example, if a Dataset is launched, then information
     *        about its Item, ItemRevision and type of operation, including any additional information
     *        can be provided.
     *
     * @param serverInfo
     *        Server information for the viewer to connect to the server. Contains protocol, server
     *        URL, connection mode of the server and any other additional server relevant key value
     *        pair.
     *
     * @param userDataAgentInfo
     *        The information about the client that initiated the launch (e.g., application name,
     *        application version, and any other additional client application relevant key value
     *        pair).
     *
     * @param sessionInfo
     *        The session information for the viewer to connect to the session. Includes the session
     *        discriminator and any other additional session relevant key value pair.
     *
     * @return
     *         VVI file data as a string buffer or FMS file ticket for the request objects. The
     *         following partial errors may be returned:
     *         <br>
     *         208031: Launch request is not valid.
     *         <br>
     *         208013: The selected object is invalid for the launch operation;
     *         <br>
     *         208012: Launch file generation failed.
     *
     */
    virtual Awv0::Services::Activeworkspacevis::_2015_03::Datamanagement::LaunchInfoResponse createLaunchInfo ( const std::vector< Awv0::Services::Activeworkspacevis::_2015_03::Datamanagement::IdInfo >& idInfos,
        const Awv0::Services::Activeworkspacevis::_2015_03::Datamanagement::ServerInfo&  serverInfo,
        const Awv0::Services::Activeworkspacevis::_2015_03::Datamanagement::UserAgentDataInfo&  userDataAgentInfo,
        const Awv0::Services::Activeworkspacevis::_2015_03::Datamanagement::SessionInfo&  sessionInfo ) = 0;


    SOA_CLASS_NEW_OPERATORS_WITH_IMPL("DatamanagementService")

};
        }
    }
}


#ifdef WIN32
#pragma warning ( pop )
#endif

#include <awv0/services/activeworkspacevis/ActiveWorkspaceVis_undef.h>
#endif

