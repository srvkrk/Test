/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef AWV0_SERVICES_ACTIVEWORKSPACEVIS__2015_03_DATAMANAGEMENT_HXX
#define AWV0_SERVICES_ACTIVEWORKSPACEVIS__2015_03_DATAMANAGEMENT_HXX

#include <teamcenter/soa/client/model/Item.hxx>
#include <teamcenter/soa/client/model/ItemRevision.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <awv0/services/activeworkspacevis/ActiveWorkspaceVis_exports.h>

namespace Awv0
{
    namespace Services
    {
        namespace Activeworkspacevis
        {
            namespace _2015_03
            {
                class Datamanagement;

class AWV0SOAACTIVEWORKSPACEVISSTRONGMNGD_API Datamanagement
{
public:

    struct IdInfo;
    struct LaunchInfoResponse;
    struct OptionInfo;
    struct ServerInfo;
    struct SessionInfo;
    struct UserAgentDataInfo;

    /**
     * Map of key-value name pairs, each of type std::string.
     */
    typedef std::map< std::string, std::string > KeyValueMap;

    /**
     * A map of option key names to OptionInfo structures. These options are used to control
     * the creation of the launch file in some way.
     * <br>
     */
    typedef std::map< std::string, OptionInfo > OptionsMap;

    /**
     * A map containing client ids or additional Teamcenter object UID  and vviStringBuffer
     * as key/value pairs.
     */
    typedef std::map< std::string, std::string > VVIStringBufferOutputMap;

    /**
     * This structure holds information about the object(s) that will be launched to the
     * viewer. It may contain addtional option information that can affect how the VVI is
     * to be generated.
     */
    struct IdInfo
    {
        /**
         * The business object to be laucnhed. Launched object could be of type Item, ItemRevision,
         * Dataset, BOMView, BOMViewRevision or Awb0ProductContextInfo. The business object
         * will be resolved by the server in some cases (e.g. Item or ItemRevision launch) to
         * a directly launchable visualization object (such as a DirectModel Dataset or BOMViewRevision).
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  launchedObject;
        /**
         * The parent or containing Item of the launched object.  If this is not provided, the
         * server will attempt to identify the parent if it can. If the parent information cannot
         * be identified, this will not result in an error condition. The parent Item information
         * will simply not be passed to the visualization client, which could affect what features
         * are available in the client.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Item>  item;
        /**
         * The parent or containing ItemRevision of the launched object. If this is not known,
         * the server will attempt to identify the parent if it can. If the parent information
         * cannot be identified, this will not result in an error condition. The parent ItemRevision
         * information will simply not be passed to the visualization client, which could affect
         * what features are available in the client.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::ItemRevision>  itemRev;
        /**
         * The list of selected occurrences being launched. These occurrences may be of type
         * BOMLine or Awb0Element. When this vector is non-empty then the launchedObject field
         * of the IdInfo structure must contain an object that defines the configuration state
         * for the occurrences. For example, the configuration object is of type Awb0ProductContextInfo
         * when the occurrences are of type Awb0Element. The configuration object is of type
         * BOMWindow when the occurrences are of type BOMLine.
         */
        std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  > occurrencesList;
        /**
         * Map of option names to OptionInfo structures. These options are used to control the
         * creation of the launch information in some way.
         * <br>
         * <br>
         * Current options include:
         * <br>
         * <br>
         * "CreateVisSC" - "True" or "False"
         * <br>
         * Informs the service to create a VisStructureContext object based on the laucnhedObject
         * and occurrenceList field of the IdInfo structure.
         * <br>
         * <br>
         * "OVERRIDE_VisDoc_Type" - some replacement string
         * <br>
         * Directs the service to replace the value of the VisDoc_Type key in the launch
         * file with the specified string.
         * <br>
         * <br>
         * "TransientDoc" - "True" or "False"
         * <br>
         * Indicates whether the launched object is to be considered transient by the viewer.
         * Transient objects are normally deleted when the viewer is finished with the document
         * used to open the launched object.
         * <br>
         * <br>
         * "Operation" - "open", "insert", "merge", "interop"
         * <br>
         * Informs the viewer on what type of launch operation is being requested.
         * <br>
         * <br>
         * "OperationStructure" - "Dynamic", "Static", "Preference", "Ask"
         * <br>
         * Informs the viewer on what type of structure launch is being requested.
         * <br>
         * <br>
         * "UseTransientVolume" - "True" or "False"
         * <br>
         * Determines how the service is to return the launch information. If "True" then
         * the launch information is written to a file in the transient volume and a FMS ticket
         * is returned in the ticket field of the LaunchInfoResponce structure. If "False" then
         * the launch information is written to a string and that string is placed into the
         * vviStrBufferOutputMap field of the LaunchInfoResponce structure. In the later case,
         * the key name to be used is found in the "ClientId" option that is now required.
         * <br>
         * <br>
         * "ClientId" - a unique string used to identify this call to the service.
         * <br>
         * Is a required option when the "TransientVolume" option is "False".
         * <br>
         * <br>
         * "Client" - string used to identify the client calling this service
         * <br>
         * &nbsp;&nbsp;&nbsp;&nbsp;Currently the only value being recognized is "AW", which
         * indicates that ActiveWorkspace is the desired client viewer.
         * <br>
         * <br>
         */
        OptionsMap createOptions;
        /**
         * This is a generic mechanism for putting additional key/value pairs into the output
         * launch information. This data is considered opaque to the service and the key/value
         * pairs are simply output into the VVI launch information.
         */
        KeyValueMap idAdditionalInfo;
    };

    /**
     * The output response structure for the createLaunchInfo () operation.
     */
    struct LaunchInfoResponse
    {
        /**
         * Holds a FMS transient file ticket for the launch information written to the VVI file.
         * <br>
         * This member is valid only when the "UseTransientVolume" option from the IdInfo input
         * structure was set to "True".
         */
        std::string ticket;
        /**
         * The map of clientId string to the VVI launch information string buffer(string/string).
         * This member is valid only when the "UseTransientVolume" option from the IdInfo input
         * structure was set to "False". Also requires the "ClientId" option from the IdInfo
         * input structure to be present and set to non-zero length string. The value of the
         * "ClientId" option is used as the key to this map.
         */
        VVIStringBufferOutputMap vviStrBuffersOutputMap;
        /**
         * SOA Framework object containing error information. In cases where objects cannot
         * be launched, error message, codes will be mapped to respective object id in the list
         * of partial errors.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * This structure contains the value of the for a given launch file option and a flag
     * indicating whether the option key name and value should be written to the launch
     * file.
     */
    struct OptionInfo
    {
        /**
         * The value for the given option.
         */
        std::string optionValue;
        /**
         * A flag indicating whether the option key/value pair should also be written into the
         * launch file.
         */
        bool includeInLaunchFile;
    };

    /**
     * This structure holds the basic information for Teamcenter Visualization to connect
     * to the server.
     */
    struct ServerInfo
    {
        /**
         * A required parameter referencing the protocol type for connection to the server.
         * Use http for standard 4 tier connections, and iiop for 2 tier deployments.
         */
        std::string protocol;
        /**
         * A required parameter referencing the URL to connect to the server.
         */
        std::string hostpath;
        /**
         * A required parameter referencing the servermode that controls how the connection
         * to the server is made: 2 for two tier. 4 for four tier.
         */
        int servermode;
        /**
         * An optional parameter referencing the additional information of the server in form
         * of key/value pair (if any).
         */
        KeyValueMap serverAdditionalInfo;
    };

    /**
     * This structure holds the information about the session information of the client
     * application from where the launch operation was initiated.
     */
    struct SessionInfo
    {
        /**
         * Client/Server session discriminator to connect to existing specified session.  This
         * allows the viewer application to share an existing server process session with the
         * client that initiated the launch. If this is not specified, the viewer will present
         * a login prompt.
         */
        std::string sessionDescriminator;
        /**
         * Map of option names to OptionInfo structures. These options are used to control the
         * creation of the launch information in some way.
         * <br>
         * <br>
         * Current options include:
         * <br>
         * <br>
         * "UseTransientVolume" - "True" or "False"
         * <br>
         * Determines how the service is to return the launch information. If "True" then
         * the launch information is written to a file in the transient volume and a FMS ticket
         * is returned in the ticket field of the LaunchInfoResponce structure. If "False" then
         * the launch information is written to a string and that string is placed into the
         * vviStrBufferOutputMap field of the LaunchInfoResponce structure. In the later case,
         * the key name to be used is found in the "ClientId" option that is now required.
         * <br>
         */
        OptionsMap sessionOptions;
        /**
         * An optional parameter referencing the additional information of the session in form
         * of key/value pair (if any).
         */
        KeyValueMap sessionAdditionalInfo;
    };

    /**
     * This structure holds the information about the client application that initiated
     * the launch.
     */
    struct UserAgentDataInfo
    {
        /**
         * An optional parameter referencing the client who initiates the launch.
         */
        std::string userApplication;
        /**
         * An optional parameter referencing the version of the client that initiated launch.
         */
        std::string userAppVersion;
        /**
         * An optional parameter referencing the additional information of client application
         * in form of key/value pair (if any).
         */
        KeyValueMap userAdditionalInfo;
    };




    /**
     * This service operation is an extension to the service operation with the same name
     * located in the DataManagement Interface of the Visualization service library. This
     * extension allows the support of launching ActiveWorkspace specific objects such as
     * Awb0Element and Awb0ProductContextInfo.
     * <br>
     * <br>
     * This service generates a VVI information which is used to launch Teamcenter Visualization
     * viewers with selected objects from Teamcenter and preserve a two way communication
     * link between the viewer and the server.  This operation can return the VVI information
     * as a string buffer or as a read file ticket to a vvi/vfz file in the FMS transient
     * file volume. The "UseTransientVolume" option passed into the service via the Idinfo
     * structure controls how the VVI launch information is returned.
     * <br>
     * <br>
     * Obtaining the launch information as a string might be usefule to avoid setup and
     * use of the FMS system directly by the calling client.  It is the responsibility of
     * the client to determine how to use the returned string buffer.  For example, the
     * vvi string buffer(s) can be written out as a vvi or vfz file on the client and passed
     * to visualization, or the string buffer can be passed directly to embedded visualization
     * if using the PLMVis toolkit.
     * <br>
     * <br>
     * If returning the launch information as a FMS transient file ticket then the operation
     * requires the Teamcenter File Management System (FMS) to be installed (including FCC
     * and transient volumes) in order to retrieve the VVI file from the transient file
     * volume. When operating in this mode, the operation generates the launch file (VFZ
     * or VVI), stores it in the FMS transient volume, and returns the FMS ticket. The client
     * that initiated this operation is responsible for downloading the transient file (VVI
     * or VFZ) from the transient volume to a local file system using the transient ticket.
     * The transient (VVI or VFZ) file is consumed by the Teamcenter Visualization client.
     * The viewer establishs a server connection and loads the object(s) specified in the
     * VVI file.  Launch on multiple objects will generate a VFZ file (zip of all the vvi
     * files) and transient ticket of VFZ file would be sent to client.
     * <br>
     * <br>
     * NOTE: VVI and VFZ files are not intended to be persisted and should be generated
     * with each launch to Teamcenter Visualization. For example, the VVI format is not
     * guaranteed to be supported if the server or viewer is updated. VFZ files are used
     * if more than one object is launched at a time, while VVI files are used for single
     * objects.
     * <br>
     * <br>
     * As with the previous createLaunchInfo service operation located in the Visualization
     * library, this service supports launch on Teamcenter persistent objects like Dataset,
     * Item, ItemRevision, BOMViewRevision, BOMView. It also supports launch of selected
     * BOMLines of a configured structure from Structure Manager or BOPLines from Manufacturing
     * Process Planner, but in this case the caller must first create a VisStructureContext
     * object and make it the launched object. However with this operation you may also
     * launch objects of type Awb0Element and Awb0ProductContextInfo. See description of
     * IdInfo for details.
     * <br>
     * <br>
     * Valid launch object types and behavior such as priority order can be configured with
     * the Teamcenter Preferences VMU_Datasets, VMU_FileSearchOrder and VMU_RelationSearchOrder.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * This operation supports the mechanism of visualizing Teamcenter specific objects
     * in Teamcenter Visualization client.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace Visualization - Capability to support visualization features.
     *
     * @param idInfos
     *        A list of Teamcenter objects and related information that need to be visualized in
     *        Teamcenter Visualization. For example, if a Dataset is launched, then information
     *        about its Item, ItemRevision and type of operation, including any additional information
     *        can be provided.
     *
     * @param serverInfo
     *        Server information for the viewer to connect to the server. Contains protocol, server
     *        URL, connection mode of the server and any other additional server relevant key value
     *        pair.
     *
     * @param userDataAgentInfo
     *        The information about the client that initiated the launch (e.g., application name,
     *        application version, and any other additional client application relevant key value
     *        pair).
     *
     * @param sessionInfo
     *        The session information for the viewer to connect to the session. Includes the session
     *        discriminator and any other additional session relevant key value pair.
     *
     * @return
     *         VVI file data as a string buffer or FMS file ticket for the request objects. The
     *         following partial errors may be returned:
     *         <br>
     *         208031: Launch request is not valid.
     *         <br>
     *         208013: The selected object is invalid for the launch operation;
     *         <br>
     *         208012: Launch file generation failed.
     *
     */
    virtual Awv0::Services::Activeworkspacevis::_2015_03::Datamanagement::LaunchInfoResponse createLaunchInfo ( const std::vector< Awv0::Services::Activeworkspacevis::_2015_03::Datamanagement::IdInfo >& idInfos,
        const Awv0::Services::Activeworkspacevis::_2015_03::Datamanagement::ServerInfo&  serverInfo,
        const Awv0::Services::Activeworkspacevis::_2015_03::Datamanagement::UserAgentDataInfo&  userDataAgentInfo,
        const Awv0::Services::Activeworkspacevis::_2015_03::Datamanagement::SessionInfo&  sessionInfo ) = 0;


protected:
    virtual ~Datamanagement() {}
};
            }
        }
    }
}

#include <awv0/services/activeworkspacevis/ActiveWorkspaceVis_undef.h>
#endif

