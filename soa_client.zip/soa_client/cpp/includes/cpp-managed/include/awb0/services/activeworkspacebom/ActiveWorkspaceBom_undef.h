/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/
#include <common/library_indicators.h>


#if !defined(EXPORTLIBRARY)
#   error EXPORTLIBRARY is not defined
#endif

#undef EXPORTLIBRARY

#if !defined(IPLIB)
#   error IPLIB is not defined
#endif

#undef AWB0SOAACTIVEWORKSPACEBOMSTRONGMNGD_API
#undef AWB0SOAACTIVEWORKSPACEBOMSTRONGMNGDEXPORT
#undef AWB0SOAACTIVEWORKSPACEBOMSTRONGMNGDGLOBAL
#undef AWB0SOAACTIVEWORKSPACEBOMSTRONGMNGDPRIVATE

