/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef AWB0_SERVICES_ACTIVEWORKSPACEBOM_OCCURRENCEMANAGEMENTCADSERVICE_HXX
#define AWB0_SERVICES_ACTIVEWORKSPACEBOM_OCCURRENCEMANAGEMENTCADSERVICE_HXX

#include <awb0/services/activeworkspacebom/_2015_10/Occurrencemanagementcad.hxx>



#include <teamcenter/soa/client/Connection.hxx>
#include <new> // for size_t
#include <teamcenter/soa/common/MemoryManager.hxx>

#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable : 4996  )
#endif

#include <awb0/services/activeworkspacebom/ActiveWorkspaceBom_exports.h>

namespace Awb0
{
    namespace Services
    {
        namespace Activeworkspacebom
        {
            class OccurrencemanagementcadService;

/**
 * The OccurrenceManagementCad service exposes operations to create <b>BOMWindow</b>
 * objects from object types used in Active Workspace.  The operations in this service
 * are not intended for use by Active Workspace directly.
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libawb0soaactiveworkspacebomstrongmngd.dll
 * </li>
 * <li type="disc">libawb0soaactiveworkspacebomtypes.dll (runtime dependency)
 * </li>
 * </ul>
 */

class AWB0SOAACTIVEWORKSPACEBOMSTRONGMNGD_API OccurrencemanagementcadService
    : public Awb0::Services::Activeworkspacebom::_2015_10::Occurrencemanagementcad
{
public:
    static OccurrencemanagementcadService* getService( Teamcenter::Soa::Client::Connection* );


    /**
     * This operation creates BOM windows (<b>BOMWindow</b> objects) from Active Workspace
     * saved bookmarks (<b>Awb0SavedBookmark</b> objects).  A BOM window will be created
     * for each product contained within each saved bookmark.  With each <b>BOMwindow</b>
     * there will be a corresponding list of <b>BOMLline</b> objects that identify any selections
     * included in the saved bookmark.  The product of the <b>Awb0ProductContextInfo</b>
     * that is associated with each saved bookmark will be set as the top line of the <b>BOMWindow</b>.
     * The product contexts also contain information that will be set on the BOM window
     * when it is created.  This information may include:
     * <br>
     * <br>
     * <ul>
     * <li type="disc">Revision rule
     * </li>
     * <li type="disc">End item
     * </li>
     * <li type="disc">Effective date
     * </li>
     * <li type="disc">Effective unit
     * </li>
     * <li type="disc">Saved Variant rule
     * </li>
     * </ul>
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * The user has found a saved bookmark in the Active Context Experience.  The user wants
     * to open the contents of the bookmark in the CAD application.  The Active Workspace
     * Client communicates saved bookmark details to the CAD application, which then uses
     * it as an input to this operation to create BOM windows.
     * <br>
     * <br>
     * When <b>BOMWindow</b> objects are needed but only <b>Awb0SavedBookmark</b> objects
     * are accessible, this operation will use the necessary information from the <b>Awb0SavedBookmark</b>
     * objects to provide corresponding <b>BOMWindow</b> objects.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace BOM - Active Workspace BOM services.
     *
     * @param savedBookmarks
     *        The <b>Awb0SavedBookmark</b> objects from which <b>BOMWindow</b> objects will be
     *        created.
     *
     * @param expandToSelection
     *        Flag that when true will cause the operation to process selections, returning the
     *        BOM lines of the selected occurrences.
     *
     * @return
     *         A map of input <b>Awb0SavedBookmark</b> objects to a list of <b>BOMWindowAndSelections</b>
     *         objects.
     *         <br>
     *         <br>
     *         The following error originates from this operation:
     *         <br>
     *         <br>
     *         <ul>
     *         <li type="disc">199001: A BOM Window could not be created from the saved bookmark.
     *         Please contact the system administrator to report this error.
     *         </li>
     *         </ul>
     *         <br>
     *         <br>
     *         Each selection corresponds to a user selected occurrence in the "Active Content Experience"
     *         (ACE) application in Active Workspace.  This SOA operation performs the BOM expansions
     *         to return the list of the <b>BOMLine</b> objects of the selected occurrences.  The
     *         BOM expansions will be limited only on the branches of the structure where the selected
     *         occurrences are and the expansions will only be up to the selected nodes.
     *
     */
    virtual Awb0::Services::Activeworkspacebom::_2015_10::Occurrencemanagementcad::SavedBookmarksBOMWindowsResponse createBOMWindowsFromBookmarks ( const std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0SavedBookmark>  >& savedBookmarks,
        bool expandToSelection ) = 0;

    /**
     * This operation creates BOM windows (<b>BOMWindow</b> objects) from Active Workspace
     * product contexts (<b>Awb0ProductContextInfo</b> objects).  One BOM window will be
     * created for each product context.  The product of the <b>Awb0ProductContextInfo</b>
     * will be set as the top line of the <b>BOMWindow</b>.  With each <b>BOMWindow</b>
     * there will be a corresponding list of <b>BOMLine</b> objects that identify any selections
     * included in the product context information.  The product context contains configuration
     * data that will be set on the BOM Window when it is created.  This information may
     * include:
     * <br>
     * <br>
     * <ul>
     * <li type="disc">Revision rule
     * </li>
     * <li type="disc">End item
     * </li>
     * <li type="disc">Effective date
     * </li>
     * <li type="disc">Effective unit
     * </li>
     * <li type="disc">Saved Variant rule
     * </li>
     * </ul>
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * The user opens an Item-BVR assembly in the Active Content Experience and makes changes
     * to the <b>RevisionRule</b> or other configuration parameters.  Then, the user opens
     * it in the CAD application.  The Active Workspace client communicates the <b>Awb0ProductContextInfo</b>
     * to the CAD application, which then uses it as an input to this operation to create
     * the <b>BOMWindow</b>.
     * <br>
     * <br>
     * When <b>BOMWindow</b> objects are needed but only <b>Awb0ProductContextInfo</b> objects
     * are accessible, this operation will use the necessary information from the <b>Awb0ProductContextInfo</b>
     * objects to create corresponding <b>BOMWindow</b> objects.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace BOM - Active Workspace BOM services.
     *
     * @param productContextInfos
     *        List of <b>Awb0ProductContextInfo</b> from which <b>BOMWindow</b> objects will be
     *        created.
     *
     * @param expandToSelection
     *        Flag that when true will cause the operation to process selections, returning the
     *        BOM lines of the selected occurrences.
     *
     * @return
     *         A map of input <b>Awb0ProductContextInfo</b> to <b>BOMWindowAndSelections</b> objects.
     *         <br>
     *         <br>
     *         The following error originates from this operation:
     *         <br>
     *         <br>
     *         <ul>
     *         <li type="disc">199002: A BOM Window could not be created from the product context.
     *         Please contact the system administrator to report this error.
     *         </li>
     *         </ul>
     *         <br>
     *         <br>
     *         Each selection corresponds to a user selected occurrence in the "Active Content Experience"
     *         (ACE) application in Active Workspace.  This SOA operation performs the BOM expansions
     *         to return the list of the <b>BOMLine</b> objects of the selected occurrences.  The
     *         BOM expansions will be limited only on the branches of the structure where the selected
     *         occurrences are and the expansions will only be up to the selected nodes.
     *
     */
    virtual Awb0::Services::Activeworkspacebom::_2015_10::Occurrencemanagementcad::ProductContextBOMWindowResponse createBOMWindowsFromContexts ( const std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0ProductContextInfo>  >& productContextInfos,
        bool expandToSelection ) = 0;


    SOA_CLASS_NEW_OPERATORS_WITH_IMPL("OccurrencemanagementcadService")

};
        }
    }
}


#ifdef WIN32
#pragma warning ( pop )
#endif

#include <awb0/services/activeworkspacebom/ActiveWorkspaceBom_undef.h>
#endif

