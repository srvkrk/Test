/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef ASE0_SERVICES_ACTIVEWORKSPACESYSENG__2015_10_DIAGRAMMANAGEMENT_HXX
#define ASE0_SERVICES_ACTIVEWORKSPACESYSENG__2015_10_DIAGRAMMANAGEMENT_HXX

#include <ase0/services/activeworkspacesyseng/_2012_10/Diagrammanagement.hxx>
#include <ase0/services/activeworkspacesyseng/_2014_11/Diagrammanagement.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <ase0/services/activeworkspacesyseng/ActiveWorkspaceSysEng_exports.h>

namespace Ase0
{
    namespace Services
    {
        namespace Activeworkspacesyseng
        {
            namespace _2015_10
            {
                class Diagrammanagement;

class ASE0SOAACTIVEWORKSPACESYSENGSTRONGMNGD_API Diagrammanagement
{
public:

    struct DiagramLegendData1;
    struct DiagramLegendResponse1;
    struct FilterData1;

    /**
     * Structure represents the output data of the operation.
     */
    struct DiagramLegendData1
    {
        /**
         * The name of the Legend.
         */
        std::string name;
        /**
         * The localized display name of the Legend.
         */
        std::string displayName;
        /**
         * The default layout of the view. The values are: <i>Incremental, Orthographic, Tree,
         * Left To Right</i>, and <i>Right To Left</i>.  This value is utilized by the Graph
         * component.
         */
        std::string defaultLayout;
        /**
         * The list of data of different types.
         */
        std::vector< Ase0::Services::Activeworkspacesyseng::_2015_10::Diagrammanagement::FilterData1 > groupData;
    };

    /**
     * Structure represents the output parameters of the operation.
     */
    struct DiagramLegendResponse1
    {
        /**
         * The list of DiagramLegendData1 structures.
         */
        std::vector< Ase0::Services::Activeworkspacesyseng::_2015_10::Diagrammanagement::DiagramLegendData1 > legendData;
        /**
         * The information about how a Node or an Edge is to be rendered based on the type it
         * represents is defined in this XML. For instance, a Node representing the type <b>Ase0FunctionalElement</b>
         * is shown as a Tile.  This XML is read from the dataset specified in the preference
         * <i>SE_diagram_presentation_rules_file_name</i>. A sample entry in the XML files is
         * as follows.
         * <br>
         * <b>&lt;PresentationRule type="Node" styleId="FunctionalStyle"&gt;
         * <br>
         * &lt;Conditions operator="and"&gt;
         * <br>
         * &lt;Type value="Ase0FunctionalElement" operator="typeOf" /&gt;
         * <br>
         * &lt;/Conditions&gt;
         * <br>
         * &lt;/PresentationRule&gt;</b>
         */
        std::string presentationRulesXML;
        /**
         * The information about shapes assigned to types For instance, to show Traceability
         * as a line on the diagram, the parameters of the line are defined in the XML, like
         * lineWidth, lineStyle, lineColor. This XML is read from the dataset specified in the
         * preference <i>SE_diagram_presentation_styles_file_name</i>. A sample entry in the
         * XML file is as follows.
         * <br>
         * <b>&lt;NodePresentation id="FunctionalStyle"&gt;
         * <br>
         * &lt;parameter name="shape"&gt;&lt;value&gt;Tile&lt;/value&gt;&lt;/parameter&gt;
         * <br>
         * &lt;/NodePresentation&gt;</b>
         */
        std::string presentationStylesXML;
        /**
         * The Service Data.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * Structure for representing information of a filter, including filter name, group
     * type of filter data, RGB values to color the legend of the filter at client side.
     * It's used in structure GraphGroup.
     */
    struct FilterData1
    {
        /**
         * The name of the filter. For objects, the values are <b>Logical</b>, <b>Function</b>,
         * <b>Requirement</b> and <b>Items</b> and for relations, the values are Connectivity,
         * Traceability and Structure.
         */
        std::string name;
        /**
         * The display name of the filter.
         */
        std::string displayName;
        /**
         * The object or relation type information to be shown in the legend.
         */
        std::vector< Ase0::Services::Activeworkspacesyseng::_2014_11::Diagrammanagement::TypeData1 > types;
        /**
         * The color used for legend of this filter on the client.
         */
        Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::RGBValue color;
        /**
         * The type name of group to be added in Legend.
         */
        std::string groupType;
        /**
         * The scope of the filter for creation of object for any of given types. Current valid
         * values for this field are <i>Global, Context</i>.  For instance, <b>Trace Link</b>
         * category in Relations Legend with value Context allows creating occurrence <b>Trace
         * Link</b> in given structure context. This XML is read from the dataset specified
         * in the preference <i>SE_diagram_legend_configuration_file_name</i>. A sample entry
         * in the XML files is as follows.
         * <br>
         * <b>&lt;parameterSet name="OccurrenceTraceability" scopeFilter="Context"&gt;
         * <br>
         * &lt;typesForCreation&gt;
         * <br>
         * &lt;type&gt;FND_TraceLink&lt;/type&gt;
         * <br>
         * &lt;/typesForCreation&gt;
         * <br>
         * &lt;/parameterSet&gt;</b>
         */
        std::string scopeFilter;
    };




    /**
     * This operation returns a localized list of objects, relation and port type names
     * which are used to navigate the data on a diagram. This list of object type names
     * is the filter which is applied during the diagram navigation. The type data returns
     * the flag to mention indicate if the user has access to author the object type or
     * not. Filter data returns additional filter which denotes scope for creation of object
     * of given types.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * An Active Workspace user selects an object in the Architecture Modeler tab and clicks
     * on the expansion link to expand its relations. System responds by building new shapes
     * for the related objects and relations. User clicks to open the legends section where
     * he/she sees the localized names of the objects and relations. User then selects the
     * types of objects and relations from the legends section to be filtered out. System
     * responds by removing the corresponding shapes from the tab.
     * <br>
     * User enters edit mode and selects an object type in the legend and clicks on the
     * Architecture Modeler tab. System responds by creating an object of the selected type
     * and drawing a shape on the tab. User will see object type in legend as disabled if
     * user does not have access create or edit the type.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param viewName
     *        The name of the view for which the legend is to be populated.
     *
     * @return
     *         A list of supported objects and relation types. If there is no matching data for
     *         the input view, empty list will be returned. The following partial errors may be
     *         returned. 124003&nbsp;&nbsp;&nbsp;&nbsp;  if the configuration file does not exist
     *         on the server.
     *
     */
    virtual Ase0::Services::Activeworkspacesyseng::_2015_10::Diagrammanagement::DiagramLegendResponse1 getDiagramLegend4 ( const std::string&  viewName ) = 0;


protected:
    virtual ~Diagrammanagement() {}
};
            }
        }
    }
}

#include <ase0/services/activeworkspacesyseng/ActiveWorkspaceSysEng_undef.h>
#endif

