/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef ASE0_SERVICES_ACTIVEWORKSPACESYSENG_DIAGRAMMANAGEMENTSERVICE_HXX
#define ASE0_SERVICES_ACTIVEWORKSPACESYSENG_DIAGRAMMANAGEMENTSERVICE_HXX

#include <ase0/services/activeworkspacesyseng/_2012_10/Diagrammanagement.hxx>
#include <ase0/services/activeworkspacesyseng/_2014_11/Diagrammanagement.hxx>
#include <ase0/services/activeworkspacesyseng/_2015_10/Diagrammanagement.hxx>



#include <teamcenter/soa/client/Connection.hxx>
#include <new> // for size_t
#include <teamcenter/soa/common/MemoryManager.hxx>

#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable : 4996  )
#endif

#include <ase0/services/activeworkspacesyseng/ActiveWorkspaceSysEng_exports.h>

namespace Ase0
{
    namespace Services
    {
        namespace Activeworkspacesyseng
        {
            class DiagrammanagementService;

/**
 * Diagram Management Service
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libase0soaactiveworkspacesysengstrongmngd.dll
 * </li>
 * <li type="disc">libase0soaactiveworkspacesysengtypes.dll (runtime dependency)
 * </li>
 * </ul>
 */

class ASE0SOAACTIVEWORKSPACESYSENGSTRONGMNGD_API DiagrammanagementService
    : public Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement,
             public Ase0::Services::Activeworkspacesyseng::_2014_11::Diagrammanagement,
             public Ase0::Services::Activeworkspacesyseng::_2015_10::Diagrammanagement
{
public:
    static DiagrammanagementService* getService( Teamcenter::Soa::Client::Connection* );


    /**
     * This operation creates a Awb0Connection  object and its underlying PSConnection object
     * to connect the given Awb0Element objects and their underlying  ItemRevision objects.
     * It also creates Awb0Interface objects based on the preference value.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param input
     *        Structures which hold the required information to create connections between the
     *        given occurrences.
     *
     * @return
     *         A  list of CreateConnectionsResponseData structures, one for each successfully created
     *         Awb0Connection object  corresponding to each input and the ServiceData. Any failure
     *         will be returned with clientId mapped to  error message in the ServiceData list of
     *         partial errors.  Following error codes are returned in the ServiceData. 1.  124001
     *         If there is an internal error during creation of the connection. 2. 124002  If there
     *         is  no suitable adapter found to handle this input object.
     *
     */
    virtual Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::CreateConnectionsResponse createConnections ( const std::vector< Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::CreateConnectionsInputData >& input ) = 0;

    /**
     * This operation creates a FND_TraceLink  object between the underlying ItemRevision
     * objects of the given Awb0Occurrence objects.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param input
     *        Structures which hold the required information to create tracelinks between the given
     *        occurrences.
     *
     * @return
     *         A  list of CreateTracelinksResponseData structures, one for each successfully created
     *         FND_TraceLink object  corresponding to each input and the ServiceData. Any failure
     *         will be returned with clientId mapped to  error message in the ServiceData list of
     *         partial errors.  Following error codes are returned in the ServiceData. -  124001
     *         - If there is an internal error during the creation due to invalid input parameters.
     *         - 124002  - If there is no suitable adapter found to handle this input object.
     *
     */
    virtual Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::CreateTracelinksResponse createTracelinks ( const std::vector< Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::CreateTracelinksInputData >& input ) = 0;

    /**
     * This operation deletes the Awb0Connection  objects and optionally the Awb0Interface
     * objects they connect. It also deletes the underlying PSConnection  and optionally
     * the Interfaces objects.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param input
     *        Structures which hold the required information to delete the connection objects and
     *        optionally the ports they connect.
     *
     * @return
     *         A  list of affected Aw0Element parent object from which the Awb0Connection elements
     *         were removed along with  the ServiceData. The Awb0Element objects from which the
     *         Awb0Interface objects are deleted will be returned  in the ServiceData as updated
     *         objects. Any failure will be returned with clientId mapped to error message  in the
     *         ServiceData list of partial errors.  Following error codes are returned in the ServiceData.124001
     *         If there is an internal error during the deletion due to invalid input parameters.
     *         124002 If there is  no suitable adapter found to handle this input object.
     *
     */
    virtual Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::DeleteConnectionsResponse deleteConnections ( const Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::DeleteConnectionsInputData&  input ) = 0;

    /**
     * This operation returns the  child occurrence Awb0Element objects of a given parent
     * occurrence Awb0Element object. It also returns  the ports Awb0Inteface objects of
     * the child occurrence objects. Optionally, it returns the connections  Awb0Connection
     * objects between the child occurrences and also the occurrences in the given product
     * context.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param input
     *        Structures which hold the required information to get child occurrences, ports and
     *        connections under a given parent.
     *
     * @return
     *         Maps  containing The Awb0Element objects and their related objects lists and the
     *         ServiceData. Any failure will  be returned with clientId mapped to error message
     *         in the ServiceData list of partial errors.
     *
     */
    virtual Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::GetChildOccsPortsConnectionsResponse getChildOccsPortsConnections ( const std::vector< Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::GetChildOccsPortsConnectionsInputData >& input ) = 0;

    /**
     * This operation returns a list of objects and relation types which are used to navigate
     * the  data on a diagram. This list of objects and relation types is the filter which
     * is applied during the  diagram navigation.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param viewName
     *        The name of the view for which the legend is to be populated.
     *
     * @return
     *         A  list of supported objects and relation types. If there is no matching data for
     *         the input view, empty  list will be returned. The following partial errors may be
     *         returend. 124003      if the configuration  file does not exist on the server.
     *
     * @deprecated
     *         As of Teamcenter 10.1.5, this operation does not support ability to consider display
     *         rules for returned types and ability to define scope for creation of any category
     *         types. Use the getDiagramLegend4 service operation.
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 10.1.5, this operation does not support ability to consider display rules for returned types and ability to define scope for creation of any category types. Use the getDiagramLegend4 service operation."))
#endif
    virtual Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::DiagramLegendResponse getDiagramLegend ( const std::string&  viewName ) = 0;

    /**
     * This operation returns a localized list of objects and relation types which are used
     * to  navigate the data on a diagram. This list of objects and relation types is the
     * filter which is applied  during the diagram navigation.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param viewName
     *        The name of the view for which the legend is to be populated.
     *
     * @return
     *         A list of supported objects and relation types. If there is no matching data for
     *         the input view, empty list will be returned. The following partial errors may be
     *         returned.
     *         <br>
     *         124003&nbsp;&nbsp;&nbsp;&nbsp;  if the configuration file does not exist on the server.
     *
     * @deprecated
     *         As of Teamcenter 10.1.5, this operation does not support ability to consider display
     *         rules for returned types and ability to define scope for creation of any category
     *         types. Use the getDiagramLegend4 service operation.
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 10.1.5, this operation does not support ability to consider display rules for returned types and ability to define scope for creation of any category types. Use the getDiagramLegend4 service operation."))
#endif
    virtual Ase0::Services::Activeworkspacesyseng::_2014_11::Diagrammanagement::DiagramLegendResponse getDiagramLegend2 ( const std::string&  viewName ) = 0;

    /**
     * This operation returns a localized list of objects, relation and port type names
     * which are used to navigate the data on a diagram. This list of object type names
     * is the filter which is applied during the diagram navigation. The type data returns
     * the flag to mention if the user has access to author the object type or not.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param viewName
     *        The name of the view for which the legend is to be populated.
     *
     * @return
     *         A list of supported objects and relation types. If there is no matching data for
     *         the input view, empty list will be returned. The following partial errors may be
     *         returned. 124003      if the configuration file does not exist on the server.
     *
     * @deprecated
     *         As of Teamcenter 10.1.5, this operation does not support ability to define scope
     *         for creation of any category types. Use the getDiagramLegend4 service operation.
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 10.1.5, this operation does not support ability to define scope for creation of any category types. Use the getDiagramLegend4 service operation."))
#endif
    virtual Ase0::Services::Activeworkspacesyseng::_2014_11::Diagrammanagement::DiagramLegendResponse1 getDiagramLegend3 ( const std::string&  viewName ) = 0;

    /**
     * This operation returns a localized list of objects, relation and port type names
     * which are used to navigate the data on a diagram. This list of object type names
     * is the filter which is applied during the diagram navigation. The type data returns
     * the flag to mention indicate if the user has access to author the object type or
     * not. Filter data returns additional filter which denotes scope for creation of object
     * of given types.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * An Active Workspace user selects an object in the Architecture Modeler tab and clicks
     * on the expansion link to expand its relations. System responds by building new shapes
     * for the related objects and relations. User clicks to open the legends section where
     * he/she sees the localized names of the objects and relations. User then selects the
     * types of objects and relations from the legends section to be filtered out. System
     * responds by removing the corresponding shapes from the tab.
     * <br>
     * User enters edit mode and selects an object type in the legend and clicks on the
     * Architecture Modeler tab. System responds by creating an object of the selected type
     * and drawing a shape on the tab. User will see object type in legend as disabled if
     * user does not have access create or edit the type.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param viewName
     *        The name of the view for which the legend is to be populated.
     *
     * @return
     *         A list of supported objects and relation types. If there is no matching data for
     *         the input view, empty list will be returned. The following partial errors may be
     *         returned. 124003&nbsp;&nbsp;&nbsp;&nbsp;  if the configuration file does not exist
     *         on the server.
     *
     */
    virtual Ase0::Services::Activeworkspacesyseng::_2015_10::Diagrammanagement::DiagramLegendResponse1 getDiagramLegend4 ( const std::string&  viewName ) = 0;


    SOA_CLASS_NEW_OPERATORS_WITH_IMPL("DiagrammanagementService")

};
        }
    }
}


#ifdef WIN32
#pragma warning ( pop )
#endif

#include <ase0/services/activeworkspacesyseng/ActiveWorkspaceSysEng_undef.h>
#endif

