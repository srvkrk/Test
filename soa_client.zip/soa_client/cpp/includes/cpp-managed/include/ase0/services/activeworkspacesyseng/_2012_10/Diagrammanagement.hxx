/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef ASE0_SERVICES_ACTIVEWORKSPACESYSENG__2012_10_DIAGRAMMANAGEMENT_HXX
#define ASE0_SERVICES_ACTIVEWORKSPACESYSENG__2012_10_DIAGRAMMANAGEMENT_HXX

#include <teamcenter/soa/client/model/Awb0Connection.hxx>
#include <teamcenter/soa/client/model/Awb0Element.hxx>
#include <teamcenter/soa/client/model/Awb0ProductContextInfo.hxx>
#include <teamcenter/soa/client/model/FND_TraceLink.hxx>
#include <teamcenter/soa/client/model/RevisionRule.hxx>
#include <teamcenter/soa/client/model/VariantRule.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <ase0/services/activeworkspacesyseng/ActiveWorkspaceSysEng_exports.h>

namespace Ase0
{
    namespace Services
    {
        namespace Activeworkspacesyseng
        {
            namespace _2012_10
            {
                class Diagrammanagement;

class ASE0SOAACTIVEWORKSPACESYSENGSTRONGMNGD_API Diagrammanagement
{
public:

    struct ChildOccsPortsConnectionsResponseData;
    struct CreateInput;
    struct CreateConnectionsInputData;
    struct CreateConnectionsResponse;
    struct CreateConnectionsResponseData;
    struct CreateTracelinksInputData;
    struct CreateTracelinksResponse;
    struct CreateTracelinksResponseData;
    struct DeleteConnectionsInputData;
    struct DeleteConnectionsResponse;
    struct DiagramLegendData;
    struct DiagramLegendResponse;
    struct RGBValue;
    struct FilterData;
    struct OccurrenceConfigurationInfo;
    struct InputContext;
    struct GetChildOccsPortsConnectionsInputData;
    struct GetChildOccsPortsConnectionsResponse;
    struct TypeData;

    /**
     * CreateInputMap is a map of reference or relation property name to secondary CreateInput
     * objects.
     */
    typedef std::map< std::string, std::vector< CreateInput > > CreateInputMap;

    /**
     * A map of Parent Awb0Element objects to its children Awb0Element objects.
     */
    typedef std::map< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject> , std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  > > ParentElementToChildElementsMap;

    /**
     * PropertyValues is a map of property name (key) and property values (values) in string
     * format.
     */
    typedef std::map< std::string, std::vector< std::string > > PropertyValues;

    /**
     * Map of preferences and their values. keys and values are case sensitive. Allowed
     * keys are processConnections.
     */
    typedef std::map< std::string, std::string > RequestPreference;

    /**
     * Structure represents the output of the operation.
     */
    struct ChildOccsPortsConnectionsResponseData
    {
        /**
         * The clientId from the input element. This value is unchanged from the input, and
         * can be used to identify this response element with the corresponding input element.
         */
        std::string clientId;
        /**
         * A map of parent Awb0Element object and its child Awb0Element objects (business object
         * /list of business objects).
         */
        ParentElementToChildElementsMap occurrences;
        /**
         * A map of Awb0Element and its Awb0Interface objects (business object /list of business
         * objects).
         */
        ParentElementToChildElementsMap interfaces;
        /**
         * A map of Awb0Connection  objects and  their connected Awb0Element objects (business
         * object /list of business objects)
         */
        ParentElementToChildElementsMap connections;
        /**
         * A map of tracelink Objects Vs its's definging and complying object.
         */
        ParentElementToChildElementsMap tracelinks;
    };

    /**
     * CreateInput structure used to capture the inputs required for creation of a business
     * object. This is a recursive structure containing the CreateInput(s) for any secondary(compounded)
     * objects that might be created (e.g Item also creates ItemRevision and ItemMasterForm
     * etc.)
     */
    struct CreateInput
    {
        /**
         * The type name of the Business Object.
         */
        std::string boName;
        /**
         * Map of property name (key) and property values (values) in string format, to be set
         * on new object being created. The calling client is responsible for converting the
         * different property types (int, float, date .etc) to a string using the appropriate
         * function(s) in the SOA client framework Property class.
         */
        PropertyValues propertyNameValues;
        /**
         * CreateInput map (string, list of CreateInput) for compounded objects. Valid keys
         * are compound properties on CreateInput and valid values are CreateInput of compound
         * objects. E.g. For CreateInput of Item, ItemRevision CreateInput is defined as Compound
         * CreateInput using property "revision". In such case, valid key will be "revision"
         * and valid value will be CreateInput of ItemRevision.
         */
        CreateInputMap compoundCreateInput;
    };

    /**
     * Structure represents the parameters required to create connections between the given
     * set of objects.
     */
    struct CreateConnectionsInputData
    {
        /**
         * A unique string supplied by the caller. This ID is used to identify return data elements
         * and partial errors associated with this input structure.
         */
        std::string clientId;
        /**
         * Create Input structure for the Connection object.
         */
        Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::CreateInput connectionCreateInput;
        /**
         * The Awb0Element object which represents one end of the connection.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Element>  end1;
        /**
         * The Awb0Element object which represents the other end of the connection.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Element>  end2;
        /**
         * The Awb0Element object under which the Awb0Connection object is to be created. This
         * is an optional input.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Element>  connectionParent;
        /**
         * Create Input structure for creating one end of the Connection. This will create the
         * underlying ItemRevision or GDE which the Connection object can connect to.
         */
        Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::CreateInput end1CreateInput;
        /**
         * Create Input structure for creating the other end of the Connection. This will create
         * the underlying ItemRevision or GDE which the Connection object can connect to.
         */
        Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::CreateInput end2CreateInput;
        /**
         * Awb0ProductContextInfo of the product in which connection will be created.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0ProductContextInfo>  productContext;
    };

    /**
     * Structure represents the output parameters of the operation.
     */
    struct CreateConnectionsResponse
    {
        /**
         * A list of CreateConnectionsResponseData structures.
         */
        std::vector< Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::CreateConnectionsResponseData > output;
        /**
         * The Service Data.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * Structure represents the output of the operation.
     */
    struct CreateConnectionsResponseData
    {
        /**
         * The clientId from the input CreateConnectionsInputData element. This value is unchanged
         * from the input, and can be used to identify this response element with the corresponding
         * input element.
         */
        std::string clientId;
        /**
         * The Awb0Connection  object.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Connection>  connection;
    };

    /**
     * Structure represents the parameters required to create a tracelink between the given
     * set of objects.
     */
    struct CreateTracelinksInputData
    {
        /**
         * A unique string supplied by the caller. This ID is used to identify return data elements
         * and partial errors associated with this input structure.
         */
        std::string clientId;
        /**
         * The Create Input structure which holds the necessary information to create an object
         * of type  FND_TraceLink or its subtypes.
         */
        Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::CreateInput tracelinkCreateInput;
        /**
         * The Awb0Element object which represents the Defining end of the tracelink.  FND_TraceLink
         * object will be created with its underlying ItemRevision or AbsoluteOccurrence object
         * depending on the input preference.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Element>  definingEnd;
        /**
         * The Awb0Element object which represents the Complying end of the tracelink. FND_TraceLink
         * object will be created with its underlying ItemRevision or AbsoluteOccurrence object
         * depending on the input preference.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Element>  complyingEnd;
        /**
         * A map of  preferences and their values (string/string). For e.g. keys could be  createComplyingTracelinkWithOccurrence,
         * createDefiningTracelinkWithOccurrence, createTracelinkWithOccurrences etc. and values
         * could be true or false and are case sensitive.
         */
        RequestPreference requestPref;
    };

    /**
     * Structure represents the output parameters of the operation.
     */
    struct CreateTracelinksResponse
    {
        /**
         * A list of CreateTracelinksResponseData structures.
         */
        std::vector< Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::CreateTracelinksResponseData > output;
        /**
         * The Service Data.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * Structure represents the output of the operation.
     */
    struct CreateTracelinksResponseData
    {
        /**
         * The clientId from the input CreateTracelinksInputData element. This value is unchanged
         * from the input, and can be used to identify this response element with the corresponding
         * input element.
         */
        std::string clientId;
        /**
         * The FND_TraceLink  object.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::FND_TraceLink>  tracelinkObject;
    };

    /**
     * Structure represents the parameters required to delete connection occurrences.
     */
    struct DeleteConnectionsInputData
    {
        /**
         * A unique string supplied by the caller. This ID is used to identify return data elements
         * and partial errors associated with this input structure.
         */
        std::string clientId;
        /**
         * A list of Awb0Connection objects to be deleted.
         */
        std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Connection>  > connectionsToBeDeleted;
        /**
         * Map(string,string) of preferences and their values. For e.g. key could be deletePorts
         * etc. and value could be true or false and is case sensitive.
         */
        RequestPreference requestPref;
    };

    /**
     * Structure represents the output parameters of the operation delete connections.
     */
    struct DeleteConnectionsResponse
    {
        /**
         * The clientId from the input DeleteConnectionsInputData element. This value is unchanged
         * from the input, and can be used to identify this response element with the corresponding
         * input element.
         */
        std::string clientId;
        /**
         * A list of parent Awb0Element objects from which Awb0Connection objects  were deleted.
         */
        std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Element>  > parentObjects;
        /**
         * The Service Data.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * Structure represents the output data of the operation.
     */
    struct DiagramLegendData
    {
        /**
         * The name of the Legend.
         */
        std::string name;
        /**
         * The default layout of the view.  The value could be Incremental, Orthographic,Tree,Left
         * To Right, Right To Left etc.  This value is utilized by the Graph component.
         */
        std::string defaultLayout;
        /**
         * The list of object filters.
         */
        std::vector< Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::FilterData > objectGroup;
        /**
         * The list of relation filters.
         */
        std::vector< Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::FilterData > relationGroup;
    };

    /**
     * Structure represents the output parameters of the operation.
     */
    struct DiagramLegendResponse
    {
        /**
         * The list of DiagramLegendData structures.
         */
        std::vector< Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::DiagramLegendData > legendData;
        /**
         * Contains the information about presentation rules based on types and properties.
         */
        std::string presentationRulesXML;
        /**
         * Contains the information about shapes assigned to types.
         */
        std::string presentationStylesXML;
        /**
         * The Service Data.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * Structure for representing color using RGB values, used in structure FilterData.
     */
    struct RGBValue
    {
        /**
         * The Red component of color.  Legal range is 0-255.
         */
        double redValue;
        /**
         * The Green component of color.  Legal range is 0-255.
         */
        double greenValue;
        /**
         * The Blue component of color.  Legal range is 0-255.
         */
        double blueValue;
    };

    /**
     * Structure for representing information of a filter, including filter name, RGB values
     * to color the legend of the filter at client side.
     */
    struct FilterData
    {
        /**
         * The name of the filter. For objects, the values could beLogical, Function, Requirement
         * etc. and for relations, the values could be Connectivity, Traceability etc.
         */
        std::string name;
        /**
         * The object or relation type information to be shown in the legend.
         */
        std::vector< Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::TypeData > types;
        /**
         * The color used for legend of this filter on the client.
         */
        Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::RGBValue color;
    };

    /**
     * Occurrence Configuration Info
     */
    struct OccurrenceConfigurationInfo
    {
        /**
         * The RevisionRule object used to configure the structure.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::RevisionRule>  revisionRule;
        /**
         * The effectivity Date used in the Revision Rule configuration.
         */
        Teamcenter::Soa::Common::DateTime effectivityDate;
        /**
         * The end item Item or ItemRevision object used for Effectivity.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  endItem;
        /**
         * The saved VariantRule object used  to configure the structure.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::VariantRule>  variantRule;
        /**
         * The ConfigurationContext  object . If specified, the other configuration information
         * will be ignored.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  configurationObject;
        /**
         * The unit number to be used in Effectivity.
         */
        int unitNo;
        /**
         * If true, the configuration is the current time.
         */
        bool now;
    };

    /**
     * InputContext
     */
    struct InputContext
    {
        /**
         * The OccurrenceConfigurationInfo structure.
         */
        Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::OccurrenceConfigurationInfo configuration;
        /**
         * pageSize
         */
        int pageSize;
        /**
         * This holds reference to structure context object, which further references configuration
         * context and content objects which could be Item, ItemRevision or AppearanceGroup.
         * If structureContextObject object is given in input the product and configuration
         * context are optional.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  structureContextObject;
        /**
         * This indiactes the productContext information, this represent the product along with
         * the configuration information.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0ProductContextInfo>  productContext;
    };

    /**
     * GetChildOccsPortsConnectionsInputData
     */
    struct GetChildOccsPortsConnectionsInputData
    {
        /**
         * A unique string supplied by the caller. This ID is used to identify return data elements
         * and partial errors associated with this input structure.
         */
        std::string clientId;
        /**
         * The parent Awb0Element objects.
         */
        std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Element>  > parentOccurrences;
        /**
         * The configuration information.
         */
        Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::InputContext inputCtxt;
        /**
         * A map of  preferences and their values (string/string). For e.g. keys could be  processConnections,
         * processComplyingTracelinks etc. and values could be true or false and are case sensitive.
         */
        RequestPreference requestPreference;
        /**
         * List of tracelink types to query.
         */
        std::vector< std::string > typesOfTraceLinks;
    };

    /**
     * GetChildOccsPortsConnectionsResponse
     */
    struct GetChildOccsPortsConnectionsResponse
    {
        /**
         * A list of ChildOccsPortsConnectionsResponseData  structures.
         */
        std::vector< Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::ChildOccsPortsConnectionsResponseData > output;
        /**
         * The Service Data.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * Structure containing the type information.
     */
    struct TypeData
    {
        /**
         * The model name of the type.
         */
        std::string typeName;
        /**
         * The display name of the type
         */
        std::string displayName;
    };




    /**
     * This operation creates a Awb0Connection  object and its underlying PSConnection object
     * to connect the given Awb0Element objects and their underlying  ItemRevision objects.
     * It also creates Awb0Interface objects based on the preference value.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param input
     *        Structures which hold the required information to create connections between the
     *        given occurrences.
     *
     * @return
     *         A  list of CreateConnectionsResponseData structures, one for each successfully created
     *         Awb0Connection object  corresponding to each input and the ServiceData. Any failure
     *         will be returned with clientId mapped to  error message in the ServiceData list of
     *         partial errors.  Following error codes are returned in the ServiceData. 1.  124001
     *         If there is an internal error during creation of the connection. 2. 124002  If there
     *         is  no suitable adapter found to handle this input object.
     *
     */
    virtual Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::CreateConnectionsResponse createConnections ( const std::vector< Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::CreateConnectionsInputData >& input ) = 0;

    /**
     * This operation creates a FND_TraceLink  object between the underlying ItemRevision
     * objects of the given Awb0Occurrence objects.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param input
     *        Structures which hold the required information to create tracelinks between the given
     *        occurrences.
     *
     * @return
     *         A  list of CreateTracelinksResponseData structures, one for each successfully created
     *         FND_TraceLink object  corresponding to each input and the ServiceData. Any failure
     *         will be returned with clientId mapped to  error message in the ServiceData list of
     *         partial errors.  Following error codes are returned in the ServiceData. -  124001
     *         - If there is an internal error during the creation due to invalid input parameters.
     *         - 124002  - If there is no suitable adapter found to handle this input object.
     *
     */
    virtual Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::CreateTracelinksResponse createTracelinks ( const std::vector< Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::CreateTracelinksInputData >& input ) = 0;

    /**
     * This operation deletes the Awb0Connection  objects and optionally the Awb0Interface
     * objects they connect. It also deletes the underlying PSConnection  and optionally
     * the Interfaces objects.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param input
     *        Structures which hold the required information to delete the connection objects and
     *        optionally the ports they connect.
     *
     * @return
     *         A  list of affected Aw0Element parent object from which the Awb0Connection elements
     *         were removed along with  the ServiceData. The Awb0Element objects from which the
     *         Awb0Interface objects are deleted will be returned  in the ServiceData as updated
     *         objects. Any failure will be returned with clientId mapped to error message  in the
     *         ServiceData list of partial errors.  Following error codes are returned in the ServiceData.124001
     *         If there is an internal error during the deletion due to invalid input parameters.
     *         124002 If there is  no suitable adapter found to handle this input object.
     *
     */
    virtual Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::DeleteConnectionsResponse deleteConnections ( const Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::DeleteConnectionsInputData&  input ) = 0;

    /**
     * This operation returns the  child occurrence Awb0Element objects of a given parent
     * occurrence Awb0Element object. It also returns  the ports Awb0Inteface objects of
     * the child occurrence objects. Optionally, it returns the connections  Awb0Connection
     * objects between the child occurrences and also the occurrences in the given product
     * context.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param input
     *        Structures which hold the required information to get child occurrences, ports and
     *        connections under a given parent.
     *
     * @return
     *         Maps  containing The Awb0Element objects and their related objects lists and the
     *         ServiceData. Any failure will  be returned with clientId mapped to error message
     *         in the ServiceData list of partial errors.
     *
     */
    virtual Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::GetChildOccsPortsConnectionsResponse getChildOccsPortsConnections ( const std::vector< Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::GetChildOccsPortsConnectionsInputData >& input ) = 0;

    /**
     * This operation returns a list of objects and relation types which are used to navigate
     * the  data on a diagram. This list of objects and relation types is the filter which
     * is applied during the  diagram navigation.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param viewName
     *        The name of the view for which the legend is to be populated.
     *
     * @return
     *         A  list of supported objects and relation types. If there is no matching data for
     *         the input view, empty  list will be returned. The following partial errors may be
     *         returend. 124003      if the configuration  file does not exist on the server.
     *
     * @deprecated
     *         As of Teamcenter 10.1.5, this operation does not support ability to consider display
     *         rules for returned types and ability to define scope for creation of any category
     *         types. Use the getDiagramLegend4 service operation.
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 10.1.5, this operation does not support ability to consider display rules for returned types and ability to define scope for creation of any category types. Use the getDiagramLegend4 service operation."))
#endif
    virtual Ase0::Services::Activeworkspacesyseng::_2012_10::Diagrammanagement::DiagramLegendResponse getDiagramLegend ( const std::string&  viewName ) = 0;


protected:
    virtual ~Diagrammanagement() {}
};
            }
        }
    }
}

#include <ase0/services/activeworkspacesyseng/ActiveWorkspaceSysEng_undef.h>
#endif

