/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef EWI0_SERVICES_EWIA_DATAMANAGEMENTSERVICE_HXX
#define EWI0_SERVICES_EWIA_DATAMANAGEMENTSERVICE_HXX

#include <ewi0/services/ewia/_2012_10/Datamanagement.hxx>
#include <ewi0/services/ewia/_2015_03/Datamanagement.hxx>



#include <teamcenter/soa/client/Connection.hxx>
#include <new> // for size_t
#include <teamcenter/soa/common/MemoryManager.hxx>

#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable : 4996  )
#endif

#include <ewi0/services/ewia/Ewia_exports.h>

namespace Ewi0
{
    namespace Services
    {
        namespace Ewia
        {
            class DatamanagementService;

/**
 * Contains general data management operations for EWI
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libewi0soaewiastrongmngd.dll
 * </li>
 * <li type="disc">libewi0soaewiatypes.dll (runtime dependency)
 * </li>
 * </ul>
 */

class EWI0SOAEWIASTRONGMNGD_API DatamanagementService
    : public Ewi0::Services::Ewia::_2012_10::Datamanagement,
             public Ewi0::Services::Ewia::_2015_03::Datamanagement
{
public:
    static DatamanagementService* getService( Teamcenter::Soa::Client::Connection* );


    /**
     * Generates printable report for the EWI.
     *
     * @param input
     *        The input object for the report generation SOA.
     *
     * @return
     *         The printable report object.
     *
     */
    virtual Ewi0::Services::Ewia::_2012_10::Datamanagement::GeneratePrintReportResponse generatePrintableReport ( const std::vector< Ewi0::Services::Ewia::_2012_10::Datamanagement::GeneratePrintReportInput >& input ) = 0;

    /**
     * Returns the file read ticket of the Cortona 3D animation (.wrl) file from the given
     * Cortona build file.
     *
     * @param input
     *        the vector of cortona files for which read ticket is required.
     *
     * @return
     *         The file read ticket of animation file.
     *
     */
    virtual Ewi0::Services::Ewia::_2012_10::Datamanagement::CortonaFileResponse getCortonaAnimationFileTicket ( const std::vector< Ewi0::Services::Ewia::_2012_10::Datamanagement::CortonaFileInput >& input ) = 0;

    /**
     * This operation returns the given relation/property data of input business objects.
     * For every relation/property, you can specify the type of required objects you want
     * to load. In case you want to load all of the objects related, then pass empty list
     * of types.
     *
     * @param input
     *        the input
     *
     * @return
     *         The relations/properties data by given types.
     *
     */
    virtual Ewi0::Services::Ewia::_2012_10::Datamanagement::GetRelatedResponse getRelated ( const Ewi0::Services::Ewia::_2012_10::Datamanagement::GetRelatedInputInfo&  input ) = 0;

    /**
     * Load required work package data for Ewi.
     *
     * @param input
     *        The input vector.
     *
     * @return
     *         Required work package data for Ewi.
     *
     */
    virtual Ewi0::Services::Ewia::_2012_10::Datamanagement::LoadWorkPackageDataResponse loadWorkPackageData ( const std::vector< Ewi0::Services::Ewia::_2012_10::Datamanagement::LoadWorkPackageInput >& input ) = 0;

    /**
     * This operation loads work package data with optional configuration parameters to
     * the EWI (Electronic Work Instructions) application. Work package is a Collaboration
     * Context object packaging manufacturing structures with specific configuration settings.
     * The additionl configuration parameters can be used to apply further , on-demand,
     * configuration settings on top of the work package configuration.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param input
     *        A vector containing the input structures.
     *
     * @return
     *         The requested work package data.
     *         <br>
     *         The following partial errors may be returned:
     *         <br>
     *         <ul>
     *         <li type="disc">115001 - The operation "loadWorkPackageData" has failed because the
     *         input does not contain work package information. Please contact your system administrator.
     *         </li>
     *         <li type="disc">115002 - The creation of an Electronic Work Instruction object for
     *         the work package has failed. Please contact your system administrator.
     *         </li>
     *         <li type="disc">115003 - The creation of an Electronic Work Instruction object for
     *         the current step has failed. Please contact your system administrator.
     *         </li>
     *         <li type="disc">115004 - None of the preferred navigation structures are found in
     *         the selected work package. Either add a value to the preference "EWI_NavigationStructure"
     *         (in order to open a different navigation structure), or select a different work package.
     *         </li>
     *         <li type="disc">115007 - Teamcenter Electronic Work Instructions (EWI) license is
     *         not installed. Please contact your system administrator.
     *         </li>
     *         </ul>
     *
     */
    virtual Ewi0::Services::Ewia::_2012_10::Datamanagement::LoadWorkPackageDataResponse loadWorkPackageDataConfigured ( const std::vector< Ewi0::Services::Ewia::_2015_03::Datamanagement::LoadWorkPackageConfiguredInput >& input ) = 0;


    SOA_CLASS_NEW_OPERATORS_WITH_IMPL("DatamanagementService")

};
        }
    }
}


#ifdef WIN32
#pragma warning ( pop )
#endif

#include <ewi0/services/ewia/Ewia_undef.h>
#endif

