/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef CM1_SERVICES_CMAWS_REVISESERVICE_HXX
#define CM1_SERVICES_CMAWS_REVISESERVICE_HXX

#include <cm1/services/cmaws/_2017_06/Revise.hxx>



#include <teamcenter/soa/client/Connection.hxx>
#include <new> // for size_t
#include <teamcenter/soa/common/MemoryManager.hxx>

#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable : 4996  )
#endif

#include <cm1/services/cmaws/CmAws_exports.h>

namespace Cm1
{
    namespace Services
    {
        namespace Cmaws
        {
            class ReviseService;

/**
 * Service for revising objects
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libcm1soacmawsstrongmngd.dll
 * </li>
 * <li type="disc">libcm1soacmawstypes.dll (runtime dependency)
 * </li>
 * </ul>
 */

class CM1SOACMAWSSTRONGMNGD_API ReviseService
    : public Cm1::Services::Cmaws::_2017_06::Revise
{
public:
    static ReviseService* getService( Teamcenter::Soa::Client::Connection* );


    /**
     * This operation revises the impacted objects in ChangeNoticeRevision. Newly revised
     * object is added as Solution in ChangeNoticeRevision and also creates CMSolutionToImpacted
     * relation between old impacted objects and revised solution objects of ChangeNoticeRevision.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Change Management - This Component is intended to identify all Operations and Services
     * under Change Management.
     *
     * @param ecnImpactedObjects
     *        Input is list of ChangeNoticeRevision objects and its corresponding list of WorkspaceObject
     *        referred as impacted objects that needs to be revised.
     *
     * @return
     *         A generic container that contains list of ChangeNoticeRevision, corresponding list
     *         of WorkspaceObject referred as solution objects and service data.
     *
     */
    virtual Cm1::Services::Cmaws::_2017_06::Revise::ReviseToSolutionResponse reviseToSolution ( const std::vector< Cm1::Services::Cmaws::_2017_06::Revise::EcnImpactedObjectsInfo >& ecnImpactedObjects ) = 0;


    SOA_CLASS_NEW_OPERATORS_WITH_IMPL("ReviseService")

};
        }
    }
}


#ifdef WIN32
#pragma warning ( pop )
#endif

#include <cm1/services/cmaws/CmAws_undef.h>
#endif

