/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef CM1_SERVICES_CMAWS__2017_06_REVISE_HXX
#define CM1_SERVICES_CMAWS__2017_06_REVISE_HXX

#include <teamcenter/soa/client/model/ItemRevision.hxx>
#include <teamcenter/soa/client/model/WorkspaceObject.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <cm1/services/cmaws/CmAws_exports.h>

namespace Cm1
{
    namespace Services
    {
        namespace Cmaws
        {
            namespace _2017_06
            {
                class Revise;

class CM1SOACMAWSSTRONGMNGD_API Revise
{
public:

    struct EcnImpactedObjectsInfo;
    struct EcnSolutionObjects;
    struct ReviseToSolutionResponse;

    /**
     * Input is list of ChangeNoticeRevision objects and its corresponding list of WorkspaceObject
     * referred as impacted objects that needs to be revised.
     */
    struct EcnImpactedObjectsInfo
    {
        /**
         * An ItemRevision referred as ChangeNoticeRevision.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::ItemRevision>  ecn;
        /**
         * A list of WorkspaceObject which are referred as impacted objects that need to be
         * revised to solution objects of ChangeNoticeRevision.
         */
        std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::WorkspaceObject>  > impactedObjects;
    };

    /**
     * A generic container that contains ChangeNoticeRevision and its corresponding list
     * of WorkspaceObject referred as solution objects.
     */
    struct EcnSolutionObjects
    {
        /**
         * An ItemRevision referred as ChangeNoticeRevision.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::ItemRevision>  ecn;
        /**
         * A list of WorkspaceObjects which are referred as solution objects of ChangeNoticeRevision
         */
        std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::WorkspaceObject>  > solutionObjects;
    };

    /**
     * A generic container that contains list of ChangeNoticeRevision, corresponding list
     * of WorkspaceObject referred as solution objects and service data.
     */
    struct ReviseToSolutionResponse
    {
        /**
         * A list of ChangeNoticeRevision and corresponding list of WorkspaceObject referred
         * as solution objects.
         */
        std::vector< Cm1::Services::Cmaws::_2017_06::Revise::EcnSolutionObjects > ecnSolutionObjects;
        /**
         * Contains newly created relations in the created list.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };




    /**
     * This operation revises the impacted objects in ChangeNoticeRevision. Newly revised
     * object is added as Solution in ChangeNoticeRevision and also creates CMSolutionToImpacted
     * relation between old impacted objects and revised solution objects of ChangeNoticeRevision.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Change Management - This Component is intended to identify all Operations and Services
     * under Change Management.
     *
     * @param ecnImpactedObjects
     *        Input is list of ChangeNoticeRevision objects and its corresponding list of WorkspaceObject
     *        referred as impacted objects that needs to be revised.
     *
     * @return
     *         A generic container that contains list of ChangeNoticeRevision, corresponding list
     *         of WorkspaceObject referred as solution objects and service data.
     *
     */
    virtual Cm1::Services::Cmaws::_2017_06::Revise::ReviseToSolutionResponse reviseToSolution ( const std::vector< Cm1::Services::Cmaws::_2017_06::Revise::EcnImpactedObjectsInfo >& ecnImpactedObjects ) = 0;


protected:
    virtual ~Revise() {}
};
            }
        }
    }
}

#include <cm1/services/cmaws/CmAws_undef.h>
#endif

