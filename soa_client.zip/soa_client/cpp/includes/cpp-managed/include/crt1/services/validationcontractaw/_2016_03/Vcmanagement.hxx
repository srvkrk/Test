/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef CRT1_SERVICES_VALIDATIONCONTRACTAW__2016_03_VCMANAGEMENT_HXX
#define CRT1_SERVICES_VALIDATIONCONTRACTAW__2016_03_VCMANAGEMENT_HXX

#include <teamcenter/soa/client/model/Att0MeasurableAttribute.hxx>
#include <teamcenter/soa/client/model/Awb0Element.hxx>
#include <teamcenter/soa/client/model/Crt0StudyRevision.hxx>
#include <teamcenter/soa/client/model/Crt0VldnContractRevision.hxx>
#include <teamcenter/soa/client/model/WorkspaceObject.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <crt1/services/validationcontractaw/ValidationContractAW_exports.h>

namespace Crt1
{
    namespace Services
    {
        namespace Validationcontractaw
        {
            namespace _2016_03
            {
                class Vcmanagement;

class CRT1SOAVALIDATIONCONTRACTAWSTRONGMNGD_API Vcmanagement
{
public:

    struct AnalysisRequestInfoInput;
    struct AttributeData;
    struct GetAnalysisRequestInfoRespData;
    struct GetAnalysisRequestInfoResponse;
    struct InputObjectData;
    struct InputSectionData;
    struct OutputSectionData;
    struct StudyData;

    /**
     * This structure contains inputs that are required to get the Analysis Request  (<b>Crt0VldnContractRevision</b>)
     * or Study (<b>Crt0StudyRevision</b>) information.
     */
    struct AnalysisRequestInfoInput
    {
        /**
         * This unique ID is used to identify return data elements and partial errors associated
         * with this input structure.
         */
        std::string clientId;
        /**
         * The <b>Crt0VldnContractRevision</b> or <b>Crt0StudyRevision</b> object whose information
         * this structure holds.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Crt0VldnContractRevision>  arOrStudyRevision;
        /**
         * The scope of Analysis Request information that must be retrieved. Supported values
         * are:
         * <br>
         * InputObjects - Get information of all objects that are added as input of analysis.
         * <br>
         * OutputObjects - Get information of all objects that are added as output of analysis.
         * <br>
         * InputAttributes - Get information of all input attributes (<b>Att0MeasurableAttribute</b>).
         * <br>
         * OutputAttributes - Get information of all output attributes (<b>Att0MeasurableAttribute</b>).
         */
        std::vector< std::string > arOrStudyScope;
        /**
         * If true, the child information is returned. If <b>Crt0StudyRevision</b> is used as
         * input, includeChildrenStudies is not relevant.
         */
        bool includeChildrenStudies;
        /**
         * The scope of Analysis Request Studies information that must be retrieved. Supported
         * values are: "InputObjects", "OutputObjects", "InputAttributes" and "OutputAttributes".
         */
        std::vector< std::string > childrenStudyScope;
    };

    /**
     * This structure contains detailed information of the input or output attribute (<b>Att0MeasurableAttribute</b>).
     */
    struct AttributeData
    {
        /**
         * The measurable attribute.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasurableAttribute>  attribute;
        /**
         * The usage of the measurable attribute. Supported values are "Input" and "Output".
         */
        std::string inputOrOutput;
    };

    /**
     * This structure contains detailed information about each Analysis Request. The Input
     * and Output objects of each Analysis Request will be returned in separate sections,
     * grouped by object type. The section names and the types to be returned in the section
     * is defined in a mapping file.
     * <br>
     * <br>
     * The COTS mapping file can be found in the Dataset with name "Crt0VldnContractRevisionMapping".
     * This mapping file is for the OOTB Analysis Request (<b>Crt0VldnContractRevision</b>).
     * Custom mapping files that will be used for this SOA operation can be defined. For
     * more information about the mapping file, refer documentation of Analysis Request.
     */
    struct GetAnalysisRequestInfoRespData
    {
        /**
         * The Analysis Request (<b>Crt0VldnContractRevision</b>) or Study Revision (<b>Crt0StudyRevision</b>)
         * whose information this structure holds.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Crt0VldnContractRevision>  arOrStudyRevision;
        /**
         * Section wise information about the input objects that are added to the Analysis Request
         * (<b>Crt0VldnContractRevision</b>) or child Study (<b>Crt0StudyRevision</b>) for analysis
         * purpose.
         */
        std::vector< Crt1::Services::Validationcontractaw::_2016_03::Vcmanagement::InputSectionData > inputSectionData;
        /**
         * Section wise information about the output objects that are added to the Analysis
         * Request (<b>Crt0VldnContractRevision</b>) or child Study (<b>Crt0StudyRevision</b>)
         * after analysis.
         */
        std::vector< Crt1::Services::Validationcontractaw::_2016_03::Vcmanagement::OutputSectionData > outputSectionData;
        /**
         * List of input attributes (<b>Att0MeasurableAttribute</b>).
         */
        std::vector< Crt1::Services::Validationcontractaw::_2016_03::Vcmanagement::AttributeData > inputAttributes;
        /**
         * List of output attributes (<b>Att0MeasurableAttribute</b>).
         */
        std::vector< Crt1::Services::Validationcontractaw::_2016_03::Vcmanagement::AttributeData > outputAttributes;
        /**
         * List of children Studies (<b>Crt0StudyRevision</b>) of the Analysis Request (<b>Crt0VldnContractRevision</b>).
         */
        std::vector< Crt1::Services::Validationcontractaw::_2016_03::Vcmanagement::StudyData > childrenStudies;
    };

    /**
     * This structure contains Analysis Request (<b>Crt0VldnContractRevision</b>) or Study
     * (<b>Crt0StudyRevision</b>) information in the output and errors in service data.
     */
    struct GetAnalysisRequestInfoResponse
    {
        /**
         * List of GetAnalysisRequestInfoRespData that contains information about the input
         * Analysis Requests (<b>Crt0VldnContractRevision</b>) or Studies (<b>Crt0StudyRevision</b>).
         */
        std::vector< Crt1::Services::Validationcontractaw::_2016_03::Vcmanagement::GetAnalysisRequestInfoRespData > output;
        /**
         * Service Data.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * This structure contains detailed information of the input object that is added to
     * Analysis Request for analysis purpose.
     */
    struct InputObjectData
    {
        /**
         * The occurrence thread chain of the object that is added to the Analysis Request for
         * analysis purpose.
         */
        std::string occurrenceThreadChain;
        /**
         * The runtime representation of a line in a product structure that is added to the
         * Analysis Request for analyis purpose. This element represents the Teamcenter object
         * for the occurrenceThreadChain.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Element>  element;
        /**
         * List of attribute (<b>Att0MeasurableAttribute</b>) data of the input object .
         */
        std::vector< Crt1::Services::Validationcontractaw::_2016_03::Vcmanagement::AttributeData > attributesInfo;
    };

    /**
     * This structure contains section wise detailed information of the input objects that
     * are added to Analysis Request for analysis purpose.
     */
    struct InputSectionData
    {
        /**
         * The key of the section that is used to group the input objects by type. The section
         * key and the object types are defined in the mapping file. The COTS mapping file can
         * be found in the Dataset with name "Crt0VldnContractRevisionMapping". This mapping
         * file is for the COTS Analysis Request (<b>Crt0VldnContractRevision</b>).
         */
        std::string sectionKey;
        /**
         * The localized name of the section that is used to group the input objects by type.
         */
        std::string sectionDisplayName;
        /**
         * List of input objects that are added to the Analysis Request (<b>Crt0VldnContractRevision</b>)
         * for analysis purpose.
         */
        std::vector< Crt1::Services::Validationcontractaw::_2016_03::Vcmanagement::InputObjectData > inputObjects;
    };

    /**
     * This structure contains section wise detailed information of the output objects that
     * are added to Analysis Request for analysis purpose.
     */
    struct OutputSectionData
    {
        /**
         * The key of the section that is used to group the input objects by type. The section
         * key and the object types are defined in the mapping file. The OOTB mapping file can
         * be found in the Dataset with name "Crt0VldnContractRevisionMapping". This mapping
         * file is for the OOTB Analysis Request (<b>Crt0VldnContractRevision</b>).
         */
        std::string sectionKey;
        /**
         * The localized name of the section that is used to group the input objects by type.
         */
        std::string sectionDisplayName;
        /**
         * List of output objects that are added to the Analysis Request (<b>Crt0VldnContractRevision</b>).
         */
        std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::WorkspaceObject>  > outputObjects;
    };

    /**
     * This structure contains detailed information of the Analysis Request children Study
     * object (<b>Crt0StudyRevision</b>).
     */
    struct StudyData
    {
        /**
         * The Analysis Request's child Study(<b>Crt0StudyRevision</b>) object whose information
         * this structure holds.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Crt0StudyRevision>  studyRevision;
        /**
         * List of input objects that are added to the Analysis Request Study (<b>Crt0StudyRevision</b>)
         * for analysis purpose.
         */
        std::vector< Crt1::Services::Validationcontractaw::_2016_03::Vcmanagement::InputSectionData > inputSectionData;
        /**
         * List of output objects that are added to the Analysis Request Study (<b>Crt0StudyRevision</b>)
         * after the analysis.
         */
        std::vector< Crt1::Services::Validationcontractaw::_2016_03::Vcmanagement::OutputSectionData > outputSectionData;
        /**
         * List of input attributes (<b>Att0MeasurableAttribute</b>) of the Analysis Request
         * Study.
         */
        std::vector< Crt1::Services::Validationcontractaw::_2016_03::Vcmanagement::AttributeData > inputAttributes;
        /**
         * List of output attributes (<b>Att0MeasurableAttribute</b>) of the Analysis Request
         * Study.
         */
        std::vector< Crt1::Services::Validationcontractaw::_2016_03::Vcmanagement::AttributeData > outputAttributes;
    };




    /**
     * This service operation gets information of the input Analysis Requests (<b>Crt0VldnContractRevision</b>)
     * or Study (<b>Crt0StudyRevision</b>), which is a sub type of Analysis Request (<b>Crt0VldnContractRevision</b>).
     * <br>
     * <br>
     * The following information can be retrieved:
     * <br>
     * a. Input objects (<b>Awb0Element</b>) that are added to Analysis Request.
     * <br>
     * b. Output objects (<b>WorkspaceObject</b>) that are added to Analysis Request.
     * <br>
     * c. Input attributes (<b>Att0MeasurableAttribute</b>).
     * <br>
     * d. Output attributes(<b>Att0MeasurableAttribute</b>).
     * <br>
     * e. Children studies (<b>Crt0StudyRevision</b>) of an Analysis Request (<b>Crt0VldnContractRevision</b>).
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * None
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace Validation Contract - This is a component for Active Workspace Validation
     * Contract.
     *
     * @param input
     *        The input contains the Analysis Request (<b>Crt0VldnContractRevision</b>) or Study
     *        (<b>Crt0StudyRevision</b>) and the scope of information that must be retreived.
     *
     * @return
     *         Information about the input Analysis Request is returned. The amount of information
     *         retrieved depends on the scope specified in the input to the operation.
     *         <br>
     *         <br>
     *         The Analysis Request (<b>Crt0VldnContractRevision</b>), Studies (<b>Crt0StudyRevision</b>),
     *         Input Objects (<b>Awb0Element</b>), Output Objects (<b>WorkspaceObject</b>) and Attributes
     *         (<b>Att0MeasuableAttribute</b>) will be added to the plain objects list of the Service
     *         Data in the response..
     *         <br>
     *         <br>
     *         The following partial errors may be returned:
     *         <br>
     *         184024 : The Analysis Request mapping file in dataset is invalid, because either
     *         the XML contains a syntax error or it does not confirm to the Analysis Request mapping
     *         schema (which can be found in the dataset AnalysisRequestMappingSchema).
     *         <br>
     *         184025 : The information of Analysis Request or Study cannot be retrieved, because
     *         the input scope, is not supported.
     *         <br>
     *         184026 : The children studies information of Analysis Request cannot be retrieved,
     *         because the input children studies scope, is not supported.
     *         <br>
     *         184027 : The information of Analysis Request or Study cannot be retrieved, because
     *         the XSD schema dataset of the mapping file is not found.
     *         <br>
     *         184028 : The information of Analysis Request or Study cannot be retrieved, because
     *         the name of mapping dataset to be used, was not specified. The Analysis Request mapping
     *         preference does not exist or does not contain a value.
     *         <br>
     *         184029 : The information of Analysis Request or Study cannot be retrieved, because
     *         the mapping dataset is not found.
     *
     */
    virtual Crt1::Services::Validationcontractaw::_2016_03::Vcmanagement::GetAnalysisRequestInfoResponse getAnalysisRequestInfo ( const std::vector< Crt1::Services::Validationcontractaw::_2016_03::Vcmanagement::AnalysisRequestInfoInput >& input ) = 0;


protected:
    virtual ~Vcmanagement() {}
};
            }
        }
    }
}

#include <crt1/services/validationcontractaw/ValidationContractAW_undef.h>
#endif

