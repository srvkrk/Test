/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef CRT1_SERVICES_VALIDATIONCONTRACTAW_VCMANAGEMENTSERVICE_HXX
#define CRT1_SERVICES_VALIDATIONCONTRACTAW_VCMANAGEMENTSERVICE_HXX

#include <crt1/services/validationcontractaw/_2015_03/Vcmanagement.hxx>
#include <crt1/services/validationcontractaw/_2015_10/Vcmanagement.hxx>
#include <crt1/services/validationcontractaw/_2016_03/Vcmanagement.hxx>



#include <teamcenter/soa/client/Connection.hxx>
#include <new> // for size_t
#include <teamcenter/soa/common/MemoryManager.hxx>

#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable : 4996  )
#endif

#include <crt1/services/validationcontractaw/ValidationContractAW_exports.h>

namespace Crt1
{
    namespace Services
    {
        namespace Validationcontractaw
        {
            class VcmanagementService;

/**
 * This service manages data specific to Active Workspace Validation Contract template.
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libcrt1soavalidationcontractawstrongmngd.dll
 * </li>
 * <li type="disc">libcrt1soavalidationcontractawtypes.dll (runtime dependency)
 * </li>
 * </ul>
 */

class CRT1SOAVALIDATIONCONTRACTAWSTRONGMNGD_API VcmanagementService
    : public Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement,
             public Crt1::Services::Validationcontractaw::_2015_10::Vcmanagement,
             public Crt1::Services::Validationcontractaw::_2016_03::Vcmanagement
{
public:
    static VcmanagementService* getService( Teamcenter::Soa::Client::Connection* );


    /**
     * Objects that need to be validated must be added to Validation Contracts. This operation
     * adds specified objects that need to be validated to the Valiation Contract. It does
     * this by creating tracelinks of the specified type between the Validation Contract
     * Revision and the specified Components to be validated.
     * <br>
     * Tracelink creation rules are mentioned below:
     * <br>
     * <br>
     * 1.&nbsp;&nbsp;&nbsp;&nbsp;If a Component (<b>Awb0Element</b>) and the Context are
     * specified, in-context tracelink is created.
     * <br>
     * 2.&nbsp;&nbsp;&nbsp;&nbsp;If a Component (<b>Awb0Element</b>) is specified but the
     * Context is not specified, the Item Revision corresponding to the Component is used
     * to created the tracelink.
     * <br>
     * <br>
     * The objects will be added to sections specified in the "view" group. The sections
     * in the "view" group are specified in the Contract Definition that is attached to
     * the Validation Contract.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * Use case 1: Add a Component in a Product for validation from the Validation Contract's
     * Domain. The Component can be at any level in the Product.
     * <br>
     * An in-context tracelink is created between the Component (<b>Awb0Element</b>) and
     * the Validation Contract. The Product is the context in which the tracelink is created.
     * <br>
     * <br>
     * Use case 2: Add a Product for validation from the Validation Contract's Domain
     * <br>
     * A  tracelink is created between the Product's Item Revision and the Validation Contract.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace Validation Contract - This is a component for Active Workspace Validation
     * Contract.
     *
     * @param input
     *        This structure contains all information required to add objects to Validation Contract.
     *
     * @return
     *         The following partial errors may be returned in the ServiceData:
     *         <br>
     *         35003: If the input Trace Link type is invalid.
     *         <br>
     *         35006: If the input Validation Contract is invalid.
     *         <br>
     *         35007: If the input object to the added to the Validaiton Contract is invalid.
     *         <br>
     *         184007: If the object cannot be added to the Analysis Request, because the specified
     *         Trace Link type is not (Crt0ValidationLink).
     *         <br>
     *         184008: If the object cannot be added to the Analysis Request, because the section
     *         name is empty.
     *         <br>
     *         184009: If the object cannot be added to the Analysis Request, because the component
     *         and the context are the same.
     *         <br>
     *         184010: If the object cannot be added to the Analysis Request, because the context
     *         of the component does not belong to the Analysis Request's domain.
     *         <br>
     *         184011: If the object cannot be added to the Analysis Request, because it exceeds
     *         the quantity of allowed objects for the specified section. The quantity of objects
     *         allowed for the section is specified in the Analysis definition.
     *         <br>
     *         184012: If the object cannot be added to the Analysis Request, because the specified
     *         section does not exist in the Analysis definition.
     *         <br>
     *         184015: If the object cannot be added to the Analysis Request, because it is already
     *         added to it.
     *         <br>
     *         184016: If the object cannot be added to the Analysis Request, because the current
     *         user does not have write privileges to the Analysis Request.
     *         <br>
     *         184017: If the object cannot be added to the Analysis Request, because the Analysis
     *         Request is released.
     *         <br>
     *         184018: If the object cannot be added to the Analysis Request, because the Analysis
     *         Request is checked out by another user.
     *
     */
    virtual Teamcenter::Soa::Client::ServiceData addObjectsForValidation ( const std::vector< Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::AddObjsForValidationInput >& input ) = 0;

    /**
     * After a validation activity, results need to be added to Validation Contracts. This
     * operation adds the specified result objects to the Validation Contract. Tracelinks
     * are created for the specified type between the <b>Crt0VldnContractRevision</b> and
     * the specified result objects.
     * <br>
     * The result objects will be added to sections specified in the "results" group. The
     * sections in the "results" group are specified in the contract definition revision
     * (<b>Crt0VCDefnRevision</b>) that is attached to the validation contract revision
     * (<b>Crt0VldnContractRevision</b>).
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace Validation Contract - This is a component for Active Workspace Validation
     * Contract.
     *
     * @param input
     *        Information of result objects to be added to Validation Contract
     *
     * @return
     *         The following partial errors may be returned:
     *         <br>
     *         184001: If the The object cannot be added to the Analysis Request, because the Analysis
     *         Request's definition does not have the input section.
     *         <br>
     *         184002: If the object cannot be added to the Analysis Request, because the Analysis
     *         Request's definition does not have a section for the object type.
     *         <br>
     *         184007: If the object cannot be added to the Analysis Request, because the specified
     *         Trace Link type is not Crt0ValidationLink.
     *         <br>
     *         184014: If the object cannot be added to the Analysis Request, because the input
     *         section defined in the Analysis Request's definition does not accept object type.
     *         <br>
     *         184015: If the object cannot be added to the Analysis Request, because it is already
     *         added to it.
     *         <br>
     *         184016: If the object cannot be added to the Analysis Request, because the current
     *         user does not have write privileges to the Analysis Request.
     *         <br>
     *         184017: If the object cannot be added to the Analysis Request, because the Analysis
     *         Request is released.
     *         <br>
     *         184018: If the object cannot be added to the Analysis Request, because the Analysis
     *         Request is checked out by another user.
     *
     */
    virtual Teamcenter::Soa::Client::ServiceData addValidationResults ( const std::vector< Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::AddResultsOfValidationInput >& input ) = 0;

    /**
     * This operation retrieves the information about objects added to Validation Contract
     * (<b>Crt0VldnContractRevision</b>) for validation activity. The below details are
     * retrieved.
     * <br>
     * <br>
     * 1.&nbsp;&nbsp;&nbsp;&nbsp;Objects added to Validation Contract (<b>Crt0VldnContractRevision</b>)
     * for validation activity.
     * <br>
     * 2.&nbsp;&nbsp;&nbsp;&nbsp;Complete information of the "view" group as specified in
     * the Contract definition (<b>Crt0VCDefnRevision</b>) that is attached to the Validation
     * Contract (<b>Crt0VldnContractRevision</b>).
     * <br>
     * 3.&nbsp;&nbsp;&nbsp;&nbsp;<b>Crt0ValidationLink</b> tracelinks that were created
     * when objects were added to the Validation Contract (<b>Crt0VldnContractRevision</b>).
     * <br>
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace Validation Contract - This is a component for Active Workspace Validation
     * Contract.
     *
     * @param input
     *        Validation Contracts (<b>Crt0VldnContractRevision</b>) whose information must be
     *        retreived.
     *
     * @return
     *         Information about the objects added to validation contracts, the sections where the
     *         objects have been added and the tracelinks are returned.
     *         <br>
     *         <br>
     *         The following partial errors may be returned:
     *         <br>
     *         184013: If the Analysis definition details cannot be retrieved, because no definition
     *         is attached to the Analysis Request.
     *
     */
    virtual Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::ObjectsAddForValidationResponse getObjectsAddedForValidation ( const std::vector< Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::GetObjectsAddForValidationInput >& input ) = 0;

    /**
     * This operation retrieves the information about result objects added to Validation
     * Contract (<b>Crt0VldnContractRevision</b>). The below details are retrieved.
     * <br>
     * <ul>
     * <li type="disc">Result objects that were added to Validation Contract (<b>Crt0VldnContractRevision</b>).
     * The result objects are generally added after a validation activity.
     * </li>
     * <li type="disc">Complete information of the "results" group as specified in the Contract
     * definition (<b>Crt0VCDefnRevision</b>) that is attached to the Validation Contract
     * (<b>Crt0VldnContractRevision</b>).
     * </li>
     * <li type="disc"><b>Crt0ValidationLink</b> tracelinks that were created when the result
     * objects were added to the Validation Contract (<b>Crt0VldnContractRevision</b>).
     * </li>
     * </ul>
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace Validation Contract - This is a component for Active Workspace Validation
     * Contract.
     *
     * @param input
     *        Validation Contracts (Crt0VldnContractRevision)whose information must be retreived.
     *
     * @return
     *         Information about the result objects that were previously added to validation contracts,
     *         the sections where the objects have been added and the tracelinks are returned.
     *         <br>
     *         <br>
     *         The following partial errors may be returned:
     *         <br>
     *         184013: If the Analysis definition details cannot be retrieved, because no definition
     *         is attached to the Analysis Request.
     *
     */
    virtual Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::GetValidationResultsResponse getValidationResults ( const std::vector< Crt1::Services::Validationcontractaw::_2015_03::Vcmanagement::GetResultsOfValidationInput >& input ) = 0;

    /**
     * Objects that need to be validated or analyzed must be added to an Analysis Request.
     * This operation adds or updates for validation or analysis purpose, all the objects
     * from the current Architecture Diagram of the input Analysis Request's (<b>Crt0VldnContractRevision</b>)
     * domain.
     * <br>
     * 1. If objects have not been previously added, all the current Architecture Diagram
     * elements are added to the Analysis Request.
     * <br>
     * 2. If objects have been previously added, they are removed and all the current Architecture
     * Diagram elements are added to the Analysis Request.
     * <br>
     * All the objects that are displayed in the diagram and those that meet the Analysis
     * Request's definition criteria are added to the Analysis Request. This includes any
     * displayed children of any object  in the diagram.
     * <br>
     * If the Analysis Definition contains more than one possible sections that can accept
     * an object, the object will be added to the first possible section.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * 1. Add the Domain's models, requirements, targets, test cases from the Architecture
     * <br>
     * diagram to the Analysis Request in a simplified manner.
     * <br>
     * Prior to creating an Analysis Request, specific elements    relavant for an analysis
     * or validation are turned ON in the domain, so that they appear on the Architecture
     * Diagram.  User selects a one step command in Active Workspace to add or update objects
     * from the Architecture Diagram to the Analysis Request in one go.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace Validation Contract - This is a component for Active Workspace Validation
     * Contract.
     *
     * @param input
     *        Analysis Requests (<b>Crt0VldnContractRevision</b>) whose diagram elements must be
     *        added for validation/analysis.
     *
     * @return
     *         The successfully updated Analysis Request objects are returned in the Updated list
     *         of the ServiceData. The following  partial errors may be retured:
     *         <br>
     *         <br>
     *         184021 :The object being added to the Analysis Request is not accepted by any section
     *         specified in the Analysis Request's definition.
     *
     */
    virtual Teamcenter::Soa::Client::ServiceData addObjectsForValidationFromDiagram ( const std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Crt0VldnContractRevision>  >& input ) = 0;

    /**
     * Objects that need to be validated must be added to an Analysis Request. This operation
     * checks whether the input objects are already added to the input Analysis Request.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * <b>Give visual indication of objects added to the Analysis Request</b>:
     * <br>
     * Add a Product's component (<b>Awb0Element</b>) to an Analysis Request. When the same
     * component is again selected for adding to the Analysis Request, a visual indication
     * must be given to the user that it is already added.  This can be achieved for example
     * by greying out a command on the client.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace Validation Contract - This is a component for Active Workspace Validation
     * Contract.
     *
     * @param input
     *        Information of objects to be added to an Analysis Request.
     *
     * @return
     *         The set of <b>Crt0VldnContractRevision</b> objects with the 'added' state for each
     *         <b>Awb0Element</b>. Following partial errors may be returned.
     *         <br>
     *         <ul>
     *         <li type="disc">184006: There are no adapters defined for the <b>Awb0Element</b>.
     *         </li>
     *         </ul>
     *
     */
    virtual Crt1::Services::Validationcontractaw::_2015_10::Vcmanagement::AreObjsAddedToAnalysisReqResponse areObjectsAddedToAnalysisRequest ( const std::vector< Crt1::Services::Validationcontractaw::_2015_10::Vcmanagement::AreObjsAddedToAnalysisReqInput >& input ) = 0;

    /**
     * This service operation gets information of the input Analysis Requests (<b>Crt0VldnContractRevision</b>)
     * or Study (<b>Crt0StudyRevision</b>), which is a sub type of Analysis Request (<b>Crt0VldnContractRevision</b>).
     * <br>
     * <br>
     * The following information can be retrieved:
     * <br>
     * a. Input objects (<b>Awb0Element</b>) that are added to Analysis Request.
     * <br>
     * b. Output objects (<b>WorkspaceObject</b>) that are added to Analysis Request.
     * <br>
     * c. Input attributes (<b>Att0MeasurableAttribute</b>).
     * <br>
     * d. Output attributes(<b>Att0MeasurableAttribute</b>).
     * <br>
     * e. Children studies (<b>Crt0StudyRevision</b>) of an Analysis Request (<b>Crt0VldnContractRevision</b>).
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * None
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active Workspace Validation Contract - This is a component for Active Workspace Validation
     * Contract.
     *
     * @param input
     *        The input contains the Analysis Request (<b>Crt0VldnContractRevision</b>) or Study
     *        (<b>Crt0StudyRevision</b>) and the scope of information that must be retreived.
     *
     * @return
     *         Information about the input Analysis Request is returned. The amount of information
     *         retrieved depends on the scope specified in the input to the operation.
     *         <br>
     *         <br>
     *         The Analysis Request (<b>Crt0VldnContractRevision</b>), Studies (<b>Crt0StudyRevision</b>),
     *         Input Objects (<b>Awb0Element</b>), Output Objects (<b>WorkspaceObject</b>) and Attributes
     *         (<b>Att0MeasuableAttribute</b>) will be added to the plain objects list of the Service
     *         Data in the response..
     *         <br>
     *         <br>
     *         The following partial errors may be returned:
     *         <br>
     *         184024 : The Analysis Request mapping file in dataset is invalid, because either
     *         the XML contains a syntax error or it does not confirm to the Analysis Request mapping
     *         schema (which can be found in the dataset AnalysisRequestMappingSchema).
     *         <br>
     *         184025 : The information of Analysis Request or Study cannot be retrieved, because
     *         the input scope, is not supported.
     *         <br>
     *         184026 : The children studies information of Analysis Request cannot be retrieved,
     *         because the input children studies scope, is not supported.
     *         <br>
     *         184027 : The information of Analysis Request or Study cannot be retrieved, because
     *         the XSD schema dataset of the mapping file is not found.
     *         <br>
     *         184028 : The information of Analysis Request or Study cannot be retrieved, because
     *         the name of mapping dataset to be used, was not specified. The Analysis Request mapping
     *         preference does not exist or does not contain a value.
     *         <br>
     *         184029 : The information of Analysis Request or Study cannot be retrieved, because
     *         the mapping dataset is not found.
     *
     */
    virtual Crt1::Services::Validationcontractaw::_2016_03::Vcmanagement::GetAnalysisRequestInfoResponse getAnalysisRequestInfo ( const std::vector< Crt1::Services::Validationcontractaw::_2016_03::Vcmanagement::AnalysisRequestInfoInput >& input ) = 0;


    SOA_CLASS_NEW_OPERATORS_WITH_IMPL("VcmanagementService")

};
        }
    }
}


#ifdef WIN32
#pragma warning ( pop )
#endif

#include <crt1/services/validationcontractaw/ValidationContractAW_undef.h>
#endif

