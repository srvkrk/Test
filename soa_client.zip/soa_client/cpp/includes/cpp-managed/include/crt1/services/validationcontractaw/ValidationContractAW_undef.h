/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/
#include <common/library_indicators.h>


#if !defined(EXPORTLIBRARY)
#   error EXPORTLIBRARY is not defined
#endif

#undef EXPORTLIBRARY

#if !defined(IPLIB)
#   error IPLIB is not defined
#endif

#undef CRT1SOAVALIDATIONCONTRACTAWSTRONGMNGD_API
#undef CRT1SOAVALIDATIONCONTRACTAWSTRONGMNGDEXPORT
#undef CRT1SOAVALIDATIONCONTRACTAWSTRONGMNGDGLOBAL
#undef CRT1SOAVALIDATIONCONTRACTAWSTRONGMNGDPRIVATE

