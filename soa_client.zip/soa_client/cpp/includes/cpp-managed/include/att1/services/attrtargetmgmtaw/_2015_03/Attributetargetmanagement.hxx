/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef ATT1_SERVICES_ATTRTARGETMGMTAW__2015_03_ATTRIBUTETARGETMANAGEMENT_HXX
#define ATT1_SERVICES_ATTRTARGETMGMTAW__2015_03_ATTRIBUTETARGETMANAGEMENT_HXX

#include <teamcenter/soa/client/model/Att0MeasurableAttribute.hxx>
#include <teamcenter/soa/client/model/Att0MeasureValue.hxx>
#include <teamcenter/soa/client/model/Awb0Element.hxx>
#include <teamcenter/soa/client/model/WorkspaceObject.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <att1/services/attrtargetmgmtaw/AttrTargetMgmtAW_exports.h>

namespace Att1
{
    namespace Services
    {
        namespace Attrtargetmgmtaw
        {
            namespace _2015_03
            {
                class Attributetargetmanagement;

class ATT1SOAATTRTARGETMGMTAWSTRONGMNGD_API Attributetargetmanagement
{
public:

    struct AssignMeasurableAttributeInfo;
    struct AssignMeasurableAttributeInput;
    struct AssignMeasurableAttributePref;
    struct AssignMeasurableAttributesResponse;
    struct AttributeInfo;
    struct ObjectInput;
    struct MeasurableAttributeInput;
    struct CreateOrModifyAttrInput;
    struct CreateOrModifyAttrOutput;
    struct CreateOrModifyAttrResp;
    struct GetMeasurableAttrInput;
    struct GetMeasurableAttrOutput;
    struct GetMeasurableAttrResp;
    struct ParentAttrList;

    /**
     * The action to peform on given Measurable Attribute.
     */
    enum AssignAction{ SetInput,
                 SetOutput,
                 UnsetInput,
                 UnsetOutput,
                 SetInputAsOutput,
                 SetOutputAsInput
                 };

    /**
     * The AttributeType represents runtime role of a MeasurableAttribue. Runtime actions
     * are performed based on this type.
     */
    enum AttributeType{ SOURCEATTR,
                 OVERRIDDENATTR,
                 INPUTATTR,
                 SYNCCANDIDATE,
                 OUTPUTATTR_NOTUPDATE,
                 OUTPUTATTR_PUBLISHCANDIDATE,
                 OUTPUTATTR_PUBLISHED
                 };

    /**
     * AssignMeasurableAttributesMap Contains client Id and list of AssignMeasurableAttributeInfo
     * structure which holds Att0MeasurableAttribute objects based on assign action.
     * <br>
     * Elements:
     * <br>
     * key&nbsp;&nbsp;&nbsp;&nbsp;Client identifier defined by user to track the related
     * object.
     * <br>
     * values&nbsp;&nbsp;&nbsp;&nbsp;List of AssignMeasurableAttributeInfo objects for this
     * client Id.
     * <br>
     */
    typedef std::map< std::string, std::vector< AssignMeasurableAttributeInfo > > AssignMeasurableAttributesMap;

    /**
     * Name value pair (string/list of string) of the property name and its value. The calling
     * client is responsible for converting the different property types (int, float, date
     * .etc) to a string using the appropriate toXXXString functions in the SOA client framework's
     * Property class.
     */
    typedef std::map< std::string, std::vector< std::string > > ObjectPropertiesMap;

    /**
     * AssignMeasurableAttributeInfo holds Att0MeasurableAttribute object and it associated
     * measurableAttributes index.
     */
    struct AssignMeasurableAttributeInfo
    {
        /**
         * The index of measurableAttributes in related AssignMeasurableAttributeInput.
         */
        int index;
        /**
         * The Att0MeasurableAttribute object returned by associated assign action.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasurableAttribute>  measurableAttribute;
    };

    /**
     * AssignMeasurableAttributeInput structure represents the criteria to assign measurable
     * attribute objects to input/output attribute parent object.
     */
    struct AssignMeasurableAttributeInput
    {
        /**
         * Identifier defined by client to track the related object.
         */
        std::string clientID;
        /**
         * The desired assign action name, SetInput, SetOutput, UnsetInput, UnsetOutput, SetInputAsOutput,
         * SetOutputAsInput.
         */
        AssignAction actionName;
        /**
         * The parent object for input or output measurable attributes.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::WorkspaceObject>  inputOutputAttrParent;
        /**
         * A list of Att0MeasurableAttribute object which will be set as input/output to parent
         * object.
         */
        std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasurableAttribute>  > measurableAttributes;
        /**
         * The parent line in the product structure that measurableAttributes associated with.
         * It is required if and only if assignAction equals to SetInput or SetOutput.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Element>  parentLine;
        /**
         * The context line which represents the current product context. It is required if
         * and only if AssignAction equals to SetInput or SetOutput.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Element>  contextLine;
    };

    /**
     * AssignMeasurableAttributePref structure represents input and output relation names
     * that is used to link the input and output attributes (Att0MeasurableAttribute) to
     * parent object.
     * <br>
     * <br>
     * If no value is provided for inputAttributeRelation, system uses default relation
     * <br>
     * (Att0InputAttrRelation).
     * <br>
     * If no value is provided for outputAttributeRelation, system uses default
     * <br>
     * relation (Att0OutputAttrRelation).
     * <br>
     */
    struct AssignMeasurableAttributePref
    {
        /**
         * The relation name system uses to link input measurable       attribute(Att0MeasurableAttribute)
         * to inputOutputAttrParent object.
         */
        std::string inputAttributeRelation;
        /**
         * The relation name system uses to link output measurable       attribute(Att0MeasurableAttribute)
         * to inputOutputAttrParent object.
         */
        std::string outputAttributeRelation;
    };

    /**
     * AssignMeasurableAttributesResponse holds the response of assignMeasuableAttributes.
     * This output structure contains service data with partial errors and outputMap which
     * contains list of Att0MeasurableAttribute objects related to assign action.
     */
    struct AssignMeasurableAttributesResponse
    {
        /**
         * The Service Data with partial errors for AssignMeasurableAttributeInput identified
         * by its clientId.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
        /**
         * A map (string/list) of client identifer and list of AssignMeasurableAttributeInfo)
         * pairs.
         * <br>
         * If the AssignAction equals to UnsetInput or UnsetOutput, the outputMap will be empty
         * since system deletes all input or output attributes as well as associated relations.
         * <br>
         */
        AssignMeasurableAttributesMap outputMap;
    };

    /**
     * This structure represents a measurable attribute and it has the associated information
     * for the measurable attribute.
     */
    struct AttributeInfo
    {
        /**
         * The measurable attribute object. The object must derive from Att0MeasurableAttribute.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasurableAttribute>  attribute;
        /**
         * The name of the primary occurrence which is associated with measurable attribute.
         */
        std::string occName;
        /**
         * The type of Measurable Attribute. The possible values of attribute type will be SOURCEATTR,
         * OVERRIDDENATTR, INPUTATTR, SYNCCANDIDATE, OUTPUTATTR_NOTUPDATE, OUTPUTATTR_PUBLISHCANDIDATE
         * and OUTPUTATTR_PUBLISHED.
         */
        AttributeType attributeType;
        /**
         * The source measurable attribute for the Overidden, Input and Ouput attribute. For
         * source attribute, this field will be NULL.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasurableAttribute>  sourceAttribute;
    };

    /**
     * ObjectInput structure represents all the information needed to create or modify an
     * object.
     */
    struct ObjectInput
    {
        /**
         * Type of the object to create a new object. The allowed values are Att0MeasurableAttribute
         * and Att0MeasureValue.
         */
        std::string objType;
        /**
         * Name value pair (string/list of strings) of property name and its value to create
         * or modify the properties on object. The calling client is responsible for converting
         * the different property types (int, float, date .etc) to a string using the appropriate
         * toXXXString functions in the SOA client framework's Property class.
         */
        ObjectPropertiesMap objPropertiesMap;
    };

    /**
     * MeasurableAttributeInput structure represents all the information needed to create
     * or modify the measurable attribute object.
     */
    struct MeasurableAttributeInput
    {
        /**
         * Name of the measurable attribute to create a new object. This parameter will be ignored
         * in case of modify use case.
         */
        std::string objName;
        /**
         * Measurable Aattribute type and property information to update or create the measurable
         * attribute.
         */
        Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::ObjectInput objInput;
    };

    /**
     * CreateOrModifyAttrInput structure represents all the information needed to create
     * or modify the measurable attribute.
     */
    struct CreateOrModifyAttrInput
    {
        /**
         * This unique ID is used to identify return data elements and partial errors associated
         * with this input structure.
         */
        std::string clientId;
        /**
         * Name of the relation between parent object and measurable attribute. This relation
         * will be used to create and query the measurable attribute from parent object.
         */
        std::string relationName;
        /**
         * Instance of measurable attribute object for modify use case, provide NULL to create
         * a new attribute.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasurableAttribute>  attribute;
        /**
         * The parent object to create and associate the measurable attributes with. If value
         * for parentLine is also provided then this parameter should be NULL.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::WorkspaceObject>  parentObj;
        /**
         * The parent line in the product structure to create the measurable attributes. If
         * value for parentObj is provided then this parameter will be ignored.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Element>  parentLine;
        /**
         * The context line which represents the current product context. If value for parentObj
         * is provided then this parameter will be ignored.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Element>  contextLine;
        /**
         * All the information needed to create or modify the measurement object.
         */
        Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::ObjectInput measureValueObjInput;
        /**
         * All the information needed to create or modify the measurable attribute object.
         */
        Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::MeasurableAttributeInput attributeObjInput;
    };

    /**
     * CreateOrModifyAttrResp represents created or modified measurable attributes for a
     * given input.
     */
    struct CreateOrModifyAttrOutput
    {
        /**
         * The unmodified value from the CreateOrModifyAttrInput.clientId. This is used by the
         * caller to identify this data structure with the source input data.
         */
        std::string clientId;
        /**
         * Represents created or modified measurable attributes for a given input. All objects
         * must derive from Att0MeasurableAttribute.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasurableAttribute>  measurableAttribute;
        /**
         * True, id the measurable attribute object is an override
         */
        bool isOverriden;
        /**
         * Instance of newly created measure value object.All objects must derive from parent
         * object Att0MeasureValue.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasureValue>  measureValue;
    };

    /**
     * CreateOrModifyAttrResp represents created or modified measurable attributes for all
     * the inputs.
     */
    struct CreateOrModifyAttrResp
    {
        /**
         * Represents created or modified measurable attributes for all the inputs.
         */
        std::vector< Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::CreateOrModifyAttrOutput > attrList;
        /**
         * Standard ServiceData object to hold the partial errors that the operation encounters.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * GetMeasurableAttrInput structure represents all the information for all parent objects
     * to get the associated measurable attributes.
     */
    struct GetMeasurableAttrInput
    {
        /**
         * This unique ID is used to identify return data elements and partial errors associated
         * with this input structure.
         */
        std::string clientId;
        /**
         * List of relation type name to get associated measurable attributes from parent object.
         */
        std::vector< std::string > relationList;
        /**
         * The parent object to get the measurable attributes. The parent object can be any
         * WorkspaceObject type. If value for parentLine is also provided then this parameter
         * should be NULL.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::WorkspaceObject>  parentObj;
        /**
         * The parent line in the product structure to get the associated measurable attributes.
         * If value for parentObj is provided then this parameter will be ignored.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Element>  parentLine;
        /**
         * The context line which represents the current product context. If value for parentObj
         * is provided then this parameter will be ignored.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Element>  contextLine;
    };

    /**
     * This structure represent all the measurable attributes for a given parent object.
     */
    struct GetMeasurableAttrOutput
    {
        /**
         * The unmodified value from the GetMeasurableAttrInput.clientId. This is used by the
         * caller to identify this data structure with the source input data.
         */
        std::string clientId;
        /**
         * The list of attributes for a specific relation.
         */
        std::vector< Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::ParentAttrList > attrList;
        /**
         * True if the parentLine is assigned to parentObject in the context of contextLine.
         */
        bool isLineInValidationList;
    };

    /**
     * GetMeasurableAttrResp structure represents all the attributes for the list of parents
     * in input.
     */
    struct GetMeasurableAttrResp
    {
        /**
         * A list of measurable attributes objects for a given parent.
         */
        std::vector< Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::GetMeasurableAttrOutput > parentAttrList;
        /**
         * Standard ServiceData object to hold the partial errors that the operation encounters.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * This structure represents the list of attributes associated with a given parent object
     * using a specific relation.
     */
    struct ParentAttrList
    {
        /**
         * The name of the relation using which parent object and measurable attributes objects
         * are connected.
         */
        std::string relationType;
        /**
         * The list of measurable attributes associated with the parent object using relationType
         * relation.
         */
        std::vector< Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::AttributeInfo > attrObjList;
    };




    /**
     * This operation is used to assign measurable attributes (Att0MeasurableAttribute)
     * objects to given WorkspaceObject as input or output attributes for product validation
     * or measurement.
     * <br>
     * When an Att0MeasurableAttribute is assigned as input or output attribute, a save-as
     * operation is performed against the source attribute object and new relations will
     * be created to link the new Att0MeasurableAttribute with parent WorkspaceObject. Any
     * update on source attribute will not impact input or output attribute object, and
     * on the contrary.
     * <br>
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * 1. A system architect creates a product structure of logical blocks (Fnd0LogicalBlock),
     * and defines for each block its measurable attributes (Att0MeasurableAttribute). As
     * the design of the product architecture evolves, the system architect sets a logical
     * block attribute (Att0MeasurableAttribute) as an input of the validation context(WorkspaceObject),
     * the system builds a copy of the attribute for the validation context, and create
     * related links from input attribute to validation context.
     * <br>
     * 2. A system architect creates a product structure of logical blocks (Fnd0LogicalBlock),
     * and defines for each block its measurable attributes (Att0MeasurableAttribute), then
     * sets a logical block attribute (Att0MeasurableAttribute) as an output of the validation
     * context(WorkspaceObject).
     * <br>
     * However design changes and system architect needs to un-set the output attribute
     * for the validation context, the system deletes the output attributes as well as its
     * related output relations with validation context.
     * <br>
     * 3. A system architect creates a product structure of logical blocks (Fnd0LogicalBlock),
     * and defines for each block its measurable attributes (Att0MeasurableAttribute), then
     * sets a logical block attribute (Att0MeasurableAttribute) as an input of the validation
     * context(WorkspaceObject). However design changes and system architect needs to re-set
     * an input attribute as the output attribute of the validation context, the system
     * deletes the input attributes as well as its related input relations, then builds
     * a new copy of the source input attribute as an output attribute for the validation
     * context and creates related links from output attribute to validation context.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Attribute Target Management AW - This component consists of the Client and Enterprise
     * Tier code and constructs that support Attribute and Target related functionality
     * for Teamcenter Active Workspace application plus SOA, ITK and Preferences.
     *
     * @param inputs
     *        The measurable attribute assignment inputs.
     *
     * @param pref
     *        The measurable attribute assignment configuration.
     *
     * @return
     *         A map of client identifier to the Att0MeasurableAttribute objects. The following
     *         partial errors may be returned:
     *         <br>
     *         185401 - Invalid input or output parent object.
     *         <br>
     *         185405 - Input/output parent object is null.
     *         <br>
     *         185406 - The measurable attribute parameter is null.
     *         <br>
     *         185407 - The parent line must provide to set input/output measurable attribute.
     *         <br>
     *         185408 - The context line must provide to set input/output measurable attribute.
     *         <br>
     *         185409 - System does not support the given assign action.
     *         <br>
     *         185410 - The system does not support the "Assign" action on top lines.
     *
     */
    virtual Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::AssignMeasurableAttributesResponse assignMeasurableAttributes ( const std::vector< Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::AssignMeasurableAttributeInput >& inputs,
        const Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::AssignMeasurableAttributePref&  pref ) = 0;

    /**
     * This operation either creates a new measurable attribute object or modifies the existing
     * measurable attribute object depending on the input parameter.
     * <br>
     * Please refer to documentation for more details on Measurable Attribute object.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * Background
     * <br>
     * A Measurable Attribute is a characteristic of the system which can be externally
     * observed and has a target value or range in the context of the product, which must
     * be satisfied before the product is delivered. It consists of two parts. One is the
     * goal value and the other is the measured/validated value. A measurable attribute
     * may have more than one measured value (dependent of product maturity) and can be
     * seen in context of more than one application object.
     * <br>
     * Example: mass, cost, speed, pressure and other constituents of energy flow
     * <br>
     * <br>
     * 1.&nbsp;&nbsp;&nbsp;&nbsp;User wants to create a measurable attribute on the parent
     * object. For example, user wants to create a measurable attribute 'weight' on parent
     * object 'engine'.
     * <br>
     * 2.&nbsp;&nbsp;&nbsp;&nbsp;User has already created a measurable attribute on the
     * parent object and user wants to modify the properties of measurable attribute and
     * / or create a new measure value.
     * <br>
     * 3.&nbsp;&nbsp;&nbsp;&nbsp;The parent object is part of any assembly and now user
     * wants to override the value of measurable attribute properties in the context of
     * product. For example, Engine is part of assembly car and now user would like to change
     * the value of weight attribute on engine in the context of car.
     * <br>
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Attribute Target Management AW - This component consists of the Client and Enterprise
     * Tier code and constructs that support Attribute and Target related functionality
     * for Teamcenter Active Workspace application plus SOA, ITK and Preferences.
     *
     * @param inputs
     *        Information needed to create or modify the measurable attribute object.
     *
     * @return
     *         The response contains the list of measurable attribute objects which are either created
     *         or modified.
     *         <br>
     *         The following errors may be returned:
     *         <br>
     *         <br>
     *         185401 - Both the parent objects are NULL. Please provide value for either parentObj
     *         or parentLine input parameter.
     *         <br>
     *         185402 - Unable to create new measurable attribute. There is existing attribute on
     *         the parent object with the given name.
     *         <br>
     *         185403 - The input Measure Value type is not valid. Please contact the system administrator.
     *         <br>
     *         214116 - For any requested relation types the relation type name is invalid.
     *         <br>
     *         126214 - Unable to get Measurable Attributes because the provided context line does
     *         not have a BOMViewRevision.
     *
     * @deprecated
     *         As of Teamcenter 10.1.5, this operation does not support attachement of measurement
     *         datasets. Use the createOrUpdateMeasurableAttributes service operation.
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 10.1.5, this operation does not support attachement of measurement datasets. Use the createOrUpdateMeasurableAttributes service operation."))
#endif
    virtual Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::CreateOrModifyAttrResp createOrModifyMeasurableAttribute ( const std::vector< Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::CreateOrModifyAttrInput >& inputs ) = 0;

    /**
     * This operation gets the list of associated measurable attributes for the input parent
     * objects. A measurable attribute is a characteristic of the system which can be externally
     * observed and has a target value or range in the context of the product, which must
     * be satisfied before the product is delivered. It consists of two parts. One is the
     * goal value the other is the measured/validated value. A measurable attribute may
     * have more than one measured value (dependent of product maturity) and can be seen
     * in context of more than one application object.
     * <br>
     * Example: mass, cost, speed, pressure and other constituents of energy flow.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * 1.&nbsp;&nbsp;&nbsp;&nbsp;User has already created a measurable attribute on a parent
     * object and now user wants to see the list of attributes present on the object. For
     * example, user has created a measurable attribute 'mass' on 'Engine' and user wants
     * to see the value of attribute 'mass'.
     * <br>
     * 2.&nbsp;&nbsp;&nbsp;&nbsp;User wants to see overridden value of measurable attribute
     * on the parent object present in the assembly. For example, if 'Engine' is part of
     * 'Car' assembly and user has changed the value of 'mass' attribute on Engine in the
     * context of 'Car' then user wants to see the changed attribute value in context of
     * Car.
     * <br>
     * 3.&nbsp;&nbsp;&nbsp;&nbsp;User requires the list of measurable attributes associated
     * with the given model object of a validation contract.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Attribute Target Management AW - This component consists of the Client and Enterprise
     * Tier code and constructs that support Attribute and Target related functionality
     * for Teamcenter Active Workspace application plus SOA, ITK and Preferences.
     *
     * @param inputs
     *        A list of of parent objects to get associated measurable attributes.
     *
     * @return
     *         The response contains the list of associated measurable attributes objects with the
     *         parent objects provided in input.
     *         <br>
     *         <br>
     *         The following errors may be returned:
     *         <br>
     *         <br>
     *         185401 - Both the parent objects are NULL. Please provide value for either parentObj
     *         or parentLine input parameter.
     *         <br>
     *         214116 - For any requested relation types the relation type name is invalid.
     *         <br>
     *         126214 - Unable to get Measurable Attributes because the provided context line does
     *         not have a BOMViewRevision.
     *
     */
    virtual Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::GetMeasurableAttrResp getMeasurableAttributes ( const std::vector< Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::GetMeasurableAttrInput >& inputs ) = 0;


protected:
    virtual ~Attributetargetmanagement() {}
};
            }
        }
    }
}

#include <att1/services/attrtargetmgmtaw/AttrTargetMgmtAW_undef.h>
#endif

