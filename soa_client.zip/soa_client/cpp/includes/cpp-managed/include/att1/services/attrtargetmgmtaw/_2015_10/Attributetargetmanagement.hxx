/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef ATT1_SERVICES_ATTRTARGETMGMTAW__2015_10_ATTRIBUTETARGETMANAGEMENT_HXX
#define ATT1_SERVICES_ATTRTARGETMGMTAW__2015_10_ATTRIBUTETARGETMANAGEMENT_HXX

#include <att1/services/attrtargetmgmtaw/_2015_03/Attributetargetmanagement.hxx>
#include <teamcenter/soa/client/model/Att0MeasurableAttribute.hxx>
#include <teamcenter/soa/client/model/Att0MeasureValue.hxx>
#include <teamcenter/soa/client/model/Awb0Element.hxx>
#include <teamcenter/soa/client/model/Dataset.hxx>
#include <teamcenter/soa/client/model/WorkspaceObject.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <att1/services/attrtargetmgmtaw/AttrTargetMgmtAW_exports.h>

namespace Att1
{
    namespace Services
    {
        namespace Attrtargetmgmtaw
        {
            namespace _2015_10
            {
                class Attributetargetmanagement;

class ATT1SOAATTRTARGETMGMTAWSTRONGMNGD_API Attributetargetmanagement
{
public:

    struct AssignMeasurableAttributeInfo2;
    struct AssignMeasurableAttributeInput2;
    struct AssignMeasurableAttributePref2;
    struct AssignMeasurableAttributesResponse2;
    struct AttributeInfo2;
    struct CreateOrUpdateAttrInput;
    struct CreateOrUpdateAttrOutput;
    struct CreateOrUpdateAttrResp;
    struct GetMeasurableAttrOutput2;
    struct GetMeasurableAttrResp2;
    struct ParentAttrList2;
    struct SyncMeasurableAttributeInput;
    struct SyncMeasurableAttributePref;
    struct SyncMeasurableAttributeResponse;

    /**
     * <b>SyncFromSource</b> - Synchonization happens from source <i>Att0MeasurableAttribute</i>
     * objects to input <i>Att0MeasurableAttribute</i> objects.
     * <br>
     * <b>PublishToSource</b> - Synchonization happens from output <i>Att0MeasurableAttribute</i>
     * objects to source <i>Att0MeasurableAttribute</i> objects.
     */
    enum SyncDirection{ SyncFromSource,
                 PublishToSource
                 };

    /**
     * AssignMeasurableAttributesMap2 Contains client Id and list of AssignMeasurableAttributeInfo2
     * structure which holds Att0MeasurableAttribute objects based on assign action.
     * <br>
     * Elements:
     * <br>
     * <ul>
     * <li type="disc">key     Client identifier defined by user to track the related object.
     * </li>
     * <li type="disc">values  List of AssignMeasurableAttributeInfo2 objects for this client
     * Id.
     * </li>
     * </ul>
     */
    typedef std::map< std::string, std::vector< AssignMeasurableAttributeInfo2 > > AssignMeasurableAttributesMap2;

    /**
     * <i>SyncMeasurableAttributeMap</i> contains client Id and <i>Att0MeasurableAttribute</i>
     * objects which have been synchonized.
     * <br>
     * <ul>
     * <li type="disc">If <i>direction</i> is <i>SyncFromSource</i>, <i>SyncMeasurableAttributeMap</i>
     * contains all input <i>Att0MeasurableAttribute</i> objects that been synchronized
     * successfully.
     * </li>
     * <li type="disc">If <i>direction</i> is <i>PublishToSource</i>, <i>SyncMeasurableAttributeMap</i>
     * contains all source <i>Att0MeasurableAttribute</i> objects that been published successfully.
     * </li>
     * </ul>
     */
    typedef std::map< std::string, std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasurableAttribute>  > > SyncMeasurableAttributesMap;

    /**
     * AssignMeasurableAttributeInfo2 holds Att0MeasurableAttribute object and its associated
     * measurableAttributes index. It also holds attributeName and list of reference WorkspaceObject
     * objects other than parent.
     */
    struct AssignMeasurableAttributeInfo2
    {
        /**
         * The index of measurableAttributes in related AssignMeasurableAttributeInput2.
         */
        int index;
        /**
         * The Att0MeasurableAttribute object returned by associated assign action.
         * <br>
         * If the AssignAction equals to UnsetInput or UnsetOutput, the measurableAttribute
         * will be empty since system deletes all input or output attributes as well as associated
         * relations.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasurableAttribute>  measurableAttribute;
        /**
         * Name of measurable attribute.
         */
        std::string attributeName;
        /**
         * List of impacted primary objects e.g. Study(WorkspaceObject).
         */
        std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::WorkspaceObject>  > attributeReferenceList;
    };

    /**
     * AssignMeasurableAttributeInput2 structure represents the criteria to assign measurable
     * attribute objects to input/output attribute parent object.
     */
    struct AssignMeasurableAttributeInput2
    {
        /**
         * Identifier defined by client to track the related object.
         */
        std::string clientID;
        /**
         * The desired assign action name, SetInput, SetOutput,UnsetInput,UnsetOutput, SetInputAsOutput,
         * SetOutputAsInput.
         */
        std::string actionName;
        /**
         * The parent object for input or output measurable attributes.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::WorkspaceObject>  inputOutputAttrParent;
        /**
         * A list of Att0MeasurableAttribute object which will be set as input/output to parent
         * object.
         */
        std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasurableAttribute>  > measurableAttributes;
        /**
         * The parent line in the product structure that measurableAttributes associated with.
         * It is required if and only if assignAction equals to SetInput or SetOutput.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Element>  parentLine;
        /**
         * The context line which represents the current product context. It is required if
         * and only if assignAction equals to SetInput or SetOutput.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Element>  contextLine;
    };

    /**
     * AssignMeasurableAttributePref2 structure represents input and output relation names
     * that is used to link the input and output attributes (Att0MeasurableAttribute) to
     * parent object.
     * <br>
     * <ul>
     * <li type="disc">If no value is provided for inputAttributeRelation, system uses default
     * relation (Att0InputAttrRelation).
     * </li>
     * <li type="disc">If no value is provided for outputAttributeRelation, system uses
     * default relation (Att0OutputAttrRelation).
     * </li>
     * </ul>
     */
    struct AssignMeasurableAttributePref2
    {
        /**
         * The relation name system uses to link input measurable       attribute(Att0MeasurableAttribute)
         * to inputOutputAttrParent object.
         */
        std::string inputAttributeRelation;
        /**
         * The relation name system uses to link output measurable       attribute(Att0MeasurableAttribute)
         * to inputOutputAttrParent object.
         */
        std::string outputAttributeRelation;
        /**
         * This input flag, indicates to proceed or not , if Validation Context(WorkspaceObject)
         * measurable attributes (Att0MeasurableAttribute) is referenced in Study. This flag
         * will useful only in case if assignAction equals to UnsetInput or  UnsetOutput or
         * SetInputAsOutput or SetOutputAsInput. Values are 'true' or 'false'.
         */
        bool proceedWithImpactedStudies;
    };

    /**
     * AssignMeasurableAttributesResponse2 holds the response of assignMeasuableAttributes.
     * This output structure contains service data with partial errors and outputMap which
     * contains list of Att0MeasurableAttribute objects related to assign action.
     */
    struct AssignMeasurableAttributesResponse2
    {
        /**
         * The Service Data with partial errors for AssignMeasurableAttributeInput2 identified
         * by its clientId.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
        /**
         * A map of string client identifer and list of AssignMeasurableAttributeInfo pairs.
         * <br>
         * If the AssignAction equals to UnsetInput or UnsetOutput, the outputMap will be empty
         * since system deletes all input or output attributes as well as associated relations.
         */
        AssignMeasurableAttributesMap2 outputMap;
    };

    /**
     * This structure represents a measurable attribute and it has the associated information
     * for the measurable attribute.
     */
    struct AttributeInfo2
    {
        /**
         * The source measurable attribute for the Overridden, Input and Output attribute. For
         * source attribute, this field will be NULL.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasurableAttribute>  sourceAttribute;
        /**
         * The measurable attribute object. The object must derive from Att0MeasurableAttribute.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasurableAttribute>  attribute;
        /**
         * Specify the type of Measurable Attribute. Allowed values are SOURCEATTR, OVERRIDDENATTR,
         * INPUTATTR, SYNCCANDIDATE, OUTPUTATTR, PUBLISHCANDIDATE, SOURCEATTRINPUT, SOURCEATTROUTPUT
         */
        std::string attributeType;
        /**
         * The name of the primary occurrence which is associated with measurable attribute.
         */
        std::string occName;
    };

    /**
     * CreateOrModifyAttrInput structure represents all the information needed to create
     * or modify the measurable attribute.
     */
    struct CreateOrUpdateAttrInput
    {
        /**
         * This unique ID is used to identify return data elements and partial errors associated
         * with this input structure.
         */
        std::string clientId;
        /**
         * Name of the relation between parent object and measurable attribute. This relation
         * will be used to create and query the measurable attribute from parent object.
         */
        std::string relationName;
        /**
         * Instance of measurable attribute object for modify use case, provide NULL to create
         * a new attribute.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasurableAttribute>  attribute;
        /**
         * The parent object to create and associate the measurable attributes with. If value
         * for parentLine is also provided then this parameter should be NULL.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::WorkspaceObject>  parentObj;
        /**
         * The parent line in the product structure to create the measurable attributes. If
         * value for parentObj is provided then this parameter will be ignored.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Element>  parentLine;
        /**
         * The context line which represents the current product context. If value for parentObj
         * is provided then this parameter will be ignored.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Awb0Element>  contextLine;
        /**
         * Name of the relation between measurement object and measurement dataset.
         */
        std::string measurementDatasetRelationName;
        /**
         * The Dataset object to attach to measurement.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Dataset>  measurementDatasetObject;
        /**
         * All the information needed to create or modify the measurable attribute object.
         */
        Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::MeasurableAttributeInput attributeObjInput;
        /**
         * All the information needed to create or modify the measurement object.
         */
        Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::ObjectInput measureValueObjInput;
    };

    /**
     * CreateOrUpdateAttrResp represents created or modified measurable attributes for a
     * given input.
     */
    struct CreateOrUpdateAttrOutput
    {
        /**
         * The unmodified value from the CreateOrModifyAttrInput.clientId. This is used by the
         * caller to identify this data structure with the source input data.
         */
        std::string clientId;
        /**
         * Represents created or modified measurable attributes for a given input. All objects
         * must derive from Att0MeasurableAttribute.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasurableAttribute>  measurableAttribute;
        /**
         * True, id the measurable attribute object is an override
         */
        bool isOverriden;
        /**
         * Instance of newly created measure value object.All objects must derive from parent
         * object Att0MeasureValue.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasureValue>  measureValue;
    };

    /**
     * CreateOrUpdateAttrResp represents created or modified measurable attributes for all
     * the inputs.
     */
    struct CreateOrUpdateAttrResp
    {
        /**
         * Represents created or modified measurable attributes for all the inputs.
         */
        std::vector< Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::CreateOrUpdateAttrOutput > attrList;
        /**
         * Standard ServiceData object to hold the partial errors that the operation encounters.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * This structure represent all the measurable attributes for a given parent object.
     */
    struct GetMeasurableAttrOutput2
    {
        /**
         * The unmodified value from the GetMeasurableAttrInput.clientId. This is used by the
         * caller to identify this data structure with the source input data.
         */
        std::string clientId;
        /**
         * The list of attributes for a specific relation.
         */
        std::vector< Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::ParentAttrList2 > attrList;
        /**
         * True if the parentLine is assigned to inputOutputAttrParent in the context of contextLine.
         */
        bool isLineInValidationList;
    };

    /**
     * GetMeasurableAttrResp structure represents all the attributes for the list of parents
     * in input.
     */
    struct GetMeasurableAttrResp2
    {
        /**
         * A list of measurable attributes objects for a given parent.
         */
        std::vector< Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::GetMeasurableAttrOutput2 > parentAttrList;
        /**
         * Standard ServiceData object to hold the partial errors that the operation encounters.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * This structure represents the list of attributes associated with a given parent object
     * using a specific relation.
     */
    struct ParentAttrList2
    {
        /**
         * The name of the relation using which parent object and measurable attributes objects
         * are connected.
         */
        std::string relationType;
        /**
         * The list of measurable attributes associated with the parent object using relationType
         * relation.
         */
        std::vector< Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::AttributeInfo2 > attrObjList;
    };

    /**
     * <i>SyncMeasurableAttributeInput</i> structure represents the criteria to synchronize
     * measurable attribute objects
     */
    struct SyncMeasurableAttributeInput
    {
        /**
         * Identifier defined by client to track the related object.
         */
        std::string clientID;
        /**
         * The parent object holds list of measurable attributes which need to be synchronized.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::WorkspaceObject>  parentObj;
        /**
         * A list of <i>Att0MeasurableAttribute</i> object which needs to be synchronized or
         * published.
         */
        std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasurableAttribute>  > attrCandidates;
    };

    /**
     * <i>SyncMeasurableAttributePref</i> structure represents the synchronization direction(synchonize
     * from source or publish to source), and input relations as well as output relations
     * which are used to find out all input or output measurable attributes.
     */
    struct SyncMeasurableAttributePref
    {
        /**
         * It represents the synchronization direction.
         */
        SyncDirection direction;
        /**
         * A list of relation names from where the system traverses a list of input <i>Att0MeasurableAttribute</i>
         * objects to synchronize.
         * <br>
         * <ul>
         * <li type="disc">If direction is <i>SyncFromSource</i>, this parameter is used along
         * with parentObj to find a list of <i>Att0MeasurableAttribute</i> which will be updated
         * with latest values from source <i>Att0MeasurableAttribute</i> as well as latest <i>Att0MeasurableValue</i>
         * related to each <i>Att0MeasurableAttribute</i>
         * </li>
         * </ul>
         */
        std::vector< std::string > inputRelations;
        /**
         * A list of relation names from where the system traverses a list of output <i>Att0MeasurableAttribute</i>
         * objects to publish.
         * <br>
         * <ul>
         * <li type="disc">If <i>direction</i> is <i>SyncFromSource</i>, this parameter is used
         * along with parentObj to find a list of output <i>Att0MeasurableAttribute</i>. Then
         * the system removes <i>Att0Measurement</i> object for each output <i>Att0MeasurableAttribute</i>
         * object.
         * </li>
         * <li type="disc">If <i>direction</i> is <i>PublishToSource</i>, this parameter is
         * used along with parentObj to find a list of output <i>Att0MeasurableAttribute</i>
         * objects. Then the system will insert the latest <i>Att0MeasurableValue</i> to source
         * <i>Att0MeasurableAttribute</i> for each output <i>Att0MeasurableAttribute</i> object
         * .
         * </li>
         * </ul>
         */
        std::vector< std::string > outputRelations;
    };

    /**
     * <i>SyncMeasurableAttributeResponse</i> holds the response of synchronize Measuable
     * Attributes. This output structure contains service data with partial errors and an
     * outputMap which contains list of <i>Att0MeasurableAttribute</i> objects which have
     * been synchronized.
     */
    struct SyncMeasurableAttributeResponse
    {
        /**
         * The Service Data with partial errors identified by its clientId.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
        /**
         * Map input client ID to list of <i>Att0MeasurableAttribute</i> objects
         */
        SyncMeasurableAttributesMap outputMap;
    };




    /**
     * This operation assigns measurable attribute (Att0MeasurableAttribute) objects to
     * given WorkspaceObject as input or output attributes for product validation or measurement.
     * <br>
     * <br>
     * When an Att0MeasurableAttribute is assigned as input or output attribute, a save-as
     * operation is performed against the source attribute object and new relations will
     * be created to link the new Att0MeasurableAttribute with parent WorkspaceObject. Parent
     * Validaiton context (WorkspaceObject ) attribute can be set as Input or attribute
     * in associated Study(WorkspaceObject). Any update on source attribute will not impact
     * input or output attribute object, and on the contrary.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * 1. A system architect creates a product structure of logical blocks (Fnd0LogicalBlock),
     * and defines for each block its measurable attributes (Att0MeasurableAttribute). As
     * the design of the product architecture evolves, the system architect sets a logical
     * block attribute (Att0MeasurableAttribute) as an input of the validation context(WorkspaceObject),
     * the system builds a copy of the attribute for the validation context(WorkspaceObject),
     * and create related links from input attribute to validation context(WorkspaceObject).
     * System architect can set available Attribute from Validation Context (WorkspaceObject)
     * in Study(WorkspaceObject) as Input or Output for further specific analysis.
     * <br>
     * 2. A system architect creates a product structure of logical blocks (Fnd0LogicalBlock),
     * and defines for each block its measurable attributes (Att0MeasurableAttribute), then
     * sets a logical block attribute (Att0MeasurableAttribute) as an input or output of
     * the validation context(WorkspaceObject). System architect sets Validation Context(WorkspaceObject)
     * attribute as Input or Output on Study(WorkspaceObject). However design changes and
     * system architect needs to un-set the output attribute for the validation context(WorkspaceObject),
     * the system deletes the output attributes as well as its related output relations
     * with validation context(WorkspaceObject). If Validation Context(WorkspaceObject)
     * attribute is used in Study(WorkspaceObject) system will warn user to proceed or not
     * about attribute reference in Study(WorkspaceObject), before deleting its reference
     * from Study(WorkspaceObject). User can ignore or proceed.
     * <br>
     * 3. A system architect creates a product structure of logical blocks (Fnd0LogicalBlock),
     * and defines for each block its measurable attributes (Att0MeasurableAttribute), then
     * sets a logical block attribute (Att0MeasurableAttribute) as an input of the validation
     * context(WorkspaceObject). System architect sets Validation Context(WorkspaceObject)
     * attribute as Input or Output on Study(WorkspaceObject). However design changes and
     * system architect needs to re-set an input attribute as the output attribute of the
     * validation context(WorkspaceObject), the system deletes the input attributes as well
     * as its related input relations, then builds a new copy of the source input attribute
     * as an output attribute for the validation context(WorkspaceObject) and creates related
     * links from output attribute to validation context(WorkspaceObject). If Validation
     * Context(WorkspaceObject) attribute is referenced in Study(WorkspaceObject) and user
     * changes the direction of Validation Context(WorkspaceObject) attribute from input
     * to output or vice-versa, system will automatically change the direction of referenced
     * attribute in Study(WorkspaceObject). Before direction change, system will warn user
     * to proceed or not. User can ignore operation or proceed.
     * <br>
     * 4. A system architect creates a product structure of logical blocks (Fnd0LogicalBlock),
     * and defines for each block its measurable attributes (Att0MeasurableAttribute), then
     * sets a logical block attribute (Att0MeasurableAttribute) as an input of the validation
     * context(WorkspaceObject). System architect may set Validation Context(WorkspaceObject)
     * attribute as Input or Output on Study(WorkspaceObject). However in case of re-set
     * or change direction of Validation Context(WorkspaceObject) attribute, system will
     * not warn, if there is no impact on Studies. System will delete or change direction
     * of attribute in Validation Context(WorkspaceObject) only.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Attribute Target Management AW - This component consists of the Client and Enterprise
     * Tier code and constructs that support Attribute and Target related functionality
     * for Teamcenter Active Workspace application plus SOA, ITK and Preferences.
     *
     * @param inputs
     *        The measurable attribute assignment inputs.
     *
     * @param pref
     *        The measurable attribute assignment configuration.
     *
     * @return
     *         Returns:
     *         <br>
     *         A map of client identifier to the Att0MeasurableAttribute objects. The following
     *         partial errors may be returned:
     *         <br>
     *         <ul>
     *         <li type="disc">185401 - Invalid input or output parent object.
     *         </li>
     *         <li type="disc">185405 - Input/output parent object is null.
     *         </li>
     *         <li type="disc">185406 - The measurable attribute parameter is null.
     *         </li>
     *         <li type="disc">185407 - The parent line must provide to set input/output measurable
     *         attribute.
     *         </li>
     *         <li type="disc">185408 - The context line must provide to set input/output measurable
     *         attribute.
     *         </li>
     *         <li type="disc">185409 - System does not support the given assign action.
     *         </li>
     *         </ul>
     *
     */
    virtual Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::AssignMeasurableAttributesResponse2 assignMeasurableAttributes2 ( const std::vector< Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::AssignMeasurableAttributeInput2 >& inputs,
        const Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::AssignMeasurableAttributePref2&  pref ) = 0;

    /**
     * This operation either creates a new measurable attribute object or modifies the existing
     * measurable attribute object depending on the input parameter.
     * <br>
     * Please refer to documentation for more details on Measurable Attribute object.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * Background
     * <br>
     * A Measurable Attribute is a characteristic of the system which can be externally
     * observed and has a target value or range in the context of the product, which must
     * be satisfied before the product is delivered. It consists of two parts. One is the
     * goal value and the other is the measured/validated value. A measurable attribute
     * may have more than one measured value (dependent of product maturity) and can be
     * seen in context of more than one application object.
     * <br>
     * Example: mass, cost, speed, pressure and other constituents of energy flow
     * <br>
     * <br>
     * 1. User wants to create a measurable attribute on the parent object. For example,
     * user wants to create a measurable
     * <br>
     * attribute 'weight' on parent object 'engine'.
     * <br>
     * 2. User has already created a measurable attribute on the parent object and user
     * wants to update the properties of
     * <br>
     * measurable attribute and / or create a new measure value.
     * <br>
     * 3. The parent object is part of any assembly and now user wants to override the value
     * of measurable attribute
     * <br>
     * properties in the context of product. For example, Engine is part of assembly
     * car and now user would like to change
     * <br>
     * the value of weight attribute on engine in the context of car.
     * <br>
     * 4. User wants to attach a dataset to Measure Value object.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Attribute Target Management AW - This component consists of the Client and Enterprise
     * Tier code and constructs that support Attribute and Target related functionality
     * for Teamcenter Active Workspace application plus SOA, ITK and Preferences.
     *
     * @param inputs
     *        Information needed to create or update the measurable attribute object.
     *
     * @return
     *         The response contains the list of measurable attribute objects which are either created
     *         or modified.
     *         <br>
     *         The following errors may be returned:
     *         <br>
     *         <br>
     *         185401 - Both the parent objects are NULL. Please provide value for either parentObj
     *         or parentLine input parameter.
     *         <br>
     *         185402 - Unable to create new measurable attribute. There is existing attribute on
     *         the parent object with the given name.
     *         <br>
     *         185403 - The input Measure Value type is not valid. Please contact the system administrator.
     *         <br>
     *         214116 - For any requested relation types the relation type name is invalid.
     *         <br>
     *         126214 - Unable to get Measurable Attributes because the provided context line does
     *         not have a BOMViewRevision.
     *
     */
    virtual Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::CreateOrUpdateAttrResp createOrUpdateMeasurableAttribute ( const std::vector< Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::CreateOrUpdateAttrInput >& inputs ) = 0;

    /**
     * This operation gets the list of associated measurable attributes for the input parent
     * objects. A measurable attribute is a characteristic of the system which can be externally
     * observed and has a target value or range in the context of the product, which must
     * be satisfied before the product is delivered. It consists of two parts. One is the
     * goal value and the other is the measured and validated value. A measurable attribute
     * may have more than one measured value (dependent of product maturity) and can be
     * seen in context of more than one application object.
     * <br>
     * Example: mass, cost, speed, pressure and other constituents of energy flow
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * 1. User has already created a measurable attribute on a parent object and now user
     * wants to see the list of attributes present on the object. For example, user has
     * created a measurable attribute 'mass' on 'Engine' and user wants to see the value
     * of attribute 'mass'.
     * <br>
     * 2. User wants to see overridden value of measurable attribute on the parent object
     * present in the assembly. For example, if 'Engine' is part of 'Car' assembly and user
     * has changed the value of 'mass' attribute on Engine in the context of 'Car' then
     * user wants to see the changed attribute value in context of Car.
     * <br>
     * 3. User requires the list of measurable attributes associated with the given model
     * object of a validation contract.
     * <br>
     * 4. User has already created the measurable attribute on Crt0VldnContract object and
     * now user wants to set these attributes as Input or Output on Study object.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Attribute Target Management AW - This component consists of the Client and Enterprise
     * Tier code and constructs that support Attribute and Target related functionality
     * for Teamcenter Active Workspace application plus SOA, ITK and Preferences.
     *
     * @param inputs
     *        A list of parent objects to get associated measurable attributes.
     *
     * @return
     *         The response contains the list of associated measurable attributes objects with the
     *         parent objects provided in input.
     *         <br>
     *         <br>
     *         The following errors may be returned:
     *         <br>
     *         <br>
     *         185401 - Both the parent objects are NULL. Please provide value for either parentObj
     *         or parentLine input parameter.
     *         <br>
     *         214116 - For any requested relation types the relation type name is invalid.
     *         <br>
     *         126214 - Unable to get Measurable Attributes because the provided context line does
     *         not have a BOMViewRevision.
     *
     */
    virtual Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::GetMeasurableAttrResp2 getMeasurableAttributes2 ( const std::vector< Att1::Services::Attrtargetmgmtaw::_2015_03::Attributetargetmanagement::GetMeasurableAttrInput >& inputs ) = 0;

    /**
     * This operation is used to synchronize <i>Att0MeasurableAttribute</i> objects between
     * source <i>Att0MeasurableAttribute</i> instances and target <i>Att0MeasurableAttribute</i>
     * instances. This synchronization operation has two process flows: synchronize from
     * source <i>Att0MeasurableAttribute</i> instances to input <i>Att0MeasurableAttribute</i>
     * instances; and publish from output <i>Att0MeasurableAttribute</i> instances to source
     * <i>Att0MeasurableAttribute</i> instances.
     * <br>
     * <ul>
     * <li type="disc">When synchronize from source to input <i>Att0MeasurableAttribute</i>,
     * an update operation is done against input <i>Att0MeasurableAttribute</i> with latest
     * property values from source <i>Att0MeasurableAttribute</i>. Meanwhile copies the
     * latest <i>Att0MeasurableValue</i> of source <i>Att0MeasurableAttribute</i> and inserts
     * it into the input <i>Att0MeasurableAttribute</i>.
     * </li>
     * <li type="disc">When publish from output to source <i>Att0MeasurableAttribute</i>,
     * the latest <i>Att0MeasurableValue</i> is retrieved from output <i>Att0MeasurableAttribute</i>
     * and inserts it into the latest <i>Att0MeasurableValue</i> list on the source <i>Att0MeasurableAttribute</i>.
     * The source <i>Att0MeasurableAttribute</i> properties will not be updated. If there
     * is an issue during publication, the process stops and all modified objects are be
     * restored.
     * </li>
     * </ul>
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * <ul>
     * <li type="disc">A systems designer creates an analysis request with one or multiple
     * products. He adds the input elements, i.e. system block (<i>Fnd0LogicalBlock</i>),
     * to the analysis request, and set the input measurable attribute (<i>Att0MeasurableAttribute</i>)
     * from the system block to the analysis request. And then transfer the analysis request
     * to the simulation engineer via the workflow. While processing the analysis request,
     * the simulation engineer would be aware that some of input measurable attributes are
     * out-of-date, and he is able to use "Refresh" command to synchronize between the system
     * blocks' attributes and input attributes.
     * </li>
     * <li type="disc">A systems designer creates an analysis request with one or multiple
     * products. He adds the input elements, i.e. system block (<i>Fnd0LogicalBlock</i>),
     * to the analysis request, and set the output measurable attribute (<i>Att0MeasurableAttribute</i>)
     * from the system block to the analysis request. And then transfer the analysis request
     * to the simulation engineer via the workflow. The simulation engineer updates the
     * output measurable attributes according to the simulation test result. And then he
     * is able to use "Publish" command to synchronize between the output attributes and
     * system block's attributes.
     * </li>
     * </ul>
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Attribute Target Management AW - This component consists of the Client and Enterprise
     * Tier code and constructs that support Attribute and Target related functionality
     * for Teamcenter Active Workspace application plus SOA, ITK and Preferences.
     *
     * @param inputs
     *        The synchronization measurable attribute inputs
     *
     * @param pref
     *        The synchronization measurable attribute preference.
     *
     * @return
     *         A map of client identifier to the Att0MeasurableAttribute objects. The following
     *         partial errors may be returned:
     *         <br>
     *         <br>
     *         <ul>
     *         <li type="disc">185017 - The given object is invalid primary object for Input Measurable
     *         Attribute.
     *         </li>
     *         <li type="disc">185018 - The given object is invalid primary object for Output Measurable
     *         Attribute.
     *         </li>
     *         <li type="disc">185025 - Some input Att0MeasurableAttribute objects are out of date,
     *         publication could only be done when all input Att0MeasurableAttribute objects are
     *         up to date.
     *         </li>
     *         <li type="disc">185026 - The given synchronization candidates type does not match
     *         to the source object type.
     *         </li>
     *         <li type="disc">185027 - The validation object is not allowed to publish measurable
     *         attributes, because its release status is not match with pre-defined ones.
     *         </li>
     *         </ul>
     *
     */
    virtual Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::SyncMeasurableAttributeResponse synchronizeMeasuableAttributes ( const std::vector< Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::SyncMeasurableAttributeInput >& inputs,
        const Att1::Services::Attrtargetmgmtaw::_2015_10::Attributetargetmanagement::SyncMeasurableAttributePref&  pref ) = 0;


protected:
    virtual ~Attributetargetmanagement() {}
};
            }
        }
    }
}

#include <att1/services/attrtargetmgmtaw/AttrTargetMgmtAW_undef.h>
#endif

