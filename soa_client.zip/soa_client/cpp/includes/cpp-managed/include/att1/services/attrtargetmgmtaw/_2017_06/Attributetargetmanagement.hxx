/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef ATT1_SERVICES_ATTRTARGETMGMTAW__2017_06_ATTRIBUTETARGETMANAGEMENT_HXX
#define ATT1_SERVICES_ATTRTARGETMGMTAW__2017_06_ATTRIBUTETARGETMANAGEMENT_HXX

#include <teamcenter/soa/client/model/Att0MeasurableAttribute.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <att1/services/attrtargetmgmtaw/AttrTargetMgmtAW_exports.h>

namespace Att1
{
    namespace Services
    {
        namespace Attrtargetmgmtaw
        {
            namespace _2017_06
            {
                class Attributetargetmanagement;

class ATT1SOAATTRTARGETMGMTAWSTRONGMNGD_API Attributetargetmanagement
{
public:

    struct AttachMeasurableAttrInput;
    struct AttachMeasurableAttrOutput;
    struct AttachMeasurableAttrResp;

    /**
     * The structure represents the request details for attaching measurable attributes.
     */
    struct AttachMeasurableAttrInput
    {
        /**
         * A unique string supplied by the caller. This ID is used to identify returned AttachMeasurableAttrOutput
         * elements and Partial Errors associated with this input AttachMeasurableAttrInput.
         */
        std::string clientId;
        /**
         * The given business object where to add the measurable attribute. It must be a type
         * of <b>WorkspaceObject</b> or <b>Awb0Element</b>.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  parentObj;
        /**
         * The list of <b>Att0MeasurableAttribute</b> objects to be added.
         */
        std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasurableAttribute>  > attrList;
        /**
         * The specified relation name.
         */
        std::string relation;
        /**
         * If true, it hard copies the attributes and adds the copied attributes to the parent
         * object. If false, it adds the attributes to the parent object directly.
         */
        bool addAsCopy;
    };

    /**
     * The structure represents the output details with the added attributes and ignored
     * attributes.
     */
    struct AttachMeasurableAttrOutput
    {
        /**
         * Identifying string from the source AttachMeasurableAttrInput
         */
        std::string clientId;
        /**
         * The newly added measurable attributes
         */
        std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasurableAttribute>  > addedAttrList;
        /**
         * The ingored measurable attributes. Because a measurable attribute with the same name
         * exists under the given object.
         */
        std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Att0MeasurableAttribute>  > ignoredAttrList;
    };

    /**
     * The structure represents the response for attaching measurable attributes.
     */
    struct AttachMeasurableAttrResp
    {
        /**
         * A list of outputs with the added measurable attributes and ignored measurable attributes.
         */
        std::vector< Att1::Services::Attrtargetmgmtaw::_2017_06::Attributetargetmanagement::AttachMeasurableAttrOutput > outputs;
        /**
         * The Service Data.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };




    /**
     * Adds a list of Measurable Attributes to the given object via the specified relation.
     * <br>
     * <br>
     * When the given object is the <b>WorkspaceObject</b>,
     * <br>
     * Add as Copy
     * <br>
     * This operation hard copies the input measurable attributes and adds the copied measurable
     * attributes to the <b>WorkspaceObject</b> via the specified relation.
     * <br>
     * Note, the input measurable attribute can't be added, if a measurable attribute exists
     * with the same name under the given <b>WorkspaceObject</b>.
     * <br>
     * Add as Reference
     * <br>
     * This operation adds the input measurable attributes to the <b>WorkspaceObject</b>
     * via the specified relation.
     * <br>
     * <br>
     * When the given object is the <b>Awb0Element</b>, it adds the input measurable attributes
     * to the underlying object for the given <b>Awb0Element</b>.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * <ul>
     * <li type="disc">Users add the measurable attributes as copy to the given <b>WorkspaceObject</b>
     * via the relation <b>Att0AttrRelation</b>.
     * </li>
     * <li type="disc">Users add the measurable attributes as reference to the given WorkspaceObject
     * via the relation <b>IMAN_reference</b>
     * </li>
     * <li type="disc">Users add the measurable attributes as copy to the given <b>Awb0Element</b>
     * via the relation <b>Att0AttrRelation</b>.
     * </li>
     * <li type="disc">Users add the measurable attributes as reference to the given <b>Awb0Element</b>
     * via the relation <b>IMAN_reference</b>
     * </li>
     * </ul>
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Attribute Target Management AW - This component consists of the Client and Enterprise
     * Tier code and constructs that support Attribute and Target related functionality
     * for Teamcenter Active Workspace application plus SOA, ITK and Preferences.
     *
     * @param inputs
     *        A list of structures contains details to add Measurable Attributes to the given object
     *        via the specified relation
     *
     * @return
     *         Contains a list of AttachMeasurableAttrOutput structures (which contain the added
     *         attributes and ignored attributes). Any created objects will be sent back in the
     *         standard ServiceData lists of created objects. Any failure will be returned with
     *         client id mapped to error message in the ServiceData list of partial errors.
     *         <br>
     *         <br>
     *         The following partial errors may be returned:
     *         <br>
     *         <ul>
     *         <li type="disc">185415 - The given object must be a type of WorkspaceObject or Awb0Element.
     *         </li>
     *         </ul>
     *
     */
    virtual Att1::Services::Attrtargetmgmtaw::_2017_06::Attributetargetmanagement::AttachMeasurableAttrResp attachMeasurableAttributes ( const std::vector< Att1::Services::Attrtargetmgmtaw::_2017_06::Attributetargetmanagement::AttachMeasurableAttrInput >& inputs ) = 0;


protected:
    virtual ~Attributetargetmanagement() {}
};
            }
        }
    }
}

#include <att1/services/attrtargetmgmtaw/AttrTargetMgmtAW_undef.h>
#endif

