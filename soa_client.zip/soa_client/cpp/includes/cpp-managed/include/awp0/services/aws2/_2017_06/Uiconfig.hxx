/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef AWP0_SERVICES_AWS2__2017_06_UICONFIG_HXX
#define AWP0_SERVICES_AWS2__2017_06_UICONFIG_HXX

#include <awp0/services/aws2/_2016_12/Uiconfig.hxx>
#include <awp0/services/internal/aws2/_2016_03/Uiconfig.hxx>
#include <teamcenter/soa/client/model/Fnd0AbstractCommand.hxx>
#include <teamcenter/soa/client/model/Fnd0Client.hxx>
#include <teamcenter/soa/client/model/Fnd0ClientScope.hxx>
#include <teamcenter/soa/client/model/Fnd0UIConfigCollectionRel.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <awp0/services/aws2/AWS2_exports.h>

namespace Awp0
{
    namespace Services
    {
        namespace Aws2
        {
            namespace _2017_06
            {
                class Uiconfig;

class AWP0SOAAWS2STRONGMNGD_API Uiconfig
{
public:

    struct ClientConfigurations;
    struct ColumnConfig;
    struct ColumnConfigData;
    struct ViewModelPropertyDescriptor;
    struct ColumnDefInfo;
    struct CommandConfigData;
    struct GetUIConfigInput;
    struct GetUIConfigResponse;

    /**
     * Map to store the property constant name and value pair.
     */
    typedef std::map< std::string, std::string > PropertyConstantsMap;

    /**
     * This structure contains command and column configuration data for the indicated client.
     */
    struct ClientConfigurations
    {
        /**
         * The client for which the configurations are applicable. It is to match the clientName
         * in ClientInput SOA struture.
         */
        std::string client;
        /**
         * A list of column configurations.
         */
        std::vector< Awp0::Services::Aws2::_2017_06::Uiconfig::ColumnConfigData > columnConfigurations;
        /**
         * A list of command configurations.
         */
        std::vector< Awp0::Services::Aws2::_2017_06::Uiconfig::CommandConfigData > commandConfigurations;
    };

    /**
     * This structure contains information for a column configuration within a client scope
     * URI. It contains a unique column config id, a list of column definition information,
     * and the default sort direction.
     */
    struct ColumnConfig
    {
        /**
         * The unique identifier of the column.
         */
        std::string columnConfigId;
        /**
         * How the columns are sorted. Valid values are Ascending and Descending.
         */
        std::string sortDirection;
        /**
         * The operation that was used to finalize the columns to be returned back.
         * <br>
         * Valid values are:  "Intersection", "Union" and "Configured".
         */
        std::string operationType;
        /**
         * Ordered list of column details.
         */
        std::vector< Awp0::Services::Aws2::_2017_06::Uiconfig::ColumnDefInfo > columns;
    };

    /**
     * This structure returns information about the column configuration definitions for
     * a scope, hosting client and client scope.
     */
    struct ColumnConfigData
    {
        /**
         * The scope for which the column data is applicable.
         */
        std::string scope;
        /**
         * The scope name for which the column data is applicable.
         */
        std::string scopeName;
        /**
         * The name of hosting client for which the list of column configurations is applicable.
         * This value must correspond to the value of the property fnd0ClientName for an <b>Fnd0Client</b>
         * object in the Teamcenter database.
         */
        std::string hostingClient;
        /**
         * The client scope for which the list of column configurations is applicable. This
         * must match a value of fnd0ClientScopeURI which is the unique identifier of a client
         * scope (<b>Fnd0ClientScope</b>).
         */
        std::string clientScopeURI;
        /**
         * List of column configuration details.
         */
        std::vector< Awp0::Services::Aws2::_2017_06::Uiconfig::ColumnConfig > columnConfigurations;
    };

    /**
     * Represents the property descriptor details for a ViewModelProperty.
     */
    struct ViewModelPropertyDescriptor
    {
        /**
         * Type name of the source object on which the property is defined.
         */
        std::string srcObjectTypeName;
        /**
         * Name of the property.
         */
        std::string propertyName;
        /**
         * Has value as true in case of array properties and value as false for single valued
         * properties.
         */
        bool isArray;
        /**
         * A map(string,string) consisting of propertyConstant name as key and  and value being
         * the property constant value.
         */
        PropertyConstantsMap propConstants;
        /**
         * Display name of the property.
         */
        std::string displayName;
        /**
         * Indicates the LOV category, if the property is attached to LOV.
         */
        int lovCategory;
        /**
         * LOV object reference associated with the property.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  lov;
        /**
         * Maximimum number of elements allowed in case of VLA properties.
         */
        int maxArraySize;
        /**
         * Max allowed length for the property
         */
        int maxLength;
        /**
         * Indicates the property type. Valid property types are:
         * <br>
         * 1 - attribute.
         * <br>
         * 2 - Reference Property.
         * <br>
         * 3 - Relation Property.
         * <br>
         * 4 - Compound Property.
         * <br>
         * 5 - Runtime Property.
         * <br>
         * 6 - Operation input.
         */
        int propertyType;
        /**
         * Indicates the value type for the property. Valid value types are:
         * <br>
         * 1 - Char
         * <br>
         * 2 - Date
         * <br>
         * 3 - Double
         * <br>
         * 4 - Float
         * <br>
         * 5 - Integer
         * <br>
         * 6 - Boolean
         * <br>
         * 7 - Short Integer
         * <br>
         * 8 - String
         * <br>
         * 9 - Type Reference
         * <br>
         * 10 - UnTyped Reference
         * <br>
         * 11 - External Reference
         * <br>
         * 12 - Note
         * <br>
         * 13 - Typed Relation
         * <br>
         * 14 - UnTyped Relation
         */
        int valueType;
    };

    /**
     * Contains details about a specific column. This includes the type of object for which
     * the column is applicable, the name of the property displayed in the column, a flag
     * indicating if the column should be used to order information displayed in the client
     * and pixel width and the display name of the property.
     */
    struct ColumnDefInfo
    {
        /**
         * If true, the column is used to sort the information displayed to the user; otherwise,
         * not used.
         */
        bool sortByFlag;
        /**
         * The pixel width for the column. Valid pixel widths are values between 1 and 500.
         */
        int pixelWidth;
        /**
         * The column order value is used to arrange the columns in order.
         */
        int columnOrder;
        /**
         * True if the column should be hidden on the client user interface.
         */
        bool hiddenFlag;
        /**
         * Sort priority set on column helps identify the order in which the columns should
         * be used during sort. Sort priority value will be zero for columns not marked for
         * sorting.
         */
        int sortPriority;
        /**
         * How the columns are sorted. Valid values are: "Ascending" and "Descending". This
         * value will be empty if the column is not marked for sorting.
         */
        std::string colDefSortDirection;
        /**
         * List of ViewModelPropertyDescriptors required to render the object properties in
         * AW client.
         */
        Awp0::Services::Aws2::_2017_06::Uiconfig::ViewModelPropertyDescriptor propDescriptor;
        /**
         * Valid Teamcenter type for which the column property has been defined
         */
        std::string columnSrcType;
    };

    /**
     * This structure returns information about the command configuration definitions for
     * a client scope URI.
     */
    struct CommandConfigData
    {
        /**
         * This structure returns information about the command configuration definitions for
         * a client scope URI.
         */
        std::string scopeName;
        /**
         * The hosting <b>Fnd0Client</b> for which the command data is applicable.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Fnd0Client>  hostingClient;
        /**
         * The <b>Fnd0ClientScope</b> containing the list of command configurations.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Fnd0ClientScope>  clientScope;
        /**
         * A list of all top level and child command collections in the client scope.
         */
        std::vector< Awp0::Services::Aws2::_2016_12::Uiconfig::CommandCollectionInfo > cmdCollections;
        /**
         * A list of index values into cmdCollections list for top level command collections
         * in the client scope.
         */
        std::vector< int > cmdCollectionIndex;
        /**
         * A list of all <b>Fnd0AbstractCommand</b> objects accessible in the client scope.
         */
        std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Fnd0AbstractCommand>  > commands;
        /**
         * A list of all <b>Fnd0UIConfigCollectionRel</b> objects that associate top level command
         * collections with client scope.
         */
        std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Fnd0UIConfigCollectionRel>  > commandCollectionRels;
        /**
         * A list of visible <b>Fnd0AbstractCommand</b> objects accessible in the client scope.
         */
        std::vector< Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::Fnd0AbstractCommand>  > visibleCommands;
    };

    /**
     * Contains input information required to retrieve UI configurations from the Teamcenter
     * database.
     */
    struct GetUIConfigInput
    {
        /**
         * A list of client scope URIs representing, for example location.sublocation in Active
         * Workspace. (Fnd0ClientScope::fnd0ClientScopeURI). If empty, the UI Configuration
         * for all client scopes are returned.
         */
        std::vector< std::string > clientScopeURIs;
        /**
         * The scope of the desired UI configuration information. This includes the name of
         * the scope (i.e. a user, group or role) and scope query parameter information.
         */
        Awp0::Services::Aws2::_2016_12::Uiconfig::ScopeInput scope;
        /**
         * Client information including client name and hosting client name.
         */
        Awp0::Services::Aws2::_2016_12::Uiconfig::ClientInput client;
        /**
         * A list of command context name value pairs, Supprted key/value pairs are : isHosted"="true|false",
         * - if true , active workspace clinet is hosted in another application such as NX.
         * If false, active workspace client is stand alone. "productContext"=productContextUid.
         */
        std::vector< Awp0::Services::Internal::Aws2::_2016_03::Uiconfig::CommandContextInfo > commandContextInfo;
    };

    /**
     * This structure returns information to the client about column configuration and command
     * applicability. The ServiceData contains information about errors encountered during
     * processing.
     */
    struct GetUIConfigResponse
    {
        /**
         * ServiceData structure containing errors and command, command collection and icon
         * objects. If there is an error retrieving the configuration information, the error
         * added to the ServiceData as a partial error.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
        /**
         * List of configuration information including command and column information.
         */
        std::vector< Awp0::Services::Aws2::_2017_06::Uiconfig::ClientConfigurations > uiConfigInfo;
    };




    /**
     * This operation returns information used by the client to render the User Interface.
     * The information returned includes command and column configuration information. The
     * returned information includes Fnd0CommandCollectionRel objects that associate the
     * top level command collections to client scope in CommandConfigData structure.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param getUiConfigsIn
     *        Contains input information required to retrieve UI configurations from the Teamcenter
     *        database.
     *
     * @return
     *         Returns: A list of command and column configurations based on the input provided
     *         to the operation. The following partial errors may be returned:
     *         <br>
     *         141112-Invalid Scope for the client.
     *         <br>
     *         141113-Invalid Client Scope.
     *
     */
    virtual Awp0::Services::Aws2::_2017_06::Uiconfig::GetUIConfigResponse getUIConfigs3 ( const std::vector< Awp0::Services::Aws2::_2017_06::Uiconfig::GetUIConfigInput >& getUiConfigsIn ) = 0;


protected:
    virtual ~Uiconfig() {}
};
            }
        }
    }
}

#include <awp0/services/aws2/AWS2_undef.h>
#endif

