/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef AWP0_SERVICES_AWS2_UICONFIGSERVICE_HXX
#define AWP0_SERVICES_AWS2_UICONFIGSERVICE_HXX

#include <awp0/services/aws2/_2016_12/Uiconfig.hxx>
#include <awp0/services/aws2/_2017_06/Uiconfig.hxx>



#include <teamcenter/soa/client/Connection.hxx>
#include <new> // for size_t
#include <teamcenter/soa/common/MemoryManager.hxx>

#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable : 4996  )
#endif

#include <awp0/services/aws2/AWS2_exports.h>

namespace Awp0
{
    namespace Services
    {
        namespace Aws2
        {
            class UiconfigService;

/**
 * The UIConfig service provides operations to support confgurable Teamcenter commands
 * and columns. These configurations are persisted in the Teamcenter database and defined
 * using the Business Modeler IDE.
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libawp0soaaws2strongmngd.dll
 * </li>
 * <li type="disc">libawp0soaaws2types.dll (runtime dependency)
 * </li>
 * </ul>
 */

class AWP0SOAAWS2STRONGMNGD_API UiconfigService
    : public Awp0::Services::Aws2::_2016_12::Uiconfig,
             public Awp0::Services::Aws2::_2017_06::Uiconfig
{
public:
    static UiconfigService* getService( Teamcenter::Soa::Client::Connection* );


    /**
     * This operation returns information used by the client to render the User Interface.
     * The information returned includes command and column configuration information. This
     * operation replaces getUIConfigs operation, it returns the Awp0CommandCollectionRel
     * objects that associate the top level command collections to client scope in CommandConfigData2
     * structure instead of Awp0CommandCollection objects in CommandConfigData.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param getUiConfigsIn
     *        Contains input information required to retrieve UI configurations from the Teamcenter
     *        database.
     *
     * @return
     *         Returns: A list of command and column configurations based on the input provided
     *         to the operation. The following partial errors may be returned: 141112-Invalid Scope
     *         for the client. 141113-Invalid Client Scope.
     *
     * @deprecated
     *         As of ActiveWorkspace3.3, this operation is deprecated and created new SOA getUIConfigs3
     *         in AW3.3.0 release. So use new service definition Awp0::Soa::AWS2::UiConfig::getUIConfigs3.
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of ActiveWorkspace3.3, this operation is deprecated and created new SOA getUIConfigs3 in AW3.3.0 release. So use new service definition Awp0::Soa::AWS2::UiConfig::getUIConfigs3."))
#endif
    virtual Awp0::Services::Aws2::_2016_12::Uiconfig::GetUIConfigResponse getUIConfigs2 ( const std::vector< Awp0::Services::Aws2::_2016_12::Uiconfig::GetUIConfigInput >& getUiConfigsIn ) = 0;

    /**
     * This operation returns information used by the client to render the User Interface.
     * The information returned includes command and column configuration information. The
     * returned information includes Fnd0CommandCollectionRel objects that associate the
     * top level command collections to client scope in CommandConfigData structure.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param getUiConfigsIn
     *        Contains input information required to retrieve UI configurations from the Teamcenter
     *        database.
     *
     * @return
     *         Returns: A list of command and column configurations based on the input provided
     *         to the operation. The following partial errors may be returned:
     *         <br>
     *         141112-Invalid Scope for the client.
     *         <br>
     *         141113-Invalid Client Scope.
     *
     */
    virtual Awp0::Services::Aws2::_2017_06::Uiconfig::GetUIConfigResponse getUIConfigs3 ( const std::vector< Awp0::Services::Aws2::_2017_06::Uiconfig::GetUIConfigInput >& getUiConfigsIn ) = 0;


    SOA_CLASS_NEW_OPERATORS_WITH_IMPL("UiconfigService")

};
        }
    }
}


#ifdef WIN32
#pragma warning ( pop )
#endif

#include <awp0/services/aws2/AWS2_undef.h>
#endif

