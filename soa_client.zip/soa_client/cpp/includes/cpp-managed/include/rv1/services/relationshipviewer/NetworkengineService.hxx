/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef RV1_SERVICES_RELATIONSHIPVIEWER_NETWORKENGINESERVICE_HXX
#define RV1_SERVICES_RELATIONSHIPVIEWER_NETWORKENGINESERVICE_HXX

#include <rv1/services/relationshipviewer/_2012_10/Networkengine.hxx>
#include <rv1/services/relationshipviewer/_2014_11/Networkengine.hxx>



#include <teamcenter/soa/client/Connection.hxx>
#include <new> // for size_t
#include <teamcenter/soa/common/MemoryManager.hxx>

#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable : 4996  )
#endif

#include <rv1/services/relationshipviewer/RelationshipViewer_exports.h>

namespace Rv1
{
    namespace Services
    {
        namespace Relationshipviewer
        {
            class NetworkengineService;

/**
 * network engine
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">librv1soarelationshipviewerstrongmngd.dll
 * </li>
 * <li type="disc">librv1soarelationshipviewertypes.dll (runtime dependency)
 * </li>
 * </ul>
 */

class RV1SOARELATIONSHIPVIEWERSTRONGMNGD_API NetworkengineService
    : public Rv1::Services::Relationshipviewer::_2012_10::Networkengine,
             public Rv1::Services::Relationshipviewer::_2014_11::Networkengine
{
public:
    static NetworkengineService* getService( Teamcenter::Soa::Client::Connection* );


    /**
     * The operation will create the specified relation between the input objects (primary
     * and secondary objects) for each input structure.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * You can create relations that can be represented as edges in network graph. Such
     * as GRM (General Relation Management) relation, BOM structure and PS Connection.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param inputs
     *        A list of CreateRelationInput structure.
     *
     * @return
     *         The response contains a list of created network edges which are encapsulation of
     *         the created relation. Any failure will be returned with the input clientId mapped
     *         to the error message in the ServiceData list of partial errors.
     *         <br>
     *         116001 (error):&nbsp;&nbsp;&nbsp;&nbsp; The specified relation can not be created
     *         between the selected two business objects.
     *         <br>
     *         116002 (error):&nbsp;&nbsp;&nbsp;&nbsp; Primary or secondary object is not specified.
     *         <br>
     *         116003 (error):&nbsp;&nbsp;&nbsp;&nbsp; The specified relation type is not supported
     *         in Teamcenter.
     *
     */
    virtual Rv1::Services::Relationshipviewer::_2012_10::Networkengine::CreateRelationsResponse createRelations ( const std::vector< Rv1::Services::Relationshipviewer::_2012_10::Networkengine::CreateRelationInput >& inputs ) = 0;

    /**
     * Provides a style definition which can be used for client to render graph data. For
     * example, it returns style definition of node shape and color,edge type and color.
     *
     * @return
     *         Graph style definition in XML string. The caller of this method need parse XML to
     *         get style definition.
     *
     */
    virtual Rv1::Services::Relationshipviewer::_2012_10::Networkengine::GraphStyleDefResponse getGraphStyleDef (  ) = 0;

    /**
     * The RelationShipViewer library provides graph (nodes connected via edges) views of
     * data elements. Each graph has a defined view type. The view type is a container for
     * the rules that determine what should be included in a graph and how it should be
     * represented. The choice of graph view is determined based on business need.
     * <br>
     * <br>
     * This API provides a list of the available graph view types. A graph view is a set
     * of configuration that can be used for network expansion. For example: view name,
     * graph parameters, inquires, graph presentation rules. The view list is role based,
     * different role may get different view list.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Diagram Management - Diagram Management
     *
     * @return
     *         The list of supported views
     *
     * @deprecated
     *         As of Teamcenter 10.1.2, use getViews3 instead
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 10.1.2, use getViews3 instead"))
#endif
    virtual Rv1::Services::Relationshipviewer::_2012_10::Networkengine::GraphTypeListResponse getViews (  ) = 0;

    /**
     * This operation provides a list of the available graph view types identified by the
     * input key. A graph view is a set of configuration that can be used for network expansion.
     * For example: view name, graph parameters, inquires, graph presentation rules. The
     * view list is role based, different role may get different view list.
     * <br>
     * <br>
     * The RelationShipViewer library provides graph (nodes connected via edges) views of
     * data elements. Each graph has a defined view type. The view type is a container for
     * the rules that determine what should be included in a graph and how it should be
     * represented. The choice of graph view is determined based on business need.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param key
     *        The key to identify a list of views. Each graph view have a key field, but not the
     *        identifier.
     *
     * @return
     *         The list of supported views identified by input key. If no view match the input key,
     *         a empty view list will be returned.
     *
     * @deprecated
     *         As of Teamcenter 10.1.2, use getViews3 instead
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 10.1.2, use getViews3 instead"))
#endif
    virtual Rv1::Services::Relationshipviewer::_2012_10::Networkengine::GraphTypeListResponse getViews2 ( const std::string&  key ) = 0;

    /**
     * This API produces a graph of data corresponding to the input parameters. For Teamcenter
     * data source, the graph nodes are Teamcenter business objects, the relation between
     * the returns objects and the input root objects may be Teamcenter Relation class (GRM)
     * relationships, TraceLink and its sub types, Where used, where referenced, BOM relation
     * and Tag reference.
     *
     * @param rootIds
     *        A list of object IDs that input as network root nodes. If data source is Teamcenter,
     *        it is the UID list of Teamcenter business objects.
     *
     * @param viewName
     *        The name of graph view that will be used for network expansion. Call getViews() service
     *        method to get available view names.
     *
     * @param graphParamMap
     *        A (string, list(string)) map of graph parameter name and parameter values, such as
     *        expansion level, expansion direction. Parameters are inputs leveraged by the graph
     *        generation logic. Call getViews() service method to get available graph parameters
     *        supported by the specified view.
     *
     * @param inquiries
     *        A list of inquiries. Inquiries identify calculations that are performed using the
     *        graph contents as inputs. The full supported inquires can be got by calling getView()
     *        method. Currently supported inquires: numOfNodes, numOfEdges.
     *
     * @return
     *         Return network data of the input root object, answers to the inqures and soa service
     *         data. If data source is TC, the nodes of graph is Teamcenter business objects list,
     *         they are filled in serviceData as plain objects.
     *
     */
    virtual Rv1::Services::Relationshipviewer::_2012_10::Networkengine::NetworkResponse queryNetwork ( const std::vector< std::string >& rootIds,
        const std::string&  viewName,
        const GraphParamMap&  graphParamMap,
        const std::vector< std::string >& inquiries ) = 0;

    /**
     * This operation produces a graph of data corresponding to the input parameters. The
     * graph nodes are Teamcenter business objects, the relation between the returned objects
     * and the input root objects may be Teamcenter Relation class (GRM) relationships,
     * TraceLink and its sub types, Where used, where referenced, BOM relation and Tag reference.
     * You can query relations supported in Teamcenter for the input root Business Objects,
     * such as GRM (General Relationship Management) relation, BOM structure, Connectility,
     * etc.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param input
     *        Input parameter for querying network.
     *
     * @return
     *         Return network data of the input root object and answers to the inqures . The nodes
     *         of the graph are returned as plain objects in the ServiceData .
     *         <br>
     *         116011(error):&nbsp;&nbsp;&nbsp;&nbsp;  Not all input root Ids can identify valid
     *         business objects.
     *         <br>
     *         116012(error):&nbsp;&nbsp;&nbsp;&nbsp;  Configuration data doesn't exist for the
     *         specified graph view.
     *         <br>
     *         116013(error):&nbsp;&nbsp;&nbsp;&nbsp;  Query service index out of range.
     *         <br>
     *         116014(error):&nbsp;&nbsp;&nbsp;&nbsp;  Expansion direction isn't supported.
     *
     */
    virtual Rv1::Services::Relationshipviewer::_2012_10::Networkengine::NetworkResponse queryNetwork2 ( const Rv1::Services::Relationshipviewer::_2012_10::Networkengine::QueryNetworkInputs&  input ) = 0;

    /**
     * This operation provides a list of the available graph view types identified by the
     * input key. A graph view is a set of configuration that can be used for network expansion.
     * For example: localized view name and category types which classify a list of supported
     * Teamcenter Business Object types, legend color of each category types. The view list
     * is role based, different role may get different view list.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param key
     *        The key to identify a list of views. Each graph view have a key field, but not the
     *        identifier.
     *
     * @return
     *         The list of supported views identified by input key. If no view match the input key,
     *         a empty view list will be returned. Partial Errors are returned when:  #142003 (error)
     *         The view configuration does not exist.  #142004 (error)   The view configuration
     *         file could not be parsed.
     *
     */
    virtual Rv1::Services::Relationshipviewer::_2014_11::Networkengine::GraphTypeListResponse getViews3 ( const std::string&  key ) = 0;


    SOA_CLASS_NEW_OPERATORS_WITH_IMPL("NetworkengineService")

};
        }
    }
}


#ifdef WIN32
#pragma warning ( pop )
#endif

#include <rv1/services/relationshipviewer/RelationshipViewer_undef.h>
#endif

