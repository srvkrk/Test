/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef RV1_SERVICES_RELATIONSHIPVIEWER__2012_10_NETWORKENGINE_HXX
#define RV1_SERVICES_RELATIONSHIPVIEWER__2012_10_NETWORKENGINE_HXX

#include <teamcenter/soa/client/ModelObject.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <rv1/services/relationshipviewer/RelationshipViewer_exports.h>

namespace Rv1
{
    namespace Services
    {
        namespace Relationshipviewer
        {
            namespace _2012_10
            {
                class Networkengine;

class RV1SOARELATIONSHIPVIEWERSTRONGMNGD_API Networkengine
{
public:

    struct CreateRelationInput;
    struct CreateRelationsResponse;
    struct Edge;
    struct Graph;
    struct RGBValue;
    struct GraphFilter;
    struct GraphGroup;
    struct GraphInquiry;
    struct GraphParameterInfo;
    struct GraphStyleDefResponse;
    struct GraphTypeListResponse;
    struct GraphViewDescription;
    struct NetworkResponse;
    struct Node;
    struct QueryNetworkInputs;
    struct Type;

    /**
     * The query mode enumeration.
     */
    enum QueryModeEnum{ DegreeOnly,
                 ExpandOnly,
                 ExpandAndDegree
                 };

    /**
     * the inquiry/answer map
     */
    typedef std::map< std::string, std::string > GraphInquiryMap;

    /**
     * Network graph parameter map
     */
    typedef std::map< std::string, std::vector< std::string > > GraphParamMap;

    /**
     * The map with the key of input node uid to output node.
     */
    typedef std::map< std::string, Node > NodeUpdateMap;

    /**
     * The map contains key and value for string property.
     */
    typedef std::map< std::string, std::string > StringPropertyMap;

    /**
     * Input struct for createRelations operation.
     */
    struct CreateRelationInput
    {
        /**
         * Unique client identifier, optional.
         */
        std::string clientId;
        /**
         * The relation type to create between the two input Business Objects. For example:
         * FND_TraceLink, PSConnection, Content. You can get all the supported relation type
         * decriptions by service opertion NetworkEngine .getView2().
         */
        std::string relationType;
        /**
         * The primary object to create relation from.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  primaryObject;
        /**
         * The secondary object to create relation to.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  secondaryObject;
        /**
         * The (string, string) map contains properties for relation creation.
         */
        StringPropertyMap props;
    };

    /**
     * Output struct for createRelations operation.
     */
    struct CreateRelationsResponse
    {
        /**
         * Identifier that helps the client to track the relation(s) created.
         */
        std::string clientId;
        /**
         * The list of new created network edges which representing the relation between Business
         * Objects.
         */
        std::vector< Rv1::Services::Relationshipviewer::_2012_10::Networkengine::Edge > edges;
        /**
         * The (string,Node) map contains the uid of input node and output node to be updated.
         * This is especially useful for BOM struction creation, as the input is uid of ItemRevision,
         * while the output is a BomLine node, so client can update network if necessary.
         */
        NodeUpdateMap nodeUpdates;
        /**
         * Service data including partial errors.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * The structure of edge.
     */
    struct Edge
    {
        /**
         * Left node id
         */
        std::string leftId;
        /**
         * Right node id.
         */
        std::string rightId;
        /**
         * The logical type of the edge. It is localized.
         */
        std::string relationType;
        /**
         * Underlining Teamcenter object.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  metaObject;
        /**
         * The start port object associated with the meta object.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  startPortObject;
        /**
         * The end port object associated with the meta object.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  endPortObject;
        /**
         * A map of property name and property value pairs  (string/string).
         */
        StringPropertyMap props;
    };

    /**
     * Structure of network graph data.
     */
    struct Graph
    {
        /**
         * Graph name of the network.
         */
        std::string viewName;
        /**
         * A list of graph root IDs. If data source is Teamcenter, it is the UID list of Teamcenter
         * business objects.
         */
        std::vector< std::string > rootIds;
        /**
         * The cursor point to query service that going to be called. For initial query, set
         * service cursor to 0.
         */
        int serviceCursor;
        /**
         * A list of Node structures.
         */
        std::vector< Rv1::Services::Relationshipviewer::_2012_10::Networkengine::Node > nodes;
        /**
         * A list of Edge structures.
         */
        std::vector< Rv1::Services::Relationshipviewer::_2012_10::Networkengine::Edge > edges;
        /**
         * A (string,string) map of inquery and answer pairs.
         */
        GraphInquiryMap analysisResult;
        /**
         * The flag indicates whether it's a partial graph.
         */
        bool isPartial;
    };

    /**
     * Structure for representing color using RGB values, used in structure GraphFilter.
     */
    struct RGBValue
    {
        /**
         * The red component of color.
         */
        double redValue;
        /**
         * The green component of color.
         */
        double greenValue;
        /**
         * The blue component of color.
         */
        double blueValue;
    };

    /**
     * Structure for representing information of a filter item, including filter name, RGB
     * values to color the legend of the filter at client side. It is used in structure
     * GraphGroup.
     */
    struct GraphFilter
    {
        /**
         * name of the filter
         */
        std::string name;
        /**
         * The color used for legend of this filter at client side
         */
        Rv1::Services::Relationshipviewer::_2012_10::Networkengine::RGBValue color;
        /**
         * The list of types belong to this category.
         */
        std::vector< Rv1::Services::Relationshipviewer::_2012_10::Networkengine::Type > types;
    };

    /**
     * The graph group is a group name with a list of filters. A filter take effect either
     * on node or edge, it filts out graph that fall into its type. It is used in structure
     * GraphViewDescription.
     */
    struct GraphGroup
    {
        /**
         * Backend name of the group. Currently, there are two available groups, relations and
         * objects.
         */
        std::string name;
        /**
         * The list of graph group filter names. For example: the relations graph group may
         * have Attach, Tracability, Structure, Folder, Connectivity as filters. The objects
         * graph group may have Requirement, Functional, Logical, Physical, Dataset, Plant as
         * filters.
         */
        std::vector< Rv1::Services::Relationshipviewer::_2012_10::Networkengine::GraphFilter > filters;
    };

    /**
     * The supported inquiry of graph.
     */
    struct GraphInquiry
    {
        /**
         * Backend name of the inquiry. A inquery is a short query clause that can be used to
         * retrieve information from network graph.
         */
        std::string name;
        /**
         * Description of the inquiry. Not localized.
         */
        std::string description;
    };

    /**
     * The info of graph parameter
     */
    struct GraphParameterInfo
    {
        /**
         * Backend name of the parameter.
         */
        std::string name;
        /**
         * The regular expression that used to validate the parameter value.
         */
        std::string valueMask;
        /**
         * The value type of the parameter. Currently supported types: int, double, string.
         */
        std::string type;
        /**
         * Default value of the parameter
         */
        std::string defaultValue;
        /**
         * the description of the parameter. Not localized.
         */
        std::string description;
    };

    /**
     * graph style definition
     */
    struct GraphStyleDefResponse
    {
        /**
         * XML string contains graph style definition.
         */
        std::string styleXMLStr;
        /**
         * Service data contains the list of created or modified objects and also the partial
         * errors is used to report any partial failures.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * Graph type response.
     */
    struct GraphTypeListResponse
    {
        /**
         * A list of  role based avaliable graph views. Different role may get different view
         * list.
         */
        std::vector< Rv1::Services::Relationshipviewer::_2012_10::Networkengine::GraphViewDescription > views;
        /**
         * Service data contains the partial errors which used to report any partial failures.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * The description of a graph view
     */
    struct GraphViewDescription
    {
        /**
         * Name of the graph view. It is also the identifier of graph view.
         */
        std::string name;
        /**
         * the default layout of the view
         */
        std::string defaultLayout;
        /**
         * the default expansion direction of the view
         */
        std::string defaultExpandDirection;
        /**
         * Flag to indicate whether the view is visible on graph control panel.
         */
        bool visible;
        /**
         * Flag to indicate whether the graph view is in diagram mode by default.
         */
        bool diagramMode;
        /**
         * The list of graph view parameters.
         */
        std::vector< Rv1::Services::Relationshipviewer::_2012_10::Networkengine::GraphParameterInfo > parameters;
        /**
         * The list of supported graph view inquiries. For example: numOfNodes, numOfEdges.
         */
        std::vector< Rv1::Services::Relationshipviewer::_2012_10::Networkengine::GraphInquiry > inquiries;
        /**
         * The list of graph view groups.
         */
        std::vector< Rv1::Services::Relationshipviewer::_2012_10::Networkengine::GraphGroup > groups;
    };

    /**
     * network response
     */
    struct NetworkResponse
    {
        /**
         * Graph data of the network.
         */
        Rv1::Services::Relationshipviewer::_2012_10::Networkengine::Graph graph;
        /**
         * Service data contains the list of Teamcenter business objects and also the partial
         * errors is used to report any partial failures.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * node of the graph
     */
    struct Node
    {
        /**
         * Node id. A unique immutable identifier of the node. It is business object UID for
         * Teamcenter data source.
         */
        std::string id;
        /**
         * Name of node
         */
        std::string name;
        /**
         * Underlying Teamcenter object. For example: BomLine, Item, ItemRevision, Function
         * etc. Can be null. For external data source, it can be RuntimeObject.
         */
        Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject>  metaObject;
        /**
         * A map of property name and property value pairs (string/string). For example, [in_degree,
         * 2], [out_degree, 4].
         */
        StringPropertyMap props;
    };

    /**
     * The input structure containing parameters for query network.
     */
    struct QueryNetworkInputs
    {
        /**
         * A list of object IDs that input as network root nodes. If data source is Teamcenter,
         * it is the UID list of Teamcenter business objects.
         */
        std::vector< std::string > rootIds;
        /**
         * The name of graph view that will be used for network expansion. Call getViews() service
         * method to get available view names.
         */
        std::string viewName;
        /**
         * The query mode that applied to this query operation.
         */
        QueryModeEnum queryMode;
        /**
         * The cursor of the start service index in service list. It's set to 0 for initial
         * call. If client get a partial graph by queryNetwork2 operation, it can be set great
         * than 0 to get remaining part of graph.
         */
        int serviceCursor;
        /**
         * A map of graph parameter name and parameter value list (string / list of string),
         * such as expansion level, expansion direction. Parameters are inputs leveraged by
         * the graph generation logic. Call getViews() service method to get available graph
         * parameters supported by the specified view.
         */
        GraphParamMap graphParamMap;
        /**
         * A list of inquiries.. Inqueries identify calculations that are performed using the
         * graph contents as inputs. The full supported inquires can be got by calling getView()
         * method. Currently supported inquires: numOfNodes, numOfEdges.
         */
        std::vector< std::string > inquiries;
    };

    /**
     * The graph element type structure, used in structure GraphFilter.
     */
    struct Type
    {
        /**
         * The internal type name.
         */
        std::string internalName;
        /**
         * The display name of type.
         */
        std::string displayName;
    };




    /**
     * The operation will create the specified relation between the input objects (primary
     * and secondary objects) for each input structure.
     * <br>
     * <br>
     * <b>Use Cases:</b>
     * <br>
     * You can create relations that can be represented as edges in network graph. Such
     * as GRM (General Relation Management) relation, BOM structure and PS Connection.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param inputs
     *        A list of CreateRelationInput structure.
     *
     * @return
     *         The response contains a list of created network edges which are encapsulation of
     *         the created relation. Any failure will be returned with the input clientId mapped
     *         to the error message in the ServiceData list of partial errors.
     *         <br>
     *         116001 (error):&nbsp;&nbsp;&nbsp;&nbsp; The specified relation can not be created
     *         between the selected two business objects.
     *         <br>
     *         116002 (error):&nbsp;&nbsp;&nbsp;&nbsp; Primary or secondary object is not specified.
     *         <br>
     *         116003 (error):&nbsp;&nbsp;&nbsp;&nbsp; The specified relation type is not supported
     *         in Teamcenter.
     *
     */
    virtual Rv1::Services::Relationshipviewer::_2012_10::Networkengine::CreateRelationsResponse createRelations ( const std::vector< Rv1::Services::Relationshipviewer::_2012_10::Networkengine::CreateRelationInput >& inputs ) = 0;

    /**
     * Provides a style definition which can be used for client to render graph data. For
     * example, it returns style definition of node shape and color,edge type and color.
     *
     * @return
     *         Graph style definition in XML string. The caller of this method need parse XML to
     *         get style definition.
     *
     */
    virtual Rv1::Services::Relationshipviewer::_2012_10::Networkengine::GraphStyleDefResponse getGraphStyleDef (  ) = 0;

    /**
     * The RelationShipViewer library provides graph (nodes connected via edges) views of
     * data elements. Each graph has a defined view type. The view type is a container for
     * the rules that determine what should be included in a graph and how it should be
     * represented. The choice of graph view is determined based on business need.
     * <br>
     * <br>
     * This API provides a list of the available graph view types. A graph view is a set
     * of configuration that can be used for network expansion. For example: view name,
     * graph parameters, inquires, graph presentation rules. The view list is role based,
     * different role may get different view list.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Diagram Management - Diagram Management
     *
     * @return
     *         The list of supported views
     *
     * @deprecated
     *         As of Teamcenter 10.1.2, use getViews3 instead
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 10.1.2, use getViews3 instead"))
#endif
    virtual Rv1::Services::Relationshipviewer::_2012_10::Networkengine::GraphTypeListResponse getViews (  ) = 0;

    /**
     * This operation provides a list of the available graph view types identified by the
     * input key. A graph view is a set of configuration that can be used for network expansion.
     * For example: view name, graph parameters, inquires, graph presentation rules. The
     * view list is role based, different role may get different view list.
     * <br>
     * <br>
     * The RelationShipViewer library provides graph (nodes connected via edges) views of
     * data elements. Each graph has a defined view type. The view type is a container for
     * the rules that determine what should be included in a graph and how it should be
     * represented. The choice of graph view is determined based on business need.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param key
     *        The key to identify a list of views. Each graph view have a key field, but not the
     *        identifier.
     *
     * @return
     *         The list of supported views identified by input key. If no view match the input key,
     *         a empty view list will be returned.
     *
     * @deprecated
     *         As of Teamcenter 10.1.2, use getViews3 instead
     *
     */
#ifdef WNT
__declspec(deprecated("Deprecated as of Teamcenter 10.1.2, use getViews3 instead"))
#endif
    virtual Rv1::Services::Relationshipviewer::_2012_10::Networkengine::GraphTypeListResponse getViews2 ( const std::string&  key ) = 0;

    /**
     * This API produces a graph of data corresponding to the input parameters. For Teamcenter
     * data source, the graph nodes are Teamcenter business objects, the relation between
     * the returns objects and the input root objects may be Teamcenter Relation class (GRM)
     * relationships, TraceLink and its sub types, Where used, where referenced, BOM relation
     * and Tag reference.
     *
     * @param rootIds
     *        A list of object IDs that input as network root nodes. If data source is Teamcenter,
     *        it is the UID list of Teamcenter business objects.
     *
     * @param viewName
     *        The name of graph view that will be used for network expansion. Call getViews() service
     *        method to get available view names.
     *
     * @param graphParamMap
     *        A (string, list(string)) map of graph parameter name and parameter values, such as
     *        expansion level, expansion direction. Parameters are inputs leveraged by the graph
     *        generation logic. Call getViews() service method to get available graph parameters
     *        supported by the specified view.
     *
     * @param inquiries
     *        A list of inquiries. Inquiries identify calculations that are performed using the
     *        graph contents as inputs. The full supported inquires can be got by calling getView()
     *        method. Currently supported inquires: numOfNodes, numOfEdges.
     *
     * @return
     *         Return network data of the input root object, answers to the inqures and soa service
     *         data. If data source is TC, the nodes of graph is Teamcenter business objects list,
     *         they are filled in serviceData as plain objects.
     *
     */
    virtual Rv1::Services::Relationshipviewer::_2012_10::Networkengine::NetworkResponse queryNetwork ( const std::vector< std::string >& rootIds,
        const std::string&  viewName,
        const GraphParamMap&  graphParamMap,
        const std::vector< std::string >& inquiries ) = 0;

    /**
     * This operation produces a graph of data corresponding to the input parameters. The
     * graph nodes are Teamcenter business objects, the relation between the returned objects
     * and the input root objects may be Teamcenter Relation class (GRM) relationships,
     * TraceLink and its sub types, Where used, where referenced, BOM relation and Tag reference.
     * You can query relations supported in Teamcenter for the input root Business Objects,
     * such as GRM (General Relationship Management) relation, BOM structure, Connectility,
     * etc.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param input
     *        Input parameter for querying network.
     *
     * @return
     *         Return network data of the input root object and answers to the inqures . The nodes
     *         of the graph are returned as plain objects in the ServiceData .
     *         <br>
     *         116011(error):&nbsp;&nbsp;&nbsp;&nbsp;  Not all input root Ids can identify valid
     *         business objects.
     *         <br>
     *         116012(error):&nbsp;&nbsp;&nbsp;&nbsp;  Configuration data doesn't exist for the
     *         specified graph view.
     *         <br>
     *         116013(error):&nbsp;&nbsp;&nbsp;&nbsp;  Query service index out of range.
     *         <br>
     *         116014(error):&nbsp;&nbsp;&nbsp;&nbsp;  Expansion direction isn't supported.
     *
     */
    virtual Rv1::Services::Relationshipviewer::_2012_10::Networkengine::NetworkResponse queryNetwork2 ( const Rv1::Services::Relationshipviewer::_2012_10::Networkengine::QueryNetworkInputs&  input ) = 0;


protected:
    virtual ~Networkengine() {}
};
            }
        }
    }
}

#include <rv1/services/relationshipviewer/RelationshipViewer_undef.h>
#endif

