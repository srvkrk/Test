/* 
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef RV1_SERVICES_RELATIONSHIPVIEWER__2014_11_NETWORKENGINE_HXX
#define RV1_SERVICES_RELATIONSHIPVIEWER__2014_11_NETWORKENGINE_HXX

#include <rv1/services/relationshipviewer/_2012_10/Networkengine.hxx>


#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <rv1/services/relationshipviewer/RelationshipViewer_exports.h>

namespace Rv1
{
    namespace Services
    {
        namespace Relationshipviewer
        {
            namespace _2014_11
            {
                class Networkengine;

class RV1SOARELATIONSHIPVIEWERSTRONGMNGD_API Networkengine
{
public:

    struct GraphFilter;
    struct GraphGroup;
    struct GraphTypeListResponse;
    struct GraphViewDescription;

    /**
     * Structure for representing information of a filter item, including filter name, RGB
     * values to color the legend of the filter at client side. It is used in structure
     * GraphGroup.
     */
    struct GraphFilter
    {
        /**
         * name of the filter
         */
        std::string name;
        /**
         * display name of the filter
         */
        std::string displayName;
        /**
         * The color used for legend of this filter at client side
         */
        Rv1::Services::Relationshipviewer::_2012_10::Networkengine::RGBValue color;
        /**
         * The list of types belong to this category.
         */
        std::vector< Rv1::Services::Relationshipviewer::_2012_10::Networkengine::Type > types;
    };

    /**
     * The graph group is a group name with a list of filters. A filter take effect either
     * on node or edge, it filts out graph that fall into its type. It is used in structure
     * GraphViewDescription.
     */
    struct GraphGroup
    {
        /**
         * Backend name of the group. Currently, there are two available groups, relations and
         * objects.
         */
        std::string name;
        /**
         * The list of graph group filter names. For example: the relations graph group may
         * have Attach, Tracability, Structure, Folder, Connectivity as filters. The objects
         * graph group may have Requirement, Functional, Logical, Physical, Dataset, Plant as
         * filters.
         */
        std::vector< Rv1::Services::Relationshipviewer::_2014_11::Networkengine::GraphFilter > filters;
    };

    /**
     * Graph type response.
     */
    struct GraphTypeListResponse
    {
        /**
         * A list of  role based avaliable graph views. Different role may get different view
         * list.
         */
        std::vector< Rv1::Services::Relationshipviewer::_2014_11::Networkengine::GraphViewDescription > views;
        /**
         * Service data contains the partial errors which used to report any partial failures.
         */
        Teamcenter::Soa::Client::ServiceData serviceData;
    };

    /**
     * The description of a graph view
     */
    struct GraphViewDescription
    {
        /**
         * Name of the graph view. It is also the identifier of graph view.
         */
        std::string name;
        /**
         * Display name of the graph view. It is also the identifier of graph view.
         */
        std::string displayName;
        /**
         * the default layout of the view. The possible values are: IncrementalHierarchic, Top-to-Bottom,
         * Left-to-Right, Bottom-to-Top, Right-to-Left.
         */
        std::string defaultLayout;
        /**
         * the default expansion direction of the view. The possibile values are: forward, backward,
         * all.
         */
        std::string defaultExpandDirection;
        /**
         * Flag to indicate whether the view is visible on graph control panel.
         */
        bool visible;
        /**
         * Flag to indicate whether the graph view is in diagram mode by default.
         */
        bool diagramMode;
        /**
         * The list of graph view groups.
         */
        std::vector< Rv1::Services::Relationshipviewer::_2014_11::Networkengine::GraphGroup > groups;
    };




    /**
     * This operation provides a list of the available graph view types identified by the
     * input key. A graph view is a set of configuration that can be used for network expansion.
     * For example: localized view name and category types which classify a list of supported
     * Teamcenter Business Object types, legend color of each category types. The view list
     * is role based, different role may get different view list.
     * <br>
     * <br>
     * <b>Teamcenter Component:</b>
     * <br>
     * Active WorkSpace - Active Workspace component.
     *
     * @param key
     *        The key to identify a list of views. Each graph view have a key field, but not the
     *        identifier.
     *
     * @return
     *         The list of supported views identified by input key. If no view match the input key,
     *         a empty view list will be returned. Partial Errors are returned when:  #142003 (error)
     *         The view configuration does not exist.  #142004 (error)   The view configuration
     *         file could not be parsed.
     *
     */
    virtual Rv1::Services::Relationshipviewer::_2014_11::Networkengine::GraphTypeListResponse getViews3 ( const std::string&  key ) = 0;


protected:
    virtual ~Networkengine() {}
};
            }
        }
    }
}

#include <rv1/services/relationshipviewer/RelationshipViewer_undef.h>
#endif

