./compile PLMSAPOldMatUpdate.c
./linkitk -o PLMSAPOldMatUpdate PLMSAPOldMatUpdate.o
chmod 777 *
