./compile tm_DMLWise_VC_MMSC_Sloc_Update.c
./linkitk -o tm_DMLWise_VC_MMSC_Sloc_Update tm_DMLWise_VC_MMSC_Sloc_Update.o
chmod 777 *
