./compile tm_Set_AR_SAP.c
./linkitk -o tm_Set_AR_SAP tm_Set_AR_SAP.o
chmod 777 *
