./compile tm_Remove_SAP.c
./linkitk -o tm_Remove_SAP tm_Remove_SAP.o
chmod 777 *
