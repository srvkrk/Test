./compile PLMSAPSLOCStatus.c
./linkitk -o PLMSAPSLOCStatus PLMSAPSLOCStatus.o
chmod 777 *
