/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   PLM-SAP
*  Description  :   Provide Part SLOC Status From SAP using PLM - SAP PO Code  
*  File Name    :   PLMSAPSLOCStatus.c
*  Created on   :   July 25th, 2025
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     25/07/2025                 Sourav Karak
***************************************************************************/

#include "malloc.h"
#include "stdio.h"
#include <ae/dataset.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <tc/envelope.h>
#include <fclasses/tc_date.h>
#include <user_exits/epm_toolkit_utils.h>
#include <cJSON.h>
#include <curl/curl.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\


char *prod_sloc;
char *sloc_ep;

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: [%d]\tERROR MSG: [%s]\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: [%d]\tERROR MSG: [%s]\n", ifails[index], texts[index]);
			printf ("FUNCTION: [%s]\nFILE: [%s] LINE: [%d]\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: [%s]\nFILE: [%s] LINE: [%d]\n", function, file, line);
		}
		EMH_clear_errors();	
	}
	return return_code;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString(char* mainStringf ,int fromCharf ,int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}

struct memory {
  char *response;
  size_t size;
};

static size_t WriteCallback(char *data, size_t size, size_t nmemb, void *clientp)
{
  size_t realsize = size * nmemb;
  struct memory *mem = (struct memory *)clientp;
 
  char *ptr = realloc(mem->response, mem->size + realsize + 1);
  if(!ptr)
    return 0;  /* out of memory */
 
  mem->response = ptr;
  memcpy(&(mem->response[mem->size]), data, realsize);
  mem->size += realsize;
  mem->response[mem->size] = 0;
  
  printf("\n WriteCallback Done..!!"); fflush(stdout);
 
  return realsize;
}

int parse_json_object(const char *json_string,char *ParseType) 
{
    int i = 0;
	cJSON *json = cJSON_Parse(json_string);
	if (json == NULL) 
	{ 
        const char *error_ptr = cJSON_GetErrorPtr(); 
        if (error_ptr != NULL) 
		{ 
            printf("Error: %s\n", error_ptr); 
        } 
        cJSON_Delete(json); 
        return 1; 
    } 
	printf("\njson_string : [%s]\n\n",json_string);
	printf("\ncJSON_GetArraySize(json) : [%d]\n\n",cJSON_GetArraySize(json));
	
	printf ("\nParseType : [%s]",ParseType);
	
	if( tc_strcmp ( ParseType, "PSTAT" ) == 0 )
	{
		printf("\njson_string : [%s]\n\n",json_string);
		if( tc_strstr(json_string ,"BAPI_MATERIAL_GETALLResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALLResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "PLANTDATA");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				prod_sloc = cJSON_GetObjectItem(moon_2, "ISS_ST_LOC")->valuestring; //Prod. stor. location 
				sloc_ep = cJSON_GetObjectItem(moon_2, "SLOC_EXPRC")->valuestring; //Storage loc. for EP  
			}
			printf("\n #---------- In[parse_json_object] -----------#");
            printf("\n Prod. stor. location: [%s]",prod_sloc);
			printf("\n Storage loc. for EP: [%s]",sloc_ep);
			printf("\n #---------- In[parse_json_object] -----------#");
		}
	}
	else
	{
		printf("\n Returned JSON Object Not Valid..!!");
	}
			
	return 0;
}

void print_json_object(const char *json_string)
{
    cJSON *json = cJSON_Parse(json_string);
    char *formatted_json = cJSON_Print(json);
    printf("Formatted json_object: [%s]\n", formatted_json);
    cJSON_Delete(json);
    free(formatted_json);
}
 
 int tm_PLM_BAPI_MATERIAL_GETALL ( char *data )
{
	struct memory chunk = {0};
	char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) 
	{
       printf("\n Failed To Initialize CURL..!!");
       return 0;
    }
	
	struct curl_slist *list = NULL;
	curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_BAPI_MATERIAL_GETALL_CV"); //PLM_BAPI_MATERIAL_GETALL_CV
	curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	
	list = curl_slist_append(list, "Content-Type: application/json");
    
	printf("\nFile request content as below "); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
	printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	res = curl_easy_perform(curl);
	
	printf("\ncurl_easy_perform");fflush(stdout);
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "PSTAT");
	
	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
	printf("\nfree"); fflush(stdout);
	
    curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	
	return 0;
}
 
 
 int cll_PLM_BAPI_MATERIAL_GETALL ( char *part_noDup, char *plantcode , char *json_pstat_req_obj )
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	char *out;
		
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();

	cJSON_AddItemToObject(rfc_root, "BAPI_MATERIAL_GETALL", exp_imp_tab_req);
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIAL", cJSON_CreateString(part_noDup));
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANT", cJSON_CreateString(plantcode));
	
	out = cJSON_Print(rfc_root);
	printf("Request Object For PLMSAP System Tag: [%s]\n", out);
	tc_strcpy( json_pstat_req_obj, out ) ;
	free(out);
	cJSON_Delete(rfc_root);
	
	return 0;
}


extern int ITK_user_main(int argc, char ** argv )
{
	char *message;
	char *loggedInUser = NULL;
	char *inputPart = NULL;
	char *iPlantCode = NULL;
	char *RptFile = (char *) malloc(100*sizeof(char));

	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"PLM-SAP_SLOC_Status");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Name Generated..!!");fflush(stdout);
	
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	fpPart_List = fopen("PartList.txt","r");
	FILE* fpOutput_file = fopen(RptFile, "w");
	fprintf(fpOutput_file,"PART_NO, PLANT, PROD_SLOC, SLOC_FOR_EP\n");fflush(fpOutput_file);
	if(fpOutput_file == NULL)
	{
		printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}

	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		char *json_pstat_req_obj = NULL;
		json_pstat_req_obj = malloc(34000);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			inputPart=strtok(Buffer,"^");
			iPlantCode=strtok(NULL,"^");
			
			printf("\n 1111....inputPart: [%s]\n", inputPart);
			printf("\n 2222....iPlantCode: [%s]\n", iPlantCode);
			
			printf("\n Function[1]: cll_PLM_BAPI_MATERIAL_GETALL() Start..!!\n");fflush(stdout);	
			cll_PLM_BAPI_MATERIAL_GETALL(inputPart, iPlantCode,json_pstat_req_obj);
			printf("\nRequest String: [%s]\n", json_pstat_req_obj);
			tm_PLM_BAPI_MATERIAL_GETALL ( json_pstat_req_obj );
			printf("\n\n #---------- In[Main-Function] -----------#");
			printf("\n Prod. stor. location: [%s]",prod_sloc);
			printf("\n Storage loc. for EP: [%s]",sloc_ep);
			printf("\n #---------- In[Main-Function] -----------#");
			printf("\n Function[1]: cll_PLM_BAPI_MATERIAL_GETALL() End..!!\n");fflush(stdout);
			fprintf(fpOutput_file,"%s,%s,%s,%s\n",inputPart,iPlantCode,prod_sloc,sloc_ep);fflush(fpOutput_file);
		}
		free(json_pstat_req_obj);
	}
	else
	{
	   printf(" Input File is Null..!!\n");fflush(stdout);
	}
	fclose(fpPart_List);
	fclose(fpOutput_file);

	
	printf(" PLM-SAP SLOC Status Generation End..!!\n");fflush(stdout);	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}
