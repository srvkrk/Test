./compile SAP_Child_Bom_Delete.c
./linkitk -o SAP_Child_Bom_Delete SAP_Child_Bom_Delete.o
chmod 777 *
