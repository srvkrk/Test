#include "malloc.h"
#include "stdio.h"

//#include "bapi.h"
//#include "bom_del.h"
//#include "wmhelpe.h"
//#include <itk/mem.h>
#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/envelope.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
//#include <bom/bom.h>

#include<cJSON.h>
#include <curl/curl.h>


#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}

char *iSapServer = NULL;
char *inputPart  = NULL;
char *iPlantCode = NULL;
char *changenumber  = NULL;
	
struct memory 
{
  char *response;
  size_t size;
};

static size_t WriteCallback(char *data, size_t size, size_t nmemb, void *clientp)
{
  size_t realsize = size * nmemb;
  struct memory *mem = (struct memory *)clientp;
 
  char *ptr = realloc(mem->response, mem->size + realsize + 1);
  if(!ptr)
    return 0;  /* out of memory */
 
  mem->response = ptr;
  memcpy(&(mem->response[mem->size]), data, realsize);
  mem->size += realsize;
  mem->response[mem->size] = 0;
  
  printf("\nWriteCallback done"); fflush(stdout);
 
  return realsize;
}

int parse_json_object(const char *json_string,char *ParseType) {
	
	printf("\n i am in function parse_json_object");
		
    int i = 0;
	cJSON *json = cJSON_Parse(json_string);
	if (json == NULL) { 
        const char *error_ptr = cJSON_GetErrorPtr(); 
        if (error_ptr != NULL) { 
            printf("Error: [%s] ParseType:[%s]", error_ptr,ParseType); 
        } 
        cJSON_Delete(json); 
        return 1; 
    } 
	printf("\n json_string : [%s]",json_string);//to see complete response
	printf("\n cJSON_GetArraySize(json) : [%d]",cJSON_GetArraySize(json));
	
	printf ("\n ParseType : [%s]\n",ParseType);

	if ( tc_strcmp ( ParseType, "CHILD_BOM_DELETE" ) == 0 )
	{
	
		if( tc_strstr(json_string ,"addition") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "addition");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "ZPPRFC_BDC_CS02Exception");	
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_changename = cJSON_GetObjectItem(moon_2, "Name")->valuestring;
				char *tm_changetext = cJSON_GetObjectItem(moon_2, "Text")->valuestring;
				//printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
				printf("\n Name: [%s]\n", tm_changename);fflush(stdout);
				printf("\n Text: [%s]\n", tm_changetext);fflush(stdout);
				printf("\n BOM not found for this material/plant/usage\n");fflush(stdout);
				//printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			}
		}
		else
		{
			//const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "CcapEcnCreate");
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "CSAP_MAT_BOM_DELETEResponse");
			for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				//printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
				char *tm_material = cJSON_GetObjectItem(moon_1, "FL_WARNING")->valuestring;
				printf("\n FL_WARNING [%s]\n", tm_material);fflush(stdout);
				printf("\n Bom Succesfully Deleted...\n");fflush(stdout);
				//printf("\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			}
		}
	}
	
}

void call_ZPPRFC_BDC_CS02(char *inputPart, char *iPlantCode, char *changenumber, char *childItemNo,char *child, char *iSapServer,char *json_del_child_req_obj)
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	
	
	cJSON *TABLE_req;
	cJSON *t_item_req;
	cJSON *single_t_item_req;
	
	//DMS_CLASS_DATA
	//SAP_FIELD_DATA
	char *out;
		
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
		
	TABLE_req = cJSON_CreateObject();
	t_item_req = cJSON_CreateArray();
	single_t_item_req = cJSON_CreateObject();
	
	
	cJSON_AddItemToObject(rfc_root, "ZPPRFC_BDC_CS02", exp_imp_tab_req);
	
		
	cJSON_AddItemToObject(exp_imp_tab_req, "BOM_USAGE", cJSON_CreateString("2"));  //S/4HANA Change
	cJSON_AddItemToObject(exp_imp_tab_req, "CHANGE_NO", cJSON_CreateString(changenumber));
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIAL_HEADER", cJSON_CreateString(inputPart));//QA
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANT", cJSON_CreateString(iPlantCode));
	cJSON_AddItemToObject(exp_imp_tab_req, "STLAL", cJSON_CreateString(""));
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "TABLE", TABLE_req);
	cJSON_AddItemToObject(TABLE_req, "item", t_item_req);
	cJSON_AddItemToArray(t_item_req, single_t_item_req = cJSON_CreateObject());
	cJSON_AddItemToObject(single_t_item_req, "ITEM_NO", cJSON_CreateString(childItemNo));//QA
	cJSON_AddItemToObject(single_t_item_req, "MATERIAL_NO", cJSON_CreateString(child));//QA
	
	
	
	out = cJSON_Print(rfc_root);
	printf("%s\n", out);
	strcpy(json_del_child_req_obj,out);
	free(out);
	cJSON_Delete(rfc_root);
}


int tm_curl_ZPPRFC_BDC_CS02 ( char *data )
{
	struct memory chunk = {0};
	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_BDC_CS02_CV");//dev
	
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_BDC_CS02_CV_QA");//QA works fine
	//curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential

	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_BDC_CS02_CV");//dev 18 AUG 25
	//curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential	
		
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_BDC_CS02_CV");//prod
	
	//curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	
	if ( tc_strcmp ( iSapServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_BDC_CS02_CV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_BDC_CS02_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_BDC_CS02_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n iSapServer is Blank..!!");fflush(stdout);
	}
	
	list = curl_slist_append(list, "Content-Type: application/json");
    
	printf("\nFile request content as below "); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
	printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	printf("\ncurl_easy_perform");fflush(stdout);
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "MAT_REV");
	
	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
	printf("\nfree"); fflush(stdout);
	
    curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}

extern int ITK_user_main(int argc, char ** argv )
{

	char *sUserName  = NULL;
	char *sPassword  = NULL;
	//char *inputPart  = NULL;
	//char *iPlantCode = NULL;
	//char *changenumber  = NULL;
	//char *iSapServer = NULL;

	char *childItemNo=NULL;
	char *child=NULL;

	
	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-pf=");
	inputPart = ITK_ask_cli_argument("-i=");
	childItemNo = ITK_ask_cli_argument("-n=");
	child= ITK_ask_cli_argument("-ch=");
	iPlantCode = ITK_ask_cli_argument("-j=");
	changenumber = ITK_ask_cli_argument("-c=");
	iSapServer = ITK_ask_cli_argument("-s=");

	
	printf ( "\n inputPart : [%s] child : [%s] childItemNo : [%s]  iPlantCode : [%s] iSapServer : [%s]", inputPart,child,childItemNo, iPlantCode, iSapServer ) ;
				

	char *json_del_child_req_obj = NULL;
	json_del_child_req_obj = malloc(34000);

	call_ZPPRFC_BDC_CS02(inputPart, iPlantCode, changenumber,childItemNo,child, iSapServer, json_del_child_req_obj);
	printf("\nRetuned Str : %s\n", json_del_child_req_obj);
	tm_curl_ZPPRFC_BDC_CS02 ( json_del_child_req_obj );
	free(json_del_child_req_obj);
			
	
	ITK_CALL(POM_logout(false));
	
	return ITK_ok;

}

/*
compile SAP_Child_Bom_Delete.c
linkitk -o SAP_Child_Bom_Delete SAP_Child_Bom_Delete.o
scp SAP_Child_Bom_Delete cvprod@172.22.97.90:/user/cvprod/PLMSAP/Nikhil/.
/user/cvprod/PLMSAP/prasad/tcldPatch/tcPatchExecutable SAP_Child_Bom_Delete
./SAP_Child_Bom_Delete -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -i=5532G4A0254001 -j=1500 -c=CORCT03JUL25 -n=0003 -ch=12655000648 -s=CVQ
*/