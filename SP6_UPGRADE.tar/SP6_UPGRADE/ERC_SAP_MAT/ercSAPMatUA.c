/********************************************************************************************************************************
* Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : ercSAPMatUA.c
* Created By                   : Devkant Kedar
* Created On                   : 19/03/2025
* Project                      : Tata Motors PLM-CAD BOM
* Methods Defined              :
* Description                  : Creates Basic View in SAP From UA using PO interface
* Specific Notes               :
*
* Modification History :
* S.No		Date			CR No       Modified By		Modification Notes
************************************************************************************************************************************/
#define TE_MAXLINELEN  128
//#include "saprfc.h"
//#include "sapitab.h"
//#include "wmhelpe.h"
//#include "bapi.h"
//#include "t.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ae/dataset.h>
//#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
//#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <fclasses/tc_date.h>

#include<cJSON.h>
#include <curl/curl.h>

FILE * fsuccess;
FILE* fp=NULL;
char fsuccess_name[200];

//WERKS_D eWerks;
//static MATNR eMatnr;

int partCnt=0;
char *dml_numER=NULL;
char *iSapServer=NULL;
char *erc_release_date=NULL;
char *DMLDescription=NULL;
tag_t *SetOfPartTags= NULLTAG;

char *part_noDupDes=NULL;
char *part_noDupDesx=NULL;
char *doc_no=NULL;
char *basic_division=NULL;
char *unit_wt=NULL;
char *volume=NULL;
char *vol_unit=NULL;
char *material_group=NULL;
char *doc_noDup=NULL;
char *dwg_typeDup=NULL;
char *tmpDrwNum1=NULL;
char *tmpDrwNum=NULL;
char *tmpDrwRev=NULL;
char *tmpDrwSeq=NULL;
char *dwg_revDup=NULL;
char *dwg_rev=NULL;
char *OldMatNo=NULL;
char *OldMatNoDup=NULL;
char *sizeDup=NULL;
char *net_wt=NULL;
char *net_wtDup=NULL;
char *gross_weight=NULL;
char *gross_weightDup=NULL;
char *part_noDup=NULL;
char *make_buy_indDup=NULL;
char *make_buy_ind=NULL;
char *mat_type=NULL;
char *store_loc=NULL;
char *store_locDup=NULL;
char *mrp_grp=NULL;
char *mat_grp=NULL;
char *division=NULL;
char *weight_unit=NULL;
char *mrp_type=NULL;
char *abc_ind=NULL;
char *odstatus=NULL;
char *num;
char *drstatus = NULL;
char *drstatusDup = NULL;
char *mm_pp_status = NULL;
char *partClrIndDup = NULL;
char *partClrInd = NULL;
char *quota_arrangement_usage = NULL;
char *mrp_controller = NULL;
char *lot_size_key = NULL;
char *fixed_lot_size = NULL;
char *max_stlvl = NULL;
char *blk_ind = NULL;
char *sched_mar_key = NULL;
char *req_grp = NULL;
char *period_ind = NULL;
char *mixedmrp = NULL;
char *cs1_val = NULL;
char *alternativb = NULL;
char *avail_chk = NULL;
char *splan_mat = NULL;
char *splan_plant = NULL;
char *splan_conv_fact = NULL;
char *ind_collect = NULL;
char *rep_mfg_in = NULL;
char *rep_mfg = NULL;
char *stock_det_group = NULL;
char *uoissue = NULL;
char *qua_ins_ind = NULL;
char *doc_req = NULL;
char *grptime = NULL;
char *certificate_type = NULL;
char *qm_proc_ind = NULL;
char *control_key = NULL;
char *catalog_prof = NULL;
char *valuation_cat = NULL;
char *price_con = NULL;
char *std_price = NULL;
char *moving_avg_price = NULL;
char *val_class = NULL;
char *mat_origin = NULL;
char *cost_lot_size = NULL;
char *variance_key = NULL;
char *with_quantity_structure = NULL;
char *costing_split_valuation = NULL;
char *costing_val_class = NULL;
char *MatCrChFlag = NULL;
char *dml_numAP1 = NULL;
char *PrtRevDup = NULL;
char *OrgIDDup = NULL;
char *plan_calendar = NULL;
char *profit_centre_sap = NULL;
char *overhd_grp = NULL;
char *myzeroDup3 = NULL;
char *myzeroDup1 = NULL;
char *myzeroDup2 = NULL;
char *myzeroDup4 = NULL;
char *sap_msg = NULL;
char *p;


char *meas_unit=NULL;
char *desc=NULL;
char *descDup=NULL;
char *drg_ind=NULL;
char *drg_indDup=NULL;
char *docClassDup=NULL;
char *docClass=NULL;
char *docRefClass=NULL;
char *spl_proc_key=NULL;
char *OwnerNameDup=NULL;
char *proc_type;

char *inputDML=NULL;


char *SAPpstat=NULL;
char *MRPpstat=NULL;
char pstat;
char pstat_mrp;
char pstat_acc;
char proc_Key;
char spl_Key;
char group;
const char *attrs[2];
const char *values[2];

//drwnum = (char *)malloc(500 * sizeof(char));

/*
#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)
void displaying_objects(void);
int GetCSPstat(char cMaterial[15]);
RFC_RC cll_ccap_ecn_create(RFC_HANDLE);
RFC_RC ccap_ecn_create(RFC_HANDLE hRfc,AENR_API01 *,CSDATA_XFELD *,CSDATA_XFELD *,CSDATA_XFELD *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AEEF_API01 *,AENRB_AENNR *,ITAB_H,ITAB_H,ITAB_H,ITAB_H,ITAB_H,char *);
void CLL_BAPI_MATERIAL_SAVEDATA(void);
RFC_RC ZBAPI_MATERIAL_SAVEDATA(RFC_HANDLE hRfc,BAPIMATHEAD *,BAPI_MARA *,BAPI_MARAX *,RMMG1_AENNR *,BAPIRET2 *,ITAB_H ,ITAB_H ,ITAB_H ,ITAB_H ,ITAB_H ,char *);
int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3]);
RFC_RC WIN_DLL_EXPORT_FLAGS zpprfc_revisionnum_change(RFC_HANDLE hRfc,AENNR *eAennr,CCMATNR *eMatnr,CC_REVLV *eRevlv,BAPIRET2 *iMessg,SYST_SUBRC *iRetval,char *xException);
RFC_RC export_CSpastat(RFC_HANDLE hRfc,MATNR *eMatnr,WERKS_D* eWerks,PLANTDATA* iMrpView, CLIENTDATA* iView, char *xException);
RFC_RC BAPI_MATERIAL_UPDATEDATA(RFC_HANDLE hRfc,BAPIMATHEAD *, BAPI_MARA *, BAPI_MARAX *, BAPIRET2 *,char *);
int pstat_basicFun(void);
int getChassisType(tag_t PartTag,char *part_type,char *part_ColorId);
void descChange(char *Part_Num,char *DescStr,char *dml_no_arg);
RFC_RC zbapi_material_savedata_mrp(RFC_HANDLE hRfc,BAPIMATHEAD *eBapiMatHead,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2 *eBapiret2,ITAB_H thBapi_Makt,char *xException);
void rfc_error(char *);
void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);
void str2nbcd(char *str,unsigned char *bcd,size_t size,int decimals);

*/
#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

char* subString(char* mainStringf ,int fromCharf ,int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}
/*
BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;

	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find2("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			
			if (nSysnr != 0)
			{
				RfcConnoptR3only.sysnr=nSysnr;
			}

			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}
*/
int material_savedata_json_cr ( char *json_mat_cr_req_obj ) 
{

	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *CLIENTDATA_req;
	cJSON *CLIENTDATAX_req;
	cJSON *EXTENSIONIN_req;
	cJSON *EXTENSIONINX_req;
	cJSON *item1_req;
	cJSON *item2_req;
	
	
	cJSON *FORECASTPARAMETERS_req;
	cJSON *FORECASTPARAMETERSX_req;
	
	cJSON *HEADDATA_req;
	
	cJSON *INTERNATIONALARTNOS_req;
	cJSON *item3_req;
	
	cJSON *MATERIALDESCRIPTION_req;
	cJSON *item4_req;
	
	
	cJSON *MATERIALLONGTEXT_req;
	cJSON *item5_req;
	
	cJSON *PLANNINGDATA_req;
	cJSON *PLANNINGDATAX_req;
	
	cJSON *PLANTDATA_req;
	cJSON *PLANTDATAX_req;
	
	cJSON *PRTDATA_req;
	cJSON *item6_req;

	cJSON *PRTDATAX_req;
	cJSON *item7_req;
	
	cJSON *RETURNMESSAGES_req;
	cJSON *item8_req;

	cJSON *SALESDATA_req;
	cJSON *SALESDATAX_req;

	cJSON *STORAGELOCATIONDATA_req;
	cJSON *STORAGELOCATIONDATAX_req;

	cJSON *STORAGETYPEDATA_req;
	cJSON *STORAGETYPEDATAX_req;

	cJSON *TAXCLASSIFICATIONS_req;
	cJSON *item9_req;
	
	cJSON *UNITSOFMEASURE_req;
	cJSON *item10_req;
	
	cJSON *UNITSOFMEASUREX_req;
	cJSON *item11_req;

	cJSON *VALUATIONDATA_req;
	cJSON *VALUATIONDATAX_req;

	cJSON *WAREHOUSENUMBERDATA_req;
	cJSON *WAREHOUSENUMBERDATAX_req;
		
	
	
	char *out;
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	CLIENTDATA_req = cJSON_CreateObject();
	CLIENTDATAX_req = cJSON_CreateObject();
	
	EXTENSIONIN_req = cJSON_CreateObject();
	EXTENSIONINX_req = cJSON_CreateObject();
	item1_req = cJSON_CreateObject();
	item2_req = cJSON_CreateObject();
	
	HEADDATA_req = cJSON_CreateObject();
	
	FORECASTPARAMETERS_req = cJSON_CreateObject();
	FORECASTPARAMETERSX_req = cJSON_CreateObject();
	
	INTERNATIONALARTNOS_req = cJSON_CreateObject();
	item3_req = cJSON_CreateObject();
	
	MATERIALDESCRIPTION_req = cJSON_CreateObject();
	item4_req = cJSON_CreateObject();
	
	MATERIALLONGTEXT_req = cJSON_CreateObject();
	item5_req = cJSON_CreateObject();
	
	PLANNINGDATA_req = cJSON_CreateObject();
	PLANNINGDATAX_req = cJSON_CreateObject();
	
	PLANTDATA_req = cJSON_CreateObject();
	PLANTDATAX_req = cJSON_CreateObject();
	
	PRTDATA_req = cJSON_CreateObject();
	item6_req = cJSON_CreateObject();
	
	PRTDATAX_req = cJSON_CreateObject();
	item7_req = cJSON_CreateObject();
	
	RETURNMESSAGES_req = cJSON_CreateObject();
	item8_req = cJSON_CreateObject();
	
	
	SALESDATA_req = cJSON_CreateObject();
	SALESDATAX_req = cJSON_CreateObject();
	
	STORAGELOCATIONDATA_req = cJSON_CreateObject();
	STORAGELOCATIONDATAX_req = cJSON_CreateObject();
	
	STORAGETYPEDATA_req = cJSON_CreateObject();
	STORAGETYPEDATAX_req = cJSON_CreateObject();
	
	TAXCLASSIFICATIONS_req = cJSON_CreateObject();
	item9_req = cJSON_CreateObject();
	
	UNITSOFMEASURE_req = cJSON_CreateObject();
	item10_req = cJSON_CreateObject();
	
	UNITSOFMEASUREX_req = cJSON_CreateObject();
	item11_req = cJSON_CreateObject();
	
	VALUATIONDATA_req = cJSON_CreateObject();
	VALUATIONDATAX_req = cJSON_CreateObject();
	
	WAREHOUSENUMBERDATA_req = cJSON_CreateObject();
	WAREHOUSENUMBERDATAX_req = cJSON_CreateObject();
	
	printf("\nDMLNo      : [%s]",dml_numER);
	printf("\nMatGrp	 : [%s]",mat_grp);
	printf("\nOldMat	 : [%s]",OldMatNoDup);
	printf("\nUQ		 : [%s]",meas_unit);
	printf("\nDOCNo      : [%s]",doc_noDup);
	printf("\nDrwType    : [%s]",dwg_typeDup);
	printf("\nDrwRev     : [%s]",dwg_revDup);
	printf("\nSheetSize  : [%s]",sizeDup);
	printf("\nNetWeight  : [%s]",net_wtDup);
	printf("\nWeightUnit : [%s]",weight_unit);
	printf("\nDiv        : [%s]",division);
	printf("\nPartDesc   : [%s]",part_noDupDes);
	printf("\nPartDescX  : [%s]",part_noDupDesx);
	printf("\nPartNo     : [%s]",part_noDup);
	printf("\nMatType    : [%s]",mat_type);
	printf("\nDesc       : [%s]",descDup);
		
	cJSON_AddItemToObject(rfc_root, "ZBAPI_MATERIAL_SAVEDATA", exp_imp_tab_req);
	cJSON_AddItemToObject(exp_imp_tab_req, "CHANGE_NUMBER", cJSON_CreateString(dml_numER));
		
	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATA", CLIENTDATA_req);
	cJSON_AddItemToObject(CLIENTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATL_GROUP" , cJSON_CreateString(mat_grp));
	cJSON_AddItemToObject(CLIENTDATA_req, "OLD_MAT_NO" , cJSON_CreateString(OldMatNoDup));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM_ISO" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOCUMENT" , cJSON_CreateString(doc_noDup));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_TYPE" , cJSON_CreateString(dwg_typeDup));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_VERS" , cJSON_CreateString(dwg_revDup));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_FORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NO_SHEETS" , cJSON_CreateString(sizeDup));
	//cJSON_AddItemToObject(CLIENTDATA_req, "NO_SHEETS" , cJSON_CreateString(""));
	//int i_no_sheets = atoi(sizeDup);
	//cJSON_AddNumberToObject(CLIENTDATA_req, "NO_SHEETS" , i_no_sheets);
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGEFORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SIZE_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NET_WEIGHT" , cJSON_CreateString(net_wtDup));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT" , cJSON_CreateString(weight_unit));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(weight_unit));
	cJSON_AddItemToObject(CLIENTDATA_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DIVISION" , cJSON_CreateString(division));
	cJSON_AddItemToObject(CLIENTDATA_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QTY_GR_GI" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CAD_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLOWED_WT" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLWD_VOL" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WT_TOL_LT" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(CLIENTDATA_req, "VOL_TOL_LT" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(CLIENTDATA_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "FILL_LEVEL" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "STACK_FACT" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QM_PROCMNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CATPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MINREMLIFE" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "SHELF_LIFE" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_PCT" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATCMPLLVL" , cJSON_CreateString("00"));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ANP" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATAX", CLIENTDATAX_req);
	cJSON_AddItemToObject(CLIENTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATL_GROUP" , cJSON_CreateString("X"));
	if( OldMatNoDup == NULL || tc_strcmp (OldMatNoDup, "" ) == 0 )
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "OLD_MAT_NO" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "OLD_MAT_NO" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM_ISO" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
	if( doc_noDup == NULL || tc_strcmp (doc_noDup, "" ) == 0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOCUMENT" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOCUMENT" , cJSON_CreateString("X"));
	}
	
	if( dwg_typeDup == NULL || tc_strcmp (dwg_typeDup, "" ) == 0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_TYPE" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_TYPE" , cJSON_CreateString("X"));
	}
	
	if( dwg_revDup == NULL || tc_strcmp (dwg_revDup, "" ) == 0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_VERS" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_VERS" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_FORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGE_NO" , cJSON_CreateString(""));
	if( sizeDup == NULL || tc_strcmp (sizeDup, "" ) == 0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "NO_SHEETS" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "NO_SHEETS" , cJSON_CreateString("X"));		
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGEFORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SIZE_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NET_WEIGHT" , cJSON_CreateString("X"));
	if( weight_unit == NULL || tc_strcmp (weight_unit, "" ) == 0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT" , cJSON_CreateString(""));
		cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT" , cJSON_CreateString("X"));
		cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT_ISO" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DIVISION" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QTY_GR_GI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CAD_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLOWED_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLWD_VOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WT_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VOL_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "FILL_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STACK_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QM_PROCMNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CATPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MINREMLIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SHELF_LIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_PCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATCMPLLVL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString("D"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ANP" , cJSON_CreateString(""));
	
	
	//cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_CAD_CALL", cJSON_CreateString(""));
	//cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_ONLINE", cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "EXTENSIONIN", EXTENSIONIN_req);
	cJSON_AddItemToObject(EXTENSIONIN_req, "item" , item1_req);
	cJSON_AddItemToObject(item1_req, "STRUCTURE" , cJSON_CreateString("BAPI_TE_MARA"));
	cJSON_AddItemToObject(item1_req, "VALUEPART1" , cJSON_CreateString(part_noDupDes));
	cJSON_AddItemToObject(item1_req, "VALUEPART2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART4" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "EXTENSIONINX", EXTENSIONINX_req);
	cJSON_AddItemToObject(EXTENSIONINX_req, "item" , item2_req);
	cJSON_AddItemToObject(item2_req, "STRUCTURE" , cJSON_CreateString("BAPI_TE_MARAX"));
	cJSON_AddItemToObject(item2_req, "VALUEPART1" , cJSON_CreateString(part_noDupDesx));
	cJSON_AddItemToObject(item2_req, "VALUEPART2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART4" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "HEADDATA", HEADDATA_req);
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL" , cJSON_CreateString(part_noDup));
	cJSON_AddItemToObject(HEADDATA_req, "IND_SECTOR" , cJSON_CreateString("M"));
	cJSON_AddItemToObject(HEADDATA_req, "MATL_TYPE" , cJSON_CreateString(mat_type));
	cJSON_AddItemToObject(HEADDATA_req, "BASIC_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "SALES_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PURCHASE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MRP_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "FORECAST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "WORK_SCHED_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PRT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "STORAGE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "WAREHOUSE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "QUALITY_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "ACCOUNT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "COST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "INP_FLD_CHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_VERSION" , cJSON_CreateString(""));
	
	
	/*cJSON_AddItemToObject(exp_imp_tab_req, "FORECASTPARAMETERS", FORECASTPARAMETERS_req);
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FORE_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "MODEL_SI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "MODEL_SP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "PARAM_OPT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "OPTIM_LEV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "INITIALIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FORE_MODEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "ALPHA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "BETA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "GAMMA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "DELTA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "TRACKLIMIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FORE_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "HIST_VALS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "INIT_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "SEASON_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "EXPOST_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FORE_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FIXED_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "WTG_GROUP" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "FORECASTPARAMETERSX", FORECASTPARAMETERSX_req);
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FORE_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "MODEL_SI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "MODEL_SP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "PARAM_OPT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "OPTIM_LEV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "INITIALIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FORE_MODEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "ALPHA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "BETA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "GAMMA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "DELTA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "TRACKLIMIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FORE_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "HIST_VALS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "INIT_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "SEASON_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "EXPOST_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FORE_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FIXED_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "WTG_GROUP" , cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "INTERNATIONALARTNOS", INTERNATIONALARTNOS_req);
	cJSON_AddItemToObject(INTERNATIONALARTNOS_req, "item" , item3_req);
	cJSON_AddItemToObject(item3_req, "UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item3_req, "UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item3_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item3_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item3_req, "DEL_FLAG" , cJSON_CreateString(""));*/
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALDESCRIPTION", MATERIALDESCRIPTION_req);
	cJSON_AddItemToObject(MATERIALDESCRIPTION_req, "item" , item4_req);
	cJSON_AddItemToObject(item4_req, "LANGU" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "LANGU_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item4_req, "MATL_DESC" , cJSON_CreateString(descDup));
	cJSON_AddItemToObject(item4_req, "DEL_FLAG" , cJSON_CreateString(""));
	
	/*cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALLONGTEXT", MATERIALLONGTEXT_req);
	cJSON_AddItemToObject(MATERIALLONGTEXT_req, "item" , item5_req);
	cJSON_AddItemToObject(item5_req, "APPLOBJECT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "TEXT_NAME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "TEXT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "LANGU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "LANGU_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "FORMAT_COL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "TEXT_LINE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "DEL_FLAG" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANNINGDATA", PLANNINGDATA_req);
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "CONVFACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_VERSION" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANNINGDATA", PLANNINGDATAX_req);
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "CONVFACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_VERSION" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATA", PLANTDATA_req);
	cJSON_AddItemToObject(PLANTDATA_req, "PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ABC_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRPPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_CTRLER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLND_DELRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ASSY_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOTSIZEKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SPPROCTYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MINLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAXLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FIXED_LOT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_VAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORD_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEP_REQ_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ALT_BOM_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "GRP_REQMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIXED_MRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SM_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUPTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INTEROP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INHSEPRODT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGEPERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNDER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLENTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLACE_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DOC_REQD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QUOTAUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SERV_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SPLIT_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAILCHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUP_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY_PLAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SHIP_PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROFIT_CTR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PPC_PL_CAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REP_MANUF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PL_TI_FNCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISS_ST_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMP_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CERT_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CYCLE_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "VARIANCE_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SERNO_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPMANPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MULT_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INSP_INT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLAN_STRGP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SLOC_EXPRC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BULK_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DETERM_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETYTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEPLOY_HORIZ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FIX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_INCREMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATAX", PLANTDATAX_req);
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ABC_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRPPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_CTRLER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLND_DELRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ASSY_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOTSIZEKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPPROCTYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MINLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAXLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIXED_LOT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_VAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORD_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEP_REQ_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALT_BOM_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "GRP_REQMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIXED_MRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SM_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUPTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INTEROP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INHSEPRODT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGEPERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNDER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLENTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLACE_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DOC_REQD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QUOTAUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERV_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPLIT_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAILCHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUP_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY_PLAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SHIP_PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROFIT_CTR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PPC_PL_CAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REP_MANUF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PL_TI_FNCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISS_ST_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMP_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CERT_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CYCLE_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "VARIANCE_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERNO_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPMANPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MULT_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INSP_INT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLAN_STRGP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SLOC_EXPRC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BULK_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DETERM_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETYTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEPLOY_HORIZ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_INCREMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "PRTDATA", PRTDATA_req);
	cJSON_AddItemToObject(PRTDATA_req, "item", item6_req);
	cJSON_AddItemToObject(item6_req, "PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "CREATE_LOAD_RECS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "CTRL_KEY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "GRP_KEY_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "GRP_KEY_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "PRT_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "STD_TEXT_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "REF_KEY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_REF_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "ST_REF_DATE_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_OFFSET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_OFFSET_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_OFFSET_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_OFFSET_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_REF_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_REF_DATE_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_OFFSET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_OFFSET_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_OFFSET_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_OFFSET_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "FORMULA_TOT_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "FORMULA_TOT_QTY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "FORMULA_TOT_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "FORMULA_TOT_USAGE_NO_CHG" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PRTDATAX", PRTDATAX_req);
	cJSON_AddItemToObject(PRTDATAX_req, "item", item7_req);
	cJSON_AddItemToObject(item7_req, "PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "CREATE_LOAD_RECS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "CTRL_KEY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "GRP_KEY_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "GRP_KEY_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "PRT_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "STD_TEXT_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "REF_KEY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_REF_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "ST_REF_DATE_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_OFFSET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_OFFSET_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_OFFSET_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_OFFSET_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_REF_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_REF_DATE_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_OFFSET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_OFFSET_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_OFFSET_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_OFFSET_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "FORMULA_TOT_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "FORMULA_TOT_QTY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "FORMULA_TOT_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "FORMULA_TOT_USAGE_NO_CHG" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "RETURNMESSAGES", RETURNMESSAGES_req);
	cJSON_AddItemToObject(RETURNMESSAGES_req, "item", item8_req);
	cJSON_AddItemToObject(item8_req, "TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "NUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_MSG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "PARAMETER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ROW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "FIELD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "SYSTEM" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "SALESDATA", SALESDATA_req);
	cJSON_AddItemToObject(SALESDATA_req, "SALES_ORG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DISTR_CHAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_STATS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "REBATE_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "COMM_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "CASH_DISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MIN_ORDER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MIN_DELY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MIN_MTO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DELY_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DELY_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DELY_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "SALES_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "SALES_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DELYG_PLNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PR_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MAT_PR_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "ACCT_ASSGT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_6" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_7" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_8" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_9" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT10" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "VAR_SALES_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PR_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PR_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PR_REF_MAT_VERSION" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "SALESDATAX", SALESDATAX_req);
	cJSON_AddItemToObject(SALESDATAX_req, "SALES_ORG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DISTR_CHAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_STATS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "REBATE_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "COMM_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "CASH_DISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MIN_ORDER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MIN_DELY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MIN_MTO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DELY_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DELY_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DELY_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "SALES_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "SALES_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DELYG_PLNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PR_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MAT_PR_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "ACCT_ASSGT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_6" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_7" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_8" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_9" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT10" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "VAR_SALES_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PR_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PR_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PR_REF_MAT_VERSION" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATA" , STORAGELOCATIONDATA_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "INV_CORR_FAC" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATAX" , STORAGELOCATIONDATAX_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "INV_CORR_FAC" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGETYPEDATA" , STORAGETYPEDATA_req);
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "WHSE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "STGE_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "MAX_SB_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "MIN_SB_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "CTRL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "REPLEN_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "PICK_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "ROUND_QTY" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGETYPEDATAX" , STORAGETYPEDATAX_req);
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "WHSE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "STGE_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "MAX_SB_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "MIN_SB_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "CTRL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "REPLEN_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "PICK_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "ROUND_QTY" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "TAXCLASSIFICATIONS" , TAXCLASSIFICATIONS_req);
	cJSON_AddItemToObject(TAXCLASSIFICATIONS_req, "item" , item9_req);
	cJSON_AddItemToObject(item9_req, "DEPCOUNTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "DEPCOUNTRY_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_6" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_6" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_7" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_7" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_8" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_8" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_9" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_9" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_IND" , cJSON_CreateString(""));*/
	
	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASURE" , UNITSOFMEASURE_req);
	cJSON_AddItemToObject(UNITSOFMEASURE_req, "item" , item10_req);
	cJSON_AddItemToObject(item10_req, "ALT_UNIT" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(item10_req, "ALT_UNIT_ISO" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(item10_req, "NUMERATOR" , cJSON_CreateString("1"));
	cJSON_AddItemToObject(item10_req, "DENOMINATR" , cJSON_CreateString("1"));
	cJSON_AddItemToObject(item10_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUME" , cJSON_CreateString(volume));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT" , cJSON_CreateString(vol_unit));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT_ISO" , cJSON_CreateString(vol_unit));
	cJSON_AddItemToObject(item10_req, "GROSS_WT" , cJSON_CreateString(gross_weightDup));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT" , cJSON_CreateString(weight_unit));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(weight_unit));
	cJSON_AddItemToObject(item10_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString(""));

	
	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASUREX" , UNITSOFMEASUREX_req);
	cJSON_AddItemToObject(UNITSOFMEASUREX_req, "item" , item11_req);
	cJSON_AddItemToObject(item11_req, "ALT_UNIT" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(item11_req, "ALT_UNIT_ISO" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(item11_req, "NUMERATOR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "DENOMINATR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUME" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT_ISO" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "GROSS_WT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT_ISO" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString(""));
	
	/*cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATA" , VALUATIONDATA_req);
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOVING_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CLASS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "FUTURE_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLND_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEVAL_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "OVERHEAD_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "QTY_STRUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MAT_ORIGIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAX_CML_UN" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATAX" , VALUATIONDATAX_req);
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOVING_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CLASS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "FUTURE_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLND_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEVAL_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "OVERHEAD_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "QTY_STRUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MAT_ORIGIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAX_CML_UN" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "WAREHOUSENUMBERDATA" , WAREHOUSENUMBERDATA_req);
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "WHSE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "STGESECTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "PLACEMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "WITHDRAWAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "L_EQUIP_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "L_EQUIP_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "L_EQUIP_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_1_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_2_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_3_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "UNITTYPE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "UNITTYPE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "UNITTYPE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "WM_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "WM_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "ADD_TO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "BLOCK_STGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "MSG_TO_IM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "SPEC_MVMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "CAPY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "PROCURE_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "PROCURE_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "STGE_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "REF_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "STEP_PICK" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "WAREHOUSENUMBERDATAX" , WAREHOUSENUMBERDATAX_req);
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "WHSE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "STGESECTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "PLACEMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "WITHDRAWAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "L_EQUIP_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "L_EQUIP_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "L_EQUIP_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_1_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_2_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_3_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "UNITTYPE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "UNITTYPE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "UNITTYPE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "WM_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "WM_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "ADD_TO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "BLOCK_STGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "MSG_TO_IM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "SPEC_MVMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "CAPY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "PROCURE_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "PROCURE_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "STGE_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "REF_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "STEP_PICK" , cJSON_CreateString(""));*/
	    
		
	out = cJSON_Print(rfc_root);
	//printf("%s\n", out);
	tc_strcpy(json_mat_cr_req_obj,out);
	free(out);
	cJSON_Delete(rfc_root);
	return 0;
	
}

int desc_chg_json ( char *Part_Num, char *DescStr, char *dml_no_arg, char *json_mat_desc_chg_req_obj )
{

	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *HEADDATA_req;
	cJSON *MATERIALDESCRIPTION_req;
	cJSON *item4_req;
	char *out;
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	
	HEADDATA_req = cJSON_CreateObject();
	
	MATERIALDESCRIPTION_req = cJSON_CreateObject();
	item4_req = cJSON_CreateObject();

	printf("\nDMLNo      : [%s]",dml_numER);
	printf("\nPartNo     : [%s]",part_noDup);
	printf("\nDesc       : [%s]",descDup);
		
	cJSON_AddItemToObject(rfc_root, "ZBAPI_MATERIAL_SAVEDATA", exp_imp_tab_req);
	cJSON_AddItemToObject(exp_imp_tab_req, "CHANGE_NUMBER", cJSON_CreateString(dml_numER));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "HEADDATA", HEADDATA_req);
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL" , cJSON_CreateString(part_noDup));
	cJSON_AddItemToObject(HEADDATA_req, "IND_SECTOR" , cJSON_CreateString("M"));
	cJSON_AddItemToObject(HEADDATA_req, "MATL_TYPE" , cJSON_CreateString(mat_type));
	cJSON_AddItemToObject(HEADDATA_req, "BASIC_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "SALES_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PURCHASE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MRP_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "FORECAST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "WORK_SCHED_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PRT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "STORAGE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "WAREHOUSE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "QUALITY_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "ACCOUNT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "COST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "INP_FLD_CHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_VERSION" , cJSON_CreateString(""));
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALDESCRIPTION", MATERIALDESCRIPTION_req);
	cJSON_AddItemToObject(MATERIALDESCRIPTION_req, "item" , item4_req);
	cJSON_AddItemToObject(item4_req, "LANGU" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "LANGU_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item4_req, "MATL_DESC" , cJSON_CreateString(descDup));
	cJSON_AddItemToObject(item4_req, "DEL_FLAG" , cJSON_CreateString(""));
		
	out = cJSON_Print(rfc_root);
	//printf("%s\n", out);
	tc_strcpy(json_mat_desc_chg_req_obj,out);
	free(out);
	cJSON_Delete(rfc_root);
	return 0;
	
	
}
int design_drw_upd_json ( char *json_dsg_drw_ver_upd_req_obj )
{

	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *CLIENTDATA_req;
	cJSON *CLIENTDATAX_req;
	cJSON *EXTENSIONIN_req;
	cJSON *EXTENSIONINX_req;
	cJSON *item1_req;
	cJSON *item2_req;
	
	
	cJSON *FORECASTPARAMETERS_req;
	cJSON *FORECASTPARAMETERSX_req;
	
	cJSON *HEADDATA_req;
	
	cJSON *INTERNATIONALARTNOS_req;
	cJSON *item3_req;
	
	cJSON *MATERIALDESCRIPTION_req;
	cJSON *item4_req;
	
	
	cJSON *MATERIALLONGTEXT_req;
	cJSON *item5_req;
	
	cJSON *PLANNINGDATA_req;
	cJSON *PLANNINGDATAX_req;
	
	cJSON *PLANTDATA_req;
	cJSON *PLANTDATAX_req;
	
	cJSON *PRTDATA_req;
	cJSON *item6_req;

	cJSON *PRTDATAX_req;
	cJSON *item7_req;
	
	cJSON *RETURNMESSAGES_req;
	cJSON *item8_req;

	cJSON *SALESDATA_req;
	cJSON *SALESDATAX_req;

	cJSON *STORAGELOCATIONDATA_req;
	cJSON *STORAGELOCATIONDATAX_req;

	cJSON *STORAGETYPEDATA_req;
	cJSON *STORAGETYPEDATAX_req;

	cJSON *TAXCLASSIFICATIONS_req;
	cJSON *item9_req;
	
	cJSON *UNITSOFMEASURE_req;
	cJSON *item10_req;
	
	cJSON *UNITSOFMEASUREX_req;
	cJSON *item11_req;

	cJSON *VALUATIONDATA_req;
	cJSON *VALUATIONDATAX_req;

	cJSON *WAREHOUSENUMBERDATA_req;
	cJSON *WAREHOUSENUMBERDATAX_req;
		
	
	
	char *out;
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	CLIENTDATA_req = cJSON_CreateObject();
	CLIENTDATAX_req = cJSON_CreateObject();
	
	EXTENSIONIN_req = cJSON_CreateObject();
	EXTENSIONINX_req = cJSON_CreateObject();
	item1_req = cJSON_CreateObject();
	item2_req = cJSON_CreateObject();
	
	HEADDATA_req = cJSON_CreateObject();
	
	FORECASTPARAMETERS_req = cJSON_CreateObject();
	FORECASTPARAMETERSX_req = cJSON_CreateObject();
	
	INTERNATIONALARTNOS_req = cJSON_CreateObject();
	item3_req = cJSON_CreateObject();
	
	MATERIALDESCRIPTION_req = cJSON_CreateObject();
	item4_req = cJSON_CreateObject();
	
	MATERIALLONGTEXT_req = cJSON_CreateObject();
	item5_req = cJSON_CreateObject();
	
	PLANNINGDATA_req = cJSON_CreateObject();
	PLANNINGDATAX_req = cJSON_CreateObject();
	
	PLANTDATA_req = cJSON_CreateObject();
	PLANTDATAX_req = cJSON_CreateObject();
	
	PRTDATA_req = cJSON_CreateObject();
	item6_req = cJSON_CreateObject();
	
	PRTDATAX_req = cJSON_CreateObject();
	item7_req = cJSON_CreateObject();
	
	RETURNMESSAGES_req = cJSON_CreateObject();
	item8_req = cJSON_CreateObject();
	
	
	SALESDATA_req = cJSON_CreateObject();
	SALESDATAX_req = cJSON_CreateObject();
	
	STORAGELOCATIONDATA_req = cJSON_CreateObject();
	STORAGELOCATIONDATAX_req = cJSON_CreateObject();
	
	STORAGETYPEDATA_req = cJSON_CreateObject();
	STORAGETYPEDATAX_req = cJSON_CreateObject();
	
	TAXCLASSIFICATIONS_req = cJSON_CreateObject();
	item9_req = cJSON_CreateObject();
	
	UNITSOFMEASURE_req = cJSON_CreateObject();
	item10_req = cJSON_CreateObject();
	
	UNITSOFMEASUREX_req = cJSON_CreateObject();
	item11_req = cJSON_CreateObject();
	
	VALUATIONDATA_req = cJSON_CreateObject();
	VALUATIONDATAX_req = cJSON_CreateObject();
	
	WAREHOUSENUMBERDATA_req = cJSON_CreateObject();
	WAREHOUSENUMBERDATAX_req = cJSON_CreateObject();
	
	printf("\nDMLNo      : [%s]",dml_numER);
	printf("\nMatGrp	 : [%s]",mat_grp);
	printf("\nOldMat	 : [%s]",OldMatNoDup);
	printf("\nUQ		 : [%s]",meas_unit);
	printf("\nDOCNo      : [%s]",doc_noDup);
	printf("\nDrwType    : [%s]",dwg_typeDup);
	printf("\nDrwRev     : [%s]",dwg_revDup);
	printf("\nSheetSize  : [%s]",sizeDup);
	printf("\nNetWeight  : [%s]",net_wtDup);
	printf("\nWeightUnit : [%s]",weight_unit);
	printf("\nDiv        : [%s]",division);
	printf("\nPartDesc   : [%s]",part_noDupDes);
	printf("\nPartDescX  : [%s]",part_noDupDesx);
	printf("\nPartNo     : [%s]",part_noDup);
	printf("\nMatType    : [%s]",mat_type);
	printf("\nDesc       : [%s]",descDup);
		
	cJSON_AddItemToObject(rfc_root, "ZBAPI_MATERIAL_SAVEDATA", exp_imp_tab_req);
	cJSON_AddItemToObject(exp_imp_tab_req, "CHANGE_NUMBER", cJSON_CreateString(dml_numER));
		
	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATA", CLIENTDATA_req);
	cJSON_AddItemToObject(CLIENTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "OLD_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOCUMENT" , cJSON_CreateString(doc_noDup));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_TYPE" , cJSON_CreateString(dwg_typeDup));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_VERS" , cJSON_CreateString(dwg_revDup));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_FORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NO_SHEETS" , cJSON_CreateString(sizeDup));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGEFORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SIZE_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NET_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT" , cJSON_CreateString(weight_unit));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(weight_unit));
	cJSON_AddItemToObject(CLIENTDATA_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DIVISION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QTY_GR_GI" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CAD_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLOWED_WT" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLWD_VOL" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WT_TOL_LT" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(CLIENTDATA_req, "VOL_TOL_LT" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(CLIENTDATA_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "FILL_LEVEL" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "STACK_FACT" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QM_PROCMNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CATPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MINREMLIFE" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "SHELF_LIFE" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_PCT" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATCMPLLVL" , cJSON_CreateString("00"));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ANP" , cJSON_CreateString(""));
	
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATAX", CLIENTDATAX_req);
	cJSON_AddItemToObject(CLIENTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATL_GROUP" , cJSON_CreateString(""));
	if( OldMatNoDup == NULL || tc_strcmp (OldMatNoDup, "" ) == 0 )
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "OLD_MAT_NO" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "OLD_MAT_NO" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
	if( doc_noDup == NULL || tc_strcmp (doc_noDup, "" ) == 0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOCUMENT" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOCUMENT" , cJSON_CreateString("X"));
	}
	
	if( dwg_typeDup == NULL || tc_strcmp (dwg_typeDup, "" ) == 0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_TYPE" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_TYPE" , cJSON_CreateString("X"));
	}
	
	if( dwg_revDup == NULL || tc_strcmp (dwg_revDup, "" ) == 0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_VERS" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_VERS" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_FORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGE_NO" , cJSON_CreateString(""));
	if( sizeDup == NULL || tc_strcmp (sizeDup, "" ) == 0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "NO_SHEETS" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "NO_SHEETS" , cJSON_CreateString("X"));		
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGEFORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SIZE_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NET_WEIGHT" , cJSON_CreateString(""));
	if( weight_unit == NULL || tc_strcmp (weight_unit, "" ) == 0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT" , cJSON_CreateString(""));
		cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT" , cJSON_CreateString("X"));
		cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT_ISO" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DIVISION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QTY_GR_GI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CAD_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLOWED_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLWD_VOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WT_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VOL_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "FILL_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STACK_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QM_PROCMNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CATPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MINREMLIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SHELF_LIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_PCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATCMPLLVL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString("D"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ANP" , cJSON_CreateString(""));
	
	
	

	cJSON_AddItemToObject(exp_imp_tab_req, "HEADDATA", HEADDATA_req);
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL" , cJSON_CreateString(part_noDup));
	cJSON_AddItemToObject(HEADDATA_req, "IND_SECTOR" , cJSON_CreateString("M"));
	cJSON_AddItemToObject(HEADDATA_req, "MATL_TYPE" , cJSON_CreateString(mat_type));
	cJSON_AddItemToObject(HEADDATA_req, "BASIC_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "SALES_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PURCHASE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MRP_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "FORECAST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "WORK_SCHED_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PRT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "STORAGE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "WAREHOUSE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "QUALITY_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "ACCOUNT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "COST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "INP_FLD_CHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_VERSION" , cJSON_CreateString(""));
	
	
	
		
	out = cJSON_Print(rfc_root);
	//printf("%s\n", out);
	tc_strcpy(json_dsg_drw_ver_upd_req_obj,out);
	free(out);
	cJSON_Delete(rfc_root);
	return 0;
	
}
struct memory {
  char *response;
  size_t size;
};
static size_t WriteCallback(char *data, size_t size, size_t nmemb, void *clientp)
{
  size_t realsize = size * nmemb;
  struct memory *mem = (struct memory *)clientp;
 
  char *ptr = realloc(mem->response, mem->size + realsize + 1);
  if(!ptr)
    return 0;  /* out of memory */
 
  mem->response = ptr;
  memcpy(&(mem->response[mem->size]), data, realsize);
  mem->size += realsize;
  mem->response[mem->size] = 0;
  
  printf("\nWriteCallback done"); fflush(stdout);
 
  return realsize;
}
int parse_json_object(const char *json_string,char *ParseType) {
    	int i = 0;
	cJSON *json = cJSON_Parse(json_string);
	if (json == NULL) { 
        const char *error_ptr = cJSON_GetErrorPtr(); 
        if (error_ptr != NULL) { 
            printf("Error: %s\n", error_ptr); 
        } 
        cJSON_Delete(json); 
        return 1; 
    } 
	//printf("\njson_string : [%s]\n\n",json_string);//to see complete response
	printf("\ncJSON_GetArraySize(json) : [%d]\n\n",cJSON_GetArraySize(json));
	//below is format for response
	/*
	{
        "MT_Finish_Receiving_GR_Notification_Response": {
                "Return":       {
                        "Item": {
                                "TYPE": "E",
                                "MESSAGE":      "Given material does not exist for the plant"
                        }
                }
        }
	}

	*/
	
//	const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "MT_Inbound_Complete_Putaway_Notification_Response");
//	const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "Return");
//	const cJSON *moon_3 = cJSON_GetObjectItemCaseSensitive(moon_2, "Item");
//		
//	for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
//	{
//		char *tm_Type = cJSON_GetObjectItem(moon_3, "TYPE")->valuestring;
//		char *tm_Message = cJSON_GetObjectItem(moon_3, "MESSAGE")->valuestring;
//		printf("tm_Type: [%s]\n", tm_Type);fflush(stdout);
//		printf("tm_Message: [%s]\n", tm_Message);fflush(stdout);
//	}

	printf ("\nParseType : [%s]",ParseType);
	if ( tc_strcmp ( ParseType, "MAT_BASIC_VIEW" ) == 0 )
	{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZBAPI_MATERIAL_SAVEDATAResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "RETURN");
				
			for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_Type = cJSON_GetObjectItem(moon_2, "SYSTEM")->valuestring;
				char *tm_Message = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
				printf("\ntm_Type: [%s]\n", tm_Type);fflush(stdout);
				printf("\nMAT_BASIC_VIEW tm_Message: [%s]\n", tm_Message);fflush(stdout);
			}
	}
	else if ( tc_strcmp ( ParseType, "DESIGN_DRW_UPD" ) == 0 )
	{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZBAPI_MATERIAL_SAVEDATAResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "RETURN");
				
			for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_Type = cJSON_GetObjectItem(moon_2, "SYSTEM")->valuestring;
				char *tm_Message = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
				printf("\ntm_Type: [%s]\n", tm_Type);fflush(stdout);
				printf("\nDESIGN_DRW_UPD tm_Message: [%s]\n", tm_Message);fflush(stdout);
			}
	}
	else if ( tc_strcmp ( ParseType, "DESC_UPD" ) == 0 )
	{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZBAPI_MATERIAL_SAVEDATAResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "RETURN");
				
			for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_Type = cJSON_GetObjectItem(moon_2, "SYSTEM")->valuestring;
				char *tm_Message = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
				printf("\ntm_Type: [%s]\n", tm_Type);fflush(stdout);
				printf("\nDESC_UPD tm_Message: [%s]\n", tm_Message);fflush(stdout);
			}
	}
	else if ( tc_strcmp ( ParseType, "MAT_REV" ) == 0 )
	{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZPPRFC_REVISIONNUM_CHANGEResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "MESSG");
				
			for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_Type = cJSON_GetObjectItem(moon_2, "NUMBER")->valuestring;
				char *tm_Message = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
				printf("\ntm_Type: [%s]\n", tm_Type);fflush(stdout);
				printf("\nMAT_REV tm_Message: [%s]\n", tm_Message);fflush(stdout);
			}
	}
	else if ( tc_strcmp ( ParseType, "PSTAT" ) == 0 )
	{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALL");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "CLIENTDATA");
				
			for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_maint_stat = cJSON_GetObjectItem(moon_2, "MAINT_STAT")->valuestring;
				printf("\nPSTAT MAINT_STAT: [%s]\n", tm_maint_stat);fflush(stdout);
				tc_strcpy ( SAPpstat, tm_maint_stat );
			}
	}
	else if ( tc_strcmp ( ParseType, "CHANGE_NO" ) == 0 )
	{
			printf("\njson_string : [%s]\n\n",json_string);
			
			if ( tc_strstr(json_string ,"addition") != NULL )
			{
			
				const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "addition");
				const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "CcapEcnCreate_Exception");
					
				for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
				{
					char *tm_material = cJSON_GetObjectItem(moon_2, "Name")->valuestring;
					char *tm_maint_stat = cJSON_GetObjectItem(moon_2, "Text")->valuestring;
					printf("\nCHANGE_NO MATERIAL: [%s]\n", tm_material);fflush(stdout);
					printf("\nCHANGE_NO Text: [%s]\n", tm_maint_stat);fflush(stdout);
				}
			}
			else
			{
				
				const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "CcapEcnCreate");
					
				for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
				{
					char *tm_material = cJSON_GetObjectItem(moon_1, "ChangeNo")->valuestring;
					printf("\nCHANGE_NO Change no Created : [%s]\n", tm_material);fflush(stdout);
					
				}
			}
	}
	return 0;
}

void print_json_object(const char *json_string) {
    cJSON *json = cJSON_Parse(json_string);
    char *formatted_json = cJSON_Print(json);
    printf("%s\n", formatted_json);
    cJSON_Delete(json);
    free(formatted_json);
}
int mat_pstat_json_cr ( char *json_pstat_req_obj )
{
	
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *EXTENSIONOUT_req;
	cJSON *EXTENSIONOUT_item_req;
	
	cJSON *INTERNATIONARTICLENUMBERS_req;
	cJSON *INTERNATIONARTICLENUMBERS_item_req;
	
	cJSON *MATERIALDESCRIPTION_req;
	cJSON *MATERIALDESCRIPTION_item_req;
	
	cJSON *MATERIALTEXT_req;
	cJSON *MATERIALTEXT_item_req;
	
	cJSON *MATERIAL_EVG_req;
	
	cJSON *RETURN_req;
	cJSON *RETURN_item_req;
	
	cJSON *TAXCLASSIFICATIONS_req;
	cJSON *TAXCLASSIFICATIONS_item_req;
	
	cJSON *UNITSOFMEASURE_req;
	cJSON *UNITSOFMEASURE_item_req;
	
	
	char *out;
	
		
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	EXTENSIONOUT_req = cJSON_CreateObject();
	EXTENSIONOUT_item_req = cJSON_CreateObject();
	
	INTERNATIONARTICLENUMBERS_req = cJSON_CreateObject();
	INTERNATIONARTICLENUMBERS_item_req = cJSON_CreateObject();
	
	MATERIALDESCRIPTION_req = cJSON_CreateObject();
	MATERIALDESCRIPTION_item_req = cJSON_CreateObject();
	
	MATERIALTEXT_req = cJSON_CreateObject();
	MATERIALTEXT_item_req = cJSON_CreateObject();
	
	MATERIAL_EVG_req = cJSON_CreateObject();
	
	RETURN_req = cJSON_CreateObject();
	RETURN_item_req = cJSON_CreateObject();
	
	TAXCLASSIFICATIONS_req = cJSON_CreateObject();
	TAXCLASSIFICATIONS_item_req = cJSON_CreateObject();
	
	UNITSOFMEASURE_req = cJSON_CreateObject();
	UNITSOFMEASURE_item_req = cJSON_CreateObject();
	
	
	cJSON_AddItemToObject(rfc_root, "BAPI_MATERIAL_GETALL", exp_imp_tab_req);
	/*cJSON_AddItemToObject(exp_imp_tab_req, "COMPANYCODE", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "DISTRIBUTIONCHANNEL", cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "EXTENSIONOUT", EXTENSIONOUT_req);
		cJSON_AddItemToObject(EXTENSIONOUT_req, "item", EXTENSIONOUT_item_req);
			cJSON_AddItemToObject(EXTENSIONOUT_item_req, "STRUCTURE", cJSON_CreateString(""));
			cJSON_AddItemToObject(EXTENSIONOUT_item_req, "VALUEPART1", cJSON_CreateString(""));
			cJSON_AddItemToObject(EXTENSIONOUT_item_req, "VALUEPART2", cJSON_CreateString(""));
			cJSON_AddItemToObject(EXTENSIONOUT_item_req, "VALUEPART3", cJSON_CreateString(""));
			cJSON_AddItemToObject(EXTENSIONOUT_item_req, "VALUEPART4", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "INTERNATIONARTICLENUMBERS", INTERNATIONARTICLENUMBERS_req);
		cJSON_AddItemToObject(INTERNATIONARTICLENUMBERS_req, "item", INTERNATIONARTICLENUMBERS_item_req);
			cJSON_AddItemToObject(INTERNATIONARTICLENUMBERS_item_req, "UNIT", cJSON_CreateString(""));
			cJSON_AddItemToObject(INTERNATIONARTICLENUMBERS_item_req, "UNIT_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(INTERNATIONARTICLENUMBERS_item_req, "EAN_UPC", cJSON_CreateString(""));
			cJSON_AddItemToObject(INTERNATIONARTICLENUMBERS_item_req, "EAN_CAT", cJSON_CreateString(""));
			cJSON_AddItemToObject(INTERNATIONARTICLENUMBERS_item_req, "MAIN_EAN", cJSON_CreateString(""));
			
	cJSON_AddItemToObject(exp_imp_tab_req, "KZRFB_ALL", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "LIFOVALUATIONLEVEL", cJSON_CreateString(""));*/
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIAL", cJSON_CreateString(part_noDup));//dev=123456789999
	
	/*cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALDESCRIPTION", MATERIALDESCRIPTION_req);
		cJSON_AddItemToObject(MATERIALDESCRIPTION_req, "item", MATERIALDESCRIPTION_item_req);
			cJSON_AddItemToObject(MATERIALDESCRIPTION_item_req, "LANGU", cJSON_CreateString(""));
			cJSON_AddItemToObject(MATERIALDESCRIPTION_item_req, "LANGU_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(MATERIALDESCRIPTION_item_req, "MATL_DESC", cJSON_CreateString(""));
			
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALTEXT", MATERIALTEXT_req);
		cJSON_AddItemToObject(MATERIALTEXT_req, "item", MATERIALTEXT_item_req);
			cJSON_AddItemToObject(MATERIALTEXT_item_req, "APPLOBJECT", cJSON_CreateString(""));
			cJSON_AddItemToObject(MATERIALTEXT_item_req, "TEXT_NAME", cJSON_CreateString(""));
			cJSON_AddItemToObject(MATERIALTEXT_item_req, "TEXT_ID", cJSON_CreateString(""));
			cJSON_AddItemToObject(MATERIALTEXT_item_req, "LANGU", cJSON_CreateString(""));
			cJSON_AddItemToObject(MATERIALTEXT_item_req, "LANGU_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(MATERIALTEXT_item_req, "FORMAT_COL", cJSON_CreateString(""));
			cJSON_AddItemToObject(MATERIALTEXT_item_req, "TEXT_LINE", cJSON_CreateString(""));
		
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIAL_EVG", MATERIAL_EVG_req);
		cJSON_AddItemToObject(MATERIAL_EVG_req, "MATERIAL_EXT", cJSON_CreateString(""));
		cJSON_AddItemToObject(MATERIAL_EVG_req, "MATERIAL_VERS", cJSON_CreateString(""));
		cJSON_AddItemToObject(MATERIAL_EVG_req, "MATERIAL_GUID", cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANT", cJSON_CreateString("1001"));//dev=1001
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "RETURN", RETURN_req);
		cJSON_AddItemToObject(RETURN_req, "item", RETURN_item_req);
			cJSON_AddItemToObject(RETURN_item_req, "TYPE", cJSON_CreateString(""));
			cJSON_AddItemToObject(RETURN_item_req, "CODE", cJSON_CreateString(""));
			cJSON_AddItemToObject(RETURN_item_req, "MESSAGE", cJSON_CreateString(""));
			cJSON_AddItemToObject(RETURN_item_req, "LOG_NO", cJSON_CreateString(""));
			cJSON_AddItemToObject(RETURN_item_req, "LOG_MSG_NO", cJSON_CreateString(""));
			cJSON_AddItemToObject(RETURN_item_req, "MESSAGE_V1", cJSON_CreateString(""));
			cJSON_AddItemToObject(RETURN_item_req, "MESSAGE_V2", cJSON_CreateString(""));
			cJSON_AddItemToObject(RETURN_item_req, "MESSAGE_V3", cJSON_CreateString(""));
			cJSON_AddItemToObject(RETURN_item_req, "MESSAGE_V4", cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "SALESORGANISATION", cJSON_CreateString(""));//dev=1001
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATION", cJSON_CreateString(""));//dev=1001
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGETYPE", cJSON_CreateString(""));//dev=1001
	
	
	
		
	cJSON_AddItemToObject(exp_imp_tab_req, "TAXCLASSIFICATIONS", TAXCLASSIFICATIONS_req);
		cJSON_AddItemToObject(TAXCLASSIFICATIONS_req, "item", TAXCLASSIFICATIONS_item_req);
			cJSON_AddItemToObject(TAXCLASSIFICATIONS_item_req, "DEPCOUNTRY", cJSON_CreateString(""));
			cJSON_AddItemToObject(TAXCLASSIFICATIONS_item_req, "DEPCOUNTRY_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(TAXCLASSIFICATIONS_item_req, "TAX_TYPE_1", cJSON_CreateString(""));
			cJSON_AddItemToObject(TAXCLASSIFICATIONS_item_req, "TAXCLASS_1", cJSON_CreateString(""));
		
	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASURE", UNITSOFMEASURE_req);
		cJSON_AddItemToObject(UNITSOFMEASURE_req, "item", UNITSOFMEASURE_item_req);
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "ALT_UNIT", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "ALT_UNIT_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "NUMERATOR", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "DENOMINATR", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "EAN_UPC", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "EAN_CAT", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "LENGTH", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "WIDTH", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "HEIGHT", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "UNIT_DIM", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "UNIT_DIM_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "VOLUME", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "VOLUMEUNIT_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "GROSS_WT", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "UNIT_OF_WT", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "UNIT_OF_WT_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "SUB_UOM", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "SUB_UOM_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "INTERNAL_CHAR", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "UOMSORTNUMBER", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "LEADINGUOM", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "VALUEDUOM", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "CHAR_UNIT", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "CHAR_UNIT_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "GTIN_VARIANT", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "NET_WEIGHT", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "ME_ANZ_SUB", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "EWM_CW_UOM_TYPE", cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONAREA", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONTYPE", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "WAREHOUSENUMBER", cJSON_CreateString(""));*/
	
	
	
	
	out = cJSON_Print(rfc_root);
	//printf("%s\n", out);
	tc_strcpy ( json_pstat_req_obj, out ) ;
	free(out);
	cJSON_Delete(rfc_root);
	return 0;
	
}
int get_pstat_from_sap ( char *data )
{
	struct memory chunk = {0};
	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	//const char *data = readd_sap_request_json_file();
	
	//printf("\nFile request content as below : %s",data);
	
	//curl_easy_setopt(curl, CURLOPT_URL, api_url);
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV_DEV");//ccap_ecn_create
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV_DEV");//ccap_ecn_create
	curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_BAPI_MATERIAL_GETALL_CV");//ccap_ecn_create
	curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	
	list = curl_slist_append(list, "Content-Type: application/json");
    //curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);
	
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, 12L);
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\nFile request content as below "); fflush(stdout);
	print_json_object ( data ) ;
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
		printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
		printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
		printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	//printf ("\nresponse : [%s] [%d]",chunk.response,strlen(chunk.response)) ;
	printf("\ncurl_easy_perform");fflush(stdout);
	//print_json_object ( chunk.response ) ;
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "PSTAT");
	
		printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
		printf("\nfree"); fflush(stdout);
	
    curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}
int GetCSPstat(char cMaterial[15])
{
	char *json_pstat_req_obj = NULL;
	
	tc_strcpy(SAPpstat,"");
	
	json_pstat_req_obj = malloc(34000);
	mat_pstat_json_cr ( json_pstat_req_obj );
	printf("%s\n", json_pstat_req_obj);
	
	get_pstat_from_sap ( json_pstat_req_obj ) ;
	
	free(json_pstat_req_obj);
	return 0;
}
int create_mat_basic_view_in_sap ( char *data )
{
	struct memory chunk = {0};
	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	//const char *data = readd_sap_request_json_file();
	
	//printf("\nFile request content as below : %s",data);
	
	//curl_easy_setopt(curl, CURLOPT_URL, api_url);
	curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV");//ccap_ecn_create
	curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	
	list = curl_slist_append(list, "Content-Type: application/json");
    //curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);
	
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, 12L);
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\nFile request content as below "); fflush(stdout);
	//print_json_object ( data ) ;
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
		printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
		printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
		printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	//printf ("\nresponse : [%s] [%d]",chunk.response,strlen(chunk.response)) ;
	printf("\ncurl_easy_perform");fflush(stdout);
	//print_json_object ( chunk.response ) ;
		printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "MAT_BASIC_VIEW");
	
		printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
		printf("\nfree"); fflush(stdout);
	
    curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}

int desc_upd_in_basic_view_in_sap ( char *data )
{
	struct memory chunk = {0};
	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	//const char *data = readd_sap_request_json_file();
	
	//printf("\nFile request content as below : %s",data);
	
	//curl_easy_setopt(curl, CURLOPT_URL, api_url);
	curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV");//ccap_ecn_create
	curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	
	list = curl_slist_append(list, "Content-Type: application/json");
    //curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);
	
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, 12L);
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\nFile request content as below "); fflush(stdout);
	//print_json_object ( data ) ;
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
		printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
		printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
		printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	//printf ("\nresponse : [%s] [%d]",chunk.response,strlen(chunk.response)) ;
	printf("\ncurl_easy_perform");fflush(stdout);
	//print_json_object ( chunk.response ) ;
		printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "DESC_UPD");
	
	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
	printf("\nfree"); fflush(stdout);
	
    curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}
 
int drawing_upd_in_basic2_view_in_sap ( char *data )
{
	struct memory chunk = {0};
	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	//const char *data = readd_sap_request_json_file();
	
	//printf("\nFile request content as below : %s",data);
	
	//curl_easy_setopt(curl, CURLOPT_URL, api_url);
	curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV");//ccap_ecn_create
	curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	
	list = curl_slist_append(list, "Content-Type: application/json");
    //curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);
	
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, 12L);
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\nFile request content as below "); fflush(stdout);
	//print_json_object ( data ) ;
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
		printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
		printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
		printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	//printf ("\nresponse : [%s] [%d]",chunk.response,strlen(chunk.response)) ;
	printf("\ncurl_easy_perform");fflush(stdout);
	//print_json_object ( chunk.response ) ;
		printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "DESIGN_DRW_UPD");
	
	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
	printf("\nfree"); fflush(stdout);
	
    curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}

int pstat_basicFun(void)
{
	if(tc_strlen(SAPpstat)>0 && tc_strstr(SAPpstat,"K"))
	{
		pstat = 'K';
	}
	else
	{
		pstat = '0';
	}

	/*if(!nlsIsStrNull(nlsStrStr(MRPpstat,"D")))
	{
		pstat_mrp = 'D';
	}
	else
	{
		pstat_mrp = '0';
	}

	if(!nlsIsStrNull(nlsStrStr(MRPpstat,"B")))
	{
		pstat_acc = 'B';
	}
	else
	{
		pstat_acc = '0';
	}*/
	//printf("\n..%c:%c:%c..\n",pstat,pstat_mrp,pstat_acc); fflush(stdout);
	return 0;
}

void CLL_BAPI_MATERIAL_SAVEDATA()
{
	char *plantcode=NULL;
	char *json_mat_cr_req_obj = NULL;
	
	json_mat_cr_req_obj = malloc(34000);
	
	tc_strdup("1001",&plantcode);
	tc_strcpy(SAPpstat,"");
	tc_strcpy(MRPpstat,"");
	pstat='0';
	GetCSPstat(part_noDup);
	printf("\n SAPpstat:[%s][%s][%s]",part_noDup,SAPpstat,MRPpstat) ; fflush(stdout);
	fprintf(fsuccess,"\n SAPpstat:[%s][%s][%s]",part_noDup,SAPpstat,MRPpstat) ; fflush(fsuccess);
	
	pstat_basicFun();
	printf("\n... pstat Values are :%c:",pstat);fflush(stdout);
	
	if (pstat=='K')
	{
			printf("\nMessage for Basic Material Create: Material %s already exists \n", part_noDup);
			printf("\n****************************************************************");
			fprintf(fsuccess, "\nMessage for Basic Material Create: Material %s already exists", part_noDup);
			fprintf(fsuccess, "\n****************************************************************");
	}
	else
	{
		printf("\nGoing for Basic view creation");
		material_savedata_json_cr ( json_mat_cr_req_obj );
		printf("%s\n", json_mat_cr_req_obj);
		create_mat_basic_view_in_sap ( json_mat_cr_req_obj );
		
	}
	free(json_mat_cr_req_obj);
}
void UPD_BAPI_MATERIAL_SAVEDATA(void)
{
	char *plantcode=NULL;
	char *json_dsg_drw_ver_upd_req_obj = NULL;
	
	json_dsg_drw_ver_upd_req_obj = malloc(34000);
	
	tc_strcpy(SAPpstat,"");
	tc_strcpy(MRPpstat,"");
	pstat='0';
	GetCSPstat(part_noDup);
	printf("\n SAPpstat:[%s][%s][%s]",part_noDup,SAPpstat,MRPpstat) ; fflush(stdout);
	fprintf(fsuccess,"\n SAPpstat:[%s][%s][%s]",part_noDup,SAPpstat,MRPpstat) ; fflush(fsuccess);
	
	pstat_basicFun();
	printf("\npstat Values are :%c:",pstat);fflush(stdout);
	
	if (pstat=='K')
	{
			
		printf("\nGoing for drawing info update");
		design_drw_upd_json ( json_dsg_drw_ver_upd_req_obj );
		printf("%s\n", json_dsg_drw_ver_upd_req_obj);
		drawing_upd_in_basic2_view_in_sap ( json_dsg_drw_ver_upd_req_obj );
		
	}
	free(json_dsg_drw_ver_upd_req_obj);
}
void descChange(char *Part_Num,char *DescStr,char *dml_no_arg)
{
	char *plantcode=NULL;
	char *json_mat_desc_chg_req_obj = NULL;
	
	json_mat_desc_chg_req_obj = malloc(34000);
	
	tc_strcpy(SAPpstat,"");
	tc_strcpy(MRPpstat,"");
	pstat='0';
	GetCSPstat(part_noDup);
	printf("\n SAPpstat:[%s][%s][%s]",part_noDup,SAPpstat,MRPpstat) ; fflush(stdout);
	fprintf(fsuccess,"\n SAPpstat:[%s][%s][%s]",part_noDup,SAPpstat,MRPpstat) ; fflush(fsuccess);
	
	pstat_basicFun();
	printf("\npstat Values are :%c:",pstat);fflush(stdout);
	
	if (pstat=='K')
	{
			
		printf("\nGoing for desc change");
		desc_chg_json ( Part_Num, DescStr, dml_no_arg,json_mat_desc_chg_req_obj );
		printf("%s\n", json_mat_desc_chg_req_obj);
		desc_upd_in_basic_view_in_sap ( json_mat_desc_chg_req_obj );
		
	}
	free(json_mat_desc_chg_req_obj);
	
}
int create_mat_rev_in_sap ( char *data )
{
	struct memory chunk = {0};
	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	//const char *data = readd_sap_request_json_file();
	
	//printf("\nFile request content as below : %s",data);
	
	//curl_easy_setopt(curl, CURLOPT_URL, api_url);
	curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_REVISIONNUM_CHANGE_CV");//ccap_ecn_create
	curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	
	list = curl_slist_append(list, "Content-Type: application/json");
    //curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);
	
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, 12L);
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\nFile request content as below "); fflush(stdout);
	//print_json_object ( data ) ;
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
		printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
		printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
		printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	//printf ("\nresponse : [%s] [%d]",chunk.response,strlen(chunk.response)) ;
	printf("\ncurl_easy_perform");fflush(stdout);
	//print_json_object ( chunk.response ) ;
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "MAT_REV");
	
		printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
		printf("\nfree"); fflush(stdout);
	
    curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}
int material_rev_json_cr ( char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3],char *json_mat_rev_cr_req_obj )
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	char *out;
	
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	cJSON_AddItemToObject(rfc_root, "ZPPRFC_REVISIONNUM_CHANGE", exp_imp_tab_req);
	
	cJSON_AddItemToObject(exp_imp_tab_req, "AENNR", cJSON_CreateString(sap_dml_no));
	cJSON_AddItemToObject(exp_imp_tab_req, "MATNR", cJSON_CreateString(sap_part_no));
	cJSON_AddItemToObject(exp_imp_tab_req, "REVLV", cJSON_CreateString(sap_rev_sheet_status));
	
	
	out = cJSON_Print(rfc_root);
	//printf("%s\n", out);
	tc_strcpy(json_mat_rev_cr_req_obj,out);
	free(out);
	cJSON_Delete(rfc_root);
	return 0;
}
int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3])
{
	char *json_mat_rev_cr_req_obj = NULL;
	json_mat_rev_cr_req_obj = malloc(34000);
	material_rev_json_cr ( sap_dml_no, sap_part_no, sap_rev_sheet_status, json_mat_rev_cr_req_obj );
	printf("%s\n", json_mat_rev_cr_req_obj);
	create_mat_rev_in_sap ( json_mat_rev_cr_req_obj );
	free(json_mat_rev_cr_req_obj);
}
int change_no_json_cr(char *json_req_obj)
{
	
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *AltDates_req;
	cJSON *AltDates_item_req;
	cJSON *ChangeHeader_req;
	cJSON *Effectivity_req;
	cJSON *Effectivity_item_req;
	cJSON *ObjectBom_req;
	cJSON *Object084_req;
	cJSON *ObjectBomCus_req;
	cJSON *ObjectBomDoc_req;
	cJSON *ObjectBomEqui_req;
	cJSON *ObjectBomLoc_req;
	cJSON *ObjectBomMat_req;
	cJSON *ObjectBomPsp_req;
	cJSON *ObjectBomStd_req;
	cJSON *ObjectChar_req;
	cJSON *ObjectCls_req;
	cJSON *ObjectClsMaint_req;
	cJSON *ObjectConfProf_req;
	cJSON *ObjectDep_req;
	cJSON *ObjectDoc_req;
	cJSON *ObjectHazmat_req;
	cJSON *ObjectMat_req;
	cJSON *ObjectO75_req;
	cJSON *ObjectO76_req;
	cJSON *ObjectO77_req;
	cJSON *ObjectO78_req;
	cJSON *ObjectO79_req;
	cJSON *ObjectO80_req;
	cJSON *ObjectO81_req;
	cJSON *ObjectO82_req;
	cJSON *ObjectO83_req;
	cJSON *ObjectO85_req;
	cJSON *ObjectO86_req;
	cJSON *ObjectO87_req;
	cJSON *ObjectO88_req;
	cJSON *ObjectO89_req;
	cJSON *ObjectO90_req;
	cJSON *ObjectO91_req;
	cJSON *ObjectO92_req;
	cJSON *ObjectO93_req;
	cJSON *ObjectO94_req;
	cJSON *ObjectO95_req;
	cJSON *ObjectO96_req;
	cJSON *ObjectO97_req;
	cJSON *ObjectO98_req;
	cJSON *ObjectO99_req;
	cJSON *ObjectPhrase_req;
	cJSON *ObjectPvs_req;
	cJSON *ObjectPvsAlt_req;
	cJSON *ObjectPvsRel_req;
	cJSON *ObjectPvsVar_req;
	cJSON *ObjectSubstance_req;
	cJSON *ObjectTlist_req;
	cJSON *ObjectTlistA_req;
	cJSON *ObjectTlistE_req;
	cJSON *ObjectTlistM_req;
	cJSON *ObjectTlistN_req;
	cJSON *ObjectTlistQ_req;
	cJSON *ObjectTlistR_req;
	cJSON *ObjectTlistS_req;
	cJSON *ObjectTlistT_req;
	cJSON *ObjectTlist_2_req;
	cJSON *ObjectValidMatvers_req;
	cJSON *ObjectVarTab_req;

	cJSON *Objmgrec_req;
	cJSON *Objmgrec_item_req;

	cJSON *Textheader_req;
	cJSON *Textheader_item_req;

	cJSON *Textlines_req;
	cJSON *Textlines_item_req;

	cJSON *ValueAssign_req;

	printf("\nCalling json for change no"); fflush(stdout);
	char *out;
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	AltDates_req = cJSON_CreateObject();
	AltDates_item_req = cJSON_CreateObject();
	ChangeHeader_req = cJSON_CreateObject();
	Effectivity_req = cJSON_CreateObject();
	Effectivity_item_req = cJSON_CreateObject();
	ObjectBom_req = cJSON_CreateObject();
	Object084_req = cJSON_CreateObject();
	ObjectBomCus_req = cJSON_CreateObject();
	ObjectBomDoc_req = cJSON_CreateObject();
	ObjectBomEqui_req = cJSON_CreateObject();
	ObjectBomLoc_req = cJSON_CreateObject();
	ObjectBomMat_req = cJSON_CreateObject();
	ObjectBomPsp_req = cJSON_CreateObject();
	ObjectBomStd_req = cJSON_CreateObject();
	ObjectChar_req = cJSON_CreateObject();
	ObjectCls_req = cJSON_CreateObject();
	ObjectClsMaint_req = cJSON_CreateObject();
	ObjectConfProf_req = cJSON_CreateObject();
	ObjectDep_req = cJSON_CreateObject();
	ObjectDoc_req = cJSON_CreateObject();
	ObjectHazmat_req = cJSON_CreateObject();
	ObjectMat_req = cJSON_CreateObject();
	ObjectO75_req = cJSON_CreateObject();
	ObjectO76_req = cJSON_CreateObject();
	ObjectO77_req = cJSON_CreateObject();
	ObjectO78_req = cJSON_CreateObject();
	ObjectO79_req = cJSON_CreateObject();
	ObjectO80_req = cJSON_CreateObject();
	ObjectO81_req = cJSON_CreateObject();
	ObjectO82_req = cJSON_CreateObject();
	ObjectO83_req = cJSON_CreateObject();
	ObjectO85_req = cJSON_CreateObject();
	ObjectO86_req = cJSON_CreateObject();
	ObjectO87_req = cJSON_CreateObject();
	ObjectO88_req = cJSON_CreateObject();
	ObjectO89_req = cJSON_CreateObject();
	ObjectO90_req = cJSON_CreateObject();
	ObjectO91_req = cJSON_CreateObject();
	ObjectO92_req = cJSON_CreateObject();
	ObjectO93_req = cJSON_CreateObject();
	ObjectO94_req = cJSON_CreateObject();
	ObjectO95_req = cJSON_CreateObject();
	ObjectO96_req = cJSON_CreateObject();
	ObjectO97_req = cJSON_CreateObject();
	ObjectO98_req = cJSON_CreateObject();
	ObjectO99_req = cJSON_CreateObject();
	ObjectPhrase_req = cJSON_CreateObject();
	ObjectPvs_req = cJSON_CreateObject();
	ObjectPvsAlt_req = cJSON_CreateObject();
	ObjectPvsRel_req = cJSON_CreateObject();
	ObjectPvsVar_req = cJSON_CreateObject();
	ObjectSubstance_req = cJSON_CreateObject();
	ObjectTlist_req = cJSON_CreateObject();
	ObjectTlistA_req = cJSON_CreateObject();
	ObjectTlistE_req = cJSON_CreateObject();
	ObjectTlistM_req = cJSON_CreateObject();
	ObjectTlistN_req = cJSON_CreateObject();
	ObjectTlistQ_req = cJSON_CreateObject();
	ObjectTlistR_req = cJSON_CreateObject();
	ObjectTlistS_req = cJSON_CreateObject();
	ObjectTlistT_req = cJSON_CreateObject();
	ObjectTlist_2_req = cJSON_CreateObject();
	ObjectValidMatvers_req = cJSON_CreateObject();
	ObjectVarTab_req = cJSON_CreateObject();

	Objmgrec_req = cJSON_CreateObject();
	Objmgrec_item_req = cJSON_CreateObject();

	Textheader_req = cJSON_CreateObject();
	Textheader_item_req = cJSON_CreateObject();

	Textlines_req = cJSON_CreateObject();
	Textlines_item_req = cJSON_CreateObject();

	ValueAssign_req = cJSON_CreateObject();


	cJSON_AddItemToObject(rfc_root, "CcapEcnCreate", exp_imp_tab_req);

	/*cJSON_AddItemToObject(exp_imp_tab_req, "AltDates", AltDates_req);
		cJSON_AddItemToObject(AltDates_req, "item", AltDates_item_req);
			cJSON_AddItemToObject(AltDates_item_req, "AltDate", cJSON_CreateString(erc_release_date));//erc_release_date
			cJSON_AddItemToObject(AltDates_item_req, "ValidFrom", cJSON_CreateString(erc_release_date));//07.02.2025//erc_release_date
			cJSON_AddItemToObject(AltDates_item_req, "FlDelete", cJSON_CreateString(""));*/
			
			

	cJSON_AddItemToObject(exp_imp_tab_req, "ChangeHeader", ChangeHeader_req);
		cJSON_AddItemToObject(ChangeHeader_req, "ChangeNo", cJSON_CreateString(dml_numER));//dml_numER//"CORRCT070225"
		cJSON_AddItemToObject(ChangeHeader_req, "Status", cJSON_CreateString("01"));
		cJSON_AddItemToObject(ChangeHeader_req, "AuthGroup", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "ValidFrom", cJSON_CreateString(erc_release_date));//07022025//erc_release_date
		cJSON_AddItemToObject(ChangeHeader_req, "Descript", cJSON_CreateString(DMLDescription));//DMLDescription//"DBK TEST REST API POC"
		cJSON_AddItemToObject(ChangeHeader_req, "ReasonChg", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "DeletionMark", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "IndateRule", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "OutdateRule", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "Function", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "ChangeLeader", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "EffectivityType", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "OverridingMark", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "Rank", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "ReleaseKey", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "StatusProfile", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "TechRel", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "BasicChange", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "Effectivity", Effectivity_req);
		cJSON_AddItemToObject(Effectivity_req, "item", Effectivity_item_req);
			cJSON_AddItemToObject(Effectivity_item_req, "ValidFrom", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "ValidTo", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "DateMark", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Material", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "SerialnrLow", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "SerialnrHigh", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Product", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Class", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Classty", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Startup", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Plant", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Locno", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "SernrOi", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "FlDelete", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "FlAle", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "FlCommitAndWait", cJSON_CreateString("X"));
	cJSON_AddItemToObject(exp_imp_tab_req, "FlNoCommitWork", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "IvAccessUseCase", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBom", ObjectBom_req);
		cJSON_AddItemToObject(ObjectBom_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomCus", ObjectBomCus_req);
		cJSON_AddItemToObject(ObjectBomCus_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "GenDialog", cJSON_CreateString(""));


		cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomDoc", ObjectBomDoc_req);
		cJSON_AddItemToObject(ObjectBomDoc_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomEqui", ObjectBomEqui_req);
		cJSON_AddItemToObject(ObjectBomEqui_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomLoc", ObjectBomLoc_req);
		cJSON_AddItemToObject(ObjectBomLoc_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "GenDialog", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomMat", ObjectBomMat_req);
		cJSON_AddItemToObject(ObjectBomMat_req, "Active", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectBomMat_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomMat_req, "ObjRequ", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectBomMat_req, "MgtrecGen", cJSON_CreateString("X"));/*X*/
		cJSON_AddItemToObject(ObjectBomMat_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomMat_req, "GenDialog", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomPsp", ObjectBomPsp_req);
		cJSON_AddItemToObject(ObjectBomPsp_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomStd", ObjectBomStd_req);
		cJSON_AddItemToObject(ObjectBomStd_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectChar", ObjectChar_req);
		cJSON_AddItemToObject(ObjectChar_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectCls", ObjectCls_req);
		cJSON_AddItemToObject(ObjectCls_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectClsMaint", ObjectClsMaint_req);
		cJSON_AddItemToObject(ObjectClsMaint_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectConfProf", ObjectConfProf_req);
		cJSON_AddItemToObject(ObjectConfProf_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectDep", ObjectDep_req);
		cJSON_AddItemToObject(ObjectDep_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "GenDialog", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectDoc", ObjectDoc_req);
		cJSON_AddItemToObject(ObjectDoc_req, "Active", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectDoc_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDoc_req, "ObjRequ", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectDoc_req, "MgtrecGen", cJSON_CreateString("X"));/*X*/
		cJSON_AddItemToObject(ObjectDoc_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDoc_req, "GenDialog", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "ObjectHazmat", ObjectHazmat_req);
		cJSON_AddItemToObject(ObjectHazmat_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "GenDialog", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectMat", ObjectMat_req);
		cJSON_AddItemToObject(ObjectMat_req, "Active", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectMat_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectMat_req, "ObjRequ", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectMat_req, "MgtrecGen", cJSON_CreateString("X"));/*X*/
		cJSON_AddItemToObject(ObjectMat_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectMat_req, "GenDialog", cJSON_CreateString(""));


	/*cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO75", ObjectO75_req);
		cJSON_AddItemToObject(ObjectO75_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO76", ObjectO76_req);
		cJSON_AddItemToObject(ObjectO76_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO77", ObjectO77_req);
		cJSON_AddItemToObject(ObjectO77_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO78", ObjectO78_req);
		cJSON_AddItemToObject(ObjectO78_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO79", ObjectO79_req);
		cJSON_AddItemToObject(ObjectO79_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO80", ObjectO80_req);
		cJSON_AddItemToObject(ObjectO80_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO81", ObjectO81_req);
		cJSON_AddItemToObject(ObjectO81_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO82", ObjectO82_req);
		cJSON_AddItemToObject(ObjectO82_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO83", ObjectO83_req);
		cJSON_AddItemToObject(ObjectO83_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "GenDialog", cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "Object084", Object084_req);
		cJSON_AddItemToObject(Object084_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "GenDialog", cJSON_CreateString(""));

	


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO85", ObjectO85_req);
		cJSON_AddItemToObject(ObjectO85_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO86", ObjectO86_req);
		cJSON_AddItemToObject(ObjectO86_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO87", ObjectO87_req);
		cJSON_AddItemToObject(ObjectO87_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO88", ObjectO88_req);
		cJSON_AddItemToObject(ObjectO88_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO89", ObjectO89_req);
		cJSON_AddItemToObject(ObjectO89_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO90", ObjectO90_req);
		cJSON_AddItemToObject(ObjectO90_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO91", ObjectO91_req);
		cJSON_AddItemToObject(ObjectO91_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO92", ObjectO92_req);
		cJSON_AddItemToObject(ObjectO92_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO93", ObjectO93_req);
		cJSON_AddItemToObject(ObjectO93_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO94", ObjectO94_req);
		cJSON_AddItemToObject(ObjectO94_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO95", ObjectO95_req);
		cJSON_AddItemToObject(ObjectO95_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO96", ObjectO96_req);
		cJSON_AddItemToObject(ObjectO96_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO97", ObjectO97_req);
		cJSON_AddItemToObject(ObjectO97_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO98", ObjectO98_req);
		cJSON_AddItemToObject(ObjectO98_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO99", ObjectO99_req);
		cJSON_AddItemToObject(ObjectO99_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPhrase", ObjectPhrase_req);
		cJSON_AddItemToObject(ObjectPhrase_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPvs", ObjectPvs_req);
		cJSON_AddItemToObject(ObjectPvs_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPvsAlt", ObjectPvsAlt_req);
		cJSON_AddItemToObject(ObjectPvsAlt_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPvsRel", ObjectPvsRel_req);
		cJSON_AddItemToObject(ObjectPvsRel_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPvsVar", ObjectPvsVar_req);
		cJSON_AddItemToObject(ObjectPvsVar_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsVar_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsVar_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsVar_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsVar_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsVar_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectSubstance", ObjectSubstance_req);
		cJSON_AddItemToObject(ObjectSubstance_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlist", ObjectTlist_req);
		cJSON_AddItemToObject(ObjectTlist_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistA", ObjectTlistA_req);
		cJSON_AddItemToObject(ObjectTlistA_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistE", ObjectTlistE_req);
		cJSON_AddItemToObject(ObjectTlistE_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistM", ObjectTlistM_req);
		cJSON_AddItemToObject(ObjectTlistM_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistN", ObjectTlistN_req);
		cJSON_AddItemToObject(ObjectTlistN_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistQ", ObjectTlistQ_req);
		cJSON_AddItemToObject(ObjectTlistQ_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistR", ObjectTlistR_req);
		cJSON_AddItemToObject(ObjectTlistR_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistS", ObjectTlistS_req);
		cJSON_AddItemToObject(ObjectTlistS_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistT", ObjectTlistT_req);
		cJSON_AddItemToObject(ObjectTlistT_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlist_2", ObjectTlist_2_req);
		cJSON_AddItemToObject(ObjectTlist_2_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectValidMatvers", ObjectValidMatvers_req);
		cJSON_AddItemToObject(ObjectValidMatvers_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectVarTab", ObjectVarTab_req);
		cJSON_AddItemToObject(ObjectVarTab_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "GenDialog", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "Objmgrec", Objmgrec_req);
		cJSON_AddItemToObject(Objmgrec_req, "item", Objmgrec_item_req);
			cJSON_AddItemToObject(Objmgrec_item_req, "AltDate", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "ChgObjtyp", cJSON_CreateString(""));//"4"
			cJSON_AddItemToObject(Objmgrec_item_req, "BomCat", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "BomStdObject", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "BomUsage", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "Chgtypeobj", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DescrObj", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DocType", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DocNumber", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DocVers", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DocPart", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "Equipment", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "FuncLoc", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "Material", cJSON_CreateString(""));/*PartNumC*/
			cJSON_AddItemToObject(Objmgrec_item_req, "Plant", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PspElement", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsGuid", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsType", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsNode", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsClassNumber", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsClassType", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsVariant", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "SdOrder", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "SdOrderI", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "Textkey", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "TlistType", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "TlistGrp", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "ObjChglock", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "StatusProfObj", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "FlDelete", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "Textheader", Textheader_req);
		cJSON_AddItemToObject(Textheader_req, "item", Textheader_item_req);
			cJSON_AddItemToObject(Textheader_item_req, "Textkey", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textheader_item_req, "Tdname", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textheader_item_req, "Tdid", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textheader_item_req, "Tdspras", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "Textlines", Textlines_req);
		cJSON_AddItemToObject(Textlines_req, "item", Textlines_item_req);
			cJSON_AddItemToObject(Textlines_item_req, "Textkey", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textlines_item_req, "Tdformat", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textlines_item_req, "Tdline", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ValueAssign", ValueAssign_req);
		cJSON_AddItemToObject(ValueAssign_req, "ValidFrom", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "ValidTo", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "DateMark", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Material", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "SerialnrLow", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "SerialnrHigh", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Product", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Class", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Classty", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Startup", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Plant", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Locno", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "SernrOi", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "FlDelete", cJSON_CreateString(""));*/

	out = cJSON_Print(rfc_root);
	//printf("%s\n", out);
	
	tc_strcpy(json_req_obj,out);
		
	free(out);
	cJSON_Delete(rfc_root);
	printf("\nend json for change no : %d",tc_strlen(json_req_obj)); fflush(stdout);
	return 0;
}


int create_change_no_in_sap ( char *data )
{
	struct memory chunk = {0};
	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	//const char *data = readd_sap_request_json_file();
	
	//printf("\nFile request content as below : %s",data);
	
	//curl_easy_setopt(curl, CURLOPT_URL, api_url);
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV_DEV");//ccap_ecn_create
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV_DEV");//ccap_ecn_create
	curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV");//ccap_ecn_create
	curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	
	list = curl_slist_append(list, "Content-Type: application/json");
    //curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);
	
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, 12L);
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\nFile request content as below "); fflush(stdout);
	print_json_object ( data ) ;
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
		printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
		printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
		printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	//printf ("\nresponse : [%s] [%d]",chunk.response,strlen(chunk.response)) ;
	printf("\ncurl_easy_perform");fflush(stdout);
	//print_json_object ( chunk.response ) ;
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "CHANGE_NO");
	
		printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
		printf("\nfree"); fflush(stdout);
	
    curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}
int cll_ccap_ecn_create()
{
	char *json_req_obj = NULL;
	json_req_obj = malloc(34000);
	change_no_json_cr ( json_req_obj );
	printf("%s\n", json_req_obj);
	
	create_change_no_in_sap ( json_req_obj ) ;
	
	free(json_req_obj);
	return 0;
}

/*
void displaying_objects_old(void)
{
	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;

	hRfc = BapiLogon();
	printf("\ncalling the change no creation function");
	RfcRc = cll_ccap_ecn_create(hRfc);
	RfcClose(hRfc);
}

RFC_RC cll_ccap_ecn_create_old(RFC_HANDLE hRfc)
{
	static RFC_RC RfcRc;
	int status;
	int p=0;
	char *PartNumC=NULL;
	char *part_typeC=NULL;

	tag_t PartTag1= NULLTAG;

	AENR_API01 eChangeHeader;
	CSDATA_XFELD eFlAle;
	CSDATA_XFELD eFlCommitAndWait;
	CSDATA_XFELD eFlNoCommitWork;
	AENV_API01 eObjectBom;
	AENV_API01 eObjectBomCus;
	AENV_API01 eObjectBomDoc;
	AENV_API01 eObjectBomEqui;
	AENV_API01 eObjectBomLoc;
	AENV_API01 eObjectBomMat;
	AENV_API01 eObjectBomPsp;
	AENV_API01 eObjectBomStd;
	AENV_API01 eObjectChar;
	AENV_API01 eObjectCls;
	AENV_API01 eObjectClsMaint;
	AENV_API01 eObjectConfProf;
	AENV_API01 eObjectDep;
	AENV_API01 eObjectDoc;
	AENV_API01 eObjectHazmat;
	AENV_API01 eObjectMat;
	AENV_API01 eObjectPhrase;
	AENV_API01 eObjectPvs;
	AENV_API01 eObjectPvsAlt;
	AENV_API01 eObjectPvsRel;
	AENV_API01 eObjectPvsVar;
	AENV_API01 eObjectSubstance;
	AENV_API01 eObjectTlist;
	AENV_API01 eObjectTlist2;
	AENV_API01 eObjectTlistA;
	AENV_API01 eObjectTlistE;
	AENV_API01 eObjectTlistM;
	AENV_API01 eObjectTlistN;
	AENV_API01 eObjectTlistQ;
	AENV_API01 eObjectTlistR;
	AENV_API01 eObjectTlistS;
	AENV_API01 eObjectTlistT;
	AENV_API01 eObjectValidMatvers;
	AENV_API01 eObjectVarTab;
	AEEF_API01 eValueAssign;
	AENRB_AENNR iChangeNo;
	ITAB_H thAltDates = ITAB_NULL;
	ITAB_H thEffectivity = ITAB_NULL;
	ITAB_H thObjmgrec = ITAB_NULL;
	ITAB_H thTextheader = ITAB_NULL;
	ITAB_H thTextlines = ITAB_NULL;
	char xException[256];

	AEOI_API01 *tObjmgrec;

	//tc_strdup("16.04.2018",&erc_release_date); //Temp Date

	printf("\nChangeNo : %s ",dml_numER);
	printf("\nDMLDescription : %s",DMLDescription);
	printf("\nERC_RELEASE_DATE : %s",erc_release_date);
	
	SETCHAR(eChangeHeader.ChangeNo,dml_numER);
	SETNUM(eChangeHeader.Status,"01");
	SETCHAR(eChangeHeader.AuthGroup,"");

	SETCHAR(eChangeHeader.ValidFrom,erc_release_date);
	SETCHAR(eChangeHeader.Descript,DMLDescription);
	SETCHAR(eChangeHeader.ReasonChg,"");
	SETCHAR(eChangeHeader.DeletionMark,"");
	SETCHAR(eChangeHeader.IndateRule,"");
	SETCHAR(eChangeHeader.OutdateRule,"");
	SETCHAR(eChangeHeader.Function,"");
	SETCHAR(eChangeHeader.ChangeLeader,"");
	SETCHAR(eChangeHeader.EffectivityType,"");
	SETCHAR(eChangeHeader.OverridingMark,"");
	SETNUM(eChangeHeader.Rank,"");
	SETNUM(eChangeHeader.ReleaseKey,"");
	SETCHAR(eChangeHeader.StatusProfile,"");
	SETCHAR(eChangeHeader.TechRel,"");
	SETCHAR(eChangeHeader.BasicChange,"");
	SETCHAR(eFlAle,"");
	SETCHAR(eFlCommitAndWait,"X");
	SETCHAR(eFlNoCommitWork,"");
	SETCHAR(eObjectBom.Active,"");
	SETCHAR(eObjectBom.Locked,"");
	SETCHAR(eObjectBom.ObjRequ,"");
	SETCHAR(eObjectBom.MgtrecGen,"");
	SETCHAR(eObjectBom.GenNew,"");
	SETCHAR(eObjectBom.GenDialog,"");
	SETCHAR(eObjectBomCus.Active,"");
	SETCHAR(eObjectBomCus.Locked,"");
	SETCHAR(eObjectBomCus.ObjRequ,"");
	SETCHAR(eObjectBomCus.MgtrecGen,"");
	SETCHAR(eObjectBomCus.GenNew,"");
	SETCHAR(eObjectBomCus.GenDialog,"");
	SETCHAR(eObjectBomDoc.Active,"");
	SETCHAR(eObjectBomDoc.Locked,"");
	SETCHAR(eObjectBomDoc.ObjRequ,"");
	SETCHAR(eObjectBomDoc.MgtrecGen,"");
	SETCHAR(eObjectBomDoc.GenNew,"");
	SETCHAR(eObjectBomDoc.GenDialog,"");
	SETCHAR(eObjectBomEqui.Active,"");
	SETCHAR(eObjectBomEqui.Locked,"");
	SETCHAR(eObjectBomEqui.ObjRequ,"");
	SETCHAR(eObjectBomEqui.MgtrecGen,"");
	SETCHAR(eObjectBomEqui.GenNew,"");
	SETCHAR(eObjectBomEqui.GenDialog,"");
	SETCHAR(eObjectBomLoc.Active,"");
	SETCHAR(eObjectBomLoc.Locked,"");
	SETCHAR(eObjectBomLoc.ObjRequ,"");
	SETCHAR(eObjectBomLoc.MgtrecGen,"");
	SETCHAR(eObjectBomLoc.GenNew,"");
	SETCHAR(eObjectBomLoc.GenDialog,"");
	SETCHAR(eObjectBomMat.Active,"X");
	SETCHAR(eObjectBomMat.Locked,"");
	SETCHAR(eObjectBomMat.ObjRequ,"X");
	SETCHAR(eObjectBomMat.MgtrecGen,"X");
	SETCHAR(eObjectBomMat.GenNew,"");
	SETCHAR(eObjectBomMat.GenDialog,"");
	SETCHAR(eObjectBomPsp.Active,"");
	SETCHAR(eObjectBomPsp.Locked,"");
	SETCHAR(eObjectBomPsp.ObjRequ,"");
	SETCHAR(eObjectBomPsp.MgtrecGen,"");
	SETCHAR(eObjectBomPsp.GenNew,"");
	SETCHAR(eObjectBomPsp.GenDialog,"");
	SETCHAR(eObjectBomStd.Active,"");
	SETCHAR(eObjectBomStd.Locked,"");
	SETCHAR(eObjectBomStd.ObjRequ,"");
	SETCHAR(eObjectBomStd.MgtrecGen,"");
	SETCHAR(eObjectBomStd.GenNew,"");
	SETCHAR(eObjectBomStd.GenDialog,"");
	SETCHAR(eObjectChar.Active,"");
	SETCHAR(eObjectChar.Locked,"");
	SETCHAR(eObjectChar.ObjRequ,"");
	SETCHAR(eObjectChar.MgtrecGen,"");
	SETCHAR(eObjectChar.GenNew,"");
	SETCHAR(eObjectChar.GenDialog,"");
	SETCHAR(eObjectCls.Active,"");
	SETCHAR(eObjectCls.Locked,"");
	SETCHAR(eObjectCls.ObjRequ,"");
	SETCHAR(eObjectCls.MgtrecGen,"");
	SETCHAR(eObjectCls.GenNew,"");
	SETCHAR(eObjectCls.GenDialog,"");
	SETCHAR(eObjectClsMaint.Active,"");
	SETCHAR(eObjectClsMaint.Locked,"");
	SETCHAR(eObjectClsMaint.ObjRequ,"");
	SETCHAR(eObjectClsMaint.MgtrecGen,"");
	SETCHAR(eObjectClsMaint.GenNew,"");
	SETCHAR(eObjectClsMaint.GenDialog,"");
	SETCHAR(eObjectConfProf.Active,"");
	SETCHAR(eObjectConfProf.Locked,"");
	SETCHAR(eObjectConfProf.ObjRequ,"");
	SETCHAR(eObjectConfProf.MgtrecGen,"");
	SETCHAR(eObjectConfProf.GenNew,"");
	SETCHAR(eObjectConfProf.GenDialog,"");
	SETCHAR(eObjectDep.Active,"");
	SETCHAR(eObjectDep.Locked,"");
	SETCHAR(eObjectDep.ObjRequ,"");
	SETCHAR(eObjectDep.MgtrecGen,"");
	SETCHAR(eObjectDep.GenNew,"");
	SETCHAR(eObjectDep.GenDialog,"");
	SETCHAR(eObjectDoc.Active,"X");
	SETCHAR(eObjectDoc.Locked,"");
	SETCHAR(eObjectDoc.ObjRequ,"X");
	SETCHAR(eObjectDoc.MgtrecGen,"X");
	SETCHAR(eObjectDoc.GenNew,"");
	SETCHAR(eObjectDoc.GenDialog,"");
	SETCHAR(eObjectHazmat.Active,"");
	SETCHAR(eObjectHazmat.Locked,"");
	SETCHAR(eObjectHazmat.ObjRequ,"");
	SETCHAR(eObjectHazmat.MgtrecGen,"");
	SETCHAR(eObjectHazmat.GenNew,"");
	SETCHAR(eObjectHazmat.GenDialog,"");
	SETCHAR(eObjectMat.Active,"X");
	SETCHAR(eObjectMat.Locked,"");
	SETCHAR(eObjectMat.ObjRequ,"X");
	SETCHAR(eObjectMat.MgtrecGen,"X");
	SETCHAR(eObjectMat.GenNew,"");
	SETCHAR(eObjectMat.GenDialog,"");
	SETCHAR(eObjectPhrase.Active,"");
	SETCHAR(eObjectPhrase.Locked,"");
	SETCHAR(eObjectPhrase.ObjRequ,"");
	SETCHAR(eObjectPhrase.MgtrecGen,"");
	SETCHAR(eObjectPhrase.GenNew,"");
	SETCHAR(eObjectPhrase.GenDialog,"");
	SETCHAR(eObjectPvs.Active,"");
	SETCHAR(eObjectPvs.Locked,"");
	SETCHAR(eObjectPvs.ObjRequ,"");
	SETCHAR(eObjectPvs.MgtrecGen,"");
	SETCHAR(eObjectPvs.GenNew,"");
	SETCHAR(eObjectPvs.GenDialog,"");
	SETCHAR(eObjectPvsAlt.Active,"");
	SETCHAR(eObjectPvsAlt.Locked,"");
	SETCHAR(eObjectPvsAlt.ObjRequ,"");
	SETCHAR(eObjectPvsAlt.MgtrecGen,"");
	SETCHAR(eObjectPvsAlt.GenNew,"");
	SETCHAR(eObjectPvsAlt.GenDialog,"");
	SETCHAR(eObjectPvsRel.Active,"");
	SETCHAR(eObjectPvsRel.Locked,"");
	SETCHAR(eObjectPvsRel.ObjRequ,"");
	SETCHAR(eObjectPvsRel.MgtrecGen,"");
	SETCHAR(eObjectPvsRel.GenNew,"");
	SETCHAR(eObjectPvsRel.GenDialog,"");
	SETCHAR(eObjectPvsVar.Active,"");
	SETCHAR(eObjectPvsVar.Locked,"");
	SETCHAR(eObjectPvsVar.ObjRequ,"");
	SETCHAR(eObjectPvsVar.MgtrecGen,"");
	SETCHAR(eObjectPvsVar.GenNew,"");
	SETCHAR(eObjectPvsVar.GenDialog,"");
	SETCHAR(eObjectSubstance.Active,"");
	SETCHAR(eObjectSubstance.Locked,"");
	SETCHAR(eObjectSubstance.ObjRequ,"");
	SETCHAR(eObjectSubstance.MgtrecGen,"");
	SETCHAR(eObjectSubstance.GenNew,"");
	SETCHAR(eObjectSubstance.GenDialog,"");
	SETCHAR(eObjectTlist.Active,"");
	SETCHAR(eObjectTlist.Locked,"");
	SETCHAR(eObjectTlist.ObjRequ,"");
	SETCHAR(eObjectTlist.MgtrecGen,"");
	SETCHAR(eObjectTlist.GenNew,"");
	SETCHAR(eObjectTlist.GenDialog,"");
	SETCHAR(eObjectTlist2.Active,"");
	SETCHAR(eObjectTlist2.Locked,"");
	SETCHAR(eObjectTlist2.ObjRequ,"");
	SETCHAR(eObjectTlist2.MgtrecGen,"");
	SETCHAR(eObjectTlist2.GenNew,"");
	SETCHAR(eObjectTlist2.GenDialog,"");
	SETCHAR(eObjectTlistA.Active,"");
	SETCHAR(eObjectTlistA.Locked,"");
	SETCHAR(eObjectTlistA.ObjRequ,"");
	SETCHAR(eObjectTlistA.MgtrecGen,"");
	SETCHAR(eObjectTlistA.GenNew,"");
	SETCHAR(eObjectTlistA.GenDialog,"");
	SETCHAR(eObjectTlistE.Active,"");
	SETCHAR(eObjectTlistE.Locked,"");
	SETCHAR(eObjectTlistE.ObjRequ,"");
	SETCHAR(eObjectTlistE.MgtrecGen,"");
	SETCHAR(eObjectTlistE.GenNew,"");
	SETCHAR(eObjectTlistE.GenDialog,"");
	SETCHAR(eObjectTlistM.Active,"");
	SETCHAR(eObjectTlistM.Locked,"");
	SETCHAR(eObjectTlistM.ObjRequ,"");
	SETCHAR(eObjectTlistM.MgtrecGen,"");
	SETCHAR(eObjectTlistM.GenNew,"");
	SETCHAR(eObjectTlistM.GenDialog,"");
	SETCHAR(eObjectTlistN.Active,"");
	SETCHAR(eObjectTlistN.Locked,"");
	SETCHAR(eObjectTlistN.ObjRequ,"");
	SETCHAR(eObjectTlistN.MgtrecGen,"");
	SETCHAR(eObjectTlistN.GenNew,"");
	SETCHAR(eObjectTlistN.GenDialog,"");
	SETCHAR(eObjectTlistQ.Active,"");
	SETCHAR(eObjectTlistQ.Locked,"");
	SETCHAR(eObjectTlistQ.ObjRequ,"");
	SETCHAR(eObjectTlistQ.MgtrecGen,"");
	SETCHAR(eObjectTlistQ.GenNew,"");
	SETCHAR(eObjectTlistQ.GenDialog,"");
	SETCHAR(eObjectTlistR.Active,"");
	SETCHAR(eObjectTlistR.Locked,"");
	SETCHAR(eObjectTlistR.ObjRequ,"");
	SETCHAR(eObjectTlistR.MgtrecGen,"");
	SETCHAR(eObjectTlistR.GenNew,"");
	SETCHAR(eObjectTlistR.GenDialog,"");
	SETCHAR(eObjectTlistS.Active,"");
	SETCHAR(eObjectTlistS.Locked,"");
	SETCHAR(eObjectTlistS.ObjRequ,"");
	SETCHAR(eObjectTlistS.MgtrecGen,"");
	SETCHAR(eObjectTlistS.GenNew,"");
	SETCHAR(eObjectTlistS.GenDialog,"");
	SETCHAR(eObjectTlistT.Active,"");
	SETCHAR(eObjectTlistT.Locked,"");
	SETCHAR(eObjectTlistT.ObjRequ,"");
	SETCHAR(eObjectTlistT.MgtrecGen,"");
	SETCHAR(eObjectTlistT.GenNew,"");
	SETCHAR(eObjectTlistT.GenDialog,"");
	SETCHAR(eObjectValidMatvers.Active,"");
	SETCHAR(eObjectValidMatvers.Locked,"");
	SETCHAR(eObjectValidMatvers.ObjRequ,"");
	SETCHAR(eObjectValidMatvers.MgtrecGen,"");
	SETCHAR(eObjectValidMatvers.GenNew,"");
	SETCHAR(eObjectValidMatvers.GenDialog,"");
	SETCHAR(eObjectVarTab.Active,"");
	SETCHAR(eObjectVarTab.Locked,"");
	SETCHAR(eObjectVarTab.ObjRequ,"");
	SETCHAR(eObjectVarTab.MgtrecGen,"");
	SETCHAR(eObjectVarTab.GenNew,"");
	SETCHAR(eObjectVarTab.GenDialog,"");
	SETCHAR(eValueAssign.ValidFrom,"");
	SETCHAR(eValueAssign.ValidTo,"");
	SETCHAR(eValueAssign.DateMark,"");
	SETCHAR(eValueAssign.Material,"");
	SETCHAR(eValueAssign.SerialnrLow,"");
	SETCHAR(eValueAssign.SerialnrHigh,"");
	SETCHAR(eValueAssign.Class,"");
	SETCHAR(eValueAssign.Classty,"");
	SETCHAR(eValueAssign.Startup,"");
	SETCHAR(eValueAssign.Plant,"");
	SETCHAR(eValueAssign.SernrOi,"");
	SETCHAR(eValueAssign.FlDelete,"");


    if (thAltDates==ITAB_NULL)
	{
		thAltDates = ItCreate("ALT_DATES", sizeof(AEDT_API01), 0, 0);
		if (thAltDates == ITAB_NULL)
			printf("\nItCreate ALT_DATES");
	}
    else if (ItFree(thAltDates) != 0)
		printf("\nItFree ALT_DATES");

    if (thEffectivity==ITAB_NULL)
	{
		thEffectivity = ItCreate("EFFECTIVITY", sizeof(AEEF_API01), 0, 0);
		if (thEffectivity == ITAB_NULL)
			printf("\nItCreate EFFECTIVITY");
	}
    else if (ItFree(thEffectivity) != 0)
		printf("\nItFree EFFECTIVITY");

	if (thObjmgrec==ITAB_NULL)
	{
		thObjmgrec = ItCreate("OBJMGREC", sizeof(AEOI_API01), 0, 0);
		if (thObjmgrec==ITAB_NULL)
			printf("\nItCreate OBJMGREC");
	}
    else if (ItFree(thObjmgrec) != 0)
		printf("\nItFree OBJMGREC");

    if (thTextheader==ITAB_NULL)
	{
		thTextheader = ItCreate("TEXTHEADER", sizeof(CCTHEAD), 0, 0);
		if (thTextheader==ITAB_NULL)
			printf("\nItCreate TEXTHEADER");
	 }
    else if (ItFree(thTextheader) != 0)
		printf("\nItFree TEXTHEADER");

    if (thTextlines==ITAB_NULL)
	{
		thTextlines = ItCreate("TEXTLINES", sizeof(CCTLINE), 0, 0);
		if (thTextlines==ITAB_NULL)
			printf("\nItCreate TEXTLINES");
	}
    else if (ItFree(thTextlines) != 0)
		printf("\nItFree TEXTLINES");

	printf("\nSetOfPartTags in Displaying Object %d",partCnt);
	fprintf(fsuccess,"\nSetOfPartTags in Displaying Object %d",partCnt);

	if(partCnt>0)
	{
		for(p=0;p<partCnt;p++)
		{
			PartTag1=SetOfPartTags[p];
			ITK_CALL(AOM_ask_value_string(PartTag1,"item_id",&PartNumC));
			ITK_CALL(AOM_ask_value_string(PartTag1,"t5_PartType",&part_typeC));
			
			//Skipping Dummy,Dummy Assembly/Component,Info Fit Drw Parts
			if(	tc_strcmp(part_typeC,"D")==0 ||
				tc_strcmp(part_typeC,"DA")==0 ||
				tc_strcmp(part_typeC,"DC")==0 ||
				tc_strcmp(part_typeC,"CM")==0 ||//added 25.03.2023 Hrishikesh
				tc_strcmp(part_typeC,"IFD")==0 ||
				tc_strcmp(part_typeC,"IM")==0 ||
				tc_strcmp(part_typeC,"CP")==0)
			{	continue;	}

			printf("\nAdding partno As Part is %s %s", PartNumC,part_typeC);
			fprintf(fsuccess,"\nAdding partno As Part is %s %s", PartNumC,part_typeC);

			tObjmgrec = ItAppLine(thObjmgrec);
			if (tObjmgrec == NULL)
				printf("\nItAppLine OBJMGREC");

			SETCHAR(tObjmgrec->AltDate,"");
			SETNUM(tObjmgrec->ChgObjtyp,"");
			SETNUM(tObjmgrec->ChgObjtyp,"4");
			SETCHAR(tObjmgrec->BomCat,"");
			SETCHAR(tObjmgrec->BomStdObject,"");
			SETCHAR(tObjmgrec->BomUsage,"");
			SETNUM(tObjmgrec->Chgtypeobj,"");
			SETCHAR(tObjmgrec->DescrObj,"");
			SETCHAR(tObjmgrec->DocType,"");
			SETCHAR(tObjmgrec->DocNumber,"");
			SETCHAR(tObjmgrec->DocVers,"");
			SETCHAR(tObjmgrec->DocPart,"");
			SETCHAR(tObjmgrec->Equipment,"");
			SETCHAR(tObjmgrec->FuncLoc,"");
			SETCHAR(tObjmgrec->Material,PartNumC);
			SETCHAR(tObjmgrec->Plant,"");
			SETCHAR(tObjmgrec->PspElement,"");
			SETCHAR(tObjmgrec->PvsType,"");
			SETCHAR(tObjmgrec->PvsNode,"");
			SETCHAR(tObjmgrec->PvsClassNumber,"");
			SETCHAR(tObjmgrec->PvsClassType,"");
			SETCHAR(tObjmgrec->PvsVariant,"");
			SETCHAR(tObjmgrec->SdOrder,"");
			SETNUM(tObjmgrec->SdOrderI,"");
			SETNUM(tObjmgrec->Textkey,"");
			SETCHAR(tObjmgrec->TlistType,"");
			SETCHAR(tObjmgrec->TlistGrp,"");
			SETCHAR(tObjmgrec->ObjChglock,"");
			SETCHAR(tObjmgrec->StatusProfObj,"");
			SETCHAR(tObjmgrec->FlDelete,"");
		}
	}
	RfcRc = ccap_ecn_create(hRfc,&eChangeHeader,&eFlAle,&eFlCommitAndWait,&eFlNoCommitWork,&eObjectBom,&eObjectBomCus,&eObjectBomDoc,&eObjectBomEqui,&eObjectBomLoc,&eObjectBomMat,&eObjectBomPsp,&eObjectBomStd,&eObjectChar,&eObjectCls,&eObjectClsMaint,&eObjectConfProf,&eObjectDep,&eObjectDoc,&eObjectHazmat,&eObjectMat,&eObjectPhrase,&eObjectPvs,&eObjectPvsAlt,&eObjectPvsRel,&eObjectPvsVar,&eObjectSubstance,&eObjectTlist,&eObjectTlist2,&eObjectTlistA,&eObjectTlistE,&eObjectTlistM,&eObjectTlistN,&eObjectTlistQ,&eObjectTlistR,&eObjectTlistS,&eObjectTlistT,&eObjectValidMatvers,&eObjectVarTab,&eValueAssign,&iChangeNo,thAltDates,thEffectivity,thObjmgrec,thTextheader,thTextlines,xException);
	switch (RfcRc)
	{
		case RFC_OK:
			printf("\necn create: %u",RFC_OK);
			fprintf(fsuccess,"\necn create: %u",RFC_OK);
		break;
		case RFC_EXCEPTION :
			printf("\nRFC Exception: %s",xException);
			fprintf(fsuccess,"\nRFC Exception: %s",xException);
		break;
		default:;
	}
	EXIT:
	printf("exit from bapi");
	return RfcRc;
}

RFC_RC export_CSpastat(RFC_HANDLE hRfc,MATNR *eMatnr,WERKS_D* eWerks,PLANTDATA* iMrpView, CLIENTDATA* iView, char *xException)
{
	RFC_RC RfcRc;
	RFC_PARAMETER Exporting[3];
	RFC_PARAMETER Importing[3];
	RFC_TABLE Tables[1];
	char *RfcException = NULL;

	Exporting[0].name = "MATERIAL";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfMATNR;
	Exporting[0].leng = sizeof(MATNR);
	Exporting[0].addr = eMatnr;

	Exporting[1].name = "PLANT";
	Exporting[1].nlen = 5;
	Exporting[1].type = handleOfWERKS_D;
	Exporting[1].leng = sizeof(WERKS_D);
	Exporting[1].addr = eWerks;

	Exporting[2].name = NULL;

	Tables[0].name = NULL;

	RfcRc = RfcCall(hRfc,"BAPI_MATERIAL_GETALL",Exporting,Tables);

	switch (RfcRc)
	{
	  	case RFC_OK :

			Importing[0].name = "CLIENTDATA";
			Importing[0].nlen = 10;
			Importing[0].type = handleOfCLIENTDATA;
			Importing[0].leng = sizeof(CLIENTDATA);
			Importing[0].addr = iView;

			Importing[1].name = "PLANTDATA";
			Importing[1].nlen = 9;
			Importing[1].type = handleOfPLANTDATA;
			Importing[1].leng = sizeof(PLANTDATA);
			Importing[1].addr = iMrpView;

			Importing[2].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
	  			case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				default:;
			}
		default:;
	}
	return RfcRc;
}

int GetCSPstat(char cMaterial[15])
{
	char xException[256];
	RFC_HANDLE hRfc;
	RFC_RC RfcRc;
	MATNR eMatnr;
	WERKS_D eWerks;
	PLANTDATA iMrpView;
	CLIENTDATA iView;

	char *plantcode=NULL;
	tc_strdup("1001",&plantcode);

	printf("\nProcessing GetCSPstat:[%s,%s]",cMaterial,plantcode);

	hRfc = BapiLogon();

	tc_strcpy(SAPpstat,"");
	tc_strcpy(MRPpstat,"");

	SETCHAR(eMatnr.Matnr,cMaterial);
	//SETCHAR(eMatnr.Matnr,part_noDup);
	SETCHAR(eWerks.WerksD,plantcode);

	RfcRc = export_CSpastat(hRfc
							,&eMatnr
							,&eWerks
							,&iMrpView
							,&iView
							,xException);

	switch (RfcRc)
	{
		case RFC_OK:
			//printf("\n In RFC_OK case...\n");	fflush(stdout);
			GETCHAR(iView.MAINT_STAT, SAPpstat);
			//nlsStrTrimTrailWhiteSpace(SAPpstat);
			//nlsStrTrimLeadWhiteSpace(SAPpstat);
			SAPpstat[tc_strlen(SAPpstat)] = '\0';

			GETCHAR(iMrpView.MAINT_STAT, MRPpstat);
			//nlsStrTrimTrailWhiteSpace(MRPpstat);
			//nlsStrTrimLeadWhiteSpace(MRPpstat);
			MRPpstat[tc_strlen(MRPpstat)] = '\0';

		break;
		case RFC_EXCEPTION:
			printf("\nRFC Exception : %s",xException);
			exit(0);
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");
			exit(0);
		break;
		case RFC_FAILURE:
			printf("\nFailure!!!");
			exit(0);
		break;
		default:
			printf("\nOther Failure!");
			exit(0);
	}

	RfcClose(hRfc);
	return 0;
}

void CLL_BAPI_MATERIAL_SAVEDATA(void)
{
	static RFC_RC RfcRc;
	static RFC_HANDLE hRfc;
	char xException[256];

	BAPIMATHEAD eBapiMatHead;
	BAPI_MARA	eBasicView;
	BAPI_MARAX	eBasicViewx;
	RMMG1_AENNR eRmmg1_Aennr;
	BAPIRET2	eBapiret2;

	ITAB_H thBapi_Makt = ITAB_NULL;
	ITAB_H thBapi_Marm = ITAB_NULL;
	ITAB_H thBapi_Marmx = ITAB_NULL;
	ITAB_H thBapi_Mean = ITAB_NULL;
	ITAB_H thBAPIE1PAREX3 = ITAB_NULL;
	ITAB_H thBAPIE1PAREXX3 = ITAB_NULL;

	BAPI_MAKT *tBapi_Makt;
	BAPI_MARM *tBapi_Marm;
	BAPI_MARMX *tBapi_Marmx;
	BAPI_MEAN *tBapi_Mean;

	BAPIE1PAREX3 *tBAPIE1PAREX3;
	BAPIE1PAREXX3 *tBAPIE1PAREXX3;

	pstat='0';

	tc_strcpy(SAPpstat,"");
	tc_strcpy(MRPpstat,"");
	pstat='0';
	GetCSPstat(part_noDup);
	printf("\n SAPpstat:[%s][%s][%s]",part_noDup,SAPpstat,MRPpstat) ; fflush(stdout);
	fprintf(fsuccess,"\n SAPpstat:[%s][%s][%s]",part_noDup,SAPpstat,MRPpstat) ; fflush(fsuccess);

	pstat_basicFun();
	printf("\n... pstat Values are :%c:",pstat);fflush(stdout);
	fprintf(fsuccess,"\n... pstat Values are :%c:",pstat);fflush(stdout);
	//pstat='0';
	if (pstat=='K')
	{
			printf("\nMessage for Basic Material Create: Material %s already exists \n", part_noDup);
			printf("\n****************************************************************");
			fprintf(fsuccess, "\nMessage for Basic Material Create: Material %s already exists", part_noDup);
			fprintf(fsuccess, "\n****************************************************************");
	}
	else
	{
		hRfc = BapiLogon();
		SETCHAR(eBapiMatHead.Material,part_noDup);
		SETCHAR(eBapiMatHead.Ind_Sector,"M");
		SETCHAR(eBapiMatHead.Matl_Type,mat_type);
		SETCHAR(eBapiMatHead.Basic_View,"X");
		SETCHAR(eBapiMatHead.Sales_View,"");
		SETCHAR(eBapiMatHead.Purchase_View,"");
		SETCHAR(eBapiMatHead.Mrp_View,"");
		SETCHAR(eBapiMatHead.Forecast_View,"");
		SETCHAR(eBapiMatHead.Work_Sched_View,"");
		SETCHAR(eBapiMatHead.Prt_View,"");
		SETCHAR(eBapiMatHead.Storage_View,"");
		SETCHAR(eBapiMatHead.Warehouse_View,"");
		SETCHAR(eBapiMatHead.Quality_View,"");
		SETCHAR(eBapiMatHead.Account_View,"");
		SETCHAR(eBapiMatHead.Cost_View,"");
		SETCHAR(eBapiMatHead.Inp_Fld_Check,"");
		SETCHAR(eBapiMatHead.Material_External,"");
		SETCHAR(eBapiMatHead.MateriaL_Guid,"");
		SETCHAR(eBapiMatHead.Material_Version,"");
		SETCHAR(eRmmg1_Aennr.Aennr,dml_numER);

		SETCHAR(eBasicView.Del_Flag,"");
		SETCHAR(eBasicView.Matl_Group,mat_grp);

		if(OldMatNoDup == NULL)
		{
			SETCHAR(eBasicView.Old_Mat_No,"");
			SETCHAR(eBasicViewx.Old_Mat_No,"");
		}
		else
		{
			SETCHAR(eBasicView.Old_Mat_No,OldMatNoDup);
			SETCHAR(eBasicViewx.Old_Mat_No,"X");
		}

		SETCHAR(eBasicView.Base_Uom,meas_unit);
		SETCHAR(eBasicView.Base_Uom_Iso,meas_unit);
		SETCHAR(eBasicView.Po_Unit,"");
		SETCHAR(eBasicView.Po_Unit_Iso,"");
		if(doc_noDup == NULL)
		{
			SETCHAR(eBasicView.Document,"");
			SETCHAR(eBasicViewx.Document,"");
		}
		else
		{
			SETCHAR(eBasicView.Document,doc_noDup);
			SETCHAR(eBasicViewx.Document,"X");
		}

		if(dwg_typeDup == NULL)
		{
			SETCHAR(eBasicView.Doc_Type,"");
			SETCHAR(eBasicViewx.Doc_Type,"");
		}
		else
		{
			SETCHAR(eBasicView.Doc_Type,dwg_typeDup);
			SETCHAR(eBasicViewx.Doc_Type,"X");
		}

		if(dwg_revDup == NULL)
		{
			SETCHAR(eBasicView.Doc_Vers,"");
			SETCHAR(eBasicViewx.Doc_Vers,"");
		}
		else
		{
			SETCHAR(eBasicView.Doc_Vers,dwg_revDup);
			SETCHAR(eBasicViewx.Doc_Vers,"X");
		}

		SETCHAR(eBasicView.Doc_Format,"");
		SETCHAR(eBasicView.Doc_Chg_No,"");
		SETCHAR(eBasicView.Page_No,"");
		if(sizeDup == NULL)
		{
			SETNUM(eBasicView.No_Sheets,"");
			SETCHAR(eBasicViewx.No_Sheets,"");
		}
		else
		{
			SETNUM(eBasicView.No_Sheets,sizeDup);
			SETCHAR(eBasicViewx.No_Sheets,"X");
		}

		SETCHAR(eBasicView.Prod_Memo,"");
		SETCHAR(eBasicView.Pageformat,"");
		SETCHAR(eBasicView.Size_Dim,"");
		SETCHAR(eBasicView.Basic_Matl,"");
		SETCHAR(eBasicView.Std_Descr,"");
		SETCHAR(eBasicView.Dsn_Office,"");
		SETCHAR(eBasicView.Pur_Valkey,"");

		SETBCD(eBasicView.Net_Weight,net_wtDup,3);
		SETCHAR(eBasicViewx.Net_Weight,"X");
		if(weight_unit == NULL)
		{
			SETCHAR(eBasicView.Unit_Of_Wt,"");
			SETCHAR(eBasicViewx.Unit_Of_Wt,"");
		}
		else
		{
			SETCHAR(eBasicView.Unit_Of_Wt,weight_unit);
			SETCHAR(eBasicViewx.Unit_Of_Wt,"X");
		}

		if(weight_unit == NULL)
		{
			SETCHAR(eBasicView.Unit_Of_Wt_Iso,"");
			SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"");
		}
		else
		{
			SETCHAR(eBasicView.Unit_Of_Wt_Iso,weight_unit);
			SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"X");
		}

		SETCHAR(eBasicView.Container,"");
		SETCHAR(eBasicView.Stor_Conds,"");
		SETCHAR(eBasicView.Temp_Conds,"");
		SETCHAR(eBasicView.Trans_Grp,"");
		SETCHAR(eBasicView.Haz_Mat_No,"");
		SETCHAR(eBasicView.Division,division);
		SETCHAR(eBasicView.Competitor,"");
		SETBCD(eBasicView.Qty_Gr_Gi,myzeroDup3,3);
		SETCHAR(eBasicView.Proc_Rule,"");
		SETCHAR(eBasicView.Sup_Source,"");
		SETCHAR(eBasicView.Season,"");
		SETCHAR(eBasicView.Label_Type,"");
		SETCHAR(eBasicView.Label_Form,"");
		SETCHAR(eBasicView.Prod_Hier,"");
		SETCHAR(eBasicView.Cad_Id,"");
		SETBCD(eBasicView.Allowed_Wt,myzeroDup3,3);
		SETCHAR(eBasicView.Pack_Wt_Un,"");
		SETCHAR(eBasicView.Pack_Wt_Un_Iso,"");
		SETBCD(eBasicView.Allwd_Vol,myzeroDup3,3);
		SETCHAR(eBasicView.Pack_Vo_Un,"");
		SETCHAR(eBasicView.Pack_Vo_Un_Iso,"");
		SETBCD(eBasicView.Wt_Tol_Lt,myzeroDup1,1);
		SETBCD(eBasicView.Vol_Tol_Lt,myzeroDup1,1);
		SETCHAR(eBasicView.Var_Ord_Un,"");
		SETCHAR(eBasicView.Batch_Mgmt,"");
		SETCHAR(eBasicView.Sh_Mat_Typ,"");
		SETBCD(eBasicView.Fill_Level,"0",0);
		SETINT2(&eBasicView.Stack_Fact,"0");
		SETCHAR(eBasicView.Mat_Grp_Sm,"");
		SETCHAR(eBasicView.Authoritygroup,"");
		SETCHAR(eBasicView.Qm_Procmnt,"");
		SETCHAR(eBasicView.Catprofile,"");
		SETBCD(eBasicView.Minremlife,"0",0);
		SETBCD(eBasicView.Shelf_Life,"0",0);
		SETBCD(eBasicView.Stor_Pct,"0",0);
		SETCHAR(eBasicView.Pur_Status,"");
		SETCHAR(eBasicView.Sal_Status,"");
		SETDATE(eBasicView.Pvalidfrom,"");
		SETDATE(eBasicView.Svalidfrom,"");
		SETCHAR(eBasicView.Envt_Rlvt,"");
		SETCHAR(eBasicView.Prod_Alloc,"");
		SETCHAR(eBasicView.Qual_Dik,"");
		SETCHAR(eBasicView.Manu_Mat,"");
		SETCHAR(eBasicView.Mfr_No,"");
		SETCHAR(eBasicView.Inv_Mat_No,"");
		SETCHAR(eBasicView.Manuf_Prof,"");
		SETCHAR(eBasicView.Hazmatprof,"");
		SETCHAR(eBasicView.High_Visc,"");
		SETCHAR(eBasicView.Looseorliq,"");
		SETCHAR(eBasicView.Closed_Box,"");
		SETCHAR(eBasicView.Appd_B_Rec,"");
		SETNUM(eBasicView.Matcmpllvl,"00");
		SETCHAR(eBasicView.Par_Eff,"");
		SETCHAR(eBasicView.Round_Up_Rule_Expiration_Date,"");
		SETCHAR(eBasicView.Period_Ind_Expiration_Date,"D");
		SETCHAR(eBasicView.Prod_Composition_On_Packaging,"");
		SETCHAR(eBasicView.Item_Cat,"");
		SETCHAR(eBasicView.Haz_Mat_No_External,"");
		SETCHAR(eBasicView.Haz_Mat_No_Guid,"");
		SETCHAR(eBasicView.Haz_Mat_No_Version,"");
		SETCHAR(eBasicView.Inv_Mat_No_External,"");
		SETCHAR(eBasicView.Inv_Mat_No_Guid,"");
		SETCHAR(eBasicView.Inv_Mat_No_Version,"");
		SETCHAR(eBasicView.Material_Fixed,"");
		SETCHAR(eBasicView.Cm_Relevance_Flag,"");
		SETCHAR(eBasicView.Sled_Bbd,"");
		SETCHAR(eBasicView.Gtin_Variant,"");
		SETCHAR(eBasicView.Serialization_Level,"");
		SETCHAR(eBasicView.Pl_Ref_Mat,"");
		SETCHAR(eBasicView.Extmatlgrp,"");
		SETCHAR(eBasicView.Uomusage,"");
		SETCHAR(eBasicView.Pl_Ref_Mat_External,"");
		SETCHAR(eBasicView.Pl_Ref_Mat_Guid,"");
		SETCHAR(eBasicView.Pl_Ref_Mat_Version,"");

		SETCHAR(eBasicViewx.Del_Flag,"");
		SETCHAR(eBasicViewx.Matl_Group,"X");

		SETCHAR(eBasicViewx.Base_Uom,"X");
		SETCHAR(eBasicViewx.Base_Uom_Iso,"X");
		SETCHAR(eBasicViewx.Po_Unit,"");
		SETCHAR(eBasicViewx.Po_Unit_Iso,"");
		SETCHAR(eBasicViewx.Doc_Format,"");
		SETCHAR(eBasicViewx.Doc_Chg_No,"");
		SETCHAR(eBasicViewx.Page_No,"");

		SETCHAR(eBasicViewx.Prod_Memo,"");
		SETCHAR(eBasicViewx.Pageformat,"");
		SETCHAR(eBasicViewx.Size_Dim,"X");
		SETCHAR(eBasicViewx.Basic_Matl,"");
		SETCHAR(eBasicViewx.Std_Descr,"");
		SETCHAR(eBasicViewx.Dsn_Office,"");
		SETCHAR(eBasicViewx.Pur_Valkey,"");

		SETCHAR(eBasicViewx.Container,"");
		SETCHAR(eBasicViewx.Stor_Conds,"");
		SETCHAR(eBasicViewx.Temp_Conds,"");
		SETCHAR(eBasicViewx.Trans_Grp,"");
		SETCHAR(eBasicViewx.Haz_Mat_No,"");
		SETCHAR(eBasicViewx.Division,"X");
		SETCHAR(eBasicViewx.Competitor,"");
		SETCHAR(eBasicViewx.Qty_Gr_Gi,"");
		SETCHAR(eBasicViewx.Proc_Rule,"");
		SETCHAR(eBasicViewx.Sup_Source,"");
		SETCHAR(eBasicViewx.Season,"");
		SETCHAR(eBasicViewx.Label_Type,"");
		SETCHAR(eBasicViewx.Label_Form,"");
		SETCHAR(eBasicViewx.Prod_Hier,"");
		SETCHAR(eBasicViewx.Cad_Id,"");
		SETCHAR(eBasicViewx.Allowed_Wt,"");
		SETCHAR(eBasicViewx.Pack_Wt_Un,"");
		SETCHAR(eBasicViewx.Pack_Wt_Un_Iso,"");
		SETCHAR(eBasicViewx.Allwd_Vol,"");
		SETCHAR(eBasicViewx.Pack_Vo_Un,"");
		SETCHAR(eBasicViewx.Pack_Vo_Un_Iso,"");
		SETCHAR(eBasicViewx.Wt_Tol_Lt,"");
		SETCHAR(eBasicViewx.Vol_Tol_Lt,"");
		SETCHAR(eBasicViewx.Var_Ord_Un,"");
		SETCHAR(eBasicViewx.Batch_Mgmt,"");
		SETCHAR(eBasicViewx.Sh_Mat_Typ,"");
		SETCHAR(eBasicViewx.Fill_Level,"");
		SETCHAR(eBasicViewx.Stack_Fact,"");
		SETCHAR(eBasicViewx.Mat_Grp_Sm,"");
		SETCHAR(eBasicViewx.Authoritygroup,"");
		SETCHAR(eBasicViewx.Qm_Procmnt,"");
		SETCHAR(eBasicViewx.Catprofile,"");
		SETCHAR(eBasicViewx.Minremlife,"");
		SETCHAR(eBasicViewx.Shelf_Life,"");
		SETCHAR(eBasicViewx.Stor_Pct,"");
		SETCHAR(eBasicViewx.Pur_Status,"");
		SETCHAR(eBasicViewx.Sal_Status,"");
		SETCHAR(eBasicViewx.Pvalidfrom,"");
		SETCHAR(eBasicViewx.Svalidfrom,"");
		SETCHAR(eBasicViewx.Envt_Rlvt,"");
		SETCHAR(eBasicViewx.Prod_Alloc,"");
		SETCHAR(eBasicViewx.Qual_Dik,"");
		SETCHAR(eBasicViewx.Manu_Mat,"");
		SETCHAR(eBasicViewx.Mfr_No,"");
		SETCHAR(eBasicViewx.Inv_Mat_No,"");
		SETCHAR(eBasicViewx.Manuf_Prof,"");
		SETCHAR(eBasicViewx.Hazmatprof,"");
		SETCHAR(eBasicViewx.High_Visc,"");
		SETCHAR(eBasicViewx.Looseorliq,"");
		SETCHAR(eBasicViewx.Closed_Box,"");
		SETCHAR(eBasicViewx.Appd_B_Rec,"");
		SETCHAR(eBasicViewx.Matcmpllvl,"");
		SETCHAR(eBasicViewx.Par_Eff,"");
		SETCHAR(eBasicViewx.Round_Up_Rule_Expiration_Date,"");
		SETCHAR(eBasicViewx.Period_Ind_Expiration_Date,"");
		SETCHAR(eBasicViewx.Prod_Composition_On_Packaging,"");
		SETCHAR(eBasicViewx.Item_Cat,"");
		SETCHAR(eBasicViewx.Haz_Mat_No_External,"");
		SETCHAR(eBasicViewx.Haz_Mat_No_Guid,"");
		SETCHAR(eBasicViewx.Haz_Mat_No_Version,"");
		SETCHAR(eBasicViewx.Inv_Mat_No_External,"");
		SETCHAR(eBasicViewx.Inv_Mat_No_Guid,"");
		SETCHAR(eBasicViewx.Inv_Mat_No_Version,"");
		SETCHAR(eBasicViewx.Material_Fixed,"");
		SETCHAR(eBasicViewx.Cm_Relevance_Flag,"");
		SETCHAR(eBasicViewx.Sled_Bbd,"");
		SETCHAR(eBasicViewx.Gtin_Variant,"");
		SETCHAR(eBasicViewx.Serialization_Level,"");
		SETCHAR(eBasicViewx.Pl_Ref_Mat,"");
		SETCHAR(eBasicViewx.Extmatlgrp,"");
		SETCHAR(eBasicViewx.Uomusage,"");
		SETCHAR(eBasicViewx.Pl_Ref_Mat_External,"");
		SETCHAR(eBasicViewx.Pl_Ref_Mat_Guid,"");
		SETCHAR(eBasicViewx.Pl_Ref_Mat_Version,"");
			
		thBapi_Makt = ITAB_NULL;
		thBapi_Marm = ITAB_NULL;
		thBapi_Marmx = ITAB_NULL;
		thBapi_Mean = ITAB_NULL;

		thBAPIE1PAREX3 = ITAB_NULL;
		thBAPIE1PAREXX3 = ITAB_NULL;

		if (thBapi_Makt==ITAB_NULL)
		{
			thBapi_Makt = ItCreate("MATERIALDESCRIPTION",sizeof(BAPI_MAKT),0,0);
			if (thBapi_Makt==ITAB_NULL)
				printf("\nItCreate MATERIALDESCRIPTION");
		}
		else
		  {
			if (ItFree(thBapi_Makt) != 0)
				printf("\nItFree MATERIALDESCRIPTION");
		  }

		if (thBapi_Marm==ITAB_NULL)
		{
			 thBapi_Marm = ItCreate("UNITSOFMEASURE",sizeof(BAPI_MARM),0,0);
			 if (thBapi_Marm==ITAB_NULL)
				 printf("\nItCreate UNITSOFMEASURE");
		}
		else
		{
			if (ItFree(thBapi_Marm)!= 0)
				printf("\nItFree UNITSOFMEASURE");
		}

		if (thBapi_Marmx==ITAB_NULL)
		{
			 thBapi_Marmx = ItCreate("UNITSOFMEASUREX",sizeof(BAPI_MARMX),0,0);
			if (thBapi_Marmx==ITAB_NULL)
				printf("\nItCreate UNITSOFMEASUREX");
		}
		else
		{
			if (ItFree(thBapi_Marmx)!= 0)
				printf("\nItFree UNITSOFMEASUREX");
		}

		if (thBapi_Mean==ITAB_NULL)
		{
			 thBapi_Mean = ItCreate("INTERNATIONALARTNOS",sizeof(BAPI_MEAN),0,0);
			 if (thBapi_Mean==ITAB_NULL)
				 printf("\nItCreate INTERNATIONALARTNOS");
		}
		else
		{
			if (ItFree(thBapi_Mean)!= 0)
				printf("\nItFree INTERNATIONALARTNOS");
		}

		if (thBAPIE1PAREX3==ITAB_NULL)
		{
				thBAPIE1PAREX3 = ItCreate("EXTENSIONIN",sizeof(BAPIE1PAREX3),0,0);
				if (thBAPIE1PAREX3==ITAB_NULL)
					rfc_error("ItCreate EXTENSIONIN");
		}
		else
		{
				if (ItFree(thBAPIE1PAREX3)!= 0)
					rfc_error("ItFree EXTENSIONIN");
		}

		if (thBAPIE1PAREXX3==ITAB_NULL)
		{
			thBAPIE1PAREXX3 = ItCreate("EXTENSIONINX",sizeof(BAPIE1PAREXX3),0,0);
			if (thBAPIE1PAREXX3==ITAB_NULL)
				rfc_error("ItCreate EXTENSIONINX");
		}
		else
		{
			if (ItFree(thBAPIE1PAREXX3)!= 0)
				rfc_error("ItFree EXTENSIONINX");
		}

		printf("\nNO. OF LINES IN OBJ. ARE: %d",ItFill(thBapi_Makt));
		tBapi_Makt = ItAppLine(thBapi_Makt) ;
		tBapi_Marm  = ItAppLine(thBapi_Marm) ;
		tBapi_Marmx = ItAppLine(thBapi_Marmx) ;
		tBapi_Mean =  ItAppLine(thBapi_Mean) ;

		tBAPIE1PAREX3 = ItAppLine(thBAPIE1PAREX3) ;
		tBAPIE1PAREXX3 = ItAppLine(thBAPIE1PAREXX3) ;

		if (tBAPIE1PAREX3 == NULL) rfc_error("ItAppLine BAPIE1PAREX3");
		if (tBAPIE1PAREXX3 == NULL) rfc_error("ItAppLine BAPIE1PAREXX3");


		if (tBapi_Makt == NULL)
		printf("\nItAppLine BAPI_MAKT");

		SETCHAR(tBapi_Makt->Langu,"EN");
		SETCHAR(tBapi_Makt->Langu_Iso,"");
		SETCHAR(tBapi_Makt->Matl_Desc,descDup);
		SETCHAR(tBapi_Makt->Del_Flag,"");

		if (tBapi_Marm == NULL)
		printf("\nItAppLine BAPI_MARM second table");

		SETCHAR(tBapi_Marm->Alt_Unit,meas_unit);
		SETCHAR(tBapi_Marm->Alt_Unit_Iso,meas_unit);
		SETBCD(tBapi_Marm->Numerator,"1",0);
		SETBCD(tBapi_Marm->Denominatr,"1",0);
		SETCHAR(tBapi_Marm->Ean_Upc,"");
		SETCHAR(tBapi_Marm->Ean_Cat,"");
		SETCHAR(tBapi_Marm->Length,"");
		SETCHAR(tBapi_Marm->Width,"");
		SETCHAR(tBapi_Marm->Height,"");
		SETCHAR(tBapi_Marm->Unit_Dim,"");
		SETCHAR(tBapi_Marm->Unit_Dim_Iso,"");
		SETBCD(tBapi_Marm->Volume,volume,3);
		SETCHAR(tBapi_Marm->VolumeUnit,vol_unit);
		SETCHAR(tBapi_Marm->VolumeUnit_Iso,vol_unit);
		SETBCD(tBapi_Marm->Gross_Wt,gross_weightDup,3);
		SETCHAR(tBapi_Marm->Unit_Of_Wt,weight_unit);
		SETCHAR(tBapi_Marm->Unit_Of_Wt_Iso,weight_unit);
		SETCHAR(tBapi_Marm->Del_Flag,"");
		SETCHAR(tBapi_Marm->Sub_Uom,"");
		SETCHAR(tBapi_Marm->Sub_Uom_Iso,"");
		SETCHAR(tBapi_Marm->Gtin_Variant,"");

		if (tBapi_Marmx == NULL)
		printf("\nItAppLine BAPI_MARMX");

		SETCHAR(tBapi_Marmx->Alt_Unit,meas_unit);
		SETCHAR(tBapi_Marmx->Alt_Unit_Iso,meas_unit);
		SETCHAR(tBapi_Marmx->Numerator,"X");
		SETCHAR(tBapi_Marmx->Denominatr,"X");
		SETCHAR(tBapi_Marmx->Ean_Upc,"");
		SETCHAR(tBapi_Marmx->Ean_Cat,"");
		SETCHAR(tBapi_Marmx->Length,"");
		SETCHAR(tBapi_Marmx->Width,"");
		SETCHAR(tBapi_Marmx->Height,"");
		SETCHAR(tBapi_Marmx->Unit_Dim,"");
		SETCHAR(tBapi_Marmx->Unit_Dim_Iso,"");
		SETCHAR(tBapi_Marmx->Volume,"X");
		SETCHAR(tBapi_Marmx->VolumeUnit,"X");
		SETCHAR(tBapi_Marmx->VolumeUnit_Iso,"X");
		SETCHAR(tBapi_Marmx->Gross_Wt,"X");
		SETCHAR(tBapi_Marmx->Unit_Of_Wt,"X");
		SETCHAR(tBapi_Marmx->Unit_Of_Wt_Iso,"X");
		SETCHAR(tBapi_Marmx->Sub_Uom,"");
		SETCHAR(tBapi_Marmx->Sub_Uom_Iso,"");
		SETCHAR(tBapi_Marmx->Gtin_Variant,"");

		SETCHAR(tBAPIE1PAREX3->STRUCTURE,"BAPI_TE_MARA");
		SETCHAR(tBAPIE1PAREX3->VALUEPART1,part_noDupDes);
		SETCHAR(tBAPIE1PAREX3->VALUEPART2,"");
		SETCHAR(tBAPIE1PAREX3->VALUEPART3,"");
		SETCHAR(tBAPIE1PAREX3->VALUEPART4,"");

		SETCHAR(tBAPIE1PAREXX3->STRUCTURE,"BAPI_TE_MARAX");
		SETCHAR(tBAPIE1PAREXX3->VALUEPART1,part_noDupDesx);
		SETCHAR(tBAPIE1PAREXX3->VALUEPART2,"");
		SETCHAR(tBAPIE1PAREXX3->VALUEPART3,"");
		SETCHAR(tBAPIE1PAREXX3->VALUEPART4,"");

		RfcRc = ZBAPI_MATERIAL_SAVEDATA(hRfc,&eBapiMatHead,&eBasicView,&eBasicViewx,&eRmmg1_Aennr,&eBapiret2,thBapi_Makt,thBapi_Marm,thBapi_Marmx,thBAPIE1PAREX3,thBAPIE1PAREXX3,xException);
		switch (RfcRc)
		{
			case RFC_OK :
				printf("\nMessage for Basic Material [%s] Create:%s",part_noDup,eBapiret2.Message);
				printf("\n******************************************************");
				fprintf(fsuccess,"\nMessage for Basic Material [%s] Create:%s",part_noDup,eBapiret2.Message);
				fprintf(fsuccess, "\n******************************************************");
			break;
			case RFC_EXCEPTION :
				printf("\nRFC EXCEPTION:%s",xException);
				fprintf(fsuccess,"\nRFC EXCEPTION:%s",xException);
			break;
			case RFC_SYS_EXCEPTION :
				printf("\nsystem exception raised");
				fprintf(fsuccess,"\nsystem exception raised");
			break;
			case RFC_FAILURE :
				printf("\nfailure");
			break;
			default :
				printf("\nother failure");
			break;
		}

		if(ItDelete(thBapi_Makt) != 0)
			printf("ItDelete thBapi_Makt");
		if(ItDelete(thBapi_Marm) != 0)
			printf("ItDelete tBapi_Marm");
		if(ItDelete(thBapi_Marmx) != 0)
			printf("ItDelete thBapi_Marmx");
		if(ItDelete(thBAPIE1PAREX3) != 0)
			rfc_error("ItDelete thBAPIE1PAREX3");
		if(ItDelete(thBAPIE1PAREXX3) != 0)
			rfc_error("ItDelete thBAPIE1PAREXX3");
	}
	RfcClose(RfcRc);
}

RFC_RC ZBAPI_MATERIAL_SAVEDATA(RFC_HANDLE hRfc,
						BAPIMATHEAD *eBapiMatHead,
						BAPI_MARA	*eBasicView,
						BAPI_MARAX	*eBasicViewx,
						RMMG1_AENNR *eRmmg1_Aennr,
						BAPIRET2	*eBapiret2,
						ITAB_H       thBapi_Makt,
						ITAB_H       thBapi_Marm,
						ITAB_H       thBapi_Marmx,
						ITAB_H       thBAPIE1PAREX3,
						ITAB_H       thBAPIE1PAREXX3,
						char *xException)
{
	RFC_PARAMETER Exporting[5];
	RFC_PARAMETER Importing[2];
	RFC_TABLE Tables[6];
	RFC_RC RfcRc;
	char *RfcException = NULL;

	Exporting[0].name = "HEADDATA";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfBAPIMATHEAD;
	Exporting[0].leng = sizeof(BAPIMATHEAD);
	Exporting[0].addr = eBapiMatHead;

	Exporting[1].name = "CLIENTDATA";
	Exporting[1].nlen = 10;
	Exporting[1].type = handleOfBAPI_MARA;
	Exporting[1].leng = sizeof(BAPI_MARA);
	Exporting[1].addr = eBasicView;

	Exporting[2].name = "CLIENTDATAX";
	Exporting[2].nlen = 11;
	Exporting[2].type = handleOfBAPI_MARAX;
	Exporting[2].leng = sizeof(BAPI_MARAX);
	Exporting[2].addr = eBasicViewx;

	Exporting[3].name = "CHANGE_NUMBER";
	Exporting[3].nlen = 13;
	Exporting[3].type = handleOfRMMG1_AENNR;
	Exporting[3].leng = sizeof(RMMG1_AENNR);
	Exporting[3].addr = eRmmg1_Aennr;

	Exporting[4].name = NULL;

	Tables[0].name     = "MATERIALDESCRIPTION";
	Tables[0].nlen     = 19;
	Tables[0].type     = handleOfBAPI_MAKT;
	Tables[0].ithandle = thBapi_Makt;

	Tables[1].name     = "UNITSOFMEASURE";
	Tables[1].nlen     = 14;
	Tables[1].type     = handleOfBAPI_MARM;
	Tables[1].ithandle = thBapi_Marm;

	Tables[2].name     = "UNITSOFMEASUREX";
	Tables[2].nlen     = 15;
	Tables[2].type     = handleOfBAPI_MARMX;
	Tables[2].ithandle = thBapi_Marmx;

	Tables[3].name     = "EXTENSIONIN";
	Tables[3].nlen     = 11;
	Tables[3].type     = handleOfBAPIE1PAREX3;
	Tables[3].ithandle = thBAPIE1PAREX3;

	Tables[4].name     = "EXTENSIONINX";
	Tables[4].nlen     = 12;
	Tables[4].type     = handleOfBAPIE1PAREXX3;
	Tables[4].ithandle = thBAPIE1PAREXX3;

	Tables[5].name = NULL;

	RfcRc = RfcCall(hRfc,"ZBAPI_MATERIAL_SAVEDATA",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK :
			Importing[0].name = "RETURN";
			Importing[0].nlen = 6;
			Importing[0].type = TYPC;
			Importing[0].leng = sizeof(BAPIRET2);
			Importing[0].addr = eBapiret2;

			Importing[1].name = NULL;
			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION :
					strcpy(xException,RfcException);
				break;
				case RFC_EXCEPTION :
					strcpy(xException,RfcException);
				break;
				default:;
			}
		break;
		default :
			printf("\nNOT RFC OK");
	}

	return RfcRc;
}

void UPD_BAPI_MATERIAL_SAVEDATA(void)
{
	static RFC_RC RfcRc;
	static RFC_HANDLE hRfc;
	char xException[256];

	BAPIMATHEAD eBapiMatHead;
	BAPI_MARA	eBasicView;
	BAPI_MARAX	eBasicViewx;
	BAPIRET2	eBapiret2;

	printf("\nInside Design Drawing Version update");
	fprintf(fsuccess,"\nInside Design Drawing Version update");

	hRfc = BapiLogon();
	SETCHAR(eBapiMatHead.Material,part_noDup);
	SETCHAR(eBapiMatHead.Ind_Sector,"M");
	SETCHAR(eBapiMatHead.Matl_Type,mat_type);
	SETCHAR(eBapiMatHead.Basic_View,"X");
	SETCHAR(eBapiMatHead.Sales_View,"");
	SETCHAR(eBapiMatHead.Purchase_View,"");
	SETCHAR(eBapiMatHead.Mrp_View,"");
	SETCHAR(eBapiMatHead.Forecast_View,"");
	SETCHAR(eBapiMatHead.Work_Sched_View,"");
	SETCHAR(eBapiMatHead.Prt_View,"");
	SETCHAR(eBapiMatHead.Storage_View,"");
	SETCHAR(eBapiMatHead.Warehouse_View,"");
	SETCHAR(eBapiMatHead.Quality_View,"");
	SETCHAR(eBapiMatHead.Account_View,"");
	SETCHAR(eBapiMatHead.Cost_View,"");
	SETCHAR(eBapiMatHead.Inp_Fld_Check,"");
	SETCHAR(eBapiMatHead.Material_External,"");
	SETCHAR(eBapiMatHead.MateriaL_Guid,"");
	SETCHAR(eBapiMatHead.Material_Version,"");

	SETCHAR(eBasicView.Del_Flag,"");
	SETCHAR(eBasicView.Matl_Group,"");
	SETCHAR(eBasicView.Base_Uom,"");
	SETCHAR(eBasicView.Base_Uom_Iso,"");
	SETCHAR(eBasicView.Po_Unit,"");
	SETCHAR(eBasicView.Po_Unit_Iso,"");
	SETCHAR(eBasicView.Doc_Format,"");
	SETCHAR(eBasicView.Doc_Chg_No,"");
	SETCHAR(eBasicView.Page_No,"");
	SETNUM(eBasicView.No_Sheets,"");
	SETCHAR(eBasicView.Prod_Memo,"");
	SETCHAR(eBasicView.Pageformat,"");
	SETCHAR(eBasicView.Size_Dim,"");
	SETCHAR(eBasicView.Basic_Matl,"");
	SETCHAR(eBasicView.Std_Descr,"");
	SETCHAR(eBasicView.Dsn_Office,"");
	SETCHAR(eBasicView.Pur_Valkey,"");
	SETBCD(eBasicView.Net_Weight,myzeroDup3,3);

	if(OldMatNoDup == NULL)
	{
		SETCHAR(eBasicView.Old_Mat_No,"");
		SETCHAR(eBasicViewx.Old_Mat_No,"");
	}
	else
	{
		SETCHAR(eBasicView.Old_Mat_No,OldMatNoDup);
		SETCHAR(eBasicViewx.Old_Mat_No,"X");
	}
	//Design Drawing Details Update on Basic View 2 Start
	if(doc_noDup == NULL)
	{
		SETCHAR(eBasicView.Document,"");
		SETCHAR(eBasicViewx.Document,"");
	}
	else
	{
		SETCHAR(eBasicView.Document,doc_noDup);
		SETCHAR(eBasicViewx.Document,"X");
	}

	if(dwg_typeDup == NULL)
	{
		SETCHAR(eBasicView.Doc_Type,"");
		SETCHAR(eBasicViewx.Doc_Type,"");
	}
	else
	{
		SETCHAR(eBasicView.Doc_Type,dwg_typeDup);
		SETCHAR(eBasicViewx.Doc_Type,"X");
	}

	if(dwg_revDup == NULL)
	{
		SETCHAR(eBasicView.Doc_Vers,"");
		SETCHAR(eBasicViewx.Doc_Vers,"");
	}
	else
	{
		SETCHAR(eBasicView.Doc_Vers,dwg_revDup);
		SETCHAR(eBasicViewx.Doc_Vers,"X");
	}
	
	//Design Drawing Details Update on Basic View 2 End

	if(weight_unit == NULL)
	{
		SETCHAR(eBasicView.Unit_Of_Wt,"");
		SETCHAR(eBasicViewx.Unit_Of_Wt,"");
	}
	else
	{
		SETCHAR(eBasicView.Unit_Of_Wt,weight_unit);
		SETCHAR(eBasicViewx.Unit_Of_Wt,"X");
	}

	if(weight_unit == NULL)
	{
		SETCHAR(eBasicView.Unit_Of_Wt_Iso,"");
		SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"");
	}
	else
	{
		SETCHAR(eBasicView.Unit_Of_Wt_Iso,weight_unit);
		SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"X");
	}
	SETCHAR(eBasicView.Container,"");
	SETCHAR(eBasicView.Stor_Conds,"");
	SETCHAR(eBasicView.Temp_Conds,"");
	SETCHAR(eBasicView.Trans_Grp,"");
	SETCHAR(eBasicView.Haz_Mat_No,"");
	SETCHAR(eBasicView.Division,"");
	SETCHAR(eBasicView.Competitor,"");
	SETBCD(eBasicView.Qty_Gr_Gi,myzeroDup3,3);
	SETCHAR(eBasicView.Proc_Rule,"");
	SETCHAR(eBasicView.Sup_Source,"");
	SETCHAR(eBasicView.Season,"");
	SETCHAR(eBasicView.Label_Type,"");
	SETCHAR(eBasicView.Label_Form,"");
	SETCHAR(eBasicView.Prod_Hier,"");
	SETCHAR(eBasicView.Cad_Id,"");
	SETBCD(eBasicView.Allowed_Wt,myzeroDup3,3);
	SETCHAR(eBasicView.Pack_Wt_Un,"");
	SETCHAR(eBasicView.Pack_Wt_Un_Iso,"");
	SETBCD(eBasicView.Allwd_Vol,myzeroDup3,3);
	SETCHAR(eBasicView.Pack_Vo_Un,"");
	SETCHAR(eBasicView.Pack_Vo_Un_Iso,"");
	SETBCD(eBasicView.Wt_Tol_Lt,myzeroDup1,1);
	SETBCD(eBasicView.Vol_Tol_Lt,myzeroDup1,1);
	SETCHAR(eBasicView.Var_Ord_Un,"");
	SETCHAR(eBasicView.Batch_Mgmt,"");
	SETCHAR(eBasicView.Sh_Mat_Typ,"");
	SETBCD(eBasicView.Fill_Level,"0",0);
	SETINT2(&eBasicView.Stack_Fact,"0");
	SETCHAR(eBasicView.Mat_Grp_Sm,"");
	SETCHAR(eBasicView.Authoritygroup,"");
	SETCHAR(eBasicView.Qm_Procmnt,"");
	SETCHAR(eBasicView.Catprofile,"");
	SETBCD(eBasicView.Minremlife,"0",0);
	SETBCD(eBasicView.Shelf_Life,"0",0);
	SETBCD(eBasicView.Stor_Pct,"0",0);
	SETCHAR(eBasicView.Pur_Status,"");
	SETCHAR(eBasicView.Sal_Status,"");
	SETDATE(eBasicView.Pvalidfrom,"");
	SETDATE(eBasicView.Svalidfrom,"");
	SETCHAR(eBasicView.Envt_Rlvt,"");
	SETCHAR(eBasicView.Prod_Alloc,"");
	SETCHAR(eBasicView.Qual_Dik,"");
	SETCHAR(eBasicView.Manu_Mat,"");
	SETCHAR(eBasicView.Mfr_No,"");
	SETCHAR(eBasicView.Inv_Mat_No,"");
	SETCHAR(eBasicView.Manuf_Prof,"");
	SETCHAR(eBasicView.Hazmatprof,"");
	SETCHAR(eBasicView.High_Visc,"");
	SETCHAR(eBasicView.Looseorliq,"");
	SETCHAR(eBasicView.Closed_Box,"");
	SETCHAR(eBasicView.Appd_B_Rec,"");
	SETNUM(eBasicView.Matcmpllvl,"00");
	SETCHAR(eBasicView.Par_Eff,"");
	SETCHAR(eBasicView.Round_Up_Rule_Expiration_Date,"");
	SETCHAR(eBasicView.Period_Ind_Expiration_Date,"D");
	SETCHAR(eBasicView.Prod_Composition_On_Packaging,"");
	SETCHAR(eBasicView.Item_Cat,"");
	SETCHAR(eBasicView.Haz_Mat_No_External,"");
	SETCHAR(eBasicView.Haz_Mat_No_Guid,"");
	SETCHAR(eBasicView.Haz_Mat_No_Version,"");
	SETCHAR(eBasicView.Inv_Mat_No_External,"");
	SETCHAR(eBasicView.Inv_Mat_No_Guid,"");
	SETCHAR(eBasicView.Inv_Mat_No_Version,"");
	SETCHAR(eBasicView.Material_Fixed,"");
	SETCHAR(eBasicView.Cm_Relevance_Flag,"");
	SETCHAR(eBasicView.Sled_Bbd,"");
	SETCHAR(eBasicView.Gtin_Variant,"");
	SETCHAR(eBasicView.Serialization_Level,"");
	SETCHAR(eBasicView.Pl_Ref_Mat,"");
	SETCHAR(eBasicView.Extmatlgrp,"");
	SETCHAR(eBasicView.Uomusage,"");
	SETCHAR(eBasicView.Pl_Ref_Mat_External,"");
	SETCHAR(eBasicView.Pl_Ref_Mat_Guid,"");
	SETCHAR(eBasicView.Pl_Ref_Mat_Version,"");

	SETCHAR(eBasicViewx.Del_Flag,"");
	SETCHAR(eBasicViewx.Matl_Group,"");
	SETCHAR(eBasicViewx.Base_Uom,"");
	SETCHAR(eBasicViewx.Base_Uom_Iso,"");
	SETCHAR(eBasicViewx.Po_Unit,"");
	SETCHAR(eBasicViewx.Po_Unit_Iso,"");
	SETCHAR(eBasicViewx.Doc_Format,"");
	SETCHAR(eBasicViewx.Doc_Chg_No,"");
	SETCHAR(eBasicViewx.Page_No,"");
	SETCHAR(eBasicViewx.No_Sheets,"");
	SETCHAR(eBasicViewx.Prod_Memo,"");
	SETCHAR(eBasicViewx.Pageformat,"");
	SETCHAR(eBasicViewx.Size_Dim,"");
	SETCHAR(eBasicViewx.Basic_Matl,"");
	SETCHAR(eBasicViewx.Std_Descr,"");
	SETCHAR(eBasicViewx.Dsn_Office,"");
	SETCHAR(eBasicViewx.Pur_Valkey,"");
	SETCHAR(eBasicViewx.Net_Weight,"");
	SETCHAR(eBasicViewx.Unit_Of_Wt,"");
	SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"");
	SETCHAR(eBasicViewx.Container,"");
	SETCHAR(eBasicViewx.Stor_Conds,"");
	SETCHAR(eBasicViewx.Temp_Conds,"");
	SETCHAR(eBasicViewx.Trans_Grp,"");
	SETCHAR(eBasicViewx.Haz_Mat_No,"");
	SETCHAR(eBasicViewx.Division,"");
	SETCHAR(eBasicViewx.Competitor,"");
	SETCHAR(eBasicViewx.Qty_Gr_Gi,"");
	SETCHAR(eBasicViewx.Proc_Rule,"");
	SETCHAR(eBasicViewx.Sup_Source,"");
	SETCHAR(eBasicViewx.Season,"");
	SETCHAR(eBasicViewx.Label_Type,"");
	SETCHAR(eBasicViewx.Label_Form,"");
	SETCHAR(eBasicViewx.Prod_Hier,"");
	SETCHAR(eBasicViewx.Cad_Id,"");
	SETCHAR(eBasicViewx.Allowed_Wt,"");
	SETCHAR(eBasicViewx.Pack_Wt_Un,"");
	SETCHAR(eBasicViewx.Pack_Wt_Un_Iso,"");
	SETCHAR(eBasicViewx.Allwd_Vol,"");
	SETCHAR(eBasicViewx.Pack_Vo_Un,"");
	SETCHAR(eBasicViewx.Pack_Vo_Un_Iso,"");
	SETCHAR(eBasicViewx.Wt_Tol_Lt,"");
	SETCHAR(eBasicViewx.Vol_Tol_Lt,"");
	SETCHAR(eBasicViewx.Var_Ord_Un,"");
	SETCHAR(eBasicViewx.Batch_Mgmt,"");
	SETCHAR(eBasicViewx.Sh_Mat_Typ,"");
	SETCHAR(eBasicViewx.Fill_Level,"");
	SETCHAR(eBasicViewx.Stack_Fact,"");
	SETCHAR(eBasicViewx.Mat_Grp_Sm,"");
	SETCHAR(eBasicViewx.Authoritygroup,"");
	SETCHAR(eBasicViewx.Qm_Procmnt,"");
	SETCHAR(eBasicViewx.Catprofile,"");
	SETCHAR(eBasicViewx.Minremlife,"");
	SETCHAR(eBasicViewx.Shelf_Life,"");
	SETCHAR(eBasicViewx.Stor_Pct,"");
	SETCHAR(eBasicViewx.Pur_Status,"");
	SETCHAR(eBasicViewx.Sal_Status,"");
	SETCHAR(eBasicViewx.Pvalidfrom,"");
	SETCHAR(eBasicViewx.Svalidfrom,"");
	SETCHAR(eBasicViewx.Envt_Rlvt,"");
	SETCHAR(eBasicViewx.Prod_Alloc,"");
	SETCHAR(eBasicViewx.Qual_Dik,"");
	SETCHAR(eBasicViewx.Manu_Mat,"");
	SETCHAR(eBasicViewx.Mfr_No,"");
	SETCHAR(eBasicViewx.Inv_Mat_No,"");
	SETCHAR(eBasicViewx.Manuf_Prof,"");
	SETCHAR(eBasicViewx.Hazmatprof,"");
	SETCHAR(eBasicViewx.High_Visc,"");
	SETCHAR(eBasicViewx.Looseorliq,"");
	SETCHAR(eBasicViewx.Closed_Box,"");
	SETCHAR(eBasicViewx.Appd_B_Rec,"");
	SETCHAR(eBasicViewx.Matcmpllvl,"");
	SETCHAR(eBasicViewx.Par_Eff,"");
	SETCHAR(eBasicViewx.Round_Up_Rule_Expiration_Date,"");
	SETCHAR(eBasicViewx.Period_Ind_Expiration_Date,"");
	SETCHAR(eBasicViewx.Prod_Composition_On_Packaging,"");
	SETCHAR(eBasicViewx.Item_Cat,"");
	SETCHAR(eBasicViewx.Haz_Mat_No_External,"");
	SETCHAR(eBasicViewx.Haz_Mat_No_Guid,"");
	SETCHAR(eBasicViewx.Haz_Mat_No_Version,"");
	SETCHAR(eBasicViewx.Inv_Mat_No_External,"");
	SETCHAR(eBasicViewx.Inv_Mat_No_Guid,"");
	SETCHAR(eBasicViewx.Inv_Mat_No_Version,"");
	SETCHAR(eBasicViewx.Material_Fixed,"");
	SETCHAR(eBasicViewx.Cm_Relevance_Flag,"");
	SETCHAR(eBasicViewx.Sled_Bbd,"");
	SETCHAR(eBasicViewx.Gtin_Variant,"");
	SETCHAR(eBasicViewx.Serialization_Level,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat,"");
	SETCHAR(eBasicViewx.Extmatlgrp,"");
	SETCHAR(eBasicViewx.Uomusage,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat_External,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat_Guid,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat_Version,"");

	printf("\nhi");

	RfcRc = BAPI_MATERIAL_UPDATEDATA(hRfc
			,&eBapiMatHead
			,&eBasicView
			,&eBasicViewx
			,&eBapiret2
			
			,xException);

	switch (RfcRc)
	{
		case RFC_OK :
					printf("\nMessage for Basic Material Create:-%s",eBapiret2.Message);
					fflush(stdout);
					break;
		case RFC_EXCEPTION :
					printf("\nRFC EXCEPTION:-%s",xException);
					break;
		case RFC_SYS_EXCEPTION :
					printf("\nsystem exception raised");
					break;
		case RFC_FAILURE :
					printf("\nfailure");
					break;
		default :
					printf("\nother failure");
					break;
	}
	RfcClose(hRfc);
}

RFC_RC BAPI_MATERIAL_UPDATEDATA(RFC_HANDLE hRfc,
						BAPIMATHEAD *eBapiMatHead,
						BAPI_MARA	*eBasicView,
						BAPI_MARAX	*eBasicViewx,
						BAPIRET2	*eBapiret2,
						char *xException)
{
	RFC_PARAMETER Exporting[4];
	RFC_PARAMETER Importing[2];
	RFC_TABLE Tables[1];
	RFC_RC RfcRc;
	char *RfcException = NULL;

	printf("bi");
	Exporting[0].name = "HEADDATA";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfBAPIMATHEAD;
	Exporting[0].leng = sizeof(BAPIMATHEAD);
	Exporting[0].addr = eBapiMatHead;

	Exporting[1].name = "CLIENTDATA";
	Exporting[1].nlen = 10;
	Exporting[1].type = handleOfBAPI_MARA;
	Exporting[1].leng = sizeof(BAPI_MARA);
	Exporting[1].addr = eBasicView;

	Exporting[2].name = "CLIENTDATAX";
	Exporting[2].nlen = 11;
	Exporting[2].type = handleOfBAPI_MARAX;
	Exporting[2].leng = sizeof(BAPI_MARAX);
	Exporting[2].addr = eBasicViewx;

	Exporting[3].name = NULL;

	Tables[0].name = NULL;

	

	RfcRc = RfcCall(hRfc,"ZBAPI_MATERIAL_SAVEDATA",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK :
			 Importing[0].name = "RETURN";  
			 Importing[0].nlen = 6;
			 Importing[0].type = TYPC;
			 Importing[0].leng = sizeof(BAPIRET2);
			 Importing[0].addr = eBapiret2;

			 Importing[1].name = NULL;
			 RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			printf("\nRfcException:%s",RfcException);
			 switch (RfcRc)
			 {
				 case RFC_SYS_EXCEPTION :
					strcpy(xException,RfcException);
					break;
				 case RFC_EXCEPTION :
					strcpy(xException,RfcException);
					break;
				default: ;
			 }
			break;
			default :
				printf("\nNOT RFC OK");
	}

	return RfcRc;
}

int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3])
{
	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;
	AENNR eAennr;
	CCMATNR eMatnr;
	CC_REVLV eRevlv;
	BAPIRET2 iMessg;
	SYST_SUBRC iRetval;
	char xException[256];
	char s[1024] = { 0 } ;

	hRfc = BapiLogon();

	printf("\nRevision Creation DmlNo.:[%s]\t PartNo.:[%s]\tRevSheetstatus:[%s]",sap_dml_no,sap_part_no,sap_rev_sheet_status);
	fprintf(fsuccess,"\nRevision Creation DmlNo.:[%s]\t PartNo.:[%s]\tRevSheetstatus:[%s]",sap_dml_no,sap_part_no,sap_rev_sheet_status);

	SETCHAR(eAennr.Aennr,sap_dml_no);
	SETCHAR(eMatnr.Ccmatnr,sap_part_no);
	SETCHAR(eRevlv.CcRevlv,sap_rev_sheet_status);

	RfcRc = zpprfc_revisionnum_change(hRfc,&eAennr,&eMatnr,&eRevlv,&iMessg,&iRetval,xException);

	switch (RfcRc)
	{
		case RFC_OK:
			printf("\n[%s]Revision Creation Message	:%s",sap_part_no,iMessg.Message);
			fprintf(fsuccess,"\n[%s]Revision Creation Message	:%s",sap_part_no,iMessg.Message);fflush(stdout);
			
			NL;
		break;
		case RFC_EXCEPTION:
			printf("\nRFC_EXCEPTION raised");
			fprintf(fsuccess,"\nRFC_EXCEPTION raised");
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nsystem exception raised");
			fprintf(fsuccess,"\nsystem exception raised");
		break;
		case RFC_FAILURE:
			printf("\nfailure");
		break;
		default:
			printf("\nother failure");
	}
	RfcClose(hRfc);

	return 0;
}

RFC_RC zbapi_material_savedata_mrp(RFC_HANDLE hRfc,BAPIMATHEAD *eBapiMatHead,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2 *eBapiret2,ITAB_H thBapi_Makt,char *xException)
{
	RFC_PARAMETER Exporting[3];
	RFC_PARAMETER Importing[2];
	RFC_TABLE Tables[2];
	RFC_RC RfcRc;
	char *RfcException = NULL;

	Exporting[0].name = "HEADDATA";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfBAPIMATHEAD;
	Exporting[0].leng = sizeof(BAPIMATHEAD);
	Exporting[0].addr = eBapiMatHead;

	Exporting[1].name = "CHANGE_NUMBER";
	Exporting[1].nlen = 13;
	Exporting[1].type = handleOfRMMG1_AENNR;
	Exporting[1].leng = sizeof(RMMG1_AENNR);
	Exporting[1].addr = eRmmg1_Aennr;

	Exporting[2].name = NULL;

	Tables[0].name     = "MATERIALDESCRIPTION";
	Tables[0].nlen     = 19;
	Tables[0].type     = handleOfBAPI_MAKT;
	Tables[0].ithandle = thBapi_Makt;


	Tables[1].name = NULL;

	RfcRc = RfcCall(hRfc,"ZBAPI_MATERIAL_SAVEDATA",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK:
			Importing[0].name = "RETURN";
			Importing[0].nlen = 6;
			Importing[0].type = TYPC;
			Importing[0].leng = sizeof(BAPIRET2);
			Importing[0].addr = eBapiret2;

			Importing[1].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				default: ;
			}
			break;
		default:
			printf("\nNOT RFC OK");
			break;
	}
	return RfcRc;
}

void descChange(char *Part_Num,char *DescStr,char *dml_no_arg)
{
	static RFC_RC RfcRc;
	static RFC_HANDLE hRfc;
	char xException[256];
	char sap_msg[60];
	BAPIMATHEAD eBapiMatHead;
	RMMG1_AENNR eRmmg1_Aennr;
	BAPIRET2 eBapiret2;
	
	ITAB_H thBapi_Makt = ITAB_NULL;
	BAPI_MAKT *tBapi_Makt;

	printf("\nPart Number : [%s] Description : [%s] ChangeNo : [%s]",Part_Num,DescStr,dml_no_arg);
	fprintf(fsuccess,"\nPart Number : [%s] Description : [%s] ChangeNo : [%s]",Part_Num,DescStr,dml_no_arg);
	hRfc = BapiLogon();
	SETCHAR(eBapiMatHead.Material,Part_Num);
	SETCHAR(eBapiMatHead.Ind_Sector,"");
	SETCHAR(eBapiMatHead.Matl_Type,"");
	SETCHAR(eBapiMatHead.Basic_View,"");
	SETCHAR(eBapiMatHead.Sales_View,"");
	SETCHAR(eBapiMatHead.Purchase_View,"");
	SETCHAR(eBapiMatHead.Mrp_View,"");
	SETCHAR(eBapiMatHead.Forecast_View,"");
	SETCHAR(eBapiMatHead.Work_Sched_View,"");
	SETCHAR(eBapiMatHead.Prt_View,"");
	SETCHAR(eBapiMatHead.Storage_View,"");
	SETCHAR(eBapiMatHead.Warehouse_View,"");
	SETCHAR(eBapiMatHead.Quality_View,"");
	SETCHAR(eBapiMatHead.Account_View,"");
	SETCHAR(eBapiMatHead.Cost_View,"");
	SETCHAR(eBapiMatHead.Inp_Fld_Check,"");
	SETCHAR(eBapiMatHead.Material_External,"");
	SETCHAR(eBapiMatHead.MateriaL_Guid,"");
	SETCHAR(eBapiMatHead.Material_Version,"");

	SETCHAR(eRmmg1_Aennr.Aennr,dml_no_arg);

	thBapi_Makt = ITAB_NULL;
	if (thBapi_Makt==ITAB_NULL)
	{
		thBapi_Makt = ItCreate("MATERIALDESCRIPTION",sizeof(BAPI_MAKT),0,0);
		if (thBapi_Makt==ITAB_NULL)
		rfc_error("ItCreate MATERIALDESCRIPTION");
	}
	else if (ItFree(thBapi_Makt) != 0)
	{
		rfc_error("ItFree MATERIALDESCRIPTION");
	}

	tBapi_Makt = ItAppLine (thBapi_Makt) ;
	if (tBapi_Makt == NULL)
	{
		rfc_error("ItAppLine BAPI_MAKT");
	}

	SETCHAR(tBapi_Makt->Langu,"EN");
	SETCHAR(tBapi_Makt->Langu_Iso,"");
	SETCHAR(tBapi_Makt->Matl_Desc,DescStr);
	SETCHAR(tBapi_Makt->Del_Flag,"");

	RfcRc = zbapi_material_savedata_mrp(hRfc,&eBapiMatHead,&eRmmg1_Aennr,&eBapiret2,thBapi_Makt,xException);

	switch (RfcRc)
	{
		case RFC_OK:
			sprintf(sap_msg,"%.*s:",sizeof(sap_msg),eBapiret2.Message);
			printf("\n\nDesc Change Message: %s\n",sap_msg);
			fprintf(fsuccess,"\nDesc Change Message:%s",sap_msg);
			break;
		case RFC_EXCEPTION:
			printf("\nRFC EXCEPTION: %s",xException);
			break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");
			break;
		case RFC_FAILURE:
			printf("\nFailure!!!");
			break;
		default:
			printf("\nOther Failure!");
		break;
	}
	if (ItDelete(thBapi_Makt) != 0)
	{
		rfc_error("ItDelete thBapi_Makt");
	}

	RfcClose(hRfc);
}*/

int getChassisType(tag_t PartTag,char *part_type,char *part_ColorId)
{
	int status;
	int Count = 0;
	tag_t	VehicleRevTag		= NULLTAG;
	tag_t	VehicleMstTag		= NULLTAG;
	tag_t	PartTagDup			= NULLTAG;
	tag_t	*NonColPartTags		= NULLTAG;
	tag_t	*VCChildTags		= NULLTAG;
	
	char *partType = NULL;

	tc_strdup(part_type,&partType);
	PartTagDup = PartTag;

	if (tc_strcmp(part_ColorId,"C")==0)
	{
		ITK_CALL(AOM_ask_value_tags(PartTag,"TC_Is_Represented_By",&Count,&NonColPartTags));
		if (Count>0)
		{
			PartTagDup = NonColPartTags[0];
			ITK_CALL(AOM_ask_value_string(PartTagDup,"t5_PartType",&partType));
		}
		else
		{
			printf("\nColour VC to Non Colour VC relation not found");
			fprintf(fsuccess,"\nColour VC to Non Colour VC relation not found");
		}
	}

	if (tc_strcmp(partType,"VC")==0 || tc_strcmp(partType,"VCCR")==0)
	{
		ITK_CALL(AOM_ask_value_tags(PartTagDup,"ps_children",&Count,&VCChildTags));
		if (Count>0)
		{
			VehicleRevTag = VCChildTags[0];
			ITK_CALL(AOM_ask_value_tag(VehicleRevTag,"items_tag",&VehicleMstTag));
			ITK_CALL(AOM_UIF_ask_value(VehicleMstTag,"T5_HasChassisTypeNo",&OldMatNo));
			tc_strdup(OldMatNo,&OldMatNoDup);
		}
		else
		{
			printf("\nVC Vehicle relation not found");
			fprintf(fsuccess,"\nVC Vehicle relation not found");
		}
	}

	if (tc_strcmp(partType,"V")==0 || tc_strcmp(partType,"CCVC")==0)
	{
		ITK_CALL(AOM_ask_value_tag(PartTagDup,"items_tag",&VehicleMstTag));
		ITK_CALL(AOM_UIF_ask_value(VehicleMstTag,"T5_HasChassisTypeNo",&OldMatNo));
		tc_strdup(OldMatNo,&OldMatNoDup);
	}

	printf("\nOLD MATERIAL NUMBER FOR VC : [%s]",OldMatNoDup);
	fprintf(fsuccess,"\nOLD MATERIAL NUMBER FOR VC : [%s]",OldMatNoDup);
}

extern int ITK_user_main (int argc, char ** argv )
{
    int status;
	int kk=0;
	int is=0;
	int sflag=0;
	int RefDocflag=0;
	int ii=2;
	int doccount=0;
	int docRefcount=0;
	int *ip=&ii;
	int len=0;
	int Refcount=0;
	int DocPartCnt=0;
	int RefRelPartCnt=0;
	int resultCount =0;
	int n_entries = 1; //no. of query input arg
	int n_tags_found = 0;
	int tskcnt =0,t=0,p=0,ref=0;

	tag_t queryTag = NULLTAG;
	tag_t ErcDmlTag = NULLTAG;
	tag_t *SetOfDmlTasksTag= NULLTAG;
	tag_t PartTag= NULLTAG;
	tag_t PartMasterTag = NULLTAG;

	tag_t docOPtr = NULLTAG;
	tag_t docRefOPtr = NULLTAG;
	tag_t *outTag = NULLTAG;
	tag_t resultOutputTag = NULLTAG;
    tag_t docRelObjs=NULLTAG;
    tag_t *docObjs=NULLTAG;
    tag_t *docRefObjs=NULLTAG;
	//tag_t *refdocObjs=NULLTAG;
	tag_t *refdocObjs=NULLTAG;
	//GRM_relation_t *refdocObjs=NULLTAG;
    tag_t doctag=NULLTAG;
    tag_t docReftag=NULLTAG;
    tag_t specDocRelObj=NULLTAG;
    tag_t specDocRelRefObj=NULLTAG;
    tag_t refdocRelObj=NULLTAG;
    tag_t objTypeTag=NULLTAG;
    tag_t specParttag=NULLTAG;
    tag_t RefPartTag=NULLTAG;
	//tag_t *DocPartObj = NULLTAG;
	tag_t	*DesignTags	= NULLTAG;

	GRM_relation_t *DocPartObj=NULLTAG;
	GRM_relation_t *RefRelPartObj=NULLTAG;

	date_t DmlRelDate;
	char* sUserName	= NULL;
	char* sPassword = NULL;

	char *DmlRelDateStr=NULL;

	char *DmlId=NULL;
	char *DmlDesc=NULL;
	char *DmlRelType=NULL;
	char *DmlRelStat=NULL;
	char *TaskId=NULL;
	char *PartNum=NULL;
	char *PartNumDup=NULL;
	char *PartRev=NULL;
	char *PartRevDup=NULL;
	char *PartRelStat=NULL;
	char *part_type=NULL;
	char *unit=NULL;
	char *LatRevName=NULL;
	char *chrp=NULL;
	char *part_typeDup=NULL;
	char *unitDup=NULL;
	char *doc_no=NULL;
	char *DmlTagId=NULL;
	char *KeywordDescription=NULL;
	char *KeywordDescriptionDup=NULL;
	char *MaterialClass=NULL;
	char *MaterialClassDup=NULL;
	char *PartFamily=NULL;
	char *PartFamilyDup=NULL;
	char *Barcode=NULL;
	char *BarcodeDup=NULL;
	char *PartRevision=NULL;
	char *specPartNum=NULL;
	char *specPartRev=NULL;
	char *specPartRevDup=NULL;
	char *specPartRelStat=NULL;
	char *RefDocRelObjType=NULL;
	char *RefPartNum=NULL;
	char *RefPartRev=NULL;
	char *RefPartRelStat=NULL;

	char *vcmdu_type = NULL;
	char *VcDesc = NULL;
	char *VcDescDup = NULL;
	char *ColorInd = NULL;
	char *ColorIndDup = NULL;
	char *ColVCNum = NULL;
	char *ColDesc = NULL;
	char *ColDescDup = NULL;

	int ColCount = 0;
	int vehCount = 0;
	int vehColCount = 0;
	int c = 0;
	int d = 0;

	int num_to_sort = 1;
	int sort_order[1]  ={2};
	char *keysAttr[1] = {"creation_date"};

	tag_t *ColPartTags = NULLTAG;
	tag_t *ChildTags = NULLTAG;
	tag_t ChildPartTag = NULLTAG;

	//char  type_name[TCTYPE_name_size_c+1];
	char *type_name = NULL;
	const char *cTemp="item_id";
//	static RFC_RC RfcRc;

	char sbarcode[3];

	meas_unit=(char *) malloc(500 * sizeof(char));

	tmpDrwNum = (char *)malloc(500 * sizeof(char));
	tmpDrwNum1 = (char *)malloc(500 * sizeof(char));
	tmpDrwRev = (char *)malloc(500 * sizeof(char));
	tmpDrwSeq = (char *)malloc(500 * sizeof(char));

	SAPpstat = (char *)malloc(500 * sizeof(char));
	MRPpstat = (char *)malloc(500 * sizeof(char));
	myzeroDup1 = (char *)malloc(500 * sizeof(char));
	myzeroDup2 = (char *)malloc(500 * sizeof(char));
	myzeroDup3 = (char *)malloc(500 * sizeof(char));
	myzeroDup4 = (char *)malloc(500 * sizeof(char));
	std_price = (char *)malloc(500 * sizeof(char));
	moving_avg_price = (char *)malloc(500 * sizeof(char));
	cost_lot_size = (char *)malloc(500 * sizeof(char));
	mat_type = (char *)malloc(500 * sizeof(char));
	descDup = (char *)malloc(500 * sizeof(char));
	dml_numER=(char *) MEM_alloc(20 * sizeof(char));
	DMLDescription=(char *) MEM_alloc(40 * sizeof(char));
	erc_release_date=(char *) MEM_alloc(40 * sizeof(char));



	//char *qry_entries[1] = {"Name"};
	char *qry_entries[1] = {"ID"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	//printf("\n 111111"); fflush(stdout);

	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	
	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
	inputDML = ITK_ask_cli_argument("-d=");
	iSapServer = ITK_ask_cli_argument("-s=");

	if(tc_strcmp(sUserName,"")==0 || tc_strcmp(sPassword,"")==0 || tc_strcmp(inputDML,"")==0 || tc_strcmp(iSapServer,"")==0)
	{
		printf("\nercSAPMatUA -u=userid -p=password -d=dml_number -s=PVP\n");fflush(stdout);
		goto CLEANUP;
	}
	
	//sprintf(fsuccess_name,"%s/PLMSAP/PLM_SAP_ERC_LOG/Erc_Sap_Mat_%s_%s.log",getenv("ONLREP"),inputDML,iSapServer);
	//sprintf(fsuccess_name,"/user/plmsap/PLMSAP/PLM_SAP_ERC_LOG/Erc_Sap_Mat_%s.log",inputDML);
	sprintf(fsuccess_name,"Erc_Sap_Mat_%s.log",inputDML);
	fsuccess = fopen(fsuccess_name,"a");

	if(QRY_find2("ERCDMLReleased", &queryTag));
	printf("\nAfter ERCDMLReleased : QRY_find \n");fflush(stdout);
	if (queryTag)
	{
		printf("\nFound Query ERCDMLReleased  \n");fflush(stdout);
	}
	else
	{
		printf("\nNotFound Query ERCDMLReleased");fflush(stdout);
		goto CLEANUP;
	}

	  printf("\n inputDML:%s: \n ", inputDML);fflush(stdout);
	  fprintf(fsuccess,"\nInputDML:%s: \n ", inputDML);fflush(stdout);

      qry_values[0] = inputDML;

	//if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &outTag));
	//1-Ascending 2- Descending
	ITK_CALL(QRY_execute_with_sort(queryTag, n_entries, qry_entries, qry_values,num_to_sort,keysAttr,sort_order, &resultCount, &outTag));

    printf("\t resultCount :%d:\n", resultCount);fflush(stdout);

	//if(resultCount>0)
for (d = 0 ; d < resultCount ; d ++ )
{
       ErcDmlTag=outTag[d];
	
	
	if (ErcDmlTag != NULLTAG)
	{
		printf("\nDML : %s Found With ERCDMLReleased Query",inputDML);fflush(stdout);
		fprintf(fsuccess,"\nDML : %s Found With ERCDMLReleased Query",inputDML);fflush(stdout);
	}
	else
	{ 
		printf("\nERC DML %s not found in TCUA\n",inputDML);
		fprintf(fsuccess,"\nERC DML %s not found in TCUA\n",inputDML);
		goto CLEANUP;
	}

	if(TCTYPE_ask_object_type(ErcDmlTag,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\nErcDmlTag -> objTypeTag  %s\n", type_name);fflush(stdout);
	fprintf(fsuccess,"\nErcDmlTag -> objTypeTag  %s\n", type_name);fflush(stdout);


	if(strcmp(type_name,"ChangeRequestRevision")==0)
	{
		ITK_CALL(AOM_ask_value_string(ErcDmlTag,"item_id",&DmlId));
		ITK_CALL(AOM_ask_value_string(ErcDmlTag,"current_name",&DmlDesc));
		ITK_CALL(AOM_ask_value_string(ErcDmlTag,"t5_rlstype",&DmlRelType));
		ITK_CALL(AOM_UIF_ask_value(ErcDmlTag,"release_status_list",&DmlRelStat));
		ITK_CALL(AOM_ask_value_date(ErcDmlTag,"date_released",&DmlRelDate));
		//ITK_CALL(ITK_date_to_string(DmlRelDate,&DmlRelDateStr));
		ITK_CALL(DATE_date_to_string(DmlRelDate,"%d/%m/%Y",&DmlRelDateStr));
		printf("\nDmlId [%s]  DmlRelType [%s] LifeCycleState [%s] DmlDesc [%s]\n",DmlId,DmlRelType,DmlRelStat,DmlDesc);	fflush(stdout);
		fprintf(fsuccess,"\nDmlId [%s]  DmlRelType [%s] LifeCycleState [%s] DmlDesc [%s]\n",DmlId,DmlRelType,DmlRelStat,DmlDesc);	fflush(stdout);
		
		printf("\nDmlReleasedDate [%s] \n",DmlRelDateStr);	fflush(stdout);
		fprintf(fsuccess,"\nDmlReleasedDate [%s] \n",DmlRelDateStr);

		//if(strcmp(DmlRelStat,"ERC Released")!=0)
		if(tc_strstr(DmlRelStat,"ERC Released")==NULL)
		{
			printf("\nDML [%s] is not ERC Released LifeCycleState [%s]\n",DmlId,DmlRelStat); fflush(stdout);
			fprintf(fsuccess,"\nDML [%s] is not ERC Released LifeCycleState [%s]\n",DmlId,DmlRelStat); fflush(stdout);
			//goto CLEANUP;
			continue;
		}

		tc_strcpy(dml_numER, DmlId);
		strcat(dml_numER,"ER");
		//strcat(dml_numER,"E5");
		
		printf("\nDML Change Number [%s]",dml_numER); fflush(stdout);
		fprintf(fsuccess,"\nDML Change Number [%s]",dml_numER); fflush(stdout);

		/*tc_strcpy(DMLDescription,dml_numER);
		strcat(DMLDescription," ");
		strcat(DMLDescription,DmlDesc);*/
		tc_strncpy(DMLDescription,DmlDesc,39);

		printf("\nDML SAP Desc [%s]",DMLDescription); fflush(stdout);
		fprintf(fsuccess,"\nDML SAP Desc [%s]",DMLDescription); fflush(stdout);

		//DmlReleasedDate [11/04/2018]
		strcpy(erc_release_date,"");
		strcpy(erc_release_date,strtok(DmlRelDateStr,"/"));
		strcat(erc_release_date,".");
		strcat(erc_release_date,strtok(NULL,"/"));
		strcat(erc_release_date,".");
		strcat(erc_release_date,strtok(NULL,"/"));

		printf("\nerc_release_date [%s] \n",erc_release_date);	fflush(stdout);
		fprintf(fsuccess,"\nerc_release_date [%s] \n",erc_release_date);	fflush(stdout);

		ITK_CALL(AOM_ask_value_tags(ErcDmlTag,"T5_DMLTaskRelation",&tskcnt,&SetOfDmlTasksTag));
		printf("\nDML Task Count : %d\n",tskcnt);fflush(stdout);
		fprintf(fsuccess,"\nDML Task Count : %d\n",tskcnt);fflush(stdout);
		
		if (tskcnt>0)
		{
			for(t=0;t<tskcnt;t++)
			{
				ITK_CALL(AOM_ask_value_string(SetOfDmlTasksTag[t],"item_id",&TaskId));
				printf("\nDML Task [%s]",TaskId);fflush(stdout);
				fprintf(fsuccess,"\nDML Task [%s]",TaskId);fflush(stdout);
				
				if (tc_strstr(TaskId,"APL")!=NULL)
				{
					printf("\nSkipping APL DML Task [%s]",TaskId);fflush(stdout);
					fprintf(fsuccess,"\nSkipping APL DML Task [%s]",TaskId);fflush(stdout);
					continue;
				}
				
				AOM_ask_value_tags(SetOfDmlTasksTag[t],"CMHasSolutionItem",&partCnt,&SetOfPartTags);
				printf("\nTask : %s No of SolutionItem Parts : %d\n",TaskId, partCnt);
				fprintf(fsuccess,"\nTask : %s No of SolutionItem Parts : %d\n",TaskId,partCnt);
				if (partCnt>0)
				{
					//displaying_objects();
					cll_ccap_ecn_create();
					
					
					printf("\n******Material Creation Starting for [%s]******",TaskId);fflush(stdout);
					fprintf(fsuccess,"\n******Material Creation Starting for [%s]******",TaskId);fflush(stdout);

					for(p=0;p<partCnt;p++)
					{
						PartTag=SetOfPartTags[p];

						
						ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
						tc_strdup(PartNum,&part_noDup);

						ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&PartRev));
						tc_strdup(PartRev,&PartRevDup);

						ITK_CALL(AOM_ask_value_string(PartTag,"t5_PartType",&part_type));
						tc_strdup(part_type,&part_typeDup);

						if(	tc_strcmp(part_typeDup,"D")==0 ||
							tc_strcmp(part_typeDup,"DA")==0 ||
							tc_strcmp(part_typeDup,"DC")==0 ||
							tc_strcmp(part_typeDup,"CM")==0 ||//added 25.03.2023 Hrishikesh
							tc_strcmp(part_typeDup,"IFD")==0 ||
							tc_strcmp(part_typeDup,"IM")==0 ||
							tc_strcmp(part_typeDup,"CP")==0)
						{
							printf("\nPart %s Part Type %s Skiping...",part_noDup,part_typeDup);
							fprintf(fsuccess,"\nPart %s Part Type %s ! Skiping...",part_noDup,part_typeDup);
							continue;
						}

						//CR-FY21-0218
						if (tc_strlen(part_noDup)==12)
						{
							if(STRNG_find_last_char(part_noDup,'R')!=NULL || STRNG_find_last_char(part_noDup,'L')!=NULL)
							{
								if (
									tc_strcmp(part_typeDup,"VC")==0 ||
									tc_strcmp(part_typeDup,"CCVC")==0 ||
									tc_strcmp(part_typeDup,"VCCR")==0 ||
									tc_strcmp(part_typeDup,"CKDVC") == 0 ||
									tc_strcmp(part_typeDup,"SKDVC") == 0
								 )
								{
									printf("\nPart %s and PartType %s Found OK\n",part_noDup,part_type);
								}
								else
								{
									printf("\nPart %s and PartType %s Its PartType must be either of VC/CCVC/VCCR/CKDVC/SKDVC... NOT OK\n",part_noDup,part_type);
									fprintf(fsuccess,"\nPart %s and PartType %s Its PartType must be either of VC/CCVC/VCCR/CKDVC/SKDVC... NOT OK\n",part_noDup,part_type);
									continue;
								}
							}
							else
							{
								printf("\nPart %s and PartType %s Normal 12-Digit Part\n",part_noDup,part_type);
							}
						}
						
						ITK_CALL(AOM_UIF_ask_value(PartTag,"release_status_list",&PartRelStat));

						if(tc_strstr(PartRelStat,"ERC Released")==NULL)
						{
							printf("\nPart [%s] is not ERC Released LifeCycleState [%s] Skipping...",PartNum,PartRelStat); fflush(stdout);
							fprintf(fsuccess,"\nPart [%s] is not ERC Released LifeCycleState [%s] Skipping...",PartNum,PartRelStat); fflush(stdout);
							continue;
						}
						else
						{
							printf("\nPart [%s] Release Status [%s]",PartNum,PartRelStat); fflush(stdout);
							fprintf(fsuccess,"\nPart [%s] Release Status [%s]",PartNum,PartRelStat); fflush(stdout);
						}

						ITK_CALL(AOM_UIF_ask_value(PartTag,"object_desc",&desc));
						tc_strdup(desc,&descDup);
						
						ITK_CALL(AOM_ask_value_string(PartTag,"t5_ColourInd",&partClrInd));
						tc_strdup(partClrInd,&partClrIndDup);

						ITK_CALL(AOM_ask_value_tag(PartTag,"items_tag",&PartMasterTag));
						
						if ( tc_strcmp(partClrInd,"C") ==0)
						{
							//t5_uom is not found on colour part master/revision

							ITK_CALL(AOM_UIF_ask_value(PartMasterTag,"uom_tag",&unit));
							
							ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_EngineType",&PartFamily));
							tc_strdup(PartFamily,&PartFamilyDup);
						}
						else
						{
							ITK_CALL(AOM_UIF_ask_value(PartMasterTag,"t5_uom",&unit));
							
							ITK_CALL(AOM_UIF_ask_value(PartMasterTag,"t5_EngineType",&PartFamily));
							tc_strdup(PartFamily,&PartFamilyDup);

							ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_Barcode",&Barcode));
							tc_strdup(Barcode,&BarcodeDup);
						}

						ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_CategoryName",&KeywordDescription));
						tc_strdup(KeywordDescription,&KeywordDescriptionDup);

						printf("\nPart Number %s,%s PartType %s ColorInd %s",PartNum,PartRev,part_type,partClrInd);
						fprintf(fsuccess,"\nPart Number %s,%s PartType %s ColorInd %s",PartNum,PartRev,part_type,partClrInd);

						ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_MatlClass",&MaterialClass));
						tc_strdup(MaterialClass,&MaterialClassDup);

						
						
						
						tc_strcpy(sbarcode,"");
						if (tc_strlen(BarcodeDup)==1)
						{
							sbarcode[0] = '0';
							sbarcode[1] = BarcodeDup[tc_strlen(BarcodeDup)-1];
							sbarcode[2] = '\0';
						}
						else if (tc_strlen(BarcodeDup)>=2)
						{
							sbarcode[0] = BarcodeDup[tc_strlen(BarcodeDup)-2];
							sbarcode[1] = BarcodeDup[tc_strlen(BarcodeDup)-1];
							sbarcode[2] = '\0';
						}
						else
						{tc_strcpy(sbarcode,"");}
						
						printf("\nPartFamilyDup : %s",PartFamilyDup);
						printf("\nCategoryName : %s",KeywordDescriptionDup);
						printf("\nMat Class : %s",MaterialClassDup); fflush(stdout);
						printf("\nBarcode : %s and sbarcode : %s",BarcodeDup,sbarcode); fflush(stdout);

						fprintf(fsuccess,"\nPartFamilyDup : %s",PartFamilyDup);
						fprintf(fsuccess,"\nCategoryName : %s",KeywordDescriptionDup);
						fprintf(fsuccess,"\nMat Class : %s",MaterialClassDup); fflush(stdout);
						fprintf(fsuccess,"\nBarcode : %s",BarcodeDup); fflush(stdout);
						
						int plen = 0, ip = 0;
						part_noDupDes = (char *)MEM_alloc(500 * sizeof(char));
						part_noDupDesx = (char *)MEM_alloc(500 * sizeof(char));

						tc_strcpy(part_noDupDes,part_noDup);
						
						plen = tc_strlen(part_noDupDes);

						for(ip = plen; ip < 18 ; ip++)
						{
							tc_strcat(part_noDupDes," ");
						}

						tc_strcat(part_noDupDes,PartFamilyDup);
						plen = tc_strlen(part_noDupDes);

						for(ip = plen; ip < 68; ip++)
						{
							tc_strcat(part_noDupDes," ");
						}

						tc_strcat(part_noDupDes,KeywordDescriptionDup);

						plen = tc_strlen(part_noDupDes);

						for(ip = plen; ip < 108; ip++)
						{
							tc_strcat(part_noDupDes," ");
						}

						tc_strcat(part_noDupDes,MaterialClassDup);
						
						plen = tc_strlen(part_noDupDes);

						for(ip = plen; ip < 148; ip++)
						{
							tc_strcat(part_noDupDes," ");
						}

						tc_strcat(part_noDupDes,sbarcode);

						part_noDupDes[tc_strlen(part_noDupDes)]='\0';
						plen = tc_strlen(part_noDupDes);
						printf("\npart_noDupDes : %s,%d",part_noDupDes,plen);

						tc_strcpy(part_noDupDesx,part_noDup);
						plen = tc_strlen(part_noDupDesx);

						for(ip = plen; ip < 18 ; ip++)
						{
							tc_strcat(part_noDupDesx," ");
						}
						tc_strcat(part_noDupDesx,"XXXX");
						part_noDupDesx[tc_strlen(part_noDupDesx)]='\0';
						plen = tc_strlen(part_noDupDesx);
						printf("\npart_noDupDesx : %s,%d",part_noDupDesx,plen);

						strcpy(myzeroDup1,"0.0");
						strcpy(myzeroDup2,"0.00");
						strcpy(myzeroDup3,"0.000");
						strcpy(myzeroDup4,"0.0000");

						len = tc_strlen(part_noDup);

						if(strcmp(part_typeDup,"")!=0)
						{
							tc_strcpy(mat_type,"");
							
							if (tc_strcmp(part_typeDup, "C") == 0 ||
								tc_strcmp(part_typeDup, "A") == 0 ||
								tc_strcmp(part_typeDup, "G") == 0 
								)
							{
								tc_strcpy(mat_type,"HALB");
							}
							else if (tc_strcmp(part_typeDup, "M") == 0)		//Module
							{
								tc_strcpy(mat_type,"HALB");
							}
							else if (tc_strcmp(part_typeDup, "V") == 0)
							{
								tc_strcpy(mat_type,"HALB");
							}
							else if (tc_strcmp(part_typeDup, "T") == 0)
							{
								tc_strcpy(mat_type,"HALB");
							}
							else if((tc_strcmp(part_typeDup, "VC") == 0)	||
									(tc_strcmp(part_typeDup, "CKDVC") == 0) ||
									(tc_strcmp(part_typeDup, "SKDVC") == 0) ||
									(tc_strcmp(part_typeDup, "CCVC") == 0)	||
									(tc_strcmp(part_typeDup, "SVR") == 0)	||
									(tc_strcmp(part_typeDup, "VCCR") == 0)
									)
							{
								tc_strcpy(mat_type,"FERT");
							}
							else if (tc_strcmp(part_typeDup,"DTPL")==0)
							{
								tc_strcpy(mat_type, "HALB");
							}
							else if (tc_strcmp(part_typeDup,"SA")==0)
							{
								tc_strcpy(mat_type, "HALB");
							}
							else if (tc_strcmp(part_typeDup,"SP")==0)
							{
								tc_strcpy(mat_type, "HALB");
							}
							else if (len == 12 || len == 14)
							{
								tc_strcpy(mat_type,"HALB");
							}
							else if (len == 10 || len == 11)
							{
								tc_strcpy(mat_type,"ROH");
							}
							else if (len == 14 || len == 16)	/*cabin kit logic by Ashish on 19.11.2013*/
							{
								if((*(part_noDup+10)=='C') && (*(part_noDup+11)=='K'))
								{
									tc_strcpy(mat_type,"HALB");
								}
							}

							printf("\nMaterial Type: %s", mat_type);
							fprintf(fsuccess,"\nMaterial Type: %s", mat_type);
						}
						else
						{
							printf("\nPart Type for the part %s is NULL\n",part_noDup);
							continue;
						}
						
					if(strcmp(mat_type,"")==0)
					{
						printf("\nNo Material Type Matching For Part : %s\n", part_noDup);
						fprintf(fsuccess,"\nNo Material Type Matching For Part : %s\n", part_noDup);
						continue;
					}
					
					printf("\nPLM Unit Of Measure : %s",unit);
					fprintf(fsuccess,"\nPLM Unit Of Measure : %s",unit);

					if(tc_strlen(unit)>0)
					{
						tc_strdup(unit,&unitDup);
						if (tc_strcmp(unitDup,"1-Mtr") == 0) tc_strcpy(meas_unit,"M");
						else if (tc_strcmp(unitDup,"2-Kg") == 0) tc_strcpy(meas_unit,"KG");
						else if (tc_strcmp(unitDup,"3-Ltr") == 0) tc_strcpy(meas_unit,"L");
						else if (tc_strcmp(unitDup,"4-Nos") == 0) tc_strcpy(meas_unit,"EA");
						else if (tc_strcmp(unitDup,"5-Sq.Mtr") == 0) tc_strcpy(meas_unit,"M2");
						else if (tc_strcmp(unitDup,"6-Sets") == 0) tc_strcpy(meas_unit,"EA");
						else if (tc_strcmp(unitDup,"7-Tonne") == 0) tc_strcpy(meas_unit,"TO");
						else if (tc_strcmp(unitDup,"8-Cu.Mtr") == 0) tc_strcpy(meas_unit,"M3");
						else if (tc_strcmp(unitDup,"9-Thsnds") == 0) tc_strcpy(meas_unit,"TS");
						else if (tc_strcmp(unitDup,"EA") == 0) tc_strcpy(meas_unit,"EA");
						else
						{
							tc_strdup("EA",&unitDup);
							tc_strcpy(meas_unit,"EA");
						}
					}
					else
					{
						tc_strdup("EA",&unitDup);
						tc_strcpy(meas_unit,"EA");
					}

					//As per CR-FY20-0181
					if (tc_strcmp(part_typeDup, "M") == 0)
					{
						tc_strdup("EA",&unitDup);
						tc_strcpy(meas_unit,"EA");
					}

					printf("\nSAP Unit Of Measure : %s", meas_unit);
					fprintf(fsuccess,"\nSAP Unit Of Measure : %s", meas_unit);

					ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_DrawingInd",&drg_ind));

					if(strcmp(drg_ind,"")!=0)
					{
						tc_strdup(drg_ind,&drg_indDup);
						printf("\nDrawing Indicator: %s\n", drg_indDup);
						fprintf(fsuccess,"\nDrawing Indicator: %s\n", drg_indDup);
					}
					else
					{
						tc_strdup("",&drg_indDup);
						printf("\nDrawing Indicator is NULL!\n");
					}
					
					tc_strdup("",&sizeDup);
					tc_strdup("",&doc_noDup);
					tc_strdup("",&dwg_typeDup);
					tc_strdup("",&dwg_revDup);
					sflag=0;
					RefDocflag=0;

					if(tc_strcmp(drg_indDup,"D")==0 || tc_strcmp(drg_indDup,"A")==0)
					{
						ITK_CALL(GRM_find_relation_type("IMAN_specification", &specDocRelObj));
						ITK_CALL(GRM_list_secondary_objects_only(PartTag,specDocRelObj,&doccount,&docObjs));
						printf("\nIMAN_specification DocCount Value :%d\n",doccount);fflush(stdout);
						fprintf(fsuccess,"\nIMAN_specification DocCount Value :%d\n",doccount);fflush(stdout);

						ITK_CALL(GRM_find_relation_type("IMAN_reference", &specDocRelRefObj));
						ITK_CALL(GRM_list_secondary_objects_only(PartTag,specDocRelRefObj,&docRefcount,&docRefObjs));
						printf("\nIMAN_reference docRefcount Value :%d\n",docRefcount);fflush(stdout);
						fprintf(fsuccess,"\nIMAN_reference docRefcount Value :%d\n",docRefcount);fflush(stdout);

						if(doccount>0)
						{
							for (is=0;is<doccount;is++ )
							{	
								doctag = docObjs[is];
								if(TCTYPE_ask_object_type(doctag,&docOPtr));
								if(TCTYPE_ask_name2(docOPtr,&docClass));
								printf("\nIMAN_specification docClass :: %s\n", docClass);fflush(stdout);
								fprintf(fsuccess,"\nIMAN_specification docClass :: %s\n", docClass);fflush(stdout);

								if (tc_strcmp(docClass,"CMI2Product")==0)
								{
									tc_strdup("CMI2Product",&docClassDup);
								}
								
								if(tc_strcmp(drg_indDup,"D")==0 && (tc_strcmp(docClass,"ProDrw")==0 || tc_strcmp(docClass,"CMI2Drawing")==0))
								{
									sflag=1;
									printf("\n%s,%s \n",drg_indDup,docClass);fflush(stdout);
									break;
								}

								if((tc_strcmp(drg_indDup,"A")==0 && tc_strcmp(part_type,"A")==0) && (tc_strcmp(docClass,"ProAsm")==0 || tc_strcmp(docClass,"CMI2Product")==0))
								{
									sflag=1;
									printf("\n%s,%s,%s \n",part_type,drg_indDup,docClass);fflush(stdout);
									break;
								}

								if((tc_strcmp(drg_indDup,"A")==0 && tc_strcmp(part_type,"C")==0) && (tc_strcmp(docClass,"ProPrt")==0 || tc_strcmp(docClass,"CMI2Part")==0))
								{
									sflag=1;
									printf("\n%s,%s,%s \n",part_type,drg_indDup,docClass);fflush(stdout);
									break;
								}
								
							}

							//21.05.2024 Hrishikesh
							if ( docRefcount > 0)
							{

								for (is=0;is<docRefcount;is++ )
								{	
									docReftag = docRefObjs[is];
									if(TCTYPE_ask_object_type(docReftag,&docRefOPtr));
									if(TCTYPE_ask_name2(docRefOPtr,&docRefClass));
									printf("\nIMAN_reference docRefClass :: %s\n", docRefClass);fflush(stdout);
									fprintf(fsuccess,"\nIMAN_reference docRefClass :: %s\n", docRefClass);fflush(stdout);
									
									if(tc_strcmp(drg_indDup,"D")==0 && (tc_strcmp(docRefClass,"PDF")==0 && tc_strcmp(docClassDup,"CMI2Product")==0))
									{
										sflag=1;
										printf("\n%s,%s,%s \n",drg_indDup,docRefClass,docClassDup);fflush(stdout);
										break;
									}
									
								}
							}

							if(sflag==1)
							{
								ITK_CALL(AOM_UIF_ask_value(doctag,"object_name",&doc_no));
								doc_noDup=strtok(doc_no,"/");
								//dwg_revDup=strtok(NULL,";");
								//tc_strdup(doc_no,&doc_noDup);
								tc_strdup("OWN",&dwg_typeDup);
								tc_strdup("1",&sizeDup);
								dwg_revDup=strtok(PartRevDup,";");
								printf("\nDocument Number : [%s] Document Type : [%s] Document Version : [%s]\n",doc_noDup,dwg_typeDup,dwg_revDup);fflush(stdout);
								fprintf(fsuccess,"\nDocument Number : [%s] Document Type : [%s] Document Version : [%s]\n",doc_noDup,dwg_typeDup,dwg_revDup);fflush(stdout);
							}
						}
						
						if(sflag==0)
						{
							ITK_CALL(GRM_find_relation_type("IMAN_reference", &refdocRelObj));
							//ITK_CALL(GRM_list_secondary_objects(PartTag,refdocRelObj,&Refcount,&refdocObjs));
							ITK_CALL(GRM_list_secondary_objects_only(PartTag,refdocRelObj,&Refcount,&refdocObjs));
							printf("\nIMAN_reference DocCount Value :%d\n",Refcount);fflush(stdout);
							fprintf(fsuccess,"\nIMAN_reference DocCount Value :%d\n",Refcount);fflush(stdout);
							//char sRefDoctype_name[TCTYPE_name_size_c+1];
							char *sRefDoctype_name = NULL;
							if(Refcount>0)
							{

								for (is=0;is<Refcount;is++ )
								{	
									//doctag = refdocObjs[is].secondary;

									doctag = refdocObjs[is];
									if(TCTYPE_ask_object_type(doctag,&docOPtr));
									if(TCTYPE_ask_name2(docOPtr,&sRefDoctype_name));
									printf("\nIMAN_reference sRefDoctype_name :: %s\n", sRefDoctype_name);fflush(stdout);
									fprintf(fsuccess,"\nIMAN_reference sRefDoctype_name :: %s\n", sRefDoctype_name);fflush(stdout);

									if(tc_strcmp(drg_indDup,"D")==0 && (tc_strcmp(sRefDoctype_name,"ProDrw")==0 || tc_strcmp(sRefDoctype_name,"CMI2Drawing")==0))
									{
										RefDocflag=1;
										printf("\n%s \n",sRefDoctype_name);fflush(stdout);
										break;
									}

									if((tc_strcmp(drg_indDup,"A")==0 && tc_strcmp(part_type,"A")==0) && (tc_strcmp(sRefDoctype_name,"ProAsm")==0 || tc_strcmp(sRefDoctype_name,"CMI2Product")==0))
									{
										RefDocflag=1;
										printf("\n%s,%s,%s \n",part_type,drg_indDup,sRefDoctype_name);fflush(stdout);
										break;
									}

									if((tc_strcmp(drg_indDup,"A")==0 && tc_strcmp(part_type,"C")==0) && (tc_strcmp(sRefDoctype_name,"ProPrt")==0 || tc_strcmp(sRefDoctype_name,"CMI2Part")==0))
									{
										RefDocflag=1;
										printf("\n%s,%s,%s \n",part_type,drg_indDup,sRefDoctype_name);fflush(stdout);
										break;
									}
								}

								if(RefDocflag==1)
								{


									//08.05.2024 Hrishikesh CR/ERC/PLM/24/0101
									ITK_CALL(AOM_UIF_ask_value(doctag,"object_name",&doc_no));
									doc_noDup=strtok(doc_no,"/");
									//dwg_revDup=strtok(NULL,";");
									//tc_strdup(doc_no,&doc_noDup);
									tc_strdup("REF",&dwg_typeDup);
									tc_strdup("1",&sizeDup);
									//dwg_revDup=strtok(specPartRev,";");
									dwg_revDup=strtok(PartRevDup,";");
									printf("\nDocument Number : [%s] Document Type : [%s] Document Version : [%s]\n",doc_noDup,dwg_typeDup,dwg_revDup);fflush(stdout);
									fprintf(fsuccess,"\nDocument Number : [%s] Document Type : [%s] Document Version : [%s]\n",doc_noDup,dwg_typeDup,dwg_revDup);fflush(stdout);

									//ITK_CALL(GRM_find_relation_type("IMAN_specification", &specDocRelObj));
									//ITK_CALL(GRM_list_primary_objects(doctag,specDocRelObj,&DocPartCnt,&DocPartObj));
									//printf("\nIMAN_specification relation PartObjCnt %d\n",DocPartCnt);	fflush(stdout);
									//fprintf(fsuccess,"\nIMAN_specification relation PartObjCnt %d\n",DocPartCnt);	fflush(stdout);
									//
									//if (DocPartCnt>0)
									//{
									//	specParttag = DocPartObj[0].primary;
									//	ITK_CALL(AOM_ask_value_string(specParttag,"object_type",&RefDocRelObjType));
									//	ITK_CALL(AOM_ask_value_string(specParttag,"item_id",&specPartNum));
									//	ITK_CALL(AOM_ask_value_string(specParttag,"item_revision_id",&specPartRev));
									//	ITK_CALL(AOM_UIF_ask_value(specParttag,"release_status_list",&specPartRelStat));
									//
									//	printf("\nDocPartObj object_type : [%s]",RefDocRelObjType);
									//
									//	if(tc_strstr(specPartRelStat,"ERC Released")!=NULL)
									//	{
									//		printf("\nspecPartNum : [%s]	specPartRev : [%s]	specPartRelStat : [%s]\n",specPartNum,specPartRev,specPartRelStat);	fflush(stdout);
									//
									//		ITK_CALL(AOM_UIF_ask_value(doctag,"object_name",&doc_no));
									//		doc_noDup=strtok(doc_no,"/");
									//		//dwg_revDup=strtok(NULL,";");
									//		//tc_strdup(doc_no,&doc_noDup);
									//		tc_strdup("REF",&dwg_typeDup);
									//		tc_strdup("1",&sizeDup);
									//		dwg_revDup=strtok(specPartRev,";");
									//		printf("\nDocument Number : [%s] Document Type : [%s] Document Version : [%s]\n",doc_noDup,dwg_typeDup,dwg_revDup);fflush(stdout);
									//		fprintf(fsuccess,"\nDocument Number : [%s] Document Type : [%s] Document Version : [%s]\n",doc_noDup,dwg_typeDup,dwg_revDup);fflush(stdout);
									//	}
									//}
								}
							}
						}
					}


					if ((tc_strcmp(part_typeDup, "VC") == 0) || (tc_strcmp(part_typeDup, "VCCR") == 0)|| (tc_strcmp(part_typeDup, "CKDVC") == 0)|| (tc_strcmp(part_typeDup, "SKDVC") == 0))
					{
						//ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_Weight",&net_wt));
						
						if(tc_strlen(net_wt)>0)
						{
							tc_strdup(net_wt,&net_wtDup);
						}
						else
						{
							tc_strdup("0.000",&net_wtDup);
						}
					}
					else
					{
						tc_strdup("0.000",&net_wtDup);
					}

					tc_strdup("0.000",&gross_weight);
					tc_strdup(gross_weight,&gross_weightDup);
					printf("\nNet Weight: %s", net_wtDup);fflush(stdout);
					printf("\nGross Weight: %s", gross_weight);fflush(stdout);						

					tc_strdup("",&OldMatNoDup);

					tc_strdup("01",&division);
					printf("\ndivision: %s", division);fflush(stdout);
					fprintf(fsuccess,"\ndivision: %s", division);fflush(stdout);

					 /*Weight Unit = KG*/
					tc_strdup("KG",&weight_unit);
					printf("\nWeight Unit: %s", weight_unit);fflush(stdout);
					fprintf(fsuccess,"\nWeight Unit: %s", weight_unit);fflush(stdout);

					/*Volume = 0.000*/
					tc_strdup("0.000",&volume);
					printf("\nVolume: %s", volume);fflush(stdout);
					fprintf(fsuccess,"\nVolume: %s", volume);fflush(stdout);

					/*Volume Unit = M3*/
					tc_strdup("M3",&vol_unit);
					printf("\nVolume Unit: %s", vol_unit);fflush(stdout);
					fprintf(fsuccess,"\nVolume Unit: %s", vol_unit);fflush(stdout);

					/*Material Group = ZZZZZZ*/
					tc_strdup("ZZZZZZ",&mat_grp);
					printf("\nMaterial Group: %s", mat_grp);fflush(stdout);
					fprintf(fsuccess,"\nMaterial Group: %s", mat_grp);fflush(stdout);

					/*Division = 01*/
					tc_strdup("01",&basic_division);
					printf("\nBasic Division: %s", basic_division);fflush(stdout);
					fprintf(fsuccess,"\nBasic Division: %s", basic_division);fflush(stdout);

					group = *part_noDup;
					if (group=='G')
					{
						printf("\nGroup Part : %c", part_noDup);fflush(stdout);
					}
					
					if (tc_strcmp(part_typeDup,"VC")==0 ||
						tc_strcmp(part_typeDup,"VCCR")==0 ||
						tc_strcmp(part_typeDup,"CCVC")==0 ||
						tc_strcmp(part_typeDup,"V")==0)
					{
						//printf("\nGetting Chassis Type Number : %s", part_noDup);fflush(stdout);
						//fprintf(fsuccess,"\nGetting Chassis Type Number : %s", part_noDup);fflush(stdout);
						getChassisType(PartTag,part_typeDup,partClrIndDup);
					}
					else
					{
						tc_strdup("",&OldMatNoDup);
					}

					printf("\nCalling... CLL_BAPI_MATERIAL_SAVEDATA 1");fflush(stdout);
					fprintf(fsuccess,"\nCalling... CLL_BAPI_MATERIAL_SAVEDATA 1");fflush(stdout);
					CLL_BAPI_MATERIAL_SAVEDATA();

					if (pstat=='K')
					{
						if( sflag==1 || RefDocflag==1)
						{
							printf("\n****** Document Version Update for part :[%s] ******",part_noDup); fflush(stdout);
							fprintf(fsuccess,"\n****** Document Version Update for part :[%s] ******",part_noDup); fflush(stdout);
							UPD_BAPI_MATERIAL_SAVEDATA();
						}

						printf("\nGoing for Description Change : "); fflush(stdout);
						fprintf(fsuccess,"\nGoing for Description Change : "); fflush(stdout);
						//descChange(part_noDup,descDup,dml_numER);//14.12.2022 Hrishikesh
					}
				}
				
				printf("\n******Drawing Revision Creation loop starting for :[%s] ******",TaskId); fflush(stdout);
				fprintf(fsuccess,"\n******Drawing Revision Creation loop starting for :[%s] ******",TaskId);

				for(p=0;p<partCnt;p++)
				{
					PartTag=SetOfPartTags[p];
					ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
					tc_strdup(PartNum,&part_noDup);

					ITK_CALL(AOM_ask_value_string(PartTag,"t5_PartType",&part_type));
					tc_strdup(part_type,&part_typeDup);

					ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_DrawingInd",&drg_ind));
					tc_strdup(drg_ind,&drg_indDup);
					
					ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&PartRev));
					tc_strdup(PartRev,&PartRevDup);
					PartRevision=strtok(PartRevDup,";");
					printf("\nPartNum [%s] part_type [%s] drg_ind [%s] PartRevision [%s]",part_noDup,part_typeDup,drg_indDup,PartRevision);
					fprintf(fsuccess,"\nPartNum [%s] part_type [%s] drg_ind [%s] PartRevision [%s]",part_noDup,part_typeDup,drg_indDup,PartRevision);

					if(tc_strcmp(part_type,"D")!=0 && tc_strcmp(part_type,"DA")!=0 && tc_strcmp(part_type,"Dummy")!=0 && tc_strcmp(part_type,"DC")!=0 && tc_strcmp(part_type,"IFD")!=0 && tc_strcmp(part_type,"IM")!=0 && tc_strcmp(part_type,"V")!=0 && tc_strcmp(part_type,"T")!=0 && tc_strcmp(part_type,"VC")!=0)
					{
						if(tc_strcmp(drg_indDup,"D")==0 || tc_strcmp(drg_indDup,"A")==0)
						{
							ITK_CALL(GRM_find_relation_type("IMAN_specification", &specDocRelObj));
							ITK_CALL(GRM_list_secondary_objects_only(PartTag,specDocRelObj,&doccount,&docObjs));
							printf("\nIMAN_specification DocCount Value :%d\n",doccount);fflush(stdout);
							fprintf(fsuccess,"\nIMAN_specification DocCount Value :%d\n",doccount);fflush(stdout);

							if(doccount>0)
							{
								for (is=0;is<doccount;is++ )
								{	
									doctag = docObjs[is];
									if(TCTYPE_ask_object_type(doctag,&docOPtr));
									if(TCTYPE_ask_name2(docOPtr,&docClass));
									printf("\nIMAN_specification docClass :: %s\n", docClass);fflush(stdout);
									fprintf(fsuccess,"\nIMAN_specification docClass :: %s\n", docClass);fflush(stdout);

									if (tc_strcmp(docClass,"CMI2Product")==0)
									{
										tc_strdup("CMI2Product",&docClassDup);
									}
									
									if(tc_strcmp(drg_indDup,"D")==0 && (tc_strcmp(docClass,"ProDrw")==0 || tc_strcmp(docClass,"CMI2Drawing")==0))
									{
										sflag=1;
										printf("\n%s,%s \n",drg_indDup,docClass);fflush(stdout);
										break;
									}

									if((tc_strcmp(drg_indDup,"A")==0 && tc_strcmp(part_type,"A")==0) && (tc_strcmp(docClass,"ProAsm")==0 || tc_strcmp(docClass,"CMI2Product")==0))
									{
										sflag=1;
										printf("\n%s,%s,%s \n",part_type,drg_indDup,docClass);fflush(stdout);
										break;
									}

									if((tc_strcmp(drg_indDup,"A")==0 && tc_strcmp(part_type,"C")==0) && (tc_strcmp(docClass,"ProPrt")==0 || tc_strcmp(docClass,"CMI2Part")==0))
									{
										sflag=1;
										printf("\n%s,%s,%s \n",part_type,drg_indDup,docClass);fflush(stdout);
										break;
									}
									
								}
								
								//28.05.2024 Hrishikesh
								if ( docRefcount > 0)
								{

									for (is=0;is<docRefcount;is++ )
									{	
										docReftag = docRefObjs[is];
										if(TCTYPE_ask_object_type(docReftag,&docRefOPtr));
										if(TCTYPE_ask_name2(docRefOPtr,&docRefClass));
										printf("\nIMAN_reference docRefClass :: %s\n", docRefClass);fflush(stdout);
										fprintf(fsuccess,"\nIMAN_reference docRefClass :: %s\n", docRefClass);fflush(stdout);
										
										if(tc_strcmp(drg_indDup,"D")==0 && (tc_strcmp(docRefClass,"PDF")==0 && tc_strcmp(docClassDup,"CMI2Product")==0))
										{
											sflag=1;
											printf("\n%s,%s,%s \n",drg_indDup,docRefClass,docClassDup);fflush(stdout);
											break;
										}
										
									}
								}

								if(sflag==1)
								{
									ITK_CALL(AOM_UIF_ask_value(doctag,"object_name",&doc_no));
									tc_strdup(doc_no,&doc_noDup);
									tc_strdup("OWN",&dwg_typeDup);
									tc_strdup("1",&sizeDup);

									printf("\nIMAN_specification relation found, updating Design Revission as SAP Revision level : [%s]\n", PartRevision);fflush(stdout);
									fprintf(fsuccess,"\nIMAN_specification relation found, updating Design Revission as SAP Revision level : [%s]\n", PartRevision);fflush(stdout);
									BapiRevcr(dml_numER,part_noDup,PartRevision);
								}
							}
							
							if(sflag==0)
							{
								ITK_CALL(GRM_find_relation_type("IMAN_reference", &refdocRelObj));
								//ITK_CALL(GRM_list_secondary_objects(PartTag,refdocRelObj,&Refcount,&refdocObjs));
								ITK_CALL(GRM_list_secondary_objects_only(PartTag,refdocRelObj,&Refcount,&refdocObjs));
								printf("\nIMAN_reference DocCount Value :%d\n",Refcount);fflush(stdout);
								fprintf(fsuccess,"\nIMAN_reference DocCount Value :%d\n",Refcount);fflush(stdout);
								//char sRefDoctype_name[TCTYPE_name_size_c+1];
								char *sRefDoctype_name = NULL;
								if(Refcount>0)
								{

									for (is=0;is<Refcount;is++ )
									{	
										//doctag = refdocObjs[is].secondary;
										doctag = refdocObjs[is];
										if(TCTYPE_ask_object_type(doctag,&docOPtr));
										if(TCTYPE_ask_name2(docOPtr,&sRefDoctype_name));
										printf("\nIMAN_reference sRefDoctype_name :: %s\n", sRefDoctype_name);fflush(stdout);
										fprintf(fsuccess,"\nIMAN_reference sRefDoctype_name :: %s\n", sRefDoctype_name);fflush(stdout);

										if(tc_strcmp(drg_indDup,"D")==0 && (tc_strcmp(sRefDoctype_name,"ProDrw")==0 || tc_strcmp(sRefDoctype_name,"CMI2Drawing")==0))
										{
											RefDocflag=1;
											printf("\n%s \n",sRefDoctype_name);fflush(stdout);
											break;
										}

										if((tc_strcmp(drg_indDup,"A")==0 && tc_strcmp(part_type,"A")==0) && (tc_strcmp(sRefDoctype_name,"ProAsm")==0 || tc_strcmp(sRefDoctype_name,"CMI2Product")==0))
										{
											RefDocflag=1;
											printf("\n%s,%s,%s \n",part_type,drg_indDup,sRefDoctype_name);fflush(stdout);
											break;
										}

										if((tc_strcmp(drg_indDup,"A")==0 && tc_strcmp(part_type,"C")==0) && (tc_strcmp(sRefDoctype_name,"ProPrt")==0 || tc_strcmp(sRefDoctype_name,"CMI2Part")==0))
										{
											RefDocflag=1;
											printf("\n%s,%s,%s \n",part_type,drg_indDup,sRefDoctype_name);fflush(stdout);
											break;
										}
									}

									if(RefDocflag==1)
									{

										//08.05.2024 Hrishikesh CR/ERC/PLM/24/0101
										ITK_CALL(AOM_UIF_ask_value(doctag,"object_name",&doc_no));
										tc_strdup(doc_no,&doc_noDup);
										tc_strdup("REF",&dwg_typeDup);
										tc_strdup("1",&sizeDup);
										//08.05.2024 Hrishikesh CR/ERC/PLM/24/0101
										printf("\nIMAN_reference relation found, updating Design Revission as SAP Revision level : [%s]\n", PartRevision);fflush(stdout);
										fprintf(fsuccess,"\nIMAN_reference relation found, updating Design Revission as SAP Revision level : [%s]\n", PartRevision);fflush(stdout);
										BapiRevcr(dml_numER,part_noDup,PartRevision);



										//ITK_CALL(AOM_UIF_ask_value(doctag,"object_name",&doc_no));
										//tc_strdup(doc_no,&doc_noDup);
										//printf("\nReference Drawing Documents Found, Document Number: %s",doc_noDup);fflush(stdout);
										//fprintf(fsuccess,"\nReference Drawing Documents Found, Document Number: %s",doc_noDup);fflush(stdout);
										//
										//ITK_CALL(GRM_find_relation_type("IMAN_specification", &specDocRelObj));
										//ITK_CALL(GRM_list_primary_objects(doctag,specDocRelObj,&DocPartCnt,&DocPartObj));
										//printf("\nIMAN_specification relation PartObjCnt %d\n",DocPartCnt);	fflush(stdout);
										//fprintf(fsuccess,"\nIMAN_specification relation PartObjCnt %d\n",DocPartCnt);	fflush(stdout);
										//
										//if (DocPartCnt>0)
										//{
										//	specParttag = DocPartObj[0].primary;
										//	ITK_CALL(AOM_ask_value_string(specParttag,"object_type",&RefDocRelObjType));
										//	ITK_CALL(AOM_ask_value_string(specParttag,"item_id",&specPartNum));
										//	ITK_CALL(AOM_ask_value_string(specParttag,"item_revision_id",&specPartRev));
										//	ITK_CALL(AOM_UIF_ask_value(specParttag,"release_status_list",&specPartRelStat));
										//
										//	printf("\nDocPartObj object_type : [%s]",RefDocRelObjType);
										//
										//	if(tc_strstr(specPartRelStat,"ERC Released")!=NULL)
										//	{
										//		printf("\nspecPartNum : [%s]	specPartRev : [%s]	specPartRelStat : [%s]\n",specPartNum,specPartRev,specPartRelStat);	fflush(stdout);
										//		tc_strdup(specPartRev,&specPartRevDup);
										//		PartRevision=strtok(specPartRevDup,";");
										//		printf("\nspecPartNum : [%s]	PartRevision : [%s]\n",specPartNum,PartRevision);	fflush(stdout);
										//		fprintf(fsuccess,"\nspecPartNum : [%s]	PartRevision : [%s]\n",specPartNum,PartRevision);	fflush(stdout);
										//		printf("\nIMAN_reference relation found, updating Reference Doc Part Revision as SAP Revision level : [%s]\n", PartRevision);fflush(stdout);
										//		fprintf(fsuccess,"\nIMAN_reference relation found, updating Reference Doc Part Revision as SAP Revision level : [%s]\n", PartRevision);fflush(stdout);
										//		BapiRevcr(dml_numER,part_noDup,PartRevision);
										//
										//		//Updating all reference relation parts of drawing Document.
										//		ITK_CALL(GRM_list_primary_objects(doctag,refdocRelObj,&RefRelPartCnt,&RefRelPartObj));
										//		printf("\nDrawing Document [%s] RefRelPartCnt : [%d]",doc_noDup,RefRelPartCnt);
										//		
										//		for (ref=0;ref<RefRelPartCnt;ref++)
										//		{
										//			RefPartTag = RefRelPartObj[ref].primary;
										//
										//			ITK_CALL(AOM_ask_value_string(RefPartTag,"item_id",&RefPartNum));
										//			ITK_CALL(AOM_ask_value_string(RefPartTag,"item_revision_id",&RefPartRev));
										//			ITK_CALL(AOM_UIF_ask_value(RefPartTag,"release_status_list",&RefPartRelStat));
										//
										//			if(tc_strstr(RefPartRelStat,"ERC Released")!=NULL)
										//			{
										//				printf("\nDrawing Document [%s] Rev [%s] Updating Revision of RefPartNum : [%s] [%s] [%s]",doc_noDup,PartRevision,RefPartNum,RefPartRev,RefPartRelStat);
										//				fprintf(fsuccess,"\nDrawing Document [%s] Rev [%s] Updating Revision of RefPartNum : [%s] [%s] [%s]",doc_noDup,PartRevision,RefPartNum,RefPartRev,RefPartRelStat);
										//				BapiRevcr(dml_numER,RefPartNum,PartRevision);
										//			}
										//			else
										//			{
										//				printf("\nDrawing Document [%s] RefPartNum : [%s] [%s] skipping from revision update as LCS [%s]",doc_noDup,RefPartNum,RefPartRev,RefPartRelStat);
										//				fprintf(fsuccess,"\nDrawing Document [%s] RefPartNum : [%s] [%s] skipping from revision update as LCS [%s]",doc_noDup,RefPartNum,RefPartRev,RefPartRelStat);
										//				continue;
										//			}
										//
										//		}
										//	}
										//	else
										//	{
										//		printf("\nspecPartNum : [%s]	specPartRev : [%s]	specPartRelStat : [%s], hence skipping Revsion Level update for Part [%s]",specPartNum,specPartRev,specPartRelStat,part_noDup);	fflush(stdout);
										//		fprintf(fsuccess,"\nspecPartNum : [%s]	specPartRev : [%s]	specPartRelStat : [%s], hence skipping Revsion Level update for Part [%s]",specPartNum,specPartRev,specPartRelStat,part_noDup);	fflush(stdout);
										//		continue;
										//	}
										//
										//	
										//}
									}
								}
							}

							if (Refcount==0)
							{
								printf("\nPart [%s]	Drawing Ind [%s] Updating Part Revision [%s]",part_noDup,drg_indDup,PartRevision);
								fprintf(fsuccess,"\nPart [%s]	Drawing Ind [%s] Updating Part Revision [%s]",part_noDup,drg_indDup,PartRevision);
								BapiRevcr(dml_numER,part_noDup,PartRevision);
							}

							
						
						}
						else if(tc_strcmp(drg_indDup,"N")==0)
						{
							printf("\nPart [%s]	Drawing Ind [%s] Updating Part Revision [%s]",part_noDup,drg_indDup,PartRevision);
							fprintf(fsuccess,"\nPart [%s]	Drawing Ind [%s] Updating Part Revision [%s]",part_noDup,drg_indDup,PartRevision);
							BapiRevcr(dml_numER,part_noDup,PartRevision);
						}
						else
						{continue;}
					}
				}
			}

			//VCMDU - VDESC
			if (tc_strcmp(DmlRelType,"VCMDU")==0)
			{
				ITK_CALL(AOM_ask_value_string(ErcDmlTag,"t5_mdmrlstype",&vcmdu_type));

				printf("\nDmlRelType : %s Type : %s",DmlRelType,vcmdu_type);fflush(stdout);
				fprintf(fsuccess,"\nDmlRelType : %s Type : %s",DmlRelType,vcmdu_type);fflush(stdout);

				if (tc_strcmp(vcmdu_type,"VCDESC")==0 )
				{
					ITK_CALL(AOM_ask_value_tags(SetOfDmlTasksTag[t],"CMReferences",&partCnt,&SetOfPartTags)); //Change References
				}//if VCDESC
				else if(tc_strcmp(vcmdu_type,"Alias")==0)
				{
					ITK_CALL(AOM_ask_value_tags(SetOfDmlTasksTag[t],"IMAN_reference",&partCnt,&SetOfPartTags)); //Change References
				}
					
				printf("\nTask : %s No of CMReferences Parts : %d\n",TaskId, partCnt);
				fprintf(fsuccess,"\nTask : %s No of CMReferences Parts : %d\n",TaskId,partCnt);

				if (partCnt>0)
				{
					//displaying_objects();
					cll_ccap_ecn_create();

				}

				for(p=0;p<partCnt;p++)
				{
					PartTag = SetOfPartTags[p];
					ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
					tc_strdup(PartNum,&PartNumDup);

					ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&PartRev));
					tc_strdup(PartRev,&PartRevDup);

					ITK_CALL(AOM_ask_value_string(PartTag,"t5_PartType",&part_type));
					tc_strdup(part_type,&part_typeDup);

					ITK_CALL(AOM_ask_value_string(PartTag,"object_desc",&VcDesc));
					tc_strdup(VcDesc,&VcDescDup);

					printf("\nPart %s/%s Part Type : %s\n",PartNumDup,PartRevDup,part_typeDup);

					if (tc_strcmp(part_typeDup,"VC")!=0 && tc_strcmp(part_typeDup,"CCVC")!=0)
					{
						printf("\nPart type not VC or CCVC, skipping %s",PartNumDup);
						continue;
					}

					printf("\nVC : %s/%s Desc : %s\n",PartNumDup,PartRevDup,VcDescDup);
					fprintf(fsuccess,"\nVC : %s/%s Desc : %s\n",PartNumDup,PartRevDup,VcDescDup);
					
					descChange(PartNumDup,VcDescDup,dml_numER);

					//Get All Colour VC CCVC and update Desc
					ITK_CALL(AOM_ask_value_string(PartTag,"t5_ColourInd",&ColorInd));
					tc_strdup(ColorInd,&ColorIndDup);
					if (tc_strcmp(ColorIndDup,"Y")==0)
					{
						ITK_CALL(AOM_ask_value_tags(PartTag,"representation_for",&ColCount,&ColPartTags));
						
						for (c=0;c<ColCount;c++)
						{
							ITK_CALL(AOM_ask_value_string(ColPartTags[c],"item_id",&ColVCNum));
							ITK_CALL(AOM_ask_value_string(ColPartTags[c],"object_desc",&ColDesc));
							tc_strdup(ColDesc,&ColDescDup);

							printf("\nColor VC : %s New Desc : %s",ColVCNum,ColDescDup);
							fprintf(fsuccess,"\nColor VC : %s New Desc : %s",ColVCNum,ColDescDup);

							descChange(ColVCNum,ColDescDup,dml_numER);
						}
					}

					if (tc_strcmp(part_typeDup,"VC")==0)
					{
						//Getting Child of VC
						ITK_CALL(AOM_ask_value_tags(PartTag,"ps_children",&vehCount,&ChildTags));
						if (vehCount>0)
						{
							ChildPartTag = ChildTags [0];
							ITK_CALL(AOM_ask_value_string(ChildPartTag,"item_id",&PartNum));
							tc_strdup(PartNum,&PartNumDup);

							ITK_CALL(AOM_ask_value_string(ChildPartTag,"item_revision_id",&PartRev));
							tc_strdup(PartRev,&PartRevDup);

							ITK_CALL(AOM_ask_value_string(ChildPartTag,"t5_PartType",&part_type));
							tc_strdup(part_type,&part_typeDup);

							ITK_CALL(AOM_ask_value_string(ChildPartTag,"object_desc",&VcDesc));
							tc_strdup(VcDesc,&VcDescDup);

							//Get colour vehicle and update description
							ITK_CALL(AOM_ask_value_string(ChildPartTag,"t5_ColourInd",&ColorInd));
							tc_strdup(ColorInd,&ColorIndDup);
						
							printf("\nVehicle : %s/%s Desc : %s\n",PartNumDup,PartRevDup,VcDescDup);
							fprintf(fsuccess,"\nVehicle : %s/%s Desc : %s\n",PartNumDup,PartRevDup,VcDescDup);
							
							descChange(PartNumDup,VcDescDup,dml_numER);
							
							if (tc_strcmp(ColorIndDup,"Y")==0)
							{
								ITK_CALL(AOM_ask_value_tags(ChildPartTag,"representation_for",&vehColCount,&ColPartTags));
								for (c=0;c<vehColCount;c++)
								{
									ITK_CALL(AOM_ask_value_string(ColPartTags[c],"item_id",&PartNum));
									tc_strdup(PartNum,&PartNumDup);

									ITK_CALL(AOM_ask_value_string(ColPartTags[c],"item_revision_id",&PartRev));
									tc_strdup(PartRev,&PartRevDup);

									ITK_CALL(AOM_ask_value_string(ColPartTags[c],"t5_PartType",&part_type));
									tc_strdup(part_type,&part_typeDup);

									ITK_CALL(AOM_ask_value_string(ColPartTags[c],"object_desc",&VcDesc));
									tc_strdup(VcDesc,&VcDescDup);

									printf("\nColour Vehicle : %s/%s Desc : %s\n",PartNumDup,PartRevDup,VcDescDup);
									fprintf(fsuccess,"\nColour Vehicle : %s/%s Desc : %s\n",PartNumDup,PartRevDup,VcDescDup);
									
									descChange(PartNumDup,VcDescDup,dml_numER);
								}
							}
						}
					}
				}//for loop
			}

			}//task id loop
			break;
		}
	}

}

printf("\nERC DML Transfer Program Completed\n");
fprintf(fsuccess,"\nERC DML Transfer Program Completed\n");

ITK_CALL(POM_logout(false));
return status;

CLEANUP:
ITK_CALL(POM_logout(false));
printf("\nCLEANUP...\n"); fflush(stdout);

}

