compile ercSAPMatUA.c
linkitk -o ercSAPMatUA ercSAPMatUA.o
$TC_ROOT/tcldPatch/tcPatchExecutable ercSAPMatUA
#ercSAPMatUA -d=test -s=CVD
