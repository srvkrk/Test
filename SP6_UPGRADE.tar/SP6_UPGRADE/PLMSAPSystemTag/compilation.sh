./compile PLMSAPSystemTag.c
./linkitk -o PLMSAPSystemTag PLMSAPSystemTag.o
chmod 777 *
