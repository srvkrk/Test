#include "malloc.h"
#include "stdio.h"
#include <ae/dataset.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <tc/envelope.h>
#include <fclasses/tc_date.h>
#include <user_exits/epm_toolkit_utils.h>
#include <cJSON.h>
#include <curl/curl.h>
#define MAX_LINE_LENGTH 1000
#include <ics/ics2.h>
#include <ics/ics.h>

FILE* fsuccess;
FILE* fp=NULL;
FILE* finsp;
FILE* fval;

char fsuccess_name[200];
char fisa_name[200];
char fvac_name[200];

tag_t		*TaskRevision		= NULLTAG;
tag_t		TaskRevTag			= NULLTAG;
tag_t		*PartTags			= NULLTAG;

int tcount=0,pcount=0,TaskCnt=0,PartCnt=0;
char fsuccess_name[200];

//WERKS_D eWerks;
//static MATNR eMatnr;

int apl_dml_flag = 0;
int car_dml = 0;
int go_for_rfc = 0;
int flag_vc_v_tpl = 0;
int flag = 0;
int acc_flag = 0;

char *part_noDupDes=NULL;
char *part_noDupDesx=NULL;
char *MMSCSLocDup=NULL;
char *doc_no=NULL;
char *basic_division=NULL;
char *unit_wt=NULL;
char *volume=NULL;
char *vol_unit=NULL;
char *material_group=NULL;
char *doc_noDup=NULL;
char *dwg_typeDup=NULL;
char *tmpDrwNum1=NULL;
char *tmpDrwNum=NULL;
char *tmpDrwRev=NULL;
char *tmpDrwSeq=NULL;
char *dwg_revDup=NULL;
char *dwg_rev=NULL;
char *sizeDup=NULL;
char *sheet_noDup=NULL;
char *old_mat_no=NULL;
char *net_wt=NULL;
char *net_wtDup=NULL;
char *gross_wt=NULL;
char *part_noDup=NULL;
char *Plant_MakeBuy=NULL;
char *Plant_StoreLoc=NULL;
char *make_buy_indDup=NULL;
char *make_buy_ind=NULL;
char *mat_type=NULL;
char *store_loc=NULL;
char *store_locDup=NULL;
char *mrp_grp=NULL;
char *mrp_type=NULL;
char *abc_ind=NULL;
char *odstatus=NULL;
char *num;
char *drstatus = NULL;
char *drstatusDup = NULL;
char *mm_pp_status = NULL;
char *partClrIndDup = NULL;
char *partClrInd = NULL;
char *reord_pt = NULL;
char *quota_arrangement_usage = NULL;
char *mrp_controller = NULL;
char *lot_size_key = NULL;
char *fixed_lot_size = NULL;
char *max_stlvl = NULL;
char *blk_ind = NULL;
char *sched_mar_key = NULL;
char *req_grp = NULL;
char *period_ind = NULL;
char *mixedmrp = NULL;
char *cs1_val = NULL;
char *alternativb = NULL;
char *avail_chk = NULL;
char *splan_mat = NULL;
char *splan_plant = NULL;
char *splan_conv_fact = NULL;
char *ind_collect = NULL;
char *rep_mfg_in = NULL;
char *rep_mfg = NULL;
char *stock_det_group = NULL;
char *uoissue = NULL;
char *qua_ins_ind = NULL;
char *doc_req = NULL;
char *grptime = NULL;
char *certificate_type = NULL;
char *qm_proc_ind = NULL;
char *control_key = NULL;
char *catalog_prof = NULL;
char *valuation_cat = NULL;
char *price_con = NULL;
char *std_price = NULL;
char *moving_avg_price = NULL;
char *val_class = NULL;
char *mat_origin = NULL;
char *cost_lot_size = NULL;
char *variance_key = NULL;
char *with_quantity_structure = NULL;
char *costing_split_valuation = NULL;
char *costing_val_class = NULL;
char *MatCrChFlag = NULL;
char *dml_numAP1 = NULL;
char *PrtRevDup = NULL;
char *OrgIDDup = NULL;
char *plan_calendar = NULL;
char *profit_centre_sap = NULL;
char *overhd_grp = NULL;
char *dml_no_arg = NULL;
char *myzeroDup3 = NULL;
char *myzeroDup1 = NULL;
char *myzeroDup2 = NULL;
char *myzeroDup4 = NULL;
char *sap_msg = NULL;
char *p;

char *PrtRev=NULL;
char *dml_no = NULL;
char *plant = NULL;
char *PartNumber = NULL;
char *PartRev = NULL;
char *PartSeq = NULL;
char *Parttype = NULL;
char *Error_message = NULL;
char *MATstatus = NULL;
char *series=NULL;
char *PartMakeBuyInd=NULL;
char *DMLEcnType = NULL;
char *DMLRelStatus = NULL;
char *DMLNumDup = NULL;


char *plantcode=NULL;
char *profit_centre2=NULL;
char *plan_calendar2=NULL;
char *overhd_grp2=NULL;
char *origin_group2=NULL;
char *origin_group=NULL;
char *meas_unit=NULL;
char *desc=NULL;
char *descDup=NULL;
char *drg_ind=NULL;
char *drg_indDup=NULL;
char *docClass=NULL;
char *spl_proc_key=NULL;
char *OwnerNameDup=NULL;
char *OwnerName=NULL;
char *proc_type;

char *inputPart=NULL;
char *iPlantCode=NULL;
char *iSapServer=NULL;


char *sap_proc_type=NULL;
char *sap_spproc_type=NULL;
char *SAPpstat=NULL;
char *MRPpstat=NULL;
char pstat;
char pstat_mrp;
char pstat_acc;
char proc_Key;
char spl_Key;
char group;


char *vcprofit_centre_sap = NULL;


//drwnum = (char *)malloc(500 * sizeof(char));


#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)
void rfc_error(char *);
void cll_zbapi_material_savedata_mrp();
////#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
//void cll_zrfc_ac_view_create(void);
//void cll_zbapi_material_savedata_mrp(void);
//
//RFC_RC zbapi_material_savedata_mrp(RFC_HANDLE hRfc,BAPIMATHEAD *,BAPI_MARA *,BAPI_MARAX *,BAPI_MARC *,BAPI_MARCX *,BAPI_MPGD *,BAPI_MPGDX *,BAPI_MARD *,BAPI_MARDX *,BAPI_MBEW *,BAPI_MBEWX *,RMMG1_AENNR *,BAPIRET2 *,ITAB_H ,ITAB_H ,ITAB_H,ITAB_H ,ITAB_H ,char *);
//RFC_RC zbapi_material_savedata_mrpCreate(RFC_HANDLE hRfc,BAPIMATHEAD *eBapiMatHead,BAPI_MARA	*eBasicView,BAPI_MARAX	*eBasicViewx,BAPI_MARC	*eMrpView,BAPI_MARCX	*eMrpViewx,BAPI_MPGD	*eBapi_Mpgd,BAPI_MPGDX	*eBapi_Mpgdx,BAPI_MARD	*eBapi_Mard,BAPI_MARDX	*eBapi_Mardx,BAPI_MBEW	*eAccView,BAPI_MBEWX	*eAccViewx,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2 *eBapiret2,ITAB_H thBapi_Makt,ITAB_H thBapi_Marm,ITAB_H thBapi_Marmx,ITAB_H thBAPIE1PAREX3,ITAB_H thBAPIE1PAREXX3,char *xException);
//RFC_RC BAPI_MATERIAL_MARD(RFC_HANDLE hRfc,BAPIMATHEAD *eBapiMatHead,BAPI_MARD *eBapi_Mard,BAPI_MARDX *eBapi_Mardx,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2 *eBapiret2,char *xException);
//RFC_RC allocate_insp_type(void);
//RFC_RC allocate_insp_type_vc(void);
//
//RFC_RC cll_zrfc_insptype_alloc(RFC_HANDLE);
//RFC_RC vc_zrfc_insptype_alloc(RFC_HANDLE );
//int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3]);
//RFC_RC WIN_DLL_EXPORT_FLAGS zpprfc_revisionnum_change(RFC_HANDLE hRfc,AENNR *eAennr,CCMATNR *eMatnr,CC_REVLV *eRevlv,BAPIRET2 *iMessg,SYST_SUBRC *iRetval,char *xException);
//
//void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);
//void str2nbcd(char *str,unsigned char *bcd,size_t size,int decimals);

//int FetchPlantSpecificData(char* plantcode);
//int Part_CreateChangeFunction(tag_t LatestRev, char *SapServer);
void getTodayDate(char* StdDate);
//int Create_PLMSAP_audit_object ( char *iDmlTask, char *plant, char *PartNumber, char *PartRev, char *PartSeq,char *Parttype, char *Error_message, char *MATstatus);
int DATE_date_to_string (date_t date_struct, const char *format_str, char **date_str);
int EPM__parse_string (const char *pszInputString, char *pszSeparator, int *piStringCount, char ***pppStringList);
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))


static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}

//void F_OUTK(const char *text,const unsigned pos,const unsigned len,char*str)
//{
//  printf("%*.0s",pos,text);fflush(stdout); printf("%-*s : %s\n",len,text,str);fflush(stdout);
//  fprintf(fsuccess,"%*.0s",pos,text); fprintf(fsuccess,"%-*s : %s\n",len,text,str);
//  return;
//}

char *trimwhitespace(char *str)
{
  char *end;

  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)
    return str;

  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  end[1] = '\0';

  return str;
}

char* subString(char* mainStringf ,int fromCharf ,int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}

void getTodayDate(char* StdDate)
{
	struct tm *Sys_T = NULL;
	int Month;
	int Day;
	int Year;
	int hour;
	int min;
	int sec;

	time_t Tval = 0;
	Tval = time(NULL);
	Sys_T = localtime(&Tval);
	Day=Sys_T->tm_mday;
	Month=Sys_T->tm_mon+1;
	Year=1900 + Sys_T->tm_year;
	hour = Sys_T->tm_hour;
	min = Sys_T->tm_min;
	sec = Sys_T->tm_sec;

	sprintf(StdDate,"%02d%02d%02d",Month,Day,Year);
	printf("\nDate:[%s]",StdDate); fflush(stdout);
}

void getCurrentDateTime(char cCurrentAccessDate[20])
{
        int ch;
        time_t temp;
        struct tm *timeptr;
        char pAccessDate[20];
        char    DateS[4];
        printf("getCurrentDateTime calling..........\n");
        temp = time(NULL);
        tc_strcpy(pAccessDate,"");
        timeptr = (struct tm *)localtime(&temp);
        ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
        tc_strcpy(cCurrentAccessDate,pAccessDate);
        printf("cCurrentAccessDate:%s\n",cCurrentAccessDate);

        printf("Date:%d\n",(timeptr->tm_mday));
        printf("Month:%d\n",(timeptr->tm_mon)+1);
        printf("Year:%d\n",(timeptr->tm_year+1900));
        fflush(stdout);
}


struct memory {
  char *response;
  size_t size;
};

static size_t WriteCallback(char *data, size_t size, size_t nmemb, void *clientp)
{
  size_t realsize = size * nmemb;
  struct memory *mem = (struct memory *)clientp;
 
  char *ptr = realloc(mem->response, mem->size + realsize + 1);
  if(!ptr)
    return 0;  /* out of memory */
 
  mem->response = ptr;
  memcpy(&(mem->response[mem->size]), data, realsize);
  mem->size += realsize;
  mem->response[mem->size] = 0;
  
  printf("\nWriteCallback done"); fflush(stdout);
 
  return realsize;
}

int parse_json_object(const char *json_string,char *ParseType) 
{
    int i = 0;
	cJSON *json = cJSON_Parse(json_string);
	if (json == NULL) 
	{ 
        const char *error_ptr = cJSON_GetErrorPtr(); 
        if (error_ptr != NULL) 
		{ 
            printf("Error: %s\n", error_ptr); 
        } 
        cJSON_Delete(json); 
        return 1; 
    } 
	printf("\njson_string : [%s]\n\n",json_string);//to see complete response
	printf("\ncJSON_GetArraySize(json) : [%d]\n\n",cJSON_GetArraySize(json));
	
	printf ("\nParseType : [%s]",ParseType);
	if ( tc_strcmp ( ParseType, "INSP_CREATE" ) == 0 )
	{
		const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZRFC_INSPTYPE_ALLOCResponse");
		const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "MESSG");
			
		for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
		{
			char *tm_Message = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
			printf("\n @@@@@@@@@@@@ INSPECTION ALLOCATION STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			printf("\n INSPTYPE_ALLOC_Message: [%s]\n", tm_Message);fflush(stdout);
			printf("\n SAP Msg for Material Inspection Allocation: [%s]\n", tm_Message);fflush(stdout);
			printf("\n @@@@@@@@@@@@ INSPECTION ALLOCATION STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
		}
	}
	else if ( tc_strcmp ( ParseType, "Batch_Create" ) == 0 )
	{
		const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZRFC_AC_VIEW_CREATEResponse");
		const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "MESSG");
			
		for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
		{
			char *tm_Type = cJSON_GetObjectItem(moon_2, "SYSTEM")->valuestring;
			char *tm_Message = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
			printf("\ntm_Type: [%s]\n", tm_Type);fflush(stdout);
			printf("\nZRFC_AC_VIEW_CREATE_Message: [%s]\n", tm_Message);fflush(stdout);
		}
	}
	/* else if ( tc_strcmp ( ParseType, "PSTAT" ) == 0 )
	{
		//const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "get_pstat_from_sapResponse");
		const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALL");
		const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "RETURN");
			
		for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
		{
			char *tm_Type = cJSON_GetObjectItem(moon_2, "SYSTEM")->valuestring;
			char *tm_Message = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
			printf("\ntm_Type: [%s]\n", tm_Type);fflush(stdout);
			printf("\nget_pstat_from_sap_Message: [%s]\n", tm_Message);fflush(stdout);
		}
	} */
	else if ( tc_strcmp ( ParseType, "PSTAT" ) == 0 )
	{
		printf("\njson_string : [%s]\n\n",json_string);
		if( tc_strstr(json_string ,"BAPI_MATERIAL_GETALLResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALLResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "CLIENTDATA");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_KStatMessage = cJSON_GetObjectItem(moon_2, "MAINT_STAT")->valuestring;
			    printf("\n K-Flag Message: [%s]\n", tm_KStatMessage);fflush(stdout);
			}
		}
		if( tc_strstr(json_string ,"BAPI_MATERIAL_GETALLResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALLResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "PLANTDATA");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_DStatMessage = cJSON_GetObjectItem(moon_2, "MAINT_STAT")->valuestring;
			    printf("\n D-Flag Message: [%s]\n", tm_DStatMessage);fflush(stdout);
			}
		}
		if( tc_strstr(json_string ,"BAPI_MATERIAL_GETALLResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALLResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "VALUATIONDATA");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_BStatMessage = cJSON_GetObjectItem(moon_2, "MAINT_STAT")->valuestring;
			    printf("\n B-Flag Message: [%s]\n", tm_BStatMessage);fflush(stdout);
			}
		}
	}
	else if ( tc_strcmp ( ParseType, "MAT_CREATE_CHANGE" ) == 0 )
	{
		printf("\njson_string : [%s]\n\n",json_string);
		if( tc_strstr(json_string ,"ZBAPI_MATERIAL_SAVEDATAResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZBAPI_MATERIAL_SAVEDATAResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "RETURN");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_matcrexmsg = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
				printf("\n @@@@@@@@@@@@ MATERIAL CREATE/EXTEND STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			    printf("\n SAP Msg for Material Create/Extend: [%s]\n", tm_matcrexmsg);fflush(stdout);
				printf("\n @@@@@@@@@@@@ MATERIAL CREATE/EXTEND STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			}
		}
	}
	else if ( tc_strcmp ( ParseType, "CHANGE_NO" ) == 0 )
	{
		printf("\njson_string : [%s]\n\n",json_string);
		if( tc_strstr(json_string ,"addition") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "addition");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "CcapEcnCreate_Exception");	
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_changename = cJSON_GetObjectItem(moon_2, "Name")->valuestring;
				char *tm_changetext = cJSON_GetObjectItem(moon_2, "Text")->valuestring;
				printf("\n @@@@@@@@@@@@ CHANGE_NO CREATE STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
				printf("\n Change_No Name: [%s]\n", tm_changename);fflush(stdout);
				printf("\n Change_No Text: [%s]\n", tm_changetext);fflush(stdout);
				printf("\n SAP Msg for Change_no Create/Extend: Change_no already maintained for this transaction/event\n");fflush(stdout);
				printf("\n @@@@@@@@@@@@ CHANGE_NO CREATE STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			}
		}
		else
		{
			//const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "CcapEcnCreate");
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "CcapEcnCreateResponse");
			for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				printf("\n @@@@@@@@@@@@ CHANGE_NO CREATE STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
				char *tm_material = cJSON_GetObjectItem(moon_1, "ChangeNo")->valuestring;
				printf("\n Change_No [%s]\n", tm_material);fflush(stdout);
				printf("\n SAP Msg for Change_no Create/Extend: Transaction Completed Succesfully...\n");fflush(stdout);
				printf("\n @@@@@@@@@@@@ CHANGE_NO CREATE STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			}
		}
	}
			
	return 0;
}

void print_json_object(const char *json_string)
{
    cJSON *json = cJSON_Parse(json_string);
    char *formatted_json = cJSON_Print(json);
    printf("%s\n", formatted_json);
    cJSON_Delete(json);
    free(formatted_json);
}

//char *inputPart = NULL;
//char *iPlantCode = NULL; 
char *iMMSCSLoc = NULL;
//char *iSapServer = NULL;

/*struct memory {
  char *response;
  size_t size;
};

static size_t WriteCallback(char *data, size_t size, size_t nmemb, void *clientp)
{
  size_t realsize = size * nmemb;
  struct memory *mem = (struct memory *)clientp;
 
  char *ptr = realloc(mem->response, mem->size + realsize + 1);
  if(!ptr)
    return 0;
 
  mem->response = ptr;
  memcpy(&(mem->response[mem->size]), data, realsize);
  mem->size += realsize;
  mem->response[mem->size] = 0;
  
  printf("\nWriteCallback done"); fflush(stdout);
 
  return realsize;
}

int parse_json_object(const char *json_string,char *ParseType) 
{
    int i = 0;
	cJSON *json = cJSON_Parse(json_string);
	if (json == NULL) 
	{ 
        const char *error_ptr = cJSON_GetErrorPtr(); 
        if (error_ptr != NULL) 
		{ 
            printf("Error: %s\n", error_ptr); 
        } 
        cJSON_Delete(json); 
        return 1; 
    } 
	printf("\njson_string : [%s]\n\n",json_string);
	printf("\ncJSON_GetArraySize(json) : [%d]\n\n",cJSON_GetArraySize(json));
	
	printf ("\nParseType : [%s]",ParseType);
	if( tc_strcmp ( ParseType, "MAT_CREATE_CHANGE" ) == 0 )
	{
		printf("\njson_string : [%s]\n\n",json_string);
		if( tc_strstr(json_string ,"ZBAPI_MATERIAL_SAVEDATAResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZBAPI_MATERIAL_SAVEDATAResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "RETURN");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_matcrexmsg = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
				printf("\n @@@@@@@@@@@@ MATERIAL CREATE/EXTEND STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			    printf("\n SAP Msg for Material Create/Extend: [%s]\n", tm_matcrexmsg);fflush(stdout);
				printf("\n @@@@@@@@@@@@ MATERIAL CREATE/EXTEND STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			}
		}
	}
	else
	{
		printf("\n ------------ ParseType Not Matched --------------\n");fflush(stdout);
	}
			
	return 0;
} 

void print_json_object(const char *json_string)
{
    cJSON *json = cJSON_Parse(json_string);
    char *formatted_json = cJSON_Print(json);
    printf("%s\n", formatted_json);
    cJSON_Delete(json);
    free(formatted_json);
}*/

int tm_curl_profit_center_update ( char *data )
{
	struct memory chunk = {0};
	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\n Failed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	if ( tc_strcmp ( iSapServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n iSapServer is Blank..!!");fflush(stdout);
	}
	
	list = curl_slist_append(list, "Content-Type: application/json");
    
	printf("\nFile request content as below "); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
	printf("\ncurl_easy_setopt"); fflush(stdout);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	printf("\ncurl_easy_perform");fflush(stdout);
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "MAT_CREATE_CHANGE");
	
	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
	printf("\nfree"); fflush(stdout);
	
	curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}

int cll_VC_Profit_Center_Update(char *part_noDup, char *plantcode, char *MMSCSLocDup, char *json_profit_center_update_req_obj)
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *CLIENTDATA_req;
	cJSON *CLIENTDATAX_req;
	cJSON *EXTENSIONIN_req;
	cJSON *EXTENSIONINX_req;
	cJSON *item1_req;
	cJSON *item2_req;
	
	
	cJSON *FORECASTPARAMETERS_req;
	cJSON *FORECASTPARAMETERSX_req;
	
	cJSON *HEADDATA_req;
	
	cJSON *INTERNATIONALARTNOS_req;
	cJSON *item3_req;
	
	cJSON *MATERIALDESCRIPTION_req;
	cJSON *item4_req;
	
	
	cJSON *MATERIALLONGTEXT_req;
	cJSON *item5_req;
	
	cJSON *PLANNINGDATA_req;
	cJSON *PLANNINGDATAX_req;
	
	cJSON *PLANTDATA_req;
	cJSON *PLANTDATAX_req;
	
	cJSON *PRTDATA_req;
	cJSON *item6_req;

	cJSON *PRTDATAX_req;
	cJSON *item7_req;
	
	cJSON *RETURNMESSAGES_req;
	cJSON *item8_req;

	cJSON *SALESDATA_req;
	cJSON *SALESDATAX_req;

	cJSON *STORAGELOCATIONDATA_req;
	cJSON *STORAGELOCATIONDATAX_req;

	cJSON *STORAGETYPEDATA_req;
	cJSON *STORAGETYPEDATAX_req;

	cJSON *TAXCLASSIFICATIONS_req;
	cJSON *item9_req;
	
	cJSON *UNITSOFMEASURE_req;
	cJSON *item10_req;
	
	cJSON *UNITSOFMEASUREX_req;
	cJSON *item11_req;

	cJSON *VALUATIONDATA_req;
	cJSON *VALUATIONDATAX_req;

	cJSON *WAREHOUSENUMBERDATA_req;
	cJSON *WAREHOUSENUMBERDATAX_req;
		
	
	
	char *out;
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	CLIENTDATA_req = cJSON_CreateObject();
	CLIENTDATAX_req = cJSON_CreateObject();
	
	EXTENSIONIN_req = cJSON_CreateObject();
	EXTENSIONINX_req = cJSON_CreateObject();
	item1_req = cJSON_CreateObject();
	item2_req = cJSON_CreateObject();
	
	HEADDATA_req = cJSON_CreateObject();
	
	FORECASTPARAMETERS_req = cJSON_CreateObject();
	FORECASTPARAMETERSX_req = cJSON_CreateObject();
	
	INTERNATIONALARTNOS_req = cJSON_CreateObject();
	item3_req = cJSON_CreateObject();
	
	MATERIALDESCRIPTION_req = cJSON_CreateObject();
	item4_req = cJSON_CreateObject();
	
	MATERIALLONGTEXT_req = cJSON_CreateObject();
	item5_req = cJSON_CreateObject();
	
	PLANNINGDATA_req = cJSON_CreateObject();
	PLANNINGDATAX_req = cJSON_CreateObject();
	
	PLANTDATA_req = cJSON_CreateObject();
	PLANTDATAX_req = cJSON_CreateObject();
	
	PRTDATA_req = cJSON_CreateObject();
	item6_req = cJSON_CreateObject();
	
	PRTDATAX_req = cJSON_CreateObject();
	item7_req = cJSON_CreateObject();
	
	RETURNMESSAGES_req = cJSON_CreateObject();
	item8_req = cJSON_CreateObject();
	
	
	SALESDATA_req = cJSON_CreateObject();
	SALESDATAX_req = cJSON_CreateObject();
	
	STORAGELOCATIONDATA_req = cJSON_CreateObject();
	STORAGELOCATIONDATAX_req = cJSON_CreateObject();
	
	STORAGETYPEDATA_req = cJSON_CreateObject();
	STORAGETYPEDATAX_req = cJSON_CreateObject();
	
	TAXCLASSIFICATIONS_req = cJSON_CreateObject();
	item9_req = cJSON_CreateObject();
	
	UNITSOFMEASURE_req = cJSON_CreateObject();
	item10_req = cJSON_CreateObject();
	
	UNITSOFMEASUREX_req = cJSON_CreateObject();
	item11_req = cJSON_CreateObject();
	
	VALUATIONDATA_req = cJSON_CreateObject();
	VALUATIONDATAX_req = cJSON_CreateObject();
	
	WAREHOUSENUMBERDATA_req = cJSON_CreateObject();
	WAREHOUSENUMBERDATAX_req = cJSON_CreateObject();
	
	
	cJSON_AddItemToObject(rfc_root, "ZBAPI_MATERIAL_SAVEDATA", exp_imp_tab_req);
	cJSON_AddItemToObject(exp_imp_tab_req, "CHANGE_NUMBER", cJSON_CreateString("22CU046216PP"));  //24MM901810JP  CORRCT240625
		
	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATA", CLIENTDATA_req);
	cJSON_AddItemToObject(CLIENTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "OLD_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATA_req, "DOCUMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_TYPE" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATA_req, "DOC_VERS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_FORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGE_NO" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATA_req, "NO_SHEETS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGEFORMAT" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATA_req, "SIZE_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NET_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DIVISION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QTY_GR_GI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CAD_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLOWED_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLWD_VOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WT_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VOL_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "FILL_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STACK_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATA_req, "QM_PROCMNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CATPROFILE" , cJSON_CreateString(""));		
	cJSON_AddItemToObject(CLIENTDATA_req, "MINREMLIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SHELF_LIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_PCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATCMPLLVL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ANP" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATAX", CLIENTDATAX_req);
	cJSON_AddItemToObject(CLIENTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "OLD_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATAX_req, "DOCUMENT" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_TYPE" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_VERS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_FORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGE_NO" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATAX_req, "NO_SHEETS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGEFORMAT" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATAX_req, "SIZE_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NET_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DIVISION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QTY_GR_GI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CAD_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLOWED_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLWD_VOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WT_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VOL_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "FILL_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STACK_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATAX_req, "QM_PROCMNT" , cJSON_CreateString(""));		
    cJSON_AddItemToObject(CLIENTDATAX_req, "CATPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MINREMLIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SHELF_LIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_PCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATCMPLLVL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ANP" , cJSON_CreateString(""));
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_CAD_CALL", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_ONLINE", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "HEADDATA", HEADDATA_req);
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL" , cJSON_CreateString(part_noDup));
	cJSON_AddItemToObject(HEADDATA_req, "IND_SECTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "BASIC_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "SALES_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PURCHASE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MRP_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "FORECAST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "WORK_SCHED_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PRT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "STORAGE_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "WAREHOUSE_VIEW" , cJSON_CreateString(""));
    cJSON_AddItemToObject(HEADDATA_req, "QUALITY_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "ACCOUNT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "COST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "INP_FLD_CHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_VERSION" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALDESCRIPTION", MATERIALDESCRIPTION_req);
	cJSON_AddItemToObject(MATERIALDESCRIPTION_req, "item" , item4_req);
	cJSON_AddItemToObject(item4_req, "LANGU" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "LANGU_ISO" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "MATL_DESC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item4_req, "DEL_FLAG" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATA", PLANTDATA_req);
	cJSON_AddItemToObject(PLANTDATA_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(PLANTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ABC_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRPPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_CTRLER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLND_DELRY" , cJSON_CreateString(""));
    cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(""));		
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ASSY_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOTSIZEKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SPPROCTYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MINLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAXLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FIXED_LOT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_VAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORD_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEP_REQ_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ALT_BOM_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "GRP_REQMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIXED_MRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SM_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUPTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INTEROP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INHSEPRODT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGEPERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNDER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLENTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLACE_PT" , cJSON_CreateString(""));
    cJSON_AddItemToObject(PLANTDATA_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DOC_REQD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QUOTAUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SERV_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SPLIT_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAILCHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUP_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY_PLAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SHIP_PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROFIT_CTR" , cJSON_CreateString(MMSCSLocDup));
	cJSON_AddItemToObject(PLANTDATA_req, "PPC_PL_CAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REP_MANUF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPMANPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PL_TI_FNCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISS_ST_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMP_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CERT_TYPE" , cJSON_CreateString(""));		
	cJSON_AddItemToObject(PLANTDATA_req, "CYCLE_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "VARIANCE_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SERNO_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MULT_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INSP_INT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLAN_STRGP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SLOC_EXPRC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BULK_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DETERM_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUR_STATUS" , cJSON_CreateString(" "));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETYTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEPLOY_HORIZ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FIX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_INCREMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_SAFETY_STK" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATAX", PLANTDATAX_req);
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ABC_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRPPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_CTRLER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLND_DELRY" , cJSON_CreateString(""));
    cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ASSY_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOTSIZEKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPPROCTYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MINLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAXLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIXED_LOT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_VAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORD_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEP_REQ_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALT_BOM_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "GRP_REQMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIXED_MRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SM_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUPTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INTEROP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INHSEPRODT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGEPERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNDER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLENTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLACE_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_KEY" , cJSON_CreateString(""));
    cJSON_AddItemToObject(PLANTDATAX_req, "DOC_REQD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QUOTAUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERV_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPLIT_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAILCHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUP_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY_PLAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SHIP_PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROFIT_CTR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "PPC_PL_CAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REP_MANUF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PL_TI_FNCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISS_ST_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMP_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CERT_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CYCLE_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "VARIANCE_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERNO_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPMANPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MULT_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INSP_INT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLAN_STRGP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SLOC_EXPRC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BULK_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DETERM_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
    cJSON_AddItemToObject(PLANTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETYTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEPLOY_HORIZ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_INCREMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "RETURNMESSAGES", RETURNMESSAGES_req);
	cJSON_AddItemToObject(RETURNMESSAGES_req, "item", item8_req);
	cJSON_AddItemToObject(item8_req, "TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "NUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_MSG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "PARAMETER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ROW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "FIELD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "SYSTEM" , cJSON_CreateString(""));
	
	/* 
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATA" , STORAGELOCATIONDATA_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "INV_CORR_FAC" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATAX" , STORAGELOCATIONDATAX_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "INV_CORR_FAC" , cJSON_CreateString("")); */
	
	/*cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASURE" , UNITSOFMEASURE_req);
	cJSON_AddItemToObject(UNITSOFMEASURE_req, "item" , item10_req);
	cJSON_AddItemToObject(item10_req, "ALT_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "ALT_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "NUMERATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "DENOMINATR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "GROSS_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString(""));

	
	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASUREX" , UNITSOFMEASUREX_req);
	cJSON_AddItemToObject(UNITSOFMEASUREX_req, "item" , item11_req);
	cJSON_AddItemToObject(item11_req, "ALT_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "ALT_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "NUMERATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "DENOMINATR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "GROSS_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString("")); */
	
	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATA" , VALUATIONDATA_req);
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_AREA" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOVING_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CLASS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "FUTURE_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLND_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEVAL_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "OVERHEAD_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "QTY_STRUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MAT_ORIGIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAX_CML_UN" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATAX" , VALUATIONDATAX_req);
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_AREA" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOVING_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CLASS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "FUTURE_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLND_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEVAL_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "OVERHEAD_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "QTY_STRUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MAT_ORIGIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAX_CML_UN" , cJSON_CreateString(""));
	    
		
	out = cJSON_Print(rfc_root);
	tc_strcpy(json_profit_center_update_req_obj,out);
	printf("%s\n", out);
	free(out);
	cJSON_Delete(rfc_root);

	return 0;
}


int getClsValueFrmICSTag_pm( tag_t  IcsClsTag_pm , char *clsKeyAtrrId_pm,char **AttrVal)
{
	tag_t objTypeTag_pm=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	//char   Ptype_name_pm[TCTYPE_name_size_c+1];
	char   *Ptype_name_pm	=	NULL;
	char   Stype_name[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	tag_t *ClsObjTag = NULLTAG;
	tag_t*    status_list;
	
	

	if(TCTYPE_ask_object_type(IcsClsTag_pm,&objTypeTag_pm));
	//if(TCTYPE_ask_name(objTypeTag_pm,Ptype_name_pm));
	if(TCTYPE_ask_name2(objTypeTag_pm,&Ptype_name_pm)); // TC 14.3 Upgrade

	
	if(IcsClsTag_pm!=NULLTAG)
	{
		    char * 	theClassId = NULL;
			int  	theAttributeCount;
			int * 	theAttributeIds;
			int * 	theAttributeValCounts;
			char ** 	theAttributeValues;
			tag_t 	theICOTag=NULLTAG;
			printf("\n  input clsKeyAtrrId[%s]",clsKeyAtrrId_pm); fflush(stdout);
			//char keyPrefix[10];
			//tc_strcpy(keyPrefix,"-");
			//tc_strcat(keyPrefix,clsKeyAtrrId);
			int intid2 = 0;
			char * 	unctName = NULL;
		    char *	shortName = NULL;
		    char * 	unctUnit = NULL;
		    int  unctFormat = 0;
			intid2=atoi(clsKeyAtrrId_pm);
			printf("\n  input intid2[%d]",intid2); fflush(stdout);
	 
			printf("\n  111"); fflush(stdout);
			ITKCALL(ICS_describe_unct(intid2,&unctName,&shortName,&unctUnit,&unctFormat));
			printf("\n  222 ifail[%d]",ifail); fflush(stdout);
			if(ifail != ITK_ok)
			{
				printf("\n FAIL:  intid2[%d] unctName[%s] shortName[%s] unctUnit[%s] unctFormat[%d]",intid2,unctName,shortName,unctUnit,unctFormat); fflush(stdout);						
				return ifail;	
			}
			
			printf("\n SUCCESS:  intid2[%d] unctName[%s] shortName[%s] unctUnit[%s] unctFormat[%d]",intid2,unctName,shortName,unctUnit,unctFormat); fflush(stdout);
			//printf("\n  input keyPrefix[%s]",keyPrefix); fflush(stdout);
			//const char * 	key_lov_id=keyPrefix; //cls attr id for ChassisTypeNo_TYP_APPRVL_NO
			char theKeyLOVId[10];
			const char * 	key_lov_id;
			if(unctFormat)
			{

				sprintf(theKeyLOVId, "%d", unctFormat);
				key_lov_id=theKeyLOVId;	
			}
			char * 	key_lov_name;
			int  	options;
			int t = 0;
			int keyfound=0;
			int  	n_lov_entries;
			char ** 	lov_keys;
			char ** 	lov_values;
			logical * 	deprecated_staus;
			char * 	owning_site;
			char *keyLovOfCCVNo=(char*) MEM_alloc( 1 * sizeof(lov_keys) );
			int  	n_shared_sites;
			char ** 	shared_sites;
			theICOTag=IcsClsTag_pm;
			ITKCALL(ICS_ask_attribute_value(theICOTag,clsKeyAtrrId_pm,&AttrKeyValue));
			
			printf("\n AttrKeyValue: [%s]  key_lov_id: [%s]",AttrKeyValue,key_lov_id); fflush(stdout);
			
			if(AttrKeyValue)
			{
				*AttrVal = AttrKeyValue;
			
			    if(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			    //CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			    printf("\n key_lov_name: [%s] n_lov_entries: [%d] options: [%d]",key_lov_name,n_lov_entries,options); fflush(stdout);
 				for(t=0;t<n_lov_entries;t++)								
				{
					//printf("\n lov_keys: [%s] lov_values: [%s]",lov_keys[t],lov_values[t]);fflush(stdout);
					
					//if(tc_strcasecmp(AttrKeyValue,lov_keys[t])==0)
					if(tc_strstr(lov_keys[t],AttrKeyValue) != NULL)
					{
						printf("\n AttrKeyValue: [%s]",AttrKeyValue);fflush(stdout);
						printf("\n Mascot lov_keys: [%s] lov_values: [%s]",lov_keys[t],lov_values[t]);fflush(stdout);
						printf("\n lov_keys: [%s] lov_values: [%s]",lov_keys[t],lov_values[t]);fflush(stdout);
						
						if(lov_values[t])
						{
							tc_strdup(lov_values[t],&RetAttrVal);
						}
						*AttrVal=RetAttrVal;
						printf("\n Before Break RetAttrVal: [%s]",RetAttrVal);fflush(stdout);
						break;
					}	
				} 
			}
			else
			{
				*AttrVal="";
				return ITK_ok;
			}
	}
    printf("\n @@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);	
	printf("\n RetAttrVal: [%s]",RetAttrVal);fflush(stdout);
	printf("\n @@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);	
			
	return ITK_ok;
}

int TC_VCClassification_Details(char* partno,char* rev,char* seq,char* type,char* plant,char* server)
{
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int s = 0;
	tag_t VCRev_tag = NULLTAG;
	char *item_revseq = (char *) malloc(20*sizeof(char));
	int ChldCount = 0;
    tag_t *PartChildTags = NULLTAG;
	tag_t Veh_tag = NULLTAG;
	char *vehno_str = NULL;
	char *vehno_strDup = NULL;
	int z = 0;
	tag_t vehtItemobj = NULLTAG;
	int vehn_entries = 4;
	int vehn_itemobj_found = 0;
	tag_t* vehtitemobj_results = NULLTAG;
	int y = 0;
	tag_t VehRev_tag = NULLTAG;
	int iFail = ITK_ok;
	char *prodlineval = NULL;
	prodlineval = (char *) malloc(100*sizeof(char));
	char *platformval = NULL;
	platformval = (char *) malloc(100*sizeof(char));
	char *segmentval = NULL;
	segmentval = (char *) malloc(100*sizeof(char));
	char *variantval = NULL;
	variantval = (char *) malloc(100*sizeof(char));
	
	if(prodlineval!=NULL)trimwhitespace(prodlineval);
	if(platformval!=NULL)trimwhitespace(platformval);
	if(segmentval!=NULL)trimwhitespace(segmentval);
	if(variantval!=NULL)trimwhitespace(variantval);
	char *vcctnpc = NULL;
	
	tc_strcpy(item_revseq,rev);
	tc_strcat(item_revseq,"*");
	tc_strcat(item_revseq,seq);
	printf(" Final: Part_Rev_Seq Value(item_revseq): [%s]\n",item_revseq);
	
	printf("\n Finding Query[DesignRevision Sequence]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
    if(tItemobj != NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully..!!\n");fflush(stdout);
		char *cEntries[2]  = {"Revision","ID"};
		char *cValues[2]  = {item_revseq,partno};
		//char *cValues[2]  = {"A*2","51780353000R"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf(" Queried Design Revision & Sequence Found..!!\n");fflush(stdout);
			for(s = 0; s < n_itemobj_found; s++)
			{
				VCRev_tag = titemobj_results[s];
				ITK_CALL(AOM_ask_value_tags(VCRev_tag,"ps_children",&ChldCount,&PartChildTags));
				if(ChldCount>0)
				{
					for(z = 0; z < ChldCount; z++)
			        {
						Veh_tag = PartChildTags[z];
						ITK_CALL(AOM_ask_value_string(PartChildTags[z],"item_id",&vehno_str));
						if(tc_strlen(vehno_str)>0)
						{
							tc_strdup(vehno_str,&vehno_strDup);
							ITK_CALL(QRY_find2("MCC_ERC_Released_Latest_Revision",&vehtItemobj));
							if(vehtItemobj != NULLTAG)
							{
								printf("\n Query [MCC_ERC_Released_Latest_Revision] Found Successfully..!!\n");fflush(stdout);
								char *vehEntries[4]  = {"Item ID","Release Status","Part Type","Type"};
								char *vehValues[4]  = {vehno_strDup,"T5_LcsErcRlzd","V","Design Revision"};
								ITK_CALL(QRY_execute(vehtItemobj, vehn_entries, vehEntries, vehValues, &vehn_itemobj_found, &vehtitemobj_results));
								printf("\n -----------------------------------------------\n");fflush(stdout);
								printf("\n No of Revision Found: [%d]\n",vehn_itemobj_found);fflush(stdout);
								printf("\n -----------------------------------------------\n");fflush(stdout);
								if(vehn_itemobj_found > 0)
								{
									printf("\n Query [MCC_ERC_Released_Latest_Revision] Found..!!\n");fflush(stdout);
									for (y = 0; y < vehn_itemobj_found; y++)
									{
										VehRev_tag = vehtitemobj_results[y];
										printf("\n Function2: Classification Attribute Find Start");fflush(stdout);
										tag_t Vc_spec_relation_type = NULLTAG;
										int vcspec_count_f = 0;
										tag_t* Vc_specObjects_f = NULLTAG;
										char *vcspec_item_id_f = NULL;
										char *vcclass_f = NULL;
										tag_t VehMstrTag = NULLTAG;
										int cnt	= 0;
										tag_t *ClsObjTag_results = NULLTAG;
										tag_t ClsObj_f = NULLTAG;
									
										ITK_CALL(GRM_find_relation_type("T5_VCSpec",&Vc_spec_relation_type));
										if(Vc_spec_relation_type != NULLTAG)
										{
											ITK_CALL(GRM_list_secondary_objects_only(VehRev_tag, Vc_spec_relation_type, &vcspec_count_f, &Vc_specObjects_f));
											printf("\n ----------------------------------------------");fflush(stdout);
											printf("\n Total Tech_Spech Attached with Vehicle: [%d]",vcspec_count_f);fflush(stdout);
											printf("\n ----------------------------------------------\n");fflush(stdout);
											if(vcspec_count_f > 0)
											{
												ITK_CALL(AOM_ask_value_string(Vc_specObjects_f[0],"item_id",&vcspec_item_id_f));
												printf("\n Tech_Spech No: [%s]\n",vcspec_item_id_f);fflush(stdout);
																						
												ITK_CALL(AOM_ask_value_string(Vc_specObjects_f[0],"t5_VCClassName",&vcclass_f));
												printf("\n Vehicle Class: [%s]",vcclass_f);fflush(stdout);
												
												if(tc_strlen(vcclass_f) > 0)
												{
													char *geproductlineval_id = NULL;
													geproductlineval_id = (char *) malloc(100*sizeof(char));
													char *getplatformval_id = NULL;
													getplatformval_id = (char *) malloc(100*sizeof(char));
													char *getsegmentval_id = NULL;
													getsegmentval_id = (char *) malloc(100*sizeof(char));
													char *getvariantval_id = NULL;
													getvariantval_id = (char *) malloc(100*sizeof(char));
													
													if(tc_strcmp(vcclass_f,"MCV")==0)
													{
														printf("\n Attribute_ID Start: [MCV] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
														
														printf("\n geproductlineval_id_MCV: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_MCV: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_MCV: [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_MCV: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [MCV] \n");fflush(stdout);
													}
													else if(tc_strcmp(vcclass_f,"HCV")==0)
													{
														printf("\n Attribute_ID Start: [HCV] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
														
														printf("\n geproductlineval_id_HCV: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_HCV: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_HCV: [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_HCV: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [HCV] \n");fflush(stdout);
													}
													else if(tc_strcmp(vcclass_f,"LCV")==0)
													{
														printf("\n Attribute_ID Start: [LCV] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
														
														printf("\n geproductlineval_id_LCV: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_LCV: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_LCV: [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_LCV: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [LCV] \n");fflush(stdout);
													}
													else if(tc_strcmp(vcclass_f,"LMV")==0)
													{
														printf("\n Attribute_ID Start: [LMV] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
													
														printf("\n geproductlineval_id_LMV: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_LMV: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_LMV: [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_LMV: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [LMV] \n");fflush(stdout);
													}
													else if(tc_strcmp(vcclass_f,"BUS")==0)
													{
														printf("\n Attribute_ID Start: [BUS] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
														
														printf("\n geproductlineval_id_BUS: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_BUS: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_BUS: [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_BUS: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [BUS] \n");fflush(stdout);
													}
													else if(tc_strcmp(vcclass_f,"UV_VAN")==0)
													{
														printf("\n Attribute_ID Start: [UV_VAN] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
														
														printf("\n geproductlineval_id_UV_VAN: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_UV_VAN: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_UV_VAN: [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_UV_VAN: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [UV_VAN] \n");fflush(stdout);
													}
													else if(tc_strcmp(vcclass_f,"ICV")==0)
													{
														printf("\n Attribute_ID Start: [ICV] \n");fflush(stdout);
														tc_strcpy(geproductlineval_id,"6240");
														tc_strcpy(getplatformval_id,"6241");
														tc_strcpy(getsegmentval_id,"6242");
														tc_strcpy(getvariantval_id,"6243");
														
														printf("\n geproductlineval_id_ICV: [%s]",geproductlineval_id);fflush(stdout);
														printf("\n getplatformval_id_ICV: [%s]",getplatformval_id);fflush(stdout);
														printf("\n getsegmentval_id_ICV [%s]",getsegmentval_id);fflush(stdout);
														printf("\n getvariantval_id_ICV: [%s]",getvariantval_id);fflush(stdout);
														printf("\n Attribute_ID End: [ICV] \n");fflush(stdout);
													}
													else
													{
														printf("\n VC Class Not Matched..!! \n");fflush(stdout);
													}
													
													ITK_CALL(ITEM_ask_item_of_rev(VehRev_tag,&VehMstrTag));
													ITK_CALL(AOM_ask_value_tags(VehMstrTag,"IMAN_classification",&cnt,&ClsObjTag_results));
													printf("\n Vehicle Master Object Count: [%d]\n", cnt); fflush(stdout);
													if(cnt > 0)
													{
														ClsObj_f=*ClsObjTag_results;	
														ITK_CALL(getClsValueFrmICSTag_pm(ClsObj_f,geproductlineval_id,&prodlineval));
														ITK_CALL(getClsValueFrmICSTag_pm(ClsObj_f,getplatformval_id,&platformval));
														ITK_CALL(getClsValueFrmICSTag_pm(ClsObj_f,getsegmentval_id,&segmentval));
														ITK_CALL(getClsValueFrmICSTag_pm(ClsObj_f,getvariantval_id,&variantval));
														
														if(prodlineval!=NULL)trimwhitespace(prodlineval);
														if(platformval!=NULL)trimwhitespace(platformval);
														if(segmentval!=NULL)trimwhitespace(segmentval);
														if(variantval!=NULL)trimwhitespace(variantval);	
														
														printf("\n PRODUCTLINE : [%s]",prodlineval); fflush(stdout);
														printf("\n PLATFORM : [%s]",platformval); fflush(stdout);
														printf("\n SEGMENT : [%s]",segmentval); fflush(stdout);
														printf("\n VARIANT : [%s]",variantval); fflush(stdout);
													}
													else
													{
														printf("\n VC Master Not Found..!! \n");fflush(stdout);
														tc_strcpy(prodlineval,"");
														tc_strcpy(platformval,"");
														tc_strcpy(segmentval,"");
														tc_strcpy(variantval,"");
													}				
												}
												else
												{
													printf("\n VC Class Not Found..!! \n");fflush(stdout);
													tc_strcpy(prodlineval,"");
													tc_strcpy(platformval,"");
													tc_strcpy(segmentval,"");
													tc_strcpy(variantval,"");
												}
											}
											else
											{
												printf("\n No Tech_Spech Attached with Vehicle..!! \n");fflush(stdout);
												tc_strcpy(prodlineval,"");
												tc_strcpy(platformval,"");
												tc_strcpy(segmentval,"");
												tc_strcpy(variantval,"");
											}
										}
										printf("\n Function3: Classification Attribute Find End");fflush(stdout);
									}
								}
								else
								{
								   printf("\n Veh_No Value is NULL..!!");fflush(stdout);
								}
							}
						}
						else
						{
							tc_strdup("",&vehno_strDup);
							printf("\n Veh Master Value is NULL..!!");fflush(stdout);
						}
					}
				}
				else
				{
					printf(" VC To Vehicle Not Found..!!\n");fflush(stdout);
				}

			}
		}
	}
	
	if((tc_strlen(prodlineval)>0) && (tc_strlen(platformval)>0))
	{
		tag_t ctltItemobj = NULLTAG;
		int ctln_entries = 4;
		int newctln_entries = 3;
		int ctln_itemobj_found = 0;
		tag_t* ctltitemobj_results = NULLTAG;
		int v = 0;
		tag_t CtlRev_tag = NULLTAG;
		vcprofit_centre_sap = (char *)malloc(100 * sizeof(char));
		
		if(((tc_strcmp(prodlineval,"Passenger")==0) || (tc_strcmp(prodlineval,"SCV PU")==0)) && ((tc_strcmp(platformval,"Busses")==0) || (tc_strcmp(platformval,"PU Small")==0) || (tc_strcmp(platformval,"Vans")==0)))
		{
			printf(" Product_Line and Platform Value is Not Null..!!\n");fflush(stdout);
			printf("\n Finding Query[Control Objects...]!!\n");fflush(stdout);
			ITK_CALL(QRY_find2("Control Objects...",&ctltItemobj));
			if(ctltItemobj != NULLTAG)
			{
				printf("\n [Control Objects...] Query Found Successfully..!!\n");fflush(stdout);
				char *ctlEntries[4]  = {"SYSCD","Information-1","Information-2","Information-3"};
				char *ctlValues[4]  = {"S4HANAPLANTDATAVC",prodlineval,platformval,segmentval};
				//char *ctlValues[4]  = {"S4HANAPLANTDATAVC","Passenger","Buses","ICV Buses"};
				ITK_CALL(QRY_execute(ctltItemobj, ctln_entries, ctlEntries, ctlValues, &ctln_itemobj_found, &ctltitemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n  No of Revision Found: [%d]\n",ctln_itemobj_found);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				if(ctln_itemobj_found > 0)
				{
					printf(" Queried Control Object Found..!!\n");fflush(stdout);
					printf(" Queried Design Revision & Sequence Found..!!\n");fflush(stdout);
					for(v = 0; v < ctln_itemobj_found; v++)
					{
						CtlRev_tag = ctltitemobj_results[v];
						ITK_CALL(AOM_ask_value_string(ctltitemobj_results[v],"t5_SubSyscd",&vcctnpc));
						printf("\n Control Table Profit Center: [%s]\n",vcctnpc);fflush(stdout);
						tc_strcpy(vcprofit_centre_sap,"0000");
						tc_strcat(vcprofit_centre_sap,vcctnpc);
					}
				}
			}
		}
		else
		{
			printf(" Product_Line and Platform Value is Not Null..!!\n");fflush(stdout);
			printf("\n Finding Query[Control Objects...]!!\n");fflush(stdout);
			ITK_CALL(QRY_find2("Control Objects...",&ctltItemobj));
			if(ctltItemobj != NULLTAG)
			{
				printf("\n [Control Objects...] Query Found Successfully..!!\n");fflush(stdout);
				char *ctlEntries[3]  = {"SYSCD","Information-1","Information-2"};
				char *ctlValues[3]  = {"S4HANAPLANTDATAVC",prodlineval,platformval};
				//char *ctlValues[3]  = {"S4HANAPLANTDATAVC","Passenger","Buses"};
				ITK_CALL(QRY_execute(ctltItemobj, newctln_entries, ctlEntries, ctlValues, &ctln_itemobj_found, &ctltitemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n  No of Revision Found: [%d]\n",ctln_itemobj_found);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				if(ctln_itemobj_found > 0)
				{
					printf(" Queried Control Object Found..!!\n");fflush(stdout);
					printf(" Queried Design Revision & Sequence Found..!!\n");fflush(stdout);
					for(v = 0; v < ctln_itemobj_found; v++)
					{
						CtlRev_tag = ctltitemobj_results[v];
						ITK_CALL(AOM_ask_value_string(ctltitemobj_results[v],"t5_SubSyscd",&vcctnpc));
						printf("\n Control Table Profit Center: [%s]\n",vcctnpc);fflush(stdout);
						tc_strcpy(vcprofit_centre_sap,"0000");
						tc_strcat(vcprofit_centre_sap,vcctnpc);
					}
				}
			}
		}
		if(tc_strlen(vcprofit_centre_sap)>0)
		{
		    printf("\n Function1: Profit Center Value Updation Start\n");fflush(stdout);
		    char *json_profit_center_update_req_obj = NULL;
			json_profit_center_update_req_obj = malloc(34000);
			
			cll_VC_Profit_Center_Update(partno, plant, vcprofit_centre_sap, json_profit_center_update_req_obj);
			printf("\n Request String : [%s]\n", json_profit_center_update_req_obj);
			tm_curl_profit_center_update( json_profit_center_update_req_obj );
			
			free(json_profit_center_update_req_obj);
	        printf("\n Function1: Profit Center Value Updation End\n");fflush(stdout);
		}
		else
		{
			printf("\n !!!!!!!!!!! Profit Center Value Not Found For VC not Found !!!!!!!!!!!\n");fflush(stdout);
		}
	}

	return iFail;	
}


extern int ITK_user_main(int argc, char ** argv )
{
    int status;
	int kk=0;
	int is=0;
	int sflag=0;
	int i=0;
	int doccount=0;
	int len=0;
	int Refcount=0;
	int resultCount =0;
	int n_entries = 2;
	int n_tags_found = 1;
	int num_to_sort = 1;
	int sort_order[1]  ={2};
	char *keysAttr[1] = {"creation_date"};

	tag_t queryTag = NULLTAG;
	tag_t docOPtr = NULLTAG;
	tag_t *outTag = NULLTAG;
	tag_t resultOutputTag = NULLTAG;
	tag_t LatestRev=NULLTAG;
    tag_t docRelObjs=NULLTAG;
    tag_t *docObjs=NULLTAG;
    tag_t *refdocObjs=NULLTAG;
    tag_t doctag=NULLTAG;
    tag_t docRelObj=NULLTAG;
    tag_t refdocRelObj=NULLTAG;
	tag_t		*DesignTags			= NULLTAG;
	tag_t		PartMasterTag		= NULLTAG;

	char* sUserName	= NULL;
	char* sPassword = NULL;
	char *LatRevName=NULL;
	char *part_type=NULL;
	char *unit=NULL;
	char *part_typeDup=NULL;
	char *unitDup=NULL;
	char *doc_no=NULL;
	char *PrtRev=NULL;
	char* PartRelStatus = NULL;
	char *Lcs = NULL;
	char *SapServer = NULL;

	//static RFC_RC RfcRc;
	const char *attrs[2];
	const char *values[2];

    plantcode=(char *) malloc (500 * sizeof(char));
	profit_centre2 = (char *)malloc(500 * sizeof(char));
	plan_calendar2 = (char *)malloc(500 * sizeof(char));
	overhd_grp2 = (char *)malloc(500 * sizeof(char));
	origin_group2 = (char *)malloc(500 * sizeof(char));
	origin_group = (char *)malloc(500 * sizeof(char));
	mat_type=(char *) malloc(500 * sizeof(char));
	meas_unit=(char *) malloc(500 * sizeof(char));

	tmpDrwNum = (char *)malloc(500 * sizeof(char));
	tmpDrwNum1 = (char *)malloc(500 * sizeof(char));
	tmpDrwRev = (char *)malloc(500 * sizeof(char));
	tmpDrwSeq = (char *)malloc(500 * sizeof(char));

	sap_proc_type = (char *)malloc(500 * sizeof(char));
	sap_spproc_type = (char *)malloc(500 * sizeof(char));
	SAPpstat = (char *)malloc(500 * sizeof(char));
	MRPpstat = (char *)malloc(500 * sizeof(char));
	myzeroDup1 = (char *)malloc(500 * sizeof(char));
	myzeroDup2 = (char *)malloc(500 * sizeof(char));
	myzeroDup3 = (char *)malloc(500 * sizeof(char));
	myzeroDup4 = (char *)malloc(500 * sizeof(char));
	std_price = (char *)malloc(500 * sizeof(char));
	moving_avg_price = (char *)malloc(500 * sizeof(char));
	cost_lot_size = (char *)malloc(500 * sizeof(char));
	mat_type = (char *)malloc(500 * sizeof(char));
	descDup = (char *)malloc(500 * sizeof(char));
	reord_pt = (char *)malloc(500 * sizeof(char));
	profit_centre_sap = (char *)malloc(500 * sizeof(char));
	part_noDupDes = (char *)malloc(500 * sizeof(char));
	part_noDupDesx = (char *)malloc(500 * sizeof(char));


	//char *qry_entries[1] = {"Name"};
	char *qry_entries[] = {"Item ID","Release Status"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	printf("\n ........111111.........."); fflush(stdout);

	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	
	PartNumber = ITK_ask_cli_argument("-part=");
	PartRev = ITK_ask_cli_argument("-rev=");
	PartSeq = ITK_ask_cli_argument("-seq=");
	Parttype = ITK_ask_cli_argument("-type=");
	plantcode = ITK_ask_cli_argument("-plant=");
	iSapServer = ITK_ask_cli_argument("-serv=");
	
	printf(" [1]: Input PartNumber(PartNumber): [%s]\n",PartNumber);
	printf(" [2]: Input PartRev(PartRev): [%s]\n",PartRev);
	printf(" [3]: Input PartSeq(PartSeq): [%s]\n",PartSeq);
	printf(" [4]: Input Parttype(Parttype): [%s]\n",Parttype);
	printf(" [5]: Input Plantcode(plantcode): [%s]\n",plantcode);
	printf(" [6]: Input SAPServer(iSapServer): [%s]\n",iSapServer);
	
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	fpPart_List = fopen("PartList.txt","r");
	
	if((PartNumber != NULL) && (PartRev != NULL) && (PartSeq != NULL) && (Parttype != NULL) && (plantcode != NULL) && (iSapServer != NULL) && (tc_strcmp(Parttype,"VC") == 0))
	{
		printf(" Input Argument Not Null..!!\n");fflush(stdout);
		printf("\n Function1: VC To Vehicle Classification Details Find Start\n");fflush(stdout);
		TC_VCClassification_Details(PartNumber,PartRev,PartSeq,Parttype,plantcode,iSapServer);
	    printf("\n Function1: VC To Vehicle Classification Details Find End\n");fflush(stdout);
	}
	else
	{
	   printf(" Sorry! Input Argument is Wrong. Try with Correct Input Argument..!!\n");fflush(stdout);
	}

	CLEANUP:
	ITK_CALL(POM_logout(false));
	printf("\nCLEANUP..."); fflush(stdout);
}
