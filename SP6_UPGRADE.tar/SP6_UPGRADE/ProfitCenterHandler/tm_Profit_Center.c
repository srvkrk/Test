/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: tm_Profit_Center.c
**
**
**	Date				   Author			        Modification
**	18-09-2025			Sourav Karak	    Profit Center Logic Implementation
* 
* SrNo		Modified By		   Date			     Modification
*	1		Sourav Karak 	18-Sep-2025		Profit Center Logic Implementation

***********************************************************************************************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/signoff.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <pom/pom/pom.h>
#include <tccore/project.h>
#include <sa/groupmember.h>
#include <user_exits/epm_toolkit_utils.h>
#include <cJSON.h>
#include <curl/curl.h>
#define PS_where_used_all_levels   -1 
#define T5_WorkFlowHandlerErr (EMH_USER_error_base + 701)

int status =0;
char *p;
char *inputPart = NULL;
char *part_noDup = NULL;
char *iPlantCode = NULL;
char *plantcode = NULL;
char *iSapServer = NULL;
char *changeno = NULL;

void getTodayDate(char* StdDate);
int DATE_date_to_string (date_t date_struct, const char *format_str, char **date_str);
int EPM__parse_string (const char *pszInputString, char *pszSeparator, int *piStringCount, char ***pppStringList);

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
**
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst ); 
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

void getTodayDate(char* StdDate)
{
	struct tm *Sys_T = NULL;
	int Month;
	int Day;
	int Year;
	int hour;
	int min;
	int sec;

	time_t Tval = 0;
	Tval = time(NULL);
	Sys_T = localtime(&Tval);
	Day=Sys_T->tm_mday;
	Month=Sys_T->tm_mon+1;
	Year=1900 + Sys_T->tm_year;
	hour = Sys_T->tm_hour;
	min = Sys_T->tm_min;
	sec = Sys_T->tm_sec;

	sprintf(StdDate,"%02d%02d%02d",Month,Day,Year);
	printf("\nDate:[%s]",StdDate); fflush(stdout);
}

void getCurrentDateTime(char cCurrentAccessDate[20])
{
	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char    DateS[4];
	printf("getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("cCurrentAccessDate:%s\n",cCurrentAccessDate);

	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

struct memory {
  char *response;
  size_t size;
};

static size_t WriteCallback(char *data, size_t size, size_t nmemb, void *clientp)
{
  size_t realsize = size * nmemb;
  struct memory *mem = (struct memory *)clientp;
 
  char *ptr = realloc(mem->response, mem->size + realsize + 1);
  if(!ptr)
    return 0;  /* out of memory */
 
  mem->response = ptr;
  memcpy(&(mem->response[mem->size]), data, realsize);
  mem->size += realsize;
  mem->response[mem->size] = 0;
  
  printf("\n WriteCallback done"); fflush(stdout);
 
  return realsize;
}

int parse_json_object(const char *json_string,char *ParseType) 
{
    int i = 0;
	cJSON *json = cJSON_Parse(json_string);
	if (json == NULL) 
	{ 
        const char *error_ptr = cJSON_GetErrorPtr(); 
        if (error_ptr != NULL) 
		{ 
            printf("Error: [%s]\n", error_ptr); 
        } 
        cJSON_Delete(json); 
        return 1; 
    } 
	printf("\njson_string: [%s]\n\n",json_string); //to see complete response
	printf("\ncJSON_GetArraySize(json): [%d]\n\n",cJSON_GetArraySize(json));
	
	printf ("\nParseType: [%s]",ParseType);
	if ( tc_strcmp ( ParseType, "INSP_CREATE" ) == 0 )
	{
		const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZRFC_INSPTYPE_ALLOCResponse");
		const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "MESSG");
			
		for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
		{
			char *tm_Message = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
			printf("\n @@@@@@@@@@@@ INSPECTION ALLOCATION STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			printf("\n INSPTYPE_ALLOC_Message: [%s]\n", tm_Message);fflush(stdout);
			printf("\n SAP Msg for Material Inspection Allocation: [%s]\n", tm_Message);fflush(stdout);
			printf("\n @@@@@@@@@@@@ INSPECTION ALLOCATION STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
		}
	}
	else if ( tc_strcmp ( ParseType, "ARPBPCZI_REMOVE" ) == 0 )
	{
		printf("\njson_string : [%s]\n\n",json_string);
		if( tc_strstr(json_string ,"ZBAPI_MATERIAL_SAVEDATAResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZBAPI_MATERIAL_SAVEDATAResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "RETURN");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_matcrexmsg = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
				printf("\n @@@@@@@@@@@@ MATERIAL CREATE/EXTEND STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			    printf("\n SAP Msg for Material Create/Extend: [%s]\n", tm_matcrexmsg);fflush(stdout);
				printf("\n @@@@@@@@@@@@ MATERIAL CREATE/EXTEND STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			}
		}
	}
	else
	{
	  printf("\n ~~~~~~~~~ ParseType Not Matched ~~~~~~~~~~~\n");fflush(stdout);
	}
			
	return 0;
}

void print_json_object(const char *json_string)
{
    cJSON *json = cJSON_Parse(json_string);
    char *formatted_json = cJSON_Print(json);
    printf("%s\n", formatted_json);
    cJSON_Delete(json);
    free(formatted_json);
}

int tm_curl_arpbpczi_remove ( char *data )
{
	struct memory chunk = {0};
	char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\n Failed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	if ( tc_strcmp ( iSapServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV"); //Change or Create in Development
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234"); //with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV_QA"); //Change or Create in Quality
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234"); //with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV"); //Change or Create in Production
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234"); //with credential
	}
	else
	{
		printf("\n iSapServer is Blank..!!");fflush(stdout);
	}
	
	list = curl_slist_append(list, "Content-Type: application/json");
    
	printf("\nFile request content as below "); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
	printf("\ncurl_easy_setopt"); fflush(stdout);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	printf("\ncurl_easy_perform");fflush(stdout);
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "ARPBPCZI_REMOVE");
	
	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
	printf("\nfree"); fflush(stdout);
	
	curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}

int cll_arpbpczi_remove(char *part_noDup, char *plantcode, char *changeno, char *json_arpbpczi_remove_req_obj)
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *CLIENTDATA_req;
	cJSON *CLIENTDATAX_req;
	cJSON *EXTENSIONIN_req;
	cJSON *EXTENSIONINX_req;
	cJSON *item1_req;
	cJSON *item2_req;
	
	
	cJSON *FORECASTPARAMETERS_req;
	cJSON *FORECASTPARAMETERSX_req;
	
	cJSON *HEADDATA_req;
	
	cJSON *INTERNATIONALARTNOS_req;
	cJSON *item3_req;
	
	cJSON *MATERIALDESCRIPTION_req;
	cJSON *item4_req;
	
	
	cJSON *MATERIALLONGTEXT_req;
	cJSON *item5_req;
	
	cJSON *PLANNINGDATA_req;
	cJSON *PLANNINGDATAX_req;
	
	cJSON *PLANTDATA_req;
	cJSON *PLANTDATAX_req;
	
	cJSON *PRTDATA_req;
	cJSON *item6_req;

	cJSON *PRTDATAX_req;
	cJSON *item7_req;
	
	cJSON *RETURNMESSAGES_req;
	cJSON *item8_req;

	cJSON *SALESDATA_req;
	cJSON *SALESDATAX_req;

	cJSON *STORAGELOCATIONDATA_req;
	cJSON *STORAGELOCATIONDATAX_req;

	cJSON *STORAGETYPEDATA_req;
	cJSON *STORAGETYPEDATAX_req;

	cJSON *TAXCLASSIFICATIONS_req;
	cJSON *item9_req;
	
	cJSON *UNITSOFMEASURE_req;
	cJSON *item10_req;
	
	cJSON *UNITSOFMEASUREX_req;
	cJSON *item11_req;

	cJSON *VALUATIONDATA_req;
	cJSON *VALUATIONDATAX_req;

	cJSON *WAREHOUSENUMBERDATA_req;
	cJSON *WAREHOUSENUMBERDATAX_req;
		
	
	
	char *out;
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	CLIENTDATA_req = cJSON_CreateObject();
	CLIENTDATAX_req = cJSON_CreateObject();
	
	EXTENSIONIN_req = cJSON_CreateObject();
	EXTENSIONINX_req = cJSON_CreateObject();
	item1_req = cJSON_CreateObject();
	item2_req = cJSON_CreateObject();
	
	HEADDATA_req = cJSON_CreateObject();
	
	FORECASTPARAMETERS_req = cJSON_CreateObject();
	FORECASTPARAMETERSX_req = cJSON_CreateObject();
	
	INTERNATIONALARTNOS_req = cJSON_CreateObject();
	item3_req = cJSON_CreateObject();
	
	MATERIALDESCRIPTION_req = cJSON_CreateObject();
	item4_req = cJSON_CreateObject();
	
	MATERIALLONGTEXT_req = cJSON_CreateObject();
	item5_req = cJSON_CreateObject();
	
	PLANNINGDATA_req = cJSON_CreateObject();
	PLANNINGDATAX_req = cJSON_CreateObject();
	
	PLANTDATA_req = cJSON_CreateObject();
	PLANTDATAX_req = cJSON_CreateObject();
	
	PRTDATA_req = cJSON_CreateObject();
	item6_req = cJSON_CreateObject();
	
	PRTDATAX_req = cJSON_CreateObject();
	item7_req = cJSON_CreateObject();
	
	RETURNMESSAGES_req = cJSON_CreateObject();
	item8_req = cJSON_CreateObject();
	
	
	SALESDATA_req = cJSON_CreateObject();
	SALESDATAX_req = cJSON_CreateObject();
	
	STORAGELOCATIONDATA_req = cJSON_CreateObject();
	STORAGELOCATIONDATAX_req = cJSON_CreateObject();
	
	STORAGETYPEDATA_req = cJSON_CreateObject();
	STORAGETYPEDATAX_req = cJSON_CreateObject();
	
	TAXCLASSIFICATIONS_req = cJSON_CreateObject();
	item9_req = cJSON_CreateObject();
	
	UNITSOFMEASURE_req = cJSON_CreateObject();
	item10_req = cJSON_CreateObject();
	
	UNITSOFMEASUREX_req = cJSON_CreateObject();
	item11_req = cJSON_CreateObject();
	
	VALUATIONDATA_req = cJSON_CreateObject();
	VALUATIONDATAX_req = cJSON_CreateObject();
	
	WAREHOUSENUMBERDATA_req = cJSON_CreateObject();
	WAREHOUSENUMBERDATAX_req = cJSON_CreateObject();
	
	
	cJSON_AddItemToObject(rfc_root, "ZBAPI_MATERIAL_SAVEDATA", exp_imp_tab_req);
	cJSON_AddItemToObject(exp_imp_tab_req, "CHANGE_NUMBER", cJSON_CreateString(changeno));  //Sample Change Number: CORRCT240625
		
	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATA", CLIENTDATA_req);
	cJSON_AddItemToObject(CLIENTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "OLD_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATA_req, "DOCUMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_TYPE" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATA_req, "DOC_VERS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_FORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGE_NO" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATA_req, "NO_SHEETS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGEFORMAT" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATA_req, "SIZE_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NET_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DIVISION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QTY_GR_GI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CAD_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLOWED_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLWD_VOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WT_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VOL_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "FILL_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STACK_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATA_req, "QM_PROCMNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CATPROFILE" , cJSON_CreateString(""));		
	cJSON_AddItemToObject(CLIENTDATA_req, "MINREMLIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SHELF_LIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_PCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATCMPLLVL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ANP" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATAX", CLIENTDATAX_req);
	cJSON_AddItemToObject(CLIENTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "OLD_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATAX_req, "DOCUMENT" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_TYPE" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_VERS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_FORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGE_NO" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATAX_req, "NO_SHEETS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGEFORMAT" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATAX_req, "SIZE_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NET_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DIVISION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QTY_GR_GI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CAD_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLOWED_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLWD_VOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WT_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VOL_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "FILL_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STACK_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATAX_req, "QM_PROCMNT" , cJSON_CreateString(""));		
    cJSON_AddItemToObject(CLIENTDATAX_req, "CATPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MINREMLIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SHELF_LIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_PCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATCMPLLVL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ANP" , cJSON_CreateString(""));
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_CAD_CALL", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_ONLINE", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "HEADDATA", HEADDATA_req);
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL" , cJSON_CreateString(part_noDup));
	cJSON_AddItemToObject(HEADDATA_req, "IND_SECTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "BASIC_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "SALES_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PURCHASE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MRP_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "FORECAST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "WORK_SCHED_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PRT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "STORAGE_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "WAREHOUSE_VIEW" , cJSON_CreateString(""));
    cJSON_AddItemToObject(HEADDATA_req, "QUALITY_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "ACCOUNT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "COST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "INP_FLD_CHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_VERSION" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALDESCRIPTION", MATERIALDESCRIPTION_req);
	cJSON_AddItemToObject(MATERIALDESCRIPTION_req, "item" , item4_req);
	cJSON_AddItemToObject(item4_req, "LANGU" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "LANGU_ISO" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "MATL_DESC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item4_req, "DEL_FLAG" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATA", PLANTDATA_req);
	cJSON_AddItemToObject(PLANTDATA_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(PLANTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ABC_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRPPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_CTRLER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLND_DELRY" , cJSON_CreateString(""));
    cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(""));		
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ASSY_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOTSIZEKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SPPROCTYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MINLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAXLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FIXED_LOT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_VAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORD_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEP_REQ_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ALT_BOM_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "GRP_REQMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIXED_MRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SM_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUPTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INTEROP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INHSEPRODT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGEPERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNDER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLENTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLACE_PT" , cJSON_CreateString(""));
    cJSON_AddItemToObject(PLANTDATA_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DOC_REQD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QUOTAUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SERV_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SPLIT_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAILCHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUP_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY_PLAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SHIP_PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROFIT_CTR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PPC_PL_CAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REP_MANUF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPMANPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PL_TI_FNCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISS_ST_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMP_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CERT_TYPE" , cJSON_CreateString(""));		
	cJSON_AddItemToObject(PLANTDATA_req, "CYCLE_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "VARIANCE_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SERNO_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MULT_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INSP_INT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLAN_STRGP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SLOC_EXPRC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BULK_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DETERM_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUR_STATUS" , cJSON_CreateString(" "));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETYTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEPLOY_HORIZ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FIX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_INCREMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATAX", PLANTDATAX_req);
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ABC_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRPPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_CTRLER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLND_DELRY" , cJSON_CreateString(""));
    cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ASSY_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOTSIZEKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPPROCTYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MINLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAXLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIXED_LOT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_VAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORD_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEP_REQ_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALT_BOM_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "GRP_REQMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIXED_MRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SM_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUPTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INTEROP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INHSEPRODT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGEPERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNDER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLENTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLACE_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_KEY" , cJSON_CreateString(""));
    cJSON_AddItemToObject(PLANTDATAX_req, "DOC_REQD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QUOTAUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERV_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPLIT_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAILCHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUP_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY_PLAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SHIP_PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROFIT_CTR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PPC_PL_CAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REP_MANUF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PL_TI_FNCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISS_ST_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMP_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CERT_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CYCLE_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "VARIANCE_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERNO_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPMANPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MULT_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INSP_INT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLAN_STRGP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SLOC_EXPRC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BULK_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DETERM_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
    cJSON_AddItemToObject(PLANTDATAX_req, "PUR_STATUS" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETYTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEPLOY_HORIZ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_INCREMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "RETURNMESSAGES", RETURNMESSAGES_req);
	cJSON_AddItemToObject(RETURNMESSAGES_req, "item", item8_req);
	cJSON_AddItemToObject(item8_req, "TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "NUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_MSG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "PARAMETER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ROW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "FIELD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "SYSTEM" , cJSON_CreateString(""));
	
	/* 
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATA" , STORAGELOCATIONDATA_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "INV_CORR_FAC" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATAX" , STORAGELOCATIONDATAX_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "INV_CORR_FAC" , cJSON_CreateString("")); */
	
	/*cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASURE" , UNITSOFMEASURE_req);
	cJSON_AddItemToObject(UNITSOFMEASURE_req, "item" , item10_req);
	cJSON_AddItemToObject(item10_req, "ALT_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "ALT_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "NUMERATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "DENOMINATR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "GROSS_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString(""));

	
	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASUREX" , UNITSOFMEASUREX_req);
	cJSON_AddItemToObject(UNITSOFMEASUREX_req, "item" , item11_req);
	cJSON_AddItemToObject(item11_req, "ALT_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "ALT_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "NUMERATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "DENOMINATR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "GROSS_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString("")); */
	
	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATA" , VALUATIONDATA_req);
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_AREA" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOVING_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CLASS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "FUTURE_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLND_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEVAL_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "OVERHEAD_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "QTY_STRUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MAT_ORIGIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAX_CML_UN" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATAX" , VALUATIONDATAX_req);
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_AREA" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOVING_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CLASS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "FUTURE_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLND_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEVAL_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "OVERHEAD_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "QTY_STRUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MAT_ORIGIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAX_CML_UN" , cJSON_CreateString(""));
	    
		
	out = cJSON_Print(rfc_root);
	tc_strcpy(json_arpbpczi_remove_req_obj,out);
	printf("%s\n", out);
	free(out);
	cJSON_Delete(rfc_root);

	return 0;
}

int PC_PreApprovalMail_Func(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	PCobjTag	=  NULLTAG;
	tag_t	ObjTypTag	    = NULLTAG;
	int      no_attach      =  0;
    char	*PCobjName	=  NULL;
	char	*PCobjDesc	=  NULL;
	char	*PCobjBu	=  NULL;
	char	*PCobjDML	=  NULL;
	char	*PCObjvcNo	=  NULL;
	char	*PCObjProd	=  NULL;
	char	*PCobjPlat	=  NULL;
	char	*PCobjSeg	=  NULL;
	char	*PCobjVar	=  NULL;
	char	*PCobjProfit	=  NULL;
	char	*PCobjAppStatus	=  NULL;
	char	*PCobjRelDate	=  NULL;
	char	*PCobjCrDate	=  NULL;
	char	*PCobjPlant	=  NULL;
	char   *ObjTypName = NULL;
	char* info1 = NULL;
	char* info2 = NULL;
	tag_t   qryTag1     = NULLTAG; 
	char    *qry_entry1[1]  = {"SYSCD"};
	int     n_entry1    = 1; 
	int     rsltCount1 =  0; 
	tag_t   *CntrlObjectTag1  = NULLTAG;	
	int error_code = ITK_ok;
	char* user_id1 =NULL;
	char    *qry_values1[1] = {"ProfitCenterPreApprovalMail"};
    POM_get_user_id (&user_id1);
	
	printf("\n PC: PC_PreApprovalMail_Func start.......");fflush(stdout);
	printf("\n PC: current user is: [%s]", user_id1);fflush(stdout);
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n PC: No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		PCobjTag = attachment[0];
	}
	if(TCTYPE_ask_object_type(attachment[0],&ObjTypTag));
	if(TCTYPE_ask_name2(ObjTypTag,&ObjTypName));
	printf("\n PC: Workfow Object Type Name: [%s]\n", ObjTypName);fflush(stdout);
	if(QRY_find2("ControlObjects", &qryTag1));
	if (qryTag1)
	{
		printf("\n PC: ProfitCenterPreApprovalMail: Found Query ControlObjects \n");fflush(stdout);
		if(QRY_execute(qryTag1, n_entry1, qry_entry1, qry_values1, &rsltCount1, &CntrlObjectTag1));
		printf("\n PC: ProfitCenterPreApprovalMail: Result Count: [%d]", rsltCount1);fflush(stdout);
		if(rsltCount1 > 0)
		{
			if(AOM_ask_value_string(CntrlObjectTag1[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
			if(AOM_ask_value_string(CntrlObjectTag1[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
			printf("\n PC: ProfitCenterPreApprovalMail: Information-2: [%s]\n", info2);fflush(stdout);
			if((tc_strcmp(ObjTypName,info1)==0) && (tc_strcmp(info2,"Mail")==0))
			{
				if(AOM_ask_value_string(attachment[0],"object_name",&PCobjName)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"object_desc",&PCobjDesc)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_BusinessUnit",&PCobjBu)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ERCDMLNo",&PCobjDML)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_VcNumber",&PCObjvcNo)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ProductLine",&PCObjProd)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Platform",&PCobjPlat)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Segment",&PCobjSeg)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Variant",&PCobjVar)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ProfitCenter",&PCobjProfit)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ApprovalStatus",&PCobjAppStatus)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr1",&PCobjRelDate)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr2",&PCobjCrDate)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr5",&PCobjPlant)!=ITK_ok)PrintErrorStack();
				printf("\n PC: Name: [%s]", PCobjName);fflush(stdout);
				printf("\n PC: Description: [%s]", PCobjDesc);fflush(stdout);
				printf("\n PC: Business Unit: [%s]", PCobjBu);fflush(stdout);
				printf("\n PC: DML No: [%s]", PCobjDML);fflush(stdout);
				printf("\n PC: VC No: [%s]", PCObjvcNo);fflush(stdout);
				printf("\n PC: Product Line: [%s]", PCObjProd);fflush(stdout);
				printf("\n PC: Platform: [%s]", PCobjPlat);fflush(stdout);
				printf("\n PC: Segment: [%s]", PCobjSeg);fflush(stdout);
				printf("\n PC: Variant: [%s]", PCobjVar);fflush(stdout);
				printf("\n PC: Profit Center: [%s]", PCobjProfit);fflush(stdout);
				printf("\n PC: Approval Status: [%s]", PCobjAppStatus);fflush(stdout);
				printf("\n PC: System Release Date: [%s]", PCobjRelDate);fflush(stdout);
				printf("\n PC: Object Creation Date: [%s]", PCobjCrDate);fflush(stdout);
				printf("\n PC: Plant Code: [%s]", PCobjPlant);fflush(stdout);
	
				char  *envSub	  = NULL;
				char  *envDesc	  = NULL;
				char  *buff 	= NULL;
				char*	eMailCC			= NULL;
				char*	eMailTo			= NULL;
				eMailCC=(char *) MEM_alloc(500 * sizeof(char *));
				eMailTo=(char *) MEM_alloc(500 * sizeof(char *));
				envSub = (char *) MEM_alloc( 250 * sizeof(char) );
				envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
				buff=(char *) MEM_alloc(2000 * sizeof(char *));
				char* info5 = NULL;
				char* info6 = NULL;
				char* info7 = NULL;
				char* info8 = NULL;
				char* info9 = NULL;
				char* info10 = NULL;
				if(AOM_ask_value_string(CntrlObjectTag1[0],"t5_Userinfo5",&info5)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag1[0],"t5_Userinfo6",&info6)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag1[0],"t5_Userinfo7",&info7)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag1[0],"t5_Userinfo8",&info8)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag1[0],"t5_Userinfo9",&info9)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag1[0],"t5_userinfo10",&info10)!=ITK_ok)   PrintErrorStack();
				tc_strcpy(eMailCC,"");
				tc_strcpy(eMailTo,"");
				tc_strcpy(envSub,"");
				tc_strcpy(envDesc,"");
				tc_strcpy(buff,"");
				tc_strcpy(eMailTo,info5);
				tc_strcat(eMailTo,info6);
				tc_strcat(eMailTo,info7);
				tc_strcpy(eMailCC,info8);
				tc_strcat(eMailCC,info9);
				tc_strcat(eMailCC,info10);
				
				tc_strcpy(envSub,"Profit Center for new VC: ");
				tc_strcat(envSub,PCobjName);
				tc_strcat(envSub," | ");
				tc_strcat(envSub,PCobjProfit);
				tc_strcat(envSub," | ");
				tc_strcat(envSub,PCobjPlant);

				tc_strcpy(envDesc,"Dear Sir / Madam, ");
				tc_strcat(envDesc,"\n\nBelow VC created in SAP with the profit center indicated: ");
				tc_strcat(envDesc,"\nVC Number: ");
				tc_strcat(envDesc,PCObjvcNo);
				tc_strcat(envDesc,"\nDescription: ");
				tc_strcat(envDesc,PCobjDesc);
				tc_strcat(envDesc,"\nProduct Line: ");
				tc_strcat(envDesc,PCObjProd);
				tc_strcat(envDesc,"\nPlatform: ");
				tc_strcat(envDesc,PCobjPlat);
				tc_strcat(envDesc,"\nSegment: ");
				tc_strcat(envDesc,PCobjSeg);
				tc_strcat(envDesc,"\nProfit Center: ");
				tc_strcat(envDesc,PCobjProfit);
				tc_strcat(envDesc,"\nPlant Code: ");
				tc_strcat(envDesc,PCobjPlant);
				tc_strcat(envDesc,"\nSystem Release Date: ");
				tc_strcat(envDesc,PCobjRelDate);
				tc_strcat(envDesc,"\nObject Created Date: ");
				tc_strcat(envDesc,PCobjCrDate);
				tc_strcat(envDesc,"\n\nApproval Status: ");
				tc_strcat(envDesc,PCobjAppStatus);
				tc_strcat(envDesc,"\n\nRegards, ");
				tc_strcat(envDesc,"PLM Team\n\n");

				printf("\n\nMAIL_initialize\n\n");
				sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
				printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
				system(buff);
			}
		}
		else
		{
			printf("\n PC: ProfitCenterPreApprovalMail: Control Object Not Found \n");fflush(stdout);
		}
	}
	else
	{
		printf("\n PC: ControlObjects Query Tag Not Found \n");fflush(stdout);
	}
    printf("\n PC: PC_PreApprovalMail_Func end.......");fflush(stdout);

	return error_code;
}

int PC_PostApprovalMail_Func(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	PCobjTag			=  NULLTAG;
	int     no_attach      =  0;
	tag_t	ObjTypTag	    = NULLTAG;
    char	*PCobjName	=  NULL;
	char	*PCobjDesc	=  NULL;
	char	*PCobjBu	=  NULL;
	char	*PCobjDML	=  NULL;
	char	*PCObjvcNo	=  NULL;
	char	*PCObjProd	=  NULL;
	char	*PCobjPlat	=  NULL;
	char	*PCobjSeg	=  NULL;
	char	*PCobjVar	=  NULL;
	char	*PCobjProfit	=  NULL;
	char	*PCobjAppStatus	=  NULL;
	char	*PCobjRelDate	=  NULL;
	char	*PCobjCrDate	=  NULL;
	char	*PCobjPlant	=  NULL;
	char   *ObjTypName = NULL;
	char* info1 = NULL;
	char* info2 = NULL;
	tag_t   qryTag2     = NULLTAG; 
	char    *qry_entry2[1]  = {"SYSCD"};
	int     n_entry2    = 1; 
	int     rsltCount2 =  0; 
	tag_t   *CntrlObjectTag2  = NULLTAG;	
	char    *qry_values2[1] = {"ProfitCenterPostApprovalMail"};
	int error_code = ITK_ok;
	char* user_id2 =NULL;
	
    POM_get_user_id (&user_id2);
	printf("\n PC: PC_PostApprovalMail_Func start.......");fflush(stdout);
	printf("\n PC: current user is: [%s]", user_id2);fflush(stdout);
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n PC: No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		PCobjTag = attachment[0];
	}

	if(TCTYPE_ask_object_type(attachment[0],&ObjTypTag));
	if(TCTYPE_ask_name2(ObjTypTag,&ObjTypName));
	printf("\n PC: Workfow Object Type Name: [%s]\n", ObjTypName);fflush(stdout);
	if(QRY_find2("ControlObjects", &qryTag2));
	if (qryTag2)
	{
		printf("\n PC: ProfitCenterPostApprovalMail: Found Query ControlObjects \n");fflush(stdout);
		if(QRY_execute(qryTag2, n_entry2, qry_entry2, qry_values2, &rsltCount2, &CntrlObjectTag2));
		printf("\n PC: ProfitCenterPostApprovalMail: Result Count: [%d]", rsltCount2);fflush(stdout);
		if(rsltCount2 > 0)
		{
			if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
			if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
			printf("\n PC: ProfitCenterPostApprovalMail: Information-2: [%s]\n", info2);fflush(stdout);
			if((tc_strcmp(ObjTypName,info1)==0) && (tc_strcmp(info2,"Mail")==0))
			{
				if(AOM_ask_value_string(attachment[0],"object_name",&PCobjName)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"object_desc",&PCobjDesc)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_BusinessUnit",&PCobjBu)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ERCDMLNo",&PCobjDML)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_VcNumber",&PCObjvcNo)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ProductLine",&PCObjProd)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Platform",&PCobjPlat)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Segment",&PCobjSeg)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Variant",&PCobjVar)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ProfitCenter",&PCobjProfit)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ApprovalStatus",&PCobjAppStatus)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr1",&PCobjRelDate)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr2",&PCobjCrDate)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr5",&PCobjPlant)!=ITK_ok)PrintErrorStack();
				printf("\n PC: Name: [%s]", PCobjName);fflush(stdout);
				printf("\n PC: Description: [%s]", PCobjDesc);fflush(stdout);
				printf("\n PC: Business Unit: [%s]", PCobjBu);fflush(stdout);
				printf("\n PC: DML No: [%s]", PCobjDML);fflush(stdout);
				printf("\n PC: VC No: [%s]", PCObjvcNo);fflush(stdout);
				printf("\n PC: Product Line: [%s]", PCObjProd);fflush(stdout);
				printf("\n PC: Platform: [%s]", PCobjPlat);fflush(stdout);
				printf("\n PC: Segment: [%s]", PCobjSeg);fflush(stdout);
				printf("\n PC: Variant: [%s]", PCobjVar);fflush(stdout);
				printf("\n PC: Profit Center: [%s]", PCobjProfit);fflush(stdout);
				printf("\n PC: Approval Status: [%s]", PCobjAppStatus);fflush(stdout);
				printf("\n PC: System Release Date: [%s]", PCobjRelDate);fflush(stdout);
				printf("\n PC: Object Creation Date: [%s]", PCobjCrDate);fflush(stdout);
				printf("\n PC: Plant Code: [%s]", PCobjPlant);fflush(stdout);
	
				char  *envSub	  = NULL;
				char  *envDesc	  = NULL;
				char  *buff 	= NULL;
				char*	eMailCC			= NULL;
				char*	eMailTo			= NULL;
				eMailCC=(char *) MEM_alloc(500 * sizeof(char *));
				eMailTo=(char *) MEM_alloc(500 * sizeof(char *));
				envSub = (char *) MEM_alloc( 250 * sizeof(char) );
				envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
				buff=(char *) MEM_alloc(2000 * sizeof(char *));
				char* info5 = NULL;
				char* info6 = NULL;
				char* info7 = NULL;
				char* info8 = NULL;
				char* info9 = NULL;
				char* info10 = NULL;
				if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo5",&info5)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo6",&info6)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo7",&info7)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo8",&info8)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo9",&info9)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_userinfo10",&info10)!=ITK_ok)   PrintErrorStack();
				tc_strcpy(eMailCC,"");
				tc_strcpy(eMailTo,"");
				tc_strcpy(envSub,"");
				tc_strcpy(envDesc,"");
				tc_strcpy(buff,"");
				tc_strcpy(eMailTo,info5);
				tc_strcat(eMailTo,info6);
				tc_strcat(eMailTo,info7);
				tc_strcpy(eMailCC,info8);
				tc_strcat(eMailCC,info9);
				tc_strcat(eMailCC,info10);
				
				tc_strcpy(envSub,"APPROVED:Profit Center for new VC: ");
				tc_strcat(envSub,PCobjName);
				tc_strcat(envSub," | ");
				tc_strcat(envSub,PCobjProfit);
				tc_strcat(envSub," | ");
				tc_strcat(envSub,PCobjPlant);

				tc_strcpy(envDesc,"Dear Sir / Madam, ");
				tc_strcat(envDesc,"\n\nThanks for confirming we are processing below VC’s with mapped profit center ");
				tc_strcat(envDesc,"\nVC Number: ");
				tc_strcat(envDesc,PCObjvcNo);
				tc_strcat(envDesc,"\nDescription: ");
				tc_strcat(envDesc,PCobjDesc);
				tc_strcat(envDesc,"\nProduct Line: ");
				tc_strcat(envDesc,PCObjProd);
				tc_strcat(envDesc,"\nPlatform: ");
				tc_strcat(envDesc,PCobjPlat);
				tc_strcat(envDesc,"\nSegment: ");
				tc_strcat(envDesc,PCobjSeg);
				tc_strcat(envDesc,"\nProfit Center: ");
				tc_strcat(envDesc,PCobjProfit);
				tc_strcat(envDesc,"\nPlant Code: ");
				tc_strcat(envDesc,PCobjPlant);
				tc_strcat(envDesc,"\nSystem Release Date: ");
				tc_strcat(envDesc,PCobjRelDate);
				tc_strcat(envDesc,"\nObject Created Date: ");
				tc_strcat(envDesc,PCobjCrDate);
				tc_strcat(envDesc,"\n\nApproval Status: ");
				tc_strcat(envDesc,"APPROVED");
				tc_strcat(envDesc,"\n\nRegards, ");
				tc_strcat(envDesc,"PLM Team\n\n");

				printf("\n\nMAIL_initialize\n\n");
				sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
				printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
				system(buff);
			}
		}
		else
		{
			printf("\n PC: ProfitCenterPostApprovalMail: Control Object Not Found \n");fflush(stdout);
		}
	}
	else
	{
		printf("\n PC: ControlObjects Query Tag Not Found \n");fflush(stdout);
	}
    printf("\n PC: PC_PostApprovalMail_Func end.......");fflush(stdout);
	
	return error_code;
}

int PC_FinanceHeadRejectEmail_Func(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	PCobjTag		=  NULLTAG;
	tag_t	ObjTypTag	    = NULLTAG;
	int      no_attach      =  0;
    char	*PCobjName	=  NULL;
	char	*PCobjDesc	=  NULL;
	char	*PCobjBu	=  NULL;
	char	*PCobjDML	=  NULL;
	char	*PCObjvcNo	=  NULL;
	char	*PCObjProd	=  NULL;
	char	*PCobjPlat	=  NULL;
	char	*PCobjSeg	=  NULL;
	char	*PCobjVar	=  NULL;
	char	*PCobjProfit	=  NULL;
	char	*PCobjAppStatus	=  NULL;
	char	*PCobjRelDate	=  NULL;
	char	*PCobjCrDate	=  NULL;
	char	*PCobjPlant	=  NULL;
	char   *ObjTypName = NULL;
	char* info1 = NULL;
	char* info2 = NULL;
	tag_t   qryTag3     = NULLTAG; 
	char    *qry_entry3[1]  = {"SYSCD"};
	int     n_entry3    = 1; 
	int     rsltCount3 =  0; 
	tag_t   *CntrlObjectTag3  = NULLTAG;	
	char    *qry_values3[1] = {"ProfitCenterPostApprovalMail"};
	int error_code = ITK_ok;
	char* user_id3 =NULL;
	
    POM_get_user_id (&user_id3);
	printf("\n PC: PC_FinanceHeadRejectEmail_Func start.......");fflush(stdout);
	printf("\n PC: current user is: [%s]", user_id3);fflush(stdout);
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n PC: No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		PCobjTag = attachment[0];
	}

	if(TCTYPE_ask_object_type(attachment[0],&ObjTypTag));
	if(TCTYPE_ask_name2(ObjTypTag,&ObjTypName));
	printf("\n PC: Workfow Object Type Name: [%s]\n", ObjTypName);fflush(stdout);
	if(QRY_find2("ControlObjects", &qryTag3));
	if (qryTag3)
	{
		printf("\n PC: ProfitCenterPostApprovalMail: Found Query ControlObjects \n");fflush(stdout);
		if(QRY_execute(qryTag3, n_entry3, qry_entry3, qry_values3, &rsltCount3, &CntrlObjectTag3));
		printf("\n PC: ProfitCenterPostApprovalMail: Result Count: [%d]", rsltCount3);fflush(stdout);
		if(rsltCount3 > 0)
		{
			if(AOM_ask_value_string(CntrlObjectTag3[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
			if(AOM_ask_value_string(CntrlObjectTag3[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
			printf("\n PC: ProfitCenterPostApprovalMail: Information-2: [%s]\n", info2);fflush(stdout);
			if((tc_strcmp(ObjTypName,info1)==0) && (tc_strcmp(info2,"Mail")==0))
			{
				if(AOM_ask_value_string(attachment[0],"object_name",&PCobjName)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"object_desc",&PCobjDesc)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_BusinessUnit",&PCobjBu)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ERCDMLNo",&PCobjDML)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_VcNumber",&PCObjvcNo)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ProductLine",&PCObjProd)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Platform",&PCobjPlat)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Segment",&PCobjSeg)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Variant",&PCobjVar)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ProfitCenter",&PCobjProfit)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ApprovalStatus",&PCobjAppStatus)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr1",&PCobjRelDate)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr2",&PCobjCrDate)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr5",&PCobjPlant)!=ITK_ok)PrintErrorStack();
				printf("\n PC: Name: [%s]", PCobjName);fflush(stdout);
				printf("\n PC: Description: [%s]", PCobjDesc);fflush(stdout);
				printf("\n PC: Business Unit: [%s]", PCobjBu);fflush(stdout);
				printf("\n PC: DML No: [%s]", PCobjDML);fflush(stdout);
				printf("\n PC: VC No: [%s]", PCObjvcNo);fflush(stdout);
				printf("\n PC: Product Line: [%s]", PCObjProd);fflush(stdout);
				printf("\n PC: Platform: [%s]", PCobjPlat);fflush(stdout);
				printf("\n PC: Segment: [%s]", PCobjSeg);fflush(stdout);
				printf("\n PC: Variant: [%s]", PCobjVar);fflush(stdout);
				printf("\n PC: Profit Center: [%s]", PCobjProfit);fflush(stdout);
				printf("\n PC: Approval Status: [%s]", PCobjAppStatus);fflush(stdout);
				printf("\n PC: System Release Date: [%s]", PCobjRelDate);fflush(stdout);
				printf("\n PC: Object Creation Date: [%s]", PCobjCrDate);fflush(stdout);
				printf("\n PC: Plant Code: [%s]", PCobjPlant);fflush(stdout);
	
				char  *envSub	  = NULL;
				char  *envDesc	  = NULL;
				char  *buff 	= NULL;
				char*	eMailCC			= NULL;
				char*	eMailTo			= NULL;
				eMailCC=(char *) MEM_alloc(500 * sizeof(char *));
				eMailTo=(char *) MEM_alloc(500 * sizeof(char *));
				envSub = (char *) MEM_alloc( 250 * sizeof(char) );
				envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
				buff=(char *) MEM_alloc(2000 * sizeof(char *));
				char* info5 = NULL;
				char* info6 = NULL;
				char* info7 = NULL;
				char* info8 = NULL;
				char* info9 = NULL;
				char* info10 = NULL;
				if(AOM_ask_value_string(CntrlObjectTag3[0],"t5_Userinfo5",&info5)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag3[0],"t5_Userinfo6",&info6)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag3[0],"t5_Userinfo7",&info7)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag3[0],"t5_Userinfo8",&info8)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag3[0],"t5_Userinfo9",&info9)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag3[0],"t5_userinfo10",&info10)!=ITK_ok)   PrintErrorStack();
				tc_strcpy(eMailCC,"");
				tc_strcpy(eMailTo,"");
				tc_strcpy(envSub,"");
				tc_strcpy(envDesc,"");
				tc_strcpy(buff,"");
				tc_strcpy(eMailTo,info5);
				tc_strcat(eMailTo,info6);
				tc_strcat(eMailTo,info7);
				tc_strcpy(eMailCC,info8);
				tc_strcat(eMailCC,info9);
				tc_strcat(eMailCC,info10);
				
				tc_strcpy(envSub,"REJECTED:Profit Center for new VC: ");
				tc_strcat(envSub,PCobjName);
				tc_strcat(envSub," | ");
				tc_strcat(envSub,PCobjProfit);
				tc_strcat(envSub," | ");
				tc_strcat(envSub,PCobjPlant);

				tc_strcpy(envDesc,"Dear Sir / Madam, ");
				tc_strcat(envDesc,"\n\nThanks we will review rejection comments and re-process below VC with correct profit center ");
				tc_strcat(envDesc,"\nVC Number: ");
				tc_strcat(envDesc,PCObjvcNo);
				tc_strcat(envDesc,"\nDescription: ");
				tc_strcat(envDesc,PCobjDesc);
				tc_strcat(envDesc,"\nProduct Line: ");
				tc_strcat(envDesc,PCObjProd);
				tc_strcat(envDesc,"\nPlatform: ");
				tc_strcat(envDesc,PCobjPlat);
				tc_strcat(envDesc,"\nSegment: ");
				tc_strcat(envDesc,PCobjSeg);
				tc_strcat(envDesc,"\nProfit Center: ");
				tc_strcat(envDesc,PCobjProfit);
				tc_strcat(envDesc,"\nPlant Code: ");
				tc_strcat(envDesc,PCobjPlant);
				tc_strcat(envDesc,"\nSystem Release Date: ");
				tc_strcat(envDesc,PCobjRelDate);
				tc_strcat(envDesc,"\nObject Created Date: ");
				tc_strcat(envDesc,PCobjCrDate);
				tc_strcat(envDesc,"\n\nApproval Status: ");
				tc_strcat(envDesc,"REJECTED");
				tc_strcat(envDesc,"\n\nRegards, ");
				tc_strcat(envDesc,"PLM Team\n\n");

				printf("\n\nMAIL_initialize\n\n");
				sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
				printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
				system(buff);
			}
		}
		else
		{
			printf("\n PC: ProfitCenterPostApprovalMail: Control Object Not Found \n");fflush(stdout);
		}
	}
	else
	{
		printf("\n PC: ControlObjects Query Tag Not Found \n");fflush(stdout);
	}
	printf("\n PC: PC_FinanceHeadRejectEmail_Func end.......");fflush(stdout);
	
	return error_code;
}

int PCRemove_Func(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	PCobjTag			=  NULLTAG;
	int     no_attach      =  0;
	tag_t	ObjTypTag	    = NULLTAG;
    char	*PCobjName	=  NULL;
	char	*PCobjDesc	=  NULL;
	char	*PCobjBu	=  NULL;
	char	*PCobjDML	=  NULL;
	char	*PCObjvcNo	=  NULL;
	char	*PCObjProd	=  NULL;
	char	*PCobjPlat	=  NULL;
	char	*PCobjSeg	=  NULL;
	char	*PCobjVar	=  NULL;
	char	*PCobjProfit	=  NULL;
	char	*PCobjAppStatus	=  NULL;
	char	*PCobjRelDate	=  NULL;
	char	*PCobjCrDate	=  NULL;
	char	*PCobjPlant	=  NULL;
	char   *ObjTypName = NULL;
	char* info1 = NULL;
	char* info2 = NULL;
	char* info3 = NULL;
	char* info4 = NULL;
	tag_t   qryTag2     = NULLTAG; 
	char    *qry_entry2[1]  = {"SYSCD"};
	int     n_entry2    = 1; 
	int     rsltCount2 =  0; 
	tag_t   *CntrlObjectTag2  = NULLTAG;	
	char    *qry_values2[1] = {"ProfitCenterPostApprovalMail"};
	int error_code = ITK_ok;
	char* user_id2 =NULL;
	
    POM_get_user_id (&user_id2);
	printf("\n PC: PCRemove_Func start.......");fflush(stdout);
	printf("\n PC: current user is: [%s]", user_id2);fflush(stdout);
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n PC: No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		PCobjTag = attachment[0];
	}

	if(TCTYPE_ask_object_type(attachment[0],&ObjTypTag));
	if(TCTYPE_ask_name2(ObjTypTag,&ObjTypName));
	printf("\n PC: Workfow Object Type Name: [%s]\n", ObjTypName);fflush(stdout);
	if(QRY_find2("ControlObjects", &qryTag2));
	if (qryTag2)
	{
		printf("\n PC: PCRemove_Func: Found Query ControlObjects \n");fflush(stdout);
		if(QRY_execute(qryTag2, n_entry2, qry_entry2, qry_values2, &rsltCount2, &CntrlObjectTag2));
		printf("\n PC: PCRemove_Func: Result Count: [%d]", rsltCount2);fflush(stdout);
		if(rsltCount2 > 0)
		{
			if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
			if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
			if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo3",&info3)!=ITK_ok)   PrintErrorStack();
			printf("\n PC: PCRemove_Func: Information-1: [%s]\n", info1);fflush(stdout);
			printf("\n PC: PCRemove_Func: Information-2: [%s]\n", info2);fflush(stdout);
			printf("\n PC: PCRemove_Func: Information-3: [%s]\n", info3);fflush(stdout);
			printf("\n PC: PCRemove_Func: Information-4: [%s]\n", info4);fflush(stdout);
			if((tc_strcmp(ObjTypName,info1)==0) && (tc_strcmp(info2,"Mail")==0))
			{
				if(AOM_ask_value_string(attachment[0],"object_name",&PCobjName)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"object_desc",&PCobjDesc)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_BusinessUnit",&PCobjBu)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ERCDMLNo",&PCobjDML)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_VcNumber",&PCObjvcNo)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ProductLine",&PCObjProd)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Platform",&PCobjPlat)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Segment",&PCobjSeg)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Variant",&PCobjVar)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ProfitCenter",&PCobjProfit)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ApprovalStatus",&PCobjAppStatus)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr1",&PCobjRelDate)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr2",&PCobjCrDate)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr5",&PCobjPlant)!=ITK_ok)PrintErrorStack();
				printf("\n PC: Name: [%s]", PCobjName);fflush(stdout);
				printf("\n PC: Description: [%s]", PCobjDesc);fflush(stdout);
				printf("\n PC: Business Unit: [%s]", PCobjBu);fflush(stdout);
				printf("\n PC: DML No: [%s]", PCobjDML);fflush(stdout);
				printf("\n PC: VC No: [%s]", PCObjvcNo);fflush(stdout);
				printf("\n PC: Product Line: [%s]", PCObjProd);fflush(stdout);
				printf("\n PC: Platform: [%s]", PCobjPlat);fflush(stdout);
				printf("\n PC: Segment: [%s]", PCobjSeg);fflush(stdout);
				printf("\n PC: Variant: [%s]", PCobjVar);fflush(stdout);
				printf("\n PC: Profit Center: [%s]", PCobjProfit);fflush(stdout);
				printf("\n PC: Approval Status: [%s]", PCobjAppStatus);fflush(stdout);
				printf("\n PC: System Release Date: [%s]", PCobjRelDate);fflush(stdout);
				printf("\n PC: Object Creation Date: [%s]", PCobjCrDate);fflush(stdout);
				printf("\n PC: Plant Code: [%s]", PCobjPlant);fflush(stdout);
				
				tc_strdup(PCObjvcNo,&inputPart);
				tc_strdup(PCobjPlant,&iPlantCode);
				tc_strdup(info3,&iSapServer);
				printf("\n PC: PCRemove_Func 1111....inputPart: [%s]\n", inputPart);
				printf("\n PC: PCRemove_Func 2222....iPlantCode: [%s]\n", iPlantCode);
				printf("\n PC: PCRemove_Func 3333....iSapServer: [%s]\n", iSapServer);
				char *changeno = (char *) malloc(100*sizeof(char));
				char GenDate[100] = "";
				time_t 	now;
				struct 	tm when;
				time(&now);
				when = *localtime(&now);
				strftime(GenDate,100,"%d%m%y",&when);
				printf(" PC: PCRemove_Func: Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
				tc_strcpy(changeno,"CORRCT");
				tc_strcat(changeno,GenDate);
				printf(" PC: PCRemove_Func: Change Number: [%s]\n", changeno);fflush(stdout);

				if((tc_strlen(inputPart)>0) && (tc_strlen(iPlantCode)>0) && (tc_strlen(iSapServer)>0))
				{
					printf(" PC: PCRemove_Func: Input_Argument Not Null..!!\n");fflush(stdout);
					char *json_arpbpczi_remove_req_obj = NULL;
					json_arpbpczi_remove_req_obj = malloc(34000);
					cll_arpbpczi_remove(inputPart, iPlantCode, changeno, json_arpbpczi_remove_req_obj);
					printf("\n PC: PCRemove_Func: Request String: [%s]\n", json_arpbpczi_remove_req_obj);
					tm_curl_arpbpczi_remove( json_arpbpczi_remove_req_obj );
					free(json_arpbpczi_remove_req_obj);
				}
				else
				{
				   printf(" PC: PCRemove_Func: Input_Argument is Null..!!\n");fflush(stdout);
				}
	
				char  *envSub	  = NULL;
				char  *envDesc	  = NULL;
				char  *buff 	= NULL;
				char*	eMailCC			= NULL;
				char*	eMailTo			= NULL;
				eMailCC=(char *) MEM_alloc(500 * sizeof(char *));
				eMailTo=(char *) MEM_alloc(500 * sizeof(char *));
				envSub = (char *) MEM_alloc( 250 * sizeof(char) );
				envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
				buff=(char *) MEM_alloc(2000 * sizeof(char *));
				//char* info5 = NULL;
				//char* info6 = NULL;
				//char* info7 = NULL;
				char* info8 = NULL;
				char* info9 = NULL;
				char* info10 = NULL;
				//if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo5",&info5)!=ITK_ok)   PrintErrorStack();
				//if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo6",&info6)!=ITK_ok)   PrintErrorStack();
				//if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo7",&info7)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo8",&info8)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo9",&info9)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_userinfo10",&info10)!=ITK_ok)   PrintErrorStack();
				tc_strcpy(eMailCC,"");
				tc_strcpy(eMailTo,"");
				tc_strcpy(envSub,"");
				tc_strcpy(envDesc,"");
				tc_strcpy(buff,"");
				//tc_strcpy(eMailTo,info5);
				//tc_strcat(eMailTo,info6);
				//tc_strcat(eMailTo,info7);
				tc_strcpy(eMailTo,info8);
				tc_strcat(eMailTo,info9);
				tc_strcat(eMailTo,info10);
				tc_strcpy(eMailCC,info4);
				//tc_strcpy(eMailCC,info8);
				//tc_strcat(eMailCC,info9);
				//tc_strcat(eMailCC,info10);
				
				tc_strcpy(envSub,"UPDATE:PC tag removed from SAP: ");
				tc_strcat(envSub,PCobjName);
				tc_strcat(envSub," | ");
				tc_strcat(envSub,PCobjProfit);
				tc_strcat(envSub," | ");
				tc_strcat(envSub,PCobjPlant);

				tc_strcpy(envDesc,"Dear All, ");
				tc_strcat(envDesc,"\n\nPC tag removed for below vc from SAP");
				tc_strcat(envDesc,"\nVC Number: ");
				tc_strcat(envDesc,PCObjvcNo);
				tc_strcat(envDesc,"\nDescription: ");
				tc_strcat(envDesc,PCobjDesc);
				tc_strcat(envDesc,"\nProduct Line: ");
				tc_strcat(envDesc,PCObjProd);
				tc_strcat(envDesc,"\nPlatform: ");
				tc_strcat(envDesc,PCobjPlat);
				tc_strcat(envDesc,"\nSegment: ");
				tc_strcat(envDesc,PCobjSeg);
				tc_strcat(envDesc,"\nProfit Center: ");
				tc_strcat(envDesc,PCobjProfit);
				tc_strcat(envDesc,"\nPlant Code: ");
				tc_strcat(envDesc,PCobjPlant);
				tc_strcat(envDesc,"\nSystem Release Date: ");
				tc_strcat(envDesc,PCobjRelDate);
				tc_strcat(envDesc,"\nObject Created Date: ");
				tc_strcat(envDesc,PCobjCrDate);
				//tc_strcat(envDesc,"\n\nApproval Status: ");
				//tc_strcat(envDesc,"APPROVED");
				tc_strcat(envDesc,"\n\nRegards, ");
				tc_strcat(envDesc,"PLM Team\n\n");

				printf("\n\nMAIL_initialize\n\n");
				sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
				printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
				system(buff);
			}
		}
		else
		{
			printf("\n PC: PCRemove_Func: Control Object Not Found \n");fflush(stdout);
		}
	}
	else
	{
		printf("\n PC: PCRemove_Func: ControlObjects Query Tag Not Found \n");fflush(stdout);
	}
    printf("\n PC: PCRemove_Func end.......");fflush(stdout);
	
	return error_code;
}

EPM_decision_t PCFinanceHeadDecisionCmnt( EPM_rule_message_t msg)
{
	tag_t   *attachment     =  NULLTAG;
	tag_t	objTag			=  NULLTAG;
	tag_t	objTypTag		= NULLTAG;
	tag_t   qryTag     = NULLTAG; 
	tag_t   *CntrlObjectTag      = NULLTAG;
	int      no_attach      =  0;
	char	*DMLType		=  NULL;		
	char    *qry_entry[1]  = {"SYSCD"};
	char    *qry_values2[1]     =  {"ProfitCenterPostApprovalMail"};
	int     n_entry    = 1; 
	int     rsltCount      =  0; 
	char	*info1	= NULL;
	char	*info2	= NULL;
	char   *ObjTyp = NULL;
	char	*PCobjName	=  NULL;
	char	*PCobjDesc	=  NULL;
	char	*PCobjBu	=  NULL;
	char	*PCobjDML	=  NULL;
	char	*PCObjvcNo	=  NULL;
	char	*PCObjProd	=  NULL;
	char	*PCobjPlat	=  NULL;
	char	*PCobjSeg	=  NULL;
	char	*PCobjVar	=  NULL;
	char	*PCobjProfit	=  NULL;
	char	*PCobjAppStatus	=  NULL;
	char	*PCobjRelDate	=  NULL;
	char	*PCobjCrDate	=  NULL;
	char	*PCobjPlant	=  NULL;
	char command[512];
	int error_code = ITK_ok;
	char* user_id =NULL;
	char* TaskResult = NULL;
	int cnt = 0;
	EPM_decision_t	decision = EPM_go;
	int ifail = ITK_ok;
	tag_t	rootTask = NULLTAG;
	tag_t* signOffTags = NULLTAG;
	char* decisiondate = NULL;
	tag_t updateappstat = NULLTAG;
	
	if(EPM_ask_root_task(msg.task,&rootTask)!=ITK_ok)PrintErrorStack();
	printf("\n PC: Root Task Found");fflush(stdout);	
	if(EPM_ask_attachments(msg.task, EPM_signoff_attachment, &cnt, &signOffTags)!=ITK_ok)PrintErrorStack();
	printf("\n PC: No of Sign off Tags Count: [%d]\n",cnt);fflush(stdout);
	if(cnt>0)
	{
		tag_t signOffTag = NULLTAG;
		EPM_signoff_decision_t decsn = EPM_no_decision;
		char* comments = NULL;
		date_t decision_date = NULLDATE;
		signOffTag = signOffTags[0];
		if(EPM_ask_signoff_decision(signOffTag, &decsn, &comments, &decision_date)!=ITK_ok)PrintErrorStack();
		printf("\n PC: Decision: [%d]\n",decsn);fflush(stdout);
		printf("\n PC: Decision Comments: [%s]\n",comments);fflush(stdout);
		ITK_date_to_string(decision_date,&decisiondate);
		printf("\n PC: Decision Date: [%s]\n",decisiondate);fflush(stdout);
		if(decsn==EPM_approve_decision || decsn==EPM_reject_decision)
		{
			if(comments == NULL)
			{
				char* buff = NULL;
				ifail=T5_WorkFlowHandlerErr;
				buff = (char*)MEM_alloc(200*sizeof(char));
				sprintf(buff, "Sign off Comment is mandatory. Please enter comments before sign off");
				EMH_store_error_s1(EMH_severity_error,ifail,buff);
				decision = EPM_nogo;
				if(buff)MEM_free(buff);
				return decision; 						
			}
			else
			{
				if(tc_strcmp(comments,"")==0)
				{
					char* buff = NULL;
					ifail=T5_WorkFlowHandlerErr;
					buff = (char*)MEM_alloc(200*sizeof(char));
					sprintf(buff, "Sign off Comment is blank. Please enter comments before sign off");
					EMH_store_error_s1(EMH_severity_error,ifail,buff);
					decision = EPM_nogo;
					if(buff)MEM_free(buff);
					return decision; 						
				}
				else
				{
					if(EPM_ask_attachments(rootTask, EPM_target_attachment, &no_attach, &attachment)!=ITK_ok)PrintErrorStack();
					printf("\n PC: No of Attachements: [%d]", no_attach);fflush(stdout);
					if (no_attach > 0)
					{
						objTag = attachment[0];
						char* COCDecision = NULL;
						if (decsn==EPM_approve_decision)
						{
							tc_strdup("APPROVED",&COCDecision);
						}
						else
						{
							tc_strdup("REJECT",&COCDecision);
						}

                        printf("\n PC: Finance Head Decision: [%s]", COCDecision); fflush(stdout);
						if(TCTYPE_ask_object_type(objTag,&objTypTag));
						if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
						printf("\n PC: Workfow Object Type Name: [%s]\n", ObjTyp);fflush(stdout);
						if(QRY_find2("ControlObjects", &qryTag));
						if(qryTag)
						{
							printf("\n PC: ProfitCenterPostApprovalMail: Found Query ControlObjects \n");fflush(stdout);
							if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
							printf("\n PC: ProfitCenterPostApprovalMail: Result Count: [%d]", rsltCount); fflush(stdout);
							if(rsltCount > 0)
							{
								if(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
			                    if(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
			                    printf("\n PC: ProfitCenterPostApprovalMail: Information-2: [%s]\n", info2);fflush(stdout);
								if((tc_strcmp(ObjTyp,info1)==0) && (tc_strcmp(info2,"Mail")==0))
			                    {
									if(AOM_ask_value_string(objTag,"object_name",&PCobjName)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(objTag,"object_desc",&PCobjDesc)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(objTag,"t5_BusinessUnit",&PCobjBu)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(objTag,"t5_ERCDMLNo",&PCobjDML)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(objTag,"t5_VcNumber",&PCObjvcNo)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(objTag,"t5_ProductLine",&PCObjProd)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(objTag,"t5_Platform",&PCobjPlat)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(objTag,"t5_Segment",&PCobjSeg)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(objTag,"t5_Variant",&PCobjVar)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(objTag,"t5_ProfitCenter",&PCobjProfit)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(objTag,"t5_ApprovalStatus",&PCobjAppStatus)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(objTag,"t5_ExtraAttr1",&PCobjRelDate)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(objTag,"t5_ExtraAttr2",&PCobjCrDate)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(objTag,"t5_ExtraAttr5",&PCobjPlant)!=ITK_ok)PrintErrorStack();
									printf("\n PC: Name: [%s]", PCobjName);fflush(stdout);
									printf("\n PC: Description: [%s]", PCobjDesc);fflush(stdout);
									printf("\n PC: Business Unit: [%s]", PCobjBu);fflush(stdout);
									printf("\n PC: DML No: [%s]", PCobjDML);fflush(stdout);
									printf("\n PC: VC No: [%s]", PCObjvcNo);fflush(stdout);
									printf("\n PC: Product Line: [%s]", PCObjProd);fflush(stdout);
									printf("\n PC: Platform: [%s]", PCobjPlat);fflush(stdout);
									printf("\n PC: Segment: [%s]", PCobjSeg);fflush(stdout);
									printf("\n PC: Variant: [%s]", PCobjVar);fflush(stdout);
									printf("\n PC: Profit Center: [%s]", PCobjProfit);fflush(stdout);
									printf("\n PC: Approval Status: [%s]", PCobjAppStatus);fflush(stdout);
									printf("\n PC: System Release Date: [%s]", PCobjRelDate);fflush(stdout);
									printf("\n PC: Object Creation Date: [%s]", PCobjCrDate);fflush(stdout);
									printf("\n PC: Plant Code: [%s]", PCobjPlant);fflush(stdout);
									 printf("\n PC: Before Finance Head Decision: [%s]", COCDecision); fflush(stdout);
									if(decsn==EPM_approve_decision || tc_strcmp(COCDecision,"APPROVED")==0 || decsn==EPM_reject_decision || tc_strcmp(COCDecision,"REJECT")==0)
									{
										printf("\n PC: PCFinanceHeadDecisionCmnt: desc: [%d]", decsn);fflush(stdout);
										printf("\n PC: After PCFinanceHeadDecisionCmnt: COCDecision: [%s]", COCDecision);fflush(stdout);
										if(decsn==EPM_reject_decision || tc_strcmp(COCDecision,"REJECT")==0)
										{
											printf("\n PC: PCFinanceHeadDecisionCmnt: Approval Status set For [REJECT] Decision Start..");fflush(stdout);
											AOM_refresh(objTag, TRUE);
											POM_attr_id_of_attr("t5_ApprovalStatus", "T5_ProfitCenterMapping", &updateappstat);
											POM_set_attr_string(1, &objTag, updateappstat, "REJECT");
											POM_save_instances(1, &objTag, false);
											printf("\n PC: PCFinanceHeadDecisionCmnt: Completed: POM_save_instances");fflush(stdout);
											AOM_refresh(objTag, FALSE);
											printf("\n PC: PCFinanceHeadDecisionCmnt: Approval Status set For [REJECT] Decision End..");fflush(stdout);
										}
										if(decsn==EPM_approve_decision || tc_strcmp(COCDecision,"APPROVED")==0)
										{
											printf("\n PC: PCFinanceHeadDecisionCmnt: Approval Status set For [APPROVED] Decision Start..");fflush(stdout);
											AOM_refresh(objTag, TRUE);
											POM_attr_id_of_attr("t5_ApprovalStatus", "T5_ProfitCenterMapping", &updateappstat);
											POM_set_attr_string(1, &objTag, updateappstat, "APPROVED");
											POM_save_instances(1, &objTag, false);
											AOM_refresh(objTag, FALSE);
											printf("\n PC: PCFinanceHeadDecisionCmnt: Approval Status set For [APPROVED] Decision End..");fflush(stdout);
										}
									}	
				
									char  *envSub	  = NULL;
									char  *envDesc	  = NULL;
									char  *buff 	= NULL;
									char*	eMailCC			= NULL;
									char*	eMailTo			= NULL;
									eMailCC=(char *) MEM_alloc(500 * sizeof(char *));
									eMailTo=(char *) MEM_alloc(500 * sizeof(char *));
									envSub = (char *) MEM_alloc( 250 * sizeof(char) );
									envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
									buff=(char *) MEM_alloc(2000 * sizeof(char *));
									char* info5 = NULL;
									char* info6 = NULL;
									char* info7 = NULL;
									char* info8 = NULL;
									char* info9 = NULL;
									char* info10 = NULL;
									if(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo5",&info5)!=ITK_ok)   PrintErrorStack();
									if(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo6",&info6)!=ITK_ok)   PrintErrorStack();
									if(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo7",&info7)!=ITK_ok)   PrintErrorStack();
									if(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo8",&info8)!=ITK_ok)   PrintErrorStack();
									if(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo9",&info9)!=ITK_ok)   PrintErrorStack();
									if(AOM_ask_value_string(CntrlObjectTag[0],"t5_userinfo10",&info10)!=ITK_ok)   PrintErrorStack();
									tc_strcpy(eMailCC,"");
									tc_strcpy(eMailTo,"");
									tc_strcpy(envSub,"");
									tc_strcpy(envDesc,"");
									tc_strcpy(buff,"");
									tc_strcpy(eMailTo,info8);
									tc_strcat(eMailTo,info9);
									tc_strcat(eMailTo,info10);
									tc_strcpy(eMailCC,info5);
									tc_strcat(eMailCC,info6);
									tc_strcat(eMailCC,info7);
									
									tc_strcpy(envSub,COCDecision);
									tc_strcat(envSub,":Profit Center for new VC: ");
									tc_strcat(envSub,PCobjName);
									tc_strcat(envSub," | ");
									tc_strcat(envSub,PCobjProfit);
									tc_strcat(envSub," | ");
									tc_strcat(envSub,PCobjPlant);

									tc_strcpy(envDesc,"Dear All, ");
									tc_strcat(envDesc,"\n\n Please find Finance Head Teams comments for below VC ");
									tc_strcat(envDesc,"\nVC Number: ");
									tc_strcat(envDesc,PCObjvcNo);
									tc_strcat(envDesc,"\nDescription: ");
									tc_strcat(envDesc,PCobjDesc);
									tc_strcat(envDesc,"\nProduct Line: ");
									tc_strcat(envDesc,PCObjProd);
									tc_strcat(envDesc,"\nPlatform: ");
									tc_strcat(envDesc,PCobjPlat);
									tc_strcat(envDesc,"\nSegment: ");
									tc_strcat(envDesc,PCobjSeg);
									tc_strcat(envDesc,"\nProfit Center: ");
									tc_strcat(envDesc,PCobjProfit);
									tc_strcat(envDesc,"\nPlant Code: ");
									tc_strcat(envDesc,PCobjPlant);
									tc_strcat(envDesc,"\nSystem Release Date: ");
									tc_strcat(envDesc,PCobjRelDate);
									tc_strcat(envDesc,"\nObject Created Date: ");
									tc_strcat(envDesc,PCobjCrDate);
									tc_strcat(envDesc,"\n\n Finance Team Approval Status: ");
									tc_strcat(envDesc,COCDecision);
									tc_strcat(envDesc,"\nFinance Team Comments: ");
									tc_strcat(envDesc,comments);
									tc_strcat(envDesc,"\n\nRegards, ");
									tc_strcat(envDesc,"PLM Team\n\n");

									printf("\n\nMAIL_initialize\n\n");
									sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
									printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
									system(buff);
								}
							}
							else
							{
								printf("\n PC: ProfitCenterPostApprovalMail: Control Object Not Found \n");fflush(stdout);
							}
						}
						else
						{
							printf("\n PC: ControlObjects Query Tag Not Found \n");fflush(stdout);
						}
					}
				}
			}
		}
		else
		{
			printf("\n ---------------------------------------------- \n");fflush(stdout);
			printf("\n PC: decsn Not Matched...!! \n");fflush(stdout);
			printf("\n ---------------------------------------------- \n");fflush(stdout);
		}
	}
	
	return decision;
}

extern int Profit_Center_register_method(int *decision, va_list args)
{
	int status = ITK_ok;
	*decision=ALL_CUSTOMIZATIONS;

	status = EPM_register_action_handler ("PCPreApprovalMail","PCPreApprovalMail",(EPM_action_handler_t)PC_PreApprovalMail_Func);
	status = EPM_register_action_handler ("PCPostApprovalMail","PCPostApprovalMail",(EPM_action_handler_t)PC_PostApprovalMail_Func);
	status = EPM_register_action_handler ("PCFinanceHeadRejectEmail","PCFinanceHeadRejectEmail",(EPM_action_handler_t)PC_FinanceHeadRejectEmail_Func);
	status = EPM_register_action_handler ("PCRemove","PCRemove",(EPM_action_handler_t)PCRemove_Func);
    printf("\n Before Register Rule Handler...[PCFinanceHeadDecision]");fflush(stdout);
    status = EPM_register_rule_handler ("PCFinanceHeadDecision","PCFinanceHeadDecision",(EPM_rule_handler_t)PCFinanceHeadDecisionCmnt);
	printf("\n After Register Rule Handler...[PCFinanceHeadDecision]");fflush(stdout);
	
	return status;
}

extern DLLAPI int tm_Profit_Center_register_callbacks ()
{
	int ifail = ITK_ok;
	printf("\n [Profit_Center]Before register tm_Profit_Center...");fflush(stdout);
    ifail=CUSTOM_register_exit("tm_Profit_Center","USER_init_module",(CUSTOM_EXIT_ftn_t)Profit_Center_register_method);
	printf("\n [Profit_Center]After register tm_Profit_Center...");fflush(stdout);
    return ( ITK_ok );
}