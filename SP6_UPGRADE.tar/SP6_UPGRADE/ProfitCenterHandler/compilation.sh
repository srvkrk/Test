./compile tm_Profit_Center.c
./link_custom_exits tm_Profit_Center
chmod 777 *.o *.so
