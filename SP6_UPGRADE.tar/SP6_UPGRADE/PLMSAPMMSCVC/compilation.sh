./compile PLMSAPMMSCVC.c
./linkitk -o PLMSAPMMSCVC PLMSAPMMSCVC.o
chmod 777 *
