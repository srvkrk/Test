#include "malloc.h"
#include "stdio.h"
#include <ae/dataset.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <tc/envelope.h>
#include <fclasses/tc_date.h>
#include <user_exits/epm_toolkit_utils.h>
#include <cJSON.h>
#include <curl/curl.h>
#define MAX_LINE_LENGTH 1000

FILE* fsuccess;
FILE* fp=NULL;
FILE* finsp;
FILE* fval;

char fsuccess_name[200];
char fisa_name[200];
char fvac_name[200];

tag_t		*TaskRevision		= NULLTAG;
tag_t		TaskRevTag			= NULLTAG;
tag_t		*PartTags			= NULLTAG;

int tcount=0,pcount=0,TaskCnt=0,PartCnt=0;
char fsuccess_name[200];

int apl_dml_flag = 0;
int car_dml = 0;
int go_for_rfc = 0;
int flag_vc_v_tpl = 0;
int flag = 0;
int acc_flag = 0;

char *part_noDupDes=NULL;
char *part_noDupDesx=NULL;
char *MMSCSLocDup=NULL;
char *doc_no=NULL;
char *basic_division=NULL;
char *unit_wt=NULL;
char *volume=NULL;
char *vol_unit=NULL;
char *material_group=NULL;
char *doc_noDup=NULL;
char *dwg_typeDup=NULL;
char *tmpDrwNum1=NULL;
char *tmpDrwNum=NULL;
char *tmpDrwRev=NULL;
char *tmpDrwSeq=NULL;
char *dwg_revDup=NULL;
char *dwg_rev=NULL;
char *sizeDup=NULL;
char *sheet_noDup=NULL;
char *old_mat_no=NULL;
char *net_wt=NULL;
char *net_wtDup=NULL;
char *gross_wt=NULL;
char *part_noDup=NULL;
char *Plant_MakeBuy=NULL;
char *Plant_StoreLoc=NULL;
char *make_buy_indDup=NULL;
char *make_buy_ind=NULL;
char *mat_type=NULL;
char *store_loc=NULL;
char *store_locDup=NULL;
char *mrp_grp=NULL;
char *mrp_type=NULL;
char *abc_ind=NULL;
char *odstatus=NULL;
char *num;
char *drstatus = NULL;
char *drstatusDup = NULL;
char *mm_pp_status = NULL;
char *partClrIndDup = NULL;
char *partClrInd = NULL;
char *reord_pt = NULL;
char *quota_arrangement_usage = NULL;
char *mrp_controller = NULL;
char *lot_size_key = NULL;
char *fixed_lot_size = NULL;
char *max_stlvl = NULL;
char *blk_ind = NULL;
char *sched_mar_key = NULL;
char *req_grp = NULL;
char *period_ind = NULL;
char *mixedmrp = NULL;
char *cs1_val = NULL;
char *alternativb = NULL;
char *avail_chk = NULL;
char *splan_mat = NULL;
char *splan_plant = NULL;
char *splan_conv_fact = NULL;
char *ind_collect = NULL;
char *rep_mfg_in = NULL;
char *rep_mfg = NULL;
char *stock_det_group = NULL;
char *uoissue = NULL;
char *qua_ins_ind = NULL;
char *doc_req = NULL;
char *grptime = NULL;
char *certificate_type = NULL;
char *qm_proc_ind = NULL;
char *control_key = NULL;
char *catalog_prof = NULL;
char *valuation_cat = NULL;
char *price_con = NULL;
char *std_price = NULL;
char *moving_avg_price = NULL;
char *val_class = NULL;
char *mat_origin = NULL;
char *cost_lot_size = NULL;
char *variance_key = NULL;
char *with_quantity_structure = NULL;
char *costing_split_valuation = NULL;
char *costing_val_class = NULL;
char *MatCrChFlag = NULL;
char *dml_numAP1 = NULL;
char *PrtRevDup = NULL;
char *OrgIDDup = NULL;
char *plan_calendar = NULL;
char *profit_centre_sap = NULL;
char *overhd_grp = NULL;
char *dml_no_arg = NULL;
char *myzeroDup3 = NULL;
char *myzeroDup1 = NULL;
char *myzeroDup2 = NULL;
char *myzeroDup4 = NULL;
char *sap_msg = NULL;
char *p;

char *PrtRev=NULL;
char *dml_no = NULL;
char *plant = NULL;
char *PartNumber = NULL;
char *PartRev = NULL;
char *PartSeq = NULL;
char *Parttype = NULL;
char *Error_message = NULL;
char *MATstatus = NULL;
char *series=NULL;
char *PartMakeBuyInd=NULL;
char *DMLEcnType = NULL;
char *DMLRelStatus = NULL;
char *DMLNumDup = NULL;


char *plantcode=NULL;
char *profit_centre2=NULL;
char *plan_calendar2=NULL;
char *overhd_grp2=NULL;
char *origin_group2=NULL;
char *origin_group=NULL;
char *meas_unit=NULL;
char *desc=NULL;
char *descDup=NULL;
char *drg_ind=NULL;
char *drg_indDup=NULL;
char *docClass=NULL;
char *spl_proc_key=NULL;
char *OwnerNameDup=NULL;
char *OwnerName=NULL;
char *proc_type;

char *inputPart=NULL;
char *iPlantCode=NULL;
char *attrname=NULL;
char *attrnewval=NULL;
char *attroldval=NULL;
char *iSapServer=NULL;
char *sapreturnval=NULL;
char *attrjsonname=NULL;


char *sap_proc_type=NULL;
char *sap_spproc_type=NULL;
char *SAPpstat=NULL;
char *MRPpstat=NULL;
char pstat;
char pstat_mrp;
char pstat_acc;
char proc_Key;
char spl_Key;
char group;


#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)
void rfc_error(char *);
void cll_zbapi_material_savedata_mrp();
////#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
//void cll_zrfc_ac_view_create(void);
//void cll_zbapi_material_savedata_mrp(void);
//
//RFC_RC zbapi_material_savedata_mrp(RFC_HANDLE hRfc,BAPIMATHEAD *,BAPI_MARA *,BAPI_MARAX *,BAPI_MARC *,BAPI_MARCX *,BAPI_MPGD *,BAPI_MPGDX *,BAPI_MARD *,BAPI_MARDX *,BAPI_MBEW *,BAPI_MBEWX *,RMMG1_AENNR *,BAPIRET2 *,ITAB_H ,ITAB_H ,ITAB_H,ITAB_H ,ITAB_H ,char *);
//RFC_RC zbapi_material_savedata_mrpCreate(RFC_HANDLE hRfc,BAPIMATHEAD *eBapiMatHead,BAPI_MARA	*eBasicView,BAPI_MARAX	*eBasicViewx,BAPI_MARC	*eMrpView,BAPI_MARCX	*eMrpViewx,BAPI_MPGD	*eBapi_Mpgd,BAPI_MPGDX	*eBapi_Mpgdx,BAPI_MARD	*eBapi_Mard,BAPI_MARDX	*eBapi_Mardx,BAPI_MBEW	*eAccView,BAPI_MBEWX	*eAccViewx,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2 *eBapiret2,ITAB_H thBapi_Makt,ITAB_H thBapi_Marm,ITAB_H thBapi_Marmx,ITAB_H thBAPIE1PAREX3,ITAB_H thBAPIE1PAREXX3,char *xException);
//RFC_RC BAPI_MATERIAL_MARD(RFC_HANDLE hRfc,BAPIMATHEAD *eBapiMatHead,BAPI_MARD *eBapi_Mard,BAPI_MARDX *eBapi_Mardx,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2 *eBapiret2,char *xException);
//RFC_RC allocate_insp_type(void);
//RFC_RC allocate_insp_type_vc(void);
//
//RFC_RC cll_zrfc_insptype_alloc(RFC_HANDLE);
//RFC_RC vc_zrfc_insptype_alloc(RFC_HANDLE );
//int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3]);
//RFC_RC WIN_DLL_EXPORT_FLAGS zpprfc_revisionnum_change(RFC_HANDLE hRfc,AENNR *eAennr,CCMATNR *eMatnr,CC_REVLV *eRevlv,BAPIRET2 *iMessg,SYST_SUBRC *iRetval,char *xException);
//
//void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);
//void str2nbcd(char *str,unsigned char *bcd,size_t size,int decimals);

//int FetchPlantSpecificData(char* plantcode);
//int Part_CreateChangeFunction(tag_t LatestRev, char *SapServer);
void getTodayDate(char* StdDate);
//int Create_PLMSAP_audit_object ( char *iDmlTask, char *plant, char *PartNumber, char *PartRev, char *PartSeq,char *Parttype, char *Error_message, char *MATstatus);
int DATE_date_to_string (date_t date_struct, const char *format_str, char **date_str);
int EPM__parse_string (const char *pszInputString, char *pszSeparator, int *piStringCount, char ***pppStringList);
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))


static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}

//void F_OUTK(const char *text,const unsigned pos,const unsigned len,char*str)
//{
//  printf("%*.0s",pos,text);fflush(stdout); printf("%-*s : %s\n",len,text,str);fflush(stdout);
//  fprintf(fsuccess,"%*.0s",pos,text); fprintf(fsuccess,"%-*s : %s\n",len,text,str);
//  return;
//}

char* subString(char* mainStringf ,int fromCharf ,int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}

void getTodayDate(char* StdDate)
{
	struct tm *Sys_T = NULL;
	int Month;
	int Day;
	int Year;
	int hour;
	int min;
	int sec;

	time_t Tval = 0;
	Tval = time(NULL);
	Sys_T = localtime(&Tval);
	Day=Sys_T->tm_mday;
	Month=Sys_T->tm_mon+1;
	Year=1900 + Sys_T->tm_year;
	hour = Sys_T->tm_hour;
	min = Sys_T->tm_min;
	sec = Sys_T->tm_sec;

	sprintf(StdDate,"%02d%02d%02d",Month,Day,Year);
	printf("\nDate:[%s]",StdDate); fflush(stdout);
}

void getCurrentDateTime(char cCurrentAccessDate[20])
{
        int ch;
        time_t temp;
        struct tm *timeptr;
        char pAccessDate[20];
        char    DateS[4];
        printf("getCurrentDateTime calling..........\n");
        temp = time(NULL);
        tc_strcpy(pAccessDate,"");
        timeptr = (struct tm *)localtime(&temp);
        ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
        tc_strcpy(cCurrentAccessDate,pAccessDate);
        printf("cCurrentAccessDate:%s\n",cCurrentAccessDate);

        printf("Date:%d\n",(timeptr->tm_mday));
        printf("Month:%d\n",(timeptr->tm_mon)+1);
        printf("Year:%d\n",(timeptr->tm_year+1900));
        fflush(stdout);
}


struct memory {
  char *response;
  size_t size;
};

static size_t WriteCallback(char *data, size_t size, size_t nmemb, void *clientp)
{
  size_t realsize = size * nmemb;
  struct memory *mem = (struct memory *)clientp;
 
  char *ptr = realloc(mem->response, mem->size + realsize + 1);
  if(!ptr)
    return 0;  /* out of memory */
 
  mem->response = ptr;
  memcpy(&(mem->response[mem->size]), data, realsize);
  mem->size += realsize;
  mem->response[mem->size] = 0;
  
  printf("\nWriteCallback done"); fflush(stdout);
 
  return realsize;
}

int parse_json_object(const char *json_string,char *ParseType)
{
    int i = 0;
	cJSON *json = cJSON_Parse(json_string);
	if (json == NULL) 
	{ 
        const char *error_ptr = cJSON_GetErrorPtr(); 
        if (error_ptr != NULL) 
		{ 
            printf("Error: %s\n", error_ptr); 
        } 
        cJSON_Delete(json); 
        return 1; 
    } 
	printf("\njson_string : [%s]\n\n",json_string);//to see complete response
	printf("\ncJSON_GetArraySize(json) : [%d]\n\n",cJSON_GetArraySize(json));
	
	printf ("\nParseType : [%s]",ParseType);
	if ( tc_strcmp ( ParseType, "INSP_CREATE" ) == 0 )
	{
		const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZRFC_INSPTYPE_ALLOCResponse");
		const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "MESSG");
			
		for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
		{
			char *tm_Message = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
			printf("\n @@@@@@@@@@@@ INSPECTION ALLOCATION STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			printf("\n INSPTYPE_ALLOC_Message: [%s]\n", tm_Message);fflush(stdout);
			printf("\n SAP Msg for Material Inspection Allocation: [%s]\n", tm_Message);fflush(stdout);
			printf("\n @@@@@@@@@@@@ INSPECTION ALLOCATION STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
		}
	}
	else if ( tc_strcmp ( ParseType, "Batch_Create" ) == 0 )
	{
		const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZRFC_AC_VIEW_CREATEResponse");
		const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "MESSG");
			
		for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
		{
			char *tm_Type = cJSON_GetObjectItem(moon_2, "SYSTEM")->valuestring;
			char *tm_Message = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
			printf("\ntm_Type: [%s]\n", tm_Type);fflush(stdout);
			printf("\nZRFC_AC_VIEW_CREATE_Message: [%s]\n", tm_Message);fflush(stdout);
		}
	}
	/* else if ( tc_strcmp ( ParseType, "PSTAT" ) == 0 )
	{
		//const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "get_pstat_from_sapResponse");
		const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALL");
		const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "RETURN");
			
		for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
		{
			char *tm_Type = cJSON_GetObjectItem(moon_2, "SYSTEM")->valuestring;
			char *tm_Message = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
			printf("\ntm_Type: [%s]\n", tm_Type);fflush(stdout);
			printf("\nget_pstat_from_sap_Message: [%s]\n", tm_Message);fflush(stdout);
		}
	} */
	else if ( tc_strcmp ( ParseType, "PSTAT" ) == 0 )
	{
		printf("\njson_string : [%s]\n\n",json_string);
		if( tc_strstr(json_string ,"BAPI_MATERIAL_GETALLResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALLResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "CLIENTDATA");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_KStatMessage = cJSON_GetObjectItem(moon_2, "MAINT_STAT")->valuestring;
			    printf("\n K-Flag Message: [%s]\n", tm_KStatMessage);fflush(stdout);
			}
		}
		if( tc_strstr(json_string ,"BAPI_MATERIAL_GETALLResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALLResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "PLANTDATA");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_DStatMessage = cJSON_GetObjectItem(moon_2, "MAINT_STAT")->valuestring;
			    printf("\n D-Flag Message: [%s]\n", tm_DStatMessage);fflush(stdout);
			}
		}
		if( tc_strstr(json_string ,"BAPI_MATERIAL_GETALLResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALLResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "VALUATIONDATA");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_BStatMessage = cJSON_GetObjectItem(moon_2, "MAINT_STAT")->valuestring;
			    printf("\n B-Flag Message: [%s]\n", tm_BStatMessage);fflush(stdout);
			}
		}
	}
	else if ( tc_strcmp ( ParseType, "MAT_CREATE_CHANGE" ) == 0 )
	{
		printf("\njson_string : [%s]\n\n",json_string);
		if( tc_strstr(json_string ,"ZBAPI_MATERIAL_SAVEDATAResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZBAPI_MATERIAL_SAVEDATAResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "RETURN");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_matcrexmsg = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
				printf("\n @@@@@@@@@@@@ MATERIAL CREATE/EXTEND STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			    printf("\n SAP Msg for Material Create/Extend: [%s]\n", tm_matcrexmsg);fflush(stdout);
				printf("\n @@@@@@@@@@@@ MATERIAL CREATE/EXTEND STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			}
		}
	}
	else if ( tc_strcmp ( ParseType, "CHANGE_NO" ) == 0 )
	{
		printf("\njson_string : [%s]\n\n",json_string);
		if( tc_strstr(json_string ,"addition") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "addition");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "CcapEcnCreate_Exception");	
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_changename = cJSON_GetObjectItem(moon_2, "Name")->valuestring;
				char *tm_changetext = cJSON_GetObjectItem(moon_2, "Text")->valuestring;
				printf("\n @@@@@@@@@@@@ CHANGE_NO CREATE STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
				printf("\n Change_No Name: [%s]\n", tm_changename);fflush(stdout);
				printf("\n Change_No Text: [%s]\n", tm_changetext);fflush(stdout);
				printf("\n SAP Msg for Change_no Create/Extend: Change_no already maintained for this transaction/event\n");fflush(stdout);
				printf("\n @@@@@@@@@@@@ CHANGE_NO CREATE STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			}
		}
		else
		{
			//const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "CcapEcnCreate");
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "CcapEcnCreateResponse");
			for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				printf("\n @@@@@@@@@@@@ CHANGE_NO CREATE STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
				char *tm_material = cJSON_GetObjectItem(moon_1, "ChangeNo")->valuestring;
				printf("\n Change_No [%s]\n", tm_material);fflush(stdout);
				printf("\n SAP Msg for Change_no Create/Extend: Transaction Completed Succesfully...\n");fflush(stdout);
				printf("\n @@@@@@@@@@@@ CHANGE_NO CREATE STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			}
		}
	}
	else if( tc_strcmp ( ParseType, "GETALL" ) == 0 )
	{
		printf("\njson_string : [%s]\n\n",json_string);
		if( tc_strstr(json_string ,"BAPI_MATERIAL_GETALLResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALLResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "PLANTDATA");

			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				sapreturnval = cJSON_GetObjectItem(moon_2, attrjsonname)->valuestring;
			}
			printf("\n #---------- In[parse_json_object] -----------#");
			printf("\n Attribute Return value From SAP: [%s]",sapreturnval);
			printf("\n #---------- In[parse_json_object] -----------#");
		}
	}
        
	return 0;
}

void print_json_object(const char *json_string)
{
    cJSON *json = cJSON_Parse(json_string);
    char *formatted_json = cJSON_Print(json);
    printf("%s\n", formatted_json);
    cJSON_Delete(json);
    free(formatted_json);
}

/*struct memory {
  char *response;
  size_t size;
};

static size_t WriteCallback(char *data, size_t size, size_t nmemb, void *clientp)
{
  size_t realsize = size * nmemb;
  struct memory *mem = (struct memory *)clientp;
 
  char *ptr = realloc(mem->response, mem->size + realsize + 1);
  if(!ptr)
    return 0;
 
  mem->response = ptr;
  memcpy(&(mem->response[mem->size]), data, realsize);
  mem->size += realsize;
  mem->response[mem->size] = 0;
  
  printf("\nWriteCallback done"); fflush(stdout);
 
  return realsize;
}

int parse_json_object(const char *json_string,char *ParseType) 
{
    int i = 0;
	cJSON *json = cJSON_Parse(json_string);
	if (json == NULL) 
	{ 
        const char *error_ptr = cJSON_GetErrorPtr(); 
        if (error_ptr != NULL) 
		{ 
            printf("Error: %s\n", error_ptr); 
        } 
        cJSON_Delete(json); 
        return 1; 
    } 
	printf("\njson_string : [%s]\n\n",json_string);
	printf("\ncJSON_GetArraySize(json) : [%d]\n\n",cJSON_GetArraySize(json));
	
	printf ("\nParseType : [%s]",ParseType);
	if( tc_strcmp ( ParseType, "MAT_CREATE_CHANGE" ) == 0 )
	{
		printf("\njson_string : [%s]\n\n",json_string);
		if( tc_strstr(json_string ,"ZBAPI_MATERIAL_SAVEDATAResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZBAPI_MATERIAL_SAVEDATAResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "RETURN");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_matcrexmsg = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
				printf("\n @@@@@@@@@@@@ MATERIAL CREATE/EXTEND STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			    printf("\n SAP Msg for Material Create/Extend: [%s]\n", tm_matcrexmsg);fflush(stdout);
				printf("\n @@@@@@@@@@@@ MATERIAL CREATE/EXTEND STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			}
		}
	}
	else
	{
		printf("\n ------------ ParseType Not Matched --------------\n");fflush(stdout);
	}
			
	return 0;
} 

void print_json_object(const char *json_string)
{
    cJSON *json = cJSON_Parse(json_string);
    char *formatted_json = cJSON_Print(json);
    printf("%s\n", formatted_json);
    cJSON_Delete(json);
    free(formatted_json);
}*/

int tm_curl_matreupdate ( char *data )
{
	struct memory chunk = {0};
	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\n Failed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	printf("\n >>> iSapServer:  [%s]", iSapServer);fflush(stdout);
	
	if ( tc_strcmp ( iSapServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n iSapServer is Blank..!!");fflush(stdout);
	}
	
	list = curl_slist_append(list, "Content-Type: application/json");
    
	printf("\nFile request content as below "); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
	printf("\ncurl_easy_setopt"); fflush(stdout);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	printf("\ncurl_easy_perform");fflush(stdout);
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "MAT_CREATE_CHANGE");
	
	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
	printf("\nfree"); fflush(stdout);
	
	curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}

int cll_matreupdate(char *part_noDup, char *plantcode, char *attrjsnnme, char *attrnval, char *attroval, char *sapratval, char *json_matreupdate_req_obj)
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *CLIENTDATA_req;
	cJSON *CLIENTDATAX_req;
	cJSON *EXTENSIONIN_req;
	cJSON *EXTENSIONINX_req;
	cJSON *item1_req;
	cJSON *item2_req;
	
	
	cJSON *FORECASTPARAMETERS_req;
	cJSON *FORECASTPARAMETERSX_req;
	
	cJSON *HEADDATA_req;
	
	cJSON *INTERNATIONALARTNOS_req;
	cJSON *item3_req;
	
	cJSON *MATERIALDESCRIPTION_req;
	cJSON *item4_req;
	
	
	cJSON *MATERIALLONGTEXT_req;
	cJSON *item5_req;
	
	cJSON *PLANNINGDATA_req;
	cJSON *PLANNINGDATAX_req;
	
	cJSON *PLANTDATA_req;
	cJSON *PLANTDATAX_req;
	
	cJSON *PRTDATA_req;
	cJSON *item6_req;

	cJSON *PRTDATAX_req;
	cJSON *item7_req;
	
	cJSON *RETURNMESSAGES_req;
	cJSON *item8_req;

	cJSON *SALESDATA_req;
	cJSON *SALESDATAX_req;

	cJSON *STORAGELOCATIONDATA_req;
	cJSON *STORAGELOCATIONDATAX_req;

	cJSON *STORAGETYPEDATA_req;
	cJSON *STORAGETYPEDATAX_req;

	cJSON *TAXCLASSIFICATIONS_req;
	cJSON *item9_req;
	
	cJSON *UNITSOFMEASURE_req;
	cJSON *item10_req;
	
	cJSON *UNITSOFMEASUREX_req;
	cJSON *item11_req;

	cJSON *VALUATIONDATA_req;
	cJSON *VALUATIONDATAX_req;

	cJSON *WAREHOUSENUMBERDATA_req;
	cJSON *WAREHOUSENUMBERDATAX_req;
		
	
	
	char *out;
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	CLIENTDATA_req = cJSON_CreateObject();
	CLIENTDATAX_req = cJSON_CreateObject();
	
	EXTENSIONIN_req = cJSON_CreateObject();
	EXTENSIONINX_req = cJSON_CreateObject();
	item1_req = cJSON_CreateObject();
	item2_req = cJSON_CreateObject();
	
	HEADDATA_req = cJSON_CreateObject();
	
	FORECASTPARAMETERS_req = cJSON_CreateObject();
	FORECASTPARAMETERSX_req = cJSON_CreateObject();
	
	INTERNATIONALARTNOS_req = cJSON_CreateObject();
	item3_req = cJSON_CreateObject();
	
	MATERIALDESCRIPTION_req = cJSON_CreateObject();
	item4_req = cJSON_CreateObject();
	
	MATERIALLONGTEXT_req = cJSON_CreateObject();
	item5_req = cJSON_CreateObject();
	
	PLANNINGDATA_req = cJSON_CreateObject();
	PLANNINGDATAX_req = cJSON_CreateObject();
	
	PLANTDATA_req = cJSON_CreateObject();
	PLANTDATAX_req = cJSON_CreateObject();
	
	PRTDATA_req = cJSON_CreateObject();
	item6_req = cJSON_CreateObject();
	
	PRTDATAX_req = cJSON_CreateObject();
	item7_req = cJSON_CreateObject();
	
	RETURNMESSAGES_req = cJSON_CreateObject();
	item8_req = cJSON_CreateObject();
	
	
	SALESDATA_req = cJSON_CreateObject();
	SALESDATAX_req = cJSON_CreateObject();
	
	STORAGELOCATIONDATA_req = cJSON_CreateObject();
	STORAGELOCATIONDATAX_req = cJSON_CreateObject();
	
	STORAGETYPEDATA_req = cJSON_CreateObject();
	STORAGETYPEDATAX_req = cJSON_CreateObject();
	
	TAXCLASSIFICATIONS_req = cJSON_CreateObject();
	item9_req = cJSON_CreateObject();
	
	UNITSOFMEASURE_req = cJSON_CreateObject();
	item10_req = cJSON_CreateObject();
	
	UNITSOFMEASUREX_req = cJSON_CreateObject();
	item11_req = cJSON_CreateObject();
	
	VALUATIONDATA_req = cJSON_CreateObject();
	VALUATIONDATAX_req = cJSON_CreateObject();
	
	WAREHOUSENUMBERDATA_req = cJSON_CreateObject();
	WAREHOUSENUMBERDATAX_req = cJSON_CreateObject();
	
	
	cJSON_AddItemToObject(rfc_root, "ZBAPI_MATERIAL_SAVEDATA", exp_imp_tab_req);
	cJSON_AddItemToObject(exp_imp_tab_req, "CHANGE_NUMBER", cJSON_CreateString("CORRCT211125"));
		
	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATA", CLIENTDATA_req);
	cJSON_AddItemToObject(CLIENTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "OLD_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATA_req, "DOCUMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_TYPE" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATA_req, "DOC_VERS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_FORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGE_NO" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATA_req, "NO_SHEETS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGEFORMAT" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATA_req, "SIZE_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NET_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DIVISION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QTY_GR_GI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CAD_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLOWED_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLWD_VOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WT_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VOL_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "FILL_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STACK_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATA_req, "QM_PROCMNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CATPROFILE" , cJSON_CreateString(""));		
	cJSON_AddItemToObject(CLIENTDATA_req, "MINREMLIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SHELF_LIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_PCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATCMPLLVL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ANP" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATAX", CLIENTDATAX_req);
	cJSON_AddItemToObject(CLIENTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "OLD_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATAX_req, "DOCUMENT" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_TYPE" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_VERS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_FORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGE_NO" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATAX_req, "NO_SHEETS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGEFORMAT" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATAX_req, "SIZE_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NET_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DIVISION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QTY_GR_GI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CAD_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLOWED_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLWD_VOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WT_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VOL_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "FILL_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STACK_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
    cJSON_AddItemToObject(CLIENTDATAX_req, "QM_PROCMNT" , cJSON_CreateString(""));		
    cJSON_AddItemToObject(CLIENTDATAX_req, "CATPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MINREMLIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SHELF_LIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_PCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATCMPLLVL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ANP" , cJSON_CreateString(""));
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_CAD_CALL", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_ONLINE", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "HEADDATA", HEADDATA_req);
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL" , cJSON_CreateString(part_noDup));
	cJSON_AddItemToObject(HEADDATA_req, "IND_SECTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "BASIC_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "SALES_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PURCHASE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MRP_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "FORECAST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "WORK_SCHED_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PRT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "STORAGE_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "WAREHOUSE_VIEW" , cJSON_CreateString(""));
    cJSON_AddItemToObject(HEADDATA_req, "QUALITY_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "ACCOUNT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "COST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "INP_FLD_CHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_VERSION" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALDESCRIPTION", MATERIALDESCRIPTION_req);
	cJSON_AddItemToObject(MATERIALDESCRIPTION_req, "item" , item4_req);
	cJSON_AddItemToObject(item4_req, "LANGU" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "LANGU_ISO" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "MATL_DESC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item4_req, "DEL_FLAG" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATA", PLANTDATA_req);
	cJSON_AddItemToObject(PLANTDATA_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(PLANTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));	
	if(tc_strcmp(attrjsnnme,"ABC_ID")==0)
    {
	    if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)!=0))
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "ABC_ID" , cJSON_CreateString(""));
		}
		else if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)==0))
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "ABC_ID" , cJSON_CreateString(attroval));
		}
		else
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "ABC_ID" , cJSON_CreateString(""));
		}
	}
	else
	{
	  cJSON_AddItemToObject(PLANTDATA_req, "ABC_ID" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRPPROFILE" , cJSON_CreateString(""));
	if(tc_strcmp(attrjsnnme,"MRP_TYPE")==0)
    {
	    if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)!=0))
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "MRP_TYPE" , cJSON_CreateString(""));
		}
		else if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)==0))
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "MRP_TYPE" , cJSON_CreateString(attroval));
		}
		else
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "MRP_TYPE" , cJSON_CreateString(""));
		}
	}
	else
	{
	  cJSON_AddItemToObject(PLANTDATA_req, "MRP_TYPE" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_CTRLER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLND_DELRY" , cJSON_CreateString(""));
	if(tc_strcmp(attrjsnnme,"GR_PR_TIME")==0)
    {
	    if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)!=0))
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(""));
		}
		else if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)==0))
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(attroval));
		}
		else
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(""));
		}
	}
	else
	{
	  cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(""));
	}	
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ASSY_SCRAP" , cJSON_CreateString(""));
	if(tc_strcmp(attrjsnnme,"LOTSIZEKEY")==0)
    {
	    if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)!=0))
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "LOTSIZEKEY" , cJSON_CreateString(""));
		}
		else if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)==0))
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "LOTSIZEKEY" , cJSON_CreateString(attroval));
		}
		else
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "LOTSIZEKEY" , cJSON_CreateString(""));
		}
	}
	else
	{
	  cJSON_AddItemToObject(PLANTDATA_req, "LOTSIZEKEY" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SPPROCTYPE" , cJSON_CreateString(""));
	if(tc_strcmp(attrjsnnme,"REORDER_PT")==0)
    {
	    if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)!=0))
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "REORDER_PT" , cJSON_CreateString(""));
		}
		else if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)==0))
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "REORDER_PT" , cJSON_CreateString(attroval));
		}
		else
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "REORDER_PT" , cJSON_CreateString(""));
		}
	}
	else
	{
	  cJSON_AddItemToObject(PLANTDATA_req, "REORDER_PT" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MINLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAXLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FIXED_LOT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_VAL" , cJSON_CreateString(""));
	if(tc_strcmp(attrjsnnme,"MAX_STOCK")==0)
    {
	    if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)!=0))
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "MAX_STOCK" , cJSON_CreateString(""));
		}
		else if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)==0))
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "MAX_STOCK" , cJSON_CreateString(attroval));
		}
		else
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "MAX_STOCK" , cJSON_CreateString(""));
		}
	}
	else
	{
	  cJSON_AddItemToObject(PLANTDATA_req, "MAX_STOCK" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "ORD_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEP_REQ_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ALT_BOM_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "GRP_REQMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIXED_MRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SM_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUPTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INTEROP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INHSEPRODT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGEPERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNDER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLENTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLACE_PT" , cJSON_CreateString(""));
    cJSON_AddItemToObject(PLANTDATA_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DOC_REQD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QUOTAUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SERV_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SPLIT_IND" , cJSON_CreateString(""));
	if(tc_strcmp(attrjsnnme,"AVAILCHECK")==0)
    {
	    if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)!=0))
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "AVAILCHECK" , cJSON_CreateString(""));
		}
		else if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)==0))
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "AVAILCHECK" , cJSON_CreateString(attroval));
		}
		else
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "AVAILCHECK" , cJSON_CreateString(""));
		}
	}
	else
	{
	  cJSON_AddItemToObject(PLANTDATA_req, "AVAILCHECK" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUP_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY_PLAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SHIP_PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROFIT_CTR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PPC_PL_CAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REP_MANUF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPMANPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PL_TI_FNCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISS_ST_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMP_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CERT_TYPE" , cJSON_CreateString(""));		
	cJSON_AddItemToObject(PLANTDATA_req, "CYCLE_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "VARIANCE_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SERNO_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MULT_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INSP_INT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLAN_STRGP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SLOC_EXPRC" , cJSON_CreateString(""));
	if(tc_strcmp(attrjsnnme,"BULK_MAT")==0)
    {
	    if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)!=0))
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "BULK_MAT" , cJSON_CreateString(""));
		}
		else if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)==0))
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "BULK_MAT" , cJSON_CreateString(attroval));
		}
		else
		{
		  cJSON_AddItemToObject(PLANTDATA_req, "BULK_MAT" , cJSON_CreateString(""));
		}
	}
	else
	{
	  cJSON_AddItemToObject(PLANTDATA_req, "BULK_MAT" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DETERM_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUR_STATUS" , cJSON_CreateString(" "));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETYTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEPLOY_HORIZ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FIX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_INCREMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATAX", PLANTDATAX_req);
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	if(tc_strcmp(attrjsnnme,"ABC_ID")==0)
    {
	    if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)!=0))
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "ABC_ID" , cJSON_CreateString(""));
		}
		else if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)==0))
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "ABC_ID" , cJSON_CreateString("X"));
		}
		else
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "ABC_ID" , cJSON_CreateString(""));
		}
	}
	else
	{
	  cJSON_AddItemToObject(PLANTDATAX_req, "ABC_ID" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRPPROFILE" , cJSON_CreateString(""));
	if(tc_strcmp(attrjsnnme,"MRP_TYPE")==0)
    {
	    if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)!=0))
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "MRP_TYPE" , cJSON_CreateString(""));
		}
		else if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)==0))
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "MRP_TYPE" , cJSON_CreateString("X"));
		}
		else
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "MRP_TYPE" , cJSON_CreateString(""));
		}
	}
	else
	{
	  cJSON_AddItemToObject(PLANTDATAX_req, "MRP_TYPE" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_CTRLER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLND_DELRY" , cJSON_CreateString(""));
	if(tc_strcmp(attrjsnnme,"GR_PR_TIME")==0)
    {
	    if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)!=0))
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString(""));
		}
		else if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)==0))
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString("X"));
		}
		else
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString(""));
		}
	}
	else
	{
	  cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ASSY_SCRAP" , cJSON_CreateString(""));
	if(tc_strcmp(attrjsnnme,"LOTSIZEKEY")==0)
    {
	    if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)!=0))
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "LOTSIZEKEY" , cJSON_CreateString(""));
		}
		else if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)==0))
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "LOTSIZEKEY" , cJSON_CreateString("X"));
		}
		else
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "LOTSIZEKEY" , cJSON_CreateString(""));
		}
	}
	else
	{
	  cJSON_AddItemToObject(PLANTDATAX_req, "LOTSIZEKEY" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPPROCTYPE" , cJSON_CreateString(""));
	if(tc_strcmp(attrjsnnme,"REORDER_PT")==0)
    {
	    if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)!=0))
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
		}
		else if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)==0))
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "REORDER_PT" , cJSON_CreateString("X"));
		}
		else
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
		}
	}
	else
	{
	  cJSON_AddItemToObject(PLANTDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MINLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAXLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIXED_LOT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_VAL" , cJSON_CreateString(""));
	if(tc_strcmp(attrjsnnme,"MAX_STOCK")==0)
    {
	    if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)!=0))
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "MAX_STOCK" , cJSON_CreateString(""));
		}
		else if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)==0))
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "MAX_STOCK" , cJSON_CreateString("X"));
		}
		else
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "MAX_STOCK" , cJSON_CreateString(""));
		}
	}
	else
	{
	  cJSON_AddItemToObject(PLANTDATAX_req, "MAX_STOCK" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "ORD_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEP_REQ_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALT_BOM_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "GRP_REQMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIXED_MRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SM_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUPTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INTEROP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INHSEPRODT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGEPERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNDER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLENTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLACE_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_KEY" , cJSON_CreateString(""));
    cJSON_AddItemToObject(PLANTDATAX_req, "DOC_REQD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QUOTAUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERV_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPLIT_IND" , cJSON_CreateString(""));
	if(tc_strcmp(attrjsnnme,"AVAILCHECK")==0)
    {
	    if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)!=0))
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "AVAILCHECK" , cJSON_CreateString(""));
		}
		else if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)==0))
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "AVAILCHECK" , cJSON_CreateString("X"));
		}
		else
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "AVAILCHECK" , cJSON_CreateString(""));
		}
	}
	else
	{
	  cJSON_AddItemToObject(PLANTDATAX_req, "AVAILCHECK" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUP_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY_PLAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SHIP_PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROFIT_CTR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PPC_PL_CAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REP_MANUF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PL_TI_FNCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISS_ST_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMP_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CERT_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CYCLE_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "VARIANCE_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERNO_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPMANPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MULT_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INSP_INT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLAN_STRGP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SLOC_EXPRC" , cJSON_CreateString(""));
	if(tc_strcmp(attrjsnnme,"BULK_MAT")==0)
    {
	    if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)!=0))
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "BULK_MAT" , cJSON_CreateString(""));
		}
		else if((tc_strcmp(attroval,sapratval)!=0) && (tc_strcmp(attrnval,sapratval)==0))
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "BULK_MAT" , cJSON_CreateString("X"));
		}
		else
		{
		  cJSON_AddItemToObject(PLANTDATAX_req, "BULK_MAT" , cJSON_CreateString(""));
		}
	}
	else
	{
	  cJSON_AddItemToObject(PLANTDATAX_req, "BULK_MAT" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DETERM_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
    cJSON_AddItemToObject(PLANTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETYTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEPLOY_HORIZ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_INCREMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "RETURNMESSAGES", RETURNMESSAGES_req);
	cJSON_AddItemToObject(RETURNMESSAGES_req, "item", item8_req);
	cJSON_AddItemToObject(item8_req, "TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "NUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_MSG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "PARAMETER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ROW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "FIELD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "SYSTEM" , cJSON_CreateString(""));
	
	/* 
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATA" , STORAGELOCATIONDATA_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "INV_CORR_FAC" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATAX" , STORAGELOCATIONDATAX_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "INV_CORR_FAC" , cJSON_CreateString("")); */
	
	/*cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASURE" , UNITSOFMEASURE_req);
	cJSON_AddItemToObject(UNITSOFMEASURE_req, "item" , item10_req);
	cJSON_AddItemToObject(item10_req, "ALT_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "ALT_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "NUMERATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "DENOMINATR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "GROSS_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString(""));

	
	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASUREX" , UNITSOFMEASUREX_req);
	cJSON_AddItemToObject(UNITSOFMEASUREX_req, "item" , item11_req);
	cJSON_AddItemToObject(item11_req, "ALT_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "ALT_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "NUMERATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "DENOMINATR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "GROSS_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString("")); */
	
	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATA" , VALUATIONDATA_req);
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_AREA" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOVING_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CLASS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "FUTURE_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLND_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEVAL_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "OVERHEAD_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "QTY_STRUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MAT_ORIGIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAX_CML_UN" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATAX" , VALUATIONDATAX_req);
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_AREA" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOVING_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CLASS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "FUTURE_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLND_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEVAL_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "OVERHEAD_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "QTY_STRUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MAT_ORIGIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAX_CML_UN" , cJSON_CreateString(""));
	    
		
	out = cJSON_Print(rfc_root);
	tc_strcpy(json_matreupdate_req_obj,out);
	printf("%s\n", out);
	free(out);
	cJSON_Delete(rfc_root);

	return 0;
}

/* int parse_json_object(const char *json_string,char *ParseType)
{
    int i = 0;
        cJSON *json = cJSON_Parse(json_string);
        if (json == NULL)
        {
        const char *error_ptr = cJSON_GetErrorPtr();
        if (error_ptr != NULL)
                {
            printf("Error: %s\n", error_ptr);
        }
        cJSON_Delete(json);
        return 1;
    }
        printf("\njson_string : [%s]\n\n",json_string);
        printf("\ncJSON_GetArraySize(json) : [%d]\n\n",cJSON_GetArraySize(json));

        printf ("\nParseType : [%s]",ParseType);

        if( tc_strcmp ( ParseType, "PSTAT" ) == 0 )
        {
			printf("\njson_string : [%s]\n\n",json_string);
			if( tc_strstr(json_string ,"BAPI_MATERIAL_GETALLResponse") != NULL )
			{
				const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALLResponse");
				const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "PLANTDATA");

				for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
				{
					sapreturnval = cJSON_GetObjectItem(moon_2, attrjsonname)->valuestring;
				}
				printf("\n #---------- In[parse_json_object] -----------#");
				printf("\n Attribute Return value From SAP: [%s]",sapreturnval);
				printf("\n #---------- In[parse_json_object] -----------#");
			}
        }
        else
        {
            printf("\n Returned JSON Object Not Valid..!!");
        }

        return 0;
} 

void print_json_object(const char *json_string)
{
    cJSON *json = cJSON_Parse(json_string);
    char *formatted_json = cJSON_Print(json);
    printf("Formatted json_object: [%s]\n", formatted_json);
    cJSON_Delete(json);
    free(formatted_json);
}*/

 int tm_PLM_BAPI_MATERIAL_GETALL ( char *data )
{
    struct memory chunk = {0};
    char* response;
    CURLcode res;
    CURL *curl = curl_easy_init();
    if (!curl)
    {
       printf("\n Failed To Initialize CURL..!!");
       return 0;
    }

	struct curl_slist *list = NULL;
	printf("\n >>> iSapServer:  [%s]", iSapServer);fflush(stdout);
	
	if ( tc_strcmp ( iSapServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_BAPI_MATERIAL_GETALL_CV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_BAPI_MATERIAL_GETALL_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_BAPI_MATERIAL_GETALL_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n iSapServer is Blank..!!");fflush(stdout);
	}

	list = curl_slist_append(list, "Content-Type: application/json");

	printf("\nFile request content as below "); fflush(stdout);

	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

	printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);

	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);

	printf("\ncurl_easy_setopt"); fflush(stdout);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);

	printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);

	res = curl_easy_perform(curl);

	printf("\ncurl_easy_perform");fflush(stdout);
	printf("\nprint_json_object"); fflush(stdout);

	parse_json_object(chunk.response, "GETALL");

	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);

	printf("\nfree"); fflush(stdout);

	curl_easy_cleanup(curl);

	printf("\ncurl_easy_cleanup"); fflush(stdout);

	return 0;
}


 int cll_PLM_BAPI_MATERIAL_GETALL( char *part_noDup, char *plantcode , char *json_pstat_req_obj )
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	char *out;

	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();

	cJSON_AddItemToObject(rfc_root, "BAPI_MATERIAL_GETALL", exp_imp_tab_req);
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIAL", cJSON_CreateString(part_noDup));
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANT", cJSON_CreateString(plantcode));

	out = cJSON_Print(rfc_root);
	printf("Request Object For PLMSAP System Tag: [%s]\n", out);
	tc_strcpy( json_pstat_req_obj, out ) ;
	free(out);
	cJSON_Delete(rfc_root);

	return 0;
}

extern int ITK_user_main(int argc, char ** argv )
{
    int status;
	int kk=0;
	int is=0;
	int sflag=0;
	int i=0;
	int doccount=0;
	int len=0;
	int Refcount=0;
	int resultCount =0;
	int n_entries = 2;
	int n_tags_found = 1;
	int num_to_sort = 1;
	int sort_order[1]  ={2};
	char *keysAttr[1] = {"creation_date"};

	tag_t queryTag = NULLTAG;
	tag_t docOPtr = NULLTAG;
	tag_t *outTag = NULLTAG;
	tag_t resultOutputTag = NULLTAG;
	tag_t LatestRev=NULLTAG;
    tag_t docRelObjs=NULLTAG;
    tag_t *docObjs=NULLTAG;
    tag_t *refdocObjs=NULLTAG;
    tag_t doctag=NULLTAG;
    tag_t docRelObj=NULLTAG;
    tag_t refdocRelObj=NULLTAG;
	tag_t		*DesignTags			= NULLTAG;
	tag_t		PartMasterTag		= NULLTAG;

	char* sUserName	= NULL;
	char* sPassword = NULL;
	char *LatRevName=NULL;
	char *part_type=NULL;
	char *unit=NULL;
	char *part_typeDup=NULL;
	char *unitDup=NULL;
	char *doc_no=NULL;
	char *PrtRev=NULL;
	char* PartRelStatus = NULL;
	char *Lcs = NULL;
	char *SapServer = NULL;

	//static RFC_RC RfcRc;
	const char *attrs[2];
	const char *values[2];

    plantcode=(char *) malloc (500 * sizeof(char));
	profit_centre2 = (char *)malloc(500 * sizeof(char));
	plan_calendar2 = (char *)malloc(500 * sizeof(char));
	overhd_grp2 = (char *)malloc(500 * sizeof(char));
	origin_group2 = (char *)malloc(500 * sizeof(char));
	origin_group = (char *)malloc(500 * sizeof(char));
	mat_type=(char *) malloc(500 * sizeof(char));
	meas_unit=(char *) malloc(500 * sizeof(char));

	tmpDrwNum = (char *)malloc(500 * sizeof(char));
	tmpDrwNum1 = (char *)malloc(500 * sizeof(char));
	tmpDrwRev = (char *)malloc(500 * sizeof(char));
	tmpDrwSeq = (char *)malloc(500 * sizeof(char));

	sap_proc_type = (char *)malloc(500 * sizeof(char));
	sap_spproc_type = (char *)malloc(500 * sizeof(char));
	SAPpstat = (char *)malloc(500 * sizeof(char));
	MRPpstat = (char *)malloc(500 * sizeof(char));
	myzeroDup1 = (char *)malloc(500 * sizeof(char));
	myzeroDup2 = (char *)malloc(500 * sizeof(char));
	myzeroDup3 = (char *)malloc(500 * sizeof(char));
	myzeroDup4 = (char *)malloc(500 * sizeof(char));
	std_price = (char *)malloc(500 * sizeof(char));
	moving_avg_price = (char *)malloc(500 * sizeof(char));
	cost_lot_size = (char *)malloc(500 * sizeof(char));
	mat_type = (char *)malloc(500 * sizeof(char));
	descDup = (char *)malloc(500 * sizeof(char));
	reord_pt = (char *)malloc(500 * sizeof(char));
	profit_centre_sap = (char *)malloc(500 * sizeof(char));
	part_noDupDes = (char *)malloc(500 * sizeof(char));
	part_noDupDesx = (char *)malloc(500 * sizeof(char));


	char *qry_entries[] = {"Item ID","Release Status"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	printf("\n ........111111.........."); fflush(stdout);

	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	fpPart_List = fopen("PartList.txt","r");
	
	//char* attrjsonname = NULL;
	attrjsonname = (char*)MEM_alloc(200*sizeof(char));
	
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		char *json_matreupdate_req_obj = NULL;
		json_matreupdate_req_obj = malloc(34000);
		char *json_pstat_req_obj = NULL;
        json_pstat_req_obj = malloc(34000);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			inputPart=strtok(Buffer,"^");
			iPlantCode=strtok(NULL,"^");
			attrname=strtok(NULL,"^");
			attrnewval=strtok(NULL,"^");
			attroldval=strtok(NULL,"^");
			iSapServer=strtok(NULL,"^");
			
			printf("\n 1111....inputPart: [%s]\n", inputPart);
			printf("\n 2222....iPlantCode: [%s]\n", iPlantCode);
			printf("\n 3333....attrname: [%s]\n", attrname);
			printf("\n 4444....attrnewval: [%s]\n", attrnewval);
			printf("\n 5555....attroldval: [%s]\n", attroldval);
			printf("\n 6666....iSapServer: [%s]\n", iSapServer);

            if(tc_strcmp(attrname,"Lot Sizing Procedure")==0)
			{
				tc_strcpy(attrjsonname,"LOTSIZEKEY");
			}
			else if(tc_strcmp(attrname,"MRP Type")==0)
			{
				tc_strcpy(attrjsonname,"MRP_TYPE");
			}
			else if(tc_strcmp(attrname,"ABC Indicator")==0)
			{
				tc_strcpy(attrjsonname,"ABC_ID");
			}
			else if(tc_strcmp(attrname,"Maximum Stock Level")==0)
			{
				tc_strcpy(attrjsonname,"MAX_STOCK");
			}
			else if(tc_strcmp(attrname,"Reorder Point")==0)
			{
				tc_strcpy(attrjsonname,"REORDER_PT");
			}
			else if(tc_strcmp(attrname,"Availability Check")==0)
			{
				tc_strcpy(attrjsonname,"AVAILCHECK");
			}
			else if(tc_strcmp(attrname,"Bulk Material")==0)
			{
				tc_strcpy(attrjsonname,"BULK_MAT");
			}
			else if(tc_strcmp(attrname,"Goods Rec. Proc. Time")==0)
			{
				tc_strcpy(attrjsonname,"GR_PR_TIME");
			}
			else
			{
				printf("\n >>>>> Input Attribute Real Name Not Matched <<<<<<\n");
			}
			
			if(tc_strlen(attrjsonname)>0)
			{
				printf("\n Function[1]: cll_PLM_BAPI_MATERIAL_GETALL() Start..!!\n");fflush(stdout);
				cll_PLM_BAPI_MATERIAL_GETALL(inputPart, iPlantCode,json_pstat_req_obj);
				printf("\nRequest String: [%s]\n", json_pstat_req_obj);
				tm_PLM_BAPI_MATERIAL_GETALL ( json_pstat_req_obj );
				printf("\n\n #---------- In[Main-Function] -----------#");
				printf("\n Returned Value From SAP: [%s]",sapreturnval);
				printf("\n #---------- In[Main-Function] -----------#");
				printf("\n Function[1]: cll_PLM_BAPI_MATERIAL_GETALL() End..!!\n");fflush(stdout);
				cll_matreupdate(inputPart, iPlantCode, attrjsonname, attrnewval, attroldval, sapreturnval, json_matreupdate_req_obj);
				printf("\n Request String : [%s]\n", json_matreupdate_req_obj);
				tm_curl_matreupdate( json_matreupdate_req_obj );
				//if(attrjsonname)MEM_free(attrjsonname);
			}
			else
			{
				printf("\n >>>>> Attribute JSON Name Not Found <<<<<<\n");
			}
		}
		free(json_matreupdate_req_obj);
	}
	else
	{
	   printf(" Input File is Null..!!\n");fflush(stdout);
	}

	
	sprintf(fsuccess_name,"APL_SAP_MAT_%s.log",inputPart);
	fsuccess = fopen(fsuccess_name,"a");

	CLEANUP:
	ITK_CALL(POM_logout(false));
	printf("\nCLEANUP..."); fflush(stdout);
}
