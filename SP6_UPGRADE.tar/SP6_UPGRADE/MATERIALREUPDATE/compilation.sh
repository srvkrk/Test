./compile tm_matreupdate.c
./linkitk -o tm_matreupdate tm_matreupdate.o
chmod 777 *
