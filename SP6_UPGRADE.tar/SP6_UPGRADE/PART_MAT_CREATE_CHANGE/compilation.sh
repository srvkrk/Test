compile PartMatCreChangeUA.c
linkitk -o PartMatCreChangeUA PartMatCreChangeUA.o
