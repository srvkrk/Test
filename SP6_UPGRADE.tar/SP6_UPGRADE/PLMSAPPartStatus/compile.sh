rm -f *.wsdl ns.xsd *.nsmap *.res.xml *.req.xml soapServerLib.c soapClientLib.c soapStub.h soapServer.c soapH.h soapClient.c soapC.c *.o *.cgi

./soapcpp2 -1 -e -c PLMSAPPartStatus.h

./compile PLMSAPPartStatus.c

./linkitk -o PLMSAPPartStatus.cgi PLMSAPPartStatus.o soapC.c soapServer.c stdsoap2.c *.a
chmod 777 *
#cp PLMSAPPartStatus.wsdl /user/cvprod/apache-tomcat-9.0.100/webapps/ROOT/
#cp PLMSAPPartStatus.cgi /user/cvprod/apache-tomcat-9.0.100/webapps/ROOT/WEB-INF/cgi/
#cp *.xml /user/cvprod/apache-tomcat-9.0.100/webapps/ROOT/WEB-INF/cgi/
#cd /user/cvprod/apache-tomcat-9.0.100/bin
#./shutdown.sh
#./startup.sh
#cd /home/ercdev/devgroups/sourav/P_ORCH_PLM_SAP/PLMSAPPartStatus/
