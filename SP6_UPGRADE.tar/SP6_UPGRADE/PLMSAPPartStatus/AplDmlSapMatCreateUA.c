/***************************************************************************
*  Copyright (c) 2020 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : AplDmlSapMatCreateUA.c
* Created By                   : Amol Narke
* Created On                   : 11/05/2020
* Project                      : Tata Motors TCUA-SAP Interface
* Methods Defined              :
* Description                  : TCUA - SAP DML Wise Material Master Creation
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
***************************************************************************/

#include "malloc.h"
#include "stdio.h"
#include <ae/dataset.h>
//#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <tc/envelope.h>
#include <fclasses/tc_date.h>
#include <user_exits/epm_toolkit_utils.h>
#include<cJSON.h>
#include <curl/curl.h>

//#include <librfc.a>
//#include <ProdSap_functions.a>
//#include "VrCre.h"
//#include "wmhelpe.h"
//#include "ppe.h"
//#include "bapi.h"


/* int FetchPlantSpecificData(char* DMLNumber,char* ProjCode);
void displaying_objects(void);
void cll_zbapi_material_savedata_mrp(void);
RFC_RC cll_ccap_ecn_create(RFC_HANDLE);
RFC_RC ccap_ecn_create(RFC_HANDLE hRfc,AENR_API01 *,CSDATA_XFELD *,CSDATA_XFELD *,CSDATA_XFELD *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AEEF_API01 *,AENRB_AENNR *,ITAB_H,ITAB_H,ITAB_H,ITAB_H,ITAB_H,char *);
RFC_RC zbapi_material_savedata_mrp(RFC_HANDLE hRfc,BAPIMATHEAD *,BAPI_MARA *,BAPI_MARAX *,BAPI_MARC *,BAPI_MARCX *,BAPI_MPGD *,BAPI_MPGDX *,BAPI_MARD *,BAPI_MARDX *,BAPI_MBEW *,BAPI_MBEWX *,RMMG1_AENNR *,BAPIRET2 *,ITAB_H ,ITAB_H ,ITAB_H,ITAB_H ,ITAB_H ,char *);
RFC_RC zbapi_material_savedata_mrpCreate(RFC_HANDLE hRfc,BAPIMATHEAD *eBapiMatHead,BAPI_MARA	*eBasicView,BAPI_MARAX	*eBasicViewx,BAPI_MARC	*eMrpView,BAPI_MARCX	*eMrpViewx,BAPI_MPGD	*eBapi_Mpgd,BAPI_MPGDX	*eBapi_Mpgdx,BAPI_MARD	*eBapi_Mard,BAPI_MARDX	*eBapi_Mardx,BAPI_MBEW	*eAccView,BAPI_MBEWX	*eAccViewx,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2 *eBapiret2,ITAB_H thBapi_Makt,ITAB_H thBapi_Marm,ITAB_H thBapi_Marmx,ITAB_H thBAPIE1PAREX3,ITAB_H thBAPIE1PAREXX3,char *xException);
RFC_RC BAPI_MATERIAL_MARD(RFC_HANDLE hRfc,BAPIMATHEAD *eBapiMatHead,BAPI_MARD *eBapi_Mard,BAPI_MARDX *eBapi_Mardx,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2 *eBapiret2,char *xException);
RFC_RC allocate_insp_type(void);
RFC_RC allocate_insp_type_vc(void);
RFC_RC cll_zrfc_insptype_alloc(RFC_HANDLE);
RFC_RC vc_zrfc_insptype_alloc(RFC_HANDLE );
int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3]);
void cll_zrfc_ac_view_create(void);
void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);
void str2nbcd(char *str,unsigned char *bcd,size_t size,int decimals);

int Part_CreateChangeFunction(tag_t LatestRev); */


FILE* fsuccess;
FILE* fp=NULL;
FILE* finsp;
FILE* fval;

char fsuccess_name[200];
char fisa_name[200];
char fvac_name[200];

//WERKS_D eWerks;
//static MATNR eMatnr;

tag_t		*TaskRevision		= NULLTAG;
tag_t		TaskRevTag			= NULLTAG;
tag_t		*PartTags			= NULLTAG;

int tcount=0,pcount=0,TaskCnt=0,PartCnt=0;

int apl_dml_flag = 0;
int car_dml = 0;
int go_for_rfc = 0;
int flag_vc_v_tpl = 0;
int flag = 0;
int acc_flag = 0;

char* DMLDesc = NULL;
char *iSapServer = NULL;
char *part_noDupDes=NULL;
char *part_noDupDesx=NULL;
char *doc_no=NULL;
char *basic_division=NULL;
char *unit_wt=NULL;
char *volume=NULL;
char *vol_unit=NULL;
char *material_group=NULL;
char *doc_noDup=NULL;
char *dwg_typeDup=NULL;
char *tmpDrwNum1=NULL;
char *tmpDrwNum=NULL;
char *tmpDrwRev=NULL;
char *tmpDrwSeq=NULL;
char *dwg_revDup=NULL;
char *dwg_rev=NULL;
char *sizeDup=NULL;
char *sheet_noDup=NULL;
char *OldMatNoDup=NULL;
char *net_wt=NULL;
char *net_wtDup=NULL;
char *gross_wt=NULL;
char *part_noDup=NULL;
char *PartMakeBuyInd=NULL;
char *make_buy_indDup=NULL;
char *make_buy_ind=NULL;
char *mat_type=NULL;
char *store_loc=NULL;
char *store_locDup=NULL;
char *mrp_grp=NULL;
char *mrp_type=NULL;
char *abc_ind=NULL;
char *series=NULL;
char *odstatus=NULL;
char *num;
char *drstatus = NULL;
char *drstatusDup = NULL;
char *mm_pp_status = NULL;
char *partClrIndDup = NULL;
char *partClrInd = NULL;
char *reord_pt = NULL;
char *quota_arrangement_usage = NULL;
char *mrp_controller = NULL;
char *lot_size_key = NULL;
char *fixed_lot_size = NULL;
char *max_stlvl = NULL;
char *blk_ind = NULL;
char *sched_mar_key = NULL;
char *req_grp = NULL;
char *period_ind = NULL;
char *mixedmrp = NULL;
char *cs1_val = NULL;
char *alternativb = NULL;
char *avail_chk = NULL;
char *splan_mat = NULL;
char *splan_plant = NULL;
char *splan_conv_fact = NULL;
char *ind_collect = NULL;
char *rep_mfg_in = NULL;
char *rep_mfg = NULL;
char *stock_det_group = NULL;
char *uoissue = NULL;
char *qua_ins_ind = NULL;
char *doc_req = NULL;
char *grptime = NULL;
char *certificate_type = NULL;
char *qm_proc_ind = NULL;
char *control_key = NULL;
char *catalog_prof = NULL;
char *valuation_cat = NULL;
char *price_con = NULL;
char *std_price = NULL;
char *moving_avg_price = NULL;
char *val_class = NULL;
char *mat_origin = NULL;
char *cost_lot_size = NULL;
char *variance_key = NULL;
char *with_quantity_structure = NULL;
char *costing_split_valuation = NULL;
char *costing_val_class = NULL;
char *MatCrChFlag = NULL;
char *OrgIDDup = NULL;
char *plan_calendar = NULL;
char *profit_centre_sap = NULL;
char *overhd_grp = NULL;
char *myzeroDup3 = NULL;
char *myzeroDup1 = NULL;
char *myzeroDup2 = NULL;
char *myzeroDup4 = NULL;
char *sap_msg = NULL;
char *p;

char *DMLEcnType = NULL;
char *DMLRelStatus = NULL;
char *DMLNumDup = NULL;

char *plantcode=NULL;
char *Plant_MakeBuy=NULL;
char *Plant_StoreLoc=NULL;
char *profit_centre2=NULL;
char *plan_calendar2=NULL;
char *overhd_grp2=NULL;
char *origin_group2=NULL;
char *origin_group=NULL;
char *meas_unit=NULL;
char *desc=NULL;
char *descDup=NULL;
char *DMLDescription=NULL;
char *apl_release_date=NULL;
char *drg_ind=NULL;
char *drg_indDup=NULL;
char *docClass=NULL;
char *spl_proc_key=NULL;
char *PrtRev=NULL;
char *PrtRevDup=NULL;
char *OwnerNameDup=NULL;
char *OwnerName=NULL;
char *proc_type;

char *inputDml=NULL;
char *iPlantCode=NULL;


char *sap_proc_type=NULL;
char *sap_spproc_type=NULL;
char *SAPpstat=NULL;
char *MRPpstat=NULL;
char pstat;
char pstat_mrp;
char pstat_acc;
char proc_Key;
char spl_Key;
char group;

char dml_no_arg[14]={0};
char dml_numAP1[14]={0};

const char *attrs[2];
const char *values[2];

char *dml_no = NULL;
char *plant = NULL;
char *PartNumber = NULL;
char *PartRev = NULL;
char *PartSeq = NULL;
char *Parttype = NULL;
char *Error_message = NULL;
char *MATstatus = NULL;

//drwnum = (char *)malloc(500 * sizeof(char));


#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)
void rfc_error(char *);
//#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}

void cll_zbapi_material_savedata_mrp();
int FetchPlantSpecificData(char* DMLNumber,char* ProjCode);
int Part_CreateChangeFunction(tag_t LatestRev, char *SapServer);
void getTodayDate(char* StdDate);
int Create_PLMSAP_audit_object ( char *iDmlTask, char *plant, char *PartNumber, char *PartRev, char *PartSeq,char *Parttype, char *Error_message, char *MATstatus);
int DATE_date_to_string (date_t date_struct, const char *format_str, char **date_str);
int EPM__parse_string (const char *pszInputString, char *pszSeparator, int *piStringCount, char ***pppStringList);
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString(char* mainStringf ,int fromCharf ,int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}

void getTodayDate(char* StdDate)
{
	struct tm *Sys_T = NULL;
	int Month;
	int Day;
	int Year;
	int hour;
	int min;
	int sec;

	time_t Tval = 0;
	Tval = time(NULL);
	Sys_T = localtime(&Tval);
	Day=Sys_T->tm_mday;
	Month=Sys_T->tm_mon+1;
	Year=1900 + Sys_T->tm_year;
	hour = Sys_T->tm_hour;
	min = Sys_T->tm_min;
	sec = Sys_T->tm_sec;

	sprintf(StdDate,"%02d%02d%02d",Month,Day,Year);
	printf("\nDate:[%s]",StdDate); fflush(stdout);
}

void getCurrentDateTime(char cCurrentAccessDate[20])
{
        int ch;
        time_t temp;
        struct tm *timeptr;
        char pAccessDate[20];
        char    DateS[4];
        printf("getCurrentDateTime calling..........\n");
        temp = time(NULL);
        tc_strcpy(pAccessDate,"");
        timeptr = (struct tm *)localtime(&temp);
        ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
        tc_strcpy(cCurrentAccessDate,pAccessDate);
        printf("cCurrentAccessDate:%s\n",cCurrentAccessDate);

        printf("Date:%d\n",(timeptr->tm_mday));
        printf("Month:%d\n",(timeptr->tm_mon)+1);
        printf("Year:%d\n",(timeptr->tm_year+1900));
        fflush(stdout);
}

int Create_PLMSAP_audit_object ( char *iDmlTask, char *plant, char *PartNumber, char *PartRev, char *PartSeq,char *Parttype, char *Error_message, char *MATstatus)
{
	char *object_name = NULL;
	char StdDate[11] = { 0  };
	char cCurrentAccessDate[20];
	tag_t tItemTypeTag = NULLTAG;
	tag_t tItemCreateInputTag = NULLTAG;
	tag_t tItemTag = NULLTAG;
	date_t transfer_date;

	plant = (char *) MEM_alloc(10 * sizeof(char ));

	if (tc_strstr(iDmlTask,"APLC")!=NULL)
	{
		tc_strcpy(plant,"1100");
	}
	else if (tc_strstr(iDmlTask,"APLA")!=NULL)
	{
		tc_strcpy(plant,"E201");
	}
	else if (tc_strstr(iDmlTask,"APLP")!=NULL)
	{
		tc_strcpy(plant,"1001");
	}
	else if (tc_strstr(iDmlTask,"APLD")!=NULL)
	{
		tc_strcpy(plant,"1500");
	}
	else if (tc_strstr(iDmlTask,"APLU")!=NULL)
	{
		tc_strcpy(plant,"3100");
	}
	else if (tc_strstr(iDmlTask,"APLJ")!=NULL)
	{
		tc_strcpy(plant,"2001");
	}

	printf("\nDML_No : [%s]\n", iDmlTask);
	printf("\nPlant : [%s]\n", plant);
	printf("\nPart_Number : [%s]\n", PartNumber);
	printf("\nPart_Rev : [%s]\n", PartRev);
	printf("\nPart_Seq : [%s]\n", PartSeq);
	printf("\nError_Message : [%s]\n", Error_message);
	printf("\nMaterial_Status : [%s]\n", MATstatus);
	getTodayDate(StdDate);
	object_name = MEM_alloc(50);
	sprintf(object_name,"%s_%s",iDmlTask,StdDate);
	printf("object_name : [%s]\n", object_name);

	getCurrentDateTime(cCurrentAccessDate);
	printf("cCurrentAccessDate:%s\n",cCurrentAccessDate);
	ITK_CALL(ITK_string_to_date(cCurrentAccessDate, &transfer_date ));



	ITK_CALL ( TCTYPE_find_type ( "T5_PLMSAP_AU_LOG", NULL, &tItemTypeTag ) ) ;
	ITK_CALL ( TCTYPE_construct_create_input ( tItemTypeTag, &tItemCreateInputTag ) ) ;
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "object_name", object_name ) ) ;		
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Task_number", iDmlTask ) ) ;		
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Part_number", PartNumber ) ) ;
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Revision", PartRev ) ) ;
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Sequence", PartSeq ) ) ;
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Part_type", Parttype ) ) ;//VC/V/A/M/G
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Plant", plant ) ) ;
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Status", MATstatus ) ) ;//mismatch true false Y/N
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Transfer_type", "MAT" ) ) ;//BOM//Material
	//ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Error_message", "Creating BOM for material 585862600130" ) ) ;
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Error_message", Error_message ) ) ;
	//ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Error_message", "BOM for material 585862600130 changed" ) ) ;
	ITK_CALL ( AOM_set_value_date ( tItemCreateInputTag, "t5_Transfer_date", transfer_date ) ) ;
	ITK_CALL ( TCTYPE_create_object ( tItemCreateInputTag, &tItemTag ) ) ;
	ITK_CALL ( AOM_refresh ( tItemTag, 1 ) ) ;	
	ITK_CALL ( AOM_save_with_extensions ( tItemTag ) ) ;
	ITK_CALL ( AOM_unlock ( tItemTag ) ) ;

	return 0;
}

int FetchPlantSpecificData(char* DMLNumber,char* ProjCode)
{
	char	*DMLNo			= NULL;
	char	*PlantSuffix	= NULL;
	char	*SAPLivFlg		= NULL;
	
	int     n_entry			= 3;
	int     p_entry			= 2;
	int		ContObjCnt		= 0;

	tag_t   PlantCodeQryTag     = NULLTAG;
	tag_t   MakeBuyQryTag		= NULLTAG;
	tag_t   PlantDataQryTag     = NULLTAG;
	tag_t   *ContorlObjTag     = NULLTAG;

	char    *qry_entryApl[3]  = {"SYSCD","SUBSYSCD","Information-1"};
	char    *qry_entryStd[3]  = {"SYSCD","SUBSYSCD","Information-2"};

	char    *qry_entryMake[2] = {"SYSCD","SUBSYSCD"};

	DMLNo = strtok(DMLNumber, "_" );
	PlantSuffix  = strtok ( NULL, "_" );
	
	tc_strcpy(dml_no_arg,DMLNo);
	tc_strcpy(dml_numAP1,DMLNo);

	profit_centre_sap = (char *)malloc(100 * sizeof(char));

	printf("\nDMLNo [%s]	PlantSuffix [%s]	Project Code [%s]", DMLNo,PlantSuffix,ProjCode);

	char	*qry_value[3] = {"XFRDML",ProjCode,PlantSuffix};
	
	if(QRY_find2("Control Objects...", &PlantCodeQryTag));

	if(PlantCodeQryTag)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		if(QRY_execute(PlantCodeQryTag,n_entry,qry_entryApl,qry_value,&ContObjCnt,&ContorlObjTag));

		if (ContObjCnt==0)
		{
			if(QRY_execute(PlantCodeQryTag,n_entry,qry_entryStd,qry_value,&ContObjCnt,&ContorlObjTag));
		}

		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo3",&plantcode);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo4",&SAPLivFlg);
			printf("\nPlantSuffix [%s]	Plant Code [%s]",PlantSuffix,plantcode);
		}
		else
		{
			printf("\nProjectCode [%s] do not have entry in Control Object PlantDML for Suffix [%s] hence exiting!",ProjCode,PlantSuffix); fflush(stdout);
			goto CLEANUP;
		}

		char    *qry_MakeValue[2]  = {"MAKEBUY",plantcode};
		
		if(QRY_execute(PlantCodeQryTag,p_entry,qry_entryMake,qry_MakeValue,&ContObjCnt,&ContorlObjTag));

		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo1",&Plant_StoreLoc);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo2",&Plant_MakeBuy);
			printf("\nPlant Code [%s]	Plant_MakeBuy [%s]	Plant_StoreLoc [%s]",plantcode,Plant_MakeBuy,Plant_StoreLoc);
		}
		else
		{
			printf("\nPlantcode [%s] do not have entry in Control Object MAKEBUY hence exiting!",plantcode); fflush(stdout);
			goto CLEANUP;
		}



		char    *qry_PlantValue[2]  = {"PLANTDATA",plantcode};

		if(QRY_execute(PlantCodeQryTag,p_entry,qry_entryMake,qry_PlantValue,&ContObjCnt,&ContorlObjTag));
		
		printf("\nContObjCnt:%d",ContObjCnt);
		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo1",&profit_centre2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo2",&plan_calendar2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo3",&overhd_grp2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo4",&origin_group2);

			tc_strcpy(profit_centre_sap,"000");
			tc_strcat(profit_centre_sap,profit_centre2);
			tc_strdup(plan_calendar2,&plan_calendar);
			tc_strdup(overhd_grp2,&overhd_grp);
			tc_strdup(origin_group2,&origin_group);

			printf("\nplantcode      :[%s]",plantcode);
			printf("\nprofit_centre  :[%s]",profit_centre_sap);
			printf("\nplan_calendar  :[%s]",plan_calendar);
			printf("\noverhd_grp     :[%s]",overhd_grp);
			printf("\norigin_group   :[%s]",origin_group);
		}
		if(tc_strcmp(plantcode,"1100")==0)
		{
			//nlsStrCpy(plantcode,"1100");
			/*profit_centre2=(char *) MEM_alloc(15 * sizeof(char));
			plan_calendar2=(char *) MEM_alloc(15 * sizeof(char));
			overhd_grp2=(char *) MEM_alloc(15 * sizeof(char));
			origin_group2=(char *) MEM_alloc(15 * sizeof(char));
			tc_strcpy(profit_centre2,"2511200");

			tc_strcpy(profit_centre_sap,"000");
			tc_strcat(profit_centre_sap,profit_centre2);

			tc_strdup(plan_calendar2,"CAR");
			tc_strdup(overhd_grp2,"ZG110000");
			tc_strdup(origin_group2,"0005");*/

			plan_calendar = (char *)malloc(100 * sizeof(char));
			overhd_grp = (char *)malloc(100 * sizeof(char));
			origin_group = (char *)malloc(100 * sizeof(char));

			tc_strcpy(profit_centre_sap,"0002511200");
			tc_strcpy(plan_calendar,"CAR");
			tc_strcpy(overhd_grp,"ZG110000");
			tc_strcpy(origin_group,"0005");

			printf("\nplantcode 1     :[%s]",plantcode);
			printf("\nprofit_centre1  :[%s]",profit_centre_sap);
			printf("\nplan_calendar1  :[%s]",plan_calendar);
			printf("\noverhd_grp1     :[%s]",overhd_grp);
			printf("\norigin_group1   :[%s]",origin_group);

			ContObjCnt = 1;
		}

		
		if (tc_strlen(PlantSuffix)>3)
		{
			dml_no_arg[10] = PlantSuffix[3];
			dml_no_arg[11] = 'P';
			dml_no_arg[12] = '\0';

			dml_numAP1[10] = PlantSuffix[3];
			dml_numAP1[11] = 'P';
			dml_numAP1[12] = '\0';
		}
		else
		{
			tc_strcat(dml_no_arg,"AP");
			tc_strcat(dml_numAP1,"AP");
		}
	}

	CLEANUP:
	return ContObjCnt;
}
 
struct memory {
  char *response;
  size_t size;
};

static size_t WriteCallback(char *data, size_t size, size_t nmemb, void *clientp)
{
  size_t realsize = size * nmemb;
  struct memory *mem = (struct memory *)clientp;
 
  char *ptr = realloc(mem->response, mem->size + realsize + 1);
  if(!ptr)
    return 0;  /* out of memory */
 
  mem->response = ptr;
  memcpy(&(mem->response[mem->size]), data, realsize);
  mem->size += realsize;
  mem->response[mem->size] = 0;
  
  printf("\nWriteCallback done"); fflush(stdout);
 
  return realsize;
}

int parse_json_object(const char *json_string,char *ParseType) 
{
    int i = 0;
	cJSON *json = cJSON_Parse(json_string);
	if (json == NULL) 
	{ 
        const char *error_ptr = cJSON_GetErrorPtr(); 
        if (error_ptr != NULL) 
		{ 
            printf("Error: %s\n", error_ptr); 
        } 
        cJSON_Delete(json); 
        return 1; 
    } 
	printf("\njson_string : [%s]\n\n",json_string);//to see complete response
	printf("\ncJSON_GetArraySize(json) : [%d]\n\n",cJSON_GetArraySize(json));
	
	printf ("\nParseType : [%s]",ParseType);
	if ( tc_strcmp ( ParseType, "INSP_CREATE" ) == 0 )
	{
		const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZRFC_INSPTYPE_ALLOCResponse");
		const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "MESSG");
			
		for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
		{
			char *tm_Message = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
			printf("\n @@@@@@@@@@@@ INSPECTION ALLOCATION STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			printf("\n INSPTYPE_ALLOC_Message: [%s]\n", tm_Message);fflush(stdout);
			printf("\n SAP Msg for Material Inspection Allocation: [%s]\n", tm_Message);fflush(stdout);
			printf("\n @@@@@@@@@@@@ INSPECTION ALLOCATION STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
		}
	}
	else if ( tc_strcmp ( ParseType, "Batch_Create" ) == 0 )
	{
		const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZRFC_AC_VIEW_CREATEResponse");
		const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "MESSG");
			
		for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
		{
			char *tm_Type = cJSON_GetObjectItem(moon_2, "SYSTEM")->valuestring;
			char *tm_Message = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
			printf("\ntm_Type: [%s]\n", tm_Type);fflush(stdout);
			printf("\nZRFC_AC_VIEW_CREATE_Message: [%s]\n", tm_Message);fflush(stdout);
		}
	}
	/* else if ( tc_strcmp ( ParseType, "PSTAT" ) == 0 )
	{
		//const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "get_pstat_from_sapResponse");
		const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALL");
		const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "RETURN");
			
		for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
		{
			char *tm_Type = cJSON_GetObjectItem(moon_2, "SYSTEM")->valuestring;
			char *tm_Message = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
			printf("\ntm_Type: [%s]\n", tm_Type);fflush(stdout);
			printf("\nget_pstat_from_sap_Message: [%s]\n", tm_Message);fflush(stdout);
		}
	} */
	else if ( tc_strcmp ( ParseType, "PSTAT" ) == 0 )
	{
		printf("\njson_string : [%s]\n\n",json_string);
		if( tc_strstr(json_string ,"BAPI_MATERIAL_GETALLResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALLResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "CLIENTDATA");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_KStatMessage = cJSON_GetObjectItem(moon_2, "MAINT_STAT")->valuestring;
			    printf("\n K-Flag Message: [%s]\n", tm_KStatMessage);fflush(stdout);
			}
		}
		if( tc_strstr(json_string ,"BAPI_MATERIAL_GETALLResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALLResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "PLANTDATA");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_DStatMessage = cJSON_GetObjectItem(moon_2, "MAINT_STAT")->valuestring;
			    printf("\n D-Flag Message: [%s]\n", tm_DStatMessage);fflush(stdout);
			}
		}
		if( tc_strstr(json_string ,"BAPI_MATERIAL_GETALLResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALLResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "VALUATIONDATA");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_BStatMessage = cJSON_GetObjectItem(moon_2, "MAINT_STAT")->valuestring;
			    printf("\n B-Flag Message: [%s]\n", tm_BStatMessage);fflush(stdout);
			}
		}
	}
	else if ( tc_strcmp ( ParseType, "MAT_CREATE_CHANGE" ) == 0 )
	{
		printf("\njson_string : [%s]\n\n",json_string);
		if( tc_strstr(json_string ,"ZBAPI_MATERIAL_SAVEDATAResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZBAPI_MATERIAL_SAVEDATAResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "RETURN");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_matcrexmsg = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
				printf("\n @@@@@@@@@@@@ MATERIAL CREATE/EXTEND STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			    printf("\n SAP Msg for Material Create/Extend: [%s]\n", tm_matcrexmsg);fflush(stdout);
				printf("\n @@@@@@@@@@@@ MATERIAL CREATE/EXTEND STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			}
		}
	}
	else if ( tc_strcmp ( ParseType, "CHANGE_NO" ) == 0 )
	{
		printf("\njson_string : [%s]\n\n",json_string);
		if( tc_strstr(json_string ,"addition") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "addition");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "CcapEcnCreate_Exception");	
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_changename = cJSON_GetObjectItem(moon_2, "Name")->valuestring;
				char *tm_changetext = cJSON_GetObjectItem(moon_2, "Text")->valuestring;
				printf("\n @@@@@@@@@@@@ CHANGE_NO CREATE STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
				printf("\n Change_No Name: [%s]\n", tm_changename);fflush(stdout);
				printf("\n Change_No Text: [%s]\n", tm_changetext);fflush(stdout);
				printf("\n SAP Msg for Change_no Create/Extend: Change_no already maintained for this transaction/event\n");fflush(stdout);
				printf("\n @@@@@@@@@@@@ CHANGE_NO CREATE STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			}
		}
		else
		{
			//const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "CcapEcnCreate");
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "CcapEcnCreateResponse");
			for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				printf("\n @@@@@@@@@@@@ CHANGE_NO CREATE STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
				char *tm_material = cJSON_GetObjectItem(moon_1, "ChangeNo")->valuestring;
				printf("\n Change_No [%s]\n", tm_material);fflush(stdout);
				printf("\n SAP Msg for Change_no Create/Extend: Transaction Completed Succesfully...\n");fflush(stdout);
				printf("\n @@@@@@@@@@@@ CHANGE_NO CREATE STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			}
		}
	}
			
	return 0;
}

void print_json_object(const char *json_string)
{
    cJSON *json = cJSON_Parse(json_string);
    char *formatted_json = cJSON_Print(json);
    printf("%s\n", formatted_json);
    cJSON_Delete(json);
    free(formatted_json);
}

int create_change_no_in_sap ( char *data )
{
	struct memory chunk = {0};
	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	//const char *data = readd_sap_request_json_file();
	
	//printf("\nFile request content as below : %s",data);
	
	//curl_easy_setopt(curl, CURLOPT_URL, api_url);
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV_DEV");//ccap_ecn_create
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV_DEV");//ccap_ecn_create
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV");//ccap_ecn_create DEV
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV_QA");//ccap_ecn_create
	//curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	
	if ( tc_strcmp ( iSapServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV_DEV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n iSapServer is Blank..!!");fflush(stdout);
	}
	
	list = curl_slist_append(list, "Content-Type: application/json");
    //curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);
	
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, 12L);
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\nFile request content as below "); fflush(stdout);
	print_json_object ( data ) ;
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
		printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
		printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
		printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	//printf ("\nresponse : [%s] [%d]",chunk.response,strlen(chunk.response)) ;
	printf("\ncurl_easy_perform");fflush(stdout);
	//print_json_object ( chunk.response ) ;
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "CHANGE_NO");
	
		printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
		printf("\nfree"); fflush(stdout);
	
    curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}

int change_no_json_cr(char *json_req_obj)
{
	
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *AltDates_req;
	cJSON *AltDates_item_req;
	cJSON *ChangeHeader_req;
	cJSON *Effectivity_req;
	cJSON *Effectivity_item_req;
	cJSON *ObjectBom_req;
	cJSON *Object084_req;
	cJSON *ObjectBomCus_req;
	cJSON *ObjectBomDoc_req;
	cJSON *ObjectBomEqui_req;
	cJSON *ObjectBomLoc_req;
	cJSON *ObjectBomMat_req;
	cJSON *ObjectBomPsp_req;
	cJSON *ObjectBomStd_req;
	cJSON *ObjectChar_req;
	cJSON *ObjectCls_req;
	cJSON *ObjectClsMaint_req;
	cJSON *ObjectConfProf_req;
	cJSON *ObjectDep_req;
	cJSON *ObjectDoc_req;
	cJSON *ObjectHazmat_req;
	cJSON *ObjectMat_req;
	cJSON *ObjectO75_req;
	cJSON *ObjectO76_req;
	cJSON *ObjectO77_req;
	cJSON *ObjectO78_req;
	cJSON *ObjectO79_req;
	cJSON *ObjectO80_req;
	cJSON *ObjectO81_req;
	cJSON *ObjectO82_req;
	cJSON *ObjectO83_req;
	cJSON *ObjectO85_req;
	cJSON *ObjectO86_req;
	cJSON *ObjectO87_req;
	cJSON *ObjectO88_req;
	cJSON *ObjectO89_req;
	cJSON *ObjectO90_req;
	cJSON *ObjectO91_req;
	cJSON *ObjectO92_req;
	cJSON *ObjectO93_req;
	cJSON *ObjectO94_req;
	cJSON *ObjectO95_req;
	cJSON *ObjectO96_req;
	cJSON *ObjectO97_req;
	cJSON *ObjectO98_req;
	cJSON *ObjectO99_req;
	cJSON *ObjectPhrase_req;
	cJSON *ObjectPvs_req;
	cJSON *ObjectPvsAlt_req;
	cJSON *ObjectPvsRel_req;
	cJSON *ObjectPvsVar_req;
	cJSON *ObjectSubstance_req;
	cJSON *ObjectTlist_req;
	cJSON *ObjectTlistA_req;
	cJSON *ObjectTlistE_req;
	cJSON *ObjectTlistM_req;
	cJSON *ObjectTlistN_req;
	cJSON *ObjectTlistQ_req;
	cJSON *ObjectTlistR_req;
	cJSON *ObjectTlistS_req;
	cJSON *ObjectTlistT_req;
	cJSON *ObjectTlist_2_req;
	cJSON *ObjectValidMatvers_req;
	cJSON *ObjectVarTab_req;

	cJSON *Objmgrec_req;
	cJSON *Objmgrec_item_req;

	cJSON *Textheader_req;
	cJSON *Textheader_item_req;

	cJSON *Textlines_req;
	cJSON *Textlines_item_req;

	cJSON *ValueAssign_req;

	printf("\nCalling json for change no"); fflush(stdout);
	char *out;
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	AltDates_req = cJSON_CreateObject();
	AltDates_item_req = cJSON_CreateObject();
	ChangeHeader_req = cJSON_CreateObject();
	Effectivity_req = cJSON_CreateObject();
	Effectivity_item_req = cJSON_CreateObject();
	ObjectBom_req = cJSON_CreateObject();
	Object084_req = cJSON_CreateObject();
	ObjectBomCus_req = cJSON_CreateObject();
	ObjectBomDoc_req = cJSON_CreateObject();
	ObjectBomEqui_req = cJSON_CreateObject();
	ObjectBomLoc_req = cJSON_CreateObject();
	ObjectBomMat_req = cJSON_CreateObject();
	ObjectBomPsp_req = cJSON_CreateObject();
	ObjectBomStd_req = cJSON_CreateObject();
	ObjectChar_req = cJSON_CreateObject();
	ObjectCls_req = cJSON_CreateObject();
	ObjectClsMaint_req = cJSON_CreateObject();
	ObjectConfProf_req = cJSON_CreateObject();
	ObjectDep_req = cJSON_CreateObject();
	ObjectDoc_req = cJSON_CreateObject();
	ObjectHazmat_req = cJSON_CreateObject();
	ObjectMat_req = cJSON_CreateObject();
	ObjectO75_req = cJSON_CreateObject();
	ObjectO76_req = cJSON_CreateObject();
	ObjectO77_req = cJSON_CreateObject();
	ObjectO78_req = cJSON_CreateObject();
	ObjectO79_req = cJSON_CreateObject();
	ObjectO80_req = cJSON_CreateObject();
	ObjectO81_req = cJSON_CreateObject();
	ObjectO82_req = cJSON_CreateObject();
	ObjectO83_req = cJSON_CreateObject();
	ObjectO85_req = cJSON_CreateObject();
	ObjectO86_req = cJSON_CreateObject();
	ObjectO87_req = cJSON_CreateObject();
	ObjectO88_req = cJSON_CreateObject();
	ObjectO89_req = cJSON_CreateObject();
	ObjectO90_req = cJSON_CreateObject();
	ObjectO91_req = cJSON_CreateObject();
	ObjectO92_req = cJSON_CreateObject();
	ObjectO93_req = cJSON_CreateObject();
	ObjectO94_req = cJSON_CreateObject();
	ObjectO95_req = cJSON_CreateObject();
	ObjectO96_req = cJSON_CreateObject();
	ObjectO97_req = cJSON_CreateObject();
	ObjectO98_req = cJSON_CreateObject();
	ObjectO99_req = cJSON_CreateObject();
	ObjectPhrase_req = cJSON_CreateObject();
	ObjectPvs_req = cJSON_CreateObject();
	ObjectPvsAlt_req = cJSON_CreateObject();
	ObjectPvsRel_req = cJSON_CreateObject();
	ObjectPvsVar_req = cJSON_CreateObject();
	ObjectSubstance_req = cJSON_CreateObject();
	ObjectTlist_req = cJSON_CreateObject();
	ObjectTlistA_req = cJSON_CreateObject();
	ObjectTlistE_req = cJSON_CreateObject();
	ObjectTlistM_req = cJSON_CreateObject();
	ObjectTlistN_req = cJSON_CreateObject();
	ObjectTlistQ_req = cJSON_CreateObject();
	ObjectTlistR_req = cJSON_CreateObject();
	ObjectTlistS_req = cJSON_CreateObject();
	ObjectTlistT_req = cJSON_CreateObject();
	ObjectTlist_2_req = cJSON_CreateObject();
	ObjectValidMatvers_req = cJSON_CreateObject();
	ObjectVarTab_req = cJSON_CreateObject();

	Objmgrec_req = cJSON_CreateObject();
	Objmgrec_item_req = cJSON_CreateObject();

	Textheader_req = cJSON_CreateObject();
	Textheader_item_req = cJSON_CreateObject();

	Textlines_req = cJSON_CreateObject();
	Textlines_item_req = cJSON_CreateObject();

	ValueAssign_req = cJSON_CreateObject();


	cJSON_AddItemToObject(rfc_root, "CcapEcnCreate", exp_imp_tab_req);

	/*cJSON_AddItemToObject(exp_imp_tab_req, "AltDates", AltDates_req);
		cJSON_AddItemToObject(AltDates_req, "item", AltDates_item_req);
			cJSON_AddItemToObject(AltDates_item_req, "AltDate", cJSON_CreateString(erc_release_date));//erc_release_date
			cJSON_AddItemToObject(AltDates_item_req, "ValidFrom", cJSON_CreateString(erc_release_date));//07.02.2025//erc_release_date
			cJSON_AddItemToObject(AltDates_item_req, "FlDelete", cJSON_CreateString(""));*/
			
			

	cJSON_AddItemToObject(exp_imp_tab_req, "ChangeHeader", ChangeHeader_req);
		cJSON_AddItemToObject(ChangeHeader_req, "ChangeNo", cJSON_CreateString(dml_no_arg));//dml_numER//"CORRCT070225"
		cJSON_AddItemToObject(ChangeHeader_req, "Status", cJSON_CreateString("01"));
		cJSON_AddItemToObject(ChangeHeader_req, "AuthGroup", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "ValidFrom", cJSON_CreateString(apl_release_date));//07022025//erc_release_date
		//cJSON_AddItemToObject(ChangeHeader_req, "Descript", cJSON_CreateString(DMLDescription));//DMLDescription//"DBK TEST REST API POC"
		cJSON_AddItemToObject(ChangeHeader_req, "Descript", cJSON_CreateString("Test Data"));
		cJSON_AddItemToObject(ChangeHeader_req, "ReasonChg", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "DeletionMark", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "IndateRule", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "OutdateRule", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "Function", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "ChangeLeader", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "EffectivityType", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "OverridingMark", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "Rank", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "ReleaseKey", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "StatusProfile", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "TechRel", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "BasicChange", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "Effectivity", Effectivity_req);
		cJSON_AddItemToObject(Effectivity_req, "item", Effectivity_item_req);
			cJSON_AddItemToObject(Effectivity_item_req, "ValidFrom", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "ValidTo", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "DateMark", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Material", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "SerialnrLow", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "SerialnrHigh", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Product", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Class", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Classty", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Startup", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Plant", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Locno", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "SernrOi", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "FlDelete", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "FlAle", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "FlCommitAndWait", cJSON_CreateString("X"));
	cJSON_AddItemToObject(exp_imp_tab_req, "FlNoCommitWork", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "IvAccessUseCase", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBom", ObjectBom_req);
		cJSON_AddItemToObject(ObjectBom_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomCus", ObjectBomCus_req);
		cJSON_AddItemToObject(ObjectBomCus_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "GenDialog", cJSON_CreateString(""));


		cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomDoc", ObjectBomDoc_req);
		cJSON_AddItemToObject(ObjectBomDoc_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomEqui", ObjectBomEqui_req);
		cJSON_AddItemToObject(ObjectBomEqui_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomLoc", ObjectBomLoc_req);
		cJSON_AddItemToObject(ObjectBomLoc_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "GenDialog", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomMat", ObjectBomMat_req);
		cJSON_AddItemToObject(ObjectBomMat_req, "Active", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectBomMat_req, "Locked", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectBomMat_req, "ObjRequ", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectBomMat_req, "MgtrecGen", cJSON_CreateString("X"));/*X*/
		cJSON_AddItemToObject(ObjectBomMat_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomMat_req, "GenDialog", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomPsp", ObjectBomPsp_req);
		cJSON_AddItemToObject(ObjectBomPsp_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomStd", ObjectBomStd_req);
		cJSON_AddItemToObject(ObjectBomStd_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectChar", ObjectChar_req);
		cJSON_AddItemToObject(ObjectChar_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectCls", ObjectCls_req);
		cJSON_AddItemToObject(ObjectCls_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectClsMaint", ObjectClsMaint_req);
		cJSON_AddItemToObject(ObjectClsMaint_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectConfProf", ObjectConfProf_req);
		cJSON_AddItemToObject(ObjectConfProf_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectDep", ObjectDep_req);
		cJSON_AddItemToObject(ObjectDep_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "GenDialog", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectDoc", ObjectDoc_req);
		cJSON_AddItemToObject(ObjectDoc_req, "Active", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectDoc_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDoc_req, "ObjRequ", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectDoc_req, "MgtrecGen", cJSON_CreateString("X"));/*X*/
		cJSON_AddItemToObject(ObjectDoc_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDoc_req, "GenDialog", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "ObjectHazmat", ObjectHazmat_req);
		cJSON_AddItemToObject(ObjectHazmat_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "GenDialog", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectMat", ObjectMat_req);
		cJSON_AddItemToObject(ObjectMat_req, "Active", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectMat_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectMat_req, "ObjRequ", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectMat_req, "MgtrecGen", cJSON_CreateString("X"));/*X*/
		cJSON_AddItemToObject(ObjectMat_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectMat_req, "GenDialog", cJSON_CreateString(""));


	/*cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO75", ObjectO75_req);
		cJSON_AddItemToObject(ObjectO75_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO76", ObjectO76_req);
		cJSON_AddItemToObject(ObjectO76_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO77", ObjectO77_req);
		cJSON_AddItemToObject(ObjectO77_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO78", ObjectO78_req);
		cJSON_AddItemToObject(ObjectO78_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO79", ObjectO79_req);
		cJSON_AddItemToObject(ObjectO79_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO80", ObjectO80_req);
		cJSON_AddItemToObject(ObjectO80_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO81", ObjectO81_req);
		cJSON_AddItemToObject(ObjectO81_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO82", ObjectO82_req);
		cJSON_AddItemToObject(ObjectO82_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO83", ObjectO83_req);
		cJSON_AddItemToObject(ObjectO83_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "GenDialog", cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "Object084", Object084_req);
		cJSON_AddItemToObject(Object084_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "GenDialog", cJSON_CreateString(""));

	


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO85", ObjectO85_req);
		cJSON_AddItemToObject(ObjectO85_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO86", ObjectO86_req);
		cJSON_AddItemToObject(ObjectO86_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO87", ObjectO87_req);
		cJSON_AddItemToObject(ObjectO87_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO88", ObjectO88_req);
		cJSON_AddItemToObject(ObjectO88_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO89", ObjectO89_req);
		cJSON_AddItemToObject(ObjectO89_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO90", ObjectO90_req);
		cJSON_AddItemToObject(ObjectO90_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO91", ObjectO91_req);
		cJSON_AddItemToObject(ObjectO91_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO92", ObjectO92_req);
		cJSON_AddItemToObject(ObjectO92_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO93", ObjectO93_req);
		cJSON_AddItemToObject(ObjectO93_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO94", ObjectO94_req);
		cJSON_AddItemToObject(ObjectO94_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO95", ObjectO95_req);
		cJSON_AddItemToObject(ObjectO95_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO96", ObjectO96_req);
		cJSON_AddItemToObject(ObjectO96_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO97", ObjectO97_req);
		cJSON_AddItemToObject(ObjectO97_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO98", ObjectO98_req);
		cJSON_AddItemToObject(ObjectO98_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO99", ObjectO99_req);
		cJSON_AddItemToObject(ObjectO99_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPhrase", ObjectPhrase_req);
		cJSON_AddItemToObject(ObjectPhrase_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPvs", ObjectPvs_req);
		cJSON_AddItemToObject(ObjectPvs_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPvsAlt", ObjectPvsAlt_req);
		cJSON_AddItemToObject(ObjectPvsAlt_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPvsRel", ObjectPvsRel_req);
		cJSON_AddItemToObject(ObjectPvsRel_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPvsVar", ObjectPvsVar_req);
		cJSON_AddItemToObject(ObjectPvsVar_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsVar_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsVar_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsVar_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsVar_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsVar_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectSubstance", ObjectSubstance_req);
		cJSON_AddItemToObject(ObjectSubstance_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlist", ObjectTlist_req);
		cJSON_AddItemToObject(ObjectTlist_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistA", ObjectTlistA_req);
		cJSON_AddItemToObject(ObjectTlistA_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistE", ObjectTlistE_req);
		cJSON_AddItemToObject(ObjectTlistE_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistM", ObjectTlistM_req);
		cJSON_AddItemToObject(ObjectTlistM_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistN", ObjectTlistN_req);
		cJSON_AddItemToObject(ObjectTlistN_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistQ", ObjectTlistQ_req);
		cJSON_AddItemToObject(ObjectTlistQ_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistR", ObjectTlistR_req);
		cJSON_AddItemToObject(ObjectTlistR_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistS", ObjectTlistS_req);
		cJSON_AddItemToObject(ObjectTlistS_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistT", ObjectTlistT_req);
		cJSON_AddItemToObject(ObjectTlistT_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlist_2", ObjectTlist_2_req);
		cJSON_AddItemToObject(ObjectTlist_2_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectValidMatvers", ObjectValidMatvers_req);
		cJSON_AddItemToObject(ObjectValidMatvers_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectVarTab", ObjectVarTab_req);
		cJSON_AddItemToObject(ObjectVarTab_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "GenDialog", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "Objmgrec", Objmgrec_req);
		cJSON_AddItemToObject(Objmgrec_req, "item", Objmgrec_item_req);
			cJSON_AddItemToObject(Objmgrec_item_req, "AltDate", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "ChgObjtyp", cJSON_CreateString(""));//"4"
			cJSON_AddItemToObject(Objmgrec_item_req, "BomCat", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "BomStdObject", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "BomUsage", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "Chgtypeobj", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DescrObj", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DocType", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DocNumber", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DocVers", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DocPart", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "Equipment", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "FuncLoc", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "Material", cJSON_CreateString(""));/*PartNumC*/
			cJSON_AddItemToObject(Objmgrec_item_req, "Plant", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PspElement", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsGuid", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsType", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsNode", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsClassNumber", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsClassType", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsVariant", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "SdOrder", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "SdOrderI", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "Textkey", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "TlistType", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "TlistGrp", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "ObjChglock", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "StatusProfObj", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "FlDelete", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "Textheader", Textheader_req);
		cJSON_AddItemToObject(Textheader_req, "item", Textheader_item_req);
			cJSON_AddItemToObject(Textheader_item_req, "Textkey", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textheader_item_req, "Tdname", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textheader_item_req, "Tdid", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textheader_item_req, "Tdspras", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "Textlines", Textlines_req);
		cJSON_AddItemToObject(Textlines_req, "item", Textlines_item_req);
			cJSON_AddItemToObject(Textlines_item_req, "Textkey", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textlines_item_req, "Tdformat", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textlines_item_req, "Tdline", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ValueAssign", ValueAssign_req);
		cJSON_AddItemToObject(ValueAssign_req, "ValidFrom", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "ValidTo", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "DateMark", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Material", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "SerialnrLow", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "SerialnrHigh", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Product", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Class", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Classty", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Startup", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Plant", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Locno", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "SernrOi", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "FlDelete", cJSON_CreateString(""));*/

	out = cJSON_Print(rfc_root);
	//printf("%s\n", out);
	
	tc_strcpy(json_req_obj,out);
		
	free(out);
	cJSON_Delete(rfc_root);
	printf("\nend json for change no : %d",tc_strlen(json_req_obj)); fflush(stdout);
	return 0;
}

int cll_ccap_ecn_create()
{
	char *json_req_obj = NULL;
	json_req_obj = malloc(34000);
	change_no_json_cr ( json_req_obj );
	printf("%s\n", json_req_obj);
	
	create_change_no_in_sap ( json_req_obj ) ;
	
	free(json_req_obj);
	return 0;
}

int tm_curl_ZRFC_INSPTYPE_ALLOC ( char *data )
{
	struct memory chunk = {0};
	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZRFC_INSPTYPE_ALLOC_CV");  //DEV
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZRFC_INSPTYPE_ALLOC_CV_QA");
	//curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	if ( tc_strcmp ( iSapServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZRFC_INSPTYPE_ALLOC_CV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZRFC_INSPTYPE_ALLOC_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_ZRFC_INSPTYPE_ALLOC_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n iSapServer is Blank..!!");fflush(stdout);
	}
	
	list = curl_slist_append(list, "Content-Type: application/json");
    
	printf("\nFile request content as below "); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
	printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	printf("\ncurl_easy_perform");fflush(stdout);
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "INSP_CREATE");
	
	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
	printf("\nfree"); fflush(stdout);
	
    curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}

int cll_ZRFC_INSPTYPE_ALLOC( char *Part_no, char *plant, char *iSapServer,char* insp_type,char *json_alloc_inspect_type_req_obj)
{
	cJSON *rfc_root;
	cJSON *insp_type_list;
	char *out;
	
	
	rfc_root = cJSON_CreateObject();
	insp_type_list = cJSON_CreateObject();
	cJSON_AddItemToObject(rfc_root, "ZRFC_INSPTYPE_ALLOC", insp_type_list);
	
	
	cJSON_AddItemToObject(insp_type_list, "MATNR", cJSON_CreateString(Part_no));
	cJSON_AddItemToObject(insp_type_list, "QPART", cJSON_CreateString(insp_type));
	cJSON_AddItemToObject(insp_type_list, "WERKS", cJSON_CreateString(plant));
	
	
	out = cJSON_Print(rfc_root);
	
	printf("\nRequest object for Batches create : %s\n", out);
	strcpy ( json_alloc_inspect_type_req_obj, out );
	free(out);
	cJSON_Delete(rfc_root);
	
	return 0;
}

void get_origingroup(void)
{
	char *dw;
	int partlen;

	partlen = strcspn(part_noDup, " ");
	dw = subString(part_noDup,0,2);


	if (tc_strcmp(make_buy_indDup, "F  ") == 0)
	{
		if (car_dml == 1)
		{
			tc_strcpy(origin_group,origin_group2);
		}
		if (car_dml == 0)
		{
			tc_strcpy(origin_group,origin_group2);

		}
		if ((partlen == 11) && tc_strcmp(dw, "55") == 0)
		{
			tc_strcpy(origin_group,origin_group2);
		}

		if (tc_strcmp(mat_type, "ROH") == 0)
		{
			tc_strcpy(origin_group,origin_group2);
		}
	}
	else
	{
		tc_strcpy(origin_group,origin_group2);
	}
}

int mat_pstat_json_cr ( char *json_pstat_req_obj )
{
	
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *EXTENSIONOUT_req;
	cJSON *EXTENSIONOUT_item_req;
	
	cJSON *INTERNATIONARTICLENUMBERS_req;
	cJSON *INTERNATIONARTICLENUMBERS_item_req;
	
	cJSON *MATERIALDESCRIPTION_req;
	cJSON *MATERIALDESCRIPTION_item_req;
	
	cJSON *MATERIALTEXT_req;
	cJSON *MATERIALTEXT_item_req;
	
	cJSON *MATERIAL_EVG_req;
	
	cJSON *RETURN_req;
	cJSON *RETURN_item_req;
	
	cJSON *TAXCLASSIFICATIONS_req;
	cJSON *TAXCLASSIFICATIONS_item_req;
	
	cJSON *UNITSOFMEASURE_req;
	cJSON *UNITSOFMEASURE_item_req;
	
	
	char *out;
	
		
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	EXTENSIONOUT_req = cJSON_CreateObject();
	EXTENSIONOUT_item_req = cJSON_CreateObject();
	
	INTERNATIONARTICLENUMBERS_req = cJSON_CreateObject();
	INTERNATIONARTICLENUMBERS_item_req = cJSON_CreateObject();
	
	MATERIALDESCRIPTION_req = cJSON_CreateObject();
	MATERIALDESCRIPTION_item_req = cJSON_CreateObject();
	
	MATERIALTEXT_req = cJSON_CreateObject();
	MATERIALTEXT_item_req = cJSON_CreateObject();
	
	MATERIAL_EVG_req = cJSON_CreateObject();
	
	RETURN_req = cJSON_CreateObject();
	RETURN_item_req = cJSON_CreateObject();
	
	TAXCLASSIFICATIONS_req = cJSON_CreateObject();
	TAXCLASSIFICATIONS_item_req = cJSON_CreateObject();
	
	UNITSOFMEASURE_req = cJSON_CreateObject();
	UNITSOFMEASURE_item_req = cJSON_CreateObject();
	
	
	cJSON_AddItemToObject(rfc_root, "BAPI_MATERIAL_GETALL", exp_imp_tab_req);
	/*cJSON_AddItemToObject(exp_imp_tab_req, "COMPANYCODE", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "DISTRIBUTIONCHANNEL", cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "EXTENSIONOUT", EXTENSIONOUT_req);
		cJSON_AddItemToObject(EXTENSIONOUT_req, "item", EXTENSIONOUT_item_req);
			cJSON_AddItemToObject(EXTENSIONOUT_item_req, "STRUCTURE", cJSON_CreateString(""));
			cJSON_AddItemToObject(EXTENSIONOUT_item_req, "VALUEPART1", cJSON_CreateString(""));
			cJSON_AddItemToObject(EXTENSIONOUT_item_req, "VALUEPART2", cJSON_CreateString(""));
			cJSON_AddItemToObject(EXTENSIONOUT_item_req, "VALUEPART3", cJSON_CreateString(""));
			cJSON_AddItemToObject(EXTENSIONOUT_item_req, "VALUEPART4", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "INTERNATIONARTICLENUMBERS", INTERNATIONARTICLENUMBERS_req);
		cJSON_AddItemToObject(INTERNATIONARTICLENUMBERS_req, "item", INTERNATIONARTICLENUMBERS_item_req);
			cJSON_AddItemToObject(INTERNATIONARTICLENUMBERS_item_req, "UNIT", cJSON_CreateString(""));
			cJSON_AddItemToObject(INTERNATIONARTICLENUMBERS_item_req, "UNIT_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(INTERNATIONARTICLENUMBERS_item_req, "EAN_UPC", cJSON_CreateString(""));
			cJSON_AddItemToObject(INTERNATIONARTICLENUMBERS_item_req, "EAN_CAT", cJSON_CreateString(""));
			cJSON_AddItemToObject(INTERNATIONARTICLENUMBERS_item_req, "MAIN_EAN", cJSON_CreateString(""));
			
	cJSON_AddItemToObject(exp_imp_tab_req, "KZRFB_ALL", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "LIFOVALUATIONLEVEL", cJSON_CreateString(""));*/
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIAL", cJSON_CreateString(part_noDup));//dev=123456789999
	
	/*cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALDESCRIPTION", MATERIALDESCRIPTION_req);
		cJSON_AddItemToObject(MATERIALDESCRIPTION_req, "item", MATERIALDESCRIPTION_item_req);
			cJSON_AddItemToObject(MATERIALDESCRIPTION_item_req, "LANGU", cJSON_CreateString(""));
			cJSON_AddItemToObject(MATERIALDESCRIPTION_item_req, "LANGU_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(MATERIALDESCRIPTION_item_req, "MATL_DESC", cJSON_CreateString(""));
			
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALTEXT", MATERIALTEXT_req);
		cJSON_AddItemToObject(MATERIALTEXT_req, "item", MATERIALTEXT_item_req);
			cJSON_AddItemToObject(MATERIALTEXT_item_req, "APPLOBJECT", cJSON_CreateString(""));
			cJSON_AddItemToObject(MATERIALTEXT_item_req, "TEXT_NAME", cJSON_CreateString(""));
			cJSON_AddItemToObject(MATERIALTEXT_item_req, "TEXT_ID", cJSON_CreateString(""));
			cJSON_AddItemToObject(MATERIALTEXT_item_req, "LANGU", cJSON_CreateString(""));
			cJSON_AddItemToObject(MATERIALTEXT_item_req, "LANGU_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(MATERIALTEXT_item_req, "FORMAT_COL", cJSON_CreateString(""));
			cJSON_AddItemToObject(MATERIALTEXT_item_req, "TEXT_LINE", cJSON_CreateString(""));
		
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIAL_EVG", MATERIAL_EVG_req);
		cJSON_AddItemToObject(MATERIAL_EVG_req, "MATERIAL_EXT", cJSON_CreateString(""));
		cJSON_AddItemToObject(MATERIAL_EVG_req, "MATERIAL_VERS", cJSON_CreateString(""));
		cJSON_AddItemToObject(MATERIAL_EVG_req, "MATERIAL_GUID", cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANT", cJSON_CreateString("1001"));//dev=1001
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "RETURN", RETURN_req);
		cJSON_AddItemToObject(RETURN_req, "item", RETURN_item_req);
			cJSON_AddItemToObject(RETURN_item_req, "TYPE", cJSON_CreateString(""));
			cJSON_AddItemToObject(RETURN_item_req, "CODE", cJSON_CreateString(""));
			cJSON_AddItemToObject(RETURN_item_req, "MESSAGE", cJSON_CreateString(""));
			cJSON_AddItemToObject(RETURN_item_req, "LOG_NO", cJSON_CreateString(""));
			cJSON_AddItemToObject(RETURN_item_req, "LOG_MSG_NO", cJSON_CreateString(""));
			cJSON_AddItemToObject(RETURN_item_req, "MESSAGE_V1", cJSON_CreateString(""));
			cJSON_AddItemToObject(RETURN_item_req, "MESSAGE_V2", cJSON_CreateString(""));
			cJSON_AddItemToObject(RETURN_item_req, "MESSAGE_V3", cJSON_CreateString(""));
			cJSON_AddItemToObject(RETURN_item_req, "MESSAGE_V4", cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "SALESORGANISATION", cJSON_CreateString(""));//dev=1001
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATION", cJSON_CreateString(""));//dev=1001
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGETYPE", cJSON_CreateString(""));//dev=1001
	
	
	
		
	cJSON_AddItemToObject(exp_imp_tab_req, "TAXCLASSIFICATIONS", TAXCLASSIFICATIONS_req);
		cJSON_AddItemToObject(TAXCLASSIFICATIONS_req, "item", TAXCLASSIFICATIONS_item_req);
			cJSON_AddItemToObject(TAXCLASSIFICATIONS_item_req, "DEPCOUNTRY", cJSON_CreateString(""));
			cJSON_AddItemToObject(TAXCLASSIFICATIONS_item_req, "DEPCOUNTRY_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(TAXCLASSIFICATIONS_item_req, "TAX_TYPE_1", cJSON_CreateString(""));
			cJSON_AddItemToObject(TAXCLASSIFICATIONS_item_req, "TAXCLASS_1", cJSON_CreateString(""));
		
	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASURE", UNITSOFMEASURE_req);
		cJSON_AddItemToObject(UNITSOFMEASURE_req, "item", UNITSOFMEASURE_item_req);
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "ALT_UNIT", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "ALT_UNIT_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "NUMERATOR", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "DENOMINATR", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "EAN_UPC", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "EAN_CAT", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "LENGTH", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "WIDTH", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "HEIGHT", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "UNIT_DIM", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "UNIT_DIM_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "VOLUME", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "VOLUMEUNIT_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "GROSS_WT", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "UNIT_OF_WT", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "UNIT_OF_WT_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "SUB_UOM", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "SUB_UOM_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "INTERNAL_CHAR", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "UOMSORTNUMBER", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "LEADINGUOM", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "VALUEDUOM", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "CHAR_UNIT", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "CHAR_UNIT_ISO", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "GTIN_VARIANT", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "NET_WEIGHT", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "ME_ANZ_SUB", cJSON_CreateString(""));
			cJSON_AddItemToObject(UNITSOFMEASURE_item_req, "EWM_CW_UOM_TYPE", cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONAREA", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONTYPE", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "WAREHOUSENUMBER", cJSON_CreateString(""));*/
	
	
	
	
	out = cJSON_Print(rfc_root);
	//printf("%s\n", out);
	tc_strcpy ( json_pstat_req_obj, out ) ;
	free(out);
	cJSON_Delete(rfc_root);
	return 0;
	
}
int get_pstat_from_sap ( char *data )
{
	struct memory chunk = {0};
	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	//const char *data = readd_sap_request_json_file();
	
	//printf("\nFile request content as below : %s",data);
	
	//curl_easy_setopt(curl, CURLOPT_URL, api_url);
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_BAPI_MATERIAL_GETALL_CV");//ccap_ecn_create_DEV
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_BAPI_MATERIAL_GETALL_CV_QA");
	//curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	
	if ( tc_strcmp ( iSapServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_BAPI_MATERIAL_GETALL_CV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_BAPI_MATERIAL_GETALL_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_BAPI_MATERIAL_GETALL_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n iSapServer is Blank..!!");fflush(stdout);
	}
	
	list = curl_slist_append(list, "Content-Type: application/json");
    //curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);
	
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, 12L);
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\nFile request content as below "); fflush(stdout);
	print_json_object ( data ) ;
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
		printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
		printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
		printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	//printf ("\nresponse : [%s] [%d]",chunk.response,strlen(chunk.response)) ;
	printf("\ncurl_easy_perform");fflush(stdout);
	//print_json_object ( chunk.response ) ;
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "PSTAT");
	
		printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
		printf("\nfree"); fflush(stdout);
	
    curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}
int GetCSPstat(char cMaterial[15])
{
	char *json_pstat_req_obj = NULL;
	
	tc_strcpy(SAPpstat,"");
	
	json_pstat_req_obj = malloc(34000);
	mat_pstat_json_cr ( json_pstat_req_obj );
	printf("%s\n", json_pstat_req_obj);
	
	get_pstat_from_sap ( json_pstat_req_obj ) ;
	
	free(json_pstat_req_obj);
	return 0;
}

int pstat_basicFun(void)
{
	//printf("\n In pstat_basicFun function..[%s]\n",sappstat); fflush(stdout);
	if(tc_strlen(tc_strstr(SAPpstat,"K"))>0)
	{
		pstat = 'K';
	}
	else
	{
		pstat = '0';
	}

	
   if(tc_strlen(tc_strstr(MRPpstat,"D"))>0)
	{
		pstat_mrp = 'D';
	}
	else
	{
		pstat_mrp = '0';
	}

	
  if(tc_strlen(tc_strstr(MRPpstat,"B"))>0)
	{
		pstat_acc = 'B';
	}
	else
	{
		pstat_acc = '0';
	}
	//printf("\n..%c:%c:%c..\n",pstat,pstat_mrp,pstat_acc); fflush(stdout);
	return 0;
}

/* int tm_curl_BAPI_mmsc_sloc_update ( char *data )
{
	struct memory chunk = {0};
	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV");
	curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	
	if ( tc_strcmp ( iSapServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n iSapServer is Blank..!!");fflush(stdout);
	}
	
	list = curl_slist_append(list, "Content-Type: application/json");
    
	printf("\nFile request content as below "); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
	printf("\ncurl_easy_setopt"); fflush(stdout);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	printf("\ncurl_easy_perform");fflush(stdout);
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "BOM_DELETE");
	
	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
	printf("\nfree"); fflush(stdout);
	
	curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}

int call_BAPI_mmsc_sloc_update(char *json_mmsc_sloc_update_req_obj)
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	
	cJSON *HEADDATA_req;
	
	cJSON *STORAGELOCATIONDATA_req;
	cJSON *STORAGELOCATIONDATAX_req;
	
	char *out;
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	
	HEADDATA_req = cJSON_CreateObject();
	
	STORAGELOCATIONDATA_req = cJSON_CreateObject();
	STORAGELOCATIONDATAX_req = cJSON_CreateObject();
	
	cJSON_AddItemToObject(exp_imp_tab_req, "HEADDATA", HEADDATA_req);
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL" , cJSON_CreateString(part_noDup));
	cJSON_AddItemToObject(HEADDATA_req, "MATL_TYPE" , cJSON_CreateString(mat_type));
	cJSON_AddItemToObject(HEADDATA_req, "IND_SECTOR" , cJSON_CreateString("M"));
	cJSON_AddItemToObject(HEADDATA_req, "BASIC_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "STORAGE_VIEW" , cJSON_CreateString("X"));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATA" , STORAGELOCATIONDATA_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_LOC" , cJSON_CreateString(store_locDup));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REORDER_PT" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REPL_QTY" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "INV_CORR_FAC" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATAX" , STORAGELOCATIONDATAX_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_LOC" , cJSON_CreateString("9005"));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "INV_CORR_FAC" , cJSON_CreateString(""));

    out = cJSON_Print(rfc_root);
	printf("%s\n", out);
	free(out);
	cJSON_Delete(rfc_root);

	return 0;
}

int mmsc_sloc_update()
{
	char *json_mmsc_sloc_update_req_obj = NULL;
	json_mmsc_sloc_update_req_obj = malloc(34000);
	
	call_BAPI_mmsc_sloc_update(json_mmsc_sloc_update_req_obj);
	printf("\nRetuned Str : %s\n", json_mmsc_sloc_update_req_obj);
	tm_curl_BAPI_mmsc_sloc_update ( json_mmsc_sloc_update_req_obj );
	//tm_curl_ZBAPI_MATERIAL_SAVEDATA ( json_mmsc_sloc_update_req_obj );
	free(json_mmsc_sloc_update_req_obj);
	
	return 0;
} */

int tm_curl_BAPI_create_mat_all_view ( char *data )
{
	struct memory chunk = {0};
	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV"); //DEV
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV_QA");
	//curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	
	if ( tc_strcmp ( iSapServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n iSapServer is Blank..!!");fflush(stdout);
	}
	
	list = curl_slist_append(list, "Content-Type: application/json");
    
	printf("\nFile request content as below "); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
	printf("\ncurl_easy_setopt"); fflush(stdout);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	printf("\ncurl_easy_perform");fflush(stdout);
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "MAT_CREATE_CHANGE");
	
	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
	printf("\nfree"); fflush(stdout);
	
	curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}

int call_BAPI_create_mat_all_view(char *json_create_mat_all_view_req_obj)
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *CLIENTDATA_req;
	cJSON *CLIENTDATAX_req;
	cJSON *EXTENSIONIN_req;
	cJSON *EXTENSIONINX_req;
	cJSON *item1_req;
	cJSON *item2_req;
	
	
	cJSON *FORECASTPARAMETERS_req;
	cJSON *FORECASTPARAMETERSX_req;
	
	cJSON *HEADDATA_req;
	
	cJSON *INTERNATIONALARTNOS_req;
	cJSON *item3_req;
	
	cJSON *MATERIALDESCRIPTION_req;
	cJSON *item4_req;
	
	
	cJSON *MATERIALLONGTEXT_req;
	cJSON *item5_req;
	
	cJSON *PLANNINGDATA_req;
	cJSON *PLANNINGDATAX_req;
	
	cJSON *PLANTDATA_req;
	cJSON *PLANTDATAX_req;
	
	cJSON *PRTDATA_req;
	cJSON *item6_req;

	cJSON *PRTDATAX_req;
	cJSON *item7_req;
	
	cJSON *RETURNMESSAGES_req;
	cJSON *item8_req;

	cJSON *SALESDATA_req;
	cJSON *SALESDATAX_req;

	cJSON *STORAGELOCATIONDATA_req;
	cJSON *STORAGELOCATIONDATAX_req;

	cJSON *STORAGETYPEDATA_req;
	cJSON *STORAGETYPEDATAX_req;

	cJSON *TAXCLASSIFICATIONS_req;
	cJSON *item9_req;
	
	cJSON *UNITSOFMEASURE_req;
	cJSON *item10_req;
	
	cJSON *UNITSOFMEASUREX_req;
	cJSON *item11_req;

	cJSON *VALUATIONDATA_req;
	cJSON *VALUATIONDATAX_req;

	cJSON *WAREHOUSENUMBERDATA_req;
	cJSON *WAREHOUSENUMBERDATAX_req;
		
	
	
	char *out;
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	CLIENTDATA_req = cJSON_CreateObject();
	CLIENTDATAX_req = cJSON_CreateObject();
	
	EXTENSIONIN_req = cJSON_CreateObject();
	EXTENSIONINX_req = cJSON_CreateObject();
	item1_req = cJSON_CreateObject();
	item2_req = cJSON_CreateObject();
	
	HEADDATA_req = cJSON_CreateObject();
	
	FORECASTPARAMETERS_req = cJSON_CreateObject();
	FORECASTPARAMETERSX_req = cJSON_CreateObject();
	
	INTERNATIONALARTNOS_req = cJSON_CreateObject();
	item3_req = cJSON_CreateObject();
	
	MATERIALDESCRIPTION_req = cJSON_CreateObject();
	item4_req = cJSON_CreateObject();
	
	MATERIALLONGTEXT_req = cJSON_CreateObject();
	item5_req = cJSON_CreateObject();
	
	PLANNINGDATA_req = cJSON_CreateObject();
	PLANNINGDATAX_req = cJSON_CreateObject();
	
	PLANTDATA_req = cJSON_CreateObject();
	PLANTDATAX_req = cJSON_CreateObject();
	
	PRTDATA_req = cJSON_CreateObject();
	item6_req = cJSON_CreateObject();
	
	PRTDATAX_req = cJSON_CreateObject();
	item7_req = cJSON_CreateObject();
	
	RETURNMESSAGES_req = cJSON_CreateObject();
	item8_req = cJSON_CreateObject();
	
	
	SALESDATA_req = cJSON_CreateObject();
	SALESDATAX_req = cJSON_CreateObject();
	
	STORAGELOCATIONDATA_req = cJSON_CreateObject();
	STORAGELOCATIONDATAX_req = cJSON_CreateObject();
	
	STORAGETYPEDATA_req = cJSON_CreateObject();
	STORAGETYPEDATAX_req = cJSON_CreateObject();
	
	TAXCLASSIFICATIONS_req = cJSON_CreateObject();
	item9_req = cJSON_CreateObject();
	
	UNITSOFMEASURE_req = cJSON_CreateObject();
	item10_req = cJSON_CreateObject();
	
	UNITSOFMEASUREX_req = cJSON_CreateObject();
	item11_req = cJSON_CreateObject();
	
	VALUATIONDATA_req = cJSON_CreateObject();
	VALUATIONDATAX_req = cJSON_CreateObject();
	
	WAREHOUSENUMBERDATA_req = cJSON_CreateObject();
	WAREHOUSENUMBERDATAX_req = cJSON_CreateObject();
	
	
	cJSON_AddItemToObject(rfc_root, "ZBAPI_MATERIAL_SAVEDATA", exp_imp_tab_req);
	cJSON_AddItemToObject(exp_imp_tab_req, "CHANGE_NUMBER", cJSON_CreateString(dml_no_arg));
		
	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATA", CLIENTDATA_req);
	cJSON_AddItemToObject(CLIENTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATL_GROUP" , cJSON_CreateString(material_group));
	cJSON_AddItemToObject(CLIENTDATA_req, "OLD_MAT_NO" , cJSON_CreateString(OldMatNoDup));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM_ISO" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
	if(tc_strlen(doc_noDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "DOCUMENT" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "DOCUMENT" , cJSON_CreateString(doc_noDup));
	}
	
	if(tc_strlen(dwg_typeDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "DOC_TYPE" , cJSON_CreateString(""));
	}
	else
	{
		if(tc_strcmp(dwg_typeDup,"CMI2Drawing")==0)
		{
		  cJSON_AddItemToObject(CLIENTDATA_req, "DOC_TYPE" , cJSON_CreateString("CAD"));
		}
		else if(tc_strcmp(dwg_typeDup,"PDF")==0)
		{
		  cJSON_AddItemToObject(CLIENTDATA_req, "DOC_TYPE" , cJSON_CreateString("PDF"));
		}
		else if(tc_strcmp(dwg_typeDup,"Creo drawing")==0)
		{
		  cJSON_AddItemToObject(CLIENTDATA_req, "DOC_TYPE" , cJSON_CreateString("CRO"));
		}
		else if(tc_strcmp(dwg_typeDup,"ProDrw")==0)
		{
		  cJSON_AddItemToObject(CLIENTDATA_req, "DOC_TYPE" , cJSON_CreateString("CRO"));
		}
		else
		{
			cJSON_AddItemToObject(CLIENTDATA_req, "DOC_TYPE" , cJSON_CreateString(dwg_typeDup));
		}
	}
	if(tc_strlen(dwg_revDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "DOC_VERS" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "DOC_VERS" , cJSON_CreateString(dwg_revDup));
	}
	
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_FORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGE_NO" , cJSON_CreateString(""));
	if(tc_strlen(sheet_noDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "NO_SHEETS" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "NO_SHEETS" , cJSON_CreateString(sheet_noDup));
	}
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGEFORMAT" , cJSON_CreateString(""));
	if(tc_strlen(sizeDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "SIZE_DIM" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "SIZE_DIM" , cJSON_CreateString(sizeDup));
	}
	cJSON_AddItemToObject(CLIENTDATA_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NET_WEIGHT" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT" , cJSON_CreateString(unit_wt));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(unit_wt));
	cJSON_AddItemToObject(CLIENTDATA_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DIVISION" , cJSON_CreateString(basic_division));
	cJSON_AddItemToObject(CLIENTDATA_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QTY_GR_GI" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CAD_ID" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLOWED_WT" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLWD_VOL" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WT_TOL_LT" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(CLIENTDATA_req, "VOL_TOL_LT" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(CLIENTDATA_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "FILL_LEVEL" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "STACK_FACT" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "QM_PROCMNT" , cJSON_CreateString(qm_proc_ind));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "QM_PROCMNT" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "QM_PROCMNT" , cJSON_CreateString(""));		
	}
	
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "CATPROFILE" , cJSON_CreateString(catalog_prof));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "CATPROFILE" , cJSON_CreateString(catalog_prof));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "CATPROFILE" , cJSON_CreateString(""));		
	}
	cJSON_AddItemToObject(CLIENTDATA_req, "MINREMLIFE" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "SHELF_LIFE" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_PCT" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_STATUS" , cJSON_CreateString(""));
	/* if(tc_strlen(mm_pp_status)==0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "PUR_STATUS" , cJSON_CreateString(" "));
		printf("\nMaterial  status is........ABC : %s",mm_pp_status);
		fprintf(fsuccess,"\nMaterial  status is........ABC : %s",mm_pp_status);
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "PUR_STATUS" , cJSON_CreateString(mm_pp_status));
		printf("\nMaterial  status is........ABC1 : %s",mm_pp_status);
		fprintf(fsuccess,"\nMaterial  status is........ABC1 : %s",mm_pp_status);
	} */
	cJSON_AddItemToObject(CLIENTDATA_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATCMPLLVL" , cJSON_CreateString("00"));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString("D"));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ANP" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATAX", CLIENTDATAX_req);
	cJSON_AddItemToObject(CLIENTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATL_GROUP" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "OLD_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM_ISO" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
	if(tc_strlen(doc_noDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOCUMENT" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOCUMENT" , cJSON_CreateString("X"));
	}
	
	if(tc_strlen(dwg_typeDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_TYPE" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_TYPE" , cJSON_CreateString("X"));
	}
	if(tc_strlen(dwg_revDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_VERS" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_VERS" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_FORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGE_NO" , cJSON_CreateString(""));
	if(tc_strlen(sheet_noDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "NO_SHEETS" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "NO_SHEETS" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGEFORMAT" , cJSON_CreateString(""));
	if(tc_strlen(sizeDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "SIZE_DIM" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "SIZE_DIM" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NET_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DIVISION" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QTY_GR_GI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CAD_ID" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLOWED_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLWD_VOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WT_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VOL_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "FILL_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STACK_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "QM_PROCMNT" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "QM_PROCMNT" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "QM_PROCMNT" , cJSON_CreateString(""));		
	}
	
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "CATPROFILE" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "CATPROFILE" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "CATPROFILE" , cJSON_CreateString(""));		
	}
	
	cJSON_AddItemToObject(CLIENTDATAX_req, "MINREMLIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SHELF_LIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_PCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	/* if(tc_strlen(mm_pp_status)==0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_STATUS" , cJSON_CreateString("X"));
	} */
	cJSON_AddItemToObject(CLIENTDATAX_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATCMPLLVL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ANP" , cJSON_CreateString(""));
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_CAD_CALL", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_ONLINE", cJSON_CreateString(""));
	
	/* cJSON_AddItemToObject(exp_imp_tab_req, "EXTENSIONIN", EXTENSIONIN_req);
	cJSON_AddItemToObject(EXTENSIONIN_req, "item" , item1_req);
	cJSON_AddItemToObject(item1_req, "STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART4" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "EXTENSIONINX", EXTENSIONINX_req);
	cJSON_AddItemToObject(EXTENSIONINX_req, "item" , item2_req);
	cJSON_AddItemToObject(item2_req, "STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART4" , cJSON_CreateString("")); */

	cJSON_AddItemToObject(exp_imp_tab_req, "HEADDATA", HEADDATA_req);
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL" , cJSON_CreateString(part_noDup));
	cJSON_AddItemToObject(HEADDATA_req, "IND_SECTOR" , cJSON_CreateString("M"));
	cJSON_AddItemToObject(HEADDATA_req, "MATL_TYPE" , cJSON_CreateString(mat_type));
	cJSON_AddItemToObject(HEADDATA_req, "BASIC_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "SALES_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PURCHASE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MRP_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "FORECAST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "WORK_SCHED_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PRT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "STORAGE_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "WAREHOUSE_VIEW" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(HEADDATA_req, "QUALITY_VIEW" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(HEADDATA_req, "QUALITY_VIEW" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(HEADDATA_req, "QUALITY_VIEW" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(HEADDATA_req, "ACCOUNT_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "COST_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "INP_FLD_CHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_VERSION" , cJSON_CreateString(""));
	
	
	/* cJSON_AddItemToObject(exp_imp_tab_req, "FORECASTPARAMETERS", FORECASTPARAMETERS_req);
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FORE_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "MODEL_SI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "MODEL_SP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "PARAM_OPT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "OPTIM_LEV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "INITIALIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FORE_MODEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "ALPHA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "BETA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "GAMMA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "DELTA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "TRACKLIMIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FORE_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "HIST_VALS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "INIT_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "SEASON_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "EXPOST_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FORE_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FIXED_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "WTG_GROUP" , cJSON_CreateString("")); 

	cJSON_AddItemToObject(exp_imp_tab_req, "FORECASTPARAMETERSX", FORECASTPARAMETERSX_req);
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FORE_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "MODEL_SI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "MODEL_SP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "PARAM_OPT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "OPTIM_LEV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "INITIALIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FORE_MODEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "ALPHA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "BETA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "GAMMA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "DELTA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "TRACKLIMIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FORE_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "HIST_VALS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "INIT_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "SEASON_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "EXPOST_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FORE_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FIXED_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "WTG_GROUP" , cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "INTERNATIONALARTNOS", INTERNATIONALARTNOS_req);
	cJSON_AddItemToObject(INTERNATIONALARTNOS_req, "item" , item3_req);
	cJSON_AddItemToObject(item3_req, "UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item3_req, "UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item3_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item3_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item3_req, "DEL_FLAG" , cJSON_CreateString("")); */
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALDESCRIPTION", MATERIALDESCRIPTION_req);
	cJSON_AddItemToObject(MATERIALDESCRIPTION_req, "item" , item4_req);
	cJSON_AddItemToObject(item4_req, "LANGU" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "LANGU_ISO" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "MATL_DESC" , cJSON_CreateString(descDup));
	cJSON_AddItemToObject(item4_req, "DEL_FLAG" , cJSON_CreateString(""));
	
	/* cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALLONGTEXT", MATERIALLONGTEXT_req);
	cJSON_AddItemToObject(MATERIALLONGTEXT_req, "item" , item5_req);
	cJSON_AddItemToObject(item5_req, "APPLOBJECT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "TEXT_NAME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "TEXT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "LANGU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "LANGU_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "FORMAT_COL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "TEXT_LINE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "DEL_FLAG" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANNINGDATA", PLANNINGDATA_req);
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL" , cJSON_CreateString(splan_mat));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_PLANT" , cJSON_CreateString(splan_plant));
	cJSON_AddItemToObject(PLANNINGDATA_req, "CONVFACTOR" , cJSON_CreateString(splan_conv_fact));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_VERSION" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANNINGDATAX", PLANNINGDATAX_req);
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_PLANT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "CONVFACTOR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_VERSION" , cJSON_CreateString("")); */
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATA", PLANTDATA_req);
	cJSON_AddItemToObject(PLANTDATA_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(PLANTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ABC_ID" , cJSON_CreateString(abc_ind));
	cJSON_AddItemToObject(PLANTDATA_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT" , cJSON_CreateString(uoissue));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(uoissue));
	cJSON_AddItemToObject(PLANTDATA_req, "MRPPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_TYPE" , cJSON_CreateString(mrp_type));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_CTRLER" , cJSON_CreateString(mrp_controller));
	cJSON_AddItemToObject(PLANTDATA_req, "PLND_DELRY" , cJSON_CreateString("0"));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(grptime));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(grptime));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(""));		
	}
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_IND" , cJSON_CreateString(period_ind));
	cJSON_AddItemToObject(PLANTDATA_req, "ASSY_SCRAP" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "LOTSIZEKEY" , cJSON_CreateString(lot_size_key));
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TYPE" , cJSON_CreateString(proc_type));
	cJSON_AddItemToObject(PLANTDATA_req, "SPPROCTYPE" , cJSON_CreateString(spl_proc_key));
	cJSON_AddItemToObject(PLANTDATA_req, "REORDER_PT" , cJSON_CreateString(reord_pt));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETY_STK" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "MINLOTSIZE" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "MAXLOTSIZE" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "FIXED_LOT" , cJSON_CreateString(fixed_lot_size));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_VAL" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_STOCK" , cJSON_CreateString(max_stlvl));
	cJSON_AddItemToObject(PLANTDATA_req, "ORD_COSTS" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(PLANTDATA_req, "DEP_REQ_ID" , cJSON_CreateString(ind_collect));
	cJSON_AddItemToObject(PLANTDATA_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ALT_BOM_ID" , cJSON_CreateString(alternativb));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "GRP_REQMTS" , cJSON_CreateString(req_grp));
	cJSON_AddItemToObject(PLANTDATA_req, "MIXED_MRP" , cJSON_CreateString(mixedmrp));
	cJSON_AddItemToObject(PLANTDATA_req, "SM_KEY" , cJSON_CreateString(sched_mar_key));
	cJSON_AddItemToObject(PLANTDATA_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TIME" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUPTIME" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "INTEROP" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "INHSEPRODT" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(PLANTDATA_req, "STGEPERIOD" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVER_TOL" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(PLANTDATA_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNDER_TOL" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLENTIME" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLACE_PT" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATA_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATA_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	}
	
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATA_req, "CTRL_KEY" , cJSON_CreateString(control_key));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATA_req, "CTRL_KEY" , cJSON_CreateString(control_key));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "CTRL_KEY" , cJSON_CreateString(""));
	}
	
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATA_req, "DOC_REQD" , cJSON_CreateString(doc_req));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATA_req, "DOC_REQD" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "DOC_REQD" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QUOTAUSAGE" , cJSON_CreateString(quota_arrangement_usage));
	cJSON_AddItemToObject(PLANTDATA_req, "SERV_LEVEL" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(PLANTDATA_req, "SPLIT_IND" , cJSON_CreateString(costing_split_valuation));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAILCHECK" , cJSON_CreateString(avail_chk));
	cJSON_AddItemToObject(PLANTDATA_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUP_TIME" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY_PLAN" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "SHIP_PROC_TIME" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROFIT_CTR" , cJSON_CreateString(profit_centre_sap));
	cJSON_AddItemToObject(PLANTDATA_req, "PPC_PL_CAL" , cJSON_CreateString(plan_calendar));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		if(tc_strlen(rep_mfg)>0)		//rep_mfg modified on 14.02.2017 for TE02
		{
			cJSON_AddItemToObject(PLANTDATA_req, "REP_MANUF" , cJSON_CreateString("X"));
			cJSON_AddItemToObject(PLANTDATA_req, "REPMANPROF" , cJSON_CreateString(rep_mfg));
		}
		else
		{
			cJSON_AddItemToObject(PLANTDATA_req, "REP_MANUF" , cJSON_CreateString(""));
			cJSON_AddItemToObject(PLANTDATA_req, "REPMANPROF" , cJSON_CreateString(""));
		}
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		
	}
	else    /* as per req. on 1/8 */
	{
		
	}
	cJSON_AddItemToObject(PLANTDATA_req, "PL_TI_FNCE" , cJSON_CreateString("000"));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BWD_CONS" , cJSON_CreateString("000"));
	cJSON_AddItemToObject(PLANTDATA_req, "FWD_CONS" , cJSON_CreateString("000"));
	cJSON_AddItemToObject(PLANTDATA_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_SIZE" , cJSON_CreateString(cost_lot_size));
	cJSON_AddItemToObject(PLANTDATA_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	if(tc_strlen(store_locDup)>0)
	{
					//string strtoupper ( string store_locDup );
					//store_locDup1 = strtoupper(store_locDup);

		printf ("Before conversion: %s\n", store_locDup);
		for (p = store_locDup; *p != '\0'; ++p)
		{
			*p = toupper(*p);
		}
		printf ("After conversion: %s\n", store_locDup);
		cJSON_AddItemToObject(PLANTDATA_req, "ISS_ST_LOC" , cJSON_CreateString(store_locDup));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "ISS_ST_LOC" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_GROUP" , cJSON_CreateString(mrp_grp));
	cJSON_AddItemToObject(PLANTDATA_req, "COMP_SCRAP" , cJSON_CreateString(myzeroDup2));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATA_req, "CERT_TYPE" , cJSON_CreateString(certificate_type));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATA_req, "CERT_TYPE" , cJSON_CreateString(certificate_type));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "CERT_TYPE" , cJSON_CreateString(""));
	}
			
	cJSON_AddItemToObject(PLANTDATA_req, "CYCLE_TIME" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(PLANTDATA_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "VARIANCE_KEY" , cJSON_CreateString(variance_key));
	cJSON_AddItemToObject(PLANTDATA_req, "SERNO_PROF" , cJSON_CreateString(""));
	/* if(tc_strlen(rep_mfg)>0)		//rep_mfg modified on 14.02.2017 for TE02
	{
		cJSON_AddItemToObject(PLANTDATA_req, "REPMANPROF" , cJSON_CreateString(rep_mfg));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "REPMANPROF" , cJSON_CreateString(""));
	} */
	cJSON_AddItemToObject(PLANTDATA_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MULT_REF_M" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INSP_INT" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(PLANTDATA_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLAN_STRGP" , cJSON_CreateString(""));
	if(tc_strlen(store_locDup)>0)
	{
					//string strtoupper ( string store_locDup );
					//store_locDup1 = strtoupper(store_locDup);

		printf ("Before conversion: %s\n", store_locDup);
		for (p = store_locDup; *p != '\0'; ++p)
		{
			*p = toupper(*p);
		}
		printf ("After conversion: %s\n", store_locDup);
		
		cJSON_AddItemToObject(PLANTDATA_req, "SLOC_EXPRC" , cJSON_CreateString(store_locDup));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "SLOC_EXPRC" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "BULK_MAT" , cJSON_CreateString(blk_ind));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DETERM_GRP" , cJSON_CreateString(stock_det_group));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
	if(tc_strlen(mm_pp_status)==0)
	{
		cJSON_AddItemToObject(PLANTDATA_req, "PUR_STATUS" , cJSON_CreateString(" "));
		printf("\nMaterial  status is........ABC : %s",mm_pp_status);
		fprintf(fsuccess,"\nMaterial  status is........ABC : %s",mm_pp_status);
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "PUR_STATUS" , cJSON_CreateString(mm_pp_status));
		printf("\nMaterial  status is........ABC1 : %s",mm_pp_status);
		fprintf(fsuccess,"\nMaterial  status is........ABC1 : %s",mm_pp_status);
	}
	cJSON_AddItemToObject(PLANTDATA_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETYTIME" , cJSON_CreateString("00"));
	cJSON_AddItemToObject(PLANTDATA_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEPLOY_HORIZ" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_LOT_SIZE" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_LOT_SIZE" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "FIX_LOT_SIZE" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_INCREMENT" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_SAFETY_STK" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATAX", PLANTDATAX_req);
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ABC_ID" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRPPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_TYPE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_CTRLER" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLND_DELRY" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_IND" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "ASSY_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOTSIZEKEY" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TYPE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPPROCTYPE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "REORDER_PT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MINLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAXLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIXED_LOT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_VAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_STOCK" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORD_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEP_REQ_ID" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALT_BOM_ID" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "GRP_REQMTS" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIXED_MRP" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SM_KEY" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUPTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INTEROP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INHSEPRODT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGEPERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNDER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLENTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLACE_PT" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		//cJSON_AddItemToObject(PLANTDATAX_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString("qua_ins_ind"));
		cJSON_AddItemToObject(PLANTDATAX_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	}
	
	
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_KEY" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_KEY" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_KEY" , cJSON_CreateString(""));
	}
					
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "DOC_REQD" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "DOC_REQD" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "DOC_REQD" , cJSON_CreateString(""));
	}
	
	cJSON_AddItemToObject(PLANTDATAX_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QUOTAUSAGE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERV_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPLIT_IND" , cJSON_CreateString(""));/*Please make it as X*/
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAILCHECK" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUP_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY_PLAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SHIP_PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROFIT_CTR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "PPC_PL_CAL" , cJSON_CreateString("X"));
	if(tc_strlen(rep_mfg)>0)		//rep_mfg modified on 14.02.2017 for TE02
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "REP_MANUF" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "REP_MANUF" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "PL_TI_FNCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_SIZE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	if(tc_strlen(store_locDup)>0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "ISS_ST_LOC" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "ISS_ST_LOC" , cJSON_CreateString(""));
		printf("\nstore location is null"); 
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_GROUP" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMP_SCRAP" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "CERT_TYPE" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "CERT_TYPE" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "CERT_TYPE" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "CYCLE_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "VARIANCE_KEY" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERNO_PROF" , cJSON_CreateString(""));
	if(tc_strlen(rep_mfg)>0)		//rep_mfg modified on 14.02.2017 for TE02
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "REPMANPROF" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "REPMANPROF" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MULT_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INSP_INT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLAN_STRGP" , cJSON_CreateString(""));
	if(tc_strlen(store_locDup)>0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "SLOC_EXPRC" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "SLOC_EXPRC" , cJSON_CreateString(""));
		printf("\nstore location is null"); 
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "BULK_MAT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DETERM_GRP" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
	if(tc_strlen(mm_pp_status)==0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "PUR_STATUS" , cJSON_CreateString("X"));
		printf("\nMaterial  status is........ABC : %s",mm_pp_status);
		fprintf(fsuccess,"\nMaterial  status is........ABC : %s",mm_pp_status);
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "PUR_STATUS" , cJSON_CreateString("X"));
		printf("\nMaterial  status is........ABC1 : %s",mm_pp_status);
		fprintf(fsuccess,"\nMaterial  status is........ABC1 : %s",mm_pp_status);
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETYTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEPLOY_HORIZ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_INCREMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));

	/* cJSON_AddItemToObject(exp_imp_tab_req, "PRTDATA", PRTDATA_req);
	cJSON_AddItemToObject(PRTDATA_req, "item", item6_req);
	cJSON_AddItemToObject(item6_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(item6_req, "CREATE_LOAD_RECS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "CTRL_KEY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "GRP_KEY_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "GRP_KEY_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "PRT_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "STD_TEXT_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "REF_KEY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_REF_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "ST_REF_DATE_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_OFFSET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_OFFSET_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_OFFSET_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_OFFSET_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_REF_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_REF_DATE_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_OFFSET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_OFFSET_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_OFFSET_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_OFFSET_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "FORMULA_TOT_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "FORMULA_TOT_QTY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "FORMULA_TOT_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "FORMULA_TOT_USAGE_NO_CHG" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PRTDATAX", PRTDATAX_req);
	cJSON_AddItemToObject(PRTDATAX_req, "item", item7_req);
	cJSON_AddItemToObject(item7_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(item7_req, "CREATE_LOAD_RECS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "CTRL_KEY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "GRP_KEY_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "GRP_KEY_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "PRT_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "STD_TEXT_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "REF_KEY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_REF_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "ST_REF_DATE_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_OFFSET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_OFFSET_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_OFFSET_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_OFFSET_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_REF_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_REF_DATE_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_OFFSET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_OFFSET_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_OFFSET_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_OFFSET_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "FORMULA_TOT_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "FORMULA_TOT_QTY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "FORMULA_TOT_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "FORMULA_TOT_USAGE_NO_CHG" , cJSON_CreateString("")); */
	
	cJSON_AddItemToObject(exp_imp_tab_req, "RETURNMESSAGES", RETURNMESSAGES_req);
	cJSON_AddItemToObject(RETURNMESSAGES_req, "item", item8_req);
	cJSON_AddItemToObject(item8_req, "TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "NUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_MSG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "PARAMETER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ROW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "FIELD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "SYSTEM" , cJSON_CreateString(""));
	
	/* cJSON_AddItemToObject(exp_imp_tab_req, "SALESDATA", SALESDATA_req);
	cJSON_AddItemToObject(SALESDATA_req, "SALES_ORG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DISTR_CHAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_STATS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "REBATE_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "COMM_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "CASH_DISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MIN_ORDER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MIN_DELY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MIN_MTO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DELY_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DELY_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DELY_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "SALES_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "SALES_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DELYG_PLNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PR_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MAT_PR_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "ACCT_ASSGT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_6" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_7" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_8" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_9" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT10" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "VAR_SALES_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PR_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PR_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PR_REF_MAT_VERSION" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "SALESDATAX", SALESDATAX_req);
	cJSON_AddItemToObject(SALESDATAX_req, "SALES_ORG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DISTR_CHAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_STATS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "REBATE_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "COMM_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "CASH_DISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MIN_ORDER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MIN_DELY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MIN_MTO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DELY_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DELY_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DELY_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "SALES_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "SALES_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DELYG_PLNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PR_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MAT_PR_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "ACCT_ASSGT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_6" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_7" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_8" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_9" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT10" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "VAR_SALES_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PR_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PR_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PR_REF_MAT_VERSION" , cJSON_CreateString("")); */
	
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATA" , STORAGELOCATIONDATA_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_LOC" , cJSON_CreateString("9005"));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REORDER_PT" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REPL_QTY" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "INV_CORR_FAC" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATAX" , STORAGELOCATIONDATAX_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_LOC" , cJSON_CreateString("9005"));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "INV_CORR_FAC" , cJSON_CreateString(""));
	
	/* cJSON_AddItemToObject(exp_imp_tab_req, "STORAGETYPEDATA" , STORAGETYPEDATA_req);
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "WHSE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "STGE_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "MAX_SB_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "MIN_SB_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "CTRL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "REPLEN_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "PICK_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "ROUND_QTY" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGETYPEDATAX" , STORAGETYPEDATAX_req);
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "WHSE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "STGE_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "MAX_SB_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "MIN_SB_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "CTRL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "REPLEN_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "PICK_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "ROUND_QTY" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "TAXCLASSIFICATIONS" , TAXCLASSIFICATIONS_req);
	cJSON_AddItemToObject(TAXCLASSIFICATIONS_req, "item" , item9_req);
	cJSON_AddItemToObject(item9_req, "DEPCOUNTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "DEPCOUNTRY_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_6" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_6" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_7" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_7" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_8" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_8" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_9" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_9" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_IND" , cJSON_CreateString("")); */
	
	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASURE" , UNITSOFMEASURE_req);
	cJSON_AddItemToObject(UNITSOFMEASURE_req, "item" , item10_req);
	cJSON_AddItemToObject(item10_req, "ALT_UNIT" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(item10_req, "ALT_UNIT_ISO" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(item10_req, "NUMERATOR" , cJSON_CreateString("1"));
	cJSON_AddItemToObject(item10_req, "DENOMINATR" , cJSON_CreateString("1"));
	cJSON_AddItemToObject(item10_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUME" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT" , cJSON_CreateString(vol_unit));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT_ISO" , cJSON_CreateString(vol_unit));
	cJSON_AddItemToObject(item10_req, "GROSS_WT" , cJSON_CreateString(gross_wt));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT" , cJSON_CreateString(unit_wt));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(unit_wt));
	cJSON_AddItemToObject(item10_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString(""));

	
	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASUREX" , UNITSOFMEASUREX_req);
	cJSON_AddItemToObject(UNITSOFMEASUREX_req, "item" , item11_req);
	cJSON_AddItemToObject(item11_req, "ALT_UNIT" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(item11_req, "ALT_UNIT_ISO" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(item11_req, "NUMERATOR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "DENOMINATR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUME" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT_ISO" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "GROSS_WT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT_ISO" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATA" , VALUATIONDATA_req);
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_AREA" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_CTRL" , cJSON_CreateString(price_con));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOVING_PR" , cJSON_CreateString(moving_avg_price));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PRICE" , cJSON_CreateString(std_price));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CLASS" , cJSON_CreateString(val_class));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PP" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PP" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PP" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PY" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PY" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PY" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CAT" , cJSON_CreateString(valuation_cat));
	cJSON_AddItemToObject(VALUATIONDATA_req, "FUTURE_PR" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_1" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE1" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_3" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE3" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLND_PRICE" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE1" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE2" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE3" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_2" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE2" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEVAL_IND" , cJSON_CreateString("00"));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_GROUP" , cJSON_CreateString(origin_group));
	cJSON_AddItemToObject(VALUATIONDATA_req, "OVERHEAD_GRP" , cJSON_CreateString(overhd_grp));
	cJSON_AddItemToObject(VALUATIONDATA_req, "QTY_STRUCT" , cJSON_CreateString(with_quantity_structure));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_MAT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MAT_ORIGIN" , cJSON_CreateString(mat_origin));
	cJSON_AddItemToObject(VALUATIONDATA_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAX_CML_UN" , cJSON_CreateString("0"));

	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATAX" , VALUATIONDATAX_req);
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_AREA" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_CTRL" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOVING_PR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PRICE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CLASS" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CAT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "FUTURE_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLND_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEVAL_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_GROUP" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "OVERHEAD_GRP" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "QTY_STRUCT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_MAT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MAT_ORIGIN" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAX_CML_UN" , cJSON_CreateString(""));
	
	/* cJSON_AddItemToObject(exp_imp_tab_req, "WAREHOUSENUMBERDATA" , WAREHOUSENUMBERDATA_req);
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "WHSE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "STGESECTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "PLACEMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "WITHDRAWAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "L_EQUIP_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "L_EQUIP_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "L_EQUIP_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_1_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_2_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_3_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "UNITTYPE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "UNITTYPE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "UNITTYPE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "WM_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "WM_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "ADD_TO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "BLOCK_STGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "MSG_TO_IM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "SPEC_MVMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "CAPY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "PROCURE_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "PROCURE_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "STGE_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "REF_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "STEP_PICK" , cJSON_CreateString("")); 

	cJSON_AddItemToObject(exp_imp_tab_req, "WAREHOUSENUMBERDATAX" , WAREHOUSENUMBERDATAX_req);
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "WHSE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "STGESECTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "PLACEMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "WITHDRAWAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "L_EQUIP_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "L_EQUIP_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "L_EQUIP_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_1_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_2_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_3_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "UNITTYPE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "UNITTYPE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "UNITTYPE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "WM_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "WM_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "ADD_TO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "BLOCK_STGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "MSG_TO_IM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "SPEC_MVMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "CAPY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "PROCURE_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "PROCURE_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "STGE_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "REF_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "STEP_PICK" , cJSON_CreateString("")); */
	    
		
	out = cJSON_Print(rfc_root);//json_create_mat_all_view_req_obj
	tc_strcpy(json_create_mat_all_view_req_obj,out);
	printf("%s\n", out);
	free(out);
	cJSON_Delete(rfc_root);

	return 0;
}

int create_mat_all_view()
{
	char *json_create_mat_all_view_req_obj = NULL;
	json_create_mat_all_view_req_obj = malloc(234000);
	
	call_BAPI_create_mat_all_view(json_create_mat_all_view_req_obj);
	printf("\nRetuned Str : %s\n", json_create_mat_all_view_req_obj);
	tm_curl_BAPI_create_mat_all_view ( json_create_mat_all_view_req_obj );
	//tm_curl_ZBAPI_MATERIAL_SAVEDATA ( json_create_mat_all_view_req_obj );
	free(json_create_mat_all_view_req_obj);
	
	return 0;
}

int tm_curl_BAPI_extend_mat_in_plant ( char *data )
{
	struct memory chunk = {0};
	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV"); //DEV
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV_QA");
	//curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	
	if ( tc_strcmp ( iSapServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n iSapServer is Blank..!!");fflush(stdout);
	}
	
	list = curl_slist_append(list, "Content-Type: application/json");
    
	printf("\nFile request content as below "); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
	printf("\ncurl_easy_setopt"); fflush(stdout);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	printf("\ncurl_easy_perform");fflush(stdout);
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "BOM_DELETE");
	
	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
	printf("\nfree"); fflush(stdout);
	
	curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}
int call_BAPI_extend_mat_in_plant(char *json_extend_mat_in_plant_req_obj)
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *CLIENTDATA_req;
	cJSON *CLIENTDATAX_req;
	cJSON *EXTENSIONIN_req;
	cJSON *EXTENSIONINX_req;
	cJSON *item1_req;
	cJSON *item2_req;
	
	
	cJSON *FORECASTPARAMETERS_req;
	cJSON *FORECASTPARAMETERSX_req;
	
	cJSON *HEADDATA_req;
	
	cJSON *INTERNATIONALARTNOS_req;
	cJSON *item3_req;
	
	cJSON *MATERIALDESCRIPTION_req;
	cJSON *item4_req;
	
	
	cJSON *MATERIALLONGTEXT_req;
	cJSON *item5_req;
	
	cJSON *PLANNINGDATA_req;
	cJSON *PLANNINGDATAX_req;
	
	cJSON *PLANTDATA_req;
	cJSON *PLANTDATAX_req;
	
	cJSON *PRTDATA_req;
	cJSON *item6_req;

	cJSON *PRTDATAX_req;
	cJSON *item7_req;
	
	cJSON *RETURNMESSAGES_req;
	cJSON *item8_req;

	cJSON *SALESDATA_req;
	cJSON *SALESDATAX_req;

	cJSON *STORAGELOCATIONDATA_req;
	cJSON *STORAGELOCATIONDATAX_req;

	cJSON *STORAGETYPEDATA_req;
	cJSON *STORAGETYPEDATAX_req;

	cJSON *TAXCLASSIFICATIONS_req;
	cJSON *item9_req;
	
	cJSON *UNITSOFMEASURE_req;
	cJSON *item10_req;
	
	cJSON *UNITSOFMEASUREX_req;
	cJSON *item11_req;

	cJSON *VALUATIONDATA_req;
	cJSON *VALUATIONDATAX_req;

	cJSON *WAREHOUSENUMBERDATA_req;
	cJSON *WAREHOUSENUMBERDATAX_req;
		
	
	
	char *out;
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	CLIENTDATA_req = cJSON_CreateObject();
	CLIENTDATAX_req = cJSON_CreateObject();
	
	EXTENSIONIN_req = cJSON_CreateObject();
	EXTENSIONINX_req = cJSON_CreateObject();
	item1_req = cJSON_CreateObject();
	item2_req = cJSON_CreateObject();
	
	HEADDATA_req = cJSON_CreateObject();
	
	FORECASTPARAMETERS_req = cJSON_CreateObject();
	FORECASTPARAMETERSX_req = cJSON_CreateObject();
	
	INTERNATIONALARTNOS_req = cJSON_CreateObject();
	item3_req = cJSON_CreateObject();
	
	MATERIALDESCRIPTION_req = cJSON_CreateObject();
	item4_req = cJSON_CreateObject();
	
	MATERIALLONGTEXT_req = cJSON_CreateObject();
	item5_req = cJSON_CreateObject();
	
	PLANNINGDATA_req = cJSON_CreateObject();
	PLANNINGDATAX_req = cJSON_CreateObject();
	
	PLANTDATA_req = cJSON_CreateObject();
	PLANTDATAX_req = cJSON_CreateObject();
	
	PRTDATA_req = cJSON_CreateObject();
	item6_req = cJSON_CreateObject();
	
	PRTDATAX_req = cJSON_CreateObject();
	item7_req = cJSON_CreateObject();
	
	RETURNMESSAGES_req = cJSON_CreateObject();
	item8_req = cJSON_CreateObject();
	
	
	SALESDATA_req = cJSON_CreateObject();
	SALESDATAX_req = cJSON_CreateObject();
	
	STORAGELOCATIONDATA_req = cJSON_CreateObject();
	STORAGELOCATIONDATAX_req = cJSON_CreateObject();
	
	STORAGETYPEDATA_req = cJSON_CreateObject();
	STORAGETYPEDATAX_req = cJSON_CreateObject();
	
	TAXCLASSIFICATIONS_req = cJSON_CreateObject();
	item9_req = cJSON_CreateObject();
	
	UNITSOFMEASURE_req = cJSON_CreateObject();
	item10_req = cJSON_CreateObject();
	
	UNITSOFMEASUREX_req = cJSON_CreateObject();
	item11_req = cJSON_CreateObject();
	
	VALUATIONDATA_req = cJSON_CreateObject();
	VALUATIONDATAX_req = cJSON_CreateObject();
	
	WAREHOUSENUMBERDATA_req = cJSON_CreateObject();
	WAREHOUSENUMBERDATAX_req = cJSON_CreateObject();
	
	
	cJSON_AddItemToObject(rfc_root, "ZBAPI_MATERIAL_SAVEDATA", exp_imp_tab_req);
	cJSON_AddItemToObject(exp_imp_tab_req, "CHANGE_NUMBER", cJSON_CreateString(dml_no_arg));
		
	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATA", CLIENTDATA_req);
	cJSON_AddItemToObject(CLIENTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATL_GROUP" , cJSON_CreateString(material_group));
	cJSON_AddItemToObject(CLIENTDATA_req, "OLD_MAT_NO" , cJSON_CreateString(OldMatNoDup));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM_ISO" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
	if(tc_strlen(doc_noDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "DOCUMENT" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "DOCUMENT" , cJSON_CreateString(doc_noDup));
	}
	
	if(tc_strlen(dwg_typeDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "DOC_TYPE" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "DOC_TYPE" , cJSON_CreateString(dwg_typeDup));
	}
	if(tc_strlen(dwg_revDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "DOC_VERS" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "DOC_VERS" , cJSON_CreateString(dwg_revDup));
	}
	
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_FORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGE_NO" , cJSON_CreateString(""));
	if(tc_strlen(sheet_noDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "NO_SHEETS" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "NO_SHEETS" , cJSON_CreateString(sheet_noDup));
	}
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGEFORMAT" , cJSON_CreateString(""));
	if(tc_strlen(sizeDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "SIZE_DIM" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "SIZE_DIM" , cJSON_CreateString(sizeDup));
	}
	cJSON_AddItemToObject(CLIENTDATA_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NET_WEIGHT" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT" , cJSON_CreateString(unit_wt));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(unit_wt));
	cJSON_AddItemToObject(CLIENTDATA_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DIVISION" , cJSON_CreateString(basic_division));
	cJSON_AddItemToObject(CLIENTDATA_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QTY_GR_GI" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CAD_ID" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLOWED_WT" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLWD_VOL" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WT_TOL_LT" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(CLIENTDATA_req, "VOL_TOL_LT" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(CLIENTDATA_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "FILL_LEVEL" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "STACK_FACT" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "QM_PROCMNT" , cJSON_CreateString(qm_proc_ind));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "QM_PROCMNT" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "QM_PROCMNT" , cJSON_CreateString(""));		
	}
	
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "CATPROFILE" , cJSON_CreateString(catalog_prof));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "CATPROFILE" , cJSON_CreateString(catalog_prof));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "CATPROFILE" , cJSON_CreateString(""));		
	}
	cJSON_AddItemToObject(CLIENTDATA_req, "MINREMLIFE" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "SHELF_LIFE" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_PCT" , cJSON_CreateString("0"));
	if(tc_strlen(mm_pp_status)==0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "PUR_STATUS" , cJSON_CreateString(" "));
		printf("\nMaterial  status is........ABC : %s",mm_pp_status);
		fprintf(fsuccess,"\nMaterial  status is........ABC : %s",mm_pp_status);
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "PUR_STATUS" , cJSON_CreateString(mm_pp_status));
		printf("\nMaterial  status is........ABC1 : %s",mm_pp_status);
		fprintf(fsuccess,"\nMaterial  status is........ABC1 : %s",mm_pp_status);
	}
	cJSON_AddItemToObject(CLIENTDATA_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATCMPLLVL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString("D"));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ANP" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATAX", CLIENTDATAX_req);
	cJSON_AddItemToObject(CLIENTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "OLD_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM_ISO" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
	if(tc_strlen(doc_noDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOCUMENT" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOCUMENT" , cJSON_CreateString("X"));
	}
	
	if(tc_strlen(dwg_typeDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_TYPE" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_TYPE" , cJSON_CreateString("X"));
	}
	if(tc_strlen(dwg_revDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_VERS" , cJSON_CreateString(""));
	}
	else
	{
				cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_VERS" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_FORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGE_NO" , cJSON_CreateString(""));
	if(tc_strlen(sheet_noDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "NO_SHEETS" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "NO_SHEETS" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGEFORMAT" , cJSON_CreateString(""));
	if(tc_strlen(sizeDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "SIZE_DIM" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "SIZE_DIM" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NET_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DIVISION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QTY_GR_GI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CAD_ID" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLOWED_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLWD_VOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WT_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VOL_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "FILL_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STACK_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "QM_PROCMNT" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "QM_PROCMNT" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "QM_PROCMNT" , cJSON_CreateString(""));		
	}
	
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "CATPROFILE" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "CATPROFILE" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "CATPROFILE" , cJSON_CreateString(""));		
	}
	
	cJSON_AddItemToObject(CLIENTDATAX_req, "MINREMLIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SHELF_LIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_PCT" , cJSON_CreateString(""));
	if(tc_strlen(mm_pp_status)==0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_STATUS" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATCMPLLVL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ANP" , cJSON_CreateString(""));
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_CAD_CALL", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_ONLINE", cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "EXTENSIONIN", EXTENSIONIN_req);
	cJSON_AddItemToObject(EXTENSIONIN_req, "item" , item1_req);
	cJSON_AddItemToObject(item1_req, "STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART4" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "EXTENSIONINX", EXTENSIONINX_req);
	cJSON_AddItemToObject(EXTENSIONINX_req, "item" , item2_req);
	cJSON_AddItemToObject(item2_req, "STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART4" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "HEADDATA", HEADDATA_req);
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL" , cJSON_CreateString(part_noDup));
	cJSON_AddItemToObject(HEADDATA_req, "IND_SECTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATL_TYPE" , cJSON_CreateString(mat_type));
	cJSON_AddItemToObject(HEADDATA_req, "BASIC_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "SALES_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PURCHASE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MRP_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "FORECAST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "WORK_SCHED_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PRT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "STORAGE_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "WAREHOUSE_VIEW" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(HEADDATA_req, "QUALITY_VIEW" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(HEADDATA_req, "QUALITY_VIEW" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(HEADDATA_req, "ACCOUNT_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "COST_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "INP_FLD_CHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_VERSION" , cJSON_CreateString(""));
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "FORECASTPARAMETERS", FORECASTPARAMETERS_req);
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FORE_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "MODEL_SI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "MODEL_SP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "PARAM_OPT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "OPTIM_LEV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "INITIALIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FORE_MODEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "ALPHA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "BETA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "GAMMA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "DELTA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "TRACKLIMIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FORE_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "HIST_VALS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "INIT_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "SEASON_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "EXPOST_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FORE_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FIXED_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "WTG_GROUP" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "FORECASTPARAMETERSX", FORECASTPARAMETERSX_req);
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FORE_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "MODEL_SI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "MODEL_SP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "PARAM_OPT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "OPTIM_LEV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "INITIALIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FORE_MODEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "ALPHA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "BETA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "GAMMA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "DELTA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "TRACKLIMIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FORE_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "HIST_VALS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "INIT_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "SEASON_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "EXPOST_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FORE_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FIXED_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "WTG_GROUP" , cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "INTERNATIONALARTNOS", INTERNATIONALARTNOS_req);
	cJSON_AddItemToObject(INTERNATIONALARTNOS_req, "item" , item3_req);
	cJSON_AddItemToObject(item3_req, "UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item3_req, "UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item3_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item3_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item3_req, "DEL_FLAG" , cJSON_CreateString(""));
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALDESCRIPTION", MATERIALDESCRIPTION_req);
	cJSON_AddItemToObject(MATERIALDESCRIPTION_req, "item" , item4_req);
	cJSON_AddItemToObject(item4_req, "LANGU" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "LANGU_ISO" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "MATL_DESC" , cJSON_CreateString(descDup));
	cJSON_AddItemToObject(item4_req, "DEL_FLAG" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALLONGTEXT", MATERIALLONGTEXT_req);
	cJSON_AddItemToObject(MATERIALLONGTEXT_req, "item" , item5_req);
	cJSON_AddItemToObject(item5_req, "APPLOBJECT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "TEXT_NAME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "TEXT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "LANGU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "LANGU_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "FORMAT_COL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "TEXT_LINE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "DEL_FLAG" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANNINGDATA", PLANNINGDATA_req);
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL" , cJSON_CreateString(splan_mat));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_PLANT" , cJSON_CreateString(splan_plant));
	cJSON_AddItemToObject(PLANNINGDATA_req, "CONVFACTOR" , cJSON_CreateString(splan_conv_fact));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_VERSION" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANNINGDATAX", PLANNINGDATAX_req);
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_PLANT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "CONVFACTOR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_VERSION" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATA", PLANTDATA_req);
	cJSON_AddItemToObject(PLANTDATA_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(PLANTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ABC_ID" , cJSON_CreateString(abc_ind));
	cJSON_AddItemToObject(PLANTDATA_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT" , cJSON_CreateString(uoissue));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(uoissue));
	cJSON_AddItemToObject(PLANTDATA_req, "MRPPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_TYPE" , cJSON_CreateString(mrp_type));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_CTRLER" , cJSON_CreateString(mrp_controller));
	cJSON_AddItemToObject(PLANTDATA_req, "PLND_DELRY" , cJSON_CreateString("0"));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(grptime));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(grptime));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(""));		
	}
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_IND" , cJSON_CreateString(period_ind));
	cJSON_AddItemToObject(PLANTDATA_req, "ASSY_SCRAP" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "LOTSIZEKEY" , cJSON_CreateString(lot_size_key));
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TYPE" , cJSON_CreateString(proc_type));
	cJSON_AddItemToObject(PLANTDATA_req, "SPPROCTYPE" , cJSON_CreateString(spl_proc_key));
	cJSON_AddItemToObject(PLANTDATA_req, "REORDER_PT" , cJSON_CreateString(reord_pt));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETY_STK" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "MINLOTSIZE" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "MAXLOTSIZE" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "FIXED_LOT" , cJSON_CreateString(fixed_lot_size));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_VAL" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_STOCK" , cJSON_CreateString(max_stlvl));
	cJSON_AddItemToObject(PLANTDATA_req, "ORD_COSTS" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(PLANTDATA_req, "DEP_REQ_ID" , cJSON_CreateString(ind_collect));
	cJSON_AddItemToObject(PLANTDATA_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ALT_BOM_ID" , cJSON_CreateString(alternativb));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "GRP_REQMTS" , cJSON_CreateString(req_grp));
	cJSON_AddItemToObject(PLANTDATA_req, "MIXED_MRP" , cJSON_CreateString(mixedmrp));
	cJSON_AddItemToObject(PLANTDATA_req, "SM_KEY" , cJSON_CreateString(sched_mar_key));
	cJSON_AddItemToObject(PLANTDATA_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TIME" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUPTIME" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "INTEROP" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "INHSEPRODT" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(PLANTDATA_req, "STGEPERIOD" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVER_TOL" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(PLANTDATA_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNDER_TOL" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLENTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLACE_PT" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATA_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(qua_ins_ind));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATA_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	}
	
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATA_req, "CTRL_KEY" , cJSON_CreateString(control_key));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATA_req, "CTRL_KEY" , cJSON_CreateString(control_key));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "CTRL_KEY" , cJSON_CreateString(control_key));
	}
	
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATA_req, "DOC_REQD" , cJSON_CreateString(doc_req));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATA_req, "DOC_REQD" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "DOC_REQD" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QUOTAUSAGE" , cJSON_CreateString(quota_arrangement_usage));
	cJSON_AddItemToObject(PLANTDATA_req, "SERV_LEVEL" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(PLANTDATA_req, "SPLIT_IND" , cJSON_CreateString(costing_split_valuation));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAILCHECK" , cJSON_CreateString(avail_chk));
	cJSON_AddItemToObject(PLANTDATA_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUP_TIME" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY_PLAN" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "SHIP_PROC_TIME" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROFIT_CTR" , cJSON_CreateString(profit_centre_sap));
	cJSON_AddItemToObject(PLANTDATA_req, "PPC_PL_CAL" , cJSON_CreateString(plan_calendar));
	if(tc_strlen(rep_mfg)>0)		//rep_mfg modified on 14.02.2017 for TE02
	{
		cJSON_AddItemToObject(PLANTDATA_req, "REP_MANUF" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "REP_MANUF" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "PL_TI_FNCE" , cJSON_CreateString("000"));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BWD_CONS" , cJSON_CreateString("000"));
	cJSON_AddItemToObject(PLANTDATA_req, "FWD_CONS" , cJSON_CreateString("000"));
	cJSON_AddItemToObject(PLANTDATA_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_SIZE" , cJSON_CreateString(cost_lot_size));
	cJSON_AddItemToObject(PLANTDATA_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	if(tc_strlen(store_locDup)>0)
	{
					//string strtoupper ( string store_locDup );
					//store_locDup1 = strtoupper(store_locDup);

		printf ("Before conversion: %s\n", store_locDup);
		for (p = store_locDup; *p != '\0'; ++p)
		{
			*p = toupper(*p);
		}
		printf ("After conversion: %s\n", store_locDup);
		cJSON_AddItemToObject(PLANTDATA_req, "ISS_ST_LOC" , cJSON_CreateString(store_locDup));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "ISS_ST_LOC" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_GROUP" , cJSON_CreateString(mrp_grp));
	cJSON_AddItemToObject(PLANTDATA_req, "COMP_SCRAP" , cJSON_CreateString(myzeroDup2));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATA_req, "CERT_TYPE" , cJSON_CreateString(certificate_type));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATA_req, "CERT_TYPE" , cJSON_CreateString(certificate_type));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "CERT_TYPE" , cJSON_CreateString(""));
	}
			
	cJSON_AddItemToObject(PLANTDATA_req, "CYCLE_TIME" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(PLANTDATA_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "VARIANCE_KEY" , cJSON_CreateString(variance_key));
	cJSON_AddItemToObject(PLANTDATA_req, "SERNO_PROF" , cJSON_CreateString(""));
	if(tc_strlen(rep_mfg)>0)		//rep_mfg modified on 14.02.2017 for TE02
	{
		cJSON_AddItemToObject(PLANTDATA_req, "REPMANPROF" , cJSON_CreateString(rep_mfg));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "REPMANPROF" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MULT_REF_M" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INSP_INT" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(PLANTDATA_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLAN_STRGP" , cJSON_CreateString(""));
	if(tc_strlen(store_locDup)>0)
	{
					//string strtoupper ( string store_locDup );
					//store_locDup1 = strtoupper(store_locDup);

		printf ("Before conversion: %s\n", store_locDup);
		for (p = store_locDup; *p != '\0'; ++p)
		{
			*p = toupper(*p);
		}
		printf ("After conversion: %s\n", store_locDup);
		
		cJSON_AddItemToObject(PLANTDATA_req, "SLOC_EXPRC" , cJSON_CreateString(store_locDup));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "SLOC_EXPRC" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "BULK_MAT" , cJSON_CreateString(blk_ind));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DETERM_GRP" , cJSON_CreateString(stock_det_group));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETYTIME" , cJSON_CreateString("00"));
	cJSON_AddItemToObject(PLANTDATA_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEPLOY_HORIZ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_LOT_SIZE" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_LOT_SIZE" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "FIX_LOT_SIZE" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_INCREMENT" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_SAFETY_STK" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATAX", PLANTDATAX_req);
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ABC_ID" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRPPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_TYPE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_CTRLER" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLND_DELRY" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_IND" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "ASSY_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOTSIZEKEY" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TYPE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPPROCTYPE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "REORDER_PT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MINLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAXLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIXED_LOT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_VAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_STOCK" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORD_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEP_REQ_ID" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALT_BOM_ID" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "GRP_REQMTS" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIXED_MRP" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SM_KEY" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUPTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INTEROP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INHSEPRODT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGEPERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNDER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLENTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLACE_PT" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	}
	
	
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_KEY" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_KEY" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_KEY" , cJSON_CreateString(""));
	}
					
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "DOC_REQD" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "DOC_REQD" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "DOC_REQD" , cJSON_CreateString(""));
	}
	
	cJSON_AddItemToObject(PLANTDATAX_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QUOTAUSAGE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERV_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPLIT_IND" , cJSON_CreateString(""));/*Please make it as X*/
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAILCHECK" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUP_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY_PLAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SHIP_PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROFIT_CTR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "PPC_PL_CAL" , cJSON_CreateString("X"));
	if(tc_strlen(rep_mfg)>0)		//rep_mfg modified on 14.02.2017 for TE02
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "REP_MANUF" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "REP_MANUF" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "PL_TI_FNCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_SIZE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	if(tc_strlen(store_locDup)>0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "ISS_ST_LOC" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "ISS_ST_LOC" , cJSON_CreateString(""));
		printf("\nstore location is null"); 
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_GROUP" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMP_SCRAP" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "CERT_TYPE" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "CERT_TYPE" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "CERT_TYPE" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "CYCLE_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "VARIANCE_KEY" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERNO_PROF" , cJSON_CreateString(""));
	if(tc_strlen(rep_mfg)>0)		//rep_mfg modified on 14.02.2017 for TE02
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "REPMANPROF" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "REPMANPROF" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MULT_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INSP_INT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLAN_STRGP" , cJSON_CreateString(""));
	if(tc_strlen(store_locDup)>0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "SLOC_EXPRC" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "SLOC_EXPRC" , cJSON_CreateString(""));
		printf("\nstore location is null"); 
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "BULK_MAT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DETERM_GRP" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETYTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEPLOY_HORIZ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_INCREMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "PRTDATA", PRTDATA_req);
	cJSON_AddItemToObject(PRTDATA_req, "item", item6_req);
	cJSON_AddItemToObject(item6_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(item6_req, "CREATE_LOAD_RECS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "CTRL_KEY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "GRP_KEY_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "GRP_KEY_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "PRT_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "STD_TEXT_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "REF_KEY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_REF_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "ST_REF_DATE_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_OFFSET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_OFFSET_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_OFFSET_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_OFFSET_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_REF_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_REF_DATE_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_OFFSET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_OFFSET_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_OFFSET_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_OFFSET_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "FORMULA_TOT_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "FORMULA_TOT_QTY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "FORMULA_TOT_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "FORMULA_TOT_USAGE_NO_CHG" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PRTDATAX", PRTDATAX_req);
	cJSON_AddItemToObject(PRTDATAX_req, "item", item7_req);
	cJSON_AddItemToObject(item7_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(item7_req, "CREATE_LOAD_RECS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "CTRL_KEY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "GRP_KEY_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "GRP_KEY_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "PRT_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "STD_TEXT_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "REF_KEY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_REF_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "ST_REF_DATE_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_OFFSET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_OFFSET_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_OFFSET_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_OFFSET_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_REF_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_REF_DATE_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_OFFSET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_OFFSET_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_OFFSET_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_OFFSET_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "FORMULA_TOT_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "FORMULA_TOT_QTY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "FORMULA_TOT_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "FORMULA_TOT_USAGE_NO_CHG" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "RETURNMESSAGES", RETURNMESSAGES_req);
	cJSON_AddItemToObject(RETURNMESSAGES_req, "item", item8_req);
	cJSON_AddItemToObject(item8_req, "TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "NUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_MSG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "PARAMETER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ROW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "FIELD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "SYSTEM" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "SALESDATA", SALESDATA_req);
	cJSON_AddItemToObject(SALESDATA_req, "SALES_ORG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DISTR_CHAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_STATS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "REBATE_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "COMM_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "CASH_DISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MIN_ORDER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MIN_DELY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MIN_MTO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DELY_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DELY_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DELY_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "SALES_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "SALES_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DELYG_PLNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PR_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MAT_PR_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "ACCT_ASSGT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_6" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_7" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_8" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_9" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT10" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "VAR_SALES_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PR_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PR_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PR_REF_MAT_VERSION" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "SALESDATAX", SALESDATAX_req);
	cJSON_AddItemToObject(SALESDATAX_req, "SALES_ORG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DISTR_CHAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_STATS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "REBATE_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "COMM_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "CASH_DISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MIN_ORDER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MIN_DELY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MIN_MTO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DELY_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DELY_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DELY_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "SALES_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "SALES_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DELYG_PLNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PR_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MAT_PR_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "ACCT_ASSGT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_6" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_7" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_8" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_9" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT10" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "VAR_SALES_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PR_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PR_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PR_REF_MAT_VERSION" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATA" , STORAGELOCATIONDATA_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_LOC" , cJSON_CreateString("9005"));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "INV_CORR_FAC" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATAX" , STORAGELOCATIONDATAX_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_LOC" , cJSON_CreateString("9005"));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "INV_CORR_FAC" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGETYPEDATA" , STORAGETYPEDATA_req);
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "WHSE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "STGE_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "MAX_SB_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "MIN_SB_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "CTRL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "REPLEN_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "PICK_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "ROUND_QTY" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGETYPEDATAX" , STORAGETYPEDATAX_req);
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "WHSE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "STGE_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "MAX_SB_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "MIN_SB_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "CTRL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "REPLEN_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "PICK_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "ROUND_QTY" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "TAXCLASSIFICATIONS" , TAXCLASSIFICATIONS_req);
	cJSON_AddItemToObject(TAXCLASSIFICATIONS_req, "item" , item9_req);
	cJSON_AddItemToObject(item9_req, "DEPCOUNTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "DEPCOUNTRY_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_6" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_6" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_7" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_7" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_8" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_8" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_9" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_9" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_IND" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASURE" , UNITSOFMEASURE_req);
	cJSON_AddItemToObject(UNITSOFMEASURE_req, "item" , item10_req);
	cJSON_AddItemToObject(item10_req, "ALT_UNIT" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(item10_req, "ALT_UNIT_ISO" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(item10_req, "NUMERATOR" , cJSON_CreateString("1"));
	cJSON_AddItemToObject(item10_req, "DENOMINATR" , cJSON_CreateString("1"));
	cJSON_AddItemToObject(item10_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUME" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT" , cJSON_CreateString(vol_unit));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT_ISO" , cJSON_CreateString(vol_unit));
	cJSON_AddItemToObject(item10_req, "GROSS_WT" , cJSON_CreateString(gross_wt));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT" , cJSON_CreateString(unit_wt));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(unit_wt));
	cJSON_AddItemToObject(item10_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString(""));

	
	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASUREX" , UNITSOFMEASUREX_req);
	cJSON_AddItemToObject(UNITSOFMEASUREX_req, "item" , item11_req);
	cJSON_AddItemToObject(item11_req, "ALT_UNIT" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(item11_req, "ALT_UNIT_ISO" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(item11_req, "NUMERATOR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "DENOMINATR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "GROSS_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATA" , VALUATIONDATA_req);
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_AREA" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_CTRL" , cJSON_CreateString(price_con));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOVING_PR" , cJSON_CreateString(moving_avg_price));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PRICE" , cJSON_CreateString(std_price));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CLASS" , cJSON_CreateString(val_class));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PP" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PP" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PY" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PY" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CAT" , cJSON_CreateString(valuation_cat));
	cJSON_AddItemToObject(VALUATIONDATA_req, "FUTURE_PR" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_1" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE1" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_3" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE3" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLND_PRICE" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE1" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE2" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE3" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_2" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE2" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEVAL_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_GROUP" , cJSON_CreateString(origin_group));
	cJSON_AddItemToObject(VALUATIONDATA_req, "OVERHEAD_GRP" , cJSON_CreateString(overhd_grp));
	cJSON_AddItemToObject(VALUATIONDATA_req, "QTY_STRUCT" , cJSON_CreateString(with_quantity_structure));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_MAT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MAT_ORIGIN" , cJSON_CreateString(mat_origin));
	cJSON_AddItemToObject(VALUATIONDATA_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAX_CML_UN" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATAX" , VALUATIONDATAX_req);
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_AREA" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_CTRL" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOVING_PR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PRICE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CLASS" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CAT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "FUTURE_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLND_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEVAL_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_GROUP" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "OVERHEAD_GRP" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "QTY_STRUCT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_MAT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MAT_ORIGIN" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAX_CML_UN" , cJSON_CreateString("0"));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "WAREHOUSENUMBERDATA" , WAREHOUSENUMBERDATA_req);
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "WHSE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "STGESECTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "PLACEMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "WITHDRAWAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "L_EQUIP_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "L_EQUIP_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "L_EQUIP_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_1_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_2_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_3_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "UNITTYPE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "UNITTYPE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "UNITTYPE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "WM_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "WM_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "ADD_TO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "BLOCK_STGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "MSG_TO_IM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "SPEC_MVMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "CAPY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "PROCURE_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "PROCURE_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "STGE_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "REF_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "STEP_PICK" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "WAREHOUSENUMBERDATAX" , WAREHOUSENUMBERDATAX_req);
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "WHSE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "STGESECTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "PLACEMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "WITHDRAWAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "L_EQUIP_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "L_EQUIP_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "L_EQUIP_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_1_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_2_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_3_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "UNITTYPE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "UNITTYPE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "UNITTYPE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "WM_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "WM_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "ADD_TO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "BLOCK_STGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "MSG_TO_IM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "SPEC_MVMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "CAPY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "PROCURE_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "PROCURE_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "STGE_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "REF_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "STEP_PICK" , cJSON_CreateString(""));
	    
		
	out = cJSON_Print(rfc_root);
	printf("%s\n", out);//json_extend_mat_in_plant_req_obj
	tc_strcpy(json_extend_mat_in_plant_req_obj,out);
	free(out);
	cJSON_Delete(rfc_root);

	return 0;
}
int extend_mat_in_plant()
{
	char *json_extend_mat_in_plant_req_obj = NULL;
	json_extend_mat_in_plant_req_obj = malloc(234000);
	
	call_BAPI_extend_mat_in_plant(json_extend_mat_in_plant_req_obj);
	printf("\nRetuned Str : %s\n", json_extend_mat_in_plant_req_obj);
	tm_curl_BAPI_extend_mat_in_plant ( json_extend_mat_in_plant_req_obj );
	//tm_curl_ZBAPI_MATERIAL_SAVEDATA ( json_extend_mat_in_plant_req_obj );
	free(json_extend_mat_in_plant_req_obj);
	
	return 0;
}

int tm_curl_BAPI_mat_change_all_view ( char *data )
{
	struct memory chunk = {0};
	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV"); //DEV
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV_QA");
	
	if ( tc_strcmp ( iSapServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n iSapServer is Blank..!!");fflush(stdout);
	}
	
	curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	
	list = curl_slist_append(list, "Content-Type: application/json");
    
	printf("\nFile request content as below "); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
	printf("\ncurl_easy_setopt"); fflush(stdout);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	printf("\ncurl_easy_perform");fflush(stdout);
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "BOM_DELETE");
	
	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
	printf("\nfree"); fflush(stdout);
	
	curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}

int call_BAPI_mat_change_all_view(char *json_mat_change_all_view_req_obj)
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *CLIENTDATA_req;
	cJSON *CLIENTDATAX_req;
	cJSON *EXTENSIONIN_req;
	cJSON *EXTENSIONINX_req;
	cJSON *item1_req;
	cJSON *item2_req;
	
	
	cJSON *FORECASTPARAMETERS_req;
	cJSON *FORECASTPARAMETERSX_req;
	
	cJSON *HEADDATA_req;
	
	cJSON *INTERNATIONALARTNOS_req;
	cJSON *item3_req;
	
	cJSON *MATERIALDESCRIPTION_req;
	cJSON *item4_req;
	
	
	cJSON *MATERIALLONGTEXT_req;
	cJSON *item5_req;
	
	cJSON *PLANNINGDATA_req;
	cJSON *PLANNINGDATAX_req;
	
	cJSON *PLANTDATA_req;
	cJSON *PLANTDATAX_req;
	
	cJSON *PRTDATA_req;
	cJSON *item6_req;

	cJSON *PRTDATAX_req;
	cJSON *item7_req;
	
	cJSON *RETURNMESSAGES_req;
	cJSON *item8_req;

	cJSON *SALESDATA_req;
	cJSON *SALESDATAX_req;

	cJSON *STORAGELOCATIONDATA_req;
	cJSON *STORAGELOCATIONDATAX_req;

	cJSON *STORAGETYPEDATA_req;
	cJSON *STORAGETYPEDATAX_req;

	cJSON *TAXCLASSIFICATIONS_req;
	cJSON *item9_req;
	
	cJSON *UNITSOFMEASURE_req;
	cJSON *item10_req;
	
	cJSON *UNITSOFMEASUREX_req;
	cJSON *item11_req;

	cJSON *VALUATIONDATA_req;
	cJSON *VALUATIONDATAX_req;

	cJSON *WAREHOUSENUMBERDATA_req;
	cJSON *WAREHOUSENUMBERDATAX_req;
		
	
	
	char *out;
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	CLIENTDATA_req = cJSON_CreateObject();
	CLIENTDATAX_req = cJSON_CreateObject();
	
	EXTENSIONIN_req = cJSON_CreateObject();
	EXTENSIONINX_req = cJSON_CreateObject();
	item1_req = cJSON_CreateObject();
	item2_req = cJSON_CreateObject();
	
	HEADDATA_req = cJSON_CreateObject();
	
	FORECASTPARAMETERS_req = cJSON_CreateObject();
	FORECASTPARAMETERSX_req = cJSON_CreateObject();
	
	INTERNATIONALARTNOS_req = cJSON_CreateObject();
	item3_req = cJSON_CreateObject();
	
	MATERIALDESCRIPTION_req = cJSON_CreateObject();
	item4_req = cJSON_CreateObject();
	
	MATERIALLONGTEXT_req = cJSON_CreateObject();
	item5_req = cJSON_CreateObject();
	
	PLANNINGDATA_req = cJSON_CreateObject();
	PLANNINGDATAX_req = cJSON_CreateObject();
	
	PLANTDATA_req = cJSON_CreateObject();
	PLANTDATAX_req = cJSON_CreateObject();
	
	PRTDATA_req = cJSON_CreateObject();
	item6_req = cJSON_CreateObject();
	
	PRTDATAX_req = cJSON_CreateObject();
	item7_req = cJSON_CreateObject();
	
	RETURNMESSAGES_req = cJSON_CreateObject();
	item8_req = cJSON_CreateObject();
	
	
	SALESDATA_req = cJSON_CreateObject();
	SALESDATAX_req = cJSON_CreateObject();
	
	STORAGELOCATIONDATA_req = cJSON_CreateObject();
	STORAGELOCATIONDATAX_req = cJSON_CreateObject();
	
	STORAGETYPEDATA_req = cJSON_CreateObject();
	STORAGETYPEDATAX_req = cJSON_CreateObject();
	
	TAXCLASSIFICATIONS_req = cJSON_CreateObject();
	item9_req = cJSON_CreateObject();
	
	UNITSOFMEASURE_req = cJSON_CreateObject();
	item10_req = cJSON_CreateObject();
	
	UNITSOFMEASUREX_req = cJSON_CreateObject();
	item11_req = cJSON_CreateObject();
	
	VALUATIONDATA_req = cJSON_CreateObject();
	VALUATIONDATAX_req = cJSON_CreateObject();
	
	WAREHOUSENUMBERDATA_req = cJSON_CreateObject();
	WAREHOUSENUMBERDATAX_req = cJSON_CreateObject();
	
	
	cJSON_AddItemToObject(rfc_root, "ZBAPI_MATERIAL_SAVEDATA", exp_imp_tab_req);
	cJSON_AddItemToObject(exp_imp_tab_req, "CHANGE_NUMBER", cJSON_CreateString(dml_no_arg));
		
	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATA", CLIENTDATA_req);
	cJSON_AddItemToObject(CLIENTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATL_GROUP" , cJSON_CreateString(material_group));
	cJSON_AddItemToObject(CLIENTDATA_req, "OLD_MAT_NO" , cJSON_CreateString(OldMatNoDup));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM_ISO" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
	if(tc_strlen(doc_noDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "DOCUMENT" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "DOCUMENT" , cJSON_CreateString(doc_noDup));
	}
	
	if(tc_strlen(dwg_typeDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "DOC_TYPE" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "DOC_TYPE" , cJSON_CreateString(dwg_typeDup));
	}
	if(tc_strlen(dwg_revDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "DOC_VERS" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "DOC_VERS" , cJSON_CreateString(dwg_revDup));
	}
	
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_FORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGE_NO" , cJSON_CreateString(""));
	if(tc_strlen(sheet_noDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "NO_SHEETS" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "NO_SHEETS" , cJSON_CreateString(sheet_noDup));
	}
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGEFORMAT" , cJSON_CreateString(""));
	if(tc_strlen(sizeDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "SIZE_DIM" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "SIZE_DIM" , cJSON_CreateString(sizeDup));
	}
	cJSON_AddItemToObject(CLIENTDATA_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NET_WEIGHT" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT" , cJSON_CreateString(unit_wt));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(unit_wt));
	cJSON_AddItemToObject(CLIENTDATA_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DIVISION" , cJSON_CreateString(basic_division));
	cJSON_AddItemToObject(CLIENTDATA_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QTY_GR_GI" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CAD_ID" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLOWED_WT" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLWD_VOL" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WT_TOL_LT" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(CLIENTDATA_req, "VOL_TOL_LT" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(CLIENTDATA_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "FILL_LEVEL" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "STACK_FACT" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "QM_PROCMNT" , cJSON_CreateString(qm_proc_ind));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "QM_PROCMNT" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "QM_PROCMNT" , cJSON_CreateString(""));		
	}
	
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "CATPROFILE" , cJSON_CreateString(""));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "CATPROFILE" , cJSON_CreateString(catalog_prof));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "CATPROFILE" , cJSON_CreateString(""));		
	}
	cJSON_AddItemToObject(CLIENTDATA_req, "MINREMLIFE" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "SHELF_LIFE" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_PCT" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_STATUS" , cJSON_CreateString(""));
	/* if(tc_strlen(mm_pp_status)==0)
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "PUR_STATUS" , cJSON_CreateString(" "));
		printf("\nMaterial  status is........ABC : %s",mm_pp_status);
		fprintf(fsuccess,"\nMaterial  status is........ABC : %s",mm_pp_status);
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "PUR_STATUS" , cJSON_CreateString(mm_pp_status));
		printf("\nMaterial  status is........ABC1 : %s",mm_pp_status);
		fprintf(fsuccess,"\nMaterial  status is........ABC1 : %s",mm_pp_status);
	} */
	cJSON_AddItemToObject(CLIENTDATA_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATCMPLLVL" , cJSON_CreateString("00"));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString("D"));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ANP" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATAX", CLIENTDATAX_req);
	cJSON_AddItemToObject(CLIENTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATL_GROUP" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "OLD_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM_ISO" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
	if(tc_strlen(doc_noDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOCUMENT" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOCUMENT" , cJSON_CreateString("X"));
	}
	
	if(tc_strlen(dwg_typeDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_TYPE" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_TYPE" , cJSON_CreateString("X"));
	}
	if(tc_strlen(dwg_revDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_VERS" , cJSON_CreateString(""));
	}
	else
	{
				cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_VERS" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_FORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGE_NO" , cJSON_CreateString(""));
	if(tc_strlen(sheet_noDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "NO_SHEETS" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "NO_SHEETS" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGEFORMAT" , cJSON_CreateString(""));
	if(tc_strlen(sizeDup)==0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "SIZE_DIM" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "SIZE_DIM" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NET_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DIVISION" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QTY_GR_GI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CAD_ID" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLOWED_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLWD_VOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WT_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VOL_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "FILL_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STACK_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "QM_PROCMNT" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "QM_PROCMNT" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "QM_PROCMNT" , cJSON_CreateString(""));		
	}
	
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "CATPROFILE" , cJSON_CreateString(""));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "CATPROFILE" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "CATPROFILE" , cJSON_CreateString(""));		
	}
	
	cJSON_AddItemToObject(CLIENTDATAX_req, "MINREMLIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SHELF_LIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_PCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	/* if(tc_strlen(mm_pp_status)==0)
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_STATUS" , cJSON_CreateString("X"));
	} */
	cJSON_AddItemToObject(CLIENTDATAX_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATCMPLLVL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ANP" , cJSON_CreateString(""));
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_CAD_CALL", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_ONLINE", cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "EXTENSIONIN", EXTENSIONIN_req);
	cJSON_AddItemToObject(EXTENSIONIN_req, "item" , item1_req);
	cJSON_AddItemToObject(item1_req, "STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART4" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "EXTENSIONINX", EXTENSIONINX_req);
	cJSON_AddItemToObject(EXTENSIONINX_req, "item" , item2_req);
	cJSON_AddItemToObject(item2_req, "STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART4" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "HEADDATA", HEADDATA_req);
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL" , cJSON_CreateString(part_noDup));
	cJSON_AddItemToObject(HEADDATA_req, "IND_SECTOR" , cJSON_CreateString("M"));
	cJSON_AddItemToObject(HEADDATA_req, "MATL_TYPE" , cJSON_CreateString(mat_type));
	cJSON_AddItemToObject(HEADDATA_req, "BASIC_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "SALES_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PURCHASE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MRP_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "FORECAST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "WORK_SCHED_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PRT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "STORAGE_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "WAREHOUSE_VIEW" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		printf("\npart is not a VC"); fflush(stdout);
		cJSON_AddItemToObject(HEADDATA_req, "QUALITY_VIEW" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		printf("\nQM View For VC");fflush(stdout);
		printf("\n[%s,%s,%s,%s,%s]",qua_ins_ind,doc_req,grptime,catalog_prof,qm_proc_ind);fflush(stdout);
		cJSON_AddItemToObject(HEADDATA_req, "QUALITY_VIEW" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(HEADDATA_req, "QUALITY_VIEW" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(HEADDATA_req, "ACCOUNT_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "COST_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "INP_FLD_CHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_VERSION" , cJSON_CreateString(""));
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "FORECASTPARAMETERS", FORECASTPARAMETERS_req);
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FORE_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "MODEL_SI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "MODEL_SP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "PARAM_OPT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "OPTIM_LEV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "INITIALIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FORE_MODEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "ALPHA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "BETA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "GAMMA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "DELTA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "TRACKLIMIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FORE_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "HIST_VALS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "INIT_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "SEASON_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "EXPOST_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FORE_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "FIXED_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERS_req, "WTG_GROUP" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "FORECASTPARAMETERSX", FORECASTPARAMETERSX_req);
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FORE_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "MODEL_SI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "MODEL_SP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "PARAM_OPT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "OPTIM_LEV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "INITIALIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FORE_MODEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "ALPHA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "BETA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "GAMMA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "DELTA_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "TRACKLIMIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FORE_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "HIST_VALS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "INIT_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "SEASON_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "EXPOST_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FORE_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "FIXED_PDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(FORECASTPARAMETERSX_req, "WTG_GROUP" , cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "INTERNATIONALARTNOS", INTERNATIONALARTNOS_req);
	cJSON_AddItemToObject(INTERNATIONALARTNOS_req, "item" , item3_req);
	cJSON_AddItemToObject(item3_req, "UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item3_req, "UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item3_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item3_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item3_req, "DEL_FLAG" , cJSON_CreateString(""));
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALDESCRIPTION", MATERIALDESCRIPTION_req);
	cJSON_AddItemToObject(MATERIALDESCRIPTION_req, "item" , item4_req);
	cJSON_AddItemToObject(item4_req, "LANGU" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "LANGU_ISO" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "MATL_DESC" , cJSON_CreateString(descDup));
	cJSON_AddItemToObject(item4_req, "DEL_FLAG" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALLONGTEXT", MATERIALLONGTEXT_req);
	cJSON_AddItemToObject(MATERIALLONGTEXT_req, "item" , item5_req);
	cJSON_AddItemToObject(item5_req, "APPLOBJECT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "TEXT_NAME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "TEXT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "LANGU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "LANGU_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "FORMAT_COL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "TEXT_LINE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item5_req, "DEL_FLAG" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANNINGDATA", PLANNINGDATA_req);
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL" , cJSON_CreateString(splan_mat));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_PLANT" , cJSON_CreateString(splan_plant));
	cJSON_AddItemToObject(PLANNINGDATA_req, "CONVFACTOR" , cJSON_CreateString(splan_conv_fact));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_VERSION" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANNINGDATAX", PLANNINGDATAX_req);
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_PLANT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "CONVFACTOR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_VERSION" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATA", PLANTDATA_req);
	cJSON_AddItemToObject(PLANTDATA_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(PLANTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ABC_ID" , cJSON_CreateString(abc_ind));
	cJSON_AddItemToObject(PLANTDATA_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT" , cJSON_CreateString(uoissue));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(uoissue));
	cJSON_AddItemToObject(PLANTDATA_req, "MRPPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_TYPE" , cJSON_CreateString(mrp_type));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_CTRLER" , cJSON_CreateString(mrp_controller));
	cJSON_AddItemToObject(PLANTDATA_req, "PLND_DELRY" , cJSON_CreateString("0"));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(grptime));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(grptime));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(""));		
	}
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_IND" , cJSON_CreateString(period_ind));
	cJSON_AddItemToObject(PLANTDATA_req, "ASSY_SCRAP" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "LOTSIZEKEY" , cJSON_CreateString(lot_size_key));
	if(*part_noDup=='G')
	{
		printf("\nGrp Part...... \n");fflush(stdout);
	    cJSON_AddItemToObject(PLANTDATA_req, "PROC_TYPE" , cJSON_CreateString(proc_type));
		cJSON_AddItemToObject(PLANTDATA_req, "SPPROCTYPE" , cJSON_CreateString(spl_proc_key));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "PROC_TYPE" , cJSON_CreateString(proc_type));
		cJSON_AddItemToObject(PLANTDATA_req, "SPPROCTYPE" , cJSON_CreateString(spl_proc_key));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "REORDER_PT" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETY_STK" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "MINLOTSIZE" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "MAXLOTSIZE" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "FIXED_LOT" , cJSON_CreateString(fixed_lot_size));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_VAL" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_STOCK" , cJSON_CreateString(max_stlvl));
	cJSON_AddItemToObject(PLANTDATA_req, "ORD_COSTS" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(PLANTDATA_req, "DEP_REQ_ID" , cJSON_CreateString(ind_collect));
	cJSON_AddItemToObject(PLANTDATA_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ALT_BOM_ID" , cJSON_CreateString(alternativb));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "GRP_REQMTS" , cJSON_CreateString(req_grp));
	cJSON_AddItemToObject(PLANTDATA_req, "MIXED_MRP" , cJSON_CreateString(mixedmrp));
	if (tc_strcmp(mat_type,"FERT")==0)
	{
		cJSON_AddItemToObject(PLANTDATA_req, "SM_KEY" , cJSON_CreateString("000"));  //schedk
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "SM_KEY" , cJSON_CreateString("000"));  //schedk
	}
	cJSON_AddItemToObject(PLANTDATA_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TIME" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUPTIME" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "INTEROP" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "INHSEPRODT" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(PLANTDATA_req, "STGEPERIOD" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVER_TOL" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(PLANTDATA_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNDER_TOL" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLENTIME" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLACE_PT" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATA_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(qua_ins_ind));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATA_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	}
	
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATA_req, "CTRL_KEY" , cJSON_CreateString(control_key));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATA_req, "CTRL_KEY" , cJSON_CreateString(control_key));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "CTRL_KEY" , cJSON_CreateString(""));
	}
	
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATA_req, "DOC_REQD" , cJSON_CreateString(doc_req));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATA_req, "DOC_REQD" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "DOC_REQD" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QUOTAUSAGE" , cJSON_CreateString(quota_arrangement_usage));
	cJSON_AddItemToObject(PLANTDATA_req, "SERV_LEVEL" , cJSON_CreateString(myzeroDup1));
	cJSON_AddItemToObject(PLANTDATA_req, "SPLIT_IND" , cJSON_CreateString(costing_split_valuation));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAILCHECK" , cJSON_CreateString(avail_chk));
	cJSON_AddItemToObject(PLANTDATA_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUP_TIME" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY_PLAN" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "SHIP_PROC_TIME" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROFIT_CTR" , cJSON_CreateString(profit_centre_sap));
	cJSON_AddItemToObject(PLANTDATA_req, "PPC_PL_CAL" , cJSON_CreateString(plan_calendar));

	if(tc_strlen(rep_mfg)>0)		//rep_mfg modified on 14.02.2017 for TE02
	{
		cJSON_AddItemToObject(PLANTDATA_req, "REP_MANUF" , cJSON_CreateString("X"));
		cJSON_AddItemToObject(PLANTDATA_req, "REPMANPROF" , cJSON_CreateString(rep_mfg));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "REP_MANUF" , cJSON_CreateString(""));
		cJSON_AddItemToObject(PLANTDATA_req, "REPMANPROF" , cJSON_CreateString(""));
	}
	
	cJSON_AddItemToObject(PLANTDATA_req, "PL_TI_FNCE" , cJSON_CreateString("000"));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BWD_CONS" , cJSON_CreateString("000"));
	cJSON_AddItemToObject(PLANTDATA_req, "FWD_CONS" , cJSON_CreateString("000"));
	cJSON_AddItemToObject(PLANTDATA_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_SIZE" , cJSON_CreateString(cost_lot_size));
	cJSON_AddItemToObject(PLANTDATA_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	if(tc_strlen(store_locDup)>0)
	{
					//string strtoupper ( string store_locDup );
					//store_locDup1 = strtoupper(store_locDup);

		printf ("Before conversion: %s\n", store_locDup);
		for (p = store_locDup; *p != '\0'; ++p)
		{
			*p = toupper(*p);
		}
		printf ("After conversion: %s\n", store_locDup);
		cJSON_AddItemToObject(PLANTDATA_req, "ISS_ST_LOC" , cJSON_CreateString(store_locDup));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "ISS_ST_LOC" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_GROUP" , cJSON_CreateString(mrp_grp));
	cJSON_AddItemToObject(PLANTDATA_req, "COMP_SCRAP" , cJSON_CreateString(myzeroDup2));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATA_req, "CERT_TYPE" , cJSON_CreateString(certificate_type));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATA_req, "CERT_TYPE" , cJSON_CreateString(certificate_type));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "CERT_TYPE" , cJSON_CreateString(""));
	}
			
	cJSON_AddItemToObject(PLANTDATA_req, "CYCLE_TIME" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(PLANTDATA_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "VARIANCE_KEY" , cJSON_CreateString(variance_key));
	cJSON_AddItemToObject(PLANTDATA_req, "SERNO_PROF" , cJSON_CreateString(""));
	/* if(tc_strlen(rep_mfg)>0)		//rep_mfg modified on 14.02.2017 for TE02
	{
		cJSON_AddItemToObject(PLANTDATA_req, "REPMANPROF" , cJSON_CreateString(rep_mfg));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "REPMANPROF" , cJSON_CreateString(""));
	} */
	cJSON_AddItemToObject(PLANTDATA_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MULT_REF_M" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INSP_INT" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(PLANTDATA_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLAN_STRGP" , cJSON_CreateString(""));
	if(tc_strlen(store_locDup)>0)
	{
					//string strtoupper ( string store_locDup );
					//store_locDup1 = strtoupper(store_locDup);

		printf ("Before conversion: %s\n", store_locDup);
		for (p = store_locDup; *p != '\0'; ++p)
		{
			*p = toupper(*p);
		}
		printf ("After conversion: %s\n", store_locDup);
		
		cJSON_AddItemToObject(PLANTDATA_req, "SLOC_EXPRC" , cJSON_CreateString(store_locDup));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "SLOC_EXPRC" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATA_req, "BULK_MAT" , cJSON_CreateString(blk_ind));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DETERM_GRP" , cJSON_CreateString(stock_det_group));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
	if(tc_strlen(mm_pp_status)==0)
	{
		cJSON_AddItemToObject(PLANTDATA_req, "PUR_STATUS" , cJSON_CreateString(" "));
		printf("\nMaterial  status is........ABC : %s",mm_pp_status);
		fprintf(fsuccess,"\nMaterial  status is........ABC : %s",mm_pp_status);
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "PUR_STATUS" , cJSON_CreateString(mm_pp_status));
		printf("\nMaterial  status is........ABC1 : %s",mm_pp_status);
		fprintf(fsuccess,"\nMaterial  status is........ABC1 : %s",mm_pp_status);
	}
	cJSON_AddItemToObject(PLANTDATA_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETYTIME" , cJSON_CreateString("00"));
	cJSON_AddItemToObject(PLANTDATA_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEPLOY_HORIZ" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_LOT_SIZE" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_LOT_SIZE" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "FIX_LOT_SIZE" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_INCREMENT" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_SAFETY_STK" , cJSON_CreateString(myzeroDup2));
	cJSON_AddItemToObject(PLANTDATA_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATAX", PLANTDATAX_req);
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ABC_ID" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRPPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_TYPE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_CTRLER" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLND_DELRY" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_IND" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "ASSY_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOTSIZEKEY" , cJSON_CreateString("X"));
	if(*part_noDup=='G')
	{
		printf("\nGrp Part...... \n");fflush(stdout);
	    cJSON_AddItemToObject(PLANTDATA_req, "PROC_TYPE" , cJSON_CreateString(""));
		cJSON_AddItemToObject(PLANTDATA_req, "SPPROCTYPE" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATA_req, "PROC_TYPE" , cJSON_CreateString("X"));
		cJSON_AddItemToObject(PLANTDATA_req, "SPPROCTYPE" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TYPE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPPROCTYPE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "REORDER_PT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MINLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAXLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIXED_LOT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_VAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_STOCK" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORD_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEP_REQ_ID" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALT_BOM_ID" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "GRP_REQMTS" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIXED_MRP" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SM_KEY" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUPTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INTEROP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INHSEPRODT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGEPERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNDER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLENTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLACE_PT" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString("qua_ins_ind"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	}
	
	
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_KEY" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_KEY" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_KEY" , cJSON_CreateString(""));
	}
					
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "DOC_REQD" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "DOC_REQD" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "DOC_REQD" , cJSON_CreateString(""));
	}
	
	cJSON_AddItemToObject(PLANTDATAX_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QUOTAUSAGE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERV_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPLIT_IND" , cJSON_CreateString(""));/*Please make it as X*/
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAILCHECK" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUP_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY_PLAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SHIP_PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROFIT_CTR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "PPC_PL_CAL" , cJSON_CreateString("X"));
	if(tc_strlen(rep_mfg)>0)		//rep_mfg modified on 14.02.2017 for TE02
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "REP_MANUF" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "REP_MANUF" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "PL_TI_FNCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_SIZE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	if(tc_strlen(store_locDup)>0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "ISS_ST_LOC" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "ISS_ST_LOC" , cJSON_CreateString(""));
		printf("\nstore location is null"); 
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_GROUP" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMP_SCRAP" , cJSON_CreateString(""));
	if(tc_strcmp(mat_type,"FERT") != 0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "CERT_TYPE" , cJSON_CreateString("X"));
	}
	else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "CERT_TYPE" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "CERT_TYPE" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "CYCLE_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "VARIANCE_KEY" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERNO_PROF" , cJSON_CreateString(""));
	if(tc_strlen(rep_mfg)>0)		//rep_mfg modified on 14.02.2017 for TE02
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "REPMANPROF" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "REPMANPROF" , cJSON_CreateString("X"));
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MULT_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INSP_INT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLAN_STRGP" , cJSON_CreateString(""));
	if(tc_strlen(store_locDup)>0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "SLOC_EXPRC" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "SLOC_EXPRC" , cJSON_CreateString(""));
		printf("\nstore location is null"); 
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "BULK_MAT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DETERM_GRP" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
	if(tc_strlen(mm_pp_status)==0)
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "PUR_STATUS" , cJSON_CreateString("X"));
		printf("\nMaterial  status is........ABC : %s",mm_pp_status);
		fprintf(fsuccess,"\nMaterial  status is........ABC : %s",mm_pp_status);
	}
	else
	{
		cJSON_AddItemToObject(PLANTDATAX_req, "PUR_STATUS" , cJSON_CreateString("X"));
		printf("\nMaterial  status is........ABC1 : %s",mm_pp_status);
		fprintf(fsuccess,"\nMaterial  status is........ABC1 : %s",mm_pp_status);
	}
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETYTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEPLOY_HORIZ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_INCREMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "PRTDATA", PRTDATA_req);
	cJSON_AddItemToObject(PRTDATA_req, "item", item6_req);
	cJSON_AddItemToObject(item6_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(item6_req, "CREATE_LOAD_RECS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "CTRL_KEY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "GRP_KEY_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "GRP_KEY_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "PRT_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "STD_TEXT_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "REF_KEY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_REF_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "ST_REF_DATE_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_OFFSET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_OFFSET_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_OFFSET_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "START_OFFSET_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_REF_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_REF_DATE_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_OFFSET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_OFFSET_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_OFFSET_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "END_OFFSET_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "FORMULA_TOT_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "FORMULA_TOT_QTY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "FORMULA_TOT_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item6_req, "FORMULA_TOT_USAGE_NO_CHG" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PRTDATAX", PRTDATAX_req);
	cJSON_AddItemToObject(PRTDATAX_req, "item", item7_req);
	cJSON_AddItemToObject(item7_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(item7_req, "CREATE_LOAD_RECS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "CTRL_KEY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "GRP_KEY_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "GRP_KEY_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "PRT_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "STD_TEXT_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "REF_KEY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_REF_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "ST_REF_DATE_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_OFFSET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_OFFSET_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_OFFSET_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "START_OFFSET_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_REF_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_REF_DATE_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_OFFSET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_OFFSET_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_OFFSET_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "END_OFFSET_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "FORMULA_TOT_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "FORMULA_TOT_QTY_NO_CHG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "FORMULA_TOT_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item7_req, "FORMULA_TOT_USAGE_NO_CHG" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "RETURNMESSAGES", RETURNMESSAGES_req);
	cJSON_AddItemToObject(RETURNMESSAGES_req, "item", item8_req);
	cJSON_AddItemToObject(item8_req, "TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "NUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_MSG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "PARAMETER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ROW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "FIELD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "SYSTEM" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "SALESDATA", SALESDATA_req);
	cJSON_AddItemToObject(SALESDATA_req, "SALES_ORG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DISTR_CHAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_STATS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "REBATE_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "COMM_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "CASH_DISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MIN_ORDER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MIN_DELY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MIN_MTO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DELY_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DELY_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DELY_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "SALES_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "SALES_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "DELYG_PLNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PR_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MAT_PR_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "ACCT_ASSGT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "MATL_GRP_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_6" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_7" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_8" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT_9" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PROD_ATT10" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "VAR_SALES_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PR_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PR_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATA_req, "PR_REF_MAT_VERSION" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "SALESDATAX", SALESDATAX_req);
	cJSON_AddItemToObject(SALESDATAX_req, "SALES_ORG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DISTR_CHAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_STATS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "REBATE_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "COMM_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "CASH_DISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MIN_ORDER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MIN_DELY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MIN_MTO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DELY_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DELY_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DELY_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "SALES_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "SALES_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "ITEM_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "DELYG_PLNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PR_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MAT_PR_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "ACCT_ASSGT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "MATL_GRP_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_6" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_7" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_8" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT_9" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PROD_ATT10" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "VAR_SALES_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PR_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PR_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(SALESDATAX_req, "PR_REF_MAT_VERSION" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATA" , STORAGELOCATIONDATA_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_LOC" , cJSON_CreateString("9005"));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REORDER_PT" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REPL_QTY" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "INV_CORR_FAC" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATAX" , STORAGELOCATIONDATAX_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PLANT" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_LOC" , cJSON_CreateString("9005"));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "INV_CORR_FAC" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGETYPEDATA" , STORAGETYPEDATA_req);
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "WHSE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "STGE_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "MAX_SB_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "MIN_SB_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "CTRL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "REPLEN_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "PICK_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATA_req, "ROUND_QTY" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGETYPEDATAX" , STORAGETYPEDATAX_req);
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "WHSE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "STGE_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "MAX_SB_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "MIN_SB_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "CTRL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "REPLEN_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "PICK_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGETYPEDATAX_req, "ROUND_QTY" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "TAXCLASSIFICATIONS" , TAXCLASSIFICATIONS_req);
	cJSON_AddItemToObject(TAXCLASSIFICATIONS_req, "item" , item9_req);
	cJSON_AddItemToObject(item9_req, "DEPCOUNTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "DEPCOUNTRY_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_5" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_6" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_6" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_7" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_7" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_8" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_8" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_TYPE_9" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAXCLASS_9" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item9_req, "TAX_IND" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASURE" , UNITSOFMEASURE_req);
	cJSON_AddItemToObject(UNITSOFMEASURE_req, "item" , item10_req);
	cJSON_AddItemToObject(item10_req, "ALT_UNIT" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(item10_req, "ALT_UNIT_ISO" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(item10_req, "NUMERATOR" , cJSON_CreateString("1"));
	cJSON_AddItemToObject(item10_req, "DENOMINATR" , cJSON_CreateString("1"));
	cJSON_AddItemToObject(item10_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUME" , cJSON_CreateString(myzeroDup3));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT" , cJSON_CreateString(vol_unit));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT_ISO" , cJSON_CreateString(vol_unit));
	cJSON_AddItemToObject(item10_req, "GROSS_WT" , cJSON_CreateString(gross_wt));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT" , cJSON_CreateString(unit_wt));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(unit_wt));
	cJSON_AddItemToObject(item10_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString(""));

	
	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASUREX" , UNITSOFMEASUREX_req);
	cJSON_AddItemToObject(UNITSOFMEASUREX_req, "item" , item11_req);
	cJSON_AddItemToObject(item11_req, "ALT_UNIT" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(item11_req, "ALT_UNIT_ISO" , cJSON_CreateString(meas_unit));
	cJSON_AddItemToObject(item11_req, "NUMERATOR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "DENOMINATR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUME" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT_ISO" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "GROSS_WT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT_ISO" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATA" , VALUATIONDATA_req);
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_AREA" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_CTRL" , cJSON_CreateString(price_con));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOVING_PR" , cJSON_CreateString(moving_avg_price));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PRICE" , cJSON_CreateString(std_price));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CLASS" , cJSON_CreateString(val_class));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PP" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PP" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PP" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PY" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PY" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PY" , cJSON_CreateString("0"));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CAT" , cJSON_CreateString(valuation_cat));
	cJSON_AddItemToObject(VALUATIONDATA_req, "FUTURE_PR" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_1" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE1" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_3" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE3" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLND_PRICE" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE1" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE2" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE3" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_2" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE2" , cJSON_CreateString(myzeroDup4));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEVAL_IND" , cJSON_CreateString("00"));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_GROUP" , cJSON_CreateString(origin_group));
	cJSON_AddItemToObject(VALUATIONDATA_req, "OVERHEAD_GRP" , cJSON_CreateString(overhd_grp));
	cJSON_AddItemToObject(VALUATIONDATA_req, "QTY_STRUCT" , cJSON_CreateString(with_quantity_structure));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_MAT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MAT_ORIGIN" , cJSON_CreateString(mat_origin));
	cJSON_AddItemToObject(VALUATIONDATA_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAX_CML_UN" , cJSON_CreateString("0"));

	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATAX" , VALUATIONDATAX_req);
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_AREA" , cJSON_CreateString(plantcode));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_CTRL" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOVING_PR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PRICE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CLASS" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CAT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "FUTURE_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLND_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEVAL_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_GROUP" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "OVERHEAD_GRP" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "QTY_STRUCT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_MAT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MAT_ORIGIN" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAX_CML_UN" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "WAREHOUSENUMBERDATA" , WAREHOUSENUMBERDATA_req);
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "WHSE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "STGESECTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "PLACEMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "WITHDRAWAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "L_EQUIP_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "L_EQUIP_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "L_EQUIP_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_1_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_2_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "LEQ_UNIT_3_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "UNITTYPE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "UNITTYPE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "UNITTYPE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "WM_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "WM_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "ADD_TO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "BLOCK_STGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "MSG_TO_IM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "SPEC_MVMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "CAPY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "PROCURE_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "PROCURE_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "STGE_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "REF_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATA_req, "STEP_PICK" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "WAREHOUSENUMBERDATAX" , WAREHOUSENUMBERDATAX_req);
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "WHSE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "STGESECTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "PLACEMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "WITHDRAWAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "L_EQUIP_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "L_EQUIP_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "L_EQUIP_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_1_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_2_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "LEQ_UNIT_3_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "UNITTYPE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "UNITTYPE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "UNITTYPE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "WM_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "WM_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "ADD_TO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "BLOCK_STGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "MSG_TO_IM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "SPEC_MVMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "CAPY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "PROCURE_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "PROCURE_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "STGE_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "REF_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(WAREHOUSENUMBERDATAX_req, "STEP_PICK" , cJSON_CreateString(""));
	    
		
	out = cJSON_Print(rfc_root);//json_mat_change_all_view_req_obj
	tc_strcpy(json_mat_change_all_view_req_obj,out);
	printf("%s\n", out);
	free(out);
	cJSON_Delete(rfc_root);

	return 0;
}

int mat_change_all_view()
{
	char *json_mat_change_all_view_req_obj = NULL;
	json_mat_change_all_view_req_obj = malloc(234000);
	
	call_BAPI_mat_change_all_view(json_mat_change_all_view_req_obj);
	printf("\nRetuned Str : %s\n", json_mat_change_all_view_req_obj);
	tm_curl_BAPI_mat_change_all_view ( json_mat_change_all_view_req_obj );
	//tm_curl_ZBAPI_MATERIAL_SAVEDATA ( json_mat_change_all_view_req_obj );
	free(json_mat_change_all_view_req_obj);
	
	return 0;
}

void mat_create()
{
	printf("\nmmat_create");
	//cll_BAPI_MATERIAL_SAVEREPLICA();
	cll_zbapi_material_savedata_mrp();
	go_for_rfc = 1;
	fprintf(fsuccess,"\n******************************************************************");
	if (tc_strcmp(mat_type, "FERT") == 0 && apl_dml_flag == 2)
	{
		printf("\nmat_type = FERT and apl_dml_flag = 2");
	}
	else
	{

		go_for_rfc = 1;
	}
}

void cll_zbapi_material_savedata_mrp()
{
//	static RFC_RC RfcRc;
//	static RFC_HANDLE hRfc;
//	char xException[256];
//	char a[256];
//
//	BAPIMATHEAD eBapiMatHead;
//	BAPI_MARA eBasicView;
//	BAPI_MARAX eBasicViewx;
//	BAPI_MARC eMrpView;
//	BAPI_MARCX eMrpViewx;
//	BAPI_MPGD eBapi_Mpgd;
//	BAPI_MPGDX eBapi_Mpgdx;
//	BAPI_MARD eBapi_Mard;
//	BAPI_MARDX eBapi_Mardx;
//	BAPI_MBEW eAccView;
//	BAPI_MBEWX eAccViewx;
//	RMMG1_AENNR eRmmg1_Aennr;
//	BAPIRET2 eBapiret2;
//
//	ITAB_H thBapi_Makt = ITAB_NULL;
//	ITAB_H thBapi_Marm = ITAB_NULL;
//	ITAB_H thBapi_Marmx = ITAB_NULL;
//	BAPI_MAKT *tBapi_Makt;
//	BAPI_MARM *tBapi_Marm;
//	BAPI_MARMX *tBapi_Marmx;
//
//	ITAB_H thBAPIE1PAREX3 = ITAB_NULL;
//	ITAB_H thBAPIE1PAREXX3 = ITAB_NULL;
//	BAPIE1PAREX3 *tBAPIE1PAREX3;
//	BAPIE1PAREXX3 *tBAPIE1PAREXX3;
//
//	apl_dml_flag = 0;
	printf("\nflag == 0");
	if (flag == 0)
	{
//		printf("\npstat: %c %c %c", pstat, pstat_acc, pstat_mrp); fflush(stdout);
//		if (pstat_mrp=='D' || pstat_acc== 'B')
		{
//			printf("\nMesage for Material Create: Material %s already exists for plant %s", part_noDup, plantcode); fflush(stdout);
//			fprintf(fsuccess, "\nMSG RCVD:Mesage for Material Create: Material %s already exists for plant %s", part_noDup, plantcode); fflush(fsuccess);
//			acc_flag = 1;
		}
//		else
		{
			acc_flag = 0;
			printf("\nGoing for MATERIAL CREATION..."); fflush(stdout);

			if (apl_dml_flag != 2 || apl_dml_flag == 0) /*only other views to be created as pstat = K*/
			{
				printf("\nOnly other Views will be extended"); fflush(stdout);
				extend_mat_in_plant();
//				hRfc = BapiLogon();
//				thBapi_Makt = ITAB_NULL;
//				thBapi_Marm = ITAB_NULL;
//				thBapi_Marmx = ITAB_NULL;
//
//				thBAPIE1PAREX3 = ITAB_NULL;
//				thBAPIE1PAREXX3 = ITAB_NULL;
//
//				if (thBapi_Makt==ITAB_NULL)
//				{
//					thBapi_Makt = ItCreate("MATERIALDESCRIPTION",sizeof(BAPI_MAKT),0,0);
//					if (thBapi_Makt==ITAB_NULL) rfc_error("ItCreate MATERIALDESCRIPTION");
//				}
//				else if (ItFree(thBapi_Makt) != 0) rfc_error("ItFree MATERIALDESCRIPTION");
//
//				if (thBapi_Marm==ITAB_NULL)
//				{
//					 thBapi_Marm = ItCreate("UNITSOFMEASURE",sizeof(BAPI_MARM),0,0);
//					 if (thBapi_Marm==ITAB_NULL) rfc_error("ItCreate UNITSOFMEASURE");
//				}
//				else if (ItFree(thBapi_Marm)!= 0) rfc_error("ItFree UNITSOFMEASURE");
//
//				if (thBapi_Marmx==ITAB_NULL)
//				{
//					thBapi_Marmx = ItCreate("UNITSOFMEASUREX",sizeof(BAPI_MARMX),0,0);
//					if (thBapi_Marmx==ITAB_NULL) rfc_error("ItCreate UNITSOFMEASUREX");
//				}
//				else if (ItFree(thBapi_Marmx)!= 0) rfc_error("ItFree UNITSOFMEASUREX");
//
//				if (thBAPIE1PAREX3==ITAB_NULL)
//				{
//					thBAPIE1PAREX3 = ItCreate("EXTENSIONIN",sizeof(BAPIE1PAREX3),0,0);
//					if (thBAPIE1PAREX3==ITAB_NULL)
//						rfc_error("ItCreate EXTENSIONIN");
//				}
//				else
//				{
//					if (ItFree(thBAPIE1PAREX3)!= 0)
//						rfc_error("ItFree EXTENSIONIN");
//				}
//
//				if (thBAPIE1PAREXX3==ITAB_NULL)
//				{
//					thBAPIE1PAREXX3 = ItCreate("EXTENSIONINX",sizeof(BAPIE1PAREXX3),0,0);
//					if (thBAPIE1PAREXX3==ITAB_NULL)
//						rfc_error("ItCreate EXTENSIONINX");
//				}
//				else
//				{
//					if (ItFree(thBAPIE1PAREXX3)!= 0)
//						rfc_error("ItFree EXTENSIONINX");
//				}
//
//				tBapi_Makt = ItAppLine (thBapi_Makt) ;
//				tBapi_Marm  = ItAppLine (thBapi_Marm) ;
//				tBapi_Marmx = ItAppLine (thBapi_Marmx) ;
//				tBAPIE1PAREX3 = ItAppLine(thBAPIE1PAREX3) ;
//				tBAPIE1PAREXX3 = ItAppLine(thBAPIE1PAREXX3) ;
//
//				if (tBapi_Makt == NULL)	rfc_error("ItAppLine BAPI_MAKT");
//				if (tBapi_Marm == NULL)	rfc_error("ItAppLine BAPI_MARM second table");
//				if (tBapi_Marmx == NULL) rfc_error("ItAppLine BAPI_MARMX");
//				if (tBAPIE1PAREX3 == NULL) rfc_error("ItAppLine BAPIE1PAREX3");
//				if (tBAPIE1PAREXX3 == NULL) rfc_error("ItAppLine BAPIE1PAREXX3");
//
				printf("\neBapiMatHead.Material:		%s",part_noDup); fflush(stdout);
				printf("\neBapiMatHead.Matl_Type:		%s",mat_type);
				printf("\neBapiMatHead.Ind_Sector:	%s","M");
				printf("\neBapiMatHead.Basic_View:		X");		/*basic view*/
				printf("\neBasicView.Base_Uom:		%s",meas_unit);
				printf("\neBasicView.Base_Uom_Iso:	%s",meas_unit);
				printf("\ntBapi_Marm->Alt_Unit:		%s",meas_unit);
				printf("\ntBapi_Marm->Alt_Unit_Iso:	%s",meas_unit);
				printf("\ntBapi_Marmx->Alt_Unit:	%s",meas_unit);
				printf("\ntBapi_Marmx->Alt_Unit_Iso:	%s",meas_unit);
				printf("\ntBapi_Makt->Matl_Desc:	%s",descDup);
				printf("\neBasicView.Document:		%s",doc_noDup);
				printf("\neBasicView.Doc_Type:		%s",dwg_typeDup);
				printf("\neBasicView.Doc_Vers:		%s",dwg_revDup);
				printf("\neBasicView.No_Sheets:		%s",sheet_noDup);
				printf("\neBasicView.Old_Mat_No:	%s",OldMatNoDup);
				printf("\neBasicView.Net_Weight:	%s",net_wtDup);
				printf("\ntBapi_Marm->Gross_Wt:		%s",gross_wt);
				printf("\neBasicView.Unit_Of_Wt:	%s",unit_wt);
				printf("\neBasicView.Unit_Of_Wt_Iso:	%s",unit_wt);
				printf("\ntBapi_Marm->Unit_Of_Wt:	%s",unit_wt);
				printf("\ntBapi_Marm->Unit_Of_Wt_Iso:	%s",unit_wt);
				printf("\ntBapi_Marm->Volume:		%s",volume);
				printf("\ntBapi_Marm->VolumeUnit:	%s",vol_unit);
				printf("\ntBapi_Marm->VolumeUnit_Iso:	%s",vol_unit);
				printf("\neBasicView.Size_Dim:		%s",sizeDup);
				printf("\neBasicView.Matl_Group:	%s",material_group);
				printf("\neBasicView.Division:		%s",basic_division);
				printf("\neBapiMatHead.Mrp_View:		X");		/*mrp view*/
				printf("\neMrpView.Mrp_Group:		%s",mrp_grp);
				printf("\neMrpView.Abc_Id:		%s",abc_ind);
				printf("\neMrpView.Pur_Status:		%s",mm_pp_status);
				printf("\neMrpView.Mrp_Type:		%s",mrp_type);
				printf("\neMrpView.Reorder_Pt:		%s",reord_pt);
				printf("\neMrpView.Quotausage:		%s",quota_arrangement_usage);
				printf("\neMrpView.Mrp_Ctrler:		%s",mrp_controller);
				printf("\neMrpView.Lotsizekey:		%s",lot_size_key);
				printf("\neMrpView.Fixed_Lot:		%s",fixed_lot_size);
				printf("\neMrpView.Max_Stock:		%s",max_stlvl);
				printf("\neMrpView.Proc_Type:		%s",proc_type);
				printf("\neMrpView.Spproctype:		%s",spl_proc_key);
				printf("\neMrpView.Bulk_Mat:		%s",blk_ind);
				printf("\neMrpView.Sm_Key:		%s",sched_mar_key);
				printf("\neMrpView.Ppc_Pl_Cal:		%s",plan_calendar);
				printf("\neMrpView.Grp_Reqmts:		%s",req_grp);
				printf("\neMrpView.Period_Ind:		%s",period_ind);
				printf("\neMrpView.Mixed_Mrp:		%s",mixedmrp);
				printf("\neMrpView.Availcheck:		%s",avail_chk);
				printf("\neBapi_Mpgd.Plng_Matl:		%s",splan_mat);
				printf("\neBapi_Mpgd.Plng_Plant:	%s",splan_plant);
				printf("\neBapi_Mpgd.Convfactor:	%s",splan_conv_fact);
				printf("\neMrpView.Alternative_Bom:	%s",alternativb);
				printf("\neMrpView.Dep_Req_Id:		%s",ind_collect);
				printf("\neMrpView.Rep_Manuf:		%s",rep_mfg_in);
				printf("\neMrpView.Repmanprof:		%s",rep_mfg);
				printf("\neMrpView.Determ_Grp:		%s",stock_det_group);
				printf("\neBapiMatHead.Storage_View:	X");			/*store view*/
				printf("\neMrpView.Issue_Unit:		%s",uoissue);
				printf("\neMrpView.Issue_Unit_Iso:	%s",uoissue);
				printf("\neMrpView.Profit_Ctr:		%s",profit_centre_sap);		/*profit_centre=0001111010*/
				printf("\neBapiMatHead.Quality_View:		X");			/*quality view*/
				printf("\neMrpView.Ind_Post_To_Insp_Stock:%s",qua_ins_ind);
				printf("\neMrpView.Doc_Reqd:		%s",doc_req);
				printf("\neMrpView.Gr_Pr_Time:		%s",grptime);
				printf("\neBasicView.Catprofile:	%s",catalog_prof);
				printf("\neBasicView.Qm_Procmnt:	%s",qm_proc_ind);
				printf("\neMrpView.Ctrl_Key:		%s",control_key);
				printf("\neMrpView.Cert_Type:		%s",certificate_type);
				printf("\neBapiMatHead.Account_View:		X"); 			/*accounting view */
				printf("\neAccView.Val_Cat:		%s",valuation_cat);
				printf("\neAccView.Val_Class:		%s",val_class);
				printf("\neAccView.Price_Ctrl:		%s",price_con);
				printf("\neAccView.Std_Price:		%s",std_price);
				printf("\neAccView.Moving_Pr:		%s",moving_avg_price);
				printf("\neBapiMatHead.Cost_View:		X");		/*lvl cost view */
				printf("\neAccView.Mat_Origin:		%s",mat_origin);
				printf("\neAccView.Orig_Group:		%s",origin_group);
				printf("\neMrpView.Lot_Size:		%s",cost_lot_size);
				printf("\neAccView.Overhead_Grp:	%s",overhd_grp);
				printf("\neMrpView.Variance_Key:	%s",variance_key);
				printf("\neAccView.Qty_Struct:		%s",with_quantity_structure);
				printf("\neMrpView.Split_Ind:		%s",costing_split_valuation);
				printf("\neMrpViewx.Split_Ind:		X");
				printf("\neRmmg1_Aennr.Aennr:		%s",dml_no_arg);
				printf("\npart_noDupDes:		%s",part_noDupDes);
				printf("\npart_noDupDes:		%s",part_noDupDesx); fflush(stdout);

				fprintf(fsuccess,"\neBapiMatHead.Material:	%s",part_noDup); fflush(fsuccess);
				fprintf(fsuccess,"\neBapiMatHead.Matl_Type:	%s",mat_type);
				fprintf(fsuccess,"\neBapiMatHead.Ind_Sector:		M");
				fprintf(fsuccess,"\neBapiMatHead.Basic_View:		X");		/*basic view*/
				fprintf(fsuccess,"\neBasicView.Base_Uom:	%s",meas_unit);
				fprintf(fsuccess,"\neBasicView.Base_Uom_Iso:	%s",meas_unit);
				fprintf(fsuccess,"\ntBapi_Marm->Alt_Unit:	%s",meas_unit);
				fprintf(fsuccess,"\ntBapi_Marm->Alt_Unit_Iso:	%s",meas_unit);
				fprintf(fsuccess,"\ntBapi_Marmx->Alt_Unit:	%s",meas_unit);
				fprintf(fsuccess,"\ntBapi_Marmx->Alt_Unit_Iso:	%s",meas_unit);
				fprintf(fsuccess,"\ntBapi_Makt->Matl_Desc:	%s",descDup);
				fprintf(fsuccess,"\neBasicView.Document:	%s",doc_noDup);
				fprintf(fsuccess,"\neBasicView.Doc_Type:	%s",dwg_typeDup);
				fprintf(fsuccess,"\neBasicView.Doc_Vers:	%s",dwg_revDup);
				fprintf(fsuccess,"\neBasicView.No_Sheets:	%s",sheet_noDup);
				fprintf(fsuccess,"\neBasicView.Old_Mat_No:	%s",OldMatNoDup);
				fprintf(fsuccess,"\neBasicView.Net_Weight:	%s",net_wtDup);
				fprintf(fsuccess,"\ntBapi_Marm->Gross_Wt:	%s",gross_wt);
				fprintf(fsuccess,"\neBasicView.Unit_Of_Wt:	%s",unit_wt);
				fprintf(fsuccess,"\neBasicView.Unit_Of_Wt_Iso:	%s",unit_wt);
				fprintf(fsuccess,"\ntBapi_Marm->Unit_Of_Wt:	%s",unit_wt);
				fprintf(fsuccess,"\ntBapi_Marm->Unit_Of_Wt_Iso:	%s",unit_wt);
				fprintf(fsuccess,"\ntBapi_Marm->Volume:		%s",volume);
				fprintf(fsuccess,"\ntBapi_Marm->VolumeUnit:	%s",vol_unit);
				fprintf(fsuccess,"\ntBapi_Marm->VolumeUnit_Iso:	%s",vol_unit);
				fprintf(fsuccess,"\neBasicView.Size_Dim:	%s",sizeDup);
				fprintf(fsuccess,"\neBasicView.Matl_Group:	%s",material_group);
				fprintf(fsuccess,"\neBasicView.Division:	%s",basic_division);
				fprintf(fsuccess,"\neBapiMatHead.Mrp_View:		X");		/*mrp view*/
				fprintf(fsuccess,"\neMrpView.Mrp_Group:		%s",mrp_grp);
				fprintf(fsuccess,"\neMrpView.Abc_Id:		%s",abc_ind);
				fprintf(fsuccess,"\neMrpView.Pur_Status:	%s",mm_pp_status);
				fprintf(fsuccess,"\neMrpView.Mrp_Type:		%s",mrp_type);
				fprintf(fsuccess,"\neMrpView.Reorder_Pt:	%s",reord_pt);
				fprintf(fsuccess,"\neMrpView.Quotausage:	%s",quota_arrangement_usage);
				fprintf(fsuccess,"\neMrpView.Mrp_Ctrler:	%s",mrp_controller);
				fprintf(fsuccess,"\neMrpView.Lotsizekey:	%s",lot_size_key);
				fprintf(fsuccess,"\neMrpView.Fixed_Lot:		%s",fixed_lot_size);
				fprintf(fsuccess,"\neMrpView.Max_Stock:		%s",max_stlvl);
				fprintf(fsuccess,"\neMrpView.Proc_Type:		%s",proc_type);
				fprintf(fsuccess,"\neMrpView.Spproctype:	%s",spl_proc_key);
				fprintf(fsuccess,"\neMrpView.Bulk_Mat:		%s",blk_ind);
				fprintf(fsuccess,"\neMrpView.Sm_Key:		%s",sched_mar_key);
				fprintf(fsuccess,"\neMrpView.Ppc_Pl_Cal:	%s",plan_calendar);
				fprintf(fsuccess,"\neMrpView.Grp_Reqmts:	%s",req_grp);
				fprintf(fsuccess,"\neMrpView.Period_Ind:	%s",period_ind);
				fprintf(fsuccess,"\neMrpView.Mixed_Mrp:		%s",mixedmrp);
				fprintf(fsuccess,"\neMrpView.Availcheck:	%s",avail_chk);
				fprintf(fsuccess,"\neBapi_Mpgd.Plng_Matl:	%s",splan_mat);
				fprintf(fsuccess,"\neBapi_Mpgd.Plng_Plant:	%s",splan_plant);
				fprintf(fsuccess,"\neBapi_Mpgd.Convfactor:	%s",splan_conv_fact);
				fprintf(fsuccess,"\neMrpView.Alternative_Bom:	%s",alternativb);
				fprintf(fsuccess,"\neMrpView.Dep_Req_Id:	%s",ind_collect);
				fprintf(fsuccess,"\neMrpView.Rep_Manuf:		%s",rep_mfg_in);
				fprintf(fsuccess,"\neMrpView.Repmanprof:	%s",rep_mfg);
				fprintf(fsuccess,"\neMrpView.Determ_Grp:	%s",stock_det_group);
				fprintf(fsuccess,"\neBapiMatHead.Storage_View:		X");		/*store view*/
				fprintf(fsuccess,"\neMrpView.Issue_Unit:	%s",uoissue);
				fprintf(fsuccess,"\neMrpView.Issue_Unit_Iso:	%s",uoissue);
				fprintf(fsuccess,"\neMrpView.Profit_Ctr:	%s",profit_centre_sap);		/*profit_centre=0001111010*/
				fprintf(fsuccess,"\neBapiMatHead.Quality_View:		X");		/*quality view*/
				fprintf(fsuccess,"\neMrpView.Ind_Post_To_Insp_Stock:%s",qua_ins_ind);
				fprintf(fsuccess,"\neMrpView.Doc_Reqd:		%s",doc_req);
				fprintf(fsuccess,"\neMrpView.Gr_Pr_Time:	%s",grptime);
				fprintf(fsuccess,"\neBasicView.Catprofile:	%s",catalog_prof);
				fprintf(fsuccess,"\neBasicView.Qm_Procmnt:	%s",qm_proc_ind);
				fprintf(fsuccess,"\neMrpView.Ctrl_Key:		%s",control_key);
				fprintf(fsuccess,"\neMrpView.Cert_Type:		%s",certificate_type);
				fprintf(fsuccess,"\neBapiMatHead.Account_View:		X"); 		/*accounting view */
				fprintf(fsuccess,"\neAccView.Val_Cat:		%s",valuation_cat);
				fprintf(fsuccess,"\neAccView.Val_Class:		%s",val_class);
				fprintf(fsuccess,"\neAccView.Price_Ctrl:	%s",price_con);
				fprintf(fsuccess,"\neAccView.Std_Price:		%s",std_price);
				fprintf(fsuccess,"\neAccView.Moving_Pr:		%s",moving_avg_price);
				fprintf(fsuccess,"\neBapiMatHead.Cost_View:		X");		/*lvl cost view */
				fprintf(fsuccess,"\neAccView.Mat_Origin:	%s",mat_origin);
				fprintf(fsuccess,"\neAccView.Orig_Group:	%s",origin_group);
				fprintf(fsuccess,"\neMrpView.Lot_Size:		%s",cost_lot_size);
				fprintf(fsuccess,"\neAccView.Overhead_Grp:	%s",overhd_grp);
				fprintf(fsuccess,"\neMrpView.Variance_Key:	%s",variance_key);
				fprintf(fsuccess,"\neAccView.Qty_Struct:	%s",with_quantity_structure);
				fprintf(fsuccess,"\neMrpView.Split_Ind:		%s",costing_split_valuation);
				fprintf(fsuccess,"\neMrpViewx.Split_Ind:		X");	/*Please make it as X*/
				fprintf(fsuccess,"\neRmmg1_Aennr.Aennr:		%s",dml_no_arg);
				fprintf(fsuccess,"\npart_noDupDes:		%s",part_noDupDes);
				fprintf(fsuccess,"\npart_noDupDes:		%s",part_noDupDesx); fflush(fsuccess);
//
//				SETCHAR(eBapiMatHead.Material,part_noDup);
//				SETCHAR(eBapiMatHead.Matl_Type,mat_type);
//				SETCHAR(eBapiMatHead.Ind_Sector,"M");
//				SETCHAR(eBapiMatHead.Basic_View,"");
//				SETCHAR(eBasicView.Base_Uom,meas_unit);
//				SETCHAR(eBasicView.Base_Uom_Iso,meas_unit);
//				SETCHAR(eBasicViewx.Base_Uom,"X");
//				SETCHAR(eBasicViewx.Base_Uom_Iso,"X");
//				SETCHAR(tBapi_Marm->Alt_Unit,meas_unit);
//				SETCHAR(tBapi_Marm->Alt_Unit_Iso,meas_unit);
//				SETCHAR(tBapi_Marmx->Alt_Unit,meas_unit);
//				SETCHAR(tBapi_Marmx->Alt_Unit_Iso,meas_unit);
//				SETCHAR(tBapi_Makt->Matl_Desc,descDup);
//				
//				if(tc_strlen(doc_noDup)==0)
//				{
//					SETCHAR(eBasicView.Document,"");
//					SETCHAR(eBasicViewx.Document,"");
//				}
//				else
//				{
//					SETCHAR(eBasicView.Document,doc_noDup);
//					SETCHAR(eBasicViewx.Document,"X");
//				}
//				if(tc_strlen(dwg_typeDup)==0)
//				{
//						SETCHAR(eBasicView.Doc_Type,"");
//						SETCHAR(eBasicViewx.Doc_Type,"");
//				}
//				else
//				{
//					SETCHAR(eBasicView.Doc_Type,dwg_typeDup);
//					SETCHAR(eBasicViewx.Doc_Type,"X");
//				}
//				if(tc_strlen(dwg_revDup)==0)
//				{
//						SETCHAR(eBasicView.Doc_Vers,"");
//						SETCHAR(eBasicViewx.Doc_Vers,"");
//				}
//				else
//				{
//					SETCHAR(eBasicView.Doc_Vers,dwg_revDup);
//					SETCHAR(eBasicViewx.Doc_Vers,"X");
//				}
//				if(tc_strlen(sheet_noDup)==0)
//				{
//						SETCHAR(eBasicView.No_Sheets,"");
//						SETCHAR(eBasicViewx.No_Sheets,"");
//				}
//				else
//				{
//					SETNUM(eBasicView.No_Sheets,sheet_noDup);
//					SETCHAR(eBasicViewx.No_Sheets,"X");
//				}
//				printf("sheet_noDup:%s",sheet_noDup); fflush(stdout);
//				fprintf(fsuccess,"sheet_noDup:%s",sheet_noDup); fflush(fsuccess);
//
//				SETCHAR(eBasicView.Old_Mat_No,OldMatNoDup);
//				SETCHAR(eBasicViewx.Old_Mat_No,"");
//				SETBCD(eBasicView.Net_Weight,myzeroDup3,3);
//				SETCHAR(eBasicViewx.Net_Weight,"");
//				SETBCD(tBapi_Marm->Gross_Wt,gross_wt,3);
//				SETCHAR(tBapi_Marmx->Gross_Wt,"");
//				SETCHAR(eBasicView.Unit_Of_Wt,unit_wt);
//				SETCHAR(eBasicView.Unit_Of_Wt_Iso,unit_wt);
//				SETCHAR(eBasicViewx.Unit_Of_Wt,"");
//				SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"");
//				SETCHAR(tBapi_Marm->Unit_Of_Wt,unit_wt);
//				SETCHAR(tBapi_Marm->Unit_Of_Wt_Iso,unit_wt);
//				SETCHAR(tBapi_Marmx->Unit_Of_Wt,"");
//				SETCHAR(tBapi_Marmx->Unit_Of_Wt_Iso,"");
//				SETBCD(tBapi_Marm->Volume,myzeroDup3,3);
//				SETCHAR(tBapi_Marm->VolumeUnit,vol_unit);
//				SETCHAR(tBapi_Marm->VolumeUnit_Iso,vol_unit);
//				SETCHAR(tBapi_Marmx->Volume,"");
//				SETCHAR(tBapi_Marmx->VolumeUnit,"");
//				SETCHAR(tBapi_Marmx->VolumeUnit_Iso,"");
//				if(tc_strlen(sizeDup)==0)
//				{
//					SETCHAR(eBasicView.Size_Dim,"");
//					SETCHAR(eBasicViewx.Size_Dim,"");
//				}
//				else
//				{
//					SETCHAR(eBasicView.Size_Dim,sizeDup);/*sizeDup*/
//					SETCHAR(eBasicViewx.Size_Dim,"X");
//				}
//
//				if(tc_strlen(store_locDup)>0)
//				{
//					//string strtoupper ( string store_locDup );
//					//store_locDup1 = strtoupper(store_locDup);
//
//					printf ("Before conversion: %s\n", store_locDup);
//					for (p = store_locDup; *p != '\0'; ++p)
//					{
//						*p = toupper(*p);
//					}
//					printf ("After conversion: %s\n", store_locDup);
//
//					//printf("\nstore location converted to capital letters, if in small letters  : %s",store_locDup1);
//					SETCHAR(eMrpView.Iss_St_Loc,store_locDup);
//					SETCHAR(eMrpView.Sloc_Exprc,store_locDup);
//					SETCHAR(eMrpViewx.Iss_St_Loc,"X");
//					SETCHAR(eMrpViewx.Sloc_Exprc,"X");
//					printf("\nstore location is : %s",store_locDup);
//					fprintf(fsuccess,"\nstore location is : %s",store_locDup);
//				}
//				else
//				{
//					SETCHAR(eMrpView.Iss_St_Loc,"");
//					SETCHAR(eMrpView.Sloc_Exprc,"");
//					SETCHAR(eMrpViewx.Iss_St_Loc,"");
//					SETCHAR(eMrpViewx.Sloc_Exprc,"");
//
//					//printf("\nstore location is : %s",store_locDup); fflush(stdout);
//					//fprintf(fsuccess,"\nstore location is : %s",store_locDup); fflush(fsuccess);
//					printf("\nstore location is null"); 
//				}
//				
//				SETCHAR(eBasicView.Matl_Group,material_group);
//				SETCHAR(eBasicViewx.Matl_Group,"");
//				SETCHAR(eBasicView.Division,basic_division);
//				SETCHAR(eBasicViewx.Division,"");
//				SETCHAR(eBapiMatHead.Mrp_View,"X");	/*mrp view*/
//				
//				SETCHAR(eMrpView.Mrp_Group,mrp_grp);
//				SETCHAR(eMrpViewx.Mrp_Group,"X");
//				SETCHAR(eMrpView.Abc_Id,abc_ind);
//				SETCHAR(eMrpViewx.Abc_Id,"X");
//
//				if(tc_strlen(mm_pp_status)==0)
//				{
//					SETCHAR(eMrpView.Pur_Status," ");
//					SETCHAR(eMrpViewx.Pur_Status,"X");
//					printf("\nMaterial  status is........ABC : %s",mm_pp_status);
//					fprintf(fsuccess,"\nMaterial  status is........ABC : %s",mm_pp_status);
//				}
//				else
//				{
//					SETCHAR(eMrpView.Pur_Status,mm_pp_status);
//					SETCHAR(eMrpViewx.Pur_Status,"X");
//					printf("\nMaterial  status is........ABC1 : %s",mm_pp_status);
//					fprintf(fsuccess,"\nMaterial  status is........ABC1 : %s",mm_pp_status);
//				}
//				
//				//SETCHAR(eMrpView.Pur_Status,mm_pp_status);
//				//SETCHAR(eMrpViewx.Pur_Status,"X");
//				SETCHAR(eMrpView.Mrp_Type,mrp_type);
//				SETCHAR(eMrpViewx.Mrp_Type,"X");
//				SETBCD(eMrpView.Reorder_Pt,reord_pt,3);
//				SETCHAR(eMrpViewx.Reorder_Pt,"X");
//
//				SETCHAR(eMrpView.Quotausage,quota_arrangement_usage);
//				SETCHAR(eMrpViewx.Quotausage,"X");
//				SETCHAR(eMrpView.Mrp_Ctrler,mrp_controller);
//				SETCHAR(eMrpViewx.Mrp_Ctrler,"X");
//				SETCHAR(eMrpView.Lotsizekey,lot_size_key);
//				SETCHAR(eMrpViewx.Lotsizekey,"X");
//				SETBCD(eMrpView.Fixed_Lot,fixed_lot_size,3);
//				SETCHAR(eMrpViewx.Fixed_Lot,"X");
//				SETBCD(eMrpView.Max_Stock,max_stlvl,3);
//				SETCHAR(eMrpViewx.Max_Stock,"X");
//				SETCHAR(eMrpView.Proc_Type,proc_type);
//				SETCHAR(eMrpViewx.Proc_Type,"X");
//				SETCHAR(eMrpView.Spproctype,spl_proc_key);
//				SETCHAR(eMrpViewx.Spproctype,"X");
//				SETCHAR(eMrpView.Bulk_Mat,blk_ind);
//				SETCHAR(eMrpViewx.Bulk_Mat,"X");
//				SETCHAR(eMrpView.Sm_Key,sched_mar_key);
//				SETCHAR(eMrpViewx.Sm_Key,"X");
//				SETCHAR(eMrpView.Ppc_Pl_Cal,plan_calendar);
//				SETCHAR(eMrpViewx.Ppc_Pl_Cal,"X");
//				SETCHAR(eMrpView.Grp_Reqmts,req_grp);
//				SETCHAR(eMrpViewx.Grp_Reqmts,"X");
//				SETCHAR(eMrpView.Period_Ind,period_ind);
//				SETCHAR(eMrpViewx.Period_Ind,"X");
//				SETCHAR(eMrpView.Mixed_Mrp,mixedmrp);
//				SETCHAR(eMrpViewx.Mixed_Mrp,"X");
//				SETCHAR(eMrpView.Availcheck,avail_chk);
//				SETCHAR(eMrpViewx.Availcheck,"X");
//				SETCHAR(eBapi_Mpgd.Plng_Matl,splan_mat);
//				SETCHAR(eBapi_Mpgdx.Plng_Matl,"X");
//				SETCHAR(eBapi_Mpgd.Plng_Plant,splan_plant);
//				SETCHAR(eBapi_Mpgdx.Plng_Plant,"X");
//				SETCHAR(eBapi_Mpgd.Convfactor,splan_conv_fact);
//				SETCHAR(eBapi_Mpgdx.Convfactor,"X");
//				SETCHAR(eMrpView.Alternative_Bom,"");
//				SETCHAR(eMrpViewx.Alternative_Bom,"");
//				SETCHAR(eMrpView.Alt_Bom_Id,alternativb);
//				SETCHAR(eMrpViewx.Alt_Bom_Id,"X");
//				SETCHAR(eMrpView.Dep_Req_Id,ind_collect);
//				SETCHAR(eMrpViewx.Dep_Req_Id,"X");
//				
//				
//
//				//SETCHAR(eMrpView.Rep_Manuf,"");/*rep_mfg_in*/
//				//SETCHAR(eMrpViewx.Rep_Manuf,"");/*X*/
//				//SETCHAR(eMrpView.Repmanprof,"");/*rep_mfg*/
//				//SETCHAR(eMrpViewx.Repmanprof,"");/*X*/
//
//				if(tc_strlen(rep_mfg)>0)		//rep_mfg modified on 14.02.2017 for TE02
//				{
//					SETCHAR(eMrpView.Rep_Manuf,"X");/*rep_mfg_in*/
//					SETCHAR(eMrpViewx.Rep_Manuf,"X");/*X*/
//					SETCHAR(eMrpView.Repmanprof,rep_mfg);/*rep_mfg*/
//					SETCHAR(eMrpViewx.Repmanprof,"X");/*X*/
//				}
//				else
//				{
//					SETCHAR(eMrpView.Rep_Manuf,"");/*rep_mfg_in*/
//					SETCHAR(eMrpViewx.Rep_Manuf,"X");/*X*/
//					SETCHAR(eMrpView.Repmanprof,"");/*rep_mfg*/
//					SETCHAR(eMrpViewx.Repmanprof,"X");/*X*/
//				}
//				
//				SETCHAR(eMrpView.Determ_Grp,stock_det_group);
//				SETCHAR(eMrpViewx.Determ_Grp,"X");
//				SETCHAR(eBapiMatHead.Storage_View,"X");	/*store view*/
//				SETCHAR(eMrpView.Issue_Unit,uoissue);
//				SETCHAR(eMrpView.Issue_Unit_Iso,uoissue);
//				SETCHAR(eMrpViewx.Issue_Unit,"");	/*these values they are sending as blank hence removed*/
//				SETCHAR(eMrpViewx.Issue_Unit_Iso,"");
//				SETCHAR(eMrpView.Profit_Ctr,profit_centre_sap);		/*profit_centre=0001111010*/
//				SETCHAR(eMrpViewx.Profit_Ctr,"X");
//				printf("\n3"); fflush(stdout);
//				if(tc_strcmp(mat_type,"FERT") != 0)
//				{
//					SETCHAR(eBapiMatHead.Quality_View,"X");	/*quality view*/
//					SETCHAR(eMrpView.Ind_Post_To_Insp_Stock,qua_ins_ind);
//					SETCHAR(eMrpViewx.Ind_Post_To_Insp_Stock,"X");
//					SETCHAR(eMrpView.Doc_Reqd,doc_req);
//					SETCHAR(eMrpViewx.Doc_Reqd,"X");
//					SETBCD(eMrpView.Gr_Pr_Time,grptime,0);
//					SETCHAR(eMrpViewx.Gr_Pr_Time,"X");
//					SETCHAR(eBasicView.Catprofile,catalog_prof);
//					SETCHAR(eBasicViewx.Catprofile,"X");
//					SETCHAR(eBasicView.Qm_Procmnt,qm_proc_ind);
//					SETCHAR(eBasicViewx.Qm_Procmnt,"X");
//					SETCHAR(eMrpView.Ctrl_Key,control_key);
//					SETCHAR(eMrpViewx.Ctrl_Key,"X");
//					SETCHAR(eMrpView.Cert_Type,certificate_type);
//					SETCHAR(eMrpViewx.Cert_Type,"X");
//
//					printf("\ncertificate_type:%s",certificate_type); fflush(stdout);
//				}
//				else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
//				{
//					printf("\nQM View For VC");fflush(stdout);
//					printf("\n[%s,%s,%s,%s,%s]",qua_ins_ind,doc_req,grptime,catalog_prof,qm_proc_ind);fflush(stdout);
//
//					SETCHAR(eBapiMatHead.Quality_View,"X");	/*quality view*/
//					SETCHAR(eMrpView.Ind_Post_To_Insp_Stock,"");
//					SETCHAR(eMrpViewx.Ind_Post_To_Insp_Stock,"");
//					SETCHAR(eMrpView.Doc_Reqd,"");
//					SETCHAR(eMrpViewx.Doc_Reqd,"");
//					SETBCD(eMrpView.Gr_Pr_Time,grptime,0);
//					SETCHAR(eMrpViewx.Gr_Pr_Time,"X");
//					SETCHAR(eBasicView.Catprofile,catalog_prof);
//					SETCHAR(eBasicViewx.Catprofile,"X");
//					SETCHAR(eBasicView.Qm_Procmnt,"");
//					SETCHAR(eBasicViewx.Qm_Procmnt,"");
//					SETCHAR(eMrpView.Ctrl_Key,control_key);
//					SETCHAR(eMrpViewx.Ctrl_Key,"X");
//					SETCHAR(eMrpView.Cert_Type,certificate_type);
//					SETCHAR(eMrpViewx.Cert_Type,"X");
//				}
//				else    /* as per req. on 1/8 */
//				{
//					SETCHAR(eBapiMatHead.Quality_View,"");	/*quality view*/
//					SETCHAR(eMrpView.Ind_Post_To_Insp_Stock,"");
//					SETCHAR(eMrpViewx.Ind_Post_To_Insp_Stock,"");
//					SETCHAR(eMrpView.Doc_Reqd,"");
//					SETCHAR(eMrpViewx.Doc_Reqd,"");
//					SETBCD(eMrpView.Gr_Pr_Time,"",0);
//					SETCHAR(eMrpViewx.Gr_Pr_Time,"");
//					SETCHAR(eBasicView.Catprofile,"");
//					SETCHAR(eBasicViewx.Catprofile,"");
//					SETCHAR(eBasicView.Qm_Procmnt,"");
//					SETCHAR(eBasicViewx.Qm_Procmnt,"");
//					SETCHAR(eMrpView.Ctrl_Key,"");
//					SETCHAR(eMrpViewx.Ctrl_Key,"");
//					SETCHAR(eMrpView.Cert_Type,"");
//					SETCHAR(eMrpViewx.Cert_Type,"");
//				}
//				SETCHAR(eBapiMatHead.Account_View,"X"); /*accounting view */
//				SETCHAR(eAccView.Val_Cat,valuation_cat);
//				SETCHAR(eAccViewx.Val_Cat,"X");
//				SETCHAR(eAccView.Val_Class,val_class);
//				SETCHAR(eAccViewx.Val_Class,"X");
//				SETCHAR(eAccView.Price_Ctrl,price_con);
//				SETCHAR(eAccViewx.Price_Ctrl,"X");
//				SETBCD(eAccView.Std_Price,std_price,4);
//				SETCHAR(eAccViewx.Std_Price,"X");
//				SETBCD(eAccView.Moving_Pr,moving_avg_price,4);
//				SETCHAR(eAccViewx.Moving_Pr,"X");
//
//				SETCHAR(eBapiMatHead.Cost_View,"X");/*lvl cost view */
//				SETCHAR(eAccView.Mat_Origin,mat_origin);
//				SETCHAR(eAccViewx.Mat_Origin,"X");
//				SETCHAR(eAccView.Orig_Group,origin_group);
//				SETCHAR(eAccViewx.Orig_Group,"X");
//				SETBCD(eMrpView.Lot_Size,cost_lot_size,3);
//				SETCHAR(eMrpViewx.Lot_Size,"X");
//				SETCHAR(eAccView.Overhead_Grp,overhd_grp);
//				SETCHAR(eAccViewx.Overhead_Grp,"X");
//				SETCHAR(eMrpView.Variance_Key,variance_key);
//				SETCHAR(eMrpViewx.Variance_Key,"X");
//				SETCHAR(eAccView.Qty_Struct,with_quantity_structure);
//				SETCHAR(eAccViewx.Qty_Struct,"X");
//				SETCHAR(eMrpView.Split_Ind,costing_split_valuation);
//				SETCHAR(eMrpViewx.Split_Ind,"");/*Please make it as X*/
//				SETCHAR(eRmmg1_Aennr.Aennr,dml_no_arg);
//
//				SETCHAR(eBapiMatHead.Sales_View,"");
//				SETCHAR(eBapiMatHead.Purchase_View,"");
//				SETCHAR(eBapiMatHead.Forecast_View,"");
//				SETCHAR(eBapiMatHead.Work_Sched_View,"");
//				SETCHAR(eBapiMatHead.Prt_View,"");
//				SETCHAR(eBapiMatHead.Warehouse_View,"");
//				SETCHAR(eBapiMatHead.Inp_Fld_Check,"");
//				SETCHAR(eBapiMatHead.Material_External,"");
//				SETCHAR(eBapiMatHead.MateriaL_Guid,"");
//				SETCHAR(eBapiMatHead.Material_Version,"");
//
//				SETCHAR(eBasicView.Del_Flag,"");
//				SETCHAR(eBasicView.Po_Unit,"");
//				SETCHAR(eBasicView.Po_Unit_Iso,"");
//				SETCHAR(eBasicView.Doc_Format,"");
//				SETCHAR(eBasicView.Doc_Chg_No,"");
//				SETCHAR(eBasicView.Page_No,"");
//				SETCHAR(eBasicView.Prod_Memo,"");
//				SETCHAR(eBasicView.Pageformat,"");
//				SETCHAR(eBasicView.Basic_Matl,"");
//				SETCHAR(eBasicView.Std_Descr,"");
//				SETCHAR(eBasicView.Dsn_Office,"");
//				SETCHAR(eBasicView.Pur_Valkey,"");
//				SETCHAR(eBasicView.Container,"");
//				SETCHAR(eBasicView.Stor_Conds,"");
//				SETCHAR(eBasicView.Temp_Conds,"");
//				SETCHAR(eBasicView.Trans_Grp,"");
//				SETCHAR(eBasicView.Haz_Mat_No,"");
//				SETCHAR(eBasicView.Competitor,"");
//				SETBCD(eBasicView.Qty_Gr_Gi,myzeroDup3,3);
//				SETCHAR(eBasicView.Proc_Rule,"");
//				SETCHAR(eBasicView.Sup_Source,"");
//				SETCHAR(eBasicView.Season,"");
//				SETCHAR(eBasicView.Label_Type,"");
//				SETCHAR(eBasicView.Label_Form,"");
//				SETCHAR(eBasicView.Prod_Hier,"");
//				SETCHAR(eBasicView.Cad_Id,"X");
//				SETBCD(eBasicView.Allowed_Wt,myzeroDup3,3);
//				SETCHAR(eBasicView.Pack_Wt_Un,"");
//				SETCHAR(eBasicView.Pack_Wt_Un_Iso,"");
//				SETBCD(eBasicView.Allwd_Vol,myzeroDup3,3);
//				SETCHAR(eBasicView.Pack_Vo_Un,"");
//				SETCHAR(eBasicView.Pack_Vo_Un_Iso,"");
//				SETBCD(eBasicView.Wt_Tol_Lt,myzeroDup1,1);
//				SETBCD(eBasicView.Vol_Tol_Lt,myzeroDup1,1);
//				SETCHAR(eBasicView.Var_Ord_Un,"");
//				SETCHAR(eBasicView.Batch_Mgmt,"");
//				SETCHAR(eBasicView.Sh_Mat_Typ,"");
//				SETBCD(eBasicView.Fill_Level,"0",0);
//				SETINT2(&eBasicView.Stack_Fact,"0");
//				SETCHAR(eBasicView.Mat_Grp_Sm,"");
//				SETCHAR(eBasicView.Authoritygroup,"");
//				SETBCD(eBasicView.Minremlife,"0",0);
//				SETBCD(eBasicView.Shelf_Life,"0",0);
//				SETBCD(eBasicView.Stor_Pct,"0",0);
//				SETCHAR(eBasicView.Pur_Status,"");
//				SETCHAR(eBasicView.Sal_Status,"");
//				SETDATE(eBasicView.Pvalidfrom,"");
//				SETDATE(eBasicView.Svalidfrom,"");
//				SETCHAR(eBasicView.Envt_Rlvt,"");
//				SETCHAR(eBasicView.Prod_Alloc,"");
//				SETCHAR(eBasicView.Qual_Dik,"");
//				SETCHAR(eBasicView.Manu_Mat,"");
//				SETCHAR(eBasicView.Mfr_No,"");
//				SETCHAR(eBasicView.Inv_Mat_No,"");
//				SETCHAR(eBasicView.Manuf_Prof,"");
//				SETCHAR(eBasicView.Hazmatprof,"");
//				SETCHAR(eBasicView.High_Visc,"");
//				SETCHAR(eBasicView.Looseorliq,"");
//				SETCHAR(eBasicView.Closed_Box,"");
//				SETCHAR(eBasicView.Appd_B_Rec,"");
//				SETNUM(eBasicView.Matcmpllvl,"00");
//				SETCHAR(eBasicView.Par_Eff,"");
//				SETCHAR(eBasicView.Round_Up_Rule_Expiration_Date,"");
//				SETCHAR(eBasicView.Period_Ind_Expiration_Date,"D");
//				SETCHAR(eBasicView.Prod_Composition_On_Packaging,"");
//				SETCHAR(eBasicView.Item_Cat,"");
//				SETCHAR(eBasicView.Haz_Mat_No_External,"");
//				SETCHAR(eBasicView.Haz_Mat_No_Guid,"");
//				SETCHAR(eBasicView.Haz_Mat_No_Version,"");
//				SETCHAR(eBasicView.Inv_Mat_No_External,"");
//				SETCHAR(eBasicView.Inv_Mat_No_Guid,"");
//				SETCHAR(eBasicView.Inv_Mat_No_Version,"");
//				SETCHAR(eBasicView.Material_Fixed,"");
//				SETCHAR(eBasicView.Cm_Relevance_Flag,"");
//				SETCHAR(eBasicView.Sled_Bbd,"");
//				SETCHAR(eBasicView.Gtin_Variant,"");
//				SETCHAR(eBasicView.Serialization_Level,"");
//				SETCHAR(eBasicView.Pl_Ref_Mat,"");
//				SETCHAR(eBasicView.Extmatlgrp,"");
//				SETCHAR(eBasicView.Uomusage,"");
//				SETCHAR(eBasicView.Pl_Ref_Mat_External,"");
//				SETCHAR(eBasicView.Pl_Ref_Mat_Guid,"");
//				SETCHAR(eBasicView.Pl_Ref_Mat_Version,"");
//
//				SETCHAR(eBasicViewx.Del_Flag,"");
//				SETCHAR(eBasicViewx.Po_Unit,"");
//				SETCHAR(eBasicViewx.Po_Unit_Iso,"");
//				SETCHAR(eBasicViewx.Doc_Format,"");
//				SETCHAR(eBasicViewx.Doc_Chg_No,"");
//				SETCHAR(eBasicViewx.Page_No,"");
//				SETCHAR(eBasicViewx.Prod_Memo,"");
//				SETCHAR(eBasicViewx.Pageformat,"");
//				SETCHAR(eBasicViewx.Basic_Matl,"");
//				SETCHAR(eBasicViewx.Std_Descr,"");
//				SETCHAR(eBasicViewx.Dsn_Office,"");
//				SETCHAR(eBasicViewx.Pur_Valkey,"");
//				SETCHAR(eBasicViewx.Container,"");
//				SETCHAR(eBasicViewx.Stor_Conds,"");
//				SETCHAR(eBasicViewx.Temp_Conds,"");
//				SETCHAR(eBasicViewx.Trans_Grp,"");
//				SETCHAR(eBasicViewx.Haz_Mat_No,"");
//				SETCHAR(eBasicViewx.Competitor,"");
//				SETCHAR(eBasicViewx.Qty_Gr_Gi,"");
//				SETCHAR(eBasicViewx.Proc_Rule,"");
//				SETCHAR(eBasicViewx.Sup_Source,"");
//				SETCHAR(eBasicViewx.Season,"");
//				SETCHAR(eBasicViewx.Label_Type,"");
//				SETCHAR(eBasicViewx.Label_Form,"");
//				SETCHAR(eBasicViewx.Prod_Hier,"");
//				SETCHAR(eBasicViewx.Cad_Id,"X");
//				SETCHAR(eBasicViewx.Allowed_Wt,"");
//				SETCHAR(eBasicViewx.Pack_Wt_Un,"");
//				SETCHAR(eBasicViewx.Pack_Wt_Un_Iso,"");
//				SETCHAR(eBasicViewx.Allwd_Vol,"");
//				SETCHAR(eBasicViewx.Pack_Vo_Un,"");
//				SETCHAR(eBasicViewx.Pack_Vo_Un_Iso,"");
//				SETCHAR(eBasicViewx.Wt_Tol_Lt,"");
//				SETCHAR(eBasicViewx.Vol_Tol_Lt,"");
//				SETCHAR(eBasicViewx.Var_Ord_Un,"");
//				SETCHAR(eBasicViewx.Batch_Mgmt,"");
//				SETCHAR(eBasicViewx.Sh_Mat_Typ,"");
//				SETCHAR(eBasicViewx.Fill_Level,"");
//				SETCHAR(eBasicViewx.Stack_Fact,"");
//				SETCHAR(eBasicViewx.Mat_Grp_Sm,"");
//				SETCHAR(eBasicViewx.Authoritygroup,"");
//				SETCHAR(eBasicViewx.Minremlife,"");
//				SETCHAR(eBasicViewx.Shelf_Life,"");
//				SETCHAR(eBasicViewx.Stor_Pct,"");
//				SETCHAR(eBasicViewx.Pur_Status,"");
//				SETCHAR(eBasicViewx.Sal_Status,"");
//				SETCHAR(eBasicViewx.Pvalidfrom,"");
//				SETCHAR(eBasicViewx.Svalidfrom,"");
//				SETCHAR(eBasicViewx.Envt_Rlvt,"");
//				SETCHAR(eBasicViewx.Prod_Alloc,"");
//				SETCHAR(eBasicViewx.Qual_Dik,"");
//				SETCHAR(eBasicViewx.Manu_Mat,"");
//				SETCHAR(eBasicViewx.Mfr_No,"");
//				SETCHAR(eBasicViewx.Inv_Mat_No,"");
//				SETCHAR(eBasicViewx.Manuf_Prof,"");
//				SETCHAR(eBasicViewx.Hazmatprof,"");
//				SETCHAR(eBasicViewx.High_Visc,"");
//				SETCHAR(eBasicViewx.Looseorliq,"");
//				SETCHAR(eBasicViewx.Closed_Box,"");
//				SETCHAR(eBasicViewx.Appd_B_Rec,"");
//				SETCHAR(eBasicViewx.Matcmpllvl,"");
//				SETCHAR(eBasicViewx.Par_Eff,"");
//				SETCHAR(eBasicViewx.Round_Up_Rule_Expiration_Date,"");
//				SETCHAR(eBasicViewx.Period_Ind_Expiration_Date,"");
//				SETCHAR(eBasicViewx.Prod_Composition_On_Packaging,"");
//				SETCHAR(eBasicViewx.Item_Cat,"");
//				SETCHAR(eBasicViewx.Haz_Mat_No_External,"");
//				SETCHAR(eBasicViewx.Haz_Mat_No_Guid,"");
//				SETCHAR(eBasicViewx.Haz_Mat_No_Version,"");
//				SETCHAR(eBasicViewx.Inv_Mat_No_External,"");
//				SETCHAR(eBasicViewx.Inv_Mat_No_Guid,"");
//				SETCHAR(eBasicViewx.Inv_Mat_No_Version,"");
//				SETCHAR(eBasicViewx.Material_Fixed,"");
//				SETCHAR(eBasicViewx.Cm_Relevance_Flag,"");
//				SETCHAR(eBasicViewx.Sled_Bbd,"");
//				SETCHAR(eBasicViewx.Gtin_Variant,"");
//				SETCHAR(eBasicViewx.Serialization_Level,"");
//				SETCHAR(eBasicViewx.Pl_Ref_Mat,"");
//				SETCHAR(eBasicViewx.Extmatlgrp,"");
//				SETCHAR(eBasicViewx.Uomusage,"");
//				SETCHAR(eBasicViewx.Pl_Ref_Mat_External,"");
//				SETCHAR(eBasicViewx.Pl_Ref_Mat_Guid,"");
//				SETCHAR(eBasicViewx.Pl_Ref_Mat_Version,"");
//				SETCHAR(eMrpView.Plant,plantcode);
//				SETCHAR(eMrpView.Del_Flag,"");
//				SETCHAR(eMrpView.Crit_Part,"");
//				SETCHAR(eMrpView.Pur_Group,"");
//				SETCHAR(eMrpView.Mrpprofile,"");
//				SETCHAR(eMrpView.Plnd_Delry,"0");
//				SETBCD(eMrpView.Assy_Scrap,myzeroDup2,2);
//				SETBCD(eMrpView.Safety_Stk,myzeroDup3,3);
//				SETBCD(eMrpView.Minlotsize,myzeroDup3,3);
//				SETBCD(eMrpView.Maxlotsize,myzeroDup3,3);
//				SETBCD(eMrpView.Round_Val,myzeroDup3,3);
//				SETBCD(eMrpView.Ord_Costs,myzeroDup4,4);
//				SETCHAR(eMrpView.Stor_Costs,"");
//
//				SETCHAR(eMrpView.Discontinu,"");
//				SETCHAR(eMrpView.Eff_O_Day,"");
//				SETCHAR(eMrpView.Follow_Up,"");
//				SETCHAR(eMrpView.Backflush,"");
//				SETCHAR(eMrpView.Production_Scheduler,"");
//				SETBCD(eMrpView.Proc_Time,myzeroDup2,2);
//				SETBCD(eMrpView.Setuptime,myzeroDup2,2);
//				SETBCD(eMrpView.Interop,myzeroDup2,2);
//				SETBCD(eMrpView.Base_Qty,myzeroDup3,3);
//				SETBCD(eMrpView.Inhseprodt,"0",0);
//				SETBCD(eMrpView.Stgeperiod,"0",0);
//				SETCHAR(eMrpView.Stge_Pd_Un,"");
//				SETCHAR(eMrpView.Stge_Pd_Un_Iso,"");
//				SETBCD(eMrpView.Over_Tol,myzeroDup1,1);
//				SETCHAR(eMrpView.Unlimited,"");
//				SETBCD(eMrpView.Under_Tol,myzeroDup1,1);
//				SETBCD(eMrpView.Replentime,"0",0);
//				SETCHAR(eMrpView.Replace_Pt,"");
//				SETCHAR(eMrpView.Loadinggrp,"");
//				SETCHAR(eMrpView.Batch_Mgmt,"");
//				SETBCD(eMrpView.Serv_Level,myzeroDup1,1);
//				SETCHAR(eMrpView.Fy_Variant,"");
//				SETCHAR(eMrpView.Corr_Fact,"");
//				SETBCD(eMrpView.Setup_Time,myzeroDup2,2);
//				SETBCD(eMrpView.Base_Qty_Plan,myzeroDup3,3);
//				SETBCD(eMrpView.Ship_Proc_Time,myzeroDup2,2);
//				SETCHAR(eMrpView.Sup_Source,"");
//				SETCHAR(eMrpView.Auto_P_Ord,"");
//				SETCHAR(eMrpView.Sourcelist,"");
//				SETCHAR(eMrpView.Comm_Code,"");
//				SETCHAR(eMrpView.Countryori,"");
//				SETCHAR(eMrpView.Countryori_Iso,"");
//				SETCHAR(eMrpView.Regionorig,"");
//				SETCHAR(eMrpView.Comm_Co_Un,"");
//				SETCHAR(eMrpView.Comm_Co_Un_Iso,"");
//				SETCHAR(eMrpView.Expimpgrp,"");
//				SETNUM(eMrpView.Pl_Ti_Fnce,"000");
//				SETCHAR(eMrpView.Consummode,"");
//				SETNUM(eMrpView.Bwd_Cons,"000");
//				SETNUM(eMrpView.Fwd_Cons,"000");
//				SETCHAR(eMrpView.Bom_Usage,"");
//				SETCHAR(eMrpView.Planlistgrp,"");
//				SETCHAR(eMrpView.Planlistcnt,"");
//				SETCHAR(eMrpView.Specprocty,"");
//				SETCHAR(eMrpView.Prod_Unit,"");
//				SETCHAR(eMrpView.Prod_Unit_Iso,"");
//				//SETCHAR(eMrpView.Iss_St_Loc,store_locDup);
//				//SETCHAR(eMrpView.Iss_St_Loc,"");
//				SETBCD(eMrpView.Comp_Scrap,myzeroDup2,2);
//				SETBCD(eMrpView.Cycle_Time,"0",0);
//				SETCHAR(eMrpView.Covprofile,"");
//				SETCHAR(eMrpView.Cc_Ph_Inv,"");
//				SETCHAR(eMrpView.Serno_Prof,"");
//				SETCHAR(eMrpView.Neg_Stocks,"");
//				SETCHAR(eMrpView.Qm_Rgmts,"");
//				SETCHAR(eMrpView.Plng_Cycle,"");
//				SETCHAR(eMrpView.Round_Prof,"");
//				SETCHAR(eMrpView.Refmatcons,"");
//				SETCHAR(eMrpView.D_To_Ref_M,"");
//				SETBCD(eMrpView.Mult_Ref_M,myzeroDup2,2);
//				SETCHAR(eMrpView.Auto_Reset,"");
//				SETCHAR(eMrpView.Ex_Cert_Id,"");
//				SETCHAR(eMrpView.Ex_Cert_No_New,"");
//				SETCHAR(eMrpView.Ex_Cert_Dt,"");
//				SETCHAR(eMrpView.Milit_Id,"");
//				SETBCD(eMrpView.Insp_Int,"0",0);
//				SETCHAR(eMrpView.Co_Product,"");
//				SETCHAR(eMrpView.Plan_Strgp,"");
//				//SETCHAR(eMrpView.Sloc_Exprc,store_locDup);
//				//SETCHAR(eMrpView.Sloc_Exprc,"");
//				SETCHAR(eMrpView.Cc_Fixed,"");
//				SETCHAR(eMrpView.Qm_Authgrp,"");
//				SETCHAR(eMrpView.Task_List_Type,"");
//				SETCHAR(eMrpView.Prodprof,"");
//				SETCHAR(eMrpView.Safty_T_Id,"");
//				SETNUM(eMrpView.Safetytime,"00");
//				SETCHAR(eMrpView.Plord_Ctrl,"");
//				SETCHAR(eMrpView.Batchentry,"");
//				SETDATE(eMrpView.Pvalidfrom,"");
//				SETCHAR(eMrpView.Matfrgtgrp,"");
//				SETCHAR(eMrpView.Prodverscs,"");
//				SETCHAR(eMrpView.Mat_Cfop,"");
//				SETCHAR(eMrpView.Eu_List_No,"");
//				SETCHAR(eMrpView.Eu_Mat_Grp,"");
//				SETCHAR(eMrpView.Cas_No,"");
//				SETCHAR(eMrpView.Prodcom_No,"");
//				SETCHAR(eMrpView.Ctrl_Code,"");
//				SETCHAR(eMrpView.Jit_Relvt,"");
//				SETCHAR(eMrpView.Mat_Grp_Trans,"");
//				SETCHAR(eMrpView.Handlg_Grp,"");
//				SETCHAR(eMrpView.Supply_Area,"");
//				SETCHAR(eMrpView.Fair_Share_Rule,"");
//				SETCHAR(eMrpView.Push_Distrib,"");
//				SETBCD(eMrpView.Deploy_Horiz,"0",0);
//				SETBCD(eMrpView.Min_Lot_Size,myzeroDup3,3);
//				SETBCD(eMrpView.Max_Lot_Size,myzeroDup3,3);
//				SETBCD(eMrpView.Fix_Lot_Size,myzeroDup3,3);
//				SETBCD(eMrpView.Lot_Increment,myzeroDup3,3);
//				SETCHAR(eMrpView.Prod_Conv_Type,"");
//				SETCHAR(eMrpView.Distr_Prof,"");
//				SETCHAR(eMrpView.Period_Profile_Safety_Time,"");
//				SETCHAR(eMrpView.Fxd_Price,"");
//				SETCHAR(eMrpView.Avail_Check_All_Proj_Segments,"");
//				SETCHAR(eMrpView.Overallprf,"");
//				SETCHAR(eMrpView.Mrp_Relevancy_Dep_Requirements,"");
//				SETBCD(eMrpView.Min_Safety_Stk,myzeroDup2,2);
//				SETCHAR(eMrpView.No_Costing,"");
//				SETCHAR(eMrpView.Unit_Group,"");
//				SETCHAR(eMrpView.Follow_Up_External,"");
//				SETCHAR(eMrpView.Follow_Up_Guid,"");
//				SETCHAR(eMrpView.Follow_Up_Version,"");
//				SETCHAR(eMrpView.Refmatcons_External,"");
//				SETCHAR(eMrpView.Refmatcons_Guid,"");
//				SETCHAR(eMrpView.Refmatcons_Version,"");
//				SETCHAR(eMrpView.Rotation_Date,"");
//				SETCHAR(eMrpView.Original_Batch_Flag,"");
//				SETCHAR(eMrpView.Original_Batch_Ref_Material,"");
//				SETCHAR(eMrpView.Original_Batch_Ref_Material_E,"");
//				SETCHAR(eMrpView.Original_Batch_Ref_Material_V,"");
//				SETCHAR(eMrpView.Original_Batch_Ref_Material_G,"");
//
//				SETCHAR(eMrpViewx.Plant,plantcode);
//				SETCHAR(eMrpViewx.Del_Flag,"");
//				SETCHAR(eMrpViewx.Crit_Part,"");
//				SETCHAR(eMrpViewx.Pur_Group,"");
//				SETCHAR(eMrpViewx.Mrpprofile,"");
//				SETCHAR(eMrpViewx.Plnd_Delry,"");
//				SETCHAR(eMrpViewx.Assy_Scrap,"");
//				SETCHAR(eMrpViewx.Safety_Stk,"");
//				SETCHAR(eMrpViewx.Minlotsize,"");
//				SETCHAR(eMrpViewx.Maxlotsize,"");
//				SETCHAR(eMrpViewx.Round_Val,"");
//				SETCHAR(eMrpViewx.Ord_Costs,"");
//				SETCHAR(eMrpViewx.Stor_Costs,"");
//
//				SETCHAR(eMrpViewx.Discontinu,"");
//				SETCHAR(eMrpViewx.Eff_O_Day,"");
//				SETCHAR(eMrpViewx.Follow_Up,"");
//				SETCHAR(eMrpViewx.Backflush,"");
//				SETCHAR(eMrpViewx.Production_Scheduler,"");
//				SETCHAR(eMrpViewx.Proc_Time,"");
//				SETCHAR(eMrpViewx.Setuptime,"");
//				SETCHAR(eMrpViewx.Interop,"");
//				SETCHAR(eMrpViewx.Base_Qty,"");
//				SETCHAR(eMrpViewx.Inhseprodt,"");
//				SETCHAR(eMrpViewx.Stgeperiod,"");
//				SETCHAR(eMrpViewx.Stge_Pd_Un,"");
//				SETCHAR(eMrpViewx.Stge_Pd_Un_Iso,"");
//				SETCHAR(eMrpViewx.Over_Tol,"");
//				SETCHAR(eMrpViewx.Unlimited,"");
//				SETCHAR(eMrpViewx.Under_Tol,"");
//				SETCHAR(eMrpViewx.Replentime,"");
//				SETCHAR(eMrpViewx.Replace_Pt,"");
//				SETCHAR(eMrpViewx.Loadinggrp,"");
//				SETCHAR(eMrpViewx.Batch_Mgmt,"");
//				SETCHAR(eMrpViewx.Serv_Level,"");
//				SETCHAR(eMrpViewx.Fy_Variant,"");
//				SETCHAR(eMrpViewx.Corr_Fact,"");
//				SETCHAR(eMrpViewx.Setup_Time,"");
//				SETCHAR(eMrpViewx.Base_Qty_Plan,"");
//				SETCHAR(eMrpViewx.Ship_Proc_Time,"");
//				SETCHAR(eMrpViewx.Sup_Source,"");
//				SETCHAR(eMrpViewx.Auto_P_Ord,"");
//				SETCHAR(eMrpViewx.Sourcelist,"");
//				SETCHAR(eMrpViewx.Comm_Code,"");
//				SETCHAR(eMrpViewx.Countryori,"");
//				SETCHAR(eMrpViewx.Countryori_Iso,"");
//				SETCHAR(eMrpViewx.Regionorig,"");
//				SETCHAR(eMrpViewx.Comm_Co_Un,"");
//				SETCHAR(eMrpViewx.Comm_Co_Un_Iso,"");
//				SETCHAR(eMrpViewx.Expimpgrp,"");
//				SETCHAR(eMrpViewx.Pl_Ti_Fncve,"");
//				SETCHAR(eMrpViewx.Consummode,"");
//				SETCHAR(eMrpViewx.Bwd_Cons,"");
//				SETCHAR(eMrpViewx.Fwd_Cons,"");
//				SETCHAR(eMrpViewx.Bom_Usage,"");
//				SETCHAR(eMrpViewx.Planlistgrp,"");
//				SETCHAR(eMrpViewx.Planlistcnt,"");
//				SETCHAR(eMrpViewx.Specprocty,"");
//				SETCHAR(eMrpViewx.Prod_Unit,"");
//				SETCHAR(eMrpViewx.Prod_Unit_Iso,"");
//				//SETCHAR(eMrpViewx.Iss_St_Loc,"X");
//				//SETCHAR(eMrpViewx.Iss_St_Loc,"");
//				SETCHAR(eMrpViewx.Comp_Scrap,"");
//				SETCHAR(eMrpViewx.Cycle_Time,"");
//				SETCHAR(eMrpViewx.Covprofile,"");
//				SETCHAR(eMrpViewx.Cc_Ph_Inv,"");
//				SETCHAR(eMrpViewx.Serno_Prof,"");
//				SETCHAR(eMrpViewx.Neg_Stocks,"");
//				SETCHAR(eMrpViewx.Qm_Rgmts,"");
//				SETCHAR(eMrpViewx.Plng_Cycle,"");
//				SETCHAR(eMrpViewx.Round_Prof,"");
//				SETCHAR(eMrpViewx.Refmatcons,"");
//				SETCHAR(eMrpViewx.D_To_Ref_M,"");
//				SETCHAR(eMrpViewx.Mult_Ref_M,"");
//				SETCHAR(eMrpViewx.Auto_Reset,"");
//				SETCHAR(eMrpViewx.Ex_Cert_Id,"");
//				SETCHAR(eMrpViewx.Ex_Cert_No_New,"");
//				SETCHAR(eMrpViewx.Ex_Cert_Dt,"");
//				SETCHAR(eMrpViewx.Milit_Id,"");
//				SETCHAR(eMrpViewx.Insp_Int,"");
//				SETCHAR(eMrpViewx.Co_Product,"");
//				SETCHAR(eMrpViewx.Plan_Strgp,"");
//				//SETCHAR(eMrpViewx.Sloc_Exprc,"X");
//				//SETCHAR(eMrpViewx.Sloc_Exprc,"");
//				SETCHAR(eMrpViewx.Cc_Fixed,"");
//				SETCHAR(eMrpViewx.Qm_Authgrp,"");
//				SETCHAR(eMrpViewx.Task_List_Type,"");
//				SETCHAR(eMrpViewx.Prodprof,"");
//				SETCHAR(eMrpViewx.Safty_T_Id,"");
//				SETCHAR(eMrpViewx.Safetytime,"");
//				SETCHAR(eMrpViewx.Plord_Ctrl,"");
//				SETCHAR(eMrpViewx.Batchentry,"");
//				SETCHAR(eMrpViewx.Pvalidfrom,"");
//				SETCHAR(eMrpViewx.Matfrgtgrp,"");
//				SETCHAR(eMrpViewx.Prodverscs,"");
//				SETCHAR(eMrpViewx.Mat_Cfop,"");
//				SETCHAR(eMrpViewx.Eu_List_No,"");
//				SETCHAR(eMrpViewx.Eu_Mat_Grp,"");
//				SETCHAR(eMrpViewx.Cas_No,"");
//				SETCHAR(eMrpViewx.Prodcom_No,"");
//				SETCHAR(eMrpViewx.Ctrl_Code,"");
//				SETCHAR(eMrpViewx.Jit_Relvt,"");
//				SETCHAR(eMrpViewx.Mat_Grp_Trans,"");
//				SETCHAR(eMrpViewx.Handlg_Grp,"");
//				SETCHAR(eMrpViewx.Supply_Area,"");
//				SETCHAR(eMrpViewx.Fair_Share_Rule,"");
//				SETCHAR(eMrpViewx.Push_Distrib,"");
//				SETCHAR(eMrpViewx.Deploy_Horiz,"");
//				SETCHAR(eMrpViewx.Min_Lot_Size,"");
//				SETCHAR(eMrpViewx.Max_Lot_Size,"");
//				SETCHAR(eMrpViewx.Fix_Lot_Size,"");
//				SETCHAR(eMrpViewx.Lot_Increment,"");
//				SETCHAR(eMrpViewx.Prod_Conv_Type,"");
//				SETCHAR(eMrpViewx.Distr_Prof,"");
//				SETCHAR(eMrpViewx.Period_Profile_Safety_Time,"");
//				SETCHAR(eMrpViewx.Fxd_Price,"");
//				SETCHAR(eMrpViewx.Avail_Check_All_Proj_Segments,"");
//				SETCHAR(eMrpViewx.Overallprf,"");
//				SETCHAR(eMrpViewx.Mrp_Relevancy_Dep_Requirements,"");
//				SETCHAR(eMrpViewx.Min_Safety_Stk,"");
//				SETCHAR(eMrpViewx.No_Costing,"");
//				SETCHAR(eMrpViewx.Unit_Group,"");
//				SETCHAR(eMrpViewx.Follow_Up_External,"");
//				SETCHAR(eMrpViewx.Follow_Up_Guid,"");
//				SETCHAR(eMrpViewx.Follow_Up_Version,"");
//				SETCHAR(eMrpViewx.Refmatcons_External,"");
//				SETCHAR(eMrpViewx.Refmatcons_Guid,"");
//				SETCHAR(eMrpViewx.Refmatcons_Version,"");
//				SETCHAR(eMrpViewx.Rotation_Date,"");
//				SETCHAR(eMrpViewx.Original_Batch_Flag,"");
//				SETCHAR(eMrpViewx.Original_Batch_Ref_Material,"");
//				SETCHAR(eMrpViewx.Original_Batch_Ref_Material_E,"");
//				SETCHAR(eMrpViewx.Original_Batch_Ref_Material_V,"");
//				SETCHAR(eMrpViewx.Original_Batch_Ref_Material_G,"");
//
//				SETCHAR(eBapi_Mpgd.Plant,plantcode);
//				SETCHAR(eBapi_Mpgd.Plng_Matl_External,"");
//				SETCHAR(eBapi_Mpgd.Plng_Matl_Guid,"");
//				SETCHAR(eBapi_Mpgd.Plng_Matl_Version,"");
//				SETCHAR(eBapi_Mpgdx.Plant,plantcode);
//				SETCHAR(eBapi_Mpgdx.Plng_Matl_External,"");
//				SETCHAR(eBapi_Mpgdx.Plng_Matl_Guid,"");
//				SETCHAR(eBapi_Mpgdx.Plng_Matl_Version,"");
//
//				SETCHAR(eBapi_Mard.Plant,plantcode);
//				SETCHAR(eBapi_Mard.Stge_Loc,"9005");
//				SETCHAR(eBapi_Mard.Del_Flag,"");
//				SETCHAR(eBapi_Mard.Mrp_Ind,"");
//				SETCHAR(eBapi_Mard.Spec_Proc,"");
//				SETBCD(eBapi_Mard.Reorder_Pt,myzeroDup3,3);
//				SETBCD(eBapi_Mard.Repl_Qty,myzeroDup3,3);
//				SETCHAR(eBapi_Mard.Stge_Bin,"");
//				SETCHAR(eBapi_Mard.Pickg_Area,"");
//				SETFLOAT(&eBapi_Mard.Inv_Corr_Fac,"");
//
//				SETCHAR(eBapi_Mardx.Plant,plantcode);
//				SETCHAR(eBapi_Mardx.Stge_Loc,"9005");
//				SETCHAR(eBapi_Mardx.Del_Flag,"");
//				SETCHAR(eBapi_Mardx.Mrp_Ind,"");
//				SETCHAR(eBapi_Mardx.Spec_Proc,"");
//				SETCHAR(eBapi_Mardx.Reorder_Pt,"");
//				SETCHAR(eBapi_Mardx.Repl_Qty,"");
//				SETCHAR(eBapi_Mardx.Stge_Bin,"");
//				SETCHAR(eBapi_Mardx.Pickg_Area,"");
//				SETCHAR(eBapi_Mardx.Inv_Corr_Fac,"");
//
//				SETCHAR(eAccView.Val_Area,plantcode);
//				SETCHAR(eAccView.Val_Type,"");
//				SETCHAR(eAccView.Del_Flag,"");
//				SETBCD(eAccView.Price_Unit,"",0);
//				SETCHAR(eAccView.Pr_Ctrl_Pp,"");
//				SETBCD(eAccView.Mov_Pr_Pp,myzeroDup4,4);
//				SETBCD(eAccView.Std_Pr_Pp,myzeroDup4,4);
//				SETBCD(eAccView.Pr_Unit_Pp,"0",1);
//				SETCHAR(eAccView.Vclass_Pp,"");
//				SETCHAR(eAccView.Pr_Ctrl_Py,"");
//				SETBCD(eAccView.Mov_Pr_Py,myzeroDup4,4);
//				SETBCD(eAccView.Std_Pr_Py,myzeroDup4,4);
//				SETCHAR(eAccView.Vclass_Py,"");
//				SETBCD(eAccView.Pr_Unit_Py,"0",0);
//				SETBCD(eAccView.Future_Pr,myzeroDup4,4);
//				SETDATE(eAccView.Valid_From,"");
//				SETBCD(eAccView.Taxprice_1,myzeroDup4,4);
//				SETBCD(eAccView.Commprice1,myzeroDup4,4);
//				SETBCD(eAccView.Taxprice_3,myzeroDup4,4);
//				SETBCD(eAccView.Commprice3,myzeroDup4,4);
//				SETBCD(eAccView.Plnd_Price,myzeroDup4,4);
//				SETBCD(eAccView.Plndprice1,myzeroDup4,4);
//				SETBCD(eAccView.Plndprice2,myzeroDup4,4);
//				SETBCD(eAccView.Plndprice3,myzeroDup4,4);
//				SETDATE(eAccView.Plndprdate1,"");
//				SETDATE(eAccView.Plndprdate2,"");
//				SETDATE(eAccView.Plndprdate3,"");
//				SETCHAR(eAccView.Lifo_Fifo,"");
//				SETCHAR(eAccView.Poolnumber,"");
//				SETBCD(eAccView.Taxprice_2,myzeroDup4,4);
//				SETBCD(eAccView.Commprice2,myzeroDup4,4);
//				SETNUM(eAccView.Deval_Ind,"00");
//				SETCHAR(eAccView.Ml_Active,"");
//				SETCHAR(eAccView.Ml_Settle,"");
//				SETCHAR(eAccView.Orig_Mat,"X");
//				SETCHAR(eAccView.Vm_So_Stk,"");
//				SETCHAR(eAccView.Vm_P_Stock,"");
//				SETCHAR(eAccView.Matl_Usage,"");
//				SETCHAR(eAccView.In_House,"");
//				SETBCD(eAccView.Tax_Cml_Un,"0",0);
//
//				SETCHAR(eAccViewx.Val_Area,plantcode);
//				SETCHAR(eAccViewx.Val_Type,"");
//				SETCHAR(eAccViewx.Del_Flag,"");
//				SETCHAR(eAccViewx.Price_Unit,"");
//				SETCHAR(eAccViewx.Pr_Ctrl_Pp,"");
//				SETCHAR(eAccViewx.Mov_Pr_Pp,"");
//				SETCHAR(eAccViewx.Std_Pr_Pp,"");
//				SETCHAR(eAccViewx.Pr_Unit_Pp,"");
//				SETCHAR(eAccViewx.Vclass_Pp,"");
//				SETCHAR(eAccViewx.Pr_Ctrl_Py,"");
//				SETCHAR(eAccViewx.Mov_Pr_Py,"");
//				SETCHAR(eAccViewx.Std_Pr_Py,"");
//				SETCHAR(eAccViewx.Vclass_Py,"");
//				SETCHAR(eAccViewx.Pr_Unit_Py,"");
//				SETCHAR(eAccViewx.Future_Pr,"");
//				SETCHAR(eAccViewx.Valid_From,"");
//				SETCHAR(eAccViewx.Taxprice_1,"");
//				SETCHAR(eAccViewx.Commprice1,"");
//				SETCHAR(eAccViewx.Taxprice_3,"");
//				SETCHAR(eAccViewx.Commprice3,"");
//				SETCHAR(eAccViewx.Plnd_Price,"");
//				SETCHAR(eAccViewx.Plndprice1,"");
//				SETCHAR(eAccViewx.Plndprice2,"");
//				SETCHAR(eAccViewx.Plndprice3,"");
//				SETCHAR(eAccViewx.Plndprdate1,"");
//				SETCHAR(eAccViewx.Plndprdate2,"");
//				SETCHAR(eAccViewx.Plndprdate3,"");
//				SETCHAR(eAccViewx.Lifo_Fifo,"");
//				SETCHAR(eAccViewx.Poolnumber,"");
//				SETCHAR(eAccViewx.Taxprice_2,"");
//				SETCHAR(eAccViewx.Commprice2,"");
//				SETCHAR(eAccViewx.Deval_Ind,"");
//				SETCHAR(eAccViewx.Ml_Active,"");
//				SETCHAR(eAccViewx.Ml_Settle,"");
//				SETCHAR(eAccViewx.Orig_Mat,"X");
//				SETCHAR(eAccViewx.Vm_So_Stk,"");
//				SETCHAR(eAccViewx.Vm_P_Stock,"");
//				SETCHAR(eAccViewx.Matl_Usage,"");
//				SETCHAR(eAccViewx.In_House,"");
//				SETCHAR(eAccViewx.Tax_Cml_Un,"");
//
//				SETCHAR(tBapi_Makt->Langu,"EN");
//				SETCHAR(tBapi_Makt->Langu_Iso,"EN");
//				SETCHAR(tBapi_Makt->Del_Flag,"");
//
//				SETBCD(tBapi_Marm->Numerator,"1",0);
//				SETBCD(tBapi_Marm->Denominatr,"1",0);
//				SETCHAR(tBapi_Marm->Ean_Upc,"");
//				SETCHAR(tBapi_Marm->Ean_Cat,"");
//				SETCHAR(tBapi_Marm->Length,"");
//				SETCHAR(tBapi_Marm->Width,"");
//				SETCHAR(tBapi_Marm->Height,"");
//				SETCHAR(tBapi_Marm->Unit_Dim,"");
//				SETCHAR(tBapi_Marm->Unit_Dim_Iso,"");
//				SETCHAR(tBapi_Marm->Del_Flag,"");
//				SETCHAR(tBapi_Marm->Sub_Uom,"");
//				SETCHAR(tBapi_Marm->Sub_Uom_Iso,"");
//				SETCHAR(tBapi_Marm->Gtin_Variant,"");
//
//				SETCHAR(tBapi_Marmx->Numerator,"X");
//				SETCHAR(tBapi_Marmx->Denominatr,"X");
//				SETCHAR(tBapi_Marmx->Ean_Upc,"");
//				SETCHAR(tBapi_Marmx->Ean_Cat,"");
//				SETCHAR(tBapi_Marmx->Length,"");
//				SETCHAR(tBapi_Marmx->Width,"");
//				SETCHAR(tBapi_Marmx->Height,"");
//				SETCHAR(tBapi_Marmx->Unit_Dim,"");
//				SETCHAR(tBapi_Marmx->Unit_Dim_Iso,"");
//				SETCHAR(tBapi_Marmx->Sub_Uom,"");
//				SETCHAR(tBapi_Marmx->Sub_Uom_Iso,"");
//				SETCHAR(tBapi_Marmx->Gtin_Variant,"");
//
//
//				SETCHAR(tBAPIE1PAREX3->STRUCTURE,"");//BAPI_TE_MARA
//				SETCHAR(tBAPIE1PAREX3->VALUEPART1,"");//part_noDupDes
//				SETCHAR(tBAPIE1PAREX3->VALUEPART2,"");
//				SETCHAR(tBAPIE1PAREX3->VALUEPART3,"");
//				SETCHAR(tBAPIE1PAREX3->VALUEPART4,"");
//
//				SETCHAR(tBAPIE1PAREXX3->STRUCTURE,"");//BAPI_TE_MARAX
//				SETCHAR(tBAPIE1PAREXX3->VALUEPART1,"");//part_noDupDesx
//				SETCHAR(tBAPIE1PAREXX3->VALUEPART2,"");
//				SETCHAR(tBAPIE1PAREXX3->VALUEPART3,"");
//				SETCHAR(tBAPIE1PAREXX3->VALUEPART4,"");
//
//				RfcRc = zbapi_material_savedata_mrp(hRfc,&eBapiMatHead,&eBasicView,&eBasicViewx,&eMrpView,&eMrpViewx,&eBapi_Mpgd,&eBapi_Mpgdx,&eBapi_Mard,&eBapi_Mardx,&eAccView,&eAccViewx,&eRmmg1_Aennr,&eBapiret2,thBapi_Makt,thBapi_Marm,thBapi_Marmx,thBAPIE1PAREX3,thBAPIE1PAREXX3,xException);
//
//				switch (RfcRc)
//				{
//					case RFC_OK:
//						//sprintf(sap_msg,"%.*s:",sizeof(sap_msg),eBapiret2.Message);
//						//GETCHAR(eBapiret2.Message,sap_msg);
//
//						printf("\nMessage for Material %s create Other view extend:%s",part_noDup,eBapiret2.Message); fflush(stdout);
//						fprintf(fsuccess,"\nMessage for Material %s create Other view extend:%s",part_noDup,eBapiret2.Message); fflush(fsuccess);
//
//
//						sprintf(a,"The material %s has been created or extended",part_noDup);
//						
//						if (tc_strstr(eBapiret2.Message,a)!=NULL)
//						{
//
//							sprintf(Error_message,"The material %s has been created or extended",part_noDup);
//							tc_strcpy(MATstatus,"Y");
//							Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
//
//						}
//						else
//						{
//
//							tc_strcpy(MATstatus,"N");
//							tc_strcpy(Error_message,eBapiret2.Message);
//							Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
//
//						}
//
//
//
//						break;
//					case RFC_EXCEPTION:
//						printf("\nRFC EXCEPTION: %s",xException); fflush(stdout);
//						break;
//					case RFC_SYS_EXCEPTION:
//						printf("\nSystem Exception Raised!!!"); fflush(stdout);
//						break;
//					case RFC_FAILURE:
//						printf("\nFailure!!!"); fflush(stdout);
//						break;
//					default:
//						printf("\nOther Failure!"); fflush(stdout);
//						break;
//				}
//				if(ItDelete(thBapi_Makt) != 0) rfc_error("ItDelete thBapi_Makt");
//				if(ItDelete(thBapi_Marm) != 0) rfc_error("ItDelete tBapi_Marm");
//				if(ItDelete(thBapi_Marmx) != 0) rfc_error("ItDelete thBapi_Marmx");
//				if(ItDelete(thBAPIE1PAREX3) != 0) rfc_error("ItDelete thBAPIE1PAREX3");
//				if(ItDelete(thBAPIE1PAREXX3) != 0)	rfc_error("ItDelete thBAPIE1PAREXX3");
//				/*sleep(5);*/
//				RfcClose(hRfc);
//
			}
			if (apl_dml_flag == 2) /*all view will created*/
			{
				
				create_mat_all_view(); //POCHANGE
				
				printf("\neBapiMatHead.Material:		%s",part_noDup); fflush(stdout);
				printf("\neBapiMatHead.Matl_Type:		%s",mat_type);
				printf("\neBapiMatHead.Ind_Sector:	%s","M");
				printf("\neBapiMatHead.Basic_View:	%s","X");		/*basic view*/
				printf("\neBasicView.Base_Uom:		%s",meas_unit);
				printf("\neBasicView.Base_Uom_Iso:	%s",meas_unit);
				printf("\ntBapi_Marm->Alt_Unit:		%s",meas_unit);
				printf("\ntBapi_Marm->Alt_Unit_Iso:	%s",meas_unit);
				printf("\ntBapi_Marmx->Alt_Unit:		%s",meas_unit);
				printf("\ntBapi_Marmx->Alt_Unit_Iso:	%s",meas_unit);
				printf("\ntBapi_Makt->Matl_Desc:		%s",descDup);
				printf("\neBasicView.Document:		%s",doc_noDup);
				printf("\neBasicView.Doc_Type:		%s",dwg_typeDup);
				printf("\neBasicView.Doc_Vers:		%s",dwg_revDup);
				printf("\neBasicView.No_Sheets:		%s",sheet_noDup);
				printf("\neBasicView.Old_Mat_No:		%s",OldMatNoDup);
				printf("\neBasicView.Net_Weight:		%s",net_wtDup);
				printf("\ntBapi_Marm->Gross_Wt:		%s",gross_wt);
				printf("\neBasicView.Unit_Of_Wt:		%s",unit_wt);
				printf("\neBasicView.Unit_Of_Wt_Iso:	%s",unit_wt);
				printf("\ntBapi_Marm->Unit_Of_Wt:		%s",unit_wt);
				printf("\ntBapi_Marm->Unit_Of_Wt_Iso:	%s",unit_wt);
				printf("\ntBapi_Marm->Volume:			%s",volume);
				printf("\ntBapi_Marm->VolumeUnit:		%s",vol_unit);
				printf("\ntBapi_Marm->VolumeUnit_Iso:	%s",vol_unit);
				printf("\neBasicView.Size_Dim:		%s",sizeDup);
				printf("\neBasicView.Matl_Group:		%s",material_group);
				printf("\neBasicView.Division:		%s",basic_division);
				printf("\neBapiMatHead.Mrp_View:		%s","X");	/*mrp view*/
				printf("\neMrpView.Mrp_Group:			%s",mrp_grp);
				printf("\neMrpView.Abc_Id:			%s",abc_ind);
				printf("\neMrpView.Pur_Status:		%s",mm_pp_status);
				printf("\neMrpView.Mrp_Type:			%s",mrp_type);
				printf("\neMrpView.Reorder_Pt:		%s",reord_pt);
				printf("\neMrpView.Quotausage:		%s",quota_arrangement_usage);
				printf("\neMrpView.Mrp_Ctrler:		%s",mrp_controller);
				printf("\neMrpView.Lotsizekey:		%s",lot_size_key);
				printf("\neMrpView.Fixed_Lot:			%s",fixed_lot_size);
				printf("\neMrpView.Max_Stock:			%s",max_stlvl);
				printf("\neMrpView.Proc_Type:			%s",proc_type);
				printf("\neMrpView.Spproctype:		%s",spl_proc_key);
				printf("\neMrpView.Bulk_Mat:			%s",blk_ind);
				printf("\neMrpView.Sm_Key:			%s",sched_mar_key);
				printf("\neMrpView.Ppc_Pl_Cal:		%s",plan_calendar);
				printf("\neMrpView.Grp_Reqmts:		%s",req_grp);
				printf("\neMrpView.Period_Ind:		%s",period_ind);
				printf("\neMrpView.Mixed_Mrp:			%s",mixedmrp);
				printf("\neMrpView.Availcheck:		%s",avail_chk);
				printf("\neBapi_Mpgd.Plng_Matl:		%s",splan_mat);
				printf("\neBapi_Mpgd.Plng_Plant:		%s",splan_plant);
				printf("\neBapi_Mpgd.Convfactor:		%s",splan_conv_fact);
				printf("\neMrpView.Alternative_Bom:	%s",alternativb);
				printf("\neMrpView.Dep_Req_Id:		%s",ind_collect);
				printf("\neMrpView.Rep_Manuf:			%s",rep_mfg_in);
				printf("\neMrpView.Repmanprof:		%s",rep_mfg);
				printf("\neMrpView.Determ_Grp:		%s",stock_det_group);
				printf("\neBapiMatHead.Storage_View:	%s","X");	/*store view*/
				printf("\neMrpView.Issue_Unit:		%s",uoissue);
				printf("\neMrpView.Issue_Unit_Iso:	%s",uoissue);
				printf("\neMrpView.Profit_Ctr:		%s",profit_centre_sap);		/*profit_centre=0001111010*/
				printf("\neBapiMatHead.Quality_View:	%s","X");	/*quality view*/
				printf("\neMrpView.Ind_Post_To_Insp_Stock:%s",qua_ins_ind);
				printf("\neMrpView.Doc_Reqd:			%s",doc_req);
				printf("\neMrpView.Gr_Pr_Time:		%s",grptime);
				printf("\neBasicView.Catprofile:		%s",catalog_prof);
				printf("\neBasicView.Qm_Procmnt:		%s",qm_proc_ind);
				printf("\neMrpView.Ctrl_Key:			%s",control_key);
				printf("\neMrpView.Cert_Type:			%s",certificate_type);
				printf("\neBapiMatHead.Account_View:	%s","X"); /*accounting view */
				printf("\neAccView.Val_Cat:			%s",valuation_cat);
				printf("\neAccView.Val_Class:			%s",val_class);
				printf("\neAccView.Price_Ctrl:		%s",price_con);
				printf("\neAccView.Std_Price:			%s",std_price);
				printf("\neAccView.Moving_Pr:			%s",moving_avg_price);
				printf("\neBapiMatHead.Cost_View:		%s","X");/*lvl cost view */
				printf("\neAccView.Mat_Origin:		%s",mat_origin);
				printf("\neAccView.Orig_Group:		%s",origin_group);
				printf("\neMrpView.Lot_Size:			%s",cost_lot_size);
				printf("\neAccView.Overhead_Grp:		%s",overhd_grp);
				printf("\neMrpView.Variance_Key:		%s",variance_key);
				printf("\neAccView.Qty_Struct:		%s",with_quantity_structure);
				printf("\neMrpView.Split_Ind:			%s",costing_split_valuation);
				printf("\neMrpViewx.Split_Ind:		%s","");/*Please make it as X*/
				printf("\neRmmg1_Aennr.Aennr:			%s",dml_no_arg);
				printf("\npart_noDupDes:			%s",part_noDupDes);
				printf("\npart_noDupDes:			%s",part_noDupDesx); fflush(stdout);

				fprintf(fsuccess,"\neBapiMatHead.Material:		%s",part_noDup); fflush(fsuccess);
				fprintf(fsuccess,"\neBapiMatHead.Matl_Type:		%s",mat_type);
				fprintf(fsuccess,"\neBapiMatHead.Ind_Sector:	%s","M");
				fprintf(fsuccess,"\neBapiMatHead.Basic_View:	%s","X");		/*basic view*/
				fprintf(fsuccess,"\neBasicView.Base_Uom:		%s",meas_unit);
				fprintf(fsuccess,"\neBasicView.Base_Uom_Iso:	%s",meas_unit);
				fprintf(fsuccess,"\ntBapi_Marm->Alt_Unit:		%s",meas_unit);
				fprintf(fsuccess,"\ntBapi_Marm->Alt_Unit_Iso:	%s",meas_unit);
				fprintf(fsuccess,"\ntBapi_Marmx->Alt_Unit:		%s",meas_unit);
				fprintf(fsuccess,"\ntBapi_Marmx->Alt_Unit_Iso:	%s",meas_unit);
				fprintf(fsuccess,"\ntBapi_Makt->Matl_Desc:		%s",descDup);
				fprintf(fsuccess,"\neBasicView.Document:		%s",doc_noDup);
				fprintf(fsuccess,"\neBasicView.Doc_Type:		%s",dwg_typeDup);
				fprintf(fsuccess,"\neBasicView.Doc_Vers:		%s",dwg_revDup);
				fprintf(fsuccess,"\neBasicView.No_Sheets:		%s",sheet_noDup);
				fprintf(fsuccess,"\neBasicView.Old_Mat_No:		%s",OldMatNoDup);
				fprintf(fsuccess,"\neBasicView.Net_Weight:		%s",net_wtDup);
				fprintf(fsuccess,"\ntBapi_Marm->Gross_Wt:		%s",gross_wt);
				fprintf(fsuccess,"\neBasicView.Unit_Of_Wt:		%s",unit_wt);
				fprintf(fsuccess,"\neBasicView.Unit_Of_Wt_Iso:	%s",unit_wt);
				fprintf(fsuccess,"\ntBapi_Marm->Unit_Of_Wt:		%s",unit_wt);
				fprintf(fsuccess,"\ntBapi_Marm->Unit_Of_Wt_Iso:	%s",unit_wt);
				fprintf(fsuccess,"\ntBapi_Marm->Volume:			%s",volume);
				fprintf(fsuccess,"\ntBapi_Marm->VolumeUnit:		%s",vol_unit);
				fprintf(fsuccess,"\ntBapi_Marm->VolumeUnit_Iso:	%s",vol_unit);
				fprintf(fsuccess,"\neBasicView.Size_Dim:		%s",sizeDup);
				fprintf(fsuccess,"\neBasicView.Matl_Group:		%s",material_group);
				fprintf(fsuccess,"\neBasicView.Division:		%s",basic_division);
				fprintf(fsuccess,"\neBapiMatHead.Mrp_View:		%s","X");	/*mrp view*/
				fprintf(fsuccess,"\neMrpView.Mrp_Group:			%s",mrp_grp);
				fprintf(fsuccess,"\neMrpView.Abc_Id:			%s",abc_ind);
				fprintf(fsuccess,"\neMrpView.Pur_Status:		%s",mm_pp_status);
				fprintf(fsuccess,"\neMrpView.Mrp_Type:			%s",mrp_type);
				fprintf(fsuccess,"\neMrpView.Reorder_Pt:		%s",reord_pt);
				fprintf(fsuccess,"\neMrpView.Quotausage:		%s",quota_arrangement_usage);
				fprintf(fsuccess,"\neMrpView.Mrp_Ctrler:		%s",mrp_controller);
				fprintf(fsuccess,"\neMrpView.Lotsizekey:		%s",lot_size_key);
				fprintf(fsuccess,"\neMrpView.Fixed_Lot:			%s",fixed_lot_size);
				fprintf(fsuccess,"\neMrpView.Max_Stock:			%s",max_stlvl);
				fprintf(fsuccess,"\neMrpView.Proc_Type:			%s",proc_type);
				fprintf(fsuccess,"\neMrpView.Spproctype:		%s",spl_proc_key);
				fprintf(fsuccess,"\neMrpView.Bulk_Mat:			%s",blk_ind);
				fprintf(fsuccess,"\neMrpView.Sm_Key:			%s",sched_mar_key);
				fprintf(fsuccess,"\neMrpView.Ppc_Pl_Cal:		%s",plan_calendar);
				fprintf(fsuccess,"\neMrpView.Grp_Reqmts:		%s",req_grp);
				fprintf(fsuccess,"\neMrpView.Period_Ind:		%s",period_ind);
				fprintf(fsuccess,"\neMrpView.Mixed_Mrp:			%s",mixedmrp);
				fprintf(fsuccess,"\neMrpView.Availcheck:		%s",avail_chk);
				fprintf(fsuccess,"\neBapi_Mpgd.Plng_Matl:		%s",splan_mat);
				fprintf(fsuccess,"\neBapi_Mpgd.Plng_Plant:		%s",splan_plant);
				fprintf(fsuccess,"\neBapi_Mpgd.Convfactor:		%s",splan_conv_fact);
				fprintf(fsuccess,"\neMrpView.Alternative_Bom:	%s",alternativb);
				fprintf(fsuccess,"\neMrpView.Dep_Req_Id:		%s",ind_collect);
				fprintf(fsuccess,"\neMrpView.Rep_Manuf:			%s",rep_mfg_in);
				fprintf(fsuccess,"\neMrpView.Repmanprof:		%s",rep_mfg);
				fprintf(fsuccess,"\neMrpView.Determ_Grp:		%s",stock_det_group);
				fprintf(fsuccess,"\neBapiMatHead.Storage_View:	%s","X");	/*store view*/
				fprintf(fsuccess,"\neMrpView.Issue_Unit:		%s",uoissue);
				fprintf(fsuccess,"\neMrpView.Issue_Unit_Iso:	%s",uoissue);
				fprintf(fsuccess,"\neMrpView.Profit_Ctr:		%s",profit_centre_sap);		/*profit_centre=0001111010*/
				fprintf(fsuccess,"\neBapiMatHead.Quality_View:	%s","X");	/*quality view*/
				fprintf(fsuccess,"\neMrpView.Ind_Post_To_Insp_Stock:%s",qua_ins_ind);
				fprintf(fsuccess,"\neMrpView.Doc_Reqd:			%s",doc_req);
				fprintf(fsuccess,"\neMrpView.Gr_Pr_Time:		%s",grptime);
				fprintf(fsuccess,"\neBasicView.Catprofile:		%s",catalog_prof);
				fprintf(fsuccess,"\neBasicView.Qm_Procmnt:		%s",qm_proc_ind);
				fprintf(fsuccess,"\neMrpView.Ctrl_Key:			%s",control_key);
				fprintf(fsuccess,"\neMrpView.Cert_Type:			%s",certificate_type);
				fprintf(fsuccess,"\neBapiMatHead.Account_View:	%s","X"); /*accounting view */
				fprintf(fsuccess,"\neAccView.Val_Cat:			%s",valuation_cat);
				fprintf(fsuccess,"\neAccView.Val_Class:			%s",val_class);
				fprintf(fsuccess,"\neAccView.Price_Ctrl:		%s",price_con);
				fprintf(fsuccess,"\neAccView.Std_Price:			%s",std_price);
				fprintf(fsuccess,"\neAccView.Moving_Pr:			%s",moving_avg_price);
				fprintf(fsuccess,"\neBapiMatHead.Cost_View:		%s","X");/*lvl cost view */
				fprintf(fsuccess,"\neAccView.Mat_Origin:		%s",mat_origin);
				fprintf(fsuccess,"\neAccView.Orig_Group:		%s",origin_group);
				fprintf(fsuccess,"\neMrpView.Lot_Size:			%s",cost_lot_size);
				fprintf(fsuccess,"\neAccView.Overhead_Grp:		%s",overhd_grp);
				fprintf(fsuccess,"\neMrpView.Variance_Key:		%s",variance_key);
				fprintf(fsuccess,"\neAccView.Qty_Struct:		%s",with_quantity_structure);
				fprintf(fsuccess,"\neMrpView.Split_Ind:			%s",costing_split_valuation);
				fprintf(fsuccess,"\neMrpViewx.Split_Ind:		%s","");/*Please make it as X*/
				fprintf(fsuccess,"\neRmmg1_Aennr.Aennr:			%s",dml_no_arg);
				fprintf(fsuccess,"\npart_noDupDes:			%s",part_noDupDes);
				fprintf(fsuccess,"\npart_noDupDes:			%s",part_noDupDesx); fflush(fsuccess);

				printf("\nCreating ALL Views..."); fflush(stdout);
//
//				hRfc = BapiLogon();
//				thBapi_Makt = ITAB_NULL;
//				thBapi_Marm = ITAB_NULL;
//				thBapi_Marmx = ITAB_NULL;
//				thBAPIE1PAREX3 = ITAB_NULL;
//				thBAPIE1PAREXX3 = ITAB_NULL;
//
//				if (thBapi_Makt==ITAB_NULL)
//				{
//					thBapi_Makt = ItCreate("MATERIALDESCRIPTION",sizeof(BAPI_MAKT),0,0);
//					if (thBapi_Makt==ITAB_NULL) rfc_error("ItCreate MATERIALDESCRIPTION");
//				}
//				else if (ItFree(thBapi_Makt) != 0) rfc_error("ItFree MATERIALDESCRIPTION");
//
//				if (thBapi_Marm==ITAB_NULL)
//				{
//					 thBapi_Marm = ItCreate("UNITSOFMEASURE",sizeof(BAPI_MARM),0,0);
//					 if (thBapi_Marm==ITAB_NULL) rfc_error("ItCreate UNITSOFMEASURE");
//				}
//				else if (ItFree(thBapi_Marm)!= 0) rfc_error("ItFree UNITSOFMEASURE");
//
//				if (thBapi_Marmx==ITAB_NULL)
//				{
//					 thBapi_Marmx = ItCreate("UNITSOFMEASUREX",sizeof(BAPI_MARMX),0,0);
//					if (thBapi_Marmx==ITAB_NULL) rfc_error("ItCreate UNITSOFMEASUREX");
//				}
//				else if (ItFree(thBapi_Marmx)!= 0) rfc_error("ItFree UNITSOFMEASUREX");
//
//				if (thBAPIE1PAREX3==ITAB_NULL)
//				{
//					thBAPIE1PAREX3 = ItCreate("EXTENSIONIN",sizeof(BAPIE1PAREX3),0,0);
//					if (thBAPIE1PAREX3==ITAB_NULL)
//						rfc_error("ItCreate EXTENSIONIN");
//				}
//				else
//				{
//					if (ItFree(thBAPIE1PAREX3)!= 0)
//						rfc_error("ItFree EXTENSIONIN");
//				}
//
//				if (thBAPIE1PAREXX3==ITAB_NULL)
//				{
//					thBAPIE1PAREXX3 = ItCreate("EXTENSIONINX",sizeof(BAPIE1PAREXX3),0,0);
//					if (thBAPIE1PAREXX3==ITAB_NULL)
//						rfc_error("ItCreate EXTENSIONINX");
//				}
//				else
//				{
//					if (ItFree(thBAPIE1PAREXX3)!= 0)
//						rfc_error("ItFree EXTENSIONINX");
//				}
//
//				tBapi_Makt = ItAppLine (thBapi_Makt) ;
//				tBapi_Marm  = ItAppLine (thBapi_Marm) ;
//				tBapi_Marmx = ItAppLine (thBapi_Marmx) ;
//				tBAPIE1PAREX3 = ItAppLine(thBAPIE1PAREX3) ;
//				tBAPIE1PAREXX3 = ItAppLine(thBAPIE1PAREXX3) ;
//
//
//				if (tBapi_Makt == NULL)
//				rfc_error("ItAppLine BAPI_MAKT");
//				if (tBapi_Marm == NULL)
//				rfc_error("ItAppLine BAPI_MARM second table");
//				if (tBapi_Marmx == NULL)
//				rfc_error("ItAppLine BAPI_MARMX");
//				if (tBAPIE1PAREX3 == NULL) rfc_error("ItAppLine BAPIE1PAREX3");
//				if (tBAPIE1PAREXX3 == NULL) rfc_error("ItAppLine BAPIE1PAREXX3");
//
//				SETCHAR(eBapiMatHead.Material,part_noDup);
//				SETCHAR(eBapiMatHead.Matl_Type,mat_type);
//				SETCHAR(eBapiMatHead.Ind_Sector,"M");
//				SETCHAR(eBapiMatHead.Basic_View,"X");		/*basic view*/
//				SETCHAR(eBasicView.Base_Uom,meas_unit);
//				SETCHAR(eBasicView.Base_Uom_Iso,meas_unit);
//				SETCHAR(eBasicViewx.Base_Uom,"X");
//				SETCHAR(eBasicViewx.Base_Uom_Iso,"X");
//				SETCHAR(tBapi_Marm->Alt_Unit,meas_unit);
//				SETCHAR(tBapi_Marm->Alt_Unit_Iso,meas_unit);
//				SETCHAR(tBapi_Marmx->Alt_Unit,meas_unit);
//				SETCHAR(tBapi_Marmx->Alt_Unit_Iso,meas_unit);
//				SETCHAR(tBapi_Makt->Matl_Desc,descDup);
//				if(tc_strlen(doc_noDup)==0)
//				{
//						SETCHAR(eBasicView.Document,"");
//						SETCHAR(eBasicViewx.Document,"");
//				}
//				else
//				{
//						SETCHAR(eBasicView.Document,doc_noDup);
//						SETCHAR(eBasicViewx.Document,"X");
//				}
//				if(tc_strlen(dwg_typeDup)==0)
//				{
//						SETCHAR(eBasicView.Doc_Type,"");
//						SETCHAR(eBasicViewx.Doc_Type,"");
//				}
//				else
//				{
//						SETCHAR(eBasicView.Doc_Type,dwg_typeDup);
//						SETCHAR(eBasicViewx.Doc_Type,"X");
//				}
//				if(tc_strlen(dwg_revDup)==0)
//				{
//						SETCHAR(eBasicView.Doc_Vers,"");
//						SETCHAR(eBasicViewx.Doc_Vers,"");
//				}
//				else
//				{
//						SETCHAR(eBasicView.Doc_Vers,dwg_revDup);
//						SETCHAR(eBasicViewx.Doc_Vers,"X");
//				}
//
//				if(tc_strlen(sheet_noDup)==0)
//				{
//						SETCHAR(eBasicView.No_Sheets,"");
//						SETCHAR(eBasicViewx.No_Sheets,"");
//				}
//				else
//				{
//						SETNUM(eBasicView.No_Sheets,sheet_noDup);
//						SETCHAR(eBasicViewx.No_Sheets,"X");
//				}
//
//				SETCHAR(eBasicView.Old_Mat_No,OldMatNoDup);
//				SETCHAR(eBasicViewx.Old_Mat_No,"X");
//
//				SETBCD(eBasicView.Net_Weight,myzeroDup3,3);
//				SETCHAR(eBasicViewx.Net_Weight,"X");
//
//				SETBCD(tBapi_Marm->Gross_Wt,gross_wt,3);
//				SETCHAR(tBapi_Marmx->Gross_Wt,"X");
//
//				SETCHAR(eBasicView.Unit_Of_Wt,unit_wt);
//				SETCHAR(eBasicView.Unit_Of_Wt_Iso,unit_wt);
//				SETCHAR(eBasicViewx.Unit_Of_Wt,"X");
//				SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"X");
//
//				SETCHAR(tBapi_Marm->Unit_Of_Wt,unit_wt);
//				SETCHAR(tBapi_Marm->Unit_Of_Wt_Iso,unit_wt);
//				SETCHAR(tBapi_Marmx->Unit_Of_Wt,"X");
//				SETCHAR(tBapi_Marmx->Unit_Of_Wt_Iso,"X");
//
//				SETBCD(tBapi_Marm->Volume,myzeroDup3,3);
//				SETCHAR(tBapi_Marm->VolumeUnit,vol_unit);
//				SETCHAR(tBapi_Marm->VolumeUnit_Iso,vol_unit);
//				SETCHAR(tBapi_Marmx->Volume,"X");
//				SETCHAR(tBapi_Marmx->VolumeUnit,"X");
//				SETCHAR(tBapi_Marmx->VolumeUnit_Iso,"X");
//
//				if(tc_strlen(sizeDup)==0)
//				{
//						SETCHAR(eBasicView.Size_Dim,"");
//						SETCHAR(eBasicViewx.Size_Dim,"");
//				}
//				else
//				{
//					SETCHAR(eBasicView.Size_Dim,sizeDup);/*sizeDup*/
//					SETCHAR(eBasicViewx.Size_Dim,"X");
//				}
//
//				if(tc_strlen(store_locDup)>0)
//				{
//					printf ("\nBefore conversion: %s", store_locDup);
//					tc_strupr(store_locDup,&store_locDup);
//					printf ("\nAfter conversion: %s", store_locDup);
//
//					SETCHAR(eMrpView.Iss_St_Loc,store_locDup);
//					SETCHAR(eMrpView.Sloc_Exprc,store_locDup);
//					SETCHAR(eMrpViewx.Iss_St_Loc,"X");
//					SETCHAR(eMrpViewx.Sloc_Exprc,"X");
//					printf("\nstore location is : %s",store_locDup);
//					fprintf(fsuccess,"\nstore location is : %s",store_locDup);
//				}
//				else
//				{
//					SETCHAR(eMrpView.Iss_St_Loc,"");
//					SETCHAR(eMrpView.Sloc_Exprc,"");
//					SETCHAR(eMrpViewx.Iss_St_Loc,"");
//					SETCHAR(eMrpViewx.Sloc_Exprc,"");
//
//					//printf("\nstore location is : %s",store_locDup); fflush(stdout);
//					//fprintf(fsuccess,"\nstore location is : %s",store_locDup); fflush(fsuccess);
//					printf("\nstore location is null"); 
//				}
//
//				SETCHAR(eBasicView.Matl_Group,material_group);
//				SETCHAR(eBasicViewx.Matl_Group,"X");
//
//				SETCHAR(eBasicView.Division,basic_division);
//				SETCHAR(eBasicViewx.Division,"X");
//
//				SETCHAR(eBapiMatHead.Mrp_View,"X");	/*mrp view*/
//				SETCHAR(eMrpView.Mrp_Group,mrp_grp);
//				SETCHAR(eMrpViewx.Mrp_Group,"X");
//				SETCHAR(eMrpView.Abc_Id,abc_ind);
//				SETCHAR(eMrpViewx.Abc_Id,"X");
//				if(tc_strlen(mm_pp_status)==0)
//				{
//					SETCHAR(eMrpView.Pur_Status," ");
//					SETCHAR(eMrpViewx.Pur_Status,"X");
//					printf("\nMaterial  status is........ABC : %s",mm_pp_status);
//					fprintf(fsuccess,"\nMaterial  status is........ABC : %s",mm_pp_status);
//				}
//				else
//				{
//					SETCHAR(eMrpView.Pur_Status,mm_pp_status);
//					SETCHAR(eMrpViewx.Pur_Status,"X");
//					printf("\nMaterial  status is........ABC1 : %s",mm_pp_status);
//					fprintf(fsuccess,"\nMaterial  status is........ABC1 : %s",mm_pp_status);
//				}
//				//SETCHAR(eMrpView.Pur_Status,mm_pp_status);
//				//SETCHAR(eMrpViewx.Pur_Status,"X");
//				SETCHAR(eMrpView.Mrp_Type,mrp_type);
//				SETCHAR(eMrpViewx.Mrp_Type,"X");
//				SETBCD(eMrpView.Reorder_Pt,reord_pt,3);
//				SETCHAR(eMrpViewx.Reorder_Pt,"X");
//				SETCHAR(eMrpView.Quotausage,quota_arrangement_usage);
//				SETCHAR(eMrpViewx.Quotausage,"X");
//				SETCHAR(eMrpView.Mrp_Ctrler,mrp_controller);
//				SETCHAR(eMrpViewx.Mrp_Ctrler,"X");
//				SETCHAR(eMrpView.Lotsizekey,lot_size_key);
//				SETCHAR(eMrpViewx.Lotsizekey,"X");
//				SETBCD(eMrpView.Fixed_Lot,fixed_lot_size,3);
//				SETCHAR(eMrpViewx.Fixed_Lot,"X");
//				SETBCD(eMrpView.Max_Stock,max_stlvl,3);
//				SETCHAR(eMrpViewx.Max_Stock,"X");
//				SETCHAR(eMrpView.Proc_Type,proc_type);
//				SETCHAR(eMrpViewx.Proc_Type,"X");
//				SETCHAR(eMrpView.Spproctype,spl_proc_key);
//				SETCHAR(eMrpViewx.Spproctype,"X");
//				SETCHAR(eMrpView.Bulk_Mat,blk_ind);
//				SETCHAR(eMrpViewx.Bulk_Mat,"X");
//				SETCHAR(eMrpView.Sm_Key,sched_mar_key);
//				SETCHAR(eMrpViewx.Sm_Key,"X");
//				SETCHAR(eMrpView.Ppc_Pl_Cal,plan_calendar);
//
//				SETCHAR(eMrpViewx.Ppc_Pl_Cal,"X");
//				SETCHAR(eMrpView.Grp_Reqmts,req_grp);
//				SETCHAR(eMrpViewx.Grp_Reqmts,"X");
//				SETCHAR(eMrpView.Period_Ind,period_ind);
//				SETCHAR(eMrpViewx.Period_Ind,"X");
//				SETCHAR(eMrpView.Mixed_Mrp,mixedmrp);
//				SETCHAR(eMrpViewx.Mixed_Mrp,"X");
//				SETCHAR(eMrpView.Availcheck,avail_chk);
//				SETCHAR(eMrpViewx.Availcheck,"X");
//				SETCHAR(eBapi_Mpgd.Plng_Matl,splan_mat);
//				SETCHAR(eBapi_Mpgdx.Plng_Matl,"X");
//				SETCHAR(eBapi_Mpgd.Plng_Plant,splan_plant);
//				SETCHAR(eBapi_Mpgdx.Plng_Plant,"X");
//				SETCHAR(eBapi_Mpgd.Convfactor,splan_conv_fact);
//				SETCHAR(eBapi_Mpgdx.Convfactor,"X");
//				SETCHAR(eMrpView.Alternative_Bom,"");
//				SETCHAR(eMrpViewx.Alternative_Bom,"");
//				SETCHAR(eMrpView.Alt_Bom_Id,alternativb);
//				SETCHAR(eMrpViewx.Alt_Bom_Id,"X");
//				SETCHAR(eMrpView.Dep_Req_Id,ind_collect);
//				SETCHAR(eMrpViewx.Dep_Req_Id,"X");
//
//				//SETCHAR(eMrpView.Rep_Manuf,"");/*rep_mfg_in*/
//				//SETCHAR(eMrpViewx.Rep_Manuf,"");/*X*/
//				//SETCHAR(eMrpView.Repmanprof,"");/*rep_mfg*/
//				//SETCHAR(eMrpViewx.Repmanprof,"");/*X*/
//
//				if(tc_strlen(rep_mfg)>0)		//rep_mfg modified on 14.02.2017 for TE02
//				{
//					SETCHAR(eMrpView.Rep_Manuf,"X");/*rep_mfg_in*/
//					SETCHAR(eMrpViewx.Rep_Manuf,"X");/*X*/
//					SETCHAR(eMrpView.Repmanprof,rep_mfg);/*rep_mfg*/
//					SETCHAR(eMrpViewx.Repmanprof,"X");/*X*/
//				}
//				else
//				{
//					SETCHAR(eMrpView.Rep_Manuf,"");/*rep_mfg_in*/
//					SETCHAR(eMrpViewx.Rep_Manuf,"X");/*X*/
//					SETCHAR(eMrpView.Repmanprof,"");/*rep_mfg*/
//					SETCHAR(eMrpViewx.Repmanprof,"X");/*X*/
//				}
//
//				SETCHAR(eMrpView.Determ_Grp,stock_det_group);
//
//				SETCHAR(eMrpViewx.Determ_Grp,"X");
//				SETCHAR(eBapiMatHead.Storage_View,"X");	/*store view*/
//				SETCHAR(eMrpView.Issue_Unit,uoissue);
//				SETCHAR(eMrpView.Issue_Unit_Iso,uoissue);
//				SETCHAR(eMrpViewx.Issue_Unit,"");	/*these value they are sending as blank hence removed*/
//				SETCHAR(eMrpViewx.Issue_Unit_Iso,"");
//				SETCHAR(eMrpView.Profit_Ctr,profit_centre_sap);		/*profit_centre=0001111010*/
//				SETCHAR(eMrpViewx.Profit_Ctr,"X");
//
//				if(tc_strcmp(mat_type,"FERT") != 0)
//				{
//					//SETCHAR(eMrpView.Rep_Manuf,"");/*X*/	/*for vc it is checked in mrp4*/
//					//SETCHAR(eMrpViewx.Rep_Manuf,"");/*X*/
//					//SETCHAR(eMrpView.Repmanprof,"");/*rep_mfg*/
//					//SETCHAR(eMrpViewx.Repmanprof,"");/*X*/
//
//					if(tc_strlen(rep_mfg)>0)		//rep_mfg modified on 14.02.2017 for TE02
//					{
//						SETCHAR(eMrpView.Rep_Manuf,"X");/*rep_mfg_in*/
//						SETCHAR(eMrpViewx.Rep_Manuf,"X");/*X*/
//						SETCHAR(eMrpView.Repmanprof,rep_mfg);/*rep_mfg*/
//						SETCHAR(eMrpViewx.Repmanprof,"X");/*X*/
//					}
//					else
//					{
//						SETCHAR(eMrpView.Rep_Manuf,"");/*rep_mfg_in*/
//						SETCHAR(eMrpViewx.Rep_Manuf,"X");/*X*/
//						SETCHAR(eMrpView.Repmanprof,"");/*rep_mfg*/
//						SETCHAR(eMrpViewx.Repmanprof,"X");/*X*/
//					}
//
//					SETCHAR(eBapiMatHead.Quality_View,"X");	/*quality view*/
//					SETCHAR(eMrpView.Ind_Post_To_Insp_Stock,qua_ins_ind);
//					SETCHAR(eMrpViewx.Ind_Post_To_Insp_Stock,"X");
//
//					SETCHAR(eMrpView.Doc_Reqd,doc_req);
//					SETCHAR(eMrpViewx.Doc_Reqd,"X");
//					SETBCD(eMrpView.Gr_Pr_Time,grptime,0);
//					SETCHAR(eMrpViewx.Gr_Pr_Time,"X");
//					SETCHAR(eBasicView.Catprofile,catalog_prof);
//					SETCHAR(eBasicViewx.Catprofile,"X");
//					SETCHAR(eBasicView.Qm_Procmnt,qm_proc_ind);
//					SETCHAR(eBasicViewx.Qm_Procmnt,"X");
//
//					//control_key = "";
//					SETCHAR(eMrpView.Ctrl_Key,control_key);
//					SETCHAR(eMrpViewx.Ctrl_Key,"X");
//
//					SETCHAR(eMrpView.Cert_Type,certificate_type);
//					SETCHAR(eMrpViewx.Cert_Type,"X");
//				}
//				else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
//				{
//					printf("\nQM View For VC");fflush(stdout);
//					printf("\n[%s,%s,%s,%s,%s]",qua_ins_ind,doc_req,grptime,catalog_prof,qm_proc_ind);fflush(stdout);
//
//					SETCHAR(eBapiMatHead.Quality_View,"X");	/*quality view*/
//					SETCHAR(eMrpView.Ind_Post_To_Insp_Stock,"");
//					SETCHAR(eMrpViewx.Ind_Post_To_Insp_Stock,"");
//					SETCHAR(eMrpView.Doc_Reqd,"");
//					SETCHAR(eMrpViewx.Doc_Reqd,"");
//					SETBCD(eMrpView.Gr_Pr_Time,grptime,0);
//					SETCHAR(eMrpViewx.Gr_Pr_Time,"X");
//					SETCHAR(eBasicView.Catprofile,catalog_prof);
//					SETCHAR(eBasicViewx.Catprofile,"X");
//					SETCHAR(eBasicView.Qm_Procmnt,"");
//					SETCHAR(eBasicViewx.Qm_Procmnt,"");
//					SETCHAR(eMrpView.Ctrl_Key,control_key);
//					SETCHAR(eMrpViewx.Ctrl_Key,"X");
//					SETCHAR(eMrpView.Cert_Type,certificate_type);
//					SETCHAR(eMrpViewx.Cert_Type,"X");
//				}
//				else    /* as per req. on 1/8 */
//				{
//					SETCHAR(eBapiMatHead.Quality_View,"");	/*quality view*/
//					SETCHAR(eMrpView.Ind_Post_To_Insp_Stock,"");
//					SETCHAR(eMrpViewx.Ind_Post_To_Insp_Stock,"");
//					SETCHAR(eMrpView.Doc_Reqd,"");
//					SETCHAR(eMrpViewx.Doc_Reqd,"");
//					SETBCD(eMrpView.Gr_Pr_Time,"",0);
//					SETCHAR(eMrpViewx.Gr_Pr_Time,"");
//					SETCHAR(eBasicView.Catprofile,"");
//					SETCHAR(eBasicViewx.Catprofile,"");
//					SETCHAR(eBasicView.Qm_Procmnt,"");
//					SETCHAR(eBasicViewx.Qm_Procmnt,"");
//					SETCHAR(eMrpView.Ctrl_Key,"");
//					SETCHAR(eMrpViewx.Ctrl_Key,"");
//					SETCHAR(eMrpView.Cert_Type,"");
//					SETCHAR(eMrpViewx.Cert_Type,"");
//				}
//
//				SETCHAR(eBapiMatHead.Account_View,"X"); /*accounting view */
//				SETCHAR(eAccView.Val_Cat,valuation_cat);
//				SETCHAR(eAccViewx.Val_Cat,"X");
//				SETCHAR(eAccView.Val_Class,val_class);
//				SETCHAR(eAccViewx.Val_Class,"X");
//				SETCHAR(eAccView.Price_Ctrl,price_con);
//				SETCHAR(eAccViewx.Price_Ctrl,"X");
//				SETBCD(eAccView.Std_Price,std_price,4);
//				SETCHAR(eAccViewx.Std_Price,"X");
//				SETBCD(eAccView.Moving_Pr,moving_avg_price,4);
//				SETCHAR(eAccViewx.Moving_Pr,"X");
//
//				SETCHAR(eBapiMatHead.Cost_View,"X");/*lvl cost view */
//				SETCHAR(eAccView.Mat_Origin,mat_origin);
//				SETCHAR(eAccViewx.Mat_Origin,"X");
//				SETCHAR(eAccView.Orig_Group,origin_group);
//				SETCHAR(eAccViewx.Orig_Group,"X");
//				SETBCD(eMrpView.Lot_Size,cost_lot_size,3);
//				SETCHAR(eMrpViewx.Lot_Size,"X");
//				SETCHAR(eAccView.Overhead_Grp,overhd_grp);
//				SETCHAR(eAccViewx.Overhead_Grp,"X");
//				SETCHAR(eMrpView.Variance_Key,variance_key);
//				SETCHAR(eMrpViewx.Variance_Key,"X");
//				SETCHAR(eAccView.Qty_Struct,with_quantity_structure);
//				SETCHAR(eAccViewx.Qty_Struct,"X");
//				SETCHAR(eMrpView.Split_Ind,costing_split_valuation);
//				SETCHAR(eMrpViewx.Split_Ind,"");	/*Please make it as X*/
//				SETCHAR(eRmmg1_Aennr.Aennr,dml_no_arg);
//
//				SETCHAR(eBapiMatHead.Sales_View,"");
//				SETCHAR(eBapiMatHead.Purchase_View,"");
//				SETCHAR(eBapiMatHead.Forecast_View,"");
//				SETCHAR(eBapiMatHead.Work_Sched_View,"");
//				SETCHAR(eBapiMatHead.Prt_View,"");
//				SETCHAR(eBapiMatHead.Warehouse_View,"");
//				SETCHAR(eBapiMatHead.Inp_Fld_Check,"");
//				SETCHAR(eBapiMatHead.Material_External,"");
//				SETCHAR(eBapiMatHead.MateriaL_Guid,"");
//				SETCHAR(eBapiMatHead.Material_Version,"");
//
//				SETCHAR(eBasicView.Del_Flag,"");
//				SETCHAR(eBasicView.Po_Unit,"");
//				SETCHAR(eBasicView.Po_Unit_Iso,"");
//				SETCHAR(eBasicView.Doc_Format,"");
//				SETCHAR(eBasicView.Doc_Chg_No,"");
//				SETCHAR(eBasicView.Page_No,"");
//				SETCHAR(eBasicView.Prod_Memo,"");
//				SETCHAR(eBasicView.Pageformat,"");
//				SETCHAR(eBasicView.Basic_Matl,"");
//				SETCHAR(eBasicView.Std_Descr,"");
//				SETCHAR(eBasicView.Dsn_Office,"");
//				SETCHAR(eBasicView.Pur_Valkey,"");
//				SETCHAR(eBasicView.Container,"");
//				SETCHAR(eBasicView.Stor_Conds,"");
//				SETCHAR(eBasicView.Temp_Conds,"");
//				SETCHAR(eBasicView.Trans_Grp,"");
//				SETCHAR(eBasicView.Haz_Mat_No,"");
//				SETCHAR(eBasicView.Competitor,"");
//				SETBCD(eBasicView.Qty_Gr_Gi,myzeroDup3,3);
//				SETCHAR(eBasicView.Proc_Rule,"");
//				SETCHAR(eBasicView.Sup_Source,"");
//				SETCHAR(eBasicView.Season,"");
//				SETCHAR(eBasicView.Label_Type,"");
//				SETCHAR(eBasicView.Label_Form,"");
//				SETCHAR(eBasicView.Prod_Hier,"");
//				SETCHAR(eBasicView.Cad_Id,"X");
//				SETBCD(eBasicView.Allowed_Wt,myzeroDup3,3);
//				SETCHAR(eBasicView.Pack_Wt_Un,"");
//				SETCHAR(eBasicView.Pack_Wt_Un_Iso,"");
//				SETBCD(eBasicView.Allwd_Vol,myzeroDup3,3);
//				SETCHAR(eBasicView.Pack_Vo_Un,"");
//				SETCHAR(eBasicView.Pack_Vo_Un_Iso,"");
//				SETBCD(eBasicView.Wt_Tol_Lt,myzeroDup1,1);
//				SETBCD(eBasicView.Vol_Tol_Lt,myzeroDup1,1);
//				SETCHAR(eBasicView.Var_Ord_Un,"");
//				SETCHAR(eBasicView.Batch_Mgmt,"");
//				SETCHAR(eBasicView.Sh_Mat_Typ,"");
//				SETBCD(eBasicView.Fill_Level,"0",0);
//				SETINT2(&eBasicView.Stack_Fact,"0");
//				SETCHAR(eBasicView.Mat_Grp_Sm,"");
//				SETCHAR(eBasicView.Authoritygroup,"");
//				SETBCD(eBasicView.Minremlife,"0",0);
//				SETBCD(eBasicView.Shelf_Life,"0",0);
//				SETBCD(eBasicView.Stor_Pct,"0",0);
//				SETCHAR(eBasicView.Pur_Status,"");
//				SETCHAR(eBasicView.Sal_Status,"");
//				SETDATE(eBasicView.Pvalidfrom,"");
//				SETDATE(eBasicView.Svalidfrom,"");
//				SETCHAR(eBasicView.Envt_Rlvt,"");
//				SETCHAR(eBasicView.Prod_Alloc,"");
//				SETCHAR(eBasicView.Qual_Dik,"");
//				SETCHAR(eBasicView.Manu_Mat,"");
//				SETCHAR(eBasicView.Mfr_No,"");
//				SETCHAR(eBasicView.Inv_Mat_No,"");
//				SETCHAR(eBasicView.Manuf_Prof,"");
//				SETCHAR(eBasicView.Hazmatprof,"");
//				SETCHAR(eBasicView.High_Visc,"");
//				SETCHAR(eBasicView.Looseorliq,"");
//				SETCHAR(eBasicView.Closed_Box,"");
//				SETCHAR(eBasicView.Appd_B_Rec,"");
//				SETNUM(eBasicView.Matcmpllvl,"00");
//				SETCHAR(eBasicView.Par_Eff,"");
//				SETCHAR(eBasicView.Round_Up_Rule_Expiration_Date,"");
//				SETCHAR(eBasicView.Period_Ind_Expiration_Date,"D");
//				SETCHAR(eBasicView.Prod_Composition_On_Packaging,"");
//				SETCHAR(eBasicView.Item_Cat,"");
//				SETCHAR(eBasicView.Haz_Mat_No_External,"");
//				SETCHAR(eBasicView.Haz_Mat_No_Guid,"");
//				SETCHAR(eBasicView.Haz_Mat_No_Version,"");
//				SETCHAR(eBasicView.Inv_Mat_No_External,"");
//				SETCHAR(eBasicView.Inv_Mat_No_Guid,"");
//				SETCHAR(eBasicView.Inv_Mat_No_Version,"");
//				SETCHAR(eBasicView.Material_Fixed,"");
//				SETCHAR(eBasicView.Cm_Relevance_Flag,"");
//				SETCHAR(eBasicView.Sled_Bbd,"");
//				SETCHAR(eBasicView.Gtin_Variant,"");
//				SETCHAR(eBasicView.Serialization_Level,"");
//				SETCHAR(eBasicView.Pl_Ref_Mat,"");
//				SETCHAR(eBasicView.Extmatlgrp,"");
//				SETCHAR(eBasicView.Uomusage,"");
//				SETCHAR(eBasicView.Pl_Ref_Mat_External,"");
//				SETCHAR(eBasicView.Pl_Ref_Mat_Guid,"");
//				SETCHAR(eBasicView.Pl_Ref_Mat_Version,"");
//
//				SETCHAR(eBasicViewx.Del_Flag,"");
//				SETCHAR(eBasicViewx.Po_Unit,"");
//				SETCHAR(eBasicViewx.Po_Unit_Iso,"");
//				SETCHAR(eBasicViewx.Doc_Format,"");
//				SETCHAR(eBasicViewx.Doc_Chg_No,"");
//				SETCHAR(eBasicViewx.Page_No,"");
//				SETCHAR(eBasicViewx.Prod_Memo,"");
//				SETCHAR(eBasicViewx.Pageformat,"");
//				SETCHAR(eBasicViewx.Basic_Matl,"");
//				SETCHAR(eBasicViewx.Std_Descr,"");
//				SETCHAR(eBasicViewx.Dsn_Office,"");
//				SETCHAR(eBasicViewx.Pur_Valkey,"");
//				SETCHAR(eBasicViewx.Container,"");
//				SETCHAR(eBasicViewx.Stor_Conds,"");
//				SETCHAR(eBasicViewx.Temp_Conds,"");
//				SETCHAR(eBasicViewx.Trans_Grp,"");
//				SETCHAR(eBasicViewx.Haz_Mat_No,"");
//				SETCHAR(eBasicViewx.Competitor,"");
//				SETCHAR(eBasicViewx.Qty_Gr_Gi,"");
//				SETCHAR(eBasicViewx.Proc_Rule,"");
//				SETCHAR(eBasicViewx.Sup_Source,"");
//				SETCHAR(eBasicViewx.Season,"");
//				SETCHAR(eBasicViewx.Label_Type,"");
//				SETCHAR(eBasicViewx.Label_Form,"");
//				SETCHAR(eBasicViewx.Prod_Hier,"");
//				SETCHAR(eBasicViewx.Cad_Id,"X");
//				SETCHAR(eBasicViewx.Allowed_Wt,"");
//				SETCHAR(eBasicViewx.Pack_Wt_Un,"");
//				SETCHAR(eBasicViewx.Pack_Wt_Un_Iso,"");
//				SETCHAR(eBasicViewx.Allwd_Vol,"");
//				SETCHAR(eBasicViewx.Pack_Vo_Un,"");
//				SETCHAR(eBasicViewx.Pack_Vo_Un_Iso,"");
//				SETCHAR(eBasicViewx.Wt_Tol_Lt,"");
//				SETCHAR(eBasicViewx.Vol_Tol_Lt,"");
//				SETCHAR(eBasicViewx.Var_Ord_Un,"");
//				SETCHAR(eBasicViewx.Batch_Mgmt,"");
//				SETCHAR(eBasicViewx.Sh_Mat_Typ,"");
//				SETCHAR(eBasicViewx.Fill_Level,"");
//				SETCHAR(eBasicViewx.Stack_Fact,"");
//				SETCHAR(eBasicViewx.Mat_Grp_Sm,"");
//				SETCHAR(eBasicViewx.Authoritygroup,"");
//				SETCHAR(eBasicViewx.Minremlife,"");
//				SETCHAR(eBasicViewx.Shelf_Life,"");
//				SETCHAR(eBasicViewx.Stor_Pct,"");
//				SETCHAR(eBasicViewx.Pur_Status,"");
//				SETCHAR(eBasicViewx.Sal_Status,"");
//				SETCHAR(eBasicViewx.Pvalidfrom,"");
//				SETCHAR(eBasicViewx.Svalidfrom,"");
//				SETCHAR(eBasicViewx.Envt_Rlvt,"");
//				SETCHAR(eBasicViewx.Prod_Alloc,"");
//				SETCHAR(eBasicViewx.Qual_Dik,"");
//				SETCHAR(eBasicViewx.Manu_Mat,"");
//				SETCHAR(eBasicViewx.Mfr_No,"");
//				SETCHAR(eBasicViewx.Inv_Mat_No,"");
//				SETCHAR(eBasicViewx.Manuf_Prof,"");
//				SETCHAR(eBasicViewx.Hazmatprof,"");
//				SETCHAR(eBasicViewx.High_Visc,"");
//				SETCHAR(eBasicViewx.Looseorliq,"");
//				SETCHAR(eBasicViewx.Closed_Box,"");
//				SETCHAR(eBasicViewx.Appd_B_Rec,"");
//				SETCHAR(eBasicViewx.Matcmpllvl,"");
//				SETCHAR(eBasicViewx.Par_Eff,"");
//				SETCHAR(eBasicViewx.Round_Up_Rule_Expiration_Date,"");
//				SETCHAR(eBasicViewx.Period_Ind_Expiration_Date,"");
//				SETCHAR(eBasicViewx.Prod_Composition_On_Packaging,"");
//				SETCHAR(eBasicViewx.Item_Cat,"");
//				SETCHAR(eBasicViewx.Haz_Mat_No_External,"");
//				SETCHAR(eBasicViewx.Haz_Mat_No_Guid,"");
//				SETCHAR(eBasicViewx.Haz_Mat_No_Version,"");
//				SETCHAR(eBasicViewx.Inv_Mat_No_External,"");
//				SETCHAR(eBasicViewx.Inv_Mat_No_Guid,"");
//				SETCHAR(eBasicViewx.Inv_Mat_No_Version,"");
//				SETCHAR(eBasicViewx.Material_Fixed,"");
//				SETCHAR(eBasicViewx.Cm_Relevance_Flag,"");
//				SETCHAR(eBasicViewx.Sled_Bbd,"");
//				SETCHAR(eBasicViewx.Gtin_Variant,"");
//				SETCHAR(eBasicViewx.Serialization_Level,"");
//				SETCHAR(eBasicViewx.Pl_Ref_Mat,"");
//				SETCHAR(eBasicViewx.Extmatlgrp,"");
//				SETCHAR(eBasicViewx.Uomusage,"");
//				SETCHAR(eBasicViewx.Pl_Ref_Mat_External,"");
//				SETCHAR(eBasicViewx.Pl_Ref_Mat_Guid,"");
//				SETCHAR(eBasicViewx.Pl_Ref_Mat_Version,"");
//
//				SETCHAR(eMrpView.Plant,plantcode);
//				SETCHAR(eMrpView.Del_Flag,"");
//				SETCHAR(eMrpView.Crit_Part,"");
//				SETCHAR(eMrpView.Pur_Group,"");
//				SETCHAR(eMrpView.Mrpprofile,"");
//				SETCHAR(eMrpView.Plnd_Delry,"0");
//				SETBCD(eMrpView.Assy_Scrap,myzeroDup2,2);
//				SETBCD(eMrpView.Safety_Stk,myzeroDup3,3);
//				SETBCD(eMrpView.Minlotsize,myzeroDup3,3);
//				SETBCD(eMrpView.Maxlotsize,myzeroDup3,3);
//				SETBCD(eMrpView.Round_Val,myzeroDup3,3);
//				SETBCD(eMrpView.Ord_Costs,myzeroDup4,4);
//				SETCHAR(eMrpView.Stor_Costs,"");
//
//				SETCHAR(eMrpView.Discontinu,"");
//				SETCHAR(eMrpView.Eff_O_Day,"");
//				SETCHAR(eMrpView.Follow_Up,"");
//				SETCHAR(eMrpView.Backflush,"");
//				SETCHAR(eMrpView.Production_Scheduler,"");
//				SETBCD(eMrpView.Proc_Time,myzeroDup2,2);
//				SETBCD(eMrpView.Setuptime,myzeroDup2,2);
//				SETBCD(eMrpView.Interop,myzeroDup2,2);
//				SETBCD(eMrpView.Base_Qty,myzeroDup3,3);
//				SETBCD(eMrpView.Inhseprodt,"0",0);
//				SETBCD(eMrpView.Stgeperiod,"0",0);
//				SETCHAR(eMrpView.Stge_Pd_Un,"");
//				SETCHAR(eMrpView.Stge_Pd_Un_Iso,"");
//				SETBCD(eMrpView.Over_Tol,myzeroDup1,1);
//				SETCHAR(eMrpView.Unlimited,"");
//				SETBCD(eMrpView.Under_Tol,myzeroDup1,1);
//				SETBCD(eMrpView.Replentime,"0",0);
//				SETCHAR(eMrpView.Replace_Pt,"");
//				SETCHAR(eMrpView.Loadinggrp,"");
//				SETCHAR(eMrpView.Batch_Mgmt,"");
//				SETBCD(eMrpView.Serv_Level,myzeroDup1,1);
//				SETCHAR(eMrpView.Fy_Variant,"");
//				SETCHAR(eMrpView.Corr_Fact,"");
//				SETBCD(eMrpView.Setup_Time,myzeroDup2,2);
//				SETBCD(eMrpView.Base_Qty_Plan,myzeroDup3,3);
//				SETBCD(eMrpView.Ship_Proc_Time,myzeroDup2,2);
//				SETCHAR(eMrpView.Sup_Source,"");
//				SETCHAR(eMrpView.Auto_P_Ord,"");
//				SETCHAR(eMrpView.Sourcelist,"");
//				SETCHAR(eMrpView.Comm_Code,"");
//				SETCHAR(eMrpView.Countryori,"");
//				SETCHAR(eMrpView.Countryori_Iso,"");
//				SETCHAR(eMrpView.Regionorig,"");
//				SETCHAR(eMrpView.Comm_Co_Un,"");
//				SETCHAR(eMrpView.Comm_Co_Un_Iso,"");
//				SETCHAR(eMrpView.Expimpgrp,"");
//				SETNUM(eMrpView.Pl_Ti_Fnce,"000");
//				SETCHAR(eMrpView.Consummode,"");
//				SETNUM(eMrpView.Bwd_Cons,"000");
//				SETNUM(eMrpView.Fwd_Cons,"000");
//				SETCHAR(eMrpView.Bom_Usage,"");
//				SETCHAR(eMrpView.Planlistgrp,"");
//				SETCHAR(eMrpView.Planlistcnt,"");
//				SETCHAR(eMrpView.Specprocty,"");
//				SETCHAR(eMrpView.Prod_Unit,"");
//				SETCHAR(eMrpView.Prod_Unit_Iso,"");
//				//SETCHAR(eMrpView.Iss_St_Loc,store_locDup);
//				//SETCHAR(eMrpView.Iss_St_Loc,"");
//				SETBCD(eMrpView.Comp_Scrap,myzeroDup2,2);
//				SETBCD(eMrpView.Cycle_Time,"0",0);
//				SETCHAR(eMrpView.Covprofile,"");
//				SETCHAR(eMrpView.Cc_Ph_Inv,"");
//				SETCHAR(eMrpView.Serno_Prof,"");
//				SETCHAR(eMrpView.Neg_Stocks,"");
//				SETCHAR(eMrpView.Qm_Rgmts,"");
//				SETCHAR(eMrpView.Plng_Cycle,"");
//				SETCHAR(eMrpView.Round_Prof,"");
//				SETCHAR(eMrpView.Refmatcons,"");
//				SETCHAR(eMrpView.D_To_Ref_M,"");
//				SETBCD(eMrpView.Mult_Ref_M,myzeroDup2,2);
//				SETCHAR(eMrpView.Auto_Reset,"");
//				SETCHAR(eMrpView.Ex_Cert_Id,"");
//				SETCHAR(eMrpView.Ex_Cert_No_New,"");
//				SETCHAR(eMrpView.Ex_Cert_Dt,"");
//				SETCHAR(eMrpView.Milit_Id,"");
//				SETBCD(eMrpView.Insp_Int,"0",0);
//				SETCHAR(eMrpView.Co_Product,"");
//				SETCHAR(eMrpView.Plan_Strgp,"");
//				//SETCHAR(eMrpView.Sloc_Exprc,store_locDup);
//				//SETCHAR(eMrpView.Sloc_Exprc,"");
//				SETCHAR(eMrpView.Cc_Fixed,"");
//				SETCHAR(eMrpView.Qm_Authgrp,"");
//				SETCHAR(eMrpView.Task_List_Type,"");
//				SETCHAR(eMrpView.Prodprof,"");
//				SETCHAR(eMrpView.Safty_T_Id,"");
//				SETNUM(eMrpView.Safetytime,"00");
//				SETCHAR(eMrpView.Plord_Ctrl,"");
//				SETCHAR(eMrpView.Batchentry,"");
//				SETDATE(eMrpView.Pvalidfrom,"");
//				SETCHAR(eMrpView.Matfrgtgrp,"");
//				SETCHAR(eMrpView.Prodverscs,"");
//				SETCHAR(eMrpView.Mat_Cfop,"");
//				SETCHAR(eMrpView.Eu_List_No,"");
//				SETCHAR(eMrpView.Eu_Mat_Grp,"");
//				SETCHAR(eMrpView.Cas_No,"");
//				SETCHAR(eMrpView.Prodcom_No,"");
//				SETCHAR(eMrpView.Ctrl_Code,"");
//				SETCHAR(eMrpView.Jit_Relvt,"");
//				SETCHAR(eMrpView.Mat_Grp_Trans,"");
//				SETCHAR(eMrpView.Handlg_Grp,"");
//				SETCHAR(eMrpView.Supply_Area,"");
//				SETCHAR(eMrpView.Fair_Share_Rule,"");
//				SETCHAR(eMrpView.Push_Distrib,"");
//				SETBCD(eMrpView.Deploy_Horiz,"0",0);
//				SETBCD(eMrpView.Min_Lot_Size,myzeroDup3,3);
//				SETBCD(eMrpView.Max_Lot_Size,myzeroDup3,3);
//				SETBCD(eMrpView.Fix_Lot_Size,myzeroDup3,3);
//				SETBCD(eMrpView.Lot_Increment,myzeroDup3,3);
//				SETCHAR(eMrpView.Prod_Conv_Type,"");
//				SETCHAR(eMrpView.Distr_Prof,"");
//				SETCHAR(eMrpView.Period_Profile_Safety_Time,"");
//				SETCHAR(eMrpView.Fxd_Price,"");
//				SETCHAR(eMrpView.Avail_Check_All_Proj_Segments,"");
//				SETCHAR(eMrpView.Overallprf,"");
//				SETCHAR(eMrpView.Mrp_Relevancy_Dep_Requirements,"");
//				SETBCD(eMrpView.Min_Safety_Stk,myzeroDup2,2);
//				SETCHAR(eMrpView.No_Costing,"");
//				SETCHAR(eMrpView.Unit_Group,"");
//				SETCHAR(eMrpView.Follow_Up_External,"");
//				SETCHAR(eMrpView.Follow_Up_Guid,"");
//				SETCHAR(eMrpView.Follow_Up_Version,"");
//				SETCHAR(eMrpView.Refmatcons_External,"");
//				SETCHAR(eMrpView.Refmatcons_Guid,"");
//				SETCHAR(eMrpView.Refmatcons_Version,"");
//				SETCHAR(eMrpView.Rotation_Date,"");
//				SETCHAR(eMrpView.Original_Batch_Flag,"");
//				SETCHAR(eMrpView.Original_Batch_Ref_Material,"");
//				SETCHAR(eMrpView.Original_Batch_Ref_Material_E,"");
//				SETCHAR(eMrpView.Original_Batch_Ref_Material_V,"");
//				SETCHAR(eMrpView.Original_Batch_Ref_Material_G,"");
//
//				SETCHAR(eMrpViewx.Plant,plantcode);
//				SETCHAR(eMrpViewx.Del_Flag,"");
//				SETCHAR(eMrpViewx.Crit_Part,"");
//				SETCHAR(eMrpViewx.Pur_Group,"");
//				SETCHAR(eMrpViewx.Mrpprofile,"");
//				SETCHAR(eMrpViewx.Plnd_Delry,"");
//				SETCHAR(eMrpViewx.Assy_Scrap,"");
//				SETCHAR(eMrpViewx.Safety_Stk,"");
//				SETCHAR(eMrpViewx.Minlotsize,"");
//				SETCHAR(eMrpViewx.Maxlotsize,"");
//				SETCHAR(eMrpViewx.Round_Val,"");
//				SETCHAR(eMrpViewx.Ord_Costs,"");
//				SETCHAR(eMrpViewx.Stor_Costs,"");
//
//				SETCHAR(eMrpViewx.Discontinu,"");
//				SETCHAR(eMrpViewx.Eff_O_Day,"");
//				SETCHAR(eMrpViewx.Follow_Up,"");
//				SETCHAR(eMrpViewx.Backflush,"");
//				SETCHAR(eMrpViewx.Production_Scheduler,"");
//				SETCHAR(eMrpViewx.Proc_Time,"");
//				SETCHAR(eMrpViewx.Setuptime,"");
//				SETCHAR(eMrpViewx.Interop,"");
//				SETCHAR(eMrpViewx.Base_Qty,"");
//				SETCHAR(eMrpViewx.Inhseprodt,"");
//				SETCHAR(eMrpViewx.Stgeperiod,"");
//				SETCHAR(eMrpViewx.Stge_Pd_Un,"");
//				SETCHAR(eMrpViewx.Stge_Pd_Un_Iso,"");
//				SETCHAR(eMrpViewx.Over_Tol,"");
//				SETCHAR(eMrpViewx.Unlimited,"");
//				SETCHAR(eMrpViewx.Under_Tol,"");
//				SETCHAR(eMrpViewx.Replentime,"");
//				SETCHAR(eMrpViewx.Replace_Pt,"");
//				SETCHAR(eMrpViewx.Loadinggrp,"");
//				SETCHAR(eMrpViewx.Batch_Mgmt,"");
//				SETCHAR(eMrpViewx.Serv_Level,"");
//				SETCHAR(eMrpViewx.Fy_Variant,"");
//				SETCHAR(eMrpViewx.Corr_Fact,"");
//				SETCHAR(eMrpViewx.Setup_Time,"");
//				SETCHAR(eMrpViewx.Base_Qty_Plan,"");
//				SETCHAR(eMrpViewx.Ship_Proc_Time,"");
//				SETCHAR(eMrpViewx.Sup_Source,"");
//				SETCHAR(eMrpViewx.Auto_P_Ord,"");
//				SETCHAR(eMrpViewx.Sourcelist,"");
//				SETCHAR(eMrpViewx.Comm_Code,"");
//				SETCHAR(eMrpViewx.Countryori,"");
//				SETCHAR(eMrpViewx.Countryori_Iso,"");
//				SETCHAR(eMrpViewx.Regionorig,"");
//				SETCHAR(eMrpViewx.Comm_Co_Un,"");
//				SETCHAR(eMrpViewx.Comm_Co_Un_Iso,"");
//				SETCHAR(eMrpViewx.Expimpgrp,"");
//				SETCHAR(eMrpViewx.Pl_Ti_Fncve,"");
//				SETCHAR(eMrpViewx.Consummode,"");
//				SETCHAR(eMrpViewx.Bwd_Cons,"");
//				SETCHAR(eMrpViewx.Fwd_Cons,"");
//				SETCHAR(eMrpViewx.Bom_Usage,"");
//				SETCHAR(eMrpViewx.Planlistgrp,"");
//				SETCHAR(eMrpViewx.Planlistcnt,"");
//				SETCHAR(eMrpViewx.Specprocty,"");
//				SETCHAR(eMrpViewx.Prod_Unit,"");
//				SETCHAR(eMrpViewx.Prod_Unit_Iso,"");
//				//SETCHAR(eMrpViewx.Iss_St_Loc,"X");
//				//SETCHAR(eMrpViewx.Iss_St_Loc,"");
//				SETCHAR(eMrpViewx.Comp_Scrap,"");
//				SETCHAR(eMrpViewx.Cycle_Time,"");
//				SETCHAR(eMrpViewx.Covprofile,"");
//				SETCHAR(eMrpViewx.Cc_Ph_Inv,"");
//				SETCHAR(eMrpViewx.Serno_Prof,"");
//				SETCHAR(eMrpViewx.Neg_Stocks,"");
//				SETCHAR(eMrpViewx.Qm_Rgmts,"");
//				SETCHAR(eMrpViewx.Plng_Cycle,"");
//				SETCHAR(eMrpViewx.Round_Prof,"");
//				SETCHAR(eMrpViewx.Refmatcons,"");
//				SETCHAR(eMrpViewx.D_To_Ref_M,"");
//				SETCHAR(eMrpViewx.Mult_Ref_M,"");
//				SETCHAR(eMrpViewx.Auto_Reset,"");
//				SETCHAR(eMrpViewx.Ex_Cert_Id,"");
//				SETCHAR(eMrpViewx.Ex_Cert_No_New,"");
//				SETCHAR(eMrpViewx.Ex_Cert_Dt,"");
//				SETCHAR(eMrpViewx.Milit_Id,"");
//				SETCHAR(eMrpViewx.Insp_Int,"");
//				SETCHAR(eMrpViewx.Co_Product,"");
//				SETCHAR(eMrpViewx.Plan_Strgp,"");
//				//SETCHAR(eMrpViewx.Sloc_Exprc,"X");
//				//SETCHAR(eMrpViewx.Sloc_Exprc,"");
//				SETCHAR(eMrpViewx.Cc_Fixed,"");
//				SETCHAR(eMrpViewx.Qm_Authgrp,"");
//				SETCHAR(eMrpViewx.Task_List_Type,"");
//				SETCHAR(eMrpViewx.Prodprof,"");
//				SETCHAR(eMrpViewx.Safty_T_Id,"");
//				SETCHAR(eMrpViewx.Safetytime,"");
//				SETCHAR(eMrpViewx.Plord_Ctrl,"");
//				SETCHAR(eMrpViewx.Batchentry,"");
//				SETCHAR(eMrpViewx.Pvalidfrom,"");
//				SETCHAR(eMrpViewx.Matfrgtgrp,"");
//				SETCHAR(eMrpViewx.Prodverscs,"");
//				SETCHAR(eMrpViewx.Mat_Cfop,"");
//				SETCHAR(eMrpViewx.Eu_List_No,"");
//				SETCHAR(eMrpViewx.Eu_Mat_Grp,"");
//				SETCHAR(eMrpViewx.Cas_No,"");
//				SETCHAR(eMrpViewx.Prodcom_No,"");
//				SETCHAR(eMrpViewx.Ctrl_Code,"");
//				SETCHAR(eMrpViewx.Jit_Relvt,"");
//				SETCHAR(eMrpViewx.Mat_Grp_Trans,"");
//				SETCHAR(eMrpViewx.Handlg_Grp,"");
//				SETCHAR(eMrpViewx.Supply_Area,"");
//				SETCHAR(eMrpViewx.Fair_Share_Rule,"");
//				SETCHAR(eMrpViewx.Push_Distrib,"");
//				SETCHAR(eMrpViewx.Deploy_Horiz,"");
//				SETCHAR(eMrpViewx.Min_Lot_Size,"");
//				SETCHAR(eMrpViewx.Max_Lot_Size,"");
//				SETCHAR(eMrpViewx.Fix_Lot_Size,"");
//				SETCHAR(eMrpViewx.Lot_Increment,"");
//				SETCHAR(eMrpViewx.Prod_Conv_Type,"");
//				SETCHAR(eMrpViewx.Distr_Prof,"");
//				SETCHAR(eMrpViewx.Period_Profile_Safety_Time,"");
//				SETCHAR(eMrpViewx.Fxd_Price,"");
//				SETCHAR(eMrpViewx.Avail_Check_All_Proj_Segments,"");
//				SETCHAR(eMrpViewx.Overallprf,"");
//				SETCHAR(eMrpViewx.Mrp_Relevancy_Dep_Requirements,"");
//				SETCHAR(eMrpViewx.Min_Safety_Stk,"");
//				SETCHAR(eMrpViewx.No_Costing,"");
//				SETCHAR(eMrpViewx.Unit_Group,"");
//				SETCHAR(eMrpViewx.Follow_Up_External,"");
//				SETCHAR(eMrpViewx.Follow_Up_Guid,"");
//				SETCHAR(eMrpViewx.Follow_Up_Version,"");
//				SETCHAR(eMrpViewx.Refmatcons_External,"");
//				SETCHAR(eMrpViewx.Refmatcons_Guid,"");
//				SETCHAR(eMrpViewx.Refmatcons_Version,"");
//				SETCHAR(eMrpViewx.Rotation_Date,"");
//				SETCHAR(eMrpViewx.Original_Batch_Flag,"");
//				SETCHAR(eMrpViewx.Original_Batch_Ref_Material,"");
//				SETCHAR(eMrpViewx.Original_Batch_Ref_Material_E,"");
//				SETCHAR(eMrpViewx.Original_Batch_Ref_Material_V,"");
//				SETCHAR(eMrpViewx.Original_Batch_Ref_Material_G,"");
//
//				SETCHAR(eBapi_Mpgd.Plant,plantcode);
//				SETCHAR(eBapi_Mpgd.Plng_Matl_External,"");
//				SETCHAR(eBapi_Mpgd.Plng_Matl_Guid,"");
//				SETCHAR(eBapi_Mpgd.Plng_Matl_Version,"");
//				SETCHAR(eBapi_Mpgdx.Plant,plantcode);
//				SETCHAR(eBapi_Mpgdx.Plng_Matl_External,"");
//				SETCHAR(eBapi_Mpgdx.Plng_Matl_Guid,"");
//				SETCHAR(eBapi_Mpgdx.Plng_Matl_Version,"");
//
//				SETCHAR(eBapi_Mard.Plant,plantcode);
//				SETCHAR(eBapi_Mard.Stge_Loc,"9005");
//				SETCHAR(eBapi_Mard.Del_Flag,"");
//				SETCHAR(eBapi_Mard.Mrp_Ind,"");
//				SETCHAR(eBapi_Mard.Spec_Proc,"");
//				SETBCD(eBapi_Mard.Reorder_Pt,myzeroDup3,3);
//				SETBCD(eBapi_Mard.Repl_Qty,myzeroDup3,3);
//				SETCHAR(eBapi_Mard.Stge_Bin,"");
//				SETCHAR(eBapi_Mard.Pickg_Area,"");
//				SETFLOAT(&eBapi_Mard.Inv_Corr_Fac,"");
//
//				SETCHAR(eBapi_Mardx.Plant,plantcode);
//				SETCHAR(eBapi_Mardx.Stge_Loc,"9005");
//				SETCHAR(eBapi_Mardx.Del_Flag,"");
//				SETCHAR(eBapi_Mardx.Mrp_Ind,"");
//				SETCHAR(eBapi_Mardx.Spec_Proc,"");
//				SETCHAR(eBapi_Mardx.Reorder_Pt,"");
//				SETCHAR(eBapi_Mardx.Repl_Qty,"");
//				SETCHAR(eBapi_Mardx.Stge_Bin,"");
//				SETCHAR(eBapi_Mardx.Pickg_Area,"");
//				SETCHAR(eBapi_Mardx.Inv_Corr_Fac,"");
//
//				SETCHAR(eAccView.Val_Area,plantcode);
//				SETCHAR(eAccView.Val_Type,"");
//				SETCHAR(eAccView.Del_Flag,"");
//				SETBCD(eAccView.Price_Unit,"",0);
//				SETCHAR(eAccView.Pr_Ctrl_Pp,"");
//				SETBCD(eAccView.Mov_Pr_Pp,myzeroDup4,4);
//				SETBCD(eAccView.Std_Pr_Pp,myzeroDup4,4);
//				SETBCD(eAccView.Pr_Unit_Pp,"0",1);
//				SETCHAR(eAccView.Vclass_Pp,"");
//				SETCHAR(eAccView.Pr_Ctrl_Py,"");
//				SETBCD(eAccView.Mov_Pr_Py,myzeroDup4,4);
//				SETBCD(eAccView.Std_Pr_Py,myzeroDup4,4);
//				SETCHAR(eAccView.Vclass_Py,"");
//				SETBCD(eAccView.Pr_Unit_Py,"0",0);
//				SETBCD(eAccView.Future_Pr,myzeroDup4,4);
//				SETDATE(eAccView.Valid_From,"");
//				SETBCD(eAccView.Taxprice_1,myzeroDup4,4);
//				SETBCD(eAccView.Commprice1,myzeroDup4,4);
//				SETBCD(eAccView.Taxprice_3,myzeroDup4,4);
//				SETBCD(eAccView.Commprice3,myzeroDup4,4);
//				SETBCD(eAccView.Plnd_Price,myzeroDup4,4);
//				SETBCD(eAccView.Plndprice1,myzeroDup4,4);
//				SETBCD(eAccView.Plndprice2,myzeroDup4,4);
//				SETBCD(eAccView.Plndprice3,myzeroDup4,4);
//				SETDATE(eAccView.Plndprdate1,"");
//				SETDATE(eAccView.Plndprdate2,"");
//				SETDATE(eAccView.Plndprdate3,"");
//				SETCHAR(eAccView.Lifo_Fifo,"");
//				SETCHAR(eAccView.Poolnumber,"");
//				SETBCD(eAccView.Taxprice_2,myzeroDup4,4);
//				SETBCD(eAccView.Commprice2,myzeroDup4,4);
//				SETNUM(eAccView.Deval_Ind,"00");
//				SETCHAR(eAccView.Ml_Active,"");
//				SETCHAR(eAccView.Ml_Settle,"");
//				SETCHAR(eAccView.Orig_Mat,"X");
//				SETCHAR(eAccView.Vm_So_Stk,"");
//				SETCHAR(eAccView.Vm_P_Stock,"");
//				SETCHAR(eAccView.Matl_Usage,"");
//				SETCHAR(eAccView.In_House,"");
//				SETBCD(eAccView.Tax_Cml_Un,"0",0);
//
//				SETCHAR(eAccViewx.Val_Area,plantcode);
//				SETCHAR(eAccViewx.Val_Type,"");
//				SETCHAR(eAccViewx.Del_Flag,"");
//				SETCHAR(eAccViewx.Price_Unit,"");
//				SETCHAR(eAccViewx.Pr_Ctrl_Pp,"");
//				SETCHAR(eAccViewx.Mov_Pr_Pp,"");
//				SETCHAR(eAccViewx.Std_Pr_Pp,"");
//				SETCHAR(eAccViewx.Pr_Unit_Pp,"");
//				SETCHAR(eAccViewx.Vclass_Pp,"");
//				SETCHAR(eAccViewx.Pr_Ctrl_Py,"");
//				SETCHAR(eAccViewx.Mov_Pr_Py,"");
//				SETCHAR(eAccViewx.Std_Pr_Py,"");
//				SETCHAR(eAccViewx.Vclass_Py,"");
//				SETCHAR(eAccViewx.Pr_Unit_Py,"");
//				SETCHAR(eAccViewx.Future_Pr,"");
//				SETCHAR(eAccViewx.Valid_From,"");
//				SETCHAR(eAccViewx.Taxprice_1,"");
//				SETCHAR(eAccViewx.Commprice1,"");
//				SETCHAR(eAccViewx.Taxprice_3,"");
//				SETCHAR(eAccViewx.Commprice3,"");
//				SETCHAR(eAccViewx.Plnd_Price,"");
//				SETCHAR(eAccViewx.Plndprice1,"");
//				SETCHAR(eAccViewx.Plndprice2,"");
//				SETCHAR(eAccViewx.Plndprice3,"");
//				SETCHAR(eAccViewx.Plndprdate1,"");
//				SETCHAR(eAccViewx.Plndprdate2,"");
//				SETCHAR(eAccViewx.Plndprdate3,"");
//				SETCHAR(eAccViewx.Lifo_Fifo,"");
//				SETCHAR(eAccViewx.Poolnumber,"");
//				SETCHAR(eAccViewx.Taxprice_2,"");
//				SETCHAR(eAccViewx.Commprice2,"");
//				SETCHAR(eAccViewx.Deval_Ind,"");
//				SETCHAR(eAccViewx.Ml_Active,"");
//				SETCHAR(eAccViewx.Ml_Settle,"");
//				SETCHAR(eAccViewx.Orig_Mat,"X");
//				SETCHAR(eAccViewx.Vm_So_Stk,"");
//				SETCHAR(eAccViewx.Vm_P_Stock,"");
//				SETCHAR(eAccViewx.Matl_Usage,"");
//				SETCHAR(eAccViewx.In_House,"");
//				SETCHAR(eAccViewx.Tax_Cml_Un,"");
//
//				SETCHAR(tBapi_Makt->Langu,"EN");
//				SETCHAR(tBapi_Makt->Langu_Iso,"EN");
//				SETCHAR(tBapi_Makt->Del_Flag,"");
//
//				SETBCD(tBapi_Marm->Numerator,"1",0);
//				SETBCD(tBapi_Marm->Denominatr,"1",0);
//				SETCHAR(tBapi_Marm->Ean_Upc,"");
//				SETCHAR(tBapi_Marm->Ean_Cat,"");
//				SETCHAR(tBapi_Marm->Length,"");
//				SETCHAR(tBapi_Marm->Width,"");
//				SETCHAR(tBapi_Marm->Height,"");
//				SETCHAR(tBapi_Marm->Unit_Dim,"");
//				SETCHAR(tBapi_Marm->Unit_Dim_Iso,"");
//				SETCHAR(tBapi_Marm->Del_Flag,"");
//				SETCHAR(tBapi_Marm->Sub_Uom,"");
//				SETCHAR(tBapi_Marm->Sub_Uom_Iso,"");
//				SETCHAR(tBapi_Marm->Gtin_Variant,"");
//
//				SETCHAR(tBapi_Marmx->Numerator,"X");
//				SETCHAR(tBapi_Marmx->Denominatr,"X");
//				SETCHAR(tBapi_Marmx->Ean_Upc,"");
//				SETCHAR(tBapi_Marmx->Ean_Cat,"");
//				SETCHAR(tBapi_Marmx->Length,"");
//				SETCHAR(tBapi_Marmx->Width,"");
//				SETCHAR(tBapi_Marmx->Height,"");
//				SETCHAR(tBapi_Marmx->Unit_Dim,"");
//				SETCHAR(tBapi_Marmx->Unit_Dim_Iso,"");
//				SETCHAR(tBapi_Marmx->Sub_Uom,"");
//				SETCHAR(tBapi_Marmx->Sub_Uom_Iso,"");
//				SETCHAR(tBapi_Marmx->Gtin_Variant,"");
//
//				SETCHAR(tBAPIE1PAREX3->STRUCTURE,"BAPI_TE_MARA");
//				SETCHAR(tBAPIE1PAREX3->VALUEPART1,part_noDupDes);
//				SETCHAR(tBAPIE1PAREX3->VALUEPART2,"");
//				SETCHAR(tBAPIE1PAREX3->VALUEPART3,"");
//				SETCHAR(tBAPIE1PAREX3->VALUEPART4,"");
//
//				SETCHAR(tBAPIE1PAREXX3->STRUCTURE,"BAPI_TE_MARAX");
//				SETCHAR(tBAPIE1PAREXX3->VALUEPART1,part_noDupDesx);
//				SETCHAR(tBAPIE1PAREXX3->VALUEPART2,"");
//				SETCHAR(tBAPIE1PAREXX3->VALUEPART3,"");
//				SETCHAR(tBAPIE1PAREXX3->VALUEPART4,"");
//
//				RfcRc = zbapi_material_savedata_mrpCreate(hRfc,&eBapiMatHead,&eBasicView,&eBasicViewx,&eMrpView,&eMrpViewx,&eBapi_Mpgd,&eBapi_Mpgdx,&eBapi_Mard,&eBapi_Mardx,&eAccView,&eAccViewx,&eRmmg1_Aennr,&eBapiret2,thBapi_Makt,thBapi_Marm,thBapi_Marmx,thBAPIE1PAREX3,thBAPIE1PAREXX3,xException);
//
//				switch (RfcRc)
//				{
//					case RFC_OK:
//						//sprintf(sap_msg,"%.*s:",sizeof(sap_msg),eBapiret2.Message);
//						//GETCHAR(eBapiret2.Message,sap_msg);
//
//						printf("\nMessage for Material %s Create with basic view: %s",part_noDup,eBapiret2.Message); fflush(stdout);
//						fprintf(fsuccess,"\nMessage for Material %s Create with basic view: %s",part_noDup,eBapiret2.Message); fflush(fsuccess);
//
//						sprintf(a,"The material %s has been created or extended",part_noDup);
//
//						if (tc_strstr(eBapiret2.Message,a)!=NULL)
//						{
//
//							sprintf(Error_message,"The material %s has been created or extended",part_noDup);
//							tc_strcpy(MATstatus,"Y");
//							Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
//
//						}
//						else
//						{
//
//							tc_strcpy(MATstatus,"N");
//							tc_strcpy(Error_message,eBapiret2.Message);
//							Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
//
//						}
//
//						break;
//					case RFC_EXCEPTION:
//						printf("\nRFC EXCEPTION: %s",xException); fflush(stdout);
//						break;
//					case RFC_SYS_EXCEPTION:
//						printf("\nSystem Exception Raised!!!"); fflush(stdout);
//						break;
//					case RFC_FAILURE:
//						printf("\nFailure!!!"); fflush(stdout);
//						break;
//					default:
//						printf("\nOther Failure!"); fflush(stdout);
//					break;
//				}
//				if(ItDelete(thBapi_Makt) != 0)	rfc_error("ItDelete thBapi_Makt");
//				if(ItDelete(thBapi_Marm) != 0)	rfc_error("ItDelete tBapi_Marm");
//				if(ItDelete(thBapi_Marmx) != 0) rfc_error("ItDelete thBapi_Marmx");
//				if(ItDelete(thBAPIE1PAREX3) != 0) rfc_error("ItDelete thBAPIE1PAREX3");
//				if(ItDelete(thBAPIE1PAREXX3) != 0) rfc_error("ItDelete thBAPIE1PAREXX3");
//				/*sleep(5);*/
//				RfcClose(hRfc);
			}
			
			if(tc_strlen(store_locDup)>0 && tc_strcmp(store_locDup,"NA")!=0)
			{
				//if ((tc_strcmp(plantcode,"1001")==0) || (tc_strcmp(plantcode,"1500")==0) || (tc_strcmp(plantcode,"3100")==0) || (tc_strcmp(plantcode,"1100")==0)  || (tc_strcmp(plantcode,"1140")==0) )
				//if ((tc_strcmp(plantcode,"1001")==0) || (tc_strcmp(plantcode,"1500")==0) || (tc_strcmp(plantcode,"3100")==0) || (tc_strcmp(plantcode,"1100")==0)  || (tc_strcmp(plantcode,"1140")==0) || (tc_strcmp(plantcode,"2001")==0) )//added Hrishikesh 20.09.2023
				if ((tc_strcmp(plantcode,"1001")==0) || (tc_strcmp(plantcode,"1500")==0) || (tc_strcmp(plantcode,"3100")==0) || (tc_strcmp(plantcode,"1100")==0)  || (tc_strcmp(plantcode,"1140")==0) || (tc_strcmp(plantcode,"2001")==0) || (tc_strcmp(plantcode,"E201")==0) )//added Hrishikesh 02.10.2023
				{
					printf ("\n1 Going for Store location updation in MMSC, as plant is %s",plantcode);
					//mmsc_sloc_update();  //MMSC2025
			    }
			}
//
//			//Store Loacation View Set
//			if(tc_strlen(store_locDup)>0 && tc_strcmp(store_locDup,"NA")!=0)
//			{
//				//if ((tc_strcmp(plantcode,"1001")==0) || (tc_strcmp(plantcode,"1500")==0) || (tc_strcmp(plantcode,"3100")==0) || (tc_strcmp(plantcode,"1100")==0)  || (tc_strcmp(plantcode,"1140")==0) )
//				//if ((tc_strcmp(plantcode,"1001")==0) || (tc_strcmp(plantcode,"1500")==0) || (tc_strcmp(plantcode,"3100")==0) || (tc_strcmp(plantcode,"1100")==0)  || (tc_strcmp(plantcode,"1140")==0) || (tc_strcmp(plantcode,"2001")==0) )//added Hrishikesh 20.09.2023
//				if ((tc_strcmp(plantcode,"1001")==0) || (tc_strcmp(plantcode,"1500")==0) || (tc_strcmp(plantcode,"3100")==0) || (tc_strcmp(plantcode,"1100")==0)  || (tc_strcmp(plantcode,"1140")==0) || (tc_strcmp(plantcode,"2001")==0) || (tc_strcmp(plantcode,"E201")==0) )//added Hrishikesh 02.10.2023
//				{
//					printf ("\n1 Going for Store location updation in MMSC, as plant is %s",plantcode);
//					hRfc = BapiLogon();
//					
//					SETCHAR(eBapiMatHead.Material,part_noDup);
//					SETCHAR(eBapiMatHead.Matl_Type,mat_type);
//					SETCHAR(eBapiMatHead.Ind_Sector,"M");
//					SETCHAR(eBapiMatHead.Basic_View,"");
//					SETCHAR(eBapiMatHead.Storage_View,"X");
//
//					SETCHAR(eBapi_Mard.Plant,plantcode);
//					SETCHAR(eBapi_Mard.Stge_Loc,store_locDup);
//					SETCHAR(eBapi_Mard.Del_Flag,"");
//					SETCHAR(eBapi_Mard.Mrp_Ind,"");
//					SETCHAR(eBapi_Mard.Spec_Proc,"");
//					SETBCD(eBapi_Mard.Reorder_Pt,myzeroDup3,3);
//					SETBCD(eBapi_Mard.Repl_Qty,myzeroDup3,3);
//					SETCHAR(eBapi_Mard.Stge_Bin,"");
//					SETCHAR(eBapi_Mard.Pickg_Area,"");
//					SETFLOAT(&eBapi_Mard.Inv_Corr_Fac,"");
//
//					SETCHAR(eBapi_Mardx.Plant,plantcode);
//					SETCHAR(eBapi_Mardx.Stge_Loc,store_locDup);
//					SETCHAR(eBapi_Mardx.Del_Flag,"");
//					SETCHAR(eBapi_Mardx.Mrp_Ind,"");
//					SETCHAR(eBapi_Mardx.Spec_Proc,"");
//					SETCHAR(eBapi_Mardx.Reorder_Pt,"");
//					SETCHAR(eBapi_Mardx.Repl_Qty,"");
//					SETCHAR(eBapi_Mardx.Stge_Bin,"");
//					SETCHAR(eBapi_Mardx.Pickg_Area,"");
//					SETCHAR(eBapi_Mardx.Inv_Corr_Fac,"");
//					
//					SETCHAR(eRmmg1_Aennr.Aennr,dml_no_arg);
//
//					RfcRc = BAPI_MATERIAL_MARD(hRfc,&eBapiMatHead,&eBapi_Mard,&eBapi_Mardx,&eRmmg1_Aennr,&eBapiret2,xException);
//
//					switch (RfcRc)
//					{
//						case RFC_OK:
//
//							printf("\nMessage for %s Store location update in MMSC : %s\n",part_noDup,eBapiret2.Message);
//							fprintf(fsuccess,"\nMessage for %s Store location update in MMSC : %s\n",part_noDup,eBapiret2.Message);
//
//							printf("\nStore loc updated in MMSC, part,plant : %s, %s, %s\n",store_locDup,part_noDup,plantcode);
//							fprintf(fsuccess,"\nStore loc updated in MMSC, part,plant : %s, %s, %s\n",store_locDup,part_noDup,plantcode);
//							break;
//						case RFC_EXCEPTION:
//							printf("\nRFC EXCEPTION: %s",xException);
//							break;
//						case RFC_SYS_EXCEPTION:
//							printf("\nSystem Exception Raised!!!");
//							break;
//						case RFC_FAILURE:
//							printf("\nFailure!!!");
//							break;
//						default:
//							printf("\nOther Failure!");
//						break;
//					}
//					RfcClose(hRfc);
//				}
//
//			}
		}
	}
	if (flag == 1)
	{
		printf("\nGoing for MATERIAL CHANGE..."); fflush(stdout);
		printf("\nMaterial change string : %s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s",part_noDup,plantcode,meas_unit,dml_numAP1,descDup,doc_noDup,dwg_typeDup,dwg_revDup,mrp_type,lot_size_key,proc_type,spl_proc_key,mrp_grp,reord_pt,max_stlvl,val_class,overhd_grp,origin_group,dml_no_arg); fflush(stdout);
		fprintf(fsuccess,"\nMaterial change string : %s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s",part_noDup,plantcode,meas_unit,dml_numAP1,descDup,doc_noDup,dwg_typeDup,dwg_revDup,mrp_type,lot_size_key,proc_type,spl_proc_key,mrp_grp,reord_pt,max_stlvl,val_class,overhd_grp,origin_group,dml_no_arg); fflush(fsuccess);
		fprintf(fsuccess,"\npart_noDupDes:%s",part_noDupDes);
		fprintf(fsuccess,"\npart_noDupDes:%s",part_noDupDesx); fflush(fsuccess);
		
		mat_change_all_view();
//
//		hRfc = BapiLogon();
//		thBapi_Makt = ITAB_NULL;
//		thBapi_Marm = ITAB_NULL;
//		thBapi_Marmx = ITAB_NULL;
//		thBAPIE1PAREX3 = ITAB_NULL;
//		thBAPIE1PAREXX3 = ITAB_NULL;
//
//		if (thBapi_Makt==ITAB_NULL)
//		{
//			thBapi_Makt = ItCreate("MATERIALDESCRIPTION",sizeof(BAPI_MAKT),0,0);
//			if (thBapi_Makt==ITAB_NULL) rfc_error("ItCreate MATERIALDESCRIPTION");
//		}
//		else if (ItFree(thBapi_Makt) != 0) rfc_error("ItFree MATERIALDESCRIPTION");
//
//		if (thBapi_Marm==ITAB_NULL)
//		{
//			 thBapi_Marm = ItCreate("UNITSOFMEASURE",sizeof(BAPI_MARM),0,0);
//			 if (thBapi_Marm==ITAB_NULL) rfc_error("ItCreate UNITSOFMEASURE");
//		}
//		else if (ItFree(thBapi_Marm)!= 0) rfc_error("ItFree UNITSOFMEASURE");
//
//		if (thBapi_Marmx==ITAB_NULL)
//		{
//			 thBapi_Marmx = ItCreate("UNITSOFMEASUREX",sizeof(BAPI_MARMX),0,0);
//			if (thBapi_Marmx==ITAB_NULL) rfc_error("ItCreate UNITSOFMEASUREX");
//		}
//		else if (ItFree(thBapi_Marmx)!= 0) rfc_error("ItFree UNITSOFMEASUREX");
//
//		if (thBAPIE1PAREX3==ITAB_NULL)
//		{
//			thBAPIE1PAREX3 = ItCreate("EXTENSIONIN",sizeof(BAPIE1PAREX3),0,0);
//			if (thBAPIE1PAREX3==ITAB_NULL)
//				rfc_error("ItCreate EXTENSIONIN");
//		}
//		else
//		{
//			if (ItFree(thBAPIE1PAREX3)!= 0)
//				rfc_error("ItFree EXTENSIONIN");
//		}
//
//		if (thBAPIE1PAREXX3==ITAB_NULL)
//		{
//			thBAPIE1PAREXX3 = ItCreate("EXTENSIONINX",sizeof(BAPIE1PAREXX3),0,0);
//			if (thBAPIE1PAREXX3==ITAB_NULL)
//				rfc_error("ItCreate EXTENSIONINX");
//		}
//		else
//		{
//			if (ItFree(thBAPIE1PAREXX3)!= 0)
//				rfc_error("ItFree EXTENSIONINX");
//		}
//
//		tBapi_Makt = ItAppLine (thBapi_Makt);
//		tBapi_Marm = ItAppLine (thBapi_Marm);
//		tBapi_Marmx = ItAppLine (thBapi_Marmx);
//		tBAPIE1PAREX3 = ItAppLine(thBAPIE1PAREX3) ;
//		tBAPIE1PAREXX3 = ItAppLine(thBAPIE1PAREXX3) ;
//
//		if (tBapi_Makt == NULL)	rfc_error("ItAppLine BAPI_MAKT");
//		if (tBapi_Marm == NULL)	rfc_error("ItAppLine BAPI_MARM second table");
//		if (tBapi_Marmx == NULL) rfc_error("ItAppLine BAPI_MARMX");
//		if (tBAPIE1PAREX3 == NULL) rfc_error("ItAppLine BAPIE1PAREX3");
//		if (tBAPIE1PAREXX3 == NULL) rfc_error("ItAppLine BAPIE1PAREXX3");
//
//		SETCHAR(eBapiMatHead.Material,part_noDup);
//		SETCHAR(eMrpView.Plant,plantcode);
//		SETCHAR(eMrpViewx.Plant,plantcode);
//		SETCHAR(eBapi_Mpgd.Plant,plantcode);
//		SETCHAR(eBapi_Mpgdx.Plant,plantcode);
//		SETCHAR(eBapi_Mard.Plant,plantcode);
//		SETCHAR(eBapi_Mardx.Plant,plantcode);
//		SETCHAR(eAccView.Val_Area,plantcode);
//		SETCHAR(eAccViewx.Val_Area,plantcode);
//		SETCHAR(eBasicView.Base_Uom,meas_unit);
//		SETCHAR(eBasicView.Base_Uom_Iso,meas_unit);
//		SETCHAR(eBasicViewx.Base_Uom,"X");
//		SETCHAR(eBasicViewx.Base_Uom_Iso,"X");
//
//		SETCHAR(tBapi_Marm->Alt_Unit,meas_unit);
//		SETCHAR(tBapi_Marm->Alt_Unit_Iso,meas_unit);
//		SETCHAR(tBapi_Marmx->Alt_Unit,meas_unit);
//		SETCHAR(tBapi_Marmx->Alt_Unit_Iso,meas_unit);
//		SETCHAR(eRmmg1_Aennr.Aennr,dml_no_arg);
//		if (tc_strcmp(mat_type,"FERT") != 0)
//		{
//			printf("\npart is not a VC"); fflush(stdout);
//			SETCHAR(eBapiMatHead.Quality_View,"X");//qm view
//		}
//		else if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar - QM View for VC
//		{
//			printf("\nQM View For VC");fflush(stdout);
//			printf("\n[%s,%s,%s,%s,%s]",qua_ins_ind,doc_req,grptime,catalog_prof,qm_proc_ind);fflush(stdout);
//
//			SETCHAR(eBapiMatHead.Quality_View,"X");	/*quality view*/
//			SETCHAR(eMrpView.Ind_Post_To_Insp_Stock,"");
//			SETCHAR(eMrpViewx.Ind_Post_To_Insp_Stock,"");
//			SETCHAR(eMrpView.Doc_Reqd,"");
//			SETCHAR(eMrpViewx.Doc_Reqd,"");
//			SETBCD(eMrpView.Gr_Pr_Time,grptime,0);
//			SETCHAR(eMrpViewx.Gr_Pr_Time,"X");
//			SETCHAR(eBasicView.Catprofile,catalog_prof);
//			SETCHAR(eBasicViewx.Catprofile,"X");
//			SETCHAR(eBasicView.Qm_Procmnt,"");
//			SETCHAR(eBasicViewx.Qm_Procmnt,"");
//			SETCHAR(eMrpView.Ctrl_Key,control_key);
//			SETCHAR(eMrpViewx.Ctrl_Key,"X");
//			SETCHAR(eMrpView.Cert_Type,certificate_type);
//			SETCHAR(eMrpViewx.Cert_Type,"X");
//		}
//		else SETCHAR(eBapiMatHead.Quality_View,"");     //qm view
//		// construct string for the mtchmdu string
//		SETCHAR(eBapiMatHead.Basic_View,"X");		//basic view
//		SETCHAR(tBapi_Makt->Matl_Desc,descDup);
//		if(tc_strlen(doc_noDup)==0)
//		{
//				SETCHAR(eBasicView.Document,"");
//				SETCHAR(eBasicViewx.Document,"");
//		}
//		else
//		{
//			SETCHAR(eBasicView.Document,doc_noDup);
//			SETCHAR(eBasicViewx.Document,"X");
//		}
//		if(tc_strlen(dwg_typeDup)==0)
//		{
//				SETCHAR(eBasicView.Doc_Type,"");
//				SETCHAR(eBasicViewx.Doc_Type,"");
//		}
//		else
//		{
//			SETCHAR(eBasicView.Doc_Type,dwg_typeDup);
//			SETCHAR(eBasicViewx.Doc_Type,"X");
//		}
//		if(tc_strlen(dwg_revDup)==0)
//		{
//				SETCHAR(eBasicView.Doc_Vers,"");
//				SETCHAR(eBasicViewx.Doc_Vers,"");
//		}
//		else
//		{
//			SETCHAR(eBasicView.Doc_Vers,dwg_revDup);
//			SETCHAR(eBasicViewx.Doc_Vers,"X");
//		}
//		if(tc_strlen(sheet_noDup)==0)
//		{
//				SETCHAR(eBasicView.No_Sheets,"");
//				SETCHAR(eBasicViewx.No_Sheets,"");
//		}
//		else
//		{
//			SETNUM(eBasicView.No_Sheets,sheet_noDup);
//			SETCHAR(eBasicViewx.No_Sheets,"X");
//		}
//		SETCHAR(eBapiMatHead.Mrp_View,"X");	//mrp view
//		SETCHAR(eMrpView.Mrp_Type,"");//mrp_type X
//		SETCHAR(eMrpViewx.Mrp_Type,"");
//		SETCHAR(eMrpView.Lotsizekey,"");//lot_size_key X
//		SETCHAR(eMrpViewx.Lotsizekey,"");
//		tc_strdup("S",&price_con);
//		//if(car_dml==1)
//		//{
//		//	SETCHAR(eMrpView.Proc_Type,proc_type);
//		//	SETCHAR(eMrpViewx.Proc_Type,"");
//		//	SETCHAR(eMrpView.Spproctype,spl_proc_key);
//		//	SETCHAR(eMrpViewx.Spproctype,"");
//		//}
//		//else
//		//{
//		//As per new request manisha madam 28.12.2007 car dml cs changes also trasffered to sap
//			//SETCHAR(eMrpView.Proc_Type,proc_type);
//			//SETCHAR(eMrpViewx.Proc_Type,"X");
//			//SETCHAR(eMrpView.Spproctype,spl_proc_key);
//			//SETCHAR(eMrpViewx.Spproctype,"X");
//		//}
//
//       
//	    //SCO-7079-Rajendra-G part-CS change stop from PLM -13 Nov 2017
//
//		if(*part_noDup=='G')
//		{
//			printf("\nGrp Part...... \n");fflush(stdout);
//			SETCHAR(eMrpView.Proc_Type,proc_type);
//			SETCHAR(eMrpViewx.Proc_Type,"");
//			SETCHAR(eMrpView.Spproctype,spl_proc_key);
//			SETCHAR(eMrpViewx.Spproctype,"");
//		}
//        else
//		{
//			//As per new request manisha madam 28.12.2007 car dml cs changes also trasffered to sap
//			SETCHAR(eMrpView.Proc_Type,proc_type);
//			SETCHAR(eMrpViewx.Proc_Type,"X");
//			SETCHAR(eMrpView.Spproctype,spl_proc_key);
//			SETCHAR(eMrpViewx.Spproctype,"X");
//		}
//
//		if(tc_strlen(store_locDup)>0)
//		{
//			printf ("\nBefore conversion: %s", store_locDup);
//			tc_strupr(store_locDup,&store_locDup);
//			printf ("\nAfter conversion: %s", store_locDup);
//
//			SETCHAR(eMrpView.Iss_St_Loc,store_locDup);
//			SETCHAR(eMrpView.Sloc_Exprc,store_locDup);
//			//SETCHAR(eMrpViewx.Iss_St_Loc,"X");		//old values
//			//SETCHAR(eMrpViewx.Sloc_Exprc,"X");		//old values
//			//below is corrected by DBK on 12-DEC-2022 as code is updating sloc on material change which is wrong.
//			SETCHAR(eMrpViewx.Iss_St_Loc,"");
//			SETCHAR(eMrpViewx.Sloc_Exprc,"");
//			printf("\nstore location is : %s",store_locDup);
//			fprintf(fsuccess,"\nstore location is : %s",store_locDup);
//		}
//		else
//		{
//			SETCHAR(eMrpView.Iss_St_Loc,"");
//			SETCHAR(eMrpView.Sloc_Exprc,"");
//			SETCHAR(eMrpViewx.Iss_St_Loc,"");
//			SETCHAR(eMrpViewx.Sloc_Exprc,"");
//
//			//printf("\nstore location is : %s",store_locDup); fflush(stdout);
//			//fprintf(fsuccess,"\nstore location is : %s",store_locDup); fflush(fsuccess);
//			printf("\nstore location is null"); 
//		}
//
//		SETCHAR(eMrpView.Mrp_Group,"");//mrp_grp X
//		SETCHAR(eMrpViewx.Mrp_Group,"");
//		SETBCD(eMrpView.Reorder_Pt,myzeroDup3,3);//reord_pt X
//		SETCHAR(eMrpViewx.Reorder_Pt,"");
//		SETBCD(eMrpView.Max_Stock,max_stlvl,3);
//		SETCHAR(eMrpViewx.Max_Stock,"X");
//		SETCHAR(eBapiMatHead.Account_View,"X"); //accounting view
//		SETCHAR(eAccView.Val_Class,val_class);
//		SETCHAR(eAccViewx.Val_Class,"X");
//		SETCHAR(eAccView.Overhead_Grp,overhd_grp);
//		SETCHAR(eAccViewx.Overhead_Grp,"X");
//		SETCHAR(eAccView.Orig_Group,origin_group);
//		SETCHAR(eAccViewx.Orig_Group,"X");
//
//		SETCHAR(eBapiMatHead.Ind_Sector,"M");
//		SETCHAR(eBapiMatHead.Matl_Type,mat_type);
//		SETCHAR(eBapiMatHead.Sales_View,"");
//		SETCHAR(eBapiMatHead.Purchase_View,"");
//		SETCHAR(eBapiMatHead.Forecast_View,"");
//		SETCHAR(eBapiMatHead.Work_Sched_View,"");
//		SETCHAR(eBapiMatHead.Prt_View,"");
//		SETCHAR(eBapiMatHead.Storage_View,"");
//		SETCHAR(eBapiMatHead.Warehouse_View,"");
//		SETCHAR(eBapiMatHead.Cost_View,"");
//		SETCHAR(eBapiMatHead.Inp_Fld_Check,"");
//		SETCHAR(eBapiMatHead.Material_External,"");
//		SETCHAR(eBapiMatHead.MateriaL_Guid,"");
//		SETCHAR(eBapiMatHead.Material_Version,"");
//
//		SETCHAR(eBasicView.Del_Flag,"");
//		SETCHAR(eBasicView.Matl_Group,"");
//		SETCHAR(eBasicView.Old_Mat_No,OldMatNoDup);
//		SETCHAR(eBasicView.Po_Unit,"");
//		SETCHAR(eBasicView.Po_Unit_Iso,"");
//		SETCHAR(eBasicView.Doc_Format,"");
//		SETCHAR(eBasicView.Doc_Chg_No,"");
//		SETCHAR(eBasicView.Page_No,"");
//		SETNUM(eBasicView.No_Sheets,"");
//		SETCHAR(eBasicView.Prod_Memo,"");
//		SETCHAR(eBasicView.Pageformat,"");
//		SETCHAR(eBasicView.Size_Dim,"");
//		SETCHAR(eBasicView.Basic_Matl,"");
//		SETCHAR(eBasicView.Std_Descr,"");
//		SETCHAR(eBasicView.Dsn_Office,"");
//		SETCHAR(eBasicView.Pur_Valkey,"");
//		SETBCD(eBasicView.Net_Weight,myzeroDup3,3);
//		SETCHAR(eBasicView.Unit_Of_Wt,"");
//		SETCHAR(eBasicView.Unit_Of_Wt_Iso,"");
//		SETCHAR(eBasicView.Container,"");
//		SETCHAR(eBasicView.Stor_Conds,"");
//		SETCHAR(eBasicView.Temp_Conds,"");
//		SETCHAR(eBasicView.Trans_Grp,"");
//		SETCHAR(eBasicView.Haz_Mat_No,"");
//		SETCHAR(eBasicView.Division,"");
//		SETCHAR(eBasicView.Competitor,"");
//		SETBCD(eBasicView.Qty_Gr_Gi,myzeroDup3,3);
//		SETCHAR(eBasicView.Proc_Rule,"");
//		SETCHAR(eBasicView.Sup_Source,"");
//		SETCHAR(eBasicView.Season,"");
//		SETCHAR(eBasicView.Label_Type,"");
//		SETCHAR(eBasicView.Label_Form,"");
//		SETCHAR(eBasicView.Prod_Hier,"");
//		SETCHAR(eBasicView.Cad_Id,"X");
//		SETBCD(eBasicView.Allowed_Wt,myzeroDup3,3);
//		SETCHAR(eBasicView.Pack_Wt_Un,"");
//		SETCHAR(eBasicView.Pack_Wt_Un_Iso,"");
//		SETBCD(eBasicView.Allwd_Vol,myzeroDup3,3);
//		SETCHAR(eBasicView.Pack_Vo_Un,"");
//		SETCHAR(eBasicView.Pack_Vo_Un_Iso,"");
//		SETBCD(eBasicView.Wt_Tol_Lt,myzeroDup1,1);
//		SETBCD(eBasicView.Vol_Tol_Lt,myzeroDup1,1);
//		SETCHAR(eBasicView.Var_Ord_Un,"");
//		SETCHAR(eBasicView.Batch_Mgmt,"");
//		SETCHAR(eBasicView.Sh_Mat_Typ,"");
//		SETBCD(eBasicView.Fill_Level,"0",0);
//		SETINT2(&eBasicView.Stack_Fact,"0");
//		SETCHAR(eBasicView.Mat_Grp_Sm,"");
//		SETCHAR(eBasicView.Authoritygroup,"");
//		SETCHAR(eBasicView.Qm_Procmnt,"");
//		SETCHAR(eBasicView.Catprofile,"");
//		SETBCD(eBasicView.Minremlife,"0",0);
//		SETBCD(eBasicView.Shelf_Life,"0",0);
//		SETBCD(eBasicView.Stor_Pct,"0",0);
//		SETCHAR(eBasicView.Pur_Status,"");
//		SETCHAR(eBasicView.Sal_Status,"");
//		SETDATE(eBasicView.Pvalidfrom,"");
//		SETDATE(eBasicView.Svalidfrom,"");
//		SETCHAR(eBasicView.Envt_Rlvt,"");
//		SETCHAR(eBasicView.Prod_Alloc,"");
//		SETCHAR(eBasicView.Qual_Dik,"");
//		SETCHAR(eBasicView.Manu_Mat,"");
//		SETCHAR(eBasicView.Mfr_No,"");
//		SETCHAR(eBasicView.Inv_Mat_No,"");
//		SETCHAR(eBasicView.Manuf_Prof,"");
//		SETCHAR(eBasicView.Hazmatprof,"");
//		SETCHAR(eBasicView.High_Visc,"");
//		SETCHAR(eBasicView.Looseorliq,"");
//		SETCHAR(eBasicView.Closed_Box,"");
//		SETCHAR(eBasicView.Appd_B_Rec,"");
//		SETNUM(eBasicView.Matcmpllvl,"00");
//		SETCHAR(eBasicView.Par_Eff,"");
//		SETCHAR(eBasicView.Round_Up_Rule_Expiration_Date,"");
//		SETCHAR(eBasicView.Period_Ind_Expiration_Date,"D");
//		SETCHAR(eBasicView.Prod_Composition_On_Packaging,"");
//		SETCHAR(eBasicView.Item_Cat,"");
//		SETCHAR(eBasicView.Haz_Mat_No_External,"");
//		SETCHAR(eBasicView.Haz_Mat_No_Guid,"");
//		SETCHAR(eBasicView.Haz_Mat_No_Version,"");
//		SETCHAR(eBasicView.Inv_Mat_No_External,"");
//		SETCHAR(eBasicView.Inv_Mat_No_Guid,"");
//		SETCHAR(eBasicView.Inv_Mat_No_Version,"");
//		SETCHAR(eBasicView.Material_Fixed,"");
//		SETCHAR(eBasicView.Cm_Relevance_Flag,"");
//		SETCHAR(eBasicView.Sled_Bbd,"");
//		SETCHAR(eBasicView.Gtin_Variant,"");
//		SETCHAR(eBasicView.Serialization_Level,"");
//		SETCHAR(eBasicView.Pl_Ref_Mat,"");
//		SETCHAR(eBasicView.Extmatlgrp,"");
//		SETCHAR(eBasicView.Uomusage,"");
//		SETCHAR(eBasicView.Pl_Ref_Mat_External,"");
//		SETCHAR(eBasicView.Pl_Ref_Mat_Guid,"");
//		SETCHAR(eBasicView.Pl_Ref_Mat_Version,"");
//
//		SETCHAR(eBasicViewx.Del_Flag,"");
//		SETCHAR(eBasicViewx.Matl_Group,"");
//		SETCHAR(eBasicViewx.Old_Mat_No,"");
//		SETCHAR(eBasicViewx.Po_Unit,"");
//		SETCHAR(eBasicViewx.Po_Unit_Iso,"");
//		SETCHAR(eBasicViewx.Doc_Format,"");
//		SETCHAR(eBasicViewx.Doc_Chg_No,"");
//		SETCHAR(eBasicViewx.Page_No,"");
//		SETCHAR(eBasicViewx.No_Sheets,"");
//		SETCHAR(eBasicViewx.Prod_Memo,"");
//		SETCHAR(eBasicViewx.Pageformat,"");
//		SETCHAR(eBasicViewx.Size_Dim,"");
//		SETCHAR(eBasicViewx.Basic_Matl,"");
//		SETCHAR(eBasicViewx.Std_Descr,"");
//		SETCHAR(eBasicViewx.Dsn_Office,"");
//		SETCHAR(eBasicViewx.Pur_Valkey,"");
//		SETCHAR(eBasicViewx.Net_Weight,"");
//		SETCHAR(eBasicViewx.Unit_Of_Wt,"");
//		SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"");
//		SETCHAR(eBasicViewx.Container,"");
//		SETCHAR(eBasicViewx.Stor_Conds,"");
//		SETCHAR(eBasicViewx.Temp_Conds,"");
//		SETCHAR(eBasicViewx.Trans_Grp,"");
//		SETCHAR(eBasicViewx.Haz_Mat_No,"");
//		SETCHAR(eBasicViewx.Division,"");
//		SETCHAR(eBasicViewx.Competitor,"");
//		SETCHAR(eBasicViewx.Qty_Gr_Gi,"");
//		SETCHAR(eBasicViewx.Proc_Rule,"");
//		SETCHAR(eBasicViewx.Sup_Source,"");
//		SETCHAR(eBasicViewx.Season,"");
//		SETCHAR(eBasicViewx.Label_Type,"");
//		SETCHAR(eBasicViewx.Label_Form,"");
//		SETCHAR(eBasicViewx.Prod_Hier,"");
//		SETCHAR(eBasicViewx.Cad_Id,"X");
//		SETCHAR(eBasicViewx.Allowed_Wt,"");
//		SETCHAR(eBasicViewx.Pack_Wt_Un,"");
//		SETCHAR(eBasicViewx.Pack_Wt_Un_Iso,"");
//		SETCHAR(eBasicViewx.Allwd_Vol,"");
//		SETCHAR(eBasicViewx.Pack_Vo_Un,"");
//		SETCHAR(eBasicViewx.Pack_Vo_Un_Iso,"");
//		SETCHAR(eBasicViewx.Wt_Tol_Lt,"");
//		SETCHAR(eBasicViewx.Vol_Tol_Lt,"");
//		SETCHAR(eBasicViewx.Var_Ord_Un,"");
//		SETCHAR(eBasicViewx.Batch_Mgmt,"");
//		SETCHAR(eBasicViewx.Sh_Mat_Typ,"");
//		SETCHAR(eBasicViewx.Fill_Level,"");
//		SETCHAR(eBasicViewx.Stack_Fact,"");
//		SETCHAR(eBasicViewx.Mat_Grp_Sm,"");
//		SETCHAR(eBasicViewx.Authoritygroup,"");
//		SETCHAR(eBasicViewx.Qm_Procmnt,"");
//		SETCHAR(eBasicViewx.Catprofile,"");
//		SETCHAR(eBasicViewx.Minremlife,"");
//		SETCHAR(eBasicViewx.Shelf_Life,"");
//		SETCHAR(eBasicViewx.Stor_Pct,"");
//		SETCHAR(eBasicViewx.Pur_Status,"");
//		SETCHAR(eBasicViewx.Sal_Status,"");
//		SETCHAR(eBasicViewx.Pvalidfrom,"");
//		SETCHAR(eBasicViewx.Svalidfrom,"");
//		SETCHAR(eBasicViewx.Envt_Rlvt,"");
//		SETCHAR(eBasicViewx.Prod_Alloc,"");
//		SETCHAR(eBasicViewx.Qual_Dik,"");
//		SETCHAR(eBasicViewx.Manu_Mat,"");
//		SETCHAR(eBasicViewx.Mfr_No,"");
//		SETCHAR(eBasicViewx.Inv_Mat_No,"");
//		SETCHAR(eBasicViewx.Manuf_Prof,"");
//		SETCHAR(eBasicViewx.Hazmatprof,"");
//		SETCHAR(eBasicViewx.High_Visc,"");
//		SETCHAR(eBasicViewx.Looseorliq,"");
//		SETCHAR(eBasicViewx.Closed_Box,"");
//		SETCHAR(eBasicViewx.Appd_B_Rec,"");
//		SETCHAR(eBasicViewx.Matcmpllvl,"");
//		SETCHAR(eBasicViewx.Par_Eff,"");
//		SETCHAR(eBasicViewx.Round_Up_Rule_Expiration_Date,"");
//		SETCHAR(eBasicViewx.Period_Ind_Expiration_Date,"");
//		SETCHAR(eBasicViewx.Prod_Composition_On_Packaging,"");
//		SETCHAR(eBasicViewx.Item_Cat,"");
//		SETCHAR(eBasicViewx.Haz_Mat_No_External,"");
//		SETCHAR(eBasicViewx.Haz_Mat_No_Guid,"");
//		SETCHAR(eBasicViewx.Haz_Mat_No_Version,"");
//		SETCHAR(eBasicViewx.Inv_Mat_No_External,"");
//		SETCHAR(eBasicViewx.Inv_Mat_No_Guid,"");
//		SETCHAR(eBasicViewx.Inv_Mat_No_Version,"");
//		SETCHAR(eBasicViewx.Material_Fixed,"");
//		SETCHAR(eBasicViewx.Cm_Relevance_Flag,"");
//		SETCHAR(eBasicViewx.Sled_Bbd,"");
//		SETCHAR(eBasicViewx.Gtin_Variant,"");
//		SETCHAR(eBasicViewx.Serialization_Level,"");
//		SETCHAR(eBasicViewx.Pl_Ref_Mat,"");
//		SETCHAR(eBasicViewx.Extmatlgrp,"");
//		SETCHAR(eBasicViewx.Uomusage,"");
//		SETCHAR(eBasicViewx.Pl_Ref_Mat_External,"");
//		SETCHAR(eBasicViewx.Pl_Ref_Mat_Guid,"");
//		SETCHAR(eBasicViewx.Pl_Ref_Mat_Version,"");
//
//		SETCHAR(eMrpView.Del_Flag,"");
//		SETCHAR(eMrpView.Abc_Id,"");
//		SETCHAR(eMrpView.Crit_Part,"");
//		SETCHAR(eMrpView.Pur_Group,"");
//		SETCHAR(eMrpView.Issue_Unit,"");
//		SETCHAR(eMrpView.Issue_Unit_Iso,"");
//		SETCHAR(eMrpView.Mrpprofile,"");
//		SETCHAR(eMrpView.Mrp_Ctrler,"");
//		SETCHAR(eMrpView.Plnd_Delry,"0");
//		SETBCD(eMrpView.Gr_Pr_Time,"0",0);
//		SETCHAR(eMrpView.Period_Ind,"");
//		SETBCD(eMrpView.Assy_Scrap,myzeroDup2,2);
//		SETBCD(eMrpView.Safety_Stk,myzeroDup3,3);
//		SETBCD(eMrpView.Minlotsize,myzeroDup3,3);
//		SETBCD(eMrpView.Maxlotsize,myzeroDup3,3);
//		SETBCD(eMrpView.Fixed_Lot,myzeroDup3,3);
//		SETBCD(eMrpView.Round_Val,myzeroDup3,3);
//		SETBCD(eMrpView.Ord_Costs,myzeroDup4,4);
//		SETCHAR(eMrpView.Dep_Req_Id,"");
//		SETCHAR(eMrpView.Stor_Costs,"");
//		SETCHAR(eMrpView.Alt_Bom_Id,"");
//		SETCHAR(eMrpView.Discontinu,"");
//		SETCHAR(eMrpView.Eff_O_Day,"");
//		SETCHAR(eMrpView.Follow_Up,"");
//		SETCHAR(eMrpView.Grp_Reqmts,"");
//		SETCHAR(eMrpView.Mixed_Mrp,"");
//		SETCHAR(eMrpView.Backflush,"");
//		SETCHAR(eMrpView.Production_Scheduler,"");
//		SETBCD(eMrpView.Proc_Time,myzeroDup2,2);
//		SETBCD(eMrpView.Setuptime,myzeroDup2,2);
//		SETBCD(eMrpView.Interop,myzeroDup2,2);
//		SETBCD(eMrpView.Base_Qty,myzeroDup3,3);
//		SETBCD(eMrpView.Inhseprodt,"0",0);
//		SETBCD(eMrpView.Stgeperiod,"0",0);
//		SETCHAR(eMrpView.Stge_Pd_Un,"");
//		SETCHAR(eMrpView.Stge_Pd_Un_Iso,"");
//		SETBCD(eMrpView.Over_Tol,myzeroDup1,1);
//		SETCHAR(eMrpView.Unlimited,"");
//		SETBCD(eMrpView.Under_Tol,myzeroDup1,1);
//		SETBCD(eMrpView.Replentime,"0",0);
//		SETCHAR(eMrpView.Replace_Pt,"");
//		SETCHAR(eMrpView.Ind_Post_To_Insp_Stock,"");
//		SETCHAR(eMrpView.Doc_Reqd,"");
//		SETCHAR(eMrpView.Loadinggrp,"");
//		SETCHAR(eMrpView.Batch_Mgmt,"");
//		SETCHAR(eMrpView.Quotausage,"");
//		SETBCD(eMrpView.Serv_Level,myzeroDup1,1);
//		SETCHAR(eMrpView.Split_Ind,"");
//		SETCHAR(eMrpView.Availcheck,"");
//		SETCHAR(eMrpView.Fy_Variant,"");
//		SETCHAR(eMrpView.Corr_Fact,"");
//		SETBCD(eMrpView.Setup_Time,myzeroDup2,2);
//		SETBCD(eMrpView.Base_Qty_Plan,myzeroDup3,3);
//		SETBCD(eMrpView.Ship_Proc_Time,myzeroDup2,2);
//		SETCHAR(eMrpView.Sup_Source,"");
//		SETCHAR(eMrpView.Auto_P_Ord,"");
//		SETCHAR(eMrpView.Sourcelist,"");
//		SETCHAR(eMrpView.Comm_Code,"");
//		SETCHAR(eMrpView.Countryori,"");
//		SETCHAR(eMrpView.Countryori_Iso,"");
//		SETCHAR(eMrpView.Regionorig,"");
//		SETCHAR(eMrpView.Comm_Co_Un,"");
//		SETCHAR(eMrpView.Comm_Co_Un_Iso,"");
//		SETCHAR(eMrpView.Expimpgrp,"");
//		SETCHAR(eMrpView.Profit_Ctr,"");
//		SETCHAR(eMrpView.Ppc_Pl_Cal,"");
//		//SETCHAR(eMrpView.Rep_Manuf,"");
//		SETNUM(eMrpView.Pl_Ti_Fnce,"000");
//		SETCHAR(eMrpView.Consummode,"");
//		SETNUM(eMrpView.Bwd_Cons,"000");
//		SETNUM(eMrpView.Fwd_Cons,"000");
//		SETCHAR(eMrpView.Alternative_Bom,"");
//		SETCHAR(eMrpView.Bom_Usage,"");
//		SETCHAR(eMrpView.Planlistgrp,"");
//		SETCHAR(eMrpView.Planlistcnt,"");
//		SETBCD(eMrpView.Lot_Size,myzeroDup3,3);
//		SETCHAR(eMrpView.Specprocty,"");
//		SETCHAR(eMrpView.Prod_Unit,"");
//		SETCHAR(eMrpView.Prod_Unit_Iso,"");
//		//SETCHAR(eMrpView.Iss_St_Loc,"");
//		SETBCD(eMrpView.Comp_Scrap,myzeroDup2,2);
//		SETBCD(eMrpView.Cycle_Time,"0",0);
//		SETCHAR(eMrpView.Covprofile,"");
//		SETCHAR(eMrpView.Cc_Ph_Inv,"");
//		SETCHAR(eMrpView.Variance_Key,"");
//		SETCHAR(eMrpView.Serno_Prof,"");
//		//SETCHAR(eMrpView.Repmanprof,"");
//		SETCHAR(eMrpView.Neg_Stocks,"");
//		SETCHAR(eMrpView.Qm_Rgmts,"");
//		SETCHAR(eMrpView.Plng_Cycle,"");
//		SETCHAR(eMrpView.Round_Prof,"");
//		SETCHAR(eMrpView.Refmatcons,"");
//		SETCHAR(eMrpView.D_To_Ref_M,"");
//		SETBCD(eMrpView.Mult_Ref_M,myzeroDup2,2);
//		SETCHAR(eMrpView.Auto_Reset,"");
//		SETCHAR(eMrpView.Ex_Cert_Id,"");
//		SETCHAR(eMrpView.Ex_Cert_No_New,"");
//		SETCHAR(eMrpView.Ex_Cert_Dt,"");
//		SETCHAR(eMrpView.Milit_Id,"");
//		SETBCD(eMrpView.Insp_Int,"0",0);
//		SETCHAR(eMrpView.Co_Product,"");
//		SETCHAR(eMrpView.Plan_Strgp,"");
//		//SETCHAR(eMrpView.Sloc_Exprc,"");
//		SETCHAR(eMrpView.Bulk_Mat,"");
//		SETCHAR(eMrpView.Cc_Fixed,"");
//		SETCHAR(eMrpView.Determ_Grp,"");
//		SETCHAR(eMrpView.Qm_Authgrp,"");
//		SETCHAR(eMrpView.Task_List_Type,"");
//		SETCHAR(eMrpView.Pur_Status,"");
//		SETCHAR(eMrpView.Prodprof,"");
//		SETCHAR(eMrpView.Safty_T_Id,"");
//		SETNUM(eMrpView.Safetytime,"00");
//		SETCHAR(eMrpView.Plord_Ctrl,"");
//		SETCHAR(eMrpView.Batchentry,"");
//		SETDATE(eMrpView.Pvalidfrom,"");
//		SETCHAR(eMrpView.Matfrgtgrp,"");
//		SETCHAR(eMrpView.Prodverscs,"");
//		SETCHAR(eMrpView.Mat_Cfop,"");
//		SETCHAR(eMrpView.Eu_List_No,"");
//		SETCHAR(eMrpView.Eu_Mat_Grp,"");
//		SETCHAR(eMrpView.Cas_No,"");
//		SETCHAR(eMrpView.Prodcom_No,"");
//		SETCHAR(eMrpView.Ctrl_Code,"");
//		SETCHAR(eMrpView.Jit_Relvt,"");
//		SETCHAR(eMrpView.Mat_Grp_Trans,"");
//		SETCHAR(eMrpView.Handlg_Grp,"");
//		SETCHAR(eMrpView.Supply_Area,"");
//		SETCHAR(eMrpView.Fair_Share_Rule,"");
//		SETCHAR(eMrpView.Push_Distrib,"");
//		SETBCD(eMrpView.Deploy_Horiz,"0",0);
//		SETBCD(eMrpView.Min_Lot_Size,myzeroDup3,3);
//		SETBCD(eMrpView.Max_Lot_Size,myzeroDup3,3);
//		SETBCD(eMrpView.Fix_Lot_Size,myzeroDup3,3);
//		SETBCD(eMrpView.Lot_Increment,myzeroDup3,3);
//		SETCHAR(eMrpView.Prod_Conv_Type,"");
//		SETCHAR(eMrpView.Distr_Prof,"");
//		SETCHAR(eMrpView.Period_Profile_Safety_Time,"");
//		SETCHAR(eMrpView.Fxd_Price,"");
//		SETCHAR(eMrpView.Avail_Check_All_Proj_Segments,"");
//		SETCHAR(eMrpView.Overallprf,"");
//		SETCHAR(eMrpView.Mrp_Relevancy_Dep_Requirements,"");
//		SETBCD(eMrpView.Min_Safety_Stk,myzeroDup2,2);
//		SETCHAR(eMrpView.No_Costing,"");
//		SETCHAR(eMrpView.Unit_Group,"");
//		SETCHAR(eMrpView.Follow_Up_External,"");
//		SETCHAR(eMrpView.Follow_Up_Guid,"");
//		SETCHAR(eMrpView.Follow_Up_Version,"");
//		SETCHAR(eMrpView.Refmatcons_External,"");
//		SETCHAR(eMrpView.Refmatcons_Guid,"");
//		SETCHAR(eMrpView.Refmatcons_Version,"");
//		SETCHAR(eMrpView.Rotation_Date,"");
//		SETCHAR(eMrpView.Original_Batch_Flag,"");
//		SETCHAR(eMrpView.Original_Batch_Ref_Material,"");
//		SETCHAR(eMrpView.Original_Batch_Ref_Material_E,"");
//		SETCHAR(eMrpView.Original_Batch_Ref_Material_V,"");
//		SETCHAR(eMrpView.Original_Batch_Ref_Material_G,"");
//
//		SETCHAR(eMrpViewx.Del_Flag,"");
//		SETCHAR(eMrpViewx.Abc_Id,"");
//		SETCHAR(eMrpViewx.Crit_Part,"");
//		SETCHAR(eMrpViewx.Pur_Group,"");
//		SETCHAR(eMrpViewx.Issue_Unit,"");
//		SETCHAR(eMrpViewx.Issue_Unit_Iso,"");
//		SETCHAR(eMrpViewx.Mrpprofile,"");
//		SETCHAR(eMrpViewx.Mrp_Ctrler,"");
//		SETCHAR(eMrpViewx.Plnd_Delry,"");
//		SETCHAR(eMrpViewx.Gr_Pr_Time,"");
//		SETCHAR(eMrpViewx.Period_Ind,"");
//		SETCHAR(eMrpViewx.Assy_Scrap,"");
//		SETCHAR(eMrpViewx.Safety_Stk,"");
//		SETCHAR(eMrpViewx.Minlotsize,"");
//		SETCHAR(eMrpViewx.Maxlotsize,"");
//		SETCHAR(eMrpViewx.Fixed_Lot,"");
//		SETCHAR(eMrpViewx.Round_Val,"");
//		SETCHAR(eMrpViewx.Ord_Costs,"");
//		SETCHAR(eMrpViewx.Dep_Req_Id,"");
//		SETCHAR(eMrpViewx.Stor_Costs,"");
//		SETCHAR(eMrpViewx.Alt_Bom_Id,"");
//		SETCHAR(eMrpViewx.Discontinu,"");
//		SETCHAR(eMrpViewx.Eff_O_Day,"");
//		SETCHAR(eMrpViewx.Follow_Up,"");
//		SETCHAR(eMrpViewx.Grp_Reqmts,"");
//		SETCHAR(eMrpViewx.Mixed_Mrp,"");
//		SETCHAR(eMrpViewx.Backflush,"");
//		SETCHAR(eMrpViewx.Production_Scheduler,"");
//		SETCHAR(eMrpViewx.Proc_Time,"");
//		SETCHAR(eMrpViewx.Setuptime,"");
//		SETCHAR(eMrpViewx.Interop,"");
//		SETCHAR(eMrpViewx.Base_Qty,"");
//		SETCHAR(eMrpViewx.Inhseprodt,"");
//		SETCHAR(eMrpViewx.Stgeperiod,"");
//		SETCHAR(eMrpViewx.Stge_Pd_Un,"");
//		SETCHAR(eMrpViewx.Stge_Pd_Un_Iso,"");
//		SETCHAR(eMrpViewx.Over_Tol,"");
//		SETCHAR(eMrpViewx.Unlimited,"");
//		SETCHAR(eMrpViewx.Under_Tol,"");
//		SETCHAR(eMrpViewx.Replentime,"");
//		SETCHAR(eMrpViewx.Replace_Pt,"");
//		SETCHAR(eMrpViewx.Ind_Post_To_Insp_Stock,"");
//		SETCHAR(eMrpViewx.Doc_Reqd,"");
//		SETCHAR(eMrpViewx.Loadinggrp,"");
//		SETCHAR(eMrpViewx.Batch_Mgmt,"");
//		SETCHAR(eMrpViewx.Quotausage,"");
//		SETCHAR(eMrpViewx.Serv_Level,"");
//		SETCHAR(eMrpViewx.Split_Ind,"");
//		SETCHAR(eMrpViewx.Availcheck,"");
//		SETCHAR(eMrpViewx.Fy_Variant,"");
//		SETCHAR(eMrpViewx.Corr_Fact,"");
//		SETCHAR(eMrpViewx.Setup_Time,"");
//		SETCHAR(eMrpViewx.Base_Qty_Plan,"");
//		SETCHAR(eMrpViewx.Ship_Proc_Time,"");
//		SETCHAR(eMrpViewx.Sup_Source,"");
//		SETCHAR(eMrpViewx.Auto_P_Ord,"");
//		SETCHAR(eMrpViewx.Sourcelist,"");
//		SETCHAR(eMrpViewx.Comm_Code,"");
//		SETCHAR(eMrpViewx.Countryori,"");
//		SETCHAR(eMrpViewx.Countryori_Iso,"");
//		SETCHAR(eMrpViewx.Regionorig,"");
//		SETCHAR(eMrpViewx.Comm_Co_Un,"");
//		SETCHAR(eMrpViewx.Comm_Co_Un_Iso,"");
//		SETCHAR(eMrpViewx.Expimpgrp,"");
//		SETCHAR(eMrpViewx.Profit_Ctr,"");
//		SETCHAR(eMrpViewx.Ppc_Pl_Cal,"");
//		//SETCHAR(eMrpViewx.Rep_Manuf,"");
//		SETCHAR(eMrpViewx.Pl_Ti_Fncve,"");
//		SETCHAR(eMrpViewx.Consummode,"");
//		SETCHAR(eMrpViewx.Bwd_Cons,"");
//		SETCHAR(eMrpViewx.Fwd_Cons,"");
//		SETCHAR(eMrpViewx.Alternative_Bom,"");
//		SETCHAR(eMrpViewx.Bom_Usage,"");
//		SETCHAR(eMrpViewx.Planlistgrp,"");
//		SETCHAR(eMrpViewx.Planlistcnt,"");
//		SETCHAR(eMrpViewx.Lot_Size,"");
//		SETCHAR(eMrpViewx.Specprocty,"");
//		SETCHAR(eMrpViewx.Prod_Unit,"");
//		SETCHAR(eMrpViewx.Prod_Unit_Iso,"");
//		//SETCHAR(eMrpViewx.Iss_St_Loc,"");
//		SETCHAR(eMrpViewx.Comp_Scrap,"");
//		SETCHAR(eMrpViewx.Cycle_Time,"");
//		SETCHAR(eMrpViewx.Covprofile,"");
//		SETCHAR(eMrpViewx.Cc_Ph_Inv,"");
//		SETCHAR(eMrpViewx.Variance_Key,"");
//		SETCHAR(eMrpViewx.Serno_Prof,"");
//		//SETCHAR(eMrpViewx.Repmanprof,"");
//		SETCHAR(eMrpViewx.Neg_Stocks,"");
//		SETCHAR(eMrpViewx.Qm_Rgmts,"");
//		SETCHAR(eMrpViewx.Plng_Cycle,"");
//		SETCHAR(eMrpViewx.Round_Prof,"");
//		SETCHAR(eMrpViewx.Refmatcons,"");
//		SETCHAR(eMrpViewx.D_To_Ref_M,"");
//		SETCHAR(eMrpViewx.Mult_Ref_M,"");
//		SETCHAR(eMrpViewx.Auto_Reset,"");
//		SETCHAR(eMrpViewx.Ex_Cert_Id,"");
//		SETCHAR(eMrpViewx.Ex_Cert_No_New,"");
//		SETCHAR(eMrpViewx.Ex_Cert_Dt,"");
//		SETCHAR(eMrpViewx.Milit_Id,"");
//		SETCHAR(eMrpViewx.Insp_Int,"");
//		SETCHAR(eMrpViewx.Co_Product,"");
//		SETCHAR(eMrpViewx.Plan_Strgp,"");
//		//SETCHAR(eMrpViewx.Sloc_Exprc,"");
//		SETCHAR(eMrpViewx.Bulk_Mat,"");
//		SETCHAR(eMrpViewx.Cc_Fixed,"");
//		SETCHAR(eMrpViewx.Determ_Grp,"");
//		SETCHAR(eMrpViewx.Qm_Authgrp,"");
//		SETCHAR(eMrpViewx.Task_List_Type,"");
//		SETCHAR(eMrpViewx.Pur_Status,"");
//		SETCHAR(eMrpViewx.Prodprof,"");
//		SETCHAR(eMrpViewx.Safty_T_Id,"");
//		SETCHAR(eMrpViewx.Safetytime,"");
//		SETCHAR(eMrpViewx.Plord_Ctrl,"");
//		SETCHAR(eMrpViewx.Batchentry,"");
//		SETCHAR(eMrpViewx.Pvalidfrom,"");
//		SETCHAR(eMrpViewx.Matfrgtgrp,"");
//		SETCHAR(eMrpViewx.Prodverscs,"");
//		SETCHAR(eMrpViewx.Mat_Cfop,"");
//		SETCHAR(eMrpViewx.Eu_List_No,"");
//		SETCHAR(eMrpViewx.Eu_Mat_Grp,"");
//		SETCHAR(eMrpViewx.Cas_No,"");
//		SETCHAR(eMrpViewx.Prodcom_No,"");
//		SETCHAR(eMrpViewx.Ctrl_Code,"");
//		SETCHAR(eMrpViewx.Jit_Relvt,"");
//		SETCHAR(eMrpViewx.Mat_Grp_Trans,"");
//		SETCHAR(eMrpViewx.Handlg_Grp,"");
//		SETCHAR(eMrpViewx.Supply_Area,"");
//		SETCHAR(eMrpViewx.Fair_Share_Rule,"");
//		SETCHAR(eMrpViewx.Push_Distrib,"");
//		SETCHAR(eMrpViewx.Deploy_Horiz,"");
//		SETCHAR(eMrpViewx.Min_Lot_Size,"");
//		SETCHAR(eMrpViewx.Max_Lot_Size,"");
//		SETCHAR(eMrpViewx.Fix_Lot_Size,"");
//		SETCHAR(eMrpViewx.Lot_Increment,"");
//		SETCHAR(eMrpViewx.Prod_Conv_Type,"");
//		SETCHAR(eMrpViewx.Distr_Prof,"");
//		SETCHAR(eMrpViewx.Period_Profile_Safety_Time,"");
//		SETCHAR(eMrpViewx.Fxd_Price,"");
//		SETCHAR(eMrpViewx.Avail_Check_All_Proj_Segments,"");
//		SETCHAR(eMrpViewx.Overallprf,"");
//		SETCHAR(eMrpViewx.Mrp_Relevancy_Dep_Requirements,"");
//		SETCHAR(eMrpViewx.Min_Safety_Stk,"");
//		SETCHAR(eMrpViewx.No_Costing,"");
//		SETCHAR(eMrpViewx.Unit_Group,"");
//		SETCHAR(eMrpViewx.Follow_Up_External,"");
//		SETCHAR(eMrpViewx.Follow_Up_Guid,"");
//		SETCHAR(eMrpViewx.Follow_Up_Version,"");
//		SETCHAR(eMrpViewx.Refmatcons_External,"");
//		SETCHAR(eMrpViewx.Refmatcons_Guid,"");
//		SETCHAR(eMrpViewx.Refmatcons_Version,"");
//		SETCHAR(eMrpViewx.Rotation_Date,"");
//		SETCHAR(eMrpViewx.Original_Batch_Flag,"");
//		SETCHAR(eMrpViewx.Original_Batch_Ref_Material,"");
//		SETCHAR(eMrpViewx.Original_Batch_Ref_Material_E,"");
//		SETCHAR(eMrpViewx.Original_Batch_Ref_Material_V,"");
//		SETCHAR(eMrpViewx.Original_Batch_Ref_Material_G,"");
//
//		if(tc_strlen(rep_mfg)>0)		//rep_mfg modified on 14.02.2017 for TE02
//		{
//			SETCHAR(eMrpView.Rep_Manuf,"X");/*rep_mfg_in*/
//			SETCHAR(eMrpViewx.Rep_Manuf,"X");/*X*/
//			SETCHAR(eMrpView.Repmanprof,rep_mfg);/*rep_mfg*/
//			SETCHAR(eMrpViewx.Repmanprof,"X");/*X*/
//		}
//		else
//		{
//			SETCHAR(eMrpView.Rep_Manuf,"");/*rep_mfg_in*/
//			SETCHAR(eMrpViewx.Rep_Manuf,"X");/*X*/
//			SETCHAR(eMrpView.Repmanprof,"");/*rep_mfg*/
//			SETCHAR(eMrpViewx.Repmanprof,"X");/*X*/
//		}
//
//		SETCHAR(eBapi_Mpgd.Plng_Matl,"");
//		SETCHAR(eBapi_Mpgd.Plng_Plant,"");
//		SETCHAR(eBapi_Mpgd.Convfactor,"");
//		SETCHAR(eBapi_Mpgd.Plng_Matl_External,"");
//		SETCHAR(eBapi_Mpgd.Plng_Matl_Guid,"");
//		SETCHAR(eBapi_Mpgd.Plng_Matl_Version,"");
//
//		SETCHAR(eBapi_Mpgdx.Plng_Matl,"");
//		SETCHAR(eBapi_Mpgdx.Plng_Plant,"");
//		SETCHAR(eBapi_Mpgdx.Convfactor,"");
//		SETCHAR(eBapi_Mpgdx.Plng_Matl_External,"");
//		SETCHAR(eBapi_Mpgdx.Plng_Matl_Guid,"");
//		SETCHAR(eBapi_Mpgdx.Plng_Matl_Version,"");
//
//		SETCHAR(eBapi_Mard.Stge_Loc,"9005");
//		SETCHAR(eBapi_Mard.Del_Flag,"");
//		SETCHAR(eBapi_Mard.Mrp_Ind,"");
//		SETCHAR(eBapi_Mard.Spec_Proc,"");
//		SETBCD(eBapi_Mard.Reorder_Pt,myzeroDup3,3);
//		SETBCD(eBapi_Mard.Repl_Qty,myzeroDup3,3);
//		SETCHAR(eBapi_Mard.Stge_Bin,"");
//		SETCHAR(eBapi_Mard.Pickg_Area,"");
//		SETFLOAT(&eBapi_Mard.Inv_Corr_Fac,"");
//
//		SETCHAR(eBapi_Mardx.Stge_Loc,"9005");
//		SETCHAR(eBapi_Mardx.Del_Flag,"");
//		SETCHAR(eBapi_Mardx.Mrp_Ind,"");
//		SETCHAR(eBapi_Mardx.Spec_Proc,"");
//		SETCHAR(eBapi_Mardx.Reorder_Pt,"");
//		SETCHAR(eBapi_Mardx.Repl_Qty,"");
//		SETCHAR(eBapi_Mardx.Stge_Bin,"");
//		SETCHAR(eBapi_Mardx.Pickg_Area,"");
//		SETCHAR(eBapi_Mardx.Inv_Corr_Fac,"");
//
//		SETCHAR(eAccView.Val_Type,"");
//		SETCHAR(eAccView.Del_Flag,"");
//		SETCHAR(eAccView.Price_Ctrl,"");
//		SETBCD(eAccView.Moving_Pr,myzeroDup4,4);
//		SETBCD(eAccView.Std_Price,myzeroDup4,4);
//		SETBCD(eAccView.Price_Unit,"",0);
//		SETCHAR(eAccView.Pr_Ctrl_Pp,"");
//		SETBCD(eAccView.Mov_Pr_Pp,myzeroDup4,4);
//		SETBCD(eAccView.Std_Pr_Pp,myzeroDup4,4);
//		SETBCD(eAccView.Pr_Unit_Pp,"0",1);
//		SETCHAR(eAccView.Vclass_Pp,"");
//		SETCHAR(eAccView.Pr_Ctrl_Py,"");
//		SETBCD(eAccView.Mov_Pr_Py,myzeroDup4,4);
//		SETBCD(eAccView.Std_Pr_Py,myzeroDup4,4);
//		SETCHAR(eAccView.Vclass_Py,"");
//		SETBCD(eAccView.Pr_Unit_Py,"0",0);
//		SETCHAR(eAccView.Val_Cat,"");
//		SETBCD(eAccView.Future_Pr,myzeroDup4,4);
//		SETDATE(eAccView.Valid_From,"");
//		SETBCD(eAccView.Taxprice_1,myzeroDup4,4);
//		SETBCD(eAccView.Commprice1,myzeroDup4,4);
//		SETBCD(eAccView.Taxprice_3,myzeroDup4,4);
//		SETBCD(eAccView.Commprice3,myzeroDup4,4);
//		SETBCD(eAccView.Plnd_Price,myzeroDup4,4);
//		SETBCD(eAccView.Plndprice1,myzeroDup4,4);
//		SETBCD(eAccView.Plndprice2,myzeroDup4,4);
//		SETBCD(eAccView.Plndprice3,myzeroDup4,4);
//		SETDATE(eAccView.Plndprdate1,"");
//		SETDATE(eAccView.Plndprdate2,"");
//		SETDATE(eAccView.Plndprdate3,"");
//		SETCHAR(eAccView.Lifo_Fifo,"");
//		SETCHAR(eAccView.Poolnumber,"");
//		SETBCD(eAccView.Taxprice_2,myzeroDup4,4);
//		SETBCD(eAccView.Commprice2,myzeroDup4,4);
//		SETNUM(eAccView.Deval_Ind,"00");
//		SETCHAR(eAccView.Qty_Struct,"");
//		SETCHAR(eAccView.Ml_Active,"");
//		SETCHAR(eAccView.Ml_Settle,"");
//		SETCHAR(eAccView.Orig_Mat,"X");
//		SETCHAR(eAccView.Vm_So_Stk,"");
//		SETCHAR(eAccView.Vm_P_Stock,"");
//		SETCHAR(eAccView.Matl_Usage,"");
//		SETCHAR(eAccView.Mat_Origin,"");
//		SETCHAR(eAccView.In_House,"");
//		SETBCD(eAccView.Tax_Cml_Un,"0",0);
//
//		SETCHAR(eAccViewx.Val_Type,"");
//		SETCHAR(eAccViewx.Del_Flag,"");
//		SETCHAR(eAccViewx.Price_Ctrl,"");
//		SETCHAR(eAccViewx.Moving_Pr,"");
//		SETCHAR(eAccViewx.Std_Price,"");
//		SETCHAR(eAccViewx.Price_Unit,"");
//		SETCHAR(eAccViewx.Pr_Ctrl_Pp,"");
//		SETCHAR(eAccViewx.Mov_Pr_Pp,"");
//		SETCHAR(eAccViewx.Std_Pr_Pp,"");
//		SETCHAR(eAccViewx.Pr_Unit_Pp,"");
//		SETCHAR(eAccViewx.Vclass_Pp,"");
//		SETCHAR(eAccViewx.Pr_Ctrl_Py,"");
//		SETCHAR(eAccViewx.Mov_Pr_Py,"");
//		SETCHAR(eAccViewx.Std_Pr_Py,"");
//		SETCHAR(eAccViewx.Vclass_Py,"");
//		SETCHAR(eAccViewx.Pr_Unit_Py,"");
//		SETCHAR(eAccViewx.Val_Cat,"");
//		SETCHAR(eAccViewx.Future_Pr,"");
//		SETCHAR(eAccViewx.Valid_From,"");
//		SETCHAR(eAccViewx.Taxprice_1,"");
//		SETCHAR(eAccViewx.Commprice1,"");
//		SETCHAR(eAccViewx.Taxprice_3,"");
//		SETCHAR(eAccViewx.Commprice3,"");
//		SETCHAR(eAccViewx.Plnd_Price,"");
//		SETCHAR(eAccViewx.Plndprice1,"");
//		SETCHAR(eAccViewx.Plndprice2,"");
//		SETCHAR(eAccViewx.Plndprice3,"");
//		SETCHAR(eAccViewx.Plndprdate1,"");
//		SETCHAR(eAccViewx.Plndprdate2,"");
//		SETCHAR(eAccViewx.Plndprdate3,"");
//		SETCHAR(eAccViewx.Lifo_Fifo,"");
//		SETCHAR(eAccViewx.Poolnumber,"");
//		SETCHAR(eAccViewx.Taxprice_2,"");
//		SETCHAR(eAccViewx.Commprice2,"");
//		SETCHAR(eAccViewx.Deval_Ind,"");
//		SETCHAR(eAccViewx.Qty_Struct,"");
//		SETCHAR(eAccViewx.Ml_Active,"");
//		SETCHAR(eAccViewx.Ml_Settle,"");
//		SETCHAR(eAccViewx.Orig_Mat,"X");
//		SETCHAR(eAccViewx.Vm_So_Stk,"");
//		SETCHAR(eAccViewx.Vm_P_Stock,"");
//		SETCHAR(eAccViewx.Matl_Usage,"");
//		SETCHAR(eAccViewx.Mat_Origin,"");
//		SETCHAR(eAccViewx.In_House,"");
//		SETCHAR(eAccViewx.Tax_Cml_Un,"");
//
//		SETCHAR(tBapi_Makt->Langu,"EN");
//		SETCHAR(tBapi_Makt->Langu_Iso,"EN");
//		SETCHAR(tBapi_Makt->Del_Flag,"");
//
//		SETBCD(tBapi_Marm->Numerator,"1",0);
//		SETBCD(tBapi_Marm->Denominatr,"1",0);
//		SETCHAR(tBapi_Marm->Ean_Upc,"");
//		SETCHAR(tBapi_Marm->Ean_Cat,"");
//		SETCHAR(tBapi_Marm->Length,"");
//		SETCHAR(tBapi_Marm->Width,"");
//		SETCHAR(tBapi_Marm->Height,"");
//		SETCHAR(tBapi_Marm->Unit_Dim,"");
//		SETCHAR(tBapi_Marm->Unit_Dim_Iso,"");
//		SETBCD(tBapi_Marm->Volume,myzeroDup3,3);
//		SETCHAR(tBapi_Marm->VolumeUnit,"");
//		SETCHAR(tBapi_Marm->VolumeUnit_Iso,"");
//		SETBCD(tBapi_Marm->Gross_Wt,gross_wt,3);
//		SETCHAR(tBapi_Marm->Unit_Of_Wt,"");
//		SETCHAR(tBapi_Marm->Unit_Of_Wt_Iso,"");
//		SETCHAR(tBapi_Marm->Del_Flag,"");
//		SETCHAR(tBapi_Marm->Sub_Uom,"");
//		SETCHAR(tBapi_Marm->Sub_Uom_Iso,"");
//		SETCHAR(tBapi_Marm->Gtin_Variant,"");
//
//		SETCHAR(tBapi_Marmx->Numerator,"X");
//		SETCHAR(tBapi_Marmx->Denominatr,"X");
//		SETCHAR(tBapi_Marmx->Ean_Upc,"");
//		SETCHAR(tBapi_Marmx->Ean_Cat,"");
//		SETCHAR(tBapi_Marmx->Length,"");
//		SETCHAR(tBapi_Marmx->Width,"");
//		SETCHAR(tBapi_Marmx->Height,"");
//		SETCHAR(tBapi_Marmx->Unit_Dim,"");
//		SETCHAR(tBapi_Marmx->Unit_Dim_Iso,"");
//		SETCHAR(tBapi_Marmx->Volume,"");
//		SETCHAR(tBapi_Marmx->VolumeUnit,"");
//		SETCHAR(tBapi_Marmx->VolumeUnit_Iso,"");
//		SETCHAR(tBapi_Marmx->Gross_Wt,"");
//		SETCHAR(tBapi_Marmx->Unit_Of_Wt,"");
//		SETCHAR(tBapi_Marmx->Unit_Of_Wt_Iso,"");
//		SETCHAR(tBapi_Marmx->Sub_Uom,"");
//		SETCHAR(tBapi_Marmx->Sub_Uom_Iso,"");
//		SETCHAR(tBapi_Marmx->Gtin_Variant,"");
//		if (tc_strcmp(mat_type,"FERT")==0)
//		{
//			SETCHAR(eMrpView.Sm_Key,"000");//schedk
//			SETCHAR(eMrpViewx.Sm_Key,"");
//			SETCHAR(eMrpView.Ctrl_Key,control_key);
//			SETCHAR(eMrpViewx.Ctrl_Key,"");
//			SETCHAR(eMrpView.Cert_Type,certificate_type);
//			SETCHAR(eMrpViewx.Cert_Type,"");
//		}
//		else
//		{
//			SETCHAR(eMrpView.Sm_Key,"000");//schedk
//			SETCHAR(eMrpViewx.Sm_Key,"X");
//			SETCHAR(eMrpView.Ctrl_Key,control_key);
//			SETCHAR(eMrpViewx.Ctrl_Key,"X");
//			SETCHAR(eMrpView.Cert_Type,certificate_type);
//			SETCHAR(eMrpViewx.Cert_Type,"X");
//		}
//
//		SETCHAR(tBAPIE1PAREX3->STRUCTURE,"");//BAPI_TE_MARA
//		SETCHAR(tBAPIE1PAREX3->VALUEPART1,"");//part_noDupDes
//		SETCHAR(tBAPIE1PAREX3->VALUEPART2,"");
//		SETCHAR(tBAPIE1PAREX3->VALUEPART3,"");
//		SETCHAR(tBAPIE1PAREX3->VALUEPART4,"");
//
//		SETCHAR(tBAPIE1PAREXX3->STRUCTURE,"");//BAPI_TE_MARAX
//		SETCHAR(tBAPIE1PAREXX3->VALUEPART1,"");//part_noDupDesx
//		SETCHAR(tBAPIE1PAREXX3->VALUEPART2,"");
//		SETCHAR(tBAPIE1PAREXX3->VALUEPART3,"");
//		SETCHAR(tBAPIE1PAREXX3->VALUEPART4,"");
//
//		RfcRc = zbapi_material_savedata_mrp(hRfc,&eBapiMatHead,&eBasicView,&eBasicViewx,&eMrpView,&eMrpViewx,&eBapi_Mpgd,&eBapi_Mpgdx,&eBapi_Mard,&eBapi_Mardx,&eAccView,&eAccViewx,&eRmmg1_Aennr,&eBapiret2,thBapi_Makt,thBapi_Marm,thBapi_Marmx,thBAPIE1PAREX3,thBAPIE1PAREXX3,xException);
//
//		switch (RfcRc)
//		{
//			case RFC_OK:
//				//sprintf(sap_msg,"%.*s:",sizeof(sap_msg),eBapiret2.Message);
//				//GETCHAR(eBapiret2.Message,sap_msg);
//				printf("\nMessage for Material %s change: %s",part_noDup,eBapiret2.Message); fflush(stdout);
//				fprintf(fsuccess,"\nMessage for Material %s change: %s",part_noDup,eBapiret2.Message); fflush(fsuccess);
//
//				sprintf(a,"The material %s has been created or extended",part_noDup);
//
//				if (tc_strstr(eBapiret2.Message,a)!=NULL)
//				{
//
//					sprintf(Error_message,"The material %s has been created or extended",part_noDup);
//					tc_strcpy(MATstatus,"Y");
//					Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
//
//				}
//				else
//				{
//
//					tc_strcpy(MATstatus,"N");
//					tc_strcpy(Error_message,eBapiret2.Message);
//					Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
//
//				}
//
//				break;
//			case RFC_EXCEPTION:
//				printf("\nRFC EXCEPTION: %s",xException); fflush(stdout);
//				break;
//			case RFC_SYS_EXCEPTION:
//				printf("\nSYSTEM EXCEPTION RAISED!!!"); fflush(stdout);
//				break;
//			case RFC_FAILURE:
//				printf("\nFAILURE!!!"); fflush(stdout);
//				break;
//			default:
//				printf("\nOTHER FAILURE!"); fflush(stdout);
//				break;
//		}
//
//		if(ItDelete(thBapi_Makt) != 0)	rfc_error("ItDelete thBapi_Makt");
//		if(ItDelete(thBapi_Marm) != 0)	rfc_error("ItDelete tBapi_Marm");
//		if(ItDelete(thBapi_Marmx) != 0) rfc_error("ItDelete thBapi_Marmx");
//		if(ItDelete(thBAPIE1PAREX3) != 0) rfc_error("ItDelete thBAPIE1PAREX3");
//		if(ItDelete(thBAPIE1PAREXX3) != 0) rfc_error("ItDelete thBAPIE1PAREXX3");
//		//sleep(5);
//		RfcClose(hRfc);

        if(tc_strlen(store_locDup)>0 && tc_strcmp(store_locDup,"NA")!=0)
		{
			//if ((tc_strcmp(plantcode,"1001")==0) || (tc_strcmp(plantcode,"1500")==0) || (tc_strcmp(plantcode,"3100")==0) || (tc_strcmp(plantcode,"1100")==0)  || (tc_strcmp(plantcode,"1140")==0) )
			//if ((tc_strcmp(plantcode,"1001")==0) || (tc_strcmp(plantcode,"1500")==0) || (tc_strcmp(plantcode,"3100")==0) || (tc_strcmp(plantcode,"1100")==0)  || (tc_strcmp(plantcode,"1140")==0) || (tc_strcmp(plantcode,"2001")==0) )//added Hrishikesh 20.09.2023
			if ((tc_strcmp(plantcode,"1001")==0) || (tc_strcmp(plantcode,"1500")==0) || (tc_strcmp(plantcode,"3100")==0) || (tc_strcmp(plantcode,"1100")==0)  || (tc_strcmp(plantcode,"1140")==0) || (tc_strcmp(plantcode,"2001")==0) || (tc_strcmp(plantcode,"E201")==0) )//added Hrishikesh 02.10.2023
			{
				printf ("\n1 Going for Store location updation in MMSC, as plant is %s",plantcode);
				//mmsc_sloc_update();  //MMSC2025
			}
		}

//		//Store Loacation View Set
//		if(tc_strlen(store_locDup)>0 && tc_strcmp(store_locDup,"NA")!=0)
//		{
//			//if ((tc_strcmp(plantcode,"1001")==0) || (tc_strcmp(plantcode,"1500")==0) || (tc_strcmp(plantcode,"3100")==0) || (tc_strcmp(plantcode,"1100")==0)  || (tc_strcmp(plantcode,"1140")==0) )
//			//if ((tc_strcmp(plantcode,"1001")==0) || (tc_strcmp(plantcode,"1500")==0) || (tc_strcmp(plantcode,"3100")==0) || (tc_strcmp(plantcode,"1100")==0)  || (tc_strcmp(plantcode,"1140")==0) || (tc_strcmp(plantcode,"2001")==0))//added Hrishikesh 20.09.2023
//			if ((tc_strcmp(plantcode,"1001")==0) || (tc_strcmp(plantcode,"1500")==0) || (tc_strcmp(plantcode,"3100")==0) || (tc_strcmp(plantcode,"1100")==0)  || (tc_strcmp(plantcode,"1140")==0) || (tc_strcmp(plantcode,"2001")==0) || (tc_strcmp(plantcode,"E201")==0))//added Hrishikesh 02.10.2023
//			{
//				printf ("\n1 Going for Store location updation in MMSC, as plant is %s",plantcode);
//				hRfc = BapiLogon();
//				
//				SETCHAR(eBapiMatHead.Material,part_noDup);
//				SETCHAR(eBapiMatHead.Matl_Type,mat_type);
//				SETCHAR(eBapiMatHead.Ind_Sector,"M");
//				SETCHAR(eBapiMatHead.Basic_View,"");
//				SETCHAR(eBapiMatHead.Storage_View,"X");
//
//				SETCHAR(eBapi_Mard.Plant,plantcode);
//				SETCHAR(eBapi_Mard.Stge_Loc,store_locDup);
//				SETCHAR(eBapi_Mard.Del_Flag,"");
//				SETCHAR(eBapi_Mard.Mrp_Ind,"");
//				SETCHAR(eBapi_Mard.Spec_Proc,"");
//				SETBCD(eBapi_Mard.Reorder_Pt,myzeroDup3,3);
//				SETBCD(eBapi_Mard.Repl_Qty,myzeroDup3,3);
//				SETCHAR(eBapi_Mard.Stge_Bin,"");
//				SETCHAR(eBapi_Mard.Pickg_Area,"");
//				SETFLOAT(&eBapi_Mard.Inv_Corr_Fac,"");
//
//				SETCHAR(eBapi_Mardx.Plant,plantcode);
//				SETCHAR(eBapi_Mardx.Stge_Loc,store_locDup);
//				SETCHAR(eBapi_Mardx.Del_Flag,"");
//				SETCHAR(eBapi_Mardx.Mrp_Ind,"");
//				SETCHAR(eBapi_Mardx.Spec_Proc,"");
//				SETCHAR(eBapi_Mardx.Reorder_Pt,"");
//				SETCHAR(eBapi_Mardx.Repl_Qty,"");
//				SETCHAR(eBapi_Mardx.Stge_Bin,"");
//				SETCHAR(eBapi_Mardx.Pickg_Area,"");
//				SETCHAR(eBapi_Mardx.Inv_Corr_Fac,"");
//				
//				SETCHAR(eRmmg1_Aennr.Aennr,dml_no_arg);
//
//				RfcRc = BAPI_MATERIAL_MARD(hRfc,&eBapiMatHead,&eBapi_Mard,&eBapi_Mardx,&eRmmg1_Aennr,&eBapiret2,xException);
//
//				switch (RfcRc)
//				{
//					case RFC_OK:
//
//						printf("\nMessage for %s Store location update in MMSC : %s\n",part_noDup,eBapiret2.Message);
//						fprintf(fsuccess,"\nMessage for %s Store location update in MMSC : %s\n",part_noDup,eBapiret2.Message);
//
//						printf("\nStore loc updated in MMSC, part,plant : %s, %s, %s\n",store_locDup,part_noDup,plantcode);
//						fprintf(fsuccess,"\nStore loc updated in MMSC, part,plant : %s, %s, %s\n",store_locDup,part_noDup,plantcode);
//						break;
//					case RFC_EXCEPTION:
//						printf("\nRFC EXCEPTION: %s",xException);
//						break;
//					case RFC_SYS_EXCEPTION:
//						printf("\nSystem Exception Raised!!!");
//						break;
//					case RFC_FAILURE:
//						printf("\nFailure!!!");
//						break;
//					default:
//						printf("\nOther Failure!");
//					break;
//				}
//				RfcClose(hRfc);
//			}
//
//		}
	}
//	/*finished setting values for mat create and change*/
}

int create_mat_rev_in_sap ( char *data )
{
	struct memory chunk = {0};
	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	//const char *data = readd_sap_request_json_file();
	
	//printf("\nFile request content as below : %s",data);
	
	//curl_easy_setopt(curl, CURLOPT_URL, api_url);
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_REVISIONNUM_CHANGE_CV");//ccap_ecn_create DEV
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_REVISIONNUM_CHANGE_CV_QA");
	//curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	
	if ( tc_strcmp ( iSapServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_REVISIONNUM_CHANGE_CV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_REVISIONNUM_CHANGE_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_REVISIONNUM_CHANGE_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n iSapServer is Blank..!!");fflush(stdout);
	}
	
	list = curl_slist_append(list, "Content-Type: application/json");
    //curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);
	
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, 12L);
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\nFile request content as below "); fflush(stdout);
	//print_json_object ( data ) ;
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
		printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
		printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
		printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	//printf ("\nresponse : [%s] [%d]",chunk.response,strlen(chunk.response)) ;
	printf("\ncurl_easy_perform");fflush(stdout);
	//print_json_object ( chunk.response ) ;
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "MAT_REV");
	
		printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
		printf("\nfree"); fflush(stdout);
	
    curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}
int material_rev_json_cr ( char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3],char *json_mat_rev_cr_req_obj )
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	char *out;
	
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	cJSON_AddItemToObject(rfc_root, "ZPPRFC_REVISIONNUM_CHANGE", exp_imp_tab_req);
	
	cJSON_AddItemToObject(exp_imp_tab_req, "AENNR", cJSON_CreateString(sap_dml_no));
	cJSON_AddItemToObject(exp_imp_tab_req, "MATNR", cJSON_CreateString(sap_part_no));
	cJSON_AddItemToObject(exp_imp_tab_req, "REVLV", cJSON_CreateString(sap_rev_sheet_status));
	
	
	out = cJSON_Print(rfc_root);
	//printf("%s\n", out);
	tc_strcpy(json_mat_rev_cr_req_obj,out);
	free(out);
	cJSON_Delete(rfc_root);
	return 0;
}

int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3])
{
	char *json_mat_rev_cr_req_obj = NULL;
	json_mat_rev_cr_req_obj = malloc(34000);
	material_rev_json_cr ( sap_dml_no, sap_part_no, sap_rev_sheet_status, json_mat_rev_cr_req_obj );
	printf("%s\n", json_mat_rev_cr_req_obj);
	create_mat_rev_in_sap ( json_mat_rev_cr_req_obj );
	free(json_mat_rev_cr_req_obj);
}

int tm_curl_ZRFC_AC_VIEW_CREATE ( char *data )
{
	struct memory chunk = {0};
	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZRFC_AC_VIEW_CREATE_CV"); //DEV
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZRFC_AC_VIEW_CREATE_CV_QA");
	//curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	
	if ( tc_strcmp ( iSapServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZRFC_AC_VIEW_CREATE_CV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZRFC_AC_VIEW_CREATE_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_ZRFC_AC_VIEW_CREATE_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n iSapServer is Blank..!!");fflush(stdout);
	}
	
	list = curl_slist_append(list, "Content-Type: application/json");
    
	printf("\nFile request content as below "); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
	printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	
	res = curl_easy_perform(curl);
	
	printf("\ncurl_easy_perform");fflush(stdout);
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "Batch_Create");
	
	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
	printf("\nfree"); fflush(stdout);
	
    curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}

//int cll_ZRFC_AC_VIEW_CREATE( char *Part_no, char *plant, char *iSapServer,char *json_batches_create_req_obj)
int cll_ZRFC_AC_VIEW_CREATE( char *Part_no, char *plant, char *iSapServer,char* val_type,char* val_class,char *json_batches_create_req_obj)
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	char *out;
	
	
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	cJSON_AddItemToObject(rfc_root, "ZRFC_AC_VIEW_CREATE", exp_imp_tab_req);
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "BKLAS", cJSON_CreateString(val_class));
	cJSON_AddItemToObject(exp_imp_tab_req, "BWTAR", cJSON_CreateString(val_type));
	cJSON_AddItemToObject(exp_imp_tab_req, "MATNR", cJSON_CreateString(Part_no));
	cJSON_AddItemToObject(exp_imp_tab_req, "WERKS", cJSON_CreateString(plant));
	
	
	out = cJSON_Print(rfc_root);
	
	printf("\nRequest object for Batches create : %s\n", out);
	strcpy ( json_batches_create_req_obj, out );
	free(out);
	cJSON_Delete(rfc_root);
	
	return 0;
}

extern int ITK_user_main (int argc, char ** argv )
{
    int status;
	int d=0;
	int resultCount =0;
	int PartQryOutCount =0;
	int n_entries = 1; //no. of query input arg
	int two_entries = 2; //no. of query input arg

	int n_tags_found = 1;
	int ColCount = 0, cl = 0;

	//char  type_name[TCTYPE_name_size_c+1];
	char *type_name = NULL;

	tag_t		queryTag			= NULLTAG;
	tag_t		PartQueryTag		= NULLTAG;
	tag_t		*outTag				= NULLTAG;
	tag_t		DMLTag				= NULLTAG;
	tag_t		objTypeTag			= NULLTAG;
	tag_t		*DesignTags			= NULLTAG;
	tag_t		resultOutputTag		= NULLTAG;
	tag_t		relation_type		= NULLTAG;
	tag_t		PartRevTag			= NULLTAG;

	char* sUserName	= NULL;
	char* sPassword = NULL;

	char* DMLNum = NULL;
	//char* DMLDesc = NULL;
	char* DMLProjCode = NULL;
	char* DMLProjCodeDup = NULL;
	char* DMLRelType = NULL;
	char* DML_Owner = NULL;
	char* object_type = NULL;
	char* taskId = NULL;
	char* DateStr = NULL;
	
	char	*AllColRevSet	= NULL;
	tag_t	*AllColPartTags = NULLTAG;
	tag_t	ColPartTag = NULLTAG;
	char	*ColPartRev = NULL;
	int		PStrCount = 0, i=0, j=0;
	int		num_to_sort = 1;
	int		sort_order[1]  ={2};
	char	*keysAttr[1] = {"creation_date"};

	char	*PartRelStatus = NULL;
	char	**ColPartList =NULL;
	char	*RelRevNumber =NULL;
	char	*Lcs = NULL;

	Lcs = (char *) MEM_alloc(15);
	//tc_strcpy(Lcs,"T5_LcsErcRlzd");
	//tc_strcpy(Lcs,"T5_LcsStdRlzd");
	tc_strcpy(Lcs,"T5_LcsAplRlzd");

	tag_t	*ColPTags = NULLTAG;
	tag_t	ColPTag = NULLTAG;

	date_t APLRelDate;
	date_t STDRelDate;

	char* APLRelDateStr = NULL;
	char* STDRelDateStr = NULL;

    plantcode=(char *) malloc (500 * sizeof(char));
	apl_release_date=(char *) MEM_alloc(40 * sizeof(char));
	DMLDescription=(char *) MEM_alloc(50 * sizeof(char));
	profit_centre2 = (char *)malloc(500 * sizeof(char));
	plan_calendar2 = (char *)malloc(500 * sizeof(char));
	overhd_grp2 = (char *)malloc(500 * sizeof(char));
	origin_group2 = (char *)malloc(500 * sizeof(char));
	origin_group = (char *)malloc(500 * sizeof(char));
	iPlantCode=(char *) malloc( 500 * sizeof(char));
	mat_type=(char *) malloc(500 * sizeof(char));
	meas_unit=(char *) malloc(500 * sizeof(char));

	tmpDrwNum = (char *)malloc(500 * sizeof(char));
	tmpDrwNum1 = (char *)malloc(500 * sizeof(char));
	tmpDrwRev = (char *)malloc(500 * sizeof(char));
	tmpDrwSeq = (char *)malloc(500 * sizeof(char));

	sap_proc_type = (char *)malloc(500 * sizeof(char));
	sap_spproc_type = (char *)malloc(500 * sizeof(char));
	SAPpstat = (char *)malloc(500 * sizeof(char));
	MRPpstat = (char *)malloc(500 * sizeof(char));
	myzeroDup1 = (char *)malloc(500 * sizeof(char));
	myzeroDup2 = (char *)malloc(500 * sizeof(char));
	myzeroDup3 = (char *)malloc(500 * sizeof(char));
	myzeroDup4 = (char *)malloc(500 * sizeof(char));
	std_price = (char *)malloc(500 * sizeof(char));
	moving_avg_price = (char *)malloc(500 * sizeof(char));
	cost_lot_size = (char *)malloc(500 * sizeof(char));
	mat_type = (char *)malloc(500 * sizeof(char));
	descDup = (char *)malloc(500 * sizeof(char));
	reord_pt = (char *)malloc(500 * sizeof(char));

	part_noDupDes = (char *)malloc(500 * sizeof(char));
	part_noDupDesx = (char *)malloc(500 * sizeof(char));

	AllColRevSet     =  (char *) MEM_alloc(100000 * sizeof(char));

	PartNumber	= (char *) MEM_alloc(50 * sizeof(char));
	PartRev	= (char *) MEM_alloc(50 * sizeof(char));
	PartSeq	= (char *) MEM_alloc(50 * sizeof(char));
	Error_message	= (char *) MEM_alloc(200 * sizeof(char));
	MATstatus	= (char *) MEM_alloc(10 * sizeof(char));
	Parttype	= (char *) MEM_alloc(30 * sizeof(char));
	dml_no	= (char *) MEM_alloc(30 * sizeof(char));

	//char *qry_entries[1] = {"Name"};
	//char *qry_entries[1] = {"item_id"};
	char *PartQry_entries[] = {"Item ID","Release Status"};

	char *qry_entries[1] = {"ID"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char **PartQry_values = (char **) MEM_alloc(20 * sizeof(char *));

	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
	inputDml = ITK_ask_cli_argument("-d=");
	iSapServer = ITK_ask_cli_argument("-s=");

	if(tc_strcmp(sUserName,"")==0 || tc_strcmp(sPassword,"")==0 || tc_strcmp(inputDml,"")==0 || tc_strcmp(iSapServer,"")==0)
	{
		printf("\nAplDmlSapMatCreateUA -u=userid -p=password -d=inputDml -s=PVP/EVP/CVP\n");fflush(stdout);
		goto CLEANUP;
	}
    //sprintf(fsuccess_name,"%s/PLMSAP/PLM_SAP_APL_LOG/APL_Sap_Mat_%s_%s.log",getenv("ONLREP"),inputDml,iSapServer);
    //sprintf(fsuccess_name,"/home/uadev/devgroups/hps/PLMSAP/liveXfr/APL_Sap_Mat_%s_%s.log",inputDml,iSapServer);
	//sprintf(fsuccess_name,"/user/uaprodtrl/PLMSAP/PLM_SAP_APL_LOG/APL_Sap_Mat_%s.log",inputDml);
	sprintf(fsuccess_name,"APL_Sap_Mat_%s.log",inputDml);
	fsuccess = fopen(fsuccess_name,"a");

	if ((tc_strstr(inputDml,"APLC")!=NULL) || (tc_strstr(inputDml,"STDC")!=NULL))
	{
		tc_strdup("1100",&iPlantCode);

	}
	if ((tc_strstr(inputDml,"APLP")!=NULL) || (tc_strstr(inputDml,"STDP")!=NULL))
	{
		tc_strdup("1001",&iPlantCode);

	}
	if ((tc_strstr(inputDml,"APLD")!=NULL) || (tc_strstr(inputDml,"STDD")!=NULL))
	{
		tc_strdup("1500",&iPlantCode);

	}
	if ((tc_strstr(inputDml,"APLU")!=NULL) || (tc_strstr(inputDml,"STDU")!=NULL))
	{
		tc_strdup("3100",&iPlantCode);

	}
	if ((tc_strstr(inputDml,"APLJ")!=NULL) || (tc_strstr(inputDml,"STDJ")!=NULL))
	{
		tc_strdup("2001",&iPlantCode);

	}
	if ((tc_strstr(inputDml,"APLA")!=NULL) || (tc_strstr(inputDml,"STDA")!=NULL))
	{
		tc_strdup("E201",&iPlantCode);

	}

	printf("\ninputDml : [%s]",inputDml);
	printf("\niSapServer : [%s]",iSapServer);

		if (tc_strstr(inputDml,"APLC")!=NULL || 
			tc_strstr(inputDml,"STDC")!=NULL)
		{
			if 	(tc_strcmp(iSapServer,"EVP")==0 || 
				 tc_strcmp(iSapServer,"EVQ")==0 || 
				 tc_strcmp(iSapServer,"EVD")==0 || 
				 tc_strcmp(iSapServer,"CVP")==0 || 
				 tc_strcmp(iSapServer,"CVQ")==0 || 
				 tc_strcmp(iSapServer,"CVD")==0)
			{
			
				printf("\nDML %s Cannot Transfer to  %s\n",inputDml,iSapServer);
				fprintf(fsuccess,"\nDML %s Cannot Transfer to  %s\n",inputDml,iSapServer);
				goto CLEANUP;
			
			}//added Hrishikesh 07.02.2024
		}

		else if (tc_strstr(inputDml,"APLA")!=NULL || 
				 tc_strstr(inputDml,"STDA")!=NULL)
		{

			if 	(tc_strcmp(iSapServer,"PVP")==0 || 
				 tc_strcmp(iSapServer,"PVQ")==0 || 
				 tc_strcmp(iSapServer,"PVD")==0 || 
				 tc_strcmp(iSapServer,"CVP")==0 || 
				 tc_strcmp(iSapServer,"CVQ")==0 || 
				 tc_strcmp(iSapServer,"CVD")==0)
			{
			
				printf("\nDML %s Cannot Transfer to  %s\n",inputDml,iSapServer);
				fprintf(fsuccess,"\nDML %s Cannot Transfer to  %s\n",inputDml,iSapServer);
				goto CLEANUP;
			
			}//added Hrishikesh 07.02.2024
		}

		else if (tc_strstr(inputDml,"APLP")!=NULL || 
				 tc_strstr(inputDml,"APLU")!=NULL || 
				 tc_strstr(inputDml,"APLD")!=NULL || 
				 tc_strstr(inputDml,"STDP")!=NULL || 
				 tc_strstr(inputDml,"STDU")!=NULL || 
				 tc_strstr(inputDml,"STDD")!=NULL ) 
		{

			if (tc_strcmp(iSapServer,"PVP")==0 || 
				tc_strcmp(iSapServer,"PVD")==0 || 
				tc_strcmp(iSapServer,"PVQ")==0 || 
				tc_strcmp(iSapServer,"EVP")==0 || 
				tc_strcmp(iSapServer,"EVD")==0 || 
				tc_strcmp(iSapServer,"EVQ")==0)
			{	
				printf("\nDML %s Cannot Transfer to  %s\n",inputDml,iSapServer);
				fprintf(fsuccess,"\nDML %s Cannot Transfer to  %s\n",inputDml,iSapServer);
				goto CLEANUP;
			
			}//added Hrishikesh 07.02.2024
		}


	//if(QRY_find("APLDML_Query", &queryTag));
	if(QRY_find2("Driver VC Query", &PartQueryTag));
	if(QRY_find2("APLDMLRevisionQry", &queryTag));
	if (queryTag)
	{
		printf("\nQuery Found : APLDMLRevisionQry\n");fflush(stdout);
	}
	else
	{
		printf("\nQuery NotFound : APLDMLRevisionQry\n");fflush(stdout);
		goto CLEANUP;
	}
	printf("\nAfter QRY_find2 : APLDMLRevisionQry\n");fflush(stdout);
    printf("\nInput APL DML : %s\n ", inputDml);fflush(stdout);

    qry_values[0] = inputDml;

	//if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &outTag));
	ITK_CALL(QRY_execute_with_sort(queryTag, n_entries, qry_entries, qry_values,num_to_sort,keysAttr,sort_order, &resultCount, &outTag));

    printf("\nResultCount :%d:\n", resultCount);fflush(stdout);

	if(resultCount>0)
	{
		for (d = 0;d < resultCount ; d++ )
		{
			DMLTag = outTag[d];
		
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	//if(TCTYPE_ask_name(objTypeTag,type_name));
		if(TCTYPE_ask_name2(objTypeTag,&type_name));
	    printf("\nInput APL DML Object Type : [%s]\n",type_name);fflush(stdout);
		printf("\nQuery Executed...\n");fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(DMLTag,"current_id",&DMLNum));
		ITK_CALL(AOM_UIF_ask_value(DMLTag,"t5_cprojectcode",&DMLProjCode));
		ITK_CALL(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLRelType));
		ITK_CALL(AOM_UIF_ask_value(DMLTag,"current_desc",&DMLDesc));
		ITK_CALL(AOM_UIF_ask_value(DMLTag,"release_status_list",&DMLRelStatus));
		ITK_CALL(AOM_UIF_ask_value(DMLTag,"owning_user",&DML_Owner));
		ITK_CALL(AOM_ask_value_string(DMLTag,"t5_EcnType",&DMLEcnType));

		ITK_CALL(AOM_ask_value_date(DMLTag,"t5_APLReleaseDate",&APLRelDate));
		ITK_CALL(DATE_date_to_string(APLRelDate,"%d/%m/%Y",&APLRelDateStr));
		
		ITK_CALL(AOM_ask_value_date(DMLTag,"date_released",&STDRelDate));
		ITK_CALL(DATE_date_to_string(STDRelDate,"%d/%m/%Y",&STDRelDateStr));
		
		ITK_CALL(ITK_date_to_string(APLRelDate,&DateStr));
		tc_strcpy(dml_no,DMLNum);

		printf("\nDML Release Type ECN Type : [%s,%s]",DMLRelType,DMLEcnType);
		if(tc_strcmp(DMLRelType,"TODR")==0)
		{
			printf("\nSkipping DML from material creation change as DML [%s] Release Type [%s]\n",DMLNum,DMLRelType);
			goto CLEANUP;
		}
		
		printf("\nDMLRelStatus : [%s]",DMLRelStatus);

		//if(tc_strstr(DMLRelStatus,"APLC Released")!=NULL)
		//added Hrishikesh 12.07.2023
		if((tc_strcmp(iPlantCode,"1100")==0 && tc_strstr(DMLRelStatus,"APLC Released")!=NULL)||
		   (tc_strcmp(iPlantCode,"1001")==0 && tc_strstr(DMLRelStatus,"APLP Released")!=NULL)||
		   (tc_strcmp(iPlantCode,"1500")==0 && tc_strstr(DMLRelStatus,"APLD Released")!=NULL)||
		   (tc_strcmp(iPlantCode,"3100")==0 && tc_strstr(DMLRelStatus,"APLU Released")!=NULL)||
		   (tc_strcmp(iPlantCode,"2001")==0 && tc_strstr(DMLRelStatus,"APLJ Released")!=NULL)||
		   (tc_strcmp(iPlantCode,"E201")==0 && tc_strstr(DMLRelStatus,"APLA Released")!=NULL)) //added Hrishikesh 02.10.2023
		{
			if (tc_strlen(APLRelDateStr)!=10)
			{
				printf("\nDML Number [%s] APL Release Date is NULL..Exiting!\n",DMLNum,tc_strlen(DateStr));
				fprintf(fsuccess,"\nDML Number [%s] APL Release Date is NULL..Exiting!\n",DMLNum,tc_strlen(DateStr));
				tc_strcpy(MATstatus,"N");
				tc_strcpy(PartNumber,"NA");
				tc_strcpy(PartRev,"NA");
				tc_strcpy(PartSeq,"NA");
				tc_strcpy(Parttype,"NA");
				sprintf(Error_message,"DML Number [%s] APL Release Date is NULL..Exiting!",DMLNum,tc_strlen(DateStr));
				Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
				continue;
			}
		}

		//if [APLloader (aplloader)] skip DML transfer. - Check removed on 23-09-2020 as confirmed by APL/STD Team
		if(tc_strstr(DML_Owner,"APLloader")!=NULL || tc_strstr(DML_Owner,"aplloader")!=NULL)
		{
			printf("\nDML [%s] as DML Owner [%s]",DMLNum,DML_Owner);
			fprintf(fsuccess,"\nDML [%s] as DML Owner [%s]",DMLNum,DML_Owner);
			//goto CLEANUP;
		}

		tc_strdup(DMLNum,&DMLNumDup);
		tc_strdup(DMLProjCode,&DMLProjCodeDup);

		printf("\nDML Number [%s] Release Status [%s] APLReleaseDate [%s]\n",DMLNum,DMLRelStatus,APLRelDateStr);fflush(stdout);
		fprintf(fsuccess,"\nDML Number [%s] Release Status [%s] APLReleaseDate [%s]\n",DMLNum,DMLRelStatus,APLRelDateStr);fflush(stdout);

		//if(tc_strstr(DMLRelStatus,"STDSIC Released")==NULL)

		//added Hrishikesh 12.07.2023
		if((tc_strcmp(iPlantCode,"1100")==0 && tc_strstr(DMLRelStatus,"STDSIC Released")==NULL)||//added Hrishikesh 12.07.2023
		   (tc_strcmp(iPlantCode,"1001")==0 && tc_strstr(DMLRelStatus,"STDSIP Released")==NULL)||//added Hrishikesh 12.07.2023
		   (tc_strcmp(iPlantCode,"1500")==0 && tc_strstr(DMLRelStatus,"STDSID Released")==NULL)||//added Hrishikesh 12.07.2023
		   (tc_strcmp(iPlantCode,"3100")==0 && tc_strstr(DMLRelStatus,"STDSIU Released")==NULL)|| //added Hrishikesh 12.07.2023
		   (tc_strcmp(iPlantCode,"2001")==0 && tc_strstr(DMLRelStatus,"STDSIJ Released")==NULL)|| //added Hrishikesh 20.09.2023
		   (tc_strcmp(iPlantCode,"E201")==0 && tc_strstr(DMLRelStatus,"STDSIA Released")==NULL)) //added Hrishikesh 02.10.2023
		{
			//if(tc_strstr(DMLRelStatus,"APLC Released")!=NULL)

			if((tc_strcmp(iPlantCode,"1100")==0 && tc_strstr(DMLRelStatus,"APLC Released")!=NULL)||//added Hrishikesh 12.07.2023
			   (tc_strcmp(iPlantCode,"1001")==0 && tc_strstr(DMLRelStatus,"APLP Released")!=NULL)||//added Hrishikesh 12.07.2023
			   (tc_strcmp(iPlantCode,"1500")==0 && tc_strstr(DMLRelStatus,"APLD Released")!=NULL)||//added Hrishikesh 12.07.2023
			   (tc_strcmp(iPlantCode,"3100")==0 && tc_strstr(DMLRelStatus,"APLU Released")!=NULL)|| //added Hrishikesh 12.07.2023
			   (tc_strcmp(iPlantCode,"2001")==0 && tc_strstr(DMLRelStatus,"APLJ Released")!=NULL)|| //added Hrishikesh 20.09.2023
			   (tc_strcmp(iPlantCode,"E201")==0 && tc_strstr(DMLRelStatus,"APLA Released")!=NULL)) //added Hrishikesh 02.10.2023
			{
				printf("\nDML Number [%s] Release Type [%s] Project Code [%s]\n",DMLNum,DMLRelType,DMLProjCode);fflush(stdout);
				printf("\nRelease Status [%s] APLReleaseDate [%s] STD Released Date [%s]\n",DMLRelStatus,APLRelDateStr,STDRelDateStr);fflush(stdout);
				printf("\nDML Desc :%s\n",DMLDesc);fflush(stdout);
				printf("\nDMLNumDup :%s	DMLProjCodeDup : %s\n",DMLNumDup,DMLProjCodeDup);fflush(stdout);
			}
			else
			{
				printf("\nDML Number [%s] Release Status [%s] Not APL Released or Above...\n",DMLNum,DMLRelStatus);fflush(stdout);
				fprintf(fsuccess,"\nDML Number [%s] Release Status [%s] Not APL Released or Above...\n",DMLNum,DMLRelStatus);fflush(stdout);


				tc_strcpy(MATstatus,"N");
				tc_strcpy(PartNumber,"NA");
				tc_strcpy(PartRev,"NA");
				tc_strcpy(PartSeq,"NA");
				tc_strcpy(Parttype,"NA");
				sprintf(Error_message,"DML Number [%s] Release Status [%s] Not APL Released or Above...",DMLNum,DMLRelStatus);
				Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
				continue;
			}
		}

		//if(tc_strstr(DMLRelStatus,"STDSIC Released")!=NULL)
		if((tc_strcmp(iPlantCode,"1100")==0 && tc_strstr(DMLRelStatus,"STDSIC Released")!=NULL)||//added Hrishikesh 12.07.2023
		   (tc_strcmp(iPlantCode,"1001")==0 && tc_strstr(DMLRelStatus,"STDSIP Released")!=NULL)||//added Hrishikesh 12.07.2023
		   (tc_strcmp(iPlantCode,"1500")==0 && tc_strstr(DMLRelStatus,"STDSID Released")!=NULL)||//added Hrishikesh 12.07.2023
		   (tc_strcmp(iPlantCode,"3100")==0 && tc_strstr(DMLRelStatus,"STDSIU Released")!=NULL)|| //added Hrishikesh 12.07.2023
		   (tc_strcmp(iPlantCode,"2001")==0 && tc_strstr(DMLRelStatus,"STDSIJ Released")!=NULL)|| //added Hrishikesh 20.09.2023
		   (tc_strcmp(iPlantCode,"E201")==0 && tc_strstr(DMLRelStatus,"STDSIA Released")!=NULL)) //added Hrishikesh 02.10.2023
		{
			if (tc_strlen(STDRelDateStr)!=10)
			{
				printf("\nDML Number [%s] STD Release Date is NULL..Exiting!\n",DMLNum);
				fprintf(fsuccess,"\nDML Number [%s] STD Release Date is NULL..Exiting!\n",DMLNum);

				tc_strcpy(MATstatus,"N");
				tc_strcpy(PartNumber,"NA");
				tc_strcpy(PartRev,"NA");
				tc_strcpy(PartSeq,"NA");
				tc_strcpy(Parttype,"NA");
				sprintf(Error_message,"DML Number [%s] STD Release Date is NULL..Exiting!",DMLNum);
				Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
				continue;
			}
			else
			{
				tc_strdup(STDRelDateStr,&APLRelDateStr);
				printf("\nDML Number [%s] STD Release Date [%s]\n",DMLNum,STDRelDateStr);
				fprintf(fsuccess,"\nDML Number [%s] STD Release Date [%s]\n",DMLNum,STDRelDateStr);
			}
		}

		if(FetchPlantSpecificData(DMLNumDup,DMLProjCodeDup)>0)
		{
			printf("\nPlant Specific Data Found...\n");fflush(stdout);
			fprintf(fsuccess,"\nPlant Specific Data Found...\n");fflush(stdout);
		}
		else
		{
			printf("\nError in Fetching Plant Specific Data...\n");fflush(stdout);
			fprintf(fsuccess,"\nError in Fetching Plant Specific Data...\n");fflush(stdout);

			tc_strcpy(MATstatus,"N");
			tc_strcpy(PartNumber,"NA");
			tc_strcpy(PartRev,"NA");
			tc_strcpy(PartSeq,"NA");
			tc_strcpy(Parttype,"NA");
			tc_strcpy(Error_message,"Error in Fetching Plant Specific Data...");
			Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
			goto CLEANUP;
		}
		
		if(tc_strcmp(plantcode,"")==0)
		{
			printf("\nPlant code is null hence exit"); fflush(stdout);
			fprintf(fsuccess,"\nPlant code is null hence exit"); fflush(fsuccess);
			goto CLEANUP;
		}

		strcpy(myzeroDup1,"0.0");
		strcpy(myzeroDup2,"0.00");
		strcpy(myzeroDup3,"0.000");
		strcpy(myzeroDup4,"0.0000");

		if(tc_strlen(DMLDesc)<=5)
		{
			tc_strcpy(DMLDescription,DMLNum);
		}
		else
		{
			tc_strncpy(DMLDescription,DMLDesc,40);
		}
		//tc_strdup(DMLDesc,&DMLDescription);
		trimwhitespace(DMLDescription);

		//DmlReleasedDate [11/04/2018]
		strcpy(apl_release_date,"");
		strcpy(apl_release_date,strtok(APLRelDateStr,"/"));
		strcat(apl_release_date,".");
		strcat(apl_release_date,strtok(NULL,"/"));
		strcat(apl_release_date,".");
		strcat(apl_release_date,strtok(NULL,"/"));

		printf("\ndml_no_arg :%s",dml_no_arg);fflush(stdout);
		printf("\napl_release_date :%s",apl_release_date);fflush(stdout);
		printf("\nDMLDescription :%s",DMLDescription);fflush(stdout);

		/// Solution Item start
		GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
		ITK_CALL(GRM_list_secondary_objects_only(DMLTag,relation_type,&tcount,&TaskRevision));
		printf("\nAPL DML Revision to Task Count : %d",tcount);fflush(stdout);
		
		//change number creation
		if(tcount>0)
		{
			//displaying_objects(); //SAPPO2025
			cll_ccap_ecn_create();
		}

		for (TaskCnt=0;TaskCnt<tcount ;TaskCnt++ )
		{
			TaskRevTag = TaskRevision[TaskCnt];
			ITK_CALL(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
			ITK_CALL(AOM_ask_value_string(TaskRevTag,"item_id",&taskId));
			printf("\nTask ID [%s]	object_type : %s",taskId,object_type);fflush(stdout);
			
			pcount=0;
			ITK_CALL(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&pcount,&PartTags));
			printf("\nTask To Part Count : %d",pcount);fflush(stdout);

			for (PartCnt=0;PartCnt<pcount;PartCnt++)
			{
				PartRevTag=PartTags[PartCnt];
				//Part_CreateChangeFunction(PartRevTag);  //PLMSAPPO
				Part_CreateChangeFunction(PartRevTag,iSapServer);
				
				//if(tc_strstr(DMLRelStatus,"STDSIC Released")!=NULL)

				if((tc_strcmp(iPlantCode,"1100")==0 && tc_strstr(DMLRelStatus,"STDSIC Released")!=NULL)||//added Hrishikesh 12.07.2023
				   (tc_strcmp(iPlantCode,"1001")==0 && tc_strstr(DMLRelStatus,"STDSIP Released")!=NULL)||//added Hrishikesh 12.07.2023
				   (tc_strcmp(iPlantCode,"1500")==0 && tc_strstr(DMLRelStatus,"STDSID Released")!=NULL)||//added Hrishikesh 12.07.2023
				   (tc_strcmp(iPlantCode,"3100")==0 && tc_strstr(DMLRelStatus,"STDSIU Released")!=NULL)|| //added Hrishikesh 12.07.2023
				   (tc_strcmp(iPlantCode,"2001")==0 && tc_strstr(DMLRelStatus,"STDSIJ Released")!=NULL)||//added Hrishikesh 20.09.2023
				   (tc_strcmp(iPlantCode,"E201")==0 && tc_strstr(DMLRelStatus,"STDSIA Released")!=NULL)) //added Hrishikesh 02.10.2023
				{
					/****************************Going to Update Colour Part CS************************/
					ITK_CALL(AOM_UIF_ask_value(PartRevTag,"t5_ColourInd",&partClrInd));
					
					if (tc_strcmp(partClrInd,"Y")==0)
					{
						tc_strcpy (AllColRevSet,"" );
						printf("\nColourable Part Found...Going to Fetch Colour Parts for CS Update : %s",partClrInd);fflush(stdout);
						fprintf(fsuccess,"\nColourable Part Found...Going to Fetch Colour Parts for CS Update : %s",partClrInd);fflush(stdout);

						ITK_CALL(AOM_ask_value_tags(PartRevTag,"representation_for",&ColCount,&AllColPartTags));
						
						printf("\nColour Parts found in representation_for relation : %d",ColCount);fflush(stdout);
						fprintf(fsuccess,"\nColour Parts found in representation_for relation : %d",ColCount);fflush(stdout);
						if (ColCount==0)
						{
							continue;
						}

						for (cl=0 ; cl<ColCount ; cl++)
						{
							ColPartTag = AllColPartTags[cl];
							ITK_CALL(AOM_ask_value_string(ColPartTag,"item_id",&ColPartRev));
							//printf("\nColor Part : %s", ColPartRev);

							if(tc_strcmp(AllColRevSet,"")==0)
							{
								tc_strcpy (AllColRevSet,"" );
								tc_strcat (AllColRevSet,ColPartRev);
							}
							else
							{
								if(tc_strstr(AllColRevSet,ColPartRev)==NULL)
								{
									tc_strcat (AllColRevSet,"," );
									tc_strcat (AllColRevSet,ColPartRev);
									printf("\nPart added to AllColRevSet: %s",ColPartRev);	fflush(stdout);
								}
							}
						}

						ITK_CALL(EPM__parse_string(AllColRevSet,",",&PStrCount,&ColPartList));
						
						for ( i=0;i<PStrCount ;i++ )
						{
							printf("\nChecking Part : %s",ColPartList[i]);	fflush(stdout);

							PartQry_values[0] = ColPartList[i];
							PartQry_values[1] = Lcs;

							//1-Ascending 2- Descending
							ITK_CALL(QRY_execute_with_sort(PartQueryTag, two_entries, PartQry_entries, PartQry_values,num_to_sort,keysAttr,sort_order, &PartQryOutCount, &ColPTags));
							printf("\nPartQryOutCount : %d", PartQryOutCount);

							for (j=0;j< PartQryOutCount;j++ )
							{
								ColPTag=ColPTags[j];
								//ITK_CALL(AOM_ask_value_string(ColPTag,"item_revision_id",&RelRevNumber));
								ITK_CALL(AOM_UIF_ask_value(ColPTag,"release_status_list",&PartRelStatus));

								if((tc_strcmp(iPlantCode,"1100")==0 && tc_strstr(PartRelStatus,"APLC Released")!=NULL)||//added Hrishikesh 12.07.2023
								   (tc_strcmp(iPlantCode,"1001")==0 && tc_strstr(PartRelStatus,"APLP Released")!=NULL)||//added Hrishikesh 12.07.2023
								   (tc_strcmp(iPlantCode,"1500")==0 && tc_strstr(PartRelStatus,"APLD Released")!=NULL)||//added Hrishikesh 12.07.2023
								   (tc_strcmp(iPlantCode,"3100")==0 && tc_strstr(PartRelStatus,"APLU Released")!=NULL)|| //added Hrishikesh 12.07.2023
								   (tc_strcmp(iPlantCode,"2001")==0 && tc_strstr(PartRelStatus,"APLJ Released")!=NULL)|| //added Hrishikesh 12.07.2023
								   (tc_strcmp(iPlantCode,"E201")==0 && tc_strstr(PartRelStatus,"APLA Released")!=NULL)) //added Hrishikesh 12.07.2023

								{
									ITK_CALL(AOM_ask_value_string(ColPTag,"object_string",&RelRevNumber));
									printf("\nLatest Colour Revision : %s\n",RelRevNumber);
									//Part_CreateChangeFunction(ColPTag);  //PLMSAPPO
									Part_CreateChangeFunction(PartRevTag,iSapServer);
									break;
								}
								else
								{
									continue;
								}
							}
						}
					}
					else
					{
						printf("\nNot Colorable Part : %s", part_noDup);
						continue;
					}
				}

			}//Part Loop
			
		}//Task Loop

		break;
	 }
	}//DML Revision Found
	else
	{
		printf("\n\nDML [%s] Not Found in TCUA...Exiting!!",inputDml); fflush(stdout);
		fprintf(fsuccess,"\n\nDML [%s] Not Found in TCUA...Exiting!!",inputDml); fflush(fsuccess);		
	}

	ITK_CALL(POM_logout(false));
	return status;

	CLEANUP:
	ITK_CALL(POM_logout(false));
	printf("\nCLEANUP..."); fflush(stdout);
}
;

int Part_CreateChangeFunction(tag_t LatestRev, char *SapServer)
{

	int status;
	int len=0;
	int sflag=0;
	int doccount=0;
	int is=0;
	int Refcount=0;

    tag_t		docRelObjs			= NULLTAG;
    tag_t		*docObjs			= NULLTAG;
    tag_t		*refdocObjs			= NULLTAG;
    tag_t		doctag				= NULLTAG;
    tag_t		docRelObj			= NULLTAG;
    tag_t		refdocRelObj		= NULLTAG;
	tag_t		PartMasterTag		= NULLTAG;
	tag_t		docOPtr				= NULLTAG;

	char	*LatRevName=NULL;
	char	*part_type=NULL;
	char	*unit=NULL;
	char	*part_typeDup=NULL;
	char	*unitDup=NULL;
	char	*doc_no=NULL;
	char	*PartRelStatus = NULL;
	char	*PrtSeqDup = NULL;

	//static RFC_RC RfcRc;

	ITK_CALL(AOM_UIF_ask_value(LatestRev,"object_string",&LatRevName));
	ITK_CALL(AOM_UIF_ask_value(LatestRev,"owning_user",&OwnerName));
	tc_strdup(OwnerName,&OwnerNameDup);
	ITK_CALL(AOM_ask_value_string(LatestRev,"t5_PartType",&part_type));
	tc_strdup(part_type,&part_typeDup);

	ITK_CALL(AOM_UIF_ask_value(LatestRev,"item_id",&part_noDup));
	ITK_CALL(AOM_UIF_ask_value(LatestRev,"item_revision_id",&PrtRev));
	PrtRevDup=strtok(PrtRev,";");
	PrtSeqDup=strtok(NULL,";");
	ITK_CALL(AOM_UIF_ask_value(LatestRev,"release_status_list",&PartRelStatus));
	ITK_CALL(AOM_UIF_ask_value(LatestRev,"t5_ColourInd",&partClrInd));

	printf("\nLatRevName:%s \n",LatRevName);fflush(stdout);
	printf("\nPart Type: %s\n",part_typeDup);
	printf("\npart_noDup: %s\n",part_noDup);
	printf("\nOwnerName: %s\n",OwnerNameDup);

	tc_strcpy(PartNumber,part_noDup);
	tc_strcpy(PartRev,PrtRevDup);
	tc_strcpy(PartSeq,PrtSeqDup);
	tc_strcpy(Parttype,part_typeDup);

	if(	tc_strcmp(part_typeDup,"D")==0 ||
		tc_strcmp(part_typeDup,"DA")==0 ||
		tc_strcmp(part_typeDup,"DC")==0 ||
		tc_strcmp(part_typeDup,"CM")==0 ||//added 25.03.2023 Hrishikesh
		tc_strcmp(part_typeDup,"IFD")==0 ||
		tc_strcmp(part_typeDup,"IM")==0 ||
		tc_strcmp(part_typeDup,"CP")==0)
	{
		printf("\nSkipping from MM Creation as Part Type is %s : %s\n",part_type,part_noDup);
		fprintf(fsuccess,"\nSkipping from MM Creation as Part Type is %s : %s\n",part_type,part_noDup);

		tc_strcpy(MATstatus,"N");
		sprintf(Error_message,"Skipping from MM Creation as Part Type is %s : %s",part_type,part_noDup);
		Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);

		goto CLEANUP;
	}
	
	//CR-FY21-0218
	if (tc_strlen(part_noDup)==12)
	{
		if(STRNG_find_last_char(part_noDup,'R')!=NULL || STRNG_find_last_char(part_noDup,'L')!=NULL)
		{
			if (
				tc_strcmp(part_typeDup,"VC")==0 ||
				tc_strcmp(part_typeDup,"CCVC")==0 ||
				tc_strcmp(part_typeDup,"VCCR")==0 ||
				tc_strcmp(part_typeDup,"CKDVC") == 0 ||
				tc_strcmp(part_typeDup,"SKDVC") == 0
			 )
			{
				printf("\nPart %s and PartType %s Found OK\n",part_noDup,part_type);
			}
			else
			{
				printf("\nPart %s and PartType %s Its PartType must be VC/CCVC... NOT OK\n",part_noDup,part_type);
				fprintf(fsuccess,"\nPart %s and PartType %s Its PartType must be VC/CCVC... NOT OK\n",part_noDup,part_type);

				tc_strcpy(MATstatus,"N");
				sprintf(Error_message,"Part %s and PartType %s Its PartType must be VC/CCVC... NOT OK",part_noDup,part_type);
				Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
				goto CLEANUP;
			}
		}
		else
		{
			printf("\nPart %s and PartType %s Normal 12-Digit Part\n",part_noDup,part_type);
		}
	}


	printf("\nPartRelStatus: %s\n",PartRelStatus);
	fprintf(fsuccess,"\nPartRelStatus: %s\n",PartRelStatus);

	//if(tc_strstr(PartRelStatus,"APLC Released")==NULL && tc_strstr(PartRelStatus,"STDSIC Released")==NULL)

	if((tc_strcmp(iPlantCode,"1100")==0 && tc_strstr(PartRelStatus,"APLC Released")==NULL && tc_strstr(PartRelStatus,"STDSIC Released")==NULL)||//added Hrishikesh 12.07.2023
	   (tc_strcmp(iPlantCode,"1001")==0 && tc_strstr(PartRelStatus,"APLP Released")==NULL && tc_strstr(PartRelStatus,"STDSIP Released")==NULL)||//added Hrishikesh 12.07.2023
	   (tc_strcmp(iPlantCode,"1500")==0 && tc_strstr(PartRelStatus,"APLD Released")==NULL && tc_strstr(PartRelStatus,"STDSID Released")==NULL)||//added Hrishikesh 12.07.2023
	   (tc_strcmp(iPlantCode,"3100")==0 && tc_strstr(PartRelStatus,"APLU Released")==NULL && tc_strstr(PartRelStatus,"STDSIU Released")==NULL)|| //added Hrishikesh 12.07.2023
	   (tc_strcmp(iPlantCode,"2001")==0 && tc_strstr(PartRelStatus,"APLJ Released")==NULL && tc_strstr(PartRelStatus,"STDSIJ Released")==NULL)|| //added Hrishikesh 12.07.2023
	   (tc_strcmp(iPlantCode,"E201")==0 && tc_strstr(PartRelStatus,"APLA Released")==NULL && tc_strstr(PartRelStatus,"STDSIA Released")==NULL)) //added Hrishikesh 12.07.2023

	{
		printf("\nPart %s PartRelStatus: %s Part LCS not APL Released or Above...\n",LatRevName,PartRelStatus);
		fprintf(fsuccess,"\nPart %s PartRelStatus: %s Part LCS not APL Released or Above...\n",LatRevName,PartRelStatus);

		tc_strcpy(MATstatus,"N");
		sprintf(Error_message,"Part %s PartRelStatus: %s Part LCS not APL Released or Above...",LatRevName,PartRelStatus);
		Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
		goto CLEANUP;
	}

	len = tc_strlen(part_noDup);

	if(len>0)
	{
		if(tc_strstr(part_noDup,"98R"))
		{
			tc_strdup("T",&part_type);
			tc_strdup("T",&part_typeDup);
		}
		else if(*part_noDup == 'G')
		{
			 tc_strdup("C",&part_type);
			 tc_strdup("C",&part_typeDup);
		}

	}

	strcpy(part_noDupDes,part_noDup);
	
	strcpy(part_noDupDesx,part_noDup);


	tc_strcpy(mat_type,"");

	if (tc_strcmp(part_typeDup, "C") == 0 ||
		tc_strcmp(part_typeDup, "A") == 0 ||
		tc_strcmp(part_typeDup, "G") == 0 
		)
	{
		tc_strcpy(mat_type,"HALB");
	}
	else if (tc_strcmp(part_typeDup, "M") == 0)
	{
		tc_strcpy(mat_type,"HALB");
	}
	else if (tc_strcmp(part_typeDup, "V") == 0)
	{
			tc_strcpy(mat_type,"HALB");
	}
	else if((tc_strcmp(part_typeDup, "VC") == 0)	||
			(tc_strcmp(part_typeDup, "CKDVC") == 0) ||
			(tc_strcmp(part_typeDup, "SKDVC") == 0) ||
			(tc_strcmp(part_typeDup, "CCVC") == 0)	||
			(tc_strcmp(part_typeDup, "SVR") == 0)	||
			(tc_strcmp(part_typeDup, "VCCR") == 0)
			)
	{
		tc_strcpy(mat_type,"FERT");
	}
	else if (tc_strcmp(part_typeDup, "T") == 0)
	{
			tc_strcpy(mat_type,"HALB");
	}
	else if (tc_strcmp(part_typeDup,"DTPL")==0)
	{
		tc_strcpy(mat_type, "HALB");
	}
	else if (tc_strcmp(part_typeDup,"SA")==0)  // added on 17.03.2016 for 16 digit stage assembly of 60R TPL disintegration 
	{
		tc_strcpy(mat_type, "HALB");
	}
	else if (tc_strcmp(part_typeDup,"SP")==0)  // Stage Part
	{
		tc_strcpy(mat_type, "HALB");
	}
	else if (len == 12 || len == 14)
	{
			tc_strcpy(mat_type,"HALB");
	}
	else if (len == 10 || len == 11)
	{
			tc_strcpy(mat_type,"ROH");
	}
	else if (len == 14 || len == 16)	/*cabin kit logic by Ashish on 19.11.2013*/
	{
		if((*(part_noDup+10)=='C') && (*(part_noDup+11)=='K'))
		{
			tc_strcpy(mat_type,"HALB");
		}
	}

	printf("\nMaterial Type: %s", mat_type);
	fprintf(fsuccess,"\nMaterial Type: %s", mat_type);

	if(strcmp(mat_type,"")==0)
	{
		printf("\nNo Material Type Matching For Part : %s\n", part_noDup);
		fprintf(fsuccess,"\nNo Material Type Matching For Part : %s\n", part_noDup);
		goto CLEANUP;
	}

	
	ITK_CALL(AOM_ask_value_tag(LatestRev,"items_tag",&PartMasterTag));

	if ( tc_strcmp(partClrInd,"C") ==0)
	{
		//t5_uom is not found on colour part master/revision
		ITK_CALL(AOM_UIF_ask_value(PartMasterTag,"uom_tag",&unit));
	}
	else
	{
		ITK_CALL(AOM_UIF_ask_value(PartMasterTag,"t5_uom",&unit));
	}
	
	printf("\nPLM Unit Of Masure : %s",unit);
	fprintf(fsuccess,"\nPLM Unit Of Masure : %s",unit);

	if(tc_strlen(unit)>0)
	{
		tc_strdup(unit,&unitDup);
		if (tc_strcmp(unitDup,"1-Mtr") == 0) tc_strcpy(meas_unit,"M");
		else if (tc_strcmp(unitDup,"2-Kg") == 0) tc_strcpy(meas_unit,"KG");
		else if (tc_strcmp(unitDup,"3-Ltr") == 0) tc_strcpy(meas_unit,"L");
		else if (tc_strcmp(unitDup,"4-Nos") == 0) tc_strcpy(meas_unit,"EA");
		else if (tc_strcmp(unitDup,"5-Sq.Mtr") == 0) tc_strcpy(meas_unit,"M2");
		else if (tc_strcmp(unitDup,"6-Sets") == 0) tc_strcpy(meas_unit,"EA");
		else if (tc_strcmp(unitDup,"7-Tonne") == 0) tc_strcpy(meas_unit,"TO");
		else if (tc_strcmp(unitDup,"8-Cu.Mtr") == 0) tc_strcpy(meas_unit,"M3");
		else if (tc_strcmp(unitDup,"9-Thsnds") == 0) tc_strcpy(meas_unit,"TS");
		else if (tc_strcmp(unitDup,"EA") == 0) tc_strcpy(meas_unit,"EA");
		else
		{
			tc_strdup("EA",&unitDup);
			tc_strcpy(meas_unit,"EA");
		}
	}
	else
	{
		tc_strdup("EA",&unitDup);
		tc_strcpy(meas_unit,"EA");
	}

	//As per CR-FY20-0181
	if (tc_strcmp(part_typeDup, "M") == 0)
	{
		tc_strdup("EA",&unitDup);
		tc_strcpy(meas_unit,"EA");
	}


	printf("\nSAP Unit Of Measure: %s", meas_unit);
	fprintf(fsuccess,"\nSAP Unit Of Measure: %s", meas_unit);

	ITK_CALL(AOM_UIF_ask_value(LatestRev,"object_desc",&desc));

	/*Description = Nomenclature*/

	if(tc_strlen(desc)>0)
	{
		tc_strdup(desc,&descDup);
		printf("\nDescription: %s", descDup);
	}
	else printf("\nDescription is NULL!");

	/*if Drawing Indicator = D, only then go for Documents*/
	ITK_CALL(AOM_UIF_ask_value(LatestRev,"t5_DrawingInd",&drg_ind));
	
	if(tc_strlen(drg_ind)>0)
	{
		tc_strdup(drg_ind,&drg_indDup);
		printf("\nDrawing Indicator: %s\n", drg_indDup);
	}
	else
	{
		tc_strdup("",&drg_indDup);
		printf("\nDrawing Indicator is NULL!\n");
	}

	doc_noDup = NULL;
	dwg_typeDup = NULL;
	dwg_revDup = NULL;
	sheet_noDup = NULL;
	sizeDup = NULL;
	sflag=0;
	
	if(tc_strcmp(part_type,"D")!=0)
	{
		if(tc_strcmp(drg_indDup,"D")==0)
		{
			ITK_CALL(GRM_find_relation_type("IMAN_specification", &docRelObj));

			if(docRelObj)
			{
				ITK_CALL(GRM_list_secondary_objects_only(LatestRev,docRelObj,&doccount,&docObjs));
				printf("\n Speccount Value :  %d\n",doccount);fflush(stdout);

				for (is=0;is<doccount;is++ )
				{	
					doctag = docObjs[is];
					
					if(TCTYPE_ask_object_type(doctag,&docOPtr));
					if(TCTYPE_ask_name2(docOPtr,&docClass));
					printf("\nT5TaskToPartCreateVal RefDoc_tag  docClass :: %s\n", docClass);fflush(stdout);
				
					if(!strcmp(docClass,"ProDrw"))
					{
						printf("\n ProDrw \n");fflush(stdout);
						//intDrgCnt++;
						sflag=1;
						break;
					}
					else if(!strcmp(docClass,"CMI2Drawing"))
					{
						printf("\n CMI2Drawing \n");fflush(stdout);
						//intDrgCnt++;
						sflag=1;
						break;
					}
				}
			}
			else
			{
				ITK_CALL(GRM_find_relation_type("IMAN_reference", &refdocRelObj));
				if(refdocRelObj)
				{
					ITK_CALL(GRM_list_secondary_objects_only(LatestRev,refdocRelObj,&Refcount,&refdocObjs));
					printf("\n Refcount Value :-------------------->>>> Rajendra   %d\n",Refcount);fflush(stdout);

					for (is=0;is<Refcount;is++ )
					{	
						doctag = refdocObjs[is];
						if(TCTYPE_ask_object_type(doctag,&docOPtr));
						if(TCTYPE_ask_name2(docOPtr,&docClass));
						printf("\n RefDoc_tag  docClass :: %s\n", docClass);fflush(stdout);
					
						if(!strcmp(docClass,"ProDrw"))
						{
							printf("\n Ref ProDrw \n");fflush(stdout);
							//intDrgCnt++;
							sflag=1;
							break;
						}
						else if(!strcmp(docClass,"CMI2Drawing"))
						{
							printf("\n Ref CMI2Drawing \n");fflush(stdout);
							//intDrgCnt++;
							sflag=1;
							break;
						}
					}
				}
			}

			if(sflag>0)
			{
			  
				 printf("\n<Drawing Documents Found!>");fflush(stdout);

				 ITK_CALL(AOM_UIF_ask_value(doctag,"object_name",&doc_no));
				 tc_strdup(doc_no,&doc_noDup);

				printf("\nDocument Number: %s",doc_noDup);fflush(stdout);

				if(tc_strlen(docClass)>0)
				{
					tc_strdup(docClass,&dwg_typeDup);
					printf("\nDocument Type: %s", dwg_typeDup);
				}
				else
				{
					printf("\nDocument Type is NULL!");fflush(stdout);
				}
		
				strcpy(tmpDrwNum,doc_noDup);
				tmpDrwNum1=strtok(tmpDrwNum,"/");
				tmpDrwRev=strtok(NULL,";");
				tmpDrwSeq=strtok(NULL,";");

				printf("\nDocument Number: %s",tmpDrwNum1);fflush(stdout);
				printf("\nDocument Rev: %s",tmpDrwRev);fflush(stdout);
				printf("\nDocument Seq: %s",tmpDrwSeq);fflush(stdout);

				if(tc_strlen(tmpDrwRev)>0)
				{
					tc_strdup(tmpDrwRev,&dwg_revDup);
					printf("\nDocument Version: %s", dwg_revDup);fflush(stdout);
					fprintf(fsuccess,"\nDocument Version: %s", dwg_revDup);
				}
				else
				{
					tc_strdup("NR",&dwg_revDup);
					printf("\nDocument Version: %s", dwg_revDup);fflush(stdout);
					fprintf(fsuccess,"\nDocument Version: %s", dwg_revDup);
				}

				tc_strdup("0",&sheet_noDup);// ZERO as no Sheet available in UA
			}
		}
		else
		{
			printf("Getting NR revision here");fflush(stdout);
			//tc_strdup("0",&sheet_noDup);
			doc_noDup = NULL;
			sizeDup = NULL;
			dwg_typeDup = NULL;
			dwg_revDup = NULL;
			sheet_noDup = NULL;
		}

		tc_strdup("",&OldMatNoDup);

		printf("\nOld Material No.: %s", OldMatNoDup);fflush(stdout);

		//if ((tc_strcmp(part_typeDup, "VC") == 0) || (tc_strcmp(part_typeDup, "VCCR") == 0)|| (tc_strcmp(part_typeDup, "CKDVC") == 0)|| (tc_strcmp(part_typeDup, "SKDVC") == 0))
		if (tc_strcmp(mat_type, "FERT") == 0)
		{
			printf("\nPlease Create Classification View for VC - %s",part_noDup);fflush(stdout);
			fprintf(fsuccess,"\nPlease Create Classification View for VC - %s",part_noDup);
			ITK_CALL(AOM_UIF_ask_value(LatestRev,"t5_Weight",&net_wt));
			
			if(tc_strlen(net_wt)>0)
			{
				tc_strdup(net_wt,&net_wtDup);
			}
			else
			{
				tc_strdup("0.000",&net_wtDup);
				
			}
		}
		else
		{
			tc_strdup("0.000",&net_wtDup);
		}


		tc_strdup("0.000",&gross_wt);
		printf("\nNet Weight: %s", net_wtDup);fflush(stdout);
		printf("\nGross Weight: %s", gross_wt);fflush(stdout);
	}

   
	 /*Weight Unit = KG*/
	tc_strdup("KG",&unit_wt);
	printf("\nWeight Unit: %s", unit_wt);

	/*Volume = 0.000*/
	tc_strdup("0.000",&volume);
	printf("\nVolume: %s", volume);

	/*Volume Unit = M3*/
	tc_strdup("M3",&vol_unit);
	printf("\nVolume Unit: %s", vol_unit);

	/*Page Format of Production Memo = ""*/
	printf("\nPage Format of Production Memo: ''");

	/*Material Group = ZZZZZZ*/
	tc_strdup("ZZZZZZ",&material_group);
	printf("\nMaterial Group: %s", material_group);

	/*Division = 01*/
	tc_strdup("01",&basic_division);
	printf("\nBasic Division: %s", basic_division);

	/********************** add logic for pstat and apl_dml_flag here *******************/
	//group = subString(part_noDup, 0, 1);
	group = *part_noDup;
	printf("\nGroup: %c", group);


	//Uncomment later to check APL DML

	printf("\ndml_noDup=%s",dml_numAP1);
	series = subString(dml_numAP1, 2, 2);
	printf("\nDML Series: %s", series);
	
	//if ((tc_strcmp(series, "AM") == 0) || (tc_strcmp(series, "MC") == 0)) apl_dml_flag = 2;
	//else apl_dml_flag = 0;
	//printf("\nAPL_DML_FLAG: %d", apl_dml_flag);

	if ((tc_strcmp(series, "AM") == 0) || (tc_strcmp(series, "MC") == 0) || (tc_strcmp(series, "MM") == 0) )  apl_dml_flag = 2;
	else apl_dml_flag = 0;
	printf("\nAPL_DML_FLAG: %d", apl_dml_flag);//Hrishikesh 13.06.2024 MM dml live in tcua

	strcpy(sap_proc_type,"");
	strcpy(sap_spproc_type,"");
	strcpy(SAPpstat,"");
	strcpy(MRPpstat,"");

	GetCSPstat(part_noDup);

	pstat='0';
	pstat_mrp='0';
	pstat_acc='0';

	/*pstat = pstat_basic(part_noDup, plantcode, 1, group);
	pstat_mrp = pstat_basic(part_noDup, plantcode, 2, group);
	pstat_acc = pstat_basic(part_noDup, plantcode, 3, group);*/

	pstat_basicFun();   //PLSAPPO

	printf("\n... pstat Values are :%c:%c:%c",pstat,pstat_mrp,pstat_acc);fflush(stdout);
	fprintf(fsuccess,"\n... pstat Values are :%c:%c:%c",pstat,pstat_mrp,pstat_acc);fflush(stdout);

	printf("\nPStat for Basic View: %c",pstat);
	printf("\nPStat for MRP View: %c",pstat_mrp);
	printf("\nPStat for Accounting View: %c",pstat_acc);

	fprintf(fsuccess,"\nPStat %c %c %c",pstat,pstat_mrp,pstat_acc);

	if (pstat == 'K')
	{
		apl_dml_flag = 0;
	}
	else
	{
		apl_dml_flag = 2;
	}
	printf("\nAPL_DML_FLAG after PStat :: %d", apl_dml_flag);
	printf("\nPlant Code Is :: %s",plantcode);

	ITK_CALL(AOM_ask_value_string(LatestRev,Plant_MakeBuy,&PartMakeBuyInd));
	ITK_CALL(AOM_ask_value_string(LatestRev,Plant_StoreLoc,&store_loc));
	printf("\nPart Make Buy Ind : %s",PartMakeBuyInd);
	if (tc_strlen(PartMakeBuyInd)==0)
	{
		printf("\nSkipping Part %s from MM Creation as Make Buy Ind is NULL!!",part_noDup);
		fprintf(fsuccess,"\nSkipping Part %s from MM Creation as Make Buy Ind is NULL!!",part_noDup);
		goto CLEANUP;
	}
	tc_strdup(PartMakeBuyInd,&make_buy_ind);
	
	printf("\nMake_buy_ind : %s		store_loc : %s ",make_buy_ind,store_loc);
	fprintf(fsuccess,"\nMake_buy_ind : %s		store_loc : %s ",make_buy_ind,store_loc);
	
	if (tc_strlen(store_loc)>0 && tc_strcmp(store_loc,"NA")!=0)
	{
		tc_strdup(store_loc,&store_locDup);
	}
	else
	{
		tc_strdup("",&store_locDup);
	}

	printf("\nMake_buy_ind : %s		store_locDup : %s ",make_buy_ind,store_locDup);
	fprintf(fsuccess,"\nMake_buy_ind : %s		store_locDup : %s ",make_buy_ind,store_locDup);

	if(tc_strcmp(make_buy_ind,"F19")==0)
	{
		strcpy(make_buy_ind,"F30");
	}

	if(tc_strcmp(make_buy_ind,"NA")==0)
	{
		printf("\nMakebuy indicator is NA hence can not create material for %s",part_noDup);
		fprintf(fsuccess,"\nMakebuy indicator is NA hence can not create material for %s",part_noDup);

		tc_strcpy(MATstatus,"N");
		sprintf(Error_message,"Makebuy indicator is NA hence can not create material for %s",part_noDup);
		Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
		goto CLEANUP;
	}

	/***********************************************************************************/

	printf("\n part_noDup:[%s, %s] SAPpstat:[%s][%s]  sap_proc_type:[%s , %s]",part_noDup,plantcode,SAPpstat,MRPpstat,sap_proc_type,sap_spproc_type); fflush(stdout);
	fprintf(fsuccess,"\n part_noDup:[%s, %s] SAPpstat:[%s][%s]  sap_proc_type:[%s , %s]",part_noDup,plantcode,SAPpstat,MRPpstat,sap_proc_type,sap_spproc_type); fflush(fsuccess);
	
	//As per request from bhalchandra kulkarni on 29.10.2017-change for condition of supply change from E99 to E50 or F through AM DML change.
	if(tc_strcmp(plantcode,"1100")==0 && tc_strcmp(DMLEcnType,"AMDML")!=0)
	{
		if(tc_strcmp(sap_proc_type,"E")==0)
		{
			//strcpy(proc_Key,sap_proc_type);
			proc_Key = 'E';
		}
		else
		{
			//strcpy(proc_Key,"0");
			proc_Key = '0';
		}

		if(tc_strcmp(sap_spproc_type,"99")==0)
		{
			//strcpy(spl_Key,"Y");
			spl_Key = 'Y';
		}
		else
		{
			//strcpy(spl_Key,"0");
			spl_Key = '0';
		}

		printf("\n Plant 1100...proc_Key:[%c] spl_Key:[%c]",proc_Key,spl_Key) ; fflush(stdout);
		fprintf(fsuccess,"\n Plant 1100...proc_Key:[%c] spl_Key:[%c]",proc_Key,spl_Key) ; fflush(stdout);
	}

	if(tc_strcmp(plantcode,"1100")==0)
	{
		if(tc_strlen(make_buy_ind)>0)
		{

			tc_strdup(make_buy_ind,&make_buy_indDup);
			printf("\nInSide GET CS Proc");
			fprintf(fsuccess,"\nInSide GET CS Proc");
			//proc_Key = GetCSSAP(part_noDup,1);
			//spl_Key = GetCSSAP(part_noDup,2);
			if(proc_Key == 'E' && spl_Key == 'Y')
			{
				printf("\nTaking Value from CS Proc");
				fprintf(fsuccess,"\nTaking Value from CS Proc");
				printf("\nMake/Buy Indicator in PLM:%s:", make_buy_indDup);
				fprintf(fsuccess,"\nPune Make/Buy Indicator in PLM:%s:", make_buy_indDup);
				tc_strdup("E",&proc_type);
				printf("\nProcurement Type: %s", proc_type);
				fprintf(fsuccess,"\nProcurement Type: %s", proc_type);
				tc_strdup("99",&spl_proc_key);
				
				printf("\nSpecial Procurement Key: %s", spl_proc_key);
				fprintf(fsuccess,"\nSpecial Procurement Key: %s", spl_proc_key);
			}
			else
			{
				printf("\nTaking Value from PLM");
				fprintf(fsuccess,"\nTaking Value from PLM");
				printf("\nMake/Buy Indicator:%s:", make_buy_indDup);
				proc_type = subString(make_buy_indDup, 0, 1);
				printf("\nProcurement Type: %s", proc_type);
				spl_proc_key = subString(make_buy_indDup, 1, 2);
				printf("\nSpecial Procurement Key: %s", spl_proc_key);
			}
		}
		else
		{
			printf("\nPune Make/Buy Indicator is NULL!");
			printf("\nProcurement Type is NULL!");
			printf("\nSpecial Procurement Key is NULL!");
			printf("\nPart %s is found in Release Vault with Life Cycle State as APL Released but CS is NULL",part_noDup);
			fprintf(fsuccess,"\nPart %s is found in Release Vault with Life Cycle State as APL Released but CS is NULL",part_noDup);

			tc_strcpy(MATstatus,"N");
			sprintf(Error_message,"Part %s is found in Release Vault with Life Cycle State as APL Released but CS is NULL",part_noDup);
			Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
			goto CLEANUP;
		}
	}
	else
	{
		if(tc_strlen(make_buy_ind)>0)
		{
			tc_strdup(make_buy_ind,&make_buy_indDup);

		
			printf("\nMake/Buy Indicator:%s:", make_buy_indDup);
			proc_type = subString(make_buy_indDup, 0, 1);
			printf("\nProcurement Type: %s", proc_type);
			spl_proc_key = subString(make_buy_indDup, 1, 2);
			printf("\nSpecial Procurement Key: %s", spl_proc_key);

		}
		else
		{
			printf("\nPune Make/Buy Indicator is NULL!");
			printf("\nProcurement Type is NULL!");
			printf("\nSpecial Procurement Key is NULL!");
			printf("\nPart %s is found in Release Vault with Life Cycle State as APL Released but CS is NULL",part_noDup);
			fprintf(fsuccess,"\nMSG RCVD:Part %s is found in Release Vault with Life Cycle State as APL Released but CS is NULL",part_noDup);

			tc_strcpy(MATstatus,"N");
			sprintf(Error_message,"MSG RCVD:Part %s is found in Release Vault with Life Cycle State as APL Released but CS is NULL",part_noDup);
			Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
			goto CLEANUP;
		}


	}

	//if(tc_strcmp(sap_proc_type,"F")==0)
	

	/**************************MRP 1 VIEW***********************************************/

	/*mrp_grp*/
	/*mrp_type-> car_dml => if plantcode == 1100, car_dml=1 else car_dml=0
	car_dml = 0 for plant 7001*/
	/*strcpy(mrp_grp, "");*/

	if(tc_strcmp(plantcode,"1100")==0)
	{
		car_dml=1;
	}
	else
	{
		car_dml=0;
	}

	printf("\ncar_dml value is :: %d",car_dml);
	fprintf(fsuccess,"\ncar_dml value is :: %d",car_dml);


	/*MRP type logic changed by Prasad as per request from Kartik Dhond. mail dated 29.04.2016 */

	tc_strdup("",&mrp_grp);
	tc_strdup("PD",&mrp_type);

	printf("\nMaterial type %s",mat_type);

	if (tc_strcmp(mat_type, "FERT") == 0)
	{
		tc_strdup("A1",&mrp_grp);
		
	}
	else if (tc_strcmp(mat_type, "HALB") == 0 || tc_strcmp(mat_type, "ROH") == 0)
	{
		tc_strdup("A2",&mrp_grp);
		
	}
	if (tc_strcmp(proc_type, "F") == 0)
	{
		tc_strdup("PD",&mrp_type);
		
	}
	if (tc_strcmp(make_buy_indDup, "F18") == 0) 
	{
		tc_strdup("PD",&mrp_type);
		
	}
	if (tc_strcmp(make_buy_indDup, "F30") == 0) 
	{
		tc_strdup("PD",&mrp_type);
		
	}
	if (tc_strcmp(subString(part_noDup,0,1),"G") == 0)
	{
		if ((tc_strcmp(make_buy_indDup, "E") == 0) || (tc_strcmp(make_buy_indDup, "E50") == 0) )
		{
			tc_strdup("PD",&mrp_type);
			
		}
	}


	/*MRP logic change end*/

	printf("\nMRP Group: %s", mrp_grp);
	printf("\nMRP Type: %s", mrp_type);

	/*abc_ind = "B"*/
	tc_strdup("B",&abc_ind);
	printf("\nABC Indicator: %s", abc_ind);

	/*mm_pp_status-> odstatus = ??
	EXEC SQL select	'1' into :odstatus from	amden_part where part_no = :comp
	and	substr(part_no,9,2) = '16' and description like '%OFFER%';*/
	num = subString(part_noDup, 8, 2);
	/*if ((strcmp(num, "16")==0) && (!nlsIsStrNull(nlsStrStr(descDup, "OFFER")))) */
	tc_strdup("",&odstatus);

	if ((tc_strcmp(num, "16")==0))
	{
		//fprintf(fsuccess,"\nnum= %s.........",num);
		if((tc_strstr(descDup, "OFFER"))!=NULL)
		{
			tc_strdup("1",&odstatus);
			
		}
	}
	else
	{
		tc_strdup("",&odstatus);
		
	}
	


	ITK_CALL(AOM_UIF_ask_value(LatestRev,"t5_PartStatus",&drstatus));

	
	if(tc_strlen(drstatus)>0)
	{
		tc_strdup(drstatus,&drstatusDup);
	}

	//fprintf(fsuccess,"\nPart Number: %s    DR/AR Status:%s", part_noDup,drstatusDup); fflush(fsuccess);

	
	if(tc_strlen(partClrInd)>0)
	{
		tc_strdup(partClrInd,&partClrIndDup);
	} 

	printf("\nPart Number: %s    DR/AR Status:%s   Color Ind:%s ", part_noDup,drstatusDup,partClrIndDup); fflush(stdout);

	tc_strdup("",&mm_pp_status);


	//commented mmpp status 30 logic as per Mr. Kartik Dhond mail on 28 April 2019.

	/*if ((tc_strcmp(make_buy_indDup, "F18") == 0)  || (tc_strcmp(make_buy_indDup, "F") == 0)  || (tc_strcmp(make_buy_indDup, "F19") == 0) || (tc_strcmp(make_buy_indDup, "F30") == 0)) 
	{
	
		tc_strdup("30",&mm_pp_status);

		printf("\nmmpp status is set to 30 for part with proc F"); fflush(stdout);

	}*/



   /*if ((tc_strcmp(partClrIndDup, "Y") == 0))
	{

		//tc_strdup("PB",&mm_pp_status);
		//printf("\nmmpp status is set to PB for colour ind Y part"); fflush(stdout);
		//fprintf(fsuccess,"\nmmpp status is set to PB for colour ind Y part"); fflush(stdout);
	}
	else
	{

		//As per new request from Rohan Ghate below logic is added on date 06.12.2016 for materail status mm_pp_status
		if((tc_strcmp(part_typeDup, "VC") == 0) || (tc_strcmp(part_typeDup, "VCCR") == 0))
		{
//					if(dstat = oiSqlCreateSelect(&mstrlSql)) goto CLEANUP;
//					if(dstat = oiSqlWhereBegParen(mstrlSql)) goto CLEANUP;
//					if(dstat = oiSqlWhereEQ(mstrlSql,"t5Syscd","MMPPST")) goto CLEANUP;
//					if(dstat = oiSqlWhereAND(mstrlSql)) goto CLEANUP;
//					if(dstat = oiSqlWhereEQ(mstrlSql,"t5SubSyscd",plantcode)) goto CLEANUP;
//					if(dstat = oiSqlWhereEndParen(mstrlSql)) goto CLEANUP;
//					if(dstat = QueryWhere("t5Cntrol",mstrlSql,&MMPPControlObjs,&mfail)) goto CLEANUP;
			
			//if(setSize(MMPPControlObjs)>0)
			//{
				if (tc_strcmp(OwnerNameDup, "Obsolete Vault") == 0 )
				{
					tc_strdup("AR",&mm_pp_status);
		
				}
				else if((tc_strcmp(drstatusDup,"DR0")==0)||(tc_strcmp(drstatusDup,"DR1")==0)||(tc_strcmp(drstatusDup,"DR2")==0)||
					(tc_strcmp(drstatusDup,"DR3")==0)||(tc_strcmp(drstatusDup,"AR0")==0)||(tc_strcmp(drstatusDup,"AR1")==0)||
					(tc_strcmp(drstatusDup,"AR2")==0)||(tc_strcmp(drstatusDup,"AR3")==0))
				{
					//tc_strdup("PB",&mm_pp_status);
					
					printf("\nVC..mm_pp_status is set to 'PB' for DR status %s  < DR4",drstatusDup); fflush(stdout);
					fprintf(fsuccess,"\nVC..mm_pp_status is set to 'PB' for DR status %s  < DR4",drstatusDup); fflush(fsuccess);
				}
				else
				{
					tc_strdup("",&mm_pp_status);

					printf("\nVC..mm_pp_status is set to NULL for DR status %s > DR3",drstatusDup); fflush(stdout);
					fprintf(fsuccess,"\nVC..mm_pp_status is set to NULL for DR status %s > DR3",drstatusDup); fflush(fsuccess);
				}
			//}
			//else	// else condition for non-control object plant present which having part type VC/VCCR
			//{
			//		tc_strdup("",&mm_pp_status);

			//	printf("\nVC..Plantcode %s is not live to set mm_pp_status hence updating to NULL...",plantcode); fflush(stdout);
			//	//fprintf(fsuccess,"\nVC..Plantcode %s is not live to set mm_pp_status hence updating to NULL...",plantcode); fflush(fsuccess);
			//}
		}
		else
		{
			//A7 Logic Commented as per instruction from Rohan
			if (tc_strcmp(odstatus, "1") == 0)
			{
				tc_strdup("A7",&mm_pp_status);
				
			}
			else
			{
				printf("\nmmpp status inot changed"); fflush(stdout);
				fprintf(fsuccess,"\nmmpp status inot changed"); fflush(stdout);
			}

			printf("\nPartType: [%s]  odstatus:[%s] and mm_pp_status: [%s] \n  ",part_typeDup,odstatus,mm_pp_status); fflush(stdout);
			fprintf(fsuccess,"\nPartType: [%s]  odstatus:[%s] and mm_pp_status: [%s]  ",part_typeDup,odstatus,mm_pp_status); fflush(fsuccess);
		}
	}*/

	printf("\n%s Part_noDup: %s    part_typeDup: %s    drstatusDup: %s    mm_pp_status: %s\n",plantcode,part_noDup, part_typeDup,drstatusDup,mm_pp_status); fflush(stdout);
	fprintf(fsuccess,"\n%s Part_noDup: %s    part_typeDup: %s    drstatusDup: %s    mm_pp_status: %s",plantcode,part_noDup, part_typeDup,drstatusDup,mm_pp_status); fflush(fsuccess);

	printf("\nodstatus: %s", odstatus);
	printf("\nnum: %s", num);
	printf("\nMM/PP Status: %s", mm_pp_status);
	fprintf(fsuccess,"\nMM/PP Status: %s %s %s %s", mm_pp_status,num,odstatus,descDup);

	tc_strdup("0.000",&reord_pt);

	printf("\nReorder Point: %s", reord_pt);

	tc_strdup("Z",&quota_arrangement_usage);
	printf("\nQuota Arrangement Usage: %s", quota_arrangement_usage);

	tc_strdup("ZZZ",&mrp_controller);

	printf("\nMRP Controller: %s", mrp_controller);

	tc_strdup("",&lot_size_key);
	tc_strdup("",&fixed_lot_size);
	
	if (tc_strcmp(part_typeDup, "D") != 0)
	{
		tc_strdup("EX",&lot_size_key);
		
	}
	printf("\nLot Size: %s\nFixed Lot Size: %s", lot_size_key, fixed_lot_size);

   tc_strdup("",&max_stlvl);
	printf("\nMaximum stock level: %s", max_stlvl);
	
	tc_strdup("",&blk_ind);
	printf("\nBulk Indicator: %s", blk_ind);

	tc_strdup("000",&sched_mar_key);
	printf("\nScheduling Margin Key: %s", sched_mar_key);

	tc_strdup("T",&req_grp);
	printf("\nRequirements Grouping: %s", req_grp);

	/*******************************MRP 2 VIEW***********************************/

	tc_strdup("M",&period_ind);
	printf("\nPeriod Indicator: %s", period_ind);

	tc_strdup("",&mixedmrp);
	tc_strdup("S",&cs1_val);
	tc_strdup("",&alternativb);

	if (tc_strcmp(part_typeDup, "D") != 0)
	{
		if (tc_strcmp(mat_type, "FERT") == 0 && car_dml != 1)
		{
			tc_strdup("2",&mixedmrp);
			
		}
		if (tc_strcmp(cs1_val,"S") == 0)
		{
			tc_strdup("",&alternativb);
		}
	}
	printf("\nMixed MRP: %s", mixedmrp);
	printf("\nMethod for Selecting Alternative Bills: %s", alternativb);

	tc_strdup("02",&avail_chk);
	printf("\nChecking Group for Availability Check: %s", avail_chk);

	tc_strdup("",&splan_mat);
	printf("\nPlanning Material: %s", splan_mat);

	tc_strdup("",&splan_plant);
	printf("\nPlanning Plant: %s", splan_plant);

	tc_strdup("",&splan_conv_fact);
	printf("\nConversion Factor for Planning Material: %s", splan_conv_fact);

	tc_strdup("2",&ind_collect);
	printf("\nDependent requirements ind. for individual: %s", ind_collect);

	tc_strdup("",&rep_mfg_in);
	printf("\nRepetitive Mfg. Allowed: %s", rep_mfg_in);

	if(tc_strcmp(make_buy_indDup,"E98") == 0 || tc_strcmp(make_buy_indDup,"E99") == 0)
	{
			tc_strdup("TE02",&rep_mfg);
	}
	else
	{
			tc_strdup("",&rep_mfg);
	}
	
	printf("\nRepetitive Manufacturing Profile: %s", rep_mfg);


	tc_strdup("0001",&stock_det_group);
	printf("\nStock determination group: %s", stock_det_group);

	/**************************STORAGE VIEW***********************************/
	tc_strdup("",&uoissue);
	printf("\nUnit of Issue: %s", uoissue);

	/*qua_ins_ind, doc_req, grptime, qm_proc_ind, certificate_type, control_key*/

	tc_strdup("",&qua_ins_ind);
	tc_strdup("",&doc_req);
	tc_strdup("1",&grptime);
	tc_strdup("",&certificate_type);
	tc_strdup("",&qm_proc_ind);


	if (tc_strcmp(proc_type,"F") == 0 && tc_strcmp(spl_proc_key,"40") != 0)
	{  
		tc_strdup("X",&qua_ins_ind);
		tc_strdup("X",&doc_req);
		tc_strdup("1",&grptime);
		tc_strdup("0005",&certificate_type);
		tc_strdup("0008",&control_key);
		tc_strdup("X",&qm_proc_ind);

	}
	else if (tc_strcmp(proc_type,"E") == 0 || tc_strcmp(spl_proc_key,"40") == 0)
	{

		tc_strdup("",&qua_ins_ind);
		tc_strdup("X",&doc_req);
		tc_strdup("",&grptime);
		tc_strdup("",&certificate_type);
		tc_strdup("0000",&control_key);
		tc_strdup("X",&qm_proc_ind);
	}
	
	if(tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar Requirement QM View for VC 
	{
		tc_strdup("X",&qua_ins_ind);
		tc_strdup("",&doc_req);
		tc_strdup("",&grptime);
		tc_strdup("0005",&certificate_type);
		tc_strdup("0008",&control_key);
		tc_strdup("X",&qm_proc_ind);
	}
	
	printf("\nPost to Inspection Stock: %s", qua_ins_ind);
	printf("\nDocumentation Required Indicator: %s", doc_req);
	printf("\nGoods Receipt Processing Time in Days: %s", grptime);
	printf("\nQM in Procurement is Active: %s", qm_proc_ind);
	printf("\nControl Key for Quality Management: %s", control_key);
	printf("\nCertificate Type: %s", certificate_type);


    tc_strdup("",&catalog_prof);
	printf("\nCatalog Profile: %s", catalog_prof);

	tc_strdup("",&valuation_cat);
	tc_strdup("",&price_con);
	tc_strdup("",&std_price);
	tc_strdup("",&moving_avg_price);

	printf("\nmoving_avg_price: %s", moving_avg_price);

	//if ((tc_strcmp(part_typeDup, "VC") != 0) && (tc_strcmp(part_typeDup, "VCCR") != 0) && (tc_strcmp(part_typeDup, "CKDVC") != 0) && (tc_strcmp(part_typeDup, "SKDVC") != 0))
	if (tc_strcmp(mat_type, "FERT") != 0)
	{
		printf("\nNot FERT.......");
		flag_vc_v_tpl = 1;
		tc_strdup("S",&valuation_cat);
		tc_strdup("V",&price_con);
		tc_strdup("0.0100",&moving_avg_price);
	}
	else
	{
		printf("\nFERT Materal......."); 
		tc_strdup("",&valuation_cat);
		tc_strdup("S",&price_con);
		tc_strdup("0.01",&std_price);
	}
	
	printf("\nValuation Category: %s", valuation_cat);
	printf("\nPrice control indicator: %s", price_con);
	printf("\nStandard Price: %s", std_price);
	printf("\nMoving Average Price: %s", moving_avg_price);

	tc_strdup("",&val_class);

	if (tc_strcmp(mat_type, "FERT") == 0)
	{
	   tc_strdup("0530",&val_class);
		
	}
	else
	{
		if (tc_strcmp(make_buy_indDup, "F") == 0 || tc_strcmp(make_buy_indDup, "F01") == 0)
		{
			tc_strdup("0110",&val_class);
			
		}
		if (tc_strcmp(make_buy_indDup, "F98") == 0)
		{
			tc_strdup("0110",&val_class);
		}
		if (tc_strcmp(make_buy_indDup, "F18") == 0)
		{
			tc_strdup("0110",&val_class);
		}
		if (tc_strcmp(make_buy_indDup, "F30") == 0)
		{
		
			tc_strdup("0240",&val_class);
		}
		if (tc_strcmp(make_buy_indDup, "F19") == 0)
		{
			tc_strdup("0240",&val_class);
		}
		if (tc_strcmp(make_buy_indDup, "F40") == 0)
		{
			tc_strdup("0250",&val_class); //29.05.2024 Hrishikesh CR/ERC/PLM/24/0116
		}
		if (tc_strcmp(proc_type, "E") == 0)
		{
			tc_strdup("0230",&val_class);
		}

	}

	printf("\nGoing in valuation class loop................%s %s :%s:",mat_type,val_class,make_buy_indDup);
	printf("\nValuation Class: %s", val_class);
	
	if(tc_strcmp(val_class,"")==0)
	{
		printf("\n**Valuation Class is NULL, skipping from material transfer\n\n");
		fprintf(fsuccess,"\n**Valuation Class is NULL, skipping from material transfer\n\n");

		tc_strcpy(MATstatus,"N");
		tc_strcpy(Error_message,"**Valuation Class is NULL, skipping from material transfer");
		Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
		goto CLEANUP;
	}

	tc_strdup("X",&mat_origin);

	printf("\nMaterial-related origin: %s", mat_origin);

	strcpy(origin_group,origin_group2);
	get_origingroup();
	printf("\nOrigin Group: %s", origin_group);

	if (group != 'G')
	{
		tc_strdup("1",&cost_lot_size);
		
	}
	else if (group == 'G')
	{
		tc_strdup("100",&cost_lot_size);
		
	}
	printf("\nLot Size for Product Costing: %s", cost_lot_size);


	tc_strdup("PP1",&variance_key);
	printf("\nVariance Key: %s", variance_key);

	tc_strdup("X",&with_quantity_structure);
	printf("\nMaterial Is Costed with Quantity Structure: %s", with_quantity_structure);

	tc_strdup("",&costing_split_valuation);
	tc_strdup("",&costing_val_class);

	if (tc_strcmp(mat_type, "FERT") == 0)
	{
		tc_strdup("",&costing_split_valuation);
		tc_strdup("0530",&costing_val_class);
		
	}

	if (tc_strcmp(mat_type, "HALB") == 0 || tc_strcmp(mat_type, "ROH") == 0)
	{
		tc_strdup("S",&costing_split_valuation);
	}
	
	printf("\nCosting Valuation Category: %s", costing_split_valuation);
	printf("\nCosting Valuation Class: %s", costing_val_class);

	if (flag == 0)
	{
		char *insp_type_val = NULL;
		int insp_type = 0;
		char *val_type = NULL;
		int iVal_type = 1;
		mat_create();  //SAPPOC2025
		
		//CR-FY21-0001
		if (tc_strcmp(part_typeDup,"SA")==0 || tc_strcmp(part_typeDup,"SP")==0)
		{
			//Create Revision level for Stage Assay/Parts
			printf("\nGoing for revision update of Stage Part %s as %s",part_noDup,PrtRevDup);
			BapiRevcr(dml_no_arg, part_noDup, PrtRevDup);
			printf("\nRevision updated for part %s as %s",part_noDup,PrtRevDup);
			fprintf(fsuccess,"\nrevision updated for part %s as %s",part_noDup,PrtRevDup);
		}

		if (go_for_rfc == 1 && flag_vc_v_tpl == 1 && acc_flag !=1)
		{
			printf("\nAccounting View and go_for_rfc flag = 1");
			//if ((tc_strcmp(part_typeDup, "VC") != 0) && (tc_strcmp(part_typeDup, "VCCR") != 0) && (tc_strcmp(part_typeDup, "CKDVC") != 0) && (tc_strcmp(part_typeDup, "SKDVC") != 0))
			if (tc_strcmp(mat_type, "FERT") != 0)
			{
				printf("\nPart is not VC");
				if((tc_strcmp(proc_type, "F") == 0) && (tc_strcmp(spl_proc_key, "40") != 0))
				{
					//RfcRc = allocate_insp_type();  //SAPPOC2025
					char *json_alloc_inspect_type_req_obj = NULL;
					
					insp_type_val = MEM_alloc(5);
					json_alloc_inspect_type_req_obj = malloc(34000);
					for ( insp_type = 0; insp_type < 4; insp_type++ )
					{
						
						if ( insp_type == 0 )
						{
							tc_strcpy ( insp_type_val, "01" );
						}
						else if ( insp_type == 1 )
						{
							tc_strcpy ( insp_type_val, "0101" );
						}
						else if ( insp_type == 2 )
						{
							tc_strcpy ( insp_type_val, "0102" );
						}
						else if ( insp_type == 3 )
						{
							tc_strcpy ( insp_type_val, "8901" );
						}
						cll_ZRFC_INSPTYPE_ALLOC(part_noDup, plantcode, SapServer, insp_type_val ,json_alloc_inspect_type_req_obj);
						printf("\nRequest String : %s\n", json_alloc_inspect_type_req_obj);
						tm_curl_ZRFC_INSPTYPE_ALLOC ( json_alloc_inspect_type_req_obj );
						
					}	
					free(json_alloc_inspect_type_req_obj);
				}
			
				/*In material change it will not go for batches create*/
				if (tc_strcmp(valuation_cat, "S") == 0 && flag != 1)
				{
					//Accounting View Valuation Type Create
					//cll_zrfc_ac_view_create();   //SAPPOC2025
					char *json_batches_create_req_obj = NULL;
					json_batches_create_req_obj = malloc(34000);
					val_type = (char *) MEM_alloc(10 * sizeof (char) );
					for ( iVal_type = 1; iVal_type < 6; iVal_type++ )
					{
						
						
						sprintf( val_type, "%d", iVal_type ) ;
				
						if ( tc_strcmp ( val_type, "1")  == 0 )
						{
							tc_strcpy ( val_class, "0110" );
						}
						else if ( tc_strcmp ( val_type, "2")  == 0 )
						{
							tc_strcpy ( val_class, "0120" );
						}
						else if ( tc_strcmp ( val_type, "3")  == 0 )
						{
							tc_strcpy ( val_class, "0230" );
						}
						else if ( tc_strcmp ( val_type, "4")  == 0 )
						{
							tc_strcpy ( val_class, "0240" );
						}
						else if ( tc_strcmp ( val_type, "5")  == 0 )
						{
							tc_strcpy ( val_class, "0250" );
						}
						
						printf ( "\nval_type : [%s] val_class : [%s]", val_type, val_class ) ;
						
						cll_ZRFC_AC_VIEW_CREATE ( part_noDup, plantcode, SapServer, val_type, val_class, json_batches_create_req_obj ) ;
						printf("\nRequest String : %s\n", json_batches_create_req_obj);
						tm_curl_ZRFC_AC_VIEW_CREATE ( json_batches_create_req_obj );
						
					}
					free(json_batches_create_req_obj);
				}
			}
		}
		go_for_rfc = 0;  /* reseting for next material  */

		if (tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar Request for QM View for VC
		{
			//allocate_insp_type_vc();  //SAPPOC2025
			char *json_alloc_inspect_type_req_obj = NULL;
			insp_type_val = MEM_alloc(5);
			int insp_type = 0;
			for ( insp_type = 0; insp_type < 4; insp_type++ )
			{
				json_alloc_inspect_type_req_obj = malloc(34000);
				if ( insp_type == 0 )
				{
					tc_strcpy ( insp_type_val, "01" );
				}
				else if ( insp_type == 1 )
				{
					tc_strcpy ( insp_type_val, "0101" );
				}
				else if ( insp_type == 2 )
				{
					tc_strcpy ( insp_type_val, "0102" );
				}
				else if ( insp_type == 3 )
				{
					tc_strcpy ( insp_type_val, "8901" );
				}
				cll_ZRFC_INSPTYPE_ALLOC(part_noDup, plantcode, SapServer, insp_type_val ,json_alloc_inspect_type_req_obj);
				printf("\nRequest String : %s\n", json_alloc_inspect_type_req_obj);
				tm_curl_ZRFC_INSPTYPE_ALLOC ( json_alloc_inspect_type_req_obj );
				free(json_alloc_inspect_type_req_obj);
			}	
		}
	}
	printf("\nI am here series........................%s",subString(dml_numAP1, 2, 2));
	printf("\nI am here partrev ........................%s",PrtRevDup);
	printf("\nI am here organization........................%s",OrgIDDup);
	
	//if ((tc_strcmp(plantcode,"1001") != 0) && (tc_strcmp(plantcode,"1020" )!= 0) && (tc_strcmp(plantcode,"1500") != 0) && (tc_strcmp(plantcode,"3100") != 0))
	//if(tc_strstr(DMLRelStatus,"STDSIC Released")!=NULL)

	if((tc_strcmp(iPlantCode,"1100")==0 && tc_strstr(DMLRelStatus,"STDSIC Released")!=NULL)||//added Hrishikesh 12.07.2023
	   (tc_strcmp(iPlantCode,"1001")==0 && tc_strstr(DMLRelStatus,"STDSIP Released")!=NULL)||//added Hrishikesh 12.07.2023
	   (tc_strcmp(iPlantCode,"1500")==0 && tc_strstr(DMLRelStatus,"STDSID Released")!=NULL)||//added Hrishikesh 12.07.2023
	   (tc_strcmp(iPlantCode,"3100")==0 && tc_strstr(DMLRelStatus,"STDSIU Released")!=NULL)|| //added Hrishikesh 12.07.2023
	   (tc_strcmp(iPlantCode,"2001")==0 && tc_strstr(DMLRelStatus,"STDSIJ Released")!=NULL)|| //added Hrishikesh 20.09.2023
	   (tc_strcmp(iPlantCode,"E201")==0 && tc_strstr(DMLRelStatus,"STDSIA Released")!=NULL)) //added Hrishikesh 02.10.2023


	{
		if((tc_strcmp(subString(dml_numAP1, 2, 2),"PP")==0||tc_strcmp(subString(dml_numAP1, 2, 2),"PM")==0) && tc_strcmp(PrtRevDup,"NR")!=0)	//tc_strcmp(PrtRevDup,"NR")!=0
		{	flag = 1;}

		if(tc_strcmp(subString(dml_numAP1, 2, 2),"AM")==0) //&& tc_strcmp(OrgIDDup,"ERC")==0)
		{	flag = 1;}

		if(tc_strcmp(subString(dml_numAP1, 2, 2),"AM")==0 /*&& tc_strcmp(OrgIDDup,"APL")==0*/ && tc_strcmp(PrtRevDup,"NR")!=0)
		{
			flag = 1;
		}

		if(tc_strcmp(subString(dml_numAP1, 2, 2),"MM")==0) //Hrishikesh 13.06.2024 MM dml live in tcua
		{	flag = 1;}

		if (flag == 1)
		{
			char *insp_type_val = NULL;
			int insp_type = 0;
			printf("\nGoing for MATERIAL CHANGE");
			mat_create();   //SAPPOC2025
			if(tc_strcmp(proc_type, "F") == 0 && tc_strcmp(mat_type, "FERT") != 0)
			{
				printf("\nCreating insp. type during Material Change as proc = F");
				//RfcRc = allocate_insp_type();  //SAPPOC2025
				char *json_alloc_inspect_type_req_obj = NULL;
				insp_type_val = MEM_alloc(5);
				
				for ( insp_type = 0; insp_type < 4; insp_type++ )
				{
					json_alloc_inspect_type_req_obj = malloc(34000);
					if ( insp_type == 0 )
					{
						tc_strcpy ( insp_type_val, "01" );
					}
					else if ( insp_type == 1 )
					{
						tc_strcpy ( insp_type_val, "0101" );
					}
					else if ( insp_type == 2 )
					{
						tc_strcpy ( insp_type_val, "0102" );
					}
					else if ( insp_type == 3 )
					{
						tc_strcpy ( insp_type_val, "8901" );
					}
					cll_ZRFC_INSPTYPE_ALLOC(part_noDup, plantcode, SapServer, insp_type_val ,json_alloc_inspect_type_req_obj);
					printf("\nRequest String : %s\n", json_alloc_inspect_type_req_obj);
					tm_curl_ZRFC_INSPTYPE_ALLOC ( json_alloc_inspect_type_req_obj );
					free(json_alloc_inspect_type_req_obj);
				}	
			}

			if (tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar Request for QM View for VC
			{
				//allocate_insp_type_vc();  //SAPPOC2025
				char *json_alloc_inspect_type_req_obj = NULL;
				insp_type_val = MEM_alloc(5);
				for ( insp_type = 0; insp_type < 4; insp_type++ )
				{
					json_alloc_inspect_type_req_obj = malloc(34000);
					if ( insp_type == 0 )
					{
						tc_strcpy ( insp_type_val, "01" );
					}
					else if ( insp_type == 1 )
					{
						tc_strcpy ( insp_type_val, "0101" );
					}
					else if ( insp_type == 2 )
					{
						tc_strcpy ( insp_type_val, "0102" );
					}
					else if ( insp_type == 3 )
					{
						tc_strcpy ( insp_type_val, "8901" );
					}
					cll_ZRFC_INSPTYPE_ALLOC(part_noDup, plantcode, SapServer, insp_type_val ,json_alloc_inspect_type_req_obj);
					printf("\nRequest String : %s\n", json_alloc_inspect_type_req_obj);
					tm_curl_ZRFC_INSPTYPE_ALLOC ( json_alloc_inspect_type_req_obj );
					free(json_alloc_inspect_type_req_obj);
				}
			}
		}
		flag=0; //reseting flag
	}
	else
	{
		printf("\n\n****DML is not STD Released hence skipping from MM Change %s",DMLNumDup); fflush(stdout);
		fprintf(fsuccess,"\n\n****DML is not STD Released hence skipping from MM Change %s",DMLNumDup); fflush(fsuccess);
	}

	CLEANUP:
	return 0;
}//End Of Function