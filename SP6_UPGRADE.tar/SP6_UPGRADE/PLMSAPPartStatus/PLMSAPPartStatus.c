/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   PLM-SAP
*  Description  :   Provide Part Information From SAP via Webservice For TCUA - CV  
*  File Name    :   PLMSAPPartStatus.c
*  Created on   :   June 11th, 2024
*  Usage        :   PLMSAPPartStatus
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     11/06/2024                 Sourav Karak
***************************************************************************/

#include "soapH.h"
#include "PLMSAPPartStatus.nsmap"
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc_startup.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>
#include <string.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <malloc.h>
#include<cJSON.h>
#include <curl/curl.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITEM_id_size_c   128
#define atoa(x) #x

#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}

void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);
void str2nbcd(char *str,unsigned char *bcd,size_t size,int decimals);

char* InpPrt_str = NULL;
char* InpPlnt_str = NULL;
char* InpPrt_strDup = NULL;
char* InpPlnt_strDup = NULL;
char* plantcode = NULL;
char *proc_type;
char *inputPart = NULL;
char *iPlantCode = NULL;
//char *sap_proc_type = NULL;
//char *sap_spproc_type = NULL;
char *SAPpstat = NULL;
char *MRPpstat = NULL;
char pstat;
//char *sloc1_type = NULL;
//char *sloc2_type = NULL;
char *sloc1_type;
char *sloc2_type;
//char *PSAP_CS;
//char *PSAP_SLOC;
char *sap_proc_type;
int sappproc;
char sap_spproc_type[4];

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
	const int*      pSevLst = 0;
	const int*      pErrCdeLst = 0;
	const char**    pMsgLst = NULL;
 
    int i =0;
    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    for ( i = 0; i < iNumErrs; i++ )
    {
	   printf("Test");
    }
    return ITK_ok;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n str %s",str);fflush(stdout);
	printf("\n setAddStr %d",*count);fflush(stdout);

	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	if(str!=NULL)
	{
		(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
		tc_strcpy((*strset)[*count-1],str);
		printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
	}
}

 struct memory {
  char *response;
  size_t size;
};

static size_t WriteCallback(char *data, size_t size, size_t nmemb, void *clientp)
{
  size_t realsize = size * nmemb;
  struct memory *mem = (struct memory *)clientp;
 
  char *ptr = realloc(mem->response, mem->size + realsize + 1);
  if(!ptr)
    return 0;  /* out of memory */
 
  mem->response = ptr;
  memcpy(&(mem->response[mem->size]), data, realsize);
  mem->size += realsize;
  mem->response[mem->size] = 0;
  
  printf("\nWriteCallback done"); fflush(stdout);
 
  return realsize;
}

int parse_json_object(const char *json_string,char *ParseType) 
{
    int i = 0;
	//char *sap_proc_type = (char *)malloc(500 * sizeof(char));
	//char *sap_spproc_type = (char *)malloc(500 * sizeof(char));
	/* char *sap_proc_type = NULL;
	int sappproc;
	char sap_spproc_type[4]; */
    //char *sap_spproc_type = NULL;
	//char *PSAP_CS = (char *) malloc(50*sizeof(char));
	//char *PSAP_SLOC = (char *) malloc(50*sizeof(char));
	cJSON *json = cJSON_Parse(json_string);
	if (json == NULL) 
	{ 
        const char *error_ptr = cJSON_GetErrorPtr(); 
        if (error_ptr != NULL) 
		{ 
            printf("Error: %s\n", error_ptr); 
        } 
        cJSON_Delete(json); 
        return 1; 
    } 
	printf("\njson_string : [%s]\n\n",json_string);
	printf("\ncJSON_GetArraySize(json) : [%d]\n\n",cJSON_GetArraySize(json));
	
	printf ("\nParseType : [%s]",ParseType);
	
	if( tc_strcmp ( ParseType, "PSTAT" ) == 0 )
	{
		printf("\njson_string : [%s]\n\n",json_string);
		if( tc_strstr(json_string ,"BAPI_MATERIAL_GETALLResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALLResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "PLANTDATA");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				sap_proc_type = cJSON_GetObjectItem(moon_2, "PROC_TYPE")->valuestring; //Procurement type
				sappproc = cJSON_GetObjectItem(moon_2, "SPPROCTYPE")->valueint; //Special procurements
				//sap_spproc_type = cJSON_GetObjectItem(moon_2, "SPPROCTYPE")->valuestring; //Special procurement
				sloc1_type = cJSON_GetObjectItem(moon_2, "SLOC_EXPRC")->valuestring; //Storage loc. for EP
				//char *sloc2_type = cJSON_GetObjectItem(moon_2, "ISS_ST_LOC")->valuestring; //Prod. stor. location    
			}
			printf("Special Procurement[Integer]: [%d]",sappproc);
			sprintf(sap_spproc_type, "%d", sappproc);
            printf("Special Procurement[Integer To String]: [%s]",sap_spproc_type);
			printf("\n ....sap_proc_type..... : [%s]\n\n",sap_proc_type);
			printf("\n ....sap_spproc_type.... : [%s]\n\n",sap_spproc_type);
			printf("\n ....sloc1_type.... : [%s]\n\n",sloc1_type);
			
			//trimwhitespace(sap_proc_type);
			//trimwhitespace(sap_spproc_type);
			/* if((tc_strcmp(sap_proc_type,"")!=0) && (tc_strcmp(sap_proc_type," ")!=0) && (tc_strcmp(sap_proc_type,"    ")!=0))
			{
				printf("\nPart SAP CS Value is not NULL or Blank");
			    tc_strcpy(PSAP_CS,sap_proc_type);
				if((tc_strcmp(sap_spproc_type,"")!=0) && (tc_strcmp(sap_spproc_type," ")!=0) && (tc_strcmp(sap_spproc_type,"    ")!=0))
			    {
					printf("\nPart SAP Special Procurement Type Value is not NULL or Blank");
					tc_strcat(PSAP_CS,sap_spproc_type);
				}
				else
				{
					printf("\n Part SAP Special Procurement Type is Blank or NULL so, will not Concatinate with Procurement Type");fflush(stdout);
				}
			}
            else
            {
				printf("\nPart SAP CS Value is NULL or Blank");
			    tc_strcpy(PSAP_CS,"Blank");
			}
			//trimwhitespace(sloc1_type);
			if((tc_strcmp(sloc1_type,"")!=0) && (tc_strcmp(sloc1_type," ")!=0) && (tc_strcmp(sloc1_type,"    ")!=0))
			{
				printf("\nPart SAP SLOC Value is not NULL or Blank");
				tc_strcpy(PSAP_SLOC,sloc1_type);
			}
			else
			{
				printf("\nPart SAP SLOC Value is NULL or Blank");
				tc_strcpy(PSAP_SLOC,"Blank");
			} */
		}
		/* else
		{
			tc_strcpy(PSAP_CS,"Blank");
			tc_strcpy(PSAP_SLOC,"Blank");
		} */
	}
	else
	{
		printf("\n Returned jSON Object Not Valid..!!");
	}
	
	//printf("\n ....PSAP_CS..... : [%s]\n\n",PSAP_CS);
	//printf("\n ....PSAP_SLOC.... : [%s]\n\n",PSAP_SLOC);
			
	return 0;
}

void print_json_object(const char *json_string)
{
    cJSON *json = cJSON_Parse(json_string);
    char *formatted_json = cJSON_Print(json);
    printf("Formatted json_object: [%s]\n", formatted_json);
    cJSON_Delete(json);
    free(formatted_json);
}
 
 int tm_PLM_BAPI_MATERIAL_GETALL ( char *data )
{
	struct memory chunk = {0};
	char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) 
	{
       printf("\nFailed to initialize CURL");
       return 0;
    }
	
	struct curl_slist *list = NULL;
	curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_BAPI_MATERIAL_GETALL_CV");//PLM_BAPI_MATERIAL_GETALL_CV
	curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	
	list = curl_slist_append(list, "Content-Type: application/json");
    
	printf("\nFile request content as below "); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
	printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	res = curl_easy_perform(curl);
	
	printf("\ncurl_easy_perform");fflush(stdout);
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "PSTAT");
	
	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
	printf("\nfree"); fflush(stdout);
	
    curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	
	return 0;
}
 
 
 int cll_PLM_BAPI_MATERIAL_GETALL ( char *part_noDup, char *plantcode , char *json_pstat_req_obj )
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	char *out;
		
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();

	cJSON_AddItemToObject(rfc_root, "BAPI_MATERIAL_GETALL", exp_imp_tab_req);
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIAL", cJSON_CreateString(part_noDup));
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANT", cJSON_CreateString(plantcode));
	
	out = cJSON_Print(rfc_root);
	printf("Request Object For PLMSAP-PO-CS-SLOC: [%s]\n", out);
	tc_strcpy( json_pstat_req_obj, out ) ;
	free(out);
	cJSON_Delete(rfc_root);
	
	return 0;
}

char* TC_PartCS(tag_t PartRevtag, char* PartPlantName)
{
	
	trimwhitespace(PartPlantName);
	char *PartPlmCS = NULL;
	PartPlmCS = (char *) malloc(500*sizeof(char));
	char* PartPlmCSVal = NULL;
	char* PartPlmCSValDup = NULL;
	
	printf("\n Part Plant Name Value: [%s]\n", PartPlantName);fflush(stdout);
	if(tc_strcmp(PartPlantName,"1001")==0)
	{
		tc_strcpy(PartPlmCS,"t5_PunMakeBuyIndicator"); //APLP
	}
	else if(tc_strcmp(PartPlantName,"1100")==0)
	{
		tc_strcpy(PartPlmCS,"t5_CarMakeBuyIndicator"); //APLC
	}
	else if(tc_strcmp(PartPlantName,"1500")==0)
	{
		tc_strcpy(PartPlmCS,"t5_DwdMakeBuyIndicator"); //APLD
	}
	else if(tc_strcmp(PartPlantName,"2001")==0)
	{
		tc_strcpy(PartPlmCS,"t5_JsrMakeBuyIndicator"); //APLJ
	}
	else if(tc_strcmp(PartPlantName,"3001")==0)
	{
		tc_strcpy(PartPlmCS,"t5_LkoMakeBuyIndicator"); //APLL
	}
	else if(tc_strcmp(PartPlantName,"3100")==0)
	{
		tc_strcpy(PartPlmCS,"t5_PnrMakeBuyIndicator"); //APLU
	}
	else if(tc_strcmp(PartPlantName,"E201")==0) 
	{
		tc_strcpy(PartPlmCS,"t5_AhdMakeBuyIndicator"); //APLA
	}
	else if(tc_strcmp(PartPlantName,"7501")==0) 
	{
		tc_strcpy(PartPlmCS,"t5_JdlMakeBuyIndicator"); //APLS
	}
	else if(tc_strcmp(PartPlantName,"1140")==0) 
	{
		tc_strcpy(PartPlmCS,"t5_PunUVMakeBuyIndicator"); //APLV
	}
	else
	{
		printf(" Plant Code Invalid..!!\n");fflush(stdout);
	}
	trimwhitespace(PartPlmCS);
	printf("\n Part PLM CS(PartPlmCS):  [%s] \n",PartPlmCS);fflush(stdout);
	ITK_CALL(AOM_ask_value_string(PartRevtag,PartPlmCS,&PartPlmCSVal));
	if(tc_strlen(PartPlmCSVal)>0)
	{
		tc_strdup(PartPlmCSVal,&PartPlmCSValDup);
	}
	else
	{
		tc_strdup("Blank",&PartPlmCSValDup);
		printf("\n Part PLM CS Value is NULL");fflush(stdout);
	}
	printf("\n Part PLM CS Final Value(PartPlmCSValDup):  [%s]\n",PartPlmCSValDup);fflush(stdout);
	return PartPlmCSValDup;	
}

char* TC_PartSLOC(tag_t PartRevtag, char* PartPlantName)
{
	
	trimwhitespace(PartPlantName);
	char *PartPlmSloc = NULL;
	PartPlmSloc = (char *) malloc(20*sizeof(char));
	char* PartPlmSlocVal = NULL;
	char* PartPlmSlocValDup = NULL;
	
	printf("\n Part Plant Name Value: [%s]\n", PartPlantName);fflush(stdout);
	if(tc_strcmp(PartPlantName,"1001")==0)
	{
		tc_strcpy(PartPlmSloc,"t5_PunStoreLocation"); //APLP
	}
	else if(tc_strcmp(PartPlantName,"1100")==0)
	{
		tc_strcpy(PartPlmSloc,"t5_CarStoreLocation"); //APLC
	}
	else if(tc_strcmp(PartPlantName,"1500")==0)
	{
		tc_strcpy(PartPlmSloc,"t5_DwdStoreLocation"); //APLD
	}
	else if(tc_strcmp(PartPlantName,"2001")==0)
	{
		tc_strcpy(PartPlmSloc,"t5_JsrStoreLocation"); //APLJ
	}
	else if(tc_strcmp(PartPlantName,"3001")==0)
	{
		tc_strcpy(PartPlmSloc,"t5_LkoStoreLocation"); //APLL
	}
	else if(tc_strcmp(PartPlantName,"3100")==0)
	{
		tc_strcpy(PartPlmSloc,"t5_PnrStoreLocation"); //APLU
	}
	else if(tc_strcmp(PartPlantName,"E201")==0) 
	{
		tc_strcpy(PartPlmSloc,"t5_AhdStoreLocation"); //APLA
	}
	else if(tc_strcmp(PartPlantName,"7501")==0) 
	{
		tc_strcpy(PartPlmSloc,"t5_JdlStoreLocation"); //APLS
	}
	else if(tc_strcmp(PartPlantName,"1140")==0) 
	{
		tc_strcpy(PartPlmSloc,"t5_PunUVStoreLocation"); //APLV
	}
	else
	{
		printf(" Plant Code Invalid..!!\n");fflush(stdout);
	}
	trimwhitespace(PartPlmSloc);
	printf("\n Part PLM SLOC(PartPlmSloc):  [%s] \n",PartPlmSloc);fflush(stdout);
	ITK_CALL(AOM_ask_value_string(PartRevtag,PartPlmSloc,&PartPlmSlocVal));
	if(tc_strlen(PartPlmSlocVal)>0)
	{
		tc_strdup(PartPlmSlocVal,&PartPlmSlocValDup);
	}
	else
	{
		tc_strdup("Blank",&PartPlmSlocValDup);
		printf("\n Part PLM SLOC Value is NULL");fflush(stdout);
	}
	printf("\n Part PLM SLOC Final Value(PartPlmSlocValDup):  [%s]\n",PartPlmSlocValDup);fflush(stdout);
	return PartPlmSlocValDup;	
}

extern int ITK_user_main(int argc, char *argv[])
{
    /* char *PSAP_CS = (char *) malloc(50*sizeof(char));
	char *PSAP_SLOC = (char *) malloc(50*sizeof(char)); */
	return soap_serve(soap_new());

}
;

int ns__getItemData(struct soap* soap,char *Input_line_str,struct ns__CharArray1 *aString_test)
{
        int ifail = 0;
		int	tt1	= 0;
		char *loggedInUser = NULL;
		int iFail = 0;
        int n_tags_found = 0;
		tag_t* tags_found = NULLTAG;
		tag_t rev_tags_found = NULLTAG;
		tag_t item_t = NULLTAG;
		tag_t query = NULLTAG; 
		char* responseString1 = NULL;
		char* responseString2 = NULL;
		char* responseString3 = NULL;
		char* responseString4 = NULL;
		char* responseString5 = NULL;
		char* responseString6 = NULL;
		char* responseString7 = NULL;
		char* responseString8 = NULL;
		char* responseString9 = NULL;
		char* responseString10 = NULL;
		char* responseString11 = NULL;
		char* responseString12 = NULL;
		char* Print_Report = NULL;
		char* cProjectDes  = NULL;
        char* Proj_id  = NULL;
		char** ReportSetSTR = NULL;
		size_t len;
		int	status_count = 0;
		tag_t*	relStatus_list = NULLTAG;
		char *latest_rev_Rel_Status = NULL;
		char *latest_rev_Part_Type = NULL;
		char *LCState = NULL;
		LCState = (char *) malloc(50*sizeof(char));
		int n_entries = 2;
		//static RFC_RC RfcRc;
		plantcode=(char *) malloc (500 * sizeof(char));
		//sap_proc_type = (char *)malloc(500 * sizeof(char));
		//sap_spproc_type = (char *)malloc(500 * sizeof(char));
		SAPpstat = (char *)malloc(500 * sizeof(char));
		MRPpstat = (char *)malloc(500 * sizeof(char));
		//profit_centre_sap = (char *)malloc(500 * sizeof(char));
		sloc1_type = (char *) malloc(500*sizeof(char));
		sloc2_type = (char *) malloc(500*sizeof(char));
		char *Input_line_strDup = NULL;
		char *rspstring = NULL;
	    rspstring = (char *) malloc(100*sizeof(char));
		
		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
		freopen("/tmp/PLMSAPPartStatusReport.txt", "w", stdout);

        printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		CALLAPI(ITK_auto_login( ));
		CALLAPI(ITK_set_journalling( TRUE ));
		
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
		
		trimwhitespace(Input_line_str);
		if(Input_line_str!=NULL)tc_strdup(Input_line_str,&Input_line_strDup);
		printf(" [0]: Input Line(Input_line_str): [%s]\n",Input_line_strDup);
		InpPrt_str=tc_strtok(Input_line_strDup,",");
		InpPlnt_strDup=tc_strtok(NULL,",");
		
		if(InpPrt_str!=NULL)tc_strdup(InpPrt_str,&InpPrt_strDup);
		if(InpPlnt_str!=NULL)tc_strdup(InpPlnt_str,&InpPlnt_strDup);
		printf(" [1]: Input Part(InpPrt_strDup): [%s]\n",InpPrt_strDup);
		printf(" [2]: Input Plant(InpPlnt_strDup): [%s]\n",InpPlnt_strDup);
		
		if(tc_strcmp(InpPlnt_strDup,"1001")==0)
		{
			tc_strcpy(LCState,"T5_LcsAplpRlzd"); //APLP
		}
		else if(tc_strcmp(InpPlnt_strDup,"1100")==0)
		{
			tc_strcpy(LCState,"T5_LcsAplRlzd"); //APLC
		}
		else if(tc_strcmp(InpPlnt_strDup,"1500")==0)
		{
			tc_strcpy(LCState,"T5_LcsApldRlzd"); //APLD
		}
		else if(tc_strcmp(InpPlnt_strDup,"2001")==0)
		{
			tc_strcpy(LCState,"T5_LcsApljRlzd"); //APLJ
		}
		else if(tc_strcmp(InpPlnt_strDup,"3001")==0)
		{
			tc_strcpy(LCState,"T5_LcsApllRlzd"); //APLL
		}
		else if(tc_strcmp(InpPlnt_strDup,"3100")==0)
		{
			tc_strcpy(LCState,"T5_LcsApluRlzd"); //APLU
		}
		else if(tc_strcmp(InpPlnt_strDup,"E201")==0) 
		{
			tc_strcpy(LCState,"T5_LcsAplaRlzd"); //APLA
		}
		else if(tc_strcmp(InpPlnt_strDup,"7501")==0) 
		{
			tc_strcpy(LCState,"T5_LcsAplsRlzd"); //APLS
		}
		else if(tc_strcmp(InpPlnt_strDup,"1140")==0) 
		{
			tc_strcpy(LCState,"T5_LcsAplvRlzd"); //APLV
		}
		else
		{
			printf(" Plant Code Invalid..!!\n");fflush(stdout);
		}
		
		tag_t QryTag = NULLTAG;
		char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
		int num_to_sort = 1;
		int sort_order[1]  ={2};
		char *keysAttr[1] = {"creation_date"};
		int resultcount = 0;
		tag_t* titemobj_results = NULLTAG;
		tag_t LatestRev = NULLTAG;
		char* LatRevName = NULL;
		char* OwnerName = NULL;
		char* OwnerNameDup = NULL;
		char* PrtRev = NULL;
		char* PrtRevDup = NULL;
		char* PartRelStatus = NULL;
		char* Part_No = NULL;
		char* PPLM_CS = NULL;
		char* PPLM_SLOC = NULL;
		//char* PSAP_CS = NULL;
		//char* PSAP_SLOC = NULL;
		char *PSAP_CS = (char *) malloc(50*sizeof(char));
	    char *PSAP_SLOC = (char *) malloc(50*sizeof(char));
		
		ITK_CALL(QRY_find2("Driver VC Query",&QryTag));
		char *qry_entries[] = {"Item ID","Release Status"};
		qry_values[0] = InpPrt_strDup;
		qry_values[1] = LCState;
		ITK_CALL(QRY_execute_with_sort(QryTag, n_entries, qry_entries, qry_values, num_to_sort, keysAttr, sort_order, &resultcount, &titemobj_results));
		
		if(resultcount > 0)
		{
			//responseString1=(char *)MEM_alloc(200);
			//responseString2=(char *)MEM_alloc(200);
			responseString1=(char *)MEM_alloc(200);
			responseString2=(char *)MEM_alloc(200);
			responseString3=(char *)MEM_alloc(200);
			responseString4=(char *)MEM_alloc(200);
			responseString5=(char *)MEM_alloc(200);
			responseString6=(char *)MEM_alloc(200);
			
			LatestRev = titemobj_results[0];
			ITK_CALL(AOM_ask_value_string(LatestRev,"object_string",&LatRevName));
			ITK_CALL(AOM_UIF_ask_value(LatestRev,"owning_user",&OwnerName));
			tc_strdup(OwnerName,&OwnerNameDup);
			ITK_CALL(AOM_ask_value_string(LatestRev,"item_revision_id",&PrtRev));
			PrtRevDup=strtok(PrtRev,";");
			ITK_CALL(AOM_UIF_ask_value(LatestRev,"release_status_list",&PartRelStatus));
			ITK_CALL(AOM_ask_value_string(LatestRev,"item_id",&Part_No));
			
			printf("\n Part No: [%s]\n",Part_No);fflush(stdout);
			printf("\n Part Revision: [%s]\n",PrtRevDup);fflush(stdout);
			printf("\n Part Details: [%s]\n",LatRevName);fflush(stdout);
			printf("\n Owner Name: [%s]\n",OwnerNameDup);fflush(stdout);
			printf("\n Release Status: [%s]\n",PartRelStatus);fflush(stdout);
			
			tc_strdup(InpPlnt_strDup,&plantcode);
			
			printf("\n Function[1]: cll_PLM_BAPI_MATERIAL_GETALL() Start..!!\n");fflush(stdout);
			//tc_strcpy(sap_proc_type,"");
			//tc_strcpy(sap_spproc_type,"");
			
			char *json_pstat_req_obj = NULL;
			json_pstat_req_obj = malloc(34000);
			  
				cll_PLM_BAPI_MATERIAL_GETALL(InpPrt_strDup, plantcode,json_pstat_req_obj);
				printf("\nRequest String : %s\n", json_pstat_req_obj);
				tm_PLM_BAPI_MATERIAL_GETALL ( json_pstat_req_obj );
				
			if((tc_strcmp(sap_proc_type,"")!=0) && (tc_strcmp(sap_proc_type," ")!=0) && (tc_strcmp(sap_proc_type,"    ")!=0))
			{
				printf("\nPart SAP CS Value is not NULL or Blank");
			    tc_strcpy(PSAP_CS,sap_proc_type);
				if((tc_strcmp(sap_spproc_type,"")!=0) && (tc_strcmp(sap_spproc_type," ")!=0) && (tc_strcmp(sap_spproc_type,"    ")!=0))
			    {
					printf("\nPart SAP Special Procurement Type Value is not NULL or Blank");
					tc_strcat(PSAP_CS,sap_spproc_type);
				}
				else
				{
					printf("\n Part SAP Special Procurement Type is Blank or NULL so, will not Concatinate with Procurement Type");fflush(stdout);
				}
			}
            else
            {
				printf("\nPart SAP CS Value is NULL or Blank");
			    tc_strcpy(PSAP_CS,"Blank");
			}

			if((tc_strcmp(sloc1_type,"")!=0) && (tc_strcmp(sloc1_type," ")!=0) && (tc_strcmp(sloc1_type,"    ")!=0))
			{
				printf("\nPart SAP SLOC Value is not NULL or Blank");
				tc_strcpy(PSAP_SLOC,sloc1_type);
			}
			else
			{
				printf("\nPart SAP SLOC Value is NULL or Blank");
				tc_strcpy(PSAP_SLOC,"Blank");
			}
			
			printf("\n Before Free[PSAP_CS]: [%s]\n",PSAP_CS);fflush(stdout);
			printf("\n Before Free[PSAP_SLOC]: [%s]\n",PSAP_SLOC);fflush(stdout);
			
			free(json_pstat_req_obj);
			printf("\n Function[1]: cll_PLM_BAPI_MATERIAL_GETALL() End..!!\n");fflush(stdout);
			
			printf("\n After Free[PSAP_CS]: [%s]\n",PSAP_CS);fflush(stdout);
			printf("\n After Free[PSAP_SLOC]: [%s]\n",PSAP_SLOC);fflush(stdout);
			
			printf("\n Function[2]: TC_PartCS() Start..!!\n");fflush(stdout);
			PPLM_CS = TC_PartCS(LatestRev, plantcode);
			printf("\n Function[2]: TC_PartCS() End..!!\n");fflush(stdout);
			
			printf("\n Function[3]: TC_PartSLOC() Start..!!\n");fflush(stdout);
			PPLM_SLOC = TC_PartSLOC(LatestRev, plantcode);
			printf("\n Function[3]: TC_PartSLOC() End..!!\n");fflush(stdout);
			
			//if((tc_strcmp(PPLM_CS,PSAP_CS)==0) && (tc_strcmp(PPLM_SLOC,PSAP_SLOC)==0))
			if((tc_strcmp(PSAP_SLOC,"Blank")!=0) && (tc_strcmp(PPLM_SLOC,PSAP_SLOC)==0))
			{
				tc_strcpy(rspstring,"Yes");
				//tc_strcat(rspstring,plantcode);
			}
			else
			{
				tc_strcpy(rspstring,"No");
				//tc_strcat(rspstring,plantcode);
			}
			
			printf("\n#---------------------------------------------------------#");fflush(stdout);
			printf("\n Part No(InpPrt_strDup): [%s]", InpPrt_strDup);fflush(stdout);
			printf("\n Plant Name(plantcode): [%s]", plantcode);fflush(stdout);
			printf("\n Part SAP CS Response(PSAP_CS): [%s]", PSAP_CS);fflush(stdout);
			printf("\n Part SAP SLOC Response(PSAP_SLOC): [%s]", PSAP_SLOC);fflush(stdout);
			printf("\n Part PLM CS Response(PPLM_CS): [%s]", PPLM_CS);fflush(stdout);
			printf("\n Part PLM SLOC Response(PPLM_SLOC): [%s]", PPLM_SLOC);fflush(stdout);
			printf("\n Material Status(rspstring): [%s]", rspstring);fflush(stdout);
			printf("\n#---------------------------------------------------------#");fflush(stdout);
			
			//tc_strcpy(responseString1,"MATERIAL_NUMBER=");
			//tc_strcat(responseString1,InpPrt_strDup);
			//setAddStr(&tt1,&ReportSetSTR,responseString1);
			
			//tc_strcpy(responseString2,"PLANT_CODE=");
			//tc_strcat(responseString2,plantcode);
			//setAddStr(&tt1,&ReportSetSTR,responseString2);
			
			tc_strcpy(responseString1,"PLM_CS=");
			tc_strcat(responseString1,PPLM_CS);
			setAddStr(&tt1,&ReportSetSTR,responseString1);
			
			tc_strcpy(responseString2,"SAP_CS=");
			tc_strcat(responseString2,PSAP_CS);
			setAddStr(&tt1,&ReportSetSTR,responseString2);
			
			tc_strcpy(responseString3,"PLM_SLOC=");
			tc_strcat(responseString3,PPLM_SLOC);
			setAddStr(&tt1,&ReportSetSTR,responseString3);
			
			tc_strcpy(responseString4,"SAP_SLOC=");
			tc_strcat(responseString4,PSAP_SLOC);
			setAddStr(&tt1,&ReportSetSTR,responseString4);
			
			tc_strcpy(responseString5,"MATERIAL_STATUS=");
			tc_strcat(responseString5,rspstring);
			setAddStr(&tt1,&ReportSetSTR,responseString5);
			
			tc_strcpy(responseString6,"MATERIAL_SOURCE=");
			tc_strcat(responseString6,"TCUA");
			setAddStr(&tt1,&ReportSetSTR,responseString6);
			
			aString_test-> __size =tt1;
			//aString_test->__ptrItem = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrItem) );
			aString_test->__ptrDetails = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrDetails) );
			int i =0;
			for(i=0;i<tt1;i++)
			{
				/* aString_test->__ptrItem[i].PROJECT_ID = malloc(30 * sizeof(char *) );
			    strcpy(aString_test->__ptrItem[i].PROJECT_ID,responseString1); // PROJECT_ID

				aString_test->__ptrItem[i].ORGANIZATION_ID = malloc(30 * sizeof(char *) );
				strcpy(aString_test->__ptrItem[i].ORGANIZATION_ID,responseString2); // ORGANIZATION_ID */
								
				Print_Report = ReportSetSTR[i];
				printf("\n Print_Report: -----> <%s> \n",Print_Report);fflush(stdout);

				aString_test->__ptrDetails[i].PartIDDetails = malloc(500 * sizeof(char *) );
				strcpy(aString_test->__ptrDetails[i].PartIDDetails,Print_Report);

			}	
		}
		else
		{
			printf("\n Latest Revision Not Found in TCUA - CV..!!");fflush(stdout);
			
			responseString7=(char *)MEM_alloc(200);
			responseString8=(char *)MEM_alloc(200);
			responseString9=(char *)MEM_alloc(200);
			responseString10=(char *)MEM_alloc(200);
			responseString11=(char *)MEM_alloc(200);
			responseString12=(char *)MEM_alloc(200);
			
			tc_strdup(InpPlnt_strDup,&plantcode);
			
			printf("\n Function[1]: cll_PLM_BAPI_MATERIAL_GETALL() Start..!!\n");fflush(stdout);
			//tc_strcpy(sap_proc_type,"");
			//tc_strcpy(sap_spproc_type,"");
			
			char *json_pstat_req_obj = NULL;
			json_pstat_req_obj = malloc(34000);
			  
				cll_PLM_BAPI_MATERIAL_GETALL(InpPrt_strDup, plantcode,json_pstat_req_obj);
				printf("\nRequest String : %s\n", json_pstat_req_obj);
				tm_PLM_BAPI_MATERIAL_GETALL ( json_pstat_req_obj );
			
			if((tc_strcmp(sap_proc_type,"")!=0) && (tc_strcmp(sap_proc_type," ")!=0) && (tc_strcmp(sap_proc_type,"    ")!=0))
			{
				printf("\nPart SAP CS Value is not NULL or Blank");
			    tc_strcpy(PSAP_CS,sap_proc_type);
				if((tc_strcmp(sap_spproc_type,"")!=0) && (tc_strcmp(sap_spproc_type," ")!=0) && (tc_strcmp(sap_spproc_type,"    ")!=0))
			    {
					printf("\nPart SAP Special Procurement Type Value is not NULL or Blank");
					tc_strcat(PSAP_CS,sap_spproc_type);
				}
				else
				{
					printf("\n Part SAP Special Procurement Type is Blank or NULL so, will not Concatinate with Procurement Type");fflush(stdout);
				}
			}
            else
            {
				printf("\nPart SAP CS Value is NULL or Blank");
			    tc_strcpy(PSAP_CS,"Blank");
			}

			if((tc_strcmp(sloc1_type,"")!=0) && (tc_strcmp(sloc1_type," ")!=0) && (tc_strcmp(sloc1_type,"    ")!=0))
			{
				printf("\nPart SAP SLOC Value is not NULL or Blank");
				tc_strcpy(PSAP_SLOC,sloc1_type);
			}
			else
			{
				printf("\nPart SAP SLOC Value is NULL or Blank");
				tc_strcpy(PSAP_SLOC,"Blank");
			}
			
			printf("\n Before Free[PSAP_CS]: [%s]\n",PSAP_CS);fflush(stdout);
			printf("\n Before Free[PSAP_SLOC]: [%s]\n",PSAP_SLOC);fflush(stdout);
			
			free(json_pstat_req_obj);
			printf("\n Function[1]: cll_PLM_BAPI_MATERIAL_GETALL() End..!!\n");fflush(stdout);
			
			printf("\n After Free[PSAP_CS]: [%s]\n",PSAP_CS);fflush(stdout);
			printf("\n After Free[PSAP_SLOC]: [%s]\n",PSAP_SLOC);fflush(stdout);
			
			//if((tc_strcmp(PPLM_CS,PSAP_CS)==0) && (tc_strcmp(PPLM_SLOC,PSAP_SLOC)==0))
			if((tc_strcmp(PSAP_SLOC,"Blank")!=0) && (tc_strcmp(PPLM_SLOC,PSAP_SLOC)==0))
			{
				tc_strcpy(rspstring,"Yes");
				//tc_strcat(rspstring,plantcode);
			}
			else
			{
				tc_strcpy(rspstring,"No");
				//tc_strcat(rspstring,plantcode);
			}
			
			printf("\n#---------------------------------------------------------#");fflush(stdout);
			printf("\n Part No(InpPrt_strDup): [%s]", InpPrt_strDup);fflush(stdout);
			printf("\n Plant Name(plantcode): [%s]", plantcode);fflush(stdout);
			printf("\n Part SAP CS Response(PSAP_CS): [%s]", PSAP_CS);fflush(stdout);
			printf("\n Part SAP SLOC Response(PSAP_SLOC): [%s]", PSAP_SLOC);fflush(stdout);
			printf("\n Part PLM CS Response(PPLM_CS): [%s]", PPLM_CS);fflush(stdout);
			printf("\n Part PLM SLOC Response(PPLM_SLOC): [%s]", PPLM_SLOC);fflush(stdout);
			printf("\n Material Status(rspstring): [%s]", rspstring);fflush(stdout);
			printf("\n#---------------------------------------------------------#");fflush(stdout);
			
			//tc_strcpy(responseString1,"MATERIAL_NUMBER=");
			//tc_strcat(responseString1,InpPrt_strDup);
			//setAddStr(&tt1,&ReportSetSTR,responseString1);
			
			//tc_strcpy(responseString2,"PLANT_CODE=");
			//tc_strcat(responseString2,plantcode);
			//setAddStr(&tt1,&ReportSetSTR,responseString2);
			
			tc_strcpy(responseString7,"PLM_CS=");
			tc_strcat(responseString7,"NA");
			setAddStr(&tt1,&ReportSetSTR,responseString7);
			
			tc_strcpy(responseString8,"SAP_CS=");
			tc_strcat(responseString8,PSAP_CS);
			setAddStr(&tt1,&ReportSetSTR,responseString8);
			
			tc_strcpy(responseString9,"PLM_SLOC=");
			tc_strcat(responseString9,"NA");
			setAddStr(&tt1,&ReportSetSTR,responseString9);
			
			tc_strcpy(responseString10,"SAP_SLOC=");
			tc_strcat(responseString10,PSAP_SLOC);
			setAddStr(&tt1,&ReportSetSTR,responseString10);
			
			tc_strcpy(responseString11,"MATERIAL_STATUS=");
			tc_strcat(responseString11,rspstring);
			setAddStr(&tt1,&ReportSetSTR,responseString11);
			
			tc_strcpy(responseString12,"MATERIAL_SOURCE=");
			tc_strcat(responseString12,"TCE");
			setAddStr(&tt1,&ReportSetSTR,responseString12);
			
			aString_test-> __size =tt1;
			//aString_test->__ptrItem = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrItem) );
			aString_test->__ptrDetails = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrDetails) );
			int i =0;
			for(i=0;i<tt1;i++)
			{
				/* aString_test->__ptrItem[i].PROJECT_ID = malloc(30 * sizeof(char *) );
			    strcpy(aString_test->__ptrItem[i].PROJECT_ID,responseString1); // PROJECT_ID

				aString_test->__ptrItem[i].ORGANIZATION_ID = malloc(30 * sizeof(char *) );
				strcpy(aString_test->__ptrItem[i].ORGANIZATION_ID,responseString2); // ORGANIZATION_ID */
								
				Print_Report = ReportSetSTR[i];
				printf("\n Print_Report: -----> <%s> \n",Print_Report);fflush(stdout);

				aString_test->__ptrDetails[i].PartIDDetails = malloc(500 * sizeof(char *) );
				strcpy(aString_test->__ptrDetails[i].PartIDDetails,Print_Report);

			}	
		}
		printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
		
		fflush(stdout);
		dup2(fd, fileno(stdout));
		close(fd);
		clearerr(stdout);
		fsetpos(stdout, &pos);

	return SOAP_OK;
}