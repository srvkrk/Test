./compile tm_ARPBPCZIRemove.c
./linkitk -o tm_ARPBPCZIRemove tm_ARPBPCZIRemove.o
chmod 777 *
