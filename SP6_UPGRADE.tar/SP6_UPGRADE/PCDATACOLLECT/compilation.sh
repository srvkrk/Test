./compile PCDataCollect.c
./linkitk -o PCDataCollect PCDataCollect.o
chmod 777 *
