/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   PLM-SAP
*  Description  :   Profit Center Details Data Collect For PC Removal in PLM-SAP S/4-HANA 
*  File Name    :   PCDataCollect.c
*  Created on   :   Dec 04th, 2025
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     04/12/2025                 Sourav Karak
***************************************************************************/

#include "malloc.h"
#include "stdio.h"
#include <ae/dataset.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <tc/envelope.h>
#include <fclasses/tc_date.h>
#include <user_exits/epm_toolkit_utils.h>
#include <cJSON.h>
#include <curl/curl.h>
#define POM_MIN_lock_type_token   0
#define POM_no_lock   0
#define POM_modify_lock   1
#define POM_read_lock   2
#define POM_delete_lock   3
#define POM_MAX_lock_type_token   3
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\


char *proctype;
char *spl_proctype;
char *control_key;
char *cert_type;
char *insp_setup;
char *plantspec_mat_stat;

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: [%d]\tERROR MSG: [%s]\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: [%d]\tERROR MSG: [%s]\n", ifails[index], texts[index]);
			printf ("FUNCTION: [%s]\nFILE: [%s] LINE: [%d]\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: [%s]\nFILE: [%s] LINE: [%d]\n", function, file, line);
		}
		EMH_clear_errors();	
	}
	return return_code;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString(char* mainStringf ,int fromCharf ,int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}

struct memory {
  char *response;
  size_t size;
};

static size_t WriteCallback(char *data, size_t size, size_t nmemb, void *clientp)
{
  size_t realsize = size * nmemb;
  struct memory *mem = (struct memory *)clientp;
 
  char *ptr = realloc(mem->response, mem->size + realsize + 1);
  if(!ptr)
    return 0;  /* out of memory */
 
  mem->response = ptr;
  memcpy(&(mem->response[mem->size]), data, realsize);
  mem->size += realsize;
  mem->response[mem->size] = 0;
  
  printf("\n WriteCallback Done..!!"); fflush(stdout);
 
  return realsize;
}

int parse_json_object(const char *json_string,char *ParseType) 
{
    int i = 0;
	cJSON *json = cJSON_Parse(json_string);
	if (json == NULL) 
	{ 
        const char *error_ptr = cJSON_GetErrorPtr(); 
        if (error_ptr != NULL) 
		{ 
            printf("Error: %s\n", error_ptr); 
        } 
        cJSON_Delete(json); 
        return 1; 
    } 
	printf("\njson_string : [%s]\n\n",json_string);
	printf("\ncJSON_GetArraySize(json) : [%d]\n\n",cJSON_GetArraySize(json));
	
	printf ("\nParseType : [%s]",ParseType);
	
	if( tc_strcmp ( ParseType, "PSTAT" ) == 0 )
	{
		printf("\njson_string : [%s]\n\n",json_string);
		if( tc_strstr(json_string ,"BAPI_MATERIAL_GETALLResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALLResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "PLANTDATA");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				proctype = cJSON_GetObjectItem(moon_2, "PROC_TYPE")->valuestring; //Procurement Type
				spl_proctype = cJSON_GetObjectItem(moon_2, "SPPROCTYPE")->valuestring; //Special procurement
				control_key = cJSON_GetObjectItem(moon_2, "CTRL_KEY")->valuestring; //QM Control Key
				cert_type = cJSON_GetObjectItem(moon_2, "CERT_TYPE")->valuestring; //Certificate type
				insp_setup = cJSON_GetObjectItem(moon_2, "INSP_SETUP_FLAG")->valuestring; //QM proc. active
				plantspec_mat_stat = cJSON_GetObjectItem(moon_2, "PUR_STATUS")->valuestring; //Plant-sp. matl status   
			}
			printf("\n #---------- In[parse_json_object] -----------#");
			printf("\n Procurement Type: [%s]",proctype);
			printf("\n Special Procurement Type: [%s]",spl_proctype);
            printf("\n QM Control Key: [%s]",control_key);
			printf("\n Certificate Type: [%s]",cert_type);
			printf("\n QM proc. active: [%s]",insp_setup);
			printf("\n Plnt-sp. matl status: [%s]",plantspec_mat_stat);
			printf("\n #---------- In[parse_json_object] -----------#");
		}
	}
	else
	{
		printf("\n Returned JSON Object Not Valid..!!");
	}
			
	return 0;
}

void print_json_object(const char *json_string)
{
    cJSON *json = cJSON_Parse(json_string);
    char *formatted_json = cJSON_Print(json);
    printf("Formatted json_object: [%s]\n", formatted_json);
    cJSON_Delete(json);
    free(formatted_json);
}
 
 int tm_PLM_BAPI_MATERIAL_GETALL ( char *data )
{
	struct memory chunk = {0};
	char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) 
	{
       printf("\n Failed To Initialize CURL..!!");
       return 0;
    }
	
	struct curl_slist *list = NULL;
	curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_BAPI_MATERIAL_GETALL_CV"); //PLM_BAPI_MATERIAL_GETALL_CV
	curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	
	list = curl_slist_append(list, "Content-Type: application/json");
    
	printf("\nFile request content as below "); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
	printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	res = curl_easy_perform(curl);
	
	printf("\ncurl_easy_perform");fflush(stdout);
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "PSTAT");
	
	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
	printf("\nfree"); fflush(stdout);
	
    curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	
	return 0;
}
 
 
 int cll_PLM_BAPI_MATERIAL_GETALL ( char *part_noDup, char *plantcode , char *json_pstat_req_obj )
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	char *out;
		
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();

	cJSON_AddItemToObject(rfc_root, "BAPI_MATERIAL_GETALL", exp_imp_tab_req);
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIAL", cJSON_CreateString(part_noDup));
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANT", cJSON_CreateString(plantcode));
	
	out = cJSON_Print(rfc_root);
	printf("Request Object For PLMSAP System Tag: [%s]\n", out);
	tc_strcpy( json_pstat_req_obj, out ) ;
	free(out);
	cJSON_Delete(rfc_root);
	
	return 0;
}

char* TC_PartDesc(char* PSrch,char* PRevSeqSrch)
{
	
	trimwhitespace(PSrch);
	trimwhitespace(PRevSeqSrch);
	tag_t tpQryobj = NULLTAG;
	int np_entries = 2;
	int np_Qryobj_found = 0;
	tag_t* tpQryobj_results = NULLTAG;
	char* cItem_Desc = NULL;
	char* cItem_DescDup = NULL;
	tag_t DesRev_tag = NULLTAG;
	char *Item_revseq = NULL;
	int m = 0;
	printf("\n Searched Part Number Value: [%s]\n", PSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpQryobj));
    if(tpQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully...");fflush(stdout);
		char *PartEntries[2]  = {"Revision","ID"};
		char *PartValues[2]  = {PRevSeqSrch,PSrch};
		ITK_CALL(QRY_execute(tpQryobj, np_entries, PartEntries, PartValues, &np_Qryobj_found, &tpQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",np_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(np_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (m = 0; m < np_Qryobj_found; m++)
			{
				tag_t rev_tags_found = NULLTAG;
				rev_tags_found = tpQryobj_results[m];
				if(rev_tags_found != NULLTAG)
				{	
					AOM_ask_value_string(tpQryobj_results[m],"object_desc",&cItem_Desc);
					printf("\n Item Description Before Dup & Trim:  <%s> \n",cItem_Desc);fflush(stdout);
					if(tc_strlen(cItem_Desc)>0)
					{
						tc_strdup(cItem_Desc,&cItem_DescDup);
					}
					else
					{
						tc_strdup("--",&cItem_DescDup);
						printf("\n Item Description Value is NULL");fflush(stdout);
					}
					trimwhitespace(cItem_DescDup);
					printf("\n Item Description Value After Dup & Trim: [%s]", cItem_DescDup);fflush(stdout);
					STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
					printf("\n Item Description Final Value: [%s]", cItem_DescDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&cItem_DescDup);
					printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&cItem_DescDup);
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&cItem_DescDup);
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	return cItem_DescDup;	
}

int TC_ValidVC_Details(char *PType, FILE *VRpt)
{
	char *item_id_str = NULL;
	char *item_revseq_str = NULL;
	char *item_rev_str = NULL;
	char *item_seq_str = NULL;
	char *item_product_str = NULL;
	char *item_bypass_str = NULL;
	char *item_id_strDup = NULL;
	char *item_revseq_strDup = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	char *item_product_strDup = NULL;
	char *item_bypass_strDup = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 3;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	tag_t DesRev_tag = NULLTAG;
	int ChldCount = 0;
	tag_t *PartChildTags = NULLTAG;
	int iFail = ITK_ok;
	char *cItem_RevSeq = NULL;
	char *item_desc = NULL;

	printf("\n Searched Part Type: [%s]\n", PType);fflush(stdout);
	ITK_CALL(QRY_find2("MCC_ERC_Released_Latest_Revision",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query [MCC_ERC_Released_Latest_Revision] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[3]  = {"Item ID","Part Type","Type"};
		char *cValues[3]  = {"????????????",PType,"Design Revision"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf("\n Query [MCC_ERC_Released_Latest_Revision] Found..!!\n");fflush(stdout);
			for (i = 0; i < n_itemobj_found; i++)
			{
				DesRev_tag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&item_id_str));
				if(tc_strlen(item_id_str)>0)
				{
					tc_strdup(item_id_str,&item_id_strDup);
				}
				else
				{
					tc_strdup("--",&item_id_strDup);
					printf("\n Part_No Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_revision_id",&item_revseq_str));
				if(tc_strlen(item_revseq_str)>0)
				{
					tc_strdup(item_revseq_str,&item_revseq_strDup);
					item_rev_strDup=tc_strtok(item_revseq_strDup,";");
					item_seq_strDup=tc_strtok(NULL,";");
				}
				else
				{
					tc_strdup("--",&item_revseq_strDup);
					tc_strdup("--",&item_rev_strDup);
					tc_strdup("--",&item_seq_strDup);
					printf("\n Part Rev_seq Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i], "item_revision_id", &cItem_RevSeq));
				trimwhitespace(cItem_RevSeq);
				printf("\n Part Rev-Seq Value After Trim: [%s]\n", cItem_RevSeq);fflush(stdout);
				
				item_desc = TC_PartDesc(item_id_strDup,cItem_RevSeq);
				printf("\n Part Description Value: [%s]", item_desc);fflush(stdout);
			}
		}
		else
		{
		  printf(" Query [MCC_ERC_Released_Latest_Revision] Not Found..!!\n");fflush(stdout);
		}
	}
	else
	{
	   printf(" [MCC_ERC_Released_Latest_Revision] Query Tag Not Found..!!\n");fflush(stdout);
	}

    return iFail;
}

extern int ITK_user_main(int argc, char ** argv )
{
	char *message;
	char *loggedInUser = NULL;
	char *inp_id_str = NULL;
	char *inp_plant_str = NULL;
	char *inputPart = NULL;
	char *inputPartRev = NULL;
	char *inputPartSeq = NULL;
	char *iPlantCode = NULL;
	char *inp_file_str = NULL;
	char *inp_file_strDup = NULL;
	char *inputfile = NULL;
	char *PNRevSeqSrch = (char *) malloc(20*sizeof(char));
	tag_t tpLCQryobj = NULLTAG;
	int nplc_entries = 2;
	int nplc_Qryobj_found = 0;
	tag_t* tpLCQryobj_results = NULLTAG;
	char *RptFile = (char *) malloc(200*sizeof(char));
	char *RptFile1 = (char *) malloc(200*sizeof(char));
	char *RptFile2 = (char *) malloc(200*sizeof(char));
	FILE *fpPart_List = NULL;
	FILE *fpOutput_file = NULL;
	FILE *fpplantop_file = NULL;
    char Buffer[MAX_LINE_LENGTH];
	tag_t rev_tags_found = NULLTAG;

	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

    printf("\n Generating VC Details File Name..!!");fflush(stdout);
    tc_strcpy(RptFile2,"valid_vc_details");
    tc_strcat(RptFile2,"_");
    tc_strcat(RptFile2,GenDate);
    tc_strcat(RptFile2,".txt");
    printf("\n VC Details File Name: [%s]", RptFile2);fflush(stdout);
    printf("\n VC Details File Generated..!!");fflush(stdout);
	FILE *fpvcdet_file = fopen(RptFile2, "w");
	if(fpvcdet_file == NULL)
	{
	    printf("\n Unable to Create VC Details File: --------> [%s]",RptFile2);fflush(stdout);
		return 0;
	}
	printf("\n Function1: Vehicle Combination Details Find Start\n");fflush(stdout);
    TC_ValidVC_Details("VC",fpvcdet_file);
    printf("\n Function1: Vehicle Combination Details Find End\n");fflush(stdout);


	
	inputfile = ITK_ask_cli_argument("-File=");
	//if(inp_file_str!=NULL)tc_strdup(inp_file_str,&inputfile);
	printf(" [1]: Input File(inputfile): [%s]\n",inputfile);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"PLM_SAP_System_Tag_Status_Report");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".txt");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	
	printf("\n Generating Plantwise Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile1,"Plantwise_PLM_SAP_System_Tag_Status_Report");
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,GenDate);
	tc_strcat(RptFile1,".csv");
	printf("\n Plantwise Report File Name: [%s]", RptFile1);fflush(stdout);
	printf("\n Plantwise Report File Generated..!!");fflush(stdout);
	
	fpPart_List = fopen(inputfile,"r"); 
    fpOutput_file = fopen(RptFile, "w");
	fpplantop_file = fopen(RptFile1, "w");
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	if(fpplantop_file == NULL)
	{
	    printf("\n Unable to Create Plantwise Report File: --------> [%s]",RptFile1);fflush(stdout);
		return 0;
	}
	fprintf(fpplantop_file,"PART_NO, REV, SEQ, PLANT, FINAL_STATUS, QM_PROC._ACTIVE(TICK MARK), QM_CONTROL_KEY, CERTIFICATE_TYPE, PLANT_SP_MATERIAL_STATUS, PROCUREMENT_TYPE, SPECIAL_PROCUREMENT_TYPE\n");fflush(fpplantop_file);
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		char *json_pstat_req_obj = NULL;
		json_pstat_req_obj = malloc(34000);
		/* char *LCState = NULL;
		char *LCStateDup = NULL;
	    //LCState = (char *) malloc(3000*sizeof(char));
		LCState =(char *) MEM_alloc(3000 * sizeof(char *));
		tc_strcpy(LCState,"@"); */
			while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
			{
				inputPart=tc_strtok(Buffer,"^");
				inputPartRev=tc_strtok(NULL,"^");
				inputPartSeq=tc_strtok(NULL,"^");

				printf("\n 1111....inputPart: [%s]\n", inputPart);
				printf("\n 2222....inputPartRev: [%s]\n", inputPartRev);
				printf("\n 3333....inputPartSeq: [%s]\n", inputPartSeq);
				
				tc_strcpy(PNRevSeqSrch,inputPartRev);
				tc_strcat(PNRevSeqSrch,"*");
				tc_strcat(PNRevSeqSrch,inputPartSeq);
				printf("\n Final Revision & Sequence: [%s]\n", PNRevSeqSrch);fflush(stdout);
				
				char *LCState = NULL;
				char *LCStateDup = NULL;
				//LCState = (char *) malloc(3000*sizeof(char));
				LCState =(char *) MEM_alloc(500 * sizeof(char *));
				tc_strcpy(LCState,"@");
				
				ITK_CALL(QRY_find2("DesignRevision Sequence",&tpLCQryobj));
				if(tpLCQryobj!=NULLTAG)
				{
					printf("\n DesignRevision Sequence Query Found Successfully..!! \n");fflush(stdout);
					char *PartLCEntries[2]  = {"Revision","ID"};
					char *PartLCValues[2]  = {PNRevSeqSrch,inputPart};
					ITK_CALL(QRY_execute(tpLCQryobj, nplc_entries, PartLCEntries, PartLCValues, &nplc_Qryobj_found, &tpLCQryobj_results));
					printf("\n -----------------------------------------------\n");fflush(stdout);
					printf("\n No of Revision Found: [%d]\n",nplc_Qryobj_found);fflush(stdout);
					printf("\n -----------------------------------------------\n");fflush(stdout);
					if(nplc_Qryobj_found > 0)
					{
						int	status_count = 0;
						tag_t* relStatus_list = NULLTAG;
						char* latest_rev_Rel_Status = NULL;
						char* latest_rev_Rel_StatusDup = NULL;			
						rev_tags_found = tpLCQryobj_results[0];
						//int lock_token = 0;
						//ITK_CALL(POM_ask_instance_lock(rev_tags_found, &lock_token));
						//printf("\n POM_ask_instance_lock Status: -----> <%d> \n",lock_token);fflush(stdout);
						ITK_CALL(WSOM_ask_release_status_list(rev_tags_found, &status_count, &relStatus_list));
						printf("\n No of Release Status Found: -----> <%d> \n",status_count);fflush(stdout);
						if(status_count>0)
						{
							int g = 0;
							for(g = 0; g<status_count; g++)
							{			  
								ITK_CALL(AOM_ask_value_string(relStatus_list[g],"object_name",&latest_rev_Rel_StatusDup));
								printf("\n Latest_Rev_Rel_Status: ------> <%s> \n",latest_rev_Rel_StatusDup);fflush(stdout);
								if(tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsAplpRlzd")==0)
								{
									tc_strcat(LCState,"1001_"); //APLP
									tc_strcat(LCState,",");
								}
								else if(tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsAplRlzd")==0)
								{
									tc_strcat(LCState,"1100_"); //APLC
									tc_strcat(LCState,",");
								}
								else if(tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsApldRlzd")==0)
								{
									tc_strcat(LCState,"1500_"); //APLD
									tc_strcat(LCState,",");
								}
								else if(tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsApljRlzd")==0)
								{
									tc_strcat(LCState,"2001_"); //APLJ
									tc_strcat(LCState,",");
								}
								else if(tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsApllRlzd")==0)
								{
									tc_strcat(LCState,"3001_"); //APLL
									tc_strcat(LCState,",");
								}
								else if(tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsApluRlzd")==0)
								{
									tc_strcat(LCState,"3100_"); //APLU
									tc_strcat(LCState,",");
								}
								else if(tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsAplaRlzd")==0)
								{
									tc_strcat(LCState,"E201_"); //APLA
									tc_strcat(LCState,",");
								}
								else if(tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsAplsRlzd")==0)
								{
									tc_strcat(LCState,"7501_"); //APLS
									tc_strcat(LCState,",");
								}
								else if(tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsAplvRlzd")==0)
								{
									tc_strcat(LCState,"1140_"); //APLV
									tc_strcat(LCState,",");
								}
								else
								{
									printf(" Plant Code Invalid..!!\n");fflush(stdout);
								}			  
							}
						}
					}
				}
				printf("\n LC State(Before Replace - @): [%s]",LCState);fflush(stdout);
				tc_strcat(LCState,"@");
	            STRNG_replace_str(LCState,"@","",&LCState);
				printf("\n LC State(After Replace - @): [%s]",LCState);fflush(stdout);
				if(tc_strlen(LCState)>0)
				{
					tc_strdup(LCState,&LCStateDup);
					char token_list[20][20];
					char* token = strtok(LCStateDup, ",");
					int num_tokens = 0;
					int totalrelplant = 0;
					while(token != NULL) 
					{
						strcpy(token_list[num_tokens], token); 
						num_tokens++;
						totalrelplant++;
						token = strtok(NULL, ",");
					}					
					printf("\n No of Applicable Plants: [%d]",num_tokens);fflush(stdout);
					printf("\n No of Total Released Plants: [%d]",totalrelplant);fflush(stdout);
					
					/* char token_list[20][20];
					char* token = tc_strtok(LCStateDup, ",");
					int num_tokens = 0;
					int totalrelplant = 0;
					while(token != NULL) 
					{
						strcpy(token_list[num_tokens], token);
						num_tokens++;
						totalrelplant++;
						token = tc_strtok(NULL, "/");
					}					
					printf("\n No of Applicable Plants: [%d]",num_tokens);fflush(stdout);
					printf("\n No of Total Released Plants: [%d]",totalrelplant);fflush(stdout); */	
					int c=0;
					int totalpassplant = 0;
					int totalfailplant = 0;
					for (c=0; c < num_tokens; c++)
					{
						char* InpLine = (char *) malloc(20*sizeof(char));
						tc_strcpy(InpLine,token_list[c]);
						printf("\n Input_Line:  [%s]",InpLine);fflush(stdout);
						iPlantCode = tc_strtok(InpLine,"_");
						printf("Plant_Code: [%s] \n", iPlantCode);fflush(stdout);
						printf("\n Function[1]: cll_PLM_BAPI_MATERIAL_GETALL() Start..!!\n");fflush(stdout);	
						cll_PLM_BAPI_MATERIAL_GETALL(inputPart, iPlantCode,json_pstat_req_obj);
						printf("\nRequest String: [%s]\n", json_pstat_req_obj);
						tm_PLM_BAPI_MATERIAL_GETALL ( json_pstat_req_obj );
						printf("\n\n #---------- In[Main-Function] -----------#");
						printf("\n Procurement Type: [%s]",proctype);
			            printf("\n Special Procurement Type: [%s]",spl_proctype);
						printf("\n QM Control Key: [%s]",control_key);
						printf("\n Certificate Type: [%s]",cert_type);
						printf("\n QM proc. active: [%s]",insp_setup);
						printf("\n Plnt-sp. matl status: [%s]",plantspec_mat_stat);
						printf("\n #---------- In[Main-Function] -----------#");
						printf("\n Function[1]: cll_PLM_BAPI_MATERIAL_GETALL() End..!!\n");fflush(stdout);
						
						if(tc_strlen(proctype)>0)
						{
							if((tc_strcmp(proctype,"E")==0) && (tc_strlen(control_key)>0) && (tc_strlen(insp_setup)>0) && (tc_strlen(plantspec_mat_stat)<=0) && (plantspec_mat_stat!=NULL))
							{
								totalpassplant = totalpassplant + 1;
								fprintf(fpplantop_file,"%s,%s,%s,%s,%s,%s,'%s,'%s,%s,%s,%s\n",inputPart,inputPartRev,inputPartSeq,iPlantCode,"PASS",insp_setup,control_key,cert_type,plantspec_mat_stat,proctype,spl_proctype);fflush(fpplantop_file);
							}
							else if((tc_strcmp(proctype,"F")==0) && (tc_strcmp(spl_proctype,"40")!=0) && (tc_strlen(control_key)>0) && (tc_strlen(cert_type)>0) && (tc_strlen(insp_setup)>0) && (tc_strlen(plantspec_mat_stat)<=0) && (plantspec_mat_stat!=NULL))
							{
								totalpassplant = totalpassplant + 1;
								fprintf(fpplantop_file,"%s,%s,%s,%s,%s,%s,'%s,'%s,%s,%s,%s\n",inputPart,inputPartRev,inputPartSeq,iPlantCode,"PASS",insp_setup,control_key,cert_type,plantspec_mat_stat,proctype,spl_proctype);fflush(fpplantop_file);
							}
							else if((tc_strcmp(proctype,"F")==0) && (tc_strcmp(spl_proctype,"40")==0) && (tc_strlen(control_key)>0) && (tc_strlen(cert_type)>0) && (tc_strlen(insp_setup)>0) && (tc_strlen(plantspec_mat_stat)<=0) && (plantspec_mat_stat!=NULL))
							{
								totalpassplant = totalpassplant + 1;
								fprintf(fpplantop_file,"%s,%s,%s,%s,%s,%s,'%s,'%s,%s,%s,%s\n",inputPart,inputPartRev,inputPartSeq,iPlantCode,"PASS",insp_setup,control_key,cert_type,plantspec_mat_stat,proctype,spl_proctype);fflush(fpplantop_file);
							}
							else
							{
								totalfailplant = totalfailplant + 1;
								fprintf(fpplantop_file,"%s,%s,%s,%s,%s,%s,'%s,'%s,%s,%s,%s\n",inputPart,inputPartRev,inputPartSeq,iPlantCode,"FAIL",insp_setup,control_key,cert_type,plantspec_mat_stat,proctype,spl_proctype);fflush(fpplantop_file);
							}
						}
						else
						{
							totalfailplant = totalfailplant + 1;
							fprintf(fpplantop_file,"%s,%s,%s,%s,%s,%s,'%s,'%s,%s,%s,%s\n",inputPart,inputPartRev,inputPartSeq,iPlantCode,"FAIL",insp_setup,control_key,cert_type,plantspec_mat_stat,proctype,spl_proctype);fflush(fpplantop_file);
						}
					}
					if((totalrelplant == totalpassplant) && (totalfailplant == 0))
					{
						printf(" !!!!!!! Part [%s] Passed From All Plant..!!\n");fflush(stdout);
						if(tc_strlen(inputPart)>0)
						{
							fprintf(fpOutput_file,"%s^%s^%s^%s^\n",inputPart,inputPartRev,inputPartSeq,"PASS");fflush(fpOutput_file);
						}
						else
						{
							printf(" Input Part_No is NULL..!!\n");fflush(stdout);
						}
					}
					else
					{
						printf(" Part [%s] Failed..!!\n");fflush(stdout);
						fprintf(fpOutput_file,"%s^%s^%s^%s^\n",inputPart,inputPartRev,inputPartSeq,"FAIL");fflush(fpOutput_file);
					}
				}
				else
				{
					tc_strdup(" ",&LCStateDup);
					printf("\n Response File Value is NULL..!!");fflush(stdout);
					fprintf(fpOutput_file,"%s^%s^%s^%s^\n",inputPart,inputPartRev,inputPartSeq,"FAIL");fflush(fpOutput_file);
					fprintf(fpplantop_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",inputPart,inputPartRev,inputPartSeq,"","FAIL","","","","","","");fflush(fpplantop_file);
				}
				
			}
			free(json_pstat_req_obj);
	}
	else
	{
	   printf(" Input File is Null..!!\n");fflush(stdout);
	}
	fprintf(fpplantop_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpplantop_file);
	fclose(fpPart_List);
	fclose(fpplantop_file);
	fclose(fpOutput_file);

	printf(" PLM-SAP System Tag Generation End..!!\n");fflush(stdout);	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
	CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}
