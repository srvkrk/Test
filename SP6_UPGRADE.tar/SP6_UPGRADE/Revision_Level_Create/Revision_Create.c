#include "malloc.h"
#include "stdio.h"
#include <ae/dataset.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <tc/envelope.h>
#include <fclasses/tc_date.h>
#include <user_exits/epm_toolkit_utils.h>
#include <cJSON.h>
#include <curl/curl.h>
#define MAX_LINE_LENGTH 1000

int status =0;
char *p;
char *inputPart = NULL;
char *rev = NULL;
char *iSapServer = NULL;
char *changeno = NULL;
char sap_dml_no[13]={0};
char sap_part_no[15]={0};
char sap_rev_sheet_status[3]={0};

#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)
int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3]);
void rfc_error(char *);
void getTodayDate(char* StdDate);
int DATE_date_to_string (date_t date_struct, const char *format_str, char **date_str);
int EPM__parse_string (const char *pszInputString, char *pszSeparator, int *piStringCount, char ***pppStringList);
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}

char* subString(char* mainStringf ,int fromCharf ,int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}

void getTodayDate(char* StdDate)
{
	struct tm *Sys_T = NULL;
	int Month;
	int Day;
	int Year;
	int hour;
	int min;
	int sec;

	time_t Tval = 0;
	Tval = time(NULL);
	Sys_T = localtime(&Tval);
	Day=Sys_T->tm_mday;
	Month=Sys_T->tm_mon+1;
	Year=1900 + Sys_T->tm_year;
	hour = Sys_T->tm_hour;
	min = Sys_T->tm_min;
	sec = Sys_T->tm_sec;

	sprintf(StdDate,"%02d%02d%02d",Month,Day,Year);
	printf("\nDate:[%s]",StdDate); fflush(stdout);
}

void getCurrentDateTime(char cCurrentAccessDate[20])
{
	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char    DateS[4];
	printf("getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("cCurrentAccessDate:%s\n",cCurrentAccessDate);

	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

struct memory {
  char *response;
  size_t size;
};

static size_t WriteCallback(char *data, size_t size, size_t nmemb, void *clientp)
{
  size_t realsize = size * nmemb;
  struct memory *mem = (struct memory *)clientp;
 
  char *ptr = realloc(mem->response, mem->size + realsize + 1);
  if(!ptr)
    return 0;  /* out of memory */
 
  mem->response = ptr;
  memcpy(&(mem->response[mem->size]), data, realsize);
  mem->size += realsize;
  mem->response[mem->size] = 0;
  
  printf("\n WriteCallback done"); fflush(stdout);
 
  return realsize;
}

int parse_json_object(const char *json_string,char *ParseType) 
{
    int i = 0;
	cJSON *json = cJSON_Parse(json_string);
	if (json == NULL) 
	{ 
        const char *error_ptr = cJSON_GetErrorPtr(); 
        if (error_ptr != NULL) 
		{ 
            printf("Error: [%s]\n", error_ptr); 
        } 
        cJSON_Delete(json); 
        return 1; 
    } 
	printf("\njson_string: [%s]\n\n",json_string); //to see complete response
	printf("\ncJSON_GetArraySize(json): [%d]\n\n",cJSON_GetArraySize(json));
	
	printf ("\nParseType: [%s]",ParseType);
	if ( tc_strcmp ( ParseType, "MAT_REV" ) == 0 )
	{
		const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZPPRFC_REVISIONNUM_CHANGEResponse");
		const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "MESSG");
			
		for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
		{
			char *tm_Message = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
			printf("\n @@@@@@@@@@@@ REVISION LEVEL CREATION STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			printf("\n Revision_Level_Create_Message: [%s]\n", tm_Message);fflush(stdout);
			printf("\n SAP Msg for Revision Level Creation: [%s]\n", tm_Message);fflush(stdout);
			printf("\n @@@@@@@@@@@@ REVISION LEVEL CREATION STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
		}
	}
	else if ( tc_strcmp ( ParseType, "ARPBPCZI_REMOVE" ) == 0 )
	{
		printf("\njson_string : [%s]\n\n",json_string);
		if( tc_strstr(json_string ,"ZBAPI_MATERIAL_SAVEDATAResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZBAPI_MATERIAL_SAVEDATAResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "RETURN");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_matcrexmsg = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
				printf("\n @@@@@@@@@@@@ MATERIAL CREATE/EXTEND STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			    printf("\n SAP Msg for Material Create/Extend: [%s]\n", tm_matcrexmsg);fflush(stdout);
				printf("\n @@@@@@@@@@@@ MATERIAL CREATE/EXTEND STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			}
		}
	}
	else
	{
	  printf("\n ~~~~~~~~~ ParseType Not Matched ~~~~~~~~~~~\n");fflush(stdout);
	}
			
	return 0;
}

void print_json_object(const char *json_string)
{
    cJSON *json = cJSON_Parse(json_string);
    char *formatted_json = cJSON_Print(json);
    printf("%s\n", formatted_json);
    cJSON_Delete(json);
    free(formatted_json);
}

int create_mat_rev_in_sap ( char *data )
{
	struct memory chunk = {0};
	char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }
	
	struct curl_slist *list = NULL;
	
	if ( tc_strcmp ( iSapServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_REVISIONNUM_CHANGE_CV"); //Create in Development
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234"); //with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_REVISIONNUM_CHANGE_CV_QA"); //Create in Quality
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234"); //with credential
	}
	else if ( tc_strcmp ( iSapServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_REVISIONNUM_CHANGE_CV"); //Create in Production
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234"); //with credential
	}
	else
	{
		printf("\n iSapServer is Blank..!!");fflush(stdout);
	}
	
	list = curl_slist_append(list, "Content-Type: application/json");
	
	printf("\nFile request content as below "); fflush(stdout);
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);
	
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
	
	printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	
	printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);
	
	res = curl_easy_perform(curl);
	
	printf("\ncurl_easy_perform");fflush(stdout);
	printf("\nprint_json_object"); fflush(stdout);
	
	parse_json_object(chunk.response, "MAT_REV");
	
	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);
	
	printf("\nfree"); fflush(stdout);
	
    curl_easy_cleanup(curl);
	
	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}
int material_rev_json_cr ( char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3],char *json_mat_rev_cr_req_obj )
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	char *out;
	
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	cJSON_AddItemToObject(rfc_root, "ZPPRFC_REVISIONNUM_CHANGE", exp_imp_tab_req);
	
	cJSON_AddItemToObject(exp_imp_tab_req, "AENNR", cJSON_CreateString(sap_dml_no));
	cJSON_AddItemToObject(exp_imp_tab_req, "MATNR", cJSON_CreateString(sap_part_no));
	cJSON_AddItemToObject(exp_imp_tab_req, "REVLV", cJSON_CreateString(sap_rev_sheet_status));
	
	
	out = cJSON_Print(rfc_root);
	tc_strcpy(json_mat_rev_cr_req_obj,out);
	free(out);
	cJSON_Delete(rfc_root);
	
	return 0;
}

int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3])
{
	char *json_mat_rev_cr_req_obj = NULL;
	json_mat_rev_cr_req_obj = malloc(34000);
	material_rev_json_cr ( sap_dml_no, sap_part_no, sap_rev_sheet_status, json_mat_rev_cr_req_obj );
	printf("%s\n", json_mat_rev_cr_req_obj);
	create_mat_rev_in_sap ( json_mat_rev_cr_req_obj );
	free(json_mat_rev_cr_req_obj);
}

extern int ITK_user_main(int argc, char ** argv )
{
	char *message;
	char *loggedInUser = NULL;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	changeno = ITK_ask_cli_argument("-i=");
	inputPart = ITK_ask_cli_argument("-j=");
	rev = ITK_ask_cli_argument("-k=");
	iSapServer = ITK_ask_cli_argument("-s=");
	
	printf("\n 1111....changeno: [%s]\n", changeno);
	printf("\n 2222....inputPart: [%s]\n", inputPart);
	printf("\n 3333....rev: [%s]\n", rev);
	printf("\n 4444....iSapServer: [%s]\n", iSapServer);
	
	if((tc_strlen(changeno)>0) && (tc_strlen(inputPart)>0) && (tc_strlen(rev)>0) && (tc_strlen(iSapServer)>0))
	{
		printf(" Input_Argument Not Null..!!\n");fflush(stdout);
		BapiRevcr(changeno, inputPart, rev);
	}
	else
	{
	   printf(" Input_Argument is Null..!!\n");fflush(stdout);
	}

	CLEANUP:
	ITK_CALL(POM_logout(false));
	printf("\nCLEANUP..."); fflush(stdout);
}
