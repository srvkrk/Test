./compile Revision_Create.c
./linkitk -o Revision_Create Revision_Create.o
chmod 777 *
