./compile AplDmlSapMatCreateUA.c
./linkitk -o AplDmlSapMatCreateUA AplDmlSapMatCreateUA.o
chmod 777 *
