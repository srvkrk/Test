/*
 *  FILE: msglcm.h
 */

#ifndef msglcm_H
#define msglcm_H

#include <Mtimsgh.h>
#ifndef _LCINTERP_
#include <metadt.h>
#else
extern "c" {
#endif

/*
 *  Message Function Definitions (Prototypes).
 *  Published Messages
 */

MTIstatus _AbortProcessHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string comments, integer * mfail);

MTIstatus _AbortProcessHistoryDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _AcknowledgeUsrWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr rcpSig,
   ObjectPtr workItem, ObjectPtr authObj, string externalStamp,
   string comments, integer * mfail);

MTIstatus _AcknowledgeWork2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr rcpSig,
   ObjectPtr workItem, string externalStamp, string comments,
   integer * mfail);

MTIstatus _AcknowledgeWorkDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _AcknowledgeWorkPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr rcpSig,
   ObjectPtr workItem, integer * mfail);

MTIstatus _AdvAbortWorkItemPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr prhObj, integer * mfail);

MTIstatus _AdvAbortWorkItemPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr prhObj, integer * mfail);

MTIstatus _AdvCloseAssignmentAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _AdvCloseProcessInstAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, ObjectPtr env, string exitState,
   string exitMode, string advComment, integer * mfail);

MTIstatus _AdvComputeExitStateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sigObj, SetOfObjects processSigs, string * exitState,
   string * exitMode, string * sequence, integer * mfail);

MTIstatus _AdvComputeLvlExitStateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, ObjectPtr procHist, ObjectPtr childProcHist,
   string * exitState, string * exitMode, string * sequence,
   integer * mfail);

MTIstatus _AdvDoExpireActionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _AdvDoProcessAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, ObjectPtr procHist, ObjectPtr env,
   integer * mfail);

MTIstatus _AdvDoProcessExitAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string exitState, string exitMode, string sequence,
   ObjectPtr itemObj, ObjectPtr procHist, ObjectPtr env,
   SetOfObjects * processSigs, integer * mfail);

MTIstatus _AdvGetNextStepAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stepObj,
   string exitState, string * nextStep, boolean * advance,
   integer * mfail);

MTIstatus _AdvInflateDynParticipAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr effProcessObj, SetOfObjects processActors, integer * mfail);

MTIstatus _AdvRouteWorkItemPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, ObjectPtr flowObj, integer * mfail);

MTIstatus _AdvRouteWorkItemPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, ObjectPtr flowObj, integer * mfail);

MTIstatus _AdvStartAssignmentAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _AdvSubmitWorkItemPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, ObjectPtr flowObj, integer * mfail);

MTIstatus _AdvSubmitWorkItemPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, ObjectPtr flowObj, integer * mfail);

MTIstatus _AdvTransferObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr procHist, string vaultName, string vaultDirName,
   boolean maintainPath, boolean transferAttachedItems, boolean transferAppDepndItems,
   string * advComment, integer * mfail);

MTIstatus _AdvValidateDoProcessAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string * advComment, integer * mfail);

MTIstatus _ApproveExpediteUsrWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workItem, ObjectPtr authObj, string externalStamp,
   string comments, integer * mfail);

MTIstatus _ApproveExpediteWork2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workItem, string externalStamp, string comments,
   integer * mfail);

MTIstatus _ApproveExpediteWorkDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _ApproveExpediteWorkPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workItem, integer * mfail);

MTIstatus _ApproveUsrWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workItem, ObjectPtr authObj, string externalStamp,
   string comments, integer * mfail);

MTIstatus _ApproveWork2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workItem, string externalStamp, string comments,
   integer * mfail);

MTIstatus _ApproveWorkDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _ApproveWorkPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workItem, integer * mfail);

MTIstatus _AssignReviewListAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   SetOfStrings revList, integer * mfail);

MTIstatus _AssignReviewListDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _AuthenticateSignoffAtClass
   (MTIstring _class, boolean getParent, ObjectPtr sigObj,
   ObjectPtr workItem, ObjectPtr authObj, boolean * authenticated,
   integer * mfail);

MTIstatus _AuthenticateSignoffPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr sigObj,
   ObjectPtr workItem, ObjectPtr * authObj, boolean * authenticated,
   integer * mfail);

MTIstatus _BldLCMActDetailInfoAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr procHist, ObjectPtr dialogObj, SetOfStrings * objectInfo,
   integer * mfail);

MTIstatus _BldLCMActivityInfoAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr lcStep, ObjectPtr dialogObj, SetOfStrings * objectInfo,
   integer * mfail);

MTIstatus _BldLCMActorInfoAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * objectInfo, integer * mfail);

MTIstatus _BldLCMMetricsInfoAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * objectInfo, integer * mfail);

MTIstatus _BuildTaskWorkListSqlAtClass
   (MTIstring _class, boolean getParent, ObjectPtr taskObject,
   ObjectPtr workListFilterObj, SqlPtr * sql, integer * mfail);

MTIstatus _CalComputeDueDateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr calendarObj,
   string startDate, integer days, string * dueDate,
   integer * mfail);

MTIstatus _CheckForReplacementUser
   (MTIstring _class, boolean getParent, string className,
   string curParticp, ObjectPtr itemObj, ObjectPtr curPrtcpObj,
   string * replaceParticp, ObjectPtr * replacePrcptObj, integer * mfail);

MTIstatus _ClaimUsrWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _ClaimUsrWorkDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _CommentWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr workItem, boolean append, string comments,
   integer * mfail);

MTIstatus _CommentWorkDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _CommentWorkHistoryDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _CompleteUsrWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr asgSig,
   ObjectPtr workItem, ObjectPtr authObj, string externalStamp,
   string comments, integer * mfail);

MTIstatus _CompleteWork2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr asgSig,
   ObjectPtr workItem, string externalStamp, string comments,
   integer * mfail);

MTIstatus _CompleteWorkDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _CompleteWorkPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr asgSig,
   ObjectPtr workItem, integer * mfail);

MTIstatus _DEditAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _DGetLVSReviewListAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DViewAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _DoAbortWorkItemPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAbortWorkItemPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAssignReviewListPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAssignReviewListPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoClaimWorkItemPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sigObj, integer * mfail);

MTIstatus _DoClaimWorkItemPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sigObj, integer * mfail);

MTIstatus _DoReAssignWorkItemPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sigObj, integer * mfail);

MTIstatus _DoReAssignWorkItemPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sigObj, integer * mfail);

MTIstatus _DoResumeProcHistPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoResumeProcHistPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoResumeWorkItemPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoResumeWorkItemPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoRevListFailCleanupAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoRouteFailureCleanupAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoRouteWorkItemPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoRouteWorkItemPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoSignoffWorkItemPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sigObj, integer * mfail);

MTIstatus _DoSignoffWorkItemPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sigObj, integer * mfail);

MTIstatus _DoSubmitFailureCleanupAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoSubmitWorkItemPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoSubmitWorkItemPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoSubmitWorkItemPreIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoUnclaimWorkItemPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sigObj, integer * mfail);

MTIstatus _DoUnclaimWorkItemPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sigObj, integer * mfail);

MTIstatus _DoWorklistPostProcAtClass
   (MTIstring _class, boolean getParent, ObjectPtr taskItem,
   SetOfObjects * processSigs, SetOfObjects * workItems, integer * mfail);

MTIstatus _DrawHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _DrawProcessHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _DrawStepHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stepObj,
   ObjectPtr lcObj, integer * mfail);

MTIstatus _EditEffStepProcessAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stepObj,
   ObjectPtr lcObj, integer * mfail);

MTIstatus _ExpMLevAllPrcInstAtClass
   (MTIstring _class, boolean getParent, ObjectPtr prcInst,
   SetOfObjects * prcInstSet, integer * mfail);

MTIstatus _FilterTaskWorkListAtClass
   (MTIstring _class, boolean getParent, ObjectPtr taskObject,
   ObjectPtr workListFilterObj, SetOfObjects * processSigs, SetOfObjects * workItems,
   integer * mfail);

MTIstatus _FindAllTopLvlPrcInsts
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr workItem, SetOfObjects * prcInsts, integer * mfail);

MTIstatus _FindAllWorkForPrcInsts
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr workItem, SetOfObjects procInstSet, SetOfObjects * workAsgSet,
   integer * mfail);

MTIstatus _FindEffProcessRev
   (MTIstring _class, boolean getParent, string className,
   string processName, string InProduction, string Baselined,
   ObjectPtr * curProcessObj, integer * mfail);

MTIstatus _FindProcsForPrcInsts
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects prcInstSet, SetOfObjects * processSet, integer * mfail);

MTIstatus _GenMultiSelAssignment
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects selectedRels, SetOfObjects selectedItems, string msgOptionTag,
   integer * mfail);

MTIstatus _GenerateProcessSigs
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr effProcessObj, ObjectPtr workItem, ObjectPtr processHistory,
   SetOfObjects addtlActors, SetOfObjects * signatureObjects, integer * mfail);

MTIstatus _GetAllProcessBranches
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr processObj, SetOfObjects * branchObjs, integer * mfail);

MTIstatus _GetCreateRevListAtClass
   (MTIstring _class, boolean getParent, ObjectPtr dialogObj,
   string destClassName, SetOfObjects * objects, integer * mfail);

MTIstatus _GetEffProcesses
   (MTIstring _class, boolean getParent, string className,
   string effFrom, string effTo, SetOfObjects * prcObjSet,
   integer * mfail);

MTIstatus _GetExpireActnsForDialg
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr thisObj, ObjectPtr dialogObj, integer * mfail);

MTIstatus _GetLCMWlbParams
   (MTIstring _class, boolean getParent, string className,
   string tagName, string usrName, SqlPtr * sql,
   SetOfStrings * brNames, integer * mfail);

MTIstatus _GetProcHistForLevel
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr itemObj, ObjectPtr prhObj, SetOfObjects * prhObjSet,
   integer * mfail);

MTIstatus _GetProcHistForProcess
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr processObj, SetOfObjects * prhObjSet, integer * mfail);

MTIstatus _GetProcInstForWorkflow
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr flowObj, string stepName, SetOfObjects * prhObjSet,
   integer * mfail);

MTIstatus _GetStepObj
   (MTIstring _class, boolean getParent, string className,
   string flowName, string flowRev, string flowVersion,
   string flowSeq, string flowType, string stepName,
   ObjectPtr * stepObj, integer * mfail);

MTIstatus _GetStepsForWorkflow
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr flowObj, SetOfObjects * objects, integer * mfail);

MTIstatus _GetSuspendedProcInst
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr itemObj, SetOfObjects * prhObjSet, integer * mfail);

MTIstatus _GetValidLifeCycsForCls
   (MTIstring _class, boolean getParent, string className,
   string objClassName, SetOfObjects * flowObjs, integer * mfail);

MTIstatus _GetValidReviewListAtClass
   (MTIstring _class, boolean getParent, ObjectPtr objItem,
   SetOfStrings * values, integer * mfail);

MTIstatus _InflateStepPopup
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr stepObj, integer * mfail);

MTIstatus _IsActorAssignableAtClass
   (MTIstring _class, boolean getParent, ObjectPtr actorObj,
   ObjectPtr itemObj, ObjectPtr procHistObj, boolean * answer,
   integer * mfail);

MTIstatus _IsProcessInUse
   (MTIstring _class, boolean getParent, string className,
   string processName, boolean * answer, integer * mfail);

MTIstatus _LcmBaselineItemObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _LcmExportItemObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _LcmFalseTestMessageAtClass
   (MTIstring _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _LcmTrueTestMessageAtClass
   (MTIstring _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _LcmVaultTransItemObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _ManageAltWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr workitem, ObjectPtr dialogObj, integer * mfail);

MTIstatus _ManageAltWorkDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _ManageUsrWorkDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _MarkOverdueObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _NotCompleteUsrWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr asgSig,
   ObjectPtr workItem, ObjectPtr authObj, string externalStamp,
   string comments, integer * mfail);

MTIstatus _NotOKUsrWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr avrSig,
   ObjectPtr workItem, ObjectPtr authObj, string externalStamp,
   string comments, integer * mfail);

MTIstatus _NotOKWork2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr avrSig,
   ObjectPtr workItem, string externalStamp, string comments,
   integer * mfail);

MTIstatus _NotOKWorkDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _NotOKWorkPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr avrSig,
   ObjectPtr workItem, integer * mfail);

MTIstatus _OKUsrWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr avrSig,
   ObjectPtr workItem, ObjectPtr authObj, string externalStamp,
   string comments, integer * mfail);

MTIstatus _OKWork2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr avrSig,
   ObjectPtr workItem, string externalStamp, string comments,
   integer * mfail);

MTIstatus _OKWorkDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _OKWorkPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr avrSig,
   ObjectPtr workItem, integer * mfail);

MTIstatus _PerformSignoffAtClass
   (MTIstring _class, boolean getParent, ObjectPtr sig,
   ObjectPtr workItem, ObjectPtr authObj, string intStamp,
   string intStampMode, string advEvent, string notifEvent,
   string externalStamp, string comments, integer * mfail);

MTIstatus _PerformSignoffDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr sig,
   ObjectPtr workItem, string intStamp, string intStampMode,
   string advEvent, string notifEvent, integer * mfail);

MTIstatus _PrepareItemForRouteAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _PrepareItemForSubmitAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _QueryAltWorklist
   (MTIstring _class, boolean getParent, string className,
   string optName, string altUserName, ObjectPtr filterObj,
   SetOfObjects * processSigs, SetOfObjects * workItems, integer * mfail);

MTIstatus _QueryAltWorklistDP
   (MTIstring _class, boolean getParent, string classname,
   string tagname, integer * mfail);

MTIstatus _QueryForLCABrowser
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _QueryForLCMWorkExists
   (MTIstring _class, boolean getParent, string className,
   boolean * workExists, integer * mfail);

MTIstatus _QueryItmWorklistObject
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr itemObj, string optName, string participant,
   SetOfObjects * processSigs, integer * mfail);

MTIstatus _QueryUserWorklist
   (MTIstring _class, boolean getParent, string className,
   string optName, ObjectPtr filterObj, SetOfObjects * processSigs,
   SetOfObjects * workItems, integer * mfail);

MTIstatus _QueryUserWorklistD
   (MTIstring _class, boolean getParent, string classname,
   string tagname, integer * mfail);

MTIstatus _ReAssignAltWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, ObjectPtr authObj, string reassignTo,
   string extStamp, string comments, integer * mfail);

MTIstatus _ReAssignAltWorkDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _ReAssignObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean lcmAdminMode, string intStampMode, string reassignTo,
   string extStamp, string comments, integer * mfail);

MTIstatus _ReAssignObject2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean lcmAdminMode, string intStampMode, string reassignTo,
   string extStamp, string comments, integer * mfail);

MTIstatus _ReAssignUsrWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, ObjectPtr authObj, string reassignTo,
   string extStamp, string comments, integer * mfail);

MTIstatus _ReAssignUsrWorkDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _RefreshProcHistQuiet
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr thisObj, ObjectPtr itemObj, integer * mfail);

MTIstatus _RefreshWorklistObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr refreshFromObj, integer * mfail);

MTIstatus _RejectExpediteUsrWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workItem, ObjectPtr authObj, string externalStamp,
   string comments, integer * mfail);

MTIstatus _RejectExpediteWork2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workItem, string externalStamp, string comments,
   integer * mfail);

MTIstatus _RejectExpediteWorkDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _RejectExpediteWorkPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workItem, integer * mfail);

MTIstatus _RejectUsrWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workItem, ObjectPtr authObj, string externalStamp,
   string comments, integer * mfail);

MTIstatus _RejectWork2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workItem, string externalStamp, string comments,
   integer * mfail);

MTIstatus _RejectWorkDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _RejectWorkPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workItem, integer * mfail);

MTIstatus _ReplaceActorAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr backgroundItem, ObjectPtr selectedRelation, integer * mfail);

MTIstatus _ReplaceAdvExpandActor
   (MTIstring _class, boolean getParent, string className,
   string inactiveParticp, ObjectPtr workItemObj, ObjectPtr inactivePrtcpObj,
   string * replaceParticp, ObjectPtr * replacePrtcpObj, boolean * haveCustomize,
   integer * mfail);

MTIstatus _RequeryForProcHist
   (MTIstring _class, boolean getParent, string className,
   string optionTag, ObjectPtr queryDialog, integer * mfail);

MTIstatus _RequeryWorklistD
   (MTIstring _class, boolean getParent, string className,
   string optionTag, ObjectPtr queryDialog, integer * mfail);

MTIstatus _ResumeProcHistCleanupAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, ObjectPtr dialogObj, integer * mfail);

MTIstatus _ResumeProcessHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string comments, integer * mfail);

MTIstatus _ResumeProcessHistoryPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ReviseIfActiveUserAtClass
   (MTIstring _class, boolean getParent, ObjectPtr replaceUsrObj,
   string replaceUser, SetOfStrings * userList, SetOfObjects * processParticips,
   boolean * newActiveUser, integer * mfail);

MTIstatus _RouteWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr rteObj, string rteWorkDesc, SetOfStrings rteAddList,
   string rteCmts, ObjectPtr rteContext, integer * mfail);

MTIstatus _RouteWorkDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _SendAutoProcSyncMsgAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string messageName, ObjectPtr itemObj, ObjectPtr procHist,
   string * exitState, string * advComments, integer * mfail);

MTIstatus _SetReAssignAttributesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr origSigObj, ObjectPtr rasParticipObj, integer * mfail);

MTIstatus _SetSigAttributesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr actorObj, ObjectPtr curParticipObj, ObjectPtr originParticipObj,
   integer * mfail);

MTIstatus _ShowHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ShowSigHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ShowSignoffHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ShowStepCommentsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stepObj,
   ObjectPtr lcObj, integer * mfail);

MTIstatus _SubmitWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr lcObj, string subCmts, integer * mfail);

MTIstatus _SubmitWorkDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _TGenMultiSelAssignment
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects selectedRels, SetOfObjects selectedItems, string msgOptionTag,
   integer * mfail);

MTIstatus _UnableToCompleteWork2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr asgSig,
   ObjectPtr workItem, string externalStamp, string comments,
   integer * mfail);

MTIstatus _UnableToCompleteWorkDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _UnableToCompleteWorkPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr asgSig,
   ObjectPtr workItem, integer * mfail);

MTIstatus _UnclaimUsrWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _UnclaimUsrWorkDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _UpdateCtxtForWbpExpandAtClass
   (MTIstring _class, boolean getParent, ObjectPtr workItem,
   string relationship, ObjectPtr * expCtxtObj, integer * mfail);

MTIstatus _UpdateEffStepProcessAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stepObj,
   ObjectPtr lcObj, integer * mfail);

MTIstatus _UpdateEffectiveDatesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _UpdateRevTabulationAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValAhdItemForCreAhrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr ahdItem,
   ObjectPtr adhcDataRel, integer * mfail);

MTIstatus _ValAuxOnlineForSubmitAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _ValForAssignReviewListAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   integer * mfail);

MTIstatus _ValForReplaceActorAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr processObj, ObjectPtr actorObj, integer * mfail);

MTIstatus _ValForUnclaimAssignAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _ValWrkItemForCreAhrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr wrkItem,
   ObjectPtr adhcDataRel, integer * mfail);

MTIstatus _ValidateAbortWorkItemAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateAuxForSubmitAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateEditProcessAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateExpireActions
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr dialogObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _ValidateForClaimAssignAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _ValidateForCommentAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForExpireAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForLcySubmitAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForManageSigAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean lcmAdminMode, integer * mfail);

MTIstatus _ValidateForReAssignAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean lcmAdminMode, integer * mfail);

MTIstatus _ValidateForRouteAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForSigActionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string intStamp, string intStampMode, integer * mfail);

MTIstatus _ValidateForSubmitAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForUpdEffDateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForUpdRevTabAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateItemForSignoffAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sigObj, string intStamp, string intStampMode,
   integer * mfail);

MTIstatus _ValidateItemReAssignAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sigObj, boolean lcmAdminMode, string intStamp,
   string intStampMode, integer * mfail);

MTIstatus _ValidateResumeProcHistAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _ValidateResumeWorkItemAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateViewProcessAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _WLGetValidWorkflows
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr itemObj, SetOfObjects * flowObjs, integer * mfail);

MTIstatus _WLGrantAccessToExpItms
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects objectSet, string relationship, SetOfObjects * otherSideObjSet,
   SetOfObjects * relObjSet, integer * mfail);

MTIstatus _WLInflateWorklistAttrsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, string userName, integer * mfail);

MTIstatus _WLRefreshGrantedAccessAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string relationship, integer * mfail);

MTIstatus _WorkReminderObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

#ifdef _LCINTERP_
}
#else

/*
 *  Unpublished Messages
 */

MTIstatus _AcknowledgeWork3AtClass
   (MTIstring _class, boolean getParent, ObjectPtr rcpSig,
   ObjectPtr workItem, string externalStamp, string comments,
   integer * mfail);

MTIstatus _AdvAbortProcHistAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, ObjectPtr env, string usrComment,
   integer * mfail);

MTIstatus _AdvAbortProcHistLvlsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, ObjectPtr env, string usrComment,
   integer * mfail);

MTIstatus _AdvAbortProcHistPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _AdvAbortProcHistPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _AdvAppndProcessHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string advComment, integer * mfail);

MTIstatus _AdvBuildProcessHistory
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr lastProcHist, integer procHistType, ObjectPtr flowObj,
   string nextStep, string submitter, string advComment,
   ObjectPtr itemObj, ObjectPtr env, ObjectPtr * procHistObj,
   integer * mfail);

MTIstatus _AdvCloseAssignmentSet
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects * processSigs, integer * mfail);

MTIstatus _AdvCloseProcessAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string exitState, string exitMode, string advComment,
   ObjectPtr itemObj, ObjectPtr procHist, ObjectPtr env,
   SetOfObjects * processSigs, integer * mfail);

MTIstatus _AdvCloseRelatedHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _AdvCreateSubmitterSig
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr workItem, ObjectPtr processHistory, string sbrUserName,
   string sbrComments, ObjectPtr * sbrSigObj, integer * mfail);

MTIstatus _AdvDoPostProcessExitAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr procHist, integer * mfail);

MTIstatus _AdvDoSigActionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr env, integer * mfail);

MTIstatus _AdvExpandActor
   (MTIstring _class, boolean getParent, string className,
   string participant, ObjectPtr itemObj, boolean postEvent,
   SetOfObjects * processParticips, SetOfStrings * userList, integer * noUsers,
   integer * mfail);

MTIstatus _AdvExpandActor2
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr actorObj, string participant, ObjectPtr itemObj,
   boolean postEvent, boolean procInactiveUsers, SetOfObjects * processParticips,
   SetOfStrings * userList, integer * noUsers, integer * mfail);

MTIstatus _AdvExpandActor3
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr actorObj, string participant, ObjectPtr processHistory,
   ObjectPtr itemObj, boolean postEvent, boolean procInactiveUsers,
   SetOfObjects * processParticips, SetOfStrings * userList, integer * noUsers,
   integer * mfail);

MTIstatus _AdvFindEffProcessRev
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr thisObj, ObjectPtr stepObj, ObjectPtr * effProcessObj,
   string * advComment, integer * mfail);

MTIstatus _AdvFindProcessActors
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr effProcess, SetOfObjects dynActors, SetOfObjects * processActors,
   SetOfObjects * processParticipants, SetOfStrings * processWorkList, string * advComment,
   integer * mfail);

MTIstatus _AdvGetNextStateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stepObj,
   string exitState, string * nextState, integer * mfail);

MTIstatus _AdvGetNextVaultAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stepObj,
   string exitState, string * nextVault, integer * mfail);

MTIstatus _AdvGetNextVaultReqAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stepObj,
   ObjectPtr procHist, string exitState, string * nextVault,
   integer * mfail);

MTIstatus _AdvGetStepObj
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr procHist, ObjectPtr * stepObj, string * advComment,
   integer * mfail);

MTIstatus _AdvPauseProcessHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, ObjectPtr env, integer * mfail);

MTIstatus _AdvPromoteObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr procHist, ObjectPtr env, ObjectPtr stepObj,
   string exitState, string * advComment, integer * mfail);

MTIstatus _AdvResetProcessHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer advFail, string advComment,
   ObjectPtr effProcess, integer * mfail);

MTIstatus _AdvRouteAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dlgObj, ObjectPtr env, integer * mfail);

MTIstatus _AdvStartProcessHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr effProcess, ObjectPtr itemObj, ObjectPtr env,
   integer * mfail);

MTIstatus _AdvStateProcessHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, ObjectPtr env, ObjectPtr stepObj,
   string exitState, integer * mfail);

MTIstatus _AdvStepEntryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr procHist, ObjectPtr env, integer * mfail);

MTIstatus _AdvStepExitAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr procHist, ObjectPtr env, integer * mfail);

MTIstatus _AdvSubmitAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dlgObj, ObjectPtr env, integer * mfail);

MTIstatus _AdvSubmitIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dlgObj, ObjectPtr env, ObjectPtr lastProcHist,
   ObjectPtr lcyObj, string submitter, string nextStep,
   integer prhType, integer * mfail);

MTIstatus _AdvTrailProcessHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string advComment, integer * mfail);

MTIstatus _AdvTransferAllObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr procHist, string vaultName, string * advComment,
   integer * mfail);

MTIstatus _AdvVaultProcessHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, ObjectPtr stepObj, ObjectPtr env,
   string exitState, integer * mfail);

MTIstatus _AllowRoutingListUsageAtClass
   (MTIstring _class, boolean getParent, ObjectPtr rteObj,
   ObjectPtr itemObj, boolean * allowed, integer * mfail);

MTIstatus _AllowWorkflowUsageAtClass
   (MTIstring _class, boolean getParent, ObjectPtr workflowObj,
   ObjectPtr itemObj, boolean * allowed, integer * mfail);

MTIstatus _ApproveExpediteWork3AtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workItem, string externalStamp, string comments,
   integer * mfail);

MTIstatus _ApproveWork3AtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workItem, string externalStamp, string comments,
   integer * mfail);

MTIstatus _BldFindInSetSrchStr
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr actorObj, ObjectPtr participObj, string * findInSetStr,
   integer * mfail);

MTIstatus _BranchDefUseWorkflow
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr flowObj, boolean * answer, integer * mfail);

MTIstatus _CalendarNameExists
   (MTIstring _class, boolean getParent, string className,
   string calendarName, boolean * exists, integer * mfail);

MTIstatus _CkiItemForSignoffAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _CompleteWork3AtClass
   (MTIstring _class, boolean getParent, ObjectPtr asgSig,
   ObjectPtr workItem, string externalStamp, string comments,
   integer * mfail);

MTIstatus _ComputeMetricsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * prcMetricsObj, integer * mfail);

MTIstatus _ConstructDlgForCreRel
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr originObject, string relationship, integer * mfail,
   ObjectPtr * dialogObj);

MTIstatus _CopyProcessBranchesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sourceObj, integer * mfail);

MTIstatus _CopyWorkflowStepsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr flowObj, integer * mfail);

MTIstatus _CreateAdvisorExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr dialogObj,
   string relationClassName, ObjectPtr leftObject, integer * mfail);

MTIstatus _DEditMoveStepInAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr originObject, SetOfObjects * extraObj, string stepName,
   integer * mfail);

MTIstatus _DEditMoveStepOutAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr originObject, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DGetLVSAllActiveUsersAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSAllParticipantsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSCalendarNamesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSLcmActMsgGrpsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSLcmAvrMsgGrpsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSLcyForSavPrefAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSLcyForSubmitAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSLcyProcessNamesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSLcyVaultNamesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSMsgsForAutoProcAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSPlpConditionsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSRListForRouteAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSTaskToolsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSTflProcessNamesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSUsersAndRolesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSWbpConditionsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSWbpSubmittersAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSWorkItemRelsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSWorkflwsForProcAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DViewMoveStepInAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr originObject, SetOfObjects * extraObj, string stepName,
   integer * mfail);

MTIstatus _DeleteRelForSetIntExt
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects originObjects, integer * mfail);

MTIstatus _DetermineAltUser
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr * usrObj, boolean * validAltUser, integer * mfail);

MTIstatus _DoAbortProcHistAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAbortProcHistPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAbortProcHistPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAssignReviewListAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoClaimAssignAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _DoClaimAssignPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _DoClaimAssignPostIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _DoClaimAssignPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _DoClaimWorkItemPostIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sigObj, integer * mfail);

MTIstatus _DoDEditSaveAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoDrawHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr prhObj, integer * mfail);

MTIstatus _DoDrawProcessAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoEditProcessAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoQueryForItemWorklist
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr itemObj, string participant, SqlPtr sql,
   SetOfObjects * processSigs, integer * mfail);

MTIstatus _DoQueryForUserWorklist
   (MTIstring _class, boolean getParent, string className,
   string participant, SqlPtr sql, ObjectPtr filterObj,
   SetOfObjects * processSigs, SetOfObjects * workItems, integer * mfail);

MTIstatus _DoReAssignAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoReAssign2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoReplaceUsrForActorAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr processObj, ObjectPtr usrObj, string newUsr,
   ObjectPtr * newUsrObj, integer * mfail);

MTIstatus _DoResumeProcHistAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoRouteAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoShowHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer expansion, integer * mfail);

MTIstatus _DoSigActionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, ObjectPtr dialogObj, string advEvent,
   string notifEvent, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoSubmitAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoSubmitItemSyncAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, ObjectPtr lcObj, integer * mfail);

MTIstatus _DoTaskWorkListQueryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr taskObject,
   ObjectPtr workListFilterObj, SqlPtr sql, SetOfObjects * processSigs,
   SetOfObjects * workItems, integer * mfail);

MTIstatus _DoUnclaimAsgmentAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _DoUnclaimAssignPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _DoUnclaimAssignPostIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _DoUnclaimAssignPreAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _DoUnclaimWrkItmPostIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sigObj, integer * mfail);

MTIstatus _DoUpdateRevTabsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoViewProcessAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoesProcessUseCalendar
   (MTIstring _class, boolean getParent, string className,
   string calendarName, boolean * answer, integer * mfail);

MTIstatus _DoesUserHaveWorkInProc
   (MTIstring _class, boolean getParent, string className,
   string userToCheck, ObjectPtr processObj, boolean * hasWork,
   integer * mfail);

MTIstatus _DoesWorkflowHaveInst
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr flowObj, string stepName, boolean * answer,
   integer * mfail);

MTIstatus _DrawProcInstForProcess
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr wilObj, ObjectPtr prhObj, integer * mfail);

MTIstatus _ExpMLevOpenPrcInstAtClass
   (MTIstring _class, boolean getParent, ObjectPtr prcInst,
   SetOfObjects * prcInstSet, integer * mfail);

MTIstatus _ExpMLevPrcInstAtClass
   (MTIstring _class, boolean getParent, ObjectPtr prcInst,
   ObjectPtr qryDef, ObjectPtr genContextObj, SetOfObjects * prcInstSet,
   integer * mfail);

MTIstatus _ExpMultiLevForItemObj
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr object, string relationship, ObjectPtr dialogObject,
   SetOfObjects otherSideObjSet, SetOfObjects relObjSet, ObjectPtr genContextObj,
   SetOfObjects * recurList, SetOfObjects * itemObjSet, integer * currentExpandLevel,
   integer * mfail);

MTIstatus _ExtQryLCMObjectByOwner
   (MTIstring _class, boolean getParent, string className,
   SqlPtr sql, boolean expand, string owner,
   ObjectPtr * object, integer * mfail);

MTIstatus _FindAllProcActorsExt
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr processObj, SetOfObjects * processActors, SetOfObjects * processParticipants,
   SetOfStrings * processWorkList, integer * mfail);

MTIstatus _FindAllProcessActors
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr processObj, SetOfObjects * processActors, SetOfObjects * processParticipants,
   SetOfStrings * processWorkList, integer * mfail);

MTIstatus _FindAllProcessRevs
   (MTIstring _class, boolean getParent, string className,
   string processName, SetOfObjects * processObjects, integer * mfail);

MTIstatus _FindAllProcessSigs
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr wrkItemObj, ObjectPtr procHistObj, SetOfObjects * sigObjects,
   integer * mfail);

MTIstatus _FindAllReviewersInSeq
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr processObj, string sequence, SetOfObjects * reviewerObjects,
   integer * mfail);

MTIstatus _FindCalendarName
   (MTIstring _class, boolean getParent, string className,
   string calendarName, ObjectPtr * calendarObj, integer * mfail);

MTIstatus _FindEffProcessRevD
   (MTIstring _class, boolean getParent, string className,
   string processName, string InProduction, string Baselined,
   ObjectPtr * curProcessObj, integer * mfail);

MTIstatus _FindItemObjForWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean inflate, ObjectPtr * wrkItemObj, integer * mfail);

MTIstatus _FindLatestEffProcess
   (MTIstring _class, boolean getParent, string className,
   string processName, ObjectPtr * curProcessObj, integer * mfail);

MTIstatus _FindLowestLvlPrcInsts
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr wilObj, SetOfObjects * lowestLvlInsts, integer * mfail);

MTIstatus _FindOneProcessRev
   (MTIstring _class, boolean getParent, string className,
   string processName, string processRev, string processVersion,
   string processSeq, ObjectPtr * curProcessObj, integer * mfail);

MTIstatus _FindOneProcessRevD
   (MTIstring _class, boolean getParent, string className,
   string processName, string processRev, string processVersion,
   string processSeq, ObjectPtr * curProcessObj, integer * mfail);

MTIstatus _FindOpenPrcInst
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr thisObj, SetOfObjects * prcInstSet, integer * mfail);

MTIstatus _FindOpenProcessSigs
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr wrkItemObj, ObjectPtr procHistObj, SetOfObjects * sigObjects,
   integer * mfail);

MTIstatus _FindOpenRLPrcInst
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr wilObj, ObjectPtr * prcInst, integer * mfail);

MTIstatus _FindOpenSigMsgGroups
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr wrkItemObj, ObjectPtr procHistObj, SetOfStrings * curUserList,
   SetOfStrings * msgGroupList, integer * mfail);

MTIstatus _FindParentPrcInstAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * prcInst, integer * mfail);

MTIstatus _FindProcHistForWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * procHistObj, integer * mfail);

MTIstatus _FindProcessObjForActorAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean inflate, ObjectPtr * processObj, integer * mfail);

MTIstatus _FindRelatedRLstPrcInstAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, SetOfObjects * prcInstSet, integer * mfail);

MTIstatus _FindTopLvlPrcInst
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr wilObj, ObjectPtr * prcInst, integer * mfail);

MTIstatus _FindWorkItemForWorkExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr sigObj,
   ObjectPtr * workItem, integer * mfail);

MTIstatus _GenAdHocData
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr workItem, ObjectPtr lcObj, ObjectPtr * adhcDataObj,
   integer * mfail);

MTIstatus _GetAdHcDataOfWorkItemAtClass
   (MTIstring _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr * adhcDataObj, integer * mfail);

MTIstatus _GetAllStepsForProcess
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr flowObj, SetOfObjects * stepObjs, integer * mfail);

MTIstatus _GetAllWorkflows
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects * flowObjs, integer * mfail);

MTIstatus _GetAltUserNotOof
   (MTIstring _class, boolean getParent, string className,
   string currentUser, string * altUser, integer * mfail);

MTIstatus _GetBranchesForWorkflow
   (MTIstring _class, boolean getParent, string className,
   string workflowName, SetOfObjects * branchObjs, integer * mfail);

MTIstatus _GetCurrentRevListSetAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   SetOfObjects * objects, integer * mfail);

MTIstatus _GetDiagramAttributes
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects objSet, integer * mfail);

MTIstatus _GetFilterForWrkLstType
   (MTIstring _class, boolean getParent, string worklistClassName,
   string worklistType, ObjectPtr * worklistFilterObj, integer * mfail);

MTIstatus _GetFlowObjFromNameInt
   (MTIstring _class, boolean getParent, string className,
   string flowName, ObjectPtr * flowObject, integer * mfail);

MTIstatus _GetInfoActStepProcessAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stepObj,
   ObjectPtr lcObj, integer * mfail);

MTIstatus _GetInfoEffStepProcessAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stepObj,
   ObjectPtr lcObj, integer * mfail);

MTIstatus _GetItemSignoffHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr procHistObj, SetOfObjects * sigObjectSet, integer * mfail);

MTIstatus _GetLCObjectFromLCName
   (MTIstring _class, boolean getParent, string className,
   string lifeCycleName, ObjectPtr * lcObject, integer * mfail);

MTIstatus _GetLegalActorMsgGrpsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects msgGrpObjs, SetOfStrings * values, integer * mfail);

MTIstatus _GetLegalWorkflowsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr originObject, SetOfStrings extraStr, SetOfObjects extraObj,
   SetOfStrings * values, integer * mfail);

MTIstatus _GetParticipSideOfActor
   (MTIstring _class, boolean getParent, string className,
   boolean * side, integer * mfail);

MTIstatus _GetParticipsForProcessAtClass
   (MTIstring _class, boolean getParent, ObjectPtr processObj,
   ObjectPtr actorObj, ObjectPtr participantObj, ObjectPtr itemObj,
   ObjectPtr procHistObj, SetOfObjects * userObjs, integer * mfail);

MTIstatus _GetPrcUsrsFromProcHistAtClass
   (MTIstring _class, boolean getParent, ObjectPtr procHistObj,
   ObjectPtr itemObj, string participant, SetOfObjects * userObjSet,
   integer * mfail);

MTIstatus _GetPrhOfSameLvlAndStepAtClass
   (MTIstring _class, boolean getParent, ObjectPtr prhObj,
   ObjectPtr itemObj, SetOfObjects * prhObjSet, integer * mfail);

MTIstatus _GetProcFromProcInstAtClass
   (MTIstring _class, boolean getParent, ObjectPtr prhObj,
   ObjectPtr * procObj, integer * mfail);

MTIstatus _GetProcFromProcInstDAtClass
   (MTIstring _class, boolean getParent, ObjectPtr prhObj,
   ObjectPtr * procObj, integer * mfail);

MTIstatus _GetProcHistForLevelExt
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr itemObj, ObjectPtr prhObj, SetOfObjects * prhObjSet,
   integer * mfail);

MTIstatus _GetProcHistToDrawAtClass
   (MTIstring _class, boolean getParent, ObjectPtr processObj,
   ObjectPtr drawDialogObj, SetOfObjects * procHistObjSet, integer * mfail);

MTIstatus _GetProcessActorsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr processObj,
   ObjectPtr itemObj, SetOfObjects * procActorObjs, SetOfObjects * participantObjs,
   integer * mfail);

MTIstatus _GetProcessForStepAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stepObj,
   ObjectPtr itemObj, ObjectPtr procHistObj, ObjectPtr * processObj,
   integer * mfail);

MTIstatus _GetProcessForStepIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stepObj,
   ObjectPtr itemObj, ObjectPtr procHistObj, ObjectPtr * processObj,
   integer * mfail);

MTIstatus _GetProcessSecurityAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string * processSecurity, integer * mfail);

MTIstatus _GetRoleGrpUsersAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   string roleName, SetOfStrings * roleMembers, integer * numMembers,
   integer * mfail);

MTIstatus _GetRplUsrForInactvUsrAtClass
   (MTIstring _class, boolean getParent, ObjectPtr inactivePrtcpObj,
   string * replaceParticp, ObjectPtr * replacePrtcpObj, integer * mfail);

MTIstatus _GetStepClassAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string * stepClass, integer * mfail);

MTIstatus _GetStepsForWorkflowInt
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr flowObj, SetOfObjects * objects, integer * mfail);

MTIstatus _GetTabulationsForDialgAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _GetTaskClassFromOption
   (MTIstring _class, boolean getParent, string worklistClassName,
   string optName, string * taskWorkListClass, integer * mfail);

MTIstatus _GetTaskWorkListClass
   (MTIstring _class, boolean getParent, string workListClassName,
   string worklistType, string * taskWorkListClass, integer * mfail);

MTIstatus _GetTaskWorklistAtClass
   (MTIstring _class, boolean getParent, ObjectPtr taskItem,
   SetOfObjects * processSigs, SetOfObjects * workItems, integer * mfail);

MTIstatus _GetTaskWorklistClassesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr taskItem,
   integer * mfail);

MTIstatus _GetTaskWorklistFilterAtClass
   (MTIstring _class, boolean getParent, ObjectPtr taskItem,
   SetOfObjects * processSigs, SetOfObjects * workItems, integer * mfail);

MTIstatus _GetTaskWorklistScopeAtClass
   (MTIstring _class, boolean getParent, ObjectPtr taskItem,
   SetOfStrings * databases, integer * mfail);

MTIstatus _GetTskObjForWrkLstType
   (MTIstring _class, boolean getParent, string worklistClassName,
   string worklistType, ObjectPtr * worklistTaskObj, integer * mfail);

MTIstatus _GetValidOofPrefs
   (MTIstring _class, boolean getParent, string className,
   string currentUser, string * altUser, string * altBegDate,
   string * altEndDate, integer * mfail);

MTIstatus _GetValidRevListSetAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   SetOfObjects * objects, integer * mfail);

MTIstatus _GetValidWorkflows
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr obj, SetOfObjects * flowObjs, integer * mfail);

MTIstatus _GetWorkItemForProcHistAtClass
   (MTIstring _class, boolean getParent, ObjectPtr procHistObj,
   ObjectPtr * workItemObj, integer * mfail);

MTIstatus _GetWorkListFilterClass
   (MTIstring _class, boolean getParent, string workListClassName,
   string * workListFilterClass, integer * mfail);

MTIstatus _GetWorkListScopeAtClass
   (MTIstring _class, boolean getParent, ObjectPtr taskObject,
   ObjectPtr workListFilterObj, SqlPtr sql, SetOfStrings * databases,
   integer * mfail);

MTIstatus _GetWorkflowForProcHistAtClass
   (MTIstring _class, boolean getParent, ObjectPtr procHistObj,
   ObjectPtr * workflowObj, integer * mfail);

MTIstatus _GetWorkflowForProcInstAtClass
   (MTIstring _class, boolean getParent, ObjectPtr prhObj,
   ObjectPtr * flowObj, integer * mfail);

MTIstatus _GetWorkflowForStepAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stepObj,
   ObjectPtr * lifeCycObj, integer * mfail);

MTIstatus _GetWorkflowsForProcAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * validValues, integer * mfail);

MTIstatus _GetWorkflowsToViewAtClass
   (MTIstring _class, boolean getParent, ObjectPtr processObj,
   ObjectPtr viewDialogObj, SetOfObjects * workflowObjSet, integer * mfail);

MTIstatus _InflatDispResourceAtClass
   (MTIstring _class, boolean getParent, ObjectPtr dialogObj,
   ObjectPtr adhcDataObj, integer * mfail);

MTIstatus _InitEffectiveDatesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _InitRevTabsAtSequenceAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _IntMultiSelAssignment
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects selectedItems, SetOfObjects selectedRels, string msgOptionTag,
   integer * mfail);

MTIstatus _IsHigherPrecedentAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr originParticipObj, boolean * higherPrecedent, integer * mfail);

MTIstatus _IsInteractiveProcess
   (MTIstring _class, boolean getParent, string classname,
   boolean * interactive, integer * mfail);

MTIstatus _IsItemCheckedOutAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean * isCkoPred, boolean * isCkoSucc, integer * mfail);

MTIstatus _IsTopLvlPrcHstOpenAtClass
   (MTIstring _class, boolean getParent, ObjectPtr prhObj,
   boolean * isOpen, integer * mfail);

MTIstatus _IsUserAssignedThisWork
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr wrkItemObj, ObjectPtr procHistObj, string workDesc,
   string userToCheck, boolean * isAssignedWork, integer * mfail);

MTIstatus _ManageAltAssignmentAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _ManageUserWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr workitem, string reminderDate, integer * mfail);

MTIstatus _NewButtonAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string originClassName, string option, ObjectPtr originObject,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * keepInteracting,
   integer * mfail);

MTIstatus _NotOKWork3AtClass
   (MTIstring _class, boolean getParent, ObjectPtr avrSig,
   ObjectPtr workItem, string externalStamp, string comments,
   integer * mfail);

MTIstatus _OKWork3AtClass
   (MTIstring _class, boolean getParent, ObjectPtr avrSig,
   ObjectPtr workItem, string externalStamp, string comments,
   integer * mfail);

MTIstatus _OrderSigsByCreDate
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects * sigObjectSet, integer * mfail);

MTIstatus _PerformComments
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr wrkItemObj, ObjectPtr procHistObj, string dialogConstant,
   ObjectPtr sigObj, integer * mfail);

MTIstatus _PerformViewSignoff
   (MTIstring _class, boolean getParent, string className,
   string dialogConstant, SetOfObjects * sigObjs, ObjectPtr sigObj,
   integer * mfail);

MTIstatus _PerformWorkSignoffAtClass
   (MTIstring _class, boolean getParent, ObjectPtr sig,
   ObjectPtr workItem, string intStamp, string intStampMode,
   string advEvent, string notifEvent, string externalStamp,
   string comments, integer * mfail);

MTIstatus _PerformWorkSignoff2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr sig,
   ObjectPtr workItem, string intStamp, string intStampMode,
   string advEvent, string notifEvent, string externalStamp,
   string comments, boolean appendComments, integer * mfail);

MTIstatus _PerformWorkSignoffDPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr sig,
   ObjectPtr workItem, string intStamp, string intStampMode,
   string advEvent, string notifEvent, integer * mfail);

MTIstatus _PollDbForWorkAtClass
   (MTIstring _class, boolean getParent, ObjectPtr taskObject,
   ObjectPtr workListFilterObj, string dbName, SqlPtr sql,
   integer * count, integer * mfail);

MTIstatus _PopulateAdHocDataAtClass
   (MTIstring _class, boolean getParent, ObjectPtr lifeCycleObj,
   ObjectPtr workItem, ObjectPtr * adhcDataObj, integer * mfail);

MTIstatus _ProcessNameExists
   (MTIstring _class, boolean getParent, string className,
   string processName, boolean * exists, integer * mfail);

MTIstatus _ProcessOutOfOfficeUser
   (MTIstring _class, boolean getParent, string className,
   string currentUser, string * altUser, string * altBegDate,
   string * altEndDate, integer * mfail);

MTIstatus _PropagateMsgAccessTblAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr thisPre, integer mode, integer * mfail);

MTIstatus _QueryForAltWorklist
   (MTIstring _class, boolean getParent, string classname,
   string tagname, integer * mfail);

MTIstatus _QueryForUserWorklist
   (MTIstring _class, boolean getParent, string className,
   string usrName, string optName, boolean browserExists,
   ObjectPtr filterObj, integer * mfail);

MTIstatus _QuerySpecificSigItems
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr thisObj, string usrName, SetOfObjects * sigObjs,
   integer * mfail);

MTIstatus _QueryTaskWorkListAtClass
   (MTIstring _class, boolean getParent, ObjectPtr taskObject,
   ObjectPtr worklistFilterObj, SetOfObjects * processSigs, SetOfObjects * workItems,
   integer * mfail);

MTIstatus _QueryWorkList
   (MTIstring _class, boolean getParent, string worklistClassName,
   ObjectPtr worklistFilterObj, SetOfObjects * processSigs, SetOfObjects * workItems,
   integer * mfail);

MTIstatus _ReAssignAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean lcmAdminMode, integer * mfail);

MTIstatus _ReAssignAltAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ReAssignAltWork2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string reassignTo, string extStamp, string comments,
   integer * mfail);

MTIstatus _ReAssignDynPrtcpInItemAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   ObjectPtr sigObj, SetOfStrings userList, integer * mfail);

MTIstatus _ReAssignUsrWork2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string reassignTo, string extStamp, string comments,
   integer * mfail);

MTIstatus _ReAssignUsrWork3AtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _RefreshWorkForActionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _RejectExpediteWork3AtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workItem, string externalStamp, string comments,
   integer * mfail);

MTIstatus _RejectWork3AtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workItem, string externalStamp, string comments,
   integer * mfail);

MTIstatus _RemoveButtonAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string originClassName, string option, ObjectPtr originObject,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * keepInteracting,
   integer * mfail);

MTIstatus _ReplaceUsrForActorAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr processObj, ObjectPtr usrObj, integer * mfail);

MTIstatus _SaveEditAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects contentSet, integer * mfail);

MTIstatus _ScanCommentsForBrowser
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects * sigObjects, integer * mfail);

MTIstatus _SetAhdTblDfltsForDlgAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string originClassName, ObjectPtr originObject, integer * mfail);

MTIstatus _SetDiagramAttributes
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects objSet, integer * mfail);

MTIstatus _SetRevTabsAtSequenceAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr processObj, integer * mfail);

MTIstatus _SetTaskWorklistScopeAtClass
   (MTIstring _class, boolean getParent, ObjectPtr taskItem,
   SetOfStrings databases, integer * mfail);

MTIstatus _SetUpDlgForDrawProcessAtClass
   (MTIstring _class, boolean getParent, ObjectPtr processObj,
   ObjectPtr workItem, ObjectPtr procHistObj, ObjectPtr * drawDialogObj,
   integer * mfail);

MTIstatus _ShowAllProcsForStepAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stepObj,
   ObjectPtr lcObj, integer * mfail);

MTIstatus _SubmitItemSyncAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr lcObj, string subCmts, integer * mfail);

MTIstatus _SubmitItemSyncIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr lcObj, string subCmts, integer * mfail);

MTIstatus _ToFailButtonAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string originClassName, string option, ObjectPtr originObject,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * keepInteracting,
   integer * mfail);

MTIstatus _ToSuccButtonAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string originClassName, string option, ObjectPtr originObject,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * keepInteracting,
   integer * mfail);

MTIstatus _UnableToCompleteWork3AtClass
   (MTIstring _class, boolean getParent, ObjectPtr asgSig,
   ObjectPtr workItem, string externalStamp, string comments,
   integer * mfail);

MTIstatus _UpdAdHcDataForStepIntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string stepName, string processName, string duration,
   string resource, string schStartDate, string schEndDate,
   string stepStatus, string actStartDate, string actEndDate,
   integer * mfail);

MTIstatus _UpdPrcHistFromAdHcDataAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr adHcDataObj, integer * mfail);

MTIstatus _UpdPrhWithAHDataCommntAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _UpdateAdHcDataForStepAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string stepName, string processName, string duration,
   string resource, string schStartDate, string schEndDate,
   integer * mfail);

MTIstatus _UpdateAdHcDataStepExitAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr procHist, integer * mfail);

MTIstatus _UpdateAttrOnReAssignAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   string updateAttrb, ObjectPtr sigObj, integer * mfail);

MTIstatus _UpdateObjectEffDatesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string effectiveOnFrom, string effectiveOnTo, integer * mfail);

MTIstatus _UpdateParticipAttrOKAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   string updateAttrb, ObjectPtr sigObj, boolean * isOkToUpdate,
   integer * mfail);

MTIstatus _Upgrade2LCMLCStepAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer execMode, integer traceMode, integer * mfail);

MTIstatus _UseButtonAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string originClassName, string option, ObjectPtr originObject,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * keepInteracting,
   integer * mfail);

MTIstatus _ValAcknowledgeWorkExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr rcpSig,
   ObjectPtr workitem, integer * mfail);

MTIstatus _ValApproveWorkExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workitem, integer * mfail);

MTIstatus _ValClaimAssignExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr actvSig,
   ObjectPtr workitem, integer * mfail);

MTIstatus _ValCompleteWorkExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr asgSig,
   ObjectPtr workitem, integer * mfail);

MTIstatus _ValDirContentForSubmitAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _ValDomainForDrawHistAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean * isLocal, integer * mfail);

MTIstatus _ValDomainForRouteAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean * isLocal, integer * mfail);

MTIstatus _ValDomainForShowHistAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean * isLocal, integer * mfail);

MTIstatus _ValDomainForSignHistAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean * isLocal, integer * mfail);

MTIstatus _ValDomainForSubmitAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean * isLocal, integer * mfail);

MTIstatus _ValExpediteApproveWExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workitem, integer * mfail);

MTIstatus _ValExpediteRejectWExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workitem, integer * mfail);

MTIstatus _ValForAsgnRevwListExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   integer * mfail);

MTIstatus _ValForFrozenSupersededAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValForManageSigExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean lcmAdminMode, integer * mfail);

MTIstatus _ValForOpenExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr sig,
   ObjectPtr workitem, integer * mfail);

MTIstatus _ValForProcessHistExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr workItem,
   integer * mfail);

MTIstatus _ValForQueryWorkList
   (MTIstring _class, boolean getParent, string worklistClassName,
   string worklistType, integer * mfail);

MTIstatus _ValForSignoffHistExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr workItem,
   integer * mfail);

MTIstatus _ValForSubmitUMHExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr workItem,
   integer * mfail);

MTIstatus _ValForWCCSubmitExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr workItem,
   integer * mfail);

MTIstatus _ValNotCompleteWorkExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr asgSig,
   ObjectPtr workitem, integer * mfail);

MTIstatus _ValNotOkWorkExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr avrSig,
   ObjectPtr workitem, integer * mfail);

MTIstatus _ValOkWorkExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr avrSig,
   ObjectPtr workitem, integer * mfail);

MTIstatus _ValPtcpForQryWorkListAtClass
   (MTIstring _class, boolean getParent, ObjectPtr taskObj,
   ObjectPtr worklistFilterObj, integer * mfail);

MTIstatus _ValReAssignAltWorkExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr sig,
   ObjectPtr workitem, integer * mfail);

MTIstatus _ValReAssignWorkExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr sig,
   ObjectPtr workitem, integer * mfail);

MTIstatus _ValRejectWorkExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr revSig,
   ObjectPtr workitem, integer * mfail);

MTIstatus _ValSubmitUMHDialogExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr lifeCycleObj, string destinationVault, integer * mfail);

MTIstatus _ValUnclaimAssignExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr actvSig,
   ObjectPtr workitem, integer * mfail);

MTIstatus _ValidateAbortProcHistAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, integer * mfail);

MTIstatus _ValidateBranchDefTableAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _ValidateCalEffectivity
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr dialogObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _ValidateCkoForAdvanceAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateDrawProcessExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr processObj,
   integer * mfail);

MTIstatus _ValidateEditAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects contentSet, integer * mfail);

MTIstatus _ValidateExpireDaysAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForCommentExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr sig,
   integer * mfail);

MTIstatus _ValidateForDrawHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForRouteExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForShowHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForSignHistoryAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateGrpAssignmentAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateParticpForWork
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr dialogObj, string attribute, ObjectPtr participObj,
   ObjectPtr procHist, ObjectPtr itemObj, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValidatePrcCal
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr thisObj, integer * mfail);

MTIstatus _ValidatePrcEffDates
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr processObj, string effectiveOnFrom, string effectiveOnTo,
   integer * mfail);

MTIstatus _ValidateProcAndPrompt
   (MTIstring _class, boolean getParent, string className,
   string processName, ObjectPtr * procObj, integer * mfail);

MTIstatus _ValidateProcessName
   (MTIstring _class, boolean getParent, string className,
   string processName, boolean forExistance, integer * mfail);

MTIstatus _ValidateReAssignActionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, boolean lcmAdminMode, string intStamp,
   string intStampMode, integer * mfail);

MTIstatus _ValidateSignoffActionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, string intStamp, string intStampMode,
   integer * mfail);

MTIstatus _ValidateTabulations
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _ValidateVaultName
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr thisObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _ValidateViewProcessExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr processObj,
   integer * mfail);

MTIstatus _ValidateWorkDescAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean updateFlag, integer * mfail);

MTIstatus _ValidateWorkweekAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ViewActStepProcessAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stepObj,
   ObjectPtr lcObj, integer * mfail);

MTIstatus _ViewEffStepProcessAtClass
   (MTIstring _class, boolean getParent, ObjectPtr stepObj,
   ObjectPtr lcObj, integer * mfail);

MTIstatus _WbpGetValidRelations1AtClass
   (MTIstring _class, boolean getParent, ObjectPtr dialogObj,
   SetOfStrings * relationships, SetOfStrings * values, integer * mfail);
/*
 *  Protected Messages
 */
#endif /* _LCINTERP_ */

/*
 *  Message Macro Definitions.
 */

#define AbortProcessHistory(thisObj, comments, mfail) \
        _AbortProcessHistoryAtClass(NULL, FALSE, thisObj, comments, mfail)
#define AbortProcessHistoryAtClass(class, thisObj, comments, mfail) \
        _AbortProcessHistoryAtClass(class, FALSE, thisObj, comments, mfail)
#define AbortProcessHistoryAtParent(class, thisObj, comments, mfail) \
        _AbortProcessHistoryAtClass(class, TRUE, thisObj, comments, mfail)

#define AbortProcessHistoryDP(thisObj, mfail) \
        _AbortProcessHistoryDPAtClass(NULL, FALSE, thisObj, mfail)
#define AbortProcessHistoryDPAtClass(class, thisObj, mfail) \
        _AbortProcessHistoryDPAtClass(class, FALSE, thisObj, mfail)
#define AbortProcessHistoryDPAtParent(class, thisObj, mfail) \
        _AbortProcessHistoryDPAtClass(class, TRUE, thisObj, mfail)

#define AcknowledgeUsrWork(rcpSig, workItem, authObj, externalStamp, comments, mfail) \
        _AcknowledgeUsrWorkAtClass(NULL, FALSE, rcpSig, workItem, authObj, externalStamp, comments, mfail)
#define AcknowledgeUsrWorkAtClass(class, rcpSig, workItem, authObj, externalStamp, comments, mfail) \
        _AcknowledgeUsrWorkAtClass(class, FALSE, rcpSig, workItem, authObj, externalStamp, comments, mfail)
#define AcknowledgeUsrWorkAtParent(class, rcpSig, workItem, authObj, externalStamp, comments, mfail) \
        _AcknowledgeUsrWorkAtClass(class, TRUE, rcpSig, workItem, authObj, externalStamp, comments, mfail)

#define AcknowledgeWork2(rcpSig, workItem, externalStamp, comments, mfail) \
        _AcknowledgeWork2AtClass(NULL, FALSE, rcpSig, workItem, externalStamp, comments, mfail)
#define AcknowledgeWork2AtClass(class, rcpSig, workItem, externalStamp, comments, mfail) \
        _AcknowledgeWork2AtClass(class, FALSE, rcpSig, workItem, externalStamp, comments, mfail)
#define AcknowledgeWork2AtParent(class, rcpSig, workItem, externalStamp, comments, mfail) \
        _AcknowledgeWork2AtClass(class, TRUE, rcpSig, workItem, externalStamp, comments, mfail)

#define AcknowledgeWork3(rcpSig, workItem, externalStamp, comments, mfail) \
        _AcknowledgeWork3AtClass(NULL, FALSE, rcpSig, workItem, externalStamp, comments, mfail)
#define AcknowledgeWork3AtClass(class, rcpSig, workItem, externalStamp, comments, mfail) \
        _AcknowledgeWork3AtClass(class, FALSE, rcpSig, workItem, externalStamp, comments, mfail)
#define AcknowledgeWork3AtParent(class, rcpSig, workItem, externalStamp, comments, mfail) \
        _AcknowledgeWork3AtClass(class, TRUE, rcpSig, workItem, externalStamp, comments, mfail)

#define AcknowledgeWorkDP(thisObj, itemObj, mfail) \
        _AcknowledgeWorkDPAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define AcknowledgeWorkDPAtClass(class, thisObj, itemObj, mfail) \
        _AcknowledgeWorkDPAtClass(class, FALSE, thisObj, itemObj, mfail)
#define AcknowledgeWorkDPAtParent(class, thisObj, itemObj, mfail) \
        _AcknowledgeWorkDPAtClass(class, TRUE, thisObj, itemObj, mfail)

#define AcknowledgeWorkP(rcpSig, workItem, mfail) \
        _AcknowledgeWorkPAtClass(NULL, FALSE, rcpSig, workItem, mfail)
#define AcknowledgeWorkPAtClass(class, rcpSig, workItem, mfail) \
        _AcknowledgeWorkPAtClass(class, FALSE, rcpSig, workItem, mfail)
#define AcknowledgeWorkPAtParent(class, rcpSig, workItem, mfail) \
        _AcknowledgeWorkPAtClass(class, TRUE, rcpSig, workItem, mfail)

#define AdvAbortProcHist(thisObj, itemObj, env, usrComment, mfail) \
        _AdvAbortProcHistAtClass(NULL, FALSE, thisObj, itemObj, env, usrComment, mfail)
#define AdvAbortProcHistAtClass(class, thisObj, itemObj, env, usrComment, mfail) \
        _AdvAbortProcHistAtClass(class, FALSE, thisObj, itemObj, env, usrComment, mfail)
#define AdvAbortProcHistAtParent(class, thisObj, itemObj, env, usrComment, mfail) \
        _AdvAbortProcHistAtClass(class, TRUE, thisObj, itemObj, env, usrComment, mfail)

#define AdvAbortProcHistLvls(thisObj, itemObj, env, usrComment, mfail) \
        _AdvAbortProcHistLvlsAtClass(NULL, FALSE, thisObj, itemObj, env, usrComment, mfail)
#define AdvAbortProcHistLvlsAtClass(class, thisObj, itemObj, env, usrComment, mfail) \
        _AdvAbortProcHistLvlsAtClass(class, FALSE, thisObj, itemObj, env, usrComment, mfail)
#define AdvAbortProcHistLvlsAtParent(class, thisObj, itemObj, env, usrComment, mfail) \
        _AdvAbortProcHistLvlsAtClass(class, TRUE, thisObj, itemObj, env, usrComment, mfail)

#define AdvAbortProcHistPost(thisObj, itemObj, mfail) \
        _AdvAbortProcHistPostAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define AdvAbortProcHistPostAtClass(class, thisObj, itemObj, mfail) \
        _AdvAbortProcHistPostAtClass(class, FALSE, thisObj, itemObj, mfail)
#define AdvAbortProcHistPostAtParent(class, thisObj, itemObj, mfail) \
        _AdvAbortProcHistPostAtClass(class, TRUE, thisObj, itemObj, mfail)

#define AdvAbortProcHistPre(thisObj, itemObj, mfail) \
        _AdvAbortProcHistPreAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define AdvAbortProcHistPreAtClass(class, thisObj, itemObj, mfail) \
        _AdvAbortProcHistPreAtClass(class, FALSE, thisObj, itemObj, mfail)
#define AdvAbortProcHistPreAtParent(class, thisObj, itemObj, mfail) \
        _AdvAbortProcHistPreAtClass(class, TRUE, thisObj, itemObj, mfail)

#define AdvAbortWorkItemPost(thisObj, prhObj, mfail) \
        _AdvAbortWorkItemPostAtClass(NULL, FALSE, thisObj, prhObj, mfail)
#define AdvAbortWorkItemPostAtClass(class, thisObj, prhObj, mfail) \
        _AdvAbortWorkItemPostAtClass(class, FALSE, thisObj, prhObj, mfail)
#define AdvAbortWorkItemPostAtParent(class, thisObj, prhObj, mfail) \
        _AdvAbortWorkItemPostAtClass(class, TRUE, thisObj, prhObj, mfail)

#define AdvAbortWorkItemPre(thisObj, prhObj, mfail) \
        _AdvAbortWorkItemPreAtClass(NULL, FALSE, thisObj, prhObj, mfail)
#define AdvAbortWorkItemPreAtClass(class, thisObj, prhObj, mfail) \
        _AdvAbortWorkItemPreAtClass(class, FALSE, thisObj, prhObj, mfail)
#define AdvAbortWorkItemPreAtParent(class, thisObj, prhObj, mfail) \
        _AdvAbortWorkItemPreAtClass(class, TRUE, thisObj, prhObj, mfail)

#define AdvAppndProcessHistory(thisObj, advComment, mfail) \
        _AdvAppndProcessHistoryAtClass(NULL, FALSE, thisObj, advComment, mfail)
#define AdvAppndProcessHistoryAtClass(class, thisObj, advComment, mfail) \
        _AdvAppndProcessHistoryAtClass(class, FALSE, thisObj, advComment, mfail)
#define AdvAppndProcessHistoryAtParent(class, thisObj, advComment, mfail) \
        _AdvAppndProcessHistoryAtClass(class, TRUE, thisObj, advComment, mfail)

#define AdvBuildProcessHistory(className, lastProcHist, procHistType, flowObj, nextStep, submitter, advComment, itemObj, env, procHistObj, mfail) \
        _AdvBuildProcessHistory(className, FALSE, className, lastProcHist, procHistType, flowObj, nextStep, submitter, advComment, itemObj, env, procHistObj, mfail)
#define AdvBuildProcessHistoryAtParent(_class, className, lastProcHist, procHistType, flowObj, nextStep, submitter, advComment, itemObj, env, procHistObj, mfail) \
        _AdvBuildProcessHistory(_class, TRUE, className, lastProcHist, procHistType, flowObj, nextStep, submitter, advComment, itemObj, env, procHistObj, mfail)

#define AdvCloseAssignment(thisObj, mfail) \
        _AdvCloseAssignmentAtClass(NULL, FALSE, thisObj, mfail)
#define AdvCloseAssignmentAtClass(class, thisObj, mfail) \
        _AdvCloseAssignmentAtClass(class, FALSE, thisObj, mfail)
#define AdvCloseAssignmentAtParent(class, thisObj, mfail) \
        _AdvCloseAssignmentAtClass(class, TRUE, thisObj, mfail)

#define AdvCloseAssignmentSet(className, processSigs, mfail) \
        _AdvCloseAssignmentSet(className, FALSE, className, processSigs, mfail)
#define AdvCloseAssignmentSetAtParent(_class, className, processSigs, mfail) \
        _AdvCloseAssignmentSet(_class, TRUE, className, processSigs, mfail)

#define AdvCloseProcess(thisObj, exitState, exitMode, advComment, itemObj, procHist, env, processSigs, mfail) \
        _AdvCloseProcessAtClass(NULL, FALSE, thisObj, exitState, exitMode, advComment, itemObj, procHist, env, processSigs, mfail)
#define AdvCloseProcessAtClass(class, thisObj, exitState, exitMode, advComment, itemObj, procHist, env, processSigs, mfail) \
        _AdvCloseProcessAtClass(class, FALSE, thisObj, exitState, exitMode, advComment, itemObj, procHist, env, processSigs, mfail)
#define AdvCloseProcessAtParent(class, thisObj, exitState, exitMode, advComment, itemObj, procHist, env, processSigs, mfail) \
        _AdvCloseProcessAtClass(class, TRUE, thisObj, exitState, exitMode, advComment, itemObj, procHist, env, processSigs, mfail)

#define AdvCloseProcessInst(thisObj, itemObj, env, exitState, exitMode, advComment, mfail) \
        _AdvCloseProcessInstAtClass(NULL, FALSE, thisObj, itemObj, env, exitState, exitMode, advComment, mfail)
#define AdvCloseProcessInstAtClass(class, thisObj, itemObj, env, exitState, exitMode, advComment, mfail) \
        _AdvCloseProcessInstAtClass(class, FALSE, thisObj, itemObj, env, exitState, exitMode, advComment, mfail)
#define AdvCloseProcessInstAtParent(class, thisObj, itemObj, env, exitState, exitMode, advComment, mfail) \
        _AdvCloseProcessInstAtClass(class, TRUE, thisObj, itemObj, env, exitState, exitMode, advComment, mfail)

#define AdvCloseRelatedHistory(thisObj, itemObj, mfail) \
        _AdvCloseRelatedHistoryAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define AdvCloseRelatedHistoryAtClass(class, thisObj, itemObj, mfail) \
        _AdvCloseRelatedHistoryAtClass(class, FALSE, thisObj, itemObj, mfail)
#define AdvCloseRelatedHistoryAtParent(class, thisObj, itemObj, mfail) \
        _AdvCloseRelatedHistoryAtClass(class, TRUE, thisObj, itemObj, mfail)

#define AdvComputeExitState(thisObj, sigObj, processSigs, exitState, exitMode, sequence, mfail) \
        _AdvComputeExitStateAtClass(NULL, FALSE, thisObj, sigObj, processSigs, exitState, exitMode, sequence, mfail)
#define AdvComputeExitStateAtClass(class, thisObj, sigObj, processSigs, exitState, exitMode, sequence, mfail) \
        _AdvComputeExitStateAtClass(class, FALSE, thisObj, sigObj, processSigs, exitState, exitMode, sequence, mfail)
#define AdvComputeExitStateAtParent(class, thisObj, sigObj, processSigs, exitState, exitMode, sequence, mfail) \
        _AdvComputeExitStateAtClass(class, TRUE, thisObj, sigObj, processSigs, exitState, exitMode, sequence, mfail)

#define AdvComputeLvlExitState(thisObj, itemObj, procHist, childProcHist, exitState, exitMode, sequence, mfail) \
        _AdvComputeLvlExitStateAtClass(NULL, FALSE, thisObj, itemObj, procHist, childProcHist, exitState, exitMode, sequence, mfail)
#define AdvComputeLvlExitStateAtClass(class, thisObj, itemObj, procHist, childProcHist, exitState, exitMode, sequence, mfail) \
        _AdvComputeLvlExitStateAtClass(class, FALSE, thisObj, itemObj, procHist, childProcHist, exitState, exitMode, sequence, mfail)
#define AdvComputeLvlExitStateAtParent(class, thisObj, itemObj, procHist, childProcHist, exitState, exitMode, sequence, mfail) \
        _AdvComputeLvlExitStateAtClass(class, TRUE, thisObj, itemObj, procHist, childProcHist, exitState, exitMode, sequence, mfail)

#define AdvCreateSubmitterSig(className, workItem, processHistory, sbrUserName, sbrComments, sbrSigObj, mfail) \
        _AdvCreateSubmitterSig(className, FALSE, className, workItem, processHistory, sbrUserName, sbrComments, sbrSigObj, mfail)
#define AdvCreateSubmitterSigAtParent(_class, className, workItem, processHistory, sbrUserName, sbrComments, sbrSigObj, mfail) \
        _AdvCreateSubmitterSig(_class, TRUE, className, workItem, processHistory, sbrUserName, sbrComments, sbrSigObj, mfail)

#define AdvDoExpireAction(thisObj, mfail) \
        _AdvDoExpireActionAtClass(NULL, FALSE, thisObj, mfail)
#define AdvDoExpireActionAtClass(class, thisObj, mfail) \
        _AdvDoExpireActionAtClass(class, FALSE, thisObj, mfail)
#define AdvDoExpireActionAtParent(class, thisObj, mfail) \
        _AdvDoExpireActionAtClass(class, TRUE, thisObj, mfail)

#define AdvDoPostProcessExit(thisObj, procHist, mfail) \
        _AdvDoPostProcessExitAtClass(NULL, FALSE, thisObj, procHist, mfail)
#define AdvDoPostProcessExitAtClass(class, thisObj, procHist, mfail) \
        _AdvDoPostProcessExitAtClass(class, FALSE, thisObj, procHist, mfail)
#define AdvDoPostProcessExitAtParent(class, thisObj, procHist, mfail) \
        _AdvDoPostProcessExitAtClass(class, TRUE, thisObj, procHist, mfail)

#define AdvDoProcess(thisObj, itemObj, procHist, env, mfail) \
        _AdvDoProcessAtClass(NULL, FALSE, thisObj, itemObj, procHist, env, mfail)
#define AdvDoProcessAtClass(class, thisObj, itemObj, procHist, env, mfail) \
        _AdvDoProcessAtClass(class, FALSE, thisObj, itemObj, procHist, env, mfail)
#define AdvDoProcessAtParent(class, thisObj, itemObj, procHist, env, mfail) \
        _AdvDoProcessAtClass(class, TRUE, thisObj, itemObj, procHist, env, mfail)

#define AdvDoProcessExit(thisObj, exitState, exitMode, sequence, itemObj, procHist, env, processSigs, mfail) \
        _AdvDoProcessExitAtClass(NULL, FALSE, thisObj, exitState, exitMode, sequence, itemObj, procHist, env, processSigs, mfail)
#define AdvDoProcessExitAtClass(class, thisObj, exitState, exitMode, sequence, itemObj, procHist, env, processSigs, mfail) \
        _AdvDoProcessExitAtClass(class, FALSE, thisObj, exitState, exitMode, sequence, itemObj, procHist, env, processSigs, mfail)
#define AdvDoProcessExitAtParent(class, thisObj, exitState, exitMode, sequence, itemObj, procHist, env, processSigs, mfail) \
        _AdvDoProcessExitAtClass(class, TRUE, thisObj, exitState, exitMode, sequence, itemObj, procHist, env, processSigs, mfail)

#define AdvDoSigAction(thisObj, env, mfail) \
        _AdvDoSigActionAtClass(NULL, FALSE, thisObj, env, mfail)
#define AdvDoSigActionAtClass(class, thisObj, env, mfail) \
        _AdvDoSigActionAtClass(class, FALSE, thisObj, env, mfail)
#define AdvDoSigActionAtParent(class, thisObj, env, mfail) \
        _AdvDoSigActionAtClass(class, TRUE, thisObj, env, mfail)

#define AdvExpandActor(className, participant, itemObj, postEvent, processParticips, userList, noUsers, mfail) \
        _AdvExpandActor(className, FALSE, className, participant, itemObj, postEvent, processParticips, userList, noUsers, mfail)
#define AdvExpandActorAtParent(_class, className, participant, itemObj, postEvent, processParticips, userList, noUsers, mfail) \
        _AdvExpandActor(_class, TRUE, className, participant, itemObj, postEvent, processParticips, userList, noUsers, mfail)

#define AdvExpandActor2(className, actorObj, participant, itemObj, postEvent, procInactiveUsers, processParticips, userList, noUsers, mfail) \
        _AdvExpandActor2(className, FALSE, className, actorObj, participant, itemObj, postEvent, procInactiveUsers, processParticips, userList, noUsers, mfail)
#define AdvExpandActor2AtParent(_class, className, actorObj, participant, itemObj, postEvent, procInactiveUsers, processParticips, userList, noUsers, mfail) \
        _AdvExpandActor2(_class, TRUE, className, actorObj, participant, itemObj, postEvent, procInactiveUsers, processParticips, userList, noUsers, mfail)

#define AdvExpandActor3(className, actorObj, participant, processHistory, itemObj, postEvent, procInactiveUsers, processParticips, userList, noUsers, mfail) \
        _AdvExpandActor3(className, FALSE, className, actorObj, participant, processHistory, itemObj, postEvent, procInactiveUsers, processParticips, userList, noUsers, mfail)
#define AdvExpandActor3AtParent(_class, className, actorObj, participant, processHistory, itemObj, postEvent, procInactiveUsers, processParticips, userList, noUsers, mfail) \
        _AdvExpandActor3(_class, TRUE, className, actorObj, participant, processHistory, itemObj, postEvent, procInactiveUsers, processParticips, userList, noUsers, mfail)

#define AdvFindEffProcessRev(className, thisObj, stepObj, effProcessObj, advComment, mfail) \
        _AdvFindEffProcessRev(className, FALSE, className, thisObj, stepObj, effProcessObj, advComment, mfail)
#define AdvFindEffProcessRevAtParent(_class, className, thisObj, stepObj, effProcessObj, advComment, mfail) \
        _AdvFindEffProcessRev(_class, TRUE, className, thisObj, stepObj, effProcessObj, advComment, mfail)

#define AdvFindProcessActors(className, effProcess, dynActors, processActors, processParticipants, processWorkList, advComment, mfail) \
        _AdvFindProcessActors(className, FALSE, className, effProcess, dynActors, processActors, processParticipants, processWorkList, advComment, mfail)
#define AdvFindProcessActorsAtParent(_class, className, effProcess, dynActors, processActors, processParticipants, processWorkList, advComment, mfail) \
        _AdvFindProcessActors(_class, TRUE, className, effProcess, dynActors, processActors, processParticipants, processWorkList, advComment, mfail)

#define AdvGetNextState(stepObj, exitState, nextState, mfail) \
        _AdvGetNextStateAtClass(NULL, FALSE, stepObj, exitState, nextState, mfail)
#define AdvGetNextStateAtClass(class, stepObj, exitState, nextState, mfail) \
        _AdvGetNextStateAtClass(class, FALSE, stepObj, exitState, nextState, mfail)
#define AdvGetNextStateAtParent(class, stepObj, exitState, nextState, mfail) \
        _AdvGetNextStateAtClass(class, TRUE, stepObj, exitState, nextState, mfail)

#define AdvGetNextStep(stepObj, exitState, nextStep, advance, mfail) \
        _AdvGetNextStepAtClass(NULL, FALSE, stepObj, exitState, nextStep, advance, mfail)
#define AdvGetNextStepAtClass(class, stepObj, exitState, nextStep, advance, mfail) \
        _AdvGetNextStepAtClass(class, FALSE, stepObj, exitState, nextStep, advance, mfail)
#define AdvGetNextStepAtParent(class, stepObj, exitState, nextStep, advance, mfail) \
        _AdvGetNextStepAtClass(class, TRUE, stepObj, exitState, nextStep, advance, mfail)

#define AdvGetNextVault(stepObj, exitState, nextVault, mfail) \
        _AdvGetNextVaultAtClass(NULL, FALSE, stepObj, exitState, nextVault, mfail)
#define AdvGetNextVaultAtClass(class, stepObj, exitState, nextVault, mfail) \
        _AdvGetNextVaultAtClass(class, FALSE, stepObj, exitState, nextVault, mfail)
#define AdvGetNextVaultAtParent(class, stepObj, exitState, nextVault, mfail) \
        _AdvGetNextVaultAtClass(class, TRUE, stepObj, exitState, nextVault, mfail)

#define AdvGetNextVaultReq(stepObj, procHist, exitState, nextVault, mfail) \
        _AdvGetNextVaultReqAtClass(NULL, FALSE, stepObj, procHist, exitState, nextVault, mfail)
#define AdvGetNextVaultReqAtClass(class, stepObj, procHist, exitState, nextVault, mfail) \
        _AdvGetNextVaultReqAtClass(class, FALSE, stepObj, procHist, exitState, nextVault, mfail)
#define AdvGetNextVaultReqAtParent(class, stepObj, procHist, exitState, nextVault, mfail) \
        _AdvGetNextVaultReqAtClass(class, TRUE, stepObj, procHist, exitState, nextVault, mfail)

#define AdvGetStepObj(className, procHist, stepObj, advComment, mfail) \
        _AdvGetStepObj(className, FALSE, className, procHist, stepObj, advComment, mfail)
#define AdvGetStepObjAtParent(_class, className, procHist, stepObj, advComment, mfail) \
        _AdvGetStepObj(_class, TRUE, className, procHist, stepObj, advComment, mfail)

#define AdvInflateDynParticip(thisObj, effProcessObj, processActors, mfail) \
        _AdvInflateDynParticipAtClass(NULL, FALSE, thisObj, effProcessObj, processActors, mfail)
#define AdvInflateDynParticipAtClass(class, thisObj, effProcessObj, processActors, mfail) \
        _AdvInflateDynParticipAtClass(class, FALSE, thisObj, effProcessObj, processActors, mfail)
#define AdvInflateDynParticipAtParent(class, thisObj, effProcessObj, processActors, mfail) \
        _AdvInflateDynParticipAtClass(class, TRUE, thisObj, effProcessObj, processActors, mfail)

#define AdvPauseProcessHistory(thisObj, itemObj, env, mfail) \
        _AdvPauseProcessHistoryAtClass(NULL, FALSE, thisObj, itemObj, env, mfail)
#define AdvPauseProcessHistoryAtClass(class, thisObj, itemObj, env, mfail) \
        _AdvPauseProcessHistoryAtClass(class, FALSE, thisObj, itemObj, env, mfail)
#define AdvPauseProcessHistoryAtParent(class, thisObj, itemObj, env, mfail) \
        _AdvPauseProcessHistoryAtClass(class, TRUE, thisObj, itemObj, env, mfail)

#define AdvPromoteObject(thisObj, procHist, env, stepObj, exitState, advComment, mfail) \
        _AdvPromoteObjectAtClass(NULL, FALSE, thisObj, procHist, env, stepObj, exitState, advComment, mfail)
#define AdvPromoteObjectAtClass(class, thisObj, procHist, env, stepObj, exitState, advComment, mfail) \
        _AdvPromoteObjectAtClass(class, FALSE, thisObj, procHist, env, stepObj, exitState, advComment, mfail)
#define AdvPromoteObjectAtParent(class, thisObj, procHist, env, stepObj, exitState, advComment, mfail) \
        _AdvPromoteObjectAtClass(class, TRUE, thisObj, procHist, env, stepObj, exitState, advComment, mfail)

#define AdvResetProcessHistory(thisObj, itemObj, advFail, advComment, effProcess, mfail) \
        _AdvResetProcessHistoryAtClass(NULL, FALSE, thisObj, itemObj, advFail, advComment, effProcess, mfail)
#define AdvResetProcessHistoryAtClass(class, thisObj, itemObj, advFail, advComment, effProcess, mfail) \
        _AdvResetProcessHistoryAtClass(class, FALSE, thisObj, itemObj, advFail, advComment, effProcess, mfail)
#define AdvResetProcessHistoryAtParent(class, thisObj, itemObj, advFail, advComment, effProcess, mfail) \
        _AdvResetProcessHistoryAtClass(class, TRUE, thisObj, itemObj, advFail, advComment, effProcess, mfail)

#define AdvRoute(thisObj, dlgObj, env, mfail) \
        _AdvRouteAtClass(NULL, FALSE, thisObj, dlgObj, env, mfail)
#define AdvRouteAtClass(class, thisObj, dlgObj, env, mfail) \
        _AdvRouteAtClass(class, FALSE, thisObj, dlgObj, env, mfail)
#define AdvRouteAtParent(class, thisObj, dlgObj, env, mfail) \
        _AdvRouteAtClass(class, TRUE, thisObj, dlgObj, env, mfail)

#define AdvRouteWorkItemPost(thisObj, dialogObj, flowObj, mfail) \
        _AdvRouteWorkItemPostAtClass(NULL, FALSE, thisObj, dialogObj, flowObj, mfail)
#define AdvRouteWorkItemPostAtClass(class, thisObj, dialogObj, flowObj, mfail) \
        _AdvRouteWorkItemPostAtClass(class, FALSE, thisObj, dialogObj, flowObj, mfail)
#define AdvRouteWorkItemPostAtParent(class, thisObj, dialogObj, flowObj, mfail) \
        _AdvRouteWorkItemPostAtClass(class, TRUE, thisObj, dialogObj, flowObj, mfail)

#define AdvRouteWorkItemPre(thisObj, dialogObj, flowObj, mfail) \
        _AdvRouteWorkItemPreAtClass(NULL, FALSE, thisObj, dialogObj, flowObj, mfail)
#define AdvRouteWorkItemPreAtClass(class, thisObj, dialogObj, flowObj, mfail) \
        _AdvRouteWorkItemPreAtClass(class, FALSE, thisObj, dialogObj, flowObj, mfail)
#define AdvRouteWorkItemPreAtParent(class, thisObj, dialogObj, flowObj, mfail) \
        _AdvRouteWorkItemPreAtClass(class, TRUE, thisObj, dialogObj, flowObj, mfail)

#define AdvStartAssignment(thisObj, mfail) \
        _AdvStartAssignmentAtClass(NULL, FALSE, thisObj, mfail)
#define AdvStartAssignmentAtClass(class, thisObj, mfail) \
        _AdvStartAssignmentAtClass(class, FALSE, thisObj, mfail)
#define AdvStartAssignmentAtParent(class, thisObj, mfail) \
        _AdvStartAssignmentAtClass(class, TRUE, thisObj, mfail)

#define AdvStartProcessHistory(thisObj, effProcess, itemObj, env, mfail) \
        _AdvStartProcessHistoryAtClass(NULL, FALSE, thisObj, effProcess, itemObj, env, mfail)
#define AdvStartProcessHistoryAtClass(class, thisObj, effProcess, itemObj, env, mfail) \
        _AdvStartProcessHistoryAtClass(class, FALSE, thisObj, effProcess, itemObj, env, mfail)
#define AdvStartProcessHistoryAtParent(class, thisObj, effProcess, itemObj, env, mfail) \
        _AdvStartProcessHistoryAtClass(class, TRUE, thisObj, effProcess, itemObj, env, mfail)

#define AdvStateProcessHistory(thisObj, itemObj, env, stepObj, exitState, mfail) \
        _AdvStateProcessHistoryAtClass(NULL, FALSE, thisObj, itemObj, env, stepObj, exitState, mfail)
#define AdvStateProcessHistoryAtClass(class, thisObj, itemObj, env, stepObj, exitState, mfail) \
        _AdvStateProcessHistoryAtClass(class, FALSE, thisObj, itemObj, env, stepObj, exitState, mfail)
#define AdvStateProcessHistoryAtParent(class, thisObj, itemObj, env, stepObj, exitState, mfail) \
        _AdvStateProcessHistoryAtClass(class, TRUE, thisObj, itemObj, env, stepObj, exitState, mfail)

#define AdvStepEntry(thisObj, procHist, env, mfail) \
        _AdvStepEntryAtClass(NULL, FALSE, thisObj, procHist, env, mfail)
#define AdvStepEntryAtClass(class, thisObj, procHist, env, mfail) \
        _AdvStepEntryAtClass(class, FALSE, thisObj, procHist, env, mfail)
#define AdvStepEntryAtParent(class, thisObj, procHist, env, mfail) \
        _AdvStepEntryAtClass(class, TRUE, thisObj, procHist, env, mfail)

#define AdvStepExit(thisObj, procHist, env, mfail) \
        _AdvStepExitAtClass(NULL, FALSE, thisObj, procHist, env, mfail)
#define AdvStepExitAtClass(class, thisObj, procHist, env, mfail) \
        _AdvStepExitAtClass(class, FALSE, thisObj, procHist, env, mfail)
#define AdvStepExitAtParent(class, thisObj, procHist, env, mfail) \
        _AdvStepExitAtClass(class, TRUE, thisObj, procHist, env, mfail)

#define AdvSubmit(thisObj, dlgObj, env, mfail) \
        _AdvSubmitAtClass(NULL, FALSE, thisObj, dlgObj, env, mfail)
#define AdvSubmitAtClass(class, thisObj, dlgObj, env, mfail) \
        _AdvSubmitAtClass(class, FALSE, thisObj, dlgObj, env, mfail)
#define AdvSubmitAtParent(class, thisObj, dlgObj, env, mfail) \
        _AdvSubmitAtClass(class, TRUE, thisObj, dlgObj, env, mfail)

#define AdvSubmitInt(thisObj, dlgObj, env, lastProcHist, lcyObj, submitter, nextStep, prhType, mfail) \
        _AdvSubmitIntAtClass(NULL, FALSE, thisObj, dlgObj, env, lastProcHist, lcyObj, submitter, nextStep, prhType, mfail)
#define AdvSubmitIntAtClass(class, thisObj, dlgObj, env, lastProcHist, lcyObj, submitter, nextStep, prhType, mfail) \
        _AdvSubmitIntAtClass(class, FALSE, thisObj, dlgObj, env, lastProcHist, lcyObj, submitter, nextStep, prhType, mfail)
#define AdvSubmitIntAtParent(class, thisObj, dlgObj, env, lastProcHist, lcyObj, submitter, nextStep, prhType, mfail) \
        _AdvSubmitIntAtClass(class, TRUE, thisObj, dlgObj, env, lastProcHist, lcyObj, submitter, nextStep, prhType, mfail)

#define AdvSubmitWorkItemPost(thisObj, dialogObj, flowObj, mfail) \
        _AdvSubmitWorkItemPostAtClass(NULL, FALSE, thisObj, dialogObj, flowObj, mfail)
#define AdvSubmitWorkItemPostAtClass(class, thisObj, dialogObj, flowObj, mfail) \
        _AdvSubmitWorkItemPostAtClass(class, FALSE, thisObj, dialogObj, flowObj, mfail)
#define AdvSubmitWorkItemPostAtParent(class, thisObj, dialogObj, flowObj, mfail) \
        _AdvSubmitWorkItemPostAtClass(class, TRUE, thisObj, dialogObj, flowObj, mfail)

#define AdvSubmitWorkItemPre(thisObj, dialogObj, flowObj, mfail) \
        _AdvSubmitWorkItemPreAtClass(NULL, FALSE, thisObj, dialogObj, flowObj, mfail)
#define AdvSubmitWorkItemPreAtClass(class, thisObj, dialogObj, flowObj, mfail) \
        _AdvSubmitWorkItemPreAtClass(class, FALSE, thisObj, dialogObj, flowObj, mfail)
#define AdvSubmitWorkItemPreAtParent(class, thisObj, dialogObj, flowObj, mfail) \
        _AdvSubmitWorkItemPreAtClass(class, TRUE, thisObj, dialogObj, flowObj, mfail)

#define AdvTrailProcessHistory(thisObj, advComment, mfail) \
        _AdvTrailProcessHistoryAtClass(NULL, FALSE, thisObj, advComment, mfail)
#define AdvTrailProcessHistoryAtClass(class, thisObj, advComment, mfail) \
        _AdvTrailProcessHistoryAtClass(class, FALSE, thisObj, advComment, mfail)
#define AdvTrailProcessHistoryAtParent(class, thisObj, advComment, mfail) \
        _AdvTrailProcessHistoryAtClass(class, TRUE, thisObj, advComment, mfail)

#define AdvTransferAllObject(thisObj, procHist, vaultName, advComment, mfail) \
        _AdvTransferAllObjectAtClass(NULL, FALSE, thisObj, procHist, vaultName, advComment, mfail)
#define AdvTransferAllObjectAtClass(class, thisObj, procHist, vaultName, advComment, mfail) \
        _AdvTransferAllObjectAtClass(class, FALSE, thisObj, procHist, vaultName, advComment, mfail)
#define AdvTransferAllObjectAtParent(class, thisObj, procHist, vaultName, advComment, mfail) \
        _AdvTransferAllObjectAtClass(class, TRUE, thisObj, procHist, vaultName, advComment, mfail)

#define AdvTransferObject(thisObj, procHist, vaultName, vaultDirName, maintainPath, transferAttachedItems, transferAppDepndItems, advComment, mfail) \
        _AdvTransferObjectAtClass(NULL, FALSE, thisObj, procHist, vaultName, vaultDirName, maintainPath, transferAttachedItems, transferAppDepndItems, advComment, mfail)
#define AdvTransferObjectAtClass(class, thisObj, procHist, vaultName, vaultDirName, maintainPath, transferAttachedItems, transferAppDepndItems, advComment, mfail) \
        _AdvTransferObjectAtClass(class, FALSE, thisObj, procHist, vaultName, vaultDirName, maintainPath, transferAttachedItems, transferAppDepndItems, advComment, mfail)
#define AdvTransferObjectAtParent(class, thisObj, procHist, vaultName, vaultDirName, maintainPath, transferAttachedItems, transferAppDepndItems, advComment, mfail) \
        _AdvTransferObjectAtClass(class, TRUE, thisObj, procHist, vaultName, vaultDirName, maintainPath, transferAttachedItems, transferAppDepndItems, advComment, mfail)

#define AdvValidateDoProcess(thisObj, advComment, mfail) \
        _AdvValidateDoProcessAtClass(NULL, FALSE, thisObj, advComment, mfail)
#define AdvValidateDoProcessAtClass(class, thisObj, advComment, mfail) \
        _AdvValidateDoProcessAtClass(class, FALSE, thisObj, advComment, mfail)
#define AdvValidateDoProcessAtParent(class, thisObj, advComment, mfail) \
        _AdvValidateDoProcessAtClass(class, TRUE, thisObj, advComment, mfail)

#define AdvVaultProcessHistory(thisObj, itemObj, stepObj, env, exitState, mfail) \
        _AdvVaultProcessHistoryAtClass(NULL, FALSE, thisObj, itemObj, stepObj, env, exitState, mfail)
#define AdvVaultProcessHistoryAtClass(class, thisObj, itemObj, stepObj, env, exitState, mfail) \
        _AdvVaultProcessHistoryAtClass(class, FALSE, thisObj, itemObj, stepObj, env, exitState, mfail)
#define AdvVaultProcessHistoryAtParent(class, thisObj, itemObj, stepObj, env, exitState, mfail) \
        _AdvVaultProcessHistoryAtClass(class, TRUE, thisObj, itemObj, stepObj, env, exitState, mfail)

#define AllowRoutingListUsage(rteObj, itemObj, allowed, mfail) \
        _AllowRoutingListUsageAtClass(NULL, FALSE, rteObj, itemObj, allowed, mfail)
#define AllowRoutingListUsageAtClass(class, rteObj, itemObj, allowed, mfail) \
        _AllowRoutingListUsageAtClass(class, FALSE, rteObj, itemObj, allowed, mfail)
#define AllowRoutingListUsageAtParent(class, rteObj, itemObj, allowed, mfail) \
        _AllowRoutingListUsageAtClass(class, TRUE, rteObj, itemObj, allowed, mfail)

#define AllowWorkflowUsage(workflowObj, itemObj, allowed, mfail) \
        _AllowWorkflowUsageAtClass(NULL, FALSE, workflowObj, itemObj, allowed, mfail)
#define AllowWorkflowUsageAtClass(class, workflowObj, itemObj, allowed, mfail) \
        _AllowWorkflowUsageAtClass(class, FALSE, workflowObj, itemObj, allowed, mfail)
#define AllowWorkflowUsageAtParent(class, workflowObj, itemObj, allowed, mfail) \
        _AllowWorkflowUsageAtClass(class, TRUE, workflowObj, itemObj, allowed, mfail)

#define ApproveExpediteUsrWork(revSig, workItem, authObj, externalStamp, comments, mfail) \
        _ApproveExpediteUsrWorkAtClass(NULL, FALSE, revSig, workItem, authObj, externalStamp, comments, mfail)
#define ApproveExpediteUsrWorkAtClass(class, revSig, workItem, authObj, externalStamp, comments, mfail) \
        _ApproveExpediteUsrWorkAtClass(class, FALSE, revSig, workItem, authObj, externalStamp, comments, mfail)
#define ApproveExpediteUsrWorkAtParent(class, revSig, workItem, authObj, externalStamp, comments, mfail) \
        _ApproveExpediteUsrWorkAtClass(class, TRUE, revSig, workItem, authObj, externalStamp, comments, mfail)

#define ApproveExpediteWork2(revSig, workItem, externalStamp, comments, mfail) \
        _ApproveExpediteWork2AtClass(NULL, FALSE, revSig, workItem, externalStamp, comments, mfail)
#define ApproveExpediteWork2AtClass(class, revSig, workItem, externalStamp, comments, mfail) \
        _ApproveExpediteWork2AtClass(class, FALSE, revSig, workItem, externalStamp, comments, mfail)
#define ApproveExpediteWork2AtParent(class, revSig, workItem, externalStamp, comments, mfail) \
        _ApproveExpediteWork2AtClass(class, TRUE, revSig, workItem, externalStamp, comments, mfail)

#define ApproveExpediteWork3(revSig, workItem, externalStamp, comments, mfail) \
        _ApproveExpediteWork3AtClass(NULL, FALSE, revSig, workItem, externalStamp, comments, mfail)
#define ApproveExpediteWork3AtClass(class, revSig, workItem, externalStamp, comments, mfail) \
        _ApproveExpediteWork3AtClass(class, FALSE, revSig, workItem, externalStamp, comments, mfail)
#define ApproveExpediteWork3AtParent(class, revSig, workItem, externalStamp, comments, mfail) \
        _ApproveExpediteWork3AtClass(class, TRUE, revSig, workItem, externalStamp, comments, mfail)

#define ApproveExpediteWorkDP(thisObj, itemObj, mfail) \
        _ApproveExpediteWorkDPAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define ApproveExpediteWorkDPAtClass(class, thisObj, itemObj, mfail) \
        _ApproveExpediteWorkDPAtClass(class, FALSE, thisObj, itemObj, mfail)
#define ApproveExpediteWorkDPAtParent(class, thisObj, itemObj, mfail) \
        _ApproveExpediteWorkDPAtClass(class, TRUE, thisObj, itemObj, mfail)

#define ApproveExpediteWorkP(revSig, workItem, mfail) \
        _ApproveExpediteWorkPAtClass(NULL, FALSE, revSig, workItem, mfail)
#define ApproveExpediteWorkPAtClass(class, revSig, workItem, mfail) \
        _ApproveExpediteWorkPAtClass(class, FALSE, revSig, workItem, mfail)
#define ApproveExpediteWorkPAtParent(class, revSig, workItem, mfail) \
        _ApproveExpediteWorkPAtClass(class, TRUE, revSig, workItem, mfail)

#define ApproveUsrWork(revSig, workItem, authObj, externalStamp, comments, mfail) \
        _ApproveUsrWorkAtClass(NULL, FALSE, revSig, workItem, authObj, externalStamp, comments, mfail)
#define ApproveUsrWorkAtClass(class, revSig, workItem, authObj, externalStamp, comments, mfail) \
        _ApproveUsrWorkAtClass(class, FALSE, revSig, workItem, authObj, externalStamp, comments, mfail)
#define ApproveUsrWorkAtParent(class, revSig, workItem, authObj, externalStamp, comments, mfail) \
        _ApproveUsrWorkAtClass(class, TRUE, revSig, workItem, authObj, externalStamp, comments, mfail)

#define ApproveWork2(revSig, workItem, externalStamp, comments, mfail) \
        _ApproveWork2AtClass(NULL, FALSE, revSig, workItem, externalStamp, comments, mfail)
#define ApproveWork2AtClass(class, revSig, workItem, externalStamp, comments, mfail) \
        _ApproveWork2AtClass(class, FALSE, revSig, workItem, externalStamp, comments, mfail)
#define ApproveWork2AtParent(class, revSig, workItem, externalStamp, comments, mfail) \
        _ApproveWork2AtClass(class, TRUE, revSig, workItem, externalStamp, comments, mfail)

#define ApproveWork3(revSig, workItem, externalStamp, comments, mfail) \
        _ApproveWork3AtClass(NULL, FALSE, revSig, workItem, externalStamp, comments, mfail)
#define ApproveWork3AtClass(class, revSig, workItem, externalStamp, comments, mfail) \
        _ApproveWork3AtClass(class, FALSE, revSig, workItem, externalStamp, comments, mfail)
#define ApproveWork3AtParent(class, revSig, workItem, externalStamp, comments, mfail) \
        _ApproveWork3AtClass(class, TRUE, revSig, workItem, externalStamp, comments, mfail)

#define ApproveWorkDP(thisObj, itemObj, mfail) \
        _ApproveWorkDPAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define ApproveWorkDPAtClass(class, thisObj, itemObj, mfail) \
        _ApproveWorkDPAtClass(class, FALSE, thisObj, itemObj, mfail)
#define ApproveWorkDPAtParent(class, thisObj, itemObj, mfail) \
        _ApproveWorkDPAtClass(class, TRUE, thisObj, itemObj, mfail)

#define ApproveWorkP(revSig, workItem, mfail) \
        _ApproveWorkPAtClass(NULL, FALSE, revSig, workItem, mfail)
#define ApproveWorkPAtClass(class, revSig, workItem, mfail) \
        _ApproveWorkPAtClass(class, FALSE, revSig, workItem, mfail)
#define ApproveWorkPAtParent(class, revSig, workItem, mfail) \
        _ApproveWorkPAtClass(class, TRUE, revSig, workItem, mfail)

#define AssignReviewList(itemObj, revList, mfail) \
        _AssignReviewListAtClass(NULL, FALSE, itemObj, revList, mfail)
#define AssignReviewListAtClass(class, itemObj, revList, mfail) \
        _AssignReviewListAtClass(class, FALSE, itemObj, revList, mfail)
#define AssignReviewListAtParent(class, itemObj, revList, mfail) \
        _AssignReviewListAtClass(class, TRUE, itemObj, revList, mfail)

#define AssignReviewListDP(thisObj, mfail) \
        _AssignReviewListDPAtClass(NULL, FALSE, thisObj, mfail)
#define AssignReviewListDPAtClass(class, thisObj, mfail) \
        _AssignReviewListDPAtClass(class, FALSE, thisObj, mfail)
#define AssignReviewListDPAtParent(class, thisObj, mfail) \
        _AssignReviewListDPAtClass(class, TRUE, thisObj, mfail)

#define AuthenticateSignoff(sigObj, workItem, authObj, authenticated, mfail) \
        _AuthenticateSignoffAtClass(NULL, FALSE, sigObj, workItem, authObj, authenticated, mfail)
#define AuthenticateSignoffAtClass(class, sigObj, workItem, authObj, authenticated, mfail) \
        _AuthenticateSignoffAtClass(class, FALSE, sigObj, workItem, authObj, authenticated, mfail)
#define AuthenticateSignoffAtParent(class, sigObj, workItem, authObj, authenticated, mfail) \
        _AuthenticateSignoffAtClass(class, TRUE, sigObj, workItem, authObj, authenticated, mfail)

#define AuthenticateSignoffP(sigObj, workItem, authObj, authenticated, mfail) \
        _AuthenticateSignoffPAtClass(NULL, FALSE, sigObj, workItem, authObj, authenticated, mfail)
#define AuthenticateSignoffPAtClass(class, sigObj, workItem, authObj, authenticated, mfail) \
        _AuthenticateSignoffPAtClass(class, FALSE, sigObj, workItem, authObj, authenticated, mfail)
#define AuthenticateSignoffPAtParent(class, sigObj, workItem, authObj, authenticated, mfail) \
        _AuthenticateSignoffPAtClass(class, TRUE, sigObj, workItem, authObj, authenticated, mfail)

#define BldFindInSetSrchStr(className, actorObj, participObj, findInSetStr, mfail) \
        _BldFindInSetSrchStr(className, FALSE, className, actorObj, participObj, findInSetStr, mfail)
#define BldFindInSetSrchStrAtParent(_class, className, actorObj, participObj, findInSetStr, mfail) \
        _BldFindInSetSrchStr(_class, TRUE, className, actorObj, participObj, findInSetStr, mfail)

#define BldLCMActDetailInfo(thisObj, procHist, dialogObj, objectInfo, mfail) \
        _BldLCMActDetailInfoAtClass(NULL, FALSE, thisObj, procHist, dialogObj, objectInfo, mfail)
#define BldLCMActDetailInfoAtClass(class, thisObj, procHist, dialogObj, objectInfo, mfail) \
        _BldLCMActDetailInfoAtClass(class, FALSE, thisObj, procHist, dialogObj, objectInfo, mfail)
#define BldLCMActDetailInfoAtParent(class, thisObj, procHist, dialogObj, objectInfo, mfail) \
        _BldLCMActDetailInfoAtClass(class, TRUE, thisObj, procHist, dialogObj, objectInfo, mfail)

#define BldLCMActivityInfo(thisObj, lcStep, dialogObj, objectInfo, mfail) \
        _BldLCMActivityInfoAtClass(NULL, FALSE, thisObj, lcStep, dialogObj, objectInfo, mfail)
#define BldLCMActivityInfoAtClass(class, thisObj, lcStep, dialogObj, objectInfo, mfail) \
        _BldLCMActivityInfoAtClass(class, FALSE, thisObj, lcStep, dialogObj, objectInfo, mfail)
#define BldLCMActivityInfoAtParent(class, thisObj, lcStep, dialogObj, objectInfo, mfail) \
        _BldLCMActivityInfoAtClass(class, TRUE, thisObj, lcStep, dialogObj, objectInfo, mfail)

#define BldLCMActorInfo(thisObj, dialogObj, objectInfo, mfail) \
        _BldLCMActorInfoAtClass(NULL, FALSE, thisObj, dialogObj, objectInfo, mfail)
#define BldLCMActorInfoAtClass(class, thisObj, dialogObj, objectInfo, mfail) \
        _BldLCMActorInfoAtClass(class, FALSE, thisObj, dialogObj, objectInfo, mfail)
#define BldLCMActorInfoAtParent(class, thisObj, dialogObj, objectInfo, mfail) \
        _BldLCMActorInfoAtClass(class, TRUE, thisObj, dialogObj, objectInfo, mfail)

#define BldLCMMetricsInfo(thisObj, dialogObj, objectInfo, mfail) \
        _BldLCMMetricsInfoAtClass(NULL, FALSE, thisObj, dialogObj, objectInfo, mfail)
#define BldLCMMetricsInfoAtClass(class, thisObj, dialogObj, objectInfo, mfail) \
        _BldLCMMetricsInfoAtClass(class, FALSE, thisObj, dialogObj, objectInfo, mfail)
#define BldLCMMetricsInfoAtParent(class, thisObj, dialogObj, objectInfo, mfail) \
        _BldLCMMetricsInfoAtClass(class, TRUE, thisObj, dialogObj, objectInfo, mfail)

#define BranchDefUseWorkflow(className, flowObj, answer, mfail) \
        _BranchDefUseWorkflow(className, FALSE, className, flowObj, answer, mfail)
#define BranchDefUseWorkflowAtParent(_class, className, flowObj, answer, mfail) \
        _BranchDefUseWorkflow(_class, TRUE, className, flowObj, answer, mfail)

#define BuildTaskWorkListSql(taskObject, workListFilterObj, sql, mfail) \
        _BuildTaskWorkListSqlAtClass(NULL, FALSE, taskObject, workListFilterObj, sql, mfail)
#define BuildTaskWorkListSqlAtClass(class, taskObject, workListFilterObj, sql, mfail) \
        _BuildTaskWorkListSqlAtClass(class, FALSE, taskObject, workListFilterObj, sql, mfail)
#define BuildTaskWorkListSqlAtParent(class, taskObject, workListFilterObj, sql, mfail) \
        _BuildTaskWorkListSqlAtClass(class, TRUE, taskObject, workListFilterObj, sql, mfail)

#define CalComputeDueDate(calendarObj, startDate, days, dueDate, mfail) \
        _CalComputeDueDateAtClass(NULL, FALSE, calendarObj, startDate, days, dueDate, mfail)
#define CalComputeDueDateAtClass(class, calendarObj, startDate, days, dueDate, mfail) \
        _CalComputeDueDateAtClass(class, FALSE, calendarObj, startDate, days, dueDate, mfail)
#define CalComputeDueDateAtParent(class, calendarObj, startDate, days, dueDate, mfail) \
        _CalComputeDueDateAtClass(class, TRUE, calendarObj, startDate, days, dueDate, mfail)

#define CalendarNameExists(className, calendarName, exists, mfail) \
        _CalendarNameExists(className, FALSE, className, calendarName, exists, mfail)
#define CalendarNameExistsAtParent(_class, className, calendarName, exists, mfail) \
        _CalendarNameExists(_class, TRUE, className, calendarName, exists, mfail)

#define CheckForReplacementUser(className, curParticp, itemObj, curPrtcpObj, replaceParticp, replacePrcptObj, mfail) \
        _CheckForReplacementUser(className, FALSE, className, curParticp, itemObj, curPrtcpObj, replaceParticp, replacePrcptObj, mfail)
#define CheckForReplacementUserAtParent(_class, className, curParticp, itemObj, curPrtcpObj, replaceParticp, replacePrcptObj, mfail) \
        _CheckForReplacementUser(_class, TRUE, className, curParticp, itemObj, curPrtcpObj, replaceParticp, replacePrcptObj, mfail)

#define CkiItemForSignoff(thisObj, mfail) \
        _CkiItemForSignoffAtClass(NULL, FALSE, thisObj, mfail)
#define CkiItemForSignoffAtClass(class, thisObj, mfail) \
        _CkiItemForSignoffAtClass(class, FALSE, thisObj, mfail)
#define CkiItemForSignoffAtParent(class, thisObj, mfail) \
        _CkiItemForSignoffAtClass(class, TRUE, thisObj, mfail)

#define ClaimUsrWork(thisObj, itemObj, mfail) \
        _ClaimUsrWorkAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define ClaimUsrWorkAtClass(class, thisObj, itemObj, mfail) \
        _ClaimUsrWorkAtClass(class, FALSE, thisObj, itemObj, mfail)
#define ClaimUsrWorkAtParent(class, thisObj, itemObj, mfail) \
        _ClaimUsrWorkAtClass(class, TRUE, thisObj, itemObj, mfail)

#define ClaimUsrWorkDP(thisObj, itemObj, mfail) \
        _ClaimUsrWorkDPAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define ClaimUsrWorkDPAtClass(class, thisObj, itemObj, mfail) \
        _ClaimUsrWorkDPAtClass(class, FALSE, thisObj, itemObj, mfail)
#define ClaimUsrWorkDPAtParent(class, thisObj, itemObj, mfail) \
        _ClaimUsrWorkDPAtClass(class, TRUE, thisObj, itemObj, mfail)

#define CommentWork(thisObj, workItem, append, comments, mfail) \
        _CommentWorkAtClass(NULL, FALSE, thisObj, workItem, append, comments, mfail)
#define CommentWorkAtClass(class, thisObj, workItem, append, comments, mfail) \
        _CommentWorkAtClass(class, FALSE, thisObj, workItem, append, comments, mfail)
#define CommentWorkAtParent(class, thisObj, workItem, append, comments, mfail) \
        _CommentWorkAtClass(class, TRUE, thisObj, workItem, append, comments, mfail)

#define CommentWorkDP(thisObj, itemObj, mfail) \
        _CommentWorkDPAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define CommentWorkDPAtClass(class, thisObj, itemObj, mfail) \
        _CommentWorkDPAtClass(class, FALSE, thisObj, itemObj, mfail)
#define CommentWorkDPAtParent(class, thisObj, itemObj, mfail) \
        _CommentWorkDPAtClass(class, TRUE, thisObj, itemObj, mfail)

#define CommentWorkHistoryDP(thisObj, itemObj, mfail) \
        _CommentWorkHistoryDPAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define CommentWorkHistoryDPAtClass(class, thisObj, itemObj, mfail) \
        _CommentWorkHistoryDPAtClass(class, FALSE, thisObj, itemObj, mfail)
#define CommentWorkHistoryDPAtParent(class, thisObj, itemObj, mfail) \
        _CommentWorkHistoryDPAtClass(class, TRUE, thisObj, itemObj, mfail)

#define CompleteUsrWork(asgSig, workItem, authObj, externalStamp, comments, mfail) \
        _CompleteUsrWorkAtClass(NULL, FALSE, asgSig, workItem, authObj, externalStamp, comments, mfail)
#define CompleteUsrWorkAtClass(class, asgSig, workItem, authObj, externalStamp, comments, mfail) \
        _CompleteUsrWorkAtClass(class, FALSE, asgSig, workItem, authObj, externalStamp, comments, mfail)
#define CompleteUsrWorkAtParent(class, asgSig, workItem, authObj, externalStamp, comments, mfail) \
        _CompleteUsrWorkAtClass(class, TRUE, asgSig, workItem, authObj, externalStamp, comments, mfail)

#define CompleteWork2(asgSig, workItem, externalStamp, comments, mfail) \
        _CompleteWork2AtClass(NULL, FALSE, asgSig, workItem, externalStamp, comments, mfail)
#define CompleteWork2AtClass(class, asgSig, workItem, externalStamp, comments, mfail) \
        _CompleteWork2AtClass(class, FALSE, asgSig, workItem, externalStamp, comments, mfail)
#define CompleteWork2AtParent(class, asgSig, workItem, externalStamp, comments, mfail) \
        _CompleteWork2AtClass(class, TRUE, asgSig, workItem, externalStamp, comments, mfail)

#define CompleteWork3(asgSig, workItem, externalStamp, comments, mfail) \
        _CompleteWork3AtClass(NULL, FALSE, asgSig, workItem, externalStamp, comments, mfail)
#define CompleteWork3AtClass(class, asgSig, workItem, externalStamp, comments, mfail) \
        _CompleteWork3AtClass(class, FALSE, asgSig, workItem, externalStamp, comments, mfail)
#define CompleteWork3AtParent(class, asgSig, workItem, externalStamp, comments, mfail) \
        _CompleteWork3AtClass(class, TRUE, asgSig, workItem, externalStamp, comments, mfail)

#define CompleteWorkDP(thisObj, itemObj, mfail) \
        _CompleteWorkDPAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define CompleteWorkDPAtClass(class, thisObj, itemObj, mfail) \
        _CompleteWorkDPAtClass(class, FALSE, thisObj, itemObj, mfail)
#define CompleteWorkDPAtParent(class, thisObj, itemObj, mfail) \
        _CompleteWorkDPAtClass(class, TRUE, thisObj, itemObj, mfail)

#define CompleteWorkP(asgSig, workItem, mfail) \
        _CompleteWorkPAtClass(NULL, FALSE, asgSig, workItem, mfail)
#define CompleteWorkPAtClass(class, asgSig, workItem, mfail) \
        _CompleteWorkPAtClass(class, FALSE, asgSig, workItem, mfail)
#define CompleteWorkPAtParent(class, asgSig, workItem, mfail) \
        _CompleteWorkPAtClass(class, TRUE, asgSig, workItem, mfail)

#define ComputeMetrics(thisObj, prcMetricsObj, mfail) \
        _ComputeMetricsAtClass(NULL, FALSE, thisObj, prcMetricsObj, mfail)
#define ComputeMetricsAtClass(class, thisObj, prcMetricsObj, mfail) \
        _ComputeMetricsAtClass(class, FALSE, thisObj, prcMetricsObj, mfail)
#define ComputeMetricsAtParent(class, thisObj, prcMetricsObj, mfail) \
        _ComputeMetricsAtClass(class, TRUE, thisObj, prcMetricsObj, mfail)

#define ConstructDlgForCreRel(className, originObject, relationship, mfail, dialogObj) \
        _ConstructDlgForCreRel(className, FALSE, className, originObject, relationship, mfail, dialogObj)
#define ConstructDlgForCreRelAtParent(_class, className, originObject, relationship, mfail, dialogObj) \
        _ConstructDlgForCreRel(_class, TRUE, className, originObject, relationship, mfail, dialogObj)

#define CopyProcessBranches(thisObj, sourceObj, mfail) \
        _CopyProcessBranchesAtClass(NULL, FALSE, thisObj, sourceObj, mfail)
#define CopyProcessBranchesAtClass(class, thisObj, sourceObj, mfail) \
        _CopyProcessBranchesAtClass(class, FALSE, thisObj, sourceObj, mfail)
#define CopyProcessBranchesAtParent(class, thisObj, sourceObj, mfail) \
        _CopyProcessBranchesAtClass(class, TRUE, thisObj, sourceObj, mfail)

#define CopyWorkflowSteps(thisObj, flowObj, mfail) \
        _CopyWorkflowStepsAtClass(NULL, FALSE, thisObj, flowObj, mfail)
#define CopyWorkflowStepsAtClass(class, thisObj, flowObj, mfail) \
        _CopyWorkflowStepsAtClass(class, FALSE, thisObj, flowObj, mfail)
#define CopyWorkflowStepsAtParent(class, thisObj, flowObj, mfail) \
        _CopyWorkflowStepsAtClass(class, TRUE, thisObj, flowObj, mfail)

#define CreateAdvisorExt(dialogObj, relationClassName, leftObject, mfail) \
        _CreateAdvisorExtAtClass(NULL, FALSE, dialogObj, relationClassName, leftObject, mfail)
#define CreateAdvisorExtAtClass(class, dialogObj, relationClassName, leftObject, mfail) \
        _CreateAdvisorExtAtClass(class, FALSE, dialogObj, relationClassName, leftObject, mfail)
#define CreateAdvisorExtAtParent(class, dialogObj, relationClassName, leftObject, mfail) \
        _CreateAdvisorExtAtClass(class, TRUE, dialogObj, relationClassName, leftObject, mfail)

#define DEdit(thisObj, mfail) \
        _DEditAtClass(NULL, FALSE, thisObj, mfail)
#define DEditAtClass(class, thisObj, mfail) \
        _DEditAtClass(class, FALSE, thisObj, mfail)
#define DEditAtParent(class, thisObj, mfail) \
        _DEditAtClass(class, TRUE, thisObj, mfail)

#define DEditMoveStepIn(thisObj, originObject, extraObj, stepName, mfail) \
        _DEditMoveStepInAtClass(NULL, FALSE, thisObj, originObject, extraObj, stepName, mfail)
#define DEditMoveStepInAtClass(class, thisObj, originObject, extraObj, stepName, mfail) \
        _DEditMoveStepInAtClass(class, FALSE, thisObj, originObject, extraObj, stepName, mfail)
#define DEditMoveStepInAtParent(class, thisObj, originObject, extraObj, stepName, mfail) \
        _DEditMoveStepInAtClass(class, TRUE, thisObj, originObject, extraObj, stepName, mfail)

#define DEditMoveStepOut(thisObj, originObject, extraStr, extraObj, mfail) \
        _DEditMoveStepOutAtClass(NULL, FALSE, thisObj, originObject, extraStr, extraObj, mfail)
#define DEditMoveStepOutAtClass(class, thisObj, originObject, extraStr, extraObj, mfail) \
        _DEditMoveStepOutAtClass(class, FALSE, thisObj, originObject, extraStr, extraObj, mfail)
#define DEditMoveStepOutAtParent(class, thisObj, originObject, extraStr, extraObj, mfail) \
        _DEditMoveStepOutAtClass(class, TRUE, thisObj, originObject, extraStr, extraObj, mfail)

#define DGetLVSAllActiveUsers(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSAllActiveUsersAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSAllActiveUsersAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSAllActiveUsersAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSAllActiveUsersAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSAllActiveUsersAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSAllParticipants(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSAllParticipantsAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSAllParticipantsAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSAllParticipantsAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSAllParticipantsAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSAllParticipantsAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSCalendarNames(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCalendarNamesAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCalendarNamesAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCalendarNamesAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCalendarNamesAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCalendarNamesAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSLcmActMsgGrps(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSLcmActMsgGrpsAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSLcmActMsgGrpsAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSLcmActMsgGrpsAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSLcmActMsgGrpsAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSLcmActMsgGrpsAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSLcmAvrMsgGrps(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSLcmAvrMsgGrpsAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSLcmAvrMsgGrpsAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSLcmAvrMsgGrpsAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSLcmAvrMsgGrpsAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSLcmAvrMsgGrpsAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSLcyForSavPref(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSLcyForSavPrefAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSLcyForSavPrefAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSLcyForSavPrefAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSLcyForSavPrefAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSLcyForSavPrefAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSLcyForSubmit(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSLcyForSubmitAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSLcyForSubmitAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSLcyForSubmitAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSLcyForSubmitAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSLcyForSubmitAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSLcyProcessNames(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSLcyProcessNamesAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSLcyProcessNamesAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSLcyProcessNamesAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSLcyProcessNamesAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSLcyProcessNamesAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSLcyVaultNames(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSLcyVaultNamesAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSLcyVaultNamesAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSLcyVaultNamesAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSLcyVaultNamesAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSLcyVaultNamesAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSMsgsForAutoProc(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSMsgsForAutoProcAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSMsgsForAutoProcAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSMsgsForAutoProcAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSMsgsForAutoProcAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSMsgsForAutoProcAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSPlpConditions(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSPlpConditionsAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSPlpConditionsAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSPlpConditionsAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSPlpConditionsAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSPlpConditionsAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSRListForRoute(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSRListForRouteAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSRListForRouteAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSRListForRouteAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSRListForRouteAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSRListForRouteAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSReviewList(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSReviewListAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSReviewListAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSReviewListAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSReviewListAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSReviewListAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSTaskTools(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSTaskToolsAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSTaskToolsAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSTaskToolsAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSTaskToolsAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSTaskToolsAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSTflProcessNames(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSTflProcessNamesAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSTflProcessNamesAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSTflProcessNamesAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSTflProcessNamesAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSTflProcessNamesAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSUsersAndRoles(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSUsersAndRolesAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSUsersAndRolesAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSUsersAndRolesAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSUsersAndRolesAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSUsersAndRolesAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSWbpConditions(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSWbpConditionsAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSWbpConditionsAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSWbpConditionsAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSWbpConditionsAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSWbpConditionsAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSWbpSubmitters(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSWbpSubmittersAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSWbpSubmittersAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSWbpSubmittersAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSWbpSubmittersAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSWbpSubmittersAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSWorkItemRels(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSWorkItemRelsAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSWorkItemRelsAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSWorkItemRelsAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSWorkItemRelsAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSWorkItemRelsAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSWorkflwsForProc(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSWorkflwsForProcAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSWorkflwsForProcAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSWorkflwsForProcAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSWorkflwsForProcAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSWorkflwsForProcAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DView(thisObj, mfail) \
        _DViewAtClass(NULL, FALSE, thisObj, mfail)
#define DViewAtClass(class, thisObj, mfail) \
        _DViewAtClass(class, FALSE, thisObj, mfail)
#define DViewAtParent(class, thisObj, mfail) \
        _DViewAtClass(class, TRUE, thisObj, mfail)

#define DViewMoveStepIn(thisObj, originObject, extraObj, stepName, mfail) \
        _DViewMoveStepInAtClass(NULL, FALSE, thisObj, originObject, extraObj, stepName, mfail)
#define DViewMoveStepInAtClass(class, thisObj, originObject, extraObj, stepName, mfail) \
        _DViewMoveStepInAtClass(class, FALSE, thisObj, originObject, extraObj, stepName, mfail)
#define DViewMoveStepInAtParent(class, thisObj, originObject, extraObj, stepName, mfail) \
        _DViewMoveStepInAtClass(class, TRUE, thisObj, originObject, extraObj, stepName, mfail)

#define DeleteRelForSetIntExt(className, originObjects, mfail) \
        _DeleteRelForSetIntExt(className, FALSE, className, originObjects, mfail)
#define DeleteRelForSetIntExtAtParent(_class, className, originObjects, mfail) \
        _DeleteRelForSetIntExt(_class, TRUE, className, originObjects, mfail)

#define DetermineAltUser(className, usrObj, validAltUser, mfail) \
        _DetermineAltUser(className, FALSE, className, usrObj, validAltUser, mfail)
#define DetermineAltUserAtParent(_class, className, usrObj, validAltUser, mfail) \
        _DetermineAltUser(_class, TRUE, className, usrObj, validAltUser, mfail)

#define DoAbortProcHist(thisObj, itemObj, dialogObj, mfail) \
        _DoAbortProcHistAtClass(NULL, FALSE, thisObj, itemObj, dialogObj, mfail)
#define DoAbortProcHistAtClass(class, thisObj, itemObj, dialogObj, mfail) \
        _DoAbortProcHistAtClass(class, FALSE, thisObj, itemObj, dialogObj, mfail)
#define DoAbortProcHistAtParent(class, thisObj, itemObj, dialogObj, mfail) \
        _DoAbortProcHistAtClass(class, TRUE, thisObj, itemObj, dialogObj, mfail)

#define DoAbortProcHistPost(thisObj, itemObj, dialogObj, mfail) \
        _DoAbortProcHistPostAtClass(NULL, FALSE, thisObj, itemObj, dialogObj, mfail)
#define DoAbortProcHistPostAtClass(class, thisObj, itemObj, dialogObj, mfail) \
        _DoAbortProcHistPostAtClass(class, FALSE, thisObj, itemObj, dialogObj, mfail)
#define DoAbortProcHistPostAtParent(class, thisObj, itemObj, dialogObj, mfail) \
        _DoAbortProcHistPostAtClass(class, TRUE, thisObj, itemObj, dialogObj, mfail)

#define DoAbortProcHistPre(thisObj, itemObj, dialogObj, mfail) \
        _DoAbortProcHistPreAtClass(NULL, FALSE, thisObj, itemObj, dialogObj, mfail)
#define DoAbortProcHistPreAtClass(class, thisObj, itemObj, dialogObj, mfail) \
        _DoAbortProcHistPreAtClass(class, FALSE, thisObj, itemObj, dialogObj, mfail)
#define DoAbortProcHistPreAtParent(class, thisObj, itemObj, dialogObj, mfail) \
        _DoAbortProcHistPreAtClass(class, TRUE, thisObj, itemObj, dialogObj, mfail)

#define DoAbortWorkItemPost(thisObj, dialogObj, mfail) \
        _DoAbortWorkItemPostAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoAbortWorkItemPostAtClass(class, thisObj, dialogObj, mfail) \
        _DoAbortWorkItemPostAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoAbortWorkItemPostAtParent(class, thisObj, dialogObj, mfail) \
        _DoAbortWorkItemPostAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoAbortWorkItemPre(thisObj, dialogObj, mfail) \
        _DoAbortWorkItemPreAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoAbortWorkItemPreAtClass(class, thisObj, dialogObj, mfail) \
        _DoAbortWorkItemPreAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoAbortWorkItemPreAtParent(class, thisObj, dialogObj, mfail) \
        _DoAbortWorkItemPreAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoAssignReviewList(itemObj, dialogObj, mfail) \
        _DoAssignReviewListAtClass(NULL, FALSE, itemObj, dialogObj, mfail)
#define DoAssignReviewListAtClass(class, itemObj, dialogObj, mfail) \
        _DoAssignReviewListAtClass(class, FALSE, itemObj, dialogObj, mfail)
#define DoAssignReviewListAtParent(class, itemObj, dialogObj, mfail) \
        _DoAssignReviewListAtClass(class, TRUE, itemObj, dialogObj, mfail)

#define DoAssignReviewListPost(itemObj, dialogObj, mfail) \
        _DoAssignReviewListPostAtClass(NULL, FALSE, itemObj, dialogObj, mfail)
#define DoAssignReviewListPostAtClass(class, itemObj, dialogObj, mfail) \
        _DoAssignReviewListPostAtClass(class, FALSE, itemObj, dialogObj, mfail)
#define DoAssignReviewListPostAtParent(class, itemObj, dialogObj, mfail) \
        _DoAssignReviewListPostAtClass(class, TRUE, itemObj, dialogObj, mfail)

#define DoAssignReviewListPre(itemObj, dialogObj, mfail) \
        _DoAssignReviewListPreAtClass(NULL, FALSE, itemObj, dialogObj, mfail)
#define DoAssignReviewListPreAtClass(class, itemObj, dialogObj, mfail) \
        _DoAssignReviewListPreAtClass(class, FALSE, itemObj, dialogObj, mfail)
#define DoAssignReviewListPreAtParent(class, itemObj, dialogObj, mfail) \
        _DoAssignReviewListPreAtClass(class, TRUE, itemObj, dialogObj, mfail)

#define DoClaimAssign(thisObj, itemObj, mfail) \
        _DoClaimAssignAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define DoClaimAssignAtClass(class, thisObj, itemObj, mfail) \
        _DoClaimAssignAtClass(class, FALSE, thisObj, itemObj, mfail)
#define DoClaimAssignAtParent(class, thisObj, itemObj, mfail) \
        _DoClaimAssignAtClass(class, TRUE, thisObj, itemObj, mfail)

#define DoClaimAssignPost(thisObj, itemObj, mfail) \
        _DoClaimAssignPostAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define DoClaimAssignPostAtClass(class, thisObj, itemObj, mfail) \
        _DoClaimAssignPostAtClass(class, FALSE, thisObj, itemObj, mfail)
#define DoClaimAssignPostAtParent(class, thisObj, itemObj, mfail) \
        _DoClaimAssignPostAtClass(class, TRUE, thisObj, itemObj, mfail)

#define DoClaimAssignPostInt(thisObj, itemObj, mfail) \
        _DoClaimAssignPostIntAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define DoClaimAssignPostIntAtClass(class, thisObj, itemObj, mfail) \
        _DoClaimAssignPostIntAtClass(class, FALSE, thisObj, itemObj, mfail)
#define DoClaimAssignPostIntAtParent(class, thisObj, itemObj, mfail) \
        _DoClaimAssignPostIntAtClass(class, TRUE, thisObj, itemObj, mfail)

#define DoClaimAssignPre(thisObj, itemObj, mfail) \
        _DoClaimAssignPreAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define DoClaimAssignPreAtClass(class, thisObj, itemObj, mfail) \
        _DoClaimAssignPreAtClass(class, FALSE, thisObj, itemObj, mfail)
#define DoClaimAssignPreAtParent(class, thisObj, itemObj, mfail) \
        _DoClaimAssignPreAtClass(class, TRUE, thisObj, itemObj, mfail)

#define DoClaimWorkItemPost(thisObj, sigObj, mfail) \
        _DoClaimWorkItemPostAtClass(NULL, FALSE, thisObj, sigObj, mfail)
#define DoClaimWorkItemPostAtClass(class, thisObj, sigObj, mfail) \
        _DoClaimWorkItemPostAtClass(class, FALSE, thisObj, sigObj, mfail)
#define DoClaimWorkItemPostAtParent(class, thisObj, sigObj, mfail) \
        _DoClaimWorkItemPostAtClass(class, TRUE, thisObj, sigObj, mfail)

#define DoClaimWorkItemPostInt(thisObj, sigObj, mfail) \
        _DoClaimWorkItemPostIntAtClass(NULL, FALSE, thisObj, sigObj, mfail)
#define DoClaimWorkItemPostIntAtClass(class, thisObj, sigObj, mfail) \
        _DoClaimWorkItemPostIntAtClass(class, FALSE, thisObj, sigObj, mfail)
#define DoClaimWorkItemPostIntAtParent(class, thisObj, sigObj, mfail) \
        _DoClaimWorkItemPostIntAtClass(class, TRUE, thisObj, sigObj, mfail)

#define DoClaimWorkItemPre(thisObj, sigObj, mfail) \
        _DoClaimWorkItemPreAtClass(NULL, FALSE, thisObj, sigObj, mfail)
#define DoClaimWorkItemPreAtClass(class, thisObj, sigObj, mfail) \
        _DoClaimWorkItemPreAtClass(class, FALSE, thisObj, sigObj, mfail)
#define DoClaimWorkItemPreAtParent(class, thisObj, sigObj, mfail) \
        _DoClaimWorkItemPreAtClass(class, TRUE, thisObj, sigObj, mfail)

#define DoDEditSave(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoDEditSaveAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoDEditSaveAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoDEditSaveAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoDEditSaveAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoDEditSaveAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define DoDrawHistory(thisObj, prhObj, mfail) \
        _DoDrawHistoryAtClass(NULL, FALSE, thisObj, prhObj, mfail)
#define DoDrawHistoryAtClass(class, thisObj, prhObj, mfail) \
        _DoDrawHistoryAtClass(class, FALSE, thisObj, prhObj, mfail)
#define DoDrawHistoryAtParent(class, thisObj, prhObj, mfail) \
        _DoDrawHistoryAtClass(class, TRUE, thisObj, prhObj, mfail)

#define DoDrawProcess(thisObj, dialogObj, mfail) \
        _DoDrawProcessAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoDrawProcessAtClass(class, thisObj, dialogObj, mfail) \
        _DoDrawProcessAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoDrawProcessAtParent(class, thisObj, dialogObj, mfail) \
        _DoDrawProcessAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoEditProcess(thisObj, dialogObj, mfail) \
        _DoEditProcessAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoEditProcessAtClass(class, thisObj, dialogObj, mfail) \
        _DoEditProcessAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoEditProcessAtParent(class, thisObj, dialogObj, mfail) \
        _DoEditProcessAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoQueryForItemWorklist(className, itemObj, participant, sql, processSigs, mfail) \
        _DoQueryForItemWorklist(className, FALSE, className, itemObj, participant, sql, processSigs, mfail)
#define DoQueryForItemWorklistAtParent(_class, className, itemObj, participant, sql, processSigs, mfail) \
        _DoQueryForItemWorklist(_class, TRUE, className, itemObj, participant, sql, processSigs, mfail)

#define DoQueryForUserWorklist(className, participant, sql, filterObj, processSigs, workItems, mfail) \
        _DoQueryForUserWorklist(className, FALSE, className, participant, sql, filterObj, processSigs, workItems, mfail)
#define DoQueryForUserWorklistAtParent(_class, className, participant, sql, filterObj, processSigs, workItems, mfail) \
        _DoQueryForUserWorklist(_class, TRUE, className, participant, sql, filterObj, processSigs, workItems, mfail)

#define DoReAssign(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoReAssignAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoReAssignAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoReAssignAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoReAssignAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoReAssignAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define DoReAssign2(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoReAssign2AtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoReAssign2AtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoReAssign2AtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoReAssign2AtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoReAssign2AtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define DoReAssignWorkItemPost(thisObj, sigObj, mfail) \
        _DoReAssignWorkItemPostAtClass(NULL, FALSE, thisObj, sigObj, mfail)
#define DoReAssignWorkItemPostAtClass(class, thisObj, sigObj, mfail) \
        _DoReAssignWorkItemPostAtClass(class, FALSE, thisObj, sigObj, mfail)
#define DoReAssignWorkItemPostAtParent(class, thisObj, sigObj, mfail) \
        _DoReAssignWorkItemPostAtClass(class, TRUE, thisObj, sigObj, mfail)

#define DoReAssignWorkItemPre(thisObj, sigObj, mfail) \
        _DoReAssignWorkItemPreAtClass(NULL, FALSE, thisObj, sigObj, mfail)
#define DoReAssignWorkItemPreAtClass(class, thisObj, sigObj, mfail) \
        _DoReAssignWorkItemPreAtClass(class, FALSE, thisObj, sigObj, mfail)
#define DoReAssignWorkItemPreAtParent(class, thisObj, sigObj, mfail) \
        _DoReAssignWorkItemPreAtClass(class, TRUE, thisObj, sigObj, mfail)

#define DoReplaceUsrForActor(thisObj, processObj, usrObj, newUsr, newUsrObj, mfail) \
        _DoReplaceUsrForActorAtClass(NULL, FALSE, thisObj, processObj, usrObj, newUsr, newUsrObj, mfail)
#define DoReplaceUsrForActorAtClass(class, thisObj, processObj, usrObj, newUsr, newUsrObj, mfail) \
        _DoReplaceUsrForActorAtClass(class, FALSE, thisObj, processObj, usrObj, newUsr, newUsrObj, mfail)
#define DoReplaceUsrForActorAtParent(class, thisObj, processObj, usrObj, newUsr, newUsrObj, mfail) \
        _DoReplaceUsrForActorAtClass(class, TRUE, thisObj, processObj, usrObj, newUsr, newUsrObj, mfail)

#define DoResumeProcHist(thisObj, itemObj, dialogObj, mfail) \
        _DoResumeProcHistAtClass(NULL, FALSE, thisObj, itemObj, dialogObj, mfail)
#define DoResumeProcHistAtClass(class, thisObj, itemObj, dialogObj, mfail) \
        _DoResumeProcHistAtClass(class, FALSE, thisObj, itemObj, dialogObj, mfail)
#define DoResumeProcHistAtParent(class, thisObj, itemObj, dialogObj, mfail) \
        _DoResumeProcHistAtClass(class, TRUE, thisObj, itemObj, dialogObj, mfail)

#define DoResumeProcHistPost(thisObj, itemObj, dialogObj, mfail) \
        _DoResumeProcHistPostAtClass(NULL, FALSE, thisObj, itemObj, dialogObj, mfail)
#define DoResumeProcHistPostAtClass(class, thisObj, itemObj, dialogObj, mfail) \
        _DoResumeProcHistPostAtClass(class, FALSE, thisObj, itemObj, dialogObj, mfail)
#define DoResumeProcHistPostAtParent(class, thisObj, itemObj, dialogObj, mfail) \
        _DoResumeProcHistPostAtClass(class, TRUE, thisObj, itemObj, dialogObj, mfail)

#define DoResumeProcHistPre(thisObj, itemObj, dialogObj, mfail) \
        _DoResumeProcHistPreAtClass(NULL, FALSE, thisObj, itemObj, dialogObj, mfail)
#define DoResumeProcHistPreAtClass(class, thisObj, itemObj, dialogObj, mfail) \
        _DoResumeProcHistPreAtClass(class, FALSE, thisObj, itemObj, dialogObj, mfail)
#define DoResumeProcHistPreAtParent(class, thisObj, itemObj, dialogObj, mfail) \
        _DoResumeProcHistPreAtClass(class, TRUE, thisObj, itemObj, dialogObj, mfail)

#define DoResumeWorkItemPost(thisObj, dialogObj, mfail) \
        _DoResumeWorkItemPostAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoResumeWorkItemPostAtClass(class, thisObj, dialogObj, mfail) \
        _DoResumeWorkItemPostAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoResumeWorkItemPostAtParent(class, thisObj, dialogObj, mfail) \
        _DoResumeWorkItemPostAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoResumeWorkItemPre(thisObj, dialogObj, mfail) \
        _DoResumeWorkItemPreAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoResumeWorkItemPreAtClass(class, thisObj, dialogObj, mfail) \
        _DoResumeWorkItemPreAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoResumeWorkItemPreAtParent(class, thisObj, dialogObj, mfail) \
        _DoResumeWorkItemPreAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoRevListFailCleanup(itemObj, dialogObj, mfail) \
        _DoRevListFailCleanupAtClass(NULL, FALSE, itemObj, dialogObj, mfail)
#define DoRevListFailCleanupAtClass(class, itemObj, dialogObj, mfail) \
        _DoRevListFailCleanupAtClass(class, FALSE, itemObj, dialogObj, mfail)
#define DoRevListFailCleanupAtParent(class, itemObj, dialogObj, mfail) \
        _DoRevListFailCleanupAtClass(class, TRUE, itemObj, dialogObj, mfail)

#define DoRoute(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoRouteAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoRouteAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoRouteAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoRouteAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoRouteAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define DoRouteFailureCleanup(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoRouteFailureCleanupAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoRouteFailureCleanupAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoRouteFailureCleanupAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoRouteFailureCleanupAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoRouteFailureCleanupAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define DoRouteWorkItemPost(thisObj, dialogObj, mfail) \
        _DoRouteWorkItemPostAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoRouteWorkItemPostAtClass(class, thisObj, dialogObj, mfail) \
        _DoRouteWorkItemPostAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoRouteWorkItemPostAtParent(class, thisObj, dialogObj, mfail) \
        _DoRouteWorkItemPostAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoRouteWorkItemPre(thisObj, dialogObj, mfail) \
        _DoRouteWorkItemPreAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoRouteWorkItemPreAtClass(class, thisObj, dialogObj, mfail) \
        _DoRouteWorkItemPreAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoRouteWorkItemPreAtParent(class, thisObj, dialogObj, mfail) \
        _DoRouteWorkItemPreAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoShowHistory(thisObj, dialogObj, expansion, mfail) \
        _DoShowHistoryAtClass(NULL, FALSE, thisObj, dialogObj, expansion, mfail)
#define DoShowHistoryAtClass(class, thisObj, dialogObj, expansion, mfail) \
        _DoShowHistoryAtClass(class, FALSE, thisObj, dialogObj, expansion, mfail)
#define DoShowHistoryAtParent(class, thisObj, dialogObj, expansion, mfail) \
        _DoShowHistoryAtClass(class, TRUE, thisObj, dialogObj, expansion, mfail)

#define DoSigAction(thisObj, itemObj, dialogObj, advEvent, notifEvent, extraStr, extraObj, mfail) \
        _DoSigActionAtClass(NULL, FALSE, thisObj, itemObj, dialogObj, advEvent, notifEvent, extraStr, extraObj, mfail)
#define DoSigActionAtClass(class, thisObj, itemObj, dialogObj, advEvent, notifEvent, extraStr, extraObj, mfail) \
        _DoSigActionAtClass(class, FALSE, thisObj, itemObj, dialogObj, advEvent, notifEvent, extraStr, extraObj, mfail)
#define DoSigActionAtParent(class, thisObj, itemObj, dialogObj, advEvent, notifEvent, extraStr, extraObj, mfail) \
        _DoSigActionAtClass(class, TRUE, thisObj, itemObj, dialogObj, advEvent, notifEvent, extraStr, extraObj, mfail)

#define DoSignoffWorkItemPost(thisObj, sigObj, mfail) \
        _DoSignoffWorkItemPostAtClass(NULL, FALSE, thisObj, sigObj, mfail)
#define DoSignoffWorkItemPostAtClass(class, thisObj, sigObj, mfail) \
        _DoSignoffWorkItemPostAtClass(class, FALSE, thisObj, sigObj, mfail)
#define DoSignoffWorkItemPostAtParent(class, thisObj, sigObj, mfail) \
        _DoSignoffWorkItemPostAtClass(class, TRUE, thisObj, sigObj, mfail)

#define DoSignoffWorkItemPre(thisObj, sigObj, mfail) \
        _DoSignoffWorkItemPreAtClass(NULL, FALSE, thisObj, sigObj, mfail)
#define DoSignoffWorkItemPreAtClass(class, thisObj, sigObj, mfail) \
        _DoSignoffWorkItemPreAtClass(class, FALSE, thisObj, sigObj, mfail)
#define DoSignoffWorkItemPreAtParent(class, thisObj, sigObj, mfail) \
        _DoSignoffWorkItemPreAtClass(class, TRUE, thisObj, sigObj, mfail)

#define DoSubmit(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoSubmitAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoSubmitAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoSubmitAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoSubmitAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoSubmitAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define DoSubmitFailureCleanup(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoSubmitFailureCleanupAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoSubmitFailureCleanupAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoSubmitFailureCleanupAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoSubmitFailureCleanupAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoSubmitFailureCleanupAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define DoSubmitItemSync(thisObj, dialogObj, lcObj, mfail) \
        _DoSubmitItemSyncAtClass(NULL, FALSE, thisObj, dialogObj, lcObj, mfail)
#define DoSubmitItemSyncAtClass(class, thisObj, dialogObj, lcObj, mfail) \
        _DoSubmitItemSyncAtClass(class, FALSE, thisObj, dialogObj, lcObj, mfail)
#define DoSubmitItemSyncAtParent(class, thisObj, dialogObj, lcObj, mfail) \
        _DoSubmitItemSyncAtClass(class, TRUE, thisObj, dialogObj, lcObj, mfail)

#define DoSubmitWorkItemPost(thisObj, dialogObj, mfail) \
        _DoSubmitWorkItemPostAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoSubmitWorkItemPostAtClass(class, thisObj, dialogObj, mfail) \
        _DoSubmitWorkItemPostAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoSubmitWorkItemPostAtParent(class, thisObj, dialogObj, mfail) \
        _DoSubmitWorkItemPostAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoSubmitWorkItemPre(thisObj, dialogObj, mfail) \
        _DoSubmitWorkItemPreAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoSubmitWorkItemPreAtClass(class, thisObj, dialogObj, mfail) \
        _DoSubmitWorkItemPreAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoSubmitWorkItemPreAtParent(class, thisObj, dialogObj, mfail) \
        _DoSubmitWorkItemPreAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoSubmitWorkItemPreInt(thisObj, dialogObj, mfail) \
        _DoSubmitWorkItemPreIntAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoSubmitWorkItemPreIntAtClass(class, thisObj, dialogObj, mfail) \
        _DoSubmitWorkItemPreIntAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoSubmitWorkItemPreIntAtParent(class, thisObj, dialogObj, mfail) \
        _DoSubmitWorkItemPreIntAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoTaskWorkListQuery(taskObject, workListFilterObj, sql, processSigs, workItems, mfail) \
        _DoTaskWorkListQueryAtClass(NULL, FALSE, taskObject, workListFilterObj, sql, processSigs, workItems, mfail)
#define DoTaskWorkListQueryAtClass(class, taskObject, workListFilterObj, sql, processSigs, workItems, mfail) \
        _DoTaskWorkListQueryAtClass(class, FALSE, taskObject, workListFilterObj, sql, processSigs, workItems, mfail)
#define DoTaskWorkListQueryAtParent(class, taskObject, workListFilterObj, sql, processSigs, workItems, mfail) \
        _DoTaskWorkListQueryAtClass(class, TRUE, taskObject, workListFilterObj, sql, processSigs, workItems, mfail)

#define DoUnclaimAsgment(thisObj, itemObj, mfail) \
        _DoUnclaimAsgmentAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define DoUnclaimAsgmentAtClass(class, thisObj, itemObj, mfail) \
        _DoUnclaimAsgmentAtClass(class, FALSE, thisObj, itemObj, mfail)
#define DoUnclaimAsgmentAtParent(class, thisObj, itemObj, mfail) \
        _DoUnclaimAsgmentAtClass(class, TRUE, thisObj, itemObj, mfail)

#define DoUnclaimAssignPost(thisObj, itemObj, mfail) \
        _DoUnclaimAssignPostAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define DoUnclaimAssignPostAtClass(class, thisObj, itemObj, mfail) \
        _DoUnclaimAssignPostAtClass(class, FALSE, thisObj, itemObj, mfail)
#define DoUnclaimAssignPostAtParent(class, thisObj, itemObj, mfail) \
        _DoUnclaimAssignPostAtClass(class, TRUE, thisObj, itemObj, mfail)

#define DoUnclaimAssignPostInt(thisObj, itemObj, mfail) \
        _DoUnclaimAssignPostIntAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define DoUnclaimAssignPostIntAtClass(class, thisObj, itemObj, mfail) \
        _DoUnclaimAssignPostIntAtClass(class, FALSE, thisObj, itemObj, mfail)
#define DoUnclaimAssignPostIntAtParent(class, thisObj, itemObj, mfail) \
        _DoUnclaimAssignPostIntAtClass(class, TRUE, thisObj, itemObj, mfail)

#define DoUnclaimAssignPre(thisObj, itemObj, mfail) \
        _DoUnclaimAssignPreAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define DoUnclaimAssignPreAtClass(class, thisObj, itemObj, mfail) \
        _DoUnclaimAssignPreAtClass(class, FALSE, thisObj, itemObj, mfail)
#define DoUnclaimAssignPreAtParent(class, thisObj, itemObj, mfail) \
        _DoUnclaimAssignPreAtClass(class, TRUE, thisObj, itemObj, mfail)

#define DoUnclaimWorkItemPost(thisObj, sigObj, mfail) \
        _DoUnclaimWorkItemPostAtClass(NULL, FALSE, thisObj, sigObj, mfail)
#define DoUnclaimWorkItemPostAtClass(class, thisObj, sigObj, mfail) \
        _DoUnclaimWorkItemPostAtClass(class, FALSE, thisObj, sigObj, mfail)
#define DoUnclaimWorkItemPostAtParent(class, thisObj, sigObj, mfail) \
        _DoUnclaimWorkItemPostAtClass(class, TRUE, thisObj, sigObj, mfail)

#define DoUnclaimWorkItemPre(thisObj, sigObj, mfail) \
        _DoUnclaimWorkItemPreAtClass(NULL, FALSE, thisObj, sigObj, mfail)
#define DoUnclaimWorkItemPreAtClass(class, thisObj, sigObj, mfail) \
        _DoUnclaimWorkItemPreAtClass(class, FALSE, thisObj, sigObj, mfail)
#define DoUnclaimWorkItemPreAtParent(class, thisObj, sigObj, mfail) \
        _DoUnclaimWorkItemPreAtClass(class, TRUE, thisObj, sigObj, mfail)

#define DoUnclaimWrkItmPostInt(thisObj, sigObj, mfail) \
        _DoUnclaimWrkItmPostIntAtClass(NULL, FALSE, thisObj, sigObj, mfail)
#define DoUnclaimWrkItmPostIntAtClass(class, thisObj, sigObj, mfail) \
        _DoUnclaimWrkItmPostIntAtClass(class, FALSE, thisObj, sigObj, mfail)
#define DoUnclaimWrkItmPostIntAtParent(class, thisObj, sigObj, mfail) \
        _DoUnclaimWrkItmPostIntAtClass(class, TRUE, thisObj, sigObj, mfail)

#define DoUpdateRevTabs(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoUpdateRevTabsAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoUpdateRevTabsAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoUpdateRevTabsAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoUpdateRevTabsAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoUpdateRevTabsAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define DoViewProcess(thisObj, dialogObj, mfail) \
        _DoViewProcessAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoViewProcessAtClass(class, thisObj, dialogObj, mfail) \
        _DoViewProcessAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoViewProcessAtParent(class, thisObj, dialogObj, mfail) \
        _DoViewProcessAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoWorklistPostProc(taskItem, processSigs, workItems, mfail) \
        _DoWorklistPostProcAtClass(NULL, FALSE, taskItem, processSigs, workItems, mfail)
#define DoWorklistPostProcAtClass(class, taskItem, processSigs, workItems, mfail) \
        _DoWorklistPostProcAtClass(class, FALSE, taskItem, processSigs, workItems, mfail)
#define DoWorklistPostProcAtParent(class, taskItem, processSigs, workItems, mfail) \
        _DoWorklistPostProcAtClass(class, TRUE, taskItem, processSigs, workItems, mfail)

#define DoesProcessUseCalendar(className, calendarName, answer, mfail) \
        _DoesProcessUseCalendar(className, FALSE, className, calendarName, answer, mfail)
#define DoesProcessUseCalendarAtParent(_class, className, calendarName, answer, mfail) \
        _DoesProcessUseCalendar(_class, TRUE, className, calendarName, answer, mfail)

#define DoesUserHaveWorkInProc(className, userToCheck, processObj, hasWork, mfail) \
        _DoesUserHaveWorkInProc(className, FALSE, className, userToCheck, processObj, hasWork, mfail)
#define DoesUserHaveWorkInProcAtParent(_class, className, userToCheck, processObj, hasWork, mfail) \
        _DoesUserHaveWorkInProc(_class, TRUE, className, userToCheck, processObj, hasWork, mfail)

#define DoesWorkflowHaveInst(className, flowObj, stepName, answer, mfail) \
        _DoesWorkflowHaveInst(className, FALSE, className, flowObj, stepName, answer, mfail)
#define DoesWorkflowHaveInstAtParent(_class, className, flowObj, stepName, answer, mfail) \
        _DoesWorkflowHaveInst(_class, TRUE, className, flowObj, stepName, answer, mfail)

#define DrawHistory(thisObj, mfail) \
        _DrawHistoryAtClass(NULL, FALSE, thisObj, mfail)
#define DrawHistoryAtClass(class, thisObj, mfail) \
        _DrawHistoryAtClass(class, FALSE, thisObj, mfail)
#define DrawHistoryAtParent(class, thisObj, mfail) \
        _DrawHistoryAtClass(class, TRUE, thisObj, mfail)

#define DrawProcInstForProcess(className, wilObj, prhObj, mfail) \
        _DrawProcInstForProcess(className, FALSE, className, wilObj, prhObj, mfail)
#define DrawProcInstForProcessAtParent(_class, className, wilObj, prhObj, mfail) \
        _DrawProcInstForProcess(_class, TRUE, className, wilObj, prhObj, mfail)

#define DrawProcessHistory(thisObj, mfail) \
        _DrawProcessHistoryAtClass(NULL, FALSE, thisObj, mfail)
#define DrawProcessHistoryAtClass(class, thisObj, mfail) \
        _DrawProcessHistoryAtClass(class, FALSE, thisObj, mfail)
#define DrawProcessHistoryAtParent(class, thisObj, mfail) \
        _DrawProcessHistoryAtClass(class, TRUE, thisObj, mfail)

#define DrawStepHistory(stepObj, lcObj, mfail) \
        _DrawStepHistoryAtClass(NULL, FALSE, stepObj, lcObj, mfail)
#define DrawStepHistoryAtClass(class, stepObj, lcObj, mfail) \
        _DrawStepHistoryAtClass(class, FALSE, stepObj, lcObj, mfail)
#define DrawStepHistoryAtParent(class, stepObj, lcObj, mfail) \
        _DrawStepHistoryAtClass(class, TRUE, stepObj, lcObj, mfail)

#define EditEffStepProcess(stepObj, lcObj, mfail) \
        _EditEffStepProcessAtClass(NULL, FALSE, stepObj, lcObj, mfail)
#define EditEffStepProcessAtClass(class, stepObj, lcObj, mfail) \
        _EditEffStepProcessAtClass(class, FALSE, stepObj, lcObj, mfail)
#define EditEffStepProcessAtParent(class, stepObj, lcObj, mfail) \
        _EditEffStepProcessAtClass(class, TRUE, stepObj, lcObj, mfail)

#define ExpMLevAllPrcInst(prcInst, prcInstSet, mfail) \
        _ExpMLevAllPrcInstAtClass(NULL, FALSE, prcInst, prcInstSet, mfail)
#define ExpMLevAllPrcInstAtClass(class, prcInst, prcInstSet, mfail) \
        _ExpMLevAllPrcInstAtClass(class, FALSE, prcInst, prcInstSet, mfail)
#define ExpMLevAllPrcInstAtParent(class, prcInst, prcInstSet, mfail) \
        _ExpMLevAllPrcInstAtClass(class, TRUE, prcInst, prcInstSet, mfail)

#define ExpMLevOpenPrcInst(prcInst, prcInstSet, mfail) \
        _ExpMLevOpenPrcInstAtClass(NULL, FALSE, prcInst, prcInstSet, mfail)
#define ExpMLevOpenPrcInstAtClass(class, prcInst, prcInstSet, mfail) \
        _ExpMLevOpenPrcInstAtClass(class, FALSE, prcInst, prcInstSet, mfail)
#define ExpMLevOpenPrcInstAtParent(class, prcInst, prcInstSet, mfail) \
        _ExpMLevOpenPrcInstAtClass(class, TRUE, prcInst, prcInstSet, mfail)

#define ExpMLevPrcInst(prcInst, qryDef, genContextObj, prcInstSet, mfail) \
        _ExpMLevPrcInstAtClass(NULL, FALSE, prcInst, qryDef, genContextObj, prcInstSet, mfail)
#define ExpMLevPrcInstAtClass(class, prcInst, qryDef, genContextObj, prcInstSet, mfail) \
        _ExpMLevPrcInstAtClass(class, FALSE, prcInst, qryDef, genContextObj, prcInstSet, mfail)
#define ExpMLevPrcInstAtParent(class, prcInst, qryDef, genContextObj, prcInstSet, mfail) \
        _ExpMLevPrcInstAtClass(class, TRUE, prcInst, qryDef, genContextObj, prcInstSet, mfail)

#define ExpMultiLevForItemObj(className, object, relationship, dialogObject, otherSideObjSet, relObjSet, genContextObj, recurList, itemObjSet, currentExpandLevel, mfail) \
        _ExpMultiLevForItemObj(className, FALSE, className, object, relationship, dialogObject, otherSideObjSet, relObjSet, genContextObj, recurList, itemObjSet, currentExpandLevel, mfail)
#define ExpMultiLevForItemObjAtParent(_class, className, object, relationship, dialogObject, otherSideObjSet, relObjSet, genContextObj, recurList, itemObjSet, currentExpandLevel, mfail) \
        _ExpMultiLevForItemObj(_class, TRUE, className, object, relationship, dialogObject, otherSideObjSet, relObjSet, genContextObj, recurList, itemObjSet, currentExpandLevel, mfail)

#define ExtQryLCMObjectByOwner(className, sql, expand, owner, object, mfail) \
        _ExtQryLCMObjectByOwner(className, FALSE, className, sql, expand, owner, object, mfail)
#define ExtQryLCMObjectByOwnerAtParent(_class, className, sql, expand, owner, object, mfail) \
        _ExtQryLCMObjectByOwner(_class, TRUE, className, sql, expand, owner, object, mfail)

#define FilterTaskWorkList(taskObject, workListFilterObj, processSigs, workItems, mfail) \
        _FilterTaskWorkListAtClass(NULL, FALSE, taskObject, workListFilterObj, processSigs, workItems, mfail)
#define FilterTaskWorkListAtClass(class, taskObject, workListFilterObj, processSigs, workItems, mfail) \
        _FilterTaskWorkListAtClass(class, FALSE, taskObject, workListFilterObj, processSigs, workItems, mfail)
#define FilterTaskWorkListAtParent(class, taskObject, workListFilterObj, processSigs, workItems, mfail) \
        _FilterTaskWorkListAtClass(class, TRUE, taskObject, workListFilterObj, processSigs, workItems, mfail)

#define FindAllProcActorsExt(className, processObj, processActors, processParticipants, processWorkList, mfail) \
        _FindAllProcActorsExt(className, FALSE, className, processObj, processActors, processParticipants, processWorkList, mfail)
#define FindAllProcActorsExtAtParent(_class, className, processObj, processActors, processParticipants, processWorkList, mfail) \
        _FindAllProcActorsExt(_class, TRUE, className, processObj, processActors, processParticipants, processWorkList, mfail)

#define FindAllProcessActors(className, processObj, processActors, processParticipants, processWorkList, mfail) \
        _FindAllProcessActors(className, FALSE, className, processObj, processActors, processParticipants, processWorkList, mfail)
#define FindAllProcessActorsAtParent(_class, className, processObj, processActors, processParticipants, processWorkList, mfail) \
        _FindAllProcessActors(_class, TRUE, className, processObj, processActors, processParticipants, processWorkList, mfail)

#define FindAllProcessRevs(className, processName, processObjects, mfail) \
        _FindAllProcessRevs(className, FALSE, className, processName, processObjects, mfail)
#define FindAllProcessRevsAtParent(_class, className, processName, processObjects, mfail) \
        _FindAllProcessRevs(_class, TRUE, className, processName, processObjects, mfail)

#define FindAllProcessSigs(className, wrkItemObj, procHistObj, sigObjects, mfail) \
        _FindAllProcessSigs(className, FALSE, className, wrkItemObj, procHistObj, sigObjects, mfail)
#define FindAllProcessSigsAtParent(_class, className, wrkItemObj, procHistObj, sigObjects, mfail) \
        _FindAllProcessSigs(_class, TRUE, className, wrkItemObj, procHistObj, sigObjects, mfail)

#define FindAllReviewersInSeq(className, processObj, sequence, reviewerObjects, mfail) \
        _FindAllReviewersInSeq(className, FALSE, className, processObj, sequence, reviewerObjects, mfail)
#define FindAllReviewersInSeqAtParent(_class, className, processObj, sequence, reviewerObjects, mfail) \
        _FindAllReviewersInSeq(_class, TRUE, className, processObj, sequence, reviewerObjects, mfail)

#define FindAllTopLvlPrcInsts(className, workItem, prcInsts, mfail) \
        _FindAllTopLvlPrcInsts(className, FALSE, className, workItem, prcInsts, mfail)
#define FindAllTopLvlPrcInstsAtParent(_class, className, workItem, prcInsts, mfail) \
        _FindAllTopLvlPrcInsts(_class, TRUE, className, workItem, prcInsts, mfail)

#define FindAllWorkForPrcInsts(className, workItem, procInstSet, workAsgSet, mfail) \
        _FindAllWorkForPrcInsts(className, FALSE, className, workItem, procInstSet, workAsgSet, mfail)
#define FindAllWorkForPrcInstsAtParent(_class, className, workItem, procInstSet, workAsgSet, mfail) \
        _FindAllWorkForPrcInsts(_class, TRUE, className, workItem, procInstSet, workAsgSet, mfail)

#define FindCalendarName(className, calendarName, calendarObj, mfail) \
        _FindCalendarName(className, FALSE, className, calendarName, calendarObj, mfail)
#define FindCalendarNameAtParent(_class, className, calendarName, calendarObj, mfail) \
        _FindCalendarName(_class, TRUE, className, calendarName, calendarObj, mfail)

#define FindEffProcessRev(className, processName, InProduction, Baselined, curProcessObj, mfail) \
        _FindEffProcessRev(className, FALSE, className, processName, InProduction, Baselined, curProcessObj, mfail)
#define FindEffProcessRevAtParent(_class, className, processName, InProduction, Baselined, curProcessObj, mfail) \
        _FindEffProcessRev(_class, TRUE, className, processName, InProduction, Baselined, curProcessObj, mfail)

#define FindEffProcessRevD(className, processName, InProduction, Baselined, curProcessObj, mfail) \
        _FindEffProcessRevD(className, FALSE, className, processName, InProduction, Baselined, curProcessObj, mfail)
#define FindEffProcessRevDAtParent(_class, className, processName, InProduction, Baselined, curProcessObj, mfail) \
        _FindEffProcessRevD(_class, TRUE, className, processName, InProduction, Baselined, curProcessObj, mfail)

#define FindItemObjForWork(thisObj, inflate, wrkItemObj, mfail) \
        _FindItemObjForWorkAtClass(NULL, FALSE, thisObj, inflate, wrkItemObj, mfail)
#define FindItemObjForWorkAtClass(class, thisObj, inflate, wrkItemObj, mfail) \
        _FindItemObjForWorkAtClass(class, FALSE, thisObj, inflate, wrkItemObj, mfail)
#define FindItemObjForWorkAtParent(class, thisObj, inflate, wrkItemObj, mfail) \
        _FindItemObjForWorkAtClass(class, TRUE, thisObj, inflate, wrkItemObj, mfail)

#define FindLatestEffProcess(className, processName, curProcessObj, mfail) \
        _FindLatestEffProcess(className, FALSE, className, processName, curProcessObj, mfail)
#define FindLatestEffProcessAtParent(_class, className, processName, curProcessObj, mfail) \
        _FindLatestEffProcess(_class, TRUE, className, processName, curProcessObj, mfail)

#define FindLowestLvlPrcInsts(className, wilObj, lowestLvlInsts, mfail) \
        _FindLowestLvlPrcInsts(className, FALSE, className, wilObj, lowestLvlInsts, mfail)
#define FindLowestLvlPrcInstsAtParent(_class, className, wilObj, lowestLvlInsts, mfail) \
        _FindLowestLvlPrcInsts(_class, TRUE, className, wilObj, lowestLvlInsts, mfail)

#define FindOneProcessRev(className, processName, processRev, processVersion, processSeq, curProcessObj, mfail) \
        _FindOneProcessRev(className, FALSE, className, processName, processRev, processVersion, processSeq, curProcessObj, mfail)
#define FindOneProcessRevAtParent(_class, className, processName, processRev, processVersion, processSeq, curProcessObj, mfail) \
        _FindOneProcessRev(_class, TRUE, className, processName, processRev, processVersion, processSeq, curProcessObj, mfail)

#define FindOneProcessRevD(className, processName, processRev, processVersion, processSeq, curProcessObj, mfail) \
        _FindOneProcessRevD(className, FALSE, className, processName, processRev, processVersion, processSeq, curProcessObj, mfail)
#define FindOneProcessRevDAtParent(_class, className, processName, processRev, processVersion, processSeq, curProcessObj, mfail) \
        _FindOneProcessRevD(_class, TRUE, className, processName, processRev, processVersion, processSeq, curProcessObj, mfail)

#define FindOpenPrcInst(className, thisObj, prcInstSet, mfail) \
        _FindOpenPrcInst(className, FALSE, className, thisObj, prcInstSet, mfail)
#define FindOpenPrcInstAtParent(_class, className, thisObj, prcInstSet, mfail) \
        _FindOpenPrcInst(_class, TRUE, className, thisObj, prcInstSet, mfail)

#define FindOpenProcessSigs(className, wrkItemObj, procHistObj, sigObjects, mfail) \
        _FindOpenProcessSigs(className, FALSE, className, wrkItemObj, procHistObj, sigObjects, mfail)
#define FindOpenProcessSigsAtParent(_class, className, wrkItemObj, procHistObj, sigObjects, mfail) \
        _FindOpenProcessSigs(_class, TRUE, className, wrkItemObj, procHistObj, sigObjects, mfail)

#define FindOpenRLPrcInst(className, wilObj, prcInst, mfail) \
        _FindOpenRLPrcInst(className, FALSE, className, wilObj, prcInst, mfail)
#define FindOpenRLPrcInstAtParent(_class, className, wilObj, prcInst, mfail) \
        _FindOpenRLPrcInst(_class, TRUE, className, wilObj, prcInst, mfail)

#define FindOpenSigMsgGroups(className, wrkItemObj, procHistObj, curUserList, msgGroupList, mfail) \
        _FindOpenSigMsgGroups(className, FALSE, className, wrkItemObj, procHistObj, curUserList, msgGroupList, mfail)
#define FindOpenSigMsgGroupsAtParent(_class, className, wrkItemObj, procHistObj, curUserList, msgGroupList, mfail) \
        _FindOpenSigMsgGroups(_class, TRUE, className, wrkItemObj, procHistObj, curUserList, msgGroupList, mfail)

#define FindParentPrcInst(thisObj, prcInst, mfail) \
        _FindParentPrcInstAtClass(NULL, FALSE, thisObj, prcInst, mfail)
#define FindParentPrcInstAtClass(class, thisObj, prcInst, mfail) \
        _FindParentPrcInstAtClass(class, FALSE, thisObj, prcInst, mfail)
#define FindParentPrcInstAtParent(class, thisObj, prcInst, mfail) \
        _FindParentPrcInstAtClass(class, TRUE, thisObj, prcInst, mfail)

#define FindProcHistForWork(thisObj, procHistObj, mfail) \
        _FindProcHistForWorkAtClass(NULL, FALSE, thisObj, procHistObj, mfail)
#define FindProcHistForWorkAtClass(class, thisObj, procHistObj, mfail) \
        _FindProcHistForWorkAtClass(class, FALSE, thisObj, procHistObj, mfail)
#define FindProcHistForWorkAtParent(class, thisObj, procHistObj, mfail) \
        _FindProcHistForWorkAtClass(class, TRUE, thisObj, procHistObj, mfail)

#define FindProcessObjForActor(thisObj, inflate, processObj, mfail) \
        _FindProcessObjForActorAtClass(NULL, FALSE, thisObj, inflate, processObj, mfail)
#define FindProcessObjForActorAtClass(class, thisObj, inflate, processObj, mfail) \
        _FindProcessObjForActorAtClass(class, FALSE, thisObj, inflate, processObj, mfail)
#define FindProcessObjForActorAtParent(class, thisObj, inflate, processObj, mfail) \
        _FindProcessObjForActorAtClass(class, TRUE, thisObj, inflate, processObj, mfail)

#define FindProcsForPrcInsts(className, prcInstSet, processSet, mfail) \
        _FindProcsForPrcInsts(className, FALSE, className, prcInstSet, processSet, mfail)
#define FindProcsForPrcInstsAtParent(_class, className, prcInstSet, processSet, mfail) \
        _FindProcsForPrcInsts(_class, TRUE, className, prcInstSet, processSet, mfail)

#define FindRelatedRLstPrcInst(thisObj, itemObj, prcInstSet, mfail) \
        _FindRelatedRLstPrcInstAtClass(NULL, FALSE, thisObj, itemObj, prcInstSet, mfail)
#define FindRelatedRLstPrcInstAtClass(class, thisObj, itemObj, prcInstSet, mfail) \
        _FindRelatedRLstPrcInstAtClass(class, FALSE, thisObj, itemObj, prcInstSet, mfail)
#define FindRelatedRLstPrcInstAtParent(class, thisObj, itemObj, prcInstSet, mfail) \
        _FindRelatedRLstPrcInstAtClass(class, TRUE, thisObj, itemObj, prcInstSet, mfail)

#define FindTopLvlPrcInst(className, wilObj, prcInst, mfail) \
        _FindTopLvlPrcInst(className, FALSE, className, wilObj, prcInst, mfail)
#define FindTopLvlPrcInstAtParent(_class, className, wilObj, prcInst, mfail) \
        _FindTopLvlPrcInst(_class, TRUE, className, wilObj, prcInst, mfail)

#define FindWorkItemForWorkExt(sigObj, workItem, mfail) \
        _FindWorkItemForWorkExtAtClass(NULL, FALSE, sigObj, workItem, mfail)
#define FindWorkItemForWorkExtAtClass(class, sigObj, workItem, mfail) \
        _FindWorkItemForWorkExtAtClass(class, FALSE, sigObj, workItem, mfail)
#define FindWorkItemForWorkExtAtParent(class, sigObj, workItem, mfail) \
        _FindWorkItemForWorkExtAtClass(class, TRUE, sigObj, workItem, mfail)

#define GenAdHocData(className, workItem, lcObj, adhcDataObj, mfail) \
        _GenAdHocData(className, FALSE, className, workItem, lcObj, adhcDataObj, mfail)
#define GenAdHocDataAtParent(_class, className, workItem, lcObj, adhcDataObj, mfail) \
        _GenAdHocData(_class, TRUE, className, workItem, lcObj, adhcDataObj, mfail)

#define GenMultiSelAssignment(className, selectedRels, selectedItems, msgOptionTag, mfail) \
        _GenMultiSelAssignment(className, FALSE, className, selectedRels, selectedItems, msgOptionTag, mfail)
#define GenMultiSelAssignmentAtParent(_class, className, selectedRels, selectedItems, msgOptionTag, mfail) \
        _GenMultiSelAssignment(_class, TRUE, className, selectedRels, selectedItems, msgOptionTag, mfail)

#define GenerateProcessSigs(className, effProcessObj, workItem, processHistory, addtlActors, signatureObjects, mfail) \
        _GenerateProcessSigs(className, FALSE, className, effProcessObj, workItem, processHistory, addtlActors, signatureObjects, mfail)
#define GenerateProcessSigsAtParent(_class, className, effProcessObj, workItem, processHistory, addtlActors, signatureObjects, mfail) \
        _GenerateProcessSigs(_class, TRUE, className, effProcessObj, workItem, processHistory, addtlActors, signatureObjects, mfail)

#define GetAdHcDataOfWorkItem(workItem, adhcDataObj, mfail) \
        _GetAdHcDataOfWorkItemAtClass(NULL, FALSE, workItem, adhcDataObj, mfail)
#define GetAdHcDataOfWorkItemAtClass(class, workItem, adhcDataObj, mfail) \
        _GetAdHcDataOfWorkItemAtClass(class, FALSE, workItem, adhcDataObj, mfail)
#define GetAdHcDataOfWorkItemAtParent(class, workItem, adhcDataObj, mfail) \
        _GetAdHcDataOfWorkItemAtClass(class, TRUE, workItem, adhcDataObj, mfail)

#define GetAllProcessBranches(className, processObj, branchObjs, mfail) \
        _GetAllProcessBranches(className, FALSE, className, processObj, branchObjs, mfail)
#define GetAllProcessBranchesAtParent(_class, className, processObj, branchObjs, mfail) \
        _GetAllProcessBranches(_class, TRUE, className, processObj, branchObjs, mfail)

#define GetAllStepsForProcess(className, flowObj, stepObjs, mfail) \
        _GetAllStepsForProcess(className, FALSE, className, flowObj, stepObjs, mfail)
#define GetAllStepsForProcessAtParent(_class, className, flowObj, stepObjs, mfail) \
        _GetAllStepsForProcess(_class, TRUE, className, flowObj, stepObjs, mfail)

#define GetAllWorkflows(className, flowObjs, mfail) \
        _GetAllWorkflows(className, FALSE, className, flowObjs, mfail)
#define GetAllWorkflowsAtParent(_class, className, flowObjs, mfail) \
        _GetAllWorkflows(_class, TRUE, className, flowObjs, mfail)

#define GetAltUserNotOof(className, currentUser, altUser, mfail) \
        _GetAltUserNotOof(className, FALSE, className, currentUser, altUser, mfail)
#define GetAltUserNotOofAtParent(_class, className, currentUser, altUser, mfail) \
        _GetAltUserNotOof(_class, TRUE, className, currentUser, altUser, mfail)

#define GetBranchesForWorkflow(className, workflowName, branchObjs, mfail) \
        _GetBranchesForWorkflow(className, FALSE, className, workflowName, branchObjs, mfail)
#define GetBranchesForWorkflowAtParent(_class, className, workflowName, branchObjs, mfail) \
        _GetBranchesForWorkflow(_class, TRUE, className, workflowName, branchObjs, mfail)

#define GetCreateRevList(dialogObj, destClassName, objects, mfail) \
        _GetCreateRevListAtClass(NULL, FALSE, dialogObj, destClassName, objects, mfail)
#define GetCreateRevListAtClass(class, dialogObj, destClassName, objects, mfail) \
        _GetCreateRevListAtClass(class, FALSE, dialogObj, destClassName, objects, mfail)
#define GetCreateRevListAtParent(class, dialogObj, destClassName, objects, mfail) \
        _GetCreateRevListAtClass(class, TRUE, dialogObj, destClassName, objects, mfail)

#define GetCurrentRevListSet(itemObj, objects, mfail) \
        _GetCurrentRevListSetAtClass(NULL, FALSE, itemObj, objects, mfail)
#define GetCurrentRevListSetAtClass(class, itemObj, objects, mfail) \
        _GetCurrentRevListSetAtClass(class, FALSE, itemObj, objects, mfail)
#define GetCurrentRevListSetAtParent(class, itemObj, objects, mfail) \
        _GetCurrentRevListSetAtClass(class, TRUE, itemObj, objects, mfail)

#define GetDiagramAttributes(className, objSet, mfail) \
        _GetDiagramAttributes(className, FALSE, className, objSet, mfail)
#define GetDiagramAttributesAtParent(_class, className, objSet, mfail) \
        _GetDiagramAttributes(_class, TRUE, className, objSet, mfail)

#define GetEffProcesses(className, effFrom, effTo, prcObjSet, mfail) \
        _GetEffProcesses(className, FALSE, className, effFrom, effTo, prcObjSet, mfail)
#define GetEffProcessesAtParent(_class, className, effFrom, effTo, prcObjSet, mfail) \
        _GetEffProcesses(_class, TRUE, className, effFrom, effTo, prcObjSet, mfail)

#define GetExpireActnsForDialg(className, thisObj, dialogObj, mfail) \
        _GetExpireActnsForDialg(className, FALSE, className, thisObj, dialogObj, mfail)
#define GetExpireActnsForDialgAtParent(_class, className, thisObj, dialogObj, mfail) \
        _GetExpireActnsForDialg(_class, TRUE, className, thisObj, dialogObj, mfail)

#define GetFilterForWrkLstType(worklistClassName, worklistType, worklistFilterObj, mfail) \
        _GetFilterForWrkLstType(worklistClassName, FALSE, worklistClassName, worklistType, worklistFilterObj, mfail)
#define GetFilterForWrkLstTypeAtParent(_class, worklistClassName, worklistType, worklistFilterObj, mfail) \
        _GetFilterForWrkLstType(_class, TRUE, worklistClassName, worklistType, worklistFilterObj, mfail)

#define GetFlowObjFromNameInt(className, flowName, flowObject, mfail) \
        _GetFlowObjFromNameInt(className, FALSE, className, flowName, flowObject, mfail)
#define GetFlowObjFromNameIntAtParent(_class, className, flowName, flowObject, mfail) \
        _GetFlowObjFromNameInt(_class, TRUE, className, flowName, flowObject, mfail)

#define GetInfoActStepProcess(stepObj, lcObj, mfail) \
        _GetInfoActStepProcessAtClass(NULL, FALSE, stepObj, lcObj, mfail)
#define GetInfoActStepProcessAtClass(class, stepObj, lcObj, mfail) \
        _GetInfoActStepProcessAtClass(class, FALSE, stepObj, lcObj, mfail)
#define GetInfoActStepProcessAtParent(class, stepObj, lcObj, mfail) \
        _GetInfoActStepProcessAtClass(class, TRUE, stepObj, lcObj, mfail)

#define GetInfoEffStepProcess(stepObj, lcObj, mfail) \
        _GetInfoEffStepProcessAtClass(NULL, FALSE, stepObj, lcObj, mfail)
#define GetInfoEffStepProcessAtClass(class, stepObj, lcObj, mfail) \
        _GetInfoEffStepProcessAtClass(class, FALSE, stepObj, lcObj, mfail)
#define GetInfoEffStepProcessAtParent(class, stepObj, lcObj, mfail) \
        _GetInfoEffStepProcessAtClass(class, TRUE, stepObj, lcObj, mfail)

#define GetItemSignoffHistory(workItem, procHistObj, sigObjectSet, mfail) \
        _GetItemSignoffHistoryAtClass(NULL, FALSE, workItem, procHistObj, sigObjectSet, mfail)
#define GetItemSignoffHistoryAtClass(class, workItem, procHistObj, sigObjectSet, mfail) \
        _GetItemSignoffHistoryAtClass(class, FALSE, workItem, procHistObj, sigObjectSet, mfail)
#define GetItemSignoffHistoryAtParent(class, workItem, procHistObj, sigObjectSet, mfail) \
        _GetItemSignoffHistoryAtClass(class, TRUE, workItem, procHistObj, sigObjectSet, mfail)

#define GetLCMWlbParams(className, tagName, usrName, sql, brNames, mfail) \
        _GetLCMWlbParams(className, FALSE, className, tagName, usrName, sql, brNames, mfail)
#define GetLCMWlbParamsAtParent(_class, className, tagName, usrName, sql, brNames, mfail) \
        _GetLCMWlbParams(_class, TRUE, className, tagName, usrName, sql, brNames, mfail)

#define GetLCObjectFromLCName(className, lifeCycleName, lcObject, mfail) \
        _GetLCObjectFromLCName(className, FALSE, className, lifeCycleName, lcObject, mfail)
#define GetLCObjectFromLCNameAtParent(_class, className, lifeCycleName, lcObject, mfail) \
        _GetLCObjectFromLCName(_class, TRUE, className, lifeCycleName, lcObject, mfail)

#define GetLegalActorMsgGrps(thisObj, msgGrpObjs, values, mfail) \
        _GetLegalActorMsgGrpsAtClass(NULL, FALSE, thisObj, msgGrpObjs, values, mfail)
#define GetLegalActorMsgGrpsAtClass(class, thisObj, msgGrpObjs, values, mfail) \
        _GetLegalActorMsgGrpsAtClass(class, FALSE, thisObj, msgGrpObjs, values, mfail)
#define GetLegalActorMsgGrpsAtParent(class, thisObj, msgGrpObjs, values, mfail) \
        _GetLegalActorMsgGrpsAtClass(class, TRUE, thisObj, msgGrpObjs, values, mfail)

#define GetLegalWorkflows(thisObj, originObject, extraStr, extraObj, values, mfail) \
        _GetLegalWorkflowsAtClass(NULL, FALSE, thisObj, originObject, extraStr, extraObj, values, mfail)
#define GetLegalWorkflowsAtClass(class, thisObj, originObject, extraStr, extraObj, values, mfail) \
        _GetLegalWorkflowsAtClass(class, FALSE, thisObj, originObject, extraStr, extraObj, values, mfail)
#define GetLegalWorkflowsAtParent(class, thisObj, originObject, extraStr, extraObj, values, mfail) \
        _GetLegalWorkflowsAtClass(class, TRUE, thisObj, originObject, extraStr, extraObj, values, mfail)

#define GetParticipSideOfActor(className, side, mfail) \
        _GetParticipSideOfActor(className, FALSE, className, side, mfail)
#define GetParticipSideOfActorAtParent(_class, className, side, mfail) \
        _GetParticipSideOfActor(_class, TRUE, className, side, mfail)

#define GetParticipsForProcess(processObj, actorObj, participantObj, itemObj, procHistObj, userObjs, mfail) \
        _GetParticipsForProcessAtClass(NULL, FALSE, processObj, actorObj, participantObj, itemObj, procHistObj, userObjs, mfail)
#define GetParticipsForProcessAtClass(class, processObj, actorObj, participantObj, itemObj, procHistObj, userObjs, mfail) \
        _GetParticipsForProcessAtClass(class, FALSE, processObj, actorObj, participantObj, itemObj, procHistObj, userObjs, mfail)
#define GetParticipsForProcessAtParent(class, processObj, actorObj, participantObj, itemObj, procHistObj, userObjs, mfail) \
        _GetParticipsForProcessAtClass(class, TRUE, processObj, actorObj, participantObj, itemObj, procHistObj, userObjs, mfail)

#define GetPrcUsrsFromProcHist(procHistObj, itemObj, participant, userObjSet, mfail) \
        _GetPrcUsrsFromProcHistAtClass(NULL, FALSE, procHistObj, itemObj, participant, userObjSet, mfail)
#define GetPrcUsrsFromProcHistAtClass(class, procHistObj, itemObj, participant, userObjSet, mfail) \
        _GetPrcUsrsFromProcHistAtClass(class, FALSE, procHistObj, itemObj, participant, userObjSet, mfail)
#define GetPrcUsrsFromProcHistAtParent(class, procHistObj, itemObj, participant, userObjSet, mfail) \
        _GetPrcUsrsFromProcHistAtClass(class, TRUE, procHistObj, itemObj, participant, userObjSet, mfail)

#define GetPrhOfSameLvlAndStep(prhObj, itemObj, prhObjSet, mfail) \
        _GetPrhOfSameLvlAndStepAtClass(NULL, FALSE, prhObj, itemObj, prhObjSet, mfail)
#define GetPrhOfSameLvlAndStepAtClass(class, prhObj, itemObj, prhObjSet, mfail) \
        _GetPrhOfSameLvlAndStepAtClass(class, FALSE, prhObj, itemObj, prhObjSet, mfail)
#define GetPrhOfSameLvlAndStepAtParent(class, prhObj, itemObj, prhObjSet, mfail) \
        _GetPrhOfSameLvlAndStepAtClass(class, TRUE, prhObj, itemObj, prhObjSet, mfail)

#define GetProcFromProcInst(prhObj, procObj, mfail) \
        _GetProcFromProcInstAtClass(NULL, FALSE, prhObj, procObj, mfail)
#define GetProcFromProcInstAtClass(class, prhObj, procObj, mfail) \
        _GetProcFromProcInstAtClass(class, FALSE, prhObj, procObj, mfail)
#define GetProcFromProcInstAtParent(class, prhObj, procObj, mfail) \
        _GetProcFromProcInstAtClass(class, TRUE, prhObj, procObj, mfail)

#define GetProcFromProcInstD(prhObj, procObj, mfail) \
        _GetProcFromProcInstDAtClass(NULL, FALSE, prhObj, procObj, mfail)
#define GetProcFromProcInstDAtClass(class, prhObj, procObj, mfail) \
        _GetProcFromProcInstDAtClass(class, FALSE, prhObj, procObj, mfail)
#define GetProcFromProcInstDAtParent(class, prhObj, procObj, mfail) \
        _GetProcFromProcInstDAtClass(class, TRUE, prhObj, procObj, mfail)

#define GetProcHistForLevel(className, itemObj, prhObj, prhObjSet, mfail) \
        _GetProcHistForLevel(className, FALSE, className, itemObj, prhObj, prhObjSet, mfail)
#define GetProcHistForLevelAtParent(_class, className, itemObj, prhObj, prhObjSet, mfail) \
        _GetProcHistForLevel(_class, TRUE, className, itemObj, prhObj, prhObjSet, mfail)

#define GetProcHistForLevelExt(className, itemObj, prhObj, prhObjSet, mfail) \
        _GetProcHistForLevelExt(className, FALSE, className, itemObj, prhObj, prhObjSet, mfail)
#define GetProcHistForLevelExtAtParent(_class, className, itemObj, prhObj, prhObjSet, mfail) \
        _GetProcHistForLevelExt(_class, TRUE, className, itemObj, prhObj, prhObjSet, mfail)

#define GetProcHistForProcess(className, processObj, prhObjSet, mfail) \
        _GetProcHistForProcess(className, FALSE, className, processObj, prhObjSet, mfail)
#define GetProcHistForProcessAtParent(_class, className, processObj, prhObjSet, mfail) \
        _GetProcHistForProcess(_class, TRUE, className, processObj, prhObjSet, mfail)

#define GetProcHistToDraw(processObj, drawDialogObj, procHistObjSet, mfail) \
        _GetProcHistToDrawAtClass(NULL, FALSE, processObj, drawDialogObj, procHistObjSet, mfail)
#define GetProcHistToDrawAtClass(class, processObj, drawDialogObj, procHistObjSet, mfail) \
        _GetProcHistToDrawAtClass(class, FALSE, processObj, drawDialogObj, procHistObjSet, mfail)
#define GetProcHistToDrawAtParent(class, processObj, drawDialogObj, procHistObjSet, mfail) \
        _GetProcHistToDrawAtClass(class, TRUE, processObj, drawDialogObj, procHistObjSet, mfail)

#define GetProcInstForWorkflow(className, flowObj, stepName, prhObjSet, mfail) \
        _GetProcInstForWorkflow(className, FALSE, className, flowObj, stepName, prhObjSet, mfail)
#define GetProcInstForWorkflowAtParent(_class, className, flowObj, stepName, prhObjSet, mfail) \
        _GetProcInstForWorkflow(_class, TRUE, className, flowObj, stepName, prhObjSet, mfail)

#define GetProcessActors(processObj, itemObj, procActorObjs, participantObjs, mfail) \
        _GetProcessActorsAtClass(NULL, FALSE, processObj, itemObj, procActorObjs, participantObjs, mfail)
#define GetProcessActorsAtClass(class, processObj, itemObj, procActorObjs, participantObjs, mfail) \
        _GetProcessActorsAtClass(class, FALSE, processObj, itemObj, procActorObjs, participantObjs, mfail)
#define GetProcessActorsAtParent(class, processObj, itemObj, procActorObjs, participantObjs, mfail) \
        _GetProcessActorsAtClass(class, TRUE, processObj, itemObj, procActorObjs, participantObjs, mfail)

#define GetProcessForStep(stepObj, itemObj, procHistObj, processObj, mfail) \
        _GetProcessForStepAtClass(NULL, FALSE, stepObj, itemObj, procHistObj, processObj, mfail)
#define GetProcessForStepAtClass(class, stepObj, itemObj, procHistObj, processObj, mfail) \
        _GetProcessForStepAtClass(class, FALSE, stepObj, itemObj, procHistObj, processObj, mfail)
#define GetProcessForStepAtParent(class, stepObj, itemObj, procHistObj, processObj, mfail) \
        _GetProcessForStepAtClass(class, TRUE, stepObj, itemObj, procHistObj, processObj, mfail)

#define GetProcessForStepInt(stepObj, itemObj, procHistObj, processObj, mfail) \
        _GetProcessForStepIntAtClass(NULL, FALSE, stepObj, itemObj, procHistObj, processObj, mfail)
#define GetProcessForStepIntAtClass(class, stepObj, itemObj, procHistObj, processObj, mfail) \
        _GetProcessForStepIntAtClass(class, FALSE, stepObj, itemObj, procHistObj, processObj, mfail)
#define GetProcessForStepIntAtParent(class, stepObj, itemObj, procHistObj, processObj, mfail) \
        _GetProcessForStepIntAtClass(class, TRUE, stepObj, itemObj, procHistObj, processObj, mfail)

#define GetProcessSecurity(thisObj, processSecurity, mfail) \
        _GetProcessSecurityAtClass(NULL, FALSE, thisObj, processSecurity, mfail)
#define GetProcessSecurityAtClass(class, thisObj, processSecurity, mfail) \
        _GetProcessSecurityAtClass(class, FALSE, thisObj, processSecurity, mfail)
#define GetProcessSecurityAtParent(class, thisObj, processSecurity, mfail) \
        _GetProcessSecurityAtClass(class, TRUE, thisObj, processSecurity, mfail)

#define GetRoleGrpUsers(itemObj, roleName, roleMembers, numMembers, mfail) \
        _GetRoleGrpUsersAtClass(NULL, FALSE, itemObj, roleName, roleMembers, numMembers, mfail)
#define GetRoleGrpUsersAtClass(class, itemObj, roleName, roleMembers, numMembers, mfail) \
        _GetRoleGrpUsersAtClass(class, FALSE, itemObj, roleName, roleMembers, numMembers, mfail)
#define GetRoleGrpUsersAtParent(class, itemObj, roleName, roleMembers, numMembers, mfail) \
        _GetRoleGrpUsersAtClass(class, TRUE, itemObj, roleName, roleMembers, numMembers, mfail)

#define GetRplUsrForInactvUsr(inactivePrtcpObj, replaceParticp, replacePrtcpObj, mfail) \
        _GetRplUsrForInactvUsrAtClass(NULL, FALSE, inactivePrtcpObj, replaceParticp, replacePrtcpObj, mfail)
#define GetRplUsrForInactvUsrAtClass(class, inactivePrtcpObj, replaceParticp, replacePrtcpObj, mfail) \
        _GetRplUsrForInactvUsrAtClass(class, FALSE, inactivePrtcpObj, replaceParticp, replacePrtcpObj, mfail)
#define GetRplUsrForInactvUsrAtParent(class, inactivePrtcpObj, replaceParticp, replacePrtcpObj, mfail) \
        _GetRplUsrForInactvUsrAtClass(class, TRUE, inactivePrtcpObj, replaceParticp, replacePrtcpObj, mfail)

#define GetStepClass(thisObj, stepClass, mfail) \
        _GetStepClassAtClass(NULL, FALSE, thisObj, stepClass, mfail)
#define GetStepClassAtClass(class, thisObj, stepClass, mfail) \
        _GetStepClassAtClass(class, FALSE, thisObj, stepClass, mfail)
#define GetStepClassAtParent(class, thisObj, stepClass, mfail) \
        _GetStepClassAtClass(class, TRUE, thisObj, stepClass, mfail)

#define GetStepObj(className, flowName, flowRev, flowVersion, flowSeq, flowType, stepName, stepObj, mfail) \
        _GetStepObj(className, FALSE, className, flowName, flowRev, flowVersion, flowSeq, flowType, stepName, stepObj, mfail)
#define GetStepObjAtParent(_class, className, flowName, flowRev, flowVersion, flowSeq, flowType, stepName, stepObj, mfail) \
        _GetStepObj(_class, TRUE, className, flowName, flowRev, flowVersion, flowSeq, flowType, stepName, stepObj, mfail)

#define GetStepsForWorkflow(className, flowObj, objects, mfail) \
        _GetStepsForWorkflow(className, FALSE, className, flowObj, objects, mfail)
#define GetStepsForWorkflowAtParent(_class, className, flowObj, objects, mfail) \
        _GetStepsForWorkflow(_class, TRUE, className, flowObj, objects, mfail)

#define GetStepsForWorkflowInt(className, flowObj, objects, mfail) \
        _GetStepsForWorkflowInt(className, FALSE, className, flowObj, objects, mfail)
#define GetStepsForWorkflowIntAtParent(_class, className, flowObj, objects, mfail) \
        _GetStepsForWorkflowInt(_class, TRUE, className, flowObj, objects, mfail)

#define GetSuspendedProcInst(className, itemObj, prhObjSet, mfail) \
        _GetSuspendedProcInst(className, FALSE, className, itemObj, prhObjSet, mfail)
#define GetSuspendedProcInstAtParent(_class, className, itemObj, prhObjSet, mfail) \
        _GetSuspendedProcInst(_class, TRUE, className, itemObj, prhObjSet, mfail)

#define GetTabulationsForDialg(thisObj, dialogObj, mfail) \
        _GetTabulationsForDialgAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define GetTabulationsForDialgAtClass(class, thisObj, dialogObj, mfail) \
        _GetTabulationsForDialgAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define GetTabulationsForDialgAtParent(class, thisObj, dialogObj, mfail) \
        _GetTabulationsForDialgAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define GetTaskClassFromOption(worklistClassName, optName, taskWorkListClass, mfail) \
        _GetTaskClassFromOption(worklistClassName, FALSE, worklistClassName, optName, taskWorkListClass, mfail)
#define GetTaskClassFromOptionAtParent(_class, worklistClassName, optName, taskWorkListClass, mfail) \
        _GetTaskClassFromOption(_class, TRUE, worklistClassName, optName, taskWorkListClass, mfail)

#define GetTaskWorkListClass(workListClassName, worklistType, taskWorkListClass, mfail) \
        _GetTaskWorkListClass(workListClassName, FALSE, workListClassName, worklistType, taskWorkListClass, mfail)
#define GetTaskWorkListClassAtParent(_class, workListClassName, worklistType, taskWorkListClass, mfail) \
        _GetTaskWorkListClass(_class, TRUE, workListClassName, worklistType, taskWorkListClass, mfail)

#define GetTaskWorklist(taskItem, processSigs, workItems, mfail) \
        _GetTaskWorklistAtClass(NULL, FALSE, taskItem, processSigs, workItems, mfail)
#define GetTaskWorklistAtClass(class, taskItem, processSigs, workItems, mfail) \
        _GetTaskWorklistAtClass(class, FALSE, taskItem, processSigs, workItems, mfail)
#define GetTaskWorklistAtParent(class, taskItem, processSigs, workItems, mfail) \
        _GetTaskWorklistAtClass(class, TRUE, taskItem, processSigs, workItems, mfail)

#define GetTaskWorklistClasses(taskItem, mfail) \
        _GetTaskWorklistClassesAtClass(NULL, FALSE, taskItem, mfail)
#define GetTaskWorklistClassesAtClass(class, taskItem, mfail) \
        _GetTaskWorklistClassesAtClass(class, FALSE, taskItem, mfail)
#define GetTaskWorklistClassesAtParent(class, taskItem, mfail) \
        _GetTaskWorklistClassesAtClass(class, TRUE, taskItem, mfail)

#define GetTaskWorklistFilter(taskItem, processSigs, workItems, mfail) \
        _GetTaskWorklistFilterAtClass(NULL, FALSE, taskItem, processSigs, workItems, mfail)
#define GetTaskWorklistFilterAtClass(class, taskItem, processSigs, workItems, mfail) \
        _GetTaskWorklistFilterAtClass(class, FALSE, taskItem, processSigs, workItems, mfail)
#define GetTaskWorklistFilterAtParent(class, taskItem, processSigs, workItems, mfail) \
        _GetTaskWorklistFilterAtClass(class, TRUE, taskItem, processSigs, workItems, mfail)

#define GetTaskWorklistScope(taskItem, databases, mfail) \
        _GetTaskWorklistScopeAtClass(NULL, FALSE, taskItem, databases, mfail)
#define GetTaskWorklistScopeAtClass(class, taskItem, databases, mfail) \
        _GetTaskWorklistScopeAtClass(class, FALSE, taskItem, databases, mfail)
#define GetTaskWorklistScopeAtParent(class, taskItem, databases, mfail) \
        _GetTaskWorklistScopeAtClass(class, TRUE, taskItem, databases, mfail)

#define GetTskObjForWrkLstType(worklistClassName, worklistType, worklistTaskObj, mfail) \
        _GetTskObjForWrkLstType(worklistClassName, FALSE, worklistClassName, worklistType, worklistTaskObj, mfail)
#define GetTskObjForWrkLstTypeAtParent(_class, worklistClassName, worklistType, worklistTaskObj, mfail) \
        _GetTskObjForWrkLstType(_class, TRUE, worklistClassName, worklistType, worklistTaskObj, mfail)

#define GetValidLifeCycsForCls(className, objClassName, flowObjs, mfail) \
        _GetValidLifeCycsForCls(className, FALSE, className, objClassName, flowObjs, mfail)
#define GetValidLifeCycsForClsAtParent(_class, className, objClassName, flowObjs, mfail) \
        _GetValidLifeCycsForCls(_class, TRUE, className, objClassName, flowObjs, mfail)

#define GetValidOofPrefs(className, currentUser, altUser, altBegDate, altEndDate, mfail) \
        _GetValidOofPrefs(className, FALSE, className, currentUser, altUser, altBegDate, altEndDate, mfail)
#define GetValidOofPrefsAtParent(_class, className, currentUser, altUser, altBegDate, altEndDate, mfail) \
        _GetValidOofPrefs(_class, TRUE, className, currentUser, altUser, altBegDate, altEndDate, mfail)

#define GetValidRevListSet(itemObj, objects, mfail) \
        _GetValidRevListSetAtClass(NULL, FALSE, itemObj, objects, mfail)
#define GetValidRevListSetAtClass(class, itemObj, objects, mfail) \
        _GetValidRevListSetAtClass(class, FALSE, itemObj, objects, mfail)
#define GetValidRevListSetAtParent(class, itemObj, objects, mfail) \
        _GetValidRevListSetAtClass(class, TRUE, itemObj, objects, mfail)

#define GetValidReviewList(objItem, values, mfail) \
        _GetValidReviewListAtClass(NULL, FALSE, objItem, values, mfail)
#define GetValidReviewListAtClass(class, objItem, values, mfail) \
        _GetValidReviewListAtClass(class, FALSE, objItem, values, mfail)
#define GetValidReviewListAtParent(class, objItem, values, mfail) \
        _GetValidReviewListAtClass(class, TRUE, objItem, values, mfail)

#define GetValidWorkflows(className, obj, flowObjs, mfail) \
        _GetValidWorkflows(className, FALSE, className, obj, flowObjs, mfail)
#define GetValidWorkflowsAtParent(_class, className, obj, flowObjs, mfail) \
        _GetValidWorkflows(_class, TRUE, className, obj, flowObjs, mfail)

#define GetWorkItemForProcHist(procHistObj, workItemObj, mfail) \
        _GetWorkItemForProcHistAtClass(NULL, FALSE, procHistObj, workItemObj, mfail)
#define GetWorkItemForProcHistAtClass(class, procHistObj, workItemObj, mfail) \
        _GetWorkItemForProcHistAtClass(class, FALSE, procHistObj, workItemObj, mfail)
#define GetWorkItemForProcHistAtParent(class, procHistObj, workItemObj, mfail) \
        _GetWorkItemForProcHistAtClass(class, TRUE, procHistObj, workItemObj, mfail)

#define GetWorkListFilterClass(workListClassName, workListFilterClass, mfail) \
        _GetWorkListFilterClass(workListClassName, FALSE, workListClassName, workListFilterClass, mfail)
#define GetWorkListFilterClassAtParent(_class, workListClassName, workListFilterClass, mfail) \
        _GetWorkListFilterClass(_class, TRUE, workListClassName, workListFilterClass, mfail)

#define GetWorkListScope(taskObject, workListFilterObj, sql, databases, mfail) \
        _GetWorkListScopeAtClass(NULL, FALSE, taskObject, workListFilterObj, sql, databases, mfail)
#define GetWorkListScopeAtClass(class, taskObject, workListFilterObj, sql, databases, mfail) \
        _GetWorkListScopeAtClass(class, FALSE, taskObject, workListFilterObj, sql, databases, mfail)
#define GetWorkListScopeAtParent(class, taskObject, workListFilterObj, sql, databases, mfail) \
        _GetWorkListScopeAtClass(class, TRUE, taskObject, workListFilterObj, sql, databases, mfail)

#define GetWorkflowForProcHist(procHistObj, workflowObj, mfail) \
        _GetWorkflowForProcHistAtClass(NULL, FALSE, procHistObj, workflowObj, mfail)
#define GetWorkflowForProcHistAtClass(class, procHistObj, workflowObj, mfail) \
        _GetWorkflowForProcHistAtClass(class, FALSE, procHistObj, workflowObj, mfail)
#define GetWorkflowForProcHistAtParent(class, procHistObj, workflowObj, mfail) \
        _GetWorkflowForProcHistAtClass(class, TRUE, procHistObj, workflowObj, mfail)

#define GetWorkflowForProcInst(prhObj, flowObj, mfail) \
        _GetWorkflowForProcInstAtClass(NULL, FALSE, prhObj, flowObj, mfail)
#define GetWorkflowForProcInstAtClass(class, prhObj, flowObj, mfail) \
        _GetWorkflowForProcInstAtClass(class, FALSE, prhObj, flowObj, mfail)
#define GetWorkflowForProcInstAtParent(class, prhObj, flowObj, mfail) \
        _GetWorkflowForProcInstAtClass(class, TRUE, prhObj, flowObj, mfail)

#define GetWorkflowForStep(stepObj, lifeCycObj, mfail) \
        _GetWorkflowForStepAtClass(NULL, FALSE, stepObj, lifeCycObj, mfail)
#define GetWorkflowForStepAtClass(class, stepObj, lifeCycObj, mfail) \
        _GetWorkflowForStepAtClass(class, FALSE, stepObj, lifeCycObj, mfail)
#define GetWorkflowForStepAtParent(class, stepObj, lifeCycObj, mfail) \
        _GetWorkflowForStepAtClass(class, TRUE, stepObj, lifeCycObj, mfail)

#define GetWorkflowsForProc(thisObj, dialogObj, validValues, mfail) \
        _GetWorkflowsForProcAtClass(NULL, FALSE, thisObj, dialogObj, validValues, mfail)
#define GetWorkflowsForProcAtClass(class, thisObj, dialogObj, validValues, mfail) \
        _GetWorkflowsForProcAtClass(class, FALSE, thisObj, dialogObj, validValues, mfail)
#define GetWorkflowsForProcAtParent(class, thisObj, dialogObj, validValues, mfail) \
        _GetWorkflowsForProcAtClass(class, TRUE, thisObj, dialogObj, validValues, mfail)

#define GetWorkflowsToView(processObj, viewDialogObj, workflowObjSet, mfail) \
        _GetWorkflowsToViewAtClass(NULL, FALSE, processObj, viewDialogObj, workflowObjSet, mfail)
#define GetWorkflowsToViewAtClass(class, processObj, viewDialogObj, workflowObjSet, mfail) \
        _GetWorkflowsToViewAtClass(class, FALSE, processObj, viewDialogObj, workflowObjSet, mfail)
#define GetWorkflowsToViewAtParent(class, processObj, viewDialogObj, workflowObjSet, mfail) \
        _GetWorkflowsToViewAtClass(class, TRUE, processObj, viewDialogObj, workflowObjSet, mfail)

#define InflatDispResource(dialogObj, adhcDataObj, mfail) \
        _InflatDispResourceAtClass(NULL, FALSE, dialogObj, adhcDataObj, mfail)
#define InflatDispResourceAtClass(class, dialogObj, adhcDataObj, mfail) \
        _InflatDispResourceAtClass(class, FALSE, dialogObj, adhcDataObj, mfail)
#define InflatDispResourceAtParent(class, dialogObj, adhcDataObj, mfail) \
        _InflatDispResourceAtClass(class, TRUE, dialogObj, adhcDataObj, mfail)

#define InflateStepPopup(className, stepObj, mfail) \
        _InflateStepPopup(className, FALSE, className, stepObj, mfail)
#define InflateStepPopupAtParent(_class, className, stepObj, mfail) \
        _InflateStepPopup(_class, TRUE, className, stepObj, mfail)

#define InitEffectiveDates(thisObj, mfail) \
        _InitEffectiveDatesAtClass(NULL, FALSE, thisObj, mfail)
#define InitEffectiveDatesAtClass(class, thisObj, mfail) \
        _InitEffectiveDatesAtClass(class, FALSE, thisObj, mfail)
#define InitEffectiveDatesAtParent(class, thisObj, mfail) \
        _InitEffectiveDatesAtClass(class, TRUE, thisObj, mfail)

#define InitRevTabsAtSequence(thisObj, mfail) \
        _InitRevTabsAtSequenceAtClass(NULL, FALSE, thisObj, mfail)
#define InitRevTabsAtSequenceAtClass(class, thisObj, mfail) \
        _InitRevTabsAtSequenceAtClass(class, FALSE, thisObj, mfail)
#define InitRevTabsAtSequenceAtParent(class, thisObj, mfail) \
        _InitRevTabsAtSequenceAtClass(class, TRUE, thisObj, mfail)

#define IntMultiSelAssignment(classname, selectedItems, selectedRels, msgOptionTag, mfail) \
        _IntMultiSelAssignment(classname, FALSE, classname, selectedItems, selectedRels, msgOptionTag, mfail)
#define IntMultiSelAssignmentAtParent(_class, classname, selectedItems, selectedRels, msgOptionTag, mfail) \
        _IntMultiSelAssignment(_class, TRUE, classname, selectedItems, selectedRels, msgOptionTag, mfail)

#define IsActorAssignable(actorObj, itemObj, procHistObj, answer, mfail) \
        _IsActorAssignableAtClass(NULL, FALSE, actorObj, itemObj, procHistObj, answer, mfail)
#define IsActorAssignableAtClass(class, actorObj, itemObj, procHistObj, answer, mfail) \
        _IsActorAssignableAtClass(class, FALSE, actorObj, itemObj, procHistObj, answer, mfail)
#define IsActorAssignableAtParent(class, actorObj, itemObj, procHistObj, answer, mfail) \
        _IsActorAssignableAtClass(class, TRUE, actorObj, itemObj, procHistObj, answer, mfail)

#define IsHigherPrecedent(thisObj, originParticipObj, higherPrecedent, mfail) \
        _IsHigherPrecedentAtClass(NULL, FALSE, thisObj, originParticipObj, higherPrecedent, mfail)
#define IsHigherPrecedentAtClass(class, thisObj, originParticipObj, higherPrecedent, mfail) \
        _IsHigherPrecedentAtClass(class, FALSE, thisObj, originParticipObj, higherPrecedent, mfail)
#define IsHigherPrecedentAtParent(class, thisObj, originParticipObj, higherPrecedent, mfail) \
        _IsHigherPrecedentAtClass(class, TRUE, thisObj, originParticipObj, higherPrecedent, mfail)

#define IsInteractiveProcess(classname, interactive, mfail) \
        _IsInteractiveProcess(classname, FALSE, classname, interactive, mfail)
#define IsInteractiveProcessAtParent(_class, classname, interactive, mfail) \
        _IsInteractiveProcess(_class, TRUE, classname, interactive, mfail)

#define IsItemCheckedOut(thisObj, isCkoPred, isCkoSucc, mfail) \
        _IsItemCheckedOutAtClass(NULL, FALSE, thisObj, isCkoPred, isCkoSucc, mfail)
#define IsItemCheckedOutAtClass(class, thisObj, isCkoPred, isCkoSucc, mfail) \
        _IsItemCheckedOutAtClass(class, FALSE, thisObj, isCkoPred, isCkoSucc, mfail)
#define IsItemCheckedOutAtParent(class, thisObj, isCkoPred, isCkoSucc, mfail) \
        _IsItemCheckedOutAtClass(class, TRUE, thisObj, isCkoPred, isCkoSucc, mfail)

#define IsProcessInUse(className, processName, answer, mfail) \
        _IsProcessInUse(className, FALSE, className, processName, answer, mfail)
#define IsProcessInUseAtParent(_class, className, processName, answer, mfail) \
        _IsProcessInUse(_class, TRUE, className, processName, answer, mfail)

#define IsTopLvlPrcHstOpen(prhObj, isOpen, mfail) \
        _IsTopLvlPrcHstOpenAtClass(NULL, FALSE, prhObj, isOpen, mfail)
#define IsTopLvlPrcHstOpenAtClass(class, prhObj, isOpen, mfail) \
        _IsTopLvlPrcHstOpenAtClass(class, FALSE, prhObj, isOpen, mfail)
#define IsTopLvlPrcHstOpenAtParent(class, prhObj, isOpen, mfail) \
        _IsTopLvlPrcHstOpenAtClass(class, TRUE, prhObj, isOpen, mfail)

#define IsUserAssignedThisWork(className, wrkItemObj, procHistObj, workDesc, userToCheck, isAssignedWork, mfail) \
        _IsUserAssignedThisWork(className, FALSE, className, wrkItemObj, procHistObj, workDesc, userToCheck, isAssignedWork, mfail)
#define IsUserAssignedThisWorkAtParent(_class, className, wrkItemObj, procHistObj, workDesc, userToCheck, isAssignedWork, mfail) \
        _IsUserAssignedThisWork(_class, TRUE, className, wrkItemObj, procHistObj, workDesc, userToCheck, isAssignedWork, mfail)

#define LcmBaselineItemObject(obj, procHist, msgProc, exitState, advComments, mfail) \
        _LcmBaselineItemObjectAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define LcmBaselineItemObjectAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _LcmBaselineItemObjectAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define LcmBaselineItemObjectAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _LcmBaselineItemObjectAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define LcmExportItemObject(obj, procHist, msgProc, exitState, advComments, mfail) \
        _LcmExportItemObjectAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define LcmExportItemObjectAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _LcmExportItemObjectAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define LcmExportItemObjectAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _LcmExportItemObjectAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define LcmFalseTestMessage(obj, procHist, msgProc, exitState, advComments, mfail) \
        _LcmFalseTestMessageAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define LcmFalseTestMessageAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _LcmFalseTestMessageAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define LcmFalseTestMessageAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _LcmFalseTestMessageAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define LcmTrueTestMessage(obj, procHist, msgProc, exitState, advComments, mfail) \
        _LcmTrueTestMessageAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define LcmTrueTestMessageAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _LcmTrueTestMessageAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define LcmTrueTestMessageAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _LcmTrueTestMessageAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define LcmVaultTransItemObj(obj, procHist, msgProc, exitState, advComments, mfail) \
        _LcmVaultTransItemObjAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define LcmVaultTransItemObjAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _LcmVaultTransItemObjAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define LcmVaultTransItemObjAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _LcmVaultTransItemObjAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define ManageAltAssignment(thisObj, itemObj, mfail) \
        _ManageAltAssignmentAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define ManageAltAssignmentAtClass(class, thisObj, itemObj, mfail) \
        _ManageAltAssignmentAtClass(class, FALSE, thisObj, itemObj, mfail)
#define ManageAltAssignmentAtParent(class, thisObj, itemObj, mfail) \
        _ManageAltAssignmentAtClass(class, TRUE, thisObj, itemObj, mfail)

#define ManageAltWork(thisObj, workitem, dialogObj, mfail) \
        _ManageAltWorkAtClass(NULL, FALSE, thisObj, workitem, dialogObj, mfail)
#define ManageAltWorkAtClass(class, thisObj, workitem, dialogObj, mfail) \
        _ManageAltWorkAtClass(class, FALSE, thisObj, workitem, dialogObj, mfail)
#define ManageAltWorkAtParent(class, thisObj, workitem, dialogObj, mfail) \
        _ManageAltWorkAtClass(class, TRUE, thisObj, workitem, dialogObj, mfail)

#define ManageAltWorkDP(thisObj, itemObj, mfail) \
        _ManageAltWorkDPAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define ManageAltWorkDPAtClass(class, thisObj, itemObj, mfail) \
        _ManageAltWorkDPAtClass(class, FALSE, thisObj, itemObj, mfail)
#define ManageAltWorkDPAtParent(class, thisObj, itemObj, mfail) \
        _ManageAltWorkDPAtClass(class, TRUE, thisObj, itemObj, mfail)

#define ManageUserWork(thisObj, workitem, reminderDate, mfail) \
        _ManageUserWorkAtClass(NULL, FALSE, thisObj, workitem, reminderDate, mfail)
#define ManageUserWorkAtClass(class, thisObj, workitem, reminderDate, mfail) \
        _ManageUserWorkAtClass(class, FALSE, thisObj, workitem, reminderDate, mfail)
#define ManageUserWorkAtParent(class, thisObj, workitem, reminderDate, mfail) \
        _ManageUserWorkAtClass(class, TRUE, thisObj, workitem, reminderDate, mfail)

#define ManageUsrWorkDP(thisObj, itemObj, mfail) \
        _ManageUsrWorkDPAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define ManageUsrWorkDPAtClass(class, thisObj, itemObj, mfail) \
        _ManageUsrWorkDPAtClass(class, FALSE, thisObj, itemObj, mfail)
#define ManageUsrWorkDPAtParent(class, thisObj, itemObj, mfail) \
        _ManageUsrWorkDPAtClass(class, TRUE, thisObj, itemObj, mfail)

#define MarkOverdueObject(thisObj, mfail) \
        _MarkOverdueObjectAtClass(NULL, FALSE, thisObj, mfail)
#define MarkOverdueObjectAtClass(class, thisObj, mfail) \
        _MarkOverdueObjectAtClass(class, FALSE, thisObj, mfail)
#define MarkOverdueObjectAtParent(class, thisObj, mfail) \
        _MarkOverdueObjectAtClass(class, TRUE, thisObj, mfail)

#define NewButton(thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _NewButtonAtClass(NULL, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define NewButtonAtClass(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _NewButtonAtClass(class, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define NewButtonAtParent(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _NewButtonAtClass(class, TRUE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)

#define NotCompleteUsrWork(asgSig, workItem, authObj, externalStamp, comments, mfail) \
        _NotCompleteUsrWorkAtClass(NULL, FALSE, asgSig, workItem, authObj, externalStamp, comments, mfail)
#define NotCompleteUsrWorkAtClass(class, asgSig, workItem, authObj, externalStamp, comments, mfail) \
        _NotCompleteUsrWorkAtClass(class, FALSE, asgSig, workItem, authObj, externalStamp, comments, mfail)
#define NotCompleteUsrWorkAtParent(class, asgSig, workItem, authObj, externalStamp, comments, mfail) \
        _NotCompleteUsrWorkAtClass(class, TRUE, asgSig, workItem, authObj, externalStamp, comments, mfail)

#define NotOKUsrWork(avrSig, workItem, authObj, externalStamp, comments, mfail) \
        _NotOKUsrWorkAtClass(NULL, FALSE, avrSig, workItem, authObj, externalStamp, comments, mfail)
#define NotOKUsrWorkAtClass(class, avrSig, workItem, authObj, externalStamp, comments, mfail) \
        _NotOKUsrWorkAtClass(class, FALSE, avrSig, workItem, authObj, externalStamp, comments, mfail)
#define NotOKUsrWorkAtParent(class, avrSig, workItem, authObj, externalStamp, comments, mfail) \
        _NotOKUsrWorkAtClass(class, TRUE, avrSig, workItem, authObj, externalStamp, comments, mfail)

#define NotOKWork2(avrSig, workItem, externalStamp, comments, mfail) \
        _NotOKWork2AtClass(NULL, FALSE, avrSig, workItem, externalStamp, comments, mfail)
#define NotOKWork2AtClass(class, avrSig, workItem, externalStamp, comments, mfail) \
        _NotOKWork2AtClass(class, FALSE, avrSig, workItem, externalStamp, comments, mfail)
#define NotOKWork2AtParent(class, avrSig, workItem, externalStamp, comments, mfail) \
        _NotOKWork2AtClass(class, TRUE, avrSig, workItem, externalStamp, comments, mfail)

#define NotOKWork3(avrSig, workItem, externalStamp, comments, mfail) \
        _NotOKWork3AtClass(NULL, FALSE, avrSig, workItem, externalStamp, comments, mfail)
#define NotOKWork3AtClass(class, avrSig, workItem, externalStamp, comments, mfail) \
        _NotOKWork3AtClass(class, FALSE, avrSig, workItem, externalStamp, comments, mfail)
#define NotOKWork3AtParent(class, avrSig, workItem, externalStamp, comments, mfail) \
        _NotOKWork3AtClass(class, TRUE, avrSig, workItem, externalStamp, comments, mfail)

#define NotOKWorkDP(thisObj, itemObj, mfail) \
        _NotOKWorkDPAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define NotOKWorkDPAtClass(class, thisObj, itemObj, mfail) \
        _NotOKWorkDPAtClass(class, FALSE, thisObj, itemObj, mfail)
#define NotOKWorkDPAtParent(class, thisObj, itemObj, mfail) \
        _NotOKWorkDPAtClass(class, TRUE, thisObj, itemObj, mfail)

#define NotOKWorkP(avrSig, workItem, mfail) \
        _NotOKWorkPAtClass(NULL, FALSE, avrSig, workItem, mfail)
#define NotOKWorkPAtClass(class, avrSig, workItem, mfail) \
        _NotOKWorkPAtClass(class, FALSE, avrSig, workItem, mfail)
#define NotOKWorkPAtParent(class, avrSig, workItem, mfail) \
        _NotOKWorkPAtClass(class, TRUE, avrSig, workItem, mfail)

#define OKUsrWork(avrSig, workItem, authObj, externalStamp, comments, mfail) \
        _OKUsrWorkAtClass(NULL, FALSE, avrSig, workItem, authObj, externalStamp, comments, mfail)
#define OKUsrWorkAtClass(class, avrSig, workItem, authObj, externalStamp, comments, mfail) \
        _OKUsrWorkAtClass(class, FALSE, avrSig, workItem, authObj, externalStamp, comments, mfail)
#define OKUsrWorkAtParent(class, avrSig, workItem, authObj, externalStamp, comments, mfail) \
        _OKUsrWorkAtClass(class, TRUE, avrSig, workItem, authObj, externalStamp, comments, mfail)

#define OKWork2(avrSig, workItem, externalStamp, comments, mfail) \
        _OKWork2AtClass(NULL, FALSE, avrSig, workItem, externalStamp, comments, mfail)
#define OKWork2AtClass(class, avrSig, workItem, externalStamp, comments, mfail) \
        _OKWork2AtClass(class, FALSE, avrSig, workItem, externalStamp, comments, mfail)
#define OKWork2AtParent(class, avrSig, workItem, externalStamp, comments, mfail) \
        _OKWork2AtClass(class, TRUE, avrSig, workItem, externalStamp, comments, mfail)

#define OKWork3(avrSig, workItem, externalStamp, comments, mfail) \
        _OKWork3AtClass(NULL, FALSE, avrSig, workItem, externalStamp, comments, mfail)
#define OKWork3AtClass(class, avrSig, workItem, externalStamp, comments, mfail) \
        _OKWork3AtClass(class, FALSE, avrSig, workItem, externalStamp, comments, mfail)
#define OKWork3AtParent(class, avrSig, workItem, externalStamp, comments, mfail) \
        _OKWork3AtClass(class, TRUE, avrSig, workItem, externalStamp, comments, mfail)

#define OKWorkDP(thisObj, itemObj, mfail) \
        _OKWorkDPAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define OKWorkDPAtClass(class, thisObj, itemObj, mfail) \
        _OKWorkDPAtClass(class, FALSE, thisObj, itemObj, mfail)
#define OKWorkDPAtParent(class, thisObj, itemObj, mfail) \
        _OKWorkDPAtClass(class, TRUE, thisObj, itemObj, mfail)

#define OKWorkP(avrSig, workItem, mfail) \
        _OKWorkPAtClass(NULL, FALSE, avrSig, workItem, mfail)
#define OKWorkPAtClass(class, avrSig, workItem, mfail) \
        _OKWorkPAtClass(class, FALSE, avrSig, workItem, mfail)
#define OKWorkPAtParent(class, avrSig, workItem, mfail) \
        _OKWorkPAtClass(class, TRUE, avrSig, workItem, mfail)

#define OrderSigsByCreDate(className, sigObjectSet, mfail) \
        _OrderSigsByCreDate(className, FALSE, className, sigObjectSet, mfail)
#define OrderSigsByCreDateAtParent(_class, className, sigObjectSet, mfail) \
        _OrderSigsByCreDate(_class, TRUE, className, sigObjectSet, mfail)

#define PerformComments(className, wrkItemObj, procHistObj, dialogConstant, sigObj, mfail) \
        _PerformComments(className, FALSE, className, wrkItemObj, procHistObj, dialogConstant, sigObj, mfail)
#define PerformCommentsAtParent(_class, className, wrkItemObj, procHistObj, dialogConstant, sigObj, mfail) \
        _PerformComments(_class, TRUE, className, wrkItemObj, procHistObj, dialogConstant, sigObj, mfail)

#define PerformSignoff(sig, workItem, authObj, intStamp, intStampMode, advEvent, notifEvent, externalStamp, comments, mfail) \
        _PerformSignoffAtClass(NULL, FALSE, sig, workItem, authObj, intStamp, intStampMode, advEvent, notifEvent, externalStamp, comments, mfail)
#define PerformSignoffAtClass(class, sig, workItem, authObj, intStamp, intStampMode, advEvent, notifEvent, externalStamp, comments, mfail) \
        _PerformSignoffAtClass(class, FALSE, sig, workItem, authObj, intStamp, intStampMode, advEvent, notifEvent, externalStamp, comments, mfail)
#define PerformSignoffAtParent(class, sig, workItem, authObj, intStamp, intStampMode, advEvent, notifEvent, externalStamp, comments, mfail) \
        _PerformSignoffAtClass(class, TRUE, sig, workItem, authObj, intStamp, intStampMode, advEvent, notifEvent, externalStamp, comments, mfail)

#define PerformSignoffDP(sig, workItem, intStamp, intStampMode, advEvent, notifEvent, mfail) \
        _PerformSignoffDPAtClass(NULL, FALSE, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, mfail)
#define PerformSignoffDPAtClass(class, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, mfail) \
        _PerformSignoffDPAtClass(class, FALSE, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, mfail)
#define PerformSignoffDPAtParent(class, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, mfail) \
        _PerformSignoffDPAtClass(class, TRUE, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, mfail)

#define PerformViewSignoff(className, dialogConstant, sigObjs, sigObj, mfail) \
        _PerformViewSignoff(className, FALSE, className, dialogConstant, sigObjs, sigObj, mfail)
#define PerformViewSignoffAtParent(_class, className, dialogConstant, sigObjs, sigObj, mfail) \
        _PerformViewSignoff(_class, TRUE, className, dialogConstant, sigObjs, sigObj, mfail)

#define PerformWorkSignoff(sig, workItem, intStamp, intStampMode, advEvent, notifEvent, externalStamp, comments, mfail) \
        _PerformWorkSignoffAtClass(NULL, FALSE, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, externalStamp, comments, mfail)
#define PerformWorkSignoffAtClass(class, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, externalStamp, comments, mfail) \
        _PerformWorkSignoffAtClass(class, FALSE, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, externalStamp, comments, mfail)
#define PerformWorkSignoffAtParent(class, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, externalStamp, comments, mfail) \
        _PerformWorkSignoffAtClass(class, TRUE, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, externalStamp, comments, mfail)

#define PerformWorkSignoff2(sig, workItem, intStamp, intStampMode, advEvent, notifEvent, externalStamp, comments, appendComments, mfail) \
        _PerformWorkSignoff2AtClass(NULL, FALSE, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, externalStamp, comments, appendComments, mfail)
#define PerformWorkSignoff2AtClass(class, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, externalStamp, comments, appendComments, mfail) \
        _PerformWorkSignoff2AtClass(class, FALSE, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, externalStamp, comments, appendComments, mfail)
#define PerformWorkSignoff2AtParent(class, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, externalStamp, comments, appendComments, mfail) \
        _PerformWorkSignoff2AtClass(class, TRUE, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, externalStamp, comments, appendComments, mfail)

#define PerformWorkSignoffDP(sig, workItem, intStamp, intStampMode, advEvent, notifEvent, mfail) \
        _PerformWorkSignoffDPAtClass(NULL, FALSE, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, mfail)
#define PerformWorkSignoffDPAtClass(class, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, mfail) \
        _PerformWorkSignoffDPAtClass(class, FALSE, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, mfail)
#define PerformWorkSignoffDPAtParent(class, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, mfail) \
        _PerformWorkSignoffDPAtClass(class, TRUE, sig, workItem, intStamp, intStampMode, advEvent, notifEvent, mfail)

#define PollDbForWork(taskObject, workListFilterObj, dbName, sql, count, mfail) \
        _PollDbForWorkAtClass(NULL, FALSE, taskObject, workListFilterObj, dbName, sql, count, mfail)
#define PollDbForWorkAtClass(class, taskObject, workListFilterObj, dbName, sql, count, mfail) \
        _PollDbForWorkAtClass(class, FALSE, taskObject, workListFilterObj, dbName, sql, count, mfail)
#define PollDbForWorkAtParent(class, taskObject, workListFilterObj, dbName, sql, count, mfail) \
        _PollDbForWorkAtClass(class, TRUE, taskObject, workListFilterObj, dbName, sql, count, mfail)

#define PopulateAdHocData(lifeCycleObj, workItem, adhcDataObj, mfail) \
        _PopulateAdHocDataAtClass(NULL, FALSE, lifeCycleObj, workItem, adhcDataObj, mfail)
#define PopulateAdHocDataAtClass(class, lifeCycleObj, workItem, adhcDataObj, mfail) \
        _PopulateAdHocDataAtClass(class, FALSE, lifeCycleObj, workItem, adhcDataObj, mfail)
#define PopulateAdHocDataAtParent(class, lifeCycleObj, workItem, adhcDataObj, mfail) \
        _PopulateAdHocDataAtClass(class, TRUE, lifeCycleObj, workItem, adhcDataObj, mfail)

#define PrepareItemForRoute(thisObj, mfail) \
        _PrepareItemForRouteAtClass(NULL, FALSE, thisObj, mfail)
#define PrepareItemForRouteAtClass(class, thisObj, mfail) \
        _PrepareItemForRouteAtClass(class, FALSE, thisObj, mfail)
#define PrepareItemForRouteAtParent(class, thisObj, mfail) \
        _PrepareItemForRouteAtClass(class, TRUE, thisObj, mfail)

#define PrepareItemForSubmit(thisObj, mfail) \
        _PrepareItemForSubmitAtClass(NULL, FALSE, thisObj, mfail)
#define PrepareItemForSubmitAtClass(class, thisObj, mfail) \
        _PrepareItemForSubmitAtClass(class, FALSE, thisObj, mfail)
#define PrepareItemForSubmitAtParent(class, thisObj, mfail) \
        _PrepareItemForSubmitAtClass(class, TRUE, thisObj, mfail)

#define ProcessNameExists(className, processName, exists, mfail) \
        _ProcessNameExists(className, FALSE, className, processName, exists, mfail)
#define ProcessNameExistsAtParent(_class, className, processName, exists, mfail) \
        _ProcessNameExists(_class, TRUE, className, processName, exists, mfail)

#define ProcessOutOfOfficeUser(className, currentUser, altUser, altBegDate, altEndDate, mfail) \
        _ProcessOutOfOfficeUser(className, FALSE, className, currentUser, altUser, altBegDate, altEndDate, mfail)
#define ProcessOutOfOfficeUserAtParent(_class, className, currentUser, altUser, altBegDate, altEndDate, mfail) \
        _ProcessOutOfOfficeUser(_class, TRUE, className, currentUser, altUser, altBegDate, altEndDate, mfail)

#define PropagateMsgAccessTbl(thisObj, thisPre, mode, mfail) \
        _PropagateMsgAccessTblAtClass(NULL, FALSE, thisObj, thisPre, mode, mfail)
#define PropagateMsgAccessTblAtClass(class, thisObj, thisPre, mode, mfail) \
        _PropagateMsgAccessTblAtClass(class, FALSE, thisObj, thisPre, mode, mfail)
#define PropagateMsgAccessTblAtParent(class, thisObj, thisPre, mode, mfail) \
        _PropagateMsgAccessTblAtClass(class, TRUE, thisObj, thisPre, mode, mfail)

#define QueryAltWorklist(className, optName, altUserName, filterObj, processSigs, workItems, mfail) \
        _QueryAltWorklist(className, FALSE, className, optName, altUserName, filterObj, processSigs, workItems, mfail)
#define QueryAltWorklistAtParent(_class, className, optName, altUserName, filterObj, processSigs, workItems, mfail) \
        _QueryAltWorklist(_class, TRUE, className, optName, altUserName, filterObj, processSigs, workItems, mfail)

#define QueryAltWorklistDP(classname, tagname, mfail) \
        _QueryAltWorklistDP(classname, FALSE, classname, tagname, mfail)
#define QueryAltWorklistDPAtParent(_class, classname, tagname, mfail) \
        _QueryAltWorklistDP(_class, TRUE, classname, tagname, mfail)

#define QueryForAltWorklist(classname, tagname, mfail) \
        _QueryForAltWorklist(classname, FALSE, classname, tagname, mfail)
#define QueryForAltWorklistAtParent(_class, classname, tagname, mfail) \
        _QueryForAltWorklist(_class, TRUE, classname, tagname, mfail)

#define QueryForLCABrowser(className, mfail) \
        _QueryForLCABrowser(className, FALSE, className, mfail)
#define QueryForLCABrowserAtParent(_class, className, mfail) \
        _QueryForLCABrowser(_class, TRUE, className, mfail)

#define QueryForLCMWorkExists(className, workExists, mfail) \
        _QueryForLCMWorkExists(className, FALSE, className, workExists, mfail)
#define QueryForLCMWorkExistsAtParent(_class, className, workExists, mfail) \
        _QueryForLCMWorkExists(_class, TRUE, className, workExists, mfail)

#define QueryForUserWorklist(className, usrName, optName, browserExists, filterObj, mfail) \
        _QueryForUserWorklist(className, FALSE, className, usrName, optName, browserExists, filterObj, mfail)
#define QueryForUserWorklistAtParent(_class, className, usrName, optName, browserExists, filterObj, mfail) \
        _QueryForUserWorklist(_class, TRUE, className, usrName, optName, browserExists, filterObj, mfail)

#define QueryItmWorklistObject(className, itemObj, optName, participant, processSigs, mfail) \
        _QueryItmWorklistObject(className, FALSE, className, itemObj, optName, participant, processSigs, mfail)
#define QueryItmWorklistObjectAtParent(_class, className, itemObj, optName, participant, processSigs, mfail) \
        _QueryItmWorklistObject(_class, TRUE, className, itemObj, optName, participant, processSigs, mfail)

#define QuerySpecificSigItems(className, thisObj, usrName, sigObjs, mfail) \
        _QuerySpecificSigItems(className, FALSE, className, thisObj, usrName, sigObjs, mfail)
#define QuerySpecificSigItemsAtParent(_class, className, thisObj, usrName, sigObjs, mfail) \
        _QuerySpecificSigItems(_class, TRUE, className, thisObj, usrName, sigObjs, mfail)

#define QueryTaskWorkList(taskObject, worklistFilterObj, processSigs, workItems, mfail) \
        _QueryTaskWorkListAtClass(NULL, FALSE, taskObject, worklistFilterObj, processSigs, workItems, mfail)
#define QueryTaskWorkListAtClass(class, taskObject, worklistFilterObj, processSigs, workItems, mfail) \
        _QueryTaskWorkListAtClass(class, FALSE, taskObject, worklistFilterObj, processSigs, workItems, mfail)
#define QueryTaskWorkListAtParent(class, taskObject, worklistFilterObj, processSigs, workItems, mfail) \
        _QueryTaskWorkListAtClass(class, TRUE, taskObject, worklistFilterObj, processSigs, workItems, mfail)

#define QueryUserWorklist(className, optName, filterObj, processSigs, workItems, mfail) \
        _QueryUserWorklist(className, FALSE, className, optName, filterObj, processSigs, workItems, mfail)
#define QueryUserWorklistAtParent(_class, className, optName, filterObj, processSigs, workItems, mfail) \
        _QueryUserWorklist(_class, TRUE, className, optName, filterObj, processSigs, workItems, mfail)

#define QueryUserWorklistD(classname, tagname, mfail) \
        _QueryUserWorklistD(classname, FALSE, classname, tagname, mfail)
#define QueryUserWorklistDAtParent(_class, classname, tagname, mfail) \
        _QueryUserWorklistD(_class, TRUE, classname, tagname, mfail)

#define QueryWorkList(worklistClassName, worklistFilterObj, processSigs, workItems, mfail) \
        _QueryWorkList(worklistClassName, FALSE, worklistClassName, worklistFilterObj, processSigs, workItems, mfail)
#define QueryWorkListAtParent(_class, worklistClassName, worklistFilterObj, processSigs, workItems, mfail) \
        _QueryWorkList(_class, TRUE, worklistClassName, worklistFilterObj, processSigs, workItems, mfail)

#define ReAssign(thisObj, lcmAdminMode, mfail) \
        _ReAssignAtClass(NULL, FALSE, thisObj, lcmAdminMode, mfail)
#define ReAssignAtClass(class, thisObj, lcmAdminMode, mfail) \
        _ReAssignAtClass(class, FALSE, thisObj, lcmAdminMode, mfail)
#define ReAssignAtParent(class, thisObj, lcmAdminMode, mfail) \
        _ReAssignAtClass(class, TRUE, thisObj, lcmAdminMode, mfail)

#define ReAssignAlt(thisObj, mfail) \
        _ReAssignAltAtClass(NULL, FALSE, thisObj, mfail)
#define ReAssignAltAtClass(class, thisObj, mfail) \
        _ReAssignAltAtClass(class, FALSE, thisObj, mfail)
#define ReAssignAltAtParent(class, thisObj, mfail) \
        _ReAssignAltAtClass(class, TRUE, thisObj, mfail)

#define ReAssignAltWork(thisObj, itemObj, authObj, reassignTo, extStamp, comments, mfail) \
        _ReAssignAltWorkAtClass(NULL, FALSE, thisObj, itemObj, authObj, reassignTo, extStamp, comments, mfail)
#define ReAssignAltWorkAtClass(class, thisObj, itemObj, authObj, reassignTo, extStamp, comments, mfail) \
        _ReAssignAltWorkAtClass(class, FALSE, thisObj, itemObj, authObj, reassignTo, extStamp, comments, mfail)
#define ReAssignAltWorkAtParent(class, thisObj, itemObj, authObj, reassignTo, extStamp, comments, mfail) \
        _ReAssignAltWorkAtClass(class, TRUE, thisObj, itemObj, authObj, reassignTo, extStamp, comments, mfail)

#define ReAssignAltWork2(thisObj, reassignTo, extStamp, comments, mfail) \
        _ReAssignAltWork2AtClass(NULL, FALSE, thisObj, reassignTo, extStamp, comments, mfail)
#define ReAssignAltWork2AtClass(class, thisObj, reassignTo, extStamp, comments, mfail) \
        _ReAssignAltWork2AtClass(class, FALSE, thisObj, reassignTo, extStamp, comments, mfail)
#define ReAssignAltWork2AtParent(class, thisObj, reassignTo, extStamp, comments, mfail) \
        _ReAssignAltWork2AtClass(class, TRUE, thisObj, reassignTo, extStamp, comments, mfail)

#define ReAssignAltWorkDP(thisObj, itemObj, mfail) \
        _ReAssignAltWorkDPAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define ReAssignAltWorkDPAtClass(class, thisObj, itemObj, mfail) \
        _ReAssignAltWorkDPAtClass(class, FALSE, thisObj, itemObj, mfail)
#define ReAssignAltWorkDPAtParent(class, thisObj, itemObj, mfail) \
        _ReAssignAltWorkDPAtClass(class, TRUE, thisObj, itemObj, mfail)

#define ReAssignDynPrtcpInItem(itemObj, sigObj, userList, mfail) \
        _ReAssignDynPrtcpInItemAtClass(NULL, FALSE, itemObj, sigObj, userList, mfail)
#define ReAssignDynPrtcpInItemAtClass(class, itemObj, sigObj, userList, mfail) \
        _ReAssignDynPrtcpInItemAtClass(class, FALSE, itemObj, sigObj, userList, mfail)
#define ReAssignDynPrtcpInItemAtParent(class, itemObj, sigObj, userList, mfail) \
        _ReAssignDynPrtcpInItemAtClass(class, TRUE, itemObj, sigObj, userList, mfail)

#define ReAssignObject(thisObj, lcmAdminMode, intStampMode, reassignTo, extStamp, comments, mfail) \
        _ReAssignObjectAtClass(NULL, FALSE, thisObj, lcmAdminMode, intStampMode, reassignTo, extStamp, comments, mfail)
#define ReAssignObjectAtClass(class, thisObj, lcmAdminMode, intStampMode, reassignTo, extStamp, comments, mfail) \
        _ReAssignObjectAtClass(class, FALSE, thisObj, lcmAdminMode, intStampMode, reassignTo, extStamp, comments, mfail)
#define ReAssignObjectAtParent(class, thisObj, lcmAdminMode, intStampMode, reassignTo, extStamp, comments, mfail) \
        _ReAssignObjectAtClass(class, TRUE, thisObj, lcmAdminMode, intStampMode, reassignTo, extStamp, comments, mfail)

#define ReAssignObject2(thisObj, lcmAdminMode, intStampMode, reassignTo, extStamp, comments, mfail) \
        _ReAssignObject2AtClass(NULL, FALSE, thisObj, lcmAdminMode, intStampMode, reassignTo, extStamp, comments, mfail)
#define ReAssignObject2AtClass(class, thisObj, lcmAdminMode, intStampMode, reassignTo, extStamp, comments, mfail) \
        _ReAssignObject2AtClass(class, FALSE, thisObj, lcmAdminMode, intStampMode, reassignTo, extStamp, comments, mfail)
#define ReAssignObject2AtParent(class, thisObj, lcmAdminMode, intStampMode, reassignTo, extStamp, comments, mfail) \
        _ReAssignObject2AtClass(class, TRUE, thisObj, lcmAdminMode, intStampMode, reassignTo, extStamp, comments, mfail)

#define ReAssignUsrWork(thisObj, itemObj, authObj, reassignTo, extStamp, comments, mfail) \
        _ReAssignUsrWorkAtClass(NULL, FALSE, thisObj, itemObj, authObj, reassignTo, extStamp, comments, mfail)
#define ReAssignUsrWorkAtClass(class, thisObj, itemObj, authObj, reassignTo, extStamp, comments, mfail) \
        _ReAssignUsrWorkAtClass(class, FALSE, thisObj, itemObj, authObj, reassignTo, extStamp, comments, mfail)
#define ReAssignUsrWorkAtParent(class, thisObj, itemObj, authObj, reassignTo, extStamp, comments, mfail) \
        _ReAssignUsrWorkAtClass(class, TRUE, thisObj, itemObj, authObj, reassignTo, extStamp, comments, mfail)

#define ReAssignUsrWork2(thisObj, reassignTo, extStamp, comments, mfail) \
        _ReAssignUsrWork2AtClass(NULL, FALSE, thisObj, reassignTo, extStamp, comments, mfail)
#define ReAssignUsrWork2AtClass(class, thisObj, reassignTo, extStamp, comments, mfail) \
        _ReAssignUsrWork2AtClass(class, FALSE, thisObj, reassignTo, extStamp, comments, mfail)
#define ReAssignUsrWork2AtParent(class, thisObj, reassignTo, extStamp, comments, mfail) \
        _ReAssignUsrWork2AtClass(class, TRUE, thisObj, reassignTo, extStamp, comments, mfail)

#define ReAssignUsrWork3(thisObj, dialogObj, mfail) \
        _ReAssignUsrWork3AtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define ReAssignUsrWork3AtClass(class, thisObj, dialogObj, mfail) \
        _ReAssignUsrWork3AtClass(class, FALSE, thisObj, dialogObj, mfail)
#define ReAssignUsrWork3AtParent(class, thisObj, dialogObj, mfail) \
        _ReAssignUsrWork3AtClass(class, TRUE, thisObj, dialogObj, mfail)

#define ReAssignUsrWorkDP(thisObj, itemObj, mfail) \
        _ReAssignUsrWorkDPAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define ReAssignUsrWorkDPAtClass(class, thisObj, itemObj, mfail) \
        _ReAssignUsrWorkDPAtClass(class, FALSE, thisObj, itemObj, mfail)
#define ReAssignUsrWorkDPAtParent(class, thisObj, itemObj, mfail) \
        _ReAssignUsrWorkDPAtClass(class, TRUE, thisObj, itemObj, mfail)

#define RefreshProcHistQuiet(className, thisObj, itemObj, mfail) \
        _RefreshProcHistQuiet(className, FALSE, className, thisObj, itemObj, mfail)
#define RefreshProcHistQuietAtParent(_class, className, thisObj, itemObj, mfail) \
        _RefreshProcHistQuiet(_class, TRUE, className, thisObj, itemObj, mfail)

#define RefreshWorkForAction(thisObj, itemObj, mfail) \
        _RefreshWorkForActionAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define RefreshWorkForActionAtClass(class, thisObj, itemObj, mfail) \
        _RefreshWorkForActionAtClass(class, FALSE, thisObj, itemObj, mfail)
#define RefreshWorkForActionAtParent(class, thisObj, itemObj, mfail) \
        _RefreshWorkForActionAtClass(class, TRUE, thisObj, itemObj, mfail)

#define RefreshWorklistObject(thisObj, refreshFromObj, mfail) \
        _RefreshWorklistObjectAtClass(NULL, FALSE, thisObj, refreshFromObj, mfail)
#define RefreshWorklistObjectAtClass(class, thisObj, refreshFromObj, mfail) \
        _RefreshWorklistObjectAtClass(class, FALSE, thisObj, refreshFromObj, mfail)
#define RefreshWorklistObjectAtParent(class, thisObj, refreshFromObj, mfail) \
        _RefreshWorklistObjectAtClass(class, TRUE, thisObj, refreshFromObj, mfail)

#define RejectExpediteUsrWork(revSig, workItem, authObj, externalStamp, comments, mfail) \
        _RejectExpediteUsrWorkAtClass(NULL, FALSE, revSig, workItem, authObj, externalStamp, comments, mfail)
#define RejectExpediteUsrWorkAtClass(class, revSig, workItem, authObj, externalStamp, comments, mfail) \
        _RejectExpediteUsrWorkAtClass(class, FALSE, revSig, workItem, authObj, externalStamp, comments, mfail)
#define RejectExpediteUsrWorkAtParent(class, revSig, workItem, authObj, externalStamp, comments, mfail) \
        _RejectExpediteUsrWorkAtClass(class, TRUE, revSig, workItem, authObj, externalStamp, comments, mfail)

#define RejectExpediteWork2(revSig, workItem, externalStamp, comments, mfail) \
        _RejectExpediteWork2AtClass(NULL, FALSE, revSig, workItem, externalStamp, comments, mfail)
#define RejectExpediteWork2AtClass(class, revSig, workItem, externalStamp, comments, mfail) \
        _RejectExpediteWork2AtClass(class, FALSE, revSig, workItem, externalStamp, comments, mfail)
#define RejectExpediteWork2AtParent(class, revSig, workItem, externalStamp, comments, mfail) \
        _RejectExpediteWork2AtClass(class, TRUE, revSig, workItem, externalStamp, comments, mfail)

#define RejectExpediteWork3(revSig, workItem, externalStamp, comments, mfail) \
        _RejectExpediteWork3AtClass(NULL, FALSE, revSig, workItem, externalStamp, comments, mfail)
#define RejectExpediteWork3AtClass(class, revSig, workItem, externalStamp, comments, mfail) \
        _RejectExpediteWork3AtClass(class, FALSE, revSig, workItem, externalStamp, comments, mfail)
#define RejectExpediteWork3AtParent(class, revSig, workItem, externalStamp, comments, mfail) \
        _RejectExpediteWork3AtClass(class, TRUE, revSig, workItem, externalStamp, comments, mfail)

#define RejectExpediteWorkDP(thisObj, itemObj, mfail) \
        _RejectExpediteWorkDPAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define RejectExpediteWorkDPAtClass(class, thisObj, itemObj, mfail) \
        _RejectExpediteWorkDPAtClass(class, FALSE, thisObj, itemObj, mfail)
#define RejectExpediteWorkDPAtParent(class, thisObj, itemObj, mfail) \
        _RejectExpediteWorkDPAtClass(class, TRUE, thisObj, itemObj, mfail)

#define RejectExpediteWorkP(revSig, workItem, mfail) \
        _RejectExpediteWorkPAtClass(NULL, FALSE, revSig, workItem, mfail)
#define RejectExpediteWorkPAtClass(class, revSig, workItem, mfail) \
        _RejectExpediteWorkPAtClass(class, FALSE, revSig, workItem, mfail)
#define RejectExpediteWorkPAtParent(class, revSig, workItem, mfail) \
        _RejectExpediteWorkPAtClass(class, TRUE, revSig, workItem, mfail)

#define RejectUsrWork(revSig, workItem, authObj, externalStamp, comments, mfail) \
        _RejectUsrWorkAtClass(NULL, FALSE, revSig, workItem, authObj, externalStamp, comments, mfail)
#define RejectUsrWorkAtClass(class, revSig, workItem, authObj, externalStamp, comments, mfail) \
        _RejectUsrWorkAtClass(class, FALSE, revSig, workItem, authObj, externalStamp, comments, mfail)
#define RejectUsrWorkAtParent(class, revSig, workItem, authObj, externalStamp, comments, mfail) \
        _RejectUsrWorkAtClass(class, TRUE, revSig, workItem, authObj, externalStamp, comments, mfail)

#define RejectWork2(revSig, workItem, externalStamp, comments, mfail) \
        _RejectWork2AtClass(NULL, FALSE, revSig, workItem, externalStamp, comments, mfail)
#define RejectWork2AtClass(class, revSig, workItem, externalStamp, comments, mfail) \
        _RejectWork2AtClass(class, FALSE, revSig, workItem, externalStamp, comments, mfail)
#define RejectWork2AtParent(class, revSig, workItem, externalStamp, comments, mfail) \
        _RejectWork2AtClass(class, TRUE, revSig, workItem, externalStamp, comments, mfail)

#define RejectWork3(revSig, workItem, externalStamp, comments, mfail) \
        _RejectWork3AtClass(NULL, FALSE, revSig, workItem, externalStamp, comments, mfail)
#define RejectWork3AtClass(class, revSig, workItem, externalStamp, comments, mfail) \
        _RejectWork3AtClass(class, FALSE, revSig, workItem, externalStamp, comments, mfail)
#define RejectWork3AtParent(class, revSig, workItem, externalStamp, comments, mfail) \
        _RejectWork3AtClass(class, TRUE, revSig, workItem, externalStamp, comments, mfail)

#define RejectWorkDP(thisObj, itemObj, mfail) \
        _RejectWorkDPAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define RejectWorkDPAtClass(class, thisObj, itemObj, mfail) \
        _RejectWorkDPAtClass(class, FALSE, thisObj, itemObj, mfail)
#define RejectWorkDPAtParent(class, thisObj, itemObj, mfail) \
        _RejectWorkDPAtClass(class, TRUE, thisObj, itemObj, mfail)

#define RejectWorkP(revSig, workItem, mfail) \
        _RejectWorkPAtClass(NULL, FALSE, revSig, workItem, mfail)
#define RejectWorkPAtClass(class, revSig, workItem, mfail) \
        _RejectWorkPAtClass(class, FALSE, revSig, workItem, mfail)
#define RejectWorkPAtParent(class, revSig, workItem, mfail) \
        _RejectWorkPAtClass(class, TRUE, revSig, workItem, mfail)

#define RemoveButton(thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _RemoveButtonAtClass(NULL, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define RemoveButtonAtClass(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _RemoveButtonAtClass(class, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define RemoveButtonAtParent(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _RemoveButtonAtClass(class, TRUE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)

#define ReplaceActor(thisObj, backgroundItem, selectedRelation, mfail) \
        _ReplaceActorAtClass(NULL, FALSE, thisObj, backgroundItem, selectedRelation, mfail)
#define ReplaceActorAtClass(class, thisObj, backgroundItem, selectedRelation, mfail) \
        _ReplaceActorAtClass(class, FALSE, thisObj, backgroundItem, selectedRelation, mfail)
#define ReplaceActorAtParent(class, thisObj, backgroundItem, selectedRelation, mfail) \
        _ReplaceActorAtClass(class, TRUE, thisObj, backgroundItem, selectedRelation, mfail)

#define ReplaceAdvExpandActor(className, inactiveParticp, workItemObj, inactivePrtcpObj, replaceParticp, replacePrtcpObj, haveCustomize, mfail) \
        _ReplaceAdvExpandActor(className, FALSE, className, inactiveParticp, workItemObj, inactivePrtcpObj, replaceParticp, replacePrtcpObj, haveCustomize, mfail)
#define ReplaceAdvExpandActorAtParent(_class, className, inactiveParticp, workItemObj, inactivePrtcpObj, replaceParticp, replacePrtcpObj, haveCustomize, mfail) \
        _ReplaceAdvExpandActor(_class, TRUE, className, inactiveParticp, workItemObj, inactivePrtcpObj, replaceParticp, replacePrtcpObj, haveCustomize, mfail)

#define ReplaceUsrForActor(thisObj, processObj, usrObj, mfail) \
        _ReplaceUsrForActorAtClass(NULL, FALSE, thisObj, processObj, usrObj, mfail)
#define ReplaceUsrForActorAtClass(class, thisObj, processObj, usrObj, mfail) \
        _ReplaceUsrForActorAtClass(class, FALSE, thisObj, processObj, usrObj, mfail)
#define ReplaceUsrForActorAtParent(class, thisObj, processObj, usrObj, mfail) \
        _ReplaceUsrForActorAtClass(class, TRUE, thisObj, processObj, usrObj, mfail)

#define RequeryForProcHist(className, optionTag, queryDialog, mfail) \
        _RequeryForProcHist(className, FALSE, className, optionTag, queryDialog, mfail)
#define RequeryForProcHistAtParent(_class, className, optionTag, queryDialog, mfail) \
        _RequeryForProcHist(_class, TRUE, className, optionTag, queryDialog, mfail)

#define RequeryWorklistD(className, optionTag, queryDialog, mfail) \
        _RequeryWorklistD(className, FALSE, className, optionTag, queryDialog, mfail)
#define RequeryWorklistDAtParent(_class, className, optionTag, queryDialog, mfail) \
        _RequeryWorklistD(_class, TRUE, className, optionTag, queryDialog, mfail)

#define ResumeProcHistCleanup(thisObj, itemObj, dialogObj, mfail) \
        _ResumeProcHistCleanupAtClass(NULL, FALSE, thisObj, itemObj, dialogObj, mfail)
#define ResumeProcHistCleanupAtClass(class, thisObj, itemObj, dialogObj, mfail) \
        _ResumeProcHistCleanupAtClass(class, FALSE, thisObj, itemObj, dialogObj, mfail)
#define ResumeProcHistCleanupAtParent(class, thisObj, itemObj, dialogObj, mfail) \
        _ResumeProcHistCleanupAtClass(class, TRUE, thisObj, itemObj, dialogObj, mfail)

#define ResumeProcessHistory(thisObj, comments, mfail) \
        _ResumeProcessHistoryAtClass(NULL, FALSE, thisObj, comments, mfail)
#define ResumeProcessHistoryAtClass(class, thisObj, comments, mfail) \
        _ResumeProcessHistoryAtClass(class, FALSE, thisObj, comments, mfail)
#define ResumeProcessHistoryAtParent(class, thisObj, comments, mfail) \
        _ResumeProcessHistoryAtClass(class, TRUE, thisObj, comments, mfail)

#define ResumeProcessHistoryP(thisObj, mfail) \
        _ResumeProcessHistoryPAtClass(NULL, FALSE, thisObj, mfail)
#define ResumeProcessHistoryPAtClass(class, thisObj, mfail) \
        _ResumeProcessHistoryPAtClass(class, FALSE, thisObj, mfail)
#define ResumeProcessHistoryPAtParent(class, thisObj, mfail) \
        _ResumeProcessHistoryPAtClass(class, TRUE, thisObj, mfail)

#define ReviseIfActiveUser(replaceUsrObj, replaceUser, userList, processParticips, newActiveUser, mfail) \
        _ReviseIfActiveUserAtClass(NULL, FALSE, replaceUsrObj, replaceUser, userList, processParticips, newActiveUser, mfail)
#define ReviseIfActiveUserAtClass(class, replaceUsrObj, replaceUser, userList, processParticips, newActiveUser, mfail) \
        _ReviseIfActiveUserAtClass(class, FALSE, replaceUsrObj, replaceUser, userList, processParticips, newActiveUser, mfail)
#define ReviseIfActiveUserAtParent(class, replaceUsrObj, replaceUser, userList, processParticips, newActiveUser, mfail) \
        _ReviseIfActiveUserAtClass(class, TRUE, replaceUsrObj, replaceUser, userList, processParticips, newActiveUser, mfail)

#define RouteWork(thisObj, rteObj, rteWorkDesc, rteAddList, rteCmts, rteContext, mfail) \
        _RouteWorkAtClass(NULL, FALSE, thisObj, rteObj, rteWorkDesc, rteAddList, rteCmts, rteContext, mfail)
#define RouteWorkAtClass(class, thisObj, rteObj, rteWorkDesc, rteAddList, rteCmts, rteContext, mfail) \
        _RouteWorkAtClass(class, FALSE, thisObj, rteObj, rteWorkDesc, rteAddList, rteCmts, rteContext, mfail)
#define RouteWorkAtParent(class, thisObj, rteObj, rteWorkDesc, rteAddList, rteCmts, rteContext, mfail) \
        _RouteWorkAtClass(class, TRUE, thisObj, rteObj, rteWorkDesc, rteAddList, rteCmts, rteContext, mfail)

#define RouteWorkDP(thisObj, mfail) \
        _RouteWorkDPAtClass(NULL, FALSE, thisObj, mfail)
#define RouteWorkDPAtClass(class, thisObj, mfail) \
        _RouteWorkDPAtClass(class, FALSE, thisObj, mfail)
#define RouteWorkDPAtParent(class, thisObj, mfail) \
        _RouteWorkDPAtClass(class, TRUE, thisObj, mfail)

#define SaveEdit(thisObj, contentSet, mfail) \
        _SaveEditAtClass(NULL, FALSE, thisObj, contentSet, mfail)
#define SaveEditAtClass(class, thisObj, contentSet, mfail) \
        _SaveEditAtClass(class, FALSE, thisObj, contentSet, mfail)
#define SaveEditAtParent(class, thisObj, contentSet, mfail) \
        _SaveEditAtClass(class, TRUE, thisObj, contentSet, mfail)

#define ScanCommentsForBrowser(className, sigObjects, mfail) \
        _ScanCommentsForBrowser(className, FALSE, className, sigObjects, mfail)
#define ScanCommentsForBrowserAtParent(_class, className, sigObjects, mfail) \
        _ScanCommentsForBrowser(_class, TRUE, className, sigObjects, mfail)

#define SendAutoProcSyncMsg(thisObj, messageName, itemObj, procHist, exitState, advComments, mfail) \
        _SendAutoProcSyncMsgAtClass(NULL, FALSE, thisObj, messageName, itemObj, procHist, exitState, advComments, mfail)
#define SendAutoProcSyncMsgAtClass(class, thisObj, messageName, itemObj, procHist, exitState, advComments, mfail) \
        _SendAutoProcSyncMsgAtClass(class, FALSE, thisObj, messageName, itemObj, procHist, exitState, advComments, mfail)
#define SendAutoProcSyncMsgAtParent(class, thisObj, messageName, itemObj, procHist, exitState, advComments, mfail) \
        _SendAutoProcSyncMsgAtClass(class, TRUE, thisObj, messageName, itemObj, procHist, exitState, advComments, mfail)

#define SetAhdTblDfltsForDlg(thisObj, originClassName, originObject, mfail) \
        _SetAhdTblDfltsForDlgAtClass(NULL, FALSE, thisObj, originClassName, originObject, mfail)
#define SetAhdTblDfltsForDlgAtClass(class, thisObj, originClassName, originObject, mfail) \
        _SetAhdTblDfltsForDlgAtClass(class, FALSE, thisObj, originClassName, originObject, mfail)
#define SetAhdTblDfltsForDlgAtParent(class, thisObj, originClassName, originObject, mfail) \
        _SetAhdTblDfltsForDlgAtClass(class, TRUE, thisObj, originClassName, originObject, mfail)

#define SetDiagramAttributes(className, objSet, mfail) \
        _SetDiagramAttributes(className, FALSE, className, objSet, mfail)
#define SetDiagramAttributesAtParent(_class, className, objSet, mfail) \
        _SetDiagramAttributes(_class, TRUE, className, objSet, mfail)

#define SetReAssignAttributes(thisObj, origSigObj, rasParticipObj, mfail) \
        _SetReAssignAttributesAtClass(NULL, FALSE, thisObj, origSigObj, rasParticipObj, mfail)
#define SetReAssignAttributesAtClass(class, thisObj, origSigObj, rasParticipObj, mfail) \
        _SetReAssignAttributesAtClass(class, FALSE, thisObj, origSigObj, rasParticipObj, mfail)
#define SetReAssignAttributesAtParent(class, thisObj, origSigObj, rasParticipObj, mfail) \
        _SetReAssignAttributesAtClass(class, TRUE, thisObj, origSigObj, rasParticipObj, mfail)

#define SetRevTabsAtSequence(thisObj, processObj, mfail) \
        _SetRevTabsAtSequenceAtClass(NULL, FALSE, thisObj, processObj, mfail)
#define SetRevTabsAtSequenceAtClass(class, thisObj, processObj, mfail) \
        _SetRevTabsAtSequenceAtClass(class, FALSE, thisObj, processObj, mfail)
#define SetRevTabsAtSequenceAtParent(class, thisObj, processObj, mfail) \
        _SetRevTabsAtSequenceAtClass(class, TRUE, thisObj, processObj, mfail)

#define SetSigAttributes(thisObj, actorObj, curParticipObj, originParticipObj, mfail) \
        _SetSigAttributesAtClass(NULL, FALSE, thisObj, actorObj, curParticipObj, originParticipObj, mfail)
#define SetSigAttributesAtClass(class, thisObj, actorObj, curParticipObj, originParticipObj, mfail) \
        _SetSigAttributesAtClass(class, FALSE, thisObj, actorObj, curParticipObj, originParticipObj, mfail)
#define SetSigAttributesAtParent(class, thisObj, actorObj, curParticipObj, originParticipObj, mfail) \
        _SetSigAttributesAtClass(class, TRUE, thisObj, actorObj, curParticipObj, originParticipObj, mfail)

#define SetTaskWorklistScope(taskItem, databases, mfail) \
        _SetTaskWorklistScopeAtClass(NULL, FALSE, taskItem, databases, mfail)
#define SetTaskWorklistScopeAtClass(class, taskItem, databases, mfail) \
        _SetTaskWorklistScopeAtClass(class, FALSE, taskItem, databases, mfail)
#define SetTaskWorklistScopeAtParent(class, taskItem, databases, mfail) \
        _SetTaskWorklistScopeAtClass(class, TRUE, taskItem, databases, mfail)

#define SetUpDlgForDrawProcess(processObj, workItem, procHistObj, drawDialogObj, mfail) \
        _SetUpDlgForDrawProcessAtClass(NULL, FALSE, processObj, workItem, procHistObj, drawDialogObj, mfail)
#define SetUpDlgForDrawProcessAtClass(class, processObj, workItem, procHistObj, drawDialogObj, mfail) \
        _SetUpDlgForDrawProcessAtClass(class, FALSE, processObj, workItem, procHistObj, drawDialogObj, mfail)
#define SetUpDlgForDrawProcessAtParent(class, processObj, workItem, procHistObj, drawDialogObj, mfail) \
        _SetUpDlgForDrawProcessAtClass(class, TRUE, processObj, workItem, procHistObj, drawDialogObj, mfail)

#define ShowAllProcsForStep(stepObj, lcObj, mfail) \
        _ShowAllProcsForStepAtClass(NULL, FALSE, stepObj, lcObj, mfail)
#define ShowAllProcsForStepAtClass(class, stepObj, lcObj, mfail) \
        _ShowAllProcsForStepAtClass(class, FALSE, stepObj, lcObj, mfail)
#define ShowAllProcsForStepAtParent(class, stepObj, lcObj, mfail) \
        _ShowAllProcsForStepAtClass(class, TRUE, stepObj, lcObj, mfail)

#define ShowHistory(thisObj, mfail) \
        _ShowHistoryAtClass(NULL, FALSE, thisObj, mfail)
#define ShowHistoryAtClass(class, thisObj, mfail) \
        _ShowHistoryAtClass(class, FALSE, thisObj, mfail)
#define ShowHistoryAtParent(class, thisObj, mfail) \
        _ShowHistoryAtClass(class, TRUE, thisObj, mfail)

#define ShowSigHistory(thisObj, mfail) \
        _ShowSigHistoryAtClass(NULL, FALSE, thisObj, mfail)
#define ShowSigHistoryAtClass(class, thisObj, mfail) \
        _ShowSigHistoryAtClass(class, FALSE, thisObj, mfail)
#define ShowSigHistoryAtParent(class, thisObj, mfail) \
        _ShowSigHistoryAtClass(class, TRUE, thisObj, mfail)

#define ShowSignoffHistory(thisObj, mfail) \
        _ShowSignoffHistoryAtClass(NULL, FALSE, thisObj, mfail)
#define ShowSignoffHistoryAtClass(class, thisObj, mfail) \
        _ShowSignoffHistoryAtClass(class, FALSE, thisObj, mfail)
#define ShowSignoffHistoryAtParent(class, thisObj, mfail) \
        _ShowSignoffHistoryAtClass(class, TRUE, thisObj, mfail)

#define ShowStepComments(stepObj, lcObj, mfail) \
        _ShowStepCommentsAtClass(NULL, FALSE, stepObj, lcObj, mfail)
#define ShowStepCommentsAtClass(class, stepObj, lcObj, mfail) \
        _ShowStepCommentsAtClass(class, FALSE, stepObj, lcObj, mfail)
#define ShowStepCommentsAtParent(class, stepObj, lcObj, mfail) \
        _ShowStepCommentsAtClass(class, TRUE, stepObj, lcObj, mfail)

#define SubmitItemSync(thisObj, lcObj, subCmts, mfail) \
        _SubmitItemSyncAtClass(NULL, FALSE, thisObj, lcObj, subCmts, mfail)
#define SubmitItemSyncAtClass(class, thisObj, lcObj, subCmts, mfail) \
        _SubmitItemSyncAtClass(class, FALSE, thisObj, lcObj, subCmts, mfail)
#define SubmitItemSyncAtParent(class, thisObj, lcObj, subCmts, mfail) \
        _SubmitItemSyncAtClass(class, TRUE, thisObj, lcObj, subCmts, mfail)

#define SubmitItemSyncInt(thisObj, lcObj, subCmts, mfail) \
        _SubmitItemSyncIntAtClass(NULL, FALSE, thisObj, lcObj, subCmts, mfail)
#define SubmitItemSyncIntAtClass(class, thisObj, lcObj, subCmts, mfail) \
        _SubmitItemSyncIntAtClass(class, FALSE, thisObj, lcObj, subCmts, mfail)
#define SubmitItemSyncIntAtParent(class, thisObj, lcObj, subCmts, mfail) \
        _SubmitItemSyncIntAtClass(class, TRUE, thisObj, lcObj, subCmts, mfail)

#define SubmitWork(thisObj, lcObj, subCmts, mfail) \
        _SubmitWorkAtClass(NULL, FALSE, thisObj, lcObj, subCmts, mfail)
#define SubmitWorkAtClass(class, thisObj, lcObj, subCmts, mfail) \
        _SubmitWorkAtClass(class, FALSE, thisObj, lcObj, subCmts, mfail)
#define SubmitWorkAtParent(class, thisObj, lcObj, subCmts, mfail) \
        _SubmitWorkAtClass(class, TRUE, thisObj, lcObj, subCmts, mfail)

#define SubmitWorkDP(thisObj, mfail) \
        _SubmitWorkDPAtClass(NULL, FALSE, thisObj, mfail)
#define SubmitWorkDPAtClass(class, thisObj, mfail) \
        _SubmitWorkDPAtClass(class, FALSE, thisObj, mfail)
#define SubmitWorkDPAtParent(class, thisObj, mfail) \
        _SubmitWorkDPAtClass(class, TRUE, thisObj, mfail)

#define TGenMultiSelAssignment(className, selectedRels, selectedItems, msgOptionTag, mfail) \
        _TGenMultiSelAssignment(className, FALSE, className, selectedRels, selectedItems, msgOptionTag, mfail)
#define TGenMultiSelAssignmentAtParent(_class, className, selectedRels, selectedItems, msgOptionTag, mfail) \
        _TGenMultiSelAssignment(_class, TRUE, className, selectedRels, selectedItems, msgOptionTag, mfail)

#define ToFailButton(thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _ToFailButtonAtClass(NULL, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define ToFailButtonAtClass(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _ToFailButtonAtClass(class, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define ToFailButtonAtParent(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _ToFailButtonAtClass(class, TRUE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)

#define ToSuccButton(thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _ToSuccButtonAtClass(NULL, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define ToSuccButtonAtClass(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _ToSuccButtonAtClass(class, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define ToSuccButtonAtParent(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _ToSuccButtonAtClass(class, TRUE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)

#define UnableToCompleteWork2(asgSig, workItem, externalStamp, comments, mfail) \
        _UnableToCompleteWork2AtClass(NULL, FALSE, asgSig, workItem, externalStamp, comments, mfail)
#define UnableToCompleteWork2AtClass(class, asgSig, workItem, externalStamp, comments, mfail) \
        _UnableToCompleteWork2AtClass(class, FALSE, asgSig, workItem, externalStamp, comments, mfail)
#define UnableToCompleteWork2AtParent(class, asgSig, workItem, externalStamp, comments, mfail) \
        _UnableToCompleteWork2AtClass(class, TRUE, asgSig, workItem, externalStamp, comments, mfail)

#define UnableToCompleteWork3(asgSig, workItem, externalStamp, comments, mfail) \
        _UnableToCompleteWork3AtClass(NULL, FALSE, asgSig, workItem, externalStamp, comments, mfail)
#define UnableToCompleteWork3AtClass(class, asgSig, workItem, externalStamp, comments, mfail) \
        _UnableToCompleteWork3AtClass(class, FALSE, asgSig, workItem, externalStamp, comments, mfail)
#define UnableToCompleteWork3AtParent(class, asgSig, workItem, externalStamp, comments, mfail) \
        _UnableToCompleteWork3AtClass(class, TRUE, asgSig, workItem, externalStamp, comments, mfail)

#define UnableToCompleteWorkDP(thisObj, itemObj, mfail) \
        _UnableToCompleteWorkDPAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define UnableToCompleteWorkDPAtClass(class, thisObj, itemObj, mfail) \
        _UnableToCompleteWorkDPAtClass(class, FALSE, thisObj, itemObj, mfail)
#define UnableToCompleteWorkDPAtParent(class, thisObj, itemObj, mfail) \
        _UnableToCompleteWorkDPAtClass(class, TRUE, thisObj, itemObj, mfail)

#define UnableToCompleteWorkP(asgSig, workItem, mfail) \
        _UnableToCompleteWorkPAtClass(NULL, FALSE, asgSig, workItem, mfail)
#define UnableToCompleteWorkPAtClass(class, asgSig, workItem, mfail) \
        _UnableToCompleteWorkPAtClass(class, FALSE, asgSig, workItem, mfail)
#define UnableToCompleteWorkPAtParent(class, asgSig, workItem, mfail) \
        _UnableToCompleteWorkPAtClass(class, TRUE, asgSig, workItem, mfail)

#define UnclaimUsrWork(thisObj, itemObj, mfail) \
        _UnclaimUsrWorkAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define UnclaimUsrWorkAtClass(class, thisObj, itemObj, mfail) \
        _UnclaimUsrWorkAtClass(class, FALSE, thisObj, itemObj, mfail)
#define UnclaimUsrWorkAtParent(class, thisObj, itemObj, mfail) \
        _UnclaimUsrWorkAtClass(class, TRUE, thisObj, itemObj, mfail)

#define UnclaimUsrWorkDP(thisObj, itemObj, mfail) \
        _UnclaimUsrWorkDPAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define UnclaimUsrWorkDPAtClass(class, thisObj, itemObj, mfail) \
        _UnclaimUsrWorkDPAtClass(class, FALSE, thisObj, itemObj, mfail)
#define UnclaimUsrWorkDPAtParent(class, thisObj, itemObj, mfail) \
        _UnclaimUsrWorkDPAtClass(class, TRUE, thisObj, itemObj, mfail)

#define UpdAdHcDataForStepInt(thisObj, stepName, processName, duration, resource, schStartDate, schEndDate, stepStatus, actStartDate, actEndDate, mfail) \
        _UpdAdHcDataForStepIntAtClass(NULL, FALSE, thisObj, stepName, processName, duration, resource, schStartDate, schEndDate, stepStatus, actStartDate, actEndDate, mfail)
#define UpdAdHcDataForStepIntAtClass(class, thisObj, stepName, processName, duration, resource, schStartDate, schEndDate, stepStatus, actStartDate, actEndDate, mfail) \
        _UpdAdHcDataForStepIntAtClass(class, FALSE, thisObj, stepName, processName, duration, resource, schStartDate, schEndDate, stepStatus, actStartDate, actEndDate, mfail)
#define UpdAdHcDataForStepIntAtParent(class, thisObj, stepName, processName, duration, resource, schStartDate, schEndDate, stepStatus, actStartDate, actEndDate, mfail) \
        _UpdAdHcDataForStepIntAtClass(class, TRUE, thisObj, stepName, processName, duration, resource, schStartDate, schEndDate, stepStatus, actStartDate, actEndDate, mfail)

#define UpdPrcHistFromAdHcData(thisObj, adHcDataObj, mfail) \
        _UpdPrcHistFromAdHcDataAtClass(NULL, FALSE, thisObj, adHcDataObj, mfail)
#define UpdPrcHistFromAdHcDataAtClass(class, thisObj, adHcDataObj, mfail) \
        _UpdPrcHistFromAdHcDataAtClass(class, FALSE, thisObj, adHcDataObj, mfail)
#define UpdPrcHistFromAdHcDataAtParent(class, thisObj, adHcDataObj, mfail) \
        _UpdPrcHistFromAdHcDataAtClass(class, TRUE, thisObj, adHcDataObj, mfail)

#define UpdPrhWithAHDataCommnt(thisObj, mfail) \
        _UpdPrhWithAHDataCommntAtClass(NULL, FALSE, thisObj, mfail)
#define UpdPrhWithAHDataCommntAtClass(class, thisObj, mfail) \
        _UpdPrhWithAHDataCommntAtClass(class, FALSE, thisObj, mfail)
#define UpdPrhWithAHDataCommntAtParent(class, thisObj, mfail) \
        _UpdPrhWithAHDataCommntAtClass(class, TRUE, thisObj, mfail)

#define UpdateAdHcDataForStep(thisObj, stepName, processName, duration, resource, schStartDate, schEndDate, mfail) \
        _UpdateAdHcDataForStepAtClass(NULL, FALSE, thisObj, stepName, processName, duration, resource, schStartDate, schEndDate, mfail)
#define UpdateAdHcDataForStepAtClass(class, thisObj, stepName, processName, duration, resource, schStartDate, schEndDate, mfail) \
        _UpdateAdHcDataForStepAtClass(class, FALSE, thisObj, stepName, processName, duration, resource, schStartDate, schEndDate, mfail)
#define UpdateAdHcDataForStepAtParent(class, thisObj, stepName, processName, duration, resource, schStartDate, schEndDate, mfail) \
        _UpdateAdHcDataForStepAtClass(class, TRUE, thisObj, stepName, processName, duration, resource, schStartDate, schEndDate, mfail)

#define UpdateAdHcDataStepExit(thisObj, procHist, mfail) \
        _UpdateAdHcDataStepExitAtClass(NULL, FALSE, thisObj, procHist, mfail)
#define UpdateAdHcDataStepExitAtClass(class, thisObj, procHist, mfail) \
        _UpdateAdHcDataStepExitAtClass(class, FALSE, thisObj, procHist, mfail)
#define UpdateAdHcDataStepExitAtParent(class, thisObj, procHist, mfail) \
        _UpdateAdHcDataStepExitAtClass(class, TRUE, thisObj, procHist, mfail)

#define UpdateAttrOnReAssign(itemObj, updateAttrb, sigObj, mfail) \
        _UpdateAttrOnReAssignAtClass(NULL, FALSE, itemObj, updateAttrb, sigObj, mfail)
#define UpdateAttrOnReAssignAtClass(class, itemObj, updateAttrb, sigObj, mfail) \
        _UpdateAttrOnReAssignAtClass(class, FALSE, itemObj, updateAttrb, sigObj, mfail)
#define UpdateAttrOnReAssignAtParent(class, itemObj, updateAttrb, sigObj, mfail) \
        _UpdateAttrOnReAssignAtClass(class, TRUE, itemObj, updateAttrb, sigObj, mfail)

#define UpdateCtxtForWbpExpand(workItem, relationship, expCtxtObj, mfail) \
        _UpdateCtxtForWbpExpandAtClass(NULL, FALSE, workItem, relationship, expCtxtObj, mfail)
#define UpdateCtxtForWbpExpandAtClass(class, workItem, relationship, expCtxtObj, mfail) \
        _UpdateCtxtForWbpExpandAtClass(class, FALSE, workItem, relationship, expCtxtObj, mfail)
#define UpdateCtxtForWbpExpandAtParent(class, workItem, relationship, expCtxtObj, mfail) \
        _UpdateCtxtForWbpExpandAtClass(class, TRUE, workItem, relationship, expCtxtObj, mfail)

#define UpdateEffStepProcess(stepObj, lcObj, mfail) \
        _UpdateEffStepProcessAtClass(NULL, FALSE, stepObj, lcObj, mfail)
#define UpdateEffStepProcessAtClass(class, stepObj, lcObj, mfail) \
        _UpdateEffStepProcessAtClass(class, FALSE, stepObj, lcObj, mfail)
#define UpdateEffStepProcessAtParent(class, stepObj, lcObj, mfail) \
        _UpdateEffStepProcessAtClass(class, TRUE, stepObj, lcObj, mfail)

#define UpdateEffectiveDates(thisObj, mfail) \
        _UpdateEffectiveDatesAtClass(NULL, FALSE, thisObj, mfail)
#define UpdateEffectiveDatesAtClass(class, thisObj, mfail) \
        _UpdateEffectiveDatesAtClass(class, FALSE, thisObj, mfail)
#define UpdateEffectiveDatesAtParent(class, thisObj, mfail) \
        _UpdateEffectiveDatesAtClass(class, TRUE, thisObj, mfail)

#define UpdateObjectEffDates(thisObj, effectiveOnFrom, effectiveOnTo, mfail) \
        _UpdateObjectEffDatesAtClass(NULL, FALSE, thisObj, effectiveOnFrom, effectiveOnTo, mfail)
#define UpdateObjectEffDatesAtClass(class, thisObj, effectiveOnFrom, effectiveOnTo, mfail) \
        _UpdateObjectEffDatesAtClass(class, FALSE, thisObj, effectiveOnFrom, effectiveOnTo, mfail)
#define UpdateObjectEffDatesAtParent(class, thisObj, effectiveOnFrom, effectiveOnTo, mfail) \
        _UpdateObjectEffDatesAtClass(class, TRUE, thisObj, effectiveOnFrom, effectiveOnTo, mfail)

#define UpdateParticipAttrOK(itemObj, updateAttrb, sigObj, isOkToUpdate, mfail) \
        _UpdateParticipAttrOKAtClass(NULL, FALSE, itemObj, updateAttrb, sigObj, isOkToUpdate, mfail)
#define UpdateParticipAttrOKAtClass(class, itemObj, updateAttrb, sigObj, isOkToUpdate, mfail) \
        _UpdateParticipAttrOKAtClass(class, FALSE, itemObj, updateAttrb, sigObj, isOkToUpdate, mfail)
#define UpdateParticipAttrOKAtParent(class, itemObj, updateAttrb, sigObj, isOkToUpdate, mfail) \
        _UpdateParticipAttrOKAtClass(class, TRUE, itemObj, updateAttrb, sigObj, isOkToUpdate, mfail)

#define UpdateRevTabulation(thisObj, mfail) \
        _UpdateRevTabulationAtClass(NULL, FALSE, thisObj, mfail)
#define UpdateRevTabulationAtClass(class, thisObj, mfail) \
        _UpdateRevTabulationAtClass(class, FALSE, thisObj, mfail)
#define UpdateRevTabulationAtParent(class, thisObj, mfail) \
        _UpdateRevTabulationAtClass(class, TRUE, thisObj, mfail)

#define Upgrade2LCMLCStep(thisObj, execMode, traceMode, mfail) \
        _Upgrade2LCMLCStepAtClass(NULL, FALSE, thisObj, execMode, traceMode, mfail)
#define Upgrade2LCMLCStepAtClass(class, thisObj, execMode, traceMode, mfail) \
        _Upgrade2LCMLCStepAtClass(class, FALSE, thisObj, execMode, traceMode, mfail)
#define Upgrade2LCMLCStepAtParent(class, thisObj, execMode, traceMode, mfail) \
        _Upgrade2LCMLCStepAtClass(class, TRUE, thisObj, execMode, traceMode, mfail)

#define UseButton(thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _UseButtonAtClass(NULL, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define UseButtonAtClass(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _UseButtonAtClass(class, FALSE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)
#define UseButtonAtParent(class, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail) \
        _UseButtonAtClass(class, TRUE, thisObj, originClassName, option, originObject, extraStr, extraObj, keepInteracting, mfail)

#define ValAcknowledgeWorkExt(rcpSig, workitem, mfail) \
        _ValAcknowledgeWorkExtAtClass(NULL, FALSE, rcpSig, workitem, mfail)
#define ValAcknowledgeWorkExtAtClass(class, rcpSig, workitem, mfail) \
        _ValAcknowledgeWorkExtAtClass(class, FALSE, rcpSig, workitem, mfail)
#define ValAcknowledgeWorkExtAtParent(class, rcpSig, workitem, mfail) \
        _ValAcknowledgeWorkExtAtClass(class, TRUE, rcpSig, workitem, mfail)

#define ValAhdItemForCreAhr(ahdItem, adhcDataRel, mfail) \
        _ValAhdItemForCreAhrAtClass(NULL, FALSE, ahdItem, adhcDataRel, mfail)
#define ValAhdItemForCreAhrAtClass(class, ahdItem, adhcDataRel, mfail) \
        _ValAhdItemForCreAhrAtClass(class, FALSE, ahdItem, adhcDataRel, mfail)
#define ValAhdItemForCreAhrAtParent(class, ahdItem, adhcDataRel, mfail) \
        _ValAhdItemForCreAhrAtClass(class, TRUE, ahdItem, adhcDataRel, mfail)

#define ValApproveWorkExt(revSig, workitem, mfail) \
        _ValApproveWorkExtAtClass(NULL, FALSE, revSig, workitem, mfail)
#define ValApproveWorkExtAtClass(class, revSig, workitem, mfail) \
        _ValApproveWorkExtAtClass(class, FALSE, revSig, workitem, mfail)
#define ValApproveWorkExtAtParent(class, revSig, workitem, mfail) \
        _ValApproveWorkExtAtClass(class, TRUE, revSig, workitem, mfail)

#define ValAuxOnlineForSubmit(thisObj, itemObj, mfail) \
        _ValAuxOnlineForSubmitAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define ValAuxOnlineForSubmitAtClass(class, thisObj, itemObj, mfail) \
        _ValAuxOnlineForSubmitAtClass(class, FALSE, thisObj, itemObj, mfail)
#define ValAuxOnlineForSubmitAtParent(class, thisObj, itemObj, mfail) \
        _ValAuxOnlineForSubmitAtClass(class, TRUE, thisObj, itemObj, mfail)

#define ValClaimAssignExt(actvSig, workitem, mfail) \
        _ValClaimAssignExtAtClass(NULL, FALSE, actvSig, workitem, mfail)
#define ValClaimAssignExtAtClass(class, actvSig, workitem, mfail) \
        _ValClaimAssignExtAtClass(class, FALSE, actvSig, workitem, mfail)
#define ValClaimAssignExtAtParent(class, actvSig, workitem, mfail) \
        _ValClaimAssignExtAtClass(class, TRUE, actvSig, workitem, mfail)

#define ValCompleteWorkExt(asgSig, workitem, mfail) \
        _ValCompleteWorkExtAtClass(NULL, FALSE, asgSig, workitem, mfail)
#define ValCompleteWorkExtAtClass(class, asgSig, workitem, mfail) \
        _ValCompleteWorkExtAtClass(class, FALSE, asgSig, workitem, mfail)
#define ValCompleteWorkExtAtParent(class, asgSig, workitem, mfail) \
        _ValCompleteWorkExtAtClass(class, TRUE, asgSig, workitem, mfail)

#define ValDirContentForSubmit(thisObj, itemObj, mfail) \
        _ValDirContentForSubmitAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define ValDirContentForSubmitAtClass(class, thisObj, itemObj, mfail) \
        _ValDirContentForSubmitAtClass(class, FALSE, thisObj, itemObj, mfail)
#define ValDirContentForSubmitAtParent(class, thisObj, itemObj, mfail) \
        _ValDirContentForSubmitAtClass(class, TRUE, thisObj, itemObj, mfail)

#define ValDomainForDrawHist(thisObj, isLocal, mfail) \
        _ValDomainForDrawHistAtClass(NULL, FALSE, thisObj, isLocal, mfail)
#define ValDomainForDrawHistAtClass(class, thisObj, isLocal, mfail) \
        _ValDomainForDrawHistAtClass(class, FALSE, thisObj, isLocal, mfail)
#define ValDomainForDrawHistAtParent(class, thisObj, isLocal, mfail) \
        _ValDomainForDrawHistAtClass(class, TRUE, thisObj, isLocal, mfail)

#define ValDomainForRoute(thisObj, isLocal, mfail) \
        _ValDomainForRouteAtClass(NULL, FALSE, thisObj, isLocal, mfail)
#define ValDomainForRouteAtClass(class, thisObj, isLocal, mfail) \
        _ValDomainForRouteAtClass(class, FALSE, thisObj, isLocal, mfail)
#define ValDomainForRouteAtParent(class, thisObj, isLocal, mfail) \
        _ValDomainForRouteAtClass(class, TRUE, thisObj, isLocal, mfail)

#define ValDomainForShowHist(thisObj, isLocal, mfail) \
        _ValDomainForShowHistAtClass(NULL, FALSE, thisObj, isLocal, mfail)
#define ValDomainForShowHistAtClass(class, thisObj, isLocal, mfail) \
        _ValDomainForShowHistAtClass(class, FALSE, thisObj, isLocal, mfail)
#define ValDomainForShowHistAtParent(class, thisObj, isLocal, mfail) \
        _ValDomainForShowHistAtClass(class, TRUE, thisObj, isLocal, mfail)

#define ValDomainForSignHist(thisObj, isLocal, mfail) \
        _ValDomainForSignHistAtClass(NULL, FALSE, thisObj, isLocal, mfail)
#define ValDomainForSignHistAtClass(class, thisObj, isLocal, mfail) \
        _ValDomainForSignHistAtClass(class, FALSE, thisObj, isLocal, mfail)
#define ValDomainForSignHistAtParent(class, thisObj, isLocal, mfail) \
        _ValDomainForSignHistAtClass(class, TRUE, thisObj, isLocal, mfail)

#define ValDomainForSubmit(thisObj, isLocal, mfail) \
        _ValDomainForSubmitAtClass(NULL, FALSE, thisObj, isLocal, mfail)
#define ValDomainForSubmitAtClass(class, thisObj, isLocal, mfail) \
        _ValDomainForSubmitAtClass(class, FALSE, thisObj, isLocal, mfail)
#define ValDomainForSubmitAtParent(class, thisObj, isLocal, mfail) \
        _ValDomainForSubmitAtClass(class, TRUE, thisObj, isLocal, mfail)

#define ValExpediteApproveWExt(revSig, workitem, mfail) \
        _ValExpediteApproveWExtAtClass(NULL, FALSE, revSig, workitem, mfail)
#define ValExpediteApproveWExtAtClass(class, revSig, workitem, mfail) \
        _ValExpediteApproveWExtAtClass(class, FALSE, revSig, workitem, mfail)
#define ValExpediteApproveWExtAtParent(class, revSig, workitem, mfail) \
        _ValExpediteApproveWExtAtClass(class, TRUE, revSig, workitem, mfail)

#define ValExpediteRejectWExt(revSig, workitem, mfail) \
        _ValExpediteRejectWExtAtClass(NULL, FALSE, revSig, workitem, mfail)
#define ValExpediteRejectWExtAtClass(class, revSig, workitem, mfail) \
        _ValExpediteRejectWExtAtClass(class, FALSE, revSig, workitem, mfail)
#define ValExpediteRejectWExtAtParent(class, revSig, workitem, mfail) \
        _ValExpediteRejectWExtAtClass(class, TRUE, revSig, workitem, mfail)

#define ValForAsgnRevwListExt(itemObj, mfail) \
        _ValForAsgnRevwListExtAtClass(NULL, FALSE, itemObj, mfail)
#define ValForAsgnRevwListExtAtClass(class, itemObj, mfail) \
        _ValForAsgnRevwListExtAtClass(class, FALSE, itemObj, mfail)
#define ValForAsgnRevwListExtAtParent(class, itemObj, mfail) \
        _ValForAsgnRevwListExtAtClass(class, TRUE, itemObj, mfail)

#define ValForAssignReviewList(itemObj, mfail) \
        _ValForAssignReviewListAtClass(NULL, FALSE, itemObj, mfail)
#define ValForAssignReviewListAtClass(class, itemObj, mfail) \
        _ValForAssignReviewListAtClass(class, FALSE, itemObj, mfail)
#define ValForAssignReviewListAtParent(class, itemObj, mfail) \
        _ValForAssignReviewListAtClass(class, TRUE, itemObj, mfail)

#define ValForFrozenSuperseded(thisObj, mfail) \
        _ValForFrozenSupersededAtClass(NULL, FALSE, thisObj, mfail)
#define ValForFrozenSupersededAtClass(class, thisObj, mfail) \
        _ValForFrozenSupersededAtClass(class, FALSE, thisObj, mfail)
#define ValForFrozenSupersededAtParent(class, thisObj, mfail) \
        _ValForFrozenSupersededAtClass(class, TRUE, thisObj, mfail)

#define ValForManageSigExt(thisObj, lcmAdminMode, mfail) \
        _ValForManageSigExtAtClass(NULL, FALSE, thisObj, lcmAdminMode, mfail)
#define ValForManageSigExtAtClass(class, thisObj, lcmAdminMode, mfail) \
        _ValForManageSigExtAtClass(class, FALSE, thisObj, lcmAdminMode, mfail)
#define ValForManageSigExtAtParent(class, thisObj, lcmAdminMode, mfail) \
        _ValForManageSigExtAtClass(class, TRUE, thisObj, lcmAdminMode, mfail)

#define ValForOpenExt(sig, workitem, mfail) \
        _ValForOpenExtAtClass(NULL, FALSE, sig, workitem, mfail)
#define ValForOpenExtAtClass(class, sig, workitem, mfail) \
        _ValForOpenExtAtClass(class, FALSE, sig, workitem, mfail)
#define ValForOpenExtAtParent(class, sig, workitem, mfail) \
        _ValForOpenExtAtClass(class, TRUE, sig, workitem, mfail)

#define ValForProcessHistExt(workItem, mfail) \
        _ValForProcessHistExtAtClass(NULL, FALSE, workItem, mfail)
#define ValForProcessHistExtAtClass(class, workItem, mfail) \
        _ValForProcessHistExtAtClass(class, FALSE, workItem, mfail)
#define ValForProcessHistExtAtParent(class, workItem, mfail) \
        _ValForProcessHistExtAtClass(class, TRUE, workItem, mfail)

#define ValForQueryWorkList(worklistClassName, worklistType, mfail) \
        _ValForQueryWorkList(worklistClassName, FALSE, worklistClassName, worklistType, mfail)
#define ValForQueryWorkListAtParent(_class, worklistClassName, worklistType, mfail) \
        _ValForQueryWorkList(_class, TRUE, worklistClassName, worklistType, mfail)

#define ValForReplaceActor(thisObj, processObj, actorObj, mfail) \
        _ValForReplaceActorAtClass(NULL, FALSE, thisObj, processObj, actorObj, mfail)
#define ValForReplaceActorAtClass(class, thisObj, processObj, actorObj, mfail) \
        _ValForReplaceActorAtClass(class, FALSE, thisObj, processObj, actorObj, mfail)
#define ValForReplaceActorAtParent(class, thisObj, processObj, actorObj, mfail) \
        _ValForReplaceActorAtClass(class, TRUE, thisObj, processObj, actorObj, mfail)

#define ValForSignoffHistExt(workItem, mfail) \
        _ValForSignoffHistExtAtClass(NULL, FALSE, workItem, mfail)
#define ValForSignoffHistExtAtClass(class, workItem, mfail) \
        _ValForSignoffHistExtAtClass(class, FALSE, workItem, mfail)
#define ValForSignoffHistExtAtParent(class, workItem, mfail) \
        _ValForSignoffHistExtAtClass(class, TRUE, workItem, mfail)

#define ValForSubmitUMHExt(workItem, mfail) \
        _ValForSubmitUMHExtAtClass(NULL, FALSE, workItem, mfail)
#define ValForSubmitUMHExtAtClass(class, workItem, mfail) \
        _ValForSubmitUMHExtAtClass(class, FALSE, workItem, mfail)
#define ValForSubmitUMHExtAtParent(class, workItem, mfail) \
        _ValForSubmitUMHExtAtClass(class, TRUE, workItem, mfail)

#define ValForUnclaimAssign(thisObj, itemObj, mfail) \
        _ValForUnclaimAssignAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define ValForUnclaimAssignAtClass(class, thisObj, itemObj, mfail) \
        _ValForUnclaimAssignAtClass(class, FALSE, thisObj, itemObj, mfail)
#define ValForUnclaimAssignAtParent(class, thisObj, itemObj, mfail) \
        _ValForUnclaimAssignAtClass(class, TRUE, thisObj, itemObj, mfail)

#define ValForWCCSubmitExt(workItem, mfail) \
        _ValForWCCSubmitExtAtClass(NULL, FALSE, workItem, mfail)
#define ValForWCCSubmitExtAtClass(class, workItem, mfail) \
        _ValForWCCSubmitExtAtClass(class, FALSE, workItem, mfail)
#define ValForWCCSubmitExtAtParent(class, workItem, mfail) \
        _ValForWCCSubmitExtAtClass(class, TRUE, workItem, mfail)

#define ValNotCompleteWorkExt(asgSig, workitem, mfail) \
        _ValNotCompleteWorkExtAtClass(NULL, FALSE, asgSig, workitem, mfail)
#define ValNotCompleteWorkExtAtClass(class, asgSig, workitem, mfail) \
        _ValNotCompleteWorkExtAtClass(class, FALSE, asgSig, workitem, mfail)
#define ValNotCompleteWorkExtAtParent(class, asgSig, workitem, mfail) \
        _ValNotCompleteWorkExtAtClass(class, TRUE, asgSig, workitem, mfail)

#define ValNotOkWorkExt(avrSig, workitem, mfail) \
        _ValNotOkWorkExtAtClass(NULL, FALSE, avrSig, workitem, mfail)
#define ValNotOkWorkExtAtClass(class, avrSig, workitem, mfail) \
        _ValNotOkWorkExtAtClass(class, FALSE, avrSig, workitem, mfail)
#define ValNotOkWorkExtAtParent(class, avrSig, workitem, mfail) \
        _ValNotOkWorkExtAtClass(class, TRUE, avrSig, workitem, mfail)

#define ValOkWorkExt(avrSig, workitem, mfail) \
        _ValOkWorkExtAtClass(NULL, FALSE, avrSig, workitem, mfail)
#define ValOkWorkExtAtClass(class, avrSig, workitem, mfail) \
        _ValOkWorkExtAtClass(class, FALSE, avrSig, workitem, mfail)
#define ValOkWorkExtAtParent(class, avrSig, workitem, mfail) \
        _ValOkWorkExtAtClass(class, TRUE, avrSig, workitem, mfail)

#define ValPtcpForQryWorkList(taskObj, worklistFilterObj, mfail) \
        _ValPtcpForQryWorkListAtClass(NULL, FALSE, taskObj, worklistFilterObj, mfail)
#define ValPtcpForQryWorkListAtClass(class, taskObj, worklistFilterObj, mfail) \
        _ValPtcpForQryWorkListAtClass(class, FALSE, taskObj, worklistFilterObj, mfail)
#define ValPtcpForQryWorkListAtParent(class, taskObj, worklistFilterObj, mfail) \
        _ValPtcpForQryWorkListAtClass(class, TRUE, taskObj, worklistFilterObj, mfail)

#define ValReAssignAltWorkExt(sig, workitem, mfail) \
        _ValReAssignAltWorkExtAtClass(NULL, FALSE, sig, workitem, mfail)
#define ValReAssignAltWorkExtAtClass(class, sig, workitem, mfail) \
        _ValReAssignAltWorkExtAtClass(class, FALSE, sig, workitem, mfail)
#define ValReAssignAltWorkExtAtParent(class, sig, workitem, mfail) \
        _ValReAssignAltWorkExtAtClass(class, TRUE, sig, workitem, mfail)

#define ValReAssignWorkExt(sig, workitem, mfail) \
        _ValReAssignWorkExtAtClass(NULL, FALSE, sig, workitem, mfail)
#define ValReAssignWorkExtAtClass(class, sig, workitem, mfail) \
        _ValReAssignWorkExtAtClass(class, FALSE, sig, workitem, mfail)
#define ValReAssignWorkExtAtParent(class, sig, workitem, mfail) \
        _ValReAssignWorkExtAtClass(class, TRUE, sig, workitem, mfail)

#define ValRejectWorkExt(revSig, workitem, mfail) \
        _ValRejectWorkExtAtClass(NULL, FALSE, revSig, workitem, mfail)
#define ValRejectWorkExtAtClass(class, revSig, workitem, mfail) \
        _ValRejectWorkExtAtClass(class, FALSE, revSig, workitem, mfail)
#define ValRejectWorkExtAtParent(class, revSig, workitem, mfail) \
        _ValRejectWorkExtAtClass(class, TRUE, revSig, workitem, mfail)

#define ValSubmitUMHDialogExt(workItem, lifeCycleObj, destinationVault, mfail) \
        _ValSubmitUMHDialogExtAtClass(NULL, FALSE, workItem, lifeCycleObj, destinationVault, mfail)
#define ValSubmitUMHDialogExtAtClass(class, workItem, lifeCycleObj, destinationVault, mfail) \
        _ValSubmitUMHDialogExtAtClass(class, FALSE, workItem, lifeCycleObj, destinationVault, mfail)
#define ValSubmitUMHDialogExtAtParent(class, workItem, lifeCycleObj, destinationVault, mfail) \
        _ValSubmitUMHDialogExtAtClass(class, TRUE, workItem, lifeCycleObj, destinationVault, mfail)

#define ValUnclaimAssignExt(actvSig, workitem, mfail) \
        _ValUnclaimAssignExtAtClass(NULL, FALSE, actvSig, workitem, mfail)
#define ValUnclaimAssignExtAtClass(class, actvSig, workitem, mfail) \
        _ValUnclaimAssignExtAtClass(class, FALSE, actvSig, workitem, mfail)
#define ValUnclaimAssignExtAtParent(class, actvSig, workitem, mfail) \
        _ValUnclaimAssignExtAtClass(class, TRUE, actvSig, workitem, mfail)

#define ValWrkItemForCreAhr(wrkItem, adhcDataRel, mfail) \
        _ValWrkItemForCreAhrAtClass(NULL, FALSE, wrkItem, adhcDataRel, mfail)
#define ValWrkItemForCreAhrAtClass(class, wrkItem, adhcDataRel, mfail) \
        _ValWrkItemForCreAhrAtClass(class, FALSE, wrkItem, adhcDataRel, mfail)
#define ValWrkItemForCreAhrAtParent(class, wrkItem, adhcDataRel, mfail) \
        _ValWrkItemForCreAhrAtClass(class, TRUE, wrkItem, adhcDataRel, mfail)

#define ValidateAbortProcHist(thisObj, itemObj, mfail) \
        _ValidateAbortProcHistAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define ValidateAbortProcHistAtClass(class, thisObj, itemObj, mfail) \
        _ValidateAbortProcHistAtClass(class, FALSE, thisObj, itemObj, mfail)
#define ValidateAbortProcHistAtParent(class, thisObj, itemObj, mfail) \
        _ValidateAbortProcHistAtClass(class, TRUE, thisObj, itemObj, mfail)

#define ValidateAbortWorkItem(thisObj, mfail) \
        _ValidateAbortWorkItemAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateAbortWorkItemAtClass(class, thisObj, mfail) \
        _ValidateAbortWorkItemAtClass(class, FALSE, thisObj, mfail)
#define ValidateAbortWorkItemAtParent(class, thisObj, mfail) \
        _ValidateAbortWorkItemAtClass(class, TRUE, thisObj, mfail)

#define ValidateAuxForSubmit(thisObj, mfail) \
        _ValidateAuxForSubmitAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateAuxForSubmitAtClass(class, thisObj, mfail) \
        _ValidateAuxForSubmitAtClass(class, FALSE, thisObj, mfail)
#define ValidateAuxForSubmitAtParent(class, thisObj, mfail) \
        _ValidateAuxForSubmitAtClass(class, TRUE, thisObj, mfail)

#define ValidateBranchDefTable(thisObj, dialogObj, badArgs, mfail) \
        _ValidateBranchDefTableAtClass(NULL, FALSE, thisObj, dialogObj, badArgs, mfail)
#define ValidateBranchDefTableAtClass(class, thisObj, dialogObj, badArgs, mfail) \
        _ValidateBranchDefTableAtClass(class, FALSE, thisObj, dialogObj, badArgs, mfail)
#define ValidateBranchDefTableAtParent(class, thisObj, dialogObj, badArgs, mfail) \
        _ValidateBranchDefTableAtClass(class, TRUE, thisObj, dialogObj, badArgs, mfail)

#define ValidateCalEffectivity(className, dialogObj, badArgs, mfail) \
        _ValidateCalEffectivity(className, FALSE, className, dialogObj, badArgs, mfail)
#define ValidateCalEffectivityAtParent(_class, className, dialogObj, badArgs, mfail) \
        _ValidateCalEffectivity(_class, TRUE, className, dialogObj, badArgs, mfail)

#define ValidateCkoForAdvance(thisObj, mfail) \
        _ValidateCkoForAdvanceAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateCkoForAdvanceAtClass(class, thisObj, mfail) \
        _ValidateCkoForAdvanceAtClass(class, FALSE, thisObj, mfail)
#define ValidateCkoForAdvanceAtParent(class, thisObj, mfail) \
        _ValidateCkoForAdvanceAtClass(class, TRUE, thisObj, mfail)

#define ValidateDrawProcessExt(processObj, mfail) \
        _ValidateDrawProcessExtAtClass(NULL, FALSE, processObj, mfail)
#define ValidateDrawProcessExtAtClass(class, processObj, mfail) \
        _ValidateDrawProcessExtAtClass(class, FALSE, processObj, mfail)
#define ValidateDrawProcessExtAtParent(class, processObj, mfail) \
        _ValidateDrawProcessExtAtClass(class, TRUE, processObj, mfail)

#define ValidateEdit(thisObj, contentSet, mfail) \
        _ValidateEditAtClass(NULL, FALSE, thisObj, contentSet, mfail)
#define ValidateEditAtClass(class, thisObj, contentSet, mfail) \
        _ValidateEditAtClass(class, FALSE, thisObj, contentSet, mfail)
#define ValidateEditAtParent(class, thisObj, contentSet, mfail) \
        _ValidateEditAtClass(class, TRUE, thisObj, contentSet, mfail)

#define ValidateEditProcess(thisObj, mfail) \
        _ValidateEditProcessAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateEditProcessAtClass(class, thisObj, mfail) \
        _ValidateEditProcessAtClass(class, FALSE, thisObj, mfail)
#define ValidateEditProcessAtParent(class, thisObj, mfail) \
        _ValidateEditProcessAtClass(class, TRUE, thisObj, mfail)

#define ValidateExpireActions(className, dialogObj, badArgs, mfail) \
        _ValidateExpireActions(className, FALSE, className, dialogObj, badArgs, mfail)
#define ValidateExpireActionsAtParent(_class, className, dialogObj, badArgs, mfail) \
        _ValidateExpireActions(_class, TRUE, className, dialogObj, badArgs, mfail)

#define ValidateExpireDays(thisObj, mfail) \
        _ValidateExpireDaysAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateExpireDaysAtClass(class, thisObj, mfail) \
        _ValidateExpireDaysAtClass(class, FALSE, thisObj, mfail)
#define ValidateExpireDaysAtParent(class, thisObj, mfail) \
        _ValidateExpireDaysAtClass(class, TRUE, thisObj, mfail)

#define ValidateForClaimAssign(thisObj, itemObj, mfail) \
        _ValidateForClaimAssignAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define ValidateForClaimAssignAtClass(class, thisObj, itemObj, mfail) \
        _ValidateForClaimAssignAtClass(class, FALSE, thisObj, itemObj, mfail)
#define ValidateForClaimAssignAtParent(class, thisObj, itemObj, mfail) \
        _ValidateForClaimAssignAtClass(class, TRUE, thisObj, itemObj, mfail)

#define ValidateForComment(thisObj, mfail) \
        _ValidateForCommentAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForCommentAtClass(class, thisObj, mfail) \
        _ValidateForCommentAtClass(class, FALSE, thisObj, mfail)
#define ValidateForCommentAtParent(class, thisObj, mfail) \
        _ValidateForCommentAtClass(class, TRUE, thisObj, mfail)

#define ValidateForCommentExt(sig, mfail) \
        _ValidateForCommentExtAtClass(NULL, FALSE, sig, mfail)
#define ValidateForCommentExtAtClass(class, sig, mfail) \
        _ValidateForCommentExtAtClass(class, FALSE, sig, mfail)
#define ValidateForCommentExtAtParent(class, sig, mfail) \
        _ValidateForCommentExtAtClass(class, TRUE, sig, mfail)

#define ValidateForDrawHistory(thisObj, mfail) \
        _ValidateForDrawHistoryAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForDrawHistoryAtClass(class, thisObj, mfail) \
        _ValidateForDrawHistoryAtClass(class, FALSE, thisObj, mfail)
#define ValidateForDrawHistoryAtParent(class, thisObj, mfail) \
        _ValidateForDrawHistoryAtClass(class, TRUE, thisObj, mfail)

#define ValidateForExpire(thisObj, mfail) \
        _ValidateForExpireAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForExpireAtClass(class, thisObj, mfail) \
        _ValidateForExpireAtClass(class, FALSE, thisObj, mfail)
#define ValidateForExpireAtParent(class, thisObj, mfail) \
        _ValidateForExpireAtClass(class, TRUE, thisObj, mfail)

#define ValidateForLcySubmit(thisObj, mfail) \
        _ValidateForLcySubmitAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForLcySubmitAtClass(class, thisObj, mfail) \
        _ValidateForLcySubmitAtClass(class, FALSE, thisObj, mfail)
#define ValidateForLcySubmitAtParent(class, thisObj, mfail) \
        _ValidateForLcySubmitAtClass(class, TRUE, thisObj, mfail)

#define ValidateForManageSig(thisObj, lcmAdminMode, mfail) \
        _ValidateForManageSigAtClass(NULL, FALSE, thisObj, lcmAdminMode, mfail)
#define ValidateForManageSigAtClass(class, thisObj, lcmAdminMode, mfail) \
        _ValidateForManageSigAtClass(class, FALSE, thisObj, lcmAdminMode, mfail)
#define ValidateForManageSigAtParent(class, thisObj, lcmAdminMode, mfail) \
        _ValidateForManageSigAtClass(class, TRUE, thisObj, lcmAdminMode, mfail)

#define ValidateForReAssign(thisObj, lcmAdminMode, mfail) \
        _ValidateForReAssignAtClass(NULL, FALSE, thisObj, lcmAdminMode, mfail)
#define ValidateForReAssignAtClass(class, thisObj, lcmAdminMode, mfail) \
        _ValidateForReAssignAtClass(class, FALSE, thisObj, lcmAdminMode, mfail)
#define ValidateForReAssignAtParent(class, thisObj, lcmAdminMode, mfail) \
        _ValidateForReAssignAtClass(class, TRUE, thisObj, lcmAdminMode, mfail)

#define ValidateForRoute(thisObj, mfail) \
        _ValidateForRouteAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForRouteAtClass(class, thisObj, mfail) \
        _ValidateForRouteAtClass(class, FALSE, thisObj, mfail)
#define ValidateForRouteAtParent(class, thisObj, mfail) \
        _ValidateForRouteAtClass(class, TRUE, thisObj, mfail)

#define ValidateForRouteExt(thisObj, mfail) \
        _ValidateForRouteExtAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForRouteExtAtClass(class, thisObj, mfail) \
        _ValidateForRouteExtAtClass(class, FALSE, thisObj, mfail)
#define ValidateForRouteExtAtParent(class, thisObj, mfail) \
        _ValidateForRouteExtAtClass(class, TRUE, thisObj, mfail)

#define ValidateForShowHistory(thisObj, mfail) \
        _ValidateForShowHistoryAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForShowHistoryAtClass(class, thisObj, mfail) \
        _ValidateForShowHistoryAtClass(class, FALSE, thisObj, mfail)
#define ValidateForShowHistoryAtParent(class, thisObj, mfail) \
        _ValidateForShowHistoryAtClass(class, TRUE, thisObj, mfail)

#define ValidateForSigAction(thisObj, intStamp, intStampMode, mfail) \
        _ValidateForSigActionAtClass(NULL, FALSE, thisObj, intStamp, intStampMode, mfail)
#define ValidateForSigActionAtClass(class, thisObj, intStamp, intStampMode, mfail) \
        _ValidateForSigActionAtClass(class, FALSE, thisObj, intStamp, intStampMode, mfail)
#define ValidateForSigActionAtParent(class, thisObj, intStamp, intStampMode, mfail) \
        _ValidateForSigActionAtClass(class, TRUE, thisObj, intStamp, intStampMode, mfail)

#define ValidateForSignHistory(thisObj, mfail) \
        _ValidateForSignHistoryAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForSignHistoryAtClass(class, thisObj, mfail) \
        _ValidateForSignHistoryAtClass(class, FALSE, thisObj, mfail)
#define ValidateForSignHistoryAtParent(class, thisObj, mfail) \
        _ValidateForSignHistoryAtClass(class, TRUE, thisObj, mfail)

#define ValidateForSubmit(thisObj, mfail) \
        _ValidateForSubmitAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForSubmitAtClass(class, thisObj, mfail) \
        _ValidateForSubmitAtClass(class, FALSE, thisObj, mfail)
#define ValidateForSubmitAtParent(class, thisObj, mfail) \
        _ValidateForSubmitAtClass(class, TRUE, thisObj, mfail)

#define ValidateForUpdEffDate(thisObj, mfail) \
        _ValidateForUpdEffDateAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForUpdEffDateAtClass(class, thisObj, mfail) \
        _ValidateForUpdEffDateAtClass(class, FALSE, thisObj, mfail)
#define ValidateForUpdEffDateAtParent(class, thisObj, mfail) \
        _ValidateForUpdEffDateAtClass(class, TRUE, thisObj, mfail)

#define ValidateForUpdRevTab(thisObj, mfail) \
        _ValidateForUpdRevTabAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForUpdRevTabAtClass(class, thisObj, mfail) \
        _ValidateForUpdRevTabAtClass(class, FALSE, thisObj, mfail)
#define ValidateForUpdRevTabAtParent(class, thisObj, mfail) \
        _ValidateForUpdRevTabAtClass(class, TRUE, thisObj, mfail)

#define ValidateGrpAssignment(thisObj, mfail) \
        _ValidateGrpAssignmentAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateGrpAssignmentAtClass(class, thisObj, mfail) \
        _ValidateGrpAssignmentAtClass(class, FALSE, thisObj, mfail)
#define ValidateGrpAssignmentAtParent(class, thisObj, mfail) \
        _ValidateGrpAssignmentAtClass(class, TRUE, thisObj, mfail)

#define ValidateItemForSignoff(thisObj, sigObj, intStamp, intStampMode, mfail) \
        _ValidateItemForSignoffAtClass(NULL, FALSE, thisObj, sigObj, intStamp, intStampMode, mfail)
#define ValidateItemForSignoffAtClass(class, thisObj, sigObj, intStamp, intStampMode, mfail) \
        _ValidateItemForSignoffAtClass(class, FALSE, thisObj, sigObj, intStamp, intStampMode, mfail)
#define ValidateItemForSignoffAtParent(class, thisObj, sigObj, intStamp, intStampMode, mfail) \
        _ValidateItemForSignoffAtClass(class, TRUE, thisObj, sigObj, intStamp, intStampMode, mfail)

#define ValidateItemReAssign(thisObj, sigObj, lcmAdminMode, intStamp, intStampMode, mfail) \
        _ValidateItemReAssignAtClass(NULL, FALSE, thisObj, sigObj, lcmAdminMode, intStamp, intStampMode, mfail)
#define ValidateItemReAssignAtClass(class, thisObj, sigObj, lcmAdminMode, intStamp, intStampMode, mfail) \
        _ValidateItemReAssignAtClass(class, FALSE, thisObj, sigObj, lcmAdminMode, intStamp, intStampMode, mfail)
#define ValidateItemReAssignAtParent(class, thisObj, sigObj, lcmAdminMode, intStamp, intStampMode, mfail) \
        _ValidateItemReAssignAtClass(class, TRUE, thisObj, sigObj, lcmAdminMode, intStamp, intStampMode, mfail)

#define ValidateParticpForWork(className, dialogObj, attribute, participObj, procHist, itemObj, badArgs, mfail) \
        _ValidateParticpForWork(className, FALSE, className, dialogObj, attribute, participObj, procHist, itemObj, badArgs, mfail)
#define ValidateParticpForWorkAtParent(_class, className, dialogObj, attribute, participObj, procHist, itemObj, badArgs, mfail) \
        _ValidateParticpForWork(_class, TRUE, className, dialogObj, attribute, participObj, procHist, itemObj, badArgs, mfail)

#define ValidatePrcCal(className, thisObj, mfail) \
        _ValidatePrcCal(className, FALSE, className, thisObj, mfail)
#define ValidatePrcCalAtParent(_class, className, thisObj, mfail) \
        _ValidatePrcCal(_class, TRUE, className, thisObj, mfail)

#define ValidatePrcEffDates(className, processObj, effectiveOnFrom, effectiveOnTo, mfail) \
        _ValidatePrcEffDates(className, FALSE, className, processObj, effectiveOnFrom, effectiveOnTo, mfail)
#define ValidatePrcEffDatesAtParent(_class, className, processObj, effectiveOnFrom, effectiveOnTo, mfail) \
        _ValidatePrcEffDates(_class, TRUE, className, processObj, effectiveOnFrom, effectiveOnTo, mfail)

#define ValidateProcAndPrompt(className, processName, procObj, mfail) \
        _ValidateProcAndPrompt(className, FALSE, className, processName, procObj, mfail)
#define ValidateProcAndPromptAtParent(_class, className, processName, procObj, mfail) \
        _ValidateProcAndPrompt(_class, TRUE, className, processName, procObj, mfail)

#define ValidateProcessName(className, processName, forExistance, mfail) \
        _ValidateProcessName(className, FALSE, className, processName, forExistance, mfail)
#define ValidateProcessNameAtParent(_class, className, processName, forExistance, mfail) \
        _ValidateProcessName(_class, TRUE, className, processName, forExistance, mfail)

#define ValidateReAssignAction(thisObj, itemObj, lcmAdminMode, intStamp, intStampMode, mfail) \
        _ValidateReAssignActionAtClass(NULL, FALSE, thisObj, itemObj, lcmAdminMode, intStamp, intStampMode, mfail)
#define ValidateReAssignActionAtClass(class, thisObj, itemObj, lcmAdminMode, intStamp, intStampMode, mfail) \
        _ValidateReAssignActionAtClass(class, FALSE, thisObj, itemObj, lcmAdminMode, intStamp, intStampMode, mfail)
#define ValidateReAssignActionAtParent(class, thisObj, itemObj, lcmAdminMode, intStamp, intStampMode, mfail) \
        _ValidateReAssignActionAtClass(class, TRUE, thisObj, itemObj, lcmAdminMode, intStamp, intStampMode, mfail)

#define ValidateResumeProcHist(thisObj, itemObj, mfail) \
        _ValidateResumeProcHistAtClass(NULL, FALSE, thisObj, itemObj, mfail)
#define ValidateResumeProcHistAtClass(class, thisObj, itemObj, mfail) \
        _ValidateResumeProcHistAtClass(class, FALSE, thisObj, itemObj, mfail)
#define ValidateResumeProcHistAtParent(class, thisObj, itemObj, mfail) \
        _ValidateResumeProcHistAtClass(class, TRUE, thisObj, itemObj, mfail)

#define ValidateResumeWorkItem(thisObj, mfail) \
        _ValidateResumeWorkItemAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateResumeWorkItemAtClass(class, thisObj, mfail) \
        _ValidateResumeWorkItemAtClass(class, FALSE, thisObj, mfail)
#define ValidateResumeWorkItemAtParent(class, thisObj, mfail) \
        _ValidateResumeWorkItemAtClass(class, TRUE, thisObj, mfail)

#define ValidateSignoffAction(thisObj, itemObj, intStamp, intStampMode, mfail) \
        _ValidateSignoffActionAtClass(NULL, FALSE, thisObj, itemObj, intStamp, intStampMode, mfail)
#define ValidateSignoffActionAtClass(class, thisObj, itemObj, intStamp, intStampMode, mfail) \
        _ValidateSignoffActionAtClass(class, FALSE, thisObj, itemObj, intStamp, intStampMode, mfail)
#define ValidateSignoffActionAtParent(class, thisObj, itemObj, intStamp, intStampMode, mfail) \
        _ValidateSignoffActionAtClass(class, TRUE, thisObj, itemObj, intStamp, intStampMode, mfail)

#define ValidateTabulations(className, dialogObj, mfail) \
        _ValidateTabulations(className, FALSE, className, dialogObj, mfail)
#define ValidateTabulationsAtParent(_class, className, dialogObj, mfail) \
        _ValidateTabulations(_class, TRUE, className, dialogObj, mfail)

#define ValidateVaultName(className, thisObj, badArgs, mfail) \
        _ValidateVaultName(className, FALSE, className, thisObj, badArgs, mfail)
#define ValidateVaultNameAtParent(_class, className, thisObj, badArgs, mfail) \
        _ValidateVaultName(_class, TRUE, className, thisObj, badArgs, mfail)

#define ValidateViewProcess(thisObj, mfail) \
        _ValidateViewProcessAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateViewProcessAtClass(class, thisObj, mfail) \
        _ValidateViewProcessAtClass(class, FALSE, thisObj, mfail)
#define ValidateViewProcessAtParent(class, thisObj, mfail) \
        _ValidateViewProcessAtClass(class, TRUE, thisObj, mfail)

#define ValidateViewProcessExt(processObj, mfail) \
        _ValidateViewProcessExtAtClass(NULL, FALSE, processObj, mfail)
#define ValidateViewProcessExtAtClass(class, processObj, mfail) \
        _ValidateViewProcessExtAtClass(class, FALSE, processObj, mfail)
#define ValidateViewProcessExtAtParent(class, processObj, mfail) \
        _ValidateViewProcessExtAtClass(class, TRUE, processObj, mfail)

#define ValidateWorkDesc(thisObj, updateFlag, mfail) \
        _ValidateWorkDescAtClass(NULL, FALSE, thisObj, updateFlag, mfail)
#define ValidateWorkDescAtClass(class, thisObj, updateFlag, mfail) \
        _ValidateWorkDescAtClass(class, FALSE, thisObj, updateFlag, mfail)
#define ValidateWorkDescAtParent(class, thisObj, updateFlag, mfail) \
        _ValidateWorkDescAtClass(class, TRUE, thisObj, updateFlag, mfail)

#define ValidateWorkweek(thisObj, mfail) \
        _ValidateWorkweekAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateWorkweekAtClass(class, thisObj, mfail) \
        _ValidateWorkweekAtClass(class, FALSE, thisObj, mfail)
#define ValidateWorkweekAtParent(class, thisObj, mfail) \
        _ValidateWorkweekAtClass(class, TRUE, thisObj, mfail)

#define ViewActStepProcess(stepObj, lcObj, mfail) \
        _ViewActStepProcessAtClass(NULL, FALSE, stepObj, lcObj, mfail)
#define ViewActStepProcessAtClass(class, stepObj, lcObj, mfail) \
        _ViewActStepProcessAtClass(class, FALSE, stepObj, lcObj, mfail)
#define ViewActStepProcessAtParent(class, stepObj, lcObj, mfail) \
        _ViewActStepProcessAtClass(class, TRUE, stepObj, lcObj, mfail)

#define ViewEffStepProcess(stepObj, lcObj, mfail) \
        _ViewEffStepProcessAtClass(NULL, FALSE, stepObj, lcObj, mfail)
#define ViewEffStepProcessAtClass(class, stepObj, lcObj, mfail) \
        _ViewEffStepProcessAtClass(class, FALSE, stepObj, lcObj, mfail)
#define ViewEffStepProcessAtParent(class, stepObj, lcObj, mfail) \
        _ViewEffStepProcessAtClass(class, TRUE, stepObj, lcObj, mfail)

#define WLGetValidWorkflows(className, itemObj, flowObjs, mfail) \
        _WLGetValidWorkflows(className, FALSE, className, itemObj, flowObjs, mfail)
#define WLGetValidWorkflowsAtParent(_class, className, itemObj, flowObjs, mfail) \
        _WLGetValidWorkflows(_class, TRUE, className, itemObj, flowObjs, mfail)

#define WLGrantAccessToExpItms(className, objectSet, relationship, otherSideObjSet, relObjSet, mfail) \
        _WLGrantAccessToExpItms(className, FALSE, className, objectSet, relationship, otherSideObjSet, relObjSet, mfail)
#define WLGrantAccessToExpItmsAtParent(_class, className, objectSet, relationship, otherSideObjSet, relObjSet, mfail) \
        _WLGrantAccessToExpItms(_class, TRUE, className, objectSet, relationship, otherSideObjSet, relObjSet, mfail)

#define WLInflateWorklistAttrs(thisObj, itemObj, userName, mfail) \
        _WLInflateWorklistAttrsAtClass(NULL, FALSE, thisObj, itemObj, userName, mfail)
#define WLInflateWorklistAttrsAtClass(class, thisObj, itemObj, userName, mfail) \
        _WLInflateWorklistAttrsAtClass(class, FALSE, thisObj, itemObj, userName, mfail)
#define WLInflateWorklistAttrsAtParent(class, thisObj, itemObj, userName, mfail) \
        _WLInflateWorklistAttrsAtClass(class, TRUE, thisObj, itemObj, userName, mfail)

#define WLRefreshGrantedAccess(thisObj, relationship, mfail) \
        _WLRefreshGrantedAccessAtClass(NULL, FALSE, thisObj, relationship, mfail)
#define WLRefreshGrantedAccessAtClass(class, thisObj, relationship, mfail) \
        _WLRefreshGrantedAccessAtClass(class, FALSE, thisObj, relationship, mfail)
#define WLRefreshGrantedAccessAtParent(class, thisObj, relationship, mfail) \
        _WLRefreshGrantedAccessAtClass(class, TRUE, thisObj, relationship, mfail)

#define WbpGetValidRelations1(dialogObj, relationships, values, mfail) \
        _WbpGetValidRelations1AtClass(NULL, FALSE, dialogObj, relationships, values, mfail)
#define WbpGetValidRelations1AtClass(class, dialogObj, relationships, values, mfail) \
        _WbpGetValidRelations1AtClass(class, FALSE, dialogObj, relationships, values, mfail)
#define WbpGetValidRelations1AtParent(class, dialogObj, relationships, values, mfail) \
        _WbpGetValidRelations1AtClass(class, TRUE, dialogObj, relationships, values, mfail)

#define WorkReminderObject(thisObj, mfail) \
        _WorkReminderObjectAtClass(NULL, FALSE, thisObj, mfail)
#define WorkReminderObjectAtClass(class, thisObj, mfail) \
        _WorkReminderObjectAtClass(class, FALSE, thisObj, mfail)
#define WorkReminderObjectAtParent(class, thisObj, mfail) \
        _WorkReminderObjectAtClass(class, TRUE, thisObj, mfail)
#endif /* for msglcm_H */

