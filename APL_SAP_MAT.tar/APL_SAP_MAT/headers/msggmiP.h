/*
 *  FILE: msggmiP.h
 */

#ifndef msggmiP_H
#define msggmiP_H

#include <Mtimsgh.h>
#ifndef _LCINTERP_
#include <metadt.h>
#else
extern "c" {
#endif

/*
 *  Message Function Definitions (Prototypes).
 *  Published Messages
 */

#ifdef _LCINTERP_
}
#else
#endif /* _LCINTERP_ */

/*
 *  Message Macro Definitions.
 */
#endif /* for msggmi_H */

