#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <tel.h>
#include <time.h>

status getDataBaseSetByUser(SetOfStrings* dbscope,string options,integer* mfail)
{

	string Scope=NULL;
	string userSelectedOptionS=NULL;

	t5MethodInit("getDataBaseSetByUser");	

	userSelectedOptionS=nlsStrAlloc(100);
	nlsStrCpy(userSelectedOptionS,options);

	Scope=strtok(userSelectedOptionS,",");
	if(nlsStrCmp(Scope,"+")==0)
	{
		low_set_add_str(*dbscope, "supprod");	
	}
	Scope=strtok(NULL,",");
	if(nlsStrCmp(Scope,"+")==0)
	{
		low_set_add_str(*dbscope, "suhprod");	
	}

	Scope=strtok(NULL,",");
	if(nlsStrCmp(Scope,"+")==0)
	{
		low_set_add_str(*dbscope, "sujprod");	
	}

	Scope=strtok(NULL,",");
	if(nlsStrCmp(Scope,"+")==0)
	{
		low_set_add_str(*dbscope, "sulprod");	
	}


	CLEANUP:
		t5PrintCleanUpModName;

	EXIT:
		t5CheckDstatAndReturn;

}

status readVaultlistfrominputFile(string inputfilename,SetOfStrings* jtlist)
{
	FILE* inputfp=NULL;
	char buffer[200];
	int i=0,c=0;

	inputfp=fopen(inputfilename,"r");
	memset(buffer,'\0',200);
	if(inputfp!=NULL)
	{
		*jtlist=setCreate(1);
		while(1)
		{
			c=getc(inputfp);
			if(c=='\n'||c==EOF)
			{
				//printf("\nInput File Name Is :[%s]",buffer);
				low_set_add_str_unique(*jtlist,buffer);		
				memset(buffer,'\0',200);
				i=0;
				if(c==EOF)
					break;
			}else
			{
				buffer[i]=c;
				i++;
			}
		}		

	}else
	{
		printf("\n ----------------------------------------------------- \n");
		printf("   | File Containig Vault List Not Found               |    ");
		printf("\n ----------------------------------------------------- \n");
		exit(0);
	}	
	fclose(inputfp);
	inputfp=NULL;
}  

status readjtlistfrominputFile(string inputfilename,SetOfStrings* jtlist)
{
	FILE* inputfp=NULL;
	char buffer[200];
	int i=0,c=0;

	inputfp=fopen(inputfilename,"r");
	if(inputfp!=NULL)
	{
		*jtlist=setCreate(1);
		while(1)
		{
			c=getc(inputfp);
			if(c=='\n'||c==EOF)
			{
				printf("\nInput File Name Is :[%s]",buffer);
				low_set_add_str_unique(*jtlist,buffer);		
				memset(buffer,'\0',200);
				i=0;
				if(c==EOF)
					break;
			}else
			{
				buffer[i]=c;
				i++;
			}
		}		

	}else
	{
		printf("\n File Not Found");
	}	

}

int IsCEVault(ObjectPtr thisObj1,int *mfail)
{
	char* mod_name="t5Function"; 
	
	string       ProjectName                = NULL;
	string       ProjectNameDup             = NULL;
	SqlPtr		 Vsql		                = NULL;
	SetOfObjects PrjControlObj	            = NULL;
	
	status       dstat                      = OKAY; 
	 
    // function code starts here...

    //
	if(dstat=objGetAttribute(thisObj1,ProjectNameAttr,&ProjectName))goto EXIT;
    if(ProjectName)ProjectNameDup = nlsStrDup(ProjectName);


    if(dstat = oiSqlCreateSelect(&Vsql)) goto CLEANUP;
	if(dstat = oiSqlWhereEQ(Vsql,t5SyscdAttr,ProjectNameDup)) goto CLEANUP;
	if(dstat = oiSqlWhereAND(Vsql)) goto CLEANUP;
	if(dstat = oiSqlWhereEQ(Vsql,t5SubSyscdAttr,"Live")) goto CLEANUP;
	if(dstat = QueryWhere("t5Cntrol",Vsql,&PrjControlObj,mfail)) goto CLEANUP;
	if (*mfail) goto CLEANUP;

	if(setSize(PrjControlObj)>0)
	{
		  printf("\n Project %s is in CE Vault\n",ProjectNameDup);fflush(stdout);
		  return 1;
	}
    else
	{
		  printf("\n Project %s is in WIP Vault\n",ProjectNameDup);fflush(stdout);
		  return 0;
		  
    }

CLEANUP:
EXIT:
	  if (dstat != OKAY)  uiShowFatalError( dstat, WHERE );                       
	  return 0;  

}



