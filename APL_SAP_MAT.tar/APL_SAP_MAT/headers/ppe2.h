#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "saprfc.h"
#include "sapitab.h"

#ifndef SAP_ST_LOGSYS
#define SAP_ST_LOGSYS
typedef struct {
	RFC_CHAR LogSys[10];
} LOGSYS;
#endif

#ifndef SAP_TH_LOGSYS
#define SAP_TH_LOGSYS
static RFC_TYPEHANDLE handleOfLOGSYS;
static RFC_TYPE_ELEMENT typeOfLOGSYS[] = {
  {"LOGSYS", TYPC, 10, 0},
};
#endif

#ifndef SAP_ST_PVS_PNODE
#define SAP_ST_PVS_PNODE
typedef struct 
{
  RFC_CHAR Pvs_Pnode[40];
} PVS_PNODE;
#endif

#ifndef SAP_TH_PVS_PNODE
#define SAP_TH_PVS_PNODE
static RFC_TYPEHANDLE handleOfPVS_PNODE;

static RFC_TYPE_ELEMENT typeOfPVS_PNODE[] = 
{
  {"PVS_PNODE", TYPC, 40, 0},
};
#endif

#ifndef SAP_ST_PVS_PNODETX
#define SAP_ST_PVS_PNODETX
typedef struct 
{
	RFC_CHAR Pvs_Pnodetx[60];
} PVS_PNODETX;
#endif

#ifndef SAP_TH_PVS_PNODETX
#define SAP_TH_PVS_PNODETX
static RFC_TYPEHANDLE handleOfPVS_PNODETX;

static RFC_TYPE_ELEMENT typeOfPVS_PNODETX[] = 
{
  {"PVS_PNODETX", TYPC, 60, 0},
 };
#endif

/*-----------------------*/
#ifndef SAP_ST_BAPIRET2
#define SAP_ST_BAPIRET2
typedef struct 
{
	RFC_CHAR TYPE[1];	
	RFC_CHAR ID[20];	
	RFC_NUM  NUMBER[3];	
	RFC_CHAR MESSAGE[220];	
	RFC_CHAR LOG_NO[20];	
	RFC_NUM  LOG_MSG_NO[6];	
	RFC_CHAR MESSAGE_V1[50];	
	RFC_CHAR MESSAGE_V2[50];	
	RFC_CHAR MESSAGE_V3[50];	
	RFC_CHAR MESSAGE_V4[50];	
	RFC_CHAR PARAMETER[32];	
	RFC_INT  ROW;	
	RFC_CHAR FIELD[30];	
	RFC_CHAR SYSTEM[10];	
} 
BAPIRET2;
#endif

#ifndef SAP_TH_BAPIRET2
#define SAP_TH_BAPIRET2
static RFC_TYPEHANDLE handleOfBAPIRET2;

static RFC_TYPE_ELEMENT typeOfBAPIRET2[] = {
{"TYPE"			,TYPC,	1	,0},		/*	Message type: S Success, E Error, W Warning, I Info, A Abort*/
{"ID"			,TYPC,	20	,0},		/*	Message Class*/
{"NUMBER"		,TYPNUM,3	,0},		/*	Message Number*/
{"MESSAGE"		,TYPC,	220	,0},		/*	Message Text*/
{"LOG_NO"		,TYPC,	20	,0},		/*	Application log: log number*/
{"LOG_MSG_NO"	,TYPNUM,6	,0},		/*	Application log: Internal message serial number*/
{"MESSAGE_V1"	,TYPC,	50	,0},		/*	Message Variable*/
{"MESSAGE_V2"	,TYPC,	50	,0},		/*	Message Variable*/
{"MESSAGE_V3"	,TYPC,	50	,0},		/*	Message Variable*/
{"MESSAGE_V4"	,TYPC,	50	,0},		/*	Message Variable*/
{"PARAMETER"		,TYPC,	32	,0},		/*	Parameter Name*/
{"ROW"			,TYPINT,sizeof(RFC_INT),0},	/*	Lines in parameter*/
{"FIELD"			,TYPC,	30	,0},		/*	Field in parameter*/
{"SYSTEM"		,TYPC,	10	,0},		/*	Logical system from which message originates*/

 };
#endif

#ifndef SAP_ST_ZISSTU_IPPE_ASMBLY_NODE_DATA
#define SAP_ST_ZISSTU_IPPE_ASMBLY_NODE_DATA
typedef struct 
{
	RFC_CHAR HEAD_VARIANT[8];
	RFC_CHAR HEAD_TEXT[60];
	RFC_CHAR CHANGE_NUMBER[12];
	RFC_CHAR DELETE_FLG[1];	
	RFC_CHAR CHILD_VARIANT[8];	
	RFC_CHAR CHILD_TEXT[60];
	RFC_CHAR PHANTOM_ASG[40];
	RFC_CHAR MATNR_INT[18];
	RFC_CHAR MATERIAL_VERSION[10];
	RFC_BCD  QUANTITY[7];	
	RFC_CHAR QUANTITY_UNIT[3];	
	RFC_CHAR QUANTITY_UNIT_ISO[3];	
	RFC_BCD  VSI_SIZE1[7];	
	RFC_BCD  VSI_PERCENT1[3];	
	RFC_BCD  VSI_SIZE2[7];	
	RFC_BCD  VSI_PERCENT2[3];	
	RFC_BCD  VSI_SIZE3[7];	
	RFC_BCD  VSI_PERCENT3[3];	
	RFC_CHAR VSI_SZUNIT[3];	
	RFC_CHAR VSI_SZUNIT_ISO[3];	
	RFC_BCD  VSI_QUANTITY[7];	
	RFC_CHAR VSI_CMPUNIT[3];	
	RFC_CHAR VSI_CMPUNIT_ISO[3];	
	RFC_CHAR VSI_FORMUL[2];	
	RFC_CHAR DELETE_NONHIST_FLG[1];	
	RFC_CHAR ALT_MATERIAL_GROUP[2];	
	RFC_CHAR DEEP_DELETE_FLG[1];	
	RFC_CHAR CONCEPT_GROUP[32];
	RFC_CHAR VARIANT_REFERENCE[32];
	RFC_BCD  QUANTITY_FIX[7];
}ZISSTU_IPPE_ASMBLY_NODE_DATA;
#endif

#ifndef SAP_TH_ZISSTU_IPPE_ASMBLY_NODE_DATA
#define SAP_TH_ZISSTU_IPPE_ASMBLY_NODE_DATA
static RFC_TYPEHANDLE handleOfZISSTU_IPPE_ASMBLY_NODE_DATA;

static RFC_TYPE_ELEMENT typeOfZISSTU_IPPE_ASMBLY_NODE_DATA[] = 
{
	{"HEAD_VARIANT",		TYPC,	8,	0},		/*	Variant*/
	{"HEAD_TEXT",			TYPC,	60,	0},		/*	First Line of Long Text*/
	{"CHANGE_NUMBER",		TYPC,	12,	0},		/*	Change Number in iPPE*/
	{"DELETE_FLG",			TYPC,	1,	0},		/*	Deletion Indicator*/
	{"CHILD_VARIANT",		TYPC,	8,	0},		/*	Variant*/
	{"CHILD_TEXT",			TYPC,	60,	0},		/*	First Line of Long Text*/
	{"PHANTOM_ASG",			TYPC,	40,	0},		/*	iPPE Node Description*/
	{"MATNR_INT",			TYPC,	18,	0},		/*	Material Number*/
	{"MATERIAL_VERSION",	TYPC,	10,	0},	/*	Material Version Number*/
	{"QUANTITY",			TYPP,	7,	0},		/*	Quantity (in Component Variant)*/
	{"QUANTITY_UNIT",		TYPC,	3,	0},		/*	Unit of Measure*/
	{"QUANTITY_UNIT_ISO",	TYPC,	3,	0},	/*	ISO code for unit of measurement*/
	{"VSI_SIZE1",			TYPP,	7,	0},		/*	Size 1*/
	{"VSI_PERCENT1",		TYPP,	3,	0},		/*	Percentage Rate for Rounding Size Up or Down*/
	{"VSI_SIZE2",			TYPP,	7,	0},		/*	Size 2*/
	{"VSI_PERCENT2",		TYPP,	3,	0},		/*	Percentage Rate for Rounding Size Up or Down*/
	{"VSI_SIZE3",			TYPP,	7,	0},		/*	Size 3*/
	{"VSI_PERCENT3",		TYPP,	3,	0},		/*	Percentage Rate for Rounding Size Up or Down*/
	{"VSI_SZUNIT",			TYPC,	3,	0},		/*	iPPE/BAPI: Unit of Measure for Sizes 1 to 3*/
	{"VSI_SZUNIT_ISO",		TYPC,	3,	0},		/*	ISO code for unit of measurement*/
	{"VSI_QUANTITY",		TYPP,	7,	0},		/*	Quantity of Variable-Size Item*/
	{"VSI_CMPUNIT",			TYPC,	3,	0},		/*	Unit of Measure for Variable-Size Component*/
	{"VSI_CMPUNIT_ISO",		TYPC,	3,	0},		/*	ISO code for unit of measurement*/
	{"VSI_FORMUL",			TYPC,	2,	0},		/*	Formula Key*/
	{"DELETE_NONHIST_FLG",	TYPC,	1,	0},	/*	Object Deleted*/
	{"ALT_MATERIAL_GROUP",	TYPC,	2,	0},	/*	Alternative Item Group*/
	{"DEEP_DELETE_FLG",		TYPC,	1,	0},		/*	Delete an Object with Entire Environment*/
	{"CONCEPT_GROUP",		TYPC,	32,	0},		/*	Concept Group (Internal Indicator)*/
	{"VARIANT_REFERENCE",	TYPC,	32,	0},	/*	Variant of Configurable Phantom (Internal Indicator)*/
	{"QUANTITY_FIX",		TYPP,	7,	0},		/*	Fixed Quantity in Variant of iPPE Product Structure*/
};
#endif

/**********here onwards struct for header check*********************/
#ifndef SAP_FT_PPE_MODE_ALL
#define SAP_FT_PPE_MODE_ALL
typedef RFC_CHAR PPE_MODE_ALL[1];
#endif

#ifndef SAP_FT_PPE_MESSAGE_OPTION
#define SAP_FT_PPE_MESSAGE_OPTION
typedef RFC_CHAR PPE_MESSAGE_OPTION[1];
#endif

#ifndef SAP_FT_PPE_EXISTENCE_ONLY
#define SAP_FT_PPE_EXISTENCE_ONLY
typedef RFC_CHAR PPE_EXISTENCE_ONLY[1];
#endif

/*#ifndef SAP_FT_PVS_PNODE
#define SAP_FT_PVS_PNODE
typedef RFC_CHAR PVS_PNODE[40];
#endif
*/
#ifndef SAP_FT_PPE_KLASSE
#define SAP_FT_PPE_KLASSE
typedef RFC_CHAR PPE_KLASSE[18];
#endif

#ifndef SAP_FT_PPE_KLASSENART
#define SAP_FT_PPE_KLASSENART
typedef RFC_CHAR PPE_KLASSENART[3];
#endif

#ifndef SAP_FT_PVS_POSVAR
#define SAP_FT_PVS_POSVAR
typedef RFC_CHAR PVS_POSVAR[8];
#endif

#ifndef SAP_FT_PVS_ALTNUM
#define SAP_FT_PVS_ALTNUM
typedef RFC_CHAR PVS_ALTNUM[2];
#endif

#ifndef SAP_FT_PVS_APPLOBJ_TYPE
#define SAP_FT_PVS_APPLOBJ_TYPE
typedef RFC_CHAR PVS_APPLOBJ_TYPE[4];
#endif

#ifndef SAP_FT_PVS_GUID_EXT
#define SAP_FT_PVS_GUID_EXT
typedef RFC_CHAR PVS_GUID_EXT[32];
#endif

#ifndef SAP_FT_PPE_GUID_EXISTENCE
#define SAP_FT_PPE_GUID_EXISTENCE
/*typedef RFC_CHAR PPE_GUID_EXISTENCE[1];*/
typedef RFC_CHAR PPE_GUID_EXISTENCE;
#endif

#ifndef SAP_ST_BAPIRET2
#define SAP_ST_BAPIRET2
typedef struct
{
RFC_CHAR Type[1];
RFC_CHAR Id[20];
RFC_NUM  Number[3];
RFC_CHAR Message[220];
RFC_CHAR Log_No[20];
RFC_NUM  Log_Msg_No[6];
RFC_CHAR Message_V1[50];
RFC_CHAR Message_V2[50];
RFC_CHAR Message_V3[50];
RFC_CHAR Message_V4[50];
RFC_CHAR Parameter[32];
RFC_INT2 Row[10];
RFC_CHAR Field[30];
RFC_CHAR System[10];
}BAPIRET2;
#endif

#ifndef SAP_TH_BAPIRET2
#define SAP_TH_BAPIRET2
static RFC_TYPEHANDLE handleOfBAPIRET2;
static RFC_TYPE_ELEMENT typeOfBAPIRET2[]=
{
{"TYPE",TYPC,1,0},
{"ID",TYPC,20,0},
{"NUMBER",TYPNUM,3,0},
{"MESSAGE",TYPC,220,0},
{"LOG_NO",TYPC,20,0},
{"LOG_MSG_NO",TYPNUM,6,0},
{"MESSAGE_V1",TYPC,50,0},
{"MESSAGE_V2",TYPC,50,0},
{"MESSAGE_V3",TYPC,50,0},
{"MESSAGE_V4",TYPC,50,0},
{"PARAMETER",TYPC,32,0},
{"ROW",TYPINT2,10,0},
{"FIELD",TYPC,30,0},
{"SYSTEM",TYPC,10,0},
};
#endif
/****************here end of struct header********************/
/*
#define SETBCD(var,str,dec) str2nbcd(str,var,sizeof(var),dec)  

#define GETCHAR(var,str) sprintf(str,"%.*s",sizeof(var),var)
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var))); if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
void str2nbyte(char *str,unsigned char *byte,size_t size)                       
{                                                                               

  size_t c; char tmp[1024]; int i;                                              
  strcpy(tmp,str); for (c=0;c<strlen(tmp);++c) tmp[c]=toupper(tmp[c]);          
  for (c=strlen(tmp);c<(size<<1);c++) tmp[c] = '0';                             
  for (c=0;c<size;c++) { sscanf(& tmp[c<<1],"%2x",& i); byte[c]=i; }            
}                                                                                 
void str2nbcd(char *str,unsigned char *bcd,size_t size, int decimals)           
{                                                                               

  char s[1024],*p; size_t c, strs=size<<1;                                      
                                                                                
  if (str[0]=='-') {s[strs-1]='D'; str++;}                                      
  else {s[strs-1]='C'; if (str[0]=='+') str++;}                                 
  if (p=strchr(str,'.')) *(p++)=0; else p=str+strlen(str);                      
  c=strs-1-decimals;                                                            
  if (strlen(str)>c) memcpy(s,str+strlen(str)-c,c);                             
  else {memset(s,'0',c-strlen(str));memcpy(s+c-strlen(str),str,strlen(str));}   
  while((*p) && (c < strs-1)) s[c++]=*(p++);                                    
  while(c < strs-1) s[c++]='0';                                                 
  str2nbyte(s,bcd,size);                                                        
} 
*/

#ifndef SAP_ST_PVS_PNODETXUP
#define SAP_ST_PVS_PNODETXUP
typedef struct {
  RFC_CHAR Description[60];
 } PVS_PNODETXUP;
#endif
#ifndef SAP_TH_PVS_PNODETXUP
#define SAP_TH_PVS_PNODETXUP
static RFC_TYPEHANDLE handleOfPVS_PNODETXUP;

static RFC_TYPE_ELEMENT typeOfPVS_PNODETXUP[] = {
  {"PVS_PNODETXUP", TYPC, 60, 0},
 };
#endif


#ifndef SAP_ST_ZPP_STR_IPPE_BOM
#define SAP_ST_ZPP_STR_IPPE_BOM
typedef struct {
	RFC_INT LEVEL;
	RFC_INT ITEM;
	RFC_CHAR VARIANT[8];
	RFC_CHAR MATERIAL[40];
	RFC_CHAR DESCRIPTION[40];
	RFC_BCD	QUAN[7];
	RFC_CHAR UOM[3];
	RFC_CHAR CHANGE_NO[12];
	RFC_CHAR BULK_IND[1];
	RFC_CHAR PROCUREMENT[1];
	RFC_CHAR SP_PROC[2];
} ZPP_STR_IPPE_BOM;
#endif

#ifndef SAP_TH_ZPP_STR_IPPE_BOM
#define SAP_TH_ZPP_STR_IPPE_BOM
static RFC_TYPEHANDLE handleOfZPP_STR_IPPE_BOM;

static RFC_TYPE_ELEMENT typeOfZPP_STR_IPPE_BOM[] = {
{"LEVEL",		TYPINT,sizeof(RFC_INT)	,0},
{"ITEM",		TYPINT,sizeof(RFC_INT)	,0},
{"VARIANT",		TYPC,	8	,0},
{"MATERIAL",	TYPC,	40	,0},
{"DESCRIPTION",	TYPC,	40	,0},
{"QUANTITY",	TYPP,	7	,0},
{"UOM",			TYPC,	3	,0},
{"CHANGE_NO",	TYPC,	12	,0},
{"BULK_IND",	TYPC,	1	,0},
{"PROCUREMENT",	TYPC,	1	,0},
{"SP_PROC",		TYPC,	2	,0},
};
#endif
