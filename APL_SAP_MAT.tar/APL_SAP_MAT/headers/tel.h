/***********************************************************************************
*  File            :   tel.h
*  Created By      :   A K Murthy
*  Created On      :   1 Feb 2006
*  Project         :   TML Implementation 
*
*  Purpose         :   Header file to have macro defintions
*
*
*  Functions:
*
*  Modification History :
*  S.No    Date        CR      Modified By            Modification Notes
*  1       4-Aug-2006  264     A.K.Murthy             Added macro t5MethodInitWMD
*
**********************************************************************************/

#ifndef tel_H
#define tel_H

#include <Mtimsgh.h>
#ifndef _LCINTERP_
#include <metadt.h>
#include <msgapc.h>
#else
extern "c" {
#endif

/* prints the modname */
#define t5PrintModName  \
		fprintf(stderr, "%s ...\n", mod_name); fflush(stdout);

/* prints the modname along with dstat and mfail values. useful for cleanup section */
#define t5PrintCleanUpModName  \
		fprintf(stderr, "CLEAN UP  %s, dstat %d, mfail %d ...\n", mod_name, dstat, *mfail); fflush(stdout);

/* method intialization with modname and dstat and mfail settings */
#define t5MethodInit(A) \
		MODNAME(A); status dstat = OKAY; *mfail = USC_OKAY;

/* method initialization with modname and dstat and mfail settings with mfail declaration*/
#define t5MethodInitWMD(A) \
		MODNAME(A); status dstat = OKAY; integer *mfail = NULL; mfail = (int*) malloc(sizeof(int)*2); *mfail = USC_OKAY;


/* code for method exit */
#define t5CheckDstatAndReturn \
		if (dstat != OKAY) { \
			fprintf(stderr, "RETURNING DSTAT NOT OKAY FROM : %s\n", mod_name); \
			uiShowFatalError(dstat, WHERE); }\
		return(dstat);

/* check for mfail and print the error details. useful for message calls */
#define t5CheckMfail(A) \
		if(dstat = A) { \
			fprintf(stderr, "DSTAT NOT OKAY (%d): %s  line: %d\n", dstat, mod_name, __LINE__); \
			goto EXIT; } \
		if(*mfail) { \
			fprintf(stderr, "DSTAT OR MFAIL NOT OKAY (%d, %d): %s  line: %d\n", dstat, *mfail, mod_name, __LINE__); \
			goto CLEANUP; }

/* check for dstat and print the error details. useful for function calls */
#define t5CheckDstat(A) \
		if(dstat = A) { \
			fprintf(stderr, "DSTAT NOT OKAY (%d): %s  line: %d\n", dstat, mod_name, __LINE__); \
			goto EXIT; }

/* memory free for NVSet */
#define t5FreeNVSet(NVS) \
		if(NVS != NULL) { \
			if(dstat) nvsDestroy(&NVS); \
            else dstat = nvsDestroy(&NVS); \
            NVS = NULL; }

/* memory free for ObjectPtr */
#define t5FreeObjectPtr(O) \
		if(O != NULL) { \
			if(dstat) objDispose(O); \
			else dstat = objDispose(O); \
			O = NULL; }

/* memory free for string */
#define t5FreeString(S) \
		if(S != NULL) { \
			if(dstat) nlsStrFree(S); \
			else dstat = nlsStrFree(S); \
			S = NULL; }

/* memory free for SetOfObjects */
#define t5FreeSetOfObjects(SO) \
		if(SO != NULL) { \
			if(dstat) objDisposeAll(SO); \
			else dstat = objDisposeAll(SO); \
			SO = NULL; }

/* memory free for SetOfStrings */
#define t5FreeSetOfStrings(SS) \
		if(SS != NULL) { \
			if(dstat) setDestroy(SS); \
			else dstat = setDestroy(SS); \
			SS = NULL; }

/* memory free for SqlPtr */
#define t5FreeSqlPtr(PSQL) \
		if(PSQL != NULL) { \
			if (dstat) oiSqlDispose(PSQL); \
			else dstat = oiSqlDispose(PSQL); \
			PSQL = NULL; }


#endif /* for tel_H */

//Prototypes of functions - required for Tce9 compilation

status t0UpdateObject(ObjectPtr *itemObj,integer *mfail);
status t5GetMultiLevelExplosion(ObjectPtr,integer,ObjectPtr,SetOfObjects *,SetOfObjects *,SetOfStrings *,integer *);
status t5CustPrtReplication(ObjectPtr thisObj,string  Serv1,integer *mfail);
status t5GetDistinctAttributeValues(SetOfObjects set,string str,SetOfObjects* setobj,integer* mfail);
status IsInGrp(string UsrName,string GrpName,int *IsUser);
status t5GetCSAttrForPlant(string planttype,char** csIndicator,char** IAIndicator,string* SAPPlant);
status customCreate(SetOfStrings soChildren,ObjectPtr opParentObj,ObjectPtr opDialogObj,integer* mfail);
status Update_ModelInd(string M_PartNumberDup,string DesIDDup,string OSUsername);
status IsInLoc(string UsrName,string Location,int *IsInLocation);
status IsInLocAgency(string UsrName,string Agency,string Location,int *IsInLocationAgency);
status getMakeBuyDetails(string ,string ,char *,char *);
status getStoreLocationDetails(string ,char *,char *);
status RecRollUp(ObjectPtr InputObj,string * AttrArray,string PrtQty ,SetOfStrings attrNames,ObjectPtr genContextObj,integer * mfail);
status AttachConsumablesTo98Grp1_Revise(ObjectPtr MyTPL1,string inputCategory,SetOfStrings	conClass,integer *mfail,boolean flag_QTY);
status AttachNewConsumablesTo98Grp(ObjectPtr MyTPL1,string inputCategory,integer *mfail);
//Start - Multi Plant DML implementation by JSR Team
//status BuildReportCSV(boolean isAMDML,ObjectPtr DmlObj,ObjectPtr APLObj,ObjectPtr SGRObj, SetOfStrings *outputStringSet ,string agency,string RemoveUnderScoreDup,integer*  mfail);
status BuildReportCSV(boolean isAMDML,ObjectPtr DmlObj,ObjectPtr APLObj, SetOfStrings *outputStringSet ,string agency,string RemoveUnderScoreDup,integer*  mfail);
//End - Commented the code for Multi Plant DML implementation by JSR Team
status CheckCsAgencyChng(ObjectPtr Assmly,char DmlNo[20]);
status CheckIntoRel(ObjectPtr PartPtr);
status CheckforBasicPartRelease( ObjectPtr ColourPart ,ObjectPtr viewSTD,string ViewName ,integer*  mfail );
status ClTaskForColourBomGen(string DmlNumInp,integer mfail);
status CmpTwoDocumets(ObjectPtr docCurr,ObjectPtr docPrev,ObjectPtr t5TempObjPtr,int *t5RevCntPtr);
status ColorexpandAssemblyByRev(ObjectPtr AssyDup,string DateDup,string ViewDup,string ContextDup,SET_PTR *soUsesParts,integer*  mfail);
status ColorgetComparisonSets(SetOfObjects soUsesPartsA,SetOfObjects soUsesPartsB,SET_PTR soAssyA,SET_PTR soAssyB,SET_PTR soCommon,integer*  mfail);
status CreateEffectivity(ObjectPtr partObj,ObjectPtr vewObj,string start_date, string end_date,integer *mfail);
status CreatePeEffectivity(ObjectPtr partObj,ObjectPtr vewObj, int start_unit, int end_unit, int* mfail);
status DBOnAgency(ObjectPtr,string,string,string ,SetOfStrings ,integer* );
status EPAXfrToDenisFun(ObjectPtr DmlObj, string tOption,integer*  mfail);
status ExpandAssembly(ObjectPtr  resDmlPartObj, ObjectPtr objDMLtoJT,SET_PTR  setDMLtoJT,integer*  mfail );
status ExpandDoc(string classname,int is_catia_prod_doc,ObjectPtr  DocObj, ObjectPtr objDMLtoJT,SET_PTR  setDMLtoJT,integer*  mfail);
status ExpandTask(ObjectPtr  brkTaskObj,ObjectPtr opDialogObj, SET_PTR setDMLtoJT,integer*  mfail);
status Filter_Dup_Parts(SetOfObjects *NuAplObjects);
status GetCompleteUserName(string userName, string* fullName,int *mfail);
status GetFileFulPthAndObj(char *,char *,char *,char *,char **,ObjectPtr *,int *);
status GetFileFulPthAndObj(char *FileClasNm,char *FileCreDiaNm,char *WrkLocNm,char *FileDefaultNm,char **FlPath,ObjectPtr *FilePtr,int *mfail);
status GetProjectType(char *ProjCode, char *ProjType, int *mfail);
status GetRefDrawforPart(ObjectPtr  resDmlPartObj, ObjectPtr objDMLtoJT,integer*  mfail);
status IsEcnType(ObjectPtr thisObj,ObjectPtr  leftObj,ObjectPtr  rightObj,integer* mfail);
status MainSrldup(char *assembly,char *revision,char *sequence,char *mainserial,int *mfail);
status MoveEpaPartsFunction(string tCurrEpaNo,string InpPlant,string TempPlant,string EpaPlantADup,SetOfStrings EpaSets,integer *mfail);
status NEWNAME(ObjectPtr thisObj,ObjectPtr GenContextObjP,SetOfObjects *vcobj,int *mfail);
status OptionalCsCarryOnSuperSed(ObjectPtr RelObject,string GenOptMakeBuyInd,string UserLocation,integer* mfail);
status OptionalCsTaskCreation(string UsrName,ObjectPtr taskObj,ObjectPtr partObj);
status RecurTPLExplFun(ObjectPtr Vehobj,ObjectPtr TPLObj,ObjectPtr NxtAssObj,SetOfStrings ItmCatSet3,ObjectPtr genContextObj,SetOfStrings outputStringSet,integer* mfail);
status RmvDuplication(ObjectPtr ValTempObj,ObjectPtr PartObj,ObjectPtr genContextObj1,integer *mfail);
status SendEpaReport(ObjectPtr EpaObj, string tOption,integer*  mfail);
status ShowErrorMsg1(int ErrorFlag, string displayvalue);
status ShowStructureErrorMsg(int ErrorFlag, string displayvalue, string passedval);
status UpdClassAttr(ObjectPtr myObj,string AttrName, string AttrVal,integer* mfail);
status UpdOutPutAttr(ObjectPtr myObj,string AttrName, string AttrVal,integer* mfail);
status UpdateEffectivity1(ObjectPtr effRelObj,ObjectPtr partObj, ObjectPtr vewObj,string end_date,integer *mfail);
status UpdatePEEffectivity(ObjectPtr effRelObj,ObjectPtr partObj, ObjectPtr vewObj, string start_unit, string end_unit, int* mfail);
status ValidationOnView(ObjectPtr thisObj,ObjectPtr  leftObj,ObjectPtr  rightObj,integer* mfail);
status VehExplosion(string VCDup,SetOfStrings ItmCatSet3,SetOfStrings outputStringSet,integer* mfail);
status allClausesFunct(ObjectPtr parentObj,SetOfObjects* allClauses,integer* mfail) ;
status copyAttchs(ObjectPtr targetObj,ObjectPtr sourceObj,integer* mfail) ;
status cusCpyCls(SetOfObjects targetSet,SetOfObjects sourceSet,integer* mfail) ;
status delUsrValForRep(string usrName,string hostName,string osName,integer* mfail);
status expandAssemblyByDate(ObjectPtr AssyDup,string DateDup,string ViewDup,string ContextDup,SET_PTR soUsesParts,SET_PTR soUsesPartsRel,integer*  mfail);
status expandAssemblyByRev(ObjectPtr AssyDup,string DateDup,string ViewDup,string ContextDup,SET_PTR soUsesParts,SET_PTR soUsesPartsRel,integer*  mfail);
status expandAssemblyRawByDate(ObjectPtr AssyDup,string DateDup,string ViewDup,string ContextDup,SET_PTR soUsesParts,SET_PTR soUsesPartsRel,integer*  mfail);
status gen_next_addenda4(ObjectPtr *sDML, string *tDML,int * mfail);
status generateDmlBomMth(string chngNotice,string prtRev,string prtSeq,string configCntxt,string viewName,string opFileName);
status generateVehicleBomMth(string prtNum,string prtRev,string prtSeq,string configCntxt,string viewName,string opFileName);
status getComparisonSets(SetOfObjects soUsesPartsA,SetOfObjects soUsesPartsRelA,SetOfObjects soUsesPartsB, SetOfObjects soUsesPartsRelB,SET_PTR soAssyA,SET_PTR soAssyARel,SET_PTR soAssyB,SET_PTR soAssyBRel,SET_PTR soCommon,SET_PTR soCommonRel,integer*  mfail);
status getFromDate(ObjectPtr tmpvcObj1,string viewNameDup2,string *scloserDate,integer* mfail);
status getMakeBuyDetails(string UsrName,string Agency,char *csIndicator,char *IAIndicator);
status getMakeBuyDetailsCSHist(string ,string ,char *,char *);
status getMakeBuyDetailsCSHist(string UsrName,string Agency,char *GenMakeBuyIndicatorCSHist,char *GenIntialAgencyCSHist);
status getPlantDetails(string ProjectCode,string *PlantName);
status getVisViewVersionToLaunch(string userS,string versionS,integer*mfail);
status get_next_epano(ObjectPtr *EPAObj, string *tEpaNo,int * mfail);
status launchIntermBatchProc(string driveS,string serverListS,string LaunchIntrmBat,string dirS,int* stat,integer* mfail);
status printTopLevelJtInfoCol(ObjectPtr* JtFile,FILE *fp,integer* mfail);
status t0CreCstAndUpd(ObjectPtr itemObj, string *sPartNumber, string *sWeight, SetOfStrings *extraStr, SetOfObjects *extraObj, integer *mfail);
status t0DateFormat(string , string *);
status t0GetSheetString(SetOfStrings sheetNumber,SetOfStrings sheetRevision, SetOfStrings sheetSizeSet, SetOfStrings delIndicatorSet, SetOfStrings sheetDescription, string *stringToBeReturned, integer *mfail);
status t0SheetStringToSet(string stringConvertToSet, SetOfStrings *sheetNoReturned,SetOfStrings *sheetRevReturned, SetOfStrings *sheetSizeReturned, SetOfStrings *sheetDelIndReturned, SetOfStrings *sheetDesReturned, integer *mfail);
status t598GrpTplExp(ObjectPtr oToExpand,ObjectPtr oToExpand1,ObjectPtr grpMasObj,ObjectPtr grpMasRelObj,ObjectPtr genContextObj,int level,int count,string viewName,string t5IsDmlDetails,string expand,SetOfStrings *outputStringSet,string t5QtyConsolidateOptDup,string LocationDup,integer *mfail);
status t598GrpTplExpForCSV(ObjectPtr oToExpand,ObjectPtr oToExpand1,ObjectPtr grpMasObj,ObjectPtr grpMasRelObj,ObjectPtr genContextObj,int level,int count,string viewName,string t5IsDmlDetails,string expand,SetOfStrings *outputStringSet,string t5QtyConsolidateOptDup,string LocationDup,integer *mfail);
status t5ActFuncGetCSAttrForPlant(string planttype,char **csIndicator,integer* mfail);
status t5AutoReStructuringAtSTDSI(ObjectPtr	thisObj,SetOfObjects soOrgDmlObjs,string EcnName,int *mfail);
status t5BomCreateByExpl(ObjectPtr PePrtObj,ObjectPtr genContextObj,int sum,ObjectPtr ViewP,integer* mfail);
status t5CaeFnct(const char *, char **, char **, char **, char **);
status t5CaeFnct(const char *szInput, char **szFirst, char **szSecond, char **szThird, char **szFourth);
status t5CheckForValidAssy(string partnum, ObjectPtr *partObj,integer *mfail);
status t5CheckInAllFun(ObjectPtr thisObj,SetOfStrings *templogSOS,string CheckInTime,integer *mfail);
status t5CheckInAndTransferObject(ObjectPtr PrtDocDiObj,ObjectPtr TcPrtObj,string OBIDTcPrt,integer *mfail);
status t5CheckInCstAndMstrObject(ObjectPtr PrtCstMstrObj,integer *mfail);
status t5CheckInModelBeforeDwg(ObjectPtr DIDocObj,ObjectPtr TcPrtObj,string OBIDTcPrt,integer *CheckInDrwStsFlg,integer *mfail);
status t5CheckOutAllFun(ObjectPtr  thisObj, string CheckOutTime, string UserWorkLoc, integer *mfail);
status t5CheckTempPH1AtSTDSI(ObjectPtr thisObj);
status t5ChkPrtDocRevisionMatch(ObjectPtr PrtObj,integer *mfail);
status t5ChkUpdSpdIndicator(SetOfObjects soPartsInTask,SetOfStrings *SoNoSPD,int *mfail);
status t5ConDocSendMail(ObjectPtr prObj,string childpart,integer *mfail);
status t5CopyUnRegFileBackToWIP(ObjectPtr DIObj,integer *mfail);
status t5CreRptFileObj(string strWorkLoc,string ReportFile,ObjectPtr *FileObj,integer*  mfail);
status t5CreateColorPartDup(ObjectPtr NonColourPartObj,string PrntPrtNoDup,string FunColSrl,string FunColID,integer Coated,integer HnjInd , ObjectPtr *NewCreateColourPartObj,integer* Ispresent ,integer*  mfail);
status t5CreatePEBom(ObjectPtr InputObj,integer* mfail);
status t5DelRelUPL(ObjectPtr thisObj,int* mfail);
status t5DmlReleaseLetterFunct(ObjectPtr DmlObjPtr,string filename,string Name,string MailToMngrs,string dsgntn,int *mfail);
status t5EpaOnNextRev(ObjectPtr oToExpand,string tCurrEpaNo,string InpPlant,string TempPlant,string EpaPlantADup,SetOfStrings *tEpaSets,integer *mfail);
status t5ExpandObjecttoJT(ObjectPtr thisObj, integer*	mfail) ;
status t5FilterDocsWithRevNR(SetOfObjects	*docSet, integer *mfail);
status t5FilterUniqueParts(SetOfObjects	*itemObjs,integer* rfail);
status t5GenPrevRevForColPrt(ObjectPtr *colourPart,boolean *isColLcsMch,SetOfStrings *LcsSet,string viewName,string IsBomExWView,integer *mfail);
status t5GenPrevRevForViewExp(ObjectPtr *oToExpand,string viewName,boolean *IsFound,integer *mfail);
status t5GenPrevRevForViewExp1(ObjectPtr *oToExpand,string viewName,boolean *IsFound,integer *mfail);
status t5GenTplExpForCSV(ObjectPtr oToExpand,ObjectPtr oToExpand1,ObjectPtr grpMasObj,ObjectPtr grpMasRelObj,ObjectPtr dialogObj,ObjectPtr genContextObj,int level,int count,string viewName,string t5IsDmlDetails,string t5DrawDetails,string rptPath,string host,string user,string stopCSDupOpt,string stpECSDupOpt,SetOfStrings LcsSet,string strPath,SetOfStrings outputStringSet,string t5QtyConsolidateOptDup,string LocationDup,integer *mfail);
status t5GenTplExpForCSVPE(ObjectPtr oToExpand,ObjectPtr oToExpand1,ObjectPtr grpMasObj,ObjectPtr grpMasRelObj,ObjectPtr dialogObj,ObjectPtr genContextObj,int level,int count,string viewName,string t5IsDmlDetails,string t5DrawDetails,string rptPath,string host,string user,string stopCSDupOpt,SetOfStrings LcsSet,string strPath,SetOfStrings outputStringSet,string t5QtyConsolidateOptDup,string LocationDup,integer *mfail);
status t5GenTplExpForColourForCSV(ObjectPtr oToExpand,ObjectPtr oToExpand1,ObjectPtr grpMasObj,ObjectPtr grpMasRelObj,ObjectPtr dialogObj,ObjectPtr ColObj,ObjectPtr genContextObj,int level,int count,SetOfStrings VCHasClSch,string viewName,string t5IsDmlDetails,string rptPath,string host,string user,string IscoatedSchmDup,string stopCSDupOpt,SetOfStrings LcsSet,ObjectPtr objFile,SetOfStrings outputStringSet,string t5QtyConsolidateOptDup,string LocationDup,string RemoveUnderColDup,integer *mfail);
status t5GenUPL(ObjectPtr thisObj,int* mfail);
status t5GenUPLCurStat(ObjectPtr thisObj,int* mfail);
status t5GenerateChangeReport(ObjectPtr thisObj,string sCreOn,int *mfail);
status t5GenerateEPACreReport(ObjectPtr thisObj,SetOfStrings *outputStringSet,boolean MepaRpt, integer*  mfail);
status t5GenerateIMPLJSRDML(ObjectPtr thisObj,string Dml_No,SetOfStrings *Strs,SetOfStrings JsrVcListSet,ObjectPtr GenContextObjP,integer *mfail);
//status t5GenerateIMPLJSRDMLSTDSI(ObjectPtr thisObj,string Dml_No,ObjectPtr genContextObj,NVSET AsmAgencyNv,string Host,string CurDirTip,string CurDirWT,string CurDirEPA,string CurDirDiff,string CurDirCar,NVSET  *UniqNVAsmAgencySet,integer *mfail);
status t5GenerateSTDRestrReport(ObjectPtr thisObj,SetOfStrings *outputStringSet,string Filepath, integer*  mfail);
status t5GenerateToolIndentCstEstReport(ObjectPtr IndentObj, SetOfStrings *outputStringSet ,integer*  mfail) ;
status t5GenerateToolIndentReport(ObjectPtr IndentObj, SetOfStrings *outputStringSet ,integer*  mfail) ;
status t5GenerateUniqueRequestID(string type,string *id ,integer*  mfail);
status t5MBPAReportFunction(ObjectPtr MbpaObj,string, integer *mfail);
status customClauseCre(ObjectPtr opClause,ObjectPtr opDept,ObjectPtr opDataDia,ObjectPtr OldClauseObj,string sVeh,integer* mfail);
status t5MBPAReportFunctionForExport(ObjectPtr thisObj,integer *mfail);
status t5NonIntChkInAndTrnsfrOwnrShp(ObjectPtr PrtDocDiObj,ObjectPtr TcPrtObj,string OBIDTcPrt,integer *mfail);
status t5ObjGetTableAttribute(ObjectPtr object,string table, string ip_column1, string ip_a_value, string ip_column2, string *ip_a_value2,integer *mfail);
status t5ObjGetTableAttribute(ObjectPtr object,string table, string ip_column1, string ip_a_value, string ip_column2, string *ip_a_value2,integer *mfail);
status t5PartRepliWithCtxt(ObjectPtr partObj, ObjectPtr ctxtObj, string SevList, integer *mfail);
status t5PostReleaseVarification( ObjectPtr thisObj ,SET_PTR *ColourPartSet,integer*  mfail );
status t5PrFOs(SetOfObjects childAsmD,SetOfObjects*	ResRegDIO,integer* mfail);
status t5PrFse(ObjectPtr TknPtr1,ObjectPtr* ConvDc, integer* mfail);
status t5ReGenUPL(ObjectPtr thisObj,int* mfail);
status t5ReportsCSDetails(string a_list,string *csIndicator,string *IAIndicator);
status t5ReviseFun(SetOfObjects LatestDocSO,int *mfail);
//status t5SListAllPartExpFunc1(SetOfObjects setOfObj,SetOfObjects setOfRelObj,SetOfStrings setOflevelStrings,SetOfObjects tempsetOfObj,string RequestID,string RptPath1,string RptPath2, string RptPath3,integer* mfail );
status t5SelectiveSuffixUpt(ObjectPtr ColSchObj,integer*  mfail);
status t5SendMailToPeople(ObjectPtr opPerson,ObjectPtr	opItem,SetOfStrings ssAttrs,string sSubject,string sFirstLine,int *mfail);
status t5SetDBScope(int *mfail);
status t5ShowSchemeForColourPart(ObjectPtr ColourPart, ObjectPtr *Colourscheme ,string	EffectiveDate,integer*  mfail);
status t5ShowSchemeForColourPart(ObjectPtr ColourPart, ObjectPtr *Colourscheme ,string	EffectiveDate,integer*  mfail);
status t5ShowUsesCLPartMsgFunction(ObjectPtr ColourPart,boolean	ShowInWindow,ObjectPtr genContextObjSTD,SetOfObjects *UsesColParts,integer* mfail);
status t5ShowUsesColourPart(ObjectPtr ColourPart, SET_PTR *ColourPartSet ,string InSchmName,integer*  mfail);
status t5SortBOMObjs(SetOfObjects *itemObjs, SetOfObjects *relObjs, integer* mfail);
status t5SortColourPart(SetOfObjects	*itemObjs,integer *mfail);
status t5SortPrtOnDrgInd(SetOfObjects *SorDmlPrtObjSet,integer *mfail);
status t5SortRevObjs(ObjectPtr genContextObj, SetOfObjects *itemObjs, string Chkdate, integer*	mfail );
status t5StringToStringSetFun(string t5ERCIndDescVarDup,int t5divider,SetOfStrings t5StringSet,integer *mfail);
status t5Topran_Fun(ObjectPtr docObj,SetOfObjects childAsmD, integer*	mfail) ;
status t5TransCaeDocForHM(ObjectPtr thisObj,integer*  mfail);
status t5Translate_Fun( ObjectPtr thisObj, integer *mfail);
status t5UpdAplStrInd(ObjectPtr LeftObj,integer *mfail);
status t5UpdSMDMLForRelation(ObjectPtr RelObject,string SMDMLNum,integer *mfail);
status t5UpdateColourScheme(ObjectPtr CLObj,ObjectPtr *thisObj, ObjectPtr GenCtxtObj ,SET_PTR *CCAHasCCATPLSet,SET_PTR *CompCodeCompltdSet,integer*  mfail);
status t5UsrCheck(char user[100], int *UserDb, integer *mfail);
status t5WorkOrderList(ObjectPtr thisObj,SetOfStrings*   values ,integer*  mfail);
status t5getDMLForPart(ObjectPtr PrtObj, string *partDML,integer *mfail);
status t5getPartObjFromNum(string partNum,ObjectPtr *partObj,int *mfail);
status t5getPlantName1(string DbName,string *PlantType, integer *mfail);
status t5getRqDomainName(string domain, string *domainName, integer *mfail);
status t5getUserDetails(string UsrName,string *Agency,string *Location,int *mfail);
status t5getViewObjFromStr(string vewName,ObjectPtr *vewObj,int *mfail);
status t5setCtxtByOption(ObjectPtr genContextObj,string strOption,string strVewName,int zeroQty, int *mfail);
status usrValForRep(string usrName,string hostName,string osName,integer* mfail);
status GetLatestOwnerships (ObjectPtr oSubObj,integer* mfail);
status GetLatestStruct (ObjectPtr oSubObj,integer* mfail);
status CreHlgDocStruct (string sSubjectDoc,ObjectPtr oHdrObj,ObjectPtr dialogObj,integer* mfail);
status t5ArHdrUpd2R (SetOfStrings soChildren, ObjectPtr opParentObj,ObjectPtr opDialogObj,integer* mfail);
status GetMultiLvlImpVehRestr (ObjectPtr ChildPart,ObjectPtr PhOneRelPart,ObjectPtr PhOnePart,ObjectPtr PhTwoPart,ObjectPtr GenContextObjP,SetOfStrings *outputStringSet,SetOfStrings *CreResHisSet,SetOfObjects *FoundObjs,int *mfail);
status stdsichildprtvalidation (ObjectPtr thisObj,int *mfail,SetOfStrings *Str);
status t5StdAMDMLValidation (ObjectPtr thisObj,int *mfail,SetOfStrings *Str);
status t5PrintPartInfo (ObjectPtr thisObj,ObjectPtr thisRelObj,string curdir1,int l,int *mfail);
status GetMultiLvlImpVehRestr (ObjectPtr ,ObjectPtr ,ObjectPtr ,ObjectPtr ,ObjectPtr ,SetOfStrings *,SetOfStrings *,SetOfObjects *,int *);
status DBOnAgency1 (string                  ,       string                  ,       string                  , integer*   );
status getMatAttrs (        char* ,         char* ,         char* ,         char* ,         integer*  );
status getUsrDetails (      char* ,         char* ,         char* ,         integer*  );
status t5getRec (ObjectPtr,ObjectPtr,int *,int *);
status t5ToPDupCk (ObjectPtr docObj1,string *DFlag, integer*   mfail);
status t5PrintDOp1 (ObjectPtr thisObj,string curdir1,int l,int *mfail);
status t5PrintDOp (ObjectPtr thisObj,ObjectPtr thisRelObj,string curdir1,int l,string csplant1,int *mfail);
status t5getRec (ObjectPtr thisObj,ObjectPtr genContextObj,int *RecFlag ,int *mfail);
status DBOnAgency1 (string                   ,       string                  ,       string                  , integer*   );
status getColourVC_p (ObjectPtr thisObj,string compartdup,string quantitystring,string CurDir,string csplant1,int *mfail);
status t5PrintDOpMulPrt (ObjectPtr thisObj,string curdir1,int l,string csplant1,int *mfail);
//status t5SListAllPartExpFunc1(SetOfObjects setOfObj,SetOfObjects setOfRelObj,SetOfStrings setOflevelStrings,SetOfObjects tempsetOfObj,string RequestID,string RptPath1,string RptPath2, string RptPath3,integer* mfail );
status t5InfDAttch (ObjectPtr PrtWInf,ObjectPtr PrtToAdInf,integer *mfail);
status t5CndExpFun(ObjectPtr oToExpand,string sRelClass,string sRelation,string sCndAtt,string sCndVal,SetOfObjects* soRHObjs,integer *mfail);
status t5FilterSO(SetOfObjects soObjToFilt,string sAttribute,string sValue,string sType,SetOfObjects* soResultObjs,integer* mfail);
status t5BKPExpFunc(SetOfObjects itemObjs,ObjectPtr dialogObj,int level,integer* mfail);
status t5SortByAgencyPartNo1(SetOfObjects* itemObjs,integer* mfail);
status t5ExclGetview(string agencyDup,string* Viewname);
status GetMultiLevelExpForExclusiveParts2(ObjectPtr partObj,integer reqLevel,ObjectPtr contextObj,SetOfObjects* childObjs,SetOfObjects* childRelObjs,SetOfStrings* levels,string VcNum,integer* mfail);
status t5GetSLBomExplosion1LKN(ObjectPtr partObj,integer reqLevel,ObjectPtr contextObj,SetOfObjects* childObjs,SetOfObjects* childRelObjs,SetOfStrings* levels,integer* level,integer flag,integer* mfail);
status t5FitExpFunc(SetOfObjects VCParts,ObjectPtr dialogObj,int level,integer* mfail);
status t5GetExplosionSum(ObjectPtr partObj,integer reqLevel,ObjectPtr contextObj,SetOfObjects* childObjs,SetOfObjects* childRelObjs,SetOfStrings* levels,integer* level,integer* mfail);
status t5GetLatestDrwDoc1(SetOfObjects docObjs,ObjectPtr* latestDocs,integer* mfail);
status t5GetSLBomExplosion1(ObjectPtr partObj,integer reqLevel,ObjectPtr contextObj,string plantn2,SetOfObjects* childObjs,SetOfObjects* childRelObjs,SetOfStrings* levels,integer* level,integer flag,integer* mfail);
status t5GetSLExplosionUpCs1(ObjectPtr partObj,integer reqLevel,ObjectPtr contextObj,string plantn2,SetOfObjects* childObjs,SetOfObjects* childRelObjs,SetOfStrings* levels,integer* mfail);
status t5GetSLExplosionUpCs2(ObjectPtr partObj,integer reqLevel,ObjectPtr contextApl,ObjectPtr contextApl1,SetOfObjects* childObjs,SetOfObjects* childRelObjs,SetOfStrings* levels,SetOfStrings ProjNameSet,integer* mfail);
status t5GetSLExplosionUpCs(ObjectPtr partObj,integer reqLevel,ObjectPtr contextObj,SetOfObjects* childObjs,SetOfObjects* childRelObjs,SetOfStrings* levels,string* Plant,integer* mfail);
status t5SortBYAgencyFun(SetOfObjects* itemObjs,SetOfObjects* relObjs,integer* mfail);
status t5SortByAgencyPartNo(SetOfObjects* itemObjs,SetOfObjects* relObjs,integer* mfail);
status t5SortByDsgGrp(SetOfObjects* itemObjs,SetOfObjects* relObjs,integer* mfail);
status t5SortByPartNo(SetOfObjects* itemObjs,SetOfObjects* relObjs,integer* mfail);
status t5GetDocumentTypes(SetOfObjects docObjs,SetOfStrings* docTypes,integer* mfail);
status t5GetLatestDocumnets(SetOfObjects docObjs,SetOfObjects docRelObjs,SetOfObjects* latestDocs,SetOfObjects* latestRelDocs,integer* mfail);
status t5GetTypeDocuments(SetOfObjects docObjs,SetOfObjects docRelObjs,string docType,SetOfObjects* docTypeObjs,SetOfObjects* docTypeRelObjs,integer* mfail);
status t0LatestBI(SetOfObjects itemObj,SetOfObjects itemRel,ObjectPtr* returnedObj,ObjectPtr* returnedRel,integer* mfail);
status smGetSessionUsrName(string *);
status  t5CheckForSTDColPartReleased(ObjectPtr thisObj,int *mfail,SetOfStrings *Str);
status ClauseUpdCre(ObjectPtr MClause,ObjectPtr MSubj,ObjectPtr SubjObj,ObjectPtr ClauseObj,integer* mfail);
status GetTextPages(ObjectPtr SubObj,string host,string pdf,string xmlpath,string *totalnm,integer *mfail);
status GetTextPagesEur(ObjectPtr SubObj,string host,string pdf,string xmlpath,string* totalnm,integer* mfail);
status  t5IsVisFile(ObjectPtr thisObj,int *mfail);
status  t5ModelCheck(ObjectPtr thisObj,int *mfail);
status  t5RevRlzCheckForSTDS1(ObjectPtr thisObj,int *mfail,SetOfStrings *Str);
status  t5SeqRlzCheckForSM(ObjectPtr thisObj,int *mfail);
status  t5SeqRlzCheckForSTDS1(ObjectPtr thisObj,int *mfail,int *resultPrev,SetOfStrings *Str);
status  usrGetName(string sUserId,string *usrname,int *mfail);
int CheckAffectedDrawing(ObjectPtr Assmly,char DmlNo[20]);
boolean CheckPEDocDIStatus(ObjectPtr itemObj, string Syscd, string Action,integer *mfail);
boolean CheckPartAttrStatus(ObjectPtr itemObj, string Syscd, string Action,integer *mfail);
int CheckRelstatusN(ObjectPtr LeftObjP ,ObjectPtr RightObjP ,string RelClass ,integer* mfail);
int CheckRelstatus(ObjectPtr LeftObjP ,ObjectPtr RightObjP ,string RelClass ,integer* mfail);
int CheckforBasicDMLRelease( ObjectPtr thisObj ,integer*  mfail );
void DECODE_Agency(char charInp,string StrAgency);
status t5SortByICRNo1(SetOfObjects* itemObjs,integer* mfail);
status GetTextPagesGulf(ObjectPtr SubObj,string host,string pdf,string xmlpath,string* totalnm,integer* mfail);
int FindAddedDeletedParts(char DmlNo[20], ObjectPtr Assmly ,SetOfObjects AsmMstrObjs , SetOfObjects AsmMstrRelObjs );
int GetIndirectlyAffectedParts(ObjectPtr passedObj,char DmlNo[20],int Add_Del_Ind);
int IsCEVault(ObjectPtr thisObj1,int *mfail);
boolean PartAttrStatusMasterFunc(ObjectPtr itemObj, string Syscd, string Action,integer *mfail);
int Stamp_STD_Eff(ObjectPtr oPartObj,string StampViewStr);
status t5HlgCmpMatrix(string ipclauseNumber,string ipValue,int column,int *mfail);
void StringCpyForCSV( char * Str1 ,int Str1Size ,char *Str2 );
int datecompare(char *date1,char* date2);
int getMoveRelation();
int getcurrentuser(string GroupName,integer* mfail);
int getVCExplodedList(ObjectPtr partObj,SetOfObjects* SetofVCExploded,int* mfail);
void hlg_string_replace( char * Str1 ,int Str1Size ,char *Str2 );
int t5DateComparision(string TarDate);
boolean t5RHCheck(ObjectPtr itemObj,integer *mfail);
int t5ValSignOff(ObjectPtr UPLHdr,string Assgn,int* mfail);
int validatePartWithVC(ObjectPtr ClrPartObj,string VCNoDup,string DMLNo,int* mfail);

unsigned long CalcDays(char *Date);
status CmpReportGen(ObjectPtr thisObj,string XSLName,integer* mfail);
status DrStatusCheckForPart(ObjectPtr PrtObj,int *mfail, int *DRresult);
status GetMultiLevelExpForExclusiveParts(ObjectPtr partObj,integer reqLevel,ObjectPtr contextObj,SetOfObjects* childObjs,SetOfObjects* childRelObjs,SetOfStrings* levels,integer* mfail);
status GetUsesColourParts(ObjectPtr ColourPart,SetOfStrings *ColSchemeS,integer* mfail);
status GetUsesColourPartsForVC(ObjectPtr NonColVc,SetOfStrings *ColourSchemes,integer* mfail);
status ReportFun(ObjectPtr thisObj,string XSLName,integer* mfail);
status SendViewStampFailMail(ObjectPtr obj,integer* mfail);
status SourceListMultiLevelExp(ObjectPtr partObj,integer reqLevel,ObjectPtr contextObj,SetOfObjects* childObjs,SetOfObjects* childRelObjs,SetOfStrings* levels,string ParentQty,integer* mfail);
status StructureChangeDetailsFun1(ObjectPtr thisObj,ObjectPtr vcObj1,ObjectPtr vcObj2,string viewNameDup1,string EpaPlant,integer* mfail);
status UpdDrwIndBasedOnAnnotation(ObjectPtr TCPartObj, ObjectPtr CadObj, integer *mfail);
status UpdateEffectivity(ObjectPtr effRelObj,ObjectPtr partObj, ObjectPtr vewObj,string start_date, string end_date,integer* mfail);
status UpdateEffectivity2(ObjectPtr effRelObj,ObjectPtr partObj, ObjectPtr vewObj,string start_date, string end_date,integer *mfail);
status expandAssemblyRawByRev(ObjectPtr AssyDup,string DateDup,string ViewDup,string ContextDup,SET_PTR soUsesParts,SET_PTR soUsesPartsRel,integer*  mfail);
int getAplSGRValue();
status getColourVC (ObjectPtr thisObj,string compartdup,string quantitystring,string CurDir,string csplant1,int *mfail);
void setMoveRelation();
status t5CheckPartValidWorkAssgn(ObjectPtr PartObj,integer* mfail);
int t5ChkCfgCntxt(string* ret_locCfgId,int *mfail);
status t5EpaOnPrevRev(ObjectPtr oToExpand,string tCurrEpaNo,string InpPlant,string TempPlant,string EpaPlantADup,SetOfStrings *tEpaSets,integer *mfail);
status t5ExpMulFun(ObjectPtr oToExpand,ObjectPtr genContextObj,SetOfStrings *assyInfo,int *lineLen,int *begCol,int *endCol,int *RowNo,integer *mfail);
status t5FinalizeTskFunc(ObjectPtr thisObj,integer *mfail);
status t5GeExclusivePartFuction(SetOfObjects itemObjs,ObjectPtr dialogObj,SetOfStrings setOfAgency,SetOfStrings outputStringSet,integer* mfail);
//status t5GenTPLMulVc(string filenamedup,string gcontext1dup,string gcontext2dup,string agency1dup,string agency2dup,string part1dup,string rev1dup,string seq1dup,string part2dup,string rev2dup,string seq2dup,string sapdatadup,string username,string cHostDup,string cWorkLocDup,int reqlevel,string RevWiseDup,string DtWiseDup,string VCDt1Dup,string VCDt2Dup,integer* mfail);
status t5GentplCoatedPrtExpCSVR(ObjectPtr oToExpand,ObjectPtr oToExpand1,ObjectPtr grpMasObj,ObjectPtr grpMasRelObj,ObjectPtr genContextObj,string viewName,int slvl,int count,boolean *AssyHasFlag,SetOfStrings LcsSet,SetOfStrings VCHasClSch,string rptPath,string host,string user,SetOfStrings *outputStringSet,string CSAttribute,integer *mfail);
status t5GentplCoatedPrtExpTxt(ObjectPtr oToExpand,ObjectPtr oToExpand1,ObjectPtr grpMasObj,ObjectPtr grpMasRelObj,ObjectPtr genContextObj,string viewName,string t5IsDmlDetails,int slvl,int count,boolean *AssyHasFlag,SetOfStrings LcsSet,SetOfStrings VCHasClSch,SetOfStrings *outputStringSet,string t5QtyConsolidateOptDup,string LocationDup,integer *mfail);
status t5GetAttachmentFun(ObjectPtr DesObj,SetOfStrings *assyInfo,int *lineLen,integer *mfail);
status t5GetBomExplosion(ObjectPtr partObj,integer reqLevel,ObjectPtr contextObj,SetOfObjects *childObjs,SetOfObjects *childRelObjs,SetOfStrings *levels,integer* level,integer flag,SetOfObjects* GrpTPLSO,NVSET* consolidatedQty,integer prntQty,integer* mfail);
status t5GetCntxtObjReStr(ObjectPtr thisObj,string VewNameS, string ContextOptS,ObjectPtr *genContextObj,integer*  mfail);
status t5GetCntxtObjUplJSR(ObjectPtr thisObj,string VewNameS, string ContextOptS,string EffUplDateS,ObjectPtr *genContextObj,integer*  mfail);
status t5GetCommonPartFuction(SetOfObjects itemObjs,ObjectPtr dialogObj,SetOfStrings setOfAgency,SetOfStrings outputStringSet,integer* mfail);
status t5GetDML(SetOfObjects instanceobjSO, SetOfStrings* DMLWbsid, SetOfStrings* DMLdesc, SetOfStrings* DMLCat, integer* mfail );
status t5GetDmlForPart(ObjectPtr thisObj,ObjectPtr *DmlObj,integer*  mfail);
status t5GetDmlImpPartDetailsJSR(ObjectPtr thisObj,ObjectPtr genContextObj,SetOfStrings *StrsPrt,integer*  mfail);
status t5GetECUDBScope(int *mfail);
status t5GetExplosion(ObjectPtr partObj,integer reqLevel,ObjectPtr contextObj,SetOfObjects *childObjs,SetOfObjects *childRelObjs,SetOfStrings *levels,integer* level,integer* mfail);
status t5GetLatestDrwDoc(SetOfObjects docObjs,ObjectPtr *latestDocs,integer* mfail);
status t5GetMultiLevelExplosionD(ObjectPtr partObj,integer reqLevel,ObjectPtr contextObj,SetOfObjects* childObjs,SetOfObjects*   childRelObjs,SetOfStrings*   levels,integer* mfail);
status t5GetMultiLevelExplosionDForEx(ObjectPtr partObj,integer reqLevel,ObjectPtr contextObj,SetOfObjects*   childObjs,SetOfObjects*   childRelObjs,SetOfObjects*   ssOfCommObjs,SetOfObjects*   ssOfCommRelObjs,SetOfStrings*   levels,integer* mfail);
status t5GetExplosionNewDD(ObjectPtr partObj,integer reqLevel,ObjectPtr contextObj,SetOfObjects    *childObjs,SetOfObjects    *childRelObjs,SetOfStrings    *levels,integer* level,string t5X3ProjFlagDup,string ViewNameS,integer* mfail);
status t5GetExplosionForClrBomCmpr(ObjectPtr partObj,integer reqLevel,ObjectPtr contextObj,SetOfObjects    *childObjs,SetOfObjects    *childRelObjs,SetOfStrings    *levels,integer* level,SetOfStrings    *QUANTITY,string qty,integer* mfail);
status t5GetNextFeedbackSeries(string catagory,string *nxtSrl ,integer*  mfail);
status t5GetNextFirSeries(string catagory,string *nxtSrl ,integer*  mfail);
status t5GetNextReqSeries(string catagory,string *nxtSrl ,integer*  mfail);
status t5GetPartDetails(SetOfObjects instanceobjSO,string plant,string epaNo,SetOfStrings* col1,SetOfStrings* col2,SetOfStrings* col3,SetOfStrings* col4,SetOfStrings* col5,SetOfStrings* col6,SetOfStrings* col7,SetOfStrings* col8,SetOfStrings* col9,int* mfail );
status t5GetPartobjbyEffectivity(SetOfObjects selectedObj,string cuttoffdate,ObjectPtr *partbyeffObj,int *prtfnd,integer*  mfail);
status t5GetUPLReportHeaderPrint(ObjectPtr thisObj,string strPath,int ReportType,integer*  mfail);
status t5GetUPLRptHdrPrnt(ObjectPtr thisObj,string strPath,int ReportType,integer*  mfail);
status t5SListAllPartExpFunc(SetOfObjects itemObjs,ObjectPtr dialogObj,SetOfStrings setOfAgency,SetOfStrings outputStringSet,integer* mfail);
status t5GetUplRptObjPath(string WorkLocName,string ReportFor,string ReportName,string ReportType,string *filename,char **RptPath,integer*  mfail);
status t5GetUplRptPath(string WorkLocName,string ReportFor,string ReportName,string ReportType,char **RptPath,integer*  mfail);
status t5GetUplRptPath_Filepointer(string ReportFor,string ReportName,string ReportType,char **RptPath,ObjectPtr *FileObj,integer*  mfail);
status t5IfPrtDocDiInVaultChgLCSAndFrz(ObjectPtr thisObj,SetOfObjects PrtDocDIObjs,integer *mfail);
status t5IfPrtDocDiInWlChgAttrb(ObjectPtr PrtDocDIOP,integer *mfail);
status t5ImpMulFun(ObjectPtr oToExpand,ObjectPtr genContextObj,SetOfStrings *assyInfo,int *lineLen,int *begCol,int *endCol,int *RowNo,integer *mfail);
status t5IsNonBomDoc(ObjectPtr  thisObj,boolean *result,int *mfail);
status t5LeadingTrim(string t5Sourcestring,int ChartoTrim,string t5MintProcIdZ,integer *mfail);
status t5LkoSTDEff(ObjectPtr thisObj,integer* mfail);
status t5PartHasWrkEPA(ObjectPtr PartObj,string DMLNo,string FailPassEPA,integer *mfail);
//status t5PlmSapValFunction(ObjectPtr DmlObj, ObjectPtr ColourPartObj);
status t5PlmSapValFunction(ObjectPtr DmlObj, ObjectPtr ColourPartObj,int *ResultFlag,int *Status,integer *mfail);
int t5PrepareMatrix(string thismatchsubdiv,int rowl,int col,int setsize,int model,int *mfail);
status t5SLExplosionUpCs(ObjectPtr partObj,integer reqLevel,ObjectPtr contextObj,SetOfObjects* childObjs,SetOfObjects* childRelObjs,SetOfStrings* levels,string ParentQty,string* Plant,integer* mfail);
status t5SListAllPartExpFunc(SetOfObjects itemObjs,ObjectPtr dialogObj,SetOfStrings setOfAgency,SetOfStrings outputStringSet,integer* mfail);
status t5SortBOMObjsByDate(SetOfObjects      *,SetOfObjects  *,integer *);
status t5SortSchObjsByDate(SetOfObjects    *itemObjs,SetOfObjects    *relObjs,integer* mfail );
status t5ValidatePrtDrpOnSMDML(ObjectPtr DmlTaskObj,ObjectPtr droppedObj,integer      *mfail);
int DZ_CHK_IN_TML_DM_FROM_TMETC(char inp_Prt[40],char GET_TML_Assm_DB_UserName[20],char GET_TML_Assm_DB_Pwd[20]);
status getPartAttrs (char* ,char* ,char* ,char* ,char* ,char* ,char* ,integer*);
int DZ_SPD_Get_Stock_SAP(char PartNumber[60],char PlantName[30],char** Stock);
int DZ_SPD_Get_PODtl_SAP(char PartNumber[60],char PlantName[30],char** PONumber,char** PODate,char** PrOrg,char** VendName);
int DZ_GetDenisStatus(char FirstCh[20]);
int DZ_CheckValConn(char Req_Id[60],int *Exeflg);
status t5MulLvlExplFunForParts(ObjectPtr oToExpand,ObjectPtr genContextObj,SetOfStrings *outputStringSet,int *RowNo,int iLLimit,integer* mfail);
int DZ_t5ChkRecordMBPA(char FirstCh[15]);
void t5GetNextColSrl(string,string);
status t5GentplCoatedPrtExpCSV(ObjectPtr oToExpand,ObjectPtr oToExpand1,ObjectPtr grpMasObj,ObjectPtr grpMasRelObj,ObjectPtr genContextObj,string viewName,string t5IsDmlDetails,int slvl,int count,boolean *AssyHasFlag,SetOfStrings LcsSet,SetOfStrings VCHasClSch,SetOfStrings *outputStringSet,string t5QtyConsolidateOptDup,string LocationDup,integer *mfail);
//Added for Multiplant changes by JSR
void ReverseStr(char str[]);
status t5GetTaskDmlLastValue(string DmlTaskName,string myPlant,integer* mfail);
status t5GetLivePlantCotrolObjSet(char* ProjCode,SetOfObjects soPlntCtrlObj,integer* mfail);
status t5GetPlantDmlDetails(char* ProjCode,SetOfStrings soinfo1,SetOfStrings    soinfo2,SetOfStrings    soinfo3,integer* mfail );
status t5GetPlantDmlAPLDetails(char* ProjCode,char* InputSTDDMLSuffix,char* ReturnAPLSuffix,char* Location,     integer* mfail);
status t5GetPlantDmlSTDDetails(char* ProjCode,char* InputAPLDMLSuffix,char* ReturnSTDSuffix,char* Location,     integer* mfail );
//Added by Anu Nair for SCO  5241
status SpecialRstrctdGrpCheck(string ,string , string , integer* );
status checkforSPV(string ,string ,integer* );
status checkUserValidityforSPV(string ,string ,string ,integer* );
status t5SpecialAccGrpChk(ObjectPtr ,integer* );
status oscItemFoundChangeDatabaseScope(ObjectPtr oscItemObj, integer *mfail) ;
//End of Added by Anu Nair for SCO  5241
status t5getIDTSubGroupName(string,string, integer *);
char* ValidateHlgUser(ObjectPtr,string,char * );
status StaleRemove(ObjectPtr DIObj,integer *mfail);
int CreateAndClassify(int ,char *,char *,char *,char *);

