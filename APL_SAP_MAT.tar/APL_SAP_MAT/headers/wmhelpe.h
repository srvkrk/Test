/**********************************************************************/
/*                                                                    */
/* (C) Copyright  SAP AG, Walldorf  1997                              */
/*                                                                    */
/* wmhelpe.h                                                          */
/*                                                                    */
/* Workflow application programming interface administration and      */
/* help functions (header file). For external use, too.               */
/* (WAPI interface 2, Version 1.1, March 1997).                       */
/*                                                                    */
/* Author:		Stefan Maier																					  */
/* Reviewer:	Rainer Weber																						*/
/*                                                                    */
/* Standard C code (fully portable)                                   */
/*                                                                    */
/**********************************************************************/


#ifndef WMHELPE_H
#define WMHELPE_H


/* Include files */
#include "sapwapit.h"


/*************************/
/* Definitions (#define) */
/*************************/


/* Take the lower value out of two values */
#define TAKE_MIN(a,b) (((a)<(b)) ? (a):(b))

/*#define __min(a,b) (((a)<(b))?(a):(b))*/

/************************/
/* Type casting support */
/************************/


/* The following macros refer to standard C functions */
#define SAP_WAPI_STRLEN( str )               strlen(  (char*)str )
#define SAP_WAPI_STRCPY( dest, src )         strcpy(  (char*)dest, \
                                                      (char*)src )
#define SAP_WAPI_STRNCPY( dest, src, chars ) strncpy( (char*)dest, \
                                                      (char*)src, \
                                                      chars )
#define SAP_WAPI_STRCAT( dest, append )      strcat(  (char*)dest, \
                                                      (char*)append )
#define SAP_WAPI_STRCMP( str1, str2 )        strcmp(  (char*)str1, \
                                                      (char*)str2 )
#define SAP_WAPI_STRNCMP( str1, str2, chars) strncmp( (char*)str1, \
                                                      (char*)str2, \
                                                      chars )


/****************************************************/
/* Converting macros (generated via SAP R/3 system) */
/****************************************************/


/* The value of str is copied into var, str will be blank padded. */
#define SETCHAR(var, str)	memcpy(	var,\
																	str,\
																	TAKE_MIN(SAP_WAPI_STRLEN(str),\
                                           sizeof(var))); \
													if (sizeof(var)>SAP_WAPI_STRLEN(str)) \
														memset(	var+SAP_WAPI_STRLEN(str),\
																		BLANK,\
																		sizeof(var)-SAP_WAPI_STRLEN(str))

/* See SETCHAR, var will be terminated with a NULL_BYTE. */
#define SETCHAR_NULL_STRING(var, str) memcpy(	var,\
																							str,\
																							TAKE_MIN(\
                                                SAP_WAPI_STRLEN(str),\
																							  sizeof(var))); \
																			if (sizeof(var)\
                                            >SAP_WAPI_STRLEN(str))\
																				memset(	var+SAP_WAPI_STRLEN(\
                                                      str),\
																				        BLANK,\
																				sizeof(var)\
                                          -SAP_WAPI_STRLEN(str)); \
																			var[ sizeof(var)-1 ]\
																				= NULL_BYTE

/* The value of str is copied into var (format of var is like NUMC
   format inside SAP R/3 <0..0><value>). */
#define SETNUM(var,str)	memcpy(	var+(sizeof(var)-TAKE_MIN(\
                                       SAP_WAPI_STRLEN(str),\
																sizeof(var))),\
																str,\
																TAKE_MIN(SAP_WAPI_STRLEN(str),\
                                         sizeof(var))); \
												if (sizeof(var)>SAP_WAPI_STRLEN(str))\
													memset(var,'0',sizeof(var)\
																					 -SAP_WAPI_STRLEN(str))

/* Like SETNUM, only var is NULL terminated at the end */
#define SETNUM_NULL_STRING(var,str)	memcpy(	var+(sizeof(var)-TAKE_MIN(\
                                       				SAP_WAPI_STRLEN(str),\
																						sizeof(var))),\
																						str,\
																		TAKE_MIN(SAP_WAPI_STRLEN(str),\
                                    	      sizeof(var))); \
												if (sizeof(var)>SAP_WAPI_STRLEN(str))\
													memset(var,'0',sizeof(var)\
																					 -SAP_WAPI_STRLEN(str));\
												var[ sizeof(var)-1 ] = NULL_BYTE


/*set BCD*/


/*************/
/* Functions */
/*************/


/*********************/
/* Diverse functions */
/*********************/


WMTPText SAPWapiBuildEngineName (
	in	WMTPText phostname,
  in  WMTInt32 sysnr,
  in  WMTPText pclient,
  in  WMTPText planguage );

WMTErrRetType SAPWapiStartWorkFlow (
	in	WMTPSessionHandle psession_handle,
	in	SAPWapiTPTaskID ptask_id,
	in	WMTUInt32 input_container_lines_count,
	in  SAPWapiTPContainer pinput_container_lines,
	out SAPWapiTPItemID pitem_id,
  out WMTPInt32 pmessage_lines_count,
  out SAPWapiTPMessage* ppmessage_lines );

WMTErrRetType SAPWapiCreateEvent (
	in	WMTPSessionHandle psession_handle,
	in	SAPWapiTPObjectType pobject_type,
	in	SAPWapiTPObjectKey pobject_key,
  in	SAPWapiTPEvent pevent,
	in	WMTUInt32 input_container_lines_count,
	in  SAPWapiTPContainer pinput_container_lines,
	out SAPWapiTPEventID pevent_id,
  out WMTPInt32 pmessage_lines_count,
	out SAPWapiTPMessage* ppmessage_lines );


#endif
