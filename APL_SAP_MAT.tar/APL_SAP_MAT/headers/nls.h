/* $Id: nls.h,v 2.25.2.3 1999/01/29 23:19:48 smdw Exp $ */
/*
bcprt
THIS SOFTWARE AND RELATED DOCUMENTATION ARE PROPRIETARY TO SIEMENS PRODUCT LIFECYCLE MANAGEMENT SOFTWARE INC.
COPYRIGHT 2015 SIEMENS PRODUCT LIFECYCLE MANAGEMENT SOFTWARE INC. ALL RIGHTS RESERVED.
ALL TRADEMARKS BELONG TO THEIR RESPECTIVE HOLDERS.
ecprt
 */

/*******************************************************************************
 * FILE
 *   nls.h
 *
 * DESCRIPTION
 *   Definitions and include files for the nls subsystem.
 *
 * NOTES
 *   None.
 *
 * HISTORY
 * 02/03/94  Add function prototype for nlsGetTextHelp.                RJV
 * 02/07/94  Add function prototype for nlsGetAutoParameter.           RJV
 * 02/07/94  Add error constant NLS_ERR_NO_SUBSTITUTION.               RJV
 * 02/08/94  Remove definition of NLS_CENTURY and modified NLSDATE.    RJV
 * 02/10/94  Move prototype for nlsSubstituteText here from nlstxt.c.  RJV
 * 02/15/94  Modify error codes.  Add prototypes for new functions.    RJV
 * 02/22/94  Modify/delete error codes.                                RJV
 * 03/05/94  Add/rearrange function prototypes, rename constant.       RJV
 * 03/07/94  Define NLS_NEWLINE_CHARACTER and NLS_STRING_TERMINATOR.   RJV
 * 03/07/94  Add prototype for nlsGetTextLabel.                        RJV
 * 03/15/94  Add little C wrappers.                                    RJV
 * 03/18/94  Add/remove/enhance of symbolic constants.                 RJV
 * 03/23/94  Rename typedef to avoid little c conflict.                RJV
 * 03/24/94  Add prototypes for string manipulation routines.          RJV
 * 03/28/94  Add #ifndef _LCINTERP_ to solve little c problem.         RJV
 * 03/29/94  Add prototype for nlsGetTextFileDir.                      RJV
 * 03/30/94  Rename string field to strng to avoid little c conflict.  RJV
 * 04/04/94  Add prototype for nlsStrNCmp and nlsStrNCaseCmp.          RJV
 * 04/07/94  Modify prototypes to accommodate little c problem.        RJV
 * 04/08/94  Add #defines for new symbolic constants.                  RJV
 * 04/18/94  Add prototype for nlsStrDup.                              RJV
 * 04/18/94  Add #defines for NLS_OKAY and NLS_FILE_ACCESS_ERROR       RJV
 * 04/22/94  Modify names of symbolic constants to aviod conflicts.    RJV
 * 05/02/94  Add/modify #defines for single text file configuration.   RJV
 * 05/04/94  Remove filename field from the nlsTextType structure.     RJV
 * 08/26/94  Add prototypes for nlsConvert* functions and #defines.    RJV
 * 09/05/95  Add prototypes for nlsconv.c functions and #defines.      PHY
 * 10/24/95  Add prototypes for callback setting functions.            JDG
 * 12/15/95  Refined multibyte conversion prototyping, etc.            TJC
 * 01/19/96  Add #defines and prototypes for userpref support funcs.   RJV
 * 01/31/96  Add #define for NLS_BLANK_CHARACTER.                      RJV
 * 02/12/96  Use MTI_FDECL for nlsStrChangeNewlinesToBlanks            RJV
 * 02/29/96  Add prototype for nlsStrDupBackSlashes.                   RJV
 * 03/09/96  Update multibyte conversion support for 2.2               TJC
 * 09/19/97  Added nlsStrReplaceNonPrint.                              TPD
 * 10/08/97  Remove all traces of non-ANSI prototypes.                 BRP
 * 02/11/99  Change nlsConvert* in nlstxt to use MTI_FDECL.            DJR
 * 07/30/99  Add prototype for nlsGetTimeStamp.                        MDS
 * 10/07/99  Add prototype for nlsStrGetLine.                          CJW
 * 01/24/00  Add prototype for nlsIsPrint.                             AMS
 * 10/31/00  Change NLS_PRODVER_DFLT for pre-release "3.2.1"           SHOLM
 * 01/25/01  Add prototypes for nlsStrToLower/Upper.                   AMS
 * 02/27/01  Add new multibyte conversion prototyping for Chinese.     XLU
 * 05/09/01  Update NLS_PRODVER_DFLT and PRODNAM for Delmar 3.3.       TJD
 * 05/23/01  Update NLS_PRODVER and PRODNAM for Delmar 1.0             TJD
 * 10/05/01  Change NLS_PRODVER_DFLT for release "2.0.0"               GWEI
 * 05/30/01  Update NLS_PRODVER_DFLT and PRODNAM fo TC3.0              TJD
 * 07/01/02  Added nlsStrReplaceNewlines and nlsStrReplaceNewlinesInSet TRS
 * 02/16/03  Update NLS_PRODVER_DFLT and PRODNAM fo TC3.1              BJL
 * 07/31/03  Update NLS_PRODVER_DFLT and PRODNAM fo TC4.0              GWEI
 * 05/10/03  Add prototypes for fixing PR1175077                       XLU
 * 04/23/04  Add prototype for function nlsIsHebrew                    XLU
 * 05/11/04  Add prototype for function nlsStrDeleteWhiteSpace.        CJW
 * 06/10/04  Update NLS_PRODVER_DFLT and PRODNAM for TC5.0             RUSTJ
 * 05/20/05  Update NLS_PRODVER_DFLT and PRODNAM for 2005              GWEI
 * 06/01/05  Added nlsGetLocaleISOEqiv function to retrive
 *           ISO Eqivilaent Locale                                     YADAVR
 * 03/02/05  Add prototypes for APIs for TcLink 22 project             XLU
 * 06/29/07  Update NLS_PRODVER_DFLT for 2007.1                        X_PANSE
 * 06/12/11  Update NLS_PRODVER_DFLT for 9                             WAGHMARS
 ******************************************************************************/

#ifndef _NLS_
#define _NLS_

#ifdef __cplusplus  
extern "C" {
#endif

#ifdef _LCINTERP_
#include <nlsh.imh>
extern "c" {
#else

/*******************************************************************************
 *   INCLUDE FILES
 ******************************************************************************/

#include "dlow.h"

#endif   /* _LCINTERP_ */

/*******************************************************************************
 *   MACRO DEFINITIONS
 ******************************************************************************/

/* CONSTANTS */
#define NLS_DATE_FORMAT_ID          "20nlstxt007"
#define NLS_TIME_FORMAT_ID          "20nlstxt008"
#define NLS_CONCAT_STR_ID           "20nlstxt010"
#define NLS_ALT_CONCAT_STR_ID       "21nlstxt011"
#define NLS_OPEN_PAREN_ID           "22nlsstr001"
#define NLS_CLOSE_PAREN_ID          "22nlsstr002"

#define NLS_ALT_CONCAT_STR_DFLT     "-"
#define NLS_BACKSLASH_CHARACTER     '\\'
#define NLS_BLANK_CHARACTER         ' '
#define NLS_AMPERSAND_CHARACTER     '&'
#define NLS_CLOSE_PAREN_DFLT        ")"
#define NLS_CONCAT_STR_DFLT         ","
#define NLS_CONCAT_UNIQUE_STR       "\034"
#define NLS_DATE_FORMAT_DFLT        "%.2d-%.2d-%.2d"
#define NLS_DIR_DFLT                "nls"
#define NLS_HELP_ID_SUFFIX          "HELP"
#define NLS_INDEX_EXT               "idx"
#define NLS_INDEX_HEADER            "textIndexFile"
#define NLS_LOCALE_ENV              "NLS_LOCALE"
#define NLS_LOCALE_DFLT             "en_us"
#define NLS_NEWLINE_CHARACTER       '\n'
#define NLS_NEWLINE_STRING          "\n"
#define NLS_OPEN_PAREN_DFLT         " ("
#define NLS_PATH_ENV                "NLS_PATH"
#ifdef NT_OS
#define NLS_PATH_DELIMITER          "\\"
#else
#define NLS_PATH_DELIMITER          "/"
#endif /* _UNIX_ */
#define NLS_PRODNAM_DFLT            "Teamcenter Enterprise"
#define NLS_PRODVER_DFLT            "9.0"
#define NLS_PRODNAM_PRM             "PRODNAM"
#define NLS_PRODVER_PRM             "PRODVER"
#define NLS_STRING_TERMINATOR       '\0'
#define NLS_SUBSTITUTION_DELIMITER  '#'
#define NLS_SUBST_DELIMITER_STRING  "#"
#define NLS_TEXT_ENV                "NLS_TEXT"
#define NLS_TEXT_EXT                "txt"
#define NLS_TEXT_DFLT               "tmti"
#define NLS_TIME_FORMAT_DFLT        "%.2d:%.2d:%.2d"

/* ERROR CODES */
/* Be careful, because the sequence of these errors is known in nlsGetNlsErrorText()! */
#define NLS_OKAY                    0  /* No nls error occurred.           */
#define NLS_ERR_IDX_FILE_NOT_OPEN   1  /* Index file cannot be opened.     */
#define NLS_ERR_TEXT_ID_NOT_FOUND   2  /* Text index cannot be found.      */
#define NLS_ERR_BAD_TEXT_FILE       3  /* Text file cannot be opened.      */
#define NLS_ERR_TEXT_NOT_FOUND      4  /* Text string cannot be found.     */
#define NLS_ERR_NO_SUBSTITUTION     5  /* Parameter cannot be substituted. */
#define NLS_STRING_ERROR           -1  /* Error in string routine.         */
#define NLS_FILE_ACCESS_ERROR      -1  /* Nls file could not be accessed.  */
#define NLS_STR_NO_ERR              6  /* No nls string error occurred.    */
#define NLS_STR_IS_NULL_CHAR        7  /* Character in string is NULL.     */
#define NLS_STR_IS_INV_CHAR         8  /* Character in string is invalid.  */
#define NLS_STR_IS_OUT_OF_MEM       9  /* A call to getspace has failed.   */

/* VALUES */
#define NLS_INITIAL_ITEMID_SET_SIZE     5  /* Used in nlsConvertStringToSet */
#define NLS_INITIAL_TEXTID_SET_SIZE  5000  /* Used in nlsOpenText           */

#define nlsIsStrNull(str) \
   ((str == NULL) || (*str == NLS_STRING_TERMINATOR))

#define b5_abs1(in0,in1) \
   (((in0) - 0xa1) * 157 + (in1) - ((in1) >= 0xa1 ? (0xa1 - 63) : 0x40))
#define b5_abs(in)       ((int)b5_abs1(in >> 8, in & 0xff))
#define get_b5_c0(in)    (((in) / 157) + 0xa1)
#define get_b5_c1(in)    ((in) % 157 + ((in) % 157 < 63 ? 0x40 : 0xa1 - 63))

#define cns_abs1(in0,in1,in2) \
   (((in0) - 0x21) * (94 * 94) + ((in1) - 0x21) * 94 + (in2) - 0x21)
#define cns_abs(in)      ((int)cns_abs1(in >> 16, (in >> 8) & 0xff, in & 0xff))
#define get_cns_c0(in)   ((in) / (94 * 94) + 0x21)
#define get_cns_c1(in)   ((in) % (94 * 94) / 94 + 0x21)
#define get_cns_c2(in)   ((in) % 94 + 0x21)

/*******************************************************************************
 *   Multibyte Conversion headers
 ******************************************************************************/

#ifndef _LCINTERP_
#define MTIMB
#endif  /* _LCINTERP_ */

#define NLS_MAX_INDEX_SIZE   5           /* Used in I2E and E2I macro     */

#ifdef MTIMB

#if (defined(SOLARIS_OS) || defined(HPUX_OS) ||\
    defined(AIX) || defined(NT_OS) || defined(LINUX))


#define I2E1(a)   nlsI2E((a),1)
#define I2E2(a)   nlsI2E((a),2)
#define I2E3(a)   nlsI2E((a),3)
#define I2E4(a)   nlsI2E((a),4)
#define I2E5(a)   nlsI2E((a), NLS_MAX_INDEX_SIZE)

#define E2I1(a)   nlsE2I((a),1)
#define E2I2(a)   nlsE2I((a),2)
#define E2I3(a)   nlsE2I((a),3)
#define E2I4(a)   nlsE2I((a),4)
#define E2I5(a)   nlsE2I((a), NLS_MAX_INDEX_SIZE)

#define nlsMBConvInitAll(a,b,c)  nlsE2IArgv((a),(b),(c))
#define nlsMBConvInitAll2(a,b,c,d) nlsE2IArgv2((a),(b),(c),(d))
#define nlsMBConvFreeAll()       nlsConvFree()
#define nlsIsMultibyte()         nlsMBIsMultibyte()
#define nlsIsUTF8()              nlsMBIsNTUTF8()
#define nlsIsJapanese()          nlsMBIsJapanese()
#define nlsIsKorean()            nlsMBIsKorean()
#define nlsIsSimplified()        nlsMBIsSimplified()
#define nlsIsTraditional()       nlsMBIsTraditional()
#define nlsMaxBytesInMBChar()    nlsMBMaxBytesInChar()
#define nlsMBStrCpy(a,b) \
   if ((nlsIsMultibyte()) && (((a) != NULL) && ((b) != NULL))) strcpy((a),(b))
#define nlsMBE2IExpFactor()      nlsE2IExpFactor()
#define nlsMBI2EExpFactor()      nlsI2EExpFactor()
#define nlsMBCheckConv()         nlsCheckConv()

#else                     /* a non supported platform, just return string */
                          /* except we do want to do nlsMBInit() for all  */
#undef  MTIMB

#define I2E1(a)   (a)
#define I2E2(a)   (a)
#define I2E3(a)   (a)
#define I2E4(a)   (a)
#define I2E5(a)   (a)

#define E2I1(a)   (a)
#define E2I2(a)   (a)
#define E2I3(a)   (a)
#define E2I4(a)   (a)
#define E2I5(a)   (a)

#define nlsMBConvInitAll(a,b,c)  nlsE2IArgv((a),(b),(c))
#define nlsMBConvInitAll2(a,b,c,d) nlsE2IArgv2((a),(b),(c), (d))
#define nlsMBConvFreeAll()
#define nlsIsMultibyte()        FALSE
#define nlsIsUTF8()             FALSE
#define nlsIsJapanese()         FALSE
#define nlsIsKorean()           FALSE
#define nlsIsSimplified()       FALSE
#define nlsIsTraditional()      FALSE
#define nlsMaxBytesInMBChar()   1
#define nlsMBStrCpy(a,b)
#define nlsMBE2IExpFactor()     1
#define nlsMBI2EExpFactor()     1
#define nlsMBCheckConv()        FALSE

#endif                    /* MTIMB defined                         */

#else                     /* MTIMB not defined, just return string */

#define I2E1(a)   (a)
#define I2E2(a)   (a)
#define I2E3(a)   (a)
#define I2E4(a)   (a)
#define I2E5(a)   (a)

#define E2I1(a)   (a)
#define E2I2(a)   (a)
#define E2I3(a)   (a)
#define E2I4(a)   (a)
#define E2I5(a)   (a)

#define nlsMBConvInitAll(a,b,c) OKAY
#define nlsMBConvInitAll2(a,b,c,d) OKAY
#define nlsMBConvFreeAll()
#define nlsIsMultibyte()        FALSE
#define nlsIsUTF8()             FALSE
#define nlsIsJapanese()         FALSE
#define nlsIsKorean()           FALSE
#define nlsIsSimplified()       FALSE
#define nlsIsTraditional()      FALSE
#define nlsMaxBytesInMBChar()   1
#define nlsMBStrCpy(a,b)
#define nlsMBE2IExpFactor()     1
#define nlsMBI2EExpFactor()     1
#define nlsMBCheckConv()        FALSE

#endif

/* Returns true for any 7-bit ASCII character in internal character sets. */
/* Input is an initial byte or full multi-byte char. */
/* Not valid for external character sets. */
#define nlsIsAscii(ch)          (!(((int)(ch)) & ~0x7F))

#define FILTER1                 0x00
#define FILTER2                 0xC0
#define FILTER3                 0xE0


/*******************************************************************************
 *   TYPE DEFINITIONS
 ******************************************************************************/

#ifndef _LCINTERP_

typedef struct nlsTextType
{
   char *identifier;
   long start;                  /* Passed into fseek(,, SEEK_SET) */
   int  length;
} nlsText_t, *nlsTextPtr;

#endif   /* _LCINTERP_ */

/*******************************************************************************
 *   EXTERNAL GLOBAL VARIABLE DEFINITIONS/DECLARATIONS
 ******************************************************************************/

/*******************************************************************************
 *   EXTERNAL FUNCTION DECLARATIONS
 ******************************************************************************/

#ifndef _LCINTERP_

/* nlsconv.c */

MTI_FDECL(E, boolean, nlsCheckHebrewLocaleOverride,(void));

MTI_FDECL(E, MTIstatus,  nlsConvFree, (void));

MTI_FDECL(EP, MTIstatus,  nlsModLangIs, (char *locale));

MTI_FDECL(EP, MTIstatus,  nlsModUTF8LangIs, (char *locale));

MTI_FDECL(EP, MTIstatus, nlsConvFreeAll, (void));

MTI_FDECL(EP, char *, nlsE2I, (const char *exMbStr, size_t idx));

MTI_FDECL(EP, MTIstatus, nlsE2IArgv,
          (int ArgcE2I,char ***ArgvE2I,char ***EnvE2I));

MTI_FDECL(EP, MTIstatus, nlsE2IArgv2,
          (int ArgcE2I, char ***ArgvE2I, char ***EnvE2I, char *locName));

MTI_FDECL(E, MTIstatus,  nlsE2IArgvFree, (void));

MTI_FDECL(EP, MTIstatus, nlsE2IEnv, (char ***EnvE2I));

MTI_FDECL(E, MTIstatus,  nlsE2IEnvFree, (void));

MTI_FDECL(EP, char *, nlsI2E, (const char *inMbStr, size_t idx));

MTI_FDECL(EP, MTIstatus, nlsI2EArgv, (int ArgcI2E, const char ***ArgvI2E));

MTI_FDECL(E, MTIstatus,  nlsI2EArgvFree, (void));

MTI_FDECL(EP, MTIstatus, nlsI2EEnv, (char ***EnvI2E));

MTI_FDECL(E, MTIstatus,  nlsI2EEnvFree, (void));

MTI_FDECL(EP, int, nlsStdMbLen, (const char *mbStr, const size_t numBytes));

MTI_FDECL(E, int, nlsE2IExpFactor, (void));

MTI_FDECL(E, int, nlsI2EExpFactor, (void));

MTI_FDECL(EP, boolean, nlsMBIsMultibyte, (void));

MTI_FDECL(EP, boolean, nlsMBIsNTUTF8, (void));

MTI_FDECL(E, boolean, nlsMBIsJapanese, (void));

MTI_FDECL(E, boolean, nlsMBIsKorean, (void));

MTI_FDECL(E, boolean, nlsMBIsSimplified, (void));

MTI_FDECL(E, boolean, nlsMBIsTraditional, (void));

MTI_FDECL(E, int, nlsMBMaxBytesInChar, (void));

MTI_FDECL(E, boolean, nlsCheckConv, (void));

MTI_FDECL(E, boolean, nlsIsFrench, (void));

MTI_FDECL(E, boolean, nlsIsGerman, (void));

MTI_FDECL(E, boolean, nlsIsDutch, (void));

MTI_FDECL(E, boolean, nlsIsItalian, (void));

MTI_FDECL(E, boolean, nlsIsPortuguese, (void));

MTI_FDECL(E, boolean, nlsIsSpanish, (void));

MTI_FDECL(E, boolean, nlsIsRussian, (void));

MTI_FDECL(E, boolean, nlsIsHebrew, (void));

MTI_FDECL(E, boolean, nlsIsJapaneseEUC, (void));

MTI_FDECL(E, boolean, nlsIs8859_1, (void));

MTI_FDECL(E, MTIstatus, nlsLangEncodingInfo,
             (char *LangName, char *EncodingName));

MTI_FDECL(E, MTIstatus, nlsLangEncodingInfoFMS,
             (char *LangName, char *EncodingName));

MTI_FDECL(E, MTIstatus, nlsConvertByEncoding,
             (char *inBuf, char *outBuf, char *encoding, int *inBytes,
              int *outBytes, boolean intToExt, sysPathFormat_t crlfFormat,
              boolean lastBlock));

MTI_FDECL(E, MTIstatus, nlsAddReplaceXMLUTF8Decl,
            (MTIconstString inString, MTIconstString *outString));

MTI_FDECL(E, MTIstatus, nlsConvertStringToUTF8,
            (const char *inString, int *outUTF8Len, char **outUTF8Chars));

MTI_FDECL(E, MTIstatus, nlsConvertStringToUTF8NoLF,
            (const char *inString, int *outUTF8Len, char **outUTF8Chars));

MTI_FDECL(E, MTIstatus, nlsConvertStrSetToUTF8,
   ( SetOfStrings inStringSet, int *outUTF8Len, char **outUTF8Chars));

MTI_FDECL(EP, MTIstatus, nlsConvtFloatByFormatInCLocale,
             (double inValue, char *fmt, char *outStr));

MTI_FDECL(EP, MTIstatus, nlsTcEntToPLMXMLUTF16,
             (const char *in, unsigned short *out,
              int  *errcode));

MTI_FDECL(EP, MTIstatus, nlsTcEntToPLMXMLUTF8,
             (const char *in, char *out,
              int  *errcode));

MTI_FDECL(EP, MTIstatus, nlsPLMXMLUTF8ToTcEnt,
             (const char *in, char *out,
              int  *errcode));

MTI_FDECL(EP, MTIstatus, nlsNativeLangToHexUTF8,
             (const unsigned char *in, unsigned char **out,
              int  *errcode));

MTI_FDECL(EP, MTIstatus, nlsNativeLangToUTF8,
             (const char *in, char *out,
              int  *errcode));

MTI_FDECL(EP, MTIstatus, nlsUTF8ToNativeLang,
             (const char *in, char *out,
              int  *errcode));

MTI_FDECL(EP, MTIstatus, nlsSjisToHexUTF8,
             (const unsigned char *in, unsigned char **out,
              int  *errcode));

MTI_FDECL(EP, MTIstatus, nlsUhcToHexUTF8,
             (const unsigned char *in, unsigned char **out,
              int  *errcode));

MTI_FDECL(EP, MTIstatus, nlsGbToHexUTF8,
             (const unsigned char *in, unsigned char **out,
              int  *errcode));

MTI_FDECL(EP, MTIstatus, nlsBig5ToHexUTF8,
             (const unsigned char *in, unsigned char **out,
              int  *errcode));

MTI_FDECL(EP, MTIstatus, nlsiso88591ToHexUTF8,
             (const unsigned char *in, unsigned char **out,
              int  *errcode));

/* nlswstr.c */

MTI_FDECL(E, wchar_t *, nlsMbsToWcs,
                    (wchar_t *str1, const char *str2, const size_t numCodes));

MTI_FDECL(E, char *, nlsWcsToMbs,
                    (char *str1, const wchar_t *str2, const size_t numBytes));

MTI_FDECL(E, int,  nlsWcsLen, (const wchar_t *wstr));

MTI_FDECL(E, int,  nlsWcsCmp, (const wchar_t *str1, const wchar_t *str2));

MTI_FDECL(E, int, nlsWcsNCmp,
              (const wchar_t *str1, const wchar_t *str2, const size_t count));

MTI_FDECL(E, int, nlsMbToWc,
               (wchar_t *wideChar, const char *mbStr, const size_t numBytes));

MTI_FDECL(E, int,  nlsMbLen, (const char *mbStr, const size_t numBytes));

MTI_FDECL(i, MTIstatus, nlsEuc2Sjis,
                  (const unsigned char *in, unsigned char *out, int *errcode));

/* nlsconv.c test functions */
#ifdef NLSMBTEST
MTI_FDECL(i, void,  nlsMBConvCheck, (void));        /* A Test Function */
#endif

#endif   /* _LCINTERP_ */

/* nlsstr.c */

#ifndef _LCINTERP_
MTI_FDECL(EP, char *, nlsStrAlloc, (const int len));
#endif   /* _LCINTERP_ */

int nlsStrCaseCmp(const char *str1,const char *str2);

#ifndef _LCINTERP_
MTI_FDECL(EP, char *, nlsStrCat, (char *str1,const char *str2));
#else
#define nlsStrCat(s1, s2) (s1 = s1 + s2)
#endif   /* _LCINTERP_ */

char *nlsStrCatLabelTag(char *catStr, const char *label, const char *tag);

#ifndef _LCINTERP_
MTI_FDECLC(I, MTIstatus, nlsStrChangeNewlinesToBlanks, (const char  *str,
                                                        const char **newStr));
#endif   /* _LCINTERP_ */
   
MTI_FDECL(EP, int, nlsStrCmp, (const char *str1,const char *str2));

char *nlsStrColInsert2
   (      char *str1,
    const char *str2,
    const int   col1,
    const int   col2);

#ifndef _LCINTERP_
MTI_FDECL(EP, char *, nlsStrCpy, (char *str1,const char *str2));
#else
#define nlsStrCpy(s1, s2) (s1 = s2)
#endif   /* _LCINTERP_ */

MTI_FDECL(EP, char *, nlsStrDeleteChar,
          (char *str,const char *c));

MTI_FDECL(EP, MTIstatus, nlsStrDeleteWhiteSpace, (char *str));

#ifndef _LCINTERP_
MTI_FDECL(EP, char *, nlsStrDup, (const char *str));

MTI_FDECL(EP, MTIstatus, nlsStrFree, (char *str));
#endif   /* _LCINTERP_ */

#ifndef _LCINTERP_
MTI_FDECL(E, char *, nlsStrGetLine, (char *inStr, int lineNum));
#endif   /* _LCINTERP_ */

MTI_FDECL(EP, MTIstatus, nlsStrGetMarkedChar,
          (const char *str,const char *mark,char *marked));

MTI_FDECL(EP, int, nlsStrLen, (const char *str));

MTI_FDECL(EP, int, nlsStrMaxLineLen, (const char *str));

MTI_FDECL(EP, char *, nlsStrNBlank, ( char *str,const int   n));

MTI_FDECL(EP, int, nlsStrNCaseCmp,
          (const char *str1,const char *str2,const int   n));

MTI_FDECL(EP, int, nlsStrNCmp,
          (const char *str1,const char *str2,const int   n));

#ifndef _LCINTERP_
MTI_FDECL(EP, char *, nlsStrNCpy,
          (char *str1,const char *str2,const int   n));
#else
#define nlsStrNCpy(s1, s2, len) (s1 = substr(s2, 0, len))
#endif   /* _LCINTERP_ */

MTI_FDECL(EP, char *, nlsStrNInsert,
          (char *str1,const char *str2,const int   n));

MTI_FDECL(EP, int, nlsStrNumLines, (const char *str));

#ifndef _LCINTERP_
MTIstatus nlsStrDupBackSlashes
   (      char *str);
MTIstatus nlsStrPadBackSlashes
   (      char *str);
MTIstatus nlsStrPadAmpersands
   (      char *str);
#endif   /* _LCINTERP_ */

MTIstatus nlsStrSplitLabelTag(const char *catStr, char **label, char **tag);

MTI_FDECL(EP, char *, nlsStrStr, (const char *str1,const char *str2));

MTI_FDECL(EP, MTIstatus, nlsStrTrimLeadWhiteSpace, (char *str));

MTI_FDECL(EP, MTIstatus, nlsStrTrimTrailWhiteSpace, (char *str));

MTI_FDECL(E,  MTIstatus, nlsStrTrimTrailChars, (char *str,const int   n));

MTI_FDECL(EP, MTIstatus, nlsStrTruncate, (char *str,const int   n));

#ifndef _LCINTERP_
MTI_FDECL(EP, char *, nlsStrReplaceNonPrint,
          (char *str,const char c));
MTI_FDECL(EP, boolean, nlsIsPrint,
          (const char *str,int *numBytesInChar,int *errcode));
MTI_FDECL(E, MTIstatus, nlsStrToLower,
          (char *str,int *errcode));
MTI_FDECL(E, MTIstatus, nlsStrToUpper,
          (char *str,int *errcode));

MTIstatus nlsStrLCpy(char *dst, const char *src, size_t sz);

MTIstatus nlsStrLCat(char *dst, const char *src, size_t sz);

#endif   /* _LCINTERP_ */

MTI_FDECL(E,  MTIstatus, nlsStrReplaceNewLines, \
         (const char *inStr, const char *repStr, char **outStr));
MTI_FDECL(E,  MTIstatus, nlsStrReplaceNewLinesInSet, \
         (SetOfStrings inStringSet, const char *repStr, char **outStr));

/* nlstxt.c */

MTI_FDECL(I, MTIstatus, nlsCloseFiles, (void));

MTI_FDECL(EP, MTIstatus, nlsConvertSetToString,
          (const SetPtr set, char **strng));

MTI_FDECL(EP, MTIstatus, nlsConvertStringToSet,
          (const char *strng, SetPtr *set));

MTI_FDECL(I, MTIstatus, nlsConvertSetToString2,
          (const SetPtr set, char **strng));

MTI_FDECL(I, MTIstatus, nlsConvertStringToSet2,
          (const char *strng, SetPtr *set));

#define nlsConvertSetToString3(s,a_s) nlsConvertSetToString (s,(char**) a_s) 

#define nlsConvertSetToString4(s,a_s) nlsConvertSetToString2(s,(char**) a_s) 

#ifndef _LCINTERP_

MTI_FDECL(I, MTIstatus, nlsFindFileInSpecificLocale,
          (const char *file, const char *locale, char **path, int *error));

MTI_FDECL(I, MTIstatus, nlsFindFileInCurrentLocale,
          (const char *file, char **path, int *error));

#endif

MTI_FDECL(EP, MTIstatus, nlsGetAutoParameter,
          (char  *parName,char **setValue));

MTI_FDECL(EP, MTIstatus, nlsGetLocale, (char  **locale));

MTI_FDECL(EP, MTIstatus, nlsGetLocaleISOEqiv, (char  **localeISOEqiv));

MTI_FDECL(E, int, nlsMaxBytesPerChar, (void));

MTI_FDECL(EP, MTIstatus, nlsGetText,
          (const char  *textId,NVSET  textInserts,char **textString,int   *error));

#ifndef _LCINTERP_
MTI_FDECL(I, MTIstatus, nlsGetNlsDir,
   (
      const char  *locale,
      const char **dir
   ));
#endif

MTI_FDECL(EP, MTIstatus, nlsGetTextHelp,
          (const char  *textId,NVSET  textInserts,char **textString,int   *error));

MTI_FDECL(EP, MTIstatus, nlsGetTextLabel,
          (const char  *textId,NVSET  textInserts,char **textString,int   *error));

#define nlsGetTextLabel2(id,ins,s,e) nlsGetTextLabel(id,ins,(char **) s,e) 

MTI_FDECL(EP, MTIstatus, nlsGetTimeStamp,
          (char  **timeStamp));

MTI_FDECL(EP, boolean, nlsIsInQuietMode, (void));

MTI_FDECL(EP, MTIstatus, nlsOpenCurrentLocaleIndexFile, (int *error));

MTIstatus nlsSetConcatStr
   (MTIconstString  concatStr);

#ifndef _LCINTERP_

MTI_FDECL(I, const char *, nlsBaseFileName, (const char *));

MTI_FDECL(I, const char *, nlsIndexFileName, (const char *));

MTI_FDECL(I, const char *, nlsTextFileName, (const char *));

#endif

MTI_FDECL(EP, MTIstatus, nlsSetLocale, (const char  *locale));

#ifndef _LCINTERP_
MTIstatus nlsSetCallbacks
(MTIstatus (*getTextBaseCallback)(const char*, char**, boolean*),
 MTIstatus (*openFilesCallback)(char*, boolean*),
 MTIstatus (*closeFilesCallback)(void));
#endif

MTI_FDECL(EP, MTIstatus, nlsSetQuietMode, (boolean mode));

MTIstatus nlsSubstituteParms
   (NVSET  substitutions,
          char **textString,
          int   *error);

MTI_FDECL(EP, MTIstatus, nlsSubstituteText,
          (NVSET  substitutions,char  *textString,int   *error));

MTIstatus nlsGetConcatStr(char  **concatStr);

/* ddb/nlsserv/nlsclnt.c (NLS Server) */

#ifndef _LCINTERP_
MTIstatus nlsClntSetCallbacks
   (void);
#endif

/* nlsgenid.c */

MTI_FDECL(I, MTIstatus, nlsGenidx, (char *infile, char *outfile));

#ifdef _LCINTERP_
}
#endif

#ifdef __cplusplus  
}
#endif

#endif /* _NLS_ */
