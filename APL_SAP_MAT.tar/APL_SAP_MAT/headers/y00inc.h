#ifndef _Y00INC_H_
#define _Y00INC_H_
/*******************************************************************************
**   INCLUDE FILES
*******************************************************************************
**
** master include for r0x
** General required includes..
*/
#include <msgomf.h>		/* omf messages				*/
#include <msgy00.h>		/* y00 messages				*/
#include <usc.h>		/* USC constants + uly* functions	*/
#include <nls.h>		/* NLS constants,nls* functions + dlow.h*/
#include <ui.h>			/* UI and ui constants +functions	*/
#include <relation.h>		/* includes also pdmroot.h  and sc.h	*/
#include <cnd.h>		/* required for cnd* functions 		*/
#include <ft.h>			/* all file-access constants		*/
#include <Mtimsgh.h>		/* all Model constants			*/
#include <stdio.h>		/* for standard c I/O functions		*/

#include <y00FnGeneral.h>	/* General functions			*/


/*******************************************************************************
**   MACRO DEFINITIONS
*******************************************************************************/

//#define Y00IFD(A)	if(dstat=A) goto EXIT;else NULL;
#define Y00IFD(A) \
		if(dstat = A) { \
			printf("\n"); \
			goto EXIT; }

/*
** constants ...
*/
#define Y00_BR_LARGE_ICON_EXT	".lbm"		/* must correspond with br.h */
#define Y00_BR_SMALL_ICON_EXT	".sbm"		/* must correspond with br.h */

#define Y00_METHOD_DEF_EXP_CA	"y00MDECA"	/* Stored method object name */
#define Y00_METHOD_DEF_EXP_MM	"y00MDEMM"	/* Stored method object name */

#define Y00_TRUE_VALUE		"TRUE"		/* The TRUE condition        */
#define Y00_FALSE_VALUE		"FALSE"		/* The FALSE condition       */

#define Y00_WILD_CHAR		'*'		/* Wild card for query	     */
#define Y00_ALT_WILD_CHAR	'?'		/* Alt. wild card for query  */

#define Y00_ROLE_WILD_CARD	"*"		/* Wild card for rules	     */
#define Y00_CLASS_WILD_CARD	"*"		/* Wild card for rules	     */
#define Y00_MSG_WILD_CARD	"*"		/* Wild card for rules	     */

#define Y00_CONDITION_SEPARATOR	"="		/* Separates name of express.*/
#endif
