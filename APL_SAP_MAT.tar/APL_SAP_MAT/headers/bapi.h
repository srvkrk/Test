#ifndef bapi_H
#define bapi_H

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "saprfc.h"
#include "sapitab.h"
void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);
//void nbyte2str(char *str,unsigned char *byte,size_t size);
//void str2nbyte(char *str,unsigned char *byte,size_t size);
void str2nbcd(char *str,unsigned char *bcd,size_t size, int decimals);
//void OUTS(const char *text,const unsigned pos,const unsigned len,char*str);
#define __min(a,b) (((a)<(b))?(a):(b))
#define OUT(text,pos) printf("%*.0s",pos,text); printf("%s\n",text); \
if(stdout!=NULL) fprintf(stdout,"=%s\n",text)
#define NL printf("\n")

//void OUTS(const char *text,const unsigned pos,const unsigned len,char*str)
//{
//  printf("%*.0s",pos,text); printf("%-*s : %s\n",len,text,str);
//  //if (stdout!=NULL) fprintf(stdout,"=%s\n>%s\n",text,str);
//  return;
//}


#ifndef SAP_FT_RC29L_STLAL
#define SAP_FT_RC29L_STLAL
typedef RFC_CHAR RC29L_STLAL[2];
#endif

#ifndef SAP_FT_RC29L_STLAN
#define SAP_FT_RC29L_STLAN
typedef RFC_CHAR RC29L_STLAN[1];
#endif

#ifndef SAP_FT_RC29L_AENNR
#define SAP_FT_RC29L_AENNR
typedef RFC_CHAR RC29L_AENNR[12];
#endif

#ifndef SAP_FT_RC29L_MATNR
#define SAP_FT_RC29L_MATNR
typedef RFC_CHAR RC29L_MATNR[18];
#endif

#ifndef SAP_FT_RC29L_WERKS
#define SAP_FT_RC29L_WERKS
typedef RFC_CHAR RC29L_WERKS[4];
#endif

#ifndef SAP_FT_RC29L_REVLV
#define SAP_FT_RC29L_REVLV
typedef RFC_CHAR RC29L_REVLV[2];
#endif

#ifndef SAP_FT_BICSK_DATUV
#define SAP_FT_BICSK_DATUV
typedef RFC_CHAR BICSK_DATUV[10];
#endif


#ifndef SAP_FT_SYST_SUBRC
#define SAP_FT_SYST_SUBRC
typedef RFC_INT SYST_SUBRC;
#endif

#ifndef SAP_FT_CSDATA_XFELD
#define SAP_FT_CSDATA_XFELD
typedef RFC_CHAR CSDATA_XFELD[1];
#endif

#ifndef SAP_FT_AENRB_AENNR
#define SAP_FT_AENRB_AENNR
typedef RFC_CHAR AENRB_AENNR[12];
#endif

/* structure type definition */

#ifndef SAP_ST_BWTAR_D
#define SAP_ST_BWTAR_D
typedef struct {
  RFC_CHAR BwtarD[10];
 } BWTAR_D;
#endif

#ifndef SAP_ST_BKLAS
#define SAP_ST_BKLAS
typedef struct {
  RFC_CHAR Bklas[4];
 } BKLAS;
#endif

#ifndef SAP_ST_MATNR
#define SAP_ST_MATNR
typedef struct {
  RFC_CHAR Matnr[18];
 } MATNR;
#endif

#ifndef SAP_ST_QPART
#define SAP_ST_QPART
typedef struct {
  RFC_CHAR Qpart[8];
 } QPART;
#endif

#ifndef SAP_ST_WERKS_D
#define SAP_ST_WERKS_D
typedef struct {
  RFC_CHAR WerksD[4];
 } WERKS_D;
#endif

#ifndef SAP_ST_MESSAGEINF
#define SAP_ST_MESSAGEINF
typedef struct {
  RFC_CHAR Msgty[1];
  RFC_CHAR Msgid[20];
  RFC_CHAR Msgno[3];
  RFC_CHAR Msspc[1];
  RFC_CHAR Msgtx[255];
 } MESSAGEINF;
#endif

#ifndef SAP_ST_AENR_API01
#define SAP_ST_AENR_API01
typedef struct {
RFC_CHAR ChangeNo[12];
RFC_NUM Status[2];
RFC_CHAR AuthGroup[4];
RFC_CHAR ValidFrom[10];
RFC_CHAR Descript[40];
RFC_CHAR ReasonChg[40];
RFC_CHAR DeletionMark[1];
RFC_CHAR IndateRule[10];
RFC_CHAR OutdateRule[10];
RFC_CHAR Function[1];
RFC_CHAR ChangeLeader[12];
RFC_CHAR EffectivityType[10];
RFC_CHAR OverridingMark[1];
RFC_NUM Rank[2];
RFC_NUM ReleaseKey[2];
RFC_CHAR StatusProfile[8];
RFC_CHAR TechRel[1];
RFC_CHAR BasicChange[1];
} AENR_API01;
#endif

#ifndef SAP_ST_AENV_API01
#define SAP_ST_AENV_API01
typedef struct {
RFC_CHAR Active[1];
RFC_CHAR Locked[1];
RFC_CHAR ObjRequ[1];
RFC_CHAR MgtrecGen[1];
RFC_CHAR GenNew[1];
RFC_CHAR GenDialog[1];
} AENV_API01;
#endif

#ifndef SAP_ST_AEEF_API01
#define SAP_ST_AEEF_API01
typedef struct {
RFC_CHAR ValidFrom[10];
RFC_CHAR ValidTo[10];
RFC_CHAR DateMark[1];
RFC_CHAR Material[18];
RFC_CHAR SerialnrLow[18];
RFC_CHAR SerialnrHigh[18];
RFC_CHAR Class[18];
RFC_CHAR Classty[3];
RFC_CHAR Startup[30];
RFC_CHAR Plant[4];
RFC_CHAR SernrOi[1];
RFC_CHAR FlDelete[1];
} AEEF_API01;
#endif

#ifndef SAP_ST_AEDT_API01
#define SAP_ST_AEDT_API01
typedef struct {
RFC_CHAR AltDate[18];
RFC_CHAR ValidFrom[10];
RFC_CHAR FlDelete[1];
} AEDT_API01;
#endif

#ifndef SAP_ST_AEOI_API01
#define SAP_ST_AEOI_API01
typedef struct {
RFC_CHAR AltDate[18];
RFC_NUM ChgObjtyp[1];
RFC_CHAR BomCat[1];
RFC_CHAR BomStdObject[18];
RFC_CHAR BomUsage[1];
RFC_NUM Chgtypeobj[3];
RFC_CHAR DescrObj[40];
RFC_CHAR DocType[3];
RFC_CHAR DocNumber[25];
RFC_CHAR DocVers[2];
RFC_CHAR DocPart[3];
RFC_CHAR Equipment[18];
RFC_CHAR FuncLoc[30];
RFC_CHAR Material[18];
RFC_CHAR Plant[4];
RFC_CHAR PspElement[24];
RFC_BYTE PvsGuid[16];
RFC_CHAR PvsType[1];
RFC_CHAR PvsNode[40];
RFC_CHAR PvsClassNumber[18];
RFC_CHAR PvsClassType[3];
RFC_CHAR PvsVariant[8];
RFC_CHAR SdOrder[10];
RFC_NUM SdOrderI[6];
RFC_NUM Textkey[8];
RFC_CHAR TlistType[1];
RFC_CHAR TlistGrp[8];
RFC_CHAR ObjChglock[1];
RFC_CHAR StatusProfObj[8];
RFC_CHAR FlDelete[1];
 } AEOI_API01;
 #endif

#ifndef SAP_ST_CCTHEAD
#define SAP_ST_CCTHEAD
typedef struct {
RFC_NUM Textkey[8];
RFC_CHAR Tdname[70];
RFC_CHAR Tdid[4];
RFC_CHAR Tdspras[1];
} CCTHEAD;
#endif

#ifndef SAP_ST_CCTLINE
#define SAP_ST_CCTLINE
typedef struct {
  RFC_NUM Textkey[8];
  RFC_CHAR Tdformat[2];
  RFC_CHAR Tdline[132];
 } CCTLINE;
#endif


/*
#ifndef SAP_TH_BWTAR_D
#define SAP_TH_BWTAR_D
static const RFC_TYPEHANDLE handleOfBWTAR_D;
static const RFC_TYPE_ELEMENT typeOfBWTAR_D[] = {
  {"BWTAR_D", TYPC, 10, 0},
 };
#endif


#ifndef SAP_TH_BKLAS
#define SAP_TH_BKLAS
static const RFC_TYPEHANDLE handleOfBKLAS;

static const RFC_TYPE_ELEMENT typeOfBKLAS[] = {
  {"BKLAS", TYPC, 4, 0},
 };
#endif



#ifndef SAP_TH_MATNR
#define SAP_TH_MATNR
static const RFC_TYPEHANDLE handleOfMATNR;

static const RFC_TYPE_ELEMENT typeOfMATNR[] = {
  {"MATNR", TYPC, 18, 0},
 };
#endif

#ifndef SAP_TH_QPART
#define SAP_TH_QPART
static const RFC_TYPEHANDLE handleOfQPART;

static const RFC_TYPE_ELEMENT typeOfQPART[] = {
  {"QPART", TYPC, 8, 0},
 };
#endif

#ifndef SAP_TH_WERKS_D
#define SAP_TH_WERKS_D
static const RFC_TYPEHANDLE handleOfWERKS_D;

static const RFC_TYPE_ELEMENT typeOfWERKS_D[] = {
  {"WERKS_D", TYPC, 4, 0},
 };
#endif

#ifndef SAP_TH_MESSAGEINF
#define SAP_TH_MESSAGEINF
static const RFC_TYPEHANDLE handleOfMESSAGEINF;

static const RFC_TYPE_ELEMENT typeOfMESSAGEINF[] = {
  {"MSGTY", TYPC, 1, 0},
  {"MSGID", TYPC, 20, 0},
  {"MSGNO", TYPC, 3, 0},
  {"MSSPC", TYPC, 1, 0},
  {"MSGTX", TYPC, 255, 0},
 };
#endif*/

#ifndef SAP_TH_AENR_API01
#define SAP_TH_AENR_API01
static const RFC_TYPEHANDLE handleOfAENR_API01;
static const RFC_TYPE_ELEMENT typeOfAENR_API01[] = {
 {"CHANGE_NO", TYPC, 12, 0},
 {"STATUS", TYPNUM, 2, 0},
 {"AUTH_GROUP", TYPC, 4, 0},
 {"VALID_FROM", TYPC, 10, 0},
 {"DESCRIPT", TYPC, 40, 0},
 {"REASON_CHG", TYPC, 40, 0},
 {"DELETION_MARK", TYPC, 1, 0},
 {"INDATE_RULE", TYPC, 10, 0},
 {"OUTDATE_RULE", TYPC, 10, 0},
 {"FUNCTION", TYPC, 1, 0},
 {"CHANGE_LEADER", TYPC, 12, 0},
 {"EFFECTIVITY_TYPE", TYPC, 10, 0},
 {"OVERRIDING_MARK", TYPC, 1, 0},
 {"RANK", TYPNUM, 2, 0},
 {"RELEASE_KEY", TYPNUM, 2, 0},
 {"STATUS_PROFILE", TYPC, 8, 0},
 {"STATUS_PROFILE", TYPC, 8, 0},
 {"TECH_REL", TYPC, 1, 0},
 {"BASIC_CHANGE", TYPC, 1, 0},
 };
 #endif

 #ifndef SAP_TH_AENV_API01
 #define SAP_TH_AENV_API01
 static const RFC_TYPEHANDLE handleOfAENV_API01;

 static const RFC_TYPE_ELEMENT typeOfAENV_API01[] = {
  {"ACTIVE", TYPC, 1, 0},
	{"LOCKED", TYPC, 1, 0},
	{"OBJ_REQU", TYPC, 1, 0},
	{"MGTREC_GEN", TYPC, 1, 0},
	{"GEN_NEW", TYPC, 1, 0},
	{"GEN_DIALOG", TYPC, 1, 0},
 };
 #endif

 #ifndef SAP_TH_AEEF_API01
 #define SAP_TH_AEEF_API01
 static const RFC_TYPEHANDLE handleOfAEEF_API01;

 static const RFC_TYPE_ELEMENT typeOfAEEF_API01[] = {
 {"VALID_FROM", TYPC, 10, 0},
 {"VALID_TO", TYPC, 10, 0},
 {"DATE_MARK", TYPC, 1, 0},
 {"MATERIAL", TYPC, 18, 0},
 {"SERIALNR_LOW", TYPC, 18, 0},
 {"SERIALNR_HIGH", TYPC, 18, 0},
 {"CLASS", TYPC, 18, 0},
 {"CLASSTY", TYPC, 3, 0},
 {"STARTUP", TYPC, 30, 0},
 {"PLANT", TYPC, 4, 0},
 {"SERNR_OI", TYPC, 1, 0},
 {"FL_DELETE", TYPC, 1, 0},
};
#endif

#ifndef SAP_TH_AEDT_API01
#define SAP_TH_AEDT_API01
static const RFC_TYPEHANDLE handleOfAEDT_API01;

static const RFC_TYPE_ELEMENT typeOfAEDT_API01[] = {
{"ALT_DATE", TYPC, 18, 0},
{"VALID_FROM", TYPC, 10, 0},
{"FL_DELETE", TYPC, 1, 0},
};
#endif

#ifndef SAP_TH_AEOI_API01
#define SAP_TH_AEOI_API01
static const RFC_TYPEHANDLE handleOfAEOI_API01;

static const RFC_TYPE_ELEMENT typeOfAEOI_API01[] = {
 {"ALT_DATE", TYPC, 18, 0},
 {"CHG_OBJTYP", TYPNUM, 1, 0},
 {"BOM_CAT", TYPC, 1, 0},
 {"BOM_STD_OBJECT", TYPC, 18, 0},
 {"BOM_USAGE", TYPC, 1, 0},
 {"CHGTYPEOBJ", TYPNUM, 3, 0},
 {"DESCR_OBJ", TYPC, 40, 0},
 {"DOC_TYPE", TYPC, 3, 0},
 {"DOC_NUMBER", TYPC, 25, 0},
 {"DOC_VERS", TYPC, 2, 0},
 {"DOC_PART", TYPC, 3, 0},
 {"EQUIPMENT", TYPC, 18, 0},
 {"FUNC_LOC", TYPC, 30, 0},
 {"MATERIAL", TYPC, 18, 0},
 {"PLANT", TYPC, 4, 0},
 {"PSP_ELEMENT", TYPC, 24, 0},
 {"PVS_GUID", TYPX, 16, 0},
 {"PVS_TYPE", TYPC, 1, 0},
 {"PVS_NODE", TYPC, 40, 0},
 {"PVS_CLASS_NUMBER", TYPC, 18, 0},
 {"PVS_CLASS_TYPE", TYPC, 3, 0},
 {"PVS_VARIANT", TYPC, 8, 0},
 {"SD_ORDER", TYPC, 10, 0},
 {"SD_ORDER_I", TYPNUM, 6, 0},
 {"TEXTKEY", TYPNUM, 8, 0},
 {"TLIST_TYPE", TYPC, 1, 0},
 {"TLIST_GRP", TYPC, 8, 0},
 {"OBJ_CHGLOCK", TYPC, 1, 0},
 {"STATUS_PROF_OBJ", TYPC, 8, 0},
 {"FL_DELETE", TYPC, 1, 0},
};
#endif

#ifndef SAP_TH_CCTHEAD
#define SAP_TH_CCTHEAD
static const RFC_TYPEHANDLE handleOfCCTHEAD;

static const RFC_TYPE_ELEMENT typeOfCCTHEAD[] = {
{"TEXTKEY", TYPNUM, 8, 0},
{"TDNAME", TYPC, 70, 0},
{"TDID", TYPC, 4, 0},
{"TDSPRAS", TYPC, 1, 0},
};
#endif

#ifndef SAP_TH_CCTLINE
#define SAP_TH_CCTLINE
static const RFC_TYPEHANDLE handleOfCCTLINE;

static const RFC_TYPE_ELEMENT typeOfCCTLINE[] = {
{"TEXTKEY", TYPNUM, 8, 0},
{"TDFORMAT", TYPC, 2, 0},
{"TDLINE", TYPC, 132, 0},
};
#endif

#ifndef SAP_FT_MESSAGE_MSGTX
#define SAP_FT_MESSAGE_MSGTX
typedef RFC_CHAR MESSAGE_MSGTX[200];
#endif


#ifndef SAP_FT_DRAW_LOEDK
#define SAP_FT_DRAW_LOEDK
typedef RFC_CHAR DRAW_LOEDK[1];
#endif

#ifndef SAP_FT_CAD_RETURN_MESSAGE_LEN
#define SAP_FT_CAD_RETURN_MESSAGE_LEN
typedef RFC_CHAR CAD_RETURN_MESSAGE_LEN[4];
#endif

#ifndef SAP_FT_CAD_RETURN_VALUE
#define SAP_FT_CAD_RETURN_VALUE
typedef RFC_CHAR CAD_RETURN_VALUE[10];
#endif


/* structure type definition */

#ifndef SAP_ST_CAD_BICSK
#define SAP_ST_CAD_BICSK
typedef struct {
  RFC_CHAR Stype[1];
  RFC_CHAR Tcode[20];
  RFC_CHAR Aennr[12];
  RFC_CHAR Bmein[3];
  RFC_CHAR Bmeng[17];
  RFC_CHAR Cadkz[1];
  RFC_CHAR Datub[10];
  RFC_CHAR Datuv[10];
  RFC_CHAR Emeng[17];
  RFC_CHAR Equnr[18];
  RFC_CHAR Exstl[18];
  RFC_CHAR Labor[3];
  RFC_CHAR Loekz[1];
  RFC_CHAR Losbs[17];
  RFC_CHAR Losvn[17];
  RFC_CHAR Matnr[18];
  RFC_CHAR Selal[2];
  RFC_CHAR Serge[30];
  RFC_CHAR Stktx[40];
  RFC_CHAR Stlal[2];
  RFC_CHAR Stlan[1];
  RFC_CHAR Stlbe[4];
  RFC_CHAR Stlst[2];
  RFC_CHAR Vmtnr[18];
  RFC_CHAR Werks[4];
  RFC_CHAR Ztext[40];
  RFC_CHAR Revlv[2];
  RFC_CHAR Tplnr[30];
  RFC_CHAR Dokar[3];
  RFC_CHAR Doknr[25];
  RFC_CHAR Doktl[3];
  RFC_CHAR Dokvr[2];
  RFC_CHAR Vbeln[10];
  RFC_NUM Vbpos[6];
  RFC_CHAR Stobj[18];
  RFC_CHAR Vdknr[25];
  RFC_CHAR Vdkar[3];
  RFC_CHAR Vdktl[3];
  RFC_CHAR Vdkvr[2];
  RFC_CHAR Veqnr[18];
  RFC_CHAR Vtpnr[30];
  RFC_CHAR Pspnr[24];
  RFC_CHAR Oitxt[40];
  RFC_CHAR MatnrLong[40];
 } CAD_BICSK;
#endif

#ifndef SAP_ST_CAD_BOM_ITEM
#define SAP_ST_CAD_BOM_ITEM
typedef struct {
  RFC_CHAR Upskz[1];
  RFC_CHAR Auskz[1];
  RFC_CHAR Alpos[1];
  RFC_CHAR Ausch[6];
  RFC_CHAR Avoau[6];
  RFC_CHAR Beikz[1];
  RFC_CHAR Cadpo[1];
  RFC_CHAR Ekgrp[3];
  RFC_CHAR Erskz[1];
  RFC_CHAR Fmeng[1];
  RFC_CHAR Idnrk[18];
  RFC_CHAR Lifnr[10];
  RFC_CHAR Lifzt[3];
  RFC_CHAR Matkl[9];
  RFC_CHAR Meins[3];
  RFC_CHAR Menge[18];
  RFC_CHAR Netau[1];
  RFC_CHAR Nfmat[18];
  RFC_CHAR Nlfzt[3];
  RFC_CHAR Peinh[6];
  RFC_CHAR Posnr[4];
  RFC_CHAR Postp[1];
  RFC_CHAR Preis[14];
  RFC_CHAR Potx1[40];
  RFC_CHAR Potx2[40];
  RFC_CHAR Pswrk[4];
  RFC_CHAR Rekrs[1];
  RFC_CHAR Rform[2];
  RFC_CHAR Roanz[17];
  RFC_CHAR Roame[3];
  RFC_CHAR Rokme[3];
  RFC_CHAR Romei[3];
  RFC_CHAR Romen[17];
  RFC_CHAR Roms1[17];
  RFC_CHAR Roms2[17];
  RFC_CHAR Roms3[17];
  RFC_CHAR Rvrel[1];
  RFC_CHAR Sakto[10];
  RFC_CHAR Sanfe[1];
  RFC_CHAR Sanin[1];
  RFC_CHAR Sanka[1];
  RFC_CHAR Sanko[1];
  RFC_CHAR Sanvs[1];
  RFC_CHAR Schgt[1];
  RFC_CHAR Selal[2];
  RFC_CHAR Selid[18];
  RFC_CHAR Selpo[4];
  RFC_CHAR Selsb[10];
  RFC_CHAR Sortf[10];
  RFC_CHAR Stkkz[1];
  RFC_CHAR Stktx[40];
  RFC_CHAR Stlal[2];
  RFC_CHAR Stlkz[1];
  RFC_CHAR Verti[4];
  RFC_CHAR Webaz[3];
  RFC_CHAR Waers[5];
  RFC_CHAR Dokar[3];
  RFC_CHAR Doknr[25];
  RFC_CHAR Dokvr[2];
  RFC_CHAR Doktl[3];
  RFC_CHAR Ewahr[3];
  RFC_CHAR Ekorg[4];
  RFC_CHAR Lgort[4];
  RFC_CHAR Class[18];
  RFC_CHAR Klart[3];
  RFC_CHAR Potpr[1];
  RFC_CHAR Alpgr[2];
  RFC_CHAR Alpst[1];
  RFC_NUM Alprf[2];
  RFC_CHAR Dspst[2];
  RFC_CHAR Prvbe[10];
  RFC_CHAR Nfeag[2];
  RFC_CHAR Nfgrp[2];
  RFC_CHAR Kzkup[1];
  RFC_CHAR Intrm[18];
  RFC_CHAR Kzclb[1];
  RFC_CHAR Nlfzv[4];
  RFC_CHAR Nlfmv[3];
  RFC_CHAR Rfpnt[20];
  RFC_CHAR MatnrLong[40];
 } CAD_BOM_ITEM;
#endif

#ifndef SAP_ST_CSSUBITEM
#define SAP_ST_CSSUBITEM
typedef struct {
  RFC_CHAR Posid[4];
  RFC_CHAR Ebort[20];
  RFC_CHAR Upmng[17];
  RFC_CHAR Uposz[4];
  RFC_CHAR Uptxt[40];
 } CSSUBITEM;
#endif

#ifndef SAP_ST_CLS_CHARAC
#define SAP_ST_CLS_CHARAC
typedef struct {
  RFC_CHAR Atnam[30];
  RFC_CHAR Atbez[30];
  RFC_CHAR Atwrt[30];
  RFC_CHAR Dinkb[3];
  RFC_CHAR Unit[6];
 } CLS_CHARAC;
#endif

#ifndef SAP_ST_RFCDMSDATA
#define SAP_ST_RFCDMSDATA
typedef struct {
  RFC_CHAR Fieldmulti[40];
  RFC_CHAR Fieldname[35];
  RFC_CHAR Fieldvalue[255];
 } RFCDMSDATA;
#endif

#ifndef SAP_ST_CAD_RETURN_VALUE_test
#define SAP_ST_CAD_RETURN_VALUE_test
typedef struct {
  RFC_CHAR VALUE[10];
  RFC_CHAR MESSAGE_LEN[4];
 } CAD_RETURN_VALUE_test;
#endif

#ifndef SAP_TH_CAD_RETURN_VALUE_test
#define SAP_TH_CAD_RETURN_VALUE_test
static const RFC_TYPEHANDLE handleOfCAD_RETURN_VALUE_test;

static const RFC_TYPE_ELEMENT typeOfCAD_RETURN_VALUE_test[] = {
  {"VALUE", TYPC, 10, 0},
  {"MESSAGE_LEN", TYPC, 4, 0},
 };
#endif

/* structure type handle and element definition */

#ifndef SAP_TH_CAD_BICSK
#define SAP_TH_CAD_BICSK
static const RFC_TYPEHANDLE handleOfCAD_BICSK;

static const RFC_TYPE_ELEMENT typeOfCAD_BICSK[] = {
  {"STYPE", TYPC, 1, 0},
  {"TCODE", TYPC, 20, 0},
  {"AENNR", TYPC, 12, 0},
  {"BMEIN", TYPC, 3, 0},
  {"BMENG", TYPC, 17, 0},
  {"CADKZ", TYPC, 1, 0},
  {"DATUB", TYPC, 10, 0},
  {"DATUV", TYPC, 10, 0},
  {"EMENG", TYPC, 17, 0},
  {"EQUNR", TYPC, 18, 0},
  {"EXSTL", TYPC, 18, 0},
  {"LABOR", TYPC, 3, 0},
  {"LOEKZ", TYPC, 1, 0},
  {"LOSBS", TYPC, 17, 0},
  {"LOSVN", TYPC, 17, 0},
  {"MATNR", TYPC, 18, 0},
  {"SELAL", TYPC, 2, 0},
  {"SERGE", TYPC, 30, 0},
  {"STKTX", TYPC, 40, 0},
  {"STLAL", TYPC, 2, 0},
  {"STLAN", TYPC, 1, 0},
  {"STLBE", TYPC, 4, 0},
  {"STLST", TYPC, 2, 0},
  {"VMTNR", TYPC, 18, 0},
  {"WERKS", TYPC, 4, 0},
  {"ZTEXT", TYPC, 40, 0},
  {"REVLV", TYPC, 2, 0},
  {"TPLNR", TYPC, 30, 0},
  {"DOKAR", TYPC, 3, 0},
  {"DOKNR", TYPC, 25, 0},
  {"DOKTL", TYPC, 3, 0},
  {"DOKVR", TYPC, 2, 0},
  {"VBELN", TYPC, 10, 0},
  {"VBPOS", TYPNUM, 6, 0},
  {"STOBJ", TYPC, 18, 0},
  {"VDKNR", TYPC, 25, 0},
  {"VDKAR", TYPC, 3, 0},
  {"VDKTL", TYPC, 3, 0},
  {"VDKVR", TYPC, 2, 0},
  {"VEQNR", TYPC, 18, 0},
  {"VTPNR", TYPC, 30, 0},
  {"PSPNR", TYPC, 24, 0},
  {"OITXT", TYPC, 40, 0},
  {"MATNR_LONG", TYPC, 40, 0},
 };
#endif

#ifndef SAP_TH_CAD_BOM_ITEM
#define SAP_TH_CAD_BOM_ITEM
static const RFC_TYPEHANDLE handleOfCAD_BOM_ITEM;
static const RFC_TYPE_ELEMENT typeOfCAD_BOM_ITEM[] = {
  {"UPSKZ", TYPC, 1, 0},
  {"AUSKZ", TYPC, 1, 0},
  {"ALPOS", TYPC, 1, 0},
  {"AUSCH", TYPC, 6, 0},
  {"AVOAU", TYPC, 6, 0},
  {"BEIKZ", TYPC, 1, 0},
  {"CADPO", TYPC, 1, 0},
  {"EKGRP", TYPC, 3, 0},
  {"ERSKZ", TYPC, 1, 0},
  {"FMENG", TYPC, 1, 0},
  {"IDNRK", TYPC, 18, 0},
  {"LIFNR", TYPC, 10, 0},
  {"LIFZT", TYPC, 3, 0},
  {"MATKL", TYPC, 9, 0},
  {"MEINS", TYPC, 3, 0},
  {"MENGE", TYPC, 18, 0},
  {"NETAU", TYPC, 1, 0},
  {"NFMAT", TYPC, 18, 0},
  {"NLFZT", TYPC, 3, 0},
  {"PEINH", TYPC, 6, 0},
  {"POSNR", TYPC, 4, 0},
  {"POSTP", TYPC, 1, 0},
  {"PREIS", TYPC, 14, 0},
  {"POTX1", TYPC, 40, 0},
  {"POTX2", TYPC, 40, 0},
  {"PSWRK", TYPC, 4, 0},
  {"REKRS", TYPC, 1, 0},
  {"RFORM", TYPC, 2, 0},
  {"ROANZ", TYPC, 17, 0},
  {"ROAME", TYPC, 3, 0},
  {"ROKME", TYPC, 3, 0},
  {"ROMEI", TYPC, 3, 0},
  {"ROMEN", TYPC, 17, 0},
  {"ROMS1", TYPC, 17, 0},
  {"ROMS2", TYPC, 17, 0},
  {"ROMS3", TYPC, 17, 0},
  {"RVREL", TYPC, 1, 0},
  {"SAKTO", TYPC, 10, 0},
  {"SANFE", TYPC, 1, 0},
  {"SANIN", TYPC, 1, 0},
  {"SANKA", TYPC, 1, 0},
  {"SANKO", TYPC, 1, 0},
  {"SANVS", TYPC, 1, 0},
  {"SCHGT", TYPC, 1, 0},
  {"SELAL", TYPC, 2, 0},
  {"SELID", TYPC, 18, 0},
  {"SELPO", TYPC, 4, 0},
  {"SELSB", TYPC, 10, 0},
  {"SORTF", TYPC, 10, 0},
  {"STKKZ", TYPC, 1, 0},
  {"STKTX", TYPC, 40, 0},
  {"STLAL", TYPC, 2, 0},
  {"STLKZ", TYPC, 1, 0},
  {"VERTI", TYPC, 4, 0},
  {"WEBAZ", TYPC, 3, 0},
  {"WAERS", TYPC, 5, 0},
  {"DOKAR", TYPC, 3, 0},
  {"DOKNR", TYPC, 25, 0},
  {"DOKVR", TYPC, 2, 0},
  {"DOKTL", TYPC, 3, 0},
  {"EWAHR", TYPC, 3, 0},
  {"EKORG", TYPC, 4, 0},
  {"LGORT", TYPC, 4, 0},
  {"CLASS", TYPC, 18, 0},
  {"KLART", TYPC, 3, 0},
  {"POTPR", TYPC, 1, 0},
  {"ALPGR", TYPC, 2, 0},
  {"ALPST", TYPC, 1, 0},
  {"ALPRF", TYPNUM, 2, 0},
  {"DSPST", TYPC, 2, 0},
  {"PRVBE", TYPC, 10, 0},
  {"NFEAG", TYPC, 2, 0},
  {"NFGRP", TYPC, 2, 0},
  {"KZKUP", TYPC, 1, 0},
  {"INTRM", TYPC, 18, 0},
  {"KZCLB", TYPC, 1, 0},
  {"NLFZV", TYPC, 4, 0},
  {"NLFMV", TYPC, 3, 0},
  {"RFPNT", TYPC, 20, 0},
  {"MATNR_LONG", TYPC, 40, 0},
 };
#endif
/*
#ifndef SAP_TH_CSSUBITEM
#define SAP_TH_CSSUBITEM
static const RFC_TYPEHANDLE handleOfCSSUBITEM;
static const RFC_TYPE_ELEMENT typeOfCSSUBITEM[] = {
  {"POSID", TYPC, 4, 0},
  {"EBORT", TYPC, 20, 0},
  {"UPMNG", TYPC, 17, 0},
  {"UPOSZ", TYPC, 4, 0},
  {"UPTXT", TYPC, 40, 0},
 };
#endif*/

#ifndef SAP_TH_CLS_CHARAC
#define SAP_TH_CLS_CHARAC
static const RFC_TYPEHANDLE handleOfCLS_CHARAC;

static const RFC_TYPE_ELEMENT typeOfCLS_CHARAC[] = {
  {"ATNAM", TYPC, 30, 0},
  {"ATBEZ", TYPC, 30, 0},
  {"ATWRT", TYPC, 30, 0},
  {"DINKB", TYPC, 3, 0},
  {"UNIT", TYPC, 6, 0},
 };
#endif

#ifndef SAP_TH_RFCDMSDATA
#define SAP_TH_RFCDMSDATA
static const RFC_TYPEHANDLE handleOfRFCDMSDATA;

static const RFC_TYPE_ELEMENT typeOfRFCDMSDATA[] = {
  {"FIELDMULTI", TYPC, 40, 0},
  {"FIELDNAME", TYPC, 35, 0},
  {"FIELDVALUE", TYPC, 255, 0},
 };
#endif

#ifndef SAP_TH_CSSUBITEM
#define SAP_TH_CSSUBITEM
static const RFC_TYPEHANDLE handleOfCSSUBITEM;

static const RFC_TYPE_ELEMENT typeOfCSSUBITEM[] = {
  {"POSID", TYPC, 4, 0},
  {"EBORT", TYPC, 20, 0},
  {"UPMNG", TYPC, 17, 0},
  {"UPOSZ", TYPC, 4, 0},
  {"UPTXT", TYPC, 40, 0},
 };
#endif
/*
#ifndef SAP_TH_CLS_CHARAC
#define SAP_TH_CLS_CHARAC
static const RFC_TYPEHANDLE handleOfCLS_CHARAC;

static const RFC_TYPE_ELEMENT typeOfCLS_CHARAC[] = {
  {"ATNAM", TYPC, 30, 0},
  {"ATBEZ", TYPC, 30, 0},
  {"ATWRT", TYPC, 30, 0},
  {"DINKB", TYPC, 3, 0},
  {"UNIT", TYPC, 6, 0},
 };
#endif

#ifndef SAP_TH_RFCDMSDATA
#define SAP_TH_RFCDMSDATA
static const RFC_TYPEHANDLE handleOfRFCDMSDATA;

static const RFC_TYPE_ELEMENT typeOfRFCDMSDATA[] = {
  {"FIELDMULTI", TYPC, 40, 0},
  {"FIELDNAME", TYPC, 35, 0},
  {"FIELDVALUE", TYPC, 255, 0},
 };
#endif*/

/*------------------BAPIMATHEAD------------------*/
#ifndef SAP_ST_BAPIMATHEAD
#define SAP_ST_BAPIMATHEAD
typedef struct
{
RFC_CHAR Material[18];			/*	Material Number*/
RFC_CHAR Ind_Sector[1];			/*	Industry sector*/
RFC_CHAR Matl_Type[4];			/*Material type*/
RFC_CHAR Basic_View[1];			/*Basic Data View*/
RFC_CHAR Sales_View[1];			/*	Sales View*/
RFC_CHAR Purchase_View[1];	    /*	Purchasing View*/
RFC_CHAR Mrp_View[1];		    /*Material Requirements Planning (MRP) View*/
RFC_CHAR Forecast_View[1];	/*	Forecasting View*/
RFC_CHAR Work_Sched_View[1];	/*	Work Scheduling View*/
RFC_CHAR Prt_View[1];		    /*Production Resources/Tools (PRT) View*/
RFC_CHAR Storage_View[1];		/*Storage View*/
RFC_CHAR Warehouse_View[1];		/*Warehouse Management View*/
RFC_CHAR Quality_View[1];		/*Quality Management View*/
RFC_CHAR Account_View[1];		/*Accounting View*/
RFC_CHAR Cost_View[1];		     /*Costing View*/
RFC_CHAR Inp_Fld_Check[1];		/*Response if Fields Are Inactive*/
RFC_CHAR Material_External[40];	/*	Long Material Number for MATERIAL Field*/
RFC_CHAR MateriaL_Guid[32];		/*External GUID for MATERIAL Field*/
RFC_CHAR Material_Version[10];	/*	Version Number for MATERIAL Field*/
}BAPIMATHEAD;
#endif

#ifndef SAP_TH_BAPIMATHEAD
#define SAP_TH_BAPIMATHEAD
static const RFC_TYPEHANDLE handleOfBAPIMATHEAD;
static const RFC_TYPE_ELEMENT typeOfBAPIMATHEAD[]=
{
	{"MATERIAL",TYPC,18,0},
	{"IND_SECTOR",TYPC,1,0},
	{"MATL_TYPE",TYPC,4,0},
	{"BASIC_VIEW",TYPC,1,0},
	{"SALES_VIEW",TYPC,1,0},
	{"PURCHASE_VIEW",TYPC,1,0},
	{"MRP_VIEW",TYPC,1,0},
	{"FORECAST_VIEW",TYPC,1,0},
	{"WORK_SCHED_VIEW",TYPC,1,0},
	{"PRT_VIEW",TYPC,1,0},
	{"STORAGE_VIEW",TYPC,1,0},
	{"WAREHOUSE_VIEW",TYPC,1,0},
	{"QUALITY_VIEW",TYPC,1,0},
	{"ACCOUNT_VIEW",TYPC,1,0},
	{"COST_VIEW",TYPC,1,0},
	{"INP_FLD_CHECK",TYPC,1,0},
	{"MATERIAL_EXTERNAL",TYPC,40,0},
	{"MATERIAL_GUID",TYPC,32,0},
	{"MATERIAL_VERSION",TYPC,10,0},
};
#endif
/*--------------------END Of BAPIMATHEAD-------------------*/
/*--------------------BAPI_MARA-------------------*/
#ifndef SAP_ST_BAPI_MARA
#define SAP_ST_BAPI_MARA
typedef struct
{
RFC_CHAR Del_Flag[1];	/*0	Flag Material for Deletion at Client Level*/
RFC_CHAR Matl_Group[9];	/*	Material group*/
RFC_CHAR Old_Mat_No[18];	/*	Old material number*/
RFC_CHAR Base_Uom[3];	/*	Base Unit of Measure*/
RFC_CHAR Base_Uom_Iso[3];	/*	Base unit of measure in ISO code*/
RFC_CHAR Po_Unit[3];	/*	Order unit*/
RFC_CHAR Po_Unit_Iso[3];	/*	Order unit in ISO code*/
RFC_CHAR Document[22];	/*	Document number (without document management system)*/
RFC_CHAR Doc_Type[3];	/*	Document type (without Document Management system)*/
RFC_CHAR Doc_Vers[2];	/*	Document version (without Document Management system)*/
RFC_CHAR Doc_Format[4];	/*	Page format of document (without Document Management system)*/
RFC_CHAR Doc_Chg_No[6];	/*	Document change number (without document management system)*/
RFC_CHAR Page_No[3];	/*	Page number of document (without Document Management system)*/
RFC_NUM  No_Sheets[3];	/*	Number of sheets (without Document Management system)*/
RFC_CHAR Prod_Memo[18];	/*	Production/inspection memo*/
RFC_CHAR Pageformat[4];	/*	Page Format of Production Memo*/
RFC_CHAR Size_Dim[32];	/*	Size/dimensions*/
RFC_CHAR Basic_Matl[48];	/*	Basic Material*/
RFC_CHAR Std_Descr[18];	/*	Industry Standard Description (such as ANSI or ISO)*/
RFC_CHAR Dsn_Office[3];	/*	Laboratory/design office*/
RFC_CHAR Pur_Valkey[4];	/*	Purchasing Value Key*/
RFC_BCD Net_Weight[7]; 	/*Net weight*/
RFC_CHAR Unit_Of_Wt[3];	/*	Weight Unit*/
RFC_CHAR Unit_Of_Wt_Iso[3];	/*	Unit of weight in ISO code*/
RFC_CHAR Container[2];	/*	Container requirements*/
RFC_CHAR Stor_Conds[2];	/*	Storage conditions*/
RFC_CHAR Temp_Conds[2];	/*	Temperature conditions indicator*/
RFC_CHAR Trans_Grp[4];	/*	Transportation group*/
RFC_CHAR Haz_Mat_No[18];	/*	Hazardous material number*/
RFC_CHAR Division[2];	/*	Division*/
RFC_CHAR Competitor[10];	/*	Competitor*/
RFC_BCD Qty_Gr_Gi[7];	/*Quantity: Number of GR/GI slips to be printed*/
RFC_CHAR Proc_Rule[1];	/*	Procurement rule*/
RFC_CHAR Sup_Source[1];	/*	Source of Supply*/
RFC_CHAR Season[4];	/*	Season category*/
RFC_CHAR Label_Type[2];	/*	Label type*/
RFC_CHAR Label_Form[2];	/*	Label form*/
RFC_CHAR Prod_Hier[18];	/*	Product hierarchy*/
RFC_CHAR Cad_Id[1];	/*	CAD indicator*/
RFC_BCD Allowed_Wt[7];	/*Allowed packaging weight*/
RFC_CHAR Pack_Wt_Un[3];	/*	Unit of weight (allowed packaging weight)*/
RFC_CHAR Pack_Wt_Un_Iso[3];	/*	Unit of weight (allowed packaging weight) in ISO code*/
RFC_BCD Allwd_Vol[7];	/*Allowed packaging volume*/
RFC_CHAR Pack_Vo_Un[3];	/*	Volume unit (allowed packaging volume)*/
RFC_CHAR Pack_Vo_Un_Iso[3];	/*	Volume unit (allowed packaging volume) in ISO code*/
RFC_BCD Wt_Tol_Lt[2];	/*Excess Weight Tolerance for Handling unit*/
RFC_BCD Vol_Tol_Lt[2];	/*Excess Volume Tolerance of the Handling Unit*/
RFC_CHAR Var_Ord_Un[1];	/*	Variable order unit active*/
RFC_CHAR Batch_Mgmt[1];	/*	Batch management requirement indicator*/
RFC_CHAR Sh_Mat_Typ[4];	/*	Packaging Material Type*/
RFC_BCD Fill_Level[2];	/*	Maximum level (by volume)*/
RFC_INT2 Stack_Fact;	/*	Stacking factor*/
RFC_CHAR Mat_Grp_Sm[4];	/*	Material Group: Packaging Materials*/
RFC_CHAR Authoritygroup[4];	/*	Authorization Group*/
RFC_CHAR Qm_Procmnt[1];	/*	QM in Procurement is Active*/
RFC_CHAR Catprofile[9];	/*	Catalog Profile*/
RFC_BCD Minremlife[3];	/*	Minimum remaining shelf life*/
RFC_BCD Shelf_Life[3];	/*	Total shelf life*/
RFC_BCD Stor_Pct[2];	/*	Storage percentage*/
RFC_CHAR Pur_Status[2];	/*	Cross-Plant Material Status*/
RFC_CHAR Sal_Status[2];	/*	Cross-distribution-chain material status*/
RFC_DATE Pvalidfrom;	/*	Date from which the cross-plant material status is valid*/
RFC_DATE Svalidfrom;	/*	Date from which the X-distr.-chain material status is valid*/
RFC_CHAR Envt_Rlvt[1];	/*	Indicator: Environmentally Relevant*/
RFC_CHAR Prod_Alloc[18];	/*	Product allocation determination procedure*/
RFC_CHAR Qual_Dik[1];	/*	Material qualifies for discount in kind*/
RFC_CHAR Manu_Mat[40];	/*	Manufacturer part number*/
RFC_CHAR Mfr_No[10];	/*	Manufacturer number*/
RFC_CHAR Inv_Mat_No[18];	/*	Number of firm's own (internal) inventory-managed material*/
RFC_CHAR Manuf_Prof[4];	/*	Mfr part profile*/
RFC_CHAR Hazmatprof[3];	/*	Dangerous Goods Indicator Profile*/
RFC_CHAR High_Visc[1];	/*	Indicator: Highly Viscous*/
RFC_CHAR Looseorliq[1];	/*	Indicator: In Bulk/Liquid*/
RFC_CHAR Closed_Box[1];	/*	Packaging Material is Closed Packaging*/
RFC_CHAR Appd_B_Rec[1];	/*	Indicator: Approved batch record required*/
RFC_NUM	 Matcmpllvl[2];	/*	Material completion level*/
RFC_CHAR Par_Eff[1];	/*	Assign effectivity parameter values/ override change numbers*/
RFC_CHAR Round_Up_Rule_Expiration_Date[1];	/*	Rounding rule for calculation of SLED*/
RFC_CHAR Period_Ind_Expiration_Date[1];	/*	Period indicator for shelf life expiration date*/
RFC_CHAR Prod_Composition_On_Packaging[1];	/*	Indicator: Product composition printed on packaging*/
RFC_CHAR Item_Cat[4];	/*	General item category group*/
RFC_CHAR Haz_Mat_No_External[40];	/*	Long Material Number for HAZ_MAT_NO Field*/
RFC_CHAR Haz_Mat_No_Guid[32];	/*	External GUID for HAZ_MAT_NO Field*/
RFC_CHAR Haz_Mat_No_Version[10];	/*	Version Number for HAZ_MAT_NO Field*/
RFC_CHAR Inv_Mat_No_External[40];	/*	Long Material Number for INV_MAT_NO Field*/
RFC_CHAR Inv_Mat_No_Guid[32];	/*	External GUID for INV_MAT_NO Field*/
RFC_CHAR Inv_Mat_No_Version[10];	/*	Version Number for INV_MAT_NO Field*/
RFC_CHAR Material_Fixed[1];	/*	Material Is Locked*/
RFC_CHAR Cm_Relevance_Flag[1];	/*	Relevant for Configuration Management*/
RFC_CHAR Sled_Bbd[1];	/*	Expiration Date*/
RFC_CHAR Gtin_Variant[2];	/*	Global Trade Item Number Variant*/
RFC_CHAR Serialization_Level[1];	/*	Level of Explicitness for Serial Number*/
RFC_CHAR Pl_Ref_Mat[18];	/*	Reference material for materials packed in same way*/
RFC_CHAR Extmatlgrp[18];	/*	External Material Group*/
RFC_CHAR Uomusage[1];	/*	Units of measure usage*/
RFC_CHAR Pl_Ref_Mat_External[40];	/*	Long Material Number for Field PL_REF_MAT*/
RFC_CHAR Pl_Ref_Mat_Guid[32];	/*	External GUID for Field PL_REF_MAT*/
RFC_CHAR Pl_Ref_Mat_Version[10];	/*	Version Number for Field PL_REF_MAT*/
}BAPI_MARA;
#endif

#ifndef SAP_TH_BAPI_MARA
#define SAP_TH_BAPI_MARA
static const RFC_TYPEHANDLE handleOfBAPI_MARA;
static const RFC_TYPE_ELEMENT typeOfBAPI_MARA[]=
{
	{"DEL_FLAG",TYPC,	1,	0},
	{"MATL_GROUP",TYPC,	9,	0},
	{"OLD_MAT_NO",TYPC,	18,	0},
	{"BASE_UOM",TYPC,	3,	0},
	{"BASE_UOM_ISO",TYPC,	3,	0},
	{"PO_UNIT",	TYPC,3,	0},
	{"PO_UNIT_ISO",	TYPC,	3,	0},
	{"DOCUMENT",	TYPC,	22,	0},
	{"DOC_TYPE",	TYPC,	3,	0},
	{"DOC_VERS",	TYPC,	2,	0},
	{"DOC_FORMAT",	TYPC,	4,	0},
	{"DOC_CHG_NO",	TYPC,	6,	0},
	{"PAGE_NO",	TYPC,	3,	0},
	{"NO_SHEETS",	TYPNUM,	3,	0},
	{"PROD_MEMO",	TYPC,	18,	0},
	{"PAGEFORMAT",	TYPC,	4,	0},
	{"SIZE_DIM",	TYPC,	32,	0},
	{"BASIC_MATL",	TYPC,	48,	0},
	{"STD_DESCR",	TYPC,	18,	0},
	{"DSN_OFFICE",	TYPC,	3,	0},
	{"PUR_VALKEY",	TYPC,	4,	0},
	{"NET_WEIGHT",	TYPP,	7,	0},
	{"UNIT_OF_WT",	TYPC,	3,	0},
	{"UNIT_OF_WT_ISO",	TYPC,	3,	0},
	{"CONTAINER",	TYPC,	2,	0},
	{"STOR_CONDS",	TYPC,	2,	0},
	{"TEMP_CONDS",	TYPC,	2,	0},
	{"TRANS_GRP",	TYPC,	4,	0},
	{"HAZ_MAT_NO",	TYPC,	18,	0},
	{"DIVISION",	TYPC,	2,	0},
	{"COMPETITOR",	TYPC,	10,	0},
	{"QTY_GR_GI",	TYPP,	7,	0},
	{"PROC_RULE",	TYPC,	1,	0},
	{"SUP_SOURCE",	TYPC,	1,	0},
	{"SEASON",	TYPC,	4,	0},
	{"LABEL_TYPE",	TYPC,	2,	0},
	{"LABEL_FORM",	TYPC,	2,	0},
	{"PROD_HIER",	TYPC,	18,	0},
	{"CAD_ID",	TYPC,	1,	0},
	{"ALLOWED_WT",	TYPP,	7,	0},
	{"PACK_WT_UN",	TYPC,	3,	0},
	{"PACK_WT_UN_ISO",	TYPC,	3,	0},
	{"ALLWD_VOL",	TYPP,	7,	0},
	{"PACK_VO_UN",	TYPC,	3,	0},
	{"PACK_VO_UN_ISO",	TYPC,	3,	0},
	{"WT_TOL_LT",	TYPP,	2,	0},
	{"VOL_TOL_LT",	TYPP,	2,	0},
	{"VAR_ORD_UN",	TYPC,	1,	0},
	{"BATCH_MGMT",	TYPC,	1,	0},
	{"SH_MAT_TYP",	TYPC,	4,	0},
	{"FILL_LEVEL",	TYPP,	2,	0},
	{"STACK_FACT",	TYPINT2,	sizeof(RFC_INT2),	0},
	{"MAT_GRP_SM",	TYPC,	4,	0},
	{"AUTHORITYGROUP",	TYPC,	4,	0},
	{"QM_PROCMNT",	TYPC,	1,	0},
	{"CATPROFILE",	TYPC,	9,	0},
	{"MINREMLIFE",	TYPP,	3,	0},
	{"SHELF_LIFE",	TYPP,	3,	0},
	{"STOR_PCT",	TYPP,	2,	0},
	{"PUR_STATUS",	TYPC,	2,	0},
	{"SAL_STATUS",	TYPC,	2,	0},
	{"PVALIDFROM",	TYPDATE,	sizeof(RFC_DATE),	0},
	{"SVALIDFROM",	TYPDATE,	sizeof(RFC_DATE),	0},
	{"ENVT_RLVT",	TYPC,	1,	0},
	{"PROD_ALLOC",	TYPC,	18,	0},
	{"QUAL_DIK",	TYPC,	1,	0},
	{"MANU_MAT",	TYPC,	40,	0},
	{"MFR_NO",	TYPC,	10,	0},
	{"INV_MAT_NO",	TYPC,	18,	0},
	{"MANUF_PROF",	TYPC,	4,	0},
	{"HAZMATPROF",	TYPC,	3,	0},
	{"HIGH_VISC",	TYPC,	1,	0},
	{"LOOSEORLIQ",	TYPC,	1,	0},
	{"CLOSED_BOX",	TYPC,	1,	0},
	{"APPD_B_REC",	TYPC,	1,	0},
	{"MATCMPLLVL",	TYPNUM,	2,	0},
	{"PAR_EFF",	TYPC,	1,	0},
	{"ROUND_UP_RULE_EXPIRATION_DATE",	TYPC,	1,	0},
	{"PERIOD_IND_EXPIRATION_DATE",	TYPC,	1,	0},
	{"PROD_COMPOSITION_ON_PACKAGING",	TYPC,	1,	0},
	{"ITEM_CAT",	TYPC,	4,	0},
	{"HAZ_MAT_NO_EXTERNAL",	TYPC,	40,	0},
	{"HAZ_MAT_NO_GUID",	TYPC,	32,	0},
	{"HAZ_MAT_NO_VERSION",	TYPC,	10,	0},
	{"INV_MAT_NO_EXTERNAL",	TYPC,	40,	0},
	{"INV_MAT_NO_GUID",	TYPC,	32,	0},
	{"INV_MAT_NO_VERSION",	TYPC,	10,	0},
	{"MATERIAL_FIXED",	TYPC,	1,	0},
	{"CM_RELEVANCE_FLAG",	TYPC,	1,	0},
	{"SLED_BBD",	TYPC,	1,	0},
	{"GTIN_VARIANT",	TYPC,	2,	0},
	{"SERIALIZATION_LEVEL",	TYPC,	1,	0},
	{"PL_REF_MAT",	TYPC,	18,	0},
	{"EXTMATLGRP",	TYPC,	18,	0},
	{"UOMUSAGE",	TYPC,	1,	0},
	{"PL_REF_MAT_EXTERNAL",	TYPC,	40,	0},
	{"PL_REF_MAT_GUID",	TYPC,	32,	0},
	{"PL_REF_MAT_VERSION",	TYPC,	10,	0},
};
#endif
/*--------------------End BAPI_MARA-------------------*/
/*--------------------BAPI_MARAX-------------------*/

#ifndef SAP_ST_BAPI_MARAX
#define SAP_ST_BAPI_MARAX
typedef struct
{
RFC_CHAR Del_Flag[1];
RFC_CHAR Matl_Group[1];
RFC_CHAR Old_Mat_No[1];
RFC_CHAR Base_Uom[1];
RFC_CHAR Base_Uom_Iso[1];
RFC_CHAR Po_Unit[1];
RFC_CHAR Po_Unit_Iso[1];
RFC_CHAR Document[1];
RFC_CHAR Doc_Type[1];
RFC_CHAR Doc_Vers[1];
RFC_CHAR Doc_Format[1];
RFC_CHAR Doc_Chg_No[1];
RFC_CHAR Page_No[1];
RFC_CHAR No_Sheets[1];
RFC_CHAR Prod_Memo[1];
RFC_CHAR Pageformat[1];
RFC_CHAR Size_Dim[1];
RFC_CHAR Basic_Matl[1];
RFC_CHAR Std_Descr[1];
RFC_CHAR Dsn_Office[1];
RFC_CHAR Pur_Valkey[1];
RFC_CHAR Net_Weight[1];
RFC_CHAR Unit_Of_Wt[1];
RFC_CHAR Unit_Of_Wt_Iso[1];
RFC_CHAR Container[1];
RFC_CHAR Stor_Conds[1];
RFC_CHAR Temp_Conds[1];
RFC_CHAR Trans_Grp[1];
RFC_CHAR Haz_Mat_No[1];
RFC_CHAR Division[1];
RFC_CHAR Competitor[1];
RFC_CHAR Qty_Gr_Gi[1];
RFC_CHAR Proc_Rule[1];
RFC_CHAR Sup_Source[1];
RFC_CHAR Season[1];
RFC_CHAR Label_Type[1];
RFC_CHAR Label_Form[1];
RFC_CHAR Prod_Hier[1];
RFC_CHAR Cad_Id[1];
RFC_CHAR Allowed_Wt[1];
RFC_CHAR Pack_Wt_Un[1];
RFC_CHAR Pack_Wt_Un_Iso[1];
RFC_CHAR Allwd_Vol[1];
RFC_CHAR Pack_Vo_Un[1];
RFC_CHAR Pack_Vo_Un_Iso[1];
RFC_CHAR Wt_Tol_Lt[1];
RFC_CHAR Vol_Tol_Lt[1];
RFC_CHAR Var_Ord_Un[1];
RFC_CHAR Batch_Mgmt[1];
RFC_CHAR Sh_Mat_Typ[1];
RFC_CHAR Fill_Level[1];
RFC_CHAR Stack_Fact[1];
RFC_CHAR Mat_Grp_Sm[1];
RFC_CHAR Authoritygroup[1];
RFC_CHAR Qm_Procmnt[1];
RFC_CHAR Catprofile[1];
RFC_CHAR Minremlife[1];
RFC_CHAR Shelf_Life[1];
RFC_CHAR Stor_Pct[1];
RFC_CHAR Pur_Status[1];
RFC_CHAR Sal_Status[1];
RFC_CHAR Pvalidfrom[1];
RFC_CHAR Svalidfrom[1];
RFC_CHAR Envt_Rlvt[1];
RFC_CHAR Prod_Alloc[1];
RFC_CHAR Qual_Dik[1];
RFC_CHAR Manu_Mat[1];
RFC_CHAR Mfr_No[1];
RFC_CHAR Inv_Mat_No[1];
RFC_CHAR Manuf_Prof[1];
RFC_CHAR Hazmatprof[1];
RFC_CHAR High_Visc[1];
RFC_CHAR Looseorliq[1];
RFC_CHAR Closed_Box[1];
RFC_CHAR Appd_B_Rec[1];
RFC_CHAR Matcmpllvl[1];
RFC_CHAR Par_Eff[1];
RFC_CHAR Round_Up_Rule_Expiration_Date[1];
RFC_CHAR Period_Ind_Expiration_Date[1];
RFC_CHAR Prod_Composition_On_Packaging[1];
RFC_CHAR Item_Cat[1];
RFC_CHAR Haz_Mat_No_External[1];
RFC_CHAR Haz_Mat_No_Guid[1];
RFC_CHAR Haz_Mat_No_Version[1];
RFC_CHAR Inv_Mat_No_External[1];
RFC_CHAR Inv_Mat_No_Guid[1];
RFC_CHAR Inv_Mat_No_Version[1];
RFC_CHAR Material_Fixed[1];
RFC_CHAR Cm_Relevance_Flag[1];
RFC_CHAR Sled_Bbd[1];
RFC_CHAR Gtin_Variant[1];
RFC_CHAR Serialization_Level[1];
RFC_CHAR Pl_Ref_Mat[1];
RFC_CHAR Extmatlgrp[1];
RFC_CHAR Uomusage[1];
RFC_CHAR Pl_Ref_Mat_External[1];
RFC_CHAR Pl_Ref_Mat_Guid[1];
RFC_CHAR Pl_Ref_Mat_Version[1];
}BAPI_MARAX;
#endif

#ifndef SAP_TH_BAPI_MARAX
#define SAP_TH_BAPI_MARAX
static const RFC_TYPEHANDLE handleOfBAPI_MARAX;
static const RFC_TYPE_ELEMENT typeOfBAPI_MARAX[]=
{
	{"DEL_FLAG",TYPC	,1,	0},
	{"MATL_GROUP",TYPC	,1,	0},
	{"OLD_MAT_NO",TYPC	,1,	0},
	{"BASE_UOM",TYPC	,1,	0},
	{"BASE_UOM_ISO",TYPC	,1,	0},
	{"PO_UNIT",	TYPC	,1,	0},
	{"PO_UNIT_ISO",	TYPC	,1,	0},
	{"DOCUMENT",TYPC	,1,	0},
	{"DOC_TYPE",TYPC	,1,	0},
	{"DOC_VERS",TYPC	,1,	0},
	{"DOC_FORMAT",TYPC	,1,	0},
	{"DOC_CHG_NO",TYPC	,1,	0},
	{"PAGE_NO",TYPC	,1,	0},
	{"NO_SHEETS",TYPC	,1,	0},
	{"PROD_MEMO",TYPC	,1,	0},
	{"PAGEFORMAT",TYPC	,1,	0},
	{"SIZE_DIM",TYPC	,1,	0},
	{"BASIC_MATL",TYPC	,1,	0},
	{"STD_DESCR",TYPC	,1,	0},
	{"DSN_OFFICE",TYPC	,1,	0},
	{"PUR_VALKEY",TYPC	,1,	0},
	{"NET_WEIGHT",TYPC	,1,	0},
	{"UNIT_OF_WT",TYPC	,1,	0},
	{"UNIT_OF_WT_ISO",TYPC	,1,	0},
	{"CONTAINER",TYPC	,1,	0},
	{"STOR_CONDS",TYPC	,1,	0},
	{"TEMP_CONDS",TYPC	,1,	0},
	{"TRANS_GRP",TYPC	,1,	0},
	{"HAZ_MAT_NO",TYPC	,1,	0},
	{"DIVISION",TYPC	,1,	0},
	{"COMPETITOR",TYPC	,1,	0},
	{"QTY_GR_GI",TYPC	,1,	0},
	{"PROC_RULE",TYPC	,1,	0},
	{"SUP_SOURCE",TYPC	,1,	0},
	{"SEASON",TYPC	,1,	0},
	{"LABEL_TYPE",TYPC	,1,	0},
	{"LABEL_FORM",TYPC	,1,	0},
	{"PROD_HIER",TYPC	,1,	0},
	{"CAD_ID",TYPC	,1,	0},
	{"ALLOWED_WT",TYPC	,1,	0},
	{"PACK_WT_UN",TYPC	,1,	0},
	{"PACK_WT_UN_ISO",TYPC	,1,	0},
	{"ALLWD_VOL",TYPC	,1,	0},
	{"PACK_VO_UN",TYPC	,1,	0},
	{"PACK_VO_UN_ISO",TYPC	,1,	0},
	{"WT_TOL_LT",TYPC	,1,	0},
	{"VOL_TOL_LT",TYPC	,1,	0},
	{"VAR_ORD_UN",TYPC	,1,	0},
	{"BATCH_MGMT",TYPC	,1,	0},
	{"SH_MAT_TYP",TYPC	,1,	0},
	{"FILL_LEVEL",TYPC	,1,	0},
	{"STACK_FACT",TYPC	,1,	0},
	{"MAT_GRP_SM",TYPC	,1,	0},
	{"AUTHORITYGROUP",TYPC	,1,	0},
	{"QM_PROCMNT",TYPC	,1,	0},
	{"CATPROFILE",TYPC	,1,	0},
	{"MINREMLIFE",TYPC	,1,	0},
	{"SHELF_LIFE",TYPC	,1,	0},
	{"STOR_PCT",TYPC	,1,	0},
	{"PUR_STATUS",TYPC	,1,	0},
	{"SAL_STATUS",TYPC	,1,	0},
	{"PVALIDFROM",TYPC	,1,	0},
	{"SVALIDFROM",TYPC	,1,	0},
	{"ENVT_RLVT",TYPC	,1,	0},
	{"PROD_ALLOC",TYPC	,1,	0},
	{"QUAL_DIK",TYPC	,1,	0},
	{"MANU_MAT",TYPC	,1,	0},
	{"MFR_NO",TYPC	,1,	0},
	{"INV_MAT_NO",TYPC	,1,	0},
	{"MANUF_PROF",TYPC	,1,	0},
	{"HAZMATPROF",TYPC	,1,	0},
	{"HIGH_VISC",TYPC	,1,	0},
	{"LOOSEORLIQ",TYPC	,1,	0},
	{"CLOSED_BOX",TYPC	,1,	0},
	{"APPD_B_REC",TYPC	,1,	0},
	{"MATCMPLLVL",TYPC	,1,	0},
	{"PAR_EFF",TYPC	,1,	0},
	{"ROUND_UP_RULE_EXPIRATION_DATE",TYPC	,1,	0},
	{"PERIOD_IND_EXPIRATION_DATE",TYPC	,1,	0},
	{"PROD_COMPOSITION_ON_PACKAGING",TYPC	,1,	0},
	{"ITEM_CAT",TYPC	,1,	0},
	{"HAZ_MAT_NO_EXTERNAL",	TYPC	,1,	0},
	{"HAZ_MAT_NO_GUID",TYPC	,1,	0},
	{"HAZ_MAT_NO_VERSION",TYPC	,1,	0},
	{"INV_MAT_NO_EXTERNAL",TYPC	,1,	0},
	{"INV_MAT_NO_GUID",TYPC	,1,	0},
	{"INV_MAT_NO_VERSION",TYPC	,1,	0},
	{"MATERIAL_FIXED",TYPC	,1,	0},
	{"CM_RELEVANCE_FLAG",TYPC	,1,	0},
	{"SLED_BBD",TYPC	,1,	0},
	{"GTIN_VARIANT",TYPC	,1,	0},
	{"SERIALIZATION_LEVEL",	TYPC	,1,	0},
	{"PL_REF_MAT",	TYPC	,1,	0},
	{"EXTMATLGRP",	TYPC	,1,	0},
	{"UOMUSAGE",TYPC	,1,	0},
	{"PL_REF_MAT_EXTERNAL",	TYPC	,1,	0},
	{"PL_REF_MAT_GUID",	TYPC	,1,	0},
	{"PL_REF_MAT_VERSION",	TYPC	,1,	0},
};
#endif

/*--------------------End BAPI_MARAX-------------------*/
/*--------------------BAPI_MARC-------------------*/
#ifndef SAP_ST_BAPI_MARC
#define SAP_ST_BAPI_MARC
typedef struct
{
RFC_CHAR Plant[4];/*	0	Plant*/
RFC_CHAR Del_Flag[1];/*	0	Flag Material for Deletion at Plant Level*/
RFC_CHAR Abc_Id[1];/*	0	ABC indicator*/
RFC_CHAR Crit_Part[1];/*	0	Indicator: Critical part*/
RFC_CHAR Pur_Group[3];/*	0	Purchasing group*/
RFC_CHAR Issue_Unit[3];/*	0	Unit of issue*/
RFC_CHAR Issue_Unit_Iso[3];/*	0	Unit of issue in ISO code*/
RFC_CHAR Mrpprofile[4];/*	0	Material: MRP profile*/
RFC_CHAR Mrp_Type[2];/*	0	MRP Type*/
RFC_CHAR Mrp_Ctrler[3];/*	0	MRP controller*/
RFC_BCD Plnd_Delry[2];/*	0	Planned delivery time in days*/
RFC_BCD Gr_Pr_Time[2];/*	0	Goods receipt processing time in days*/
RFC_CHAR Period_Ind[1];/*	0	Period indicator*/
RFC_BCD Assy_Scrap[3];/*	2	Assembly scrap in percent*/
RFC_CHAR Lotsizekey[2];/*	0	Lot size (materials planning)*/
RFC_CHAR Proc_Type[1];/*	0	Procurement Type*/
RFC_CHAR Spproctype[2];/*	0	Special procurement type*/
RFC_BCD Reorder_Pt[7];/*	3	Reorder Point*/
RFC_BCD Safety_Stk[7];/*	3	Safety stock*/
RFC_BCD Minlotsize[7];/*	3	Minimum lot size*/
RFC_BCD Maxlotsize[7];/*	3	Maximum lot size*/
RFC_BCD Fixed_Lot[7];/*	3	Fixed lot size*/
RFC_BCD Round_Val[7];/*	3	Rounding value for purchase order quantity*/
RFC_BCD Max_Stock[7];/*	3	Maximum stock level*/
RFC_BCD Ord_Costs[12];/*	4	Ordering costs (BAPI interfaces)*/
RFC_CHAR Dep_Req_Id[1];/*	0	Dependent requirements ind. for individual and coll. reqmts*/
RFC_CHAR Stor_Costs[1];/*	0	Storage costs indicator*/
RFC_CHAR Alt_Bom_Id[1];/*	0	Method for Selecting Alternative Bills of Material*/
RFC_CHAR Discontinu[1];/*	0	Discontinuation indicator*/
RFC_DATE Eff_O_Day;/*	0	Effective-Out Date*/
RFC_CHAR Follow_Up[18];/*	0	Follow-up material*/
RFC_CHAR Grp_Reqmts[1];/*	0	Indicator for Requirements Grouping*/
RFC_CHAR Mixed_Mrp[1];/*	0	Mixed MRP indicator*/
RFC_CHAR Sm_Key[3];/*	0	Scheduling Margin Key for Floats*/
RFC_CHAR Backflush[1];/*	0	Indicator: Backflush*/
RFC_CHAR Production_Scheduler[3];/*	0	Production scheduler*/
RFC_BCD Proc_Time[3];/*	2	Processing time*/
RFC_BCD Setuptime[3];/*	2	Setup and teardown time*/
RFC_BCD Interop[3]	;/*2	Interoperation time*/
RFC_BCD Base_Qty[7]	;/*3	Base quantity*/
RFC_BCD Inhseprodt[2];/*	0	In-house production time*/
RFC_BCD Stgeperiod[3];/*	0	Maximum storage period*/
RFC_CHAR Stge_Pd_Un[3];/*	0	Unit for maximum storage period*/
RFC_CHAR Stge_Pd_Un_Iso[3];/*	0	Unit for the maximum storage period in ISO code*/
RFC_BCD Over_Tol[2];/*	1	Overdelivery tolerance limit*/
RFC_CHAR Unlimited[1];/*	0	Indicator: Unlimited Overdelivery Allowed*/
RFC_BCD Under_Tol[2];/*	1	Underdelivery tolerance limit*/
RFC_BCD Replentime[2];/*	0	Total replenishment lead time (in workdays)*/
RFC_CHAR Replace_Pt[1];/*	0	Replacement part*/
RFC_CHAR Ind_Post_To_Insp_Stock[1];/*	0	Post to Inspection Stock*/
RFC_CHAR Ctrl_Key[8];/*	0	Control Key for Quality Management in Procurement*/
RFC_CHAR Doc_Reqd[1];/*	0	Documentation required indicator*/
RFC_CHAR Loadinggrp[4];/*	0	Loading group*/
RFC_CHAR Batch_Mgmt[1];/*	0	Batch management requirement indicator*/
RFC_CHAR Quotausage[1];/*	0	Quota arrangement usage*/
RFC_BCD Serv_Level[2];/*	1	Service level*/
RFC_CHAR Split_Ind[1];/*	0	Splitting Indicator*/
RFC_CHAR Availcheck[2];/*	0	Checking Group for Availability Check*/
RFC_CHAR Fy_Variant[2];/*	0	Fiscal Year Variant*/
RFC_CHAR Corr_Fact[1];/*	0	Indicator: take correction factors into account*/
RFC_BCD Setup_Time[3];/*	2	Shipping setup time*/
RFC_BCD Base_Qty_Plan[7];/*	3	Base quantity for capacity planning in shipping*/
RFC_BCD Ship_Proc_Time[3];/*	2	Shipping processing time*/
RFC_CHAR Sup_Source[1];/*	0	Source of Supply*/
RFC_CHAR Auto_P_Ord[1];/*	0	Indicator: "automatic purchase order allowed"*/
RFC_CHAR Sourcelist[1];/*	0	Indicator: Source list requirement*/
RFC_CHAR Comm_Code[17];/*	0	Commodity code / Import code number for foreign trade*/
RFC_CHAR Countryori[3];/*	0	Country of origin of the material*/
RFC_CHAR Countryori_Iso[2];/*	0	Material's country of origin in ISO code*/
RFC_CHAR Regionorig[3];/*	0	Region of origin of material (non-preferential origin)*/
RFC_CHAR Comm_Co_Un[3];/*	0	Unit of measure for commodity code (foreign trade)*/
RFC_CHAR Comm_Co_Un_Iso[3];/*	0	Unit of measure for commodity code (for. trade) in ISO code*/
RFC_CHAR Expimpgrp[4];/*	0	Export/import material group*/
RFC_CHAR Profit_Ctr[10];/*	0	Profit Center*/
RFC_CHAR Ppc_Pl_Cal[3];/*	0	PPC planning calendar*/
RFC_CHAR Rep_Manuf[1];/*	0	Ind.: Repetitive mfg allowed*/
RFC_NUM Pl_Ti_Fnce[3];/*	0	Planning time fence*/
RFC_CHAR Consummode[1];/*	0	Consumption mode*/
RFC_NUM Bwd_Cons[3];/*	0	Consumption period: backward*/
RFC_NUM Fwd_Cons[3];/*	0	Consumption period: forward*/
RFC_CHAR Alternative_Bom[2];/*	0	Alternative BOM*/
RFC_CHAR Bom_Usage[1];/*	0	BOM Usage*/
RFC_CHAR Planlistgrp[8];/*	0	Key for Task List Group*/
RFC_CHAR Planlistcnt[2];/*	0	Group Counter*/
RFC_BCD Lot_Size[7];/*	3	Lot Size for Product Costing*/
RFC_CHAR Specprocty[2];/*	0	Special Procurement Type for Costing*/
RFC_CHAR Prod_Unit[3];/*	0	Production unit*/
RFC_CHAR Prod_Unit_Iso[3];/*	0	Production Unit in ISO Code*/
RFC_CHAR Iss_St_Loc[4];/*	0	Issue Storage Location*/
RFC_CHAR Mrp_Group[4];/*	0	MRP Group*/
RFC_BCD Comp_Scrap[3];/*	2	Component scrap in percent*/
RFC_CHAR Cert_Type[4];/*	0	Certificate Type*/
RFC_BCD Cycle_Time[2];/*	0	Takt time*/
RFC_CHAR Covprofile[3];/*	0	Range of coverage profile*/
RFC_CHAR Cc_Ph_Inv[1];/*	0	Physical inventory indicator for cycle counting*/
RFC_CHAR Variance_Key[6];/*	0	Variance Key*/
RFC_CHAR Serno_Prof[4];/*	0	Serial Number Profile*/
RFC_CHAR Repmanprof[4];/*	0	Repetitive manufacturing profile*/
RFC_CHAR Neg_Stocks[1];/*	0	Negative stocks allowed in plant*/
RFC_CHAR Qm_Rgmts[4];/*	0	Required QM System for Vendor*/
RFC_CHAR Plng_Cycle[3];/*	0	Planning cycle*/
RFC_CHAR Round_Prof[4];/*	0	Rounding profile*/
RFC_CHAR Refmatcons[18];/*	0	Reference material for consumption*/
RFC_DATE D_To_Ref_M;/*	0	To date of the material to be copied for consumption*/
RFC_BCD Mult_Ref_M[3]	;/*2	Multiplier for reference material for consumption*/
RFC_CHAR Auto_Reset[1];/*	0	Reset Forecast Model Automatically*/
RFC_CHAR Ex_Cert_Id[1];/*	0	Exemption certificate: Indicator for legal control*/
RFC_CHAR Ex_Cert_No_New[8];/*	0	Exemption certificate number for legal control*/
RFC_DATE Ex_Cert_Dt;/*	0	Exemption certificate: Issue date of exemption certificate*/
RFC_CHAR Milit_Id[1];/*	0	Indicator: Military goods*/
RFC_BCD Insp_Int[3];/*	0	Interval until next recurring inspection*/
RFC_CHAR Co_Product[1];/*	0	Indicator: Material can be co-product*/
RFC_CHAR Plan_Strgp[2];/*	0	Planning strategy group*/
RFC_CHAR Sloc_Exprc[4];/*	0	Default storage location for external procurement*/
RFC_CHAR Bulk_Mat[1];/*	0	Indicator: bulk material*/
RFC_CHAR Cc_Fixed[1];/*	0	CC indicator is fixed*/
RFC_CHAR Determ_Grp[4];/*	0	Stock determination group*/
RFC_CHAR Qm_Authgrp[6];/*	0	Material Authorization Group for Activities in QM*/
RFC_CHAR Task_List_Type[1];/*	0	Task List Type*/
RFC_CHAR Pur_Status[2];/*	0	Plant-Specific Material Status*/
RFC_CHAR Prodprof[6];/*	0	Production Scheduling Profile*/
RFC_CHAR Safty_T_Id[1];/*	0	Safety time indicator (with or without safety time)*/
RFC_NUM Safetytime[2];/*	0	Safety time (in workdays)*/
RFC_CHAR Plord_Ctrl[2];/*	0	Action control: planned order processing*/
RFC_CHAR Batchentry[1];/*	0	Determination of batch entry in the production/process order*/
RFC_DATE Pvalidfrom;/*	0	Date from which the plant-specific material status is valid*/
RFC_CHAR Matfrgtgrp[8];/*	0	Material freight group*/
RFC_CHAR Prodverscs[4];/*	0	Production Version To Be Costed*/
RFC_CHAR Mat_Cfop[2];/*	0	Material CFOP category*/
RFC_CHAR Eu_List_No[12];/*	0	CAP: Number of CAP products list*/
RFC_CHAR Eu_Mat_Grp[6];/*	0	Common Agricultural Policy: CAP products group-Foreign Trade*/
RFC_CHAR Cas_No[15];/*	0	CAS number for pharmaceutical products in foreign trade*/
RFC_CHAR Prodcom_No[9];/*	0	Production statistics: PRODCOM number for foreign trade*/
RFC_CHAR Ctrl_Code[16];/*	0	Control code for consumption taxes in foreign trade*/
RFC_CHAR Jit_Relvt[1];/*	0	Indicator: Item relevant to JIT delivery schedules*/
RFC_CHAR Mat_Grp_Trans[20];/*	0	Group of Materials for Transition Matrix*/
RFC_CHAR Handlg_Grp[4];/*	0	Logistics handling group for workload calculation*/
RFC_CHAR Supply_Area[10];/*	0	Proposed Supply Area in Material Master Record*/
RFC_CHAR Fair_Share_Rule[2];/*	0	Fair share rule*/
RFC_CHAR Push_Distrib[1];/*	0	Indicator: push distribution*/
RFC_BCD Deploy_Horiz[2]	;/*0	Deployment horizon in days*/
RFC_BCD Min_Lot_Size[7];/*	3	Minimum lot size for Supply Demand Match*/
RFC_BCD Max_Lot_Size[7];/*	3	Maximum lot size for Supply Demand Match*/
RFC_BCD Fix_Lot_Size[7];/*	3	Fixed lot size for Supply Demand Match*/
RFC_BCD Lot_Increment[7];/*	3	Lot size increment for  Supply Demand Match*/
RFC_CHAR Prod_Conv_Type[2];/*	0	Conversion types for production figures*/
RFC_CHAR Distr_Prof[3];	/*0	Distribution profile of material in plant*/
RFC_CHAR Period_Profile_Safety_Time[3];/*	0	Period Profile for Safety Time*/
RFC_CHAR Fxd_Price[1];	/*0	Fixed-Price Co-Product*/
RFC_CHAR Avail_Check_All_Proj_Segments[1];/*	0	Indicator for cross-project material*/
RFC_CHAR Overallprf[6];	/*0	Overall profile for order change management*/
RFC_CHAR Mrp_Relevancy_Dep_Requirements[1];/*	0	MRP relevancy for dependent requirements*/
RFC_BCD Min_Safety_Stk[7];/*	3	Minimum Safety Stock*/
RFC_CHAR No_Costing[1];/*	0	Do Not Cost*/
RFC_CHAR Unit_Group[4];/*	0	Unit of measure group*/
RFC_CHAR Follow_Up_External[40];/*	0	Long Material Number for FOLLOW_UP Field*/
RFC_CHAR Follow_Up_Guid[32];/*	0	External GUID for FOLLOW_UP Field*/
RFC_CHAR Follow_Up_Version[10];/*	0	Version Number for FOLLOW_UP Field*/
RFC_CHAR Refmatcons_External[40];/*	0	Long Material Number for REFMATCONS Field*/
RFC_CHAR Refmatcons_Guid[32];/*	0	External GUID for REFMATCONS Field*/
RFC_CHAR Refmatcons_Version[10];	/*0	Version Number for REFMATCONS Field*/
RFC_CHAR Rotation_Date[1];/*	0*/
RFC_CHAR Original_Batch_Flag[1];/*	0	Indicator for Original Batch Management*/
RFC_CHAR Original_Batch_Ref_Material[18];/*	0	Reference Material for Original Batches*/
RFC_CHAR Original_Batch_Ref_Material_E[40];	/*0	Reference Material for Original Batches*/
RFC_CHAR Original_Batch_Ref_Material_V[10];	/*0	Reference Material for Original Batches*/
RFC_CHAR Original_Batch_Ref_Material_G[32];	/*0	Reference Material for Original Batches*/
}BAPI_MARC;
#endif

#ifndef SAP_TH_BAPI_MARC
#define SAP_TH_BAPI_MARC
static const RFC_TYPEHANDLE handleOfBAPI_MARC;
static const RFC_TYPE_ELEMENT typeOfBAPI_MARC[]=
{
	{"PLANT",	TYPC,	4,	0},
	{"DEL_FLAG",TYPC	,1,	0},
	{"ABC_ID",	TYPC	,1,	0},
	{"CRIT_PART",TYPC	,1,	0},
	{"PUR_GROUP",TYPC	,3,	0},
	{"ISSUE_UNIT",TYPC	,3,	0},
	{"ISSUE_UNIT_ISO",TYPC	,3,	0},
	{"MRPPROFILE",TYPC	,4,	0},
	{"MRP_TYPE",TYPC	,2,	0},
	{"MRP_CTRLER",TYPC	,3,	0},
	{"PLND_DELRY",	TYPP	,2,	0},
	{"GR_PR_TIME",	TYPP	,2,	0},
	{"PERIOD_IND",	TYPC	,1,	0},
	{"ASSY_SCRAP",	TYPP	,3,	0},
	{"LOTSIZEKEY",	TYPC	,2,	0},
	{"PROC_TYPE",	TYPC	,1,	0},
	{"SPPROCTYPE",TYPC	,2,	0},
	{"REORDER_PT",TYPP	,7,	0},
	{"SAFETY_STK",TYPP	,7,	0},
	{"MINLOTSIZE",TYPP	,7,	0},
	{"MAXLOTSIZE",TYPP	,7,	0},
	{"FIXED_LOT",TYPP	,7,	0},
	{"ROUND_VAL",TYPP	,7,	0},
	{"MAX_STOCK",TYPP	,7,	0},
	{"ORD_COSTS",TYPP	,12,	0},
	{"DEP_REQ_ID",TYPC	,1,	0},
	{"STOR_COSTS",TYPC	,1,	0},
	{"ALT_BOM_ID",TYPC	,1,	0},
	{"DISCONTINU",TYPC	,1,	0},
	{"EFF_O_DAY",TYPDATE	,sizeof(RFC_DATE),	0},
	{"FOLLOW_UP",TYPC	,18,	0},
	{"GRP_REQMTS",TYPC	,1,	0},
	{"MIXED_MRP",TYPC	,1,	0},
	{"SM_KEY",TYPC	,3,	0},
	{"BACKFLUSH",TYPC	,1,	0},
	{"PRODUCTION_SCHEDULER",TYPC	,3,	0},
	{"PROC_TIME",	TYPP	,3,	0},
	{"SETUPTIME",	TYPP	,3,	0},
	{"INTEROP",	TYPP	,3,	0},
	{"BASE_QTY",TYPP	,7,	0},
	{"INHSEPRODT",TYPP	,2,	0},
	{"STGEPERIOD",TYPP	,3,	0},
	{"STGE_PD_UN",TYPC	,3,	0},
	{"STGE_PD_UN_ISO",TYPC	,3,	0},
	{"OVER_TOL",	TYPP	,2,	0},
	{"UNLIMITED",	TYPC	,1,	0},
	{"UNDER_TOL",	TYPP	,2,	0},
	{"REPLENTIME",TYPP	,2,	0},
	{"REPLACE_PT",TYPC	,1,	0},
	{"IND_POST_TO_INSP_STOCK",TYPC	,1,	0},
	{"CTRL_KEY",TYPC	,8,	0},
	{"DOC_REQD",TYPC	,1,	0},
	{"LOADINGGRP",TYPC	,4,	0},
	{"BATCH_MGMT",TYPC	,1,	0},
	{"QUOTAUSAGE",TYPC	,1,	0},
	{"SERV_LEVEL",TYPP	,2,	0},
	{"SPLIT_IND",	TYPC	,1,	0},
	{"AVAILCHECK",TYPC	,2,	0},
	{"FY_VARIANT",TYPC	,2,	0},
	{"CORR_FACT",	TYPC	,1,	0},
	{"SETUP_TIME",TYPP	,3,	0},
	{"BASE_QTY_PLAN",TYPP	,7,	0},
	{"SHIP_PROC_TIME",TYPP	,3,	2},
	{"SUP_SOURCE",TYPC	,1,	0},
	{"AUTO_P_ORD",TYPC	,1,	0},
	{"SOURCELIST",TYPC	,1,	0},
	{"COMM_CODE",TYPC	,17,	0},
	{"COUNTRYORI",TYPC	,3,	0},
	{"COUNTRYORI_ISO",TYPC	,2,	0},
	{"REGIONORIG",TYPC	,3,	0},
	{"COMM_CO_UN",TYPC	,3,	0},
	{"COMM_CO_UN_ISO",TYPC	,3,	0},
	{"EXPIMPGRP",	TYPC	,4,	0},
	{"PROFIT_CTR",TYPC	,10,	0},
	{"PPC_PL_CAL",TYPC	,3,	0},
	{"REP_MANUF",TYPC	,1,	0},
	{"PL_TI_FNCE",TYPNUM	,3,	0},
	{"CONSUMMODE",TYPC	,1,	0},
	{"BWD_CONS",TYPNUM	,3,	0},
	{"FWD_CONS",TYPNUM	,3,	0},
	{"ALTERNATIVE_BOM",TYPC	,2,	0},
	{"BOM_USAGE",	TYPC	,1,	0},
	{"PLANLISTGRP",TYPC	,8,	0},
	{"PLANLISTCNT",TYPC	,2,	0},
	{"LOT_SIZE",TYPP	,7,	0},
	{"SPECPROCTY",TYPC	,2,	0},
	{"PROD_UNIT",TYPC	,3,	0},
	{"PROD_UNIT_ISO",TYPC	,3,	0},
	{"ISS_ST_LOC",TYPC	,4,	0},
	{"MRP_GROUP",TYPC	,4,	0},
	{"COMP_SCRAP",TYPP	,3,	0},
	{"CERT_TYPE",TYPC	,4,	0},
	{"CYCLE_TIME",TYPP	,2,	0},
	{"COVPROFILE",TYPC	,3,	0},
	{"CC_PH_INV",TYPC	,1,	0},
	{"VARIANCE_KEY",TYPC	,6,	0},
	{"SERNO_PROF",TYPC	,4,	0},
	{"REPMANPROF",TYPC	,4,	0},
	{"NEG_STOCKS",TYPC	,1,	0},
	{"QM_RGMTS",TYPC	,4,	0},
	{"PLNG_CYCLE",TYPC	,3,	0},
	{"ROUND_PROF",TYPC	,4,	0},
	{"REFMATCONS",TYPC	,18,	0},
	{"D_TO_REF_M",TYPDATE	,sizeof(RFC_DATE),	0},
	{"MULT_REF_M",TYPP	,3,	0},
	{"AUTO_RESET",TYPC	,1,	0},
	{"EX_CERT_ID",TYPC	,1,	0},
	{"EX_CERT_NO_NEW",TYPC	,8,	0},
	{"EX_CERT_DT",TYPDATE	,sizeof(RFC_DATE),	0},
	{"MILIT_ID",TYPC	,1,	0},
	{"INSP_INT",TYPP	,3,	0},
	{"CO_PRODUCT",TYPC	,1,	0},
	{"PLAN_STRGP",TYPC	,2,	0},
	{"SLOC_EXPRC",TYPC	,4,	0},
	{"BULK_MAT",TYPC	,1,	0},
	{"CC_FIXED",TYPC	,1,	0},
	{"DETERM_GRP",TYPC	,4,	0},
	{"QM_AUTHGRP",TYPC	,6,	0},
	{"TASK_LIST_TYPE",TYPC	,1,	0},
	{"PUR_STATUS",TYPC	,2,	0},
	{"PRODPROF",TYPC	,6,	0},
	{"SAFTY_T_ID",TYPC	,1,	0},
	{"SAFETYTIME",TYPNUM	,2,	0},
	{"PLORD_CTRL",TYPC	,2,	0},
	{"BATCHENTRY",TYPC	,1,	0},
	{"PVALIDFROM",TYPDATE	,sizeof(RFC_DATE),	0},
	{"MATFRGTGRP",TYPC	,8,	0},
	{"PRODVERSCS",TYPC	,4,	0},
	{"MAT_CFOP",TYPC	,2,	0},
	{"EU_LIST_NO",TYPC	,12,	0},
	{"EU_MAT_GRP",TYPC	,6,	0},
	{"CAS_NO",TYPC	,15,	0},
	{"PRODCOM_NO",TYPC	,9,	0},
	{"CTRL_CODE",TYPC	,16,	0},
	{"JIT_RELVT",TYPC	,1,	0},
	{"MAT_GRP_TRANS",TYPC	,20,	0},
	{"HANDLG_GRP",TYPC	,4,	0},
	{"SUPPLY_AREA",TYPC	,10,	0},
	{"FAIR_SHARE_RULE",	TYPC	,2,	0},
	{"PUSH_DISTRIB",TYPC	,1,	0},
	{"DEPLOY_HORIZ",TYPP	,2,	0},
	{"MIN_LOT_SIZE",TYPP	,7,	0},
	{"MAX_LOT_SIZE",TYPP	,7,	0},
	{"FIX_LOT_SIZE",TYPP	,7,	0},
	{"LOT_INCREMENT",TYPP	,7,	0},
	{"PROD_CONV_TYPE",TYPC	,2,	0},
	{"DISTR_PROF",TYPC	,3,	0},
	{"PERIOD_PROFILE_SAFETY_TIME",TYPC	,3,	0},
	{"FXD_PRICE	CK_FIXPRKU",TYPC	,1,	0},
	{"AVAIL_CHECK_ALL_PROJ_SEGMENTS",TYPC	,1,	0},
	{"OVERALLPRF",	TYPC	,6,	0},
	{"MRP_RELEVANCY_DEP_REQUIREMENTS",TYPC	,1,	0},
	{"MIN_SAFETY_STK",TYPP	,7,	0},
	{"NO_COSTING",TYPC	,1,	0},
	{"UNIT_GROUP",TYPC	,4,	0},
	{"FOLLOW_UP_EXTERNAL",TYPC	,40,	0},
	{"FOLLOW_UP_GUID",TYPC	,32,	0},
	{"FOLLOW_UP_VERSION",TYPC	,10,	0},
	{"REFMATCONS_EXTERNAL",TYPC	,40,	0},
	{"REFMATCONS_GUID",TYPC	,32,	0},
	{"REFMATCONS_VERSION",TYPC	,10,	0},
	{"ROTATION_DATE	ROTATION_DATE",	TYPC	,1,	0},
	{"ORIGINAL_BATCH_FLAG",TYPC	,1,	0},
	{"ORIGINAL_BATCH_REF_MATERIAL",TYPC	,18,	0},
	{"ORIGINAL_BATCH_REF_MATERIAL_E",TYPC	,40,	0},
	{"ORIGINAL_BATCH_REF_MATERIAL_V",TYPC	,10,	0},
	{"ORIGINAL_BATCH_REF_MATERIAL_G",TYPC	,32,	0},
};
#endif
/*--------------------End BAPI_MARC-------------------*/
/*--------------------BAPI_MARCX-------------------*/
#ifndef SAP_ST_BAPI_MARCX
#define SAP_ST_BAPI_MARCX
typedef struct
{
RFC_CHAR Plant[4];
RFC_CHAR Del_Flag[1];
RFC_CHAR Abc_Id[1];
RFC_CHAR Crit_Part[1];
RFC_CHAR Pur_Group[1];
RFC_CHAR Issue_Unit[1];
RFC_CHAR Issue_Unit_Iso[1];
RFC_CHAR Mrpprofile[1];
RFC_CHAR Mrp_Type[1];
RFC_CHAR Mrp_Ctrler[1];
RFC_CHAR Plnd_Delry[1];
RFC_CHAR Gr_Pr_Time[1];
RFC_CHAR Period_Ind[1];
RFC_CHAR Assy_Scrap[1];
RFC_CHAR Lotsizekey[1];
RFC_CHAR Proc_Type[1];
RFC_CHAR Spproctype[1];
RFC_CHAR Reorder_Pt[1];
RFC_CHAR Safety_Stk[1];
RFC_CHAR Minlotsize[1];
RFC_CHAR Maxlotsize[1];
RFC_CHAR Fixed_Lot[1];
RFC_CHAR Round_Val[1];
RFC_CHAR Max_Stock[1];
RFC_CHAR Ord_Costs[1];
RFC_CHAR Dep_Req_Id[1];
RFC_CHAR Stor_Costs[1];
RFC_CHAR Alt_Bom_Id[1];
RFC_CHAR Discontinu[1];
RFC_CHAR Eff_O_Day[1];
RFC_CHAR Follow_Up[1];
RFC_CHAR Grp_Reqmts[1];
RFC_CHAR Mixed_Mrp[1];
RFC_CHAR Sm_Key[1];
RFC_CHAR Backflush[1];
RFC_CHAR Production_Scheduler[1];
RFC_CHAR Proc_Time[1];
RFC_CHAR Setuptime[1];
RFC_CHAR Interop[1];
RFC_CHAR Base_Qty[1];
RFC_CHAR Inhseprodt[1];
RFC_CHAR Stgeperiod[1];
RFC_CHAR Stge_Pd_Un[1];
RFC_CHAR Stge_Pd_Un_Iso[1];
RFC_CHAR Over_Tol[1];
RFC_CHAR Unlimited[1];
RFC_CHAR Under_Tol[1];
RFC_CHAR Replentime[1];
RFC_CHAR Replace_Pt[1];
RFC_CHAR Ind_Post_To_Insp_Stock[1];
RFC_CHAR Ctrl_Key[1];
RFC_CHAR Doc_Reqd[1];
RFC_CHAR Loadinggrp[1];
RFC_CHAR Batch_Mgmt[1];
RFC_CHAR Quotausage[1];
RFC_CHAR Serv_Level[1];
RFC_CHAR Split_Ind[1];
RFC_CHAR Availcheck[1];
RFC_CHAR Fy_Variant[1];
RFC_CHAR Corr_Fact[1];
RFC_CHAR Setup_Time[1];
RFC_CHAR Base_Qty_Plan[1];
RFC_CHAR Ship_Proc_Time[1];
RFC_CHAR Sup_Source[1];
RFC_CHAR Auto_P_Ord[1];
RFC_CHAR Sourcelist[1];
RFC_CHAR Comm_Code[1];
RFC_CHAR Countryori[1];
RFC_CHAR Countryori_Iso[1];
RFC_CHAR Regionorig[1];
RFC_CHAR Comm_Co_Un[1];
RFC_CHAR Comm_Co_Un_Iso[1];
RFC_CHAR Expimpgrp[1];
RFC_CHAR Profit_Ctr[1];
RFC_CHAR Ppc_Pl_Cal[1];
RFC_CHAR Rep_Manuf[1];
RFC_CHAR Pl_Ti_Fncve[1];
RFC_CHAR Consummode[1];
RFC_CHAR Bwd_Cons[1];
RFC_CHAR Fwd_Cons[1];
RFC_CHAR Alternative_Bom[1];
RFC_CHAR Bom_Usage[1];
RFC_CHAR Planlistgrp[1];
RFC_CHAR Planlistcnt[1];
RFC_CHAR Lot_Size[1];
RFC_CHAR Specprocty[1];
RFC_CHAR Prod_Unit[1];
RFC_CHAR Prod_Unit_Iso[1];
RFC_CHAR Iss_St_Loc[1];
RFC_CHAR Mrp_Group[1];
RFC_CHAR Comp_Scrap[1];
RFC_CHAR Cert_Type[1];
RFC_CHAR Cycle_Time[1];
RFC_CHAR Covprofile[1];
RFC_CHAR Cc_Ph_Inv[1];
RFC_CHAR Variance_Key[1];
RFC_CHAR Serno_Prof[1];
RFC_CHAR Repmanprof[1];
RFC_CHAR Neg_Stocks[1];
RFC_CHAR Qm_Rgmts[1];
RFC_CHAR Plng_Cycle[1];
RFC_CHAR Round_Prof[1];
RFC_CHAR Refmatcons[1];
RFC_CHAR D_To_Ref_M[1];
RFC_CHAR Mult_Ref_M[1];
RFC_CHAR Auto_Reset[1];
RFC_CHAR Ex_Cert_Id[1];
RFC_CHAR Ex_Cert_No_New[1];
RFC_CHAR Ex_Cert_Dt[1];
RFC_CHAR Milit_Id[1];
RFC_CHAR Insp_Int[1];
RFC_CHAR Co_Product[1];
RFC_CHAR Plan_Strgp[1];
RFC_CHAR Sloc_Exprc[1];
RFC_CHAR Bulk_Mat[1];
RFC_CHAR Cc_Fixed[1];
RFC_CHAR Determ_Grp[1];
RFC_CHAR Qm_Authgrp[1];
RFC_CHAR Task_List_Type[1];
RFC_CHAR Pur_Status[1];
RFC_CHAR Prodprof[1];
RFC_CHAR Safty_T_Id[1];
RFC_CHAR Safetytime[1];
RFC_CHAR Plord_Ctrl[1];
RFC_CHAR Batchentry[1];
RFC_CHAR Pvalidfrom[1];
RFC_CHAR Matfrgtgrp[1];
RFC_CHAR Prodverscs[1];
RFC_CHAR Mat_Cfop[1];
RFC_CHAR Eu_List_No[1];
RFC_CHAR Eu_Mat_Grp[1];
RFC_CHAR Cas_No[1];
RFC_CHAR Prodcom_No[1];
RFC_CHAR Ctrl_Code[1];
RFC_CHAR Jit_Relvt[1];
RFC_CHAR Mat_Grp_Trans[1];
RFC_CHAR Handlg_Grp[1];
RFC_CHAR Supply_Area[1];
RFC_CHAR Fair_Share_Rule[1];
RFC_CHAR Push_Distrib[1];
RFC_CHAR Deploy_Horiz[1];
RFC_CHAR Min_Lot_Size[1];
RFC_CHAR Max_Lot_Size[1];
RFC_CHAR Fix_Lot_Size[1];
RFC_CHAR Lot_Increment[1];
RFC_CHAR Prod_Conv_Type[1];
RFC_CHAR Distr_Prof[1];
RFC_CHAR Period_Profile_Safety_Time[1];
RFC_CHAR Fxd_Price[1];
RFC_CHAR Avail_Check_All_Proj_Segments[1];
RFC_CHAR Overallprf[1];
RFC_CHAR Mrp_Relevancy_Dep_Requirements[1];
RFC_CHAR Min_Safety_Stk[1];
RFC_CHAR No_Costing[1];
RFC_CHAR Unit_Group[1];
RFC_CHAR Follow_Up_External[1];
RFC_CHAR Follow_Up_Guid[1];
RFC_CHAR Follow_Up_Version[1];
RFC_CHAR Refmatcons_External[1];
RFC_CHAR Refmatcons_Guid[1];
RFC_CHAR Refmatcons_Version[1];
RFC_CHAR Rotation_Date[1];
RFC_CHAR Original_Batch_Flag[1];
RFC_CHAR Original_Batch_Ref_Material[1];
RFC_CHAR Original_Batch_Ref_Material_E[1];
RFC_CHAR Original_Batch_Ref_Material_V[1];
RFC_CHAR Original_Batch_Ref_Material_G[1];
}BAPI_MARCX;
#endif
#ifndef SAP_TH_BAPI_MARCX
#define SAP_TH_BAPI_MARCX
static const RFC_TYPEHANDLE handleOfBAPI_MARCX;
static const RFC_TYPE_ELEMENT typeOfBAPI_MARCX[]=
{
	{"PLANT",TYPC,4,	0},
	{"DEL_FLAG",TYPC,1,	0},
	{"ABC_ID",TYPC,	1,	0},
	{"CRIT_PART",TYPC,	1,	0},
	{"PUR_GROUP",TYPC,	1,	0},
	{"ISSUE_UNIT",TYPC,	1,	0},
	{"ISSUE_UNIT_ISO",TYPC,	1,	0},
	{"MRPPROFILE",TYPC,	1,	0},
	{"MRP_TYPE",TYPC,	1,	0},
	{"MRP_CTRLER",TYPC,	1,	0},
	{"PLND_DELRY",TYPC,	1,	0},
	{"GR_PR_TIME",TYPC,	1,	0},
	{"PERIOD_IND",TYPC,	1,	0},
	{"ASSY_SCRAP",TYPC,	1,	0},
	{"LOTSIZEKEY",TYPC,	1,	0},
	{"PROC_TYPE	",TYPC,	1,	0},
	{"SPPROCTYPE",TYPC,	1,	0},
	{"REORDER_PT",TYPC,	1,	0},
	{"SAFETY_STK",TYPC,	1,	0},
	{"MINLOTSIZE",TYPC,	1,	0},
	{"MAXLOTSIZE",TYPC,	1,	0},
	{"FIXED_LOT",TYPC,	1,	0},
	{"ROUND_VAL",TYPC,	1,	0},
	{"MAX_STOCK",TYPC,	1,	0},
	{"ORD_COSTS",TYPC,	1,	0},
	{"DEP_REQ_ID",TYPC,	1,	0},
	{"STOR_COSTS",TYPC,	1,	0},
	{"ALT_BOM_ID",TYPC,	1,	0},
	{"DISCONTINU",TYPC,	1,	0},
	{"EFF_O_DAY",TYPC,	1,	0},
	{"FOLLOW_UP",TYPC,	1,	0},
	{"GRP_REQMTS",TYPC,	1,	0},
	{"MIXED_MRP",TYPC,	1,	0},
	{"SM_KEY",TYPC,	1,	0},
	{"BACKFLUSH",TYPC,	1,	0},
	{"PRODUCTION_SCHEDULER",TYPC,	1,	0},
	{"PROC_TIME",TYPC,	1,	0},
	{"SETUPTIME",TYPC,	1	,0},
	{"INTEROP",TYPC,	1,	0},
	{"BASE_QTY",TYPC,	1,	0},
	{"INHSEPRODT",TYPC,	1,	0},
	{"STGEPERIOD",TYPC,	1,	0},
	{"STGE_PD_UN",TYPC,	1	,0},
	{"STGE_PD_UN_ISO",TYPC,	1,	0},
	{"OVER_TOL",TYPC,	1,	0},
	{"UNLIMITED",TYPC,	1,	0},
	{"UNDER_TOL",TYPC,	1,	0},
	{"REPLENTIME",TYPC,	1,	0},
	{"REPLACE_PT",TYPC,	1	,0},
	{"IND_POST_TO_INSP_STOCK",TYPC,	1,	0},
	{"CTRL_KEY",TYPC,	1,	0},
	{"DOC_REQD",TYPC,	1,	0},
	{"LOADINGGRP",TYPC,	1,	0},
	{"BATCH_MGMT",TYPC,	1,	0},
	{"QUOTAUSAGE",TYPC,	1,	0},
	{"SERV_LEVEL",TYPC,	1,	0},
	{"SPLIT_IND",TYPC,	1,	0},
	{"AVAILCHECK",TYPC,	1,	0},
	{"FY_VARIANT",TYPC,	1,	0},
	{"CORR_FACT",TYPC,	1,	0},
	{"SETUP_TIME",TYPC,	1,	0},
	{"BASE_QTY_PLAN",TYPC,	1,	0},
	{"SHIP_PROC_TIME",TYPC,	1,	0},
	{"SUP_SOURCE",TYPC,	1,	0},
	{"AUTO_P_ORD",TYPC,	1,0},
	{"SOURCELIST",TYPC,	1,	0},
	{"COMM_CODE",TYPC,	1,	0},
	{"COUNTRYORI",TYPC,	1,	0},
	{"COUNTRYORI_ISO",TYPC,	1,	0},
	{"REGIONORIG",TYPC,	1,	0},
	{"COMM_CO_UN",TYPC,	1,	0},
	{"COMM_CO_UN_ISO",TYPC,	1,	0},
	{"EXPIMPGRP",TYPC,	1,	0},
	{"PROFIT_CTR",TYPC,	1,	0},
	{"PPC_PL_CAL",TYPC,	1,	0},
	{"REP_MANUF",TYPC,	1,	0},
	{"PL_TI_FNCE",TYPC,	1,	0},
	{"CONSUMMODE",TYPC,	1,	0},
	{"BWD_CONS",TYPC,	1,	0},
	{"FWD_CONS",TYPC,	1,	0},
	{"ALTERNATIVE_BOM",TYPC,	1,	0},
	{"BOM_USAGE",TYPC,	1,	0},
	{"PLANLISTGRP",TYPC,	1,	0},
	{"PLANLISTCNT",TYPC,	1,	0},
	{"LOT_SIZE",TYPC,	1,	0},
	{"SPECPROCTY",TYPC,	1,	0},
	{"PROD_UNIT",TYPC,	1,	0},
	{"PROD_UNIT_ISO",TYPC,	1,	0},
	{"ISS_ST_LOC",TYPC,	1,	0},
	{"MRP_GROUP",TYPC,	1,	0},
	{"COMP_SCRAP",TYPC,	1,	0},
	{"CERT_TYPE",TYPC,	1,	0},
	{"CYCLE_TIME",TYPC,	1,	0},
	{"COVPROFILE",TYPC,	1,	0},
	{"CC_PH_INV",TYPC,	1,	0},
	{"VARIANCE_KEY",TYPC,	1,	0},
	{"SERNO_PROF",TYPC,	1,	0},
	{"REPMANPROF",TYPC,	1,	0},
	{"NEG_STOCKS",TYPC,	1,	0},
	{"QM_RGMTS",TYPC,	1,	0},
	{"PLNG_CYCLE",TYPC,	1,	0},
	{"ROUND_PROF",TYPC,	1,	0},
	{"REFMATCONS",TYPC,	1,	0},
	{"D_TO_REF_M",TYPC,	1,	0},
	{"MULT_REF_M",TYPC,	1,	0},
	{"AUTO_RESET",TYPC,	1,	0},
	{"EX_CERT_ID",TYPC,	1,	0},
	{"EX_CERT_NO_NEW",TYPC,	1,	0},
	{"EX_CERT_DT",TYPC,	1,	0},
	{"MILIT_ID",TYPC,	1,	0},
	{"INSP_INT",TYPC,	1,	0},
	{"CO_PRODUCT",TYPC,	1,	0},
	{"PLAN_STRGP",TYPC,	1,	0},
	{"SLOC_EXPRC",TYPC,	1,	0},
	{"BULK_MAT",TYPC,	1,	0},
	{"CC_FIXED",TYPC,	1,	0},
	{"DETERM_GRP",TYPC,	1,	0},
	{"QM_AUTHGRP",TYPC,	1,	0},
	{"TASK_LIST_TYPE",TYPC,	1,	0},
	{"PUR_STATUS",TYPC,	1,	0},
	{"PRODPROF",TYPC,	1,	0},
	{"SAFTY_T_ID",TYPC,	1,	0},
	{"SAFETYTIME",TYPC,	1,	0},
	{"PLORD_CTRL",TYPC,	1,	0},
	{"BATCHENTRY",TYPC,	1,	0},
	{"PVALIDFROM",TYPC,	1,	0},
	{"MATFRGTGRP",TYPC,	1,	0},
	{"PRODVERSCS",TYPC,	1,	0},
	{"MAT_CFOP",TYPC,	1,	0},
	{"EU_LIST_NO",TYPC,	1,	0},
	{"EU_MAT_GRP",TYPC,	1,	0},
	{"CAS_NO",TYPC,	1,	0},
	{"PRODCOM_NO",TYPC,	1,	0},
	{"CTRL_CODE",TYPC,	1,	0},
	{"JIT_RELVT",TYPC,	1,	0},
	{"MAT_GRP_TRANS",TYPC,	1,	0},
	{"HANDLG_GRP",TYPC,	1,	0},
	{"SUPPLY_AREA",TYPC,	1,	0},
	{"FAIR_SHARE_RULE",TYPC,	1,	0},
	{"PUSH_DISTRIB",TYPC,	1,	0},
	{"DEPLOY_HORIZ",TYPC,	1,	0},
	{"MIN_LOT_SIZE",TYPC,	1,	0},
	{"MAX_LOT_SIZE",TYPC,	1,	0},
	{"FIX_LOT_SIZE",TYPC,	1,	0},
	{"LOT_INCREMENT",TYPC,	1,	0},
	{"PROD_CONV_TYPE",TYPC,	1,	0},
	{"DISTR_PROF",TYPC,	1,	0},
	{"PERIOD_PROFILE_SAFETY_TIME",TYPC,	1,	0},
	{"FXD_PRICE",TYPC,	1,	0},
	{"AVAIL_CHECK_ALL_PROJ_SEGMENTS",TYPC,	1,	0},
	{"OVERALLPRF",TYPC,	1,	0},
	{"MRP_RELEVANCY_DEP_REQUIREMENTS",TYPC,	1,	0},
	{"MIN_SAFETY_STK",TYPC,	1,	0},
	{"NO_COSTING",TYPC,	1,	0},
	{"UNIT_GROUP",TYPC,	1,	0},
	{"FOLLOW_UP_EXTERNAL",TYPC,	1,	0},
	{"FOLLOW_UP_GUID",TYPC,	1,	0},
	{"FOLLOW_UP_VERSION",TYPC,	1,	0},
	{"REFMATCONS_EXTERNAL",TYPC,	1,	0},
	{"REFMATCONS_GUID",TYPC,	1,	0},
	{"REFMATCONS_VERSION",TYPC,	1,	0},
	{"ROTATION_DATE",TYPC,	1,	0},
	{"ORIGINAL_BATCH_FLAG",TYPC,	1,	0},
	{"ORIGINAL_BATCH_REF_MATERIAL",TYPC,	1,	0},
	{"ORIGINAL_BATCH_REF_MATERIAL_E",TYPC,	1,	0},
	{"ORIGINAL_BATCH_REF_MATERIAL_V",TYPC,	1,	0},
	{"ORIGINAL_BATCH_REF_MATERIAL_G",TYPC,	1,	0},
};
#endif
/*--------------------BAPI_MARCX-------------------*/
/*--------------------BAPI_MPOP-------------------*/
#ifndef SAP_ST_BAPI_MPOP
#define SAP_ST_BAPI_MPOP
typedef struct
{
RFC_CHAR Plant[4];		/*Plant*/
RFC_CHAR Fore_Prof[4];		/*Forecast profile*/
RFC_CHAR Model_Si[1];		/*Model selection indicator*/
RFC_CHAR Model_Sp[1];		/*Model selection procedure*/
RFC_CHAR Param_Opt[1];		/*Indicator for parameter optimization*/
RFC_CHAR Optim_Lev[1];		/*Optimization level*/
RFC_CHAR Initialize[1];		/*Initialization indicator*/
RFC_CHAR Fore_Model[1];		/*Forecast model*/
RFC_BCD Alpha_Fact[2];			/*2Basic value smoothing using alpha factor*/
RFC_BCD Beta_Fact[2];			/*2Trend value smoothing using the beta factor*/
RFC_BCD Gamma_Fact[2];			/*2Seasonal index smoothing using gamma factor*/
RFC_BCD Delta_Fact[2];			/*2MAD (mean absolute deviation) smoothing using delta factor*/
RFC_BCD Tracklimit[3];			/*3Tracking limit*/
RFC_DATE Fore_Date;		/*Date of last forecast*/
RFC_BCD Hist_Vals[2];			/*Number of historical periods*/
RFC_BCD Init_Pds[2];			/*Number of periods for initialization*/
RFC_BCD Season_Pds[2];		/*Number of periods per seasonal cycle*/
RFC_BCD Expost_Pds[2];			/*Number of periods for ex-post forecasting*/
RFC_BCD Fore_Pds[2];			/*Number of forecast periods*/
RFC_BCD Fixed_Pds[2];			/*Fixed periods*/
RFC_CHAR Wtg_Group[2];		/*Weighting group*/
}BAPI_MPOP;
#endif
#ifndef SAP_TH_BAPI_MPOP
#define SAP_TH_BAPI_MPOP
static const RFC_TYPEHANDLE handleOfBAPI_MPOP;
static const RFC_TYPE_ELEMENT typeOfBAPI_MPOP[]=
{
	{"PLANT",		TYPC,	 4,	0},
	{"FORE_PROF",	TYPC,	 4,	0},
	{"MODEL_SI",	TYPC,	 1,	0},
	{"MODEL_SP",	TYPC,	 1,	0},
	{"PARAM_OPT",	TYPC,	 1,	0},
	{"OPTIM_LEV",	TYPC,	 1,	0},
	{"INITIALIZE",	TYPC,	 1,	0},
	{"FORE_MODEL",	TYPC,	 1,	0},
	{"ALPHA_FACT",	TYPP,2,	0},
	{"BETA_FACT",	TYPP,2,	0},
	{"GAMMA_FACT",	TYPP,2,	0},
	{"DELTA_FACT",	TYPP,2,	0},
	{"TRACKLIMIT",	TYPP,3,	0},
	{"FORE_DATE",	TYPDATE, sizeof(RFC_DATE),	0},
	{"HIST_VALS",	TYPP,2,	0},
	{"INIT_PDS",	TYPP,3,	0},
	{"SEASON_PDS",	TYPP,2,	0},
	{"EXPOST_PDS",	TYPP,2,	0},
	{"FORE_PDS",	TYPP,2,	0},
	{"FIXED_PDS",	TYPP,2,	0},
	{"WTG_GROUP",	TYPC,    2,	0},
};
#endif
/*--------------------End BAPI_MPOP-------------------*/
/*--------------------BAPI_MPOPX-------------------*/
#ifndef SAP_ST_BAPI_MPOPX
#define SAP_ST_BAPI_MPOPX
typedef struct
{
RFC_CHAR Plant[4];
RFC_CHAR Fore_Prof[1];
RFC_CHAR Model_Si[1];
RFC_CHAR Model_Sp[1];
RFC_CHAR Param_Opt[1];
RFC_CHAR Optim_Lev[1];
RFC_CHAR Initialize[1];
RFC_CHAR Fore_Model[1];
RFC_CHAR Alpha_Fact[1];
RFC_CHAR Beta_Fact[1];
RFC_CHAR Gamma_Fact[1];
RFC_CHAR Delta_Fact[1];
RFC_CHAR Tracklimit[1];
RFC_CHAR Fore_Date[1];
RFC_CHAR Hist_Vals[1];
RFC_CHAR Init_Pds[1];
RFC_CHAR Season_Pds[1];
RFC_CHAR Expost_Pds[1];
RFC_CHAR Fore_Pds[1];
RFC_CHAR Fixed_Pds[1];
RFC_CHAR Wtg_Group[1];
}BAPI_MPOPX;
#endif

#ifndef SAP_TH_BAPI_MPOPX
#define SAP_TH_BAPI_MPOPX
static const RFC_TYPEHANDLE handleOfBAPI_MPOPX;
static const RFC_TYPE_ELEMENT typeOfBAPI_MPOPX[]=
{
	{"PLANT"			,TYPC,	4	,0},
	{"FORE_PROF"		,TYPC,	1	,0},
	{"MODEL_SI"			,TYPC,	1	,0},
	{"MODEL_SP"			,TYPC,	1	,0},
	{"PARAM_OPT"		,TYPC,	1	,0},
	{"OPTIM_LEV"		,TYPC,	1	,0},
	{"INITIALIZE"		,TYPC,	1	,0},
	{"FORE_MODEL"		,TYPC,	1	,0},
	{"ALPHA_FACT"		,TYPC,	1	,0},
	{"BETA_FACT"		,TYPC,	1	,0},
	{"GAMMA_FACT"		,TYPC,	1	,0},
	{"DELTA_FACT"		,TYPC,	1	,0},
	{"TRACKLIMIT"		,TYPC,	1	,0},
	{"FORE_DATE"		,TYPC,	1	,0},
	{"HIST_VALS"		,TYPC,	1	,0},
	{"INIT_PDS"			,TYPC,	1	,0},
	{"SEASON_PDS"		,TYPC,	1	,0},
	{"EXPOST_PDS"		,TYPC,	1	,0},
	{"FORE_PDS"			,TYPC,	1	,0},
	{"FIXED_PDS"		,TYPC,	1	,0},
	{"WTG_GROUP"		,TYPC,	1	,0},
};
#endif
/*--------------------End BAPI_MPOPX-------------------*/
/*--------------------BAPI_MPGD-------------------*/
#ifndef SAP_ST_BAPI_MPGD
#define SAP_ST_BAPI_MPGD
typedef struct
{
RFC_CHAR Plant[4];	/*0	Plant*/
RFC_CHAR Plng_Matl[18];	/*0	Planning material*/
RFC_CHAR Plng_Plant[4];	/*0	Planning plant*/
RFC_CHAR Convfactor[10];	/*0	Conv. factor f. plng material*/
RFC_CHAR Plng_Matl_External[40];	/*0	Long Material Number for PLNG_MATL Field*/
RFC_CHAR Plng_Matl_Guid[32];	/*0	External GUID for PLNG_MATL Field*/
RFC_CHAR Plng_Matl_Version[10];	/*0	Version Number for PLNG_MATL Field*/
}BAPI_MPGD;
#endif

#ifndef SAP_TH_BAPI_MPGD
#define SAP_TH_BAPI_MPGD
static const RFC_TYPEHANDLE handleOfBAPI_MPGD;
static const RFC_TYPE_ELEMENT typeOfBAPI_MPGD[]=
{
	{"PLANT"				,TYPC,	4	,0},
	{"PLNG_MATL"			,TYPC,	18	,0},
	{"PLNG_PLANT"			,TYPC,	4	,0},
	{"CONVFACTOR"			,TYPC,	10	,0},
	{"PLNG_MATL_EXTERNAL"	,TYPC,	40	,0},
	{"PLNG_MATL_GUID"		,TYPC,	32	,0},
	{"PLNG_MATL_VERSION"	,TYPC,	10	,0},
};
#endif
/*--------------------End BAPI_MPGD-------------------*/
/*--------------------BAPI_MPGDX-------------------*/
#ifndef SAP_ST_BAPI_MPGDX
#define SAP_ST_BAPI_MPGDX
typedef struct
{
RFC_CHAR Plant[4];
RFC_CHAR Plng_Matl[1];
RFC_CHAR Plng_Plant[1];
RFC_CHAR Convfactor[1];
RFC_CHAR Plng_Matl_External[1];
RFC_CHAR Plng_Matl_Guid[1];
RFC_CHAR Plng_Matl_Version[1];
}BAPI_MPGDX;
#endif

#ifndef SAP_TH_BAPI_MPGDX
#define SAP_TH_BAPI_MPGDX
static const RFC_TYPEHANDLE handleOfBAPI_MPGDX;
static const RFC_TYPE_ELEMENT typeOfBAPI_MPGDX[]=
{
	{"PLANT"				,TYPC,	4,	0},
	{"PLNG_MATL"			,TYPC,	1,	0},
	{"PLNG_PLANT"			,TYPC,	1,	0},
	{"CONVFACTOR"			,TYPC,	1,	0},
	{"PLNG_MATL_EXTERNAL"	,TYPC,	1,	0},
	{"PLNG_MATL_GUID"		,TYPC,	1,	0},
	{"PLNG_MATL_VERSION"	,TYPC,	1,	0},
};
#endif
/*--------------------End BAPI_MPGDX-------------------*/

/*--------------------BAPI_MARD-------------------*/
#ifndef SAP_ST_BAPI_MARD
#define SAP_ST_BAPI_MARD
typedef struct
{
RFC_CHAR Plant[4];			/*	0	Plant*/
RFC_CHAR Stge_Loc[4];		/*	0	Storage location*/
RFC_CHAR Del_Flag[1];		/*	0	Flag Material for Deletion at Storage Location Level*/
RFC_CHAR Mrp_Ind[1];		/*	0	Storage location MRP indicator*/
RFC_CHAR Spec_Proc[2];		/*0	Special procurement type at storage location level*/
RFC_BCD Reorder_Pt[7];	/*3	Reorder point for storage location MRP*/
RFC_BCD Repl_Qty[7];		/*3	Replenishment quantity for storage location MRP*/
RFC_CHAR Stge_Bin[10];		/*0	Storage bin*/
RFC_CHAR Pickg_Area[3];		/*0	Picking area for lean WM*/
RFC_FLOAT Inv_Corr_Fac;	/*16	Inventory correction factor*/
}BAPI_MARD;
#endif

#ifndef SAP_TH_BAPI_MARD
#define SAP_TH_BAPI_MARD
static const RFC_TYPEHANDLE handleOfBAPI_MARD;
static const RFC_TYPE_ELEMENT typeOfBAPI_MARD[]=
{
	{"PLANT"		,TYPC,		4,	0},
	{"STGE_LOC"		,TYPC,		4,	0},
	{"DEL_FLAG"		,TYPC,		1,	0},
	{"MRP_IND"		,TYPC,		1,	0},
	{"SPEC_PROC"	,TYPC,		2,	0},
	{"REORDER_PT"	,TYPP,	7,	0},
	{"REPL_QTY"		,TYPP,	7,	0},
	{"STGE_BIN"		,TYPC,		10,	0},
	{"PICKG_AREA"	,TYPC,		3,  0},
	{"INV_CORR_FAC"	,TYPFLOAT,	sizeof(double),	0},
};
#endif
/*--------------------End BAPI_MARD-------------------*/
/*--------------------BAPI_MARDX-------------------*/
#ifndef SAP_ST_BAPI_MARDX
#define SAP_ST_BAPI_MARDX
typedef struct
{
RFC_CHAR Plant[4];
RFC_CHAR Stge_Loc[4];
RFC_CHAR Del_Flag[1];
RFC_CHAR Mrp_Ind[1];
RFC_CHAR Spec_Proc[1];
RFC_CHAR Reorder_Pt[1];
RFC_CHAR Repl_Qty[1];
RFC_CHAR Stge_Bin[1];
RFC_CHAR Pickg_Area[1];
RFC_CHAR Inv_Corr_Fac[1];
}BAPI_MARDX;
#endif

#ifndef SAP_TH_BAPI_MARDX
#define SAP_TH_BAPI_MARDX
static const RFC_TYPEHANDLE handleOfBAPI_MARDX;
static const RFC_TYPE_ELEMENT typeOfBAPI_MARDX[]=
{
	{"PLANT",		TYPC,	4,	0},
	{"STGE_LOC",	TYPC,	4,	0},
	{"DEL_FLAG",	TYPC,	1,	0},
	{"MRP_IND",		TYPC,	1,	0},
	{"SPEC_PROC",	TYPC,	1,	0},
	{"REORDER_PT",	TYPC,	1,	0},
	{"REPL_QTY",	TYPC,	1,	0},
	{"STGE_BIN",	TYPC,	1,	0},
	{"PICKG_AREA",	TYPC,	1,	0},
	{"INV_CORR_FAC",TYPC,	1,	0},
};
#endif
/*--------------------End BAPI_MARDX-------------------*/
/*--------------------BAPI_MBEW-------------------*/
#ifndef SAP_ST_BAPI_MBEW
#define SAP_ST_BAPI_MBEW
typedef struct
{
RFC_CHAR Val_Area[4];/*	0	Valuation area*/
RFC_CHAR Val_Type[10];/*	0	Valuation type*/
RFC_CHAR Del_Flag[1];/*	0	Deletion flag for all material data of a valuation type*/
RFC_CHAR Price_Ctrl[1];/*	0	Price control indicator*/
RFC_BCD Moving_Pr[12];/*	4	Moving average price/periodic unit price*/
RFC_BCD Std_Price[12];/*	4	Standard price*/
RFC_BCD Price_Unit[3];/*	0	Price unit*/
RFC_CHAR Val_Class[4];/*	0	Valuation Class*/
RFC_CHAR Pr_Ctrl_Pp[1];/*	0	Price Control Indicator in Previous Period*/
RFC_BCD Mov_Pr_Pp[12];/*	4	Moving average price/periodic unit price in previous period*/
RFC_BCD Std_Pr_Pp[12];/*	4	Standard price in the previous period*/
RFC_BCD Pr_Unit_Pp[3];/*	0	Price unit of previous period*/
RFC_CHAR Vclass_Pp[4];/*	0	Valuation Class in Previous Period*/
RFC_CHAR Pr_Ctrl_Py[1];/*	0	Price Control Indicator in Previous Year*/
RFC_BCD Mov_Pr_Py[12];/*	4	Moving average price/periodic unit price in previous year*/
RFC_BCD Std_Pr_Py[12];/*	4	Standard price in previous year*/
RFC_CHAR Vclass_Py[4];/*	0	Valuation Class in Previous Year*/
RFC_BCD Pr_Unit_Py[3];/*	0	Price unit of previous year*/
RFC_CHAR Val_Cat[1];/*	0	Valuation Category*/
RFC_BCD Future_Pr[12];/*	4	Future price*/
RFC_DATE Valid_From;/*	0	Date as of which the price is valid*/
RFC_BCD Taxprice_1[12];/*	4	Valuation price based on tax law: level 1*/
RFC_BCD Commprice1[12];/*	4	Valuation price based on commercial law: level 1*/
RFC_BCD Taxprice_3[12];/*	4	Valuation price based on tax law: level 3*/
RFC_BCD Commprice3[12];/*	4	Valuation price based on commercial law: level 3*/
RFC_BCD Plnd_Price[12];/*	4	Future Planned Price*/
RFC_BCD Plndprice1[12];/*	4	Future Planned Price 1*/
RFC_BCD Plndprice2[12];/*	4	Future Planned Price 2*/
RFC_BCD Plndprice3[12];/*	4	Future Planned Price 3*/
RFC_DATE Plndprdate1;/*	0	Date from Which Future Planned Price 1 Is Valid*/
RFC_DATE Plndprdate2;/*	0	Date from Which Future Planned Price 2 Is Valid*/
RFC_DATE Plndprdate3;/*	0	Date from Which Future Planned Price 3 Is Valid*/
RFC_CHAR Lifo_Fifo[1];/*	0	LIFO/FIFO-relevant*/
RFC_CHAR Poolnumber[4];/*	0	Pool number for LIFO valuation*/
RFC_BCD Taxprice_2[12];/*	4	Valuation price based on tax law: level 2*/
RFC_BCD Commprice2[12];/*	4	Valuation price based on commercial law: level 2*/
RFC_NUM Deval_Ind[2];/*	0	Lowest value: devaluation indicator*/
RFC_CHAR Orig_Group[4];/*	0	Origin Group as Subdivision of Cost Element*/
RFC_CHAR Overhead_Grp[10];/*	0	Costing Overhead Group*/
RFC_CHAR Qty_Struct[1];/*	0	Material Is Costed with Quantity Structure*/
RFC_CHAR Ml_Active[1];/*	0	Material ledger activated at material level*/
RFC_CHAR Ml_Settle[1];/*	0	Material Price Determination: Control*/
RFC_CHAR Orig_Mat[1];/*	0	Material-related origin*/
RFC_CHAR Vm_So_Stk[4];/*	0	Valuation Class for Sales Order Stock*/
RFC_CHAR Vm_P_Stock[4];/*	0	Valuation Class for Project Stock*/
RFC_CHAR Matl_Usage[1];/*	0	Usage of the material*/
RFC_CHAR Mat_Origin[1];/*	0	Origin of the material*/
RFC_CHAR In_House[1];/*	0	Produced in-house*/
RFC_BCD Tax_Cml_Un[3];/*	0	Price unit for valuation prices based on tax/commercial law*/
}BAPI_MBEW;
#endif

#ifndef SAP_TH_BAPI_MBEW
#define SAP_TH_BAPI_MBEW
static const RFC_TYPEHANDLE handleOfBAPI_MBEW;
static const RFC_TYPE_ELEMENT typeOfBAPI_MBEW[]=
{
{"VAL_AREA",		TYPC,		4	,0},
{"VAL_TYPE",		TYPC,		10	,0},
{"DEL_FLAG",		TYPC,		1	,0},
{"PRICE_CTRL",		TYPC,		1	,0},
{"MOVING_PR",		TYPP,	12		,0},
{"STD_PRICE",		TYPP,	12		,0},
{"PRICE_UNIT",		TYPP,	3		,0},
{"VAL_CLASS",		TYPC,		4	,0},
{"PR_CTRL_PP",		TYPC,		1	,0},
{"MOV_PR_PP",		TYPP,	12,	0},
{"STD_PR_PP",		TYPP,	12	,0},
{"PR_UNIT_PP",		TYPP,	3	,0},
{"VCLASS_PP",		TYPC,		4	,0},
{"PR_CTRL_PY",		TYPC,		1	,0},
{"MOV_PR_PY",		TYPP,	12	,0},
{"STD_PR_PY",		TYPP,	12	,0},
{"VCLASS_PY",		TYPC,		4	,0},
{"PR_UNIT_PY",		TYPP,	3	,0},
{"VAL_CAT",			TYPC,		1	,0},
{"FUTURE_PR",		TYPP,	12	,0},
{"VALID_FROM",		TYPDATE,	sizeof(RFC_DATE)	,0},
{"TAXPRICE_1",		TYPP,	12	,0},
{"COMMPRICE1",		TYPP,	12	,0},
{"TAXPRICE_3",		TYPP,	12	,0},
{"COMMPRICE3",		TYPP,	12	,0},
{"PLND_PRICE",		TYPP,	12	,0},
{"PLNDPRICE1",		TYPP,	12	,0},
{"PLNDPRICE2",		TYPP,	12	,0},
{"PLNDPRICE3",		TYPP,	12	,0},
{"PLNDPRDATE1",		TYPDATE,	sizeof(RFC_DATE)	,0},
{"PLNDPRDATE2",		TYPDATE,	sizeof(RFC_DATE)	,0},
{"PLNDPRDATE3",		TYPDATE,	sizeof(RFC_DATE)	,0},
{"LIFO_FIFO",		TYPC,		1	,0},
{"POOLNUMBER",		TYPC,		4	,0},
{"TAXPRICE_2",		TYPP,	12	,0},
{"COMMPRICE2",		TYPP,	12	,0},
{"DEVAL_IND",		TYPNUM,	2	,0},
{"ORIG_GROUP",		TYPC,		4	,0},
{"OVERHEAD_GRP",	TYPC,		10	,0},
{"QTY_STRUCT",		TYPC,		1	,0},
{"ML_ACTIVE",		TYPC,		1	,0},
{"ML_SETTLE",		TYPC,		1	,0},
{"ORIG_MAT",		TYPC,		1	,0},
{"VM_SO_STK",		TYPC,		4	,0},
{"VM_P_STOCK",		TYPC,		4	,0},
{"MATL_USAGE",		TYPC,		1	,0},
{"MAT_ORIGIN",		TYPC,		1	,0},
{"IN_HOUSE",		TYPC,		1	,0},
{"TAX_CML_UN",		TYPP,	3	,0},
};
#endif
/*--------------------End BAPI_MBEW-------------------*/

/*--------------------BAPI_MBEWX-------------------*/
#ifndef SAP_ST_BAPI_MBEWX
#define SAP_ST_BAPI_MBEWX
typedef struct
{
RFC_CHAR Val_Area[4];
RFC_CHAR Val_Type[10];
RFC_CHAR Del_Flag[1];
RFC_CHAR Price_Ctrl[1];
RFC_CHAR Moving_Pr[1];
RFC_CHAR Std_Price[1];
RFC_CHAR Price_Unit[1];
RFC_CHAR Val_Class[1];
RFC_CHAR Pr_Ctrl_Pp[1];
RFC_CHAR Mov_Pr_Pp[1];
RFC_CHAR Std_Pr_Pp[1];
RFC_CHAR Pr_Unit_Pp[1];
RFC_CHAR Vclass_Pp[1];
RFC_CHAR Pr_Ctrl_Py[1];
RFC_CHAR Mov_Pr_Py[1];
RFC_CHAR Std_Pr_Py[1];
RFC_CHAR Vclass_Py[1];
RFC_CHAR Pr_Unit_Py[1];
RFC_CHAR Val_Cat[1];
RFC_CHAR Future_Pr[1];
RFC_CHAR Valid_From[1];
RFC_CHAR Taxprice_1[1];
RFC_CHAR Commprice1[1];
RFC_CHAR Taxprice_3[1];
RFC_CHAR Commprice3[1];
RFC_CHAR Plnd_Price[1];
RFC_CHAR Plndprice1[1];
RFC_CHAR Plndprice2[1];
RFC_CHAR Plndprice3[1];
RFC_CHAR Plndprdate1[1];
RFC_CHAR Plndprdate2[1];
RFC_CHAR Plndprdate3[1];
RFC_CHAR Lifo_Fifo[1];
RFC_CHAR Poolnumber[1];
RFC_CHAR Taxprice_2[1];
RFC_CHAR Commprice2[1];
RFC_CHAR Deval_Ind[1];
RFC_CHAR Orig_Group[1];
RFC_CHAR Overhead_Grp[1];
RFC_CHAR Qty_Struct[1];
RFC_CHAR Ml_Active[1];
RFC_CHAR Ml_Settle[1];
RFC_CHAR Orig_Mat[1];
RFC_CHAR Vm_So_Stk[1];
RFC_CHAR Vm_P_Stock[1];
RFC_CHAR Matl_Usage[1];
RFC_CHAR Mat_Origin[1];
RFC_CHAR In_House[1];
RFC_CHAR Tax_Cml_Un[1];
}BAPI_MBEWX;
#endif

#ifndef SAP_TH_BAPI_MBEWX
#define SAP_TH_BAPI_MBEWX
static const RFC_TYPEHANDLE handleOfBAPI_MBEWX;
static const RFC_TYPE_ELEMENT typeOfBAPI_MBEWX[]=
{
{"VAL_AREA",		TYPC,	4	,0},
{"VAL_TYPE",		TYPC,	10	,0},
{"DEL_FLAG",		TYPC,	1	,0},
{"PRICE_CTRL",		TYPC,	1	,0},
{"MOVING_PR",		TYPC,	1	,0},
{"STD_PRICE",		TYPC,	1	,0},
{"PRICE_UNIT",		TYPC,	1	,0},
{"VAL_CLASS",		TYPC,	1	,0},
{"PR_CTRL_PP",		TYPC,	1	,0},
{"MOV_PR_PP",		TYPC,	1,	0},
{"STD_PR_PP",		TYPC,	1	,0},
{"PR_UNIT_PP",		TYPC,	1	,0},
{"VCLASS_PP",		TYPC,	1	,0},
{"PR_CTRL_PY",		TYPC,	1	,0},
{"MOV_PR_PY",		TYPC,	1	,0},
{"STD_PR_PY",		TYPC,	1	,0},
{"VCLASS_PY",		TYPC,	1	,0},
{"PR_UNIT_PY",		TYPC,	1	,0},
{"VAL_CAT",			TYPC,	1	,0},
{"FUTURE_PR",		TYPC,	1	,0},
{"VALID_FROM",		TYPC,	1	,0},
{"TAXPRICE_1",		TYPC,	1	,0},
{"COMMPRICE1",		TYPC,	1	,0},
{"TAXPRICE_3",		TYPC,	1	,0},
{"COMMPRICE3",		TYPC,	1	,0},
{"PLND_PRICE",		TYPC,	1	,0},
{"PLNDPRICE1",		TYPC,	1	,0},
{"PLNDPRICE2",		TYPC,	1	,0},
{"PLNDPRICE3",		TYPC,	1	,0},
{"PLNDPRDATE1",		TYPC,	1	,0},
{"PLNDPRDATE2",		TYPC,	1	,0},
{"PLNDPRDATE3",		TYPC,	1	,0},
{"LIFO_FIFO",		TYPC,	1	,0},
{"POOLNUMBER",		TYPC,	1	,0},
{"TAXPRICE_2",		TYPC,	1	,0},
{"COMMPRICE2",		TYPC,	1	,0},
{"DEVAL_IND",		TYPC,	1	,0},
{"ORIG_GROUP",		TYPC,	1	,0},
{"OVERHEAD_GRP",	TYPC,	1	,0},
{"QTY_STRUCT",		TYPC,	1	,0},
{"ML_ACTIVE",		TYPC,	1	,0},
{"ML_SETTLE",		TYPC,	1	,0},
{"ORIG_MAT",		TYPC,	1	,0},
{"VM_SO_STK",		TYPC,	1	,0},
{"VM_P_STOCK",		TYPC,	1	,0},
{"MATL_USAGE",		TYPC,	1	,0},
{"MAT_ORIGIN",		TYPC,	1	,0},
{"IN_HOUSE",		TYPC,	1	,0},
{"TAX_CML_UN",		TYPC,	1	,0},
};
#endif
/*--------------------End BAPI_MBEWX-------------------*/
/*--------------------BAPI_MLGN-------------------*/
#ifndef SAP_ST_BAPI_MLGN
#define SAP_ST_BAPI_MLGN
typedef struct
{
RFC_CHAR Whse_No[3];/*	0	Warehouse Number / Warehouse Complex*/
RFC_CHAR Del_Flag[1];/*	0	Deletion flag for all material data of a warehouse number*/
RFC_CHAR Stgesector[3];/*	0	Storage section indicator*/
RFC_CHAR Placement[3];/*	0	Storage type indicator for stock placement*/
RFC_CHAR Withdrawal[3];/*	0	Storage type indicator for stock removal*/
RFC_BCD L_Equip_1[7];/*	3	Loading equipment quantity 1*/
RFC_BCD L_Equip_2[7];/*	3	Loading equipment quantity 2*/
RFC_BCD L_Equip_3[7];/*	3	Loading equipment quantity 3*/
RFC_CHAR Leq_Unit_1[3];/*	0	Unit of measure for loading equipment quantity 1*/
RFC_CHAR Leq_Unit_1_Iso[3];/*	0	Unit of measure for loading equipment quantity 1 in ISO code*/
RFC_CHAR Leq_Unit_2[3];/*	0	Unit of measure for loading equipment quantity 2*/
RFC_CHAR Leq_Unit_2_Iso[3];/*	0	Unit of measure for loading equipment quantity 2 in ISO code*/
RFC_CHAR Leq_Unit_3[3];/*	0	Unit of measure for loading equipment quantity 3*/
RFC_CHAR Leq_Unit_3_Iso[3];/*	0	Unit of measure for loading equipment quantity 3 in ISO code*/
RFC_CHAR Unittype_1[3];/*	0	1st storage unit type*/
RFC_CHAR Unittype_2[3];/*	0	2nd storage unit type*/
RFC_CHAR Unittype_3[3];/*	0	3rd storage unit type*/
RFC_CHAR Wm_Unit[3];/*	0	Warehouse Management Unit of Measure*/
RFC_CHAR Wm_Unit_Iso[3];/*	0	WM unit in ISO code*/
RFC_CHAR Add_To_Stk[1];/*	0	Indicator: Allow addition to existing stock*/
RFC_CHAR Block_Stge[2];/*	0	Bulk storage indicator*/
RFC_CHAR Msg_To_Im[1];/*	0	Indicator: Message to inventory management*/
RFC_CHAR Spec_Mvmt[1];/*	0	Special movement indicator for warehouse management*/
RFC_BCD Capy_Usage[6];/*	3	Capacity usage*/
RFC_CHAR Procure_Un[3];/*	0	Unit of measure for capacity consumption*/
RFC_CHAR Procure_Un_Iso[3];/*	0	Unit of measure for capacity consumption in ISO code*/
RFC_CHAR Stge_Type[3];/*	0	Picking storage type for rough-cut and detailed planning*/
RFC_CHAR Ref_Unit[1];/*	0	Default for unit of measure from material master record*/
RFC_CHAR Step_Pick[1];/*	0	Material relevance for 2-step picking*/
}BAPI_MLGN;
#endif

#ifndef SAP_TH_BAPI_MLGN
#define SAP_TH_BAPI_MLGN
static const RFC_TYPEHANDLE handleOfBAPI_MLGN;
static const RFC_TYPE_ELEMENT typeOfBAPI_MLGN[]=
{
	{"WHSE_NO",			TYPC,	3,	0},
	{"DEL_FLAG",		TYPC,	1,	0},
	{"STGESECTOR",		TYPC,	3,	0},
	{"PLACEMENT",		TYPC,	3,	0},
	{"WITHDRAWAL",		TYPC,	3,	0},
	{"L_EQUIP_1",		TYPP,	7,	0},
	{"L_EQUIP_2",		TYPP,	7,	0},
	{"L_EQUIP_3",		TYPP,	7,	0},
	{"LEQ_UNIT_1",		TYPC,	3,	0},
	{"LEQ_UNIT_1_ISO",	TYPC,	3,	0},
	{"LEQ_UNIT_2",		TYPC,	3,	0},
	{"LEQ_UNIT_2_ISO",	TYPC,	3,	0},
	{"LEQ_UNIT_3",		TYPC,	3,	0},
	{"LEQ_UNIT_3_ISO",	TYPC,	3,	0},
	{"UNITTYPE_1",		TYPC,	3,	0},
	{"UNITTYPE_2",		TYPC,	3,	0},
	{"UNITTYPE_3",		TYPC,	3,	0},
	{"WM_UNIT",			TYPC,	3,	0},
	{"WM_UNIT_ISO",		TYPC,	3,	0},
	{"ADD_TO_STK",		TYPC,	1,	0},
	{"BLOCK_STGE",		TYPC,	2,	0},
	{"MSG_TO_IM",		TYPC,	1,	0},
	{"SPEC_MVMT",		TYPC,	1,	0},
	{"CAPY_USAGE",		TYPP,   6,	0},
	{"PROCURE_UN",		TYPC,	3,	0},
	{"PROCURE_UN_ISO",	TYPC,	3,	0},
	{"STGE_TYPE",		TYPC,	3,	0},
	{"REF_UNIT",		TYPC,	1,	0},
	{"2STEP_PICK",		TYPC,	1,	0},
};
#endif
/*--------------------End BAPI_MLGN-------------------*/
/*--------------------BAPI_MLGNX-------------------*/
#ifndef SAP_ST_BAPI_MLGNX
#define SAP_ST_BAPI_MLGNX
typedef struct
{
RFC_CHAR Whse_No[3];
RFC_CHAR Del_Flag[1];
RFC_CHAR Stgesector[1];
RFC_CHAR Placement[1];
RFC_CHAR Withdrawal[1];
RFC_CHAR L_Equip_1[1];
RFC_CHAR L_Equip_2[1];
RFC_CHAR L_Equip_3[1];
RFC_CHAR Leq_Unit_1[1];
RFC_CHAR Leq_Unit_1_Iso[1];
RFC_CHAR Leq_Unit_2[1];
RFC_CHAR Leq_Unit_2_Iso[1];
RFC_CHAR Leq_Unit_3[1];
RFC_CHAR Leq_Unit_3_Iso[1];
RFC_CHAR Unittype_1[1];
RFC_CHAR Unittype_2[1];
RFC_CHAR Unittype_3[1];
RFC_CHAR Wm_Unit[1];
RFC_CHAR Wm_Unit_Iso[1];
RFC_CHAR Add_To_Stk[1];
RFC_CHAR Block_Stge[1];
RFC_CHAR Msg_To_Im[1];
RFC_CHAR Spec_Mvmt[1];
RFC_CHAR Capy_Usage[1];
RFC_CHAR Procure_Un[1];
RFC_CHAR Procure_Un_Iso[1];
RFC_CHAR Stge_Type[1];
RFC_CHAR Ref_Unit[1];
RFC_CHAR Step_Pick[1];
}BAPI_MLGNX;
#endif

#ifndef SAP_TH_BAPI_MLGNX
#define SAP_TH_BAPI_MLGNX
static const RFC_TYPEHANDLE handleOfBAPI_MLGNX;
static const RFC_TYPE_ELEMENT typeOfBAPI_MLGNX[]=
{
	{"WHSE_NO",			TYPC,	3,	0},
	{"DEL_FLAG",		TYPC,	1,	0},
	{"STGESECTOR",		TYPC,	1,	0},
	{"PLACEMENT",		TYPC,	1,	0},
	{"WITHDRAWAL",		TYPC,	1,	0},
	{"L_EQUIP_1",		TYPC,	1,	0},
	{"L_EQUIP_2",		TYPC,	1,	0},
	{"L_EQUIP_3",		TYPC,	1,	0},
	{"LEQ_UNIT_1",		TYPC,	1,	0},
	{"LEQ_UNIT_1_ISO",	TYPC,	1,	0},
	{"LEQ_UNIT_2",		TYPC,	1,	0},
	{"LEQ_UNIT_2_ISO",	TYPC,	1,	0},
	{"LEQ_UNIT_3",		TYPC,	1,	0},
	{"LEQ_UNIT_3_ISO",	TYPC,	1,	0},
	{"UNITTYPE_1",		TYPC,	1,	0},
	{"UNITTYPE_2",		TYPC,	1,	0},
	{"UNITTYPE_3",		TYPC,	1,	0},
	{"WM_UNIT",			TYPC,	1,	0},
	{"WM_UNIT_ISO",		TYPC,	1,	0},
	{"ADD_TO_STK",		TYPC,	1,	0},
	{"BLOCK_STGE",		TYPC,	1,	0},
	{"MSG_TO_IM",		TYPC,	1,	0},
	{"SPEC_MVMT",		TYPC,	1,	0},
	{"CAPY_USAGE",		TYPC,	1,	0},
	{"PROCURE_UN",		TYPC,	1,	0},
	{"PROCURE_UN_ISO",	TYPC,	1,	0},
	{"STGE_TYPE",		TYPC,	1,	0},
	{"REF_UNIT",		TYPC,	1,	0},
	{"2STEP_PICK",		TYPC,	1,	0},
};
#endif
/*--------------------End BAPI_MLGNX-------------------*/
/*--------------------BAPI_MVKE-------------------*/
#ifndef SAP_ST_BAPI_MVKE
#define SAP_ST_BAPI_MVKE
typedef struct
{
RFC_CHAR Sales_Org[4];/*	0	Sales Organization*/
RFC_CHAR Distr_Chan[2];/*	0	Distribution Channel*/
RFC_CHAR Del_Flag[1];/*	0	Ind.: Flag material for deletion at distribution chain level*/
RFC_CHAR Matl_Stats[1];/*	0	Material statistics group*/
RFC_CHAR Rebate_Grp[2];/*	0	Volume rebate group*/
RFC_CHAR Comm_Group[2];/*	0	Commission group*/
RFC_CHAR Cash_Disc[1];/*	0	Cash discount indicator*/
RFC_CHAR Sal_Status[2];/*	0	Distribution-chain-specific material status*/
RFC_DATE Valid_From;/*	0	Date from which distr.-chain-spec. material status is valid*/
RFC_BCD Min_Order[7];/*	3	Minimum order quantity in base unit of measure*/
RFC_BCD Min_Dely[7];/*	3	Minimum delivery quantity in delivery note processing*/
RFC_BCD Min_Mto[7];/*	3	Minimum make-to-order quantity*/
RFC_BCD Dely_Unit[7];/*	3	Delivery unit*/
RFC_CHAR Dely_Uom[3];/*	0	Unit of measure of delivery unit*/
RFC_CHAR Dely_Uom_Iso[3];/*	0	Unit of measure for delivery unit in ISO code*/
RFC_CHAR Sales_Unit[3];/*	0	Sales unit*/
RFC_CHAR Sales_Unit_Iso[3];/*	0	Sales unit in ISO code*/
RFC_CHAR Item_Cat[4];/*	0	Item category group from material master*/
RFC_CHAR Delyg_Plnt[4];/*	0	Delivering Plant*/
RFC_CHAR Prod_Hier[18];/*	0	Product hierarchy*/
RFC_CHAR Pr_Ref_Mat[18];/*	0	Pricing reference material*/
RFC_CHAR Mat_Pr_Grp[2];/*	0	Material Pricing Group*/
RFC_CHAR Acct_Assgt[2];/*	0	Account assignment group for this material*/
RFC_CHAR Matl_Grp_1[3];/*	0	Material group 1*/
RFC_CHAR Matl_Grp_2[3];/*	0	Material group 2*/
RFC_CHAR Matl_Grp_3[3];/*	0	Material group 3*/
RFC_CHAR Matl_Grp_4[3];/*	0	Material group 4*/
RFC_CHAR Matl_Grp_5[3];/*	0	Material group 5*/
RFC_CHAR Prod_Att_1[1];/*	0	ID for product attribute 1*/
RFC_CHAR Prod_Att_2[1];/*	0	ID for product attribute 2*/
RFC_CHAR Prod_Att_3[1];/*	0	ID for product attribute 3*/
RFC_CHAR Prod_Att_4[1];/*	0	ID for product attribute 4*/
RFC_CHAR Prod_Att_5[1];/*	0	ID for product attribute 5*/
RFC_CHAR Prod_Att_6[1];/*	0	ID for product attribute 6*/
RFC_CHAR Prod_Att_7[1];/*	0	ID for product attribute 7*/
RFC_CHAR Prod_Att_8[1];/*	0	ID for product attribute 8*/
RFC_CHAR Prod_Att_9[1];/*	0	ID for product attribute 9*/
RFC_CHAR Prod_Att10[1];/*	0	ID for product attribute 10*/
RFC_CHAR Round_Prof[4];/*	0	Rounding profile*/
RFC_CHAR Var_Sales_Un[1];/*	0	Variable Sales Unit Not Allowed*/
RFC_CHAR Unit_Group[4];/*	0	Unit of measure group*/
RFC_CHAR Pr_Ref_Mat_External[40];/*	0	Long Material Number for PR_REF_MAT Field*/
RFC_CHAR Pr_Ref_Mat_Guid[32];/*	0	External GUID for PR_REF_MAT Field*/
RFC_CHAR Pr_Ref_Mat_Version[10];/*	0	Version Number for PR_REF_MAT Field*/
}BAPI_MVKE;
#endif

#ifndef SAP_TH_BAPI_MVKE
#define SAP_TH_BAPI_MVKE
static const RFC_TYPEHANDLE handleOfBAPI_MVKE;
static const RFC_TYPE_ELEMENT typeOfBAPI_MVKE[]=
{
	{"SALES_ORG",		TYPC,		4,	0},
	{"DISTR_CHAN",		TYPC,		2,	0},
	{"DEL_FLAG",		TYPC,		1,	0},
	{"MATL_STATS",		TYPC,		1,	0},
	{"REBATE_GRP",		TYPC,		2,	0},
	{"COMM_GROUP",		TYPC,		2,	0},
	{"CASH_DISC",		TYPC,		1,	0},
	{"SAL_STATUS",		TYPC,		2,	0},
	{"VALID_FROM",		TYPDATE,	sizeof(RFC_DATE),	0},
	{"MIN_ORDER",		TYPP,	7,	0},
	{"MIN_DELY",		TYPP,	7,	0},
	{"MIN_MTO",			TYPP,	7,	0},
	{"DELY_UNIT",		TYPP,	7,	0},
	{"DELY_UOM",		TYPNUM,		3,	0},
	{"DELY_UOM_ISO",	TYPC,		3,	0},
	{"SALES_UNIT",		TYPNUM,		3,	0},
	{"SALES_UNIT_ISO",	TYPC,		3,	0},
	{"ITEM_CAT",		TYPC,		4,	0},
	{"DELYG_PLNT",		TYPC,		4,	0},
	{"PROD_HIER",		TYPC,		18,	0},
	{"PR_REF_MAT",		TYPC,		18,	0},
	{"MAT_PR_GRP",		TYPC,		2,	0},
	{"ACCT_ASSGT",		TYPC,		2,	0},
	{"MATL_GRP_1",		TYPC,		3,	0},
	{"MATL_GRP_2",		TYPC,		3,	0},
	{"MATL_GRP_3",		TYPC,		3,	0},
	{"MATL_GRP_4",		TYPC,		3,	0},
	{"MATL_GRP_5",		TYPC,		3,	0},
	{"PROD_ATT_1",		TYPC,		1,	0},
	{"PROD_ATT_2",		TYPC,		1,	0},
	{"PROD_ATT_3",		TYPC,		1,	0},
	{"PROD_ATT_4",		TYPC,		1,	0},
	{"PROD_ATT_5",		TYPC,		1,	0},
	{"PROD_ATT_6",		TYPC,		1,	0},
	{"PROD_ATT_7",		TYPC,		1,	0},
	{"PROD_ATT_8",		TYPC,		1,	0},
	{"PROD_ATT_9",		TYPC,		1,	0},
	{"PROD_ATT10",		TYPC,		1,	0},
	{"ROUND_PROF",		TYPC,		4,	0},
	{"VAR_SALES_UN",	TYPC,		1,	0},
	{"UNIT_GROUP",		TYPC,		4,	0},
	{"PR_REF_MAT_EXTERNAL",	TYPC,	40,	0},
	{"PR_REF_MAT_GUID",	TYPC,		32,	0},
	{"PR_REF_MAT_VERSION",	TYPC,	10,	0},
};
#endif
/*--------------------End BAPI_MVKE-------------------*/
/*--------------------BAPI_MVKEX-------------------*/
#ifndef SAP_ST_BAPI_MVKEX
#define SAP_ST_BAPI_MVKEX
typedef struct
{
RFC_CHAR Sales_Org[4];
RFC_CHAR Distr_Chan[2];
RFC_CHAR Del_Flag[1];
RFC_CHAR Matl_Stats[1];
RFC_CHAR Rebate_Grp[1];
RFC_CHAR Comm_Group[1];
RFC_CHAR Cash_Disc[1];
RFC_CHAR Sal_Status[1];
RFC_CHAR Valid_From[1];
RFC_CHAR Min_Order[1];
RFC_CHAR Min_Dely[1];
RFC_CHAR Min_Mto[1];
RFC_CHAR Dely_Unit[1];
RFC_CHAR Dely_Uom[1];
RFC_CHAR Dely_Uom_Iso[1];
RFC_CHAR Sales_Unit[1];
RFC_CHAR Sales_Unit_Iso[1];
RFC_CHAR Item_Cat[1];
RFC_CHAR Delyg_Plnt[1];
RFC_CHAR Prod_Hier[1];
RFC_CHAR Pr_Ref_Mat[1];
RFC_CHAR Mat_Pr_Grp[1];
RFC_CHAR Acct_Assgt[1];
RFC_CHAR Matl_Grp_1[1];
RFC_CHAR Matl_Grp_2[1];
RFC_CHAR Matl_Grp_3[1];
RFC_CHAR Matl_Grp_4[1];
RFC_CHAR Matl_Grp_5[1];
RFC_CHAR Prod_Att_1[1];
RFC_CHAR Prod_Att_2[1];
RFC_CHAR Prod_Att_3[1];
RFC_CHAR Prod_Att_4[1];
RFC_CHAR Prod_Att_5[1];
RFC_CHAR Prod_Att_6[1];
RFC_CHAR Prod_Att_7[1];
RFC_CHAR Prod_Att_8[1];
RFC_CHAR Prod_Att_9[1];
RFC_CHAR Prod_Att10[1];
RFC_CHAR Round_Prof[1];
RFC_CHAR Var_Sales_Un[1];
RFC_CHAR Unit_Group[1];
RFC_CHAR Pr_Ref_Mat_External[1];
RFC_CHAR Pr_Ref_Mat_Guid[1];
RFC_CHAR Pr_Ref_Mat_Version[1];
}BAPI_MVKEX;
#endif

#ifndef SAP_TH_BAPI_MVKEX
#define SAP_TH_BAPI_MVKEX
static const RFC_TYPEHANDLE handleOfBAPI_MVKEX;
static const RFC_TYPE_ELEMENT typeOfBAPI_MVKEX[]=
{
	{"SALES_ORG",		TYPC,		4,	0},
	{"DISTR_CHAN",		TYPC,		2,	0},
	{"DEL_FLAG",		TYPC,		1,	0},
	{"MATL_STATS",		TYPC,		1,	0},
	{"REBATE_GRP",		TYPC,		1,	0},
	{"COMM_GROUP",		TYPC,		1,	0},
	{"CASH_DISC",		TYPC,		1,	0},
	{"SAL_STATUS",		TYPC,		1,	0},
	{"VALID_FROM",		TYPC,		1,	0},
	{"MIN_ORDER",		TYPC,		1,	0},
	{"MIN_DELY",		TYPC,		1,	0},
	{"MIN_MTO",			TYPC,		1,	0},
	{"DELY_UNIT",		TYPC,		1,	0},
	{"DELY_UOM",		TYPC,		1,	0},
	{"DELY_UOM_ISO",	TYPC,		1,	0},
	{"SALES_UNIT",		TYPC,		1,	0},
	{"SALES_UNIT_ISO",	TYPC,		1,	0},
	{"ITEM_CAT",		TYPC,		1,	0},
	{"DELYG_PLNT",		TYPC,		1,	0},
	{"PROD_HIER",		TYPC,		1,	0},
	{"PR_REF_MAT",		TYPC,		1,	0},
	{"MAT_PR_GRP",		TYPC,		1,	0},
	{"ACCT_ASSGT",		TYPC,		1,	0},
	{"MATL_GRP_1",		TYPC,		1,	0},
	{"MATL_GRP_2",		TYPC,		1,	0},
	{"MATL_GRP_3",		TYPC,		1,	0},
	{"MATL_GRP_4",		TYPC,		1,	0},
	{"MATL_GRP_5",		TYPC,		1,	0},
	{"PROD_ATT_1",		TYPC,		1,	0},
	{"PROD_ATT_2",		TYPC,		1,	0},
	{"PROD_ATT_3",		TYPC,		1,	0},
	{"PROD_ATT_4",		TYPC,		1,	0},
	{"PROD_ATT_5",		TYPC,		1,	0},
	{"PROD_ATT_6",		TYPC,		1,	0},
	{"PROD_ATT_7",		TYPC,		1,	0},
	{"PROD_ATT_8",		TYPC,		1,	0},
	{"PROD_ATT_9",		TYPC,		1,	0},
	{"PROD_ATT10",		TYPC,		1,	0},
	{"ROUND_PROF",		TYPC,		1,	0},
	{"VAR_SALES_UN",	TYPC,		1,	0},
	{"UNIT_GROUP",		TYPC,		1,	0},
	{"PR_REF_MAT_EXTERNAL",	TYPC,	1,	0},
	{"PR_REF_MAT_GUID",	TYPC,		1,	0},
	{"PR_REF_MAT_VERSION",	TYPC,	1,	0},
};
#endif
/*--------------------End BAPI_MVKEX-------------------*/
/*--------------------End BAPI_MLGT-------------------*/
#ifndef SAP_ST_BAPI_MLGT
#define SAP_ST_BAPI_MLGT
typedef struct
{
RFC_CHAR Whse_No[3];/*0	Warehouse Number / Warehouse Complex*/
RFC_CHAR Stge_Type[3];/*	0	Storage Type*/
RFC_CHAR Del_Flag[1];/*	0	Deletion flag for all material data of a storage type*/
RFC_CHAR Stge_Bin[10];/*	0	Storage Bin*/
RFC_BCD Max_Sb_Qty[7];/*	3	Maximum storage bin quantity*/
RFC_BCD Min_Sb_Qty[7];/*	3	Minimum storage bin quantity*/
RFC_BCD Ctrl_Qty[7];/*	3	Control quantity*/
RFC_BCD Replen_Qty[7];/*	3	Replenishment quantity*/
RFC_CHAR Pick_Area[3];/*	0	Picking Area*/
RFC_BCD Round_Qty[7];/*	3	Rounding qty*/
}BAPI_MLGT;
#endif

#ifndef SAP_TH_BAPI_MLGT
#define SAP_TH_BAPI_MLGT
static const RFC_TYPEHANDLE handleOfBAPI_MLGT;
static const RFC_TYPE_ELEMENT typeOfBAPI_MLGT[]=
{
	{"WHSE_NO"		,TYPC,	3,	0},
	{"STGE_TYPE"	,TYPC,	3,	0},
	{"DEL_FLAG"	,TYPC,	1,	0},
	{"STGE_BIN"	,TYPC,	10,	0},
	{"MAX_SB_QTY"	,TYPP,	7,	0},
	{"MIN_SB_QTY"	,TYPP,	7,	0},
	{"CTRL_QTY"	,TYPP,	7,	0},
	{"REPLEN_QTY"	,TYPP,	7,	0},
	{"PICK_AREA"	,TYPC,	3,	0},
	{"ROUND_QTY"	,TYPP,	7,	0},
};
#endif

/*--------------------End BAPI_MLGT-------------------*/
/*--------------------BAPI_MLGTX-------------------*/
#ifndef SAP_ST_BAPI_MLGTX
#define SAP_ST_BAPI_MLGTX
typedef struct
{
RFC_CHAR Whse_No[3];
RFC_CHAR Stge_Type[3];
RFC_CHAR Del_Flag[1];
RFC_CHAR Stge_Bin[1];
RFC_CHAR Max_Sb_Qty[1];
RFC_CHAR Min_Sb_Qty[1];
RFC_CHAR Ctrl_Qty[1];
RFC_CHAR Replen_Qty[1];
RFC_CHAR Pick_Area[1];
RFC_CHAR Round_Qty[1];
}BAPI_MLGTX;
#endif

#ifndef SAP_TH_BAPI_MLGTX
#define SAP_TH_BAPI_MLGTX
static const RFC_TYPEHANDLE handleOfBAPI_MLGTX;
static const RFC_TYPE_ELEMENT typeOfBAPI_MLGTX[]=
{
	{"WHSE_NO"		,TYPC,	3,	0},
	{"STGE_TYPE"	,TYPC,	3,	0},
	{"DEL_FLAG"		,TYPC,	1,	0},
	{"STGE_BIN"		,TYPC,	1,	0},
	{"MAX_SB_QTY"	,TYPC,	1,	0},
	{"MIN_SB_QTY"	,TYPC,	1,	0},
	{"CTRL_QTY"		,TYPC,	1,	0},
	{"REPLEN_QTY"	,TYPC,	1,	0},
	{"PICK_AREA"	,TYPC,	1,	0},
	{"ROUND_QTY"	,TYPC,	1,	0},
};
#endif
/*--------------------End BAPI_MLGTX-------------------*/
/*--------------------SY-DATAR-------------------*/
#ifndef SAP_ST_SYDATAR
#define SAP_ST_SYDATAR
typedef struct
{
RFC_CHAR	Datar[1];	/*0	Screens, display user entry*/
RFC_CHAR	Host[32];	/*0	R/3 System, Name of Application Server*/
RFC_CHAR	Locdb[1];	/*0	Obsolete*/
RFC_CHAR	Locop[1];/*0	Obsolete*/
RFC_DATE	Datlo;	/*0	Date and time, local date of user*/
RFC_TIME	Timlo[6];/*0	Date and time, local time for user*/
RFC_CHAR	Zonlo[6];	/*0	Date and time, time zone of user*/
}SYDATAR;
#endif

#ifndef SAP_TH_SYDATAR
#define SAP_TH_SYDATAR
static const RFC_TYPEHANDLE handleOfSYDATAR;
static const RFC_TYPE_ELEMENT typeOfSYDATAR[]=
{
	{"DATAR",TYPC		,1  ,	0},
	{"HOST", TYPC		,32 ,	0},
	{"LOCDB",TYPC		,1  ,	0},
	{"LOCOP",TYPC		,1  ,	0},
	{"DATLO",TYPDATE	,sizeof(RFC_DATE)  ,	0},
	{"TIMLO",TYPTIME	,6  ,	0},
	{"ZONLO",TYPC		,6  ,	0},
};
#endif
/*--------------------End SY-DATAR-------------------*/

/*--------------------SY-DATAR-------------------*/
#ifndef SAP_ST_BAPIRET2
#define SAP_ST_BAPIRET2
typedef struct
{
RFC_CHAR Type[1];
RFC_CHAR Id[20];
RFC_NUM  Number[3];
RFC_CHAR Message[220];
RFC_CHAR Log_No[20];
RFC_NUM  Log_Msg_No[6];
RFC_CHAR Message_V1[50];
RFC_CHAR Message_V2[50];
RFC_CHAR Message_V3[50];
RFC_CHAR Message_V4[50];
RFC_CHAR Parameter[32];
RFC_INT2 Row[10];
RFC_CHAR Field[30];
RFC_CHAR System[10];
}BAPIRET2;
#endif

#ifndef SAP_TH_BAPIRET2
#define SAP_TH_BAPIRET2
static const RFC_TYPEHANDLE handleOfBAPIRET2;
static const RFC_TYPE_ELEMENT typeOfBAPIRET2[]=
{
{"TYPE",TYPC,1,0},
{"ID",TYPC,20,0},
{"NUMBER",TYPNUM,3,0},
{"MESSAGE",TYPC,220,0},
{"LOG_NO",TYPC,20,0},
{"LOG_MSG_NO",TYPNUM,6,0},
{"MESSAGE_V1",TYPC,50,0},
{"MESSAGE_V2",TYPC,50,0},
{"MESSAGE_V3",TYPC,50,0},
{"MESSAGE_V4",TYPC,50,0},
{"PARAMETER",TYPC,32,0},
{"Row",TYPINT2,10,0},
{"FIELD",TYPC,30,0},
{"SYSTEM",TYPC,10,0},
};
#endif

/*--------------------End SY-DATAR-------------------*/
/*********************HERE ONWARDS TABLE STARTS********************************/
#ifndef SAP_ST_BAPI_MAKT
#define SAP_ST_BAPI_MAKT
typedef struct {
	RFC_CHAR Langu[1];
	RFC_CHAR Langu_Iso[2];
	RFC_CHAR Matl_Desc[40];
	RFC_CHAR Del_Flag[1];
} BAPI_MAKT;
#endif

#ifndef SAP_TH_BAPI_MAKT
#define SAP_TH_BAPI_MAKT
static const RFC_TYPEHANDLE handleOfBAPI_MAKT;

static const RFC_TYPE_ELEMENT typeOfBAPI_MAKT[] = {
	{"LANGU"	,TYPC,	1,	0},
	{"LANGU_ISO"	,TYPC,	2,	0},
	{"MATL_DESC"	,TYPC,	40,	0},
	{"DEL_FLAG"	,TYPC,	1,	0},
};
#endif
/**************************/

#ifndef SAP_ST_BAPI_MARM
#define SAP_ST_BAPI_MARM
typedef struct {
	RFC_CHAR Alt_Unit[3];
	RFC_CHAR Alt_Unit_Iso[3];
	RFC_BCD Numerator[3];
	RFC_BCD Denominatr[3];
	RFC_CHAR Ean_Upc[18];
	RFC_CHAR Ean_Cat[2];
	RFC_BCD Length[7];
	RFC_BCD Width[7];
	RFC_BCD Height[7];
	RFC_CHAR Unit_Dim[3];
	RFC_CHAR Unit_Dim_Iso[3];
	RFC_BCD Volume[7];
	RFC_CHAR VolumeUnit[3];
	RFC_CHAR VolumeUnit_Iso[3];
	RFC_BCD Gross_Wt[7];
	RFC_CHAR Unit_Of_Wt[3];
	RFC_CHAR Unit_Of_Wt_Iso[3];
	RFC_CHAR Del_Flag[1];
	RFC_CHAR Sub_Uom[3];
	RFC_CHAR Sub_Uom_Iso[3];
	RFC_CHAR Gtin_Variant[2];

} BAPI_MARM;
#endif

#ifndef SAP_TH_BAPI_MARM
#define SAP_TH_BAPI_MARM
static const RFC_TYPEHANDLE handleOfBAPI_MARM;

static const RFC_TYPE_ELEMENT typeOfBAPI_MARM[] = {
	{"ALT_UNIT"			,TYPC,		3,	0},
	{"ALT_UNIT_ISO"		,TYPC,		3,	0},
	{"NUMERATOR"		,TYPP,	    3,	0},
	{"DENOMINATR"		,TYPP,	    3,	0},
	{"EAN_UPC"			,TYPC,		18,	0},
	{"EAN_CAT"			,TYPC,		2,	0},
	{"LENGTH"			,TYPP,	    7,	0},
	{"WIDTH"			,TYPP,	    7,	0},
	{"HEIGHT"			,TYPP,	    7,	0},
	{"UNIT_DIM"			,TYPC,		3,	0},
	{"UNIT_DIM_ISO"		,TYPC,		3,	0},
	{"VOLUME"			,TYPP,	    7,	0},
	{"VOLUMEUNIT"		,TYPC,		3,	0},
	{"VOLUMEUNIT_ISO"	,TYPC,		3,	0},
	{"GROSS_WT"			,TYPP,	    7,	0},
	{"UNIT_OF_WT"		,TYPC,		3,	0},
	{"UNIT_OF_WT_ISO"	,TYPC,		3,	0},
	{"DEL_FLAG"			,TYPC,		1,	0},
	{"SUB_UOM"			,TYPC,		3,	0},
	{"SUB_UOM_ISO"		,TYPC,		3,	0},
	{"GTIN_VARIANT"		,TYPC,		2,	0},

};
#endif
/**************************/

#ifndef SAP_ST_BAPI_MARMX
#define SAP_ST_BAPI_MARMX
typedef struct {
	RFC_CHAR Alt_Unit[3];
	RFC_CHAR Alt_Unit_Iso[3];
	RFC_CHAR Numerator[1];
	RFC_CHAR Denominatr[1];
	RFC_CHAR Ean_Upc[1];
	RFC_CHAR Ean_Cat[1];
	RFC_CHAR Length[1];
	RFC_CHAR Width[1];
	RFC_CHAR Height[1];
	RFC_CHAR Unit_Dim[1];
	RFC_CHAR Unit_Dim_Iso[1];
	RFC_CHAR Volume[1];
	RFC_CHAR VolumeUnit[1];
	RFC_CHAR VolumeUnit_Iso[1];
	RFC_CHAR Gross_Wt[1];
	RFC_CHAR Unit_Of_Wt[1];
	RFC_CHAR Unit_Of_Wt_Iso[1];
	RFC_CHAR Sub_Uom[1];
	RFC_CHAR Sub_Uom_Iso[1];
	RFC_CHAR Gtin_Variant[1];
} BAPI_MARMX;
#endif

#ifndef SAP_TH_BAPI_MARMX
#define SAP_TH_BAPI_MARMX
static const RFC_TYPEHANDLE handleOfBAPI_MARMX;

static const RFC_TYPE_ELEMENT typeOfMARMX[] = {
	{"ALT_UNIT"			,TYPC,	3,	0},
	{"ALT_UNIT_ISO"		,TYPC,	3,	0},
	{"NUMERATOR"		,TYPC,	1,	0},
	{"DENOMINATR"		,TYPC,	1,	0},
	{"EAN_UPC"			,TYPC,	1,	0},
	{"EAN_CAT"			,TYPC,	1,	0},
	{"LENGTH"			,TYPC,	1,	0},
	{"WIDTH"			,TYPC,	1,	0},
	{"HEIGHT"			,TYPC,	1,	0},
	{"UNIT_DIM"			,TYPC,	1,	0},
	{"UNIT_DIM_ISO"		,TYPC,	1,	0},
	{"VOLUME"			,TYPC,	1,	0},
	{"VOLUMEUNIT"		,TYPC,	1,	0},
	{"VOLUMEUNIT_ISO"	,TYPC,	1,	0},
	{"GROSS_WT"			,TYPC,	1,	0},
	{"UNIT_OF_WT"		,TYPC,	1,	0},
	{"UNIT_OF_WT_ISO"	,TYPC,	1,	0},
	{"SUB_UOM"			,TYPC,	1,	0},
	{"SUB_UOM_ISO"		,TYPC,	1,	0},
	{"GTIN_VARIANT"		,TYPC,	1,	0},

};
#endif
/**************************/

#ifndef SAP_ST_BAPI_MEAN
#define SAP_ST_BAPI_MEAN
typedef struct {
	RFC_CHAR Unit[3];
	RFC_CHAR Unit_Iso[3];
	RFC_CHAR Ean_Upc[18];
	RFC_CHAR Ean_Cat[2];
	RFC_CHAR Del_Flag[1];
} BAPI_MEAN;
#endif

#ifndef SAP_TH_BAPI_MEAN
#define SAP_TH_BAPI_MEAN
static const RFC_TYPEHANDLE handleOfBAPI_MEAN;

static const RFC_TYPE_ELEMENT typeOfBAPI_MEAN[] = {
	{"UNIT"		,TYPC,	3,	0},
	{"UNIT_ISO"	,TYPC,	3,	0},
	{"EAN_UPC"	,TYPC,	18,	0},
	{"EAN_CAT"	,TYPC,	2,	0},
	{"DEL_FLAG"	,TYPC,	1,	0},
};
#endif
/**************************/

#ifndef SAP_ST_BAPI_MLTX
#define SAP_ST_BAPI_MLTX
typedef struct {
	RFC_CHAR Applobject[10];
	RFC_CHAR Text_Name[70];
	RFC_CHAR Text_Id[4];
	RFC_CHAR Langu[1];
	RFC_CHAR Langu_Iso[2];
	RFC_CHAR Format_Col[2];
	RFC_CHAR Text_Line[132];
	RFC_CHAR Del_Flag[1];

} BAPI_MLTX;
#endif

#ifndef SAP_TH_BAPI_MLTX
#define SAP_TH_BAPI_MLTX
static const RFC_TYPEHANDLE handleOfBAPI_MLTX;

static const RFC_TYPE_ELEMENT typeOfBAPI_MLTX[] = {
	{"APPLOBJECT"	,TYPC,	10,		0},
	{"TEXT_NAME"	,TYPC,	70,		0},
	{"TEXT_ID"		,TYPC,	4,		0},
	{"LANGU"		,TYPC,	1,		0},
	{"LANGU_ISO"	,TYPC,	2,		0},
	{"FORMAT_COL"	,TYPC,	2,		0},
	{"TEXT_LINE"	,TYPC,	132,	0},
	{"DEL_FLAG"		,TYPC,	1,		0},

};
#endif

/**************************/

#ifndef SAP_ST_BAPI_MLAN
#define SAP_ST_BAPI_MLAN
typedef struct {
	RFC_CHAR Depcountry[3];
	RFC_CHAR Depcountry_Iso[2];
	RFC_CHAR Tax_Type_1[4];
	RFC_CHAR Taxclass_1[1];
	RFC_CHAR Tax_Type_2[4];
	RFC_CHAR Taxclass_2[1];
	RFC_CHAR Tax_Type_3[4];
	RFC_CHAR Taxclass_3[1];
	RFC_CHAR Tax_Type_4[4];
	RFC_CHAR Taxclass_4[1];
	RFC_CHAR Tax_Type_5[4];
	RFC_CHAR Taxclass_5[1];
	RFC_CHAR Tax_Type_6[4];
	RFC_CHAR Taxclass_6[1];
	RFC_CHAR Tax_Type_7[4];
	RFC_CHAR Taxclass_7[1];
	RFC_CHAR Tax_Type_8[4];
	RFC_CHAR Taxclass_8[1];
	RFC_CHAR Tax_Type_9[4];
	RFC_CHAR Taxclass_9[1];
	RFC_CHAR Tax_Ind[1];

} BAPI_MLAN;
#endif

#ifndef SAP_TH_BAPI_MLAN
#define SAP_TH_BAPI_MLAN
static const RFC_TYPEHANDLE handleOfBAPI_MLAN;

static const RFC_TYPE_ELEMENT typeOfBAPI_MLAN[] = {
	{"DEPCOUNTRY"		,TYPC,	3,	0},
	{"DEPCOUNTRY_ISO"	,TYPC,	2,	0},
	{"TAX_TYPE_1"		,TYPC,	4,	0},
	{"TAXCLASS_1"		,TYPC,	1,	0},
	{"TAX_TYPE_2"		,TYPC,	4,	0},
	{"TAXCLASS_2"		,TYPC,	1,	0},
	{"TAX_TYPE_3"		,TYPC,	4,	0},
	{"TAXCLASS_3"		,TYPC,	1,	0},
	{"TAX_TYPE_4"		,TYPC,	4,	0},
	{"TAXCLASS_4"		,TYPC,	1,	0},
	{"TAX_TYPE_5"		,TYPC,	4,	0},
	{"TAXCLASS_5"		,TYPC,	1,	0},
	{"TAX_TYPE_6"		,TYPC,	4,	0},
	{"TAXCLASS_6"		,TYPC,	1,	0},
	{"TAX_TYPE_7"		,TYPC,	4,	0},
	{"TAXCLASS_7"		,TYPC,	1,	0},
	{"TAX_TYPE_8"		,TYPC,	4,	0},
	{"TAXCLASS_8"		,TYPC,	1,	0},
	{"TAX_TYPE_9"		,TYPC,	4,	0},
	{"TAXCLASS_9"		,TYPC,	1,	0},
	{"TAX_IND"			,TYPC,	1,	0},

};
#endif
/**************************/

#ifndef SAP_ST_BAPI_BAPI_MATRETURN2
#define SAP_ST_BAPI_BAPI_MATRETURN2
typedef struct {
	RFC_CHAR Type[1];
	RFC_CHAR Id[20];
	RFC_NUM Number[3];
	RFC_CHAR Message[220];
	RFC_CHAR Log_No[20];
	RFC_NUM Log_Msg_No[6];
	RFC_CHAR Message_V1[50];
	RFC_CHAR Message_V2[50];
	RFC_CHAR Message_V3[50];
	RFC_CHAR Message_V4[50];
	RFC_CHAR Parameter[32];
	RFC_CHAR Row[10];
	RFC_CHAR Field[30];
	RFC_CHAR System[10];

} BAPI_MATRETURN2;
#endif

#ifndef SAP_TH_BAPI_BAPI_MATRETURN2
#define SAP_TH_BAPI_BAPI_MATRETURN2
static const RFC_TYPEHANDLE handleOfBAPI_MATRETURN2;

static const RFC_TYPE_ELEMENT typeOfBAPI_BAPI_MATRETURN2[] = {
	{"TYPE"			,TYPC,	1,	0},
	{"ID"			,TYPC,	20,	0},
	{"NUMBER"		,TYPNUM,3,	0},
	{"MESSAGE"		,TYPC,	220,0},
	{"LOG_NO"		,TYPC,	20,	0},
	{"LOG_MSG_NO"	,TYPNUM,6,	0},
	{"MESSAGE_V1"	,TYPC,	50,	0},
	{"MESSAGE_V2"	,TYPC,	50,	0},
	{"MESSAGE_V3"	,TYPC,	50,	0},
	{"MESSAGE_V4"	,TYPC,	50,	0},
	{"PARAMETER"	,TYPC,	32,	0},
	{"ROW"			,TYPC,	10,	0},
	{"FIELD"		,TYPC,	30,	0},
	{"SYSTEM"		,TYPC,	10,	0},

};
#endif
/**************************/

#ifndef SAP_ST_BAPI_MFHM
#define SAP_ST_BAPI_MFHM
typedef struct {
	RFC_CHAR Plant[4];
	RFC_CHAR Create_Load_Recs[1];
	RFC_CHAR Ctrl_Key[4];
	RFC_CHAR Ctrl_Key_No_Chg[1];
	RFC_CHAR Grp_Key_1[4];
	RFC_CHAR Grp_Key_2[4];
	RFC_CHAR Prt_Usage[3];
	RFC_CHAR Std_Text_Key[7];
	RFC_CHAR Ref_Key_No_Chg[1];
	RFC_CHAR Start_Ref_Date[2];
	RFC_CHAR St_Ref_Date_No_Chg[1];
	RFC_BCD Start_Offset[3];
	RFC_CHAR Start_Offset_Unit[3];
	RFC_CHAR Start_Offset_Unit_Iso[3];
	RFC_CHAR Start_Offset_No_Chg[1];
	RFC_CHAR End_Ref_Date[2];
	RFC_CHAR End_Ref_Date_No_Chg[1];
	RFC_BCD End_Offset[3];
	RFC_CHAR End_Offset_Unit[3];
	RFC_CHAR End_Offset_Unit_Iso[3];
	RFC_CHAR End_Offset_No_Chg[1];
	RFC_CHAR Formula_Tot_Qty[6];
	RFC_CHAR Formula_Tot_Qty_No_Chg[1];
	RFC_CHAR Formula_Tot_Usage[6];
	RFC_CHAR Formula_Tot_Usage_No_Chg[1];

} BAPI_MFHM;
#endif

#ifndef SAP_TH_BAPI_MFHM
#define SAP_TH_BAPI_MFHM
static const RFC_TYPEHANDLE handleOfBAPI_MFHM;

static const RFC_TYPE_ELEMENT typeOfBAPI_MFHM[] = {
	{"PLANT"					,TYPC,		4,	0},
	{"CREATE_LOAD_RECS"			,TYPC,		1,	0},
	{"CTRL_KEY"					,TYPC,		4,	0},
	{"CTRL_KEY_NO_CHG"			,TYPC,		1,	0},
	{"GRP_KEY_1"				,TYPC,		4,	0},
	{"GRP_KEY_2"				,TYPC,		4,	0},
	{"PRT_USAGE"				,TYPC,		3,	0},
	{"STD_TEXT_KEY"				,TYPC,		7,	0},
	{"REF_KEY_NO_CHG"			,TYPC,		1,	0},
	{"START_REF_DATE"			,TYPC,		2,	0},
	{"ST_REF_DATE_NO_CHG"		,TYPC,		1,	0},
	{"START_OFFSET"				,TYPP,	    3,	0},
	{"START_OFFSET_UNIT"		,TYPC,		3,	0},
	{"START_OFFSET_UNIT_ISO"	,TYPC,		3,	0},
	{"START_OFFSET_NO_CHG"		,TYPC,		1,	0},
	{"END_REF_DATE"				,TYPC,		2,	0},
	{"END_REF_DATE_NO_CHG"		,TYPC,		1,	0},
	{"END_OFFSET"				,TYPP,	    3,	0},
	{"END_OFFSET_UNIT"			,TYPC,		3,	0},
	{"END_OFFSET_UNIT_ISO"		,TYPC,		3,	0},
	{"END_OFFSET_NO_CHG"		,TYPC,		1,	0},
	{"FORMULA_TOT_QTY"			,TYPC,		6,	0},
	{"FORMULA_TOT_QTY_NO_CHG"	,TYPC,		1,	0},
	{"FORMULA_TOT_USAGE"		,TYPC,		6,	0},
	{"FORMULA_TOT_USAGE_NO_CHG"	,TYPC,		1,	0},

};
#endif
/**************************/

#ifndef SAP_ST_BAPI_MFHMX
#define SAP_ST_BAPI_MFHMX
typedef struct {
	RFC_CHAR Plant[4];
	RFC_CHAR Create_Load_Recs[1];
	RFC_CHAR Ctrl_Key[1];
	RFC_CHAR Ctrl_Key_No_Chg[1];
	RFC_CHAR Grp_Key_1[1];
	RFC_CHAR Grp_Key_2[1];
	RFC_CHAR Prt_Usage[1];
	RFC_CHAR Std_Text_Key[1];
	RFC_CHAR Ref_Key_No_Chg[1];
	RFC_CHAR Start_Ref_Date[1];
	RFC_CHAR St_Ref_Date_No_Chg[1];
	RFC_CHAR Start_Offset[1];
	RFC_CHAR Start_Offset_Unit[1];
	RFC_CHAR Start_Offset_Unit_Iso[1];
	RFC_CHAR Start_Offset_No_Chg[1];
	RFC_CHAR End_Ref_Date[1];
	RFC_CHAR End_Ref_Date_No_Chg[1];
	RFC_CHAR End_Offset[1];
	RFC_CHAR End_Offset_Unit[1];
	RFC_CHAR End_Offset_Unit_Iso[1];
	RFC_CHAR End_Offset_No_Chg[1];
	RFC_CHAR Formula_Tot_Qty[1];
	RFC_CHAR Formula_Tot_Qty_No_Chg[1];
	RFC_CHAR Formula_Tot_Usage[1];
	RFC_CHAR Formula_Tot_Usage_No_Chg[1];
} BAPI_MFHMX;
#endif

#ifndef SAP_TH_BAPI_MFHMX
#define SAP_TH_BAPI_MFHMX
static const RFC_TYPEHANDLE handleOfBAPI_MFHMX;

static const RFC_TYPE_ELEMENT typeOfBAPI_MFHMX[] = {
	{"PLANT"					,TYPC,	4,	0},
	{"CREATE_LOAD_RECS"			,TYPC,	1,	0},
	{"CTRL_KEY"					,TYPC,	1,	0},
	{"CTRL_KEY_NO_CHG"			,TYPC,	1,	0},
	{"GRP_KEY_1"				,TYPC,	1,	0},
	{"GRP_KEY_2"				,TYPC,	1,	0},
	{"PRT_USAGE"				,TYPC,	1,	0},
	{"STD_TEXT_KEY"				,TYPC,	1,	0},
	{"REF_KEY_NO_CHG"			,TYPC,	1,	0},
	{"START_REF_DATE"			,TYPC,	1,	0},
	{"ST_REF_DATE_NO_CHG"		,TYPC,	1,	0},
	{"START_OFFSET"				,TYPC,	1,	0},
	{"START_OFFSET_UNIT"		,TYPC,	1,	0},
	{"START_OFFSET_UNIT_ISO"	,TYPC,	1,	0},
	{"START_OFFSET_NO_CHG"		,TYPC,	1,	0},
	{"END_REF_DATE"				,TYPC,	1,	0},
	{"END_REF_DATE_NO_CHG"		,TYPC,	1,	0},
	{"END_OFFSET"				,TYPC,	1,	0},
	{"END_OFFSET_UNIT"			,TYPC,	1,	0},
	{"END_OFFSET_UNIT_ISO"		,TYPC,	1,	0},
	{"END_OFFSET_NO_CHG"		,TYPC,	1,	0},
	{"FORMULA_TOT_QTY"			,TYPC,	1,	0},
	{"FORMULA_TOT_QTY_NO_CHG"	,TYPC,	1,	0},
	{"FORMULA_TOT_USAGE"		,TYPC,	1,	0},
	{"FORMULA_TOT_USAGE_NO_CHG"	,TYPC,	1,	0},
};
#endif
/**************************/

#ifndef SAP_ST_BAPIPAREX
#define SAP_ST_BAPIPAREX
typedef struct {
	RFC_CHAR Structure[30];
	RFC_CHAR Valuepart1[240];
	RFC_CHAR Valuepart2[240];
	RFC_CHAR Valuepart3[240];
	RFC_CHAR Valuepart4[240];

} BAPIPAREX;
#endif

#ifndef SAP_TH_BAPIPAREX
#define SAP_TH_BAPIPAREX
static const RFC_TYPEHANDLE handleOfBAPIPAREX;

static const RFC_TYPE_ELEMENT typeOfBAPIPAREX[] = {
	{"STRUCTURE"	,TYPC,	30,		0},
	{"VALUEPART1"	,TYPC,	240,	0},
	{"VALUEPART2"	,TYPC,	240,	0},
	{"VALUEPART3"	,TYPC,	240,	0},
	{"VALUEPART4"	,TYPC,	240,	0},

};
#endif
/**************************/

#ifndef SAP_ST_BAPIPAREXX
#define SAP_ST_BAPIPAREXX
typedef struct {
	RFC_CHAR Structure[30];
	RFC_CHAR Valuepart1[240];
	RFC_CHAR Valuepart2[240];
	RFC_CHAR Valuepart3[240];
	RFC_CHAR Valuepart4[240];

} BAPIPAREXX;
#endif

#ifndef SAP_TH_BAPIPAREXX
#define SAP_TH_BAPIPAREXX
static const RFC_TYPEHANDLE handleOfBAPIPAREXX;

static const RFC_TYPE_ELEMENT typeOfBAPIPAREXX[] = {
	{"STRUCTURE"	,TYPC,	30,		0},
	{"VALUEPART1"	,TYPC,	240,	0},
	{"VALUEPART2"	,TYPC,	240,	0},
	{"VALUEPART3"	,TYPC,	240,	0},
	{"VALUEPART4"	,TYPC,	240,	0},

};
#endif
/**************************/

#ifndef SAP_ST_NFMBAPITVGW
#define SAP_ST_NFMBAPITVGW
typedef struct {
	RFC_CHAR Plant[4];
	RFC_CHAR Orga[4];
	RFC_CHAR Distr_Chan[2];
	RFC_CHAR Nfmkey[3];
	RFC_BCD Chargewe[15];
	RFC_BCD Refqnty[5];
	RFC_CHAR Basekey[2];

} NFMBAPITVGW;
#endif

#ifndef SAP_TH_NFMBAPITVGW
#define SAP_TH_NFMBAPITVGW
static const RFC_TYPEHANDLE handleOfNFMBAPITVGW;

static const RFC_TYPE_ELEMENT typeOfNFMBAPITVGW[] = {
	{"PLANT"		,TYPC,		4,	0},
	{"ORGA"			,TYPC,		4,	0},
	{"DISTR_CHAN"	,TYPC,		2,	0},
	{"NFMKEY"		,TYPC,		3,	0},
	{"CHARGEWE"		,TYPP,	15,	3},
	{"REFQNTY"		,TYPP,	5,	0},
	{"BASEKEY"		,TYPC,		2,	0},

};
#endif
/**************************/

#ifndef SAP_ST_NFMBAPITVGWX
#define SAP_ST_NFMBAPITVGWX
typedef struct {
	RFC_CHAR Plant[4];
	RFC_CHAR Orga[4];
	RFC_CHAR Distr_Chan[2];
	RFC_CHAR Nfmkey[3];
	RFC_CHAR Chargewe[1];
	RFC_CHAR Refqnty[1];
	RFC_CHAR Basekey[1];

} NFMBAPITVGWX;
#endif

#ifndef SAP_TH_NFMBAPITVGWX
#define SAP_TH_NFMBAPITVGWX
static const RFC_TYPEHANDLE handleOfNFMBAPITVGWX;

static const RFC_TYPE_ELEMENT typeOfNFMBAPITVGWX[] = {
	{"PLANT"		,TYPC,	4,	0},
	{"ORGA"			,TYPC,	4,	0},
	{"DISTR_CHAN"	,TYPC,	2,	0},
	{"NFMKEY"		,TYPC,	3,	0},
	{"CHARGEWE"		,TYPC,	1,	0},
	{"REFQNTY"		,TYPC,	1,	0},
	{"BASEKEY"		,TYPC,	1,	0},

};
#endif
/**************************/

#ifndef SAP_ST_NFMBAPITKGW
#define SAP_ST_NFMBAPITKGW
typedef struct {
	RFC_CHAR Plant[4];
	RFC_CHAR Nfmkey[3];
	RFC_BCD Strucwe[15];
	RFC_BCD Refqnty[7];
	RFC_CHAR Baseuom[3];
	RFC_CHAR Baseuomiso[3];


} NFMBAPITKGW;
#endif

#ifndef SAP_TH_NFMBAPITKGW
#define SAP_TH_NFMBAPITKGW
static const RFC_TYPEHANDLE handleOfNFMBAPITKGW;

static const RFC_TYPE_ELEMENT typeOfNFMBAPITKGW[] = {
	{"PLANT"		,TYPC,		4,	0},
	{"NFMKEY"		,TYPC,		3,	0},
	{"STRUCWE"		,TYPP,	15,	3},
	{"REFQNTY"		,TYPP,	7,	0},
	{"BASEUOM"		,TYPC,		3,	0},
	{"BASEUOMISO"	,TYPC,		3,	0},

};
#endif
/**************************/

#ifndef SAP_ST_NFMBAPITKGWX
#define SAP_ST_NFMBAPITKGWX
typedef struct {
	RFC_CHAR Plant[4];
	RFC_CHAR Nfmkey[3];
	RFC_CHAR Strucwe[1];
	RFC_CHAR Refqnty[1];
	RFC_CHAR Baseuom[1];
} NFMBAPITKGWX;
#endif

#ifndef SAP_TH_NFMBAPITKGWX
#define SAP_TH_NFMBAPITKGWX
static const RFC_TYPEHANDLE handleOfNFMBAPITKGWX;

static const RFC_TYPE_ELEMENT typeOfNFMBAPITKGWX[] = {
	{"PLANT"	,TYPC,	4,	0},
	{"NFMKEY"	,TYPC,	3,	0},
	{"STRUCWE"	,TYPC,	1,	0},
	{"REFQNTY"	,TYPC,	1,	0},
	{"BASEUOM"	,TYPC,	1,	0},

};
#endif


#ifndef SAP_ST_RMMG1_AENNR
#define SAP_ST_RMMG1_AENNR
typedef struct {
	RFC_CHAR Aennr[12];
} RMMG1_AENNR;
#endif

#ifndef SAP_TH_RMMG1_AENNR
#define SAP_TH_RMMG1_AENNR
static const RFC_TYPEHANDLE handleOfRMMG1_AENNR;

static const RFC_TYPE_ELEMENT typeOfRMMG1_AENNR[] = {
	{"AENNR"	,TYPC,	12,	0}
};
#endif
#ifndef SAP_ST_MATNR
#define SAP_ST_MATNR
typedef struct {
  RFC_CHAR Matnr[18];
 } MATNR;
#endif

#ifndef SAP_TH_MATNR
#define SAP_TH_MATNR
static const RFC_TYPEHANDLE handleOfMATNR;

static const RFC_TYPE_ELEMENT typeOfMATNR[] = {
  {"MATNR", TYPC, 18, 0},
 };
#endif

#ifndef SAP_ST_BWTAR_D
#define SAP_ST_BWTAR_D
typedef struct {
  RFC_CHAR BwtarD[10];
 } BWTAR_D;
#endif

#ifndef SAP_TH_BWTAR_D
#define SAP_TH_BWTAR_D
static const RFC_TYPEHANDLE handleOfBWTAR_D;

static const RFC_TYPE_ELEMENT typeOfBWTAR_D[] = {
  {"BWTAR_D", TYPC, 10, 0},
 };
#endif

#ifndef SAP_ST_BKLAS
#define SAP_ST_BKLAS
typedef struct {
  RFC_CHAR Bklas[4];
 } BKLAS;
#endif


#ifndef SAP_TH_BKLAS
#define SAP_TH_BKLAS
static const RFC_TYPEHANDLE handleOfBKLAS;

static const RFC_TYPE_ELEMENT typeOfBKLAS[] = {
  {"BKLAS", TYPC, 4, 0},
 };
#endif

#ifndef SAP_ST_QPART
#define SAP_ST_QPART
typedef struct {
  RFC_CHAR Qpart[8];
 } QPART;
#endif

#ifndef SAP_TH_QPART
#define SAP_TH_QPART
static const RFC_TYPEHANDLE handleOfQPART;

static const RFC_TYPE_ELEMENT typeOfQPART[] = {
  {"QPART", TYPC, 8, 0},
 };
#endif

#ifndef SAP_ST_WERKS_D
#define SAP_ST_WERKS_D
typedef struct {
  RFC_CHAR WerksD[4];
 } WERKS_D;
#endif

#ifndef SAP_TH_WERKS_D
#define SAP_TH_WERKS_D
static const RFC_TYPEHANDLE handleOfWERKS_D;

static const RFC_TYPE_ELEMENT typeOfWERKS_D[] = {
  {"WERKS_D", TYPC, 4, 0},
 };
#endif

#ifndef SAP_ST_MESSAGEINF
#define SAP_ST_MESSAGEINF
typedef struct {
  RFC_CHAR Msgty[1];
  RFC_CHAR Msgid[20];
  RFC_CHAR Msgno[3];
  RFC_CHAR Msspc[1];
  RFC_CHAR Msgtx[255];
 } MESSAGEINF;
#endif

#ifndef SAP_TH_MESSAGEINF
#define SAP_TH_MESSAGEINF
static const RFC_TYPEHANDLE handleOfMESSAGEINF;

static const RFC_TYPE_ELEMENT typeOfMESSAGEINF[] = {
  {"MSGTY", TYPC, 1, 0},
  {"MSGID", TYPC, 20, 0},
  {"MSGNO", TYPC, 3, 0},
  {"MSSPC", TYPC, 1, 0},
  {"MSGTX", TYPC, 255, 0},
 };
#endif
/*
#ifndef SAP_FT_SYST_SUBRC
#define SAP_FT_SYST_SUBRC
typedef RFC_INT SYST_SUBRC;
#endif
*/
#ifndef SAP_FT_KLASSE_D
#define SAP_FT_KLASSE_D
typedef struct
{
RFC_CHAR KLASSE_D[18];
}KLASSE_D;
#endif


#ifndef SAP_FT_SY_SUBRC
#define SAP_FT_SY_SUBRC
typedef RFC_INT SY_SUBRC[10];
#endif

#ifndef SAP_ST_MESSAGEINF
#define SAP_ST_MESSAGEINF
typedef struct {
  RFC_CHAR Msgty[1];
  RFC_CHAR Msgid[20];
  RFC_CHAR Msgno[3];
  RFC_CHAR Msspc[1];
  RFC_CHAR Msgtx[255];
 } MESSAGEINF;
#endif

#ifndef SAP_TH_MESSAGEINF
#define SAP_TH_MESSAGEINF
static const RFC_TYPEHANDLE handleOfMESSAGEINF;

static const RFC_TYPE_ELEMENT typeOfMESSAGEINF[] = {
  {"MSGTY", TYPC, 1, 0},
  {"MSGID", TYPC, 20, 0},
  {"MSGNO", TYPC, 3, 0},
  {"MSSPC", TYPC, 1, 0},
  {"MSGTX", TYPC, 255, 0},
 };
#endif


#ifndef SAP_ST_AUSPARCH
#define SAP_ST_AUSPARCH
typedef struct
{
RFC_CHAR Mandt[3];
RFC_CHAR Objek[50];
RFC_CHAR Mafid[1];
RFC_CHAR Klart[3];
RFC_CHAR Atnam[30];
RFC_CHAR Atwrt[30];
RFC_CHAR Aennr[12];
RFC_DATE Datuv;
RFC_CHAR Lkenz[1];
RFC_NUM  Atinn[10];
}AUSPARCH;
#endif

#ifndef SAP_TH_AUSPARCH
#define SAP_TH_AUSPARCH
static const RFC_TYPEHANDLE handleOfAUSPARCH;
static const RFC_TYPE_ELEMENT typeOfAUSPARCH[]=
{
{"MANDT"	,TYPC	,3	,0},
{"OBJEK"	,TYPC	,50	,0},
{"MAFID"	,TYPC	,1	,0},
{"KLART"	,TYPC	,3	,0},
{"ATNAM"	,TYPC	,30	,0},
{"ATWRT"	,TYPC	,30	,0},
{"AENNR"	,TYPC	,12	,0},
{"DATUV"	,TYPDATE	,sizeof(RFC_DATE)	,0},
{"LKENZ"	,TYPC	,1	,0},
{"ATINN"	,TYPNUM	,10	,0},
};
#endif

#ifndef SAP_FT_SYST_SUBRC
#define SAP_FT_SYST_SUBRC
typedef RFC_INT SYST_SUBRC;
#endif

#ifndef SAP_ST_AENNR
#define SAP_ST_AENNR
typedef struct
{
  RFC_CHAR Aennr[12];
} AENNR;
#endif


#ifndef SAP_ST_CC_REVLV
#define SAP_ST_CC_REVLV
typedef struct
{
  RFC_CHAR CcRevlv[2];
} CC_REVLV;
#endif

#ifndef SAP_ST_CCMATNR
#define SAP_ST_CCMATNR
typedef struct
{
  RFC_CHAR Ccmatnr[18];
} CCMATNR;
#endif


#ifndef SAP_TH_AENNR
#define SAP_TH_AENNR
static const RFC_TYPEHANDLE handleOfAENNR;
static const RFC_TYPE_ELEMENT typeOfAENNR[] =
{
  {"AENNR", TYPC, 12, 0}
};
#endif

#ifndef SAP_TH_CCMATNR
#define SAP_TH_CCMATNR
static const RFC_TYPEHANDLE handleOfCCMATNR;
static const RFC_TYPE_ELEMENT typeOfCCMATNR[] =
{
  {"CCMATNR", TYPC, 18, 0}
};
#endif

#ifndef SAP_TH_CC_REVLV
#define SAP_TH_CC_REVLV
static const RFC_TYPEHANDLE handleOfCC_REVLV;
static const RFC_TYPE_ELEMENT typeOfCC_REVLV[] ={
  {"CC_REVLV", TYPC, 2, 0}
};
#endif

#ifndef SAP_ST_MESSAGEINF
#define SAP_ST_MESSAGEINF
typedef struct
{
  RFC_CHAR Msgty[1];
  RFC_CHAR Msgid[20];
  RFC_CHAR Msgno[3];
  RFC_CHAR Msspc[1];
  RFC_CHAR Msgtx[255];
} MESSAGEINF;
#endif
#ifndef SAP_TH_MESSAGEINF
#define SAP_TH_MESSAGEINF
static const RFC_TYPEHANDLE handleOfMESSAGEINF;

static const RFC_TYPE_ELEMENT typeOfMESSAGEINF[] = {
  {"MSGTY", TYPC, 1, 0},
  {"MSGID", TYPC, 20, 0},
  {"MSGNO", TYPC, 3, 0},
  {"MSSPC", TYPC, 1, 0},
  {"MSGTX", TYPC, 255, 0},  };
#endif

#ifndef SAP_FT_CSAP_MBOM_MATNR
#define SAP_FT_CSAP_MBOM_MATNR
typedef RFC_CHAR CSAP_MBOM_MATNR[18];
#endif

#ifndef SAP_FT_CSAP_MBOM_WERKS
#define SAP_FT_CSAP_MBOM_WERKS
typedef RFC_CHAR CSAP_MBOM_WERKS[4];
#endif

#ifndef SAP_FT_CSAP_MBOM_AENNR
#define SAP_FT_CSAP_MBOM_AENNR
typedef RFC_CHAR CSAP_MBOM_AENNR[12];
#endif

#ifndef SAP_FT_CSAP_MBOM_STLAL
#define SAP_FT_CSAP_MBOM_STLAL
typedef RFC_CHAR CSAP_MBOM_STLAL[2];
#endif

#ifndef SAP_FT_CSAP_MBOM_STLAN
#define SAP_FT_CSAP_MBOM_STLAN
typedef RFC_CHAR CSAP_MBOM_STLAN[1];
#endif

#ifndef SAP_FT_CAPIFLAG_COMM_WAIT
#define SAP_FT_CAPIFLAG_COMM_WAIT
typedef RFC_CHAR CAPIFLAG_COMM_WAIT[1];
#endif

#ifndef SAP_FT_CAPIFLAG_NO_CHG_DOC
#define SAP_FT_CAPIFLAG_NO_CHG_DOC
typedef RFC_CHAR CAPIFLAG_NO_CHG_DOC[1];
#endif

#ifndef SAP_FT_CSAP_MBOM_REVLV
#define SAP_FT_CSAP_MBOM_REVLV
typedef RFC_CHAR CSAP_MBOM_REVLV[2];
#endif

#ifndef SAP_FT_CSAP_MBOM_DATUV
#define SAP_FT_CSAP_MBOM_DATUV
typedef RFC_CHAR CSAP_MBOM_DATUV[10];
#endif

#ifndef SAP_FT_CAPIFLAG_FLWARNING
#define SAP_FT_CAPIFLAG_FLWARNING
typedef RFC_CHAR CAPIFLAG_FLWARNING[1];
#endif
#define GETBCD(var,str,dec) nbcd2str(str,var,sizeof(var),dec)
//void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals)
//{
/* convert bcd to string, e.g. bcd '01230C' length 3 decimals 2 to str
//"+012.30" */
//  char s[1024]; size_t c, strs=size<<1;
//  nbyte2str(s,bcd,size);
//  if (s[strs-1]=='D') *(str++)='-'; else *(str++)='+';
//  for(c=0;c<strs-decimals-1;c++) *(str++)=s[c];
//  if (decimals>0) { *(str++)='.'; while (c<strs-1) *(str++)=s[c++];}
//  *str=0;
//}
#define SETBCD(var,str,dec) str2nbcd(str,var,sizeof(var),dec)
//void nbyte2str(char *str,unsigned char *byte,size_t size)
//{
//  /* convert byte to string, e.g. byte 'abc' to str "818283" */
//  size_t c;
//  for ( c=0; c<size; c++ ) sprintf( &str[c<<1], "%02X", byte[c] );
//  str[size<<1] = 0;
//}
//void str2nbyte(char *str,unsigned char *byte,size_t size)
//{
//  /* convert string to byte, e.g. str "818283" to byte 'abc' */
//  size_t c; char tmp[1024]; int i;
//  strcpy(tmp,str); for (c=0;c<strlen(tmp);++c) tmp[c]=toupper(tmp[c]);
//  for (c=strlen(tmp);c<(size<<1);c++) tmp[c] = '0';
//  for (c=0;c<size;c++) { sscanf(& tmp[c<<1],"%2x",& i); byte[c]=i; }
//}
//void str2nbcd(char *str,unsigned char *bcd,size_t size, int decimals)
//{
//  /* convert string to bcd, e.g. str "+012.3" to bcd '01230C' length 3decimals  */
//  char s[1024],*p; size_t c, strs=size<<1;
//
//  if (str[0]=='-') {s[strs-1]='D'; str++;}
//  else {s[strs-1]='C'; if (str[0]=='+') str++;}
//  if (p=strchr(str,'.')) *(p++)=0; else p=str+strlen(str);
//  c=strs-1-decimals;
//  if (strlen(str)>c) memcpy(s,str+strlen(str)-c,c);
//  else {memset(s,'0',c-strlen(str));memcpy(s+c-strlen(str),str,strlen(str));}
//  while((*p) && (c < strs-1)) s[c++]=*(p++);
//  while(c < strs-1) s[c++]='0';
//  str2nbyte(s,bcd,size);
//}
/*below sprintf * will replace by sizeof(var) int value
suppose sizeof(var) =10 see below conversion
sprintf(str,"%.10s",var)
*/
#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETDATE(var,str) sprintf(str,"%.*s",sizeof(var),var)

#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
/*Set Date*/

/**/
#define SETTIME(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))

/**/

/*Set Float*/
#define SETFLOAT(var,str) *var=atof(str);
#define GETFLOAT(var,str) sprintf(str,"%f",var);

/*set int2*/
/**/
#define SETINT2(var,str) *var=atoi(str);
/*set int2*/

#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);


#define GETTIME(var,str) sprintf(str,"%.*s",sizeof(var),var);

#define SETINT1(var,str) *var=atoi(str);
#define GETINT1(var,str) sprintf(str,"%hu",var);

#define GETINT2(var,str) sprintf(str,"%d",var);

#define SETINT(var,str) *var=atol(str);
#define GETINT(var,str) sprintf(str,"%ld",var);

#ifndef SAP_FT_BAPI_DOC_AUX_HOSTNAME
#define SAP_FT_BAPI_DOC_AUX_HOSTNAME
typedef RFC_CHAR BAPI_DOC_AUX_HOSTNAME[20];
#endif

#ifndef SAP_FT_BAPI_DOC_AUX_DOCNUMBER
#define SAP_FT_BAPI_DOC_AUX_DOCNUMBER
typedef RFC_CHAR BAPI_DOC_AUX_DOCNUMBER[25];
#endif

#ifndef SAP_FT_BAPI_DOC_AUX_DOCPART
#define SAP_FT_BAPI_DOC_AUX_DOCPART
typedef RFC_CHAR BAPI_DOC_AUX_DOCPART[3];
#endif

#ifndef SAP_FT_BAPI_DOC_AUX_DOCTYPE
#define SAP_FT_BAPI_DOC_AUX_DOCTYPE
typedef RFC_CHAR BAPI_DOC_AUX_DOCTYPE[3];
#endif

#ifndef SAP_FT_BAPI_DOC_AUX_DOCVERSION
#define SAP_FT_BAPI_DOC_AUX_DOCVERSION
typedef RFC_CHAR BAPI_DOC_AUX_DOCVERSION[2];
#endif

/* structure type definition */

#ifndef SAP_ST_BAPI_DOC_DRAW
#define SAP_ST_BAPI_DOC_DRAW
typedef struct
{
	RFC_CHAR Documenttype[3];
	RFC_CHAR Documentnumber[25];
	RFC_CHAR Documentversion[2];
	RFC_CHAR Documentpart[3];
	RFC_CHAR Description[40];
	RFC_CHAR Username[12];
	RFC_CHAR Statusextern[2];
	RFC_CHAR Statusintern[2];
	RFC_CHAR Statuslog[20];
	RFC_CHAR Laboratory[3];
	RFC_CHAR Ecnumber[12];
	RFC_DATE Validfromdate;
	RFC_CHAR Deleteindicator[1];
	RFC_CHAR Cadindicator[1];
	RFC_CHAR Structureindicator[1];
	RFC_CHAR Predocumentnumber[25];
	RFC_CHAR Predocumentversion[2];
	RFC_CHAR Predocumentpart[3];
	RFC_CHAR Predocumenttype[3];
	RFC_CHAR Authoritygroup[4];
	RFC_CHAR Docfile1[255];
	RFC_CHAR Datacarrier1[10];
	RFC_CHAR Wsapplication1[3];
	RFC_CHAR Docfile2[255];
	RFC_CHAR Datacarrier2[10];
	RFC_CHAR Wsapplication2[3];
	RFC_DATE Vrldat;
	RFC_CHAR Userdefined1[14];
	RFC_CHAR Userdefined2[14];
	RFC_CHAR Userdefined3[14];
	RFC_CHAR Userdefined4[14];
	RFC_CHAR Savedocfile1[255];
	RFC_CHAR Savedatacarrier1[10];
	RFC_CHAR Savedocfile2[255];
	RFC_CHAR Savedatacarrier2[10];
	RFC_DATE Createdate;
	RFC_CHAR Refdocumentnumber[25];
	RFC_CHAR Refdocumentpart[3];
	RFC_CHAR Refdocumentversion[2];
	RFC_NUM Filesize1[12];
	RFC_NUM Filesize2[12];
} BAPI_DOC_DRAW;
#endif

#ifndef SAP_ST_BAPIRET2
#define SAP_ST_BAPIRET2
typedef struct
{
	RFC_CHAR Type[1];
	RFC_CHAR Id[20];
	RFC_NUM Number[3];
	RFC_CHAR Message[220];
	RFC_CHAR LogNo[20];
	RFC_NUM LogMsgNo[6];
	RFC_CHAR MessageV1[50];
	RFC_CHAR MessageV2[50];
	RFC_CHAR MessageV3[50];
	RFC_CHAR MessageV4[50];
	RFC_CHAR Parameter[32];
	RFC_INT Row;
	RFC_CHAR Field[30];
	RFC_CHAR System[10];
} BAPIRET2;
#endif

#ifndef SAP_ST_T_STKO
#define SAP_ST_T_STKO
typedef struct {
	RFC_CHAR BASE_QUAN[17];
	RFC_CHAR BASE_UNIT[3];
	RFC_NUM BOM_STATUS[2];
	RFC_CHAR ALT_TEXT[40];
	RFC_CHAR LABORATORY[3];
	RFC_CHAR DELETE_IND[1];
	RFC_CHAR BOM_TEXT[40];
	RFC_CHAR BOM_GROUP[18];
	RFC_CHAR AUTH_GROUP[4];
	RFC_CHAR CAD_IND[1];
	RFC_CHAR ID_GUID[32];
	RFC_CHAR BOM_NO[8];
	RFC_CHAR ALE_IND[1];
	RFC_CHAR VALID_TO[10];
	RFC_CHAR CHG_NO_TO[12];
	RFC_CHAR CREATED_ON[10];
	RFC_CHAR CREATED_BY[12];
	RFC_CHAR CHANGED_ON[10];
	RFC_CHAR CHANGED_BY[12];
	RFC_CHAR VALID_FROM[10];
	RFC_CHAR CHG_NO[12];
} T_STKO;
#endif

#ifndef SAP_TH_T_STKO
#define SAP_TH_T_STKO
static const RFC_TYPEHANDLE handleOfT_STKO;

static const RFC_TYPE_ELEMENT typeOfT_STKO[] = {
	{"BASE_QUAN"	,TYPC,	17,	0},
	{"BASE_UNIT"	,TYPC,	3,	0},
	{"BOM_STATUS"	,TYPNUM,	2,	0},
	{"ALT_TEXT"	,TYPC,	40,	0},
	{"LABORATORY"	,TYPC,	3,	0},
	{"DELETE_IND"	,TYPC,	1,	0},
	{"BOM_TEXT"	,TYPC,	40,	0},
	{"BOM_GROUP"	,TYPC,	18,	0},
	{"AUTH_GROUP"	,TYPC,	4,	0},
	{"CAD_IND"	,TYPC,	1,	0},
	{"ID_GUID"	,TYPC,	32,	0},
	{"BOM_NO"	,TYPC,	8,	0},
	{"ALE_IND"	,TYPC,	1,	0},
	{"VALID_TO"	,TYPC,	10,	0},
	{"CHG_NO_TO"	,TYPC,	12,	0},
	{"CREATED_ON"	,TYPC,	10,	0},
	{"CREATED_BY"	,TYPC,	12,	0},
	{"CHANGED_ON"	,TYPC,	10,	0},
	{"CHANGED_BY"	,TYPC,	12,	0},
	{"VALID_FROM"	,TYPC,	10,	0},
	{"CHG_NO"	,TYPC,	12,	0},
};
#endif

#ifndef SAP_ST_T_STPO
#define SAP_ST_T_STPO
typedef struct {
RFC_CHAR ITEM_CATEG [1];
RFC_CHAR ITEM_NO	[4];
RFC_CHAR  COMPONENT	[18];
RFC_CHAR COMP_QTY	[18];
RFC_CHAR COMP_UNIT	[3];
RFC_CHAR FIXED_QTY	[1];
RFC_CHAR ITEM_TEXT1	[40];
RFC_CHAR ITEM_TEXT2	[40];
RFC_CHAR SORTSTRING	[10];
RFC_CHAR REL_COST	[1];
RFC_CHAR REL_ENGIN	[1];
RFC_CHAR REL_PMAINT	[1];
RFC_CHAR REL_PROD	[1];
RFC_CHAR REL_SALES	[1];
RFC_CHAR SPARE_PART	[1];
RFC_CHAR MAT_PROVIS	[1];
RFC_CHAR BULK_MAT	[1];
RFC_CHAR REC_ALLOWD	[1];
RFC_CHAR COMP_SCRAP	[6];
RFC_CHAR OP_SCRAP	[6];
RFC_CHAR OP_NET_IND	[1];
RFC_CHAR DISTR_KEY	[4];
RFC_CHAR  EXPL_TYPE	[2];
RFC_CHAR SPPROCTYPE	[2];
RFC_CHAR SUPPLYAREA	[10];
RFC_CHAR ISSUE_LOC	[4];
RFC_CHAR LEAD_TIME	[4];
RFC_CHAR OP_LEAD_TM	[4];
RFC_CHAR OP_LT_UNIT	[3];
RFC_CHAR CO_PRODUCT	[1];
RFC_CHAR DISCON_GRP	[2];
RFC_CHAR FOLLOW_GRP	[2];
RFC_CHAR AI_GROUP	[2];
RFC_CHAR AI_STRATEG	[1];
RFC_CHAR AI_PRIO	[2];
RFC_CHAR USAGE_PROB	[3];
RFC_CHAR REFPOINT	[20];
RFC_CHAR PM_ASSMBLY	[1];
RFC_CHAR COST_ELEM	[10];
RFC_CHAR DELIV_TIME	[3];
RFC_CHAR GRP_TIME	[3];
RFC_CHAR MAT_GROUP	[9];
RFC_CHAR PRICE	    [14];
RFC_CHAR PRICE_UNIT	[6];
RFC_CHAR CURRENCY	[5];
RFC_CHAR PURCH_GRP	[3];
RFC_CHAR PURCH_ORG	[4];
RFC_CHAR VENDOR	    [10];
RFC_CHAR VSI_NO	    [17];
RFC_CHAR VSI_QTY	[17];
RFC_CHAR VSI_SIZE1	[17];
RFC_CHAR VSI_SIZE2	[17];
RFC_CHAR VSI_SIZE3	[17];
RFC_CHAR VSI_SZUNIT	[3];
RFC_CHAR VSI_FORMUL	[2];
RFC_CHAR DOCUMENT	[25];
RFC_CHAR DOC_TYPE	[3];
RFC_CHAR DOC_PART	[3];
RFC_CHAR DOC_VERS	[2];
RFC_CHAR aCLASS	[18];
RFC_CHAR CLASS_TYPE	[3];
RFC_CHAR RES_ITM_CT	[1];
RFC_CHAR SEL_COND	[1];
RFC_CHAR REQD_COMP	[1];
RFC_CHAR MULT_SELEC	[1];
RFC_CHAR REL_HLCONF	[1];
RFC_CHAR CAD_IND	[1];
RFC_CHAR ITM_IDENT	[8];
RFC_CHAR ITEM_GUID	[32];
RFC_CHAR VALID_FROM	[10];
RFC_CHAR CHANGE_NO	[12];
RFC_CHAR IDENTIFIER	[10];
RFC_CHAR ZZTD_MODEL1	[5];
RFC_CHAR ZZTD_MODEL2	[5];
RFC_CHAR SAPMP_MET_LRCH        [2];
RFC_CHAR SAPMP_MAX_FERTL       [17];
RFC_CHAR SAPMP_FIX_AS_J	[17];
RFC_CHAR SAPMP_FIX_AS_E	[17];
RFC_CHAR SAPMP_FIX_AS_L	[17];
RFC_CHAR SAPMP_ABL_ZAHL	[6];
RFC_CHAR SAPMP_RUND_FAKT       [17];
RFC_CHAR BOM_NO		[8];
RFC_NUM  ITEM_NODE	[8];
RFC_NUM ITEM_COUNT	[8];
RFC_CHAR RECURSIVE	[1];
RFC_NUM DEP_LINK	[18];
RFC_CHAR ALE_IND	[1];
RFC_CHAR VALID_TO	[10];
RFC_CHAR CHG_NO_TO	[12];
RFC_CHAR CREATED_ON	[10];
RFC_CHAR CREATED_BY	[12];
RFC_CHAR CHANGED_ON	[10];
RFC_CHAR CHANGED_BY	[12];
RFC_CHAR BOM_ALT    [2];
RFC_CHAR FLDELETE	[1];
} T_STPO;
#endif

#ifndef SAP_TH_T_STPO
#define SAP_TH_T_STPO
static const RFC_TYPEHANDLE handleOfT_STPO;

static const RFC_TYPE_ELEMENT typeOfT_STPO[] = {
{"ITEM_CATEG"     ,TYPC,    1,   0},
{"ITEM_NO"     ,TYPC, 	    4 ,  0},
{"COMPONENT"     ,TYPC,     18,   0},
{"COMP_QTY"     ,TYPC, 	    18,   0},
{"COMP_UNIT"     ,TYPC,     3,   0},
{"FIXED_QTY"     ,TYPC,     1,   0},
{"ITEM_TEXT1"     ,TYPC,    40,   0},
{"ITEM_TEXT2"     ,TYPC,    40,   0},
{"SORTSTRING"     ,TYPC,    10,   0},
{"REL_COST"     ,TYPC, 	    1,   0},
{"REL_ENGIN"     ,TYPC,     1,   0},
{"REL_PMAINT"     ,TYPC,    1,   0},
{"REL_PROD"     ,TYPC, 	    1,   0},
{"REL_SALES"     ,TYPC,     1,   0},
{"SPARE_PART"     ,TYPC,    1,   0},
{"MAT_PROVIS"     ,TYPC,    1,   0},
{"BULK_MAT"     ,TYPC, 	    1,   0},
{"REC_ALLOWD"     ,TYPC,    1,   0},
{"COMP_SCRAP"     ,TYPC,    6,   0},
{"OP_SCRAP"     ,TYPC, 	    6,   0},
{"OP_NET_IND"     ,TYPC,    1,   0},
{"DISTR_KEY"     ,TYPC,     4,   0},
{"EXPL_TYPE"     ,TYPC,     2,   0},
{"SPPROCTYPE"     ,TYPC,    2,   0},
{"SUPPLYAREA"     ,TYPC,    10,   0},
{"ISSUE_LOC"     ,TYPC,     4,   0},
{"LEAD_TIME"     ,TYPC,     4,   0},
{"OP_LEAD_TM"     ,TYPC,    4,   0},
{"OP_LT_UNIT"     ,TYPC,    3,   0},
{"CO_PRODUCT"     ,TYPC,    1,   0},
{"DISCON_GRP"     ,TYPC,    2,   0},
{"FOLLOW_GRP"     ,TYPC,    2,   0},
{"AI_GROUP"     ,TYPC, 	    2,   0},
{"AI_STRATEG"     ,TYPC,    1,   0},
{"AI_PRIO"     ,TYPC, 	    2,   0},
{"USAGE_PROB"     ,TYPC,    3,   0},
{"REFPOINT"     ,TYPC, 	    20,   0},
{"PM_ASSMBLY"     ,TYPC,    1,   0},
{"COST_ELEM"     ,TYPC,     10,   0},
{"DELIV_TIME"     ,TYPC,    3,   0},
{"GRP_TIME"     ,TYPC, 	    3,   0},
{"MAT_GROUP"     ,TYPC,     9,   0},
{"PRICE"     ,TYPC, 	    14,   0},
{"PRICE_UNIT"     ,TYPC,    6,   0},
{"CURRENCY"     ,TYPC, 	    5,   0},
{"PURCH_GRP"     ,TYPC,     3,   0},
{"PURCH_ORG"     ,TYPC,     4,   0},
{"VENDOR"     ,TYPC, 	    10,   0},
{"VSI_NO"     ,TYPC, 	    17,   0},
{"VSI_QTY"     ,TYPC, 	    17,   0},
{"VSI_SIZE1"     ,TYPC,     17,   0},
{"VSI_SIZE2"     ,TYPC,     17,   0},
{"VSI_SIZE3"     ,TYPC,     17,   0},
{"VSI_SZUNIT"     ,TYPC,    3,   0},
{"VSI_FORMUL"     ,TYPC,    2,   0},
{"DOCUMENT"     ,TYPC, 	    25,   0},
{"DOC_TYPE"     ,TYPC, 	    3,   0},
{"DOC_PART"     ,TYPC, 	    3,   0},
{"DOC_VERS"     ,TYPC, 	    2,   0},
{"aCLASS"     ,TYPC, 	    18,   0},
{"CLASS_TYPE"     ,TYPC,    3,   0},
{"RES_ITM_CT"     ,TYPC,    1,   0},
{"SEL_COND"     ,TYPC, 	    1,   0},
{"REQD_COMP"     ,TYPC,     1,   0},
{"MULT_SELEC"     ,TYPC,    1,   0},
{"REL_HLCONF"     ,TYPC,    1,   0},
{"CAD_IND"     ,TYPC, 	    1,   0},
{"ITM_IDENT"     ,TYPC,     8,   0},
{"ITEM_GUID"     ,TYPC,     32,   0},
{"VALID_FROM"     ,TYPC,    10,   0},
{"CHANGE_NO"     ,TYPC,     12,   0},
{"IDENTIFIER"     ,TYPC,    10,   0},
{"ZZTD_MODEL1"     ,TYPC,   5,   0},
{"ZZTD_MODEL2"     ,TYPC,   5,   0},
{"SAPMP_MET_LRCH"     ,TYPC,  2,   0},
{"SAPMP_MAX_FERTL"     ,TYPC, 17,   0},
{"SAPMP_FIX_AS_J"     ,TYPC,  17,   0},
{"SAPMP_FIX_AS_E"     ,TYPC,  17,   0},
{"SAPMP_FIX_AS_L"     ,TYPC,  17,   0},
{"SAPMP_ABL_ZAHL"     ,TYPC,  6,   0},
{"SAPMP_RUND_FAKT"     ,TYPC, 17,   0},
{"BOM_NO"     ,TYPC,        8,   0},
{"ITEM_NODE"     ,TYPNUM,     8,   0},
{"ITEM_COUNT"     ,TYPNUM,    8,   0},
{"RECURSIVE"     ,TYPC,     1,   0},
{"DEP_LINK"     ,TYPNUM, 	    18,   0},
{"ALE_IND"     ,TYPC, 	    1,   0},
{"VALID_TO"     ,TYPC, 	    10,   0},
{"CHG_NO_TO"     ,TYPC,     12,   0},
{"CREATED_ON"     ,TYPC,    10,   0},
{"CREATED_BY"     ,TYPC,    12,   0},
{"CHANGED_ON"     ,TYPC,    10,   0},
{"CHANGED_BY"     ,TYPC,    12,   0},
{"BOM_ALT"     ,TYPC, 	    2,  0},
{"FLDELETE"     ,TYPC, 	    1,   0},
};
#endif
#ifndef SAP_ST_PLANTDATA
#define SAP_ST_PLANTDATA
typedef struct {
RFC_CHAR  PLANT[4];
RFC_CHAR  MAINT_STAT[15];
RFC_CHAR  DEL_FLAG[1];
RFC_CHAR  ABC_ID[1];
RFC_CHAR  CRIT_PART[1];
RFC_CHAR  PUR_GROUP[3];
RFC_CHAR  ISSUE_UNIT[3];
RFC_CHAR  ISSUE_UNIT_ISO[3];
RFC_CHAR  MRPPROFILE[4];
RFC_CHAR  MRP_TYPE[2];
RFC_CHAR  MRP_CTRLER[3];
RFC_BCD	  PLND_DELRY[2];
RFC_BCD	  GR_PR_TIME[2];
RFC_CHAR  PERIOD_IND[1];
RFC_BCD	  ASSY_SCRAP[3];
RFC_CHAR  LOTSIZEKEY[2];
RFC_CHAR  PROC_TYPE	[1];
RFC_CHAR  SPPROCTYPE[2];
RFC_BCD	  REORDER_PT[7];
RFC_BCD	  SAFETY_STK[7];
RFC_BCD	  MINLOTSIZE[7];
RFC_BCD	  MAXLOTSIZE[7];
RFC_BCD	  FIXED_LOT[7];
RFC_BCD	  ROUND_VAL[7];
RFC_BCD	  MAX_STOCK[7];
RFC_BCD	  ORD_COSTS[12];
RFC_CHAR  DEP_REQ_ID[1];
RFC_CHAR  STOR_COSTS[1];
RFC_CHAR  ALT_BOM_ID[1];
RFC_CHAR  DISCONTINU[1];
RFC_DATE  EFF_O_DAY;
RFC_CHAR  FOLLOW_UP[18];
RFC_CHAR  GRP_REQMTS[1];
RFC_CHAR  MIXED_MRP[1];
RFC_CHAR  SM_KEY[3];
RFC_CHAR  BACKFLUSH[1];
RFC_CHAR  PRODUCTION_SCHEDULER[3];
RFC_BCD   PROC_TIME[3];
RFC_BCD	  SETUPTIME[3];
RFC_BCD	  INTEROP[3];
RFC_BCD	  BASE_QTY[7];
RFC_BCD	  INHSEPRODT[2];
RFC_BCD	  STGEPERIOD[3];
/*RFC_NUM	  STGE_PD_UN[3];*/
RFC_CHAR  STGE_PD_UN[3];
RFC_CHAR  STGE_PD_UN_ISO[3];
RFC_BCD	  OVER_TOL[2];
RFC_CHAR  UNLIMITED[1];
RFC_BCD	  UNDER_TOL[2];
RFC_BCD	  REPLENTIME[2];
RFC_CHAR  REPLACE_PT[1];
RFC_CHAR  IND_POST_TO_INSP_STOCK[1];
RFC_CHAR  CTRL_KEY[8];
RFC_CHAR  DOC_REQD[1];
RFC_CHAR  LOADINGGRP[4];
RFC_CHAR  BATCH_MGMT[1];
RFC_CHAR  QUOTAUSAGE[1];
RFC_BCD	  SERV_LEVEL[2];
RFC_CHAR  SPLIT_IND[1];
RFC_CHAR  AVAILCHECK[2];
RFC_CHAR  FY_VARIANT[2];
RFC_CHAR  CORR_FACT[1];
RFC_BCD	  SETUP_TIME[3];
RFC_BCD	  BASE_QTY_PLAN[7];
RFC_BCD	  SHIP_PROC_TIME[3];
RFC_CHAR  SUP_SOURCE[1];
RFC_CHAR  AUTO_P_ORD[1];
RFC_CHAR  SOURCELIST[1];
RFC_CHAR  COMM_CODE[17];
RFC_CHAR  COUNTRYORI[3];
RFC_CHAR  COUNTRYORI_ISO[2];
RFC_CHAR  REGIONORIG[3];
RFC_CHAR  COMM_CO_UN[3];
RFC_CHAR  COMM_CO_UN_ISO[3];
RFC_CHAR  EXPIMPGRP[4];
RFC_CHAR  PROFIT_CTR[10];
RFC_CHAR  PPC_PL_CAL[3];
RFC_CHAR  REP_MANUF[1];
RFC_NUM   PL_TI_FNCE[3];
RFC_CHAR  CONSUMMODE[1];
RFC_NUM   BWD_CONS[3];
RFC_NUM   FWD_CONS[3];
RFC_CHAR  VERSION_FLAG[1];
RFC_CHAR  ALTERNATIVE_BOM[2];
RFC_CHAR  BOM_USAGE[1];
RFC_CHAR  PLANLISTGRP[8];
RFC_CHAR  PLANLISTCNT[2];
RFC_BCD	  LOT_SIZE[7];
RFC_CHAR  SPECPROCTY[2];
RFC_CHAR  PROD_UNIT[3];
RFC_CHAR  PROD_UNIT_ISO[3];
RFC_CHAR  ISS_ST_LOC[4];
RFC_CHAR  MRP_GROUP[4];
RFC_BCD	  COMP_SCRAP[3];
RFC_CHAR  CERT_TYPE[4];
RFC_BCD	  CYCLE_TIME[2];
RFC_CHAR  INSP_SETUP_FLAG[1];
RFC_CHAR  COVPROFILE[3];
RFC_CHAR  CC_PH_INV[1];
RFC_CHAR  VARIANCE_KEY[6];
RFC_CHAR  SERNO_PROF[4];
RFC_CHAR  PS_CONF_MAT[18];
RFC_CHAR  REPMANPROF[4];
RFC_CHAR  NEG_STOCKS[1];
RFC_CHAR  QM_RGMTS[4];
RFC_CHAR  PLNG_CYCLE[3];
RFC_CHAR  ROUND_PROF[4];
RFC_CHAR  REFMATCONS[18];
RFC_CHAR  REFPLTCONS[4];
RFC_DATE  D_TO_REF_M;
RFC_BCD	  MULT_REF_M[3];
RFC_CHAR  AUTO_RESET[1];
RFC_CHAR  PREF_STAT_FLAG[1];
RFC_CHAR  EX_CERT_ID[1];
RFC_CHAR  EX_CERT_NO_NEW[8];
RFC_DATE  EX_CERT_DT;
RFC_CHAR  DECL_STAT_FLAG[1];
RFC_CHAR  MILIT_ID[1];
RFC_BCD	  INSP_INT[3];
RFC_CHAR  CO_PRODUCT[1];
RFC_CHAR  PLAN_STRGP[2];
RFC_CHAR  SLOC_EXPRC[4];
RFC_CHAR  BULK_MAT[1];
RFC_CHAR  CC_FIXED[1];
RFC_CHAR  DETERM_GRP[4];
RFC_CHAR  QM_AUTHGRP[6];
RFC_CHAR  TASK_LIST_TYPE[1];
RFC_CHAR  PUR_STATUS[2];
RFC_CHAR  PRODPROF[6];
RFC_CHAR  SAFTY_T_ID[1];
RFC_NUM  SAFETYTIME[2];
RFC_CHAR  PLORD_CTRL[2];
RFC_CHAR  BATCHENTRY[1];
RFC_DATE  PVALIDFROM;
RFC_CHAR  MATFRGTGRP[8];
RFC_CHAR  PRODVERSCS[4];
RFC_CHAR  MAT_CFOP[2];
RFC_CHAR  EU_LIST_NO[12];
RFC_CHAR  EU_MAT_GRP[6];
RFC_CHAR  CAS_NO[15];
RFC_CHAR  PRODCOM_NO[9];
RFC_CHAR  CTRL_CODE[16];
RFC_CHAR  JIT_RELVT[1];
RFC_CHAR  MAT_GRP_TRANS[20];
RFC_CHAR  HANDLG_GRP[4];
RFC_CHAR  SUPPLY_AREA[10];
RFC_CHAR  FAIR_SHARE_RULE[2];
RFC_CHAR  PUSH_DISTRIB[1];
RFC_BCD	  DEPLOY_HORIZ[2];
RFC_BCD	  MIN_LOT_SIZE[7];
RFC_BCD	  MAX_LOT_SIZE[7];
RFC_BCD	  FIX_LOT_SIZE[7];
RFC_BCD	  LOT_INCREMENT[7];
RFC_CHAR  PROD_CONV_TYPE[2];
RFC_CHAR  DISTR_PROF[3];
RFC_CHAR  PERIOD_PROFILE_SAFETY_TIME[3];
RFC_CHAR  FXD_PRICE[1];
RFC_CHAR  AVAIL_CHECK_ALL_PROJ_SEGMENTS[1];
RFC_CHAR  OVERALLPRF[6];
RFC_CHAR  MRP_RELEVANCY_DEP_REQUIREMENTS[1];
RFC_CHAR  MRP_AREA_EXISTS[1];
RFC_BCD	  MIN_SAFETY_STK[7];
RFC_CHAR  NO_COSTING[1];
RFC_CHAR  UNIT_GROUP[4];
RFC_CHAR  FOLLOW_UP_EXTERNAL[40];
RFC_CHAR  FOLLOW_UP_GUID[32];
RFC_CHAR  FOLLOW_UP_VERSION[10];
RFC_CHAR  REFMATCONS_EXTERNAL[40];
RFC_CHAR  REFMATCONS_GUID[32];
RFC_CHAR  REFMATCONS_VERSION[10];
RFC_CHAR  ROTATION_DATE[1];
RFC_CHAR  ORIGINAL_BATCH_FLAG[1];
RFC_CHAR  ORIGINAL_BATCH_REF_MATERIAL[18];
RFC_CHAR  PS_CONF_MAT_EXTERNAL[40];
RFC_CHAR  PS_CONF_MAT_GUID[32];
RFC_CHAR  PS_CONF_MAT_VERSION [10];
RFC_CHAR  ORIGINAL_BATCH_REF_MATERIAL_E[40];
RFC_CHAR  ORIGINAL_BATCH_REF_MATERIAL_V[10];
RFC_CHAR  ORIGINAL_BATCH_REF_MATERIAL_G[32];
} PLANTDATA;
#endif

#ifndef SAP_TH_PLANTDATA
#define SAP_TH_PLANTDATA
static const RFC_TYPEHANDLE handleOfPLANTDATA;

static const RFC_TYPE_ELEMENT typeOfPLANTDATA[] = {
{"PLANT"         ,TYPC,   4,    0},
{"MAINT_STAT"	 ,TYPC,	 15,    0},
{"DEL_FLAG"	     ,TYPC,	  1,    0},
{"ABC_ID"	     ,TYPC,	  1,    0},
{"CRIT_PART"	 ,TYPC,	  1,    0},
{"PUR_GROUP"	 ,TYPC,	  3,    0},
{"ISSUE_UNIT"	 ,TYPC,   3,    0},
{"ISSUE_UNIT_ISO",TYPC,	  3,    0},
{"MRPPROFILE"	 ,TYPC,	  4,    0},
{"MRP_TYPE"	     ,TYPC,	  2,    0},
{"MRP_CTRLER"	 ,TYPC,	  3,    0},
{"PLND_DELRY"	 ,TYPP,	  2,    0},
{"GR_PR_TIME"	 ,TYPP,	  2,    0},
{"PERIOD_IND"	 ,TYPC,	  1,    0},
{"ASSY_SCRAP"	 ,TYPP,	  3,    2},
{"LOTSIZEKEY"	 ,TYPC,	  2,    0},
{"PROC_TYPE"	 ,TYPC,	  1,    0},
{"SPPROCTYPE"	 ,TYPC,	  2,    0},
{"REORDER_PT"	 ,TYPP,	  7,    3},
{"SAFETY_STK"	 ,TYPP,	  7,    3},
{"MINLOTSIZE"	 ,TYPP,	  7,    3},
{"MAXLOTSIZE"	 ,TYPP,	  7,    3},
{"FIXED_LOT"	 ,TYPP,	  7,    3},
{"ROUND_VAL"	 ,TYPP,	  7,    3},
{"MAX_STOCK"	 ,TYPP,	  7,    3},
{"ORD_COSTS"	 ,TYPP,	  12,    4},
{"DEP_REQ_ID"	 ,TYPC,	  1,    0},
{"STOR_COSTS"	 ,TYPC,	  1,    0},
{"ALT_BOM_ID"	 ,TYPC,	  1,    0},
{"DISCONTINU"	 ,TYPC,	  1,    0},
{"EFF_O_DAY"	 ,TYPDATE,sizeof(RFC_DATE),0},
{"FOLLOW_UP"	 ,TYPC,	  18,    0},
{"GRP_REQMTS"	 ,TYPC,	  1,    0},
{"MIXED_MRP"	 ,TYPC,	  1,    0},
{"SM_KEY"	     ,TYPC,	  3,    0},
{"BACKFLUSH"	 ,TYPC,	  1,    0},
{"PRODUCTION_SCHEDULER",TYPC,    3,0},
{"PROC_TIME"        ,TYPP,	  3,    2},
{"SETUPTIME"	    ,TYPP,	  3,    2},
{"INTEROP"	        ,TYPP,	  3,    2},
{"BASE_QTY"	        ,TYPP,	  7,    3},
{"INHSEPRODT"	    ,TYPP,	  2,    0},
{"STGEPERIOD"	    ,TYPP,	  3,    0},
{"STGE_PD_UN"	    ,TYPC,  3,    0},
{"STGE_PD_UN_ISO"   ,TYPC,	  3,    0},
{"OVER_TOL"	        ,TYPP,	  2,    1},
{"UNLIMITED"	    ,TYPC,	  1,    0},
{"UNDER_TOL"	    ,TYPP,	  2,    1},
{"REPLENTIME"	    ,TYPP,	  2,    0},
{"REPLACE_PT"	    ,TYPC,	  1,    0},
{"IND_POST_TO_INSP_STOCK",TYPC,	  1,    0},
{"CTRL_KEY"            ,TYPC,	  8,    0},
{"DOC_REQD"	           ,TYPC,	  1,    0},
{"LOADINGGRP"	       ,TYPC,	  4,    0},
{"BATCH_MGMT"	       ,TYPC,	  1,    0},
{"QUOTAUSAGE"	       ,TYPC,	  1,    0},
{"SERV_LEVEL"	       ,TYPP,	  2,    1},
{"SPLIT_IND"	       ,TYPC,	  1,    0},
{"AVAILCHECK"	       ,TYPC,	  2,    0},
{"FY_VARIANT"	       ,TYPC,	  2,    0},
{"CORR_FACT"	       ,TYPC,	  1,    0},
{"SETUP_TIME"	       ,TYPP,	  3,    2},
{"BASE_QTY_PLAN"       ,TYPP,	  7,    3},
{"SHIP_PROC_TIME"      ,TYPP,	  3,    2},
{"SUP_SOURCE"	       ,TYPC,	  1,    0},
{"AUTO_P_ORD"	       ,TYPC,	  1,    0},
{"SOURCELIST"	       ,TYPC,	  1,    0},
{"COMM_CODE"	       ,TYPC,	  17,    0},
{"COUNTRYORI"	       ,TYPC,	  3,    0},
{"COUNTRYORI_ISO"      ,TYPC,	  2,    0},
{"REGIONORIG"	       ,TYPC,	  3,    0},
{"COMM_CO_UN"	       ,TYPC,     3,    0},
{"COMM_CO_UN_ISO"      ,TYPC,	  3,    0},
{"EXPIMPGRP"	       ,TYPC,	  4,    0},
{"PROFIT_CTR"	       ,TYPC,	  10,   0},
{"PPC_PL_CAL"	       ,TYPC,	  3,    0},
{"REP_MANUF"	       ,TYPC,	  1,    0},
{"PL_TI_FNCE"	       ,TYPNUM,   3,    0},
{"CONSUMMODE"	       ,TYPC,	  1,    0},
{"BWD_CONS"			   ,TYPNUM,   3,    0},
{"FWD_CONS"	           ,TYPNUM,   3,    0},
{"VERSION_FLAG"	       ,TYPC,	  1,    0},
{"ALTERNATIVE_BOM"     ,TYPC,	  2,    0},
{"BOM_USAGE"	       ,TYPC,	  1,    0},
{"PLANLISTGRP"	       ,TYPC,	  8,    0},
{"PLANLISTCNT"	       ,TYPC,	  2,    0},
{"LOT_SIZE"	           ,TYPP,	  7,    3},
{"SPECPROCTY"	       ,TYPC,	  2,    0},
{"PROD_UNIT"	       ,TYPC,     3,    0},
{"PROD_UNIT_ISO"       ,TYPC,	  3,    0},
{"ISS_ST_LOC"	       ,TYPC,	  4,    0},
{"MRP_GROUP"	       ,TYPC,	  4,    0},
{"COMP_SCRAP"	       ,TYPP,	  3,    2},
{"CERT_TYPE"	       ,TYPC,	  4,    0},
{"CYCLE_TIME"	       ,TYPP,	  2,    0},
{"INSP_SETUP_FLAG"     ,TYPC,	  1,    0},
{"COVPROFILE"	       ,TYPC,	  3,    0},
{"CC_PH_INV"	       ,TYPC,	  1,    0},
{"VARIANCE_KEY"	       ,TYPC,	  6,    0},
{"SERNO_PROF"	       ,TYPC,	  4,    0},
{"PS_CONF_MAT"	       ,TYPC,	  18,    0},
{"REPMANPROF"	       ,TYPC,	  4,    0},
{"NEG_STOCKS"	       ,TYPC,	  1,    0},
{"QM_RGMTS"	           ,TYPC,	  4,    0},
{"PLNG_CYCLE"	       ,TYPC,	  3,    0},
{"ROUND_PROF"	       ,TYPC,	  4,    0},
{"REFMATCONS"	       ,TYPC,	  18,    0},
{"REFPLTCONS"	       ,TYPC,	  4,    0},
{"D_TO_REF_M"	       ,TYPDATE	,sizeof(RFC_DATE),    0},
{"MULT_REF_M"	       ,TYPP,	  3,    2},
{"AUTO_RESET"	       ,TYPC,	  1,    0},
{"PREF_STAT_FLAG"      ,TYPC,	  1,    0},
{"EX_CERT_ID"	       ,TYPC,	  1,    0},
{"EX_CERT_NO_NEW"      ,TYPC,	  8,    0},
{"EX_CERT_DT"	       ,TYPDATE	,sizeof(RFC_DATE),    0},
{"DECL_STAT_FLAG"      ,TYPC,	  1,    0},
{"MILIT_ID"	           ,TYPC,	  1,    0},
{"INSP_INT"	           ,TYPP,	  3,    0},
{"CO_PRODUCT"	       ,TYPC,	  1,    0},
{"PLAN_STRGP"	       ,TYPC,	  2,    0},
{"SLOC_EXPRC"	       ,TYPC,	  4,    0},
{"BULK_MAT"	           ,TYPC,	  1,    0},
{"CC_FIXED"	           ,TYPC,     1,    0},
{"DETERM_GRP"	       ,TYPC,	  4,    0},
{"QM_AUTHGRP"	       ,TYPC,	  6,    0},
{"TASK_LIST_TYPE"      ,TYPC,	  1,    0},
{"PUR_STATUS"	       ,TYPC,	  2,    0},
{"PRODPROF"	           ,TYPC,	  6,    0},
{"SAFTY_T_ID"	       ,TYPC,	  1,    0},
{"SAFETYTIME"	       ,TYPNUM,  2,    0},
{"PLORD_CTRL"	       ,TYPC,	  2,    0},
{"BATCHENTRY"	       ,TYPC,	  1,    0},
{"PVALIDFROM"	       ,TYPDATE	,sizeof(RFC_DATE),    0},
{"MATFRGTGRP"	       ,TYPC,	  8,    0},
{"PRODVERSCS"	       ,TYPC,	  4,    0},
{"MAT_CFOP"	           ,TYPC,	  2,    0},
{"EU_LIST_NO"	       ,TYPC,	  12,    0},
{"EU_MAT_GRP"	       ,TYPC,	  6,    0},
{"CAS_NO"              ,TYPC,	  15,    0},
{"PRODCOM_NO"	       ,TYPC,	  9,    0},
{"CTRL_CODE"	       ,TYPC,	  16,    0},
{"JIT_RELVT"	       ,TYPC,	  1,    0},
{"MAT_GRP_TRANS"       ,TYPC,	  20,    0},
{"HANDLG_GRP"	       ,TYPC,	  4,    0},
{"SUPPLY_AREA"	       ,TYPC,	  10,    0},
{"FAIR_SHARE_RULE"     ,TYPC,	  2,    0},
{"PUSH_DISTRIB"	       ,TYPC,	  1,    0},
{"DEPLOY_HORIZ"	       ,TYPP,	  2,    0},
{"MIN_LOT_SIZE"	       ,TYPP,	  7,    3},
{"MAX_LOT_SIZE"	       ,TYPP,	  7,    3},
{"FIX_LOT_SIZE"	       ,TYPP,	  7,    3},
{"LOT_INCREMENT"       ,TYPP,	  7,    3},
{"PROD_CONV_TYPE"      ,TYPC,	  2,    0},
{"DISTR_PROF" ,TYPC,	  3,    0},
{"PERIOD_PROFILE_SAFETY_TIME" ,TYPC, 3, 0},
{"FXD_PRICE" ,TYPC,	  1,    0},
{"AVAIL_CHECK_ALL_PROJ_SEGMENTS" ,TYPC, 1, 0},
{"OVERALLPRF" ,TYPC, 6, 0},
{"MRP_RELEVANCY_DEP_REQUIREMENTS" ,TYPC, 1, 0},
{"MRP_AREA_EXISTS"   ,TYPC,	  1,    0},
{"MIN_SAFETY_STK"	 ,TYPP,	  7,    7},
{"NO_COSTING"		 ,TYPC,	  1,    0},
{"UNIT_GROUP"		 ,TYPC,	  4,    0},
{"FOLLOW_UP_EXTERNAL",TYPC,	  40,    0},
{"FOLLOW_UP_GUID"	 ,TYPC,	  32,    0},
{"FOLLOW_UP_VERSION" ,TYPC,	  10,    0},
{"REFMATCONS_EXTERNAL",TYPC,  40,    0},
{"REFMATCONS_GUID"	 ,TYPC,	  32,    0},
{"REFMATCONS_VERSION",TYPC,	  10,    0},
{"ROTATION_DATE"	 ,TYPC,	  1,    0},
{"ORIGINAL_BATCH_FLAG",TYPC,  1,    0},
{"ORIGINAL_BATCH_REF_MATERIAL" ,TYPC, 18, 0},
{"PS_CONF_MAT_EXTERNAL"	 ,TYPC,	  40,    0},
{"PS_CONF_MAT_GUID"	     ,TYPC,	  32,    0},
{"PS_CONF_MAT_VERSION"	 ,TYPC,	  10,    0},
{"ORIGINAL_BATCH_REF_MATERIAL_E"  ,TYPC, 40, 0},
{"ORIGINAL_BATCH_REF_MATERIAL_V"  ,TYPC, 10, 0},
{"ORIGINAL_BATCH_REF_MATERIAL_G"  ,TYPC, 32, 0},
};
#endif

#ifndef SAP_ST_CLIENTDATA
#define SAP_ST_CLIENTDATA
typedef struct
{
RFC_CHAR aMATERIAL[18];
RFC_CHAR IND_SECTOR[1];
RFC_CHAR MATL_TYPE[4];
RFC_DATE CREATED_ON;
RFC_CHAR CREATED_BY[12];
RFC_DATE LAST_CHNGE;
RFC_CHAR CHANGED_BY[12];
RFC_CHAR MAT_STATUS[15];
RFC_CHAR MAINT_STAT[15];
RFC_CHAR DEL_FLAG[1];
RFC_CHAR MATL_GROUP[9];
RFC_CHAR OLD_MAT_NO[18];
RFC_CHAR BASE_UOM[3];
RFC_CHAR BASE_UOM_ISO[3];
RFC_CHAR PO_UNIT[3];
RFC_CHAR PO_UNIT_ISO[3];
RFC_CHAR DOCUMENT[22];
RFC_CHAR DOC_TYPE[3];
RFC_CHAR DOC_VERS[2];
RFC_CHAR DOC_FORMAT[4];
RFC_CHAR DOC_CHG_NO[6];
RFC_CHAR PAGE_NO[3];
RFC_NUM NO_SHEETS[3];
RFC_CHAR PROD_MEMO[18];
RFC_CHAR PAGEFORMAT[4];
RFC_CHAR SIZE_DIM[32];
RFC_CHAR BASIC_MATL[48];
RFC_CHAR STD_DESCR[18];
RFC_CHAR DSN_OFFICE[3];
RFC_CHAR PUR_VALKEY[4];
RFC_BCD NET_WEIGHT[7];
RFC_CHAR UNIT_OF_WT[3];
RFC_CHAR UNIT_OF_WT_ISO[3];
RFC_CHAR CONTAINER[2];
RFC_CHAR STOR_CONDS[2];
RFC_CHAR TEMP_CONDS[2];
RFC_CHAR TRANS_GRP[4];
RFC_CHAR HAZ_MAT_NO[18];
RFC_CHAR DIVISION[2];
RFC_CHAR COMPETITOR[10];
RFC_BCD  QTY_GR_GI[7];
RFC_CHAR PROC_RULE[1];
RFC_CHAR SUP_SOURCE[1];
RFC_CHAR SEASON[4];
RFC_CHAR LABEL_TYPE[2];
RFC_CHAR LABEL_FORM[2];
RFC_CHAR PROD_HIER[18];
RFC_CHAR CAD_ID[1];
RFC_BCD  ALLOWED_WT[7];
RFC_CHAR PACK_WT_UN[3];
RFC_CHAR PACK_WT_UN_ISO[3];
RFC_BCD  ALLWD_VOL[7];
RFC_CHAR PACK_VO_UN[3];
RFC_CHAR PACK_VO_UN_ISO[3];
RFC_BCD  WT_TOL_LT[2];
RFC_BCD  VOL_TOL_LT[2];
RFC_CHAR VAR_ORD_UN[1];
RFC_CHAR CONFIGURED[1];
RFC_CHAR BATCH_MGMT[1];
RFC_CHAR SH_MAT_TYP[4];
RFC_BCD  FILL_LEVEL[2];
RFC_INT2 STACK_FACT;     ///// 5
RFC_CHAR MAT_GRP_SM[4];
RFC_CHAR AUTHORITYGROUP[4];
RFC_CHAR QM_PROCMNT[1];
RFC_CHAR CATPROFILE[9];
RFC_BCD  MINREMLIFE[3];
RFC_BCD  SHELF_LIFE[3];
RFC_BCD  STOR_PCT[2];
RFC_CHAR CONF_MATL[18];
RFC_CHAR CO_PRODUCT[1];
RFC_CHAR PR_REF_MAT[18];
RFC_CHAR PUR_STATUS[2];
RFC_CHAR SAL_STATUS[2];
RFC_DATE PVALIDFROM;
RFC_DATE SVALIDFROM;
RFC_CHAR ENVT_RLVT[1];
RFC_CHAR PROD_ALLOC[18];
RFC_CHAR QUAL_DIK[1];
RFC_CHAR MANU_MAT[40];
RFC_CHAR MFR_NO[10];
RFC_CHAR INV_MAT_NO[18];
RFC_CHAR MANUF_PROF[4];
RFC_CHAR HAZMATPROF[3];
RFC_CHAR HIGH_VISC[1];
RFC_CHAR LOOSEORLIQ[1];
RFC_CHAR CLOSED_BOX[1];
RFC_CHAR APPD_B_REC[1];
RFC_NUM  MATCMPLLVL[2];
RFC_CHAR PAR_EFF[1];
RFC_CHAR ROUND_UP_RULE_EXPIRATION_DATE[1];
RFC_CHAR PERIOD_IND_EXPIRATION_DATE[1];
RFC_CHAR PROD_COMPOSITION_ON_PACKAGING[1];
RFC_CHAR ITEM_CAT[4];
RFC_CHAR HAZ_MAT_NO_EXTERNAL[40];
RFC_CHAR HAZ_MAT_NO_GUID[32];
RFC_CHAR HAZ_MAT_NO_VERSION[10];
RFC_CHAR INV_MAT_NO_EXTERNAL[40];
RFC_CHAR INV_MAT_NO_GUID[32];
RFC_CHAR INV_MAT_NO_VERSION[10];
RFC_CHAR MATERIAL_FIXED[1];
RFC_CHAR CM_RELEVANCE_FLAG[1];
RFC_CHAR SLED_BBD[1];
RFC_CHAR GTIN_VARIANT[2];
RFC_CHAR SERIALIZATION_LEVEL[1];
RFC_CHAR PL_REF_MAT[18];
RFC_CHAR EXTMATLGRP[18];
RFC_CHAR UOMUSAGE[1];
RFC_CHAR GDS_RELEVANT[1];
RFC_CHAR MATERIAL_EXTERNAL[40];
RFC_CHAR MATERIAL_GUID[32];
RFC_CHAR MATERIAL_VERSION[10];
RFC_CHAR CONF_MATL_EXTERNAL[40];
RFC_CHAR CONF_MATL_GUID[32];
RFC_CHAR CONF_MATL_VERSION[10];
RFC_CHAR PL_REF_MAT_EXTERNAL[40];
RFC_CHAR PL_REF_MAT_GUID[32];
RFC_CHAR PL_REF_MAT_VERSION[10];
RFC_CHAR PR_REF_MAT_EXTERNAL[40];
RFC_CHAR PR_REF_MAT_GUID[32];
RFC_CHAR PR_REF_MAT_VERSION[10];
RFC_CHAR WE_ORIGIN_ACCEPTANCE[1];
}CLIENTDATA;
#endif

#ifndef SAP_TH_CLIENTDATA
#define SAP_TH_CLIENTDATA
static const RFC_TYPEHANDLE handleOfCLIENTDATA;
static const RFC_TYPE_ELEMENT typeOfCLIENTDATA[]=
{
	{"aMATERIAL",		TYPC 	,18,0 },
	{"IND_SECTOR",		TYPC 	,1 ,0 },
	{"MATL_TYPE",		TYPC 	,4 ,0 },
	{"CREATED_ON",		TYPDATE , sizeof(RFC_DATE), 0},
	{"CREATED_BY",		TYPC 	,12,0 },
	{"LAST_CHNGE",		TYPDATE , sizeof(RFC_DATE), 0},
	{"CHANGED_BY",		TYPC 	,12,0 },
	{"MAT_STATUS",		TYPC 	,15,0 },
	{"MAINT_STAT",		TYPC 	,15,0 },
	{"DEL_FLAG",		TYPC 	,1 ,0 },
	{"MATL_GROUP",		TYPC 	,9 ,0 },
	{"OLD_MAT_NO",		TYPC 	,18,0 },
	{"BASE_UOM",		TYPC 	,3 ,0 },
	{"BASE_UOM_ISO",	TYPC 	,3 ,0 },
	{"PO_UNIT",			TYPC 	,3 ,0 },
	{"PO_UNIT_ISO",		TYPC 	,3 ,0 },
	{"DOCUMENT",		TYPC 	,22,0 },
	{"DOC_TYPE",		TYPC 	,3 ,0 },
	{"DOC_VERS",		TYPC 	,2 ,0 },
	{"DOC_FORMAT",		TYPC 	,4 ,0 },
	{"DOC_CHG_NO",		TYPC 	,6 ,0 },
	{"PAGE_NO",			TYPC 	,3 ,0 },
	{"NO_SHEETS",		TYPNUM 	,3 ,0 },
	{"PROD_MEMO",		TYPC 	,18,0 },
	{"PAGEFORMAT",		TYPC 	,4 ,0 },
	{"SIZE_DIM",		TYPC 	,32,0 },
	{"BASIC_MATL",		TYPC 	,48,0 },
	{"STD_DESCR",		TYPC 	,18,0 },
	{"DSN_OFFICE",		TYPC 	,3 ,0 },
	{"PUR_VALKEY",		TYPC 	,4 ,0 },
	{"NET_WEIGHT",		TYPP 	,7 ,3 },
	{"UNIT_OF_WT",		TYPC 	,3 ,0 },
	{"UNIT_OF_WT_ISO",	TYPC 	,3 ,0 },
	{"CONTAINER",		TYPC 	,2 ,0 },
	{"STOR_CONDS",		TYPC 	,2 ,0 },
	{"TEMP_CONDS",		TYPC 	,2 ,0 },
	{"TRANS_GRP",		TYPC 	,4 ,0 },
	{"HAZ_MAT_NO",		TYPC 	,18,0 },
	{"DIVISION",		TYPC 	,2 ,0 },
	{"COMPETITOR",		TYPC 	,10,0 },
	{"QTY_GR_GI",		TYPP 	,7 ,3 },
	{"PROC_RULE",		TYPC 	,1 ,0 },
	{"SUP_SOURCE",		TYPC 	,1 ,0 },
	{"SEASON",			TYPC 	,4 ,0 },
	{"LABEL_TYPE",		TYPC 	,2 ,0 },
	{"LABEL_FORM",		TYPC 	,2 ,0 },
	{"PROD_HIER",		TYPC 	,18,0 },
	{"CAD_ID",			TYPC 	,1 ,0 },
	{"ALLOWED_WT",		TYPP 	,7 ,3 },
	{"PACK_WT_UN",		TYPC 	,3 ,0 },
	{"PACK_WT_UN_ISO",	TYPC 	,3 ,0 },
	{"ALLWD_VOL",		TYPP 	,7 ,3 },
	{"PACK_VO_UN",		TYPC 	,3 ,0 },
	{"PACK_VO_UN_ISO",	TYPC 	,3 ,0 },
	{"WT_TOL_LT",		TYPP 	,2 ,1 },
	{"VOL_TOL_LT",		TYPP 	,2 ,1 },
	{"VAR_ORD_UN",		TYPC 	,1 ,0 },
	{"CONFIGURED",		TYPC 	,1 ,0 },
	{"BATCH_MGMT",		TYPC 	,1 ,0 },
	{"SH_MAT_TYP",		TYPC 	,4 ,0 },
	{"FILL_LEVEL",		TYPP 	,2 ,0 },
	{"STACK_FACT",		TYPINT2	,sizeof(RFC_INT2) ,0 },	/////5
	{"MAT_GRP_SM",		TYPC 	,4 ,0 },
	{"AUTHORITYGROUP",	TYPC 	,4 ,0 },
	{"QM_PROCMNT",		TYPC 	,1 ,0 },
	{"CATPROFILE",		TYPC 	,9 ,0 },
	{"MINREMLIFE",		TYPP 	,3 ,0 },
	{"SHELF_LIFE",		TYPP 	,3 ,0 },
	{"STOR_PCT",		TYPP 	,2 ,0 },
	{"CONF_MATL",		TYPC 	,18,0 },
	{"CO_PRODUCT",		TYPC 	,1 ,0 },
	{"PR_REF_MAT",		TYPC 	,18,0 },
	{"PUR_STATUS",		TYPC 	,2 ,0 },
	{"SAL_STATUS",		TYPC 	,2 ,0 },
	{"PVALIDFROM",		TYPDATE , sizeof(RFC_DATE), 0},
	{"SVALIDFROM",		TYPDATE , sizeof(RFC_DATE), 0},
	{"ENVT_RLVT",		TYPC 	,1 ,0 },
	{"PROD_ALLOC",		TYPC 	,18,0 },
	{"QUAL_DIK",		TYPC 	,1 ,0 },
	{"MANU_MAT",		TYPC 	,40,0 },
	{"MFR_NO",			TYPC 	,10,0 },
	{"INV_MAT_NO",		TYPC 	,18,0 },
	{"MANUF_PROF",		TYPC 	,4 ,0 },
	{"HAZMATPROF",		TYPC 	,3 ,0 },
	{"HIGH_VISC",		TYPC 	,1 ,0 },
	{"LOOSEORLIQ",		TYPC 	,1 ,0 },
	{"CLOSED_BOX",		TYPC 	,1 ,0 },
	{"APPD_B_REC",		TYPC 	,1 ,0 },
	{"MATCMPLLVL",		TYPNUM 	,2 ,0 },
	{"PAR_EFF",			TYPC 	,1 ,0 },
	{"ROUND_UP_RULE_EXPIRATION_DATE",TYPC ,1,0 },
	{"PERIOD_IND_EXPIRATION_DATE",	 TYPC ,1,0 },
	{"PROD_COMPOSITION_ON_PACKAGING",TYPC ,1,0 },
	{"ITEM_CAT",			TYPC 	,4 ,0 },
	{"HAZ_MAT_NO_EXTERNAL",	TYPC 	,40,0 },
	{"HAZ_MAT_NO_GUID",		TYPC 	,32,0 },
	{"HAZ_MAT_NO_VERSION",	TYPC 	,10,0 },
	{"INV_MAT_NO_EXTERNAL",	TYPC 	,40,0 },
	{"INV_MAT_NO_GUID",		TYPC 	,32,0 },
	{"INV_MAT_NO_VERSION",	TYPC 	,10,0 },
	{"MATERIAL_FIXED",		TYPC 	,1 ,0 },
	{"CM_RELEVANCE_FLAG",	TYPC 	,1 ,0 },
	{"SLED_BBD",			TYPC 	,1 ,0 },
	{"GTIN_VARIANT",		TYPC 	,2 ,0 },
	{"SERIALIZATION_LEVEL",	TYPC 	,1 ,0 },
	{"PL_REF_MAT",			TYPC 	,18,0 },
	{"EXTMATLGRP",			TYPC 	,18,0 },
	{"UOMUSAGE",			TYPC 	,1 ,0 },
	{"GDS_RELEVANT",		TYPC 	,1 ,0 },
	{"MATERIAL_EXTERNAL",	TYPC 	,40,0 },
	{"MATERIAL_GUID",		TYPC 	,32,0 },
	{"MATERIAL_VERSION",	TYPC 	,10,0 },
	{"CONF_MATL_EXTERNAL",	TYPC 	,40,0 },
	{"CONF_MATL_GUID",		TYPC 	,32,0 },
	{"CONF_MATL_VERSION",	TYPC 	,10,0 },
	{"PL_REF_MAT_EXTERNAL",	TYPC 	,40,0 },
	{"PL_REF_MAT_GUID",		TYPC 	,32,0 },
	{"PL_REF_MAT_VERSION",	TYPC 	,10,0 },
	{"PR_REF_MAT_EXTERNAL",	TYPC 	,40,0 },
	{"PR_REF_MAT_GUID",		TYPC 	,32,0 },
	{"PR_REF_MAT_VERSION",	TYPC 	,10,0 },
	{"WE_ORIGIN_ACCEPTANCE",TYPC 	,1 ,0 },
};
#endif

/*
#ifndef SAP_ST_BAPI_CHARACTERISTIC_VALUES
#define SAP_ST_BAPI_CHARACTERISTIC_VALUES
typedef struct
{
	RFC_CHAR Classtype[3];
	RFC_CHAR Classname[18];
	RFC_CHAR Charname[30];
	RFC_CHAR Charvalue[30];
	RFC_CHAR Deletevalue[1];
} BAPI_CHARACTERISTIC_VALUES;
#endif

#ifndef SAP_ST_BAPI_CLASS_ALLOCATION
#define SAP_ST_BAPI_CLASS_ALLOCATION
typedef struct
{
	RFC_CHAR Classtype[3];
	RFC_CHAR Classname[18];
	RFC_CHAR Status[1];
	RFC_CHAR Standardclass[1];
	RFC_CHAR Deleteallocation[1];
	RFC_CHAR Ecnumber[12];
} BAPI_CLASS_ALLOCATION;
#endif

#ifndef SAP_ST_BAPI_DOC_DRAT
#define SAP_ST_BAPI_DOC_DRAT
typedef struct
{
	RFC_CHAR Deletevalue[1];
	RFC_CHAR Language[1];
	RFC_CHAR LanguageIso[2];
	RFC_CHAR Description[40];
	RFC_CHAR Textindicator[1];
} BAPI_DOC_DRAT;
#endif

#ifndef SAP_ST_BAPI_DOC_FILES
#define SAP_ST_BAPI_DOC_FILES
typedef struct
{
	RFC_CHAR Documenttype[3];
	RFC_CHAR Documentnumber[25];
	RFC_CHAR Documentpart[3];
	RFC_CHAR Documentversion[2];
	RFC_CHAR Originaltype[1];
	RFC_CHAR Sourcedatacarrier[10];
	RFC_CHAR Datacarrier[10];
	RFC_CHAR Wsapplication[3];
	RFC_CHAR Docfile[255];
	RFC_CHAR Statusintern[2];
	RFC_CHAR Statusextern[2];
	RFC_CHAR Statuslog[20];
} BAPI_DOC_FILES;
#endif

#ifndef SAP_ST_BAPI_DOC_STRUCTURE
#define SAP_ST_BAPI_DOC_STRUCTURE
typedef struct
{
	RFC_CHAR Deletevalue[1];
	RFC_CHAR Documenttype[3];
	RFC_CHAR Documentnumber[25];
	RFC_CHAR Documentpart[3];
	RFC_CHAR Documentversion[2];
	RFC_CHAR Quantity[18];
	RFC_CHAR Sortstring[10];
	RFC_CHAR Recallowed[1];
	RFC_CHAR CadPos[1];
} BAPI_DOC_STRUCTURE;
#endif

#ifndef SAP_ST_BAPI_DOC_TEXT
#define SAP_ST_BAPI_DOC_TEXT
typedef struct
{
	RFC_CHAR Deletevalue[1];
	RFC_CHAR Language[1];
	RFC_CHAR LanguageIso[2];
	RFC_CHAR Textline[132];
} BAPI_DOC_TEXT;
#endif

#ifndef SAP_ST_BAPI_DOC_DRAD
#define SAP_ST_BAPI_DOC_DRAD
typedef struct
{
	RFC_CHAR Deletevalue[1];
	RFC_CHAR Objecttype[10];
	RFC_CHAR Objectkey[50];
	RFC_CHAR Documentdirection[1];
	RFC_CHAR Objectdescription[40];
	RFC_CHAR Objectlinkid[32];
	RFC_CHAR Addobjecttype[30];
	RFC_CHAR Addobjectkey[50];
} BAPI_DOC_DRAD;
#endif



#ifndef SAP_TH_BAPI_DOC_DRAW
#define SAP_TH_BAPI_DOC_DRAW
static const RFC_TYPEHANDLE handleOfBAPI_DOC_DRAW;

static const RFC_TYPE_ELEMENT typeOfBAPI_DOC_DRAW[] = {
  {"DOCUMENTTYPE", TYPC, 3, 0},
  {"DOCUMENTNUMBER", TYPC, 25, 0},
  {"DOCUMENTVERSION", TYPC, 2, 0},
  {"DOCUMENTPART", TYPC, 3, 0},
  {"DESCRIPTION", TYPC, 40, 0},
  {"USERNAME", TYPC, 12, 0},
  {"STATUSEXTERN", TYPC, 2, 0},
  {"STATUSINTERN", TYPC, 2, 0},
  {"STATUSLOG", TYPC, 20, 0},
  {"LABORATORY", TYPC, 3, 0},
  {"ECNUMBER", TYPC, 12, 0},
  {"VALIDFROMDATE", TYPDATE, sizeof(RFC_DATE), 0},
  {"DELETEINDICATOR", TYPC, 1, 0},
  {"CADINDICATOR", TYPC, 1, 0},
  {"STRUCTUREINDICATOR", TYPC, 1, 0},
  {"PREDOCUMENTNUMBER", TYPC, 25, 0},
  {"PREDOCUMENTVERSION", TYPC, 2, 0},
  {"PREDOCUMENTPART", TYPC, 3, 0},
  {"PREDOCUMENTTYPE", TYPC, 3, 0},
  {"AUTHORITYGROUP", TYPC, 4, 0},
  {"DOCFILE1", TYPC, 255, 0},
  {"DATACARRIER1", TYPC, 10, 0},
  {"WSAPPLICATION1", TYPC, 3, 0},
  {"DOCFILE2", TYPC, 255, 0},
  {"DATACARRIER2", TYPC, 10, 0},
  {"WSAPPLICATION2", TYPC, 3, 0},
  {"VRLDAT", TYPDATE, sizeof(RFC_DATE), 0},
  {"USERDEFINED1", TYPC, 14, 0},
  {"USERDEFINED2", TYPC, 14, 0},
  {"USERDEFINED3", TYPC, 14, 0},
  {"USERDEFINED4", TYPC, 14, 0},
  {"SAVEDOCFILE1", TYPC, 255, 0},
  {"SAVEDATACARRIER1", TYPC, 10, 0},
  {"SAVEDOCFILE2", TYPC, 255, 0},
  {"SAVEDATACARRIER2", TYPC, 10, 0},
  {"CREATEDATE", TYPDATE, sizeof(RFC_DATE), 0},
  {"REFDOCUMENTNUMBER", TYPC, 25, 0},
  {"REFDOCUMENTPART", TYPC, 3, 0},
  {"REFDOCUMENTVERSION", TYPC, 2, 0},
  {"FILESIZE1", TYPNUM, 12, 0},
  {"FILESIZE2", TYPNUM, 12, 0},  };
#endif

#ifndef SAP_TH_BAPIRET2
#define SAP_TH_BAPIRET2
static const RFC_TYPEHANDLE handleOfBAPIRET2;

static const RFC_TYPE_ELEMENT typeOfBAPIRET2[] = {
  {"TYPE", TYPC, 1, 0},
  {"ID", TYPC, 20, 0},
  {"NUMBER", TYPNUM, 3, 0},
  {"MESSAGE", TYPC, 220, 0},
  {"LOG_NO", TYPC, 20, 0},
  {"LOG_MSG_NO", TYPNUM, 6, 0},
  {"MESSAGE_V1", TYPC, 50, 0},
  {"MESSAGE_V2", TYPC, 50, 0},
  {"MESSAGE_V3", TYPC, 50, 0},
  {"MESSAGE_V4", TYPC, 50, 0},
  {"PARAMETER", TYPC, 32, 0},
  {"ROW", TYPINT, sizeof(RFC_INT), 0},
  {"FIELD", TYPC, 30, 0},
  {"SYSTEM", TYPC, 10, 0},  };
#endif*/

/*
#ifndef SAP_TH_BAPI_CHARACTERISTIC_VALUES
#define SAP_TH_BAPI_CHARACTERISTIC_VALUES
static const RFC_TYPEHANDLE handleOfBAPI_CHARACTERISTIC_VALUES;

static const RFC_TYPE_ELEMENT typeOfBAPI_CHARACTERISTIC_VALUES[] = {
  {"CLASSTYPE", TYPC, 3, 0},
  {"CLASSNAME", TYPC, 18, 0},
  {"CHARNAME", TYPC, 30, 0},
  {"CHARVALUE", TYPC, 30, 0},
  {"DELETEVALUE", TYPC, 1, 0},  };

#endif

#ifndef SAP_TH_BAPI_CLASS_ALLOCATION
#define SAP_TH_BAPI_CLASS_ALLOCATION
static const RFC_TYPEHANDLE handleOfBAPI_CLASS_ALLOCATION;

static const RFC_TYPE_ELEMENT typeOfBAPI_CLASS_ALLOCATION[] = {
  {"CLASSTYPE", TYPC, 3, 0},
  {"CLASSNAME", TYPC, 18, 0},
  {"STATUS", TYPC, 1, 0},
  {"STANDARDCLASS", TYPC, 1, 0},
  {"DELETEALLOCATION", TYPC, 1, 0},
  {"ECNUMBER", TYPC, 12, 0},  };
#endif

#ifndef SAP_TH_BAPI_DOC_DRAT
#define SAP_TH_BAPI_DOC_DRAT
static const RFC_TYPEHANDLE handleOfBAPI_DOC_DRAT;

static const RFC_TYPE_ELEMENT typeOfBAPI_DOC_DRAT[] = {
  {"DELETEVALUE", TYPC, 1, 0},
  {"LANGUAGE", TYPC, 1, 0},
  {"LANGUAGE_ISO", TYPC, 2, 0},
  {"DESCRIPTION", TYPC, 40, 0},
  {"TEXTINDICATOR", TYPC, 1, 0},  };
#endif

#ifndef SAP_TH_BAPI_DOC_FILES
#define SAP_TH_BAPI_DOC_FILES
static const RFC_TYPEHANDLE handleOfBAPI_DOC_FILES;

static const RFC_TYPE_ELEMENT typeOfBAPI_DOC_FILES[] = {
  {"DOCUMENTTYPE", TYPC, 3, 0},
  {"DOCUMENTNUMBER", TYPC, 25, 0},
  {"DOCUMENTPART", TYPC, 3, 0},
  {"DOCUMENTVERSION", TYPC, 2, 0},
  {"ORIGINALTYPE", TYPC, 1, 0},
  {"SOURCEDATACARRIER", TYPC, 10, 0},
  {"DATACARRIER", TYPC, 10, 0},
  {"WSAPPLICATION", TYPC, 3, 0},
  {"DOCFILE", TYPC, 255, 0},
  {"STATUSINTERN", TYPC, 2, 0},
  {"STATUSEXTERN", TYPC, 2, 0},
  {"STATUSLOG", TYPC, 20, 0},  };
#endif

#ifndef SAP_TH_BAPI_DOC_STRUCTURE
#define SAP_TH_BAPI_DOC_STRUCTURE
static const RFC_TYPEHANDLE handleOfBAPI_DOC_STRUCTURE;

static const RFC_TYPE_ELEMENT typeOfBAPI_DOC_STRUCTURE[] = {
  {"DELETEVALUE", TYPC, 1, 0},
  {"DOCUMENTTYPE", TYPC, 3, 0},
  {"DOCUMENTNUMBER", TYPC, 25, 0},
  {"DOCUMENTPART", TYPC, 3, 0},
  {"DOCUMENTVERSION", TYPC, 2, 0},
  {"QUANTITY", TYPC, 18, 0},
  {"SORTSTRING", TYPC, 10, 0},
  {"RECALLOWED", TYPC, 1, 0},
  {"CAD_POS", TYPC, 1, 0},  };
#endif

#ifndef SAP_TH_BAPI_DOC_TEXT
#define SAP_TH_BAPI_DOC_TEXT
static const RFC_TYPEHANDLE handleOfBAPI_DOC_TEXT;

static const RFC_TYPE_ELEMENT typeOfBAPI_DOC_TEXT[] = {

  {"DELETEVALUE", TYPC, 1, 0},
  {"LANGUAGE", TYPC, 1, 0},
  {"LANGUAGE_ISO", TYPC, 2, 0},
  {"TEXTLINE", TYPC, 132, 0},  };
#endif

#ifndef SAP_TH_BAPI_DOC_DRAD
#define SAP_TH_BAPI_DOC_DRAD
static const RFC_TYPEHANDLE handleOfBAPI_DOC_DRAD;

static const RFC_TYPE_ELEMENT typeOfBAPI_DOC_DRAD[] = {
  {"DELETEVALUE", TYPC, 1, 0},
  {"OBJECTTYPE", TYPC, 10, 0},
  {"OBJECTKEY", TYPC, 50, 0},
  {"DOCUMENTDIRECTION", TYPC, 1, 0},
  {"OBJECTDESCRIPTION", TYPC, 40, 0},
  {"OBJECTLINKID", TYPC, 32, 0},
  {"ADDOBJECTTYPE", TYPC, 30, 0},
  {"ADDOBJECTKEY", TYPC, 50, 0},  };
#endif*/

#ifndef SAP_ST_BAPIMATHEAD1
#define SAP_ST_BAPIMATHEAD1
typedef struct
{
RFC_CHAR FUNCTION[3];
RFC_CHAR aMATERIAL[18];
RFC_CHAR IND_SECTOR[1];
RFC_CHAR MATL_TYPE[4];
RFC_CHAR BASIC_VIEW[1];
RFC_CHAR SALES_VIEW[1];
RFC_CHAR PURCHASE_VIEW[1];
RFC_CHAR MRP_VIEW[1];
RFC_CHAR FORECAST_VIEW[1];
RFC_CHAR WORK_SCHED_VIEW[1];
RFC_CHAR PRT_VIEW[1];
RFC_CHAR STORAGE_VIEW[1];
RFC_CHAR WAREHOUSE_VIEW[1];
RFC_CHAR QUALITY_VIEW[1];
RFC_CHAR ACCOUNT_VIEW[1];
RFC_CHAR COST_VIEW[1];
RFC_CHAR MATERIAL_EXTERNAL[40];
RFC_CHAR MATERIAL_GUID[32];
RFC_CHAR MATERIAL_VERSION[10];
} BAPIMATHEAD1 ;
#endif

#ifndef SAP_TH_BAPIMATHEAD1
#define SAP_TH_BAPIMATHEAD1
static const RFC_TYPEHANDLE handleOfBAPIMATHEAD1;
static const RFC_TYPE_ELEMENT typeOfBAPIMATHEAD1[]=
{
	{"FUNCTION",TYPC,3,0},
	{"aMATERIAL",TYPC,18,0},
	{"IND_SECTOR",TYPC,1,0},
	{"MATL_TYPE",TYPC,4,0},
	{"BASIC_VIEW",TYPC,1,0},
	{"SALES_VIEW",TYPC,1,0},
	{"PURCHASE_VIEW",TYPC,1,0},
	{"MRP_VIEW",TYPC,1,0},
	{"FORECAST_VIEW",TYPC,1,0},
	{"WORK_SCHED_VIEW",TYPC,1,0},
	{"PRT_VIEW",TYPC,1,0},
	{"STORAGE_VIEW",TYPC,1,0},
	{"WAREHOUSE_VIEW",TYPC,1,0},
	{"QUALITY_VIEW",TYPC,1,0},
	{"ACCOUNT_VIEW",TYPC,1,0},
	{"COST_VIEW",TYPC,1,0},
	{"MATERIAL_EXTERNAL",TYPC,40,0},
	{"MATERIAL_GUID",TYPC,32,0},
	{"MATERIAL_VERSION",TYPC,10,0},
};
#endif


#ifndef SAP_ST_BAPI_MARC1
#define SAP_ST_BAPI_MARC1
typedef struct {
RFC_CHAR  FUNCTION        [3];
RFC_CHAR  aMATERIAL	[18];
RFC_CHAR  PLANT	[4];
RFC_CHAR  DEL_FLAG	[1];
RFC_CHAR  ABC_ID	[1];
RFC_CHAR  CRIT_PART	[1];
RFC_CHAR  PUR_GROUP	[3];
RFC_CHAR	  ISSUE_UNIT	[3];
RFC_CHAR  ISSUE_UNIT_ISO [3];
RFC_CHAR  MRPPROFILE	[4];
RFC_CHAR  MRP_TYPE	[2];
RFC_CHAR  MRP_CTRLER	[3];
RFC_BCD	  PLND_DELRY	[2];
RFC_BCD	  GR_PR_TIME	[2];
RFC_CHAR  PERIOD_IND	[1];
RFC_BCD	  ASSY_SCRAP	[3];
RFC_CHAR  LOTSIZEKEY	[2];
RFC_CHAR  PROC_TYPE	[1];
RFC_CHAR  SPPROCTYPE	[2];
RFC_BCD	  REORDER_PT	[7];
RFC_BCD	  SAFETY_STK	[7];
RFC_BCD	  MINLOTSIZE	[7];
RFC_BCD	  MAXLOTSIZE	[7];
RFC_BCD	  FIXED_LOT	[7];
RFC_BCD	  ROUND_VAL	[7];
RFC_BCD	  MAX_STOCK	[7];
RFC_BCD	  ORD_COSTS	[12];
RFC_CHAR  DEP_REQ_ID	[1];
RFC_CHAR  STOR_COSTS	[1];
RFC_CHAR  ALT_BOM_ID	[1];
RFC_CHAR  DISCONTINU	[1];
RFC_DATE  EFF_O_DAY;
RFC_CHAR  FOLLOW_UP	[18];
RFC_CHAR  GRP_REQMTS	[1];
RFC_CHAR  MIXED_MRP	[1];
RFC_CHAR  SM_KEY	[3];
RFC_CHAR  BACKFLUSH	[1];
RFC_CHAR  PRODUCTION_SCHEDULER [3];
RFC_BCD   PROC_TIME      [3];
RFC_BCD	  SETUPTIME	 [3];
RFC_BCD	  INTEROP	 [3];
RFC_BCD	  BASE_QTY	 [7];
RFC_BCD	  INHSEPRODT	 [2];
RFC_BCD	  STGEPERIOD	 [3];
RFC_NUM	  STGE_PD_UN	 [3];
RFC_CHAR  STGE_PD_UN_ISO [3];
RFC_BCD	  OVER_TOL	 [2];
RFC_CHAR  UNLIMITED	 [1];
RFC_BCD	  UNDER_TOL	 [2];
RFC_BCD	  REPLENTIME	 [2];
RFC_CHAR  REPLACE_PT	 [1];
RFC_CHAR  IND_POST_TO_INSP_STOCK [1];
RFC_CHAR  CTRL_KEY         [8];
RFC_CHAR  DOC_REQD	   [1];
RFC_CHAR  LOADINGGRP	   [4];
RFC_CHAR  BATCH_MGMT	   [1];
RFC_CHAR  QUOTAUSAGE	   [1];
RFC_BCD	  SERV_LEVEL	   [2];
RFC_CHAR  SPLIT_IND	   [1];
RFC_CHAR  AVAILCHECK	   [2];
RFC_CHAR  FY_VARIANT	   [2];
RFC_CHAR  CORR_FACT	   [1];
RFC_BCD	  SETUP_TIME	   [3];
RFC_BCD	  BASE_QTY_PLAN	   [7];
RFC_BCD	  SHIP_PROC_TIME   [3];
RFC_CHAR  SUP_SOURCE	   [1];
RFC_CHAR  AUTO_P_ORD	   [1];
RFC_CHAR  SOURCELIST	   [1];
RFC_CHAR  COMM_CODE	   [17];
RFC_CHAR  COUNTRYORI	   [3];
RFC_CHAR  COUNTRYORI_ISO   [2];
RFC_CHAR  REGIONORIG	   [3];
RFC_CHAR  COMM_CO_UN	   [3];
RFC_CHAR  COMM_CO_UN_ISO   [3];
RFC_CHAR  EXPIMPGRP	   [4];
RFC_CHAR  PROFIT_CTR	   [10];
RFC_CHAR  PPC_PL_CAL	   [3];
RFC_CHAR  REP_MANUF	   [1];
RFC_NUM  PL_TI_FNCE	   [3];
RFC_CHAR  CONSUMMODE	   [1];
RFC_NUM  BWD_CONS	   [3];
RFC_NUM  FWD_CONS	   [3];
RFC_CHAR  ALTERNATIVE_BOM  [2];
RFC_CHAR  BOM_USAGE	   [1];
RFC_CHAR  PLANLISTGRP	   [8];
RFC_CHAR  PLANLISTCNT	   [2];
RFC_BCD	  LOT_SIZE	   [7];
RFC_CHAR  SPECPROCTY	   [2];
RFC_CHAR  PROD_UNIT	   [3];
RFC_CHAR  PROD_UNIT_ISO	   [3];
RFC_CHAR  ISS_ST_LOC	   [4];
RFC_CHAR  MRP_GROUP	   [4];
RFC_BCD	  COMP_SCRAP	   [3];
RFC_CHAR  CERT_TYPE	   [4];
RFC_BCD	  CYCLE_TIME	   [2];
RFC_CHAR  COVPROFILE	   [3];
RFC_CHAR  CC_PH_INV	   [1];
RFC_CHAR  VARIANCE_KEY	   [6];
RFC_CHAR  SERNO_PROF	   [4];
RFC_CHAR  REPMANPROF	   [4];
RFC_CHAR  NEG_STOCKS	   [1];
RFC_CHAR  QM_RGMTS			[4];
RFC_CHAR  PLNG_CYCLE	   [3];
RFC_CHAR  ROUND_PROF	   [4];
RFC_CHAR  REFMATCONS	   [18];
RFC_DATE  D_TO_REF_M;
RFC_BCD	  MULT_REF_M	   [3];
RFC_CHAR  AUTO_RESET	   [1];
RFC_CHAR  EX_CERT_ID	   [1];
RFC_CHAR  EX_CERT_NO_NEW   [8];
RFC_DATE  EX_CERT_DT;
RFC_CHAR  MILIT_ID			[1];
RFC_BCD	  INSP_INT			[3];
RFC_CHAR  CO_PRODUCT	   [1];
RFC_CHAR  PLAN_STRGP	   [2];
RFC_CHAR  SLOC_EXPRC	   [4];
RFC_CHAR  BULK_MAT			[1];
RFC_CHAR  CC_FIXED			[1];
RFC_CHAR  DETERM_GRP	   [4];
RFC_CHAR  QM_AUTHGRP	   [6];
RFC_CHAR  TASK_LIST_TYPE   [1];
RFC_CHAR  PUR_STATUS	   [2];
RFC_CHAR  PRODPROF	   [6];
RFC_CHAR  SAFTY_T_ID	   [1];
RFC_NUM  SAFETYTIME	   [2];
RFC_CHAR  PLORD_CTRL	   [2];
RFC_CHAR  BATCHENTRY	   [1];
RFC_DATE  PVALIDFROM;
RFC_CHAR  MATFRGTGRP	   [8];
RFC_CHAR  PRODVERSCS	   [4];
RFC_CHAR  MAT_CFOP	   [2];
RFC_CHAR  EU_LIST_NO	   [12];
RFC_CHAR  EU_MAT_GRP	   [6];
RFC_CHAR  CAS_NO	   [15];
RFC_CHAR  PRODCOM_NO	   [9];
RFC_CHAR  CTRL_CODE	   [16];
RFC_CHAR  JIT_RELVT	   [1];
RFC_CHAR  MAT_GRP_TRANS	   [20];
RFC_CHAR  HANDLG_GRP	   [4];
RFC_CHAR  SUPPLY_AREA	   [10];
RFC_CHAR  FAIR_SHARE_RULE  [2];
RFC_CHAR  PUSH_DISTRIB	   [1];
RFC_BCD	  DEPLOY_HORIZ	   [2];
RFC_BCD	  MIN_LOT_SIZE	   [7];
RFC_BCD	  MAX_LOT_SIZE	   [7];
RFC_BCD	  FIX_LOT_SIZE	   [7];
RFC_BCD	  LOT_INCREMENT	   [7];
RFC_CHAR  PROD_CONV_TYPE   [2];
RFC_CHAR  DISTR_PROF	   [3];
RFC_CHAR  PERIOD_PROFILE_SAFETY_TIME    [3];
RFC_CHAR  FXD_PRICE	[1];
RFC_CHAR  AVAIL_CHECK_ALL_PROJ_SEGMENTS	[1];
RFC_CHAR  OVERALLPRF	[6];
RFC_CHAR  MRP_RELEVANCY_DEP_REQUIREMENTS [1];
RFC_BCD	  MIN_SAFETY_STK       [7];
RFC_CHAR  NO_COSTING	[1];
RFC_CHAR  UNIT_GROUP	[4];
RFC_CHAR  FOLLOW_UP_EXTERNAL   [40];
RFC_CHAR  FOLLOW_UP_GUID       [32];
RFC_CHAR  FOLLOW_UP_VERSION    [10];
RFC_CHAR  REFMATCONS_EXTERNAL  [40];
RFC_CHAR  REFMATCONS_GUID      [32];
RFC_CHAR  REFMATCONS_VERSION   [10];
RFC_CHAR  SALES_VIEW   [1];
RFC_CHAR  PURCH_VIEW   [1];
RFC_CHAR  MRP_VIEW   [1];
RFC_CHAR  FORECAST_VIEW   [1];
RFC_CHAR  WORK_SCHED_VIEW   [1];
RFC_CHAR  PRT_VIEW   [1];
RFC_CHAR  STORAGE_VIEW   [1];
RFC_CHAR  WAREHOUSE_VIEW   [1];
RFC_CHAR  QUALITY_VIEW   [1];
RFC_CHAR  ACCOUNT_VIEW   [1];
RFC_CHAR  COST_VIEW   [1];
RFC_CHAR  ROTATION_DATE	       [1];
RFC_CHAR  ORIGINAL_BATCH_FLAG  [1];
RFC_CHAR  ORIGINAL_BATCH_REF_MATERIAL   [18];
RFC_CHAR  MATERIAL_EXTERNAL   [40];
RFC_CHAR  MATERIAL_GUID   [32];
RFC_CHAR  MATERIAL_VERSION   [10];
RFC_CHAR  ORIGINAL_BATCH_REF_MATERIAL_E	[40];
RFC_CHAR  ORIGINAL_BATCH_REF_MATERIAL_V	[10];
RFC_CHAR  ORIGINAL_BATCH_REF_MATERIAL_G	[32];
} BAPI_MARC1;
#endif

#ifndef SAP_TH_BAPI_MARC1
#define SAP_TH_BAPI_MARC1
static const RFC_TYPEHANDLE handleOfBAPI_MARC1;

static const RFC_TYPE_ELEMENT typeOfBAPI_MARC1[] = {
{"FUNCTION"            ,TYPC,    3,    0},
{"aMATERIAL"	    ,TYPC,	  18,    0},
{"PLANT"	    ,TYPC,	  4,    0},
{"DEL_FLAG"	    ,TYPC,	  1,    0},
{"ABC_ID"	    ,TYPC,	  1,    0},
{"CRIT_PART"	    ,TYPC,	  1,    0},
{"PUR_GROUP"	    ,TYPC,	  3,    0},
{"ISSUE_UNIT"	    ,TYPC,  3,    0},
{"ISSUE_UNIT_ISO"   ,TYPC,	  3,    0},
{"MRPPROFILE"	    ,TYPC,	  4,    0},
{"MRP_TYPE"	    ,TYPC,	  2,    0},
{"MRP_CTRLER"	    ,TYPC,	  3,    0},
{"PLND_DELRY"	    ,TYPP,	  2,    0},
{"GR_PR_TIME"	    ,TYPP,	  2,    0},
{"PERIOD_IND"	    ,TYPC,	  1,    0},
{"ASSY_SCRAP"	    ,TYPP,	  3,    2},
{"LOTSIZEKEY"	    ,TYPC,	  2,    0},
{"PROC_TYPE"	    ,TYPC,	  1,    0},
{"SPPROCTYPE"	    ,TYPC,	  2,    0},
{"REORDER_PT"	    ,TYPP,	  7,    3},
{"SAFETY_STK"	    ,TYPP,	  7,    3},
{"MINLOTSIZE"	    ,TYPP,	  7,    3},
{"MAXLOTSIZE"	    ,TYPP,	  7,    3},
{"FIXED_LOT"	    ,TYPP,	  7,    3},
{"ROUND_VAL"	    ,TYPP,	  7,    3},
{"MAX_STOCK"	    ,TYPP,	  7,    3},
{"ORD_COSTS"	    ,TYPP,	  12,    4},
{"DEP_REQ_ID"	    ,TYPC,	  1,    0},
{"STOR_COSTS"	    ,TYPC,	  1,    0},
{"ALT_BOM_ID"	    ,TYPC,	  1,    0},
{"DISCONTINU"	    ,TYPC,	  1,    0},
{"EFF_O_DAY"	    ,TYPDATE	,sizeof(RFC_DATE),    0},
{"FOLLOW_UP"	    ,TYPC,	  18,    0},
{"GRP_REQMTS"	    ,TYPC,	  1,    0},
{"MIXED_MRP"	    ,TYPC,	  1,    0},
{"SM_KEY"	    ,TYPC,	  3,    0},
{"BACKFLUSH"	    ,TYPC,	  1,    0},
{"PRODUCTION_SCHEDULER"  ,TYPC,    3,    0},
{"PROC_TIME"        ,TYPP,	  3,    2},
{"SETUPTIME"	    ,TYPP,	  3,    2},
{"INTEROP"	    ,TYPP,	  3,    2},
{"BASE_QTY"	    ,TYPP,	  7,    3},
{"INHSEPRODT"	    ,TYPP,	  2,    0},
{"STGEPERIOD"	    ,TYPP,	  3,    0},
{"STGE_PD_UN"	    ,TYPNUM,  3,    0},
{"STGE_PD_UN_ISO"   ,TYPC,	  3,    0},
{"OVER_TOL"	    ,TYPP,	  2,    1},
{"UNLIMITED"	    ,TYPC,	  1,    0},
{"UNDER_TOL"	    ,TYPP,	  2,    1},
{"REPLENTIME"	    ,TYPP,	  2,    0},
{"REPLACE_PT"	    ,TYPC,	  1,    0},
{"IND_POST_TO_INSP_STOCK"  ,TYPC,	  1,    0},
{"CTRL_KEY"            ,TYPC,	  8,    0},
{"DOC_REQD"	       ,TYPC,	  1,    0},
{"LOADINGGRP"	       ,TYPC,	  4,    0},
{"BATCH_MGMT"	       ,TYPC,	  1,    0},
{"QUOTAUSAGE"	       ,TYPC,	  1,    0},
{"SERV_LEVEL"	       ,TYPP,	  2,    1},
{"SPLIT_IND"	       ,TYPC,	  1,    0},
{"AVAILCHECK"	       ,TYPC,	  2,    0},
{"FY_VARIANT"	       ,TYPC,	  2,    0},
{"CORR_FACT"	       ,TYPC,	  1,    0},
{"SETUP_TIME"	       ,TYPP,	  3,    2},
{"BASE_QTY_PLAN"       ,TYPP,	  7,    3},
{"SHIP_PROC_TIME"      ,TYPP,	  3,    2},
{"SUP_SOURCE"	       ,TYPC,	  1,    0},
{"AUTO_P_ORD"	       ,TYPC,	  1,    0},
{"SOURCELIST"	       ,TYPC,	  1,    0},
{"COMM_CODE"	       ,TYPC,	  17,    0},
{"COUNTRYORI"	       ,TYPC,	  3,    0},
{"COUNTRYORI_ISO"      ,TYPC,	  2,    0},
{"REGIONORIG"	       ,TYPC,	  3,    0},
{"COMM_CO_UN"	       ,TYPC,  3,    0},
{"COMM_CO_UN_ISO"      ,TYPC,	  3,    0},
{"EXPIMPGRP"	       ,TYPC,	  4,    0},
{"PROFIT_CTR"	       ,TYPC,	  10,    0},
{"PPC_PL_CAL"	       ,TYPC,	  3,    0},
{"REP_MANUF"	       ,TYPC,	  1,    0},
{"PL_TI_FNCE"	       ,TYPNUM,  3,    0},
{"CONSUMMODE"	       ,TYPC,	  1,    0},
{"BWD_CONS"	       ,TYPNUM,  3,    0},
{"FWD_CONS"	       ,TYPNUM,  3,    0},
{"ALTERNATIVE_BOM"     ,TYPC,	  2,    0},
{"BOM_USAGE"	       ,TYPC,	  1,    0},
{"PLANLISTGRP"	       ,TYPC,	  8,    0},
{"PLANLISTCNT"	       ,TYPC,	  2,    0},
{"LOT_SIZE"	       ,TYPP,	  7,    3},
{"SPECPROCTY"	       ,TYPC,	  2,    0},
{"PROD_UNIT"	       ,TYPC,  3,    0},
{"PROD_UNIT_ISO"       ,TYPC,	  3,    0},
{"ISS_ST_LOC"	       ,TYPC,	  4,    0},
{"MRP_GROUP"	       ,TYPC,	  4,    0},
{"COMP_SCRAP"	       ,TYPP,	  3,    2},
{"CERT_TYPE"	       ,TYPC,	  4,    0},
{"CYCLE_TIME"	       ,TYPP,	  2,    0},
{"COVPROFILE"	       ,TYPC,	  3,    0},
{"CC_PH_INV"	       ,TYPC,	  1,    0},
{"VARIANCE_KEY"	       ,TYPC,	  6,    0},
{"SERNO_PROF"	       ,TYPC,	  4,    0},
{"REPMANPROF"	       ,TYPC,	  4,    0},
{"NEG_STOCKS"	       ,TYPC,	  1,    0},
{"QM_RGMTS"	       ,TYPC,	  4,    0},
{"PLNG_CYCLE"	       ,TYPC,	  3,    0},
{"ROUND_PROF"	       ,TYPC,	  4,    0},
{"REFMATCONS"	       ,TYPC,	  18,    0},
{"D_TO_REF_M"	       ,TYPDATE	,sizeof(RFC_DATE),    0},
{"MULT_REF_M"	       ,TYPP,	  3,    2},
{"AUTO_RESET"	       ,TYPC,	  1,    0},
{"EX_CERT_ID"	       ,TYPC,	  1,    0},
{"EX_CERT_NO_NEW"      ,TYPC,	  8,    0},
{"EX_CERT_DT"	       ,TYPDATE	,sizeof(RFC_DATE),    0},
{"MILIT_ID"	       ,TYPC,	  1,    0},
{"INSP_INT"	       ,TYPP,	  3,    0},
{"CO_PRODUCT"	       ,TYPC,	  1,    0},
{"PLAN_STRGP"	       ,TYPC,	  2,    0},
{"SLOC_EXPRC"	       ,TYPC,	  4,    0},
{"BULK_MAT"	       ,TYPC,	  1,    0},
{"CC_FIXED"	       ,TYPC,    1,    0},
{"DETERM_GRP"	       ,TYPC,	  4,    0},
{"QM_AUTHGRP"	       ,TYPC,	  6,    0},
{"TASK_LIST_TYPE"      ,TYPC,	  1,    0},
{"PUR_STATUS"	       ,TYPC,	  2,    0},
{"PRODPROF"	       ,TYPC,	  6,    0},
{"SAFTY_T_ID"	       ,TYPC,	  1,    0},
{"SAFETYTIME"	       ,TYPNUM,  2,    0},
{"PLORD_CTRL"	       ,TYPC,	  2,    0},
{"BATCHENTRY"	       ,TYPC,	  1,    0},
{"PVALIDFROM"	       ,TYPDATE	,sizeof(RFC_DATE),    0},
{"MATFRGTGRP"	       ,TYPC,	  8,    0},
{"PRODVERSCS"	       ,TYPC,	  4,    0},
{"MAT_CFOP"	       ,TYPC,	  2,    0},
{"EU_LIST_NO"	       ,TYPC,	  12,    0},
{"EU_MAT_GRP"	       ,TYPC,	  6,    0},
{"CAS_NO"              ,TYPC,	  15,    0},
{"PRODCOM_NO"	       ,TYPC,	  9,    0},
{"CTRL_CODE"	       ,TYPC,	  16,    0},
{"JIT_RELVT"	       ,TYPC,	  1,    0},
{"MAT_GRP_TRANS"       ,TYPC,	  20,    0},
{"HANDLG_GRP"	       ,TYPC,	  4,    0},
{"SUPPLY_AREA"	       ,TYPC,	  10,    0},
{"FAIR_SHARE_RULE"     ,TYPC,	  2,    0},
{"PUSH_DISTRIB"	       ,TYPC,	  1,    0},
{"DEPLOY_HORIZ"	       ,TYPP,	  2,    0},
{"MIN_LOT_SIZE"	       ,TYPP,	  7,    3},
{"MAX_LOT_SIZE"	       ,TYPP,	  7,    3},
{"FIX_LOT_SIZE"	       ,TYPP,	  7,    3},
{"LOT_INCREMENT"       ,TYPP,	  7,    3},
{"PROD_CONV_TYPE"      ,TYPC,	  2,    0},
{"DISTR_PROF"	       ,TYPC,	  3,    0},
{"PERIOD_PROFILE_SAFETY_TIME"     ,TYPC,	  3,    0},
{"FXD_PRICE"		,TYPC,	  1,    0},
{"AVAIL_CHECK_ALL_PROJ_SEGMENTS"  ,TYPC,	  1,    0},
{"OVERALLPRF"		,TYPC,	  6,    0},
{"MRP_RELEVANCY_DEP_REQUIREMENTS" ,TYPC,	  1,    0},
{"MIN_SAFETY_STK"	 ,TYPP,	  7,    7},
{"NO_COSTING"		 ,TYPC,	  1,    0},
{"UNIT_GROUP"		 ,TYPC,	  4,    0},
{"FOLLOW_UP_EXTERNAL"	 ,TYPC,	  40,    0},
{"FOLLOW_UP_GUID"	 ,TYPC,	  32,    0},
{"FOLLOW_UP_VERSION"	 ,TYPC,	  10,    0},
{"REFMATCONS_EXTERNAL"	 ,TYPC,	  40,    0},
{"REFMATCONS_GUID"	 ,TYPC,	  32,    0},
{"REFMATCONS_VERSION"	 ,TYPC,	  10,    0},
{"SALES_VIEW"	 ,TYPC,	  1,    0},
{"PURCH_VIEW"	 ,TYPC,	  1,    0},
{"MRP_VIEW"	 ,TYPC,	  1,    0},
{"FORECAST_VIEW"	 ,TYPC,	  1,    0},
{"WORK_SCHED_VIEW"	 ,TYPC,	  1,    0},
{"PRT_VIEW"	 ,TYPC,	  1,    0},
{"STORAGE_VIEW"	 ,TYPC,	  1,    0},
{"WAREHOUSE_VIEW"	 ,TYPC,	  1,    0},
{"QUALITY_VIEW"	 ,TYPC,	  1,    0},
{"ACCOUNT_VIEW"	 ,TYPC,	  1,    0},
{"COST_VIEW"	 ,TYPC,	  1,    0},
{"ROTATION_DATE"	 ,TYPC,	  1,    0},
{"ORIGINAL_BATCH_FLAG"	 ,TYPC,	  1,    0},
{"ORIGINAL_BATCH_REF_MATERIAL"    ,TYPC,	  18,    0},
{"MATERIAL_EXTERNAL"    ,TYPC,	  40,    0},
{"MATERIAL_GUID"    ,TYPC,	  32,    0},
{"MATERIAL_VERSION"    ,TYPC,	  10,    0},
{"ORIGINAL_BATCH_REF_MATERIAL_E"  ,TYPC,	  40,    0},
{"ORIGINAL_BATCH_REF_MATERIAL_V"  ,TYPC,	  10,    0},
{"ORIGINAL_BATCH_REF_MATERIAL_G"  ,TYPC,	  32,    0},
};
#endif

#ifndef SAP_ST_BAPI_MARCX1
#define SAP_ST_BAPI_MARCX1
typedef struct {
RFC_CHAR FUNCTION                       [3];
RFC_CHAR aMATERIAL 		       [18];
RFC_CHAR PLANT			       [4];
RFC_CHAR DEL_FLAG		       [1];
RFC_CHAR ABC_ID			       [1];
RFC_CHAR CRIT_PART		       [1];
RFC_CHAR PUR_GROUP		       [1];
RFC_CHAR ISSUE_UNIT		       [1];
RFC_CHAR ISSUE_UNIT_ISO		       [1];
RFC_CHAR MRPPROFILE		       [1];
RFC_CHAR MRP_TYPE		       [1];
RFC_CHAR MRP_CTRLER		       [1];
RFC_CHAR PLND_DELRY		       [1];
RFC_CHAR GR_PR_TIME		       [1];
RFC_CHAR PERIOD_IND		       [1];
RFC_CHAR ASSY_SCRAP		       [1];
RFC_CHAR LOTSIZEKEY		       [1];
RFC_CHAR PROC_TYPE		       [1];
RFC_CHAR SPPROCTYPE		       [1];
RFC_CHAR REORDER_PT		       [1];
RFC_CHAR SAFETY_STK		       [1];
RFC_CHAR MINLOTSIZE		       [1];
RFC_CHAR MAXLOTSIZE		       [1];
RFC_CHAR FIXED_LOT		       [1];
RFC_CHAR ROUND_VAL		       [1];
RFC_CHAR MAX_STOCK		       [1];
RFC_CHAR ORD_COSTS		       [1];
RFC_CHAR DEP_REQ_ID		       [1];
RFC_CHAR STOR_COSTS		       [1];
RFC_CHAR ALT_BOM_ID		       [1];
RFC_CHAR DISCONTINU		       [1];
RFC_CHAR EFF_O_DAY		       [1];
RFC_CHAR FOLLOW_UP		       [1];
RFC_CHAR GRP_REQMTS		       [1];
RFC_CHAR MIXED_MRP		       [1];
RFC_CHAR SM_KEY			       [1];
RFC_CHAR BACKFLUSH		       [1];
RFC_CHAR PRODUCTION_SCHEDULER	       [1];
RFC_CHAR PROC_TIME		       [1];
RFC_CHAR SETUPTIME		       [1];
RFC_CHAR INTEROP			       [1];
RFC_CHAR BASE_QTY		       [1];
RFC_CHAR INHSEPRODT		       [1];
RFC_CHAR STGEPERIOD		       [1];
RFC_CHAR STGE_PD_UN		       [1];
RFC_CHAR STGE_PD_UN_ISO		       [1];
RFC_CHAR OVER_TOL		       [1];
RFC_CHAR UNLIMITED		       [1];
RFC_CHAR UNDER_TOL		       [1];
RFC_CHAR REPLENTIME		       [1];
RFC_CHAR REPLACE_PT		       [1];
RFC_CHAR IND_POST_TO_INSP_STOCK	       [1];
RFC_CHAR CTRL_KEY		       [1];
RFC_CHAR DOC_REQD		       [1];
RFC_CHAR LOADINGGRP		       [1];
RFC_CHAR BATCH_MGMT		       [1];
RFC_CHAR QUOTAUSAGE		       [1];
RFC_CHAR SERV_LEVEL		       [1];
RFC_CHAR SPLIT_IND		       [1];
RFC_CHAR AVAILCHECK		       [1];
RFC_CHAR FY_VARIANT		       [1];
RFC_CHAR CORR_FACT		       [1];
RFC_CHAR SETUP_TIME		       [1];
RFC_CHAR BASE_QTY_PLAN		       [1];
RFC_CHAR SHIP_PROC_TIME		       [1];
RFC_CHAR SUP_SOURCE		       [1];
RFC_CHAR AUTO_P_ORD		       [1];
RFC_CHAR SOURCELIST		       [1];
RFC_CHAR COMM_CODE		       [1];
RFC_CHAR COUNTRYORI		       [1];
RFC_CHAR COUNTRYORI_ISO		       [1];
RFC_CHAR REGIONORIG		       [1];
RFC_CHAR COMM_CO_UN		       [1];
RFC_CHAR COMM_CO_UN_ISO		       [1];
RFC_CHAR EXPIMPGRP		       [1];
RFC_CHAR PROFIT_CTR		       [1];
RFC_CHAR PPC_PL_CAL		       [1];
RFC_CHAR REP_MANUF		       [1];
RFC_CHAR PL_TI_FNCE		       [1];
RFC_CHAR CONSUMMODE		       [1];
RFC_CHAR BWD_CONS		       [1];
RFC_CHAR FWD_CONS		       [1];
RFC_CHAR ALTERNATIVE_BOM		       [1];
RFC_CHAR BOM_USAGE		       [1];
RFC_CHAR PLANLISTGRP		       [1];
RFC_CHAR PLANLISTCNT		       [1];
RFC_CHAR LOT_SIZE		       [1];
RFC_CHAR SPECPROCTY		       [1];
RFC_CHAR PROD_UNIT		       [1];
RFC_CHAR PROD_UNIT_ISO		       [1];
RFC_CHAR ISS_ST_LOC		       [1];
RFC_CHAR MRP_GROUP		       [1];
RFC_CHAR COMP_SCRAP		       [1];
RFC_CHAR CERT_TYPE		       [1];
RFC_CHAR CYCLE_TIME		       [1];
RFC_CHAR COVPROFILE		       [1];
RFC_CHAR CC_PH_INV		       [1];
RFC_CHAR VARIANCE_KEY		       [1];
RFC_CHAR SERNO_PROF		       [1];
RFC_CHAR REPMANPROF		       [1];
RFC_CHAR NEG_STOCKS		       [1];
RFC_CHAR QM_RGMTS		       [1];
RFC_CHAR PLNG_CYCLE		       [1];
RFC_CHAR ROUND_PROF		       [1];
RFC_CHAR REFMATCONS		       [1];
RFC_CHAR D_TO_REF_M		       [1];
RFC_CHAR MULT_REF_M		       [1];
RFC_CHAR AUTO_RESET		       [1];
RFC_CHAR EX_CERT_ID		       [1];
RFC_CHAR EX_CERT_NO_NEW		       [1];
RFC_CHAR EX_CERT_DT		       [1];
RFC_CHAR MILIT_ID		       [1];
RFC_CHAR INSP_INT		       [1];
RFC_CHAR CO_PRODUCT		       [1];
RFC_CHAR PLAN_STRGP		       [1];
RFC_CHAR SLOC_EXPRC		       [1];
RFC_CHAR BULK_MAT		       [1];
RFC_CHAR CC_FIXED		       [1];
RFC_CHAR DETERM_GRP		       [1];
RFC_CHAR QM_AUTHGRP		       [1];
RFC_CHAR TASK_LIST_TYPE		       [1];
RFC_CHAR PUR_STATUS		       [1];
RFC_CHAR PRODPROF		       [1];
RFC_CHAR SAFTY_T_ID		       [1];
RFC_CHAR SAFETYTIME		       [1];
RFC_CHAR PLORD_CTRL		       [1];
RFC_CHAR BATCHENTRY		       [1];
RFC_CHAR PVALIDFROM		       [1];
RFC_CHAR MATFRGTGRP		       [1];
RFC_CHAR PRODVERSCS		       [1];
RFC_CHAR MAT_CFOP		       [1];
RFC_CHAR EU_LIST_NO		       [1];
RFC_CHAR EU_MAT_GRP		       [1];
RFC_CHAR CAS_NO			       [1];
RFC_CHAR PRODCOM_NO		       [1];
RFC_CHAR CTRL_CODE		       [1];
RFC_CHAR JIT_RELVT		       [1];
RFC_CHAR MAT_GRP_TRANS		       [1];
RFC_CHAR HANDLG_GRP		       [1];
RFC_CHAR SUPPLY_AREA		       [1];
RFC_CHAR FAIR_SHARE_RULE		       [1];
RFC_CHAR PUSH_DISTRIB		       [1];
RFC_CHAR DEPLOY_HORIZ		       [1];
RFC_CHAR MIN_LOT_SIZE		       [1];
RFC_CHAR MAX_LOT_SIZE		       [1];
RFC_CHAR FIX_LOT_SIZE		       [1];
RFC_CHAR LOT_INCREMENT		       [1];
RFC_CHAR PROD_CONV_TYPE		       [1];
RFC_CHAR DISTR_PROF		       [1];
RFC_CHAR PERIOD_PROFILE_SAFETY_TIME     [1];
RFC_CHAR FXD_PRICE		       [1];
RFC_CHAR AVAIL_CHECK_ALL_PROJ_SEGMENTS  [1];
RFC_CHAR OVERALLPRF		       [1];
RFC_CHAR MRP_RELEVANCY_DEP_REQUIREMENTS [1];
RFC_CHAR MIN_SAFETY_STK		       [1];
RFC_CHAR NO_COSTING		       [1];
RFC_CHAR UNIT_GROUP		       [1];
RFC_CHAR FOLLOW_UP_EXTERNAL	       [1];
RFC_CHAR FOLLOW_UP_GUID		       [1];
RFC_CHAR FOLLOW_UP_VERSION	       [1];
RFC_CHAR REFMATCONS_EXTERNAL	       [1];
RFC_CHAR REFMATCONS_GUID		       [1];
RFC_CHAR REFMATCONS_VERSION	       [1];
RFC_CHAR ROTATION_DATE		       [1];
RFC_CHAR ORIGINAL_BATCH_FLAG	       [1];
RFC_CHAR ORIGINAL_BATCH_REF_MATERIAL    [1];
RFC_CHAR MATERIAL_EXTERNAL	       [1];
RFC_CHAR MATERIAL_GUID		       [1];
RFC_CHAR MATERIAL_VERSION	       [1];
RFC_CHAR ORIGINAL_BATCH_REF_MATERIAL_E  [1];
RFC_CHAR ORIGINAL_BATCH_REF_MATERIAL_V  [1];
RFC_CHAR ORIGINAL_BATCH_REF_MATERIAL_G  [1];
} BAPI_MARCX1;
#endif

#ifndef SAP_TH_BAPI_MARCX1
#define SAP_TH_BAPI_MARCX1
static const RFC_TYPEHANDLE handleOfBAPI_MARCX1;

static const RFC_TYPE_ELEMENT typeOfBAPI_MARCX1[] = {
{"FUNCTION"                        ,TYPC, 3,    0},
{"aMATERIAL"			   ,TYPC, 18,    0},
{"PLANT"			   ,TYPC, 4,    0},
{"DEL_FLAG"			   ,TYPC, 1,    0},
{"ABC_ID"			   ,TYPC, 1,    0},
{"CRIT_PART"			   ,TYPC, 1,    0},
{"PUR_GROUP"			   ,TYPC, 1,    0},
{"ISSUE_UNIT"			   ,TYPC, 1,    0},
{"ISSUE_UNIT_ISO"		   ,TYPC, 1,    0},
{"MRPPROFILE"			   ,TYPC, 1,    0},
{"MRP_TYPE"			   ,TYPC, 1,    0},
{"MRP_CTRLER"			   ,TYPC, 1,    0},
{"PLND_DELRY"			   ,TYPC, 1,    0},
{"GR_PR_TIME"			   ,TYPC, 1,    0},
{"PERIOD_IND"			   ,TYPC, 1,    0},
{"ASSY_SCRAP"			   ,TYPC, 1,    0},
{"LOTSIZEKEY"			   ,TYPC, 1,    0},
{"PROC_TYPE"			   ,TYPC, 1,    0},
{"SPPROCTYPE"			   ,TYPC, 1,    0},
{"REORDER_PT"			   ,TYPC, 1,    0},
{"SAFETY_STK"			   ,TYPC, 1,    0},
{"MINLOTSIZE"			   ,TYPC, 1,    0},
{"MAXLOTSIZE"			   ,TYPC, 1,    0},
{"FIXED_LOT"			   ,TYPC, 1,    0},
{"ROUND_VAL"			   ,TYPC, 1,    0},
{"MAX_STOCK"			   ,TYPC, 1,    0},
{"ORD_COSTS"			   ,TYPC, 1,    0},
{"DEP_REQ_ID"			   ,TYPC, 1,    0},
{"STOR_COSTS"			   ,TYPC, 1,    0},
{"ALT_BOM_ID"			   ,TYPC, 1,    0},
{"DISCONTINU"			   ,TYPC, 1,    0},
{"EFF_O_DAY;"			   ,TYPC, 1,    0},
{"FOLLOW_UP"			   ,TYPC, 1,    0},
{"GRP_REQMTS"			   ,TYPC, 1,    0},
{"MIXED_MRP"			   ,TYPC, 1,    0},
{"SM_KEY"			   ,TYPC, 1,    0},
{"BACKFLUSH"			   ,TYPC, 1,    0},
{"PRODUCTION_SCHEDULER"		   ,TYPC, 1,    0},
{"PROC_TIME"			   ,TYPC, 1,    0},
{"SETUPTIME"			   ,TYPC, 1,    0},
{"INTEROP"			   ,TYPC, 1,    0},
{"BASE_QTY"			   ,TYPC, 1,    0},
{"INHSEPRODT"			   ,TYPC, 1,    0},
{"STGEPERIOD"			   ,TYPC, 1,    0},
{"STGE_PD_UN"			   ,TYPC, 1,    0},
{"STGE_PD_UN_ISO"		   ,TYPC, 1,    0},
{"OVER_TOL"			   ,TYPC, 1,    0},
{"UNLIMITED"			   ,TYPC, 1,    0},
{"UNDER_TOL"			   ,TYPC, 1,    0},
{"REPLENTIME"			   ,TYPC, 1,    0},
{"REPLACE_PT"			   ,TYPC, 1,    0},
{"IND_POST_TO_INSP_STOCK"	   ,TYPC, 1,    0},
{"CTRL_KEY"			   ,TYPC, 1,    0},
{"DOC_REQD"			   ,TYPC, 1,    0},
{"LOADINGGRP"			   ,TYPC, 1,    0},
{"BATCH_MGMT"			   ,TYPC, 1,    0},
{"QUOTAUSAGE"			   ,TYPC, 1,    0},
{"SERV_LEVEL"			   ,TYPC, 1,    0},
{"SPLIT_IND"			   ,TYPC, 1,    0},
{"AVAILCHECK"			   ,TYPC, 1,    0},
{"FY_VARIANT"			   ,TYPC, 1,    0},
{"CORR_FACT"			   ,TYPC, 1,    0},
{"SETUP_TIME"			   ,TYPC, 1,    0},
{"BASE_QTY_PLAN"		   ,TYPC, 1,    0},
{"SHIP_PROC_TIME"		   ,TYPC, 1,    0},
{"SUP_SOURCE"			   ,TYPC, 1,    0},
{"AUTO_P_ORD"			   ,TYPC, 1,    0},
{"SOURCELIST"			   ,TYPC, 1,    0},
{"COMM_CODE"			   ,TYPC, 1,    0},
{"COUNTRYORI"			   ,TYPC, 1,    0},
{"COUNTRYORI_ISO"		   ,TYPC, 1,    0},
{"REGIONORIG"			   ,TYPC, 1,    0},
{"COMM_CO_UN"			   ,TYPC, 1,    0},
{"COMM_CO_UN_ISO"		   ,TYPC, 1,    0},
{"EXPIMPGRP"			   ,TYPC, 1,    0},
{"PROFIT_CTR"			   ,TYPC, 1,    0},
{"PPC_PL_CAL"			   ,TYPC, 1,    0},
{"REP_MANUF"			   ,TYPC, 1,    0},
{"PL_TI_FNCE"			   ,TYPC, 1,    0},
{"CONSUMMODE"			   ,TYPC, 1,    0},
{"BWD_CONS"			   ,TYPC, 1,    0},
{"FWD_CONS"			   ,TYPC, 1,    0},
{"ALTERNATIVE_BOM"		   ,TYPC, 1,    0},
{"BOM_USAGE"			   ,TYPC, 1,    0},
{"PLANLISTGRP"			   ,TYPC, 1,    0},
{"PLANLISTCNT"			   ,TYPC, 1,    0},
{"LOT_SIZE"			   ,TYPC, 1,    0},
{"SPECPROCTY"			   ,TYPC, 1,    0},
{"PROD_UNIT"			   ,TYPC, 1,    0},
{"PROD_UNIT_ISO"		   ,TYPC, 1,    0},
{"ISS_ST_LOC"			   ,TYPC, 1,    0},
{"MRP_GROUP"			   ,TYPC, 1,    0},
{"COMP_SCRAP"			   ,TYPC, 1,    0},
{"CERT_TYPE"			   ,TYPC, 1,    0},
{"CYCLE_TIME"			   ,TYPC, 1,    0},
{"COVPROFILE"			   ,TYPC, 1,    0},
{"CC_PH_INV"			   ,TYPC, 1,    0},
{"VARIANCE_KEY"			   ,TYPC, 1,    0},
{"SERNO_PROF"			   ,TYPC, 1,    0},
{"REPMANPROF"			   ,TYPC, 1,    0},
{"NEG_STOCKS"			   ,TYPC, 1,    0},
{"QM_RGMTS"			   ,TYPC, 1,    0},
{"PLNG_CYCLE"			   ,TYPC, 1,    0},
{"ROUND_PROF"			   ,TYPC, 1,    0},
{"REFMATCONS"			   ,TYPC, 1,    0},
{"D_TO_REF_M;"			   ,TYPC, 1,    0},
{"MULT_REF_M"			   ,TYPC, 1,    0},
{"AUTO_RESET"			   ,TYPC, 1,    0},
{"EX_CERT_ID"			   ,TYPC, 1,    0},
{"EX_CERT_NO_NEW"		   ,TYPC, 1,    0},
{"EX_CERT_DT;"			   ,TYPC, 1,    0},
{"MILIT_ID"			   ,TYPC, 1,    0},
{"INSP_INT"			   ,TYPC, 1,    0},
{"CO_PRODUCT"			   ,TYPC, 1,    0},
{"PLAN_STRGP"			   ,TYPC, 1,    0},
{"SLOC_EXPRC"			   ,TYPC, 1,    0},
{"BULK_MAT"			   ,TYPC, 1,    0},
{"CC_FIXED"			   ,TYPC, 1,    0},
{"DETERM_GRP"			   ,TYPC, 1,    0},
{"QM_AUTHGRP"			   ,TYPC, 1,    0},
{"TASK_LIST_TYPE"		   ,TYPC, 1,    0},
{"PUR_STATUS"			   ,TYPC, 1,    0},
{"PRODPROF"			   ,TYPC, 1,    0},
{"SAFTY_T_ID"			   ,TYPC, 1,    0},
{"SAFETYTIME"			   ,TYPC, 1,    0},
{"PLORD_CTRL"			   ,TYPC, 1,    0},
{"BATCHENTRY"			   ,TYPC, 1,    0},
{"PVALIDFROM;"			   ,TYPC, 1,    0},
{"MATFRGTGRP"			   ,TYPC, 1,    0},
{"PRODVERSCS"			   ,TYPC, 1,    0},
{"MAT_CFOP"			   ,TYPC, 1,    0},
{"EU_LIST_NO"			   ,TYPC, 1,    0},
{"EU_MAT_GRP"			   ,TYPC, 1,    0},
{"CAS_NO"			   ,TYPC, 1,    0},
{"PRODCOM_NO"			   ,TYPC, 1,    0},
{"CTRL_CODE"			   ,TYPC, 1,    0},
{"JIT_RELVT"			   ,TYPC, 1,    0},
{"MAT_GRP_TRANS"		   ,TYPC, 1,    0},
{"HANDLG_GRP"			   ,TYPC, 1,    0},
{"SUPPLY_AREA"			   ,TYPC, 1,    0},
{"FAIR_SHARE_RULE"		   ,TYPC, 1,    0},
{"PUSH_DISTRIB"			   ,TYPC, 1,    0},
{"DEPLOY_HORIZ"			   ,TYPC, 1,    0},
{"MIN_LOT_SIZE"			   ,TYPC, 1,    0},
{"MAX_LOT_SIZE"			   ,TYPC, 1,    0},
{"FIX_LOT_SIZE"			   ,TYPC, 1,    0},
{"LOT_INCREMENT"		   ,TYPC, 1,    0},
{"PROD_CONV_TYPE"		   ,TYPC, 1,    0},
{"DISTR_PROF"			   ,TYPC, 1,    0},
{"PERIOD_PROFILE_SAFETY_TIME"	   ,TYPC, 1,    0},
{"FXD_PRICE"			   ,TYPC, 1,    0},
{"AVAIL_CHECK_ALL_PROJ_SEGMENTS"   ,TYPC, 1,    0},
{"OVERALLPRF"			   ,TYPC, 1,    0},
{"MRP_RELEVANCY_DEP_REQUIREMENTS"  ,TYPC, 1,    0},
{"MIN_SAFETY_STK"		   ,TYPC, 1,    0},
{"NO_COSTING"			   ,TYPC, 1,    0},
{"UNIT_GROUP"			   ,TYPC, 1,    0},
{"FOLLOW_UP_EXTERNAL"		   ,TYPC, 1,    0},
{"FOLLOW_UP_GUID"		   ,TYPC, 1,    0},
{"FOLLOW_UP_VERSION"		   ,TYPC, 1,    0},
{"REFMATCONS_EXTERNAL"		   ,TYPC, 1,    0},
{"REFMATCONS_GUID"		   ,TYPC, 1,    0},
{"REFMATCONS_VERSION"		   ,TYPC, 1,    0},
{"ROTATION_DATE"		   ,TYPC, 1,    0},
{"ORIGINAL_BATCH_FLAG"		   ,TYPC, 1,    0},
{"ORIGINAL_BATCH_REF_MATERIAL"	   ,TYPC, 1,    0},
{"MATERIAL_EXTERNAL"		   ,TYPC, 1,    0},
{"MATERIAL_GUID"		   ,TYPC, 1,    0},
{"MATERIAL_VERSION"		   ,TYPC, 1,    0},
{"ORIGINAL_BATCH_REF_MATERIAL_E"   ,TYPC, 1,    0},
{"ORIGINAL_BATCH_REF_MATERIAL_V"   ,TYPC, 1,    0},
{"ORIGINAL_BATCH_REF_MATERIAL_G"   ,TYPC, 1,    0},
};
#endif





#ifndef SAP_ST_NOAPPLLOG
#define SAP_ST_NOAPPLLOG
typedef struct {
  RFC_CHAR NOAPPLLOG[1];
 } NOAPPLLOG;
#endif

#ifndef SAP_TH_NOAPPLLOG
#define SAP_TH_NOAPPLLOG
static const RFC_TYPEHANDLE handleOfNOAPPLLOG;

static const RFC_TYPE_ELEMENT typeOfNOAPPLLOG[] = {
  {"NOAPPLLOG", TYPC, 1, 0},
 };
#endif




#ifndef SAP_ST_NOCHANGEDOC
#define SAP_ST_NOCHANGEDOC
typedef struct {
  RFC_CHAR NOCHANGEDOC[1];
 } NOCHANGEDOC;
#endif

#ifndef SAP_TH_NOCHANGEDOC
#define SAP_TH_NOCHANGEDOC
static const RFC_TYPEHANDLE handleOfNOCHANGEDOC;

static const RFC_TYPE_ELEMENT typeOfNOCHANGEDOC[] = {
  {"NOCHANGEDOC", TYPC, 1, 0},
 };
#endif




#ifndef SAP_ST_TESTRUN
#define SAP_ST_TESTRUN
typedef struct {
  RFC_CHAR TESTRUN[1];
 } TESTRUN;
#endif

#ifndef SAP_TH_TESTRUN
#define SAP_TH_TESTRUN
static const RFC_TYPEHANDLE handleOfTESTRUN;

static const RFC_TYPE_ELEMENT typeOfTESTRUN[] = {
  {"TESTRUN", TYPC, 1, 0},
 };
#endif



#ifndef SAP_ST_INPFLDCHECK
#define SAP_ST_INPFLDCHECK
typedef struct {
  RFC_CHAR INPFLDCHECK[1];
 } INPFLDCHECK;
#endif

#ifndef SAP_TH_INPFLDCHECK
#define SAP_TH_INPFLDCHECK
static const RFC_TYPEHANDLE handleOfINPFLDCHECK;

static const RFC_TYPE_ELEMENT typeOfINPFLDCHECK[] = {
  {"INPFLDCHECK", TYPC, 1, 0},
 };
#endif

#ifndef SAP_ST_FLAG_CAD_CALL
#define SAP_ST_FLAG_CAD_CALL
typedef struct {
  RFC_CHAR FLAG_CAD_CALL[1];
 } FLAG_CAD_CALL;
#endif

#ifndef SAP_TH_FLAG_CAD_CALL
#define SAP_TH_FLAG_CAD_CALL
static const RFC_TYPEHANDLE handleOfFLAG_CAD_CALL;

static const RFC_TYPE_ELEMENT typeOfFLAG_CAD_CALL[] = {
  {"FLAG_CAD_CALL", TYPC, 1, 0},
 };
#endif


#ifndef SAP_ST_NO_ROLLBACK_WORK
#define SAP_ST_NO_ROLLBACK_WORK
typedef struct {
  RFC_CHAR NO_ROLLBACK_WORK[1];
 } NO_ROLLBACK_WORK;
#endif

#ifndef SAP_TH_NO_ROLLBACK_WORK
#define SAP_TH_NO_ROLLBACK_WORK
static const RFC_TYPEHANDLE handleOfNO_ROLLBACK_WORK;

static const RFC_TYPE_ELEMENT typeOfNO_ROLLBACK_WORK[] = {
  {"NO_ROLLBACK_WORK", TYPC, 1, 0},
 };
#endif



#ifndef SAP_ST_FLAG_ONLINE
#define SAP_ST_FLAG_ONLINE
typedef struct {
  RFC_CHAR FLAG_ONLINE[1];
 } FLAG_ONLINE;
#endif

#ifndef SAP_TH_FLAG_ONLINE
#define SAP_TH_FLAG_ONLINE
static const RFC_TYPEHANDLE handleOfFLAG_ONLINE;

static const RFC_TYPE_ELEMENT typeOfFLAG_ONLINE[] = {
  {"FLAG_ONLINE", TYPC, 1, 0},
 };
#endif
#ifndef SAP_ST_I_MATNR
#define SAP_ST_I_MATNR
typedef struct
{
RFC_CHAR Matnr[18];
}I_MATNR;
#endif

#ifndef SAP_TH_I_MATNR
#define SAP_TH_I_MATNR
static const RFC_TYPEHANDLE handleOfI_MATNR;
static const RFC_TYPE_ELEMENT typeOfI_MATNR[]=
{
{"MATNR"	,TYPC	,18	,0},
};
#endif

#ifndef SAP_ST_E_MAT_IND
#define SAP_ST_E_MAT_IND
typedef struct
{
RFC_CHAR MATNR[18];
RFC_CHAR MAKTX[40];
RFC_CHAR MMSTA[2];
}E_MAT_IND;
#endif

#ifndef SAP_TH_E_MAT_IND
#define SAP_TH_E_MAT_IND
static const RFC_TYPEHANDLE handleOfE_MAT_IND;
static const RFC_TYPE_ELEMENT typeOfE_MAT_IND[]=
{
{"MATNR"	,TYPC	,18	,0},
{"MAKTX"	,TYPC	,40	,0},
{"MMSTA"	,TYPC	,2	,0},
};
#endif


#ifndef SAP_ST_MMSTA
#define SAP_ST_MMSTA
typedef struct {
  RFC_CHAR MMSTA[2];
 } MMSTA;
#endif

#ifndef SAP_TH_MMSTA
#define SAP_TH_MMSTA
static const RFC_TYPEHANDLE handleOfMMSTA;

static const RFC_TYPE_ELEMENT typeOfMMSTA[] = {
  {"MMSTA", TYPC, 2, 0},
 };
#endif



#ifndef SAP_ST_LANGU
#define SAP_ST_LANGU
typedef struct {
  RFC_CHAR LANGU[1];
 } LANGU;
#endif

#ifndef SAP_TH_LANGU
#define SAP_TH_LANGU
static const RFC_TYPEHANDLE handleOfLANGU;

static const RFC_TYPE_ELEMENT typeOfLANGU[] = {
  {"LANGU", TYPC, 1, 0},
 };
#endif

#ifndef SAP_ST_STNUM
#define SAP_ST_STNUM
typedef struct {
  RFC_CHAR Stnum[8];
 } STNUM;
#endif

#ifndef SAP_TH_STNUM
#define SAP_TH_STNUM
static const RFC_TYPEHANDLE handleOfSTNUM;

static const RFC_TYPE_ELEMENT typeOfSTNUM[] = {
  {"STNUM", TYPC, 8, 0},
 };
#endif

#ifndef SAP_ST_STLAN
#define SAP_ST_STLAN
typedef struct {
  RFC_CHAR Stlan[1];
 } STLAN;
#endif

#ifndef SAP_TH_STLAN
#define SAP_TH_STLAN
static const RFC_TYPEHANDLE handleOfSTLAN;

static const RFC_TYPE_ELEMENT typeOfSTLAN[] = {
  {"STLAN", TYPC, 1, 0},
 };
#endif


#ifndef SAP_ST_STLAL
#define SAP_ST_STLAL
typedef struct {
  RFC_CHAR Stlal[2];
 } STLAL;
#endif

#ifndef SAP_TH_STLAL
#define SAP_TH_STLAL
static const RFC_TYPEHANDLE handleOfSTLAL;

static const RFC_TYPE_ELEMENT typeOfSTLAL[] = {
  {"STLAL", TYPC, 2, 0},
 };
#endif
#ifndef SAP_ST_CHAR1
#define SAP_ST_CHAR1
typedef struct {
  RFC_CHAR Char1[1];
 } CHAR1;
#endif

#ifndef SAP_TH_CHAR1
#define SAP_TH_CHAR1
static const RFC_TYPEHANDLE handleOfCHAR1;

static const RFC_TYPE_ELEMENT typeOfCHAR1[] = {
  {"CHAR1", TYPC, 1, 0},
 };
#endif



#ifndef SAP_ST_MESSTAB2
#define SAP_ST_MESSTAB2
typedef struct {
	RFC_CHAR TCODE[20];
	RFC_CHAR DYNAME[40];
	RFC_CHAR DYNUMB[4];
	RFC_CHAR MSGTYP[1];
	RFC_CHAR MSGSPRA[1];
	RFC_CHAR MSGID[20];
	RFC_CHAR MSGNR[3];
	RFC_CHAR MSGV1[100];
	RFC_CHAR MSGV2[100];
	RFC_CHAR MSGV3[100];
	RFC_CHAR MSGV4[100];
	RFC_CHAR ENV[4];
	RFC_CHAR FLDNAME[132];
} MESSTAB2;
#endif

#ifndef SAP_TH_MESSTAB2
#define SAP_TH_MESSTAB2
static const RFC_TYPEHANDLE handleOfMESSTAB2;

static const RFC_TYPE_ELEMENT typeOfMESSTAB2[] = {
	{"TCODE"	,TYPC,	20,	0},
	{"DYNAME"	,TYPC,	40,	0},
	{"DYNUMB"	,TYPC,	4,	0},
	{"MSGTYP"	,TYPC,	1,	0},
	{"MSGSPRA"	,TYPC,	1,	0},
	{"MSGID"	,TYPC,	20,	0},
	{"MSGNR"	,TYPC,	3,	0},
	{"MSGV1"	,TYPC,	100,	0},
	{"MSGV2"	,TYPC,	100,	0},
	{"MSGV3"	,TYPC,	100,	0},
	{"MSGV4"	,TYPC,	100,	0},
	{"ENV"	    ,TYPC,	4,		0},
	{"FLDNAME"	,TYPC,	132,	0},

};
#endif

#ifndef SAP_ST_FROM_DATE
#define SAP_ST_FROM_DATE
typedef struct {
  RFC_DATE FROM_DATE;
 } FROM_DATE;
#endif

#ifndef SAP_TH_FROM_DATE
#define SAP_TH_FROM_DATE
static const RFC_TYPEHANDLE handleOfFROM_DATE;

static const RFC_TYPE_ELEMENT typeOfFROM_DATE[] = {
  {"FROM_DATE", TYPDATE	,sizeof(RFC_DATE),    0},
 };
#endif



#ifndef SAP_ST_TO_DATE
#define SAP_ST_TO_DATE
typedef struct {
  RFC_DATE TO_DATE;
 } TO_DATE;
#endif

#ifndef SAP_TH_TO_DATE
#define SAP_TH_TO_DATE
static const RFC_TYPEHANDLE handleOfTO_DATE;

static const RFC_TYPE_ELEMENT typeOfTO_DATE[] = {
  {"TO_DATE", TYPDATE	,sizeof(RFC_DATE),    0},
 };
#endif


#ifndef SAP_ST_FROM_TIME
#define SAP_ST_FROM_TIME
typedef struct {
  RFC_TIME FROM_TIME;
 } FROM_TIME;
#endif

#ifndef SAP_TH_FROM_TIME
#define SAP_TH_FROM_TIME
static const RFC_TYPEHANDLE handleOfFROM_TIME;

static const RFC_TYPE_ELEMENT typeOfFROM_TIME[] = {
  {"FROM_TIME", TYPTIME	,sizeof(RFC_TIME),    0},
 };
#endif


#ifndef SAP_ST_TO_TIME
#define SAP_ST_TO_TIME
typedef struct {
  RFC_TIME TO_TIME;
 } TO_TIME;
#endif

#ifndef SAP_TH_TO_TIME
#define SAP_TH_TO_TIME
static const RFC_TYPEHANDLE handleOfTO_TIME;

static const RFC_TYPE_ELEMENT typeOfTO_TIME[] = {
  {"TO_TIME", TYPTIME	,sizeof(RFC_TIME),    0},
 };
#endif




#ifndef SAP_ST_IT_VALID_VC
#define SAP_ST_IT_VALID_VC
typedef struct {
RFC_CHAR CLIENT [3] ;
RFC_CHAR PLANT [4]  ;
RFC_CHAR VC_NUMBER [18]  ;
RFC_CHAR ASSY_TYPE	[1]  ;
RFC_DATE VALID_FROM	;
RFC_DATE VALID_TO	;
RFC_DATE LAST_PROD	;
RFC_CHAR ACT_INACT_IND	[1] ;
RFC_DATE UPDATE_DATE ;
RFC_TIME UPDATE_TIME ;
RFC_CHAR UPDATED_BY	[12]  ;
RFC_CHAR PROCESS_FLAG	[1] ;
RFC_CHAR REMARKS	[80]  ;
} IT_VALID_VC;
#endif

#ifndef SAP_TH_IT_VALID_VC
#define SAP_TH_IT_VALID_VC
static const RFC_TYPEHANDLE handleOfIT_VALID_VC;

static const RFC_TYPE_ELEMENT typeOfIT_VALID_VC[] = {
{"CLIENT"          ,TYPC,        3,    0},
{"PLANT"	   ,TYPC,	 4,    0},
{"VC_NUMBER"	   ,TYPC,	 18,    0},
{"ASSY_TYPE"	   ,TYPC,        1,    0},
{"VALID_FROM"	   ,TYPDATE	,sizeof(RFC_DATE),    0},
{"VALID_TO"	   ,TYPDATE	,sizeof(RFC_DATE),    0},
{"LAST_PROD"	   ,TYPDATE	,sizeof(RFC_DATE),    0},
{"ACT_INACT_IND"   ,TYPC,	 1,    0},
{"UPDATE_DATE"	   ,TYPDATE	,sizeof(RFC_DATE),    0},
{"UPDATE_TIME"	   ,TYPTIME	,sizeof(RFC_DATE),    0},
{"UPDATED_BY"	   ,TYPC,	 12,    0},
{"PROCESS_FLAG"	   ,TYPC,	 1,    0},
{"REMARKS"	   ,TYPC,	 80,    0},
};
#endif

#ifndef SAP_ST_CHANGE_HEADER_TABLE
#define SAP_ST_CHANGE_HEADER_TABLE
typedef struct {
RFC_CHAR CHANGE_NO[12];
RFC_NUM STATUS[2];
RFC_CHAR AUTH_GROUP[4];
RFC_CHAR VALID_FROM[10];
RFC_CHAR DESCRIPT[40];
RFC_CHAR REASON_CHG[40];
RFC_CHAR CREATED_ON[10];
RFC_CHAR CREATED_BY[12];
RFC_CHAR CHANGED_ON[10];
RFC_CHAR CHANGED_BY[12];
RFC_CHAR DELETION_MARK[1];
RFC_CHAR INDATE_RULE[10];
RFC_CHAR OUTDATE_RULE[10];
RFC_CHAR FUNCTION[1];
RFC_CHAR EFFECTIVITY_TYPE[10];
RFC_CHAR OVERRIDING_MARK[1];
RFC_NUM RANK[2];
RFC_NUM RELEASE_KEY[2];
RFC_DATE RELEASE_KEY_CHGDATE;
RFC_TIME RELEASE_KEY_CHGTIME;
RFC_CHAR STATUS_PROFILE[8];
RFC_CHAR TECH_REL[1];
} CHANGE_HEADER_TABLE;
#endif

#ifndef SAP_TH_CHANGE_HEADER_TABLE
#define SAP_TH_CHANGE_HEADER_TABLE
static const RFC_TYPEHANDLE handleOfCHANGE_HEADER_TABLE;

static const RFC_TYPE_ELEMENT typeOfCHANGE_HEADER_TABLE[] = {
{"CHANGE_NO"		, TYPC,			12,	0},
{"STATUS"			,TYPNUM,		2,	0},
{"AUTH_GROUP"		, TYPC,			4,	0},
{"VALID_FROM"		, TYPC,			10,	0},
{"DESCRIPT"			, TYPC,			40,	0},
{"REASON_CHG"		, TYPC,			40,	0},
{"CREATED_ON"		, TYPC,			10,	0},
{"CREATED_BY"		, TYPC,			12,	0},
{"CHANGED_ON"		, TYPC,			10,	0},
{"CHANGED_BY"		, TYPC,			12,	0},
{"DELETION_MARK"	, TYPC,			1,	0},
{"INDATE_RULE"		, TYPC,			10,	0},
{"OUTDATE_RULE"		, TYPC,			10,	0},
{"FUNCTION"			, TYPC,			1,	0},
{"EFFECTIVITY_TYPE"	, TYPC,			10,	0},
{"OVERRIDING_MARK"	, TYPC,			1,	0},
{"RANK"				,TYPNUM,		2,	0},
{"RELEASE_KEY"		,TYPNUM,		2,	0},
{"RELEASE_KEY_CHGDATE"	,TYPDATE,sizeof(RFC_DATE),	0},
{"RELEASE_KEY_CHGTIME"	,TYPTIME,sizeof(RFC_TIME),	0},
{"STATUS_PROFILE"	, TYPC,			8,	0},
{"TECH_REL"			, TYPC,			1,	0},
};
#endif


#ifndef SAP_ST_CHANGE_NO_TABLE
#define SAP_ST_CHANGE_NO_TABLE
typedef struct {
RFC_CHAR CHANGE_NO[12];
} CHANGE_NO_TABLE;
#endif

#ifndef SAP_TH_CHANGE_NO_TABLE
#define SAP_TH_CHANGE_NO_TABLE
static const RFC_TYPEHANDLE handleOfCHANGE_NO_TABLE;

static const RFC_TYPE_ELEMENT typeOfCHANGE_NO_TABLE[] = {
{"CHANGE_NO"		, TYPC,			12,	0},
};
#endif


#ifndef SAP_ST_BAPIE1PAREX3
#define SAP_ST_BAPIE1PAREX3
typedef struct {
RFC_CHAR STRUCTURE[30];
RFC_CHAR VALUEPART1[240];
RFC_CHAR VALUEPART2[240];
RFC_CHAR VALUEPART3[240];
RFC_CHAR VALUEPART4[240];
} BAPIE1PAREX3;
#endif

#ifndef SAP_TH_BAPIE1PAREX3
 #define SAP_TH_BAPIE1PAREX3
 static const RFC_TYPEHANDLE handleOfBAPIE1PAREX3;

 static const RFC_TYPE_ELEMENT typeOfBAPIE1PAREX3[] = {
	{"STRUCTURE", TYPC, 30, 0},
	{"VALUEPART1", TYPC, 240, 0},
	{"VALUEPART2", TYPC, 240, 0},
	{"VALUEPART3", TYPC, 240, 0},
	{"VALUEPART4", TYPC, 240, 0},
 };
 #endif

#ifndef SAP_ST_BAPIE1PAREXX3
#define SAP_ST_BAPIE1PAREXX3
typedef struct {
RFC_CHAR STRUCTURE[30];
RFC_CHAR VALUEPART1[240];
RFC_CHAR VALUEPART2[240];
RFC_CHAR VALUEPART3[240];
RFC_CHAR VALUEPART4[240];
} BAPIE1PAREXX3;
#endif

#ifndef SAP_TH_BAPIE1PAREXX3
 #define SAP_TH_BAPIE1PAREXX3
 static const RFC_TYPEHANDLE handleOfBAPIE1PAREXX3;

 static const RFC_TYPE_ELEMENT typeOfBAPIE1PAREXX3[] = {
	{"STRUCTURE", TYPC, 30, 0},
	{"VALUEPART1", TYPC, 240, 0},
	{"VALUEPART2", TYPC, 240, 0},
	{"VALUEPART3", TYPC, 240, 0},
	{"VALUEPART4", TYPC, 240, 0},
 };
 #endif

#ifndef SAP_ST_BAPIE1PAREX1
#define SAP_ST_BAPIE1PAREX1
typedef struct {
RFC_CHAR FUNCTION[3];
RFC_CHAR MATERIAL[18];
RFC_CHAR STRUCTURE[30];
RFC_CHAR VALUEPART1[240];
RFC_CHAR VALUEPART2[240];
RFC_CHAR VALUEPART3[240];
RFC_CHAR VALUEPART4[240];
RFC_CHAR MATERIAL_EXTERNAL[40];
RFC_CHAR MATERIAL_GUID[32];
RFC_CHAR MATERIAL_VERSION[10];
} BAPIE1PAREX1;
#endif

#ifndef SAP_TH_BAPIE1PAREX1
 #define SAP_TH_BAPIE1PAREX1
 static const RFC_TYPEHANDLE handleOfBAPIE1PAREX1;

 static const RFC_TYPE_ELEMENT typeOfBAPIE1PAREX1[] = {
	{"FUNCTION", TYPC, 3, 0},
	{"MATERIAL", TYPC, 18, 0},
	{"STRUCTURE", TYPC, 30, 0},
	{"VALUEPART1", TYPC, 240, 0},
	{"VALUEPART2", TYPC, 240, 0},
	{"VALUEPART3", TYPC, 240, 0},
	{"VALUEPART4", TYPC, 240, 0},
	{"MATERIAL_EXTERNAL", TYPC, 40, 0},
	{"MATERIAL_GUID", TYPC, 32, 0},
	{"MATERIAL_VERSION", TYPC, 10, 0},
 };
 #endif

#ifndef SAP_ST_BAPIE1PAREXX1
#define SAP_ST_BAPIE1PAREXX1
typedef struct {
RFC_CHAR FUNCTION[3];
RFC_CHAR MATERIAL[18];
RFC_CHAR STRUCTURE[30];
RFC_CHAR VALUEPART1[240];
RFC_CHAR VALUEPART2[240];
RFC_CHAR VALUEPART3[240];
RFC_CHAR VALUEPART4[229];
RFC_CHAR MATERIAL_EXTERNAL[40];
RFC_CHAR MATERIAL_GUID[32];
RFC_CHAR MATERIAL_VERSION[10];
} BAPIE1PAREXX1;
#endif

#ifndef SAP_TH_BAPIE1PAREXX1
 #define SAP_TH_BAPIE1PAREXX1
 static const RFC_TYPEHANDLE handleOfBAPIE1PAREXX1;

 static const RFC_TYPE_ELEMENT typeOfBAPIE1PAREXX1[] = {
	{"FUNCTION", TYPC, 3, 0},
	{"MATERIAL", TYPC, 18, 0},
	{"STRUCTURE", TYPC, 30, 0},
	{"VALUEPART1", TYPC, 240, 0},
	{"VALUEPART2", TYPC, 240, 0},
	{"VALUEPART3", TYPC, 240, 0},
	{"VALUEPART4", TYPC, 229, 0},
	{"MATERIAL_EXTERNAL", TYPC, 40, 0},
	{"MATERIAL_GUID", TYPC, 32, 0},
	{"MATERIAL_VERSION", TYPC, 10, 0},
 };
 #endif

#endif

/****************************    ZPPRFC_CS_BOM_EXPL_MAT_V2   ****************************/
#ifndef SAP_FT_MARA_MATNR
#define SAP_FT_MARA_MATNR
typedef RFC_CHAR MARA_MATNR[18];
#endif

#ifndef SAP_FT_MARC_WERKS
#define SAP_FT_MARC_WERKS
typedef RFC_CHAR MARC_WERKS[4];
#endif

#ifndef SAP_FT_STZU_STLAN
#define SAP_FT_STZU_STLAN
typedef RFC_CHAR STZU_STLAN[1];
#endif

#ifndef SAP_FT_STKO_STLAL
#define SAP_FT_STKO_STLAL
typedef RFC_CHAR STKO_STLAL[2];
#endif

#ifndef SAP_FT_TC04_CAPID
#define SAP_FT_TC04_CAPID
typedef RFC_CHAR TC04_CAPID[4];
#endif

#ifndef SAP_FT_STKO_DATUV
#define SAP_FT_STKO_DATUV
typedef RFC_DATE STKO_DATUV;
#endif

/*--------------------STB-------------------*/
#ifndef SAP_ST_STB
#define SAP_ST_STB
typedef struct
{
RFC_BCD		STUFE	[2 ];
RFC_BCD		WEGXX	[3 ];
RFC_CHAR	BMTYP	[1 ];
RFC_INT		TTIDX;	//data type INT4	//No. of char length 10
RFC_BCD		VWEGX	[3 ];
RFC_CHAR	OJTXB	[40];
RFC_BCD		BAUSF	[3 ];
RFC_CHAR	STLAN	[1 ];
RFC_CHAR	STLAL	[2 ];
RFC_CHAR	ALTST	[1 ];
RFC_CHAR	VARST	[1 ];
RFC_CHAR	KBAUS	[1 ];
RFC_CHAR	LOEKZ	[1 ];
RFC_CHAR	OJTXP	[40];
RFC_CHAR	MTART	[4 ];
RFC_CHAR	WERKS	[4 ];
RFC_CHAR	VERID	[4 ];
RFC_CHAR	VPSTA	[15];
RFC_CHAR	FSTAT	[15];
RFC_CHAR	MMEIN	[3 ];
RFC_CHAR	BWTTY	[1 ];
RFC_CHAR	VPRSV	[1 ];
RFC_BCD		STPRS	[6 ];	//data type CURR
RFC_BCD		VERPR	[6 ];	//data type CURR
RFC_BCD		PREIH	[3 ];
RFC_CHAR	SBDKZ	[1 ];
RFC_CHAR	XCHAR	[1 ];
RFC_CHAR	KZECH	[1 ];
RFC_CHAR	KZWSM	[1 ];
RFC_CHAR	MMSTA	[2 ];
RFC_DATE	MMSTD;
RFC_CHAR	MSTAE	[2 ];
RFC_DATE	MSTDE;
RFC_CHAR	ZEINR	[22];
RFC_CHAR	ZEIVR	[2 ];
RFC_CHAR	ZEIAR	[3 ];
RFC_CHAR	ZEIFO	[4 ];
RFC_CHAR	BLATT	[3 ];
RFC_NUM 	BLANZ	[3 ];
RFC_CHAR	DISST	[3 ];
RFC_CHAR	DISMM	[2 ];
RFC_CHAR	SERNP	[4 ];
RFC_BCD 	MNGLG	[7 ];
RFC_BCD 	MNGKO	[7 ];
RFC_CHAR	MSIGN	[1 ];
RFC_BCD		AUSSS	[3 ];
RFC_BCD		KAUSF	[3 ];
RFC_CHAR	SOBSL	[2 ];
RFC_CHAR	SOBSK	[2 ];
RFC_CHAR	KZAUS	[1 ];
RFC_DATE	AUSDT;
RFC_CHAR	NFMAT	[18];
RFC_CHAR	RGEKZ	[1 ];
RFC_CHAR	KZDKZ	[1 ];
RFC_BCD		UMREZ	[3 ];
RFC_BCD		UMREN	[3 ];
RFC_CHAR	LGPRO	[4 ];
RFC_CHAR	PRCTR	[10];
RFC_CHAR	REVLV	[2 ];
RFC_CHAR	KZEFF	[1 ];
RFC_CHAR	KZKFG	[1 ];
RFC_NUM 	MCUOB	[18];
RFC_NUM 	CUOBJ	[18];
RFC_CHAR	NCONF	[1 ];
RFC_CHAR	FBSKZ	[1 ];
RFC_CHAR	STAWN	[17];
RFC_CHAR	PREFE	[1 ];
RFC_CHAR	MSCHG	[1 ];
RFC_CHAR	FXPRU	[1 ];
RFC_CHAR	MATMK	[9 ];
RFC_CHAR	STABK	[2 ];
RFC_CHAR	DOSTX	[16];
RFC_CHAR	STLTY	[1 ];
RFC_CHAR	STLNR	[8 ];
RFC_NUM 	STLKN	[8 ];
RFC_NUM 	STPOZ	[8 ];
RFC_NUM 	STVKN	[8 ];
RFC_DATE	DATUV;
RFC_CHAR	TECHV	[12];
RFC_CHAR	AENNR	[12];
RFC_DATE	ANDAT;
RFC_CHAR	ANNAM	[12];
RFC_DATE	AEDAT;
RFC_CHAR	AENAM	[12];
RFC_CHAR	IDNRK	[18];
RFC_CHAR	PSWRK	[4 ];
RFC_CHAR	POSTP	[1 ];
RFC_CHAR	POSNR	[4 ];
RFC_CHAR	SORTF	[10];
RFC_CHAR	MEINS	[3];
RFC_BCD 	MENGE	[7 ];
RFC_CHAR	FMENG	[1 ];
RFC_BCD		AUSCH	[3 ];
RFC_BCD		AVOAU	[3 ];
RFC_CHAR	NETAU	[1 ];
RFC_CHAR	SCHGT	[1 ];
RFC_CHAR	BEIKZ	[1 ];
RFC_CHAR	ERSKZ	[1 ];
RFC_CHAR	RVREL	[1 ];
RFC_CHAR	SANFE	[1 ];
RFC_CHAR	SANIN	[1 ];
RFC_CHAR	SANKA	[1 ];
RFC_CHAR	SANKO	[1 ];
RFC_CHAR	SANVS	[1 ];
RFC_CHAR	STKKZ	[1 ];
RFC_CHAR	REKRI	[1 ];
RFC_CHAR	REKRS	[1 ];
RFC_CHAR	CADPO	[1 ];
RFC_BCD		NLFZT	[2 ];
RFC_BCD		NLFZV	[2 ];
RFC_CHAR	NLFMV	[3 ];
RFC_CHAR	VERTI	[4 ];
RFC_CHAR	ALPOS	[1 ];
RFC_BCD		EWAHR	[2 ];
RFC_CHAR	EKGRP	[3 ];
RFC_BCD		LIFZT	[2 ];
RFC_CHAR	LIFNR	[10];
RFC_BCD		PREIS	[6 ];
RFC_BCD		PEINH	[3 ];
RFC_CHAR	WAERS	[5 ];
RFC_CHAR	SAKTO	[10];
RFC_BCD 	ROANZ	[7 ];
RFC_BCD 	ROMS1	[7 ];
RFC_BCD 	ROMS2	[7 ];
RFC_BCD 	ROMS3	[7 ];
RFC_CHAR	ROMEI	[3 ];
RFC_BCD 	ROMEN	[7 ];
RFC_CHAR	RFORM	[2 ];
RFC_CHAR	UPSKZ	[1 ];
RFC_CHAR	LTXSP	[1 ];
RFC_CHAR	POTX1	[40];
RFC_CHAR	POTX2	[40];
RFC_CHAR	OBJTY	[1 ];
RFC_CHAR	ITMMK	[9 ];
RFC_BCD		WEBAZ	[2 ];
RFC_CHAR	DOKAR	[3 ];
RFC_CHAR	DOKNR	[25];
RFC_CHAR	DOKVR	[2 ];
RFC_CHAR	DOKTL	[3 ];
RFC_BCD		CSSTR	[3 ];
RFC_CHAR	cLASS	[18];
RFC_CHAR	KLART	[3 ];
RFC_CHAR	INTRM	[18];
RFC_CHAR	POTPR	[1 ];
RFC_CHAR	EKORG	[4 ];
RFC_CHAR	CLOBK	[1 ];
RFC_CHAR	CLMUL	[1 ];
RFC_CHAR	CVIEW	[10];
RFC_NUM 	KNOBJ	[18];
RFC_CHAR	LGORT	[4 ];
RFC_CHAR	PRVBE	[10];
RFC_CHAR	KZKUP	[1 ];
RFC_DATE	DATUB;
RFC_CHAR	AENRA	[12];
RFC_BCD 	AMGLG	[7 ];
RFC_BCD 	AMGKO	[7 ];
RFC_CHAR	DUMPS	[1 ];
RFC_CHAR	XTLTY	[1 ];
RFC_CHAR	XTLNR	[8 ];
RFC_CHAR	XTLAN	[1 ];
RFC_CHAR	XTLAL	[2 ];
RFC_CHAR	XISDT	[1 ];
RFC_CHAR	XISSR	[1 ];
RFC_BCD 	XMENG	[7 ];
RFC_CHAR	XMEIN	[3 ];
RFC_CHAR	XALTS	[1 ];
RFC_CHAR	XVARS	[1 ];
RFC_CHAR	XKBAU	[1 ];
RFC_CHAR	XLOEK	[1 ];
RFC_CHAR	AUSNM	[4 ];
RFC_CHAR	HDNFO	[1 ];
RFC_CHAR	AFFLG	[1 ];
RFC_CHAR	LTFLG	[1 ];
RFC_CHAR	NLFLG	[1 ];
RFC_INT		INDEX ;	//data type INT4	//No. of char length 10
RFC_CHAR	SUMKZ	[1 ];
RFC_NUM 	AUFST	[2 ];
RFC_NUM 	AUFWG	[2 ];
RFC_NUM 	BAUST	[2 ];
RFC_NUM 	BAUWG	[2 ];
RFC_BCD		ASTOV	[2 ];
RFC_BCD		AWGOV	[3 ];
RFC_BCD		BSTOV	[2 ];
RFC_BCD		BWGOV	[3 ];
RFC_NUM 	NLINK	[6 ];
RFC_CHAR	ALPST	[1 ];
RFC_NUM 	ALPRF	[2 ];
RFC_CHAR	ALPGR	[2 ];
RFC_CHAR	DSPST	[2 ];
RFC_CHAR	KZNFP	[1 ];
RFC_CHAR	NFGRP	[2 ];
RFC_CHAR	NFEAG	[2 ];
RFC_CHAR	KZCLB	[1 ];
RFC_NUM 	CLSZU	[8 ];
RFC_CHAR	ITMID	[8 ];
RFC_CHAR	ALEKZ	[1 ];
RFC_CHAR	GUIDX	[16];
RFC_CHAR	ITSOB	[2 ];
RFC_CHAR	RFPNT	[20];
RFC_CHAR	SOBMX	[2 ];
RFC_CHAR	MATKL	[9 ];
RFC_NUM 	INSTS	[8 ];
RFC_NUM 	INSTP	[8 ];
RFC_CHAR	KSTTY	[1 ];
RFC_CHAR	KSTNR	[8 ];
RFC_NUM 	KSTKN	[8 ];
RFC_NUM 	KSTPZ	[8 ];
RFC_CHAR	CAALT	[2 ];
RFC_CHAR	STLTY_W [1 ];
RFC_CHAR	STLNR_W [8 ];
}STB;
#endif

#ifndef SAP_TH_STB
#define SAP_TH_STB
static const RFC_TYPEHANDLE handleOfSTB;
static const RFC_TYPE_ELEMENT typeOfSTB[]=
{
	{"STUFE", TYPP	,2  ,0},
	{"WEGXX", TYPP	,3  ,0},
	{"BMTYP", TYPC	,1  ,0},
	{"TTIDX", TYPINT,sizeof(RFC_INT),0},	//data type INT4
	{"VWEGX", TYPP	,3  ,0},
	{"OJTXB", TYPC	,40 ,0},
	{"BAUSF", TYPP	,3  ,2},
	{"STLAN", TYPC	,1  ,0},
	{"STLAL", TYPC	,2  ,0},
	{"ALTST", TYPC	,1  ,0},
	{"VARST", TYPC	,1  ,0},
	{"KBAUS", TYPC	,1  ,0},
	{"LOEKZ", TYPC	,1  ,0},
	{"OJTXP", TYPC	,40 ,0},
	{"MTART", TYPC	,4  ,0},
	{"WERKS", TYPC	,4  ,0},
	{"VERID", TYPC	,4  ,0},
	{"VPSTA", TYPC	,15 ,0},
	{"FSTAT", TYPC	,15 ,0},
	{"MMEIN", TYPC	,3  ,0},
	{"BWTTY", TYPC	,1  ,0},
	{"VPRSV", TYPC	,1  ,0},
	{"STPRS", TYPP	,6  ,2},
	{"VERPR", TYPP	,6  ,2},
	{"PREIH", TYPP	,3  ,0},
	{"SBDKZ", TYPC	,1  ,0},
	{"XCHAR", TYPC	,1  ,0},
	{"KZECH", TYPC	,1  ,0},
	{"KZWSM", TYPC	,1  ,0},
	{"MMSTA", TYPC	,2  ,0},
	{"MMSTD", TYPDATE , sizeof(RFC_DATE), 0},
	{"MSTAE", TYPC	,2  ,0},
	{"MSTDE", TYPDATE , sizeof(RFC_DATE), 0},
	{"ZEINR", TYPC	,22 ,0},
	{"ZEIVR", TYPC	,2  ,0},
	{"ZEIAR", TYPC	,3  ,0},
	{"ZEIFO", TYPC	,4  ,0},
	{"BLATT", TYPC	,3  ,0},
	{"BLANZ", TYPNUM,3  ,0},
	{"DISST", TYPC	,3  ,0},
	{"DISMM", TYPC	,2  ,0},
	{"SERNP", TYPC	,4  ,0},
	{"MNGLG", TYPP	,7  ,3},
	{"MNGKO", TYPP	,7  ,3},
	{"MSIGN", TYPC	,1  ,0},
	{"AUSSS", TYPP	,3  ,2},
	{"KAUSF", TYPP	,3  ,2},
	{"SOBSL", TYPC	,2  ,0},
	{"SOBSK", TYPC	,2  ,0},
	{"KZAUS", TYPC	,1  ,0},
	{"AUSDT", TYPDATE , sizeof(RFC_DATE), 0},
	{"NFMAT", TYPC	,18 ,0},
	{"RGEKZ", TYPC	,1  ,0},
	{"KZDKZ", TYPC	,1  ,0},
	{"UMREZ", TYPP	,3  ,0},
	{"UMREN", TYPP	,3  ,0},
	{"LGPRO", TYPC	,4  ,0},
	{"PRCTR", TYPC	,10 ,0},
	{"REVLV", TYPC	,2  ,0},
	{"KZEFF", TYPC	,1  ,0},
	{"KZKFG", TYPC	,1  ,0},
	{"MCUOB", TYPNUM,18 ,0},
	{"CUOBJ", TYPNUM,18 ,0},
	{"NCONF", TYPC	,1  ,0},
	{"FBSKZ", TYPC	,1  ,0},
	{"STAWN", TYPC	,17 ,0},
	{"PREFE", TYPC	,1  ,0},
	{"MSCHG", TYPC	,1  ,0},
	{"FXPRU", TYPC	,1  ,0},
	{"MATMK", TYPC	,9  ,0},
	{"STABK", TYPC	,2  ,0},
	{"DOSTX", TYPC	,16 ,0},
	{"STLTY", TYPC	,1  ,0},
	{"STLNR", TYPC	,8  ,0},
	{"STLKN", TYPNUM,8  ,0},
	{"STPOZ", TYPNUM,8  ,0},
	{"STVKN", TYPNUM,8  ,0},
	{"DATUV", TYPDATE , sizeof(RFC_DATE), 0},
	{"TECHV", TYPC	,12 ,0},
	{"AENNR", TYPC	,12 ,0},
	{"ANDAT", TYPDATE , sizeof(RFC_DATE), 0},
	{"ANNAM", TYPC	,12 ,0},
	{"AEDAT", TYPDATE , sizeof(RFC_DATE), 0},
	{"AENAM", TYPC	,12 ,0},
	{"IDNRK", TYPC	,18 ,0},
	{"PSWRK", TYPC	,4  ,0},
	{"POSTP", TYPC	,1  ,0},
	{"POSNR", TYPC	,4  ,0},
	{"SORTF", TYPC	,10 ,0},
	{"MEINS", TYPC	,3 ,0},
	{"MENGE", TYPP	,7  ,3},
	{"FMENG", TYPC	,1  ,0},
	{"AUSCH", TYPP	,3  ,2},
	{"AVOAU", TYPP	,3  ,2},
	{"NETAU", TYPC	,1  ,0},
	{"SCHGT", TYPC	,1  ,0},
	{"BEIKZ", TYPC	,1  ,0},
	{"ERSKZ", TYPC	,1  ,0},
	{"RVREL", TYPC	,1  ,0},
	{"SANFE", TYPC	,1  ,0},
	{"SANIN", TYPC	,1  ,0},
	{"SANKA", TYPC	,1  ,0},
	{"SANKO", TYPC	,1  ,0},
	{"SANVS", TYPC	,1  ,0},
	{"STKKZ", TYPC	,1  ,0},
	{"REKRI", TYPC	,1  ,0},
	{"REKRS", TYPC	,1  ,0},
	{"CADPO", TYPC	,1  ,0},
	{"NLFZT", TYPP	,2  ,0},
	{"NLFZV", TYPP	,2  ,0},
	{"NLFMV", TYPC	,3  ,0},
	{"VERTI", TYPC	,4  ,0},
	{"ALPOS", TYPC	,1  ,0},
	{"EWAHR", TYPP	,2  ,0},
	{"EKGRP", TYPC	,3  ,0},
	{"LIFZT", TYPP	,2  ,0},
	{"LIFNR", TYPC	,10 ,0},
	{"PREIS", TYPP	,6  ,2},
	{"PEINH", TYPP	,3  ,0},
	{"WAERS", TYPC	,5  ,0},
	{"SAKTO", TYPC	,10 ,0},
	{"ROANZ", TYPP	,7  ,3},
	{"ROMS1", TYPP	,7  ,3},
	{"ROMS2", TYPP	,7  ,3},
	{"ROMS3", TYPP	,7  ,3},
	{"ROMEI", TYPC	,3  ,0},
	{"ROMEN", TYPP	,7  ,3},
	{"RFORM", TYPC	,2  ,0},
	{"UPSKZ", TYPC	,1  ,0},
	{"LTXSP", TYPC	,1  ,0},
	{"POTX1", TYPC	,40 ,0},
	{"POTX2", TYPC	,40 ,0},
	{"OBJTY", TYPC	,1  ,0},
	{"ITMMK", TYPC	,9  ,0},
	{"WEBAZ", TYPP	,2  ,0},
	{"DOKAR", TYPC	,3  ,0},
	{"DOKNR", TYPC	,25 ,0},
	{"DOKVR", TYPC	,2  ,0},
	{"DOKTL", TYPC	,3  ,0},
	{"CSSTR", TYPP	,3  ,2},
	{"cLASS", TYPC	,18 ,0},
	{"KLART", TYPC	,3  ,0},
	{"INTRM", TYPC	,18 ,0},
	{"POTPR", TYPC	,1  ,0},
	{"EKORG", TYPC	,4  ,0},
	{"CLOBK", TYPC	,1  ,0},
	{"CLMUL", TYPC	,1  ,0},
	{"CVIEW", TYPC	,10 ,0},
	{"KNOBJ", TYPNUM,18 ,0},
	{"LGORT", TYPC	,4  ,0},
	{"PRVBE", TYPC	,10 ,0},
	{"KZKUP", TYPC	,1  ,0},
	{"DATUB", TYPDATE , sizeof(RFC_DATE), 0},
	{"AENRA", TYPC	,12 ,0},
	{"AMGLG", TYPP	,7  ,3},
	{"AMGKO", TYPP	,7  ,3},
	{"DUMPS", TYPC	,1  ,0},
	{"XTLTY", TYPC	,1  ,0},
	{"XTLNR", TYPC	,8  ,0},
	{"XTLAN", TYPC	,1  ,0},
	{"XTLAL", TYPC	,2  ,0},
	{"XISDT", TYPC	,1  ,0},
	{"XISSR", TYPC	,1  ,0},
	{"XMENG", TYPP	,7  ,3},
	{"XMEIN", TYPC	,3  ,0},
	{"XALTS", TYPC	,1  ,0},
	{"XVARS", TYPC	,1  ,0},
	{"XKBAU", TYPC	,1  ,0},
	{"XLOEK", TYPC	,1  ,0},
	{"AUSNM", TYPC	,4  ,0},
	{"HDNFO", TYPC	,1  ,0},
	{"AFFLG", TYPC	,1  ,0},
	{"LTFLG", TYPC	,1  ,0},
	{"NLFLG", TYPC	,1  ,0},
	{"INDEX", TYPINT,sizeof(RFC_INT),0},
	{"SUMKZ", TYPC	,1  ,0},
	{"AUFST", TYPNUM,2  ,0},
	{"AUFWG", TYPNUM,2  ,0},
	{"BAUST", TYPNUM,2  ,0},
	{"BAUWG", TYPNUM,2  ,0},
	{"ASTOV", TYPP	,2  ,0},
	{"AWGOV", TYPP	,3  ,0},
	{"BSTOV", TYPP	,2  ,0},
	{"BWGOV", TYPP	,3  ,0},
	{"NLINK", TYPNUM,6  ,0},
	{"ALPST", TYPC	,1  ,0},
	{"ALPRF", TYPNUM,2  ,0},
	{"ALPGR", TYPC	,2  ,0},
	{"DSPST", TYPC	,2  ,0},
	{"KZNFP", TYPC	,1  ,0},
	{"NFGRP", TYPC	,2  ,0},
	{"NFEAG", TYPC	,2  ,0},
	{"KZCLB", TYPC	,1  ,0},
	{"CLSZU", TYPNUM,8  ,0},
	{"ITMID", TYPC	,8  ,0},
	{"ALEKZ", TYPC	,1  ,0},
	{"GUIDX", TYPC	,16 ,0},
	{"ITSOB", TYPC	,2  ,0},
	{"RFPNT", TYPC	,20 ,0},
	{"SOBMX", TYPC	,2  ,0},
	{"MATKL", TYPC	,9  ,0},
	{"INSTS", TYPNUM,8  ,0},
	{"INSTP", TYPNUM,8  ,0},
	{"KSTTY", TYPC	,1  ,0},
	{"KSTNR", TYPC	,8  ,0},
	{"KSTKN", TYPNUM,8  ,0},
	{"KSTPZ", TYPNUM,8  ,0},
	{"CAALT", TYPC	,2  ,0},
	{"STLTY_W", TYPC,1 ,0},
	{"STLNR_W", TYPC,8 ,0},
};
#endif
/*--------------------End STB-------------------*/

/*--------------------MATCAT-------------------*/
#ifndef SAP_ST_MATCAT
#define SAP_ST_MATCAT
typedef struct
{
RFC_CHAR	MATNR[18];			//Material Number
RFC_CHAR	REVLV[2	];			//Revision Level
RFC_CHAR	VERID[4	];			//Production Version
RFC_CHAR	STKTX[40];			//Alternative BOM Text
RFC_CHAR	PRWRK[4	];			//Production plant in planned order
RFC_INT2	INDEX[10];			//Index in category table				// DataType INT4
}MATCAT;
#endif

#ifndef SAP_TH_MATCAT
#define SAP_TH_MATCAT
static const RFC_TYPEHANDLE handleOfMATCAT;
static const RFC_TYPE_ELEMENT typeOfMATCAT[]=
{
	{"MATNR", TYPC, 18,0},
	{"REVLV", TYPC, 2 ,0},
	{"VERID", TYPC, 4 ,0},
	{"STKTX", TYPC, 40,0},
	{"PRWRK", TYPC, 4 ,0},
	{"INDEX", TYPINT2, 10,0},	// DataType INT4

};
#endif
/*--------------------End MATCAT-------------------*/

/****************************    END  ZPPRFC_CS_BOM_EXPL_MAT_V2   ****************************/