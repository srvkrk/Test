/*
 *  FILE: msgccf.h
 */

#ifndef msgccf_H
#define msgccf_H

#include <Mtimsgh.h>
#include <metadt.h>
/*
 *  Message Function Definitions (Prototypes).
 *  Published Messages
 */

MTIstatus _AssignAnalystAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   MTIconstString analyst, integer * mfail);

MTIstatus _AssignAnalyst2AtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _AssignAnalystDPAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _AssignChangeAdminAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   MTIconstString chgAdmin, integer * mfail);

MTIstatus _AssignChangeAdmin2AtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _AssignChangeAdminDPAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _AssignDefaultAnalystAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _AssignDefaultChgAdminAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _AssignDefaultRevBoardAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _AssignOriginatorAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   MTIconstString newOriginator, integer * mfail);

MTIstatus _AssignOriginator2AtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _AssignOriginatorDPAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _AssignRevBoardAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   SetOfStrings revBoard, integer * mfail);

MTIstatus _AssignRevBoardDPAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _AuthorizeForCkinAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr dialogObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _AuthorizeForCkirAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr dialogObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _AuthorizeForCkoAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _AuthorizeForCpyAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr dialogObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _AuthorizeForCreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _AuthorizeForDelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr dialogObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _AuthorizeForMkvAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr dialogObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _AuthorizeForRevAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr dialogObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _AuthorizeForUpdAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr dialogObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _ChangeDispoItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   MTIconstString disposition, MTIconstString dispoComments, integer * mfail);

MTIstatus _ChangeDispoItem2AtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _ChangeDispoItemDPAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ChangeStatusItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   MTIconstString wbsStatus, integer * mfail);

MTIstatus _ChangeStatusItemDPAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ChgDispPrdPlnItAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _ChgDispPrdPlnToApprvdAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _ChgPrdPlnClosurToClosdAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _ChgStateECNToExecutingAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _ChgStateECNToIncrptdAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _ChgStatePdpToExecutingAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _ChgStatePrdPlnToAuthrgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _ChgStatePrdPlnToIncrpAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _ChgStatePrdPlnToReadyAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _ChgStatePrdPlnToReviewAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _ChgStatusPdpToCompltdAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _ChgStatusPdpToProgressAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _ChgTechDispItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   MTIconstString techDisposition, MTIconstString techRevPriority, MTIconstString prbVerifSummary,
   MTIconstString ramifications, integer * mfail);

MTIstatus _ChgTechDispItemDPAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ClassifyChgItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   MTIconstString reason, MTIconstString wbsPriority, MTIconstString classification,
   integer * mfail);

MTIstatus _ClassifyChgItemDPAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _DGetLVSCcfAdminsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSCcfAnalystsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSCcfOriginatorsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSCcfReviewersAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSCcfTechDispAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSCfiDispositionAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSChgTypeForDvRqAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSISDispositionAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DetermineIPRelClass
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr itemObj, string * realClassName, integer * mfail);

MTIstatus _DoAadFailureCleanupAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAanFailureCleanupAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAssignAnalystPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAssignAnalystPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAssignChgAdminPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAssignChgAdminPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAssignOriginatorPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAssignOriginatorPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAssignRevBoardPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAssignRevBoardPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoCdiFailCleanupAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChangeDispoPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChangeDispoPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChangeStatusPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChangeStatusPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChgTechDispPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoChgTechDispPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoClaFailCleanupAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoClassifyChgPostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoClassifyChgPreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoClosureFailCleanupAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoCsuFailCleanupAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoCtdFailCleanupAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoOriginatrFailCleanupAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoPdpClosurePostAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoPdpClosurePreAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoRevBrdFailCleanupAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoesRelClassPrcForCdi
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * answer, integer * mfail);

MTIstatus _DoesRelClassPrcForCla
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * answer, integer * mfail);

MTIstatus _DoesRelClassPrcForCpp
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * answer, integer * mfail);

MTIstatus _DoesRelClassPrcForCsu
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * answer, integer * mfail);

MTIstatus _DoesRelClassPrcForCtd
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * answer, integer * mfail);

MTIstatus _DoesRelClassValForCdi
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * answer, integer * mfail);

MTIstatus _DoesRelClassValForCla
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * answer, integer * mfail);

MTIstatus _DoesRelClassValForCpp
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * answer, integer * mfail);

MTIstatus _DoesRelClassValForCsu
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * answer, integer * mfail);

MTIstatus _DoesRelClassValForCtd
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * answer, integer * mfail);

MTIstatus _ExpSetForIsAffBy
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects itemObjSet, MTIconstString relationship, ObjectPtr qryDef,
   ObjectPtr genContextObj, integer scope, SetOfObjects * otherSideObjSet,
   SetOfObjects * relObjSet, integer * mfail);

MTIstatus _FreezePrpEffForPrdPlnAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _GetAllValidAdminsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   SetOfStrings * values, integer * mfail);

MTIstatus _GetAllValidAnalystsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   SetOfStrings * values, integer * mfail);

MTIstatus _GetAllValidClassifyAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   SetOfStrings * values, integer * mfail);

MTIstatus _GetAllValidDispoAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   SetOfStrings * values, integer * mfail);

MTIstatus _GetAllValidOriginatorsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   SetOfStrings * values, integer * mfail);

MTIstatus _GetAllValidPlanStatusAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   SetOfStrings * values, integer * mfail);

MTIstatus _GetAllValidPrioritiesAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   SetOfStrings * values, integer * mfail);

MTIstatus _GetAllValidReasonsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   SetOfStrings * values, integer * mfail);

MTIstatus _GetAllValidReviewersAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   SetOfStrings * values, integer * mfail);

MTIstatus _GetApprovedDisposition
   (MTIconstString _class, boolean getParent, MTIconstString className,
   string * apprvdDisposition, integer * mfail);

MTIstatus _GetCdiDialogNameAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   string * dialogName, integer * mfail);

MTIstatus _GetChildIncorpUsgCtxtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr relObj, SetOfObjects * childIncObjsSet, integer * mfail);

MTIstatus _GetClaDialogNameAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   string * dialogName, integer * mfail);

MTIstatus _GetCsuDialogNameAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   string * dialogName, integer * mfail);

MTIstatus _GetCtdDialogNameAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   string * dialogName, integer * mfail);

MTIstatus _GetImplementedPdpItemsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   SetOfObjects * relObjSet, SetOfObjects * otherSideObjSet, integer * mfail);

MTIstatus _GetImplementedPrdPlnMrAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   SetOfObjects * relObjSet, SetOfObjects * otherSideObjSet, integer * mfail);

MTIstatus _GetImplementingPrdPlnAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr * prdPlnMstrObj, SetOfObjects * relObjSet, SetOfObjects * otherSideObjSet,
   integer * mfail);

MTIstatus _GetIncorpPntUsingCtxtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr relObj, SetOfObjects incorpRObjSet, SetOfObjects incPntObjSet,
   ObjectPtr * incorpObj, integer * mfail);

MTIstatus _GetIncorpRIsForPrdPlnAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr * incMstrObj, SetOfObjects * relObjSet, SetOfObjects * otherSideObjSet,
   integer * mfail);

MTIstatus _GetParentIncorpUsgCtxtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr relObj, ObjectPtr * parIncObj, integer * mfail);

MTIstatus _GetPdpClosureDlgNameAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   string * dialogName, integer * mfail);

MTIstatus _InitAttributesForCkoAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr sourceObj, integer * mfail);

MTIstatus _InitAttributesForCpyAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr sourceObj, integer * mfail);

MTIstatus _InitAttributesForRevAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr sourceObj, integer * mfail);

MTIstatus _InitDispositionForCkoAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr sourceObj, integer * mfail);

MTIstatus _InitDispositionForCpyAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr sourceObj, integer * mfail);

MTIstatus _InitDispositionForRevAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr sourceObj, integer * mfail);

MTIstatus _InitStateForCkoAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr sourceObj, integer * mfail);

MTIstatus _InitStateForCpyAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr sourceObj, integer * mfail);

MTIstatus _InitStateForRevAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr sourceObj, integer * mfail);

MTIstatus _InitStatusForCkoAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr sourceObj, integer * mfail);

MTIstatus _InitStatusForCpyAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr sourceObj, integer * mfail);

MTIstatus _InitStatusForRevAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr sourceObj, integer * mfail);

MTIstatus _IsEffectivityAssignedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _IsPdpInAuthoringStateAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   boolean * authoringState, integer * mfail);

MTIstatus _IsPdpInReviewStateAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   boolean * inReviewState, integer * mfail);

MTIstatus _IsPrdPlanImplementedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _IsPrdPlnMrApprovedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpMstr,
   boolean * isApproved, string * approvedDisp, integer * mfail);

MTIstatus _IsPrdPlnMrImplementedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpMstr,
   boolean * isImplemented, integer * mfail);

MTIstatus _IsReviewBoardAssignedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _IsStateVecOkForIncorpRAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr relObj, boolean * condExists, integer * mfail);

MTIstatus _IsStateVecOkForPpsRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr relObj, boolean * condExists, integer * mfail);

MTIstatus _IsStateVecOkForRefRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr relObj, boolean * condExists, integer * mfail);

MTIstatus _IsStateVecOkForSupRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr relObj, boolean * condExists, integer * mfail);

MTIstatus _IsStateVectorOkForCsuAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _LogChangeItem
   (MTIconstString _class, boolean getParent, MTIconstString griItemClass,
   ObjectPtr createArgs, ObjectPtr * griItem, integer * mfail);

MTIstatus _LogChangeItemAndRel
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr backgroundItem, MTIconstString relationship, integer * mfail);

MTIstatus _PdpIsApprovedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * isApproved, integer * mfail);

MTIstatus _PdpIsCanceledAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   boolean * isCanceled, integer * mfail);

MTIstatus _PdpIsClosedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   boolean * isClosed, integer * mfail);

MTIstatus _PdpIsDisapprovedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   boolean * isDisapproved, integer * mfail);

MTIstatus _PdpIsExecutingAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   boolean * isExecuting, integer * mfail);

MTIstatus _PdpIsInProgressAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   boolean * isInProgress, integer * mfail);

MTIstatus _PdpIsInReadyStateAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   boolean * isInReadyState, integer * mfail);

MTIstatus _PdpIsIncorporatedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   boolean * isIncorporated, integer * mfail);

MTIstatus _PdpIsOpenAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   boolean * isOpen, integer * mfail);

MTIstatus _PdpIsSuspendedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   boolean * isSuspended, integer * mfail);

MTIstatus _PrdPlnValMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _ProcRelForPdpClosureAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr relObj,
   ObjectPtr dialogObj, ObjectPtr pdpItem, integer * mfail);

MTIstatus _ProcessRelForCdiAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr relObj,
   ObjectPtr dialogObj, ObjectPtr itemObj, integer * mfail);

MTIstatus _ProcessRelForClaAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr relObj,
   ObjectPtr dialogObj, ObjectPtr itemObj, integer * mfail);

MTIstatus _ProcessRelForCsuAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr relObj,
   ObjectPtr dialogObj, ObjectPtr itemObj, integer * mfail);

MTIstatus _ProcessRelForCtdAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr relObj,
   ObjectPtr dialogObj, ObjectPtr itemObj, integer * mfail);

MTIstatus _ProcessSetForCdi
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr dlgObj, SetOfObjects originObjects, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _ProcessSetForCdiPost
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr dlgObj, SetOfObjects originObjects, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _ProcessSetForCdiPre
   (MTIconstString _class, boolean getParent, MTIconstString ClassName,
   ObjectPtr dlgObj, SetOfObjects originObjects, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _ProcessSetForCsu
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr dlgObj, SetOfObjects originObjects, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _ProcessSetForCsuPost
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr dlgObj, SetOfObjects originObjects, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _ProcessSetForCsuPre
   (MTIconstString _class, boolean getParent, MTIconstString ClassName,
   ObjectPtr dlgObj, SetOfObjects originObjects, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _ProductPlanClosureAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   MTIconstString closure, MTIconstString closureComments, integer * mfail);

MTIstatus _ProductPlanClosureDPAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _QueryForChgAdminBrwD
   (MTIconstString _class, boolean getParent, MTIconstString className,
   integer * mfail);

MTIstatus _SetFastTrackPdpRevBrdAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _UpdPrdPlnActCmpTimeAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _UpdateAdminForTasksAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _UpdateAnalystForTasksAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _UpdateRequestorForTsksAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _ValAffItmForCkoAffectAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr relation, boolean * buildNewRelation, boolean * delOldRelation,
   integer * mfail);

MTIstatus _ValAffItmForCreAffectAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr relation, integer * mfail);

MTIstatus _ValAffItmForDelAffectAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr relation, integer * mfail);

MTIstatus _ValAffItmForRevAffectAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr relation, boolean * buildNewRelation, boolean * delOldRelation,
   integer * mfail);

MTIstatus _ValDlgForCdiSetAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr originObj,
   MTIconstString originClassName, ObjectPtr dlgObject, SetOfStrings * extraStr,
   SetOfObjects * extraObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _ValDlgForCsuSetAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr originObj,
   MTIconstString originClassName, ObjectPtr dlgObject, SetOfStrings * extraStr,
   SetOfObjects * extraObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _ValEffectivityRange
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString startRange, MTIconstString endRange, boolean * isValid,
   integer * mfail);

MTIstatus _ValForAssignAnalystAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _ValForAssignChangeAdmAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _ValForAssignOriginatorAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _ValForAssignRevBoardAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _ValForDelPrdPlnChildAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr childObj,
   integer * mfail);

MTIstatus _ValIPMrForCkoIncorpRAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr incMstr,
   SetOfObjects prdPlnItemSet, SetOfObjects incRSet, integer * mfail);

MTIstatus _ValIPMrForCreIncorpRAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr incMstr,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValIPMrForDelIncorpRAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr incMstr,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValIPMrForRevIncorpRAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr incMstr,
   SetOfObjects prdPlnItemSet, SetOfObjects incRSet, integer * mfail);

MTIstatus _ValPPlnMrForCkoImpRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr prdPlnMstr,
   SetOfObjects prdPlnItemSet, SetOfObjects pPlnImpSet, integer * mfail);

MTIstatus _ValPPlnMrForCreImpRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr prdPlnMstr,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValPPlnMrForDelImpRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr prdPlnMstr,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValPPlnMrForDelPpsRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr prdPlnMstr,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValPPlnMrForRevImpRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr prdPlnMstr,
   SetOfObjects prdPlnItemSet, SetOfObjects pPlnImpSet, integer * mfail);

MTIstatus _ValPrdPlnForCreAffectAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr relation, integer * mfail);

MTIstatus _ValPrdPlnForCreImpRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValPrdPlnForCreIncorpRAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValPrdPlnForCrePpsRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValPrdPlnForCstImpRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   SetOfObjects relObjSet, SetOfObjects otherSideObjSet, integer * mfail);

MTIstatus _ValPrdPlnForCstIncorpRAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr incObj, integer * mfail);

MTIstatus _ValPrdPlnForDelAffectAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr relation, integer * mfail);

MTIstatus _ValPrdPlnForDelImpRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValPrdPlnForDelIncorpRAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValPrdPlnForDelPpsRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValPrdPlnForUpdAffectAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr affectsRel, integer * mfail);

MTIstatus _ValProdPlanForCreRefIAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr referenceRel, integer * mfail);

MTIstatus _ValProdPlanForCreSupIAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr supportRel, integer * mfail);

MTIstatus _ValProdPlanForDelRefIAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr referenceRel, integer * mfail);

MTIstatus _ValProdPlanForDelSupIAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr supportRel, integer * mfail);

MTIstatus _ValRefItemForCreRefIAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr referenceItem,
   ObjectPtr referenceRel, integer * mfail);

MTIstatus _ValRefItemForDelRefIAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr referenceItem,
   ObjectPtr referenceRel, integer * mfail);

MTIstatus _ValRelForChangeDispoAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, ObjectPtr itemObj, integer * mfail);

MTIstatus _ValRelForChangeStatusAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, ObjectPtr itemObj, integer * mfail);

MTIstatus _ValRelForChgTechDispAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, ObjectPtr itemObj, integer * mfail);

MTIstatus _ValRelForClassifyChgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr relItem,
   ObjectPtr dialogObj, ObjectPtr itemObj, integer * mfail);

MTIstatus _ValRelForPdpClosureAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr relObj,
   ObjectPtr dialogObj, ObjectPtr pdpItem, integer * mfail);

MTIstatus _ValRsltsItForCstRsltAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr resultsItem,
   ObjectPtr resultRelObj, ObjectPtr prdPlnIt, integer * mfail);

MTIstatus _ValSetForCdiPost
   (MTIconstString _class, boolean getParent, MTIconstString originClassName,
   SetOfObjects passedObjects, SetOfObjects failedObjects, integer * mfail);

MTIstatus _ValSetForCdiPre
   (MTIconstString _class, boolean getParent, MTIconstString originClassName,
   SetOfObjects originObjects, integer * mfail);

MTIstatus _ValSetForCsuPost
   (MTIconstString _class, boolean getParent, MTIconstString originClassName,
   SetOfObjects passedObjects, SetOfObjects failedObjects, integer * mfail);

MTIstatus _ValSetForCsuPre
   (MTIconstString _class, boolean getParent, MTIconstString originClassName,
   SetOfObjects originObjects, integer * mfail);

MTIstatus _ValSupItemForCreSupIAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr supportItem,
   ObjectPtr supportRel, integer * mfail);

MTIstatus _ValSupItemForDelSupIAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr supportItem,
   ObjectPtr supportRel, integer * mfail);

MTIstatus _ValidateBIForTermStateAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _ValidateForChangeDispoAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidateForChgTechDispAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _ValidateForClassifyChgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   integer * mfail);

MTIstatus _ValidateForCsuAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _ValidateForPdpClosureAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

/*
 *  Unpublished Messages
 */

MTIstatus _APARBaselineRptXMLAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString lineSeparator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _AcceptVisitorAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr visitorObj, integer * mfail);

MTIstatus _AffectedItmSummryRptAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * reportTextStrings,
   integer * mfail);

MTIstatus _AllwProcAffItmForCkoAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr source, boolean * buildRelation, boolean * deleteRelation,
   integer * mfail);

MTIstatus _AllwProcAffItmForRevAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr source, boolean * buildRelation, boolean * deleteRelation,
   integer * mfail);

MTIstatus _AssignDefaultOriginAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _AssignDefaultValueAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   int * numMembers, MTIconstString constantRoleName, MTIconstString constantGrpName,
   MTIconstString attrName, MTIconstString attrFlag, integer * mfail);

MTIstatus _AssignValueFromListAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   MTIconstString attrName, SetOfStrings roleMembers, MTIconstString attrFlag,
   integer * mfail);

MTIstatus _CalPdpCycleTimeAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ChangeDispoItemDPIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ChangeDispoItemIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _ChangeDispoItemSetDP
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects SelectedItems, integer * mfail);

MTIstatus _ChangeStatusItemDPIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ChangeStatusItemIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr workItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _ChangeStatusItemSetDP
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects SelectedItems, integer * mfail);

MTIstatus _CheckPdpCanceledAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _CheckPdpClosedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _ChgClosureSummaryRptAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * reportTextStrings,
   integer * mfail);

MTIstatus _ChgClosureSummaryXMLAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString lineSeparator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _ChgCycleTMetricRpt
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects selectedItems, ObjectPtr taskObject, ObjectPtr argsObj,
   SetOfStrings * reportTextStrings, integer * mfail);

MTIstatus _ChgDetailRptAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * report,
   integer * mfail);

MTIstatus _ChgDetailRptInt
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects chgObjects, SetOfObjects * objectsForReport, SetOfObjects * objectsForInflate,
   integer * mfail);

MTIstatus _ChgDetailRptXMLAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString lineSeparator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _ChgEffectivityRptXMLAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString lineSeparator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _ChgImpactMatrixRptXMLAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString lineSeparator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _ChgReconcilationRptAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * reportTextStrings,
   integer * mfail);

MTIstatus _ChgResultsInRptInt
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects chgObjects, SetOfObjects * objectsForReport, SetOfObjects * objectsForInflate,
   integer * mfail);

MTIstatus _ChgResultsInRptXMLAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString lineSeparator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _ChgStatusSummaryRpt
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects selectedItems, ObjectPtr taskObject, ObjectPtr argsObj,
   SetOfStrings * reportTextStrings, integer * mfail);

MTIstatus _ChgTechDispItemDPIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ChgTechDispItemIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _ClassifyChgItemDPIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   integer * mfail);

MTIstatus _ClassifyChgItemIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _ClassifyChgItemIntExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _CloseTaskAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr taskItem,
   MTIconstString closure_comments, integer * mfail);

MTIstatus _CreateRelationObjAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr leftObj, ObjectPtr rightObj, ObjectPtr * relationObj,
   integer * mfail);

MTIstatus _DGetLVSAfrDispositionAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSAfrTypeAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSCcfClassifyAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSCcfClosureAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSCcfDispositionAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSCcfPlanStatusAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSCcfPriorityAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSCcfReasonAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSCcfStatusAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DGetLVSCcfTechRevPtyAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString valueSetName, MTIconstString lvAttribute, MTIconstString realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _DetectRecursion
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString role, ObjectPtr checkMstrObj, ObjectPtr startMstrObj,
   boolean * recursionDectected, integer * mfail);

MTIstatus _DoAssignAnalystAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAssignChangeAdminAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAssignOriginatorAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoAssignRevBoardAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoChangeDispoAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChangeDispoItemRelsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoChangeDispoPostIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChangeStatusAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChangeStatus2AtClass
   (MTIconstString _class, boolean getParent, ObjectPtr wbsItem,
   MTIconstString wbsStatus, integer * mfail);

MTIstatus _DoChangeStatusItemRelsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoChangeStatusPostIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoChgTechDispAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoChgTechDispItemRelsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoChgTechDispPostIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoClassifyChgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoClassifyChgItemRelsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoClassifyChgPostIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoClassifyChgPreIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoClosurePostForCancelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoClosurePostForCloseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoClosurePostForOpenAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoClosurePostForSuspAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoDeleteAllRevsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr ItemMstrObj,
   integer * mfail);

MTIstatus _DoPdpClosureItemRelsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoPdpClosurePostIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoPdpClosurePreIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _DoPdpClsrOnAllChildrenAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoPdpClsrOnAllImptdItsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _DoPrcForAPARBslRpt
   (MTIconstString _class, boolean getParent, MTIconstString itemClass,
   SetOfObjects partsToReport, SetOfObjects * objectsForReport, SetOfObjects * objectsForInflate,
   integer * mfail);

MTIstatus _DoPrcForChgImpMtxRpt
   (MTIconstString _class, boolean getParent, MTIconstString thisClassName,
   SetOfObjects chgsObjsToProcess, SetOfObjects * objectsForReport, SetOfObjects * objectsForInflate,
   integer * mfail);

MTIstatus _DoProductPlanClosureAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * extraStr, SetOfObjects * extraObj,
   integer * mfail);

MTIstatus _ExpRelMultiLevWbsItem
   (MTIconstString _class, boolean getParent, MTIconstString className,
   MTIconstString relationship, integer maxExpandLevel, SetOfObjects itemObjSet,
   ObjectPtr qryDef, ObjectPtr genContextObj, SetOfObjects * recurList,
   SetOfObjects * resultObjSet, integer * mfail);

MTIstatus _ExpandWbsMultiLevAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString relationship, SetOfObjects * otherSideObjSet, integer * mfail);

MTIstatus _ExpandWbsMultiLevIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString relationship, ObjectPtr genContextObj, SetOfObjects * otherSideObjSet,
   integer * mfail);

MTIstatus _FreezePrpEffAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr incPntObj,
   integer * mfail);

MTIstatus _FreezePrpEffForPdpObjAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _GenChgQryForSumRptXML
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects selectedItems, MTIconstString lineSeparator, ObjectPtr taskObject,
   ObjectPtr argsObj, ObjectPtr * resultXMLObj, boolean * needToTranslit,
   integer * mfail);

MTIstatus _GenRelatedItemsRptAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects relatedObjs, SetOfStrings * report, integer * mfail);

MTIstatus _GenerateImpactsRptXMLAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString lineSeperator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needTrans, integer * mfail);

MTIstatus _GenerateReportSCTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * report, MTIconstString reqAttrList, integer * mfail);

MTIstatus _GenerateSCTReportColAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * report, MTIconstString reqAttrList, integer * mfail);

MTIstatus _GetAdminGrp
   (MTIconstString _class, boolean getParent, MTIconstString className,
   string * adminGrp, integer * mfail);

MTIstatus _GetAffDocForSCTReportAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * report, integer * mfail);

MTIstatus _GetAffPrtMForSCTReportAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * report, integer * mfail);

MTIstatus _GetAllRevisionsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr busItem,
   SetOfObjects * busItemRevisions, integer * mfail);

MTIstatus _GetAllTasksExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * childPdpObjSet, integer * mfail);

MTIstatus _GetAllValidRevBoardSetAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   SetOfObjects * validRevBoardMembers, integer * mfail);

MTIstatus _GetAttSizeForSCTReportAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString reqAttrName, int * sizeOfAttr, integer * mfail);

MTIstatus _GetBiImpForSCTReportAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * report, integer * mfail);

MTIstatus _GetCAZItemForSCTReportAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * report, integer * mfail);

MTIstatus _GetChangeHistoryAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr busItem,
   SetOfObjects * busItemRevisions, integer * mfail);

MTIstatus _GetChangeHistoryIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr busItem,
   SetOfObjects * busItemRevisions, SetOfObjects * resultOfRelsForBusItem, SetOfObjects * resultOfChangeItems,
   integer * mfail);

MTIstatus _GetChangeHistoryXMLAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr busItem,
   MTIconstString lineSeparator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _GetChgAdmItems
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfStrings databases, SetOfObjects * querySet, integer * mfail);

MTIstatus _GetCmtdEffForRptSCTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * report, integer * mfail);

MTIstatus _GetCmtdEffForRptSCTColAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * report, integer * mfail);

MTIstatus _GetCmtdEffObjAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * otherSideObj, integer * mfail);

MTIstatus _GetCurrentRevBoardSetAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   SetOfObjects * currRevBoardMembers, integer * mfail);

MTIstatus _GetDefaultAttrSet
   (MTIconstString _class, boolean getParent, MTIconstString className1,
   MTIconstString className2, MTIconstString classConstant, SetOfStrings * selectedAttrs,
   integer * mfail);

MTIstatus _GetEffForPrdPlnSet
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects prdplnObjSet, SetOfObjects * incorpObjSet, integer * mfail);

MTIstatus _GetHderForSCTReportColAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * report, MTIconstString reqAttrList, integer * mfail);

MTIstatus _GetImpactingChgItemsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr busItem,
   SetOfObjects * affectedByRelsForBusItem, SetOfObjects * affectingChangeItems, integer * mfail);

MTIstatus _GetImplementingECNAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * ECNObj, integer * mfail);

MTIstatus _GetIncorpPntForReviseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr prdPlnItem,
   ObjectPtr * incPntItem, integer * mfail);

MTIstatus _GetIncorporationAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr relObj, ObjectPtr * incorpObj, integer * mfail);

MTIstatus _GetNamesFromRoleGrpAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   MTIconstString roleName, SetOfStrings * roleMembers, integer * numMembers,
   integer * mfail);

MTIstatus _GetPendingChangesAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr busItem,
   SetOfObjects * affectedByRelsForBusItem, SetOfObjects * affectingChangeItems, integer * mfail);

MTIstatus _GetPendingChangesIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr busItem,
   SetOfObjects * affectedByRelsForBusItem, SetOfObjects * affectingChangeItems, integer * mfail);

MTIstatus _GetPlStrcPdpItemsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * otherSideObjSet, integer * mfail);

MTIstatus _GetPlnItemForSCTReportAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * report, integer * mfail);

MTIstatus _GetPrdPlnItTypeAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * prdPlnItType, integer * mfail);

MTIstatus _GetPrdPlnItTypeCtxtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr ctxtObj, integer * prdPlnItType, integer * mfail);

MTIstatus _GetPropEffForRptSCTColAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * report, integer * mfail);

MTIstatus _GetRefForSCTReportAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * report, integer * mfail);

MTIstatus _GetRelatedPdpItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   MTIconstString relClass, ObjectPtr * pdpItem, integer * mfail);

MTIstatus _GetResultsRelForChange
   (MTIconstString _class, boolean getParent, MTIconstString className,
   string * resultsClass, integer * mfail);

MTIstatus _GetReviewersGrp
   (MTIconstString _class, boolean getParent, MTIconstString className,
   string * reviewersGrp, integer * mfail);

MTIstatus _GetRlsTsRForSCTReportAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * report, integer * mfail);

MTIstatus _GetRoleGrpNameAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   MTIconstString constantName, string * roleName, integer * mfail);

MTIstatus _GetScopeReportsSCTAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr taskItem,
   SetOfStrings * databases, integer * mfail);

MTIstatus _GetSolutionTreeIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr rootObj, ObjectPtr * treeObj, integer * mfail);

MTIstatus _GetSupByForSCTReportAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * report, integer * mfail);

MTIstatus _GetSupsdRvForImpMtxRptAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr affectedObj,
   ObjectPtr resultsRev, ObjectPtr * supsdRev, integer * mfail);

MTIstatus _GetTaskAdmBrwScopeAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr taskItem,
   SetOfStrings * databases, integer * mfail);

MTIstatus _GetTaskLRRelationsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr taskItem,
   integer * mfail);

MTIstatus _GetWbsChildrenAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * childObjSet, integer * mfail);

MTIstatus _GetWbsChildrenMultiLevAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * childObjSet, integer * mfail);

MTIstatus _GetWbsMultiLevExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * childObjSet, integer * mfail);

MTIstatus _GetWbsParentAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * parentObj, integer * mfail);

MTIstatus _GetWbsRootAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * rootObj, integer * mfail);

MTIstatus _HasChildrenAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * hasChildren, integer * mfail);

MTIstatus _HasParentsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * hasParents, ObjectPtr * parentObj, integer * mfail);

MTIstatus _IsChangeDispAllowedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr parentObj,
   ObjectPtr childObj, boolean * propagateDisp, integer * mfail);

MTIstatus _IsClosureValueValidAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString closurevalue, boolean * isClosureValueValid, integer * mfail);

MTIstatus _IsImplementingPdpCloseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _IsParentImptdBySameECNAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * isSame, integer * mfail);

MTIstatus _IsStateOkForPdpCloseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * isStateOk, integer * mfail);

MTIstatus _IsUnderCMControlAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * anwer, integer * mfail);

MTIstatus _IsWbsRollUpAllowedAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * isOkay, integer * mfail);

MTIstatus _NotifyGrpOnAssgnFailAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   MTIconstString invalidUsrOrGrp, MTIconstString attrName, integer * mfail);

MTIstatus _PdpIsApprovedExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * isApproved, integer * mfail);

MTIstatus _PendingChangesRptXMLAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString lineSeparator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _PlannedImpactsRptInt
   (MTIconstString _class, boolean getParent, MTIconstString className,
   SetOfObjects chgObjects, SetOfObjects * objectsForReport, SetOfObjects * objectsForInflate,
   integer * mfail);

MTIstatus _PlannedImpactsRptXMLAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString lineSeparator, ObjectPtr taskObject, ObjectPtr argsObj,
   ObjectPtr * resultXMLObj, boolean * needToTranslit, integer * mfail);

MTIstatus _PrcAffItmForImpMtxRptAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr affObj,
   SetOfObjects resObjSet, SetOfObjects resRelSet, SetOfObjects * objectsForReport,
   SetOfObjects * objectsForInflate, integer * mfail);

MTIstatus _PrcChgEffForBslRptAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr chgObj,
   SetOfObjects * objectsForReport, SetOfObjects * objectsForInflate, integer * mfail);

MTIstatus _PrcChgsForBslRptAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfObjects * objectsForReport, SetOfObjects * objectsForInflate, integer * mfail);

MTIstatus _PrcImplChgForImpMtxRptAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr chgObj,
   SetOfObjects * objectsForReport, SetOfObjects * objectsForInflate, integer * mfail);

MTIstatus _PrcSuppInfoForBslRpt
   (MTIconstString _class, boolean getParent, MTIconstString relClass,
   MTIconstString relshipName, SetOfObjects itemsToProcess, SetOfObjects * objectsForReport,
   SetOfObjects * objectsForInflate, integer * mfail);

MTIstatus _PrcSuppInfoImpMtxRpt
   (MTIconstString _class, boolean getParent, MTIconstString relClass,
   MTIconstString relshipName, ObjectPtr objToProcess, SetOfObjects * objectsForReport,
   SetOfObjects * objectsForInflate, integer * mfail);

MTIstatus _PrdPlnClosureDPIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _PrepareObjForBIImpRptAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr * rootObj, integer * mfail);

MTIstatus _ProceedRelationAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr leftObj,
   boolean * relateResultsIn, integer * mfail);

MTIstatus _ProductPlanClosureIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr prdPlnIt,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _QueryForChgAdmTaskBrwAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr browserItem,
   SetOfStrings databases, SetOfObjects * resultBrwObjs, integer * mfail);

MTIstatus _QueryForReportsSCT
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr argsObj, SetOfObjects * chgObjs, integer * mfail);

MTIstatus _ReviseIncorpPntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr incPntItem,
   ObjectPtr updateDlgObj, integer * mfail);

MTIstatus _SetCmtdEffAttrsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _TransferAllToVaultAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemObj,
   MTIconstString vault, SetOfObjects * failedObjs, integer * mfail);

MTIstatus _UpdPlStrcAprDispRecursAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _UpdPlStrcLCStateRecursAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString newState, string * exitState, string * advComments,
   integer * mfail);

MTIstatus _UpdPlStrcStatusRecursAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString newStatus, string * exitState, string * advComments,
   integer * mfail);

MTIstatus _UpdPlnImpAprDispRecursAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _UpdPlnImpLCStateRecursAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString newState, string * exitState, string * advComments,
   integer * mfail);

MTIstatus _UpdPlnImpStatusRecursAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString newStatus, string * exitState, string * advComments,
   integer * mfail);

MTIstatus _UpdStatusNStateForClsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _UpdateApprvdDispAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _UpdateLCStateAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString newState, integer * mfail);

MTIstatus _UpdateWbsStatusAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString newStatus, integer * mfail);

MTIstatus _ValAffItmForModifyRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValAuthoringForCreRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr prdPlnIt,
   MTIconstString relationName, integer * mfail);

MTIstatus _ValAuthoringForDelRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr prdPlnIt,
   MTIconstString relationName, integer * mfail);

MTIstatus _ValAuthoringForUpdRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr prdPlnIt,
   MTIconstString relationName, integer * mfail);

MTIstatus _ValCdiForStateMachineAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, boolean refresh, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValChangeDispoItemRelsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _ValChgTechDispItemRelsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _ValClaForStateMachineAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   ObjectPtr dialogObj, boolean refresh, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValClassifyChgItemRelsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _ValCsuItemRelsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _ValCtdForStateMachineAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, boolean refresh, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValDoChangeDispoItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, boolean refresh, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValDoChangeStatusItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, boolean refresh, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValDoChgTechDispItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, boolean refresh, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValDoClassifyChgItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   ObjectPtr dialogObj, boolean refresh, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValDoCloseProductPlanAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, boolean refresh, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValDomainForCdiAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * isLocal, integer * mfail);

MTIstatus _ValDomainForClaAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   boolean * isLocal, integer * mfail);

MTIstatus _ValDomainForCsuAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * isLocal, integer * mfail);

MTIstatus _ValDomainForCtdAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * isLocal, integer * mfail);

MTIstatus _ValDomainForPdpClosureAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * isLocal, integer * mfail);

MTIstatus _ValForAsgnChangeAdmExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _ValForAsgnOrignatorExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _ValForAsgnRevBoardExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _ValForAssignAnalystExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _ValForChangeDispoExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _ValForClassifyChgExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   integer * mfail);

MTIstatus _ValForCloseTaskExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr taskItem,
   integer * mfail);

MTIstatus _ValForDeleteAllRevsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr ItemMstrObj,
   SetOfStrings * recurSetPtr, integer * mfail);

MTIstatus _ValForPdpClosureExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   integer * mfail);

MTIstatus _ValForSpfCommittedIPExAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValIfRelatedItmsInVltAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   SetOfObjects itmObjSet, SetOfStrings * val_errors, boolean * inVault,
   integer * mfail);

MTIstatus _ValImplPdpParentForClsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   boolean * okToClose, integer * mfail);

MTIstatus _ValPdpClosureRelsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, integer * mfail);

MTIstatus _ValPdpForCancelExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValPdpForModifyIncorpRAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   ObjectPtr relObj, integer * mfail);

MTIstatus _ValPdpForSuspendExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValPrdPlnForModifyRelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValReviseForChangeAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr itemToRevise,
   ObjectPtr changeItem, integer * mfail);

MTIstatus _ValReviseIncorpPntExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr incPntItem,
   integer * mfail);

MTIstatus _ValSetForChangeDispo
   (MTIconstString _class, boolean getParent, MTIconstString originClassName,
   SetOfObjects passedObjects, SetOfObjects failedObjects, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _ValSetForChangeStatus
   (MTIconstString _class, boolean getParent, MTIconstString originClassName,
   SetOfObjects passedObjects, SetOfObjects failedObjects, SetOfStrings * extraStr,
   SetOfObjects * extraObj, integer * mfail);

MTIstatus _ValidateAttrValidValueAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr originObj,
   ObjectPtr dialogObj, MTIconstString attr, SetOfStrings valueList,
   boolean * isValid, SetOfStrings * badArgs, integer * mfail);

MTIstatus _ValidateDoChangeDispoAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, boolean refresh, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValidateDoChangeStatusAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, boolean refresh, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValidateDoChgTechDispAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, boolean refresh, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValidateDoClassifyChgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr griItem,
   ObjectPtr dialogObj, boolean refresh, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValidateDoPdpClosureAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, boolean refresh, SetOfStrings * badArgs,
   integer * mfail);

MTIstatus _ValidateIncorporation
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr parentObj, ObjectPtr childObj, integer * mfail);

MTIstatus _ValidateNewDispositionValueAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr dialogObj,
   ObjectPtr pdpItem, SetOfStrings * badArgs, integer * mfail);

MTIstatus _ValidateParticipantsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdpItem,
   SetOfStrings * roleMembers, SetOfStrings validUsers, MTIconstString attrName,
   MTIconstString attrFlag, integer * isValidFlag, integer * mfail);

MTIstatus _ValidatePdpForCancelAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _ValidatePdpForCloseAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _ValidatePdpForCloseExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidatePdpForCloseIntAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * badArgs, integer * mfail);

MTIstatus _ValidatePdpForOpenAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _ValidatePdpForOpenExtAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _ValidatePdpForSuspendAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr dialogObj, SetOfStrings * badArgs, integer * mfail);

MTIstatus _VisitChildrenAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr visitorObj,
   ObjectPtr visitedObj, MTIconstString relationship, integer * mfail);

MTIstatus _VisitWbsItemAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr wbsItemObj, integer * mfail);

MTIstatus _VstDetectRecursionAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr visitorObj,
   ObjectPtr visitedObj, integer * mfail);
/*
 *  Protected Messages
 */
/*
 *  Message Macro Definitions.
 */

#define APARBaselineRptXML(thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _APARBaselineRptXMLAtClass(NULL, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define APARBaselineRptXMLAtClass(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _APARBaselineRptXMLAtClass(class, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define APARBaselineRptXMLAtParent(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _APARBaselineRptXMLAtClass(class, TRUE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define AcceptVisitor(thisObj, visitorObj, mfail) \
        _AcceptVisitorAtClass(NULL, FALSE, thisObj, visitorObj, mfail)
#define AcceptVisitorAtClass(class, thisObj, visitorObj, mfail) \
        _AcceptVisitorAtClass(class, FALSE, thisObj, visitorObj, mfail)
#define AcceptVisitorAtParent(class, thisObj, visitorObj, mfail) \
        _AcceptVisitorAtClass(class, TRUE, thisObj, visitorObj, mfail)

#define AffectedItmSummryRpt(thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _AffectedItmSummryRptAtClass(NULL, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define AffectedItmSummryRptAtClass(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _AffectedItmSummryRptAtClass(class, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define AffectedItmSummryRptAtParent(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _AffectedItmSummryRptAtClass(class, TRUE, thisObj, taskObject, argsObj, reportTextStrings, mfail)

#define AllwProcAffItmForCko(thisObj, source, buildRelation, deleteRelation, mfail) \
        _AllwProcAffItmForCkoAtClass(NULL, FALSE, thisObj, source, buildRelation, deleteRelation, mfail)
#define AllwProcAffItmForCkoAtClass(class, thisObj, source, buildRelation, deleteRelation, mfail) \
        _AllwProcAffItmForCkoAtClass(class, FALSE, thisObj, source, buildRelation, deleteRelation, mfail)
#define AllwProcAffItmForCkoAtParent(class, thisObj, source, buildRelation, deleteRelation, mfail) \
        _AllwProcAffItmForCkoAtClass(class, TRUE, thisObj, source, buildRelation, deleteRelation, mfail)

#define AllwProcAffItmForRev(thisObj, source, buildRelation, deleteRelation, mfail) \
        _AllwProcAffItmForRevAtClass(NULL, FALSE, thisObj, source, buildRelation, deleteRelation, mfail)
#define AllwProcAffItmForRevAtClass(class, thisObj, source, buildRelation, deleteRelation, mfail) \
        _AllwProcAffItmForRevAtClass(class, FALSE, thisObj, source, buildRelation, deleteRelation, mfail)
#define AllwProcAffItmForRevAtParent(class, thisObj, source, buildRelation, deleteRelation, mfail) \
        _AllwProcAffItmForRevAtClass(class, TRUE, thisObj, source, buildRelation, deleteRelation, mfail)

#define AssignAnalyst(pdpItem, analyst, mfail) \
        _AssignAnalystAtClass(NULL, FALSE, pdpItem, analyst, mfail)
#define AssignAnalystAtClass(class, pdpItem, analyst, mfail) \
        _AssignAnalystAtClass(class, FALSE, pdpItem, analyst, mfail)
#define AssignAnalystAtParent(class, pdpItem, analyst, mfail) \
        _AssignAnalystAtClass(class, TRUE, pdpItem, analyst, mfail)

#define AssignAnalyst2(pdpItem, dialogObj, mfail) \
        _AssignAnalyst2AtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define AssignAnalyst2AtClass(class, pdpItem, dialogObj, mfail) \
        _AssignAnalyst2AtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define AssignAnalyst2AtParent(class, pdpItem, dialogObj, mfail) \
        _AssignAnalyst2AtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define AssignAnalystDP(thisObj, mfail) \
        _AssignAnalystDPAtClass(NULL, FALSE, thisObj, mfail)
#define AssignAnalystDPAtClass(class, thisObj, mfail) \
        _AssignAnalystDPAtClass(class, FALSE, thisObj, mfail)
#define AssignAnalystDPAtParent(class, thisObj, mfail) \
        _AssignAnalystDPAtClass(class, TRUE, thisObj, mfail)

#define AssignChangeAdmin(pdpItem, chgAdmin, mfail) \
        _AssignChangeAdminAtClass(NULL, FALSE, pdpItem, chgAdmin, mfail)
#define AssignChangeAdminAtClass(class, pdpItem, chgAdmin, mfail) \
        _AssignChangeAdminAtClass(class, FALSE, pdpItem, chgAdmin, mfail)
#define AssignChangeAdminAtParent(class, pdpItem, chgAdmin, mfail) \
        _AssignChangeAdminAtClass(class, TRUE, pdpItem, chgAdmin, mfail)

#define AssignChangeAdmin2(pdpItem, dialogObj, mfail) \
        _AssignChangeAdmin2AtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define AssignChangeAdmin2AtClass(class, pdpItem, dialogObj, mfail) \
        _AssignChangeAdmin2AtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define AssignChangeAdmin2AtParent(class, pdpItem, dialogObj, mfail) \
        _AssignChangeAdmin2AtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define AssignChangeAdminDP(thisObj, mfail) \
        _AssignChangeAdminDPAtClass(NULL, FALSE, thisObj, mfail)
#define AssignChangeAdminDPAtClass(class, thisObj, mfail) \
        _AssignChangeAdminDPAtClass(class, FALSE, thisObj, mfail)
#define AssignChangeAdminDPAtParent(class, thisObj, mfail) \
        _AssignChangeAdminDPAtClass(class, TRUE, thisObj, mfail)

#define AssignDefaultAnalyst(pdpItem, mfail) \
        _AssignDefaultAnalystAtClass(NULL, FALSE, pdpItem, mfail)
#define AssignDefaultAnalystAtClass(class, pdpItem, mfail) \
        _AssignDefaultAnalystAtClass(class, FALSE, pdpItem, mfail)
#define AssignDefaultAnalystAtParent(class, pdpItem, mfail) \
        _AssignDefaultAnalystAtClass(class, TRUE, pdpItem, mfail)

#define AssignDefaultChgAdmin(pdpItem, mfail) \
        _AssignDefaultChgAdminAtClass(NULL, FALSE, pdpItem, mfail)
#define AssignDefaultChgAdminAtClass(class, pdpItem, mfail) \
        _AssignDefaultChgAdminAtClass(class, FALSE, pdpItem, mfail)
#define AssignDefaultChgAdminAtParent(class, pdpItem, mfail) \
        _AssignDefaultChgAdminAtClass(class, TRUE, pdpItem, mfail)

#define AssignDefaultOrigin(pdpItem, mfail) \
        _AssignDefaultOriginAtClass(NULL, FALSE, pdpItem, mfail)
#define AssignDefaultOriginAtClass(class, pdpItem, mfail) \
        _AssignDefaultOriginAtClass(class, FALSE, pdpItem, mfail)
#define AssignDefaultOriginAtParent(class, pdpItem, mfail) \
        _AssignDefaultOriginAtClass(class, TRUE, pdpItem, mfail)

#define AssignDefaultRevBoard(pdpItem, mfail) \
        _AssignDefaultRevBoardAtClass(NULL, FALSE, pdpItem, mfail)
#define AssignDefaultRevBoardAtClass(class, pdpItem, mfail) \
        _AssignDefaultRevBoardAtClass(class, FALSE, pdpItem, mfail)
#define AssignDefaultRevBoardAtParent(class, pdpItem, mfail) \
        _AssignDefaultRevBoardAtClass(class, TRUE, pdpItem, mfail)

#define AssignDefaultValue(pdpItem, numMembers, constantRoleName, constantGrpName, attrName, attrFlag, mfail) \
        _AssignDefaultValueAtClass(NULL, FALSE, pdpItem, numMembers, constantRoleName, constantGrpName, attrName, attrFlag, mfail)
#define AssignDefaultValueAtClass(class, pdpItem, numMembers, constantRoleName, constantGrpName, attrName, attrFlag, mfail) \
        _AssignDefaultValueAtClass(class, FALSE, pdpItem, numMembers, constantRoleName, constantGrpName, attrName, attrFlag, mfail)
#define AssignDefaultValueAtParent(class, pdpItem, numMembers, constantRoleName, constantGrpName, attrName, attrFlag, mfail) \
        _AssignDefaultValueAtClass(class, TRUE, pdpItem, numMembers, constantRoleName, constantGrpName, attrName, attrFlag, mfail)

#define AssignOriginator(pdpItem, newOriginator, mfail) \
        _AssignOriginatorAtClass(NULL, FALSE, pdpItem, newOriginator, mfail)
#define AssignOriginatorAtClass(class, pdpItem, newOriginator, mfail) \
        _AssignOriginatorAtClass(class, FALSE, pdpItem, newOriginator, mfail)
#define AssignOriginatorAtParent(class, pdpItem, newOriginator, mfail) \
        _AssignOriginatorAtClass(class, TRUE, pdpItem, newOriginator, mfail)

#define AssignOriginator2(pdpItem, dialogObj, mfail) \
        _AssignOriginator2AtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define AssignOriginator2AtClass(class, pdpItem, dialogObj, mfail) \
        _AssignOriginator2AtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define AssignOriginator2AtParent(class, pdpItem, dialogObj, mfail) \
        _AssignOriginator2AtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define AssignOriginatorDP(thisObj, mfail) \
        _AssignOriginatorDPAtClass(NULL, FALSE, thisObj, mfail)
#define AssignOriginatorDPAtClass(class, thisObj, mfail) \
        _AssignOriginatorDPAtClass(class, FALSE, thisObj, mfail)
#define AssignOriginatorDPAtParent(class, thisObj, mfail) \
        _AssignOriginatorDPAtClass(class, TRUE, thisObj, mfail)

#define AssignRevBoard(pdpItem, revBoard, mfail) \
        _AssignRevBoardAtClass(NULL, FALSE, pdpItem, revBoard, mfail)
#define AssignRevBoardAtClass(class, pdpItem, revBoard, mfail) \
        _AssignRevBoardAtClass(class, FALSE, pdpItem, revBoard, mfail)
#define AssignRevBoardAtParent(class, pdpItem, revBoard, mfail) \
        _AssignRevBoardAtClass(class, TRUE, pdpItem, revBoard, mfail)

#define AssignRevBoardDP(thisObj, mfail) \
        _AssignRevBoardDPAtClass(NULL, FALSE, thisObj, mfail)
#define AssignRevBoardDPAtClass(class, thisObj, mfail) \
        _AssignRevBoardDPAtClass(class, FALSE, thisObj, mfail)
#define AssignRevBoardDPAtParent(class, thisObj, mfail) \
        _AssignRevBoardDPAtClass(class, TRUE, thisObj, mfail)

#define AssignValueFromList(pdpItem, attrName, roleMembers, attrFlag, mfail) \
        _AssignValueFromListAtClass(NULL, FALSE, pdpItem, attrName, roleMembers, attrFlag, mfail)
#define AssignValueFromListAtClass(class, pdpItem, attrName, roleMembers, attrFlag, mfail) \
        _AssignValueFromListAtClass(class, FALSE, pdpItem, attrName, roleMembers, attrFlag, mfail)
#define AssignValueFromListAtParent(class, pdpItem, attrName, roleMembers, attrFlag, mfail) \
        _AssignValueFromListAtClass(class, TRUE, pdpItem, attrName, roleMembers, attrFlag, mfail)

#define AuthorizeForCkin(workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForCkinAtClass(NULL, FALSE, workItem, dialogObj, badArgs, mfail)
#define AuthorizeForCkinAtClass(class, workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForCkinAtClass(class, FALSE, workItem, dialogObj, badArgs, mfail)
#define AuthorizeForCkinAtParent(class, workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForCkinAtClass(class, TRUE, workItem, dialogObj, badArgs, mfail)

#define AuthorizeForCkir(workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForCkirAtClass(NULL, FALSE, workItem, dialogObj, badArgs, mfail)
#define AuthorizeForCkirAtClass(class, workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForCkirAtClass(class, FALSE, workItem, dialogObj, badArgs, mfail)
#define AuthorizeForCkirAtParent(class, workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForCkirAtClass(class, TRUE, workItem, dialogObj, badArgs, mfail)

#define AuthorizeForCko(thisObj, dialogObj, badArgs, mfail) \
        _AuthorizeForCkoAtClass(NULL, FALSE, thisObj, dialogObj, badArgs, mfail)
#define AuthorizeForCkoAtClass(class, thisObj, dialogObj, badArgs, mfail) \
        _AuthorizeForCkoAtClass(class, FALSE, thisObj, dialogObj, badArgs, mfail)
#define AuthorizeForCkoAtParent(class, thisObj, dialogObj, badArgs, mfail) \
        _AuthorizeForCkoAtClass(class, TRUE, thisObj, dialogObj, badArgs, mfail)

#define AuthorizeForCpy(workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForCpyAtClass(NULL, FALSE, workItem, dialogObj, badArgs, mfail)
#define AuthorizeForCpyAtClass(class, workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForCpyAtClass(class, FALSE, workItem, dialogObj, badArgs, mfail)
#define AuthorizeForCpyAtParent(class, workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForCpyAtClass(class, TRUE, workItem, dialogObj, badArgs, mfail)

#define AuthorizeForCre(thisObj, dialogObj, badArgs, mfail) \
        _AuthorizeForCreAtClass(NULL, FALSE, thisObj, dialogObj, badArgs, mfail)
#define AuthorizeForCreAtClass(class, thisObj, dialogObj, badArgs, mfail) \
        _AuthorizeForCreAtClass(class, FALSE, thisObj, dialogObj, badArgs, mfail)
#define AuthorizeForCreAtParent(class, thisObj, dialogObj, badArgs, mfail) \
        _AuthorizeForCreAtClass(class, TRUE, thisObj, dialogObj, badArgs, mfail)

#define AuthorizeForDel(workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForDelAtClass(NULL, FALSE, workItem, dialogObj, badArgs, mfail)
#define AuthorizeForDelAtClass(class, workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForDelAtClass(class, FALSE, workItem, dialogObj, badArgs, mfail)
#define AuthorizeForDelAtParent(class, workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForDelAtClass(class, TRUE, workItem, dialogObj, badArgs, mfail)

#define AuthorizeForMkv(workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForMkvAtClass(NULL, FALSE, workItem, dialogObj, badArgs, mfail)
#define AuthorizeForMkvAtClass(class, workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForMkvAtClass(class, FALSE, workItem, dialogObj, badArgs, mfail)
#define AuthorizeForMkvAtParent(class, workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForMkvAtClass(class, TRUE, workItem, dialogObj, badArgs, mfail)

#define AuthorizeForRev(workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForRevAtClass(NULL, FALSE, workItem, dialogObj, badArgs, mfail)
#define AuthorizeForRevAtClass(class, workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForRevAtClass(class, FALSE, workItem, dialogObj, badArgs, mfail)
#define AuthorizeForRevAtParent(class, workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForRevAtClass(class, TRUE, workItem, dialogObj, badArgs, mfail)

#define AuthorizeForUpd(workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForUpdAtClass(NULL, FALSE, workItem, dialogObj, badArgs, mfail)
#define AuthorizeForUpdAtClass(class, workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForUpdAtClass(class, FALSE, workItem, dialogObj, badArgs, mfail)
#define AuthorizeForUpdAtParent(class, workItem, dialogObj, badArgs, mfail) \
        _AuthorizeForUpdAtClass(class, TRUE, workItem, dialogObj, badArgs, mfail)

#define CalPdpCycleTime(thisObj, mfail) \
        _CalPdpCycleTimeAtClass(NULL, FALSE, thisObj, mfail)
#define CalPdpCycleTimeAtClass(class, thisObj, mfail) \
        _CalPdpCycleTimeAtClass(class, FALSE, thisObj, mfail)
#define CalPdpCycleTimeAtParent(class, thisObj, mfail) \
        _CalPdpCycleTimeAtClass(class, TRUE, thisObj, mfail)

#define ChangeDispoItem(pdpItem, disposition, dispoComments, mfail) \
        _ChangeDispoItemAtClass(NULL, FALSE, pdpItem, disposition, dispoComments, mfail)
#define ChangeDispoItemAtClass(class, pdpItem, disposition, dispoComments, mfail) \
        _ChangeDispoItemAtClass(class, FALSE, pdpItem, disposition, dispoComments, mfail)
#define ChangeDispoItemAtParent(class, pdpItem, disposition, dispoComments, mfail) \
        _ChangeDispoItemAtClass(class, TRUE, pdpItem, disposition, dispoComments, mfail)

#define ChangeDispoItem2(pdpItem, dialogObj, mfail) \
        _ChangeDispoItem2AtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define ChangeDispoItem2AtClass(class, pdpItem, dialogObj, mfail) \
        _ChangeDispoItem2AtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define ChangeDispoItem2AtParent(class, pdpItem, dialogObj, mfail) \
        _ChangeDispoItem2AtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define ChangeDispoItemDP(thisObj, mfail) \
        _ChangeDispoItemDPAtClass(NULL, FALSE, thisObj, mfail)
#define ChangeDispoItemDPAtClass(class, thisObj, mfail) \
        _ChangeDispoItemDPAtClass(class, FALSE, thisObj, mfail)
#define ChangeDispoItemDPAtParent(class, thisObj, mfail) \
        _ChangeDispoItemDPAtClass(class, TRUE, thisObj, mfail)

#define ChangeDispoItemDPInt(thisObj, mfail) \
        _ChangeDispoItemDPIntAtClass(NULL, FALSE, thisObj, mfail)
#define ChangeDispoItemDPIntAtClass(class, thisObj, mfail) \
        _ChangeDispoItemDPIntAtClass(class, FALSE, thisObj, mfail)
#define ChangeDispoItemDPIntAtParent(class, thisObj, mfail) \
        _ChangeDispoItemDPIntAtClass(class, TRUE, thisObj, mfail)

#define ChangeDispoItemInt(thisObj, dialogObj, mfail) \
        _ChangeDispoItemIntAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define ChangeDispoItemIntAtClass(class, thisObj, dialogObj, mfail) \
        _ChangeDispoItemIntAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define ChangeDispoItemIntAtParent(class, thisObj, dialogObj, mfail) \
        _ChangeDispoItemIntAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define ChangeDispoItemSetDP(className, SelectedItems, mfail) \
        _ChangeDispoItemSetDP(className, FALSE, className, SelectedItems, mfail)
#define ChangeDispoItemSetDPAtParent(_class, className, SelectedItems, mfail) \
        _ChangeDispoItemSetDP(_class, TRUE, className, SelectedItems, mfail)

#define ChangeStatusItem(pdpItem, wbsStatus, mfail) \
        _ChangeStatusItemAtClass(NULL, FALSE, pdpItem, wbsStatus, mfail)
#define ChangeStatusItemAtClass(class, pdpItem, wbsStatus, mfail) \
        _ChangeStatusItemAtClass(class, FALSE, pdpItem, wbsStatus, mfail)
#define ChangeStatusItemAtParent(class, pdpItem, wbsStatus, mfail) \
        _ChangeStatusItemAtClass(class, TRUE, pdpItem, wbsStatus, mfail)

#define ChangeStatusItemDP(thisObj, mfail) \
        _ChangeStatusItemDPAtClass(NULL, FALSE, thisObj, mfail)
#define ChangeStatusItemDPAtClass(class, thisObj, mfail) \
        _ChangeStatusItemDPAtClass(class, FALSE, thisObj, mfail)
#define ChangeStatusItemDPAtParent(class, thisObj, mfail) \
        _ChangeStatusItemDPAtClass(class, TRUE, thisObj, mfail)

#define ChangeStatusItemDPInt(thisObj, mfail) \
        _ChangeStatusItemDPIntAtClass(NULL, FALSE, thisObj, mfail)
#define ChangeStatusItemDPIntAtClass(class, thisObj, mfail) \
        _ChangeStatusItemDPIntAtClass(class, FALSE, thisObj, mfail)
#define ChangeStatusItemDPIntAtParent(class, thisObj, mfail) \
        _ChangeStatusItemDPIntAtClass(class, TRUE, thisObj, mfail)

#define ChangeStatusItemInt(workItem, dialogObj, mfail) \
        _ChangeStatusItemIntAtClass(NULL, FALSE, workItem, dialogObj, mfail)
#define ChangeStatusItemIntAtClass(class, workItem, dialogObj, mfail) \
        _ChangeStatusItemIntAtClass(class, FALSE, workItem, dialogObj, mfail)
#define ChangeStatusItemIntAtParent(class, workItem, dialogObj, mfail) \
        _ChangeStatusItemIntAtClass(class, TRUE, workItem, dialogObj, mfail)

#define ChangeStatusItemSetDP(className, SelectedItems, mfail) \
        _ChangeStatusItemSetDP(className, FALSE, className, SelectedItems, mfail)
#define ChangeStatusItemSetDPAtParent(_class, className, SelectedItems, mfail) \
        _ChangeStatusItemSetDP(_class, TRUE, className, SelectedItems, mfail)

#define CheckPdpCanceled(pdpItem, mfail) \
        _CheckPdpCanceledAtClass(NULL, FALSE, pdpItem, mfail)
#define CheckPdpCanceledAtClass(class, pdpItem, mfail) \
        _CheckPdpCanceledAtClass(class, FALSE, pdpItem, mfail)
#define CheckPdpCanceledAtParent(class, pdpItem, mfail) \
        _CheckPdpCanceledAtClass(class, TRUE, pdpItem, mfail)

#define CheckPdpClosed(pdpItem, mfail) \
        _CheckPdpClosedAtClass(NULL, FALSE, pdpItem, mfail)
#define CheckPdpClosedAtClass(class, pdpItem, mfail) \
        _CheckPdpClosedAtClass(class, FALSE, pdpItem, mfail)
#define CheckPdpClosedAtParent(class, pdpItem, mfail) \
        _CheckPdpClosedAtClass(class, TRUE, pdpItem, mfail)

#define ChgClosureSummaryRpt(thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _ChgClosureSummaryRptAtClass(NULL, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define ChgClosureSummaryRptAtClass(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _ChgClosureSummaryRptAtClass(class, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define ChgClosureSummaryRptAtParent(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _ChgClosureSummaryRptAtClass(class, TRUE, thisObj, taskObject, argsObj, reportTextStrings, mfail)

#define ChgClosureSummaryXML(thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _ChgClosureSummaryXMLAtClass(NULL, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define ChgClosureSummaryXMLAtClass(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _ChgClosureSummaryXMLAtClass(class, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define ChgClosureSummaryXMLAtParent(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _ChgClosureSummaryXMLAtClass(class, TRUE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define ChgCycleTMetricRpt(className, selectedItems, taskObject, argsObj, reportTextStrings, mfail) \
        _ChgCycleTMetricRpt(className, FALSE, className, selectedItems, taskObject, argsObj, reportTextStrings, mfail)
#define ChgCycleTMetricRptAtParent(_class, className, selectedItems, taskObject, argsObj, reportTextStrings, mfail) \
        _ChgCycleTMetricRpt(_class, TRUE, className, selectedItems, taskObject, argsObj, reportTextStrings, mfail)

#define ChgDetailRpt(thisObj, taskObject, argsObj, report, mfail) \
        _ChgDetailRptAtClass(NULL, FALSE, thisObj, taskObject, argsObj, report, mfail)
#define ChgDetailRptAtClass(class, thisObj, taskObject, argsObj, report, mfail) \
        _ChgDetailRptAtClass(class, FALSE, thisObj, taskObject, argsObj, report, mfail)
#define ChgDetailRptAtParent(class, thisObj, taskObject, argsObj, report, mfail) \
        _ChgDetailRptAtClass(class, TRUE, thisObj, taskObject, argsObj, report, mfail)

#define ChgDetailRptInt(className, chgObjects, objectsForReport, objectsForInflate, mfail) \
        _ChgDetailRptInt(className, FALSE, className, chgObjects, objectsForReport, objectsForInflate, mfail)
#define ChgDetailRptIntAtParent(_class, className, chgObjects, objectsForReport, objectsForInflate, mfail) \
        _ChgDetailRptInt(_class, TRUE, className, chgObjects, objectsForReport, objectsForInflate, mfail)

#define ChgDetailRptXML(thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _ChgDetailRptXMLAtClass(NULL, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define ChgDetailRptXMLAtClass(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _ChgDetailRptXMLAtClass(class, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define ChgDetailRptXMLAtParent(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _ChgDetailRptXMLAtClass(class, TRUE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define ChgDispPrdPlnIt(obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgDispPrdPlnItAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgDispPrdPlnItAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgDispPrdPlnItAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgDispPrdPlnItAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgDispPrdPlnItAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define ChgDispPrdPlnToApprvd(obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgDispPrdPlnToApprvdAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgDispPrdPlnToApprvdAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgDispPrdPlnToApprvdAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgDispPrdPlnToApprvdAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgDispPrdPlnToApprvdAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define ChgEffectivityRptXML(thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _ChgEffectivityRptXMLAtClass(NULL, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define ChgEffectivityRptXMLAtClass(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _ChgEffectivityRptXMLAtClass(class, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define ChgEffectivityRptXMLAtParent(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _ChgEffectivityRptXMLAtClass(class, TRUE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define ChgImpactMatrixRptXML(thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _ChgImpactMatrixRptXMLAtClass(NULL, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define ChgImpactMatrixRptXMLAtClass(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _ChgImpactMatrixRptXMLAtClass(class, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define ChgImpactMatrixRptXMLAtParent(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _ChgImpactMatrixRptXMLAtClass(class, TRUE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define ChgPrdPlnClosurToClosd(obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgPrdPlnClosurToClosdAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgPrdPlnClosurToClosdAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgPrdPlnClosurToClosdAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgPrdPlnClosurToClosdAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgPrdPlnClosurToClosdAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define ChgReconcilationRpt(thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _ChgReconcilationRptAtClass(NULL, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define ChgReconcilationRptAtClass(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _ChgReconcilationRptAtClass(class, FALSE, thisObj, taskObject, argsObj, reportTextStrings, mfail)
#define ChgReconcilationRptAtParent(class, thisObj, taskObject, argsObj, reportTextStrings, mfail) \
        _ChgReconcilationRptAtClass(class, TRUE, thisObj, taskObject, argsObj, reportTextStrings, mfail)

#define ChgResultsInRptInt(className, chgObjects, objectsForReport, objectsForInflate, mfail) \
        _ChgResultsInRptInt(className, FALSE, className, chgObjects, objectsForReport, objectsForInflate, mfail)
#define ChgResultsInRptIntAtParent(_class, className, chgObjects, objectsForReport, objectsForInflate, mfail) \
        _ChgResultsInRptInt(_class, TRUE, className, chgObjects, objectsForReport, objectsForInflate, mfail)

#define ChgResultsInRptXML(thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _ChgResultsInRptXMLAtClass(NULL, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define ChgResultsInRptXMLAtClass(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _ChgResultsInRptXMLAtClass(class, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define ChgResultsInRptXMLAtParent(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _ChgResultsInRptXMLAtClass(class, TRUE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define ChgStateECNToExecuting(obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStateECNToExecutingAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgStateECNToExecutingAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStateECNToExecutingAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgStateECNToExecutingAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStateECNToExecutingAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define ChgStateECNToIncrptd(obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStateECNToIncrptdAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgStateECNToIncrptdAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStateECNToIncrptdAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgStateECNToIncrptdAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStateECNToIncrptdAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define ChgStatePdpToExecuting(obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatePdpToExecutingAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgStatePdpToExecutingAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatePdpToExecutingAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgStatePdpToExecutingAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatePdpToExecutingAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define ChgStatePrdPlnToAuthrg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatePrdPlnToAuthrgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgStatePrdPlnToAuthrgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatePrdPlnToAuthrgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgStatePrdPlnToAuthrgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatePrdPlnToAuthrgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define ChgStatePrdPlnToIncrp(obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatePrdPlnToIncrpAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgStatePrdPlnToIncrpAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatePrdPlnToIncrpAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgStatePrdPlnToIncrpAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatePrdPlnToIncrpAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define ChgStatePrdPlnToReady(obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatePrdPlnToReadyAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgStatePrdPlnToReadyAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatePrdPlnToReadyAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgStatePrdPlnToReadyAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatePrdPlnToReadyAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define ChgStatePrdPlnToReview(obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatePrdPlnToReviewAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgStatePrdPlnToReviewAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatePrdPlnToReviewAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgStatePrdPlnToReviewAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatePrdPlnToReviewAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define ChgStatusPdpToCompltd(obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatusPdpToCompltdAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgStatusPdpToCompltdAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatusPdpToCompltdAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgStatusPdpToCompltdAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatusPdpToCompltdAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define ChgStatusPdpToProgress(obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatusPdpToProgressAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgStatusPdpToProgressAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatusPdpToProgressAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ChgStatusPdpToProgressAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ChgStatusPdpToProgressAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define ChgStatusSummaryRpt(className, selectedItems, taskObject, argsObj, reportTextStrings, mfail) \
        _ChgStatusSummaryRpt(className, FALSE, className, selectedItems, taskObject, argsObj, reportTextStrings, mfail)
#define ChgStatusSummaryRptAtParent(_class, className, selectedItems, taskObject, argsObj, reportTextStrings, mfail) \
        _ChgStatusSummaryRpt(_class, TRUE, className, selectedItems, taskObject, argsObj, reportTextStrings, mfail)

#define ChgTechDispItem(pdpItem, techDisposition, techRevPriority, prbVerifSummary, ramifications, mfail) \
        _ChgTechDispItemAtClass(NULL, FALSE, pdpItem, techDisposition, techRevPriority, prbVerifSummary, ramifications, mfail)
#define ChgTechDispItemAtClass(class, pdpItem, techDisposition, techRevPriority, prbVerifSummary, ramifications, mfail) \
        _ChgTechDispItemAtClass(class, FALSE, pdpItem, techDisposition, techRevPriority, prbVerifSummary, ramifications, mfail)
#define ChgTechDispItemAtParent(class, pdpItem, techDisposition, techRevPriority, prbVerifSummary, ramifications, mfail) \
        _ChgTechDispItemAtClass(class, TRUE, pdpItem, techDisposition, techRevPriority, prbVerifSummary, ramifications, mfail)

#define ChgTechDispItemDP(thisObj, mfail) \
        _ChgTechDispItemDPAtClass(NULL, FALSE, thisObj, mfail)
#define ChgTechDispItemDPAtClass(class, thisObj, mfail) \
        _ChgTechDispItemDPAtClass(class, FALSE, thisObj, mfail)
#define ChgTechDispItemDPAtParent(class, thisObj, mfail) \
        _ChgTechDispItemDPAtClass(class, TRUE, thisObj, mfail)

#define ChgTechDispItemDPInt(thisObj, mfail) \
        _ChgTechDispItemDPIntAtClass(NULL, FALSE, thisObj, mfail)
#define ChgTechDispItemDPIntAtClass(class, thisObj, mfail) \
        _ChgTechDispItemDPIntAtClass(class, FALSE, thisObj, mfail)
#define ChgTechDispItemDPIntAtParent(class, thisObj, mfail) \
        _ChgTechDispItemDPIntAtClass(class, TRUE, thisObj, mfail)

#define ChgTechDispItemInt(thisObj, dialogObj, mfail) \
        _ChgTechDispItemIntAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define ChgTechDispItemIntAtClass(class, thisObj, dialogObj, mfail) \
        _ChgTechDispItemIntAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define ChgTechDispItemIntAtParent(class, thisObj, dialogObj, mfail) \
        _ChgTechDispItemIntAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define ClassifyChgItem(griItem, reason, wbsPriority, classification, mfail) \
        _ClassifyChgItemAtClass(NULL, FALSE, griItem, reason, wbsPriority, classification, mfail)
#define ClassifyChgItemAtClass(class, griItem, reason, wbsPriority, classification, mfail) \
        _ClassifyChgItemAtClass(class, FALSE, griItem, reason, wbsPriority, classification, mfail)
#define ClassifyChgItemAtParent(class, griItem, reason, wbsPriority, classification, mfail) \
        _ClassifyChgItemAtClass(class, TRUE, griItem, reason, wbsPriority, classification, mfail)

#define ClassifyChgItemDP(thisObj, mfail) \
        _ClassifyChgItemDPAtClass(NULL, FALSE, thisObj, mfail)
#define ClassifyChgItemDPAtClass(class, thisObj, mfail) \
        _ClassifyChgItemDPAtClass(class, FALSE, thisObj, mfail)
#define ClassifyChgItemDPAtParent(class, thisObj, mfail) \
        _ClassifyChgItemDPAtClass(class, TRUE, thisObj, mfail)

#define ClassifyChgItemDPInt(griItem, mfail) \
        _ClassifyChgItemDPIntAtClass(NULL, FALSE, griItem, mfail)
#define ClassifyChgItemDPIntAtClass(class, griItem, mfail) \
        _ClassifyChgItemDPIntAtClass(class, FALSE, griItem, mfail)
#define ClassifyChgItemDPIntAtParent(class, griItem, mfail) \
        _ClassifyChgItemDPIntAtClass(class, TRUE, griItem, mfail)

#define ClassifyChgItemInt(griItem, dialogObj, mfail) \
        _ClassifyChgItemIntAtClass(NULL, FALSE, griItem, dialogObj, mfail)
#define ClassifyChgItemIntAtClass(class, griItem, dialogObj, mfail) \
        _ClassifyChgItemIntAtClass(class, FALSE, griItem, dialogObj, mfail)
#define ClassifyChgItemIntAtParent(class, griItem, dialogObj, mfail) \
        _ClassifyChgItemIntAtClass(class, TRUE, griItem, dialogObj, mfail)

#define ClassifyChgItemIntExt(griItem, dialogObj, mfail) \
        _ClassifyChgItemIntExtAtClass(NULL, FALSE, griItem, dialogObj, mfail)
#define ClassifyChgItemIntExtAtClass(class, griItem, dialogObj, mfail) \
        _ClassifyChgItemIntExtAtClass(class, FALSE, griItem, dialogObj, mfail)
#define ClassifyChgItemIntExtAtParent(class, griItem, dialogObj, mfail) \
        _ClassifyChgItemIntExtAtClass(class, TRUE, griItem, dialogObj, mfail)

#define CloseTask(taskItem, closure_comments, mfail) \
        _CloseTaskAtClass(NULL, FALSE, taskItem, closure_comments, mfail)
#define CloseTaskAtClass(class, taskItem, closure_comments, mfail) \
        _CloseTaskAtClass(class, FALSE, taskItem, closure_comments, mfail)
#define CloseTaskAtParent(class, taskItem, closure_comments, mfail) \
        _CloseTaskAtClass(class, TRUE, taskItem, closure_comments, mfail)

#define CreateRelationObj(thisObj, leftObj, rightObj, relationObj, mfail) \
        _CreateRelationObjAtClass(NULL, FALSE, thisObj, leftObj, rightObj, relationObj, mfail)
#define CreateRelationObjAtClass(class, thisObj, leftObj, rightObj, relationObj, mfail) \
        _CreateRelationObjAtClass(class, FALSE, thisObj, leftObj, rightObj, relationObj, mfail)
#define CreateRelationObjAtParent(class, thisObj, leftObj, rightObj, relationObj, mfail) \
        _CreateRelationObjAtClass(class, TRUE, thisObj, leftObj, rightObj, relationObj, mfail)

#define DGetLVSAfrDisposition(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSAfrDispositionAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSAfrDispositionAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSAfrDispositionAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSAfrDispositionAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSAfrDispositionAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSAfrType(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSAfrTypeAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSAfrTypeAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSAfrTypeAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSAfrTypeAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSAfrTypeAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSCcfAdmins(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfAdminsAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfAdminsAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfAdminsAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfAdminsAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfAdminsAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSCcfAnalysts(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfAnalystsAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfAnalystsAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfAnalystsAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfAnalystsAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfAnalystsAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSCcfClassify(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfClassifyAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfClassifyAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfClassifyAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfClassifyAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfClassifyAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSCcfClosure(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfClosureAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfClosureAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfClosureAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfClosureAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfClosureAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSCcfDisposition(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfDispositionAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfDispositionAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfDispositionAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfDispositionAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfDispositionAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSCcfOriginators(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfOriginatorsAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfOriginatorsAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfOriginatorsAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfOriginatorsAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfOriginatorsAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSCcfPlanStatus(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfPlanStatusAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfPlanStatusAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfPlanStatusAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfPlanStatusAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfPlanStatusAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSCcfPriority(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfPriorityAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfPriorityAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfPriorityAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfPriorityAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfPriorityAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSCcfReason(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfReasonAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfReasonAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfReasonAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfReasonAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfReasonAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSCcfReviewers(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfReviewersAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfReviewersAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfReviewersAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfReviewersAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfReviewersAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSCcfStatus(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfStatusAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfStatusAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfStatusAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfStatusAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfStatusAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSCcfTechDisp(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfTechDispAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfTechDispAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfTechDispAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfTechDispAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfTechDispAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSCcfTechRevPty(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfTechRevPtyAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfTechRevPtyAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfTechRevPtyAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCcfTechRevPtyAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCcfTechRevPtyAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSCfiDisposition(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCfiDispositionAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCfiDispositionAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCfiDispositionAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSCfiDispositionAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSCfiDispositionAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSChgTypeForDvRq(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSChgTypeForDvRqAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSChgTypeForDvRqAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSChgTypeForDvRqAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSChgTypeForDvRqAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSChgTypeForDvRqAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DGetLVSISDisposition(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSISDispositionAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSISDispositionAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSISDispositionAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define DGetLVSISDispositionAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _DGetLVSISDispositionAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define DetectRecursion(className, role, checkMstrObj, startMstrObj, recursionDectected, mfail) \
        _DetectRecursion(className, FALSE, className, role, checkMstrObj, startMstrObj, recursionDectected, mfail)
#define DetectRecursionAtParent(_class, className, role, checkMstrObj, startMstrObj, recursionDectected, mfail) \
        _DetectRecursion(_class, TRUE, className, role, checkMstrObj, startMstrObj, recursionDectected, mfail)

#define DetermineIPRelClass(className, itemObj, realClassName, mfail) \
        _DetermineIPRelClass(className, FALSE, className, itemObj, realClassName, mfail)
#define DetermineIPRelClassAtParent(_class, className, itemObj, realClassName, mfail) \
        _DetermineIPRelClass(_class, TRUE, className, itemObj, realClassName, mfail)

#define DoAadFailureCleanup(pdpItem, dialogObj, mfail) \
        _DoAadFailureCleanupAtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define DoAadFailureCleanupAtClass(class, pdpItem, dialogObj, mfail) \
        _DoAadFailureCleanupAtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define DoAadFailureCleanupAtParent(class, pdpItem, dialogObj, mfail) \
        _DoAadFailureCleanupAtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define DoAanFailureCleanup(pdpItem, dialogObj, mfail) \
        _DoAanFailureCleanupAtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define DoAanFailureCleanupAtClass(class, pdpItem, dialogObj, mfail) \
        _DoAanFailureCleanupAtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define DoAanFailureCleanupAtParent(class, pdpItem, dialogObj, mfail) \
        _DoAanFailureCleanupAtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define DoAssignAnalyst(pdpItem, dialogObj, mfail) \
        _DoAssignAnalystAtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignAnalystAtClass(class, pdpItem, dialogObj, mfail) \
        _DoAssignAnalystAtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignAnalystAtParent(class, pdpItem, dialogObj, mfail) \
        _DoAssignAnalystAtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define DoAssignAnalystPost(pdpItem, dialogObj, mfail) \
        _DoAssignAnalystPostAtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignAnalystPostAtClass(class, pdpItem, dialogObj, mfail) \
        _DoAssignAnalystPostAtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignAnalystPostAtParent(class, pdpItem, dialogObj, mfail) \
        _DoAssignAnalystPostAtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define DoAssignAnalystPre(pdpItem, dialogObj, mfail) \
        _DoAssignAnalystPreAtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignAnalystPreAtClass(class, pdpItem, dialogObj, mfail) \
        _DoAssignAnalystPreAtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignAnalystPreAtParent(class, pdpItem, dialogObj, mfail) \
        _DoAssignAnalystPreAtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define DoAssignChangeAdmin(pdpItem, dialogObj, mfail) \
        _DoAssignChangeAdminAtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignChangeAdminAtClass(class, pdpItem, dialogObj, mfail) \
        _DoAssignChangeAdminAtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignChangeAdminAtParent(class, pdpItem, dialogObj, mfail) \
        _DoAssignChangeAdminAtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define DoAssignChgAdminPost(pdpItem, dialogObj, mfail) \
        _DoAssignChgAdminPostAtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignChgAdminPostAtClass(class, pdpItem, dialogObj, mfail) \
        _DoAssignChgAdminPostAtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignChgAdminPostAtParent(class, pdpItem, dialogObj, mfail) \
        _DoAssignChgAdminPostAtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define DoAssignChgAdminPre(pdpItem, dialogObj, mfail) \
        _DoAssignChgAdminPreAtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignChgAdminPreAtClass(class, pdpItem, dialogObj, mfail) \
        _DoAssignChgAdminPreAtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignChgAdminPreAtParent(class, pdpItem, dialogObj, mfail) \
        _DoAssignChgAdminPreAtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define DoAssignOriginator(pdpItem, dialogObj, mfail) \
        _DoAssignOriginatorAtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignOriginatorAtClass(class, pdpItem, dialogObj, mfail) \
        _DoAssignOriginatorAtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignOriginatorAtParent(class, pdpItem, dialogObj, mfail) \
        _DoAssignOriginatorAtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define DoAssignOriginatorPost(pdpItem, dialogObj, mfail) \
        _DoAssignOriginatorPostAtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignOriginatorPostAtClass(class, pdpItem, dialogObj, mfail) \
        _DoAssignOriginatorPostAtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignOriginatorPostAtParent(class, pdpItem, dialogObj, mfail) \
        _DoAssignOriginatorPostAtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define DoAssignOriginatorPre(pdpItem, dialogObj, mfail) \
        _DoAssignOriginatorPreAtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignOriginatorPreAtClass(class, pdpItem, dialogObj, mfail) \
        _DoAssignOriginatorPreAtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignOriginatorPreAtParent(class, pdpItem, dialogObj, mfail) \
        _DoAssignOriginatorPreAtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define DoAssignRevBoard(pdpItem, dialogObj, mfail) \
        _DoAssignRevBoardAtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignRevBoardAtClass(class, pdpItem, dialogObj, mfail) \
        _DoAssignRevBoardAtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignRevBoardAtParent(class, pdpItem, dialogObj, mfail) \
        _DoAssignRevBoardAtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define DoAssignRevBoardPost(pdpItem, dialogObj, mfail) \
        _DoAssignRevBoardPostAtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignRevBoardPostAtClass(class, pdpItem, dialogObj, mfail) \
        _DoAssignRevBoardPostAtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignRevBoardPostAtParent(class, pdpItem, dialogObj, mfail) \
        _DoAssignRevBoardPostAtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define DoAssignRevBoardPre(pdpItem, dialogObj, mfail) \
        _DoAssignRevBoardPreAtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignRevBoardPreAtClass(class, pdpItem, dialogObj, mfail) \
        _DoAssignRevBoardPreAtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define DoAssignRevBoardPreAtParent(class, pdpItem, dialogObj, mfail) \
        _DoAssignRevBoardPreAtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define DoCdiFailCleanup(pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoCdiFailCleanupAtClass(NULL, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoCdiFailCleanupAtClass(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoCdiFailCleanupAtClass(class, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoCdiFailCleanupAtParent(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoCdiFailCleanupAtClass(class, TRUE, pdpItem, dialogObj, extraStr, extraObj, mfail)

#define DoChangeDispo(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeDispoAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoChangeDispoAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeDispoAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoChangeDispoAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeDispoAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define DoChangeDispoItemRels(thisObj, dialogObj, mfail) \
        _DoChangeDispoItemRelsAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoChangeDispoItemRelsAtClass(class, thisObj, dialogObj, mfail) \
        _DoChangeDispoItemRelsAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoChangeDispoItemRelsAtParent(class, thisObj, dialogObj, mfail) \
        _DoChangeDispoItemRelsAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoChangeDispoPost(pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeDispoPostAtClass(NULL, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoChangeDispoPostAtClass(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeDispoPostAtClass(class, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoChangeDispoPostAtParent(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeDispoPostAtClass(class, TRUE, pdpItem, dialogObj, extraStr, extraObj, mfail)

#define DoChangeDispoPostInt(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeDispoPostIntAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoChangeDispoPostIntAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeDispoPostIntAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoChangeDispoPostIntAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeDispoPostIntAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define DoChangeDispoPre(pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeDispoPreAtClass(NULL, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoChangeDispoPreAtClass(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeDispoPreAtClass(class, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoChangeDispoPreAtParent(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeDispoPreAtClass(class, TRUE, pdpItem, dialogObj, extraStr, extraObj, mfail)

#define DoChangeStatus(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeStatusAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoChangeStatusAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeStatusAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoChangeStatusAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeStatusAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define DoChangeStatus2(wbsItem, wbsStatus, mfail) \
        _DoChangeStatus2AtClass(NULL, FALSE, wbsItem, wbsStatus, mfail)
#define DoChangeStatus2AtClass(class, wbsItem, wbsStatus, mfail) \
        _DoChangeStatus2AtClass(class, FALSE, wbsItem, wbsStatus, mfail)
#define DoChangeStatus2AtParent(class, wbsItem, wbsStatus, mfail) \
        _DoChangeStatus2AtClass(class, TRUE, wbsItem, wbsStatus, mfail)

#define DoChangeStatusItemRels(thisObj, dialogObj, mfail) \
        _DoChangeStatusItemRelsAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoChangeStatusItemRelsAtClass(class, thisObj, dialogObj, mfail) \
        _DoChangeStatusItemRelsAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoChangeStatusItemRelsAtParent(class, thisObj, dialogObj, mfail) \
        _DoChangeStatusItemRelsAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoChangeStatusPost(pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeStatusPostAtClass(NULL, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoChangeStatusPostAtClass(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeStatusPostAtClass(class, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoChangeStatusPostAtParent(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeStatusPostAtClass(class, TRUE, pdpItem, dialogObj, extraStr, extraObj, mfail)

#define DoChangeStatusPostInt(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeStatusPostIntAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoChangeStatusPostIntAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeStatusPostIntAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoChangeStatusPostIntAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeStatusPostIntAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define DoChangeStatusPre(pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeStatusPreAtClass(NULL, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoChangeStatusPreAtClass(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeStatusPreAtClass(class, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoChangeStatusPreAtParent(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoChangeStatusPreAtClass(class, TRUE, pdpItem, dialogObj, extraStr, extraObj, mfail)

#define DoChgTechDisp(thisObj, dialogObj, mfail) \
        _DoChgTechDispAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoChgTechDispAtClass(class, thisObj, dialogObj, mfail) \
        _DoChgTechDispAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoChgTechDispAtParent(class, thisObj, dialogObj, mfail) \
        _DoChgTechDispAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoChgTechDispItemRels(thisObj, dialogObj, mfail) \
        _DoChgTechDispItemRelsAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoChgTechDispItemRelsAtClass(class, thisObj, dialogObj, mfail) \
        _DoChgTechDispItemRelsAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoChgTechDispItemRelsAtParent(class, thisObj, dialogObj, mfail) \
        _DoChgTechDispItemRelsAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoChgTechDispPost(pdpItem, dialogObj, mfail) \
        _DoChgTechDispPostAtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define DoChgTechDispPostAtClass(class, pdpItem, dialogObj, mfail) \
        _DoChgTechDispPostAtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define DoChgTechDispPostAtParent(class, pdpItem, dialogObj, mfail) \
        _DoChgTechDispPostAtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define DoChgTechDispPostInt(thisObj, dialogObj, mfail) \
        _DoChgTechDispPostIntAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoChgTechDispPostIntAtClass(class, thisObj, dialogObj, mfail) \
        _DoChgTechDispPostIntAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoChgTechDispPostIntAtParent(class, thisObj, dialogObj, mfail) \
        _DoChgTechDispPostIntAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoChgTechDispPre(pdpItem, dialogObj, mfail) \
        _DoChgTechDispPreAtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define DoChgTechDispPreAtClass(class, pdpItem, dialogObj, mfail) \
        _DoChgTechDispPreAtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define DoChgTechDispPreAtParent(class, pdpItem, dialogObj, mfail) \
        _DoChgTechDispPreAtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define DoClaFailCleanup(griItem, dialogObj, mfail) \
        _DoClaFailCleanupAtClass(NULL, FALSE, griItem, dialogObj, mfail)
#define DoClaFailCleanupAtClass(class, griItem, dialogObj, mfail) \
        _DoClaFailCleanupAtClass(class, FALSE, griItem, dialogObj, mfail)
#define DoClaFailCleanupAtParent(class, griItem, dialogObj, mfail) \
        _DoClaFailCleanupAtClass(class, TRUE, griItem, dialogObj, mfail)

#define DoClassifyChg(griItem, dialogObj, mfail) \
        _DoClassifyChgAtClass(NULL, FALSE, griItem, dialogObj, mfail)
#define DoClassifyChgAtClass(class, griItem, dialogObj, mfail) \
        _DoClassifyChgAtClass(class, FALSE, griItem, dialogObj, mfail)
#define DoClassifyChgAtParent(class, griItem, dialogObj, mfail) \
        _DoClassifyChgAtClass(class, TRUE, griItem, dialogObj, mfail)

#define DoClassifyChgItemRels(griItem, dialogObj, mfail) \
        _DoClassifyChgItemRelsAtClass(NULL, FALSE, griItem, dialogObj, mfail)
#define DoClassifyChgItemRelsAtClass(class, griItem, dialogObj, mfail) \
        _DoClassifyChgItemRelsAtClass(class, FALSE, griItem, dialogObj, mfail)
#define DoClassifyChgItemRelsAtParent(class, griItem, dialogObj, mfail) \
        _DoClassifyChgItemRelsAtClass(class, TRUE, griItem, dialogObj, mfail)

#define DoClassifyChgPost(griItem, dialogObj, mfail) \
        _DoClassifyChgPostAtClass(NULL, FALSE, griItem, dialogObj, mfail)
#define DoClassifyChgPostAtClass(class, griItem, dialogObj, mfail) \
        _DoClassifyChgPostAtClass(class, FALSE, griItem, dialogObj, mfail)
#define DoClassifyChgPostAtParent(class, griItem, dialogObj, mfail) \
        _DoClassifyChgPostAtClass(class, TRUE, griItem, dialogObj, mfail)

#define DoClassifyChgPostInt(griItem, dialogObj, mfail) \
        _DoClassifyChgPostIntAtClass(NULL, FALSE, griItem, dialogObj, mfail)
#define DoClassifyChgPostIntAtClass(class, griItem, dialogObj, mfail) \
        _DoClassifyChgPostIntAtClass(class, FALSE, griItem, dialogObj, mfail)
#define DoClassifyChgPostIntAtParent(class, griItem, dialogObj, mfail) \
        _DoClassifyChgPostIntAtClass(class, TRUE, griItem, dialogObj, mfail)

#define DoClassifyChgPre(griItem, dialogObj, mfail) \
        _DoClassifyChgPreAtClass(NULL, FALSE, griItem, dialogObj, mfail)
#define DoClassifyChgPreAtClass(class, griItem, dialogObj, mfail) \
        _DoClassifyChgPreAtClass(class, FALSE, griItem, dialogObj, mfail)
#define DoClassifyChgPreAtParent(class, griItem, dialogObj, mfail) \
        _DoClassifyChgPreAtClass(class, TRUE, griItem, dialogObj, mfail)

#define DoClassifyChgPreInt(griItem, dialogObj, mfail) \
        _DoClassifyChgPreIntAtClass(NULL, FALSE, griItem, dialogObj, mfail)
#define DoClassifyChgPreIntAtClass(class, griItem, dialogObj, mfail) \
        _DoClassifyChgPreIntAtClass(class, FALSE, griItem, dialogObj, mfail)
#define DoClassifyChgPreIntAtParent(class, griItem, dialogObj, mfail) \
        _DoClassifyChgPreIntAtClass(class, TRUE, griItem, dialogObj, mfail)

#define DoClosureFailCleanup(pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoClosureFailCleanupAtClass(NULL, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoClosureFailCleanupAtClass(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoClosureFailCleanupAtClass(class, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoClosureFailCleanupAtParent(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoClosureFailCleanupAtClass(class, TRUE, pdpItem, dialogObj, extraStr, extraObj, mfail)

#define DoClosurePostForCancel(thisObj, dialogObj, mfail) \
        _DoClosurePostForCancelAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoClosurePostForCancelAtClass(class, thisObj, dialogObj, mfail) \
        _DoClosurePostForCancelAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoClosurePostForCancelAtParent(class, thisObj, dialogObj, mfail) \
        _DoClosurePostForCancelAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoClosurePostForClose(thisObj, dialogObj, mfail) \
        _DoClosurePostForCloseAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoClosurePostForCloseAtClass(class, thisObj, dialogObj, mfail) \
        _DoClosurePostForCloseAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoClosurePostForCloseAtParent(class, thisObj, dialogObj, mfail) \
        _DoClosurePostForCloseAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoClosurePostForOpen(thisObj, dialogObj, mfail) \
        _DoClosurePostForOpenAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoClosurePostForOpenAtClass(class, thisObj, dialogObj, mfail) \
        _DoClosurePostForOpenAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoClosurePostForOpenAtParent(class, thisObj, dialogObj, mfail) \
        _DoClosurePostForOpenAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoClosurePostForSusp(thisObj, dialogObj, mfail) \
        _DoClosurePostForSuspAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoClosurePostForSuspAtClass(class, thisObj, dialogObj, mfail) \
        _DoClosurePostForSuspAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoClosurePostForSuspAtParent(class, thisObj, dialogObj, mfail) \
        _DoClosurePostForSuspAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoCsuFailCleanup(pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoCsuFailCleanupAtClass(NULL, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoCsuFailCleanupAtClass(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoCsuFailCleanupAtClass(class, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoCsuFailCleanupAtParent(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoCsuFailCleanupAtClass(class, TRUE, pdpItem, dialogObj, extraStr, extraObj, mfail)

#define DoCtdFailCleanup(thisObj, dialogObj, mfail) \
        _DoCtdFailCleanupAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoCtdFailCleanupAtClass(class, thisObj, dialogObj, mfail) \
        _DoCtdFailCleanupAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoCtdFailCleanupAtParent(class, thisObj, dialogObj, mfail) \
        _DoCtdFailCleanupAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoDeleteAllRevs(ItemMstrObj, mfail) \
        _DoDeleteAllRevsAtClass(NULL, FALSE, ItemMstrObj, mfail)
#define DoDeleteAllRevsAtClass(class, ItemMstrObj, mfail) \
        _DoDeleteAllRevsAtClass(class, FALSE, ItemMstrObj, mfail)
#define DoDeleteAllRevsAtParent(class, ItemMstrObj, mfail) \
        _DoDeleteAllRevsAtClass(class, TRUE, ItemMstrObj, mfail)

#define DoOriginatrFailCleanup(pdpItem, dialogObj, mfail) \
        _DoOriginatrFailCleanupAtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define DoOriginatrFailCleanupAtClass(class, pdpItem, dialogObj, mfail) \
        _DoOriginatrFailCleanupAtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define DoOriginatrFailCleanupAtParent(class, pdpItem, dialogObj, mfail) \
        _DoOriginatrFailCleanupAtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define DoPdpClosureItemRels(thisObj, dialogObj, mfail) \
        _DoPdpClosureItemRelsAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoPdpClosureItemRelsAtClass(class, thisObj, dialogObj, mfail) \
        _DoPdpClosureItemRelsAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoPdpClosureItemRelsAtParent(class, thisObj, dialogObj, mfail) \
        _DoPdpClosureItemRelsAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoPdpClosurePost(pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoPdpClosurePostAtClass(NULL, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoPdpClosurePostAtClass(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoPdpClosurePostAtClass(class, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoPdpClosurePostAtParent(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoPdpClosurePostAtClass(class, TRUE, pdpItem, dialogObj, extraStr, extraObj, mfail)

#define DoPdpClosurePostInt(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoPdpClosurePostIntAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoPdpClosurePostIntAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoPdpClosurePostIntAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoPdpClosurePostIntAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoPdpClosurePostIntAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define DoPdpClosurePre(pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoPdpClosurePreAtClass(NULL, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoPdpClosurePreAtClass(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoPdpClosurePreAtClass(class, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoPdpClosurePreAtParent(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoPdpClosurePreAtClass(class, TRUE, pdpItem, dialogObj, extraStr, extraObj, mfail)

#define DoPdpClosurePreInt(pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoPdpClosurePreIntAtClass(NULL, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoPdpClosurePreIntAtClass(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoPdpClosurePreIntAtClass(class, FALSE, pdpItem, dialogObj, extraStr, extraObj, mfail)
#define DoPdpClosurePreIntAtParent(class, pdpItem, dialogObj, extraStr, extraObj, mfail) \
        _DoPdpClosurePreIntAtClass(class, TRUE, pdpItem, dialogObj, extraStr, extraObj, mfail)

#define DoPdpClsrOnAllChildren(thisObj, dialogObj, mfail) \
        _DoPdpClsrOnAllChildrenAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoPdpClsrOnAllChildrenAtClass(class, thisObj, dialogObj, mfail) \
        _DoPdpClsrOnAllChildrenAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoPdpClsrOnAllChildrenAtParent(class, thisObj, dialogObj, mfail) \
        _DoPdpClsrOnAllChildrenAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoPdpClsrOnAllImptdIts(thisObj, dialogObj, mfail) \
        _DoPdpClsrOnAllImptdItsAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define DoPdpClsrOnAllImptdItsAtClass(class, thisObj, dialogObj, mfail) \
        _DoPdpClsrOnAllImptdItsAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define DoPdpClsrOnAllImptdItsAtParent(class, thisObj, dialogObj, mfail) \
        _DoPdpClsrOnAllImptdItsAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define DoPrcForAPARBslRpt(itemClass, partsToReport, objectsForReport, objectsForInflate, mfail) \
        _DoPrcForAPARBslRpt(itemClass, FALSE, itemClass, partsToReport, objectsForReport, objectsForInflate, mfail)
#define DoPrcForAPARBslRptAtParent(_class, itemClass, partsToReport, objectsForReport, objectsForInflate, mfail) \
        _DoPrcForAPARBslRpt(_class, TRUE, itemClass, partsToReport, objectsForReport, objectsForInflate, mfail)

#define DoPrcForChgImpMtxRpt(thisClassName, chgsObjsToProcess, objectsForReport, objectsForInflate, mfail) \
        _DoPrcForChgImpMtxRpt(thisClassName, FALSE, thisClassName, chgsObjsToProcess, objectsForReport, objectsForInflate, mfail)
#define DoPrcForChgImpMtxRptAtParent(_class, thisClassName, chgsObjsToProcess, objectsForReport, objectsForInflate, mfail) \
        _DoPrcForChgImpMtxRpt(_class, TRUE, thisClassName, chgsObjsToProcess, objectsForReport, objectsForInflate, mfail)

#define DoProductPlanClosure(thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoProductPlanClosureAtClass(NULL, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoProductPlanClosureAtClass(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoProductPlanClosureAtClass(class, FALSE, thisObj, dialogObj, extraStr, extraObj, mfail)
#define DoProductPlanClosureAtParent(class, thisObj, dialogObj, extraStr, extraObj, mfail) \
        _DoProductPlanClosureAtClass(class, TRUE, thisObj, dialogObj, extraStr, extraObj, mfail)

#define DoRevBrdFailCleanup(pdpItem, dialogObj, mfail) \
        _DoRevBrdFailCleanupAtClass(NULL, FALSE, pdpItem, dialogObj, mfail)
#define DoRevBrdFailCleanupAtClass(class, pdpItem, dialogObj, mfail) \
        _DoRevBrdFailCleanupAtClass(class, FALSE, pdpItem, dialogObj, mfail)
#define DoRevBrdFailCleanupAtParent(class, pdpItem, dialogObj, mfail) \
        _DoRevBrdFailCleanupAtClass(class, TRUE, pdpItem, dialogObj, mfail)

#define DoesRelClassPrcForCdi(className, answer, mfail) \
        _DoesRelClassPrcForCdi(className, FALSE, className, answer, mfail)
#define DoesRelClassPrcForCdiAtParent(_class, className, answer, mfail) \
        _DoesRelClassPrcForCdi(_class, TRUE, className, answer, mfail)

#define DoesRelClassPrcForCla(className, answer, mfail) \
        _DoesRelClassPrcForCla(className, FALSE, className, answer, mfail)
#define DoesRelClassPrcForClaAtParent(_class, className, answer, mfail) \
        _DoesRelClassPrcForCla(_class, TRUE, className, answer, mfail)

#define DoesRelClassPrcForCpp(className, answer, mfail) \
        _DoesRelClassPrcForCpp(className, FALSE, className, answer, mfail)
#define DoesRelClassPrcForCppAtParent(_class, className, answer, mfail) \
        _DoesRelClassPrcForCpp(_class, TRUE, className, answer, mfail)

#define DoesRelClassPrcForCsu(className, answer, mfail) \
        _DoesRelClassPrcForCsu(className, FALSE, className, answer, mfail)
#define DoesRelClassPrcForCsuAtParent(_class, className, answer, mfail) \
        _DoesRelClassPrcForCsu(_class, TRUE, className, answer, mfail)

#define DoesRelClassPrcForCtd(className, answer, mfail) \
        _DoesRelClassPrcForCtd(className, FALSE, className, answer, mfail)
#define DoesRelClassPrcForCtdAtParent(_class, className, answer, mfail) \
        _DoesRelClassPrcForCtd(_class, TRUE, className, answer, mfail)

#define DoesRelClassValForCdi(className, answer, mfail) \
        _DoesRelClassValForCdi(className, FALSE, className, answer, mfail)
#define DoesRelClassValForCdiAtParent(_class, className, answer, mfail) \
        _DoesRelClassValForCdi(_class, TRUE, className, answer, mfail)

#define DoesRelClassValForCla(className, answer, mfail) \
        _DoesRelClassValForCla(className, FALSE, className, answer, mfail)
#define DoesRelClassValForClaAtParent(_class, className, answer, mfail) \
        _DoesRelClassValForCla(_class, TRUE, className, answer, mfail)

#define DoesRelClassValForCpp(className, answer, mfail) \
        _DoesRelClassValForCpp(className, FALSE, className, answer, mfail)
#define DoesRelClassValForCppAtParent(_class, className, answer, mfail) \
        _DoesRelClassValForCpp(_class, TRUE, className, answer, mfail)

#define DoesRelClassValForCsu(className, answer, mfail) \
        _DoesRelClassValForCsu(className, FALSE, className, answer, mfail)
#define DoesRelClassValForCsuAtParent(_class, className, answer, mfail) \
        _DoesRelClassValForCsu(_class, TRUE, className, answer, mfail)

#define DoesRelClassValForCtd(className, answer, mfail) \
        _DoesRelClassValForCtd(className, FALSE, className, answer, mfail)
#define DoesRelClassValForCtdAtParent(_class, className, answer, mfail) \
        _DoesRelClassValForCtd(_class, TRUE, className, answer, mfail)

#define ExpRelMultiLevWbsItem(className, relationship, maxExpandLevel, itemObjSet, qryDef, genContextObj, recurList, resultObjSet, mfail) \
        _ExpRelMultiLevWbsItem(className, FALSE, className, relationship, maxExpandLevel, itemObjSet, qryDef, genContextObj, recurList, resultObjSet, mfail)
#define ExpRelMultiLevWbsItemAtParent(_class, className, relationship, maxExpandLevel, itemObjSet, qryDef, genContextObj, recurList, resultObjSet, mfail) \
        _ExpRelMultiLevWbsItem(_class, TRUE, className, relationship, maxExpandLevel, itemObjSet, qryDef, genContextObj, recurList, resultObjSet, mfail)

#define ExpSetForIsAffBy(className, itemObjSet, relationship, qryDef, genContextObj, scope, otherSideObjSet, relObjSet, mfail) \
        _ExpSetForIsAffBy(className, FALSE, className, itemObjSet, relationship, qryDef, genContextObj, scope, otherSideObjSet, relObjSet, mfail)
#define ExpSetForIsAffByAtParent(_class, className, itemObjSet, relationship, qryDef, genContextObj, scope, otherSideObjSet, relObjSet, mfail) \
        _ExpSetForIsAffBy(_class, TRUE, className, itemObjSet, relationship, qryDef, genContextObj, scope, otherSideObjSet, relObjSet, mfail)

#define ExpandWbsMultiLev(thisObj, relationship, otherSideObjSet, mfail) \
        _ExpandWbsMultiLevAtClass(NULL, FALSE, thisObj, relationship, otherSideObjSet, mfail)
#define ExpandWbsMultiLevAtClass(class, thisObj, relationship, otherSideObjSet, mfail) \
        _ExpandWbsMultiLevAtClass(class, FALSE, thisObj, relationship, otherSideObjSet, mfail)
#define ExpandWbsMultiLevAtParent(class, thisObj, relationship, otherSideObjSet, mfail) \
        _ExpandWbsMultiLevAtClass(class, TRUE, thisObj, relationship, otherSideObjSet, mfail)

#define ExpandWbsMultiLevInt(thisObj, relationship, genContextObj, otherSideObjSet, mfail) \
        _ExpandWbsMultiLevIntAtClass(NULL, FALSE, thisObj, relationship, genContextObj, otherSideObjSet, mfail)
#define ExpandWbsMultiLevIntAtClass(class, thisObj, relationship, genContextObj, otherSideObjSet, mfail) \
        _ExpandWbsMultiLevIntAtClass(class, FALSE, thisObj, relationship, genContextObj, otherSideObjSet, mfail)
#define ExpandWbsMultiLevIntAtParent(class, thisObj, relationship, genContextObj, otherSideObjSet, mfail) \
        _ExpandWbsMultiLevIntAtClass(class, TRUE, thisObj, relationship, genContextObj, otherSideObjSet, mfail)

#define FreezePrpEff(incPntObj, mfail) \
        _FreezePrpEffAtClass(NULL, FALSE, incPntObj, mfail)
#define FreezePrpEffAtClass(class, incPntObj, mfail) \
        _FreezePrpEffAtClass(class, FALSE, incPntObj, mfail)
#define FreezePrpEffAtParent(class, incPntObj, mfail) \
        _FreezePrpEffAtClass(class, TRUE, incPntObj, mfail)

#define FreezePrpEffForPdpObj(thisObj, mfail) \
        _FreezePrpEffForPdpObjAtClass(NULL, FALSE, thisObj, mfail)
#define FreezePrpEffForPdpObjAtClass(class, thisObj, mfail) \
        _FreezePrpEffForPdpObjAtClass(class, FALSE, thisObj, mfail)
#define FreezePrpEffForPdpObjAtParent(class, thisObj, mfail) \
        _FreezePrpEffForPdpObjAtClass(class, TRUE, thisObj, mfail)

#define FreezePrpEffForPrdPln(obj, procHist, msgProc, exitState, advComments, mfail) \
        _FreezePrpEffForPrdPlnAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define FreezePrpEffForPrdPlnAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _FreezePrpEffForPrdPlnAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define FreezePrpEffForPrdPlnAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _FreezePrpEffForPrdPlnAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define GenChgQryForSumRptXML(className, selectedItems, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenChgQryForSumRptXML(className, FALSE, className, selectedItems, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GenChgQryForSumRptXMLAtParent(_class, className, selectedItems, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GenChgQryForSumRptXML(_class, TRUE, className, selectedItems, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define GenRelatedItemsRpt(thisObj, relatedObjs, report, mfail) \
        _GenRelatedItemsRptAtClass(NULL, FALSE, thisObj, relatedObjs, report, mfail)
#define GenRelatedItemsRptAtClass(class, thisObj, relatedObjs, report, mfail) \
        _GenRelatedItemsRptAtClass(class, FALSE, thisObj, relatedObjs, report, mfail)
#define GenRelatedItemsRptAtParent(class, thisObj, relatedObjs, report, mfail) \
        _GenRelatedItemsRptAtClass(class, TRUE, thisObj, relatedObjs, report, mfail)

#define GenerateImpactsRptXML(thisObj, lineSeperator, taskObject, argsObj, resultXMLObj, needTrans, mfail) \
        _GenerateImpactsRptXMLAtClass(NULL, FALSE, thisObj, lineSeperator, taskObject, argsObj, resultXMLObj, needTrans, mfail)
#define GenerateImpactsRptXMLAtClass(class, thisObj, lineSeperator, taskObject, argsObj, resultXMLObj, needTrans, mfail) \
        _GenerateImpactsRptXMLAtClass(class, FALSE, thisObj, lineSeperator, taskObject, argsObj, resultXMLObj, needTrans, mfail)
#define GenerateImpactsRptXMLAtParent(class, thisObj, lineSeperator, taskObject, argsObj, resultXMLObj, needTrans, mfail) \
        _GenerateImpactsRptXMLAtClass(class, TRUE, thisObj, lineSeperator, taskObject, argsObj, resultXMLObj, needTrans, mfail)

#define GenerateReportSCT(thisObj, report, reqAttrList, mfail) \
        _GenerateReportSCTAtClass(NULL, FALSE, thisObj, report, reqAttrList, mfail)
#define GenerateReportSCTAtClass(class, thisObj, report, reqAttrList, mfail) \
        _GenerateReportSCTAtClass(class, FALSE, thisObj, report, reqAttrList, mfail)
#define GenerateReportSCTAtParent(class, thisObj, report, reqAttrList, mfail) \
        _GenerateReportSCTAtClass(class, TRUE, thisObj, report, reqAttrList, mfail)

#define GenerateSCTReportCol(thisObj, report, reqAttrList, mfail) \
        _GenerateSCTReportColAtClass(NULL, FALSE, thisObj, report, reqAttrList, mfail)
#define GenerateSCTReportColAtClass(class, thisObj, report, reqAttrList, mfail) \
        _GenerateSCTReportColAtClass(class, FALSE, thisObj, report, reqAttrList, mfail)
#define GenerateSCTReportColAtParent(class, thisObj, report, reqAttrList, mfail) \
        _GenerateSCTReportColAtClass(class, TRUE, thisObj, report, reqAttrList, mfail)

#define GetAdminGrp(className, adminGrp, mfail) \
        _GetAdminGrp(className, FALSE, className, adminGrp, mfail)
#define GetAdminGrpAtParent(_class, className, adminGrp, mfail) \
        _GetAdminGrp(_class, TRUE, className, adminGrp, mfail)

#define GetAffDocForSCTReport(thisObj, report, mfail) \
        _GetAffDocForSCTReportAtClass(NULL, FALSE, thisObj, report, mfail)
#define GetAffDocForSCTReportAtClass(class, thisObj, report, mfail) \
        _GetAffDocForSCTReportAtClass(class, FALSE, thisObj, report, mfail)
#define GetAffDocForSCTReportAtParent(class, thisObj, report, mfail) \
        _GetAffDocForSCTReportAtClass(class, TRUE, thisObj, report, mfail)

#define GetAffPrtMForSCTReport(thisObj, report, mfail) \
        _GetAffPrtMForSCTReportAtClass(NULL, FALSE, thisObj, report, mfail)
#define GetAffPrtMForSCTReportAtClass(class, thisObj, report, mfail) \
        _GetAffPrtMForSCTReportAtClass(class, FALSE, thisObj, report, mfail)
#define GetAffPrtMForSCTReportAtParent(class, thisObj, report, mfail) \
        _GetAffPrtMForSCTReportAtClass(class, TRUE, thisObj, report, mfail)

#define GetAllRevisions(busItem, busItemRevisions, mfail) \
        _GetAllRevisionsAtClass(NULL, FALSE, busItem, busItemRevisions, mfail)
#define GetAllRevisionsAtClass(class, busItem, busItemRevisions, mfail) \
        _GetAllRevisionsAtClass(class, FALSE, busItem, busItemRevisions, mfail)
#define GetAllRevisionsAtParent(class, busItem, busItemRevisions, mfail) \
        _GetAllRevisionsAtClass(class, TRUE, busItem, busItemRevisions, mfail)

#define GetAllTasksExt(thisObj, childPdpObjSet, mfail) \
        _GetAllTasksExtAtClass(NULL, FALSE, thisObj, childPdpObjSet, mfail)
#define GetAllTasksExtAtClass(class, thisObj, childPdpObjSet, mfail) \
        _GetAllTasksExtAtClass(class, FALSE, thisObj, childPdpObjSet, mfail)
#define GetAllTasksExtAtParent(class, thisObj, childPdpObjSet, mfail) \
        _GetAllTasksExtAtClass(class, TRUE, thisObj, childPdpObjSet, mfail)

#define GetAllValidAdmins(pdpItem, values, mfail) \
        _GetAllValidAdminsAtClass(NULL, FALSE, pdpItem, values, mfail)
#define GetAllValidAdminsAtClass(class, pdpItem, values, mfail) \
        _GetAllValidAdminsAtClass(class, FALSE, pdpItem, values, mfail)
#define GetAllValidAdminsAtParent(class, pdpItem, values, mfail) \
        _GetAllValidAdminsAtClass(class, TRUE, pdpItem, values, mfail)

#define GetAllValidAnalysts(pdpItem, values, mfail) \
        _GetAllValidAnalystsAtClass(NULL, FALSE, pdpItem, values, mfail)
#define GetAllValidAnalystsAtClass(class, pdpItem, values, mfail) \
        _GetAllValidAnalystsAtClass(class, FALSE, pdpItem, values, mfail)
#define GetAllValidAnalystsAtParent(class, pdpItem, values, mfail) \
        _GetAllValidAnalystsAtClass(class, TRUE, pdpItem, values, mfail)

#define GetAllValidClassify(griItem, values, mfail) \
        _GetAllValidClassifyAtClass(NULL, FALSE, griItem, values, mfail)
#define GetAllValidClassifyAtClass(class, griItem, values, mfail) \
        _GetAllValidClassifyAtClass(class, FALSE, griItem, values, mfail)
#define GetAllValidClassifyAtParent(class, griItem, values, mfail) \
        _GetAllValidClassifyAtClass(class, TRUE, griItem, values, mfail)

#define GetAllValidDispo(pdpItem, values, mfail) \
        _GetAllValidDispoAtClass(NULL, FALSE, pdpItem, values, mfail)
#define GetAllValidDispoAtClass(class, pdpItem, values, mfail) \
        _GetAllValidDispoAtClass(class, FALSE, pdpItem, values, mfail)
#define GetAllValidDispoAtParent(class, pdpItem, values, mfail) \
        _GetAllValidDispoAtClass(class, TRUE, pdpItem, values, mfail)

#define GetAllValidOriginators(pdpItem, values, mfail) \
        _GetAllValidOriginatorsAtClass(NULL, FALSE, pdpItem, values, mfail)
#define GetAllValidOriginatorsAtClass(class, pdpItem, values, mfail) \
        _GetAllValidOriginatorsAtClass(class, FALSE, pdpItem, values, mfail)
#define GetAllValidOriginatorsAtParent(class, pdpItem, values, mfail) \
        _GetAllValidOriginatorsAtClass(class, TRUE, pdpItem, values, mfail)

#define GetAllValidPlanStatus(griItem, values, mfail) \
        _GetAllValidPlanStatusAtClass(NULL, FALSE, griItem, values, mfail)
#define GetAllValidPlanStatusAtClass(class, griItem, values, mfail) \
        _GetAllValidPlanStatusAtClass(class, FALSE, griItem, values, mfail)
#define GetAllValidPlanStatusAtParent(class, griItem, values, mfail) \
        _GetAllValidPlanStatusAtClass(class, TRUE, griItem, values, mfail)

#define GetAllValidPriorities(griItem, values, mfail) \
        _GetAllValidPrioritiesAtClass(NULL, FALSE, griItem, values, mfail)
#define GetAllValidPrioritiesAtClass(class, griItem, values, mfail) \
        _GetAllValidPrioritiesAtClass(class, FALSE, griItem, values, mfail)
#define GetAllValidPrioritiesAtParent(class, griItem, values, mfail) \
        _GetAllValidPrioritiesAtClass(class, TRUE, griItem, values, mfail)

#define GetAllValidReasons(griItem, values, mfail) \
        _GetAllValidReasonsAtClass(NULL, FALSE, griItem, values, mfail)
#define GetAllValidReasonsAtClass(class, griItem, values, mfail) \
        _GetAllValidReasonsAtClass(class, FALSE, griItem, values, mfail)
#define GetAllValidReasonsAtParent(class, griItem, values, mfail) \
        _GetAllValidReasonsAtClass(class, TRUE, griItem, values, mfail)

#define GetAllValidRevBoardSet(pdpItem, validRevBoardMembers, mfail) \
        _GetAllValidRevBoardSetAtClass(NULL, FALSE, pdpItem, validRevBoardMembers, mfail)
#define GetAllValidRevBoardSetAtClass(class, pdpItem, validRevBoardMembers, mfail) \
        _GetAllValidRevBoardSetAtClass(class, FALSE, pdpItem, validRevBoardMembers, mfail)
#define GetAllValidRevBoardSetAtParent(class, pdpItem, validRevBoardMembers, mfail) \
        _GetAllValidRevBoardSetAtClass(class, TRUE, pdpItem, validRevBoardMembers, mfail)

#define GetAllValidReviewers(pdpItem, values, mfail) \
        _GetAllValidReviewersAtClass(NULL, FALSE, pdpItem, values, mfail)
#define GetAllValidReviewersAtClass(class, pdpItem, values, mfail) \
        _GetAllValidReviewersAtClass(class, FALSE, pdpItem, values, mfail)
#define GetAllValidReviewersAtParent(class, pdpItem, values, mfail) \
        _GetAllValidReviewersAtClass(class, TRUE, pdpItem, values, mfail)

#define GetApprovedDisposition(className, apprvdDisposition, mfail) \
        _GetApprovedDisposition(className, FALSE, className, apprvdDisposition, mfail)
#define GetApprovedDispositionAtParent(_class, className, apprvdDisposition, mfail) \
        _GetApprovedDisposition(_class, TRUE, className, apprvdDisposition, mfail)

#define GetAttSizeForSCTReport(thisObj, reqAttrName, sizeOfAttr, mfail) \
        _GetAttSizeForSCTReportAtClass(NULL, FALSE, thisObj, reqAttrName, sizeOfAttr, mfail)
#define GetAttSizeForSCTReportAtClass(class, thisObj, reqAttrName, sizeOfAttr, mfail) \
        _GetAttSizeForSCTReportAtClass(class, FALSE, thisObj, reqAttrName, sizeOfAttr, mfail)
#define GetAttSizeForSCTReportAtParent(class, thisObj, reqAttrName, sizeOfAttr, mfail) \
        _GetAttSizeForSCTReportAtClass(class, TRUE, thisObj, reqAttrName, sizeOfAttr, mfail)

#define GetBiImpForSCTReport(thisObj, report, mfail) \
        _GetBiImpForSCTReportAtClass(NULL, FALSE, thisObj, report, mfail)
#define GetBiImpForSCTReportAtClass(class, thisObj, report, mfail) \
        _GetBiImpForSCTReportAtClass(class, FALSE, thisObj, report, mfail)
#define GetBiImpForSCTReportAtParent(class, thisObj, report, mfail) \
        _GetBiImpForSCTReportAtClass(class, TRUE, thisObj, report, mfail)

#define GetCAZItemForSCTReport(thisObj, report, mfail) \
        _GetCAZItemForSCTReportAtClass(NULL, FALSE, thisObj, report, mfail)
#define GetCAZItemForSCTReportAtClass(class, thisObj, report, mfail) \
        _GetCAZItemForSCTReportAtClass(class, FALSE, thisObj, report, mfail)
#define GetCAZItemForSCTReportAtParent(class, thisObj, report, mfail) \
        _GetCAZItemForSCTReportAtClass(class, TRUE, thisObj, report, mfail)

#define GetCdiDialogName(pdpItem, dialogName, mfail) \
        _GetCdiDialogNameAtClass(NULL, FALSE, pdpItem, dialogName, mfail)
#define GetCdiDialogNameAtClass(class, pdpItem, dialogName, mfail) \
        _GetCdiDialogNameAtClass(class, FALSE, pdpItem, dialogName, mfail)
#define GetCdiDialogNameAtParent(class, pdpItem, dialogName, mfail) \
        _GetCdiDialogNameAtClass(class, TRUE, pdpItem, dialogName, mfail)

#define GetChangeHistory(busItem, busItemRevisions, mfail) \
        _GetChangeHistoryAtClass(NULL, FALSE, busItem, busItemRevisions, mfail)
#define GetChangeHistoryAtClass(class, busItem, busItemRevisions, mfail) \
        _GetChangeHistoryAtClass(class, FALSE, busItem, busItemRevisions, mfail)
#define GetChangeHistoryAtParent(class, busItem, busItemRevisions, mfail) \
        _GetChangeHistoryAtClass(class, TRUE, busItem, busItemRevisions, mfail)

#define GetChangeHistoryInt(busItem, busItemRevisions, resultOfRelsForBusItem, resultOfChangeItems, mfail) \
        _GetChangeHistoryIntAtClass(NULL, FALSE, busItem, busItemRevisions, resultOfRelsForBusItem, resultOfChangeItems, mfail)
#define GetChangeHistoryIntAtClass(class, busItem, busItemRevisions, resultOfRelsForBusItem, resultOfChangeItems, mfail) \
        _GetChangeHistoryIntAtClass(class, FALSE, busItem, busItemRevisions, resultOfRelsForBusItem, resultOfChangeItems, mfail)
#define GetChangeHistoryIntAtParent(class, busItem, busItemRevisions, resultOfRelsForBusItem, resultOfChangeItems, mfail) \
        _GetChangeHistoryIntAtClass(class, TRUE, busItem, busItemRevisions, resultOfRelsForBusItem, resultOfChangeItems, mfail)

#define GetChangeHistoryXML(busItem, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GetChangeHistoryXMLAtClass(NULL, FALSE, busItem, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GetChangeHistoryXMLAtClass(class, busItem, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GetChangeHistoryXMLAtClass(class, FALSE, busItem, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define GetChangeHistoryXMLAtParent(class, busItem, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _GetChangeHistoryXMLAtClass(class, TRUE, busItem, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define GetChgAdmItems(className, databases, querySet, mfail) \
        _GetChgAdmItems(className, FALSE, className, databases, querySet, mfail)
#define GetChgAdmItemsAtParent(_class, className, databases, querySet, mfail) \
        _GetChgAdmItems(_class, TRUE, className, databases, querySet, mfail)

#define GetChildIncorpUsgCtxt(pdpItem, relObj, childIncObjsSet, mfail) \
        _GetChildIncorpUsgCtxtAtClass(NULL, FALSE, pdpItem, relObj, childIncObjsSet, mfail)
#define GetChildIncorpUsgCtxtAtClass(class, pdpItem, relObj, childIncObjsSet, mfail) \
        _GetChildIncorpUsgCtxtAtClass(class, FALSE, pdpItem, relObj, childIncObjsSet, mfail)
#define GetChildIncorpUsgCtxtAtParent(class, pdpItem, relObj, childIncObjsSet, mfail) \
        _GetChildIncorpUsgCtxtAtClass(class, TRUE, pdpItem, relObj, childIncObjsSet, mfail)

#define GetClaDialogName(griItem, dialogName, mfail) \
        _GetClaDialogNameAtClass(NULL, FALSE, griItem, dialogName, mfail)
#define GetClaDialogNameAtClass(class, griItem, dialogName, mfail) \
        _GetClaDialogNameAtClass(class, FALSE, griItem, dialogName, mfail)
#define GetClaDialogNameAtParent(class, griItem, dialogName, mfail) \
        _GetClaDialogNameAtClass(class, TRUE, griItem, dialogName, mfail)

#define GetCmtdEffForRptSCT(thisObj, report, mfail) \
        _GetCmtdEffForRptSCTAtClass(NULL, FALSE, thisObj, report, mfail)
#define GetCmtdEffForRptSCTAtClass(class, thisObj, report, mfail) \
        _GetCmtdEffForRptSCTAtClass(class, FALSE, thisObj, report, mfail)
#define GetCmtdEffForRptSCTAtParent(class, thisObj, report, mfail) \
        _GetCmtdEffForRptSCTAtClass(class, TRUE, thisObj, report, mfail)

#define GetCmtdEffForRptSCTCol(thisObj, report, mfail) \
        _GetCmtdEffForRptSCTColAtClass(NULL, FALSE, thisObj, report, mfail)
#define GetCmtdEffForRptSCTColAtClass(class, thisObj, report, mfail) \
        _GetCmtdEffForRptSCTColAtClass(class, FALSE, thisObj, report, mfail)
#define GetCmtdEffForRptSCTColAtParent(class, thisObj, report, mfail) \
        _GetCmtdEffForRptSCTColAtClass(class, TRUE, thisObj, report, mfail)

#define GetCmtdEffObj(thisObj, otherSideObj, mfail) \
        _GetCmtdEffObjAtClass(NULL, FALSE, thisObj, otherSideObj, mfail)
#define GetCmtdEffObjAtClass(class, thisObj, otherSideObj, mfail) \
        _GetCmtdEffObjAtClass(class, FALSE, thisObj, otherSideObj, mfail)
#define GetCmtdEffObjAtParent(class, thisObj, otherSideObj, mfail) \
        _GetCmtdEffObjAtClass(class, TRUE, thisObj, otherSideObj, mfail)

#define GetCsuDialogName(pdpItem, dialogName, mfail) \
        _GetCsuDialogNameAtClass(NULL, FALSE, pdpItem, dialogName, mfail)
#define GetCsuDialogNameAtClass(class, pdpItem, dialogName, mfail) \
        _GetCsuDialogNameAtClass(class, FALSE, pdpItem, dialogName, mfail)
#define GetCsuDialogNameAtParent(class, pdpItem, dialogName, mfail) \
        _GetCsuDialogNameAtClass(class, TRUE, pdpItem, dialogName, mfail)

#define GetCtdDialogName(pdpItem, dialogName, mfail) \
        _GetCtdDialogNameAtClass(NULL, FALSE, pdpItem, dialogName, mfail)
#define GetCtdDialogNameAtClass(class, pdpItem, dialogName, mfail) \
        _GetCtdDialogNameAtClass(class, FALSE, pdpItem, dialogName, mfail)
#define GetCtdDialogNameAtParent(class, pdpItem, dialogName, mfail) \
        _GetCtdDialogNameAtClass(class, TRUE, pdpItem, dialogName, mfail)

#define GetCurrentRevBoardSet(pdpItem, currRevBoardMembers, mfail) \
        _GetCurrentRevBoardSetAtClass(NULL, FALSE, pdpItem, currRevBoardMembers, mfail)
#define GetCurrentRevBoardSetAtClass(class, pdpItem, currRevBoardMembers, mfail) \
        _GetCurrentRevBoardSetAtClass(class, FALSE, pdpItem, currRevBoardMembers, mfail)
#define GetCurrentRevBoardSetAtParent(class, pdpItem, currRevBoardMembers, mfail) \
        _GetCurrentRevBoardSetAtClass(class, TRUE, pdpItem, currRevBoardMembers, mfail)

#define GetDefaultAttrSet(className1, className2, classConstant, selectedAttrs, mfail) \
        _GetDefaultAttrSet(className1, FALSE, className1, className2, classConstant, selectedAttrs, mfail)
#define GetDefaultAttrSetAtParent(_class, className1, className2, classConstant, selectedAttrs, mfail) \
        _GetDefaultAttrSet(_class, TRUE, className1, className2, classConstant, selectedAttrs, mfail)

#define GetEffForPrdPlnSet(className, prdplnObjSet, incorpObjSet, mfail) \
        _GetEffForPrdPlnSet(className, FALSE, className, prdplnObjSet, incorpObjSet, mfail)
#define GetEffForPrdPlnSetAtParent(_class, className, prdplnObjSet, incorpObjSet, mfail) \
        _GetEffForPrdPlnSet(_class, TRUE, className, prdplnObjSet, incorpObjSet, mfail)

#define GetHderForSCTReportCol(thisObj, report, reqAttrList, mfail) \
        _GetHderForSCTReportColAtClass(NULL, FALSE, thisObj, report, reqAttrList, mfail)
#define GetHderForSCTReportColAtClass(class, thisObj, report, reqAttrList, mfail) \
        _GetHderForSCTReportColAtClass(class, FALSE, thisObj, report, reqAttrList, mfail)
#define GetHderForSCTReportColAtParent(class, thisObj, report, reqAttrList, mfail) \
        _GetHderForSCTReportColAtClass(class, TRUE, thisObj, report, reqAttrList, mfail)

#define GetImpactingChgItems(busItem, affectedByRelsForBusItem, affectingChangeItems, mfail) \
        _GetImpactingChgItemsAtClass(NULL, FALSE, busItem, affectedByRelsForBusItem, affectingChangeItems, mfail)
#define GetImpactingChgItemsAtClass(class, busItem, affectedByRelsForBusItem, affectingChangeItems, mfail) \
        _GetImpactingChgItemsAtClass(class, FALSE, busItem, affectedByRelsForBusItem, affectingChangeItems, mfail)
#define GetImpactingChgItemsAtParent(class, busItem, affectedByRelsForBusItem, affectingChangeItems, mfail) \
        _GetImpactingChgItemsAtClass(class, TRUE, busItem, affectedByRelsForBusItem, affectingChangeItems, mfail)

#define GetImplementedPdpItems(pdpItem, relObjSet, otherSideObjSet, mfail) \
        _GetImplementedPdpItemsAtClass(NULL, FALSE, pdpItem, relObjSet, otherSideObjSet, mfail)
#define GetImplementedPdpItemsAtClass(class, pdpItem, relObjSet, otherSideObjSet, mfail) \
        _GetImplementedPdpItemsAtClass(class, FALSE, pdpItem, relObjSet, otherSideObjSet, mfail)
#define GetImplementedPdpItemsAtParent(class, pdpItem, relObjSet, otherSideObjSet, mfail) \
        _GetImplementedPdpItemsAtClass(class, TRUE, pdpItem, relObjSet, otherSideObjSet, mfail)

#define GetImplementedPrdPlnMr(pdpItem, relObjSet, otherSideObjSet, mfail) \
        _GetImplementedPrdPlnMrAtClass(NULL, FALSE, pdpItem, relObjSet, otherSideObjSet, mfail)
#define GetImplementedPrdPlnMrAtClass(class, pdpItem, relObjSet, otherSideObjSet, mfail) \
        _GetImplementedPrdPlnMrAtClass(class, FALSE, pdpItem, relObjSet, otherSideObjSet, mfail)
#define GetImplementedPrdPlnMrAtParent(class, pdpItem, relObjSet, otherSideObjSet, mfail) \
        _GetImplementedPrdPlnMrAtClass(class, TRUE, pdpItem, relObjSet, otherSideObjSet, mfail)

#define GetImplementingECN(thisObj, ECNObj, mfail) \
        _GetImplementingECNAtClass(NULL, FALSE, thisObj, ECNObj, mfail)
#define GetImplementingECNAtClass(class, thisObj, ECNObj, mfail) \
        _GetImplementingECNAtClass(class, FALSE, thisObj, ECNObj, mfail)
#define GetImplementingECNAtParent(class, thisObj, ECNObj, mfail) \
        _GetImplementingECNAtClass(class, TRUE, thisObj, ECNObj, mfail)

#define GetImplementingPrdPln(pdpItem, prdPlnMstrObj, relObjSet, otherSideObjSet, mfail) \
        _GetImplementingPrdPlnAtClass(NULL, FALSE, pdpItem, prdPlnMstrObj, relObjSet, otherSideObjSet, mfail)
#define GetImplementingPrdPlnAtClass(class, pdpItem, prdPlnMstrObj, relObjSet, otherSideObjSet, mfail) \
        _GetImplementingPrdPlnAtClass(class, FALSE, pdpItem, prdPlnMstrObj, relObjSet, otherSideObjSet, mfail)
#define GetImplementingPrdPlnAtParent(class, pdpItem, prdPlnMstrObj, relObjSet, otherSideObjSet, mfail) \
        _GetImplementingPrdPlnAtClass(class, TRUE, pdpItem, prdPlnMstrObj, relObjSet, otherSideObjSet, mfail)

#define GetIncorpPntForRevise(prdPlnItem, incPntItem, mfail) \
        _GetIncorpPntForReviseAtClass(NULL, FALSE, prdPlnItem, incPntItem, mfail)
#define GetIncorpPntForReviseAtClass(class, prdPlnItem, incPntItem, mfail) \
        _GetIncorpPntForReviseAtClass(class, FALSE, prdPlnItem, incPntItem, mfail)
#define GetIncorpPntForReviseAtParent(class, prdPlnItem, incPntItem, mfail) \
        _GetIncorpPntForReviseAtClass(class, TRUE, prdPlnItem, incPntItem, mfail)

#define GetIncorpPntUsingCtxt(pdpItem, relObj, incorpRObjSet, incPntObjSet, incorpObj, mfail) \
        _GetIncorpPntUsingCtxtAtClass(NULL, FALSE, pdpItem, relObj, incorpRObjSet, incPntObjSet, incorpObj, mfail)
#define GetIncorpPntUsingCtxtAtClass(class, pdpItem, relObj, incorpRObjSet, incPntObjSet, incorpObj, mfail) \
        _GetIncorpPntUsingCtxtAtClass(class, FALSE, pdpItem, relObj, incorpRObjSet, incPntObjSet, incorpObj, mfail)
#define GetIncorpPntUsingCtxtAtParent(class, pdpItem, relObj, incorpRObjSet, incPntObjSet, incorpObj, mfail) \
        _GetIncorpPntUsingCtxtAtClass(class, TRUE, pdpItem, relObj, incorpRObjSet, incPntObjSet, incorpObj, mfail)

#define GetIncorpRIsForPrdPln(pdpItem, incMstrObj, relObjSet, otherSideObjSet, mfail) \
        _GetIncorpRIsForPrdPlnAtClass(NULL, FALSE, pdpItem, incMstrObj, relObjSet, otherSideObjSet, mfail)
#define GetIncorpRIsForPrdPlnAtClass(class, pdpItem, incMstrObj, relObjSet, otherSideObjSet, mfail) \
        _GetIncorpRIsForPrdPlnAtClass(class, FALSE, pdpItem, incMstrObj, relObjSet, otherSideObjSet, mfail)
#define GetIncorpRIsForPrdPlnAtParent(class, pdpItem, incMstrObj, relObjSet, otherSideObjSet, mfail) \
        _GetIncorpRIsForPrdPlnAtClass(class, TRUE, pdpItem, incMstrObj, relObjSet, otherSideObjSet, mfail)

#define GetIncorporation(thisObj, relObj, incorpObj, mfail) \
        _GetIncorporationAtClass(NULL, FALSE, thisObj, relObj, incorpObj, mfail)
#define GetIncorporationAtClass(class, thisObj, relObj, incorpObj, mfail) \
        _GetIncorporationAtClass(class, FALSE, thisObj, relObj, incorpObj, mfail)
#define GetIncorporationAtParent(class, thisObj, relObj, incorpObj, mfail) \
        _GetIncorporationAtClass(class, TRUE, thisObj, relObj, incorpObj, mfail)

#define GetNamesFromRoleGrp(pdpItem, roleName, roleMembers, numMembers, mfail) \
        _GetNamesFromRoleGrpAtClass(NULL, FALSE, pdpItem, roleName, roleMembers, numMembers, mfail)
#define GetNamesFromRoleGrpAtClass(class, pdpItem, roleName, roleMembers, numMembers, mfail) \
        _GetNamesFromRoleGrpAtClass(class, FALSE, pdpItem, roleName, roleMembers, numMembers, mfail)
#define GetNamesFromRoleGrpAtParent(class, pdpItem, roleName, roleMembers, numMembers, mfail) \
        _GetNamesFromRoleGrpAtClass(class, TRUE, pdpItem, roleName, roleMembers, numMembers, mfail)

#define GetParentIncorpUsgCtxt(thisObj, relObj, parIncObj, mfail) \
        _GetParentIncorpUsgCtxtAtClass(NULL, FALSE, thisObj, relObj, parIncObj, mfail)
#define GetParentIncorpUsgCtxtAtClass(class, thisObj, relObj, parIncObj, mfail) \
        _GetParentIncorpUsgCtxtAtClass(class, FALSE, thisObj, relObj, parIncObj, mfail)
#define GetParentIncorpUsgCtxtAtParent(class, thisObj, relObj, parIncObj, mfail) \
        _GetParentIncorpUsgCtxtAtClass(class, TRUE, thisObj, relObj, parIncObj, mfail)

#define GetPdpClosureDlgName(pdpItem, dialogName, mfail) \
        _GetPdpClosureDlgNameAtClass(NULL, FALSE, pdpItem, dialogName, mfail)
#define GetPdpClosureDlgNameAtClass(class, pdpItem, dialogName, mfail) \
        _GetPdpClosureDlgNameAtClass(class, FALSE, pdpItem, dialogName, mfail)
#define GetPdpClosureDlgNameAtParent(class, pdpItem, dialogName, mfail) \
        _GetPdpClosureDlgNameAtClass(class, TRUE, pdpItem, dialogName, mfail)

#define GetPendingChanges(busItem, affectedByRelsForBusItem, affectingChangeItems, mfail) \
        _GetPendingChangesAtClass(NULL, FALSE, busItem, affectedByRelsForBusItem, affectingChangeItems, mfail)
#define GetPendingChangesAtClass(class, busItem, affectedByRelsForBusItem, affectingChangeItems, mfail) \
        _GetPendingChangesAtClass(class, FALSE, busItem, affectedByRelsForBusItem, affectingChangeItems, mfail)
#define GetPendingChangesAtParent(class, busItem, affectedByRelsForBusItem, affectingChangeItems, mfail) \
        _GetPendingChangesAtClass(class, TRUE, busItem, affectedByRelsForBusItem, affectingChangeItems, mfail)

#define GetPendingChangesInt(busItem, affectedByRelsForBusItem, affectingChangeItems, mfail) \
        _GetPendingChangesIntAtClass(NULL, FALSE, busItem, affectedByRelsForBusItem, affectingChangeItems, mfail)
#define GetPendingChangesIntAtClass(class, busItem, affectedByRelsForBusItem, affectingChangeItems, mfail) \
        _GetPendingChangesIntAtClass(class, FALSE, busItem, affectedByRelsForBusItem, affectingChangeItems, mfail)
#define GetPendingChangesIntAtParent(class, busItem, affectedByRelsForBusItem, affectingChangeItems, mfail) \
        _GetPendingChangesIntAtClass(class, TRUE, busItem, affectedByRelsForBusItem, affectingChangeItems, mfail)

#define GetPlStrcPdpItems(thisObj, otherSideObjSet, mfail) \
        _GetPlStrcPdpItemsAtClass(NULL, FALSE, thisObj, otherSideObjSet, mfail)
#define GetPlStrcPdpItemsAtClass(class, thisObj, otherSideObjSet, mfail) \
        _GetPlStrcPdpItemsAtClass(class, FALSE, thisObj, otherSideObjSet, mfail)
#define GetPlStrcPdpItemsAtParent(class, thisObj, otherSideObjSet, mfail) \
        _GetPlStrcPdpItemsAtClass(class, TRUE, thisObj, otherSideObjSet, mfail)

#define GetPlnItemForSCTReport(thisObj, report, mfail) \
        _GetPlnItemForSCTReportAtClass(NULL, FALSE, thisObj, report, mfail)
#define GetPlnItemForSCTReportAtClass(class, thisObj, report, mfail) \
        _GetPlnItemForSCTReportAtClass(class, FALSE, thisObj, report, mfail)
#define GetPlnItemForSCTReportAtParent(class, thisObj, report, mfail) \
        _GetPlnItemForSCTReportAtClass(class, TRUE, thisObj, report, mfail)

#define GetPrdPlnItType(thisObj, prdPlnItType, mfail) \
        _GetPrdPlnItTypeAtClass(NULL, FALSE, thisObj, prdPlnItType, mfail)
#define GetPrdPlnItTypeAtClass(class, thisObj, prdPlnItType, mfail) \
        _GetPrdPlnItTypeAtClass(class, FALSE, thisObj, prdPlnItType, mfail)
#define GetPrdPlnItTypeAtParent(class, thisObj, prdPlnItType, mfail) \
        _GetPrdPlnItTypeAtClass(class, TRUE, thisObj, prdPlnItType, mfail)

#define GetPrdPlnItTypeCtxt(thisObj, ctxtObj, prdPlnItType, mfail) \
        _GetPrdPlnItTypeCtxtAtClass(NULL, FALSE, thisObj, ctxtObj, prdPlnItType, mfail)
#define GetPrdPlnItTypeCtxtAtClass(class, thisObj, ctxtObj, prdPlnItType, mfail) \
        _GetPrdPlnItTypeCtxtAtClass(class, FALSE, thisObj, ctxtObj, prdPlnItType, mfail)
#define GetPrdPlnItTypeCtxtAtParent(class, thisObj, ctxtObj, prdPlnItType, mfail) \
        _GetPrdPlnItTypeCtxtAtClass(class, TRUE, thisObj, ctxtObj, prdPlnItType, mfail)

#define GetPropEffForRptSCTCol(thisObj, report, mfail) \
        _GetPropEffForRptSCTColAtClass(NULL, FALSE, thisObj, report, mfail)
#define GetPropEffForRptSCTColAtClass(class, thisObj, report, mfail) \
        _GetPropEffForRptSCTColAtClass(class, FALSE, thisObj, report, mfail)
#define GetPropEffForRptSCTColAtParent(class, thisObj, report, mfail) \
        _GetPropEffForRptSCTColAtClass(class, TRUE, thisObj, report, mfail)

#define GetRefForSCTReport(thisObj, report, mfail) \
        _GetRefForSCTReportAtClass(NULL, FALSE, thisObj, report, mfail)
#define GetRefForSCTReportAtClass(class, thisObj, report, mfail) \
        _GetRefForSCTReportAtClass(class, FALSE, thisObj, report, mfail)
#define GetRefForSCTReportAtParent(class, thisObj, report, mfail) \
        _GetRefForSCTReportAtClass(class, TRUE, thisObj, report, mfail)

#define GetRelatedPdpItem(itemObj, relClass, pdpItem, mfail) \
        _GetRelatedPdpItemAtClass(NULL, FALSE, itemObj, relClass, pdpItem, mfail)
#define GetRelatedPdpItemAtClass(class, itemObj, relClass, pdpItem, mfail) \
        _GetRelatedPdpItemAtClass(class, FALSE, itemObj, relClass, pdpItem, mfail)
#define GetRelatedPdpItemAtParent(class, itemObj, relClass, pdpItem, mfail) \
        _GetRelatedPdpItemAtClass(class, TRUE, itemObj, relClass, pdpItem, mfail)

#define GetResultsRelForChange(className, resultsClass, mfail) \
        _GetResultsRelForChange(className, FALSE, className, resultsClass, mfail)
#define GetResultsRelForChangeAtParent(_class, className, resultsClass, mfail) \
        _GetResultsRelForChange(_class, TRUE, className, resultsClass, mfail)

#define GetReviewersGrp(className, reviewersGrp, mfail) \
        _GetReviewersGrp(className, FALSE, className, reviewersGrp, mfail)
#define GetReviewersGrpAtParent(_class, className, reviewersGrp, mfail) \
        _GetReviewersGrp(_class, TRUE, className, reviewersGrp, mfail)

#define GetRlsTsRForSCTReport(thisObj, report, mfail) \
        _GetRlsTsRForSCTReportAtClass(NULL, FALSE, thisObj, report, mfail)
#define GetRlsTsRForSCTReportAtClass(class, thisObj, report, mfail) \
        _GetRlsTsRForSCTReportAtClass(class, FALSE, thisObj, report, mfail)
#define GetRlsTsRForSCTReportAtParent(class, thisObj, report, mfail) \
        _GetRlsTsRForSCTReportAtClass(class, TRUE, thisObj, report, mfail)

#define GetRoleGrpName(pdpItem, constantName, roleName, mfail) \
        _GetRoleGrpNameAtClass(NULL, FALSE, pdpItem, constantName, roleName, mfail)
#define GetRoleGrpNameAtClass(class, pdpItem, constantName, roleName, mfail) \
        _GetRoleGrpNameAtClass(class, FALSE, pdpItem, constantName, roleName, mfail)
#define GetRoleGrpNameAtParent(class, pdpItem, constantName, roleName, mfail) \
        _GetRoleGrpNameAtClass(class, TRUE, pdpItem, constantName, roleName, mfail)

#define GetScopeReportsSCT(taskItem, databases, mfail) \
        _GetScopeReportsSCTAtClass(NULL, FALSE, taskItem, databases, mfail)
#define GetScopeReportsSCTAtClass(class, taskItem, databases, mfail) \
        _GetScopeReportsSCTAtClass(class, FALSE, taskItem, databases, mfail)
#define GetScopeReportsSCTAtParent(class, taskItem, databases, mfail) \
        _GetScopeReportsSCTAtClass(class, TRUE, taskItem, databases, mfail)

#define GetSolutionTreeInt(thisObj, rootObj, treeObj, mfail) \
        _GetSolutionTreeIntAtClass(NULL, FALSE, thisObj, rootObj, treeObj, mfail)
#define GetSolutionTreeIntAtClass(class, thisObj, rootObj, treeObj, mfail) \
        _GetSolutionTreeIntAtClass(class, FALSE, thisObj, rootObj, treeObj, mfail)
#define GetSolutionTreeIntAtParent(class, thisObj, rootObj, treeObj, mfail) \
        _GetSolutionTreeIntAtClass(class, TRUE, thisObj, rootObj, treeObj, mfail)

#define GetSupByForSCTReport(thisObj, report, mfail) \
        _GetSupByForSCTReportAtClass(NULL, FALSE, thisObj, report, mfail)
#define GetSupByForSCTReportAtClass(class, thisObj, report, mfail) \
        _GetSupByForSCTReportAtClass(class, FALSE, thisObj, report, mfail)
#define GetSupByForSCTReportAtParent(class, thisObj, report, mfail) \
        _GetSupByForSCTReportAtClass(class, TRUE, thisObj, report, mfail)

#define GetSupsdRvForImpMtxRpt(affectedObj, resultsRev, supsdRev, mfail) \
        _GetSupsdRvForImpMtxRptAtClass(NULL, FALSE, affectedObj, resultsRev, supsdRev, mfail)
#define GetSupsdRvForImpMtxRptAtClass(class, affectedObj, resultsRev, supsdRev, mfail) \
        _GetSupsdRvForImpMtxRptAtClass(class, FALSE, affectedObj, resultsRev, supsdRev, mfail)
#define GetSupsdRvForImpMtxRptAtParent(class, affectedObj, resultsRev, supsdRev, mfail) \
        _GetSupsdRvForImpMtxRptAtClass(class, TRUE, affectedObj, resultsRev, supsdRev, mfail)

#define GetTaskAdmBrwScope(taskItem, databases, mfail) \
        _GetTaskAdmBrwScopeAtClass(NULL, FALSE, taskItem, databases, mfail)
#define GetTaskAdmBrwScopeAtClass(class, taskItem, databases, mfail) \
        _GetTaskAdmBrwScopeAtClass(class, FALSE, taskItem, databases, mfail)
#define GetTaskAdmBrwScopeAtParent(class, taskItem, databases, mfail) \
        _GetTaskAdmBrwScopeAtClass(class, TRUE, taskItem, databases, mfail)

#define GetTaskLRRelations(taskItem, mfail) \
        _GetTaskLRRelationsAtClass(NULL, FALSE, taskItem, mfail)
#define GetTaskLRRelationsAtClass(class, taskItem, mfail) \
        _GetTaskLRRelationsAtClass(class, FALSE, taskItem, mfail)
#define GetTaskLRRelationsAtParent(class, taskItem, mfail) \
        _GetTaskLRRelationsAtClass(class, TRUE, taskItem, mfail)

#define GetWbsChildren(thisObj, childObjSet, mfail) \
        _GetWbsChildrenAtClass(NULL, FALSE, thisObj, childObjSet, mfail)
#define GetWbsChildrenAtClass(class, thisObj, childObjSet, mfail) \
        _GetWbsChildrenAtClass(class, FALSE, thisObj, childObjSet, mfail)
#define GetWbsChildrenAtParent(class, thisObj, childObjSet, mfail) \
        _GetWbsChildrenAtClass(class, TRUE, thisObj, childObjSet, mfail)

#define GetWbsChildrenMultiLev(thisObj, childObjSet, mfail) \
        _GetWbsChildrenMultiLevAtClass(NULL, FALSE, thisObj, childObjSet, mfail)
#define GetWbsChildrenMultiLevAtClass(class, thisObj, childObjSet, mfail) \
        _GetWbsChildrenMultiLevAtClass(class, FALSE, thisObj, childObjSet, mfail)
#define GetWbsChildrenMultiLevAtParent(class, thisObj, childObjSet, mfail) \
        _GetWbsChildrenMultiLevAtClass(class, TRUE, thisObj, childObjSet, mfail)

#define GetWbsMultiLevExt(thisObj, childObjSet, mfail) \
        _GetWbsMultiLevExtAtClass(NULL, FALSE, thisObj, childObjSet, mfail)
#define GetWbsMultiLevExtAtClass(class, thisObj, childObjSet, mfail) \
        _GetWbsMultiLevExtAtClass(class, FALSE, thisObj, childObjSet, mfail)
#define GetWbsMultiLevExtAtParent(class, thisObj, childObjSet, mfail) \
        _GetWbsMultiLevExtAtClass(class, TRUE, thisObj, childObjSet, mfail)

#define GetWbsParent(thisObj, parentObj, mfail) \
        _GetWbsParentAtClass(NULL, FALSE, thisObj, parentObj, mfail)
#define GetWbsParentAtClass(class, thisObj, parentObj, mfail) \
        _GetWbsParentAtClass(class, FALSE, thisObj, parentObj, mfail)
#define GetWbsParentAtParent(class, thisObj, parentObj, mfail) \
        _GetWbsParentAtClass(class, TRUE, thisObj, parentObj, mfail)

#define GetWbsRoot(thisObj, rootObj, mfail) \
        _GetWbsRootAtClass(NULL, FALSE, thisObj, rootObj, mfail)
#define GetWbsRootAtClass(class, thisObj, rootObj, mfail) \
        _GetWbsRootAtClass(class, FALSE, thisObj, rootObj, mfail)
#define GetWbsRootAtParent(class, thisObj, rootObj, mfail) \
        _GetWbsRootAtClass(class, TRUE, thisObj, rootObj, mfail)

#define HasChildren(thisObj, hasChildren, mfail) \
        _HasChildrenAtClass(NULL, FALSE, thisObj, hasChildren, mfail)
#define HasChildrenAtClass(class, thisObj, hasChildren, mfail) \
        _HasChildrenAtClass(class, FALSE, thisObj, hasChildren, mfail)
#define HasChildrenAtParent(class, thisObj, hasChildren, mfail) \
        _HasChildrenAtClass(class, TRUE, thisObj, hasChildren, mfail)

#define HasParents(thisObj, hasParents, parentObj, mfail) \
        _HasParentsAtClass(NULL, FALSE, thisObj, hasParents, parentObj, mfail)
#define HasParentsAtClass(class, thisObj, hasParents, parentObj, mfail) \
        _HasParentsAtClass(class, FALSE, thisObj, hasParents, parentObj, mfail)
#define HasParentsAtParent(class, thisObj, hasParents, parentObj, mfail) \
        _HasParentsAtClass(class, TRUE, thisObj, hasParents, parentObj, mfail)

#define InitAttributesForCko(pdpItem, sourceObj, mfail) \
        _InitAttributesForCkoAtClass(NULL, FALSE, pdpItem, sourceObj, mfail)
#define InitAttributesForCkoAtClass(class, pdpItem, sourceObj, mfail) \
        _InitAttributesForCkoAtClass(class, FALSE, pdpItem, sourceObj, mfail)
#define InitAttributesForCkoAtParent(class, pdpItem, sourceObj, mfail) \
        _InitAttributesForCkoAtClass(class, TRUE, pdpItem, sourceObj, mfail)

#define InitAttributesForCpy(pdpItem, sourceObj, mfail) \
        _InitAttributesForCpyAtClass(NULL, FALSE, pdpItem, sourceObj, mfail)
#define InitAttributesForCpyAtClass(class, pdpItem, sourceObj, mfail) \
        _InitAttributesForCpyAtClass(class, FALSE, pdpItem, sourceObj, mfail)
#define InitAttributesForCpyAtParent(class, pdpItem, sourceObj, mfail) \
        _InitAttributesForCpyAtClass(class, TRUE, pdpItem, sourceObj, mfail)

#define InitAttributesForRev(pdpItem, sourceObj, mfail) \
        _InitAttributesForRevAtClass(NULL, FALSE, pdpItem, sourceObj, mfail)
#define InitAttributesForRevAtClass(class, pdpItem, sourceObj, mfail) \
        _InitAttributesForRevAtClass(class, FALSE, pdpItem, sourceObj, mfail)
#define InitAttributesForRevAtParent(class, pdpItem, sourceObj, mfail) \
        _InitAttributesForRevAtClass(class, TRUE, pdpItem, sourceObj, mfail)

#define InitDispositionForCko(thisObj, sourceObj, mfail) \
        _InitDispositionForCkoAtClass(NULL, FALSE, thisObj, sourceObj, mfail)
#define InitDispositionForCkoAtClass(class, thisObj, sourceObj, mfail) \
        _InitDispositionForCkoAtClass(class, FALSE, thisObj, sourceObj, mfail)
#define InitDispositionForCkoAtParent(class, thisObj, sourceObj, mfail) \
        _InitDispositionForCkoAtClass(class, TRUE, thisObj, sourceObj, mfail)

#define InitDispositionForCpy(pdpItem, sourceObj, mfail) \
        _InitDispositionForCpyAtClass(NULL, FALSE, pdpItem, sourceObj, mfail)
#define InitDispositionForCpyAtClass(class, pdpItem, sourceObj, mfail) \
        _InitDispositionForCpyAtClass(class, FALSE, pdpItem, sourceObj, mfail)
#define InitDispositionForCpyAtParent(class, pdpItem, sourceObj, mfail) \
        _InitDispositionForCpyAtClass(class, TRUE, pdpItem, sourceObj, mfail)

#define InitDispositionForRev(pdpItem, sourceObj, mfail) \
        _InitDispositionForRevAtClass(NULL, FALSE, pdpItem, sourceObj, mfail)
#define InitDispositionForRevAtClass(class, pdpItem, sourceObj, mfail) \
        _InitDispositionForRevAtClass(class, FALSE, pdpItem, sourceObj, mfail)
#define InitDispositionForRevAtParent(class, pdpItem, sourceObj, mfail) \
        _InitDispositionForRevAtClass(class, TRUE, pdpItem, sourceObj, mfail)

#define InitStateForCko(pdpItem, sourceObj, mfail) \
        _InitStateForCkoAtClass(NULL, FALSE, pdpItem, sourceObj, mfail)
#define InitStateForCkoAtClass(class, pdpItem, sourceObj, mfail) \
        _InitStateForCkoAtClass(class, FALSE, pdpItem, sourceObj, mfail)
#define InitStateForCkoAtParent(class, pdpItem, sourceObj, mfail) \
        _InitStateForCkoAtClass(class, TRUE, pdpItem, sourceObj, mfail)

#define InitStateForCpy(pdpItem, sourceObj, mfail) \
        _InitStateForCpyAtClass(NULL, FALSE, pdpItem, sourceObj, mfail)
#define InitStateForCpyAtClass(class, pdpItem, sourceObj, mfail) \
        _InitStateForCpyAtClass(class, FALSE, pdpItem, sourceObj, mfail)
#define InitStateForCpyAtParent(class, pdpItem, sourceObj, mfail) \
        _InitStateForCpyAtClass(class, TRUE, pdpItem, sourceObj, mfail)

#define InitStateForRev(pdpItem, sourceObj, mfail) \
        _InitStateForRevAtClass(NULL, FALSE, pdpItem, sourceObj, mfail)
#define InitStateForRevAtClass(class, pdpItem, sourceObj, mfail) \
        _InitStateForRevAtClass(class, FALSE, pdpItem, sourceObj, mfail)
#define InitStateForRevAtParent(class, pdpItem, sourceObj, mfail) \
        _InitStateForRevAtClass(class, TRUE, pdpItem, sourceObj, mfail)

#define InitStatusForCko(pdpItem, sourceObj, mfail) \
        _InitStatusForCkoAtClass(NULL, FALSE, pdpItem, sourceObj, mfail)
#define InitStatusForCkoAtClass(class, pdpItem, sourceObj, mfail) \
        _InitStatusForCkoAtClass(class, FALSE, pdpItem, sourceObj, mfail)
#define InitStatusForCkoAtParent(class, pdpItem, sourceObj, mfail) \
        _InitStatusForCkoAtClass(class, TRUE, pdpItem, sourceObj, mfail)

#define InitStatusForCpy(pdpItem, sourceObj, mfail) \
        _InitStatusForCpyAtClass(NULL, FALSE, pdpItem, sourceObj, mfail)
#define InitStatusForCpyAtClass(class, pdpItem, sourceObj, mfail) \
        _InitStatusForCpyAtClass(class, FALSE, pdpItem, sourceObj, mfail)
#define InitStatusForCpyAtParent(class, pdpItem, sourceObj, mfail) \
        _InitStatusForCpyAtClass(class, TRUE, pdpItem, sourceObj, mfail)

#define InitStatusForRev(pdpItem, sourceObj, mfail) \
        _InitStatusForRevAtClass(NULL, FALSE, pdpItem, sourceObj, mfail)
#define InitStatusForRevAtClass(class, pdpItem, sourceObj, mfail) \
        _InitStatusForRevAtClass(class, FALSE, pdpItem, sourceObj, mfail)
#define InitStatusForRevAtParent(class, pdpItem, sourceObj, mfail) \
        _InitStatusForRevAtClass(class, TRUE, pdpItem, sourceObj, mfail)

#define IsChangeDispAllowed(parentObj, childObj, propagateDisp, mfail) \
        _IsChangeDispAllowedAtClass(NULL, FALSE, parentObj, childObj, propagateDisp, mfail)
#define IsChangeDispAllowedAtClass(class, parentObj, childObj, propagateDisp, mfail) \
        _IsChangeDispAllowedAtClass(class, FALSE, parentObj, childObj, propagateDisp, mfail)
#define IsChangeDispAllowedAtParent(class, parentObj, childObj, propagateDisp, mfail) \
        _IsChangeDispAllowedAtClass(class, TRUE, parentObj, childObj, propagateDisp, mfail)

#define IsClosureValueValid(thisObj, closurevalue, isClosureValueValid, mfail) \
        _IsClosureValueValidAtClass(NULL, FALSE, thisObj, closurevalue, isClosureValueValid, mfail)
#define IsClosureValueValidAtClass(class, thisObj, closurevalue, isClosureValueValid, mfail) \
        _IsClosureValueValidAtClass(class, FALSE, thisObj, closurevalue, isClosureValueValid, mfail)
#define IsClosureValueValidAtParent(class, thisObj, closurevalue, isClosureValueValid, mfail) \
        _IsClosureValueValidAtClass(class, TRUE, thisObj, closurevalue, isClosureValueValid, mfail)

#define IsEffectivityAssigned(obj, procHist, msgProc, exitState, advComments, mfail) \
        _IsEffectivityAssignedAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define IsEffectivityAssignedAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _IsEffectivityAssignedAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define IsEffectivityAssignedAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _IsEffectivityAssignedAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define IsImplementingPdpClose(thisObj, mfail) \
        _IsImplementingPdpCloseAtClass(NULL, FALSE, thisObj, mfail)
#define IsImplementingPdpCloseAtClass(class, thisObj, mfail) \
        _IsImplementingPdpCloseAtClass(class, FALSE, thisObj, mfail)
#define IsImplementingPdpCloseAtParent(class, thisObj, mfail) \
        _IsImplementingPdpCloseAtClass(class, TRUE, thisObj, mfail)

#define IsParentImptdBySameECN(thisObj, isSame, mfail) \
        _IsParentImptdBySameECNAtClass(NULL, FALSE, thisObj, isSame, mfail)
#define IsParentImptdBySameECNAtClass(class, thisObj, isSame, mfail) \
        _IsParentImptdBySameECNAtClass(class, FALSE, thisObj, isSame, mfail)
#define IsParentImptdBySameECNAtParent(class, thisObj, isSame, mfail) \
        _IsParentImptdBySameECNAtClass(class, TRUE, thisObj, isSame, mfail)

#define IsPdpInAuthoringState(pdpItem, authoringState, mfail) \
        _IsPdpInAuthoringStateAtClass(NULL, FALSE, pdpItem, authoringState, mfail)
#define IsPdpInAuthoringStateAtClass(class, pdpItem, authoringState, mfail) \
        _IsPdpInAuthoringStateAtClass(class, FALSE, pdpItem, authoringState, mfail)
#define IsPdpInAuthoringStateAtParent(class, pdpItem, authoringState, mfail) \
        _IsPdpInAuthoringStateAtClass(class, TRUE, pdpItem, authoringState, mfail)

#define IsPdpInReviewState(pdpItem, inReviewState, mfail) \
        _IsPdpInReviewStateAtClass(NULL, FALSE, pdpItem, inReviewState, mfail)
#define IsPdpInReviewStateAtClass(class, pdpItem, inReviewState, mfail) \
        _IsPdpInReviewStateAtClass(class, FALSE, pdpItem, inReviewState, mfail)
#define IsPdpInReviewStateAtParent(class, pdpItem, inReviewState, mfail) \
        _IsPdpInReviewStateAtClass(class, TRUE, pdpItem, inReviewState, mfail)

#define IsPrdPlanImplemented(obj, procHist, msgProc, exitState, advComments, mfail) \
        _IsPrdPlanImplementedAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define IsPrdPlanImplementedAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _IsPrdPlanImplementedAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define IsPrdPlanImplementedAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _IsPrdPlanImplementedAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define IsPrdPlnMrApproved(pdpMstr, isApproved, approvedDisp, mfail) \
        _IsPrdPlnMrApprovedAtClass(NULL, FALSE, pdpMstr, isApproved, approvedDisp, mfail)
#define IsPrdPlnMrApprovedAtClass(class, pdpMstr, isApproved, approvedDisp, mfail) \
        _IsPrdPlnMrApprovedAtClass(class, FALSE, pdpMstr, isApproved, approvedDisp, mfail)
#define IsPrdPlnMrApprovedAtParent(class, pdpMstr, isApproved, approvedDisp, mfail) \
        _IsPrdPlnMrApprovedAtClass(class, TRUE, pdpMstr, isApproved, approvedDisp, mfail)

#define IsPrdPlnMrImplemented(pdpMstr, isImplemented, mfail) \
        _IsPrdPlnMrImplementedAtClass(NULL, FALSE, pdpMstr, isImplemented, mfail)
#define IsPrdPlnMrImplementedAtClass(class, pdpMstr, isImplemented, mfail) \
        _IsPrdPlnMrImplementedAtClass(class, FALSE, pdpMstr, isImplemented, mfail)
#define IsPrdPlnMrImplementedAtParent(class, pdpMstr, isImplemented, mfail) \
        _IsPrdPlnMrImplementedAtClass(class, TRUE, pdpMstr, isImplemented, mfail)

#define IsReviewBoardAssigned(obj, procHist, msgProc, exitState, advComments, mfail) \
        _IsReviewBoardAssignedAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define IsReviewBoardAssignedAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _IsReviewBoardAssignedAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define IsReviewBoardAssignedAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _IsReviewBoardAssignedAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define IsStateOkForPdpClose(thisObj, isStateOk, mfail) \
        _IsStateOkForPdpCloseAtClass(NULL, FALSE, thisObj, isStateOk, mfail)
#define IsStateOkForPdpCloseAtClass(class, thisObj, isStateOk, mfail) \
        _IsStateOkForPdpCloseAtClass(class, FALSE, thisObj, isStateOk, mfail)
#define IsStateOkForPdpCloseAtParent(class, thisObj, isStateOk, mfail) \
        _IsStateOkForPdpCloseAtClass(class, TRUE, thisObj, isStateOk, mfail)

#define IsStateVecOkForIncorpR(pdpItem, relObj, condExists, mfail) \
        _IsStateVecOkForIncorpRAtClass(NULL, FALSE, pdpItem, relObj, condExists, mfail)
#define IsStateVecOkForIncorpRAtClass(class, pdpItem, relObj, condExists, mfail) \
        _IsStateVecOkForIncorpRAtClass(class, FALSE, pdpItem, relObj, condExists, mfail)
#define IsStateVecOkForIncorpRAtParent(class, pdpItem, relObj, condExists, mfail) \
        _IsStateVecOkForIncorpRAtClass(class, TRUE, pdpItem, relObj, condExists, mfail)

#define IsStateVecOkForPpsRel(pdpItem, relObj, condExists, mfail) \
        _IsStateVecOkForPpsRelAtClass(NULL, FALSE, pdpItem, relObj, condExists, mfail)
#define IsStateVecOkForPpsRelAtClass(class, pdpItem, relObj, condExists, mfail) \
        _IsStateVecOkForPpsRelAtClass(class, FALSE, pdpItem, relObj, condExists, mfail)
#define IsStateVecOkForPpsRelAtParent(class, pdpItem, relObj, condExists, mfail) \
        _IsStateVecOkForPpsRelAtClass(class, TRUE, pdpItem, relObj, condExists, mfail)

#define IsStateVecOkForRefRel(pdpItem, relObj, condExists, mfail) \
        _IsStateVecOkForRefRelAtClass(NULL, FALSE, pdpItem, relObj, condExists, mfail)
#define IsStateVecOkForRefRelAtClass(class, pdpItem, relObj, condExists, mfail) \
        _IsStateVecOkForRefRelAtClass(class, FALSE, pdpItem, relObj, condExists, mfail)
#define IsStateVecOkForRefRelAtParent(class, pdpItem, relObj, condExists, mfail) \
        _IsStateVecOkForRefRelAtClass(class, TRUE, pdpItem, relObj, condExists, mfail)

#define IsStateVecOkForSupRel(pdpItem, relObj, condExists, mfail) \
        _IsStateVecOkForSupRelAtClass(NULL, FALSE, pdpItem, relObj, condExists, mfail)
#define IsStateVecOkForSupRelAtClass(class, pdpItem, relObj, condExists, mfail) \
        _IsStateVecOkForSupRelAtClass(class, FALSE, pdpItem, relObj, condExists, mfail)
#define IsStateVecOkForSupRelAtParent(class, pdpItem, relObj, condExists, mfail) \
        _IsStateVecOkForSupRelAtClass(class, TRUE, pdpItem, relObj, condExists, mfail)

#define IsStateVectorOkForCsu(pdpItem, mfail) \
        _IsStateVectorOkForCsuAtClass(NULL, FALSE, pdpItem, mfail)
#define IsStateVectorOkForCsuAtClass(class, pdpItem, mfail) \
        _IsStateVectorOkForCsuAtClass(class, FALSE, pdpItem, mfail)
#define IsStateVectorOkForCsuAtParent(class, pdpItem, mfail) \
        _IsStateVectorOkForCsuAtClass(class, TRUE, pdpItem, mfail)

#define IsUnderCMControl(thisObj, anwer, mfail) \
        _IsUnderCMControlAtClass(NULL, FALSE, thisObj, anwer, mfail)
#define IsUnderCMControlAtClass(class, thisObj, anwer, mfail) \
        _IsUnderCMControlAtClass(class, FALSE, thisObj, anwer, mfail)
#define IsUnderCMControlAtParent(class, thisObj, anwer, mfail) \
        _IsUnderCMControlAtClass(class, TRUE, thisObj, anwer, mfail)

#define IsWbsRollUpAllowed(thisObj, isOkay, mfail) \
        _IsWbsRollUpAllowedAtClass(NULL, FALSE, thisObj, isOkay, mfail)
#define IsWbsRollUpAllowedAtClass(class, thisObj, isOkay, mfail) \
        _IsWbsRollUpAllowedAtClass(class, FALSE, thisObj, isOkay, mfail)
#define IsWbsRollUpAllowedAtParent(class, thisObj, isOkay, mfail) \
        _IsWbsRollUpAllowedAtClass(class, TRUE, thisObj, isOkay, mfail)

#define LogChangeItem(griItemClass, createArgs, griItem, mfail) \
        _LogChangeItem(griItemClass, FALSE, griItemClass, createArgs, griItem, mfail)
#define LogChangeItemAtParent(_class, griItemClass, createArgs, griItem, mfail) \
        _LogChangeItem(_class, TRUE, griItemClass, createArgs, griItem, mfail)

#define LogChangeItemAndRel(className, backgroundItem, relationship, mfail) \
        _LogChangeItemAndRel(className, FALSE, className, backgroundItem, relationship, mfail)
#define LogChangeItemAndRelAtParent(_class, className, backgroundItem, relationship, mfail) \
        _LogChangeItemAndRel(_class, TRUE, className, backgroundItem, relationship, mfail)

#define NotifyGrpOnAssgnFail(pdpItem, invalidUsrOrGrp, attrName, mfail) \
        _NotifyGrpOnAssgnFailAtClass(NULL, FALSE, pdpItem, invalidUsrOrGrp, attrName, mfail)
#define NotifyGrpOnAssgnFailAtClass(class, pdpItem, invalidUsrOrGrp, attrName, mfail) \
        _NotifyGrpOnAssgnFailAtClass(class, FALSE, pdpItem, invalidUsrOrGrp, attrName, mfail)
#define NotifyGrpOnAssgnFailAtParent(class, pdpItem, invalidUsrOrGrp, attrName, mfail) \
        _NotifyGrpOnAssgnFailAtClass(class, TRUE, pdpItem, invalidUsrOrGrp, attrName, mfail)

#define PdpIsApproved(thisObj, isApproved, mfail) \
        _PdpIsApprovedAtClass(NULL, FALSE, thisObj, isApproved, mfail)
#define PdpIsApprovedAtClass(class, thisObj, isApproved, mfail) \
        _PdpIsApprovedAtClass(class, FALSE, thisObj, isApproved, mfail)
#define PdpIsApprovedAtParent(class, thisObj, isApproved, mfail) \
        _PdpIsApprovedAtClass(class, TRUE, thisObj, isApproved, mfail)

#define PdpIsApprovedExt(thisObj, isApproved, mfail) \
        _PdpIsApprovedExtAtClass(NULL, FALSE, thisObj, isApproved, mfail)
#define PdpIsApprovedExtAtClass(class, thisObj, isApproved, mfail) \
        _PdpIsApprovedExtAtClass(class, FALSE, thisObj, isApproved, mfail)
#define PdpIsApprovedExtAtParent(class, thisObj, isApproved, mfail) \
        _PdpIsApprovedExtAtClass(class, TRUE, thisObj, isApproved, mfail)

#define PdpIsCanceled(pdpItem, isCanceled, mfail) \
        _PdpIsCanceledAtClass(NULL, FALSE, pdpItem, isCanceled, mfail)
#define PdpIsCanceledAtClass(class, pdpItem, isCanceled, mfail) \
        _PdpIsCanceledAtClass(class, FALSE, pdpItem, isCanceled, mfail)
#define PdpIsCanceledAtParent(class, pdpItem, isCanceled, mfail) \
        _PdpIsCanceledAtClass(class, TRUE, pdpItem, isCanceled, mfail)

#define PdpIsClosed(pdpItem, isClosed, mfail) \
        _PdpIsClosedAtClass(NULL, FALSE, pdpItem, isClosed, mfail)
#define PdpIsClosedAtClass(class, pdpItem, isClosed, mfail) \
        _PdpIsClosedAtClass(class, FALSE, pdpItem, isClosed, mfail)
#define PdpIsClosedAtParent(class, pdpItem, isClosed, mfail) \
        _PdpIsClosedAtClass(class, TRUE, pdpItem, isClosed, mfail)

#define PdpIsDisapproved(pdpItem, isDisapproved, mfail) \
        _PdpIsDisapprovedAtClass(NULL, FALSE, pdpItem, isDisapproved, mfail)
#define PdpIsDisapprovedAtClass(class, pdpItem, isDisapproved, mfail) \
        _PdpIsDisapprovedAtClass(class, FALSE, pdpItem, isDisapproved, mfail)
#define PdpIsDisapprovedAtParent(class, pdpItem, isDisapproved, mfail) \
        _PdpIsDisapprovedAtClass(class, TRUE, pdpItem, isDisapproved, mfail)

#define PdpIsExecuting(pdpItem, isExecuting, mfail) \
        _PdpIsExecutingAtClass(NULL, FALSE, pdpItem, isExecuting, mfail)
#define PdpIsExecutingAtClass(class, pdpItem, isExecuting, mfail) \
        _PdpIsExecutingAtClass(class, FALSE, pdpItem, isExecuting, mfail)
#define PdpIsExecutingAtParent(class, pdpItem, isExecuting, mfail) \
        _PdpIsExecutingAtClass(class, TRUE, pdpItem, isExecuting, mfail)

#define PdpIsInProgress(pdpItem, isInProgress, mfail) \
        _PdpIsInProgressAtClass(NULL, FALSE, pdpItem, isInProgress, mfail)
#define PdpIsInProgressAtClass(class, pdpItem, isInProgress, mfail) \
        _PdpIsInProgressAtClass(class, FALSE, pdpItem, isInProgress, mfail)
#define PdpIsInProgressAtParent(class, pdpItem, isInProgress, mfail) \
        _PdpIsInProgressAtClass(class, TRUE, pdpItem, isInProgress, mfail)

#define PdpIsInReadyState(pdpItem, isInReadyState, mfail) \
        _PdpIsInReadyStateAtClass(NULL, FALSE, pdpItem, isInReadyState, mfail)
#define PdpIsInReadyStateAtClass(class, pdpItem, isInReadyState, mfail) \
        _PdpIsInReadyStateAtClass(class, FALSE, pdpItem, isInReadyState, mfail)
#define PdpIsInReadyStateAtParent(class, pdpItem, isInReadyState, mfail) \
        _PdpIsInReadyStateAtClass(class, TRUE, pdpItem, isInReadyState, mfail)

#define PdpIsIncorporated(pdpItem, isIncorporated, mfail) \
        _PdpIsIncorporatedAtClass(NULL, FALSE, pdpItem, isIncorporated, mfail)
#define PdpIsIncorporatedAtClass(class, pdpItem, isIncorporated, mfail) \
        _PdpIsIncorporatedAtClass(class, FALSE, pdpItem, isIncorporated, mfail)
#define PdpIsIncorporatedAtParent(class, pdpItem, isIncorporated, mfail) \
        _PdpIsIncorporatedAtClass(class, TRUE, pdpItem, isIncorporated, mfail)

#define PdpIsOpen(pdpItem, isOpen, mfail) \
        _PdpIsOpenAtClass(NULL, FALSE, pdpItem, isOpen, mfail)
#define PdpIsOpenAtClass(class, pdpItem, isOpen, mfail) \
        _PdpIsOpenAtClass(class, FALSE, pdpItem, isOpen, mfail)
#define PdpIsOpenAtParent(class, pdpItem, isOpen, mfail) \
        _PdpIsOpenAtClass(class, TRUE, pdpItem, isOpen, mfail)

#define PdpIsSuspended(pdpItem, isSuspended, mfail) \
        _PdpIsSuspendedAtClass(NULL, FALSE, pdpItem, isSuspended, mfail)
#define PdpIsSuspendedAtClass(class, pdpItem, isSuspended, mfail) \
        _PdpIsSuspendedAtClass(class, FALSE, pdpItem, isSuspended, mfail)
#define PdpIsSuspendedAtParent(class, pdpItem, isSuspended, mfail) \
        _PdpIsSuspendedAtClass(class, TRUE, pdpItem, isSuspended, mfail)

#define PendingChangesRptXML(thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _PendingChangesRptXMLAtClass(NULL, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define PendingChangesRptXMLAtClass(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _PendingChangesRptXMLAtClass(class, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define PendingChangesRptXMLAtParent(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _PendingChangesRptXMLAtClass(class, TRUE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define PlannedImpactsRptInt(className, chgObjects, objectsForReport, objectsForInflate, mfail) \
        _PlannedImpactsRptInt(className, FALSE, className, chgObjects, objectsForReport, objectsForInflate, mfail)
#define PlannedImpactsRptIntAtParent(_class, className, chgObjects, objectsForReport, objectsForInflate, mfail) \
        _PlannedImpactsRptInt(_class, TRUE, className, chgObjects, objectsForReport, objectsForInflate, mfail)

#define PlannedImpactsRptXML(thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _PlannedImpactsRptXMLAtClass(NULL, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define PlannedImpactsRptXMLAtClass(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _PlannedImpactsRptXMLAtClass(class, FALSE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)
#define PlannedImpactsRptXMLAtParent(class, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail) \
        _PlannedImpactsRptXMLAtClass(class, TRUE, thisObj, lineSeparator, taskObject, argsObj, resultXMLObj, needToTranslit, mfail)

#define PrcAffItmForImpMtxRpt(affObj, resObjSet, resRelSet, objectsForReport, objectsForInflate, mfail) \
        _PrcAffItmForImpMtxRptAtClass(NULL, FALSE, affObj, resObjSet, resRelSet, objectsForReport, objectsForInflate, mfail)
#define PrcAffItmForImpMtxRptAtClass(class, affObj, resObjSet, resRelSet, objectsForReport, objectsForInflate, mfail) \
        _PrcAffItmForImpMtxRptAtClass(class, FALSE, affObj, resObjSet, resRelSet, objectsForReport, objectsForInflate, mfail)
#define PrcAffItmForImpMtxRptAtParent(class, affObj, resObjSet, resRelSet, objectsForReport, objectsForInflate, mfail) \
        _PrcAffItmForImpMtxRptAtClass(class, TRUE, affObj, resObjSet, resRelSet, objectsForReport, objectsForInflate, mfail)

#define PrcChgEffForBslRpt(chgObj, objectsForReport, objectsForInflate, mfail) \
        _PrcChgEffForBslRptAtClass(NULL, FALSE, chgObj, objectsForReport, objectsForInflate, mfail)
#define PrcChgEffForBslRptAtClass(class, chgObj, objectsForReport, objectsForInflate, mfail) \
        _PrcChgEffForBslRptAtClass(class, FALSE, chgObj, objectsForReport, objectsForInflate, mfail)
#define PrcChgEffForBslRptAtParent(class, chgObj, objectsForReport, objectsForInflate, mfail) \
        _PrcChgEffForBslRptAtClass(class, TRUE, chgObj, objectsForReport, objectsForInflate, mfail)

#define PrcChgsForBslRpt(thisObj, objectsForReport, objectsForInflate, mfail) \
        _PrcChgsForBslRptAtClass(NULL, FALSE, thisObj, objectsForReport, objectsForInflate, mfail)
#define PrcChgsForBslRptAtClass(class, thisObj, objectsForReport, objectsForInflate, mfail) \
        _PrcChgsForBslRptAtClass(class, FALSE, thisObj, objectsForReport, objectsForInflate, mfail)
#define PrcChgsForBslRptAtParent(class, thisObj, objectsForReport, objectsForInflate, mfail) \
        _PrcChgsForBslRptAtClass(class, TRUE, thisObj, objectsForReport, objectsForInflate, mfail)

#define PrcImplChgForImpMtxRpt(chgObj, objectsForReport, objectsForInflate, mfail) \
        _PrcImplChgForImpMtxRptAtClass(NULL, FALSE, chgObj, objectsForReport, objectsForInflate, mfail)
#define PrcImplChgForImpMtxRptAtClass(class, chgObj, objectsForReport, objectsForInflate, mfail) \
        _PrcImplChgForImpMtxRptAtClass(class, FALSE, chgObj, objectsForReport, objectsForInflate, mfail)
#define PrcImplChgForImpMtxRptAtParent(class, chgObj, objectsForReport, objectsForInflate, mfail) \
        _PrcImplChgForImpMtxRptAtClass(class, TRUE, chgObj, objectsForReport, objectsForInflate, mfail)

#define PrcSuppInfoForBslRpt(relClass, relshipName, itemsToProcess, objectsForReport, objectsForInflate, mfail) \
        _PrcSuppInfoForBslRpt(relClass, FALSE, relClass, relshipName, itemsToProcess, objectsForReport, objectsForInflate, mfail)
#define PrcSuppInfoForBslRptAtParent(_class, relClass, relshipName, itemsToProcess, objectsForReport, objectsForInflate, mfail) \
        _PrcSuppInfoForBslRpt(_class, TRUE, relClass, relshipName, itemsToProcess, objectsForReport, objectsForInflate, mfail)

#define PrcSuppInfoImpMtxRpt(relClass, relshipName, objToProcess, objectsForReport, objectsForInflate, mfail) \
        _PrcSuppInfoImpMtxRpt(relClass, FALSE, relClass, relshipName, objToProcess, objectsForReport, objectsForInflate, mfail)
#define PrcSuppInfoImpMtxRptAtParent(_class, relClass, relshipName, objToProcess, objectsForReport, objectsForInflate, mfail) \
        _PrcSuppInfoImpMtxRpt(_class, TRUE, relClass, relshipName, objToProcess, objectsForReport, objectsForInflate, mfail)

#define PrdPlnClosureDPInt(thisObj, mfail) \
        _PrdPlnClosureDPIntAtClass(NULL, FALSE, thisObj, mfail)
#define PrdPlnClosureDPIntAtClass(class, thisObj, mfail) \
        _PrdPlnClosureDPIntAtClass(class, FALSE, thisObj, mfail)
#define PrdPlnClosureDPIntAtParent(class, thisObj, mfail) \
        _PrdPlnClosureDPIntAtClass(class, TRUE, thisObj, mfail)

#define PrdPlnValMsg(obj, procHist, msgProc, exitState, advComments, mfail) \
        _PrdPlnValMsgAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define PrdPlnValMsgAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _PrdPlnValMsgAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define PrdPlnValMsgAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _PrdPlnValMsgAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define PrepareObjForBIImpRpt(pdpItem, rootObj, mfail) \
        _PrepareObjForBIImpRptAtClass(NULL, FALSE, pdpItem, rootObj, mfail)
#define PrepareObjForBIImpRptAtClass(class, pdpItem, rootObj, mfail) \
        _PrepareObjForBIImpRptAtClass(class, FALSE, pdpItem, rootObj, mfail)
#define PrepareObjForBIImpRptAtParent(class, pdpItem, rootObj, mfail) \
        _PrepareObjForBIImpRptAtClass(class, TRUE, pdpItem, rootObj, mfail)

#define ProcRelForPdpClosure(relObj, dialogObj, pdpItem, mfail) \
        _ProcRelForPdpClosureAtClass(NULL, FALSE, relObj, dialogObj, pdpItem, mfail)
#define ProcRelForPdpClosureAtClass(class, relObj, dialogObj, pdpItem, mfail) \
        _ProcRelForPdpClosureAtClass(class, FALSE, relObj, dialogObj, pdpItem, mfail)
#define ProcRelForPdpClosureAtParent(class, relObj, dialogObj, pdpItem, mfail) \
        _ProcRelForPdpClosureAtClass(class, TRUE, relObj, dialogObj, pdpItem, mfail)

#define ProceedRelation(leftObj, relateResultsIn, mfail) \
        _ProceedRelationAtClass(NULL, FALSE, leftObj, relateResultsIn, mfail)
#define ProceedRelationAtClass(class, leftObj, relateResultsIn, mfail) \
        _ProceedRelationAtClass(class, FALSE, leftObj, relateResultsIn, mfail)
#define ProceedRelationAtParent(class, leftObj, relateResultsIn, mfail) \
        _ProceedRelationAtClass(class, TRUE, leftObj, relateResultsIn, mfail)

#define ProcessRelForCdi(relObj, dialogObj, itemObj, mfail) \
        _ProcessRelForCdiAtClass(NULL, FALSE, relObj, dialogObj, itemObj, mfail)
#define ProcessRelForCdiAtClass(class, relObj, dialogObj, itemObj, mfail) \
        _ProcessRelForCdiAtClass(class, FALSE, relObj, dialogObj, itemObj, mfail)
#define ProcessRelForCdiAtParent(class, relObj, dialogObj, itemObj, mfail) \
        _ProcessRelForCdiAtClass(class, TRUE, relObj, dialogObj, itemObj, mfail)

#define ProcessRelForCla(relObj, dialogObj, itemObj, mfail) \
        _ProcessRelForClaAtClass(NULL, FALSE, relObj, dialogObj, itemObj, mfail)
#define ProcessRelForClaAtClass(class, relObj, dialogObj, itemObj, mfail) \
        _ProcessRelForClaAtClass(class, FALSE, relObj, dialogObj, itemObj, mfail)
#define ProcessRelForClaAtParent(class, relObj, dialogObj, itemObj, mfail) \
        _ProcessRelForClaAtClass(class, TRUE, relObj, dialogObj, itemObj, mfail)

#define ProcessRelForCsu(relObj, dialogObj, itemObj, mfail) \
        _ProcessRelForCsuAtClass(NULL, FALSE, relObj, dialogObj, itemObj, mfail)
#define ProcessRelForCsuAtClass(class, relObj, dialogObj, itemObj, mfail) \
        _ProcessRelForCsuAtClass(class, FALSE, relObj, dialogObj, itemObj, mfail)
#define ProcessRelForCsuAtParent(class, relObj, dialogObj, itemObj, mfail) \
        _ProcessRelForCsuAtClass(class, TRUE, relObj, dialogObj, itemObj, mfail)

#define ProcessRelForCtd(relObj, dialogObj, itemObj, mfail) \
        _ProcessRelForCtdAtClass(NULL, FALSE, relObj, dialogObj, itemObj, mfail)
#define ProcessRelForCtdAtClass(class, relObj, dialogObj, itemObj, mfail) \
        _ProcessRelForCtdAtClass(class, FALSE, relObj, dialogObj, itemObj, mfail)
#define ProcessRelForCtdAtParent(class, relObj, dialogObj, itemObj, mfail) \
        _ProcessRelForCtdAtClass(class, TRUE, relObj, dialogObj, itemObj, mfail)

#define ProcessSetForCdi(className, dlgObj, originObjects, extraStr, extraObj, mfail) \
        _ProcessSetForCdi(className, FALSE, className, dlgObj, originObjects, extraStr, extraObj, mfail)
#define ProcessSetForCdiAtParent(_class, className, dlgObj, originObjects, extraStr, extraObj, mfail) \
        _ProcessSetForCdi(_class, TRUE, className, dlgObj, originObjects, extraStr, extraObj, mfail)

#define ProcessSetForCdiPost(className, dlgObj, originObjects, extraStr, extraObj, mfail) \
        _ProcessSetForCdiPost(className, FALSE, className, dlgObj, originObjects, extraStr, extraObj, mfail)
#define ProcessSetForCdiPostAtParent(_class, className, dlgObj, originObjects, extraStr, extraObj, mfail) \
        _ProcessSetForCdiPost(_class, TRUE, className, dlgObj, originObjects, extraStr, extraObj, mfail)

#define ProcessSetForCdiPre(ClassName, dlgObj, originObjects, extraStr, extraObj, mfail) \
        _ProcessSetForCdiPre(ClassName, FALSE, ClassName, dlgObj, originObjects, extraStr, extraObj, mfail)
#define ProcessSetForCdiPreAtParent(_class, ClassName, dlgObj, originObjects, extraStr, extraObj, mfail) \
        _ProcessSetForCdiPre(_class, TRUE, ClassName, dlgObj, originObjects, extraStr, extraObj, mfail)

#define ProcessSetForCsu(className, dlgObj, originObjects, extraStr, extraObj, mfail) \
        _ProcessSetForCsu(className, FALSE, className, dlgObj, originObjects, extraStr, extraObj, mfail)
#define ProcessSetForCsuAtParent(_class, className, dlgObj, originObjects, extraStr, extraObj, mfail) \
        _ProcessSetForCsu(_class, TRUE, className, dlgObj, originObjects, extraStr, extraObj, mfail)

#define ProcessSetForCsuPost(className, dlgObj, originObjects, extraStr, extraObj, mfail) \
        _ProcessSetForCsuPost(className, FALSE, className, dlgObj, originObjects, extraStr, extraObj, mfail)
#define ProcessSetForCsuPostAtParent(_class, className, dlgObj, originObjects, extraStr, extraObj, mfail) \
        _ProcessSetForCsuPost(_class, TRUE, className, dlgObj, originObjects, extraStr, extraObj, mfail)

#define ProcessSetForCsuPre(ClassName, dlgObj, originObjects, extraStr, extraObj, mfail) \
        _ProcessSetForCsuPre(ClassName, FALSE, ClassName, dlgObj, originObjects, extraStr, extraObj, mfail)
#define ProcessSetForCsuPreAtParent(_class, ClassName, dlgObj, originObjects, extraStr, extraObj, mfail) \
        _ProcessSetForCsuPre(_class, TRUE, ClassName, dlgObj, originObjects, extraStr, extraObj, mfail)

#define ProductPlanClosure(pdpItem, closure, closureComments, mfail) \
        _ProductPlanClosureAtClass(NULL, FALSE, pdpItem, closure, closureComments, mfail)
#define ProductPlanClosureAtClass(class, pdpItem, closure, closureComments, mfail) \
        _ProductPlanClosureAtClass(class, FALSE, pdpItem, closure, closureComments, mfail)
#define ProductPlanClosureAtParent(class, pdpItem, closure, closureComments, mfail) \
        _ProductPlanClosureAtClass(class, TRUE, pdpItem, closure, closureComments, mfail)

#define ProductPlanClosureDP(thisObj, mfail) \
        _ProductPlanClosureDPAtClass(NULL, FALSE, thisObj, mfail)
#define ProductPlanClosureDPAtClass(class, thisObj, mfail) \
        _ProductPlanClosureDPAtClass(class, FALSE, thisObj, mfail)
#define ProductPlanClosureDPAtParent(class, thisObj, mfail) \
        _ProductPlanClosureDPAtClass(class, TRUE, thisObj, mfail)

#define ProductPlanClosureInt(prdPlnIt, dialogObj, mfail) \
        _ProductPlanClosureIntAtClass(NULL, FALSE, prdPlnIt, dialogObj, mfail)
#define ProductPlanClosureIntAtClass(class, prdPlnIt, dialogObj, mfail) \
        _ProductPlanClosureIntAtClass(class, FALSE, prdPlnIt, dialogObj, mfail)
#define ProductPlanClosureIntAtParent(class, prdPlnIt, dialogObj, mfail) \
        _ProductPlanClosureIntAtClass(class, TRUE, prdPlnIt, dialogObj, mfail)

#define QueryForChgAdmTaskBrw(browserItem, databases, resultBrwObjs, mfail) \
        _QueryForChgAdmTaskBrwAtClass(NULL, FALSE, browserItem, databases, resultBrwObjs, mfail)
#define QueryForChgAdmTaskBrwAtClass(class, browserItem, databases, resultBrwObjs, mfail) \
        _QueryForChgAdmTaskBrwAtClass(class, FALSE, browserItem, databases, resultBrwObjs, mfail)
#define QueryForChgAdmTaskBrwAtParent(class, browserItem, databases, resultBrwObjs, mfail) \
        _QueryForChgAdmTaskBrwAtClass(class, TRUE, browserItem, databases, resultBrwObjs, mfail)

#define QueryForChgAdminBrwD(className, mfail) \
        _QueryForChgAdminBrwD(className, FALSE, className, mfail)
#define QueryForChgAdminBrwDAtParent(_class, className, mfail) \
        _QueryForChgAdminBrwD(_class, TRUE, className, mfail)

#define QueryForReportsSCT(className, argsObj, chgObjs, mfail) \
        _QueryForReportsSCT(className, FALSE, className, argsObj, chgObjs, mfail)
#define QueryForReportsSCTAtParent(_class, className, argsObj, chgObjs, mfail) \
        _QueryForReportsSCT(_class, TRUE, className, argsObj, chgObjs, mfail)

#define ReviseIncorpPnt(incPntItem, updateDlgObj, mfail) \
        _ReviseIncorpPntAtClass(NULL, FALSE, incPntItem, updateDlgObj, mfail)
#define ReviseIncorpPntAtClass(class, incPntItem, updateDlgObj, mfail) \
        _ReviseIncorpPntAtClass(class, FALSE, incPntItem, updateDlgObj, mfail)
#define ReviseIncorpPntAtParent(class, incPntItem, updateDlgObj, mfail) \
        _ReviseIncorpPntAtClass(class, TRUE, incPntItem, updateDlgObj, mfail)

#define SetCmtdEffAttrs(pdpItem, mfail) \
        _SetCmtdEffAttrsAtClass(NULL, FALSE, pdpItem, mfail)
#define SetCmtdEffAttrsAtClass(class, pdpItem, mfail) \
        _SetCmtdEffAttrsAtClass(class, FALSE, pdpItem, mfail)
#define SetCmtdEffAttrsAtParent(class, pdpItem, mfail) \
        _SetCmtdEffAttrsAtClass(class, TRUE, pdpItem, mfail)

#define SetFastTrackPdpRevBrd(obj, procHist, msgProc, exitState, advComments, mfail) \
        _SetFastTrackPdpRevBrdAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define SetFastTrackPdpRevBrdAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _SetFastTrackPdpRevBrdAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define SetFastTrackPdpRevBrdAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _SetFastTrackPdpRevBrdAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define TransferAllToVault(itemObj, vault, failedObjs, mfail) \
        _TransferAllToVaultAtClass(NULL, FALSE, itemObj, vault, failedObjs, mfail)
#define TransferAllToVaultAtClass(class, itemObj, vault, failedObjs, mfail) \
        _TransferAllToVaultAtClass(class, FALSE, itemObj, vault, failedObjs, mfail)
#define TransferAllToVaultAtParent(class, itemObj, vault, failedObjs, mfail) \
        _TransferAllToVaultAtClass(class, TRUE, itemObj, vault, failedObjs, mfail)

#define UpdPlStrcAprDispRecurs(thisObj, mfail) \
        _UpdPlStrcAprDispRecursAtClass(NULL, FALSE, thisObj, mfail)
#define UpdPlStrcAprDispRecursAtClass(class, thisObj, mfail) \
        _UpdPlStrcAprDispRecursAtClass(class, FALSE, thisObj, mfail)
#define UpdPlStrcAprDispRecursAtParent(class, thisObj, mfail) \
        _UpdPlStrcAprDispRecursAtClass(class, TRUE, thisObj, mfail)

#define UpdPlStrcLCStateRecurs(thisObj, newState, exitState, advComments, mfail) \
        _UpdPlStrcLCStateRecursAtClass(NULL, FALSE, thisObj, newState, exitState, advComments, mfail)
#define UpdPlStrcLCStateRecursAtClass(class, thisObj, newState, exitState, advComments, mfail) \
        _UpdPlStrcLCStateRecursAtClass(class, FALSE, thisObj, newState, exitState, advComments, mfail)
#define UpdPlStrcLCStateRecursAtParent(class, thisObj, newState, exitState, advComments, mfail) \
        _UpdPlStrcLCStateRecursAtClass(class, TRUE, thisObj, newState, exitState, advComments, mfail)

#define UpdPlStrcStatusRecurs(thisObj, newStatus, exitState, advComments, mfail) \
        _UpdPlStrcStatusRecursAtClass(NULL, FALSE, thisObj, newStatus, exitState, advComments, mfail)
#define UpdPlStrcStatusRecursAtClass(class, thisObj, newStatus, exitState, advComments, mfail) \
        _UpdPlStrcStatusRecursAtClass(class, FALSE, thisObj, newStatus, exitState, advComments, mfail)
#define UpdPlStrcStatusRecursAtParent(class, thisObj, newStatus, exitState, advComments, mfail) \
        _UpdPlStrcStatusRecursAtClass(class, TRUE, thisObj, newStatus, exitState, advComments, mfail)

#define UpdPlnImpAprDispRecurs(thisObj, mfail) \
        _UpdPlnImpAprDispRecursAtClass(NULL, FALSE, thisObj, mfail)
#define UpdPlnImpAprDispRecursAtClass(class, thisObj, mfail) \
        _UpdPlnImpAprDispRecursAtClass(class, FALSE, thisObj, mfail)
#define UpdPlnImpAprDispRecursAtParent(class, thisObj, mfail) \
        _UpdPlnImpAprDispRecursAtClass(class, TRUE, thisObj, mfail)

#define UpdPlnImpLCStateRecurs(thisObj, newState, exitState, advComments, mfail) \
        _UpdPlnImpLCStateRecursAtClass(NULL, FALSE, thisObj, newState, exitState, advComments, mfail)
#define UpdPlnImpLCStateRecursAtClass(class, thisObj, newState, exitState, advComments, mfail) \
        _UpdPlnImpLCStateRecursAtClass(class, FALSE, thisObj, newState, exitState, advComments, mfail)
#define UpdPlnImpLCStateRecursAtParent(class, thisObj, newState, exitState, advComments, mfail) \
        _UpdPlnImpLCStateRecursAtClass(class, TRUE, thisObj, newState, exitState, advComments, mfail)

#define UpdPlnImpStatusRecurs(thisObj, newStatus, exitState, advComments, mfail) \
        _UpdPlnImpStatusRecursAtClass(NULL, FALSE, thisObj, newStatus, exitState, advComments, mfail)
#define UpdPlnImpStatusRecursAtClass(class, thisObj, newStatus, exitState, advComments, mfail) \
        _UpdPlnImpStatusRecursAtClass(class, FALSE, thisObj, newStatus, exitState, advComments, mfail)
#define UpdPlnImpStatusRecursAtParent(class, thisObj, newStatus, exitState, advComments, mfail) \
        _UpdPlnImpStatusRecursAtClass(class, TRUE, thisObj, newStatus, exitState, advComments, mfail)

#define UpdPrdPlnActCmpTime(obj, procHist, msgProc, exitState, advComments, mfail) \
        _UpdPrdPlnActCmpTimeAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define UpdPrdPlnActCmpTimeAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _UpdPrdPlnActCmpTimeAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define UpdPrdPlnActCmpTimeAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _UpdPrdPlnActCmpTimeAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define UpdStatusNStateForCls(thisObj, mfail) \
        _UpdStatusNStateForClsAtClass(NULL, FALSE, thisObj, mfail)
#define UpdStatusNStateForClsAtClass(class, thisObj, mfail) \
        _UpdStatusNStateForClsAtClass(class, FALSE, thisObj, mfail)
#define UpdStatusNStateForClsAtParent(class, thisObj, mfail) \
        _UpdStatusNStateForClsAtClass(class, TRUE, thisObj, mfail)

#define UpdateAdminForTasks(obj, procHist, msgProc, exitState, advComments, mfail) \
        _UpdateAdminForTasksAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define UpdateAdminForTasksAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _UpdateAdminForTasksAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define UpdateAdminForTasksAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _UpdateAdminForTasksAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define UpdateAnalystForTasks(obj, procHist, msgProc, exitState, advComments, mfail) \
        _UpdateAnalystForTasksAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define UpdateAnalystForTasksAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _UpdateAnalystForTasksAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define UpdateAnalystForTasksAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _UpdateAnalystForTasksAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define UpdateApprvdDisp(thisObj, mfail) \
        _UpdateApprvdDispAtClass(NULL, FALSE, thisObj, mfail)
#define UpdateApprvdDispAtClass(class, thisObj, mfail) \
        _UpdateApprvdDispAtClass(class, FALSE, thisObj, mfail)
#define UpdateApprvdDispAtParent(class, thisObj, mfail) \
        _UpdateApprvdDispAtClass(class, TRUE, thisObj, mfail)

#define UpdateLCState(thisObj, newState, mfail) \
        _UpdateLCStateAtClass(NULL, FALSE, thisObj, newState, mfail)
#define UpdateLCStateAtClass(class, thisObj, newState, mfail) \
        _UpdateLCStateAtClass(class, FALSE, thisObj, newState, mfail)
#define UpdateLCStateAtParent(class, thisObj, newState, mfail) \
        _UpdateLCStateAtClass(class, TRUE, thisObj, newState, mfail)

#define UpdateRequestorForTsks(obj, procHist, msgProc, exitState, advComments, mfail) \
        _UpdateRequestorForTsksAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define UpdateRequestorForTsksAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _UpdateRequestorForTsksAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define UpdateRequestorForTsksAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _UpdateRequestorForTsksAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define UpdateWbsStatus(thisObj, newStatus, mfail) \
        _UpdateWbsStatusAtClass(NULL, FALSE, thisObj, newStatus, mfail)
#define UpdateWbsStatusAtClass(class, thisObj, newStatus, mfail) \
        _UpdateWbsStatusAtClass(class, FALSE, thisObj, newStatus, mfail)
#define UpdateWbsStatusAtParent(class, thisObj, newStatus, mfail) \
        _UpdateWbsStatusAtClass(class, TRUE, thisObj, newStatus, mfail)

#define ValAffItmForCkoAffect(thisObj, relation, buildNewRelation, delOldRelation, mfail) \
        _ValAffItmForCkoAffectAtClass(NULL, FALSE, thisObj, relation, buildNewRelation, delOldRelation, mfail)
#define ValAffItmForCkoAffectAtClass(class, thisObj, relation, buildNewRelation, delOldRelation, mfail) \
        _ValAffItmForCkoAffectAtClass(class, FALSE, thisObj, relation, buildNewRelation, delOldRelation, mfail)
#define ValAffItmForCkoAffectAtParent(class, thisObj, relation, buildNewRelation, delOldRelation, mfail) \
        _ValAffItmForCkoAffectAtClass(class, TRUE, thisObj, relation, buildNewRelation, delOldRelation, mfail)

#define ValAffItmForCreAffect(thisObj, relation, mfail) \
        _ValAffItmForCreAffectAtClass(NULL, FALSE, thisObj, relation, mfail)
#define ValAffItmForCreAffectAtClass(class, thisObj, relation, mfail) \
        _ValAffItmForCreAffectAtClass(class, FALSE, thisObj, relation, mfail)
#define ValAffItmForCreAffectAtParent(class, thisObj, relation, mfail) \
        _ValAffItmForCreAffectAtClass(class, TRUE, thisObj, relation, mfail)

#define ValAffItmForDelAffect(thisObj, relation, mfail) \
        _ValAffItmForDelAffectAtClass(NULL, FALSE, thisObj, relation, mfail)
#define ValAffItmForDelAffectAtClass(class, thisObj, relation, mfail) \
        _ValAffItmForDelAffectAtClass(class, FALSE, thisObj, relation, mfail)
#define ValAffItmForDelAffectAtParent(class, thisObj, relation, mfail) \
        _ValAffItmForDelAffectAtClass(class, TRUE, thisObj, relation, mfail)

#define ValAffItmForModifyRel(thisObj, mfail) \
        _ValAffItmForModifyRelAtClass(NULL, FALSE, thisObj, mfail)
#define ValAffItmForModifyRelAtClass(class, thisObj, mfail) \
        _ValAffItmForModifyRelAtClass(class, FALSE, thisObj, mfail)
#define ValAffItmForModifyRelAtParent(class, thisObj, mfail) \
        _ValAffItmForModifyRelAtClass(class, TRUE, thisObj, mfail)

#define ValAffItmForRevAffect(thisObj, relation, buildNewRelation, delOldRelation, mfail) \
        _ValAffItmForRevAffectAtClass(NULL, FALSE, thisObj, relation, buildNewRelation, delOldRelation, mfail)
#define ValAffItmForRevAffectAtClass(class, thisObj, relation, buildNewRelation, delOldRelation, mfail) \
        _ValAffItmForRevAffectAtClass(class, FALSE, thisObj, relation, buildNewRelation, delOldRelation, mfail)
#define ValAffItmForRevAffectAtParent(class, thisObj, relation, buildNewRelation, delOldRelation, mfail) \
        _ValAffItmForRevAffectAtClass(class, TRUE, thisObj, relation, buildNewRelation, delOldRelation, mfail)

#define ValAuthoringForCreRel(prdPlnIt, relationName, mfail) \
        _ValAuthoringForCreRelAtClass(NULL, FALSE, prdPlnIt, relationName, mfail)
#define ValAuthoringForCreRelAtClass(class, prdPlnIt, relationName, mfail) \
        _ValAuthoringForCreRelAtClass(class, FALSE, prdPlnIt, relationName, mfail)
#define ValAuthoringForCreRelAtParent(class, prdPlnIt, relationName, mfail) \
        _ValAuthoringForCreRelAtClass(class, TRUE, prdPlnIt, relationName, mfail)

#define ValAuthoringForDelRel(prdPlnIt, relationName, mfail) \
        _ValAuthoringForDelRelAtClass(NULL, FALSE, prdPlnIt, relationName, mfail)
#define ValAuthoringForDelRelAtClass(class, prdPlnIt, relationName, mfail) \
        _ValAuthoringForDelRelAtClass(class, FALSE, prdPlnIt, relationName, mfail)
#define ValAuthoringForDelRelAtParent(class, prdPlnIt, relationName, mfail) \
        _ValAuthoringForDelRelAtClass(class, TRUE, prdPlnIt, relationName, mfail)

#define ValAuthoringForUpdRel(prdPlnIt, relationName, mfail) \
        _ValAuthoringForUpdRelAtClass(NULL, FALSE, prdPlnIt, relationName, mfail)
#define ValAuthoringForUpdRelAtClass(class, prdPlnIt, relationName, mfail) \
        _ValAuthoringForUpdRelAtClass(class, FALSE, prdPlnIt, relationName, mfail)
#define ValAuthoringForUpdRelAtParent(class, prdPlnIt, relationName, mfail) \
        _ValAuthoringForUpdRelAtClass(class, TRUE, prdPlnIt, relationName, mfail)

#define ValCdiForStateMachine(thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValCdiForStateMachineAtClass(NULL, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValCdiForStateMachineAtClass(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValCdiForStateMachineAtClass(class, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValCdiForStateMachineAtParent(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValCdiForStateMachineAtClass(class, TRUE, thisObj, dialogObj, refresh, badArgs, mfail)

#define ValChangeDispoItemRels(thisObj, dialogObj, mfail) \
        _ValChangeDispoItemRelsAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define ValChangeDispoItemRelsAtClass(class, thisObj, dialogObj, mfail) \
        _ValChangeDispoItemRelsAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define ValChangeDispoItemRelsAtParent(class, thisObj, dialogObj, mfail) \
        _ValChangeDispoItemRelsAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define ValChgTechDispItemRels(thisObj, dialogObj, mfail) \
        _ValChgTechDispItemRelsAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define ValChgTechDispItemRelsAtClass(class, thisObj, dialogObj, mfail) \
        _ValChgTechDispItemRelsAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define ValChgTechDispItemRelsAtParent(class, thisObj, dialogObj, mfail) \
        _ValChgTechDispItemRelsAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define ValClaForStateMachine(griItem, dialogObj, refresh, badArgs, mfail) \
        _ValClaForStateMachineAtClass(NULL, FALSE, griItem, dialogObj, refresh, badArgs, mfail)
#define ValClaForStateMachineAtClass(class, griItem, dialogObj, refresh, badArgs, mfail) \
        _ValClaForStateMachineAtClass(class, FALSE, griItem, dialogObj, refresh, badArgs, mfail)
#define ValClaForStateMachineAtParent(class, griItem, dialogObj, refresh, badArgs, mfail) \
        _ValClaForStateMachineAtClass(class, TRUE, griItem, dialogObj, refresh, badArgs, mfail)

#define ValClassifyChgItemRels(griItem, dialogObj, mfail) \
        _ValClassifyChgItemRelsAtClass(NULL, FALSE, griItem, dialogObj, mfail)
#define ValClassifyChgItemRelsAtClass(class, griItem, dialogObj, mfail) \
        _ValClassifyChgItemRelsAtClass(class, FALSE, griItem, dialogObj, mfail)
#define ValClassifyChgItemRelsAtParent(class, griItem, dialogObj, mfail) \
        _ValClassifyChgItemRelsAtClass(class, TRUE, griItem, dialogObj, mfail)

#define ValCsuItemRels(thisObj, dialogObj, mfail) \
        _ValCsuItemRelsAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define ValCsuItemRelsAtClass(class, thisObj, dialogObj, mfail) \
        _ValCsuItemRelsAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define ValCsuItemRelsAtParent(class, thisObj, dialogObj, mfail) \
        _ValCsuItemRelsAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define ValCtdForStateMachine(thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValCtdForStateMachineAtClass(NULL, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValCtdForStateMachineAtClass(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValCtdForStateMachineAtClass(class, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValCtdForStateMachineAtParent(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValCtdForStateMachineAtClass(class, TRUE, thisObj, dialogObj, refresh, badArgs, mfail)

#define ValDlgForCdiSet(originObj, originClassName, dlgObject, extraStr, extraObj, badArgs, mfail) \
        _ValDlgForCdiSetAtClass(NULL, FALSE, originObj, originClassName, dlgObject, extraStr, extraObj, badArgs, mfail)
#define ValDlgForCdiSetAtClass(class, originObj, originClassName, dlgObject, extraStr, extraObj, badArgs, mfail) \
        _ValDlgForCdiSetAtClass(class, FALSE, originObj, originClassName, dlgObject, extraStr, extraObj, badArgs, mfail)
#define ValDlgForCdiSetAtParent(class, originObj, originClassName, dlgObject, extraStr, extraObj, badArgs, mfail) \
        _ValDlgForCdiSetAtClass(class, TRUE, originObj, originClassName, dlgObject, extraStr, extraObj, badArgs, mfail)

#define ValDlgForCsuSet(originObj, originClassName, dlgObject, extraStr, extraObj, badArgs, mfail) \
        _ValDlgForCsuSetAtClass(NULL, FALSE, originObj, originClassName, dlgObject, extraStr, extraObj, badArgs, mfail)
#define ValDlgForCsuSetAtClass(class, originObj, originClassName, dlgObject, extraStr, extraObj, badArgs, mfail) \
        _ValDlgForCsuSetAtClass(class, FALSE, originObj, originClassName, dlgObject, extraStr, extraObj, badArgs, mfail)
#define ValDlgForCsuSetAtParent(class, originObj, originClassName, dlgObject, extraStr, extraObj, badArgs, mfail) \
        _ValDlgForCsuSetAtClass(class, TRUE, originObj, originClassName, dlgObject, extraStr, extraObj, badArgs, mfail)

#define ValDoChangeDispoItem(thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValDoChangeDispoItemAtClass(NULL, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValDoChangeDispoItemAtClass(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValDoChangeDispoItemAtClass(class, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValDoChangeDispoItemAtParent(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValDoChangeDispoItemAtClass(class, TRUE, thisObj, dialogObj, refresh, badArgs, mfail)

#define ValDoChangeStatusItem(thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValDoChangeStatusItemAtClass(NULL, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValDoChangeStatusItemAtClass(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValDoChangeStatusItemAtClass(class, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValDoChangeStatusItemAtParent(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValDoChangeStatusItemAtClass(class, TRUE, thisObj, dialogObj, refresh, badArgs, mfail)

#define ValDoChgTechDispItem(thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValDoChgTechDispItemAtClass(NULL, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValDoChgTechDispItemAtClass(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValDoChgTechDispItemAtClass(class, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValDoChgTechDispItemAtParent(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValDoChgTechDispItemAtClass(class, TRUE, thisObj, dialogObj, refresh, badArgs, mfail)

#define ValDoClassifyChgItem(griItem, dialogObj, refresh, badArgs, mfail) \
        _ValDoClassifyChgItemAtClass(NULL, FALSE, griItem, dialogObj, refresh, badArgs, mfail)
#define ValDoClassifyChgItemAtClass(class, griItem, dialogObj, refresh, badArgs, mfail) \
        _ValDoClassifyChgItemAtClass(class, FALSE, griItem, dialogObj, refresh, badArgs, mfail)
#define ValDoClassifyChgItemAtParent(class, griItem, dialogObj, refresh, badArgs, mfail) \
        _ValDoClassifyChgItemAtClass(class, TRUE, griItem, dialogObj, refresh, badArgs, mfail)

#define ValDoCloseProductPlan(thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValDoCloseProductPlanAtClass(NULL, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValDoCloseProductPlanAtClass(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValDoCloseProductPlanAtClass(class, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValDoCloseProductPlanAtParent(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValDoCloseProductPlanAtClass(class, TRUE, thisObj, dialogObj, refresh, badArgs, mfail)

#define ValDomainForCdi(thisObj, isLocal, mfail) \
        _ValDomainForCdiAtClass(NULL, FALSE, thisObj, isLocal, mfail)
#define ValDomainForCdiAtClass(class, thisObj, isLocal, mfail) \
        _ValDomainForCdiAtClass(class, FALSE, thisObj, isLocal, mfail)
#define ValDomainForCdiAtParent(class, thisObj, isLocal, mfail) \
        _ValDomainForCdiAtClass(class, TRUE, thisObj, isLocal, mfail)

#define ValDomainForCla(griItem, isLocal, mfail) \
        _ValDomainForClaAtClass(NULL, FALSE, griItem, isLocal, mfail)
#define ValDomainForClaAtClass(class, griItem, isLocal, mfail) \
        _ValDomainForClaAtClass(class, FALSE, griItem, isLocal, mfail)
#define ValDomainForClaAtParent(class, griItem, isLocal, mfail) \
        _ValDomainForClaAtClass(class, TRUE, griItem, isLocal, mfail)

#define ValDomainForCsu(thisObj, isLocal, mfail) \
        _ValDomainForCsuAtClass(NULL, FALSE, thisObj, isLocal, mfail)
#define ValDomainForCsuAtClass(class, thisObj, isLocal, mfail) \
        _ValDomainForCsuAtClass(class, FALSE, thisObj, isLocal, mfail)
#define ValDomainForCsuAtParent(class, thisObj, isLocal, mfail) \
        _ValDomainForCsuAtClass(class, TRUE, thisObj, isLocal, mfail)

#define ValDomainForCtd(thisObj, isLocal, mfail) \
        _ValDomainForCtdAtClass(NULL, FALSE, thisObj, isLocal, mfail)
#define ValDomainForCtdAtClass(class, thisObj, isLocal, mfail) \
        _ValDomainForCtdAtClass(class, FALSE, thisObj, isLocal, mfail)
#define ValDomainForCtdAtParent(class, thisObj, isLocal, mfail) \
        _ValDomainForCtdAtClass(class, TRUE, thisObj, isLocal, mfail)

#define ValDomainForPdpClosure(thisObj, isLocal, mfail) \
        _ValDomainForPdpClosureAtClass(NULL, FALSE, thisObj, isLocal, mfail)
#define ValDomainForPdpClosureAtClass(class, thisObj, isLocal, mfail) \
        _ValDomainForPdpClosureAtClass(class, FALSE, thisObj, isLocal, mfail)
#define ValDomainForPdpClosureAtParent(class, thisObj, isLocal, mfail) \
        _ValDomainForPdpClosureAtClass(class, TRUE, thisObj, isLocal, mfail)

#define ValEffectivityRange(className, startRange, endRange, isValid, mfail) \
        _ValEffectivityRange(className, FALSE, className, startRange, endRange, isValid, mfail)
#define ValEffectivityRangeAtParent(_class, className, startRange, endRange, isValid, mfail) \
        _ValEffectivityRange(_class, TRUE, className, startRange, endRange, isValid, mfail)

#define ValForAsgnChangeAdmExt(pdpItem, mfail) \
        _ValForAsgnChangeAdmExtAtClass(NULL, FALSE, pdpItem, mfail)
#define ValForAsgnChangeAdmExtAtClass(class, pdpItem, mfail) \
        _ValForAsgnChangeAdmExtAtClass(class, FALSE, pdpItem, mfail)
#define ValForAsgnChangeAdmExtAtParent(class, pdpItem, mfail) \
        _ValForAsgnChangeAdmExtAtClass(class, TRUE, pdpItem, mfail)

#define ValForAsgnOrignatorExt(pdpItem, mfail) \
        _ValForAsgnOrignatorExtAtClass(NULL, FALSE, pdpItem, mfail)
#define ValForAsgnOrignatorExtAtClass(class, pdpItem, mfail) \
        _ValForAsgnOrignatorExtAtClass(class, FALSE, pdpItem, mfail)
#define ValForAsgnOrignatorExtAtParent(class, pdpItem, mfail) \
        _ValForAsgnOrignatorExtAtClass(class, TRUE, pdpItem, mfail)

#define ValForAsgnRevBoardExt(pdpItem, mfail) \
        _ValForAsgnRevBoardExtAtClass(NULL, FALSE, pdpItem, mfail)
#define ValForAsgnRevBoardExtAtClass(class, pdpItem, mfail) \
        _ValForAsgnRevBoardExtAtClass(class, FALSE, pdpItem, mfail)
#define ValForAsgnRevBoardExtAtParent(class, pdpItem, mfail) \
        _ValForAsgnRevBoardExtAtClass(class, TRUE, pdpItem, mfail)

#define ValForAssignAnalyst(pdpItem, mfail) \
        _ValForAssignAnalystAtClass(NULL, FALSE, pdpItem, mfail)
#define ValForAssignAnalystAtClass(class, pdpItem, mfail) \
        _ValForAssignAnalystAtClass(class, FALSE, pdpItem, mfail)
#define ValForAssignAnalystAtParent(class, pdpItem, mfail) \
        _ValForAssignAnalystAtClass(class, TRUE, pdpItem, mfail)

#define ValForAssignAnalystExt(pdpItem, mfail) \
        _ValForAssignAnalystExtAtClass(NULL, FALSE, pdpItem, mfail)
#define ValForAssignAnalystExtAtClass(class, pdpItem, mfail) \
        _ValForAssignAnalystExtAtClass(class, FALSE, pdpItem, mfail)
#define ValForAssignAnalystExtAtParent(class, pdpItem, mfail) \
        _ValForAssignAnalystExtAtClass(class, TRUE, pdpItem, mfail)

#define ValForAssignChangeAdm(pdpItem, mfail) \
        _ValForAssignChangeAdmAtClass(NULL, FALSE, pdpItem, mfail)
#define ValForAssignChangeAdmAtClass(class, pdpItem, mfail) \
        _ValForAssignChangeAdmAtClass(class, FALSE, pdpItem, mfail)
#define ValForAssignChangeAdmAtParent(class, pdpItem, mfail) \
        _ValForAssignChangeAdmAtClass(class, TRUE, pdpItem, mfail)

#define ValForAssignOriginator(pdpItem, mfail) \
        _ValForAssignOriginatorAtClass(NULL, FALSE, pdpItem, mfail)
#define ValForAssignOriginatorAtClass(class, pdpItem, mfail) \
        _ValForAssignOriginatorAtClass(class, FALSE, pdpItem, mfail)
#define ValForAssignOriginatorAtParent(class, pdpItem, mfail) \
        _ValForAssignOriginatorAtClass(class, TRUE, pdpItem, mfail)

#define ValForAssignRevBoard(pdpItem, mfail) \
        _ValForAssignRevBoardAtClass(NULL, FALSE, pdpItem, mfail)
#define ValForAssignRevBoardAtClass(class, pdpItem, mfail) \
        _ValForAssignRevBoardAtClass(class, FALSE, pdpItem, mfail)
#define ValForAssignRevBoardAtParent(class, pdpItem, mfail) \
        _ValForAssignRevBoardAtClass(class, TRUE, pdpItem, mfail)

#define ValForChangeDispoExt(pdpItem, mfail) \
        _ValForChangeDispoExtAtClass(NULL, FALSE, pdpItem, mfail)
#define ValForChangeDispoExtAtClass(class, pdpItem, mfail) \
        _ValForChangeDispoExtAtClass(class, FALSE, pdpItem, mfail)
#define ValForChangeDispoExtAtParent(class, pdpItem, mfail) \
        _ValForChangeDispoExtAtClass(class, TRUE, pdpItem, mfail)

#define ValForClassifyChgExt(griItem, mfail) \
        _ValForClassifyChgExtAtClass(NULL, FALSE, griItem, mfail)
#define ValForClassifyChgExtAtClass(class, griItem, mfail) \
        _ValForClassifyChgExtAtClass(class, FALSE, griItem, mfail)
#define ValForClassifyChgExtAtParent(class, griItem, mfail) \
        _ValForClassifyChgExtAtClass(class, TRUE, griItem, mfail)

#define ValForCloseTaskExt(taskItem, mfail) \
        _ValForCloseTaskExtAtClass(NULL, FALSE, taskItem, mfail)
#define ValForCloseTaskExtAtClass(class, taskItem, mfail) \
        _ValForCloseTaskExtAtClass(class, FALSE, taskItem, mfail)
#define ValForCloseTaskExtAtParent(class, taskItem, mfail) \
        _ValForCloseTaskExtAtClass(class, TRUE, taskItem, mfail)

#define ValForDelPrdPlnChild(childObj, mfail) \
        _ValForDelPrdPlnChildAtClass(NULL, FALSE, childObj, mfail)
#define ValForDelPrdPlnChildAtClass(class, childObj, mfail) \
        _ValForDelPrdPlnChildAtClass(class, FALSE, childObj, mfail)
#define ValForDelPrdPlnChildAtParent(class, childObj, mfail) \
        _ValForDelPrdPlnChildAtClass(class, TRUE, childObj, mfail)

#define ValForDeleteAllRevs(ItemMstrObj, recurSetPtr, mfail) \
        _ValForDeleteAllRevsAtClass(NULL, FALSE, ItemMstrObj, recurSetPtr, mfail)
#define ValForDeleteAllRevsAtClass(class, ItemMstrObj, recurSetPtr, mfail) \
        _ValForDeleteAllRevsAtClass(class, FALSE, ItemMstrObj, recurSetPtr, mfail)
#define ValForDeleteAllRevsAtParent(class, ItemMstrObj, recurSetPtr, mfail) \
        _ValForDeleteAllRevsAtClass(class, TRUE, ItemMstrObj, recurSetPtr, mfail)

#define ValForPdpClosureExt(pdpItem, mfail) \
        _ValForPdpClosureExtAtClass(NULL, FALSE, pdpItem, mfail)
#define ValForPdpClosureExtAtClass(class, pdpItem, mfail) \
        _ValForPdpClosureExtAtClass(class, FALSE, pdpItem, mfail)
#define ValForPdpClosureExtAtParent(class, pdpItem, mfail) \
        _ValForPdpClosureExtAtClass(class, TRUE, pdpItem, mfail)

#define ValForSpfCommittedIPEx(thisObj, mfail) \
        _ValForSpfCommittedIPExAtClass(NULL, FALSE, thisObj, mfail)
#define ValForSpfCommittedIPExAtClass(class, thisObj, mfail) \
        _ValForSpfCommittedIPExAtClass(class, FALSE, thisObj, mfail)
#define ValForSpfCommittedIPExAtParent(class, thisObj, mfail) \
        _ValForSpfCommittedIPExAtClass(class, TRUE, thisObj, mfail)

#define ValIPMrForCkoIncorpR(incMstr, prdPlnItemSet, incRSet, mfail) \
        _ValIPMrForCkoIncorpRAtClass(NULL, FALSE, incMstr, prdPlnItemSet, incRSet, mfail)
#define ValIPMrForCkoIncorpRAtClass(class, incMstr, prdPlnItemSet, incRSet, mfail) \
        _ValIPMrForCkoIncorpRAtClass(class, FALSE, incMstr, prdPlnItemSet, incRSet, mfail)
#define ValIPMrForCkoIncorpRAtParent(class, incMstr, prdPlnItemSet, incRSet, mfail) \
        _ValIPMrForCkoIncorpRAtClass(class, TRUE, incMstr, prdPlnItemSet, incRSet, mfail)

#define ValIPMrForCreIncorpR(incMstr, relObj, mfail) \
        _ValIPMrForCreIncorpRAtClass(NULL, FALSE, incMstr, relObj, mfail)
#define ValIPMrForCreIncorpRAtClass(class, incMstr, relObj, mfail) \
        _ValIPMrForCreIncorpRAtClass(class, FALSE, incMstr, relObj, mfail)
#define ValIPMrForCreIncorpRAtParent(class, incMstr, relObj, mfail) \
        _ValIPMrForCreIncorpRAtClass(class, TRUE, incMstr, relObj, mfail)

#define ValIPMrForDelIncorpR(incMstr, relObj, mfail) \
        _ValIPMrForDelIncorpRAtClass(NULL, FALSE, incMstr, relObj, mfail)
#define ValIPMrForDelIncorpRAtClass(class, incMstr, relObj, mfail) \
        _ValIPMrForDelIncorpRAtClass(class, FALSE, incMstr, relObj, mfail)
#define ValIPMrForDelIncorpRAtParent(class, incMstr, relObj, mfail) \
        _ValIPMrForDelIncorpRAtClass(class, TRUE, incMstr, relObj, mfail)

#define ValIPMrForRevIncorpR(incMstr, prdPlnItemSet, incRSet, mfail) \
        _ValIPMrForRevIncorpRAtClass(NULL, FALSE, incMstr, prdPlnItemSet, incRSet, mfail)
#define ValIPMrForRevIncorpRAtClass(class, incMstr, prdPlnItemSet, incRSet, mfail) \
        _ValIPMrForRevIncorpRAtClass(class, FALSE, incMstr, prdPlnItemSet, incRSet, mfail)
#define ValIPMrForRevIncorpRAtParent(class, incMstr, prdPlnItemSet, incRSet, mfail) \
        _ValIPMrForRevIncorpRAtClass(class, TRUE, incMstr, prdPlnItemSet, incRSet, mfail)

#define ValIfRelatedItmsInVlt(pdpItem, itmObjSet, val_errors, inVault, mfail) \
        _ValIfRelatedItmsInVltAtClass(NULL, FALSE, pdpItem, itmObjSet, val_errors, inVault, mfail)
#define ValIfRelatedItmsInVltAtClass(class, pdpItem, itmObjSet, val_errors, inVault, mfail) \
        _ValIfRelatedItmsInVltAtClass(class, FALSE, pdpItem, itmObjSet, val_errors, inVault, mfail)
#define ValIfRelatedItmsInVltAtParent(class, pdpItem, itmObjSet, val_errors, inVault, mfail) \
        _ValIfRelatedItmsInVltAtClass(class, TRUE, pdpItem, itmObjSet, val_errors, inVault, mfail)

#define ValImplPdpParentForCls(thisObj, okToClose, mfail) \
        _ValImplPdpParentForClsAtClass(NULL, FALSE, thisObj, okToClose, mfail)
#define ValImplPdpParentForClsAtClass(class, thisObj, okToClose, mfail) \
        _ValImplPdpParentForClsAtClass(class, FALSE, thisObj, okToClose, mfail)
#define ValImplPdpParentForClsAtParent(class, thisObj, okToClose, mfail) \
        _ValImplPdpParentForClsAtClass(class, TRUE, thisObj, okToClose, mfail)

#define ValPPlnMrForCkoImpRel(prdPlnMstr, prdPlnItemSet, pPlnImpSet, mfail) \
        _ValPPlnMrForCkoImpRelAtClass(NULL, FALSE, prdPlnMstr, prdPlnItemSet, pPlnImpSet, mfail)
#define ValPPlnMrForCkoImpRelAtClass(class, prdPlnMstr, prdPlnItemSet, pPlnImpSet, mfail) \
        _ValPPlnMrForCkoImpRelAtClass(class, FALSE, prdPlnMstr, prdPlnItemSet, pPlnImpSet, mfail)
#define ValPPlnMrForCkoImpRelAtParent(class, prdPlnMstr, prdPlnItemSet, pPlnImpSet, mfail) \
        _ValPPlnMrForCkoImpRelAtClass(class, TRUE, prdPlnMstr, prdPlnItemSet, pPlnImpSet, mfail)

#define ValPPlnMrForCreImpRel(prdPlnMstr, relObj, mfail) \
        _ValPPlnMrForCreImpRelAtClass(NULL, FALSE, prdPlnMstr, relObj, mfail)
#define ValPPlnMrForCreImpRelAtClass(class, prdPlnMstr, relObj, mfail) \
        _ValPPlnMrForCreImpRelAtClass(class, FALSE, prdPlnMstr, relObj, mfail)
#define ValPPlnMrForCreImpRelAtParent(class, prdPlnMstr, relObj, mfail) \
        _ValPPlnMrForCreImpRelAtClass(class, TRUE, prdPlnMstr, relObj, mfail)

#define ValPPlnMrForDelImpRel(prdPlnMstr, relObj, mfail) \
        _ValPPlnMrForDelImpRelAtClass(NULL, FALSE, prdPlnMstr, relObj, mfail)
#define ValPPlnMrForDelImpRelAtClass(class, prdPlnMstr, relObj, mfail) \
        _ValPPlnMrForDelImpRelAtClass(class, FALSE, prdPlnMstr, relObj, mfail)
#define ValPPlnMrForDelImpRelAtParent(class, prdPlnMstr, relObj, mfail) \
        _ValPPlnMrForDelImpRelAtClass(class, TRUE, prdPlnMstr, relObj, mfail)

#define ValPPlnMrForDelPpsRel(prdPlnMstr, relObj, mfail) \
        _ValPPlnMrForDelPpsRelAtClass(NULL, FALSE, prdPlnMstr, relObj, mfail)
#define ValPPlnMrForDelPpsRelAtClass(class, prdPlnMstr, relObj, mfail) \
        _ValPPlnMrForDelPpsRelAtClass(class, FALSE, prdPlnMstr, relObj, mfail)
#define ValPPlnMrForDelPpsRelAtParent(class, prdPlnMstr, relObj, mfail) \
        _ValPPlnMrForDelPpsRelAtClass(class, TRUE, prdPlnMstr, relObj, mfail)

#define ValPPlnMrForRevImpRel(prdPlnMstr, prdPlnItemSet, pPlnImpSet, mfail) \
        _ValPPlnMrForRevImpRelAtClass(NULL, FALSE, prdPlnMstr, prdPlnItemSet, pPlnImpSet, mfail)
#define ValPPlnMrForRevImpRelAtClass(class, prdPlnMstr, prdPlnItemSet, pPlnImpSet, mfail) \
        _ValPPlnMrForRevImpRelAtClass(class, FALSE, prdPlnMstr, prdPlnItemSet, pPlnImpSet, mfail)
#define ValPPlnMrForRevImpRelAtParent(class, prdPlnMstr, prdPlnItemSet, pPlnImpSet, mfail) \
        _ValPPlnMrForRevImpRelAtClass(class, TRUE, prdPlnMstr, prdPlnItemSet, pPlnImpSet, mfail)

#define ValPdpClosureRels(thisObj, dialogObj, mfail) \
        _ValPdpClosureRelsAtClass(NULL, FALSE, thisObj, dialogObj, mfail)
#define ValPdpClosureRelsAtClass(class, thisObj, dialogObj, mfail) \
        _ValPdpClosureRelsAtClass(class, FALSE, thisObj, dialogObj, mfail)
#define ValPdpClosureRelsAtParent(class, thisObj, dialogObj, mfail) \
        _ValPdpClosureRelsAtClass(class, TRUE, thisObj, dialogObj, mfail)

#define ValPdpForCancelExt(thisObj, mfail) \
        _ValPdpForCancelExtAtClass(NULL, FALSE, thisObj, mfail)
#define ValPdpForCancelExtAtClass(class, thisObj, mfail) \
        _ValPdpForCancelExtAtClass(class, FALSE, thisObj, mfail)
#define ValPdpForCancelExtAtParent(class, thisObj, mfail) \
        _ValPdpForCancelExtAtClass(class, TRUE, thisObj, mfail)

#define ValPdpForModifyIncorpR(pdpItem, relObj, mfail) \
        _ValPdpForModifyIncorpRAtClass(NULL, FALSE, pdpItem, relObj, mfail)
#define ValPdpForModifyIncorpRAtClass(class, pdpItem, relObj, mfail) \
        _ValPdpForModifyIncorpRAtClass(class, FALSE, pdpItem, relObj, mfail)
#define ValPdpForModifyIncorpRAtParent(class, pdpItem, relObj, mfail) \
        _ValPdpForModifyIncorpRAtClass(class, TRUE, pdpItem, relObj, mfail)

#define ValPdpForSuspendExt(thisObj, mfail) \
        _ValPdpForSuspendExtAtClass(NULL, FALSE, thisObj, mfail)
#define ValPdpForSuspendExtAtClass(class, thisObj, mfail) \
        _ValPdpForSuspendExtAtClass(class, FALSE, thisObj, mfail)
#define ValPdpForSuspendExtAtParent(class, thisObj, mfail) \
        _ValPdpForSuspendExtAtClass(class, TRUE, thisObj, mfail)

#define ValPrdPlnForCreAffect(pdpItem, relation, mfail) \
        _ValPrdPlnForCreAffectAtClass(NULL, FALSE, pdpItem, relation, mfail)
#define ValPrdPlnForCreAffectAtClass(class, pdpItem, relation, mfail) \
        _ValPrdPlnForCreAffectAtClass(class, FALSE, pdpItem, relation, mfail)
#define ValPrdPlnForCreAffectAtParent(class, pdpItem, relation, mfail) \
        _ValPrdPlnForCreAffectAtClass(class, TRUE, pdpItem, relation, mfail)

#define ValPrdPlnForCreImpRel(pdpItem, relObj, mfail) \
        _ValPrdPlnForCreImpRelAtClass(NULL, FALSE, pdpItem, relObj, mfail)
#define ValPrdPlnForCreImpRelAtClass(class, pdpItem, relObj, mfail) \
        _ValPrdPlnForCreImpRelAtClass(class, FALSE, pdpItem, relObj, mfail)
#define ValPrdPlnForCreImpRelAtParent(class, pdpItem, relObj, mfail) \
        _ValPrdPlnForCreImpRelAtClass(class, TRUE, pdpItem, relObj, mfail)

#define ValPrdPlnForCreIncorpR(pdpItem, relObj, mfail) \
        _ValPrdPlnForCreIncorpRAtClass(NULL, FALSE, pdpItem, relObj, mfail)
#define ValPrdPlnForCreIncorpRAtClass(class, pdpItem, relObj, mfail) \
        _ValPrdPlnForCreIncorpRAtClass(class, FALSE, pdpItem, relObj, mfail)
#define ValPrdPlnForCreIncorpRAtParent(class, pdpItem, relObj, mfail) \
        _ValPrdPlnForCreIncorpRAtClass(class, TRUE, pdpItem, relObj, mfail)

#define ValPrdPlnForCrePpsRel(pdpItem, relObj, mfail) \
        _ValPrdPlnForCrePpsRelAtClass(NULL, FALSE, pdpItem, relObj, mfail)
#define ValPrdPlnForCrePpsRelAtClass(class, pdpItem, relObj, mfail) \
        _ValPrdPlnForCrePpsRelAtClass(class, FALSE, pdpItem, relObj, mfail)
#define ValPrdPlnForCrePpsRelAtParent(class, pdpItem, relObj, mfail) \
        _ValPrdPlnForCrePpsRelAtClass(class, TRUE, pdpItem, relObj, mfail)

#define ValPrdPlnForCstImpRel(pdpItem, relObjSet, otherSideObjSet, mfail) \
        _ValPrdPlnForCstImpRelAtClass(NULL, FALSE, pdpItem, relObjSet, otherSideObjSet, mfail)
#define ValPrdPlnForCstImpRelAtClass(class, pdpItem, relObjSet, otherSideObjSet, mfail) \
        _ValPrdPlnForCstImpRelAtClass(class, FALSE, pdpItem, relObjSet, otherSideObjSet, mfail)
#define ValPrdPlnForCstImpRelAtParent(class, pdpItem, relObjSet, otherSideObjSet, mfail) \
        _ValPrdPlnForCstImpRelAtClass(class, TRUE, pdpItem, relObjSet, otherSideObjSet, mfail)

#define ValPrdPlnForCstIncorpR(pdpItem, incObj, mfail) \
        _ValPrdPlnForCstIncorpRAtClass(NULL, FALSE, pdpItem, incObj, mfail)
#define ValPrdPlnForCstIncorpRAtClass(class, pdpItem, incObj, mfail) \
        _ValPrdPlnForCstIncorpRAtClass(class, FALSE, pdpItem, incObj, mfail)
#define ValPrdPlnForCstIncorpRAtParent(class, pdpItem, incObj, mfail) \
        _ValPrdPlnForCstIncorpRAtClass(class, TRUE, pdpItem, incObj, mfail)

#define ValPrdPlnForDelAffect(pdpItem, relation, mfail) \
        _ValPrdPlnForDelAffectAtClass(NULL, FALSE, pdpItem, relation, mfail)
#define ValPrdPlnForDelAffectAtClass(class, pdpItem, relation, mfail) \
        _ValPrdPlnForDelAffectAtClass(class, FALSE, pdpItem, relation, mfail)
#define ValPrdPlnForDelAffectAtParent(class, pdpItem, relation, mfail) \
        _ValPrdPlnForDelAffectAtClass(class, TRUE, pdpItem, relation, mfail)

#define ValPrdPlnForDelImpRel(pdpItem, relObj, mfail) \
        _ValPrdPlnForDelImpRelAtClass(NULL, FALSE, pdpItem, relObj, mfail)
#define ValPrdPlnForDelImpRelAtClass(class, pdpItem, relObj, mfail) \
        _ValPrdPlnForDelImpRelAtClass(class, FALSE, pdpItem, relObj, mfail)
#define ValPrdPlnForDelImpRelAtParent(class, pdpItem, relObj, mfail) \
        _ValPrdPlnForDelImpRelAtClass(class, TRUE, pdpItem, relObj, mfail)

#define ValPrdPlnForDelIncorpR(pdpItem, relObj, mfail) \
        _ValPrdPlnForDelIncorpRAtClass(NULL, FALSE, pdpItem, relObj, mfail)
#define ValPrdPlnForDelIncorpRAtClass(class, pdpItem, relObj, mfail) \
        _ValPrdPlnForDelIncorpRAtClass(class, FALSE, pdpItem, relObj, mfail)
#define ValPrdPlnForDelIncorpRAtParent(class, pdpItem, relObj, mfail) \
        _ValPrdPlnForDelIncorpRAtClass(class, TRUE, pdpItem, relObj, mfail)

#define ValPrdPlnForDelPpsRel(pdpItem, relObj, mfail) \
        _ValPrdPlnForDelPpsRelAtClass(NULL, FALSE, pdpItem, relObj, mfail)
#define ValPrdPlnForDelPpsRelAtClass(class, pdpItem, relObj, mfail) \
        _ValPrdPlnForDelPpsRelAtClass(class, FALSE, pdpItem, relObj, mfail)
#define ValPrdPlnForDelPpsRelAtParent(class, pdpItem, relObj, mfail) \
        _ValPrdPlnForDelPpsRelAtClass(class, TRUE, pdpItem, relObj, mfail)

#define ValPrdPlnForModifyRel(thisObj, mfail) \
        _ValPrdPlnForModifyRelAtClass(NULL, FALSE, thisObj, mfail)
#define ValPrdPlnForModifyRelAtClass(class, thisObj, mfail) \
        _ValPrdPlnForModifyRelAtClass(class, FALSE, thisObj, mfail)
#define ValPrdPlnForModifyRelAtParent(class, thisObj, mfail) \
        _ValPrdPlnForModifyRelAtClass(class, TRUE, thisObj, mfail)

#define ValPrdPlnForUpdAffect(pdpItem, affectsRel, mfail) \
        _ValPrdPlnForUpdAffectAtClass(NULL, FALSE, pdpItem, affectsRel, mfail)
#define ValPrdPlnForUpdAffectAtClass(class, pdpItem, affectsRel, mfail) \
        _ValPrdPlnForUpdAffectAtClass(class, FALSE, pdpItem, affectsRel, mfail)
#define ValPrdPlnForUpdAffectAtParent(class, pdpItem, affectsRel, mfail) \
        _ValPrdPlnForUpdAffectAtClass(class, TRUE, pdpItem, affectsRel, mfail)

#define ValProdPlanForCreRefI(pdpItem, referenceRel, mfail) \
        _ValProdPlanForCreRefIAtClass(NULL, FALSE, pdpItem, referenceRel, mfail)
#define ValProdPlanForCreRefIAtClass(class, pdpItem, referenceRel, mfail) \
        _ValProdPlanForCreRefIAtClass(class, FALSE, pdpItem, referenceRel, mfail)
#define ValProdPlanForCreRefIAtParent(class, pdpItem, referenceRel, mfail) \
        _ValProdPlanForCreRefIAtClass(class, TRUE, pdpItem, referenceRel, mfail)

#define ValProdPlanForCreSupI(pdpItem, supportRel, mfail) \
        _ValProdPlanForCreSupIAtClass(NULL, FALSE, pdpItem, supportRel, mfail)
#define ValProdPlanForCreSupIAtClass(class, pdpItem, supportRel, mfail) \
        _ValProdPlanForCreSupIAtClass(class, FALSE, pdpItem, supportRel, mfail)
#define ValProdPlanForCreSupIAtParent(class, pdpItem, supportRel, mfail) \
        _ValProdPlanForCreSupIAtClass(class, TRUE, pdpItem, supportRel, mfail)

#define ValProdPlanForDelRefI(pdpItem, referenceRel, mfail) \
        _ValProdPlanForDelRefIAtClass(NULL, FALSE, pdpItem, referenceRel, mfail)
#define ValProdPlanForDelRefIAtClass(class, pdpItem, referenceRel, mfail) \
        _ValProdPlanForDelRefIAtClass(class, FALSE, pdpItem, referenceRel, mfail)
#define ValProdPlanForDelRefIAtParent(class, pdpItem, referenceRel, mfail) \
        _ValProdPlanForDelRefIAtClass(class, TRUE, pdpItem, referenceRel, mfail)

#define ValProdPlanForDelSupI(pdpItem, supportRel, mfail) \
        _ValProdPlanForDelSupIAtClass(NULL, FALSE, pdpItem, supportRel, mfail)
#define ValProdPlanForDelSupIAtClass(class, pdpItem, supportRel, mfail) \
        _ValProdPlanForDelSupIAtClass(class, FALSE, pdpItem, supportRel, mfail)
#define ValProdPlanForDelSupIAtParent(class, pdpItem, supportRel, mfail) \
        _ValProdPlanForDelSupIAtClass(class, TRUE, pdpItem, supportRel, mfail)

#define ValRefItemForCreRefI(referenceItem, referenceRel, mfail) \
        _ValRefItemForCreRefIAtClass(NULL, FALSE, referenceItem, referenceRel, mfail)
#define ValRefItemForCreRefIAtClass(class, referenceItem, referenceRel, mfail) \
        _ValRefItemForCreRefIAtClass(class, FALSE, referenceItem, referenceRel, mfail)
#define ValRefItemForCreRefIAtParent(class, referenceItem, referenceRel, mfail) \
        _ValRefItemForCreRefIAtClass(class, TRUE, referenceItem, referenceRel, mfail)

#define ValRefItemForDelRefI(referenceItem, referenceRel, mfail) \
        _ValRefItemForDelRefIAtClass(NULL, FALSE, referenceItem, referenceRel, mfail)
#define ValRefItemForDelRefIAtClass(class, referenceItem, referenceRel, mfail) \
        _ValRefItemForDelRefIAtClass(class, FALSE, referenceItem, referenceRel, mfail)
#define ValRefItemForDelRefIAtParent(class, referenceItem, referenceRel, mfail) \
        _ValRefItemForDelRefIAtClass(class, TRUE, referenceItem, referenceRel, mfail)

#define ValRelForChangeDispo(pdpItem, dialogObj, itemObj, mfail) \
        _ValRelForChangeDispoAtClass(NULL, FALSE, pdpItem, dialogObj, itemObj, mfail)
#define ValRelForChangeDispoAtClass(class, pdpItem, dialogObj, itemObj, mfail) \
        _ValRelForChangeDispoAtClass(class, FALSE, pdpItem, dialogObj, itemObj, mfail)
#define ValRelForChangeDispoAtParent(class, pdpItem, dialogObj, itemObj, mfail) \
        _ValRelForChangeDispoAtClass(class, TRUE, pdpItem, dialogObj, itemObj, mfail)

#define ValRelForChangeStatus(pdpItem, dialogObj, itemObj, mfail) \
        _ValRelForChangeStatusAtClass(NULL, FALSE, pdpItem, dialogObj, itemObj, mfail)
#define ValRelForChangeStatusAtClass(class, pdpItem, dialogObj, itemObj, mfail) \
        _ValRelForChangeStatusAtClass(class, FALSE, pdpItem, dialogObj, itemObj, mfail)
#define ValRelForChangeStatusAtParent(class, pdpItem, dialogObj, itemObj, mfail) \
        _ValRelForChangeStatusAtClass(class, TRUE, pdpItem, dialogObj, itemObj, mfail)

#define ValRelForChgTechDisp(pdpItem, dialogObj, itemObj, mfail) \
        _ValRelForChgTechDispAtClass(NULL, FALSE, pdpItem, dialogObj, itemObj, mfail)
#define ValRelForChgTechDispAtClass(class, pdpItem, dialogObj, itemObj, mfail) \
        _ValRelForChgTechDispAtClass(class, FALSE, pdpItem, dialogObj, itemObj, mfail)
#define ValRelForChgTechDispAtParent(class, pdpItem, dialogObj, itemObj, mfail) \
        _ValRelForChgTechDispAtClass(class, TRUE, pdpItem, dialogObj, itemObj, mfail)

#define ValRelForClassifyChg(relItem, dialogObj, itemObj, mfail) \
        _ValRelForClassifyChgAtClass(NULL, FALSE, relItem, dialogObj, itemObj, mfail)
#define ValRelForClassifyChgAtClass(class, relItem, dialogObj, itemObj, mfail) \
        _ValRelForClassifyChgAtClass(class, FALSE, relItem, dialogObj, itemObj, mfail)
#define ValRelForClassifyChgAtParent(class, relItem, dialogObj, itemObj, mfail) \
        _ValRelForClassifyChgAtClass(class, TRUE, relItem, dialogObj, itemObj, mfail)

#define ValRelForPdpClosure(relObj, dialogObj, pdpItem, mfail) \
        _ValRelForPdpClosureAtClass(NULL, FALSE, relObj, dialogObj, pdpItem, mfail)
#define ValRelForPdpClosureAtClass(class, relObj, dialogObj, pdpItem, mfail) \
        _ValRelForPdpClosureAtClass(class, FALSE, relObj, dialogObj, pdpItem, mfail)
#define ValRelForPdpClosureAtParent(class, relObj, dialogObj, pdpItem, mfail) \
        _ValRelForPdpClosureAtClass(class, TRUE, relObj, dialogObj, pdpItem, mfail)

#define ValReviseForChange(itemToRevise, changeItem, mfail) \
        _ValReviseForChangeAtClass(NULL, FALSE, itemToRevise, changeItem, mfail)
#define ValReviseForChangeAtClass(class, itemToRevise, changeItem, mfail) \
        _ValReviseForChangeAtClass(class, FALSE, itemToRevise, changeItem, mfail)
#define ValReviseForChangeAtParent(class, itemToRevise, changeItem, mfail) \
        _ValReviseForChangeAtClass(class, TRUE, itemToRevise, changeItem, mfail)

#define ValReviseIncorpPntExt(incPntItem, mfail) \
        _ValReviseIncorpPntExtAtClass(NULL, FALSE, incPntItem, mfail)
#define ValReviseIncorpPntExtAtClass(class, incPntItem, mfail) \
        _ValReviseIncorpPntExtAtClass(class, FALSE, incPntItem, mfail)
#define ValReviseIncorpPntExtAtParent(class, incPntItem, mfail) \
        _ValReviseIncorpPntExtAtClass(class, TRUE, incPntItem, mfail)

#define ValRsltsItForCstRslt(resultsItem, resultRelObj, prdPlnIt, mfail) \
        _ValRsltsItForCstRsltAtClass(NULL, FALSE, resultsItem, resultRelObj, prdPlnIt, mfail)
#define ValRsltsItForCstRsltAtClass(class, resultsItem, resultRelObj, prdPlnIt, mfail) \
        _ValRsltsItForCstRsltAtClass(class, FALSE, resultsItem, resultRelObj, prdPlnIt, mfail)
#define ValRsltsItForCstRsltAtParent(class, resultsItem, resultRelObj, prdPlnIt, mfail) \
        _ValRsltsItForCstRsltAtClass(class, TRUE, resultsItem, resultRelObj, prdPlnIt, mfail)

#define ValSetForCdiPost(originClassName, passedObjects, failedObjects, mfail) \
        _ValSetForCdiPost(originClassName, FALSE, originClassName, passedObjects, failedObjects, mfail)
#define ValSetForCdiPostAtParent(_class, originClassName, passedObjects, failedObjects, mfail) \
        _ValSetForCdiPost(_class, TRUE, originClassName, passedObjects, failedObjects, mfail)

#define ValSetForCdiPre(originClassName, originObjects, mfail) \
        _ValSetForCdiPre(originClassName, FALSE, originClassName, originObjects, mfail)
#define ValSetForCdiPreAtParent(_class, originClassName, originObjects, mfail) \
        _ValSetForCdiPre(_class, TRUE, originClassName, originObjects, mfail)

#define ValSetForChangeDispo(originClassName, passedObjects, failedObjects, extraStr, extraObj, mfail) \
        _ValSetForChangeDispo(originClassName, FALSE, originClassName, passedObjects, failedObjects, extraStr, extraObj, mfail)
#define ValSetForChangeDispoAtParent(_class, originClassName, passedObjects, failedObjects, extraStr, extraObj, mfail) \
        _ValSetForChangeDispo(_class, TRUE, originClassName, passedObjects, failedObjects, extraStr, extraObj, mfail)

#define ValSetForChangeStatus(originClassName, passedObjects, failedObjects, extraStr, extraObj, mfail) \
        _ValSetForChangeStatus(originClassName, FALSE, originClassName, passedObjects, failedObjects, extraStr, extraObj, mfail)
#define ValSetForChangeStatusAtParent(_class, originClassName, passedObjects, failedObjects, extraStr, extraObj, mfail) \
        _ValSetForChangeStatus(_class, TRUE, originClassName, passedObjects, failedObjects, extraStr, extraObj, mfail)

#define ValSetForCsuPost(originClassName, passedObjects, failedObjects, mfail) \
        _ValSetForCsuPost(originClassName, FALSE, originClassName, passedObjects, failedObjects, mfail)
#define ValSetForCsuPostAtParent(_class, originClassName, passedObjects, failedObjects, mfail) \
        _ValSetForCsuPost(_class, TRUE, originClassName, passedObjects, failedObjects, mfail)

#define ValSetForCsuPre(originClassName, originObjects, mfail) \
        _ValSetForCsuPre(originClassName, FALSE, originClassName, originObjects, mfail)
#define ValSetForCsuPreAtParent(_class, originClassName, originObjects, mfail) \
        _ValSetForCsuPre(_class, TRUE, originClassName, originObjects, mfail)

#define ValSupItemForCreSupI(supportItem, supportRel, mfail) \
        _ValSupItemForCreSupIAtClass(NULL, FALSE, supportItem, supportRel, mfail)
#define ValSupItemForCreSupIAtClass(class, supportItem, supportRel, mfail) \
        _ValSupItemForCreSupIAtClass(class, FALSE, supportItem, supportRel, mfail)
#define ValSupItemForCreSupIAtParent(class, supportItem, supportRel, mfail) \
        _ValSupItemForCreSupIAtClass(class, TRUE, supportItem, supportRel, mfail)

#define ValSupItemForDelSupI(supportItem, supportRel, mfail) \
        _ValSupItemForDelSupIAtClass(NULL, FALSE, supportItem, supportRel, mfail)
#define ValSupItemForDelSupIAtClass(class, supportItem, supportRel, mfail) \
        _ValSupItemForDelSupIAtClass(class, FALSE, supportItem, supportRel, mfail)
#define ValSupItemForDelSupIAtParent(class, supportItem, supportRel, mfail) \
        _ValSupItemForDelSupIAtClass(class, TRUE, supportItem, supportRel, mfail)

#define ValidateAttrValidValue(originObj, dialogObj, attr, valueList, isValid, badArgs, mfail) \
        _ValidateAttrValidValueAtClass(NULL, FALSE, originObj, dialogObj, attr, valueList, isValid, badArgs, mfail)
#define ValidateAttrValidValueAtClass(class, originObj, dialogObj, attr, valueList, isValid, badArgs, mfail) \
        _ValidateAttrValidValueAtClass(class, FALSE, originObj, dialogObj, attr, valueList, isValid, badArgs, mfail)
#define ValidateAttrValidValueAtParent(class, originObj, dialogObj, attr, valueList, isValid, badArgs, mfail) \
        _ValidateAttrValidValueAtClass(class, TRUE, originObj, dialogObj, attr, valueList, isValid, badArgs, mfail)

#define ValidateBIForTermState(obj, procHist, msgProc, exitState, advComments, mfail) \
        _ValidateBIForTermStateAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ValidateBIForTermStateAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ValidateBIForTermStateAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define ValidateBIForTermStateAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _ValidateBIForTermStateAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define ValidateDoChangeDispo(thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoChangeDispoAtClass(NULL, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValidateDoChangeDispoAtClass(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoChangeDispoAtClass(class, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValidateDoChangeDispoAtParent(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoChangeDispoAtClass(class, TRUE, thisObj, dialogObj, refresh, badArgs, mfail)

#define ValidateDoChangeStatus(thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoChangeStatusAtClass(NULL, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValidateDoChangeStatusAtClass(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoChangeStatusAtClass(class, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValidateDoChangeStatusAtParent(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoChangeStatusAtClass(class, TRUE, thisObj, dialogObj, refresh, badArgs, mfail)

#define ValidateDoChgTechDisp(thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoChgTechDispAtClass(NULL, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValidateDoChgTechDispAtClass(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoChgTechDispAtClass(class, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValidateDoChgTechDispAtParent(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoChgTechDispAtClass(class, TRUE, thisObj, dialogObj, refresh, badArgs, mfail)

#define ValidateDoClassifyChg(griItem, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoClassifyChgAtClass(NULL, FALSE, griItem, dialogObj, refresh, badArgs, mfail)
#define ValidateDoClassifyChgAtClass(class, griItem, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoClassifyChgAtClass(class, FALSE, griItem, dialogObj, refresh, badArgs, mfail)
#define ValidateDoClassifyChgAtParent(class, griItem, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoClassifyChgAtClass(class, TRUE, griItem, dialogObj, refresh, badArgs, mfail)

#define ValidateDoPdpClosure(thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoPdpClosureAtClass(NULL, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValidateDoPdpClosureAtClass(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoPdpClosureAtClass(class, FALSE, thisObj, dialogObj, refresh, badArgs, mfail)
#define ValidateDoPdpClosureAtParent(class, thisObj, dialogObj, refresh, badArgs, mfail) \
        _ValidateDoPdpClosureAtClass(class, TRUE, thisObj, dialogObj, refresh, badArgs, mfail)

#define ValidateForChangeDispo(thisObj, mfail) \
        _ValidateForChangeDispoAtClass(NULL, FALSE, thisObj, mfail)
#define ValidateForChangeDispoAtClass(class, thisObj, mfail) \
        _ValidateForChangeDispoAtClass(class, FALSE, thisObj, mfail)
#define ValidateForChangeDispoAtParent(class, thisObj, mfail) \
        _ValidateForChangeDispoAtClass(class, TRUE, thisObj, mfail)

#define ValidateForChgTechDisp(pdpItem, mfail) \
        _ValidateForChgTechDispAtClass(NULL, FALSE, pdpItem, mfail)
#define ValidateForChgTechDispAtClass(class, pdpItem, mfail) \
        _ValidateForChgTechDispAtClass(class, FALSE, pdpItem, mfail)
#define ValidateForChgTechDispAtParent(class, pdpItem, mfail) \
        _ValidateForChgTechDispAtClass(class, TRUE, pdpItem, mfail)

#define ValidateForClassifyChg(griItem, mfail) \
        _ValidateForClassifyChgAtClass(NULL, FALSE, griItem, mfail)
#define ValidateForClassifyChgAtClass(class, griItem, mfail) \
        _ValidateForClassifyChgAtClass(class, FALSE, griItem, mfail)
#define ValidateForClassifyChgAtParent(class, griItem, mfail) \
        _ValidateForClassifyChgAtClass(class, TRUE, griItem, mfail)

#define ValidateForCsu(pdpItem, mfail) \
        _ValidateForCsuAtClass(NULL, FALSE, pdpItem, mfail)
#define ValidateForCsuAtClass(class, pdpItem, mfail) \
        _ValidateForCsuAtClass(class, FALSE, pdpItem, mfail)
#define ValidateForCsuAtParent(class, pdpItem, mfail) \
        _ValidateForCsuAtClass(class, TRUE, pdpItem, mfail)

#define ValidateForPdpClosure(pdpItem, mfail) \
        _ValidateForPdpClosureAtClass(NULL, FALSE, pdpItem, mfail)
#define ValidateForPdpClosureAtClass(class, pdpItem, mfail) \
        _ValidateForPdpClosureAtClass(class, FALSE, pdpItem, mfail)
#define ValidateForPdpClosureAtParent(class, pdpItem, mfail) \
        _ValidateForPdpClosureAtClass(class, TRUE, pdpItem, mfail)

#define ValidateIncorporation(className, parentObj, childObj, mfail) \
        _ValidateIncorporation(className, FALSE, className, parentObj, childObj, mfail)
#define ValidateIncorporationAtParent(_class, className, parentObj, childObj, mfail) \
        _ValidateIncorporation(_class, TRUE, className, parentObj, childObj, mfail)

#define ValidateNewDispositionValue(dialogObj, pdpItem, badArgs, mfail) \
        _ValidateNewDispositionValueAtClass(NULL, FALSE, dialogObj, pdpItem, badArgs, mfail)
#define ValidateNewDispositionValueAtClass(class, dialogObj, pdpItem, badArgs, mfail) \
        _ValidateNewDispositionValueAtClass(class, FALSE, dialogObj, pdpItem, badArgs, mfail)
#define ValidateNewDispositionValueAtParent(class, dialogObj, pdpItem, badArgs, mfail) \
        _ValidateNewDispositionValueAtClass(class, TRUE, dialogObj, pdpItem, badArgs, mfail)

#define ValidateParticipants(pdpItem, roleMembers, validUsers, attrName, attrFlag, isValidFlag, mfail) \
        _ValidateParticipantsAtClass(NULL, FALSE, pdpItem, roleMembers, validUsers, attrName, attrFlag, isValidFlag, mfail)
#define ValidateParticipantsAtClass(class, pdpItem, roleMembers, validUsers, attrName, attrFlag, isValidFlag, mfail) \
        _ValidateParticipantsAtClass(class, FALSE, pdpItem, roleMembers, validUsers, attrName, attrFlag, isValidFlag, mfail)
#define ValidateParticipantsAtParent(class, pdpItem, roleMembers, validUsers, attrName, attrFlag, isValidFlag, mfail) \
        _ValidateParticipantsAtClass(class, TRUE, pdpItem, roleMembers, validUsers, attrName, attrFlag, isValidFlag, mfail)

#define ValidatePdpForCancel(thisObj, dialogObj, badArgs, mfail) \
        _ValidatePdpForCancelAtClass(NULL, FALSE, thisObj, dialogObj, badArgs, mfail)
#define ValidatePdpForCancelAtClass(class, thisObj, dialogObj, badArgs, mfail) \
        _ValidatePdpForCancelAtClass(class, FALSE, thisObj, dialogObj, badArgs, mfail)
#define ValidatePdpForCancelAtParent(class, thisObj, dialogObj, badArgs, mfail) \
        _ValidatePdpForCancelAtClass(class, TRUE, thisObj, dialogObj, badArgs, mfail)

#define ValidatePdpForClose(thisObj, dialogObj, badArgs, mfail) \
        _ValidatePdpForCloseAtClass(NULL, FALSE, thisObj, dialogObj, badArgs, mfail)
#define ValidatePdpForCloseAtClass(class, thisObj, dialogObj, badArgs, mfail) \
        _ValidatePdpForCloseAtClass(class, FALSE, thisObj, dialogObj, badArgs, mfail)
#define ValidatePdpForCloseAtParent(class, thisObj, dialogObj, badArgs, mfail) \
        _ValidatePdpForCloseAtClass(class, TRUE, thisObj, dialogObj, badArgs, mfail)

#define ValidatePdpForCloseExt(thisObj, mfail) \
        _ValidatePdpForCloseExtAtClass(NULL, FALSE, thisObj, mfail)
#define ValidatePdpForCloseExtAtClass(class, thisObj, mfail) \
        _ValidatePdpForCloseExtAtClass(class, FALSE, thisObj, mfail)
#define ValidatePdpForCloseExtAtParent(class, thisObj, mfail) \
        _ValidatePdpForCloseExtAtClass(class, TRUE, thisObj, mfail)

#define ValidatePdpForCloseInt(thisObj, badArgs, mfail) \
        _ValidatePdpForCloseIntAtClass(NULL, FALSE, thisObj, badArgs, mfail)
#define ValidatePdpForCloseIntAtClass(class, thisObj, badArgs, mfail) \
        _ValidatePdpForCloseIntAtClass(class, FALSE, thisObj, badArgs, mfail)
#define ValidatePdpForCloseIntAtParent(class, thisObj, badArgs, mfail) \
        _ValidatePdpForCloseIntAtClass(class, TRUE, thisObj, badArgs, mfail)

#define ValidatePdpForOpen(thisObj, dialogObj, badArgs, mfail) \
        _ValidatePdpForOpenAtClass(NULL, FALSE, thisObj, dialogObj, badArgs, mfail)
#define ValidatePdpForOpenAtClass(class, thisObj, dialogObj, badArgs, mfail) \
        _ValidatePdpForOpenAtClass(class, FALSE, thisObj, dialogObj, badArgs, mfail)
#define ValidatePdpForOpenAtParent(class, thisObj, dialogObj, badArgs, mfail) \
        _ValidatePdpForOpenAtClass(class, TRUE, thisObj, dialogObj, badArgs, mfail)

#define ValidatePdpForOpenExt(thisObj, mfail) \
        _ValidatePdpForOpenExtAtClass(NULL, FALSE, thisObj, mfail)
#define ValidatePdpForOpenExtAtClass(class, thisObj, mfail) \
        _ValidatePdpForOpenExtAtClass(class, FALSE, thisObj, mfail)
#define ValidatePdpForOpenExtAtParent(class, thisObj, mfail) \
        _ValidatePdpForOpenExtAtClass(class, TRUE, thisObj, mfail)

#define ValidatePdpForSuspend(thisObj, dialogObj, badArgs, mfail) \
        _ValidatePdpForSuspendAtClass(NULL, FALSE, thisObj, dialogObj, badArgs, mfail)
#define ValidatePdpForSuspendAtClass(class, thisObj, dialogObj, badArgs, mfail) \
        _ValidatePdpForSuspendAtClass(class, FALSE, thisObj, dialogObj, badArgs, mfail)
#define ValidatePdpForSuspendAtParent(class, thisObj, dialogObj, badArgs, mfail) \
        _ValidatePdpForSuspendAtClass(class, TRUE, thisObj, dialogObj, badArgs, mfail)

#define VisitChildren(visitorObj, visitedObj, relationship, mfail) \
        _VisitChildrenAtClass(NULL, FALSE, visitorObj, visitedObj, relationship, mfail)
#define VisitChildrenAtClass(class, visitorObj, visitedObj, relationship, mfail) \
        _VisitChildrenAtClass(class, FALSE, visitorObj, visitedObj, relationship, mfail)
#define VisitChildrenAtParent(class, visitorObj, visitedObj, relationship, mfail) \
        _VisitChildrenAtClass(class, TRUE, visitorObj, visitedObj, relationship, mfail)

#define VisitWbsItem(thisObj, wbsItemObj, mfail) \
        _VisitWbsItemAtClass(NULL, FALSE, thisObj, wbsItemObj, mfail)
#define VisitWbsItemAtClass(class, thisObj, wbsItemObj, mfail) \
        _VisitWbsItemAtClass(class, FALSE, thisObj, wbsItemObj, mfail)
#define VisitWbsItemAtParent(class, thisObj, wbsItemObj, mfail) \
        _VisitWbsItemAtClass(class, TRUE, thisObj, wbsItemObj, mfail)

#define VstDetectRecursion(visitorObj, visitedObj, mfail) \
        _VstDetectRecursionAtClass(NULL, FALSE, visitorObj, visitedObj, mfail)
#define VstDetectRecursionAtClass(class, visitorObj, visitedObj, mfail) \
        _VstDetectRecursionAtClass(class, FALSE, visitorObj, visitedObj, mfail)
#define VstDetectRecursionAtParent(class, visitorObj, visitedObj, mfail) \
        _VstDetectRecursionAtClass(class, TRUE, visitorObj, visitedObj, mfail)
#endif /* for msgccf_H */

