/**********************************************************************/
/*                                                                    */
/* wmtbasic.h                                                         */
/*                                                                    */
/* Workflow application programming interface include file. This is   */
/* the file supplied by the Workflow Management Coalition.            */
/* It contains definitions of the basic Workflow Management types     */
/* that are operating system or platform dependent.                   */
/* (WAPI interface 2, Version 1.1, March 1997).                       */
/*                                                                    */
/* Author:		Workflow Management Coalition                           */
/*                                                                    */
/* Standard C code (fully portable)                                   */
/*                                                                    */
/**********************************************************************/


/* SAP: File name adapted to #ifndef */
#ifndef					 WMTBASIC_H
#define					 WMTBASIC_H


typedef          char	  	  WMTInt8;
typedef          short  	  WMTInt16;
typedef          long    	  WMTInt32;
typedef unsigned char 		  WMTUInt8;
typedef unsigned short  	  WMTUInt16;
typedef unsigned long    	  WMTUInt32;

/* WMTPointer - generic pointer representation, points to the smallest 
   addressable unit of information. */

typedef WMTUInt8*           WMTPointer;
#define WMNULL			        ((WMTPointer)0)

/* WMTText - since different vendors may represent textual information 
   in different formats for language independence purposes, we treat 
   text as an opaque generic pointer. */
 
/* WMTText adapted to SAP datatype RFC_CHAR */
typedef WMTUInt8            WMTText;      

typedef WMTText*            WMTPText;
typedef WMTInt8*            WMTPInt8;
typedef WMTInt16*           WMTPInt16;
typedef WMTInt32*           WMTPInt32;


/* WMTBoolean - boolean type and value definitions. */

typedef WMTInt8			        WMTBoolean;
typedef WMTPText            WMTPPrivate;

#define WMFalse			        0
#define WMTrue			        (!WMFalse)

#define UNIQUE_ID_SIZE		  64
#define NAME_STRING_SIZE	  64

/* SAP: Additional WMT* datatypes */

typedef WMTUInt8*           WMTPUInt8;
typedef WMTUInt16*          WMTPUInt16;
typedef WMTUInt32*          WMTPUInt32;

#endif
