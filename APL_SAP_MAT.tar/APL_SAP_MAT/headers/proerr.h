/* $Id: proerr.h,v 2.5.1.3 1998/02/11 23:09:43 smdw Exp $ */
/*
bcprt
This software and related documentation are proprietary to UGS Corp.
COPYRIGHT 2007 UGS CORP.  ALL RIGHTS RESERVED
ecprt
*/

/*******************************************************************************
 * FILE
 *   proerr.h
 *
 * DESCRIPTION
 *   Contains the mfail error codes for PRO (Pro/ENGINEER interface).
 *
 * NOTES
 *   None.
 ******************************************************************************/

#ifndef _PROERR_
#define _PROERR_

/* PRO MFAIL ERROR CODES 7000-7999 */

/*******************************************************************
 *  RESERVED General pro error codes 7000-7049
 ******************************************************************/

#define PRO_OK 0
#define PRO_ERROR 7001

/* Proint ERROR Codes 7100-7199 */
#define PRO_CANNOT_START_PRO 			7101
#define PRO_CANNOT_ACTIVATE_OBJECT 		7102
#define PRO_CANNOT_DISPLAY_OBJECT_IN_WINDOW 	7103
#define PRO_PRO_STILL_ACTIVE 			7104
#define PRO_OBJ_STILL_ACTIVE 			7105
#define PRO_REG_UNKNOWN_ON 			7106
#define PRO_FAILED_RESTORE_RENAME 		7107
#define PRO_INVALID_GENERIC_VERSION 		7108
#define PRO_OBJ_HAS_PARENT 			7109
#define PRO_OBJ_IS_ACTIVE 			7110
#define PRO_OBJ_IS_NEW 				7111
#define PRO_NULL_QUANTITY 			7112
#define PRO_APC_BI_NOT_FOUND 			7113
#define PRO_DOC_BI_NOT_FOUND 			7114
#define PRO_APC_BI_NOT_VAULTED 			7115
#define PRO_DOC_BI_NOT_VAULTED 			7116
#define PRO_OBJ_NOT_VAULTED 			7117
#define PRO_APC_BI_IS_OFFICIAL 			7118
#define PRO_DOC_BI_IS_OFFICIAL 			7119
#define PRO_APC_BI_IS_SUPERSEDED 		7120
#define PRO_DOC_BI_IS_SUPERSEDED 		7121
#define PRO_APC_BI_NOT_FROZEN 			7122
#define PRO_DOC_BI_NOT_FROZEN 			7123
#define PRO_APC_BI_BASELINE_FALIED		7124
#define PRO_DOC_BI_BASELINE_FALIED 		7125
#define PRO_NOT_OWNED_BY_CURRENT_USER 		7126
#define PRO_CHECKIN_INSTANCE_NOT_ALLOWED 	7127
#define PRO_READONLY_PROE_FILE          	7128
#define PRO_CHECKIN_FAILED_OR_CANCELLED      	7129

#endif /* _PROERR_ */

#define BUSINESS_OBJECT 1
#define APC_OBJECT 2
