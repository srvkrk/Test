/* $Id: pdmc.h,v 2.2 1997/01/08 22:58:05 mhh Exp $ */
#ifndef _PDMC_H_
#define _PDMC_H_

#ifdef __cplusplus
extern "C" {
#endif

/**********************************************************************
 * C Include Files
 **********************************************************************/

/*** Metaphase Includes (not a complete list) ***/
#include <sc.h>
#include <cfg.h>
#include <Mtimsg.h>
#include <cl.h>
#include <meta.h>
#include <mserv.h>
#include<ft.h>
#include <msg.h>
#include <msgomf.h>
#include <mutproto.h>
#include <nls.h>
#include <serv.h>
#include <sys.h>
#include <ui.h>
#include <usc.h>
#include <cfg.h>
#include <relation.h>
#include <psm.h>
#include <msgpsm.h>
#include <msglcm.h>
/*** Custom Server Includes ***/

#ifdef __cplusplus
}
#endif
#endif  /* _PDMC_H_ */
