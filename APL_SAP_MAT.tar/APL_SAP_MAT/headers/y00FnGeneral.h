#ifndef _Y00FN_GENERAL_H_
#define _Y00FN_GENERAL_H_
/*
** External function prototypes for r0x
*/
extern int	y00FnStrCmpWild		( char *chwld, char *chcmp );

extern status	y00FnCheckRoleName	( ObjectPtr	qryDef,
					  int		*mfail);

extern status	y00FnConstructr0Class	( char		*classname,
					  ObjectPtr	*classObj,
					  int		*mfail);

extern status	y00FnConstructOption	( string	name,
					  ObjectPtr	*optionObj,
					  int		*mfail);

extern status	y00FnGenerateOBID	( ObjectPtr	thisObj,
					  int		*mfail);

extern status	y00FnGetMessageObject	( string	name,
					  ObjectPtr	*messagesObj,
					  int		*mfail);

extern status	y00FnCheckAttrForCond	( string	attrName,
					  boolean	*isValidForCond,
					  int		*mfail);

extern status	y00FnQuery1		( string	className,
					  string	attrName,
					  string	attrValue,
					  SetOfObjects	*itemObjs,
					  int		*mfail);

#endif
