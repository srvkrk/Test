/*
 *  FILE: msgcmiU.h
 */

#ifndef msgcmiU_H
#define msgcmiU_H

#include <Mtimsgh.h>
#ifndef _LCINTERP_
#include <metadt.h>
#else
extern "c" {
#endif

/*
 *  Message Function Definitions (Prototypes).
 *  Published Messages
 */

MTIstatus _x3DocExpandExecFastAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string cmi_ID, SetOfStrings * xmlFile, integer * mfail);

MTIstatus _x3DocExpandFastAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string cmi_ID, SetOfStrings * xmlFile, integer * mfail);

MTIstatus _x3ExpandExecSetBased
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects topObjSet, SetOfObjects topRelSet, integer expandLevel,
   SetOfStrings cmi_ID_set, SetOfObjects * xmlFileSet, integer * mfail);

MTIstatus _x3ExpandSetBasedAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer expandLevel, string cmi_ID, SetOfStrings * xmlFile,
   integer * mfail);

MTIstatus _x3UpdateForECMI
   (MTIstring _class, boolean getParent, string ClassName,
   SetOfStrings structureFile, SetOfStrings * ticketObject, integer * mfail);

MTIstatus _x3XMLModelInfoFastAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string cmi_ID, SetOfStrings * xmlFile, integer * mfail);

#ifdef _LCINTERP_
}
#else

/*
 *  Unpublished Messages
 */

MTIstatus _InflateModelnameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr self,
   integer * mfail);

MTIstatus _g3GetAllProductFilesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   ObjectPtr WorkBnchObj, SetOfObjects * productsOfPart, integer * mfail);

MTIstatus _g3SetPortAndHost
   (MTIstring _class, boolean getParent, string ClassName,
   string WindowId, string Host, string HostIpAdr,
   integer Port, integer * mfail);

MTIstatus _x34DNavCopyAllowedAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   boolean * pAllowed, integer * mfail);

MTIstatus _x3ActivateModelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3AddBBoxFilesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   ObjectPtr WkBnchObj, SetOfObjects modelsOfPart, SetOfObjects relsOfPart,
   integer * mfail);

MTIstatus _x3AddBlackBoxFilesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   string BlackBoxOBID, SetOfStrings PartNumberList, SetOfStrings FileNameList,
   SetOfStrings FileTypeList, SetOfObjects * pNewBlackBoxObjs, integer * mfail);

MTIstatus _x3AddCmpDataAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   ObjectPtr CmpDataObj, integer * mfail);

MTIstatus _x3AddCmpDocAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   ObjectPtr CmpDocObj, integer * mfail);

MTIstatus _x3AddMarkedToCatia
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3AddModelFilesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   ObjectPtr WkBnchObj, SetOfObjects modelsOfPart, SetOfObjects relsOfPart,
   integer * mfail);

MTIstatus _x3AddPrdDataAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   ObjectPtr PrdDataObj, integer * mfail);

MTIstatus _x3AddPrdDataECMIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   ObjectPtr PrdDataObj, SetOfStrings * messageText, boolean * messageAdded,
   integer * mfail);

MTIstatus _x3AddPrdDocAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   ObjectPtr PrdDocObj, integer * mfail);

MTIstatus _x3AddPrdDocECMIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   ObjectPtr PrdDocObj, SetOfStrings * messageText, boolean * messageAdded,
   integer * mfail);

MTIstatus _x3AddTempV5
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3AddToCatia
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3AddTrafoAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfStrings trafo, string * newIndex, integer * mfail);

MTIstatus _x3AllTo4DNav
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3AllToCatia
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3AllToView
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3AnswerToListener
   (MTIstring _class, boolean getParent, string className,
   string vHostIpAdr, integer port, integer answer,
   SetOfStrings objMgrSet, integer * mfail);

MTIstatus _x3AssCmdSendObjMgr
   (MTIstring _class, boolean getParent, string className,
   string vCommand, string errMsg, SetOfStrings objMgrSet,
   integer * mfail);

MTIstatus _x3AssImpSendObjMgr
   (MTIstring _class, boolean getParent, string className,
   string vCommand, string vCatiaHost, string dhost,
   string duser, string transfer_map, SetOfStrings objMgrSet,
   integer * mfail);

MTIstatus _x3AssReadSendObjMgr
   (MTIstring _class, boolean getParent, string className,
   string vCommand, string vCatiaHost, string dhost,
   string duser, string x0ComCatStatus, SetOfStrings pSetOfStrings,
   SetOfStrings pSetOfStrings2, boolean usex0MarkedInWkbnch, string scustomattr,
   boolean bSetLink, integer * mfail);

MTIstatus _x3AttOrUpdBlackBoxAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   SetOfStrings * objMgrSet, integer * mfail);

MTIstatus _x3AttachBlackBoxCmd
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3AttachBlackBoxFilesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   SetOfObjects blackBoxFiles, integer * mfail);

MTIstatus _x3AttachBlackBoxToPartAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   SetOfStrings * objMgrSet, integer * mfail);

MTIstatus _x3BrowseBlackBoxFilesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3BrowseDepForAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3BrowseDepOnAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3BrowseMarkedItems
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3BrowseSelectedItems
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects SelectedItems, integer * mfail);

MTIstatus _x3CancelCreateForDoc
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3CancelToCatia
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3CancelUsePdmStruct
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3CancelV5AddTemp
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3CancelV5SaveAs
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3ChangeDrawFlagAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3ChangeSwapFlagAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3CheckCatArcNameExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string arcname, string * archive_out, integer * mfail);

MTIstatus _x3CheckCatCgrNameExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string cgrname, string * cgr_out, integer * mfail);

MTIstatus _x3CheckCatDrwNameExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string drawingname, string * drawing_out, integer * mfail);

MTIstatus _x3CheckCatPrtNameExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string partname, string * part_out, integer * mfail);

MTIstatus _x3CheckCatRepNameExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string repname, string origrepname, string * rep_out,
   integer * mfail);

MTIstatus _x3CheckDTNameExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string dtName, string * drawing_out, integer * mfail);

MTIstatus _x3CheckForMultiOccAtClass
   (MTIstring _class, boolean getParent, ObjectPtr assmStrcObj,
   string curSubAssObid, SetOfStrings SubAssRels, boolean * hasMultiOcc,
   integer * mfail);

MTIstatus _x3CheckIfInteractive
   (MTIstring _class, boolean getParent, string classname,
   boolean * is_interactive, integer * mfail);

MTIstatus _x3CheckModelNameExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string modelname, string * model_out, integer * mfail);

MTIstatus _x3CheckWBvsCatiaPrefs
   (MTIstring _class, boolean getParent, string ClassName,
   boolean * bContinue, integer * mfail);

MTIstatus _x3ClgFileNameInWL
   (MTIstring _class, boolean getParent, string classname,
   string oldFilename, string * newFilename, integer * mfail);

MTIstatus _x3ClrWkBnch
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3CmpFileNameInWL
   (MTIstring _class, boolean getParent, string classname,
   string oldFilename, string * newFilename, integer * mfail);

MTIstatus _x3ConvertStringList
   (MTIstring _class, boolean getParent, string className,
   string stringList, SetOfStrings * stringSet, integer * mfail);

MTIstatus _x3ConvertUserDefProps
   (MTIstring _class, boolean getParent, string className,
   NvSet objInfos, SetOfStrings * vDisplayNameSet, SetOfStrings * vPropNameSet,
   SetOfStrings * vPropValueSet, integer * mfail);

MTIstatus _x3CopyCatiaFileSet
   (MTIstring _class, boolean getParent, string classname,
   SetOfStrings sHosts, SetOfStrings sUsers, SetOfStrings sFullPaths,
   SetOfStrings dHosts, SetOfStrings dUsers, SetOfStrings dFullPaths,
   boolean * bReadOk, SetOfStrings * vStats, integer * mfail);

MTIstatus _x3CopyCgrFileToMapAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string targetSystem, boolean bCreateLink, SetOfStrings * sHosts,
   SetOfStrings * sUsers, SetOfStrings * sFullPaths, SetOfStrings * dHosts,
   SetOfStrings * dUsers, SetOfStrings * dFullPaths, string * cgrPath,
   boolean * bLinkSuccess, integer * mfail);

MTIstatus _x3CopyClgDataForCatia
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3CopyModelToMapAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   string targetSystem, string exMap, boolean bTryCgr,
   boolean bCreateLink, string sHost, string sUser,
   string sFullPath, string dHost, string dUser,
   string dFullPath, SetOfStrings * sHosts, SetOfStrings * sUsers,
   SetOfStrings * sFullPaths, SetOfStrings * dHosts, SetOfStrings * dUsers,
   SetOfStrings * dFullPaths, string * cgrFullPath, boolean * bLinkSuccess,
   integer * mfail);

MTIstatus _x3CopyStdFileToMap
   (MTIstring _class, boolean getParent, string className,
   string targetSystem, boolean bCreateLink, string sHost,
   string sUser, string sFullPath, string dHost,
   string dUser, string dFullPath, SetOfStrings * sHosts,
   SetOfStrings * sUsers, SetOfStrings * sFullPaths, SetOfStrings * dHosts,
   SetOfStrings * dUsers, SetOfStrings * dFullPaths, boolean * bLinkSuccess,
   integer * mfail);

MTIstatus _x3CopyTransMap
   (MTIstring _class, boolean getParent, string className,
   string exchange_map, string transfer_map, string dhost,
   string duser, SetOfStrings objMgrSet, integer * mfail);

MTIstatus _x3CopyWorklocDir
   (MTIstring _class, boolean getParent, string classname,
   string mhost, string muser, string dhost,
   string duser, string worklocation, string catia_exchange_file,
   string backupfilename, integer a_mode, integer * mfail);

MTIstatus _x3CopysCMIFiles
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3CreBlackBoxFileObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   string sourceFileName, string fileTypeToCreate, ObjectPtr * pBlackBoxFileObj,
   integer * mfail);

MTIstatus _x3CreFileInteractiveAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string partnumber, string relPathInWL, string worklocation,
   string worklocHost, string username, integer * mfail);

MTIstatus _x3Create
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3CreateAndLinkPrdDoc
   (MTIstring _class, boolean getParent, string className,
   string partNumber, ObjectPtr partObj, ObjectPtr * newPrdDocObj,
   SetOfStrings * vStats, integer * mfail);

MTIstatus _x3CreateAssyCATProd
   (MTIstring _class, boolean getParent, string ClassName,
   NvSet InSlots, NvSet prodModelInfos, NvSet * pOutSlots1,
   NvSet * pOutSlots2, ObjectPtr * pNewAssemblyObj, SetOfStrings * vStats,
   integer * mfail);

MTIstatus _x3CreateBackupFileName
   (MTIstring _class, boolean getParent, string className,
   string TargetFileName, string * BackupFileName, integer * mfail);

MTIstatus _x3CreateCATDrawFrFile
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3CreateCATPartFrFile
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3CreateCATV4FromFile
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3CreateCatDrwAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr docObj, boolean bInteract, string file,
   integer * mfail);

MTIstatus _x3CreateCatDrwObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr docObj, string NewModelName, string DefWorkloc,
   string CompName, boolean bInteract, NvSet ModelInfos,
   SetOfStrings vStats, integer * mfail);

MTIstatus _x3CreateCatDrwPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3CreateCatPrdForECMI
   (MTIstring _class, boolean getParent, string className,
   string pathFormat, string path, ObjectPtr * newRegFileObj,
   SetOfStrings * messageText, boolean * messageAdded, integer * mfail);

MTIstatus _x3CreateCatPrtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr docObj, boolean bInteract, string file,
   integer * mfail);

MTIstatus _x3CreateCatPrtForUpdtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string file, string partnumber, NvSet ModelInfos,
   SetOfStrings vStats, integer * mfail);

MTIstatus _x3CreateCatalogPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   NVSET nvsObjInfos, integer * mfail);

MTIstatus _x3CreateCatiaCatalog
   (MTIstring _class, boolean getParent, string className,
   string xmapPath, string xmapHost, string xmapUser,
   NVSET nvsObjInfos, ObjectPtr * newRegFileObj, integer * mfail);

MTIstatus _x3CreateCmpData
   (MTIstring _class, boolean getParent, string className,
   string xmapPath, string newFileName, ObjectPtr * newCmpDataObj,
   integer * mfail);

MTIstatus _x3CreateCmpDataPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   integer * mfail);

MTIstatus _x3CreateCmpDoc
   (MTIstring _class, boolean getParent, string className,
   string partNumber, ObjectPtr partObj, ObjectPtr * newCmpDocObj,
   integer * mfail);

MTIstatus _x3CreateCmpDocPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   integer * mfail);

MTIstatus _x3CreateComponent
   (MTIstring _class, boolean getParent, string ClassName,
   NvSet InSlots, NvSet * pOutSlots, ObjectPtr * pNewCmponentObj,
   ObjectPtr * pNewCATPartObj, SetOfStrings * vStats, boolean * updateOk,
   integer * mfail);

MTIstatus _x3CreateDmuData
   (MTIstring _class, boolean getParent, string className,
   string partNumber, string revision, string filePath,
   string protPath, string dHost, string dUser,
   SetOfStrings protSet, integer * mfail);

MTIstatus _x3CreateDmuFileAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3CreateDocForECMI
   (MTIstring _class, boolean getParent, string className,
   string documentName, ObjectPtr * documentObj, SetOfStrings * messageText,
   boolean * messageAdded, integer * mfail);

MTIstatus _x3CreateDocForModelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObject,
   ObjectPtr partObject, ObjectPtr * newDocObject, integer * mfail);

MTIstatus _x3CreateDocForModelExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObject,
   ObjectPtr partObject, SetOfStrings matrix, ObjectPtr * newDocObject,
   ObjectPtr * relObject, integer * mfail);

MTIstatus _x3CreateFileForECMI
   (MTIstring _class, boolean getParent, string className,
   string fileName, string pathFormat, string path,
   ObjectPtr * newRegFileObj, SetOfStrings * messageText, boolean * messageAdded,
   integer * mfail);

MTIstatus _x3CreateFileForUpdtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string file, string partnumber, NvSet ModelInfos,
   SetOfStrings vStats, integer * mfail);

MTIstatus _x3CreateFileForUpdtExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string file, string partnumber, NvSet ModelInfos,
   NvSet PartAttributes, SetOfStrings matrix, ObjectPtr existingPart,
   ObjectPtr * createdPart, ObjectPtr * document, ObjectPtr * relObject,
   SetOfStrings vStats, integer * mfail);

MTIstatus _x3CreateInt
   (MTIstring _class, boolean getParent, string ClassName,
   SetOfObjects * sessObjs, integer * mfail);

MTIstatus _x3CreateLink
   (MTIstring _class, boolean getParent, string classname,
   string host, string user, string dhost,
   string duser, string sourcefile, string targetfile,
   integer a_mode, integer * link_rtncode, integer * mfail);

MTIstatus _x3CreateModelFrV5PostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObject,
   string partOBID, string V5ModelOBID, integer * mfail);

MTIstatus _x3CreateModelFromCatiaAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string file, string project, string description,
   NvSet ModelInfos, integer * mfail);

MTIstatus _x3CreateModelFromTempAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3CreateModelFromV5PrtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string file, integer * mfail);

MTIstatus _x3CreateModelNameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string pHost, string pUserName, string pDirectory,
   ObjectPtr DocObj, string * filename, integer * mfail);

MTIstatus _x3CreateModelRelECMI
   (MTIstring _class, boolean getParent, string className,
   string modelOBID, SetOfStrings * messageText, boolean * messageAdded,
   integer * mfail);

MTIstatus _x3CreateNewPlotFileAtClass
   (MTIstring _class, boolean getParent, ObjectPtr originatingObj,
   SetOfStrings plotfeatures, ObjectPtr * plotFileObj, integer * mfail);

MTIstatus _x3CreateNewSubAssRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr partMaster, ObjectPtr * newRelObj, integer * mfail);

MTIstatus _x3CreateOrRepPltFiles
   (MTIstring _class, boolean getParent, string ClassName,
   SetOfStrings IpcSet, ObjectPtr modObj, SetOfObjects * plotFileObjs,
   integer * mfail);

MTIstatus _x3CreatePartAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObject,
   NvSet pAttributeSet, boolean bUseDialog, integer * mfail);

MTIstatus _x3CreatePartECMI
   (MTIstring _class, boolean getParent, string className,
   string partNumber, string dialogNames, string dialogValues,
   ObjectPtr * partObj, SetOfStrings * messageText, boolean * messageAdded,
   integer * mfail);

MTIstatus _x3CreatePartExt
   (MTIstring _class, boolean getParent, string strClassname,
   string newPartClass, ObjectPtr * partObject, NvSet pAttributeSet,
   string strPartCategory, boolean bUseDialog, SetOfStrings * vStats,
   integer * mfail);

MTIstatus _x3CreatePlotFileName
   (MTIstring _class, boolean getParent, string sClassname,
   ObjectPtr modelObj, string sCatiaFileName, string sHost,
   string sUserName, string sDirectory, string * sFilename,
   integer * mfail);

MTIstatus _x3CreatePlotObjAtClass
   (MTIstring _class, boolean getParent, ObjectPtr modObj,
   SetOfStrings plotfeatures, ObjectPtr * plotFileObj, integer * mfail);

MTIstatus _x3CreatePostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _x3CreatePrdData
   (MTIstring _class, boolean getParent, string className,
   string xmapPath, string newFileName, ObjectPtr * newPrdDataObj,
   integer * mfail);

MTIstatus _x3CreatePrdDataPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   integer * mfail);

MTIstatus _x3CreatePrdDoc
   (MTIstring _class, boolean getParent, string className,
   string partNumber, ObjectPtr partObj, ObjectPtr * newPrdDocObj,
   integer * mfail);

MTIstatus _x3CreatePrdDocPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   integer * mfail);

MTIstatus _x3CreateUsesRel
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr leftPrtObj, ObjectPtr rightPrtObj, NvSet usesInfos,
   ObjectPtr * newRelObj, string * trafoIndex, integer * mfail);

MTIstatus _x3CreateV5DrwDocFrFile
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3CreateV5PrtDocFrFile
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3CtlgGetMasterIds
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3CusGetRlvRelViaObid
   (MTIstring _class, boolean getParent, string ClassName,
   string RelOBID, ObjectPtr ctItemObj, ObjectPtr * Relation,
   integer * mfail);

MTIstatus _x3CusGetRlvRlViaObidDb
   (MTIstring _class, boolean getParent, string ClassName,
   string RelOBID, string DataBaseName, ObjectPtr ctItemObj,
   ObjectPtr * Relation, integer * mfail);

MTIstatus _x3CusMultiDocCreateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects DocumentSet, SetOfObjects ModelSet, integer * mfail);

MTIstatus _x3DecreaseRelQtyAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   ObjectPtr leftPrtObj, ObjectPtr rightPrtObj, integer * mfail);

MTIstatus _x3DeexpandInstanceAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr ctxObj, string sParentObid, string sParentDbName,
   string sRelObid, string sRelDbName, string sChildObid,
   string sChildDbName, boolean bHasMatrixIndex, integer * mfail);

MTIstatus _x3DeexpandMarked
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3DeexpandModelInstAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr ctxObj, string sParentObid, string sParentDbName,
   string sRelObid, string sRelDbName, string sChildObid,
   string sChildDbName, boolean bHasMatrixIndex, integer * mfail);

MTIstatus _x3DeexpandSelected
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects SelectedItems, integer * mfail);

MTIstatus _x3DelAssmStrcRelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string matrix_index, integer * quantity, integer * mfail);

MTIstatus _x3DelFilesInExMap
   (MTIstring _class, boolean getParent, string className,
   string exchge, integer * mfail);

MTIstatus _x3DeleteRelCIObjectsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _x3DeleteRelCIObjectsNIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _x3DeleteTempAss
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3DeleteTrafoAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string index, integer * mfail);

MTIstatus _x3DependsOnFilesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr modObj,
   SetOfObjects * depFiles, integer * mfail);

MTIstatus _x3DisplayWBTitle
   (MTIstring _class, boolean getParent, string ClassName,
   string sTargetSystem, integer * mfail);

MTIstatus _x3DocCreateCopyAttrsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr documentObj, integer * mfail);

MTIstatus _x3DocCreateCpyDlgAttrsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr documentObj, integer * mfail);

MTIstatus _x3DocCreateCreRelCus
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr dialogObj, ObjectPtr leftObj, ObjectPtr rightObj,
   ObjectPtr * relationObj, integer * mfail);

MTIstatus _x3DocCreateCustomMsg
   (MTIstring _class, boolean getParent, string className,
   string vWorkMode, SetOfStrings vStrSet, integer * mfail);

MTIstatus _x3DocCreateMsg
   (MTIstring _class, boolean getParent, string className,
   string vWorkMode, SetOfStrings vStrSet, integer * mfail);

MTIstatus _x3DocumentCreateCustomAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WkBnchObj, ObjectPtr commObj, ObjectPtr BackgroundItem,
   integer * mfail);

MTIstatus _x3DocumentLinkCatDrwAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WkBnchObj, ObjectPtr commObj, ObjectPtr BackgroundItem,
   integer * mfail);

MTIstatus _x3DocumentLinkCatPrtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WkBnchObj, ObjectPtr commObj, ObjectPtr BackgroundItem,
   integer * mfail);

MTIstatus _x3DocumentReadAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WkBnchObj, ObjectPtr commObj, ObjectPtr BackgroundItem,
   ObjectPtr * pDocRep, integer * mfail);

MTIstatus _x3DocumentSaveAsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WkBnchObj, ObjectPtr commObj, ObjectPtr BackgroundItem,
   integer * mfail);

MTIstatus _x3DocumentSaveAsPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WkBnchObj, ObjectPtr commObj, ObjectPtr BackgroundItem,
   integer * mfail);

MTIstatus _x3DropSubAssMsg
   (MTIstring _class, boolean getParent, string ClassName,
   SetOfStrings vStrSet, integer * mfail);

MTIstatus _x3DumpAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3EPlotByLstnr
   (MTIstring _class, boolean getParent, string ClassName,
   SetOfStrings vStrSet, integer * mfail);

MTIstatus _x3EPlotCustomData
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr ModelObject, SetOfStrings * NameSlotSet, SetOfStrings * ValueSlotSet,
   boolean * bIsPossible, integer * mfail);

MTIstatus _x3EPlotInWb
   (MTIstring _class, boolean getParent, string ClassName,
   string ModelOBID, string PartOBID, string WayToRoot,
   SetOfStrings DraftsList, SetOfStrings ViewsList, SetOfStrings FramesList,
   integer * mfail);

MTIstatus _x3ExpandInstanceAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr ctxObj, string sParentObid, string sParentDbName,
   string sRelObid, string sRelDbName, string sChildObid,
   string sChildDbName, boolean bHasMatrixIndex, integer * mfail);

MTIstatus _x3ExpandModelInstAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr ctxObj, string sParentObid, string sParentDbName,
   string sRelObid, string sRelDbName, string sChildObid,
   string sChildDbName, boolean bHasMatrixIndex, integer * mfail);

MTIstatus _x3ExpandV5DrawingsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3FileNameInWL
   (MTIstring _class, boolean getParent, string classname,
   string xmapUser, string xmapHost, string xmapPath,
   string defaultFilename, string * newFilename, integer * mfail);

MTIstatus _x3FillObjMgrSet
   (MTIstring _class, boolean getParent, string className,
   string exchange_map, string dhost, string duser,
   string x0ComCatStatus, SetOfStrings pSetOfStrings, SetOfStrings pSetOfStrings2,
   boolean usex0MarkedInWkbnch, string scustomattr, boolean bSetLink,
   SetOfStrings * objMgrSet, integer * mfail);

MTIstatus _x3FilterPartByVersion
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects * filterSet, integer * mfail);

MTIstatus _x3FindCatModelByCusKey
   (MTIstring _class, boolean getParent, string classname,
   SetOfStrings attributelist, SetOfStrings valuelist, ObjectPtr * FoundObj,
   boolean * bIsDocument, integer * mfail);

MTIstatus _x3FindCatPartByCusKey
   (MTIstring _class, boolean getParent, string classname,
   SetOfStrings attributelist, SetOfStrings valuelist, ObjectPtr * FoundObj,
   integer * mfail);

MTIstatus _x3FindCatRelByCusKey
   (MTIstring _class, boolean getParent, string classname,
   SetOfStrings attributelist, SetOfStrings valuelist, ObjectPtr * FoundObj,
   integer * mfail);

MTIstatus _x3FindModCompsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfStrings * doccomps, integer * mfail);

MTIstatus _x3GenInstNameForIndexAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string index, string * sInstanceName, integer * mfail);

MTIstatus _x3GetAllComponentFilesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   ObjectPtr WkBnchObj, SetOfObjects * compObjects, integer * mfail);

MTIstatus _x3GetAllModAndPos
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr partObj, ObjectPtr WorkBnchObj, SetOfObjects * vModSet,
   SetOfObjects * vPosSet, integer * mfail);

MTIstatus _x3GetAttValueForObject
   (MTIstring _class, boolean getParent, string sClassName,
   SetOfStrings vObjectObid, SetOfStrings vObjectDbName, SetOfStrings vObjectClassName,
   string sAttributeName, string * sAttributeValue, string * sReturnCode,
   integer * mfail);

MTIstatus _x3GetAttValueForPosObj
   (MTIstring _class, boolean getParent, string sThisClassName,
   string sInstanceName, SetOfStrings vObjectObid, SetOfStrings vObjectDbName,
   SetOfStrings vObjectClassName, string sAttributeName, string * sAttributeValue,
   string * sReturnCode, integer * mfail);

MTIstatus _x3GetAttValueForRelObj
   (MTIstring _class, boolean getParent, string sThisClassName,
   string sInstanceName, string sMatrixIndex, SetOfStrings vObjectObid,
   SetOfStrings vObjectDbName, SetOfStrings vObjectClassName, string sAttributeName,
   string * sAttributeValue, string * sReturnCode, integer * mfail);

MTIstatus _x3GetAttrs
   (MTIstring _class, boolean getParent, string className,
   string PartOBID, string ModelOBID, SetOfStrings Attrs_demanded,
   SetOfStrings * Attr_Vals_found, integer * mfail);

MTIstatus _x3GetAttrsForCADAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfStrings Attrs_demanded, SetOfStrings * AttrVals_found, integer * mfail);

MTIstatus _x3GetAttrsMg
   (MTIstring _class, boolean getParent, string ClassName,
   SetOfStrings vStrSet, SetOfStrings * vRetSet, integer * mfail);

MTIstatus _x3GetBomType
   (MTIstring _class, boolean getParent, string strClassname,
   NVSET nvsObjInfos, NVSET nvsUserDefInfos, NVSET nvsParentObjInfos,
   NVSET nvsParentUserDefInfos, string * bomType, integer * mfail);

MTIstatus _x3GetBomTypes
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3GetCATIADefinitExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr docObj, string * descr, integer * mfail);

MTIstatus _x3GetCATIADefinitionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string * descr, integer * mfail);

MTIstatus _x3GetCATIADescriptExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr docObj, string * descr, integer * mfail);

MTIstatus _x3GetCATIADescriptionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string * descr, integer * mfail);

MTIstatus _x3GetCATIANomenclatExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr docObj, string * descr, integer * mfail);

MTIstatus _x3GetCATIANomenclatureAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string * descr, integer * mfail);

MTIstatus _x3GetCATIARevisionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string * descr, integer * mfail);

MTIstatus _x3GetCATIARevisionExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr docObj, string * descr, integer * mfail);

MTIstatus _x3GetCIFromCMRepAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects CtItDpRelObjSet, ObjectPtr * CatiaItemObj, integer * mfail);

MTIstatus _x3GetCatalogDispNameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string * vDisplayName, integer * mfail);

MTIstatus _x3GetCatalogFile
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3GetCatalogInfo
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3GetCatalogObjects
   (MTIstring _class, boolean getParent, string classname,
   string objecthandle, ObjectPtr * pPartObject, ObjectPtr * pProductObject,
   SetOfStrings * vStats, integer * mfail);

MTIstatus _x3GetCatalogsForCatia
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects * pCatalogs, integer * mfail);

MTIstatus _x3GetCatalogsForEdit
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects * pCatalogs, integer * mfail);

MTIstatus _x3GetCatiaDispNameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObject,
   string * sCatiaDisplayName, integer * mfail);

MTIstatus _x3GetCatiaFileExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string * sExtension, integer * mfail);

MTIstatus _x3GetCatiaModSizeAtClass
   (MTIstring _class, boolean getParent, ObjectPtr ModObj,
   integer * ModSize, integer * mfail);

MTIstatus _x3GetCgrFilePathsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   string * sHost, string * sUser, string * sCgrFullPath,
   string * dHost, string * dUser, string * dCgrfullPath,
   integer * mfail);

MTIstatus _x3GetChildAssmsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   SetOfObjects * childItems, SetOfObjects * rels_in_WkBnch, SetOfObjects * childAssms,
   integer * mfail);

MTIstatus _x3GetChildInstNames
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr partObj, ObjectPtr productObj, SetOfStrings * vInstanceNameSet,
   SetOfStrings * vPartPartNumberSet, SetOfStrings * vModelInstNamesSet, SetOfStrings * vNewModelInstNamesSet,
   SetOfStrings * vModelPartNumberSet, SetOfStrings * vModelOldObidSet, SetOfStrings * vModelNewObidSet,
   integer * mfail);

MTIstatus _x3GetClassForCatRep
   (MTIstring _class, boolean getParent, string sClassName,
   string sOrigCatRepClassName, string sOrigFileName, string sOrigPartNumber,
   string * sNewCatRepClassName, integer * mfail);

MTIstatus _x3GetClgObjViaObid
   (MTIstring _class, boolean getParent, string sWkBnchClass,
   string sClgClassName, string sClgOBID, string sClgDbName,
   ObjectPtr * pObj, integer * mfail);

MTIstatus _x3GetCmpDocName
   (MTIstring _class, boolean getParent, string className,
   string partNumber, string * documentName, integer * mfail);

MTIstatus _x3GetCmpPartForModel
   (MTIstring _class, boolean getParent, string sClassName,
   ObjectPtr modelObject, ObjectPtr * pPartObject, integer * mfail);

MTIstatus _x3GetCntObjViaObid
   (MTIstring _class, boolean getParent, string className,
   string binOBID, ObjectPtr * binObj, integer * mfail);

MTIstatus _x3GetCntViaObidAndDb
   (MTIstring _class, boolean getParent, string className,
   string binOBID, string binDbName, ObjectPtr * binObj,
   integer * mfail);

MTIstatus _x3GetContainedModelsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string * sModelsFetched, string * sBBFilesFetched, SetOfObjects * modRepObjs,
   SetOfObjects * BBModels, integer * mfail);

MTIstatus _x3GetCusDataForCADExt
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr WorkbenchRel, ObjectPtr this, string objectid,
   SetOfStrings * attributelist, SetOfStrings * valuelist, integer * mfail);

MTIstatus _x3GetCustomAttrsV5
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3GetCustomDataForCAD
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr this, string objectid, SetOfStrings * attributelist,
   SetOfStrings * valuelist, integer * mfail);

MTIstatus _x3GetDependencyInfo
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3GetDependentFiles
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3GetDescriptionInCADAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string * descr, integer * mfail);

MTIstatus _x3GetDesignTablesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr catiaObj,
   ObjectPtr partObj, SetOfObjects * desTabObjs, SetOfStrings * dtFileNames,
   integer * mfail);

MTIstatus _x3GetDestCgrFilePathAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   string * dHost, string * dUser, string * dCgrfullPath,
   integer * mfail);

MTIstatus _x3GetDmuPartNumberVSAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _x3GetDmuVolNameVSAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _x3GetFeatureExtForCAD
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr this, ObjectPtr nModRep, string partOBID,
   ObjectPtr x0CTItemObj, string objectid, SetOfStrings * SetOfContainerIdsMod,
   SetOfStrings * SetOfClientIdsMod, SetOfStrings * SetOfFeatureTypesMod, SetOfStrings * SetOfFeatureAttrsMod,
   SetOfStrings * SetOfFeatureValuesMod, integer * mfail);

MTIstatus _x3GetInfoForCAD
   (MTIstring _class, boolean getParent, string ClassName,
   string RelationOBID, string PartOBID, string DocRelOBID,
   string ModelOBID, SetOfStrings * LabelSet, SetOfStrings * ValueSet,
   integer * mfail);

MTIstatus _x3GetInfoForParts
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3GetInstInfos
   (MTIstring _class, boolean getParent, string className,
   NVSET nvsInstInfos, string sXmap, ObjectPtr WkBnchObj,
   NVSET * nvsInstOutput, integer * mfail);

MTIstatus _x3GetInstNameForIndexAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string index, string * sInstanceName, integer * mfail);

MTIstatus _x3GetInstanceInfo
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3GetItemInfoForCADAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfStrings * LabelSet, SetOfStrings * ValueSet, integer * mfail);

MTIstatus _x3GetItemsOfItemAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr itemObj, SetOfObjects * ItemsOfPart, SetOfObjects * itemItemRels,
   integer * mfail);

MTIstatus _x3GetLastModSeq
   (MTIstring _class, boolean getParent, string ClassName,
   ObjectPtr modObj, string relative_path, SetOfObjects modelsOfPart,
   SetOfObjects relsOfPart, ObjectPtr * lastModObj, ObjectPtr * lastRelObj,
   integer * mfail);

MTIstatus _x3GetModCmpFrmAsmInWkBAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string compOBID, ObjectPtr * modObj, integer * mfail);

MTIstatus _x3GetModPosViaOBID
   (MTIstring _class, boolean getParent, string className,
   string ModPosClass, string Obid, ObjectPtr * ModPosObj,
   integer * mfail);

MTIstatus _x3GetModPosViaObidDb
   (MTIstring _class, boolean getParent, string className,
   string ModPosClass, string Obid, string DataBaseName,
   ObjectPtr * ModPosObj, integer * mfail);

MTIstatus _x3GetModelForSaveAsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string comStatus, ObjectPtr * compObj, integer * mfail);

MTIstatus _x3GetModelInfoMsg
   (MTIstring _class, boolean getParent, string ClassName,
   SetOfStrings vStrSet, SetOfStrings * vRetSet, integer * mfail);

MTIstatus _x3GetModelInstanceNameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr CTFileObj,
   string sOrigInstanceName, string * sNewInstanceName, integer * mfail);

MTIstatus _x3GetModelViaObidAndDb
   (MTIstring _class, boolean getParent, string className,
   string modelOBID, string modelDbName, ObjectPtr * modelObj,
   integer * mfail);

MTIstatus _x3GetModelsViaObid
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings modelClassNames, SetOfStrings modelDbNames, SetOfStrings modelOBIDs,
   SetOfObjects * modelObjs, integer * mfail);

MTIstatus _x3GetObjectForCatiaAtt
   (MTIstring _class, boolean getParent, string className,
   string sPartNumber, string sProductType, string sFileName,
   NVSET nvsExtraInfos, ObjectPtr * pdmObj, integer * mfail);

MTIstatus _x3GetOneComponentAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string comStatus, ObjectPtr * compObj, integer * mfail);

MTIstatus _x3GetOrigGeoForCgr
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3GetOrigInstNmeFrMod
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr partObj, string sRealProductOBID, ObjectPtr productObj,
   ObjectPtr modelObj, ObjectPtr posObj, boolean * bOutOfSync,
   string * sInstanceName, integer * mfail);

MTIstatus _x3GetOrigPartNumberAtClass
   (MTIstring _class, boolean getParent, ObjectPtr ArchiveObj,
   string * sOrigPartNumber, integer * mfail);

MTIstatus _x3GetPDMSettings
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3GetParamForFileV5
   (MTIstring _class, boolean getParent, string sClassname,
   ObjectPtr thisObj, SetOfStrings * vAttributeList, SetOfStrings * vAalueList,
   integer * mfail);

MTIstatus _x3GetPartAttributeApi
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3GetPartByAttributes
   (MTIstring _class, boolean getParent, string ClassName,
   string partOBID, string partNumber, string partRevision,
   string lastSeq, ObjectPtr * subassObj, integer * mfail);

MTIstatus _x3GetPartByAttrsAndDb
   (MTIstring _class, boolean getParent, string ClassName,
   string databaseName, string partOBID, string partNumber,
   string partRevision, string lastSeq, ObjectPtr * subassObj,
   integer * mfail);

MTIstatus _x3GetPartByPartNumber
   (MTIstring _class, boolean getParent, string className,
   string partNumber, ObjectPtr * PartObj, integer * mfail);

MTIstatus _x3GetPartForCatalog
   (MTIstring _class, boolean getParent, string sWkBnchClass,
   string sPartClassName, string sPartOBID, string sPartDbName,
   ObjectPtr * pObj, integer * mfail);

MTIstatus _x3GetPartForCatalogExt
   (MTIstring _class, boolean getParent, string sWkBnchClass,
   string sPartClassName, string sPartOBID, string sPartDbName,
   boolean bGetLastCtlgElem, ObjectPtr * pObj, integer * mfail);

MTIstatus _x3GetPartInfoForCADAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr PartRel, SetOfStrings * LabelSet, SetOfStrings * ValueSet,
   integer * mfail);

MTIstatus _x3GetPartModelViaObid
   (MTIstring _class, boolean getParent, string className,
   string modelOBID, ObjectPtr * modelObj, integer * mfail);

MTIstatus _x3GetPartObjViaObid
   (MTIstring _class, boolean getParent, string className,
   string partOBID, ObjectPtr * partObj, integer * mfail);

MTIstatus _x3GetPartObjViaObidDb
   (MTIstring _class, boolean getParent, string className,
   string partOBID, string partDbName, ObjectPtr * partObj,
   integer * mfail);

MTIstatus _x3GetPartsInAssViaOBID
   (MTIstring _class, boolean getParent, string ClassName,
   ObjectPtr PartObj, SetOfStrings RelIDs, SetOfStrings PartIDs,
   SetOfStrings PosInstNbrSet, SetOfStrings PartNbrSet, SetOfStrings PartRevSet,
   string lastSeq, SetOfObjects * RelationSet, SetOfObjects * PartSet,
   integer * mfail);

MTIstatus _x3GetPlotType
   (MTIstring _class, boolean getParent, string ClassName,
   SetOfStrings plotfeatures, string * plottype, integer * mfail);

MTIstatus _x3GetPrdDocName
   (MTIstring _class, boolean getParent, string className,
   string partNumber, string * documentName, integer * mfail);

MTIstatus _x3GetPrdPartObjViaObid
   (MTIstring _class, boolean getParent, string className,
   string partOBID, NvSet customData, ObjectPtr * partObj,
   integer * mfail);

MTIstatus _x3GetPrdPartViaObidDb
   (MTIstring _class, boolean getParent, string className,
   string partOBID, string partDbName, NvSet customData,
   ObjectPtr * partObj, integer * mfail);

MTIstatus _x3GetProductInfo
   (MTIstring _class, boolean getParent, string className,
   string * vProductInfo, integer * mfail);

MTIstatus _x3GetRefObjectInfos
   (MTIstring _class, boolean getParent, string className,
   NVSET nvsObjInfos, string sXmap, ObjectPtr WkBnchObj,
   NVSET * nvsObjOutput, NVSET * nvsPrdOutput, integer * mfail);

MTIstatus _x3GetReferenceInfo
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3GetRelAttrForSaveSes
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr itemObject, SetOfStrings * AttrSlotSet, SetOfStrings * ValueSlotSet,
   integer * mfail);

MTIstatus _x3GetRelAttributeApi
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3GetRelForParts
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr leftPrtObj, ObjectPtr rightPrtObj, NvSet usesInfos,
   ObjectPtr * newRelObj, integer * mfail);

MTIstatus _x3GetRelInfoForCADAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfStrings * LabelSet, SetOfStrings * ValueSet, integer * mfail);

MTIstatus _x3GetRelToBeUpdatedAtClass
   (MTIstring _class, boolean getParent, ObjectPtr FatherAssm,
   string rel_id, ObjectPtr * relObj, integer * mfail);

MTIstatus _x3GetRelevRelViaExpandAtClass
   (MTIstring _class, boolean getParent, ObjectPtr partObj,
   string relObid, ObjectPtr * relObj, integer * mfail);

MTIstatus _x3GetRelevRelViaObid
   (MTIstring _class, boolean getParent, string ClassName,
   string RelOBID, ObjectPtr * Relation, integer * mfail);

MTIstatus _x3GetRelevRelViaObidDb
   (MTIstring _class, boolean getParent, string ClassName,
   string RelOBID, string DataBaseName, ObjectPtr * Relation,
   integer * mfail);

MTIstatus _x3GetSceneFile
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings * fileContents, integer * mfail);

MTIstatus _x3GetSendingObjsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr ctItemObj,
   ObjectPtr WkBnchObj, SetOfObjects * sendingObjs, integer * mfail);

MTIstatus _x3GetSheetNamesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr ModelObject,
   SetOfStrings * SheetList, integer * mfail);

MTIstatus _x3GetSourceCgrFilePathAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   string * sHost, string * sUser, string * sCgrfullPath,
   integer * mfail);

MTIstatus _x3GetSplitComponentsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfObjects * splitComps, integer * mfail);

MTIstatus _x3GetStandardPartInfo
   (MTIstring _class, boolean getParent, string className,
   string partNumber, boolean * bIsStandard, boolean * bExists,
   string * sClassName, string * sObid, integer * mfail);

MTIstatus _x3GetStdDataForCAD
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr this, string objectid, SetOfStrings * attributelist,
   SetOfStrings * valuelist, integer * mfail);

MTIstatus _x3GetStdDataForCADExt
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr this, ObjectPtr docObj, string objectid,
   SetOfStrings * attributelist, SetOfStrings * valuelist, integer * mfail);

MTIstatus _x3GetSubAssRelsForObidAtClass
   (MTIstring _class, boolean getParent, ObjectPtr ctItemObj,
   string partOBID, SetOfObjects * foundRelObjs, integer * mfail);

MTIstatus _x3GetSupplyFilePath
   (MTIstring _class, boolean getParent, string sThisClassName,
   SetOfStrings vObjectObid, SetOfStrings vObjectDbName, SetOfStrings vObjectClassName,
   string sFileName, string sInfoFromCAD, string * sHost,
   string * sFullPath, string * sReturnCode, integer * mfail);

MTIstatus _x3GetTargetCATIAPref
   (MTIstring _class, boolean getParent, string classname,
   string * vCATIASystem, integer * mfail);

MTIstatus _x3GetTempVaultLocVSAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _x3GetTempsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _x3GetTrafosAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfStrings * indexSet, SetOfStrings * trafoSet, string * unit,
   integer * mfail);

MTIstatus _x3GetTrafosOfTableAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfStrings * indexSet, SetOfStrings * trafoSet, integer * mfail);

MTIstatus _x3GetUdfPartForCatalog
   (MTIstring _class, boolean getParent, string sWkBnchClass,
   string sClgClassName, string sClgOBID, string sClgDbName,
   ObjectPtr * pObj, integer * mfail);

MTIstatus _x3GetV5ProductTemplateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr * tplObj, integer * mfail);

MTIstatus _x3GetViewerFileAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisRep,
   ObjectPtr thisObj, string viewFormat, ObjectPtr workBench,
   string * sHost, string * sUser, string * sFullPath,
   string * sNewFileName, integer * iStatus, integer * mfail);

MTIstatus _x3GetViewerFileContent
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings * fileContents, integer * mfail);

MTIstatus _x3GetViewerFileNamesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string valueSetName, string lvAttribute, string realClass,
   ObjectPtr realObj, SetOfStrings extraStr, SetOfObjects extraObj,
   boolean * uiSort, string * uiTextId, NVSET * uiTextInserts,
   SetOfStrings * values, integer * mfail);

MTIstatus _x3GetWBInfo
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3GetWBItems
   (MTIstring _class, boolean getParent, string classname,
   SetOfObjects * ctItems, integer * mfail);

MTIstatus _x3GetWayToRoot
   (MTIstring _class, boolean getParent, string ClassName,
   string CatiaItemID, SetOfObjects CtItDpRelObjSet, SetOfStrings * assmStrcList,
   integer * mfail);

MTIstatus _x3GetWorkBenchClass
   (MTIstring _class, boolean getParent, string className,
   string * WkBnchClass, integer * mfail);

MTIstatus _x3GetWorkLocForCreate
   (MTIstring _class, boolean getParent, string classname,
   string * worklocation, integer * mfail);

MTIstatus _x3GetWorkLocationInfo
   (MTIstring _class, boolean getParent, string classname,
   string worklocation, string username, string * worklocDir,
   string * worklocHost, integer * mfail);

MTIstatus _x3GetsCMIProtocol
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings * l0PartnerObjMgrSet, integer * mfail);

MTIstatus _x3HasSendingObjsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr ctItemObj,
   boolean * bSendingMode, integer * mfail);

MTIstatus _x3HasTrafoAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   ObjectPtr itemObj, boolean * bHasTrafo, integer * mfail);

MTIstatus _x3HelpOnProduct
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3HighlightAssemblies
   (MTIstring _class, boolean getParent, string ClassName,
   SetOfStrings vStrSet, integer * mfail);

MTIstatus _x3HighlightAssyInWb
   (MTIstring _class, boolean getParent, string ClassName,
   string PartOBID, string WayToRoot, integer * mfail);

MTIstatus _x3HighlightInWB
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3HighlightModelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3HighlightProductAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3HighlightSetOfModels
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3HilightModelInWb
   (MTIstring _class, boolean getParent, string ClassName,
   string ModelOBID, string PartOBID, string WayToRoot,
   string DocrelId, integer * mfail);

MTIstatus _x3HilightModelsByLstnr
   (MTIstring _class, boolean getParent, string ClassName,
   SetOfStrings vStrSet, integer * mfail);

MTIstatus _x3ImportCMIFile
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3ImportCustomFile
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3ImportFile
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3ImportFileToWB
   (MTIstring _class, boolean getParent, string className,
   string fileName, integer * mfail);

MTIstatus _x3IncreaseRelQtyAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   ObjectPtr leftPrtObj, ObjectPtr rightPrtObj, integer * mfail);

MTIstatus _x3Inflate4DNavNameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr self,
   string * RelativePath, integer * mfail);

MTIstatus _x3InflateExMapNameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3InflateExMapNameV5AtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3InitiateDocCreateMsg
   (MTIstring _class, boolean getParent, string className,
   string vWorkMode, SetOfStrings vStrSet, integer * mfail);

MTIstatus _x3InitiateDocMulCreMsg
   (MTIstring _class, boolean getParent, string ClassName,
   string vWorkMode, SetOfStrings vStrSet, integer * mfail);

MTIstatus _x3InitiateReadMsg
   (MTIstring _class, boolean getParent, string className,
   string vWorkMode, SetOfStrings vStrSet, integer * mfail);

MTIstatus _x3InitiateReadTmpMsg
   (MTIstring _class, boolean getParent, string className,
   string vWorkMode, SetOfStrings vStrSet, integer * mfail);

MTIstatus _x3InitiateReplaceMsg
   (MTIstring _class, boolean getParent, string className,
   string vWorkMode, SetOfStrings vStrSet, integer * mfail);

MTIstatus _x3InitiateRereadMsg
   (MTIstring _class, boolean getParent, string className,
   string vWorkMode, SetOfStrings vStrSet, integer * mfail);

MTIstatus _x3InitiateWPChangeMsg
   (MTIstring _class, boolean getParent, string className,
   string vWorkMode, SetOfStrings vStrSet, integer * mfail);

MTIstatus _x3InstNameExistAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string sInstanceName, boolean * bInstNameExists, integer * mfail);

MTIstatus _x3IsCatalogReadTypeAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean * bIsCatalogReadType, integer * mfail);

MTIstatus _x3IsCompStrctToChangeAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean * bCompStructChange, integer * mfail);

MTIstatus _x3IsDependedOnByFilesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr modObj,
   SetOfObjects * depOnByFiles, integer * mfail);

MTIstatus _x3IsLinkedWithDesTabAtClass
   (MTIstring _class, boolean getParent, ObjectPtr modelObj,
   ObjectPtr desTabObj, integer * bLinked, integer * mfail);

MTIstatus _x3IsLinkedWithDocumentAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObject,
   ObjectPtr docObject, integer * bLinked, integer * mfail);

MTIstatus _x3IsModel2DAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObject,
   boolean * bIs2DModel, integer * mfail);

MTIstatus _x3IsStandAloneArchiveAtClass
   (MTIstring _class, boolean getParent, ObjectPtr ArchiveObj,
   boolean * bIsStandAlone, integer * mfail);

MTIstatus _x3IsStandardPartAtClass
   (MTIstring _class, boolean getParent, ObjectPtr itemObj,
   string partOBID, boolean * isStandard, integer * mfail);

MTIstatus _x3LinkCatDrwToPartAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   NvSet ModelInfos, SetOfStrings vStats, integer * mfail);

MTIstatus _x3LinkWithDesTabAtClass
   (MTIstring _class, boolean getParent, ObjectPtr catiaObj,
   NvSet ModelInfos, ObjectPtr desTabObj, string sPartClassName,
   string sPartOBID, string sPartDbName, ObjectPtr * relObject,
   SetOfStrings * vStats, integer * mfail);

MTIstatus _x3LinkWithDocumentAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObject,
   ObjectPtr docObject, integer * mfail);

MTIstatus _x3LinkWithDocumentExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObject,
   ObjectPtr docObject, SetOfStrings matrix, ObjectPtr * relObject,
   integer * mfail);

MTIstatus _x3MarkItemAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3MarkItemNIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr CtxObj, boolean bToggle, boolean bMark,
   integer * mfail);

MTIstatus _x3MarkSelectedItems
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects SelectedItems, integer * mfail);

MTIstatus _x3MarkSubTreeAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3MarkTreeNIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr CtxObj, boolean bMark, integer * mfail);

MTIstatus _x3MarkedTo4DNav
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3MarkedToCatia
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3MarkedToView
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3ModelHasPlotFilesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr modObj,
   SetOfObjects * plotObjs, integer * mfail);

MTIstatus _x3MultiDocCreateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WkBnchObj, ObjectPtr commObj, ObjectPtr BackgroundItem,
   integer * mfail);

MTIstatus _x3ObjectHasV5TemplateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean * bHasTemplate, boolean * bIsChangeable, integer * mfail);

MTIstatus _x3OpenAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3PlotFeaturesAreSameAtClass
   (MTIstring _class, boolean getParent, ObjectPtr modObj,
   SetOfStrings plotfeatures, integer * are_same, integer * mfail);

MTIstatus _x3PlotUpdateFeaturesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr modObj,
   ObjectPtr catiaModel, SetOfStrings plotfeatures, integer * mfail);

MTIstatus _x3PltFileBelongsToAtClass
   (MTIstring _class, boolean getParent, ObjectPtr plotObj,
   ObjectPtr * modObj, integer * mfail);

MTIstatus _x3PostProcCreatePrd
   (MTIstring _class, boolean getParent, string className,
   string partNumber, string sPartClassName, string sPartOBID,
   string sPartDbName, string sPrdClassName, string sPrdOBID,
   string sPrdDbName, SetOfStrings * vStats, integer * mfail);

MTIstatus _x3PostProcCreatePrds
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3PrcCATIADeletionECMI
   (MTIstring _class, boolean getParent, string className,
   string childOBID, string childRelOBID, string parentClass,
   string parentOBID, string matrixIndex, SetOfStrings * messageText,
   boolean * messageAdded, integer * mfail);

MTIstatus _x3PrdFileNameInWL
   (MTIstring _class, boolean getParent, string classname,
   string oldFilename, string * newFilename, integer * mfail);

MTIstatus _x3PrepModelsForToCatiaAtClass
   (MTIstring _class, boolean getParent, ObjectPtr WkBnchObj,
   SetOfObjects pSetOfTCTItems, integer * mfail);

MTIstatus _x3PrepPartsForToCatiaAtClass
   (MTIstring _class, boolean getParent, ObjectPtr WkBnchObj,
   string sCadSystem, SetOfStrings pPartObids, SetOfStrings pRel_PartObids,
   SetOfStrings pRel_RelObids, integer * mfail);

MTIstatus _x3PrepViewing
   (MTIstring _class, boolean getParent, string className,
   integer * licKey, integer * licRes, integer * mfail);

MTIstatus _x3ProcessCATIADeletion
   (MTIstring _class, boolean getParent, string className,
   string childOBID, string childRelOBID, string parentClass,
   string parentOBID, string matrixIndex, SetOfStrings statsSet,
   boolean * updateOk, integer * mfail);

MTIstatus _x3ProcessDroppedItemAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WkBenchObj, ObjectPtr commObj, ObjectPtr BackgroundItem,
   integer * mfail);

MTIstatus _x3ProcessOldPlotFilesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr originatingObj,
   SetOfObjects oldPlots, SetOfStrings plotfeatures, ObjectPtr * plotFileObj,
   integer * mfail);

MTIstatus _x3PutAttValueForObject
   (MTIstring _class, boolean getParent, string sClassName,
   SetOfStrings vObjectObid, SetOfStrings vObjectDbName, SetOfStrings vObjectClassName,
   string sAttributeName, string sAttributeValue, string * sReturnCode,
   integer * mfail);

MTIstatus _x3PutAttValueForPosObj
   (MTIstring _class, boolean getParent, string sThisClassName,
   string sInstanceName, SetOfStrings vObjectObid, SetOfStrings vObjectDbName,
   SetOfStrings vObjectClassName, string sAttributeName, string sAttributeValue,
   string * sReturnCode, integer * mfail);

MTIstatus _x3PutAttValueForRelObj
   (MTIstring _class, boolean getParent, string sThisClassName,
   string sInstanceName, string sMatrixIndex, SetOfStrings vObjectObid,
   SetOfStrings vObjectDbName, SetOfStrings vObjectClassName, string sAttributeName,
   string sAttributeValue, string * sReturnCode, integer * mfail);

MTIstatus _x3PutPartAttributeApi
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3PutRelAttributeApi
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3QueryWkBnchCTItem
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3QueryWkBnchModRep
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3Read4DNavFile
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3ReadTmpAssAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WkBnchObj, ObjectPtr commObj, ObjectPtr BackgroundItem,
   integer * mfail);

MTIstatus _x3ReadViewerFile
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3ReceiveUserDefPropsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings vPropDisplaySet, SetOfStrings vPropNameSet, SetOfStrings vPropValueSet,
   integer * mfail);

MTIstatus _x3RefreshItmAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3RefreshObject
   (MTIstring _class, boolean getParent, string ClassName,
   ObjectPtr RefreshObject, ObjectPtr RefreshRelation, integer * mfail);

MTIstatus _x3RelatePlotToModelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr modObj,
   ObjectPtr plotObj, integer * mfail);

MTIstatus _x3RemoveBlackBoxFilesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   SetOfStrings FileNames, SetOfObjects BlackBoxObjs, SetOfObjects BlackBoxRels,
   SetOfStrings * pRemovedFiles, integer * mfail);

MTIstatus _x3RemoveDesTabAtClass
   (MTIstring _class, boolean getParent, ObjectPtr modelObj,
   NvSet ModelInfos, ObjectPtr desTabObj, string sPartClassName,
   string sPartOBID, string sPartDbName, SetOfStrings * vStats,
   integer * mfail);

MTIstatus _x3RemoveDesTabExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr modelObj,
   NvSet ModelInfos, ObjectPtr desTabObj, string path,
   string sPartClassName, string sPartOBID, string sPartDbName,
   SetOfStrings * vStats, integer * mfail);

MTIstatus _x3RepSubAssAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WkBnchObj, ObjectPtr commObj, ObjectPtr BackgroundItem,
   integer * mfail);

MTIstatus _x3ReplaceEmbeddedPrdAtClass
   (MTIstring _class, boolean getParent, ObjectPtr PartObj,
   ObjectPtr CTItemObj, boolean * bReplaceEmbedded, integer * mfail);

MTIstatus _x3ReplaceInstNmeFrMod
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr productObj, ObjectPtr partObj, ObjectPtr oldModelObj,
   ObjectPtr newModelObj, string oldInstanceName, string newInstanceName,
   integer * mfail);

MTIstatus _x3RestoreWBContentsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr WkBnchObj, ObjectPtr initObj, ObjectPtr BackgroundItem,
   integer * mfail);

MTIstatus _x3RestoreWBPost
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr PrevObj, integer * mfail);

MTIstatus _x3RestoreWBPre
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr * PrevObj, integer * mfail);

MTIstatus _x3RestoreWBSubtree
   (MTIstring _class, boolean getParent, string ClassName,
   ObjectPtr catiaItem, string itemOBID, SetOfStrings vObjMgrSet,
   ObjectPtr ctxObj, ObjectPtr WkBnchObj, ObjectPtr BackgroundItem,
   string slastseq, integer * p_bErrors, SetOfStrings MissedModels,
   integer * mfail);

MTIstatus _x3SaveAsCATDrawFrFile
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3SaveAsCATPartFrFile
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3SaveAsCATPartV4FrFl
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3SaveAsFromFile
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3SaveAssm
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings vStrSet, boolean * updateOk, SetOfStrings * vStrSet_Send,
   integer * mfail);

MTIstatus _x3SaveAssmMg
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings vStrSet, boolean * updateOk, SetOfStrings * vStrSet_Send,
   integer * mfail);

MTIstatus _x3SaveCatArcPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfStrings doccomps, SetOfStrings ext_locations, integer * mfail);

MTIstatus _x3SaveCatCgrPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfStrings doccomps, SetOfStrings ext_locations, integer * mfail);

MTIstatus _x3SaveCatDrwPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfStrings doccomps, SetOfStrings ext_locations, integer * mfail);

MTIstatus _x3SaveCatPrtPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfStrings doccomps, SetOfStrings ext_locations, integer * mfail);

MTIstatus _x3SaveCatRepPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfStrings doccomps, SetOfStrings ext_locations, integer * mfail);

MTIstatus _x3SaveComponentAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   string sObjComponent, string sObjCatModInf, SetOfStrings * vStats,
   boolean * updateOk, integer * mfail);

MTIstatus _x3SaveComponentInMPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   string catia_exchange_file, integer * mfail);

MTIstatus _x3SaveComponentPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   integer * mfail);

MTIstatus _x3SaveContainerAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   string sObjCnt, NvSet cntModelInfos, integer * mfail);

MTIstatus _x3SaveContainerInMPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   string catia_exchange_file, integer * mfail);

MTIstatus _x3SaveContainerPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   integer * mfail);

MTIstatus _x3SaveModelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfStrings Model_comps, SetOfStrings Ext_locations, SetOfStrings projects,
   NvSet ModelInfos, SetOfStrings * vStats, boolean * updateOk,
   integer * mfail);

MTIstatus _x3SaveModelECMIPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   SetOfStrings * messageText, boolean * messageAdded, integer * mfail);

MTIstatus _x3SaveModelInMPAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfStrings doccomps, SetOfStrings ext_locations, integer * mfail);

MTIstatus _x3SaveModelMg
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings vStrSet, integer * mfail);

MTIstatus _x3SaveModelPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   SetOfStrings doccomps, SetOfStrings ext_locations, integer * mfail);

MTIstatus _x3SaveProductECMIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   SetOfStrings * messageText, boolean * messageAdded, integer * mfail);

MTIstatus _x3SaveProductECMIPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   SetOfStrings * messageText, boolean * messageAdded, integer * mfail);

MTIstatus _x3SendCustomAttrPref
   (MTIstring _class, boolean getParent, string className,
   boolean * bSendCusAttrs, integer * mfail);

MTIstatus _x3SendRequestXT0
   (MTIstring _class, boolean getParent, string className,
   string hostName, string requestType, integer * mfail);

MTIstatus _x3SendUserDefPropsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * vPropDisplaySet, SetOfStrings * vPropNameSet, SetOfStrings * vPropValueSet,
   integer * mfail);

MTIstatus _x3SendUserDefPropsExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   SetOfStrings * vPropDisplaySet, SetOfStrings * vPropNameSet, SetOfStrings * vPropValueSet,
   SetOfStrings * vPropDelSet, integer * mfail);

MTIstatus _x3SetCATIADefinitionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string sDefinition, integer * mfail);

MTIstatus _x3SetCATIADescriptionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string sDescription, integer * mfail);

MTIstatus _x3SetCATIANomenclatureAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string sNomenclature, integer * mfail);

MTIstatus _x3SetCATIARevisionAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string Revision, integer * mfail);

MTIstatus _x3SetCatiaFileExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string sFileName, integer * mfail);

MTIstatus _x3SetCatiaFileToDlgAtClass
   (MTIstring _class, boolean getParent, ObjectPtr dialogObj,
   string sCatiaFileName, integer * mfail);

MTIstatus _x3SetCatiaModelSizeAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _x3SetCatiaProjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string catia_project, integer * mfail);

MTIstatus _x3SetCmiAttrModInfAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   NvSet ModelInfos, integer * mfail);

MTIstatus _x3SetCmpDocDlgAttr
   (MTIstring _class, boolean getParent, string sClassName,
   string sDocName, ObjectPtr dialogObject, integer * mfail);

MTIstatus _x3SetComponentFlagAtClass
   (MTIstring _class, boolean getParent, ObjectPtr PartObj,
   boolean bIsComponent, integer * mfail);

MTIstatus _x3SetComponentFlags
   (MTIstring _class, boolean getParent, string ClassName,
   NvSet * attributeSet, integer * mfail);

MTIstatus _x3SetCusAttrModInfAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   NvSet ModelInfos, integer * mfail);

MTIstatus _x3SetDialogAttrs
   (MTIstring _class, boolean getParent, string className,
   NvSet pAttributeSet, ObjectPtr dialogObject, integer * mfail);

MTIstatus _x3SetFeatureExtFromCAD
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr this, string objectid, SetOfStrings SetOfContainerIdsMod,
   SetOfStrings SetOfClientIdsMod, SetOfStrings SetOfFeatureTypesMod, SetOfStrings SetOfFeatureAttrsMod,
   SetOfStrings SetOfFeatureValuesMod, integer * mfail);

MTIstatus _x3SetInstNameForIndexAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string index, string sInstanceName, integer * mfail);

MTIstatus _x3SetLastCatiaUpdateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _x3SetModelInfoDataAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   string sModelInfo, SetOfStrings * vStats, boolean * updateOk,
   integer * mfail);

MTIstatus _x3SetModelInfoData2AtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   NvSet ModelInfo, integer * mfail);

MTIstatus _x3SetPrdDocDlgAttr
   (MTIstring _class, boolean getParent, string sClassName,
   string sDocName, ObjectPtr dialogObject, integer * mfail);

MTIstatus _x3SetRestoreFlagAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3SetShowNeighbours
   (MTIstring _class, boolean getParent, string className,
   SetOfObjects SelectedItems, integer * mfail);

MTIstatus _x3SetStdAttrModInfAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   NvSet ModelInfos, integer * mfail);

MTIstatus _x3SetTrafoAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string matrix, integer * mfail);

MTIstatus _x3SetWorkplaneAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3ShowContainedModlsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3ShowModelsOfVol
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3ShowNeighboursAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3ShowUpdTrafoTxtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr assmStrcObj,
   string msgNr, NvSet parms, SetOfStrings * vStats,
   integer * mfail);

MTIstatus _x3SortModelsByCusAtClass
   (MTIstring _class, boolean getParent, ObjectPtr GenItemObj,
   SetOfObjects * modelsOfPart, SetOfObjects * ModRepObjSet, integer * mfail);

MTIstatus _x3StoreChildInstNames
   (MTIstring _class, boolean getParent, string classname,
   ObjectPtr partObj, ObjectPtr productObj, SetOfStrings vInstanceNameSet,
   SetOfStrings vPartPartNumberSet, SetOfStrings vModelInstNamesSet, SetOfStrings vNewModelInstNamesSet,
   SetOfStrings vModelPartNumberSet, SetOfStrings vModelOldObidSet, SetOfStrings vModelNewObidSet,
   integer * mfail);

MTIstatus _x3StoreSupplyFile
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3StoreSupplyFileCus
   (MTIstring _class, boolean getParent, string sThisClassName,
   SetOfStrings vObjectObid, SetOfStrings vObjectDbName, SetOfStrings vObjectClassName,
   string sFileHost, string sFullPath, string sInfoFromCAD,
   string * sReturnCode, integer * mfail);

MTIstatus _x3StoreTreeAllowedAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   boolean * bAllowed, integer * mfail);

MTIstatus _x3StoreWBContentsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _x3StoreWBSubtree
   (MTIstring _class, boolean getParent, string ClassName,
   ObjectPtr catiaItem, string partOBID, SetOfStrings * vObjMgrSet,
   integer * mfail);

MTIstatus _x3To4DNav
   (MTIstring _class, boolean getParent, string className,
   boolean usex0MarkedInWkbnch, integer * mfail);

MTIstatus _x3ToCatia
   (MTIstring _class, boolean getParent, string className,
   boolean usex0MarkedInWkbnch, integer * mfail);

MTIstatus _x3ToCatiaPre
   (MTIstring _class, boolean getParent, string classname,
   string ComStat, integer * mfail);

MTIstatus _x3ToEPlot
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3ToEPlotV5
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3ToView
   (MTIstring _class, boolean getParent, string className,
   boolean usex0MarkedInWkbnch, integer * mfail);

MTIstatus _x3UnmarkAll
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3UnmarkSubTreeAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _x3UpdCreCatalogFrFile
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3UpdateAllIconsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr ctxObj, integer * mfail);

MTIstatus _x3UpdateAllOccurenciesAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr ctxObj, integer * mfail);

MTIstatus _x3UpdateCatalogPostAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   NVSET nvsObjInfos, integer * mfail);

MTIstatus _x3UpdateCatiaCatalogAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisCatalogObj,
   string xmapfilename, string hostname, string username,
   NVSET nvsObjInfos, integer * mfail);

MTIstatus _x3UpdateCatiaFiles
   (MTIstring _class, boolean getParent, string ClassName,
   SetOfObjects vParentProducts, SetOfStrings vParentPartNumbers, SetOfStrings vInstanceParentPNs,
   SetOfStrings vInstanceOldNames, SetOfStrings vInstanceNewNames, SetOfObjects vChildObjects,
   SetOfStrings vChildOldPartNumbers, SetOfStrings vChildPartNumbers, SetOfStrings vChildOldFileName,
   string sCatiaEnvironment, SetOfStrings * vStats, integer * mfail);

MTIstatus _x3UpdateDepV5AtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   NvSet ModelInfo, SetOfStrings * vStats, boolean * updateOk,
   integer * mfail);

MTIstatus _x3UpdateDocForECMIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string strDocNamesList, string strDocValuesList, SetOfStrings * messageText,
   boolean * messageAdded, integer * mfail);

MTIstatus _x3UpdateFileForECMIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   string strModelSize, string strLastUpdate, string strFileNamesList,
   string strFileValuesList, SetOfStrings * messageText, boolean * messageAdded,
   integer * mfail);

MTIstatus _x3UpdateFromFile
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3UpdateObjectAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   ObjectPtr ctxObj, integer * mfail);

MTIstatus _x3UpdateTrafoAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string matrix_index, SetOfStrings matric, string unit,
   integer * mfail);

MTIstatus _x3UpdateTrafoExtAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string partNumberLeft, string partNumberRight, string matrix_index,
   SetOfStrings matric, string unit, SetOfStrings * vStats,
   integer * mfail);

MTIstatus _x3UpdateWBFromFile
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3UseCCS
   (MTIstring _class, boolean getParent, string classname,
   boolean * bUseCCS, integer * mfail);

MTIstatus _x3UseCgrFileAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisPtr,
   boolean * bUseCgr, string * sUseRelCache, integer * mfail);

MTIstatus _x3UseCustomDocCreate
   (MTIstring _class, boolean getParent, string classname,
   boolean * useCustom, integer * mfail);

MTIstatus _x3UseEmbeddedPrdECMIAtClass
   (MTIstring _class, boolean getParent, ObjectPtr thisObj,
   boolean * bUseEmbedded, integer * mfail);

MTIstatus _x3UseEmbeddedProductAtClass
   (MTIstring _class, boolean getParent, ObjectPtr self,
   ObjectPtr CTItemObj, boolean * bUseEmbedded, integer * mfail);

MTIstatus _x3UseMultiQtyRel
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr parentObj, ObjectPtr childObj, NvSet relInfos,
   boolean * bUseMultiQtyRel, integer * mfail);

MTIstatus _x3UsePdmStructure
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3ValArcNames
   (MTIstring _class, boolean getParent, string classname,
   string parentPartnumber, NvSet vObjectSet, integer * mfail);

MTIstatus _x3ValAttachV5ObjInst
   (MTIstring _class, boolean getParent, string strClassname,
   NVSET nvsObjInfos, NVSET nvsParentObjInfos, boolean * pbIsValid,
   string * pStrCatiaMsg, integer * mfail);

MTIstatus _x3ValCreateForDocAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   string filePath, integer * mfail);

MTIstatus _x3ValCreateV5Obj
   (MTIstring _class, boolean getParent, string strClassname,
   NVSET nvsObjInfos, NVSET nvsParentObjInfos, boolean * pbIsValid,
   string * pStrCatiaMsg, integer * mfail);

MTIstatus _x3ValDropV5ObjInst
   (MTIstring _class, boolean getParent, string strClassname,
   NVSET nvsObjInfos, NVSET nvsParentObjInfos, boolean * pbIsValid,
   string * pStrCatiaMsg, integer * mfail);

MTIstatus _x3ValPrepareV5Obj
   (MTIstring _class, boolean getParent, string strClassname,
   NVSET nvsObjInfos, boolean * pbIsValid, string * pStrCatiaMsg,
   integer * mfail);

MTIstatus _x3ValUpdateV5Obj
   (MTIstring _class, boolean getParent, string strClassname,
   NVSET nvsObjInfos, boolean * pbIsValid, string * pStrCatiaMsg,
   integer * mfail);

MTIstatus _x3ValUpdateV5ObjInst
   (MTIstring _class, boolean getParent, string strClassname,
   NVSET nvsObjInfos, NVSET nvsParentObjInfos, boolean * pbIsValid,
   string * pStrCatiaMsg, integer * mfail);

MTIstatus _x3ValUseV5Obj
   (MTIstring _class, boolean getParent, string strClassname,
   NVSET nvsObjInfos, NVSET nvsParentObjInfos, boolean * pbIsValid,
   string * pStrCatiaMsg, integer * mfail);

MTIstatus _x3ValidateArchive
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3ValidatePrdRelCreateAtClass
   (MTIstring _class, boolean getParent, ObjectPtr self,
   integer * mfail);

MTIstatus _x3ValidateSaveAsAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   NvSet ModelInfos, integer * mfail);

MTIstatus _x3ValidateSaveModelAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _x3ValidateSavePartAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _x3ValidateUpdateDocAtClass
   (MTIstring _class, boolean getParent, ObjectPtr this,
   integer * mfail);

MTIstatus _x3ValidateV5Nodes
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3WriteCMIFile
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings parameterSet, SetOfStrings * outputSet, integer * mfail);

MTIstatus _x3WriteEPlot
   (MTIstring _class, boolean getParent, string className,
   SetOfStrings DraftsList, SetOfStrings ViewsList, SetOfStrings FramesList,
   ObjectPtr ModelObject, integer * mfail);

MTIstatus _x3WriteEPlotV5
   (MTIstring _class, boolean getParent, string className,
   ObjectPtr ModelObject, integer * mfail);

MTIstatus _x3WriteModToSceneStr
   (MTIstring _class, boolean getParent, string ClassName,
   string modOBID, string RelativePath, string dpath,
   SetOfStrings * set, integer * mfail);

MTIstatus _x3WriteToEnvision
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3WriteToEnvisionPost
   (MTIstring _class, boolean getParent, string className,
   string sfilename, string sfolder, string sfilenamewithfolder,
   integer * mfail);

MTIstatus _x3sCmiExport
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);

MTIstatus _x3sCmiImport
   (MTIstring _class, boolean getParent, string className,
   integer * mfail);
#endif /* _LCINTERP_ */

/*
 *  Message Macro Definitions.
 */

#define InflateModelname(self, mfail) \
        _InflateModelnameAtClass(NULL, FALSE, self, mfail)
#define InflateModelnameAtClass(class, self, mfail) \
        _InflateModelnameAtClass(class, FALSE, self, mfail)
#define InflateModelnameAtParent(class, self, mfail) \
        _InflateModelnameAtClass(class, TRUE, self, mfail)

#define g3GetAllProductFiles(thisPtr, WorkBnchObj, productsOfPart, mfail) \
        _g3GetAllProductFilesAtClass(NULL, FALSE, thisPtr, WorkBnchObj, productsOfPart, mfail)
#define g3GetAllProductFilesAtClass(class, thisPtr, WorkBnchObj, productsOfPart, mfail) \
        _g3GetAllProductFilesAtClass(class, FALSE, thisPtr, WorkBnchObj, productsOfPart, mfail)
#define g3GetAllProductFilesAtParent(class, thisPtr, WorkBnchObj, productsOfPart, mfail) \
        _g3GetAllProductFilesAtClass(class, TRUE, thisPtr, WorkBnchObj, productsOfPart, mfail)

#define g3SetPortAndHost(ClassName, WindowId, Host, HostIpAdr, Port, mfail) \
        _g3SetPortAndHost(ClassName, FALSE, ClassName, WindowId, Host, HostIpAdr, Port, mfail)
#define g3SetPortAndHostAtParent(_class, ClassName, WindowId, Host, HostIpAdr, Port, mfail) \
        _g3SetPortAndHost(_class, TRUE, ClassName, WindowId, Host, HostIpAdr, Port, mfail)

#define x34DNavCopyAllowed(this, pAllowed, mfail) \
        _x34DNavCopyAllowedAtClass(NULL, FALSE, this, pAllowed, mfail)
#define x34DNavCopyAllowedAtClass(class, this, pAllowed, mfail) \
        _x34DNavCopyAllowedAtClass(class, FALSE, this, pAllowed, mfail)
#define x34DNavCopyAllowedAtParent(class, this, pAllowed, mfail) \
        _x34DNavCopyAllowedAtClass(class, TRUE, this, pAllowed, mfail)

#define x3ActivateModel(thisObj, mfail) \
        _x3ActivateModelAtClass(NULL, FALSE, thisObj, mfail)
#define x3ActivateModelAtClass(class, thisObj, mfail) \
        _x3ActivateModelAtClass(class, FALSE, thisObj, mfail)
#define x3ActivateModelAtParent(class, thisObj, mfail) \
        _x3ActivateModelAtClass(class, TRUE, thisObj, mfail)

#define x3AddBBoxFiles(thisPtr, WkBnchObj, modelsOfPart, relsOfPart, mfail) \
        _x3AddBBoxFilesAtClass(NULL, FALSE, thisPtr, WkBnchObj, modelsOfPart, relsOfPart, mfail)
#define x3AddBBoxFilesAtClass(class, thisPtr, WkBnchObj, modelsOfPart, relsOfPart, mfail) \
        _x3AddBBoxFilesAtClass(class, FALSE, thisPtr, WkBnchObj, modelsOfPart, relsOfPart, mfail)
#define x3AddBBoxFilesAtParent(class, thisPtr, WkBnchObj, modelsOfPart, relsOfPart, mfail) \
        _x3AddBBoxFilesAtClass(class, TRUE, thisPtr, WkBnchObj, modelsOfPart, relsOfPart, mfail)

#define x3AddBlackBoxFiles(thisPtr, BlackBoxOBID, PartNumberList, FileNameList, FileTypeList, pNewBlackBoxObjs, mfail) \
        _x3AddBlackBoxFilesAtClass(NULL, FALSE, thisPtr, BlackBoxOBID, PartNumberList, FileNameList, FileTypeList, pNewBlackBoxObjs, mfail)
#define x3AddBlackBoxFilesAtClass(class, thisPtr, BlackBoxOBID, PartNumberList, FileNameList, FileTypeList, pNewBlackBoxObjs, mfail) \
        _x3AddBlackBoxFilesAtClass(class, FALSE, thisPtr, BlackBoxOBID, PartNumberList, FileNameList, FileTypeList, pNewBlackBoxObjs, mfail)
#define x3AddBlackBoxFilesAtParent(class, thisPtr, BlackBoxOBID, PartNumberList, FileNameList, FileTypeList, pNewBlackBoxObjs, mfail) \
        _x3AddBlackBoxFilesAtClass(class, TRUE, thisPtr, BlackBoxOBID, PartNumberList, FileNameList, FileTypeList, pNewBlackBoxObjs, mfail)

#define x3AddCmpData(thisPtr, CmpDataObj, mfail) \
        _x3AddCmpDataAtClass(NULL, FALSE, thisPtr, CmpDataObj, mfail)
#define x3AddCmpDataAtClass(class, thisPtr, CmpDataObj, mfail) \
        _x3AddCmpDataAtClass(class, FALSE, thisPtr, CmpDataObj, mfail)
#define x3AddCmpDataAtParent(class, thisPtr, CmpDataObj, mfail) \
        _x3AddCmpDataAtClass(class, TRUE, thisPtr, CmpDataObj, mfail)

#define x3AddCmpDoc(thisPtr, CmpDocObj, mfail) \
        _x3AddCmpDocAtClass(NULL, FALSE, thisPtr, CmpDocObj, mfail)
#define x3AddCmpDocAtClass(class, thisPtr, CmpDocObj, mfail) \
        _x3AddCmpDocAtClass(class, FALSE, thisPtr, CmpDocObj, mfail)
#define x3AddCmpDocAtParent(class, thisPtr, CmpDocObj, mfail) \
        _x3AddCmpDocAtClass(class, TRUE, thisPtr, CmpDocObj, mfail)

#define x3AddMarkedToCatia(className, mfail) \
        _x3AddMarkedToCatia(className, FALSE, className, mfail)
#define x3AddMarkedToCatiaAtParent(_class, className, mfail) \
        _x3AddMarkedToCatia(_class, TRUE, className, mfail)

#define x3AddModelFiles(thisPtr, WkBnchObj, modelsOfPart, relsOfPart, mfail) \
        _x3AddModelFilesAtClass(NULL, FALSE, thisPtr, WkBnchObj, modelsOfPart, relsOfPart, mfail)
#define x3AddModelFilesAtClass(class, thisPtr, WkBnchObj, modelsOfPart, relsOfPart, mfail) \
        _x3AddModelFilesAtClass(class, FALSE, thisPtr, WkBnchObj, modelsOfPart, relsOfPart, mfail)
#define x3AddModelFilesAtParent(class, thisPtr, WkBnchObj, modelsOfPart, relsOfPart, mfail) \
        _x3AddModelFilesAtClass(class, TRUE, thisPtr, WkBnchObj, modelsOfPart, relsOfPart, mfail)

#define x3AddPrdData(thisPtr, PrdDataObj, mfail) \
        _x3AddPrdDataAtClass(NULL, FALSE, thisPtr, PrdDataObj, mfail)
#define x3AddPrdDataAtClass(class, thisPtr, PrdDataObj, mfail) \
        _x3AddPrdDataAtClass(class, FALSE, thisPtr, PrdDataObj, mfail)
#define x3AddPrdDataAtParent(class, thisPtr, PrdDataObj, mfail) \
        _x3AddPrdDataAtClass(class, TRUE, thisPtr, PrdDataObj, mfail)

#define x3AddPrdDataECMI(thisPtr, PrdDataObj, messageText, messageAdded, mfail) \
        _x3AddPrdDataECMIAtClass(NULL, FALSE, thisPtr, PrdDataObj, messageText, messageAdded, mfail)
#define x3AddPrdDataECMIAtClass(class, thisPtr, PrdDataObj, messageText, messageAdded, mfail) \
        _x3AddPrdDataECMIAtClass(class, FALSE, thisPtr, PrdDataObj, messageText, messageAdded, mfail)
#define x3AddPrdDataECMIAtParent(class, thisPtr, PrdDataObj, messageText, messageAdded, mfail) \
        _x3AddPrdDataECMIAtClass(class, TRUE, thisPtr, PrdDataObj, messageText, messageAdded, mfail)

#define x3AddPrdDoc(thisPtr, PrdDocObj, mfail) \
        _x3AddPrdDocAtClass(NULL, FALSE, thisPtr, PrdDocObj, mfail)
#define x3AddPrdDocAtClass(class, thisPtr, PrdDocObj, mfail) \
        _x3AddPrdDocAtClass(class, FALSE, thisPtr, PrdDocObj, mfail)
#define x3AddPrdDocAtParent(class, thisPtr, PrdDocObj, mfail) \
        _x3AddPrdDocAtClass(class, TRUE, thisPtr, PrdDocObj, mfail)

#define x3AddPrdDocECMI(thisPtr, PrdDocObj, messageText, messageAdded, mfail) \
        _x3AddPrdDocECMIAtClass(NULL, FALSE, thisPtr, PrdDocObj, messageText, messageAdded, mfail)
#define x3AddPrdDocECMIAtClass(class, thisPtr, PrdDocObj, messageText, messageAdded, mfail) \
        _x3AddPrdDocECMIAtClass(class, FALSE, thisPtr, PrdDocObj, messageText, messageAdded, mfail)
#define x3AddPrdDocECMIAtParent(class, thisPtr, PrdDocObj, messageText, messageAdded, mfail) \
        _x3AddPrdDocECMIAtClass(class, TRUE, thisPtr, PrdDocObj, messageText, messageAdded, mfail)

#define x3AddTempV5(className, parameterSet, outputSet, mfail) \
        _x3AddTempV5(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3AddTempV5AtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3AddTempV5(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3AddToCatia(className, mfail) \
        _x3AddToCatia(className, FALSE, className, mfail)
#define x3AddToCatiaAtParent(_class, className, mfail) \
        _x3AddToCatia(_class, TRUE, className, mfail)

#define x3AddTrafo(this, trafo, newIndex, mfail) \
        _x3AddTrafoAtClass(NULL, FALSE, this, trafo, newIndex, mfail)
#define x3AddTrafoAtClass(class, this, trafo, newIndex, mfail) \
        _x3AddTrafoAtClass(class, FALSE, this, trafo, newIndex, mfail)
#define x3AddTrafoAtParent(class, this, trafo, newIndex, mfail) \
        _x3AddTrafoAtClass(class, TRUE, this, trafo, newIndex, mfail)

#define x3AllTo4DNav(className, mfail) \
        _x3AllTo4DNav(className, FALSE, className, mfail)
#define x3AllTo4DNavAtParent(_class, className, mfail) \
        _x3AllTo4DNav(_class, TRUE, className, mfail)

#define x3AllToCatia(className, mfail) \
        _x3AllToCatia(className, FALSE, className, mfail)
#define x3AllToCatiaAtParent(_class, className, mfail) \
        _x3AllToCatia(_class, TRUE, className, mfail)

#define x3AllToView(className, mfail) \
        _x3AllToView(className, FALSE, className, mfail)
#define x3AllToViewAtParent(_class, className, mfail) \
        _x3AllToView(_class, TRUE, className, mfail)

#define x3AnswerToListener(className, vHostIpAdr, port, answer, objMgrSet, mfail) \
        _x3AnswerToListener(className, FALSE, className, vHostIpAdr, port, answer, objMgrSet, mfail)
#define x3AnswerToListenerAtParent(_class, className, vHostIpAdr, port, answer, objMgrSet, mfail) \
        _x3AnswerToListener(_class, TRUE, className, vHostIpAdr, port, answer, objMgrSet, mfail)

#define x3AssCmdSendObjMgr(className, vCommand, errMsg, objMgrSet, mfail) \
        _x3AssCmdSendObjMgr(className, FALSE, className, vCommand, errMsg, objMgrSet, mfail)
#define x3AssCmdSendObjMgrAtParent(_class, className, vCommand, errMsg, objMgrSet, mfail) \
        _x3AssCmdSendObjMgr(_class, TRUE, className, vCommand, errMsg, objMgrSet, mfail)

#define x3AssImpSendObjMgr(className, vCommand, vCatiaHost, dhost, duser, transfer_map, objMgrSet, mfail) \
        _x3AssImpSendObjMgr(className, FALSE, className, vCommand, vCatiaHost, dhost, duser, transfer_map, objMgrSet, mfail)
#define x3AssImpSendObjMgrAtParent(_class, className, vCommand, vCatiaHost, dhost, duser, transfer_map, objMgrSet, mfail) \
        _x3AssImpSendObjMgr(_class, TRUE, className, vCommand, vCatiaHost, dhost, duser, transfer_map, objMgrSet, mfail)

#define x3AssReadSendObjMgr(className, vCommand, vCatiaHost, dhost, duser, x0ComCatStatus, pSetOfStrings, pSetOfStrings2, usex0MarkedInWkbnch, scustomattr, bSetLink, mfail) \
        _x3AssReadSendObjMgr(className, FALSE, className, vCommand, vCatiaHost, dhost, duser, x0ComCatStatus, pSetOfStrings, pSetOfStrings2, usex0MarkedInWkbnch, scustomattr, bSetLink, mfail)
#define x3AssReadSendObjMgrAtParent(_class, className, vCommand, vCatiaHost, dhost, duser, x0ComCatStatus, pSetOfStrings, pSetOfStrings2, usex0MarkedInWkbnch, scustomattr, bSetLink, mfail) \
        _x3AssReadSendObjMgr(_class, TRUE, className, vCommand, vCatiaHost, dhost, duser, x0ComCatStatus, pSetOfStrings, pSetOfStrings2, usex0MarkedInWkbnch, scustomattr, bSetLink, mfail)

#define x3AttOrUpdBlackBox(thisPtr, objMgrSet, mfail) \
        _x3AttOrUpdBlackBoxAtClass(NULL, FALSE, thisPtr, objMgrSet, mfail)
#define x3AttOrUpdBlackBoxAtClass(class, thisPtr, objMgrSet, mfail) \
        _x3AttOrUpdBlackBoxAtClass(class, FALSE, thisPtr, objMgrSet, mfail)
#define x3AttOrUpdBlackBoxAtParent(class, thisPtr, objMgrSet, mfail) \
        _x3AttOrUpdBlackBoxAtClass(class, TRUE, thisPtr, objMgrSet, mfail)

#define x3AttachBlackBoxCmd(className, parameterSet, outputSet, mfail) \
        _x3AttachBlackBoxCmd(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3AttachBlackBoxCmdAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3AttachBlackBoxCmd(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3AttachBlackBoxFiles(thisPtr, blackBoxFiles, mfail) \
        _x3AttachBlackBoxFilesAtClass(NULL, FALSE, thisPtr, blackBoxFiles, mfail)
#define x3AttachBlackBoxFilesAtClass(class, thisPtr, blackBoxFiles, mfail) \
        _x3AttachBlackBoxFilesAtClass(class, FALSE, thisPtr, blackBoxFiles, mfail)
#define x3AttachBlackBoxFilesAtParent(class, thisPtr, blackBoxFiles, mfail) \
        _x3AttachBlackBoxFilesAtClass(class, TRUE, thisPtr, blackBoxFiles, mfail)

#define x3AttachBlackBoxToPart(thisPtr, objMgrSet, mfail) \
        _x3AttachBlackBoxToPartAtClass(NULL, FALSE, thisPtr, objMgrSet, mfail)
#define x3AttachBlackBoxToPartAtClass(class, thisPtr, objMgrSet, mfail) \
        _x3AttachBlackBoxToPartAtClass(class, FALSE, thisPtr, objMgrSet, mfail)
#define x3AttachBlackBoxToPartAtParent(class, thisPtr, objMgrSet, mfail) \
        _x3AttachBlackBoxToPartAtClass(class, TRUE, thisPtr, objMgrSet, mfail)

#define x3BrowseBlackBoxFiles(thisObj, mfail) \
        _x3BrowseBlackBoxFilesAtClass(NULL, FALSE, thisObj, mfail)
#define x3BrowseBlackBoxFilesAtClass(class, thisObj, mfail) \
        _x3BrowseBlackBoxFilesAtClass(class, FALSE, thisObj, mfail)
#define x3BrowseBlackBoxFilesAtParent(class, thisObj, mfail) \
        _x3BrowseBlackBoxFilesAtClass(class, TRUE, thisObj, mfail)

#define x3BrowseDepFor(thisObj, mfail) \
        _x3BrowseDepForAtClass(NULL, FALSE, thisObj, mfail)
#define x3BrowseDepForAtClass(class, thisObj, mfail) \
        _x3BrowseDepForAtClass(class, FALSE, thisObj, mfail)
#define x3BrowseDepForAtParent(class, thisObj, mfail) \
        _x3BrowseDepForAtClass(class, TRUE, thisObj, mfail)

#define x3BrowseDepOn(thisObj, mfail) \
        _x3BrowseDepOnAtClass(NULL, FALSE, thisObj, mfail)
#define x3BrowseDepOnAtClass(class, thisObj, mfail) \
        _x3BrowseDepOnAtClass(class, FALSE, thisObj, mfail)
#define x3BrowseDepOnAtParent(class, thisObj, mfail) \
        _x3BrowseDepOnAtClass(class, TRUE, thisObj, mfail)

#define x3BrowseMarkedItems(className, mfail) \
        _x3BrowseMarkedItems(className, FALSE, className, mfail)
#define x3BrowseMarkedItemsAtParent(_class, className, mfail) \
        _x3BrowseMarkedItems(_class, TRUE, className, mfail)

#define x3BrowseSelectedItems(className, SelectedItems, mfail) \
        _x3BrowseSelectedItems(className, FALSE, className, SelectedItems, mfail)
#define x3BrowseSelectedItemsAtParent(_class, className, SelectedItems, mfail) \
        _x3BrowseSelectedItems(_class, TRUE, className, SelectedItems, mfail)

#define x3CancelCreateForDoc(className, parameterSet, outputSet, mfail) \
        _x3CancelCreateForDoc(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3CancelCreateForDocAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3CancelCreateForDoc(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3CancelToCatia(className, mfail) \
        _x3CancelToCatia(className, FALSE, className, mfail)
#define x3CancelToCatiaAtParent(_class, className, mfail) \
        _x3CancelToCatia(_class, TRUE, className, mfail)

#define x3CancelUsePdmStruct(className, parameterSet, outputSet, mfail) \
        _x3CancelUsePdmStruct(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3CancelUsePdmStructAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3CancelUsePdmStruct(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3CancelV5AddTemp(className, parameterSet, outputSet, mfail) \
        _x3CancelV5AddTemp(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3CancelV5AddTempAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3CancelV5AddTemp(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3CancelV5SaveAs(className, parameterSet, outputSet, mfail) \
        _x3CancelV5SaveAs(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3CancelV5SaveAsAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3CancelV5SaveAs(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3ChangeDrawFlag(thisObj, mfail) \
        _x3ChangeDrawFlagAtClass(NULL, FALSE, thisObj, mfail)
#define x3ChangeDrawFlagAtClass(class, thisObj, mfail) \
        _x3ChangeDrawFlagAtClass(class, FALSE, thisObj, mfail)
#define x3ChangeDrawFlagAtParent(class, thisObj, mfail) \
        _x3ChangeDrawFlagAtClass(class, TRUE, thisObj, mfail)

#define x3ChangeSwapFlag(thisObj, mfail) \
        _x3ChangeSwapFlagAtClass(NULL, FALSE, thisObj, mfail)
#define x3ChangeSwapFlagAtClass(class, thisObj, mfail) \
        _x3ChangeSwapFlagAtClass(class, FALSE, thisObj, mfail)
#define x3ChangeSwapFlagAtParent(class, thisObj, mfail) \
        _x3ChangeSwapFlagAtClass(class, TRUE, thisObj, mfail)

#define x3CheckCatArcNameExt(this, arcname, archive_out, mfail) \
        _x3CheckCatArcNameExtAtClass(NULL, FALSE, this, arcname, archive_out, mfail)
#define x3CheckCatArcNameExtAtClass(class, this, arcname, archive_out, mfail) \
        _x3CheckCatArcNameExtAtClass(class, FALSE, this, arcname, archive_out, mfail)
#define x3CheckCatArcNameExtAtParent(class, this, arcname, archive_out, mfail) \
        _x3CheckCatArcNameExtAtClass(class, TRUE, this, arcname, archive_out, mfail)

#define x3CheckCatCgrNameExt(this, cgrname, cgr_out, mfail) \
        _x3CheckCatCgrNameExtAtClass(NULL, FALSE, this, cgrname, cgr_out, mfail)
#define x3CheckCatCgrNameExtAtClass(class, this, cgrname, cgr_out, mfail) \
        _x3CheckCatCgrNameExtAtClass(class, FALSE, this, cgrname, cgr_out, mfail)
#define x3CheckCatCgrNameExtAtParent(class, this, cgrname, cgr_out, mfail) \
        _x3CheckCatCgrNameExtAtClass(class, TRUE, this, cgrname, cgr_out, mfail)

#define x3CheckCatDrwNameExt(this, drawingname, drawing_out, mfail) \
        _x3CheckCatDrwNameExtAtClass(NULL, FALSE, this, drawingname, drawing_out, mfail)
#define x3CheckCatDrwNameExtAtClass(class, this, drawingname, drawing_out, mfail) \
        _x3CheckCatDrwNameExtAtClass(class, FALSE, this, drawingname, drawing_out, mfail)
#define x3CheckCatDrwNameExtAtParent(class, this, drawingname, drawing_out, mfail) \
        _x3CheckCatDrwNameExtAtClass(class, TRUE, this, drawingname, drawing_out, mfail)

#define x3CheckCatPrtNameExt(this, partname, part_out, mfail) \
        _x3CheckCatPrtNameExtAtClass(NULL, FALSE, this, partname, part_out, mfail)
#define x3CheckCatPrtNameExtAtClass(class, this, partname, part_out, mfail) \
        _x3CheckCatPrtNameExtAtClass(class, FALSE, this, partname, part_out, mfail)
#define x3CheckCatPrtNameExtAtParent(class, this, partname, part_out, mfail) \
        _x3CheckCatPrtNameExtAtClass(class, TRUE, this, partname, part_out, mfail)

#define x3CheckCatRepNameExt(this, repname, origrepname, rep_out, mfail) \
        _x3CheckCatRepNameExtAtClass(NULL, FALSE, this, repname, origrepname, rep_out, mfail)
#define x3CheckCatRepNameExtAtClass(class, this, repname, origrepname, rep_out, mfail) \
        _x3CheckCatRepNameExtAtClass(class, FALSE, this, repname, origrepname, rep_out, mfail)
#define x3CheckCatRepNameExtAtParent(class, this, repname, origrepname, rep_out, mfail) \
        _x3CheckCatRepNameExtAtClass(class, TRUE, this, repname, origrepname, rep_out, mfail)

#define x3CheckDTNameExt(this, dtName, drawing_out, mfail) \
        _x3CheckDTNameExtAtClass(NULL, FALSE, this, dtName, drawing_out, mfail)
#define x3CheckDTNameExtAtClass(class, this, dtName, drawing_out, mfail) \
        _x3CheckDTNameExtAtClass(class, FALSE, this, dtName, drawing_out, mfail)
#define x3CheckDTNameExtAtParent(class, this, dtName, drawing_out, mfail) \
        _x3CheckDTNameExtAtClass(class, TRUE, this, dtName, drawing_out, mfail)

#define x3CheckForMultiOcc(assmStrcObj, curSubAssObid, SubAssRels, hasMultiOcc, mfail) \
        _x3CheckForMultiOccAtClass(NULL, FALSE, assmStrcObj, curSubAssObid, SubAssRels, hasMultiOcc, mfail)
#define x3CheckForMultiOccAtClass(class, assmStrcObj, curSubAssObid, SubAssRels, hasMultiOcc, mfail) \
        _x3CheckForMultiOccAtClass(class, FALSE, assmStrcObj, curSubAssObid, SubAssRels, hasMultiOcc, mfail)
#define x3CheckForMultiOccAtParent(class, assmStrcObj, curSubAssObid, SubAssRels, hasMultiOcc, mfail) \
        _x3CheckForMultiOccAtClass(class, TRUE, assmStrcObj, curSubAssObid, SubAssRels, hasMultiOcc, mfail)

#define x3CheckIfInteractive(classname, is_interactive, mfail) \
        _x3CheckIfInteractive(classname, FALSE, classname, is_interactive, mfail)
#define x3CheckIfInteractiveAtParent(_class, classname, is_interactive, mfail) \
        _x3CheckIfInteractive(_class, TRUE, classname, is_interactive, mfail)

#define x3CheckModelNameExt(this, modelname, model_out, mfail) \
        _x3CheckModelNameExtAtClass(NULL, FALSE, this, modelname, model_out, mfail)
#define x3CheckModelNameExtAtClass(class, this, modelname, model_out, mfail) \
        _x3CheckModelNameExtAtClass(class, FALSE, this, modelname, model_out, mfail)
#define x3CheckModelNameExtAtParent(class, this, modelname, model_out, mfail) \
        _x3CheckModelNameExtAtClass(class, TRUE, this, modelname, model_out, mfail)

#define x3CheckWBvsCatiaPrefs(ClassName, bContinue, mfail) \
        _x3CheckWBvsCatiaPrefs(ClassName, FALSE, ClassName, bContinue, mfail)
#define x3CheckWBvsCatiaPrefsAtParent(_class, ClassName, bContinue, mfail) \
        _x3CheckWBvsCatiaPrefs(_class, TRUE, ClassName, bContinue, mfail)

#define x3ClgFileNameInWL(classname, oldFilename, newFilename, mfail) \
        _x3ClgFileNameInWL(classname, FALSE, classname, oldFilename, newFilename, mfail)
#define x3ClgFileNameInWLAtParent(_class, classname, oldFilename, newFilename, mfail) \
        _x3ClgFileNameInWL(_class, TRUE, classname, oldFilename, newFilename, mfail)

#define x3ClrWkBnch(className, mfail) \
        _x3ClrWkBnch(className, FALSE, className, mfail)
#define x3ClrWkBnchAtParent(_class, className, mfail) \
        _x3ClrWkBnch(_class, TRUE, className, mfail)

#define x3CmpFileNameInWL(classname, oldFilename, newFilename, mfail) \
        _x3CmpFileNameInWL(classname, FALSE, classname, oldFilename, newFilename, mfail)
#define x3CmpFileNameInWLAtParent(_class, classname, oldFilename, newFilename, mfail) \
        _x3CmpFileNameInWL(_class, TRUE, classname, oldFilename, newFilename, mfail)

#define x3ConvertStringList(className, stringList, stringSet, mfail) \
        _x3ConvertStringList(className, FALSE, className, stringList, stringSet, mfail)
#define x3ConvertStringListAtParent(_class, className, stringList, stringSet, mfail) \
        _x3ConvertStringList(_class, TRUE, className, stringList, stringSet, mfail)

#define x3ConvertUserDefProps(className, objInfos, vDisplayNameSet, vPropNameSet, vPropValueSet, mfail) \
        _x3ConvertUserDefProps(className, FALSE, className, objInfos, vDisplayNameSet, vPropNameSet, vPropValueSet, mfail)
#define x3ConvertUserDefPropsAtParent(_class, className, objInfos, vDisplayNameSet, vPropNameSet, vPropValueSet, mfail) \
        _x3ConvertUserDefProps(_class, TRUE, className, objInfos, vDisplayNameSet, vPropNameSet, vPropValueSet, mfail)

#define x3CopyCatiaFileSet(classname, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, bReadOk, vStats, mfail) \
        _x3CopyCatiaFileSet(classname, FALSE, classname, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, bReadOk, vStats, mfail)
#define x3CopyCatiaFileSetAtParent(_class, classname, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, bReadOk, vStats, mfail) \
        _x3CopyCatiaFileSet(_class, TRUE, classname, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, bReadOk, vStats, mfail)

#define x3CopyCgrFileToMap(this, targetSystem, bCreateLink, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, cgrPath, bLinkSuccess, mfail) \
        _x3CopyCgrFileToMapAtClass(NULL, FALSE, this, targetSystem, bCreateLink, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, cgrPath, bLinkSuccess, mfail)
#define x3CopyCgrFileToMapAtClass(class, this, targetSystem, bCreateLink, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, cgrPath, bLinkSuccess, mfail) \
        _x3CopyCgrFileToMapAtClass(class, FALSE, this, targetSystem, bCreateLink, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, cgrPath, bLinkSuccess, mfail)
#define x3CopyCgrFileToMapAtParent(class, this, targetSystem, bCreateLink, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, cgrPath, bLinkSuccess, mfail) \
        _x3CopyCgrFileToMapAtClass(class, TRUE, this, targetSystem, bCreateLink, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, cgrPath, bLinkSuccess, mfail)

#define x3CopyClgDataForCatia(className, parameterSet, outputSet, mfail) \
        _x3CopyClgDataForCatia(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3CopyClgDataForCatiaAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3CopyClgDataForCatia(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3CopyModelToMap(thisPtr, targetSystem, exMap, bTryCgr, bCreateLink, sHost, sUser, sFullPath, dHost, dUser, dFullPath, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, cgrFullPath, bLinkSuccess, mfail) \
        _x3CopyModelToMapAtClass(NULL, FALSE, thisPtr, targetSystem, exMap, bTryCgr, bCreateLink, sHost, sUser, sFullPath, dHost, dUser, dFullPath, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, cgrFullPath, bLinkSuccess, mfail)
#define x3CopyModelToMapAtClass(class, thisPtr, targetSystem, exMap, bTryCgr, bCreateLink, sHost, sUser, sFullPath, dHost, dUser, dFullPath, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, cgrFullPath, bLinkSuccess, mfail) \
        _x3CopyModelToMapAtClass(class, FALSE, thisPtr, targetSystem, exMap, bTryCgr, bCreateLink, sHost, sUser, sFullPath, dHost, dUser, dFullPath, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, cgrFullPath, bLinkSuccess, mfail)
#define x3CopyModelToMapAtParent(class, thisPtr, targetSystem, exMap, bTryCgr, bCreateLink, sHost, sUser, sFullPath, dHost, dUser, dFullPath, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, cgrFullPath, bLinkSuccess, mfail) \
        _x3CopyModelToMapAtClass(class, TRUE, thisPtr, targetSystem, exMap, bTryCgr, bCreateLink, sHost, sUser, sFullPath, dHost, dUser, dFullPath, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, cgrFullPath, bLinkSuccess, mfail)

#define x3CopyStdFileToMap(className, targetSystem, bCreateLink, sHost, sUser, sFullPath, dHost, dUser, dFullPath, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, bLinkSuccess, mfail) \
        _x3CopyStdFileToMap(className, FALSE, className, targetSystem, bCreateLink, sHost, sUser, sFullPath, dHost, dUser, dFullPath, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, bLinkSuccess, mfail)
#define x3CopyStdFileToMapAtParent(_class, className, targetSystem, bCreateLink, sHost, sUser, sFullPath, dHost, dUser, dFullPath, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, bLinkSuccess, mfail) \
        _x3CopyStdFileToMap(_class, TRUE, className, targetSystem, bCreateLink, sHost, sUser, sFullPath, dHost, dUser, dFullPath, sHosts, sUsers, sFullPaths, dHosts, dUsers, dFullPaths, bLinkSuccess, mfail)

#define x3CopyTransMap(className, exchange_map, transfer_map, dhost, duser, objMgrSet, mfail) \
        _x3CopyTransMap(className, FALSE, className, exchange_map, transfer_map, dhost, duser, objMgrSet, mfail)
#define x3CopyTransMapAtParent(_class, className, exchange_map, transfer_map, dhost, duser, objMgrSet, mfail) \
        _x3CopyTransMap(_class, TRUE, className, exchange_map, transfer_map, dhost, duser, objMgrSet, mfail)

#define x3CopyWorklocDir(classname, mhost, muser, dhost, duser, worklocation, catia_exchange_file, backupfilename, a_mode, mfail) \
        _x3CopyWorklocDir(classname, FALSE, classname, mhost, muser, dhost, duser, worklocation, catia_exchange_file, backupfilename, a_mode, mfail)
#define x3CopyWorklocDirAtParent(_class, classname, mhost, muser, dhost, duser, worklocation, catia_exchange_file, backupfilename, a_mode, mfail) \
        _x3CopyWorklocDir(_class, TRUE, classname, mhost, muser, dhost, duser, worklocation, catia_exchange_file, backupfilename, a_mode, mfail)

#define x3CopysCMIFiles(className, parameterSet, outputSet, mfail) \
        _x3CopysCMIFiles(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3CopysCMIFilesAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3CopysCMIFiles(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3CreBlackBoxFileObj(thisPtr, sourceFileName, fileTypeToCreate, pBlackBoxFileObj, mfail) \
        _x3CreBlackBoxFileObjAtClass(NULL, FALSE, thisPtr, sourceFileName, fileTypeToCreate, pBlackBoxFileObj, mfail)
#define x3CreBlackBoxFileObjAtClass(class, thisPtr, sourceFileName, fileTypeToCreate, pBlackBoxFileObj, mfail) \
        _x3CreBlackBoxFileObjAtClass(class, FALSE, thisPtr, sourceFileName, fileTypeToCreate, pBlackBoxFileObj, mfail)
#define x3CreBlackBoxFileObjAtParent(class, thisPtr, sourceFileName, fileTypeToCreate, pBlackBoxFileObj, mfail) \
        _x3CreBlackBoxFileObjAtClass(class, TRUE, thisPtr, sourceFileName, fileTypeToCreate, pBlackBoxFileObj, mfail)

#define x3CreFileInteractive(thisObj, partnumber, relPathInWL, worklocation, worklocHost, username, mfail) \
        _x3CreFileInteractiveAtClass(NULL, FALSE, thisObj, partnumber, relPathInWL, worklocation, worklocHost, username, mfail)
#define x3CreFileInteractiveAtClass(class, thisObj, partnumber, relPathInWL, worklocation, worklocHost, username, mfail) \
        _x3CreFileInteractiveAtClass(class, FALSE, thisObj, partnumber, relPathInWL, worklocation, worklocHost, username, mfail)
#define x3CreFileInteractiveAtParent(class, thisObj, partnumber, relPathInWL, worklocation, worklocHost, username, mfail) \
        _x3CreFileInteractiveAtClass(class, TRUE, thisObj, partnumber, relPathInWL, worklocation, worklocHost, username, mfail)

#define x3Create(className, mfail) \
        _x3Create(className, FALSE, className, mfail)
#define x3CreateAtParent(_class, className, mfail) \
        _x3Create(_class, TRUE, className, mfail)

#define x3CreateAndLinkPrdDoc(className, partNumber, partObj, newPrdDocObj, vStats, mfail) \
        _x3CreateAndLinkPrdDoc(className, FALSE, className, partNumber, partObj, newPrdDocObj, vStats, mfail)
#define x3CreateAndLinkPrdDocAtParent(_class, className, partNumber, partObj, newPrdDocObj, vStats, mfail) \
        _x3CreateAndLinkPrdDoc(_class, TRUE, className, partNumber, partObj, newPrdDocObj, vStats, mfail)

#define x3CreateAssyCATProd(ClassName, InSlots, prodModelInfos, pOutSlots1, pOutSlots2, pNewAssemblyObj, vStats, mfail) \
        _x3CreateAssyCATProd(ClassName, FALSE, ClassName, InSlots, prodModelInfos, pOutSlots1, pOutSlots2, pNewAssemblyObj, vStats, mfail)
#define x3CreateAssyCATProdAtParent(_class, ClassName, InSlots, prodModelInfos, pOutSlots1, pOutSlots2, pNewAssemblyObj, vStats, mfail) \
        _x3CreateAssyCATProd(_class, TRUE, ClassName, InSlots, prodModelInfos, pOutSlots1, pOutSlots2, pNewAssemblyObj, vStats, mfail)

#define x3CreateBackupFileName(className, TargetFileName, BackupFileName, mfail) \
        _x3CreateBackupFileName(className, FALSE, className, TargetFileName, BackupFileName, mfail)
#define x3CreateBackupFileNameAtParent(_class, className, TargetFileName, BackupFileName, mfail) \
        _x3CreateBackupFileName(_class, TRUE, className, TargetFileName, BackupFileName, mfail)

#define x3CreateCATDrawFrFile(className, parameterSet, outputSet, mfail) \
        _x3CreateCATDrawFrFile(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3CreateCATDrawFrFileAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3CreateCATDrawFrFile(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3CreateCATPartFrFile(className, parameterSet, outputSet, mfail) \
        _x3CreateCATPartFrFile(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3CreateCATPartFrFileAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3CreateCATPartFrFile(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3CreateCATV4FromFile(className, parameterSet, outputSet, mfail) \
        _x3CreateCATV4FromFile(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3CreateCATV4FromFileAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3CreateCATV4FromFile(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3CreateCatDrw(thisObj, docObj, bInteract, file, mfail) \
        _x3CreateCatDrwAtClass(NULL, FALSE, thisObj, docObj, bInteract, file, mfail)
#define x3CreateCatDrwAtClass(class, thisObj, docObj, bInteract, file, mfail) \
        _x3CreateCatDrwAtClass(class, FALSE, thisObj, docObj, bInteract, file, mfail)
#define x3CreateCatDrwAtParent(class, thisObj, docObj, bInteract, file, mfail) \
        _x3CreateCatDrwAtClass(class, TRUE, thisObj, docObj, bInteract, file, mfail)

#define x3CreateCatDrwObject(thisObj, docObj, NewModelName, DefWorkloc, CompName, bInteract, ModelInfos, vStats, mfail) \
        _x3CreateCatDrwObjectAtClass(NULL, FALSE, thisObj, docObj, NewModelName, DefWorkloc, CompName, bInteract, ModelInfos, vStats, mfail)
#define x3CreateCatDrwObjectAtClass(class, thisObj, docObj, NewModelName, DefWorkloc, CompName, bInteract, ModelInfos, vStats, mfail) \
        _x3CreateCatDrwObjectAtClass(class, FALSE, thisObj, docObj, NewModelName, DefWorkloc, CompName, bInteract, ModelInfos, vStats, mfail)
#define x3CreateCatDrwObjectAtParent(class, thisObj, docObj, NewModelName, DefWorkloc, CompName, bInteract, ModelInfos, vStats, mfail) \
        _x3CreateCatDrwObjectAtClass(class, TRUE, thisObj, docObj, NewModelName, DefWorkloc, CompName, bInteract, ModelInfos, vStats, mfail)

#define x3CreateCatDrwPost(thisObj, mfail) \
        _x3CreateCatDrwPostAtClass(NULL, FALSE, thisObj, mfail)
#define x3CreateCatDrwPostAtClass(class, thisObj, mfail) \
        _x3CreateCatDrwPostAtClass(class, FALSE, thisObj, mfail)
#define x3CreateCatDrwPostAtParent(class, thisObj, mfail) \
        _x3CreateCatDrwPostAtClass(class, TRUE, thisObj, mfail)

#define x3CreateCatPrdForECMI(className, pathFormat, path, newRegFileObj, messageText, messageAdded, mfail) \
        _x3CreateCatPrdForECMI(className, FALSE, className, pathFormat, path, newRegFileObj, messageText, messageAdded, mfail)
#define x3CreateCatPrdForECMIAtParent(_class, className, pathFormat, path, newRegFileObj, messageText, messageAdded, mfail) \
        _x3CreateCatPrdForECMI(_class, TRUE, className, pathFormat, path, newRegFileObj, messageText, messageAdded, mfail)

#define x3CreateCatPrt(thisObj, docObj, bInteract, file, mfail) \
        _x3CreateCatPrtAtClass(NULL, FALSE, thisObj, docObj, bInteract, file, mfail)
#define x3CreateCatPrtAtClass(class, thisObj, docObj, bInteract, file, mfail) \
        _x3CreateCatPrtAtClass(class, FALSE, thisObj, docObj, bInteract, file, mfail)
#define x3CreateCatPrtAtParent(class, thisObj, docObj, bInteract, file, mfail) \
        _x3CreateCatPrtAtClass(class, TRUE, thisObj, docObj, bInteract, file, mfail)

#define x3CreateCatPrtForUpdt(thisObj, file, partnumber, ModelInfos, vStats, mfail) \
        _x3CreateCatPrtForUpdtAtClass(NULL, FALSE, thisObj, file, partnumber, ModelInfos, vStats, mfail)
#define x3CreateCatPrtForUpdtAtClass(class, thisObj, file, partnumber, ModelInfos, vStats, mfail) \
        _x3CreateCatPrtForUpdtAtClass(class, FALSE, thisObj, file, partnumber, ModelInfos, vStats, mfail)
#define x3CreateCatPrtForUpdtAtParent(class, thisObj, file, partnumber, ModelInfos, vStats, mfail) \
        _x3CreateCatPrtForUpdtAtClass(class, TRUE, thisObj, file, partnumber, ModelInfos, vStats, mfail)

#define x3CreateCatalogPost(thisPtr, nvsObjInfos, mfail) \
        _x3CreateCatalogPostAtClass(NULL, FALSE, thisPtr, nvsObjInfos, mfail)
#define x3CreateCatalogPostAtClass(class, thisPtr, nvsObjInfos, mfail) \
        _x3CreateCatalogPostAtClass(class, FALSE, thisPtr, nvsObjInfos, mfail)
#define x3CreateCatalogPostAtParent(class, thisPtr, nvsObjInfos, mfail) \
        _x3CreateCatalogPostAtClass(class, TRUE, thisPtr, nvsObjInfos, mfail)

#define x3CreateCatiaCatalog(className, xmapPath, xmapHost, xmapUser, nvsObjInfos, newRegFileObj, mfail) \
        _x3CreateCatiaCatalog(className, FALSE, className, xmapPath, xmapHost, xmapUser, nvsObjInfos, newRegFileObj, mfail)
#define x3CreateCatiaCatalogAtParent(_class, className, xmapPath, xmapHost, xmapUser, nvsObjInfos, newRegFileObj, mfail) \
        _x3CreateCatiaCatalog(_class, TRUE, className, xmapPath, xmapHost, xmapUser, nvsObjInfos, newRegFileObj, mfail)

#define x3CreateCmpData(className, xmapPath, newFileName, newCmpDataObj, mfail) \
        _x3CreateCmpData(className, FALSE, className, xmapPath, newFileName, newCmpDataObj, mfail)
#define x3CreateCmpDataAtParent(_class, className, xmapPath, newFileName, newCmpDataObj, mfail) \
        _x3CreateCmpData(_class, TRUE, className, xmapPath, newFileName, newCmpDataObj, mfail)

#define x3CreateCmpDataPost(thisPtr, mfail) \
        _x3CreateCmpDataPostAtClass(NULL, FALSE, thisPtr, mfail)
#define x3CreateCmpDataPostAtClass(class, thisPtr, mfail) \
        _x3CreateCmpDataPostAtClass(class, FALSE, thisPtr, mfail)
#define x3CreateCmpDataPostAtParent(class, thisPtr, mfail) \
        _x3CreateCmpDataPostAtClass(class, TRUE, thisPtr, mfail)

#define x3CreateCmpDoc(className, partNumber, partObj, newCmpDocObj, mfail) \
        _x3CreateCmpDoc(className, FALSE, className, partNumber, partObj, newCmpDocObj, mfail)
#define x3CreateCmpDocAtParent(_class, className, partNumber, partObj, newCmpDocObj, mfail) \
        _x3CreateCmpDoc(_class, TRUE, className, partNumber, partObj, newCmpDocObj, mfail)

#define x3CreateCmpDocPost(thisPtr, mfail) \
        _x3CreateCmpDocPostAtClass(NULL, FALSE, thisPtr, mfail)
#define x3CreateCmpDocPostAtClass(class, thisPtr, mfail) \
        _x3CreateCmpDocPostAtClass(class, FALSE, thisPtr, mfail)
#define x3CreateCmpDocPostAtParent(class, thisPtr, mfail) \
        _x3CreateCmpDocPostAtClass(class, TRUE, thisPtr, mfail)

#define x3CreateComponent(ClassName, InSlots, pOutSlots, pNewCmponentObj, pNewCATPartObj, vStats, updateOk, mfail) \
        _x3CreateComponent(ClassName, FALSE, ClassName, InSlots, pOutSlots, pNewCmponentObj, pNewCATPartObj, vStats, updateOk, mfail)
#define x3CreateComponentAtParent(_class, ClassName, InSlots, pOutSlots, pNewCmponentObj, pNewCATPartObj, vStats, updateOk, mfail) \
        _x3CreateComponent(_class, TRUE, ClassName, InSlots, pOutSlots, pNewCmponentObj, pNewCATPartObj, vStats, updateOk, mfail)

#define x3CreateDmuData(className, partNumber, revision, filePath, protPath, dHost, dUser, protSet, mfail) \
        _x3CreateDmuData(className, FALSE, className, partNumber, revision, filePath, protPath, dHost, dUser, protSet, mfail)
#define x3CreateDmuDataAtParent(_class, className, partNumber, revision, filePath, protPath, dHost, dUser, protSet, mfail) \
        _x3CreateDmuData(_class, TRUE, className, partNumber, revision, filePath, protPath, dHost, dUser, protSet, mfail)

#define x3CreateDmuFile(thisObj, mfail) \
        _x3CreateDmuFileAtClass(NULL, FALSE, thisObj, mfail)
#define x3CreateDmuFileAtClass(class, thisObj, mfail) \
        _x3CreateDmuFileAtClass(class, FALSE, thisObj, mfail)
#define x3CreateDmuFileAtParent(class, thisObj, mfail) \
        _x3CreateDmuFileAtClass(class, TRUE, thisObj, mfail)

#define x3CreateDocForECMI(className, documentName, documentObj, messageText, messageAdded, mfail) \
        _x3CreateDocForECMI(className, FALSE, className, documentName, documentObj, messageText, messageAdded, mfail)
#define x3CreateDocForECMIAtParent(_class, className, documentName, documentObj, messageText, messageAdded, mfail) \
        _x3CreateDocForECMI(_class, TRUE, className, documentName, documentObj, messageText, messageAdded, mfail)

#define x3CreateDocForModel(thisObject, partObject, newDocObject, mfail) \
        _x3CreateDocForModelAtClass(NULL, FALSE, thisObject, partObject, newDocObject, mfail)
#define x3CreateDocForModelAtClass(class, thisObject, partObject, newDocObject, mfail) \
        _x3CreateDocForModelAtClass(class, FALSE, thisObject, partObject, newDocObject, mfail)
#define x3CreateDocForModelAtParent(class, thisObject, partObject, newDocObject, mfail) \
        _x3CreateDocForModelAtClass(class, TRUE, thisObject, partObject, newDocObject, mfail)

#define x3CreateDocForModelExt(thisObject, partObject, matrix, newDocObject, relObject, mfail) \
        _x3CreateDocForModelExtAtClass(NULL, FALSE, thisObject, partObject, matrix, newDocObject, relObject, mfail)
#define x3CreateDocForModelExtAtClass(class, thisObject, partObject, matrix, newDocObject, relObject, mfail) \
        _x3CreateDocForModelExtAtClass(class, FALSE, thisObject, partObject, matrix, newDocObject, relObject, mfail)
#define x3CreateDocForModelExtAtParent(class, thisObject, partObject, matrix, newDocObject, relObject, mfail) \
        _x3CreateDocForModelExtAtClass(class, TRUE, thisObject, partObject, matrix, newDocObject, relObject, mfail)

#define x3CreateFileForECMI(className, fileName, pathFormat, path, newRegFileObj, messageText, messageAdded, mfail) \
        _x3CreateFileForECMI(className, FALSE, className, fileName, pathFormat, path, newRegFileObj, messageText, messageAdded, mfail)
#define x3CreateFileForECMIAtParent(_class, className, fileName, pathFormat, path, newRegFileObj, messageText, messageAdded, mfail) \
        _x3CreateFileForECMI(_class, TRUE, className, fileName, pathFormat, path, newRegFileObj, messageText, messageAdded, mfail)

#define x3CreateFileForUpdt(thisObj, file, partnumber, ModelInfos, vStats, mfail) \
        _x3CreateFileForUpdtAtClass(NULL, FALSE, thisObj, file, partnumber, ModelInfos, vStats, mfail)
#define x3CreateFileForUpdtAtClass(class, thisObj, file, partnumber, ModelInfos, vStats, mfail) \
        _x3CreateFileForUpdtAtClass(class, FALSE, thisObj, file, partnumber, ModelInfos, vStats, mfail)
#define x3CreateFileForUpdtAtParent(class, thisObj, file, partnumber, ModelInfos, vStats, mfail) \
        _x3CreateFileForUpdtAtClass(class, TRUE, thisObj, file, partnumber, ModelInfos, vStats, mfail)

#define x3CreateFileForUpdtExt(thisObj, file, partnumber, ModelInfos, PartAttributes, matrix, existingPart, createdPart, document, relObject, vStats, mfail) \
        _x3CreateFileForUpdtExtAtClass(NULL, FALSE, thisObj, file, partnumber, ModelInfos, PartAttributes, matrix, existingPart, createdPart, document, relObject, vStats, mfail)
#define x3CreateFileForUpdtExtAtClass(class, thisObj, file, partnumber, ModelInfos, PartAttributes, matrix, existingPart, createdPart, document, relObject, vStats, mfail) \
        _x3CreateFileForUpdtExtAtClass(class, FALSE, thisObj, file, partnumber, ModelInfos, PartAttributes, matrix, existingPart, createdPart, document, relObject, vStats, mfail)
#define x3CreateFileForUpdtExtAtParent(class, thisObj, file, partnumber, ModelInfos, PartAttributes, matrix, existingPart, createdPart, document, relObject, vStats, mfail) \
        _x3CreateFileForUpdtExtAtClass(class, TRUE, thisObj, file, partnumber, ModelInfos, PartAttributes, matrix, existingPart, createdPart, document, relObject, vStats, mfail)

#define x3CreateInt(ClassName, sessObjs, mfail) \
        _x3CreateInt(ClassName, FALSE, ClassName, sessObjs, mfail)
#define x3CreateIntAtParent(_class, ClassName, sessObjs, mfail) \
        _x3CreateInt(_class, TRUE, ClassName, sessObjs, mfail)

#define x3CreateLink(classname, host, user, dhost, duser, sourcefile, targetfile, a_mode, link_rtncode, mfail) \
        _x3CreateLink(classname, FALSE, classname, host, user, dhost, duser, sourcefile, targetfile, a_mode, link_rtncode, mfail)
#define x3CreateLinkAtParent(_class, classname, host, user, dhost, duser, sourcefile, targetfile, a_mode, link_rtncode, mfail) \
        _x3CreateLink(_class, TRUE, classname, host, user, dhost, duser, sourcefile, targetfile, a_mode, link_rtncode, mfail)

#define x3CreateModelFrV5Post(thisObject, partOBID, V5ModelOBID, mfail) \
        _x3CreateModelFrV5PostAtClass(NULL, FALSE, thisObject, partOBID, V5ModelOBID, mfail)
#define x3CreateModelFrV5PostAtClass(class, thisObject, partOBID, V5ModelOBID, mfail) \
        _x3CreateModelFrV5PostAtClass(class, FALSE, thisObject, partOBID, V5ModelOBID, mfail)
#define x3CreateModelFrV5PostAtParent(class, thisObject, partOBID, V5ModelOBID, mfail) \
        _x3CreateModelFrV5PostAtClass(class, TRUE, thisObject, partOBID, V5ModelOBID, mfail)

#define x3CreateModelFromCatia(this, file, project, description, ModelInfos, mfail) \
        _x3CreateModelFromCatiaAtClass(NULL, FALSE, this, file, project, description, ModelInfos, mfail)
#define x3CreateModelFromCatiaAtClass(class, this, file, project, description, ModelInfos, mfail) \
        _x3CreateModelFromCatiaAtClass(class, FALSE, this, file, project, description, ModelInfos, mfail)
#define x3CreateModelFromCatiaAtParent(class, this, file, project, description, ModelInfos, mfail) \
        _x3CreateModelFromCatiaAtClass(class, TRUE, this, file, project, description, ModelInfos, mfail)

#define x3CreateModelFromTemp(thisObj, mfail) \
        _x3CreateModelFromTempAtClass(NULL, FALSE, thisObj, mfail)
#define x3CreateModelFromTempAtClass(class, thisObj, mfail) \
        _x3CreateModelFromTempAtClass(class, FALSE, thisObj, mfail)
#define x3CreateModelFromTempAtParent(class, thisObj, mfail) \
        _x3CreateModelFromTempAtClass(class, TRUE, thisObj, mfail)

#define x3CreateModelFromV5Prt(this, file, mfail) \
        _x3CreateModelFromV5PrtAtClass(NULL, FALSE, this, file, mfail)
#define x3CreateModelFromV5PrtAtClass(class, this, file, mfail) \
        _x3CreateModelFromV5PrtAtClass(class, FALSE, this, file, mfail)
#define x3CreateModelFromV5PrtAtParent(class, this, file, mfail) \
        _x3CreateModelFromV5PrtAtClass(class, TRUE, this, file, mfail)

#define x3CreateModelName(this, pHost, pUserName, pDirectory, DocObj, filename, mfail) \
        _x3CreateModelNameAtClass(NULL, FALSE, this, pHost, pUserName, pDirectory, DocObj, filename, mfail)
#define x3CreateModelNameAtClass(class, this, pHost, pUserName, pDirectory, DocObj, filename, mfail) \
        _x3CreateModelNameAtClass(class, FALSE, this, pHost, pUserName, pDirectory, DocObj, filename, mfail)
#define x3CreateModelNameAtParent(class, this, pHost, pUserName, pDirectory, DocObj, filename, mfail) \
        _x3CreateModelNameAtClass(class, TRUE, this, pHost, pUserName, pDirectory, DocObj, filename, mfail)

#define x3CreateModelRelECMI(className, modelOBID, messageText, messageAdded, mfail) \
        _x3CreateModelRelECMI(className, FALSE, className, modelOBID, messageText, messageAdded, mfail)
#define x3CreateModelRelECMIAtParent(_class, className, modelOBID, messageText, messageAdded, mfail) \
        _x3CreateModelRelECMI(_class, TRUE, className, modelOBID, messageText, messageAdded, mfail)

#define x3CreateNewPlotFile(originatingObj, plotfeatures, plotFileObj, mfail) \
        _x3CreateNewPlotFileAtClass(NULL, FALSE, originatingObj, plotfeatures, plotFileObj, mfail)
#define x3CreateNewPlotFileAtClass(class, originatingObj, plotfeatures, plotFileObj, mfail) \
        _x3CreateNewPlotFileAtClass(class, FALSE, originatingObj, plotfeatures, plotFileObj, mfail)
#define x3CreateNewPlotFileAtParent(class, originatingObj, plotfeatures, plotFileObj, mfail) \
        _x3CreateNewPlotFileAtClass(class, TRUE, originatingObj, plotfeatures, plotFileObj, mfail)

#define x3CreateNewSubAssRel(this, partMaster, newRelObj, mfail) \
        _x3CreateNewSubAssRelAtClass(NULL, FALSE, this, partMaster, newRelObj, mfail)
#define x3CreateNewSubAssRelAtClass(class, this, partMaster, newRelObj, mfail) \
        _x3CreateNewSubAssRelAtClass(class, FALSE, this, partMaster, newRelObj, mfail)
#define x3CreateNewSubAssRelAtParent(class, this, partMaster, newRelObj, mfail) \
        _x3CreateNewSubAssRelAtClass(class, TRUE, this, partMaster, newRelObj, mfail)

#define x3CreateOrRepPltFiles(ClassName, IpcSet, modObj, plotFileObjs, mfail) \
        _x3CreateOrRepPltFiles(ClassName, FALSE, ClassName, IpcSet, modObj, plotFileObjs, mfail)
#define x3CreateOrRepPltFilesAtParent(_class, ClassName, IpcSet, modObj, plotFileObjs, mfail) \
        _x3CreateOrRepPltFiles(_class, TRUE, ClassName, IpcSet, modObj, plotFileObjs, mfail)

#define x3CreatePart(thisObject, pAttributeSet, bUseDialog, mfail) \
        _x3CreatePartAtClass(NULL, FALSE, thisObject, pAttributeSet, bUseDialog, mfail)
#define x3CreatePartAtClass(class, thisObject, pAttributeSet, bUseDialog, mfail) \
        _x3CreatePartAtClass(class, FALSE, thisObject, pAttributeSet, bUseDialog, mfail)
#define x3CreatePartAtParent(class, thisObject, pAttributeSet, bUseDialog, mfail) \
        _x3CreatePartAtClass(class, TRUE, thisObject, pAttributeSet, bUseDialog, mfail)

#define x3CreatePartECMI(className, partNumber, dialogNames, dialogValues, partObj, messageText, messageAdded, mfail) \
        _x3CreatePartECMI(className, FALSE, className, partNumber, dialogNames, dialogValues, partObj, messageText, messageAdded, mfail)
#define x3CreatePartECMIAtParent(_class, className, partNumber, dialogNames, dialogValues, partObj, messageText, messageAdded, mfail) \
        _x3CreatePartECMI(_class, TRUE, className, partNumber, dialogNames, dialogValues, partObj, messageText, messageAdded, mfail)

#define x3CreatePartExt(strClassname, newPartClass, partObject, pAttributeSet, strPartCategory, bUseDialog, vStats, mfail) \
        _x3CreatePartExt(strClassname, FALSE, strClassname, newPartClass, partObject, pAttributeSet, strPartCategory, bUseDialog, vStats, mfail)
#define x3CreatePartExtAtParent(_class, strClassname, newPartClass, partObject, pAttributeSet, strPartCategory, bUseDialog, vStats, mfail) \
        _x3CreatePartExt(_class, TRUE, strClassname, newPartClass, partObject, pAttributeSet, strPartCategory, bUseDialog, vStats, mfail)

#define x3CreatePlotFileName(sClassname, modelObj, sCatiaFileName, sHost, sUserName, sDirectory, sFilename, mfail) \
        _x3CreatePlotFileName(sClassname, FALSE, sClassname, modelObj, sCatiaFileName, sHost, sUserName, sDirectory, sFilename, mfail)
#define x3CreatePlotFileNameAtParent(_class, sClassname, modelObj, sCatiaFileName, sHost, sUserName, sDirectory, sFilename, mfail) \
        _x3CreatePlotFileName(_class, TRUE, sClassname, modelObj, sCatiaFileName, sHost, sUserName, sDirectory, sFilename, mfail)

#define x3CreatePlotObj(modObj, plotfeatures, plotFileObj, mfail) \
        _x3CreatePlotObjAtClass(NULL, FALSE, modObj, plotfeatures, plotFileObj, mfail)
#define x3CreatePlotObjAtClass(class, modObj, plotfeatures, plotFileObj, mfail) \
        _x3CreatePlotObjAtClass(class, FALSE, modObj, plotfeatures, plotFileObj, mfail)
#define x3CreatePlotObjAtParent(class, modObj, plotfeatures, plotFileObj, mfail) \
        _x3CreatePlotObjAtClass(class, TRUE, modObj, plotfeatures, plotFileObj, mfail)

#define x3CreatePost(this, mfail) \
        _x3CreatePostAtClass(NULL, FALSE, this, mfail)
#define x3CreatePostAtClass(class, this, mfail) \
        _x3CreatePostAtClass(class, FALSE, this, mfail)
#define x3CreatePostAtParent(class, this, mfail) \
        _x3CreatePostAtClass(class, TRUE, this, mfail)

#define x3CreatePrdData(className, xmapPath, newFileName, newPrdDataObj, mfail) \
        _x3CreatePrdData(className, FALSE, className, xmapPath, newFileName, newPrdDataObj, mfail)
#define x3CreatePrdDataAtParent(_class, className, xmapPath, newFileName, newPrdDataObj, mfail) \
        _x3CreatePrdData(_class, TRUE, className, xmapPath, newFileName, newPrdDataObj, mfail)

#define x3CreatePrdDataPost(thisPtr, mfail) \
        _x3CreatePrdDataPostAtClass(NULL, FALSE, thisPtr, mfail)
#define x3CreatePrdDataPostAtClass(class, thisPtr, mfail) \
        _x3CreatePrdDataPostAtClass(class, FALSE, thisPtr, mfail)
#define x3CreatePrdDataPostAtParent(class, thisPtr, mfail) \
        _x3CreatePrdDataPostAtClass(class, TRUE, thisPtr, mfail)

#define x3CreatePrdDoc(className, partNumber, partObj, newPrdDocObj, mfail) \
        _x3CreatePrdDoc(className, FALSE, className, partNumber, partObj, newPrdDocObj, mfail)
#define x3CreatePrdDocAtParent(_class, className, partNumber, partObj, newPrdDocObj, mfail) \
        _x3CreatePrdDoc(_class, TRUE, className, partNumber, partObj, newPrdDocObj, mfail)

#define x3CreatePrdDocPost(thisPtr, mfail) \
        _x3CreatePrdDocPostAtClass(NULL, FALSE, thisPtr, mfail)
#define x3CreatePrdDocPostAtClass(class, thisPtr, mfail) \
        _x3CreatePrdDocPostAtClass(class, FALSE, thisPtr, mfail)
#define x3CreatePrdDocPostAtParent(class, thisPtr, mfail) \
        _x3CreatePrdDocPostAtClass(class, TRUE, thisPtr, mfail)

#define x3CreateUsesRel(className, leftPrtObj, rightPrtObj, usesInfos, newRelObj, trafoIndex, mfail) \
        _x3CreateUsesRel(className, FALSE, className, leftPrtObj, rightPrtObj, usesInfos, newRelObj, trafoIndex, mfail)
#define x3CreateUsesRelAtParent(_class, className, leftPrtObj, rightPrtObj, usesInfos, newRelObj, trafoIndex, mfail) \
        _x3CreateUsesRel(_class, TRUE, className, leftPrtObj, rightPrtObj, usesInfos, newRelObj, trafoIndex, mfail)

#define x3CreateV5DrwDocFrFile(className, parameterSet, outputSet, mfail) \
        _x3CreateV5DrwDocFrFile(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3CreateV5DrwDocFrFileAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3CreateV5DrwDocFrFile(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3CreateV5PrtDocFrFile(className, parameterSet, outputSet, mfail) \
        _x3CreateV5PrtDocFrFile(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3CreateV5PrtDocFrFileAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3CreateV5PrtDocFrFile(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3CtlgGetMasterIds(className, parameterSet, outputSet, mfail) \
        _x3CtlgGetMasterIds(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3CtlgGetMasterIdsAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3CtlgGetMasterIds(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3CusGetRlvRelViaObid(ClassName, RelOBID, ctItemObj, Relation, mfail) \
        _x3CusGetRlvRelViaObid(ClassName, FALSE, ClassName, RelOBID, ctItemObj, Relation, mfail)
#define x3CusGetRlvRelViaObidAtParent(_class, ClassName, RelOBID, ctItemObj, Relation, mfail) \
        _x3CusGetRlvRelViaObid(_class, TRUE, ClassName, RelOBID, ctItemObj, Relation, mfail)

#define x3CusGetRlvRlViaObidDb(ClassName, RelOBID, DataBaseName, ctItemObj, Relation, mfail) \
        _x3CusGetRlvRlViaObidDb(ClassName, FALSE, ClassName, RelOBID, DataBaseName, ctItemObj, Relation, mfail)
#define x3CusGetRlvRlViaObidDbAtParent(_class, ClassName, RelOBID, DataBaseName, ctItemObj, Relation, mfail) \
        _x3CusGetRlvRlViaObidDb(_class, TRUE, ClassName, RelOBID, DataBaseName, ctItemObj, Relation, mfail)

#define x3CusMultiDocCreate(this, DocumentSet, ModelSet, mfail) \
        _x3CusMultiDocCreateAtClass(NULL, FALSE, this, DocumentSet, ModelSet, mfail)
#define x3CusMultiDocCreateAtClass(class, this, DocumentSet, ModelSet, mfail) \
        _x3CusMultiDocCreateAtClass(class, FALSE, this, DocumentSet, ModelSet, mfail)
#define x3CusMultiDocCreateAtParent(class, this, DocumentSet, ModelSet, mfail) \
        _x3CusMultiDocCreateAtClass(class, TRUE, this, DocumentSet, ModelSet, mfail)

#define x3DecreaseRelQty(thisPtr, leftPrtObj, rightPrtObj, mfail) \
        _x3DecreaseRelQtyAtClass(NULL, FALSE, thisPtr, leftPrtObj, rightPrtObj, mfail)
#define x3DecreaseRelQtyAtClass(class, thisPtr, leftPrtObj, rightPrtObj, mfail) \
        _x3DecreaseRelQtyAtClass(class, FALSE, thisPtr, leftPrtObj, rightPrtObj, mfail)
#define x3DecreaseRelQtyAtParent(class, thisPtr, leftPrtObj, rightPrtObj, mfail) \
        _x3DecreaseRelQtyAtClass(class, TRUE, thisPtr, leftPrtObj, rightPrtObj, mfail)

#define x3DeexpandInstance(thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail) \
        _x3DeexpandInstanceAtClass(NULL, FALSE, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail)
#define x3DeexpandInstanceAtClass(class, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail) \
        _x3DeexpandInstanceAtClass(class, FALSE, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail)
#define x3DeexpandInstanceAtParent(class, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail) \
        _x3DeexpandInstanceAtClass(class, TRUE, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail)

#define x3DeexpandMarked(className, mfail) \
        _x3DeexpandMarked(className, FALSE, className, mfail)
#define x3DeexpandMarkedAtParent(_class, className, mfail) \
        _x3DeexpandMarked(_class, TRUE, className, mfail)

#define x3DeexpandModelInst(thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail) \
        _x3DeexpandModelInstAtClass(NULL, FALSE, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail)
#define x3DeexpandModelInstAtClass(class, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail) \
        _x3DeexpandModelInstAtClass(class, FALSE, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail)
#define x3DeexpandModelInstAtParent(class, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail) \
        _x3DeexpandModelInstAtClass(class, TRUE, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail)

#define x3DeexpandSelected(className, SelectedItems, mfail) \
        _x3DeexpandSelected(className, FALSE, className, SelectedItems, mfail)
#define x3DeexpandSelectedAtParent(_class, className, SelectedItems, mfail) \
        _x3DeexpandSelected(_class, TRUE, className, SelectedItems, mfail)

#define x3DelAssmStrcRel(this, matrix_index, quantity, mfail) \
        _x3DelAssmStrcRelAtClass(NULL, FALSE, this, matrix_index, quantity, mfail)
#define x3DelAssmStrcRelAtClass(class, this, matrix_index, quantity, mfail) \
        _x3DelAssmStrcRelAtClass(class, FALSE, this, matrix_index, quantity, mfail)
#define x3DelAssmStrcRelAtParent(class, this, matrix_index, quantity, mfail) \
        _x3DelAssmStrcRelAtClass(class, TRUE, this, matrix_index, quantity, mfail)

#define x3DelFilesInExMap(className, exchge, mfail) \
        _x3DelFilesInExMap(className, FALSE, className, exchge, mfail)
#define x3DelFilesInExMapAtParent(_class, className, exchge, mfail) \
        _x3DelFilesInExMap(_class, TRUE, className, exchge, mfail)

#define x3DeleteRelCIObjects(this, mfail) \
        _x3DeleteRelCIObjectsAtClass(NULL, FALSE, this, mfail)
#define x3DeleteRelCIObjectsAtClass(class, this, mfail) \
        _x3DeleteRelCIObjectsAtClass(class, FALSE, this, mfail)
#define x3DeleteRelCIObjectsAtParent(class, this, mfail) \
        _x3DeleteRelCIObjectsAtClass(class, TRUE, this, mfail)

#define x3DeleteRelCIObjectsNI(this, mfail) \
        _x3DeleteRelCIObjectsNIAtClass(NULL, FALSE, this, mfail)
#define x3DeleteRelCIObjectsNIAtClass(class, this, mfail) \
        _x3DeleteRelCIObjectsNIAtClass(class, FALSE, this, mfail)
#define x3DeleteRelCIObjectsNIAtParent(class, this, mfail) \
        _x3DeleteRelCIObjectsNIAtClass(class, TRUE, this, mfail)

#define x3DeleteTempAss(className, mfail) \
        _x3DeleteTempAss(className, FALSE, className, mfail)
#define x3DeleteTempAssAtParent(_class, className, mfail) \
        _x3DeleteTempAss(_class, TRUE, className, mfail)

#define x3DeleteTrafo(this, index, mfail) \
        _x3DeleteTrafoAtClass(NULL, FALSE, this, index, mfail)
#define x3DeleteTrafoAtClass(class, this, index, mfail) \
        _x3DeleteTrafoAtClass(class, FALSE, this, index, mfail)
#define x3DeleteTrafoAtParent(class, this, index, mfail) \
        _x3DeleteTrafoAtClass(class, TRUE, this, index, mfail)

#define x3DependsOnFiles(modObj, depFiles, mfail) \
        _x3DependsOnFilesAtClass(NULL, FALSE, modObj, depFiles, mfail)
#define x3DependsOnFilesAtClass(class, modObj, depFiles, mfail) \
        _x3DependsOnFilesAtClass(class, FALSE, modObj, depFiles, mfail)
#define x3DependsOnFilesAtParent(class, modObj, depFiles, mfail) \
        _x3DependsOnFilesAtClass(class, TRUE, modObj, depFiles, mfail)

#define x3DisplayWBTitle(ClassName, sTargetSystem, mfail) \
        _x3DisplayWBTitle(ClassName, FALSE, ClassName, sTargetSystem, mfail)
#define x3DisplayWBTitleAtParent(_class, ClassName, sTargetSystem, mfail) \
        _x3DisplayWBTitle(_class, TRUE, ClassName, sTargetSystem, mfail)

#define x3DocCreateCopyAttrs(this, documentObj, mfail) \
        _x3DocCreateCopyAttrsAtClass(NULL, FALSE, this, documentObj, mfail)
#define x3DocCreateCopyAttrsAtClass(class, this, documentObj, mfail) \
        _x3DocCreateCopyAttrsAtClass(class, FALSE, this, documentObj, mfail)
#define x3DocCreateCopyAttrsAtParent(class, this, documentObj, mfail) \
        _x3DocCreateCopyAttrsAtClass(class, TRUE, this, documentObj, mfail)

#define x3DocCreateCpyDlgAttrs(this, documentObj, mfail) \
        _x3DocCreateCpyDlgAttrsAtClass(NULL, FALSE, this, documentObj, mfail)
#define x3DocCreateCpyDlgAttrsAtClass(class, this, documentObj, mfail) \
        _x3DocCreateCpyDlgAttrsAtClass(class, FALSE, this, documentObj, mfail)
#define x3DocCreateCpyDlgAttrsAtParent(class, this, documentObj, mfail) \
        _x3DocCreateCpyDlgAttrsAtClass(class, TRUE, this, documentObj, mfail)

#define x3DocCreateCreRelCus(className, dialogObj, leftObj, rightObj, relationObj, mfail) \
        _x3DocCreateCreRelCus(className, FALSE, className, dialogObj, leftObj, rightObj, relationObj, mfail)
#define x3DocCreateCreRelCusAtParent(_class, className, dialogObj, leftObj, rightObj, relationObj, mfail) \
        _x3DocCreateCreRelCus(_class, TRUE, className, dialogObj, leftObj, rightObj, relationObj, mfail)

#define x3DocCreateCustomMsg(className, vWorkMode, vStrSet, mfail) \
        _x3DocCreateCustomMsg(className, FALSE, className, vWorkMode, vStrSet, mfail)
#define x3DocCreateCustomMsgAtParent(_class, className, vWorkMode, vStrSet, mfail) \
        _x3DocCreateCustomMsg(_class, TRUE, className, vWorkMode, vStrSet, mfail)

#define x3DocCreateMsg(className, vWorkMode, vStrSet, mfail) \
        _x3DocCreateMsg(className, FALSE, className, vWorkMode, vStrSet, mfail)
#define x3DocCreateMsgAtParent(_class, className, vWorkMode, vStrSet, mfail) \
        _x3DocCreateMsg(_class, TRUE, className, vWorkMode, vStrSet, mfail)

#define x3DocExpandExecFast(thisObj, cmi_ID, xmlFile, mfail) \
        _x3DocExpandExecFastAtClass(NULL, FALSE, thisObj, cmi_ID, xmlFile, mfail)
#define x3DocExpandExecFastAtClass(class, thisObj, cmi_ID, xmlFile, mfail) \
        _x3DocExpandExecFastAtClass(class, FALSE, thisObj, cmi_ID, xmlFile, mfail)
#define x3DocExpandExecFastAtParent(class, thisObj, cmi_ID, xmlFile, mfail) \
        _x3DocExpandExecFastAtClass(class, TRUE, thisObj, cmi_ID, xmlFile, mfail)

#define x3DocExpandFast(thisObj, cmi_ID, xmlFile, mfail) \
        _x3DocExpandFastAtClass(NULL, FALSE, thisObj, cmi_ID, xmlFile, mfail)
#define x3DocExpandFastAtClass(class, thisObj, cmi_ID, xmlFile, mfail) \
        _x3DocExpandFastAtClass(class, FALSE, thisObj, cmi_ID, xmlFile, mfail)
#define x3DocExpandFastAtParent(class, thisObj, cmi_ID, xmlFile, mfail) \
        _x3DocExpandFastAtClass(class, TRUE, thisObj, cmi_ID, xmlFile, mfail)

#define x3DocumentCreateCustom(this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3DocumentCreateCustomAtClass(NULL, FALSE, this, WkBnchObj, commObj, BackgroundItem, mfail)
#define x3DocumentCreateCustomAtClass(class, this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3DocumentCreateCustomAtClass(class, FALSE, this, WkBnchObj, commObj, BackgroundItem, mfail)
#define x3DocumentCreateCustomAtParent(class, this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3DocumentCreateCustomAtClass(class, TRUE, this, WkBnchObj, commObj, BackgroundItem, mfail)

#define x3DocumentLinkCatDrw(this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3DocumentLinkCatDrwAtClass(NULL, FALSE, this, WkBnchObj, commObj, BackgroundItem, mfail)
#define x3DocumentLinkCatDrwAtClass(class, this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3DocumentLinkCatDrwAtClass(class, FALSE, this, WkBnchObj, commObj, BackgroundItem, mfail)
#define x3DocumentLinkCatDrwAtParent(class, this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3DocumentLinkCatDrwAtClass(class, TRUE, this, WkBnchObj, commObj, BackgroundItem, mfail)

#define x3DocumentLinkCatPrt(this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3DocumentLinkCatPrtAtClass(NULL, FALSE, this, WkBnchObj, commObj, BackgroundItem, mfail)
#define x3DocumentLinkCatPrtAtClass(class, this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3DocumentLinkCatPrtAtClass(class, FALSE, this, WkBnchObj, commObj, BackgroundItem, mfail)
#define x3DocumentLinkCatPrtAtParent(class, this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3DocumentLinkCatPrtAtClass(class, TRUE, this, WkBnchObj, commObj, BackgroundItem, mfail)

#define x3DocumentRead(this, WkBnchObj, commObj, BackgroundItem, pDocRep, mfail) \
        _x3DocumentReadAtClass(NULL, FALSE, this, WkBnchObj, commObj, BackgroundItem, pDocRep, mfail)
#define x3DocumentReadAtClass(class, this, WkBnchObj, commObj, BackgroundItem, pDocRep, mfail) \
        _x3DocumentReadAtClass(class, FALSE, this, WkBnchObj, commObj, BackgroundItem, pDocRep, mfail)
#define x3DocumentReadAtParent(class, this, WkBnchObj, commObj, BackgroundItem, pDocRep, mfail) \
        _x3DocumentReadAtClass(class, TRUE, this, WkBnchObj, commObj, BackgroundItem, pDocRep, mfail)

#define x3DocumentSaveAs(this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3DocumentSaveAsAtClass(NULL, FALSE, this, WkBnchObj, commObj, BackgroundItem, mfail)
#define x3DocumentSaveAsAtClass(class, this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3DocumentSaveAsAtClass(class, FALSE, this, WkBnchObj, commObj, BackgroundItem, mfail)
#define x3DocumentSaveAsAtParent(class, this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3DocumentSaveAsAtClass(class, TRUE, this, WkBnchObj, commObj, BackgroundItem, mfail)

#define x3DocumentSaveAsPost(this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3DocumentSaveAsPostAtClass(NULL, FALSE, this, WkBnchObj, commObj, BackgroundItem, mfail)
#define x3DocumentSaveAsPostAtClass(class, this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3DocumentSaveAsPostAtClass(class, FALSE, this, WkBnchObj, commObj, BackgroundItem, mfail)
#define x3DocumentSaveAsPostAtParent(class, this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3DocumentSaveAsPostAtClass(class, TRUE, this, WkBnchObj, commObj, BackgroundItem, mfail)

#define x3DropSubAssMsg(ClassName, vStrSet, mfail) \
        _x3DropSubAssMsg(ClassName, FALSE, ClassName, vStrSet, mfail)
#define x3DropSubAssMsgAtParent(_class, ClassName, vStrSet, mfail) \
        _x3DropSubAssMsg(_class, TRUE, ClassName, vStrSet, mfail)

#define x3Dump(thisObj, mfail) \
        _x3DumpAtClass(NULL, FALSE, thisObj, mfail)
#define x3DumpAtClass(class, thisObj, mfail) \
        _x3DumpAtClass(class, FALSE, thisObj, mfail)
#define x3DumpAtParent(class, thisObj, mfail) \
        _x3DumpAtClass(class, TRUE, thisObj, mfail)

#define x3EPlotByLstnr(ClassName, vStrSet, mfail) \
        _x3EPlotByLstnr(ClassName, FALSE, ClassName, vStrSet, mfail)
#define x3EPlotByLstnrAtParent(_class, ClassName, vStrSet, mfail) \
        _x3EPlotByLstnr(_class, TRUE, ClassName, vStrSet, mfail)

#define x3EPlotCustomData(className, ModelObject, NameSlotSet, ValueSlotSet, bIsPossible, mfail) \
        _x3EPlotCustomData(className, FALSE, className, ModelObject, NameSlotSet, ValueSlotSet, bIsPossible, mfail)
#define x3EPlotCustomDataAtParent(_class, className, ModelObject, NameSlotSet, ValueSlotSet, bIsPossible, mfail) \
        _x3EPlotCustomData(_class, TRUE, className, ModelObject, NameSlotSet, ValueSlotSet, bIsPossible, mfail)

#define x3EPlotInWb(ClassName, ModelOBID, PartOBID, WayToRoot, DraftsList, ViewsList, FramesList, mfail) \
        _x3EPlotInWb(ClassName, FALSE, ClassName, ModelOBID, PartOBID, WayToRoot, DraftsList, ViewsList, FramesList, mfail)
#define x3EPlotInWbAtParent(_class, ClassName, ModelOBID, PartOBID, WayToRoot, DraftsList, ViewsList, FramesList, mfail) \
        _x3EPlotInWb(_class, TRUE, ClassName, ModelOBID, PartOBID, WayToRoot, DraftsList, ViewsList, FramesList, mfail)

#define x3ExpandExecSetBased(classname, topObjSet, topRelSet, expandLevel, cmi_ID_set, xmlFileSet, mfail) \
        _x3ExpandExecSetBased(classname, FALSE, classname, topObjSet, topRelSet, expandLevel, cmi_ID_set, xmlFileSet, mfail)
#define x3ExpandExecSetBasedAtParent(_class, classname, topObjSet, topRelSet, expandLevel, cmi_ID_set, xmlFileSet, mfail) \
        _x3ExpandExecSetBased(_class, TRUE, classname, topObjSet, topRelSet, expandLevel, cmi_ID_set, xmlFileSet, mfail)

#define x3ExpandInstance(thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail) \
        _x3ExpandInstanceAtClass(NULL, FALSE, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail)
#define x3ExpandInstanceAtClass(class, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail) \
        _x3ExpandInstanceAtClass(class, FALSE, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail)
#define x3ExpandInstanceAtParent(class, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail) \
        _x3ExpandInstanceAtClass(class, TRUE, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail)

#define x3ExpandModelInst(thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail) \
        _x3ExpandModelInstAtClass(NULL, FALSE, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail)
#define x3ExpandModelInstAtClass(class, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail) \
        _x3ExpandModelInstAtClass(class, FALSE, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail)
#define x3ExpandModelInstAtParent(class, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail) \
        _x3ExpandModelInstAtClass(class, TRUE, thisObj, ctxObj, sParentObid, sParentDbName, sRelObid, sRelDbName, sChildObid, sChildDbName, bHasMatrixIndex, mfail)

#define x3ExpandSetBased(thisObj, expandLevel, cmi_ID, xmlFile, mfail) \
        _x3ExpandSetBasedAtClass(NULL, FALSE, thisObj, expandLevel, cmi_ID, xmlFile, mfail)
#define x3ExpandSetBasedAtClass(class, thisObj, expandLevel, cmi_ID, xmlFile, mfail) \
        _x3ExpandSetBasedAtClass(class, FALSE, thisObj, expandLevel, cmi_ID, xmlFile, mfail)
#define x3ExpandSetBasedAtParent(class, thisObj, expandLevel, cmi_ID, xmlFile, mfail) \
        _x3ExpandSetBasedAtClass(class, TRUE, thisObj, expandLevel, cmi_ID, xmlFile, mfail)

#define x3ExpandV5Drawings(thisObj, mfail) \
        _x3ExpandV5DrawingsAtClass(NULL, FALSE, thisObj, mfail)
#define x3ExpandV5DrawingsAtClass(class, thisObj, mfail) \
        _x3ExpandV5DrawingsAtClass(class, FALSE, thisObj, mfail)
#define x3ExpandV5DrawingsAtParent(class, thisObj, mfail) \
        _x3ExpandV5DrawingsAtClass(class, TRUE, thisObj, mfail)

#define x3FileNameInWL(classname, xmapUser, xmapHost, xmapPath, defaultFilename, newFilename, mfail) \
        _x3FileNameInWL(classname, FALSE, classname, xmapUser, xmapHost, xmapPath, defaultFilename, newFilename, mfail)
#define x3FileNameInWLAtParent(_class, classname, xmapUser, xmapHost, xmapPath, defaultFilename, newFilename, mfail) \
        _x3FileNameInWL(_class, TRUE, classname, xmapUser, xmapHost, xmapPath, defaultFilename, newFilename, mfail)

#define x3FillObjMgrSet(className, exchange_map, dhost, duser, x0ComCatStatus, pSetOfStrings, pSetOfStrings2, usex0MarkedInWkbnch, scustomattr, bSetLink, objMgrSet, mfail) \
        _x3FillObjMgrSet(className, FALSE, className, exchange_map, dhost, duser, x0ComCatStatus, pSetOfStrings, pSetOfStrings2, usex0MarkedInWkbnch, scustomattr, bSetLink, objMgrSet, mfail)
#define x3FillObjMgrSetAtParent(_class, className, exchange_map, dhost, duser, x0ComCatStatus, pSetOfStrings, pSetOfStrings2, usex0MarkedInWkbnch, scustomattr, bSetLink, objMgrSet, mfail) \
        _x3FillObjMgrSet(_class, TRUE, className, exchange_map, dhost, duser, x0ComCatStatus, pSetOfStrings, pSetOfStrings2, usex0MarkedInWkbnch, scustomattr, bSetLink, objMgrSet, mfail)

#define x3FilterPartByVersion(className, filterSet, mfail) \
        _x3FilterPartByVersion(className, FALSE, className, filterSet, mfail)
#define x3FilterPartByVersionAtParent(_class, className, filterSet, mfail) \
        _x3FilterPartByVersion(_class, TRUE, className, filterSet, mfail)

#define x3FindCatModelByCusKey(classname, attributelist, valuelist, FoundObj, bIsDocument, mfail) \
        _x3FindCatModelByCusKey(classname, FALSE, classname, attributelist, valuelist, FoundObj, bIsDocument, mfail)
#define x3FindCatModelByCusKeyAtParent(_class, classname, attributelist, valuelist, FoundObj, bIsDocument, mfail) \
        _x3FindCatModelByCusKey(_class, TRUE, classname, attributelist, valuelist, FoundObj, bIsDocument, mfail)

#define x3FindCatPartByCusKey(classname, attributelist, valuelist, FoundObj, mfail) \
        _x3FindCatPartByCusKey(classname, FALSE, classname, attributelist, valuelist, FoundObj, mfail)
#define x3FindCatPartByCusKeyAtParent(_class, classname, attributelist, valuelist, FoundObj, mfail) \
        _x3FindCatPartByCusKey(_class, TRUE, classname, attributelist, valuelist, FoundObj, mfail)

#define x3FindCatRelByCusKey(classname, attributelist, valuelist, FoundObj, mfail) \
        _x3FindCatRelByCusKey(classname, FALSE, classname, attributelist, valuelist, FoundObj, mfail)
#define x3FindCatRelByCusKeyAtParent(_class, classname, attributelist, valuelist, FoundObj, mfail) \
        _x3FindCatRelByCusKey(_class, TRUE, classname, attributelist, valuelist, FoundObj, mfail)

#define x3FindModComps(this, doccomps, mfail) \
        _x3FindModCompsAtClass(NULL, FALSE, this, doccomps, mfail)
#define x3FindModCompsAtClass(class, this, doccomps, mfail) \
        _x3FindModCompsAtClass(class, FALSE, this, doccomps, mfail)
#define x3FindModCompsAtParent(class, this, doccomps, mfail) \
        _x3FindModCompsAtClass(class, TRUE, this, doccomps, mfail)

#define x3GenInstNameForIndex(thisObj, index, sInstanceName, mfail) \
        _x3GenInstNameForIndexAtClass(NULL, FALSE, thisObj, index, sInstanceName, mfail)
#define x3GenInstNameForIndexAtClass(class, thisObj, index, sInstanceName, mfail) \
        _x3GenInstNameForIndexAtClass(class, FALSE, thisObj, index, sInstanceName, mfail)
#define x3GenInstNameForIndexAtParent(class, thisObj, index, sInstanceName, mfail) \
        _x3GenInstNameForIndexAtClass(class, TRUE, thisObj, index, sInstanceName, mfail)

#define x3GetAllComponentFiles(thisPtr, WkBnchObj, compObjects, mfail) \
        _x3GetAllComponentFilesAtClass(NULL, FALSE, thisPtr, WkBnchObj, compObjects, mfail)
#define x3GetAllComponentFilesAtClass(class, thisPtr, WkBnchObj, compObjects, mfail) \
        _x3GetAllComponentFilesAtClass(class, FALSE, thisPtr, WkBnchObj, compObjects, mfail)
#define x3GetAllComponentFilesAtParent(class, thisPtr, WkBnchObj, compObjects, mfail) \
        _x3GetAllComponentFilesAtClass(class, TRUE, thisPtr, WkBnchObj, compObjects, mfail)

#define x3GetAllModAndPos(classname, partObj, WorkBnchObj, vModSet, vPosSet, mfail) \
        _x3GetAllModAndPos(classname, FALSE, classname, partObj, WorkBnchObj, vModSet, vPosSet, mfail)
#define x3GetAllModAndPosAtParent(_class, classname, partObj, WorkBnchObj, vModSet, vPosSet, mfail) \
        _x3GetAllModAndPos(_class, TRUE, classname, partObj, WorkBnchObj, vModSet, vPosSet, mfail)

#define x3GetAttValueForObject(sClassName, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail) \
        _x3GetAttValueForObject(sClassName, FALSE, sClassName, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail)
#define x3GetAttValueForObjectAtParent(_class, sClassName, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail) \
        _x3GetAttValueForObject(_class, TRUE, sClassName, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail)

#define x3GetAttValueForPosObj(sThisClassName, sInstanceName, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail) \
        _x3GetAttValueForPosObj(sThisClassName, FALSE, sThisClassName, sInstanceName, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail)
#define x3GetAttValueForPosObjAtParent(_class, sThisClassName, sInstanceName, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail) \
        _x3GetAttValueForPosObj(_class, TRUE, sThisClassName, sInstanceName, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail)

#define x3GetAttValueForRelObj(sThisClassName, sInstanceName, sMatrixIndex, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail) \
        _x3GetAttValueForRelObj(sThisClassName, FALSE, sThisClassName, sInstanceName, sMatrixIndex, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail)
#define x3GetAttValueForRelObjAtParent(_class, sThisClassName, sInstanceName, sMatrixIndex, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail) \
        _x3GetAttValueForRelObj(_class, TRUE, sThisClassName, sInstanceName, sMatrixIndex, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail)

#define x3GetAttrs(className, PartOBID, ModelOBID, Attrs_demanded, Attr_Vals_found, mfail) \
        _x3GetAttrs(className, FALSE, className, PartOBID, ModelOBID, Attrs_demanded, Attr_Vals_found, mfail)
#define x3GetAttrsAtParent(_class, className, PartOBID, ModelOBID, Attrs_demanded, Attr_Vals_found, mfail) \
        _x3GetAttrs(_class, TRUE, className, PartOBID, ModelOBID, Attrs_demanded, Attr_Vals_found, mfail)

#define x3GetAttrsForCAD(this, Attrs_demanded, AttrVals_found, mfail) \
        _x3GetAttrsForCADAtClass(NULL, FALSE, this, Attrs_demanded, AttrVals_found, mfail)
#define x3GetAttrsForCADAtClass(class, this, Attrs_demanded, AttrVals_found, mfail) \
        _x3GetAttrsForCADAtClass(class, FALSE, this, Attrs_demanded, AttrVals_found, mfail)
#define x3GetAttrsForCADAtParent(class, this, Attrs_demanded, AttrVals_found, mfail) \
        _x3GetAttrsForCADAtClass(class, TRUE, this, Attrs_demanded, AttrVals_found, mfail)

#define x3GetAttrsMg(ClassName, vStrSet, vRetSet, mfail) \
        _x3GetAttrsMg(ClassName, FALSE, ClassName, vStrSet, vRetSet, mfail)
#define x3GetAttrsMgAtParent(_class, ClassName, vStrSet, vRetSet, mfail) \
        _x3GetAttrsMg(_class, TRUE, ClassName, vStrSet, vRetSet, mfail)

#define x3GetBomType(strClassname, nvsObjInfos, nvsUserDefInfos, nvsParentObjInfos, nvsParentUserDefInfos, bomType, mfail) \
        _x3GetBomType(strClassname, FALSE, strClassname, nvsObjInfos, nvsUserDefInfos, nvsParentObjInfos, nvsParentUserDefInfos, bomType, mfail)
#define x3GetBomTypeAtParent(_class, strClassname, nvsObjInfos, nvsUserDefInfos, nvsParentObjInfos, nvsParentUserDefInfos, bomType, mfail) \
        _x3GetBomType(_class, TRUE, strClassname, nvsObjInfos, nvsUserDefInfos, nvsParentObjInfos, nvsParentUserDefInfos, bomType, mfail)

#define x3GetBomTypes(className, parameterSet, outputSet, mfail) \
        _x3GetBomTypes(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3GetBomTypesAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3GetBomTypes(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3GetCATIADefinitExt(this, docObj, descr, mfail) \
        _x3GetCATIADefinitExtAtClass(NULL, FALSE, this, docObj, descr, mfail)
#define x3GetCATIADefinitExtAtClass(class, this, docObj, descr, mfail) \
        _x3GetCATIADefinitExtAtClass(class, FALSE, this, docObj, descr, mfail)
#define x3GetCATIADefinitExtAtParent(class, this, docObj, descr, mfail) \
        _x3GetCATIADefinitExtAtClass(class, TRUE, this, docObj, descr, mfail)

#define x3GetCATIADefinition(this, descr, mfail) \
        _x3GetCATIADefinitionAtClass(NULL, FALSE, this, descr, mfail)
#define x3GetCATIADefinitionAtClass(class, this, descr, mfail) \
        _x3GetCATIADefinitionAtClass(class, FALSE, this, descr, mfail)
#define x3GetCATIADefinitionAtParent(class, this, descr, mfail) \
        _x3GetCATIADefinitionAtClass(class, TRUE, this, descr, mfail)

#define x3GetCATIADescriptExt(this, docObj, descr, mfail) \
        _x3GetCATIADescriptExtAtClass(NULL, FALSE, this, docObj, descr, mfail)
#define x3GetCATIADescriptExtAtClass(class, this, docObj, descr, mfail) \
        _x3GetCATIADescriptExtAtClass(class, FALSE, this, docObj, descr, mfail)
#define x3GetCATIADescriptExtAtParent(class, this, docObj, descr, mfail) \
        _x3GetCATIADescriptExtAtClass(class, TRUE, this, docObj, descr, mfail)

#define x3GetCATIADescription(this, descr, mfail) \
        _x3GetCATIADescriptionAtClass(NULL, FALSE, this, descr, mfail)
#define x3GetCATIADescriptionAtClass(class, this, descr, mfail) \
        _x3GetCATIADescriptionAtClass(class, FALSE, this, descr, mfail)
#define x3GetCATIADescriptionAtParent(class, this, descr, mfail) \
        _x3GetCATIADescriptionAtClass(class, TRUE, this, descr, mfail)

#define x3GetCATIANomenclatExt(this, docObj, descr, mfail) \
        _x3GetCATIANomenclatExtAtClass(NULL, FALSE, this, docObj, descr, mfail)
#define x3GetCATIANomenclatExtAtClass(class, this, docObj, descr, mfail) \
        _x3GetCATIANomenclatExtAtClass(class, FALSE, this, docObj, descr, mfail)
#define x3GetCATIANomenclatExtAtParent(class, this, docObj, descr, mfail) \
        _x3GetCATIANomenclatExtAtClass(class, TRUE, this, docObj, descr, mfail)

#define x3GetCATIANomenclature(this, descr, mfail) \
        _x3GetCATIANomenclatureAtClass(NULL, FALSE, this, descr, mfail)
#define x3GetCATIANomenclatureAtClass(class, this, descr, mfail) \
        _x3GetCATIANomenclatureAtClass(class, FALSE, this, descr, mfail)
#define x3GetCATIANomenclatureAtParent(class, this, descr, mfail) \
        _x3GetCATIANomenclatureAtClass(class, TRUE, this, descr, mfail)

#define x3GetCATIARevision(this, descr, mfail) \
        _x3GetCATIARevisionAtClass(NULL, FALSE, this, descr, mfail)
#define x3GetCATIARevisionAtClass(class, this, descr, mfail) \
        _x3GetCATIARevisionAtClass(class, FALSE, this, descr, mfail)
#define x3GetCATIARevisionAtParent(class, this, descr, mfail) \
        _x3GetCATIARevisionAtClass(class, TRUE, this, descr, mfail)

#define x3GetCATIARevisionExt(this, docObj, descr, mfail) \
        _x3GetCATIARevisionExtAtClass(NULL, FALSE, this, docObj, descr, mfail)
#define x3GetCATIARevisionExtAtClass(class, this, docObj, descr, mfail) \
        _x3GetCATIARevisionExtAtClass(class, FALSE, this, docObj, descr, mfail)
#define x3GetCATIARevisionExtAtParent(class, this, docObj, descr, mfail) \
        _x3GetCATIARevisionExtAtClass(class, TRUE, this, docObj, descr, mfail)

#define x3GetCIFromCMRep(this, CtItDpRelObjSet, CatiaItemObj, mfail) \
        _x3GetCIFromCMRepAtClass(NULL, FALSE, this, CtItDpRelObjSet, CatiaItemObj, mfail)
#define x3GetCIFromCMRepAtClass(class, this, CtItDpRelObjSet, CatiaItemObj, mfail) \
        _x3GetCIFromCMRepAtClass(class, FALSE, this, CtItDpRelObjSet, CatiaItemObj, mfail)
#define x3GetCIFromCMRepAtParent(class, this, CtItDpRelObjSet, CatiaItemObj, mfail) \
        _x3GetCIFromCMRepAtClass(class, TRUE, this, CtItDpRelObjSet, CatiaItemObj, mfail)

#define x3GetCatalogDispName(thisObj, vDisplayName, mfail) \
        _x3GetCatalogDispNameAtClass(NULL, FALSE, thisObj, vDisplayName, mfail)
#define x3GetCatalogDispNameAtClass(class, thisObj, vDisplayName, mfail) \
        _x3GetCatalogDispNameAtClass(class, FALSE, thisObj, vDisplayName, mfail)
#define x3GetCatalogDispNameAtParent(class, thisObj, vDisplayName, mfail) \
        _x3GetCatalogDispNameAtClass(class, TRUE, thisObj, vDisplayName, mfail)

#define x3GetCatalogFile(className, parameterSet, outputSet, mfail) \
        _x3GetCatalogFile(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3GetCatalogFileAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3GetCatalogFile(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3GetCatalogInfo(className, parameterSet, outputSet, mfail) \
        _x3GetCatalogInfo(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3GetCatalogInfoAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3GetCatalogInfo(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3GetCatalogObjects(classname, objecthandle, pPartObject, pProductObject, vStats, mfail) \
        _x3GetCatalogObjects(classname, FALSE, classname, objecthandle, pPartObject, pProductObject, vStats, mfail)
#define x3GetCatalogObjectsAtParent(_class, classname, objecthandle, pPartObject, pProductObject, vStats, mfail) \
        _x3GetCatalogObjects(_class, TRUE, classname, objecthandle, pPartObject, pProductObject, vStats, mfail)

#define x3GetCatalogsForCatia(className, pCatalogs, mfail) \
        _x3GetCatalogsForCatia(className, FALSE, className, pCatalogs, mfail)
#define x3GetCatalogsForCatiaAtParent(_class, className, pCatalogs, mfail) \
        _x3GetCatalogsForCatia(_class, TRUE, className, pCatalogs, mfail)

#define x3GetCatalogsForEdit(className, pCatalogs, mfail) \
        _x3GetCatalogsForEdit(className, FALSE, className, pCatalogs, mfail)
#define x3GetCatalogsForEditAtParent(_class, className, pCatalogs, mfail) \
        _x3GetCatalogsForEdit(_class, TRUE, className, pCatalogs, mfail)

#define x3GetCatiaDispName(thisObject, sCatiaDisplayName, mfail) \
        _x3GetCatiaDispNameAtClass(NULL, FALSE, thisObject, sCatiaDisplayName, mfail)
#define x3GetCatiaDispNameAtClass(class, thisObject, sCatiaDisplayName, mfail) \
        _x3GetCatiaDispNameAtClass(class, FALSE, thisObject, sCatiaDisplayName, mfail)
#define x3GetCatiaDispNameAtParent(class, thisObject, sCatiaDisplayName, mfail) \
        _x3GetCatiaDispNameAtClass(class, TRUE, thisObject, sCatiaDisplayName, mfail)

#define x3GetCatiaFileExt(thisObj, sExtension, mfail) \
        _x3GetCatiaFileExtAtClass(NULL, FALSE, thisObj, sExtension, mfail)
#define x3GetCatiaFileExtAtClass(class, thisObj, sExtension, mfail) \
        _x3GetCatiaFileExtAtClass(class, FALSE, thisObj, sExtension, mfail)
#define x3GetCatiaFileExtAtParent(class, thisObj, sExtension, mfail) \
        _x3GetCatiaFileExtAtClass(class, TRUE, thisObj, sExtension, mfail)

#define x3GetCatiaModSize(ModObj, ModSize, mfail) \
        _x3GetCatiaModSizeAtClass(NULL, FALSE, ModObj, ModSize, mfail)
#define x3GetCatiaModSizeAtClass(class, ModObj, ModSize, mfail) \
        _x3GetCatiaModSizeAtClass(class, FALSE, ModObj, ModSize, mfail)
#define x3GetCatiaModSizeAtParent(class, ModObj, ModSize, mfail) \
        _x3GetCatiaModSizeAtClass(class, TRUE, ModObj, ModSize, mfail)

#define x3GetCgrFilePaths(thisPtr, sHost, sUser, sCgrFullPath, dHost, dUser, dCgrfullPath, mfail) \
        _x3GetCgrFilePathsAtClass(NULL, FALSE, thisPtr, sHost, sUser, sCgrFullPath, dHost, dUser, dCgrfullPath, mfail)
#define x3GetCgrFilePathsAtClass(class, thisPtr, sHost, sUser, sCgrFullPath, dHost, dUser, dCgrfullPath, mfail) \
        _x3GetCgrFilePathsAtClass(class, FALSE, thisPtr, sHost, sUser, sCgrFullPath, dHost, dUser, dCgrfullPath, mfail)
#define x3GetCgrFilePathsAtParent(class, thisPtr, sHost, sUser, sCgrFullPath, dHost, dUser, dCgrfullPath, mfail) \
        _x3GetCgrFilePathsAtClass(class, TRUE, thisPtr, sHost, sUser, sCgrFullPath, dHost, dUser, dCgrfullPath, mfail)

#define x3GetChildAssms(itemObj, childItems, rels_in_WkBnch, childAssms, mfail) \
        _x3GetChildAssmsAtClass(NULL, FALSE, itemObj, childItems, rels_in_WkBnch, childAssms, mfail)
#define x3GetChildAssmsAtClass(class, itemObj, childItems, rels_in_WkBnch, childAssms, mfail) \
        _x3GetChildAssmsAtClass(class, FALSE, itemObj, childItems, rels_in_WkBnch, childAssms, mfail)
#define x3GetChildAssmsAtParent(class, itemObj, childItems, rels_in_WkBnch, childAssms, mfail) \
        _x3GetChildAssmsAtClass(class, TRUE, itemObj, childItems, rels_in_WkBnch, childAssms, mfail)

#define x3GetChildInstNames(classname, partObj, productObj, vInstanceNameSet, vPartPartNumberSet, vModelInstNamesSet, vNewModelInstNamesSet, vModelPartNumberSet, vModelOldObidSet, vModelNewObidSet, mfail) \
        _x3GetChildInstNames(classname, FALSE, classname, partObj, productObj, vInstanceNameSet, vPartPartNumberSet, vModelInstNamesSet, vNewModelInstNamesSet, vModelPartNumberSet, vModelOldObidSet, vModelNewObidSet, mfail)
#define x3GetChildInstNamesAtParent(_class, classname, partObj, productObj, vInstanceNameSet, vPartPartNumberSet, vModelInstNamesSet, vNewModelInstNamesSet, vModelPartNumberSet, vModelOldObidSet, vModelNewObidSet, mfail) \
        _x3GetChildInstNames(_class, TRUE, classname, partObj, productObj, vInstanceNameSet, vPartPartNumberSet, vModelInstNamesSet, vNewModelInstNamesSet, vModelPartNumberSet, vModelOldObidSet, vModelNewObidSet, mfail)

#define x3GetClassForCatRep(sClassName, sOrigCatRepClassName, sOrigFileName, sOrigPartNumber, sNewCatRepClassName, mfail) \
        _x3GetClassForCatRep(sClassName, FALSE, sClassName, sOrigCatRepClassName, sOrigFileName, sOrigPartNumber, sNewCatRepClassName, mfail)
#define x3GetClassForCatRepAtParent(_class, sClassName, sOrigCatRepClassName, sOrigFileName, sOrigPartNumber, sNewCatRepClassName, mfail) \
        _x3GetClassForCatRep(_class, TRUE, sClassName, sOrigCatRepClassName, sOrigFileName, sOrigPartNumber, sNewCatRepClassName, mfail)

#define x3GetClgObjViaObid(sWkBnchClass, sClgClassName, sClgOBID, sClgDbName, pObj, mfail) \
        _x3GetClgObjViaObid(sWkBnchClass, FALSE, sWkBnchClass, sClgClassName, sClgOBID, sClgDbName, pObj, mfail)
#define x3GetClgObjViaObidAtParent(_class, sWkBnchClass, sClgClassName, sClgOBID, sClgDbName, pObj, mfail) \
        _x3GetClgObjViaObid(_class, TRUE, sWkBnchClass, sClgClassName, sClgOBID, sClgDbName, pObj, mfail)

#define x3GetCmpDocName(className, partNumber, documentName, mfail) \
        _x3GetCmpDocName(className, FALSE, className, partNumber, documentName, mfail)
#define x3GetCmpDocNameAtParent(_class, className, partNumber, documentName, mfail) \
        _x3GetCmpDocName(_class, TRUE, className, partNumber, documentName, mfail)

#define x3GetCmpPartForModel(sClassName, modelObject, pPartObject, mfail) \
        _x3GetCmpPartForModel(sClassName, FALSE, sClassName, modelObject, pPartObject, mfail)
#define x3GetCmpPartForModelAtParent(_class, sClassName, modelObject, pPartObject, mfail) \
        _x3GetCmpPartForModel(_class, TRUE, sClassName, modelObject, pPartObject, mfail)

#define x3GetCntObjViaObid(className, binOBID, binObj, mfail) \
        _x3GetCntObjViaObid(className, FALSE, className, binOBID, binObj, mfail)
#define x3GetCntObjViaObidAtParent(_class, className, binOBID, binObj, mfail) \
        _x3GetCntObjViaObid(_class, TRUE, className, binOBID, binObj, mfail)

#define x3GetCntViaObidAndDb(className, binOBID, binDbName, binObj, mfail) \
        _x3GetCntViaObidAndDb(className, FALSE, className, binOBID, binDbName, binObj, mfail)
#define x3GetCntViaObidAndDbAtParent(_class, className, binOBID, binDbName, binObj, mfail) \
        _x3GetCntViaObidAndDb(_class, TRUE, className, binOBID, binDbName, binObj, mfail)

#define x3GetContainedModels(thisObj, sModelsFetched, sBBFilesFetched, modRepObjs, BBModels, mfail) \
        _x3GetContainedModelsAtClass(NULL, FALSE, thisObj, sModelsFetched, sBBFilesFetched, modRepObjs, BBModels, mfail)
#define x3GetContainedModelsAtClass(class, thisObj, sModelsFetched, sBBFilesFetched, modRepObjs, BBModels, mfail) \
        _x3GetContainedModelsAtClass(class, FALSE, thisObj, sModelsFetched, sBBFilesFetched, modRepObjs, BBModels, mfail)
#define x3GetContainedModelsAtParent(class, thisObj, sModelsFetched, sBBFilesFetched, modRepObjs, BBModels, mfail) \
        _x3GetContainedModelsAtClass(class, TRUE, thisObj, sModelsFetched, sBBFilesFetched, modRepObjs, BBModels, mfail)

#define x3GetCusDataForCADExt(classname, WorkbenchRel, this, objectid, attributelist, valuelist, mfail) \
        _x3GetCusDataForCADExt(classname, FALSE, classname, WorkbenchRel, this, objectid, attributelist, valuelist, mfail)
#define x3GetCusDataForCADExtAtParent(_class, classname, WorkbenchRel, this, objectid, attributelist, valuelist, mfail) \
        _x3GetCusDataForCADExt(_class, TRUE, classname, WorkbenchRel, this, objectid, attributelist, valuelist, mfail)

#define x3GetCustomAttrsV5(className, parameterSet, outputSet, mfail) \
        _x3GetCustomAttrsV5(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3GetCustomAttrsV5AtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3GetCustomAttrsV5(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3GetCustomDataForCAD(classname, this, objectid, attributelist, valuelist, mfail) \
        _x3GetCustomDataForCAD(classname, FALSE, classname, this, objectid, attributelist, valuelist, mfail)
#define x3GetCustomDataForCADAtParent(_class, classname, this, objectid, attributelist, valuelist, mfail) \
        _x3GetCustomDataForCAD(_class, TRUE, classname, this, objectid, attributelist, valuelist, mfail)

#define x3GetDependencyInfo(className, parameterSet, outputSet, mfail) \
        _x3GetDependencyInfo(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3GetDependencyInfoAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3GetDependencyInfo(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3GetDependentFiles(className, parameterSet, outputSet, mfail) \
        _x3GetDependentFiles(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3GetDependentFilesAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3GetDependentFiles(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3GetDescriptionInCAD(this, descr, mfail) \
        _x3GetDescriptionInCADAtClass(NULL, FALSE, this, descr, mfail)
#define x3GetDescriptionInCADAtClass(class, this, descr, mfail) \
        _x3GetDescriptionInCADAtClass(class, FALSE, this, descr, mfail)
#define x3GetDescriptionInCADAtParent(class, this, descr, mfail) \
        _x3GetDescriptionInCADAtClass(class, TRUE, this, descr, mfail)

#define x3GetDesignTables(catiaObj, partObj, desTabObjs, dtFileNames, mfail) \
        _x3GetDesignTablesAtClass(NULL, FALSE, catiaObj, partObj, desTabObjs, dtFileNames, mfail)
#define x3GetDesignTablesAtClass(class, catiaObj, partObj, desTabObjs, dtFileNames, mfail) \
        _x3GetDesignTablesAtClass(class, FALSE, catiaObj, partObj, desTabObjs, dtFileNames, mfail)
#define x3GetDesignTablesAtParent(class, catiaObj, partObj, desTabObjs, dtFileNames, mfail) \
        _x3GetDesignTablesAtClass(class, TRUE, catiaObj, partObj, desTabObjs, dtFileNames, mfail)

#define x3GetDestCgrFilePath(thisPtr, dHost, dUser, dCgrfullPath, mfail) \
        _x3GetDestCgrFilePathAtClass(NULL, FALSE, thisPtr, dHost, dUser, dCgrfullPath, mfail)
#define x3GetDestCgrFilePathAtClass(class, thisPtr, dHost, dUser, dCgrfullPath, mfail) \
        _x3GetDestCgrFilePathAtClass(class, FALSE, thisPtr, dHost, dUser, dCgrfullPath, mfail)
#define x3GetDestCgrFilePathAtParent(class, thisPtr, dHost, dUser, dCgrfullPath, mfail) \
        _x3GetDestCgrFilePathAtClass(class, TRUE, thisPtr, dHost, dUser, dCgrfullPath, mfail)

#define x3GetDmuPartNumberVS(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _x3GetDmuPartNumberVSAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define x3GetDmuPartNumberVSAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _x3GetDmuPartNumberVSAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define x3GetDmuPartNumberVSAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _x3GetDmuPartNumberVSAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define x3GetDmuVolNameVS(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _x3GetDmuVolNameVSAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define x3GetDmuVolNameVSAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _x3GetDmuVolNameVSAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define x3GetDmuVolNameVSAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _x3GetDmuVolNameVSAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define x3GetFeatureExtForCAD(classname, this, nModRep, partOBID, x0CTItemObj, objectid, SetOfContainerIdsMod, SetOfClientIdsMod, SetOfFeatureTypesMod, SetOfFeatureAttrsMod, SetOfFeatureValuesMod, mfail) \
        _x3GetFeatureExtForCAD(classname, FALSE, classname, this, nModRep, partOBID, x0CTItemObj, objectid, SetOfContainerIdsMod, SetOfClientIdsMod, SetOfFeatureTypesMod, SetOfFeatureAttrsMod, SetOfFeatureValuesMod, mfail)
#define x3GetFeatureExtForCADAtParent(_class, classname, this, nModRep, partOBID, x0CTItemObj, objectid, SetOfContainerIdsMod, SetOfClientIdsMod, SetOfFeatureTypesMod, SetOfFeatureAttrsMod, SetOfFeatureValuesMod, mfail) \
        _x3GetFeatureExtForCAD(_class, TRUE, classname, this, nModRep, partOBID, x0CTItemObj, objectid, SetOfContainerIdsMod, SetOfClientIdsMod, SetOfFeatureTypesMod, SetOfFeatureAttrsMod, SetOfFeatureValuesMod, mfail)

#define x3GetInfoForCAD(ClassName, RelationOBID, PartOBID, DocRelOBID, ModelOBID, LabelSet, ValueSet, mfail) \
        _x3GetInfoForCAD(ClassName, FALSE, ClassName, RelationOBID, PartOBID, DocRelOBID, ModelOBID, LabelSet, ValueSet, mfail)
#define x3GetInfoForCADAtParent(_class, ClassName, RelationOBID, PartOBID, DocRelOBID, ModelOBID, LabelSet, ValueSet, mfail) \
        _x3GetInfoForCAD(_class, TRUE, ClassName, RelationOBID, PartOBID, DocRelOBID, ModelOBID, LabelSet, ValueSet, mfail)

#define x3GetInfoForParts(className, parameterSet, outputSet, mfail) \
        _x3GetInfoForParts(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3GetInfoForPartsAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3GetInfoForParts(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3GetInstInfos(className, nvsInstInfos, sXmap, WkBnchObj, nvsInstOutput, mfail) \
        _x3GetInstInfos(className, FALSE, className, nvsInstInfos, sXmap, WkBnchObj, nvsInstOutput, mfail)
#define x3GetInstInfosAtParent(_class, className, nvsInstInfos, sXmap, WkBnchObj, nvsInstOutput, mfail) \
        _x3GetInstInfos(_class, TRUE, className, nvsInstInfos, sXmap, WkBnchObj, nvsInstOutput, mfail)

#define x3GetInstNameForIndex(thisObj, index, sInstanceName, mfail) \
        _x3GetInstNameForIndexAtClass(NULL, FALSE, thisObj, index, sInstanceName, mfail)
#define x3GetInstNameForIndexAtClass(class, thisObj, index, sInstanceName, mfail) \
        _x3GetInstNameForIndexAtClass(class, FALSE, thisObj, index, sInstanceName, mfail)
#define x3GetInstNameForIndexAtParent(class, thisObj, index, sInstanceName, mfail) \
        _x3GetInstNameForIndexAtClass(class, TRUE, thisObj, index, sInstanceName, mfail)

#define x3GetInstanceInfo(className, parameterSet, outputSet, mfail) \
        _x3GetInstanceInfo(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3GetInstanceInfoAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3GetInstanceInfo(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3GetItemInfoForCAD(this, LabelSet, ValueSet, mfail) \
        _x3GetItemInfoForCADAtClass(NULL, FALSE, this, LabelSet, ValueSet, mfail)
#define x3GetItemInfoForCADAtClass(class, this, LabelSet, ValueSet, mfail) \
        _x3GetItemInfoForCADAtClass(class, FALSE, this, LabelSet, ValueSet, mfail)
#define x3GetItemInfoForCADAtParent(class, this, LabelSet, ValueSet, mfail) \
        _x3GetItemInfoForCADAtClass(class, TRUE, this, LabelSet, ValueSet, mfail)

#define x3GetItemsOfItem(this, itemObj, ItemsOfPart, itemItemRels, mfail) \
        _x3GetItemsOfItemAtClass(NULL, FALSE, this, itemObj, ItemsOfPart, itemItemRels, mfail)
#define x3GetItemsOfItemAtClass(class, this, itemObj, ItemsOfPart, itemItemRels, mfail) \
        _x3GetItemsOfItemAtClass(class, FALSE, this, itemObj, ItemsOfPart, itemItemRels, mfail)
#define x3GetItemsOfItemAtParent(class, this, itemObj, ItemsOfPart, itemItemRels, mfail) \
        _x3GetItemsOfItemAtClass(class, TRUE, this, itemObj, ItemsOfPart, itemItemRels, mfail)

#define x3GetLastModSeq(ClassName, modObj, relative_path, modelsOfPart, relsOfPart, lastModObj, lastRelObj, mfail) \
        _x3GetLastModSeq(ClassName, FALSE, ClassName, modObj, relative_path, modelsOfPart, relsOfPart, lastModObj, lastRelObj, mfail)
#define x3GetLastModSeqAtParent(_class, ClassName, modObj, relative_path, modelsOfPart, relsOfPart, lastModObj, lastRelObj, mfail) \
        _x3GetLastModSeq(_class, TRUE, ClassName, modObj, relative_path, modelsOfPart, relsOfPart, lastModObj, lastRelObj, mfail)

#define x3GetModCmpFrmAsmInWkB(this, compOBID, modObj, mfail) \
        _x3GetModCmpFrmAsmInWkBAtClass(NULL, FALSE, this, compOBID, modObj, mfail)
#define x3GetModCmpFrmAsmInWkBAtClass(class, this, compOBID, modObj, mfail) \
        _x3GetModCmpFrmAsmInWkBAtClass(class, FALSE, this, compOBID, modObj, mfail)
#define x3GetModCmpFrmAsmInWkBAtParent(class, this, compOBID, modObj, mfail) \
        _x3GetModCmpFrmAsmInWkBAtClass(class, TRUE, this, compOBID, modObj, mfail)

#define x3GetModPosViaOBID(className, ModPosClass, Obid, ModPosObj, mfail) \
        _x3GetModPosViaOBID(className, FALSE, className, ModPosClass, Obid, ModPosObj, mfail)
#define x3GetModPosViaOBIDAtParent(_class, className, ModPosClass, Obid, ModPosObj, mfail) \
        _x3GetModPosViaOBID(_class, TRUE, className, ModPosClass, Obid, ModPosObj, mfail)

#define x3GetModPosViaObidDb(className, ModPosClass, Obid, DataBaseName, ModPosObj, mfail) \
        _x3GetModPosViaObidDb(className, FALSE, className, ModPosClass, Obid, DataBaseName, ModPosObj, mfail)
#define x3GetModPosViaObidDbAtParent(_class, className, ModPosClass, Obid, DataBaseName, ModPosObj, mfail) \
        _x3GetModPosViaObidDb(_class, TRUE, className, ModPosClass, Obid, DataBaseName, ModPosObj, mfail)

#define x3GetModelForSaveAs(thisObj, comStatus, compObj, mfail) \
        _x3GetModelForSaveAsAtClass(NULL, FALSE, thisObj, comStatus, compObj, mfail)
#define x3GetModelForSaveAsAtClass(class, thisObj, comStatus, compObj, mfail) \
        _x3GetModelForSaveAsAtClass(class, FALSE, thisObj, comStatus, compObj, mfail)
#define x3GetModelForSaveAsAtParent(class, thisObj, comStatus, compObj, mfail) \
        _x3GetModelForSaveAsAtClass(class, TRUE, thisObj, comStatus, compObj, mfail)

#define x3GetModelInfoMsg(ClassName, vStrSet, vRetSet, mfail) \
        _x3GetModelInfoMsg(ClassName, FALSE, ClassName, vStrSet, vRetSet, mfail)
#define x3GetModelInfoMsgAtParent(_class, ClassName, vStrSet, vRetSet, mfail) \
        _x3GetModelInfoMsg(_class, TRUE, ClassName, vStrSet, vRetSet, mfail)

#define x3GetModelInstanceName(CTFileObj, sOrigInstanceName, sNewInstanceName, mfail) \
        _x3GetModelInstanceNameAtClass(NULL, FALSE, CTFileObj, sOrigInstanceName, sNewInstanceName, mfail)
#define x3GetModelInstanceNameAtClass(class, CTFileObj, sOrigInstanceName, sNewInstanceName, mfail) \
        _x3GetModelInstanceNameAtClass(class, FALSE, CTFileObj, sOrigInstanceName, sNewInstanceName, mfail)
#define x3GetModelInstanceNameAtParent(class, CTFileObj, sOrigInstanceName, sNewInstanceName, mfail) \
        _x3GetModelInstanceNameAtClass(class, TRUE, CTFileObj, sOrigInstanceName, sNewInstanceName, mfail)

#define x3GetModelViaObidAndDb(className, modelOBID, modelDbName, modelObj, mfail) \
        _x3GetModelViaObidAndDb(className, FALSE, className, modelOBID, modelDbName, modelObj, mfail)
#define x3GetModelViaObidAndDbAtParent(_class, className, modelOBID, modelDbName, modelObj, mfail) \
        _x3GetModelViaObidAndDb(_class, TRUE, className, modelOBID, modelDbName, modelObj, mfail)

#define x3GetModelsViaObid(className, modelClassNames, modelDbNames, modelOBIDs, modelObjs, mfail) \
        _x3GetModelsViaObid(className, FALSE, className, modelClassNames, modelDbNames, modelOBIDs, modelObjs, mfail)
#define x3GetModelsViaObidAtParent(_class, className, modelClassNames, modelDbNames, modelOBIDs, modelObjs, mfail) \
        _x3GetModelsViaObid(_class, TRUE, className, modelClassNames, modelDbNames, modelOBIDs, modelObjs, mfail)

#define x3GetObjectForCatiaAtt(className, sPartNumber, sProductType, sFileName, nvsExtraInfos, pdmObj, mfail) \
        _x3GetObjectForCatiaAtt(className, FALSE, className, sPartNumber, sProductType, sFileName, nvsExtraInfos, pdmObj, mfail)
#define x3GetObjectForCatiaAttAtParent(_class, className, sPartNumber, sProductType, sFileName, nvsExtraInfos, pdmObj, mfail) \
        _x3GetObjectForCatiaAtt(_class, TRUE, className, sPartNumber, sProductType, sFileName, nvsExtraInfos, pdmObj, mfail)

#define x3GetOneComponent(thisObj, comStatus, compObj, mfail) \
        _x3GetOneComponentAtClass(NULL, FALSE, thisObj, comStatus, compObj, mfail)
#define x3GetOneComponentAtClass(class, thisObj, comStatus, compObj, mfail) \
        _x3GetOneComponentAtClass(class, FALSE, thisObj, comStatus, compObj, mfail)
#define x3GetOneComponentAtParent(class, thisObj, comStatus, compObj, mfail) \
        _x3GetOneComponentAtClass(class, TRUE, thisObj, comStatus, compObj, mfail)

#define x3GetOrigGeoForCgr(className, parameterSet, outputSet, mfail) \
        _x3GetOrigGeoForCgr(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3GetOrigGeoForCgrAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3GetOrigGeoForCgr(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3GetOrigInstNmeFrMod(classname, partObj, sRealProductOBID, productObj, modelObj, posObj, bOutOfSync, sInstanceName, mfail) \
        _x3GetOrigInstNmeFrMod(classname, FALSE, classname, partObj, sRealProductOBID, productObj, modelObj, posObj, bOutOfSync, sInstanceName, mfail)
#define x3GetOrigInstNmeFrModAtParent(_class, classname, partObj, sRealProductOBID, productObj, modelObj, posObj, bOutOfSync, sInstanceName, mfail) \
        _x3GetOrigInstNmeFrMod(_class, TRUE, classname, partObj, sRealProductOBID, productObj, modelObj, posObj, bOutOfSync, sInstanceName, mfail)

#define x3GetOrigPartNumber(ArchiveObj, sOrigPartNumber, mfail) \
        _x3GetOrigPartNumberAtClass(NULL, FALSE, ArchiveObj, sOrigPartNumber, mfail)
#define x3GetOrigPartNumberAtClass(class, ArchiveObj, sOrigPartNumber, mfail) \
        _x3GetOrigPartNumberAtClass(class, FALSE, ArchiveObj, sOrigPartNumber, mfail)
#define x3GetOrigPartNumberAtParent(class, ArchiveObj, sOrigPartNumber, mfail) \
        _x3GetOrigPartNumberAtClass(class, TRUE, ArchiveObj, sOrigPartNumber, mfail)

#define x3GetPDMSettings(className, parameterSet, outputSet, mfail) \
        _x3GetPDMSettings(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3GetPDMSettingsAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3GetPDMSettings(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3GetParamForFileV5(sClassname, thisObj, vAttributeList, vAalueList, mfail) \
        _x3GetParamForFileV5(sClassname, FALSE, sClassname, thisObj, vAttributeList, vAalueList, mfail)
#define x3GetParamForFileV5AtParent(_class, sClassname, thisObj, vAttributeList, vAalueList, mfail) \
        _x3GetParamForFileV5(_class, TRUE, sClassname, thisObj, vAttributeList, vAalueList, mfail)

#define x3GetPartAttributeApi(className, parameterSet, outputSet, mfail) \
        _x3GetPartAttributeApi(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3GetPartAttributeApiAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3GetPartAttributeApi(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3GetPartByAttributes(ClassName, partOBID, partNumber, partRevision, lastSeq, subassObj, mfail) \
        _x3GetPartByAttributes(ClassName, FALSE, ClassName, partOBID, partNumber, partRevision, lastSeq, subassObj, mfail)
#define x3GetPartByAttributesAtParent(_class, ClassName, partOBID, partNumber, partRevision, lastSeq, subassObj, mfail) \
        _x3GetPartByAttributes(_class, TRUE, ClassName, partOBID, partNumber, partRevision, lastSeq, subassObj, mfail)

#define x3GetPartByAttrsAndDb(ClassName, databaseName, partOBID, partNumber, partRevision, lastSeq, subassObj, mfail) \
        _x3GetPartByAttrsAndDb(ClassName, FALSE, ClassName, databaseName, partOBID, partNumber, partRevision, lastSeq, subassObj, mfail)
#define x3GetPartByAttrsAndDbAtParent(_class, ClassName, databaseName, partOBID, partNumber, partRevision, lastSeq, subassObj, mfail) \
        _x3GetPartByAttrsAndDb(_class, TRUE, ClassName, databaseName, partOBID, partNumber, partRevision, lastSeq, subassObj, mfail)

#define x3GetPartByPartNumber(className, partNumber, PartObj, mfail) \
        _x3GetPartByPartNumber(className, FALSE, className, partNumber, PartObj, mfail)
#define x3GetPartByPartNumberAtParent(_class, className, partNumber, PartObj, mfail) \
        _x3GetPartByPartNumber(_class, TRUE, className, partNumber, PartObj, mfail)

#define x3GetPartForCatalog(sWkBnchClass, sPartClassName, sPartOBID, sPartDbName, pObj, mfail) \
        _x3GetPartForCatalog(sWkBnchClass, FALSE, sWkBnchClass, sPartClassName, sPartOBID, sPartDbName, pObj, mfail)
#define x3GetPartForCatalogAtParent(_class, sWkBnchClass, sPartClassName, sPartOBID, sPartDbName, pObj, mfail) \
        _x3GetPartForCatalog(_class, TRUE, sWkBnchClass, sPartClassName, sPartOBID, sPartDbName, pObj, mfail)

#define x3GetPartForCatalogExt(sWkBnchClass, sPartClassName, sPartOBID, sPartDbName, bGetLastCtlgElem, pObj, mfail) \
        _x3GetPartForCatalogExt(sWkBnchClass, FALSE, sWkBnchClass, sPartClassName, sPartOBID, sPartDbName, bGetLastCtlgElem, pObj, mfail)
#define x3GetPartForCatalogExtAtParent(_class, sWkBnchClass, sPartClassName, sPartOBID, sPartDbName, bGetLastCtlgElem, pObj, mfail) \
        _x3GetPartForCatalogExt(_class, TRUE, sWkBnchClass, sPartClassName, sPartOBID, sPartDbName, bGetLastCtlgElem, pObj, mfail)

#define x3GetPartInfoForCAD(this, PartRel, LabelSet, ValueSet, mfail) \
        _x3GetPartInfoForCADAtClass(NULL, FALSE, this, PartRel, LabelSet, ValueSet, mfail)
#define x3GetPartInfoForCADAtClass(class, this, PartRel, LabelSet, ValueSet, mfail) \
        _x3GetPartInfoForCADAtClass(class, FALSE, this, PartRel, LabelSet, ValueSet, mfail)
#define x3GetPartInfoForCADAtParent(class, this, PartRel, LabelSet, ValueSet, mfail) \
        _x3GetPartInfoForCADAtClass(class, TRUE, this, PartRel, LabelSet, ValueSet, mfail)

#define x3GetPartModelViaObid(className, modelOBID, modelObj, mfail) \
        _x3GetPartModelViaObid(className, FALSE, className, modelOBID, modelObj, mfail)
#define x3GetPartModelViaObidAtParent(_class, className, modelOBID, modelObj, mfail) \
        _x3GetPartModelViaObid(_class, TRUE, className, modelOBID, modelObj, mfail)

#define x3GetPartObjViaObid(className, partOBID, partObj, mfail) \
        _x3GetPartObjViaObid(className, FALSE, className, partOBID, partObj, mfail)
#define x3GetPartObjViaObidAtParent(_class, className, partOBID, partObj, mfail) \
        _x3GetPartObjViaObid(_class, TRUE, className, partOBID, partObj, mfail)

#define x3GetPartObjViaObidDb(className, partOBID, partDbName, partObj, mfail) \
        _x3GetPartObjViaObidDb(className, FALSE, className, partOBID, partDbName, partObj, mfail)
#define x3GetPartObjViaObidDbAtParent(_class, className, partOBID, partDbName, partObj, mfail) \
        _x3GetPartObjViaObidDb(_class, TRUE, className, partOBID, partDbName, partObj, mfail)

#define x3GetPartsInAssViaOBID(ClassName, PartObj, RelIDs, PartIDs, PosInstNbrSet, PartNbrSet, PartRevSet, lastSeq, RelationSet, PartSet, mfail) \
        _x3GetPartsInAssViaOBID(ClassName, FALSE, ClassName, PartObj, RelIDs, PartIDs, PosInstNbrSet, PartNbrSet, PartRevSet, lastSeq, RelationSet, PartSet, mfail)
#define x3GetPartsInAssViaOBIDAtParent(_class, ClassName, PartObj, RelIDs, PartIDs, PosInstNbrSet, PartNbrSet, PartRevSet, lastSeq, RelationSet, PartSet, mfail) \
        _x3GetPartsInAssViaOBID(_class, TRUE, ClassName, PartObj, RelIDs, PartIDs, PosInstNbrSet, PartNbrSet, PartRevSet, lastSeq, RelationSet, PartSet, mfail)

#define x3GetPlotType(ClassName, plotfeatures, plottype, mfail) \
        _x3GetPlotType(ClassName, FALSE, ClassName, plotfeatures, plottype, mfail)
#define x3GetPlotTypeAtParent(_class, ClassName, plotfeatures, plottype, mfail) \
        _x3GetPlotType(_class, TRUE, ClassName, plotfeatures, plottype, mfail)

#define x3GetPrdDocName(className, partNumber, documentName, mfail) \
        _x3GetPrdDocName(className, FALSE, className, partNumber, documentName, mfail)
#define x3GetPrdDocNameAtParent(_class, className, partNumber, documentName, mfail) \
        _x3GetPrdDocName(_class, TRUE, className, partNumber, documentName, mfail)

#define x3GetPrdPartObjViaObid(className, partOBID, customData, partObj, mfail) \
        _x3GetPrdPartObjViaObid(className, FALSE, className, partOBID, customData, partObj, mfail)
#define x3GetPrdPartObjViaObidAtParent(_class, className, partOBID, customData, partObj, mfail) \
        _x3GetPrdPartObjViaObid(_class, TRUE, className, partOBID, customData, partObj, mfail)

#define x3GetPrdPartViaObidDb(className, partOBID, partDbName, customData, partObj, mfail) \
        _x3GetPrdPartViaObidDb(className, FALSE, className, partOBID, partDbName, customData, partObj, mfail)
#define x3GetPrdPartViaObidDbAtParent(_class, className, partOBID, partDbName, customData, partObj, mfail) \
        _x3GetPrdPartViaObidDb(_class, TRUE, className, partOBID, partDbName, customData, partObj, mfail)

#define x3GetProductInfo(className, vProductInfo, mfail) \
        _x3GetProductInfo(className, FALSE, className, vProductInfo, mfail)
#define x3GetProductInfoAtParent(_class, className, vProductInfo, mfail) \
        _x3GetProductInfo(_class, TRUE, className, vProductInfo, mfail)

#define x3GetRefObjectInfos(className, nvsObjInfos, sXmap, WkBnchObj, nvsObjOutput, nvsPrdOutput, mfail) \
        _x3GetRefObjectInfos(className, FALSE, className, nvsObjInfos, sXmap, WkBnchObj, nvsObjOutput, nvsPrdOutput, mfail)
#define x3GetRefObjectInfosAtParent(_class, className, nvsObjInfos, sXmap, WkBnchObj, nvsObjOutput, nvsPrdOutput, mfail) \
        _x3GetRefObjectInfos(_class, TRUE, className, nvsObjInfos, sXmap, WkBnchObj, nvsObjOutput, nvsPrdOutput, mfail)

#define x3GetReferenceInfo(className, parameterSet, outputSet, mfail) \
        _x3GetReferenceInfo(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3GetReferenceInfoAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3GetReferenceInfo(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3GetRelAttrForSaveSes(className, itemObject, AttrSlotSet, ValueSlotSet, mfail) \
        _x3GetRelAttrForSaveSes(className, FALSE, className, itemObject, AttrSlotSet, ValueSlotSet, mfail)
#define x3GetRelAttrForSaveSesAtParent(_class, className, itemObject, AttrSlotSet, ValueSlotSet, mfail) \
        _x3GetRelAttrForSaveSes(_class, TRUE, className, itemObject, AttrSlotSet, ValueSlotSet, mfail)

#define x3GetRelAttributeApi(className, parameterSet, outputSet, mfail) \
        _x3GetRelAttributeApi(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3GetRelAttributeApiAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3GetRelAttributeApi(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3GetRelForParts(className, leftPrtObj, rightPrtObj, usesInfos, newRelObj, mfail) \
        _x3GetRelForParts(className, FALSE, className, leftPrtObj, rightPrtObj, usesInfos, newRelObj, mfail)
#define x3GetRelForPartsAtParent(_class, className, leftPrtObj, rightPrtObj, usesInfos, newRelObj, mfail) \
        _x3GetRelForParts(_class, TRUE, className, leftPrtObj, rightPrtObj, usesInfos, newRelObj, mfail)

#define x3GetRelInfoForCAD(this, LabelSet, ValueSet, mfail) \
        _x3GetRelInfoForCADAtClass(NULL, FALSE, this, LabelSet, ValueSet, mfail)
#define x3GetRelInfoForCADAtClass(class, this, LabelSet, ValueSet, mfail) \
        _x3GetRelInfoForCADAtClass(class, FALSE, this, LabelSet, ValueSet, mfail)
#define x3GetRelInfoForCADAtParent(class, this, LabelSet, ValueSet, mfail) \
        _x3GetRelInfoForCADAtClass(class, TRUE, this, LabelSet, ValueSet, mfail)

#define x3GetRelToBeUpdated(FatherAssm, rel_id, relObj, mfail) \
        _x3GetRelToBeUpdatedAtClass(NULL, FALSE, FatherAssm, rel_id, relObj, mfail)
#define x3GetRelToBeUpdatedAtClass(class, FatherAssm, rel_id, relObj, mfail) \
        _x3GetRelToBeUpdatedAtClass(class, FALSE, FatherAssm, rel_id, relObj, mfail)
#define x3GetRelToBeUpdatedAtParent(class, FatherAssm, rel_id, relObj, mfail) \
        _x3GetRelToBeUpdatedAtClass(class, TRUE, FatherAssm, rel_id, relObj, mfail)

#define x3GetRelevRelViaExpand(partObj, relObid, relObj, mfail) \
        _x3GetRelevRelViaExpandAtClass(NULL, FALSE, partObj, relObid, relObj, mfail)
#define x3GetRelevRelViaExpandAtClass(class, partObj, relObid, relObj, mfail) \
        _x3GetRelevRelViaExpandAtClass(class, FALSE, partObj, relObid, relObj, mfail)
#define x3GetRelevRelViaExpandAtParent(class, partObj, relObid, relObj, mfail) \
        _x3GetRelevRelViaExpandAtClass(class, TRUE, partObj, relObid, relObj, mfail)

#define x3GetRelevRelViaObid(ClassName, RelOBID, Relation, mfail) \
        _x3GetRelevRelViaObid(ClassName, FALSE, ClassName, RelOBID, Relation, mfail)
#define x3GetRelevRelViaObidAtParent(_class, ClassName, RelOBID, Relation, mfail) \
        _x3GetRelevRelViaObid(_class, TRUE, ClassName, RelOBID, Relation, mfail)

#define x3GetRelevRelViaObidDb(ClassName, RelOBID, DataBaseName, Relation, mfail) \
        _x3GetRelevRelViaObidDb(ClassName, FALSE, ClassName, RelOBID, DataBaseName, Relation, mfail)
#define x3GetRelevRelViaObidDbAtParent(_class, ClassName, RelOBID, DataBaseName, Relation, mfail) \
        _x3GetRelevRelViaObidDb(_class, TRUE, ClassName, RelOBID, DataBaseName, Relation, mfail)

#define x3GetSceneFile(className, fileContents, mfail) \
        _x3GetSceneFile(className, FALSE, className, fileContents, mfail)
#define x3GetSceneFileAtParent(_class, className, fileContents, mfail) \
        _x3GetSceneFile(_class, TRUE, className, fileContents, mfail)

#define x3GetSendingObjs(ctItemObj, WkBnchObj, sendingObjs, mfail) \
        _x3GetSendingObjsAtClass(NULL, FALSE, ctItemObj, WkBnchObj, sendingObjs, mfail)
#define x3GetSendingObjsAtClass(class, ctItemObj, WkBnchObj, sendingObjs, mfail) \
        _x3GetSendingObjsAtClass(class, FALSE, ctItemObj, WkBnchObj, sendingObjs, mfail)
#define x3GetSendingObjsAtParent(class, ctItemObj, WkBnchObj, sendingObjs, mfail) \
        _x3GetSendingObjsAtClass(class, TRUE, ctItemObj, WkBnchObj, sendingObjs, mfail)

#define x3GetSheetNames(ModelObject, SheetList, mfail) \
        _x3GetSheetNamesAtClass(NULL, FALSE, ModelObject, SheetList, mfail)
#define x3GetSheetNamesAtClass(class, ModelObject, SheetList, mfail) \
        _x3GetSheetNamesAtClass(class, FALSE, ModelObject, SheetList, mfail)
#define x3GetSheetNamesAtParent(class, ModelObject, SheetList, mfail) \
        _x3GetSheetNamesAtClass(class, TRUE, ModelObject, SheetList, mfail)

#define x3GetSourceCgrFilePath(thisPtr, sHost, sUser, sCgrfullPath, mfail) \
        _x3GetSourceCgrFilePathAtClass(NULL, FALSE, thisPtr, sHost, sUser, sCgrfullPath, mfail)
#define x3GetSourceCgrFilePathAtClass(class, thisPtr, sHost, sUser, sCgrfullPath, mfail) \
        _x3GetSourceCgrFilePathAtClass(class, FALSE, thisPtr, sHost, sUser, sCgrfullPath, mfail)
#define x3GetSourceCgrFilePathAtParent(class, thisPtr, sHost, sUser, sCgrfullPath, mfail) \
        _x3GetSourceCgrFilePathAtClass(class, TRUE, thisPtr, sHost, sUser, sCgrfullPath, mfail)

#define x3GetSplitComponents(this, splitComps, mfail) \
        _x3GetSplitComponentsAtClass(NULL, FALSE, this, splitComps, mfail)
#define x3GetSplitComponentsAtClass(class, this, splitComps, mfail) \
        _x3GetSplitComponentsAtClass(class, FALSE, this, splitComps, mfail)
#define x3GetSplitComponentsAtParent(class, this, splitComps, mfail) \
        _x3GetSplitComponentsAtClass(class, TRUE, this, splitComps, mfail)

#define x3GetStandardPartInfo(className, partNumber, bIsStandard, bExists, sClassName, sObid, mfail) \
        _x3GetStandardPartInfo(className, FALSE, className, partNumber, bIsStandard, bExists, sClassName, sObid, mfail)
#define x3GetStandardPartInfoAtParent(_class, className, partNumber, bIsStandard, bExists, sClassName, sObid, mfail) \
        _x3GetStandardPartInfo(_class, TRUE, className, partNumber, bIsStandard, bExists, sClassName, sObid, mfail)

#define x3GetStdDataForCAD(classname, this, objectid, attributelist, valuelist, mfail) \
        _x3GetStdDataForCAD(classname, FALSE, classname, this, objectid, attributelist, valuelist, mfail)
#define x3GetStdDataForCADAtParent(_class, classname, this, objectid, attributelist, valuelist, mfail) \
        _x3GetStdDataForCAD(_class, TRUE, classname, this, objectid, attributelist, valuelist, mfail)

#define x3GetStdDataForCADExt(classname, this, docObj, objectid, attributelist, valuelist, mfail) \
        _x3GetStdDataForCADExt(classname, FALSE, classname, this, docObj, objectid, attributelist, valuelist, mfail)
#define x3GetStdDataForCADExtAtParent(_class, classname, this, docObj, objectid, attributelist, valuelist, mfail) \
        _x3GetStdDataForCADExt(_class, TRUE, classname, this, docObj, objectid, attributelist, valuelist, mfail)

#define x3GetSubAssRelsForObid(ctItemObj, partOBID, foundRelObjs, mfail) \
        _x3GetSubAssRelsForObidAtClass(NULL, FALSE, ctItemObj, partOBID, foundRelObjs, mfail)
#define x3GetSubAssRelsForObidAtClass(class, ctItemObj, partOBID, foundRelObjs, mfail) \
        _x3GetSubAssRelsForObidAtClass(class, FALSE, ctItemObj, partOBID, foundRelObjs, mfail)
#define x3GetSubAssRelsForObidAtParent(class, ctItemObj, partOBID, foundRelObjs, mfail) \
        _x3GetSubAssRelsForObidAtClass(class, TRUE, ctItemObj, partOBID, foundRelObjs, mfail)

#define x3GetSupplyFilePath(sThisClassName, vObjectObid, vObjectDbName, vObjectClassName, sFileName, sInfoFromCAD, sHost, sFullPath, sReturnCode, mfail) \
        _x3GetSupplyFilePath(sThisClassName, FALSE, sThisClassName, vObjectObid, vObjectDbName, vObjectClassName, sFileName, sInfoFromCAD, sHost, sFullPath, sReturnCode, mfail)
#define x3GetSupplyFilePathAtParent(_class, sThisClassName, vObjectObid, vObjectDbName, vObjectClassName, sFileName, sInfoFromCAD, sHost, sFullPath, sReturnCode, mfail) \
        _x3GetSupplyFilePath(_class, TRUE, sThisClassName, vObjectObid, vObjectDbName, vObjectClassName, sFileName, sInfoFromCAD, sHost, sFullPath, sReturnCode, mfail)

#define x3GetTargetCATIAPref(classname, vCATIASystem, mfail) \
        _x3GetTargetCATIAPref(classname, FALSE, classname, vCATIASystem, mfail)
#define x3GetTargetCATIAPrefAtParent(_class, classname, vCATIASystem, mfail) \
        _x3GetTargetCATIAPref(_class, TRUE, classname, vCATIASystem, mfail)

#define x3GetTempVaultLocVS(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _x3GetTempVaultLocVSAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define x3GetTempVaultLocVSAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _x3GetTempVaultLocVSAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define x3GetTempVaultLocVSAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _x3GetTempVaultLocVSAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define x3GetTemps(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _x3GetTempsAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define x3GetTempsAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _x3GetTempsAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define x3GetTempsAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _x3GetTempsAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define x3GetTrafos(this, indexSet, trafoSet, unit, mfail) \
        _x3GetTrafosAtClass(NULL, FALSE, this, indexSet, trafoSet, unit, mfail)
#define x3GetTrafosAtClass(class, this, indexSet, trafoSet, unit, mfail) \
        _x3GetTrafosAtClass(class, FALSE, this, indexSet, trafoSet, unit, mfail)
#define x3GetTrafosAtParent(class, this, indexSet, trafoSet, unit, mfail) \
        _x3GetTrafosAtClass(class, TRUE, this, indexSet, trafoSet, unit, mfail)

#define x3GetTrafosOfTable(this, indexSet, trafoSet, mfail) \
        _x3GetTrafosOfTableAtClass(NULL, FALSE, this, indexSet, trafoSet, mfail)
#define x3GetTrafosOfTableAtClass(class, this, indexSet, trafoSet, mfail) \
        _x3GetTrafosOfTableAtClass(class, FALSE, this, indexSet, trafoSet, mfail)
#define x3GetTrafosOfTableAtParent(class, this, indexSet, trafoSet, mfail) \
        _x3GetTrafosOfTableAtClass(class, TRUE, this, indexSet, trafoSet, mfail)

#define x3GetUdfPartForCatalog(sWkBnchClass, sClgClassName, sClgOBID, sClgDbName, pObj, mfail) \
        _x3GetUdfPartForCatalog(sWkBnchClass, FALSE, sWkBnchClass, sClgClassName, sClgOBID, sClgDbName, pObj, mfail)
#define x3GetUdfPartForCatalogAtParent(_class, sWkBnchClass, sClgClassName, sClgOBID, sClgDbName, pObj, mfail) \
        _x3GetUdfPartForCatalog(_class, TRUE, sWkBnchClass, sClgClassName, sClgOBID, sClgDbName, pObj, mfail)

#define x3GetV5ProductTemplate(thisObj, tplObj, mfail) \
        _x3GetV5ProductTemplateAtClass(NULL, FALSE, thisObj, tplObj, mfail)
#define x3GetV5ProductTemplateAtClass(class, thisObj, tplObj, mfail) \
        _x3GetV5ProductTemplateAtClass(class, FALSE, thisObj, tplObj, mfail)
#define x3GetV5ProductTemplateAtParent(class, thisObj, tplObj, mfail) \
        _x3GetV5ProductTemplateAtClass(class, TRUE, thisObj, tplObj, mfail)

#define x3GetViewerFile(thisRep, thisObj, viewFormat, workBench, sHost, sUser, sFullPath, sNewFileName, iStatus, mfail) \
        _x3GetViewerFileAtClass(NULL, FALSE, thisRep, thisObj, viewFormat, workBench, sHost, sUser, sFullPath, sNewFileName, iStatus, mfail)
#define x3GetViewerFileAtClass(class, thisRep, thisObj, viewFormat, workBench, sHost, sUser, sFullPath, sNewFileName, iStatus, mfail) \
        _x3GetViewerFileAtClass(class, FALSE, thisRep, thisObj, viewFormat, workBench, sHost, sUser, sFullPath, sNewFileName, iStatus, mfail)
#define x3GetViewerFileAtParent(class, thisRep, thisObj, viewFormat, workBench, sHost, sUser, sFullPath, sNewFileName, iStatus, mfail) \
        _x3GetViewerFileAtClass(class, TRUE, thisRep, thisObj, viewFormat, workBench, sHost, sUser, sFullPath, sNewFileName, iStatus, mfail)

#define x3GetViewerFileContent(className, fileContents, mfail) \
        _x3GetViewerFileContent(className, FALSE, className, fileContents, mfail)
#define x3GetViewerFileContentAtParent(_class, className, fileContents, mfail) \
        _x3GetViewerFileContent(_class, TRUE, className, fileContents, mfail)

#define x3GetViewerFileNames(thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _x3GetViewerFileNamesAtClass(NULL, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define x3GetViewerFileNamesAtClass(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _x3GetViewerFileNamesAtClass(class, FALSE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)
#define x3GetViewerFileNamesAtParent(class, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail) \
        _x3GetViewerFileNamesAtClass(class, TRUE, thisObj, valueSetName, lvAttribute, realClass, realObj, extraStr, extraObj, uiSort, uiTextId, uiTextInserts, values, mfail)

#define x3GetWBInfo(className, mfail) \
        _x3GetWBInfo(className, FALSE, className, mfail)
#define x3GetWBInfoAtParent(_class, className, mfail) \
        _x3GetWBInfo(_class, TRUE, className, mfail)

#define x3GetWBItems(classname, ctItems, mfail) \
        _x3GetWBItems(classname, FALSE, classname, ctItems, mfail)
#define x3GetWBItemsAtParent(_class, classname, ctItems, mfail) \
        _x3GetWBItems(_class, TRUE, classname, ctItems, mfail)

#define x3GetWayToRoot(ClassName, CatiaItemID, CtItDpRelObjSet, assmStrcList, mfail) \
        _x3GetWayToRoot(ClassName, FALSE, ClassName, CatiaItemID, CtItDpRelObjSet, assmStrcList, mfail)
#define x3GetWayToRootAtParent(_class, ClassName, CatiaItemID, CtItDpRelObjSet, assmStrcList, mfail) \
        _x3GetWayToRoot(_class, TRUE, ClassName, CatiaItemID, CtItDpRelObjSet, assmStrcList, mfail)

#define x3GetWorkBenchClass(className, WkBnchClass, mfail) \
        _x3GetWorkBenchClass(className, FALSE, className, WkBnchClass, mfail)
#define x3GetWorkBenchClassAtParent(_class, className, WkBnchClass, mfail) \
        _x3GetWorkBenchClass(_class, TRUE, className, WkBnchClass, mfail)

#define x3GetWorkLocForCreate(classname, worklocation, mfail) \
        _x3GetWorkLocForCreate(classname, FALSE, classname, worklocation, mfail)
#define x3GetWorkLocForCreateAtParent(_class, classname, worklocation, mfail) \
        _x3GetWorkLocForCreate(_class, TRUE, classname, worklocation, mfail)

#define x3GetWorkLocationInfo(classname, worklocation, username, worklocDir, worklocHost, mfail) \
        _x3GetWorkLocationInfo(classname, FALSE, classname, worklocation, username, worklocDir, worklocHost, mfail)
#define x3GetWorkLocationInfoAtParent(_class, classname, worklocation, username, worklocDir, worklocHost, mfail) \
        _x3GetWorkLocationInfo(_class, TRUE, classname, worklocation, username, worklocDir, worklocHost, mfail)

#define x3GetsCMIProtocol(className, l0PartnerObjMgrSet, mfail) \
        _x3GetsCMIProtocol(className, FALSE, className, l0PartnerObjMgrSet, mfail)
#define x3GetsCMIProtocolAtParent(_class, className, l0PartnerObjMgrSet, mfail) \
        _x3GetsCMIProtocol(_class, TRUE, className, l0PartnerObjMgrSet, mfail)

#define x3HasSendingObjs(ctItemObj, bSendingMode, mfail) \
        _x3HasSendingObjsAtClass(NULL, FALSE, ctItemObj, bSendingMode, mfail)
#define x3HasSendingObjsAtClass(class, ctItemObj, bSendingMode, mfail) \
        _x3HasSendingObjsAtClass(class, FALSE, ctItemObj, bSendingMode, mfail)
#define x3HasSendingObjsAtParent(class, ctItemObj, bSendingMode, mfail) \
        _x3HasSendingObjsAtClass(class, TRUE, ctItemObj, bSendingMode, mfail)

#define x3HasTrafo(thisObj, itemObj, bHasTrafo, mfail) \
        _x3HasTrafoAtClass(NULL, FALSE, thisObj, itemObj, bHasTrafo, mfail)
#define x3HasTrafoAtClass(class, thisObj, itemObj, bHasTrafo, mfail) \
        _x3HasTrafoAtClass(class, FALSE, thisObj, itemObj, bHasTrafo, mfail)
#define x3HasTrafoAtParent(class, thisObj, itemObj, bHasTrafo, mfail) \
        _x3HasTrafoAtClass(class, TRUE, thisObj, itemObj, bHasTrafo, mfail)

#define x3HelpOnProduct(className, mfail) \
        _x3HelpOnProduct(className, FALSE, className, mfail)
#define x3HelpOnProductAtParent(_class, className, mfail) \
        _x3HelpOnProduct(_class, TRUE, className, mfail)

#define x3HighlightAssemblies(ClassName, vStrSet, mfail) \
        _x3HighlightAssemblies(ClassName, FALSE, ClassName, vStrSet, mfail)
#define x3HighlightAssembliesAtParent(_class, ClassName, vStrSet, mfail) \
        _x3HighlightAssemblies(_class, TRUE, ClassName, vStrSet, mfail)

#define x3HighlightAssyInWb(ClassName, PartOBID, WayToRoot, mfail) \
        _x3HighlightAssyInWb(ClassName, FALSE, ClassName, PartOBID, WayToRoot, mfail)
#define x3HighlightAssyInWbAtParent(_class, ClassName, PartOBID, WayToRoot, mfail) \
        _x3HighlightAssyInWb(_class, TRUE, ClassName, PartOBID, WayToRoot, mfail)

#define x3HighlightInWB(className, parameterSet, outputSet, mfail) \
        _x3HighlightInWB(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3HighlightInWBAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3HighlightInWB(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3HighlightModel(thisObj, mfail) \
        _x3HighlightModelAtClass(NULL, FALSE, thisObj, mfail)
#define x3HighlightModelAtClass(class, thisObj, mfail) \
        _x3HighlightModelAtClass(class, FALSE, thisObj, mfail)
#define x3HighlightModelAtParent(class, thisObj, mfail) \
        _x3HighlightModelAtClass(class, TRUE, thisObj, mfail)

#define x3HighlightProduct(thisObj, mfail) \
        _x3HighlightProductAtClass(NULL, FALSE, thisObj, mfail)
#define x3HighlightProductAtClass(class, thisObj, mfail) \
        _x3HighlightProductAtClass(class, FALSE, thisObj, mfail)
#define x3HighlightProductAtParent(class, thisObj, mfail) \
        _x3HighlightProductAtClass(class, TRUE, thisObj, mfail)

#define x3HighlightSetOfModels(className, mfail) \
        _x3HighlightSetOfModels(className, FALSE, className, mfail)
#define x3HighlightSetOfModelsAtParent(_class, className, mfail) \
        _x3HighlightSetOfModels(_class, TRUE, className, mfail)

#define x3HilightModelInWb(ClassName, ModelOBID, PartOBID, WayToRoot, DocrelId, mfail) \
        _x3HilightModelInWb(ClassName, FALSE, ClassName, ModelOBID, PartOBID, WayToRoot, DocrelId, mfail)
#define x3HilightModelInWbAtParent(_class, ClassName, ModelOBID, PartOBID, WayToRoot, DocrelId, mfail) \
        _x3HilightModelInWb(_class, TRUE, ClassName, ModelOBID, PartOBID, WayToRoot, DocrelId, mfail)

#define x3HilightModelsByLstnr(ClassName, vStrSet, mfail) \
        _x3HilightModelsByLstnr(ClassName, FALSE, ClassName, vStrSet, mfail)
#define x3HilightModelsByLstnrAtParent(_class, ClassName, vStrSet, mfail) \
        _x3HilightModelsByLstnr(_class, TRUE, ClassName, vStrSet, mfail)

#define x3ImportCMIFile(className, parameterSet, outputSet, mfail) \
        _x3ImportCMIFile(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3ImportCMIFileAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3ImportCMIFile(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3ImportCustomFile(className, parameterSet, outputSet, mfail) \
        _x3ImportCustomFile(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3ImportCustomFileAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3ImportCustomFile(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3ImportFile(className, mfail) \
        _x3ImportFile(className, FALSE, className, mfail)
#define x3ImportFileAtParent(_class, className, mfail) \
        _x3ImportFile(_class, TRUE, className, mfail)

#define x3ImportFileToWB(className, fileName, mfail) \
        _x3ImportFileToWB(className, FALSE, className, fileName, mfail)
#define x3ImportFileToWBAtParent(_class, className, fileName, mfail) \
        _x3ImportFileToWB(_class, TRUE, className, fileName, mfail)

#define x3IncreaseRelQty(thisPtr, leftPrtObj, rightPrtObj, mfail) \
        _x3IncreaseRelQtyAtClass(NULL, FALSE, thisPtr, leftPrtObj, rightPrtObj, mfail)
#define x3IncreaseRelQtyAtClass(class, thisPtr, leftPrtObj, rightPrtObj, mfail) \
        _x3IncreaseRelQtyAtClass(class, FALSE, thisPtr, leftPrtObj, rightPrtObj, mfail)
#define x3IncreaseRelQtyAtParent(class, thisPtr, leftPrtObj, rightPrtObj, mfail) \
        _x3IncreaseRelQtyAtClass(class, TRUE, thisPtr, leftPrtObj, rightPrtObj, mfail)

#define x3Inflate4DNavName(self, RelativePath, mfail) \
        _x3Inflate4DNavNameAtClass(NULL, FALSE, self, RelativePath, mfail)
#define x3Inflate4DNavNameAtClass(class, self, RelativePath, mfail) \
        _x3Inflate4DNavNameAtClass(class, FALSE, self, RelativePath, mfail)
#define x3Inflate4DNavNameAtParent(class, self, RelativePath, mfail) \
        _x3Inflate4DNavNameAtClass(class, TRUE, self, RelativePath, mfail)

#define x3InflateExMapName(thisObj, mfail) \
        _x3InflateExMapNameAtClass(NULL, FALSE, thisObj, mfail)
#define x3InflateExMapNameAtClass(class, thisObj, mfail) \
        _x3InflateExMapNameAtClass(class, FALSE, thisObj, mfail)
#define x3InflateExMapNameAtParent(class, thisObj, mfail) \
        _x3InflateExMapNameAtClass(class, TRUE, thisObj, mfail)

#define x3InflateExMapNameV5(thisObj, mfail) \
        _x3InflateExMapNameV5AtClass(NULL, FALSE, thisObj, mfail)
#define x3InflateExMapNameV5AtClass(class, thisObj, mfail) \
        _x3InflateExMapNameV5AtClass(class, FALSE, thisObj, mfail)
#define x3InflateExMapNameV5AtParent(class, thisObj, mfail) \
        _x3InflateExMapNameV5AtClass(class, TRUE, thisObj, mfail)

#define x3InitiateDocCreateMsg(className, vWorkMode, vStrSet, mfail) \
        _x3InitiateDocCreateMsg(className, FALSE, className, vWorkMode, vStrSet, mfail)
#define x3InitiateDocCreateMsgAtParent(_class, className, vWorkMode, vStrSet, mfail) \
        _x3InitiateDocCreateMsg(_class, TRUE, className, vWorkMode, vStrSet, mfail)

#define x3InitiateDocMulCreMsg(ClassName, vWorkMode, vStrSet, mfail) \
        _x3InitiateDocMulCreMsg(ClassName, FALSE, ClassName, vWorkMode, vStrSet, mfail)
#define x3InitiateDocMulCreMsgAtParent(_class, ClassName, vWorkMode, vStrSet, mfail) \
        _x3InitiateDocMulCreMsg(_class, TRUE, ClassName, vWorkMode, vStrSet, mfail)

#define x3InitiateReadMsg(className, vWorkMode, vStrSet, mfail) \
        _x3InitiateReadMsg(className, FALSE, className, vWorkMode, vStrSet, mfail)
#define x3InitiateReadMsgAtParent(_class, className, vWorkMode, vStrSet, mfail) \
        _x3InitiateReadMsg(_class, TRUE, className, vWorkMode, vStrSet, mfail)

#define x3InitiateReadTmpMsg(className, vWorkMode, vStrSet, mfail) \
        _x3InitiateReadTmpMsg(className, FALSE, className, vWorkMode, vStrSet, mfail)
#define x3InitiateReadTmpMsgAtParent(_class, className, vWorkMode, vStrSet, mfail) \
        _x3InitiateReadTmpMsg(_class, TRUE, className, vWorkMode, vStrSet, mfail)

#define x3InitiateReplaceMsg(className, vWorkMode, vStrSet, mfail) \
        _x3InitiateReplaceMsg(className, FALSE, className, vWorkMode, vStrSet, mfail)
#define x3InitiateReplaceMsgAtParent(_class, className, vWorkMode, vStrSet, mfail) \
        _x3InitiateReplaceMsg(_class, TRUE, className, vWorkMode, vStrSet, mfail)

#define x3InitiateRereadMsg(className, vWorkMode, vStrSet, mfail) \
        _x3InitiateRereadMsg(className, FALSE, className, vWorkMode, vStrSet, mfail)
#define x3InitiateRereadMsgAtParent(_class, className, vWorkMode, vStrSet, mfail) \
        _x3InitiateRereadMsg(_class, TRUE, className, vWorkMode, vStrSet, mfail)

#define x3InitiateWPChangeMsg(className, vWorkMode, vStrSet, mfail) \
        _x3InitiateWPChangeMsg(className, FALSE, className, vWorkMode, vStrSet, mfail)
#define x3InitiateWPChangeMsgAtParent(_class, className, vWorkMode, vStrSet, mfail) \
        _x3InitiateWPChangeMsg(_class, TRUE, className, vWorkMode, vStrSet, mfail)

#define x3InstNameExist(thisObj, sInstanceName, bInstNameExists, mfail) \
        _x3InstNameExistAtClass(NULL, FALSE, thisObj, sInstanceName, bInstNameExists, mfail)
#define x3InstNameExistAtClass(class, thisObj, sInstanceName, bInstNameExists, mfail) \
        _x3InstNameExistAtClass(class, FALSE, thisObj, sInstanceName, bInstNameExists, mfail)
#define x3InstNameExistAtParent(class, thisObj, sInstanceName, bInstNameExists, mfail) \
        _x3InstNameExistAtClass(class, TRUE, thisObj, sInstanceName, bInstNameExists, mfail)

#define x3IsCatalogReadType(thisObj, bIsCatalogReadType, mfail) \
        _x3IsCatalogReadTypeAtClass(NULL, FALSE, thisObj, bIsCatalogReadType, mfail)
#define x3IsCatalogReadTypeAtClass(class, thisObj, bIsCatalogReadType, mfail) \
        _x3IsCatalogReadTypeAtClass(class, FALSE, thisObj, bIsCatalogReadType, mfail)
#define x3IsCatalogReadTypeAtParent(class, thisObj, bIsCatalogReadType, mfail) \
        _x3IsCatalogReadTypeAtClass(class, TRUE, thisObj, bIsCatalogReadType, mfail)

#define x3IsCompStrctToChange(thisObj, bCompStructChange, mfail) \
        _x3IsCompStrctToChangeAtClass(NULL, FALSE, thisObj, bCompStructChange, mfail)
#define x3IsCompStrctToChangeAtClass(class, thisObj, bCompStructChange, mfail) \
        _x3IsCompStrctToChangeAtClass(class, FALSE, thisObj, bCompStructChange, mfail)
#define x3IsCompStrctToChangeAtParent(class, thisObj, bCompStructChange, mfail) \
        _x3IsCompStrctToChangeAtClass(class, TRUE, thisObj, bCompStructChange, mfail)

#define x3IsDependedOnByFiles(modObj, depOnByFiles, mfail) \
        _x3IsDependedOnByFilesAtClass(NULL, FALSE, modObj, depOnByFiles, mfail)
#define x3IsDependedOnByFilesAtClass(class, modObj, depOnByFiles, mfail) \
        _x3IsDependedOnByFilesAtClass(class, FALSE, modObj, depOnByFiles, mfail)
#define x3IsDependedOnByFilesAtParent(class, modObj, depOnByFiles, mfail) \
        _x3IsDependedOnByFilesAtClass(class, TRUE, modObj, depOnByFiles, mfail)

#define x3IsLinkedWithDesTab(modelObj, desTabObj, bLinked, mfail) \
        _x3IsLinkedWithDesTabAtClass(NULL, FALSE, modelObj, desTabObj, bLinked, mfail)
#define x3IsLinkedWithDesTabAtClass(class, modelObj, desTabObj, bLinked, mfail) \
        _x3IsLinkedWithDesTabAtClass(class, FALSE, modelObj, desTabObj, bLinked, mfail)
#define x3IsLinkedWithDesTabAtParent(class, modelObj, desTabObj, bLinked, mfail) \
        _x3IsLinkedWithDesTabAtClass(class, TRUE, modelObj, desTabObj, bLinked, mfail)

#define x3IsLinkedWithDocument(thisObject, docObject, bLinked, mfail) \
        _x3IsLinkedWithDocumentAtClass(NULL, FALSE, thisObject, docObject, bLinked, mfail)
#define x3IsLinkedWithDocumentAtClass(class, thisObject, docObject, bLinked, mfail) \
        _x3IsLinkedWithDocumentAtClass(class, FALSE, thisObject, docObject, bLinked, mfail)
#define x3IsLinkedWithDocumentAtParent(class, thisObject, docObject, bLinked, mfail) \
        _x3IsLinkedWithDocumentAtClass(class, TRUE, thisObject, docObject, bLinked, mfail)

#define x3IsModel2D(thisObject, bIs2DModel, mfail) \
        _x3IsModel2DAtClass(NULL, FALSE, thisObject, bIs2DModel, mfail)
#define x3IsModel2DAtClass(class, thisObject, bIs2DModel, mfail) \
        _x3IsModel2DAtClass(class, FALSE, thisObject, bIs2DModel, mfail)
#define x3IsModel2DAtParent(class, thisObject, bIs2DModel, mfail) \
        _x3IsModel2DAtClass(class, TRUE, thisObject, bIs2DModel, mfail)

#define x3IsStandAloneArchive(ArchiveObj, bIsStandAlone, mfail) \
        _x3IsStandAloneArchiveAtClass(NULL, FALSE, ArchiveObj, bIsStandAlone, mfail)
#define x3IsStandAloneArchiveAtClass(class, ArchiveObj, bIsStandAlone, mfail) \
        _x3IsStandAloneArchiveAtClass(class, FALSE, ArchiveObj, bIsStandAlone, mfail)
#define x3IsStandAloneArchiveAtParent(class, ArchiveObj, bIsStandAlone, mfail) \
        _x3IsStandAloneArchiveAtClass(class, TRUE, ArchiveObj, bIsStandAlone, mfail)

#define x3IsStandardPart(itemObj, partOBID, isStandard, mfail) \
        _x3IsStandardPartAtClass(NULL, FALSE, itemObj, partOBID, isStandard, mfail)
#define x3IsStandardPartAtClass(class, itemObj, partOBID, isStandard, mfail) \
        _x3IsStandardPartAtClass(class, FALSE, itemObj, partOBID, isStandard, mfail)
#define x3IsStandardPartAtParent(class, itemObj, partOBID, isStandard, mfail) \
        _x3IsStandardPartAtClass(class, TRUE, itemObj, partOBID, isStandard, mfail)

#define x3LinkCatDrwToPart(thisObj, ModelInfos, vStats, mfail) \
        _x3LinkCatDrwToPartAtClass(NULL, FALSE, thisObj, ModelInfos, vStats, mfail)
#define x3LinkCatDrwToPartAtClass(class, thisObj, ModelInfos, vStats, mfail) \
        _x3LinkCatDrwToPartAtClass(class, FALSE, thisObj, ModelInfos, vStats, mfail)
#define x3LinkCatDrwToPartAtParent(class, thisObj, ModelInfos, vStats, mfail) \
        _x3LinkCatDrwToPartAtClass(class, TRUE, thisObj, ModelInfos, vStats, mfail)

#define x3LinkWithDesTab(catiaObj, ModelInfos, desTabObj, sPartClassName, sPartOBID, sPartDbName, relObject, vStats, mfail) \
        _x3LinkWithDesTabAtClass(NULL, FALSE, catiaObj, ModelInfos, desTabObj, sPartClassName, sPartOBID, sPartDbName, relObject, vStats, mfail)
#define x3LinkWithDesTabAtClass(class, catiaObj, ModelInfos, desTabObj, sPartClassName, sPartOBID, sPartDbName, relObject, vStats, mfail) \
        _x3LinkWithDesTabAtClass(class, FALSE, catiaObj, ModelInfos, desTabObj, sPartClassName, sPartOBID, sPartDbName, relObject, vStats, mfail)
#define x3LinkWithDesTabAtParent(class, catiaObj, ModelInfos, desTabObj, sPartClassName, sPartOBID, sPartDbName, relObject, vStats, mfail) \
        _x3LinkWithDesTabAtClass(class, TRUE, catiaObj, ModelInfos, desTabObj, sPartClassName, sPartOBID, sPartDbName, relObject, vStats, mfail)

#define x3LinkWithDocument(thisObject, docObject, mfail) \
        _x3LinkWithDocumentAtClass(NULL, FALSE, thisObject, docObject, mfail)
#define x3LinkWithDocumentAtClass(class, thisObject, docObject, mfail) \
        _x3LinkWithDocumentAtClass(class, FALSE, thisObject, docObject, mfail)
#define x3LinkWithDocumentAtParent(class, thisObject, docObject, mfail) \
        _x3LinkWithDocumentAtClass(class, TRUE, thisObject, docObject, mfail)

#define x3LinkWithDocumentExt(thisObject, docObject, matrix, relObject, mfail) \
        _x3LinkWithDocumentExtAtClass(NULL, FALSE, thisObject, docObject, matrix, relObject, mfail)
#define x3LinkWithDocumentExtAtClass(class, thisObject, docObject, matrix, relObject, mfail) \
        _x3LinkWithDocumentExtAtClass(class, FALSE, thisObject, docObject, matrix, relObject, mfail)
#define x3LinkWithDocumentExtAtParent(class, thisObject, docObject, matrix, relObject, mfail) \
        _x3LinkWithDocumentExtAtClass(class, TRUE, thisObject, docObject, matrix, relObject, mfail)

#define x3MarkItem(thisObj, mfail) \
        _x3MarkItemAtClass(NULL, FALSE, thisObj, mfail)
#define x3MarkItemAtClass(class, thisObj, mfail) \
        _x3MarkItemAtClass(class, FALSE, thisObj, mfail)
#define x3MarkItemAtParent(class, thisObj, mfail) \
        _x3MarkItemAtClass(class, TRUE, thisObj, mfail)

#define x3MarkItemNI(this, CtxObj, bToggle, bMark, mfail) \
        _x3MarkItemNIAtClass(NULL, FALSE, this, CtxObj, bToggle, bMark, mfail)
#define x3MarkItemNIAtClass(class, this, CtxObj, bToggle, bMark, mfail) \
        _x3MarkItemNIAtClass(class, FALSE, this, CtxObj, bToggle, bMark, mfail)
#define x3MarkItemNIAtParent(class, this, CtxObj, bToggle, bMark, mfail) \
        _x3MarkItemNIAtClass(class, TRUE, this, CtxObj, bToggle, bMark, mfail)

#define x3MarkSelectedItems(className, SelectedItems, mfail) \
        _x3MarkSelectedItems(className, FALSE, className, SelectedItems, mfail)
#define x3MarkSelectedItemsAtParent(_class, className, SelectedItems, mfail) \
        _x3MarkSelectedItems(_class, TRUE, className, SelectedItems, mfail)

#define x3MarkSubTree(thisObj, mfail) \
        _x3MarkSubTreeAtClass(NULL, FALSE, thisObj, mfail)
#define x3MarkSubTreeAtClass(class, thisObj, mfail) \
        _x3MarkSubTreeAtClass(class, FALSE, thisObj, mfail)
#define x3MarkSubTreeAtParent(class, thisObj, mfail) \
        _x3MarkSubTreeAtClass(class, TRUE, thisObj, mfail)

#define x3MarkTreeNI(this, CtxObj, bMark, mfail) \
        _x3MarkTreeNIAtClass(NULL, FALSE, this, CtxObj, bMark, mfail)
#define x3MarkTreeNIAtClass(class, this, CtxObj, bMark, mfail) \
        _x3MarkTreeNIAtClass(class, FALSE, this, CtxObj, bMark, mfail)
#define x3MarkTreeNIAtParent(class, this, CtxObj, bMark, mfail) \
        _x3MarkTreeNIAtClass(class, TRUE, this, CtxObj, bMark, mfail)

#define x3MarkedTo4DNav(className, mfail) \
        _x3MarkedTo4DNav(className, FALSE, className, mfail)
#define x3MarkedTo4DNavAtParent(_class, className, mfail) \
        _x3MarkedTo4DNav(_class, TRUE, className, mfail)

#define x3MarkedToCatia(className, mfail) \
        _x3MarkedToCatia(className, FALSE, className, mfail)
#define x3MarkedToCatiaAtParent(_class, className, mfail) \
        _x3MarkedToCatia(_class, TRUE, className, mfail)

#define x3MarkedToView(className, mfail) \
        _x3MarkedToView(className, FALSE, className, mfail)
#define x3MarkedToViewAtParent(_class, className, mfail) \
        _x3MarkedToView(_class, TRUE, className, mfail)

#define x3ModelHasPlotFiles(modObj, plotObjs, mfail) \
        _x3ModelHasPlotFilesAtClass(NULL, FALSE, modObj, plotObjs, mfail)
#define x3ModelHasPlotFilesAtClass(class, modObj, plotObjs, mfail) \
        _x3ModelHasPlotFilesAtClass(class, FALSE, modObj, plotObjs, mfail)
#define x3ModelHasPlotFilesAtParent(class, modObj, plotObjs, mfail) \
        _x3ModelHasPlotFilesAtClass(class, TRUE, modObj, plotObjs, mfail)

#define x3MultiDocCreate(this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3MultiDocCreateAtClass(NULL, FALSE, this, WkBnchObj, commObj, BackgroundItem, mfail)
#define x3MultiDocCreateAtClass(class, this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3MultiDocCreateAtClass(class, FALSE, this, WkBnchObj, commObj, BackgroundItem, mfail)
#define x3MultiDocCreateAtParent(class, this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3MultiDocCreateAtClass(class, TRUE, this, WkBnchObj, commObj, BackgroundItem, mfail)

#define x3ObjectHasV5Template(thisObj, bHasTemplate, bIsChangeable, mfail) \
        _x3ObjectHasV5TemplateAtClass(NULL, FALSE, thisObj, bHasTemplate, bIsChangeable, mfail)
#define x3ObjectHasV5TemplateAtClass(class, thisObj, bHasTemplate, bIsChangeable, mfail) \
        _x3ObjectHasV5TemplateAtClass(class, FALSE, thisObj, bHasTemplate, bIsChangeable, mfail)
#define x3ObjectHasV5TemplateAtParent(class, thisObj, bHasTemplate, bIsChangeable, mfail) \
        _x3ObjectHasV5TemplateAtClass(class, TRUE, thisObj, bHasTemplate, bIsChangeable, mfail)

#define x3Open(thisObj, mfail) \
        _x3OpenAtClass(NULL, FALSE, thisObj, mfail)
#define x3OpenAtClass(class, thisObj, mfail) \
        _x3OpenAtClass(class, FALSE, thisObj, mfail)
#define x3OpenAtParent(class, thisObj, mfail) \
        _x3OpenAtClass(class, TRUE, thisObj, mfail)

#define x3PlotFeaturesAreSame(modObj, plotfeatures, are_same, mfail) \
        _x3PlotFeaturesAreSameAtClass(NULL, FALSE, modObj, plotfeatures, are_same, mfail)
#define x3PlotFeaturesAreSameAtClass(class, modObj, plotfeatures, are_same, mfail) \
        _x3PlotFeaturesAreSameAtClass(class, FALSE, modObj, plotfeatures, are_same, mfail)
#define x3PlotFeaturesAreSameAtParent(class, modObj, plotfeatures, are_same, mfail) \
        _x3PlotFeaturesAreSameAtClass(class, TRUE, modObj, plotfeatures, are_same, mfail)

#define x3PlotUpdateFeatures(modObj, catiaModel, plotfeatures, mfail) \
        _x3PlotUpdateFeaturesAtClass(NULL, FALSE, modObj, catiaModel, plotfeatures, mfail)
#define x3PlotUpdateFeaturesAtClass(class, modObj, catiaModel, plotfeatures, mfail) \
        _x3PlotUpdateFeaturesAtClass(class, FALSE, modObj, catiaModel, plotfeatures, mfail)
#define x3PlotUpdateFeaturesAtParent(class, modObj, catiaModel, plotfeatures, mfail) \
        _x3PlotUpdateFeaturesAtClass(class, TRUE, modObj, catiaModel, plotfeatures, mfail)

#define x3PltFileBelongsTo(plotObj, modObj, mfail) \
        _x3PltFileBelongsToAtClass(NULL, FALSE, plotObj, modObj, mfail)
#define x3PltFileBelongsToAtClass(class, plotObj, modObj, mfail) \
        _x3PltFileBelongsToAtClass(class, FALSE, plotObj, modObj, mfail)
#define x3PltFileBelongsToAtParent(class, plotObj, modObj, mfail) \
        _x3PltFileBelongsToAtClass(class, TRUE, plotObj, modObj, mfail)

#define x3PostProcCreatePrd(className, partNumber, sPartClassName, sPartOBID, sPartDbName, sPrdClassName, sPrdOBID, sPrdDbName, vStats, mfail) \
        _x3PostProcCreatePrd(className, FALSE, className, partNumber, sPartClassName, sPartOBID, sPartDbName, sPrdClassName, sPrdOBID, sPrdDbName, vStats, mfail)
#define x3PostProcCreatePrdAtParent(_class, className, partNumber, sPartClassName, sPartOBID, sPartDbName, sPrdClassName, sPrdOBID, sPrdDbName, vStats, mfail) \
        _x3PostProcCreatePrd(_class, TRUE, className, partNumber, sPartClassName, sPartOBID, sPartDbName, sPrdClassName, sPrdOBID, sPrdDbName, vStats, mfail)

#define x3PostProcCreatePrds(className, parameterSet, outputSet, mfail) \
        _x3PostProcCreatePrds(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3PostProcCreatePrdsAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3PostProcCreatePrds(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3PrcCATIADeletionECMI(className, childOBID, childRelOBID, parentClass, parentOBID, matrixIndex, messageText, messageAdded, mfail) \
        _x3PrcCATIADeletionECMI(className, FALSE, className, childOBID, childRelOBID, parentClass, parentOBID, matrixIndex, messageText, messageAdded, mfail)
#define x3PrcCATIADeletionECMIAtParent(_class, className, childOBID, childRelOBID, parentClass, parentOBID, matrixIndex, messageText, messageAdded, mfail) \
        _x3PrcCATIADeletionECMI(_class, TRUE, className, childOBID, childRelOBID, parentClass, parentOBID, matrixIndex, messageText, messageAdded, mfail)

#define x3PrdFileNameInWL(classname, oldFilename, newFilename, mfail) \
        _x3PrdFileNameInWL(classname, FALSE, classname, oldFilename, newFilename, mfail)
#define x3PrdFileNameInWLAtParent(_class, classname, oldFilename, newFilename, mfail) \
        _x3PrdFileNameInWL(_class, TRUE, classname, oldFilename, newFilename, mfail)

#define x3PrepModelsForToCatia(WkBnchObj, pSetOfTCTItems, mfail) \
        _x3PrepModelsForToCatiaAtClass(NULL, FALSE, WkBnchObj, pSetOfTCTItems, mfail)
#define x3PrepModelsForToCatiaAtClass(class, WkBnchObj, pSetOfTCTItems, mfail) \
        _x3PrepModelsForToCatiaAtClass(class, FALSE, WkBnchObj, pSetOfTCTItems, mfail)
#define x3PrepModelsForToCatiaAtParent(class, WkBnchObj, pSetOfTCTItems, mfail) \
        _x3PrepModelsForToCatiaAtClass(class, TRUE, WkBnchObj, pSetOfTCTItems, mfail)

#define x3PrepPartsForToCatia(WkBnchObj, sCadSystem, pPartObids, pRel_PartObids, pRel_RelObids, mfail) \
        _x3PrepPartsForToCatiaAtClass(NULL, FALSE, WkBnchObj, sCadSystem, pPartObids, pRel_PartObids, pRel_RelObids, mfail)
#define x3PrepPartsForToCatiaAtClass(class, WkBnchObj, sCadSystem, pPartObids, pRel_PartObids, pRel_RelObids, mfail) \
        _x3PrepPartsForToCatiaAtClass(class, FALSE, WkBnchObj, sCadSystem, pPartObids, pRel_PartObids, pRel_RelObids, mfail)
#define x3PrepPartsForToCatiaAtParent(class, WkBnchObj, sCadSystem, pPartObids, pRel_PartObids, pRel_RelObids, mfail) \
        _x3PrepPartsForToCatiaAtClass(class, TRUE, WkBnchObj, sCadSystem, pPartObids, pRel_PartObids, pRel_RelObids, mfail)

#define x3PrepViewing(className, licKey, licRes, mfail) \
        _x3PrepViewing(className, FALSE, className, licKey, licRes, mfail)
#define x3PrepViewingAtParent(_class, className, licKey, licRes, mfail) \
        _x3PrepViewing(_class, TRUE, className, licKey, licRes, mfail)

#define x3ProcessCATIADeletion(className, childOBID, childRelOBID, parentClass, parentOBID, matrixIndex, statsSet, updateOk, mfail) \
        _x3ProcessCATIADeletion(className, FALSE, className, childOBID, childRelOBID, parentClass, parentOBID, matrixIndex, statsSet, updateOk, mfail)
#define x3ProcessCATIADeletionAtParent(_class, className, childOBID, childRelOBID, parentClass, parentOBID, matrixIndex, statsSet, updateOk, mfail) \
        _x3ProcessCATIADeletion(_class, TRUE, className, childOBID, childRelOBID, parentClass, parentOBID, matrixIndex, statsSet, updateOk, mfail)

#define x3ProcessDroppedItem(this, WkBenchObj, commObj, BackgroundItem, mfail) \
        _x3ProcessDroppedItemAtClass(NULL, FALSE, this, WkBenchObj, commObj, BackgroundItem, mfail)
#define x3ProcessDroppedItemAtClass(class, this, WkBenchObj, commObj, BackgroundItem, mfail) \
        _x3ProcessDroppedItemAtClass(class, FALSE, this, WkBenchObj, commObj, BackgroundItem, mfail)
#define x3ProcessDroppedItemAtParent(class, this, WkBenchObj, commObj, BackgroundItem, mfail) \
        _x3ProcessDroppedItemAtClass(class, TRUE, this, WkBenchObj, commObj, BackgroundItem, mfail)

#define x3ProcessOldPlotFiles(originatingObj, oldPlots, plotfeatures, plotFileObj, mfail) \
        _x3ProcessOldPlotFilesAtClass(NULL, FALSE, originatingObj, oldPlots, plotfeatures, plotFileObj, mfail)
#define x3ProcessOldPlotFilesAtClass(class, originatingObj, oldPlots, plotfeatures, plotFileObj, mfail) \
        _x3ProcessOldPlotFilesAtClass(class, FALSE, originatingObj, oldPlots, plotfeatures, plotFileObj, mfail)
#define x3ProcessOldPlotFilesAtParent(class, originatingObj, oldPlots, plotfeatures, plotFileObj, mfail) \
        _x3ProcessOldPlotFilesAtClass(class, TRUE, originatingObj, oldPlots, plotfeatures, plotFileObj, mfail)

#define x3PutAttValueForObject(sClassName, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail) \
        _x3PutAttValueForObject(sClassName, FALSE, sClassName, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail)
#define x3PutAttValueForObjectAtParent(_class, sClassName, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail) \
        _x3PutAttValueForObject(_class, TRUE, sClassName, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail)

#define x3PutAttValueForPosObj(sThisClassName, sInstanceName, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail) \
        _x3PutAttValueForPosObj(sThisClassName, FALSE, sThisClassName, sInstanceName, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail)
#define x3PutAttValueForPosObjAtParent(_class, sThisClassName, sInstanceName, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail) \
        _x3PutAttValueForPosObj(_class, TRUE, sThisClassName, sInstanceName, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail)

#define x3PutAttValueForRelObj(sThisClassName, sInstanceName, sMatrixIndex, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail) \
        _x3PutAttValueForRelObj(sThisClassName, FALSE, sThisClassName, sInstanceName, sMatrixIndex, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail)
#define x3PutAttValueForRelObjAtParent(_class, sThisClassName, sInstanceName, sMatrixIndex, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail) \
        _x3PutAttValueForRelObj(_class, TRUE, sThisClassName, sInstanceName, sMatrixIndex, vObjectObid, vObjectDbName, vObjectClassName, sAttributeName, sAttributeValue, sReturnCode, mfail)

#define x3PutPartAttributeApi(className, parameterSet, outputSet, mfail) \
        _x3PutPartAttributeApi(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3PutPartAttributeApiAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3PutPartAttributeApi(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3PutRelAttributeApi(className, parameterSet, outputSet, mfail) \
        _x3PutRelAttributeApi(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3PutRelAttributeApiAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3PutRelAttributeApi(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3QueryWkBnchCTItem(className, mfail) \
        _x3QueryWkBnchCTItem(className, FALSE, className, mfail)
#define x3QueryWkBnchCTItemAtParent(_class, className, mfail) \
        _x3QueryWkBnchCTItem(_class, TRUE, className, mfail)

#define x3QueryWkBnchModRep(className, mfail) \
        _x3QueryWkBnchModRep(className, FALSE, className, mfail)
#define x3QueryWkBnchModRepAtParent(_class, className, mfail) \
        _x3QueryWkBnchModRep(_class, TRUE, className, mfail)

#define x3Read4DNavFile(className, mfail) \
        _x3Read4DNavFile(className, FALSE, className, mfail)
#define x3Read4DNavFileAtParent(_class, className, mfail) \
        _x3Read4DNavFile(_class, TRUE, className, mfail)

#define x3ReadTmpAss(this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3ReadTmpAssAtClass(NULL, FALSE, this, WkBnchObj, commObj, BackgroundItem, mfail)
#define x3ReadTmpAssAtClass(class, this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3ReadTmpAssAtClass(class, FALSE, this, WkBnchObj, commObj, BackgroundItem, mfail)
#define x3ReadTmpAssAtParent(class, this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3ReadTmpAssAtClass(class, TRUE, this, WkBnchObj, commObj, BackgroundItem, mfail)

#define x3ReadViewerFile(className, mfail) \
        _x3ReadViewerFile(className, FALSE, className, mfail)
#define x3ReadViewerFileAtParent(_class, className, mfail) \
        _x3ReadViewerFile(_class, TRUE, className, mfail)

#define x3ReceiveUserDefProps(thisObj, vPropDisplaySet, vPropNameSet, vPropValueSet, mfail) \
        _x3ReceiveUserDefPropsAtClass(NULL, FALSE, thisObj, vPropDisplaySet, vPropNameSet, vPropValueSet, mfail)
#define x3ReceiveUserDefPropsAtClass(class, thisObj, vPropDisplaySet, vPropNameSet, vPropValueSet, mfail) \
        _x3ReceiveUserDefPropsAtClass(class, FALSE, thisObj, vPropDisplaySet, vPropNameSet, vPropValueSet, mfail)
#define x3ReceiveUserDefPropsAtParent(class, thisObj, vPropDisplaySet, vPropNameSet, vPropValueSet, mfail) \
        _x3ReceiveUserDefPropsAtClass(class, TRUE, thisObj, vPropDisplaySet, vPropNameSet, vPropValueSet, mfail)

#define x3RefreshItm(thisObj, mfail) \
        _x3RefreshItmAtClass(NULL, FALSE, thisObj, mfail)
#define x3RefreshItmAtClass(class, thisObj, mfail) \
        _x3RefreshItmAtClass(class, FALSE, thisObj, mfail)
#define x3RefreshItmAtParent(class, thisObj, mfail) \
        _x3RefreshItmAtClass(class, TRUE, thisObj, mfail)

#define x3RefreshObject(ClassName, RefreshObject, RefreshRelation, mfail) \
        _x3RefreshObject(ClassName, FALSE, ClassName, RefreshObject, RefreshRelation, mfail)
#define x3RefreshObjectAtParent(_class, ClassName, RefreshObject, RefreshRelation, mfail) \
        _x3RefreshObject(_class, TRUE, ClassName, RefreshObject, RefreshRelation, mfail)

#define x3RelatePlotToModel(modObj, plotObj, mfail) \
        _x3RelatePlotToModelAtClass(NULL, FALSE, modObj, plotObj, mfail)
#define x3RelatePlotToModelAtClass(class, modObj, plotObj, mfail) \
        _x3RelatePlotToModelAtClass(class, FALSE, modObj, plotObj, mfail)
#define x3RelatePlotToModelAtParent(class, modObj, plotObj, mfail) \
        _x3RelatePlotToModelAtClass(class, TRUE, modObj, plotObj, mfail)

#define x3RemoveBlackBoxFiles(thisPtr, FileNames, BlackBoxObjs, BlackBoxRels, pRemovedFiles, mfail) \
        _x3RemoveBlackBoxFilesAtClass(NULL, FALSE, thisPtr, FileNames, BlackBoxObjs, BlackBoxRels, pRemovedFiles, mfail)
#define x3RemoveBlackBoxFilesAtClass(class, thisPtr, FileNames, BlackBoxObjs, BlackBoxRels, pRemovedFiles, mfail) \
        _x3RemoveBlackBoxFilesAtClass(class, FALSE, thisPtr, FileNames, BlackBoxObjs, BlackBoxRels, pRemovedFiles, mfail)
#define x3RemoveBlackBoxFilesAtParent(class, thisPtr, FileNames, BlackBoxObjs, BlackBoxRels, pRemovedFiles, mfail) \
        _x3RemoveBlackBoxFilesAtClass(class, TRUE, thisPtr, FileNames, BlackBoxObjs, BlackBoxRels, pRemovedFiles, mfail)

#define x3RemoveDesTab(modelObj, ModelInfos, desTabObj, sPartClassName, sPartOBID, sPartDbName, vStats, mfail) \
        _x3RemoveDesTabAtClass(NULL, FALSE, modelObj, ModelInfos, desTabObj, sPartClassName, sPartOBID, sPartDbName, vStats, mfail)
#define x3RemoveDesTabAtClass(class, modelObj, ModelInfos, desTabObj, sPartClassName, sPartOBID, sPartDbName, vStats, mfail) \
        _x3RemoveDesTabAtClass(class, FALSE, modelObj, ModelInfos, desTabObj, sPartClassName, sPartOBID, sPartDbName, vStats, mfail)
#define x3RemoveDesTabAtParent(class, modelObj, ModelInfos, desTabObj, sPartClassName, sPartOBID, sPartDbName, vStats, mfail) \
        _x3RemoveDesTabAtClass(class, TRUE, modelObj, ModelInfos, desTabObj, sPartClassName, sPartOBID, sPartDbName, vStats, mfail)

#define x3RemoveDesTabExt(modelObj, ModelInfos, desTabObj, path, sPartClassName, sPartOBID, sPartDbName, vStats, mfail) \
        _x3RemoveDesTabExtAtClass(NULL, FALSE, modelObj, ModelInfos, desTabObj, path, sPartClassName, sPartOBID, sPartDbName, vStats, mfail)
#define x3RemoveDesTabExtAtClass(class, modelObj, ModelInfos, desTabObj, path, sPartClassName, sPartOBID, sPartDbName, vStats, mfail) \
        _x3RemoveDesTabExtAtClass(class, FALSE, modelObj, ModelInfos, desTabObj, path, sPartClassName, sPartOBID, sPartDbName, vStats, mfail)
#define x3RemoveDesTabExtAtParent(class, modelObj, ModelInfos, desTabObj, path, sPartClassName, sPartOBID, sPartDbName, vStats, mfail) \
        _x3RemoveDesTabExtAtClass(class, TRUE, modelObj, ModelInfos, desTabObj, path, sPartClassName, sPartOBID, sPartDbName, vStats, mfail)

#define x3RepSubAss(this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3RepSubAssAtClass(NULL, FALSE, this, WkBnchObj, commObj, BackgroundItem, mfail)
#define x3RepSubAssAtClass(class, this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3RepSubAssAtClass(class, FALSE, this, WkBnchObj, commObj, BackgroundItem, mfail)
#define x3RepSubAssAtParent(class, this, WkBnchObj, commObj, BackgroundItem, mfail) \
        _x3RepSubAssAtClass(class, TRUE, this, WkBnchObj, commObj, BackgroundItem, mfail)

#define x3ReplaceEmbeddedPrd(PartObj, CTItemObj, bReplaceEmbedded, mfail) \
        _x3ReplaceEmbeddedPrdAtClass(NULL, FALSE, PartObj, CTItemObj, bReplaceEmbedded, mfail)
#define x3ReplaceEmbeddedPrdAtClass(class, PartObj, CTItemObj, bReplaceEmbedded, mfail) \
        _x3ReplaceEmbeddedPrdAtClass(class, FALSE, PartObj, CTItemObj, bReplaceEmbedded, mfail)
#define x3ReplaceEmbeddedPrdAtParent(class, PartObj, CTItemObj, bReplaceEmbedded, mfail) \
        _x3ReplaceEmbeddedPrdAtClass(class, TRUE, PartObj, CTItemObj, bReplaceEmbedded, mfail)

#define x3ReplaceInstNmeFrMod(classname, productObj, partObj, oldModelObj, newModelObj, oldInstanceName, newInstanceName, mfail) \
        _x3ReplaceInstNmeFrMod(classname, FALSE, classname, productObj, partObj, oldModelObj, newModelObj, oldInstanceName, newInstanceName, mfail)
#define x3ReplaceInstNmeFrModAtParent(_class, classname, productObj, partObj, oldModelObj, newModelObj, oldInstanceName, newInstanceName, mfail) \
        _x3ReplaceInstNmeFrMod(_class, TRUE, classname, productObj, partObj, oldModelObj, newModelObj, oldInstanceName, newInstanceName, mfail)

#define x3RestoreWBContents(this, WkBnchObj, initObj, BackgroundItem, mfail) \
        _x3RestoreWBContentsAtClass(NULL, FALSE, this, WkBnchObj, initObj, BackgroundItem, mfail)
#define x3RestoreWBContentsAtClass(class, this, WkBnchObj, initObj, BackgroundItem, mfail) \
        _x3RestoreWBContentsAtClass(class, FALSE, this, WkBnchObj, initObj, BackgroundItem, mfail)
#define x3RestoreWBContentsAtParent(class, this, WkBnchObj, initObj, BackgroundItem, mfail) \
        _x3RestoreWBContentsAtClass(class, TRUE, this, WkBnchObj, initObj, BackgroundItem, mfail)

#define x3RestoreWBPost(className, PrevObj, mfail) \
        _x3RestoreWBPost(className, FALSE, className, PrevObj, mfail)
#define x3RestoreWBPostAtParent(_class, className, PrevObj, mfail) \
        _x3RestoreWBPost(_class, TRUE, className, PrevObj, mfail)

#define x3RestoreWBPre(className, PrevObj, mfail) \
        _x3RestoreWBPre(className, FALSE, className, PrevObj, mfail)
#define x3RestoreWBPreAtParent(_class, className, PrevObj, mfail) \
        _x3RestoreWBPre(_class, TRUE, className, PrevObj, mfail)

#define x3RestoreWBSubtree(ClassName, catiaItem, itemOBID, vObjMgrSet, ctxObj, WkBnchObj, BackgroundItem, slastseq, p_bErrors, MissedModels, mfail) \
        _x3RestoreWBSubtree(ClassName, FALSE, ClassName, catiaItem, itemOBID, vObjMgrSet, ctxObj, WkBnchObj, BackgroundItem, slastseq, p_bErrors, MissedModels, mfail)
#define x3RestoreWBSubtreeAtParent(_class, ClassName, catiaItem, itemOBID, vObjMgrSet, ctxObj, WkBnchObj, BackgroundItem, slastseq, p_bErrors, MissedModels, mfail) \
        _x3RestoreWBSubtree(_class, TRUE, ClassName, catiaItem, itemOBID, vObjMgrSet, ctxObj, WkBnchObj, BackgroundItem, slastseq, p_bErrors, MissedModels, mfail)

#define x3SaveAsCATDrawFrFile(className, parameterSet, outputSet, mfail) \
        _x3SaveAsCATDrawFrFile(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3SaveAsCATDrawFrFileAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3SaveAsCATDrawFrFile(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3SaveAsCATPartFrFile(className, parameterSet, outputSet, mfail) \
        _x3SaveAsCATPartFrFile(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3SaveAsCATPartFrFileAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3SaveAsCATPartFrFile(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3SaveAsCATPartV4FrFl(className, parameterSet, outputSet, mfail) \
        _x3SaveAsCATPartV4FrFl(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3SaveAsCATPartV4FrFlAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3SaveAsCATPartV4FrFl(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3SaveAsFromFile(className, parameterSet, outputSet, mfail) \
        _x3SaveAsFromFile(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3SaveAsFromFileAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3SaveAsFromFile(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3SaveAssm(className, vStrSet, updateOk, vStrSet_Send, mfail) \
        _x3SaveAssm(className, FALSE, className, vStrSet, updateOk, vStrSet_Send, mfail)
#define x3SaveAssmAtParent(_class, className, vStrSet, updateOk, vStrSet_Send, mfail) \
        _x3SaveAssm(_class, TRUE, className, vStrSet, updateOk, vStrSet_Send, mfail)

#define x3SaveAssmMg(className, vStrSet, updateOk, vStrSet_Send, mfail) \
        _x3SaveAssmMg(className, FALSE, className, vStrSet, updateOk, vStrSet_Send, mfail)
#define x3SaveAssmMgAtParent(_class, className, vStrSet, updateOk, vStrSet_Send, mfail) \
        _x3SaveAssmMg(_class, TRUE, className, vStrSet, updateOk, vStrSet_Send, mfail)

#define x3SaveCatArcPost(this, doccomps, ext_locations, mfail) \
        _x3SaveCatArcPostAtClass(NULL, FALSE, this, doccomps, ext_locations, mfail)
#define x3SaveCatArcPostAtClass(class, this, doccomps, ext_locations, mfail) \
        _x3SaveCatArcPostAtClass(class, FALSE, this, doccomps, ext_locations, mfail)
#define x3SaveCatArcPostAtParent(class, this, doccomps, ext_locations, mfail) \
        _x3SaveCatArcPostAtClass(class, TRUE, this, doccomps, ext_locations, mfail)

#define x3SaveCatCgrPost(this, doccomps, ext_locations, mfail) \
        _x3SaveCatCgrPostAtClass(NULL, FALSE, this, doccomps, ext_locations, mfail)
#define x3SaveCatCgrPostAtClass(class, this, doccomps, ext_locations, mfail) \
        _x3SaveCatCgrPostAtClass(class, FALSE, this, doccomps, ext_locations, mfail)
#define x3SaveCatCgrPostAtParent(class, this, doccomps, ext_locations, mfail) \
        _x3SaveCatCgrPostAtClass(class, TRUE, this, doccomps, ext_locations, mfail)

#define x3SaveCatDrwPost(this, doccomps, ext_locations, mfail) \
        _x3SaveCatDrwPostAtClass(NULL, FALSE, this, doccomps, ext_locations, mfail)
#define x3SaveCatDrwPostAtClass(class, this, doccomps, ext_locations, mfail) \
        _x3SaveCatDrwPostAtClass(class, FALSE, this, doccomps, ext_locations, mfail)
#define x3SaveCatDrwPostAtParent(class, this, doccomps, ext_locations, mfail) \
        _x3SaveCatDrwPostAtClass(class, TRUE, this, doccomps, ext_locations, mfail)

#define x3SaveCatPrtPost(this, doccomps, ext_locations, mfail) \
        _x3SaveCatPrtPostAtClass(NULL, FALSE, this, doccomps, ext_locations, mfail)
#define x3SaveCatPrtPostAtClass(class, this, doccomps, ext_locations, mfail) \
        _x3SaveCatPrtPostAtClass(class, FALSE, this, doccomps, ext_locations, mfail)
#define x3SaveCatPrtPostAtParent(class, this, doccomps, ext_locations, mfail) \
        _x3SaveCatPrtPostAtClass(class, TRUE, this, doccomps, ext_locations, mfail)

#define x3SaveCatRepPost(this, doccomps, ext_locations, mfail) \
        _x3SaveCatRepPostAtClass(NULL, FALSE, this, doccomps, ext_locations, mfail)
#define x3SaveCatRepPostAtClass(class, this, doccomps, ext_locations, mfail) \
        _x3SaveCatRepPostAtClass(class, FALSE, this, doccomps, ext_locations, mfail)
#define x3SaveCatRepPostAtParent(class, this, doccomps, ext_locations, mfail) \
        _x3SaveCatRepPostAtClass(class, TRUE, this, doccomps, ext_locations, mfail)

#define x3SaveComponent(thisPtr, sObjComponent, sObjCatModInf, vStats, updateOk, mfail) \
        _x3SaveComponentAtClass(NULL, FALSE, thisPtr, sObjComponent, sObjCatModInf, vStats, updateOk, mfail)
#define x3SaveComponentAtClass(class, thisPtr, sObjComponent, sObjCatModInf, vStats, updateOk, mfail) \
        _x3SaveComponentAtClass(class, FALSE, thisPtr, sObjComponent, sObjCatModInf, vStats, updateOk, mfail)
#define x3SaveComponentAtParent(class, thisPtr, sObjComponent, sObjCatModInf, vStats, updateOk, mfail) \
        _x3SaveComponentAtClass(class, TRUE, thisPtr, sObjComponent, sObjCatModInf, vStats, updateOk, mfail)

#define x3SaveComponentInMP(thisPtr, catia_exchange_file, mfail) \
        _x3SaveComponentInMPAtClass(NULL, FALSE, thisPtr, catia_exchange_file, mfail)
#define x3SaveComponentInMPAtClass(class, thisPtr, catia_exchange_file, mfail) \
        _x3SaveComponentInMPAtClass(class, FALSE, thisPtr, catia_exchange_file, mfail)
#define x3SaveComponentInMPAtParent(class, thisPtr, catia_exchange_file, mfail) \
        _x3SaveComponentInMPAtClass(class, TRUE, thisPtr, catia_exchange_file, mfail)

#define x3SaveComponentPost(thisPtr, mfail) \
        _x3SaveComponentPostAtClass(NULL, FALSE, thisPtr, mfail)
#define x3SaveComponentPostAtClass(class, thisPtr, mfail) \
        _x3SaveComponentPostAtClass(class, FALSE, thisPtr, mfail)
#define x3SaveComponentPostAtParent(class, thisPtr, mfail) \
        _x3SaveComponentPostAtClass(class, TRUE, thisPtr, mfail)

#define x3SaveContainer(thisPtr, sObjCnt, cntModelInfos, mfail) \
        _x3SaveContainerAtClass(NULL, FALSE, thisPtr, sObjCnt, cntModelInfos, mfail)
#define x3SaveContainerAtClass(class, thisPtr, sObjCnt, cntModelInfos, mfail) \
        _x3SaveContainerAtClass(class, FALSE, thisPtr, sObjCnt, cntModelInfos, mfail)
#define x3SaveContainerAtParent(class, thisPtr, sObjCnt, cntModelInfos, mfail) \
        _x3SaveContainerAtClass(class, TRUE, thisPtr, sObjCnt, cntModelInfos, mfail)

#define x3SaveContainerInMP(thisPtr, catia_exchange_file, mfail) \
        _x3SaveContainerInMPAtClass(NULL, FALSE, thisPtr, catia_exchange_file, mfail)
#define x3SaveContainerInMPAtClass(class, thisPtr, catia_exchange_file, mfail) \
        _x3SaveContainerInMPAtClass(class, FALSE, thisPtr, catia_exchange_file, mfail)
#define x3SaveContainerInMPAtParent(class, thisPtr, catia_exchange_file, mfail) \
        _x3SaveContainerInMPAtClass(class, TRUE, thisPtr, catia_exchange_file, mfail)

#define x3SaveContainerPost(thisPtr, mfail) \
        _x3SaveContainerPostAtClass(NULL, FALSE, thisPtr, mfail)
#define x3SaveContainerPostAtClass(class, thisPtr, mfail) \
        _x3SaveContainerPostAtClass(class, FALSE, thisPtr, mfail)
#define x3SaveContainerPostAtParent(class, thisPtr, mfail) \
        _x3SaveContainerPostAtClass(class, TRUE, thisPtr, mfail)

#define x3SaveModel(this, Model_comps, Ext_locations, projects, ModelInfos, vStats, updateOk, mfail) \
        _x3SaveModelAtClass(NULL, FALSE, this, Model_comps, Ext_locations, projects, ModelInfos, vStats, updateOk, mfail)
#define x3SaveModelAtClass(class, this, Model_comps, Ext_locations, projects, ModelInfos, vStats, updateOk, mfail) \
        _x3SaveModelAtClass(class, FALSE, this, Model_comps, Ext_locations, projects, ModelInfos, vStats, updateOk, mfail)
#define x3SaveModelAtParent(class, this, Model_comps, Ext_locations, projects, ModelInfos, vStats, updateOk, mfail) \
        _x3SaveModelAtClass(class, TRUE, this, Model_comps, Ext_locations, projects, ModelInfos, vStats, updateOk, mfail)

#define x3SaveModelECMIPost(thisPtr, messageText, messageAdded, mfail) \
        _x3SaveModelECMIPostAtClass(NULL, FALSE, thisPtr, messageText, messageAdded, mfail)
#define x3SaveModelECMIPostAtClass(class, thisPtr, messageText, messageAdded, mfail) \
        _x3SaveModelECMIPostAtClass(class, FALSE, thisPtr, messageText, messageAdded, mfail)
#define x3SaveModelECMIPostAtParent(class, thisPtr, messageText, messageAdded, mfail) \
        _x3SaveModelECMIPostAtClass(class, TRUE, thisPtr, messageText, messageAdded, mfail)

#define x3SaveModelInMP(this, doccomps, ext_locations, mfail) \
        _x3SaveModelInMPAtClass(NULL, FALSE, this, doccomps, ext_locations, mfail)
#define x3SaveModelInMPAtClass(class, this, doccomps, ext_locations, mfail) \
        _x3SaveModelInMPAtClass(class, FALSE, this, doccomps, ext_locations, mfail)
#define x3SaveModelInMPAtParent(class, this, doccomps, ext_locations, mfail) \
        _x3SaveModelInMPAtClass(class, TRUE, this, doccomps, ext_locations, mfail)

#define x3SaveModelMg(className, vStrSet, mfail) \
        _x3SaveModelMg(className, FALSE, className, vStrSet, mfail)
#define x3SaveModelMgAtParent(_class, className, vStrSet, mfail) \
        _x3SaveModelMg(_class, TRUE, className, vStrSet, mfail)

#define x3SaveModelPost(this, doccomps, ext_locations, mfail) \
        _x3SaveModelPostAtClass(NULL, FALSE, this, doccomps, ext_locations, mfail)
#define x3SaveModelPostAtClass(class, this, doccomps, ext_locations, mfail) \
        _x3SaveModelPostAtClass(class, FALSE, this, doccomps, ext_locations, mfail)
#define x3SaveModelPostAtParent(class, this, doccomps, ext_locations, mfail) \
        _x3SaveModelPostAtClass(class, TRUE, this, doccomps, ext_locations, mfail)

#define x3SaveProductECMI(thisPtr, messageText, messageAdded, mfail) \
        _x3SaveProductECMIAtClass(NULL, FALSE, thisPtr, messageText, messageAdded, mfail)
#define x3SaveProductECMIAtClass(class, thisPtr, messageText, messageAdded, mfail) \
        _x3SaveProductECMIAtClass(class, FALSE, thisPtr, messageText, messageAdded, mfail)
#define x3SaveProductECMIAtParent(class, thisPtr, messageText, messageAdded, mfail) \
        _x3SaveProductECMIAtClass(class, TRUE, thisPtr, messageText, messageAdded, mfail)

#define x3SaveProductECMIPost(thisPtr, messageText, messageAdded, mfail) \
        _x3SaveProductECMIPostAtClass(NULL, FALSE, thisPtr, messageText, messageAdded, mfail)
#define x3SaveProductECMIPostAtClass(class, thisPtr, messageText, messageAdded, mfail) \
        _x3SaveProductECMIPostAtClass(class, FALSE, thisPtr, messageText, messageAdded, mfail)
#define x3SaveProductECMIPostAtParent(class, thisPtr, messageText, messageAdded, mfail) \
        _x3SaveProductECMIPostAtClass(class, TRUE, thisPtr, messageText, messageAdded, mfail)

#define x3SendCustomAttrPref(className, bSendCusAttrs, mfail) \
        _x3SendCustomAttrPref(className, FALSE, className, bSendCusAttrs, mfail)
#define x3SendCustomAttrPrefAtParent(_class, className, bSendCusAttrs, mfail) \
        _x3SendCustomAttrPref(_class, TRUE, className, bSendCusAttrs, mfail)

#define x3SendRequestXT0(className, hostName, requestType, mfail) \
        _x3SendRequestXT0(className, FALSE, className, hostName, requestType, mfail)
#define x3SendRequestXT0AtParent(_class, className, hostName, requestType, mfail) \
        _x3SendRequestXT0(_class, TRUE, className, hostName, requestType, mfail)

#define x3SendUserDefProps(thisObj, vPropDisplaySet, vPropNameSet, vPropValueSet, mfail) \
        _x3SendUserDefPropsAtClass(NULL, FALSE, thisObj, vPropDisplaySet, vPropNameSet, vPropValueSet, mfail)
#define x3SendUserDefPropsAtClass(class, thisObj, vPropDisplaySet, vPropNameSet, vPropValueSet, mfail) \
        _x3SendUserDefPropsAtClass(class, FALSE, thisObj, vPropDisplaySet, vPropNameSet, vPropValueSet, mfail)
#define x3SendUserDefPropsAtParent(class, thisObj, vPropDisplaySet, vPropNameSet, vPropValueSet, mfail) \
        _x3SendUserDefPropsAtClass(class, TRUE, thisObj, vPropDisplaySet, vPropNameSet, vPropValueSet, mfail)

#define x3SendUserDefPropsExt(thisObj, vPropDisplaySet, vPropNameSet, vPropValueSet, vPropDelSet, mfail) \
        _x3SendUserDefPropsExtAtClass(NULL, FALSE, thisObj, vPropDisplaySet, vPropNameSet, vPropValueSet, vPropDelSet, mfail)
#define x3SendUserDefPropsExtAtClass(class, thisObj, vPropDisplaySet, vPropNameSet, vPropValueSet, vPropDelSet, mfail) \
        _x3SendUserDefPropsExtAtClass(class, FALSE, thisObj, vPropDisplaySet, vPropNameSet, vPropValueSet, vPropDelSet, mfail)
#define x3SendUserDefPropsExtAtParent(class, thisObj, vPropDisplaySet, vPropNameSet, vPropValueSet, vPropDelSet, mfail) \
        _x3SendUserDefPropsExtAtClass(class, TRUE, thisObj, vPropDisplaySet, vPropNameSet, vPropValueSet, vPropDelSet, mfail)

#define x3SetCATIADefinition(this, sDefinition, mfail) \
        _x3SetCATIADefinitionAtClass(NULL, FALSE, this, sDefinition, mfail)
#define x3SetCATIADefinitionAtClass(class, this, sDefinition, mfail) \
        _x3SetCATIADefinitionAtClass(class, FALSE, this, sDefinition, mfail)
#define x3SetCATIADefinitionAtParent(class, this, sDefinition, mfail) \
        _x3SetCATIADefinitionAtClass(class, TRUE, this, sDefinition, mfail)

#define x3SetCATIADescription(this, sDescription, mfail) \
        _x3SetCATIADescriptionAtClass(NULL, FALSE, this, sDescription, mfail)
#define x3SetCATIADescriptionAtClass(class, this, sDescription, mfail) \
        _x3SetCATIADescriptionAtClass(class, FALSE, this, sDescription, mfail)
#define x3SetCATIADescriptionAtParent(class, this, sDescription, mfail) \
        _x3SetCATIADescriptionAtClass(class, TRUE, this, sDescription, mfail)

#define x3SetCATIANomenclature(this, sNomenclature, mfail) \
        _x3SetCATIANomenclatureAtClass(NULL, FALSE, this, sNomenclature, mfail)
#define x3SetCATIANomenclatureAtClass(class, this, sNomenclature, mfail) \
        _x3SetCATIANomenclatureAtClass(class, FALSE, this, sNomenclature, mfail)
#define x3SetCATIANomenclatureAtParent(class, this, sNomenclature, mfail) \
        _x3SetCATIANomenclatureAtClass(class, TRUE, this, sNomenclature, mfail)

#define x3SetCATIARevision(this, Revision, mfail) \
        _x3SetCATIARevisionAtClass(NULL, FALSE, this, Revision, mfail)
#define x3SetCATIARevisionAtClass(class, this, Revision, mfail) \
        _x3SetCATIARevisionAtClass(class, FALSE, this, Revision, mfail)
#define x3SetCATIARevisionAtParent(class, this, Revision, mfail) \
        _x3SetCATIARevisionAtClass(class, TRUE, this, Revision, mfail)

#define x3SetCatiaFileExt(thisObj, sFileName, mfail) \
        _x3SetCatiaFileExtAtClass(NULL, FALSE, thisObj, sFileName, mfail)
#define x3SetCatiaFileExtAtClass(class, thisObj, sFileName, mfail) \
        _x3SetCatiaFileExtAtClass(class, FALSE, thisObj, sFileName, mfail)
#define x3SetCatiaFileExtAtParent(class, thisObj, sFileName, mfail) \
        _x3SetCatiaFileExtAtClass(class, TRUE, thisObj, sFileName, mfail)

#define x3SetCatiaFileToDlg(dialogObj, sCatiaFileName, mfail) \
        _x3SetCatiaFileToDlgAtClass(NULL, FALSE, dialogObj, sCatiaFileName, mfail)
#define x3SetCatiaFileToDlgAtClass(class, dialogObj, sCatiaFileName, mfail) \
        _x3SetCatiaFileToDlgAtClass(class, FALSE, dialogObj, sCatiaFileName, mfail)
#define x3SetCatiaFileToDlgAtParent(class, dialogObj, sCatiaFileName, mfail) \
        _x3SetCatiaFileToDlgAtClass(class, TRUE, dialogObj, sCatiaFileName, mfail)

#define x3SetCatiaModelSize(this, mfail) \
        _x3SetCatiaModelSizeAtClass(NULL, FALSE, this, mfail)
#define x3SetCatiaModelSizeAtClass(class, this, mfail) \
        _x3SetCatiaModelSizeAtClass(class, FALSE, this, mfail)
#define x3SetCatiaModelSizeAtParent(class, this, mfail) \
        _x3SetCatiaModelSizeAtClass(class, TRUE, this, mfail)

#define x3SetCatiaProject(this, catia_project, mfail) \
        _x3SetCatiaProjectAtClass(NULL, FALSE, this, catia_project, mfail)
#define x3SetCatiaProjectAtClass(class, this, catia_project, mfail) \
        _x3SetCatiaProjectAtClass(class, FALSE, this, catia_project, mfail)
#define x3SetCatiaProjectAtParent(class, this, catia_project, mfail) \
        _x3SetCatiaProjectAtClass(class, TRUE, this, catia_project, mfail)

#define x3SetCmiAttrModInf(this, ModelInfos, mfail) \
        _x3SetCmiAttrModInfAtClass(NULL, FALSE, this, ModelInfos, mfail)
#define x3SetCmiAttrModInfAtClass(class, this, ModelInfos, mfail) \
        _x3SetCmiAttrModInfAtClass(class, FALSE, this, ModelInfos, mfail)
#define x3SetCmiAttrModInfAtParent(class, this, ModelInfos, mfail) \
        _x3SetCmiAttrModInfAtClass(class, TRUE, this, ModelInfos, mfail)

#define x3SetCmpDocDlgAttr(sClassName, sDocName, dialogObject, mfail) \
        _x3SetCmpDocDlgAttr(sClassName, FALSE, sClassName, sDocName, dialogObject, mfail)
#define x3SetCmpDocDlgAttrAtParent(_class, sClassName, sDocName, dialogObject, mfail) \
        _x3SetCmpDocDlgAttr(_class, TRUE, sClassName, sDocName, dialogObject, mfail)

#define x3SetComponentFlag(PartObj, bIsComponent, mfail) \
        _x3SetComponentFlagAtClass(NULL, FALSE, PartObj, bIsComponent, mfail)
#define x3SetComponentFlagAtClass(class, PartObj, bIsComponent, mfail) \
        _x3SetComponentFlagAtClass(class, FALSE, PartObj, bIsComponent, mfail)
#define x3SetComponentFlagAtParent(class, PartObj, bIsComponent, mfail) \
        _x3SetComponentFlagAtClass(class, TRUE, PartObj, bIsComponent, mfail)

#define x3SetComponentFlags(ClassName, attributeSet, mfail) \
        _x3SetComponentFlags(ClassName, FALSE, ClassName, attributeSet, mfail)
#define x3SetComponentFlagsAtParent(_class, ClassName, attributeSet, mfail) \
        _x3SetComponentFlags(_class, TRUE, ClassName, attributeSet, mfail)

#define x3SetCusAttrModInf(this, ModelInfos, mfail) \
        _x3SetCusAttrModInfAtClass(NULL, FALSE, this, ModelInfos, mfail)
#define x3SetCusAttrModInfAtClass(class, this, ModelInfos, mfail) \
        _x3SetCusAttrModInfAtClass(class, FALSE, this, ModelInfos, mfail)
#define x3SetCusAttrModInfAtParent(class, this, ModelInfos, mfail) \
        _x3SetCusAttrModInfAtClass(class, TRUE, this, ModelInfos, mfail)

#define x3SetDialogAttrs(className, pAttributeSet, dialogObject, mfail) \
        _x3SetDialogAttrs(className, FALSE, className, pAttributeSet, dialogObject, mfail)
#define x3SetDialogAttrsAtParent(_class, className, pAttributeSet, dialogObject, mfail) \
        _x3SetDialogAttrs(_class, TRUE, className, pAttributeSet, dialogObject, mfail)

#define x3SetFeatureExtFromCAD(classname, this, objectid, SetOfContainerIdsMod, SetOfClientIdsMod, SetOfFeatureTypesMod, SetOfFeatureAttrsMod, SetOfFeatureValuesMod, mfail) \
        _x3SetFeatureExtFromCAD(classname, FALSE, classname, this, objectid, SetOfContainerIdsMod, SetOfClientIdsMod, SetOfFeatureTypesMod, SetOfFeatureAttrsMod, SetOfFeatureValuesMod, mfail)
#define x3SetFeatureExtFromCADAtParent(_class, classname, this, objectid, SetOfContainerIdsMod, SetOfClientIdsMod, SetOfFeatureTypesMod, SetOfFeatureAttrsMod, SetOfFeatureValuesMod, mfail) \
        _x3SetFeatureExtFromCAD(_class, TRUE, classname, this, objectid, SetOfContainerIdsMod, SetOfClientIdsMod, SetOfFeatureTypesMod, SetOfFeatureAttrsMod, SetOfFeatureValuesMod, mfail)

#define x3SetInstNameForIndex(thisObj, index, sInstanceName, mfail) \
        _x3SetInstNameForIndexAtClass(NULL, FALSE, thisObj, index, sInstanceName, mfail)
#define x3SetInstNameForIndexAtClass(class, thisObj, index, sInstanceName, mfail) \
        _x3SetInstNameForIndexAtClass(class, FALSE, thisObj, index, sInstanceName, mfail)
#define x3SetInstNameForIndexAtParent(class, thisObj, index, sInstanceName, mfail) \
        _x3SetInstNameForIndexAtClass(class, TRUE, thisObj, index, sInstanceName, mfail)

#define x3SetLastCatiaUpdate(this, mfail) \
        _x3SetLastCatiaUpdateAtClass(NULL, FALSE, this, mfail)
#define x3SetLastCatiaUpdateAtClass(class, this, mfail) \
        _x3SetLastCatiaUpdateAtClass(class, FALSE, this, mfail)
#define x3SetLastCatiaUpdateAtParent(class, this, mfail) \
        _x3SetLastCatiaUpdateAtClass(class, TRUE, this, mfail)

#define x3SetModelInfoData(thisPtr, sModelInfo, vStats, updateOk, mfail) \
        _x3SetModelInfoDataAtClass(NULL, FALSE, thisPtr, sModelInfo, vStats, updateOk, mfail)
#define x3SetModelInfoDataAtClass(class, thisPtr, sModelInfo, vStats, updateOk, mfail) \
        _x3SetModelInfoDataAtClass(class, FALSE, thisPtr, sModelInfo, vStats, updateOk, mfail)
#define x3SetModelInfoDataAtParent(class, thisPtr, sModelInfo, vStats, updateOk, mfail) \
        _x3SetModelInfoDataAtClass(class, TRUE, thisPtr, sModelInfo, vStats, updateOk, mfail)

#define x3SetModelInfoData2(thisObj, ModelInfo, mfail) \
        _x3SetModelInfoData2AtClass(NULL, FALSE, thisObj, ModelInfo, mfail)
#define x3SetModelInfoData2AtClass(class, thisObj, ModelInfo, mfail) \
        _x3SetModelInfoData2AtClass(class, FALSE, thisObj, ModelInfo, mfail)
#define x3SetModelInfoData2AtParent(class, thisObj, ModelInfo, mfail) \
        _x3SetModelInfoData2AtClass(class, TRUE, thisObj, ModelInfo, mfail)

#define x3SetPrdDocDlgAttr(sClassName, sDocName, dialogObject, mfail) \
        _x3SetPrdDocDlgAttr(sClassName, FALSE, sClassName, sDocName, dialogObject, mfail)
#define x3SetPrdDocDlgAttrAtParent(_class, sClassName, sDocName, dialogObject, mfail) \
        _x3SetPrdDocDlgAttr(_class, TRUE, sClassName, sDocName, dialogObject, mfail)

#define x3SetRestoreFlag(thisObj, mfail) \
        _x3SetRestoreFlagAtClass(NULL, FALSE, thisObj, mfail)
#define x3SetRestoreFlagAtClass(class, thisObj, mfail) \
        _x3SetRestoreFlagAtClass(class, FALSE, thisObj, mfail)
#define x3SetRestoreFlagAtParent(class, thisObj, mfail) \
        _x3SetRestoreFlagAtClass(class, TRUE, thisObj, mfail)

#define x3SetShowNeighbours(className, SelectedItems, mfail) \
        _x3SetShowNeighbours(className, FALSE, className, SelectedItems, mfail)
#define x3SetShowNeighboursAtParent(_class, className, SelectedItems, mfail) \
        _x3SetShowNeighbours(_class, TRUE, className, SelectedItems, mfail)

#define x3SetStdAttrModInf(this, ModelInfos, mfail) \
        _x3SetStdAttrModInfAtClass(NULL, FALSE, this, ModelInfos, mfail)
#define x3SetStdAttrModInfAtClass(class, this, ModelInfos, mfail) \
        _x3SetStdAttrModInfAtClass(class, FALSE, this, ModelInfos, mfail)
#define x3SetStdAttrModInfAtParent(class, this, ModelInfos, mfail) \
        _x3SetStdAttrModInfAtClass(class, TRUE, this, ModelInfos, mfail)

#define x3SetTrafo(this, matrix, mfail) \
        _x3SetTrafoAtClass(NULL, FALSE, this, matrix, mfail)
#define x3SetTrafoAtClass(class, this, matrix, mfail) \
        _x3SetTrafoAtClass(class, FALSE, this, matrix, mfail)
#define x3SetTrafoAtParent(class, this, matrix, mfail) \
        _x3SetTrafoAtClass(class, TRUE, this, matrix, mfail)

#define x3SetWorkplane(thisObj, mfail) \
        _x3SetWorkplaneAtClass(NULL, FALSE, thisObj, mfail)
#define x3SetWorkplaneAtClass(class, thisObj, mfail) \
        _x3SetWorkplaneAtClass(class, FALSE, thisObj, mfail)
#define x3SetWorkplaneAtParent(class, thisObj, mfail) \
        _x3SetWorkplaneAtClass(class, TRUE, thisObj, mfail)

#define x3ShowContainedModls(thisObj, mfail) \
        _x3ShowContainedModlsAtClass(NULL, FALSE, thisObj, mfail)
#define x3ShowContainedModlsAtClass(class, thisObj, mfail) \
        _x3ShowContainedModlsAtClass(class, FALSE, thisObj, mfail)
#define x3ShowContainedModlsAtParent(class, thisObj, mfail) \
        _x3ShowContainedModlsAtClass(class, TRUE, thisObj, mfail)

#define x3ShowModelsOfVol(className, mfail) \
        _x3ShowModelsOfVol(className, FALSE, className, mfail)
#define x3ShowModelsOfVolAtParent(_class, className, mfail) \
        _x3ShowModelsOfVol(_class, TRUE, className, mfail)

#define x3ShowNeighbours(thisObj, mfail) \
        _x3ShowNeighboursAtClass(NULL, FALSE, thisObj, mfail)
#define x3ShowNeighboursAtClass(class, thisObj, mfail) \
        _x3ShowNeighboursAtClass(class, FALSE, thisObj, mfail)
#define x3ShowNeighboursAtParent(class, thisObj, mfail) \
        _x3ShowNeighboursAtClass(class, TRUE, thisObj, mfail)

#define x3ShowUpdTrafoTxt(assmStrcObj, msgNr, parms, vStats, mfail) \
        _x3ShowUpdTrafoTxtAtClass(NULL, FALSE, assmStrcObj, msgNr, parms, vStats, mfail)
#define x3ShowUpdTrafoTxtAtClass(class, assmStrcObj, msgNr, parms, vStats, mfail) \
        _x3ShowUpdTrafoTxtAtClass(class, FALSE, assmStrcObj, msgNr, parms, vStats, mfail)
#define x3ShowUpdTrafoTxtAtParent(class, assmStrcObj, msgNr, parms, vStats, mfail) \
        _x3ShowUpdTrafoTxtAtClass(class, TRUE, assmStrcObj, msgNr, parms, vStats, mfail)

#define x3SortModelsByCus(GenItemObj, modelsOfPart, ModRepObjSet, mfail) \
        _x3SortModelsByCusAtClass(NULL, FALSE, GenItemObj, modelsOfPart, ModRepObjSet, mfail)
#define x3SortModelsByCusAtClass(class, GenItemObj, modelsOfPart, ModRepObjSet, mfail) \
        _x3SortModelsByCusAtClass(class, FALSE, GenItemObj, modelsOfPart, ModRepObjSet, mfail)
#define x3SortModelsByCusAtParent(class, GenItemObj, modelsOfPart, ModRepObjSet, mfail) \
        _x3SortModelsByCusAtClass(class, TRUE, GenItemObj, modelsOfPart, ModRepObjSet, mfail)

#define x3StoreChildInstNames(classname, partObj, productObj, vInstanceNameSet, vPartPartNumberSet, vModelInstNamesSet, vNewModelInstNamesSet, vModelPartNumberSet, vModelOldObidSet, vModelNewObidSet, mfail) \
        _x3StoreChildInstNames(classname, FALSE, classname, partObj, productObj, vInstanceNameSet, vPartPartNumberSet, vModelInstNamesSet, vNewModelInstNamesSet, vModelPartNumberSet, vModelOldObidSet, vModelNewObidSet, mfail)
#define x3StoreChildInstNamesAtParent(_class, classname, partObj, productObj, vInstanceNameSet, vPartPartNumberSet, vModelInstNamesSet, vNewModelInstNamesSet, vModelPartNumberSet, vModelOldObidSet, vModelNewObidSet, mfail) \
        _x3StoreChildInstNames(_class, TRUE, classname, partObj, productObj, vInstanceNameSet, vPartPartNumberSet, vModelInstNamesSet, vNewModelInstNamesSet, vModelPartNumberSet, vModelOldObidSet, vModelNewObidSet, mfail)

#define x3StoreSupplyFile(className, parameterSet, outputSet, mfail) \
        _x3StoreSupplyFile(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3StoreSupplyFileAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3StoreSupplyFile(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3StoreSupplyFileCus(sThisClassName, vObjectObid, vObjectDbName, vObjectClassName, sFileHost, sFullPath, sInfoFromCAD, sReturnCode, mfail) \
        _x3StoreSupplyFileCus(sThisClassName, FALSE, sThisClassName, vObjectObid, vObjectDbName, vObjectClassName, sFileHost, sFullPath, sInfoFromCAD, sReturnCode, mfail)
#define x3StoreSupplyFileCusAtParent(_class, sThisClassName, vObjectObid, vObjectDbName, vObjectClassName, sFileHost, sFullPath, sInfoFromCAD, sReturnCode, mfail) \
        _x3StoreSupplyFileCus(_class, TRUE, sThisClassName, vObjectObid, vObjectDbName, vObjectClassName, sFileHost, sFullPath, sInfoFromCAD, sReturnCode, mfail)

#define x3StoreTreeAllowed(this, bAllowed, mfail) \
        _x3StoreTreeAllowedAtClass(NULL, FALSE, this, bAllowed, mfail)
#define x3StoreTreeAllowedAtClass(class, this, bAllowed, mfail) \
        _x3StoreTreeAllowedAtClass(class, FALSE, this, bAllowed, mfail)
#define x3StoreTreeAllowedAtParent(class, this, bAllowed, mfail) \
        _x3StoreTreeAllowedAtClass(class, TRUE, this, bAllowed, mfail)

#define x3StoreWBContents(this, mfail) \
        _x3StoreWBContentsAtClass(NULL, FALSE, this, mfail)
#define x3StoreWBContentsAtClass(class, this, mfail) \
        _x3StoreWBContentsAtClass(class, FALSE, this, mfail)
#define x3StoreWBContentsAtParent(class, this, mfail) \
        _x3StoreWBContentsAtClass(class, TRUE, this, mfail)

#define x3StoreWBSubtree(ClassName, catiaItem, partOBID, vObjMgrSet, mfail) \
        _x3StoreWBSubtree(ClassName, FALSE, ClassName, catiaItem, partOBID, vObjMgrSet, mfail)
#define x3StoreWBSubtreeAtParent(_class, ClassName, catiaItem, partOBID, vObjMgrSet, mfail) \
        _x3StoreWBSubtree(_class, TRUE, ClassName, catiaItem, partOBID, vObjMgrSet, mfail)

#define x3To4DNav(className, usex0MarkedInWkbnch, mfail) \
        _x3To4DNav(className, FALSE, className, usex0MarkedInWkbnch, mfail)
#define x3To4DNavAtParent(_class, className, usex0MarkedInWkbnch, mfail) \
        _x3To4DNav(_class, TRUE, className, usex0MarkedInWkbnch, mfail)

#define x3ToCatia(className, usex0MarkedInWkbnch, mfail) \
        _x3ToCatia(className, FALSE, className, usex0MarkedInWkbnch, mfail)
#define x3ToCatiaAtParent(_class, className, usex0MarkedInWkbnch, mfail) \
        _x3ToCatia(_class, TRUE, className, usex0MarkedInWkbnch, mfail)

#define x3ToCatiaPre(classname, ComStat, mfail) \
        _x3ToCatiaPre(classname, FALSE, classname, ComStat, mfail)
#define x3ToCatiaPreAtParent(_class, classname, ComStat, mfail) \
        _x3ToCatiaPre(_class, TRUE, classname, ComStat, mfail)

#define x3ToEPlot(className, mfail) \
        _x3ToEPlot(className, FALSE, className, mfail)
#define x3ToEPlotAtParent(_class, className, mfail) \
        _x3ToEPlot(_class, TRUE, className, mfail)

#define x3ToEPlotV5(className, mfail) \
        _x3ToEPlotV5(className, FALSE, className, mfail)
#define x3ToEPlotV5AtParent(_class, className, mfail) \
        _x3ToEPlotV5(_class, TRUE, className, mfail)

#define x3ToView(className, usex0MarkedInWkbnch, mfail) \
        _x3ToView(className, FALSE, className, usex0MarkedInWkbnch, mfail)
#define x3ToViewAtParent(_class, className, usex0MarkedInWkbnch, mfail) \
        _x3ToView(_class, TRUE, className, usex0MarkedInWkbnch, mfail)

#define x3UnmarkAll(className, mfail) \
        _x3UnmarkAll(className, FALSE, className, mfail)
#define x3UnmarkAllAtParent(_class, className, mfail) \
        _x3UnmarkAll(_class, TRUE, className, mfail)

#define x3UnmarkSubTree(thisObj, mfail) \
        _x3UnmarkSubTreeAtClass(NULL, FALSE, thisObj, mfail)
#define x3UnmarkSubTreeAtClass(class, thisObj, mfail) \
        _x3UnmarkSubTreeAtClass(class, FALSE, thisObj, mfail)
#define x3UnmarkSubTreeAtParent(class, thisObj, mfail) \
        _x3UnmarkSubTreeAtClass(class, TRUE, thisObj, mfail)

#define x3UpdCreCatalogFrFile(className, parameterSet, outputSet, mfail) \
        _x3UpdCreCatalogFrFile(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3UpdCreCatalogFrFileAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3UpdCreCatalogFrFile(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3UpdateAllIcons(this, ctxObj, mfail) \
        _x3UpdateAllIconsAtClass(NULL, FALSE, this, ctxObj, mfail)
#define x3UpdateAllIconsAtClass(class, this, ctxObj, mfail) \
        _x3UpdateAllIconsAtClass(class, FALSE, this, ctxObj, mfail)
#define x3UpdateAllIconsAtParent(class, this, ctxObj, mfail) \
        _x3UpdateAllIconsAtClass(class, TRUE, this, ctxObj, mfail)

#define x3UpdateAllOccurencies(this, ctxObj, mfail) \
        _x3UpdateAllOccurenciesAtClass(NULL, FALSE, this, ctxObj, mfail)
#define x3UpdateAllOccurenciesAtClass(class, this, ctxObj, mfail) \
        _x3UpdateAllOccurenciesAtClass(class, FALSE, this, ctxObj, mfail)
#define x3UpdateAllOccurenciesAtParent(class, this, ctxObj, mfail) \
        _x3UpdateAllOccurenciesAtClass(class, TRUE, this, ctxObj, mfail)

#define x3UpdateCatalogPost(thisPtr, nvsObjInfos, mfail) \
        _x3UpdateCatalogPostAtClass(NULL, FALSE, thisPtr, nvsObjInfos, mfail)
#define x3UpdateCatalogPostAtClass(class, thisPtr, nvsObjInfos, mfail) \
        _x3UpdateCatalogPostAtClass(class, FALSE, thisPtr, nvsObjInfos, mfail)
#define x3UpdateCatalogPostAtParent(class, thisPtr, nvsObjInfos, mfail) \
        _x3UpdateCatalogPostAtClass(class, TRUE, thisPtr, nvsObjInfos, mfail)

#define x3UpdateCatiaCatalog(thisCatalogObj, xmapfilename, hostname, username, nvsObjInfos, mfail) \
        _x3UpdateCatiaCatalogAtClass(NULL, FALSE, thisCatalogObj, xmapfilename, hostname, username, nvsObjInfos, mfail)
#define x3UpdateCatiaCatalogAtClass(class, thisCatalogObj, xmapfilename, hostname, username, nvsObjInfos, mfail) \
        _x3UpdateCatiaCatalogAtClass(class, FALSE, thisCatalogObj, xmapfilename, hostname, username, nvsObjInfos, mfail)
#define x3UpdateCatiaCatalogAtParent(class, thisCatalogObj, xmapfilename, hostname, username, nvsObjInfos, mfail) \
        _x3UpdateCatiaCatalogAtClass(class, TRUE, thisCatalogObj, xmapfilename, hostname, username, nvsObjInfos, mfail)

#define x3UpdateCatiaFiles(ClassName, vParentProducts, vParentPartNumbers, vInstanceParentPNs, vInstanceOldNames, vInstanceNewNames, vChildObjects, vChildOldPartNumbers, vChildPartNumbers, vChildOldFileName, sCatiaEnvironment, vStats, mfail) \
        _x3UpdateCatiaFiles(ClassName, FALSE, ClassName, vParentProducts, vParentPartNumbers, vInstanceParentPNs, vInstanceOldNames, vInstanceNewNames, vChildObjects, vChildOldPartNumbers, vChildPartNumbers, vChildOldFileName, sCatiaEnvironment, vStats, mfail)
#define x3UpdateCatiaFilesAtParent(_class, ClassName, vParentProducts, vParentPartNumbers, vInstanceParentPNs, vInstanceOldNames, vInstanceNewNames, vChildObjects, vChildOldPartNumbers, vChildPartNumbers, vChildOldFileName, sCatiaEnvironment, vStats, mfail) \
        _x3UpdateCatiaFiles(_class, TRUE, ClassName, vParentProducts, vParentPartNumbers, vInstanceParentPNs, vInstanceOldNames, vInstanceNewNames, vChildObjects, vChildOldPartNumbers, vChildPartNumbers, vChildOldFileName, sCatiaEnvironment, vStats, mfail)

#define x3UpdateDepV5(thisObj, ModelInfo, vStats, updateOk, mfail) \
        _x3UpdateDepV5AtClass(NULL, FALSE, thisObj, ModelInfo, vStats, updateOk, mfail)
#define x3UpdateDepV5AtClass(class, thisObj, ModelInfo, vStats, updateOk, mfail) \
        _x3UpdateDepV5AtClass(class, FALSE, thisObj, ModelInfo, vStats, updateOk, mfail)
#define x3UpdateDepV5AtParent(class, thisObj, ModelInfo, vStats, updateOk, mfail) \
        _x3UpdateDepV5AtClass(class, TRUE, thisObj, ModelInfo, vStats, updateOk, mfail)

#define x3UpdateDocForECMI(thisObj, strDocNamesList, strDocValuesList, messageText, messageAdded, mfail) \
        _x3UpdateDocForECMIAtClass(NULL, FALSE, thisObj, strDocNamesList, strDocValuesList, messageText, messageAdded, mfail)
#define x3UpdateDocForECMIAtClass(class, thisObj, strDocNamesList, strDocValuesList, messageText, messageAdded, mfail) \
        _x3UpdateDocForECMIAtClass(class, FALSE, thisObj, strDocNamesList, strDocValuesList, messageText, messageAdded, mfail)
#define x3UpdateDocForECMIAtParent(class, thisObj, strDocNamesList, strDocValuesList, messageText, messageAdded, mfail) \
        _x3UpdateDocForECMIAtClass(class, TRUE, thisObj, strDocNamesList, strDocValuesList, messageText, messageAdded, mfail)

#define x3UpdateFileForECMI(thisObj, strModelSize, strLastUpdate, strFileNamesList, strFileValuesList, messageText, messageAdded, mfail) \
        _x3UpdateFileForECMIAtClass(NULL, FALSE, thisObj, strModelSize, strLastUpdate, strFileNamesList, strFileValuesList, messageText, messageAdded, mfail)
#define x3UpdateFileForECMIAtClass(class, thisObj, strModelSize, strLastUpdate, strFileNamesList, strFileValuesList, messageText, messageAdded, mfail) \
        _x3UpdateFileForECMIAtClass(class, FALSE, thisObj, strModelSize, strLastUpdate, strFileNamesList, strFileValuesList, messageText, messageAdded, mfail)
#define x3UpdateFileForECMIAtParent(class, thisObj, strModelSize, strLastUpdate, strFileNamesList, strFileValuesList, messageText, messageAdded, mfail) \
        _x3UpdateFileForECMIAtClass(class, TRUE, thisObj, strModelSize, strLastUpdate, strFileNamesList, strFileValuesList, messageText, messageAdded, mfail)

#define x3UpdateForECMI(ClassName, structureFile, ticketObject, mfail) \
        _x3UpdateForECMI(ClassName, FALSE, ClassName, structureFile, ticketObject, mfail)
#define x3UpdateForECMIAtParent(_class, ClassName, structureFile, ticketObject, mfail) \
        _x3UpdateForECMI(_class, TRUE, ClassName, structureFile, ticketObject, mfail)

#define x3UpdateFromFile(className, parameterSet, outputSet, mfail) \
        _x3UpdateFromFile(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3UpdateFromFileAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3UpdateFromFile(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3UpdateObject(this, ctxObj, mfail) \
        _x3UpdateObjectAtClass(NULL, FALSE, this, ctxObj, mfail)
#define x3UpdateObjectAtClass(class, this, ctxObj, mfail) \
        _x3UpdateObjectAtClass(class, FALSE, this, ctxObj, mfail)
#define x3UpdateObjectAtParent(class, this, ctxObj, mfail) \
        _x3UpdateObjectAtClass(class, TRUE, this, ctxObj, mfail)

#define x3UpdateTrafo(this, matrix_index, matric, unit, mfail) \
        _x3UpdateTrafoAtClass(NULL, FALSE, this, matrix_index, matric, unit, mfail)
#define x3UpdateTrafoAtClass(class, this, matrix_index, matric, unit, mfail) \
        _x3UpdateTrafoAtClass(class, FALSE, this, matrix_index, matric, unit, mfail)
#define x3UpdateTrafoAtParent(class, this, matrix_index, matric, unit, mfail) \
        _x3UpdateTrafoAtClass(class, TRUE, this, matrix_index, matric, unit, mfail)

#define x3UpdateTrafoExt(this, partNumberLeft, partNumberRight, matrix_index, matric, unit, vStats, mfail) \
        _x3UpdateTrafoExtAtClass(NULL, FALSE, this, partNumberLeft, partNumberRight, matrix_index, matric, unit, vStats, mfail)
#define x3UpdateTrafoExtAtClass(class, this, partNumberLeft, partNumberRight, matrix_index, matric, unit, vStats, mfail) \
        _x3UpdateTrafoExtAtClass(class, FALSE, this, partNumberLeft, partNumberRight, matrix_index, matric, unit, vStats, mfail)
#define x3UpdateTrafoExtAtParent(class, this, partNumberLeft, partNumberRight, matrix_index, matric, unit, vStats, mfail) \
        _x3UpdateTrafoExtAtClass(class, TRUE, this, partNumberLeft, partNumberRight, matrix_index, matric, unit, vStats, mfail)

#define x3UpdateWBFromFile(className, parameterSet, outputSet, mfail) \
        _x3UpdateWBFromFile(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3UpdateWBFromFileAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3UpdateWBFromFile(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3UseCCS(classname, bUseCCS, mfail) \
        _x3UseCCS(classname, FALSE, classname, bUseCCS, mfail)
#define x3UseCCSAtParent(_class, classname, bUseCCS, mfail) \
        _x3UseCCS(_class, TRUE, classname, bUseCCS, mfail)

#define x3UseCgrFile(thisPtr, bUseCgr, sUseRelCache, mfail) \
        _x3UseCgrFileAtClass(NULL, FALSE, thisPtr, bUseCgr, sUseRelCache, mfail)
#define x3UseCgrFileAtClass(class, thisPtr, bUseCgr, sUseRelCache, mfail) \
        _x3UseCgrFileAtClass(class, FALSE, thisPtr, bUseCgr, sUseRelCache, mfail)
#define x3UseCgrFileAtParent(class, thisPtr, bUseCgr, sUseRelCache, mfail) \
        _x3UseCgrFileAtClass(class, TRUE, thisPtr, bUseCgr, sUseRelCache, mfail)

#define x3UseCustomDocCreate(classname, useCustom, mfail) \
        _x3UseCustomDocCreate(classname, FALSE, classname, useCustom, mfail)
#define x3UseCustomDocCreateAtParent(_class, classname, useCustom, mfail) \
        _x3UseCustomDocCreate(_class, TRUE, classname, useCustom, mfail)

#define x3UseEmbeddedPrdECMI(thisObj, bUseEmbedded, mfail) \
        _x3UseEmbeddedPrdECMIAtClass(NULL, FALSE, thisObj, bUseEmbedded, mfail)
#define x3UseEmbeddedPrdECMIAtClass(class, thisObj, bUseEmbedded, mfail) \
        _x3UseEmbeddedPrdECMIAtClass(class, FALSE, thisObj, bUseEmbedded, mfail)
#define x3UseEmbeddedPrdECMIAtParent(class, thisObj, bUseEmbedded, mfail) \
        _x3UseEmbeddedPrdECMIAtClass(class, TRUE, thisObj, bUseEmbedded, mfail)

#define x3UseEmbeddedProduct(self, CTItemObj, bUseEmbedded, mfail) \
        _x3UseEmbeddedProductAtClass(NULL, FALSE, self, CTItemObj, bUseEmbedded, mfail)
#define x3UseEmbeddedProductAtClass(class, self, CTItemObj, bUseEmbedded, mfail) \
        _x3UseEmbeddedProductAtClass(class, FALSE, self, CTItemObj, bUseEmbedded, mfail)
#define x3UseEmbeddedProductAtParent(class, self, CTItemObj, bUseEmbedded, mfail) \
        _x3UseEmbeddedProductAtClass(class, TRUE, self, CTItemObj, bUseEmbedded, mfail)

#define x3UseMultiQtyRel(className, parentObj, childObj, relInfos, bUseMultiQtyRel, mfail) \
        _x3UseMultiQtyRel(className, FALSE, className, parentObj, childObj, relInfos, bUseMultiQtyRel, mfail)
#define x3UseMultiQtyRelAtParent(_class, className, parentObj, childObj, relInfos, bUseMultiQtyRel, mfail) \
        _x3UseMultiQtyRel(_class, TRUE, className, parentObj, childObj, relInfos, bUseMultiQtyRel, mfail)

#define x3UsePdmStructure(className, parameterSet, outputSet, mfail) \
        _x3UsePdmStructure(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3UsePdmStructureAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3UsePdmStructure(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3ValArcNames(classname, parentPartnumber, vObjectSet, mfail) \
        _x3ValArcNames(classname, FALSE, classname, parentPartnumber, vObjectSet, mfail)
#define x3ValArcNamesAtParent(_class, classname, parentPartnumber, vObjectSet, mfail) \
        _x3ValArcNames(_class, TRUE, classname, parentPartnumber, vObjectSet, mfail)

#define x3ValAttachV5ObjInst(strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail) \
        _x3ValAttachV5ObjInst(strClassname, FALSE, strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail)
#define x3ValAttachV5ObjInstAtParent(_class, strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail) \
        _x3ValAttachV5ObjInst(_class, TRUE, strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail)

#define x3ValCreateForDoc(this, filePath, mfail) \
        _x3ValCreateForDocAtClass(NULL, FALSE, this, filePath, mfail)
#define x3ValCreateForDocAtClass(class, this, filePath, mfail) \
        _x3ValCreateForDocAtClass(class, FALSE, this, filePath, mfail)
#define x3ValCreateForDocAtParent(class, this, filePath, mfail) \
        _x3ValCreateForDocAtClass(class, TRUE, this, filePath, mfail)

#define x3ValCreateV5Obj(strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail) \
        _x3ValCreateV5Obj(strClassname, FALSE, strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail)
#define x3ValCreateV5ObjAtParent(_class, strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail) \
        _x3ValCreateV5Obj(_class, TRUE, strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail)

#define x3ValDropV5ObjInst(strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail) \
        _x3ValDropV5ObjInst(strClassname, FALSE, strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail)
#define x3ValDropV5ObjInstAtParent(_class, strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail) \
        _x3ValDropV5ObjInst(_class, TRUE, strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail)

#define x3ValPrepareV5Obj(strClassname, nvsObjInfos, pbIsValid, pStrCatiaMsg, mfail) \
        _x3ValPrepareV5Obj(strClassname, FALSE, strClassname, nvsObjInfos, pbIsValid, pStrCatiaMsg, mfail)
#define x3ValPrepareV5ObjAtParent(_class, strClassname, nvsObjInfos, pbIsValid, pStrCatiaMsg, mfail) \
        _x3ValPrepareV5Obj(_class, TRUE, strClassname, nvsObjInfos, pbIsValid, pStrCatiaMsg, mfail)

#define x3ValUpdateV5Obj(strClassname, nvsObjInfos, pbIsValid, pStrCatiaMsg, mfail) \
        _x3ValUpdateV5Obj(strClassname, FALSE, strClassname, nvsObjInfos, pbIsValid, pStrCatiaMsg, mfail)
#define x3ValUpdateV5ObjAtParent(_class, strClassname, nvsObjInfos, pbIsValid, pStrCatiaMsg, mfail) \
        _x3ValUpdateV5Obj(_class, TRUE, strClassname, nvsObjInfos, pbIsValid, pStrCatiaMsg, mfail)

#define x3ValUpdateV5ObjInst(strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail) \
        _x3ValUpdateV5ObjInst(strClassname, FALSE, strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail)
#define x3ValUpdateV5ObjInstAtParent(_class, strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail) \
        _x3ValUpdateV5ObjInst(_class, TRUE, strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail)

#define x3ValUseV5Obj(strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail) \
        _x3ValUseV5Obj(strClassname, FALSE, strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail)
#define x3ValUseV5ObjAtParent(_class, strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail) \
        _x3ValUseV5Obj(_class, TRUE, strClassname, nvsObjInfos, nvsParentObjInfos, pbIsValid, pStrCatiaMsg, mfail)

#define x3ValidateArchive(className, parameterSet, outputSet, mfail) \
        _x3ValidateArchive(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3ValidateArchiveAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3ValidateArchive(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3ValidatePrdRelCreate(self, mfail) \
        _x3ValidatePrdRelCreateAtClass(NULL, FALSE, self, mfail)
#define x3ValidatePrdRelCreateAtClass(class, self, mfail) \
        _x3ValidatePrdRelCreateAtClass(class, FALSE, self, mfail)
#define x3ValidatePrdRelCreateAtParent(class, self, mfail) \
        _x3ValidatePrdRelCreateAtClass(class, TRUE, self, mfail)

#define x3ValidateSaveAs(this, ModelInfos, mfail) \
        _x3ValidateSaveAsAtClass(NULL, FALSE, this, ModelInfos, mfail)
#define x3ValidateSaveAsAtClass(class, this, ModelInfos, mfail) \
        _x3ValidateSaveAsAtClass(class, FALSE, this, ModelInfos, mfail)
#define x3ValidateSaveAsAtParent(class, this, ModelInfos, mfail) \
        _x3ValidateSaveAsAtClass(class, TRUE, this, ModelInfos, mfail)

#define x3ValidateSaveModel(this, mfail) \
        _x3ValidateSaveModelAtClass(NULL, FALSE, this, mfail)
#define x3ValidateSaveModelAtClass(class, this, mfail) \
        _x3ValidateSaveModelAtClass(class, FALSE, this, mfail)
#define x3ValidateSaveModelAtParent(class, this, mfail) \
        _x3ValidateSaveModelAtClass(class, TRUE, this, mfail)

#define x3ValidateSavePart(this, mfail) \
        _x3ValidateSavePartAtClass(NULL, FALSE, this, mfail)
#define x3ValidateSavePartAtClass(class, this, mfail) \
        _x3ValidateSavePartAtClass(class, FALSE, this, mfail)
#define x3ValidateSavePartAtParent(class, this, mfail) \
        _x3ValidateSavePartAtClass(class, TRUE, this, mfail)

#define x3ValidateUpdateDoc(this, mfail) \
        _x3ValidateUpdateDocAtClass(NULL, FALSE, this, mfail)
#define x3ValidateUpdateDocAtClass(class, this, mfail) \
        _x3ValidateUpdateDocAtClass(class, FALSE, this, mfail)
#define x3ValidateUpdateDocAtParent(class, this, mfail) \
        _x3ValidateUpdateDocAtClass(class, TRUE, this, mfail)

#define x3ValidateV5Nodes(className, parameterSet, outputSet, mfail) \
        _x3ValidateV5Nodes(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3ValidateV5NodesAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3ValidateV5Nodes(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3WriteCMIFile(className, parameterSet, outputSet, mfail) \
        _x3WriteCMIFile(className, FALSE, className, parameterSet, outputSet, mfail)
#define x3WriteCMIFileAtParent(_class, className, parameterSet, outputSet, mfail) \
        _x3WriteCMIFile(_class, TRUE, className, parameterSet, outputSet, mfail)

#define x3WriteEPlot(className, DraftsList, ViewsList, FramesList, ModelObject, mfail) \
        _x3WriteEPlot(className, FALSE, className, DraftsList, ViewsList, FramesList, ModelObject, mfail)
#define x3WriteEPlotAtParent(_class, className, DraftsList, ViewsList, FramesList, ModelObject, mfail) \
        _x3WriteEPlot(_class, TRUE, className, DraftsList, ViewsList, FramesList, ModelObject, mfail)

#define x3WriteEPlotV5(className, ModelObject, mfail) \
        _x3WriteEPlotV5(className, FALSE, className, ModelObject, mfail)
#define x3WriteEPlotV5AtParent(_class, className, ModelObject, mfail) \
        _x3WriteEPlotV5(_class, TRUE, className, ModelObject, mfail)

#define x3WriteModToSceneStr(ClassName, modOBID, RelativePath, dpath, set, mfail) \
        _x3WriteModToSceneStr(ClassName, FALSE, ClassName, modOBID, RelativePath, dpath, set, mfail)
#define x3WriteModToSceneStrAtParent(_class, ClassName, modOBID, RelativePath, dpath, set, mfail) \
        _x3WriteModToSceneStr(_class, TRUE, ClassName, modOBID, RelativePath, dpath, set, mfail)

#define x3WriteToEnvision(className, mfail) \
        _x3WriteToEnvision(className, FALSE, className, mfail)
#define x3WriteToEnvisionAtParent(_class, className, mfail) \
        _x3WriteToEnvision(_class, TRUE, className, mfail)

#define x3WriteToEnvisionPost(className, sfilename, sfolder, sfilenamewithfolder, mfail) \
        _x3WriteToEnvisionPost(className, FALSE, className, sfilename, sfolder, sfilenamewithfolder, mfail)
#define x3WriteToEnvisionPostAtParent(_class, className, sfilename, sfolder, sfilenamewithfolder, mfail) \
        _x3WriteToEnvisionPost(_class, TRUE, className, sfilename, sfolder, sfilenamewithfolder, mfail)

#define x3XMLModelInfoFast(thisObj, cmi_ID, xmlFile, mfail) \
        _x3XMLModelInfoFastAtClass(NULL, FALSE, thisObj, cmi_ID, xmlFile, mfail)
#define x3XMLModelInfoFastAtClass(class, thisObj, cmi_ID, xmlFile, mfail) \
        _x3XMLModelInfoFastAtClass(class, FALSE, thisObj, cmi_ID, xmlFile, mfail)
#define x3XMLModelInfoFastAtParent(class, thisObj, cmi_ID, xmlFile, mfail) \
        _x3XMLModelInfoFastAtClass(class, TRUE, thisObj, cmi_ID, xmlFile, mfail)

#define x3sCmiExport(className, mfail) \
        _x3sCmiExport(className, FALSE, className, mfail)
#define x3sCmiExportAtParent(_class, className, mfail) \
        _x3sCmiExport(_class, TRUE, className, mfail)

#define x3sCmiImport(className, mfail) \
        _x3sCmiImport(className, FALSE, className, mfail)
#define x3sCmiImportAtParent(_class, className, mfail) \
        _x3sCmiImport(_class, TRUE, className, mfail)
#endif /* for msgcmi_H */

