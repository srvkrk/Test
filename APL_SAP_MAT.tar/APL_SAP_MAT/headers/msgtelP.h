/*
 *  FILE: msgtelP.h
 */

#ifndef msgtelP_H
#define msgtelP_H

#include <Mtimsgh.h>
#include <metadt.h>
/*
 *  Message Function Definitions (Prototypes).
 *  Published Messages
 */

MTIstatus _APLDmlPrintRptMailMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _MulExpRptMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _MulImpRptMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _PostLCDocValidationsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _PreLCDocValidationsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _SnglExpMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _SnglImpMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _t5BOMEditorMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   integer * mfail);

MTIstatus _t5CheckForDesignerAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5ChkDocDescribesPartAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5CkPartAssignedtoDMLAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);

MTIstatus _t5CnvrtDocMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _t5CreUpdBOMMsg
   (MTIconstString _class, boolean getParent, MTIconstString className,
   ObjectPtr dialogObj, SetOfObjects chldObjSet, SetOfObjects relObjSet,
   integer * mfail);

MTIstatus _t5DMLPrintReportAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _t5DmlPDDAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _t5PartDocInfoRptMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _t5PartOwnerRptMsgAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr pdmItem,
   ObjectPtr taskObject, ObjectPtr argsObj, SetOfStrings * outputStringSet,
   integer * mfail);

MTIstatus _t5PopulatepartsAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr thisObj,
   MTIconstString originClassName, MTIconstString option, SetOfObjects originObjectSet,
   SetOfStrings * extraStr, SetOfObjects * extraObj, integer * keepInteracting,
   integer * mfail);

MTIstatus _t5RenameDocAtClass
   (MTIconstString _class, boolean getParent, ObjectPtr obj,
   ObjectPtr procHist, ObjectPtr msgProc, string * exitState,
   string * advComments, integer * mfail);
/*
 *  Message Macro Definitions.
 */

#define APLDmlPrintRptMailMsg(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _APLDmlPrintRptMailMsgAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define APLDmlPrintRptMailMsgAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _APLDmlPrintRptMailMsgAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define APLDmlPrintRptMailMsgAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _APLDmlPrintRptMailMsgAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define MulExpRptMsg(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _MulExpRptMsgAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define MulExpRptMsgAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _MulExpRptMsgAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define MulExpRptMsgAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _MulExpRptMsgAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define MulImpRptMsg(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _MulImpRptMsgAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define MulImpRptMsgAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _MulImpRptMsgAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define MulImpRptMsgAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _MulImpRptMsgAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define PostLCDocValidations(obj, procHist, msgProc, exitState, advComments, mfail) \
        _PostLCDocValidationsAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define PostLCDocValidationsAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _PostLCDocValidationsAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define PostLCDocValidationsAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _PostLCDocValidationsAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define PreLCDocValidations(obj, procHist, msgProc, exitState, advComments, mfail) \
        _PreLCDocValidationsAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define PreLCDocValidationsAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _PreLCDocValidationsAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define PreLCDocValidationsAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _PreLCDocValidationsAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define SnglExpMsg(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _SnglExpMsgAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define SnglExpMsgAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _SnglExpMsgAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define SnglExpMsgAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _SnglExpMsgAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define SnglImpMsg(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _SnglImpMsgAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define SnglImpMsgAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _SnglImpMsgAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define SnglImpMsgAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _SnglImpMsgAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define t5BOMEditorMsg(thisObj, mfail) \
        _t5BOMEditorMsgAtClass(NULL, FALSE, thisObj, mfail)
#define t5BOMEditorMsgAtClass(class, thisObj, mfail) \
        _t5BOMEditorMsgAtClass(class, FALSE, thisObj, mfail)
#define t5BOMEditorMsgAtParent(class, thisObj, mfail) \
        _t5BOMEditorMsgAtClass(class, TRUE, thisObj, mfail)

#define t5CheckForDesigner(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CheckForDesignerAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5CheckForDesignerAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CheckForDesignerAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5CheckForDesignerAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CheckForDesignerAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5ChkDocDescribesPart(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ChkDocDescribesPartAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ChkDocDescribesPartAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ChkDocDescribesPartAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5ChkDocDescribesPartAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5ChkDocDescribesPartAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5CkPartAssignedtoDML(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CkPartAssignedtoDMLAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5CkPartAssignedtoDMLAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CkPartAssignedtoDMLAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5CkPartAssignedtoDMLAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5CkPartAssignedtoDMLAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)

#define t5CnvrtDocMsg(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5CnvrtDocMsgAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5CnvrtDocMsgAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5CnvrtDocMsgAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5CnvrtDocMsgAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5CnvrtDocMsgAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define t5CreUpdBOMMsg(className, dialogObj, chldObjSet, relObjSet, mfail) \
        _t5CreUpdBOMMsg(className, FALSE, className, dialogObj, chldObjSet, relObjSet, mfail)
#define t5CreUpdBOMMsgAtParent(_class, className, dialogObj, chldObjSet, relObjSet, mfail) \
        _t5CreUpdBOMMsg(_class, TRUE, className, dialogObj, chldObjSet, relObjSet, mfail)

#define t5DMLPrintReport(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5DMLPrintReportAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5DMLPrintReportAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5DMLPrintReportAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5DMLPrintReportAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5DMLPrintReportAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define t5DmlPDD(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5DmlPDDAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5DmlPDDAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5DmlPDDAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5DmlPDDAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5DmlPDDAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define t5PartDocInfoRptMsg(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5PartDocInfoRptMsgAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5PartDocInfoRptMsgAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5PartDocInfoRptMsgAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5PartDocInfoRptMsgAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5PartDocInfoRptMsgAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define t5PartOwnerRptMsg(pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5PartOwnerRptMsgAtClass(NULL, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5PartOwnerRptMsgAtClass(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5PartOwnerRptMsgAtClass(class, FALSE, pdmItem, taskObject, argsObj, outputStringSet, mfail)
#define t5PartOwnerRptMsgAtParent(class, pdmItem, taskObject, argsObj, outputStringSet, mfail) \
        _t5PartOwnerRptMsgAtClass(class, TRUE, pdmItem, taskObject, argsObj, outputStringSet, mfail)

#define t5Populateparts(thisObj, originClassName, option, originObjectSet, extraStr, extraObj, keepInteracting, mfail) \
        _t5PopulatepartsAtClass(NULL, FALSE, thisObj, originClassName, option, originObjectSet, extraStr, extraObj, keepInteracting, mfail)
#define t5PopulatepartsAtClass(class, thisObj, originClassName, option, originObjectSet, extraStr, extraObj, keepInteracting, mfail) \
        _t5PopulatepartsAtClass(class, FALSE, thisObj, originClassName, option, originObjectSet, extraStr, extraObj, keepInteracting, mfail)
#define t5PopulatepartsAtParent(class, thisObj, originClassName, option, originObjectSet, extraStr, extraObj, keepInteracting, mfail) \
        _t5PopulatepartsAtClass(class, TRUE, thisObj, originClassName, option, originObjectSet, extraStr, extraObj, keepInteracting, mfail)

#define t5RenameDoc(obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5RenameDocAtClass(NULL, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5RenameDocAtClass(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5RenameDocAtClass(class, FALSE, obj, procHist, msgProc, exitState, advComments, mfail)
#define t5RenameDocAtParent(class, obj, procHist, msgProc, exitState, advComments, mfail) \
        _t5RenameDocAtClass(class, TRUE, obj, procHist, msgProc, exitState, advComments, mfail)
#endif /* for msgtel_H */

