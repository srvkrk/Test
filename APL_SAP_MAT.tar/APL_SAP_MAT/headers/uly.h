/*
bcprt
This software and related documentation are proprietary to UGS Corp.
COPYRIGHT 2006 UGS CORP.  ALL RIGHTS RESERVED
ecprt
*/

/*******************************************************************************
 * FILE
 *   uly.h
 *
 * DESCRIPTION
 *   Contains the header definitions for the uly module.
 *
 * NOTES
 *   None.
 ******************************************************************************/

#ifndef _ULY_
#define _ULY_

/*******************************************************************************
 *   INCLUDE FILES
 ******************************************************************************/

#ifndef _LCINTERP_
#include <uiinc.h>
#endif

/*******************************************************************************
 *   MACRO DEFINITIONS
 ******************************************************************************/

#define Domain                       "GlobalDomain"
#define GlobalDomainAttr             "GlobalDomain"
#define FedSysClass                  "FedSys"
#define ProxyObjClass                "ProxyObj"
#define LocalFedSysNameAttr          "LocalFedSysName"
#define OwnerDirNameAttr             "OwnerDirName"
#define InsertDbNamesAttr            "InsertDbNames"


/* The following values are used to define the behavior of Association
 * Lists when an attempt is made to insert multiple items with the
 * same key value. */
#define ASSOC_REP_ALL       0   /* keep all values */
#define ASSOC_REP_IGNORE    1   /* ignore the new value */
#define ASSOC_REP_OVERRIDE  2   /* use the new value */
#define ASSOC_REP_ERROR     3   /* return an error */

#define ASSOC_ITEM_INSERTED 10  /* item successfully inserted */
#define ASSOC_ITEM_EXISTS   11  /* error due to existence of item */

#define ulyprn(val) ((nlsIsStrNull(val)) ? "NULL": val)

#define EVENT_BROKER_PROG       271
#define EVENT_BROKER_VERS       1

/*******************************************************************************
 *   TYPE DEFINITIONS
 ******************************************************************************/

typedef struct prod_elem_strc
{
   MTIstring prod_rev_id;
   MTIstring prod_id;
   MTIstring prod_rev_view_id;
} ProdElemInfo_t, *ProdElemInfoPtr;

typedef struct prod_doc_strc
{
   MTIstring prod_rev_id;
   MTIstring assoc_ds_id;
   MTIstring ds_id;
   MTIstring mti_class;
   MTIstring plm_role;
} ProdDocInfo_t, *ProdDocInfoPtr;

typedef struct plm_info_strc
{
   int             numProdDoc;
   MTIstring       plm_id;
   ProdElemInfoPtr prodElemInfo;
   SetPtr          prodDocInfoSet;
} PlmInfo_t, *PlmInfoPtr;

typedef struct {
   char *className;
   char *taskName;
   int   maxSize;
} evqb_request_t;

/*******************************************************************************
 *   EXTERNAL GLOBAL VARIABLE DEFINITIONS/DECLARATIONS
 ******************************************************************************/

#ifdef _ULY_DEFNS
#else

#endif /* _ULY_DEFNS */


/*******************************************************************************
 *   EXTERNAL FUNCTION DECLARATIONS
 ******************************************************************************/

/*** dispose functions ***/

MTI_FDECL(EP, MTIstatus, ulyFreeProdElem,
          (ProdElemInfoPtr prodElemInfoPtr));

MTI_FDECL(EP, MTIstatus, ulyFreeProdDoc,
          (ProdDocInfoPtr prodDocInfoPtr));

MTI_FDECL(EP, MTIstatus, ulyFreePlmInfo,
          (PlmInfoPtr plmInfoPtr));

/*** allocate functions ***/

MTI_FDECL(EP, MTIstatus, ulyNewProdElemInfo,
          (ProdElemInfoPtr *prodElemInfoPtr,
           const MTIstring prodRevId,
           const MTIstring prodId,           /* NULL */
           const MTIstring prodRevViewId));  /* NULL */

MTI_FDECL(EP, MTIstatus, ulyNewProdDocInfo,
          (ProdDocInfoPtr  *prodDocInfoPtr,
           const MTIstring prodRevId,
           const MTIstring assocDSId,  /* NULL */
           const MTIstring DSId,       /* NULL */
           const MTIstring mticlass,   /* NULL */
           const MTIstring plmrole));  /* NULL */

MTI_FDECL(EP, PlmInfoPtr, ulyNewPlmInfo,
          ());

MTI_FDECL(EP, boolean, ulyPlmInfoForOBID,
          ());

/*** regular functions ***/

MTI_FDECL(EP, MTIstatus, ulyPlmInfoDispose,
          (const MTIstring    obid));

MTI_FDECL(EP, PlmInfoPtr, ulyPlmInfoCreate,
          (const MTIstring    obid));

MTI_FDECL(EP, MTIstatus, ulyPlmInfoDisposeAll, ());

MTI_FDECL(EP, MTIstatus, ulyGetPlmId,
          (const MTIstring obid,
           MTIstring *plmId));

MTI_FDECL(EP, MTIstatus, ulySetPlmId,
          (const MTIstring obid,
           const MTIstring plmId));

MTI_FDECL(EP, MTIstatus, ulyGetProdElemInfo,
          (const MTIstring obid,
           MTIstring *prodRevId,
           MTIstring *prodId,
           MTIstring *prodRevViewId));

MTI_FDECL(EP, MTIstatus, ulySetProdElemInfo,
          (const MTIstring obid,
           const MTIstring prodRevId,
           const MTIstring prodId,          /* NULL */
           const MTIstring prodRevViewId)); /* NULL */

MTI_FDECL(EP, int, ulyGetProdDocSize,
          (const MTIstring obid));

MTI_FDECL(EP, MTIstatus, ulyGetCacheAllProdElemOBIDs,
          (SetOfStrings *obids));

MTI_FDECL(EP, MTIstatus, ulyGetAllProdElemIds,
          (SetOfStrings *obids));

MTI_FDECL(EP, MTIstatus, ulyGetAllDSIds,
          (SetOfStrings *obids));

MTI_FDECL(EP, MTIstatus, ulyGetProdDocInfo,
          (const MTIstring obid,
           const MTIstring prodRevId,
           const MTIstring assocDSId,
           MTIstring *DSId));

MTI_FDECL(EP, MTIstatus, ulyGetProdRevByDSId,
          (const MTIstring DSId,
           MTIstring *obid,
           MTIstring *prodRevId,
           MTIstring *assocDSId,
           MTIstring *mticlass,
           MTIstring *plmrole));

MTI_FDECL(EP, MTIstatus, ulyGetDSForMTIClass,
          (const MTIstring DSId,
           const MTIstring mticlass,
           const MTIstring plmrole,
           MTIstring *actualDSId,
           MTIstring *obid,
           MTIstring *assocDSId,
           MTIstring *prodRevId));

MTI_FDECL(EP, MTIstatus, ulyGetProdDocInfoByIdx,
          (const MTIstring obid,
           const int idx,
           MTIstring *prodRevId,
           MTIstring *assocDSId,
           MTIstring *dsId,
           MTIstring *mticlass,
           MTIstring *plmrole));

MTI_FDECL(EP, MTIstatus, ulyGetProdRevByProdId,
          (const MTIstring prodId,
           MTIstring *obid,
           MTIstring *prodRevId,
           MTIstring *prodRevViewId));

MTI_FDECL(EP, MTIstatus, ulyGetProdDocInfoSet,
          (const MTIstring obid,
           SetPtr *prodDocInfoSet));

MTI_FDECL(EP, MTIstatus, ulyGetProdDocInfoSetCopy,
          (const MTIstring obid,
           SetPtr *prodDocInfoSet));

MTI_FDECL(EP, MTIstatus, ulyGetProdDocInfoSubSet,
          (const MTIstring obid,
           const MTIstring prodRevId,
           SetPtr *prodDocInfoSet));

MTI_FDECL(EP, MTIstatus, ulySetProdDocInfo,
          (const MTIstring obid,
           const MTIstring prodRevId,
           const MTIstring assocDSId,  /* NULL */
           const MTIstring DSId,       /* NULL */
           const MTIstring mticlass,   /* NULL */
           const MTIstring plmrole));  /* NULL */

MTI_FDECL(EP, MTIstatus, ulyPlmInfoPrint,
          (const MTIstring    obid));

MTI_FDECL(EP, MTIstatus, ulyPlmInfoPrintAll,
          ());

#include <ulyproto.h>

#endif /* _ULY_ */
