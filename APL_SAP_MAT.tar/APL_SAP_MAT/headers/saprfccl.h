

#ifndef SAPRFCcl_H
#define SAPRFCcl_H
/*
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "saprfc.h"
#include "sapitab.h"




#ifndef SAP_FT_SYST_SUBRC
#define SAP_FT_SYST_SUBRC
typedef RFC_INT SYST_SUBRC;
#endif

#ifndef SAP_FT_CSDATA_XFELD      
#define SAP_FT_CSDATA_XFELD      
typedef RFC_CHAR CSDATA_XFELD[1];
#endif                           
																 
                       



#ifndef SAP_ST_BWTAR_D
#define SAP_ST_BWTAR_D
typedef struct {
  RFC_CHAR BwtarD[10];
 } BWTAR_D;
#endif

#ifndef SAP_ST_BKLAS
#define SAP_ST_BKLAS
typedef struct {
  RFC_CHAR Bklas[4];
 } BKLAS;
#endif

#ifndef SAP_ST_MATNR
#define SAP_ST_MATNR
typedef struct {
  RFC_CHAR Matnr[18];
 } MATNR;
#endif

#ifndef SAP_ST_QPART
#define SAP_ST_QPART
typedef struct {
  RFC_CHAR Qpart[8];
 } QPART;
#endif

#ifndef SAP_ST_WERKS_D
#define SAP_ST_WERKS_D
typedef struct {
  RFC_CHAR WerksD[4];
 } WERKS_D;
#endif



#ifndef SAP_ST_CHAR01
#define SAP_ST_CHAR01
typedef struct {
  RFC_CHAR Char01[1];
 } CHAR01;
#endif


#ifndef SAP_TH_CHAR01
#define SAP_TH_CHAR01
static RFC_TYPEHANDLE handleOfCHAR01;

static RFC_TYPE_ELEMENT typeOfCHAR01[] = {
  {"CHAR01", TYPC, 1, 0},
 };
#endif



#ifndef SAP_ST_MATNR
#define SAP_ST_MATNR
typedef struct {
  RFC_CHAR Matnr[18];
 } MATNR;
#endif

#ifndef SAP_TH_MATNR
#define SAP_TH_MATNR
static RFC_TYPEHANDLE handleOfMATNR;

static RFC_TYPE_ELEMENT typeOfMATNR[] = {
  {"MATNR", TYPC, 18, 0},
 };
#endif

#ifndef SAP_ST_MTART
#define SAP_ST_MTART
typedef struct {
  RFC_CHAR Mtart[4];
 } MTART;
#endif

#ifndef SAP_TH_MTART
#define SAP_TH_MTART
static RFC_TYPEHANDLE handleOfMTART;

static RFC_TYPE_ELEMENT typeOfMTART[] = {
  {"MTART", TYPC, 4, 0},
 };
#endif

#ifndef SAP_ST_MBRSH
#define SAP_ST_MBRSH
typedef struct {
  RFC_CHAR Mbrsh[1];
 } MBRSH;
#endif


#ifndef SAP_TH_MBRSH
#define SAP_TH_MBRSH
static RFC_TYPEHANDLE handleOfMBRSH;

static RFC_TYPE_ELEMENT typeOfMBRSH[] = {
  {"MBRSH", TYPC, 1, 0},
 };
#endif

#ifndef SAP_ST_WERKS_D
#define SAP_ST_WERKS_D
typedef struct {
  RFC_CHAR WerksD[4];
 } WERKS_D;
#endif
#ifndef SAP_TH_WERKS_D
#define SAP_TH_WERKS_D
static RFC_TYPEHANDLE handleOfWERKS_D;

static RFC_TYPE_ELEMENT typeOfWERKS_D[] = {
  {"WERKS_D", TYPC, 4, 0},
 };
#endif

#ifndef SAP_ST_AENNR
#define SAP_ST_AENNR
typedef struct {
  RFC_CHAR Aennr[12];
 } AENNR;
#endif


#ifndef SAP_TH_AENNR
#define SAP_TH_AENNR
static RFC_TYPEHANDLE handleOfAENNR;

static RFC_TYPE_ELEMENT typeOfAENNR[] = {
  {"AENNR", TYPC, 12, 0},
 };
#endif

#ifndef SAP_ST_MEINS
#define SAP_ST_MEINS
typedef struct {
  RFC_CHAR Meins[3];
 } MEINS;
#endif


#ifndef SAP_TH_MEINS
#define SAP_TH_MEINS
static RFC_TYPEHANDLE handleOfMEINS;

static RFC_TYPE_ELEMENT typeOfMEINS[] = {
  {"MEINS", TYPC, 3, 0},
 };
#endif

#ifndef SAP_ST_MAKTX
#define SAP_ST_MAKTX
typedef struct {
  RFC_CHAR Maktx[40];
 } MAKTX;
#endif


#ifndef SAP_TH_MAKTX
#define SAP_TH_MAKTX
static RFC_TYPEHANDLE handleOfMAKTX;

static RFC_TYPE_ELEMENT typeOfMAKTX[] = {
  {"MAKTX", TYPC, 40, 0},
 };
#endif

#ifndef SAP_ST_ZEINR
#define SAP_ST_ZEINR
typedef struct {
  RFC_CHAR Zeinr[22];
 } ZEINR;
#endif


#ifndef SAP_TH_ZEINR
#define SAP_TH_ZEINR
static RFC_TYPEHANDLE handleOfZEINR;

static RFC_TYPE_ELEMENT typeOfZEINR[] = {
  {"ZEINR", TYPC, 22, 0},
 };
#endif

#ifndef SAP_ST_ZEIAR
#define SAP_ST_ZEIAR
typedef struct {
  RFC_CHAR Zeiar[3];
 } ZEIAR;
#endif


#ifndef SAP_TH_ZEIAR
#define SAP_TH_ZEIAR
static RFC_TYPEHANDLE handleOfZEIAR;

static RFC_TYPE_ELEMENT typeOfZEIAR[] = {
  {"ZEIAR", TYPC, 3, 0},
 };
#endif

#ifndef SAP_ST_ZEIVR
#define SAP_ST_ZEIVR
typedef struct {
  RFC_CHAR Zeivr[2];
 } ZEIVR;
#endif


#ifndef SAP_TH_ZEIVR
#define SAP_TH_ZEIVR
static RFC_TYPEHANDLE handleOfZEIVR;

static RFC_TYPE_ELEMENT typeOfZEIVR[] = {
  {"ZEIVR", TYPC, 2, 0},
 };
#endif
#ifndef SAP_ST_BLANZ
#define SAP_ST_BLANZ
typedef struct {
  RFC_CHAR Blanz[3];
 } BLANZ;
#endif

#ifndef SAP_TH_BLANZ
#define SAP_TH_BLANZ
static RFC_TYPEHANDLE handleOfBLANZ;

static RFC_TYPE_ELEMENT typeOfBLANZ[] = {
  {"BLANZ", TYPC, 3, 0},
 };
#endif
#ifndef SAP_ST_BISMT
#define SAP_ST_BISMT
typedef struct {
  RFC_CHAR Bismt[18];
 } BISMT;
#endif

#ifndef SAP_TH_BISMT
#define SAP_TH_BISMT
static RFC_TYPEHANDLE handleOfBISMT;

static RFC_TYPE_ELEMENT typeOfBISMT[] = {
  {"BISMT", TYPC, 18, 0},
 };
#endif
#ifndef SAP_ST_NTGEW
#define SAP_ST_NTGEW
typedef struct {
 	RFC_CHAR Ntgew[14];
 } NTGEW;
#endif

#ifndef SAP_TH_NTGEW
#define SAP_TH_NTGEW
static RFC_TYPEHANDLE handleOfNTGEW;

static RFC_TYPE_ELEMENT typeOfNTGEW[] = {
 {"NTGEW",TYPC,14,0},
 };
#endif
#ifndef SAP_ST_CHAR40
#define SAP_ST_CHAR40
typedef struct {
  RFC_CHAR Char40[40];
 } CHAR40;
#endif

#ifndef SAP_TH_CHAR40
#define SAP_TH_CHAR40
static RFC_TYPEHANDLE handleOfCHAR40;

static RFC_TYPE_ELEMENT typeOfCHAR40[] = {
  {"CHAR40", TYPC, 40, 0},
 };
#endif
#ifndef SAP_ST_BRGEW
#define SAP_ST_BRGEW
typedef struct {
  RFC_CHAR Brgew[14];
 } BRGEW;
#endif

#ifndef SAP_TH_BRGEW
#define SAP_TH_BRGEW
static RFC_TYPEHANDLE handleOfBRGEW;

static RFC_TYPE_ELEMENT typeOfBRGEW[] = {
  {"BRGEW", TYPC, 14, 0},
 };
#endif
#ifndef SAP_ST_GEWEI
#define SAP_ST_GEWEI
typedef struct {
  RFC_CHAR Gewei[3];
 } GEWEI;
#endif

#ifndef SAP_TH_GEWEI
#define SAP_TH_GEWEI
static RFC_TYPEHANDLE handleOfGEWEI;

static RFC_TYPE_ELEMENT typeOfGEWEI[] = {
  {"GEWEI", TYPC, 3, 0},
 };
#endif
#ifndef SAP_ST_VOLUM
#define SAP_ST_VOLUM
typedef struct {
  RFC_CHAR Volum[14];
 } VOLUM;
#endif

#ifndef SAP_TH_VOLUM
#define SAP_TH_VOLUM
static RFC_TYPEHANDLE handleOfVOLUM;

static RFC_TYPE_ELEMENT typeOfVOLUM[] = {
  {"VOLUM", TYPC, 14, 0},
 };
#endif
#ifndef SAP_ST_VOLEH
#define SAP_ST_VOLEH
typedef struct {
  RFC_CHAR Voleh[3];
 } VOLEH;
#endif

#ifndef SAP_TH_VOLEH
#define SAP_TH_VOLEH
static RFC_TYPEHANDLE handleOfVOLEH;

static RFC_TYPE_ELEMENT typeOfVOLEH[] = {
  {"VOLEH", TYPC, 3, 0},
 };
#endif
#ifndef SAP_ST_ZEIFO
#define SAP_ST_ZEIFO
typedef struct {
  RFC_CHAR Zeifo[4];
 } ZEIFO;
#endif

#ifndef SAP_TH_ZEIFO
#define SAP_TH_ZEIFO
static RFC_TYPEHANDLE handleOfZEIFO;

static RFC_TYPE_ELEMENT typeOfZEIFO[] = {
  {"ZEIFO", TYPC, 4, 0},
 };
#endif
#ifndef SAP_ST_MATKL
#define SAP_ST_MATKL
typedef struct {
  RFC_CHAR Matkl[9];
 } MATKL;
#endif

#ifndef SAP_TH_MATKL
#define SAP_TH_MATKL
static RFC_TYPEHANDLE handleOfMATKL;

static RFC_TYPE_ELEMENT typeOfMATKL[] = {
  {"MATKL", TYPC, 9, 0},
 };
#endif
#ifndef SAP_ST_SPART
#define SAP_ST_SPART
typedef struct {
  RFC_CHAR Spart[2];
 } SPART;
#endif
#ifndef SAP_TH_SPART
#define SAP_TH_SPART
static RFC_TYPEHANDLE handleOfSPART;

static RFC_TYPE_ELEMENT typeOfSPART[] = {
  {"SPART", TYPC, 2, 0},
 };
#endif
#ifndef SAP_ST_KLASSENART
#define SAP_ST_KLASSENART
typedef struct {
  RFC_CHAR Klassenart[3];
 } KLASSENART;
#endif

#ifndef SAP_TH_KLASSENART
#define SAP_TH_KLASSENART
static RFC_TYPEHANDLE handleOfKLASSENART;

static RFC_TYPE_ELEMENT typeOfKLASSENART[] = {
  {"KLASSENART", TYPC, 3, 0},
 };
#endif
#ifndef SAP_ST_CLASS
#define SAP_ST_CLASS
typedef struct {
  RFC_CHAR Class[18];
 } CLASS;
#endif

#ifndef SAP_TH_CLASS
#define SAP_TH_CLASS
static RFC_TYPEHANDLE handleOfCLASS;

static RFC_TYPE_ELEMENT typeOfCLASS[] = {
  {"CLASS", TYPC, 18, 0},
 };
#endif
#ifndef SAP_ST_DISGR
#define SAP_ST_DISGR
typedef struct {
  RFC_CHAR Disgr[4];
 } DISGR;
#endif

#ifndef SAP_TH_DISGR
#define SAP_TH_DISGR
static RFC_TYPEHANDLE handleOfDISGR;

static RFC_TYPE_ELEMENT typeOfDISGR[] = {
  {"DISGR", TYPC, 4, 0},
 };
#endif
#ifndef SAP_ST_MAABC
#define SAP_ST_MAABC
typedef struct {
  RFC_CHAR Maabc[1];
 } MAABC;
#endif

#ifndef SAP_TH_MAABC
#define SAP_TH_MAABC
static RFC_TYPEHANDLE handleOfMAABC;

static RFC_TYPE_ELEMENT typeOfMAABC[] = {
  {"MAABC", TYPC, 1, 0},
 };
#endif
#ifndef SAP_ST_MMSTA
#define SAP_ST_MMSTA
typedef struct {
  RFC_CHAR Mmsta[2];
 } MMSTA;
#endif

#ifndef SAP_TH_MMSTA
#define SAP_TH_MMSTA
static RFC_TYPEHANDLE handleOfMMSTA;

static RFC_TYPE_ELEMENT typeOfMMSTA[] = {
  {"MMSTA", TYPC, 2, 0},
 };
#endif
#ifndef SAP_ST_DISMM
#define SAP_ST_DISMM
typedef struct {
  RFC_CHAR Dismm[2];
 } DISMM;
#endif

#ifndef SAP_TH_DISMM
#define SAP_TH_DISMM
static RFC_TYPEHANDLE handleOfDISMM;

static RFC_TYPE_ELEMENT typeOfDISMM[] = {
  {"DISMM", TYPC, 2, 0},
 };
#endif
#ifndef SAP_ST_MINBE
#define SAP_ST_MINBE
typedef struct {
  RFC_FLOAT Minbe[13];
 } MINBE;
#endif

#ifndef SAP_TH_MINBE
#define SAP_TH_MINBE
static RFC_TYPEHANDLE handleOfMINBE;

static RFC_TYPE_ELEMENT typeOfMINBE[] = {
  {"MINBE", TYPFLOAT, 13, 3},
 };
#endif
#ifndef SAP_ST_USEQU
#define SAP_ST_USEQU
typedef struct {
  RFC_CHAR Usequ[1];
 } USEQU;
#endif

#ifndef SAP_TH_USEQU
#define SAP_TH_USEQU
static RFC_TYPEHANDLE handleOfUSEQU;

static RFC_TYPE_ELEMENT typeOfUSEQU[] = {
  {"USEQU", TYPC, 1, 0},
 };
#endif
#ifndef SAP_ST_DISPO
#define SAP_ST_DISPO
typedef struct {
  RFC_CHAR Dispo[3];
 } DISPO;
#endif

#ifndef SAP_TH_DISPO
#define SAP_TH_DISPO
static RFC_TYPEHANDLE handleOfDISPO;

static RFC_TYPE_ELEMENT typeOfDISPO[] = {
  {"DISPO", TYPC, 3, 0},
 };
#endif
#ifndef SAP_ST_DISLS
#define SAP_ST_DISLS
typedef struct {
  RFC_CHAR Disls[2];
 } DISLS;
#endif

#ifndef SAP_TH_DISLS
#define SAP_TH_DISLS
static RFC_TYPEHANDLE handleOfDISLS;

static RFC_TYPE_ELEMENT typeOfDISLS[] = {
  {"DISLS", TYPC, 2, 0},
 };
#endif
#ifndef SAP_ST_BSTMI
#define SAP_ST_BSTMI
typedef struct {
  RFC_FLOAT Bstmi[13];
 } BSTMI;
#endif

#ifndef SAP_TH_BSTMI
#define SAP_TH_BSTMI
static RFC_TYPEHANDLE handleOfBSTMI;

static RFC_TYPE_ELEMENT typeOfBSTMI[] = {
  {"BSTMI", TYPFLOAT, 13, 3},
 };
#endif
#ifndef SAP_ST_MABST
#define SAP_ST_MABST
typedef struct {
  RFC_FLOAT Mabst[13];
 } MABST;
#endif

#ifndef SAP_TH_MABST
#define SAP_TH_MABST
static RFC_TYPEHANDLE handleOfMABST;

static RFC_TYPE_ELEMENT typeOfMABST[] = {
  {"MABST", TYPFLOAT, 13, 3},
 };
#endif
#ifndef SAP_ST_BESKZ
#define SAP_ST_BESKZ
typedef struct {
  RFC_CHAR Beskz[1];
 } BESKZ;
#endif

#ifndef SAP_TH_BESKZ
#define SAP_TH_BESKZ
static RFC_TYPEHANDLE handleOfBESKZ;

static RFC_TYPE_ELEMENT typeOfBESKZ[] = {
  {"BESKZ", TYPC, 1, 0},
 };
#endif
#ifndef SAP_ST_SOBSL
#define SAP_ST_SOBSL
typedef struct {
  RFC_CHAR Sobsl[2];
 } SOBSL;
#endif

#ifndef SAP_TH_SOBSL
#define SAP_TH_SOBSL
static RFC_TYPEHANDLE handleOfSOBSL;

static RFC_TYPE_ELEMENT typeOfSOBSL[] = {
  {"SOBSL", TYPC, 2, 0},
 };
#endif
#ifndef SAP_ST_SCHGT
#define SAP_ST_SCHGT
typedef struct {
  RFC_CHAR Schgt[1];
 } SCHGT;
#endif

#ifndef SAP_TH_SCHGT
#define SAP_TH_SCHGT
static RFC_TYPEHANDLE handleOfSCHGT;

static RFC_TYPE_ELEMENT typeOfSCHGT[] = {
  {"SCHGT", TYPC, 1, 0},
 };
#endif
#ifndef SAP_ST_FHORI
#define SAP_ST_FHORI
typedef struct {
  RFC_CHAR Fhori[3];
 } FHORI;
#endif

#ifndef SAP_TH_FHORI
#define SAP_TH_FHORI
static RFC_TYPEHANDLE handleOfFHORI;

static RFC_TYPE_ELEMENT typeOfFHORI[] = {
  {"FHORI", TYPC, 3, 0},
 };
#endif
#ifndef SAP_ST_MRPPP
#define SAP_ST_MRPPP
typedef struct {
  RFC_CHAR Mrppp[3];
 } MRPPP;
#endif
#ifndef SAP_TH_MRPPP
#define SAP_TH_MRPPP
static RFC_TYPEHANDLE handleOfMRPPP;

static RFC_TYPE_ELEMENT typeOfMRPPP[] = {
  {"MRPPP", TYPC, 3, 0},
 };
#endif
#ifndef SAP_ST_KZBED
#define SAP_ST_KZBED
typedef struct {
  RFC_CHAR Kzbed[1];
 } KZBED;
#endif


#ifndef SAP_TH_KZBED
#define SAP_TH_KZBED
static RFC_TYPEHANDLE handleOfKZBED;

static RFC_TYPE_ELEMENT typeOfKZBED[] = {
  {"KZBED", TYPC, 1, 0},
 };
#endif

#ifndef SAP_ST_PERKZ
#define SAP_ST_PERKZ
typedef struct {
  RFC_CHAR Perkz[1];
 } PERKZ;
#endif


#ifndef SAP_TH_PERKZ
#define SAP_TH_PERKZ
static RFC_TYPEHANDLE handleOfPERKZ;

static RFC_TYPE_ELEMENT typeOfPERKZ[] = {
  {"PERKZ", TYPC, 1, 0},
 };
#endif

#ifndef SAP_ST_MISKZ
#define SAP_ST_MISKZ
typedef struct {
  RFC_CHAR Miskz[1];
 } MISKZ;
#endif


#ifndef SAP_TH_MISKZ
#define SAP_TH_MISKZ
static RFC_TYPEHANDLE handleOfMISKZ;

static RFC_TYPE_ELEMENT typeOfMISKZ[] = {
  {"MISKZ", TYPC, 1, 0},
 };
#endif

#ifndef SAP_ST_MTVFP
#define SAP_ST_MTVFP
typedef struct {
  RFC_CHAR Mtvfp[2];
 } MTVFP;
#endif


#ifndef SAP_TH_MTVFP
#define SAP_TH_MTVFP
static RFC_TYPEHANDLE handleOfMTVFP;

static RFC_TYPE_ELEMENT typeOfMTVFP[] = {
  {"MTVFP", TYPC, 2, 0},
 };
#endif

#ifndef SAP_ST_PRGRP
#define SAP_ST_PRGRP
typedef struct {
  RFC_CHAR Prgrp[18];
 } PRGRP;
#endif


#ifndef SAP_TH_PRGRP
#define SAP_TH_PRGRP
static RFC_TYPEHANDLE handleOfPRGRP;

static RFC_TYPE_ELEMENT typeOfPRGRP[] = {
  {"PRGRP", TYPC, 18, 0},
 };
#endif

#ifndef SAP_ST_PRWRK
#define SAP_ST_PRWRK
typedef struct {
  RFC_CHAR Prwrk[4];
 } PRWRK;
#endif


#ifndef SAP_TH_PRWRK
#define SAP_TH_PRWRK
static RFC_TYPEHANDLE handleOfPRWRK;

static RFC_TYPE_ELEMENT typeOfPRWRK[] = {
  {"PRWRK", TYPC, 4, 0},
 };
#endif

#ifndef SAP_ST_UMREF
#define SAP_ST_UMREF
typedef struct {
  RFC_CHAR Umref[10];
 } UMREF;
#endif


#ifndef SAP_TH_UMREF
#define SAP_TH_UMREF
static RFC_TYPEHANDLE handleOfUMREF;

static RFC_TYPE_ELEMENT typeOfUMREF[] = {
  {"UMREF", TYPC, 10, 0},
 };
#endif

#ifndef SAP_ST_ALTSL
#define SAP_ST_ALTSL
typedef struct {
  RFC_CHAR Altsl[1];
 } ALTSL;
#endif


#ifndef SAP_TH_ALTSL
#define SAP_TH_ALTSL
static RFC_TYPEHANDLE handleOfALTSL;

static RFC_TYPE_ELEMENT typeOfALTSL[] = {
  {"ALTSL", TYPC, 1, 0},
 };
#endif

#ifndef SAP_ST_SBDKZ
#define SAP_ST_SBDKZ
typedef struct {
  RFC_CHAR Sbdkz[1];
 } SBDKZ;
#endif


#ifndef SAP_TH_SBDKZ
#define SAP_TH_SBDKZ
static RFC_TYPEHANDLE handleOfSBDKZ;

static RFC_TYPE_ELEMENT typeOfSBDKZ[] = {
  {"SBDKZ", TYPC, 1, 0},
 };
#endif

#ifndef SAP_ST_SAUFT
#define SAP_ST_SAUFT
typedef struct {
  RFC_FLOAT Sauft[15];
 } SAUFT;
#endif


#ifndef SAP_TH_SAUFT
#define SAP_TH_SAUFT
static RFC_TYPEHANDLE handleOfSAUFT;

static RFC_TYPE_ELEMENT typeOfSAUFT[] = {
  {"SAUFT", TYPFLOAT, 15, 2},
 };
#endif

#ifndef SAP_ST_SFEPR
#define SAP_ST_SFEPR
typedef struct {
  RFC_CHAR Sfepr[4];
 } SFEPR;
#endif


#ifndef SAP_TH_SFEPR
#define SAP_TH_SFEPR
static RFC_TYPEHANDLE handleOfSFEPR;

static RFC_TYPE_ELEMENT typeOfSFEPR[] = {
  {"SFEPR", TYPC, 4, 0},
 };
#endif

#ifndef SAP_ST_EPRIO
#define SAP_ST_EPRIO
typedef struct {
  RFC_CHAR Eprio[4];
 } EPRIO;
#endif


#ifndef SAP_TH_EPRIO
#define SAP_TH_EPRIO
static RFC_TYPEHANDLE handleOfEPRIO;

static RFC_TYPE_ELEMENT typeOfEPRIO[] = {
  {"EPRIO", TYPC, 4, 0},
 };
#endif

#ifndef SAP_ST_AUSME
#define SAP_ST_AUSME
typedef struct {
  RFC_CHAR Ausme[3];
 } AUSME;
#endif


#ifndef SAP_TH_AUSME
#define SAP_TH_AUSME
static RFC_TYPEHANDLE handleOfAUSME;

static RFC_TYPE_ELEMENT typeOfAUSME[] = {
  {"AUSME", TYPC, 3, 0},
 };
#endif

#ifndef SAP_ST_PRCTR
#define SAP_ST_PRCTR
typedef struct {
  RFC_CHAR Prctr[10];
 } PRCTR;
#endif


#ifndef SAP_TH_PRCTR
#define SAP_TH_PRCTR
static RFC_TYPEHANDLE handleOfPRCTR;

static RFC_TYPE_ELEMENT typeOfPRCTR[] = {
  {"PRCTR", TYPC, 10, 0},
 };
#endif

#ifndef SAP_ST_INSMK
#define SAP_ST_INSMK
typedef struct {
  RFC_CHAR Insmk[1];
 } INSMK;
#endif


#ifndef SAP_TH_INSMK
#define SAP_TH_INSMK
static RFC_TYPEHANDLE handleOfINSMK;

static RFC_TYPE_ELEMENT typeOfINSMK[] = {
  {"INSMK", TYPC, 1, 0},
 };
#endif

#ifndef SAP_ST_KZDKZ
#define SAP_ST_KZDKZ
typedef struct {
  RFC_CHAR Kzdkz[1];
 } KZDKZ;
#endif


#ifndef SAP_TH_KZDKZ
#define SAP_TH_KZDKZ
static RFC_TYPEHANDLE handleOfKZDKZ;

static RFC_TYPE_ELEMENT typeOfKZDKZ[] = {
  {"KZDKZ", TYPC, 1, 0},
 };
#endif

#ifndef SAP_ST_WEBAZ
#define SAP_ST_WEBAZ
typedef struct {
  RFC_CHAR Webaz[3];
 } WEBAZ;
#endif


#ifndef SAP_TH_WEBAZ
#define SAP_TH_WEBAZ
static RFC_TYPEHANDLE handleOfWEBAZ;

static RFC_TYPE_ELEMENT typeOfWEBAZ[] = {
  {"WEBAZ", TYPC, 3, 0},
 };
#endif

#ifndef SAP_ST_RBNR
#define SAP_ST_RBNR
typedef struct {
  RFC_CHAR Rbnr[9];
 } RBNR;
#endif


#ifndef SAP_TH_RBNR
#define SAP_TH_RBNR
static RFC_TYPEHANDLE handleOfRBNR;

static RFC_TYPE_ELEMENT typeOfRBNR[] = {
  {"RBNR", TYPC, 9, 0},
 };
#endif

#ifndef SAP_ST_QMPUR
#define SAP_ST_QMPUR
typedef struct {
  RFC_CHAR Qmpur[1];
 } QMPUR;
#endif


#ifndef SAP_TH_QMPUR
#define SAP_TH_QMPUR
static RFC_TYPEHANDLE handleOfQMPUR;

static RFC_TYPE_ELEMENT typeOfQMPUR[] = {
  {"QMPUR", TYPC, 1, 0},
 };
#endif

#ifndef SAP_ST_SSQSS
#define SAP_ST_SSQSS
typedef struct {
  RFC_CHAR Ssqss[8];
 } SSQSS;
#endif


#ifndef SAP_TH_SSQSS
#define SAP_TH_SSQSS
static RFC_TYPEHANDLE handleOfSSQSS;

static RFC_TYPE_ELEMENT typeOfSSQSS[] = {
  {"SSQSS", TYPC, 8, 0},
 };
#endif

#ifndef SAP_ST_QZGTYP
#define SAP_ST_QZGTYP
typedef struct {
  RFC_CHAR Qzgtyp[4];
 } QZGTYP;
#endif


#ifndef SAP_TH_QZGTYP
#define SAP_TH_QZGTYP
static RFC_TYPEHANDLE handleOfQZGTYP;

static RFC_TYPE_ELEMENT typeOfQZGTYP[] = {
  {"QZGTYP", TYPC, 4, 0},
 };
#endif

#ifndef SAP_ST_BWTTY
#define SAP_ST_BWTTY
typedef struct {
  RFC_CHAR Bwtty[1];
 } BWTTY;
#endif


#ifndef SAP_TH_BWTTY
#define SAP_TH_BWTTY
static RFC_TYPEHANDLE handleOfBWTTY;

static RFC_TYPE_ELEMENT typeOfBWTTY[] = {
  {"BWTTY", TYPC, 1, 0},
 };
#endif

#ifndef SAP_ST_BKLAS
#define SAP_ST_BKLAS
typedef struct {
  RFC_FLOAT Bklas[11];
 } BKLAS;
#endif


#ifndef SAP_TH_BKLAS
#define SAP_TH_BKLAS
static RFC_TYPEHANDLE handleOfBKLAS;

static RFC_TYPE_ELEMENT typeOfBKLAS[] = {
  {"BKLAS", TYPFLOAT, 11, 2},
 };
#endif

#ifndef SAP_ST_VPRSV
#define SAP_ST_VPRSV
typedef struct {
  RFC_CHAR Vprsv[25];
 } VPRSV;
#endif


#ifndef SAP_TH_VPRSV
#define SAP_TH_VPRSV
static RFC_TYPEHANDLE handleOfVPRSV;

static RFC_TYPE_ELEMENT typeOfVPRSV[] = {
  {"VPRSV", TYPC, 25, 0},
 };
#endif

#ifndef SAP_ST_STPRS
#define SAP_ST_STPRS
typedef struct {
  RFC_CHAR Stprs[1];
 } STPRS;
#endif


#ifndef SAP_TH_STPRS
#define SAP_TH_STPRS
static RFC_TYPEHANDLE handleOfSTPRS;

static RFC_TYPE_ELEMENT typeOfSTPRS[] = {
  {"STPRS", TYPC, 1, 0},
 };
#endif

#ifndef SAP_ST_VERP
#define SAP_ST_VERP
typedef struct {
  RFC_CHAR Verp[4];
 } VERP;
#endif


#ifndef SAP_TH_VERP
#define SAP_TH_VERP
static RFC_TYPEHANDLE handleOfVERP;

static RFC_TYPE_ELEMENT typeOfVERP[] = {
  {"VERP", TYPC, 4, 0},
 };
#endif

#ifndef SAP_ST_HKMAT
#define SAP_ST_HKMAT
typedef struct {
  RFC_FLOAT Hkmat[13];
 } HKMAT;
#endif


#ifndef SAP_TH_HKMAT
#define SAP_TH_HKMAT
static RFC_TYPEHANDLE handleOfHKMAT;

static RFC_TYPE_ELEMENT typeOfHKMAT[] = {
  {"HKMAT", TYPFLOAT, 13, 3},
 };
#endif

#ifndef SAP_ST_HRKFT
#define SAP_ST_HRKFT
typedef struct {
  RFC_CHAR Hrkft[4];
 } HRKFT;
#endif


#ifndef SAP_TH_HRKFT
#define SAP_TH_HRKFT
static RFC_TYPEHANDLE handleOfHRKFT;

static RFC_TYPE_ELEMENT typeOfHRKFT[] = {
  {"HRKFT", TYPC, 4, 0},
 };
#endif

#ifndef SAP_ST_LOSGR
#define SAP_ST_LOSGR
typedef struct {
  RFC_FLOAT Losgr[13];
 } LOSGR;
#endif


#ifndef SAP_TH_LOSGR
#define SAP_TH_LOSGR
static RFC_TYPEHANDLE handleOfLOSGR;

static RFC_TYPE_ELEMENT typeOfLOSGR[] = {
  {"LOSGR", TYPFLOAT, 13, 3},
 };
#endif

#ifndef SAP_ST_CK_KOSGR
#define SAP_ST_CK_KOSGR
typedef struct {
  RFC_CHAR Ck_Kosgr[10];
 } CK_KOSGR;
#endif


#ifndef SAP_TH_CK_KOSGR
#define SAP_TH_CK_KOSGR
static RFC_TYPEHANDLE handleOfCK_KOSGR;

static RFC_TYPE_ELEMENT typeOfCK_KOSGR[] = {
  {"CK_KOSGR", TYPC, 10, 0},
 };
#endif
#ifndef SAP_ST_AWSLS
#define SAP_ST_AWSLS
typedef struct {
  RFC_CHAR Awsls[6];
 } AWSLS;
#endif


#ifndef SAP_TH_AWSLS
#define SAP_TH_AWSLS
static RFC_TYPEHANDLE handleOfAWSLS;

static RFC_TYPE_ELEMENT typeOfAWSLS[] = {
  {"AWSLS", TYPC, 6, 0},
 };
#endif
#ifndef SAP_ST_CK_EKALREL
#define SAP_ST_CK_EKALREL
typedef struct {
  RFC_CHAR Ck_Ekalrel[1];
 } CK_EKALREL;
#endif

#ifndef SAP_TH_CK_EKALREL
#define SAP_TH_CK_EKALREL
static RFC_TYPEHANDLE handleOfCK_EKALREL;

static RFC_TYPE_ELEMENT typeOfCK_EKALREL[] = {
  {"CK_EKALREL", TYPC, 1, 0},
 };
#endif

#ifndef SAP_ST_CHAR255
#define SAP_ST_CHAR255
typedef struct
{
RFC_CHAR char255[255];
}CHAR255;
#endif

#ifndef SAP_ST_MESSAGEINF
#define SAP_ST_MESSAGEINF
typedef struct {
  RFC_CHAR Msgty[1];
  RFC_CHAR Msgid[20];
  RFC_CHAR Msgno[3];
  RFC_CHAR Msspc[1];
  RFC_CHAR Msgtx[255];
 } MESSAGEINF;
#endif

#ifndef SAP_ST_AENR_API01
#define SAP_ST_AENR_API01
typedef struct {         
RFC_CHAR ChangeNo[12];       
RFC_NUM Status[2];           
RFC_CHAR AuthGroup[4];       
RFC_CHAR ValidFrom[10];      
RFC_CHAR Descript[40];       
RFC_CHAR ReasonChg[40];      
RFC_CHAR DeletionMark[1];    
RFC_CHAR IndateRule[10];     
RFC_CHAR OutdateRule[10];    
RFC_CHAR Function[1];        
RFC_CHAR ChangeLeader[12];   
RFC_CHAR EffectivityType[10];
RFC_CHAR OverridingMark[1];  
RFC_NUM Rank[2];             
RFC_NUM ReleaseKey[2];       
RFC_CHAR StatusProfile[8];   
RFC_CHAR TechRel[1];         
RFC_CHAR BasicChange[1];     
} AENR_API01;    
#endif

#ifndef SAP_ST_AENV_API01
#define SAP_ST_AENV_API01
typedef struct {        
RFC_CHAR Active[1];   
RFC_CHAR Locked[1];   
RFC_CHAR ObjRequ[1];  
RFC_CHAR MgtrecGen[1];
RFC_CHAR GenNew[1];   
RFC_CHAR GenDialog[1];
} AENV_API01;          
#endif      

#ifndef SAP_ST_AEEF_API01   
#define SAP_ST_AEEF_API01   
typedef struct {            
RFC_CHAR ValidFrom[10];   
RFC_CHAR ValidTo[10];     
RFC_CHAR DateMark[1];     
RFC_CHAR Material[18];    
RFC_CHAR SerialnrLow[18]; 
RFC_CHAR SerialnrHigh[18];
RFC_CHAR Class[18];       
RFC_CHAR Classty[3];      
RFC_CHAR Startup[30];     
RFC_CHAR Plant[4];        
RFC_CHAR SernrOi[1];      
RFC_CHAR FlDelete[1];     
} AEEF_API01;              
#endif   

#ifndef SAP_ST_AEDT_API01
#define SAP_ST_AEDT_API01
typedef struct {         
RFC_CHAR AltDate[18];  
RFC_CHAR ValidFrom[10];
RFC_CHAR FlDelete[1];  
} AEDT_API01;           
#endif    

#ifndef SAP_ST_AEOI_API01
#define SAP_ST_AEOI_API01
typedef struct {      
RFC_CHAR AltDate[18];     
RFC_NUM ChgObjtyp[1];     
RFC_CHAR BomCat[1];       
RFC_CHAR BomStdObject[18];
RFC_CHAR BomUsage[1];     
RFC_NUM Chgtypeobj[3];    
RFC_CHAR DescrObj[40];    
RFC_CHAR DocType[3];      
RFC_CHAR DocNumber[25];   
RFC_CHAR DocVers[2];      
RFC_CHAR DocPart[3];      
RFC_CHAR Equipment[18];   
RFC_CHAR FuncLoc[30];     
RFC_CHAR Material[18];    
RFC_CHAR Plant[4];        
RFC_CHAR PspElement[24];  
RFC_BYTE PvsGuid[16];     
RFC_CHAR PvsType[1];      
RFC_CHAR PvsNode[40];     
RFC_CHAR PvsClassNumber[18];
RFC_CHAR PvsClassType[3];   
RFC_CHAR PvsVariant[8];     
RFC_CHAR SdOrder[10];       
RFC_NUM SdOrderI[6];        
RFC_NUM Textkey[8];         
RFC_CHAR TlistType[1];      
RFC_CHAR TlistGrp[8];       
RFC_CHAR ObjChglock[1];     
RFC_CHAR StatusProfObj[8];  
RFC_CHAR FlDelete[1];       
 } AEOI_API01;
 #endif        

#ifndef SAP_ST_CCTHEAD 
#define SAP_ST_CCTHEAD 
typedef struct {       
RFC_NUM Textkey[8];  
RFC_CHAR Tdname[70]; 
RFC_CHAR Tdid[4];    
RFC_CHAR Tdspras[1]; 
} CCTHEAD;            
#endif     

#ifndef SAP_ST_CCTLINE
#define SAP_ST_CCTLINE
typedef struct {
  RFC_NUM Textkey[8];
  RFC_CHAR Tdformat[2];
  RFC_CHAR Tdline[132];
 } CCTLINE;
#endif            




#ifndef SAP_TH_BWTAR_D                     
#define SAP_TH_BWTAR_D                     
static RFC_TYPEHANDLE handleOfBWTAR_D;     
                                           
static RFC_TYPE_ELEMENT typeOfBWTAR_D[] = {
  {"BWTAR_D", TYPC, 10, 0},                
 };                                        
#endif                                     


#ifndef SAP_TH_BKLAS
#define SAP_TH_BKLAS
static RFC_TYPEHANDLE handleOfBKLAS;

static RFC_TYPE_ELEMENT typeOfBKLAS[] = {
  {"BKLAS", TYPC, 4, 0},
 };
#endif



#ifndef SAP_TH_MATNR
#define SAP_TH_MATNR
static RFC_TYPEHANDLE handleOfMATNR;

static RFC_TYPE_ELEMENT typeOfMATNR[] = {
  {"MATNR", TYPC, 18, 0},
 };
#endif

#ifndef SAP_TH_QPART
#define SAP_TH_QPART
static RFC_TYPEHANDLE handleOfQPART;

static RFC_TYPE_ELEMENT typeOfQPART[] = {
  {"QPART", TYPC, 8, 0},
 };
#endif

#ifndef SAP_TH_WERKS_D
#define SAP_TH_WERKS_D
static RFC_TYPEHANDLE handleOfWERKS_D;

static RFC_TYPE_ELEMENT typeOfWERKS_D[] = {
  {"WERKS_D", TYPC, 4, 0},
 };
#endif

#ifndef SAP_TW_CHAR255
#define SAP_TH_CHAR255
 static RFC_TYPE_ELEMENT handleOfCHAR255;

 static RFC_TYPE_ELEMENT typeOfCHAR255[]=
{
	 {"CHAR255",TYPC,255,0},
};
#endif

#ifndef SAP_TH_MESSAGEINF
#define SAP_TH_MESSAGEINF
static RFC_TYPEHANDLE handleOfMESSAGEINF;

static RFC_TYPE_ELEMENT typeOfMESSAGEINF[] = {
  {"MSGTY", TYPC, 1, 0},
  {"MSGID", TYPC, 20, 0},
  {"MSGNO", TYPC, 3, 0},
  {"MSSPC", TYPC, 1, 0},
  {"MSGTX", TYPC, 255, 0},
 };
#endif

#ifndef SAP_TH_AENR_API01                 
#define SAP_TH_AENR_API01                 
static RFC_TYPEHANDLE handleOfAENR_API01; 

static RFC_TYPE_ELEMENT typeOfAENR_API01[] = {
 {"CHANGE_NO", TYPC, 12, 0},       
 {"STATUS", TYPNUM, 2, 0},         
 {"AUTH_GROUP", TYPC, 4, 0},       
 {"VALID_FROM", TYPC, 10, 0},      
 {"DESCRIPT", TYPC, 40, 0},        
 {"REASON_CHG", TYPC, 40, 0},      
 {"DELETION_MARK", TYPC, 1, 0},    
 {"INDATE_RULE", TYPC, 10, 0},     
 {"OUTDATE_RULE", TYPC, 10, 0},    
 {"FUNCTION", TYPC, 1, 0},         
 {"CHANGE_LEADER", TYPC, 12, 0},   
 {"EFFECTIVITY_TYPE", TYPC, 10, 0},
 {"OVERRIDING_MARK", TYPC, 1, 0},  
 {"RANK", TYPNUM, 2, 0},           
 {"RELEASE_KEY", TYPNUM, 2, 0},    
 {"STATUS_PROFILE", TYPC, 8, 0},   
 {"STATUS_PROFILE", TYPC, 8, 0},
 {"TECH_REL", TYPC, 1, 0},      
 {"BASIC_CHANGE", TYPC, 1, 0},  
 };   
 #endif

 #ifndef SAP_TH_AENV_API01                
 #define SAP_TH_AENV_API01                
 static RFC_TYPEHANDLE handleOfAENV_API01;

 static RFC_TYPE_ELEMENT typeOfAENV_API01[] = {
  {"ACTIVE", TYPC, 1, 0},    
	{"LOCKED", TYPC, 1, 0},    
	{"OBJ_REQU", TYPC, 1, 0},  
	{"MGTREC_GEN", TYPC, 1, 0},
	{"GEN_NEW", TYPC, 1, 0},   
	{"GEN_DIALOG", TYPC, 1, 0},
 };   
 #endif

 #ifndef SAP_TH_AEEF_API01                
 #define SAP_TH_AEEF_API01                
 static RFC_TYPEHANDLE handleOfAEEF_API01;

 static RFC_TYPE_ELEMENT typeOfAEEF_API01[] = {
 {"VALID_FROM", TYPC, 10, 0},                
 {"VALID_TO", TYPC, 10, 0},                  
 {"DATE_MARK", TYPC, 1, 0},                  
 {"MATERIAL", TYPC, 18, 0},                  
 {"SERIALNR_LOW", TYPC, 18, 0},              
 {"SERIALNR_HIGH", TYPC, 18, 0},             
 {"CLASS", TYPC, 18, 0},                     
 {"CLASSTY", TYPC, 3, 0},                    
 {"STARTUP", TYPC, 30, 0},                   
 {"PLANT", TYPC, 4, 0},                      
 {"SERNR_OI", TYPC, 1, 0},                   
 {"FL_DELETE", TYPC, 1, 0},                  
};                                           
#endif      

#ifndef SAP_TH_AEDT_API01                
#define SAP_TH_AEDT_API01                
static RFC_TYPEHANDLE handleOfAEDT_API01;

static RFC_TYPE_ELEMENT typeOfAEDT_API01[] = {
{"ALT_DATE", TYPC, 18, 0},                  
{"VALID_FROM", TYPC, 10, 0},                
{"FL_DELETE", TYPC, 1, 0},                  
};                                           
#endif    

#ifndef SAP_TH_AEOI_API01                
#define SAP_TH_AEOI_API01                
static RFC_TYPEHANDLE handleOfAEOI_API01;

static RFC_TYPE_ELEMENT typeOfAEOI_API01[] = {
 {"ALT_DATE", TYPC, 18, 0},      
 {"CHG_OBJTYP", TYPNUM, 1, 0},   
 {"BOM_CAT", TYPC, 1, 0},        
 {"BOM_STD_OBJECT", TYPC, 18, 0},
 {"BOM_USAGE", TYPC, 1, 0},      
 {"CHGTYPEOBJ", TYPNUM, 3, 0},   
 {"DESCR_OBJ", TYPC, 40, 0},     
 {"DOC_TYPE", TYPC, 3, 0},       
 {"DOC_NUMBER", TYPC, 25, 0},    
 {"DOC_VERS", TYPC, 2, 0},       
 {"DOC_PART", TYPC, 3, 0},       
 {"EQUIPMENT", TYPC, 18, 0},     
 {"FUNC_LOC", TYPC, 30, 0},      
 {"MATERIAL", TYPC, 18, 0},      
 {"PLANT", TYPC, 4, 0},          
 {"PSP_ELEMENT", TYPC, 24, 0},   
 {"PVS_GUID", TYPX, 16, 0},      
 {"PVS_TYPE", TYPC, 1, 0},       
 {"PVS_NODE", TYPC, 40, 0},        
 {"PVS_CLASS_NUMBER", TYPC, 18, 0},
 {"PVS_CLASS_TYPE", TYPC, 3, 0},   
 {"PVS_VARIANT", TYPC, 8, 0},      
 {"SD_ORDER", TYPC, 10, 0},        
 {"SD_ORDER_I", TYPNUM, 6, 0},     
 {"TEXTKEY", TYPNUM, 8, 0},        
 {"TLIST_TYPE", TYPC, 1, 0},       
 {"TLIST_GRP", TYPC, 8, 0},        
 {"OBJ_CHGLOCK", TYPC, 1, 0},      
 {"STATUS_PROF_OBJ", TYPC, 8, 0},  
 {"FL_DELETE", TYPC, 1, 0},        
};   
#endif

#ifndef SAP_TH_CCTHEAD                
#define SAP_TH_CCTHEAD                
static RFC_TYPEHANDLE handleOfCCTHEAD;

static RFC_TYPE_ELEMENT typeOfCCTHEAD[] = {
{"TEXTKEY", TYPNUM, 8, 0},              
{"TDNAME", TYPC, 70, 0},                
{"TDID", TYPC, 4, 0},                   
{"TDSPRAS", TYPC, 1, 0},                
};                                       
#endif    

#ifndef SAP_TH_CCTLINE                
#define SAP_TH_CCTLINE                
static RFC_TYPEHANDLE handleOfCCTLINE;

static RFC_TYPE_ELEMENT typeOfCCTLINE[] = {
{"TEXTKEY", TYPNUM, 8, 0},               
{"TDFORMAT", TYPC, 2, 0},                
{"TDLINE", TYPC, 132, 0},                
};                                        
#endif                                     



#ifndef ENTRIES
#define ENTRIES(tab) (sizeof(tab)/sizeof((tab)[0]))
#endif
*/
#endif

